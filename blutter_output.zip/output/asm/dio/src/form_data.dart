// lib: , url: package:dio/src/form_data.dart

// class id: 1048888, size: 0x8
class :: {
}

// class id: 4536, size: 0x20, field offset: 0x8
class FormData extends Object {

  late String _boundary; // offset: 0x8

  int length(FormData) {
    // ** addr: 0x5587c4, size: 0x4ac
    // 0x5587c4: EnterFrame
    //     0x5587c4: stp             fp, lr, [SP, #-0x10]!
    //     0x5587c8: mov             fp, SP
    // 0x5587cc: AllocStack(0x60)
    //     0x5587cc: sub             SP, SP, #0x60
    // 0x5587d0: CheckStackOverflow
    //     0x5587d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5587d4: cmp             SP, x16
    //     0x5587d8: b.ls            #0x558c54
    // 0x5587dc: ldr             x1, [fp, #0x10]
    // 0x5587e0: LoadField: r2 = r1->field_f
    //     0x5587e0: ldur            w2, [x1, #0xf]
    // 0x5587e4: DecompressPointer r2
    //     0x5587e4: add             x2, x2, HEAP, lsl #32
    // 0x5587e8: stur            x2, [fp, #-0x28]
    // 0x5587ec: LoadField: r3 = r2->field_7
    //     0x5587ec: ldur            w3, [x2, #7]
    // 0x5587f0: DecompressPointer r3
    //     0x5587f0: add             x3, x3, HEAP, lsl #32
    // 0x5587f4: stur            x3, [fp, #-0x20]
    // 0x5587f8: LoadField: r0 = r2->field_b
    //     0x5587f8: ldur            w0, [x2, #0xb]
    // 0x5587fc: DecompressPointer r0
    //     0x5587fc: add             x0, x0, HEAP, lsl #32
    // 0x558800: r4 = LoadInt32Instr(r0)
    //     0x558800: sbfx            x4, x0, #1, #0x1f
    // 0x558804: stur            x4, [fp, #-0x18]
    // 0x558808: r6 = 0
    //     0x558808: mov             x6, #0
    // 0x55880c: r5 = 0
    //     0x55880c: mov             x5, #0
    // 0x558810: stur            x6, [fp, #-8]
    // 0x558814: stur            x5, [fp, #-0x10]
    // 0x558818: CheckStackOverflow
    //     0x558818: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55881c: cmp             SP, x16
    //     0x558820: b.ls            #0x558c5c
    // 0x558824: r0 = LoadClassIdInstr(r2)
    //     0x558824: ldur            x0, [x2, #-1]
    //     0x558828: ubfx            x0, x0, #0xc, #0x14
    // 0x55882c: SaveReg r2
    //     0x55882c: str             x2, [SP, #-8]!
    // 0x558830: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x558830: mov             x17, #0xb8ea
    //     0x558834: add             lr, x0, x17
    //     0x558838: ldr             lr, [x21, lr, lsl #3]
    //     0x55883c: blr             lr
    // 0x558840: add             SP, SP, #8
    // 0x558844: r1 = LoadInt32Instr(r0)
    //     0x558844: sbfx            x1, x0, #1, #0x1f
    //     0x558848: tbz             w0, #0, #0x558850
    //     0x55884c: ldur            x1, [x0, #7]
    // 0x558850: ldur            x2, [fp, #-0x18]
    // 0x558854: cmp             x2, x1
    // 0x558858: b.ne            #0x558c24
    // 0x55885c: ldur            x3, [fp, #-0x28]
    // 0x558860: ldur            x4, [fp, #-0x10]
    // 0x558864: cmp             x4, x1
    // 0x558868: b.lt            #0x558a3c
    // 0x55886c: ldr             x1, [fp, #0x10]
    // 0x558870: LoadField: r2 = r1->field_13
    //     0x558870: ldur            w2, [x1, #0x13]
    // 0x558874: DecompressPointer r2
    //     0x558874: add             x2, x2, HEAP, lsl #32
    // 0x558878: stur            x2, [fp, #-0x50]
    // 0x55887c: LoadField: r3 = r2->field_7
    //     0x55887c: ldur            w3, [x2, #7]
    // 0x558880: DecompressPointer r3
    //     0x558880: add             x3, x3, HEAP, lsl #32
    // 0x558884: stur            x3, [fp, #-0x48]
    // 0x558888: LoadField: r0 = r2->field_b
    //     0x558888: ldur            w0, [x2, #0xb]
    // 0x55888c: DecompressPointer r0
    //     0x55888c: add             x0, x0, HEAP, lsl #32
    // 0x558890: r4 = LoadInt32Instr(r0)
    //     0x558890: sbfx            x4, x0, #1, #0x1f
    // 0x558894: stur            x4, [fp, #-0x40]
    // 0x558898: ldur            x6, [fp, #-8]
    // 0x55889c: r5 = 0
    //     0x55889c: mov             x5, #0
    // 0x5588a0: stur            x6, [fp, #-0x30]
    // 0x5588a4: stur            x5, [fp, #-0x38]
    // 0x5588a8: CheckStackOverflow
    //     0x5588a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5588ac: cmp             SP, x16
    //     0x5588b0: b.ls            #0x558c64
    // 0x5588b4: r0 = LoadClassIdInstr(r2)
    //     0x5588b4: ldur            x0, [x2, #-1]
    //     0x5588b8: ubfx            x0, x0, #0xc, #0x14
    // 0x5588bc: SaveReg r2
    //     0x5588bc: str             x2, [SP, #-8]!
    // 0x5588c0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x5588c0: mov             x17, #0xb8ea
    //     0x5588c4: add             lr, x0, x17
    //     0x5588c8: ldr             lr, [x21, lr, lsl #3]
    //     0x5588cc: blr             lr
    // 0x5588d0: add             SP, SP, #8
    // 0x5588d4: r1 = LoadInt32Instr(r0)
    //     0x5588d4: sbfx            x1, x0, #1, #0x1f
    //     0x5588d8: tbz             w0, #0, #0x5588e0
    //     0x5588dc: ldur            x1, [x0, #7]
    // 0x5588e0: ldur            x2, [fp, #-0x40]
    // 0x5588e4: cmp             x2, x1
    // 0x5588e8: b.ne            #0x558c3c
    // 0x5588ec: ldur            x3, [fp, #-0x50]
    // 0x5588f0: ldur            x4, [fp, #-0x38]
    // 0x5588f4: cmp             x4, x1
    // 0x5588f8: b.lt            #0x558918
    // 0x5588fc: ldur            x5, [fp, #-0x30]
    // 0x558900: add             x0, x5, #2
    // 0x558904: add             x1, x0, #0x19
    // 0x558908: add             x0, x1, #4
    // 0x55890c: LeaveFrame
    //     0x55890c: mov             SP, fp
    //     0x558910: ldp             fp, lr, [SP], #0x10
    // 0x558914: ret
    //     0x558914: ret             
    // 0x558918: ldur            x5, [fp, #-0x30]
    // 0x55891c: r0 = BoxInt64Instr(r4)
    //     0x55891c: sbfiz           x0, x4, #1, #0x1f
    //     0x558920: cmp             x4, x0, asr #1
    //     0x558924: b.eq            #0x558930
    //     0x558928: bl              #0xd69bb8
    //     0x55892c: stur            x4, [x0, #7]
    // 0x558930: r1 = LoadClassIdInstr(r3)
    //     0x558930: ldur            x1, [x3, #-1]
    //     0x558934: ubfx            x1, x1, #0xc, #0x14
    // 0x558938: stp             x0, x3, [SP, #-0x10]!
    // 0x55893c: mov             x0, x1
    // 0x558940: r0 = GDT[cid_x0 + 0xd175]()
    //     0x558940: mov             x17, #0xd175
    //     0x558944: add             lr, x0, x17
    //     0x558948: ldr             lr, [x21, lr, lsl #3]
    //     0x55894c: blr             lr
    // 0x558950: add             SP, SP, #0x10
    // 0x558954: mov             x3, x0
    // 0x558958: ldur            x0, [fp, #-0x38]
    // 0x55895c: stur            x3, [fp, #-0x60]
    // 0x558960: add             x5, x0, #1
    // 0x558964: stur            x5, [fp, #-0x58]
    // 0x558968: cmp             w3, NULL
    // 0x55896c: b.ne            #0x5589a0
    // 0x558970: mov             x0, x3
    // 0x558974: ldur            x2, [fp, #-0x48]
    // 0x558978: r1 = Null
    //     0x558978: mov             x1, NULL
    // 0x55897c: cmp             w2, NULL
    // 0x558980: b.eq            #0x5589a0
    // 0x558984: LoadField: r4 = r2->field_17
    //     0x558984: ldur            w4, [x2, #0x17]
    // 0x558988: DecompressPointer r4
    //     0x558988: add             x4, x4, HEAP, lsl #32
    // 0x55898c: r8 = X0
    //     0x55898c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x558990: LoadField: r9 = r4->field_7
    //     0x558990: ldur            x9, [x4, #7]
    // 0x558994: r3 = Null
    //     0x558994: add             x3, PP, #0x14, lsl #12  ; [pp+0x14558] Null
    //     0x558998: ldr             x3, [x3, #0x558]
    // 0x55899c: blr             x9
    // 0x5589a0: ldur            x1, [fp, #-0x30]
    // 0x5589a4: ldur            x0, [fp, #-0x60]
    // 0x5589a8: ldr             x16, [fp, #0x10]
    // 0x5589ac: stp             x0, x16, [SP, #-0x10]!
    // 0x5589b0: r0 = _headerForFile()
    //     0x5589b0: bl              #0x558d5c  ; [package:dio/src/form_data.dart] FormData::_headerForFile
    // 0x5589b4: add             SP, SP, #0x10
    // 0x5589b8: r16 = Instance_Utf8Encoder
    //     0x5589b8: ldr             x16, [PP, #0x13f8]  ; [pp+0x13f8] Obj!Utf8Encoder<String, List<int>>@b5f7b1
    // 0x5589bc: stp             x0, x16, [SP, #-0x10]!
    // 0x5589c0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x5589c0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x5589c4: r0 = convert()
    //     0x5589c4: bl              #0xc1e4c0  ; [dart:convert] Utf8Encoder::convert
    // 0x5589c8: add             SP, SP, #0x10
    // 0x5589cc: LoadField: r1 = r0->field_13
    //     0x5589cc: ldur            w1, [x0, #0x13]
    // 0x5589d0: DecompressPointer r1
    //     0x5589d0: add             x1, x1, HEAP, lsl #32
    // 0x5589d4: r0 = LoadInt32Instr(r1)
    //     0x5589d4: sbfx            x0, x1, #1, #0x1f
    // 0x5589d8: add             x1, x0, #0x1d
    // 0x5589dc: ldur            x0, [fp, #-0x60]
    // 0x5589e0: stur            x1, [fp, #-0x38]
    // 0x5589e4: r2 = LoadClassIdInstr(r0)
    //     0x5589e4: ldur            x2, [x0, #-1]
    //     0x5589e8: ubfx            x2, x2, #0xc, #0x14
    // 0x5589ec: SaveReg r0
    //     0x5589ec: str             x0, [SP, #-8]!
    // 0x5589f0: mov             x0, x2
    // 0x5589f4: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x5589f4: sub             lr, x0, #0xfc4
    //     0x5589f8: ldr             lr, [x21, lr, lsl #3]
    //     0x5589fc: blr             lr
    // 0x558a00: add             SP, SP, #8
    // 0x558a04: cmp             w0, NULL
    // 0x558a08: b.eq            #0x558c6c
    // 0x558a0c: LoadField: r1 = r0->field_7
    //     0x558a0c: ldur            x1, [x0, #7]
    // 0x558a10: ldur            x0, [fp, #-0x38]
    // 0x558a14: add             x2, x0, x1
    // 0x558a18: add             x0, x2, #2
    // 0x558a1c: ldur            x1, [fp, #-0x30]
    // 0x558a20: add             x6, x1, x0
    // 0x558a24: ldur            x5, [fp, #-0x58]
    // 0x558a28: ldr             x1, [fp, #0x10]
    // 0x558a2c: ldur            x2, [fp, #-0x50]
    // 0x558a30: ldur            x3, [fp, #-0x48]
    // 0x558a34: ldur            x4, [fp, #-0x40]
    // 0x558a38: b               #0x5588a0
    // 0x558a3c: r0 = BoxInt64Instr(r4)
    //     0x558a3c: sbfiz           x0, x4, #1, #0x1f
    //     0x558a40: cmp             x4, x0, asr #1
    //     0x558a44: b.eq            #0x558a50
    //     0x558a48: bl              #0xd69bb8
    //     0x558a4c: stur            x4, [x0, #7]
    // 0x558a50: r1 = LoadClassIdInstr(r3)
    //     0x558a50: ldur            x1, [x3, #-1]
    //     0x558a54: ubfx            x1, x1, #0xc, #0x14
    // 0x558a58: stp             x0, x3, [SP, #-0x10]!
    // 0x558a5c: mov             x0, x1
    // 0x558a60: r0 = GDT[cid_x0 + 0xd175]()
    //     0x558a60: mov             x17, #0xd175
    //     0x558a64: add             lr, x0, x17
    //     0x558a68: ldr             lr, [x21, lr, lsl #3]
    //     0x558a6c: blr             lr
    // 0x558a70: add             SP, SP, #0x10
    // 0x558a74: mov             x3, x0
    // 0x558a78: ldur            x0, [fp, #-0x10]
    // 0x558a7c: stur            x3, [fp, #-0x48]
    // 0x558a80: add             x5, x0, #1
    // 0x558a84: stur            x5, [fp, #-0x30]
    // 0x558a88: cmp             w3, NULL
    // 0x558a8c: b.ne            #0x558ac0
    // 0x558a90: mov             x0, x3
    // 0x558a94: ldur            x2, [fp, #-0x20]
    // 0x558a98: r1 = Null
    //     0x558a98: mov             x1, NULL
    // 0x558a9c: cmp             w2, NULL
    // 0x558aa0: b.eq            #0x558ac0
    // 0x558aa4: LoadField: r4 = r2->field_17
    //     0x558aa4: ldur            w4, [x2, #0x17]
    // 0x558aa8: DecompressPointer r4
    //     0x558aa8: add             x4, x4, HEAP, lsl #32
    // 0x558aac: r8 = X0
    //     0x558aac: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x558ab0: LoadField: r9 = r4->field_7
    //     0x558ab0: ldur            x9, [x4, #7]
    // 0x558ab4: r3 = Null
    //     0x558ab4: add             x3, PP, #0x14, lsl #12  ; [pp+0x14568] Null
    //     0x558ab8: ldr             x3, [x3, #0x568]
    // 0x558abc: blr             x9
    // 0x558ac0: ldur            x2, [fp, #-8]
    // 0x558ac4: ldur            x1, [fp, #-0x48]
    // 0x558ac8: r0 = LoadClassIdInstr(r1)
    //     0x558ac8: ldur            x0, [x1, #-1]
    //     0x558acc: ubfx            x0, x0, #0xc, #0x14
    // 0x558ad0: SaveReg r1
    //     0x558ad0: str             x1, [SP, #-8]!
    // 0x558ad4: r0 = GDT[cid_x0 + -0xfba]()
    //     0x558ad4: sub             lr, x0, #0xfba
    //     0x558ad8: ldr             lr, [x21, lr, lsl #3]
    //     0x558adc: blr             lr
    // 0x558ae0: add             SP, SP, #8
    // 0x558ae4: mov             x2, x0
    // 0x558ae8: ldur            x1, [fp, #-0x48]
    // 0x558aec: stur            x2, [fp, #-0x50]
    // 0x558af0: r0 = LoadClassIdInstr(r1)
    //     0x558af0: ldur            x0, [x1, #-1]
    //     0x558af4: ubfx            x0, x0, #0xc, #0x14
    // 0x558af8: SaveReg r1
    //     0x558af8: str             x1, [SP, #-8]!
    // 0x558afc: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x558afc: sub             lr, x0, #0xfc4
    //     0x558b00: ldr             lr, [x21, lr, lsl #3]
    //     0x558b04: blr             lr
    // 0x558b08: add             SP, SP, #8
    // 0x558b0c: r1 = Null
    //     0x558b0c: mov             x1, NULL
    // 0x558b10: r2 = 8
    //     0x558b10: mov             x2, #8
    // 0x558b14: r0 = AllocateArray()
    //     0x558b14: bl              #0xd6987c  ; AllocateArrayStub
    // 0x558b18: stur            x0, [fp, #-0x60]
    // 0x558b1c: r17 = "content-disposition"
    //     0x558b1c: add             x17, PP, #0x14, lsl #12  ; [pp+0x14578] "content-disposition"
    //     0x558b20: ldr             x17, [x17, #0x578]
    // 0x558b24: StoreField: r0->field_f = r17
    //     0x558b24: stur            w17, [x0, #0xf]
    // 0x558b28: r17 = ": form-data; name=\""
    //     0x558b28: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] ": form-data; name=\""
    //     0x558b2c: ldr             x17, [x17, #0x580]
    // 0x558b30: StoreField: r0->field_13 = r17
    //     0x558b30: stur            w17, [x0, #0x13]
    // 0x558b34: ldr             x16, [fp, #0x10]
    // 0x558b38: ldur            lr, [fp, #-0x50]
    // 0x558b3c: stp             lr, x16, [SP, #-0x10]!
    // 0x558b40: r0 = _browserEncode()
    //     0x558b40: bl              #0x558cd8  ; [package:dio/src/form_data.dart] FormData::_browserEncode
    // 0x558b44: add             SP, SP, #0x10
    // 0x558b48: ldur            x1, [fp, #-0x60]
    // 0x558b4c: ArrayStore: r1[2] = r0  ; List_4
    //     0x558b4c: add             x25, x1, #0x17
    //     0x558b50: str             w0, [x25]
    //     0x558b54: tbz             w0, #0, #0x558b70
    //     0x558b58: ldurb           w16, [x1, #-1]
    //     0x558b5c: ldurb           w17, [x0, #-1]
    //     0x558b60: and             x16, x17, x16, lsr #2
    //     0x558b64: tst             x16, HEAP, lsr #32
    //     0x558b68: b.eq            #0x558b70
    //     0x558b6c: bl              #0xd67e5c
    // 0x558b70: ldur            x0, [fp, #-0x60]
    // 0x558b74: r17 = "\"\r\n\r\n"
    //     0x558b74: add             x17, PP, #0x14, lsl #12  ; [pp+0x14588] "\"\r\n\r\n"
    //     0x558b78: ldr             x17, [x17, #0x588]
    // 0x558b7c: StoreField: r0->field_1b = r17
    //     0x558b7c: stur            w17, [x0, #0x1b]
    // 0x558b80: SaveReg r0
    //     0x558b80: str             x0, [SP, #-8]!
    // 0x558b84: r0 = _interpolate()
    //     0x558b84: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x558b88: add             SP, SP, #8
    // 0x558b8c: r16 = Instance_Utf8Encoder
    //     0x558b8c: ldr             x16, [PP, #0x13f8]  ; [pp+0x13f8] Obj!Utf8Encoder<String, List<int>>@b5f7b1
    // 0x558b90: stp             x0, x16, [SP, #-0x10]!
    // 0x558b94: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x558b94: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x558b98: r0 = convert()
    //     0x558b98: bl              #0xc1e4c0  ; [dart:convert] Utf8Encoder::convert
    // 0x558b9c: add             SP, SP, #0x10
    // 0x558ba0: LoadField: r1 = r0->field_13
    //     0x558ba0: ldur            w1, [x0, #0x13]
    // 0x558ba4: DecompressPointer r1
    //     0x558ba4: add             x1, x1, HEAP, lsl #32
    // 0x558ba8: r0 = LoadInt32Instr(r1)
    //     0x558ba8: sbfx            x0, x1, #1, #0x1f
    // 0x558bac: add             x1, x0, #0x1d
    // 0x558bb0: ldur            x0, [fp, #-0x48]
    // 0x558bb4: stur            x1, [fp, #-0x10]
    // 0x558bb8: r2 = LoadClassIdInstr(r0)
    //     0x558bb8: ldur            x2, [x0, #-1]
    //     0x558bbc: ubfx            x2, x2, #0xc, #0x14
    // 0x558bc0: SaveReg r0
    //     0x558bc0: str             x0, [SP, #-8]!
    // 0x558bc4: mov             x0, x2
    // 0x558bc8: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x558bc8: sub             lr, x0, #0xfc4
    //     0x558bcc: ldr             lr, [x21, lr, lsl #3]
    //     0x558bd0: blr             lr
    // 0x558bd4: add             SP, SP, #8
    // 0x558bd8: r16 = Instance_Utf8Encoder
    //     0x558bd8: ldr             x16, [PP, #0x13f8]  ; [pp+0x13f8] Obj!Utf8Encoder<String, List<int>>@b5f7b1
    // 0x558bdc: stp             x0, x16, [SP, #-0x10]!
    // 0x558be0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x558be0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x558be4: r0 = convert()
    //     0x558be4: bl              #0xc1e4c0  ; [dart:convert] Utf8Encoder::convert
    // 0x558be8: add             SP, SP, #0x10
    // 0x558bec: LoadField: r1 = r0->field_13
    //     0x558bec: ldur            w1, [x0, #0x13]
    // 0x558bf0: DecompressPointer r1
    //     0x558bf0: add             x1, x1, HEAP, lsl #32
    // 0x558bf4: r0 = LoadInt32Instr(r1)
    //     0x558bf4: sbfx            x0, x1, #1, #0x1f
    // 0x558bf8: ldur            x1, [fp, #-0x10]
    // 0x558bfc: add             x2, x1, x0
    // 0x558c00: add             x0, x2, #2
    // 0x558c04: ldur            x1, [fp, #-8]
    // 0x558c08: add             x6, x1, x0
    // 0x558c0c: ldur            x5, [fp, #-0x30]
    // 0x558c10: ldr             x1, [fp, #0x10]
    // 0x558c14: ldur            x2, [fp, #-0x28]
    // 0x558c18: ldur            x3, [fp, #-0x20]
    // 0x558c1c: ldur            x4, [fp, #-0x18]
    // 0x558c20: b               #0x558810
    // 0x558c24: ldur            x0, [fp, #-0x28]
    // 0x558c28: r0 = ConcurrentModificationError()
    //     0x558c28: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x558c2c: ldur            x3, [fp, #-0x28]
    // 0x558c30: StoreField: r0->field_b = r3
    //     0x558c30: stur            w3, [x0, #0xb]
    // 0x558c34: r0 = Throw()
    //     0x558c34: bl              #0xd67e38  ; ThrowStub
    // 0x558c38: brk             #0
    // 0x558c3c: ldur            x0, [fp, #-0x50]
    // 0x558c40: r0 = ConcurrentModificationError()
    //     0x558c40: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x558c44: ldur            x3, [fp, #-0x50]
    // 0x558c48: StoreField: r0->field_b = r3
    //     0x558c48: stur            w3, [x0, #0xb]
    // 0x558c4c: r0 = Throw()
    //     0x558c4c: bl              #0xd67e38  ; ThrowStub
    // 0x558c50: brk             #0
    // 0x558c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x558c54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x558c58: b               #0x5587dc
    // 0x558c5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x558c5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x558c60: b               #0x558824
    // 0x558c64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x558c64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x558c68: b               #0x5588b4
    // 0x558c6c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x558c6c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  int dyn:get:length(FormData) {
    // ** addr: 0x558c88, size: 0x68
    // 0x558c88: EnterFrame
    //     0x558c88: stp             fp, lr, [SP, #-0x10]!
    //     0x558c8c: mov             fp, SP
    // 0x558c90: CheckStackOverflow
    //     0x558c90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x558c94: cmp             SP, x16
    //     0x558c98: b.ls            #0x558cd0
    // 0x558c9c: ldr             x16, [fp, #0x10]
    // 0x558ca0: SaveReg r16
    //     0x558ca0: str             x16, [SP, #-8]!
    // 0x558ca4: r0 = length()
    //     0x558ca4: bl              #0x5587c4  ; [package:dio/src/form_data.dart] FormData::length
    // 0x558ca8: add             SP, SP, #8
    // 0x558cac: mov             x2, x0
    // 0x558cb0: r0 = BoxInt64Instr(r2)
    //     0x558cb0: sbfiz           x0, x2, #1, #0x1f
    //     0x558cb4: cmp             x2, x0, asr #1
    //     0x558cb8: b.eq            #0x558cc4
    //     0x558cbc: bl              #0xd69bb8
    //     0x558cc0: stur            x2, [x0, #7]
    // 0x558cc4: LeaveFrame
    //     0x558cc4: mov             SP, fp
    //     0x558cc8: ldp             fp, lr, [SP], #0x10
    // 0x558ccc: ret
    //     0x558ccc: ret             
    // 0x558cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x558cd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x558cd4: b               #0x558c9c
  }
  _ _browserEncode(/* No info */) {
    // ** addr: 0x558cd8, size: 0x84
    // 0x558cd8: EnterFrame
    //     0x558cd8: stp             fp, lr, [SP, #-0x10]!
    //     0x558cdc: mov             fp, SP
    // 0x558ce0: CheckStackOverflow
    //     0x558ce0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x558ce4: cmp             SP, x16
    //     0x558ce8: b.ls            #0x558d54
    // 0x558cec: ldr             x0, [fp, #0x10]
    // 0x558cf0: cmp             w0, NULL
    // 0x558cf4: b.ne            #0x558d08
    // 0x558cf8: r0 = Null
    //     0x558cf8: mov             x0, NULL
    // 0x558cfc: LeaveFrame
    //     0x558cfc: mov             SP, fp
    //     0x558d00: ldp             fp, lr, [SP], #0x10
    // 0x558d04: ret
    //     0x558d04: ret             
    // 0x558d08: ldr             x1, [fp, #0x18]
    // 0x558d0c: LoadField: r2 = r1->field_b
    //     0x558d0c: ldur            w2, [x1, #0xb]
    // 0x558d10: DecompressPointer r2
    //     0x558d10: add             x2, x2, HEAP, lsl #32
    // 0x558d14: stp             x2, x0, [SP, #-0x10]!
    // 0x558d18: r16 = "%0D%0A"
    //     0x558d18: add             x16, PP, #0x14, lsl #12  ; [pp+0x14590] "%0D%0A"
    //     0x558d1c: ldr             x16, [x16, #0x590]
    // 0x558d20: SaveReg r16
    //     0x558d20: str             x16, [SP, #-8]!
    // 0x558d24: r0 = replaceAll()
    //     0x558d24: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0x558d28: add             SP, SP, #0x18
    // 0x558d2c: r16 = "\""
    //     0x558d2c: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0x558d30: stp             x16, x0, [SP, #-0x10]!
    // 0x558d34: r16 = "%22"
    //     0x558d34: add             x16, PP, #0x14, lsl #12  ; [pp+0x14598] "%22"
    //     0x558d38: ldr             x16, [x16, #0x598]
    // 0x558d3c: SaveReg r16
    //     0x558d3c: str             x16, [SP, #-8]!
    // 0x558d40: r0 = replaceAll()
    //     0x558d40: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0x558d44: add             SP, SP, #0x18
    // 0x558d48: LeaveFrame
    //     0x558d48: mov             SP, fp
    //     0x558d4c: ldp             fp, lr, [SP], #0x10
    // 0x558d50: ret
    //     0x558d50: ret             
    // 0x558d54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x558d54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x558d58: b               #0x558cec
  }
  _ _headerForFile(/* No info */) {
    // ** addr: 0x558d5c, size: 0x2b0
    // 0x558d5c: EnterFrame
    //     0x558d5c: stp             fp, lr, [SP, #-0x10]!
    //     0x558d60: mov             fp, SP
    // 0x558d64: AllocStack(0x20)
    //     0x558d64: sub             SP, SP, #0x20
    // 0x558d68: CheckStackOverflow
    //     0x558d68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x558d6c: cmp             SP, x16
    //     0x558d70: b.ls            #0x559000
    // 0x558d74: ldr             x1, [fp, #0x10]
    // 0x558d78: r0 = LoadClassIdInstr(r1)
    //     0x558d78: ldur            x0, [x1, #-1]
    //     0x558d7c: ubfx            x0, x0, #0xc, #0x14
    // 0x558d80: SaveReg r1
    //     0x558d80: str             x1, [SP, #-8]!
    // 0x558d84: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x558d84: sub             lr, x0, #0xfc4
    //     0x558d88: ldr             lr, [x21, lr, lsl #3]
    //     0x558d8c: blr             lr
    // 0x558d90: add             SP, SP, #8
    // 0x558d94: r1 = Null
    //     0x558d94: mov             x1, NULL
    // 0x558d98: r2 = 8
    //     0x558d98: mov             x2, #8
    // 0x558d9c: stur            x0, [fp, #-8]
    // 0x558da0: r0 = AllocateArray()
    //     0x558da0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x558da4: mov             x1, x0
    // 0x558da8: stur            x1, [fp, #-0x10]
    // 0x558dac: r17 = "content-disposition"
    //     0x558dac: add             x17, PP, #0x14, lsl #12  ; [pp+0x14578] "content-disposition"
    //     0x558db0: ldr             x17, [x17, #0x578]
    // 0x558db4: StoreField: r1->field_f = r17
    //     0x558db4: stur            w17, [x1, #0xf]
    // 0x558db8: r17 = ": form-data; name=\""
    //     0x558db8: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] ": form-data; name=\""
    //     0x558dbc: ldr             x17, [x17, #0x580]
    // 0x558dc0: StoreField: r1->field_13 = r17
    //     0x558dc0: stur            w17, [x1, #0x13]
    // 0x558dc4: ldr             x0, [fp, #0x10]
    // 0x558dc8: r2 = LoadClassIdInstr(r0)
    //     0x558dc8: ldur            x2, [x0, #-1]
    //     0x558dcc: ubfx            x2, x2, #0xc, #0x14
    // 0x558dd0: SaveReg r0
    //     0x558dd0: str             x0, [SP, #-8]!
    // 0x558dd4: mov             x0, x2
    // 0x558dd8: r0 = GDT[cid_x0 + -0xfba]()
    //     0x558dd8: sub             lr, x0, #0xfba
    //     0x558ddc: ldr             lr, [x21, lr, lsl #3]
    //     0x558de0: blr             lr
    // 0x558de4: add             SP, SP, #8
    // 0x558de8: ldr             x16, [fp, #0x18]
    // 0x558dec: stp             x0, x16, [SP, #-0x10]!
    // 0x558df0: r0 = _browserEncode()
    //     0x558df0: bl              #0x558cd8  ; [package:dio/src/form_data.dart] FormData::_browserEncode
    // 0x558df4: add             SP, SP, #0x10
    // 0x558df8: ldur            x1, [fp, #-0x10]
    // 0x558dfc: ArrayStore: r1[2] = r0  ; List_4
    //     0x558dfc: add             x25, x1, #0x17
    //     0x558e00: str             w0, [x25]
    //     0x558e04: tbz             w0, #0, #0x558e20
    //     0x558e08: ldurb           w16, [x1, #-1]
    //     0x558e0c: ldurb           w17, [x0, #-1]
    //     0x558e10: and             x16, x17, x16, lsr #2
    //     0x558e14: tst             x16, HEAP, lsr #32
    //     0x558e18: b.eq            #0x558e20
    //     0x558e1c: bl              #0xd67e5c
    // 0x558e20: ldur            x0, [fp, #-0x10]
    // 0x558e24: r17 = "\""
    //     0x558e24: ldr             x17, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0x558e28: StoreField: r0->field_1b = r17
    //     0x558e28: stur            w17, [x0, #0x1b]
    // 0x558e2c: SaveReg r0
    //     0x558e2c: str             x0, [SP, #-8]!
    // 0x558e30: r0 = _interpolate()
    //     0x558e30: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x558e34: add             SP, SP, #8
    // 0x558e38: stur            x0, [fp, #-0x10]
    // 0x558e3c: r1 = 1
    //     0x558e3c: mov             x1, #1
    // 0x558e40: r0 = AllocateContext()
    //     0x558e40: bl              #0xd68aa4  ; AllocateContextStub
    // 0x558e44: mov             x3, x0
    // 0x558e48: ldur            x0, [fp, #-0x10]
    // 0x558e4c: stur            x3, [fp, #-0x18]
    // 0x558e50: StoreField: r3->field_f = r0
    //     0x558e50: stur            w0, [x3, #0xf]
    // 0x558e54: ldur            x4, [fp, #-8]
    // 0x558e58: cmp             w4, NULL
    // 0x558e5c: b.eq            #0x559008
    // 0x558e60: r1 = Null
    //     0x558e60: mov             x1, NULL
    // 0x558e64: r2 = 8
    //     0x558e64: mov             x2, #8
    // 0x558e68: r0 = AllocateArray()
    //     0x558e68: bl              #0xd6987c  ; AllocateArrayStub
    // 0x558e6c: mov             x1, x0
    // 0x558e70: ldur            x0, [fp, #-0x10]
    // 0x558e74: stur            x1, [fp, #-0x20]
    // 0x558e78: StoreField: r1->field_f = r0
    //     0x558e78: stur            w0, [x1, #0xf]
    // 0x558e7c: r17 = "; filename=\""
    //     0x558e7c: add             x17, PP, #0x14, lsl #12  ; [pp+0x145a0] "; filename=\""
    //     0x558e80: ldr             x17, [x17, #0x5a0]
    // 0x558e84: StoreField: r1->field_13 = r17
    //     0x558e84: stur            w17, [x1, #0x13]
    // 0x558e88: ldur            x0, [fp, #-8]
    // 0x558e8c: LoadField: r2 = r0->field_f
    //     0x558e8c: ldur            w2, [x0, #0xf]
    // 0x558e90: DecompressPointer r2
    //     0x558e90: add             x2, x2, HEAP, lsl #32
    // 0x558e94: ldr             x16, [fp, #0x18]
    // 0x558e98: stp             x2, x16, [SP, #-0x10]!
    // 0x558e9c: r0 = _browserEncode()
    //     0x558e9c: bl              #0x558cd8  ; [package:dio/src/form_data.dart] FormData::_browserEncode
    // 0x558ea0: add             SP, SP, #0x10
    // 0x558ea4: ldur            x1, [fp, #-0x20]
    // 0x558ea8: ArrayStore: r1[2] = r0  ; List_4
    //     0x558ea8: add             x25, x1, #0x17
    //     0x558eac: str             w0, [x25]
    //     0x558eb0: tbz             w0, #0, #0x558ecc
    //     0x558eb4: ldurb           w16, [x1, #-1]
    //     0x558eb8: ldurb           w17, [x0, #-1]
    //     0x558ebc: and             x16, x17, x16, lsr #2
    //     0x558ec0: tst             x16, HEAP, lsr #32
    //     0x558ec4: b.eq            #0x558ecc
    //     0x558ec8: bl              #0xd67e5c
    // 0x558ecc: ldur            x0, [fp, #-0x20]
    // 0x558ed0: r17 = "\""
    //     0x558ed0: ldr             x17, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0x558ed4: StoreField: r0->field_1b = r17
    //     0x558ed4: stur            w17, [x0, #0x1b]
    // 0x558ed8: SaveReg r0
    //     0x558ed8: str             x0, [SP, #-8]!
    // 0x558edc: r0 = _interpolate()
    //     0x558edc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x558ee0: add             SP, SP, #8
    // 0x558ee4: mov             x4, x0
    // 0x558ee8: ldur            x3, [fp, #-0x18]
    // 0x558eec: stur            x4, [fp, #-0x10]
    // 0x558ef0: StoreField: r3->field_f = r0
    //     0x558ef0: stur            w0, [x3, #0xf]
    //     0x558ef4: ldurb           w16, [x3, #-1]
    //     0x558ef8: ldurb           w17, [x0, #-1]
    //     0x558efc: and             x16, x17, x16, lsr #2
    //     0x558f00: tst             x16, HEAP, lsr #32
    //     0x558f04: b.eq            #0x558f0c
    //     0x558f08: bl              #0xd682ac
    // 0x558f0c: r1 = Null
    //     0x558f0c: mov             x1, NULL
    // 0x558f10: r2 = 6
    //     0x558f10: mov             x2, #6
    // 0x558f14: r0 = AllocateArray()
    //     0x558f14: bl              #0xd6987c  ; AllocateArrayStub
    // 0x558f18: mov             x1, x0
    // 0x558f1c: ldur            x0, [fp, #-0x10]
    // 0x558f20: StoreField: r1->field_f = r0
    //     0x558f20: stur            w0, [x1, #0xf]
    // 0x558f24: r17 = "\r\ncontent-type: "
    //     0x558f24: add             x17, PP, #0x14, lsl #12  ; [pp+0x145a8] "\r\ncontent-type: "
    //     0x558f28: ldr             x17, [x17, #0x5a8]
    // 0x558f2c: StoreField: r1->field_13 = r17
    //     0x558f2c: stur            w17, [x1, #0x13]
    // 0x558f30: ldur            x0, [fp, #-8]
    // 0x558f34: LoadField: r2 = r0->field_17
    //     0x558f34: ldur            w2, [x0, #0x17]
    // 0x558f38: DecompressPointer r2
    //     0x558f38: add             x2, x2, HEAP, lsl #32
    // 0x558f3c: StoreField: r1->field_17 = r2
    //     0x558f3c: stur            w2, [x1, #0x17]
    // 0x558f40: SaveReg r1
    //     0x558f40: str             x1, [SP, #-8]!
    // 0x558f44: r0 = _interpolate()
    //     0x558f44: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x558f48: add             SP, SP, #8
    // 0x558f4c: ldur            x3, [fp, #-0x18]
    // 0x558f50: StoreField: r3->field_f = r0
    //     0x558f50: stur            w0, [x3, #0xf]
    //     0x558f54: ldurb           w16, [x3, #-1]
    //     0x558f58: ldurb           w17, [x0, #-1]
    //     0x558f5c: and             x16, x17, x16, lsr #2
    //     0x558f60: tst             x16, HEAP, lsr #32
    //     0x558f64: b.eq            #0x558f6c
    //     0x558f68: bl              #0xd682ac
    // 0x558f6c: ldur            x0, [fp, #-8]
    // 0x558f70: LoadField: r4 = r0->field_13
    //     0x558f70: ldur            w4, [x0, #0x13]
    // 0x558f74: DecompressPointer r4
    //     0x558f74: add             x4, x4, HEAP, lsl #32
    // 0x558f78: mov             x2, x3
    // 0x558f7c: stur            x4, [fp, #-0x10]
    // 0x558f80: r1 = Function '<anonymous closure>':.
    //     0x558f80: add             x1, PP, #0x14, lsl #12  ; [pp+0x145b0] AnonymousClosure: (0x55900c), in [package:dio/src/form_data.dart] FormData::_headerForFile (0x558d5c)
    //     0x558f84: ldr             x1, [x1, #0x5b0]
    // 0x558f88: r0 = AllocateClosure()
    //     0x558f88: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x558f8c: mov             x1, x0
    // 0x558f90: ldur            x0, [fp, #-0x10]
    // 0x558f94: r2 = LoadClassIdInstr(r0)
    //     0x558f94: ldur            x2, [x0, #-1]
    //     0x558f98: ubfx            x2, x2, #0xc, #0x14
    // 0x558f9c: stp             x1, x0, [SP, #-0x10]!
    // 0x558fa0: mov             x0, x2
    // 0x558fa4: r0 = GDT[cid_x0 + 0x66b]()
    //     0x558fa4: add             lr, x0, #0x66b
    //     0x558fa8: ldr             lr, [x21, lr, lsl #3]
    //     0x558fac: blr             lr
    // 0x558fb0: add             SP, SP, #0x10
    // 0x558fb4: ldur            x0, [fp, #-0x18]
    // 0x558fb8: LoadField: r3 = r0->field_f
    //     0x558fb8: ldur            w3, [x0, #0xf]
    // 0x558fbc: DecompressPointer r3
    //     0x558fbc: add             x3, x3, HEAP, lsl #32
    // 0x558fc0: stur            x3, [fp, #-8]
    // 0x558fc4: r1 = Null
    //     0x558fc4: mov             x1, NULL
    // 0x558fc8: r2 = 4
    //     0x558fc8: mov             x2, #4
    // 0x558fcc: r0 = AllocateArray()
    //     0x558fcc: bl              #0xd6987c  ; AllocateArrayStub
    // 0x558fd0: mov             x1, x0
    // 0x558fd4: ldur            x0, [fp, #-8]
    // 0x558fd8: StoreField: r1->field_f = r0
    //     0x558fd8: stur            w0, [x1, #0xf]
    // 0x558fdc: r17 = "\r\n\r\n"
    //     0x558fdc: add             x17, PP, #0x14, lsl #12  ; [pp+0x145b8] "\r\n\r\n"
    //     0x558fe0: ldr             x17, [x17, #0x5b8]
    // 0x558fe4: StoreField: r1->field_13 = r17
    //     0x558fe4: stur            w17, [x1, #0x13]
    // 0x558fe8: SaveReg r1
    //     0x558fe8: str             x1, [SP, #-8]!
    // 0x558fec: r0 = _interpolate()
    //     0x558fec: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x558ff0: add             SP, SP, #8
    // 0x558ff4: LeaveFrame
    //     0x558ff4: mov             SP, fp
    //     0x558ff8: ldp             fp, lr, [SP], #0x10
    // 0x558ffc: ret
    //     0x558ffc: ret             
    // 0x559000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x559000: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x559004: b               #0x558d74
    // 0x559008: r0 = NullErrorSharedWithoutFPURegs()
    //     0x559008: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String, List<String>) {
    // ** addr: 0x55900c, size: 0x15c
    // 0x55900c: EnterFrame
    //     0x55900c: stp             fp, lr, [SP, #-0x10]!
    //     0x559010: mov             fp, SP
    // 0x559014: AllocStack(0x20)
    //     0x559014: sub             SP, SP, #0x20
    // 0x559018: SetupParameters()
    //     0x559018: ldr             x0, [fp, #0x20]
    //     0x55901c: ldur            w1, [x0, #0x17]
    //     0x559020: add             x1, x1, HEAP, lsl #32
    //     0x559024: stur            x1, [fp, #-8]
    // 0x559028: CheckStackOverflow
    //     0x559028: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55902c: cmp             SP, x16
    //     0x559030: b.ls            #0x559158
    // 0x559034: ldr             x0, [fp, #0x10]
    // 0x559038: r2 = LoadClassIdInstr(r0)
    //     0x559038: ldur            x2, [x0, #-1]
    //     0x55903c: ubfx            x2, x2, #0xc, #0x14
    // 0x559040: SaveReg r0
    //     0x559040: str             x0, [SP, #-8]!
    // 0x559044: mov             x0, x2
    // 0x559048: r0 = GDT[cid_x0 + 0xb940]()
    //     0x559048: mov             x17, #0xb940
    //     0x55904c: add             lr, x0, x17
    //     0x559050: ldr             lr, [x21, lr, lsl #3]
    //     0x559054: blr             lr
    // 0x559058: add             SP, SP, #8
    // 0x55905c: mov             x1, x0
    // 0x559060: stur            x1, [fp, #-0x10]
    // 0x559064: ldur            x2, [fp, #-8]
    // 0x559068: ldr             x3, [fp, #0x18]
    // 0x55906c: CheckStackOverflow
    //     0x55906c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x559070: cmp             SP, x16
    //     0x559074: b.ls            #0x559160
    // 0x559078: r0 = LoadClassIdInstr(r1)
    //     0x559078: ldur            x0, [x1, #-1]
    //     0x55907c: ubfx            x0, x0, #0xc, #0x14
    // 0x559080: SaveReg r1
    //     0x559080: str             x1, [SP, #-8]!
    // 0x559084: r0 = GDT[cid_x0 + 0x541]()
    //     0x559084: add             lr, x0, #0x541
    //     0x559088: ldr             lr, [x21, lr, lsl #3]
    //     0x55908c: blr             lr
    // 0x559090: add             SP, SP, #8
    // 0x559094: tbnz            w0, #4, #0x559148
    // 0x559098: ldr             x3, [fp, #0x18]
    // 0x55909c: ldur            x2, [fp, #-8]
    // 0x5590a0: ldur            x1, [fp, #-0x10]
    // 0x5590a4: r0 = LoadClassIdInstr(r1)
    //     0x5590a4: ldur            x0, [x1, #-1]
    //     0x5590a8: ubfx            x0, x0, #0xc, #0x14
    // 0x5590ac: SaveReg r1
    //     0x5590ac: str             x1, [SP, #-8]!
    // 0x5590b0: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x5590b0: add             lr, x0, #0x5ca
    //     0x5590b4: ldr             lr, [x21, lr, lsl #3]
    //     0x5590b8: blr             lr
    // 0x5590bc: add             SP, SP, #8
    // 0x5590c0: mov             x3, x0
    // 0x5590c4: ldur            x0, [fp, #-8]
    // 0x5590c8: stur            x3, [fp, #-0x20]
    // 0x5590cc: LoadField: r4 = r0->field_f
    //     0x5590cc: ldur            w4, [x0, #0xf]
    // 0x5590d0: DecompressPointer r4
    //     0x5590d0: add             x4, x4, HEAP, lsl #32
    // 0x5590d4: stur            x4, [fp, #-0x18]
    // 0x5590d8: r1 = Null
    //     0x5590d8: mov             x1, NULL
    // 0x5590dc: r2 = 10
    //     0x5590dc: mov             x2, #0xa
    // 0x5590e0: r0 = AllocateArray()
    //     0x5590e0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5590e4: mov             x1, x0
    // 0x5590e8: ldur            x0, [fp, #-0x18]
    // 0x5590ec: StoreField: r1->field_f = r0
    //     0x5590ec: stur            w0, [x1, #0xf]
    // 0x5590f0: r17 = "\r\n"
    //     0x5590f0: ldr             x17, [PP, #0x7960]  ; [pp+0x7960] "\r\n"
    // 0x5590f4: StoreField: r1->field_13 = r17
    //     0x5590f4: stur            w17, [x1, #0x13]
    // 0x5590f8: ldr             x0, [fp, #0x18]
    // 0x5590fc: StoreField: r1->field_17 = r0
    //     0x5590fc: stur            w0, [x1, #0x17]
    // 0x559100: r17 = ": "
    //     0x559100: ldr             x17, [PP, #0xf48]  ; [pp+0xf48] ": "
    // 0x559104: StoreField: r1->field_1b = r17
    //     0x559104: stur            w17, [x1, #0x1b]
    // 0x559108: ldur            x2, [fp, #-0x20]
    // 0x55910c: StoreField: r1->field_1f = r2
    //     0x55910c: stur            w2, [x1, #0x1f]
    // 0x559110: SaveReg r1
    //     0x559110: str             x1, [SP, #-8]!
    // 0x559114: r0 = _interpolate()
    //     0x559114: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x559118: add             SP, SP, #8
    // 0x55911c: ldur            x1, [fp, #-8]
    // 0x559120: StoreField: r1->field_f = r0
    //     0x559120: stur            w0, [x1, #0xf]
    //     0x559124: ldurb           w16, [x1, #-1]
    //     0x559128: ldurb           w17, [x0, #-1]
    //     0x55912c: and             x16, x17, x16, lsr #2
    //     0x559130: tst             x16, HEAP, lsr #32
    //     0x559134: b.eq            #0x55913c
    //     0x559138: bl              #0xd6826c
    // 0x55913c: mov             x2, x1
    // 0x559140: ldur            x1, [fp, #-0x10]
    // 0x559144: b               #0x559068
    // 0x559148: r0 = Null
    //     0x559148: mov             x0, NULL
    // 0x55914c: LeaveFrame
    //     0x55914c: mov             SP, fp
    //     0x559150: ldp             fp, lr, [SP], #0x10
    // 0x559154: ret
    //     0x559154: ret             
    // 0x559158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x559158: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55915c: b               #0x559034
    // 0x559160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x559160: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x559164: b               #0x559078
  }
  _ finalize(/* No info */) {
    // ** addr: 0x559168, size: 0x4cc
    // 0x559168: EnterFrame
    //     0x559168: stp             fp, lr, [SP, #-0x10]!
    //     0x55916c: mov             fp, SP
    // 0x559170: AllocStack(0x60)
    //     0x559170: sub             SP, SP, #0x60
    // 0x559174: CheckStackOverflow
    //     0x559174: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x559178: cmp             SP, x16
    //     0x55917c: b.ls            #0x559618
    // 0x559180: r1 = 4
    //     0x559180: mov             x1, #4
    // 0x559184: r0 = AllocateContext()
    //     0x559184: bl              #0xd68aa4  ; AllocateContextStub
    // 0x559188: mov             x1, x0
    // 0x55918c: ldr             x0, [fp, #0x10]
    // 0x559190: stur            x1, [fp, #-8]
    // 0x559194: StoreField: r1->field_f = r0
    //     0x559194: stur            w0, [x1, #0xf]
    // 0x559198: LoadField: r2 = r0->field_17
    //     0x559198: ldur            w2, [x0, #0x17]
    // 0x55919c: DecompressPointer r2
    //     0x55919c: add             x2, x2, HEAP, lsl #32
    // 0x5591a0: tbz             w2, #4, #0x5595e0
    // 0x5591a4: r2 = true
    //     0x5591a4: add             x2, NULL, #0x20  ; true
    // 0x5591a8: StoreField: r0->field_17 = r2
    //     0x5591a8: stur            w2, [x0, #0x17]
    // 0x5591ac: r16 = <List<int>>
    //     0x5591ac: ldr             x16, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0x5591b0: r30 = false
    //     0x5591b0: add             lr, NULL, #0x30  ; false
    // 0x5591b4: stp             lr, x16, [SP, #-0x10]!
    // 0x5591b8: r4 = const [0, 0x2, 0x2, 0x1, sync, 0x1, null]
    //     0x5591b8: ldr             x4, [PP, #0x31b0]  ; [pp+0x31b0] List(7) [0, 0x2, 0x2, 0x1, "sync", 0x1, Null]
    // 0x5591bc: r0 = StreamController()
    //     0x5591bc: bl              #0x534f54  ; [dart:async] StreamController::StreamController
    // 0x5591c0: add             SP, SP, #0x10
    // 0x5591c4: mov             x4, x0
    // 0x5591c8: ldur            x3, [fp, #-8]
    // 0x5591cc: stur            x4, [fp, #-0x10]
    // 0x5591d0: StoreField: r3->field_13 = r0
    //     0x5591d0: stur            w0, [x3, #0x13]
    //     0x5591d4: tbz             w0, #0, #0x5591f0
    //     0x5591d8: ldurb           w16, [x3, #-1]
    //     0x5591dc: ldurb           w17, [x0, #-1]
    //     0x5591e0: and             x16, x17, x16, lsr #2
    //     0x5591e4: tst             x16, HEAP, lsr #32
    //     0x5591e8: b.eq            #0x5591f0
    //     0x5591ec: bl              #0xd682ac
    // 0x5591f0: mov             x2, x3
    // 0x5591f4: r1 = Function 'writeAscii':.
    //     0x5591f4: add             x1, PP, #0x14, lsl #12  ; [pp+0x145c8] AnonymousClosure: (0x55a3c0), in [package:dio/src/form_data.dart] FormData::finalize (0x559168)
    //     0x5591f8: ldr             x1, [x1, #0x5c8]
    // 0x5591fc: r0 = AllocateClosure()
    //     0x5591fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x559200: mov             x4, x0
    // 0x559204: ldur            x3, [fp, #-8]
    // 0x559208: stur            x4, [fp, #-0x18]
    // 0x55920c: StoreField: r3->field_17 = r0
    //     0x55920c: stur            w0, [x3, #0x17]
    //     0x559210: ldurb           w16, [x3, #-1]
    //     0x559214: ldurb           w17, [x0, #-1]
    //     0x559218: and             x16, x17, x16, lsr #2
    //     0x55921c: tst             x16, HEAP, lsr #32
    //     0x559220: b.eq            #0x559228
    //     0x559224: bl              #0xd682ac
    // 0x559228: mov             x2, x3
    // 0x55922c: r1 = Function 'writeLine':.
    //     0x55922c: add             x1, PP, #0x14, lsl #12  ; [pp+0x145d0] AnonymousClosure: (0x55a32c), in [package:dio/src/form_data.dart] FormData::finalize (0x559168)
    //     0x559230: ldr             x1, [x1, #0x5d0]
    // 0x559234: r0 = AllocateClosure()
    //     0x559234: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x559238: mov             x1, x0
    // 0x55923c: ldur            x2, [fp, #-8]
    // 0x559240: stur            x1, [fp, #-0x40]
    // 0x559244: StoreField: r2->field_1b = r0
    //     0x559244: stur            w0, [x2, #0x1b]
    //     0x559248: ldurb           w16, [x2, #-1]
    //     0x55924c: ldurb           w17, [x0, #-1]
    //     0x559250: and             x16, x17, x16, lsr #2
    //     0x559254: tst             x16, HEAP, lsr #32
    //     0x559258: b.eq            #0x559260
    //     0x55925c: bl              #0xd6828c
    // 0x559260: ldr             x3, [fp, #0x10]
    // 0x559264: LoadField: r4 = r3->field_f
    //     0x559264: ldur            w4, [x3, #0xf]
    // 0x559268: DecompressPointer r4
    //     0x559268: add             x4, x4, HEAP, lsl #32
    // 0x55926c: stur            x4, [fp, #-0x38]
    // 0x559270: LoadField: r5 = r4->field_7
    //     0x559270: ldur            w5, [x4, #7]
    // 0x559274: DecompressPointer r5
    //     0x559274: add             x5, x5, HEAP, lsl #32
    // 0x559278: stur            x5, [fp, #-0x30]
    // 0x55927c: LoadField: r0 = r4->field_b
    //     0x55927c: ldur            w0, [x4, #0xb]
    // 0x559280: DecompressPointer r0
    //     0x559280: add             x0, x0, HEAP, lsl #32
    // 0x559284: r6 = LoadInt32Instr(r0)
    //     0x559284: sbfx            x6, x0, #1, #0x1f
    // 0x559288: stur            x6, [fp, #-0x28]
    // 0x55928c: r8 = 0
    //     0x55928c: mov             x8, #0
    // 0x559290: ldur            x7, [fp, #-0x10]
    // 0x559294: stur            x8, [fp, #-0x20]
    // 0x559298: CheckStackOverflow
    //     0x559298: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55929c: cmp             SP, x16
    //     0x5592a0: b.ls            #0x559620
    // 0x5592a4: r0 = LoadClassIdInstr(r4)
    //     0x5592a4: ldur            x0, [x4, #-1]
    //     0x5592a8: ubfx            x0, x0, #0xc, #0x14
    // 0x5592ac: SaveReg r4
    //     0x5592ac: str             x4, [SP, #-8]!
    // 0x5592b0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x5592b0: mov             x17, #0xb8ea
    //     0x5592b4: add             lr, x0, x17
    //     0x5592b8: ldr             lr, [x21, lr, lsl #3]
    //     0x5592bc: blr             lr
    // 0x5592c0: add             SP, SP, #8
    // 0x5592c4: r1 = LoadInt32Instr(r0)
    //     0x5592c4: sbfx            x1, x0, #1, #0x1f
    //     0x5592c8: tbz             w0, #0, #0x5592d0
    //     0x5592cc: ldur            x1, [x0, #7]
    // 0x5592d0: ldur            x2, [fp, #-0x28]
    // 0x5592d4: cmp             x2, x1
    // 0x5592d8: b.ne            #0x559600
    // 0x5592dc: ldur            x3, [fp, #-0x38]
    // 0x5592e0: ldur            x4, [fp, #-0x20]
    // 0x5592e4: cmp             x4, x1
    // 0x5592e8: b.lt            #0x559384
    // 0x5592ec: ldr             x5, [fp, #0x10]
    // 0x5592f0: ldur            x0, [fp, #-0x10]
    // 0x5592f4: LoadField: r3 = r5->field_13
    //     0x5592f4: ldur            w3, [x5, #0x13]
    // 0x5592f8: DecompressPointer r3
    //     0x5592f8: add             x3, x3, HEAP, lsl #32
    // 0x5592fc: ldur            x2, [fp, #-8]
    // 0x559300: stur            x3, [fp, #-0x48]
    // 0x559304: r1 = Function '<anonymous closure>':.
    //     0x559304: add             x1, PP, #0x14, lsl #12  ; [pp+0x145d8] AnonymousClosure: (0x559f84), in [package:dio/src/form_data.dart] FormData::finalize (0x559168)
    //     0x559308: ldr             x1, [x1, #0x5d8]
    // 0x55930c: r0 = AllocateClosure()
    //     0x55930c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x559310: r16 = <MapEntry<String, MultipartFile>>
    //     0x559310: add             x16, PP, #0x14, lsl #12  ; [pp+0x145e0] TypeArguments: <MapEntry<String, MultipartFile>>
    //     0x559314: ldr             x16, [x16, #0x5e0]
    // 0x559318: ldur            lr, [fp, #-0x48]
    // 0x55931c: stp             lr, x16, [SP, #-0x10]!
    // 0x559320: SaveReg r0
    //     0x559320: str             x0, [SP, #-8]!
    // 0x559324: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x559324: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x559328: r0 = forEach()
    //     0x559328: bl              #0x559634  ; [dart:async] Future::forEach
    // 0x55932c: add             SP, SP, #0x18
    // 0x559330: ldur            x2, [fp, #-8]
    // 0x559334: r1 = Function '<anonymous closure>':.
    //     0x559334: add             x1, PP, #0x14, lsl #12  ; [pp+0x145e8] AnonymousClosure: (0x559d00), in [package:dio/src/form_data.dart] FormData::finalize (0x559168)
    //     0x559338: ldr             x1, [x1, #0x5e8]
    // 0x55933c: stur            x0, [fp, #-0x48]
    // 0x559340: r0 = AllocateClosure()
    //     0x559340: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x559344: r16 = <Null?>
    //     0x559344: ldr             x16, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    // 0x559348: ldur            lr, [fp, #-0x48]
    // 0x55934c: stp             lr, x16, [SP, #-0x10]!
    // 0x559350: SaveReg r0
    //     0x559350: str             x0, [SP, #-8]!
    // 0x559354: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x559354: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x559358: r0 = then()
    //     0x559358: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x55935c: add             SP, SP, #0x18
    // 0x559360: ldur            x0, [fp, #-0x10]
    // 0x559364: LoadField: r1 = r0->field_7
    //     0x559364: ldur            w1, [x0, #7]
    // 0x559368: DecompressPointer r1
    //     0x559368: add             x1, x1, HEAP, lsl #32
    // 0x55936c: r0 = _ControllerStream()
    //     0x55936c: bl              #0x534e34  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x14)
    // 0x559370: ldur            x6, [fp, #-0x10]
    // 0x559374: StoreField: r0->field_f = r6
    //     0x559374: stur            w6, [x0, #0xf]
    // 0x559378: LeaveFrame
    //     0x559378: mov             SP, fp
    //     0x55937c: ldp             fp, lr, [SP], #0x10
    // 0x559380: ret
    //     0x559380: ret             
    // 0x559384: ldr             x5, [fp, #0x10]
    // 0x559388: ldur            x6, [fp, #-0x10]
    // 0x55938c: r0 = BoxInt64Instr(r4)
    //     0x55938c: sbfiz           x0, x4, #1, #0x1f
    //     0x559390: cmp             x4, x0, asr #1
    //     0x559394: b.eq            #0x5593a0
    //     0x559398: bl              #0xd69bb8
    //     0x55939c: stur            x4, [x0, #7]
    // 0x5593a0: r1 = LoadClassIdInstr(r3)
    //     0x5593a0: ldur            x1, [x3, #-1]
    //     0x5593a4: ubfx            x1, x1, #0xc, #0x14
    // 0x5593a8: stp             x0, x3, [SP, #-0x10]!
    // 0x5593ac: mov             x0, x1
    // 0x5593b0: r0 = GDT[cid_x0 + 0xd175]()
    //     0x5593b0: mov             x17, #0xd175
    //     0x5593b4: add             lr, x0, x17
    //     0x5593b8: ldr             lr, [x21, lr, lsl #3]
    //     0x5593bc: blr             lr
    // 0x5593c0: add             SP, SP, #0x10
    // 0x5593c4: mov             x3, x0
    // 0x5593c8: ldur            x0, [fp, #-0x20]
    // 0x5593cc: stur            x3, [fp, #-0x48]
    // 0x5593d0: add             x8, x0, #1
    // 0x5593d4: stur            x8, [fp, #-0x50]
    // 0x5593d8: cmp             w3, NULL
    // 0x5593dc: b.ne            #0x559410
    // 0x5593e0: mov             x0, x3
    // 0x5593e4: ldur            x2, [fp, #-0x30]
    // 0x5593e8: r1 = Null
    //     0x5593e8: mov             x1, NULL
    // 0x5593ec: cmp             w2, NULL
    // 0x5593f0: b.eq            #0x559410
    // 0x5593f4: LoadField: r4 = r2->field_17
    //     0x5593f4: ldur            w4, [x2, #0x17]
    // 0x5593f8: DecompressPointer r4
    //     0x5593f8: add             x4, x4, HEAP, lsl #32
    // 0x5593fc: r8 = X0
    //     0x5593fc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x559400: LoadField: r9 = r4->field_7
    //     0x559400: ldur            x9, [x4, #7]
    // 0x559404: r3 = Null
    //     0x559404: add             x3, PP, #0x14, lsl #12  ; [pp+0x145f0] Null
    //     0x559408: ldr             x3, [x3, #0x5f0]
    // 0x55940c: blr             x9
    // 0x559410: ldr             x3, [fp, #0x10]
    // 0x559414: ldur            x0, [fp, #-0x48]
    // 0x559418: r1 = Null
    //     0x559418: mov             x1, NULL
    // 0x55941c: r2 = 6
    //     0x55941c: mov             x2, #6
    // 0x559420: r0 = AllocateArray()
    //     0x559420: bl              #0xd6987c  ; AllocateArrayStub
    // 0x559424: r17 = "--"
    //     0x559424: add             x17, PP, #0x14, lsl #12  ; [pp+0x14600] "--"
    //     0x559428: ldr             x17, [x17, #0x600]
    // 0x55942c: StoreField: r0->field_f = r17
    //     0x55942c: stur            w17, [x0, #0xf]
    // 0x559430: ldr             x1, [fp, #0x10]
    // 0x559434: LoadField: r2 = r1->field_7
    //     0x559434: ldur            w2, [x1, #7]
    // 0x559438: DecompressPointer r2
    //     0x559438: add             x2, x2, HEAP, lsl #32
    // 0x55943c: r16 = Sentinel
    //     0x55943c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x559440: cmp             w2, w16
    // 0x559444: b.eq            #0x559628
    // 0x559448: StoreField: r0->field_13 = r2
    //     0x559448: stur            w2, [x0, #0x13]
    // 0x55944c: r17 = "\r\n"
    //     0x55944c: ldr             x17, [PP, #0x7960]  ; [pp+0x7960] "\r\n"
    // 0x559450: StoreField: r0->field_17 = r17
    //     0x559450: stur            w17, [x0, #0x17]
    // 0x559454: SaveReg r0
    //     0x559454: str             x0, [SP, #-8]!
    // 0x559458: r0 = _interpolate()
    //     0x559458: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x55945c: add             SP, SP, #8
    // 0x559460: ldur            x16, [fp, #-0x18]
    // 0x559464: stp             x0, x16, [SP, #-0x10]!
    // 0x559468: ldur            x0, [fp, #-0x18]
    // 0x55946c: ClosureCall
    //     0x55946c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x559470: ldur            x2, [x0, #0x1f]
    //     0x559474: blr             x2
    // 0x559478: add             SP, SP, #0x10
    // 0x55947c: ldur            x1, [fp, #-0x48]
    // 0x559480: r0 = LoadClassIdInstr(r1)
    //     0x559480: ldur            x0, [x1, #-1]
    //     0x559484: ubfx            x0, x0, #0xc, #0x14
    // 0x559488: SaveReg r1
    //     0x559488: str             x1, [SP, #-8]!
    // 0x55948c: r0 = GDT[cid_x0 + -0xfba]()
    //     0x55948c: sub             lr, x0, #0xfba
    //     0x559490: ldr             lr, [x21, lr, lsl #3]
    //     0x559494: blr             lr
    // 0x559498: add             SP, SP, #8
    // 0x55949c: mov             x2, x0
    // 0x5594a0: ldur            x1, [fp, #-0x48]
    // 0x5594a4: stur            x2, [fp, #-0x58]
    // 0x5594a8: r0 = LoadClassIdInstr(r1)
    //     0x5594a8: ldur            x0, [x1, #-1]
    //     0x5594ac: ubfx            x0, x0, #0xc, #0x14
    // 0x5594b0: SaveReg r1
    //     0x5594b0: str             x1, [SP, #-8]!
    // 0x5594b4: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x5594b4: sub             lr, x0, #0xfc4
    //     0x5594b8: ldr             lr, [x21, lr, lsl #3]
    //     0x5594bc: blr             lr
    // 0x5594c0: add             SP, SP, #8
    // 0x5594c4: r1 = Null
    //     0x5594c4: mov             x1, NULL
    // 0x5594c8: r2 = 8
    //     0x5594c8: mov             x2, #8
    // 0x5594cc: r0 = AllocateArray()
    //     0x5594cc: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5594d0: stur            x0, [fp, #-0x60]
    // 0x5594d4: r17 = "content-disposition"
    //     0x5594d4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14578] "content-disposition"
    //     0x5594d8: ldr             x17, [x17, #0x578]
    // 0x5594dc: StoreField: r0->field_f = r17
    //     0x5594dc: stur            w17, [x0, #0xf]
    // 0x5594e0: r17 = ": form-data; name=\""
    //     0x5594e0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] ": form-data; name=\""
    //     0x5594e4: ldr             x17, [x17, #0x580]
    // 0x5594e8: StoreField: r0->field_13 = r17
    //     0x5594e8: stur            w17, [x0, #0x13]
    // 0x5594ec: ldr             x16, [fp, #0x10]
    // 0x5594f0: ldur            lr, [fp, #-0x58]
    // 0x5594f4: stp             lr, x16, [SP, #-0x10]!
    // 0x5594f8: r0 = _browserEncode()
    //     0x5594f8: bl              #0x558cd8  ; [package:dio/src/form_data.dart] FormData::_browserEncode
    // 0x5594fc: add             SP, SP, #0x10
    // 0x559500: ldur            x1, [fp, #-0x60]
    // 0x559504: ArrayStore: r1[2] = r0  ; List_4
    //     0x559504: add             x25, x1, #0x17
    //     0x559508: str             w0, [x25]
    //     0x55950c: tbz             w0, #0, #0x559528
    //     0x559510: ldurb           w16, [x1, #-1]
    //     0x559514: ldurb           w17, [x0, #-1]
    //     0x559518: and             x16, x17, x16, lsr #2
    //     0x55951c: tst             x16, HEAP, lsr #32
    //     0x559520: b.eq            #0x559528
    //     0x559524: bl              #0xd67e5c
    // 0x559528: ldur            x0, [fp, #-0x60]
    // 0x55952c: r17 = "\"\r\n\r\n"
    //     0x55952c: add             x17, PP, #0x14, lsl #12  ; [pp+0x14588] "\"\r\n\r\n"
    //     0x559530: ldr             x17, [x17, #0x588]
    // 0x559534: StoreField: r0->field_1b = r17
    //     0x559534: stur            w17, [x0, #0x1b]
    // 0x559538: SaveReg r0
    //     0x559538: str             x0, [SP, #-8]!
    // 0x55953c: r0 = _interpolate()
    //     0x55953c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x559540: add             SP, SP, #8
    // 0x559544: ldur            x16, [fp, #-0x18]
    // 0x559548: stp             x0, x16, [SP, #-0x10]!
    // 0x55954c: ldur            x0, [fp, #-0x18]
    // 0x559550: ClosureCall
    //     0x559550: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x559554: ldur            x2, [x0, #0x1f]
    //     0x559558: blr             x2
    // 0x55955c: add             SP, SP, #0x10
    // 0x559560: ldur            x0, [fp, #-0x48]
    // 0x559564: r1 = LoadClassIdInstr(r0)
    //     0x559564: ldur            x1, [x0, #-1]
    //     0x559568: ubfx            x1, x1, #0xc, #0x14
    // 0x55956c: SaveReg r0
    //     0x55956c: str             x0, [SP, #-8]!
    // 0x559570: mov             x0, x1
    // 0x559574: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x559574: sub             lr, x0, #0xfc4
    //     0x559578: ldr             lr, [x21, lr, lsl #3]
    //     0x55957c: blr             lr
    // 0x559580: add             SP, SP, #8
    // 0x559584: r16 = Instance_Utf8Codec
    //     0x559584: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0x559588: stp             x0, x16, [SP, #-0x10]!
    // 0x55958c: r0 = encode()
    //     0x55958c: bl              #0xbfcc28  ; [dart:convert] Codec::encode
    // 0x559590: add             SP, SP, #0x10
    // 0x559594: ldur            x16, [fp, #-0x10]
    // 0x559598: stp             x0, x16, [SP, #-0x10]!
    // 0x55959c: r0 = add()
    //     0x55959c: bl              #0xc23290  ; [dart:async] _StreamController::add
    // 0x5595a0: add             SP, SP, #0x10
    // 0x5595a4: ldur            x16, [fp, #-0x40]
    // 0x5595a8: SaveReg r16
    //     0x5595a8: str             x16, [SP, #-8]!
    // 0x5595ac: ldur            x0, [fp, #-0x40]
    // 0x5595b0: ClosureCall
    //     0x5595b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x5595b4: ldur            x2, [x0, #0x1f]
    //     0x5595b8: blr             x2
    // 0x5595bc: add             SP, SP, #8
    // 0x5595c0: ldur            x8, [fp, #-0x50]
    // 0x5595c4: ldr             x3, [fp, #0x10]
    // 0x5595c8: ldur            x2, [fp, #-8]
    // 0x5595cc: ldur            x1, [fp, #-0x40]
    // 0x5595d0: ldur            x4, [fp, #-0x38]
    // 0x5595d4: ldur            x5, [fp, #-0x30]
    // 0x5595d8: ldur            x6, [fp, #-0x28]
    // 0x5595dc: b               #0x559290
    // 0x5595e0: r0 = StateError()
    //     0x5595e0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x5595e4: mov             x1, x0
    // 0x5595e8: r0 = "The FormData has already been finalized. This typically means you are using the same FormData in repeated requests."
    //     0x5595e8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14608] "The FormData has already been finalized. This typically means you are using the same FormData in repeated requests."
    //     0x5595ec: ldr             x0, [x0, #0x608]
    // 0x5595f0: StoreField: r1->field_b = r0
    //     0x5595f0: stur            w0, [x1, #0xb]
    // 0x5595f4: mov             x0, x1
    // 0x5595f8: r0 = Throw()
    //     0x5595f8: bl              #0xd67e38  ; ThrowStub
    // 0x5595fc: brk             #0
    // 0x559600: ldur            x0, [fp, #-0x38]
    // 0x559604: r0 = ConcurrentModificationError()
    //     0x559604: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x559608: ldur            x3, [fp, #-0x38]
    // 0x55960c: StoreField: r0->field_b = r3
    //     0x55960c: stur            w3, [x0, #0xb]
    // 0x559610: r0 = Throw()
    //     0x559610: bl              #0xd67e38  ; ThrowStub
    // 0x559614: brk             #0
    // 0x559618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x559618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55961c: b               #0x559180
    // 0x559620: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x559620: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x559624: b               #0x5592a4
    // 0x559628: r9 = _boundary
    //     0x559628: add             x9, PP, #0x14, lsl #12  ; [pp+0x144c8] Field <FormData._boundary@357426596>: late (offset: 0x8)
    //     0x55962c: ldr             x9, [x9, #0x4c8]
    // 0x559630: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x559630: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x559d00, size: 0xe0
    // 0x559d00: EnterFrame
    //     0x559d00: stp             fp, lr, [SP, #-0x10]!
    //     0x559d04: mov             fp, SP
    // 0x559d08: AllocStack(0x10)
    //     0x559d08: sub             SP, SP, #0x10
    // 0x559d0c: SetupParameters()
    //     0x559d0c: ldr             x0, [fp, #0x18]
    //     0x559d10: ldur            w3, [x0, #0x17]
    //     0x559d14: add             x3, x3, HEAP, lsl #32
    //     0x559d18: stur            x3, [fp, #-0x10]
    // 0x559d1c: CheckStackOverflow
    //     0x559d1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x559d20: cmp             SP, x16
    //     0x559d24: b.ls            #0x559dcc
    // 0x559d28: LoadField: r0 = r3->field_17
    //     0x559d28: ldur            w0, [x3, #0x17]
    // 0x559d2c: DecompressPointer r0
    //     0x559d2c: add             x0, x0, HEAP, lsl #32
    // 0x559d30: stur            x0, [fp, #-8]
    // 0x559d34: r1 = Null
    //     0x559d34: mov             x1, NULL
    // 0x559d38: r2 = 6
    //     0x559d38: mov             x2, #6
    // 0x559d3c: r0 = AllocateArray()
    //     0x559d3c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x559d40: r17 = "--"
    //     0x559d40: add             x17, PP, #0x14, lsl #12  ; [pp+0x14600] "--"
    //     0x559d44: ldr             x17, [x17, #0x600]
    // 0x559d48: StoreField: r0->field_f = r17
    //     0x559d48: stur            w17, [x0, #0xf]
    // 0x559d4c: ldur            x1, [fp, #-0x10]
    // 0x559d50: LoadField: r2 = r1->field_f
    //     0x559d50: ldur            w2, [x1, #0xf]
    // 0x559d54: DecompressPointer r2
    //     0x559d54: add             x2, x2, HEAP, lsl #32
    // 0x559d58: LoadField: r3 = r2->field_7
    //     0x559d58: ldur            w3, [x2, #7]
    // 0x559d5c: DecompressPointer r3
    //     0x559d5c: add             x3, x3, HEAP, lsl #32
    // 0x559d60: r16 = Sentinel
    //     0x559d60: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x559d64: cmp             w3, w16
    // 0x559d68: b.eq            #0x559dd4
    // 0x559d6c: StoreField: r0->field_13 = r3
    //     0x559d6c: stur            w3, [x0, #0x13]
    // 0x559d70: r17 = "--\r\n"
    //     0x559d70: add             x17, PP, #0x14, lsl #12  ; [pp+0x14610] "--\r\n"
    //     0x559d74: ldr             x17, [x17, #0x610]
    // 0x559d78: StoreField: r0->field_17 = r17
    //     0x559d78: stur            w17, [x0, #0x17]
    // 0x559d7c: SaveReg r0
    //     0x559d7c: str             x0, [SP, #-8]!
    // 0x559d80: r0 = _interpolate()
    //     0x559d80: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x559d84: add             SP, SP, #8
    // 0x559d88: ldur            x16, [fp, #-8]
    // 0x559d8c: stp             x0, x16, [SP, #-0x10]!
    // 0x559d90: ldur            x0, [fp, #-8]
    // 0x559d94: ClosureCall
    //     0x559d94: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x559d98: ldur            x2, [x0, #0x1f]
    //     0x559d9c: blr             x2
    // 0x559da0: add             SP, SP, #0x10
    // 0x559da4: ldur            x0, [fp, #-0x10]
    // 0x559da8: LoadField: r1 = r0->field_13
    //     0x559da8: ldur            w1, [x0, #0x13]
    // 0x559dac: DecompressPointer r1
    //     0x559dac: add             x1, x1, HEAP, lsl #32
    // 0x559db0: SaveReg r1
    //     0x559db0: str             x1, [SP, #-8]!
    // 0x559db4: r0 = close()
    //     0x559db4: bl              #0xc069e8  ; [dart:async] _StreamController::close
    // 0x559db8: add             SP, SP, #8
    // 0x559dbc: r0 = Null
    //     0x559dbc: mov             x0, NULL
    // 0x559dc0: LeaveFrame
    //     0x559dc0: mov             SP, fp
    //     0x559dc4: ldp             fp, lr, [SP], #0x10
    // 0x559dc8: ret
    //     0x559dc8: ret             
    // 0x559dcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x559dcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x559dd0: b               #0x559d28
    // 0x559dd4: r9 = _boundary
    //     0x559dd4: add             x9, PP, #0x14, lsl #12  ; [pp+0x144c8] Field <FormData._boundary@357426596>: late (offset: 0x8)
    //     0x559dd8: ldr             x9, [x9, #0x4c8]
    // 0x559ddc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x559ddc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, MapEntry<String, MultipartFile>) {
    // ** addr: 0x559f84, size: 0x178
    // 0x559f84: EnterFrame
    //     0x559f84: stp             fp, lr, [SP, #-0x10]!
    //     0x559f88: mov             fp, SP
    // 0x559f8c: AllocStack(0x10)
    //     0x559f8c: sub             SP, SP, #0x10
    // 0x559f90: SetupParameters()
    //     0x559f90: ldr             x0, [fp, #0x18]
    //     0x559f94: ldur            w3, [x0, #0x17]
    //     0x559f98: add             x3, x3, HEAP, lsl #32
    //     0x559f9c: stur            x3, [fp, #-0x10]
    // 0x559fa0: CheckStackOverflow
    //     0x559fa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x559fa4: cmp             SP, x16
    //     0x559fa8: b.ls            #0x55a0e4
    // 0x559fac: LoadField: r0 = r3->field_17
    //     0x559fac: ldur            w0, [x3, #0x17]
    // 0x559fb0: DecompressPointer r0
    //     0x559fb0: add             x0, x0, HEAP, lsl #32
    // 0x559fb4: stur            x0, [fp, #-8]
    // 0x559fb8: r1 = Null
    //     0x559fb8: mov             x1, NULL
    // 0x559fbc: r2 = 6
    //     0x559fbc: mov             x2, #6
    // 0x559fc0: r0 = AllocateArray()
    //     0x559fc0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x559fc4: r17 = "--"
    //     0x559fc4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14600] "--"
    //     0x559fc8: ldr             x17, [x17, #0x600]
    // 0x559fcc: StoreField: r0->field_f = r17
    //     0x559fcc: stur            w17, [x0, #0xf]
    // 0x559fd0: ldur            x2, [fp, #-0x10]
    // 0x559fd4: LoadField: r1 = r2->field_f
    //     0x559fd4: ldur            w1, [x2, #0xf]
    // 0x559fd8: DecompressPointer r1
    //     0x559fd8: add             x1, x1, HEAP, lsl #32
    // 0x559fdc: LoadField: r3 = r1->field_7
    //     0x559fdc: ldur            w3, [x1, #7]
    // 0x559fe0: DecompressPointer r3
    //     0x559fe0: add             x3, x3, HEAP, lsl #32
    // 0x559fe4: r16 = Sentinel
    //     0x559fe4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x559fe8: cmp             w3, w16
    // 0x559fec: b.eq            #0x55a0ec
    // 0x559ff0: StoreField: r0->field_13 = r3
    //     0x559ff0: stur            w3, [x0, #0x13]
    // 0x559ff4: r17 = "\r\n"
    //     0x559ff4: ldr             x17, [PP, #0x7960]  ; [pp+0x7960] "\r\n"
    // 0x559ff8: StoreField: r0->field_17 = r17
    //     0x559ff8: stur            w17, [x0, #0x17]
    // 0x559ffc: SaveReg r0
    //     0x559ffc: str             x0, [SP, #-8]!
    // 0x55a000: r0 = _interpolate()
    //     0x55a000: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x55a004: add             SP, SP, #8
    // 0x55a008: ldur            x16, [fp, #-8]
    // 0x55a00c: stp             x0, x16, [SP, #-0x10]!
    // 0x55a010: ldur            x0, [fp, #-8]
    // 0x55a014: ClosureCall
    //     0x55a014: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x55a018: ldur            x2, [x0, #0x1f]
    //     0x55a01c: blr             x2
    // 0x55a020: add             SP, SP, #0x10
    // 0x55a024: ldur            x2, [fp, #-0x10]
    // 0x55a028: LoadField: r0 = r2->field_f
    //     0x55a028: ldur            w0, [x2, #0xf]
    // 0x55a02c: DecompressPointer r0
    //     0x55a02c: add             x0, x0, HEAP, lsl #32
    // 0x55a030: ldr             x16, [fp, #0x10]
    // 0x55a034: stp             x16, x0, [SP, #-0x10]!
    // 0x55a038: r0 = _headerForFile()
    //     0x55a038: bl              #0x558d5c  ; [package:dio/src/form_data.dart] FormData::_headerForFile
    // 0x55a03c: add             SP, SP, #0x10
    // 0x55a040: ldur            x16, [fp, #-8]
    // 0x55a044: stp             x0, x16, [SP, #-0x10]!
    // 0x55a048: ldur            x0, [fp, #-8]
    // 0x55a04c: ClosureCall
    //     0x55a04c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x55a050: ldur            x2, [x0, #0x1f]
    //     0x55a054: blr             x2
    // 0x55a058: add             SP, SP, #0x10
    // 0x55a05c: ldr             x0, [fp, #0x10]
    // 0x55a060: r1 = LoadClassIdInstr(r0)
    //     0x55a060: ldur            x1, [x0, #-1]
    //     0x55a064: ubfx            x1, x1, #0xc, #0x14
    // 0x55a068: SaveReg r0
    //     0x55a068: str             x0, [SP, #-8]!
    // 0x55a06c: mov             x0, x1
    // 0x55a070: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x55a070: sub             lr, x0, #0xfc4
    //     0x55a074: ldr             lr, [x21, lr, lsl #3]
    //     0x55a078: blr             lr
    // 0x55a07c: add             SP, SP, #8
    // 0x55a080: cmp             w0, NULL
    // 0x55a084: b.eq            #0x55a0f8
    // 0x55a088: SaveReg r0
    //     0x55a088: str             x0, [SP, #-8]!
    // 0x55a08c: r0 = finalize()
    //     0x55a08c: bl              #0x55a284  ; [package:dio/src/multipart_file.dart] MultipartFile::finalize
    // 0x55a090: add             SP, SP, #8
    // 0x55a094: ldur            x2, [fp, #-0x10]
    // 0x55a098: LoadField: r1 = r2->field_13
    //     0x55a098: ldur            w1, [x2, #0x13]
    // 0x55a09c: DecompressPointer r1
    //     0x55a09c: add             x1, x1, HEAP, lsl #32
    // 0x55a0a0: stp             x1, x0, [SP, #-0x10]!
    // 0x55a0a4: r0 = writeStreamToSink()
    //     0x55a0a4: bl              #0x55a0fc  ; [package:dio/src/utils.dart] ::writeStreamToSink
    // 0x55a0a8: add             SP, SP, #0x10
    // 0x55a0ac: ldur            x2, [fp, #-0x10]
    // 0x55a0b0: r1 = Function '<anonymous closure>':.
    //     0x55a0b0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14618] AnonymousClosure: (0x55a2dc), in [package:dio/src/form_data.dart] FormData::finalize (0x559168)
    //     0x55a0b4: ldr             x1, [x1, #0x618]
    // 0x55a0b8: stur            x0, [fp, #-8]
    // 0x55a0bc: r0 = AllocateClosure()
    //     0x55a0bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x55a0c0: ldur            x16, [fp, #-8]
    // 0x55a0c4: stp             x16, NULL, [SP, #-0x10]!
    // 0x55a0c8: SaveReg r0
    //     0x55a0c8: str             x0, [SP, #-8]!
    // 0x55a0cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x55a0cc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x55a0d0: r0 = then()
    //     0x55a0d0: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x55a0d4: add             SP, SP, #0x18
    // 0x55a0d8: LeaveFrame
    //     0x55a0d8: mov             SP, fp
    //     0x55a0dc: ldp             fp, lr, [SP], #0x10
    // 0x55a0e0: ret
    //     0x55a0e0: ret             
    // 0x55a0e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a0e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a0e8: b               #0x559fac
    // 0x55a0ec: r9 = _boundary
    //     0x55a0ec: add             x9, PP, #0x14, lsl #12  ; [pp+0x144c8] Field <FormData._boundary@357426596>: late (offset: 0x8)
    //     0x55a0f0: ldr             x9, [x9, #0x4c8]
    // 0x55a0f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55a0f4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55a0f8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x55a0f8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x55a2dc, size: 0x50
    // 0x55a2dc: EnterFrame
    //     0x55a2dc: stp             fp, lr, [SP, #-0x10]!
    //     0x55a2e0: mov             fp, SP
    // 0x55a2e4: ldr             x0, [fp, #0x18]
    // 0x55a2e8: LoadField: r1 = r0->field_17
    //     0x55a2e8: ldur            w1, [x0, #0x17]
    // 0x55a2ec: DecompressPointer r1
    //     0x55a2ec: add             x1, x1, HEAP, lsl #32
    // 0x55a2f0: CheckStackOverflow
    //     0x55a2f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a2f4: cmp             SP, x16
    //     0x55a2f8: b.ls            #0x55a324
    // 0x55a2fc: LoadField: r0 = r1->field_1b
    //     0x55a2fc: ldur            w0, [x1, #0x1b]
    // 0x55a300: DecompressPointer r0
    //     0x55a300: add             x0, x0, HEAP, lsl #32
    // 0x55a304: SaveReg r0
    //     0x55a304: str             x0, [SP, #-8]!
    // 0x55a308: ClosureCall
    //     0x55a308: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x55a30c: ldur            x2, [x0, #0x1f]
    //     0x55a310: blr             x2
    // 0x55a314: add             SP, SP, #8
    // 0x55a318: LeaveFrame
    //     0x55a318: mov             SP, fp
    //     0x55a31c: ldp             fp, lr, [SP], #0x10
    // 0x55a320: ret
    //     0x55a320: ret             
    // 0x55a324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a324: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a328: b               #0x55a2fc
  }
  [closure] void writeLine(dynamic) {
    // ** addr: 0x55a32c, size: 0x94
    // 0x55a32c: EnterFrame
    //     0x55a32c: stp             fp, lr, [SP, #-0x10]!
    //     0x55a330: mov             fp, SP
    // 0x55a334: AllocStack(0x10)
    //     0x55a334: sub             SP, SP, #0x10
    // 0x55a338: SetupParameters()
    //     0x55a338: mov             x0, #4
    //     0x55a33c: ldr             x1, [fp, #0x10]
    //     0x55a340: ldur            w2, [x1, #0x17]
    //     0x55a344: add             x2, x2, HEAP, lsl #32
    // 0x55a338: r0 = 4
    // 0x55a348: CheckStackOverflow
    //     0x55a348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a34c: cmp             SP, x16
    //     0x55a350: b.ls            #0x55a3b8
    // 0x55a354: LoadField: r3 = r2->field_13
    //     0x55a354: ldur            w3, [x2, #0x13]
    // 0x55a358: DecompressPointer r3
    //     0x55a358: add             x3, x3, HEAP, lsl #32
    // 0x55a35c: mov             x2, x0
    // 0x55a360: stur            x3, [fp, #-8]
    // 0x55a364: r1 = Null
    //     0x55a364: mov             x1, NULL
    // 0x55a368: r0 = AllocateArray()
    //     0x55a368: bl              #0xd6987c  ; AllocateArrayStub
    // 0x55a36c: stur            x0, [fp, #-0x10]
    // 0x55a370: r17 = 26
    //     0x55a370: mov             x17, #0x1a
    // 0x55a374: StoreField: r0->field_f = r17
    //     0x55a374: stur            w17, [x0, #0xf]
    // 0x55a378: r17 = 20
    //     0x55a378: mov             x17, #0x14
    // 0x55a37c: StoreField: r0->field_13 = r17
    //     0x55a37c: stur            w17, [x0, #0x13]
    // 0x55a380: r1 = <int>
    //     0x55a380: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x55a384: r0 = AllocateGrowableArray()
    //     0x55a384: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x55a388: mov             x1, x0
    // 0x55a38c: ldur            x0, [fp, #-0x10]
    // 0x55a390: StoreField: r1->field_f = r0
    //     0x55a390: stur            w0, [x1, #0xf]
    // 0x55a394: r0 = 4
    //     0x55a394: mov             x0, #4
    // 0x55a398: StoreField: r1->field_b = r0
    //     0x55a398: stur            w0, [x1, #0xb]
    // 0x55a39c: ldur            x16, [fp, #-8]
    // 0x55a3a0: stp             x1, x16, [SP, #-0x10]!
    // 0x55a3a4: r0 = add()
    //     0x55a3a4: bl              #0xc23290  ; [dart:async] _StreamController::add
    // 0x55a3a8: add             SP, SP, #0x10
    // 0x55a3ac: LeaveFrame
    //     0x55a3ac: mov             SP, fp
    //     0x55a3b0: ldp             fp, lr, [SP], #0x10
    // 0x55a3b4: ret
    //     0x55a3b4: ret             
    // 0x55a3b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a3b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a3bc: b               #0x55a354
  }
  [closure] void writeAscii(dynamic, String) {
    // ** addr: 0x55a3c0, size: 0x6c
    // 0x55a3c0: EnterFrame
    //     0x55a3c0: stp             fp, lr, [SP, #-0x10]!
    //     0x55a3c4: mov             fp, SP
    // 0x55a3c8: AllocStack(0x8)
    //     0x55a3c8: sub             SP, SP, #8
    // 0x55a3cc: SetupParameters()
    //     0x55a3cc: ldr             x0, [fp, #0x18]
    //     0x55a3d0: ldur            w1, [x0, #0x17]
    //     0x55a3d4: add             x1, x1, HEAP, lsl #32
    // 0x55a3d8: CheckStackOverflow
    //     0x55a3d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a3dc: cmp             SP, x16
    //     0x55a3e0: b.ls            #0x55a424
    // 0x55a3e4: LoadField: r0 = r1->field_13
    //     0x55a3e4: ldur            w0, [x1, #0x13]
    // 0x55a3e8: DecompressPointer r0
    //     0x55a3e8: add             x0, x0, HEAP, lsl #32
    // 0x55a3ec: stur            x0, [fp, #-8]
    // 0x55a3f0: r16 = Instance_Utf8Codec
    //     0x55a3f0: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0x55a3f4: ldr             lr, [fp, #0x10]
    // 0x55a3f8: stp             lr, x16, [SP, #-0x10]!
    // 0x55a3fc: r0 = encode()
    //     0x55a3fc: bl              #0xbfcc28  ; [dart:convert] Codec::encode
    // 0x55a400: add             SP, SP, #0x10
    // 0x55a404: ldur            x16, [fp, #-8]
    // 0x55a408: stp             x0, x16, [SP, #-0x10]!
    // 0x55a40c: r0 = add()
    //     0x55a40c: bl              #0xc23290  ; [dart:async] _StreamController::add
    // 0x55a410: add             SP, SP, #0x10
    // 0x55a414: r0 = Null
    //     0x55a414: mov             x0, NULL
    // 0x55a418: LeaveFrame
    //     0x55a418: mov             SP, fp
    //     0x55a41c: ldp             fp, lr, [SP], #0x10
    // 0x55a420: ret
    //     0x55a420: ret             
    // 0x55a424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a424: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a428: b               #0x55a3e4
  }
  _ FormData.fromMap(/* No info */) {
    // ** addr: 0x8c6000, size: 0x13c
    // 0x8c6000: EnterFrame
    //     0x8c6000: stp             fp, lr, [SP, #-0x10]!
    //     0x8c6004: mov             fp, SP
    // 0x8c6008: AllocStack(0x8)
    //     0x8c6008: sub             SP, SP, #8
    // 0x8c600c: CheckStackOverflow
    //     0x8c600c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8c6010: cmp             SP, x16
    //     0x8c6014: b.ls            #0x8c6134
    // 0x8c6018: r1 = 1
    //     0x8c6018: mov             x1, #1
    // 0x8c601c: r0 = AllocateContext()
    //     0x8c601c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8c6020: mov             x1, x0
    // 0x8c6024: ldr             x0, [fp, #0x18]
    // 0x8c6028: stur            x1, [fp, #-8]
    // 0x8c602c: StoreField: r1->field_f = r0
    //     0x8c602c: stur            w0, [x1, #0xf]
    // 0x8c6030: r2 = Sentinel
    //     0x8c6030: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8c6034: StoreField: r0->field_7 = r2
    //     0x8c6034: stur            w2, [x0, #7]
    // 0x8c6038: r2 = false
    //     0x8c6038: add             x2, NULL, #0x30  ; false
    // 0x8c603c: StoreField: r0->field_17 = r2
    //     0x8c603c: stur            w2, [x0, #0x17]
    // 0x8c6040: r16 = "\\r\\n|\\r|\\n"
    //     0x8c6040: add             x16, PP, #0x34, lsl #12  ; [pp+0x348b8] "\\r\\n|\\r|\\n"
    //     0x8c6044: ldr             x16, [x16, #0x8b8]
    // 0x8c6048: stp             x16, NULL, [SP, #-0x10]!
    // 0x8c604c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c604c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c6050: r0 = RegExp()
    //     0x8c6050: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0x8c6054: add             SP, SP, #0x10
    // 0x8c6058: ldr             x1, [fp, #0x18]
    // 0x8c605c: StoreField: r1->field_b = r0
    //     0x8c605c: stur            w0, [x1, #0xb]
    //     0x8c6060: ldurb           w16, [x1, #-1]
    //     0x8c6064: ldurb           w17, [x0, #-1]
    //     0x8c6068: and             x16, x17, x16, lsr #2
    //     0x8c606c: tst             x16, HEAP, lsr #32
    //     0x8c6070: b.eq            #0x8c6078
    //     0x8c6074: bl              #0xd6826c
    // 0x8c6078: r16 = <MapEntry<String, String>>
    //     0x8c6078: add             x16, PP, #0x34, lsl #12  ; [pp+0x348c0] TypeArguments: <MapEntry<String, String>>
    //     0x8c607c: ldr             x16, [x16, #0x8c0]
    // 0x8c6080: stp             xzr, x16, [SP, #-0x10]!
    // 0x8c6084: r0 = _GrowableList()
    //     0x8c6084: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c6088: add             SP, SP, #0x10
    // 0x8c608c: ldr             x1, [fp, #0x18]
    // 0x8c6090: StoreField: r1->field_f = r0
    //     0x8c6090: stur            w0, [x1, #0xf]
    //     0x8c6094: ldurb           w16, [x1, #-1]
    //     0x8c6098: ldurb           w17, [x0, #-1]
    //     0x8c609c: and             x16, x17, x16, lsr #2
    //     0x8c60a0: tst             x16, HEAP, lsr #32
    //     0x8c60a4: b.eq            #0x8c60ac
    //     0x8c60a8: bl              #0xd6826c
    // 0x8c60ac: r16 = <MapEntry<String, MultipartFile>>
    //     0x8c60ac: add             x16, PP, #0x14, lsl #12  ; [pp+0x145e0] TypeArguments: <MapEntry<String, MultipartFile>>
    //     0x8c60b0: ldr             x16, [x16, #0x5e0]
    // 0x8c60b4: stp             xzr, x16, [SP, #-0x10]!
    // 0x8c60b8: r0 = _GrowableList()
    //     0x8c60b8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c60bc: add             SP, SP, #0x10
    // 0x8c60c0: ldr             x1, [fp, #0x18]
    // 0x8c60c4: StoreField: r1->field_13 = r0
    //     0x8c60c4: stur            w0, [x1, #0x13]
    //     0x8c60c8: ldurb           w16, [x1, #-1]
    //     0x8c60cc: ldurb           w17, [x0, #-1]
    //     0x8c60d0: and             x16, x17, x16, lsr #2
    //     0x8c60d4: tst             x16, HEAP, lsr #32
    //     0x8c60d8: b.eq            #0x8c60e0
    //     0x8c60dc: bl              #0xd6826c
    // 0x8c60e0: r0 = false
    //     0x8c60e0: add             x0, NULL, #0x30  ; false
    // 0x8c60e4: StoreField: r1->field_1b = r0
    //     0x8c60e4: stur            w0, [x1, #0x1b]
    // 0x8c60e8: SaveReg r1
    //     0x8c60e8: str             x1, [SP, #-8]!
    // 0x8c60ec: r0 = _init()
    //     0x8c60ec: bl              #0x8c613c  ; [package:dio/src/form_data.dart] FormData::_init
    // 0x8c60f0: add             SP, SP, #8
    // 0x8c60f4: ldur            x2, [fp, #-8]
    // 0x8c60f8: r1 = Function '<anonymous closure>':.
    //     0x8c60f8: add             x1, PP, #0x34, lsl #12  ; [pp+0x348c8] AnonymousClosure: (0x8c6234), in [package:dio/src/form_data.dart] FormData::FormData.fromMap (0x8c6000)
    //     0x8c60fc: ldr             x1, [x1, #0x8c8]
    // 0x8c6100: r0 = AllocateClosure()
    //     0x8c6100: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8c6104: ldr             x16, [fp, #0x10]
    // 0x8c6108: stp             x0, x16, [SP, #-0x10]!
    // 0x8c610c: r16 = false
    //     0x8c610c: add             x16, NULL, #0x30  ; false
    // 0x8c6110: SaveReg r16
    //     0x8c6110: str             x16, [SP, #-8]!
    // 0x8c6114: r4 = const [0, 0x3, 0x3, 0x2, encode, 0x2, null]
    //     0x8c6114: add             x4, PP, #0x34, lsl #12  ; [pp+0x348d0] List(7) [0, 0x3, 0x3, 0x2, "encode", 0x2, Null]
    //     0x8c6118: ldr             x4, [x4, #0x8d0]
    // 0x8c611c: r0 = encodeMap()
    //     0x8c611c: bl              #0x553b44  ; [package:dio/src/utils.dart] ::encodeMap
    // 0x8c6120: add             SP, SP, #0x18
    // 0x8c6124: r0 = Null
    //     0x8c6124: mov             x0, NULL
    // 0x8c6128: LeaveFrame
    //     0x8c6128: mov             SP, fp
    //     0x8c612c: ldp             fp, lr, [SP], #0x10
    // 0x8c6130: ret
    //     0x8c6130: ret             
    // 0x8c6134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c6134: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c6138: b               #0x8c6018
  }
  _ _init(/* No info */) {
    // ** addr: 0x8c613c, size: 0xf8
    // 0x8c613c: EnterFrame
    //     0x8c613c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c6140: mov             fp, SP
    // 0x8c6144: CheckStackOverflow
    //     0x8c6144: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8c6148: cmp             SP, x16
    //     0x8c614c: b.ls            #0x8c622c
    // 0x8c6150: SaveReg rNULL
    //     0x8c6150: str             NULL, [SP, #-8]!
    // 0x8c6154: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c6154: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c6158: r0 = Random()
    //     0x8c6158: bl              #0x58977c  ; [dart:math] Random::Random
    // 0x8c615c: add             SP, SP, #8
    // 0x8c6160: SaveReg r0
    //     0x8c6160: str             x0, [SP, #-8]!
    // 0x8c6164: r0 = 4294967296
    //     0x8c6164: mov             x0, #0x100000000
    // 0x8c6168: SaveReg r0
    //     0x8c6168: str             x0, [SP, #-8]!
    // 0x8c616c: r0 = nextInt()
    //     0x8c616c: bl              #0x58957c  ; [dart:math] _Random::nextInt
    // 0x8c6170: add             SP, SP, #0x10
    // 0x8c6174: mov             x2, x0
    // 0x8c6178: r0 = BoxInt64Instr(r2)
    //     0x8c6178: sbfiz           x0, x2, #1, #0x1f
    //     0x8c617c: cmp             x2, x0, asr #1
    //     0x8c6180: b.eq            #0x8c618c
    //     0x8c6184: bl              #0xd69bb8
    //     0x8c6188: stur            x2, [x0, #7]
    // 0x8c618c: r1 = 59
    //     0x8c618c: mov             x1, #0x3b
    // 0x8c6190: branchIfSmi(r0, 0x8c619c)
    //     0x8c6190: tbz             w0, #0, #0x8c619c
    // 0x8c6194: r1 = LoadClassIdInstr(r0)
    //     0x8c6194: ldur            x1, [x0, #-1]
    //     0x8c6198: ubfx            x1, x1, #0xc, #0x14
    // 0x8c619c: SaveReg r0
    //     0x8c619c: str             x0, [SP, #-8]!
    // 0x8c61a0: mov             x0, x1
    // 0x8c61a4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c61a4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c61a8: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x8c61a8: mov             x17, #0x3f73
    //     0x8c61ac: add             lr, x0, x17
    //     0x8c61b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8c61b4: blr             lr
    // 0x8c61b8: add             SP, SP, #8
    // 0x8c61bc: r1 = LoadClassIdInstr(r0)
    //     0x8c61bc: ldur            x1, [x0, #-1]
    //     0x8c61c0: ubfx            x1, x1, #0xc, #0x14
    // 0x8c61c4: SaveReg r0
    //     0x8c61c4: str             x0, [SP, #-8]!
    // 0x8c61c8: r0 = 10
    //     0x8c61c8: mov             x0, #0xa
    // 0x8c61cc: r16 = "0"
    //     0x8c61cc: ldr             x16, [PP, #0x3af8]  ; [pp+0x3af8] "0"
    // 0x8c61d0: stp             x16, x0, [SP, #-0x10]!
    // 0x8c61d4: mov             x0, x1
    // 0x8c61d8: r0 = GDT[cid_x0 + -0xfec]()
    //     0x8c61d8: sub             lr, x0, #0xfec
    //     0x8c61dc: ldr             lr, [x21, lr, lsl #3]
    //     0x8c61e0: blr             lr
    // 0x8c61e4: add             SP, SP, #0x18
    // 0x8c61e8: r16 = "--dio-boundary-"
    //     0x8c61e8: add             x16, PP, #0x34, lsl #12  ; [pp+0x348e0] "--dio-boundary-"
    //     0x8c61ec: ldr             x16, [x16, #0x8e0]
    // 0x8c61f0: stp             x0, x16, [SP, #-0x10]!
    // 0x8c61f4: r0 = +()
    //     0x8c61f4: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x8c61f8: add             SP, SP, #0x10
    // 0x8c61fc: ldr             x1, [fp, #0x10]
    // 0x8c6200: StoreField: r1->field_7 = r0
    //     0x8c6200: stur            w0, [x1, #7]
    //     0x8c6204: ldurb           w16, [x1, #-1]
    //     0x8c6208: ldurb           w17, [x0, #-1]
    //     0x8c620c: and             x16, x17, x16, lsr #2
    //     0x8c6210: tst             x16, HEAP, lsr #32
    //     0x8c6214: b.eq            #0x8c621c
    //     0x8c6218: bl              #0xd6826c
    // 0x8c621c: r0 = Null
    //     0x8c621c: mov             x0, NULL
    // 0x8c6220: LeaveFrame
    //     0x8c6220: mov             SP, fp
    //     0x8c6224: ldp             fp, lr, [SP], #0x10
    // 0x8c6228: ret
    //     0x8c6228: ret             
    // 0x8c622c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c622c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c6230: b               #0x8c6150
  }
  [closure] Null <anonymous closure>(dynamic, String, Object?) {
    // ** addr: 0x8c6234, size: 0x254
    // 0x8c6234: EnterFrame
    //     0x8c6234: stp             fp, lr, [SP, #-0x10]!
    //     0x8c6238: mov             fp, SP
    // 0x8c623c: AllocStack(0x18)
    //     0x8c623c: sub             SP, SP, #0x18
    // 0x8c6240: SetupParameters()
    //     0x8c6240: ldr             x0, [fp, #0x20]
    //     0x8c6244: ldur            w1, [x0, #0x17]
    //     0x8c6248: add             x1, x1, HEAP, lsl #32
    // 0x8c624c: CheckStackOverflow
    //     0x8c624c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8c6250: cmp             SP, x16
    //     0x8c6254: b.ls            #0x8c6478
    // 0x8c6258: ldr             x0, [fp, #0x10]
    // 0x8c625c: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x8c625c: mov             x2, #0x76
    //     0x8c6260: tbz             w0, #0, #0x8c6270
    //     0x8c6264: ldur            x2, [x0, #-1]
    //     0x8c6268: ubfx            x2, x2, #0xc, #0x14
    //     0x8c626c: lsl             x2, x2, #1
    // 0x8c6270: r17 = 9068
    //     0x8c6270: mov             x17, #0x236c
    // 0x8c6274: cmp             w2, w17
    // 0x8c6278: b.ne            #0x8c6344
    // 0x8c627c: ldr             x2, [fp, #0x18]
    // 0x8c6280: LoadField: r3 = r1->field_f
    //     0x8c6280: ldur            w3, [x1, #0xf]
    // 0x8c6284: DecompressPointer r3
    //     0x8c6284: add             x3, x3, HEAP, lsl #32
    // 0x8c6288: LoadField: r4 = r3->field_13
    //     0x8c6288: ldur            w4, [x3, #0x13]
    // 0x8c628c: DecompressPointer r4
    //     0x8c628c: add             x4, x4, HEAP, lsl #32
    // 0x8c6290: stur            x4, [fp, #-8]
    // 0x8c6294: r1 = <String, MultipartFile>
    //     0x8c6294: add             x1, PP, #0x34, lsl #12  ; [pp+0x348d8] TypeArguments: <String, MultipartFile>
    //     0x8c6298: ldr             x1, [x1, #0x8d8]
    // 0x8c629c: r0 = MapEntry()
    //     0x8c629c: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x8c62a0: ldr             x2, [fp, #0x18]
    // 0x8c62a4: stur            x0, [fp, #-0x18]
    // 0x8c62a8: StoreField: r0->field_b = r2
    //     0x8c62a8: stur            w2, [x0, #0xb]
    // 0x8c62ac: ldr             x3, [fp, #0x10]
    // 0x8c62b0: StoreField: r0->field_f = r3
    //     0x8c62b0: stur            w3, [x0, #0xf]
    // 0x8c62b4: ldur            x1, [fp, #-8]
    // 0x8c62b8: LoadField: r2 = r1->field_b
    //     0x8c62b8: ldur            w2, [x1, #0xb]
    // 0x8c62bc: DecompressPointer r2
    //     0x8c62bc: add             x2, x2, HEAP, lsl #32
    // 0x8c62c0: stur            x2, [fp, #-0x10]
    // 0x8c62c4: LoadField: r3 = r1->field_f
    //     0x8c62c4: ldur            w3, [x1, #0xf]
    // 0x8c62c8: DecompressPointer r3
    //     0x8c62c8: add             x3, x3, HEAP, lsl #32
    // 0x8c62cc: LoadField: r4 = r3->field_b
    //     0x8c62cc: ldur            w4, [x3, #0xb]
    // 0x8c62d0: DecompressPointer r4
    //     0x8c62d0: add             x4, x4, HEAP, lsl #32
    // 0x8c62d4: cmp             w2, w4
    // 0x8c62d8: b.ne            #0x8c62e8
    // 0x8c62dc: SaveReg r1
    //     0x8c62dc: str             x1, [SP, #-8]!
    // 0x8c62e0: r0 = _growToNextCapacity()
    //     0x8c62e0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c62e4: add             SP, SP, #8
    // 0x8c62e8: ldur            x2, [fp, #-8]
    // 0x8c62ec: ldur            x0, [fp, #-0x10]
    // 0x8c62f0: r3 = LoadInt32Instr(r0)
    //     0x8c62f0: sbfx            x3, x0, #1, #0x1f
    // 0x8c62f4: add             x0, x3, #1
    // 0x8c62f8: lsl             x1, x0, #1
    // 0x8c62fc: StoreField: r2->field_b = r1
    //     0x8c62fc: stur            w1, [x2, #0xb]
    // 0x8c6300: mov             x1, x3
    // 0x8c6304: cmp             x1, x0
    // 0x8c6308: b.hs            #0x8c6480
    // 0x8c630c: LoadField: r1 = r2->field_f
    //     0x8c630c: ldur            w1, [x2, #0xf]
    // 0x8c6310: DecompressPointer r1
    //     0x8c6310: add             x1, x1, HEAP, lsl #32
    // 0x8c6314: ldur            x0, [fp, #-0x18]
    // 0x8c6318: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c6318: add             x25, x1, x3, lsl #2
    //     0x8c631c: add             x25, x25, #0xf
    //     0x8c6320: str             w0, [x25]
    //     0x8c6324: tbz             w0, #0, #0x8c6340
    //     0x8c6328: ldurb           w16, [x1, #-1]
    //     0x8c632c: ldurb           w17, [x0, #-1]
    //     0x8c6330: and             x16, x17, x16, lsr #2
    //     0x8c6334: tst             x16, HEAP, lsr #32
    //     0x8c6338: b.eq            #0x8c6340
    //     0x8c633c: bl              #0xd67e5c
    // 0x8c6340: b               #0x8c6468
    // 0x8c6344: ldr             x2, [fp, #0x18]
    // 0x8c6348: mov             x3, x0
    // 0x8c634c: LoadField: r0 = r1->field_f
    //     0x8c634c: ldur            w0, [x1, #0xf]
    // 0x8c6350: DecompressPointer r0
    //     0x8c6350: add             x0, x0, HEAP, lsl #32
    // 0x8c6354: LoadField: r1 = r0->field_f
    //     0x8c6354: ldur            w1, [x0, #0xf]
    // 0x8c6358: DecompressPointer r1
    //     0x8c6358: add             x1, x1, HEAP, lsl #32
    // 0x8c635c: stur            x1, [fp, #-8]
    // 0x8c6360: cmp             w3, NULL
    // 0x8c6364: b.ne            #0x8c6370
    // 0x8c6368: r0 = Null
    //     0x8c6368: mov             x0, NULL
    // 0x8c636c: b               #0x8c639c
    // 0x8c6370: r0 = 59
    //     0x8c6370: mov             x0, #0x3b
    // 0x8c6374: branchIfSmi(r3, 0x8c6380)
    //     0x8c6374: tbz             w3, #0, #0x8c6380
    // 0x8c6378: r0 = LoadClassIdInstr(r3)
    //     0x8c6378: ldur            x0, [x3, #-1]
    //     0x8c637c: ubfx            x0, x0, #0xc, #0x14
    // 0x8c6380: SaveReg r3
    //     0x8c6380: str             x3, [SP, #-8]!
    // 0x8c6384: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c6384: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c6388: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x8c6388: mov             x17, #0x3f73
    //     0x8c638c: add             lr, x0, x17
    //     0x8c6390: ldr             lr, [x21, lr, lsl #3]
    //     0x8c6394: blr             lr
    // 0x8c6398: add             SP, SP, #8
    // 0x8c639c: cmp             w0, NULL
    // 0x8c63a0: b.ne            #0x8c63ac
    // 0x8c63a4: r3 = ""
    //     0x8c63a4: ldr             x3, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x8c63a8: b               #0x8c63b0
    // 0x8c63ac: mov             x3, x0
    // 0x8c63b0: ldr             x0, [fp, #0x18]
    // 0x8c63b4: ldur            x2, [fp, #-8]
    // 0x8c63b8: stur            x3, [fp, #-0x10]
    // 0x8c63bc: r1 = <String, String>
    //     0x8c63bc: ldr             x1, [PP, #0x278]  ; [pp+0x278] TypeArguments: <String, String>
    // 0x8c63c0: r0 = MapEntry()
    //     0x8c63c0: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x8c63c4: mov             x1, x0
    // 0x8c63c8: ldr             x0, [fp, #0x18]
    // 0x8c63cc: stur            x1, [fp, #-0x18]
    // 0x8c63d0: StoreField: r1->field_b = r0
    //     0x8c63d0: stur            w0, [x1, #0xb]
    // 0x8c63d4: ldur            x0, [fp, #-0x10]
    // 0x8c63d8: StoreField: r1->field_f = r0
    //     0x8c63d8: stur            w0, [x1, #0xf]
    // 0x8c63dc: ldur            x0, [fp, #-8]
    // 0x8c63e0: LoadField: r2 = r0->field_b
    //     0x8c63e0: ldur            w2, [x0, #0xb]
    // 0x8c63e4: DecompressPointer r2
    //     0x8c63e4: add             x2, x2, HEAP, lsl #32
    // 0x8c63e8: stur            x2, [fp, #-0x10]
    // 0x8c63ec: LoadField: r3 = r0->field_f
    //     0x8c63ec: ldur            w3, [x0, #0xf]
    // 0x8c63f0: DecompressPointer r3
    //     0x8c63f0: add             x3, x3, HEAP, lsl #32
    // 0x8c63f4: LoadField: r4 = r3->field_b
    //     0x8c63f4: ldur            w4, [x3, #0xb]
    // 0x8c63f8: DecompressPointer r4
    //     0x8c63f8: add             x4, x4, HEAP, lsl #32
    // 0x8c63fc: cmp             w2, w4
    // 0x8c6400: b.ne            #0x8c6410
    // 0x8c6404: SaveReg r0
    //     0x8c6404: str             x0, [SP, #-8]!
    // 0x8c6408: r0 = _growToNextCapacity()
    //     0x8c6408: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c640c: add             SP, SP, #8
    // 0x8c6410: ldur            x2, [fp, #-8]
    // 0x8c6414: ldur            x3, [fp, #-0x10]
    // 0x8c6418: r4 = LoadInt32Instr(r3)
    //     0x8c6418: sbfx            x4, x3, #1, #0x1f
    // 0x8c641c: add             x0, x4, #1
    // 0x8c6420: lsl             x3, x0, #1
    // 0x8c6424: StoreField: r2->field_b = r3
    //     0x8c6424: stur            w3, [x2, #0xb]
    // 0x8c6428: mov             x1, x4
    // 0x8c642c: cmp             x1, x0
    // 0x8c6430: b.hs            #0x8c6484
    // 0x8c6434: LoadField: r1 = r2->field_f
    //     0x8c6434: ldur            w1, [x2, #0xf]
    // 0x8c6438: DecompressPointer r1
    //     0x8c6438: add             x1, x1, HEAP, lsl #32
    // 0x8c643c: ldur            x0, [fp, #-0x18]
    // 0x8c6440: ArrayStore: r1[r4] = r0  ; List_4
    //     0x8c6440: add             x25, x1, x4, lsl #2
    //     0x8c6444: add             x25, x25, #0xf
    //     0x8c6448: str             w0, [x25]
    //     0x8c644c: tbz             w0, #0, #0x8c6468
    //     0x8c6450: ldurb           w16, [x1, #-1]
    //     0x8c6454: ldurb           w17, [x0, #-1]
    //     0x8c6458: and             x16, x17, x16, lsr #2
    //     0x8c645c: tst             x16, HEAP, lsr #32
    //     0x8c6460: b.eq            #0x8c6468
    //     0x8c6464: bl              #0xd67e5c
    // 0x8c6468: r0 = Null
    //     0x8c6468: mov             x0, NULL
    // 0x8c646c: LeaveFrame
    //     0x8c646c: mov             SP, fp
    //     0x8c6470: ldp             fp, lr, [SP], #0x10
    // 0x8c6474: ret
    //     0x8c6474: ret             
    // 0x8c6478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c6478: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c647c: b               #0x8c6258
    // 0x8c6480: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c6480: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8c6484: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c6484: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:dio/src/options.dart

// class id: 1048894, size: 0x8
class :: {
}

// class id: 4528, size: 0x44, field offset: 0x8
class Options extends Object {

  _ compose(/* No info */) {
    // ** addr: 0x55a9c4, size: 0x4a0
    // 0x55a9c4: EnterFrame
    //     0x55a9c4: stp             fp, lr, [SP, #-0x10]!
    //     0x55a9c8: mov             fp, SP
    // 0x55a9cc: AllocStack(0x58)
    //     0x55a9cc: sub             SP, SP, #0x58
    // 0x55a9d0: CheckStackOverflow
    //     0x55a9d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a9d4: cmp             SP, x16
    //     0x55a9d8: b.ls            #0x55adcc
    // 0x55a9dc: r16 = <String, dynamic>
    //     0x55a9dc: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x55a9e0: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x55a9e4: stp             lr, x16, [SP, #-0x10]!
    // 0x55a9e8: r0 = Map._fromLiteral()
    //     0x55a9e8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x55a9ec: add             SP, SP, #0x10
    // 0x55a9f0: mov             x1, x0
    // 0x55a9f4: ldr             x0, [fp, #0x30]
    // 0x55a9f8: stur            x1, [fp, #-8]
    // 0x55a9fc: LoadField: r2 = r0->field_47
    //     0x55a9fc: ldur            w2, [x0, #0x47]
    // 0x55aa00: DecompressPointer r2
    //     0x55aa00: add             x2, x2, HEAP, lsl #32
    // 0x55aa04: r16 = Sentinel
    //     0x55aa04: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55aa08: cmp             w2, w16
    // 0x55aa0c: b.eq            #0x55add4
    // 0x55aa10: stp             x2, x1, [SP, #-0x10]!
    // 0x55aa14: r0 = addAll()
    //     0x55aa14: bl              #0xc79dfc  ; [dart:collection] _Map::addAll
    // 0x55aa18: add             SP, SP, #0x10
    // 0x55aa1c: ldr             x0, [fp, #0x30]
    // 0x55aa20: LoadField: r1 = r0->field_b
    //     0x55aa20: ldur            w1, [x0, #0xb]
    // 0x55aa24: DecompressPointer r1
    //     0x55aa24: add             x1, x1, HEAP, lsl #32
    // 0x55aa28: r16 = Sentinel
    //     0x55aa28: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55aa2c: cmp             w1, w16
    // 0x55aa30: b.eq            #0x55ade0
    // 0x55aa34: stp             x1, NULL, [SP, #-0x10]!
    // 0x55aa38: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x55aa38: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x55aa3c: r0 = caseInsensitiveKeyMap()
    //     0x55aa3c: bl              #0x529878  ; [package:dio/src/utils.dart] ::caseInsensitiveKeyMap
    // 0x55aa40: add             SP, SP, #0x10
    // 0x55aa44: mov             x2, x0
    // 0x55aa48: ldr             x1, [fp, #0x38]
    // 0x55aa4c: stur            x2, [fp, #-0x10]
    // 0x55aa50: LoadField: r0 = r1->field_b
    //     0x55aa50: ldur            w0, [x1, #0xb]
    // 0x55aa54: DecompressPointer r0
    //     0x55aa54: add             x0, x0, HEAP, lsl #32
    // 0x55aa58: cmp             w0, NULL
    // 0x55aa5c: b.eq            #0x55aa80
    // 0x55aa60: r3 = LoadClassIdInstr(r2)
    //     0x55aa60: ldur            x3, [x2, #-1]
    //     0x55aa64: ubfx            x3, x3, #0xc, #0x14
    // 0x55aa68: stp             x0, x2, [SP, #-0x10]!
    // 0x55aa6c: mov             x0, x3
    // 0x55aa70: r0 = GDT[cid_x0 + 0xcfd]()
    //     0x55aa70: add             lr, x0, #0xcfd
    //     0x55aa74: ldr             lr, [x21, lr, lsl #3]
    //     0x55aa78: blr             lr
    // 0x55aa7c: add             SP, SP, #0x10
    // 0x55aa80: ldr             x1, [fp, #0x38]
    // 0x55aa84: ldr             x3, [fp, #0x30]
    // 0x55aa88: ldur            x2, [fp, #-0x10]
    // 0x55aa8c: r0 = LoadClassIdInstr(r2)
    //     0x55aa8c: ldur            x0, [x2, #-1]
    //     0x55aa90: ubfx            x0, x0, #0xc, #0x14
    // 0x55aa94: r16 = "content-type"
    //     0x55aa94: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x55aa98: ldr             x16, [x16, #0xed8]
    // 0x55aa9c: stp             x16, x2, [SP, #-0x10]!
    // 0x55aaa0: r0 = GDT[cid_x0 + -0xef]()
    //     0x55aaa0: sub             lr, x0, #0xef
    //     0x55aaa4: ldr             lr, [x21, lr, lsl #3]
    //     0x55aaa8: blr             lr
    // 0x55aaac: add             SP, SP, #0x10
    // 0x55aab0: mov             x3, x0
    // 0x55aab4: r2 = Null
    //     0x55aab4: mov             x2, NULL
    // 0x55aab8: r1 = Null
    //     0x55aab8: mov             x1, NULL
    // 0x55aabc: stur            x3, [fp, #-0x18]
    // 0x55aac0: r4 = 59
    //     0x55aac0: mov             x4, #0x3b
    // 0x55aac4: branchIfSmi(r0, 0x55aad0)
    //     0x55aac4: tbz             w0, #0, #0x55aad0
    // 0x55aac8: r4 = LoadClassIdInstr(r0)
    //     0x55aac8: ldur            x4, [x0, #-1]
    //     0x55aacc: ubfx            x4, x4, #0xc, #0x14
    // 0x55aad0: sub             x4, x4, #0x5d
    // 0x55aad4: cmp             x4, #3
    // 0x55aad8: b.ls            #0x55aaec
    // 0x55aadc: r8 = String?
    //     0x55aadc: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0x55aae0: r3 = Null
    //     0x55aae0: add             x3, PP, #0x14, lsl #12  ; [pp+0x146b0] Null
    //     0x55aae4: ldr             x3, [x3, #0x6b0]
    // 0x55aae8: r0 = String?()
    //     0x55aae8: bl              #0x4b2994  ; IsType_String?_Stub
    // 0x55aaec: ldr             x0, [fp, #0x30]
    // 0x55aaf0: LoadField: r1 = r0->field_27
    //     0x55aaf0: ldur            w1, [x0, #0x27]
    // 0x55aaf4: DecompressPointer r1
    //     0x55aaf4: add             x1, x1, HEAP, lsl #32
    // 0x55aaf8: r16 = Sentinel
    //     0x55aaf8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55aafc: cmp             w1, w16
    // 0x55ab00: b.eq            #0x55adec
    // 0x55ab04: r16 = <String, dynamic>
    //     0x55ab04: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x55ab08: stp             x1, x16, [SP, #-0x10]!
    // 0x55ab0c: r0 = LinkedHashMap.from()
    //     0x55ab0c: bl              #0x5428b8  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x55ab10: add             SP, SP, #0x10
    // 0x55ab14: mov             x2, x0
    // 0x55ab18: ldr             x1, [fp, #0x38]
    // 0x55ab1c: stur            x2, [fp, #-0x20]
    // 0x55ab20: LoadField: r0 = r1->field_7
    //     0x55ab20: ldur            w0, [x1, #7]
    // 0x55ab24: DecompressPointer r0
    //     0x55ab24: add             x0, x0, HEAP, lsl #32
    // 0x55ab28: cmp             w0, NULL
    // 0x55ab2c: b.ne            #0x55ab4c
    // 0x55ab30: ldr             x3, [fp, #0x30]
    // 0x55ab34: LoadField: r0 = r3->field_7
    //     0x55ab34: ldur            w0, [x3, #7]
    // 0x55ab38: DecompressPointer r0
    //     0x55ab38: add             x0, x0, HEAP, lsl #32
    // 0x55ab3c: r16 = Sentinel
    //     0x55ab3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55ab40: cmp             w0, w16
    // 0x55ab44: b.eq            #0x55adf8
    // 0x55ab48: b               #0x55ab50
    // 0x55ab4c: ldr             x3, [fp, #0x30]
    // 0x55ab50: r4 = LoadClassIdInstr(r0)
    //     0x55ab50: ldur            x4, [x0, #-1]
    //     0x55ab54: ubfx            x4, x4, #0xc, #0x14
    // 0x55ab58: SaveReg r0
    //     0x55ab58: str             x0, [SP, #-8]!
    // 0x55ab5c: mov             x0, x4
    // 0x55ab60: r0 = GDT[cid_x0 + -0xfe8]()
    //     0x55ab60: sub             lr, x0, #0xfe8
    //     0x55ab64: ldr             lr, [x21, lr, lsl #3]
    //     0x55ab68: blr             lr
    // 0x55ab6c: add             SP, SP, #8
    // 0x55ab70: mov             x1, x0
    // 0x55ab74: ldr             x0, [fp, #0x30]
    // 0x55ab78: stur            x1, [fp, #-0x50]
    // 0x55ab7c: LoadField: r2 = r0->field_43
    //     0x55ab7c: ldur            w2, [x0, #0x43]
    // 0x55ab80: DecompressPointer r2
    //     0x55ab80: add             x2, x2, HEAP, lsl #32
    // 0x55ab84: r16 = Sentinel
    //     0x55ab84: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55ab88: cmp             w2, w16
    // 0x55ab8c: b.eq            #0x55ae04
    // 0x55ab90: LoadField: r2 = r0->field_4b
    //     0x55ab90: ldur            w2, [x0, #0x4b]
    // 0x55ab94: DecompressPointer r2
    //     0x55ab94: add             x2, x2, HEAP, lsl #32
    // 0x55ab98: stur            x2, [fp, #-0x48]
    // 0x55ab9c: LoadField: r3 = r0->field_f
    //     0x55ab9c: ldur            w3, [x0, #0xf]
    // 0x55aba0: DecompressPointer r3
    //     0x55aba0: add             x3, x3, HEAP, lsl #32
    // 0x55aba4: stur            x3, [fp, #-0x40]
    // 0x55aba8: LoadField: r4 = r0->field_13
    //     0x55aba8: ldur            w4, [x0, #0x13]
    // 0x55abac: DecompressPointer r4
    //     0x55abac: add             x4, x4, HEAP, lsl #32
    // 0x55abb0: ldr             x5, [fp, #0x38]
    // 0x55abb4: stur            x4, [fp, #-0x38]
    // 0x55abb8: LoadField: r6 = r5->field_1b
    //     0x55abb8: ldur            w6, [x5, #0x1b]
    // 0x55abbc: DecompressPointer r6
    //     0x55abbc: add             x6, x6, HEAP, lsl #32
    // 0x55abc0: cmp             w6, NULL
    // 0x55abc4: b.ne            #0x55abe0
    // 0x55abc8: LoadField: r5 = r0->field_1b
    //     0x55abc8: ldur            w5, [x0, #0x1b]
    // 0x55abcc: DecompressPointer r5
    //     0x55abcc: add             x5, x5, HEAP, lsl #32
    // 0x55abd0: r16 = Sentinel
    //     0x55abd0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55abd4: cmp             w5, w16
    // 0x55abd8: b.eq            #0x55ae10
    // 0x55abdc: mov             x6, x5
    // 0x55abe0: ldur            x5, [fp, #-0x18]
    // 0x55abe4: stur            x6, [fp, #-0x30]
    // 0x55abe8: LoadField: r7 = r0->field_1f
    //     0x55abe8: ldur            w7, [x0, #0x1f]
    // 0x55abec: DecompressPointer r7
    //     0x55abec: add             x7, x7, HEAP, lsl #32
    // 0x55abf0: r16 = Sentinel
    //     0x55abf0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55abf4: cmp             w7, w16
    // 0x55abf8: b.eq            #0x55ae1c
    // 0x55abfc: stur            x7, [fp, #-0x28]
    // 0x55ac00: LoadField: r8 = r0->field_23
    //     0x55ac00: ldur            w8, [x0, #0x23]
    // 0x55ac04: DecompressPointer r8
    //     0x55ac04: add             x8, x8, HEAP, lsl #32
    // 0x55ac08: r16 = Sentinel
    //     0x55ac08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55ac0c: cmp             w8, w16
    // 0x55ac10: b.eq            #0x55ae28
    // 0x55ac14: LoadField: r8 = r0->field_2b
    //     0x55ac14: ldur            w8, [x0, #0x2b]
    // 0x55ac18: DecompressPointer r8
    //     0x55ac18: add             x8, x8, HEAP, lsl #32
    // 0x55ac1c: r16 = Sentinel
    //     0x55ac1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55ac20: cmp             w8, w16
    // 0x55ac24: b.eq            #0x55ae34
    // 0x55ac28: LoadField: r8 = r0->field_2f
    //     0x55ac28: ldur            w8, [x0, #0x2f]
    // 0x55ac2c: DecompressPointer r8
    //     0x55ac2c: add             x8, x8, HEAP, lsl #32
    // 0x55ac30: r16 = Sentinel
    //     0x55ac30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55ac34: cmp             w8, w16
    // 0x55ac38: b.eq            #0x55ae40
    // 0x55ac3c: LoadField: r8 = r0->field_33
    //     0x55ac3c: ldur            w8, [x0, #0x33]
    // 0x55ac40: DecompressPointer r8
    //     0x55ac40: add             x8, x8, HEAP, lsl #32
    // 0x55ac44: r16 = Sentinel
    //     0x55ac44: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55ac48: cmp             w8, w16
    // 0x55ac4c: b.eq            #0x55ae4c
    // 0x55ac50: LoadField: r8 = r0->field_3f
    //     0x55ac50: ldur            w8, [x0, #0x3f]
    // 0x55ac54: DecompressPointer r8
    //     0x55ac54: add             x8, x8, HEAP, lsl #32
    // 0x55ac58: r16 = Sentinel
    //     0x55ac58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55ac5c: cmp             w8, w16
    // 0x55ac60: b.eq            #0x55ae58
    // 0x55ac64: cmp             w5, NULL
    // 0x55ac68: b.ne            #0x55ac70
    // 0x55ac6c: r5 = Null
    //     0x55ac6c: mov             x5, NULL
    // 0x55ac70: cmp             w5, NULL
    // 0x55ac74: b.ne            #0x55ace8
    // 0x55ac78: LoadField: r5 = r0->field_b
    //     0x55ac78: ldur            w5, [x0, #0xb]
    // 0x55ac7c: DecompressPointer r5
    //     0x55ac7c: add             x5, x5, HEAP, lsl #32
    // 0x55ac80: r0 = LoadClassIdInstr(r5)
    //     0x55ac80: ldur            x0, [x5, #-1]
    //     0x55ac84: ubfx            x0, x0, #0xc, #0x14
    // 0x55ac88: r16 = "content-type"
    //     0x55ac88: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x55ac8c: ldr             x16, [x16, #0xed8]
    // 0x55ac90: stp             x16, x5, [SP, #-0x10]!
    // 0x55ac94: r0 = GDT[cid_x0 + -0xef]()
    //     0x55ac94: sub             lr, x0, #0xef
    //     0x55ac98: ldr             lr, [x21, lr, lsl #3]
    //     0x55ac9c: blr             lr
    // 0x55aca0: add             SP, SP, #0x10
    // 0x55aca4: mov             x3, x0
    // 0x55aca8: r2 = Null
    //     0x55aca8: mov             x2, NULL
    // 0x55acac: r1 = Null
    //     0x55acac: mov             x1, NULL
    // 0x55acb0: stur            x3, [fp, #-0x18]
    // 0x55acb4: r4 = 59
    //     0x55acb4: mov             x4, #0x3b
    // 0x55acb8: branchIfSmi(r0, 0x55acc4)
    //     0x55acb8: tbz             w0, #0, #0x55acc4
    // 0x55acbc: r4 = LoadClassIdInstr(r0)
    //     0x55acbc: ldur            x4, [x0, #-1]
    //     0x55acc0: ubfx            x4, x4, #0xc, #0x14
    // 0x55acc4: sub             x4, x4, #0x5d
    // 0x55acc8: cmp             x4, #3
    // 0x55accc: b.ls            #0x55ace0
    // 0x55acd0: r8 = String?
    //     0x55acd0: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0x55acd4: r3 = Null
    //     0x55acd4: add             x3, PP, #0x14, lsl #12  ; [pp+0x146c0] Null
    //     0x55acd8: ldr             x3, [x3, #0x6c0]
    // 0x55acdc: r0 = String?()
    //     0x55acdc: bl              #0x4b2994  ; IsType_String?_Stub
    // 0x55ace0: ldur            x0, [fp, #-0x18]
    // 0x55ace4: b               #0x55acec
    // 0x55ace8: mov             x0, x5
    // 0x55acec: stur            x0, [fp, #-0x18]
    // 0x55acf0: r0 = RequestOptions()
    //     0x55acf0: bl              #0x55bbc8  ; AllocateRequestOptionsStub -> RequestOptions (size=0x68)
    // 0x55acf4: stur            x0, [fp, #-0x58]
    // 0x55acf8: ldur            x16, [fp, #-0x50]
    // 0x55acfc: stp             x16, x0, [SP, #-0x10]!
    // 0x55ad00: ldur            x16, [fp, #-0x10]
    // 0x55ad04: ldur            lr, [fp, #-0x20]
    // 0x55ad08: stp             lr, x16, [SP, #-0x10]!
    // 0x55ad0c: r16 = ""
    //     0x55ad0c: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x55ad10: ldr             lr, [fp, #0x28]
    // 0x55ad14: stp             lr, x16, [SP, #-0x10]!
    // 0x55ad18: ldr             x16, [fp, #0x18]
    // 0x55ad1c: ldr             lr, [fp, #0x10]
    // 0x55ad20: stp             lr, x16, [SP, #-0x10]!
    // 0x55ad24: ldur            x16, [fp, #-0x48]
    // 0x55ad28: ldur            lr, [fp, #-0x40]
    // 0x55ad2c: stp             lr, x16, [SP, #-0x10]!
    // 0x55ad30: ldur            x16, [fp, #-0x38]
    // 0x55ad34: ldur            lr, [fp, #-0x30]
    // 0x55ad38: stp             lr, x16, [SP, #-0x10]!
    // 0x55ad3c: ldur            x16, [fp, #-0x28]
    // 0x55ad40: r30 = true
    //     0x55ad40: add             lr, NULL, #0x20  ; true
    // 0x55ad44: stp             lr, x16, [SP, #-0x10]!
    // 0x55ad48: r16 = true
    //     0x55ad48: add             x16, NULL, #0x20  ; true
    // 0x55ad4c: r30 = 10
    //     0x55ad4c: mov             lr, #0xa
    // 0x55ad50: stp             lr, x16, [SP, #-0x10]!
    // 0x55ad54: r16 = true
    //     0x55ad54: add             x16, NULL, #0x20  ; true
    // 0x55ad58: ldur            lr, [fp, #-8]
    // 0x55ad5c: stp             lr, x16, [SP, #-0x10]!
    // 0x55ad60: r16 = Instance_ListFormat
    //     0x55ad60: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d0] Obj!ListFormat@b66511
    //     0x55ad64: ldr             x16, [x16, #0x6d0]
    // 0x55ad68: ldr             lr, [fp, #0x20]
    // 0x55ad6c: stp             lr, x16, [SP, #-0x10]!
    // 0x55ad70: ldur            x16, [fp, #-0x18]
    // 0x55ad74: SaveReg r16
    //     0x55ad74: str             x16, [SP, #-8]!
    // 0x55ad78: r4 = const [0, 0x15, 0x15, 0x1, baseUrl, 0x4, cancelToken, 0x13, connectTimeout, 0x8, contentType, 0x14, data, 0x6, extra, 0x3, followRedirects, 0xe, headers, 0x2, listFormat, 0x12, maxRedirects, 0xf, method, 0x1, path, 0x5, persistentConnection, 0x10, queryParameters, 0x11, receiveDataWhenStatusError, 0xd, receiveTimeout, 0xa, responseType, 0xb, sendTimeout, 0x9, sourceStackTrace, 0x7, validateStatus, 0xc, null]
    //     0x55ad78: add             x4, PP, #0x14, lsl #12  ; [pp+0x146d8] List(45) [0, 0x15, 0x15, 0x1, "baseUrl", 0x4, "cancelToken", 0x13, "connectTimeout", 0x8, "contentType", 0x14, "data", 0x6, "extra", 0x3, "followRedirects", 0xe, "headers", 0x2, "listFormat", 0x12, "maxRedirects", 0xf, "method", 0x1, "path", 0x5, "persistentConnection", 0x10, "queryParameters", 0x11, "receiveDataWhenStatusError", 0xd, "receiveTimeout", 0xa, "responseType", 0xb, "sendTimeout", 0x9, "sourceStackTrace", 0x7, "validateStatus", 0xc, Null]
    //     0x55ad7c: ldr             x4, [x4, #0x6d8]
    // 0x55ad80: r0 = RequestOptions()
    //     0x55ad80: bl              #0x55ae64  ; [package:dio/src/options.dart] RequestOptions::RequestOptions
    // 0x55ad84: add             SP, SP, #0xa8
    // 0x55ad88: ldur            x1, [fp, #-0x58]
    // 0x55ad8c: LoadField: r2 = r1->field_5b
    //     0x55ad8c: ldur            w2, [x1, #0x5b]
    // 0x55ad90: DecompressPointer r2
    //     0x55ad90: add             x2, x2, HEAP, lsl #32
    // 0x55ad94: cmp             w2, NULL
    // 0x55ad98: b.eq            #0x55adbc
    // 0x55ad9c: mov             x0, x1
    // 0x55ada0: StoreField: r2->field_f = r0
    //     0x55ada0: stur            w0, [x2, #0xf]
    //     0x55ada4: ldurb           w16, [x2, #-1]
    //     0x55ada8: ldurb           w17, [x0, #-1]
    //     0x55adac: and             x16, x17, x16, lsr #2
    //     0x55adb0: tst             x16, HEAP, lsr #32
    //     0x55adb4: b.eq            #0x55adbc
    //     0x55adb8: bl              #0xd6828c
    // 0x55adbc: mov             x0, x1
    // 0x55adc0: LeaveFrame
    //     0x55adc0: mov             SP, fp
    //     0x55adc4: ldp             fp, lr, [SP], #0x10
    // 0x55adc8: ret
    //     0x55adc8: ret             
    // 0x55adcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55adcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55add0: b               #0x55a9dc
    // 0x55add4: r9 = queryParameters
    //     0x55add4: add             x9, PP, #0x14, lsl #12  ; [pp+0x142e8] Field <_BaseOptions&_RequestConfig&OptionsMixin@361184022.queryParameters>: late (offset: 0x48)
    //     0x55add8: ldr             x9, [x9, #0x2e8]
    // 0x55addc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55addc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55ade0: r9 = _headers
    //     0x55ade0: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x55ade4: ldr             x9, [x9, #0xee0]
    // 0x55ade8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55ade8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55adec: r9 = extra
    //     0x55adec: add             x9, PP, #0x14, lsl #12  ; [pp+0x146e0] Field <_RequestConfig@361184022.extra>: late (offset: 0x28)
    //     0x55adf0: ldr             x9, [x9, #0x6e0]
    // 0x55adf4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55adf4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55adf8: r9 = method
    //     0x55adf8: add             x9, PP, #0x13, lsl #12  ; [pp+0x13458] Field <_RequestConfig@361184022.method>: late (offset: 0x8)
    //     0x55adfc: ldr             x9, [x9, #0x458]
    // 0x55ae00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55ae00: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55ae04: r9 = baseUrl
    //     0x55ae04: add             x9, PP, #0x14, lsl #12  ; [pp+0x142e0] Field <_BaseOptions&_RequestConfig&OptionsMixin@361184022.baseUrl>: late (offset: 0x44)
    //     0x55ae08: ldr             x9, [x9, #0x2e0]
    // 0x55ae0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55ae0c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55ae10: r9 = responseType
    //     0x55ae10: add             x9, PP, #0x12, lsl #12  ; [pp+0x12e90] Field <_RequestConfig@361184022.responseType>: late (offset: 0x1c)
    //     0x55ae14: ldr             x9, [x9, #0xe90]
    // 0x55ae18: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55ae18: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55ae1c: r9 = validateStatus
    //     0x55ae1c: add             x9, PP, #0x13, lsl #12  ; [pp+0x13138] Field <_RequestConfig@361184022.validateStatus>: late (offset: 0x20)
    //     0x55ae20: ldr             x9, [x9, #0x138]
    // 0x55ae24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55ae24: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55ae28: r9 = receiveDataWhenStatusError
    //     0x55ae28: add             x9, PP, #0x13, lsl #12  ; [pp+0x13140] Field <_RequestConfig@361184022.receiveDataWhenStatusError>: late (offset: 0x24)
    //     0x55ae2c: ldr             x9, [x9, #0x140]
    // 0x55ae30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55ae30: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55ae34: r9 = followRedirects
    //     0x55ae34: add             x9, PP, #0x13, lsl #12  ; [pp+0x13460] Field <_RequestConfig@361184022.followRedirects>: late (offset: 0x2c)
    //     0x55ae38: ldr             x9, [x9, #0x460]
    // 0x55ae3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55ae3c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55ae40: r9 = maxRedirects
    //     0x55ae40: add             x9, PP, #0x13, lsl #12  ; [pp+0x13470] Field <_RequestConfig@361184022.maxRedirects>: late (offset: 0x30)
    //     0x55ae44: ldr             x9, [x9, #0x470]
    // 0x55ae48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55ae48: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55ae4c: r9 = persistentConnection
    //     0x55ae4c: add             x9, PP, #0x13, lsl #12  ; [pp+0x13480] Field <_RequestConfig@361184022.persistentConnection>: late (offset: 0x34)
    //     0x55ae50: ldr             x9, [x9, #0x480]
    // 0x55ae54: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55ae54: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55ae58: r9 = listFormat
    //     0x55ae58: add             x9, PP, #0x14, lsl #12  ; [pp+0x142f0] Field <_RequestConfig@361184022.listFormat>: late (offset: 0x40)
    //     0x55ae5c: ldr             x9, [x9, #0x2f0]
    // 0x55ae60: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55ae60: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4529, size: 0x8, field offset: 0x8
abstract class OptionsMixin extends Object {
}

// class id: 4530, size: 0x44, field offset: 0x8
abstract class _RequestConfig extends Object {

  late ResponseType responseType; // offset: 0x1c
  late Map<String, dynamic> _headers; // offset: 0xc
  late (dynamic, int?) => bool validateStatus; // offset: 0x20
  late bool receiveDataWhenStatusError; // offset: 0x24
  late String method; // offset: 0x8
  late bool followRedirects; // offset: 0x2c
  late int maxRedirects; // offset: 0x30
  late bool persistentConnection; // offset: 0x34
  late ListFormat listFormat; // offset: 0x40
  late Map<String, dynamic> extra; // offset: 0x28

  set _ contentType=(/* No info */) {
    // ** addr: 0x527f98, size: 0x114
    // 0x527f98: EnterFrame
    //     0x527f98: stp             fp, lr, [SP, #-0x10]!
    //     0x527f9c: mov             fp, SP
    // 0x527fa0: CheckStackOverflow
    //     0x527fa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x527fa4: cmp             SP, x16
    //     0x527fa8: b.ls            #0x52808c
    // 0x527fac: ldr             x0, [fp, #0x10]
    // 0x527fb0: cmp             w0, NULL
    // 0x527fb4: b.ne            #0x527fc0
    // 0x527fb8: r2 = Null
    //     0x527fb8: mov             x2, NULL
    // 0x527fbc: b               #0x527fd0
    // 0x527fc0: SaveReg r0
    //     0x527fc0: str             x0, [SP, #-8]!
    // 0x527fc4: r0 = trim()
    //     0x527fc4: bl              #0x4f0838  ; [dart:core] _StringBase::trim
    // 0x527fc8: add             SP, SP, #8
    // 0x527fcc: mov             x2, x0
    // 0x527fd0: ldr             x1, [fp, #0x18]
    // 0x527fd4: mov             x0, x2
    // 0x527fd8: StoreField: r1->field_17 = r0
    //     0x527fd8: stur            w0, [x1, #0x17]
    //     0x527fdc: ldurb           w16, [x1, #-1]
    //     0x527fe0: ldurb           w17, [x0, #-1]
    //     0x527fe4: and             x16, x17, x16, lsr #2
    //     0x527fe8: tst             x16, HEAP, lsr #32
    //     0x527fec: b.eq            #0x527ff4
    //     0x527ff0: bl              #0xd6826c
    // 0x527ff4: cmp             w2, NULL
    // 0x527ff8: b.eq            #0x528040
    // 0x527ffc: LoadField: r0 = r1->field_b
    //     0x527ffc: ldur            w0, [x1, #0xb]
    // 0x528000: DecompressPointer r0
    //     0x528000: add             x0, x0, HEAP, lsl #32
    // 0x528004: r16 = Sentinel
    //     0x528004: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x528008: cmp             w0, w16
    // 0x52800c: b.eq            #0x528094
    // 0x528010: r1 = LoadClassIdInstr(r0)
    //     0x528010: ldur            x1, [x0, #-1]
    //     0x528014: ubfx            x1, x1, #0xc, #0x14
    // 0x528018: r16 = "content-type"
    //     0x528018: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x52801c: ldr             x16, [x16, #0xed8]
    // 0x528020: stp             x16, x0, [SP, #-0x10]!
    // 0x528024: SaveReg r2
    //     0x528024: str             x2, [SP, #-8]!
    // 0x528028: mov             x0, x1
    // 0x52802c: r0 = GDT[cid_x0 + 0x35a]()
    //     0x52802c: add             lr, x0, #0x35a
    //     0x528030: ldr             lr, [x21, lr, lsl #3]
    //     0x528034: blr             lr
    // 0x528038: add             SP, SP, #0x18
    // 0x52803c: b               #0x52807c
    // 0x528040: LoadField: r0 = r1->field_b
    //     0x528040: ldur            w0, [x1, #0xb]
    // 0x528044: DecompressPointer r0
    //     0x528044: add             x0, x0, HEAP, lsl #32
    // 0x528048: r16 = Sentinel
    //     0x528048: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52804c: cmp             w0, w16
    // 0x528050: b.eq            #0x5280a0
    // 0x528054: r1 = LoadClassIdInstr(r0)
    //     0x528054: ldur            x1, [x0, #-1]
    //     0x528058: ubfx            x1, x1, #0xc, #0x14
    // 0x52805c: r16 = "content-type"
    //     0x52805c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x528060: ldr             x16, [x16, #0xed8]
    // 0x528064: stp             x16, x0, [SP, #-0x10]!
    // 0x528068: mov             x0, x1
    // 0x52806c: r0 = GDT[cid_x0 + 0x6e2]()
    //     0x52806c: add             lr, x0, #0x6e2
    //     0x528070: ldr             lr, [x21, lr, lsl #3]
    //     0x528074: blr             lr
    // 0x528078: add             SP, SP, #0x10
    // 0x52807c: r0 = Null
    //     0x52807c: mov             x0, NULL
    // 0x528080: LeaveFrame
    //     0x528080: mov             SP, fp
    //     0x528084: ldp             fp, lr, [SP], #0x10
    // 0x528088: ret
    //     0x528088: ret             
    // 0x52808c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52808c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x528090: b               #0x527fac
    // 0x528094: r9 = _headers
    //     0x528094: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x528098: ldr             x9, [x9, #0xee0]
    // 0x52809c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52809c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x5280a0: r9 = _headers
    //     0x5280a0: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x5280a4: ldr             x9, [x9, #0xee0]
    // 0x5280a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x5280a8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ contentType(/* No info */) {
    // ** addr: 0x5280ac, size: 0xb4
    // 0x5280ac: EnterFrame
    //     0x5280ac: stp             fp, lr, [SP, #-0x10]!
    //     0x5280b0: mov             fp, SP
    // 0x5280b4: AllocStack(0x8)
    //     0x5280b4: sub             SP, SP, #8
    // 0x5280b8: CheckStackOverflow
    //     0x5280b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5280bc: cmp             SP, x16
    //     0x5280c0: b.ls            #0x52814c
    // 0x5280c4: ldr             x0, [fp, #0x10]
    // 0x5280c8: LoadField: r1 = r0->field_b
    //     0x5280c8: ldur            w1, [x0, #0xb]
    // 0x5280cc: DecompressPointer r1
    //     0x5280cc: add             x1, x1, HEAP, lsl #32
    // 0x5280d0: r16 = Sentinel
    //     0x5280d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5280d4: cmp             w1, w16
    // 0x5280d8: b.eq            #0x528154
    // 0x5280dc: r0 = LoadClassIdInstr(r1)
    //     0x5280dc: ldur            x0, [x1, #-1]
    //     0x5280e0: ubfx            x0, x0, #0xc, #0x14
    // 0x5280e4: r16 = "content-type"
    //     0x5280e4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x5280e8: ldr             x16, [x16, #0xed8]
    // 0x5280ec: stp             x16, x1, [SP, #-0x10]!
    // 0x5280f0: r0 = GDT[cid_x0 + -0xef]()
    //     0x5280f0: sub             lr, x0, #0xef
    //     0x5280f4: ldr             lr, [x21, lr, lsl #3]
    //     0x5280f8: blr             lr
    // 0x5280fc: add             SP, SP, #0x10
    // 0x528100: mov             x3, x0
    // 0x528104: r2 = Null
    //     0x528104: mov             x2, NULL
    // 0x528108: r1 = Null
    //     0x528108: mov             x1, NULL
    // 0x52810c: stur            x3, [fp, #-8]
    // 0x528110: r4 = 59
    //     0x528110: mov             x4, #0x3b
    // 0x528114: branchIfSmi(r0, 0x528120)
    //     0x528114: tbz             w0, #0, #0x528120
    // 0x528118: r4 = LoadClassIdInstr(r0)
    //     0x528118: ldur            x4, [x0, #-1]
    //     0x52811c: ubfx            x4, x4, #0xc, #0x14
    // 0x528120: sub             x4, x4, #0x5d
    // 0x528124: cmp             x4, #3
    // 0x528128: b.ls            #0x52813c
    // 0x52812c: r8 = String?
    //     0x52812c: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0x528130: r3 = Null
    //     0x528130: add             x3, PP, #0x12, lsl #12  ; [pp+0x12ee8] Null
    //     0x528134: ldr             x3, [x3, #0xee8]
    // 0x528138: r0 = String?()
    //     0x528138: bl              #0x4b2994  ; IsType_String?_Stub
    // 0x52813c: ldur            x0, [fp, #-8]
    // 0x528140: LeaveFrame
    //     0x528140: mov             SP, fp
    //     0x528144: ldp             fp, lr, [SP], #0x10
    // 0x528148: ret
    //     0x528148: ret             
    // 0x52814c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52814c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x528150: b               #0x5280c4
    // 0x528154: r9 = _headers
    //     0x528154: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x528158: ldr             x9, [x9, #0xee0]
    // 0x52815c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52815c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _RequestConfig(/* No info */) {
    // ** addr: 0x55b800, size: 0x2b4
    // 0x55b800: EnterFrame
    //     0x55b800: stp             fp, lr, [SP, #-0x10]!
    //     0x55b804: mov             fp, SP
    // 0x55b808: AllocStack(0x8)
    //     0x55b808: sub             SP, SP, #8
    // 0x55b80c: r0 = Sentinel
    //     0x55b80c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55b810: CheckStackOverflow
    //     0x55b810: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55b814: cmp             SP, x16
    //     0x55b818: b.ls            #0x55baa0
    // 0x55b81c: ldr             x1, [fp, #0x78]
    // 0x55b820: StoreField: r1->field_7 = r0
    //     0x55b820: stur            w0, [x1, #7]
    // 0x55b824: StoreField: r1->field_b = r0
    //     0x55b824: stur            w0, [x1, #0xb]
    // 0x55b828: StoreField: r1->field_1b = r0
    //     0x55b828: stur            w0, [x1, #0x1b]
    // 0x55b82c: StoreField: r1->field_1f = r0
    //     0x55b82c: stur            w0, [x1, #0x1f]
    // 0x55b830: StoreField: r1->field_23 = r0
    //     0x55b830: stur            w0, [x1, #0x23]
    // 0x55b834: StoreField: r1->field_27 = r0
    //     0x55b834: stur            w0, [x1, #0x27]
    // 0x55b838: StoreField: r1->field_2b = r0
    //     0x55b838: stur            w0, [x1, #0x2b]
    // 0x55b83c: StoreField: r1->field_2f = r0
    //     0x55b83c: stur            w0, [x1, #0x2f]
    // 0x55b840: StoreField: r1->field_33 = r0
    //     0x55b840: stur            w0, [x1, #0x33]
    // 0x55b844: StoreField: r1->field_3f = r0
    //     0x55b844: stur            w0, [x1, #0x3f]
    // 0x55b848: ldr             x0, [fp, #0x28]
    // 0x55b84c: StoreField: r1->field_13 = r0
    //     0x55b84c: stur            w0, [x1, #0x13]
    //     0x55b850: ldurb           w16, [x1, #-1]
    //     0x55b854: ldurb           w17, [x0, #-1]
    //     0x55b858: and             x16, x17, x16, lsr #2
    //     0x55b85c: tst             x16, HEAP, lsr #32
    //     0x55b860: b.eq            #0x55b868
    //     0x55b864: bl              #0xd6826c
    // 0x55b868: ldr             x0, [fp, #0x18]
    // 0x55b86c: StoreField: r1->field_f = r0
    //     0x55b86c: stur            w0, [x1, #0xf]
    //     0x55b870: ldurb           w16, [x1, #-1]
    //     0x55b874: ldurb           w17, [x0, #-1]
    //     0x55b878: and             x16, x17, x16, lsr #2
    //     0x55b87c: tst             x16, HEAP, lsr #32
    //     0x55b880: b.eq            #0x55b888
    //     0x55b884: bl              #0xd6826c
    // 0x55b888: ldr             x16, [fp, #0x58]
    // 0x55b88c: stp             x16, x1, [SP, #-0x10]!
    // 0x55b890: r0 = headers=()
    //     0x55b890: bl              #0x55bab4  ; [package:dio/src/options.dart] _RequestConfig::headers=
    // 0x55b894: add             SP, SP, #0x10
    // 0x55b898: ldr             x1, [fp, #0x78]
    // 0x55b89c: LoadField: r0 = r1->field_b
    //     0x55b89c: ldur            w0, [x1, #0xb]
    // 0x55b8a0: DecompressPointer r0
    //     0x55b8a0: add             x0, x0, HEAP, lsl #32
    // 0x55b8a4: r16 = Sentinel
    //     0x55b8a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55b8a8: cmp             w0, w16
    // 0x55b8ac: b.eq            #0x55baa8
    // 0x55b8b0: r2 = LoadClassIdInstr(r0)
    //     0x55b8b0: ldur            x2, [x0, #-1]
    //     0x55b8b4: ubfx            x2, x2, #0xc, #0x14
    // 0x55b8b8: r16 = "content-type"
    //     0x55b8b8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x55b8bc: ldr             x16, [x16, #0xed8]
    // 0x55b8c0: stp             x16, x0, [SP, #-0x10]!
    // 0x55b8c4: mov             x0, x2
    // 0x55b8c8: r0 = GDT[cid_x0 + 0x579]()
    //     0x55b8c8: add             lr, x0, #0x579
    //     0x55b8cc: ldr             lr, [x21, lr, lsl #3]
    //     0x55b8d0: blr             lr
    // 0x55b8d4: add             SP, SP, #0x10
    // 0x55b8d8: mov             x1, x0
    // 0x55b8dc: ldr             x0, [fp, #0x40]
    // 0x55b8e0: stur            x1, [fp, #-8]
    // 0x55b8e4: cmp             w0, NULL
    // 0x55b8e8: b.ne            #0x55b8f4
    // 0x55b8ec: r0 = "GET"
    //     0x55b8ec: add             x0, PP, #0x13, lsl #12  ; [pp+0x13630] "GET"
    //     0x55b8f0: ldr             x0, [x0, #0x630]
    // 0x55b8f4: ldr             x2, [fp, #0x78]
    // 0x55b8f8: ldr             x3, [fp, #0x50]
    // 0x55b8fc: StoreField: r2->field_7 = r0
    //     0x55b8fc: stur            w0, [x2, #7]
    //     0x55b900: ldurb           w16, [x2, #-1]
    //     0x55b904: ldurb           w17, [x0, #-1]
    //     0x55b908: and             x16, x17, x16, lsr #2
    //     0x55b90c: tst             x16, HEAP, lsr #32
    //     0x55b910: b.eq            #0x55b918
    //     0x55b914: bl              #0xd6828c
    // 0x55b918: cmp             w3, NULL
    // 0x55b91c: b.ne            #0x55b92c
    // 0x55b920: r0 = Instance_ListFormat
    //     0x55b920: add             x0, PP, #0x14, lsl #12  ; [pp+0x146d0] Obj!ListFormat@b66511
    //     0x55b924: ldr             x0, [x0, #0x6d0]
    // 0x55b928: b               #0x55b930
    // 0x55b92c: mov             x0, x3
    // 0x55b930: ldr             x3, [fp, #0x68]
    // 0x55b934: StoreField: r2->field_3f = r0
    //     0x55b934: stur            w0, [x2, #0x3f]
    //     0x55b938: ldurb           w16, [x2, #-1]
    //     0x55b93c: ldurb           w17, [x0, #-1]
    //     0x55b940: and             x16, x17, x16, lsr #2
    //     0x55b944: tst             x16, HEAP, lsr #32
    //     0x55b948: b.eq            #0x55b950
    //     0x55b94c: bl              #0xd6828c
    // 0x55b950: cmp             w3, NULL
    // 0x55b954: b.ne            #0x55b970
    // 0x55b958: r16 = <String, dynamic>
    //     0x55b958: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x55b95c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x55b960: stp             lr, x16, [SP, #-0x10]!
    // 0x55b964: r0 = Map._fromLiteral()
    //     0x55b964: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x55b968: add             SP, SP, #0x10
    // 0x55b96c: b               #0x55b974
    // 0x55b970: mov             x0, x3
    // 0x55b974: ldr             x3, [fp, #0x78]
    // 0x55b978: ldr             x1, [fp, #0x60]
    // 0x55b97c: StoreField: r3->field_27 = r0
    //     0x55b97c: stur            w0, [x3, #0x27]
    //     0x55b980: tbz             w0, #0, #0x55b99c
    //     0x55b984: ldurb           w16, [x3, #-1]
    //     0x55b988: ldurb           w17, [x0, #-1]
    //     0x55b98c: and             x16, x17, x16, lsr #2
    //     0x55b990: tst             x16, HEAP, lsr #32
    //     0x55b994: b.eq            #0x55b99c
    //     0x55b998: bl              #0xd682ac
    // 0x55b99c: cmp             w1, NULL
    // 0x55b9a0: b.ne            #0x55b9a8
    // 0x55b9a4: r1 = true
    //     0x55b9a4: add             x1, NULL, #0x20  ; true
    // 0x55b9a8: ldr             x0, [fp, #0x48]
    // 0x55b9ac: StoreField: r3->field_2b = r1
    //     0x55b9ac: stur            w1, [x3, #0x2b]
    // 0x55b9b0: cmp             w0, NULL
    // 0x55b9b4: b.ne            #0x55b9c0
    // 0x55b9b8: r1 = 5
    //     0x55b9b8: mov             x1, #5
    // 0x55b9bc: b               #0x55b9c4
    // 0x55b9c0: r1 = LoadInt32Instr(r0)
    //     0x55b9c0: sbfx            x1, x0, #1, #0x1f
    // 0x55b9c4: ldr             x0, [fp, #0x38]
    // 0x55b9c8: lsl             x2, x1, #1
    // 0x55b9cc: StoreField: r3->field_2f = r2
    //     0x55b9cc: stur            w2, [x3, #0x2f]
    // 0x55b9d0: cmp             w0, NULL
    // 0x55b9d4: b.ne            #0x55b9e0
    // 0x55b9d8: r1 = true
    //     0x55b9d8: add             x1, NULL, #0x20  ; true
    // 0x55b9dc: b               #0x55b9e4
    // 0x55b9e0: mov             x1, x0
    // 0x55b9e4: ldr             x0, [fp, #0x30]
    // 0x55b9e8: StoreField: r3->field_33 = r1
    //     0x55b9e8: stur            w1, [x3, #0x33]
    // 0x55b9ec: cmp             w0, NULL
    // 0x55b9f0: b.ne            #0x55b9fc
    // 0x55b9f4: r1 = true
    //     0x55b9f4: add             x1, NULL, #0x20  ; true
    // 0x55b9f8: b               #0x55ba00
    // 0x55b9fc: mov             x1, x0
    // 0x55ba00: ldr             x0, [fp, #0x10]
    // 0x55ba04: StoreField: r3->field_23 = r1
    //     0x55ba04: stur            w1, [x3, #0x23]
    // 0x55ba08: cmp             w0, NULL
    // 0x55ba0c: b.ne            #0x55ba20
    // 0x55ba10: r1 = Function '<anonymous closure>':.
    //     0x55ba10: add             x1, PP, #0x14, lsl #12  ; [pp+0x14748] AnonymousClosure: (0x55bb88), in [package:dio/src/options.dart] _RequestConfig::_RequestConfig (0x55b800)
    //     0x55ba14: ldr             x1, [x1, #0x748]
    // 0x55ba18: r2 = Null
    //     0x55ba18: mov             x2, NULL
    // 0x55ba1c: r0 = AllocateClosure()
    //     0x55ba1c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x55ba20: ldr             x1, [fp, #0x78]
    // 0x55ba24: ldr             x2, [fp, #0x20]
    // 0x55ba28: StoreField: r1->field_1f = r0
    //     0x55ba28: stur            w0, [x1, #0x1f]
    //     0x55ba2c: ldurb           w16, [x1, #-1]
    //     0x55ba30: ldurb           w17, [x0, #-1]
    //     0x55ba34: and             x16, x17, x16, lsr #2
    //     0x55ba38: tst             x16, HEAP, lsr #32
    //     0x55ba3c: b.eq            #0x55ba44
    //     0x55ba40: bl              #0xd6826c
    // 0x55ba44: cmp             w2, NULL
    // 0x55ba48: b.ne            #0x55ba58
    // 0x55ba4c: r0 = Instance_ResponseType
    //     0x55ba4c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12e08] Obj!ResponseType@b66531
    //     0x55ba50: ldr             x0, [x0, #0xe08]
    // 0x55ba54: b               #0x55ba5c
    // 0x55ba58: mov             x0, x2
    // 0x55ba5c: ldur            x2, [fp, #-8]
    // 0x55ba60: StoreField: r1->field_1b = r0
    //     0x55ba60: stur            w0, [x1, #0x1b]
    //     0x55ba64: ldurb           w16, [x1, #-1]
    //     0x55ba68: ldurb           w17, [x0, #-1]
    //     0x55ba6c: and             x16, x17, x16, lsr #2
    //     0x55ba70: tst             x16, HEAP, lsr #32
    //     0x55ba74: b.eq            #0x55ba7c
    //     0x55ba78: bl              #0xd6826c
    // 0x55ba7c: tbz             w2, #4, #0x55ba90
    // 0x55ba80: ldr             x16, [fp, #0x70]
    // 0x55ba84: stp             x16, x1, [SP, #-0x10]!
    // 0x55ba88: r0 = contentType=()
    //     0x55ba88: bl              #0x527f98  ; [package:dio/src/options.dart] _RequestConfig::contentType=
    // 0x55ba8c: add             SP, SP, #0x10
    // 0x55ba90: r0 = Null
    //     0x55ba90: mov             x0, NULL
    // 0x55ba94: LeaveFrame
    //     0x55ba94: mov             SP, fp
    //     0x55ba98: ldp             fp, lr, [SP], #0x10
    // 0x55ba9c: ret
    //     0x55ba9c: ret             
    // 0x55baa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55baa0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55baa4: b               #0x55b81c
    // 0x55baa8: r9 = _headers
    //     0x55baa8: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x55baac: ldr             x9, [x9, #0xee0]
    // 0x55bab0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55bab0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ headers=(/* No info */) {
    // ** addr: 0x55bab4, size: 0xd4
    // 0x55bab4: EnterFrame
    //     0x55bab4: stp             fp, lr, [SP, #-0x10]!
    //     0x55bab8: mov             fp, SP
    // 0x55babc: CheckStackOverflow
    //     0x55babc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55bac0: cmp             SP, x16
    //     0x55bac4: b.ls            #0x55bb80
    // 0x55bac8: ldr             x16, [fp, #0x10]
    // 0x55bacc: stp             x16, NULL, [SP, #-0x10]!
    // 0x55bad0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x55bad0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x55bad4: r0 = caseInsensitiveKeyMap()
    //     0x55bad4: bl              #0x529878  ; [package:dio/src/utils.dart] ::caseInsensitiveKeyMap
    // 0x55bad8: add             SP, SP, #0x10
    // 0x55badc: mov             x2, x0
    // 0x55bae0: ldr             x1, [fp, #0x18]
    // 0x55bae4: StoreField: r1->field_b = r0
    //     0x55bae4: stur            w0, [x1, #0xb]
    //     0x55bae8: tbz             w0, #0, #0x55bb04
    //     0x55baec: ldurb           w16, [x1, #-1]
    //     0x55baf0: ldurb           w17, [x0, #-1]
    //     0x55baf4: and             x16, x17, x16, lsr #2
    //     0x55baf8: tst             x16, HEAP, lsr #32
    //     0x55bafc: b.eq            #0x55bb04
    //     0x55bb00: bl              #0xd6826c
    // 0x55bb04: r0 = LoadClassIdInstr(r2)
    //     0x55bb04: ldur            x0, [x2, #-1]
    //     0x55bb08: ubfx            x0, x0, #0xc, #0x14
    // 0x55bb0c: r16 = "content-type"
    //     0x55bb0c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x55bb10: ldr             x16, [x16, #0xed8]
    // 0x55bb14: stp             x16, x2, [SP, #-0x10]!
    // 0x55bb18: r0 = GDT[cid_x0 + 0x579]()
    //     0x55bb18: add             lr, x0, #0x579
    //     0x55bb1c: ldr             lr, [x21, lr, lsl #3]
    //     0x55bb20: blr             lr
    // 0x55bb24: add             SP, SP, #0x10
    // 0x55bb28: tbz             w0, #4, #0x55bb70
    // 0x55bb2c: ldr             x0, [fp, #0x18]
    // 0x55bb30: LoadField: r1 = r0->field_17
    //     0x55bb30: ldur            w1, [x0, #0x17]
    // 0x55bb34: DecompressPointer r1
    //     0x55bb34: add             x1, x1, HEAP, lsl #32
    // 0x55bb38: cmp             w1, NULL
    // 0x55bb3c: b.eq            #0x55bb70
    // 0x55bb40: LoadField: r2 = r0->field_b
    //     0x55bb40: ldur            w2, [x0, #0xb]
    // 0x55bb44: DecompressPointer r2
    //     0x55bb44: add             x2, x2, HEAP, lsl #32
    // 0x55bb48: r0 = LoadClassIdInstr(r2)
    //     0x55bb48: ldur            x0, [x2, #-1]
    //     0x55bb4c: ubfx            x0, x0, #0xc, #0x14
    // 0x55bb50: r16 = "content-type"
    //     0x55bb50: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x55bb54: ldr             x16, [x16, #0xed8]
    // 0x55bb58: stp             x16, x2, [SP, #-0x10]!
    // 0x55bb5c: SaveReg r1
    //     0x55bb5c: str             x1, [SP, #-8]!
    // 0x55bb60: r0 = GDT[cid_x0 + 0x35a]()
    //     0x55bb60: add             lr, x0, #0x35a
    //     0x55bb64: ldr             lr, [x21, lr, lsl #3]
    //     0x55bb68: blr             lr
    // 0x55bb6c: add             SP, SP, #0x18
    // 0x55bb70: r0 = Null
    //     0x55bb70: mov             x0, NULL
    // 0x55bb74: LeaveFrame
    //     0x55bb74: mov             SP, fp
    //     0x55bb78: ldp             fp, lr, [SP], #0x10
    // 0x55bb7c: ret
    //     0x55bb7c: ret             
    // 0x55bb80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55bb80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55bb84: b               #0x55bac8
  }
  [closure] bool <anonymous closure>(dynamic, int?) {
    // ** addr: 0x55bb88, size: 0x40
    // 0x55bb88: ldr             x1, [SP]
    // 0x55bb8c: cmp             w1, NULL
    // 0x55bb90: b.eq            #0x55bbc0
    // 0x55bb94: r2 = LoadInt32Instr(r1)
    //     0x55bb94: sbfx            x2, x1, #1, #0x1f
    //     0x55bb98: tbz             w1, #0, #0x55bba0
    //     0x55bb9c: ldur            x2, [x1, #7]
    // 0x55bba0: cmp             x2, #0xc8
    // 0x55bba4: b.lt            #0x55bbc0
    // 0x55bba8: cmp             x2, #0x12c
    // 0x55bbac: r16 = true
    //     0x55bbac: add             x16, NULL, #0x20  ; true
    // 0x55bbb0: r17 = false
    //     0x55bbb0: add             x17, NULL, #0x30  ; false
    // 0x55bbb4: csel            x1, x16, x17, lt
    // 0x55bbb8: mov             x0, x1
    // 0x55bbbc: b               #0x55bbc4
    // 0x55bbc0: r0 = false
    //     0x55bbc0: add             x0, NULL, #0x30  ; false
    // 0x55bbc4: ret
    //     0x55bbc4: ret             
  }
}

// class id: 4531, size: 0x50, field offset: 0x44
//   transformed mixin,
abstract class _BaseOptions&_RequestConfig&OptionsMixin extends _RequestConfig
     with OptionsMixin {

  late String baseUrl; // offset: 0x44
  late Map<String, dynamic> queryParameters; // offset: 0x48

  set _ connectTimeout=(/* No info */) {
    // ** addr: 0x55b700, size: 0x6c
    // 0x55b700: EnterFrame
    //     0x55b700: stp             fp, lr, [SP, #-0x10]!
    //     0x55b704: mov             fp, SP
    // 0x55b708: ldr             x0, [fp, #0x10]
    // 0x55b70c: cmp             w0, NULL
    // 0x55b710: b.eq            #0x55b71c
    // 0x55b714: LoadField: r1 = r0->field_7
    //     0x55b714: ldur            x1, [x0, #7]
    // 0x55b718: tbnz            x1, #0x3f, #0x55b74c
    // 0x55b71c: ldr             x1, [fp, #0x18]
    // 0x55b720: StoreField: r1->field_4b = r0
    //     0x55b720: stur            w0, [x1, #0x4b]
    //     0x55b724: ldurb           w16, [x1, #-1]
    //     0x55b728: ldurb           w17, [x0, #-1]
    //     0x55b72c: and             x16, x17, x16, lsr #2
    //     0x55b730: tst             x16, HEAP, lsr #32
    //     0x55b734: b.eq            #0x55b73c
    //     0x55b738: bl              #0xd6826c
    // 0x55b73c: r0 = Null
    //     0x55b73c: mov             x0, NULL
    // 0x55b740: LeaveFrame
    //     0x55b740: mov             SP, fp
    //     0x55b744: ldp             fp, lr, [SP], #0x10
    // 0x55b748: ret
    //     0x55b748: ret             
    // 0x55b74c: r0 = StateError()
    //     0x55b74c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x55b750: mov             x1, x0
    // 0x55b754: r0 = "connectTimeout should be positive"
    //     0x55b754: add             x0, PP, #0x14, lsl #12  ; [pp+0x14740] "connectTimeout should be positive"
    //     0x55b758: ldr             x0, [x0, #0x740]
    // 0x55b75c: StoreField: r1->field_b = r0
    //     0x55b75c: stur            w0, [x1, #0xb]
    // 0x55b760: mov             x0, x1
    // 0x55b764: r0 = Throw()
    //     0x55b764: bl              #0xd67e38  ; ThrowStub
    // 0x55b768: brk             #0
  }
  _ _BaseOptions&_RequestConfig&OptionsMixin(/* No info */) {
    // ** addr: 0x55b76c, size: 0x94
    // 0x55b76c: EnterFrame
    //     0x55b76c: stp             fp, lr, [SP, #-0x10]!
    //     0x55b770: mov             fp, SP
    // 0x55b774: r0 = Sentinel
    //     0x55b774: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55b778: CheckStackOverflow
    //     0x55b778: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55b77c: cmp             SP, x16
    //     0x55b780: b.ls            #0x55b7f8
    // 0x55b784: ldr             x1, [fp, #0x78]
    // 0x55b788: StoreField: r1->field_43 = r0
    //     0x55b788: stur            w0, [x1, #0x43]
    // 0x55b78c: StoreField: r1->field_47 = r0
    //     0x55b78c: stur            w0, [x1, #0x47]
    // 0x55b790: ldr             x16, [fp, #0x70]
    // 0x55b794: stp             x16, x1, [SP, #-0x10]!
    // 0x55b798: ldr             x16, [fp, #0x68]
    // 0x55b79c: ldr             lr, [fp, #0x60]
    // 0x55b7a0: stp             lr, x16, [SP, #-0x10]!
    // 0x55b7a4: ldr             x16, [fp, #0x58]
    // 0x55b7a8: ldr             lr, [fp, #0x50]
    // 0x55b7ac: stp             lr, x16, [SP, #-0x10]!
    // 0x55b7b0: ldr             x16, [fp, #0x48]
    // 0x55b7b4: ldr             lr, [fp, #0x40]
    // 0x55b7b8: stp             lr, x16, [SP, #-0x10]!
    // 0x55b7bc: ldr             x16, [fp, #0x38]
    // 0x55b7c0: ldr             lr, [fp, #0x30]
    // 0x55b7c4: stp             lr, x16, [SP, #-0x10]!
    // 0x55b7c8: ldr             x16, [fp, #0x28]
    // 0x55b7cc: ldr             lr, [fp, #0x20]
    // 0x55b7d0: stp             lr, x16, [SP, #-0x10]!
    // 0x55b7d4: ldr             x16, [fp, #0x18]
    // 0x55b7d8: ldr             lr, [fp, #0x10]
    // 0x55b7dc: stp             lr, x16, [SP, #-0x10]!
    // 0x55b7e0: r0 = _RequestConfig()
    //     0x55b7e0: bl              #0x55b800  ; [package:dio/src/options.dart] _RequestConfig::_RequestConfig
    // 0x55b7e4: add             SP, SP, #0x70
    // 0x55b7e8: r0 = Null
    //     0x55b7e8: mov             x0, NULL
    // 0x55b7ec: LeaveFrame
    //     0x55b7ec: mov             SP, fp
    //     0x55b7f0: ldp             fp, lr, [SP], #0x10
    // 0x55b7f4: ret
    //     0x55b7f4: ret             
    // 0x55b7f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55b7f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55b7fc: b               #0x55b784
  }
}

// class id: 4532, size: 0x68, field offset: 0x50
class RequestOptions extends _BaseOptions&_RequestConfig&OptionsMixin {

  get _ uri(/* No info */) {
    // ** addr: 0x55382c, size: 0x2c0
    // 0x55382c: EnterFrame
    //     0x55382c: stp             fp, lr, [SP, #-0x10]!
    //     0x553830: mov             fp, SP
    // 0x553834: AllocStack(0x30)
    //     0x553834: sub             SP, SP, #0x30
    // 0x553838: CheckStackOverflow
    //     0x553838: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55383c: cmp             SP, x16
    //     0x553840: b.ls            #0x553ab8
    // 0x553844: ldr             x0, [fp, #0x10]
    // 0x553848: LoadField: r1 = r0->field_57
    //     0x553848: ldur            w1, [x0, #0x57]
    // 0x55384c: DecompressPointer r1
    //     0x55384c: add             x1, x1, HEAP, lsl #32
    // 0x553850: stur            x1, [fp, #-8]
    // 0x553854: r16 = "https\?:"
    //     0x553854: add             x16, PP, #0x14, lsl #12  ; [pp+0x142d0] "https\?:"
    //     0x553858: ldr             x16, [x16, #0x2d0]
    // 0x55385c: stp             x16, NULL, [SP, #-0x10]!
    // 0x553860: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x553860: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x553864: r0 = RegExp()
    //     0x553864: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0x553868: add             SP, SP, #0x10
    // 0x55386c: ldur            x16, [fp, #-8]
    // 0x553870: stp             x0, x16, [SP, #-0x10]!
    // 0x553874: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x553874: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x553878: r0 = startsWith()
    //     0x553878: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x55387c: add             SP, SP, #0x10
    // 0x553880: tbz             w0, #4, #0x5539c4
    // 0x553884: ldr             x0, [fp, #0x10]
    // 0x553888: LoadField: r1 = r0->field_43
    //     0x553888: ldur            w1, [x0, #0x43]
    // 0x55388c: DecompressPointer r1
    //     0x55388c: add             x1, x1, HEAP, lsl #32
    // 0x553890: r16 = Sentinel
    //     0x553890: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x553894: cmp             w1, w16
    // 0x553898: b.eq            #0x553ac0
    // 0x55389c: r16 = ""
    //     0x55389c: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x5538a0: ldur            lr, [fp, #-8]
    // 0x5538a4: stp             lr, x16, [SP, #-0x10]!
    // 0x5538a8: r0 = +()
    //     0x5538a8: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x5538ac: add             SP, SP, #0x10
    // 0x5538b0: mov             x1, x0
    // 0x5538b4: stur            x1, [fp, #-0x10]
    // 0x5538b8: r0 = LoadClassIdInstr(r1)
    //     0x5538b8: ldur            x0, [x1, #-1]
    //     0x5538bc: ubfx            x0, x0, #0xc, #0x14
    // 0x5538c0: r16 = ":/"
    //     0x5538c0: add             x16, PP, #0x14, lsl #12  ; [pp+0x142d8] ":/"
    //     0x5538c4: ldr             x16, [x16, #0x2d8]
    // 0x5538c8: stp             x16, x1, [SP, #-0x10]!
    // 0x5538cc: r0 = GDT[cid_x0 + -0xff8]()
    //     0x5538cc: sub             lr, x0, #0xff8
    //     0x5538d0: ldr             lr, [x21, lr, lsl #3]
    //     0x5538d4: blr             lr
    // 0x5538d8: add             SP, SP, #0x10
    // 0x5538dc: mov             x2, x0
    // 0x5538e0: LoadField: r0 = r2->field_b
    //     0x5538e0: ldur            w0, [x2, #0xb]
    // 0x5538e4: DecompressPointer r0
    //     0x5538e4: add             x0, x0, HEAP, lsl #32
    // 0x5538e8: cmp             w0, #4
    // 0x5538ec: b.ne            #0x5539b8
    // 0x5538f0: r3 = LoadInt32Instr(r0)
    //     0x5538f0: sbfx            x3, x0, #1, #0x1f
    // 0x5538f4: mov             x0, x3
    // 0x5538f8: stur            x3, [fp, #-0x28]
    // 0x5538fc: r1 = 0
    //     0x5538fc: mov             x1, #0
    // 0x553900: cmp             x1, x0
    // 0x553904: b.hs            #0x553acc
    // 0x553908: LoadField: r0 = r2->field_f
    //     0x553908: ldur            w0, [x2, #0xf]
    // 0x55390c: DecompressPointer r0
    //     0x55390c: add             x0, x0, HEAP, lsl #32
    // 0x553910: stur            x0, [fp, #-0x20]
    // 0x553914: LoadField: r4 = r0->field_f
    //     0x553914: ldur            w4, [x0, #0xf]
    // 0x553918: DecompressPointer r4
    //     0x553918: add             x4, x4, HEAP, lsl #32
    // 0x55391c: stur            x4, [fp, #-0x18]
    // 0x553920: r1 = Null
    //     0x553920: mov             x1, NULL
    // 0x553924: r2 = 6
    //     0x553924: mov             x2, #6
    // 0x553928: r0 = AllocateArray()
    //     0x553928: bl              #0xd6987c  ; AllocateArrayStub
    // 0x55392c: mov             x2, x0
    // 0x553930: ldur            x0, [fp, #-0x18]
    // 0x553934: stur            x2, [fp, #-0x30]
    // 0x553938: StoreField: r2->field_f = r0
    //     0x553938: stur            w0, [x2, #0xf]
    // 0x55393c: r17 = ":/"
    //     0x55393c: add             x17, PP, #0x14, lsl #12  ; [pp+0x142d8] ":/"
    //     0x553940: ldr             x17, [x17, #0x2d8]
    // 0x553944: StoreField: r2->field_13 = r17
    //     0x553944: stur            w17, [x2, #0x13]
    // 0x553948: ldur            x0, [fp, #-0x28]
    // 0x55394c: r1 = 1
    //     0x55394c: mov             x1, #1
    // 0x553950: cmp             x1, x0
    // 0x553954: b.hs            #0x553ad0
    // 0x553958: ldur            x0, [fp, #-0x20]
    // 0x55395c: LoadField: r1 = r0->field_13
    //     0x55395c: ldur            w1, [x0, #0x13]
    // 0x553960: DecompressPointer r1
    //     0x553960: add             x1, x1, HEAP, lsl #32
    // 0x553964: r16 = "//"
    //     0x553964: ldr             x16, [PP, #0x778]  ; [pp+0x778] "//"
    // 0x553968: stp             x16, x1, [SP, #-0x10]!
    // 0x55396c: r16 = "/"
    //     0x55396c: ldr             x16, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x553970: SaveReg r16
    //     0x553970: str             x16, [SP, #-8]!
    // 0x553974: r0 = replaceAll()
    //     0x553974: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0x553978: add             SP, SP, #0x18
    // 0x55397c: ldur            x1, [fp, #-0x30]
    // 0x553980: ArrayStore: r1[2] = r0  ; List_4
    //     0x553980: add             x25, x1, #0x17
    //     0x553984: str             w0, [x25]
    //     0x553988: tbz             w0, #0, #0x5539a4
    //     0x55398c: ldurb           w16, [x1, #-1]
    //     0x553990: ldurb           w17, [x0, #-1]
    //     0x553994: and             x16, x17, x16, lsr #2
    //     0x553998: tst             x16, HEAP, lsr #32
    //     0x55399c: b.eq            #0x5539a4
    //     0x5539a0: bl              #0xd67e5c
    // 0x5539a4: ldur            x16, [fp, #-0x30]
    // 0x5539a8: SaveReg r16
    //     0x5539a8: str             x16, [SP, #-8]!
    // 0x5539ac: r0 = _interpolate()
    //     0x5539ac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x5539b0: add             SP, SP, #8
    // 0x5539b4: b               #0x5539bc
    // 0x5539b8: ldur            x0, [fp, #-0x10]
    // 0x5539bc: mov             x1, x0
    // 0x5539c0: b               #0x5539c8
    // 0x5539c4: ldur            x1, [fp, #-8]
    // 0x5539c8: ldr             x0, [fp, #0x10]
    // 0x5539cc: stur            x1, [fp, #-8]
    // 0x5539d0: LoadField: r2 = r0->field_47
    //     0x5539d0: ldur            w2, [x0, #0x47]
    // 0x5539d4: DecompressPointer r2
    //     0x5539d4: add             x2, x2, HEAP, lsl #32
    // 0x5539d8: r16 = Sentinel
    //     0x5539d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5539dc: cmp             w2, w16
    // 0x5539e0: b.eq            #0x553ad4
    // 0x5539e4: LoadField: r3 = r0->field_3f
    //     0x5539e4: ldur            w3, [x0, #0x3f]
    // 0x5539e8: DecompressPointer r3
    //     0x5539e8: add             x3, x3, HEAP, lsl #32
    // 0x5539ec: r16 = Sentinel
    //     0x5539ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5539f0: cmp             w3, w16
    // 0x5539f4: b.eq            #0x553ae0
    // 0x5539f8: SaveReg r2
    //     0x5539f8: str             x2, [SP, #-8]!
    // 0x5539fc: r0 = urlEncodeQueryMap()
    //     0x5539fc: bl              #0x553aec  ; [package:dio/src/transformer.dart] Transformer::urlEncodeQueryMap
    // 0x553a00: add             SP, SP, #8
    // 0x553a04: mov             x1, x0
    // 0x553a08: stur            x1, [fp, #-0x10]
    // 0x553a0c: LoadField: r0 = r1->field_7
    //     0x553a0c: ldur            w0, [x1, #7]
    // 0x553a10: DecompressPointer r0
    //     0x553a10: add             x0, x0, HEAP, lsl #32
    // 0x553a14: cbz             w0, #0x553a78
    // 0x553a18: ldur            x2, [fp, #-8]
    // 0x553a1c: r0 = LoadClassIdInstr(r2)
    //     0x553a1c: ldur            x0, [x2, #-1]
    //     0x553a20: ubfx            x0, x0, #0xc, #0x14
    // 0x553a24: r16 = "\?"
    //     0x553a24: ldr             x16, [PP, #0x1550]  ; [pp+0x1550] "\?"
    // 0x553a28: stp             x16, x2, [SP, #-0x10]!
    // 0x553a2c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x553a2c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x553a30: r0 = GDT[cid_x0 + -0xffc]()
    //     0x553a30: sub             lr, x0, #0xffc
    //     0x553a34: ldr             lr, [x21, lr, lsl #3]
    //     0x553a38: blr             lr
    // 0x553a3c: add             SP, SP, #0x10
    // 0x553a40: tbnz            w0, #4, #0x553a50
    // 0x553a44: r0 = "&"
    //     0x553a44: add             x0, PP, #0xa, lsl #12  ; [pp+0xaac0] "&"
    //     0x553a48: ldr             x0, [x0, #0xac0]
    // 0x553a4c: b               #0x553a54
    // 0x553a50: r0 = "\?"
    //     0x553a50: ldr             x0, [PP, #0x1550]  ; [pp+0x1550] "\?"
    // 0x553a54: ldur            x16, [fp, #-0x10]
    // 0x553a58: stp             x16, x0, [SP, #-0x10]!
    // 0x553a5c: r0 = +()
    //     0x553a5c: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x553a60: add             SP, SP, #0x10
    // 0x553a64: ldur            x16, [fp, #-8]
    // 0x553a68: stp             x0, x16, [SP, #-0x10]!
    // 0x553a6c: r0 = +()
    //     0x553a6c: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x553a70: add             SP, SP, #0x10
    // 0x553a74: b               #0x553a7c
    // 0x553a78: ldur            x0, [fp, #-8]
    // 0x553a7c: SaveReg r0
    //     0x553a7c: str             x0, [SP, #-8]!
    // 0x553a80: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x553a80: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x553a84: r0 = parse()
    //     0x553a84: bl              #0x4da468  ; [dart:core] Uri::parse
    // 0x553a88: add             SP, SP, #8
    // 0x553a8c: r1 = LoadClassIdInstr(r0)
    //     0x553a8c: ldur            x1, [x0, #-1]
    //     0x553a90: ubfx            x1, x1, #0xc, #0x14
    // 0x553a94: SaveReg r0
    //     0x553a94: str             x0, [SP, #-8]!
    // 0x553a98: mov             x0, x1
    // 0x553a9c: r0 = GDT[cid_x0 + -0x4e6]()
    //     0x553a9c: sub             lr, x0, #0x4e6
    //     0x553aa0: ldr             lr, [x21, lr, lsl #3]
    //     0x553aa4: blr             lr
    // 0x553aa8: add             SP, SP, #8
    // 0x553aac: LeaveFrame
    //     0x553aac: mov             SP, fp
    //     0x553ab0: ldp             fp, lr, [SP], #0x10
    // 0x553ab4: ret
    //     0x553ab4: ret             
    // 0x553ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x553ab8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x553abc: b               #0x553844
    // 0x553ac0: r9 = baseUrl
    //     0x553ac0: add             x9, PP, #0x14, lsl #12  ; [pp+0x142e0] Field <_BaseOptions&_RequestConfig&OptionsMixin@361184022.baseUrl>: late (offset: 0x44)
    //     0x553ac4: ldr             x9, [x9, #0x2e0]
    // 0x553ac8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x553ac8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x553acc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x553acc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x553ad0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x553ad0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x553ad4: r9 = queryParameters
    //     0x553ad4: add             x9, PP, #0x14, lsl #12  ; [pp+0x142e8] Field <_BaseOptions&_RequestConfig&OptionsMixin@361184022.queryParameters>: late (offset: 0x48)
    //     0x553ad8: ldr             x9, [x9, #0x2e8]
    // 0x553adc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x553adc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x553ae0: r9 = listFormat
    //     0x553ae0: add             x9, PP, #0x14, lsl #12  ; [pp+0x142f0] Field <_RequestConfig@361184022.listFormat>: late (offset: 0x40)
    //     0x553ae4: ldr             x9, [x9, #0x2f0]
    // 0x553ae8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x553ae8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ RequestOptions(/* No info */) {
    // ** addr: 0x55ae64, size: 0x89c
    // 0x55ae64: EnterFrame
    //     0x55ae64: stp             fp, lr, [SP, #-0x10]!
    //     0x55ae68: mov             fp, SP
    // 0x55ae6c: AllocStack(0x40)
    //     0x55ae6c: sub             SP, SP, #0x40
    // 0x55ae70: SetupParameters(RequestOptions this /* r3, fp-0x40 */, {dynamic baseUrl = Null /* fp-0x8 */, dynamic cancelToken = Null /* r5 */, dynamic connectTimeout = Null /* fp-0x18 */, dynamic contentType = Null /* r7 */, dynamic data = Null /* r8 */, dynamic extra = Null /* r9 */, dynamic followRedirects = Null /* r10 */, dynamic headers = Null /* r11 */, dynamic listFormat = Null /* r12 */, dynamic maxRedirects = Null /* r13 */, dynamic method = Null /* r14 */, dynamic path = "" /* r19 */, dynamic persistentConnection = Null /* r20 */, dynamic queryParameters = Null /* fp-0x10 */, dynamic receiveDataWhenStatusError = Null /* r4 */, dynamic receiveTimeout = Null /* fp-0x20 */, dynamic responseType = Null /* fp-0x28 */, dynamic sendTimeout = Null /* fp-0x30 */, dynamic sourceStackTrace = Null /* r6, fp-0x38 */, dynamic validateStatus = Null /* r1 */})
    //     0x55ae70: mov             x0, x4
    //     0x55ae74: ldur            w1, [x0, #0x13]
    //     0x55ae78: add             x1, x1, HEAP, lsl #32
    //     0x55ae7c: sub             x2, x1, #2
    //     0x55ae80: add             x3, fp, w2, sxtw #2
    //     0x55ae84: ldr             x3, [x3, #0x10]
    //     0x55ae88: stur            x3, [fp, #-0x40]
    //     0x55ae8c: ldur            w2, [x0, #0x1f]
    //     0x55ae90: add             x2, x2, HEAP, lsl #32
    //     0x55ae94: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e8] "baseUrl"
    //     0x55ae98: ldr             x16, [x16, #0x6e8]
    //     0x55ae9c: cmp             w2, w16
    //     0x55aea0: b.ne            #0x55aec4
    //     0x55aea4: ldur            w2, [x0, #0x23]
    //     0x55aea8: add             x2, x2, HEAP, lsl #32
    //     0x55aeac: sub             w4, w1, w2
    //     0x55aeb0: add             x2, fp, w4, sxtw #2
    //     0x55aeb4: ldr             x2, [x2, #8]
    //     0x55aeb8: mov             x4, x2
    //     0x55aebc: mov             x2, #1
    //     0x55aec0: b               #0x55aecc
    //     0x55aec4: mov             x4, NULL
    //     0x55aec8: mov             x2, #0
    //     0x55aecc: stur            x4, [fp, #-8]
    //     0x55aed0: lsl             x5, x2, #1
    //     0x55aed4: lsl             w6, w5, #1
    //     0x55aed8: add             w7, w6, #8
    //     0x55aedc: add             x16, x0, w7, sxtw #1
    //     0x55aee0: ldur            w8, [x16, #0xf]
    //     0x55aee4: add             x8, x8, HEAP, lsl #32
    //     0x55aee8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12c50] "cancelToken"
    //     0x55aeec: ldr             x16, [x16, #0xc50]
    //     0x55aef0: cmp             w8, w16
    //     0x55aef4: b.ne            #0x55af28
    //     0x55aef8: add             w2, w6, #0xa
    //     0x55aefc: add             x16, x0, w2, sxtw #1
    //     0x55af00: ldur            w6, [x16, #0xf]
    //     0x55af04: add             x6, x6, HEAP, lsl #32
    //     0x55af08: sub             w2, w1, w6
    //     0x55af0c: add             x6, fp, w2, sxtw #2
    //     0x55af10: ldr             x6, [x6, #8]
    //     0x55af14: add             w2, w5, #2
    //     0x55af18: sbfx            x5, x2, #1, #0x1f
    //     0x55af1c: mov             x2, x5
    //     0x55af20: mov             x5, x6
    //     0x55af24: b               #0x55af2c
    //     0x55af28: mov             x5, NULL
    //     0x55af2c: lsl             x6, x2, #1
    //     0x55af30: lsl             w7, w6, #1
    //     0x55af34: add             w8, w7, #8
    //     0x55af38: add             x16, x0, w8, sxtw #1
    //     0x55af3c: ldur            w9, [x16, #0xf]
    //     0x55af40: add             x9, x9, HEAP, lsl #32
    //     0x55af44: add             x16, PP, #0x14, lsl #12  ; [pp+0x146f0] "connectTimeout"
    //     0x55af48: ldr             x16, [x16, #0x6f0]
    //     0x55af4c: cmp             w9, w16
    //     0x55af50: b.ne            #0x55af84
    //     0x55af54: add             w2, w7, #0xa
    //     0x55af58: add             x16, x0, w2, sxtw #1
    //     0x55af5c: ldur            w7, [x16, #0xf]
    //     0x55af60: add             x7, x7, HEAP, lsl #32
    //     0x55af64: sub             w2, w1, w7
    //     0x55af68: add             x7, fp, w2, sxtw #2
    //     0x55af6c: ldr             x7, [x7, #8]
    //     0x55af70: add             w2, w6, #2
    //     0x55af74: sbfx            x6, x2, #1, #0x1f
    //     0x55af78: mov             x2, x6
    //     0x55af7c: mov             x6, x7
    //     0x55af80: b               #0x55af88
    //     0x55af84: mov             x6, NULL
    //     0x55af88: stur            x6, [fp, #-0x18]
    //     0x55af8c: lsl             x7, x2, #1
    //     0x55af90: lsl             w8, w7, #1
    //     0x55af94: add             w9, w8, #8
    //     0x55af98: add             x16, x0, w9, sxtw #1
    //     0x55af9c: ldur            w10, [x16, #0xf]
    //     0x55afa0: add             x10, x10, HEAP, lsl #32
    //     0x55afa4: add             x16, PP, #0x14, lsl #12  ; [pp+0x146f8] "contentType"
    //     0x55afa8: ldr             x16, [x16, #0x6f8]
    //     0x55afac: cmp             w10, w16
    //     0x55afb0: b.ne            #0x55afe4
    //     0x55afb4: add             w2, w8, #0xa
    //     0x55afb8: add             x16, x0, w2, sxtw #1
    //     0x55afbc: ldur            w8, [x16, #0xf]
    //     0x55afc0: add             x8, x8, HEAP, lsl #32
    //     0x55afc4: sub             w2, w1, w8
    //     0x55afc8: add             x8, fp, w2, sxtw #2
    //     0x55afcc: ldr             x8, [x8, #8]
    //     0x55afd0: add             w2, w7, #2
    //     0x55afd4: sbfx            x7, x2, #1, #0x1f
    //     0x55afd8: mov             x2, x7
    //     0x55afdc: mov             x7, x8
    //     0x55afe0: b               #0x55afe8
    //     0x55afe4: mov             x7, NULL
    //     0x55afe8: lsl             x8, x2, #1
    //     0x55afec: lsl             w9, w8, #1
    //     0x55aff0: add             w10, w9, #8
    //     0x55aff4: add             x16, x0, w10, sxtw #1
    //     0x55aff8: ldur            w11, [x16, #0xf]
    //     0x55affc: add             x11, x11, HEAP, lsl #32
    //     0x55b000: ldr             x16, [PP, #0x1590]  ; [pp+0x1590] "data"
    //     0x55b004: cmp             w11, w16
    //     0x55b008: b.ne            #0x55b03c
    //     0x55b00c: add             w2, w9, #0xa
    //     0x55b010: add             x16, x0, w2, sxtw #1
    //     0x55b014: ldur            w9, [x16, #0xf]
    //     0x55b018: add             x9, x9, HEAP, lsl #32
    //     0x55b01c: sub             w2, w1, w9
    //     0x55b020: add             x9, fp, w2, sxtw #2
    //     0x55b024: ldr             x9, [x9, #8]
    //     0x55b028: add             w2, w8, #2
    //     0x55b02c: sbfx            x8, x2, #1, #0x1f
    //     0x55b030: mov             x2, x8
    //     0x55b034: mov             x8, x9
    //     0x55b038: b               #0x55b040
    //     0x55b03c: mov             x8, NULL
    //     0x55b040: lsl             x9, x2, #1
    //     0x55b044: lsl             w10, w9, #1
    //     0x55b048: add             w11, w10, #8
    //     0x55b04c: add             x16, x0, w11, sxtw #1
    //     0x55b050: ldur            w12, [x16, #0xf]
    //     0x55b054: add             x12, x12, HEAP, lsl #32
    //     0x55b058: add             x16, PP, #0x13, lsl #12  ; [pp+0x13088] "extra"
    //     0x55b05c: ldr             x16, [x16, #0x88]
    //     0x55b060: cmp             w12, w16
    //     0x55b064: b.ne            #0x55b098
    //     0x55b068: add             w2, w10, #0xa
    //     0x55b06c: add             x16, x0, w2, sxtw #1
    //     0x55b070: ldur            w10, [x16, #0xf]
    //     0x55b074: add             x10, x10, HEAP, lsl #32
    //     0x55b078: sub             w2, w1, w10
    //     0x55b07c: add             x10, fp, w2, sxtw #2
    //     0x55b080: ldr             x10, [x10, #8]
    //     0x55b084: add             w2, w9, #2
    //     0x55b088: sbfx            x9, x2, #1, #0x1f
    //     0x55b08c: mov             x2, x9
    //     0x55b090: mov             x9, x10
    //     0x55b094: b               #0x55b09c
    //     0x55b098: mov             x9, NULL
    //     0x55b09c: lsl             x10, x2, #1
    //     0x55b0a0: lsl             w11, w10, #1
    //     0x55b0a4: add             w12, w11, #8
    //     0x55b0a8: add             x16, x0, w12, sxtw #1
    //     0x55b0ac: ldur            w13, [x16, #0xf]
    //     0x55b0b0: add             x13, x13, HEAP, lsl #32
    //     0x55b0b4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13a10] "followRedirects"
    //     0x55b0b8: ldr             x16, [x16, #0xa10]
    //     0x55b0bc: cmp             w13, w16
    //     0x55b0c0: b.ne            #0x55b0f4
    //     0x55b0c4: add             w2, w11, #0xa
    //     0x55b0c8: add             x16, x0, w2, sxtw #1
    //     0x55b0cc: ldur            w11, [x16, #0xf]
    //     0x55b0d0: add             x11, x11, HEAP, lsl #32
    //     0x55b0d4: sub             w2, w1, w11
    //     0x55b0d8: add             x11, fp, w2, sxtw #2
    //     0x55b0dc: ldr             x11, [x11, #8]
    //     0x55b0e0: add             w2, w10, #2
    //     0x55b0e4: sbfx            x10, x2, #1, #0x1f
    //     0x55b0e8: mov             x2, x10
    //     0x55b0ec: mov             x10, x11
    //     0x55b0f0: b               #0x55b0f8
    //     0x55b0f4: mov             x10, NULL
    //     0x55b0f8: lsl             x11, x2, #1
    //     0x55b0fc: lsl             w12, w11, #1
    //     0x55b100: add             w13, w12, #8
    //     0x55b104: add             x16, x0, w13, sxtw #1
    //     0x55b108: ldur            w14, [x16, #0xf]
    //     0x55b10c: add             x14, x14, HEAP, lsl #32
    //     0x55b110: add             x16, PP, #0x13, lsl #12  ; [pp+0x13098] "headers"
    //     0x55b114: ldr             x16, [x16, #0x98]
    //     0x55b118: cmp             w14, w16
    //     0x55b11c: b.ne            #0x55b150
    //     0x55b120: add             w2, w12, #0xa
    //     0x55b124: add             x16, x0, w2, sxtw #1
    //     0x55b128: ldur            w12, [x16, #0xf]
    //     0x55b12c: add             x12, x12, HEAP, lsl #32
    //     0x55b130: sub             w2, w1, w12
    //     0x55b134: add             x12, fp, w2, sxtw #2
    //     0x55b138: ldr             x12, [x12, #8]
    //     0x55b13c: add             w2, w11, #2
    //     0x55b140: sbfx            x11, x2, #1, #0x1f
    //     0x55b144: mov             x2, x11
    //     0x55b148: mov             x11, x12
    //     0x55b14c: b               #0x55b154
    //     0x55b150: mov             x11, NULL
    //     0x55b154: lsl             x12, x2, #1
    //     0x55b158: lsl             w13, w12, #1
    //     0x55b15c: add             w14, w13, #8
    //     0x55b160: add             x16, x0, w14, sxtw #1
    //     0x55b164: ldur            w19, [x16, #0xf]
    //     0x55b168: add             x19, x19, HEAP, lsl #32
    //     0x55b16c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14700] "listFormat"
    //     0x55b170: ldr             x16, [x16, #0x700]
    //     0x55b174: cmp             w19, w16
    //     0x55b178: b.ne            #0x55b1ac
    //     0x55b17c: add             w2, w13, #0xa
    //     0x55b180: add             x16, x0, w2, sxtw #1
    //     0x55b184: ldur            w13, [x16, #0xf]
    //     0x55b188: add             x13, x13, HEAP, lsl #32
    //     0x55b18c: sub             w2, w1, w13
    //     0x55b190: add             x13, fp, w2, sxtw #2
    //     0x55b194: ldr             x13, [x13, #8]
    //     0x55b198: add             w2, w12, #2
    //     0x55b19c: sbfx            x12, x2, #1, #0x1f
    //     0x55b1a0: mov             x2, x12
    //     0x55b1a4: mov             x12, x13
    //     0x55b1a8: b               #0x55b1b0
    //     0x55b1ac: mov             x12, NULL
    //     0x55b1b0: lsl             x13, x2, #1
    //     0x55b1b4: lsl             w14, w13, #1
    //     0x55b1b8: add             w19, w14, #8
    //     0x55b1bc: add             x16, x0, w19, sxtw #1
    //     0x55b1c0: ldur            w20, [x16, #0xf]
    //     0x55b1c4: add             x20, x20, HEAP, lsl #32
    //     0x55b1c8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13a18] "maxRedirects"
    //     0x55b1cc: ldr             x16, [x16, #0xa18]
    //     0x55b1d0: cmp             w20, w16
    //     0x55b1d4: b.ne            #0x55b208
    //     0x55b1d8: add             w2, w14, #0xa
    //     0x55b1dc: add             x16, x0, w2, sxtw #1
    //     0x55b1e0: ldur            w14, [x16, #0xf]
    //     0x55b1e4: add             x14, x14, HEAP, lsl #32
    //     0x55b1e8: sub             w2, w1, w14
    //     0x55b1ec: add             x14, fp, w2, sxtw #2
    //     0x55b1f0: ldr             x14, [x14, #8]
    //     0x55b1f4: add             w2, w13, #2
    //     0x55b1f8: sbfx            x13, x2, #1, #0x1f
    //     0x55b1fc: mov             x2, x13
    //     0x55b200: mov             x13, x14
    //     0x55b204: b               #0x55b20c
    //     0x55b208: mov             x13, NULL
    //     0x55b20c: lsl             x14, x2, #1
    //     0x55b210: lsl             w19, w14, #1
    //     0x55b214: add             w20, w19, #8
    //     0x55b218: add             x16, x0, w20, sxtw #1
    //     0x55b21c: ldur            w23, [x16, #0xf]
    //     0x55b220: add             x23, x23, HEAP, lsl #32
    //     0x55b224: ldr             x16, [PP, #0x2a98]  ; [pp+0x2a98] "method"
    //     0x55b228: cmp             w23, w16
    //     0x55b22c: b.ne            #0x55b260
    //     0x55b230: add             w2, w19, #0xa
    //     0x55b234: add             x16, x0, w2, sxtw #1
    //     0x55b238: ldur            w19, [x16, #0xf]
    //     0x55b23c: add             x19, x19, HEAP, lsl #32
    //     0x55b240: sub             w2, w1, w19
    //     0x55b244: add             x19, fp, w2, sxtw #2
    //     0x55b248: ldr             x19, [x19, #8]
    //     0x55b24c: add             w2, w14, #2
    //     0x55b250: sbfx            x14, x2, #1, #0x1f
    //     0x55b254: mov             x2, x14
    //     0x55b258: mov             x14, x19
    //     0x55b25c: b               #0x55b264
    //     0x55b260: mov             x14, NULL
    //     0x55b264: lsl             x19, x2, #1
    //     0x55b268: lsl             w20, w19, #1
    //     0x55b26c: add             w23, w20, #8
    //     0x55b270: add             x16, x0, w23, sxtw #1
    //     0x55b274: ldur            w24, [x16, #0xf]
    //     0x55b278: add             x24, x24, HEAP, lsl #32
    //     0x55b27c: ldr             x16, [PP, #0x518]  ; [pp+0x518] "path"
    //     0x55b280: cmp             w24, w16
    //     0x55b284: b.ne            #0x55b2b8
    //     0x55b288: add             w2, w20, #0xa
    //     0x55b28c: add             x16, x0, w2, sxtw #1
    //     0x55b290: ldur            w20, [x16, #0xf]
    //     0x55b294: add             x20, x20, HEAP, lsl #32
    //     0x55b298: sub             w2, w1, w20
    //     0x55b29c: add             x20, fp, w2, sxtw #2
    //     0x55b2a0: ldr             x20, [x20, #8]
    //     0x55b2a4: add             w2, w19, #2
    //     0x55b2a8: sbfx            x19, x2, #1, #0x1f
    //     0x55b2ac: mov             x2, x19
    //     0x55b2b0: mov             x19, x20
    //     0x55b2b4: b               #0x55b2bc
    //     0x55b2b8: ldr             x19, [PP, #0x2d8]  ; [pp+0x2d8] ""
    //     0x55b2bc: lsl             x20, x2, #1
    //     0x55b2c0: lsl             w23, w20, #1
    //     0x55b2c4: add             w24, w23, #8
    //     0x55b2c8: add             x16, x0, w24, sxtw #1
    //     0x55b2cc: ldur            w25, [x16, #0xf]
    //     0x55b2d0: add             x25, x25, HEAP, lsl #32
    //     0x55b2d4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13a20] "persistentConnection"
    //     0x55b2d8: ldr             x16, [x16, #0xa20]
    //     0x55b2dc: cmp             w25, w16
    //     0x55b2e0: b.ne            #0x55b314
    //     0x55b2e4: add             w2, w23, #0xa
    //     0x55b2e8: add             x16, x0, w2, sxtw #1
    //     0x55b2ec: ldur            w23, [x16, #0xf]
    //     0x55b2f0: add             x23, x23, HEAP, lsl #32
    //     0x55b2f4: sub             w2, w1, w23
    //     0x55b2f8: add             x23, fp, w2, sxtw #2
    //     0x55b2fc: ldr             x23, [x23, #8]
    //     0x55b300: add             w2, w20, #2
    //     0x55b304: sbfx            x20, x2, #1, #0x1f
    //     0x55b308: mov             x2, x20
    //     0x55b30c: mov             x20, x23
    //     0x55b310: b               #0x55b318
    //     0x55b314: mov             x20, NULL
    //     0x55b318: lsl             x23, x2, #1
    //     0x55b31c: lsl             w24, w23, #1
    //     0x55b320: add             w25, w24, #8
    //     0x55b324: add             x16, x0, w25, sxtw #1
    //     0x55b328: ldur            w4, [x16, #0xf]
    //     0x55b32c: add             x4, x4, HEAP, lsl #32
    //     0x55b330: add             x16, PP, #0x14, lsl #12  ; [pp+0x14708] "queryParameters"
    //     0x55b334: ldr             x16, [x16, #0x708]
    //     0x55b338: cmp             w4, w16
    //     0x55b33c: b.ne            #0x55b36c
    //     0x55b340: add             w2, w24, #0xa
    //     0x55b344: add             x16, x0, w2, sxtw #1
    //     0x55b348: ldur            w4, [x16, #0xf]
    //     0x55b34c: add             x4, x4, HEAP, lsl #32
    //     0x55b350: sub             w2, w1, w4
    //     0x55b354: add             x4, fp, w2, sxtw #2
    //     0x55b358: ldr             x4, [x4, #8]
    //     0x55b35c: add             w2, w23, #2
    //     0x55b360: sbfx            x23, x2, #1, #0x1f
    //     0x55b364: mov             x2, x23
    //     0x55b368: b               #0x55b370
    //     0x55b36c: mov             x4, NULL
    //     0x55b370: stur            x4, [fp, #-0x10]
    //     0x55b374: lsl             x23, x2, #1
    //     0x55b378: lsl             w24, w23, #1
    //     0x55b37c: add             w25, w24, #8
    //     0x55b380: add             x16, x0, w25, sxtw #1
    //     0x55b384: ldur            w4, [x16, #0xf]
    //     0x55b388: add             x4, x4, HEAP, lsl #32
    //     0x55b38c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14710] "receiveDataWhenStatusError"
    //     0x55b390: ldr             x16, [x16, #0x710]
    //     0x55b394: cmp             w4, w16
    //     0x55b398: b.ne            #0x55b3c8
    //     0x55b39c: add             w2, w24, #0xa
    //     0x55b3a0: add             x16, x0, w2, sxtw #1
    //     0x55b3a4: ldur            w4, [x16, #0xf]
    //     0x55b3a8: add             x4, x4, HEAP, lsl #32
    //     0x55b3ac: sub             w2, w1, w4
    //     0x55b3b0: add             x4, fp, w2, sxtw #2
    //     0x55b3b4: ldr             x4, [x4, #8]
    //     0x55b3b8: add             w2, w23, #2
    //     0x55b3bc: sbfx            x23, x2, #1, #0x1f
    //     0x55b3c0: mov             x2, x23
    //     0x55b3c4: b               #0x55b3cc
    //     0x55b3c8: mov             x4, NULL
    //     0x55b3cc: lsl             x23, x2, #1
    //     0x55b3d0: lsl             w24, w23, #1
    //     0x55b3d4: add             w25, w24, #8
    //     0x55b3d8: add             x16, x0, w25, sxtw #1
    //     0x55b3dc: ldur            w6, [x16, #0xf]
    //     0x55b3e0: add             x6, x6, HEAP, lsl #32
    //     0x55b3e4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14718] "receiveTimeout"
    //     0x55b3e8: ldr             x16, [x16, #0x718]
    //     0x55b3ec: cmp             w6, w16
    //     0x55b3f0: b.ne            #0x55b420
    //     0x55b3f4: add             w2, w24, #0xa
    //     0x55b3f8: add             x16, x0, w2, sxtw #1
    //     0x55b3fc: ldur            w6, [x16, #0xf]
    //     0x55b400: add             x6, x6, HEAP, lsl #32
    //     0x55b404: sub             w2, w1, w6
    //     0x55b408: add             x6, fp, w2, sxtw #2
    //     0x55b40c: ldr             x6, [x6, #8]
    //     0x55b410: add             w2, w23, #2
    //     0x55b414: sbfx            x23, x2, #1, #0x1f
    //     0x55b418: mov             x2, x23
    //     0x55b41c: b               #0x55b424
    //     0x55b420: mov             x6, NULL
    //     0x55b424: stur            x6, [fp, #-0x20]
    //     0x55b428: lsl             x23, x2, #1
    //     0x55b42c: lsl             w24, w23, #1
    //     0x55b430: add             w25, w24, #8
    //     0x55b434: add             x16, x0, w25, sxtw #1
    //     0x55b438: ldur            w6, [x16, #0xf]
    //     0x55b43c: add             x6, x6, HEAP, lsl #32
    //     0x55b440: add             x16, PP, #0x14, lsl #12  ; [pp+0x14720] "responseType"
    //     0x55b444: ldr             x16, [x16, #0x720]
    //     0x55b448: cmp             w6, w16
    //     0x55b44c: b.ne            #0x55b47c
    //     0x55b450: add             w2, w24, #0xa
    //     0x55b454: add             x16, x0, w2, sxtw #1
    //     0x55b458: ldur            w6, [x16, #0xf]
    //     0x55b45c: add             x6, x6, HEAP, lsl #32
    //     0x55b460: sub             w2, w1, w6
    //     0x55b464: add             x6, fp, w2, sxtw #2
    //     0x55b468: ldr             x6, [x6, #8]
    //     0x55b46c: add             w2, w23, #2
    //     0x55b470: sbfx            x23, x2, #1, #0x1f
    //     0x55b474: mov             x2, x23
    //     0x55b478: b               #0x55b480
    //     0x55b47c: mov             x6, NULL
    //     0x55b480: stur            x6, [fp, #-0x28]
    //     0x55b484: lsl             x23, x2, #1
    //     0x55b488: lsl             w24, w23, #1
    //     0x55b48c: add             w25, w24, #8
    //     0x55b490: add             x16, x0, w25, sxtw #1
    //     0x55b494: ldur            w6, [x16, #0xf]
    //     0x55b498: add             x6, x6, HEAP, lsl #32
    //     0x55b49c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14728] "sendTimeout"
    //     0x55b4a0: ldr             x16, [x16, #0x728]
    //     0x55b4a4: cmp             w6, w16
    //     0x55b4a8: b.ne            #0x55b4d8
    //     0x55b4ac: add             w2, w24, #0xa
    //     0x55b4b0: add             x16, x0, w2, sxtw #1
    //     0x55b4b4: ldur            w6, [x16, #0xf]
    //     0x55b4b8: add             x6, x6, HEAP, lsl #32
    //     0x55b4bc: sub             w2, w1, w6
    //     0x55b4c0: add             x6, fp, w2, sxtw #2
    //     0x55b4c4: ldr             x6, [x6, #8]
    //     0x55b4c8: add             w2, w23, #2
    //     0x55b4cc: sbfx            x23, x2, #1, #0x1f
    //     0x55b4d0: mov             x2, x23
    //     0x55b4d4: b               #0x55b4dc
    //     0x55b4d8: mov             x6, NULL
    //     0x55b4dc: stur            x6, [fp, #-0x30]
    //     0x55b4e0: lsl             x23, x2, #1
    //     0x55b4e4: lsl             w24, w23, #1
    //     0x55b4e8: add             w25, w24, #8
    //     0x55b4ec: add             x16, x0, w25, sxtw #1
    //     0x55b4f0: ldur            w6, [x16, #0xf]
    //     0x55b4f4: add             x6, x6, HEAP, lsl #32
    //     0x55b4f8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14730] "sourceStackTrace"
    //     0x55b4fc: ldr             x16, [x16, #0x730]
    //     0x55b500: cmp             w6, w16
    //     0x55b504: b.ne            #0x55b534
    //     0x55b508: add             w2, w24, #0xa
    //     0x55b50c: add             x16, x0, w2, sxtw #1
    //     0x55b510: ldur            w6, [x16, #0xf]
    //     0x55b514: add             x6, x6, HEAP, lsl #32
    //     0x55b518: sub             w2, w1, w6
    //     0x55b51c: add             x6, fp, w2, sxtw #2
    //     0x55b520: ldr             x6, [x6, #8]
    //     0x55b524: add             w2, w23, #2
    //     0x55b528: sbfx            x23, x2, #1, #0x1f
    //     0x55b52c: mov             x2, x23
    //     0x55b530: b               #0x55b538
    //     0x55b534: mov             x6, NULL
    //     0x55b538: stur            x6, [fp, #-0x38]
    //     0x55b53c: lsl             x23, x2, #1
    //     0x55b540: lsl             w2, w23, #1
    //     0x55b544: add             w23, w2, #8
    //     0x55b548: add             x16, x0, w23, sxtw #1
    //     0x55b54c: ldur            w24, [x16, #0xf]
    //     0x55b550: add             x24, x24, HEAP, lsl #32
    //     0x55b554: add             x16, PP, #0x14, lsl #12  ; [pp+0x14738] "validateStatus"
    //     0x55b558: ldr             x16, [x16, #0x738]
    //     0x55b55c: cmp             w24, w16
    //     0x55b560: b.ne            #0x55b584
    //     0x55b564: add             w23, w2, #0xa
    //     0x55b568: add             x16, x0, w23, sxtw #1
    //     0x55b56c: ldur            w2, [x16, #0xf]
    //     0x55b570: add             x2, x2, HEAP, lsl #32
    //     0x55b574: sub             w0, w1, w2
    //     0x55b578: add             x1, fp, w0, sxtw #2
    //     0x55b57c: ldr             x1, [x1, #8]
    //     0x55b580: b               #0x55b588
    //     0x55b584: mov             x1, NULL
    // 0x55b588: CheckStackOverflow
    //     0x55b588: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55b58c: cmp             SP, x16
    //     0x55b590: b.ls            #0x55b6f8
    // 0x55b594: mov             x0, x19
    // 0x55b598: StoreField: r3->field_57 = r0
    //     0x55b598: stur            w0, [x3, #0x57]
    //     0x55b59c: ldurb           w16, [x3, #-1]
    //     0x55b5a0: ldurb           w17, [x0, #-1]
    //     0x55b5a4: and             x16, x17, x16, lsr #2
    //     0x55b5a8: tst             x16, HEAP, lsr #32
    //     0x55b5ac: b.eq            #0x55b5b4
    //     0x55b5b0: bl              #0xd682ac
    // 0x55b5b4: mov             x0, x8
    // 0x55b5b8: StoreField: r3->field_53 = r0
    //     0x55b5b8: stur            w0, [x3, #0x53]
    //     0x55b5bc: tbz             w0, #0, #0x55b5d8
    //     0x55b5c0: ldurb           w16, [x3, #-1]
    //     0x55b5c4: ldurb           w17, [x0, #-1]
    //     0x55b5c8: and             x16, x17, x16, lsr #2
    //     0x55b5cc: tst             x16, HEAP, lsr #32
    //     0x55b5d0: b.eq            #0x55b5d8
    //     0x55b5d4: bl              #0xd682ac
    // 0x55b5d8: mov             x0, x5
    // 0x55b5dc: StoreField: r3->field_5b = r0
    //     0x55b5dc: stur            w0, [x3, #0x5b]
    //     0x55b5e0: ldurb           w16, [x3, #-1]
    //     0x55b5e4: ldurb           w17, [x0, #-1]
    //     0x55b5e8: and             x16, x17, x16, lsr #2
    //     0x55b5ec: tst             x16, HEAP, lsr #32
    //     0x55b5f0: b.eq            #0x55b5f8
    //     0x55b5f4: bl              #0xd682ac
    // 0x55b5f8: stp             x7, x3, [SP, #-0x10]!
    // 0x55b5fc: stp             x10, x9, [SP, #-0x10]!
    // 0x55b600: stp             x12, x11, [SP, #-0x10]!
    // 0x55b604: stp             x14, x13, [SP, #-0x10]!
    // 0x55b608: stp             x4, x20, [SP, #-0x10]!
    // 0x55b60c: ldur            x16, [fp, #-0x20]
    // 0x55b610: ldur            lr, [fp, #-0x28]
    // 0x55b614: stp             lr, x16, [SP, #-0x10]!
    // 0x55b618: ldur            x16, [fp, #-0x30]
    // 0x55b61c: stp             x1, x16, [SP, #-0x10]!
    // 0x55b620: r0 = _BaseOptions&_RequestConfig&OptionsMixin()
    //     0x55b620: bl              #0x55b76c  ; [package:dio/src/options.dart] _BaseOptions&_RequestConfig&OptionsMixin::_BaseOptions&_RequestConfig&OptionsMixin
    // 0x55b624: add             SP, SP, #0x70
    // 0x55b628: ldur            x0, [fp, #-0x38]
    // 0x55b62c: cmp             w0, NULL
    // 0x55b630: b.ne            #0x55b638
    // 0x55b634: r0 = current()
    //     0x55b634: bl              #0x4ff3d0  ; [dart:core] StackTrace::current
    // 0x55b638: ldur            x1, [fp, #-0x40]
    // 0x55b63c: ldur            x2, [fp, #-0x10]
    // 0x55b640: StoreField: r1->field_4f = r0
    //     0x55b640: stur            w0, [x1, #0x4f]
    //     0x55b644: ldurb           w16, [x1, #-1]
    //     0x55b648: ldurb           w17, [x0, #-1]
    //     0x55b64c: and             x16, x17, x16, lsr #2
    //     0x55b650: tst             x16, HEAP, lsr #32
    //     0x55b654: b.eq            #0x55b65c
    //     0x55b658: bl              #0xd6826c
    // 0x55b65c: cmp             w2, NULL
    // 0x55b660: b.ne            #0x55b67c
    // 0x55b664: r16 = <String, dynamic>
    //     0x55b664: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x55b668: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x55b66c: stp             lr, x16, [SP, #-0x10]!
    // 0x55b670: r0 = Map._fromLiteral()
    //     0x55b670: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x55b674: add             SP, SP, #0x10
    // 0x55b678: b               #0x55b680
    // 0x55b67c: mov             x0, x2
    // 0x55b680: ldur            x1, [fp, #-0x40]
    // 0x55b684: ldur            x2, [fp, #-8]
    // 0x55b688: StoreField: r1->field_47 = r0
    //     0x55b688: stur            w0, [x1, #0x47]
    //     0x55b68c: tbz             w0, #0, #0x55b6a8
    //     0x55b690: ldurb           w16, [x1, #-1]
    //     0x55b694: ldurb           w17, [x0, #-1]
    //     0x55b698: and             x16, x17, x16, lsr #2
    //     0x55b69c: tst             x16, HEAP, lsr #32
    //     0x55b6a0: b.eq            #0x55b6a8
    //     0x55b6a4: bl              #0xd6826c
    // 0x55b6a8: cmp             w2, NULL
    // 0x55b6ac: b.ne            #0x55b6b8
    // 0x55b6b0: r0 = ""
    //     0x55b6b0: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x55b6b4: b               #0x55b6bc
    // 0x55b6b8: mov             x0, x2
    // 0x55b6bc: StoreField: r1->field_43 = r0
    //     0x55b6bc: stur            w0, [x1, #0x43]
    //     0x55b6c0: ldurb           w16, [x1, #-1]
    //     0x55b6c4: ldurb           w17, [x0, #-1]
    //     0x55b6c8: and             x16, x17, x16, lsr #2
    //     0x55b6cc: tst             x16, HEAP, lsr #32
    //     0x55b6d0: b.eq            #0x55b6d8
    //     0x55b6d4: bl              #0xd6826c
    // 0x55b6d8: ldur            x16, [fp, #-0x18]
    // 0x55b6dc: stp             x16, x1, [SP, #-0x10]!
    // 0x55b6e0: r0 = connectTimeout=()
    //     0x55b6e0: bl              #0x55b700  ; [package:dio/src/options.dart] _BaseOptions&_RequestConfig&OptionsMixin::connectTimeout=
    // 0x55b6e4: add             SP, SP, #0x10
    // 0x55b6e8: r0 = Null
    //     0x55b6e8: mov             x0, NULL
    // 0x55b6ec: LeaveFrame
    //     0x55b6ec: mov             SP, fp
    //     0x55b6f0: ldp             fp, lr, [SP], #0x10
    // 0x55b6f4: ret
    //     0x55b6f4: ret             
    // 0x55b6f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55b6f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55b6fc: b               #0x55b594
  }
}

// class id: 4533, size: 0x50, field offset: 0x50
class BaseOptions extends _BaseOptions&_RequestConfig&OptionsMixin {

  _ BaseOptions(/* No info */) {
    // ** addr: 0x55e454, size: 0x2c8
    // 0x55e454: EnterFrame
    //     0x55e454: stp             fp, lr, [SP, #-0x10]!
    //     0x55e458: mov             fp, SP
    // 0x55e45c: AllocStack(0x10)
    //     0x55e45c: sub             SP, SP, #0x10
    // 0x55e460: SetupParameters(BaseOptions this /* r3, fp-0x10 */, {dynamic connectTimeout = Null /* r4, fp-0x8 */, dynamic contentType = Null /* r5 */, dynamic receiveTimeout = Null /* r6 */, dynamic responseType = Instance_ResponseType /* r7 */, dynamic sendTimeout = Null /* r8 */, dynamic validateStatus = Null /* r0 */})
    //     0x55e460: mov             x0, x4
    //     0x55e464: ldur            w1, [x0, #0x13]
    //     0x55e468: add             x1, x1, HEAP, lsl #32
    //     0x55e46c: sub             x2, x1, #2
    //     0x55e470: add             x3, fp, w2, sxtw #2
    //     0x55e474: ldr             x3, [x3, #0x10]
    //     0x55e478: stur            x3, [fp, #-0x10]
    //     0x55e47c: ldur            w2, [x0, #0x1f]
    //     0x55e480: add             x2, x2, HEAP, lsl #32
    //     0x55e484: add             x16, PP, #0x14, lsl #12  ; [pp+0x146f0] "connectTimeout"
    //     0x55e488: ldr             x16, [x16, #0x6f0]
    //     0x55e48c: cmp             w2, w16
    //     0x55e490: b.ne            #0x55e4b4
    //     0x55e494: ldur            w2, [x0, #0x23]
    //     0x55e498: add             x2, x2, HEAP, lsl #32
    //     0x55e49c: sub             w4, w1, w2
    //     0x55e4a0: add             x2, fp, w4, sxtw #2
    //     0x55e4a4: ldr             x2, [x2, #8]
    //     0x55e4a8: mov             x4, x2
    //     0x55e4ac: mov             x2, #1
    //     0x55e4b0: b               #0x55e4bc
    //     0x55e4b4: mov             x4, NULL
    //     0x55e4b8: mov             x2, #0
    //     0x55e4bc: stur            x4, [fp, #-8]
    //     0x55e4c0: lsl             x5, x2, #1
    //     0x55e4c4: lsl             w6, w5, #1
    //     0x55e4c8: add             w7, w6, #8
    //     0x55e4cc: add             x16, x0, w7, sxtw #1
    //     0x55e4d0: ldur            w8, [x16, #0xf]
    //     0x55e4d4: add             x8, x8, HEAP, lsl #32
    //     0x55e4d8: add             x16, PP, #0x14, lsl #12  ; [pp+0x146f8] "contentType"
    //     0x55e4dc: ldr             x16, [x16, #0x6f8]
    //     0x55e4e0: cmp             w8, w16
    //     0x55e4e4: b.ne            #0x55e518
    //     0x55e4e8: add             w2, w6, #0xa
    //     0x55e4ec: add             x16, x0, w2, sxtw #1
    //     0x55e4f0: ldur            w6, [x16, #0xf]
    //     0x55e4f4: add             x6, x6, HEAP, lsl #32
    //     0x55e4f8: sub             w2, w1, w6
    //     0x55e4fc: add             x6, fp, w2, sxtw #2
    //     0x55e500: ldr             x6, [x6, #8]
    //     0x55e504: add             w2, w5, #2
    //     0x55e508: sbfx            x5, x2, #1, #0x1f
    //     0x55e50c: mov             x2, x5
    //     0x55e510: mov             x5, x6
    //     0x55e514: b               #0x55e51c
    //     0x55e518: mov             x5, NULL
    //     0x55e51c: lsl             x6, x2, #1
    //     0x55e520: lsl             w7, w6, #1
    //     0x55e524: add             w8, w7, #8
    //     0x55e528: add             x16, x0, w8, sxtw #1
    //     0x55e52c: ldur            w9, [x16, #0xf]
    //     0x55e530: add             x9, x9, HEAP, lsl #32
    //     0x55e534: add             x16, PP, #0x14, lsl #12  ; [pp+0x14718] "receiveTimeout"
    //     0x55e538: ldr             x16, [x16, #0x718]
    //     0x55e53c: cmp             w9, w16
    //     0x55e540: b.ne            #0x55e574
    //     0x55e544: add             w2, w7, #0xa
    //     0x55e548: add             x16, x0, w2, sxtw #1
    //     0x55e54c: ldur            w7, [x16, #0xf]
    //     0x55e550: add             x7, x7, HEAP, lsl #32
    //     0x55e554: sub             w2, w1, w7
    //     0x55e558: add             x7, fp, w2, sxtw #2
    //     0x55e55c: ldr             x7, [x7, #8]
    //     0x55e560: add             w2, w6, #2
    //     0x55e564: sbfx            x6, x2, #1, #0x1f
    //     0x55e568: mov             x2, x6
    //     0x55e56c: mov             x6, x7
    //     0x55e570: b               #0x55e578
    //     0x55e574: mov             x6, NULL
    //     0x55e578: lsl             x7, x2, #1
    //     0x55e57c: lsl             w8, w7, #1
    //     0x55e580: add             w9, w8, #8
    //     0x55e584: add             x16, x0, w9, sxtw #1
    //     0x55e588: ldur            w10, [x16, #0xf]
    //     0x55e58c: add             x10, x10, HEAP, lsl #32
    //     0x55e590: add             x16, PP, #0x14, lsl #12  ; [pp+0x14720] "responseType"
    //     0x55e594: ldr             x16, [x16, #0x720]
    //     0x55e598: cmp             w10, w16
    //     0x55e59c: b.ne            #0x55e5d0
    //     0x55e5a0: add             w2, w8, #0xa
    //     0x55e5a4: add             x16, x0, w2, sxtw #1
    //     0x55e5a8: ldur            w8, [x16, #0xf]
    //     0x55e5ac: add             x8, x8, HEAP, lsl #32
    //     0x55e5b0: sub             w2, w1, w8
    //     0x55e5b4: add             x8, fp, w2, sxtw #2
    //     0x55e5b8: ldr             x8, [x8, #8]
    //     0x55e5bc: add             w2, w7, #2
    //     0x55e5c0: sbfx            x7, x2, #1, #0x1f
    //     0x55e5c4: mov             x2, x7
    //     0x55e5c8: mov             x7, x8
    //     0x55e5cc: b               #0x55e5d8
    //     0x55e5d0: add             x7, PP, #0x12, lsl #12  ; [pp+0x12e08] Obj!ResponseType@b66531
    //     0x55e5d4: ldr             x7, [x7, #0xe08]
    //     0x55e5d8: lsl             x8, x2, #1
    //     0x55e5dc: lsl             w9, w8, #1
    //     0x55e5e0: add             w10, w9, #8
    //     0x55e5e4: add             x16, x0, w10, sxtw #1
    //     0x55e5e8: ldur            w11, [x16, #0xf]
    //     0x55e5ec: add             x11, x11, HEAP, lsl #32
    //     0x55e5f0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14728] "sendTimeout"
    //     0x55e5f4: ldr             x16, [x16, #0x728]
    //     0x55e5f8: cmp             w11, w16
    //     0x55e5fc: b.ne            #0x55e630
    //     0x55e600: add             w2, w9, #0xa
    //     0x55e604: add             x16, x0, w2, sxtw #1
    //     0x55e608: ldur            w9, [x16, #0xf]
    //     0x55e60c: add             x9, x9, HEAP, lsl #32
    //     0x55e610: sub             w2, w1, w9
    //     0x55e614: add             x9, fp, w2, sxtw #2
    //     0x55e618: ldr             x9, [x9, #8]
    //     0x55e61c: add             w2, w8, #2
    //     0x55e620: sbfx            x8, x2, #1, #0x1f
    //     0x55e624: mov             x2, x8
    //     0x55e628: mov             x8, x9
    //     0x55e62c: b               #0x55e634
    //     0x55e630: mov             x8, NULL
    //     0x55e634: lsl             x9, x2, #1
    //     0x55e638: lsl             w2, w9, #1
    //     0x55e63c: add             w9, w2, #8
    //     0x55e640: add             x16, x0, w9, sxtw #1
    //     0x55e644: ldur            w10, [x16, #0xf]
    //     0x55e648: add             x10, x10, HEAP, lsl #32
    //     0x55e64c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14738] "validateStatus"
    //     0x55e650: ldr             x16, [x16, #0x738]
    //     0x55e654: cmp             w10, w16
    //     0x55e658: b.ne            #0x55e680
    //     0x55e65c: add             w9, w2, #0xa
    //     0x55e660: add             x16, x0, w9, sxtw #1
    //     0x55e664: ldur            w2, [x16, #0xf]
    //     0x55e668: add             x2, x2, HEAP, lsl #32
    //     0x55e66c: sub             w0, w1, w2
    //     0x55e670: add             x1, fp, w0, sxtw #2
    //     0x55e674: ldr             x1, [x1, #8]
    //     0x55e678: mov             x0, x1
    //     0x55e67c: b               #0x55e684
    //     0x55e680: mov             x0, NULL
    // 0x55e684: CheckStackOverflow
    //     0x55e684: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55e688: cmp             SP, x16
    //     0x55e68c: b.ls            #0x55e714
    // 0x55e690: stp             x5, x3, [SP, #-0x10]!
    // 0x55e694: stp             NULL, NULL, [SP, #-0x10]!
    // 0x55e698: stp             NULL, NULL, [SP, #-0x10]!
    // 0x55e69c: stp             NULL, NULL, [SP, #-0x10]!
    // 0x55e6a0: stp             NULL, NULL, [SP, #-0x10]!
    // 0x55e6a4: stp             x7, x6, [SP, #-0x10]!
    // 0x55e6a8: stp             x0, x8, [SP, #-0x10]!
    // 0x55e6ac: r0 = _BaseOptions&_RequestConfig&OptionsMixin()
    //     0x55e6ac: bl              #0x55b76c  ; [package:dio/src/options.dart] _BaseOptions&_RequestConfig&OptionsMixin::_BaseOptions&_RequestConfig&OptionsMixin
    // 0x55e6b0: add             SP, SP, #0x70
    // 0x55e6b4: r16 = <String, dynamic>
    //     0x55e6b4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x55e6b8: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x55e6bc: stp             lr, x16, [SP, #-0x10]!
    // 0x55e6c0: r0 = Map._fromLiteral()
    //     0x55e6c0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x55e6c4: add             SP, SP, #0x10
    // 0x55e6c8: ldur            x1, [fp, #-0x10]
    // 0x55e6cc: StoreField: r1->field_47 = r0
    //     0x55e6cc: stur            w0, [x1, #0x47]
    //     0x55e6d0: tbz             w0, #0, #0x55e6ec
    //     0x55e6d4: ldurb           w16, [x1, #-1]
    //     0x55e6d8: ldurb           w17, [x0, #-1]
    //     0x55e6dc: and             x16, x17, x16, lsr #2
    //     0x55e6e0: tst             x16, HEAP, lsr #32
    //     0x55e6e4: b.eq            #0x55e6ec
    //     0x55e6e8: bl              #0xd6826c
    // 0x55e6ec: r0 = ""
    //     0x55e6ec: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x55e6f0: StoreField: r1->field_43 = r0
    //     0x55e6f0: stur            w0, [x1, #0x43]
    // 0x55e6f4: ldur            x16, [fp, #-8]
    // 0x55e6f8: stp             x16, x1, [SP, #-0x10]!
    // 0x55e6fc: r0 = connectTimeout=()
    //     0x55e6fc: bl              #0x55b700  ; [package:dio/src/options.dart] _BaseOptions&_RequestConfig&OptionsMixin::connectTimeout=
    // 0x55e700: add             SP, SP, #0x10
    // 0x55e704: r0 = Null
    //     0x55e704: mov             x0, NULL
    // 0x55e708: LeaveFrame
    //     0x55e708: mov             SP, fp
    //     0x55e70c: ldp             fp, lr, [SP], #0x10
    // 0x55e710: ret
    //     0x55e710: ret             
    // 0x55e714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55e714: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55e718: b               #0x55e690
  }
}

// class id: 6006, size: 0x14, field offset: 0x14
enum ListFormat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb155b8, size: 0x5c
    // 0xb155b8: EnterFrame
    //     0xb155b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb155bc: mov             fp, SP
    // 0xb155c0: CheckStackOverflow
    //     0xb155c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb155c4: cmp             SP, x16
    //     0xb155c8: b.ls            #0xb1560c
    // 0xb155cc: r1 = Null
    //     0xb155cc: mov             x1, NULL
    // 0xb155d0: r2 = 4
    //     0xb155d0: mov             x2, #4
    // 0xb155d4: r0 = AllocateArray()
    //     0xb155d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb155d8: r17 = "ListFormat."
    //     0xb155d8: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d590] "ListFormat."
    //     0xb155dc: ldr             x17, [x17, #0x590]
    // 0xb155e0: StoreField: r0->field_f = r17
    //     0xb155e0: stur            w17, [x0, #0xf]
    // 0xb155e4: ldr             x1, [fp, #0x10]
    // 0xb155e8: LoadField: r2 = r1->field_f
    //     0xb155e8: ldur            w2, [x1, #0xf]
    // 0xb155ec: DecompressPointer r2
    //     0xb155ec: add             x2, x2, HEAP, lsl #32
    // 0xb155f0: StoreField: r0->field_13 = r2
    //     0xb155f0: stur            w2, [x0, #0x13]
    // 0xb155f4: SaveReg r0
    //     0xb155f4: str             x0, [SP, #-8]!
    // 0xb155f8: r0 = _interpolate()
    //     0xb155f8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb155fc: add             SP, SP, #8
    // 0xb15600: LeaveFrame
    //     0xb15600: mov             SP, fp
    //     0xb15604: ldp             fp, lr, [SP], #0x10
    // 0xb15608: ret
    //     0xb15608: ret             
    // 0xb1560c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1560c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15610: b               #0xb155cc
  }
}

// class id: 6007, size: 0x14, field offset: 0x14
enum ResponseType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb1555c, size: 0x5c
    // 0xb1555c: EnterFrame
    //     0xb1555c: stp             fp, lr, [SP, #-0x10]!
    //     0xb15560: mov             fp, SP
    // 0xb15564: CheckStackOverflow
    //     0xb15564: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15568: cmp             SP, x16
    //     0xb1556c: b.ls            #0xb155b0
    // 0xb15570: r1 = Null
    //     0xb15570: mov             x1, NULL
    // 0xb15574: r2 = 4
    //     0xb15574: mov             x2, #4
    // 0xb15578: r0 = AllocateArray()
    //     0xb15578: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1557c: r17 = "ResponseType."
    //     0xb1557c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d598] "ResponseType."
    //     0xb15580: ldr             x17, [x17, #0x598]
    // 0xb15584: StoreField: r0->field_f = r17
    //     0xb15584: stur            w17, [x0, #0xf]
    // 0xb15588: ldr             x1, [fp, #0x10]
    // 0xb1558c: LoadField: r2 = r1->field_f
    //     0xb1558c: ldur            w2, [x1, #0xf]
    // 0xb15590: DecompressPointer r2
    //     0xb15590: add             x2, x2, HEAP, lsl #32
    // 0xb15594: StoreField: r0->field_13 = r2
    //     0xb15594: stur            w2, [x0, #0x13]
    // 0xb15598: SaveReg r0
    //     0xb15598: str             x0, [SP, #-8]!
    // 0xb1559c: r0 = _interpolate()
    //     0xb1559c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb155a0: add             SP, SP, #8
    // 0xb155a4: LeaveFrame
    //     0xb155a4: mov             SP, fp
    //     0xb155a8: ldp             fp, lr, [SP], #0x10
    // 0xb155ac: ret
    //     0xb155ac: ret             
    // 0xb155b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb155b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb155b4: b               #0xb15570
  }
}

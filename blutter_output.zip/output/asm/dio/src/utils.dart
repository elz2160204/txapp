// lib: , url: package:dio/src/utils.dart

// class id: 1048902, size: 0x8
class :: {

  static _ caseInsensitiveKeyMap(/* No info */) {
    // ** addr: 0x529878, size: 0x148
    // 0x529878: EnterFrame
    //     0x529878: stp             fp, lr, [SP, #-0x10]!
    //     0x52987c: mov             fp, SP
    // 0x529880: AllocStack(0x20)
    //     0x529880: sub             SP, SP, #0x20
    // 0x529884: SetupParameters([dynamic _ = Null /* r3, fp-0x10 */])
    //     0x529884: mov             x0, x4
    //     0x529888: ldur            w1, [x0, #0x13]
    //     0x52988c: add             x1, x1, HEAP, lsl #32
    //     0x529890: cmp             w1, #2
    //     0x529894: b.lt            #0x5298a8
    //     0x529898: add             x2, fp, w1, sxtw #2
    //     0x52989c: ldr             x2, [x2, #8]
    //     0x5298a0: mov             x3, x2
    //     0x5298a4: b               #0x5298ac
    //     0x5298a8: mov             x3, NULL
    //     0x5298ac: stur            x3, [fp, #-0x10]
    //     0x5298b0: ldur            w1, [x0, #0xf]
    //     0x5298b4: add             x1, x1, HEAP, lsl #32
    //     0x5298b8: cbnz            w1, #0x5298c4
    //     0x5298bc: mov             x0, NULL
    //     0x5298c0: b               #0x5298d4
    //     0x5298c4: ldur            w1, [x0, #0x17]
    //     0x5298c8: add             x1, x1, HEAP, lsl #32
    //     0x5298cc: add             x0, fp, w1, sxtw #2
    //     0x5298d0: ldr             x0, [x0, #0x10]
    //     0x5298d4: stur            x0, [fp, #-8]
    // 0x5298d8: CheckStackOverflow
    //     0x5298d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5298dc: cmp             SP, x16
    //     0x5298e0: b.ls            #0x5299b8
    // 0x5298e4: r1 = Function '<anonymous closure>': static.
    //     0x5298e4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13018] AnonymousClosure: static (0x52a0a0), in [package:dio/src/utils.dart] ::caseInsensitiveKeyMap (0x529878)
    //     0x5298e8: ldr             x1, [x1, #0x18]
    // 0x5298ec: r2 = Null
    //     0x5298ec: mov             x2, NULL
    // 0x5298f0: r0 = AllocateClosure()
    //     0x5298f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5298f4: mov             x3, x0
    // 0x5298f8: ldur            x0, [fp, #-8]
    // 0x5298fc: stur            x3, [fp, #-0x18]
    // 0x529900: StoreField: r3->field_b = r0
    //     0x529900: stur            w0, [x3, #0xb]
    // 0x529904: r1 = Function '<anonymous closure>': static.
    //     0x529904: add             x1, PP, #0x13, lsl #12  ; [pp+0x13020] AnonymousClosure: static (0x52a030), in [package:dio/src/utils.dart] ::caseInsensitiveKeyMap (0x529878)
    //     0x529908: ldr             x1, [x1, #0x20]
    // 0x52990c: r2 = Null
    //     0x52990c: mov             x2, NULL
    // 0x529910: r0 = AllocateClosure()
    //     0x529910: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x529914: ldur            x1, [fp, #-8]
    // 0x529918: stur            x0, [fp, #-0x20]
    // 0x52991c: StoreField: r0->field_b = r1
    //     0x52991c: stur            w1, [x0, #0xb]
    // 0x529920: r2 = Null
    //     0x529920: mov             x2, NULL
    // 0x529924: r3 = <String, Y0>
    //     0x529924: add             x3, PP, #0x13, lsl #12  ; [pp+0x13028] TypeArguments: <String, Y0>
    //     0x529928: ldr             x3, [x3, #0x28]
    // 0x52992c: r24 = InstantiateTypeArgumentsStub
    //     0x52992c: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x529930: LoadField: r30 = r24->field_7
    //     0x529930: ldur            lr, [x24, #7]
    // 0x529934: blr             lr
    // 0x529938: ldur            x16, [fp, #-0x18]
    // 0x52993c: stp             x16, x0, [SP, #-0x10]!
    // 0x529940: ldur            x16, [fp, #-0x20]
    // 0x529944: SaveReg r16
    //     0x529944: str             x16, [SP, #-8]!
    // 0x529948: r0 = LinkedHashMap()
    //     0x529948: bl              #0x5299c0  ; [dart:collection] LinkedHashMap::LinkedHashMap
    // 0x52994c: add             SP, SP, #0x18
    // 0x529950: mov             x2, x0
    // 0x529954: ldur            x1, [fp, #-0x10]
    // 0x529958: stur            x2, [fp, #-8]
    // 0x52995c: cmp             w1, NULL
    // 0x529960: b.eq            #0x5299a8
    // 0x529964: r0 = LoadClassIdInstr(r1)
    //     0x529964: ldur            x0, [x1, #-1]
    //     0x529968: ubfx            x0, x0, #0xc, #0x14
    // 0x52996c: SaveReg r1
    //     0x52996c: str             x1, [SP, #-8]!
    // 0x529970: r0 = GDT[cid_x0 + 0x996]()
    //     0x529970: add             lr, x0, #0x996
    //     0x529974: ldr             lr, [x21, lr, lsl #3]
    //     0x529978: blr             lr
    // 0x52997c: add             SP, SP, #8
    // 0x529980: tbnz            w0, #4, #0x5299a8
    // 0x529984: ldur            x1, [fp, #-8]
    // 0x529988: r0 = LoadClassIdInstr(r1)
    //     0x529988: ldur            x0, [x1, #-1]
    //     0x52998c: ubfx            x0, x0, #0xc, #0x14
    // 0x529990: ldur            x16, [fp, #-0x10]
    // 0x529994: stp             x16, x1, [SP, #-0x10]!
    // 0x529998: r0 = GDT[cid_x0 + 0xcfd]()
    //     0x529998: add             lr, x0, #0xcfd
    //     0x52999c: ldr             lr, [x21, lr, lsl #3]
    //     0x5299a0: blr             lr
    // 0x5299a4: add             SP, SP, #0x10
    // 0x5299a8: ldur            x0, [fp, #-8]
    // 0x5299ac: LeaveFrame
    //     0x5299ac: mov             SP, fp
    //     0x5299b0: ldp             fp, lr, [SP], #0x10
    // 0x5299b4: ret
    //     0x5299b4: ret             
    // 0x5299b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5299b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5299bc: b               #0x5298e4
  }
  [closure] static int <anonymous closure>(dynamic, String) {
    // ** addr: 0x52a030, size: 0x70
    // 0x52a030: EnterFrame
    //     0x52a030: stp             fp, lr, [SP, #-0x10]!
    //     0x52a034: mov             fp, SP
    // 0x52a038: CheckStackOverflow
    //     0x52a038: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52a03c: cmp             SP, x16
    //     0x52a040: b.ls            #0x52a098
    // 0x52a044: ldr             x0, [fp, #0x10]
    // 0x52a048: r1 = LoadClassIdInstr(r0)
    //     0x52a048: ldur            x1, [x0, #-1]
    //     0x52a04c: ubfx            x1, x1, #0xc, #0x14
    // 0x52a050: SaveReg r0
    //     0x52a050: str             x0, [SP, #-8]!
    // 0x52a054: mov             x0, x1
    // 0x52a058: r0 = GDT[cid_x0 + -0xff4]()
    //     0x52a058: sub             lr, x0, #0xff4
    //     0x52a05c: ldr             lr, [x21, lr, lsl #3]
    //     0x52a060: blr             lr
    // 0x52a064: add             SP, SP, #8
    // 0x52a068: r1 = LoadClassIdInstr(r0)
    //     0x52a068: ldur            x1, [x0, #-1]
    //     0x52a06c: ubfx            x1, x1, #0xc, #0x14
    // 0x52a070: SaveReg r0
    //     0x52a070: str             x0, [SP, #-8]!
    // 0x52a074: mov             x0, x1
    // 0x52a078: r0 = GDT[cid_x0 + 0x2721]()
    //     0x52a078: mov             x17, #0x2721
    //     0x52a07c: add             lr, x0, x17
    //     0x52a080: ldr             lr, [x21, lr, lsl #3]
    //     0x52a084: blr             lr
    // 0x52a088: add             SP, SP, #8
    // 0x52a08c: LeaveFrame
    //     0x52a08c: mov             SP, fp
    //     0x52a090: ldp             fp, lr, [SP], #0x10
    // 0x52a094: ret
    //     0x52a094: ret             
    // 0x52a098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52a098: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52a09c: b               #0x52a044
  }
  [closure] static bool <anonymous closure>(dynamic, String, String) {
    // ** addr: 0x52a0a0, size: 0xa4
    // 0x52a0a0: EnterFrame
    //     0x52a0a0: stp             fp, lr, [SP, #-0x10]!
    //     0x52a0a4: mov             fp, SP
    // 0x52a0a8: AllocStack(0x8)
    //     0x52a0a8: sub             SP, SP, #8
    // 0x52a0ac: CheckStackOverflow
    //     0x52a0ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52a0b0: cmp             SP, x16
    //     0x52a0b4: b.ls            #0x52a13c
    // 0x52a0b8: ldr             x0, [fp, #0x18]
    // 0x52a0bc: r1 = LoadClassIdInstr(r0)
    //     0x52a0bc: ldur            x1, [x0, #-1]
    //     0x52a0c0: ubfx            x1, x1, #0xc, #0x14
    // 0x52a0c4: SaveReg r0
    //     0x52a0c4: str             x0, [SP, #-8]!
    // 0x52a0c8: mov             x0, x1
    // 0x52a0cc: r0 = GDT[cid_x0 + -0xff4]()
    //     0x52a0cc: sub             lr, x0, #0xff4
    //     0x52a0d0: ldr             lr, [x21, lr, lsl #3]
    //     0x52a0d4: blr             lr
    // 0x52a0d8: add             SP, SP, #8
    // 0x52a0dc: mov             x1, x0
    // 0x52a0e0: ldr             x0, [fp, #0x10]
    // 0x52a0e4: stur            x1, [fp, #-8]
    // 0x52a0e8: r2 = LoadClassIdInstr(r0)
    //     0x52a0e8: ldur            x2, [x0, #-1]
    //     0x52a0ec: ubfx            x2, x2, #0xc, #0x14
    // 0x52a0f0: SaveReg r0
    //     0x52a0f0: str             x0, [SP, #-8]!
    // 0x52a0f4: mov             x0, x2
    // 0x52a0f8: r0 = GDT[cid_x0 + -0xff4]()
    //     0x52a0f8: sub             lr, x0, #0xff4
    //     0x52a0fc: ldr             lr, [x21, lr, lsl #3]
    //     0x52a100: blr             lr
    // 0x52a104: add             SP, SP, #8
    // 0x52a108: mov             x1, x0
    // 0x52a10c: ldur            x0, [fp, #-8]
    // 0x52a110: r2 = LoadClassIdInstr(r0)
    //     0x52a110: ldur            x2, [x0, #-1]
    //     0x52a114: ubfx            x2, x2, #0xc, #0x14
    // 0x52a118: stp             x1, x0, [SP, #-0x10]!
    // 0x52a11c: mov             x0, x2
    // 0x52a120: mov             lr, x0
    // 0x52a124: ldr             lr, [x21, lr, lsl #3]
    // 0x52a128: blr             lr
    // 0x52a12c: add             SP, SP, #0x10
    // 0x52a130: LeaveFrame
    //     0x52a130: mov             SP, fp
    //     0x52a134: ldp             fp, lr, [SP], #0x10
    // 0x52a138: ret
    //     0x52a138: ret             
    // 0x52a13c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52a13c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52a140: b               #0x52a0b8
  }
  static _ encodeMap(/* No info */) {
    // ** addr: 0x553b44, size: 0x2c0
    // 0x553b44: EnterFrame
    //     0x553b44: stp             fp, lr, [SP, #-0x10]!
    //     0x553b48: mov             fp, SP
    // 0x553b4c: AllocStack(0x28)
    //     0x553b4c: sub             SP, SP, #0x28
    // 0x553b50: SetupParameters(dynamic _ /* r3, fp-0x20 */, dynamic _ /* r4, fp-0x18 */, {dynamic encode = true /* r5, fp-0x10 */, dynamic isQuery = false /* r0, fp-0x8 */})
    //     0x553b50: mov             x0, x4
    //     0x553b54: ldur            w1, [x0, #0x13]
    //     0x553b58: add             x1, x1, HEAP, lsl #32
    //     0x553b5c: sub             x2, x1, #4
    //     0x553b60: add             x3, fp, w2, sxtw #2
    //     0x553b64: ldr             x3, [x3, #0x18]
    //     0x553b68: stur            x3, [fp, #-0x20]
    //     0x553b6c: add             x4, fp, w2, sxtw #2
    //     0x553b70: ldr             x4, [x4, #0x10]
    //     0x553b74: stur            x4, [fp, #-0x18]
    //     0x553b78: ldur            w2, [x0, #0x1f]
    //     0x553b7c: add             x2, x2, HEAP, lsl #32
    //     0x553b80: add             x16, PP, #0x14, lsl #12  ; [pp+0x14308] "encode"
    //     0x553b84: ldr             x16, [x16, #0x308]
    //     0x553b88: cmp             w2, w16
    //     0x553b8c: b.ne            #0x553bb0
    //     0x553b90: ldur            w2, [x0, #0x23]
    //     0x553b94: add             x2, x2, HEAP, lsl #32
    //     0x553b98: sub             w5, w1, w2
    //     0x553b9c: add             x2, fp, w5, sxtw #2
    //     0x553ba0: ldr             x2, [x2, #8]
    //     0x553ba4: mov             x5, x2
    //     0x553ba8: mov             x2, #1
    //     0x553bac: b               #0x553bb8
    //     0x553bb0: add             x5, NULL, #0x20  ; true
    //     0x553bb4: mov             x2, #0
    //     0x553bb8: stur            x5, [fp, #-0x10]
    //     0x553bbc: lsl             x6, x2, #1
    //     0x553bc0: lsl             w2, w6, #1
    //     0x553bc4: add             w6, w2, #8
    //     0x553bc8: add             x16, x0, w6, sxtw #1
    //     0x553bcc: ldur            w7, [x16, #0xf]
    //     0x553bd0: add             x7, x7, HEAP, lsl #32
    //     0x553bd4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14310] "isQuery"
    //     0x553bd8: ldr             x16, [x16, #0x310]
    //     0x553bdc: cmp             w7, w16
    //     0x553be0: b.ne            #0x553c08
    //     0x553be4: add             w6, w2, #0xa
    //     0x553be8: add             x16, x0, w6, sxtw #1
    //     0x553bec: ldur            w2, [x16, #0xf]
    //     0x553bf0: add             x2, x2, HEAP, lsl #32
    //     0x553bf4: sub             w0, w1, w2
    //     0x553bf8: add             x1, fp, w0, sxtw #2
    //     0x553bfc: ldr             x1, [x1, #8]
    //     0x553c00: mov             x0, x1
    //     0x553c04: b               #0x553c0c
    //     0x553c08: add             x0, NULL, #0x30  ; false
    //     0x553c0c: stur            x0, [fp, #-8]
    // 0x553c10: CheckStackOverflow
    //     0x553c10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x553c14: cmp             SP, x16
    //     0x553c18: b.ls            #0x553dfc
    // 0x553c1c: r1 = 9
    //     0x553c1c: mov             x1, #9
    // 0x553c20: r0 = AllocateContext()
    //     0x553c20: bl              #0xd68aa4  ; AllocateContextStub
    // 0x553c24: mov             x1, x0
    // 0x553c28: ldur            x0, [fp, #-0x18]
    // 0x553c2c: stur            x1, [fp, #-0x28]
    // 0x553c30: StoreField: r1->field_f = r0
    //     0x553c30: stur            w0, [x1, #0xf]
    // 0x553c34: ldur            x0, [fp, #-8]
    // 0x553c38: StoreField: r1->field_13 = r0
    //     0x553c38: stur            w0, [x1, #0x13]
    // 0x553c3c: r0 = StringBuffer()
    //     0x553c3c: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x553c40: stur            x0, [fp, #-8]
    // 0x553c44: r16 = ""
    //     0x553c44: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x553c48: stp             x16, x0, [SP, #-0x10]!
    // 0x553c4c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x553c4c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x553c50: r0 = StringBuffer()
    //     0x553c50: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0x553c54: add             SP, SP, #0x10
    // 0x553c58: ldur            x0, [fp, #-8]
    // 0x553c5c: ldur            x2, [fp, #-0x28]
    // 0x553c60: StoreField: r2->field_17 = r0
    //     0x553c60: stur            w0, [x2, #0x17]
    //     0x553c64: ldurb           w16, [x2, #-1]
    //     0x553c68: ldurb           w17, [x0, #-1]
    //     0x553c6c: and             x16, x17, x16, lsr #2
    //     0x553c70: tst             x16, HEAP, lsr #32
    //     0x553c74: b.eq            #0x553c7c
    //     0x553c78: bl              #0xd6828c
    // 0x553c7c: r0 = true
    //     0x553c7c: add             x0, NULL, #0x20  ; true
    // 0x553c80: StoreField: r2->field_1b = r0
    //     0x553c80: stur            w0, [x2, #0x1b]
    // 0x553c84: LoadField: r1 = r2->field_13
    //     0x553c84: ldur            w1, [x2, #0x13]
    // 0x553c88: DecompressPointer r1
    //     0x553c88: add             x1, x1, HEAP, lsl #32
    // 0x553c8c: mov             x0, x1
    // 0x553c90: stur            x1, [fp, #-0x18]
    // 0x553c94: tbnz            w0, #5, #0x553c9c
    // 0x553c98: r0 = AssertBoolean()
    //     0x553c98: bl              #0xd67df0  ; AssertBooleanStub
    // 0x553c9c: ldur            x1, [fp, #-0x18]
    // 0x553ca0: tbnz            w1, #4, #0x553cac
    // 0x553ca4: ldur            x2, [fp, #-0x10]
    // 0x553ca8: b               #0x553cb4
    // 0x553cac: ldur            x2, [fp, #-0x10]
    // 0x553cb0: tbz             w2, #4, #0x553cbc
    // 0x553cb4: r0 = "["
    //     0x553cb4: ldr             x0, [PP, #0x1468]  ; [pp+0x1468] "["
    // 0x553cb8: b               #0x553cc4
    // 0x553cbc: r0 = "%5B"
    //     0x553cbc: add             x0, PP, #0x14, lsl #12  ; [pp+0x14318] "%5B"
    //     0x553cc0: ldr             x0, [x0, #0x318]
    // 0x553cc4: ldur            x3, [fp, #-0x28]
    // 0x553cc8: StoreField: r3->field_1f = r0
    //     0x553cc8: stur            w0, [x3, #0x1f]
    //     0x553ccc: ldurb           w16, [x3, #-1]
    //     0x553cd0: ldurb           w17, [x0, #-1]
    //     0x553cd4: and             x16, x17, x16, lsr #2
    //     0x553cd8: tst             x16, HEAP, lsr #32
    //     0x553cdc: b.eq            #0x553ce4
    //     0x553ce0: bl              #0xd682ac
    // 0x553ce4: tbz             w1, #4, #0x553cec
    // 0x553ce8: tbz             w2, #4, #0x553cf4
    // 0x553cec: r0 = "]"
    //     0x553cec: ldr             x0, [PP, #0x1460]  ; [pp+0x1460] "]"
    // 0x553cf0: b               #0x553cfc
    // 0x553cf4: r0 = "%5D"
    //     0x553cf4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14320] "%5D"
    //     0x553cf8: ldr             x0, [x0, #0x320]
    // 0x553cfc: StoreField: r3->field_23 = r0
    //     0x553cfc: stur            w0, [x3, #0x23]
    //     0x553d00: ldurb           w16, [x3, #-1]
    //     0x553d04: ldurb           w17, [x0, #-1]
    //     0x553d08: and             x16, x17, x16, lsr #2
    //     0x553d0c: tst             x16, HEAP, lsr #32
    //     0x553d10: b.eq            #0x553d18
    //     0x553d14: bl              #0xd682ac
    // 0x553d18: tbnz            w2, #4, #0x553d28
    // 0x553d1c: r0 = Closure: (String, {Encoding encoding}) => String from Function 'encodeQueryComponent': static.
    //     0x553d1c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14328] Closure: (String, {Encoding encoding}) => String from Function 'encodeQueryComponent': static. (0x7fe6e1d548a0)
    //     0x553d20: ldr             x0, [x0, #0x328]
    // 0x553d24: b               #0x553d3c
    // 0x553d28: r1 = Function '<anonymous closure>': static.
    //     0x553d28: add             x1, PP, #0x14, lsl #12  ; [pp+0x14330] AnonymousClosure: (0xd677cc), in [package:flutter/src/services/restoration.dart] RestorationBucket::_visitChildren (0x5c6864)
    //     0x553d2c: ldr             x1, [x1, #0x330]
    // 0x553d30: r2 = Null
    //     0x553d30: mov             x2, NULL
    // 0x553d34: r0 = AllocateClosure()
    //     0x553d34: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x553d38: ldur            x3, [fp, #-0x28]
    // 0x553d3c: StoreField: r3->field_27 = r0
    //     0x553d3c: stur            w0, [x3, #0x27]
    //     0x553d40: ldurb           w16, [x3, #-1]
    //     0x553d44: ldurb           w17, [x0, #-1]
    //     0x553d48: and             x16, x17, x16, lsr #2
    //     0x553d4c: tst             x16, HEAP, lsr #32
    //     0x553d50: b.eq            #0x553d58
    //     0x553d54: bl              #0xd682ac
    // 0x553d58: mov             x2, x3
    // 0x553d5c: r1 = Function 'maybeEncode': static.
    //     0x553d5c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14338] AnonymousClosure: static (0x5547cc), in [package:dio/src/utils.dart] ::encodeMap (0x553b44)
    //     0x553d60: ldr             x1, [x1, #0x338]
    // 0x553d64: r0 = AllocateClosure()
    //     0x553d64: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x553d68: ldur            x3, [fp, #-0x28]
    // 0x553d6c: StoreField: r3->field_2b = r0
    //     0x553d6c: stur            w0, [x3, #0x2b]
    //     0x553d70: ldurb           w16, [x3, #-1]
    //     0x553d74: ldurb           w17, [x0, #-1]
    //     0x553d78: and             x16, x17, x16, lsr #2
    //     0x553d7c: tst             x16, HEAP, lsr #32
    //     0x553d80: b.eq            #0x553d88
    //     0x553d84: bl              #0xd682ac
    // 0x553d88: mov             x2, x3
    // 0x553d8c: r1 = Function 'urlEncode': static.
    //     0x553d8c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14340] AnonymousClosure: static (0x553e04), in [package:dio/src/utils.dart] ::encodeMap (0x553b44)
    //     0x553d90: ldr             x1, [x1, #0x340]
    // 0x553d94: r0 = AllocateClosure()
    //     0x553d94: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x553d98: mov             x2, x0
    // 0x553d9c: ldur            x1, [fp, #-0x28]
    // 0x553da0: StoreField: r1->field_2f = r0
    //     0x553da0: stur            w0, [x1, #0x2f]
    //     0x553da4: ldurb           w16, [x1, #-1]
    //     0x553da8: ldurb           w17, [x0, #-1]
    //     0x553dac: and             x16, x17, x16, lsr #2
    //     0x553db0: tst             x16, HEAP, lsr #32
    //     0x553db4: b.eq            #0x553dbc
    //     0x553db8: bl              #0xd6826c
    // 0x553dbc: ldur            x16, [fp, #-0x20]
    // 0x553dc0: stp             x16, x2, [SP, #-0x10]!
    // 0x553dc4: r16 = ""
    //     0x553dc4: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x553dc8: SaveReg r16
    //     0x553dc8: str             x16, [SP, #-8]!
    // 0x553dcc: mov             x0, x2
    // 0x553dd0: ClosureCall
    //     0x553dd0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x553dd4: ldur            x2, [x0, #0x1f]
    //     0x553dd8: blr             x2
    // 0x553ddc: add             SP, SP, #0x18
    // 0x553de0: ldur            x16, [fp, #-8]
    // 0x553de4: SaveReg r16
    //     0x553de4: str             x16, [SP, #-8]!
    // 0x553de8: r0 = toString()
    //     0x553de8: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0x553dec: add             SP, SP, #8
    // 0x553df0: LeaveFrame
    //     0x553df0: mov             SP, fp
    //     0x553df4: ldp             fp, lr, [SP], #0x10
    // 0x553df8: ret
    //     0x553df8: ret             
    // 0x553dfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x553dfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x553e00: b               #0x553c1c
  }
  [closure] static void urlEncode(dynamic, Object?, String) {
    // ** addr: 0x553e04, size: 0x6f0
    // 0x553e04: EnterFrame
    //     0x553e04: stp             fp, lr, [SP, #-0x10]!
    //     0x553e08: mov             fp, SP
    // 0x553e0c: AllocStack(0x60)
    //     0x553e0c: sub             SP, SP, #0x60
    // 0x553e10: SetupParameters()
    //     0x553e10: ldr             x0, [fp, #0x20]
    //     0x553e14: ldur            w1, [x0, #0x17]
    //     0x553e18: add             x1, x1, HEAP, lsl #32
    //     0x553e1c: stur            x1, [fp, #-8]
    // 0x553e20: CheckStackOverflow
    //     0x553e20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x553e24: cmp             SP, x16
    //     0x553e28: b.ls            #0x5544e0
    // 0x553e2c: r1 = 1
    //     0x553e2c: mov             x1, #1
    // 0x553e30: r0 = AllocateContext()
    //     0x553e30: bl              #0xd68aa4  ; AllocateContextStub
    // 0x553e34: mov             x4, x0
    // 0x553e38: ldur            x3, [fp, #-8]
    // 0x553e3c: stur            x4, [fp, #-0x10]
    // 0x553e40: StoreField: r4->field_b = r3
    //     0x553e40: stur            w3, [x4, #0xb]
    // 0x553e44: ldr             x5, [fp, #0x10]
    // 0x553e48: StoreField: r4->field_f = r5
    //     0x553e48: stur            w5, [x4, #0xf]
    // 0x553e4c: ldr             x0, [fp, #0x18]
    // 0x553e50: r2 = Null
    //     0x553e50: mov             x2, NULL
    // 0x553e54: r1 = Null
    //     0x553e54: mov             x1, NULL
    // 0x553e58: cmp             w0, NULL
    // 0x553e5c: b.eq            #0x553f00
    // 0x553e60: branchIfSmi(r0, 0x553f00)
    //     0x553e60: tbz             w0, #0, #0x553f00
    // 0x553e64: r3 = LoadClassIdInstr(r0)
    //     0x553e64: ldur            x3, [x0, #-1]
    //     0x553e68: ubfx            x3, x3, #0xc, #0x14
    // 0x553e6c: r17 = 5697
    //     0x553e6c: mov             x17, #0x1641
    // 0x553e70: cmp             x3, x17
    // 0x553e74: b.eq            #0x553f08
    // 0x553e78: sub             x3, x3, #0x59
    // 0x553e7c: cmp             x3, #2
    // 0x553e80: b.ls            #0x553f08
    // 0x553e84: r4 = LoadClassIdInstr(r0)
    //     0x553e84: ldur            x4, [x0, #-1]
    //     0x553e88: ubfx            x4, x4, #0xc, #0x14
    // 0x553e8c: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x553e90: ldr             x3, [x3, #0x18]
    // 0x553e94: ldr             x3, [x3, x4, lsl #3]
    // 0x553e98: LoadField: r3 = r3->field_2b
    //     0x553e98: ldur            w3, [x3, #0x2b]
    // 0x553e9c: DecompressPointer r3
    //     0x553e9c: add             x3, x3, HEAP, lsl #32
    // 0x553ea0: cmp             w3, NULL
    // 0x553ea4: b.eq            #0x553f00
    // 0x553ea8: LoadField: r3 = r3->field_f
    //     0x553ea8: ldur            w3, [x3, #0xf]
    // 0x553eac: lsr             x3, x3, #4
    // 0x553eb0: r17 = 5697
    //     0x553eb0: mov             x17, #0x1641
    // 0x553eb4: cmp             x3, x17
    // 0x553eb8: b.eq            #0x553f08
    // 0x553ebc: r3 = SubtypeTestCache
    //     0x553ebc: add             x3, PP, #0x14, lsl #12  ; [pp+0x14348] SubtypeTestCache
    //     0x553ec0: ldr             x3, [x3, #0x348]
    // 0x553ec4: r24 = Subtype1TestCacheStub
    //     0x553ec4: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x553ec8: LoadField: r30 = r24->field_7
    //     0x553ec8: ldur            lr, [x24, #7]
    // 0x553ecc: blr             lr
    // 0x553ed0: cmp             w7, NULL
    // 0x553ed4: b.eq            #0x553ee0
    // 0x553ed8: tbnz            w7, #4, #0x553f00
    // 0x553edc: b               #0x553f08
    // 0x553ee0: r8 = List
    //     0x553ee0: add             x8, PP, #0x14, lsl #12  ; [pp+0x14350] Type: List
    //     0x553ee4: ldr             x8, [x8, #0x350]
    // 0x553ee8: r3 = SubtypeTestCache
    //     0x553ee8: add             x3, PP, #0x14, lsl #12  ; [pp+0x14358] SubtypeTestCache
    //     0x553eec: ldr             x3, [x3, #0x358]
    // 0x553ef0: r24 = InstanceOfStub
    //     0x553ef0: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x553ef4: LoadField: r30 = r24->field_7
    //     0x553ef4: ldur            lr, [x24, #7]
    // 0x553ef8: blr             lr
    // 0x553efc: b               #0x553f0c
    // 0x553f00: r0 = false
    //     0x553f00: add             x0, NULL, #0x30  ; false
    // 0x553f04: b               #0x553f0c
    // 0x553f08: r0 = true
    //     0x553f08: add             x0, NULL, #0x20  ; true
    // 0x553f0c: tbnz            w0, #4, #0x5542e4
    // 0x553f10: ldur            x3, [fp, #-8]
    // 0x553f14: LoadField: r1 = r3->field_2f
    //     0x553f14: ldur            w1, [x3, #0x2f]
    // 0x553f18: DecompressPointer r1
    //     0x553f18: add             x1, x1, HEAP, lsl #32
    // 0x553f1c: stur            x1, [fp, #-0x38]
    // 0x553f20: LoadField: r2 = r3->field_2b
    //     0x553f20: ldur            w2, [x3, #0x2b]
    // 0x553f24: DecompressPointer r2
    //     0x553f24: add             x2, x2, HEAP, lsl #32
    // 0x553f28: stur            x2, [fp, #-0x30]
    // 0x553f2c: LoadField: r4 = r3->field_1f
    //     0x553f2c: ldur            w4, [x3, #0x1f]
    // 0x553f30: DecompressPointer r4
    //     0x553f30: add             x4, x4, HEAP, lsl #32
    // 0x553f34: stur            x4, [fp, #-0x28]
    // 0x553f38: LoadField: r5 = r3->field_23
    //     0x553f38: ldur            w5, [x3, #0x23]
    // 0x553f3c: DecompressPointer r5
    //     0x553f3c: add             x5, x5, HEAP, lsl #32
    // 0x553f40: stur            x5, [fp, #-0x20]
    // 0x553f44: r7 = 0
    //     0x553f44: mov             x7, #0
    // 0x553f48: ldr             x6, [fp, #0x18]
    // 0x553f4c: ldur            x3, [fp, #-0x10]
    // 0x553f50: stur            x7, [fp, #-0x18]
    // 0x553f54: CheckStackOverflow
    //     0x553f54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x553f58: cmp             SP, x16
    //     0x553f5c: b.ls            #0x5544e8
    // 0x553f60: r0 = LoadClassIdInstr(r6)
    //     0x553f60: ldur            x0, [x6, #-1]
    //     0x553f64: ubfx            x0, x0, #0xc, #0x14
    // 0x553f68: SaveReg r6
    //     0x553f68: str             x6, [SP, #-8]!
    // 0x553f6c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x553f6c: mov             x17, #0xb8ea
    //     0x553f70: add             lr, x0, x17
    //     0x553f74: ldr             lr, [x21, lr, lsl #3]
    //     0x553f78: blr             lr
    // 0x553f7c: add             SP, SP, #8
    // 0x553f80: r1 = LoadInt32Instr(r0)
    //     0x553f80: sbfx            x1, x0, #1, #0x1f
    //     0x553f84: tbz             w0, #0, #0x553f8c
    //     0x553f88: ldur            x1, [x0, #7]
    // 0x553f8c: ldur            x2, [fp, #-0x18]
    // 0x553f90: cmp             x2, x1
    // 0x553f94: b.ge            #0x5544d0
    // 0x553f98: ldr             x3, [fp, #0x18]
    // 0x553f9c: r0 = BoxInt64Instr(r2)
    //     0x553f9c: sbfiz           x0, x2, #1, #0x1f
    //     0x553fa0: cmp             x2, x0, asr #1
    //     0x553fa4: b.eq            #0x553fb0
    //     0x553fa8: bl              #0xd69bb8
    //     0x553fac: stur            x2, [x0, #7]
    // 0x553fb0: mov             x1, x0
    // 0x553fb4: stur            x1, [fp, #-0x40]
    // 0x553fb8: r0 = LoadClassIdInstr(r3)
    //     0x553fb8: ldur            x0, [x3, #-1]
    //     0x553fbc: ubfx            x0, x0, #0xc, #0x14
    // 0x553fc0: stp             x1, x3, [SP, #-0x10]!
    // 0x553fc4: r0 = GDT[cid_x0 + -0xd83]()
    //     0x553fc4: sub             lr, x0, #0xd83
    //     0x553fc8: ldr             lr, [x21, lr, lsl #3]
    //     0x553fcc: blr             lr
    // 0x553fd0: add             SP, SP, #0x10
    // 0x553fd4: r2 = Null
    //     0x553fd4: mov             x2, NULL
    // 0x553fd8: r1 = Null
    //     0x553fd8: mov             x1, NULL
    // 0x553fdc: cmp             w0, NULL
    // 0x553fe0: b.eq            #0x554078
    // 0x553fe4: branchIfSmi(r0, 0x554078)
    //     0x553fe4: tbz             w0, #0, #0x554078
    // 0x553fe8: r3 = LoadClassIdInstr(r0)
    //     0x553fe8: ldur            x3, [x0, #-1]
    //     0x553fec: ubfx            x3, x3, #0xc, #0x14
    // 0x553ff0: r17 = 5696
    //     0x553ff0: mov             x17, #0x1640
    // 0x553ff4: cmp             x3, x17
    // 0x553ff8: b.eq            #0x554080
    // 0x553ffc: r4 = LoadClassIdInstr(r0)
    //     0x553ffc: ldur            x4, [x0, #-1]
    //     0x554000: ubfx            x4, x4, #0xc, #0x14
    // 0x554004: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x554008: ldr             x3, [x3, #0x18]
    // 0x55400c: ldr             x3, [x3, x4, lsl #3]
    // 0x554010: LoadField: r3 = r3->field_2b
    //     0x554010: ldur            w3, [x3, #0x2b]
    // 0x554014: DecompressPointer r3
    //     0x554014: add             x3, x3, HEAP, lsl #32
    // 0x554018: cmp             w3, NULL
    // 0x55401c: b.eq            #0x554078
    // 0x554020: LoadField: r3 = r3->field_f
    //     0x554020: ldur            w3, [x3, #0xf]
    // 0x554024: lsr             x3, x3, #4
    // 0x554028: r17 = 5696
    //     0x554028: mov             x17, #0x1640
    // 0x55402c: cmp             x3, x17
    // 0x554030: b.eq            #0x554080
    // 0x554034: r3 = SubtypeTestCache
    //     0x554034: add             x3, PP, #0x14, lsl #12  ; [pp+0x14360] SubtypeTestCache
    //     0x554038: ldr             x3, [x3, #0x360]
    // 0x55403c: r24 = Subtype1TestCacheStub
    //     0x55403c: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x554040: LoadField: r30 = r24->field_7
    //     0x554040: ldur            lr, [x24, #7]
    // 0x554044: blr             lr
    // 0x554048: cmp             w7, NULL
    // 0x55404c: b.eq            #0x554058
    // 0x554050: tbnz            w7, #4, #0x554078
    // 0x554054: b               #0x554080
    // 0x554058: r8 = Map
    //     0x554058: add             x8, PP, #0x14, lsl #12  ; [pp+0x14368] Type: Map
    //     0x55405c: ldr             x8, [x8, #0x368]
    // 0x554060: r3 = SubtypeTestCache
    //     0x554060: add             x3, PP, #0x14, lsl #12  ; [pp+0x14370] SubtypeTestCache
    //     0x554064: ldr             x3, [x3, #0x370]
    // 0x554068: r24 = InstanceOfStub
    //     0x554068: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x55406c: LoadField: r30 = r24->field_7
    //     0x55406c: ldur            lr, [x24, #7]
    // 0x554070: blr             lr
    // 0x554074: b               #0x554084
    // 0x554078: r0 = false
    //     0x554078: add             x0, NULL, #0x30  ; false
    // 0x55407c: b               #0x554084
    // 0x554080: r0 = true
    //     0x554080: add             x0, NULL, #0x20  ; true
    // 0x554084: tbz             w0, #4, #0x55416c
    // 0x554088: ldr             x1, [fp, #0x18]
    // 0x55408c: r0 = LoadClassIdInstr(r1)
    //     0x55408c: ldur            x0, [x1, #-1]
    //     0x554090: ubfx            x0, x0, #0xc, #0x14
    // 0x554094: ldur            x16, [fp, #-0x40]
    // 0x554098: stp             x16, x1, [SP, #-0x10]!
    // 0x55409c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x55409c: sub             lr, x0, #0xd83
    //     0x5540a0: ldr             lr, [x21, lr, lsl #3]
    //     0x5540a4: blr             lr
    // 0x5540a8: add             SP, SP, #0x10
    // 0x5540ac: r2 = Null
    //     0x5540ac: mov             x2, NULL
    // 0x5540b0: r1 = Null
    //     0x5540b0: mov             x1, NULL
    // 0x5540b4: cmp             w0, NULL
    // 0x5540b8: b.eq            #0x55415c
    // 0x5540bc: branchIfSmi(r0, 0x55415c)
    //     0x5540bc: tbz             w0, #0, #0x55415c
    // 0x5540c0: r3 = LoadClassIdInstr(r0)
    //     0x5540c0: ldur            x3, [x0, #-1]
    //     0x5540c4: ubfx            x3, x3, #0xc, #0x14
    // 0x5540c8: r17 = 5697
    //     0x5540c8: mov             x17, #0x1641
    // 0x5540cc: cmp             x3, x17
    // 0x5540d0: b.eq            #0x554164
    // 0x5540d4: sub             x3, x3, #0x59
    // 0x5540d8: cmp             x3, #2
    // 0x5540dc: b.ls            #0x554164
    // 0x5540e0: r4 = LoadClassIdInstr(r0)
    //     0x5540e0: ldur            x4, [x0, #-1]
    //     0x5540e4: ubfx            x4, x4, #0xc, #0x14
    // 0x5540e8: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x5540ec: ldr             x3, [x3, #0x18]
    // 0x5540f0: ldr             x3, [x3, x4, lsl #3]
    // 0x5540f4: LoadField: r3 = r3->field_2b
    //     0x5540f4: ldur            w3, [x3, #0x2b]
    // 0x5540f8: DecompressPointer r3
    //     0x5540f8: add             x3, x3, HEAP, lsl #32
    // 0x5540fc: cmp             w3, NULL
    // 0x554100: b.eq            #0x55415c
    // 0x554104: LoadField: r3 = r3->field_f
    //     0x554104: ldur            w3, [x3, #0xf]
    // 0x554108: lsr             x3, x3, #4
    // 0x55410c: r17 = 5697
    //     0x55410c: mov             x17, #0x1641
    // 0x554110: cmp             x3, x17
    // 0x554114: b.eq            #0x554164
    // 0x554118: r3 = SubtypeTestCache
    //     0x554118: add             x3, PP, #0x14, lsl #12  ; [pp+0x14378] SubtypeTestCache
    //     0x55411c: ldr             x3, [x3, #0x378]
    // 0x554120: r24 = Subtype1TestCacheStub
    //     0x554120: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x554124: LoadField: r30 = r24->field_7
    //     0x554124: ldur            lr, [x24, #7]
    // 0x554128: blr             lr
    // 0x55412c: cmp             w7, NULL
    // 0x554130: b.eq            #0x55413c
    // 0x554134: tbnz            w7, #4, #0x55415c
    // 0x554138: b               #0x554164
    // 0x55413c: r8 = List
    //     0x55413c: add             x8, PP, #0x14, lsl #12  ; [pp+0x14380] Type: List
    //     0x554140: ldr             x8, [x8, #0x380]
    // 0x554144: r3 = SubtypeTestCache
    //     0x554144: add             x3, PP, #0x14, lsl #12  ; [pp+0x14388] SubtypeTestCache
    //     0x554148: ldr             x3, [x3, #0x388]
    // 0x55414c: r24 = InstanceOfStub
    //     0x55414c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x554150: LoadField: r30 = r24->field_7
    //     0x554150: ldur            lr, [x24, #7]
    // 0x554154: blr             lr
    // 0x554158: b               #0x554168
    // 0x55415c: r0 = false
    //     0x55415c: add             x0, NULL, #0x30  ; false
    // 0x554160: b               #0x554168
    // 0x554164: r0 = true
    //     0x554164: add             x0, NULL, #0x20  ; true
    // 0x554168: tbnz            w0, #4, #0x554174
    // 0x55416c: r3 = true
    //     0x55416c: add             x3, NULL, #0x20  ; true
    // 0x554170: b               #0x55419c
    // 0x554174: ldr             x1, [fp, #0x18]
    // 0x554178: r0 = LoadClassIdInstr(r1)
    //     0x554178: ldur            x0, [x1, #-1]
    //     0x55417c: ubfx            x0, x0, #0xc, #0x14
    // 0x554180: ldur            x16, [fp, #-0x40]
    // 0x554184: stp             x16, x1, [SP, #-0x10]!
    // 0x554188: r0 = GDT[cid_x0 + -0xd83]()
    //     0x554188: sub             lr, x0, #0xd83
    //     0x55418c: ldr             lr, [x21, lr, lsl #3]
    //     0x554190: blr             lr
    // 0x554194: add             SP, SP, #0x10
    // 0x554198: r3 = false
    //     0x554198: add             x3, NULL, #0x30  ; false
    // 0x55419c: ldr             x1, [fp, #0x18]
    // 0x5541a0: ldur            x2, [fp, #-0x10]
    // 0x5541a4: stur            x3, [fp, #-0x48]
    // 0x5541a8: r0 = LoadClassIdInstr(r1)
    //     0x5541a8: ldur            x0, [x1, #-1]
    //     0x5541ac: ubfx            x0, x0, #0xc, #0x14
    // 0x5541b0: ldur            x16, [fp, #-0x40]
    // 0x5541b4: stp             x16, x1, [SP, #-0x10]!
    // 0x5541b8: r0 = GDT[cid_x0 + -0xd83]()
    //     0x5541b8: sub             lr, x0, #0xd83
    //     0x5541bc: ldr             lr, [x21, lr, lsl #3]
    //     0x5541c0: blr             lr
    // 0x5541c4: add             SP, SP, #0x10
    // 0x5541c8: ldur            x16, [fp, #-0x30]
    // 0x5541cc: stp             x0, x16, [SP, #-0x10]!
    // 0x5541d0: ldur            x0, [fp, #-0x30]
    // 0x5541d4: ClosureCall
    //     0x5541d4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5541d8: ldur            x2, [x0, #0x1f]
    //     0x5541dc: blr             x2
    // 0x5541e0: add             SP, SP, #0x10
    // 0x5541e4: mov             x3, x0
    // 0x5541e8: ldur            x0, [fp, #-0x10]
    // 0x5541ec: stur            x3, [fp, #-0x58]
    // 0x5541f0: LoadField: r4 = r0->field_f
    //     0x5541f0: ldur            w4, [x0, #0xf]
    // 0x5541f4: DecompressPointer r4
    //     0x5541f4: add             x4, x4, HEAP, lsl #32
    // 0x5541f8: stur            x4, [fp, #-0x50]
    // 0x5541fc: r1 = Null
    //     0x5541fc: mov             x1, NULL
    // 0x554200: r2 = 4
    //     0x554200: mov             x2, #4
    // 0x554204: r0 = AllocateArray()
    //     0x554204: bl              #0xd6987c  ; AllocateArrayStub
    // 0x554208: mov             x3, x0
    // 0x55420c: ldur            x0, [fp, #-0x50]
    // 0x554210: stur            x3, [fp, #-0x60]
    // 0x554214: StoreField: r3->field_f = r0
    //     0x554214: stur            w0, [x3, #0xf]
    // 0x554218: ldur            x0, [fp, #-0x48]
    // 0x55421c: tbnz            w0, #4, #0x554264
    // 0x554220: ldur            x4, [fp, #-0x28]
    // 0x554224: ldur            x5, [fp, #-0x20]
    // 0x554228: ldur            x0, [fp, #-0x40]
    // 0x55422c: r1 = Null
    //     0x55422c: mov             x1, NULL
    // 0x554230: r2 = 6
    //     0x554230: mov             x2, #6
    // 0x554234: r0 = AllocateArray()
    //     0x554234: bl              #0xd6987c  ; AllocateArrayStub
    // 0x554238: mov             x1, x0
    // 0x55423c: ldur            x0, [fp, #-0x28]
    // 0x554240: StoreField: r1->field_f = r0
    //     0x554240: stur            w0, [x1, #0xf]
    // 0x554244: ldur            x2, [fp, #-0x40]
    // 0x554248: StoreField: r1->field_13 = r2
    //     0x554248: stur            w2, [x1, #0x13]
    // 0x55424c: ldur            x2, [fp, #-0x20]
    // 0x554250: StoreField: r1->field_17 = r2
    //     0x554250: stur            w2, [x1, #0x17]
    // 0x554254: SaveReg r1
    //     0x554254: str             x1, [SP, #-8]!
    // 0x554258: r0 = _interpolate()
    //     0x554258: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x55425c: add             SP, SP, #8
    // 0x554260: b               #0x554268
    // 0x554264: r0 = ""
    //     0x554264: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x554268: ldur            x2, [fp, #-0x18]
    // 0x55426c: ldur            x1, [fp, #-0x60]
    // 0x554270: ArrayStore: r1[1] = r0  ; List_4
    //     0x554270: add             x25, x1, #0x13
    //     0x554274: str             w0, [x25]
    //     0x554278: tbz             w0, #0, #0x554294
    //     0x55427c: ldurb           w16, [x1, #-1]
    //     0x554280: ldurb           w17, [x0, #-1]
    //     0x554284: and             x16, x17, x16, lsr #2
    //     0x554288: tst             x16, HEAP, lsr #32
    //     0x55428c: b.eq            #0x554294
    //     0x554290: bl              #0xd67e5c
    // 0x554294: ldur            x16, [fp, #-0x60]
    // 0x554298: SaveReg r16
    //     0x554298: str             x16, [SP, #-8]!
    // 0x55429c: r0 = _interpolate()
    //     0x55429c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x5542a0: add             SP, SP, #8
    // 0x5542a4: ldur            x16, [fp, #-0x38]
    // 0x5542a8: ldur            lr, [fp, #-0x58]
    // 0x5542ac: stp             lr, x16, [SP, #-0x10]!
    // 0x5542b0: SaveReg r0
    //     0x5542b0: str             x0, [SP, #-8]!
    // 0x5542b4: ldur            x0, [fp, #-0x38]
    // 0x5542b8: ClosureCall
    //     0x5542b8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x5542bc: ldur            x2, [x0, #0x1f]
    //     0x5542c0: blr             x2
    // 0x5542c4: add             SP, SP, #0x18
    // 0x5542c8: ldur            x0, [fp, #-0x18]
    // 0x5542cc: add             x7, x0, #1
    // 0x5542d0: ldur            x1, [fp, #-0x38]
    // 0x5542d4: ldur            x2, [fp, #-0x30]
    // 0x5542d8: ldur            x4, [fp, #-0x28]
    // 0x5542dc: ldur            x5, [fp, #-0x20]
    // 0x5542e0: b               #0x553f48
    // 0x5542e4: ldur            x3, [fp, #-8]
    // 0x5542e8: ldr             x0, [fp, #0x18]
    // 0x5542ec: r2 = Null
    //     0x5542ec: mov             x2, NULL
    // 0x5542f0: r1 = Null
    //     0x5542f0: mov             x1, NULL
    // 0x5542f4: cmp             w0, NULL
    // 0x5542f8: b.eq            #0x554390
    // 0x5542fc: branchIfSmi(r0, 0x554390)
    //     0x5542fc: tbz             w0, #0, #0x554390
    // 0x554300: r3 = LoadClassIdInstr(r0)
    //     0x554300: ldur            x3, [x0, #-1]
    //     0x554304: ubfx            x3, x3, #0xc, #0x14
    // 0x554308: r17 = 5696
    //     0x554308: mov             x17, #0x1640
    // 0x55430c: cmp             x3, x17
    // 0x554310: b.eq            #0x554398
    // 0x554314: r4 = LoadClassIdInstr(r0)
    //     0x554314: ldur            x4, [x0, #-1]
    //     0x554318: ubfx            x4, x4, #0xc, #0x14
    // 0x55431c: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x554320: ldr             x3, [x3, #0x18]
    // 0x554324: ldr             x3, [x3, x4, lsl #3]
    // 0x554328: LoadField: r3 = r3->field_2b
    //     0x554328: ldur            w3, [x3, #0x2b]
    // 0x55432c: DecompressPointer r3
    //     0x55432c: add             x3, x3, HEAP, lsl #32
    // 0x554330: cmp             w3, NULL
    // 0x554334: b.eq            #0x554390
    // 0x554338: LoadField: r3 = r3->field_f
    //     0x554338: ldur            w3, [x3, #0xf]
    // 0x55433c: lsr             x3, x3, #4
    // 0x554340: r17 = 5696
    //     0x554340: mov             x17, #0x1640
    // 0x554344: cmp             x3, x17
    // 0x554348: b.eq            #0x554398
    // 0x55434c: r3 = SubtypeTestCache
    //     0x55434c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14390] SubtypeTestCache
    //     0x554350: ldr             x3, [x3, #0x390]
    // 0x554354: r24 = Subtype1TestCacheStub
    //     0x554354: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x554358: LoadField: r30 = r24->field_7
    //     0x554358: ldur            lr, [x24, #7]
    // 0x55435c: blr             lr
    // 0x554360: cmp             w7, NULL
    // 0x554364: b.eq            #0x554370
    // 0x554368: tbnz            w7, #4, #0x554390
    // 0x55436c: b               #0x554398
    // 0x554370: r8 = Map
    //     0x554370: add             x8, PP, #0x14, lsl #12  ; [pp+0x14398] Type: Map
    //     0x554374: ldr             x8, [x8, #0x398]
    // 0x554378: r3 = SubtypeTestCache
    //     0x554378: add             x3, PP, #0x14, lsl #12  ; [pp+0x143a0] SubtypeTestCache
    //     0x55437c: ldr             x3, [x3, #0x3a0]
    // 0x554380: r24 = InstanceOfStub
    //     0x554380: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x554384: LoadField: r30 = r24->field_7
    //     0x554384: ldur            lr, [x24, #7]
    // 0x554388: blr             lr
    // 0x55438c: b               #0x55439c
    // 0x554390: r0 = false
    //     0x554390: add             x0, NULL, #0x30  ; false
    // 0x554394: b               #0x55439c
    // 0x554398: r0 = true
    //     0x554398: add             x0, NULL, #0x20  ; true
    // 0x55439c: tbnz            w0, #4, #0x5543e0
    // 0x5543a0: ldr             x0, [fp, #0x18]
    // 0x5543a4: ldur            x2, [fp, #-0x10]
    // 0x5543a8: r1 = Function '<anonymous closure>': static.
    //     0x5543a8: add             x1, PP, #0x14, lsl #12  ; [pp+0x143a8] AnonymousClosure: static (0x5544f4), in [package:dio/src/utils.dart] ::encodeMap (0x553b44)
    //     0x5543ac: ldr             x1, [x1, #0x3a8]
    // 0x5543b0: r0 = AllocateClosure()
    //     0x5543b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5543b4: mov             x1, x0
    // 0x5543b8: ldr             x0, [fp, #0x18]
    // 0x5543bc: r2 = LoadClassIdInstr(r0)
    //     0x5543bc: ldur            x2, [x0, #-1]
    //     0x5543c0: ubfx            x2, x2, #0xc, #0x14
    // 0x5543c4: stp             x1, x0, [SP, #-0x10]!
    // 0x5543c8: mov             x0, x2
    // 0x5543cc: r0 = GDT[cid_x0 + 0x66b]()
    //     0x5543cc: add             lr, x0, #0x66b
    //     0x5543d0: ldr             lr, [x21, lr, lsl #3]
    //     0x5543d4: blr             lr
    // 0x5543d8: add             SP, SP, #0x10
    // 0x5543dc: b               #0x5544d0
    // 0x5543e0: ldr             x0, [fp, #0x18]
    // 0x5543e4: ldur            x1, [fp, #-8]
    // 0x5543e8: LoadField: r2 = r1->field_f
    //     0x5543e8: ldur            w2, [x1, #0xf]
    // 0x5543ec: DecompressPointer r2
    //     0x5543ec: add             x2, x2, HEAP, lsl #32
    // 0x5543f0: cmp             w2, NULL
    // 0x5543f4: b.eq            #0x5544f0
    // 0x5543f8: ldr             x16, [fp, #0x10]
    // 0x5543fc: stp             x16, x2, [SP, #-0x10]!
    // 0x554400: SaveReg r0
    //     0x554400: str             x0, [SP, #-8]!
    // 0x554404: mov             x0, x2
    // 0x554408: ClosureCall
    //     0x554408: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x55440c: ldur            x2, [x0, #0x1f]
    //     0x554410: blr             x2
    // 0x554414: add             SP, SP, #0x18
    // 0x554418: stur            x0, [fp, #-0x10]
    // 0x55441c: cmp             w0, NULL
    // 0x554420: b.eq            #0x554450
    // 0x554424: SaveReg r0
    //     0x554424: str             x0, [SP, #-8]!
    // 0x554428: r0 = trim()
    //     0x554428: bl              #0x4f0838  ; [dart:core] _StringBase::trim
    // 0x55442c: add             SP, SP, #8
    // 0x554430: LoadField: r1 = r0->field_7
    //     0x554430: ldur            w1, [x0, #7]
    // 0x554434: DecompressPointer r1
    //     0x554434: add             x1, x1, HEAP, lsl #32
    // 0x554438: cbnz            w1, #0x554444
    // 0x55443c: r0 = false
    //     0x55443c: add             x0, NULL, #0x30  ; false
    // 0x554440: b               #0x554448
    // 0x554444: r0 = true
    //     0x554444: add             x0, NULL, #0x20  ; true
    // 0x554448: mov             x2, x0
    // 0x55444c: b               #0x554454
    // 0x554450: r2 = false
    //     0x554450: add             x2, NULL, #0x30  ; false
    // 0x554454: ldur            x1, [fp, #-8]
    // 0x554458: stur            x2, [fp, #-0x28]
    // 0x55445c: LoadField: r3 = r1->field_1b
    //     0x55445c: ldur            w3, [x1, #0x1b]
    // 0x554460: DecompressPointer r3
    //     0x554460: add             x3, x3, HEAP, lsl #32
    // 0x554464: mov             x0, x3
    // 0x554468: stur            x3, [fp, #-0x20]
    // 0x55446c: tbnz            w0, #5, #0x554474
    // 0x554470: r0 = AssertBoolean()
    //     0x554470: bl              #0xd67df0  ; AssertBooleanStub
    // 0x554474: ldur            x0, [fp, #-0x20]
    // 0x554478: tbz             w0, #4, #0x5544a4
    // 0x55447c: ldur            x0, [fp, #-0x28]
    // 0x554480: tbnz            w0, #4, #0x5544a4
    // 0x554484: ldur            x1, [fp, #-8]
    // 0x554488: LoadField: r2 = r1->field_17
    //     0x554488: ldur            w2, [x1, #0x17]
    // 0x55448c: DecompressPointer r2
    //     0x55448c: add             x2, x2, HEAP, lsl #32
    // 0x554490: r16 = "&"
    //     0x554490: add             x16, PP, #0xa, lsl #12  ; [pp+0xaac0] "&"
    //     0x554494: ldr             x16, [x16, #0xac0]
    // 0x554498: stp             x16, x2, [SP, #-0x10]!
    // 0x55449c: r0 = write()
    //     0x55449c: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0x5544a0: add             SP, SP, #0x10
    // 0x5544a4: ldur            x1, [fp, #-8]
    // 0x5544a8: ldur            x0, [fp, #-0x28]
    // 0x5544ac: r2 = false
    //     0x5544ac: add             x2, NULL, #0x30  ; false
    // 0x5544b0: StoreField: r1->field_1b = r2
    //     0x5544b0: stur            w2, [x1, #0x1b]
    // 0x5544b4: tbnz            w0, #4, #0x5544d0
    // 0x5544b8: LoadField: r0 = r1->field_17
    //     0x5544b8: ldur            w0, [x1, #0x17]
    // 0x5544bc: DecompressPointer r0
    //     0x5544bc: add             x0, x0, HEAP, lsl #32
    // 0x5544c0: ldur            x16, [fp, #-0x10]
    // 0x5544c4: stp             x16, x0, [SP, #-0x10]!
    // 0x5544c8: r0 = write()
    //     0x5544c8: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0x5544cc: add             SP, SP, #0x10
    // 0x5544d0: r0 = Null
    //     0x5544d0: mov             x0, NULL
    // 0x5544d4: LeaveFrame
    //     0x5544d4: mov             SP, fp
    //     0x5544d8: ldp             fp, lr, [SP], #0x10
    // 0x5544dc: ret
    //     0x5544dc: ret             
    // 0x5544e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5544e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5544e4: b               #0x553e2c
    // 0x5544e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5544e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5544ec: b               #0x553f60
    // 0x5544f0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x5544f0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static void <anonymous closure>(dynamic, dynamic, dynamic) {
    // ** addr: 0x5544f4, size: 0x2d8
    // 0x5544f4: EnterFrame
    //     0x5544f4: stp             fp, lr, [SP, #-0x10]!
    //     0x5544f8: mov             fp, SP
    // 0x5544fc: AllocStack(0x30)
    //     0x5544fc: sub             SP, SP, #0x30
    // 0x554500: SetupParameters()
    //     0x554500: ldr             x0, [fp, #0x20]
    //     0x554504: ldur            w1, [x0, #0x17]
    //     0x554508: add             x1, x1, HEAP, lsl #32
    //     0x55450c: stur            x1, [fp, #-8]
    // 0x554510: CheckStackOverflow
    //     0x554510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x554514: cmp             SP, x16
    //     0x554518: b.ls            #0x5547bc
    // 0x55451c: LoadField: r0 = r1->field_f
    //     0x55451c: ldur            w0, [x1, #0xf]
    // 0x554520: DecompressPointer r0
    //     0x554520: add             x0, x0, HEAP, lsl #32
    // 0x554524: r2 = LoadClassIdInstr(r0)
    //     0x554524: ldur            x2, [x0, #-1]
    //     0x554528: ubfx            x2, x2, #0xc, #0x14
    // 0x55452c: r16 = ""
    //     0x55452c: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x554530: stp             x16, x0, [SP, #-0x10]!
    // 0x554534: mov             x0, x2
    // 0x554538: mov             lr, x0
    // 0x55453c: ldr             lr, [x21, lr, lsl #3]
    // 0x554540: blr             lr
    // 0x554544: add             SP, SP, #0x10
    // 0x554548: tbnz            w0, #4, #0x554630
    // 0x55454c: ldur            x1, [fp, #-8]
    // 0x554550: LoadField: r2 = r1->field_b
    //     0x554550: ldur            w2, [x1, #0xb]
    // 0x554554: DecompressPointer r2
    //     0x554554: add             x2, x2, HEAP, lsl #32
    // 0x554558: stur            x2, [fp, #-0x18]
    // 0x55455c: LoadField: r1 = r2->field_2f
    //     0x55455c: ldur            w1, [x2, #0x2f]
    // 0x554560: DecompressPointer r1
    //     0x554560: add             x1, x1, HEAP, lsl #32
    // 0x554564: stur            x1, [fp, #-0x10]
    // 0x554568: LoadField: r0 = r2->field_2b
    //     0x554568: ldur            w0, [x2, #0x2b]
    // 0x55456c: DecompressPointer r0
    //     0x55456c: add             x0, x0, HEAP, lsl #32
    // 0x554570: ldr             x16, [fp, #0x10]
    // 0x554574: stp             x16, x0, [SP, #-0x10]!
    // 0x554578: ClosureCall
    //     0x554578: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x55457c: ldur            x2, [x0, #0x1f]
    //     0x554580: blr             x2
    // 0x554584: add             SP, SP, #0x10
    // 0x554588: mov             x3, x0
    // 0x55458c: ldur            x0, [fp, #-0x18]
    // 0x554590: stur            x3, [fp, #-0x28]
    // 0x554594: LoadField: r4 = r0->field_27
    //     0x554594: ldur            w4, [x0, #0x27]
    // 0x554598: DecompressPointer r4
    //     0x554598: add             x4, x4, HEAP, lsl #32
    // 0x55459c: ldr             x0, [fp, #0x18]
    // 0x5545a0: stur            x4, [fp, #-0x20]
    // 0x5545a4: r2 = Null
    //     0x5545a4: mov             x2, NULL
    // 0x5545a8: r1 = Null
    //     0x5545a8: mov             x1, NULL
    // 0x5545ac: r4 = 59
    //     0x5545ac: mov             x4, #0x3b
    // 0x5545b0: branchIfSmi(r0, 0x5545bc)
    //     0x5545b0: tbz             w0, #0, #0x5545bc
    // 0x5545b4: r4 = LoadClassIdInstr(r0)
    //     0x5545b4: ldur            x4, [x0, #-1]
    //     0x5545b8: ubfx            x4, x4, #0xc, #0x14
    // 0x5545bc: sub             x4, x4, #0x5d
    // 0x5545c0: cmp             x4, #3
    // 0x5545c4: b.ls            #0x5545d8
    // 0x5545c8: r8 = String
    //     0x5545c8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x5545cc: r3 = Null
    //     0x5545cc: add             x3, PP, #0x14, lsl #12  ; [pp+0x143b0] Null
    //     0x5545d0: ldr             x3, [x3, #0x3b0]
    // 0x5545d4: r0 = String()
    //     0x5545d4: bl              #0xd72afc  ; IsType_String_Stub
    // 0x5545d8: ldur            x0, [fp, #-0x20]
    // 0x5545dc: cmp             w0, NULL
    // 0x5545e0: b.eq            #0x5547c4
    // 0x5545e4: ldr             x16, [fp, #0x18]
    // 0x5545e8: stp             x16, x0, [SP, #-0x10]!
    // 0x5545ec: ClosureCall
    //     0x5545ec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5545f0: ldur            x2, [x0, #0x1f]
    //     0x5545f4: blr             x2
    // 0x5545f8: add             SP, SP, #0x10
    // 0x5545fc: SaveReg r0
    //     0x5545fc: str             x0, [SP, #-8]!
    // 0x554600: r0 = _interpolateSingle()
    //     0x554600: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0x554604: add             SP, SP, #8
    // 0x554608: ldur            x16, [fp, #-0x10]
    // 0x55460c: ldur            lr, [fp, #-0x28]
    // 0x554610: stp             lr, x16, [SP, #-0x10]!
    // 0x554614: SaveReg r0
    //     0x554614: str             x0, [SP, #-8]!
    // 0x554618: ldur            x0, [fp, #-0x10]
    // 0x55461c: ClosureCall
    //     0x55461c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x554620: ldur            x2, [x0, #0x1f]
    //     0x554624: blr             x2
    // 0x554628: add             SP, SP, #0x18
    // 0x55462c: b               #0x5547ac
    // 0x554630: ldur            x1, [fp, #-8]
    // 0x554634: LoadField: r2 = r1->field_b
    //     0x554634: ldur            w2, [x1, #0xb]
    // 0x554638: DecompressPointer r2
    //     0x554638: add             x2, x2, HEAP, lsl #32
    // 0x55463c: stur            x2, [fp, #-0x18]
    // 0x554640: LoadField: r3 = r2->field_2f
    //     0x554640: ldur            w3, [x2, #0x2f]
    // 0x554644: DecompressPointer r3
    //     0x554644: add             x3, x3, HEAP, lsl #32
    // 0x554648: stur            x3, [fp, #-0x10]
    // 0x55464c: LoadField: r0 = r2->field_2b
    //     0x55464c: ldur            w0, [x2, #0x2b]
    // 0x554650: DecompressPointer r0
    //     0x554650: add             x0, x0, HEAP, lsl #32
    // 0x554654: ldr             x16, [fp, #0x10]
    // 0x554658: stp             x16, x0, [SP, #-0x10]!
    // 0x55465c: ClosureCall
    //     0x55465c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x554660: ldur            x2, [x0, #0x1f]
    //     0x554664: blr             x2
    // 0x554668: add             SP, SP, #0x10
    // 0x55466c: mov             x3, x0
    // 0x554670: ldur            x0, [fp, #-8]
    // 0x554674: stur            x3, [fp, #-0x28]
    // 0x554678: LoadField: r4 = r0->field_f
    //     0x554678: ldur            w4, [x0, #0xf]
    // 0x55467c: DecompressPointer r4
    //     0x55467c: add             x4, x4, HEAP, lsl #32
    // 0x554680: stur            x4, [fp, #-0x20]
    // 0x554684: r1 = Null
    //     0x554684: mov             x1, NULL
    // 0x554688: r2 = 8
    //     0x554688: mov             x2, #8
    // 0x55468c: r0 = AllocateArray()
    //     0x55468c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x554690: mov             x3, x0
    // 0x554694: ldur            x0, [fp, #-0x20]
    // 0x554698: stur            x3, [fp, #-0x30]
    // 0x55469c: StoreField: r3->field_f = r0
    //     0x55469c: stur            w0, [x3, #0xf]
    // 0x5546a0: ldur            x4, [fp, #-0x18]
    // 0x5546a4: LoadField: r0 = r4->field_1f
    //     0x5546a4: ldur            w0, [x4, #0x1f]
    // 0x5546a8: DecompressPointer r0
    //     0x5546a8: add             x0, x0, HEAP, lsl #32
    // 0x5546ac: StoreField: r3->field_13 = r0
    //     0x5546ac: stur            w0, [x3, #0x13]
    // 0x5546b0: LoadField: r5 = r4->field_27
    //     0x5546b0: ldur            w5, [x4, #0x27]
    // 0x5546b4: DecompressPointer r5
    //     0x5546b4: add             x5, x5, HEAP, lsl #32
    // 0x5546b8: ldr             x0, [fp, #0x18]
    // 0x5546bc: stur            x5, [fp, #-8]
    // 0x5546c0: r2 = Null
    //     0x5546c0: mov             x2, NULL
    // 0x5546c4: r1 = Null
    //     0x5546c4: mov             x1, NULL
    // 0x5546c8: r4 = 59
    //     0x5546c8: mov             x4, #0x3b
    // 0x5546cc: branchIfSmi(r0, 0x5546d8)
    //     0x5546cc: tbz             w0, #0, #0x5546d8
    // 0x5546d0: r4 = LoadClassIdInstr(r0)
    //     0x5546d0: ldur            x4, [x0, #-1]
    //     0x5546d4: ubfx            x4, x4, #0xc, #0x14
    // 0x5546d8: sub             x4, x4, #0x5d
    // 0x5546dc: cmp             x4, #3
    // 0x5546e0: b.ls            #0x5546f4
    // 0x5546e4: r8 = String
    //     0x5546e4: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x5546e8: r3 = Null
    //     0x5546e8: add             x3, PP, #0x14, lsl #12  ; [pp+0x143c0] Null
    //     0x5546ec: ldr             x3, [x3, #0x3c0]
    // 0x5546f0: r0 = String()
    //     0x5546f0: bl              #0xd72afc  ; IsType_String_Stub
    // 0x5546f4: ldur            x0, [fp, #-8]
    // 0x5546f8: cmp             w0, NULL
    // 0x5546fc: b.eq            #0x5547c8
    // 0x554700: ldr             x16, [fp, #0x18]
    // 0x554704: stp             x16, x0, [SP, #-0x10]!
    // 0x554708: ClosureCall
    //     0x554708: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x55470c: ldur            x2, [x0, #0x1f]
    //     0x554710: blr             x2
    // 0x554714: add             SP, SP, #0x10
    // 0x554718: ldur            x1, [fp, #-0x30]
    // 0x55471c: ArrayStore: r1[2] = r0  ; List_4
    //     0x55471c: add             x25, x1, #0x17
    //     0x554720: str             w0, [x25]
    //     0x554724: tbz             w0, #0, #0x554740
    //     0x554728: ldurb           w16, [x1, #-1]
    //     0x55472c: ldurb           w17, [x0, #-1]
    //     0x554730: and             x16, x17, x16, lsr #2
    //     0x554734: tst             x16, HEAP, lsr #32
    //     0x554738: b.eq            #0x554740
    //     0x55473c: bl              #0xd67e5c
    // 0x554740: ldur            x0, [fp, #-0x18]
    // 0x554744: LoadField: r1 = r0->field_23
    //     0x554744: ldur            w1, [x0, #0x23]
    // 0x554748: DecompressPointer r1
    //     0x554748: add             x1, x1, HEAP, lsl #32
    // 0x55474c: mov             x0, x1
    // 0x554750: ldur            x1, [fp, #-0x30]
    // 0x554754: ArrayStore: r1[3] = r0  ; List_4
    //     0x554754: add             x25, x1, #0x1b
    //     0x554758: str             w0, [x25]
    //     0x55475c: tbz             w0, #0, #0x554778
    //     0x554760: ldurb           w16, [x1, #-1]
    //     0x554764: ldurb           w17, [x0, #-1]
    //     0x554768: and             x16, x17, x16, lsr #2
    //     0x55476c: tst             x16, HEAP, lsr #32
    //     0x554770: b.eq            #0x554778
    //     0x554774: bl              #0xd67e5c
    // 0x554778: ldur            x16, [fp, #-0x30]
    // 0x55477c: SaveReg r16
    //     0x55477c: str             x16, [SP, #-8]!
    // 0x554780: r0 = _interpolate()
    //     0x554780: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x554784: add             SP, SP, #8
    // 0x554788: ldur            x16, [fp, #-0x10]
    // 0x55478c: ldur            lr, [fp, #-0x28]
    // 0x554790: stp             lr, x16, [SP, #-0x10]!
    // 0x554794: SaveReg r0
    //     0x554794: str             x0, [SP, #-8]!
    // 0x554798: ldur            x0, [fp, #-0x10]
    // 0x55479c: ClosureCall
    //     0x55479c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x5547a0: ldur            x2, [x0, #0x1f]
    //     0x5547a4: blr             x2
    // 0x5547a8: add             SP, SP, #0x18
    // 0x5547ac: r0 = Null
    //     0x5547ac: mov             x0, NULL
    // 0x5547b0: LeaveFrame
    //     0x5547b0: mov             SP, fp
    //     0x5547b4: ldp             fp, lr, [SP], #0x10
    // 0x5547b8: ret
    //     0x5547b8: ret             
    // 0x5547bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5547bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5547c0: b               #0x55451c
    // 0x5547c4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x5547c4: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x5547c8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x5547c8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static Object? maybeEncode(dynamic, Object?) {
    // ** addr: 0x5547cc, size: 0xd4
    // 0x5547cc: EnterFrame
    //     0x5547cc: stp             fp, lr, [SP, #-0x10]!
    //     0x5547d0: mov             fp, SP
    // 0x5547d4: AllocStack(0x10)
    //     0x5547d4: sub             SP, SP, #0x10
    // 0x5547d8: SetupParameters()
    //     0x5547d8: ldr             x0, [fp, #0x18]
    //     0x5547dc: ldur            w1, [x0, #0x17]
    //     0x5547e0: add             x1, x1, HEAP, lsl #32
    //     0x5547e4: stur            x1, [fp, #-0x10]
    // 0x5547e8: CheckStackOverflow
    //     0x5547e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5547ec: cmp             SP, x16
    //     0x5547f0: b.ls            #0x554894
    // 0x5547f4: LoadField: r2 = r1->field_13
    //     0x5547f4: ldur            w2, [x1, #0x13]
    // 0x5547f8: DecompressPointer r2
    //     0x5547f8: add             x2, x2, HEAP, lsl #32
    // 0x5547fc: mov             x0, x2
    // 0x554800: stur            x2, [fp, #-8]
    // 0x554804: tbnz            w0, #5, #0x55480c
    // 0x554808: r0 = AssertBoolean()
    //     0x554808: bl              #0xd67df0  ; AssertBooleanStub
    // 0x55480c: ldur            x0, [fp, #-8]
    // 0x554810: tbz             w0, #4, #0x55481c
    // 0x554814: ldr             x0, [fp, #0x10]
    // 0x554818: b               #0x554888
    // 0x55481c: ldr             x0, [fp, #0x10]
    // 0x554820: cmp             w0, NULL
    // 0x554824: b.eq            #0x554888
    // 0x554828: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x554828: mov             x1, #0x76
    //     0x55482c: tbz             w0, #0, #0x55483c
    //     0x554830: ldur            x1, [x0, #-1]
    //     0x554834: ubfx            x1, x1, #0xc, #0x14
    //     0x554838: lsl             x1, x1, #1
    // 0x55483c: r2 = LoadInt32Instr(r1)
    //     0x55483c: sbfx            x2, x1, #1, #0x1f
    // 0x554840: cmp             x2, #0x5d
    // 0x554844: b.lt            #0x554888
    // 0x554848: cmp             x2, #0x60
    // 0x55484c: b.gt            #0x554888
    // 0x554850: ldur            x1, [fp, #-0x10]
    // 0x554854: LoadField: r2 = r1->field_27
    //     0x554854: ldur            w2, [x1, #0x27]
    // 0x554858: DecompressPointer r2
    //     0x554858: add             x2, x2, HEAP, lsl #32
    // 0x55485c: cmp             w2, NULL
    // 0x554860: b.eq            #0x55489c
    // 0x554864: stp             x0, x2, [SP, #-0x10]!
    // 0x554868: mov             x0, x2
    // 0x55486c: ClosureCall
    //     0x55486c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x554870: ldur            x2, [x0, #0x1f]
    //     0x554874: blr             x2
    // 0x554878: add             SP, SP, #0x10
    // 0x55487c: LeaveFrame
    //     0x55487c: mov             SP, fp
    //     0x554880: ldp             fp, lr, [SP], #0x10
    // 0x554884: ret
    //     0x554884: ret             
    // 0x554888: LeaveFrame
    //     0x554888: mov             SP, fp
    //     0x55488c: ldp             fp, lr, [SP], #0x10
    // 0x554890: ret
    //     0x554890: ret             
    // 0x554894: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x554894: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x554898: b               #0x5547f4
    // 0x55489c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x55489c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ writeStreamToSink(/* No info */) {
    // ** addr: 0x55a0fc, size: 0x13c
    // 0x55a0fc: EnterFrame
    //     0x55a0fc: stp             fp, lr, [SP, #-0x10]!
    //     0x55a100: mov             fp, SP
    // 0x55a104: AllocStack(0x18)
    //     0x55a104: sub             SP, SP, #0x18
    // 0x55a108: CheckStackOverflow
    //     0x55a108: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a10c: cmp             SP, x16
    //     0x55a110: b.ls            #0x55a230
    // 0x55a114: r1 = Null
    //     0x55a114: mov             x1, NULL
    // 0x55a118: r0 = _Future()
    //     0x55a118: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x55a11c: mov             x1, x0
    // 0x55a120: r0 = 0
    //     0x55a120: mov             x0, #0
    // 0x55a124: stur            x1, [fp, #-8]
    // 0x55a128: StoreField: r1->field_b = r0
    //     0x55a128: stur            x0, [x1, #0xb]
    // 0x55a12c: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x55a12c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x55a130: ldr             x0, [x0, #0xb58]
    //     0x55a134: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x55a138: cmp             w0, w16
    //     0x55a13c: b.ne            #0x55a148
    //     0x55a140: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x55a144: bl              #0xd67d44
    // 0x55a148: mov             x1, x0
    // 0x55a14c: ldur            x0, [fp, #-8]
    // 0x55a150: StoreField: r0->field_13 = r1
    //     0x55a150: stur            w1, [x0, #0x13]
    // 0x55a154: r1 = Null
    //     0x55a154: mov             x1, NULL
    // 0x55a158: r0 = _AsyncCompleter()
    //     0x55a158: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x55a15c: mov             x1, x0
    // 0x55a160: ldur            x0, [fp, #-8]
    // 0x55a164: stur            x1, [fp, #-0x10]
    // 0x55a168: StoreField: r1->field_b = r0
    //     0x55a168: stur            w0, [x1, #0xb]
    // 0x55a16c: r1 = 1
    //     0x55a16c: mov             x1, #1
    // 0x55a170: r0 = AllocateContext()
    //     0x55a170: bl              #0xd68aa4  ; AllocateContextStub
    // 0x55a174: mov             x1, x0
    // 0x55a178: ldur            x0, [fp, #-0x10]
    // 0x55a17c: stur            x1, [fp, #-0x18]
    // 0x55a180: StoreField: r1->field_f = r0
    //     0x55a180: stur            w0, [x1, #0xf]
    // 0x55a184: ldr             x2, [fp, #0x10]
    // 0x55a188: r0 = LoadClassIdInstr(r2)
    //     0x55a188: ldur            x0, [x2, #-1]
    //     0x55a18c: ubfx            x0, x0, #0xc, #0x14
    // 0x55a190: SaveReg r2
    //     0x55a190: str             x2, [SP, #-8]!
    // 0x55a194: r0 = GDT[cid_x0 + 0xe77]()
    //     0x55a194: add             lr, x0, #0xe77
    //     0x55a198: ldr             lr, [x21, lr, lsl #3]
    //     0x55a19c: blr             lr
    // 0x55a1a0: add             SP, SP, #8
    // 0x55a1a4: mov             x3, x0
    // 0x55a1a8: r2 = Null
    //     0x55a1a8: mov             x2, NULL
    // 0x55a1ac: r1 = Null
    //     0x55a1ac: mov             x1, NULL
    // 0x55a1b0: stur            x3, [fp, #-0x10]
    // 0x55a1b4: r8 = (dynamic this, dynamic) => void?
    //     0x55a1b4: add             x8, PP, #0x13, lsl #12  ; [pp+0x13fb0] FunctionType: (dynamic this, dynamic) => void?
    //     0x55a1b8: ldr             x8, [x8, #0xfb0]
    // 0x55a1bc: r3 = Null
    //     0x55a1bc: add             x3, PP, #0x14, lsl #12  ; [pp+0x14628] Null
    //     0x55a1c0: ldr             x3, [x3, #0x628]
    // 0x55a1c4: r0 = DefaultTypeTest()
    //     0x55a1c4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x55a1c8: ldr             x0, [fp, #0x10]
    // 0x55a1cc: r1 = LoadClassIdInstr(r0)
    //     0x55a1cc: ldur            x1, [x0, #-1]
    //     0x55a1d0: ubfx            x1, x1, #0xc, #0x14
    // 0x55a1d4: SaveReg r0
    //     0x55a1d4: str             x0, [SP, #-8]!
    // 0x55a1d8: mov             x0, x1
    // 0x55a1dc: r0 = GDT[cid_x0 + 0x9bd]()
    //     0x55a1dc: add             lr, x0, #0x9bd
    //     0x55a1e0: ldr             lr, [x21, lr, lsl #3]
    //     0x55a1e4: blr             lr
    // 0x55a1e8: add             SP, SP, #8
    // 0x55a1ec: ldur            x2, [fp, #-0x18]
    // 0x55a1f0: r1 = Function '<anonymous closure>': static.
    //     0x55a1f0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14638] AnonymousClosure: static (0x55a238), in [package:dio/src/utils.dart] ::writeStreamToSink (0x55a0fc)
    //     0x55a1f4: ldr             x1, [x1, #0x638]
    // 0x55a1f8: stur            x0, [fp, #-0x18]
    // 0x55a1fc: r0 = AllocateClosure()
    //     0x55a1fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x55a200: ldr             x16, [fp, #0x18]
    // 0x55a204: ldur            lr, [fp, #-0x10]
    // 0x55a208: stp             lr, x16, [SP, #-0x10]!
    // 0x55a20c: ldur            x16, [fp, #-0x18]
    // 0x55a210: stp             x0, x16, [SP, #-0x10]!
    // 0x55a214: r4 = const [0, 0x4, 0x4, 0x2, onDone, 0x3, onError, 0x2, null]
    //     0x55a214: ldr             x4, [PP, #0x7a08]  ; [pp+0x7a08] List(9) [0, 0x4, 0x4, 0x2, "onDone", 0x3, "onError", 0x2, Null]
    // 0x55a218: r0 = listen()
    //     0x55a218: bl              #0xc5955c  ; [dart:io] _FileStream::listen
    // 0x55a21c: add             SP, SP, #0x20
    // 0x55a220: ldur            x0, [fp, #-8]
    // 0x55a224: LeaveFrame
    //     0x55a224: mov             SP, fp
    //     0x55a228: ldp             fp, lr, [SP], #0x10
    // 0x55a22c: ret
    //     0x55a22c: ret             
    // 0x55a230: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a230: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a234: b               #0x55a114
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x55a238, size: 0x4c
    // 0x55a238: EnterFrame
    //     0x55a238: stp             fp, lr, [SP, #-0x10]!
    //     0x55a23c: mov             fp, SP
    // 0x55a240: ldr             x0, [fp, #0x10]
    // 0x55a244: LoadField: r1 = r0->field_17
    //     0x55a244: ldur            w1, [x0, #0x17]
    // 0x55a248: DecompressPointer r1
    //     0x55a248: add             x1, x1, HEAP, lsl #32
    // 0x55a24c: CheckStackOverflow
    //     0x55a24c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a250: cmp             SP, x16
    //     0x55a254: b.ls            #0x55a27c
    // 0x55a258: LoadField: r0 = r1->field_f
    //     0x55a258: ldur            w0, [x1, #0xf]
    // 0x55a25c: DecompressPointer r0
    //     0x55a25c: add             x0, x0, HEAP, lsl #32
    // 0x55a260: SaveReg r0
    //     0x55a260: str             x0, [SP, #-8]!
    // 0x55a264: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x55a264: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x55a268: r0 = complete()
    //     0x55a268: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x55a26c: add             SP, SP, #8
    // 0x55a270: LeaveFrame
    //     0x55a270: mov             SP, fp
    //     0x55a274: ldp             fp, lr, [SP], #0x10
    // 0x55a278: ret
    //     0x55a278: ret             
    // 0x55a27c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a27c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a280: b               #0x55a258
  }
}

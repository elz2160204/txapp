// lib: , url: package:dio/src/interceptors/imply_content_type.dart

// class id: 1048890, size: 0x8
class :: {
}

// class id: 4538, size: 0x8, field offset: 0x8
//   const constructor, 
class ImplyContentTypeInterceptor extends Interceptor {

  [closure] void onRequest(dynamic, RequestOptions, RequestInterceptorHandler) {
    // ** addr: 0x527d6c, size: 0x54
    // 0x527d6c: EnterFrame
    //     0x527d6c: stp             fp, lr, [SP, #-0x10]!
    //     0x527d70: mov             fp, SP
    // 0x527d74: ldr             x0, [fp, #0x20]
    // 0x527d78: LoadField: r1 = r0->field_17
    //     0x527d78: ldur            w1, [x0, #0x17]
    // 0x527d7c: DecompressPointer r1
    //     0x527d7c: add             x1, x1, HEAP, lsl #32
    // 0x527d80: CheckStackOverflow
    //     0x527d80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x527d84: cmp             SP, x16
    //     0x527d88: b.ls            #0x527db8
    // 0x527d8c: LoadField: r0 = r1->field_f
    //     0x527d8c: ldur            w0, [x1, #0xf]
    // 0x527d90: DecompressPointer r0
    //     0x527d90: add             x0, x0, HEAP, lsl #32
    // 0x527d94: ldr             x16, [fp, #0x18]
    // 0x527d98: stp             x16, x0, [SP, #-0x10]!
    // 0x527d9c: ldr             x16, [fp, #0x10]
    // 0x527da0: SaveReg r16
    //     0x527da0: str             x16, [SP, #-8]!
    // 0x527da4: r0 = onRequest()
    //     0x527da4: bl              #0x527dc0  ; [package:dio/src/interceptors/imply_content_type.dart] ImplyContentTypeInterceptor::onRequest
    // 0x527da8: add             SP, SP, #0x18
    // 0x527dac: LeaveFrame
    //     0x527dac: mov             SP, fp
    //     0x527db0: ldp             fp, lr, [SP], #0x10
    // 0x527db4: ret
    //     0x527db4: ret             
    // 0x527db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x527db8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x527dbc: b               #0x527d8c
  }
  _ onRequest(/* No info */) {
    // ** addr: 0x527dc0, size: 0x130
    // 0x527dc0: EnterFrame
    //     0x527dc0: stp             fp, lr, [SP, #-0x10]!
    //     0x527dc4: mov             fp, SP
    // 0x527dc8: AllocStack(0x8)
    //     0x527dc8: sub             SP, SP, #8
    // 0x527dcc: CheckStackOverflow
    //     0x527dcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x527dd0: cmp             SP, x16
    //     0x527dd4: b.ls            #0x527ee8
    // 0x527dd8: ldr             x0, [fp, #0x18]
    // 0x527ddc: LoadField: r1 = r0->field_53
    //     0x527ddc: ldur            w1, [x0, #0x53]
    // 0x527de0: DecompressPointer r1
    //     0x527de0: add             x1, x1, HEAP, lsl #32
    // 0x527de4: stur            x1, [fp, #-8]
    // 0x527de8: cmp             w1, NULL
    // 0x527dec: b.eq            #0x527ec4
    // 0x527df0: SaveReg r0
    //     0x527df0: str             x0, [SP, #-8]!
    // 0x527df4: r0 = contentType()
    //     0x527df4: bl              #0x5280ac  ; [package:dio/src/options.dart] _RequestConfig::contentType
    // 0x527df8: add             SP, SP, #8
    // 0x527dfc: cmp             w0, NULL
    // 0x527e00: b.ne            #0x527ec4
    // 0x527e04: ldur            x0, [fp, #-8]
    // 0x527e08: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x527e08: mov             x1, #0x76
    //     0x527e0c: tbz             w0, #0, #0x527e1c
    //     0x527e10: ldur            x1, [x0, #-1]
    //     0x527e14: ubfx            x1, x1, #0xc, #0x14
    //     0x527e18: lsl             x1, x1, #1
    // 0x527e1c: r17 = 9072
    //     0x527e1c: mov             x17, #0x2370
    // 0x527e20: cmp             w1, w17
    // 0x527e24: b.ne            #0x527e34
    // 0x527e28: r0 = "multipart/form-data"
    //     0x527e28: add             x0, PP, #0x12, lsl #12  ; [pp+0x12e98] "multipart/form-data"
    //     0x527e2c: ldr             x0, [x0, #0xe98]
    // 0x527e30: b               #0x527eb4
    // 0x527e34: r2 = Null
    //     0x527e34: mov             x2, NULL
    // 0x527e38: r1 = Null
    //     0x527e38: mov             x1, NULL
    // 0x527e3c: cmp             w0, NULL
    // 0x527e40: b.eq            #0x527e94
    // 0x527e44: branchIfSmi(r0, 0x527e94)
    //     0x527e44: tbz             w0, #0, #0x527e94
    // 0x527e48: r8 = List<Map>
    //     0x527e48: add             x8, PP, #0x12, lsl #12  ; [pp+0x12ea0] Type: List<Map>
    //     0x527e4c: ldr             x8, [x8, #0xea0]
    // 0x527e50: r3 = SubtypeTestCache
    //     0x527e50: add             x3, PP, #0x12, lsl #12  ; [pp+0x12ea8] SubtypeTestCache
    //     0x527e54: ldr             x3, [x3, #0xea8]
    // 0x527e58: r24 = Subtype3TestCacheStub
    //     0x527e58: ldr             x24, [PP, #0x10]  ; [pp+0x10] Stub: Subtype3TestCache (0x4ae294)
    // 0x527e5c: LoadField: r30 = r24->field_7
    //     0x527e5c: ldur            lr, [x24, #7]
    // 0x527e60: blr             lr
    // 0x527e64: cmp             w7, NULL
    // 0x527e68: b.eq            #0x527e74
    // 0x527e6c: tbnz            w7, #4, #0x527e94
    // 0x527e70: b               #0x527e9c
    // 0x527e74: r8 = List<Map>
    //     0x527e74: add             x8, PP, #0x12, lsl #12  ; [pp+0x12eb0] Type: List<Map>
    //     0x527e78: ldr             x8, [x8, #0xeb0]
    // 0x527e7c: r3 = SubtypeTestCache
    //     0x527e7c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12eb8] SubtypeTestCache
    //     0x527e80: ldr             x3, [x3, #0xeb8]
    // 0x527e84: r24 = InstanceOfStub
    //     0x527e84: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x527e88: LoadField: r30 = r24->field_7
    //     0x527e88: ldur            lr, [x24, #7]
    // 0x527e8c: blr             lr
    // 0x527e90: b               #0x527ea0
    // 0x527e94: r0 = false
    //     0x527e94: add             x0, NULL, #0x30  ; false
    // 0x527e98: b               #0x527ea0
    // 0x527e9c: r0 = true
    //     0x527e9c: add             x0, NULL, #0x20  ; true
    // 0x527ea0: tbnz            w0, #4, #0x527eb0
    // 0x527ea4: r0 = "application/json"
    //     0x527ea4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12ec0] "application/json"
    //     0x527ea8: ldr             x0, [x0, #0xec0]
    // 0x527eac: b               #0x527eb4
    // 0x527eb0: r0 = Null
    //     0x527eb0: mov             x0, NULL
    // 0x527eb4: ldr             x16, [fp, #0x18]
    // 0x527eb8: stp             x0, x16, [SP, #-0x10]!
    // 0x527ebc: r0 = contentType=()
    //     0x527ebc: bl              #0x527f98  ; [package:dio/src/options.dart] _RequestConfig::contentType=
    // 0x527ec0: add             SP, SP, #0x10
    // 0x527ec4: ldr             x16, [fp, #0x10]
    // 0x527ec8: ldr             lr, [fp, #0x18]
    // 0x527ecc: stp             lr, x16, [SP, #-0x10]!
    // 0x527ed0: r0 = next()
    //     0x527ed0: bl              #0x527ef0  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::next
    // 0x527ed4: add             SP, SP, #0x10
    // 0x527ed8: r0 = Null
    //     0x527ed8: mov             x0, NULL
    // 0x527edc: LeaveFrame
    //     0x527edc: mov             SP, fp
    //     0x527ee0: ldp             fp, lr, [SP], #0x10
    // 0x527ee4: ret
    //     0x527ee4: ret             
    // 0x527ee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x527ee8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x527eec: b               #0x527dd8
  }
}

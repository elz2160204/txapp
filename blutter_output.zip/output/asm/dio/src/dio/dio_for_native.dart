// lib: , url: package:dio/src/dio/dio_for_native.dart

// class id: 1048885, size: 0x8
class :: {

  static _ createDio(/* No info */) {
    // ** addr: 0x55c104, size: 0x48
    // 0x55c104: EnterFrame
    //     0x55c104: stp             fp, lr, [SP, #-0x10]!
    //     0x55c108: mov             fp, SP
    // 0x55c10c: AllocStack(0x8)
    //     0x55c10c: sub             SP, SP, #8
    // 0x55c110: CheckStackOverflow
    //     0x55c110: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55c114: cmp             SP, x16
    //     0x55c118: b.ls            #0x55c144
    // 0x55c11c: r0 = DioForNative()
    //     0x55c11c: bl              #0x55e448  ; AllocateDioForNativeStub -> DioForNative (size=0x1c)
    // 0x55c120: stur            x0, [fp, #-8]
    // 0x55c124: ldr             x16, [fp, #0x10]
    // 0x55c128: stp             x16, x0, [SP, #-0x10]!
    // 0x55c12c: r0 = DioForNative()
    //     0x55c12c: bl              #0x55c14c  ; [package:dio/src/dio/dio_for_native.dart] DioForNative::DioForNative
    // 0x55c130: add             SP, SP, #0x10
    // 0x55c134: ldur            x0, [fp, #-8]
    // 0x55c138: LeaveFrame
    //     0x55c138: mov             SP, fp
    //     0x55c13c: ldp             fp, lr, [SP], #0x10
    // 0x55c140: ret
    //     0x55c140: ret             
    // 0x55c144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55c144: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55c148: b               #0x55c11c
  }
}

// class id: 4546, size: 0x1c, field offset: 0x8
//   transformed mixin,
abstract class _DioForNative&Object&DioMixin extends Object
     with DioMixin {

  late BaseOptions options; // offset: 0x8
  late HttpClientAdapter httpClientAdapter; // offset: 0x10

  _ request(/* No info */) async {
    // ** addr: 0x526f38, size: 0x170
    // 0x526f38: EnterFrame
    //     0x526f38: stp             fp, lr, [SP, #-0x10]!
    //     0x526f3c: mov             fp, SP
    // 0x526f40: AllocStack(0x40)
    //     0x526f40: sub             SP, SP, #0x40
    // 0x526f44: SetupParameters(_DioForNative&Object&DioMixin this /* r4, fp-0x38 */, dynamic _ /* r5, fp-0x30 */, dynamic _ /* r6, fp-0x28 */, dynamic _ /* r7, fp-0x20 */, dynamic _ /* r8, fp-0x18 */, {dynamic onReceiveProgress})
    //     0x526f44: stur            NULL, [fp, #-8]
    //     0x526f48: mov             x0, x4
    //     0x526f4c: ldur            w1, [x0, #0x13]
    //     0x526f50: add             x1, x1, HEAP, lsl #32
    //     0x526f54: sub             x2, x1, #0xa
    //     0x526f58: add             x4, fp, w2, sxtw #2
    //     0x526f5c: ldr             x4, [x4, #0x30]
    //     0x526f60: stur            x4, [fp, #-0x38]
    //     0x526f64: add             x5, fp, w2, sxtw #2
    //     0x526f68: ldr             x5, [x5, #0x28]
    //     0x526f6c: stur            x5, [fp, #-0x30]
    //     0x526f70: add             x6, fp, w2, sxtw #2
    //     0x526f74: ldr             x6, [x6, #0x20]
    //     0x526f78: stur            x6, [fp, #-0x28]
    //     0x526f7c: add             x7, fp, w2, sxtw #2
    //     0x526f80: ldr             x7, [x7, #0x18]
    //     0x526f84: stur            x7, [fp, #-0x20]
    //     0x526f88: add             x8, fp, w2, sxtw #2
    //     0x526f8c: ldr             x8, [x8, #0x10]
    //     0x526f90: stur            x8, [fp, #-0x18]
    //     0x526f94: ldur            w1, [x0, #0x1f]
    //     0x526f98: add             x1, x1, HEAP, lsl #32
    //     0x526f9c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12db8] "onReceiveProgress"
    //     0x526fa0: ldr             x16, [x16, #0xdb8]
    //     0x526fa4: cmp             w1, w16
    //     0x526fa8: b.eq            #0x526fac
    //     0x526fac: ldur            w1, [x0, #0xf]
    //     0x526fb0: add             x1, x1, HEAP, lsl #32
    //     0x526fb4: cbnz            w1, #0x526fc0
    //     0x526fb8: mov             x0, NULL
    //     0x526fbc: b               #0x526fd0
    //     0x526fc0: ldur            w1, [x0, #0x17]
    //     0x526fc4: add             x1, x1, HEAP, lsl #32
    //     0x526fc8: add             x0, fp, w1, sxtw #2
    //     0x526fcc: ldr             x0, [x0, #0x10]
    //     0x526fd0: stur            x0, [fp, #-0x10]
    // 0x526fd4: CheckStackOverflow
    //     0x526fd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x526fd8: cmp             SP, x16
    //     0x526fdc: b.ls            #0x527094
    // 0x526fe0: mov             x1, x0
    // 0x526fe4: r2 = Null
    //     0x526fe4: mov             x2, NULL
    // 0x526fe8: r3 = <Response<Y0>>
    //     0x526fe8: add             x3, PP, #0x12, lsl #12  ; [pp+0x12dc0] TypeArguments: <Response<Y0>>
    //     0x526fec: ldr             x3, [x3, #0xdc0]
    // 0x526ff0: r24 = InstantiateTypeArgumentsStub
    //     0x526ff0: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x526ff4: LoadField: r30 = r24->field_7
    //     0x526ff4: ldur            lr, [x24, #7]
    // 0x526ff8: blr             lr
    // 0x526ffc: mov             x1, x0
    // 0x527000: stur            x1, [fp, #-0x40]
    // 0x527004: r0 = InitAsync()
    //     0x527004: bl              #0x4b92e4  ; InitAsyncStub
    // 0x527008: ldur            x0, [fp, #-0x38]
    // 0x52700c: LoadField: r1 = r0->field_7
    //     0x52700c: ldur            w1, [x0, #7]
    // 0x527010: DecompressPointer r1
    //     0x527010: add             x1, x1, HEAP, lsl #32
    // 0x527014: r16 = Sentinel
    //     0x527014: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x527018: cmp             w1, w16
    // 0x52701c: b.eq            #0x52709c
    // 0x527020: stur            x1, [fp, #-0x40]
    // 0x527024: r0 = current()
    //     0x527024: bl              #0x4ff3d0  ; [dart:core] StackTrace::current
    // 0x527028: ldur            x16, [fp, #-0x18]
    // 0x52702c: ldur            lr, [fp, #-0x40]
    // 0x527030: stp             lr, x16, [SP, #-0x10]!
    // 0x527034: ldur            x16, [fp, #-0x30]
    // 0x527038: ldur            lr, [fp, #-0x28]
    // 0x52703c: stp             lr, x16, [SP, #-0x10]!
    // 0x527040: ldur            x16, [fp, #-0x20]
    // 0x527044: stp             x0, x16, [SP, #-0x10]!
    // 0x527048: r0 = compose()
    //     0x527048: bl              #0x55a9c4  ; [package:dio/src/options.dart] Options::compose
    // 0x52704c: add             SP, SP, #0x30
    // 0x527050: mov             x1, x0
    // 0x527054: ldur            x0, [fp, #-0x38]
    // 0x527058: LoadField: r2 = r0->field_17
    //     0x527058: ldur            w2, [x0, #0x17]
    // 0x52705c: DecompressPointer r2
    //     0x52705c: add             x2, x2, HEAP, lsl #32
    // 0x527060: tbz             w2, #4, #0x527080
    // 0x527064: ldur            x16, [fp, #-0x10]
    // 0x527068: stp             x0, x16, [SP, #-0x10]!
    // 0x52706c: SaveReg r1
    //     0x52706c: str             x1, [SP, #-8]!
    // 0x527070: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x527070: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x527074: r0 = fetch()
    //     0x527074: bl              #0x5273d0  ; [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::fetch
    // 0x527078: add             SP, SP, #0x18
    // 0x52707c: r0 = ReturnAsync()
    //     0x52707c: b               #0x501858  ; ReturnAsyncStub
    // 0x527080: stp             x1, NULL, [SP, #-0x10]!
    // 0x527084: r0 = DioException.connectionError()
    //     0x527084: bl              #0x5270a8  ; [package:dio/src/dio_exception.dart] DioException::DioException.connectionError
    // 0x527088: add             SP, SP, #0x10
    // 0x52708c: r0 = Throw()
    //     0x52708c: bl              #0xd67e38  ; ThrowStub
    // 0x527090: brk             #0
    // 0x527094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x527094: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x527098: b               #0x526fe0
    // 0x52709c: r9 = options
    //     0x52709c: add             x9, PP, #0x12, lsl #12  ; [pp+0x12dc8] Field <_DioForNative&Object&DioMixin@371344244.options>: late (offset: 0x8)
    //     0x5270a0: ldr             x9, [x9, #0xdc8]
    // 0x5270a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x5270a4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ fetch(/* No info */) async {
    // ** addr: 0x5273d0, size: 0x99c
    // 0x5273d0: EnterFrame
    //     0x5273d0: stp             fp, lr, [SP, #-0x10]!
    //     0x5273d4: mov             fp, SP
    // 0x5273d8: AllocStack(0xa8)
    //     0x5273d8: sub             SP, SP, #0xa8
    // 0x5273dc: SetupParameters(_DioForNative&Object&DioMixin this /* r2, fp-0x20 */, dynamic _ /* r3, fp-0x18 */)
    //     0x5273dc: stur            NULL, [fp, #-8]
    //     0x5273e0: mov             x0, #0
    //     0x5273e4: mov             x1, x4
    //     0x5273e8: add             x2, fp, w0, sxtw #2
    //     0x5273ec: ldr             x2, [x2, #0x18]
    //     0x5273f0: stur            x2, [fp, #-0x20]
    //     0x5273f4: add             x3, fp, w0, sxtw #2
    //     0x5273f8: ldr             x3, [x3, #0x10]
    //     0x5273fc: stur            x3, [fp, #-0x18]
    //     0x527400: ldur            w0, [x1, #0xf]
    //     0x527404: add             x0, x0, HEAP, lsl #32
    //     0x527408: cbnz            w0, #0x527414
    //     0x52740c: mov             x1, NULL
    //     0x527410: b               #0x527424
    //     0x527414: ldur            w0, [x1, #0x17]
    //     0x527418: add             x0, x0, HEAP, lsl #32
    //     0x52741c: add             x1, fp, w0, sxtw #2
    //     0x527420: ldr             x1, [x1, #0x10]
    //     0x527424: stur            x1, [fp, #-0x10]
    // 0x527428: CheckStackOverflow
    //     0x527428: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52742c: cmp             SP, x16
    //     0x527430: b.ls            #0x527d40
    // 0x527434: r1 = 2
    //     0x527434: mov             x1, #2
    // 0x527438: r0 = AllocateContext()
    //     0x527438: bl              #0xd68aa4  ; AllocateContextStub
    // 0x52743c: mov             x4, x0
    // 0x527440: ldur            x0, [fp, #-0x20]
    // 0x527444: stur            x4, [fp, #-0x28]
    // 0x527448: StoreField: r4->field_f = r0
    //     0x527448: stur            w0, [x4, #0xf]
    // 0x52744c: ldur            x1, [fp, #-0x18]
    // 0x527450: StoreField: r4->field_13 = r1
    //     0x527450: stur            w1, [x4, #0x13]
    // 0x527454: ldur            x1, [fp, #-0x10]
    // 0x527458: r2 = Null
    //     0x527458: mov             x2, NULL
    // 0x52745c: r3 = <Response<Y0>>
    //     0x52745c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12dc0] TypeArguments: <Response<Y0>>
    //     0x527460: ldr             x3, [x3, #0xdc0]
    // 0x527464: r24 = InstantiateTypeArgumentsStub
    //     0x527464: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x527468: LoadField: r30 = r24->field_7
    //     0x527468: ldur            lr, [x24, #7]
    // 0x52746c: blr             lr
    // 0x527470: mov             x1, x0
    // 0x527474: stur            x1, [fp, #-0x18]
    // 0x527478: r0 = InitAsync()
    //     0x527478: bl              #0x4b92e4  ; InitAsyncStub
    // 0x52747c: ldur            x1, [fp, #-0x10]
    // 0x527480: r2 = Null
    //     0x527480: mov             x2, NULL
    // 0x527484: r3 = Y0
    //     0x527484: ldr             x3, [PP, #0x51b8]  ; [pp+0x51b8] TypeParameter: Y0
    // 0x527488: r24 = InstantiateTypeNonNullableFunctionTypeParameterStub
    //     0x527488: add             x24, PP, #0xd, lsl #12  ; [pp+0xd440] Stub: InstantiateTypeNonNullableFunctionTypeParameter (0x4accb4)
    //     0x52748c: ldr             x24, [x24, #0x440]
    // 0x527490: LoadField: r30 = r24->field_7
    //     0x527490: ldur            lr, [x24, #7]
    // 0x527494: blr             lr
    // 0x527498: r1 = LoadClassIdInstr(r0)
    //     0x527498: ldur            x1, [x0, #-1]
    //     0x52749c: ubfx            x1, x1, #0xc, #0x14
    // 0x5274a0: ldr             x16, [THR, #0xf0]  ; THR::dynamic_type
    // 0x5274a4: stp             x16, x0, [SP, #-0x10]!
    // 0x5274a8: mov             x0, x1
    // 0x5274ac: mov             lr, x0
    // 0x5274b0: ldr             lr, [x21, lr, lsl #3]
    // 0x5274b4: blr             lr
    // 0x5274b8: add             SP, SP, #0x10
    // 0x5274bc: tbz             w0, #4, #0x52757c
    // 0x5274c0: ldur            x0, [fp, #-0x28]
    // 0x5274c4: LoadField: r1 = r0->field_13
    //     0x5274c4: ldur            w1, [x0, #0x13]
    // 0x5274c8: DecompressPointer r1
    //     0x5274c8: add             x1, x1, HEAP, lsl #32
    // 0x5274cc: LoadField: r2 = r1->field_1b
    //     0x5274cc: ldur            w2, [x1, #0x1b]
    // 0x5274d0: DecompressPointer r2
    //     0x5274d0: add             x2, x2, HEAP, lsl #32
    // 0x5274d4: r16 = Sentinel
    //     0x5274d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5274d8: cmp             w2, w16
    // 0x5274dc: b.eq            #0x527d48
    // 0x5274e0: r16 = Instance_ResponseType
    //     0x5274e0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12df0] Obj!ResponseType@b66591
    //     0x5274e4: ldr             x16, [x16, #0xdf0]
    // 0x5274e8: cmp             w2, w16
    // 0x5274ec: b.eq            #0x527580
    // 0x5274f0: r16 = Instance_ResponseType
    //     0x5274f0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12df8] Obj!ResponseType@b66571
    //     0x5274f4: ldr             x16, [x16, #0xdf8]
    // 0x5274f8: cmp             w2, w16
    // 0x5274fc: b.eq            #0x527580
    // 0x527500: ldur            x1, [fp, #-0x10]
    // 0x527504: r2 = Null
    //     0x527504: mov             x2, NULL
    // 0x527508: r3 = Y0
    //     0x527508: ldr             x3, [PP, #0x51b8]  ; [pp+0x51b8] TypeParameter: Y0
    // 0x52750c: r24 = InstantiateTypeNonNullableFunctionTypeParameterStub
    //     0x52750c: add             x24, PP, #0xd, lsl #12  ; [pp+0xd440] Stub: InstantiateTypeNonNullableFunctionTypeParameter (0x4accb4)
    //     0x527510: ldr             x24, [x24, #0x440]
    // 0x527514: LoadField: r30 = r24->field_7
    //     0x527514: ldur            lr, [x24, #7]
    // 0x527518: blr             lr
    // 0x52751c: r1 = LoadClassIdInstr(r0)
    //     0x52751c: ldur            x1, [x0, #-1]
    //     0x527520: ubfx            x1, x1, #0xc, #0x14
    // 0x527524: r16 = String
    //     0x527524: ldr             x16, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x527528: stp             x16, x0, [SP, #-0x10]!
    // 0x52752c: mov             x0, x1
    // 0x527530: mov             lr, x0
    // 0x527534: ldr             lr, [x21, lr, lsl #3]
    // 0x527538: blr             lr
    // 0x52753c: add             SP, SP, #0x10
    // 0x527540: tbnz            w0, #4, #0x527560
    // 0x527544: ldur            x0, [fp, #-0x28]
    // 0x527548: r1 = Instance_ResponseType
    //     0x527548: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e00] Obj!ResponseType@b66551
    //     0x52754c: ldr             x1, [x1, #0xe00]
    // 0x527550: LoadField: r2 = r0->field_13
    //     0x527550: ldur            w2, [x0, #0x13]
    // 0x527554: DecompressPointer r2
    //     0x527554: add             x2, x2, HEAP, lsl #32
    // 0x527558: StoreField: r2->field_1b = r1
    //     0x527558: stur            w1, [x2, #0x1b]
    // 0x52755c: b               #0x527580
    // 0x527560: ldur            x0, [fp, #-0x28]
    // 0x527564: r1 = Instance_ResponseType
    //     0x527564: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e08] Obj!ResponseType@b66531
    //     0x527568: ldr             x1, [x1, #0xe08]
    // 0x52756c: LoadField: r2 = r0->field_13
    //     0x52756c: ldur            w2, [x0, #0x13]
    // 0x527570: DecompressPointer r2
    //     0x527570: add             x2, x2, HEAP, lsl #32
    // 0x527574: StoreField: r2->field_1b = r1
    //     0x527574: stur            w1, [x2, #0x1b]
    // 0x527578: b               #0x527580
    // 0x52757c: ldur            x0, [fp, #-0x28]
    // 0x527580: ldur            x3, [fp, #-0x20]
    // 0x527584: ldur            x4, [fp, #-0x10]
    // 0x527588: mov             x2, x0
    // 0x52758c: r1 = Function '<anonymous closure>':.
    //     0x52758c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e10] AnonymousClosure: (0x55a974), in [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::fetch (0x5273d0)
    //     0x527590: ldr             x1, [x1, #0xe10]
    // 0x527594: r0 = AllocateClosure()
    //     0x527594: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x527598: ldur            x1, [fp, #-0x10]
    // 0x52759c: StoreField: r0->field_b = r1
    //     0x52759c: stur            w1, [x0, #0xb]
    // 0x5275a0: stp             x0, NULL, [SP, #-0x10]!
    // 0x5275a4: r0 = Future()
    //     0x5275a4: bl              #0x4b5784  ; [dart:async] Future::Future
    // 0x5275a8: add             SP, SP, #0x10
    // 0x5275ac: mov             x1, x0
    // 0x5275b0: ldur            x0, [fp, #-0x20]
    // 0x5275b4: stur            x1, [fp, #-0x30]
    // 0x5275b8: LoadField: r2 = r0->field_b
    //     0x5275b8: ldur            w2, [x0, #0xb]
    // 0x5275bc: DecompressPointer r2
    //     0x5275bc: add             x2, x2, HEAP, lsl #32
    // 0x5275c0: stur            x2, [fp, #-0x18]
    // 0x5275c4: SaveReg r2
    //     0x5275c4: str             x2, [SP, #-8]!
    // 0x5275c8: r0 = iterator()
    //     0x5275c8: bl              #0x70b268  ; [dart:collection] ListMixin::iterator
    // 0x5275cc: add             SP, SP, #8
    // 0x5275d0: mov             x1, x0
    // 0x5275d4: stur            x1, [fp, #-0x50]
    // 0x5275d8: LoadField: r2 = r1->field_b
    //     0x5275d8: ldur            w2, [x1, #0xb]
    // 0x5275dc: DecompressPointer r2
    //     0x5275dc: add             x2, x2, HEAP, lsl #32
    // 0x5275e0: stur            x2, [fp, #-0x48]
    // 0x5275e4: LoadField: r3 = r1->field_f
    //     0x5275e4: ldur            x3, [x1, #0xf]
    // 0x5275e8: stur            x3, [fp, #-0x40]
    // 0x5275ec: LoadField: r4 = r1->field_7
    //     0x5275ec: ldur            w4, [x1, #7]
    // 0x5275f0: DecompressPointer r4
    //     0x5275f0: add             x4, x4, HEAP, lsl #32
    // 0x5275f4: stur            x4, [fp, #-0x38]
    // 0x5275f8: ldur            x7, [fp, #-0x30]
    // 0x5275fc: ldur            x5, [fp, #-0x10]
    // 0x527600: ldur            x6, [fp, #-0x28]
    // 0x527604: stur            x7, [fp, #-0x20]
    // 0x527608: CheckStackOverflow
    //     0x527608: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52760c: cmp             SP, x16
    //     0x527610: b.ls            #0x527d54
    // 0x527614: r0 = LoadClassIdInstr(r2)
    //     0x527614: ldur            x0, [x2, #-1]
    //     0x527618: ubfx            x0, x0, #0xc, #0x14
    // 0x52761c: SaveReg r2
    //     0x52761c: str             x2, [SP, #-8]!
    // 0x527620: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x527620: mov             x17, #0xb8ea
    //     0x527624: add             lr, x0, x17
    //     0x527628: ldr             lr, [x21, lr, lsl #3]
    //     0x52762c: blr             lr
    // 0x527630: add             SP, SP, #8
    // 0x527634: r1 = LoadInt32Instr(r0)
    //     0x527634: sbfx            x1, x0, #1, #0x1f
    //     0x527638: tbz             w0, #0, #0x527640
    //     0x52763c: ldur            x1, [x0, #7]
    // 0x527640: ldur            x2, [fp, #-0x40]
    // 0x527644: cmp             x2, x1
    // 0x527648: b.ne            #0x527cf8
    // 0x52764c: ldur            x4, [fp, #-0x50]
    // 0x527650: ldur            x3, [fp, #-0x48]
    // 0x527654: LoadField: r5 = r4->field_17
    //     0x527654: ldur            x5, [x4, #0x17]
    // 0x527658: cmp             x5, x1
    // 0x52765c: b.lt            #0x527b9c
    // 0x527660: ldur            x0, [fp, #-0x10]
    // 0x527664: ldur            x3, [fp, #-0x28]
    // 0x527668: ldur            x5, [fp, #-0x20]
    // 0x52766c: StoreField: r4->field_1f = rNULL
    //     0x52766c: stur            NULL, [x4, #0x1f]
    // 0x527670: mov             x2, x3
    // 0x527674: r1 = Function '<anonymous closure>':.
    //     0x527674: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e18] AnonymousClosure: (0x52a90c), in [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::fetch (0x5273d0)
    //     0x527678: ldr             x1, [x1, #0xe18]
    // 0x52767c: r0 = AllocateClosure()
    //     0x52767c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x527680: ldur            x1, [fp, #-0x10]
    // 0x527684: stur            x0, [fp, #-0x30]
    // 0x527688: StoreField: r0->field_b = r1
    //     0x527688: stur            w1, [x0, #0xb]
    // 0x52768c: r1 = 1
    //     0x52768c: mov             x1, #1
    // 0x527690: r0 = AllocateContext()
    //     0x527690: bl              #0xd68aa4  ; AllocateContextStub
    // 0x527694: mov             x1, x0
    // 0x527698: ldur            x0, [fp, #-0x28]
    // 0x52769c: StoreField: r1->field_b = r0
    //     0x52769c: stur            w0, [x1, #0xb]
    // 0x5276a0: ldur            x2, [fp, #-0x30]
    // 0x5276a4: StoreField: r1->field_f = r2
    //     0x5276a4: stur            w2, [x1, #0xf]
    // 0x5276a8: mov             x2, x1
    // 0x5276ac: r1 = Function '<anonymous closure>':.
    //     0x5276ac: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e20] AnonymousClosure: (0x52a68c), of [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin
    //     0x5276b0: ldr             x1, [x1, #0xe20]
    // 0x5276b4: r0 = AllocateClosure()
    //     0x5276b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5276b8: ldur            x1, [fp, #-0x10]
    // 0x5276bc: StoreField: r0->field_b = r1
    //     0x5276bc: stur            w1, [x0, #0xb]
    // 0x5276c0: ldur            x6, [fp, #-0x20]
    // 0x5276c4: r2 = LoadClassIdInstr(r6)
    //     0x5276c4: ldur            x2, [x6, #-1]
    //     0x5276c8: ubfx            x2, x2, #0xc, #0x14
    // 0x5276cc: stp             x6, NULL, [SP, #-0x10]!
    // 0x5276d0: SaveReg r0
    //     0x5276d0: str             x0, [SP, #-8]!
    // 0x5276d4: mov             x0, x2
    // 0x5276d8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5276d8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5276dc: r0 = GDT[cid_x0 + -0xffe]()
    //     0x5276dc: sub             lr, x0, #0xffe
    //     0x5276e0: ldr             lr, [x21, lr, lsl #3]
    //     0x5276e4: blr             lr
    // 0x5276e8: add             SP, SP, #0x18
    // 0x5276ec: stur            x0, [fp, #-0x30]
    // 0x5276f0: ldur            x16, [fp, #-0x18]
    // 0x5276f4: SaveReg r16
    //     0x5276f4: str             x16, [SP, #-8]!
    // 0x5276f8: r0 = iterator()
    //     0x5276f8: bl              #0x70b268  ; [dart:collection] ListMixin::iterator
    // 0x5276fc: add             SP, SP, #8
    // 0x527700: mov             x1, x0
    // 0x527704: stur            x1, [fp, #-0x70]
    // 0x527708: LoadField: r2 = r1->field_b
    //     0x527708: ldur            w2, [x1, #0xb]
    // 0x52770c: DecompressPointer r2
    //     0x52770c: add             x2, x2, HEAP, lsl #32
    // 0x527710: stur            x2, [fp, #-0x68]
    // 0x527714: LoadField: r3 = r1->field_f
    //     0x527714: ldur            x3, [x1, #0xf]
    // 0x527718: stur            x3, [fp, #-0x60]
    // 0x52771c: LoadField: r4 = r1->field_7
    //     0x52771c: ldur            w4, [x1, #7]
    // 0x527720: DecompressPointer r4
    //     0x527720: add             x4, x4, HEAP, lsl #32
    // 0x527724: stur            x4, [fp, #-0x58]
    // 0x527728: ldur            x5, [fp, #-0x30]
    // 0x52772c: stur            x5, [fp, #-0x30]
    // 0x527730: CheckStackOverflow
    //     0x527730: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x527734: cmp             SP, x16
    //     0x527738: b.ls            #0x527d5c
    // 0x52773c: r0 = LoadClassIdInstr(r2)
    //     0x52773c: ldur            x0, [x2, #-1]
    //     0x527740: ubfx            x0, x0, #0xc, #0x14
    // 0x527744: SaveReg r2
    //     0x527744: str             x2, [SP, #-8]!
    // 0x527748: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x527748: mov             x17, #0xb8ea
    //     0x52774c: add             lr, x0, x17
    //     0x527750: ldr             lr, [x21, lr, lsl #3]
    //     0x527754: blr             lr
    // 0x527758: add             SP, SP, #8
    // 0x52775c: r1 = LoadInt32Instr(r0)
    //     0x52775c: sbfx            x1, x0, #1, #0x1f
    //     0x527760: tbz             w0, #0, #0x527768
    //     0x527764: ldur            x1, [x0, #7]
    // 0x527768: ldur            x2, [fp, #-0x60]
    // 0x52776c: cmp             x2, x1
    // 0x527770: b.ne            #0x527d10
    // 0x527774: ldur            x4, [fp, #-0x70]
    // 0x527778: ldur            x3, [fp, #-0x68]
    // 0x52777c: LoadField: r5 = r4->field_17
    //     0x52777c: ldur            x5, [x4, #0x17]
    // 0x527780: cmp             x5, x1
    // 0x527784: b.lt            #0x527a44
    // 0x527788: StoreField: r4->field_1f = rNULL
    //     0x527788: stur            NULL, [x4, #0x1f]
    // 0x52778c: ldur            x16, [fp, #-0x18]
    // 0x527790: SaveReg r16
    //     0x527790: str             x16, [SP, #-8]!
    // 0x527794: r0 = iterator()
    //     0x527794: bl              #0x70b268  ; [dart:collection] ListMixin::iterator
    // 0x527798: add             SP, SP, #8
    // 0x52779c: mov             x1, x0
    // 0x5277a0: stur            x1, [fp, #-0x98]
    // 0x5277a4: LoadField: r2 = r1->field_b
    //     0x5277a4: ldur            w2, [x1, #0xb]
    // 0x5277a8: DecompressPointer r2
    //     0x5277a8: add             x2, x2, HEAP, lsl #32
    // 0x5277ac: stur            x2, [fp, #-0x90]
    // 0x5277b0: LoadField: r3 = r1->field_f
    //     0x5277b0: ldur            x3, [x1, #0xf]
    // 0x5277b4: stur            x3, [fp, #-0x88]
    // 0x5277b8: LoadField: r4 = r1->field_7
    //     0x5277b8: ldur            w4, [x1, #7]
    // 0x5277bc: DecompressPointer r4
    //     0x5277bc: add             x4, x4, HEAP, lsl #32
    // 0x5277c0: stur            x4, [fp, #-0x80]
    // 0x5277c4: ldur            x7, [fp, #-0x30]
    // 0x5277c8: ldur            x5, [fp, #-0x10]
    // 0x5277cc: ldur            x6, [fp, #-0x28]
    // 0x5277d0: stur            x7, [fp, #-0x78]
    // 0x5277d4: CheckStackOverflow
    //     0x5277d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5277d8: cmp             SP, x16
    //     0x5277dc: b.ls            #0x527d64
    // 0x5277e0: r0 = LoadClassIdInstr(r2)
    //     0x5277e0: ldur            x0, [x2, #-1]
    //     0x5277e4: ubfx            x0, x0, #0xc, #0x14
    // 0x5277e8: SaveReg r2
    //     0x5277e8: str             x2, [SP, #-8]!
    // 0x5277ec: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x5277ec: mov             x17, #0xb8ea
    //     0x5277f0: add             lr, x0, x17
    //     0x5277f4: ldr             lr, [x21, lr, lsl #3]
    //     0x5277f8: blr             lr
    // 0x5277fc: add             SP, SP, #8
    // 0x527800: r1 = LoadInt32Instr(r0)
    //     0x527800: sbfx            x1, x0, #1, #0x1f
    //     0x527804: tbz             w0, #0, #0x52780c
    //     0x527808: ldur            x1, [x0, #7]
    // 0x52780c: ldur            x2, [fp, #-0x88]
    // 0x527810: cmp             x2, x1
    // 0x527814: b.ne            #0x527d28
    // 0x527818: ldur            x4, [fp, #-0x98]
    // 0x52781c: ldur            x3, [fp, #-0x90]
    // 0x527820: LoadField: r5 = r4->field_17
    //     0x527820: ldur            x5, [x4, #0x17]
    // 0x527824: cmp             x5, x1
    // 0x527828: b.lt            #0x5278e8
    // 0x52782c: ldur            x0, [fp, #-0x10]
    // 0x527830: ldur            x5, [fp, #-0x78]
    // 0x527834: StoreField: r4->field_1f = rNULL
    //     0x527834: stur            NULL, [x4, #0x1f]
    // 0x527838: mov             x1, x0
    // 0x52783c: r2 = Null
    //     0x52783c: mov             x2, NULL
    // 0x527840: r3 = <Response<Y0>>
    //     0x527840: add             x3, PP, #0x12, lsl #12  ; [pp+0x12dc0] TypeArguments: <Response<Y0>>
    //     0x527844: ldr             x3, [x3, #0xdc0]
    // 0x527848: r24 = InstantiateTypeArgumentsStub
    //     0x527848: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x52784c: LoadField: r30 = r24->field_7
    //     0x52784c: ldur            lr, [x24, #7]
    // 0x527850: blr             lr
    // 0x527854: ldur            x2, [fp, #-0x28]
    // 0x527858: r1 = Function '<anonymous closure>':.
    //     0x527858: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e28] AnonymousClosure: (0x52a5b4), in [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::fetch (0x5273d0)
    //     0x52785c: ldr             x1, [x1, #0xe28]
    // 0x527860: stur            x0, [fp, #-0xa0]
    // 0x527864: r0 = AllocateClosure()
    //     0x527864: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x527868: ldur            x1, [fp, #-0x10]
    // 0x52786c: StoreField: r0->field_b = r1
    //     0x52786c: stur            w1, [x0, #0xb]
    // 0x527870: ldur            x6, [fp, #-0x78]
    // 0x527874: r2 = LoadClassIdInstr(r6)
    //     0x527874: ldur            x2, [x6, #-1]
    //     0x527878: ubfx            x2, x2, #0xc, #0x14
    // 0x52787c: ldur            x16, [fp, #-0xa0]
    // 0x527880: stp             x6, x16, [SP, #-0x10]!
    // 0x527884: SaveReg r0
    //     0x527884: str             x0, [SP, #-8]!
    // 0x527888: mov             x0, x2
    // 0x52788c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x52788c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x527890: r0 = GDT[cid_x0 + -0xffe]()
    //     0x527890: sub             lr, x0, #0xffe
    //     0x527894: ldr             lr, [x21, lr, lsl #3]
    //     0x527898: blr             lr
    // 0x52789c: add             SP, SP, #0x18
    // 0x5278a0: ldur            x2, [fp, #-0x28]
    // 0x5278a4: r1 = Function '<anonymous closure>':.
    //     0x5278a4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e30] AnonymousClosure: (0x529104), in [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::fetch (0x5273d0)
    //     0x5278a8: ldr             x1, [x1, #0xe30]
    // 0x5278ac: stur            x0, [fp, #-0xa0]
    // 0x5278b0: r0 = AllocateClosure()
    //     0x5278b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5278b4: ldur            x7, [fp, #-0x10]
    // 0x5278b8: StoreField: r0->field_b = r7
    //     0x5278b8: stur            w7, [x0, #0xb]
    // 0x5278bc: ldur            x1, [fp, #-0xa0]
    // 0x5278c0: r2 = LoadClassIdInstr(r1)
    //     0x5278c0: ldur            x2, [x1, #-1]
    //     0x5278c4: ubfx            x2, x2, #0xc, #0x14
    // 0x5278c8: stp             x0, x1, [SP, #-0x10]!
    // 0x5278cc: mov             x0, x2
    // 0x5278d0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x5278d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x5278d4: r0 = GDT[cid_x0 + -0xffb]()
    //     0x5278d4: sub             lr, x0, #0xffb
    //     0x5278d8: ldr             lr, [x21, lr, lsl #3]
    //     0x5278dc: blr             lr
    // 0x5278e0: add             SP, SP, #0x10
    // 0x5278e4: r0 = ReturnAsync()
    //     0x5278e4: b               #0x501858  ; ReturnAsyncStub
    // 0x5278e8: ldur            x7, [fp, #-0x10]
    // 0x5278ec: ldur            x6, [fp, #-0x78]
    // 0x5278f0: r0 = BoxInt64Instr(r5)
    //     0x5278f0: sbfiz           x0, x5, #1, #0x1f
    //     0x5278f4: cmp             x5, x0, asr #1
    //     0x5278f8: b.eq            #0x527904
    //     0x5278fc: bl              #0xd69bb8
    //     0x527900: stur            x5, [x0, #7]
    // 0x527904: r1 = LoadClassIdInstr(r3)
    //     0x527904: ldur            x1, [x3, #-1]
    //     0x527908: ubfx            x1, x1, #0xc, #0x14
    // 0x52790c: stp             x0, x3, [SP, #-0x10]!
    // 0x527910: mov             x0, x1
    // 0x527914: r0 = GDT[cid_x0 + 0xd175]()
    //     0x527914: mov             x17, #0xd175
    //     0x527918: add             lr, x0, x17
    //     0x52791c: ldr             lr, [x21, lr, lsl #3]
    //     0x527920: blr             lr
    // 0x527924: add             SP, SP, #0x10
    // 0x527928: mov             x4, x0
    // 0x52792c: ldur            x3, [fp, #-0x98]
    // 0x527930: stur            x4, [fp, #-0xa0]
    // 0x527934: StoreField: r3->field_1f = r0
    //     0x527934: stur            w0, [x3, #0x1f]
    //     0x527938: tbz             w0, #0, #0x527954
    //     0x52793c: ldurb           w16, [x3, #-1]
    //     0x527940: ldurb           w17, [x0, #-1]
    //     0x527944: and             x16, x17, x16, lsr #2
    //     0x527948: tst             x16, HEAP, lsr #32
    //     0x52794c: b.eq            #0x527954
    //     0x527950: bl              #0xd682ac
    // 0x527954: LoadField: r0 = r3->field_17
    //     0x527954: ldur            x0, [x3, #0x17]
    // 0x527958: add             x1, x0, #1
    // 0x52795c: StoreField: r3->field_17 = r1
    //     0x52795c: stur            x1, [x3, #0x17]
    // 0x527960: cmp             w4, NULL
    // 0x527964: b.ne            #0x527998
    // 0x527968: mov             x0, x4
    // 0x52796c: ldur            x2, [fp, #-0x80]
    // 0x527970: r1 = Null
    //     0x527970: mov             x1, NULL
    // 0x527974: cmp             w2, NULL
    // 0x527978: b.eq            #0x527998
    // 0x52797c: LoadField: r4 = r2->field_17
    //     0x52797c: ldur            w4, [x2, #0x17]
    // 0x527980: DecompressPointer r4
    //     0x527980: add             x4, x4, HEAP, lsl #32
    // 0x527984: r8 = X0
    //     0x527984: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x527988: LoadField: r9 = r4->field_7
    //     0x527988: ldur            x9, [x4, #7]
    // 0x52798c: r3 = Null
    //     0x52798c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12e38] Null
    //     0x527990: ldr             x3, [x3, #0xe38]
    // 0x527994: blr             x9
    // 0x527998: ldur            x2, [fp, #-0x10]
    // 0x52799c: ldur            x3, [fp, #-0x28]
    // 0x5279a0: ldur            x1, [fp, #-0x78]
    // 0x5279a4: ldur            x0, [fp, #-0xa0]
    // 0x5279a8: r1 = 1
    //     0x5279a8: mov             x1, #1
    // 0x5279ac: r0 = AllocateContext()
    //     0x5279ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5279b0: mov             x1, x0
    // 0x5279b4: ldur            x0, [fp, #-0xa0]
    // 0x5279b8: stur            x1, [fp, #-0xa8]
    // 0x5279bc: StoreField: r1->field_f = r0
    //     0x5279bc: stur            w0, [x1, #0xf]
    // 0x5279c0: r1 = 1
    //     0x5279c0: mov             x1, #1
    // 0x5279c4: r0 = AllocateContext()
    //     0x5279c4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5279c8: mov             x3, x0
    // 0x5279cc: ldur            x0, [fp, #-0x28]
    // 0x5279d0: stur            x3, [fp, #-0xa0]
    // 0x5279d4: StoreField: r3->field_b = r0
    //     0x5279d4: stur            w0, [x3, #0xb]
    // 0x5279d8: ldur            x2, [fp, #-0xa8]
    // 0x5279dc: r1 = Function 'onError':.
    //     0x5279dc: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e48] AnonymousClosure: (0x529040), of [package:dio/src/dio_mixin.dart] Interceptor
    //     0x5279e0: ldr             x1, [x1, #0xe48]
    // 0x5279e4: r0 = AllocateClosure()
    //     0x5279e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5279e8: ldur            x2, [fp, #-0xa0]
    // 0x5279ec: StoreField: r2->field_f = r0
    //     0x5279ec: stur            w0, [x2, #0xf]
    // 0x5279f0: r1 = Function '<anonymous closure>':.
    //     0x5279f0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e50] AnonymousClosure: (0x528c80), of [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin
    //     0x5279f4: ldr             x1, [x1, #0xe50]
    // 0x5279f8: r0 = AllocateClosure()
    //     0x5279f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5279fc: ldur            x1, [fp, #-0x10]
    // 0x527a00: StoreField: r0->field_b = r1
    //     0x527a00: stur            w1, [x0, #0xb]
    // 0x527a04: ldur            x2, [fp, #-0x78]
    // 0x527a08: r3 = LoadClassIdInstr(r2)
    //     0x527a08: ldur            x3, [x2, #-1]
    //     0x527a0c: ubfx            x3, x3, #0xc, #0x14
    // 0x527a10: stp             x0, x2, [SP, #-0x10]!
    // 0x527a14: mov             x0, x3
    // 0x527a18: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x527a18: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x527a1c: r0 = GDT[cid_x0 + -0xffb]()
    //     0x527a1c: sub             lr, x0, #0xffb
    //     0x527a20: ldr             lr, [x21, lr, lsl #3]
    //     0x527a24: blr             lr
    // 0x527a28: add             SP, SP, #0x10
    // 0x527a2c: mov             x7, x0
    // 0x527a30: ldur            x1, [fp, #-0x98]
    // 0x527a34: ldur            x4, [fp, #-0x80]
    // 0x527a38: ldur            x2, [fp, #-0x90]
    // 0x527a3c: ldur            x3, [fp, #-0x88]
    // 0x527a40: b               #0x5277c8
    // 0x527a44: r0 = BoxInt64Instr(r5)
    //     0x527a44: sbfiz           x0, x5, #1, #0x1f
    //     0x527a48: cmp             x5, x0, asr #1
    //     0x527a4c: b.eq            #0x527a58
    //     0x527a50: bl              #0xd69bb8
    //     0x527a54: stur            x5, [x0, #7]
    // 0x527a58: r1 = LoadClassIdInstr(r3)
    //     0x527a58: ldur            x1, [x3, #-1]
    //     0x527a5c: ubfx            x1, x1, #0xc, #0x14
    // 0x527a60: stp             x0, x3, [SP, #-0x10]!
    // 0x527a64: mov             x0, x1
    // 0x527a68: r0 = GDT[cid_x0 + 0xd175]()
    //     0x527a68: mov             x17, #0xd175
    //     0x527a6c: add             lr, x0, x17
    //     0x527a70: ldr             lr, [x21, lr, lsl #3]
    //     0x527a74: blr             lr
    // 0x527a78: add             SP, SP, #0x10
    // 0x527a7c: mov             x4, x0
    // 0x527a80: ldur            x3, [fp, #-0x70]
    // 0x527a84: stur            x4, [fp, #-0x78]
    // 0x527a88: StoreField: r3->field_1f = r0
    //     0x527a88: stur            w0, [x3, #0x1f]
    //     0x527a8c: tbz             w0, #0, #0x527aa8
    //     0x527a90: ldurb           w16, [x3, #-1]
    //     0x527a94: ldurb           w17, [x0, #-1]
    //     0x527a98: and             x16, x17, x16, lsr #2
    //     0x527a9c: tst             x16, HEAP, lsr #32
    //     0x527aa0: b.eq            #0x527aa8
    //     0x527aa4: bl              #0xd682ac
    // 0x527aa8: LoadField: r0 = r3->field_17
    //     0x527aa8: ldur            x0, [x3, #0x17]
    // 0x527aac: add             x1, x0, #1
    // 0x527ab0: StoreField: r3->field_17 = r1
    //     0x527ab0: stur            x1, [x3, #0x17]
    // 0x527ab4: cmp             w4, NULL
    // 0x527ab8: b.ne            #0x527aec
    // 0x527abc: mov             x0, x4
    // 0x527ac0: ldur            x2, [fp, #-0x58]
    // 0x527ac4: r1 = Null
    //     0x527ac4: mov             x1, NULL
    // 0x527ac8: cmp             w2, NULL
    // 0x527acc: b.eq            #0x527aec
    // 0x527ad0: LoadField: r4 = r2->field_17
    //     0x527ad0: ldur            w4, [x2, #0x17]
    // 0x527ad4: DecompressPointer r4
    //     0x527ad4: add             x4, x4, HEAP, lsl #32
    // 0x527ad8: r8 = X0
    //     0x527ad8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x527adc: LoadField: r9 = r4->field_7
    //     0x527adc: ldur            x9, [x4, #7]
    // 0x527ae0: r3 = Null
    //     0x527ae0: add             x3, PP, #0x12, lsl #12  ; [pp+0x12e58] Null
    //     0x527ae4: ldr             x3, [x3, #0xe58]
    // 0x527ae8: blr             x9
    // 0x527aec: ldur            x1, [fp, #-0x10]
    // 0x527af0: ldur            x2, [fp, #-0x28]
    // 0x527af4: ldur            x3, [fp, #-0x30]
    // 0x527af8: ldur            x0, [fp, #-0x78]
    // 0x527afc: r1 = 1
    //     0x527afc: mov             x1, #1
    // 0x527b00: r0 = AllocateContext()
    //     0x527b00: bl              #0xd68aa4  ; AllocateContextStub
    // 0x527b04: mov             x1, x0
    // 0x527b08: ldur            x0, [fp, #-0x78]
    // 0x527b0c: stur            x1, [fp, #-0x80]
    // 0x527b10: StoreField: r1->field_f = r0
    //     0x527b10: stur            w0, [x1, #0xf]
    // 0x527b14: r1 = 1
    //     0x527b14: mov             x1, #1
    // 0x527b18: r0 = AllocateContext()
    //     0x527b18: bl              #0xd68aa4  ; AllocateContextStub
    // 0x527b1c: mov             x3, x0
    // 0x527b20: ldur            x0, [fp, #-0x28]
    // 0x527b24: stur            x3, [fp, #-0x78]
    // 0x527b28: StoreField: r3->field_b = r0
    //     0x527b28: stur            w0, [x3, #0xb]
    // 0x527b2c: ldur            x2, [fp, #-0x80]
    // 0x527b30: r1 = Function 'onResponse':.
    //     0x527b30: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e68] AnonymousClosure: (0x528bc8), of [package:dio/src/dio_mixin.dart] Interceptor
    //     0x527b34: ldr             x1, [x1, #0xe68]
    // 0x527b38: r0 = AllocateClosure()
    //     0x527b38: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x527b3c: ldur            x2, [fp, #-0x78]
    // 0x527b40: StoreField: r2->field_f = r0
    //     0x527b40: stur            w0, [x2, #0xf]
    // 0x527b44: r1 = Function '<anonymous closure>':.
    //     0x527b44: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e70] AnonymousClosure: (0x528160), of [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin
    //     0x527b48: ldr             x1, [x1, #0xe70]
    // 0x527b4c: r0 = AllocateClosure()
    //     0x527b4c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x527b50: ldur            x1, [fp, #-0x10]
    // 0x527b54: StoreField: r0->field_b = r1
    //     0x527b54: stur            w1, [x0, #0xb]
    // 0x527b58: ldur            x2, [fp, #-0x30]
    // 0x527b5c: r3 = LoadClassIdInstr(r2)
    //     0x527b5c: ldur            x3, [x2, #-1]
    //     0x527b60: ubfx            x3, x3, #0xc, #0x14
    // 0x527b64: stp             x2, NULL, [SP, #-0x10]!
    // 0x527b68: SaveReg r0
    //     0x527b68: str             x0, [SP, #-8]!
    // 0x527b6c: mov             x0, x3
    // 0x527b70: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x527b70: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x527b74: r0 = GDT[cid_x0 + -0xffe]()
    //     0x527b74: sub             lr, x0, #0xffe
    //     0x527b78: ldr             lr, [x21, lr, lsl #3]
    //     0x527b7c: blr             lr
    // 0x527b80: add             SP, SP, #0x18
    // 0x527b84: mov             x5, x0
    // 0x527b88: ldur            x1, [fp, #-0x70]
    // 0x527b8c: ldur            x4, [fp, #-0x58]
    // 0x527b90: ldur            x2, [fp, #-0x68]
    // 0x527b94: ldur            x3, [fp, #-0x60]
    // 0x527b98: b               #0x52772c
    // 0x527b9c: ldur            x6, [fp, #-0x20]
    // 0x527ba0: r0 = BoxInt64Instr(r5)
    //     0x527ba0: sbfiz           x0, x5, #1, #0x1f
    //     0x527ba4: cmp             x5, x0, asr #1
    //     0x527ba8: b.eq            #0x527bb4
    //     0x527bac: bl              #0xd69bb8
    //     0x527bb0: stur            x5, [x0, #7]
    // 0x527bb4: r1 = LoadClassIdInstr(r3)
    //     0x527bb4: ldur            x1, [x3, #-1]
    //     0x527bb8: ubfx            x1, x1, #0xc, #0x14
    // 0x527bbc: stp             x0, x3, [SP, #-0x10]!
    // 0x527bc0: mov             x0, x1
    // 0x527bc4: r0 = GDT[cid_x0 + 0xd175]()
    //     0x527bc4: mov             x17, #0xd175
    //     0x527bc8: add             lr, x0, x17
    //     0x527bcc: ldr             lr, [x21, lr, lsl #3]
    //     0x527bd0: blr             lr
    // 0x527bd4: add             SP, SP, #0x10
    // 0x527bd8: mov             x4, x0
    // 0x527bdc: ldur            x3, [fp, #-0x50]
    // 0x527be0: stur            x4, [fp, #-0x30]
    // 0x527be4: StoreField: r3->field_1f = r0
    //     0x527be4: stur            w0, [x3, #0x1f]
    //     0x527be8: tbz             w0, #0, #0x527c04
    //     0x527bec: ldurb           w16, [x3, #-1]
    //     0x527bf0: ldurb           w17, [x0, #-1]
    //     0x527bf4: and             x16, x17, x16, lsr #2
    //     0x527bf8: tst             x16, HEAP, lsr #32
    //     0x527bfc: b.eq            #0x527c04
    //     0x527c00: bl              #0xd682ac
    // 0x527c04: LoadField: r0 = r3->field_17
    //     0x527c04: ldur            x0, [x3, #0x17]
    // 0x527c08: add             x1, x0, #1
    // 0x527c0c: StoreField: r3->field_17 = r1
    //     0x527c0c: stur            x1, [x3, #0x17]
    // 0x527c10: cmp             w4, NULL
    // 0x527c14: b.ne            #0x527c48
    // 0x527c18: mov             x0, x4
    // 0x527c1c: ldur            x2, [fp, #-0x38]
    // 0x527c20: r1 = Null
    //     0x527c20: mov             x1, NULL
    // 0x527c24: cmp             w2, NULL
    // 0x527c28: b.eq            #0x527c48
    // 0x527c2c: LoadField: r4 = r2->field_17
    //     0x527c2c: ldur            w4, [x2, #0x17]
    // 0x527c30: DecompressPointer r4
    //     0x527c30: add             x4, x4, HEAP, lsl #32
    // 0x527c34: r8 = X0
    //     0x527c34: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x527c38: LoadField: r9 = r4->field_7
    //     0x527c38: ldur            x9, [x4, #7]
    // 0x527c3c: r3 = Null
    //     0x527c3c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12e78] Null
    //     0x527c40: ldr             x3, [x3, #0xe78]
    // 0x527c44: blr             x9
    // 0x527c48: ldur            x2, [fp, #-0x10]
    // 0x527c4c: ldur            x3, [fp, #-0x28]
    // 0x527c50: ldur            x1, [fp, #-0x20]
    // 0x527c54: ldur            x0, [fp, #-0x30]
    // 0x527c58: r1 = 1
    //     0x527c58: mov             x1, #1
    // 0x527c5c: r0 = AllocateContext()
    //     0x527c5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x527c60: mov             x1, x0
    // 0x527c64: ldur            x0, [fp, #-0x30]
    // 0x527c68: stur            x1, [fp, #-0x58]
    // 0x527c6c: StoreField: r1->field_f = r0
    //     0x527c6c: stur            w0, [x1, #0xf]
    // 0x527c70: r1 = 1
    //     0x527c70: mov             x1, #1
    // 0x527c74: r0 = AllocateContext()
    //     0x527c74: bl              #0xd68aa4  ; AllocateContextStub
    // 0x527c78: mov             x3, x0
    // 0x527c7c: ldur            x0, [fp, #-0x28]
    // 0x527c80: stur            x3, [fp, #-0x30]
    // 0x527c84: StoreField: r3->field_b = r0
    //     0x527c84: stur            w0, [x3, #0xb]
    // 0x527c88: ldur            x2, [fp, #-0x58]
    // 0x527c8c: r1 = Function 'onRequest':.
    //     0x527c8c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e88] AnonymousClosure: (0x527d6c), in [package:dio/src/interceptors/imply_content_type.dart] ImplyContentTypeInterceptor::onRequest (0x527dc0)
    //     0x527c90: ldr             x1, [x1, #0xe88]
    // 0x527c94: r0 = AllocateClosure()
    //     0x527c94: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x527c98: ldur            x2, [fp, #-0x30]
    // 0x527c9c: StoreField: r2->field_f = r0
    //     0x527c9c: stur            w0, [x2, #0xf]
    // 0x527ca0: r1 = Function '<anonymous closure>':.
    //     0x527ca0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e20] AnonymousClosure: (0x52a68c), of [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin
    //     0x527ca4: ldr             x1, [x1, #0xe20]
    // 0x527ca8: r0 = AllocateClosure()
    //     0x527ca8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x527cac: ldur            x1, [fp, #-0x10]
    // 0x527cb0: StoreField: r0->field_b = r1
    //     0x527cb0: stur            w1, [x0, #0xb]
    // 0x527cb4: ldur            x2, [fp, #-0x20]
    // 0x527cb8: r3 = LoadClassIdInstr(r2)
    //     0x527cb8: ldur            x3, [x2, #-1]
    //     0x527cbc: ubfx            x3, x3, #0xc, #0x14
    // 0x527cc0: stp             x2, NULL, [SP, #-0x10]!
    // 0x527cc4: SaveReg r0
    //     0x527cc4: str             x0, [SP, #-8]!
    // 0x527cc8: mov             x0, x3
    // 0x527ccc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x527ccc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x527cd0: r0 = GDT[cid_x0 + -0xffe]()
    //     0x527cd0: sub             lr, x0, #0xffe
    //     0x527cd4: ldr             lr, [x21, lr, lsl #3]
    //     0x527cd8: blr             lr
    // 0x527cdc: add             SP, SP, #0x18
    // 0x527ce0: mov             x7, x0
    // 0x527ce4: ldur            x1, [fp, #-0x50]
    // 0x527ce8: ldur            x4, [fp, #-0x38]
    // 0x527cec: ldur            x2, [fp, #-0x48]
    // 0x527cf0: ldur            x3, [fp, #-0x40]
    // 0x527cf4: b               #0x5275fc
    // 0x527cf8: ldur            x0, [fp, #-0x48]
    // 0x527cfc: r0 = ConcurrentModificationError()
    //     0x527cfc: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x527d00: ldur            x3, [fp, #-0x48]
    // 0x527d04: StoreField: r0->field_b = r3
    //     0x527d04: stur            w3, [x0, #0xb]
    // 0x527d08: r0 = Throw()
    //     0x527d08: bl              #0xd67e38  ; ThrowStub
    // 0x527d0c: brk             #0
    // 0x527d10: ldur            x0, [fp, #-0x68]
    // 0x527d14: r0 = ConcurrentModificationError()
    //     0x527d14: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x527d18: ldur            x3, [fp, #-0x68]
    // 0x527d1c: StoreField: r0->field_b = r3
    //     0x527d1c: stur            w3, [x0, #0xb]
    // 0x527d20: r0 = Throw()
    //     0x527d20: bl              #0xd67e38  ; ThrowStub
    // 0x527d24: brk             #0
    // 0x527d28: ldur            x0, [fp, #-0x90]
    // 0x527d2c: r0 = ConcurrentModificationError()
    //     0x527d2c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x527d30: ldur            x3, [fp, #-0x90]
    // 0x527d34: StoreField: r0->field_b = r3
    //     0x527d34: stur            w3, [x0, #0xb]
    // 0x527d38: r0 = Throw()
    //     0x527d38: bl              #0xd67e38  ; ThrowStub
    // 0x527d3c: brk             #0
    // 0x527d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x527d40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x527d44: b               #0x527434
    // 0x527d48: r9 = responseType
    //     0x527d48: add             x9, PP, #0x12, lsl #12  ; [pp+0x12e90] Field <_RequestConfig@361184022.responseType>: late (offset: 0x1c)
    //     0x527d4c: ldr             x9, [x9, #0xe90]
    // 0x527d50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x527d50: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x527d54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x527d54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x527d58: b               #0x527614
    // 0x527d5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x527d5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x527d60: b               #0x52773c
    // 0x527d64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x527d64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x527d68: b               #0x5277e0
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, dynamic) async {
    // ** addr: 0x528160, size: 0x14c
    // 0x528160: EnterFrame
    //     0x528160: stp             fp, lr, [SP, #-0x10]!
    //     0x528164: mov             fp, SP
    // 0x528168: AllocStack(0x28)
    //     0x528168: sub             SP, SP, #0x28
    // 0x52816c: SetupParameters(_DioForNative&Object&DioMixin this /* r1 */, dynamic _ /* r2, fp-0x20 */)
    //     0x52816c: stur            NULL, [fp, #-8]
    //     0x528170: mov             x0, #0
    //     0x528174: add             x1, fp, w0, sxtw #2
    //     0x528178: ldr             x1, [x1, #0x18]
    //     0x52817c: add             x2, fp, w0, sxtw #2
    //     0x528180: ldr             x2, [x2, #0x10]
    //     0x528184: stur            x2, [fp, #-0x20]
    //     0x528188: ldur            w3, [x1, #0x17]
    //     0x52818c: add             x3, x3, HEAP, lsl #32
    //     0x528190: stur            x3, [fp, #-0x18]
    // 0x528194: CheckStackOverflow
    //     0x528194: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x528198: cmp             SP, x16
    //     0x52819c: b.ls            #0x5282a4
    // 0x5281a0: LoadField: r4 = r1->field_b
    //     0x5281a0: ldur            w4, [x1, #0xb]
    // 0x5281a4: DecompressPointer r4
    //     0x5281a4: add             x4, x4, HEAP, lsl #32
    // 0x5281a8: stur            x4, [fp, #-0x10]
    // 0x5281ac: InitAsync() -> Future
    //     0x5281ac: mov             x0, NULL
    //     0x5281b0: bl              #0x4b92e4
    // 0x5281b4: r1 = 1
    //     0x5281b4: mov             x1, #1
    // 0x5281b8: r0 = AllocateContext()
    //     0x5281b8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5281bc: mov             x4, x0
    // 0x5281c0: ldur            x3, [fp, #-0x18]
    // 0x5281c4: stur            x4, [fp, #-0x28]
    // 0x5281c8: StoreField: r4->field_b = r3
    //     0x5281c8: stur            w3, [x4, #0xb]
    // 0x5281cc: ldur            x0, [fp, #-0x20]
    // 0x5281d0: r2 = Null
    //     0x5281d0: mov             x2, NULL
    // 0x5281d4: r1 = Null
    //     0x5281d4: mov             x1, NULL
    // 0x5281d8: r4 = 59
    //     0x5281d8: mov             x4, #0x3b
    // 0x5281dc: branchIfSmi(r0, 0x5281e8)
    //     0x5281dc: tbz             w0, #0, #0x5281e8
    // 0x5281e0: r4 = LoadClassIdInstr(r0)
    //     0x5281e0: ldur            x4, [x0, #-1]
    //     0x5281e4: ubfx            x4, x4, #0xc, #0x14
    // 0x5281e8: r17 = 4543
    //     0x5281e8: mov             x17, #0x11bf
    // 0x5281ec: cmp             x4, x17
    // 0x5281f0: b.eq            #0x528208
    // 0x5281f4: r8 = InterceptorState
    //     0x5281f4: add             x8, PP, #0x12, lsl #12  ; [pp+0x12ef8] Type: InterceptorState
    //     0x5281f8: ldr             x8, [x8, #0xef8]
    // 0x5281fc: r3 = Null
    //     0x5281fc: add             x3, PP, #0x12, lsl #12  ; [pp+0x12f00] Null
    //     0x528200: ldr             x3, [x3, #0xf00]
    // 0x528204: r0 = InterceptorState()
    //     0x528204: bl              #0x528ba4  ; IsType_InterceptorState_Stub
    // 0x528208: ldur            x0, [fp, #-0x20]
    // 0x52820c: ldur            x2, [fp, #-0x28]
    // 0x528210: StoreField: r2->field_f = r0
    //     0x528210: stur            w0, [x2, #0xf]
    // 0x528214: LoadField: r1 = r0->field_f
    //     0x528214: ldur            w1, [x0, #0xf]
    // 0x528218: DecompressPointer r1
    //     0x528218: add             x1, x1, HEAP, lsl #32
    // 0x52821c: r16 = Instance_InterceptorResultType
    //     0x52821c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed0] Obj!InterceptorResultType@b665b1
    //     0x528220: ldr             x16, [x16, #0xed0]
    // 0x528224: cmp             w1, w16
    // 0x528228: b.eq            #0x52823c
    // 0x52822c: r16 = Instance_InterceptorResultType
    //     0x52822c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12f10] Obj!InterceptorResultType@b665d1
    //     0x528230: ldr             x16, [x16, #0xf10]
    // 0x528234: cmp             w1, w16
    // 0x528238: b.ne            #0x5282a0
    // 0x52823c: ldur            x0, [fp, #-0x18]
    // 0x528240: ldur            x3, [fp, #-0x10]
    // 0x528244: LoadField: r1 = r0->field_b
    //     0x528244: ldur            w1, [x0, #0xb]
    // 0x528248: DecompressPointer r1
    //     0x528248: add             x1, x1, HEAP, lsl #32
    // 0x52824c: LoadField: r0 = r1->field_13
    //     0x52824c: ldur            w0, [x1, #0x13]
    // 0x528250: DecompressPointer r0
    //     0x528250: add             x0, x0, HEAP, lsl #32
    // 0x528254: LoadField: r4 = r0->field_5b
    //     0x528254: ldur            w4, [x0, #0x5b]
    // 0x528258: DecompressPointer r4
    //     0x528258: add             x4, x4, HEAP, lsl #32
    // 0x52825c: stur            x4, [fp, #-0x18]
    // 0x528260: r1 = Function '<anonymous closure>':.
    //     0x528260: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f18] AnonymousClosure: (0x5289d0), in [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::<anonymous closure> (0x528160)
    //     0x528264: ldr             x1, [x1, #0xf18]
    // 0x528268: r0 = AllocateClosure()
    //     0x528268: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52826c: mov             x1, x0
    // 0x528270: ldur            x0, [fp, #-0x10]
    // 0x528274: StoreField: r1->field_b = r0
    //     0x528274: stur            w0, [x1, #0xb]
    // 0x528278: stp             x1, NULL, [SP, #-0x10]!
    // 0x52827c: r0 = Future()
    //     0x52827c: bl              #0x4b5784  ; [dart:async] Future::Future
    // 0x528280: add             SP, SP, #0x10
    // 0x528284: ldur            x16, [fp, #-0x18]
    // 0x528288: stp             x16, NULL, [SP, #-0x10]!
    // 0x52828c: SaveReg r0
    //     0x52828c: str             x0, [SP, #-8]!
    // 0x528290: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x528290: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x528294: r0 = listenCancelForAsyncTask()
    //     0x528294: bl              #0x5282ac  ; [package:dio/src/dio_mixin.dart] DioMixin::listenCancelForAsyncTask
    // 0x528298: add             SP, SP, #0x18
    // 0x52829c: r0 = ReturnAsync()
    //     0x52829c: b               #0x501858  ; ReturnAsyncStub
    // 0x5282a0: r0 = ReturnAsyncNotFuture()
    //     0x5282a0: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x5282a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5282a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5282a8: b               #0x5281a0
  }
  [closure] Future<InterceptorState<dynamic>> <anonymous closure>(dynamic) {
    // ** addr: 0x5289d0, size: 0xfc
    // 0x5289d0: EnterFrame
    //     0x5289d0: stp             fp, lr, [SP, #-0x10]!
    //     0x5289d4: mov             fp, SP
    // 0x5289d8: AllocStack(0x18)
    //     0x5289d8: sub             SP, SP, #0x18
    // 0x5289dc: SetupParameters()
    //     0x5289dc: ldr             x0, [fp, #0x10]
    //     0x5289e0: ldur            w1, [x0, #0x17]
    //     0x5289e4: add             x1, x1, HEAP, lsl #32
    //     0x5289e8: stur            x1, [fp, #-8]
    // 0x5289ec: CheckStackOverflow
    //     0x5289ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5289f0: cmp             SP, x16
    //     0x5289f4: b.ls            #0x528ac0
    // 0x5289f8: r0 = ResponseInterceptorHandler()
    //     0x5289f8: bl              #0x528b74  ; AllocateResponseInterceptorHandlerStub -> ResponseInterceptorHandler (size=0x10)
    // 0x5289fc: stur            x0, [fp, #-0x10]
    // 0x528a00: SaveReg r0
    //     0x528a00: str             x0, [SP, #-8]!
    // 0x528a04: r0 = _BaseHandler()
    //     0x528a04: bl              #0x528acc  ; [package:dio/src/dio_mixin.dart] _BaseHandler::_BaseHandler
    // 0x528a08: add             SP, SP, #8
    // 0x528a0c: ldur            x0, [fp, #-8]
    // 0x528a10: LoadField: r1 = r0->field_b
    //     0x528a10: ldur            w1, [x0, #0xb]
    // 0x528a14: DecompressPointer r1
    //     0x528a14: add             x1, x1, HEAP, lsl #32
    // 0x528a18: LoadField: r3 = r1->field_f
    //     0x528a18: ldur            w3, [x1, #0xf]
    // 0x528a1c: DecompressPointer r3
    //     0x528a1c: add             x3, x3, HEAP, lsl #32
    // 0x528a20: stur            x3, [fp, #-0x18]
    // 0x528a24: LoadField: r1 = r0->field_f
    //     0x528a24: ldur            w1, [x0, #0xf]
    // 0x528a28: DecompressPointer r1
    //     0x528a28: add             x1, x1, HEAP, lsl #32
    // 0x528a2c: LoadField: r4 = r1->field_b
    //     0x528a2c: ldur            w4, [x1, #0xb]
    // 0x528a30: DecompressPointer r4
    //     0x528a30: add             x4, x4, HEAP, lsl #32
    // 0x528a34: mov             x0, x4
    // 0x528a38: stur            x4, [fp, #-8]
    // 0x528a3c: r2 = Null
    //     0x528a3c: mov             x2, NULL
    // 0x528a40: r1 = Null
    //     0x528a40: mov             x1, NULL
    // 0x528a44: r4 = 59
    //     0x528a44: mov             x4, #0x3b
    // 0x528a48: branchIfSmi(r0, 0x528a54)
    //     0x528a48: tbz             w0, #0, #0x528a54
    // 0x528a4c: r4 = LoadClassIdInstr(r0)
    //     0x528a4c: ldur            x4, [x0, #-1]
    //     0x528a50: ubfx            x4, x4, #0xc, #0x14
    // 0x528a54: r17 = 4526
    //     0x528a54: mov             x17, #0x11ae
    // 0x528a58: cmp             x4, x17
    // 0x528a5c: b.eq            #0x528a74
    // 0x528a60: r8 = Response
    //     0x528a60: add             x8, PP, #0x12, lsl #12  ; [pp+0x12f20] Type: Response
    //     0x528a64: ldr             x8, [x8, #0xf20]
    // 0x528a68: r3 = Null
    //     0x528a68: add             x3, PP, #0x12, lsl #12  ; [pp+0x12f28] Null
    //     0x528a6c: ldr             x3, [x3, #0xf28]
    // 0x528a70: r0 = Response()
    //     0x528a70: bl              #0x528b80  ; IsType_Response_Stub
    // 0x528a74: ldur            x0, [fp, #-0x18]
    // 0x528a78: cmp             w0, NULL
    // 0x528a7c: b.eq            #0x528ac8
    // 0x528a80: ldur            x16, [fp, #-8]
    // 0x528a84: stp             x16, x0, [SP, #-0x10]!
    // 0x528a88: ldur            x16, [fp, #-0x10]
    // 0x528a8c: SaveReg r16
    //     0x528a8c: str             x16, [SP, #-8]!
    // 0x528a90: ClosureCall
    //     0x528a90: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x528a94: ldur            x2, [x0, #0x1f]
    //     0x528a98: blr             x2
    // 0x528a9c: add             SP, SP, #0x18
    // 0x528aa0: ldur            x1, [fp, #-0x10]
    // 0x528aa4: LoadField: r2 = r1->field_7
    //     0x528aa4: ldur            w2, [x1, #7]
    // 0x528aa8: DecompressPointer r2
    //     0x528aa8: add             x2, x2, HEAP, lsl #32
    // 0x528aac: LoadField: r0 = r2->field_b
    //     0x528aac: ldur            w0, [x2, #0xb]
    // 0x528ab0: DecompressPointer r0
    //     0x528ab0: add             x0, x0, HEAP, lsl #32
    // 0x528ab4: LeaveFrame
    //     0x528ab4: mov             SP, fp
    //     0x528ab8: ldp             fp, lr, [SP], #0x10
    // 0x528abc: ret
    //     0x528abc: ret             
    // 0x528ac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x528ac0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x528ac4: b               #0x5289f8
    // 0x528ac8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x528ac8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, Object) {
    // ** addr: 0x528c80, size: 0x224
    // 0x528c80: EnterFrame
    //     0x528c80: stp             fp, lr, [SP, #-0x10]!
    //     0x528c84: mov             fp, SP
    // 0x528c88: AllocStack(0x20)
    //     0x528c88: sub             SP, SP, #0x20
    // 0x528c8c: SetupParameters()
    //     0x528c8c: ldr             x0, [fp, #0x18]
    //     0x528c90: ldur            w1, [x0, #0x17]
    //     0x528c94: add             x1, x1, HEAP, lsl #32
    //     0x528c98: stur            x1, [fp, #-0x10]
    // 0x528c9c: CheckStackOverflow
    //     0x528c9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x528ca0: cmp             SP, x16
    //     0x528ca4: b.ls            #0x528e9c
    // 0x528ca8: LoadField: r2 = r0->field_b
    //     0x528ca8: ldur            w2, [x0, #0xb]
    // 0x528cac: DecompressPointer r2
    //     0x528cac: add             x2, x2, HEAP, lsl #32
    // 0x528cb0: stur            x2, [fp, #-8]
    // 0x528cb4: r1 = 1
    //     0x528cb4: mov             x1, #1
    // 0x528cb8: r0 = AllocateContext()
    //     0x528cb8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x528cbc: mov             x1, x0
    // 0x528cc0: ldur            x0, [fp, #-0x10]
    // 0x528cc4: stur            x1, [fp, #-0x18]
    // 0x528cc8: StoreField: r1->field_b = r0
    //     0x528cc8: stur            w0, [x1, #0xb]
    // 0x528ccc: ldr             x2, [fp, #0x10]
    // 0x528cd0: r3 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0x528cd0: mov             x3, #0x76
    //     0x528cd4: tbz             w2, #0, #0x528ce4
    //     0x528cd8: ldur            x3, [x2, #-1]
    //     0x528cdc: ubfx            x3, x3, #0xc, #0x14
    //     0x528ce0: lsl             x3, x3, #1
    // 0x528ce4: r17 = 9086
    //     0x528ce4: mov             x17, #0x237e
    // 0x528ce8: cmp             w3, w17
    // 0x528cec: b.ne            #0x528cfc
    // 0x528cf0: mov             x4, x2
    // 0x528cf4: mov             x2, x1
    // 0x528cf8: b               #0x528d48
    // 0x528cfc: LoadField: r3 = r0->field_b
    //     0x528cfc: ldur            w3, [x0, #0xb]
    // 0x528d00: DecompressPointer r3
    //     0x528d00: add             x3, x3, HEAP, lsl #32
    // 0x528d04: LoadField: r4 = r3->field_13
    //     0x528d04: ldur            w4, [x3, #0x13]
    // 0x528d08: DecompressPointer r4
    //     0x528d08: add             x4, x4, HEAP, lsl #32
    // 0x528d0c: stp             x4, x2, [SP, #-0x10]!
    // 0x528d10: r0 = assureDioException()
    //     0x528d10: bl              #0x528ea4  ; [package:dio/src/dio_mixin.dart] DioMixin::assureDioException
    // 0x528d14: add             SP, SP, #0x10
    // 0x528d18: r1 = <DioException>
    //     0x528d18: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f78] TypeArguments: <DioException>
    //     0x528d1c: ldr             x1, [x1, #0xf78]
    // 0x528d20: stur            x0, [fp, #-0x20]
    // 0x528d24: r0 = InterceptorState()
    //     0x528d24: bl              #0x527f68  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x528d28: mov             x1, x0
    // 0x528d2c: ldur            x0, [fp, #-0x20]
    // 0x528d30: StoreField: r1->field_b = r0
    //     0x528d30: stur            w0, [x1, #0xb]
    // 0x528d34: r0 = Instance_InterceptorResultType
    //     0x528d34: add             x0, PP, #0x12, lsl #12  ; [pp+0x12ed0] Obj!InterceptorResultType@b665b1
    //     0x528d38: ldr             x0, [x0, #0xed0]
    // 0x528d3c: StoreField: r1->field_f = r0
    //     0x528d3c: stur            w0, [x1, #0xf]
    // 0x528d40: mov             x4, x1
    // 0x528d44: ldur            x2, [fp, #-0x18]
    // 0x528d48: ldur            x3, [fp, #-8]
    // 0x528d4c: mov             x0, x4
    // 0x528d50: stur            x4, [fp, #-0x20]
    // 0x528d54: StoreField: r2->field_f = r0
    //     0x528d54: stur            w0, [x2, #0xf]
    //     0x528d58: ldurb           w16, [x2, #-1]
    //     0x528d5c: ldurb           w17, [x0, #-1]
    //     0x528d60: and             x16, x17, x16, lsr #2
    //     0x528d64: tst             x16, HEAP, lsr #32
    //     0x528d68: b.eq            #0x528d70
    //     0x528d6c: bl              #0xd6828c
    // 0x528d70: r1 = Function 'handleError':.
    //     0x528d70: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f80] AnonymousClosure: (0x528f28), in [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::<anonymous closure> (0x528c80)
    //     0x528d74: ldr             x1, [x1, #0xf80]
    // 0x528d78: r0 = AllocateClosure()
    //     0x528d78: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x528d7c: mov             x1, x0
    // 0x528d80: ldur            x0, [fp, #-8]
    // 0x528d84: stur            x1, [fp, #-0x18]
    // 0x528d88: StoreField: r1->field_b = r0
    //     0x528d88: stur            w0, [x1, #0xb]
    // 0x528d8c: ldur            x0, [fp, #-0x20]
    // 0x528d90: LoadField: r2 = r0->field_b
    //     0x528d90: ldur            w2, [x0, #0xb]
    // 0x528d94: DecompressPointer r2
    //     0x528d94: add             x2, x2, HEAP, lsl #32
    // 0x528d98: r3 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0x528d98: mov             x3, #0x76
    //     0x528d9c: tbz             w2, #0, #0x528dac
    //     0x528da0: ldur            x3, [x2, #-1]
    //     0x528da4: ubfx            x3, x3, #0xc, #0x14
    //     0x528da8: lsl             x3, x3, #1
    // 0x528dac: r17 = 9088
    //     0x528dac: mov             x17, #0x2380
    // 0x528db0: cmp             w3, w17
    // 0x528db4: b.ne            #0x528e10
    // 0x528db8: SaveReg r2
    //     0x528db8: str             x2, [SP, #-8]!
    // 0x528dbc: r4 = 0
    //     0x528dbc: mov             x4, #0
    // 0x528dc0: ldr             x0, [SP]
    // 0x528dc4: r16 = UnlinkedCall_0x4aeefc
    //     0x528dc4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12f88] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x528dc8: add             x16, x16, #0xf88
    // 0x528dcc: ldp             x5, lr, [x16]
    // 0x528dd0: blr             lr
    // 0x528dd4: add             SP, SP, #8
    // 0x528dd8: r16 = Instance_DioExceptionType
    //     0x528dd8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12da0] Obj!DioExceptionType@b66631
    //     0x528ddc: ldr             x16, [x16, #0xda0]
    // 0x528de0: cmp             w0, w16
    // 0x528de4: b.ne            #0x528e10
    // 0x528de8: ldur            x16, [fp, #-0x18]
    // 0x528dec: SaveReg r16
    //     0x528dec: str             x16, [SP, #-8]!
    // 0x528df0: ldur            x0, [fp, #-0x18]
    // 0x528df4: ClosureCall
    //     0x528df4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x528df8: ldur            x2, [x0, #0x1f]
    //     0x528dfc: blr             x2
    // 0x528e00: add             SP, SP, #8
    // 0x528e04: LeaveFrame
    //     0x528e04: mov             SP, fp
    //     0x528e08: ldp             fp, lr, [SP], #0x10
    // 0x528e0c: ret
    //     0x528e0c: ret             
    // 0x528e10: ldur            x0, [fp, #-0x20]
    // 0x528e14: LoadField: r1 = r0->field_f
    //     0x528e14: ldur            w1, [x0, #0xf]
    // 0x528e18: DecompressPointer r1
    //     0x528e18: add             x1, x1, HEAP, lsl #32
    // 0x528e1c: r16 = Instance_InterceptorResultType
    //     0x528e1c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed0] Obj!InterceptorResultType@b665b1
    //     0x528e20: ldr             x16, [x16, #0xed0]
    // 0x528e24: cmp             w1, w16
    // 0x528e28: b.eq            #0x528e3c
    // 0x528e2c: r16 = Instance_InterceptorResultType
    //     0x528e2c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12f98] Obj!InterceptorResultType@b665f1
    //     0x528e30: ldr             x16, [x16, #0xf98]
    // 0x528e34: cmp             w1, w16
    // 0x528e38: b.ne            #0x528e90
    // 0x528e3c: ldur            x0, [fp, #-0x10]
    // 0x528e40: LoadField: r1 = r0->field_b
    //     0x528e40: ldur            w1, [x0, #0xb]
    // 0x528e44: DecompressPointer r1
    //     0x528e44: add             x1, x1, HEAP, lsl #32
    // 0x528e48: LoadField: r0 = r1->field_13
    //     0x528e48: ldur            w0, [x1, #0x13]
    // 0x528e4c: DecompressPointer r0
    //     0x528e4c: add             x0, x0, HEAP, lsl #32
    // 0x528e50: LoadField: r1 = r0->field_5b
    //     0x528e50: ldur            w1, [x0, #0x5b]
    // 0x528e54: DecompressPointer r1
    //     0x528e54: add             x1, x1, HEAP, lsl #32
    // 0x528e58: stur            x1, [fp, #-8]
    // 0x528e5c: ldur            x16, [fp, #-0x18]
    // 0x528e60: stp             x16, NULL, [SP, #-0x10]!
    // 0x528e64: r0 = Future()
    //     0x528e64: bl              #0x4b5784  ; [dart:async] Future::Future
    // 0x528e68: add             SP, SP, #0x10
    // 0x528e6c: ldur            x16, [fp, #-8]
    // 0x528e70: stp             x16, NULL, [SP, #-0x10]!
    // 0x528e74: SaveReg r0
    //     0x528e74: str             x0, [SP, #-8]!
    // 0x528e78: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x528e78: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x528e7c: r0 = listenCancelForAsyncTask()
    //     0x528e7c: bl              #0x5282ac  ; [package:dio/src/dio_mixin.dart] DioMixin::listenCancelForAsyncTask
    // 0x528e80: add             SP, SP, #0x18
    // 0x528e84: LeaveFrame
    //     0x528e84: mov             SP, fp
    //     0x528e88: ldp             fp, lr, [SP], #0x10
    // 0x528e8c: ret
    //     0x528e8c: ret             
    // 0x528e90: ldr             x0, [fp, #0x10]
    // 0x528e94: r0 = Throw()
    //     0x528e94: bl              #0xd67e38  ; ThrowStub
    // 0x528e98: brk             #0
    // 0x528e9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x528e9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x528ea0: b               #0x528ca8
  }
  [closure] Future<InterceptorState<dynamic>> handleError(dynamic) async {
    // ** addr: 0x528f28, size: 0x10c
    // 0x528f28: EnterFrame
    //     0x528f28: stp             fp, lr, [SP, #-0x10]!
    //     0x528f2c: mov             fp, SP
    // 0x528f30: AllocStack(0x20)
    //     0x528f30: sub             SP, SP, #0x20
    // 0x528f34: SetupParameters(_DioForNative&Object&DioMixin this /* r1 */)
    //     0x528f34: stur            NULL, [fp, #-8]
    //     0x528f38: mov             x0, #0
    //     0x528f3c: add             x1, fp, w0, sxtw #2
    //     0x528f40: ldr             x1, [x1, #0x10]
    //     0x528f44: ldur            w2, [x1, #0x17]
    //     0x528f48: add             x2, x2, HEAP, lsl #32
    //     0x528f4c: stur            x2, [fp, #-0x10]
    // 0x528f50: CheckStackOverflow
    //     0x528f50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x528f54: cmp             SP, x16
    //     0x528f58: b.ls            #0x529028
    // 0x528f5c: InitAsync() -> Future<InterceptorState>
    //     0x528f5c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12f38] TypeArguments: <InterceptorState>
    //     0x528f60: ldr             x0, [x0, #0xf38]
    //     0x528f64: bl              #0x4b92e4
    // 0x528f68: r0 = ErrorInterceptorHandler()
    //     0x528f68: bl              #0x529034  ; AllocateErrorInterceptorHandlerStub -> ErrorInterceptorHandler (size=0x10)
    // 0x528f6c: stur            x0, [fp, #-0x18]
    // 0x528f70: SaveReg r0
    //     0x528f70: str             x0, [SP, #-8]!
    // 0x528f74: r0 = _BaseHandler()
    //     0x528f74: bl              #0x528acc  ; [package:dio/src/dio_mixin.dart] _BaseHandler::_BaseHandler
    // 0x528f78: add             SP, SP, #8
    // 0x528f7c: ldur            x0, [fp, #-0x10]
    // 0x528f80: LoadField: r1 = r0->field_b
    //     0x528f80: ldur            w1, [x0, #0xb]
    // 0x528f84: DecompressPointer r1
    //     0x528f84: add             x1, x1, HEAP, lsl #32
    // 0x528f88: LoadField: r3 = r1->field_f
    //     0x528f88: ldur            w3, [x1, #0xf]
    // 0x528f8c: DecompressPointer r3
    //     0x528f8c: add             x3, x3, HEAP, lsl #32
    // 0x528f90: stur            x3, [fp, #-0x20]
    // 0x528f94: LoadField: r1 = r0->field_f
    //     0x528f94: ldur            w1, [x0, #0xf]
    // 0x528f98: DecompressPointer r1
    //     0x528f98: add             x1, x1, HEAP, lsl #32
    // 0x528f9c: LoadField: r4 = r1->field_b
    //     0x528f9c: ldur            w4, [x1, #0xb]
    // 0x528fa0: DecompressPointer r4
    //     0x528fa0: add             x4, x4, HEAP, lsl #32
    // 0x528fa4: mov             x0, x4
    // 0x528fa8: stur            x4, [fp, #-0x10]
    // 0x528fac: r2 = Null
    //     0x528fac: mov             x2, NULL
    // 0x528fb0: r1 = Null
    //     0x528fb0: mov             x1, NULL
    // 0x528fb4: r4 = 59
    //     0x528fb4: mov             x4, #0x3b
    // 0x528fb8: branchIfSmi(r0, 0x528fc4)
    //     0x528fb8: tbz             w0, #0, #0x528fc4
    // 0x528fbc: r4 = LoadClassIdInstr(r0)
    //     0x528fbc: ldur            x4, [x0, #-1]
    //     0x528fc0: ubfx            x4, x4, #0xc, #0x14
    // 0x528fc4: r17 = 4544
    //     0x528fc4: mov             x17, #0x11c0
    // 0x528fc8: cmp             x4, x17
    // 0x528fcc: b.eq            #0x528fe4
    // 0x528fd0: r8 = DioException
    //     0x528fd0: add             x8, PP, #0x12, lsl #12  ; [pp+0x12fa0] Type: DioException
    //     0x528fd4: ldr             x8, [x8, #0xfa0]
    // 0x528fd8: r3 = Null
    //     0x528fd8: add             x3, PP, #0x12, lsl #12  ; [pp+0x12fa8] Null
    //     0x528fdc: ldr             x3, [x3, #0xfa8]
    // 0x528fe0: r0 = DioException()
    //     0x528fe0: bl              #0x527110  ; IsType_DioException_Stub
    // 0x528fe4: ldur            x0, [fp, #-0x20]
    // 0x528fe8: cmp             w0, NULL
    // 0x528fec: b.eq            #0x529030
    // 0x528ff0: ldur            x16, [fp, #-0x10]
    // 0x528ff4: stp             x16, x0, [SP, #-0x10]!
    // 0x528ff8: ldur            x16, [fp, #-0x18]
    // 0x528ffc: SaveReg r16
    //     0x528ffc: str             x16, [SP, #-8]!
    // 0x529000: ClosureCall
    //     0x529000: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x529004: ldur            x2, [x0, #0x1f]
    //     0x529008: blr             x2
    // 0x52900c: add             SP, SP, #0x18
    // 0x529010: ldur            x1, [fp, #-0x18]
    // 0x529014: LoadField: r2 = r1->field_7
    //     0x529014: ldur            w2, [x1, #7]
    // 0x529018: DecompressPointer r2
    //     0x529018: add             x2, x2, HEAP, lsl #32
    // 0x52901c: LoadField: r0 = r2->field_b
    //     0x52901c: ldur            w0, [x2, #0xb]
    // 0x529020: DecompressPointer r0
    //     0x529020: add             x0, x0, HEAP, lsl #32
    // 0x529024: r0 = ReturnAsync()
    //     0x529024: b               #0x501858  ; ReturnAsyncStub
    // 0x529028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x529028: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52902c: b               #0x528f5c
    // 0x529030: r0 = NullErrorSharedWithoutFPURegs()
    //     0x529030: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] Response<Y0> <anonymous closure>(dynamic, Object) {
    // ** addr: 0x529104, size: 0xd4
    // 0x529104: EnterFrame
    //     0x529104: stp             fp, lr, [SP, #-0x10]!
    //     0x529108: mov             fp, SP
    // 0x52910c: ldr             x0, [fp, #0x18]
    // 0x529110: LoadField: r1 = r0->field_17
    //     0x529110: ldur            w1, [x0, #0x17]
    // 0x529114: DecompressPointer r1
    //     0x529114: add             x1, x1, HEAP, lsl #32
    // 0x529118: CheckStackOverflow
    //     0x529118: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52911c: cmp             SP, x16
    //     0x529120: b.ls            #0x5291d0
    // 0x529124: LoadField: r2 = r0->field_b
    //     0x529124: ldur            w2, [x0, #0xb]
    // 0x529128: DecompressPointer r2
    //     0x529128: add             x2, x2, HEAP, lsl #32
    // 0x52912c: ldr             x0, [fp, #0x10]
    // 0x529130: r3 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x529130: mov             x3, #0x76
    //     0x529134: tbz             w0, #0, #0x529144
    //     0x529138: ldur            x3, [x0, #-1]
    //     0x52913c: ubfx            x3, x3, #0xc, #0x14
    //     0x529140: lsl             x3, x3, #1
    // 0x529144: r17 = 9086
    //     0x529144: mov             x17, #0x237e
    // 0x529148: cmp             w3, w17
    // 0x52914c: r16 = true
    //     0x52914c: add             x16, NULL, #0x20  ; true
    // 0x529150: r17 = false
    //     0x529150: add             x17, NULL, #0x30  ; false
    // 0x529154: csel            x4, x16, x17, eq
    // 0x529158: tbnz            w4, #4, #0x5291a4
    // 0x52915c: LoadField: r3 = r0->field_f
    //     0x52915c: ldur            w3, [x0, #0xf]
    // 0x529160: DecompressPointer r3
    //     0x529160: add             x3, x3, HEAP, lsl #32
    // 0x529164: r16 = Instance_InterceptorResultType
    //     0x529164: add             x16, PP, #0x12, lsl #12  ; [pp+0x12fb8] Obj!InterceptorResultType@b66611
    //     0x529168: ldr             x16, [x16, #0xfb8]
    // 0x52916c: cmp             w3, w16
    // 0x529170: b.ne            #0x5291a4
    // 0x529174: LoadField: r3 = r0->field_b
    //     0x529174: ldur            w3, [x0, #0xb]
    // 0x529178: DecompressPointer r3
    //     0x529178: add             x3, x3, HEAP, lsl #32
    // 0x52917c: LoadField: r0 = r1->field_13
    //     0x52917c: ldur            w0, [x1, #0x13]
    // 0x529180: DecompressPointer r0
    //     0x529180: add             x0, x0, HEAP, lsl #32
    // 0x529184: stp             x3, x2, [SP, #-0x10]!
    // 0x529188: SaveReg r0
    //     0x529188: str             x0, [SP, #-8]!
    // 0x52918c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x52918c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x529190: r0 = assureResponse()
    //     0x529190: bl              #0x5291d8  ; [package:dio/src/dio_mixin.dart] DioMixin::assureResponse
    // 0x529194: add             SP, SP, #0x18
    // 0x529198: LeaveFrame
    //     0x529198: mov             SP, fp
    //     0x52919c: ldp             fp, lr, [SP], #0x10
    // 0x5291a0: ret
    //     0x5291a0: ret             
    // 0x5291a4: tbnz            w4, #4, #0x5291b4
    // 0x5291a8: LoadField: r2 = r0->field_b
    //     0x5291a8: ldur            w2, [x0, #0xb]
    // 0x5291ac: DecompressPointer r2
    //     0x5291ac: add             x2, x2, HEAP, lsl #32
    // 0x5291b0: mov             x0, x2
    // 0x5291b4: LoadField: r2 = r1->field_13
    //     0x5291b4: ldur            w2, [x1, #0x13]
    // 0x5291b8: DecompressPointer r2
    //     0x5291b8: add             x2, x2, HEAP, lsl #32
    // 0x5291bc: stp             x2, x0, [SP, #-0x10]!
    // 0x5291c0: r0 = assureDioException()
    //     0x5291c0: bl              #0x528ea4  ; [package:dio/src/dio_mixin.dart] DioMixin::assureDioException
    // 0x5291c4: add             SP, SP, #0x10
    // 0x5291c8: r0 = Throw()
    //     0x5291c8: bl              #0xd67e38  ; ThrowStub
    // 0x5291cc: brk             #0
    // 0x5291d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5291d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5291d4: b               #0x529124
  }
  [closure] Response<Y0> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x52a5b4, size: 0xd8
    // 0x52a5b4: EnterFrame
    //     0x52a5b4: stp             fp, lr, [SP, #-0x10]!
    //     0x52a5b8: mov             fp, SP
    // 0x52a5bc: AllocStack(0x18)
    //     0x52a5bc: sub             SP, SP, #0x18
    // 0x52a5c0: SetupParameters()
    //     0x52a5c0: ldr             x0, [fp, #0x18]
    //     0x52a5c4: ldur            w3, [x0, #0x17]
    //     0x52a5c8: add             x3, x3, HEAP, lsl #32
    //     0x52a5cc: stur            x3, [fp, #-0x18]
    // 0x52a5d0: CheckStackOverflow
    //     0x52a5d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52a5d4: cmp             SP, x16
    //     0x52a5d8: b.ls            #0x52a684
    // 0x52a5dc: LoadField: r4 = r0->field_b
    //     0x52a5dc: ldur            w4, [x0, #0xb]
    // 0x52a5e0: DecompressPointer r4
    //     0x52a5e0: add             x4, x4, HEAP, lsl #32
    // 0x52a5e4: ldr             x0, [fp, #0x10]
    // 0x52a5e8: stur            x4, [fp, #-0x10]
    // 0x52a5ec: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x52a5ec: mov             x1, #0x76
    //     0x52a5f0: tbz             w0, #0, #0x52a600
    //     0x52a5f4: ldur            x1, [x0, #-1]
    //     0x52a5f8: ubfx            x1, x1, #0xc, #0x14
    //     0x52a5fc: lsl             x1, x1, #1
    // 0x52a600: r17 = 9086
    //     0x52a600: mov             x17, #0x237e
    // 0x52a604: cmp             w1, w17
    // 0x52a608: b.ne            #0x52a61c
    // 0x52a60c: LoadField: r1 = r0->field_b
    //     0x52a60c: ldur            w1, [x0, #0xb]
    // 0x52a610: DecompressPointer r1
    //     0x52a610: add             x1, x1, HEAP, lsl #32
    // 0x52a614: mov             x5, x1
    // 0x52a618: b               #0x52a620
    // 0x52a61c: mov             x5, x0
    // 0x52a620: stur            x5, [fp, #-8]
    // 0x52a624: cmp             w5, NULL
    // 0x52a628: b.ne            #0x52a650
    // 0x52a62c: mov             x0, x5
    // 0x52a630: r2 = Null
    //     0x52a630: mov             x2, NULL
    // 0x52a634: r1 = Null
    //     0x52a634: mov             x1, NULL
    // 0x52a638: cmp             w0, NULL
    // 0x52a63c: b.ne            #0x52a650
    // 0x52a640: r8 = Object
    //     0x52a640: ldr             x8, [PP, #0x3408]  ; [pp+0x3408] Type: Object
    // 0x52a644: r3 = Null
    //     0x52a644: add             x3, PP, #0x13, lsl #12  ; [pp+0x130c8] Null
    //     0x52a648: ldr             x3, [x3, #0xc8]
    // 0x52a64c: r0 = Object()
    //     0x52a64c: bl              #0xd74634  ; IsType_Object_Stub
    // 0x52a650: ldur            x0, [fp, #-0x18]
    // 0x52a654: LoadField: r1 = r0->field_13
    //     0x52a654: ldur            w1, [x0, #0x13]
    // 0x52a658: DecompressPointer r1
    //     0x52a658: add             x1, x1, HEAP, lsl #32
    // 0x52a65c: ldur            x16, [fp, #-0x10]
    // 0x52a660: ldur            lr, [fp, #-8]
    // 0x52a664: stp             lr, x16, [SP, #-0x10]!
    // 0x52a668: SaveReg r1
    //     0x52a668: str             x1, [SP, #-8]!
    // 0x52a66c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x52a66c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x52a670: r0 = assureResponse()
    //     0x52a670: bl              #0x5291d8  ; [package:dio/src/dio_mixin.dart] DioMixin::assureResponse
    // 0x52a674: add             SP, SP, #0x18
    // 0x52a678: LeaveFrame
    //     0x52a678: mov             SP, fp
    //     0x52a67c: ldp             fp, lr, [SP], #0x10
    // 0x52a680: ret
    //     0x52a680: ret             
    // 0x52a684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52a684: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52a688: b               #0x52a5dc
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, dynamic) async {
    // ** addr: 0x52a68c, size: 0x13c
    // 0x52a68c: EnterFrame
    //     0x52a68c: stp             fp, lr, [SP, #-0x10]!
    //     0x52a690: mov             fp, SP
    // 0x52a694: AllocStack(0x28)
    //     0x52a694: sub             SP, SP, #0x28
    // 0x52a698: SetupParameters(_DioForNative&Object&DioMixin this /* r1 */, dynamic _ /* r2, fp-0x20 */)
    //     0x52a698: stur            NULL, [fp, #-8]
    //     0x52a69c: mov             x0, #0
    //     0x52a6a0: add             x1, fp, w0, sxtw #2
    //     0x52a6a4: ldr             x1, [x1, #0x18]
    //     0x52a6a8: add             x2, fp, w0, sxtw #2
    //     0x52a6ac: ldr             x2, [x2, #0x10]
    //     0x52a6b0: stur            x2, [fp, #-0x20]
    //     0x52a6b4: ldur            w3, [x1, #0x17]
    //     0x52a6b8: add             x3, x3, HEAP, lsl #32
    //     0x52a6bc: stur            x3, [fp, #-0x18]
    // 0x52a6c0: CheckStackOverflow
    //     0x52a6c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52a6c4: cmp             SP, x16
    //     0x52a6c8: b.ls            #0x52a7c0
    // 0x52a6cc: LoadField: r4 = r1->field_b
    //     0x52a6cc: ldur            w4, [x1, #0xb]
    // 0x52a6d0: DecompressPointer r4
    //     0x52a6d0: add             x4, x4, HEAP, lsl #32
    // 0x52a6d4: stur            x4, [fp, #-0x10]
    // 0x52a6d8: InitAsync() -> Future
    //     0x52a6d8: mov             x0, NULL
    //     0x52a6dc: bl              #0x4b92e4
    // 0x52a6e0: r1 = 1
    //     0x52a6e0: mov             x1, #1
    // 0x52a6e4: r0 = AllocateContext()
    //     0x52a6e4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x52a6e8: mov             x4, x0
    // 0x52a6ec: ldur            x3, [fp, #-0x18]
    // 0x52a6f0: stur            x4, [fp, #-0x28]
    // 0x52a6f4: StoreField: r4->field_b = r3
    //     0x52a6f4: stur            w3, [x4, #0xb]
    // 0x52a6f8: ldur            x0, [fp, #-0x20]
    // 0x52a6fc: r2 = Null
    //     0x52a6fc: mov             x2, NULL
    // 0x52a700: r1 = Null
    //     0x52a700: mov             x1, NULL
    // 0x52a704: r4 = 59
    //     0x52a704: mov             x4, #0x3b
    // 0x52a708: branchIfSmi(r0, 0x52a714)
    //     0x52a708: tbz             w0, #0, #0x52a714
    // 0x52a70c: r4 = LoadClassIdInstr(r0)
    //     0x52a70c: ldur            x4, [x0, #-1]
    //     0x52a710: ubfx            x4, x4, #0xc, #0x14
    // 0x52a714: r17 = 4543
    //     0x52a714: mov             x17, #0x11bf
    // 0x52a718: cmp             x4, x17
    // 0x52a71c: b.eq            #0x52a734
    // 0x52a720: r8 = InterceptorState
    //     0x52a720: add             x8, PP, #0x12, lsl #12  ; [pp+0x12ef8] Type: InterceptorState
    //     0x52a724: ldr             x8, [x8, #0xef8]
    // 0x52a728: r3 = Null
    //     0x52a728: add             x3, PP, #0x13, lsl #12  ; [pp+0x130d8] Null
    //     0x52a72c: ldr             x3, [x3, #0xd8]
    // 0x52a730: r0 = InterceptorState()
    //     0x52a730: bl              #0x528ba4  ; IsType_InterceptorState_Stub
    // 0x52a734: ldur            x0, [fp, #-0x20]
    // 0x52a738: ldur            x2, [fp, #-0x28]
    // 0x52a73c: StoreField: r2->field_f = r0
    //     0x52a73c: stur            w0, [x2, #0xf]
    // 0x52a740: LoadField: r1 = r0->field_f
    //     0x52a740: ldur            w1, [x0, #0xf]
    // 0x52a744: DecompressPointer r1
    //     0x52a744: add             x1, x1, HEAP, lsl #32
    // 0x52a748: r16 = Instance_InterceptorResultType
    //     0x52a748: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed0] Obj!InterceptorResultType@b665b1
    //     0x52a74c: ldr             x16, [x16, #0xed0]
    // 0x52a750: cmp             w1, w16
    // 0x52a754: b.ne            #0x52a7bc
    // 0x52a758: ldur            x0, [fp, #-0x18]
    // 0x52a75c: ldur            x3, [fp, #-0x10]
    // 0x52a760: LoadField: r1 = r0->field_b
    //     0x52a760: ldur            w1, [x0, #0xb]
    // 0x52a764: DecompressPointer r1
    //     0x52a764: add             x1, x1, HEAP, lsl #32
    // 0x52a768: LoadField: r0 = r1->field_13
    //     0x52a768: ldur            w0, [x1, #0x13]
    // 0x52a76c: DecompressPointer r0
    //     0x52a76c: add             x0, x0, HEAP, lsl #32
    // 0x52a770: LoadField: r4 = r0->field_5b
    //     0x52a770: ldur            w4, [x0, #0x5b]
    // 0x52a774: DecompressPointer r4
    //     0x52a774: add             x4, x4, HEAP, lsl #32
    // 0x52a778: stur            x4, [fp, #-0x18]
    // 0x52a77c: r1 = Function '<anonymous closure>':.
    //     0x52a77c: add             x1, PP, #0x13, lsl #12  ; [pp+0x130e8] AnonymousClosure: (0x52a7c8), in [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::<anonymous closure> (0x52a68c)
    //     0x52a780: ldr             x1, [x1, #0xe8]
    // 0x52a784: r0 = AllocateClosure()
    //     0x52a784: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52a788: mov             x1, x0
    // 0x52a78c: ldur            x0, [fp, #-0x10]
    // 0x52a790: StoreField: r1->field_b = r0
    //     0x52a790: stur            w0, [x1, #0xb]
    // 0x52a794: stp             x1, NULL, [SP, #-0x10]!
    // 0x52a798: r0 = Future()
    //     0x52a798: bl              #0x4b5784  ; [dart:async] Future::Future
    // 0x52a79c: add             SP, SP, #0x10
    // 0x52a7a0: ldur            x16, [fp, #-0x18]
    // 0x52a7a4: stp             x16, NULL, [SP, #-0x10]!
    // 0x52a7a8: SaveReg r0
    //     0x52a7a8: str             x0, [SP, #-8]!
    // 0x52a7ac: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x52a7ac: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x52a7b0: r0 = listenCancelForAsyncTask()
    //     0x52a7b0: bl              #0x5282ac  ; [package:dio/src/dio_mixin.dart] DioMixin::listenCancelForAsyncTask
    // 0x52a7b4: add             SP, SP, #0x18
    // 0x52a7b8: r0 = ReturnAsync()
    //     0x52a7b8: b               #0x501858  ; ReturnAsyncStub
    // 0x52a7bc: r0 = ReturnAsyncNotFuture()
    //     0x52a7bc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x52a7c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52a7c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52a7c4: b               #0x52a6cc
  }
  [closure] Future<InterceptorState<dynamic>> <anonymous closure>(dynamic) {
    // ** addr: 0x52a7c8, size: 0xfc
    // 0x52a7c8: EnterFrame
    //     0x52a7c8: stp             fp, lr, [SP, #-0x10]!
    //     0x52a7cc: mov             fp, SP
    // 0x52a7d0: AllocStack(0x18)
    //     0x52a7d0: sub             SP, SP, #0x18
    // 0x52a7d4: SetupParameters()
    //     0x52a7d4: ldr             x0, [fp, #0x10]
    //     0x52a7d8: ldur            w1, [x0, #0x17]
    //     0x52a7dc: add             x1, x1, HEAP, lsl #32
    //     0x52a7e0: stur            x1, [fp, #-8]
    // 0x52a7e4: CheckStackOverflow
    //     0x52a7e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52a7e8: cmp             SP, x16
    //     0x52a7ec: b.ls            #0x52a8b8
    // 0x52a7f0: r0 = RequestInterceptorHandler()
    //     0x52a7f0: bl              #0x52a900  ; AllocateRequestInterceptorHandlerStub -> RequestInterceptorHandler (size=0x10)
    // 0x52a7f4: stur            x0, [fp, #-0x10]
    // 0x52a7f8: SaveReg r0
    //     0x52a7f8: str             x0, [SP, #-8]!
    // 0x52a7fc: r0 = RequestInterceptorHandler()
    //     0x52a7fc: bl              #0x52a8c4  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::RequestInterceptorHandler
    // 0x52a800: add             SP, SP, #8
    // 0x52a804: ldur            x0, [fp, #-8]
    // 0x52a808: LoadField: r1 = r0->field_b
    //     0x52a808: ldur            w1, [x0, #0xb]
    // 0x52a80c: DecompressPointer r1
    //     0x52a80c: add             x1, x1, HEAP, lsl #32
    // 0x52a810: LoadField: r3 = r1->field_f
    //     0x52a810: ldur            w3, [x1, #0xf]
    // 0x52a814: DecompressPointer r3
    //     0x52a814: add             x3, x3, HEAP, lsl #32
    // 0x52a818: stur            x3, [fp, #-0x18]
    // 0x52a81c: LoadField: r1 = r0->field_f
    //     0x52a81c: ldur            w1, [x0, #0xf]
    // 0x52a820: DecompressPointer r1
    //     0x52a820: add             x1, x1, HEAP, lsl #32
    // 0x52a824: LoadField: r4 = r1->field_b
    //     0x52a824: ldur            w4, [x1, #0xb]
    // 0x52a828: DecompressPointer r4
    //     0x52a828: add             x4, x4, HEAP, lsl #32
    // 0x52a82c: mov             x0, x4
    // 0x52a830: stur            x4, [fp, #-8]
    // 0x52a834: r2 = Null
    //     0x52a834: mov             x2, NULL
    // 0x52a838: r1 = Null
    //     0x52a838: mov             x1, NULL
    // 0x52a83c: r4 = 59
    //     0x52a83c: mov             x4, #0x3b
    // 0x52a840: branchIfSmi(r0, 0x52a84c)
    //     0x52a840: tbz             w0, #0, #0x52a84c
    // 0x52a844: r4 = LoadClassIdInstr(r0)
    //     0x52a844: ldur            x4, [x0, #-1]
    //     0x52a848: ubfx            x4, x4, #0xc, #0x14
    // 0x52a84c: r17 = 4532
    //     0x52a84c: mov             x17, #0x11b4
    // 0x52a850: cmp             x4, x17
    // 0x52a854: b.eq            #0x52a86c
    // 0x52a858: r8 = RequestOptions
    //     0x52a858: add             x8, PP, #0x13, lsl #12  ; [pp+0x130f0] Type: RequestOptions
    //     0x52a85c: ldr             x8, [x8, #0xf0]
    // 0x52a860: r3 = Null
    //     0x52a860: add             x3, PP, #0x13, lsl #12  ; [pp+0x130f8] Null
    //     0x52a864: ldr             x3, [x3, #0xf8]
    // 0x52a868: r0 = RequestOptions()
    //     0x52a868: bl              #0x527f74  ; IsType_RequestOptions_Stub
    // 0x52a86c: ldur            x0, [fp, #-0x18]
    // 0x52a870: cmp             w0, NULL
    // 0x52a874: b.eq            #0x52a8c0
    // 0x52a878: ldur            x16, [fp, #-8]
    // 0x52a87c: stp             x16, x0, [SP, #-0x10]!
    // 0x52a880: ldur            x16, [fp, #-0x10]
    // 0x52a884: SaveReg r16
    //     0x52a884: str             x16, [SP, #-8]!
    // 0x52a888: ClosureCall
    //     0x52a888: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x52a88c: ldur            x2, [x0, #0x1f]
    //     0x52a890: blr             x2
    // 0x52a894: add             SP, SP, #0x18
    // 0x52a898: ldur            x1, [fp, #-0x10]
    // 0x52a89c: LoadField: r2 = r1->field_7
    //     0x52a89c: ldur            w2, [x1, #7]
    // 0x52a8a0: DecompressPointer r2
    //     0x52a8a0: add             x2, x2, HEAP, lsl #32
    // 0x52a8a4: LoadField: r0 = r2->field_b
    //     0x52a8a4: ldur            w0, [x2, #0xb]
    // 0x52a8a8: DecompressPointer r0
    //     0x52a8a8: add             x0, x0, HEAP, lsl #32
    // 0x52a8ac: LeaveFrame
    //     0x52a8ac: mov             SP, fp
    //     0x52a8b0: ldp             fp, lr, [SP], #0x10
    // 0x52a8b4: ret
    //     0x52a8b4: ret             
    // 0x52a8b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52a8b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52a8bc: b               #0x52a7f0
    // 0x52a8c0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x52a8c0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RequestOptions, RequestInterceptorHandler) {
    // ** addr: 0x52a90c, size: 0x120
    // 0x52a90c: EnterFrame
    //     0x52a90c: stp             fp, lr, [SP, #-0x10]!
    //     0x52a910: mov             fp, SP
    // 0x52a914: AllocStack(0x18)
    //     0x52a914: sub             SP, SP, #0x18
    // 0x52a918: SetupParameters()
    //     0x52a918: ldr             x0, [fp, #0x20]
    //     0x52a91c: ldur            w1, [x0, #0x17]
    //     0x52a920: add             x1, x1, HEAP, lsl #32
    //     0x52a924: stur            x1, [fp, #-8]
    // 0x52a928: CheckStackOverflow
    //     0x52a928: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52a92c: cmp             SP, x16
    //     0x52a930: b.ls            #0x52aa24
    // 0x52a934: r1 = 1
    //     0x52a934: mov             x1, #1
    // 0x52a938: r0 = AllocateContext()
    //     0x52a938: bl              #0xd68aa4  ; AllocateContextStub
    // 0x52a93c: mov             x2, x0
    // 0x52a940: ldur            x1, [fp, #-8]
    // 0x52a944: stur            x2, [fp, #-0x18]
    // 0x52a948: StoreField: r2->field_b = r1
    //     0x52a948: stur            w1, [x2, #0xb]
    // 0x52a94c: ldr             x0, [fp, #0x10]
    // 0x52a950: StoreField: r2->field_f = r0
    //     0x52a950: stur            w0, [x2, #0xf]
    // 0x52a954: ldr             x0, [fp, #0x20]
    // 0x52a958: LoadField: r3 = r0->field_b
    //     0x52a958: ldur            w3, [x0, #0xb]
    // 0x52a95c: DecompressPointer r3
    //     0x52a95c: add             x3, x3, HEAP, lsl #32
    // 0x52a960: ldr             x0, [fp, #0x18]
    // 0x52a964: stur            x3, [fp, #-0x10]
    // 0x52a968: StoreField: r1->field_13 = r0
    //     0x52a968: stur            w0, [x1, #0x13]
    //     0x52a96c: ldurb           w16, [x1, #-1]
    //     0x52a970: ldurb           w17, [x0, #-1]
    //     0x52a974: and             x16, x17, x16, lsr #2
    //     0x52a978: tst             x16, HEAP, lsr #32
    //     0x52a97c: b.eq            #0x52a984
    //     0x52a980: bl              #0xd6826c
    // 0x52a984: LoadField: r0 = r1->field_f
    //     0x52a984: ldur            w0, [x1, #0xf]
    // 0x52a988: DecompressPointer r0
    //     0x52a988: add             x0, x0, HEAP, lsl #32
    // 0x52a98c: stp             x0, x3, [SP, #-0x10]!
    // 0x52a990: ldr             x16, [fp, #0x18]
    // 0x52a994: SaveReg r16
    //     0x52a994: str             x16, [SP, #-8]!
    // 0x52a998: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x52a998: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x52a99c: r0 = _dispatchRequest()
    //     0x52a99c: bl              #0x52aa2c  ; [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::_dispatchRequest
    // 0x52a9a0: add             SP, SP, #0x18
    // 0x52a9a4: ldur            x2, [fp, #-0x18]
    // 0x52a9a8: r1 = Function '<anonymous closure>':.
    //     0x52a9a8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13108] AnonymousClosure: (0x55a8b0), in [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::fetch (0x5273d0)
    //     0x52a9ac: ldr             x1, [x1, #0x108]
    // 0x52a9b0: stur            x0, [fp, #-8]
    // 0x52a9b4: r0 = AllocateClosure()
    //     0x52a9b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52a9b8: mov             x1, x0
    // 0x52a9bc: ldur            x0, [fp, #-0x10]
    // 0x52a9c0: StoreField: r1->field_b = r0
    //     0x52a9c0: stur            w0, [x1, #0xb]
    // 0x52a9c4: r16 = <void?>
    //     0x52a9c4: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x52a9c8: ldur            lr, [fp, #-8]
    // 0x52a9cc: stp             lr, x16, [SP, #-0x10]!
    // 0x52a9d0: SaveReg r1
    //     0x52a9d0: str             x1, [SP, #-8]!
    // 0x52a9d4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x52a9d4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x52a9d8: r0 = then()
    //     0x52a9d8: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x52a9dc: add             SP, SP, #0x18
    // 0x52a9e0: ldur            x2, [fp, #-0x18]
    // 0x52a9e4: r1 = Function '<anonymous closure>':.
    //     0x52a9e4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13110] AnonymousClosure: (0x55a794), in [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::fetch (0x5273d0)
    //     0x52a9e8: ldr             x1, [x1, #0x110]
    // 0x52a9ec: stur            x0, [fp, #-8]
    // 0x52a9f0: r0 = AllocateClosure()
    //     0x52a9f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52a9f4: mov             x1, x0
    // 0x52a9f8: ldur            x0, [fp, #-0x10]
    // 0x52a9fc: StoreField: r1->field_b = r0
    //     0x52a9fc: stur            w0, [x1, #0xb]
    // 0x52aa00: ldur            x16, [fp, #-8]
    // 0x52aa04: stp             x1, x16, [SP, #-0x10]!
    // 0x52aa08: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x52aa08: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x52aa0c: r0 = catchError()
    //     0x52aa0c: bl              #0xca5bb8  ; [dart:async] _Future::catchError
    // 0x52aa10: add             SP, SP, #0x10
    // 0x52aa14: r0 = Null
    //     0x52aa14: mov             x0, NULL
    // 0x52aa18: LeaveFrame
    //     0x52aa18: mov             SP, fp
    //     0x52aa1c: ldp             fp, lr, [SP], #0x10
    // 0x52aa20: ret
    //     0x52aa20: ret             
    // 0x52aa24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52aa24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52aa28: b               #0x52a934
  }
  _ _dispatchRequest(/* No info */) async {
    // ** addr: 0x52aa2c, size: 0x2fc
    // 0x52aa2c: EnterFrame
    //     0x52aa2c: stp             fp, lr, [SP, #-0x10]!
    //     0x52aa30: mov             fp, SP
    // 0x52aa34: AllocStack(0xc8)
    //     0x52aa34: sub             SP, SP, #0xc8
    // 0x52aa38: SetupParameters(_DioForNative&Object&DioMixin this /* r2, fp-0xa8 */, dynamic _ /* r3, fp-0xa0 */)
    //     0x52aa38: stur            NULL, [fp, #-8]
    //     0x52aa3c: mov             x0, #0
    //     0x52aa40: stur            x4, [fp, #-0xb0]
    //     0x52aa44: mov             x1, x4
    //     0x52aa48: add             x2, fp, w0, sxtw #2
    //     0x52aa4c: ldr             x2, [x2, #0x18]
    //     0x52aa50: stur            x2, [fp, #-0xa8]
    //     0x52aa54: add             x3, fp, w0, sxtw #2
    //     0x52aa58: ldr             x3, [x3, #0x10]
    //     0x52aa5c: stur            x3, [fp, #-0xa0]
    // 0x52aa60: CheckStackOverflow
    //     0x52aa60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52aa64: cmp             SP, x16
    //     0x52aa68: b.ls            #0x52acf8
    // 0x52aa6c: InitAsync() -> Future<Response>
    //     0x52aa6c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12f70] TypeArguments: <Response>
    //     0x52aa70: ldr             x0, [x0, #0xf70]
    //     0x52aa74: bl              #0x4b92e4
    // 0x52aa78: ldur            x0, [fp, #-0xa0]
    // 0x52aa7c: LoadField: r1 = r0->field_5b
    //     0x52aa7c: ldur            w1, [x0, #0x5b]
    // 0x52aa80: DecompressPointer r1
    //     0x52aa80: add             x1, x1, HEAP, lsl #32
    // 0x52aa84: stur            x1, [fp, #-0xb0]
    // 0x52aa88: ldur            x2, [fp, #-0xa8]
    // 0x52aa8c: stp             x0, x2, [SP, #-0x10]!
    // 0x52aa90: r0 = _transformData()
    //     0x52aa90: bl              #0x5572f0  ; [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::_transformData
    // 0x52aa94: add             SP, SP, #0x10
    // 0x52aa98: mov             x1, x0
    // 0x52aa9c: stur            x1, [fp, #-0xb8]
    // 0x52aaa0: r0 = Await()
    //     0x52aaa0: bl              #0x4b8e6c  ; AwaitStub
    // 0x52aaa4: mov             x1, x0
    // 0x52aaa8: ldur            x0, [fp, #-0xa8]
    // 0x52aaac: LoadField: r2 = r0->field_f
    //     0x52aaac: ldur            w2, [x0, #0xf]
    // 0x52aab0: DecompressPointer r2
    //     0x52aab0: add             x2, x2, HEAP, lsl #32
    // 0x52aab4: r16 = Sentinel
    //     0x52aab4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52aab8: cmp             w2, w16
    // 0x52aabc: b.eq            #0x52ad00
    // 0x52aac0: ldur            x3, [fp, #-0xb0]
    // 0x52aac4: cmp             w3, NULL
    // 0x52aac8: b.ne            #0x52aad4
    // 0x52aacc: r5 = Null
    //     0x52aacc: mov             x5, NULL
    // 0x52aad0: b               #0x52aae4
    // 0x52aad4: LoadField: r4 = r3->field_7
    //     0x52aad4: ldur            w4, [x3, #7]
    // 0x52aad8: DecompressPointer r4
    //     0x52aad8: add             x4, x4, HEAP, lsl #32
    // 0x52aadc: LoadField: r5 = r4->field_b
    //     0x52aadc: ldur            w5, [x4, #0xb]
    // 0x52aae0: DecompressPointer r5
    //     0x52aae0: add             x5, x5, HEAP, lsl #32
    // 0x52aae4: ldur            x4, [fp, #-0xa0]
    // 0x52aae8: stp             x4, x2, [SP, #-0x10]!
    // 0x52aaec: stp             x5, x1, [SP, #-0x10]!
    // 0x52aaf0: r0 = fetch()
    //     0x52aaf0: bl              #0x52e810  ; [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::fetch
    // 0x52aaf4: add             SP, SP, #0x20
    // 0x52aaf8: mov             x1, x0
    // 0x52aafc: stur            x1, [fp, #-0xb8]
    // 0x52ab00: r0 = Await()
    //     0x52ab00: bl              #0x4b8e6c  ; AwaitStub
    // 0x52ab04: stur            x0, [fp, #-0xb8]
    // 0x52ab08: r0 = Headers()
    //     0x52ab08: bl              #0x52a1cc  ; AllocateHeadersStub -> Headers (size=0xc)
    // 0x52ab0c: mov             x1, x0
    // 0x52ab10: ldur            x0, [fp, #-0xb8]
    // 0x52ab14: stur            x1, [fp, #-0xc0]
    // 0x52ab18: cmp             w0, NULL
    // 0x52ab1c: b.eq            #0x52ad0c
    // 0x52ab20: LoadField: r2 = r0->field_b
    //     0x52ab20: ldur            w2, [x0, #0xb]
    // 0x52ab24: DecompressPointer r2
    //     0x52ab24: add             x2, x2, HEAP, lsl #32
    // 0x52ab28: stp             x2, x1, [SP, #-0x10]!
    // 0x52ab2c: r0 = Headers.fromMap()
    //     0x52ab2c: bl              #0x52948c  ; [package:dio/src/headers.dart] Headers::Headers.fromMap
    // 0x52ab30: add             SP, SP, #0x10
    // 0x52ab34: ldur            x2, [fp, #-0xc0]
    // 0x52ab38: LoadField: r0 = r2->field_7
    //     0x52ab38: ldur            w0, [x2, #7]
    // 0x52ab3c: DecompressPointer r0
    //     0x52ab3c: add             x0, x0, HEAP, lsl #32
    // 0x52ab40: ldur            x3, [fp, #-0xb8]
    // 0x52ab44: StoreField: r3->field_b = r0
    //     0x52ab44: stur            w0, [x3, #0xb]
    //     0x52ab48: ldurb           w16, [x3, #-1]
    //     0x52ab4c: ldurb           w17, [x0, #-1]
    //     0x52ab50: and             x16, x17, x16, lsr #2
    //     0x52ab54: tst             x16, HEAP, lsr #32
    //     0x52ab58: b.eq            #0x52ab60
    //     0x52ab5c: bl              #0xd682ac
    // 0x52ab60: r1 = Null
    //     0x52ab60: mov             x1, NULL
    // 0x52ab64: r0 = Response()
    //     0x52ab64: bl              #0x52a5a8  ; AllocateResponseStub -> Response<X0> (size=0x2c)
    // 0x52ab68: mov             x3, x0
    // 0x52ab6c: ldur            x2, [fp, #-0xb8]
    // 0x52ab70: stur            x3, [fp, #-0xc8]
    // 0x52ab74: LoadField: r4 = r2->field_1f
    //     0x52ab74: ldur            w4, [x2, #0x1f]
    // 0x52ab78: DecompressPointer r4
    //     0x52ab78: add             x4, x4, HEAP, lsl #32
    // 0x52ab7c: LoadField: r5 = r2->field_1b
    //     0x52ab7c: ldur            w5, [x2, #0x1b]
    // 0x52ab80: DecompressPointer r5
    //     0x52ab80: add             x5, x5, HEAP, lsl #32
    // 0x52ab84: LoadField: r6 = r2->field_f
    //     0x52ab84: ldur            x6, [x2, #0xf]
    // 0x52ab88: LoadField: r7 = r2->field_17
    //     0x52ab88: ldur            w7, [x2, #0x17]
    // 0x52ab8c: DecompressPointer r7
    //     0x52ab8c: add             x7, x7, HEAP, lsl #32
    // 0x52ab90: LoadField: r8 = r2->field_23
    //     0x52ab90: ldur            w8, [x2, #0x23]
    // 0x52ab94: DecompressPointer r8
    //     0x52ab94: add             x8, x8, HEAP, lsl #32
    // 0x52ab98: ldur            x10, [fp, #-0xa0]
    // 0x52ab9c: StoreField: r3->field_f = r10
    //     0x52ab9c: stur            w10, [x3, #0xf]
    // 0x52aba0: r0 = BoxInt64Instr(r6)
    //     0x52aba0: sbfiz           x0, x6, #1, #0x1f
    //     0x52aba4: cmp             x6, x0, asr #1
    //     0x52aba8: b.eq            #0x52abb4
    //     0x52abac: bl              #0xd69bb8
    //     0x52abb0: stur            x6, [x0, #7]
    // 0x52abb4: StoreField: r3->field_13 = r0
    //     0x52abb4: stur            w0, [x3, #0x13]
    // 0x52abb8: StoreField: r3->field_17 = r7
    //     0x52abb8: stur            w7, [x3, #0x17]
    // 0x52abbc: StoreField: r3->field_1b = r5
    //     0x52abbc: stur            w5, [x3, #0x1b]
    // 0x52abc0: StoreField: r3->field_1f = r4
    //     0x52abc0: stur            w4, [x3, #0x1f]
    // 0x52abc4: StoreField: r3->field_23 = r8
    //     0x52abc4: stur            w8, [x3, #0x23]
    // 0x52abc8: ldur            x1, [fp, #-0xc0]
    // 0x52abcc: StoreField: r3->field_27 = r1
    //     0x52abcc: stur            w1, [x3, #0x27]
    // 0x52abd0: LoadField: r1 = r10->field_1f
    //     0x52abd0: ldur            w1, [x10, #0x1f]
    // 0x52abd4: DecompressPointer r1
    //     0x52abd4: add             x1, x1, HEAP, lsl #32
    // 0x52abd8: r16 = Sentinel
    //     0x52abd8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52abdc: cmp             w1, w16
    // 0x52abe0: b.eq            #0x52ad10
    // 0x52abe4: stur            x1, [fp, #-0xc0]
    // 0x52abe8: stp             x0, x1, [SP, #-0x10]!
    // 0x52abec: mov             x0, x1
    // 0x52abf0: ClosureCall
    //     0x52abf0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x52abf4: ldur            x2, [x0, #0x1f]
    //     0x52abf8: blr             x2
    // 0x52abfc: add             SP, SP, #0x10
    // 0x52ac00: mov             x1, x0
    // 0x52ac04: stur            x1, [fp, #-0xc0]
    // 0x52ac08: tbnz            w0, #5, #0x52ac10
    // 0x52ac0c: r0 = AssertBoolean()
    //     0x52ac0c: bl              #0xd67df0  ; AssertBooleanStub
    // 0x52ac10: ldur            x0, [fp, #-0xc0]
    // 0x52ac14: tbnz            w0, #4, #0x52ac20
    // 0x52ac18: ldur            x1, [fp, #-0xa0]
    // 0x52ac1c: b               #0x52ac38
    // 0x52ac20: ldur            x1, [fp, #-0xa0]
    // 0x52ac24: LoadField: r2 = r1->field_23
    //     0x52ac24: ldur            w2, [x1, #0x23]
    // 0x52ac28: DecompressPointer r2
    //     0x52ac28: add             x2, x2, HEAP, lsl #32
    // 0x52ac2c: r16 = Sentinel
    //     0x52ac2c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52ac30: cmp             w2, w16
    // 0x52ac34: b.eq            #0x52ad1c
    // 0x52ac38: ldur            x3, [fp, #-0xa8]
    // 0x52ac3c: ldur            x2, [fp, #-0xc8]
    // 0x52ac40: LoadField: r4 = r3->field_13
    //     0x52ac40: ldur            w4, [x3, #0x13]
    // 0x52ac44: DecompressPointer r4
    //     0x52ac44: add             x4, x4, HEAP, lsl #32
    // 0x52ac48: stp             x1, x4, [SP, #-0x10]!
    // 0x52ac4c: ldur            x16, [fp, #-0xb8]
    // 0x52ac50: SaveReg r16
    //     0x52ac50: str             x16, [SP, #-8]!
    // 0x52ac54: r0 = transformResponse()
    //     0x52ac54: bl              #0x52ae28  ; [package:dio/src/transformers/sync_transformer.dart] SyncTransformer::transformResponse
    // 0x52ac58: add             SP, SP, #0x18
    // 0x52ac5c: mov             x1, x0
    // 0x52ac60: stur            x1, [fp, #-0xa8]
    // 0x52ac64: r0 = Await()
    //     0x52ac64: bl              #0x4b8e6c  ; AwaitStub
    // 0x52ac68: ldur            x1, [fp, #-0xc8]
    // 0x52ac6c: StoreField: r1->field_b = r0
    //     0x52ac6c: stur            w0, [x1, #0xb]
    //     0x52ac70: tbz             w0, #0, #0x52ac8c
    //     0x52ac74: ldurb           w16, [x1, #-1]
    //     0x52ac78: ldurb           w17, [x0, #-1]
    //     0x52ac7c: and             x16, x17, x16, lsr #2
    //     0x52ac80: tst             x16, HEAP, lsr #32
    //     0x52ac84: b.eq            #0x52ac8c
    //     0x52ac88: bl              #0xd6826c
    // 0x52ac8c: ldur            x16, [fp, #-0xb0]
    // 0x52ac90: SaveReg r16
    //     0x52ac90: str             x16, [SP, #-8]!
    // 0x52ac94: r0 = checkCancelled()
    //     0x52ac94: bl              #0x52ade0  ; [package:dio/src/dio_mixin.dart] DioMixin::checkCancelled
    // 0x52ac98: add             SP, SP, #8
    // 0x52ac9c: ldur            x0, [fp, #-0xc0]
    // 0x52aca0: tbnz            w0, #4, #0x52acac
    // 0x52aca4: ldur            x0, [fp, #-0xc8]
    // 0x52aca8: r0 = ReturnAsyncNotFuture()
    //     0x52aca8: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x52acac: ldur            x0, [fp, #-0xb8]
    // 0x52acb0: LoadField: r1 = r0->field_f
    //     0x52acb0: ldur            x1, [x0, #0xf]
    // 0x52acb4: ldur            x16, [fp, #-0xa0]
    // 0x52acb8: stp             x16, NULL, [SP, #-0x10]!
    // 0x52acbc: ldur            x16, [fp, #-0xc8]
    // 0x52acc0: stp             x1, x16, [SP, #-0x10]!
    // 0x52acc4: r0 = DioException.badResponse()
    //     0x52acc4: bl              #0x52ad28  ; [package:dio/src/dio_exception.dart] DioException::DioException.badResponse
    // 0x52acc8: add             SP, SP, #0x20
    // 0x52accc: mov             x1, x0
    // 0x52acd0: stur            x1, [fp, #-0xa8]
    // 0x52acd4: r0 = Throw()
    //     0x52acd4: bl              #0xd67e38  ; ThrowStub
    // 0x52acd8: brk             #0
    // 0x52acdc: sub             SP, fp, #0xc8
    // 0x52ace0: ldur            x16, [fp, #-0x18]
    // 0x52ace4: stp             x16, x0, [SP, #-0x10]!
    // 0x52ace8: r0 = assureDioException()
    //     0x52ace8: bl              #0x528ea4  ; [package:dio/src/dio_mixin.dart] DioMixin::assureDioException
    // 0x52acec: add             SP, SP, #0x10
    // 0x52acf0: r0 = Throw()
    //     0x52acf0: bl              #0xd67e38  ; ThrowStub
    // 0x52acf4: brk             #0
    // 0x52acf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52acf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52acfc: b               #0x52aa6c
    // 0x52ad00: r9 = httpClientAdapter
    //     0x52ad00: add             x9, PP, #0x13, lsl #12  ; [pp+0x13128] Field <_DioForNative&Object&DioMixin@371344244.httpClientAdapter>: late (offset: 0x10)
    //     0x52ad04: ldr             x9, [x9, #0x128]
    // 0x52ad08: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52ad08: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x52ad0c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x52ad0c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x52ad10: r9 = validateStatus
    //     0x52ad10: add             x9, PP, #0x13, lsl #12  ; [pp+0x13138] Field <_RequestConfig@361184022.validateStatus>: late (offset: 0x20)
    //     0x52ad14: ldr             x9, [x9, #0x138]
    // 0x52ad18: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52ad18: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x52ad1c: r9 = receiveDataWhenStatusError
    //     0x52ad1c: add             x9, PP, #0x13, lsl #12  ; [pp+0x13140] Field <_RequestConfig@361184022.receiveDataWhenStatusError>: late (offset: 0x24)
    //     0x52ad20: ldr             x9, [x9, #0x140]
    // 0x52ad24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52ad24: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _transformData(/* No info */) async {
    // ** addr: 0x5572f0, size: 0x6ac
    // 0x5572f0: EnterFrame
    //     0x5572f0: stp             fp, lr, [SP, #-0x10]!
    //     0x5572f4: mov             fp, SP
    // 0x5572f8: AllocStack(0x50)
    //     0x5572f8: sub             SP, SP, #0x50
    // 0x5572fc: SetupParameters(_DioForNative&Object&DioMixin this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0x5572fc: stur            NULL, [fp, #-8]
    //     0x557300: mov             x0, #0
    //     0x557304: add             x1, fp, w0, sxtw #2
    //     0x557308: ldr             x1, [x1, #0x18]
    //     0x55730c: stur            x1, [fp, #-0x18]
    //     0x557310: add             x2, fp, w0, sxtw #2
    //     0x557314: ldr             x2, [x2, #0x10]
    //     0x557318: stur            x2, [fp, #-0x10]
    // 0x55731c: CheckStackOverflow
    //     0x55731c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x557320: cmp             SP, x16
    //     0x557324: b.ls            #0x557904
    // 0x557328: r1 = 2
    //     0x557328: mov             x1, #2
    // 0x55732c: r0 = AllocateContext()
    //     0x55732c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x557330: mov             x1, x0
    // 0x557334: ldur            x0, [fp, #-0x10]
    // 0x557338: stur            x1, [fp, #-0x20]
    // 0x55733c: StoreField: r1->field_f = r0
    //     0x55733c: stur            w0, [x1, #0xf]
    // 0x557340: InitAsync() -> Future<Stream<Uint8List>?>
    //     0x557340: add             x0, PP, #0x14, lsl #12  ; [pp+0x14498] TypeArguments: <Stream<Uint8List>?>
    //     0x557344: ldr             x0, [x0, #0x498]
    //     0x557348: bl              #0x4b92e4
    // 0x55734c: ldur            x2, [fp, #-0x20]
    // 0x557350: LoadField: r0 = r2->field_f
    //     0x557350: ldur            w0, [x2, #0xf]
    // 0x557354: DecompressPointer r0
    //     0x557354: add             x0, x0, HEAP, lsl #32
    // 0x557358: LoadField: r1 = r0->field_7
    //     0x557358: ldur            w1, [x0, #7]
    // 0x55735c: DecompressPointer r1
    //     0x55735c: add             x1, x1, HEAP, lsl #32
    // 0x557360: r16 = Sentinel
    //     0x557360: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x557364: cmp             w1, w16
    // 0x557368: b.eq            #0x55790c
    // 0x55736c: ldur            x16, [fp, #-0x18]
    // 0x557370: stp             x1, x16, [SP, #-0x10]!
    // 0x557374: r0 = _isValidToken()
    //     0x557374: bl              #0x55a42c  ; [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::_isValidToken
    // 0x557378: add             SP, SP, #0x10
    // 0x55737c: tbnz            w0, #4, #0x5578b4
    // 0x557380: ldur            x2, [fp, #-0x20]
    // 0x557384: LoadField: r0 = r2->field_f
    //     0x557384: ldur            w0, [x2, #0xf]
    // 0x557388: DecompressPointer r0
    //     0x557388: add             x0, x0, HEAP, lsl #32
    // 0x55738c: LoadField: r1 = r0->field_53
    //     0x55738c: ldur            w1, [x0, #0x53]
    // 0x557390: DecompressPointer r1
    //     0x557390: add             x1, x1, HEAP, lsl #32
    // 0x557394: stur            x1, [fp, #-0x10]
    // 0x557398: cmp             w1, NULL
    // 0x55739c: b.eq            #0x5578ac
    // 0x5573a0: StoreField: r2->field_13 = rNULL
    //     0x5573a0: stur            NULL, [x2, #0x13]
    // 0x5573a4: r3 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0x5573a4: mov             x3, #0x76
    //     0x5573a8: tbz             w1, #0, #0x5573b8
    //     0x5573ac: ldur            x3, [x1, #-1]
    //     0x5573b0: ubfx            x3, x3, #0xc, #0x14
    //     0x5573b4: lsl             x3, x3, #1
    // 0x5573b8: r4 = LoadInt32Instr(r3)
    //     0x5573b8: sbfx            x4, x3, #1, #0x1f
    // 0x5573bc: r17 = 5626
    //     0x5573bc: mov             x17, #0x15fa
    // 0x5573c0: cmp             x4, x17
    // 0x5573c4: b.lt            #0x557430
    // 0x5573c8: r17 = 5657
    //     0x5573c8: mov             x17, #0x1619
    // 0x5573cc: cmp             x4, x17
    // 0x5573d0: b.gt            #0x557430
    // 0x5573d4: LoadField: r3 = r0->field_b
    //     0x5573d4: ldur            w3, [x0, #0xb]
    // 0x5573d8: DecompressPointer r3
    //     0x5573d8: add             x3, x3, HEAP, lsl #32
    // 0x5573dc: r16 = Sentinel
    //     0x5573dc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5573e0: cmp             w3, w16
    // 0x5573e4: b.eq            #0x557918
    // 0x5573e8: r0 = LoadClassIdInstr(r3)
    //     0x5573e8: ldur            x0, [x3, #-1]
    //     0x5573ec: ubfx            x0, x0, #0xc, #0x14
    // 0x5573f0: SaveReg r3
    //     0x5573f0: str             x3, [SP, #-8]!
    // 0x5573f4: r0 = GDT[cid_x0 + 0x6d7]()
    //     0x5573f4: add             lr, x0, #0x6d7
    //     0x5573f8: ldr             lr, [x21, lr, lsl #3]
    //     0x5573fc: blr             lr
    // 0x557400: add             SP, SP, #8
    // 0x557404: ldur            x2, [fp, #-0x20]
    // 0x557408: r1 = Function '<anonymous closure>':.
    //     0x557408: add             x1, PP, #0x14, lsl #12  ; [pp+0x144a0] AnonymousClosure: (0x55a630), in [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::_transformData (0x5572f0)
    //     0x55740c: ldr             x1, [x1, #0x4a0]
    // 0x557410: stur            x0, [fp, #-0x28]
    // 0x557414: r0 = AllocateClosure()
    //     0x557414: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x557418: ldur            x16, [fp, #-0x28]
    // 0x55741c: stp             x0, x16, [SP, #-0x10]!
    // 0x557420: r0 = any()
    //     0x557420: bl              #0x6a4eac  ; [dart:core] Iterable::any
    // 0x557424: add             SP, SP, #0x10
    // 0x557428: ldur            x1, [fp, #-0x10]
    // 0x55742c: b               #0x557884
    // 0x557430: r17 = 9072
    //     0x557430: mov             x17, #0x2370
    // 0x557434: cmp             w3, w17
    // 0x557438: b.ne            #0x5575c8
    // 0x55743c: ldur            x3, [fp, #-0x20]
    // 0x557440: ldur            x4, [fp, #-0x10]
    // 0x557444: LoadField: r5 = r0->field_b
    //     0x557444: ldur            w5, [x0, #0xb]
    // 0x557448: DecompressPointer r5
    //     0x557448: add             x5, x5, HEAP, lsl #32
    // 0x55744c: r16 = Sentinel
    //     0x55744c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x557450: cmp             w5, w16
    // 0x557454: b.eq            #0x557924
    // 0x557458: stur            x5, [fp, #-0x28]
    // 0x55745c: r1 = Null
    //     0x55745c: mov             x1, NULL
    // 0x557460: r2 = 6
    //     0x557460: mov             x2, #6
    // 0x557464: r0 = AllocateArray()
    //     0x557464: bl              #0xd6987c  ; AllocateArrayStub
    // 0x557468: r17 = "multipart/form-data"
    //     0x557468: add             x17, PP, #0x12, lsl #12  ; [pp+0x12e98] "multipart/form-data"
    //     0x55746c: ldr             x17, [x17, #0xe98]
    // 0x557470: StoreField: r0->field_f = r17
    //     0x557470: stur            w17, [x0, #0xf]
    // 0x557474: r17 = "; boundary="
    //     0x557474: add             x17, PP, #0x14, lsl #12  ; [pp+0x144a8] "; boundary="
    //     0x557478: ldr             x17, [x17, #0x4a8]
    // 0x55747c: StoreField: r0->field_13 = r17
    //     0x55747c: stur            w17, [x0, #0x13]
    // 0x557480: ldur            x1, [fp, #-0x10]
    // 0x557484: LoadField: r2 = r1->field_7
    //     0x557484: ldur            w2, [x1, #7]
    // 0x557488: DecompressPointer r2
    //     0x557488: add             x2, x2, HEAP, lsl #32
    // 0x55748c: r16 = Sentinel
    //     0x55748c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x557490: cmp             w2, w16
    // 0x557494: b.eq            #0x557930
    // 0x557498: StoreField: r0->field_17 = r2
    //     0x557498: stur            w2, [x0, #0x17]
    // 0x55749c: SaveReg r0
    //     0x55749c: str             x0, [SP, #-8]!
    // 0x5574a0: r0 = _interpolate()
    //     0x5574a0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x5574a4: add             SP, SP, #8
    // 0x5574a8: mov             x1, x0
    // 0x5574ac: ldur            x0, [fp, #-0x28]
    // 0x5574b0: r2 = LoadClassIdInstr(r0)
    //     0x5574b0: ldur            x2, [x0, #-1]
    //     0x5574b4: ubfx            x2, x2, #0xc, #0x14
    // 0x5574b8: r16 = "content-type"
    //     0x5574b8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x5574bc: ldr             x16, [x16, #0xed8]
    // 0x5574c0: stp             x16, x0, [SP, #-0x10]!
    // 0x5574c4: SaveReg r1
    //     0x5574c4: str             x1, [SP, #-8]!
    // 0x5574c8: mov             x0, x2
    // 0x5574cc: r0 = GDT[cid_x0 + 0x35a]()
    //     0x5574cc: add             lr, x0, #0x35a
    //     0x5574d0: ldr             lr, [x21, lr, lsl #3]
    //     0x5574d4: blr             lr
    // 0x5574d8: add             SP, SP, #0x18
    // 0x5574dc: ldur            x16, [fp, #-0x10]
    // 0x5574e0: SaveReg r16
    //     0x5574e0: str             x16, [SP, #-8]!
    // 0x5574e4: r0 = finalize()
    //     0x5574e4: bl              #0x559168  ; [package:dio/src/form_data.dart] FormData::finalize
    // 0x5574e8: add             SP, SP, #8
    // 0x5574ec: stur            x0, [fp, #-0x28]
    // 0x5574f0: ldur            x16, [fp, #-0x10]
    // 0x5574f4: SaveReg r16
    //     0x5574f4: str             x16, [SP, #-8]!
    // 0x5574f8: r0 = length()
    //     0x5574f8: bl              #0x5587c4  ; [package:dio/src/form_data.dart] FormData::length
    // 0x5574fc: add             SP, SP, #8
    // 0x557500: mov             x2, x0
    // 0x557504: r0 = BoxInt64Instr(r2)
    //     0x557504: sbfiz           x0, x2, #1, #0x1f
    //     0x557508: cmp             x2, x0, asr #1
    //     0x55750c: b.eq            #0x557518
    //     0x557510: bl              #0xd69bb8
    //     0x557514: stur            x2, [x0, #7]
    // 0x557518: mov             x2, x0
    // 0x55751c: ldur            x1, [fp, #-0x20]
    // 0x557520: StoreField: r1->field_13 = r0
    //     0x557520: stur            w0, [x1, #0x13]
    //     0x557524: tbz             w0, #0, #0x557540
    //     0x557528: ldurb           w16, [x1, #-1]
    //     0x55752c: ldurb           w17, [x0, #-1]
    //     0x557530: and             x16, x17, x16, lsr #2
    //     0x557534: tst             x16, HEAP, lsr #32
    //     0x557538: b.eq            #0x557540
    //     0x55753c: bl              #0xd6826c
    // 0x557540: LoadField: r0 = r1->field_f
    //     0x557540: ldur            w0, [x1, #0xf]
    // 0x557544: DecompressPointer r0
    //     0x557544: add             x0, x0, HEAP, lsl #32
    // 0x557548: LoadField: r3 = r0->field_b
    //     0x557548: ldur            w3, [x0, #0xb]
    // 0x55754c: DecompressPointer r3
    //     0x55754c: add             x3, x3, HEAP, lsl #32
    // 0x557550: r16 = Sentinel
    //     0x557550: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x557554: cmp             w3, w16
    // 0x557558: b.eq            #0x55793c
    // 0x55755c: stur            x3, [fp, #-0x30]
    // 0x557560: r0 = 59
    //     0x557560: mov             x0, #0x3b
    // 0x557564: branchIfSmi(r2, 0x557570)
    //     0x557564: tbz             w2, #0, #0x557570
    // 0x557568: r0 = LoadClassIdInstr(r2)
    //     0x557568: ldur            x0, [x2, #-1]
    //     0x55756c: ubfx            x0, x0, #0xc, #0x14
    // 0x557570: SaveReg r2
    //     0x557570: str             x2, [SP, #-8]!
    // 0x557574: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x557574: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x557578: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x557578: mov             x17, #0x3f73
    //     0x55757c: add             lr, x0, x17
    //     0x557580: ldr             lr, [x21, lr, lsl #3]
    //     0x557584: blr             lr
    // 0x557588: add             SP, SP, #8
    // 0x55758c: mov             x1, x0
    // 0x557590: ldur            x0, [fp, #-0x30]
    // 0x557594: r2 = LoadClassIdInstr(r0)
    //     0x557594: ldur            x2, [x0, #-1]
    //     0x557598: ubfx            x2, x2, #0xc, #0x14
    // 0x55759c: r16 = "content-length"
    //     0x55759c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13510] "content-length"
    //     0x5575a0: ldr             x16, [x16, #0x510]
    // 0x5575a4: stp             x16, x0, [SP, #-0x10]!
    // 0x5575a8: SaveReg r1
    //     0x5575a8: str             x1, [SP, #-8]!
    // 0x5575ac: mov             x0, x2
    // 0x5575b0: r0 = GDT[cid_x0 + 0x35a]()
    //     0x5575b0: add             lr, x0, #0x35a
    //     0x5575b4: ldr             lr, [x21, lr, lsl #3]
    //     0x5575b8: blr             lr
    // 0x5575bc: add             SP, SP, #0x18
    // 0x5575c0: ldur            x0, [fp, #-0x28]
    // 0x5575c4: b               #0x557880
    // 0x5575c8: cmp             x4, #0x75
    // 0x5575cc: b.lt            #0x5575e0
    // 0x5575d0: cmp             x4, #0x78
    // 0x5575d4: b.gt            #0x5575e0
    // 0x5575d8: ldur            x2, [fp, #-0x10]
    // 0x5575dc: b               #0x557618
    // 0x5575e0: ldur            x1, [fp, #-0x18]
    // 0x5575e4: LoadField: r2 = r1->field_13
    //     0x5575e4: ldur            w2, [x1, #0x13]
    // 0x5575e8: DecompressPointer r2
    //     0x5575e8: add             x2, x2, HEAP, lsl #32
    // 0x5575ec: stp             x0, x2, [SP, #-0x10]!
    // 0x5575f0: r0 = transformRequest()
    //     0x5575f0: bl              #0x558638  ; [package:dio/src/transformers/sync_transformer.dart] SyncTransformer::transformRequest
    // 0x5575f4: add             SP, SP, #0x10
    // 0x5575f8: mov             x1, x0
    // 0x5575fc: stur            x1, [fp, #-0x10]
    // 0x557600: r0 = Await()
    //     0x557600: bl              #0x4b8e6c  ; AwaitStub
    // 0x557604: r16 = Instance_Utf8Codec
    //     0x557604: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0x557608: stp             x0, x16, [SP, #-0x10]!
    // 0x55760c: r0 = encode()
    //     0x55760c: bl              #0xbfcc28  ; [dart:convert] Codec::encode
    // 0x557610: add             SP, SP, #0x10
    // 0x557614: mov             x2, x0
    // 0x557618: ldur            x1, [fp, #-0x20]
    // 0x55761c: stur            x2, [fp, #-0x28]
    // 0x557620: LoadField: r3 = r2->field_13
    //     0x557620: ldur            w3, [x2, #0x13]
    // 0x557624: DecompressPointer r3
    //     0x557624: add             x3, x3, HEAP, lsl #32
    // 0x557628: stur            x3, [fp, #-0x18]
    // 0x55762c: StoreField: r1->field_13 = r3
    //     0x55762c: stur            w3, [x1, #0x13]
    // 0x557630: LoadField: r0 = r1->field_f
    //     0x557630: ldur            w0, [x1, #0xf]
    // 0x557634: DecompressPointer r0
    //     0x557634: add             x0, x0, HEAP, lsl #32
    // 0x557638: LoadField: r4 = r0->field_b
    //     0x557638: ldur            w4, [x0, #0xb]
    // 0x55763c: DecompressPointer r4
    //     0x55763c: add             x4, x4, HEAP, lsl #32
    // 0x557640: r16 = Sentinel
    //     0x557640: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x557644: cmp             w4, w16
    // 0x557648: b.eq            #0x557948
    // 0x55764c: stur            x4, [fp, #-0x10]
    // 0x557650: r0 = 59
    //     0x557650: mov             x0, #0x3b
    // 0x557654: branchIfSmi(r3, 0x557660)
    //     0x557654: tbz             w3, #0, #0x557660
    // 0x557658: r0 = LoadClassIdInstr(r3)
    //     0x557658: ldur            x0, [x3, #-1]
    //     0x55765c: ubfx            x0, x0, #0xc, #0x14
    // 0x557660: SaveReg r3
    //     0x557660: str             x3, [SP, #-8]!
    // 0x557664: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x557664: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x557668: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x557668: mov             x17, #0x3f73
    //     0x55766c: add             lr, x0, x17
    //     0x557670: ldr             lr, [x21, lr, lsl #3]
    //     0x557674: blr             lr
    // 0x557678: add             SP, SP, #8
    // 0x55767c: mov             x1, x0
    // 0x557680: ldur            x0, [fp, #-0x10]
    // 0x557684: r2 = LoadClassIdInstr(r0)
    //     0x557684: ldur            x2, [x0, #-1]
    //     0x557688: ubfx            x2, x2, #0xc, #0x14
    // 0x55768c: r16 = "content-length"
    //     0x55768c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13510] "content-length"
    //     0x557690: ldr             x16, [x16, #0x510]
    // 0x557694: stp             x16, x0, [SP, #-0x10]!
    // 0x557698: SaveReg r1
    //     0x557698: str             x1, [SP, #-8]!
    // 0x55769c: mov             x0, x2
    // 0x5576a0: r0 = GDT[cid_x0 + 0x35a]()
    //     0x5576a0: add             lr, x0, #0x35a
    //     0x5576a4: ldr             lr, [x21, lr, lsl #3]
    //     0x5576a8: blr             lr
    // 0x5576ac: add             SP, SP, #0x18
    // 0x5576b0: r16 = <List<int>>
    //     0x5576b0: ldr             x16, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0x5576b4: stp             xzr, x16, [SP, #-0x10]!
    // 0x5576b8: r0 = _GrowableList()
    //     0x5576b8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5576bc: add             SP, SP, #0x10
    // 0x5576c0: mov             x3, x0
    // 0x5576c4: ldur            x2, [fp, #-0x18]
    // 0x5576c8: stur            x3, [fp, #-0x10]
    // 0x5576cc: r4 = LoadInt32Instr(r2)
    //     0x5576cc: sbfx            x4, x2, #1, #0x1f
    // 0x5576d0: stur            x4, [fp, #-0x48]
    // 0x5576d4: scvtf           d0, x4
    // 0x5576d8: d1 = 1024.000000
    //     0x5576d8: add             x17, PP, #0x14, lsl #12  ; [pp+0x144b0] IMM: double(1024) from 0x4090000000000000
    //     0x5576dc: ldr             d1, [x17, #0x4b0]
    // 0x5576e0: fdiv            d2, d0, d1
    // 0x5576e4: fcmp            d2, d2
    // 0x5576e8: b.vs            #0x557954
    // 0x5576ec: fcvtps          x0, d2
    // 0x5576f0: asr             x16, x0, #0x1e
    // 0x5576f4: cmp             x16, x0, asr #63
    // 0x5576f8: b.ne            #0x557954
    // 0x5576fc: lsl             x0, x0, #1
    // 0x557700: r5 = LoadInt32Instr(r0)
    //     0x557700: sbfx            x5, x0, #1, #0x1f
    //     0x557704: tbz             w0, #0, #0x55770c
    //     0x557708: ldur            x5, [x0, #7]
    // 0x55770c: stur            x5, [fp, #-0x40]
    // 0x557710: r7 = 0
    //     0x557710: mov             x7, #0
    // 0x557714: ldur            x6, [fp, #-0x28]
    // 0x557718: stur            x7, [fp, #-0x38]
    // 0x55771c: CheckStackOverflow
    //     0x55771c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x557720: cmp             SP, x16
    //     0x557724: b.ls            #0x557984
    // 0x557728: cmp             x7, x5
    // 0x55772c: b.ge            #0x55786c
    // 0x557730: lsl             x8, x7, #0xa
    // 0x557734: add             x0, x8, #0x400
    // 0x557738: cmp             x0, x4
    // 0x55773c: b.le            #0x55774c
    // 0x557740: r0 = LoadInt32Instr(r2)
    //     0x557740: sbfx            x0, x2, #1, #0x1f
    // 0x557744: mov             x9, x0
    // 0x557748: b               #0x557760
    // 0x55774c: cmp             x0, x4
    // 0x557750: b.ge            #0x55775c
    // 0x557754: mov             x9, x0
    // 0x557758: b               #0x557760
    // 0x55775c: mov             x9, x0
    // 0x557760: r0 = BoxInt64Instr(r9)
    //     0x557760: sbfiz           x0, x9, #1, #0x1f
    //     0x557764: cmp             x9, x0, asr #1
    //     0x557768: b.eq            #0x557774
    //     0x55776c: bl              #0xd69bb8
    //     0x557770: stur            x9, [x0, #7]
    // 0x557774: r1 = LoadClassIdInstr(r6)
    //     0x557774: ldur            x1, [x6, #-1]
    //     0x557778: ubfx            x1, x1, #0xc, #0x14
    // 0x55777c: stp             x8, x6, [SP, #-0x10]!
    // 0x557780: SaveReg r0
    //     0x557780: str             x0, [SP, #-8]!
    // 0x557784: mov             x0, x1
    // 0x557788: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x557788: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x55778c: r0 = GDT[cid_x0 + 0x10217]()
    //     0x55778c: mov             x17, #0x217
    //     0x557790: movk            x17, #1, lsl #16
    //     0x557794: add             lr, x0, x17
    //     0x557798: ldr             lr, [x21, lr, lsl #3]
    //     0x55779c: blr             lr
    // 0x5577a0: add             SP, SP, #0x18
    // 0x5577a4: mov             x3, x0
    // 0x5577a8: r2 = Null
    //     0x5577a8: mov             x2, NULL
    // 0x5577ac: r1 = Null
    //     0x5577ac: mov             x1, NULL
    // 0x5577b0: stur            x3, [fp, #-0x30]
    // 0x5577b4: r8 = List<int>
    //     0x5577b4: ldr             x8, [PP, #0xa60]  ; [pp+0xa60] Type: List<int>
    // 0x5577b8: r3 = Null
    //     0x5577b8: add             x3, PP, #0x14, lsl #12  ; [pp+0x144b8] Null
    //     0x5577bc: ldr             x3, [x3, #0x4b8]
    // 0x5577c0: r0 = List<int>()
    //     0x5577c0: bl              #0x4b2744  ; IsType_List<int>_Stub
    // 0x5577c4: ldur            x0, [fp, #-0x10]
    // 0x5577c8: LoadField: r1 = r0->field_b
    //     0x5577c8: ldur            w1, [x0, #0xb]
    // 0x5577cc: DecompressPointer r1
    //     0x5577cc: add             x1, x1, HEAP, lsl #32
    // 0x5577d0: stur            x1, [fp, #-0x50]
    // 0x5577d4: LoadField: r2 = r0->field_f
    //     0x5577d4: ldur            w2, [x0, #0xf]
    // 0x5577d8: DecompressPointer r2
    //     0x5577d8: add             x2, x2, HEAP, lsl #32
    // 0x5577dc: LoadField: r3 = r2->field_b
    //     0x5577dc: ldur            w3, [x2, #0xb]
    // 0x5577e0: DecompressPointer r3
    //     0x5577e0: add             x3, x3, HEAP, lsl #32
    // 0x5577e4: cmp             w1, w3
    // 0x5577e8: b.ne            #0x5577f8
    // 0x5577ec: SaveReg r0
    //     0x5577ec: str             x0, [SP, #-8]!
    // 0x5577f0: r0 = _growToNextCapacity()
    //     0x5577f0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5577f4: add             SP, SP, #8
    // 0x5577f8: ldur            x2, [fp, #-0x10]
    // 0x5577fc: ldur            x3, [fp, #-0x38]
    // 0x557800: ldur            x0, [fp, #-0x50]
    // 0x557804: r4 = LoadInt32Instr(r0)
    //     0x557804: sbfx            x4, x0, #1, #0x1f
    // 0x557808: add             x0, x4, #1
    // 0x55780c: lsl             x1, x0, #1
    // 0x557810: StoreField: r2->field_b = r1
    //     0x557810: stur            w1, [x2, #0xb]
    // 0x557814: mov             x1, x4
    // 0x557818: cmp             x1, x0
    // 0x55781c: b.hs            #0x55798c
    // 0x557820: LoadField: r1 = r2->field_f
    //     0x557820: ldur            w1, [x2, #0xf]
    // 0x557824: DecompressPointer r1
    //     0x557824: add             x1, x1, HEAP, lsl #32
    // 0x557828: ldur            x0, [fp, #-0x30]
    // 0x55782c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x55782c: add             x25, x1, x4, lsl #2
    //     0x557830: add             x25, x25, #0xf
    //     0x557834: str             w0, [x25]
    //     0x557838: tbz             w0, #0, #0x557854
    //     0x55783c: ldurb           w16, [x1, #-1]
    //     0x557840: ldurb           w17, [x0, #-1]
    //     0x557844: and             x16, x17, x16, lsr #2
    //     0x557848: tst             x16, HEAP, lsr #32
    //     0x55784c: b.eq            #0x557854
    //     0x557850: bl              #0xd67e5c
    // 0x557854: add             x7, x3, #1
    // 0x557858: mov             x3, x2
    // 0x55785c: ldur            x2, [fp, #-0x18]
    // 0x557860: ldur            x4, [fp, #-0x48]
    // 0x557864: ldur            x5, [fp, #-0x40]
    // 0x557868: b               #0x557714
    // 0x55786c: mov             x2, x3
    // 0x557870: r16 = <List<int>>
    //     0x557870: ldr             x16, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0x557874: stp             x2, x16, [SP, #-0x10]!
    // 0x557878: r0 = Stream.fromIterable()
    //     0x557878: bl              #0x557db4  ; [dart:async] Stream::Stream.fromIterable
    // 0x55787c: add             SP, SP, #0x10
    // 0x557880: mov             x1, x0
    // 0x557884: ldur            x0, [fp, #-0x20]
    // 0x557888: LoadField: r2 = r0->field_13
    //     0x557888: ldur            w2, [x0, #0x13]
    // 0x55788c: DecompressPointer r2
    //     0x55788c: add             x2, x2, HEAP, lsl #32
    // 0x557890: LoadField: r3 = r0->field_f
    //     0x557890: ldur            w3, [x0, #0xf]
    // 0x557894: DecompressPointer r3
    //     0x557894: add             x3, x3, HEAP, lsl #32
    // 0x557898: stp             x2, x1, [SP, #-0x10]!
    // 0x55789c: SaveReg r3
    //     0x55789c: str             x3, [SP, #-8]!
    // 0x5578a0: r0 = addProgress()
    //     0x5578a0: bl              #0x55799c  ; [package:dio/src/progress_stream/io_progress_stream.dart] ::addProgress
    // 0x5578a4: add             SP, SP, #0x18
    // 0x5578a8: r0 = ReturnAsyncNotFuture()
    //     0x5578a8: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x5578ac: r0 = Null
    //     0x5578ac: mov             x0, NULL
    // 0x5578b0: r0 = ReturnAsyncNotFuture()
    //     0x5578b0: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x5578b4: ldur            x2, [fp, #-0x20]
    // 0x5578b8: LoadField: r0 = r2->field_f
    //     0x5578b8: ldur            w0, [x2, #0xf]
    // 0x5578bc: DecompressPointer r0
    //     0x5578bc: add             x0, x0, HEAP, lsl #32
    // 0x5578c0: LoadField: r1 = r0->field_7
    //     0x5578c0: ldur            w1, [x0, #7]
    // 0x5578c4: DecompressPointer r1
    //     0x5578c4: add             x1, x1, HEAP, lsl #32
    // 0x5578c8: r16 = Sentinel
    //     0x5578c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5578cc: cmp             w1, w16
    // 0x5578d0: b.eq            #0x557990
    // 0x5578d4: stur            x1, [fp, #-0x10]
    // 0x5578d8: r0 = ArgumentError()
    //     0x5578d8: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x5578dc: mov             x1, x0
    // 0x5578e0: r0 = "method"
    //     0x5578e0: ldr             x0, [PP, #0x2a98]  ; [pp+0x2a98] "method"
    // 0x5578e4: StoreField: r1->field_13 = r0
    //     0x5578e4: stur            w0, [x1, #0x13]
    // 0x5578e8: ldur            x0, [fp, #-0x10]
    // 0x5578ec: StoreField: r1->field_f = r0
    //     0x5578ec: stur            w0, [x1, #0xf]
    // 0x5578f0: r0 = true
    //     0x5578f0: add             x0, NULL, #0x20  ; true
    // 0x5578f4: StoreField: r1->field_b = r0
    //     0x5578f4: stur            w0, [x1, #0xb]
    // 0x5578f8: mov             x0, x1
    // 0x5578fc: r0 = Throw()
    //     0x5578fc: bl              #0xd67e38  ; ThrowStub
    // 0x557900: brk             #0
    // 0x557904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x557904: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x557908: b               #0x557328
    // 0x55790c: r9 = method
    //     0x55790c: add             x9, PP, #0x13, lsl #12  ; [pp+0x13458] Field <_RequestConfig@361184022.method>: late (offset: 0x8)
    //     0x557910: ldr             x9, [x9, #0x458]
    // 0x557914: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x557914: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x557918: r9 = _headers
    //     0x557918: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x55791c: ldr             x9, [x9, #0xee0]
    // 0x557920: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x557920: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x557924: r9 = _headers
    //     0x557924: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x557928: ldr             x9, [x9, #0xee0]
    // 0x55792c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55792c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x557930: r9 = _boundary
    //     0x557930: add             x9, PP, #0x14, lsl #12  ; [pp+0x144c8] Field <FormData._boundary@357426596>: late (offset: 0x8)
    //     0x557934: ldr             x9, [x9, #0x4c8]
    // 0x557938: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x557938: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x55793c: r9 = _headers
    //     0x55793c: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x557940: ldr             x9, [x9, #0xee0]
    // 0x557944: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x557944: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x557948: r9 = _headers
    //     0x557948: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x55794c: ldr             x9, [x9, #0xee0]
    // 0x557950: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x557950: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x557954: SaveReg d2
    //     0x557954: str             q2, [SP, #-0x10]!
    // 0x557958: stp             x3, x4, [SP, #-0x10]!
    // 0x55795c: SaveReg r2
    //     0x55795c: str             x2, [SP, #-8]!
    // 0x557960: d0 = 0.000000
    //     0x557960: fmov            d0, d2
    // 0x557964: r0 = 208
    //     0x557964: mov             x0, #0xd0
    // 0x557968: r24 = DoubleToIntegerStub
    //     0x557968: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x55796c: LoadField: r30 = r24->field_7
    //     0x55796c: ldur            lr, [x24, #7]
    // 0x557970: blr             lr
    // 0x557974: RestoreReg r2
    //     0x557974: ldr             x2, [SP], #8
    // 0x557978: ldp             x3, x4, [SP], #0x10
    // 0x55797c: RestoreReg d2
    //     0x55797c: ldr             q2, [SP], #0x10
    // 0x557980: b               #0x557700
    // 0x557984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x557984: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x557988: b               #0x557728
    // 0x55798c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x55798c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x557990: r9 = method
    //     0x557990: add             x9, PP, #0x13, lsl #12  ; [pp+0x13458] Field <_RequestConfig@361184022.method>: late (offset: 0x8)
    //     0x557994: ldr             x9, [x9, #0x458]
    // 0x557998: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x557998: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _isValidToken(/* No info */) {
    // ** addr: 0x55a42c, size: 0x204
    // 0x55a42c: EnterFrame
    //     0x55a42c: stp             fp, lr, [SP, #-0x10]!
    //     0x55a430: mov             fp, SP
    // 0x55a434: AllocStack(0x28)
    //     0x55a434: sub             SP, SP, #0x28
    // 0x55a438: CheckStackOverflow
    //     0x55a438: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a43c: cmp             SP, x16
    //     0x55a440: b.ls            #0x55a61c
    // 0x55a444: r1 = <int>
    //     0x55a444: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x55a448: r0 = CodeUnits()
    //     0x55a448: bl              #0x52dacc  ; AllocateCodeUnitsStub -> CodeUnits (size=0x10)
    // 0x55a44c: mov             x1, x0
    // 0x55a450: ldr             x0, [fp, #0x10]
    // 0x55a454: StoreField: r1->field_b = r0
    //     0x55a454: stur            w0, [x1, #0xb]
    // 0x55a458: SaveReg r1
    //     0x55a458: str             x1, [SP, #-8]!
    // 0x55a45c: r0 = iterator()
    //     0x55a45c: bl              #0x70b268  ; [dart:collection] ListMixin::iterator
    // 0x55a460: add             SP, SP, #8
    // 0x55a464: mov             x1, x0
    // 0x55a468: stur            x1, [fp, #-0x20]
    // 0x55a46c: LoadField: r2 = r1->field_b
    //     0x55a46c: ldur            w2, [x1, #0xb]
    // 0x55a470: DecompressPointer r2
    //     0x55a470: add             x2, x2, HEAP, lsl #32
    // 0x55a474: stur            x2, [fp, #-0x18]
    // 0x55a478: LoadField: r3 = r1->field_f
    //     0x55a478: ldur            x3, [x1, #0xf]
    // 0x55a47c: stur            x3, [fp, #-0x10]
    // 0x55a480: LoadField: r4 = r1->field_7
    //     0x55a480: ldur            w4, [x1, #7]
    // 0x55a484: DecompressPointer r4
    //     0x55a484: add             x4, x4, HEAP, lsl #32
    // 0x55a488: stur            x4, [fp, #-8]
    // 0x55a48c: CheckStackOverflow
    //     0x55a48c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a490: cmp             SP, x16
    //     0x55a494: b.ls            #0x55a624
    // 0x55a498: r0 = LoadClassIdInstr(r2)
    //     0x55a498: ldur            x0, [x2, #-1]
    //     0x55a49c: ubfx            x0, x0, #0xc, #0x14
    // 0x55a4a0: SaveReg r2
    //     0x55a4a0: str             x2, [SP, #-8]!
    // 0x55a4a4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x55a4a4: mov             x17, #0xb8ea
    //     0x55a4a8: add             lr, x0, x17
    //     0x55a4ac: ldr             lr, [x21, lr, lsl #3]
    //     0x55a4b0: blr             lr
    // 0x55a4b4: add             SP, SP, #8
    // 0x55a4b8: r1 = LoadInt32Instr(r0)
    //     0x55a4b8: sbfx            x1, x0, #1, #0x1f
    //     0x55a4bc: tbz             w0, #0, #0x55a4c4
    //     0x55a4c0: ldur            x1, [x0, #7]
    // 0x55a4c4: ldur            x2, [fp, #-0x10]
    // 0x55a4c8: cmp             x2, x1
    // 0x55a4cc: b.ne            #0x55a604
    // 0x55a4d0: ldur            x4, [fp, #-0x20]
    // 0x55a4d4: ldur            x3, [fp, #-0x18]
    // 0x55a4d8: LoadField: r5 = r4->field_17
    //     0x55a4d8: ldur            x5, [x4, #0x17]
    // 0x55a4dc: cmp             x5, x1
    // 0x55a4e0: b.lt            #0x55a4f8
    // 0x55a4e4: StoreField: r4->field_1f = rNULL
    //     0x55a4e4: stur            NULL, [x4, #0x1f]
    // 0x55a4e8: r0 = true
    //     0x55a4e8: add             x0, NULL, #0x20  ; true
    // 0x55a4ec: LeaveFrame
    //     0x55a4ec: mov             SP, fp
    //     0x55a4f0: ldp             fp, lr, [SP], #0x10
    // 0x55a4f4: ret
    //     0x55a4f4: ret             
    // 0x55a4f8: r0 = BoxInt64Instr(r5)
    //     0x55a4f8: sbfiz           x0, x5, #1, #0x1f
    //     0x55a4fc: cmp             x5, x0, asr #1
    //     0x55a500: b.eq            #0x55a50c
    //     0x55a504: bl              #0xd69bb8
    //     0x55a508: stur            x5, [x0, #7]
    // 0x55a50c: r1 = LoadClassIdInstr(r3)
    //     0x55a50c: ldur            x1, [x3, #-1]
    //     0x55a510: ubfx            x1, x1, #0xc, #0x14
    // 0x55a514: stp             x0, x3, [SP, #-0x10]!
    // 0x55a518: mov             x0, x1
    // 0x55a51c: r0 = GDT[cid_x0 + 0xd175]()
    //     0x55a51c: mov             x17, #0xd175
    //     0x55a520: add             lr, x0, x17
    //     0x55a524: ldr             lr, [x21, lr, lsl #3]
    //     0x55a528: blr             lr
    // 0x55a52c: add             SP, SP, #0x10
    // 0x55a530: mov             x4, x0
    // 0x55a534: ldur            x3, [fp, #-0x20]
    // 0x55a538: stur            x4, [fp, #-0x28]
    // 0x55a53c: StoreField: r3->field_1f = r0
    //     0x55a53c: stur            w0, [x3, #0x1f]
    //     0x55a540: tbz             w0, #0, #0x55a55c
    //     0x55a544: ldurb           w16, [x3, #-1]
    //     0x55a548: ldurb           w17, [x0, #-1]
    //     0x55a54c: and             x16, x17, x16, lsr #2
    //     0x55a550: tst             x16, HEAP, lsr #32
    //     0x55a554: b.eq            #0x55a55c
    //     0x55a558: bl              #0xd682ac
    // 0x55a55c: LoadField: r0 = r3->field_17
    //     0x55a55c: ldur            x0, [x3, #0x17]
    // 0x55a560: add             x1, x0, #1
    // 0x55a564: StoreField: r3->field_17 = r1
    //     0x55a564: stur            x1, [x3, #0x17]
    // 0x55a568: cmp             w4, NULL
    // 0x55a56c: b.ne            #0x55a5a0
    // 0x55a570: mov             x0, x4
    // 0x55a574: ldur            x2, [fp, #-8]
    // 0x55a578: r1 = Null
    //     0x55a578: mov             x1, NULL
    // 0x55a57c: cmp             w2, NULL
    // 0x55a580: b.eq            #0x55a5a0
    // 0x55a584: LoadField: r4 = r2->field_17
    //     0x55a584: ldur            w4, [x2, #0x17]
    // 0x55a588: DecompressPointer r4
    //     0x55a588: add             x4, x4, HEAP, lsl #32
    // 0x55a58c: r8 = X0
    //     0x55a58c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x55a590: LoadField: r9 = r4->field_7
    //     0x55a590: ldur            x9, [x4, #7]
    // 0x55a594: r3 = Null
    //     0x55a594: add             x3, PP, #0x14, lsl #12  ; [pp+0x146a0] Null
    //     0x55a598: ldr             x3, [x3, #0x6a0]
    // 0x55a59c: blr             x9
    // 0x55a5a0: ldur            x2, [fp, #-0x28]
    // 0x55a5a4: r3 = LoadInt32Instr(r2)
    //     0x55a5a4: sbfx            x3, x2, #1, #0x1f
    //     0x55a5a8: tbz             w2, #0, #0x55a5b0
    //     0x55a5ac: ldur            x3, [x2, #7]
    // 0x55a5b0: cmp             x3, #0x80
    // 0x55a5b4: b.ge            #0x55a5e0
    // 0x55a5b8: r2 = "                                 ! #$%&\'  *+ -. 0123456789       ABCDEFGHIJKLMNOPQRSTUVWXYZ   ^_`abcdefghijklmnopqrstuvwxyz | ~ "
    //     0x55a5b8: add             x2, PP, #0x14, lsl #12  ; [pp+0x142c8] "                                 ! #$%&\'  *+ -. 0123456789       ABCDEFGHIJKLMNOPQRSTUVWXYZ   ^_`abcdefghijklmnopqrstuvwxyz | ~ "
    //     0x55a5bc: ldr             x2, [x2, #0x2c8]
    // 0x55a5c0: mov             x1, x3
    // 0x55a5c4: r0 = 128
    //     0x55a5c4: mov             x0, #0x80
    // 0x55a5c8: cmp             x1, x0
    // 0x55a5cc: b.hs            #0x55a62c
    // 0x55a5d0: ArrayLoad: r1 = r2[r3]  ; TypedUnsigned_1
    //     0x55a5d0: add             x16, x2, x3
    //     0x55a5d4: ldrb            w1, [x16, #0xf]
    // 0x55a5d8: cmp             x1, #0x20
    // 0x55a5dc: b.ne            #0x55a5f0
    // 0x55a5e0: r0 = false
    //     0x55a5e0: add             x0, NULL, #0x30  ; false
    // 0x55a5e4: LeaveFrame
    //     0x55a5e4: mov             SP, fp
    //     0x55a5e8: ldp             fp, lr, [SP], #0x10
    // 0x55a5ec: ret
    //     0x55a5ec: ret             
    // 0x55a5f0: ldur            x1, [fp, #-0x20]
    // 0x55a5f4: ldur            x4, [fp, #-8]
    // 0x55a5f8: ldur            x2, [fp, #-0x18]
    // 0x55a5fc: ldur            x3, [fp, #-0x10]
    // 0x55a600: b               #0x55a48c
    // 0x55a604: ldur            x0, [fp, #-0x18]
    // 0x55a608: r0 = ConcurrentModificationError()
    //     0x55a608: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x55a60c: ldur            x3, [fp, #-0x18]
    // 0x55a610: StoreField: r0->field_b = r3
    //     0x55a610: stur            w3, [x0, #0xb]
    // 0x55a614: r0 = Throw()
    //     0x55a614: bl              #0xd67e38  ; ThrowStub
    // 0x55a618: brk             #0
    // 0x55a61c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a61c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a620: b               #0x55a444
    // 0x55a624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a624: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a628: b               #0x55a498
    // 0x55a62c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x55a62c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, String) {
    // ** addr: 0x55a630, size: 0x164
    // 0x55a630: EnterFrame
    //     0x55a630: stp             fp, lr, [SP, #-0x10]!
    //     0x55a634: mov             fp, SP
    // 0x55a638: AllocStack(0x8)
    //     0x55a638: sub             SP, SP, #8
    // 0x55a63c: SetupParameters()
    //     0x55a63c: ldr             x0, [fp, #0x18]
    //     0x55a640: ldur            w1, [x0, #0x17]
    //     0x55a644: add             x1, x1, HEAP, lsl #32
    //     0x55a648: stur            x1, [fp, #-8]
    // 0x55a64c: CheckStackOverflow
    //     0x55a64c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a650: cmp             SP, x16
    //     0x55a654: b.ls            #0x55a780
    // 0x55a658: ldr             x2, [fp, #0x10]
    // 0x55a65c: r0 = LoadClassIdInstr(r2)
    //     0x55a65c: ldur            x0, [x2, #-1]
    //     0x55a660: ubfx            x0, x0, #0xc, #0x14
    // 0x55a664: SaveReg r2
    //     0x55a664: str             x2, [SP, #-8]!
    // 0x55a668: r0 = GDT[cid_x0 + -0xff4]()
    //     0x55a668: sub             lr, x0, #0xff4
    //     0x55a66c: ldr             lr, [x21, lr, lsl #3]
    //     0x55a670: blr             lr
    // 0x55a674: add             SP, SP, #8
    // 0x55a678: r1 = LoadClassIdInstr(r0)
    //     0x55a678: ldur            x1, [x0, #-1]
    //     0x55a67c: ubfx            x1, x1, #0xc, #0x14
    // 0x55a680: r16 = "content-length"
    //     0x55a680: add             x16, PP, #0x13, lsl #12  ; [pp+0x13510] "content-length"
    //     0x55a684: ldr             x16, [x16, #0x510]
    // 0x55a688: stp             x16, x0, [SP, #-0x10]!
    // 0x55a68c: mov             x0, x1
    // 0x55a690: mov             lr, x0
    // 0x55a694: ldr             lr, [x21, lr, lsl #3]
    // 0x55a698: blr             lr
    // 0x55a69c: add             SP, SP, #0x10
    // 0x55a6a0: tbnz            w0, #4, #0x55a770
    // 0x55a6a4: ldur            x1, [fp, #-8]
    // 0x55a6a8: LoadField: r0 = r1->field_f
    //     0x55a6a8: ldur            w0, [x1, #0xf]
    // 0x55a6ac: DecompressPointer r0
    //     0x55a6ac: add             x0, x0, HEAP, lsl #32
    // 0x55a6b0: LoadField: r2 = r0->field_b
    //     0x55a6b0: ldur            w2, [x0, #0xb]
    // 0x55a6b4: DecompressPointer r2
    //     0x55a6b4: add             x2, x2, HEAP, lsl #32
    // 0x55a6b8: r16 = Sentinel
    //     0x55a6b8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55a6bc: cmp             w2, w16
    // 0x55a6c0: b.eq            #0x55a788
    // 0x55a6c4: r0 = LoadClassIdInstr(r2)
    //     0x55a6c4: ldur            x0, [x2, #-1]
    //     0x55a6c8: ubfx            x0, x0, #0xc, #0x14
    // 0x55a6cc: ldr             x16, [fp, #0x10]
    // 0x55a6d0: stp             x16, x2, [SP, #-0x10]!
    // 0x55a6d4: r0 = GDT[cid_x0 + -0xef]()
    //     0x55a6d4: sub             lr, x0, #0xef
    //     0x55a6d8: ldr             lr, [x21, lr, lsl #3]
    //     0x55a6dc: blr             lr
    // 0x55a6e0: add             SP, SP, #0x10
    // 0x55a6e4: r1 = 59
    //     0x55a6e4: mov             x1, #0x3b
    // 0x55a6e8: branchIfSmi(r0, 0x55a6f4)
    //     0x55a6e8: tbz             w0, #0, #0x55a6f4
    // 0x55a6ec: r1 = LoadClassIdInstr(r0)
    //     0x55a6ec: ldur            x1, [x0, #-1]
    //     0x55a6f0: ubfx            x1, x1, #0xc, #0x14
    // 0x55a6f4: SaveReg r0
    //     0x55a6f4: str             x0, [SP, #-8]!
    // 0x55a6f8: mov             x0, x1
    // 0x55a6fc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x55a6fc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x55a700: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x55a700: mov             x17, #0x3f73
    //     0x55a704: add             lr, x0, x17
    //     0x55a708: ldr             lr, [x21, lr, lsl #3]
    //     0x55a70c: blr             lr
    // 0x55a710: add             SP, SP, #8
    // 0x55a714: SaveReg r0
    //     0x55a714: str             x0, [SP, #-8]!
    // 0x55a718: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x55a718: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x55a71c: r0 = parse()
    //     0x55a71c: bl              #0x4d5d84  ; [dart:core] int::parse
    // 0x55a720: add             SP, SP, #8
    // 0x55a724: mov             x2, x0
    // 0x55a728: r0 = BoxInt64Instr(r2)
    //     0x55a728: sbfiz           x0, x2, #1, #0x1f
    //     0x55a72c: cmp             x2, x0, asr #1
    //     0x55a730: b.eq            #0x55a73c
    //     0x55a734: bl              #0xd69bb8
    //     0x55a738: stur            x2, [x0, #7]
    // 0x55a73c: ldur            x1, [fp, #-8]
    // 0x55a740: StoreField: r1->field_13 = r0
    //     0x55a740: stur            w0, [x1, #0x13]
    //     0x55a744: tbz             w0, #0, #0x55a760
    //     0x55a748: ldurb           w16, [x1, #-1]
    //     0x55a74c: ldurb           w17, [x0, #-1]
    //     0x55a750: and             x16, x17, x16, lsr #2
    //     0x55a754: tst             x16, HEAP, lsr #32
    //     0x55a758: b.eq            #0x55a760
    //     0x55a75c: bl              #0xd6826c
    // 0x55a760: r0 = true
    //     0x55a760: add             x0, NULL, #0x20  ; true
    // 0x55a764: LeaveFrame
    //     0x55a764: mov             SP, fp
    //     0x55a768: ldp             fp, lr, [SP], #0x10
    // 0x55a76c: ret
    //     0x55a76c: ret             
    // 0x55a770: r0 = false
    //     0x55a770: add             x0, NULL, #0x30  ; false
    // 0x55a774: LeaveFrame
    //     0x55a774: mov             SP, fp
    //     0x55a778: ldp             fp, lr, [SP], #0x10
    // 0x55a77c: ret
    //     0x55a77c: ret             
    // 0x55a780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a784: b               #0x55a658
    // 0x55a788: r9 = _headers
    //     0x55a788: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x55a78c: ldr             x9, [x9, #0xee0]
    // 0x55a790: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x55a790: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x55a794, size: 0x98
    // 0x55a794: EnterFrame
    //     0x55a794: stp             fp, lr, [SP, #-0x10]!
    //     0x55a798: mov             fp, SP
    // 0x55a79c: AllocStack(0x8)
    //     0x55a79c: sub             SP, SP, #8
    // 0x55a7a0: SetupParameters()
    //     0x55a7a0: ldr             x0, [fp, #0x18]
    //     0x55a7a4: ldur            w1, [x0, #0x17]
    //     0x55a7a8: add             x1, x1, HEAP, lsl #32
    // 0x55a7ac: CheckStackOverflow
    //     0x55a7ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a7b0: cmp             SP, x16
    //     0x55a7b4: b.ls            #0x55a824
    // 0x55a7b8: LoadField: r3 = r1->field_f
    //     0x55a7b8: ldur            w3, [x1, #0xf]
    // 0x55a7bc: DecompressPointer r3
    //     0x55a7bc: add             x3, x3, HEAP, lsl #32
    // 0x55a7c0: ldr             x0, [fp, #0x10]
    // 0x55a7c4: stur            x3, [fp, #-8]
    // 0x55a7c8: r2 = Null
    //     0x55a7c8: mov             x2, NULL
    // 0x55a7cc: r1 = Null
    //     0x55a7cc: mov             x1, NULL
    // 0x55a7d0: r4 = 59
    //     0x55a7d0: mov             x4, #0x3b
    // 0x55a7d4: branchIfSmi(r0, 0x55a7e0)
    //     0x55a7d4: tbz             w0, #0, #0x55a7e0
    // 0x55a7d8: r4 = LoadClassIdInstr(r0)
    //     0x55a7d8: ldur            x4, [x0, #-1]
    //     0x55a7dc: ubfx            x4, x4, #0xc, #0x14
    // 0x55a7e0: r17 = 4544
    //     0x55a7e0: mov             x17, #0x11c0
    // 0x55a7e4: cmp             x4, x17
    // 0x55a7e8: b.eq            #0x55a800
    // 0x55a7ec: r8 = DioException
    //     0x55a7ec: add             x8, PP, #0x12, lsl #12  ; [pp+0x12fa0] Type: DioException
    //     0x55a7f0: ldr             x8, [x8, #0xfa0]
    // 0x55a7f4: r3 = Null
    //     0x55a7f4: add             x3, PP, #0x13, lsl #12  ; [pp+0x13118] Null
    //     0x55a7f8: ldr             x3, [x3, #0x118]
    // 0x55a7fc: r0 = DioException()
    //     0x55a7fc: bl              #0x527110  ; IsType_DioException_Stub
    // 0x55a800: ldur            x16, [fp, #-8]
    // 0x55a804: ldr             lr, [fp, #0x10]
    // 0x55a808: stp             lr, x16, [SP, #-0x10]!
    // 0x55a80c: r0 = reject()
    //     0x55a80c: bl              #0x55a82c  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::reject
    // 0x55a810: add             SP, SP, #0x10
    // 0x55a814: r0 = Null
    //     0x55a814: mov             x0, NULL
    // 0x55a818: LeaveFrame
    //     0x55a818: mov             SP, fp
    //     0x55a81c: ldp             fp, lr, [SP], #0x10
    // 0x55a820: ret
    //     0x55a820: ret             
    // 0x55a824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a824: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a828: b               #0x55a7b8
  }
  [closure] void <anonymous closure>(dynamic, Response<dynamic>) {
    // ** addr: 0x55a8b0, size: 0x4c
    // 0x55a8b0: EnterFrame
    //     0x55a8b0: stp             fp, lr, [SP, #-0x10]!
    //     0x55a8b4: mov             fp, SP
    // 0x55a8b8: ldr             x0, [fp, #0x18]
    // 0x55a8bc: LoadField: r1 = r0->field_17
    //     0x55a8bc: ldur            w1, [x0, #0x17]
    // 0x55a8c0: DecompressPointer r1
    //     0x55a8c0: add             x1, x1, HEAP, lsl #32
    // 0x55a8c4: CheckStackOverflow
    //     0x55a8c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a8c8: cmp             SP, x16
    //     0x55a8cc: b.ls            #0x55a8f4
    // 0x55a8d0: LoadField: r0 = r1->field_f
    //     0x55a8d0: ldur            w0, [x1, #0xf]
    // 0x55a8d4: DecompressPointer r0
    //     0x55a8d4: add             x0, x0, HEAP, lsl #32
    // 0x55a8d8: ldr             x16, [fp, #0x10]
    // 0x55a8dc: stp             x16, x0, [SP, #-0x10]!
    // 0x55a8e0: r0 = resolve()
    //     0x55a8e0: bl              #0x55a8fc  ; [package:dio/src/dio_mixin.dart] RequestInterceptorHandler::resolve
    // 0x55a8e4: add             SP, SP, #0x10
    // 0x55a8e8: LeaveFrame
    //     0x55a8e8: mov             SP, fp
    //     0x55a8ec: ldp             fp, lr, [SP], #0x10
    // 0x55a8f0: ret
    //     0x55a8f0: ret             
    // 0x55a8f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a8f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a8f8: b               #0x55a8d0
  }
  [closure] InterceptorState<RequestOptions> <anonymous closure>(dynamic) {
    // ** addr: 0x55a974, size: 0x50
    // 0x55a974: EnterFrame
    //     0x55a974: stp             fp, lr, [SP, #-0x10]!
    //     0x55a978: mov             fp, SP
    // 0x55a97c: AllocStack(0x8)
    //     0x55a97c: sub             SP, SP, #8
    // 0x55a980: SetupParameters()
    //     0x55a980: ldr             x0, [fp, #0x10]
    //     0x55a984: ldur            w1, [x0, #0x17]
    //     0x55a988: add             x1, x1, HEAP, lsl #32
    // 0x55a98c: LoadField: r0 = r1->field_13
    //     0x55a98c: ldur            w0, [x1, #0x13]
    // 0x55a990: DecompressPointer r0
    //     0x55a990: add             x0, x0, HEAP, lsl #32
    // 0x55a994: stur            x0, [fp, #-8]
    // 0x55a998: r1 = <RequestOptions>
    //     0x55a998: add             x1, PP, #0x12, lsl #12  ; [pp+0x12ec8] TypeArguments: <RequestOptions>
    //     0x55a99c: ldr             x1, [x1, #0xec8]
    // 0x55a9a0: r0 = InterceptorState()
    //     0x55a9a0: bl              #0x527f68  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x55a9a4: ldur            x1, [fp, #-8]
    // 0x55a9a8: StoreField: r0->field_b = r1
    //     0x55a9a8: stur            w1, [x0, #0xb]
    // 0x55a9ac: r1 = Instance_InterceptorResultType
    //     0x55a9ac: add             x1, PP, #0x12, lsl #12  ; [pp+0x12ed0] Obj!InterceptorResultType@b665b1
    //     0x55a9b0: ldr             x1, [x1, #0xed0]
    // 0x55a9b4: StoreField: r0->field_f = r1
    //     0x55a9b4: stur            w1, [x0, #0xf]
    // 0x55a9b8: LeaveFrame
    //     0x55a9b8: mov             SP, fp
    //     0x55a9bc: ldp             fp, lr, [SP], #0x10
    // 0x55a9c0: ret
    //     0x55a9c0: ret             
  }
  _ _DioForNative&Object&DioMixin(/* No info */) {
    // ** addr: 0x55c20c, size: 0xf0
    // 0x55c20c: EnterFrame
    //     0x55c20c: stp             fp, lr, [SP, #-0x10]!
    //     0x55c210: mov             fp, SP
    // 0x55c214: AllocStack(0x10)
    //     0x55c214: sub             SP, SP, #0x10
    // 0x55c218: r2 = Sentinel
    //     0x55c218: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x55c21c: r1 = false
    //     0x55c21c: add             x1, NULL, #0x30  ; false
    // 0x55c220: r0 = 2
    //     0x55c220: mov             x0, #2
    // 0x55c224: ldr             x3, [fp, #0x10]
    // 0x55c228: StoreField: r3->field_7 = r2
    //     0x55c228: stur            w2, [x3, #7]
    // 0x55c22c: StoreField: r3->field_f = r2
    //     0x55c22c: stur            w2, [x3, #0xf]
    // 0x55c230: StoreField: r3->field_17 = r1
    //     0x55c230: stur            w1, [x3, #0x17]
    // 0x55c234: mov             x2, x0
    // 0x55c238: r1 = Null
    //     0x55c238: mov             x1, NULL
    // 0x55c23c: r0 = AllocateArray()
    //     0x55c23c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x55c240: stur            x0, [fp, #-8]
    // 0x55c244: r17 = Instance_ImplyContentTypeInterceptor
    //     0x55c244: add             x17, PP, #0x14, lsl #12  ; [pp+0x147b8] Obj!ImplyContentTypeInterceptor@b5c7d1
    //     0x55c248: ldr             x17, [x17, #0x7b8]
    // 0x55c24c: StoreField: r0->field_f = r17
    //     0x55c24c: stur            w17, [x0, #0xf]
    // 0x55c250: r1 = <Interceptor?>
    //     0x55c250: add             x1, PP, #0x14, lsl #12  ; [pp+0x147c0] TypeArguments: <Interceptor?>
    //     0x55c254: ldr             x1, [x1, #0x7c0]
    // 0x55c258: r0 = AllocateGrowableArray()
    //     0x55c258: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x55c25c: mov             x2, x0
    // 0x55c260: ldur            x0, [fp, #-8]
    // 0x55c264: stur            x2, [fp, #-0x10]
    // 0x55c268: StoreField: r2->field_f = r0
    //     0x55c268: stur            w0, [x2, #0xf]
    // 0x55c26c: r0 = 2
    //     0x55c26c: mov             x0, #2
    // 0x55c270: StoreField: r2->field_b = r0
    //     0x55c270: stur            w0, [x2, #0xb]
    // 0x55c274: r1 = <Interceptor>
    //     0x55c274: add             x1, PP, #0x14, lsl #12  ; [pp+0x147c8] TypeArguments: <Interceptor>
    //     0x55c278: ldr             x1, [x1, #0x7c8]
    // 0x55c27c: r0 = Interceptors()
    //     0x55c27c: bl              #0x55c308  ; AllocateInterceptorsStub -> Interceptors (size=0x10)
    // 0x55c280: mov             x1, x0
    // 0x55c284: ldur            x0, [fp, #-0x10]
    // 0x55c288: StoreField: r1->field_b = r0
    //     0x55c288: stur            w0, [x1, #0xb]
    // 0x55c28c: mov             x0, x1
    // 0x55c290: ldr             x1, [fp, #0x10]
    // 0x55c294: StoreField: r1->field_b = r0
    //     0x55c294: stur            w0, [x1, #0xb]
    //     0x55c298: ldurb           w16, [x1, #-1]
    //     0x55c29c: ldurb           w17, [x0, #-1]
    //     0x55c2a0: and             x16, x17, x16, lsr #2
    //     0x55c2a4: tst             x16, HEAP, lsr #32
    //     0x55c2a8: b.eq            #0x55c2b0
    //     0x55c2ac: bl              #0xd6826c
    // 0x55c2b0: r0 = BackgroundTransformer()
    //     0x55c2b0: bl              #0x55c2fc  ; AllocateBackgroundTransformerStub -> BackgroundTransformer (size=0x10)
    // 0x55c2b4: r1 = Closure: (String) => dynamic from Function '_decodeJson@366237976': static.
    //     0x55c2b4: add             x1, PP, #0x14, lsl #12  ; [pp+0x147d0] Closure: (String) => dynamic from Function '_decodeJson@366237976': static. (0x7fe6e1d5c42c)
    //     0x55c2b8: ldr             x1, [x1, #0x7d0]
    // 0x55c2bc: StoreField: r0->field_7 = r1
    //     0x55c2bc: stur            w1, [x0, #7]
    // 0x55c2c0: r1 = Closure: (Object?, {((Object?) => Object?)? toEncodable}) => String from Function 'jsonEncode': static.
    //     0x55c2c0: add             x1, PP, #0x14, lsl #12  ; [pp+0x147d8] Closure: (Object?, {((Object?) => Object?)? toEncodable}) => String from Function 'jsonEncode': static. (0x7fe6e1d5c314)
    //     0x55c2c4: ldr             x1, [x1, #0x7d8]
    // 0x55c2c8: StoreField: r0->field_b = r1
    //     0x55c2c8: stur            w1, [x0, #0xb]
    // 0x55c2cc: ldr             x1, [fp, #0x10]
    // 0x55c2d0: StoreField: r1->field_13 = r0
    //     0x55c2d0: stur            w0, [x1, #0x13]
    //     0x55c2d4: ldurb           w16, [x1, #-1]
    //     0x55c2d8: ldurb           w17, [x0, #-1]
    //     0x55c2dc: and             x16, x17, x16, lsr #2
    //     0x55c2e0: tst             x16, HEAP, lsr #32
    //     0x55c2e4: b.eq            #0x55c2ec
    //     0x55c2e8: bl              #0xd6826c
    // 0x55c2ec: r0 = Null
    //     0x55c2ec: mov             x0, NULL
    // 0x55c2f0: LeaveFrame
    //     0x55c2f0: mov             SP, fp
    //     0x55c2f4: ldp             fp, lr, [SP], #0x10
    // 0x55c2f8: ret
    //     0x55c2f8: ret             
  }
  _ post(/* No info */) {
    // ** addr: 0x8c5f44, size: 0x9c
    // 0x8c5f44: EnterFrame
    //     0x8c5f44: stp             fp, lr, [SP, #-0x10]!
    //     0x8c5f48: mov             fp, SP
    // 0x8c5f4c: AllocStack(0x8)
    //     0x8c5f4c: sub             SP, SP, #8
    // 0x8c5f50: SetupParameters()
    //     0x8c5f50: mov             x0, x4
    //     0x8c5f54: ldur            w1, [x0, #0xf]
    //     0x8c5f58: add             x1, x1, HEAP, lsl #32
    //     0x8c5f5c: cbnz            w1, #0x8c5f68
    //     0x8c5f60: mov             x0, NULL
    //     0x8c5f64: b               #0x8c5f78
    //     0x8c5f68: ldur            w1, [x0, #0x17]
    //     0x8c5f6c: add             x1, x1, HEAP, lsl #32
    //     0x8c5f70: add             x0, fp, w1, sxtw #2
    //     0x8c5f74: ldr             x0, [x0, #0x10]
    //     0x8c5f78: stur            x0, [fp, #-8]
    // 0x8c5f7c: CheckStackOverflow
    //     0x8c5f7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8c5f80: cmp             SP, x16
    //     0x8c5f84: b.ls            #0x8c5fd8
    // 0x8c5f88: r16 = "POST"
    //     0x8c5f88: add             x16, PP, #0x13, lsl #12  ; [pp+0x13640] "POST"
    //     0x8c5f8c: ldr             x16, [x16, #0x640]
    // 0x8c5f90: stp             NULL, x16, [SP, #-0x10]!
    // 0x8c5f94: r0 = checkOptions()
    //     0x8c5f94: bl              #0x8c5fe0  ; [package:dio/src/dio_mixin.dart] DioMixin::checkOptions
    // 0x8c5f98: add             SP, SP, #0x10
    // 0x8c5f9c: ldur            x16, [fp, #-8]
    // 0x8c5fa0: ldr             lr, [fp, #0x20]
    // 0x8c5fa4: stp             lr, x16, [SP, #-0x10]!
    // 0x8c5fa8: ldr             x16, [fp, #0x18]
    // 0x8c5fac: stp             NULL, x16, [SP, #-0x10]!
    // 0x8c5fb0: ldr             x16, [fp, #0x10]
    // 0x8c5fb4: stp             x0, x16, [SP, #-0x10]!
    // 0x8c5fb8: stp             NULL, NULL, [SP, #-0x10]!
    // 0x8c5fbc: r4 = const [0x1, 0x7, 0x7, 0x5, onReceiveProgress, 0x6, onSendProgress, 0x5, null]
    //     0x8c5fbc: add             x4, PP, #0x34, lsl #12  ; [pp+0x348b0] List(9) [0x1, 0x7, 0x7, 0x5, "onReceiveProgress", 0x6, "onSendProgress", 0x5, Null]
    //     0x8c5fc0: ldr             x4, [x4, #0x8b0]
    // 0x8c5fc4: r0 = request()
    //     0x8c5fc4: bl              #0x526f38  ; [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::request
    // 0x8c5fc8: add             SP, SP, #0x40
    // 0x8c5fcc: LeaveFrame
    //     0x8c5fcc: mov             SP, fp
    //     0x8c5fd0: ldp             fp, lr, [SP], #0x10
    // 0x8c5fd4: ret
    //     0x8c5fd4: ret             
    // 0x8c5fd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c5fd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c5fdc: b               #0x8c5f88
  }
  _ close(/* No info */) {
    // ** addr: 0xa57660, size: 0x68
    // 0xa57660: EnterFrame
    //     0xa57660: stp             fp, lr, [SP, #-0x10]!
    //     0xa57664: mov             fp, SP
    // 0xa57668: r0 = true
    //     0xa57668: add             x0, NULL, #0x20  ; true
    // 0xa5766c: CheckStackOverflow
    //     0xa5766c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa57670: cmp             SP, x16
    //     0xa57674: b.ls            #0xa576b4
    // 0xa57678: ldr             x1, [fp, #0x10]
    // 0xa5767c: StoreField: r1->field_17 = r0
    //     0xa5767c: stur            w0, [x1, #0x17]
    // 0xa57680: LoadField: r0 = r1->field_f
    //     0xa57680: ldur            w0, [x1, #0xf]
    // 0xa57684: DecompressPointer r0
    //     0xa57684: add             x0, x0, HEAP, lsl #32
    // 0xa57688: r16 = Sentinel
    //     0xa57688: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa5768c: cmp             w0, w16
    // 0xa57690: b.eq            #0xa576bc
    // 0xa57694: r16 = false
    //     0xa57694: add             x16, NULL, #0x30  ; false
    // 0xa57698: stp             x16, x0, [SP, #-0x10]!
    // 0xa5769c: r0 = close()
    //     0xa5769c: bl              #0xa576c8  ; [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::close
    // 0xa576a0: add             SP, SP, #0x10
    // 0xa576a4: r0 = Null
    //     0xa576a4: mov             x0, NULL
    // 0xa576a8: LeaveFrame
    //     0xa576a8: mov             SP, fp
    //     0xa576ac: ldp             fp, lr, [SP], #0x10
    // 0xa576b0: ret
    //     0xa576b0: ret             
    // 0xa576b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa576b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa576b8: b               #0xa57678
    // 0xa576bc: r9 = httpClientAdapter
    //     0xa576bc: add             x9, PP, #0x13, lsl #12  ; [pp+0x13128] Field <_DioForNative&Object&DioMixin@371344244.httpClientAdapter>: late (offset: 0x10)
    //     0xa576c0: ldr             x9, [x9, #0x128]
    // 0xa576c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa576c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4547, size: 0x1c, field offset: 0x1c
class DioForNative extends _DioForNative&Object&DioMixin
    implements Dio {

  _ DioForNative(/* No info */) {
    // ** addr: 0x55c14c, size: 0xb4
    // 0x55c14c: EnterFrame
    //     0x55c14c: stp             fp, lr, [SP, #-0x10]!
    //     0x55c150: mov             fp, SP
    // 0x55c154: AllocStack(0x8)
    //     0x55c154: sub             SP, SP, #8
    // 0x55c158: CheckStackOverflow
    //     0x55c158: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55c15c: cmp             SP, x16
    //     0x55c160: b.ls            #0x55c1f8
    // 0x55c164: ldr             x16, [fp, #0x18]
    // 0x55c168: SaveReg r16
    //     0x55c168: str             x16, [SP, #-8]!
    // 0x55c16c: r0 = _DioForNative&Object&DioMixin()
    //     0x55c16c: bl              #0x55c20c  ; [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::_DioForNative&Object&DioMixin
    // 0x55c170: add             SP, SP, #8
    // 0x55c174: ldr             x0, [fp, #0x10]
    // 0x55c178: cmp             w0, NULL
    // 0x55c17c: b.ne            #0x55c19c
    // 0x55c180: r0 = BaseOptions()
    //     0x55c180: bl              #0x55e71c  ; AllocateBaseOptionsStub -> BaseOptions (size=0x50)
    // 0x55c184: stur            x0, [fp, #-8]
    // 0x55c188: SaveReg r0
    //     0x55c188: str             x0, [SP, #-8]!
    // 0x55c18c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x55c18c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x55c190: r0 = BaseOptions()
    //     0x55c190: bl              #0x55e454  ; [package:dio/src/options.dart] BaseOptions::BaseOptions
    // 0x55c194: add             SP, SP, #8
    // 0x55c198: ldur            x0, [fp, #-8]
    // 0x55c19c: ldr             x1, [fp, #0x18]
    // 0x55c1a0: StoreField: r1->field_7 = r0
    //     0x55c1a0: stur            w0, [x1, #7]
    //     0x55c1a4: ldurb           w16, [x1, #-1]
    //     0x55c1a8: ldurb           w17, [x0, #-1]
    //     0x55c1ac: and             x16, x17, x16, lsr #2
    //     0x55c1b0: tst             x16, HEAP, lsr #32
    //     0x55c1b4: b.eq            #0x55c1bc
    //     0x55c1b8: bl              #0xd6826c
    // 0x55c1bc: r0 = IOHttpClientAdapter()
    //     0x55c1bc: bl              #0x55c200  ; AllocateIOHttpClientAdapterStub -> IOHttpClientAdapter (size=0x1c)
    // 0x55c1c0: r1 = false
    //     0x55c1c0: add             x1, NULL, #0x30  ; false
    // 0x55c1c4: StoreField: r0->field_17 = r1
    //     0x55c1c4: stur            w1, [x0, #0x17]
    // 0x55c1c8: ldr             x1, [fp, #0x18]
    // 0x55c1cc: StoreField: r1->field_f = r0
    //     0x55c1cc: stur            w0, [x1, #0xf]
    //     0x55c1d0: ldurb           w16, [x1, #-1]
    //     0x55c1d4: ldurb           w17, [x0, #-1]
    //     0x55c1d8: and             x16, x17, x16, lsr #2
    //     0x55c1dc: tst             x16, HEAP, lsr #32
    //     0x55c1e0: b.eq            #0x55c1e8
    //     0x55c1e4: bl              #0xd6826c
    // 0x55c1e8: r0 = Null
    //     0x55c1e8: mov             x0, NULL
    // 0x55c1ec: LeaveFrame
    //     0x55c1ec: mov             SP, fp
    //     0x55c1f0: ldp             fp, lr, [SP], #0x10
    // 0x55c1f4: ret
    //     0x55c1f4: ret             
    // 0x55c1f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55c1f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55c1fc: b               #0x55c164
  }
  _ download(/* No info */) async {
    // ** addr: 0x965f94, size: 0xa94
    // 0x965f94: EnterFrame
    //     0x965f94: stp             fp, lr, [SP, #-0x10]!
    //     0x965f98: mov             fp, SP
    // 0x965f9c: AllocStack(0xf8)
    //     0x965f9c: sub             SP, SP, #0xf8
    // 0x965fa0: SetupParameters(DioForNative this /* r3, fp-0xe8 */, dynamic _ /* r4, fp-0xe0 */, dynamic _ /* r5, fp-0xd8 */, {dynamic cancelToken = Null /* r2, fp-0xd0 */, dynamic onReceiveProgress = Null /* r1, fp-0xc8 */})
    //     0x965fa0: stur            NULL, [fp, #-8]
    //     0x965fa4: stur            x4, [fp, #-0xf0]
    //     0x965fa8: mov             x0, x4
    //     0x965fac: ldur            w1, [x0, #0x13]
    //     0x965fb0: add             x1, x1, HEAP, lsl #32
    //     0x965fb4: sub             x2, x1, #6
    //     0x965fb8: add             x3, fp, w2, sxtw #2
    //     0x965fbc: ldr             x3, [x3, #0x20]
    //     0x965fc0: stur            x3, [fp, #-0xe8]
    //     0x965fc4: add             x4, fp, w2, sxtw #2
    //     0x965fc8: ldr             x4, [x4, #0x18]
    //     0x965fcc: stur            x4, [fp, #-0xe0]
    //     0x965fd0: add             x5, fp, w2, sxtw #2
    //     0x965fd4: ldr             x5, [x5, #0x10]
    //     0x965fd8: stur            x5, [fp, #-0xd8]
    //     0x965fdc: ldur            w2, [x0, #0x1f]
    //     0x965fe0: add             x2, x2, HEAP, lsl #32
    //     0x965fe4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12c50] "cancelToken"
    //     0x965fe8: ldr             x16, [x16, #0xc50]
    //     0x965fec: cmp             w2, w16
    //     0x965ff0: b.ne            #0x966010
    //     0x965ff4: ldur            w2, [x0, #0x23]
    //     0x965ff8: add             x2, x2, HEAP, lsl #32
    //     0x965ffc: sub             w6, w1, w2
    //     0x966000: add             x2, fp, w6, sxtw #2
    //     0x966004: ldr             x2, [x2, #8]
    //     0x966008: mov             x6, #1
    //     0x96600c: b               #0x966018
    //     0x966010: mov             x6, #0
    //     0x966014: mov             x2, NULL
    //     0x966018: stur            x2, [fp, #-0xd0]
    //     0x96601c: lsl             x7, x6, #1
    //     0x966020: lsl             w6, w7, #1
    //     0x966024: add             w7, w6, #8
    //     0x966028: add             x16, x0, w7, sxtw #1
    //     0x96602c: ldur            w8, [x16, #0xf]
    //     0x966030: add             x8, x8, HEAP, lsl #32
    //     0x966034: add             x16, PP, #0x12, lsl #12  ; [pp+0x12db8] "onReceiveProgress"
    //     0x966038: ldr             x16, [x16, #0xdb8]
    //     0x96603c: cmp             w8, w16
    //     0x966040: b.ne            #0x966064
    //     0x966044: add             w7, w6, #0xa
    //     0x966048: add             x16, x0, w7, sxtw #1
    //     0x96604c: ldur            w6, [x16, #0xf]
    //     0x966050: add             x6, x6, HEAP, lsl #32
    //     0x966054: sub             w7, w1, w6
    //     0x966058: add             x1, fp, w7, sxtw #2
    //     0x96605c: ldr             x1, [x1, #8]
    //     0x966060: b               #0x966068
    //     0x966064: mov             x1, NULL
    //     0x966068: stur            x1, [fp, #-0xc8]
    // 0x96606c: CheckStackOverflow
    //     0x96606c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x966070: cmp             SP, x16
    //     0x966074: b.ls            #0x9669f4
    // 0x966078: r1 = 13
    //     0x966078: mov             x1, #0xd
    // 0x96607c: r0 = AllocateContext()
    //     0x96607c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x966080: mov             x1, x0
    // 0x966084: ldur            x0, [fp, #-0xd0]
    // 0x966088: stur            x1, [fp, #-0xf8]
    // 0x96608c: StoreField: r1->field_f = r0
    //     0x96608c: stur            w0, [x1, #0xf]
    // 0x966090: ldur            x0, [fp, #-0xc8]
    // 0x966094: StoreField: r1->field_13 = r0
    //     0x966094: stur            w0, [x1, #0x13]
    // 0x966098: InitAsync() -> Future<Response>
    //     0x966098: add             x0, PP, #0x12, lsl #12  ; [pp+0x12f70] TypeArguments: <Response>
    //     0x96609c: ldr             x0, [x0, #0xf70]
    //     0x9660a0: bl              #0x4b92e4
    // 0x9660a4: r16 = "GET"
    //     0x9660a4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13630] "GET"
    //     0x9660a8: ldr             x16, [x16, #0x630]
    // 0x9660ac: stp             NULL, x16, [SP, #-0x10]!
    // 0x9660b0: r0 = checkOptions()
    //     0x9660b0: bl              #0x8c5fe0  ; [package:dio/src/dio_mixin.dart] DioMixin::checkOptions
    // 0x9660b4: add             SP, SP, #0x10
    // 0x9660b8: mov             x1, x0
    // 0x9660bc: r0 = Instance_ResponseType
    //     0x9660bc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12df8] Obj!ResponseType@b66571
    //     0x9660c0: ldr             x0, [x0, #0xdf8]
    // 0x9660c4: stur            x1, [fp, #-0xc8]
    // 0x9660c8: StoreField: r1->field_1b = r0
    //     0x9660c8: stur            w0, [x1, #0x1b]
    // 0x9660cc: ldur            x2, [fp, #-0xf8]
    // 0x9660d0: StoreField: r2->field_17 = rNULL
    //     0x9660d0: stur            NULL, [x2, #0x17]
    // 0x9660d4: LoadField: r0 = r2->field_f
    //     0x9660d4: ldur            w0, [x2, #0xf]
    // 0x9660d8: DecompressPointer r0
    //     0x9660d8: add             x0, x0, HEAP, lsl #32
    // 0x9660dc: cmp             w0, NULL
    // 0x9660e0: b.ne            #0x9660fc
    // 0x9660e4: r0 = CancelToken()
    //     0x9660e4: bl              #0x889810  ; AllocateCancelTokenStub -> CancelToken (size=0x14)
    // 0x9660e8: stur            x0, [fp, #-0xd0]
    // 0x9660ec: SaveReg r0
    //     0x9660ec: str             x0, [SP, #-8]!
    // 0x9660f0: r0 = CancelToken()
    //     0x9660f0: bl              #0x889768  ; [package:dio/src/cancel_token.dart] CancelToken::CancelToken
    // 0x9660f4: add             SP, SP, #8
    // 0x9660f8: ldur            x0, [fp, #-0xd0]
    // 0x9660fc: ldur            x2, [fp, #-0xf8]
    // 0x966100: r16 = <ResponseBody>
    //     0x966100: add             x16, PP, #0x13, lsl #12  ; [pp+0x13368] TypeArguments: <ResponseBody>
    //     0x966104: ldr             x16, [x16, #0x368]
    // 0x966108: ldur            lr, [fp, #-0xe8]
    // 0x96610c: stp             lr, x16, [SP, #-0x10]!
    // 0x966110: ldur            x16, [fp, #-0xe0]
    // 0x966114: stp             x0, x16, [SP, #-0x10]!
    // 0x966118: ldur            x16, [fp, #-0xc8]
    // 0x96611c: stp             x16, NULL, [SP, #-0x10]!
    // 0x966120: r4 = const [0x1, 0x5, 0x5, 0x5, null]
    //     0x966120: ldr             x4, [PP, #0x5120]  ; [pp+0x5120] List(5) [0x1, 0x5, 0x5, 0x5, Null]
    // 0x966124: r0 = request()
    //     0x966124: bl              #0x526f38  ; [package:dio/src/dio/dio_for_native.dart] _DioForNative&Object&DioMixin::request
    // 0x966128: add             SP, SP, #0x30
    // 0x96612c: mov             x1, x0
    // 0x966130: stur            x1, [fp, #-0xc8]
    // 0x966134: r0 = Await()
    //     0x966134: bl              #0x4b8e6c  ; AwaitStub
    // 0x966138: mov             x4, x0
    // 0x96613c: ldur            x3, [fp, #-0xf8]
    // 0x966140: stur            x4, [fp, #-0xc8]
    // 0x966144: StoreField: r3->field_17 = r0
    //     0x966144: stur            w0, [x3, #0x17]
    //     0x966148: tbz             w0, #0, #0x966164
    //     0x96614c: ldurb           w16, [x3, #-1]
    //     0x966150: ldurb           w17, [x0, #-1]
    //     0x966154: and             x16, x17, x16, lsr #2
    //     0x966158: tst             x16, HEAP, lsr #32
    //     0x96615c: b.eq            #0x966164
    //     0x966160: bl              #0xd682ac
    // 0x966164: StoreField: r3->field_1b = rNULL
    //     0x966164: stur            NULL, [x3, #0x1b]
    // 0x966168: ldur            x0, [fp, #-0xd8]
    // 0x96616c: r2 = Null
    //     0x96616c: mov             x2, NULL
    // 0x966170: r1 = Null
    //     0x966170: mov             x1, NULL
    // 0x966174: cmp             w0, NULL
    // 0x966178: b.eq            #0x9661cc
    // 0x96617c: branchIfSmi(r0, 0x9661cc)
    //     0x96617c: tbz             w0, #0, #0x9661cc
    // 0x966180: r8 = (dynamic this, Headers) => FutureOr<String>
    //     0x966180: add             x8, PP, #0x30, lsl #12  ; [pp+0x300a0] FunctionType: (dynamic this, Headers) => FutureOr<String>
    //     0x966184: ldr             x8, [x8, #0xa0]
    // 0x966188: r3 = SubtypeTestCache
    //     0x966188: add             x3, PP, #0x30, lsl #12  ; [pp+0x300a8] SubtypeTestCache
    //     0x96618c: ldr             x3, [x3, #0xa8]
    // 0x966190: r24 = Subtype7TestCacheStub
    //     0x966190: ldr             x24, [PP, #0x18]  ; [pp+0x18] Stub: Subtype7TestCache (0x4ae0ac)
    // 0x966194: LoadField: r30 = r24->field_7
    //     0x966194: ldur            lr, [x24, #7]
    // 0x966198: blr             lr
    // 0x96619c: cmp             w7, NULL
    // 0x9661a0: b.eq            #0x9661ac
    // 0x9661a4: tbnz            w7, #4, #0x9661cc
    // 0x9661a8: b               #0x9661d4
    // 0x9661ac: r8 = (dynamic this, Headers) => FutureOr<String>
    //     0x9661ac: add             x8, PP, #0x30, lsl #12  ; [pp+0x300b0] FunctionType: (dynamic this, Headers) => FutureOr<String>
    //     0x9661b0: ldr             x8, [x8, #0xb0]
    // 0x9661b4: r3 = SubtypeTestCache
    //     0x9661b4: add             x3, PP, #0x30, lsl #12  ; [pp+0x300b8] SubtypeTestCache
    //     0x9661b8: ldr             x3, [x3, #0xb8]
    // 0x9661bc: r24 = InstanceOfStub
    //     0x9661bc: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x9661c0: LoadField: r30 = r24->field_7
    //     0x9661c0: ldur            lr, [x24, #7]
    // 0x9661c4: blr             lr
    // 0x9661c8: b               #0x9661d8
    // 0x9661cc: r0 = false
    //     0x9661cc: add             x0, NULL, #0x30  ; false
    // 0x9661d0: b               #0x9661d8
    // 0x9661d4: r0 = true
    //     0x9661d4: add             x0, NULL, #0x20  ; true
    // 0x9661d8: tbnz            w0, #4, #0x966394
    // 0x9661dc: ldur            x2, [fp, #-0xf8]
    // 0x9661e0: ldur            x0, [fp, #-0xc8]
    // 0x9661e4: cmp             w0, NULL
    // 0x9661e8: b.eq            #0x9669fc
    // 0x9661ec: LoadField: r1 = r0->field_27
    //     0x9661ec: ldur            w1, [x0, #0x27]
    // 0x9661f0: DecompressPointer r1
    //     0x9661f0: add             x1, x1, HEAP, lsl #32
    // 0x9661f4: stur            x1, [fp, #-0xd0]
    // 0x9661f8: LoadField: r3 = r0->field_1f
    //     0x9661f8: ldur            w3, [x0, #0x1f]
    // 0x9661fc: DecompressPointer r3
    //     0x9661fc: add             x3, x3, HEAP, lsl #32
    // 0x966200: r0 = LoadClassIdInstr(r3)
    //     0x966200: ldur            x0, [x3, #-1]
    //     0x966204: ubfx            x0, x0, #0xc, #0x14
    // 0x966208: SaveReg r3
    //     0x966208: str             x3, [SP, #-8]!
    // 0x96620c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x96620c: mov             x17, #0xb8ea
    //     0x966210: add             lr, x0, x17
    //     0x966214: ldr             lr, [x21, lr, lsl #3]
    //     0x966218: blr             lr
    // 0x96621c: add             SP, SP, #8
    // 0x966220: SaveReg r0
    //     0x966220: str             x0, [SP, #-8]!
    // 0x966224: r0 = toString()
    //     0x966224: bl              #0xaf6744  ; [dart:core] _Smi::toString
    // 0x966228: add             SP, SP, #8
    // 0x96622c: ldur            x16, [fp, #-0xd0]
    // 0x966230: r30 = "redirects"
    //     0x966230: add             lr, PP, #0x13, lsl #12  ; [pp+0x130a8] "redirects"
    //     0x966234: ldr             lr, [lr, #0xa8]
    // 0x966238: stp             lr, x16, [SP, #-0x10]!
    // 0x96623c: SaveReg r0
    //     0x96623c: str             x0, [SP, #-8]!
    // 0x966240: r0 = add()
    //     0x966240: bl              #0x966c40  ; [package:dio/src/headers.dart] Headers::add
    // 0x966244: add             SP, SP, #0x18
    // 0x966248: ldur            x2, [fp, #-0xf8]
    // 0x96624c: LoadField: r0 = r2->field_17
    //     0x96624c: ldur            w0, [x2, #0x17]
    // 0x966250: DecompressPointer r0
    //     0x966250: add             x0, x0, HEAP, lsl #32
    // 0x966254: cmp             w0, NULL
    // 0x966258: b.eq            #0x966a00
    // 0x96625c: SaveReg r0
    //     0x96625c: str             x0, [SP, #-8]!
    // 0x966260: r0 = realUri()
    //     0x966260: bl              #0x966b90  ; [package:dio/src/response.dart] Response::realUri
    // 0x966264: add             SP, SP, #8
    // 0x966268: r1 = LoadClassIdInstr(r0)
    //     0x966268: ldur            x1, [x0, #-1]
    //     0x96626c: ubfx            x1, x1, #0xc, #0x14
    // 0x966270: SaveReg r0
    //     0x966270: str             x0, [SP, #-8]!
    // 0x966274: mov             x0, x1
    // 0x966278: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x966278: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x96627c: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x96627c: mov             x17, #0x3f73
    //     0x966280: add             lr, x0, x17
    //     0x966284: ldr             lr, [x21, lr, lsl #3]
    //     0x966288: blr             lr
    // 0x96628c: add             SP, SP, #8
    // 0x966290: ldur            x16, [fp, #-0xd0]
    // 0x966294: r30 = "uri"
    //     0x966294: ldr             lr, [PP, #0x2aa0]  ; [pp+0x2aa0] "uri"
    // 0x966298: stp             lr, x16, [SP, #-0x10]!
    // 0x96629c: SaveReg r0
    //     0x96629c: str             x0, [SP, #-8]!
    // 0x9662a0: r0 = add()
    //     0x9662a0: bl              #0x966c40  ; [package:dio/src/headers.dart] Headers::add
    // 0x9662a4: add             SP, SP, #0x18
    // 0x9662a8: ldur            x2, [fp, #-0xf8]
    // 0x9662ac: LoadField: r0 = r2->field_17
    //     0x9662ac: ldur            w0, [x2, #0x17]
    // 0x9662b0: DecompressPointer r0
    //     0x9662b0: add             x0, x0, HEAP, lsl #32
    // 0x9662b4: cmp             w0, NULL
    // 0x9662b8: b.eq            #0x966a04
    // 0x9662bc: LoadField: r1 = r0->field_27
    //     0x9662bc: ldur            w1, [x0, #0x27]
    // 0x9662c0: DecompressPointer r1
    //     0x9662c0: add             x1, x1, HEAP, lsl #32
    // 0x9662c4: ldur            x16, [fp, #-0xd8]
    // 0x9662c8: stp             x1, x16, [SP, #-0x10]!
    // 0x9662cc: ldur            x0, [fp, #-0xd8]
    // 0x9662d0: ClosureCall
    //     0x9662d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x9662d4: ldur            x2, [x0, #0x1f]
    //     0x9662d8: blr             x2
    // 0x9662dc: add             SP, SP, #0x10
    // 0x9662e0: mov             x1, x0
    // 0x9662e4: stur            x1, [fp, #-0xc8]
    // 0x9662e8: r0 = Await()
    //     0x9662e8: bl              #0x4b8e6c  ; AwaitStub
    // 0x9662ec: stur            x0, [fp, #-0xc8]
    // 0x9662f0: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x9662f0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9662f4: ldr             x0, [x0, #0xb58]
    //     0x9662f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9662fc: cmp             w0, w16
    //     0x966300: b.ne            #0x96630c
    //     0x966304: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x966308: bl              #0xd67d44
    // 0x96630c: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0x96630c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x966310: ldr             x0, [x0, #0xdd8]
    //     0x966314: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x966318: cmp             w0, w16
    //     0x96631c: b.ne            #0x966328
    //     0x966320: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0x966324: bl              #0xd67cdc
    // 0x966328: r0 = _File()
    //     0x966328: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0x96632c: mov             x1, x0
    // 0x966330: ldur            x0, [fp, #-0xc8]
    // 0x966334: stur            x1, [fp, #-0xd0]
    // 0x966338: StoreField: r1->field_7 = r0
    //     0x966338: stur            w0, [x1, #7]
    // 0x96633c: SaveReg r0
    //     0x96633c: str             x0, [SP, #-8]!
    // 0x966340: r0 = _toUtf8Array()
    //     0x966340: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x966344: add             SP, SP, #8
    // 0x966348: ldur            x1, [fp, #-0xd0]
    // 0x96634c: StoreField: r1->field_b = r0
    //     0x96634c: stur            w0, [x1, #0xb]
    //     0x966350: ldurb           w16, [x1, #-1]
    //     0x966354: ldurb           w17, [x0, #-1]
    //     0x966358: and             x16, x17, x16, lsr #2
    //     0x96635c: tst             x16, HEAP, lsr #32
    //     0x966360: b.eq            #0x966368
    //     0x966364: bl              #0xd6826c
    // 0x966368: mov             x0, x1
    // 0x96636c: ldur            x2, [fp, #-0xf8]
    // 0x966370: StoreField: r2->field_1b = r0
    //     0x966370: stur            w0, [x2, #0x1b]
    //     0x966374: ldurb           w16, [x2, #-1]
    //     0x966378: ldurb           w17, [x0, #-1]
    //     0x96637c: and             x16, x17, x16, lsr #2
    //     0x966380: tst             x16, HEAP, lsr #32
    //     0x966384: b.eq            #0x96638c
    //     0x966388: bl              #0xd6828c
    // 0x96638c: mov             x0, x1
    // 0x966390: b               #0x96643c
    // 0x966394: ldur            x0, [fp, #-0xd8]
    // 0x966398: ldur            x2, [fp, #-0xf8]
    // 0x96639c: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x96639c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9663a0: ldr             x0, [x0, #0xb58]
    //     0x9663a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9663a8: cmp             w0, w16
    //     0x9663ac: b.ne            #0x9663b8
    //     0x9663b0: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x9663b4: bl              #0xd67d44
    // 0x9663b8: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0x9663b8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9663bc: ldr             x0, [x0, #0xdd8]
    //     0x9663c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9663c4: cmp             w0, w16
    //     0x9663c8: b.ne            #0x9663d4
    //     0x9663cc: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0x9663d0: bl              #0xd67cdc
    // 0x9663d4: r0 = _File()
    //     0x9663d4: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0x9663d8: mov             x1, x0
    // 0x9663dc: ldur            x0, [fp, #-0xd8]
    // 0x9663e0: stur            x1, [fp, #-0xc8]
    // 0x9663e4: StoreField: r1->field_7 = r0
    //     0x9663e4: stur            w0, [x1, #7]
    // 0x9663e8: SaveReg r0
    //     0x9663e8: str             x0, [SP, #-8]!
    // 0x9663ec: r0 = _toUtf8Array()
    //     0x9663ec: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x9663f0: add             SP, SP, #8
    // 0x9663f4: ldur            x1, [fp, #-0xc8]
    // 0x9663f8: StoreField: r1->field_b = r0
    //     0x9663f8: stur            w0, [x1, #0xb]
    //     0x9663fc: ldurb           w16, [x1, #-1]
    //     0x966400: ldurb           w17, [x0, #-1]
    //     0x966404: and             x16, x17, x16, lsr #2
    //     0x966408: tst             x16, HEAP, lsr #32
    //     0x96640c: b.eq            #0x966414
    //     0x966410: bl              #0xd6826c
    // 0x966414: mov             x0, x1
    // 0x966418: ldur            x2, [fp, #-0xf8]
    // 0x96641c: StoreField: r2->field_1b = r0
    //     0x96641c: stur            w0, [x2, #0x1b]
    //     0x966420: ldurb           w16, [x2, #-1]
    //     0x966424: ldurb           w17, [x0, #-1]
    //     0x966428: and             x16, x17, x16, lsr #2
    //     0x96642c: tst             x16, HEAP, lsr #32
    //     0x966430: b.eq            #0x966438
    //     0x966434: bl              #0xd6828c
    // 0x966438: mov             x0, x1
    // 0x96643c: stur            x0, [fp, #-0xc8]
    // 0x966440: r16 = true
    //     0x966440: add             x16, NULL, #0x20  ; true
    // 0x966444: stp             x16, x0, [SP, #-0x10]!
    // 0x966448: r0 = createSync()
    //     0x966448: bl              #0xcabe04  ; [dart:io] _File::createSync
    // 0x96644c: add             SP, SP, #0x10
    // 0x966450: ldur            x16, [fp, #-0xc8]
    // 0x966454: r30 = Instance_FileMode
    //     0x966454: add             lr, PP, #8, lsl #12  ; [pp+0x8e60] Obj!FileMode@b5f4b1
    //     0x966458: ldr             lr, [lr, #0xe60]
    // 0x96645c: stp             lr, x16, [SP, #-0x10]!
    // 0x966460: r4 = const [0, 0x2, 0x2, 0x1, mode, 0x1, null]
    //     0x966460: ldr             x4, [PP, #0x4128]  ; [pp+0x4128] List(7) [0, 0x2, 0x2, 0x1, "mode", 0x1, Null]
    // 0x966464: r0 = openSync()
    //     0x966464: bl              #0xcaa584  ; [dart:io] _File::openSync
    // 0x966468: add             SP, SP, #0x10
    // 0x96646c: ldur            x2, [fp, #-0xf8]
    // 0x966470: StoreField: r2->field_1f = r0
    //     0x966470: stur            w0, [x2, #0x1f]
    //     0x966474: ldurb           w16, [x2, #-1]
    //     0x966478: ldurb           w17, [x0, #-1]
    //     0x96647c: and             x16, x17, x16, lsr #2
    //     0x966480: tst             x16, HEAP, lsr #32
    //     0x966484: b.eq            #0x96648c
    //     0x966488: bl              #0xd6828c
    // 0x96648c: r1 = <Response>
    //     0x96648c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f70] TypeArguments: <Response>
    //     0x966490: ldr             x1, [x1, #0xf70]
    // 0x966494: r0 = _Future()
    //     0x966494: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x966498: mov             x2, x0
    // 0x96649c: r0 = 0
    //     0x96649c: mov             x0, #0
    // 0x9664a0: stur            x2, [fp, #-0xc8]
    // 0x9664a4: StoreField: r2->field_b = r0
    //     0x9664a4: stur            x0, [x2, #0xb]
    // 0x9664a8: r0 = LoadStaticField(0x5ac)
    //     0x9664a8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9664ac: ldr             x0, [x0, #0xb58]
    // 0x9664b0: StoreField: r2->field_13 = r0
    //     0x9664b0: stur            w0, [x2, #0x13]
    // 0x9664b4: r1 = <Response>
    //     0x9664b4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f70] TypeArguments: <Response>
    //     0x9664b8: ldr             x1, [x1, #0xf70]
    // 0x9664bc: r0 = _AsyncCompleter()
    //     0x9664bc: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x9664c0: ldur            x1, [fp, #-0xc8]
    // 0x9664c4: StoreField: r0->field_b = r1
    //     0x9664c4: stur            w1, [x0, #0xb]
    // 0x9664c8: ldur            x2, [fp, #-0xf8]
    // 0x9664cc: StoreField: r2->field_23 = r0
    //     0x9664cc: stur            w0, [x2, #0x23]
    //     0x9664d0: ldurb           w16, [x2, #-1]
    //     0x9664d4: ldurb           w17, [x0, #-1]
    //     0x9664d8: and             x16, x17, x16, lsr #2
    //     0x9664dc: tst             x16, HEAP, lsr #32
    //     0x9664e0: b.eq            #0x9664e8
    //     0x9664e4: bl              #0xd6828c
    // 0x9664e8: StoreField: r2->field_27 = rZR
    //     0x9664e8: stur            wzr, [x2, #0x27]
    // 0x9664ec: LoadField: r0 = r2->field_17
    //     0x9664ec: ldur            w0, [x2, #0x17]
    // 0x9664f0: DecompressPointer r0
    //     0x9664f0: add             x0, x0, HEAP, lsl #32
    // 0x9664f4: cmp             w0, NULL
    // 0x9664f8: b.eq            #0x966a08
    // 0x9664fc: LoadField: r3 = r0->field_b
    //     0x9664fc: ldur            w3, [x0, #0xb]
    // 0x966500: DecompressPointer r3
    //     0x966500: add             x3, x3, HEAP, lsl #32
    // 0x966504: cmp             w3, NULL
    // 0x966508: b.eq            #0x966a0c
    // 0x96650c: LoadField: r4 = r3->field_7
    //     0x96650c: ldur            w4, [x3, #7]
    // 0x966510: DecompressPointer r4
    //     0x966510: add             x4, x4, HEAP, lsl #32
    // 0x966514: stur            x4, [fp, #-0xd0]
    // 0x966518: StoreField: r2->field_2b = rZR
    //     0x966518: stur            wzr, [x2, #0x2b]
    // 0x96651c: LoadField: r3 = r0->field_27
    //     0x96651c: ldur            w3, [x0, #0x27]
    // 0x966520: DecompressPointer r3
    //     0x966520: add             x3, x3, HEAP, lsl #32
    // 0x966524: r16 = "content-encoding"
    //     0x966524: add             x16, PP, #0x13, lsl #12  ; [pp+0x139d8] "content-encoding"
    //     0x966528: ldr             x16, [x16, #0x9d8]
    // 0x96652c: stp             x16, x3, [SP, #-0x10]!
    // 0x966530: r0 = value()
    //     0x966530: bl              #0x966a28  ; [package:dio/src/headers.dart] Headers::value
    // 0x966534: add             SP, SP, #0x10
    // 0x966538: stur            x0, [fp, #-0xd8]
    // 0x96653c: cmp             w0, NULL
    // 0x966540: b.eq            #0x9665ac
    // 0x966544: r3 = 6
    //     0x966544: mov             x3, #6
    // 0x966548: mov             x2, x3
    // 0x96654c: r1 = Null
    //     0x96654c: mov             x1, NULL
    // 0x966550: r0 = AllocateArray()
    //     0x966550: bl              #0xd6987c  ; AllocateArrayStub
    // 0x966554: stur            x0, [fp, #-0xe0]
    // 0x966558: r17 = "gzip"
    //     0x966558: add             x17, PP, #0x13, lsl #12  ; [pp+0x13768] "gzip"
    //     0x96655c: ldr             x17, [x17, #0x768]
    // 0x966560: StoreField: r0->field_f = r17
    //     0x966560: stur            w17, [x0, #0xf]
    // 0x966564: r17 = "deflate"
    //     0x966564: add             x17, PP, #0x30, lsl #12  ; [pp+0x300c0] "deflate"
    //     0x966568: ldr             x17, [x17, #0xc0]
    // 0x96656c: StoreField: r0->field_13 = r17
    //     0x96656c: stur            w17, [x0, #0x13]
    // 0x966570: r17 = "compress"
    //     0x966570: add             x17, PP, #0x30, lsl #12  ; [pp+0x300c8] "compress"
    //     0x966574: ldr             x17, [x17, #0xc8]
    // 0x966578: StoreField: r0->field_17 = r17
    //     0x966578: stur            w17, [x0, #0x17]
    // 0x96657c: r1 = <String>
    //     0x96657c: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x966580: r0 = AllocateGrowableArray()
    //     0x966580: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x966584: mov             x1, x0
    // 0x966588: ldur            x0, [fp, #-0xe0]
    // 0x96658c: StoreField: r1->field_f = r0
    //     0x96658c: stur            w0, [x1, #0xf]
    // 0x966590: r0 = 6
    //     0x966590: mov             x0, #6
    // 0x966594: StoreField: r1->field_b = r0
    //     0x966594: stur            w0, [x1, #0xb]
    // 0x966598: ldur            x16, [fp, #-0xd8]
    // 0x96659c: stp             x16, x1, [SP, #-0x10]!
    // 0x9665a0: r0 = contains()
    //     0x9665a0: bl              #0x786724  ; [dart:collection] _ListBase&Object&ListMixin::contains
    // 0x9665a4: add             SP, SP, #0x10
    // 0x9665a8: b               #0x9665b0
    // 0x9665ac: r0 = false
    //     0x9665ac: add             x0, NULL, #0x30  ; false
    // 0x9665b0: tbnz            w0, #4, #0x9665c8
    // 0x9665b4: ldur            x2, [fp, #-0xf8]
    // 0x9665b8: r0 = -2
    //     0x9665b8: mov             x0, #-2
    // 0x9665bc: StoreField: r2->field_2b = r0
    //     0x9665bc: stur            w0, [x2, #0x2b]
    // 0x9665c0: mov             x3, x2
    // 0x9665c4: b               #0x966658
    // 0x9665c8: ldur            x2, [fp, #-0xf8]
    // 0x9665cc: LoadField: r0 = r2->field_17
    //     0x9665cc: ldur            w0, [x2, #0x17]
    // 0x9665d0: DecompressPointer r0
    //     0x9665d0: add             x0, x0, HEAP, lsl #32
    // 0x9665d4: cmp             w0, NULL
    // 0x9665d8: b.eq            #0x966a10
    // 0x9665dc: LoadField: r1 = r0->field_27
    //     0x9665dc: ldur            w1, [x0, #0x27]
    // 0x9665e0: DecompressPointer r1
    //     0x9665e0: add             x1, x1, HEAP, lsl #32
    // 0x9665e4: r16 = "content-length"
    //     0x9665e4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13510] "content-length"
    //     0x9665e8: ldr             x16, [x16, #0x510]
    // 0x9665ec: stp             x16, x1, [SP, #-0x10]!
    // 0x9665f0: r0 = value()
    //     0x9665f0: bl              #0x966a28  ; [package:dio/src/headers.dart] Headers::value
    // 0x9665f4: add             SP, SP, #0x10
    // 0x9665f8: cmp             w0, NULL
    // 0x9665fc: b.ne            #0x966608
    // 0x966600: r0 = "-1"
    //     0x966600: add             x0, PP, #0x25, lsl #12  ; [pp+0x25ed0] "-1"
    //     0x966604: ldr             x0, [x0, #0xed0]
    // 0x966608: ldur            x2, [fp, #-0xf8]
    // 0x96660c: SaveReg r0
    //     0x96660c: str             x0, [SP, #-8]!
    // 0x966610: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x966610: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x966614: r0 = parse()
    //     0x966614: bl              #0x4d5d84  ; [dart:core] int::parse
    // 0x966618: add             SP, SP, #8
    // 0x96661c: mov             x2, x0
    // 0x966620: r0 = BoxInt64Instr(r2)
    //     0x966620: sbfiz           x0, x2, #1, #0x1f
    //     0x966624: cmp             x2, x0, asr #1
    //     0x966628: b.eq            #0x966634
    //     0x96662c: bl              #0xd69bb8
    //     0x966630: stur            x2, [x0, #7]
    // 0x966634: ldur            x3, [fp, #-0xf8]
    // 0x966638: StoreField: r3->field_2b = r0
    //     0x966638: stur            w0, [x3, #0x2b]
    //     0x96663c: tbz             w0, #0, #0x966658
    //     0x966640: ldurb           w16, [x3, #-1]
    //     0x966644: ldurb           w17, [x0, #-1]
    //     0x966648: and             x16, x17, x16, lsr #2
    //     0x96664c: tst             x16, HEAP, lsr #32
    //     0x966650: b.eq            #0x966658
    //     0x966654: bl              #0xd682ac
    // 0x966658: ldur            x0, [fp, #-0xd0]
    // 0x96665c: r1 = false
    //     0x96665c: add             x1, NULL, #0x30  ; false
    // 0x966660: StoreField: r3->field_2f = rNULL
    //     0x966660: stur            NULL, [x3, #0x2f]
    // 0x966664: StoreField: r3->field_33 = r1
    //     0x966664: stur            w1, [x3, #0x33]
    // 0x966668: mov             x2, x3
    // 0x96666c: r1 = Function 'closeAndDelete':.
    //     0x96666c: add             x1, PP, #0x30, lsl #12  ; [pp+0x300d0] AnonymousClosure: (0x9679e4), in [package:dio/src/dio/dio_for_native.dart] DioForNative::download (0x965f94)
    //     0x966670: ldr             x1, [x1, #0xd0]
    // 0x966674: r0 = AllocateClosure()
    //     0x966674: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x966678: ldur            x3, [fp, #-0xf8]
    // 0x96667c: StoreField: r3->field_37 = r0
    //     0x96667c: stur            w0, [x3, #0x37]
    //     0x966680: ldurb           w16, [x3, #-1]
    //     0x966684: ldurb           w17, [x0, #-1]
    //     0x966688: and             x16, x17, x16, lsr #2
    //     0x96668c: tst             x16, HEAP, lsr #32
    //     0x966690: b.eq            #0x966698
    //     0x966694: bl              #0xd682ac
    // 0x966698: r0 = Sentinel
    //     0x966698: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x96669c: StoreField: r3->field_3b = r0
    //     0x96669c: stur            w0, [x3, #0x3b]
    // 0x9666a0: mov             x2, x3
    // 0x9666a4: r1 = Function '<anonymous closure>':.
    //     0x9666a4: add             x1, PP, #0x30, lsl #12  ; [pp+0x300d8] AnonymousClosure: (0x967570), in [package:dio/src/dio/dio_for_native.dart] DioForNative::download (0x965f94)
    //     0x9666a8: ldr             x1, [x1, #0xd8]
    // 0x9666ac: r0 = AllocateClosure()
    //     0x9666ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9666b0: ldur            x2, [fp, #-0xf8]
    // 0x9666b4: r1 = Function '<anonymous closure>':.
    //     0x9666b4: add             x1, PP, #0x30, lsl #12  ; [pp+0x300e0] AnonymousClosure: (0x967224), in [package:dio/src/dio/dio_for_native.dart] DioForNative::download (0x965f94)
    //     0x9666b8: ldr             x1, [x1, #0xe0]
    // 0x9666bc: stur            x0, [fp, #-0xd8]
    // 0x9666c0: r0 = AllocateClosure()
    //     0x9666c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9666c4: ldur            x2, [fp, #-0xf8]
    // 0x9666c8: r1 = Function '<anonymous closure>':.
    //     0x9666c8: add             x1, PP, #0x30, lsl #12  ; [pp+0x300e8] AnonymousClosure: (0x967068), in [package:dio/src/dio/dio_for_native.dart] DioForNative::download (0x965f94)
    //     0x9666cc: ldr             x1, [x1, #0xe8]
    // 0x9666d0: stur            x0, [fp, #-0xe0]
    // 0x9666d4: r0 = AllocateClosure()
    //     0x9666d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9666d8: mov             x1, x0
    // 0x9666dc: ldur            x0, [fp, #-0xd0]
    // 0x9666e0: r2 = LoadClassIdInstr(r0)
    //     0x9666e0: ldur            x2, [x0, #-1]
    //     0x9666e4: ubfx            x2, x2, #0xc, #0x14
    // 0x9666e8: ldur            x16, [fp, #-0xd8]
    // 0x9666ec: stp             x16, x0, [SP, #-0x10]!
    // 0x9666f0: ldur            x16, [fp, #-0xe0]
    // 0x9666f4: stp             x1, x16, [SP, #-0x10]!
    // 0x9666f8: r16 = true
    //     0x9666f8: add             x16, NULL, #0x20  ; true
    // 0x9666fc: SaveReg r16
    //     0x9666fc: str             x16, [SP, #-8]!
    // 0x966700: mov             x0, x2
    // 0x966704: r4 = const [0, 0x5, 0x5, 0x2, cancelOnError, 0x4, onDone, 0x2, onError, 0x3, null]
    //     0x966704: add             x4, PP, #0x29, lsl #12  ; [pp+0x296a0] List(11) [0, 0x5, 0x5, 0x2, "cancelOnError", 0x4, "onDone", 0x2, "onError", 0x3, Null]
    //     0x966708: ldr             x4, [x4, #0x6a0]
    // 0x96670c: r0 = GDT[cid_x0 + 0x28a]()
    //     0x96670c: add             lr, x0, #0x28a
    //     0x966710: ldr             lr, [x21, lr, lsl #3]
    //     0x966714: blr             lr
    // 0x966718: add             SP, SP, #0x28
    // 0x96671c: ldur            x3, [fp, #-0xf8]
    // 0x966720: StoreField: r3->field_3b = r0
    //     0x966720: stur            w0, [x3, #0x3b]
    //     0x966724: tbz             w0, #0, #0x966740
    //     0x966728: ldurb           w16, [x3, #-1]
    //     0x96672c: ldurb           w17, [x0, #-1]
    //     0x966730: and             x16, x17, x16, lsr #2
    //     0x966734: tst             x16, HEAP, lsr #32
    //     0x966738: b.eq            #0x966740
    //     0x96673c: bl              #0xd682ac
    // 0x966740: LoadField: r0 = r3->field_f
    //     0x966740: ldur            w0, [x3, #0xf]
    // 0x966744: DecompressPointer r0
    //     0x966744: add             x0, x0, HEAP, lsl #32
    // 0x966748: cmp             w0, NULL
    // 0x96674c: b.ne            #0x966758
    // 0x966750: mov             x2, x3
    // 0x966754: b               #0x96679c
    // 0x966758: LoadField: r1 = r0->field_7
    //     0x966758: ldur            w1, [x0, #7]
    // 0x96675c: DecompressPointer r1
    //     0x96675c: add             x1, x1, HEAP, lsl #32
    // 0x966760: LoadField: r0 = r1->field_b
    //     0x966760: ldur            w0, [x1, #0xb]
    // 0x966764: DecompressPointer r0
    //     0x966764: add             x0, x0, HEAP, lsl #32
    // 0x966768: mov             x2, x3
    // 0x96676c: stur            x0, [fp, #-0xd0]
    // 0x966770: r1 = Function '<anonymous closure>':.
    //     0x966770: add             x1, PP, #0x30, lsl #12  ; [pp+0x300f0] AnonymousClosure: (0x966f8c), in [package:dio/src/dio/dio_for_native.dart] DioForNative::download (0x965f94)
    //     0x966774: ldr             x1, [x1, #0xf0]
    // 0x966778: r0 = AllocateClosure()
    //     0x966778: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x96677c: r16 = <Null?>
    //     0x96677c: ldr             x16, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    // 0x966780: ldur            lr, [fp, #-0xd0]
    // 0x966784: stp             lr, x16, [SP, #-0x10]!
    // 0x966788: SaveReg r0
    //     0x966788: str             x0, [SP, #-8]!
    // 0x96678c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x96678c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x966790: r0 = then()
    //     0x966790: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x966794: add             SP, SP, #0x18
    // 0x966798: ldur            x2, [fp, #-0xf8]
    // 0x96679c: LoadField: r0 = r2->field_17
    //     0x96679c: ldur            w0, [x2, #0x17]
    // 0x9667a0: DecompressPointer r0
    //     0x9667a0: add             x0, x0, HEAP, lsl #32
    // 0x9667a4: cmp             w0, NULL
    // 0x9667a8: b.eq            #0x966a14
    // 0x9667ac: LoadField: r1 = r0->field_f
    //     0x9667ac: ldur            w1, [x0, #0xf]
    // 0x9667b0: DecompressPointer r1
    //     0x9667b0: add             x1, x1, HEAP, lsl #32
    // 0x9667b4: LoadField: r3 = r1->field_13
    //     0x9667b4: ldur            w3, [x1, #0x13]
    // 0x9667b8: DecompressPointer r3
    //     0x9667b8: add             x3, x3, HEAP, lsl #32
    // 0x9667bc: mov             x0, x3
    // 0x9667c0: StoreField: r2->field_3f = r0
    //     0x9667c0: stur            w0, [x2, #0x3f]
    //     0x9667c4: ldurb           w16, [x2, #-1]
    //     0x9667c8: ldurb           w17, [x0, #-1]
    //     0x9667cc: and             x16, x17, x16, lsr #2
    //     0x9667d0: tst             x16, HEAP, lsr #32
    //     0x9667d4: b.eq            #0x9667dc
    //     0x9667d8: bl              #0xd6828c
    // 0x9667dc: cmp             w3, NULL
    // 0x9667e0: b.eq            #0x966828
    // 0x9667e4: ldur            x16, [fp, #-0xc8]
    // 0x9667e8: stp             x3, x16, [SP, #-0x10]!
    // 0x9667ec: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9667ec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9667f0: r0 = timeout()
    //     0x9667f0: bl              #0xca0a98  ; [dart:async] _Future::timeout
    // 0x9667f4: add             SP, SP, #0x10
    // 0x9667f8: ldur            x2, [fp, #-0xf8]
    // 0x9667fc: r1 = Function '<anonymous closure>':.
    //     0x9667fc: add             x1, PP, #0x30, lsl #12  ; [pp+0x300f8] AnonymousClosure: (0x966e34), in [package:dio/src/dio/dio_for_native.dart] DioForNative::download (0x965f94)
    //     0x966800: ldr             x1, [x1, #0xf8]
    // 0x966804: stur            x0, [fp, #-0xd0]
    // 0x966808: r0 = AllocateClosure()
    //     0x966808: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x96680c: ldur            x16, [fp, #-0xd0]
    // 0x966810: stp             x0, x16, [SP, #-0x10]!
    // 0x966814: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x966814: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x966818: r0 = catchError()
    //     0x966818: bl              #0xca5bb8  ; [dart:async] _Future::catchError
    // 0x96681c: add             SP, SP, #0x10
    // 0x966820: mov             x1, x0
    // 0x966824: b               #0x96682c
    // 0x966828: ldur            x1, [fp, #-0xc8]
    // 0x96682c: ldur            x0, [fp, #-0xf8]
    // 0x966830: LoadField: r2 = r0->field_f
    //     0x966830: ldur            w2, [x0, #0xf]
    // 0x966834: DecompressPointer r2
    //     0x966834: add             x2, x2, HEAP, lsl #32
    // 0x966838: r16 = <Response>
    //     0x966838: add             x16, PP, #0x12, lsl #12  ; [pp+0x12f70] TypeArguments: <Response>
    //     0x96683c: ldr             x16, [x16, #0xf70]
    // 0x966840: stp             x2, x16, [SP, #-0x10]!
    // 0x966844: SaveReg r1
    //     0x966844: str             x1, [SP, #-8]!
    // 0x966848: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x966848: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x96684c: r0 = listenCancelForAsyncTask()
    //     0x96684c: bl              #0x5282ac  ; [package:dio/src/dio_mixin.dart] DioMixin::listenCancelForAsyncTask
    // 0x966850: add             SP, SP, #0x18
    // 0x966854: r0 = ReturnAsync()
    //     0x966854: b               #0x501858  ; ReturnAsyncStub
    // 0x966858: sub             SP, fp, #0xf8
    // 0x96685c: mov             x4, x0
    // 0x966860: mov             x3, x1
    // 0x966864: stur            x0, [fp, #-0xe8]
    // 0x966868: stur            x1, [fp, #-0xf0]
    // 0x96686c: r0 = LoadTaggedClassIdMayBeSmiInstr(r4)
    //     0x96686c: mov             x0, #0x76
    //     0x966870: tbz             w4, #0, #0x966880
    //     0x966874: ldur            x0, [x4, #-1]
    //     0x966878: ubfx            x0, x0, #0xc, #0x14
    //     0x96687c: lsl             x0, x0, #1
    // 0x966880: r17 = 9088
    //     0x966880: mov             x17, #0x2380
    // 0x966884: cmp             w0, w17
    // 0x966888: b.ne            #0x9669e4
    // 0x96688c: LoadField: r0 = r4->field_b
    //     0x96688c: ldur            w0, [x4, #0xb]
    // 0x966890: DecompressPointer r0
    //     0x966890: add             x0, x0, HEAP, lsl #32
    // 0x966894: r16 = Instance_DioExceptionType
    //     0x966894: add             x16, PP, #0x12, lsl #12  ; [pp+0x12d78] Obj!DioExceptionType@b66691
    //     0x966898: ldr             x16, [x16, #0xd78]
    // 0x96689c: cmp             w0, w16
    // 0x9668a0: b.ne            #0x9669d4
    // 0x9668a4: ldur            x1, [fp, #-0x10]
    // 0x9668a8: r0 = Instance_ResponseType
    //     0x9668a8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12e08] Obj!ResponseType@b66531
    //     0x9668ac: ldr             x0, [x0, #0xe08]
    // 0x9668b0: LoadField: r5 = r4->field_7
    //     0x9668b0: ldur            w5, [x4, #7]
    // 0x9668b4: DecompressPointer r5
    //     0x9668b4: add             x5, x5, HEAP, lsl #32
    // 0x9668b8: stur            x5, [fp, #-0xe0]
    // 0x9668bc: cmp             w5, NULL
    // 0x9668c0: b.eq            #0x966a18
    // 0x9668c4: LoadField: r6 = r5->field_f
    //     0x9668c4: ldur            w6, [x5, #0xf]
    // 0x9668c8: DecompressPointer r6
    //     0x9668c8: add             x6, x6, HEAP, lsl #32
    // 0x9668cc: stur            x6, [fp, #-0xd8]
    // 0x9668d0: LoadField: r2 = r6->field_23
    //     0x9668d0: ldur            w2, [x6, #0x23]
    // 0x9668d4: DecompressPointer r2
    //     0x9668d4: add             x2, x2, HEAP, lsl #32
    // 0x9668d8: r16 = Sentinel
    //     0x9668d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9668dc: cmp             w2, w16
    // 0x9668e0: b.eq            #0x966a1c
    // 0x9668e4: LoadField: r7 = r1->field_13
    //     0x9668e4: ldur            w7, [x1, #0x13]
    // 0x9668e8: DecompressPointer r7
    //     0x9668e8: add             x7, x7, HEAP, lsl #32
    // 0x9668ec: stur            x7, [fp, #-0xd0]
    // 0x9668f0: StoreField: r6->field_1b = r0
    //     0x9668f0: stur            w0, [x6, #0x1b]
    // 0x9668f4: LoadField: r8 = r5->field_b
    //     0x9668f4: ldur            w8, [x5, #0xb]
    // 0x9668f8: DecompressPointer r8
    //     0x9668f8: add             x8, x8, HEAP, lsl #32
    // 0x9668fc: mov             x0, x8
    // 0x966900: stur            x8, [fp, #-0xc8]
    // 0x966904: r2 = Null
    //     0x966904: mov             x2, NULL
    // 0x966908: r1 = Null
    //     0x966908: mov             x1, NULL
    // 0x96690c: r4 = 59
    //     0x96690c: mov             x4, #0x3b
    // 0x966910: branchIfSmi(r0, 0x96691c)
    //     0x966910: tbz             w0, #0, #0x96691c
    // 0x966914: r4 = LoadClassIdInstr(r0)
    //     0x966914: ldur            x4, [x0, #-1]
    //     0x966918: ubfx            x4, x4, #0xc, #0x14
    // 0x96691c: r17 = 4552
    //     0x96691c: mov             x17, #0x11c8
    // 0x966920: cmp             x4, x17
    // 0x966924: b.eq            #0x96693c
    // 0x966928: r8 = ResponseBody
    //     0x966928: add             x8, PP, #0x30, lsl #12  ; [pp+0x30100] Type: ResponseBody
    //     0x96692c: ldr             x8, [x8, #0x100]
    // 0x966930: r3 = Null
    //     0x966930: add             x3, PP, #0x30, lsl #12  ; [pp+0x30108] Null
    //     0x966934: ldr             x3, [x3, #0x108]
    // 0x966938: r0 = ResponseBody()
    //     0x966938: bl              #0x52fb84  ; IsType_ResponseBody_Stub
    // 0x96693c: ldur            x16, [fp, #-0xd0]
    // 0x966940: ldur            lr, [fp, #-0xd8]
    // 0x966944: stp             lr, x16, [SP, #-0x10]!
    // 0x966948: ldur            x16, [fp, #-0xc8]
    // 0x96694c: SaveReg r16
    //     0x96694c: str             x16, [SP, #-8]!
    // 0x966950: r0 = transformResponse()
    //     0x966950: bl              #0x52ae28  ; [package:dio/src/transformers/sync_transformer.dart] SyncTransformer::transformResponse
    // 0x966954: add             SP, SP, #0x18
    // 0x966958: mov             x1, x0
    // 0x96695c: stur            x1, [fp, #-0xc8]
    // 0x966960: r0 = Await()
    //     0x966960: bl              #0x4b8e6c  ; AwaitStub
    // 0x966964: mov             x4, x0
    // 0x966968: ldur            x3, [fp, #-0xe0]
    // 0x96696c: stur            x4, [fp, #-0xc8]
    // 0x966970: LoadField: r2 = r3->field_7
    //     0x966970: ldur            w2, [x3, #7]
    // 0x966974: DecompressPointer r2
    //     0x966974: add             x2, x2, HEAP, lsl #32
    // 0x966978: mov             x0, x4
    // 0x96697c: r1 = Null
    //     0x96697c: mov             x1, NULL
    // 0x966980: cmp             w0, NULL
    // 0x966984: b.eq            #0x9669ac
    // 0x966988: cmp             w2, NULL
    // 0x96698c: b.eq            #0x9669ac
    // 0x966990: LoadField: r4 = r2->field_17
    //     0x966990: ldur            w4, [x2, #0x17]
    // 0x966994: DecompressPointer r4
    //     0x966994: add             x4, x4, HEAP, lsl #32
    // 0x966998: r8 = X0?
    //     0x966998: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0x96699c: LoadField: r9 = r4->field_7
    //     0x96699c: ldur            x9, [x4, #7]
    // 0x9669a0: r3 = Null
    //     0x9669a0: add             x3, PP, #0x30, lsl #12  ; [pp+0x30118] Null
    //     0x9669a4: ldr             x3, [x3, #0x118]
    // 0x9669a8: blr             x9
    // 0x9669ac: ldur            x0, [fp, #-0xc8]
    // 0x9669b0: ldur            x1, [fp, #-0xe0]
    // 0x9669b4: StoreField: r1->field_b = r0
    //     0x9669b4: stur            w0, [x1, #0xb]
    //     0x9669b8: tbz             w0, #0, #0x9669d4
    //     0x9669bc: ldurb           w16, [x1, #-1]
    //     0x9669c0: ldurb           w17, [x0, #-1]
    //     0x9669c4: and             x16, x17, x16, lsr #2
    //     0x9669c8: tst             x16, HEAP, lsr #32
    //     0x9669cc: b.eq            #0x9669d4
    //     0x9669d0: bl              #0xd6826c
    // 0x9669d4: ldur            x0, [fp, #-0xe8]
    // 0x9669d8: ldur            x1, [fp, #-0xf0]
    // 0x9669dc: r0 = ReThrow()
    //     0x9669dc: bl              #0xd67e14  ; ReThrowStub
    // 0x9669e0: brk             #0
    // 0x9669e4: ldur            x0, [fp, #-0xe8]
    // 0x9669e8: ldur            x1, [fp, #-0xf0]
    // 0x9669ec: r0 = ReThrow()
    //     0x9669ec: bl              #0xd67e14  ; ReThrowStub
    // 0x9669f0: brk             #0
    // 0x9669f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9669f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9669f8: b               #0x966078
    // 0x9669fc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x9669fc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x966a00: r0 = NullErrorSharedWithoutFPURegs()
    //     0x966a00: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x966a04: r0 = NullErrorSharedWithoutFPURegs()
    //     0x966a04: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x966a08: r0 = NullErrorSharedWithoutFPURegs()
    //     0x966a08: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x966a0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x966a0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x966a10: r0 = NullErrorSharedWithoutFPURegs()
    //     0x966a10: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x966a14: r0 = NullErrorSharedWithoutFPURegs()
    //     0x966a14: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x966a18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x966a18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x966a1c: r9 = receiveDataWhenStatusError
    //     0x966a1c: add             x9, PP, #0x13, lsl #12  ; [pp+0x13140] Field <_RequestConfig@361184022.receiveDataWhenStatusError>: late (offset: 0x24)
    //     0x966a20: ldr             x9, [x9, #0x140]
    // 0x966a24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x966a24: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<Never> <anonymous closure>(dynamic, dynamic, StackTrace) async {
    // ** addr: 0x966e34, size: 0x158
    // 0x966e34: EnterFrame
    //     0x966e34: stp             fp, lr, [SP, #-0x10]!
    //     0x966e38: mov             fp, SP
    // 0x966e3c: AllocStack(0x20)
    //     0x966e3c: sub             SP, SP, #0x20
    // 0x966e40: SetupParameters(DioForNative this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x966e40: stur            NULL, [fp, #-8]
    //     0x966e44: mov             x0, #0
    //     0x966e48: add             x1, fp, w0, sxtw #2
    //     0x966e4c: ldr             x1, [x1, #0x20]
    //     0x966e50: add             x2, fp, w0, sxtw #2
    //     0x966e54: ldr             x2, [x2, #0x18]
    //     0x966e58: stur            x2, [fp, #-0x18]
    //     0x966e5c: ldur            w3, [x1, #0x17]
    //     0x966e60: add             x3, x3, HEAP, lsl #32
    //     0x966e64: stur            x3, [fp, #-0x10]
    // 0x966e68: CheckStackOverflow
    //     0x966e68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x966e6c: cmp             SP, x16
    //     0x966e70: b.ls            #0x966f80
    // 0x966e74: InitAsync() -> Future<Never>
    //     0x966e74: ldr             x0, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    //     0x966e78: bl              #0x4b92e4
    // 0x966e7c: ldur            x0, [fp, #-0x10]
    // 0x966e80: LoadField: r1 = r0->field_3b
    //     0x966e80: ldur            w1, [x0, #0x3b]
    // 0x966e84: DecompressPointer r1
    //     0x966e84: add             x1, x1, HEAP, lsl #32
    // 0x966e88: r16 = Sentinel
    //     0x966e88: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x966e8c: cmp             w1, w16
    // 0x966e90: b.ne            #0x966ea8
    // 0x966e94: r16 = "subscription"
    //     0x966e94: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d58] "subscription"
    //     0x966e98: ldr             x16, [x16, #0xd58]
    // 0x966e9c: SaveReg r16
    //     0x966e9c: str             x16, [SP, #-8]!
    // 0x966ea0: r0 = _throwLocalNotInitialized()
    //     0x966ea0: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x966ea4: add             SP, SP, #8
    // 0x966ea8: ldur            x2, [fp, #-0x18]
    // 0x966eac: ldur            x1, [fp, #-0x10]
    // 0x966eb0: LoadField: r0 = r1->field_3b
    //     0x966eb0: ldur            w0, [x1, #0x3b]
    // 0x966eb4: DecompressPointer r0
    //     0x966eb4: add             x0, x0, HEAP, lsl #32
    // 0x966eb8: r3 = LoadClassIdInstr(r0)
    //     0x966eb8: ldur            x3, [x0, #-1]
    //     0x966ebc: ubfx            x3, x3, #0xc, #0x14
    // 0x966ec0: SaveReg r0
    //     0x966ec0: str             x0, [SP, #-8]!
    // 0x966ec4: mov             x0, x3
    // 0x966ec8: r0 = GDT[cid_x0 + 0x307]()
    //     0x966ec8: add             lr, x0, #0x307
    //     0x966ecc: ldr             lr, [x21, lr, lsl #3]
    //     0x966ed0: blr             lr
    // 0x966ed4: add             SP, SP, #8
    // 0x966ed8: mov             x1, x0
    // 0x966edc: stur            x1, [fp, #-0x20]
    // 0x966ee0: r0 = Await()
    //     0x966ee0: bl              #0x4b8e6c  ; AwaitStub
    // 0x966ee4: ldur            x1, [fp, #-0x10]
    // 0x966ee8: LoadField: r0 = r1->field_37
    //     0x966ee8: ldur            w0, [x1, #0x37]
    // 0x966eec: DecompressPointer r0
    //     0x966eec: add             x0, x0, HEAP, lsl #32
    // 0x966ef0: SaveReg r0
    //     0x966ef0: str             x0, [SP, #-8]!
    // 0x966ef4: ClosureCall
    //     0x966ef4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x966ef8: ldur            x2, [x0, #0x1f]
    //     0x966efc: blr             x2
    // 0x966f00: add             SP, SP, #8
    // 0x966f04: mov             x1, x0
    // 0x966f08: stur            x1, [fp, #-0x20]
    // 0x966f0c: r0 = Await()
    //     0x966f0c: bl              #0x4b8e6c  ; AwaitStub
    // 0x966f10: ldur            x0, [fp, #-0x18]
    // 0x966f14: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x966f14: mov             x1, #0x76
    //     0x966f18: tbz             w0, #0, #0x966f28
    //     0x966f1c: ldur            x1, [x0, #-1]
    //     0x966f20: ubfx            x1, x1, #0xc, #0x14
    //     0x966f24: lsl             x1, x1, #1
    // 0x966f28: r17 = 11332
    //     0x966f28: mov             x17, #0x2c44
    // 0x966f2c: cmp             w1, w17
    // 0x966f30: b.ne            #0x966f78
    // 0x966f34: ldur            x1, [fp, #-0x10]
    // 0x966f38: LoadField: r2 = r1->field_17
    //     0x966f38: ldur            w2, [x1, #0x17]
    // 0x966f3c: DecompressPointer r2
    //     0x966f3c: add             x2, x2, HEAP, lsl #32
    // 0x966f40: cmp             w2, NULL
    // 0x966f44: b.eq            #0x966f88
    // 0x966f48: LoadField: r3 = r2->field_f
    //     0x966f48: ldur            w3, [x2, #0xf]
    // 0x966f4c: DecompressPointer r3
    //     0x966f4c: add             x3, x3, HEAP, lsl #32
    // 0x966f50: LoadField: r2 = r1->field_3f
    //     0x966f50: ldur            w2, [x1, #0x3f]
    // 0x966f54: DecompressPointer r2
    //     0x966f54: add             x2, x2, HEAP, lsl #32
    // 0x966f58: stp             x3, NULL, [SP, #-0x10]!
    // 0x966f5c: stp             x0, x2, [SP, #-0x10]!
    // 0x966f60: r4 = const [0, 0x4, 0x4, 0x3, error, 0x3, null]
    //     0x966f60: add             x4, PP, #0x13, lsl #12  ; [pp+0x13450] List(7) [0, 0x4, 0x4, 0x3, "error", 0x3, Null]
    //     0x966f64: ldr             x4, [x4, #0x450]
    // 0x966f68: r0 = DioException.receiveTimeout()
    //     0x966f68: bl              #0x556c64  ; [package:dio/src/dio_exception.dart] DioException::DioException.receiveTimeout
    // 0x966f6c: add             SP, SP, #0x20
    // 0x966f70: r0 = Throw()
    //     0x966f70: bl              #0xd67e38  ; ThrowStub
    // 0x966f74: brk             #0
    // 0x966f78: r0 = Throw()
    //     0x966f78: bl              #0xd67e38  ; ThrowStub
    // 0x966f7c: brk             #0
    // 0x966f80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x966f80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x966f84: b               #0x966e74
    // 0x966f88: r0 = NullErrorSharedWithoutFPURegs()
    //     0x966f88: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] Future<Null> <anonymous closure>(dynamic, DioException) async {
    // ** addr: 0x966f8c, size: 0xdc
    // 0x966f8c: EnterFrame
    //     0x966f8c: stp             fp, lr, [SP, #-0x10]!
    //     0x966f90: mov             fp, SP
    // 0x966f94: AllocStack(0x18)
    //     0x966f94: sub             SP, SP, #0x18
    // 0x966f98: SetupParameters(DioForNative this /* r1 */)
    //     0x966f98: stur            NULL, [fp, #-8]
    //     0x966f9c: mov             x0, #0
    //     0x966fa0: add             x1, fp, w0, sxtw #2
    //     0x966fa4: ldr             x1, [x1, #0x18]
    //     0x966fa8: ldur            w2, [x1, #0x17]
    //     0x966fac: add             x2, x2, HEAP, lsl #32
    //     0x966fb0: stur            x2, [fp, #-0x10]
    // 0x966fb4: CheckStackOverflow
    //     0x966fb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x966fb8: cmp             SP, x16
    //     0x966fbc: b.ls            #0x967060
    // 0x966fc0: InitAsync() -> Future<Null?>
    //     0x966fc0: ldr             x0, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    //     0x966fc4: bl              #0x4b92e4
    // 0x966fc8: ldur            x0, [fp, #-0x10]
    // 0x966fcc: LoadField: r1 = r0->field_3b
    //     0x966fcc: ldur            w1, [x0, #0x3b]
    // 0x966fd0: DecompressPointer r1
    //     0x966fd0: add             x1, x1, HEAP, lsl #32
    // 0x966fd4: r16 = Sentinel
    //     0x966fd4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x966fd8: cmp             w1, w16
    // 0x966fdc: b.ne            #0x966ff4
    // 0x966fe0: r16 = "subscription"
    //     0x966fe0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d58] "subscription"
    //     0x966fe4: ldr             x16, [x16, #0xd58]
    // 0x966fe8: SaveReg r16
    //     0x966fe8: str             x16, [SP, #-8]!
    // 0x966fec: r0 = _throwLocalNotInitialized()
    //     0x966fec: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x966ff0: add             SP, SP, #8
    // 0x966ff4: ldur            x1, [fp, #-0x10]
    // 0x966ff8: LoadField: r0 = r1->field_3b
    //     0x966ff8: ldur            w0, [x1, #0x3b]
    // 0x966ffc: DecompressPointer r0
    //     0x966ffc: add             x0, x0, HEAP, lsl #32
    // 0x967000: r2 = LoadClassIdInstr(r0)
    //     0x967000: ldur            x2, [x0, #-1]
    //     0x967004: ubfx            x2, x2, #0xc, #0x14
    // 0x967008: SaveReg r0
    //     0x967008: str             x0, [SP, #-8]!
    // 0x96700c: mov             x0, x2
    // 0x967010: r0 = GDT[cid_x0 + 0x307]()
    //     0x967010: add             lr, x0, #0x307
    //     0x967014: ldr             lr, [x21, lr, lsl #3]
    //     0x967018: blr             lr
    // 0x96701c: add             SP, SP, #8
    // 0x967020: mov             x1, x0
    // 0x967024: stur            x1, [fp, #-0x18]
    // 0x967028: r0 = Await()
    //     0x967028: bl              #0x4b8e6c  ; AwaitStub
    // 0x96702c: ldur            x1, [fp, #-0x10]
    // 0x967030: LoadField: r0 = r1->field_37
    //     0x967030: ldur            w0, [x1, #0x37]
    // 0x967034: DecompressPointer r0
    //     0x967034: add             x0, x0, HEAP, lsl #32
    // 0x967038: SaveReg r0
    //     0x967038: str             x0, [SP, #-8]!
    // 0x96703c: ClosureCall
    //     0x96703c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x967040: ldur            x2, [x0, #0x1f]
    //     0x967044: blr             x2
    // 0x967048: add             SP, SP, #8
    // 0x96704c: mov             x1, x0
    // 0x967050: stur            x1, [fp, #-0x18]
    // 0x967054: r0 = Await()
    //     0x967054: bl              #0x4b8e6c  ; AwaitStub
    // 0x967058: r0 = Null
    //     0x967058: mov             x0, NULL
    // 0x96705c: r0 = ReturnAsyncNotFuture()
    //     0x96705c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x967060: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x967060: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x967064: b               #0x966fc0
  }
  [closure] Future<Null> <anonymous closure>(dynamic, dynamic) async {
    // ** addr: 0x967068, size: 0x1bc
    // 0x967068: EnterFrame
    //     0x967068: stp             fp, lr, [SP, #-0x10]!
    //     0x96706c: mov             fp, SP
    // 0x967070: AllocStack(0x68)
    //     0x967070: sub             SP, SP, #0x68
    // 0x967074: SetupParameters(DioForNative this /* r1, fp-0x68 */, dynamic _ /* r2, fp-0x60 */)
    //     0x967074: stur            NULL, [fp, #-8]
    //     0x967078: mov             x0, #0
    //     0x96707c: add             x1, fp, w0, sxtw #2
    //     0x967080: ldr             x1, [x1, #0x18]
    //     0x967084: stur            x1, [fp, #-0x68]
    //     0x967088: add             x2, fp, w0, sxtw #2
    //     0x96708c: ldr             x2, [x2, #0x10]
    //     0x967090: stur            x2, [fp, #-0x60]
    //     0x967094: ldur            w3, [x1, #0x17]
    //     0x967098: add             x3, x3, HEAP, lsl #32
    //     0x96709c: stur            x3, [fp, #-0x58]
    // 0x9670a0: CheckStackOverflow
    //     0x9670a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9670a4: cmp             SP, x16
    //     0x9670a8: b.ls            #0x967214
    // 0x9670ac: InitAsync() -> Future<Null?>
    //     0x9670ac: ldr             x0, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    //     0x9670b0: bl              #0x4b92e4
    // 0x9670b4: ldur            x1, [fp, #-0x58]
    // 0x9670b8: LoadField: r2 = r1->field_37
    //     0x9670b8: ldur            w2, [x1, #0x37]
    // 0x9670bc: DecompressPointer r2
    //     0x9670bc: add             x2, x2, HEAP, lsl #32
    // 0x9670c0: stur            x2, [fp, #-0x68]
    // 0x9670c4: SaveReg r2
    //     0x9670c4: str             x2, [SP, #-8]!
    // 0x9670c8: mov             x0, x2
    // 0x9670cc: ClosureCall
    //     0x9670cc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x9670d0: ldur            x2, [x0, #0x1f]
    //     0x9670d4: blr             x2
    // 0x9670d8: add             SP, SP, #8
    // 0x9670dc: mov             x1, x0
    // 0x9670e0: stur            x1, [fp, #-0x68]
    // 0x9670e4: r0 = Await()
    //     0x9670e4: bl              #0x4b8e6c  ; AwaitStub
    // 0x9670e8: ldur            x4, [fp, #-0x60]
    // 0x9670ec: ldur            x3, [fp, #-0x58]
    // 0x9670f0: LoadField: r5 = r3->field_23
    //     0x9670f0: ldur            w5, [x3, #0x23]
    // 0x9670f4: DecompressPointer r5
    //     0x9670f4: add             x5, x5, HEAP, lsl #32
    // 0x9670f8: stur            x5, [fp, #-0x68]
    // 0x9670fc: cmp             w4, NULL
    // 0x967100: b.ne            #0x967128
    // 0x967104: mov             x0, x4
    // 0x967108: r2 = Null
    //     0x967108: mov             x2, NULL
    // 0x96710c: r1 = Null
    //     0x96710c: mov             x1, NULL
    // 0x967110: cmp             w0, NULL
    // 0x967114: b.ne            #0x967128
    // 0x967118: r8 = Object
    //     0x967118: ldr             x8, [PP, #0x3408]  ; [pp+0x3408] Type: Object
    // 0x96711c: r3 = Null
    //     0x96711c: add             x3, PP, #0x30, lsl #12  ; [pp+0x30140] Null
    //     0x967120: ldr             x3, [x3, #0x140]
    // 0x967124: r0 = Object()
    //     0x967124: bl              #0xd74634  ; IsType_Object_Stub
    // 0x967128: ldur            x0, [fp, #-0x58]
    // 0x96712c: LoadField: r1 = r0->field_17
    //     0x96712c: ldur            w1, [x0, #0x17]
    // 0x967130: DecompressPointer r1
    //     0x967130: add             x1, x1, HEAP, lsl #32
    // 0x967134: cmp             w1, NULL
    // 0x967138: b.eq            #0x96721c
    // 0x96713c: LoadField: r0 = r1->field_f
    //     0x96713c: ldur            w0, [x1, #0xf]
    // 0x967140: DecompressPointer r0
    //     0x967140: add             x0, x0, HEAP, lsl #32
    // 0x967144: ldur            x16, [fp, #-0x60]
    // 0x967148: stp             x0, x16, [SP, #-0x10]!
    // 0x96714c: r0 = assureDioException()
    //     0x96714c: bl              #0x528ea4  ; [package:dio/src/dio_mixin.dart] DioMixin::assureDioException
    // 0x967150: add             SP, SP, #0x10
    // 0x967154: ldur            x16, [fp, #-0x68]
    // 0x967158: stp             x0, x16, [SP, #-0x10]!
    // 0x96715c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x96715c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x967160: r0 = completeError()
    //     0x967160: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0x967164: add             SP, SP, #0x10
    // 0x967168: r0 = Null
    //     0x967168: mov             x0, NULL
    // 0x96716c: r0 = ReturnAsyncNotFuture()
    //     0x96716c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x967170: sub             SP, fp, #0x68
    // 0x967174: ldur            x5, [fp, #-0x28]
    // 0x967178: mov             x4, x0
    // 0x96717c: mov             x3, x1
    // 0x967180: stur            x0, [fp, #-0x60]
    // 0x967184: stur            x1, [fp, #-0x68]
    // 0x967188: LoadField: r6 = r5->field_23
    //     0x967188: ldur            w6, [x5, #0x23]
    // 0x96718c: DecompressPointer r6
    //     0x96718c: add             x6, x6, HEAP, lsl #32
    // 0x967190: ldur            x7, [fp, #-0x18]
    // 0x967194: stur            x6, [fp, #-0x58]
    // 0x967198: cmp             w7, NULL
    // 0x96719c: b.ne            #0x9671c4
    // 0x9671a0: mov             x0, x7
    // 0x9671a4: r2 = Null
    //     0x9671a4: mov             x2, NULL
    // 0x9671a8: r1 = Null
    //     0x9671a8: mov             x1, NULL
    // 0x9671ac: cmp             w0, NULL
    // 0x9671b0: b.ne            #0x9671c4
    // 0x9671b4: r8 = Object
    //     0x9671b4: ldr             x8, [PP, #0x3408]  ; [pp+0x3408] Type: Object
    // 0x9671b8: r3 = Null
    //     0x9671b8: add             x3, PP, #0x30, lsl #12  ; [pp+0x30150] Null
    //     0x9671bc: ldr             x3, [x3, #0x150]
    // 0x9671c0: r0 = Object()
    //     0x9671c0: bl              #0xd74634  ; IsType_Object_Stub
    // 0x9671c4: ldur            x0, [fp, #-0x28]
    // 0x9671c8: LoadField: r1 = r0->field_17
    //     0x9671c8: ldur            w1, [x0, #0x17]
    // 0x9671cc: DecompressPointer r1
    //     0x9671cc: add             x1, x1, HEAP, lsl #32
    // 0x9671d0: cmp             w1, NULL
    // 0x9671d4: b.eq            #0x967220
    // 0x9671d8: LoadField: r0 = r1->field_f
    //     0x9671d8: ldur            w0, [x1, #0xf]
    // 0x9671dc: DecompressPointer r0
    //     0x9671dc: add             x0, x0, HEAP, lsl #32
    // 0x9671e0: ldur            x16, [fp, #-0x18]
    // 0x9671e4: stp             x0, x16, [SP, #-0x10]!
    // 0x9671e8: r0 = assureDioException()
    //     0x9671e8: bl              #0x528ea4  ; [package:dio/src/dio_mixin.dart] DioMixin::assureDioException
    // 0x9671ec: add             SP, SP, #0x10
    // 0x9671f0: ldur            x16, [fp, #-0x58]
    // 0x9671f4: stp             x0, x16, [SP, #-0x10]!
    // 0x9671f8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9671f8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9671fc: r0 = completeError()
    //     0x9671fc: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0x967200: add             SP, SP, #0x10
    // 0x967204: ldur            x0, [fp, #-0x60]
    // 0x967208: ldur            x1, [fp, #-0x68]
    // 0x96720c: r0 = ReThrow()
    //     0x96720c: bl              #0xd67e14  ; ReThrowStub
    // 0x967210: brk             #0
    // 0x967214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x967214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x967218: b               #0x9670ac
    // 0x96721c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x96721c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x967220: r0 = NullErrorSharedWithoutFPURegs()
    //     0x967220: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x967224, size: 0x10c
    // 0x967224: EnterFrame
    //     0x967224: stp             fp, lr, [SP, #-0x10]!
    //     0x967228: mov             fp, SP
    // 0x96722c: AllocStack(0x50)
    //     0x96722c: sub             SP, SP, #0x50
    // 0x967230: SetupParameters(DioForNative this /* r1, fp-0x50 */)
    //     0x967230: stur            NULL, [fp, #-8]
    //     0x967234: mov             x0, #0
    //     0x967238: add             x1, fp, w0, sxtw #2
    //     0x96723c: ldr             x1, [x1, #0x10]
    //     0x967240: stur            x1, [fp, #-0x50]
    //     0x967244: ldur            w2, [x1, #0x17]
    //     0x967248: add             x2, x2, HEAP, lsl #32
    //     0x96724c: stur            x2, [fp, #-0x48]
    // 0x967250: CheckStackOverflow
    //     0x967250: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x967254: cmp             SP, x16
    //     0x967258: b.ls            #0x967324
    // 0x96725c: InitAsync() -> Future<void?>
    //     0x96725c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x967260: bl              #0x4b92e4
    // 0x967264: ldur            x1, [fp, #-0x48]
    // 0x967268: LoadField: r2 = r1->field_2f
    //     0x967268: ldur            w2, [x1, #0x2f]
    // 0x96726c: DecompressPointer r2
    //     0x96726c: add             x2, x2, HEAP, lsl #32
    // 0x967270: mov             x0, x2
    // 0x967274: stur            x2, [fp, #-0x50]
    // 0x967278: r0 = Await()
    //     0x967278: bl              #0x4b8e6c  ; AwaitStub
    // 0x96727c: ldur            x0, [fp, #-0x48]
    // 0x967280: r1 = true
    //     0x967280: add             x1, NULL, #0x20  ; true
    // 0x967284: StoreField: r0->field_33 = r1
    //     0x967284: stur            w1, [x0, #0x33]
    // 0x967288: LoadField: r1 = r0->field_1f
    //     0x967288: ldur            w1, [x0, #0x1f]
    // 0x96728c: DecompressPointer r1
    //     0x96728c: add             x1, x1, HEAP, lsl #32
    // 0x967290: SaveReg r1
    //     0x967290: str             x1, [SP, #-8]!
    // 0x967294: r0 = close()
    //     0x967294: bl              #0x967330  ; [dart:io] _RandomAccessFile::close
    // 0x967298: add             SP, SP, #8
    // 0x96729c: mov             x1, x0
    // 0x9672a0: stur            x1, [fp, #-0x50]
    // 0x9672a4: r0 = Await()
    //     0x9672a4: bl              #0x4b8e6c  ; AwaitStub
    // 0x9672a8: ldur            x0, [fp, #-0x48]
    // 0x9672ac: LoadField: r1 = r0->field_23
    //     0x9672ac: ldur            w1, [x0, #0x23]
    // 0x9672b0: DecompressPointer r1
    //     0x9672b0: add             x1, x1, HEAP, lsl #32
    // 0x9672b4: LoadField: r2 = r0->field_17
    //     0x9672b4: ldur            w2, [x0, #0x17]
    // 0x9672b8: DecompressPointer r2
    //     0x9672b8: add             x2, x2, HEAP, lsl #32
    // 0x9672bc: stp             x2, x1, [SP, #-0x10]!
    // 0x9672c0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9672c0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9672c4: r0 = complete()
    //     0x9672c4: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x9672c8: add             SP, SP, #0x10
    // 0x9672cc: b               #0x96731c
    // 0x9672d0: sub             SP, fp, #0x50
    // 0x9672d4: ldur            x1, [fp, #-0x20]
    // 0x9672d8: LoadField: r2 = r1->field_23
    //     0x9672d8: ldur            w2, [x1, #0x23]
    // 0x9672dc: DecompressPointer r2
    //     0x9672dc: add             x2, x2, HEAP, lsl #32
    // 0x9672e0: stur            x2, [fp, #-0x48]
    // 0x9672e4: LoadField: r3 = r1->field_17
    //     0x9672e4: ldur            w3, [x1, #0x17]
    // 0x9672e8: DecompressPointer r3
    //     0x9672e8: add             x3, x3, HEAP, lsl #32
    // 0x9672ec: cmp             w3, NULL
    // 0x9672f0: b.eq            #0x96732c
    // 0x9672f4: LoadField: r1 = r3->field_f
    //     0x9672f4: ldur            w1, [x3, #0xf]
    // 0x9672f8: DecompressPointer r1
    //     0x9672f8: add             x1, x1, HEAP, lsl #32
    // 0x9672fc: stp             x1, x0, [SP, #-0x10]!
    // 0x967300: r0 = assureDioException()
    //     0x967300: bl              #0x528ea4  ; [package:dio/src/dio_mixin.dart] DioMixin::assureDioException
    // 0x967304: add             SP, SP, #0x10
    // 0x967308: ldur            x16, [fp, #-0x48]
    // 0x96730c: stp             x0, x16, [SP, #-0x10]!
    // 0x967310: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x967310: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x967314: r0 = completeError()
    //     0x967314: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0x967318: add             SP, SP, #0x10
    // 0x96731c: r0 = Null
    //     0x96731c: mov             x0, NULL
    // 0x967320: r0 = ReturnAsyncNotFuture()
    //     0x967320: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x967324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x967324: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x967328: b               #0x96725c
    // 0x96732c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x96732c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Uint8List) {
    // ** addr: 0x967570, size: 0x160
    // 0x967570: EnterFrame
    //     0x967570: stp             fp, lr, [SP, #-0x10]!
    //     0x967574: mov             fp, SP
    // 0x967578: AllocStack(0x18)
    //     0x967578: sub             SP, SP, #0x18
    // 0x96757c: SetupParameters()
    //     0x96757c: ldr             x0, [fp, #0x18]
    //     0x967580: ldur            w1, [x0, #0x17]
    //     0x967584: add             x1, x1, HEAP, lsl #32
    //     0x967588: stur            x1, [fp, #-8]
    // 0x96758c: CheckStackOverflow
    //     0x96758c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x967590: cmp             SP, x16
    //     0x967594: b.ls            #0x9676c8
    // 0x967598: r1 = 1
    //     0x967598: mov             x1, #1
    // 0x96759c: r0 = AllocateContext()
    //     0x96759c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9675a0: mov             x1, x0
    // 0x9675a4: ldur            x0, [fp, #-8]
    // 0x9675a8: stur            x1, [fp, #-0x10]
    // 0x9675ac: StoreField: r1->field_b = r0
    //     0x9675ac: stur            w0, [x1, #0xb]
    // 0x9675b0: ldr             x2, [fp, #0x10]
    // 0x9675b4: StoreField: r1->field_f = r2
    //     0x9675b4: stur            w2, [x1, #0xf]
    // 0x9675b8: LoadField: r2 = r0->field_3b
    //     0x9675b8: ldur            w2, [x0, #0x3b]
    // 0x9675bc: DecompressPointer r2
    //     0x9675bc: add             x2, x2, HEAP, lsl #32
    // 0x9675c0: r16 = Sentinel
    //     0x9675c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9675c4: cmp             w2, w16
    // 0x9675c8: b.ne            #0x9675e0
    // 0x9675cc: r16 = "subscription"
    //     0x9675cc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d58] "subscription"
    //     0x9675d0: ldr             x16, [x16, #0xd58]
    // 0x9675d4: SaveReg r16
    //     0x9675d4: str             x16, [SP, #-8]!
    // 0x9675d8: r0 = _throwLocalNotInitialized()
    //     0x9675d8: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x9675dc: add             SP, SP, #8
    // 0x9675e0: ldur            x1, [fp, #-8]
    // 0x9675e4: ldur            x2, [fp, #-0x10]
    // 0x9675e8: LoadField: r0 = r1->field_3b
    //     0x9675e8: ldur            w0, [x1, #0x3b]
    // 0x9675ec: DecompressPointer r0
    //     0x9675ec: add             x0, x0, HEAP, lsl #32
    // 0x9675f0: r3 = LoadClassIdInstr(r0)
    //     0x9675f0: ldur            x3, [x0, #-1]
    //     0x9675f4: ubfx            x3, x3, #0xc, #0x14
    // 0x9675f8: SaveReg r0
    //     0x9675f8: str             x0, [SP, #-8]!
    // 0x9675fc: mov             x0, x3
    // 0x967600: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x967600: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x967604: r0 = GDT[cid_x0 + 0x3a6]()
    //     0x967604: add             lr, x0, #0x3a6
    //     0x967608: ldr             lr, [x21, lr, lsl #3]
    //     0x96760c: blr             lr
    // 0x967610: add             SP, SP, #8
    // 0x967614: ldur            x0, [fp, #-8]
    // 0x967618: LoadField: r1 = r0->field_1f
    //     0x967618: ldur            w1, [x0, #0x1f]
    // 0x96761c: DecompressPointer r1
    //     0x96761c: add             x1, x1, HEAP, lsl #32
    // 0x967620: ldur            x2, [fp, #-0x10]
    // 0x967624: LoadField: r3 = r2->field_f
    //     0x967624: ldur            w3, [x2, #0xf]
    // 0x967628: DecompressPointer r3
    //     0x967628: add             x3, x3, HEAP, lsl #32
    // 0x96762c: stp             x3, x1, [SP, #-0x10]!
    // 0x967630: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x967630: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x967634: r0 = writeFrom()
    //     0x967634: bl              #0x58ca7c  ; [dart:io] _RandomAccessFile::writeFrom
    // 0x967638: add             SP, SP, #0x10
    // 0x96763c: ldur            x2, [fp, #-0x10]
    // 0x967640: r1 = Function '<anonymous closure>':.
    //     0x967640: add             x1, PP, #0x30, lsl #12  ; [pp+0x30160] AnonymousClosure: (0x967860), in [package:dio/src/dio/dio_for_native.dart] DioForNative::download (0x965f94)
    //     0x967644: ldr             x1, [x1, #0x160]
    // 0x967648: stur            x0, [fp, #-0x18]
    // 0x96764c: r0 = AllocateClosure()
    //     0x96764c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x967650: r16 = <Null?>
    //     0x967650: ldr             x16, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    // 0x967654: ldur            lr, [fp, #-0x18]
    // 0x967658: stp             lr, x16, [SP, #-0x10]!
    // 0x96765c: SaveReg r0
    //     0x96765c: str             x0, [SP, #-8]!
    // 0x967660: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x967660: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x967664: r0 = then()
    //     0x967664: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x967668: add             SP, SP, #0x18
    // 0x96766c: ldur            x2, [fp, #-0x10]
    // 0x967670: r1 = Function '<anonymous closure>':.
    //     0x967670: add             x1, PP, #0x30, lsl #12  ; [pp+0x30168] AnonymousClosure: (0x9676d0), in [package:dio/src/dio/dio_for_native.dart] DioForNative::download (0x965f94)
    //     0x967674: ldr             x1, [x1, #0x168]
    // 0x967678: stur            x0, [fp, #-0x10]
    // 0x96767c: r0 = AllocateClosure()
    //     0x96767c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x967680: ldur            x16, [fp, #-0x10]
    // 0x967684: stp             x0, x16, [SP, #-0x10]!
    // 0x967688: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x967688: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x96768c: r0 = catchError()
    //     0x96768c: bl              #0xca5bb8  ; [dart:async] _Future::catchError
    // 0x967690: add             SP, SP, #0x10
    // 0x967694: ldur            x1, [fp, #-8]
    // 0x967698: StoreField: r1->field_2f = r0
    //     0x967698: stur            w0, [x1, #0x2f]
    //     0x96769c: tbz             w0, #0, #0x9676b8
    //     0x9676a0: ldurb           w16, [x1, #-1]
    //     0x9676a4: ldurb           w17, [x0, #-1]
    //     0x9676a8: and             x16, x17, x16, lsr #2
    //     0x9676ac: tst             x16, HEAP, lsr #32
    //     0x9676b0: b.eq            #0x9676b8
    //     0x9676b4: bl              #0xd6826c
    // 0x9676b8: r0 = Null
    //     0x9676b8: mov             x0, NULL
    // 0x9676bc: LeaveFrame
    //     0x9676bc: mov             SP, fp
    //     0x9676c0: ldp             fp, lr, [SP], #0x10
    // 0x9676c4: ret
    //     0x9676c4: ret             
    // 0x9676c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9676c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9676cc: b               #0x967598
  }
  [closure] Future<Null> <anonymous closure>(dynamic, Object) async {
    // ** addr: 0x9676d0, size: 0x190
    // 0x9676d0: EnterFrame
    //     0x9676d0: stp             fp, lr, [SP, #-0x10]!
    //     0x9676d4: mov             fp, SP
    // 0x9676d8: AllocStack(0x60)
    //     0x9676d8: sub             SP, SP, #0x60
    // 0x9676dc: SetupParameters(DioForNative this /* r1, fp-0x58 */, dynamic _ /* r2, fp-0x50 */)
    //     0x9676dc: stur            NULL, [fp, #-8]
    //     0x9676e0: mov             x0, #0
    //     0x9676e4: add             x1, fp, w0, sxtw #2
    //     0x9676e8: ldr             x1, [x1, #0x18]
    //     0x9676ec: stur            x1, [fp, #-0x58]
    //     0x9676f0: add             x2, fp, w0, sxtw #2
    //     0x9676f4: ldr             x2, [x2, #0x10]
    //     0x9676f8: stur            x2, [fp, #-0x50]
    //     0x9676fc: ldur            w3, [x1, #0x17]
    //     0x967700: add             x3, x3, HEAP, lsl #32
    //     0x967704: stur            x3, [fp, #-0x48]
    // 0x967708: CheckStackOverflow
    //     0x967708: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x96770c: cmp             SP, x16
    //     0x967710: b.ls            #0x967850
    // 0x967714: InitAsync() -> Future<Null?>
    //     0x967714: ldr             x0, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    //     0x967718: bl              #0x4b92e4
    // 0x96771c: ldur            x0, [fp, #-0x48]
    // 0x967720: LoadField: r1 = r0->field_b
    //     0x967720: ldur            w1, [x0, #0xb]
    // 0x967724: DecompressPointer r1
    //     0x967724: add             x1, x1, HEAP, lsl #32
    // 0x967728: stur            x1, [fp, #-0x58]
    // 0x96772c: LoadField: r2 = r1->field_3b
    //     0x96772c: ldur            w2, [x1, #0x3b]
    // 0x967730: DecompressPointer r2
    //     0x967730: add             x2, x2, HEAP, lsl #32
    // 0x967734: r16 = Sentinel
    //     0x967734: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x967738: cmp             w2, w16
    // 0x96773c: b.ne            #0x967754
    // 0x967740: r16 = "subscription"
    //     0x967740: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d58] "subscription"
    //     0x967744: ldr             x16, [x16, #0xd58]
    // 0x967748: SaveReg r16
    //     0x967748: str             x16, [SP, #-8]!
    // 0x96774c: r0 = _throwLocalNotInitialized()
    //     0x96774c: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x967750: add             SP, SP, #8
    // 0x967754: ldur            x1, [fp, #-0x58]
    // 0x967758: LoadField: r0 = r1->field_3b
    //     0x967758: ldur            w0, [x1, #0x3b]
    // 0x96775c: DecompressPointer r0
    //     0x96775c: add             x0, x0, HEAP, lsl #32
    // 0x967760: r2 = LoadClassIdInstr(r0)
    //     0x967760: ldur            x2, [x0, #-1]
    //     0x967764: ubfx            x2, x2, #0xc, #0x14
    // 0x967768: SaveReg r0
    //     0x967768: str             x0, [SP, #-8]!
    // 0x96776c: mov             x0, x2
    // 0x967770: r0 = GDT[cid_x0 + 0x307]()
    //     0x967770: add             lr, x0, #0x307
    //     0x967774: ldr             lr, [x21, lr, lsl #3]
    //     0x967778: blr             lr
    // 0x96777c: add             SP, SP, #8
    // 0x967780: mov             x1, x0
    // 0x967784: stur            x1, [fp, #-0x60]
    // 0x967788: r0 = Await()
    //     0x967788: bl              #0x4b8e6c  ; AwaitStub
    // 0x96778c: ldur            x0, [fp, #-0x58]
    // 0x967790: LoadField: r1 = r0->field_23
    //     0x967790: ldur            w1, [x0, #0x23]
    // 0x967794: DecompressPointer r1
    //     0x967794: add             x1, x1, HEAP, lsl #32
    // 0x967798: stur            x1, [fp, #-0x48]
    // 0x96779c: LoadField: r2 = r0->field_17
    //     0x96779c: ldur            w2, [x0, #0x17]
    // 0x9677a0: DecompressPointer r2
    //     0x9677a0: add             x2, x2, HEAP, lsl #32
    // 0x9677a4: cmp             w2, NULL
    // 0x9677a8: b.eq            #0x967858
    // 0x9677ac: LoadField: r0 = r2->field_f
    //     0x9677ac: ldur            w0, [x2, #0xf]
    // 0x9677b0: DecompressPointer r0
    //     0x9677b0: add             x0, x0, HEAP, lsl #32
    // 0x9677b4: ldur            x16, [fp, #-0x50]
    // 0x9677b8: stp             x0, x16, [SP, #-0x10]!
    // 0x9677bc: r0 = assureDioException()
    //     0x9677bc: bl              #0x528ea4  ; [package:dio/src/dio_mixin.dart] DioMixin::assureDioException
    // 0x9677c0: add             SP, SP, #0x10
    // 0x9677c4: ldur            x16, [fp, #-0x48]
    // 0x9677c8: stp             x0, x16, [SP, #-0x10]!
    // 0x9677cc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9677cc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9677d0: r0 = completeError()
    //     0x9677d0: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0x9677d4: add             SP, SP, #0x10
    // 0x9677d8: r0 = Null
    //     0x9677d8: mov             x0, NULL
    // 0x9677dc: r0 = ReturnAsyncNotFuture()
    //     0x9677dc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9677e0: sub             SP, fp, #0x60
    // 0x9677e4: ldur            x2, [fp, #-0x28]
    // 0x9677e8: stur            x0, [fp, #-0x50]
    // 0x9677ec: stur            x1, [fp, #-0x58]
    // 0x9677f0: LoadField: r3 = r2->field_b
    //     0x9677f0: ldur            w3, [x2, #0xb]
    // 0x9677f4: DecompressPointer r3
    //     0x9677f4: add             x3, x3, HEAP, lsl #32
    // 0x9677f8: LoadField: r2 = r3->field_23
    //     0x9677f8: ldur            w2, [x3, #0x23]
    // 0x9677fc: DecompressPointer r2
    //     0x9677fc: add             x2, x2, HEAP, lsl #32
    // 0x967800: stur            x2, [fp, #-0x48]
    // 0x967804: LoadField: r4 = r3->field_17
    //     0x967804: ldur            w4, [x3, #0x17]
    // 0x967808: DecompressPointer r4
    //     0x967808: add             x4, x4, HEAP, lsl #32
    // 0x96780c: cmp             w4, NULL
    // 0x967810: b.eq            #0x96785c
    // 0x967814: LoadField: r3 = r4->field_f
    //     0x967814: ldur            w3, [x4, #0xf]
    // 0x967818: DecompressPointer r3
    //     0x967818: add             x3, x3, HEAP, lsl #32
    // 0x96781c: ldur            x16, [fp, #-0x18]
    // 0x967820: stp             x3, x16, [SP, #-0x10]!
    // 0x967824: r0 = assureDioException()
    //     0x967824: bl              #0x528ea4  ; [package:dio/src/dio_mixin.dart] DioMixin::assureDioException
    // 0x967828: add             SP, SP, #0x10
    // 0x96782c: ldur            x16, [fp, #-0x48]
    // 0x967830: stp             x0, x16, [SP, #-0x10]!
    // 0x967834: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x967834: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x967838: r0 = completeError()
    //     0x967838: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0x96783c: add             SP, SP, #0x10
    // 0x967840: ldur            x0, [fp, #-0x50]
    // 0x967844: ldur            x1, [fp, #-0x58]
    // 0x967848: r0 = ReThrow()
    //     0x967848: bl              #0xd67e14  ; ReThrowStub
    // 0x96784c: brk             #0
    // 0x967850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x967850: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x967854: b               #0x967714
    // 0x967858: r0 = NullErrorSharedWithoutFPURegs()
    //     0x967858: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x96785c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x96785c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, RandomAccessFile) {
    // ** addr: 0x967860, size: 0x184
    // 0x967860: EnterFrame
    //     0x967860: stp             fp, lr, [SP, #-0x10]!
    //     0x967864: mov             fp, SP
    // 0x967868: AllocStack(0x8)
    //     0x967868: sub             SP, SP, #8
    // 0x96786c: SetupParameters()
    //     0x96786c: ldr             x0, [fp, #0x18]
    //     0x967870: ldur            w1, [x0, #0x17]
    //     0x967874: add             x1, x1, HEAP, lsl #32
    // 0x967878: CheckStackOverflow
    //     0x967878: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x96787c: cmp             SP, x16
    //     0x967880: b.ls            #0x9679d8
    // 0x967884: LoadField: r2 = r1->field_b
    //     0x967884: ldur            w2, [x1, #0xb]
    // 0x967888: DecompressPointer r2
    //     0x967888: add             x2, x2, HEAP, lsl #32
    // 0x96788c: stur            x2, [fp, #-8]
    // 0x967890: LoadField: r0 = r2->field_27
    //     0x967890: ldur            w0, [x2, #0x27]
    // 0x967894: DecompressPointer r0
    //     0x967894: add             x0, x0, HEAP, lsl #32
    // 0x967898: LoadField: r3 = r1->field_f
    //     0x967898: ldur            w3, [x1, #0xf]
    // 0x96789c: DecompressPointer r3
    //     0x96789c: add             x3, x3, HEAP, lsl #32
    // 0x9678a0: LoadField: r1 = r3->field_13
    //     0x9678a0: ldur            w1, [x3, #0x13]
    // 0x9678a4: DecompressPointer r1
    //     0x9678a4: add             x1, x1, HEAP, lsl #32
    // 0x9678a8: cmp             w0, NULL
    // 0x9678ac: b.eq            #0x9679e0
    // 0x9678b0: r3 = LoadInt32Instr(r1)
    //     0x9678b0: sbfx            x3, x1, #1, #0x1f
    // 0x9678b4: r1 = LoadInt32Instr(r0)
    //     0x9678b4: sbfx            x1, x0, #1, #0x1f
    //     0x9678b8: tbz             w0, #0, #0x9678c0
    //     0x9678bc: ldur            x1, [x0, #7]
    // 0x9678c0: add             x4, x1, x3
    // 0x9678c4: r0 = BoxInt64Instr(r4)
    //     0x9678c4: sbfiz           x0, x4, #1, #0x1f
    //     0x9678c8: cmp             x4, x0, asr #1
    //     0x9678cc: b.eq            #0x9678d8
    //     0x9678d0: bl              #0xd69bb8
    //     0x9678d4: stur            x4, [x0, #7]
    // 0x9678d8: mov             x1, x0
    // 0x9678dc: StoreField: r2->field_27 = r0
    //     0x9678dc: stur            w0, [x2, #0x27]
    //     0x9678e0: tbz             w0, #0, #0x9678fc
    //     0x9678e4: ldurb           w16, [x2, #-1]
    //     0x9678e8: ldurb           w17, [x0, #-1]
    //     0x9678ec: and             x16, x17, x16, lsr #2
    //     0x9678f0: tst             x16, HEAP, lsr #32
    //     0x9678f4: b.eq            #0x9678fc
    //     0x9678f8: bl              #0xd6828c
    // 0x9678fc: LoadField: r0 = r2->field_13
    //     0x9678fc: ldur            w0, [x2, #0x13]
    // 0x967900: DecompressPointer r0
    //     0x967900: add             x0, x0, HEAP, lsl #32
    // 0x967904: cmp             w0, NULL
    // 0x967908: b.ne            #0x967914
    // 0x96790c: mov             x1, x2
    // 0x967910: b               #0x967938
    // 0x967914: LoadField: r3 = r2->field_2b
    //     0x967914: ldur            w3, [x2, #0x2b]
    // 0x967918: DecompressPointer r3
    //     0x967918: add             x3, x3, HEAP, lsl #32
    // 0x96791c: stp             x1, x0, [SP, #-0x10]!
    // 0x967920: SaveReg r3
    //     0x967920: str             x3, [SP, #-8]!
    // 0x967924: ClosureCall
    //     0x967924: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x967928: ldur            x2, [x0, #0x1f]
    //     0x96792c: blr             x2
    // 0x967930: add             SP, SP, #0x18
    // 0x967934: ldur            x1, [fp, #-8]
    // 0x967938: ldr             x0, [fp, #0x10]
    // 0x96793c: StoreField: r1->field_1f = r0
    //     0x96793c: stur            w0, [x1, #0x1f]
    //     0x967940: ldurb           w16, [x1, #-1]
    //     0x967944: ldurb           w17, [x0, #-1]
    //     0x967948: and             x16, x17, x16, lsr #2
    //     0x96794c: tst             x16, HEAP, lsr #32
    //     0x967950: b.eq            #0x967958
    //     0x967954: bl              #0xd6826c
    // 0x967958: LoadField: r0 = r1->field_f
    //     0x967958: ldur            w0, [x1, #0xf]
    // 0x96795c: DecompressPointer r0
    //     0x96795c: add             x0, x0, HEAP, lsl #32
    // 0x967960: cmp             w0, NULL
    // 0x967964: b.eq            #0x967978
    // 0x967968: LoadField: r2 = r0->field_b
    //     0x967968: ldur            w2, [x0, #0xb]
    // 0x96796c: DecompressPointer r2
    //     0x96796c: add             x2, x2, HEAP, lsl #32
    // 0x967970: cmp             w2, NULL
    // 0x967974: b.ne            #0x9679c8
    // 0x967978: LoadField: r0 = r1->field_3b
    //     0x967978: ldur            w0, [x1, #0x3b]
    // 0x96797c: DecompressPointer r0
    //     0x96797c: add             x0, x0, HEAP, lsl #32
    // 0x967980: r16 = Sentinel
    //     0x967980: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x967984: cmp             w0, w16
    // 0x967988: b.ne            #0x9679a0
    // 0x96798c: r16 = "subscription"
    //     0x96798c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d58] "subscription"
    //     0x967990: ldr             x16, [x16, #0xd58]
    // 0x967994: SaveReg r16
    //     0x967994: str             x16, [SP, #-8]!
    // 0x967998: r0 = _throwLocalNotInitialized()
    //     0x967998: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x96799c: add             SP, SP, #8
    // 0x9679a0: ldur            x0, [fp, #-8]
    // 0x9679a4: LoadField: r1 = r0->field_3b
    //     0x9679a4: ldur            w1, [x0, #0x3b]
    // 0x9679a8: DecompressPointer r1
    //     0x9679a8: add             x1, x1, HEAP, lsl #32
    // 0x9679ac: r0 = LoadClassIdInstr(r1)
    //     0x9679ac: ldur            x0, [x1, #-1]
    //     0x9679b0: ubfx            x0, x0, #0xc, #0x14
    // 0x9679b4: SaveReg r1
    //     0x9679b4: str             x1, [SP, #-8]!
    // 0x9679b8: r0 = GDT[cid_x0 + 0x392]()
    //     0x9679b8: add             lr, x0, #0x392
    //     0x9679bc: ldr             lr, [x21, lr, lsl #3]
    //     0x9679c0: blr             lr
    // 0x9679c4: add             SP, SP, #8
    // 0x9679c8: r0 = Null
    //     0x9679c8: mov             x0, NULL
    // 0x9679cc: LeaveFrame
    //     0x9679cc: mov             SP, fp
    //     0x9679d0: ldp             fp, lr, [SP], #0x10
    // 0x9679d4: ret
    //     0x9679d4: ret             
    // 0x9679d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9679d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9679dc: b               #0x967884
    // 0x9679e0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x9679e0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> closeAndDelete(dynamic) async {
    // ** addr: 0x9679e4, size: 0x100
    // 0x9679e4: EnterFrame
    //     0x9679e4: stp             fp, lr, [SP, #-0x10]!
    //     0x9679e8: mov             fp, SP
    // 0x9679ec: AllocStack(0x18)
    //     0x9679ec: sub             SP, SP, #0x18
    // 0x9679f0: SetupParameters(DioForNative this /* r1 */)
    //     0x9679f0: stur            NULL, [fp, #-8]
    //     0x9679f4: mov             x0, #0
    //     0x9679f8: add             x1, fp, w0, sxtw #2
    //     0x9679fc: ldr             x1, [x1, #0x10]
    //     0x967a00: ldur            w2, [x1, #0x17]
    //     0x967a04: add             x2, x2, HEAP, lsl #32
    //     0x967a08: stur            x2, [fp, #-0x10]
    // 0x967a0c: CheckStackOverflow
    //     0x967a0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x967a10: cmp             SP, x16
    //     0x967a14: b.ls            #0x967ad8
    // 0x967a18: InitAsync() -> Future<void?>
    //     0x967a18: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x967a1c: bl              #0x4b92e4
    // 0x967a20: ldur            x1, [fp, #-0x10]
    // 0x967a24: LoadField: r2 = r1->field_33
    //     0x967a24: ldur            w2, [x1, #0x33]
    // 0x967a28: DecompressPointer r2
    //     0x967a28: add             x2, x2, HEAP, lsl #32
    // 0x967a2c: mov             x0, x2
    // 0x967a30: stur            x2, [fp, #-0x18]
    // 0x967a34: tbnz            w0, #5, #0x967a3c
    // 0x967a38: r0 = AssertBoolean()
    //     0x967a38: bl              #0xd67df0  ; AssertBooleanStub
    // 0x967a3c: ldur            x0, [fp, #-0x18]
    // 0x967a40: tbz             w0, #4, #0x967ad0
    // 0x967a44: ldur            x1, [fp, #-0x10]
    // 0x967a48: r0 = true
    //     0x967a48: add             x0, NULL, #0x20  ; true
    // 0x967a4c: StoreField: r1->field_33 = r0
    //     0x967a4c: stur            w0, [x1, #0x33]
    // 0x967a50: LoadField: r2 = r1->field_2f
    //     0x967a50: ldur            w2, [x1, #0x2f]
    // 0x967a54: DecompressPointer r2
    //     0x967a54: add             x2, x2, HEAP, lsl #32
    // 0x967a58: mov             x0, x2
    // 0x967a5c: stur            x2, [fp, #-0x18]
    // 0x967a60: r0 = Await()
    //     0x967a60: bl              #0x4b8e6c  ; AwaitStub
    // 0x967a64: ldur            x0, [fp, #-0x10]
    // 0x967a68: LoadField: r1 = r0->field_1f
    //     0x967a68: ldur            w1, [x0, #0x1f]
    // 0x967a6c: DecompressPointer r1
    //     0x967a6c: add             x1, x1, HEAP, lsl #32
    // 0x967a70: SaveReg r1
    //     0x967a70: str             x1, [SP, #-8]!
    // 0x967a74: r0 = close()
    //     0x967a74: bl              #0x967330  ; [dart:io] _RandomAccessFile::close
    // 0x967a78: add             SP, SP, #8
    // 0x967a7c: mov             x1, x0
    // 0x967a80: stur            x1, [fp, #-0x18]
    // 0x967a84: r0 = Await()
    //     0x967a84: bl              #0x4b8e6c  ; AwaitStub
    // 0x967a88: ldur            x0, [fp, #-0x10]
    // 0x967a8c: LoadField: r1 = r0->field_1b
    //     0x967a8c: ldur            w1, [x0, #0x1b]
    // 0x967a90: DecompressPointer r1
    //     0x967a90: add             x1, x1, HEAP, lsl #32
    // 0x967a94: stur            x1, [fp, #-0x18]
    // 0x967a98: cmp             w1, NULL
    // 0x967a9c: b.eq            #0x967ae0
    // 0x967aa0: SaveReg r1
    //     0x967aa0: str             x1, [SP, #-8]!
    // 0x967aa4: r0 = existsSync()
    //     0x967aa4: bl              #0xc7dcb4  ; [dart:io] _File::existsSync
    // 0x967aa8: add             SP, SP, #8
    // 0x967aac: tbnz            w0, #4, #0x967ad0
    // 0x967ab0: ldur            x16, [fp, #-0x18]
    // 0x967ab4: SaveReg r16
    //     0x967ab4: str             x16, [SP, #-8]!
    // 0x967ab8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x967ab8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x967abc: r0 = delete()
    //     0x967abc: bl              #0x967ae4  ; [dart:io] FileSystemEntity::delete
    // 0x967ac0: add             SP, SP, #8
    // 0x967ac4: mov             x1, x0
    // 0x967ac8: stur            x1, [fp, #-0x18]
    // 0x967acc: r0 = Await()
    //     0x967acc: bl              #0x4b8e6c  ; AwaitStub
    // 0x967ad0: r0 = Null
    //     0x967ad0: mov             x0, NULL
    // 0x967ad4: r0 = ReturnAsyncNotFuture()
    //     0x967ad4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x967ad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x967ad8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x967adc: b               #0x967a18
    // 0x967ae0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x967ae0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:dio/src/multipart_file.dart

// class id: 1048892, size: 0x8
class :: {
}

// class id: 4534, size: 0x24, field offset: 0x8
class MultipartFile extends Object {

  _ finalize(/* No info */) {
    // ** addr: 0x55a284, size: 0x58
    // 0x55a284: EnterFrame
    //     0x55a284: stp             fp, lr, [SP, #-0x10]!
    //     0x55a288: mov             fp, SP
    // 0x55a28c: ldr             x0, [fp, #0x10]
    // 0x55a290: LoadField: r1 = r0->field_1f
    //     0x55a290: ldur            w1, [x0, #0x1f]
    // 0x55a294: DecompressPointer r1
    //     0x55a294: add             x1, x1, HEAP, lsl #32
    // 0x55a298: tbz             w1, #4, #0x55a2bc
    // 0x55a29c: r1 = true
    //     0x55a29c: add             x1, NULL, #0x20  ; true
    // 0x55a2a0: StoreField: r0->field_1f = r1
    //     0x55a2a0: stur            w1, [x0, #0x1f]
    // 0x55a2a4: LoadField: r1 = r0->field_1b
    //     0x55a2a4: ldur            w1, [x0, #0x1b]
    // 0x55a2a8: DecompressPointer r1
    //     0x55a2a8: add             x1, x1, HEAP, lsl #32
    // 0x55a2ac: mov             x0, x1
    // 0x55a2b0: LeaveFrame
    //     0x55a2b0: mov             SP, fp
    //     0x55a2b4: ldp             fp, lr, [SP], #0x10
    // 0x55a2b8: ret
    //     0x55a2b8: ret             
    // 0x55a2bc: r0 = StateError()
    //     0x55a2bc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x55a2c0: mov             x1, x0
    // 0x55a2c4: r0 = "The MultipartFile has already been finalized. This typically means you are using the same MultipartFile in repeated requests."
    //     0x55a2c4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14640] "The MultipartFile has already been finalized. This typically means you are using the same MultipartFile in repeated requests."
    //     0x55a2c8: ldr             x0, [x0, #0x640]
    // 0x55a2cc: StoreField: r1->field_b = r0
    //     0x55a2cc: stur            w0, [x1, #0xb]
    // 0x55a2d0: mov             x0, x1
    // 0x55a2d4: r0 = Throw()
    //     0x55a2d4: bl              #0xd67e38  ; ThrowStub
    // 0x55a2d8: brk             #0
  }
  _ MultipartFile(/* No info */) {
    // ** addr: 0x8c66e0, size: 0x10c
    // 0x8c66e0: EnterFrame
    //     0x8c66e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c66e4: mov             fp, SP
    // 0x8c66e8: AllocStack(0x8)
    //     0x8c66e8: sub             SP, SP, #8
    // 0x8c66ec: r0 = false
    //     0x8c66ec: add             x0, NULL, #0x30  ; false
    // 0x8c66f0: CheckStackOverflow
    //     0x8c66f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8c66f4: cmp             SP, x16
    //     0x8c66f8: b.ls            #0x8c67e4
    // 0x8c66fc: ldr             x1, [fp, #0x28]
    // 0x8c6700: StoreField: r1->field_1f = r0
    //     0x8c6700: stur            w0, [x1, #0x1f]
    // 0x8c6704: ldr             x0, [fp, #0x18]
    // 0x8c6708: StoreField: r1->field_7 = r0
    //     0x8c6708: stur            x0, [x1, #7]
    // 0x8c670c: ldr             x0, [fp, #0x10]
    // 0x8c6710: StoreField: r1->field_f = r0
    //     0x8c6710: stur            w0, [x1, #0xf]
    //     0x8c6714: ldurb           w16, [x1, #-1]
    //     0x8c6718: ldurb           w17, [x0, #-1]
    //     0x8c671c: and             x16, x17, x16, lsr #2
    //     0x8c6720: tst             x16, HEAP, lsr #32
    //     0x8c6724: b.eq            #0x8c672c
    //     0x8c6728: bl              #0xd6826c
    // 0x8c672c: ldr             x0, [fp, #0x20]
    // 0x8c6730: StoreField: r1->field_1b = r0
    //     0x8c6730: stur            w0, [x1, #0x1b]
    //     0x8c6734: ldurb           w16, [x1, #-1]
    //     0x8c6738: ldurb           w17, [x0, #-1]
    //     0x8c673c: and             x16, x17, x16, lsr #2
    //     0x8c6740: tst             x16, HEAP, lsr #32
    //     0x8c6744: b.eq            #0x8c674c
    //     0x8c6748: bl              #0xd6826c
    // 0x8c674c: r16 = <List<String>>
    //     0x8c674c: ldr             x16, [PP, #0x7f58]  ; [pp+0x7f58] TypeArguments: <List<String>>
    // 0x8c6750: stp             NULL, x16, [SP, #-0x10]!
    // 0x8c6754: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8c6754: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8c6758: r0 = caseInsensitiveKeyMap()
    //     0x8c6758: bl              #0x529878  ; [package:dio/src/utils.dart] ::caseInsensitiveKeyMap
    // 0x8c675c: add             SP, SP, #0x10
    // 0x8c6760: ldr             x1, [fp, #0x28]
    // 0x8c6764: StoreField: r1->field_13 = r0
    //     0x8c6764: stur            w0, [x1, #0x13]
    //     0x8c6768: tbz             w0, #0, #0x8c6784
    //     0x8c676c: ldurb           w16, [x1, #-1]
    //     0x8c6770: ldurb           w17, [x0, #-1]
    //     0x8c6774: and             x16, x17, x16, lsr #2
    //     0x8c6778: tst             x16, HEAP, lsr #32
    //     0x8c677c: b.eq            #0x8c6784
    //     0x8c6780: bl              #0xd6826c
    // 0x8c6784: r0 = MediaType()
    //     0x8c6784: bl              #0x52ca68  ; AllocateMediaTypeStub -> MediaType (size=0x14)
    // 0x8c6788: stur            x0, [fp, #-8]
    // 0x8c678c: r16 = "application"
    //     0x8c678c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348f0] "application"
    //     0x8c6790: ldr             x16, [x16, #0x8f0]
    // 0x8c6794: stp             x16, x0, [SP, #-0x10]!
    // 0x8c6798: r16 = "octet-stream"
    //     0x8c6798: add             x16, PP, #0x34, lsl #12  ; [pp+0x348f8] "octet-stream"
    //     0x8c679c: ldr             x16, [x16, #0x8f8]
    // 0x8c67a0: SaveReg r16
    //     0x8c67a0: str             x16, [SP, #-8]!
    // 0x8c67a4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x8c67a4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x8c67a8: r0 = MediaType()
    //     0x8c67a8: bl              #0x52c328  ; [package:http_parser/src/media_type.dart] MediaType::MediaType
    // 0x8c67ac: add             SP, SP, #0x18
    // 0x8c67b0: ldur            x0, [fp, #-8]
    // 0x8c67b4: ldr             x1, [fp, #0x28]
    // 0x8c67b8: StoreField: r1->field_17 = r0
    //     0x8c67b8: stur            w0, [x1, #0x17]
    //     0x8c67bc: ldurb           w16, [x1, #-1]
    //     0x8c67c0: ldurb           w17, [x0, #-1]
    //     0x8c67c4: and             x16, x17, x16, lsr #2
    //     0x8c67c8: tst             x16, HEAP, lsr #32
    //     0x8c67cc: b.eq            #0x8c67d4
    //     0x8c67d0: bl              #0xd6826c
    // 0x8c67d4: r0 = Null
    //     0x8c67d4: mov             x0, NULL
    // 0x8c67d8: LeaveFrame
    //     0x8c67d8: mov             SP, fp
    //     0x8c67dc: ldp             fp, lr, [SP], #0x10
    // 0x8c67e0: ret
    //     0x8c67e0: ret             
    // 0x8c67e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c67e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c67e8: b               #0x8c66fc
  }
}

// lib: , url: package:dio/src/dio_mixin.dart

// class id: 1048887, size: 0x8
class :: {
}

// class id: 4537, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Interceptor extends Object {

  [closure] void onResponse(dynamic, Response<dynamic>, ResponseInterceptorHandler) {
    // ** addr: 0x528bc8, size: 0x40
    // 0x528bc8: EnterFrame
    //     0x528bc8: stp             fp, lr, [SP, #-0x10]!
    //     0x528bcc: mov             fp, SP
    // 0x528bd0: CheckStackOverflow
    //     0x528bd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x528bd4: cmp             SP, x16
    //     0x528bd8: b.ls            #0x528c00
    // 0x528bdc: ldr             x16, [fp, #0x10]
    // 0x528be0: ldr             lr, [fp, #0x18]
    // 0x528be4: stp             lr, x16, [SP, #-0x10]!
    // 0x528be8: r0 = next()
    //     0x528be8: bl              #0x528c08  ; [package:dio/src/dio_mixin.dart] ResponseInterceptorHandler::next
    // 0x528bec: add             SP, SP, #0x10
    // 0x528bf0: r0 = Null
    //     0x528bf0: mov             x0, NULL
    // 0x528bf4: LeaveFrame
    //     0x528bf4: mov             SP, fp
    //     0x528bf8: ldp             fp, lr, [SP], #0x10
    // 0x528bfc: ret
    //     0x528bfc: ret             
    // 0x528c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x528c00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x528c04: b               #0x528bdc
  }
  [closure] void onError(dynamic, DioException, ErrorInterceptorHandler) {
    // ** addr: 0x529040, size: 0x40
    // 0x529040: EnterFrame
    //     0x529040: stp             fp, lr, [SP, #-0x10]!
    //     0x529044: mov             fp, SP
    // 0x529048: CheckStackOverflow
    //     0x529048: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52904c: cmp             SP, x16
    //     0x529050: b.ls            #0x529078
    // 0x529054: ldr             x16, [fp, #0x10]
    // 0x529058: ldr             lr, [fp, #0x18]
    // 0x52905c: stp             lr, x16, [SP, #-0x10]!
    // 0x529060: r0 = next()
    //     0x529060: bl              #0x529080  ; [package:dio/src/dio_mixin.dart] ErrorInterceptorHandler::next
    // 0x529064: add             SP, SP, #0x10
    // 0x529068: r0 = Null
    //     0x529068: mov             x0, NULL
    // 0x52906c: LeaveFrame
    //     0x52906c: mov             SP, fp
    //     0x529070: ldp             fp, lr, [SP], #0x10
    // 0x529074: ret
    //     0x529074: ret             
    // 0x529078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x529078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52907c: b               #0x529054
  }
}

// class id: 4539, size: 0x10, field offset: 0x8
abstract class _BaseHandler extends Object {

  _ _BaseHandler(/* No info */) {
    // ** addr: 0x528acc, size: 0xa8
    // 0x528acc: EnterFrame
    //     0x528acc: stp             fp, lr, [SP, #-0x10]!
    //     0x528ad0: mov             fp, SP
    // 0x528ad4: AllocStack(0x8)
    //     0x528ad4: sub             SP, SP, #8
    // 0x528ad8: CheckStackOverflow
    //     0x528ad8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x528adc: cmp             SP, x16
    //     0x528ae0: b.ls            #0x528b6c
    // 0x528ae4: r1 = <InterceptorState>
    //     0x528ae4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f38] TypeArguments: <InterceptorState>
    //     0x528ae8: ldr             x1, [x1, #0xf38]
    // 0x528aec: r0 = _Future()
    //     0x528aec: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x528af0: mov             x1, x0
    // 0x528af4: r0 = 0
    //     0x528af4: mov             x0, #0
    // 0x528af8: stur            x1, [fp, #-8]
    // 0x528afc: StoreField: r1->field_b = r0
    //     0x528afc: stur            x0, [x1, #0xb]
    // 0x528b00: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x528b00: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x528b04: ldr             x0, [x0, #0xb58]
    //     0x528b08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x528b0c: cmp             w0, w16
    //     0x528b10: b.ne            #0x528b1c
    //     0x528b14: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x528b18: bl              #0xd67d44
    // 0x528b1c: mov             x1, x0
    // 0x528b20: ldur            x0, [fp, #-8]
    // 0x528b24: StoreField: r0->field_13 = r1
    //     0x528b24: stur            w1, [x0, #0x13]
    // 0x528b28: r1 = <InterceptorState>
    //     0x528b28: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f38] TypeArguments: <InterceptorState>
    //     0x528b2c: ldr             x1, [x1, #0xf38]
    // 0x528b30: r0 = _AsyncCompleter()
    //     0x528b30: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x528b34: ldur            x1, [fp, #-8]
    // 0x528b38: StoreField: r0->field_b = r1
    //     0x528b38: stur            w1, [x0, #0xb]
    // 0x528b3c: ldr             x1, [fp, #0x10]
    // 0x528b40: StoreField: r1->field_7 = r0
    //     0x528b40: stur            w0, [x1, #7]
    //     0x528b44: ldurb           w16, [x1, #-1]
    //     0x528b48: ldurb           w17, [x0, #-1]
    //     0x528b4c: and             x16, x17, x16, lsr #2
    //     0x528b50: tst             x16, HEAP, lsr #32
    //     0x528b54: b.eq            #0x528b5c
    //     0x528b58: bl              #0xd6826c
    // 0x528b5c: r0 = Null
    //     0x528b5c: mov             x0, NULL
    // 0x528b60: LeaveFrame
    //     0x528b60: mov             SP, fp
    //     0x528b64: ldp             fp, lr, [SP], #0x10
    // 0x528b68: ret
    //     0x528b68: ret             
    // 0x528b6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x528b6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x528b70: b               #0x528ae4
  }
}

// class id: 4540, size: 0x10, field offset: 0x10
class ErrorInterceptorHandler extends _BaseHandler {

  _ next(/* No info */) {
    // ** addr: 0x529080, size: 0x84
    // 0x529080: EnterFrame
    //     0x529080: stp             fp, lr, [SP, #-0x10]!
    //     0x529084: mov             fp, SP
    // 0x529088: AllocStack(0x8)
    //     0x529088: sub             SP, SP, #8
    // 0x52908c: CheckStackOverflow
    //     0x52908c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x529090: cmp             SP, x16
    //     0x529094: b.ls            #0x5290fc
    // 0x529098: ldr             x0, [fp, #0x18]
    // 0x52909c: LoadField: r2 = r0->field_7
    //     0x52909c: ldur            w2, [x0, #7]
    // 0x5290a0: DecompressPointer r2
    //     0x5290a0: add             x2, x2, HEAP, lsl #32
    // 0x5290a4: stur            x2, [fp, #-8]
    // 0x5290a8: r1 = <DioException>
    //     0x5290a8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f78] TypeArguments: <DioException>
    //     0x5290ac: ldr             x1, [x1, #0xf78]
    // 0x5290b0: r0 = InterceptorState()
    //     0x5290b0: bl              #0x527f68  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x5290b4: mov             x1, x0
    // 0x5290b8: ldr             x0, [fp, #0x10]
    // 0x5290bc: StoreField: r1->field_b = r0
    //     0x5290bc: stur            w0, [x1, #0xb]
    // 0x5290c0: r2 = Instance_InterceptorResultType
    //     0x5290c0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12ed0] Obj!InterceptorResultType@b665b1
    //     0x5290c4: ldr             x2, [x2, #0xed0]
    // 0x5290c8: StoreField: r1->field_f = r2
    //     0x5290c8: stur            w2, [x1, #0xf]
    // 0x5290cc: LoadField: r2 = r0->field_13
    //     0x5290cc: ldur            w2, [x0, #0x13]
    // 0x5290d0: DecompressPointer r2
    //     0x5290d0: add             x2, x2, HEAP, lsl #32
    // 0x5290d4: ldur            x16, [fp, #-8]
    // 0x5290d8: stp             x1, x16, [SP, #-0x10]!
    // 0x5290dc: SaveReg r2
    //     0x5290dc: str             x2, [SP, #-8]!
    // 0x5290e0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x5290e0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x5290e4: r0 = completeError()
    //     0x5290e4: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0x5290e8: add             SP, SP, #0x18
    // 0x5290ec: r0 = Null
    //     0x5290ec: mov             x0, NULL
    // 0x5290f0: LeaveFrame
    //     0x5290f0: mov             SP, fp
    //     0x5290f4: ldp             fp, lr, [SP], #0x10
    // 0x5290f8: ret
    //     0x5290f8: ret             
    // 0x5290fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5290fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x529100: b               #0x529098
  }
}

// class id: 4541, size: 0x10, field offset: 0x10
class ResponseInterceptorHandler extends _BaseHandler {

  _ next(/* No info */) {
    // ** addr: 0x528c08, size: 0x78
    // 0x528c08: EnterFrame
    //     0x528c08: stp             fp, lr, [SP, #-0x10]!
    //     0x528c0c: mov             fp, SP
    // 0x528c10: AllocStack(0x8)
    //     0x528c10: sub             SP, SP, #8
    // 0x528c14: CheckStackOverflow
    //     0x528c14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x528c18: cmp             SP, x16
    //     0x528c1c: b.ls            #0x528c78
    // 0x528c20: ldr             x0, [fp, #0x18]
    // 0x528c24: LoadField: r2 = r0->field_7
    //     0x528c24: ldur            w2, [x0, #7]
    // 0x528c28: DecompressPointer r2
    //     0x528c28: add             x2, x2, HEAP, lsl #32
    // 0x528c2c: stur            x2, [fp, #-8]
    // 0x528c30: r1 = <Response>
    //     0x528c30: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f70] TypeArguments: <Response>
    //     0x528c34: ldr             x1, [x1, #0xf70]
    // 0x528c38: r0 = InterceptorState()
    //     0x528c38: bl              #0x527f68  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x528c3c: mov             x1, x0
    // 0x528c40: ldr             x0, [fp, #0x10]
    // 0x528c44: StoreField: r1->field_b = r0
    //     0x528c44: stur            w0, [x1, #0xb]
    // 0x528c48: r0 = Instance_InterceptorResultType
    //     0x528c48: add             x0, PP, #0x12, lsl #12  ; [pp+0x12ed0] Obj!InterceptorResultType@b665b1
    //     0x528c4c: ldr             x0, [x0, #0xed0]
    // 0x528c50: StoreField: r1->field_f = r0
    //     0x528c50: stur            w0, [x1, #0xf]
    // 0x528c54: ldur            x16, [fp, #-8]
    // 0x528c58: stp             x1, x16, [SP, #-0x10]!
    // 0x528c5c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x528c5c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x528c60: r0 = complete()
    //     0x528c60: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x528c64: add             SP, SP, #0x10
    // 0x528c68: r0 = Null
    //     0x528c68: mov             x0, NULL
    // 0x528c6c: LeaveFrame
    //     0x528c6c: mov             SP, fp
    //     0x528c70: ldp             fp, lr, [SP], #0x10
    // 0x528c74: ret
    //     0x528c74: ret             
    // 0x528c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x528c78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x528c7c: b               #0x528c20
  }
}

// class id: 4542, size: 0x10, field offset: 0x10
class RequestInterceptorHandler extends _BaseHandler {

  _ next(/* No info */) {
    // ** addr: 0x527ef0, size: 0x78
    // 0x527ef0: EnterFrame
    //     0x527ef0: stp             fp, lr, [SP, #-0x10]!
    //     0x527ef4: mov             fp, SP
    // 0x527ef8: AllocStack(0x8)
    //     0x527ef8: sub             SP, SP, #8
    // 0x527efc: CheckStackOverflow
    //     0x527efc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x527f00: cmp             SP, x16
    //     0x527f04: b.ls            #0x527f60
    // 0x527f08: ldr             x0, [fp, #0x18]
    // 0x527f0c: LoadField: r2 = r0->field_7
    //     0x527f0c: ldur            w2, [x0, #7]
    // 0x527f10: DecompressPointer r2
    //     0x527f10: add             x2, x2, HEAP, lsl #32
    // 0x527f14: stur            x2, [fp, #-8]
    // 0x527f18: r1 = <RequestOptions>
    //     0x527f18: add             x1, PP, #0x12, lsl #12  ; [pp+0x12ec8] TypeArguments: <RequestOptions>
    //     0x527f1c: ldr             x1, [x1, #0xec8]
    // 0x527f20: r0 = InterceptorState()
    //     0x527f20: bl              #0x527f68  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x527f24: mov             x1, x0
    // 0x527f28: ldr             x0, [fp, #0x10]
    // 0x527f2c: StoreField: r1->field_b = r0
    //     0x527f2c: stur            w0, [x1, #0xb]
    // 0x527f30: r0 = Instance_InterceptorResultType
    //     0x527f30: add             x0, PP, #0x12, lsl #12  ; [pp+0x12ed0] Obj!InterceptorResultType@b665b1
    //     0x527f34: ldr             x0, [x0, #0xed0]
    // 0x527f38: StoreField: r1->field_f = r0
    //     0x527f38: stur            w0, [x1, #0xf]
    // 0x527f3c: ldur            x16, [fp, #-8]
    // 0x527f40: stp             x1, x16, [SP, #-0x10]!
    // 0x527f44: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x527f44: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x527f48: r0 = complete()
    //     0x527f48: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x527f4c: add             SP, SP, #0x10
    // 0x527f50: r0 = Null
    //     0x527f50: mov             x0, NULL
    // 0x527f54: LeaveFrame
    //     0x527f54: mov             SP, fp
    //     0x527f58: ldp             fp, lr, [SP], #0x10
    // 0x527f5c: ret
    //     0x527f5c: ret             
    // 0x527f60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x527f60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x527f64: b               #0x527f08
  }
  _ RequestInterceptorHandler(/* No info */) {
    // ** addr: 0x52a8c4, size: 0x3c
    // 0x52a8c4: EnterFrame
    //     0x52a8c4: stp             fp, lr, [SP, #-0x10]!
    //     0x52a8c8: mov             fp, SP
    // 0x52a8cc: CheckStackOverflow
    //     0x52a8cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52a8d0: cmp             SP, x16
    //     0x52a8d4: b.ls            #0x52a8f8
    // 0x52a8d8: ldr             x16, [fp, #0x10]
    // 0x52a8dc: SaveReg r16
    //     0x52a8dc: str             x16, [SP, #-8]!
    // 0x52a8e0: r0 = _BaseHandler()
    //     0x52a8e0: bl              #0x528acc  ; [package:dio/src/dio_mixin.dart] _BaseHandler::_BaseHandler
    // 0x52a8e4: add             SP, SP, #8
    // 0x52a8e8: r0 = Null
    //     0x52a8e8: mov             x0, NULL
    // 0x52a8ec: LeaveFrame
    //     0x52a8ec: mov             SP, fp
    //     0x52a8f0: ldp             fp, lr, [SP], #0x10
    // 0x52a8f4: ret
    //     0x52a8f4: ret             
    // 0x52a8f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52a8f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52a8fc: b               #0x52a8d8
  }
  _ reject(/* No info */) {
    // ** addr: 0x55a82c, size: 0x84
    // 0x55a82c: EnterFrame
    //     0x55a82c: stp             fp, lr, [SP, #-0x10]!
    //     0x55a830: mov             fp, SP
    // 0x55a834: AllocStack(0x8)
    //     0x55a834: sub             SP, SP, #8
    // 0x55a838: CheckStackOverflow
    //     0x55a838: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a83c: cmp             SP, x16
    //     0x55a840: b.ls            #0x55a8a8
    // 0x55a844: ldr             x0, [fp, #0x18]
    // 0x55a848: LoadField: r2 = r0->field_7
    //     0x55a848: ldur            w2, [x0, #7]
    // 0x55a84c: DecompressPointer r2
    //     0x55a84c: add             x2, x2, HEAP, lsl #32
    // 0x55a850: stur            x2, [fp, #-8]
    // 0x55a854: r1 = <DioException>
    //     0x55a854: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f78] TypeArguments: <DioException>
    //     0x55a858: ldr             x1, [x1, #0xf78]
    // 0x55a85c: r0 = InterceptorState()
    //     0x55a85c: bl              #0x527f68  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x55a860: mov             x1, x0
    // 0x55a864: ldr             x0, [fp, #0x10]
    // 0x55a868: StoreField: r1->field_b = r0
    //     0x55a868: stur            w0, [x1, #0xb]
    // 0x55a86c: r2 = Instance_InterceptorResultType
    //     0x55a86c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f98] Obj!InterceptorResultType@b665f1
    //     0x55a870: ldr             x2, [x2, #0xf98]
    // 0x55a874: StoreField: r1->field_f = r2
    //     0x55a874: stur            w2, [x1, #0xf]
    // 0x55a878: LoadField: r2 = r0->field_13
    //     0x55a878: ldur            w2, [x0, #0x13]
    // 0x55a87c: DecompressPointer r2
    //     0x55a87c: add             x2, x2, HEAP, lsl #32
    // 0x55a880: ldur            x16, [fp, #-8]
    // 0x55a884: stp             x1, x16, [SP, #-0x10]!
    // 0x55a888: SaveReg r2
    //     0x55a888: str             x2, [SP, #-8]!
    // 0x55a88c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x55a88c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x55a890: r0 = completeError()
    //     0x55a890: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0x55a894: add             SP, SP, #0x18
    // 0x55a898: r0 = Null
    //     0x55a898: mov             x0, NULL
    // 0x55a89c: LeaveFrame
    //     0x55a89c: mov             SP, fp
    //     0x55a8a0: ldp             fp, lr, [SP], #0x10
    // 0x55a8a4: ret
    //     0x55a8a4: ret             
    // 0x55a8a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a8a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a8ac: b               #0x55a844
  }
  _ resolve(/* No info */) {
    // ** addr: 0x55a8fc, size: 0x78
    // 0x55a8fc: EnterFrame
    //     0x55a8fc: stp             fp, lr, [SP, #-0x10]!
    //     0x55a900: mov             fp, SP
    // 0x55a904: AllocStack(0x8)
    //     0x55a904: sub             SP, SP, #8
    // 0x55a908: CheckStackOverflow
    //     0x55a908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55a90c: cmp             SP, x16
    //     0x55a910: b.ls            #0x55a96c
    // 0x55a914: ldr             x0, [fp, #0x18]
    // 0x55a918: LoadField: r2 = r0->field_7
    //     0x55a918: ldur            w2, [x0, #7]
    // 0x55a91c: DecompressPointer r2
    //     0x55a91c: add             x2, x2, HEAP, lsl #32
    // 0x55a920: stur            x2, [fp, #-8]
    // 0x55a924: r1 = <Response>
    //     0x55a924: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f70] TypeArguments: <Response>
    //     0x55a928: ldr             x1, [x1, #0xf70]
    // 0x55a92c: r0 = InterceptorState()
    //     0x55a92c: bl              #0x527f68  ; AllocateInterceptorStateStub -> InterceptorState<X0> (size=0x14)
    // 0x55a930: mov             x1, x0
    // 0x55a934: ldr             x0, [fp, #0x10]
    // 0x55a938: StoreField: r1->field_b = r0
    //     0x55a938: stur            w0, [x1, #0xb]
    // 0x55a93c: r0 = Instance_InterceptorResultType
    //     0x55a93c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12f10] Obj!InterceptorResultType@b665d1
    //     0x55a940: ldr             x0, [x0, #0xf10]
    // 0x55a944: StoreField: r1->field_f = r0
    //     0x55a944: stur            w0, [x1, #0xf]
    // 0x55a948: ldur            x16, [fp, #-8]
    // 0x55a94c: stp             x1, x16, [SP, #-0x10]!
    // 0x55a950: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x55a950: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x55a954: r0 = complete()
    //     0x55a954: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x55a958: add             SP, SP, #0x10
    // 0x55a95c: r0 = Null
    //     0x55a95c: mov             x0, NULL
    // 0x55a960: LeaveFrame
    //     0x55a960: mov             SP, fp
    //     0x55a964: ldp             fp, lr, [SP], #0x10
    // 0x55a968: ret
    //     0x55a968: ret             
    // 0x55a96c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55a96c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55a970: b               #0x55a914
  }
}

// class id: 4543, size: 0x14, field offset: 0x8
//   const constructor, 
class InterceptorState<X0> extends Object {
}

// class id: 4545, size: 0x8, field offset: 0x8
abstract class DioMixin extends Object
    implements Dio {

  static _ listenCancelForAsyncTask(/* No info */) {
    // ** addr: 0x5282ac, size: 0x228
    // 0x5282ac: EnterFrame
    //     0x5282ac: stp             fp, lr, [SP, #-0x10]!
    //     0x5282b0: mov             fp, SP
    // 0x5282b4: AllocStack(0x20)
    //     0x5282b4: sub             SP, SP, #0x20
    // 0x5282b8: SetupParameters()
    //     0x5282b8: mov             x0, x4
    //     0x5282bc: ldur            w1, [x0, #0xf]
    //     0x5282c0: add             x1, x1, HEAP, lsl #32
    //     0x5282c4: cbnz            w1, #0x5282d0
    //     0x5282c8: mov             x4, NULL
    //     0x5282cc: b               #0x5282e4
    //     0x5282d0: ldur            w1, [x0, #0x17]
    //     0x5282d4: add             x1, x1, HEAP, lsl #32
    //     0x5282d8: add             x0, fp, w1, sxtw #2
    //     0x5282dc: ldr             x0, [x0, #0x10]
    //     0x5282e0: mov             x4, x0
    //     0x5282e4: ldr             x0, [fp, #0x18]
    //     0x5282e8: stur            x4, [fp, #-8]
    // 0x5282ec: CheckStackOverflow
    //     0x5282ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5282f0: cmp             SP, x16
    //     0x5282f4: b.ls            #0x5284c4
    // 0x5282f8: mov             x1, x4
    // 0x5282fc: r2 = Null
    //     0x5282fc: mov             x2, NULL
    // 0x528300: r3 = <Future<Y0>>
    //     0x528300: add             x3, PP, #0x12, lsl #12  ; [pp+0x12f40] TypeArguments: <Future<Y0>>
    //     0x528304: ldr             x3, [x3, #0xf40]
    // 0x528308: r24 = InstantiateTypeArgumentsStub
    //     0x528308: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x52830c: LoadField: r30 = r24->field_7
    //     0x52830c: ldur            lr, [x24, #7]
    // 0x528310: blr             lr
    // 0x528314: stp             xzr, x0, [SP, #-0x10]!
    // 0x528318: r0 = _GrowableList()
    //     0x528318: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x52831c: add             SP, SP, #0x10
    // 0x528320: mov             x3, x0
    // 0x528324: ldr             x0, [fp, #0x18]
    // 0x528328: stur            x3, [fp, #-0x18]
    // 0x52832c: cmp             w0, NULL
    // 0x528330: b.eq            #0x528418
    // 0x528334: ldur            x4, [fp, #-8]
    // 0x528338: LoadField: r1 = r0->field_7
    //     0x528338: ldur            w1, [x0, #7]
    // 0x52833c: DecompressPointer r1
    //     0x52833c: add             x1, x1, HEAP, lsl #32
    // 0x528340: LoadField: r0 = r1->field_b
    //     0x528340: ldur            w0, [x1, #0xb]
    // 0x528344: DecompressPointer r0
    //     0x528344: add             x0, x0, HEAP, lsl #32
    // 0x528348: stur            x0, [fp, #-0x10]
    // 0x52834c: r1 = Function '<anonymous closure>': static.
    //     0x52834c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f48] AnonymousClosure: static (0x5288a4), in [package:dio/src/dio_mixin.dart] DioMixin::listenCancelForAsyncTask (0x5282ac)
    //     0x528350: ldr             x1, [x1, #0xf48]
    // 0x528354: r2 = Null
    //     0x528354: mov             x2, NULL
    // 0x528358: r0 = AllocateClosure()
    //     0x528358: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52835c: mov             x1, x0
    // 0x528360: ldur            x0, [fp, #-8]
    // 0x528364: StoreField: r1->field_b = r0
    //     0x528364: stur            w0, [x1, #0xb]
    // 0x528368: ldur            x16, [fp, #-0x10]
    // 0x52836c: stp             x16, x0, [SP, #-0x10]!
    // 0x528370: SaveReg r1
    //     0x528370: str             x1, [SP, #-8]!
    // 0x528374: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x528374: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x528378: r0 = then()
    //     0x528378: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x52837c: add             SP, SP, #0x18
    // 0x528380: mov             x1, x0
    // 0x528384: ldur            x0, [fp, #-0x18]
    // 0x528388: stur            x1, [fp, #-0x20]
    // 0x52838c: LoadField: r2 = r0->field_b
    //     0x52838c: ldur            w2, [x0, #0xb]
    // 0x528390: DecompressPointer r2
    //     0x528390: add             x2, x2, HEAP, lsl #32
    // 0x528394: stur            x2, [fp, #-0x10]
    // 0x528398: LoadField: r3 = r0->field_f
    //     0x528398: ldur            w3, [x0, #0xf]
    // 0x52839c: DecompressPointer r3
    //     0x52839c: add             x3, x3, HEAP, lsl #32
    // 0x5283a0: LoadField: r4 = r3->field_b
    //     0x5283a0: ldur            w4, [x3, #0xb]
    // 0x5283a4: DecompressPointer r4
    //     0x5283a4: add             x4, x4, HEAP, lsl #32
    // 0x5283a8: cmp             w2, w4
    // 0x5283ac: b.ne            #0x5283bc
    // 0x5283b0: SaveReg r0
    //     0x5283b0: str             x0, [SP, #-8]!
    // 0x5283b4: r0 = _growToNextCapacity()
    //     0x5283b4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5283b8: add             SP, SP, #8
    // 0x5283bc: ldur            x2, [fp, #-0x18]
    // 0x5283c0: ldur            x0, [fp, #-0x10]
    // 0x5283c4: r3 = LoadInt32Instr(r0)
    //     0x5283c4: sbfx            x3, x0, #1, #0x1f
    // 0x5283c8: add             x0, x3, #1
    // 0x5283cc: lsl             x1, x0, #1
    // 0x5283d0: StoreField: r2->field_b = r1
    //     0x5283d0: stur            w1, [x2, #0xb]
    // 0x5283d4: mov             x1, x3
    // 0x5283d8: cmp             x1, x0
    // 0x5283dc: b.hs            #0x5284cc
    // 0x5283e0: LoadField: r1 = r2->field_f
    //     0x5283e0: ldur            w1, [x2, #0xf]
    // 0x5283e4: DecompressPointer r1
    //     0x5283e4: add             x1, x1, HEAP, lsl #32
    // 0x5283e8: ldur            x0, [fp, #-0x20]
    // 0x5283ec: ArrayStore: r1[r3] = r0  ; List_4
    //     0x5283ec: add             x25, x1, x3, lsl #2
    //     0x5283f0: add             x25, x25, #0xf
    //     0x5283f4: str             w0, [x25]
    //     0x5283f8: tbz             w0, #0, #0x528414
    //     0x5283fc: ldurb           w16, [x1, #-1]
    //     0x528400: ldurb           w17, [x0, #-1]
    //     0x528404: and             x16, x17, x16, lsr #2
    //     0x528408: tst             x16, HEAP, lsr #32
    //     0x52840c: b.eq            #0x528414
    //     0x528410: bl              #0xd67e5c
    // 0x528414: b               #0x52841c
    // 0x528418: mov             x2, x3
    // 0x52841c: LoadField: r0 = r2->field_b
    //     0x52841c: ldur            w0, [x2, #0xb]
    // 0x528420: DecompressPointer r0
    //     0x528420: add             x0, x0, HEAP, lsl #32
    // 0x528424: stur            x0, [fp, #-0x10]
    // 0x528428: LoadField: r1 = r2->field_f
    //     0x528428: ldur            w1, [x2, #0xf]
    // 0x52842c: DecompressPointer r1
    //     0x52842c: add             x1, x1, HEAP, lsl #32
    // 0x528430: LoadField: r3 = r1->field_b
    //     0x528430: ldur            w3, [x1, #0xb]
    // 0x528434: DecompressPointer r3
    //     0x528434: add             x3, x3, HEAP, lsl #32
    // 0x528438: cmp             w0, w3
    // 0x52843c: b.ne            #0x52844c
    // 0x528440: SaveReg r2
    //     0x528440: str             x2, [SP, #-8]!
    // 0x528444: r0 = _growToNextCapacity()
    //     0x528444: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x528448: add             SP, SP, #8
    // 0x52844c: ldur            x2, [fp, #-0x18]
    // 0x528450: ldur            x0, [fp, #-0x10]
    // 0x528454: r3 = LoadInt32Instr(r0)
    //     0x528454: sbfx            x3, x0, #1, #0x1f
    // 0x528458: add             x0, x3, #1
    // 0x52845c: lsl             x1, x0, #1
    // 0x528460: StoreField: r2->field_b = r1
    //     0x528460: stur            w1, [x2, #0xb]
    // 0x528464: mov             x1, x3
    // 0x528468: cmp             x1, x0
    // 0x52846c: b.hs            #0x5284d0
    // 0x528470: LoadField: r1 = r2->field_f
    //     0x528470: ldur            w1, [x2, #0xf]
    // 0x528474: DecompressPointer r1
    //     0x528474: add             x1, x1, HEAP, lsl #32
    // 0x528478: ldr             x0, [fp, #0x10]
    // 0x52847c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x52847c: add             x25, x1, x3, lsl #2
    //     0x528480: add             x25, x25, #0xf
    //     0x528484: str             w0, [x25]
    //     0x528488: tbz             w0, #0, #0x5284a4
    //     0x52848c: ldurb           w16, [x1, #-1]
    //     0x528490: ldurb           w17, [x0, #-1]
    //     0x528494: and             x16, x17, x16, lsr #2
    //     0x528498: tst             x16, HEAP, lsr #32
    //     0x52849c: b.eq            #0x5284a4
    //     0x5284a0: bl              #0xd67e5c
    // 0x5284a4: ldur            x16, [fp, #-8]
    // 0x5284a8: stp             x2, x16, [SP, #-0x10]!
    // 0x5284ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x5284ac: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x5284b0: r0 = any()
    //     0x5284b0: bl              #0x5284d4  ; [dart:async] Future::any
    // 0x5284b4: add             SP, SP, #0x10
    // 0x5284b8: LeaveFrame
    //     0x5284b8: mov             SP, fp
    //     0x5284bc: ldp             fp, lr, [SP], #0x10
    // 0x5284c0: ret
    //     0x5284c0: ret             
    // 0x5284c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5284c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5284c8: b               #0x5282f8
    // 0x5284cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5284cc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5284d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5284d0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] static Never <anonymous closure>(dynamic, DioException) {
    // ** addr: 0x5288a4, size: 0x14
    // 0x5288a4: EnterFrame
    //     0x5288a4: stp             fp, lr, [SP, #-0x10]!
    //     0x5288a8: mov             fp, SP
    // 0x5288ac: ldr             x0, [fp, #0x10]
    // 0x5288b0: r0 = Throw()
    //     0x5288b0: bl              #0xd67e38  ; ThrowStub
    // 0x5288b4: brk             #0
  }
  static _ assureDioException(/* No info */) {
    // ** addr: 0x528ea4, size: 0x84
    // 0x528ea4: EnterFrame
    //     0x528ea4: stp             fp, lr, [SP, #-0x10]!
    //     0x528ea8: mov             fp, SP
    // 0x528eac: AllocStack(0x8)
    //     0x528eac: sub             SP, SP, #8
    // 0x528eb0: CheckStackOverflow
    //     0x528eb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x528eb4: cmp             SP, x16
    //     0x528eb8: b.ls            #0x528f20
    // 0x528ebc: ldr             x0, [fp, #0x18]
    // 0x528ec0: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x528ec0: mov             x1, #0x76
    //     0x528ec4: tbz             w0, #0, #0x528ed4
    //     0x528ec8: ldur            x1, [x0, #-1]
    //     0x528ecc: ubfx            x1, x1, #0xc, #0x14
    //     0x528ed0: lsl             x1, x1, #1
    // 0x528ed4: r17 = 9088
    //     0x528ed4: mov             x17, #0x2380
    // 0x528ed8: cmp             w1, w17
    // 0x528edc: b.ne            #0x528eec
    // 0x528ee0: LeaveFrame
    //     0x528ee0: mov             SP, fp
    //     0x528ee4: ldp             fp, lr, [SP], #0x10
    // 0x528ee8: ret
    //     0x528ee8: ret             
    // 0x528eec: r0 = DioException()
    //     0x528eec: bl              #0x5273c4  ; AllocateDioExceptionStub -> DioException (size=0x1c)
    // 0x528ef0: stur            x0, [fp, #-8]
    // 0x528ef4: ldr             x16, [fp, #0x18]
    // 0x528ef8: stp             x16, x0, [SP, #-0x10]!
    // 0x528efc: ldr             x16, [fp, #0x10]
    // 0x528f00: SaveReg r16
    //     0x528f00: str             x16, [SP, #-8]!
    // 0x528f04: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x528f04: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x528f08: r0 = DioException()
    //     0x528f08: bl              #0x527134  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x528f0c: add             SP, SP, #0x18
    // 0x528f10: ldur            x0, [fp, #-8]
    // 0x528f14: LeaveFrame
    //     0x528f14: mov             SP, fp
    //     0x528f18: ldp             fp, lr, [SP], #0x10
    // 0x528f1c: ret
    //     0x528f1c: ret             
    // 0x528f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x528f20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x528f24: b               #0x528ebc
  }
  static _ assureResponse(/* No info */) {
    // ** addr: 0x5291d8, size: 0x2b4
    // 0x5291d8: EnterFrame
    //     0x5291d8: stp             fp, lr, [SP, #-0x10]!
    //     0x5291dc: mov             fp, SP
    // 0x5291e0: AllocStack(0x48)
    //     0x5291e0: sub             SP, SP, #0x48
    // 0x5291e4: SetupParameters()
    //     0x5291e4: mov             x0, x4
    //     0x5291e8: ldur            w1, [x0, #0xf]
    //     0x5291ec: add             x1, x1, HEAP, lsl #32
    //     0x5291f0: cbnz            w1, #0x5291fc
    //     0x5291f4: mov             x4, NULL
    //     0x5291f8: b               #0x529210
    //     0x5291fc: ldur            w1, [x0, #0x17]
    //     0x529200: add             x1, x1, HEAP, lsl #32
    //     0x529204: add             x0, fp, w1, sxtw #2
    //     0x529208: ldr             x0, [x0, #0x10]
    //     0x52920c: mov             x4, x0
    //     0x529210: ldr             x3, [fp, #0x18]
    //     0x529214: stur            x4, [fp, #-8]
    // 0x529218: CheckStackOverflow
    //     0x529218: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52921c: cmp             SP, x16
    //     0x529220: b.ls            #0x529484
    // 0x529224: r0 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0x529224: mov             x0, #0x76
    //     0x529228: tbz             w3, #0, #0x529238
    //     0x52922c: ldur            x0, [x3, #-1]
    //     0x529230: ubfx            x0, x0, #0xc, #0x14
    //     0x529234: lsl             x0, x0, #1
    // 0x529238: r17 = 9052
    //     0x529238: mov             x17, #0x235c
    // 0x52923c: cmp             w0, w17
    // 0x529240: b.eq            #0x5292b0
    // 0x529244: mov             x0, x3
    // 0x529248: mov             x1, x4
    // 0x52924c: r2 = Null
    //     0x52924c: mov             x2, NULL
    // 0x529250: cmp             w1, NULL
    // 0x529254: b.eq            #0x529274
    // 0x529258: LoadField: r4 = r1->field_17
    //     0x529258: ldur            w4, [x1, #0x17]
    // 0x52925c: DecompressPointer r4
    //     0x52925c: add             x4, x4, HEAP, lsl #32
    // 0x529260: r8 = Y0
    //     0x529260: ldr             x8, [PP, #0x51b8]  ; [pp+0x51b8] TypeParameter: Y0
    // 0x529264: LoadField: r9 = r4->field_7
    //     0x529264: ldur            x9, [x4, #7]
    // 0x529268: r3 = Null
    //     0x529268: add             x3, PP, #0x12, lsl #12  ; [pp+0x12fc0] Null
    //     0x52926c: ldr             x3, [x3, #0xfc0]
    // 0x529270: blr             x9
    // 0x529274: ldur            x1, [fp, #-8]
    // 0x529278: r0 = Response()
    //     0x529278: bl              #0x52a5a8  ; AllocateResponseStub -> Response<X0> (size=0x2c)
    // 0x52927c: stur            x0, [fp, #-0x10]
    // 0x529280: ldr             x16, [fp, #0x10]
    // 0x529284: stp             x16, x0, [SP, #-0x10]!
    // 0x529288: ldr             x16, [fp, #0x18]
    // 0x52928c: SaveReg r16
    //     0x52928c: str             x16, [SP, #-8]!
    // 0x529290: r4 = const [0, 0x3, 0x3, 0x2, data, 0x2, null]
    //     0x529290: add             x4, PP, #0x12, lsl #12  ; [pp+0x12fd0] List(7) [0, 0x3, 0x3, 0x2, "data", 0x2, Null]
    //     0x529294: ldr             x4, [x4, #0xfd0]
    // 0x529298: r0 = Response()
    //     0x529298: bl              #0x52a1d8  ; [package:dio/src/response.dart] Response::Response
    // 0x52929c: add             SP, SP, #0x18
    // 0x5292a0: ldur            x0, [fp, #-0x10]
    // 0x5292a4: LeaveFrame
    //     0x5292a4: mov             SP, fp
    //     0x5292a8: ldp             fp, lr, [SP], #0x10
    // 0x5292ac: ret
    //     0x5292ac: ret             
    // 0x5292b0: ldr             x0, [fp, #0x18]
    // 0x5292b4: ldur            x1, [fp, #-8]
    // 0x5292b8: r2 = Null
    //     0x5292b8: mov             x2, NULL
    // 0x5292bc: cmp             w0, NULL
    // 0x5292c0: b.eq            #0x529314
    // 0x5292c4: branchIfSmi(r0, 0x529314)
    //     0x5292c4: tbz             w0, #0, #0x529314
    // 0x5292c8: r8 = Response<Y0>
    //     0x5292c8: add             x8, PP, #0x12, lsl #12  ; [pp+0x12fd8] Type: Response<Y0>
    //     0x5292cc: ldr             x8, [x8, #0xfd8]
    // 0x5292d0: r3 = SubtypeTestCache
    //     0x5292d0: add             x3, PP, #0x12, lsl #12  ; [pp+0x12fe0] SubtypeTestCache
    //     0x5292d4: ldr             x3, [x3, #0xfe0]
    // 0x5292d8: r24 = Subtype5TestCacheStub
    //     0x5292d8: ldr             x24, [PP, #0xc78]  ; [pp+0xc78] Stub: Subtype5TestCache (0x4ae1bc)
    // 0x5292dc: LoadField: r30 = r24->field_7
    //     0x5292dc: ldur            lr, [x24, #7]
    // 0x5292e0: blr             lr
    // 0x5292e4: cmp             w7, NULL
    // 0x5292e8: b.eq            #0x5292f4
    // 0x5292ec: tbnz            w7, #4, #0x529314
    // 0x5292f0: b               #0x52931c
    // 0x5292f4: r8 = Response<Y0>
    //     0x5292f4: add             x8, PP, #0x12, lsl #12  ; [pp+0x12fe8] Type: Response<Y0>
    //     0x5292f8: ldr             x8, [x8, #0xfe8]
    // 0x5292fc: r3 = SubtypeTestCache
    //     0x5292fc: add             x3, PP, #0x12, lsl #12  ; [pp+0x12ff0] SubtypeTestCache
    //     0x529300: ldr             x3, [x3, #0xff0]
    // 0x529304: r24 = InstanceOfStub
    //     0x529304: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x529308: LoadField: r30 = r24->field_7
    //     0x529308: ldur            lr, [x24, #7]
    // 0x52930c: blr             lr
    // 0x529310: b               #0x529320
    // 0x529314: r0 = false
    //     0x529314: add             x0, NULL, #0x30  ; false
    // 0x529318: b               #0x529320
    // 0x52931c: r0 = true
    //     0x52931c: add             x0, NULL, #0x20  ; true
    // 0x529320: tbz             w0, #4, #0x529474
    // 0x529324: ldr             x3, [fp, #0x18]
    // 0x529328: LoadField: r4 = r3->field_b
    //     0x529328: ldur            w4, [x3, #0xb]
    // 0x52932c: DecompressPointer r4
    //     0x52932c: add             x4, x4, HEAP, lsl #32
    // 0x529330: mov             x0, x4
    // 0x529334: ldur            x1, [fp, #-8]
    // 0x529338: stur            x4, [fp, #-0x10]
    // 0x52933c: r2 = Null
    //     0x52933c: mov             x2, NULL
    // 0x529340: cmp             w0, NULL
    // 0x529344: b.eq            #0x52936c
    // 0x529348: cmp             w1, NULL
    // 0x52934c: b.eq            #0x52936c
    // 0x529350: LoadField: r4 = r1->field_17
    //     0x529350: ldur            w4, [x1, #0x17]
    // 0x529354: DecompressPointer r4
    //     0x529354: add             x4, x4, HEAP, lsl #32
    // 0x529358: r8 = Y0?
    //     0x529358: ldr             x8, [PP, #0x3600]  ; [pp+0x3600] TypeParameter: Y0?
    // 0x52935c: LoadField: r9 = r4->field_7
    //     0x52935c: ldur            x9, [x4, #7]
    // 0x529360: r3 = Null
    //     0x529360: add             x3, PP, #0x12, lsl #12  ; [pp+0x12ff8] Null
    //     0x529364: ldr             x3, [x3, #0xff8]
    // 0x529368: blr             x9
    // 0x52936c: ldur            x0, [fp, #-0x10]
    // 0x529370: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x529370: mov             x1, #0x76
    //     0x529374: tbz             w0, #0, #0x529384
    //     0x529378: ldur            x1, [x0, #-1]
    //     0x52937c: ubfx            x1, x1, #0xc, #0x14
    //     0x529380: lsl             x1, x1, #1
    // 0x529384: r17 = 9104
    //     0x529384: mov             x17, #0x2390
    // 0x529388: cmp             w1, w17
    // 0x52938c: b.ne            #0x5293c0
    // 0x529390: LoadField: r1 = r0->field_b
    //     0x529390: ldur            w1, [x0, #0xb]
    // 0x529394: DecompressPointer r1
    //     0x529394: add             x1, x1, HEAP, lsl #32
    // 0x529398: stur            x1, [fp, #-0x18]
    // 0x52939c: r0 = Headers()
    //     0x52939c: bl              #0x52a1cc  ; AllocateHeadersStub -> Headers (size=0xc)
    // 0x5293a0: stur            x0, [fp, #-0x20]
    // 0x5293a4: ldur            x16, [fp, #-0x18]
    // 0x5293a8: stp             x16, x0, [SP, #-0x10]!
    // 0x5293ac: r0 = Headers.fromMap()
    //     0x5293ac: bl              #0x52948c  ; [package:dio/src/headers.dart] Headers::Headers.fromMap
    // 0x5293b0: add             SP, SP, #0x10
    // 0x5293b4: ldur            x3, [fp, #-0x20]
    // 0x5293b8: ldr             x0, [fp, #0x18]
    // 0x5293bc: b               #0x5293d0
    // 0x5293c0: ldr             x0, [fp, #0x18]
    // 0x5293c4: LoadField: r1 = r0->field_27
    //     0x5293c4: ldur            w1, [x0, #0x27]
    // 0x5293c8: DecompressPointer r1
    //     0x5293c8: add             x1, x1, HEAP, lsl #32
    // 0x5293cc: mov             x3, x1
    // 0x5293d0: ldur            x2, [fp, #-0x10]
    // 0x5293d4: stur            x3, [fp, #-0x48]
    // 0x5293d8: LoadField: r4 = r0->field_f
    //     0x5293d8: ldur            w4, [x0, #0xf]
    // 0x5293dc: DecompressPointer r4
    //     0x5293dc: add             x4, x4, HEAP, lsl #32
    // 0x5293e0: stur            x4, [fp, #-0x40]
    // 0x5293e4: LoadField: r5 = r0->field_13
    //     0x5293e4: ldur            w5, [x0, #0x13]
    // 0x5293e8: DecompressPointer r5
    //     0x5293e8: add             x5, x5, HEAP, lsl #32
    // 0x5293ec: stur            x5, [fp, #-0x38]
    // 0x5293f0: LoadField: r6 = r0->field_1b
    //     0x5293f0: ldur            w6, [x0, #0x1b]
    // 0x5293f4: DecompressPointer r6
    //     0x5293f4: add             x6, x6, HEAP, lsl #32
    // 0x5293f8: stur            x6, [fp, #-0x30]
    // 0x5293fc: LoadField: r7 = r0->field_1f
    //     0x5293fc: ldur            w7, [x0, #0x1f]
    // 0x529400: DecompressPointer r7
    //     0x529400: add             x7, x7, HEAP, lsl #32
    // 0x529404: stur            x7, [fp, #-0x28]
    // 0x529408: LoadField: r8 = r0->field_17
    //     0x529408: ldur            w8, [x0, #0x17]
    // 0x52940c: DecompressPointer r8
    //     0x52940c: add             x8, x8, HEAP, lsl #32
    // 0x529410: stur            x8, [fp, #-0x20]
    // 0x529414: LoadField: r9 = r0->field_23
    //     0x529414: ldur            w9, [x0, #0x23]
    // 0x529418: DecompressPointer r9
    //     0x529418: add             x9, x9, HEAP, lsl #32
    // 0x52941c: ldur            x1, [fp, #-8]
    // 0x529420: stur            x9, [fp, #-0x18]
    // 0x529424: r0 = Response()
    //     0x529424: bl              #0x52a5a8  ; AllocateResponseStub -> Response<X0> (size=0x2c)
    // 0x529428: ldur            x1, [fp, #-0x10]
    // 0x52942c: StoreField: r0->field_b = r1
    //     0x52942c: stur            w1, [x0, #0xb]
    // 0x529430: ldur            x1, [fp, #-0x40]
    // 0x529434: StoreField: r0->field_f = r1
    //     0x529434: stur            w1, [x0, #0xf]
    // 0x529438: ldur            x1, [fp, #-0x38]
    // 0x52943c: StoreField: r0->field_13 = r1
    //     0x52943c: stur            w1, [x0, #0x13]
    // 0x529440: ldur            x1, [fp, #-0x20]
    // 0x529444: StoreField: r0->field_17 = r1
    //     0x529444: stur            w1, [x0, #0x17]
    // 0x529448: ldur            x1, [fp, #-0x30]
    // 0x52944c: StoreField: r0->field_1b = r1
    //     0x52944c: stur            w1, [x0, #0x1b]
    // 0x529450: ldur            x1, [fp, #-0x28]
    // 0x529454: StoreField: r0->field_1f = r1
    //     0x529454: stur            w1, [x0, #0x1f]
    // 0x529458: ldur            x1, [fp, #-0x18]
    // 0x52945c: StoreField: r0->field_23 = r1
    //     0x52945c: stur            w1, [x0, #0x23]
    // 0x529460: ldur            x1, [fp, #-0x48]
    // 0x529464: StoreField: r0->field_27 = r1
    //     0x529464: stur            w1, [x0, #0x27]
    // 0x529468: LeaveFrame
    //     0x529468: mov             SP, fp
    //     0x52946c: ldp             fp, lr, [SP], #0x10
    // 0x529470: ret
    //     0x529470: ret             
    // 0x529474: ldr             x0, [fp, #0x18]
    // 0x529478: LeaveFrame
    //     0x529478: mov             SP, fp
    //     0x52947c: ldp             fp, lr, [SP], #0x10
    // 0x529480: ret
    //     0x529480: ret             
    // 0x529484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x529484: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x529488: b               #0x529224
  }
  static _ checkCancelled(/* No info */) {
    // ** addr: 0x52ade0, size: 0x48
    // 0x52ade0: EnterFrame
    //     0x52ade0: stp             fp, lr, [SP, #-0x10]!
    //     0x52ade4: mov             fp, SP
    // 0x52ade8: ldr             x0, [fp, #0x10]
    // 0x52adec: cmp             w0, NULL
    // 0x52adf0: b.ne            #0x52adfc
    // 0x52adf4: r0 = Null
    //     0x52adf4: mov             x0, NULL
    // 0x52adf8: b               #0x52ae08
    // 0x52adfc: LoadField: r1 = r0->field_b
    //     0x52adfc: ldur            w1, [x0, #0xb]
    // 0x52ae00: DecompressPointer r1
    //     0x52ae00: add             x1, x1, HEAP, lsl #32
    // 0x52ae04: mov             x0, x1
    // 0x52ae08: cmp             w0, NULL
    // 0x52ae0c: b.ne            #0x52ae20
    // 0x52ae10: r0 = Null
    //     0x52ae10: mov             x0, NULL
    // 0x52ae14: LeaveFrame
    //     0x52ae14: mov             SP, fp
    //     0x52ae18: ldp             fp, lr, [SP], #0x10
    // 0x52ae1c: ret
    //     0x52ae1c: ret             
    // 0x52ae20: r0 = Throw()
    //     0x52ae20: bl              #0xd67e38  ; ThrowStub
    // 0x52ae24: brk             #0
  }
  static _ checkOptions(/* No info */) {
    // ** addr: 0x8c5fe0, size: 0x20
    // 0x8c5fe0: EnterFrame
    //     0x8c5fe0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c5fe4: mov             fp, SP
    // 0x8c5fe8: r0 = Options()
    //     0x8c5fe8: bl              #0x55c058  ; AllocateOptionsStub -> Options (size=0x44)
    // 0x8c5fec: ldr             x1, [fp, #0x18]
    // 0x8c5ff0: StoreField: r0->field_7 = r1
    //     0x8c5ff0: stur            w1, [x0, #7]
    // 0x8c5ff4: LeaveFrame
    //     0x8c5ff4: mov             SP, fp
    //     0x8c5ff8: ldp             fp, lr, [SP], #0x10
    // 0x8c5ffc: ret
    //     0x8c5ffc: ret             
  }
}

// class id: 5461, size: 0x10, field offset: 0xc
class Interceptors extends ListMixin<Interceptor> {

  int length(Interceptors) {
    // ** addr: 0x7174d0, size: 0x30
    // 0x7174d0: ldr             x1, [SP]
    // 0x7174d4: LoadField: r2 = r1->field_b
    //     0x7174d4: ldur            w2, [x1, #0xb]
    // 0x7174d8: DecompressPointer r2
    //     0x7174d8: add             x2, x2, HEAP, lsl #32
    // 0x7174dc: LoadField: r0 = r2->field_b
    //     0x7174dc: ldur            w0, [x2, #0xb]
    // 0x7174e0: DecompressPointer r0
    //     0x7174e0: add             x0, x0, HEAP, lsl #32
    // 0x7174e4: ret
    //     0x7174e4: ret             
  }
  void []=(Interceptors, int, Interceptor) {
    // ** addr: 0x4c1a1c, size: 0x23c
    // 0x4c1a1c: EnterFrame
    //     0x4c1a1c: stp             fp, lr, [SP, #-0x10]!
    //     0x4c1a20: mov             fp, SP
    // 0x4c1a24: AllocStack(0x20)
    //     0x4c1a24: sub             SP, SP, #0x20
    // 0x4c1a28: CheckStackOverflow
    //     0x4c1a28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c1a2c: cmp             SP, x16
    //     0x4c1a30: b.ls            #0x4c1c30
    // 0x4c1a34: ldr             x0, [fp, #0x18]
    // 0x4c1a38: r2 = Null
    //     0x4c1a38: mov             x2, NULL
    // 0x4c1a3c: r1 = Null
    //     0x4c1a3c: mov             x1, NULL
    // 0x4c1a40: branchIfSmi(r0, 0x4c1a68)
    //     0x4c1a40: tbz             w0, #0, #0x4c1a68
    // 0x4c1a44: r4 = LoadClassIdInstr(r0)
    //     0x4c1a44: ldur            x4, [x0, #-1]
    //     0x4c1a48: ubfx            x4, x4, #0xc, #0x14
    // 0x4c1a4c: sub             x4, x4, #0x3b
    // 0x4c1a50: cmp             x4, #1
    // 0x4c1a54: b.ls            #0x4c1a68
    // 0x4c1a58: r8 = int
    //     0x4c1a58: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0x4c1a5c: r3 = Null
    //     0x4c1a5c: add             x3, PP, #0x41, lsl #12  ; [pp+0x410b0] Null
    //     0x4c1a60: ldr             x3, [x3, #0xb0]
    // 0x4c1a64: r0 = int()
    //     0x4c1a64: bl              #0xd73714  ; IsType_int_Stub
    // 0x4c1a68: ldr             x0, [fp, #0x10]
    // 0x4c1a6c: r2 = Null
    //     0x4c1a6c: mov             x2, NULL
    // 0x4c1a70: r1 = Null
    //     0x4c1a70: mov             x1, NULL
    // 0x4c1a74: r4 = 59
    //     0x4c1a74: mov             x4, #0x3b
    // 0x4c1a78: branchIfSmi(r0, 0x4c1a84)
    //     0x4c1a78: tbz             w0, #0, #0x4c1a84
    // 0x4c1a7c: r4 = LoadClassIdInstr(r0)
    //     0x4c1a7c: ldur            x4, [x0, #-1]
    //     0x4c1a80: ubfx            x4, x4, #0xc, #0x14
    // 0x4c1a84: r17 = 4538
    //     0x4c1a84: mov             x17, #0x11ba
    // 0x4c1a88: cmp             x4, x17
    // 0x4c1a8c: b.eq            #0x4c1aa4
    // 0x4c1a90: r8 = Interceptor
    //     0x4c1a90: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d5e8] Type: Interceptor
    //     0x4c1a94: ldr             x8, [x8, #0x5e8]
    // 0x4c1a98: r3 = Null
    //     0x4c1a98: add             x3, PP, #0x41, lsl #12  ; [pp+0x410c0] Null
    //     0x4c1a9c: ldr             x3, [x3, #0xc0]
    // 0x4c1aa0: r0 = Interceptor()
    //     0x4c1aa0: bl              #0x4c19e0  ; IsType_Interceptor_Stub
    // 0x4c1aa4: ldr             x0, [fp, #0x20]
    // 0x4c1aa8: LoadField: r3 = r0->field_b
    //     0x4c1aa8: ldur            w3, [x0, #0xb]
    // 0x4c1aac: DecompressPointer r3
    //     0x4c1aac: add             x3, x3, HEAP, lsl #32
    // 0x4c1ab0: stur            x3, [fp, #-0x18]
    // 0x4c1ab4: LoadField: r4 = r3->field_b
    //     0x4c1ab4: ldur            w4, [x3, #0xb]
    // 0x4c1ab8: DecompressPointer r4
    //     0x4c1ab8: add             x4, x4, HEAP, lsl #32
    // 0x4c1abc: ldr             x0, [fp, #0x18]
    // 0x4c1ac0: stur            x4, [fp, #-0x10]
    // 0x4c1ac4: r5 = LoadInt32Instr(r0)
    //     0x4c1ac4: sbfx            x5, x0, #1, #0x1f
    //     0x4c1ac8: tbz             w0, #0, #0x4c1ad0
    //     0x4c1acc: ldur            x5, [x0, #7]
    // 0x4c1ad0: stur            x5, [fp, #-0x20]
    // 0x4c1ad4: r6 = LoadInt32Instr(r4)
    //     0x4c1ad4: sbfx            x6, x4, #1, #0x1f
    // 0x4c1ad8: stur            x6, [fp, #-8]
    // 0x4c1adc: cmp             x6, x5
    // 0x4c1ae0: b.ne            #0x4c1b9c
    // 0x4c1ae4: LoadField: r2 = r3->field_7
    //     0x4c1ae4: ldur            w2, [x3, #7]
    // 0x4c1ae8: DecompressPointer r2
    //     0x4c1ae8: add             x2, x2, HEAP, lsl #32
    // 0x4c1aec: ldr             x0, [fp, #0x10]
    // 0x4c1af0: r1 = Null
    //     0x4c1af0: mov             x1, NULL
    // 0x4c1af4: cmp             w2, NULL
    // 0x4c1af8: b.eq            #0x4c1b18
    // 0x4c1afc: LoadField: r4 = r2->field_17
    //     0x4c1afc: ldur            w4, [x2, #0x17]
    // 0x4c1b00: DecompressPointer r4
    //     0x4c1b00: add             x4, x4, HEAP, lsl #32
    // 0x4c1b04: r8 = X0
    //     0x4c1b04: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x4c1b08: LoadField: r9 = r4->field_7
    //     0x4c1b08: ldur            x9, [x4, #7]
    // 0x4c1b0c: r3 = Null
    //     0x4c1b0c: add             x3, PP, #0x41, lsl #12  ; [pp+0x410d0] Null
    //     0x4c1b10: ldr             x3, [x3, #0xd0]
    // 0x4c1b14: blr             x9
    // 0x4c1b18: ldur            x0, [fp, #-0x18]
    // 0x4c1b1c: LoadField: r1 = r0->field_f
    //     0x4c1b1c: ldur            w1, [x0, #0xf]
    // 0x4c1b20: DecompressPointer r1
    //     0x4c1b20: add             x1, x1, HEAP, lsl #32
    // 0x4c1b24: LoadField: r2 = r1->field_b
    //     0x4c1b24: ldur            w2, [x1, #0xb]
    // 0x4c1b28: DecompressPointer r2
    //     0x4c1b28: add             x2, x2, HEAP, lsl #32
    // 0x4c1b2c: ldur            x1, [fp, #-0x10]
    // 0x4c1b30: cmp             w1, w2
    // 0x4c1b34: b.ne            #0x4c1b44
    // 0x4c1b38: SaveReg r0
    //     0x4c1b38: str             x0, [SP, #-8]!
    // 0x4c1b3c: r0 = _growToNextCapacity()
    //     0x4c1b3c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4c1b40: add             SP, SP, #8
    // 0x4c1b44: ldur            x3, [fp, #-0x18]
    // 0x4c1b48: ldur            x4, [fp, #-8]
    // 0x4c1b4c: add             x0, x4, #1
    // 0x4c1b50: lsl             x1, x0, #1
    // 0x4c1b54: StoreField: r3->field_b = r1
    //     0x4c1b54: stur            w1, [x3, #0xb]
    // 0x4c1b58: mov             x1, x4
    // 0x4c1b5c: cmp             x1, x0
    // 0x4c1b60: b.hs            #0x4c1c38
    // 0x4c1b64: LoadField: r1 = r3->field_f
    //     0x4c1b64: ldur            w1, [x3, #0xf]
    // 0x4c1b68: DecompressPointer r1
    //     0x4c1b68: add             x1, x1, HEAP, lsl #32
    // 0x4c1b6c: ldr             x0, [fp, #0x10]
    // 0x4c1b70: ArrayStore: r1[r4] = r0  ; List_4
    //     0x4c1b70: add             x25, x1, x4, lsl #2
    //     0x4c1b74: add             x25, x25, #0xf
    //     0x4c1b78: str             w0, [x25]
    //     0x4c1b7c: tbz             w0, #0, #0x4c1b98
    //     0x4c1b80: ldurb           w16, [x1, #-1]
    //     0x4c1b84: ldurb           w17, [x0, #-1]
    //     0x4c1b88: and             x16, x17, x16, lsr #2
    //     0x4c1b8c: tst             x16, HEAP, lsr #32
    //     0x4c1b90: b.eq            #0x4c1b98
    //     0x4c1b94: bl              #0xd67e5c
    // 0x4c1b98: b               #0x4c1c20
    // 0x4c1b9c: mov             x4, x6
    // 0x4c1ba0: LoadField: r2 = r3->field_7
    //     0x4c1ba0: ldur            w2, [x3, #7]
    // 0x4c1ba4: DecompressPointer r2
    //     0x4c1ba4: add             x2, x2, HEAP, lsl #32
    // 0x4c1ba8: ldr             x0, [fp, #0x10]
    // 0x4c1bac: r1 = Null
    //     0x4c1bac: mov             x1, NULL
    // 0x4c1bb0: cmp             w2, NULL
    // 0x4c1bb4: b.eq            #0x4c1bd4
    // 0x4c1bb8: LoadField: r4 = r2->field_17
    //     0x4c1bb8: ldur            w4, [x2, #0x17]
    // 0x4c1bbc: DecompressPointer r4
    //     0x4c1bbc: add             x4, x4, HEAP, lsl #32
    // 0x4c1bc0: r8 = X0
    //     0x4c1bc0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x4c1bc4: LoadField: r9 = r4->field_7
    //     0x4c1bc4: ldur            x9, [x4, #7]
    // 0x4c1bc8: r3 = Null
    //     0x4c1bc8: add             x3, PP, #0x41, lsl #12  ; [pp+0x410e0] Null
    //     0x4c1bcc: ldr             x3, [x3, #0xe0]
    // 0x4c1bd0: blr             x9
    // 0x4c1bd4: ldur            x0, [fp, #-8]
    // 0x4c1bd8: ldur            x1, [fp, #-0x20]
    // 0x4c1bdc: cmp             x1, x0
    // 0x4c1be0: b.hs            #0x4c1c3c
    // 0x4c1be4: ldur            x2, [fp, #-0x18]
    // 0x4c1be8: LoadField: r1 = r2->field_f
    //     0x4c1be8: ldur            w1, [x2, #0xf]
    // 0x4c1bec: DecompressPointer r1
    //     0x4c1bec: add             x1, x1, HEAP, lsl #32
    // 0x4c1bf0: ldr             x0, [fp, #0x10]
    // 0x4c1bf4: ldur            x2, [fp, #-0x20]
    // 0x4c1bf8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x4c1bf8: add             x25, x1, x2, lsl #2
    //     0x4c1bfc: add             x25, x25, #0xf
    //     0x4c1c00: str             w0, [x25]
    //     0x4c1c04: tbz             w0, #0, #0x4c1c20
    //     0x4c1c08: ldurb           w16, [x1, #-1]
    //     0x4c1c0c: ldurb           w17, [x0, #-1]
    //     0x4c1c10: and             x16, x17, x16, lsr #2
    //     0x4c1c14: tst             x16, HEAP, lsr #32
    //     0x4c1c18: b.eq            #0x4c1c20
    //     0x4c1c1c: bl              #0xd67e5c
    // 0x4c1c20: r0 = Null
    //     0x4c1c20: mov             x0, NULL
    // 0x4c1c24: LeaveFrame
    //     0x4c1c24: mov             SP, fp
    //     0x4c1c28: ldp             fp, lr, [SP], #0x10
    // 0x4c1c2c: ret
    //     0x4c1c2c: ret             
    // 0x4c1c30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c1c30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c1c34: b               #0x4c1a34
    // 0x4c1c38: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4c1c38: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4c1c3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4c1c3c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  Interceptor [](Interceptors, int) {
    // ** addr: 0x4c1c58, size: 0xb8
    // 0x4c1c58: EnterFrame
    //     0x4c1c58: stp             fp, lr, [SP, #-0x10]!
    //     0x4c1c5c: mov             fp, SP
    // 0x4c1c60: ldr             x0, [fp, #0x10]
    // 0x4c1c64: r2 = Null
    //     0x4c1c64: mov             x2, NULL
    // 0x4c1c68: r1 = Null
    //     0x4c1c68: mov             x1, NULL
    // 0x4c1c6c: branchIfSmi(r0, 0x4c1c94)
    //     0x4c1c6c: tbz             w0, #0, #0x4c1c94
    // 0x4c1c70: r4 = LoadClassIdInstr(r0)
    //     0x4c1c70: ldur            x4, [x0, #-1]
    //     0x4c1c74: ubfx            x4, x4, #0xc, #0x14
    // 0x4c1c78: sub             x4, x4, #0x3b
    // 0x4c1c7c: cmp             x4, #1
    // 0x4c1c80: b.ls            #0x4c1c94
    // 0x4c1c84: r8 = int
    //     0x4c1c84: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0x4c1c88: r3 = Null
    //     0x4c1c88: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d620] Null
    //     0x4c1c8c: ldr             x3, [x3, #0x620]
    // 0x4c1c90: r0 = int()
    //     0x4c1c90: bl              #0xd73714  ; IsType_int_Stub
    // 0x4c1c94: ldr             x2, [fp, #0x18]
    // 0x4c1c98: LoadField: r3 = r2->field_b
    //     0x4c1c98: ldur            w3, [x2, #0xb]
    // 0x4c1c9c: DecompressPointer r3
    //     0x4c1c9c: add             x3, x3, HEAP, lsl #32
    // 0x4c1ca0: LoadField: r2 = r3->field_b
    //     0x4c1ca0: ldur            w2, [x3, #0xb]
    // 0x4c1ca4: DecompressPointer r2
    //     0x4c1ca4: add             x2, x2, HEAP, lsl #32
    // 0x4c1ca8: ldr             x4, [fp, #0x10]
    // 0x4c1cac: r5 = LoadInt32Instr(r4)
    //     0x4c1cac: sbfx            x5, x4, #1, #0x1f
    //     0x4c1cb0: tbz             w4, #0, #0x4c1cb8
    //     0x4c1cb4: ldur            x5, [x4, #7]
    // 0x4c1cb8: r0 = LoadInt32Instr(r2)
    //     0x4c1cb8: sbfx            x0, x2, #1, #0x1f
    // 0x4c1cbc: mov             x1, x5
    // 0x4c1cc0: cmp             x1, x0
    // 0x4c1cc4: b.hs            #0x4c1cf0
    // 0x4c1cc8: LoadField: r1 = r3->field_f
    //     0x4c1cc8: ldur            w1, [x3, #0xf]
    // 0x4c1ccc: DecompressPointer r1
    //     0x4c1ccc: add             x1, x1, HEAP, lsl #32
    // 0x4c1cd0: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0x4c1cd0: add             x16, x1, x5, lsl #2
    //     0x4c1cd4: ldur            w0, [x16, #0xf]
    // 0x4c1cd8: DecompressPointer r0
    //     0x4c1cd8: add             x0, x0, HEAP, lsl #32
    // 0x4c1cdc: cmp             w0, NULL
    // 0x4c1ce0: b.eq            #0x4c1cf4
    // 0x4c1ce4: LeaveFrame
    //     0x4c1ce4: mov             SP, fp
    //     0x4c1ce8: ldp             fp, lr, [SP], #0x10
    // 0x4c1cec: ret
    //     0x4c1cec: ret             
    // 0x4c1cf0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4c1cf0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4c1cf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4c1cf4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ length=(/* No info */) {
    // ** addr: 0x4c7b48, size: 0x4c
    // 0x4c7b48: EnterFrame
    //     0x4c7b48: stp             fp, lr, [SP, #-0x10]!
    //     0x4c7b4c: mov             fp, SP
    // 0x4c7b50: CheckStackOverflow
    //     0x4c7b50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c7b54: cmp             SP, x16
    //     0x4c7b58: b.ls            #0x4c7b8c
    // 0x4c7b5c: ldr             x0, [fp, #0x18]
    // 0x4c7b60: LoadField: r1 = r0->field_b
    //     0x4c7b60: ldur            w1, [x0, #0xb]
    // 0x4c7b64: DecompressPointer r1
    //     0x4c7b64: add             x1, x1, HEAP, lsl #32
    // 0x4c7b68: SaveReg r1
    //     0x4c7b68: str             x1, [SP, #-8]!
    // 0x4c7b6c: ldr             x0, [fp, #0x10]
    // 0x4c7b70: SaveReg r0
    //     0x4c7b70: str             x0, [SP, #-8]!
    // 0x4c7b74: r0 = length=()
    //     0x4c7b74: bl              #0x5efc5c  ; [dart:core] _GrowableList::length=
    // 0x4c7b78: add             SP, SP, #0x10
    // 0x4c7b7c: r0 = Null
    //     0x4c7b7c: mov             x0, NULL
    // 0x4c7b80: LeaveFrame
    //     0x4c7b80: mov             SP, fp
    //     0x4c7b84: ldp             fp, lr, [SP], #0x10
    // 0x4c7b88: ret
    //     0x4c7b88: ret             
    // 0x4c7b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c7b8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c7b90: b               #0x4c7b5c
  }
  void []=(Interceptors, int, Interceptor) {
    // ** addr: 0x5043cc, size: 0x1f0
    // 0x5043cc: EnterFrame
    //     0x5043cc: stp             fp, lr, [SP, #-0x10]!
    //     0x5043d0: mov             fp, SP
    // 0x5043d4: AllocStack(0x20)
    //     0x5043d4: sub             SP, SP, #0x20
    // 0x5043d8: CheckStackOverflow
    //     0x5043d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5043dc: cmp             SP, x16
    //     0x5043e0: b.ls            #0x5045ac
    // 0x5043e4: ldr             x0, [fp, #0x10]
    // 0x5043e8: r2 = Null
    //     0x5043e8: mov             x2, NULL
    // 0x5043ec: r1 = Null
    //     0x5043ec: mov             x1, NULL
    // 0x5043f0: r4 = 59
    //     0x5043f0: mov             x4, #0x3b
    // 0x5043f4: branchIfSmi(r0, 0x504400)
    //     0x5043f4: tbz             w0, #0, #0x504400
    // 0x5043f8: r4 = LoadClassIdInstr(r0)
    //     0x5043f8: ldur            x4, [x0, #-1]
    //     0x5043fc: ubfx            x4, x4, #0xc, #0x14
    // 0x504400: r17 = 4538
    //     0x504400: mov             x17, #0x11ba
    // 0x504404: cmp             x4, x17
    // 0x504408: b.eq            #0x504420
    // 0x50440c: r8 = Interceptor
    //     0x50440c: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d5e8] Type: Interceptor
    //     0x504410: ldr             x8, [x8, #0x5e8]
    // 0x504414: r3 = Null
    //     0x504414: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d5f0] Null
    //     0x504418: ldr             x3, [x3, #0x5f0]
    // 0x50441c: r0 = Interceptor()
    //     0x50441c: bl              #0x4c19e0  ; IsType_Interceptor_Stub
    // 0x504420: ldr             x0, [fp, #0x20]
    // 0x504424: LoadField: r3 = r0->field_b
    //     0x504424: ldur            w3, [x0, #0xb]
    // 0x504428: DecompressPointer r3
    //     0x504428: add             x3, x3, HEAP, lsl #32
    // 0x50442c: stur            x3, [fp, #-0x18]
    // 0x504430: LoadField: r4 = r3->field_b
    //     0x504430: ldur            w4, [x3, #0xb]
    // 0x504434: DecompressPointer r4
    //     0x504434: add             x4, x4, HEAP, lsl #32
    // 0x504438: ldr             x0, [fp, #0x18]
    // 0x50443c: stur            x4, [fp, #-0x10]
    // 0x504440: r5 = LoadInt32Instr(r0)
    //     0x504440: sbfx            x5, x0, #1, #0x1f
    //     0x504444: tbz             w0, #0, #0x50444c
    //     0x504448: ldur            x5, [x0, #7]
    // 0x50444c: stur            x5, [fp, #-0x20]
    // 0x504450: r6 = LoadInt32Instr(r4)
    //     0x504450: sbfx            x6, x4, #1, #0x1f
    // 0x504454: stur            x6, [fp, #-8]
    // 0x504458: cmp             x6, x5
    // 0x50445c: b.ne            #0x504518
    // 0x504460: LoadField: r2 = r3->field_7
    //     0x504460: ldur            w2, [x3, #7]
    // 0x504464: DecompressPointer r2
    //     0x504464: add             x2, x2, HEAP, lsl #32
    // 0x504468: ldr             x0, [fp, #0x10]
    // 0x50446c: r1 = Null
    //     0x50446c: mov             x1, NULL
    // 0x504470: cmp             w2, NULL
    // 0x504474: b.eq            #0x504494
    // 0x504478: LoadField: r4 = r2->field_17
    //     0x504478: ldur            w4, [x2, #0x17]
    // 0x50447c: DecompressPointer r4
    //     0x50447c: add             x4, x4, HEAP, lsl #32
    // 0x504480: r8 = X0
    //     0x504480: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x504484: LoadField: r9 = r4->field_7
    //     0x504484: ldur            x9, [x4, #7]
    // 0x504488: r3 = Null
    //     0x504488: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d600] Null
    //     0x50448c: ldr             x3, [x3, #0x600]
    // 0x504490: blr             x9
    // 0x504494: ldur            x0, [fp, #-0x18]
    // 0x504498: LoadField: r1 = r0->field_f
    //     0x504498: ldur            w1, [x0, #0xf]
    // 0x50449c: DecompressPointer r1
    //     0x50449c: add             x1, x1, HEAP, lsl #32
    // 0x5044a0: LoadField: r2 = r1->field_b
    //     0x5044a0: ldur            w2, [x1, #0xb]
    // 0x5044a4: DecompressPointer r2
    //     0x5044a4: add             x2, x2, HEAP, lsl #32
    // 0x5044a8: ldur            x1, [fp, #-0x10]
    // 0x5044ac: cmp             w1, w2
    // 0x5044b0: b.ne            #0x5044c0
    // 0x5044b4: SaveReg r0
    //     0x5044b4: str             x0, [SP, #-8]!
    // 0x5044b8: r0 = _growToNextCapacity()
    //     0x5044b8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5044bc: add             SP, SP, #8
    // 0x5044c0: ldur            x3, [fp, #-0x18]
    // 0x5044c4: ldur            x4, [fp, #-8]
    // 0x5044c8: add             x0, x4, #1
    // 0x5044cc: lsl             x1, x0, #1
    // 0x5044d0: StoreField: r3->field_b = r1
    //     0x5044d0: stur            w1, [x3, #0xb]
    // 0x5044d4: mov             x1, x4
    // 0x5044d8: cmp             x1, x0
    // 0x5044dc: b.hs            #0x5045b4
    // 0x5044e0: LoadField: r1 = r3->field_f
    //     0x5044e0: ldur            w1, [x3, #0xf]
    // 0x5044e4: DecompressPointer r1
    //     0x5044e4: add             x1, x1, HEAP, lsl #32
    // 0x5044e8: ldr             x0, [fp, #0x10]
    // 0x5044ec: ArrayStore: r1[r4] = r0  ; List_4
    //     0x5044ec: add             x25, x1, x4, lsl #2
    //     0x5044f0: add             x25, x25, #0xf
    //     0x5044f4: str             w0, [x25]
    //     0x5044f8: tbz             w0, #0, #0x504514
    //     0x5044fc: ldurb           w16, [x1, #-1]
    //     0x504500: ldurb           w17, [x0, #-1]
    //     0x504504: and             x16, x17, x16, lsr #2
    //     0x504508: tst             x16, HEAP, lsr #32
    //     0x50450c: b.eq            #0x504514
    //     0x504510: bl              #0xd67e5c
    // 0x504514: b               #0x50459c
    // 0x504518: mov             x4, x6
    // 0x50451c: LoadField: r2 = r3->field_7
    //     0x50451c: ldur            w2, [x3, #7]
    // 0x504520: DecompressPointer r2
    //     0x504520: add             x2, x2, HEAP, lsl #32
    // 0x504524: ldr             x0, [fp, #0x10]
    // 0x504528: r1 = Null
    //     0x504528: mov             x1, NULL
    // 0x50452c: cmp             w2, NULL
    // 0x504530: b.eq            #0x504550
    // 0x504534: LoadField: r4 = r2->field_17
    //     0x504534: ldur            w4, [x2, #0x17]
    // 0x504538: DecompressPointer r4
    //     0x504538: add             x4, x4, HEAP, lsl #32
    // 0x50453c: r8 = X0
    //     0x50453c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x504540: LoadField: r9 = r4->field_7
    //     0x504540: ldur            x9, [x4, #7]
    // 0x504544: r3 = Null
    //     0x504544: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d610] Null
    //     0x504548: ldr             x3, [x3, #0x610]
    // 0x50454c: blr             x9
    // 0x504550: ldur            x0, [fp, #-8]
    // 0x504554: ldur            x1, [fp, #-0x20]
    // 0x504558: cmp             x1, x0
    // 0x50455c: b.hs            #0x5045b8
    // 0x504560: ldur            x2, [fp, #-0x18]
    // 0x504564: LoadField: r1 = r2->field_f
    //     0x504564: ldur            w1, [x2, #0xf]
    // 0x504568: DecompressPointer r1
    //     0x504568: add             x1, x1, HEAP, lsl #32
    // 0x50456c: ldr             x0, [fp, #0x10]
    // 0x504570: ldur            x2, [fp, #-0x20]
    // 0x504574: ArrayStore: r1[r2] = r0  ; List_4
    //     0x504574: add             x25, x1, x2, lsl #2
    //     0x504578: add             x25, x25, #0xf
    //     0x50457c: str             w0, [x25]
    //     0x504580: tbz             w0, #0, #0x50459c
    //     0x504584: ldurb           w16, [x1, #-1]
    //     0x504588: ldurb           w17, [x0, #-1]
    //     0x50458c: and             x16, x17, x16, lsr #2
    //     0x504590: tst             x16, HEAP, lsr #32
    //     0x504594: b.eq            #0x50459c
    //     0x504598: bl              #0xd67e5c
    // 0x50459c: r0 = Null
    //     0x50459c: mov             x0, NULL
    // 0x5045a0: LeaveFrame
    //     0x5045a0: mov             SP, fp
    //     0x5045a4: ldp             fp, lr, [SP], #0x10
    // 0x5045a8: ret
    //     0x5045a8: ret             
    // 0x5045ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5045ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5045b0: b               #0x5043e4
    // 0x5045b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5045b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5045b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5045b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  Interceptor [](Interceptors, int) {
    // ** addr: 0xc9f40c, size: 0x6c
    // 0xc9f40c: EnterFrame
    //     0xc9f40c: stp             fp, lr, [SP, #-0x10]!
    //     0xc9f410: mov             fp, SP
    // 0xc9f414: ldr             x2, [fp, #0x18]
    // 0xc9f418: LoadField: r3 = r2->field_b
    //     0xc9f418: ldur            w3, [x2, #0xb]
    // 0xc9f41c: DecompressPointer r3
    //     0xc9f41c: add             x3, x3, HEAP, lsl #32
    // 0xc9f420: LoadField: r2 = r3->field_b
    //     0xc9f420: ldur            w2, [x3, #0xb]
    // 0xc9f424: DecompressPointer r2
    //     0xc9f424: add             x2, x2, HEAP, lsl #32
    // 0xc9f428: ldr             x4, [fp, #0x10]
    // 0xc9f42c: r5 = LoadInt32Instr(r4)
    //     0xc9f42c: sbfx            x5, x4, #1, #0x1f
    //     0xc9f430: tbz             w4, #0, #0xc9f438
    //     0xc9f434: ldur            x5, [x4, #7]
    // 0xc9f438: r0 = LoadInt32Instr(r2)
    //     0xc9f438: sbfx            x0, x2, #1, #0x1f
    // 0xc9f43c: mov             x1, x5
    // 0xc9f440: cmp             x1, x0
    // 0xc9f444: b.hs            #0xc9f470
    // 0xc9f448: LoadField: r1 = r3->field_f
    //     0xc9f448: ldur            w1, [x3, #0xf]
    // 0xc9f44c: DecompressPointer r1
    //     0xc9f44c: add             x1, x1, HEAP, lsl #32
    // 0xc9f450: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0xc9f450: add             x16, x1, x5, lsl #2
    //     0xc9f454: ldur            w0, [x16, #0xf]
    // 0xc9f458: DecompressPointer r0
    //     0xc9f458: add             x0, x0, HEAP, lsl #32
    // 0xc9f45c: cmp             w0, NULL
    // 0xc9f460: b.eq            #0xc9f474
    // 0xc9f464: LeaveFrame
    //     0xc9f464: mov             SP, fp
    //     0xc9f468: ldp             fp, lr, [SP], #0x10
    // 0xc9f46c: ret
    //     0xc9f46c: ret             
    // 0xc9f470: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc9f470: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc9f474: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc9f474: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6008, size: 0x14, field offset: 0x14
enum InterceptorResultType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15500, size: 0x5c
    // 0xb15500: EnterFrame
    //     0xb15500: stp             fp, lr, [SP, #-0x10]!
    //     0xb15504: mov             fp, SP
    // 0xb15508: CheckStackOverflow
    //     0xb15508: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1550c: cmp             SP, x16
    //     0xb15510: b.ls            #0xb15554
    // 0xb15514: r1 = Null
    //     0xb15514: mov             x1, NULL
    // 0xb15518: r2 = 4
    //     0xb15518: mov             x2, #4
    // 0xb1551c: r0 = AllocateArray()
    //     0xb1551c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15520: r17 = "InterceptorResultType."
    //     0xb15520: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d5e0] "InterceptorResultType."
    //     0xb15524: ldr             x17, [x17, #0x5e0]
    // 0xb15528: StoreField: r0->field_f = r17
    //     0xb15528: stur            w17, [x0, #0xf]
    // 0xb1552c: ldr             x1, [fp, #0x10]
    // 0xb15530: LoadField: r2 = r1->field_f
    //     0xb15530: ldur            w2, [x1, #0xf]
    // 0xb15534: DecompressPointer r2
    //     0xb15534: add             x2, x2, HEAP, lsl #32
    // 0xb15538: StoreField: r0->field_13 = r2
    //     0xb15538: stur            w2, [x0, #0x13]
    // 0xb1553c: SaveReg r0
    //     0xb1553c: str             x0, [SP, #-8]!
    // 0xb15540: r0 = _interpolate()
    //     0xb15540: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15544: add             SP, SP, #8
    // 0xb15548: LeaveFrame
    //     0xb15548: mov             SP, fp
    //     0xb1554c: ldp             fp, lr, [SP], #0x10
    // 0xb15550: ret
    //     0xb15550: ret             
    // 0xb15554: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15554: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15558: b               #0xb15514
  }
}

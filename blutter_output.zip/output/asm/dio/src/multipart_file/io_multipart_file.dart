// lib: , url: package:dio/src/multipart_file/io_multipart_file.dart

// class id: 1048893, size: 0x8
class :: {

  static _ multipartFileFromPath(/* No info */) async {
    // ** addr: 0x8c65a4, size: 0x13c
    // 0x8c65a4: EnterFrame
    //     0x8c65a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8c65a8: mov             fp, SP
    // 0x8c65ac: AllocStack(0x28)
    //     0x8c65ac: sub             SP, SP, #0x28
    // 0x8c65b0: SetupParameters(dynamic _ /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0x8c65b0: stur            NULL, [fp, #-8]
    //     0x8c65b4: mov             x0, #0
    //     0x8c65b8: add             x1, fp, w0, sxtw #2
    //     0x8c65bc: ldr             x1, [x1, #0x18]
    //     0x8c65c0: stur            x1, [fp, #-0x18]
    //     0x8c65c4: add             x2, fp, w0, sxtw #2
    //     0x8c65c8: ldr             x2, [x2, #0x10]
    //     0x8c65cc: stur            x2, [fp, #-0x10]
    // 0x8c65d0: CheckStackOverflow
    //     0x8c65d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8c65d4: cmp             SP, x16
    //     0x8c65d8: b.ls            #0x8c66d8
    // 0x8c65dc: InitAsync() -> Future<MultipartFile>
    //     0x8c65dc: add             x0, PP, #0x34, lsl #12  ; [pp+0x348e8] TypeArguments: <MultipartFile>
    //     0x8c65e0: ldr             x0, [x0, #0x8e8]
    //     0x8c65e4: bl              #0x4b92e4
    // 0x8c65e8: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x8c65e8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8c65ec: ldr             x0, [x0, #0xb58]
    //     0x8c65f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8c65f4: cmp             w0, w16
    //     0x8c65f8: b.ne            #0x8c6604
    //     0x8c65fc: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x8c6600: bl              #0xd67d44
    // 0x8c6604: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0x8c6604: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8c6608: ldr             x0, [x0, #0xdd8]
    //     0x8c660c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8c6610: cmp             w0, w16
    //     0x8c6614: b.ne            #0x8c6620
    //     0x8c6618: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0x8c661c: bl              #0xd67cdc
    // 0x8c6620: r0 = _File()
    //     0x8c6620: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8c6624: mov             x1, x0
    // 0x8c6628: ldur            x0, [fp, #-0x18]
    // 0x8c662c: stur            x1, [fp, #-0x20]
    // 0x8c6630: StoreField: r1->field_7 = r0
    //     0x8c6630: stur            w0, [x1, #7]
    // 0x8c6634: SaveReg r0
    //     0x8c6634: str             x0, [SP, #-8]!
    // 0x8c6638: r0 = _toUtf8Array()
    //     0x8c6638: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8c663c: add             SP, SP, #8
    // 0x8c6640: ldur            x1, [fp, #-0x20]
    // 0x8c6644: StoreField: r1->field_b = r0
    //     0x8c6644: stur            w0, [x1, #0xb]
    //     0x8c6648: ldurb           w16, [x1, #-1]
    //     0x8c664c: ldurb           w17, [x0, #-1]
    //     0x8c6650: and             x16, x17, x16, lsr #2
    //     0x8c6654: tst             x16, HEAP, lsr #32
    //     0x8c6658: b.eq            #0x8c6660
    //     0x8c665c: bl              #0xd6826c
    // 0x8c6660: SaveReg r1
    //     0x8c6660: str             x1, [SP, #-8]!
    // 0x8c6664: r0 = length()
    //     0x8c6664: bl              #0xcac350  ; [dart:io] _File::length
    // 0x8c6668: add             SP, SP, #8
    // 0x8c666c: mov             x1, x0
    // 0x8c6670: stur            x1, [fp, #-0x18]
    // 0x8c6674: r0 = Await()
    //     0x8c6674: bl              #0x4b8e6c  ; AwaitStub
    // 0x8c6678: stur            x0, [fp, #-0x18]
    // 0x8c667c: ldur            x16, [fp, #-0x20]
    // 0x8c6680: SaveReg r16
    //     0x8c6680: str             x16, [SP, #-8]!
    // 0x8c6684: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c6684: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c6688: r0 = openRead()
    //     0x8c6688: bl              #0xcabf2c  ; [dart:io] _File::openRead
    // 0x8c668c: add             SP, SP, #8
    // 0x8c6690: mov             x1, x0
    // 0x8c6694: ldur            x0, [fp, #-0x18]
    // 0x8c6698: stur            x1, [fp, #-0x20]
    // 0x8c669c: r2 = LoadInt32Instr(r0)
    //     0x8c669c: sbfx            x2, x0, #1, #0x1f
    //     0x8c66a0: tbz             w0, #0, #0x8c66a8
    //     0x8c66a4: ldur            x2, [x0, #7]
    // 0x8c66a8: stur            x2, [fp, #-0x28]
    // 0x8c66ac: r0 = MultipartFile()
    //     0x8c66ac: bl              #0x8c67ec  ; AllocateMultipartFileStub -> MultipartFile (size=0x24)
    // 0x8c66b0: stur            x0, [fp, #-0x18]
    // 0x8c66b4: ldur            x16, [fp, #-0x20]
    // 0x8c66b8: stp             x16, x0, [SP, #-0x10]!
    // 0x8c66bc: ldur            x1, [fp, #-0x28]
    // 0x8c66c0: ldur            x16, [fp, #-0x10]
    // 0x8c66c4: stp             x16, x1, [SP, #-0x10]!
    // 0x8c66c8: r0 = MultipartFile()
    //     0x8c66c8: bl              #0x8c66e0  ; [package:dio/src/multipart_file.dart] MultipartFile::MultipartFile
    // 0x8c66cc: add             SP, SP, #0x20
    // 0x8c66d0: ldur            x0, [fp, #-0x18]
    // 0x8c66d4: r0 = ReturnAsyncNotFuture()
    //     0x8c66d4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x8c66d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c66d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c66dc: b               #0x8c65dc
  }
}

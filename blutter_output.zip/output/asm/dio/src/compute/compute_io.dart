// lib: , url: package:dio/src/compute/compute_io.dart

// class id: 1048883, size: 0x8
class :: {

  [closure] static Future<Y1> compute<Y0, Y1>(dynamic, (dynamic, Y0) => FutureOr<Y1>, Y0, {String? debugLabel}) {
    // ** addr: 0x55c610, size: 0xd0
    // 0x55c610: EnterFrame
    //     0x55c610: stp             fp, lr, [SP, #-0x10]!
    //     0x55c614: mov             fp, SP
    // 0x55c618: mov             x0, x4
    // 0x55c61c: LoadField: r1 = r0->field_13
    //     0x55c61c: ldur            w1, [x0, #0x13]
    // 0x55c620: DecompressPointer r1
    //     0x55c620: add             x1, x1, HEAP, lsl #32
    // 0x55c624: sub             x2, x1, #6
    // 0x55c628: add             x3, fp, w2, sxtw #2
    // 0x55c62c: ldr             x3, [x3, #0x20]
    // 0x55c630: add             x4, fp, w2, sxtw #2
    // 0x55c634: ldr             x4, [x4, #0x18]
    // 0x55c638: add             x5, fp, w2, sxtw #2
    // 0x55c63c: ldr             x5, [x5, #0x10]
    // 0x55c640: LoadField: r2 = r0->field_1f
    //     0x55c640: ldur            w2, [x0, #0x1f]
    // 0x55c644: DecompressPointer r2
    //     0x55c644: add             x2, x2, HEAP, lsl #32
    // 0x55c648: r16 = "debugLabel"
    //     0x55c648: ldr             x16, [PP, #0x44b0]  ; [pp+0x44b0] "debugLabel"
    // 0x55c64c: cmp             w2, w16
    // 0x55c650: b.ne            #0x55c66c
    // 0x55c654: LoadField: r2 = r0->field_23
    //     0x55c654: ldur            w2, [x0, #0x23]
    // 0x55c658: DecompressPointer r2
    //     0x55c658: add             x2, x2, HEAP, lsl #32
    // 0x55c65c: sub             w6, w1, w2
    // 0x55c660: add             x1, fp, w6, sxtw #2
    // 0x55c664: ldr             x1, [x1, #8]
    // 0x55c668: b               #0x55c670
    // 0x55c66c: r1 = Null
    //     0x55c66c: mov             x1, NULL
    // 0x55c670: LoadField: r2 = r0->field_f
    //     0x55c670: ldur            w2, [x0, #0xf]
    // 0x55c674: DecompressPointer r2
    //     0x55c674: add             x2, x2, HEAP, lsl #32
    // 0x55c678: cbnz            w2, #0x55c684
    // 0x55c67c: r0 = Null
    //     0x55c67c: mov             x0, NULL
    // 0x55c680: b               #0x55c694
    // 0x55c684: LoadField: r2 = r0->field_17
    //     0x55c684: ldur            w2, [x0, #0x17]
    // 0x55c688: DecompressPointer r2
    //     0x55c688: add             x2, x2, HEAP, lsl #32
    // 0x55c68c: add             x0, fp, w2, sxtw #2
    // 0x55c690: ldr             x0, [x0, #0x10]
    // 0x55c694: LoadField: r2 = r3->field_f
    //     0x55c694: ldur            w2, [x3, #0xf]
    // 0x55c698: DecompressPointer r2
    //     0x55c698: add             x2, x2, HEAP, lsl #32
    // 0x55c69c: r16 = 
    //     0x55c69c: ldr             x16, [PP, #0x50]  ; [pp+0x50] TypeArguments: 
    // 0x55c6a0: cmp             w2, w16
    // 0x55c6a4: b.eq            #0x55c6ac
    // 0x55c6a8: mov             x0, x2
    // 0x55c6ac: CheckStackOverflow
    //     0x55c6ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55c6b0: cmp             SP, x16
    //     0x55c6b4: b.ls            #0x55c6d8
    // 0x55c6b8: stp             x4, x0, [SP, #-0x10]!
    // 0x55c6bc: stp             x1, x5, [SP, #-0x10]!
    // 0x55c6c0: r4 = const [0x2, 0x3, 0x3, 0x2, debugLabel, 0x2, null]
    //     0x55c6c0: ldr             x4, [PP, #0x50e8]  ; [pp+0x50e8] List(7) [0x2, 0x3, 0x3, 0x2, "debugLabel", 0x2, Null]
    // 0x55c6c4: r0 = compute()
    //     0x55c6c4: bl              #0x55c6e0  ; [package:dio/src/compute/compute_io.dart] ::compute
    // 0x55c6c8: add             SP, SP, #0x20
    // 0x55c6cc: LeaveFrame
    //     0x55c6cc: mov             SP, fp
    //     0x55c6d0: ldp             fp, lr, [SP], #0x10
    // 0x55c6d4: ret
    //     0x55c6d4: ret             
    // 0x55c6d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55c6d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55c6dc: b               #0x55c6b8
  }
  static _ compute(/* No info */) async {
    // ** addr: 0x55c6e0, size: 0x8a4
    // 0x55c6e0: EnterFrame
    //     0x55c6e0: stp             fp, lr, [SP, #-0x10]!
    //     0x55c6e4: mov             fp, SP
    // 0x55c6e8: AllocStack(0xe8)
    //     0x55c6e8: sub             SP, SP, #0xe8
    // 0x55c6ec: SetupParameters(dynamic _ /* r3, fp-0xc0 */, dynamic _ /* r4, fp-0xb8 */, {dynamic debugLabel = Null /* r1, fp-0xb0 */})
    //     0x55c6ec: stur            NULL, [fp, #-8]
    //     0x55c6f0: stur            x4, [fp, #-0xc8]
    //     0x55c6f4: mov             x0, x4
    //     0x55c6f8: ldur            w1, [x0, #0x13]
    //     0x55c6fc: add             x1, x1, HEAP, lsl #32
    //     0x55c700: sub             x2, x1, #4
    //     0x55c704: add             x3, fp, w2, sxtw #2
    //     0x55c708: ldr             x3, [x3, #0x18]
    //     0x55c70c: stur            x3, [fp, #-0xc0]
    //     0x55c710: add             x4, fp, w2, sxtw #2
    //     0x55c714: ldr             x4, [x4, #0x10]
    //     0x55c718: stur            x4, [fp, #-0xb8]
    //     0x55c71c: ldur            w2, [x0, #0x1f]
    //     0x55c720: add             x2, x2, HEAP, lsl #32
    //     0x55c724: ldr             x16, [PP, #0x44b0]  ; [pp+0x44b0] "debugLabel"
    //     0x55c728: cmp             w2, w16
    //     0x55c72c: b.ne            #0x55c748
    //     0x55c730: ldur            w2, [x0, #0x23]
    //     0x55c734: add             x2, x2, HEAP, lsl #32
    //     0x55c738: sub             w5, w1, w2
    //     0x55c73c: add             x1, fp, w5, sxtw #2
    //     0x55c740: ldr             x1, [x1, #8]
    //     0x55c744: b               #0x55c74c
    //     0x55c748: mov             x1, NULL
    //     0x55c74c: stur            x1, [fp, #-0xb0]
    //     0x55c750: ldur            w2, [x0, #0xf]
    //     0x55c754: add             x2, x2, HEAP, lsl #32
    //     0x55c758: cbnz            w2, #0x55c764
    //     0x55c75c: mov             x2, NULL
    //     0x55c760: b               #0x55c778
    //     0x55c764: ldur            w2, [x0, #0x17]
    //     0x55c768: add             x2, x2, HEAP, lsl #32
    //     0x55c76c: add             x5, fp, w2, sxtw #2
    //     0x55c770: ldr             x5, [x5, #0x10]
    //     0x55c774: mov             x2, x5
    //     0x55c778: stur            x2, [fp, #-0xa8]
    // 0x55c77c: CheckStackOverflow
    //     0x55c77c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55c780: cmp             SP, x16
    //     0x55c784: b.ls            #0x55cf7c
    // 0x55c788: r1 = 5
    //     0x55c788: mov             x1, #5
    // 0x55c78c: r0 = AllocateContext()
    //     0x55c78c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x55c790: mov             x4, x0
    // 0x55c794: ldur            x0, [fp, #-0xb0]
    // 0x55c798: stur            x4, [fp, #-0xd0]
    // 0x55c79c: StoreField: r4->field_f = r0
    //     0x55c79c: stur            w0, [x4, #0xf]
    // 0x55c7a0: ldur            x1, [fp, #-0xa8]
    // 0x55c7a4: r2 = Null
    //     0x55c7a4: mov             x2, NULL
    // 0x55c7a8: r3 = <Y1>
    //     0x55c7a8: ldr             x3, [PP, #0x50f0]  ; [pp+0x50f0] TypeArguments: <Y1>
    // 0x55c7ac: r0 = Null
    //     0x55c7ac: mov             x0, NULL
    // 0x55c7b0: cmp             x2, x0
    // 0x55c7b4: b.ne            #0x55c7c0
    // 0x55c7b8: cmp             x1, x0
    // 0x55c7bc: b.eq            #0x55c7cc
    // 0x55c7c0: r24 = InstantiateTypeArgumentsStub
    //     0x55c7c0: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x55c7c4: LoadField: r30 = r24->field_7
    //     0x55c7c4: ldur            lr, [x24, #7]
    // 0x55c7c8: blr             lr
    // 0x55c7cc: mov             x1, x0
    // 0x55c7d0: stur            x1, [fp, #-0xb0]
    // 0x55c7d4: r0 = InitAsync()
    //     0x55c7d4: bl              #0x4b92e4  ; InitAsyncStub
    // 0x55c7d8: ldur            x2, [fp, #-0xd0]
    // 0x55c7dc: LoadField: r0 = r2->field_f
    //     0x55c7dc: ldur            w0, [x2, #0xf]
    // 0x55c7e0: DecompressPointer r0
    //     0x55c7e0: add             x0, x0, HEAP, lsl #32
    // 0x55c7e4: cmp             w0, NULL
    // 0x55c7e8: b.ne            #0x55c7f4
    // 0x55c7ec: r0 = "compute"
    //     0x55c7ec: ldr             x0, [PP, #0x50f8]  ; [pp+0x50f8] "compute"
    // 0x55c7f0: StoreField: r2->field_f = r0
    //     0x55c7f0: stur            w0, [x2, #0xf]
    // 0x55c7f4: ldur            x0, [fp, #-0xa8]
    // 0x55c7f8: r0 = begin()
    //     0x55c7f8: bl              #0x55dd58  ; [dart:developer] Flow::begin
    // 0x55c7fc: mov             x4, x0
    // 0x55c800: ldur            x3, [fp, #-0xd0]
    // 0x55c804: stur            x4, [fp, #-0xc8]
    // 0x55c808: StoreField: r3->field_13 = r0
    //     0x55c808: stur            w0, [x3, #0x13]
    //     0x55c80c: ldurb           w16, [x3, #-1]
    //     0x55c810: ldurb           w17, [x0, #-1]
    //     0x55c814: and             x16, x17, x16, lsr #2
    //     0x55c818: tst             x16, HEAP, lsr #32
    //     0x55c81c: b.eq            #0x55c824
    //     0x55c820: bl              #0xd682ac
    // 0x55c824: LoadField: r0 = r3->field_f
    //     0x55c824: ldur            w0, [x3, #0xf]
    // 0x55c828: DecompressPointer r0
    //     0x55c828: add             x0, x0, HEAP, lsl #32
    // 0x55c82c: stur            x0, [fp, #-0xb0]
    // 0x55c830: r1 = Null
    //     0x55c830: mov             x1, NULL
    // 0x55c834: r2 = 4
    //     0x55c834: mov             x2, #4
    // 0x55c838: r0 = AllocateArray()
    //     0x55c838: bl              #0xd6987c  ; AllocateArrayStub
    // 0x55c83c: mov             x1, x0
    // 0x55c840: ldur            x0, [fp, #-0xb0]
    // 0x55c844: StoreField: r1->field_f = r0
    //     0x55c844: stur            w0, [x1, #0xf]
    // 0x55c848: r17 = ": start"
    //     0x55c848: add             x17, PP, #0x14, lsl #12  ; [pp+0x14808] ": start"
    //     0x55c84c: ldr             x17, [x17, #0x808]
    // 0x55c850: StoreField: r1->field_13 = r17
    //     0x55c850: stur            w17, [x1, #0x13]
    // 0x55c854: SaveReg r1
    //     0x55c854: str             x1, [SP, #-8]!
    // 0x55c858: r0 = _interpolate()
    //     0x55c858: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x55c85c: add             SP, SP, #8
    // 0x55c860: ldur            x16, [fp, #-0xc8]
    // 0x55c864: stp             x16, x0, [SP, #-0x10]!
    // 0x55c868: r4 = const [0, 0x2, 0x2, 0x1, flow, 0x1, null]
    //     0x55c868: add             x4, PP, #0x14, lsl #12  ; [pp+0x14810] List(7) [0, 0x2, 0x2, 0x1, "flow", 0x1, Null]
    //     0x55c86c: ldr             x4, [x4, #0x810]
    // 0x55c870: r0 = startSync()
    //     0x55c870: bl              #0x55da8c  ; [dart:developer] Timeline::startSync
    // 0x55c874: add             SP, SP, #0x10
    // 0x55c878: r16 = ""
    //     0x55c878: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x55c87c: stp             x16, NULL, [SP, #-0x10]!
    // 0x55c880: r0 = _RawReceivePort()
    //     0x55c880: bl              #0x4e66e0  ; [dart:isolate] _RawReceivePort::_RawReceivePort
    // 0x55c884: add             SP, SP, #0x10
    // 0x55c888: stur            x0, [fp, #-0xb0]
    // 0x55c88c: stp             NULL, x0, [SP, #-0x10]!
    // 0x55c890: r0 = handler=()
    //     0x55c890: bl              #0x4e6514  ; [dart:isolate] _RawReceivePort::handler=
    // 0x55c894: add             SP, SP, #0x10
    // 0x55c898: ldur            x0, [fp, #-0xb0]
    // 0x55c89c: ldur            x2, [fp, #-0xd0]
    // 0x55c8a0: StoreField: r2->field_17 = r0
    //     0x55c8a0: stur            w0, [x2, #0x17]
    //     0x55c8a4: ldurb           w16, [x2, #-1]
    //     0x55c8a8: ldurb           w17, [x0, #-1]
    //     0x55c8ac: and             x16, x17, x16, lsr #2
    //     0x55c8b0: tst             x16, HEAP, lsr #32
    //     0x55c8b4: b.eq            #0x55c8bc
    //     0x55c8b8: bl              #0xd6828c
    // 0x55c8bc: r0 = finishSync()
    //     0x55c8bc: bl              #0x55d838  ; [dart:developer] Timeline::finishSync
    // 0x55c8c0: ldur            x2, [fp, #-0xd0]
    // 0x55c8c4: r1 = Function 'timeEndAndCleanup': static.
    //     0x55c8c4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14818] AnonymousClosure: static (0x55e31c), in [package:dio/src/compute/compute_io.dart] ::compute (0x55c6e0)
    //     0x55c8c8: ldr             x1, [x1, #0x818]
    // 0x55c8cc: r0 = AllocateClosure()
    //     0x55c8cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x55c8d0: ldur            x2, [fp, #-0xa8]
    // 0x55c8d4: StoreField: r0->field_b = r2
    //     0x55c8d4: stur            w2, [x0, #0xb]
    // 0x55c8d8: ldur            x3, [fp, #-0xd0]
    // 0x55c8dc: StoreField: r3->field_1b = r0
    //     0x55c8dc: stur            w0, [x3, #0x1b]
    //     0x55c8e0: ldurb           w16, [x3, #-1]
    //     0x55c8e4: ldurb           w17, [x0, #-1]
    //     0x55c8e8: and             x16, x17, x16, lsr #2
    //     0x55c8ec: tst             x16, HEAP, lsr #32
    //     0x55c8f0: b.eq            #0x55c8f8
    //     0x55c8f4: bl              #0xd682ac
    // 0x55c8f8: r1 = Null
    //     0x55c8f8: mov             x1, NULL
    // 0x55c8fc: r0 = _Future()
    //     0x55c8fc: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x55c900: mov             x1, x0
    // 0x55c904: r0 = 0
    //     0x55c904: mov             x0, #0
    // 0x55c908: stur            x1, [fp, #-0xd8]
    // 0x55c90c: StoreField: r1->field_b = r0
    //     0x55c90c: stur            x0, [x1, #0xb]
    // 0x55c910: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x55c910: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x55c914: ldr             x0, [x0, #0xb58]
    //     0x55c918: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x55c91c: cmp             w0, w16
    //     0x55c920: b.ne            #0x55c92c
    //     0x55c924: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x55c928: bl              #0xd67d44
    // 0x55c92c: mov             x1, x0
    // 0x55c930: ldur            x0, [fp, #-0xd8]
    // 0x55c934: StoreField: r0->field_13 = r1
    //     0x55c934: stur            w1, [x0, #0x13]
    // 0x55c938: r1 = Null
    //     0x55c938: mov             x1, NULL
    // 0x55c93c: r0 = _AsyncCompleter()
    //     0x55c93c: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x55c940: ldur            x3, [fp, #-0xd8]
    // 0x55c944: StoreField: r0->field_b = r3
    //     0x55c944: stur            w3, [x0, #0xb]
    // 0x55c948: ldur            x4, [fp, #-0xd0]
    // 0x55c94c: StoreField: r4->field_1f = r0
    //     0x55c94c: stur            w0, [x4, #0x1f]
    //     0x55c950: ldurb           w16, [x4, #-1]
    //     0x55c954: ldurb           w17, [x0, #-1]
    //     0x55c958: and             x16, x17, x16, lsr #2
    //     0x55c95c: tst             x16, HEAP, lsr #32
    //     0x55c960: b.eq            #0x55c968
    //     0x55c964: bl              #0xd682cc
    // 0x55c968: mov             x2, x4
    // 0x55c96c: r1 = Function '<anonymous closure>': static.
    //     0x55c96c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14820] AnonymousClosure: static (0x55e2a0), in [package:dio/src/compute/compute_io.dart] ::compute (0x55c6e0)
    //     0x55c970: ldr             x1, [x1, #0x820]
    // 0x55c974: r0 = AllocateClosure()
    //     0x55c974: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x55c978: mov             x1, x0
    // 0x55c97c: ldur            x0, [fp, #-0xa8]
    // 0x55c980: StoreField: r1->field_b = r0
    //     0x55c980: stur            w0, [x1, #0xb]
    // 0x55c984: ldur            x16, [fp, #-0xb0]
    // 0x55c988: stp             x1, x16, [SP, #-0x10]!
    // 0x55c98c: r0 = handler=()
    //     0x55c98c: bl              #0x4e6514  ; [dart:isolate] _RawReceivePort::handler=
    // 0x55c990: add             SP, SP, #0x10
    // 0x55c994: ldur            x0, [fp, #-0xd0]
    // 0x55c998: ldur            x3, [fp, #-0xc8]
    // 0x55c99c: r4 = Closure: <Y0, Y1>(_IsolateConfiguration<Y0, Y1>) => Future<void> from Function '_spawn@370363018': static.
    //     0x55c99c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14828] Closure: <Y0, Y1>(_IsolateConfiguration<Y0, Y1>) => Future<void> from Function '_spawn@370363018': static. (0x7fe6e1d5ddb8)
    //     0x55c9a0: ldr             x4, [x4, #0x828]
    // 0x55c9a4: LoadField: r5 = r4->field_13
    //     0x55c9a4: ldur            w5, [x4, #0x13]
    // 0x55c9a8: DecompressPointer r5
    //     0x55c9a8: add             x5, x5, HEAP, lsl #32
    // 0x55c9ac: stur            x5, [fp, #-0xe8]
    // 0x55c9b0: LoadField: r6 = r4->field_17
    //     0x55c9b0: ldur            w6, [x4, #0x17]
    // 0x55c9b4: DecompressPointer r6
    //     0x55c9b4: add             x6, x6, HEAP, lsl #32
    // 0x55c9b8: mov             x1, x5
    // 0x55c9bc: mov             x2, x6
    // 0x55c9c0: stur            x6, [fp, #-0xe0]
    // 0x55c9c4: r0 = AllocateClosure()
    //     0x55c9c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x55c9c8: stur            x0, [fp, #-0xe0]
    // 0x55c9cc: r16 = Closure: <Y0, Y1>(_IsolateConfiguration<Y0, Y1>) => Future<void> from Function '_spawn@370363018': static.
    //     0x55c9cc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14828] Closure: <Y0, Y1>(_IsolateConfiguration<Y0, Y1>) => Future<void> from Function '_spawn@370363018': static. (0x7fe6e1d5ddb8)
    //     0x55c9d0: ldr             x16, [x16, #0x828]
    // 0x55c9d4: ldur            lr, [fp, #-0xa8]
    // 0x55c9d8: stp             lr, x16, [SP, #-0x10]!
    // 0x55c9dc: r0 = _boundsCheckForPartialInstantiation()
    //     0x55c9dc: bl              #0x4b9f2c  ; [dart:_internal] ::_boundsCheckForPartialInstantiation
    // 0x55c9e0: add             SP, SP, #0x10
    // 0x55c9e4: ldur            x0, [fp, #-0xa8]
    // 0x55c9e8: ldur            x2, [fp, #-0xe0]
    // 0x55c9ec: StoreField: r2->field_f = r0
    //     0x55c9ec: stur            w0, [x2, #0xf]
    //     0x55c9f0: ldurb           w16, [x2, #-1]
    //     0x55c9f4: ldurb           w17, [x0, #-1]
    //     0x55c9f8: and             x16, x17, x16, lsr #2
    //     0x55c9fc: tst             x16, HEAP, lsr #32
    //     0x55ca00: b.eq            #0x55ca08
    //     0x55ca04: bl              #0xd6828c
    // 0x55ca08: r1 = Closure: <Y0, Y1>(_IsolateConfiguration<Y0, Y1>) => Future<void> from Function '_spawn@370363018': static.
    //     0x55ca08: add             x1, PP, #0x14, lsl #12  ; [pp+0x14828] Closure: <Y0, Y1>(_IsolateConfiguration<Y0, Y1>) => Future<void> from Function '_spawn@370363018': static. (0x7fe6e1d5ddb8)
    //     0x55ca0c: ldr             x1, [x1, #0x828]
    // 0x55ca10: LoadField: r0 = r1->field_7
    //     0x55ca10: ldur            w0, [x1, #7]
    // 0x55ca14: DecompressPointer r0
    //     0x55ca14: add             x0, x0, HEAP, lsl #32
    // 0x55ca18: StoreField: r2->field_7 = r0
    //     0x55ca18: stur            w0, [x2, #7]
    //     0x55ca1c: ldurb           w16, [x2, #-1]
    //     0x55ca20: ldurb           w17, [x0, #-1]
    //     0x55ca24: and             x16, x17, x16, lsr #2
    //     0x55ca28: tst             x16, HEAP, lsr #32
    //     0x55ca2c: b.eq            #0x55ca34
    //     0x55ca30: bl              #0xd6828c
    // 0x55ca34: LoadField: r0 = r1->field_b
    //     0x55ca34: ldur            w0, [x1, #0xb]
    // 0x55ca38: DecompressPointer r0
    //     0x55ca38: add             x0, x0, HEAP, lsl #32
    // 0x55ca3c: StoreField: r2->field_b = r0
    //     0x55ca3c: stur            w0, [x2, #0xb]
    //     0x55ca40: ldurb           w16, [x2, #-1]
    //     0x55ca44: ldurb           w17, [x0, #-1]
    //     0x55ca48: and             x16, x17, x16, lsr #2
    //     0x55ca4c: tst             x16, HEAP, lsr #32
    //     0x55ca50: b.eq            #0x55ca58
    //     0x55ca54: bl              #0xd6828c
    // 0x55ca58: ldur            x1, [fp, #-0xa8]
    // 0x55ca5c: r0 = _IsolateConfiguration()
    //     0x55ca5c: bl              #0x55d82c  ; Allocate_IsolateConfigurationStub -> _IsolateConfiguration<X0, X1> (size=0x24)
    // 0x55ca60: stur            x0, [fp, #-0xe8]
    // 0x55ca64: ldur            x16, [fp, #-0xb0]
    // 0x55ca68: SaveReg r16
    //     0x55ca68: str             x16, [SP, #-8]!
    // 0x55ca6c: r0 = _get_sendport()
    //     0x55ca6c: bl              #0x4e6494  ; [dart:isolate] _RawReceivePort::_get_sendport
    // 0x55ca70: add             SP, SP, #8
    // 0x55ca74: mov             x2, x0
    // 0x55ca78: ldur            x1, [fp, #-0xd0]
    // 0x55ca7c: LoadField: r3 = r1->field_f
    //     0x55ca7c: ldur            w3, [x1, #0xf]
    // 0x55ca80: DecompressPointer r3
    //     0x55ca80: add             x3, x3, HEAP, lsl #32
    // 0x55ca84: ldur            x0, [fp, #-0xc8]
    // 0x55ca88: LoadField: r4 = r0->field_f
    //     0x55ca88: ldur            x4, [x0, #0xf]
    // 0x55ca8c: ldur            x0, [fp, #-0xc0]
    // 0x55ca90: ldur            x5, [fp, #-0xe8]
    // 0x55ca94: StoreField: r5->field_b = r0
    //     0x55ca94: stur            w0, [x5, #0xb]
    //     0x55ca98: ldurb           w16, [x5, #-1]
    //     0x55ca9c: ldurb           w17, [x0, #-1]
    //     0x55caa0: and             x16, x17, x16, lsr #2
    //     0x55caa4: tst             x16, HEAP, lsr #32
    //     0x55caa8: b.eq            #0x55cab0
    //     0x55caac: bl              #0xd682ec
    // 0x55cab0: ldur            x0, [fp, #-0xb8]
    // 0x55cab4: StoreField: r5->field_f = r0
    //     0x55cab4: stur            w0, [x5, #0xf]
    //     0x55cab8: tbz             w0, #0, #0x55cad4
    //     0x55cabc: ldurb           w16, [x5, #-1]
    //     0x55cac0: ldurb           w17, [x0, #-1]
    //     0x55cac4: and             x16, x17, x16, lsr #2
    //     0x55cac8: tst             x16, HEAP, lsr #32
    //     0x55cacc: b.eq            #0x55cad4
    //     0x55cad0: bl              #0xd682ec
    // 0x55cad4: mov             x0, x2
    // 0x55cad8: StoreField: r5->field_13 = r0
    //     0x55cad8: stur            w0, [x5, #0x13]
    //     0x55cadc: ldurb           w16, [x5, #-1]
    //     0x55cae0: ldurb           w17, [x0, #-1]
    //     0x55cae4: and             x16, x17, x16, lsr #2
    //     0x55cae8: tst             x16, HEAP, lsr #32
    //     0x55caec: b.eq            #0x55caf4
    //     0x55caf0: bl              #0xd682ec
    // 0x55caf4: mov             x0, x3
    // 0x55caf8: StoreField: r5->field_17 = r0
    //     0x55caf8: stur            w0, [x5, #0x17]
    //     0x55cafc: ldurb           w16, [x5, #-1]
    //     0x55cb00: ldurb           w17, [x0, #-1]
    //     0x55cb04: and             x16, x17, x16, lsr #2
    //     0x55cb08: tst             x16, HEAP, lsr #32
    //     0x55cb0c: b.eq            #0x55cb14
    //     0x55cb10: bl              #0xd682ec
    // 0x55cb14: StoreField: r5->field_1b = r4
    //     0x55cb14: stur            x4, [x5, #0x1b]
    // 0x55cb18: ldur            x16, [fp, #-0xb0]
    // 0x55cb1c: SaveReg r16
    //     0x55cb1c: str             x16, [SP, #-8]!
    // 0x55cb20: r0 = _get_sendport()
    //     0x55cb20: bl              #0x4e6494  ; [dart:isolate] _RawReceivePort::_get_sendport
    // 0x55cb24: add             SP, SP, #8
    // 0x55cb28: stur            x0, [fp, #-0xb8]
    // 0x55cb2c: ldur            x16, [fp, #-0xb0]
    // 0x55cb30: SaveReg r16
    //     0x55cb30: str             x16, [SP, #-8]!
    // 0x55cb34: r0 = _get_sendport()
    //     0x55cb34: bl              #0x4e6494  ; [dart:isolate] _RawReceivePort::_get_sendport
    // 0x55cb38: add             SP, SP, #8
    // 0x55cb3c: mov             x4, x0
    // 0x55cb40: ldur            x0, [fp, #-0xd0]
    // 0x55cb44: stur            x4, [fp, #-0xc0]
    // 0x55cb48: LoadField: r5 = r0->field_f
    //     0x55cb48: ldur            w5, [x0, #0xf]
    // 0x55cb4c: DecompressPointer r5
    //     0x55cb4c: add             x5, x5, HEAP, lsl #32
    // 0x55cb50: ldur            x1, [fp, #-0xa8]
    // 0x55cb54: stur            x5, [fp, #-0xb0]
    // 0x55cb58: r2 = Null
    //     0x55cb58: mov             x2, NULL
    // 0x55cb5c: r3 = <_IsolateConfiguration<Y0, Y1>>
    //     0x55cb5c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14830] TypeArguments: <_IsolateConfiguration<Y0, Y1>>
    //     0x55cb60: ldr             x3, [x3, #0x830]
    // 0x55cb64: r24 = InstantiateTypeArgumentsStub
    //     0x55cb64: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x55cb68: LoadField: r30 = r24->field_7
    //     0x55cb68: ldur            lr, [x24, #7]
    // 0x55cb6c: blr             lr
    // 0x55cb70: ldur            x16, [fp, #-0xe0]
    // 0x55cb74: stp             x16, x0, [SP, #-0x10]!
    // 0x55cb78: ldur            x16, [fp, #-0xe8]
    // 0x55cb7c: ldur            lr, [fp, #-0xb0]
    // 0x55cb80: stp             lr, x16, [SP, #-0x10]!
    // 0x55cb84: ldur            x16, [fp, #-0xc0]
    // 0x55cb88: ldur            lr, [fp, #-0xb8]
    // 0x55cb8c: stp             lr, x16, [SP, #-0x10]!
    // 0x55cb90: r4 = const [0x1, 0x5, 0x5, 0x5, null]
    //     0x55cb90: ldr             x4, [PP, #0x5120]  ; [pp+0x5120] List(5) [0x1, 0x5, 0x5, 0x5, Null]
    // 0x55cb94: r0 = spawn()
    //     0x55cb94: bl              #0x55cff0  ; [dart:isolate] Isolate::spawn
    // 0x55cb98: add             SP, SP, #0x30
    // 0x55cb9c: mov             x1, x0
    // 0x55cba0: stur            x1, [fp, #-0xb0]
    // 0x55cba4: r0 = Await()
    //     0x55cba4: bl              #0x4b8e6c  ; AwaitStub
    // 0x55cba8: ldur            x0, [fp, #-0xd8]
    // 0x55cbac: r0 = Await()
    //     0x55cbac: bl              #0x4b8e6c  ; AwaitStub
    // 0x55cbb0: mov             x3, x0
    // 0x55cbb4: stur            x3, [fp, #-0xb8]
    // 0x55cbb8: cmp             w3, NULL
    // 0x55cbbc: b.eq            #0x55cdc4
    // 0x55cbc0: mov             x0, x3
    // 0x55cbc4: r2 = Null
    //     0x55cbc4: mov             x2, NULL
    // 0x55cbc8: r1 = Null
    //     0x55cbc8: mov             x1, NULL
    // 0x55cbcc: r4 = 59
    //     0x55cbcc: mov             x4, #0x3b
    // 0x55cbd0: branchIfSmi(r0, 0x55cbdc)
    //     0x55cbd0: tbz             w0, #0, #0x55cbdc
    // 0x55cbd4: r4 = LoadClassIdInstr(r0)
    //     0x55cbd4: ldur            x4, [x0, #-1]
    //     0x55cbd8: ubfx            x4, x4, #0xc, #0x14
    // 0x55cbdc: sub             x4, x4, #0x59
    // 0x55cbe0: cmp             x4, #2
    // 0x55cbe4: b.ls            #0x55cbf8
    // 0x55cbe8: r8 = List
    //     0x55cbe8: ldr             x8, [PP, #0x2248]  ; [pp+0x2248] Type: List
    // 0x55cbec: r3 = Null
    //     0x55cbec: add             x3, PP, #0x14, lsl #12  ; [pp+0x14838] Null
    //     0x55cbf0: ldr             x3, [x3, #0x838]
    // 0x55cbf4: r0 = List()
    //     0x55cbf4: bl              #0xd74840  ; IsType_List_Stub
    // 0x55cbf8: ldur            x1, [fp, #-0xb8]
    // 0x55cbfc: r0 = LoadClassIdInstr(r1)
    //     0x55cbfc: ldur            x0, [x1, #-1]
    //     0x55cc00: ubfx            x0, x0, #0xc, #0x14
    // 0x55cc04: SaveReg r1
    //     0x55cc04: str             x1, [SP, #-8]!
    // 0x55cc08: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x55cc08: mov             x17, #0xb8ea
    //     0x55cc0c: add             lr, x0, x17
    //     0x55cc10: ldr             lr, [x21, lr, lsl #3]
    //     0x55cc14: blr             lr
    // 0x55cc18: add             SP, SP, #8
    // 0x55cc1c: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x55cc1c: mov             x1, #0x76
    //     0x55cc20: tbz             w0, #0, #0x55cc30
    //     0x55cc24: ldur            x1, [x0, #-1]
    //     0x55cc28: ubfx            x1, x1, #0xc, #0x14
    //     0x55cc2c: lsl             x1, x1, #1
    // 0x55cc30: cmp             w1, #0x76
    // 0x55cc34: b.ne            #0x55cccc
    // 0x55cc38: r1 = LoadInt32Instr(r0)
    //     0x55cc38: sbfx            x1, x0, #1, #0x1f
    // 0x55cc3c: cmp             x1, #2
    // 0x55cc40: b.gt            #0x55ccc0
    // 0x55cc44: cmp             x1, #1
    // 0x55cc48: b.gt            #0x55cdfc
    // 0x55cc4c: cmp             w0, #2
    // 0x55cc50: b.ne            #0x55ccb4
    // 0x55cc54: ldur            x1, [fp, #-0xb8]
    // 0x55cc58: r0 = LoadClassIdInstr(r1)
    //     0x55cc58: ldur            x0, [x1, #-1]
    //     0x55cc5c: ubfx            x0, x0, #0xc, #0x14
    // 0x55cc60: stp             xzr, x1, [SP, #-0x10]!
    // 0x55cc64: r0 = GDT[cid_x0 + -0xd83]()
    //     0x55cc64: sub             lr, x0, #0xd83
    //     0x55cc68: ldr             lr, [x21, lr, lsl #3]
    //     0x55cc6c: blr             lr
    // 0x55cc70: add             SP, SP, #0x10
    // 0x55cc74: ldur            x1, [fp, #-0xa8]
    // 0x55cc78: mov             x3, x0
    // 0x55cc7c: r2 = Null
    //     0x55cc7c: mov             x2, NULL
    // 0x55cc80: stur            x3, [fp, #-0xa8]
    // 0x55cc84: cmp             w1, NULL
    // 0x55cc88: b.eq            #0x55ccac
    // 0x55cc8c: LoadField: r4 = r1->field_1b
    //     0x55cc8c: ldur            w4, [x1, #0x1b]
    // 0x55cc90: DecompressPointer r4
    //     0x55cc90: add             x4, x4, HEAP, lsl #32
    // 0x55cc94: r8 = Y1
    //     0x55cc94: add             x8, PP, #0x14, lsl #12  ; [pp+0x14848] TypeParameter: Y1
    //     0x55cc98: ldr             x8, [x8, #0x848]
    // 0x55cc9c: LoadField: r9 = r4->field_7
    //     0x55cc9c: ldur            x9, [x4, #7]
    // 0x55cca0: r3 = Null
    //     0x55cca0: add             x3, PP, #0x14, lsl #12  ; [pp+0x14850] Null
    //     0x55cca4: ldr             x3, [x3, #0x850]
    // 0x55cca8: blr             x9
    // 0x55ccac: ldur            x0, [fp, #-0xa8]
    // 0x55ccb0: r0 = ReturnAsync()
    //     0x55ccb0: b               #0x501858  ; ReturnAsyncStub
    // 0x55ccb4: ldur            x1, [fp, #-0xb8]
    // 0x55ccb8: r2 = Null
    //     0x55ccb8: mov             x2, NULL
    // 0x55ccbc: b               #0x55ccd4
    // 0x55ccc0: ldur            x1, [fp, #-0xb8]
    // 0x55ccc4: r2 = Null
    //     0x55ccc4: mov             x2, NULL
    // 0x55ccc8: b               #0x55ccd4
    // 0x55cccc: ldur            x1, [fp, #-0xb8]
    // 0x55ccd0: r2 = Null
    //     0x55ccd0: mov             x2, NULL
    // 0x55ccd4: r0 = LoadClassIdInstr(r1)
    //     0x55ccd4: ldur            x0, [x1, #-1]
    //     0x55ccd8: ubfx            x0, x0, #0xc, #0x14
    // 0x55ccdc: stp             xzr, x1, [SP, #-0x10]!
    // 0x55cce0: r0 = GDT[cid_x0 + -0xd83]()
    //     0x55cce0: sub             lr, x0, #0xd83
    //     0x55cce4: ldr             lr, [x21, lr, lsl #3]
    //     0x55cce8: blr             lr
    // 0x55ccec: add             SP, SP, #0x10
    // 0x55ccf0: mov             x3, x0
    // 0x55ccf4: stur            x3, [fp, #-0xa8]
    // 0x55ccf8: cmp             w3, NULL
    // 0x55ccfc: b.ne            #0x55cd24
    // 0x55cd00: mov             x0, x3
    // 0x55cd04: r2 = Null
    //     0x55cd04: mov             x2, NULL
    // 0x55cd08: r1 = Null
    //     0x55cd08: mov             x1, NULL
    // 0x55cd0c: cmp             w0, NULL
    // 0x55cd10: b.ne            #0x55cd24
    // 0x55cd14: r8 = Object
    //     0x55cd14: ldr             x8, [PP, #0x3408]  ; [pp+0x3408] Type: Object
    // 0x55cd18: r3 = Null
    //     0x55cd18: add             x3, PP, #0x14, lsl #12  ; [pp+0x14860] Null
    //     0x55cd1c: ldr             x3, [x3, #0x860]
    // 0x55cd20: r0 = Object()
    //     0x55cd20: bl              #0xd74634  ; IsType_Object_Stub
    // 0x55cd24: ldur            x0, [fp, #-0xb8]
    // 0x55cd28: r1 = LoadClassIdInstr(r0)
    //     0x55cd28: ldur            x1, [x0, #-1]
    //     0x55cd2c: ubfx            x1, x1, #0xc, #0x14
    // 0x55cd30: r16 = 2
    //     0x55cd30: mov             x16, #2
    // 0x55cd34: stp             x16, x0, [SP, #-0x10]!
    // 0x55cd38: mov             x0, x1
    // 0x55cd3c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x55cd3c: sub             lr, x0, #0xd83
    //     0x55cd40: ldr             lr, [x21, lr, lsl #3]
    //     0x55cd44: blr             lr
    // 0x55cd48: add             SP, SP, #0x10
    // 0x55cd4c: mov             x3, x0
    // 0x55cd50: r2 = Null
    //     0x55cd50: mov             x2, NULL
    // 0x55cd54: r1 = Null
    //     0x55cd54: mov             x1, NULL
    // 0x55cd58: stur            x3, [fp, #-0xb0]
    // 0x55cd5c: r4 = 59
    //     0x55cd5c: mov             x4, #0x3b
    // 0x55cd60: branchIfSmi(r0, 0x55cd6c)
    //     0x55cd60: tbz             w0, #0, #0x55cd6c
    // 0x55cd64: r4 = LoadClassIdInstr(r0)
    //     0x55cd64: ldur            x4, [x0, #-1]
    //     0x55cd68: ubfx            x4, x4, #0xc, #0x14
    // 0x55cd6c: cmp             x4, #0x4c
    // 0x55cd70: b.eq            #0x55cd90
    // 0x55cd74: r17 = 5692
    //     0x55cd74: mov             x17, #0x163c
    // 0x55cd78: cmp             x4, x17
    // 0x55cd7c: b.eq            #0x55cd90
    // 0x55cd80: r8 = StackTrace
    //     0x55cd80: ldr             x8, [PP, #0x16e0]  ; [pp+0x16e0] Type: StackTrace
    // 0x55cd84: r3 = Null
    //     0x55cd84: add             x3, PP, #0x14, lsl #12  ; [pp+0x14870] Null
    //     0x55cd88: ldr             x3, [x3, #0x870]
    // 0x55cd8c: r0 = DefaultTypeTest()
    //     0x55cd8c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x55cd90: r16 = <Never>
    //     0x55cd90: ldr             x16, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    // 0x55cd94: ldur            lr, [fp, #-0xa8]
    // 0x55cd98: stp             lr, x16, [SP, #-0x10]!
    // 0x55cd9c: ldur            x16, [fp, #-0xb0]
    // 0x55cda0: SaveReg r16
    //     0x55cda0: str             x16, [SP, #-8]!
    // 0x55cda4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x55cda4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x55cda8: r0 = Future.error()
    //     0x55cda8: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0x55cdac: add             SP, SP, #0x18
    // 0x55cdb0: mov             x1, x0
    // 0x55cdb4: stur            x1, [fp, #-0xa8]
    // 0x55cdb8: r0 = Await()
    //     0x55cdb8: bl              #0x4b8e6c  ; AwaitStub
    // 0x55cdbc: r0 = Null
    //     0x55cdbc: mov             x0, NULL
    // 0x55cdc0: r0 = ReturnAsyncNotFuture()
    //     0x55cdc0: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x55cdc4: r0 = RemoteError()
    //     0x55cdc4: bl              #0x55cfe4  ; AllocateRemoteErrorStub -> RemoteError (size=0x10)
    // 0x55cdc8: mov             x1, x0
    // 0x55cdcc: r0 = "Isolate exited without result or error."
    //     0x55cdcc: add             x0, PP, #0x14, lsl #12  ; [pp+0x14880] "Isolate exited without result or error."
    //     0x55cdd0: ldr             x0, [x0, #0x880]
    // 0x55cdd4: stur            x1, [fp, #-0xb0]
    // 0x55cdd8: StoreField: r1->field_7 = r0
    //     0x55cdd8: stur            w0, [x1, #7]
    // 0x55cddc: r0 = _StringStackTrace()
    //     0x55cddc: bl              #0x55cfd8  ; Allocate_StringStackTraceStub -> _StringStackTrace (size=0xc)
    // 0x55cde0: mov             x1, x0
    // 0x55cde4: r0 = ""
    //     0x55cde4: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x55cde8: StoreField: r1->field_7 = r0
    //     0x55cde8: stur            w0, [x1, #7]
    // 0x55cdec: ldur            x0, [fp, #-0xb0]
    // 0x55cdf0: StoreField: r0->field_b = r1
    //     0x55cdf0: stur            w1, [x0, #0xb]
    // 0x55cdf4: r0 = Throw()
    //     0x55cdf4: bl              #0xd67e38  ; ThrowStub
    // 0x55cdf8: brk             #0
    // 0x55cdfc: ldur            x1, [fp, #-0xb8]
    // 0x55ce00: r0 = LoadClassIdInstr(r1)
    //     0x55ce00: ldur            x0, [x1, #-1]
    //     0x55ce04: ubfx            x0, x0, #0xc, #0x14
    // 0x55ce08: stp             xzr, x1, [SP, #-0x10]!
    // 0x55ce0c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x55ce0c: sub             lr, x0, #0xd83
    //     0x55ce10: ldr             lr, [x21, lr, lsl #3]
    //     0x55ce14: blr             lr
    // 0x55ce18: add             SP, SP, #0x10
    // 0x55ce1c: mov             x3, x0
    // 0x55ce20: r2 = Null
    //     0x55ce20: mov             x2, NULL
    // 0x55ce24: r1 = Null
    //     0x55ce24: mov             x1, NULL
    // 0x55ce28: stur            x3, [fp, #-0xa8]
    // 0x55ce2c: r4 = 59
    //     0x55ce2c: mov             x4, #0x3b
    // 0x55ce30: branchIfSmi(r0, 0x55ce3c)
    //     0x55ce30: tbz             w0, #0, #0x55ce3c
    // 0x55ce34: r4 = LoadClassIdInstr(r0)
    //     0x55ce34: ldur            x4, [x0, #-1]
    //     0x55ce38: ubfx            x4, x4, #0xc, #0x14
    // 0x55ce3c: sub             x4, x4, #0x5d
    // 0x55ce40: cmp             x4, #3
    // 0x55ce44: b.ls            #0x55ce58
    // 0x55ce48: r8 = String
    //     0x55ce48: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x55ce4c: r3 = Null
    //     0x55ce4c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14888] Null
    //     0x55ce50: ldr             x3, [x3, #0x888]
    // 0x55ce54: r0 = String()
    //     0x55ce54: bl              #0xd72afc  ; IsType_String_Stub
    // 0x55ce58: ldur            x1, [fp, #-0xb8]
    // 0x55ce5c: r0 = LoadClassIdInstr(r1)
    //     0x55ce5c: ldur            x0, [x1, #-1]
    //     0x55ce60: ubfx            x0, x0, #0xc, #0x14
    // 0x55ce64: r16 = 2
    //     0x55ce64: mov             x16, #2
    // 0x55ce68: stp             x16, x1, [SP, #-0x10]!
    // 0x55ce6c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x55ce6c: sub             lr, x0, #0xd83
    //     0x55ce70: ldr             lr, [x21, lr, lsl #3]
    //     0x55ce74: blr             lr
    // 0x55ce78: add             SP, SP, #0x10
    // 0x55ce7c: mov             x3, x0
    // 0x55ce80: r2 = Null
    //     0x55ce80: mov             x2, NULL
    // 0x55ce84: r1 = Null
    //     0x55ce84: mov             x1, NULL
    // 0x55ce88: stur            x3, [fp, #-0xb0]
    // 0x55ce8c: r4 = 59
    //     0x55ce8c: mov             x4, #0x3b
    // 0x55ce90: branchIfSmi(r0, 0x55ce9c)
    //     0x55ce90: tbz             w0, #0, #0x55ce9c
    // 0x55ce94: r4 = LoadClassIdInstr(r0)
    //     0x55ce94: ldur            x4, [x0, #-1]
    //     0x55ce98: ubfx            x4, x4, #0xc, #0x14
    // 0x55ce9c: sub             x4, x4, #0x5d
    // 0x55cea0: cmp             x4, #3
    // 0x55cea4: b.ls            #0x55ceb8
    // 0x55cea8: r8 = String
    //     0x55cea8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x55ceac: r3 = Null
    //     0x55ceac: add             x3, PP, #0x14, lsl #12  ; [pp+0x14898] Null
    //     0x55ceb0: ldr             x3, [x3, #0x898]
    // 0x55ceb4: r0 = String()
    //     0x55ceb4: bl              #0xd72afc  ; IsType_String_Stub
    // 0x55ceb8: r0 = RemoteError()
    //     0x55ceb8: bl              #0x55cfe4  ; AllocateRemoteErrorStub -> RemoteError (size=0x10)
    // 0x55cebc: mov             x1, x0
    // 0x55cec0: ldur            x0, [fp, #-0xa8]
    // 0x55cec4: stur            x1, [fp, #-0xc0]
    // 0x55cec8: StoreField: r1->field_7 = r0
    //     0x55cec8: stur            w0, [x1, #7]
    // 0x55cecc: r0 = _StringStackTrace()
    //     0x55cecc: bl              #0x55cfd8  ; Allocate_StringStackTraceStub -> _StringStackTrace (size=0xc)
    // 0x55ced0: mov             x1, x0
    // 0x55ced4: ldur            x0, [fp, #-0xb0]
    // 0x55ced8: StoreField: r1->field_7 = r0
    //     0x55ced8: stur            w0, [x1, #7]
    // 0x55cedc: ldur            x0, [fp, #-0xc0]
    // 0x55cee0: StoreField: r0->field_b = r1
    //     0x55cee0: stur            w1, [x0, #0xb]
    // 0x55cee4: r16 = <Never>
    //     0x55cee4: ldr             x16, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    // 0x55cee8: stp             x0, x16, [SP, #-0x10]!
    // 0x55ceec: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x55ceec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x55cef0: r0 = Future.error()
    //     0x55cef0: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0x55cef4: add             SP, SP, #0x10
    // 0x55cef8: mov             x1, x0
    // 0x55cefc: stur            x1, [fp, #-0xa8]
    // 0x55cf00: r0 = Await()
    //     0x55cf00: bl              #0x4b8e6c  ; AwaitStub
    // 0x55cf04: r0 = FallThroughError()
    //     0x55cf04: bl              #0x55cf84  ; AllocateFallThroughErrorStub -> FallThroughError (size=0x18)
    // 0x55cf08: mov             x1, x0
    // 0x55cf0c: r0 = "::_compute"
    //     0x55cf0c: add             x0, PP, #0x14, lsl #12  ; [pp+0x148a8] "::_compute"
    //     0x55cf10: ldr             x0, [x0, #0x8a8]
    // 0x55cf14: StoreField: r1->field_b = r0
    //     0x55cf14: stur            w0, [x1, #0xb]
    // 0x55cf18: r2 = Null
    //     0x55cf18: mov             x2, NULL
    // 0x55cf1c: r0 = LoadInt32Instr(r2)
    //     0x55cf1c: sbfx            x0, x2, #1, #0x1f
    //     0x55cf20: tbz             w2, #0, #0x55cf28
    //     0x55cf24: ldur            x0, [x2, #7]
    // 0x55cf28: StoreField: r1->field_f = r0
    //     0x55cf28: stur            x0, [x1, #0xf]
    // 0x55cf2c: mov             x0, x1
    // 0x55cf30: r0 = Throw()
    //     0x55cf30: bl              #0xd67e38  ; ThrowStub
    // 0x55cf34: brk             #0
    // 0x55cf38: sub             SP, fp, #0xe8
    // 0x55cf3c: mov             x2, x0
    // 0x55cf40: stur            x0, [fp, #-0xa8]
    // 0x55cf44: ldur            x0, [fp, #-0x40]
    // 0x55cf48: stur            x1, [fp, #-0xb0]
    // 0x55cf4c: LoadField: r3 = r0->field_1b
    //     0x55cf4c: ldur            w3, [x0, #0x1b]
    // 0x55cf50: DecompressPointer r3
    //     0x55cf50: add             x3, x3, HEAP, lsl #32
    // 0x55cf54: SaveReg r3
    //     0x55cf54: str             x3, [SP, #-8]!
    // 0x55cf58: mov             x0, x3
    // 0x55cf5c: ClosureCall
    //     0x55cf5c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x55cf60: ldur            x2, [x0, #0x1f]
    //     0x55cf64: blr             x2
    // 0x55cf68: add             SP, SP, #8
    // 0x55cf6c: ldur            x0, [fp, #-0xa8]
    // 0x55cf70: ldur            x1, [fp, #-0xb0]
    // 0x55cf74: r0 = ReThrow()
    //     0x55cf74: bl              #0xd67e14  ; ReThrowStub
    // 0x55cf78: brk             #0
    // 0x55cf7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55cf7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55cf80: b               #0x55c788
  }
  [closure] static Future<void> _spawn<Y0, Y1>(dynamic, _IsolateConfiguration<Y0, Y1>) {
    // ** addr: 0x55ddb8, size: 0x8c
    // 0x55ddb8: EnterFrame
    //     0x55ddb8: stp             fp, lr, [SP, #-0x10]!
    //     0x55ddbc: mov             fp, SP
    // 0x55ddc0: mov             x0, x4
    // 0x55ddc4: LoadField: r1 = r0->field_f
    //     0x55ddc4: ldur            w1, [x0, #0xf]
    // 0x55ddc8: DecompressPointer r1
    //     0x55ddc8: add             x1, x1, HEAP, lsl #32
    // 0x55ddcc: cbnz            w1, #0x55ddd8
    // 0x55ddd0: r1 = Null
    //     0x55ddd0: mov             x1, NULL
    // 0x55ddd4: b               #0x55ddec
    // 0x55ddd8: LoadField: r1 = r0->field_17
    //     0x55ddd8: ldur            w1, [x0, #0x17]
    // 0x55dddc: DecompressPointer r1
    //     0x55dddc: add             x1, x1, HEAP, lsl #32
    // 0x55dde0: add             x0, fp, w1, sxtw #2
    // 0x55dde4: ldr             x0, [x0, #0x10]
    // 0x55dde8: mov             x1, x0
    // 0x55ddec: ldr             x0, [fp, #0x18]
    // 0x55ddf0: LoadField: r2 = r0->field_f
    //     0x55ddf0: ldur            w2, [x0, #0xf]
    // 0x55ddf4: DecompressPointer r2
    //     0x55ddf4: add             x2, x2, HEAP, lsl #32
    // 0x55ddf8: r16 = 
    //     0x55ddf8: ldr             x16, [PP, #0x50]  ; [pp+0x50] TypeArguments: 
    // 0x55ddfc: cmp             w2, w16
    // 0x55de00: b.ne            #0x55de0c
    // 0x55de04: mov             x0, x1
    // 0x55de08: b               #0x55de10
    // 0x55de0c: mov             x0, x2
    // 0x55de10: CheckStackOverflow
    //     0x55de10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55de14: cmp             SP, x16
    //     0x55de18: b.ls            #0x55de3c
    // 0x55de1c: ldr             x16, [fp, #0x10]
    // 0x55de20: stp             x16, x0, [SP, #-0x10]!
    // 0x55de24: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x55de24: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x55de28: r0 = _spawn()
    //     0x55de28: bl              #0x55de44  ; [package:dio/src/compute/compute_io.dart] ::_spawn
    // 0x55de2c: add             SP, SP, #0x10
    // 0x55de30: LeaveFrame
    //     0x55de30: mov             SP, fp
    //     0x55de34: ldp             fp, lr, [SP], #0x10
    // 0x55de38: ret
    //     0x55de38: ret             
    // 0x55de3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55de3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55de40: b               #0x55de1c
  }
  static _ _spawn(/* No info */) async {
    // ** addr: 0x55de44, size: 0xd8
    // 0x55de44: EnterFrame
    //     0x55de44: stp             fp, lr, [SP, #-0x10]!
    //     0x55de48: mov             fp, SP
    // 0x55de4c: AllocStack(0x68)
    //     0x55de4c: sub             SP, SP, #0x68
    // 0x55de50: SetupParameters(dynamic _ /* r2, fp-0x60 */)
    //     0x55de50: stur            NULL, [fp, #-8]
    //     0x55de54: mov             x0, #0
    //     0x55de58: stur            x4, [fp, #-0x68]
    //     0x55de5c: mov             x1, x4
    //     0x55de60: add             x2, fp, w0, sxtw #2
    //     0x55de64: ldr             x2, [x2, #0x10]
    //     0x55de68: stur            x2, [fp, #-0x60]
    // 0x55de6c: CheckStackOverflow
    //     0x55de6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55de70: cmp             SP, x16
    //     0x55de74: b.ls            #0x55df14
    // 0x55de78: InitAsync() -> Future<void?>
    //     0x55de78: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x55de7c: bl              #0x4b92e4
    // 0x55de80: ldur            x16, [fp, #-0x60]
    // 0x55de84: SaveReg r16
    //     0x55de84: str             x16, [SP, #-8]!
    // 0x55de88: r0 = applyAndTime()
    //     0x55de88: bl              #0x55e0bc  ; [package:dio/src/compute/compute_io.dart] _IsolateConfiguration::applyAndTime
    // 0x55de8c: add             SP, SP, #8
    // 0x55de90: mov             x1, x0
    // 0x55de94: stur            x1, [fp, #-0x68]
    // 0x55de98: r0 = Await()
    //     0x55de98: bl              #0x4b8e6c  ; AwaitStub
    // 0x55de9c: stp             x0, NULL, [SP, #-0x10]!
    // 0x55dea0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x55dea0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x55dea4: r0 = _buildSuccessResponse()
    //     0x55dea4: bl              #0x55dfe0  ; [package:dio/src/compute/compute_io.dart] ::_buildSuccessResponse
    // 0x55dea8: add             SP, SP, #0x10
    // 0x55deac: ldur            x1, [fp, #-0x60]
    // 0x55deb0: b               #0x55def8
    // 0x55deb4: sub             SP, fp, #0x68
    // 0x55deb8: mov             x3, x0
    // 0x55debc: stur            x0, [fp, #-0x60]
    // 0x55dec0: mov             x0, x1
    // 0x55dec4: stur            x1, [fp, #-0x68]
    // 0x55dec8: r1 = Null
    //     0x55dec8: mov             x1, NULL
    // 0x55decc: r2 = 6
    //     0x55decc: mov             x2, #6
    // 0x55ded0: r0 = AllocateArray()
    //     0x55ded0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x55ded4: mov             x1, x0
    // 0x55ded8: ldur            x0, [fp, #-0x60]
    // 0x55dedc: StoreField: r1->field_f = r0
    //     0x55dedc: stur            w0, [x1, #0xf]
    // 0x55dee0: ldur            x0, [fp, #-0x68]
    // 0x55dee4: StoreField: r1->field_13 = r0
    //     0x55dee4: stur            w0, [x1, #0x13]
    // 0x55dee8: ldur            x0, [fp, #-0x10]
    // 0x55deec: mov             x16, x1
    // 0x55def0: mov             x1, x0
    // 0x55def4: mov             x0, x16
    // 0x55def8: LoadField: r2 = r1->field_13
    //     0x55def8: ldur            w2, [x1, #0x13]
    // 0x55defc: DecompressPointer r2
    //     0x55defc: add             x2, x2, HEAP, lsl #32
    // 0x55df00: stp             x0, x2, [SP, #-0x10]!
    // 0x55df04: r0 = exit()
    //     0x55df04: bl              #0x55df1c  ; [dart:isolate] Isolate::exit
    // 0x55df08: add             SP, SP, #0x10
    // 0x55df0c: r0 = Null
    //     0x55df0c: mov             x0, NULL
    // 0x55df10: r0 = ReturnAsyncNotFuture()
    //     0x55df10: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x55df14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55df14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55df18: b               #0x55de78
  }
  static _ _buildSuccessResponse(/* No info */) {
    // ** addr: 0x55dfe0, size: 0xdc
    // 0x55dfe0: EnterFrame
    //     0x55dfe0: stp             fp, lr, [SP, #-0x10]!
    //     0x55dfe4: mov             fp, SP
    // 0x55dfe8: AllocStack(0x10)
    //     0x55dfe8: sub             SP, SP, #0x10
    // 0x55dfec: SetupParameters()
    //     0x55dfec: mov             x0, x4
    //     0x55dff0: ldur            w1, [x0, #0xf]
    //     0x55dff4: add             x1, x1, HEAP, lsl #32
    //     0x55dff8: cbnz            w1, #0x55e004
    //     0x55dffc: mov             x3, NULL
    //     0x55e000: b               #0x55e018
    //     0x55e004: ldur            w1, [x0, #0x17]
    //     0x55e008: add             x1, x1, HEAP, lsl #32
    //     0x55e00c: add             x0, fp, w1, sxtw #2
    //     0x55e010: ldr             x0, [x0, #0x10]
    //     0x55e014: mov             x3, x0
    //     0x55e018: ldr             x0, [fp, #0x10]
    // 0x55e01c: mov             x1, x3
    // 0x55e020: stur            x3, [fp, #-8]
    // 0x55e024: r2 = 2
    //     0x55e024: mov             x2, #2
    // 0x55e028: r0 = AllocateArray()
    //     0x55e028: bl              #0xd6987c  ; AllocateArrayStub
    // 0x55e02c: mov             x4, x0
    // 0x55e030: ldr             x3, [fp, #0x10]
    // 0x55e034: stur            x4, [fp, #-0x10]
    // 0x55e038: cmp             w3, NULL
    // 0x55e03c: b.eq            #0x55e0a4
    // 0x55e040: mov             x0, x3
    // 0x55e044: ldur            x2, [fp, #-8]
    // 0x55e048: r1 = Null
    //     0x55e048: mov             x1, NULL
    // 0x55e04c: cmp             w2, NULL
    // 0x55e050: b.eq            #0x55e070
    // 0x55e054: LoadField: r4 = r2->field_17
    //     0x55e054: ldur            w4, [x2, #0x17]
    // 0x55e058: DecompressPointer r4
    //     0x55e058: add             x4, x4, HEAP, lsl #32
    // 0x55e05c: r8 = X0
    //     0x55e05c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x55e060: LoadField: r9 = r4->field_7
    //     0x55e060: ldur            x9, [x4, #7]
    // 0x55e064: r3 = Null
    //     0x55e064: add             x3, PP, #0x14, lsl #12  ; [pp+0x148b0] Null
    //     0x55e068: ldr             x3, [x3, #0x8b0]
    // 0x55e06c: blr             x9
    // 0x55e070: ldr             x1, [fp, #0x10]
    // 0x55e074: ldur            x0, [fp, #-0x10]
    // 0x55e078: r2 = 0
    //     0x55e078: mov             x2, #0
    // 0x55e07c: CheckStackOverflow
    //     0x55e07c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55e080: cmp             SP, x16
    //     0x55e084: b.ls            #0x55e0b4
    // 0x55e088: cmp             x2, #1
    // 0x55e08c: b.ge            #0x55e0a8
    // 0x55e090: ArrayStore: r0[r2] = r1  ; Unknown_4
    //     0x55e090: add             x3, x0, x2, lsl #2
    //     0x55e094: stur            w1, [x3, #0xf]
    // 0x55e098: add             x3, x2, #1
    // 0x55e09c: mov             x2, x3
    // 0x55e0a0: b               #0x55e07c
    // 0x55e0a4: mov             x0, x4
    // 0x55e0a8: LeaveFrame
    //     0x55e0a8: mov             SP, fp
    //     0x55e0ac: ldp             fp, lr, [SP], #0x10
    // 0x55e0b0: ret
    //     0x55e0b0: ret             
    // 0x55e0b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55e0b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55e0b8: b               #0x55e088
  }
  [closure] static Null <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x55e2a0, size: 0x7c
    // 0x55e2a0: EnterFrame
    //     0x55e2a0: stp             fp, lr, [SP, #-0x10]!
    //     0x55e2a4: mov             fp, SP
    // 0x55e2a8: AllocStack(0x8)
    //     0x55e2a8: sub             SP, SP, #8
    // 0x55e2ac: SetupParameters()
    //     0x55e2ac: ldr             x0, [fp, #0x18]
    //     0x55e2b0: ldur            w1, [x0, #0x17]
    //     0x55e2b4: add             x1, x1, HEAP, lsl #32
    //     0x55e2b8: stur            x1, [fp, #-8]
    // 0x55e2bc: CheckStackOverflow
    //     0x55e2bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55e2c0: cmp             SP, x16
    //     0x55e2c4: b.ls            #0x55e314
    // 0x55e2c8: LoadField: r0 = r1->field_1b
    //     0x55e2c8: ldur            w0, [x1, #0x1b]
    // 0x55e2cc: DecompressPointer r0
    //     0x55e2cc: add             x0, x0, HEAP, lsl #32
    // 0x55e2d0: SaveReg r0
    //     0x55e2d0: str             x0, [SP, #-8]!
    // 0x55e2d4: ClosureCall
    //     0x55e2d4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x55e2d8: ldur            x2, [x0, #0x1f]
    //     0x55e2dc: blr             x2
    // 0x55e2e0: add             SP, SP, #8
    // 0x55e2e4: ldur            x0, [fp, #-8]
    // 0x55e2e8: LoadField: r1 = r0->field_1f
    //     0x55e2e8: ldur            w1, [x0, #0x1f]
    // 0x55e2ec: DecompressPointer r1
    //     0x55e2ec: add             x1, x1, HEAP, lsl #32
    // 0x55e2f0: ldr             x16, [fp, #0x10]
    // 0x55e2f4: stp             x16, x1, [SP, #-0x10]!
    // 0x55e2f8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x55e2f8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x55e2fc: r0 = complete()
    //     0x55e2fc: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x55e300: add             SP, SP, #0x10
    // 0x55e304: r0 = Null
    //     0x55e304: mov             x0, NULL
    // 0x55e308: LeaveFrame
    //     0x55e308: mov             SP, fp
    //     0x55e30c: ldp             fp, lr, [SP], #0x10
    // 0x55e310: ret
    //     0x55e310: ret             
    // 0x55e314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55e314: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55e318: b               #0x55e2c8
  }
  [closure] static void timeEndAndCleanup(dynamic) {
    // ** addr: 0x55e31c, size: 0xd4
    // 0x55e31c: EnterFrame
    //     0x55e31c: stp             fp, lr, [SP, #-0x10]!
    //     0x55e320: mov             fp, SP
    // 0x55e324: AllocStack(0x10)
    //     0x55e324: sub             SP, SP, #0x10
    // 0x55e328: SetupParameters()
    //     0x55e328: ldr             x0, [fp, #0x10]
    //     0x55e32c: ldur            w3, [x0, #0x17]
    //     0x55e330: add             x3, x3, HEAP, lsl #32
    //     0x55e334: stur            x3, [fp, #-0x10]
    // 0x55e338: CheckStackOverflow
    //     0x55e338: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55e33c: cmp             SP, x16
    //     0x55e340: b.ls            #0x55e3e8
    // 0x55e344: LoadField: r0 = r3->field_f
    //     0x55e344: ldur            w0, [x3, #0xf]
    // 0x55e348: DecompressPointer r0
    //     0x55e348: add             x0, x0, HEAP, lsl #32
    // 0x55e34c: stur            x0, [fp, #-8]
    // 0x55e350: r1 = Null
    //     0x55e350: mov             x1, NULL
    // 0x55e354: r2 = 4
    //     0x55e354: mov             x2, #4
    // 0x55e358: r0 = AllocateArray()
    //     0x55e358: bl              #0xd6987c  ; AllocateArrayStub
    // 0x55e35c: mov             x1, x0
    // 0x55e360: ldur            x0, [fp, #-8]
    // 0x55e364: StoreField: r1->field_f = r0
    //     0x55e364: stur            w0, [x1, #0xf]
    // 0x55e368: r17 = ": end"
    //     0x55e368: add             x17, PP, #0x14, lsl #12  ; [pp+0x148d0] ": end"
    //     0x55e36c: ldr             x17, [x17, #0x8d0]
    // 0x55e370: StoreField: r1->field_13 = r17
    //     0x55e370: stur            w17, [x1, #0x13]
    // 0x55e374: SaveReg r1
    //     0x55e374: str             x1, [SP, #-8]!
    // 0x55e378: r0 = _interpolate()
    //     0x55e378: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x55e37c: add             SP, SP, #8
    // 0x55e380: mov             x1, x0
    // 0x55e384: ldur            x0, [fp, #-0x10]
    // 0x55e388: stur            x1, [fp, #-8]
    // 0x55e38c: LoadField: r2 = r0->field_13
    //     0x55e38c: ldur            w2, [x0, #0x13]
    // 0x55e390: DecompressPointer r2
    //     0x55e390: add             x2, x2, HEAP, lsl #32
    // 0x55e394: LoadField: r3 = r2->field_f
    //     0x55e394: ldur            x3, [x2, #0xf]
    // 0x55e398: SaveReg r3
    //     0x55e398: str             x3, [SP, #-8]!
    // 0x55e39c: r0 = end()
    //     0x55e39c: bl              #0x55e3f0  ; [dart:developer] Flow::end
    // 0x55e3a0: add             SP, SP, #8
    // 0x55e3a4: ldur            x16, [fp, #-8]
    // 0x55e3a8: stp             x0, x16, [SP, #-0x10]!
    // 0x55e3ac: r4 = const [0, 0x2, 0x2, 0x1, flow, 0x1, null]
    //     0x55e3ac: add             x4, PP, #0x14, lsl #12  ; [pp+0x14810] List(7) [0, 0x2, 0x2, 0x1, "flow", 0x1, Null]
    //     0x55e3b0: ldr             x4, [x4, #0x810]
    // 0x55e3b4: r0 = startSync()
    //     0x55e3b4: bl              #0x55da8c  ; [dart:developer] Timeline::startSync
    // 0x55e3b8: add             SP, SP, #0x10
    // 0x55e3bc: ldur            x0, [fp, #-0x10]
    // 0x55e3c0: LoadField: r1 = r0->field_17
    //     0x55e3c0: ldur            w1, [x0, #0x17]
    // 0x55e3c4: DecompressPointer r1
    //     0x55e3c4: add             x1, x1, HEAP, lsl #32
    // 0x55e3c8: SaveReg r1
    //     0x55e3c8: str             x1, [SP, #-8]!
    // 0x55e3cc: r0 = close()
    //     0x55e3cc: bl              #0x4e5cc8  ; [dart:isolate] _RawReceivePort::close
    // 0x55e3d0: add             SP, SP, #8
    // 0x55e3d4: r0 = finishSync()
    //     0x55e3d4: bl              #0x55d838  ; [dart:developer] Timeline::finishSync
    // 0x55e3d8: r0 = Null
    //     0x55e3d8: mov             x0, NULL
    // 0x55e3dc: LeaveFrame
    //     0x55e3dc: mov             SP, fp
    //     0x55e3e0: ldp             fp, lr, [SP], #0x10
    // 0x55e3e4: ret
    //     0x55e3e4: ret             
    // 0x55e3e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55e3e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55e3ec: b               #0x55e344
  }
}

// class id: 4549, size: 0x24, field offset: 0x8
//   const constructor, 
class _IsolateConfiguration<X0, X1> extends Object {

  _ applyAndTime(/* No info */) {
    // ** addr: 0x55e0bc, size: 0xc8
    // 0x55e0bc: EnterFrame
    //     0x55e0bc: stp             fp, lr, [SP, #-0x10]!
    //     0x55e0c0: mov             fp, SP
    // 0x55e0c4: AllocStack(0x18)
    //     0x55e0c4: sub             SP, SP, #0x18
    // 0x55e0c8: CheckStackOverflow
    //     0x55e0c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55e0cc: cmp             SP, x16
    //     0x55e0d0: b.ls            #0x55e17c
    // 0x55e0d4: r1 = 1
    //     0x55e0d4: mov             x1, #1
    // 0x55e0d8: r0 = AllocateContext()
    //     0x55e0d8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x55e0dc: mov             x1, x0
    // 0x55e0e0: ldr             x0, [fp, #0x10]
    // 0x55e0e4: StoreField: r1->field_f = r0
    //     0x55e0e4: stur            w0, [x1, #0xf]
    // 0x55e0e8: LoadField: r3 = r0->field_17
    //     0x55e0e8: ldur            w3, [x0, #0x17]
    // 0x55e0ec: DecompressPointer r3
    //     0x55e0ec: add             x3, x3, HEAP, lsl #32
    // 0x55e0f0: stur            x3, [fp, #-0x10]
    // 0x55e0f4: LoadField: r4 = r0->field_7
    //     0x55e0f4: ldur            w4, [x0, #7]
    // 0x55e0f8: DecompressPointer r4
    //     0x55e0f8: add             x4, x4, HEAP, lsl #32
    // 0x55e0fc: mov             x2, x1
    // 0x55e100: stur            x4, [fp, #-8]
    // 0x55e104: r1 = Function '<anonymous closure>':.
    //     0x55e104: add             x1, PP, #0x14, lsl #12  ; [pp+0x148c0] AnonymousClosure: (0x55e23c), in [package:dio/src/compute/compute_io.dart] _IsolateConfiguration::applyAndTime (0x55e0bc)
    //     0x55e108: ldr             x1, [x1, #0x8c0]
    // 0x55e10c: r0 = AllocateClosure()
    //     0x55e10c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x55e110: ldur            x2, [fp, #-8]
    // 0x55e114: stur            x0, [fp, #-0x18]
    // 0x55e118: StoreField: r0->field_7 = r2
    //     0x55e118: stur            w2, [x0, #7]
    // 0x55e11c: ldr             x1, [fp, #0x10]
    // 0x55e120: LoadField: r3 = r1->field_1b
    //     0x55e120: ldur            x3, [x1, #0x1b]
    // 0x55e124: SaveReg r3
    //     0x55e124: str             x3, [SP, #-8]!
    // 0x55e128: r0 = step()
    //     0x55e128: bl              #0x55e214  ; [dart:developer] Flow::step
    // 0x55e12c: add             SP, SP, #8
    // 0x55e130: ldur            x2, [fp, #-8]
    // 0x55e134: r1 = Null
    //     0x55e134: mov             x1, NULL
    // 0x55e138: r3 = <FutureOr<X1>>
    //     0x55e138: add             x3, PP, #0x14, lsl #12  ; [pp+0x148c8] TypeArguments: <FutureOr<X1>>
    //     0x55e13c: ldr             x3, [x3, #0x8c8]
    // 0x55e140: stur            x0, [fp, #-8]
    // 0x55e144: r24 = InstantiateTypeArgumentsStub
    //     0x55e144: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x55e148: LoadField: r30 = r24->field_7
    //     0x55e148: ldur            lr, [x24, #7]
    // 0x55e14c: blr             lr
    // 0x55e150: ldur            x16, [fp, #-0x10]
    // 0x55e154: stp             x16, x0, [SP, #-0x10]!
    // 0x55e158: ldur            x16, [fp, #-0x18]
    // 0x55e15c: ldur            lr, [fp, #-8]
    // 0x55e160: stp             lr, x16, [SP, #-0x10]!
    // 0x55e164: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x55e164: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x55e168: r0 = timeSync()
    //     0x55e168: bl              #0x55e184  ; [dart:developer] Timeline::timeSync
    // 0x55e16c: add             SP, SP, #0x20
    // 0x55e170: LeaveFrame
    //     0x55e170: mov             SP, fp
    //     0x55e174: ldp             fp, lr, [SP], #0x10
    // 0x55e178: ret
    //     0x55e178: ret             
    // 0x55e17c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55e17c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55e180: b               #0x55e0d4
  }
  [closure] FutureOr<X1> <anonymous closure>(dynamic) {
    // ** addr: 0x55e23c, size: 0x64
    // 0x55e23c: EnterFrame
    //     0x55e23c: stp             fp, lr, [SP, #-0x10]!
    //     0x55e240: mov             fp, SP
    // 0x55e244: ldr             x0, [fp, #0x10]
    // 0x55e248: LoadField: r1 = r0->field_17
    //     0x55e248: ldur            w1, [x0, #0x17]
    // 0x55e24c: DecompressPointer r1
    //     0x55e24c: add             x1, x1, HEAP, lsl #32
    // 0x55e250: CheckStackOverflow
    //     0x55e250: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55e254: cmp             SP, x16
    //     0x55e258: b.ls            #0x55e298
    // 0x55e25c: LoadField: r0 = r1->field_f
    //     0x55e25c: ldur            w0, [x1, #0xf]
    // 0x55e260: DecompressPointer r0
    //     0x55e260: add             x0, x0, HEAP, lsl #32
    // 0x55e264: LoadField: r1 = r0->field_f
    //     0x55e264: ldur            w1, [x0, #0xf]
    // 0x55e268: DecompressPointer r1
    //     0x55e268: add             x1, x1, HEAP, lsl #32
    // 0x55e26c: LoadField: r2 = r0->field_b
    //     0x55e26c: ldur            w2, [x0, #0xb]
    // 0x55e270: DecompressPointer r2
    //     0x55e270: add             x2, x2, HEAP, lsl #32
    // 0x55e274: stp             x1, x2, [SP, #-0x10]!
    // 0x55e278: mov             x0, x2
    // 0x55e27c: ClosureCall
    //     0x55e27c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x55e280: ldur            x2, [x0, #0x1f]
    //     0x55e284: blr             x2
    // 0x55e288: add             SP, SP, #0x10
    // 0x55e28c: LeaveFrame
    //     0x55e28c: mov             SP, fp
    //     0x55e290: ldp             fp, lr, [SP], #0x10
    // 0x55e294: ret
    //     0x55e294: ret             
    // 0x55e298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55e298: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55e29c: b               #0x55e25c
  }
}

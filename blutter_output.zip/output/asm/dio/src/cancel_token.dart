// lib: , url: package:dio/src/cancel_token.dart

// class id: 1048881, size: 0x8
class :: {
}

// class id: 4550, size: 0x14, field offset: 0x8
class CancelToken extends Object {

  _ CancelToken(/* No info */) {
    // ** addr: 0x889768, size: 0xa8
    // 0x889768: EnterFrame
    //     0x889768: stp             fp, lr, [SP, #-0x10]!
    //     0x88976c: mov             fp, SP
    // 0x889770: AllocStack(0x8)
    //     0x889770: sub             SP, SP, #8
    // 0x889774: CheckStackOverflow
    //     0x889774: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x889778: cmp             SP, x16
    //     0x88977c: b.ls            #0x889808
    // 0x889780: r1 = <DioException>
    //     0x889780: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f78] TypeArguments: <DioException>
    //     0x889784: ldr             x1, [x1, #0xf78]
    // 0x889788: r0 = _Future()
    //     0x889788: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x88978c: mov             x1, x0
    // 0x889790: r0 = 0
    //     0x889790: mov             x0, #0
    // 0x889794: stur            x1, [fp, #-8]
    // 0x889798: StoreField: r1->field_b = r0
    //     0x889798: stur            x0, [x1, #0xb]
    // 0x88979c: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x88979c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8897a0: ldr             x0, [x0, #0xb58]
    //     0x8897a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8897a8: cmp             w0, w16
    //     0x8897ac: b.ne            #0x8897b8
    //     0x8897b0: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x8897b4: bl              #0xd67d44
    // 0x8897b8: mov             x1, x0
    // 0x8897bc: ldur            x0, [fp, #-8]
    // 0x8897c0: StoreField: r0->field_13 = r1
    //     0x8897c0: stur            w1, [x0, #0x13]
    // 0x8897c4: r1 = <DioException>
    //     0x8897c4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12f78] TypeArguments: <DioException>
    //     0x8897c8: ldr             x1, [x1, #0xf78]
    // 0x8897cc: r0 = _AsyncCompleter()
    //     0x8897cc: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x8897d0: ldur            x1, [fp, #-8]
    // 0x8897d4: StoreField: r0->field_b = r1
    //     0x8897d4: stur            w1, [x0, #0xb]
    // 0x8897d8: ldr             x1, [fp, #0x10]
    // 0x8897dc: StoreField: r1->field_7 = r0
    //     0x8897dc: stur            w0, [x1, #7]
    //     0x8897e0: ldurb           w16, [x1, #-1]
    //     0x8897e4: ldurb           w17, [x0, #-1]
    //     0x8897e8: and             x16, x17, x16, lsr #2
    //     0x8897ec: tst             x16, HEAP, lsr #32
    //     0x8897f0: b.eq            #0x8897f8
    //     0x8897f4: bl              #0xd6826c
    // 0x8897f8: r0 = Null
    //     0x8897f8: mov             x0, NULL
    // 0x8897fc: LeaveFrame
    //     0x8897fc: mov             SP, fp
    //     0x889800: ldp             fp, lr, [SP], #0x10
    // 0x889804: ret
    //     0x889804: ret             
    // 0x889808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x889808: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88980c: b               #0x889780
  }
  _ cancel(/* No info */) {
    // ** addr: 0xa5680c, size: 0xdc
    // 0xa5680c: EnterFrame
    //     0xa5680c: stp             fp, lr, [SP, #-0x10]!
    //     0xa56810: mov             fp, SP
    // 0xa56814: AllocStack(0x8)
    //     0xa56814: sub             SP, SP, #8
    // 0xa56818: CheckStackOverflow
    //     0xa56818: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5681c: cmp             SP, x16
    //     0xa56820: b.ls            #0xa568e0
    // 0xa56824: ldr             x0, [fp, #0x10]
    // 0xa56828: LoadField: r1 = r0->field_f
    //     0xa56828: ldur            w1, [x0, #0xf]
    // 0xa5682c: DecompressPointer r1
    //     0xa5682c: add             x1, x1, HEAP, lsl #32
    // 0xa56830: cmp             w1, NULL
    // 0xa56834: b.ne            #0xa56854
    // 0xa56838: r0 = RequestOptions()
    //     0xa56838: bl              #0x55bbc8  ; AllocateRequestOptionsStub -> RequestOptions (size=0x68)
    // 0xa5683c: stur            x0, [fp, #-8]
    // 0xa56840: SaveReg r0
    //     0xa56840: str             x0, [SP, #-8]!
    // 0xa56844: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa56844: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa56848: r0 = RequestOptions()
    //     0xa56848: bl              #0x55ae64  ; [package:dio/src/options.dart] RequestOptions::RequestOptions
    // 0xa5684c: add             SP, SP, #8
    // 0xa56850: ldur            x1, [fp, #-8]
    // 0xa56854: ldr             x0, [fp, #0x10]
    // 0xa56858: stur            x1, [fp, #-8]
    // 0xa5685c: r0 = current()
    //     0xa5685c: bl              #0x4ff3d0  ; [dart:core] StackTrace::current
    // 0xa56860: ldur            x16, [fp, #-8]
    // 0xa56864: stp             x16, NULL, [SP, #-0x10]!
    // 0xa56868: SaveReg r0
    //     0xa56868: str             x0, [SP, #-8]!
    // 0xa5686c: r0 = DioException.requestCancelled()
    //     0xa5686c: bl              #0xa568e8  ; [package:dio/src/dio_exception.dart] DioException::DioException.requestCancelled
    // 0xa56870: add             SP, SP, #0x18
    // 0xa56874: mov             x2, x0
    // 0xa56878: ldr             x1, [fp, #0x10]
    // 0xa5687c: StoreField: r1->field_b = r0
    //     0xa5687c: stur            w0, [x1, #0xb]
    //     0xa56880: ldurb           w16, [x1, #-1]
    //     0xa56884: ldurb           w17, [x0, #-1]
    //     0xa56888: and             x16, x17, x16, lsr #2
    //     0xa5688c: tst             x16, HEAP, lsr #32
    //     0xa56890: b.eq            #0xa56898
    //     0xa56894: bl              #0xd6826c
    // 0xa56898: LoadField: r0 = r1->field_7
    //     0xa56898: ldur            w0, [x1, #7]
    // 0xa5689c: DecompressPointer r0
    //     0xa5689c: add             x0, x0, HEAP, lsl #32
    // 0xa568a0: LoadField: r1 = r0->field_b
    //     0xa568a0: ldur            w1, [x0, #0xb]
    // 0xa568a4: DecompressPointer r1
    //     0xa568a4: add             x1, x1, HEAP, lsl #32
    // 0xa568a8: LoadField: r3 = r1->field_b
    //     0xa568a8: ldur            x3, [x1, #0xb]
    // 0xa568ac: ubfx            x3, x3, #0, #0x20
    // 0xa568b0: r1 = 30
    //     0xa568b0: mov             x1, #0x1e
    // 0xa568b4: and             x4, x3, x1
    // 0xa568b8: ubfx            x4, x4, #0, #0x20
    // 0xa568bc: cbnz            x4, #0xa568d0
    // 0xa568c0: stp             x2, x0, [SP, #-0x10]!
    // 0xa568c4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa568c4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa568c8: r0 = complete()
    //     0xa568c8: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0xa568cc: add             SP, SP, #0x10
    // 0xa568d0: r0 = Null
    //     0xa568d0: mov             x0, NULL
    // 0xa568d4: LeaveFrame
    //     0xa568d4: mov             SP, fp
    //     0xa568d8: ldp             fp, lr, [SP], #0x10
    // 0xa568dc: ret
    //     0xa568dc: ret             
    // 0xa568e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa568e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa568e4: b               #0xa56824
  }
}

// lib: , url: package:csslib/visitor.dart

// class id: 1048826, size: 0x8
class :: {
}

// class id: 4638, size: 0x8, field offset: 0x8
class BAD_HEX_VALUE extends Object {
}

// class id: 4639, size: 0xc, field offset: 0x8
abstract class TreeNode extends Object {
}

// class id: 4640, size: 0x14, field offset: 0xc
abstract class DartStyleExpression extends TreeNode {
}

// class id: 4641, size: 0x14, field offset: 0x14
class WidthExpression extends DartStyleExpression {

  _ visit(/* No info */) {
    // ** addr: 0xbfc7a0, size: 0x38
    // 0xbfc7a0: EnterFrame
    //     0xbfc7a0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc7a4: mov             fp, SP
    // 0xbfc7a8: CheckStackOverflow
    //     0xbfc7a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc7ac: cmp             SP, x16
    //     0xbfc7b0: b.ls            #0xbfc7d0
    // 0xbfc7b4: ldr             x16, [fp, #0x10]
    // 0xbfc7b8: SaveReg r16
    //     0xbfc7b8: str             x16, [SP, #-8]!
    // 0xbfc7bc: r0 = createSession()
    //     0xbfc7bc: bl              #0xcceeb4  ; [package:flutter/src/services/mouse_cursor.dart] _DeferringMouseCursor::createSession
    // 0xbfc7c0: add             SP, SP, #8
    // 0xbfc7c4: LeaveFrame
    //     0xbfc7c4: mov             SP, fp
    //     0xbfc7c8: ldp             fp, lr, [SP], #0x10
    // 0xbfc7cc: ret
    //     0xbfc7cc: ret             
    // 0xbfc7d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc7d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc7d4: b               #0xbfc7b4
  }
}

// class id: 4642, size: 0x14, field offset: 0x14
class HeightExpression extends DartStyleExpression {

  _ visit(/* No info */) {
    // ** addr: 0xbfc768, size: 0x38
    // 0xbfc768: EnterFrame
    //     0xbfc768: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc76c: mov             fp, SP
    // 0xbfc770: CheckStackOverflow
    //     0xbfc770: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc774: cmp             SP, x16
    //     0xbfc778: b.ls            #0xbfc798
    // 0xbfc77c: ldr             x16, [fp, #0x10]
    // 0xbfc780: SaveReg r16
    //     0xbfc780: str             x16, [SP, #-8]!
    // 0xbfc784: r0 = createSession()
    //     0xbfc784: bl              #0xcceeb4  ; [package:flutter/src/services/mouse_cursor.dart] _DeferringMouseCursor::createSession
    // 0xbfc788: add             SP, SP, #8
    // 0xbfc78c: LeaveFrame
    //     0xbfc78c: mov             SP, fp
    //     0xbfc790: ldp             fp, lr, [SP], #0x10
    // 0xbfc794: ret
    //     0xbfc794: ret             
    // 0xbfc798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc798: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc79c: b               #0xbfc77c
  }
}

// class id: 4643, size: 0x14, field offset: 0x14
abstract class BoxExpression extends DartStyleExpression {
}

// class id: 4644, size: 0x14, field offset: 0x14
class PaddingExpression extends BoxExpression {

  _ visit(/* No info */) {
    // ** addr: 0xbfc730, size: 0x38
    // 0xbfc730: EnterFrame
    //     0xbfc730: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc734: mov             fp, SP
    // 0xbfc738: CheckStackOverflow
    //     0xbfc738: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc73c: cmp             SP, x16
    //     0xbfc740: b.ls            #0xbfc760
    // 0xbfc744: ldr             x16, [fp, #0x10]
    // 0xbfc748: SaveReg r16
    //     0xbfc748: str             x16, [SP, #-8]!
    // 0xbfc74c: r0 = createSession()
    //     0xbfc74c: bl              #0xcceeb4  ; [package:flutter/src/services/mouse_cursor.dart] _DeferringMouseCursor::createSession
    // 0xbfc750: add             SP, SP, #8
    // 0xbfc754: LeaveFrame
    //     0xbfc754: mov             SP, fp
    //     0xbfc758: ldp             fp, lr, [SP], #0x10
    // 0xbfc75c: ret
    //     0xbfc75c: ret             
    // 0xbfc760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc760: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc764: b               #0xbfc744
  }
}

// class id: 4645, size: 0x14, field offset: 0x14
class BorderExpression extends BoxExpression {

  _ visit(/* No info */) {
    // ** addr: 0xbfc6f8, size: 0x38
    // 0xbfc6f8: EnterFrame
    //     0xbfc6f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc6fc: mov             fp, SP
    // 0xbfc700: CheckStackOverflow
    //     0xbfc700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc704: cmp             SP, x16
    //     0xbfc708: b.ls            #0xbfc728
    // 0xbfc70c: ldr             x16, [fp, #0x10]
    // 0xbfc710: SaveReg r16
    //     0xbfc710: str             x16, [SP, #-8]!
    // 0xbfc714: r0 = createSession()
    //     0xbfc714: bl              #0xcceeb4  ; [package:flutter/src/services/mouse_cursor.dart] _DeferringMouseCursor::createSession
    // 0xbfc718: add             SP, SP, #8
    // 0xbfc71c: LeaveFrame
    //     0xbfc71c: mov             SP, fp
    //     0xbfc720: ldp             fp, lr, [SP], #0x10
    // 0xbfc724: ret
    //     0xbfc724: ret             
    // 0xbfc728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc728: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc72c: b               #0xbfc70c
  }
}

// class id: 4646, size: 0x14, field offset: 0x14
class MarginExpression extends BoxExpression {

  _ visit(/* No info */) {
    // ** addr: 0xbfc6c0, size: 0x38
    // 0xbfc6c0: EnterFrame
    //     0xbfc6c0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc6c4: mov             fp, SP
    // 0xbfc6c8: CheckStackOverflow
    //     0xbfc6c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc6cc: cmp             SP, x16
    //     0xbfc6d0: b.ls            #0xbfc6f0
    // 0xbfc6d4: ldr             x16, [fp, #0x10]
    // 0xbfc6d8: SaveReg r16
    //     0xbfc6d8: str             x16, [SP, #-8]!
    // 0xbfc6dc: r0 = createSession()
    //     0xbfc6dc: bl              #0xcceeb4  ; [package:flutter/src/services/mouse_cursor.dart] _DeferringMouseCursor::createSession
    // 0xbfc6e0: add             SP, SP, #8
    // 0xbfc6e4: LeaveFrame
    //     0xbfc6e4: mov             SP, fp
    //     0xbfc6e8: ldp             fp, lr, [SP], #0x10
    // 0xbfc6ec: ret
    //     0xbfc6ec: ret             
    // 0xbfc6f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc6f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc6f4: b               #0xbfc6d4
  }
}

// class id: 4647, size: 0x18, field offset: 0x14
class FontExpression extends DartStyleExpression {

  _ FontExpression(/* No info */) {
    // ** addr: 0xb6d13c, size: 0x268
    // 0xb6d13c: EnterFrame
    //     0xb6d13c: stp             fp, lr, [SP, #-0x10]!
    //     0xb6d140: mov             fp, SP
    // 0xb6d144: AllocStack(0x30)
    //     0xb6d144: sub             SP, SP, #0x30
    // 0xb6d148: SetupParameters(FontExpression this /* r3, fp-0x30 */, dynamic _ /* r4, fp-0x28 */, {dynamic family = Null /* r5, fp-0x20 */, dynamic lineHeight = Null /* r6, fp-0x18 */, dynamic size = Null /* r7 */, dynamic weight = Null /* r8, fp-0x10 */})
    //     0xb6d148: mov             x0, x4
    //     0xb6d14c: ldur            w1, [x0, #0x13]
    //     0xb6d150: add             x1, x1, HEAP, lsl #32
    //     0xb6d154: sub             x2, x1, #4
    //     0xb6d158: add             x3, fp, w2, sxtw #2
    //     0xb6d15c: ldr             x3, [x3, #0x18]
    //     0xb6d160: stur            x3, [fp, #-0x30]
    //     0xb6d164: add             x4, fp, w2, sxtw #2
    //     0xb6d168: ldr             x4, [x4, #0x10]
    //     0xb6d16c: stur            x4, [fp, #-0x28]
    //     0xb6d170: ldur            w2, [x0, #0x1f]
    //     0xb6d174: add             x2, x2, HEAP, lsl #32
    //     0xb6d178: ldr             x16, [PP, #0x7b80]  ; [pp+0x7b80] "family"
    //     0xb6d17c: cmp             w2, w16
    //     0xb6d180: b.ne            #0xb6d1a4
    //     0xb6d184: ldur            w2, [x0, #0x23]
    //     0xb6d188: add             x2, x2, HEAP, lsl #32
    //     0xb6d18c: sub             w5, w1, w2
    //     0xb6d190: add             x2, fp, w5, sxtw #2
    //     0xb6d194: ldr             x2, [x2, #8]
    //     0xb6d198: mov             x5, x2
    //     0xb6d19c: mov             x2, #1
    //     0xb6d1a0: b               #0xb6d1ac
    //     0xb6d1a4: mov             x5, NULL
    //     0xb6d1a8: mov             x2, #0
    //     0xb6d1ac: stur            x5, [fp, #-0x20]
    //     0xb6d1b0: lsl             x6, x2, #1
    //     0xb6d1b4: lsl             w7, w6, #1
    //     0xb6d1b8: add             w8, w7, #8
    //     0xb6d1bc: add             x16, x0, w8, sxtw #1
    //     0xb6d1c0: ldur            w9, [x16, #0xf]
    //     0xb6d1c4: add             x9, x9, HEAP, lsl #32
    //     0xb6d1c8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26f40] "lineHeight"
    //     0xb6d1cc: ldr             x16, [x16, #0xf40]
    //     0xb6d1d0: cmp             w9, w16
    //     0xb6d1d4: b.ne            #0xb6d208
    //     0xb6d1d8: add             w2, w7, #0xa
    //     0xb6d1dc: add             x16, x0, w2, sxtw #1
    //     0xb6d1e0: ldur            w7, [x16, #0xf]
    //     0xb6d1e4: add             x7, x7, HEAP, lsl #32
    //     0xb6d1e8: sub             w2, w1, w7
    //     0xb6d1ec: add             x7, fp, w2, sxtw #2
    //     0xb6d1f0: ldr             x7, [x7, #8]
    //     0xb6d1f4: add             w2, w6, #2
    //     0xb6d1f8: sbfx            x6, x2, #1, #0x1f
    //     0xb6d1fc: mov             x2, x6
    //     0xb6d200: mov             x6, x7
    //     0xb6d204: b               #0xb6d20c
    //     0xb6d208: mov             x6, NULL
    //     0xb6d20c: stur            x6, [fp, #-0x18]
    //     0xb6d210: lsl             x7, x2, #1
    //     0xb6d214: lsl             w8, w7, #1
    //     0xb6d218: add             w9, w8, #8
    //     0xb6d21c: add             x16, x0, w9, sxtw #1
    //     0xb6d220: ldur            w10, [x16, #0xf]
    //     0xb6d224: add             x10, x10, HEAP, lsl #32
    //     0xb6d228: add             x16, PP, #0x14, lsl #12  ; [pp+0x14fc0] "size"
    //     0xb6d22c: ldr             x16, [x16, #0xfc0]
    //     0xb6d230: cmp             w10, w16
    //     0xb6d234: b.ne            #0xb6d268
    //     0xb6d238: add             w2, w8, #0xa
    //     0xb6d23c: add             x16, x0, w2, sxtw #1
    //     0xb6d240: ldur            w8, [x16, #0xf]
    //     0xb6d244: add             x8, x8, HEAP, lsl #32
    //     0xb6d248: sub             w2, w1, w8
    //     0xb6d24c: add             x8, fp, w2, sxtw #2
    //     0xb6d250: ldr             x8, [x8, #8]
    //     0xb6d254: add             w2, w7, #2
    //     0xb6d258: sbfx            x7, x2, #1, #0x1f
    //     0xb6d25c: mov             x2, x7
    //     0xb6d260: mov             x7, x8
    //     0xb6d264: b               #0xb6d26c
    //     0xb6d268: mov             x7, NULL
    //     0xb6d26c: lsl             x8, x2, #1
    //     0xb6d270: lsl             w2, w8, #1
    //     0xb6d274: add             w8, w2, #8
    //     0xb6d278: add             x16, x0, w8, sxtw #1
    //     0xb6d27c: ldur            w9, [x16, #0xf]
    //     0xb6d280: add             x9, x9, HEAP, lsl #32
    //     0xb6d284: add             x16, PP, #0x27, lsl #12  ; [pp+0x27db8] "weight"
    //     0xb6d288: ldr             x16, [x16, #0xdb8]
    //     0xb6d28c: cmp             w9, w16
    //     0xb6d290: b.ne            #0xb6d2b8
    //     0xb6d294: add             w8, w2, #0xa
    //     0xb6d298: add             x16, x0, w8, sxtw #1
    //     0xb6d29c: ldur            w2, [x16, #0xf]
    //     0xb6d2a0: add             x2, x2, HEAP, lsl #32
    //     0xb6d2a4: sub             w0, w1, w2
    //     0xb6d2a8: add             x1, fp, w0, sxtw #2
    //     0xb6d2ac: ldr             x1, [x1, #8]
    //     0xb6d2b0: mov             x8, x1
    //     0xb6d2b4: b               #0xb6d2bc
    //     0xb6d2b8: mov             x8, NULL
    //     0xb6d2bc: stur            x8, [fp, #-0x10]
    // 0xb6d2c0: r0 = LoadTaggedClassIdMayBeSmiInstr(r7)
    //     0xb6d2c0: mov             x0, #0x76
    //     0xb6d2c4: tbz             w7, #0, #0xb6d2d4
    //     0xb6d2c8: ldur            x0, [x7, #-1]
    //     0xb6d2cc: ubfx            x0, x0, #0xc, #0x14
    //     0xb6d2d0: lsl             x0, x0, #1
    // 0xb6d2d4: r17 = 9450
    //     0xb6d2d4: mov             x17, #0x24ea
    // 0xb6d2d8: cmp             w0, w17
    // 0xb6d2dc: b.ne            #0xb6d2ec
    // 0xb6d2e0: LoadField: r0 = r7->field_b
    //     0xb6d2e0: ldur            w0, [x7, #0xb]
    // 0xb6d2e4: DecompressPointer r0
    //     0xb6d2e4: add             x0, x0, HEAP, lsl #32
    // 0xb6d2e8: mov             x7, x0
    // 0xb6d2ec: mov             x0, x7
    // 0xb6d2f0: stur            x7, [fp, #-8]
    // 0xb6d2f4: r2 = Null
    //     0xb6d2f4: mov             x2, NULL
    // 0xb6d2f8: r1 = Null
    //     0xb6d2f8: mov             x1, NULL
    // 0xb6d2fc: branchIfSmi(r0, 0xb6d328)
    //     0xb6d2fc: tbz             w0, #0, #0xb6d328
    // 0xb6d300: r4 = LoadClassIdInstr(r0)
    //     0xb6d300: ldur            x4, [x0, #-1]
    //     0xb6d304: ubfx            x4, x4, #0xc, #0x14
    // 0xb6d308: sub             x4, x4, #0x3b
    // 0xb6d30c: cmp             x4, #2
    // 0xb6d310: b.ls            #0xb6d328
    // 0xb6d314: r8 = num?
    //     0xb6d314: add             x8, PP, #0xa, lsl #12  ; [pp+0xa468] Type: num?
    //     0xb6d318: ldr             x8, [x8, #0x468]
    // 0xb6d31c: r3 = Null
    //     0xb6d31c: add             x3, PP, #0x3c, lsl #12  ; [pp+0x3cf58] Null
    //     0xb6d320: ldr             x3, [x3, #0xf58]
    // 0xb6d324: r0 = DefaultNullableTypeTest()
    //     0xb6d324: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xb6d328: r0 = Font()
    //     0xb6d328: bl              #0xb6d3a4  ; AllocateFontStub -> Font (size=0x20)
    // 0xb6d32c: ldur            x1, [fp, #-8]
    // 0xb6d330: StoreField: r0->field_7 = r1
    //     0xb6d330: stur            w1, [x0, #7]
    // 0xb6d334: ldur            x1, [fp, #-0x20]
    // 0xb6d338: StoreField: r0->field_b = r1
    //     0xb6d338: stur            w1, [x0, #0xb]
    // 0xb6d33c: ldur            x1, [fp, #-0x10]
    // 0xb6d340: StoreField: r0->field_f = r1
    //     0xb6d340: stur            w1, [x0, #0xf]
    // 0xb6d344: ldur            x1, [fp, #-0x18]
    // 0xb6d348: StoreField: r0->field_1b = r1
    //     0xb6d348: stur            w1, [x0, #0x1b]
    // 0xb6d34c: ldur            x1, [fp, #-0x30]
    // 0xb6d350: StoreField: r1->field_13 = r0
    //     0xb6d350: stur            w0, [x1, #0x13]
    //     0xb6d354: ldurb           w16, [x1, #-1]
    //     0xb6d358: ldurb           w17, [x0, #-1]
    //     0xb6d35c: and             x16, x17, x16, lsr #2
    //     0xb6d360: tst             x16, HEAP, lsr #32
    //     0xb6d364: b.eq            #0xb6d36c
    //     0xb6d368: bl              #0xd6826c
    // 0xb6d36c: r2 = 1
    //     0xb6d36c: mov             x2, #1
    // 0xb6d370: StoreField: r1->field_b = r2
    //     0xb6d370: stur            x2, [x1, #0xb]
    // 0xb6d374: ldur            x0, [fp, #-0x28]
    // 0xb6d378: StoreField: r1->field_7 = r0
    //     0xb6d378: stur            w0, [x1, #7]
    //     0xb6d37c: ldurb           w16, [x1, #-1]
    //     0xb6d380: ldurb           w17, [x0, #-1]
    //     0xb6d384: and             x16, x17, x16, lsr #2
    //     0xb6d388: tst             x16, HEAP, lsr #32
    //     0xb6d38c: b.eq            #0xb6d394
    //     0xb6d390: bl              #0xd6826c
    // 0xb6d394: r0 = Null
    //     0xb6d394: mov             x0, NULL
    // 0xb6d398: LeaveFrame
    //     0xb6d398: mov             SP, fp
    //     0xb6d39c: ldp             fp, lr, [SP], #0x10
    // 0xb6d3a0: ret
    //     0xb6d3a0: ret             
  }
  _ FontExpression._merge(/* No info */) {
    // ** addr: 0xb6d5c0, size: 0x98
    // 0xb6d5c0: EnterFrame
    //     0xb6d5c0: stp             fp, lr, [SP, #-0x10]!
    //     0xb6d5c4: mov             fp, SP
    // 0xb6d5c8: CheckStackOverflow
    //     0xb6d5c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb6d5cc: cmp             SP, x16
    //     0xb6d5d0: b.ls            #0xb6d650
    // 0xb6d5d4: ldr             x0, [fp, #0x20]
    // 0xb6d5d8: LoadField: r1 = r0->field_13
    //     0xb6d5d8: ldur            w1, [x0, #0x13]
    // 0xb6d5dc: DecompressPointer r1
    //     0xb6d5dc: add             x1, x1, HEAP, lsl #32
    // 0xb6d5e0: ldr             x0, [fp, #0x18]
    // 0xb6d5e4: LoadField: r2 = r0->field_13
    //     0xb6d5e4: ldur            w2, [x0, #0x13]
    // 0xb6d5e8: DecompressPointer r2
    //     0xb6d5e8: add             x2, x2, HEAP, lsl #32
    // 0xb6d5ec: stp             x2, x1, [SP, #-0x10]!
    // 0xb6d5f0: r0 = merge()
    //     0xb6d5f0: bl              #0xb6d658  ; [package:csslib/parser.dart] Font::merge
    // 0xb6d5f4: add             SP, SP, #0x10
    // 0xb6d5f8: ldr             x1, [fp, #0x28]
    // 0xb6d5fc: StoreField: r1->field_13 = r0
    //     0xb6d5fc: stur            w0, [x1, #0x13]
    //     0xb6d600: ldurb           w16, [x1, #-1]
    //     0xb6d604: ldurb           w17, [x0, #-1]
    //     0xb6d608: and             x16, x17, x16, lsr #2
    //     0xb6d60c: tst             x16, HEAP, lsr #32
    //     0xb6d610: b.eq            #0xb6d618
    //     0xb6d614: bl              #0xd6826c
    // 0xb6d618: r2 = 1
    //     0xb6d618: mov             x2, #1
    // 0xb6d61c: StoreField: r1->field_b = r2
    //     0xb6d61c: stur            x2, [x1, #0xb]
    // 0xb6d620: ldr             x0, [fp, #0x10]
    // 0xb6d624: StoreField: r1->field_7 = r0
    //     0xb6d624: stur            w0, [x1, #7]
    //     0xb6d628: ldurb           w16, [x1, #-1]
    //     0xb6d62c: ldurb           w17, [x0, #-1]
    //     0xb6d630: and             x16, x17, x16, lsr #2
    //     0xb6d634: tst             x16, HEAP, lsr #32
    //     0xb6d638: b.eq            #0xb6d640
    //     0xb6d63c: bl              #0xd6826c
    // 0xb6d640: r0 = Null
    //     0xb6d640: mov             x0, NULL
    // 0xb6d644: LeaveFrame
    //     0xb6d644: mov             SP, fp
    //     0xb6d648: ldp             fp, lr, [SP], #0x10
    // 0xb6d64c: ret
    //     0xb6d64c: ret             
    // 0xb6d650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6d650: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6d654: b               #0xb6d5d4
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfc688, size: 0x38
    // 0xbfc688: EnterFrame
    //     0xbfc688: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc68c: mov             fp, SP
    // 0xbfc690: CheckStackOverflow
    //     0xbfc690: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc694: cmp             SP, x16
    //     0xbfc698: b.ls            #0xbfc6b8
    // 0xbfc69c: ldr             x16, [fp, #0x10]
    // 0xbfc6a0: SaveReg r16
    //     0xbfc6a0: str             x16, [SP, #-8]!
    // 0xbfc6a4: r0 = createSession()
    //     0xbfc6a4: bl              #0xcceeb4  ; [package:flutter/src/services/mouse_cursor.dart] _DeferringMouseCursor::createSession
    // 0xbfc6a8: add             SP, SP, #8
    // 0xbfc6ac: LeaveFrame
    //     0xbfc6ac: mov             SP, fp
    //     0xbfc6b0: ldp             fp, lr, [SP], #0x10
    // 0xbfc6b4: ret
    //     0xbfc6b4: ret             
    // 0xbfc6b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc6b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc6bc: b               #0xbfc69c
  }
}

// class id: 4648, size: 0x10, field offset: 0xc
class DeclarationGroup extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xbfc648, size: 0x40
    // 0xbfc648: EnterFrame
    //     0xbfc648: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc64c: mov             fp, SP
    // 0xbfc650: CheckStackOverflow
    //     0xbfc650: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc654: cmp             SP, x16
    //     0xbfc658: b.ls            #0xbfc680
    // 0xbfc65c: ldr             x16, [fp, #0x10]
    // 0xbfc660: ldr             lr, [fp, #0x18]
    // 0xbfc664: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc668: r0 = visitStyleSheet()
    //     0xbfc668: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfc66c: add             SP, SP, #0x10
    // 0xbfc670: r0 = Null
    //     0xbfc670: mov             x0, NULL
    // 0xbfc674: LeaveFrame
    //     0xbfc674: mov             SP, fp
    //     0xbfc678: ldp             fp, lr, [SP], #0x10
    // 0xbfc67c: ret
    //     0xbfc67c: ret             
    // 0xbfc680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc680: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc684: b               #0xbfc65c
  }
}

// class id: 4649, size: 0x10, field offset: 0x10
class MarginGroup extends DeclarationGroup {
}

// class id: 4650, size: 0x1c, field offset: 0xc
class Declaration extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xbfc49c, size: 0x40
    // 0xbfc49c: EnterFrame
    //     0xbfc49c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc4a0: mov             fp, SP
    // 0xbfc4a4: CheckStackOverflow
    //     0xbfc4a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc4a8: cmp             SP, x16
    //     0xbfc4ac: b.ls            #0xbfc4d4
    // 0xbfc4b0: ldr             x16, [fp, #0x10]
    // 0xbfc4b4: ldr             lr, [fp, #0x18]
    // 0xbfc4b8: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc4bc: r0 = visitDeclaration()
    //     0xbfc4bc: bl              #0xbfc4dc  ; [package:flutter_html/src/css_parser.dart] DeclarationVisitor::visitDeclaration
    // 0xbfc4c0: add             SP, SP, #0x10
    // 0xbfc4c4: r0 = Null
    //     0xbfc4c4: mov             x0, NULL
    // 0xbfc4c8: LeaveFrame
    //     0xbfc4c8: mov             SP, fp
    //     0xbfc4cc: ldp             fp, lr, [SP], #0x10
    // 0xbfc4d0: ret
    //     0xbfc4d0: ret             
    // 0xbfc4d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc4d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc4d8: b               #0xbfc4b0
  }
  get _ property(/* No info */) {
    // ** addr: 0xbfc5a4, size: 0xa4
    // 0xbfc5a4: EnterFrame
    //     0xbfc5a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc5a8: mov             fp, SP
    // 0xbfc5ac: CheckStackOverflow
    //     0xbfc5ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc5b0: cmp             SP, x16
    //     0xbfc5b4: b.ls            #0xbfc638
    // 0xbfc5b8: ldr             x0, [fp, #0x10]
    // 0xbfc5bc: LoadField: r1 = r0->field_17
    //     0xbfc5bc: ldur            w1, [x0, #0x17]
    // 0xbfc5c0: DecompressPointer r1
    //     0xbfc5c0: add             x1, x1, HEAP, lsl #32
    // 0xbfc5c4: tbnz            w1, #4, #0xbfc60c
    // 0xbfc5c8: r1 = Null
    //     0xbfc5c8: mov             x1, NULL
    // 0xbfc5cc: r2 = 4
    //     0xbfc5cc: mov             x2, #4
    // 0xbfc5d0: r0 = AllocateArray()
    //     0xbfc5d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xbfc5d4: r17 = "*"
    //     0xbfc5d4: ldr             x17, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0xbfc5d8: StoreField: r0->field_f = r17
    //     0xbfc5d8: stur            w17, [x0, #0xf]
    // 0xbfc5dc: ldr             x1, [fp, #0x10]
    // 0xbfc5e0: LoadField: r2 = r1->field_b
    //     0xbfc5e0: ldur            w2, [x1, #0xb]
    // 0xbfc5e4: DecompressPointer r2
    //     0xbfc5e4: add             x2, x2, HEAP, lsl #32
    // 0xbfc5e8: cmp             w2, NULL
    // 0xbfc5ec: b.eq            #0xbfc640
    // 0xbfc5f0: LoadField: r1 = r2->field_b
    //     0xbfc5f0: ldur            w1, [x2, #0xb]
    // 0xbfc5f4: DecompressPointer r1
    //     0xbfc5f4: add             x1, x1, HEAP, lsl #32
    // 0xbfc5f8: StoreField: r0->field_13 = r1
    //     0xbfc5f8: stur            w1, [x0, #0x13]
    // 0xbfc5fc: SaveReg r0
    //     0xbfc5fc: str             x0, [SP, #-8]!
    // 0xbfc600: r0 = _interpolate()
    //     0xbfc600: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xbfc604: add             SP, SP, #8
    // 0xbfc608: b               #0xbfc62c
    // 0xbfc60c: mov             x1, x0
    // 0xbfc610: LoadField: r2 = r1->field_b
    //     0xbfc610: ldur            w2, [x1, #0xb]
    // 0xbfc614: DecompressPointer r2
    //     0xbfc614: add             x2, x2, HEAP, lsl #32
    // 0xbfc618: cmp             w2, NULL
    // 0xbfc61c: b.eq            #0xbfc644
    // 0xbfc620: LoadField: r1 = r2->field_b
    //     0xbfc620: ldur            w1, [x2, #0xb]
    // 0xbfc624: DecompressPointer r1
    //     0xbfc624: add             x1, x1, HEAP, lsl #32
    // 0xbfc628: mov             x0, x1
    // 0xbfc62c: LeaveFrame
    //     0xbfc62c: mov             SP, fp
    //     0xbfc630: ldp             fp, lr, [SP], #0x10
    // 0xbfc634: ret
    //     0xbfc634: ret             
    // 0xbfc638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc638: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc63c: b               #0xbfc5b8
    // 0xbfc640: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfc640: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbfc644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfc644: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4651, size: 0x20, field offset: 0x1c
class ExtendDeclaration extends Declaration {

  _ visit(/* No info */) {
    // ** addr: 0xbfc414, size: 0x40
    // 0xbfc414: EnterFrame
    //     0xbfc414: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc418: mov             fp, SP
    // 0xbfc41c: CheckStackOverflow
    //     0xbfc41c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc420: cmp             SP, x16
    //     0xbfc424: b.ls            #0xbfc44c
    // 0xbfc428: ldr             x16, [fp, #0x10]
    // 0xbfc42c: ldr             lr, [fp, #0x18]
    // 0xbfc430: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc434: r0 = visitExtendDeclaration()
    //     0xbfc434: bl              #0xbfc454  ; [package:csslib/visitor.dart] Visitor::visitExtendDeclaration
    // 0xbfc438: add             SP, SP, #0x10
    // 0xbfc43c: r0 = Null
    //     0xbfc43c: mov             x0, NULL
    // 0xbfc440: LeaveFrame
    //     0xbfc440: mov             SP, fp
    //     0xbfc444: ldp             fp, lr, [SP], #0x10
    // 0xbfc448: ret
    //     0xbfc448: ret             
    // 0xbfc44c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc44c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc450: b               #0xbfc428
  }
}

// class id: 4652, size: 0x20, field offset: 0x1c
class IncludeMixinAtDeclaration extends Declaration {

  _ visit(/* No info */) {
    // ** addr: 0xbfc38c, size: 0x40
    // 0xbfc38c: EnterFrame
    //     0xbfc38c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc390: mov             fp, SP
    // 0xbfc394: CheckStackOverflow
    //     0xbfc394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc398: cmp             SP, x16
    //     0xbfc39c: b.ls            #0xbfc3c4
    // 0xbfc3a0: ldr             x16, [fp, #0x10]
    // 0xbfc3a4: ldr             lr, [fp, #0x18]
    // 0xbfc3a8: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc3ac: r0 = visitIncludeMixinAtDeclaration()
    //     0xbfc3ac: bl              #0xbfc3cc  ; [package:csslib/visitor.dart] Visitor::visitIncludeMixinAtDeclaration
    // 0xbfc3b0: add             SP, SP, #0x10
    // 0xbfc3b4: r0 = Null
    //     0xbfc3b4: mov             x0, NULL
    // 0xbfc3b8: LeaveFrame
    //     0xbfc3b8: mov             SP, fp
    //     0xbfc3bc: ldp             fp, lr, [SP], #0x10
    // 0xbfc3c0: ret
    //     0xbfc3c0: ret             
    // 0xbfc3c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc3c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc3c8: b               #0xbfc3a0
  }
}

// class id: 4653, size: 0x1c, field offset: 0x1c
class VarDefinition extends Declaration {

  _ visit(/* No info */) {
    // ** addr: 0xbfc34c, size: 0x40
    // 0xbfc34c: EnterFrame
    //     0xbfc34c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc350: mov             fp, SP
    // 0xbfc354: CheckStackOverflow
    //     0xbfc354: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc358: cmp             SP, x16
    //     0xbfc35c: b.ls            #0xbfc384
    // 0xbfc360: ldr             x16, [fp, #0x10]
    // 0xbfc364: ldr             lr, [fp, #0x18]
    // 0xbfc368: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc36c: r0 = visitVarDefinition()
    //     0xbfc36c: bl              #0xbfbf34  ; [package:csslib/visitor.dart] Visitor::visitVarDefinition
    // 0xbfc370: add             SP, SP, #0x10
    // 0xbfc374: r0 = Null
    //     0xbfc374: mov             x0, NULL
    // 0xbfc378: LeaveFrame
    //     0xbfc378: mov             SP, fp
    //     0xbfc37c: ldp             fp, lr, [SP], #0x10
    // 0xbfc380: ret
    //     0xbfc380: ret             
    // 0xbfc384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc384: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc388: b               #0xbfc360
  }
}

// class id: 4654, size: 0x10, field offset: 0xc
class MediaQuery extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xbfc30c, size: 0x40
    // 0xbfc30c: EnterFrame
    //     0xbfc30c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc310: mov             fp, SP
    // 0xbfc314: CheckStackOverflow
    //     0xbfc314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc318: cmp             SP, x16
    //     0xbfc31c: b.ls            #0xbfc344
    // 0xbfc320: ldr             x16, [fp, #0x10]
    // 0xbfc324: ldr             lr, [fp, #0x18]
    // 0xbfc328: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc32c: r0 = visitMediaQuery()
    //     0xbfc32c: bl              #0xbfb9c4  ; [package:csslib/visitor.dart] Visitor::visitMediaQuery
    // 0xbfc330: add             SP, SP, #0x10
    // 0xbfc334: r0 = Null
    //     0xbfc334: mov             x0, NULL
    // 0xbfc338: LeaveFrame
    //     0xbfc338: mov             SP, fp
    //     0xbfc33c: ldp             fp, lr, [SP], #0x10
    // 0xbfc340: ret
    //     0xbfc340: ret             
    // 0xbfc344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc344: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc348: b               #0xbfc320
  }
}

// class id: 4655, size: 0x10, field offset: 0xc
class MediaExpression extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xbfc2cc, size: 0x40
    // 0xbfc2cc: EnterFrame
    //     0xbfc2cc: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc2d0: mov             fp, SP
    // 0xbfc2d4: CheckStackOverflow
    //     0xbfc2d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc2d8: cmp             SP, x16
    //     0xbfc2dc: b.ls            #0xbfc304
    // 0xbfc2e0: ldr             x16, [fp, #0x10]
    // 0xbfc2e4: ldr             lr, [fp, #0x18]
    // 0xbfc2e8: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc2ec: r0 = visitMediaExpression()
    //     0xbfc2ec: bl              #0xbfb97c  ; [package:csslib/visitor.dart] Visitor::visitMediaExpression
    // 0xbfc2f0: add             SP, SP, #0x10
    // 0xbfc2f4: r0 = Null
    //     0xbfc2f4: mov             x0, NULL
    // 0xbfc2f8: LeaveFrame
    //     0xbfc2f8: mov             SP, fp
    //     0xbfc2fc: ldp             fp, lr, [SP], #0x10
    // 0xbfc300: ret
    //     0xbfc300: ret             
    // 0xbfc304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc304: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc308: b               #0xbfc2e0
  }
}

// class id: 4656, size: 0xc, field offset: 0xc
abstract class SupportsCondition extends TreeNode {
}

// class id: 4657, size: 0x10, field offset: 0xc
class SupportsDisjunction extends SupportsCondition {

  _ visit(/* No info */) {
    // ** addr: 0xbfc28c, size: 0x40
    // 0xbfc28c: EnterFrame
    //     0xbfc28c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc290: mov             fp, SP
    // 0xbfc294: CheckStackOverflow
    //     0xbfc294: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc298: cmp             SP, x16
    //     0xbfc29c: b.ls            #0xbfc2c4
    // 0xbfc2a0: ldr             x16, [fp, #0x10]
    // 0xbfc2a4: ldr             lr, [fp, #0x18]
    // 0xbfc2a8: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc2ac: r0 = visitStyleSheet()
    //     0xbfc2ac: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfc2b0: add             SP, SP, #0x10
    // 0xbfc2b4: r0 = Null
    //     0xbfc2b4: mov             x0, NULL
    // 0xbfc2b8: LeaveFrame
    //     0xbfc2b8: mov             SP, fp
    //     0xbfc2bc: ldp             fp, lr, [SP], #0x10
    // 0xbfc2c0: ret
    //     0xbfc2c0: ret             
    // 0xbfc2c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc2c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc2c8: b               #0xbfc2a0
  }
}

// class id: 4658, size: 0x10, field offset: 0xc
class SupportsConjunction extends SupportsCondition {

  _ visit(/* No info */) {
    // ** addr: 0xbfc24c, size: 0x40
    // 0xbfc24c: EnterFrame
    //     0xbfc24c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc250: mov             fp, SP
    // 0xbfc254: CheckStackOverflow
    //     0xbfc254: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc258: cmp             SP, x16
    //     0xbfc25c: b.ls            #0xbfc284
    // 0xbfc260: ldr             x16, [fp, #0x10]
    // 0xbfc264: ldr             lr, [fp, #0x18]
    // 0xbfc268: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc26c: r0 = visitStyleSheet()
    //     0xbfc26c: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfc270: add             SP, SP, #0x10
    // 0xbfc274: r0 = Null
    //     0xbfc274: mov             x0, NULL
    // 0xbfc278: LeaveFrame
    //     0xbfc278: mov             SP, fp
    //     0xbfc27c: ldp             fp, lr, [SP], #0x10
    // 0xbfc280: ret
    //     0xbfc280: ret             
    // 0xbfc284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc284: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc288: b               #0xbfc260
  }
}

// class id: 4659, size: 0x10, field offset: 0xc
class SupportsNegation extends SupportsCondition {

  _ visit(/* No info */) {
    // ** addr: 0xbfc20c, size: 0x40
    // 0xbfc20c: EnterFrame
    //     0xbfc20c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc210: mov             fp, SP
    // 0xbfc214: CheckStackOverflow
    //     0xbfc214: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc218: cmp             SP, x16
    //     0xbfc21c: b.ls            #0xbfc244
    // 0xbfc220: ldr             x16, [fp, #0x10]
    // 0xbfc224: ldr             lr, [fp, #0x18]
    // 0xbfc228: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc22c: r0 = visitSupportsNegation()
    //     0xbfc22c: bl              #0xbfb5a0  ; [package:csslib/visitor.dart] Visitor::visitSupportsNegation
    // 0xbfc230: add             SP, SP, #0x10
    // 0xbfc234: r0 = Null
    //     0xbfc234: mov             x0, NULL
    // 0xbfc238: LeaveFrame
    //     0xbfc238: mov             SP, fp
    //     0xbfc23c: ldp             fp, lr, [SP], #0x10
    // 0xbfc240: ret
    //     0xbfc240: ret             
    // 0xbfc244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc244: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc248: b               #0xbfc220
  }
}

// class id: 4660, size: 0x10, field offset: 0xc
class SupportsConditionInParens extends SupportsCondition {

  _ visit(/* No info */) {
    // ** addr: 0xbfc1cc, size: 0x40
    // 0xbfc1cc: EnterFrame
    //     0xbfc1cc: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc1d0: mov             fp, SP
    // 0xbfc1d4: CheckStackOverflow
    //     0xbfc1d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc1d8: cmp             SP, x16
    //     0xbfc1dc: b.ls            #0xbfc204
    // 0xbfc1e0: ldr             x16, [fp, #0x10]
    // 0xbfc1e4: ldr             lr, [fp, #0x18]
    // 0xbfc1e8: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc1ec: r0 = visitSupportsConditionInParens()
    //     0xbfc1ec: bl              #0xbfb53c  ; [package:csslib/visitor.dart] Visitor::visitSupportsConditionInParens
    // 0xbfc1f0: add             SP, SP, #0x10
    // 0xbfc1f4: r0 = Null
    //     0xbfc1f4: mov             x0, NULL
    // 0xbfc1f8: LeaveFrame
    //     0xbfc1f8: mov             SP, fp
    //     0xbfc1fc: ldp             fp, lr, [SP], #0x10
    // 0xbfc200: ret
    //     0xbfc200: ret             
    // 0xbfc204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc204: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc208: b               #0xbfc1e0
  }
}

// class id: 4661, size: 0xc, field offset: 0xc
abstract class Directive extends TreeNode {
}

// class id: 4662, size: 0x10, field offset: 0xc
class IncludeDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfc018, size: 0x40
    // 0xbfc018: EnterFrame
    //     0xbfc018: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc01c: mov             fp, SP
    // 0xbfc020: CheckStackOverflow
    //     0xbfc020: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc024: cmp             SP, x16
    //     0xbfc028: b.ls            #0xbfc050
    // 0xbfc02c: ldr             x16, [fp, #0x10]
    // 0xbfc030: ldr             lr, [fp, #0x18]
    // 0xbfc034: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc038: r0 = visitIncludeDirective()
    //     0xbfc038: bl              #0xbfc058  ; [package:csslib/visitor.dart] Visitor::visitIncludeDirective
    // 0xbfc03c: add             SP, SP, #0x10
    // 0xbfc040: r0 = Null
    //     0xbfc040: mov             x0, NULL
    // 0xbfc044: LeaveFrame
    //     0xbfc044: mov             SP, fp
    //     0xbfc048: ldp             fp, lr, [SP], #0x10
    // 0xbfc04c: ret
    //     0xbfc04c: ret             
    // 0xbfc050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc050: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc054: b               #0xbfc02c
  }
}

// class id: 4663, size: 0xc, field offset: 0xc
abstract class MixinDefinition extends Directive {
}

// class id: 4664, size: 0x10, field offset: 0xc
class MixinDeclarationDirective extends MixinDefinition {

  _ visit(/* No info */) {
    // ** addr: 0xbfbfd8, size: 0x40
    // 0xbfbfd8: EnterFrame
    //     0xbfbfd8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbfdc: mov             fp, SP
    // 0xbfbfe0: CheckStackOverflow
    //     0xbfbfe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbfe4: cmp             SP, x16
    //     0xbfbfe8: b.ls            #0xbfc010
    // 0xbfbfec: ldr             x16, [fp, #0x10]
    // 0xbfbff0: ldr             lr, [fp, #0x18]
    // 0xbfbff4: stp             lr, x16, [SP, #-0x10]!
    // 0xbfbff8: r0 = visitViewportDirective()
    //     0xbfbff8: bl              #0xbfb628  ; [package:csslib/visitor.dart] Visitor::visitViewportDirective
    // 0xbfbffc: add             SP, SP, #0x10
    // 0xbfc000: r0 = Null
    //     0xbfc000: mov             x0, NULL
    // 0xbfc004: LeaveFrame
    //     0xbfc004: mov             SP, fp
    //     0xbfc008: ldp             fp, lr, [SP], #0x10
    // 0xbfc00c: ret
    //     0xbfc00c: ret             
    // 0xbfc010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc010: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc014: b               #0xbfbfec
  }
}

// class id: 4665, size: 0x10, field offset: 0xc
class MixinRulesetDirective extends MixinDefinition {

  _ visit(/* No info */) {
    // ** addr: 0xbfbf98, size: 0x40
    // 0xbfbf98: EnterFrame
    //     0xbfbf98: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbf9c: mov             fp, SP
    // 0xbfbfa0: CheckStackOverflow
    //     0xbfbfa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbfa4: cmp             SP, x16
    //     0xbfbfa8: b.ls            #0xbfbfd0
    // 0xbfbfac: ldr             x16, [fp, #0x10]
    // 0xbfbfb0: ldr             lr, [fp, #0x18]
    // 0xbfbfb4: stp             lr, x16, [SP, #-0x10]!
    // 0xbfbfb8: r0 = visitStyleSheet()
    //     0xbfbfb8: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfbfbc: add             SP, SP, #0x10
    // 0xbfbfc0: r0 = Null
    //     0xbfbfc0: mov             x0, NULL
    // 0xbfbfc4: LeaveFrame
    //     0xbfbfc4: mov             SP, fp
    //     0xbfbfc8: ldp             fp, lr, [SP], #0x10
    // 0xbfbfcc: ret
    //     0xbfbfcc: ret             
    // 0xbfbfd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbfd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbfd4: b               #0xbfbfac
  }
}

// class id: 4666, size: 0x10, field offset: 0xc
class VarDefinitionDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfbeac, size: 0x40
    // 0xbfbeac: EnterFrame
    //     0xbfbeac: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbeb0: mov             fp, SP
    // 0xbfbeb4: CheckStackOverflow
    //     0xbfbeb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbeb8: cmp             SP, x16
    //     0xbfbebc: b.ls            #0xbfbee4
    // 0xbfbec0: ldr             x16, [fp, #0x10]
    // 0xbfbec4: ldr             lr, [fp, #0x18]
    // 0xbfbec8: stp             lr, x16, [SP, #-0x10]!
    // 0xbfbecc: r0 = visitVarDefinitionDirective()
    //     0xbfbecc: bl              #0xbfbeec  ; [package:csslib/visitor.dart] Visitor::visitVarDefinitionDirective
    // 0xbfbed0: add             SP, SP, #0x10
    // 0xbfbed4: r0 = Null
    //     0xbfbed4: mov             x0, NULL
    // 0xbfbed8: LeaveFrame
    //     0xbfbed8: mov             SP, fp
    //     0xbfbedc: ldp             fp, lr, [SP], #0x10
    // 0xbfbee0: ret
    //     0xbfbee0: ret             
    // 0xbfbee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbee4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbee8: b               #0xbfbec0
  }
}

// class id: 4667, size: 0xc, field offset: 0xc
class NamespaceDirective extends Directive {
}

// class id: 4669, size: 0x10, field offset: 0xc
class FontFaceDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfbe6c, size: 0x40
    // 0xbfbe6c: EnterFrame
    //     0xbfbe6c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbe70: mov             fp, SP
    // 0xbfbe74: CheckStackOverflow
    //     0xbfbe74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbe78: cmp             SP, x16
    //     0xbfbe7c: b.ls            #0xbfbea4
    // 0xbfbe80: ldr             x16, [fp, #0x10]
    // 0xbfbe84: ldr             lr, [fp, #0x18]
    // 0xbfbe88: stp             lr, x16, [SP, #-0x10]!
    // 0xbfbe8c: r0 = visitViewportDirective()
    //     0xbfbe8c: bl              #0xbfb628  ; [package:csslib/visitor.dart] Visitor::visitViewportDirective
    // 0xbfbe90: add             SP, SP, #0x10
    // 0xbfbe94: r0 = Null
    //     0xbfbe94: mov             x0, NULL
    // 0xbfbe98: LeaveFrame
    //     0xbfbe98: mov             SP, fp
    //     0xbfbe9c: ldp             fp, lr, [SP], #0x10
    // 0xbfbea0: ret
    //     0xbfbea0: ret             
    // 0xbfbea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbea4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbea8: b               #0xbfbe80
  }
}

// class id: 4670, size: 0x14, field offset: 0xc
class KeyFrameDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfbdd0, size: 0x40
    // 0xbfbdd0: EnterFrame
    //     0xbfbdd0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbdd4: mov             fp, SP
    // 0xbfbdd8: CheckStackOverflow
    //     0xbfbdd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbddc: cmp             SP, x16
    //     0xbfbde0: b.ls            #0xbfbe08
    // 0xbfbde4: ldr             x16, [fp, #0x10]
    // 0xbfbde8: ldr             lr, [fp, #0x18]
    // 0xbfbdec: stp             lr, x16, [SP, #-0x10]!
    // 0xbfbdf0: r0 = visitKeyFrameDirective()
    //     0xbfbdf0: bl              #0xbfbe10  ; [package:csslib/visitor.dart] Visitor::visitKeyFrameDirective
    // 0xbfbdf4: add             SP, SP, #0x10
    // 0xbfbdf8: r0 = Null
    //     0xbfbdf8: mov             x0, NULL
    // 0xbfbdfc: LeaveFrame
    //     0xbfbdfc: mov             SP, fp
    //     0xbfbe00: ldp             fp, lr, [SP], #0x10
    // 0xbfbe04: ret
    //     0xbfbe04: ret             
    // 0xbfbe08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbe08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbe0c: b               #0xbfbde4
  }
}

// class id: 4671, size: 0xc, field offset: 0xc
class CharsetDirective extends Directive {
}

// class id: 4672, size: 0x10, field offset: 0xc
class PageDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfbbd0, size: 0x40
    // 0xbfbbd0: EnterFrame
    //     0xbfbbd0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbbd4: mov             fp, SP
    // 0xbfbbd8: CheckStackOverflow
    //     0xbfbbd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbbdc: cmp             SP, x16
    //     0xbfbbe0: b.ls            #0xbfbc08
    // 0xbfbbe4: ldr             x16, [fp, #0x10]
    // 0xbfbbe8: ldr             lr, [fp, #0x18]
    // 0xbfbbec: stp             lr, x16, [SP, #-0x10]!
    // 0xbfbbf0: r0 = visitPageDirective()
    //     0xbfbbf0: bl              #0xbfbc10  ; [package:csslib/visitor.dart] Visitor::visitPageDirective
    // 0xbfbbf4: add             SP, SP, #0x10
    // 0xbfbbf8: r0 = Null
    //     0xbfbbf8: mov             x0, NULL
    // 0xbfbbfc: LeaveFrame
    //     0xbfbbfc: mov             SP, fp
    //     0xbfbc00: ldp             fp, lr, [SP], #0x10
    // 0xbfbc04: ret
    //     0xbfbc04: ret             
    // 0xbfbc08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbc08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbc0c: b               #0xbfbbe4
  }
}

// class id: 4673, size: 0x10, field offset: 0xc
class HostDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfbb90, size: 0x40
    // 0xbfbb90: EnterFrame
    //     0xbfbb90: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbb94: mov             fp, SP
    // 0xbfbb98: CheckStackOverflow
    //     0xbfbb98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbb9c: cmp             SP, x16
    //     0xbfbba0: b.ls            #0xbfbbc8
    // 0xbfbba4: ldr             x16, [fp, #0x10]
    // 0xbfbba8: ldr             lr, [fp, #0x18]
    // 0xbfbbac: stp             lr, x16, [SP, #-0x10]!
    // 0xbfbbb0: r0 = visitStyleSheet()
    //     0xbfbbb0: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfbbb4: add             SP, SP, #0x10
    // 0xbfbbb8: r0 = Null
    //     0xbfbbb8: mov             x0, NULL
    // 0xbfbbbc: LeaveFrame
    //     0xbfbbbc: mov             SP, fp
    //     0xbfbbc0: ldp             fp, lr, [SP], #0x10
    // 0xbfbbc4: ret
    //     0xbfbbc4: ret             
    // 0xbfbbc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbbc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbbcc: b               #0xbfbba4
  }
}

// class id: 4674, size: 0x14, field offset: 0xc
class MediaDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfbb50, size: 0x40
    // 0xbfbb50: EnterFrame
    //     0xbfbb50: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbb54: mov             fp, SP
    // 0xbfbb58: CheckStackOverflow
    //     0xbfbb58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbb5c: cmp             SP, x16
    //     0xbfbb60: b.ls            #0xbfbb88
    // 0xbfbb64: ldr             x16, [fp, #0x10]
    // 0xbfbb68: ldr             lr, [fp, #0x18]
    // 0xbfbb6c: stp             lr, x16, [SP, #-0x10]!
    // 0xbfbb70: r0 = visitDocumentDirective()
    //     0xbfbb70: bl              #0xbfb3bc  ; [package:csslib/visitor.dart] Visitor::visitDocumentDirective
    // 0xbfbb74: add             SP, SP, #0x10
    // 0xbfbb78: r0 = Null
    //     0xbfbb78: mov             x0, NULL
    // 0xbfbb7c: LeaveFrame
    //     0xbfbb7c: mov             SP, fp
    //     0xbfbb80: ldp             fp, lr, [SP], #0x10
    // 0xbfbb84: ret
    //     0xbfbb84: ret             
    // 0xbfbb88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbb88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbb8c: b               #0xbfbb64
  }
}

// class id: 4675, size: 0x10, field offset: 0xc
class ImportDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfb670, size: 0x40
    // 0xbfb670: EnterFrame
    //     0xbfb670: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb674: mov             fp, SP
    // 0xbfb678: CheckStackOverflow
    //     0xbfb678: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb67c: cmp             SP, x16
    //     0xbfb680: b.ls            #0xbfb6a8
    // 0xbfb684: ldr             x16, [fp, #0x10]
    // 0xbfb688: ldr             lr, [fp, #0x18]
    // 0xbfb68c: stp             lr, x16, [SP, #-0x10]!
    // 0xbfb690: r0 = visitImportDirective()
    //     0xbfb690: bl              #0xbfb6b0  ; [package:csslib/visitor.dart] Visitor::visitImportDirective
    // 0xbfb694: add             SP, SP, #0x10
    // 0xbfb698: r0 = Null
    //     0xbfb698: mov             x0, NULL
    // 0xbfb69c: LeaveFrame
    //     0xbfb69c: mov             SP, fp
    //     0xbfb6a0: ldp             fp, lr, [SP], #0x10
    // 0xbfb6a4: ret
    //     0xbfb6a4: ret             
    // 0xbfb6a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb6a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb6ac: b               #0xbfb684
  }
}

// class id: 4676, size: 0x10, field offset: 0xc
class ViewportDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfb5e8, size: 0x40
    // 0xbfb5e8: EnterFrame
    //     0xbfb5e8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb5ec: mov             fp, SP
    // 0xbfb5f0: CheckStackOverflow
    //     0xbfb5f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb5f4: cmp             SP, x16
    //     0xbfb5f8: b.ls            #0xbfb620
    // 0xbfb5fc: ldr             x16, [fp, #0x10]
    // 0xbfb600: ldr             lr, [fp, #0x18]
    // 0xbfb604: stp             lr, x16, [SP, #-0x10]!
    // 0xbfb608: r0 = visitViewportDirective()
    //     0xbfb608: bl              #0xbfb628  ; [package:csslib/visitor.dart] Visitor::visitViewportDirective
    // 0xbfb60c: add             SP, SP, #0x10
    // 0xbfb610: r0 = Null
    //     0xbfb610: mov             x0, NULL
    // 0xbfb614: LeaveFrame
    //     0xbfb614: mov             SP, fp
    //     0xbfb618: ldp             fp, lr, [SP], #0x10
    // 0xbfb61c: ret
    //     0xbfb61c: ret             
    // 0xbfb620: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb620: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb624: b               #0xbfb5fc
  }
}

// class id: 4677, size: 0x14, field offset: 0xc
class SupportsDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfb420, size: 0x40
    // 0xbfb420: EnterFrame
    //     0xbfb420: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb424: mov             fp, SP
    // 0xbfb428: CheckStackOverflow
    //     0xbfb428: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb42c: cmp             SP, x16
    //     0xbfb430: b.ls            #0xbfb458
    // 0xbfb434: ldr             x16, [fp, #0x10]
    // 0xbfb438: ldr             lr, [fp, #0x18]
    // 0xbfb43c: stp             lr, x16, [SP, #-0x10]!
    // 0xbfb440: r0 = visitSupportsDirective()
    //     0xbfb440: bl              #0xbfb460  ; [package:csslib/visitor.dart] Visitor::visitSupportsDirective
    // 0xbfb444: add             SP, SP, #0x10
    // 0xbfb448: r0 = Null
    //     0xbfb448: mov             x0, NULL
    // 0xbfb44c: LeaveFrame
    //     0xbfb44c: mov             SP, fp
    //     0xbfb450: ldp             fp, lr, [SP], #0x10
    // 0xbfb454: ret
    //     0xbfb454: ret             
    // 0xbfb458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb458: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb45c: b               #0xbfb434
  }
}

// class id: 4678, size: 0x14, field offset: 0xc
class DocumentDirective extends Directive {

  _ visit(/* No info */) {
    // ** addr: 0xbfb37c, size: 0x40
    // 0xbfb37c: EnterFrame
    //     0xbfb37c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb380: mov             fp, SP
    // 0xbfb384: CheckStackOverflow
    //     0xbfb384: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb388: cmp             SP, x16
    //     0xbfb38c: b.ls            #0xbfb3b4
    // 0xbfb390: ldr             x16, [fp, #0x10]
    // 0xbfb394: ldr             lr, [fp, #0x18]
    // 0xbfb398: stp             lr, x16, [SP, #-0x10]!
    // 0xbfb39c: r0 = visitDocumentDirective()
    //     0xbfb39c: bl              #0xbfb3bc  ; [package:csslib/visitor.dart] Visitor::visitDocumentDirective
    // 0xbfb3a0: add             SP, SP, #0x10
    // 0xbfb3a4: r0 = Null
    //     0xbfb3a4: mov             x0, NULL
    // 0xbfb3a8: LeaveFrame
    //     0xbfb3a8: mov             SP, fp
    //     0xbfb3ac: ldp             fp, lr, [SP], #0x10
    // 0xbfb3b0: ret
    //     0xbfb3b0: ret             
    // 0xbfb3b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb3b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb3b8: b               #0xbfb390
  }
}

// class id: 4679, size: 0xc, field offset: 0xc
abstract class TopLevelProduction extends TreeNode {
}

// class id: 4680, size: 0x14, field offset: 0xc
class RuleSet extends TopLevelProduction {

  _ visit(/* No info */) {
    // ** addr: 0xbfb2d8, size: 0x40
    // 0xbfb2d8: EnterFrame
    //     0xbfb2d8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb2dc: mov             fp, SP
    // 0xbfb2e0: CheckStackOverflow
    //     0xbfb2e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb2e4: cmp             SP, x16
    //     0xbfb2e8: b.ls            #0xbfb310
    // 0xbfb2ec: ldr             x16, [fp, #0x10]
    // 0xbfb2f0: ldr             lr, [fp, #0x18]
    // 0xbfb2f4: stp             lr, x16, [SP, #-0x10]!
    // 0xbfb2f8: r0 = visitRuleSet()
    //     0xbfb2f8: bl              #0xbfb318  ; [package:csslib/visitor.dart] Visitor::visitRuleSet
    // 0xbfb2fc: add             SP, SP, #0x10
    // 0xbfb300: r0 = Null
    //     0xbfb300: mov             x0, NULL
    // 0xbfb304: LeaveFrame
    //     0xbfb304: mov             SP, fp
    //     0xbfb308: ldp             fp, lr, [SP], #0x10
    // 0xbfb30c: ret
    //     0xbfb30c: ret             
    // 0xbfb310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb310: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb314: b               #0xbfb2ec
  }
}

// class id: 4681, size: 0x10, field offset: 0xc
class StyleSheet extends TreeNode {

  _ StyleSheet(/* No info */) {
    // ** addr: 0xb66e30, size: 0x1a4
    // 0xb66e30: EnterFrame
    //     0xb66e30: stp             fp, lr, [SP, #-0x10]!
    //     0xb66e34: mov             fp, SP
    // 0xb66e38: AllocStack(0x20)
    //     0xb66e38: sub             SP, SP, #0x20
    // 0xb66e3c: CheckStackOverflow
    //     0xb66e3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb66e40: cmp             SP, x16
    //     0xb66e44: b.ls            #0xb66fc4
    // 0xb66e48: ldr             x0, [fp, #0x18]
    // 0xb66e4c: ldr             x1, [fp, #0x20]
    // 0xb66e50: StoreField: r1->field_b = r0
    //     0xb66e50: stur            w0, [x1, #0xb]
    //     0xb66e54: ldurb           w16, [x1, #-1]
    //     0xb66e58: ldurb           w17, [x0, #-1]
    //     0xb66e5c: and             x16, x17, x16, lsr #2
    //     0xb66e60: tst             x16, HEAP, lsr #32
    //     0xb66e64: b.eq            #0xb66e6c
    //     0xb66e68: bl              #0xd6826c
    // 0xb66e6c: ldr             x0, [fp, #0x10]
    // 0xb66e70: StoreField: r1->field_7 = r0
    //     0xb66e70: stur            w0, [x1, #7]
    //     0xb66e74: ldurb           w16, [x1, #-1]
    //     0xb66e78: ldurb           w17, [x0, #-1]
    //     0xb66e7c: and             x16, x17, x16, lsr #2
    //     0xb66e80: tst             x16, HEAP, lsr #32
    //     0xb66e84: b.eq            #0xb66e8c
    //     0xb66e88: bl              #0xd6826c
    // 0xb66e8c: ldr             x1, [fp, #0x18]
    // 0xb66e90: LoadField: r2 = r1->field_7
    //     0xb66e90: ldur            w2, [x1, #7]
    // 0xb66e94: DecompressPointer r2
    //     0xb66e94: add             x2, x2, HEAP, lsl #32
    // 0xb66e98: stur            x2, [fp, #-0x18]
    // 0xb66e9c: LoadField: r0 = r1->field_b
    //     0xb66e9c: ldur            w0, [x1, #0xb]
    // 0xb66ea0: DecompressPointer r0
    //     0xb66ea0: add             x0, x0, HEAP, lsl #32
    // 0xb66ea4: r3 = LoadInt32Instr(r0)
    //     0xb66ea4: sbfx            x3, x0, #1, #0x1f
    // 0xb66ea8: stur            x3, [fp, #-0x10]
    // 0xb66eac: r4 = 0
    //     0xb66eac: mov             x4, #0
    // 0xb66eb0: stur            x4, [fp, #-8]
    // 0xb66eb4: CheckStackOverflow
    //     0xb66eb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb66eb8: cmp             SP, x16
    //     0xb66ebc: b.ls            #0xb66fcc
    // 0xb66ec0: r0 = LoadClassIdInstr(r1)
    //     0xb66ec0: ldur            x0, [x1, #-1]
    //     0xb66ec4: ubfx            x0, x0, #0xc, #0x14
    // 0xb66ec8: SaveReg r1
    //     0xb66ec8: str             x1, [SP, #-8]!
    // 0xb66ecc: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xb66ecc: mov             x17, #0xb8ea
    //     0xb66ed0: add             lr, x0, x17
    //     0xb66ed4: ldr             lr, [x21, lr, lsl #3]
    //     0xb66ed8: blr             lr
    // 0xb66edc: add             SP, SP, #8
    // 0xb66ee0: r1 = LoadInt32Instr(r0)
    //     0xb66ee0: sbfx            x1, x0, #1, #0x1f
    //     0xb66ee4: tbz             w0, #0, #0xb66eec
    //     0xb66ee8: ldur            x1, [x0, #7]
    // 0xb66eec: ldur            x2, [fp, #-0x10]
    // 0xb66ef0: cmp             x2, x1
    // 0xb66ef4: b.ne            #0xb66fac
    // 0xb66ef8: ldr             x3, [fp, #0x18]
    // 0xb66efc: ldur            x4, [fp, #-8]
    // 0xb66f00: cmp             x4, x1
    // 0xb66f04: b.lt            #0xb66f18
    // 0xb66f08: r0 = Null
    //     0xb66f08: mov             x0, NULL
    // 0xb66f0c: LeaveFrame
    //     0xb66f0c: mov             SP, fp
    //     0xb66f10: ldp             fp, lr, [SP], #0x10
    // 0xb66f14: ret
    //     0xb66f14: ret             
    // 0xb66f18: r0 = BoxInt64Instr(r4)
    //     0xb66f18: sbfiz           x0, x4, #1, #0x1f
    //     0xb66f1c: cmp             x4, x0, asr #1
    //     0xb66f20: b.eq            #0xb66f2c
    //     0xb66f24: bl              #0xd69bb8
    //     0xb66f28: stur            x4, [x0, #7]
    // 0xb66f2c: r1 = LoadClassIdInstr(r3)
    //     0xb66f2c: ldur            x1, [x3, #-1]
    //     0xb66f30: ubfx            x1, x1, #0xc, #0x14
    // 0xb66f34: stp             x0, x3, [SP, #-0x10]!
    // 0xb66f38: mov             x0, x1
    // 0xb66f3c: r0 = GDT[cid_x0 + 0xd175]()
    //     0xb66f3c: mov             x17, #0xd175
    //     0xb66f40: add             lr, x0, x17
    //     0xb66f44: ldr             lr, [x21, lr, lsl #3]
    //     0xb66f48: blr             lr
    // 0xb66f4c: add             SP, SP, #0x10
    // 0xb66f50: mov             x1, x0
    // 0xb66f54: ldur            x0, [fp, #-8]
    // 0xb66f58: add             x4, x0, #1
    // 0xb66f5c: stur            x4, [fp, #-0x20]
    // 0xb66f60: cmp             w1, NULL
    // 0xb66f64: b.ne            #0xb66f98
    // 0xb66f68: mov             x0, x1
    // 0xb66f6c: ldur            x2, [fp, #-0x18]
    // 0xb66f70: r1 = Null
    //     0xb66f70: mov             x1, NULL
    // 0xb66f74: cmp             w2, NULL
    // 0xb66f78: b.eq            #0xb66f98
    // 0xb66f7c: LoadField: r4 = r2->field_17
    //     0xb66f7c: ldur            w4, [x2, #0x17]
    // 0xb66f80: DecompressPointer r4
    //     0xb66f80: add             x4, x4, HEAP, lsl #32
    // 0xb66f84: r8 = X0
    //     0xb66f84: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xb66f88: LoadField: r9 = r4->field_7
    //     0xb66f88: ldur            x9, [x4, #7]
    // 0xb66f8c: r3 = Null
    //     0xb66f8c: add             x3, PP, #0x3c, lsl #12  ; [pp+0x3cba0] Null
    //     0xb66f90: ldr             x3, [x3, #0xba0]
    // 0xb66f94: blr             x9
    // 0xb66f98: ldur            x4, [fp, #-0x20]
    // 0xb66f9c: ldr             x1, [fp, #0x18]
    // 0xb66fa0: ldur            x2, [fp, #-0x18]
    // 0xb66fa4: ldur            x3, [fp, #-0x10]
    // 0xb66fa8: b               #0xb66eb0
    // 0xb66fac: ldr             x0, [fp, #0x18]
    // 0xb66fb0: r0 = ConcurrentModificationError()
    //     0xb66fb0: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xb66fb4: ldr             x3, [fp, #0x18]
    // 0xb66fb8: StoreField: r0->field_b = r3
    //     0xb66fb8: stur            w3, [x0, #0xb]
    // 0xb66fbc: r0 = Throw()
    //     0xb66fbc: bl              #0xd67e38  ; ThrowStub
    // 0xb66fc0: brk             #0
    // 0xb66fc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb66fc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb66fc8: b               #0xb66e48
    // 0xb66fcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb66fcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb66fd0: b               #0xb66ec0
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfb298, size: 0x40
    // 0xbfb298: EnterFrame
    //     0xbfb298: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb29c: mov             fp, SP
    // 0xbfb2a0: CheckStackOverflow
    //     0xbfb2a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb2a4: cmp             SP, x16
    //     0xbfb2a8: b.ls            #0xbfb2d0
    // 0xbfb2ac: ldr             x16, [fp, #0x10]
    // 0xbfb2b0: ldr             lr, [fp, #0x18]
    // 0xbfb2b4: stp             lr, x16, [SP, #-0x10]!
    // 0xbfb2b8: r0 = visitStyleSheet()
    //     0xbfb2b8: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfb2bc: add             SP, SP, #0x10
    // 0xbfb2c0: r0 = Null
    //     0xbfb2c0: mov             x0, NULL
    // 0xbfb2c4: LeaveFrame
    //     0xbfb2c4: mov             SP, fp
    //     0xbfb2c8: ldp             fp, lr, [SP], #0x10
    // 0xbfb2cc: ret
    //     0xbfb2cc: ret             
    // 0xbfb2d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb2d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb2d4: b               #0xbfb2ac
  }
}

// class id: 4682, size: 0x10, field offset: 0xc
class SelectorExpression extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xbfb258, size: 0x40
    // 0xbfb258: EnterFrame
    //     0xbfb258: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb25c: mov             fp, SP
    // 0xbfb260: CheckStackOverflow
    //     0xbfb260: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb264: cmp             SP, x16
    //     0xbfb268: b.ls            #0xbfb290
    // 0xbfb26c: ldr             x16, [fp, #0x10]
    // 0xbfb270: ldr             lr, [fp, #0x18]
    // 0xbfb274: stp             lr, x16, [SP, #-0x10]!
    // 0xbfb278: r0 = visitStyleSheet()
    //     0xbfb278: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfb27c: add             SP, SP, #0x10
    // 0xbfb280: r0 = Null
    //     0xbfb280: mov             x0, NULL
    // 0xbfb284: LeaveFrame
    //     0xbfb284: mov             SP, fp
    //     0xbfb288: ldp             fp, lr, [SP], #0x10
    // 0xbfb28c: ret
    //     0xbfb28c: ret             
    // 0xbfb290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb290: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb294: b               #0xbfb26c
  }
}

// class id: 4683, size: 0x10, field offset: 0xc
abstract class SimpleSelector extends TreeNode {

  String name(SimpleSelector) {
    // ** addr: 0x7ddf04, size: 0x6c
    // 0x7ddf04: EnterFrame
    //     0x7ddf04: stp             fp, lr, [SP, #-0x10]!
    //     0x7ddf08: mov             fp, SP
    // 0x7ddf0c: CheckStackOverflow
    //     0x7ddf0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ddf10: cmp             SP, x16
    //     0x7ddf14: b.ls            #0x7ddf50
    // 0x7ddf18: ldr             x0, [fp, #0x10]
    // 0x7ddf1c: LoadField: r1 = r0->field_b
    //     0x7ddf1c: ldur            w1, [x0, #0xb]
    // 0x7ddf20: DecompressPointer r1
    //     0x7ddf20: add             x1, x1, HEAP, lsl #32
    // 0x7ddf24: SaveReg r1
    //     0x7ddf24: str             x1, [SP, #-8]!
    // 0x7ddf28: r4 = 0
    //     0x7ddf28: mov             x4, #0
    // 0x7ddf2c: ldr             x0, [SP]
    // 0x7ddf30: r16 = UnlinkedCall_0x4aeefc
    //     0x7ddf30: add             x16, PP, #0x38, lsl #12  ; [pp+0x38538] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x7ddf34: add             x16, x16, #0x538
    // 0x7ddf38: ldp             x5, lr, [x16]
    // 0x7ddf3c: blr             lr
    // 0x7ddf40: add             SP, SP, #8
    // 0x7ddf44: LeaveFrame
    //     0x7ddf44: mov             SP, fp
    //     0x7ddf48: ldp             fp, lr, [SP], #0x10
    // 0x7ddf4c: ret
    //     0x7ddf4c: ret             
    // 0x7ddf50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ddf50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ddf54: b               #0x7ddf18
  }
}

// class id: 4684, size: 0x14, field offset: 0x10
class NegationSelector extends SimpleSelector {

  _ visit(/* No info */) {
    // ** addr: 0xbfb208, size: 0x50
    // 0xbfb208: EnterFrame
    //     0xbfb208: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb20c: mov             fp, SP
    // 0xbfb210: CheckStackOverflow
    //     0xbfb210: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb214: cmp             SP, x16
    //     0xbfb218: b.ls            #0xbfb250
    // 0xbfb21c: ldr             x0, [fp, #0x10]
    // 0xbfb220: r1 = LoadClassIdInstr(r0)
    //     0xbfb220: ldur            x1, [x0, #-1]
    //     0xbfb224: ubfx            x1, x1, #0xc, #0x14
    // 0xbfb228: ldr             x16, [fp, #0x18]
    // 0xbfb22c: stp             x16, x0, [SP, #-0x10]!
    // 0xbfb230: mov             x0, x1
    // 0xbfb234: r0 = GDT[cid_x0 + -0x6e3]()
    //     0xbfb234: sub             lr, x0, #0x6e3
    //     0xbfb238: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb23c: blr             lr
    // 0xbfb240: add             SP, SP, #0x10
    // 0xbfb244: LeaveFrame
    //     0xbfb244: mov             SP, fp
    //     0xbfb248: ldp             fp, lr, [SP], #0x10
    // 0xbfb24c: ret
    //     0xbfb24c: ret             
    // 0xbfb250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb250: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb254: b               #0xbfb21c
  }
}

// class id: 4685, size: 0x14, field offset: 0x10
class PseudoElementSelector extends SimpleSelector {

  _ toString(/* No info */) {
    // ** addr: 0xacef64, size: 0xb4
    // 0xacef64: EnterFrame
    //     0xacef64: stp             fp, lr, [SP, #-0x10]!
    //     0xacef68: mov             fp, SP
    // 0xacef6c: AllocStack(0x10)
    //     0xacef6c: sub             SP, SP, #0x10
    // 0xacef70: CheckStackOverflow
    //     0xacef70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacef74: cmp             SP, x16
    //     0xacef78: b.ls            #0xacf010
    // 0xacef7c: ldr             x0, [fp, #0x10]
    // 0xacef80: LoadField: r1 = r0->field_f
    //     0xacef80: ldur            w1, [x0, #0xf]
    // 0xacef84: DecompressPointer r1
    //     0xacef84: add             x1, x1, HEAP, lsl #32
    // 0xacef88: tbnz            w1, #4, #0xacef94
    // 0xacef8c: r3 = ":"
    //     0xacef8c: ldr             x3, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0xacef90: b               #0xacef9c
    // 0xacef94: r3 = "::"
    //     0xacef94: add             x3, PP, #0x38, lsl #12  ; [pp+0x38530] "::"
    //     0xacef98: ldr             x3, [x3, #0x530]
    // 0xacef9c: stur            x3, [fp, #-8]
    // 0xacefa0: r1 = Null
    //     0xacefa0: mov             x1, NULL
    // 0xacefa4: r2 = 4
    //     0xacefa4: mov             x2, #4
    // 0xacefa8: r0 = AllocateArray()
    //     0xacefa8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacefac: mov             x1, x0
    // 0xacefb0: ldur            x0, [fp, #-8]
    // 0xacefb4: stur            x1, [fp, #-0x10]
    // 0xacefb8: StoreField: r1->field_f = r0
    //     0xacefb8: stur            w0, [x1, #0xf]
    // 0xacefbc: ldr             x16, [fp, #0x10]
    // 0xacefc0: SaveReg r16
    //     0xacefc0: str             x16, [SP, #-8]!
    // 0xacefc4: r0 = name()
    //     0xacefc4: bl              #0x7ddf04  ; [package:csslib/visitor.dart] SimpleSelector::name
    // 0xacefc8: add             SP, SP, #8
    // 0xacefcc: ldur            x1, [fp, #-0x10]
    // 0xacefd0: ArrayStore: r1[1] = r0  ; List_4
    //     0xacefd0: add             x25, x1, #0x13
    //     0xacefd4: str             w0, [x25]
    //     0xacefd8: tbz             w0, #0, #0xaceff4
    //     0xacefdc: ldurb           w16, [x1, #-1]
    //     0xacefe0: ldurb           w17, [x0, #-1]
    //     0xacefe4: and             x16, x17, x16, lsr #2
    //     0xacefe8: tst             x16, HEAP, lsr #32
    //     0xacefec: b.eq            #0xaceff4
    //     0xaceff0: bl              #0xd67e5c
    // 0xaceff4: ldur            x16, [fp, #-0x10]
    // 0xaceff8: SaveReg r16
    //     0xaceff8: str             x16, [SP, #-8]!
    // 0xaceffc: r0 = _interpolate()
    //     0xaceffc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf000: add             SP, SP, #8
    // 0xacf004: LeaveFrame
    //     0xacf004: mov             SP, fp
    //     0xacf008: ldp             fp, lr, [SP], #0x10
    // 0xacf00c: ret
    //     0xacf00c: ret             
    // 0xacf010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf010: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf014: b               #0xacef7c
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfb1b8, size: 0x50
    // 0xbfb1b8: EnterFrame
    //     0xbfb1b8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb1bc: mov             fp, SP
    // 0xbfb1c0: CheckStackOverflow
    //     0xbfb1c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb1c4: cmp             SP, x16
    //     0xbfb1c8: b.ls            #0xbfb200
    // 0xbfb1cc: ldr             x0, [fp, #0x10]
    // 0xbfb1d0: r1 = LoadClassIdInstr(r0)
    //     0xbfb1d0: ldur            x1, [x0, #-1]
    //     0xbfb1d4: ubfx            x1, x1, #0xc, #0x14
    // 0xbfb1d8: ldr             x16, [fp, #0x18]
    // 0xbfb1dc: stp             x16, x0, [SP, #-0x10]!
    // 0xbfb1e0: mov             x0, x1
    // 0xbfb1e4: r0 = GDT[cid_x0 + -0x732]()
    //     0xbfb1e4: sub             lr, x0, #0x732
    //     0xbfb1e8: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb1ec: blr             lr
    // 0xbfb1f0: add             SP, SP, #0x10
    // 0xbfb1f4: LeaveFrame
    //     0xbfb1f4: mov             SP, fp
    //     0xbfb1f8: ldp             fp, lr, [SP], #0x10
    // 0xbfb1fc: ret
    //     0xbfb1fc: ret             
    // 0xbfb200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb200: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb204: b               #0xbfb1cc
  }
}

// class id: 4686, size: 0x14, field offset: 0x14
class PseudoElementFunctionSelector extends PseudoElementSelector {

  _ visit(/* No info */) {
    // ** addr: 0xbfb168, size: 0x50
    // 0xbfb168: EnterFrame
    //     0xbfb168: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb16c: mov             fp, SP
    // 0xbfb170: CheckStackOverflow
    //     0xbfb170: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb174: cmp             SP, x16
    //     0xbfb178: b.ls            #0xbfb1b0
    // 0xbfb17c: ldr             x0, [fp, #0x10]
    // 0xbfb180: r1 = LoadClassIdInstr(r0)
    //     0xbfb180: ldur            x1, [x0, #-1]
    //     0xbfb184: ubfx            x1, x1, #0xc, #0x14
    // 0xbfb188: ldr             x16, [fp, #0x18]
    // 0xbfb18c: stp             x16, x0, [SP, #-0x10]!
    // 0xbfb190: mov             x0, x1
    // 0xbfb194: r0 = GDT[cid_x0 + -0x6ea]()
    //     0xbfb194: sub             lr, x0, #0x6ea
    //     0xbfb198: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb19c: blr             lr
    // 0xbfb1a0: add             SP, SP, #0x10
    // 0xbfb1a4: LeaveFrame
    //     0xbfb1a4: mov             SP, fp
    //     0xbfb1a8: ldp             fp, lr, [SP], #0x10
    // 0xbfb1ac: ret
    //     0xbfb1ac: ret             
    // 0xbfb1b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb1b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb1b4: b               #0xbfb17c
  }
}

// class id: 4687, size: 0x10, field offset: 0x10
class PseudoClassSelector extends SimpleSelector {

  _ toString(/* No info */) {
    // ** addr: 0xaceebc, size: 0xa8
    // 0xaceebc: EnterFrame
    //     0xaceebc: stp             fp, lr, [SP, #-0x10]!
    //     0xaceec0: mov             fp, SP
    // 0xaceec4: AllocStack(0x8)
    //     0xaceec4: sub             SP, SP, #8
    // 0xaceec8: CheckStackOverflow
    //     0xaceec8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaceecc: cmp             SP, x16
    //     0xaceed0: b.ls            #0xacef5c
    // 0xaceed4: r1 = Null
    //     0xaceed4: mov             x1, NULL
    // 0xaceed8: r2 = 4
    //     0xaceed8: mov             x2, #4
    // 0xaceedc: r0 = AllocateArray()
    //     0xaceedc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xaceee0: stur            x0, [fp, #-8]
    // 0xaceee4: r17 = ":"
    //     0xaceee4: ldr             x17, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0xaceee8: StoreField: r0->field_f = r17
    //     0xaceee8: stur            w17, [x0, #0xf]
    // 0xaceeec: ldr             x1, [fp, #0x10]
    // 0xaceef0: LoadField: r2 = r1->field_b
    //     0xaceef0: ldur            w2, [x1, #0xb]
    // 0xaceef4: DecompressPointer r2
    //     0xaceef4: add             x2, x2, HEAP, lsl #32
    // 0xaceef8: SaveReg r2
    //     0xaceef8: str             x2, [SP, #-8]!
    // 0xaceefc: r4 = 0
    //     0xaceefc: mov             x4, #0
    // 0xacef00: ldr             x0, [SP]
    // 0xacef04: r16 = UnlinkedCall_0x4aeefc
    //     0xacef04: add             x16, PP, #0x38, lsl #12  ; [pp+0x38608] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xacef08: add             x16, x16, #0x608
    // 0xacef0c: ldp             x5, lr, [x16]
    // 0xacef10: blr             lr
    // 0xacef14: add             SP, SP, #8
    // 0xacef18: ldur            x1, [fp, #-8]
    // 0xacef1c: ArrayStore: r1[1] = r0  ; List_4
    //     0xacef1c: add             x25, x1, #0x13
    //     0xacef20: str             w0, [x25]
    //     0xacef24: tbz             w0, #0, #0xacef40
    //     0xacef28: ldurb           w16, [x1, #-1]
    //     0xacef2c: ldurb           w17, [x0, #-1]
    //     0xacef30: and             x16, x17, x16, lsr #2
    //     0xacef34: tst             x16, HEAP, lsr #32
    //     0xacef38: b.eq            #0xacef40
    //     0xacef3c: bl              #0xd67e5c
    // 0xacef40: ldur            x16, [fp, #-8]
    // 0xacef44: SaveReg r16
    //     0xacef44: str             x16, [SP, #-8]!
    // 0xacef48: r0 = _interpolate()
    //     0xacef48: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacef4c: add             SP, SP, #8
    // 0xacef50: LeaveFrame
    //     0xacef50: mov             SP, fp
    //     0xacef54: ldp             fp, lr, [SP], #0x10
    // 0xacef58: ret
    //     0xacef58: ret             
    // 0xacef5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacef5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacef60: b               #0xaceed4
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfb118, size: 0x50
    // 0xbfb118: EnterFrame
    //     0xbfb118: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb11c: mov             fp, SP
    // 0xbfb120: CheckStackOverflow
    //     0xbfb120: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb124: cmp             SP, x16
    //     0xbfb128: b.ls            #0xbfb160
    // 0xbfb12c: ldr             x0, [fp, #0x10]
    // 0xbfb130: r1 = LoadClassIdInstr(r0)
    //     0xbfb130: ldur            x1, [x0, #-1]
    //     0xbfb134: ubfx            x1, x1, #0xc, #0x14
    // 0xbfb138: ldr             x16, [fp, #0x18]
    // 0xbfb13c: stp             x16, x0, [SP, #-0x10]!
    // 0xbfb140: mov             x0, x1
    // 0xbfb144: r0 = GDT[cid_x0 + -0x7b6]()
    //     0xbfb144: sub             lr, x0, #0x7b6
    //     0xbfb148: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb14c: blr             lr
    // 0xbfb150: add             SP, SP, #0x10
    // 0xbfb154: LeaveFrame
    //     0xbfb154: mov             SP, fp
    //     0xbfb158: ldp             fp, lr, [SP], #0x10
    // 0xbfb15c: ret
    //     0xbfb15c: ret             
    // 0xbfb160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb160: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb164: b               #0xbfb12c
  }
}

// class id: 4688, size: 0x14, field offset: 0x10
class PseudoClassFunctionSelector extends PseudoClassSelector {

  _ visit(/* No info */) {
    // ** addr: 0xbfb0c8, size: 0x50
    // 0xbfb0c8: EnterFrame
    //     0xbfb0c8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb0cc: mov             fp, SP
    // 0xbfb0d0: CheckStackOverflow
    //     0xbfb0d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb0d4: cmp             SP, x16
    //     0xbfb0d8: b.ls            #0xbfb110
    // 0xbfb0dc: ldr             x0, [fp, #0x10]
    // 0xbfb0e0: r1 = LoadClassIdInstr(r0)
    //     0xbfb0e0: ldur            x1, [x0, #-1]
    //     0xbfb0e4: ubfx            x1, x1, #0xc, #0x14
    // 0xbfb0e8: ldr             x16, [fp, #0x18]
    // 0xbfb0ec: stp             x16, x0, [SP, #-0x10]!
    // 0xbfb0f0: mov             x0, x1
    // 0xbfb0f4: r0 = GDT[cid_x0 + -0x700]()
    //     0xbfb0f4: sub             lr, x0, #0x700
    //     0xbfb0f8: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb0fc: blr             lr
    // 0xbfb100: add             SP, SP, #0x10
    // 0xbfb104: LeaveFrame
    //     0xbfb104: mov             SP, fp
    //     0xbfb108: ldp             fp, lr, [SP], #0x10
    // 0xbfb10c: ret
    //     0xbfb10c: ret             
    // 0xbfb110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb114: b               #0xbfb0dc
  }
}

// class id: 4689, size: 0x10, field offset: 0x10
class ClassSelector extends SimpleSelector {

  _ toString(/* No info */) {
    // ** addr: 0xacee64, size: 0x58
    // 0xacee64: EnterFrame
    //     0xacee64: stp             fp, lr, [SP, #-0x10]!
    //     0xacee68: mov             fp, SP
    // 0xacee6c: CheckStackOverflow
    //     0xacee6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacee70: cmp             SP, x16
    //     0xacee74: b.ls            #0xaceeb4
    // 0xacee78: r1 = Null
    //     0xacee78: mov             x1, NULL
    // 0xacee7c: r2 = 4
    //     0xacee7c: mov             x2, #4
    // 0xacee80: r0 = AllocateArray()
    //     0xacee80: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacee84: r17 = "."
    //     0xacee84: ldr             x17, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xacee88: StoreField: r0->field_f = r17
    //     0xacee88: stur            w17, [x0, #0xf]
    // 0xacee8c: ldr             x1, [fp, #0x10]
    // 0xacee90: LoadField: r2 = r1->field_b
    //     0xacee90: ldur            w2, [x1, #0xb]
    // 0xacee94: DecompressPointer r2
    //     0xacee94: add             x2, x2, HEAP, lsl #32
    // 0xacee98: StoreField: r0->field_13 = r2
    //     0xacee98: stur            w2, [x0, #0x13]
    // 0xacee9c: SaveReg r0
    //     0xacee9c: str             x0, [SP, #-8]!
    // 0xaceea0: r0 = _interpolate()
    //     0xaceea0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xaceea4: add             SP, SP, #8
    // 0xaceea8: LeaveFrame
    //     0xaceea8: mov             SP, fp
    //     0xaceeac: ldp             fp, lr, [SP], #0x10
    // 0xaceeb0: ret
    //     0xaceeb0: ret             
    // 0xaceeb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaceeb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaceeb8: b               #0xacee78
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfb078, size: 0x50
    // 0xbfb078: EnterFrame
    //     0xbfb078: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb07c: mov             fp, SP
    // 0xbfb080: CheckStackOverflow
    //     0xbfb080: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb084: cmp             SP, x16
    //     0xbfb088: b.ls            #0xbfb0c0
    // 0xbfb08c: ldr             x0, [fp, #0x10]
    // 0xbfb090: r1 = LoadClassIdInstr(r0)
    //     0xbfb090: ldur            x1, [x0, #-1]
    //     0xbfb094: ubfx            x1, x1, #0xc, #0x14
    // 0xbfb098: ldr             x16, [fp, #0x18]
    // 0xbfb09c: stp             x16, x0, [SP, #-0x10]!
    // 0xbfb0a0: mov             x0, x1
    // 0xbfb0a4: r0 = GDT[cid_x0 + -0x7cb]()
    //     0xbfb0a4: sub             lr, x0, #0x7cb
    //     0xbfb0a8: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb0ac: blr             lr
    // 0xbfb0b0: add             SP, SP, #0x10
    // 0xbfb0b4: LeaveFrame
    //     0xbfb0b4: mov             SP, fp
    //     0xbfb0b8: ldp             fp, lr, [SP], #0x10
    // 0xbfb0bc: ret
    //     0xbfb0bc: ret             
    // 0xbfb0c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb0c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb0c4: b               #0xbfb08c
  }
}

// class id: 4690, size: 0x10, field offset: 0x10
class IdSelector extends SimpleSelector {

  _ toString(/* No info */) {
    // ** addr: 0xacee0c, size: 0x58
    // 0xacee0c: EnterFrame
    //     0xacee0c: stp             fp, lr, [SP, #-0x10]!
    //     0xacee10: mov             fp, SP
    // 0xacee14: CheckStackOverflow
    //     0xacee14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacee18: cmp             SP, x16
    //     0xacee1c: b.ls            #0xacee5c
    // 0xacee20: r1 = Null
    //     0xacee20: mov             x1, NULL
    // 0xacee24: r2 = 4
    //     0xacee24: mov             x2, #4
    // 0xacee28: r0 = AllocateArray()
    //     0xacee28: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacee2c: r17 = "#"
    //     0xacee2c: ldr             x17, [PP, #0x11c8]  ; [pp+0x11c8] "#"
    // 0xacee30: StoreField: r0->field_f = r17
    //     0xacee30: stur            w17, [x0, #0xf]
    // 0xacee34: ldr             x1, [fp, #0x10]
    // 0xacee38: LoadField: r2 = r1->field_b
    //     0xacee38: ldur            w2, [x1, #0xb]
    // 0xacee3c: DecompressPointer r2
    //     0xacee3c: add             x2, x2, HEAP, lsl #32
    // 0xacee40: StoreField: r0->field_13 = r2
    //     0xacee40: stur            w2, [x0, #0x13]
    // 0xacee44: SaveReg r0
    //     0xacee44: str             x0, [SP, #-8]!
    // 0xacee48: r0 = _interpolate()
    //     0xacee48: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacee4c: add             SP, SP, #8
    // 0xacee50: LeaveFrame
    //     0xacee50: mov             SP, fp
    //     0xacee54: ldp             fp, lr, [SP], #0x10
    // 0xacee58: ret
    //     0xacee58: ret             
    // 0xacee5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacee5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacee60: b               #0xacee20
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfb028, size: 0x50
    // 0xbfb028: EnterFrame
    //     0xbfb028: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb02c: mov             fp, SP
    // 0xbfb030: CheckStackOverflow
    //     0xbfb030: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb034: cmp             SP, x16
    //     0xbfb038: b.ls            #0xbfb070
    // 0xbfb03c: ldr             x0, [fp, #0x10]
    // 0xbfb040: r1 = LoadClassIdInstr(r0)
    //     0xbfb040: ldur            x1, [x0, #-1]
    //     0xbfb044: ubfx            x1, x1, #0xc, #0x14
    // 0xbfb048: ldr             x16, [fp, #0x18]
    // 0xbfb04c: stp             x16, x0, [SP, #-0x10]!
    // 0xbfb050: mov             x0, x1
    // 0xbfb054: r0 = GDT[cid_x0 + -0x85a]()
    //     0xbfb054: sub             lr, x0, #0x85a
    //     0xbfb058: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb05c: blr             lr
    // 0xbfb060: add             SP, SP, #0x10
    // 0xbfb064: LeaveFrame
    //     0xbfb064: mov             SP, fp
    //     0xbfb068: ldp             fp, lr, [SP], #0x10
    // 0xbfb06c: ret
    //     0xbfb06c: ret             
    // 0xbfb070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb070: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb074: b               #0xbfb03c
  }
}

// class id: 4691, size: 0x1c, field offset: 0x10
class AttributeSelector extends SimpleSelector {

  _ toString(/* No info */) {
    // ** addr: 0xaceb58, size: 0x1e0
    // 0xaceb58: EnterFrame
    //     0xaceb58: stp             fp, lr, [SP, #-0x10]!
    //     0xaceb5c: mov             fp, SP
    // 0xaceb60: AllocStack(0x8)
    //     0xaceb60: sub             SP, SP, #8
    // 0xaceb64: CheckStackOverflow
    //     0xaceb64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaceb68: cmp             SP, x16
    //     0xaceb6c: b.ls            #0xaced30
    // 0xaceb70: r1 = Null
    //     0xaceb70: mov             x1, NULL
    // 0xaceb74: r2 = 10
    //     0xaceb74: mov             x2, #0xa
    // 0xaceb78: r0 = AllocateArray()
    //     0xaceb78: bl              #0xd6987c  ; AllocateArrayStub
    // 0xaceb7c: stur            x0, [fp, #-8]
    // 0xaceb80: r17 = "["
    //     0xaceb80: ldr             x17, [PP, #0x1468]  ; [pp+0x1468] "["
    // 0xaceb84: StoreField: r0->field_f = r17
    //     0xaceb84: stur            w17, [x0, #0xf]
    // 0xaceb88: ldr             x1, [fp, #0x10]
    // 0xaceb8c: LoadField: r2 = r1->field_b
    //     0xaceb8c: ldur            w2, [x1, #0xb]
    // 0xaceb90: DecompressPointer r2
    //     0xaceb90: add             x2, x2, HEAP, lsl #32
    // 0xaceb94: SaveReg r2
    //     0xaceb94: str             x2, [SP, #-8]!
    // 0xaceb98: r4 = 0
    //     0xaceb98: mov             x4, #0
    // 0xaceb9c: ldr             x0, [SP]
    // 0xaceba0: r16 = UnlinkedCall_0x4aeefc
    //     0xaceba0: add             x16, PP, #0x38, lsl #12  ; [pp+0x38590] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xaceba4: add             x16, x16, #0x590
    // 0xaceba8: ldp             x5, lr, [x16]
    // 0xacebac: blr             lr
    // 0xacebb0: add             SP, SP, #8
    // 0xacebb4: ldur            x1, [fp, #-8]
    // 0xacebb8: ArrayStore: r1[1] = r0  ; List_4
    //     0xacebb8: add             x25, x1, #0x13
    //     0xacebbc: str             w0, [x25]
    //     0xacebc0: tbz             w0, #0, #0xacebdc
    //     0xacebc4: ldurb           w16, [x1, #-1]
    //     0xacebc8: ldurb           w17, [x0, #-1]
    //     0xacebcc: and             x16, x17, x16, lsr #2
    //     0xacebd0: tst             x16, HEAP, lsr #32
    //     0xacebd4: b.eq            #0xacebdc
    //     0xacebd8: bl              #0xd67e5c
    // 0xacebdc: ldr             x2, [fp, #0x10]
    // 0xacebe0: LoadField: r3 = r2->field_f
    //     0xacebe0: ldur            x3, [x2, #0xf]
    // 0xacebe4: r0 = BoxInt64Instr(r3)
    //     0xacebe4: sbfiz           x0, x3, #1, #0x1f
    //     0xacebe8: cmp             x3, x0, asr #1
    //     0xacebec: b.eq            #0xacebf8
    //     0xacebf0: bl              #0xd69bb8
    //     0xacebf4: stur            x3, [x0, #7]
    // 0xacebf8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xacebf8: mov             x1, #0x76
    //     0xacebfc: tbz             w0, #0, #0xacec0c
    //     0xacec00: ldur            x1, [x0, #-1]
    //     0xacec04: ubfx            x1, x1, #0xc, #0x14
    //     0xacec08: lsl             x1, x1, #1
    // 0xacec0c: cmp             w1, #0x76
    // 0xacec10: b.ne            #0xaceca8
    // 0xacec14: cmp             x3, #0x214
    // 0xacec18: b.gt            #0xacec70
    // 0xacec1c: cmp             x3, #0x212
    // 0xacec20: b.gt            #0xacec50
    // 0xacec24: cmp             x3, #0x1c
    // 0xacec28: b.gt            #0xacec3c
    // 0xacec2c: cmp             w0, #0x38
    // 0xacec30: b.ne            #0xaceca8
    // 0xacec34: r0 = "="
    //     0xacec34: ldr             x0, [PP, #0x2a8]  ; [pp+0x2a8] "="
    // 0xacec38: b               #0xacecac
    // 0xacec3c: cmp             x3, #0x212
    // 0xacec40: b.lt            #0xaceca8
    // 0xacec44: r0 = "~="
    //     0xacec44: add             x0, PP, #0x38, lsl #12  ; [pp+0x385a0] "~="
    //     0xacec48: ldr             x0, [x0, #0x5a0]
    // 0xacec4c: b               #0xacecac
    // 0xacec50: cmp             x3, #0x213
    // 0xacec54: b.gt            #0xacec64
    // 0xacec58: r0 = "|="
    //     0xacec58: add             x0, PP, #0x38, lsl #12  ; [pp+0x385a8] "|="
    //     0xacec5c: ldr             x0, [x0, #0x5a8]
    // 0xacec60: b               #0xacecac
    // 0xacec64: r0 = "^="
    //     0xacec64: add             x0, PP, #0x38, lsl #12  ; [pp+0x385b0] "^="
    //     0xacec68: ldr             x0, [x0, #0x5b0]
    // 0xacec6c: b               #0xacecac
    // 0xacec70: cmp             x3, #0x216
    // 0xacec74: b.gt            #0xacec98
    // 0xacec78: cmp             x3, #0x215
    // 0xacec7c: b.gt            #0xacec8c
    // 0xacec80: r0 = "$="
    //     0xacec80: add             x0, PP, #0x38, lsl #12  ; [pp+0x385b8] "$="
    //     0xacec84: ldr             x0, [x0, #0x5b8]
    // 0xacec88: b               #0xacecac
    // 0xacec8c: r0 = "*="
    //     0xacec8c: add             x0, PP, #0x38, lsl #12  ; [pp+0x385c0] "*="
    //     0xacec90: ldr             x0, [x0, #0x5c0]
    // 0xacec94: b               #0xacecac
    // 0xacec98: cmp             w0, #0x42e
    // 0xacec9c: b.ne            #0xaceca8
    // 0xaceca0: r0 = ""
    //     0xaceca0: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xaceca4: b               #0xacecac
    // 0xaceca8: r0 = Null
    //     0xaceca8: mov             x0, NULL
    // 0xacecac: ldur            x3, [fp, #-8]
    // 0xacecb0: mov             x1, x3
    // 0xacecb4: ArrayStore: r1[2] = r0  ; List_4
    //     0xacecb4: add             x25, x1, #0x17
    //     0xacecb8: str             w0, [x25]
    //     0xacecbc: tbz             w0, #0, #0xacecd8
    //     0xacecc0: ldurb           w16, [x1, #-1]
    //     0xacecc4: ldurb           w17, [x0, #-1]
    //     0xacecc8: and             x16, x17, x16, lsr #2
    //     0xaceccc: tst             x16, HEAP, lsr #32
    //     0xacecd0: b.eq            #0xacecd8
    //     0xacecd4: bl              #0xd67e5c
    // 0xacecd8: SaveReg r2
    //     0xacecd8: str             x2, [SP, #-8]!
    // 0xacecdc: r0 = valueToString()
    //     0xacecdc: bl              #0xaced38  ; [package:csslib/visitor.dart] AttributeSelector::valueToString
    // 0xacece0: add             SP, SP, #8
    // 0xacece4: ldur            x1, [fp, #-8]
    // 0xacece8: ArrayStore: r1[3] = r0  ; List_4
    //     0xacece8: add             x25, x1, #0x1b
    //     0xacecec: str             w0, [x25]
    //     0xacecf0: tbz             w0, #0, #0xaced0c
    //     0xacecf4: ldurb           w16, [x1, #-1]
    //     0xacecf8: ldurb           w17, [x0, #-1]
    //     0xacecfc: and             x16, x17, x16, lsr #2
    //     0xaced00: tst             x16, HEAP, lsr #32
    //     0xaced04: b.eq            #0xaced0c
    //     0xaced08: bl              #0xd67e5c
    // 0xaced0c: ldur            x0, [fp, #-8]
    // 0xaced10: r17 = "]"
    //     0xaced10: ldr             x17, [PP, #0x1460]  ; [pp+0x1460] "]"
    // 0xaced14: StoreField: r0->field_1f = r17
    //     0xaced14: stur            w17, [x0, #0x1f]
    // 0xaced18: SaveReg r0
    //     0xaced18: str             x0, [SP, #-8]!
    // 0xaced1c: r0 = _interpolate()
    //     0xaced1c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xaced20: add             SP, SP, #8
    // 0xaced24: LeaveFrame
    //     0xaced24: mov             SP, fp
    //     0xaced28: ldp             fp, lr, [SP], #0x10
    // 0xaced2c: ret
    //     0xaced2c: ret             
    // 0xaced30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaced30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaced34: b               #0xaceb70
  }
  _ valueToString(/* No info */) {
    // ** addr: 0xaced38, size: 0xd4
    // 0xaced38: EnterFrame
    //     0xaced38: stp             fp, lr, [SP, #-0x10]!
    //     0xaced3c: mov             fp, SP
    // 0xaced40: AllocStack(0x8)
    //     0xaced40: sub             SP, SP, #8
    // 0xaced44: CheckStackOverflow
    //     0xaced44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaced48: cmp             SP, x16
    //     0xaced4c: b.ls            #0xacee04
    // 0xaced50: ldr             x0, [fp, #0x10]
    // 0xaced54: LoadField: r3 = r0->field_17
    //     0xaced54: ldur            w3, [x0, #0x17]
    // 0xaced58: DecompressPointer r3
    //     0xaced58: add             x3, x3, HEAP, lsl #32
    // 0xaced5c: stur            x3, [fp, #-8]
    // 0xaced60: cmp             w3, NULL
    // 0xaced64: b.eq            #0xacedf4
    // 0xaced68: r0 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xaced68: mov             x0, #0x76
    //     0xaced6c: tbz             w3, #0, #0xaced7c
    //     0xaced70: ldur            x0, [x3, #-1]
    //     0xaced74: ubfx            x0, x0, #0xc, #0x14
    //     0xaced78: lsl             x0, x0, #1
    // 0xaced7c: r17 = 9464
    //     0xaced7c: mov             x17, #0x24f8
    // 0xaced80: cmp             w0, w17
    // 0xaced84: b.ne            #0xacedb8
    // 0xaced88: r0 = LoadClassIdInstr(r3)
    //     0xaced88: ldur            x0, [x3, #-1]
    //     0xaced8c: ubfx            x0, x0, #0xc, #0x14
    // 0xaced90: SaveReg r3
    //     0xaced90: str             x3, [SP, #-8]!
    // 0xaced94: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xaced94: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xaced98: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xaced98: mov             x17, #0x3f73
    //     0xaced9c: add             lr, x0, x17
    //     0xaceda0: ldr             lr, [x21, lr, lsl #3]
    //     0xaceda4: blr             lr
    // 0xaceda8: add             SP, SP, #8
    // 0xacedac: LeaveFrame
    //     0xacedac: mov             SP, fp
    //     0xacedb0: ldp             fp, lr, [SP], #0x10
    // 0xacedb4: ret
    //     0xacedb4: ret             
    // 0xacedb8: r1 = Null
    //     0xacedb8: mov             x1, NULL
    // 0xacedbc: r2 = 6
    //     0xacedbc: mov             x2, #6
    // 0xacedc0: r0 = AllocateArray()
    //     0xacedc0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacedc4: r17 = "\""
    //     0xacedc4: ldr             x17, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0xacedc8: StoreField: r0->field_f = r17
    //     0xacedc8: stur            w17, [x0, #0xf]
    // 0xacedcc: ldur            x1, [fp, #-8]
    // 0xacedd0: StoreField: r0->field_13 = r1
    //     0xacedd0: stur            w1, [x0, #0x13]
    // 0xacedd4: r17 = "\""
    //     0xacedd4: ldr             x17, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0xacedd8: StoreField: r0->field_17 = r17
    //     0xacedd8: stur            w17, [x0, #0x17]
    // 0xaceddc: SaveReg r0
    //     0xaceddc: str             x0, [SP, #-8]!
    // 0xacede0: r0 = _interpolate()
    //     0xacede0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacede4: add             SP, SP, #8
    // 0xacede8: LeaveFrame
    //     0xacede8: mov             SP, fp
    //     0xacedec: ldp             fp, lr, [SP], #0x10
    // 0xacedf0: ret
    //     0xacedf0: ret             
    // 0xacedf4: r0 = ""
    //     0xacedf4: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xacedf8: LeaveFrame
    //     0xacedf8: mov             SP, fp
    //     0xacedfc: ldp             fp, lr, [SP], #0x10
    // 0xacee00: ret
    //     0xacee00: ret             
    // 0xacee04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacee04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacee08: b               #0xaced50
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfafd8, size: 0x50
    // 0xbfafd8: EnterFrame
    //     0xbfafd8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfafdc: mov             fp, SP
    // 0xbfafe0: CheckStackOverflow
    //     0xbfafe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfafe4: cmp             SP, x16
    //     0xbfafe8: b.ls            #0xbfb020
    // 0xbfafec: ldr             x0, [fp, #0x10]
    // 0xbfaff0: r1 = LoadClassIdInstr(r0)
    //     0xbfaff0: ldur            x1, [x0, #-1]
    //     0xbfaff4: ubfx            x1, x1, #0xc, #0x14
    // 0xbfaff8: ldr             x16, [fp, #0x18]
    // 0xbfaffc: stp             x16, x0, [SP, #-0x10]!
    // 0xbfb000: mov             x0, x1
    // 0xbfb004: r0 = GDT[cid_x0 + -0x85e]()
    //     0xbfb004: sub             lr, x0, #0x85e
    //     0xbfb008: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb00c: blr             lr
    // 0xbfb010: add             SP, SP, #0x10
    // 0xbfb014: LeaveFrame
    //     0xbfb014: mov             SP, fp
    //     0xbfb018: ldp             fp, lr, [SP], #0x10
    // 0xbfb01c: ret
    //     0xbfb01c: ret             
    // 0xbfb020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb020: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb024: b               #0xbfafec
  }
}

// class id: 4692, size: 0x14, field offset: 0x10
class NamespaceSelector extends SimpleSelector {

  _ toString(/* No info */) {
    // ** addr: 0xace9a4, size: 0x1b4
    // 0xace9a4: EnterFrame
    //     0xace9a4: stp             fp, lr, [SP, #-0x10]!
    //     0xace9a8: mov             fp, SP
    // 0xace9ac: AllocStack(0x10)
    //     0xace9ac: sub             SP, SP, #0x10
    // 0xace9b0: CheckStackOverflow
    //     0xace9b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xace9b4: cmp             SP, x16
    //     0xace9b8: b.ls            #0xaceb4c
    // 0xace9bc: ldr             x3, [fp, #0x10]
    // 0xace9c0: LoadField: r4 = r3->field_f
    //     0xace9c0: ldur            w4, [x3, #0xf]
    // 0xace9c4: DecompressPointer r4
    //     0xace9c4: add             x4, x4, HEAP, lsl #32
    // 0xace9c8: stur            x4, [fp, #-8]
    // 0xace9cc: r0 = LoadTaggedClassIdMayBeSmiInstr(r4)
    //     0xace9cc: mov             x0, #0x76
    //     0xace9d0: tbz             w4, #0, #0xace9e0
    //     0xace9d4: ldur            x0, [x4, #-1]
    //     0xace9d8: ubfx            x0, x0, #0xc, #0x14
    //     0xace9dc: lsl             x0, x0, #1
    // 0xace9e0: r17 = 9462
    //     0xace9e0: mov             x17, #0x24f6
    // 0xace9e4: cmp             w0, w17
    // 0xace9e8: b.ne            #0xace9f8
    // 0xace9ec: mov             x0, x3
    // 0xace9f0: r3 = "*"
    //     0xace9f0: ldr             x3, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0xace9f4: b               #0xacea5c
    // 0xace9f8: cmp             w4, NULL
    // 0xace9fc: b.ne            #0xacea08
    // 0xacea00: r0 = ""
    //     0xacea00: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xacea04: b               #0xacea54
    // 0xacea08: mov             x0, x4
    // 0xacea0c: r2 = Null
    //     0xacea0c: mov             x2, NULL
    // 0xacea10: r1 = Null
    //     0xacea10: mov             x1, NULL
    // 0xacea14: r4 = 59
    //     0xacea14: mov             x4, #0x3b
    // 0xacea18: branchIfSmi(r0, 0xacea24)
    //     0xacea18: tbz             w0, #0, #0xacea24
    // 0xacea1c: r4 = LoadClassIdInstr(r0)
    //     0xacea1c: ldur            x4, [x0, #-1]
    //     0xacea20: ubfx            x4, x4, #0xc, #0x14
    // 0xacea24: r17 = 4732
    //     0xacea24: mov             x17, #0x127c
    // 0xacea28: cmp             x4, x17
    // 0xacea2c: b.eq            #0xacea44
    // 0xacea30: r8 = Identifier
    //     0xacea30: add             x8, PP, #0x38, lsl #12  ; [pp+0x385c8] Type: Identifier
    //     0xacea34: ldr             x8, [x8, #0x5c8]
    // 0xacea38: r3 = Null
    //     0xacea38: add             x3, PP, #0x38, lsl #12  ; [pp+0x385d0] Null
    //     0xacea3c: ldr             x3, [x3, #0x5d0]
    // 0xacea40: r0 = DefaultTypeTest()
    //     0xacea40: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xacea44: ldur            x0, [fp, #-8]
    // 0xacea48: LoadField: r1 = r0->field_b
    //     0xacea48: ldur            w1, [x0, #0xb]
    // 0xacea4c: DecompressPointer r1
    //     0xacea4c: add             x1, x1, HEAP, lsl #32
    // 0xacea50: mov             x0, x1
    // 0xacea54: mov             x3, x0
    // 0xacea58: ldr             x0, [fp, #0x10]
    // 0xacea5c: stur            x3, [fp, #-8]
    // 0xacea60: r1 = Null
    //     0xacea60: mov             x1, NULL
    // 0xacea64: r2 = 6
    //     0xacea64: mov             x2, #6
    // 0xacea68: r0 = AllocateArray()
    //     0xacea68: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacea6c: mov             x3, x0
    // 0xacea70: ldur            x0, [fp, #-8]
    // 0xacea74: stur            x3, [fp, #-0x10]
    // 0xacea78: StoreField: r3->field_f = r0
    //     0xacea78: stur            w0, [x3, #0xf]
    // 0xacea7c: r17 = "|"
    //     0xacea7c: ldr             x17, [PP, #0x4878]  ; [pp+0x4878] "|"
    // 0xacea80: StoreField: r3->field_13 = r17
    //     0xacea80: stur            w17, [x3, #0x13]
    // 0xacea84: ldr             x0, [fp, #0x10]
    // 0xacea88: LoadField: r4 = r0->field_b
    //     0xacea88: ldur            w4, [x0, #0xb]
    // 0xacea8c: DecompressPointer r4
    //     0xacea8c: add             x4, x4, HEAP, lsl #32
    // 0xacea90: mov             x0, x4
    // 0xacea94: stur            x4, [fp, #-8]
    // 0xacea98: r2 = Null
    //     0xacea98: mov             x2, NULL
    // 0xacea9c: r1 = Null
    //     0xacea9c: mov             x1, NULL
    // 0xaceaa0: r4 = 59
    //     0xaceaa0: mov             x4, #0x3b
    // 0xaceaa4: branchIfSmi(r0, 0xaceab0)
    //     0xaceaa4: tbz             w0, #0, #0xaceab0
    // 0xaceaa8: r4 = LoadClassIdInstr(r0)
    //     0xaceaa8: ldur            x4, [x0, #-1]
    //     0xaceaac: ubfx            x4, x4, #0xc, #0x14
    // 0xaceab0: r17 = -4684
    //     0xaceab0: mov             x17, #-0x124c
    // 0xaceab4: add             x4, x4, x17
    // 0xaceab8: cmp             x4, #9
    // 0xaceabc: b.ls            #0xacead4
    // 0xaceac0: r8 = SimpleSelector?
    //     0xaceac0: add             x8, PP, #0x38, lsl #12  ; [pp+0x385e0] Type: SimpleSelector?
    //     0xaceac4: ldr             x8, [x8, #0x5e0]
    // 0xaceac8: r3 = Null
    //     0xaceac8: add             x3, PP, #0x38, lsl #12  ; [pp+0x385e8] Null
    //     0xaceacc: ldr             x3, [x3, #0x5e8]
    // 0xacead0: r0 = DefaultNullableTypeTest()
    //     0xacead0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xacead4: ldur            x0, [fp, #-8]
    // 0xacead8: cmp             w0, NULL
    // 0xaceadc: b.eq            #0xaceb54
    // 0xaceae0: LoadField: r1 = r0->field_b
    //     0xaceae0: ldur            w1, [x0, #0xb]
    // 0xaceae4: DecompressPointer r1
    //     0xaceae4: add             x1, x1, HEAP, lsl #32
    // 0xaceae8: SaveReg r1
    //     0xaceae8: str             x1, [SP, #-8]!
    // 0xaceaec: r4 = 0
    //     0xaceaec: mov             x4, #0
    // 0xaceaf0: ldr             x0, [SP]
    // 0xaceaf4: r16 = UnlinkedCall_0x4aeefc
    //     0xaceaf4: add             x16, PP, #0x38, lsl #12  ; [pp+0x385f8] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xaceaf8: add             x16, x16, #0x5f8
    // 0xaceafc: ldp             x5, lr, [x16]
    // 0xaceb00: blr             lr
    // 0xaceb04: add             SP, SP, #8
    // 0xaceb08: ldur            x1, [fp, #-0x10]
    // 0xaceb0c: ArrayStore: r1[2] = r0  ; List_4
    //     0xaceb0c: add             x25, x1, #0x17
    //     0xaceb10: str             w0, [x25]
    //     0xaceb14: tbz             w0, #0, #0xaceb30
    //     0xaceb18: ldurb           w16, [x1, #-1]
    //     0xaceb1c: ldurb           w17, [x0, #-1]
    //     0xaceb20: and             x16, x17, x16, lsr #2
    //     0xaceb24: tst             x16, HEAP, lsr #32
    //     0xaceb28: b.eq            #0xaceb30
    //     0xaceb2c: bl              #0xd67e5c
    // 0xaceb30: ldur            x16, [fp, #-0x10]
    // 0xaceb34: SaveReg r16
    //     0xaceb34: str             x16, [SP, #-8]!
    // 0xaceb38: r0 = _interpolate()
    //     0xaceb38: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xaceb3c: add             SP, SP, #8
    // 0xaceb40: LeaveFrame
    //     0xaceb40: mov             SP, fp
    //     0xaceb44: ldp             fp, lr, [SP], #0x10
    // 0xaceb48: ret
    //     0xaceb48: ret             
    // 0xaceb4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaceb4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaceb50: b               #0xace9bc
    // 0xaceb54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaceb54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfaf88, size: 0x50
    // 0xbfaf88: EnterFrame
    //     0xbfaf88: stp             fp, lr, [SP, #-0x10]!
    //     0xbfaf8c: mov             fp, SP
    // 0xbfaf90: CheckStackOverflow
    //     0xbfaf90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfaf94: cmp             SP, x16
    //     0xbfaf98: b.ls            #0xbfafd0
    // 0xbfaf9c: ldr             x0, [fp, #0x10]
    // 0xbfafa0: r1 = LoadClassIdInstr(r0)
    //     0xbfafa0: ldur            x1, [x0, #-1]
    //     0xbfafa4: ubfx            x1, x1, #0xc, #0x14
    // 0xbfafa8: ldr             x16, [fp, #0x18]
    // 0xbfafac: stp             x16, x0, [SP, #-0x10]!
    // 0xbfafb0: mov             x0, x1
    // 0xbfafb4: r0 = GDT[cid_x0 + -0x86f]()
    //     0xbfafb4: sub             lr, x0, #0x86f
    //     0xbfafb8: ldr             lr, [x21, lr, lsl #3]
    //     0xbfafbc: blr             lr
    // 0xbfafc0: add             SP, SP, #0x10
    // 0xbfafc4: LeaveFrame
    //     0xbfafc4: mov             SP, fp
    //     0xbfafc8: ldp             fp, lr, [SP], #0x10
    // 0xbfafcc: ret
    //     0xbfafcc: ret             
    // 0xbfafd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfafd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfafd4: b               #0xbfaf9c
  }
}

// class id: 4693, size: 0x10, field offset: 0x10
class ElementSelector extends SimpleSelector {

  _ toString(/* No info */) {
    // ** addr: 0xace950, size: 0x54
    // 0xace950: EnterFrame
    //     0xace950: stp             fp, lr, [SP, #-0x10]!
    //     0xace954: mov             fp, SP
    // 0xace958: CheckStackOverflow
    //     0xace958: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xace95c: cmp             SP, x16
    //     0xace960: b.ls            #0xace99c
    // 0xace964: ldr             x0, [fp, #0x10]
    // 0xace968: LoadField: r1 = r0->field_b
    //     0xace968: ldur            w1, [x0, #0xb]
    // 0xace96c: DecompressPointer r1
    //     0xace96c: add             x1, x1, HEAP, lsl #32
    // 0xace970: SaveReg r1
    //     0xace970: str             x1, [SP, #-8]!
    // 0xace974: r4 = 0
    //     0xace974: mov             x4, #0
    // 0xace978: ldr             x0, [SP]
    // 0xace97c: r16 = UnlinkedCall_0x4aeefc
    //     0xace97c: add             x16, PP, #0x38, lsl #12  ; [pp+0x38618] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xace980: add             x16, x16, #0x618
    // 0xace984: ldp             x5, lr, [x16]
    // 0xace988: blr             lr
    // 0xace98c: add             SP, SP, #8
    // 0xace990: LeaveFrame
    //     0xace990: mov             SP, fp
    //     0xace994: ldp             fp, lr, [SP], #0x10
    // 0xace998: ret
    //     0xace998: ret             
    // 0xace99c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xace99c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xace9a0: b               #0xace964
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfaf38, size: 0x50
    // 0xbfaf38: EnterFrame
    //     0xbfaf38: stp             fp, lr, [SP, #-0x10]!
    //     0xbfaf3c: mov             fp, SP
    // 0xbfaf40: CheckStackOverflow
    //     0xbfaf40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfaf44: cmp             SP, x16
    //     0xbfaf48: b.ls            #0xbfaf80
    // 0xbfaf4c: ldr             x0, [fp, #0x10]
    // 0xbfaf50: r1 = LoadClassIdInstr(r0)
    //     0xbfaf50: ldur            x1, [x0, #-1]
    //     0xbfaf54: ubfx            x1, x1, #0xc, #0x14
    // 0xbfaf58: ldr             x16, [fp, #0x18]
    // 0xbfaf5c: stp             x16, x0, [SP, #-0x10]!
    // 0xbfaf60: mov             x0, x1
    // 0xbfaf64: r0 = GDT[cid_x0 + -0x8be]()
    //     0xbfaf64: sub             lr, x0, #0x8be
    //     0xbfaf68: ldr             lr, [x21, lr, lsl #3]
    //     0xbfaf6c: blr             lr
    // 0xbfaf70: add             SP, SP, #0x10
    // 0xbfaf74: LeaveFrame
    //     0xbfaf74: mov             SP, fp
    //     0xbfaf78: ldp             fp, lr, [SP], #0x10
    // 0xbfaf7c: ret
    //     0xbfaf7c: ret             
    // 0xbfaf80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfaf80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfaf84: b               #0xbfaf4c
  }
}

// class id: 4694, size: 0x18, field offset: 0xc
class SimpleSelectorSequence extends TreeNode {

  _ toString(/* No info */) {
    // ** addr: 0xace8f4, size: 0x5c
    // 0xace8f4: EnterFrame
    //     0xace8f4: stp             fp, lr, [SP, #-0x10]!
    //     0xace8f8: mov             fp, SP
    // 0xace8fc: CheckStackOverflow
    //     0xace8fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xace900: cmp             SP, x16
    //     0xace904: b.ls            #0xace948
    // 0xace908: ldr             x0, [fp, #0x10]
    // 0xace90c: LoadField: r1 = r0->field_13
    //     0xace90c: ldur            w1, [x0, #0x13]
    // 0xace910: DecompressPointer r1
    //     0xace910: add             x1, x1, HEAP, lsl #32
    // 0xace914: LoadField: r0 = r1->field_b
    //     0xace914: ldur            w0, [x1, #0xb]
    // 0xace918: DecompressPointer r0
    //     0xace918: add             x0, x0, HEAP, lsl #32
    // 0xace91c: SaveReg r0
    //     0xace91c: str             x0, [SP, #-8]!
    // 0xace920: r4 = 0
    //     0xace920: mov             x4, #0
    // 0xace924: ldr             x0, [SP]
    // 0xace928: r16 = UnlinkedCall_0x4aeefc
    //     0xace928: add             x16, PP, #0x38, lsl #12  ; [pp+0x38580] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xace92c: add             x16, x16, #0x580
    // 0xace930: ldp             x5, lr, [x16]
    // 0xace934: blr             lr
    // 0xace938: add             SP, SP, #8
    // 0xace93c: LeaveFrame
    //     0xace93c: mov             SP, fp
    //     0xace940: ldp             fp, lr, [SP], #0x10
    // 0xace944: ret
    //     0xace944: ret             
    // 0xace948: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xace948: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xace94c: b               #0xace908
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfaea0, size: 0x40
    // 0xbfaea0: EnterFrame
    //     0xbfaea0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfaea4: mov             fp, SP
    // 0xbfaea8: CheckStackOverflow
    //     0xbfaea8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfaeac: cmp             SP, x16
    //     0xbfaeb0: b.ls            #0xbfaed8
    // 0xbfaeb4: ldr             x16, [fp, #0x10]
    // 0xbfaeb8: ldr             lr, [fp, #0x18]
    // 0xbfaebc: stp             lr, x16, [SP, #-0x10]!
    // 0xbfaec0: r0 = visitSimpleSelectorSequence()
    //     0xbfaec0: bl              #0xbfaee0  ; [package:csslib/visitor.dart] Visitor::visitSimpleSelectorSequence
    // 0xbfaec4: add             SP, SP, #0x10
    // 0xbfaec8: r0 = Null
    //     0xbfaec8: mov             x0, NULL
    // 0xbfaecc: LeaveFrame
    //     0xbfaecc: mov             SP, fp
    //     0xbfaed0: ldp             fp, lr, [SP], #0x10
    // 0xbfaed4: ret
    //     0xbfaed4: ret             
    // 0xbfaed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfaed8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfaedc: b               #0xbfaeb4
  }
}

// class id: 4695, size: 0x10, field offset: 0xc
class Selector extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xbfae60, size: 0x40
    // 0xbfae60: EnterFrame
    //     0xbfae60: stp             fp, lr, [SP, #-0x10]!
    //     0xbfae64: mov             fp, SP
    // 0xbfae68: CheckStackOverflow
    //     0xbfae68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfae6c: cmp             SP, x16
    //     0xbfae70: b.ls            #0xbfae98
    // 0xbfae74: ldr             x16, [fp, #0x10]
    // 0xbfae78: ldr             lr, [fp, #0x18]
    // 0xbfae7c: stp             lr, x16, [SP, #-0x10]!
    // 0xbfae80: r0 = visitStyleSheet()
    //     0xbfae80: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfae84: add             SP, SP, #0x10
    // 0xbfae88: r0 = Null
    //     0xbfae88: mov             x0, NULL
    // 0xbfae8c: LeaveFrame
    //     0xbfae8c: mov             SP, fp
    //     0xbfae90: ldp             fp, lr, [SP], #0x10
    // 0xbfae94: ret
    //     0xbfae94: ret             
    // 0xbfae98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfae98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfae9c: b               #0xbfae74
  }
}

// class id: 4696, size: 0x10, field offset: 0xc
class SelectorGroup extends TreeNode {

  _ visit(/* No info */) {
    // ** addr: 0xbfae20, size: 0x40
    // 0xbfae20: EnterFrame
    //     0xbfae20: stp             fp, lr, [SP, #-0x10]!
    //     0xbfae24: mov             fp, SP
    // 0xbfae28: CheckStackOverflow
    //     0xbfae28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfae2c: cmp             SP, x16
    //     0xbfae30: b.ls            #0xbfae58
    // 0xbfae34: ldr             x16, [fp, #0x10]
    // 0xbfae38: ldr             lr, [fp, #0x18]
    // 0xbfae3c: stp             lr, x16, [SP, #-0x10]!
    // 0xbfae40: r0 = visitStyleSheet()
    //     0xbfae40: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfae44: add             SP, SP, #0x10
    // 0xbfae48: r0 = Null
    //     0xbfae48: mov             x0, NULL
    // 0xbfae4c: LeaveFrame
    //     0xbfae4c: mov             SP, fp
    //     0xbfae50: ldp             fp, lr, [SP], #0x10
    // 0xbfae54: ret
    //     0xbfae54: ret             
    // 0xbfae58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfae58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfae5c: b               #0xbfae34
  }
}

// class id: 4697, size: 0xc, field offset: 0xc
abstract class Expression extends TreeNode {
}

// class id: 4698, size: 0x10, field offset: 0xc
class Expressions extends Expression {

  _ visit(/* No info */) {
    // ** addr: 0xbfade0, size: 0x40
    // 0xbfade0: EnterFrame
    //     0xbfade0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfade4: mov             fp, SP
    // 0xbfade8: CheckStackOverflow
    //     0xbfade8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfadec: cmp             SP, x16
    //     0xbfadf0: b.ls            #0xbfae18
    // 0xbfadf4: ldr             x16, [fp, #0x10]
    // 0xbfadf8: ldr             lr, [fp, #0x18]
    // 0xbfadfc: stp             lr, x16, [SP, #-0x10]!
    // 0xbfae00: r0 = visitExpressions()
    //     0xbfae00: bl              #0xbfa8ac  ; [package:flutter_html/src/css_parser.dart] DeclarationVisitor::visitExpressions
    // 0xbfae04: add             SP, SP, #0x10
    // 0xbfae08: r0 = Null
    //     0xbfae08: mov             x0, NULL
    // 0xbfae0c: LeaveFrame
    //     0xbfae0c: mov             SP, fp
    //     0xbfae10: ldp             fp, lr, [SP], #0x10
    // 0xbfae14: ret
    //     0xbfae14: ret             
    // 0xbfae18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfae18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfae1c: b               #0xbfadf4
  }
}

// class id: 4699, size: 0x10, field offset: 0xc
class GroupTerm extends Expression {

  _ visit(/* No info */) {
    // ** addr: 0xbfac08, size: 0x40
    // 0xbfac08: EnterFrame
    //     0xbfac08: stp             fp, lr, [SP, #-0x10]!
    //     0xbfac0c: mov             fp, SP
    // 0xbfac10: CheckStackOverflow
    //     0xbfac10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfac14: cmp             SP, x16
    //     0xbfac18: b.ls            #0xbfac40
    // 0xbfac1c: ldr             x16, [fp, #0x10]
    // 0xbfac20: ldr             lr, [fp, #0x18]
    // 0xbfac24: stp             lr, x16, [SP, #-0x10]!
    // 0xbfac28: r0 = visitGroupTerm()
    //     0xbfac28: bl              #0xbfac48  ; [package:csslib/visitor.dart] Visitor::visitGroupTerm
    // 0xbfac2c: add             SP, SP, #0x10
    // 0xbfac30: r0 = Null
    //     0xbfac30: mov             x0, NULL
    // 0xbfac34: LeaveFrame
    //     0xbfac34: mov             SP, fp
    //     0xbfac38: ldp             fp, lr, [SP], #0x10
    // 0xbfac3c: ret
    //     0xbfac3c: ret             
    // 0xbfac40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfac40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfac44: b               #0xbfac1c
  }
}

// class id: 4700, size: 0xc, field offset: 0xc
class UnicodeRangeTerm extends Expression {
}

// class id: 4701, size: 0xc, field offset: 0xc
class OperatorMinus extends Expression {
}

// class id: 4702, size: 0xc, field offset: 0xc
class OperatorPlus extends Expression {
}

// class id: 4703, size: 0xc, field offset: 0xc
class OperatorComma extends Expression {
}

// class id: 4704, size: 0xc, field offset: 0xc
class OperatorSlash extends Expression {
}

// class id: 4705, size: 0x10, field offset: 0xc
class VarUsage extends Expression {

  _ visit(/* No info */) {
    // ** addr: 0xbfabc8, size: 0x40
    // 0xbfabc8: EnterFrame
    //     0xbfabc8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfabcc: mov             fp, SP
    // 0xbfabd0: CheckStackOverflow
    //     0xbfabd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfabd4: cmp             SP, x16
    //     0xbfabd8: b.ls            #0xbfac00
    // 0xbfabdc: ldr             x16, [fp, #0x10]
    // 0xbfabe0: ldr             lr, [fp, #0x18]
    // 0xbfabe4: stp             lr, x16, [SP, #-0x10]!
    // 0xbfabe8: r0 = visitStyleSheet()
    //     0xbfabe8: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfabec: add             SP, SP, #0x10
    // 0xbfabf0: r0 = Null
    //     0xbfabf0: mov             x0, NULL
    // 0xbfabf4: LeaveFrame
    //     0xbfabf4: mov             SP, fp
    //     0xbfabf8: ldp             fp, lr, [SP], #0x10
    // 0xbfabfc: ret
    //     0xbfabfc: ret             
    // 0xbfac00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfac00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfac04: b               #0xbfabdc
  }
}

// class id: 4706, size: 0x14, field offset: 0xc
class KeyFrameBlock extends Expression {

  _ visit(/* No info */) {
    // ** addr: 0xbfa9ec, size: 0x40
    // 0xbfa9ec: EnterFrame
    //     0xbfa9ec: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa9f0: mov             fp, SP
    // 0xbfa9f4: CheckStackOverflow
    //     0xbfa9f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfa9f8: cmp             SP, x16
    //     0xbfa9fc: b.ls            #0xbfaa24
    // 0xbfaa00: ldr             x16, [fp, #0x10]
    // 0xbfaa04: ldr             lr, [fp, #0x18]
    // 0xbfaa08: stp             lr, x16, [SP, #-0x10]!
    // 0xbfaa0c: r0 = visitKeyFrameBlock()
    //     0xbfaa0c: bl              #0xbfaa2c  ; [package:csslib/visitor.dart] Visitor::visitKeyFrameBlock
    // 0xbfaa10: add             SP, SP, #0x10
    // 0xbfaa14: r0 = Null
    //     0xbfaa14: mov             x0, NULL
    // 0xbfaa18: LeaveFrame
    //     0xbfaa18: mov             SP, fp
    //     0xbfaa1c: ldp             fp, lr, [SP], #0x10
    // 0xbfaa20: ret
    //     0xbfaa20: ret             
    // 0xbfaa24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfaa24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfaa28: b               #0xbfaa00
  }
}

// class id: 4707, size: 0x14, field offset: 0xc
class LiteralTerm extends Expression {
}

// class id: 4708, size: 0x14, field offset: 0x14
class IE8Term extends LiteralTerm {
}

// class id: 4709, size: 0x18, field offset: 0x14
class FunctionTerm extends LiteralTerm {

  _ visit(/* No info */) {
    // ** addr: 0xbfa824, size: 0x40
    // 0xbfa824: EnterFrame
    //     0xbfa824: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa828: mov             fp, SP
    // 0xbfa82c: CheckStackOverflow
    //     0xbfa82c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfa830: cmp             SP, x16
    //     0xbfa834: b.ls            #0xbfa85c
    // 0xbfa838: ldr             x16, [fp, #0x10]
    // 0xbfa83c: ldr             lr, [fp, #0x18]
    // 0xbfa840: stp             lr, x16, [SP, #-0x10]!
    // 0xbfa844: r0 = visitFunctionTerm()
    //     0xbfa844: bl              #0xbfa864  ; [package:csslib/visitor.dart] Visitor::visitFunctionTerm
    // 0xbfa848: add             SP, SP, #0x10
    // 0xbfa84c: r0 = Null
    //     0xbfa84c: mov             x0, NULL
    // 0xbfa850: LeaveFrame
    //     0xbfa850: mov             SP, fp
    //     0xbfa854: ldp             fp, lr, [SP], #0x10
    // 0xbfa858: ret
    //     0xbfa858: ret             
    // 0xbfa85c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa85c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa860: b               #0xbfa838
  }
}

// class id: 4710, size: 0x14, field offset: 0x14
class HexColorTerm extends LiteralTerm {
}

// class id: 4711, size: 0x14, field offset: 0x14
class UriTerm extends LiteralTerm {
}

// class id: 4712, size: 0x14, field offset: 0x14
class FractionTerm extends LiteralTerm {
}

// class id: 4713, size: 0x14, field offset: 0x14
class ExTerm extends LiteralTerm {
}

// class id: 4714, size: 0x14, field offset: 0x14
class EmTerm extends LiteralTerm {
}

// class id: 4715, size: 0x14, field offset: 0x14
class PercentageTerm extends LiteralTerm {
}

// class id: 4716, size: 0x1c, field offset: 0x14
abstract class UnitTerm extends LiteralTerm {

  _ toString(/* No info */) {
    // ** addr: 0xace624, size: 0xa0
    // 0xace624: EnterFrame
    //     0xace624: stp             fp, lr, [SP, #-0x10]!
    //     0xace628: mov             fp, SP
    // 0xace62c: AllocStack(0x10)
    //     0xace62c: sub             SP, SP, #0x10
    // 0xace630: CheckStackOverflow
    //     0xace630: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xace634: cmp             SP, x16
    //     0xace638: b.ls            #0xace6bc
    // 0xace63c: ldr             x0, [fp, #0x10]
    // 0xace640: LoadField: r3 = r0->field_f
    //     0xace640: ldur            w3, [x0, #0xf]
    // 0xace644: DecompressPointer r3
    //     0xace644: add             x3, x3, HEAP, lsl #32
    // 0xace648: stur            x3, [fp, #-8]
    // 0xace64c: r1 = Null
    //     0xace64c: mov             x1, NULL
    // 0xace650: r2 = 4
    //     0xace650: mov             x2, #4
    // 0xace654: r0 = AllocateArray()
    //     0xace654: bl              #0xd6987c  ; AllocateArrayStub
    // 0xace658: mov             x1, x0
    // 0xace65c: ldur            x0, [fp, #-8]
    // 0xace660: stur            x1, [fp, #-0x10]
    // 0xace664: StoreField: r1->field_f = r0
    //     0xace664: stur            w0, [x1, #0xf]
    // 0xace668: ldr             x16, [fp, #0x10]
    // 0xace66c: SaveReg r16
    //     0xace66c: str             x16, [SP, #-8]!
    // 0xace670: r0 = unitToString()
    //     0xace670: bl              #0xace6c4  ; [package:csslib/visitor.dart] UnitTerm::unitToString
    // 0xace674: add             SP, SP, #8
    // 0xace678: ldur            x1, [fp, #-0x10]
    // 0xace67c: ArrayStore: r1[1] = r0  ; List_4
    //     0xace67c: add             x25, x1, #0x13
    //     0xace680: str             w0, [x25]
    //     0xace684: tbz             w0, #0, #0xace6a0
    //     0xace688: ldurb           w16, [x1, #-1]
    //     0xace68c: ldurb           w17, [x0, #-1]
    //     0xace690: and             x16, x17, x16, lsr #2
    //     0xace694: tst             x16, HEAP, lsr #32
    //     0xace698: b.eq            #0xace6a0
    //     0xace69c: bl              #0xd67e5c
    // 0xace6a0: ldur            x16, [fp, #-0x10]
    // 0xace6a4: SaveReg r16
    //     0xace6a4: str             x16, [SP, #-8]!
    // 0xace6a8: r0 = _interpolate()
    //     0xace6a8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xace6ac: add             SP, SP, #8
    // 0xace6b0: LeaveFrame
    //     0xace6b0: mov             SP, fp
    //     0xace6b4: ldp             fp, lr, [SP], #0x10
    // 0xace6b8: ret
    //     0xace6b8: ret             
    // 0xace6bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xace6bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xace6c0: b               #0xace63c
  }
  _ unitToString(/* No info */) {
    // ** addr: 0xace6c4, size: 0x3c
    // 0xace6c4: EnterFrame
    //     0xace6c4: stp             fp, lr, [SP, #-0x10]!
    //     0xace6c8: mov             fp, SP
    // 0xace6cc: CheckStackOverflow
    //     0xace6cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xace6d0: cmp             SP, x16
    //     0xace6d4: b.ls            #0xace6f8
    // 0xace6d8: ldr             x0, [fp, #0x10]
    // 0xace6dc: LoadField: r1 = r0->field_13
    //     0xace6dc: ldur            x1, [x0, #0x13]
    // 0xace6e0: SaveReg r1
    //     0xace6e0: str             x1, [SP, #-8]!
    // 0xace6e4: r0 = unitToString()
    //     0xace6e4: bl              #0xace700  ; [package:csslib/parser.dart] TokenKind::unitToString
    // 0xace6e8: add             SP, SP, #8
    // 0xace6ec: LeaveFrame
    //     0xace6ec: mov             SP, fp
    //     0xace6f0: ldp             fp, lr, [SP], #0x10
    // 0xace6f4: ret
    //     0xace6f4: ret             
    // 0xace6f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xace6f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xace6fc: b               #0xace6d8
  }
}

// class id: 4717, size: 0x1c, field offset: 0x1c
class ViewportTerm extends UnitTerm {
}

// class id: 4718, size: 0x1c, field offset: 0x1c
class LineHeightTerm extends UnitTerm {
}

// class id: 4719, size: 0x1c, field offset: 0x1c
class RemTerm extends UnitTerm {
}

// class id: 4720, size: 0x1c, field offset: 0x1c
class ChTerm extends UnitTerm {
}

// class id: 4721, size: 0x1c, field offset: 0x1c
class ResolutionTerm extends UnitTerm {
}

// class id: 4722, size: 0x1c, field offset: 0x1c
class FreqTerm extends UnitTerm {
}

// class id: 4723, size: 0x1c, field offset: 0x1c
class TimeTerm extends UnitTerm {
}

// class id: 4724, size: 0x1c, field offset: 0x1c
class AngleTerm extends UnitTerm {
}

// class id: 4725, size: 0x1c, field offset: 0x1c
class LengthTerm extends UnitTerm {
}

// class id: 4726, size: 0x14, field offset: 0x14
class NumberTerm extends LiteralTerm {
}

// class id: 4727, size: 0x14, field offset: 0x14
class ItemTerm extends NumberTerm {
}

// class id: 4728, size: 0x18, field offset: 0x14
class CalcTerm extends LiteralTerm {

  _ toString(/* No info */) {
    // ** addr: 0xace5a4, size: 0x80
    // 0xace5a4: EnterFrame
    //     0xace5a4: stp             fp, lr, [SP, #-0x10]!
    //     0xace5a8: mov             fp, SP
    // 0xace5ac: AllocStack(0x8)
    //     0xace5ac: sub             SP, SP, #8
    // 0xace5b0: CheckStackOverflow
    //     0xace5b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xace5b4: cmp             SP, x16
    //     0xace5b8: b.ls            #0xace61c
    // 0xace5bc: ldr             x0, [fp, #0x10]
    // 0xace5c0: LoadField: r3 = r0->field_f
    //     0xace5c0: ldur            w3, [x0, #0xf]
    // 0xace5c4: DecompressPointer r3
    //     0xace5c4: add             x3, x3, HEAP, lsl #32
    // 0xace5c8: stur            x3, [fp, #-8]
    // 0xace5cc: r1 = Null
    //     0xace5cc: mov             x1, NULL
    // 0xace5d0: r2 = 8
    //     0xace5d0: mov             x2, #8
    // 0xace5d4: r0 = AllocateArray()
    //     0xace5d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xace5d8: mov             x1, x0
    // 0xace5dc: ldur            x0, [fp, #-8]
    // 0xace5e0: StoreField: r1->field_f = r0
    //     0xace5e0: stur            w0, [x1, #0xf]
    // 0xace5e4: r17 = "("
    //     0xace5e4: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xace5e8: StoreField: r1->field_13 = r17
    //     0xace5e8: stur            w17, [x1, #0x13]
    // 0xace5ec: ldr             x0, [fp, #0x10]
    // 0xace5f0: LoadField: r2 = r0->field_13
    //     0xace5f0: ldur            w2, [x0, #0x13]
    // 0xace5f4: DecompressPointer r2
    //     0xace5f4: add             x2, x2, HEAP, lsl #32
    // 0xace5f8: StoreField: r1->field_17 = r2
    //     0xace5f8: stur            w2, [x1, #0x17]
    // 0xace5fc: r17 = ")"
    //     0xace5fc: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xace600: StoreField: r1->field_1b = r17
    //     0xace600: stur            w17, [x1, #0x1b]
    // 0xace604: SaveReg r1
    //     0xace604: str             x1, [SP, #-8]!
    // 0xace608: r0 = _interpolate()
    //     0xace608: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xace60c: add             SP, SP, #8
    // 0xace610: LeaveFrame
    //     0xace610: mov             SP, fp
    //     0xace614: ldp             fp, lr, [SP], #0x10
    // 0xace618: ret
    //     0xace618: ret             
    // 0xace61c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xace61c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xace620: b               #0xace5bc
  }
  _ visit(/* No info */) {
    // ** addr: 0xbfa7e4, size: 0x40
    // 0xbfa7e4: EnterFrame
    //     0xbfa7e4: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa7e8: mov             fp, SP
    // 0xbfa7ec: CheckStackOverflow
    //     0xbfa7ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfa7f0: cmp             SP, x16
    //     0xbfa7f4: b.ls            #0xbfa81c
    // 0xbfa7f8: ldr             x16, [fp, #0x10]
    // 0xbfa7fc: ldr             lr, [fp, #0x18]
    // 0xbfa800: stp             lr, x16, [SP, #-0x10]!
    // 0xbfa804: r0 = Shader._()
    //     0xbfa804: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0xbfa808: add             SP, SP, #0x10
    // 0xbfa80c: r0 = Null
    //     0xbfa80c: mov             x0, NULL
    // 0xbfa810: LeaveFrame
    //     0xbfa810: mov             SP, fp
    //     0xbfa814: ldp             fp, lr, [SP], #0x10
    // 0xbfa818: ret
    //     0xbfa818: ret             
    // 0xbfa81c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa81c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa820: b               #0xbfa7f8
  }
}

// class id: 4729, size: 0xc, field offset: 0xc
class Negation extends TreeNode {

  String name(Negation) {
    // ** addr: 0x7e015c, size: 0x24
    // 0x7e015c: r0 = "not"
    //     0x7e015c: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2b418] "not"
    //     0x7e0160: ldr             x0, [x0, #0x418]
    // 0x7e0164: ret
    //     0x7e0164: ret             
  }
}

// class id: 4730, size: 0xc, field offset: 0xc
class ThisOperator extends TreeNode {

  String name(ThisOperator) {
    // ** addr: 0x7e08ec, size: 0x24
    // 0x7e08ec: r0 = "&"
    //     0x7e08ec: add             x0, PP, #0xa, lsl #12  ; [pp+0xaac0] "&"
    //     0x7e08f0: ldr             x0, [x0, #0xac0]
    // 0x7e08f4: ret
    //     0x7e08f4: ret             
  }
}

// class id: 4731, size: 0xc, field offset: 0xc
class Wildcard extends TreeNode {

  String name(Wildcard) {
    // ** addr: 0x7e07fc, size: 0x20
    // 0x7e07fc: r0 = "*"
    //     0x7e07fc: ldr             x0, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0x7e0800: ret
    //     0x7e0800: ret             
  }
}

// class id: 4732, size: 0x10, field offset: 0xc
class Identifier extends TreeNode {

  String name(Identifier) {
    // ** addr: 0x9bbf34, size: 0x28
    // 0x9bbf34: ldr             x1, [SP]
    // 0x9bbf38: LoadField: r0 = r1->field_b
    //     0x9bbf38: ldur            w0, [x1, #0xb]
    // 0x9bbf3c: DecompressPointer r0
    //     0x9bbf3c: add             x0, x0, HEAP, lsl #32
    // 0x9bbf40: ret
    //     0x9bbf40: ret             
  }
  String toString(Identifier) {
    // ** addr: 0xace564, size: 0x40
    // 0xace564: EnterFrame
    //     0xace564: stp             fp, lr, [SP, #-0x10]!
    //     0xace568: mov             fp, SP
    // 0xace56c: CheckStackOverflow
    //     0xace56c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xace570: cmp             SP, x16
    //     0xace574: b.ls            #0xace59c
    // 0xace578: ldr             x0, [fp, #0x10]
    // 0xace57c: LoadField: r1 = r0->field_7
    //     0xace57c: ldur            w1, [x0, #7]
    // 0xace580: DecompressPointer r1
    //     0xace580: add             x1, x1, HEAP, lsl #32
    // 0xace584: SaveReg r1
    //     0xace584: str             x1, [SP, #-8]!
    // 0xace588: r0 = text()
    //     0xace588: bl              #0xd613d8  ; [package:source_span/src/file.dart] _FileSpan::text
    // 0xace58c: add             SP, SP, #8
    // 0xace590: LeaveFrame
    //     0xace590: mov             SP, fp
    //     0xace594: ldp             fp, lr, [SP], #0x10
    // 0xace598: ret
    //     0xace598: ret             
    // 0xace59c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xace59c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xace5a0: b               #0xace578
  }
}

// class id: 4733, size: 0x8, field offset: 0x8
abstract class Visitor extends Object
    implements VisitorBase {

  _ visitFunctionTerm(/* No info */) {
    // ** addr: 0xbfa864, size: 0x48
    // 0xbfa864: EnterFrame
    //     0xbfa864: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa868: mov             fp, SP
    // 0xbfa86c: CheckStackOverflow
    //     0xbfa86c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfa870: cmp             SP, x16
    //     0xbfa874: b.ls            #0xbfa8a4
    // 0xbfa878: ldr             x0, [fp, #0x10]
    // 0xbfa87c: LoadField: r1 = r0->field_13
    //     0xbfa87c: ldur            w1, [x0, #0x13]
    // 0xbfa880: DecompressPointer r1
    //     0xbfa880: add             x1, x1, HEAP, lsl #32
    // 0xbfa884: ldr             x16, [fp, #0x18]
    // 0xbfa888: stp             x1, x16, [SP, #-0x10]!
    // 0xbfa88c: r0 = visitExpressions()
    //     0xbfa88c: bl              #0xbfa8ac  ; [package:flutter_html/src/css_parser.dart] DeclarationVisitor::visitExpressions
    // 0xbfa890: add             SP, SP, #0x10
    // 0xbfa894: r0 = Null
    //     0xbfa894: mov             x0, NULL
    // 0xbfa898: LeaveFrame
    //     0xbfa898: mov             SP, fp
    //     0xbfa89c: ldp             fp, lr, [SP], #0x10
    // 0xbfa8a0: ret
    //     0xbfa8a0: ret             
    // 0xbfa8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa8a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa8a8: b               #0xbfa878
  }
  _ visitKeyFrameBlock(/* No info */) {
    // ** addr: 0xbfaa2c, size: 0x64
    // 0xbfaa2c: EnterFrame
    //     0xbfaa2c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfaa30: mov             fp, SP
    // 0xbfaa34: CheckStackOverflow
    //     0xbfaa34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfaa38: cmp             SP, x16
    //     0xbfaa3c: b.ls            #0xbfaa88
    // 0xbfaa40: ldr             x0, [fp, #0x10]
    // 0xbfaa44: LoadField: r1 = r0->field_b
    //     0xbfaa44: ldur            w1, [x0, #0xb]
    // 0xbfaa48: DecompressPointer r1
    //     0xbfaa48: add             x1, x1, HEAP, lsl #32
    // 0xbfaa4c: ldr             x16, [fp, #0x18]
    // 0xbfaa50: stp             x1, x16, [SP, #-0x10]!
    // 0xbfaa54: r0 = visitExpressions()
    //     0xbfaa54: bl              #0xbfa8ac  ; [package:flutter_html/src/css_parser.dart] DeclarationVisitor::visitExpressions
    // 0xbfaa58: add             SP, SP, #0x10
    // 0xbfaa5c: ldr             x0, [fp, #0x10]
    // 0xbfaa60: LoadField: r1 = r0->field_f
    //     0xbfaa60: ldur            w1, [x0, #0xf]
    // 0xbfaa64: DecompressPointer r1
    //     0xbfaa64: add             x1, x1, HEAP, lsl #32
    // 0xbfaa68: ldr             x16, [fp, #0x18]
    // 0xbfaa6c: stp             x1, x16, [SP, #-0x10]!
    // 0xbfaa70: r0 = visitStyleSheet()
    //     0xbfaa70: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfaa74: add             SP, SP, #0x10
    // 0xbfaa78: r0 = Null
    //     0xbfaa78: mov             x0, NULL
    // 0xbfaa7c: LeaveFrame
    //     0xbfaa7c: mov             SP, fp
    //     0xbfaa80: ldp             fp, lr, [SP], #0x10
    // 0xbfaa84: ret
    //     0xbfaa84: ret             
    // 0xbfaa88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfaa88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfaa8c: b               #0xbfaa40
  }
  _ visitStyleSheet(/* No info */) {
    // ** addr: 0xbfaa90, size: 0x48
    // 0xbfaa90: EnterFrame
    //     0xbfaa90: stp             fp, lr, [SP, #-0x10]!
    //     0xbfaa94: mov             fp, SP
    // 0xbfaa98: CheckStackOverflow
    //     0xbfaa98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfaa9c: cmp             SP, x16
    //     0xbfaaa0: b.ls            #0xbfaad0
    // 0xbfaaa4: ldr             x0, [fp, #0x10]
    // 0xbfaaa8: LoadField: r1 = r0->field_b
    //     0xbfaaa8: ldur            w1, [x0, #0xb]
    // 0xbfaaac: DecompressPointer r1
    //     0xbfaaac: add             x1, x1, HEAP, lsl #32
    // 0xbfaab0: ldr             x16, [fp, #0x18]
    // 0xbfaab4: stp             x1, x16, [SP, #-0x10]!
    // 0xbfaab8: r0 = _visitNodeList()
    //     0xbfaab8: bl              #0xbfaad8  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xbfaabc: add             SP, SP, #0x10
    // 0xbfaac0: r0 = Null
    //     0xbfaac0: mov             x0, NULL
    // 0xbfaac4: LeaveFrame
    //     0xbfaac4: mov             SP, fp
    //     0xbfaac8: ldp             fp, lr, [SP], #0x10
    // 0xbfaacc: ret
    //     0xbfaacc: ret             
    // 0xbfaad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfaad0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfaad4: b               #0xbfaaa4
  }
  _ _visitNodeList(/* No info */) {
    // ** addr: 0xbfaad8, size: 0xf0
    // 0xbfaad8: EnterFrame
    //     0xbfaad8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfaadc: mov             fp, SP
    // 0xbfaae0: AllocStack(0x8)
    //     0xbfaae0: sub             SP, SP, #8
    // 0xbfaae4: CheckStackOverflow
    //     0xbfaae4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfaae8: cmp             SP, x16
    //     0xbfaaec: b.ls            #0xbfabb8
    // 0xbfaaf0: r2 = 0
    //     0xbfaaf0: mov             x2, #0
    // 0xbfaaf4: ldr             x1, [fp, #0x10]
    // 0xbfaaf8: stur            x2, [fp, #-8]
    // 0xbfaafc: CheckStackOverflow
    //     0xbfaafc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfab00: cmp             SP, x16
    //     0xbfab04: b.ls            #0xbfabc0
    // 0xbfab08: r0 = LoadClassIdInstr(r1)
    //     0xbfab08: ldur            x0, [x1, #-1]
    //     0xbfab0c: ubfx            x0, x0, #0xc, #0x14
    // 0xbfab10: SaveReg r1
    //     0xbfab10: str             x1, [SP, #-8]!
    // 0xbfab14: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xbfab14: mov             x17, #0xb8ea
    //     0xbfab18: add             lr, x0, x17
    //     0xbfab1c: ldr             lr, [x21, lr, lsl #3]
    //     0xbfab20: blr             lr
    // 0xbfab24: add             SP, SP, #8
    // 0xbfab28: r1 = LoadInt32Instr(r0)
    //     0xbfab28: sbfx            x1, x0, #1, #0x1f
    //     0xbfab2c: tbz             w0, #0, #0xbfab34
    //     0xbfab30: ldur            x1, [x0, #7]
    // 0xbfab34: ldur            x2, [fp, #-8]
    // 0xbfab38: cmp             x2, x1
    // 0xbfab3c: b.ge            #0xbfaba8
    // 0xbfab40: ldr             x3, [fp, #0x10]
    // 0xbfab44: r0 = BoxInt64Instr(r2)
    //     0xbfab44: sbfiz           x0, x2, #1, #0x1f
    //     0xbfab48: cmp             x2, x0, asr #1
    //     0xbfab4c: b.eq            #0xbfab58
    //     0xbfab50: bl              #0xd69bb8
    //     0xbfab54: stur            x2, [x0, #7]
    // 0xbfab58: r1 = LoadClassIdInstr(r3)
    //     0xbfab58: ldur            x1, [x3, #-1]
    //     0xbfab5c: ubfx            x1, x1, #0xc, #0x14
    // 0xbfab60: stp             x0, x3, [SP, #-0x10]!
    // 0xbfab64: mov             x0, x1
    // 0xbfab68: r0 = GDT[cid_x0 + -0xd83]()
    //     0xbfab68: sub             lr, x0, #0xd83
    //     0xbfab6c: ldr             lr, [x21, lr, lsl #3]
    //     0xbfab70: blr             lr
    // 0xbfab74: add             SP, SP, #0x10
    // 0xbfab78: r1 = LoadClassIdInstr(r0)
    //     0xbfab78: ldur            x1, [x0, #-1]
    //     0xbfab7c: ubfx            x1, x1, #0xc, #0x14
    // 0xbfab80: ldr             x16, [fp, #0x18]
    // 0xbfab84: stp             x16, x0, [SP, #-0x10]!
    // 0xbfab88: mov             x0, x1
    // 0xbfab8c: r0 = GDT[cid_x0 + 0xdc8]()
    //     0xbfab8c: add             lr, x0, #0xdc8
    //     0xbfab90: ldr             lr, [x21, lr, lsl #3]
    //     0xbfab94: blr             lr
    // 0xbfab98: add             SP, SP, #0x10
    // 0xbfab9c: ldur            x1, [fp, #-8]
    // 0xbfaba0: add             x2, x1, #1
    // 0xbfaba4: b               #0xbfaaf4
    // 0xbfaba8: r0 = Null
    //     0xbfaba8: mov             x0, NULL
    // 0xbfabac: LeaveFrame
    //     0xbfabac: mov             SP, fp
    //     0xbfabb0: ldp             fp, lr, [SP], #0x10
    // 0xbfabb4: ret
    //     0xbfabb4: ret             
    // 0xbfabb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfabb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfabbc: b               #0xbfaaf0
    // 0xbfabc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfabc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfabc4: b               #0xbfab08
  }
  _ visitGroupTerm(/* No info */) {
    // ** addr: 0xbfac48, size: 0x198
    // 0xbfac48: EnterFrame
    //     0xbfac48: stp             fp, lr, [SP, #-0x10]!
    //     0xbfac4c: mov             fp, SP
    // 0xbfac50: AllocStack(0x30)
    //     0xbfac50: sub             SP, SP, #0x30
    // 0xbfac54: CheckStackOverflow
    //     0xbfac54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfac58: cmp             SP, x16
    //     0xbfac5c: b.ls            #0xbfadd0
    // 0xbfac60: ldr             x0, [fp, #0x10]
    // 0xbfac64: LoadField: r1 = r0->field_b
    //     0xbfac64: ldur            w1, [x0, #0xb]
    // 0xbfac68: DecompressPointer r1
    //     0xbfac68: add             x1, x1, HEAP, lsl #32
    // 0xbfac6c: stur            x1, [fp, #-0x20]
    // 0xbfac70: LoadField: r2 = r1->field_7
    //     0xbfac70: ldur            w2, [x1, #7]
    // 0xbfac74: DecompressPointer r2
    //     0xbfac74: add             x2, x2, HEAP, lsl #32
    // 0xbfac78: stur            x2, [fp, #-0x18]
    // 0xbfac7c: LoadField: r0 = r1->field_b
    //     0xbfac7c: ldur            w0, [x1, #0xb]
    // 0xbfac80: DecompressPointer r0
    //     0xbfac80: add             x0, x0, HEAP, lsl #32
    // 0xbfac84: r3 = LoadInt32Instr(r0)
    //     0xbfac84: sbfx            x3, x0, #1, #0x1f
    // 0xbfac88: stur            x3, [fp, #-0x10]
    // 0xbfac8c: r4 = 0
    //     0xbfac8c: mov             x4, #0
    // 0xbfac90: stur            x4, [fp, #-8]
    // 0xbfac94: CheckStackOverflow
    //     0xbfac94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfac98: cmp             SP, x16
    //     0xbfac9c: b.ls            #0xbfadd8
    // 0xbfaca0: r0 = LoadClassIdInstr(r1)
    //     0xbfaca0: ldur            x0, [x1, #-1]
    //     0xbfaca4: ubfx            x0, x0, #0xc, #0x14
    // 0xbfaca8: SaveReg r1
    //     0xbfaca8: str             x1, [SP, #-8]!
    // 0xbfacac: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xbfacac: mov             x17, #0xb8ea
    //     0xbfacb0: add             lr, x0, x17
    //     0xbfacb4: ldr             lr, [x21, lr, lsl #3]
    //     0xbfacb8: blr             lr
    // 0xbfacbc: add             SP, SP, #8
    // 0xbfacc0: r1 = LoadInt32Instr(r0)
    //     0xbfacc0: sbfx            x1, x0, #1, #0x1f
    //     0xbfacc4: tbz             w0, #0, #0xbfaccc
    //     0xbfacc8: ldur            x1, [x0, #7]
    // 0xbfaccc: ldur            x2, [fp, #-0x10]
    // 0xbfacd0: cmp             x2, x1
    // 0xbfacd4: b.ne            #0xbfadb8
    // 0xbfacd8: ldur            x3, [fp, #-0x20]
    // 0xbfacdc: ldur            x4, [fp, #-8]
    // 0xbface0: cmp             x4, x1
    // 0xbface4: b.lt            #0xbfacf8
    // 0xbface8: r0 = Null
    //     0xbface8: mov             x0, NULL
    // 0xbfacec: LeaveFrame
    //     0xbfacec: mov             SP, fp
    //     0xbfacf0: ldp             fp, lr, [SP], #0x10
    // 0xbfacf4: ret
    //     0xbfacf4: ret             
    // 0xbfacf8: r0 = BoxInt64Instr(r4)
    //     0xbfacf8: sbfiz           x0, x4, #1, #0x1f
    //     0xbfacfc: cmp             x4, x0, asr #1
    //     0xbfad00: b.eq            #0xbfad0c
    //     0xbfad04: bl              #0xd69bb8
    //     0xbfad08: stur            x4, [x0, #7]
    // 0xbfad0c: r1 = LoadClassIdInstr(r3)
    //     0xbfad0c: ldur            x1, [x3, #-1]
    //     0xbfad10: ubfx            x1, x1, #0xc, #0x14
    // 0xbfad14: stp             x0, x3, [SP, #-0x10]!
    // 0xbfad18: mov             x0, x1
    // 0xbfad1c: r0 = GDT[cid_x0 + 0xd175]()
    //     0xbfad1c: mov             x17, #0xd175
    //     0xbfad20: add             lr, x0, x17
    //     0xbfad24: ldr             lr, [x21, lr, lsl #3]
    //     0xbfad28: blr             lr
    // 0xbfad2c: add             SP, SP, #0x10
    // 0xbfad30: mov             x3, x0
    // 0xbfad34: ldur            x0, [fp, #-8]
    // 0xbfad38: stur            x3, [fp, #-0x30]
    // 0xbfad3c: add             x4, x0, #1
    // 0xbfad40: stur            x4, [fp, #-0x28]
    // 0xbfad44: cmp             w3, NULL
    // 0xbfad48: b.ne            #0xbfad7c
    // 0xbfad4c: mov             x0, x3
    // 0xbfad50: ldur            x2, [fp, #-0x18]
    // 0xbfad54: r1 = Null
    //     0xbfad54: mov             x1, NULL
    // 0xbfad58: cmp             w2, NULL
    // 0xbfad5c: b.eq            #0xbfad7c
    // 0xbfad60: LoadField: r4 = r2->field_17
    //     0xbfad60: ldur            w4, [x2, #0x17]
    // 0xbfad64: DecompressPointer r4
    //     0xbfad64: add             x4, x4, HEAP, lsl #32
    // 0xbfad68: r8 = X0
    //     0xbfad68: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbfad6c: LoadField: r9 = r4->field_7
    //     0xbfad6c: ldur            x9, [x4, #7]
    // 0xbfad70: r3 = Null
    //     0xbfad70: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c9b0] Null
    //     0xbfad74: ldr             x3, [x3, #0x9b0]
    // 0xbfad78: blr             x9
    // 0xbfad7c: ldur            x0, [fp, #-0x30]
    // 0xbfad80: r1 = LoadClassIdInstr(r0)
    //     0xbfad80: ldur            x1, [x0, #-1]
    //     0xbfad84: ubfx            x1, x1, #0xc, #0x14
    // 0xbfad88: ldr             x16, [fp, #0x18]
    // 0xbfad8c: stp             x16, x0, [SP, #-0x10]!
    // 0xbfad90: mov             x0, x1
    // 0xbfad94: r0 = GDT[cid_x0 + 0xdc8]()
    //     0xbfad94: add             lr, x0, #0xdc8
    //     0xbfad98: ldr             lr, [x21, lr, lsl #3]
    //     0xbfad9c: blr             lr
    // 0xbfada0: add             SP, SP, #0x10
    // 0xbfada4: ldur            x4, [fp, #-0x28]
    // 0xbfada8: ldur            x1, [fp, #-0x20]
    // 0xbfadac: ldur            x2, [fp, #-0x18]
    // 0xbfadb0: ldur            x3, [fp, #-0x10]
    // 0xbfadb4: b               #0xbfac90
    // 0xbfadb8: ldur            x0, [fp, #-0x20]
    // 0xbfadbc: r0 = ConcurrentModificationError()
    //     0xbfadbc: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbfadc0: ldur            x3, [fp, #-0x20]
    // 0xbfadc4: StoreField: r0->field_b = r3
    //     0xbfadc4: stur            w3, [x0, #0xb]
    // 0xbfadc8: r0 = Throw()
    //     0xbfadc8: bl              #0xd67e38  ; ThrowStub
    // 0xbfadcc: brk             #0
    // 0xbfadd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfadd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfadd4: b               #0xbfac60
    // 0xbfadd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfadd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfaddc: b               #0xbfaca0
  }
  _ visitSimpleSelectorSequence(/* No info */) {
    // ** addr: 0xbfaee0, size: 0x58
    // 0xbfaee0: EnterFrame
    //     0xbfaee0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfaee4: mov             fp, SP
    // 0xbfaee8: CheckStackOverflow
    //     0xbfaee8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfaeec: cmp             SP, x16
    //     0xbfaef0: b.ls            #0xbfaf30
    // 0xbfaef4: ldr             x0, [fp, #0x10]
    // 0xbfaef8: LoadField: r1 = r0->field_13
    //     0xbfaef8: ldur            w1, [x0, #0x13]
    // 0xbfaefc: DecompressPointer r1
    //     0xbfaefc: add             x1, x1, HEAP, lsl #32
    // 0xbfaf00: r0 = LoadClassIdInstr(r1)
    //     0xbfaf00: ldur            x0, [x1, #-1]
    //     0xbfaf04: ubfx            x0, x0, #0xc, #0x14
    // 0xbfaf08: ldr             x16, [fp, #0x18]
    // 0xbfaf0c: stp             x16, x1, [SP, #-0x10]!
    // 0xbfaf10: r0 = GDT[cid_x0 + 0xdc8]()
    //     0xbfaf10: add             lr, x0, #0xdc8
    //     0xbfaf14: ldr             lr, [x21, lr, lsl #3]
    //     0xbfaf18: blr             lr
    // 0xbfaf1c: add             SP, SP, #0x10
    // 0xbfaf20: r0 = Null
    //     0xbfaf20: mov             x0, NULL
    // 0xbfaf24: LeaveFrame
    //     0xbfaf24: mov             SP, fp
    //     0xbfaf28: ldp             fp, lr, [SP], #0x10
    // 0xbfaf2c: ret
    //     0xbfaf2c: ret             
    // 0xbfaf30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfaf30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfaf34: b               #0xbfaef4
  }
  _ visitRuleSet(/* No info */) {
    // ** addr: 0xbfb318, size: 0x64
    // 0xbfb318: EnterFrame
    //     0xbfb318: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb31c: mov             fp, SP
    // 0xbfb320: CheckStackOverflow
    //     0xbfb320: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb324: cmp             SP, x16
    //     0xbfb328: b.ls            #0xbfb374
    // 0xbfb32c: ldr             x0, [fp, #0x10]
    // 0xbfb330: LoadField: r1 = r0->field_b
    //     0xbfb330: ldur            w1, [x0, #0xb]
    // 0xbfb334: DecompressPointer r1
    //     0xbfb334: add             x1, x1, HEAP, lsl #32
    // 0xbfb338: ldr             x16, [fp, #0x18]
    // 0xbfb33c: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb340: r0 = visitStyleSheet()
    //     0xbfb340: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfb344: add             SP, SP, #0x10
    // 0xbfb348: ldr             x0, [fp, #0x10]
    // 0xbfb34c: LoadField: r1 = r0->field_f
    //     0xbfb34c: ldur            w1, [x0, #0xf]
    // 0xbfb350: DecompressPointer r1
    //     0xbfb350: add             x1, x1, HEAP, lsl #32
    // 0xbfb354: ldr             x16, [fp, #0x18]
    // 0xbfb358: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb35c: r0 = visitStyleSheet()
    //     0xbfb35c: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfb360: add             SP, SP, #0x10
    // 0xbfb364: r0 = Null
    //     0xbfb364: mov             x0, NULL
    // 0xbfb368: LeaveFrame
    //     0xbfb368: mov             SP, fp
    //     0xbfb36c: ldp             fp, lr, [SP], #0x10
    // 0xbfb370: ret
    //     0xbfb370: ret             
    // 0xbfb374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb378: b               #0xbfb32c
  }
  _ visitDocumentDirective(/* No info */) {
    // ** addr: 0xbfb3bc, size: 0x64
    // 0xbfb3bc: EnterFrame
    //     0xbfb3bc: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb3c0: mov             fp, SP
    // 0xbfb3c4: CheckStackOverflow
    //     0xbfb3c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb3c8: cmp             SP, x16
    //     0xbfb3cc: b.ls            #0xbfb418
    // 0xbfb3d0: ldr             x0, [fp, #0x10]
    // 0xbfb3d4: LoadField: r1 = r0->field_b
    //     0xbfb3d4: ldur            w1, [x0, #0xb]
    // 0xbfb3d8: DecompressPointer r1
    //     0xbfb3d8: add             x1, x1, HEAP, lsl #32
    // 0xbfb3dc: ldr             x16, [fp, #0x18]
    // 0xbfb3e0: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb3e4: r0 = _visitNodeList()
    //     0xbfb3e4: bl              #0xbfaad8  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xbfb3e8: add             SP, SP, #0x10
    // 0xbfb3ec: ldr             x0, [fp, #0x10]
    // 0xbfb3f0: LoadField: r1 = r0->field_f
    //     0xbfb3f0: ldur            w1, [x0, #0xf]
    // 0xbfb3f4: DecompressPointer r1
    //     0xbfb3f4: add             x1, x1, HEAP, lsl #32
    // 0xbfb3f8: ldr             x16, [fp, #0x18]
    // 0xbfb3fc: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb400: r0 = _visitNodeList()
    //     0xbfb400: bl              #0xbfaad8  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xbfb404: add             SP, SP, #0x10
    // 0xbfb408: r0 = Null
    //     0xbfb408: mov             x0, NULL
    // 0xbfb40c: LeaveFrame
    //     0xbfb40c: mov             SP, fp
    //     0xbfb410: ldp             fp, lr, [SP], #0x10
    // 0xbfb414: ret
    //     0xbfb414: ret             
    // 0xbfb418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb418: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb41c: b               #0xbfb3d0
  }
  _ visitSupportsDirective(/* No info */) {
    // ** addr: 0xbfb460, size: 0xdc
    // 0xbfb460: EnterFrame
    //     0xbfb460: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb464: mov             fp, SP
    // 0xbfb468: CheckStackOverflow
    //     0xbfb468: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb46c: cmp             SP, x16
    //     0xbfb470: b.ls            #0xbfb530
    // 0xbfb474: ldr             x0, [fp, #0x10]
    // 0xbfb478: LoadField: r1 = r0->field_b
    //     0xbfb478: ldur            w1, [x0, #0xb]
    // 0xbfb47c: DecompressPointer r1
    //     0xbfb47c: add             x1, x1, HEAP, lsl #32
    // 0xbfb480: cmp             w1, NULL
    // 0xbfb484: b.eq            #0xbfb538
    // 0xbfb488: r2 = LoadClassIdInstr(r1)
    //     0xbfb488: ldur            x2, [x1, #-1]
    //     0xbfb48c: ubfx            x2, x2, #0xc, #0x14
    // 0xbfb490: lsl             x2, x2, #1
    // 0xbfb494: r17 = 9314
    //     0xbfb494: mov             x17, #0x2462
    // 0xbfb498: cmp             w2, w17
    // 0xbfb49c: b.ne            #0xbfb4b4
    // 0xbfb4a0: ldr             x16, [fp, #0x18]
    // 0xbfb4a4: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb4a8: r0 = visitStyleSheet()
    //     0xbfb4a8: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfb4ac: add             SP, SP, #0x10
    // 0xbfb4b0: b               #0xbfb504
    // 0xbfb4b4: r17 = 9316
    //     0xbfb4b4: mov             x17, #0x2464
    // 0xbfb4b8: cmp             w2, w17
    // 0xbfb4bc: b.ne            #0xbfb4d4
    // 0xbfb4c0: ldr             x16, [fp, #0x18]
    // 0xbfb4c4: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb4c8: r0 = visitStyleSheet()
    //     0xbfb4c8: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfb4cc: add             SP, SP, #0x10
    // 0xbfb4d0: b               #0xbfb504
    // 0xbfb4d4: r17 = 9318
    //     0xbfb4d4: mov             x17, #0x2466
    // 0xbfb4d8: cmp             w2, w17
    // 0xbfb4dc: b.ne            #0xbfb4f4
    // 0xbfb4e0: ldr             x16, [fp, #0x18]
    // 0xbfb4e4: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb4e8: r0 = visitSupportsNegation()
    //     0xbfb4e8: bl              #0xbfb5a0  ; [package:csslib/visitor.dart] Visitor::visitSupportsNegation
    // 0xbfb4ec: add             SP, SP, #0x10
    // 0xbfb4f0: b               #0xbfb504
    // 0xbfb4f4: ldr             x16, [fp, #0x18]
    // 0xbfb4f8: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb4fc: r0 = visitSupportsConditionInParens()
    //     0xbfb4fc: bl              #0xbfb53c  ; [package:csslib/visitor.dart] Visitor::visitSupportsConditionInParens
    // 0xbfb500: add             SP, SP, #0x10
    // 0xbfb504: ldr             x0, [fp, #0x10]
    // 0xbfb508: LoadField: r1 = r0->field_f
    //     0xbfb508: ldur            w1, [x0, #0xf]
    // 0xbfb50c: DecompressPointer r1
    //     0xbfb50c: add             x1, x1, HEAP, lsl #32
    // 0xbfb510: ldr             x16, [fp, #0x18]
    // 0xbfb514: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb518: r0 = _visitNodeList()
    //     0xbfb518: bl              #0xbfaad8  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xbfb51c: add             SP, SP, #0x10
    // 0xbfb520: r0 = Null
    //     0xbfb520: mov             x0, NULL
    // 0xbfb524: LeaveFrame
    //     0xbfb524: mov             SP, fp
    //     0xbfb528: ldp             fp, lr, [SP], #0x10
    // 0xbfb52c: ret
    //     0xbfb52c: ret             
    // 0xbfb530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb530: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb534: b               #0xbfb474
    // 0xbfb538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfb538: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitSupportsConditionInParens(/* No info */) {
    // ** addr: 0xbfb53c, size: 0x64
    // 0xbfb53c: EnterFrame
    //     0xbfb53c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb540: mov             fp, SP
    // 0xbfb544: CheckStackOverflow
    //     0xbfb544: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb548: cmp             SP, x16
    //     0xbfb54c: b.ls            #0xbfb594
    // 0xbfb550: ldr             x0, [fp, #0x10]
    // 0xbfb554: LoadField: r1 = r0->field_b
    //     0xbfb554: ldur            w1, [x0, #0xb]
    // 0xbfb558: DecompressPointer r1
    //     0xbfb558: add             x1, x1, HEAP, lsl #32
    // 0xbfb55c: cmp             w1, NULL
    // 0xbfb560: b.eq            #0xbfb59c
    // 0xbfb564: r0 = LoadClassIdInstr(r1)
    //     0xbfb564: ldur            x0, [x1, #-1]
    //     0xbfb568: ubfx            x0, x0, #0xc, #0x14
    // 0xbfb56c: ldr             x16, [fp, #0x18]
    // 0xbfb570: stp             x16, x1, [SP, #-0x10]!
    // 0xbfb574: r0 = GDT[cid_x0 + 0xdc8]()
    //     0xbfb574: add             lr, x0, #0xdc8
    //     0xbfb578: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb57c: blr             lr
    // 0xbfb580: add             SP, SP, #0x10
    // 0xbfb584: r0 = Null
    //     0xbfb584: mov             x0, NULL
    // 0xbfb588: LeaveFrame
    //     0xbfb588: mov             SP, fp
    //     0xbfb58c: ldp             fp, lr, [SP], #0x10
    // 0xbfb590: ret
    //     0xbfb590: ret             
    // 0xbfb594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb594: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb598: b               #0xbfb550
    // 0xbfb59c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfb59c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitSupportsNegation(/* No info */) {
    // ** addr: 0xbfb5a0, size: 0x48
    // 0xbfb5a0: EnterFrame
    //     0xbfb5a0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb5a4: mov             fp, SP
    // 0xbfb5a8: CheckStackOverflow
    //     0xbfb5a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb5ac: cmp             SP, x16
    //     0xbfb5b0: b.ls            #0xbfb5e0
    // 0xbfb5b4: ldr             x0, [fp, #0x10]
    // 0xbfb5b8: LoadField: r1 = r0->field_b
    //     0xbfb5b8: ldur            w1, [x0, #0xb]
    // 0xbfb5bc: DecompressPointer r1
    //     0xbfb5bc: add             x1, x1, HEAP, lsl #32
    // 0xbfb5c0: ldr             x16, [fp, #0x18]
    // 0xbfb5c4: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb5c8: r0 = visitSupportsConditionInParens()
    //     0xbfb5c8: bl              #0xbfb53c  ; [package:csslib/visitor.dart] Visitor::visitSupportsConditionInParens
    // 0xbfb5cc: add             SP, SP, #0x10
    // 0xbfb5d0: r0 = Null
    //     0xbfb5d0: mov             x0, NULL
    // 0xbfb5d4: LeaveFrame
    //     0xbfb5d4: mov             SP, fp
    //     0xbfb5d8: ldp             fp, lr, [SP], #0x10
    // 0xbfb5dc: ret
    //     0xbfb5dc: ret             
    // 0xbfb5e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb5e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb5e4: b               #0xbfb5b4
  }
  _ visitViewportDirective(/* No info */) {
    // ** addr: 0xbfb628, size: 0x48
    // 0xbfb628: EnterFrame
    //     0xbfb628: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb62c: mov             fp, SP
    // 0xbfb630: CheckStackOverflow
    //     0xbfb630: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb634: cmp             SP, x16
    //     0xbfb638: b.ls            #0xbfb668
    // 0xbfb63c: ldr             x0, [fp, #0x10]
    // 0xbfb640: LoadField: r1 = r0->field_b
    //     0xbfb640: ldur            w1, [x0, #0xb]
    // 0xbfb644: DecompressPointer r1
    //     0xbfb644: add             x1, x1, HEAP, lsl #32
    // 0xbfb648: ldr             x16, [fp, #0x18]
    // 0xbfb64c: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb650: r0 = visitStyleSheet()
    //     0xbfb650: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfb654: add             SP, SP, #0x10
    // 0xbfb658: r0 = Null
    //     0xbfb658: mov             x0, NULL
    // 0xbfb65c: LeaveFrame
    //     0xbfb65c: mov             SP, fp
    //     0xbfb660: ldp             fp, lr, [SP], #0x10
    // 0xbfb664: ret
    //     0xbfb664: ret             
    // 0xbfb668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb66c: b               #0xbfb63c
  }
  _ visitImportDirective(/* No info */) {
    // ** addr: 0xbfb6b0, size: 0x2cc
    // 0xbfb6b0: EnterFrame
    //     0xbfb6b0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb6b4: mov             fp, SP
    // 0xbfb6b8: AllocStack(0x50)
    //     0xbfb6b8: sub             SP, SP, #0x50
    // 0xbfb6bc: CheckStackOverflow
    //     0xbfb6bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb6c0: cmp             SP, x16
    //     0xbfb6c4: b.ls            #0xbfb964
    // 0xbfb6c8: ldr             x0, [fp, #0x10]
    // 0xbfb6cc: LoadField: r1 = r0->field_b
    //     0xbfb6cc: ldur            w1, [x0, #0xb]
    // 0xbfb6d0: DecompressPointer r1
    //     0xbfb6d0: add             x1, x1, HEAP, lsl #32
    // 0xbfb6d4: stur            x1, [fp, #-0x20]
    // 0xbfb6d8: LoadField: r2 = r1->field_7
    //     0xbfb6d8: ldur            w2, [x1, #7]
    // 0xbfb6dc: DecompressPointer r2
    //     0xbfb6dc: add             x2, x2, HEAP, lsl #32
    // 0xbfb6e0: stur            x2, [fp, #-0x18]
    // 0xbfb6e4: LoadField: r0 = r1->field_b
    //     0xbfb6e4: ldur            w0, [x1, #0xb]
    // 0xbfb6e8: DecompressPointer r0
    //     0xbfb6e8: add             x0, x0, HEAP, lsl #32
    // 0xbfb6ec: r3 = LoadInt32Instr(r0)
    //     0xbfb6ec: sbfx            x3, x0, #1, #0x1f
    // 0xbfb6f0: stur            x3, [fp, #-0x10]
    // 0xbfb6f4: r4 = 0
    //     0xbfb6f4: mov             x4, #0
    // 0xbfb6f8: stur            x4, [fp, #-8]
    // 0xbfb6fc: CheckStackOverflow
    //     0xbfb6fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb700: cmp             SP, x16
    //     0xbfb704: b.ls            #0xbfb96c
    // 0xbfb708: r0 = LoadClassIdInstr(r1)
    //     0xbfb708: ldur            x0, [x1, #-1]
    //     0xbfb70c: ubfx            x0, x0, #0xc, #0x14
    // 0xbfb710: SaveReg r1
    //     0xbfb710: str             x1, [SP, #-8]!
    // 0xbfb714: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xbfb714: mov             x17, #0xb8ea
    //     0xbfb718: add             lr, x0, x17
    //     0xbfb71c: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb720: blr             lr
    // 0xbfb724: add             SP, SP, #8
    // 0xbfb728: r1 = LoadInt32Instr(r0)
    //     0xbfb728: sbfx            x1, x0, #1, #0x1f
    //     0xbfb72c: tbz             w0, #0, #0xbfb734
    //     0xbfb730: ldur            x1, [x0, #7]
    // 0xbfb734: ldur            x2, [fp, #-0x10]
    // 0xbfb738: cmp             x2, x1
    // 0xbfb73c: b.ne            #0xbfb934
    // 0xbfb740: ldur            x3, [fp, #-0x20]
    // 0xbfb744: ldur            x4, [fp, #-8]
    // 0xbfb748: cmp             x4, x1
    // 0xbfb74c: b.lt            #0xbfb760
    // 0xbfb750: r0 = Null
    //     0xbfb750: mov             x0, NULL
    // 0xbfb754: LeaveFrame
    //     0xbfb754: mov             SP, fp
    //     0xbfb758: ldp             fp, lr, [SP], #0x10
    // 0xbfb75c: ret
    //     0xbfb75c: ret             
    // 0xbfb760: r0 = BoxInt64Instr(r4)
    //     0xbfb760: sbfiz           x0, x4, #1, #0x1f
    //     0xbfb764: cmp             x4, x0, asr #1
    //     0xbfb768: b.eq            #0xbfb774
    //     0xbfb76c: bl              #0xd69bb8
    //     0xbfb770: stur            x4, [x0, #7]
    // 0xbfb774: r1 = LoadClassIdInstr(r3)
    //     0xbfb774: ldur            x1, [x3, #-1]
    //     0xbfb778: ubfx            x1, x1, #0xc, #0x14
    // 0xbfb77c: stp             x0, x3, [SP, #-0x10]!
    // 0xbfb780: mov             x0, x1
    // 0xbfb784: r0 = GDT[cid_x0 + 0xd175]()
    //     0xbfb784: mov             x17, #0xd175
    //     0xbfb788: add             lr, x0, x17
    //     0xbfb78c: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb790: blr             lr
    // 0xbfb794: add             SP, SP, #0x10
    // 0xbfb798: mov             x3, x0
    // 0xbfb79c: ldur            x0, [fp, #-8]
    // 0xbfb7a0: stur            x3, [fp, #-0x30]
    // 0xbfb7a4: add             x4, x0, #1
    // 0xbfb7a8: stur            x4, [fp, #-0x28]
    // 0xbfb7ac: cmp             w3, NULL
    // 0xbfb7b0: b.ne            #0xbfb7e4
    // 0xbfb7b4: mov             x0, x3
    // 0xbfb7b8: ldur            x2, [fp, #-0x18]
    // 0xbfb7bc: r1 = Null
    //     0xbfb7bc: mov             x1, NULL
    // 0xbfb7c0: cmp             w2, NULL
    // 0xbfb7c4: b.eq            #0xbfb7e4
    // 0xbfb7c8: LoadField: r4 = r2->field_17
    //     0xbfb7c8: ldur            w4, [x2, #0x17]
    // 0xbfb7cc: DecompressPointer r4
    //     0xbfb7cc: add             x4, x4, HEAP, lsl #32
    // 0xbfb7d0: r8 = X0
    //     0xbfb7d0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbfb7d4: LoadField: r9 = r4->field_7
    //     0xbfb7d4: ldur            x9, [x4, #7]
    // 0xbfb7d8: r3 = Null
    //     0xbfb7d8: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c9c0] Null
    //     0xbfb7dc: ldr             x3, [x3, #0x9c0]
    // 0xbfb7e0: blr             x9
    // 0xbfb7e4: ldur            x0, [fp, #-0x30]
    // 0xbfb7e8: LoadField: r1 = r0->field_b
    //     0xbfb7e8: ldur            w1, [x0, #0xb]
    // 0xbfb7ec: DecompressPointer r1
    //     0xbfb7ec: add             x1, x1, HEAP, lsl #32
    // 0xbfb7f0: stur            x1, [fp, #-0x40]
    // 0xbfb7f4: LoadField: r2 = r1->field_7
    //     0xbfb7f4: ldur            w2, [x1, #7]
    // 0xbfb7f8: DecompressPointer r2
    //     0xbfb7f8: add             x2, x2, HEAP, lsl #32
    // 0xbfb7fc: stur            x2, [fp, #-0x30]
    // 0xbfb800: LoadField: r0 = r1->field_b
    //     0xbfb800: ldur            w0, [x1, #0xb]
    // 0xbfb804: DecompressPointer r0
    //     0xbfb804: add             x0, x0, HEAP, lsl #32
    // 0xbfb808: r3 = LoadInt32Instr(r0)
    //     0xbfb808: sbfx            x3, x0, #1, #0x1f
    // 0xbfb80c: stur            x3, [fp, #-0x38]
    // 0xbfb810: r4 = 0
    //     0xbfb810: mov             x4, #0
    // 0xbfb814: stur            x4, [fp, #-8]
    // 0xbfb818: CheckStackOverflow
    //     0xbfb818: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb81c: cmp             SP, x16
    //     0xbfb820: b.ls            #0xbfb974
    // 0xbfb824: r0 = LoadClassIdInstr(r1)
    //     0xbfb824: ldur            x0, [x1, #-1]
    //     0xbfb828: ubfx            x0, x0, #0xc, #0x14
    // 0xbfb82c: SaveReg r1
    //     0xbfb82c: str             x1, [SP, #-8]!
    // 0xbfb830: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xbfb830: mov             x17, #0xb8ea
    //     0xbfb834: add             lr, x0, x17
    //     0xbfb838: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb83c: blr             lr
    // 0xbfb840: add             SP, SP, #8
    // 0xbfb844: r1 = LoadInt32Instr(r0)
    //     0xbfb844: sbfx            x1, x0, #1, #0x1f
    //     0xbfb848: tbz             w0, #0, #0xbfb850
    //     0xbfb84c: ldur            x1, [x0, #7]
    // 0xbfb850: ldur            x2, [fp, #-0x38]
    // 0xbfb854: cmp             x2, x1
    // 0xbfb858: b.ne            #0xbfb94c
    // 0xbfb85c: ldur            x3, [fp, #-0x40]
    // 0xbfb860: ldur            x4, [fp, #-8]
    // 0xbfb864: cmp             x4, x1
    // 0xbfb868: b.lt            #0xbfb880
    // 0xbfb86c: ldur            x4, [fp, #-0x28]
    // 0xbfb870: ldur            x1, [fp, #-0x20]
    // 0xbfb874: ldur            x2, [fp, #-0x18]
    // 0xbfb878: ldur            x3, [fp, #-0x10]
    // 0xbfb87c: b               #0xbfb6f8
    // 0xbfb880: r0 = BoxInt64Instr(r4)
    //     0xbfb880: sbfiz           x0, x4, #1, #0x1f
    //     0xbfb884: cmp             x4, x0, asr #1
    //     0xbfb888: b.eq            #0xbfb894
    //     0xbfb88c: bl              #0xd69bb8
    //     0xbfb890: stur            x4, [x0, #7]
    // 0xbfb894: r1 = LoadClassIdInstr(r3)
    //     0xbfb894: ldur            x1, [x3, #-1]
    //     0xbfb898: ubfx            x1, x1, #0xc, #0x14
    // 0xbfb89c: stp             x0, x3, [SP, #-0x10]!
    // 0xbfb8a0: mov             x0, x1
    // 0xbfb8a4: r0 = GDT[cid_x0 + 0xd175]()
    //     0xbfb8a4: mov             x17, #0xd175
    //     0xbfb8a8: add             lr, x0, x17
    //     0xbfb8ac: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb8b0: blr             lr
    // 0xbfb8b4: add             SP, SP, #0x10
    // 0xbfb8b8: mov             x3, x0
    // 0xbfb8bc: ldur            x0, [fp, #-8]
    // 0xbfb8c0: stur            x3, [fp, #-0x50]
    // 0xbfb8c4: add             x4, x0, #1
    // 0xbfb8c8: stur            x4, [fp, #-0x48]
    // 0xbfb8cc: cmp             w3, NULL
    // 0xbfb8d0: b.ne            #0xbfb904
    // 0xbfb8d4: mov             x0, x3
    // 0xbfb8d8: ldur            x2, [fp, #-0x30]
    // 0xbfb8dc: r1 = Null
    //     0xbfb8dc: mov             x1, NULL
    // 0xbfb8e0: cmp             w2, NULL
    // 0xbfb8e4: b.eq            #0xbfb904
    // 0xbfb8e8: LoadField: r4 = r2->field_17
    //     0xbfb8e8: ldur            w4, [x2, #0x17]
    // 0xbfb8ec: DecompressPointer r4
    //     0xbfb8ec: add             x4, x4, HEAP, lsl #32
    // 0xbfb8f0: r8 = X0
    //     0xbfb8f0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbfb8f4: LoadField: r9 = r4->field_7
    //     0xbfb8f4: ldur            x9, [x4, #7]
    // 0xbfb8f8: r3 = Null
    //     0xbfb8f8: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c9d0] Null
    //     0xbfb8fc: ldr             x3, [x3, #0x9d0]
    // 0xbfb900: blr             x9
    // 0xbfb904: ldur            x0, [fp, #-0x50]
    // 0xbfb908: LoadField: r1 = r0->field_b
    //     0xbfb908: ldur            w1, [x0, #0xb]
    // 0xbfb90c: DecompressPointer r1
    //     0xbfb90c: add             x1, x1, HEAP, lsl #32
    // 0xbfb910: ldr             x16, [fp, #0x18]
    // 0xbfb914: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb918: r0 = visitExpressions()
    //     0xbfb918: bl              #0xbfa8ac  ; [package:flutter_html/src/css_parser.dart] DeclarationVisitor::visitExpressions
    // 0xbfb91c: add             SP, SP, #0x10
    // 0xbfb920: ldur            x4, [fp, #-0x48]
    // 0xbfb924: ldur            x1, [fp, #-0x40]
    // 0xbfb928: ldur            x2, [fp, #-0x30]
    // 0xbfb92c: ldur            x3, [fp, #-0x38]
    // 0xbfb930: b               #0xbfb814
    // 0xbfb934: ldur            x0, [fp, #-0x20]
    // 0xbfb938: r0 = ConcurrentModificationError()
    //     0xbfb938: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbfb93c: ldur            x3, [fp, #-0x20]
    // 0xbfb940: StoreField: r0->field_b = r3
    //     0xbfb940: stur            w3, [x0, #0xb]
    // 0xbfb944: r0 = Throw()
    //     0xbfb944: bl              #0xd67e38  ; ThrowStub
    // 0xbfb948: brk             #0
    // 0xbfb94c: ldur            x0, [fp, #-0x40]
    // 0xbfb950: r0 = ConcurrentModificationError()
    //     0xbfb950: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbfb954: ldur            x3, [fp, #-0x40]
    // 0xbfb958: StoreField: r0->field_b = r3
    //     0xbfb958: stur            w3, [x0, #0xb]
    // 0xbfb95c: r0 = Throw()
    //     0xbfb95c: bl              #0xd67e38  ; ThrowStub
    // 0xbfb960: brk             #0
    // 0xbfb964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb964: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb968: b               #0xbfb6c8
    // 0xbfb96c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb96c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb970: b               #0xbfb708
    // 0xbfb974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb974: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb978: b               #0xbfb824
  }
  _ visitMediaExpression(/* No info */) {
    // ** addr: 0xbfb97c, size: 0x48
    // 0xbfb97c: EnterFrame
    //     0xbfb97c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb980: mov             fp, SP
    // 0xbfb984: CheckStackOverflow
    //     0xbfb984: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb988: cmp             SP, x16
    //     0xbfb98c: b.ls            #0xbfb9bc
    // 0xbfb990: ldr             x0, [fp, #0x10]
    // 0xbfb994: LoadField: r1 = r0->field_b
    //     0xbfb994: ldur            w1, [x0, #0xb]
    // 0xbfb998: DecompressPointer r1
    //     0xbfb998: add             x1, x1, HEAP, lsl #32
    // 0xbfb99c: ldr             x16, [fp, #0x18]
    // 0xbfb9a0: stp             x1, x16, [SP, #-0x10]!
    // 0xbfb9a4: r0 = visitExpressions()
    //     0xbfb9a4: bl              #0xbfa8ac  ; [package:flutter_html/src/css_parser.dart] DeclarationVisitor::visitExpressions
    // 0xbfb9a8: add             SP, SP, #0x10
    // 0xbfb9ac: r0 = Null
    //     0xbfb9ac: mov             x0, NULL
    // 0xbfb9b0: LeaveFrame
    //     0xbfb9b0: mov             SP, fp
    //     0xbfb9b4: ldp             fp, lr, [SP], #0x10
    // 0xbfb9b8: ret
    //     0xbfb9b8: ret             
    // 0xbfb9bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb9bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb9c0: b               #0xbfb990
  }
  _ visitMediaQuery(/* No info */) {
    // ** addr: 0xbfb9c4, size: 0x18c
    // 0xbfb9c4: EnterFrame
    //     0xbfb9c4: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb9c8: mov             fp, SP
    // 0xbfb9cc: AllocStack(0x30)
    //     0xbfb9cc: sub             SP, SP, #0x30
    // 0xbfb9d0: CheckStackOverflow
    //     0xbfb9d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb9d4: cmp             SP, x16
    //     0xbfb9d8: b.ls            #0xbfbb40
    // 0xbfb9dc: ldr             x0, [fp, #0x10]
    // 0xbfb9e0: LoadField: r1 = r0->field_b
    //     0xbfb9e0: ldur            w1, [x0, #0xb]
    // 0xbfb9e4: DecompressPointer r1
    //     0xbfb9e4: add             x1, x1, HEAP, lsl #32
    // 0xbfb9e8: stur            x1, [fp, #-0x20]
    // 0xbfb9ec: LoadField: r2 = r1->field_7
    //     0xbfb9ec: ldur            w2, [x1, #7]
    // 0xbfb9f0: DecompressPointer r2
    //     0xbfb9f0: add             x2, x2, HEAP, lsl #32
    // 0xbfb9f4: stur            x2, [fp, #-0x18]
    // 0xbfb9f8: LoadField: r0 = r1->field_b
    //     0xbfb9f8: ldur            w0, [x1, #0xb]
    // 0xbfb9fc: DecompressPointer r0
    //     0xbfb9fc: add             x0, x0, HEAP, lsl #32
    // 0xbfba00: r3 = LoadInt32Instr(r0)
    //     0xbfba00: sbfx            x3, x0, #1, #0x1f
    // 0xbfba04: stur            x3, [fp, #-0x10]
    // 0xbfba08: r4 = 0
    //     0xbfba08: mov             x4, #0
    // 0xbfba0c: stur            x4, [fp, #-8]
    // 0xbfba10: CheckStackOverflow
    //     0xbfba10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfba14: cmp             SP, x16
    //     0xbfba18: b.ls            #0xbfbb48
    // 0xbfba1c: r0 = LoadClassIdInstr(r1)
    //     0xbfba1c: ldur            x0, [x1, #-1]
    //     0xbfba20: ubfx            x0, x0, #0xc, #0x14
    // 0xbfba24: SaveReg r1
    //     0xbfba24: str             x1, [SP, #-8]!
    // 0xbfba28: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xbfba28: mov             x17, #0xb8ea
    //     0xbfba2c: add             lr, x0, x17
    //     0xbfba30: ldr             lr, [x21, lr, lsl #3]
    //     0xbfba34: blr             lr
    // 0xbfba38: add             SP, SP, #8
    // 0xbfba3c: r1 = LoadInt32Instr(r0)
    //     0xbfba3c: sbfx            x1, x0, #1, #0x1f
    //     0xbfba40: tbz             w0, #0, #0xbfba48
    //     0xbfba44: ldur            x1, [x0, #7]
    // 0xbfba48: ldur            x2, [fp, #-0x10]
    // 0xbfba4c: cmp             x2, x1
    // 0xbfba50: b.ne            #0xbfbb28
    // 0xbfba54: ldur            x3, [fp, #-0x20]
    // 0xbfba58: ldur            x4, [fp, #-8]
    // 0xbfba5c: cmp             x4, x1
    // 0xbfba60: b.lt            #0xbfba74
    // 0xbfba64: r0 = Null
    //     0xbfba64: mov             x0, NULL
    // 0xbfba68: LeaveFrame
    //     0xbfba68: mov             SP, fp
    //     0xbfba6c: ldp             fp, lr, [SP], #0x10
    // 0xbfba70: ret
    //     0xbfba70: ret             
    // 0xbfba74: r0 = BoxInt64Instr(r4)
    //     0xbfba74: sbfiz           x0, x4, #1, #0x1f
    //     0xbfba78: cmp             x4, x0, asr #1
    //     0xbfba7c: b.eq            #0xbfba88
    //     0xbfba80: bl              #0xd69bb8
    //     0xbfba84: stur            x4, [x0, #7]
    // 0xbfba88: r1 = LoadClassIdInstr(r3)
    //     0xbfba88: ldur            x1, [x3, #-1]
    //     0xbfba8c: ubfx            x1, x1, #0xc, #0x14
    // 0xbfba90: stp             x0, x3, [SP, #-0x10]!
    // 0xbfba94: mov             x0, x1
    // 0xbfba98: r0 = GDT[cid_x0 + 0xd175]()
    //     0xbfba98: mov             x17, #0xd175
    //     0xbfba9c: add             lr, x0, x17
    //     0xbfbaa0: ldr             lr, [x21, lr, lsl #3]
    //     0xbfbaa4: blr             lr
    // 0xbfbaa8: add             SP, SP, #0x10
    // 0xbfbaac: mov             x3, x0
    // 0xbfbab0: ldur            x0, [fp, #-8]
    // 0xbfbab4: stur            x3, [fp, #-0x30]
    // 0xbfbab8: add             x4, x0, #1
    // 0xbfbabc: stur            x4, [fp, #-0x28]
    // 0xbfbac0: cmp             w3, NULL
    // 0xbfbac4: b.ne            #0xbfbaf8
    // 0xbfbac8: mov             x0, x3
    // 0xbfbacc: ldur            x2, [fp, #-0x18]
    // 0xbfbad0: r1 = Null
    //     0xbfbad0: mov             x1, NULL
    // 0xbfbad4: cmp             w2, NULL
    // 0xbfbad8: b.eq            #0xbfbaf8
    // 0xbfbadc: LoadField: r4 = r2->field_17
    //     0xbfbadc: ldur            w4, [x2, #0x17]
    // 0xbfbae0: DecompressPointer r4
    //     0xbfbae0: add             x4, x4, HEAP, lsl #32
    // 0xbfbae4: r8 = X0
    //     0xbfbae4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbfbae8: LoadField: r9 = r4->field_7
    //     0xbfbae8: ldur            x9, [x4, #7]
    // 0xbfbaec: r3 = Null
    //     0xbfbaec: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c9a0] Null
    //     0xbfbaf0: ldr             x3, [x3, #0x9a0]
    // 0xbfbaf4: blr             x9
    // 0xbfbaf8: ldur            x0, [fp, #-0x30]
    // 0xbfbafc: LoadField: r1 = r0->field_b
    //     0xbfbafc: ldur            w1, [x0, #0xb]
    // 0xbfbb00: DecompressPointer r1
    //     0xbfbb00: add             x1, x1, HEAP, lsl #32
    // 0xbfbb04: ldr             x16, [fp, #0x18]
    // 0xbfbb08: stp             x1, x16, [SP, #-0x10]!
    // 0xbfbb0c: r0 = visitExpressions()
    //     0xbfbb0c: bl              #0xbfa8ac  ; [package:flutter_html/src/css_parser.dart] DeclarationVisitor::visitExpressions
    // 0xbfbb10: add             SP, SP, #0x10
    // 0xbfbb14: ldur            x4, [fp, #-0x28]
    // 0xbfbb18: ldur            x1, [fp, #-0x20]
    // 0xbfbb1c: ldur            x2, [fp, #-0x18]
    // 0xbfbb20: ldur            x3, [fp, #-0x10]
    // 0xbfbb24: b               #0xbfba0c
    // 0xbfbb28: ldur            x0, [fp, #-0x20]
    // 0xbfbb2c: r0 = ConcurrentModificationError()
    //     0xbfbb2c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbfbb30: ldur            x3, [fp, #-0x20]
    // 0xbfbb34: StoreField: r0->field_b = r3
    //     0xbfbb34: stur            w3, [x0, #0xb]
    // 0xbfbb38: r0 = Throw()
    //     0xbfbb38: bl              #0xd67e38  ; ThrowStub
    // 0xbfbb3c: brk             #0
    // 0xbfbb40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbb40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbb44: b               #0xbfb9dc
    // 0xbfbb48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbb48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbb4c: b               #0xbfba1c
  }
  _ visitPageDirective(/* No info */) {
    // ** addr: 0xbfbc10, size: 0x1c0
    // 0xbfbc10: EnterFrame
    //     0xbfbc10: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbc14: mov             fp, SP
    // 0xbfbc18: AllocStack(0x30)
    //     0xbfbc18: sub             SP, SP, #0x30
    // 0xbfbc1c: CheckStackOverflow
    //     0xbfbc1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbc20: cmp             SP, x16
    //     0xbfbc24: b.ls            #0xbfbdc0
    // 0xbfbc28: ldr             x0, [fp, #0x10]
    // 0xbfbc2c: LoadField: r1 = r0->field_b
    //     0xbfbc2c: ldur            w1, [x0, #0xb]
    // 0xbfbc30: DecompressPointer r1
    //     0xbfbc30: add             x1, x1, HEAP, lsl #32
    // 0xbfbc34: stur            x1, [fp, #-0x20]
    // 0xbfbc38: LoadField: r2 = r1->field_7
    //     0xbfbc38: ldur            w2, [x1, #7]
    // 0xbfbc3c: DecompressPointer r2
    //     0xbfbc3c: add             x2, x2, HEAP, lsl #32
    // 0xbfbc40: stur            x2, [fp, #-0x18]
    // 0xbfbc44: LoadField: r0 = r1->field_b
    //     0xbfbc44: ldur            w0, [x1, #0xb]
    // 0xbfbc48: DecompressPointer r0
    //     0xbfbc48: add             x0, x0, HEAP, lsl #32
    // 0xbfbc4c: r3 = LoadInt32Instr(r0)
    //     0xbfbc4c: sbfx            x3, x0, #1, #0x1f
    // 0xbfbc50: stur            x3, [fp, #-0x10]
    // 0xbfbc54: r4 = 0
    //     0xbfbc54: mov             x4, #0
    // 0xbfbc58: stur            x4, [fp, #-8]
    // 0xbfbc5c: CheckStackOverflow
    //     0xbfbc5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbc60: cmp             SP, x16
    //     0xbfbc64: b.ls            #0xbfbdc8
    // 0xbfbc68: r0 = LoadClassIdInstr(r1)
    //     0xbfbc68: ldur            x0, [x1, #-1]
    //     0xbfbc6c: ubfx            x0, x0, #0xc, #0x14
    // 0xbfbc70: SaveReg r1
    //     0xbfbc70: str             x1, [SP, #-8]!
    // 0xbfbc74: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xbfbc74: mov             x17, #0xb8ea
    //     0xbfbc78: add             lr, x0, x17
    //     0xbfbc7c: ldr             lr, [x21, lr, lsl #3]
    //     0xbfbc80: blr             lr
    // 0xbfbc84: add             SP, SP, #8
    // 0xbfbc88: r1 = LoadInt32Instr(r0)
    //     0xbfbc88: sbfx            x1, x0, #1, #0x1f
    //     0xbfbc8c: tbz             w0, #0, #0xbfbc94
    //     0xbfbc90: ldur            x1, [x0, #7]
    // 0xbfbc94: ldur            x2, [fp, #-0x10]
    // 0xbfbc98: cmp             x2, x1
    // 0xbfbc9c: b.ne            #0xbfbda8
    // 0xbfbca0: ldur            x3, [fp, #-0x20]
    // 0xbfbca4: ldur            x4, [fp, #-8]
    // 0xbfbca8: cmp             x4, x1
    // 0xbfbcac: b.lt            #0xbfbcc0
    // 0xbfbcb0: r0 = Null
    //     0xbfbcb0: mov             x0, NULL
    // 0xbfbcb4: LeaveFrame
    //     0xbfbcb4: mov             SP, fp
    //     0xbfbcb8: ldp             fp, lr, [SP], #0x10
    // 0xbfbcbc: ret
    //     0xbfbcbc: ret             
    // 0xbfbcc0: r0 = BoxInt64Instr(r4)
    //     0xbfbcc0: sbfiz           x0, x4, #1, #0x1f
    //     0xbfbcc4: cmp             x4, x0, asr #1
    //     0xbfbcc8: b.eq            #0xbfbcd4
    //     0xbfbccc: bl              #0xd69bb8
    //     0xbfbcd0: stur            x4, [x0, #7]
    // 0xbfbcd4: r1 = LoadClassIdInstr(r3)
    //     0xbfbcd4: ldur            x1, [x3, #-1]
    //     0xbfbcd8: ubfx            x1, x1, #0xc, #0x14
    // 0xbfbcdc: stp             x0, x3, [SP, #-0x10]!
    // 0xbfbce0: mov             x0, x1
    // 0xbfbce4: r0 = GDT[cid_x0 + 0xd175]()
    //     0xbfbce4: mov             x17, #0xd175
    //     0xbfbce8: add             lr, x0, x17
    //     0xbfbcec: ldr             lr, [x21, lr, lsl #3]
    //     0xbfbcf0: blr             lr
    // 0xbfbcf4: add             SP, SP, #0x10
    // 0xbfbcf8: mov             x3, x0
    // 0xbfbcfc: ldur            x0, [fp, #-8]
    // 0xbfbd00: stur            x3, [fp, #-0x30]
    // 0xbfbd04: add             x4, x0, #1
    // 0xbfbd08: stur            x4, [fp, #-0x28]
    // 0xbfbd0c: cmp             w3, NULL
    // 0xbfbd10: b.ne            #0xbfbd44
    // 0xbfbd14: mov             x0, x3
    // 0xbfbd18: ldur            x2, [fp, #-0x18]
    // 0xbfbd1c: r1 = Null
    //     0xbfbd1c: mov             x1, NULL
    // 0xbfbd20: cmp             w2, NULL
    // 0xbfbd24: b.eq            #0xbfbd44
    // 0xbfbd28: LoadField: r4 = r2->field_17
    //     0xbfbd28: ldur            w4, [x2, #0x17]
    // 0xbfbd2c: DecompressPointer r4
    //     0xbfbd2c: add             x4, x4, HEAP, lsl #32
    // 0xbfbd30: r8 = X0
    //     0xbfbd30: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbfbd34: LoadField: r9 = r4->field_7
    //     0xbfbd34: ldur            x9, [x4, #7]
    // 0xbfbd38: r3 = Null
    //     0xbfbd38: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c9e0] Null
    //     0xbfbd3c: ldr             x3, [x3, #0x9e0]
    // 0xbfbd40: blr             x9
    // 0xbfbd44: ldur            x0, [fp, #-0x30]
    // 0xbfbd48: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xbfbd48: mov             x1, #0x76
    //     0xbfbd4c: tbz             w0, #0, #0xbfbd5c
    //     0xbfbd50: ldur            x1, [x0, #-1]
    //     0xbfbd54: ubfx            x1, x1, #0xc, #0x14
    //     0xbfbd58: lsl             x1, x1, #1
    // 0xbfbd5c: r17 = 9298
    //     0xbfbd5c: mov             x17, #0x2452
    // 0xbfbd60: cmp             w1, w17
    // 0xbfbd64: b.ne            #0xbfbd7c
    // 0xbfbd68: ldr             x16, [fp, #0x18]
    // 0xbfbd6c: stp             x0, x16, [SP, #-0x10]!
    // 0xbfbd70: r0 = visitStyleSheet()
    //     0xbfbd70: bl              #0xbfaa90  ; [package:csslib/visitor.dart] Visitor::visitStyleSheet
    // 0xbfbd74: add             SP, SP, #0x10
    // 0xbfbd78: b               #0xbfbd94
    // 0xbfbd7c: LoadField: r1 = r0->field_b
    //     0xbfbd7c: ldur            w1, [x0, #0xb]
    // 0xbfbd80: DecompressPointer r1
    //     0xbfbd80: add             x1, x1, HEAP, lsl #32
    // 0xbfbd84: ldr             x16, [fp, #0x18]
    // 0xbfbd88: stp             x1, x16, [SP, #-0x10]!
    // 0xbfbd8c: r0 = _visitNodeList()
    //     0xbfbd8c: bl              #0xbfaad8  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xbfbd90: add             SP, SP, #0x10
    // 0xbfbd94: ldur            x4, [fp, #-0x28]
    // 0xbfbd98: ldur            x1, [fp, #-0x20]
    // 0xbfbd9c: ldur            x2, [fp, #-0x18]
    // 0xbfbda0: ldur            x3, [fp, #-0x10]
    // 0xbfbda4: b               #0xbfbc58
    // 0xbfbda8: ldur            x0, [fp, #-0x20]
    // 0xbfbdac: r0 = ConcurrentModificationError()
    //     0xbfbdac: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbfbdb0: ldur            x3, [fp, #-0x20]
    // 0xbfbdb4: StoreField: r0->field_b = r3
    //     0xbfbdb4: stur            w3, [x0, #0xb]
    // 0xbfbdb8: r0 = Throw()
    //     0xbfbdb8: bl              #0xd67e38  ; ThrowStub
    // 0xbfbdbc: brk             #0
    // 0xbfbdc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbdc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbdc4: b               #0xbfbc28
    // 0xbfbdc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbdc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbdcc: b               #0xbfbc68
  }
  _ visitKeyFrameDirective(/* No info */) {
    // ** addr: 0xbfbe10, size: 0x5c
    // 0xbfbe10: EnterFrame
    //     0xbfbe10: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbe14: mov             fp, SP
    // 0xbfbe18: CheckStackOverflow
    //     0xbfbe18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbe1c: cmp             SP, x16
    //     0xbfbe20: b.ls            #0xbfbe60
    // 0xbfbe24: ldr             x0, [fp, #0x10]
    // 0xbfbe28: LoadField: r1 = r0->field_b
    //     0xbfbe28: ldur            w1, [x0, #0xb]
    // 0xbfbe2c: DecompressPointer r1
    //     0xbfbe2c: add             x1, x1, HEAP, lsl #32
    // 0xbfbe30: cmp             w1, NULL
    // 0xbfbe34: b.eq            #0xbfbe68
    // 0xbfbe38: LoadField: r1 = r0->field_f
    //     0xbfbe38: ldur            w1, [x0, #0xf]
    // 0xbfbe3c: DecompressPointer r1
    //     0xbfbe3c: add             x1, x1, HEAP, lsl #32
    // 0xbfbe40: ldr             x16, [fp, #0x18]
    // 0xbfbe44: stp             x1, x16, [SP, #-0x10]!
    // 0xbfbe48: r0 = _visitNodeList()
    //     0xbfbe48: bl              #0xbfaad8  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xbfbe4c: add             SP, SP, #0x10
    // 0xbfbe50: r0 = Null
    //     0xbfbe50: mov             x0, NULL
    // 0xbfbe54: LeaveFrame
    //     0xbfbe54: mov             SP, fp
    //     0xbfbe58: ldp             fp, lr, [SP], #0x10
    // 0xbfbe5c: ret
    //     0xbfbe5c: ret             
    // 0xbfbe60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbe60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbe64: b               #0xbfbe24
    // 0xbfbe68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfbe68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitVarDefinitionDirective(/* No info */) {
    // ** addr: 0xbfbeec, size: 0x48
    // 0xbfbeec: EnterFrame
    //     0xbfbeec: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbef0: mov             fp, SP
    // 0xbfbef4: CheckStackOverflow
    //     0xbfbef4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbef8: cmp             SP, x16
    //     0xbfbefc: b.ls            #0xbfbf2c
    // 0xbfbf00: ldr             x0, [fp, #0x10]
    // 0xbfbf04: LoadField: r1 = r0->field_b
    //     0xbfbf04: ldur            w1, [x0, #0xb]
    // 0xbfbf08: DecompressPointer r1
    //     0xbfbf08: add             x1, x1, HEAP, lsl #32
    // 0xbfbf0c: ldr             x16, [fp, #0x18]
    // 0xbfbf10: stp             x1, x16, [SP, #-0x10]!
    // 0xbfbf14: r0 = visitVarDefinition()
    //     0xbfbf14: bl              #0xbfbf34  ; [package:csslib/visitor.dart] Visitor::visitVarDefinition
    // 0xbfbf18: add             SP, SP, #0x10
    // 0xbfbf1c: r0 = Null
    //     0xbfbf1c: mov             x0, NULL
    // 0xbfbf20: LeaveFrame
    //     0xbfbf20: mov             SP, fp
    //     0xbfbf24: ldp             fp, lr, [SP], #0x10
    // 0xbfbf28: ret
    //     0xbfbf28: ret             
    // 0xbfbf2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbf2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbf30: b               #0xbfbf00
  }
  _ visitVarDefinition(/* No info */) {
    // ** addr: 0xbfbf34, size: 0x64
    // 0xbfbf34: EnterFrame
    //     0xbfbf34: stp             fp, lr, [SP, #-0x10]!
    //     0xbfbf38: mov             fp, SP
    // 0xbfbf3c: CheckStackOverflow
    //     0xbfbf3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfbf40: cmp             SP, x16
    //     0xbfbf44: b.ls            #0xbfbf8c
    // 0xbfbf48: ldr             x0, [fp, #0x10]
    // 0xbfbf4c: LoadField: r1 = r0->field_b
    //     0xbfbf4c: ldur            w1, [x0, #0xb]
    // 0xbfbf50: DecompressPointer r1
    //     0xbfbf50: add             x1, x1, HEAP, lsl #32
    // 0xbfbf54: cmp             w1, NULL
    // 0xbfbf58: b.eq            #0xbfbf94
    // 0xbfbf5c: LoadField: r1 = r0->field_f
    //     0xbfbf5c: ldur            w1, [x0, #0xf]
    // 0xbfbf60: DecompressPointer r1
    //     0xbfbf60: add             x1, x1, HEAP, lsl #32
    // 0xbfbf64: cmp             w1, NULL
    // 0xbfbf68: b.eq            #0xbfbf7c
    // 0xbfbf6c: ldr             x16, [fp, #0x18]
    // 0xbfbf70: stp             x1, x16, [SP, #-0x10]!
    // 0xbfbf74: r0 = visitExpressions()
    //     0xbfbf74: bl              #0xbfa8ac  ; [package:flutter_html/src/css_parser.dart] DeclarationVisitor::visitExpressions
    // 0xbfbf78: add             SP, SP, #0x10
    // 0xbfbf7c: r0 = Null
    //     0xbfbf7c: mov             x0, NULL
    // 0xbfbf80: LeaveFrame
    //     0xbfbf80: mov             SP, fp
    //     0xbfbf84: ldp             fp, lr, [SP], #0x10
    // 0xbfbf88: ret
    //     0xbfbf88: ret             
    // 0xbfbf8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfbf8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfbf90: b               #0xbfbf48
    // 0xbfbf94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfbf94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitIncludeDirective(/* No info */) {
    // ** addr: 0xbfc058, size: 0x174
    // 0xbfc058: EnterFrame
    //     0xbfc058: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc05c: mov             fp, SP
    // 0xbfc060: AllocStack(0x20)
    //     0xbfc060: sub             SP, SP, #0x20
    // 0xbfc064: CheckStackOverflow
    //     0xbfc064: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc068: cmp             SP, x16
    //     0xbfc06c: b.ls            #0xbfc1b0
    // 0xbfc070: ldr             x0, [fp, #0x10]
    // 0xbfc074: LoadField: r2 = r0->field_b
    //     0xbfc074: ldur            w2, [x0, #0xb]
    // 0xbfc078: DecompressPointer r2
    //     0xbfc078: add             x2, x2, HEAP, lsl #32
    // 0xbfc07c: stur            x2, [fp, #-0x20]
    // 0xbfc080: r3 = 0
    //     0xbfc080: mov             x3, #0
    // 0xbfc084: stur            x3, [fp, #-0x18]
    // 0xbfc088: CheckStackOverflow
    //     0xbfc088: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc08c: cmp             SP, x16
    //     0xbfc090: b.ls            #0xbfc1b8
    // 0xbfc094: LoadField: r0 = r2->field_b
    //     0xbfc094: ldur            w0, [x2, #0xb]
    // 0xbfc098: DecompressPointer r0
    //     0xbfc098: add             x0, x0, HEAP, lsl #32
    // 0xbfc09c: r1 = LoadInt32Instr(r0)
    //     0xbfc09c: sbfx            x1, x0, #1, #0x1f
    // 0xbfc0a0: cmp             x3, x1
    // 0xbfc0a4: b.ge            #0xbfc1a0
    // 0xbfc0a8: mov             x0, x1
    // 0xbfc0ac: mov             x1, x3
    // 0xbfc0b0: cmp             x1, x0
    // 0xbfc0b4: b.hs            #0xbfc1c0
    // 0xbfc0b8: LoadField: r0 = r2->field_f
    //     0xbfc0b8: ldur            w0, [x2, #0xf]
    // 0xbfc0bc: DecompressPointer r0
    //     0xbfc0bc: add             x0, x0, HEAP, lsl #32
    // 0xbfc0c0: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0xbfc0c0: add             x16, x0, x3, lsl #2
    //     0xbfc0c4: ldur            w1, [x16, #0xf]
    // 0xbfc0c8: DecompressPointer r1
    //     0xbfc0c8: add             x1, x1, HEAP, lsl #32
    // 0xbfc0cc: stur            x1, [fp, #-0x10]
    // 0xbfc0d0: r4 = 0
    //     0xbfc0d0: mov             x4, #0
    // 0xbfc0d4: stur            x4, [fp, #-8]
    // 0xbfc0d8: CheckStackOverflow
    //     0xbfc0d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc0dc: cmp             SP, x16
    //     0xbfc0e0: b.ls            #0xbfc1c4
    // 0xbfc0e4: r0 = LoadClassIdInstr(r1)
    //     0xbfc0e4: ldur            x0, [x1, #-1]
    //     0xbfc0e8: ubfx            x0, x0, #0xc, #0x14
    // 0xbfc0ec: SaveReg r1
    //     0xbfc0ec: str             x1, [SP, #-8]!
    // 0xbfc0f0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xbfc0f0: mov             x17, #0xb8ea
    //     0xbfc0f4: add             lr, x0, x17
    //     0xbfc0f8: ldr             lr, [x21, lr, lsl #3]
    //     0xbfc0fc: blr             lr
    // 0xbfc100: add             SP, SP, #8
    // 0xbfc104: r1 = LoadInt32Instr(r0)
    //     0xbfc104: sbfx            x1, x0, #1, #0x1f
    //     0xbfc108: tbz             w0, #0, #0xbfc110
    //     0xbfc10c: ldur            x1, [x0, #7]
    // 0xbfc110: ldur            x2, [fp, #-8]
    // 0xbfc114: cmp             x2, x1
    // 0xbfc118: b.ge            #0xbfc190
    // 0xbfc11c: ldur            x3, [fp, #-0x10]
    // 0xbfc120: r0 = BoxInt64Instr(r2)
    //     0xbfc120: sbfiz           x0, x2, #1, #0x1f
    //     0xbfc124: cmp             x2, x0, asr #1
    //     0xbfc128: b.eq            #0xbfc134
    //     0xbfc12c: bl              #0xd69bb8
    //     0xbfc130: stur            x2, [x0, #7]
    // 0xbfc134: r1 = LoadClassIdInstr(r3)
    //     0xbfc134: ldur            x1, [x3, #-1]
    //     0xbfc138: ubfx            x1, x1, #0xc, #0x14
    // 0xbfc13c: stp             x0, x3, [SP, #-0x10]!
    // 0xbfc140: mov             x0, x1
    // 0xbfc144: r0 = GDT[cid_x0 + -0xd83]()
    //     0xbfc144: sub             lr, x0, #0xd83
    //     0xbfc148: ldr             lr, [x21, lr, lsl #3]
    //     0xbfc14c: blr             lr
    // 0xbfc150: add             SP, SP, #0x10
    // 0xbfc154: r1 = LoadClassIdInstr(r0)
    //     0xbfc154: ldur            x1, [x0, #-1]
    //     0xbfc158: ubfx            x1, x1, #0xc, #0x14
    // 0xbfc15c: ldr             x16, [fp, #0x18]
    // 0xbfc160: stp             x16, x0, [SP, #-0x10]!
    // 0xbfc164: mov             x0, x1
    // 0xbfc168: r0 = GDT[cid_x0 + 0xdc8]()
    //     0xbfc168: add             lr, x0, #0xdc8
    //     0xbfc16c: ldr             lr, [x21, lr, lsl #3]
    //     0xbfc170: blr             lr
    // 0xbfc174: add             SP, SP, #0x10
    // 0xbfc178: ldur            x1, [fp, #-8]
    // 0xbfc17c: add             x4, x1, #1
    // 0xbfc180: ldur            x3, [fp, #-0x18]
    // 0xbfc184: ldur            x2, [fp, #-0x20]
    // 0xbfc188: ldur            x1, [fp, #-0x10]
    // 0xbfc18c: b               #0xbfc0d4
    // 0xbfc190: ldur            x1, [fp, #-0x18]
    // 0xbfc194: add             x3, x1, #1
    // 0xbfc198: ldur            x2, [fp, #-0x20]
    // 0xbfc19c: b               #0xbfc084
    // 0xbfc1a0: r0 = Null
    //     0xbfc1a0: mov             x0, NULL
    // 0xbfc1a4: LeaveFrame
    //     0xbfc1a4: mov             SP, fp
    //     0xbfc1a8: ldp             fp, lr, [SP], #0x10
    // 0xbfc1ac: ret
    //     0xbfc1ac: ret             
    // 0xbfc1b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc1b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc1b4: b               #0xbfc070
    // 0xbfc1b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc1b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc1bc: b               #0xbfc094
    // 0xbfc1c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbfc1c0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbfc1c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc1c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc1c8: b               #0xbfc0e4
  }
  _ visitIncludeMixinAtDeclaration(/* No info */) {
    // ** addr: 0xbfc3cc, size: 0x48
    // 0xbfc3cc: EnterFrame
    //     0xbfc3cc: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc3d0: mov             fp, SP
    // 0xbfc3d4: CheckStackOverflow
    //     0xbfc3d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc3d8: cmp             SP, x16
    //     0xbfc3dc: b.ls            #0xbfc40c
    // 0xbfc3e0: ldr             x0, [fp, #0x10]
    // 0xbfc3e4: LoadField: r1 = r0->field_1b
    //     0xbfc3e4: ldur            w1, [x0, #0x1b]
    // 0xbfc3e8: DecompressPointer r1
    //     0xbfc3e8: add             x1, x1, HEAP, lsl #32
    // 0xbfc3ec: ldr             x16, [fp, #0x18]
    // 0xbfc3f0: stp             x1, x16, [SP, #-0x10]!
    // 0xbfc3f4: r0 = visitIncludeDirective()
    //     0xbfc3f4: bl              #0xbfc058  ; [package:csslib/visitor.dart] Visitor::visitIncludeDirective
    // 0xbfc3f8: add             SP, SP, #0x10
    // 0xbfc3fc: r0 = Null
    //     0xbfc3fc: mov             x0, NULL
    // 0xbfc400: LeaveFrame
    //     0xbfc400: mov             SP, fp
    //     0xbfc404: ldp             fp, lr, [SP], #0x10
    // 0xbfc408: ret
    //     0xbfc408: ret             
    // 0xbfc40c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc40c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc410: b               #0xbfc3e0
  }
  _ visitExtendDeclaration(/* No info */) {
    // ** addr: 0xbfc454, size: 0x48
    // 0xbfc454: EnterFrame
    //     0xbfc454: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc458: mov             fp, SP
    // 0xbfc45c: CheckStackOverflow
    //     0xbfc45c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc460: cmp             SP, x16
    //     0xbfc464: b.ls            #0xbfc494
    // 0xbfc468: ldr             x0, [fp, #0x10]
    // 0xbfc46c: LoadField: r1 = r0->field_1b
    //     0xbfc46c: ldur            w1, [x0, #0x1b]
    // 0xbfc470: DecompressPointer r1
    //     0xbfc470: add             x1, x1, HEAP, lsl #32
    // 0xbfc474: ldr             x16, [fp, #0x18]
    // 0xbfc478: stp             x1, x16, [SP, #-0x10]!
    // 0xbfc47c: r0 = _visitNodeList()
    //     0xbfc47c: bl              #0xbfaad8  ; [package:csslib/visitor.dart] Visitor::_visitNodeList
    // 0xbfc480: add             SP, SP, #0x10
    // 0xbfc484: r0 = Null
    //     0xbfc484: mov             x0, NULL
    // 0xbfc488: LeaveFrame
    //     0xbfc488: mov             SP, fp
    //     0xbfc48c: ldp             fp, lr, [SP], #0x10
    // 0xbfc490: ret
    //     0xbfc490: ret             
    // 0xbfc494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc494: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc498: b               #0xbfc468
  }
  _ visitAttributeSelector(/* No info */) {
    // ** addr: 0xc95000, size: 0x40
    // 0xc95000: EnterFrame
    //     0xc95000: stp             fp, lr, [SP, #-0x10]!
    //     0xc95004: mov             fp, SP
    // 0xc95008: CheckStackOverflow
    //     0xc95008: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9500c: cmp             SP, x16
    //     0xc95010: b.ls            #0xc95038
    // 0xc95014: ldr             x16, [fp, #0x18]
    // 0xc95018: ldr             lr, [fp, #0x10]
    // 0xc9501c: stp             lr, x16, [SP, #-0x10]!
    // 0xc95020: r0 = visitSimpleSelector()
    //     0xc95020: bl              #0xc95040  ; [package:csslib/visitor.dart] Visitor::visitSimpleSelector
    // 0xc95024: add             SP, SP, #0x10
    // 0xc95028: r0 = Null
    //     0xc95028: mov             x0, NULL
    // 0xc9502c: LeaveFrame
    //     0xc9502c: mov             SP, fp
    //     0xc95030: ldp             fp, lr, [SP], #0x10
    // 0xc95034: ret
    //     0xc95034: ret             
    // 0xc95038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc95038: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9503c: b               #0xc95014
  }
  _ visitSimpleSelector(/* No info */) {
    // ** addr: 0xc95040, size: 0xa4
    // 0xc95040: EnterFrame
    //     0xc95040: stp             fp, lr, [SP, #-0x10]!
    //     0xc95044: mov             fp, SP
    // 0xc95048: AllocStack(0x8)
    //     0xc95048: sub             SP, SP, #8
    // 0xc9504c: CheckStackOverflow
    //     0xc9504c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc95050: cmp             SP, x16
    //     0xc95054: b.ls            #0xc950dc
    // 0xc95058: ldr             x0, [fp, #0x10]
    // 0xc9505c: LoadField: r3 = r0->field_b
    //     0xc9505c: ldur            w3, [x0, #0xb]
    // 0xc95060: DecompressPointer r3
    //     0xc95060: add             x3, x3, HEAP, lsl #32
    // 0xc95064: mov             x0, x3
    // 0xc95068: stur            x3, [fp, #-8]
    // 0xc9506c: r2 = Null
    //     0xc9506c: mov             x2, NULL
    // 0xc95070: r1 = Null
    //     0xc95070: mov             x1, NULL
    // 0xc95074: r4 = 59
    //     0xc95074: mov             x4, #0x3b
    // 0xc95078: branchIfSmi(r0, 0xc95084)
    //     0xc95078: tbz             w0, #0, #0xc95084
    // 0xc9507c: r4 = LoadClassIdInstr(r0)
    //     0xc9507c: ldur            x4, [x0, #-1]
    //     0xc95080: ubfx            x4, x4, #0xc, #0x14
    // 0xc95084: r17 = -4641
    //     0xc95084: mov             x17, #-0x1221
    // 0xc95088: add             x4, x4, x17
    // 0xc9508c: cmp             x4, #0x5b
    // 0xc95090: b.ls            #0xc950a8
    // 0xc95094: r8 = TreeNode
    //     0xc95094: add             x8, PP, #0x3c, lsl #12  ; [pp+0x3cbc8] Type: TreeNode
    //     0xc95098: ldr             x8, [x8, #0xbc8]
    // 0xc9509c: r3 = Null
    //     0xc9509c: add             x3, PP, #0x41, lsl #12  ; [pp+0x412b8] Null
    //     0xc950a0: ldr             x3, [x3, #0x2b8]
    // 0xc950a4: r0 = TreeNode()
    //     0xc950a4: bl              #0x7d978c  ; IsType_TreeNode_Stub
    // 0xc950a8: ldur            x0, [fp, #-8]
    // 0xc950ac: r1 = LoadClassIdInstr(r0)
    //     0xc950ac: ldur            x1, [x0, #-1]
    //     0xc950b0: ubfx            x1, x1, #0xc, #0x14
    // 0xc950b4: ldr             x16, [fp, #0x18]
    // 0xc950b8: stp             x16, x0, [SP, #-0x10]!
    // 0xc950bc: mov             x0, x1
    // 0xc950c0: r0 = GDT[cid_x0 + 0xdc8]()
    //     0xc950c0: add             lr, x0, #0xdc8
    //     0xc950c4: ldr             lr, [x21, lr, lsl #3]
    //     0xc950c8: blr             lr
    // 0xc950cc: add             SP, SP, #0x10
    // 0xc950d0: LeaveFrame
    //     0xc950d0: mov             SP, fp
    //     0xc950d4: ldp             fp, lr, [SP], #0x10
    // 0xc950d8: ret
    //     0xc950d8: ret             
    // 0xc950dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc950dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc950e0: b               #0xc95058
  }
  _ visitNamespaceSelector(/* No info */) {
    // ** addr: 0xc957d8, size: 0x11c
    // 0xc957d8: EnterFrame
    //     0xc957d8: stp             fp, lr, [SP, #-0x10]!
    //     0xc957dc: mov             fp, SP
    // 0xc957e0: AllocStack(0x8)
    //     0xc957e0: sub             SP, SP, #8
    // 0xc957e4: CheckStackOverflow
    //     0xc957e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc957e8: cmp             SP, x16
    //     0xc957ec: b.ls            #0xc958ec
    // 0xc957f0: ldr             x3, [fp, #0x10]
    // 0xc957f4: LoadField: r4 = r3->field_f
    //     0xc957f4: ldur            w4, [x3, #0xf]
    // 0xc957f8: DecompressPointer r4
    //     0xc957f8: add             x4, x4, HEAP, lsl #32
    // 0xc957fc: stur            x4, [fp, #-8]
    // 0xc95800: cmp             w4, NULL
    // 0xc95804: b.eq            #0xc95870
    // 0xc95808: mov             x0, x4
    // 0xc9580c: r2 = Null
    //     0xc9580c: mov             x2, NULL
    // 0xc95810: r1 = Null
    //     0xc95810: mov             x1, NULL
    // 0xc95814: r4 = 59
    //     0xc95814: mov             x4, #0x3b
    // 0xc95818: branchIfSmi(r0, 0xc95824)
    //     0xc95818: tbz             w0, #0, #0xc95824
    // 0xc9581c: r4 = LoadClassIdInstr(r0)
    //     0xc9581c: ldur            x4, [x0, #-1]
    //     0xc95820: ubfx            x4, x4, #0xc, #0x14
    // 0xc95824: r17 = -4641
    //     0xc95824: mov             x17, #-0x1221
    // 0xc95828: add             x4, x4, x17
    // 0xc9582c: cmp             x4, #0x5b
    // 0xc95830: b.ls            #0xc95848
    // 0xc95834: r8 = TreeNode
    //     0xc95834: add             x8, PP, #0x3c, lsl #12  ; [pp+0x3cbc8] Type: TreeNode
    //     0xc95838: ldr             x8, [x8, #0xbc8]
    // 0xc9583c: r3 = Null
    //     0xc9583c: add             x3, PP, #0x41, lsl #12  ; [pp+0x412c8] Null
    //     0xc95840: ldr             x3, [x3, #0x2c8]
    // 0xc95844: r0 = TreeNode()
    //     0xc95844: bl              #0x7d978c  ; IsType_TreeNode_Stub
    // 0xc95848: ldur            x0, [fp, #-8]
    // 0xc9584c: r1 = LoadClassIdInstr(r0)
    //     0xc9584c: ldur            x1, [x0, #-1]
    //     0xc95850: ubfx            x1, x1, #0xc, #0x14
    // 0xc95854: ldr             x16, [fp, #0x18]
    // 0xc95858: stp             x16, x0, [SP, #-0x10]!
    // 0xc9585c: mov             x0, x1
    // 0xc95860: r0 = GDT[cid_x0 + 0xdc8]()
    //     0xc95860: add             lr, x0, #0xdc8
    //     0xc95864: ldr             lr, [x21, lr, lsl #3]
    //     0xc95868: blr             lr
    // 0xc9586c: add             SP, SP, #0x10
    // 0xc95870: ldr             x0, [fp, #0x10]
    // 0xc95874: LoadField: r3 = r0->field_b
    //     0xc95874: ldur            w3, [x0, #0xb]
    // 0xc95878: DecompressPointer r3
    //     0xc95878: add             x3, x3, HEAP, lsl #32
    // 0xc9587c: mov             x0, x3
    // 0xc95880: stur            x3, [fp, #-8]
    // 0xc95884: r2 = Null
    //     0xc95884: mov             x2, NULL
    // 0xc95888: r1 = Null
    //     0xc95888: mov             x1, NULL
    // 0xc9588c: r4 = 59
    //     0xc9588c: mov             x4, #0x3b
    // 0xc95890: branchIfSmi(r0, 0xc9589c)
    //     0xc95890: tbz             w0, #0, #0xc9589c
    // 0xc95894: r4 = LoadClassIdInstr(r0)
    //     0xc95894: ldur            x4, [x0, #-1]
    //     0xc95898: ubfx            x4, x4, #0xc, #0x14
    // 0xc9589c: r17 = -4684
    //     0xc9589c: mov             x17, #-0x124c
    // 0xc958a0: add             x4, x4, x17
    // 0xc958a4: cmp             x4, #9
    // 0xc958a8: b.ls            #0xc958c0
    // 0xc958ac: r8 = SimpleSelector?
    //     0xc958ac: add             x8, PP, #0x38, lsl #12  ; [pp+0x385e0] Type: SimpleSelector?
    //     0xc958b0: ldr             x8, [x8, #0x5e0]
    // 0xc958b4: r3 = Null
    //     0xc958b4: add             x3, PP, #0x41, lsl #12  ; [pp+0x412d8] Null
    //     0xc958b8: ldr             x3, [x3, #0x2d8]
    // 0xc958bc: r0 = DefaultNullableTypeTest()
    //     0xc958bc: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xc958c0: ldur            x0, [fp, #-8]
    // 0xc958c4: cmp             w0, NULL
    // 0xc958c8: b.eq            #0xc958dc
    // 0xc958cc: ldr             x16, [fp, #0x18]
    // 0xc958d0: stp             x16, x0, [SP, #-0x10]!
    // 0xc958d4: r0 = visit()
    //     0xc958d4: bl              #0xbfaf38  ; [package:csslib/visitor.dart] ElementSelector::visit
    // 0xc958d8: add             SP, SP, #0x10
    // 0xc958dc: r0 = Null
    //     0xc958dc: mov             x0, NULL
    // 0xc958e0: LeaveFrame
    //     0xc958e0: mov             SP, fp
    //     0xc958e4: ldp             fp, lr, [SP], #0x10
    // 0xc958e8: ret
    //     0xc958e8: ret             
    // 0xc958ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc958ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc958f0: b               #0xc957f0
  }
  _ visitElementSelector(/* No info */) {
    // ** addr: 0xc96c80, size: 0x3c
    // 0xc96c80: EnterFrame
    //     0xc96c80: stp             fp, lr, [SP, #-0x10]!
    //     0xc96c84: mov             fp, SP
    // 0xc96c88: CheckStackOverflow
    //     0xc96c88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc96c8c: cmp             SP, x16
    //     0xc96c90: b.ls            #0xc96cb4
    // 0xc96c94: ldr             x16, [fp, #0x18]
    // 0xc96c98: ldr             lr, [fp, #0x10]
    // 0xc96c9c: stp             lr, x16, [SP, #-0x10]!
    // 0xc96ca0: r0 = visitSimpleSelector()
    //     0xc96ca0: bl              #0xc95040  ; [package:csslib/visitor.dart] Visitor::visitSimpleSelector
    // 0xc96ca4: add             SP, SP, #0x10
    // 0xc96ca8: LeaveFrame
    //     0xc96ca8: mov             SP, fp
    //     0xc96cac: ldp             fp, lr, [SP], #0x10
    // 0xc96cb0: ret
    //     0xc96cb0: ret             
    // 0xc96cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc96cb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc96cb8: b               #0xc96c94
  }
}

// class id: 4736, size: 0x8, field offset: 0x8
abstract class VisitorBase extends Object {
}

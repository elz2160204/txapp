// lib: , url: package:csslib/src/messages.dart

// class id: 1048824, size: 0x8
class :: {

  static late Messages messages; // offset: 0xb20
}

// class id: 4738, size: 0x14, field offset: 0x8
class Messages extends Object {

  _ error(/* No info */) {
    // ** addr: 0x7dffd0, size: 0x138
    // 0x7dffd0: EnterFrame
    //     0x7dffd0: stp             fp, lr, [SP, #-0x10]!
    //     0x7dffd4: mov             fp, SP
    // 0x7dffd8: AllocStack(0x18)
    //     0x7dffd8: sub             SP, SP, #0x18
    // 0x7dffdc: CheckStackOverflow
    //     0x7dffdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7dffe0: cmp             SP, x16
    //     0x7dffe4: b.ls            #0x7e00fc
    // 0x7dffe8: ldr             x0, [fp, #0x20]
    // 0x7dffec: LoadField: r1 = r0->field_b
    //     0x7dffec: ldur            w1, [x0, #0xb]
    // 0x7dfff0: DecompressPointer r1
    //     0x7dfff0: add             x1, x1, HEAP, lsl #32
    // 0x7dfff4: LoadField: r2 = r1->field_17
    //     0x7dfff4: ldur            w2, [x1, #0x17]
    // 0x7dfff8: DecompressPointer r2
    //     0x7dfff8: add             x2, x2, HEAP, lsl #32
    // 0x7dfffc: stur            x2, [fp, #-8]
    // 0x7e0000: r0 = Message()
    //     0x7e0000: bl              #0x7e0108  ; AllocateMessageStub -> Message (size=0x18)
    // 0x7e0004: mov             x1, x0
    // 0x7e0008: r0 = Instance_MessageLevel
    //     0x7e0008: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2b4a0] Obj!MessageLevel@b66831
    //     0x7e000c: ldr             x0, [x0, #0x4a0]
    // 0x7e0010: stur            x1, [fp, #-0x18]
    // 0x7e0014: StoreField: r1->field_7 = r0
    //     0x7e0014: stur            w0, [x1, #7]
    // 0x7e0018: ldr             x0, [fp, #0x18]
    // 0x7e001c: StoreField: r1->field_b = r0
    //     0x7e001c: stur            w0, [x1, #0xb]
    // 0x7e0020: ldr             x0, [fp, #0x10]
    // 0x7e0024: StoreField: r1->field_f = r0
    //     0x7e0024: stur            w0, [x1, #0xf]
    // 0x7e0028: ldur            x0, [fp, #-8]
    // 0x7e002c: StoreField: r1->field_13 = r0
    //     0x7e002c: stur            w0, [x1, #0x13]
    // 0x7e0030: ldr             x0, [fp, #0x20]
    // 0x7e0034: LoadField: r2 = r0->field_f
    //     0x7e0034: ldur            w2, [x0, #0xf]
    // 0x7e0038: DecompressPointer r2
    //     0x7e0038: add             x2, x2, HEAP, lsl #32
    // 0x7e003c: stur            x2, [fp, #-0x10]
    // 0x7e0040: LoadField: r3 = r2->field_b
    //     0x7e0040: ldur            w3, [x2, #0xb]
    // 0x7e0044: DecompressPointer r3
    //     0x7e0044: add             x3, x3, HEAP, lsl #32
    // 0x7e0048: stur            x3, [fp, #-8]
    // 0x7e004c: LoadField: r4 = r2->field_f
    //     0x7e004c: ldur            w4, [x2, #0xf]
    // 0x7e0050: DecompressPointer r4
    //     0x7e0050: add             x4, x4, HEAP, lsl #32
    // 0x7e0054: LoadField: r5 = r4->field_b
    //     0x7e0054: ldur            w5, [x4, #0xb]
    // 0x7e0058: DecompressPointer r5
    //     0x7e0058: add             x5, x5, HEAP, lsl #32
    // 0x7e005c: cmp             w3, w5
    // 0x7e0060: b.ne            #0x7e0070
    // 0x7e0064: SaveReg r2
    //     0x7e0064: str             x2, [SP, #-8]!
    // 0x7e0068: r0 = _growToNextCapacity()
    //     0x7e0068: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7e006c: add             SP, SP, #8
    // 0x7e0070: ldr             x2, [fp, #0x20]
    // 0x7e0074: ldur            x3, [fp, #-0x10]
    // 0x7e0078: ldur            x0, [fp, #-8]
    // 0x7e007c: r4 = LoadInt32Instr(r0)
    //     0x7e007c: sbfx            x4, x0, #1, #0x1f
    // 0x7e0080: add             x0, x4, #1
    // 0x7e0084: lsl             x1, x0, #1
    // 0x7e0088: StoreField: r3->field_b = r1
    //     0x7e0088: stur            w1, [x3, #0xb]
    // 0x7e008c: mov             x1, x4
    // 0x7e0090: cmp             x1, x0
    // 0x7e0094: b.hs            #0x7e0104
    // 0x7e0098: LoadField: r1 = r3->field_f
    //     0x7e0098: ldur            w1, [x3, #0xf]
    // 0x7e009c: DecompressPointer r1
    //     0x7e009c: add             x1, x1, HEAP, lsl #32
    // 0x7e00a0: ldur            x0, [fp, #-0x18]
    // 0x7e00a4: ArrayStore: r1[r4] = r0  ; List_4
    //     0x7e00a4: add             x25, x1, x4, lsl #2
    //     0x7e00a8: add             x25, x25, #0xf
    //     0x7e00ac: str             w0, [x25]
    //     0x7e00b0: tbz             w0, #0, #0x7e00cc
    //     0x7e00b4: ldurb           w16, [x1, #-1]
    //     0x7e00b8: ldurb           w17, [x0, #-1]
    //     0x7e00bc: and             x16, x17, x16, lsr #2
    //     0x7e00c0: tst             x16, HEAP, lsr #32
    //     0x7e00c4: b.eq            #0x7e00cc
    //     0x7e00c8: bl              #0xd67e5c
    // 0x7e00cc: LoadField: r0 = r2->field_7
    //     0x7e00cc: ldur            w0, [x2, #7]
    // 0x7e00d0: DecompressPointer r0
    //     0x7e00d0: add             x0, x0, HEAP, lsl #32
    // 0x7e00d4: ldur            x16, [fp, #-0x18]
    // 0x7e00d8: stp             x16, x0, [SP, #-0x10]!
    // 0x7e00dc: ClosureCall
    //     0x7e00dc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x7e00e0: ldur            x2, [x0, #0x1f]
    //     0x7e00e4: blr             x2
    // 0x7e00e8: add             SP, SP, #0x10
    // 0x7e00ec: r0 = Null
    //     0x7e00ec: mov             x0, NULL
    // 0x7e00f0: LeaveFrame
    //     0x7e00f0: mov             SP, fp
    //     0x7e00f4: ldp             fp, lr, [SP], #0x10
    // 0x7e00f8: ret
    //     0x7e00f8: ret             
    // 0x7e00fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7e00fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7e0100: b               #0x7dffe8
    // 0x7e0104: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7e0104: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ warning(/* No info */) {
    // ** addr: 0xb67da4, size: 0x114
    // 0xb67da4: EnterFrame
    //     0xb67da4: stp             fp, lr, [SP, #-0x10]!
    //     0xb67da8: mov             fp, SP
    // 0xb67dac: AllocStack(0x18)
    //     0xb67dac: sub             SP, SP, #0x18
    // 0xb67db0: CheckStackOverflow
    //     0xb67db0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb67db4: cmp             SP, x16
    //     0xb67db8: b.ls            #0xb67eac
    // 0xb67dbc: ldr             x0, [fp, #0x20]
    // 0xb67dc0: LoadField: r1 = r0->field_b
    //     0xb67dc0: ldur            w1, [x0, #0xb]
    // 0xb67dc4: DecompressPointer r1
    //     0xb67dc4: add             x1, x1, HEAP, lsl #32
    // 0xb67dc8: LoadField: r2 = r1->field_17
    //     0xb67dc8: ldur            w2, [x1, #0x17]
    // 0xb67dcc: DecompressPointer r2
    //     0xb67dcc: add             x2, x2, HEAP, lsl #32
    // 0xb67dd0: stur            x2, [fp, #-8]
    // 0xb67dd4: r0 = Message()
    //     0xb67dd4: bl              #0x7e0108  ; AllocateMessageStub -> Message (size=0x18)
    // 0xb67dd8: mov             x1, x0
    // 0xb67ddc: r0 = Instance_MessageLevel
    //     0xb67ddc: add             x0, PP, #0x3c, lsl #12  ; [pp+0x3cbf8] Obj!MessageLevel@b66871
    //     0xb67de0: ldr             x0, [x0, #0xbf8]
    // 0xb67de4: stur            x1, [fp, #-0x18]
    // 0xb67de8: StoreField: r1->field_7 = r0
    //     0xb67de8: stur            w0, [x1, #7]
    // 0xb67dec: ldr             x0, [fp, #0x18]
    // 0xb67df0: StoreField: r1->field_b = r0
    //     0xb67df0: stur            w0, [x1, #0xb]
    // 0xb67df4: ldr             x0, [fp, #0x10]
    // 0xb67df8: StoreField: r1->field_f = r0
    //     0xb67df8: stur            w0, [x1, #0xf]
    // 0xb67dfc: ldur            x0, [fp, #-8]
    // 0xb67e00: StoreField: r1->field_13 = r0
    //     0xb67e00: stur            w0, [x1, #0x13]
    // 0xb67e04: ldr             x0, [fp, #0x20]
    // 0xb67e08: LoadField: r2 = r0->field_f
    //     0xb67e08: ldur            w2, [x0, #0xf]
    // 0xb67e0c: DecompressPointer r2
    //     0xb67e0c: add             x2, x2, HEAP, lsl #32
    // 0xb67e10: stur            x2, [fp, #-0x10]
    // 0xb67e14: LoadField: r0 = r2->field_b
    //     0xb67e14: ldur            w0, [x2, #0xb]
    // 0xb67e18: DecompressPointer r0
    //     0xb67e18: add             x0, x0, HEAP, lsl #32
    // 0xb67e1c: stur            x0, [fp, #-8]
    // 0xb67e20: LoadField: r3 = r2->field_f
    //     0xb67e20: ldur            w3, [x2, #0xf]
    // 0xb67e24: DecompressPointer r3
    //     0xb67e24: add             x3, x3, HEAP, lsl #32
    // 0xb67e28: LoadField: r4 = r3->field_b
    //     0xb67e28: ldur            w4, [x3, #0xb]
    // 0xb67e2c: DecompressPointer r4
    //     0xb67e2c: add             x4, x4, HEAP, lsl #32
    // 0xb67e30: cmp             w0, w4
    // 0xb67e34: b.ne            #0xb67e44
    // 0xb67e38: SaveReg r2
    //     0xb67e38: str             x2, [SP, #-8]!
    // 0xb67e3c: r0 = _growToNextCapacity()
    //     0xb67e3c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb67e40: add             SP, SP, #8
    // 0xb67e44: ldur            x2, [fp, #-0x10]
    // 0xb67e48: ldur            x3, [fp, #-8]
    // 0xb67e4c: r4 = LoadInt32Instr(r3)
    //     0xb67e4c: sbfx            x4, x3, #1, #0x1f
    // 0xb67e50: add             x0, x4, #1
    // 0xb67e54: lsl             x3, x0, #1
    // 0xb67e58: StoreField: r2->field_b = r3
    //     0xb67e58: stur            w3, [x2, #0xb]
    // 0xb67e5c: mov             x1, x4
    // 0xb67e60: cmp             x1, x0
    // 0xb67e64: b.hs            #0xb67eb4
    // 0xb67e68: LoadField: r1 = r2->field_f
    //     0xb67e68: ldur            w1, [x2, #0xf]
    // 0xb67e6c: DecompressPointer r1
    //     0xb67e6c: add             x1, x1, HEAP, lsl #32
    // 0xb67e70: ldur            x0, [fp, #-0x18]
    // 0xb67e74: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb67e74: add             x25, x1, x4, lsl #2
    //     0xb67e78: add             x25, x25, #0xf
    //     0xb67e7c: str             w0, [x25]
    //     0xb67e80: tbz             w0, #0, #0xb67e9c
    //     0xb67e84: ldurb           w16, [x1, #-1]
    //     0xb67e88: ldurb           w17, [x0, #-1]
    //     0xb67e8c: and             x16, x17, x16, lsr #2
    //     0xb67e90: tst             x16, HEAP, lsr #32
    //     0xb67e94: b.eq            #0xb67e9c
    //     0xb67e98: bl              #0xd67e5c
    // 0xb67e9c: r0 = Null
    //     0xb67e9c: mov             x0, NULL
    // 0xb67ea0: LeaveFrame
    //     0xb67ea0: mov             SP, fp
    //     0xb67ea4: ldp             fp, lr, [SP], #0x10
    // 0xb67ea8: ret
    //     0xb67ea8: ret             
    // 0xb67eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb67eac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb67eb0: b               #0xb67dbc
    // 0xb67eb4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb67eb4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ mergeMessages(/* No info */) {
    // ** addr: 0xb6e4b4, size: 0xa8
    // 0xb6e4b4: EnterFrame
    //     0xb6e4b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb6e4b8: mov             fp, SP
    // 0xb6e4bc: AllocStack(0x10)
    //     0xb6e4bc: sub             SP, SP, #0x10
    // 0xb6e4c0: CheckStackOverflow
    //     0xb6e4c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb6e4c4: cmp             SP, x16
    //     0xb6e4c8: b.ls            #0xb6e554
    // 0xb6e4cc: r1 = 1
    //     0xb6e4cc: mov             x1, #1
    // 0xb6e4d0: r0 = AllocateContext()
    //     0xb6e4d0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xb6e4d4: mov             x1, x0
    // 0xb6e4d8: ldr             x0, [fp, #0x18]
    // 0xb6e4dc: stur            x1, [fp, #-0x10]
    // 0xb6e4e0: StoreField: r1->field_f = r0
    //     0xb6e4e0: stur            w0, [x1, #0xf]
    // 0xb6e4e4: LoadField: r2 = r0->field_f
    //     0xb6e4e4: ldur            w2, [x0, #0xf]
    // 0xb6e4e8: DecompressPointer r2
    //     0xb6e4e8: add             x2, x2, HEAP, lsl #32
    // 0xb6e4ec: ldr             x3, [fp, #0x10]
    // 0xb6e4f0: LoadField: r4 = r3->field_f
    //     0xb6e4f0: ldur            w4, [x3, #0xf]
    // 0xb6e4f4: DecompressPointer r4
    //     0xb6e4f4: add             x4, x4, HEAP, lsl #32
    // 0xb6e4f8: stur            x4, [fp, #-8]
    // 0xb6e4fc: stp             x4, x2, [SP, #-0x10]!
    // 0xb6e500: r0 = addAll()
    //     0xb6e500: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xb6e504: add             SP, SP, #0x10
    // 0xb6e508: ldur            x2, [fp, #-0x10]
    // 0xb6e50c: r1 = Function '<anonymous closure>':.
    //     0xb6e50c: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3cfd8] AnonymousClosure: (0xb6e55c), in [package:csslib/src/messages.dart] Messages::mergeMessages (0xb6e4b4)
    //     0xb6e510: ldr             x1, [x1, #0xfd8]
    // 0xb6e514: r0 = AllocateClosure()
    //     0xb6e514: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb6e518: ldur            x16, [fp, #-8]
    // 0xb6e51c: stp             x0, x16, [SP, #-0x10]!
    // 0xb6e520: r0 = where()
    //     0xb6e520: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0xb6e524: add             SP, SP, #0x10
    // 0xb6e528: mov             x1, x0
    // 0xb6e52c: ldr             x0, [fp, #0x18]
    // 0xb6e530: LoadField: r2 = r0->field_7
    //     0xb6e530: ldur            w2, [x0, #7]
    // 0xb6e534: DecompressPointer r2
    //     0xb6e534: add             x2, x2, HEAP, lsl #32
    // 0xb6e538: stp             x2, x1, [SP, #-0x10]!
    // 0xb6e53c: r0 = forEach()
    //     0xb6e53c: bl              #0x6ab958  ; [dart:core] Iterable::forEach
    // 0xb6e540: add             SP, SP, #0x10
    // 0xb6e544: r0 = Null
    //     0xb6e544: mov             x0, NULL
    // 0xb6e548: LeaveFrame
    //     0xb6e548: mov             SP, fp
    //     0xb6e54c: ldp             fp, lr, [SP], #0x10
    // 0xb6e550: ret
    //     0xb6e550: ret             
    // 0xb6e554: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6e554: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6e558: b               #0xb6e4cc
  }
  [closure] bool <anonymous closure>(dynamic, Message) {
    // ** addr: 0xb6e55c, size: 0x2c
    // 0xb6e55c: ldr             x1, [SP]
    // 0xb6e560: LoadField: r2 = r1->field_7
    //     0xb6e560: ldur            w2, [x1, #7]
    // 0xb6e564: DecompressPointer r2
    //     0xb6e564: add             x2, x2, HEAP, lsl #32
    // 0xb6e568: r16 = Instance_MessageLevel
    //     0xb6e568: add             x16, PP, #0x2b, lsl #12  ; [pp+0x2b4a0] Obj!MessageLevel@b66831
    //     0xb6e56c: ldr             x16, [x16, #0x4a0]
    // 0xb6e570: cmp             w2, w16
    // 0xb6e574: b.ne            #0xb6e580
    // 0xb6e578: r0 = true
    //     0xb6e578: add             x0, NULL, #0x20  ; true
    // 0xb6e57c: b               #0xb6e584
    // 0xb6e580: r0 = false
    //     0xb6e580: add             x0, NULL, #0x30  ; false
    // 0xb6e584: ret
    //     0xb6e584: ret             
  }
}

// class id: 4739, size: 0x18, field offset: 0x8
class Message extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xac4e6c, size: 0x194
    // 0xac4e6c: EnterFrame
    //     0xac4e6c: stp             fp, lr, [SP, #-0x10]!
    //     0xac4e70: mov             fp, SP
    // 0xac4e74: AllocStack(0x18)
    //     0xac4e74: sub             SP, SP, #0x18
    // 0xac4e78: CheckStackOverflow
    //     0xac4e78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xac4e7c: cmp             SP, x16
    //     0xac4e80: b.ls            #0xac4ff8
    // 0xac4e84: r0 = StringBuffer()
    //     0xac4e84: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xac4e88: stur            x0, [fp, #-8]
    // 0xac4e8c: SaveReg r0
    //     0xac4e8c: str             x0, [SP, #-8]!
    // 0xac4e90: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xac4e90: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xac4e94: r0 = StringBuffer()
    //     0xac4e94: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0xac4e98: add             SP, SP, #8
    // 0xac4e9c: ldr             x0, [fp, #0x10]
    // 0xac4ea0: LoadField: r1 = r0->field_13
    //     0xac4ea0: ldur            w1, [x0, #0x13]
    // 0xac4ea4: DecompressPointer r1
    //     0xac4ea4: add             x1, x1, HEAP, lsl #32
    // 0xac4ea8: tbnz            w1, #4, #0xac4ecc
    // 0xac4eac: LoadField: r1 = r0->field_7
    //     0xac4eac: ldur            w1, [x0, #7]
    // 0xac4eb0: DecompressPointer r1
    //     0xac4eb0: add             x1, x1, HEAP, lsl #32
    // 0xac4eb4: r16 = _ConstMap len:3
    //     0xac4eb4: add             x16, PP, #0x38, lsl #12  ; [pp+0x38628] Map<MessageLevel, String>(3)
    //     0xac4eb8: ldr             x16, [x16, #0x628]
    // 0xac4ebc: stp             x1, x16, [SP, #-0x10]!
    // 0xac4ec0: r0 = containsKey()
    //     0xac4ec0: bl              #0xca6728  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::containsKey
    // 0xac4ec4: add             SP, SP, #0x10
    // 0xac4ec8: b               #0xac4ed0
    // 0xac4ecc: r0 = false
    //     0xac4ecc: add             x0, NULL, #0x30  ; false
    // 0xac4ed0: stur            x0, [fp, #-0x10]
    // 0xac4ed4: tbnz            w0, #4, #0xac4f00
    // 0xac4ed8: ldr             x1, [fp, #0x10]
    // 0xac4edc: LoadField: r2 = r1->field_7
    //     0xac4edc: ldur            w2, [x1, #7]
    // 0xac4ee0: DecompressPointer r2
    //     0xac4ee0: add             x2, x2, HEAP, lsl #32
    // 0xac4ee4: r16 = _ConstMap len:3
    //     0xac4ee4: add             x16, PP, #0x38, lsl #12  ; [pp+0x38628] Map<MessageLevel, String>(3)
    //     0xac4ee8: ldr             x16, [x16, #0x628]
    // 0xac4eec: stp             x2, x16, [SP, #-0x10]!
    // 0xac4ef0: r0 = []()
    //     0xac4ef0: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xac4ef4: add             SP, SP, #0x10
    // 0xac4ef8: mov             x1, x0
    // 0xac4efc: b               #0xac4f04
    // 0xac4f00: r1 = Null
    //     0xac4f00: mov             x1, NULL
    // 0xac4f04: ldur            x0, [fp, #-0x10]
    // 0xac4f08: stur            x1, [fp, #-0x18]
    // 0xac4f0c: tbnz            w0, #4, #0xac4f20
    // 0xac4f10: ldur            x16, [fp, #-8]
    // 0xac4f14: stp             x1, x16, [SP, #-0x10]!
    // 0xac4f18: r0 = write()
    //     0xac4f18: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xac4f1c: add             SP, SP, #0x10
    // 0xac4f20: ldr             x1, [fp, #0x10]
    // 0xac4f24: ldur            x0, [fp, #-0x10]
    // 0xac4f28: LoadField: r2 = r1->field_7
    //     0xac4f28: ldur            w2, [x1, #7]
    // 0xac4f2c: DecompressPointer r2
    //     0xac4f2c: add             x2, x2, HEAP, lsl #32
    // 0xac4f30: r16 = _ConstMap len:3
    //     0xac4f30: add             x16, PP, #0x38, lsl #12  ; [pp+0x38630] Map<MessageLevel, String>(3)
    //     0xac4f34: ldr             x16, [x16, #0x630]
    // 0xac4f38: stp             x2, x16, [SP, #-0x10]!
    // 0xac4f3c: r0 = []()
    //     0xac4f3c: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xac4f40: add             SP, SP, #0x10
    // 0xac4f44: ldur            x16, [fp, #-8]
    // 0xac4f48: stp             x0, x16, [SP, #-0x10]!
    // 0xac4f4c: r0 = write()
    //     0xac4f4c: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xac4f50: add             SP, SP, #0x10
    // 0xac4f54: ldur            x16, [fp, #-8]
    // 0xac4f58: r30 = " "
    //     0xac4f58: ldr             lr, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xac4f5c: stp             lr, x16, [SP, #-0x10]!
    // 0xac4f60: r0 = write()
    //     0xac4f60: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xac4f64: add             SP, SP, #0x10
    // 0xac4f68: ldur            x0, [fp, #-0x10]
    // 0xac4f6c: tbnz            w0, #4, #0xac4f88
    // 0xac4f70: ldur            x16, [fp, #-8]
    // 0xac4f74: r30 = "[0m"
    //     0xac4f74: add             lr, PP, #0x1b, lsl #12  ; [pp+0x1be48] "[0m"
    //     0xac4f78: ldr             lr, [lr, #0xe48]
    // 0xac4f7c: stp             lr, x16, [SP, #-0x10]!
    // 0xac4f80: r0 = write()
    //     0xac4f80: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xac4f84: add             SP, SP, #0x10
    // 0xac4f88: ldr             x0, [fp, #0x10]
    // 0xac4f8c: ldur            x16, [fp, #-8]
    // 0xac4f90: r30 = "on "
    //     0xac4f90: add             lr, PP, #0x38, lsl #12  ; [pp+0x38638] "on "
    //     0xac4f94: ldr             lr, [lr, #0x638]
    // 0xac4f98: stp             lr, x16, [SP, #-0x10]!
    // 0xac4f9c: r0 = write()
    //     0xac4f9c: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xac4fa0: add             SP, SP, #0x10
    // 0xac4fa4: ldr             x0, [fp, #0x10]
    // 0xac4fa8: LoadField: r1 = r0->field_f
    //     0xac4fa8: ldur            w1, [x0, #0xf]
    // 0xac4fac: DecompressPointer r1
    //     0xac4fac: add             x1, x1, HEAP, lsl #32
    // 0xac4fb0: LoadField: r2 = r0->field_b
    //     0xac4fb0: ldur            w2, [x0, #0xb]
    // 0xac4fb4: DecompressPointer r2
    //     0xac4fb4: add             x2, x2, HEAP, lsl #32
    // 0xac4fb8: stp             x2, x1, [SP, #-0x10]!
    // 0xac4fbc: ldur            x16, [fp, #-0x18]
    // 0xac4fc0: SaveReg r16
    //     0xac4fc0: str             x16, [SP, #-8]!
    // 0xac4fc4: r0 = message()
    //     0xac4fc4: bl              #0xac5000  ; [package:source_span/src/span_mixin.dart] SourceSpanMixin::message
    // 0xac4fc8: add             SP, SP, #0x18
    // 0xac4fcc: ldur            x16, [fp, #-8]
    // 0xac4fd0: stp             x0, x16, [SP, #-0x10]!
    // 0xac4fd4: r0 = write()
    //     0xac4fd4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xac4fd8: add             SP, SP, #0x10
    // 0xac4fdc: ldur            x16, [fp, #-8]
    // 0xac4fe0: SaveReg r16
    //     0xac4fe0: str             x16, [SP, #-8]!
    // 0xac4fe4: r0 = toString()
    //     0xac4fe4: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0xac4fe8: add             SP, SP, #8
    // 0xac4fec: LeaveFrame
    //     0xac4fec: mov             SP, fp
    //     0xac4ff0: ldp             fp, lr, [SP], #0x10
    // 0xac4ff4: ret
    //     0xac4ff4: ret             
    // 0xac4ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xac4ff8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xac4ffc: b               #0xac4e84
  }
}

// class id: 6013, size: 0x14, field offset: 0x14
enum MessageLevel extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15334, size: 0x5c
    // 0xb15334: EnterFrame
    //     0xb15334: stp             fp, lr, [SP, #-0x10]!
    //     0xb15338: mov             fp, SP
    // 0xb1533c: CheckStackOverflow
    //     0xb1533c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15340: cmp             SP, x16
    //     0xb15344: b.ls            #0xb15388
    // 0xb15348: r1 = Null
    //     0xb15348: mov             x1, NULL
    // 0xb1534c: r2 = 4
    //     0xb1534c: mov             x2, #4
    // 0xb15350: r0 = AllocateArray()
    //     0xb15350: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15354: r17 = "MessageLevel."
    //     0xb15354: add             x17, PP, #0x38, lsl #12  ; [pp+0x38640] "MessageLevel."
    //     0xb15358: ldr             x17, [x17, #0x640]
    // 0xb1535c: StoreField: r0->field_f = r17
    //     0xb1535c: stur            w17, [x0, #0xf]
    // 0xb15360: ldr             x1, [fp, #0x10]
    // 0xb15364: LoadField: r2 = r1->field_f
    //     0xb15364: ldur            w2, [x1, #0xf]
    // 0xb15368: DecompressPointer r2
    //     0xb15368: add             x2, x2, HEAP, lsl #32
    // 0xb1536c: StoreField: r0->field_13 = r2
    //     0xb1536c: stur            w2, [x0, #0x13]
    // 0xb15370: SaveReg r0
    //     0xb15370: str             x0, [SP, #-8]!
    // 0xb15374: r0 = _interpolate()
    //     0xb15374: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15378: add             SP, SP, #8
    // 0xb1537c: LeaveFrame
    //     0xb1537c: mov             SP, fp
    //     0xb15380: ldp             fp, lr, [SP], #0x10
    // 0xb15384: ret
    //     0xb15384: ret             
    // 0xb15388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15388: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1538c: b               #0xb15348
  }
}

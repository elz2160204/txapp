// lib: , url: package:csslib/src/preprocessor_options.dart

// class id: 1048825, size: 0x8
class :: {
}

// class id: 4737, size: 0x1c, field offset: 0x8
//   const constructor, 
class PreprocessorOptions extends Object {
}

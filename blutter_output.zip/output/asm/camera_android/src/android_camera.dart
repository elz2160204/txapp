// lib: , url: package:camera_android/src/android_camera.dart

// class id: 1048705, size: 0x8
class :: {
}

// class id: 4959, size: 0x1c, field offset: 0x8
class AndroidCamera extends CameraPlatform {

  late final StreamController<DeviceEvent> _deviceEventStreamController; // offset: 0x10

  _ _cameraEvents(/* No info */) {
    // ** addr: 0x5aa63c, size: 0xac
    // 0x5aa63c: EnterFrame
    //     0x5aa63c: stp             fp, lr, [SP, #-0x10]!
    //     0x5aa640: mov             fp, SP
    // 0x5aa644: AllocStack(0x18)
    //     0x5aa644: sub             SP, SP, #0x18
    // 0x5aa648: CheckStackOverflow
    //     0x5aa648: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5aa64c: cmp             SP, x16
    //     0x5aa650: b.ls            #0x5aa6e0
    // 0x5aa654: ldr             x2, [fp, #0x10]
    // 0x5aa658: r0 = BoxInt64Instr(r2)
    //     0x5aa658: sbfiz           x0, x2, #1, #0x1f
    //     0x5aa65c: cmp             x2, x0, asr #1
    //     0x5aa660: b.eq            #0x5aa66c
    //     0x5aa664: bl              #0xd69bb8
    //     0x5aa668: stur            x2, [x0, #7]
    // 0x5aa66c: stur            x0, [fp, #-8]
    // 0x5aa670: r1 = 1
    //     0x5aa670: mov             x1, #1
    // 0x5aa674: r0 = AllocateContext()
    //     0x5aa674: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5aa678: mov             x2, x0
    // 0x5aa67c: ldur            x0, [fp, #-8]
    // 0x5aa680: stur            x2, [fp, #-0x10]
    // 0x5aa684: StoreField: r2->field_f = r0
    //     0x5aa684: stur            w0, [x2, #0xf]
    // 0x5aa688: ldr             x0, [fp, #0x18]
    // 0x5aa68c: LoadField: r3 = r0->field_b
    //     0x5aa68c: ldur            w3, [x0, #0xb]
    // 0x5aa690: DecompressPointer r3
    //     0x5aa690: add             x3, x3, HEAP, lsl #32
    // 0x5aa694: stur            x3, [fp, #-8]
    // 0x5aa698: LoadField: r1 = r3->field_7
    //     0x5aa698: ldur            w1, [x3, #7]
    // 0x5aa69c: DecompressPointer r1
    //     0x5aa69c: add             x1, x1, HEAP, lsl #32
    // 0x5aa6a0: r0 = _BroadcastStream()
    //     0x5aa6a0: bl              #0x5a25c8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x14)
    // 0x5aa6a4: mov             x3, x0
    // 0x5aa6a8: ldur            x0, [fp, #-8]
    // 0x5aa6ac: stur            x3, [fp, #-0x18]
    // 0x5aa6b0: StoreField: r3->field_f = r0
    //     0x5aa6b0: stur            w0, [x3, #0xf]
    // 0x5aa6b4: ldur            x2, [fp, #-0x10]
    // 0x5aa6b8: r1 = Function '<anonymous closure>':.
    //     0x5aa6b8: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d4e0] AnonymousClosure: (0x5aa750), in [package:camera_android/src/android_camera.dart] AndroidCamera::_cameraEvents (0x5aa63c)
    //     0x5aa6bc: ldr             x1, [x1, #0x4e0]
    // 0x5aa6c0: r0 = AllocateClosure()
    //     0x5aa6c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5aa6c4: ldur            x16, [fp, #-0x18]
    // 0x5aa6c8: stp             x0, x16, [SP, #-0x10]!
    // 0x5aa6cc: r0 = where()
    //     0x5aa6cc: bl              #0x5aa6e8  ; [dart:async] Stream::where
    // 0x5aa6d0: add             SP, SP, #0x10
    // 0x5aa6d4: LeaveFrame
    //     0x5aa6d4: mov             SP, fp
    //     0x5aa6d8: ldp             fp, lr, [SP], #0x10
    // 0x5aa6dc: ret
    //     0x5aa6dc: ret             
    // 0x5aa6e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5aa6e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5aa6e4: b               #0x5aa654
  }
  [closure] bool <anonymous closure>(dynamic, CameraEvent) {
    // ** addr: 0x5aa750, size: 0x94
    // 0x5aa750: EnterFrame
    //     0x5aa750: stp             fp, lr, [SP, #-0x10]!
    //     0x5aa754: mov             fp, SP
    // 0x5aa758: ldr             x2, [fp, #0x18]
    // 0x5aa75c: LoadField: r3 = r2->field_17
    //     0x5aa75c: ldur            w3, [x2, #0x17]
    // 0x5aa760: DecompressPointer r3
    //     0x5aa760: add             x3, x3, HEAP, lsl #32
    // 0x5aa764: ldr             x2, [fp, #0x10]
    // 0x5aa768: LoadField: r4 = r2->field_7
    //     0x5aa768: ldur            x4, [x2, #7]
    // 0x5aa76c: LoadField: r2 = r3->field_f
    //     0x5aa76c: ldur            w2, [x3, #0xf]
    // 0x5aa770: DecompressPointer r2
    //     0x5aa770: add             x2, x2, HEAP, lsl #32
    // 0x5aa774: r0 = BoxInt64Instr(r4)
    //     0x5aa774: sbfiz           x0, x4, #1, #0x1f
    //     0x5aa778: cmp             x4, x0, asr #1
    //     0x5aa77c: b.eq            #0x5aa788
    //     0x5aa780: bl              #0xd69bb8
    //     0x5aa784: stur            x4, [x0, #7]
    // 0x5aa788: cmp             w0, w2
    // 0x5aa78c: b.eq            #0x5aa7d0
    // 0x5aa790: and             w16, w0, w2
    // 0x5aa794: branchIfSmi(r16, 0x5aa7c8)
    //     0x5aa794: tbz             w16, #0, #0x5aa7c8
    // 0x5aa798: r16 = LoadClassIdInstr(r0)
    //     0x5aa798: ldur            x16, [x0, #-1]
    //     0x5aa79c: ubfx            x16, x16, #0xc, #0x14
    // 0x5aa7a0: cmp             x16, #0x3c
    // 0x5aa7a4: b.ne            #0x5aa7c8
    // 0x5aa7a8: r16 = LoadClassIdInstr(r2)
    //     0x5aa7a8: ldur            x16, [x2, #-1]
    //     0x5aa7ac: ubfx            x16, x16, #0xc, #0x14
    // 0x5aa7b0: cmp             x16, #0x3c
    // 0x5aa7b4: b.ne            #0x5aa7c8
    // 0x5aa7b8: LoadField: r16 = r0->field_7
    //     0x5aa7b8: ldur            x16, [x0, #7]
    // 0x5aa7bc: LoadField: r17 = r2->field_7
    //     0x5aa7bc: ldur            x17, [x2, #7]
    // 0x5aa7c0: cmp             x16, x17
    // 0x5aa7c4: b.eq            #0x5aa7d0
    // 0x5aa7c8: r1 = false
    //     0x5aa7c8: add             x1, NULL, #0x30  ; false
    // 0x5aa7cc: b               #0x5aa7d4
    // 0x5aa7d0: r1 = true
    //     0x5aa7d0: add             x1, NULL, #0x20  ; true
    // 0x5aa7d4: mov             x0, x1
    // 0x5aa7d8: LeaveFrame
    //     0x5aa7d8: mov             SP, fp
    //     0x5aa7dc: ldp             fp, lr, [SP], #0x10
    // 0x5aa7e0: ret
    //     0x5aa7e0: ret             
  }
  StreamController<DeviceEvent> _deviceEventStreamController(AndroidCamera) {
    // ** addr: 0x5ab85c, size: 0x38
    // 0x5ab85c: EnterFrame
    //     0x5ab85c: stp             fp, lr, [SP, #-0x10]!
    //     0x5ab860: mov             fp, SP
    // 0x5ab864: CheckStackOverflow
    //     0x5ab864: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ab868: cmp             SP, x16
    //     0x5ab86c: b.ls            #0x5ab88c
    // 0x5ab870: ldr             x16, [fp, #0x10]
    // 0x5ab874: SaveReg r16
    //     0x5ab874: str             x16, [SP, #-8]!
    // 0x5ab878: r0 = _createDeviceEventStreamController()
    //     0x5ab878: bl              #0x5ab894  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_createDeviceEventStreamController
    // 0x5ab87c: add             SP, SP, #8
    // 0x5ab880: LeaveFrame
    //     0x5ab880: mov             SP, fp
    //     0x5ab884: ldp             fp, lr, [SP], #0x10
    // 0x5ab888: ret
    //     0x5ab888: ret             
    // 0x5ab88c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ab88c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ab890: b               #0x5ab870
  }
  StreamController<DeviceEvent> _createDeviceEventStreamController(AndroidCamera) {
    // ** addr: 0x5ab894, size: 0x74
    // 0x5ab894: EnterFrame
    //     0x5ab894: stp             fp, lr, [SP, #-0x10]!
    //     0x5ab898: mov             fp, SP
    // 0x5ab89c: CheckStackOverflow
    //     0x5ab89c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ab8a0: cmp             SP, x16
    //     0x5ab8a4: b.ls            #0x5ab900
    // 0x5ab8a8: r1 = 1
    //     0x5ab8a8: mov             x1, #1
    // 0x5ab8ac: r0 = AllocateContext()
    //     0x5ab8ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5ab8b0: mov             x1, x0
    // 0x5ab8b4: ldr             x0, [fp, #0x10]
    // 0x5ab8b8: StoreField: r1->field_f = r0
    //     0x5ab8b8: stur            w0, [x1, #0xf]
    // 0x5ab8bc: mov             x2, x1
    // 0x5ab8c0: r1 = Function '_handleDeviceMethodCall@172119562':.
    //     0x5ab8c0: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d410] AnonymousClosure: (0x5ab908), in [package:camera_android/src/android_camera.dart] AndroidCamera::_handleDeviceMethodCall (0x5ab954)
    //     0x5ab8c4: ldr             x1, [x1, #0x410]
    // 0x5ab8c8: r0 = AllocateClosure()
    //     0x5ab8c8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5ab8cc: r16 = Instance_MethodChannel
    //     0x5ab8cc: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d418] Obj!MethodChannel@b34bd1
    //     0x5ab8d0: ldr             x16, [x16, #0x418]
    // 0x5ab8d4: stp             x0, x16, [SP, #-0x10]!
    // 0x5ab8d8: r0 = setMethodCallHandler()
    //     0x5ab8d8: bl              #0x5a84a0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0x5ab8dc: add             SP, SP, #0x10
    // 0x5ab8e0: r16 = <DeviceEvent>
    //     0x5ab8e0: ldr             x16, [PP, #0xdc0]  ; [pp+0xdc0] TypeArguments: <DeviceEvent>
    // 0x5ab8e4: SaveReg r16
    //     0x5ab8e4: str             x16, [SP, #-8]!
    // 0x5ab8e8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5ab8e8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5ab8ec: r0 = StreamController.broadcast()
    //     0x5ab8ec: bl              #0x5a25d4  ; [dart:async] StreamController::StreamController.broadcast
    // 0x5ab8f0: add             SP, SP, #8
    // 0x5ab8f4: LeaveFrame
    //     0x5ab8f4: mov             SP, fp
    //     0x5ab8f8: ldp             fp, lr, [SP], #0x10
    // 0x5ab8fc: ret
    //     0x5ab8fc: ret             
    // 0x5ab900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ab900: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ab904: b               #0x5ab8a8
  }
  [closure] Future<dynamic> _handleDeviceMethodCall(dynamic, MethodCall) {
    // ** addr: 0x5ab908, size: 0x4c
    // 0x5ab908: EnterFrame
    //     0x5ab908: stp             fp, lr, [SP, #-0x10]!
    //     0x5ab90c: mov             fp, SP
    // 0x5ab910: ldr             x0, [fp, #0x18]
    // 0x5ab914: LoadField: r1 = r0->field_17
    //     0x5ab914: ldur            w1, [x0, #0x17]
    // 0x5ab918: DecompressPointer r1
    //     0x5ab918: add             x1, x1, HEAP, lsl #32
    // 0x5ab91c: CheckStackOverflow
    //     0x5ab91c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ab920: cmp             SP, x16
    //     0x5ab924: b.ls            #0x5ab94c
    // 0x5ab928: LoadField: r0 = r1->field_f
    //     0x5ab928: ldur            w0, [x1, #0xf]
    // 0x5ab92c: DecompressPointer r0
    //     0x5ab92c: add             x0, x0, HEAP, lsl #32
    // 0x5ab930: ldr             x16, [fp, #0x10]
    // 0x5ab934: stp             x16, x0, [SP, #-0x10]!
    // 0x5ab938: r0 = _handleDeviceMethodCall()
    //     0x5ab938: bl              #0x5ab954  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_handleDeviceMethodCall
    // 0x5ab93c: add             SP, SP, #0x10
    // 0x5ab940: LeaveFrame
    //     0x5ab940: mov             SP, fp
    //     0x5ab944: ldp             fp, lr, [SP], #0x10
    // 0x5ab948: ret
    //     0x5ab948: ret             
    // 0x5ab94c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ab94c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ab950: b               #0x5ab928
  }
  _ _handleDeviceMethodCall(/* No info */) async {
    // ** addr: 0x5ab954, size: 0x168
    // 0x5ab954: EnterFrame
    //     0x5ab954: stp             fp, lr, [SP, #-0x10]!
    //     0x5ab958: mov             fp, SP
    // 0x5ab95c: AllocStack(0x18)
    //     0x5ab95c: sub             SP, SP, #0x18
    // 0x5ab960: SetupParameters(AndroidCamera this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0x5ab960: stur            NULL, [fp, #-8]
    //     0x5ab964: mov             x0, #0
    //     0x5ab968: add             x1, fp, w0, sxtw #2
    //     0x5ab96c: ldr             x1, [x1, #0x18]
    //     0x5ab970: stur            x1, [fp, #-0x18]
    //     0x5ab974: add             x2, fp, w0, sxtw #2
    //     0x5ab978: ldr             x2, [x2, #0x10]
    //     0x5ab97c: stur            x2, [fp, #-0x10]
    // 0x5ab980: CheckStackOverflow
    //     0x5ab980: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ab984: cmp             SP, x16
    //     0x5ab988: b.ls            #0x5abab0
    // 0x5ab98c: InitAsync() -> Future
    //     0x5ab98c: mov             x0, NULL
    //     0x5ab990: bl              #0x4b92e4
    // 0x5ab994: ldur            x0, [fp, #-0x10]
    // 0x5ab998: LoadField: r1 = r0->field_7
    //     0x5ab998: ldur            w1, [x0, #7]
    // 0x5ab99c: DecompressPointer r1
    //     0x5ab99c: add             x1, x1, HEAP, lsl #32
    // 0x5ab9a0: r16 = "orientation_changed"
    //     0x5ab9a0: ldr             x16, [PP, #0xdd8]  ; [pp+0xdd8] "orientation_changed"
    // 0x5ab9a4: stp             x1, x16, [SP, #-0x10]!
    // 0x5ab9a8: r0 = ==()
    //     0x5ab9a8: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x5ab9ac: add             SP, SP, #0x10
    // 0x5ab9b0: tbnz            w0, #4, #0x5abaa4
    // 0x5ab9b4: ldur            x16, [fp, #-0x18]
    // 0x5ab9b8: ldur            lr, [fp, #-0x10]
    // 0x5ab9bc: stp             lr, x16, [SP, #-0x10]!
    // 0x5ab9c0: r0 = _getArgumentDictionary()
    //     0x5ab9c0: bl              #0x5ababc  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_getArgumentDictionary
    // 0x5ab9c4: add             SP, SP, #0x10
    // 0x5ab9c8: ldur            x1, [fp, #-0x18]
    // 0x5ab9cc: stur            x0, [fp, #-0x10]
    // 0x5ab9d0: LoadField: r0 = r1->field_f
    //     0x5ab9d0: ldur            w0, [x1, #0xf]
    // 0x5ab9d4: DecompressPointer r0
    //     0x5ab9d4: add             x0, x0, HEAP, lsl #32
    // 0x5ab9d8: r16 = Sentinel
    //     0x5ab9d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5ab9dc: cmp             w0, w16
    // 0x5ab9e0: b.ne            #0x5ab9f0
    // 0x5ab9e4: r2 = _deviceEventStreamController
    //     0x5ab9e4: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d398] Field <AndroidCamera._deviceEventStreamController@172119562>: late final (offset: 0x10)
    //     0x5ab9e8: ldr             x2, [x2, #0x398]
    // 0x5ab9ec: r0 = InitLateFinalInstanceField()
    //     0x5ab9ec: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x5ab9f0: mov             x1, x0
    // 0x5ab9f4: ldur            x0, [fp, #-0x10]
    // 0x5ab9f8: stur            x1, [fp, #-0x18]
    // 0x5ab9fc: r2 = LoadClassIdInstr(r0)
    //     0x5ab9fc: ldur            x2, [x0, #-1]
    //     0x5aba00: ubfx            x2, x2, #0xc, #0x14
    // 0x5aba04: r16 = "orientation"
    //     0x5aba04: ldr             x16, [PP, #0xde0]  ; [pp+0xde0] "orientation"
    // 0x5aba08: stp             x16, x0, [SP, #-0x10]!
    // 0x5aba0c: mov             x0, x2
    // 0x5aba10: r0 = GDT[cid_x0 + -0xef]()
    //     0x5aba10: sub             lr, x0, #0xef
    //     0x5aba14: ldr             lr, [x21, lr, lsl #3]
    //     0x5aba18: blr             lr
    // 0x5aba1c: add             SP, SP, #0x10
    // 0x5aba20: mov             x3, x0
    // 0x5aba24: stur            x3, [fp, #-0x10]
    // 0x5aba28: cmp             w3, NULL
    // 0x5aba2c: b.eq            #0x5abab8
    // 0x5aba30: mov             x0, x3
    // 0x5aba34: r2 = Null
    //     0x5aba34: mov             x2, NULL
    // 0x5aba38: r1 = Null
    //     0x5aba38: mov             x1, NULL
    // 0x5aba3c: r4 = 59
    //     0x5aba3c: mov             x4, #0x3b
    // 0x5aba40: branchIfSmi(r0, 0x5aba4c)
    //     0x5aba40: tbz             w0, #0, #0x5aba4c
    // 0x5aba44: r4 = LoadClassIdInstr(r0)
    //     0x5aba44: ldur            x4, [x0, #-1]
    //     0x5aba48: ubfx            x4, x4, #0xc, #0x14
    // 0x5aba4c: sub             x4, x4, #0x5d
    // 0x5aba50: cmp             x4, #3
    // 0x5aba54: b.ls            #0x5aba68
    // 0x5aba58: r8 = String
    //     0x5aba58: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x5aba5c: r3 = Null
    //     0x5aba5c: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d420] Null
    //     0x5aba60: ldr             x3, [x3, #0x420]
    // 0x5aba64: r0 = String()
    //     0x5aba64: bl              #0xd72afc  ; IsType_String_Stub
    // 0x5aba68: ldur            x16, [fp, #-0x10]
    // 0x5aba6c: SaveReg r16
    //     0x5aba6c: str             x16, [SP, #-8]!
    // 0x5aba70: r0 = deserializeDeviceOrientation()
    //     0x5aba70: bl              #0x5a89d0  ; [package:camera_android/src/utils.dart] ::deserializeDeviceOrientation
    // 0x5aba74: add             SP, SP, #8
    // 0x5aba78: stur            x0, [fp, #-0x10]
    // 0x5aba7c: r0 = DeviceOrientationChangedEvent()
    //     0x5aba7c: bl              #0x5a88f4  ; AllocateDeviceOrientationChangedEventStub -> DeviceOrientationChangedEvent (size=0xc)
    // 0x5aba80: mov             x1, x0
    // 0x5aba84: ldur            x0, [fp, #-0x10]
    // 0x5aba88: StoreField: r1->field_7 = r0
    //     0x5aba88: stur            w0, [x1, #7]
    // 0x5aba8c: ldur            x16, [fp, #-0x18]
    // 0x5aba90: stp             x1, x16, [SP, #-0x10]!
    // 0x5aba94: r0 = add()
    //     0x5aba94: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0x5aba98: add             SP, SP, #0x10
    // 0x5aba9c: r0 = Null
    //     0x5aba9c: mov             x0, NULL
    // 0x5abaa0: r0 = ReturnAsyncNotFuture()
    //     0x5abaa0: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x5abaa4: r0 = MissingPluginException()
    //     0x5abaa4: bl              #0x501aa4  ; AllocateMissingPluginExceptionStub -> MissingPluginException (size=0xc)
    // 0x5abaa8: r0 = Throw()
    //     0x5abaa8: bl              #0xd67e38  ; ThrowStub
    // 0x5abaac: brk             #0
    // 0x5abab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5abab0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5abab4: b               #0x5ab98c
    // 0x5abab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5abab8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getArgumentDictionary(/* No info */) {
    // ** addr: 0x5ababc, size: 0x84
    // 0x5ababc: EnterFrame
    //     0x5ababc: stp             fp, lr, [SP, #-0x10]!
    //     0x5abac0: mov             fp, SP
    // 0x5abac4: AllocStack(0x8)
    //     0x5abac4: sub             SP, SP, #8
    // 0x5abac8: CheckStackOverflow
    //     0x5abac8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5abacc: cmp             SP, x16
    //     0x5abad0: b.ls            #0x5abb38
    // 0x5abad4: ldr             x0, [fp, #0x10]
    // 0x5abad8: LoadField: r3 = r0->field_b
    //     0x5abad8: ldur            w3, [x0, #0xb]
    // 0x5abadc: DecompressPointer r3
    //     0x5abadc: add             x3, x3, HEAP, lsl #32
    // 0x5abae0: mov             x0, x3
    // 0x5abae4: stur            x3, [fp, #-8]
    // 0x5abae8: r2 = Null
    //     0x5abae8: mov             x2, NULL
    // 0x5abaec: r1 = Null
    //     0x5abaec: mov             x1, NULL
    // 0x5abaf0: r8 = Map<Object?, Object?>
    //     0x5abaf0: ldr             x8, [PP, #0xe70]  ; [pp+0xe70] Type: Map<Object?, Object?>
    // 0x5abaf4: r3 = Null
    //     0x5abaf4: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d430] Null
    //     0x5abaf8: ldr             x3, [x3, #0x430]
    // 0x5abafc: r0 = Map<Object?, Object?>()
    //     0x5abafc: bl              #0x5a8b90  ; IsType_Map<Object?, Object?>_Stub
    // 0x5abb00: ldur            x0, [fp, #-8]
    // 0x5abb04: r1 = LoadClassIdInstr(r0)
    //     0x5abb04: ldur            x1, [x0, #-1]
    //     0x5abb08: ubfx            x1, x1, #0xc, #0x14
    // 0x5abb0c: r16 = <String, Object?>
    //     0x5abb0c: ldr             x16, [PP, #0xe88]  ; [pp+0xe88] TypeArguments: <String, Object?>
    // 0x5abb10: stp             x0, x16, [SP, #-0x10]!
    // 0x5abb14: mov             x0, x1
    // 0x5abb18: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x5abb18: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x5abb1c: r0 = GDT[cid_x0 + 0x375]()
    //     0x5abb1c: add             lr, x0, #0x375
    //     0x5abb20: ldr             lr, [x21, lr, lsl #3]
    //     0x5abb24: blr             lr
    // 0x5abb28: add             SP, SP, #0x10
    // 0x5abb2c: LeaveFrame
    //     0x5abb2c: mov             SP, fp
    //     0x5abb30: ldp             fp, lr, [SP], #0x10
    // 0x5abb34: ret
    //     0x5abb34: ret             
    // 0x5abb38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5abb38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5abb3c: b               #0x5abad4
  }
  _ resumePreview(/* No info */) async {
    // ** addr: 0xc5f218, size: 0xc0
    // 0xc5f218: EnterFrame
    //     0xc5f218: stp             fp, lr, [SP, #-0x10]!
    //     0xc5f21c: mov             fp, SP
    // 0xc5f220: AllocStack(0x18)
    //     0xc5f220: sub             SP, SP, #0x18
    // 0xc5f224: SetupParameters(AndroidCamera this /* r1, fp-0x10 */)
    //     0xc5f224: stur            NULL, [fp, #-8]
    //     0xc5f228: mov             x0, #0
    //     0xc5f22c: add             x1, fp, w0, sxtw #2
    //     0xc5f230: ldr             x1, [x1, #0x10]
    //     0xc5f234: stur            x1, [fp, #-0x10]
    // 0xc5f238: CheckStackOverflow
    //     0xc5f238: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5f23c: cmp             SP, x16
    //     0xc5f240: b.ls            #0xc5f2d0
    // 0xc5f244: InitAsync() -> Future<void?>
    //     0xc5f244: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc5f248: bl              #0x4b92e4
    // 0xc5f24c: r1 = Null
    //     0xc5f24c: mov             x1, NULL
    // 0xc5f250: r2 = 4
    //     0xc5f250: mov             x2, #4
    // 0xc5f254: r0 = AllocateArray()
    //     0xc5f254: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5f258: mov             x2, x0
    // 0xc5f25c: r17 = "cameraId"
    //     0xc5f25c: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5f260: ldr             x17, [x17, #0x890]
    // 0xc5f264: StoreField: r2->field_f = r17
    //     0xc5f264: stur            w17, [x2, #0xf]
    // 0xc5f268: ldur            x3, [fp, #-0x10]
    // 0xc5f26c: r0 = BoxInt64Instr(r3)
    //     0xc5f26c: sbfiz           x0, x3, #1, #0x1f
    //     0xc5f270: cmp             x3, x0, asr #1
    //     0xc5f274: b.eq            #0xc5f280
    //     0xc5f278: bl              #0xd69bb8
    //     0xc5f27c: stur            x3, [x0, #7]
    // 0xc5f280: StoreField: r2->field_13 = r0
    //     0xc5f280: stur            w0, [x2, #0x13]
    // 0xc5f284: r16 = <String, dynamic>
    //     0xc5f284: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5f288: stp             x2, x16, [SP, #-0x10]!
    // 0xc5f28c: r0 = Map._fromLiteral()
    //     0xc5f28c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5f290: add             SP, SP, #0x10
    // 0xc5f294: r16 = <double>
    //     0xc5f294: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5f298: r30 = Instance_MethodChannel
    //     0xc5f298: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc5f29c: ldr             lr, [lr, #0x378]
    // 0xc5f2a0: stp             lr, x16, [SP, #-0x10]!
    // 0xc5f2a4: r16 = "resumePreview"
    //     0xc5f2a4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53ac8] "resumePreview"
    //     0xc5f2a8: ldr             x16, [x16, #0xac8]
    // 0xc5f2ac: stp             x0, x16, [SP, #-0x10]!
    // 0xc5f2b0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5f2b0: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5f2b4: r0 = invokeMethod()
    //     0xc5f2b4: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5f2b8: add             SP, SP, #0x20
    // 0xc5f2bc: mov             x1, x0
    // 0xc5f2c0: stur            x1, [fp, #-0x18]
    // 0xc5f2c4: r0 = Await()
    //     0xc5f2c4: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5f2c8: r0 = Null
    //     0xc5f2c8: mov             x0, NULL
    // 0xc5f2cc: r0 = ReturnAsyncNotFuture()
    //     0xc5f2cc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc5f2d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5f2d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5f2d4: b               #0xc5f244
  }
  _ pausePreview(/* No info */) async {
    // ** addr: 0xc5f458, size: 0xc0
    // 0xc5f458: EnterFrame
    //     0xc5f458: stp             fp, lr, [SP, #-0x10]!
    //     0xc5f45c: mov             fp, SP
    // 0xc5f460: AllocStack(0x18)
    //     0xc5f460: sub             SP, SP, #0x18
    // 0xc5f464: SetupParameters(AndroidCamera this /* r1, fp-0x10 */)
    //     0xc5f464: stur            NULL, [fp, #-8]
    //     0xc5f468: mov             x0, #0
    //     0xc5f46c: add             x1, fp, w0, sxtw #2
    //     0xc5f470: ldr             x1, [x1, #0x10]
    //     0xc5f474: stur            x1, [fp, #-0x10]
    // 0xc5f478: CheckStackOverflow
    //     0xc5f478: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5f47c: cmp             SP, x16
    //     0xc5f480: b.ls            #0xc5f510
    // 0xc5f484: InitAsync() -> Future<void?>
    //     0xc5f484: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc5f488: bl              #0x4b92e4
    // 0xc5f48c: r1 = Null
    //     0xc5f48c: mov             x1, NULL
    // 0xc5f490: r2 = 4
    //     0xc5f490: mov             x2, #4
    // 0xc5f494: r0 = AllocateArray()
    //     0xc5f494: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5f498: mov             x2, x0
    // 0xc5f49c: r17 = "cameraId"
    //     0xc5f49c: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5f4a0: ldr             x17, [x17, #0x890]
    // 0xc5f4a4: StoreField: r2->field_f = r17
    //     0xc5f4a4: stur            w17, [x2, #0xf]
    // 0xc5f4a8: ldur            x3, [fp, #-0x10]
    // 0xc5f4ac: r0 = BoxInt64Instr(r3)
    //     0xc5f4ac: sbfiz           x0, x3, #1, #0x1f
    //     0xc5f4b0: cmp             x3, x0, asr #1
    //     0xc5f4b4: b.eq            #0xc5f4c0
    //     0xc5f4b8: bl              #0xd69bb8
    //     0xc5f4bc: stur            x3, [x0, #7]
    // 0xc5f4c0: StoreField: r2->field_13 = r0
    //     0xc5f4c0: stur            w0, [x2, #0x13]
    // 0xc5f4c4: r16 = <String, dynamic>
    //     0xc5f4c4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5f4c8: stp             x2, x16, [SP, #-0x10]!
    // 0xc5f4cc: r0 = Map._fromLiteral()
    //     0xc5f4cc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5f4d0: add             SP, SP, #0x10
    // 0xc5f4d4: r16 = <double>
    //     0xc5f4d4: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5f4d8: r30 = Instance_MethodChannel
    //     0xc5f4d8: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc5f4dc: ldr             lr, [lr, #0x378]
    // 0xc5f4e0: stp             lr, x16, [SP, #-0x10]!
    // 0xc5f4e4: r16 = "pausePreview"
    //     0xc5f4e4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53ad0] "pausePreview"
    //     0xc5f4e8: ldr             x16, [x16, #0xad0]
    // 0xc5f4ec: stp             x0, x16, [SP, #-0x10]!
    // 0xc5f4f0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5f4f0: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5f4f4: r0 = invokeMethod()
    //     0xc5f4f4: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5f4f8: add             SP, SP, #0x20
    // 0xc5f4fc: mov             x1, x0
    // 0xc5f500: stur            x1, [fp, #-0x18]
    // 0xc5f504: r0 = Await()
    //     0xc5f504: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5f508: r0 = Null
    //     0xc5f508: mov             x0, NULL
    // 0xc5f50c: r0 = ReturnAsyncNotFuture()
    //     0xc5f50c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc5f510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5f510: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5f514: b               #0xc5f484
  }
  _ setZoomLevel(/* No info */) async {
    // ** addr: 0xc5f700, size: 0x184
    // 0xc5f700: EnterFrame
    //     0xc5f700: stp             fp, lr, [SP, #-0x10]!
    //     0xc5f704: mov             fp, SP
    // 0xc5f708: AllocStack(0x68)
    //     0xc5f708: sub             SP, SP, #0x68
    // 0xc5f70c: SetupParameters(AndroidCamera this /* r1, fp-0x60 */, dynamic _ /* r2, fp-0x58 */, dynamic _ /* d0, fp-0x68 */)
    //     0xc5f70c: stur            NULL, [fp, #-8]
    //     0xc5f710: mov             x0, #0
    //     0xc5f714: add             x1, fp, w0, sxtw #2
    //     0xc5f718: ldr             x1, [x1, #0x20]
    //     0xc5f71c: stur            x1, [fp, #-0x60]
    //     0xc5f720: add             x2, fp, w0, sxtw #2
    //     0xc5f724: ldr             x2, [x2, #0x18]
    //     0xc5f728: stur            x2, [fp, #-0x58]
    //     0xc5f72c: add             x3, fp, w0, sxtw #2
    //     0xc5f730: ldr             d0, [x3, #0x10]
    //     0xc5f734: stur            d0, [fp, #-0x68]
    // 0xc5f738: CheckStackOverflow
    //     0xc5f738: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5f73c: cmp             SP, x16
    //     0xc5f740: b.ls            #0xc5f860
    // 0xc5f744: InitAsync() -> Future<void?>
    //     0xc5f744: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc5f748: bl              #0x4b92e4
    // 0xc5f74c: ldur            x0, [fp, #-0x58]
    // 0xc5f750: ldur            d0, [fp, #-0x68]
    // 0xc5f754: r1 = Null
    //     0xc5f754: mov             x1, NULL
    // 0xc5f758: r2 = 8
    //     0xc5f758: mov             x2, #8
    // 0xc5f75c: r0 = AllocateArray()
    //     0xc5f75c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5f760: r17 = "cameraId"
    //     0xc5f760: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5f764: ldr             x17, [x17, #0x890]
    // 0xc5f768: StoreField: r0->field_f = r17
    //     0xc5f768: stur            w17, [x0, #0xf]
    // 0xc5f76c: ldur            x1, [fp, #-0x58]
    // 0xc5f770: StoreField: r0->field_13 = r1
    //     0xc5f770: stur            w1, [x0, #0x13]
    // 0xc5f774: r17 = "zoom"
    //     0xc5f774: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ad8] "zoom"
    //     0xc5f778: ldr             x17, [x17, #0xad8]
    // 0xc5f77c: StoreField: r0->field_17 = r17
    //     0xc5f77c: stur            w17, [x0, #0x17]
    // 0xc5f780: ldur            d0, [fp, #-0x68]
    // 0xc5f784: r1 = inline_Allocate_Double()
    //     0xc5f784: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc5f788: add             x1, x1, #0x10
    //     0xc5f78c: cmp             x2, x1
    //     0xc5f790: b.ls            #0xc5f868
    //     0xc5f794: str             x1, [THR, #0x60]  ; THR::top
    //     0xc5f798: sub             x1, x1, #0xf
    //     0xc5f79c: mov             x2, #0xd108
    //     0xc5f7a0: movk            x2, #3, lsl #16
    //     0xc5f7a4: stur            x2, [x1, #-1]
    // 0xc5f7a8: StoreField: r1->field_7 = d0
    //     0xc5f7a8: stur            d0, [x1, #7]
    // 0xc5f7ac: StoreField: r0->field_1b = r1
    //     0xc5f7ac: stur            w1, [x0, #0x1b]
    // 0xc5f7b0: r16 = <String, dynamic>
    //     0xc5f7b0: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5f7b4: stp             x0, x16, [SP, #-0x10]!
    // 0xc5f7b8: r0 = Map._fromLiteral()
    //     0xc5f7b8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5f7bc: add             SP, SP, #0x10
    // 0xc5f7c0: r16 = <double>
    //     0xc5f7c0: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5f7c4: r30 = Instance_MethodChannel
    //     0xc5f7c4: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc5f7c8: ldr             lr, [lr, #0x378]
    // 0xc5f7cc: stp             lr, x16, [SP, #-0x10]!
    // 0xc5f7d0: r16 = "setZoomLevel"
    //     0xc5f7d0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d268] "setZoomLevel"
    //     0xc5f7d4: ldr             x16, [x16, #0x268]
    // 0xc5f7d8: stp             x0, x16, [SP, #-0x10]!
    // 0xc5f7dc: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5f7dc: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5f7e0: r0 = invokeMethod()
    //     0xc5f7e0: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5f7e4: add             SP, SP, #0x20
    // 0xc5f7e8: mov             x1, x0
    // 0xc5f7ec: stur            x1, [fp, #-0x58]
    // 0xc5f7f0: r0 = Await()
    //     0xc5f7f0: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5f7f4: r0 = Null
    //     0xc5f7f4: mov             x0, NULL
    // 0xc5f7f8: r0 = ReturnAsyncNotFuture()
    //     0xc5f7f8: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc5f7fc: sub             SP, fp, #0x68
    // 0xc5f800: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc5f800: mov             x2, #0x76
    //     0xc5f804: tbz             w0, #0, #0xc5f814
    //     0xc5f808: ldur            x2, [x0, #-1]
    //     0xc5f80c: ubfx            x2, x2, #0xc, #0x14
    //     0xc5f810: lsl             x2, x2, #1
    // 0xc5f814: cmp             w2, #0xf28
    // 0xc5f818: b.ne            #0xc5f858
    // 0xc5f81c: LoadField: r1 = r0->field_7
    //     0xc5f81c: ldur            w1, [x0, #7]
    // 0xc5f820: DecompressPointer r1
    //     0xc5f820: add             x1, x1, HEAP, lsl #32
    // 0xc5f824: stur            x1, [fp, #-0x60]
    // 0xc5f828: LoadField: r2 = r0->field_b
    //     0xc5f828: ldur            w2, [x0, #0xb]
    // 0xc5f82c: DecompressPointer r2
    //     0xc5f82c: add             x2, x2, HEAP, lsl #32
    // 0xc5f830: stur            x2, [fp, #-0x58]
    // 0xc5f834: r0 = CameraException()
    //     0xc5f834: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc5f838: mov             x1, x0
    // 0xc5f83c: ldur            x0, [fp, #-0x60]
    // 0xc5f840: StoreField: r1->field_7 = r0
    //     0xc5f840: stur            w0, [x1, #7]
    // 0xc5f844: ldur            x0, [fp, #-0x58]
    // 0xc5f848: StoreField: r1->field_b = r0
    //     0xc5f848: stur            w0, [x1, #0xb]
    // 0xc5f84c: mov             x0, x1
    // 0xc5f850: r0 = Throw()
    //     0xc5f850: bl              #0xd67e38  ; ThrowStub
    // 0xc5f854: brk             #0
    // 0xc5f858: r0 = ReThrow()
    //     0xc5f858: bl              #0xd67e14  ; ReThrowStub
    // 0xc5f85c: brk             #0
    // 0xc5f860: r0 = StackOverflowSharedWithFPURegs()
    //     0xc5f860: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc5f864: b               #0xc5f744
    // 0xc5f868: SaveReg d0
    //     0xc5f868: str             q0, [SP, #-0x10]!
    // 0xc5f86c: SaveReg r0
    //     0xc5f86c: str             x0, [SP, #-8]!
    // 0xc5f870: r0 = AllocateDouble()
    //     0xc5f870: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc5f874: mov             x1, x0
    // 0xc5f878: RestoreReg r0
    //     0xc5f878: ldr             x0, [SP], #8
    // 0xc5f87c: RestoreReg d0
    //     0xc5f87c: ldr             q0, [SP], #0x10
    // 0xc5f880: b               #0xc5f7a8
  }
  _ getMinZoomLevel(/* No info */) async {
    // ** addr: 0xc5fc28, size: 0xc8
    // 0xc5fc28: EnterFrame
    //     0xc5fc28: stp             fp, lr, [SP, #-0x10]!
    //     0xc5fc2c: mov             fp, SP
    // 0xc5fc30: AllocStack(0x18)
    //     0xc5fc30: sub             SP, SP, #0x18
    // 0xc5fc34: SetupParameters(AndroidCamera this /* r1, fp-0x10 */)
    //     0xc5fc34: stur            NULL, [fp, #-8]
    //     0xc5fc38: mov             x0, #0
    //     0xc5fc3c: add             x1, fp, w0, sxtw #2
    //     0xc5fc40: ldr             x1, [x1, #0x10]
    //     0xc5fc44: stur            x1, [fp, #-0x10]
    // 0xc5fc48: CheckStackOverflow
    //     0xc5fc48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5fc4c: cmp             SP, x16
    //     0xc5fc50: b.ls            #0xc5fce4
    // 0xc5fc54: InitAsync() -> Future<double>
    //     0xc5fc54: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc5fc58: bl              #0x4b92e4
    // 0xc5fc5c: r1 = Null
    //     0xc5fc5c: mov             x1, NULL
    // 0xc5fc60: r2 = 4
    //     0xc5fc60: mov             x2, #4
    // 0xc5fc64: r0 = AllocateArray()
    //     0xc5fc64: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5fc68: mov             x2, x0
    // 0xc5fc6c: r17 = "cameraId"
    //     0xc5fc6c: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5fc70: ldr             x17, [x17, #0x890]
    // 0xc5fc74: StoreField: r2->field_f = r17
    //     0xc5fc74: stur            w17, [x2, #0xf]
    // 0xc5fc78: ldur            x3, [fp, #-0x10]
    // 0xc5fc7c: r0 = BoxInt64Instr(r3)
    //     0xc5fc7c: sbfiz           x0, x3, #1, #0x1f
    //     0xc5fc80: cmp             x3, x0, asr #1
    //     0xc5fc84: b.eq            #0xc5fc90
    //     0xc5fc88: bl              #0xd69bb8
    //     0xc5fc8c: stur            x3, [x0, #7]
    // 0xc5fc90: StoreField: r2->field_13 = r0
    //     0xc5fc90: stur            w0, [x2, #0x13]
    // 0xc5fc94: r16 = <String, dynamic>
    //     0xc5fc94: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5fc98: stp             x2, x16, [SP, #-0x10]!
    // 0xc5fc9c: r0 = Map._fromLiteral()
    //     0xc5fc9c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5fca0: add             SP, SP, #0x10
    // 0xc5fca4: r16 = <double>
    //     0xc5fca4: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5fca8: r30 = Instance_MethodChannel
    //     0xc5fca8: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc5fcac: ldr             lr, [lr, #0x378]
    // 0xc5fcb0: stp             lr, x16, [SP, #-0x10]!
    // 0xc5fcb4: r16 = "getMinZoomLevel"
    //     0xc5fcb4: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d338] "getMinZoomLevel"
    //     0xc5fcb8: ldr             x16, [x16, #0x338]
    // 0xc5fcbc: stp             x0, x16, [SP, #-0x10]!
    // 0xc5fcc0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5fcc0: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5fcc4: r0 = invokeMethod()
    //     0xc5fcc4: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5fcc8: add             SP, SP, #0x20
    // 0xc5fccc: mov             x1, x0
    // 0xc5fcd0: stur            x1, [fp, #-0x18]
    // 0xc5fcd4: r0 = Await()
    //     0xc5fcd4: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5fcd8: cmp             w0, NULL
    // 0xc5fcdc: b.eq            #0xc5fcec
    // 0xc5fce0: r0 = ReturnAsync()
    //     0xc5fce0: b               #0x501858  ; ReturnAsyncStub
    // 0xc5fce4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5fce4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5fce8: b               #0xc5fc54
    // 0xc5fcec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc5fcec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMaxZoomLevel(/* No info */) async {
    // ** addr: 0xc601a8, size: 0xc8
    // 0xc601a8: EnterFrame
    //     0xc601a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc601ac: mov             fp, SP
    // 0xc601b0: AllocStack(0x18)
    //     0xc601b0: sub             SP, SP, #0x18
    // 0xc601b4: SetupParameters(AndroidCamera this /* r1, fp-0x10 */)
    //     0xc601b4: stur            NULL, [fp, #-8]
    //     0xc601b8: mov             x0, #0
    //     0xc601bc: add             x1, fp, w0, sxtw #2
    //     0xc601c0: ldr             x1, [x1, #0x10]
    //     0xc601c4: stur            x1, [fp, #-0x10]
    // 0xc601c8: CheckStackOverflow
    //     0xc601c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc601cc: cmp             SP, x16
    //     0xc601d0: b.ls            #0xc60264
    // 0xc601d4: InitAsync() -> Future<double>
    //     0xc601d4: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc601d8: bl              #0x4b92e4
    // 0xc601dc: r1 = Null
    //     0xc601dc: mov             x1, NULL
    // 0xc601e0: r2 = 4
    //     0xc601e0: mov             x2, #4
    // 0xc601e4: r0 = AllocateArray()
    //     0xc601e4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc601e8: mov             x2, x0
    // 0xc601ec: r17 = "cameraId"
    //     0xc601ec: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc601f0: ldr             x17, [x17, #0x890]
    // 0xc601f4: StoreField: r2->field_f = r17
    //     0xc601f4: stur            w17, [x2, #0xf]
    // 0xc601f8: ldur            x3, [fp, #-0x10]
    // 0xc601fc: r0 = BoxInt64Instr(r3)
    //     0xc601fc: sbfiz           x0, x3, #1, #0x1f
    //     0xc60200: cmp             x3, x0, asr #1
    //     0xc60204: b.eq            #0xc60210
    //     0xc60208: bl              #0xd69bb8
    //     0xc6020c: stur            x3, [x0, #7]
    // 0xc60210: StoreField: r2->field_13 = r0
    //     0xc60210: stur            w0, [x2, #0x13]
    // 0xc60214: r16 = <String, dynamic>
    //     0xc60214: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc60218: stp             x2, x16, [SP, #-0x10]!
    // 0xc6021c: r0 = Map._fromLiteral()
    //     0xc6021c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc60220: add             SP, SP, #0x10
    // 0xc60224: r16 = <double>
    //     0xc60224: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc60228: r30 = Instance_MethodChannel
    //     0xc60228: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc6022c: ldr             lr, [lr, #0x378]
    // 0xc60230: stp             lr, x16, [SP, #-0x10]!
    // 0xc60234: r16 = "getMaxZoomLevel"
    //     0xc60234: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d340] "getMaxZoomLevel"
    //     0xc60238: ldr             x16, [x16, #0x340]
    // 0xc6023c: stp             x0, x16, [SP, #-0x10]!
    // 0xc60240: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc60240: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc60244: r0 = invokeMethod()
    //     0xc60244: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc60248: add             SP, SP, #0x20
    // 0xc6024c: mov             x1, x0
    // 0xc60250: stur            x1, [fp, #-0x18]
    // 0xc60254: r0 = Await()
    //     0xc60254: bl              #0x4b8e6c  ; AwaitStub
    // 0xc60258: cmp             w0, NULL
    // 0xc6025c: b.eq            #0xc6026c
    // 0xc60260: r0 = ReturnAsync()
    //     0xc60260: b               #0x501858  ; ReturnAsyncStub
    // 0xc60264: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc60264: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc60268: b               #0xc601d4
    // 0xc6026c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc6026c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setFocusPoint(/* No info */) {
    // ** addr: 0xc6052c, size: 0x180
    // 0xc6052c: EnterFrame
    //     0xc6052c: stp             fp, lr, [SP, #-0x10]!
    //     0xc60530: mov             fp, SP
    // 0xc60534: CheckStackOverflow
    //     0xc60534: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc60538: cmp             SP, x16
    //     0xc6053c: b.ls            #0xc60670
    // 0xc60540: r1 = Null
    //     0xc60540: mov             x1, NULL
    // 0xc60544: r2 = 16
    //     0xc60544: mov             x2, #0x10
    // 0xc60548: r0 = AllocateArray()
    //     0xc60548: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6054c: mov             x2, x0
    // 0xc60550: r17 = "cameraId"
    //     0xc60550: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc60554: ldr             x17, [x17, #0x890]
    // 0xc60558: StoreField: r2->field_f = r17
    //     0xc60558: stur            w17, [x2, #0xf]
    // 0xc6055c: ldr             x3, [fp, #0x18]
    // 0xc60560: r0 = BoxInt64Instr(r3)
    //     0xc60560: sbfiz           x0, x3, #1, #0x1f
    //     0xc60564: cmp             x3, x0, asr #1
    //     0xc60568: b.eq            #0xc60574
    //     0xc6056c: bl              #0xd69bb8
    //     0xc60570: stur            x3, [x0, #7]
    // 0xc60574: StoreField: r2->field_13 = r0
    //     0xc60574: stur            w0, [x2, #0x13]
    // 0xc60578: r17 = "reset"
    //     0xc60578: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ae0] "reset"
    //     0xc6057c: ldr             x17, [x17, #0xae0]
    // 0xc60580: StoreField: r2->field_17 = r17
    //     0xc60580: stur            w17, [x2, #0x17]
    // 0xc60584: ldr             x0, [fp, #0x10]
    // 0xc60588: cmp             w0, NULL
    // 0xc6058c: r16 = true
    //     0xc6058c: add             x16, NULL, #0x20  ; true
    // 0xc60590: r17 = false
    //     0xc60590: add             x17, NULL, #0x30  ; false
    // 0xc60594: csel            x1, x16, x17, eq
    // 0xc60598: StoreField: r2->field_1b = r1
    //     0xc60598: stur            w1, [x2, #0x1b]
    // 0xc6059c: r17 = "x"
    //     0xc6059c: ldr             x17, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xc605a0: StoreField: r2->field_1f = r17
    //     0xc605a0: stur            w17, [x2, #0x1f]
    // 0xc605a4: cmp             w0, NULL
    // 0xc605a8: b.ne            #0xc605b4
    // 0xc605ac: r1 = Null
    //     0xc605ac: mov             x1, NULL
    // 0xc605b0: b               #0xc605e0
    // 0xc605b4: LoadField: d0 = r0->field_b
    //     0xc605b4: ldur            d0, [x0, #0xb]
    // 0xc605b8: r1 = inline_Allocate_Double()
    //     0xc605b8: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xc605bc: add             x1, x1, #0x10
    //     0xc605c0: cmp             x3, x1
    //     0xc605c4: b.ls            #0xc60678
    //     0xc605c8: str             x1, [THR, #0x60]  ; THR::top
    //     0xc605cc: sub             x1, x1, #0xf
    //     0xc605d0: mov             x3, #0xd108
    //     0xc605d4: movk            x3, #3, lsl #16
    //     0xc605d8: stur            x3, [x1, #-1]
    // 0xc605dc: StoreField: r1->field_7 = d0
    //     0xc605dc: stur            d0, [x1, #7]
    // 0xc605e0: StoreField: r2->field_23 = r1
    //     0xc605e0: stur            w1, [x2, #0x23]
    // 0xc605e4: r17 = "y"
    //     0xc605e4: ldr             x17, [PP, #0x78d0]  ; [pp+0x78d0] "y"
    // 0xc605e8: StoreField: r2->field_27 = r17
    //     0xc605e8: stur            w17, [x2, #0x27]
    // 0xc605ec: cmp             w0, NULL
    // 0xc605f0: b.ne            #0xc605fc
    // 0xc605f4: r0 = Null
    //     0xc605f4: mov             x0, NULL
    // 0xc605f8: b               #0xc60628
    // 0xc605fc: LoadField: d0 = r0->field_13
    //     0xc605fc: ldur            d0, [x0, #0x13]
    // 0xc60600: r0 = inline_Allocate_Double()
    //     0xc60600: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc60604: add             x0, x0, #0x10
    //     0xc60608: cmp             x1, x0
    //     0xc6060c: b.ls            #0xc60694
    //     0xc60610: str             x0, [THR, #0x60]  ; THR::top
    //     0xc60614: sub             x0, x0, #0xf
    //     0xc60618: mov             x1, #0xd108
    //     0xc6061c: movk            x1, #3, lsl #16
    //     0xc60620: stur            x1, [x0, #-1]
    // 0xc60624: StoreField: r0->field_7 = d0
    //     0xc60624: stur            d0, [x0, #7]
    // 0xc60628: StoreField: r2->field_2b = r0
    //     0xc60628: stur            w0, [x2, #0x2b]
    // 0xc6062c: r16 = <String, dynamic>
    //     0xc6062c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc60630: stp             x2, x16, [SP, #-0x10]!
    // 0xc60634: r0 = Map._fromLiteral()
    //     0xc60634: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc60638: add             SP, SP, #0x10
    // 0xc6063c: r16 = <void?>
    //     0xc6063c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc60640: r30 = Instance_MethodChannel
    //     0xc60640: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc60644: ldr             lr, [lr, #0x378]
    // 0xc60648: stp             lr, x16, [SP, #-0x10]!
    // 0xc6064c: r16 = "setFocusPoint"
    //     0xc6064c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53ae8] "setFocusPoint"
    //     0xc60650: ldr             x16, [x16, #0xae8]
    // 0xc60654: stp             x0, x16, [SP, #-0x10]!
    // 0xc60658: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc60658: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6065c: r0 = invokeMethod()
    //     0xc6065c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc60660: add             SP, SP, #0x20
    // 0xc60664: LeaveFrame
    //     0xc60664: mov             SP, fp
    //     0xc60668: ldp             fp, lr, [SP], #0x10
    // 0xc6066c: ret
    //     0xc6066c: ret             
    // 0xc60670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc60670: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc60674: b               #0xc60540
    // 0xc60678: SaveReg d0
    //     0xc60678: str             q0, [SP, #-0x10]!
    // 0xc6067c: stp             x0, x2, [SP, #-0x10]!
    // 0xc60680: r0 = AllocateDouble()
    //     0xc60680: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc60684: mov             x1, x0
    // 0xc60688: ldp             x0, x2, [SP], #0x10
    // 0xc6068c: RestoreReg d0
    //     0xc6068c: ldr             q0, [SP], #0x10
    // 0xc60690: b               #0xc605dc
    // 0xc60694: SaveReg d0
    //     0xc60694: str             q0, [SP, #-0x10]!
    // 0xc60698: SaveReg r2
    //     0xc60698: str             x2, [SP, #-8]!
    // 0xc6069c: r0 = AllocateDouble()
    //     0xc6069c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc606a0: RestoreReg r2
    //     0xc606a0: ldr             x2, [SP], #8
    // 0xc606a4: RestoreReg d0
    //     0xc606a4: ldr             q0, [SP], #0x10
    // 0xc606a8: b               #0xc60624
  }
  _ setExposureOffset(/* No info */) async {
    // ** addr: 0xc640b4, size: 0x114
    // 0xc640b4: EnterFrame
    //     0xc640b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc640b8: mov             fp, SP
    // 0xc640bc: AllocStack(0x18)
    //     0xc640bc: sub             SP, SP, #0x18
    // 0xc640c0: SetupParameters(AndroidCamera this /* r1, fp-0x10 */, dynamic _ /* d0, fp-0x18 */)
    //     0xc640c0: stur            NULL, [fp, #-8]
    //     0xc640c4: mov             x0, #0
    //     0xc640c8: add             x1, fp, w0, sxtw #2
    //     0xc640cc: ldr             x1, [x1, #0x18]
    //     0xc640d0: stur            x1, [fp, #-0x10]
    //     0xc640d4: add             x2, fp, w0, sxtw #2
    //     0xc640d8: ldr             d0, [x2, #0x10]
    //     0xc640dc: stur            d0, [fp, #-0x18]
    // 0xc640e0: CheckStackOverflow
    //     0xc640e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc640e4: cmp             SP, x16
    //     0xc640e8: b.ls            #0xc641a0
    // 0xc640ec: InitAsync() -> Future<double>
    //     0xc640ec: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc640f0: bl              #0x4b92e4
    // 0xc640f4: r1 = Null
    //     0xc640f4: mov             x1, NULL
    // 0xc640f8: r2 = 8
    //     0xc640f8: mov             x2, #8
    // 0xc640fc: r0 = AllocateArray()
    //     0xc640fc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc64100: r17 = "cameraId"
    //     0xc64100: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc64104: ldr             x17, [x17, #0x890]
    // 0xc64108: StoreField: r0->field_f = r17
    //     0xc64108: stur            w17, [x0, #0xf]
    // 0xc6410c: ldur            x1, [fp, #-0x10]
    // 0xc64110: StoreField: r0->field_13 = r1
    //     0xc64110: stur            w1, [x0, #0x13]
    // 0xc64114: r17 = "offset"
    //     0xc64114: add             x17, PP, #0x35, lsl #12  ; [pp+0x35530] "offset"
    //     0xc64118: ldr             x17, [x17, #0x530]
    // 0xc6411c: StoreField: r0->field_17 = r17
    //     0xc6411c: stur            w17, [x0, #0x17]
    // 0xc64120: ldur            d0, [fp, #-0x18]
    // 0xc64124: r1 = inline_Allocate_Double()
    //     0xc64124: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc64128: add             x1, x1, #0x10
    //     0xc6412c: cmp             x2, x1
    //     0xc64130: b.ls            #0xc641a8
    //     0xc64134: str             x1, [THR, #0x60]  ; THR::top
    //     0xc64138: sub             x1, x1, #0xf
    //     0xc6413c: mov             x2, #0xd108
    //     0xc64140: movk            x2, #3, lsl #16
    //     0xc64144: stur            x2, [x1, #-1]
    // 0xc64148: StoreField: r1->field_7 = d0
    //     0xc64148: stur            d0, [x1, #7]
    // 0xc6414c: StoreField: r0->field_1b = r1
    //     0xc6414c: stur            w1, [x0, #0x1b]
    // 0xc64150: r16 = <String, dynamic>
    //     0xc64150: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc64154: stp             x0, x16, [SP, #-0x10]!
    // 0xc64158: r0 = Map._fromLiteral()
    //     0xc64158: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc6415c: add             SP, SP, #0x10
    // 0xc64160: r16 = <double>
    //     0xc64160: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc64164: r30 = Instance_MethodChannel
    //     0xc64164: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc64168: ldr             lr, [lr, #0x378]
    // 0xc6416c: stp             lr, x16, [SP, #-0x10]!
    // 0xc64170: r16 = "setExposureOffset"
    //     0xc64170: add             x16, PP, #0x55, lsl #12  ; [pp+0x55cc8] "setExposureOffset"
    //     0xc64174: ldr             x16, [x16, #0xcc8]
    // 0xc64178: stp             x0, x16, [SP, #-0x10]!
    // 0xc6417c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc6417c: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc64180: r0 = invokeMethod()
    //     0xc64180: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc64184: add             SP, SP, #0x20
    // 0xc64188: mov             x1, x0
    // 0xc6418c: stur            x1, [fp, #-0x10]
    // 0xc64190: r0 = Await()
    //     0xc64190: bl              #0x4b8e6c  ; AwaitStub
    // 0xc64194: cmp             w0, NULL
    // 0xc64198: b.eq            #0xc641c4
    // 0xc6419c: r0 = ReturnAsync()
    //     0xc6419c: b               #0x501858  ; ReturnAsyncStub
    // 0xc641a0: r0 = StackOverflowSharedWithFPURegs()
    //     0xc641a0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc641a4: b               #0xc640ec
    // 0xc641a8: SaveReg d0
    //     0xc641a8: str             q0, [SP, #-0x10]!
    // 0xc641ac: SaveReg r0
    //     0xc641ac: str             x0, [SP, #-8]!
    // 0xc641b0: r0 = AllocateDouble()
    //     0xc641b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc641b4: mov             x1, x0
    // 0xc641b8: RestoreReg r0
    //     0xc641b8: ldr             x0, [SP], #8
    // 0xc641bc: RestoreReg d0
    //     0xc641bc: ldr             q0, [SP], #0x10
    // 0xc641c0: b               #0xc64148
    // 0xc641c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc641c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getExposureOffsetStepSize(/* No info */) async {
    // ** addr: 0xc644f0, size: 0xc8
    // 0xc644f0: EnterFrame
    //     0xc644f0: stp             fp, lr, [SP, #-0x10]!
    //     0xc644f4: mov             fp, SP
    // 0xc644f8: AllocStack(0x18)
    //     0xc644f8: sub             SP, SP, #0x18
    // 0xc644fc: SetupParameters(AndroidCamera this /* r1, fp-0x10 */)
    //     0xc644fc: stur            NULL, [fp, #-8]
    //     0xc64500: mov             x0, #0
    //     0xc64504: add             x1, fp, w0, sxtw #2
    //     0xc64508: ldr             x1, [x1, #0x10]
    //     0xc6450c: stur            x1, [fp, #-0x10]
    // 0xc64510: CheckStackOverflow
    //     0xc64510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc64514: cmp             SP, x16
    //     0xc64518: b.ls            #0xc645ac
    // 0xc6451c: InitAsync() -> Future<double>
    //     0xc6451c: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc64520: bl              #0x4b92e4
    // 0xc64524: r1 = Null
    //     0xc64524: mov             x1, NULL
    // 0xc64528: r2 = 4
    //     0xc64528: mov             x2, #4
    // 0xc6452c: r0 = AllocateArray()
    //     0xc6452c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc64530: mov             x2, x0
    // 0xc64534: r17 = "cameraId"
    //     0xc64534: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc64538: ldr             x17, [x17, #0x890]
    // 0xc6453c: StoreField: r2->field_f = r17
    //     0xc6453c: stur            w17, [x2, #0xf]
    // 0xc64540: ldur            x3, [fp, #-0x10]
    // 0xc64544: r0 = BoxInt64Instr(r3)
    //     0xc64544: sbfiz           x0, x3, #1, #0x1f
    //     0xc64548: cmp             x3, x0, asr #1
    //     0xc6454c: b.eq            #0xc64558
    //     0xc64550: bl              #0xd69bb8
    //     0xc64554: stur            x3, [x0, #7]
    // 0xc64558: StoreField: r2->field_13 = r0
    //     0xc64558: stur            w0, [x2, #0x13]
    // 0xc6455c: r16 = <String, dynamic>
    //     0xc6455c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc64560: stp             x2, x16, [SP, #-0x10]!
    // 0xc64564: r0 = Map._fromLiteral()
    //     0xc64564: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc64568: add             SP, SP, #0x10
    // 0xc6456c: r16 = <double>
    //     0xc6456c: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc64570: r30 = Instance_MethodChannel
    //     0xc64570: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc64574: ldr             lr, [lr, #0x378]
    // 0xc64578: stp             lr, x16, [SP, #-0x10]!
    // 0xc6457c: r16 = "getExposureOffsetStepSize"
    //     0xc6457c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d358] "getExposureOffsetStepSize"
    //     0xc64580: ldr             x16, [x16, #0x358]
    // 0xc64584: stp             x0, x16, [SP, #-0x10]!
    // 0xc64588: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc64588: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6458c: r0 = invokeMethod()
    //     0xc6458c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc64590: add             SP, SP, #0x20
    // 0xc64594: mov             x1, x0
    // 0xc64598: stur            x1, [fp, #-0x18]
    // 0xc6459c: r0 = Await()
    //     0xc6459c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc645a0: cmp             w0, NULL
    // 0xc645a4: b.eq            #0xc645b4
    // 0xc645a8: r0 = ReturnAsync()
    //     0xc645a8: b               #0x501858  ; ReturnAsyncStub
    // 0xc645ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc645ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc645b0: b               #0xc6451c
    // 0xc645b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc645b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMaxExposureOffset(/* No info */) async {
    // ** addr: 0xc64b54, size: 0xc8
    // 0xc64b54: EnterFrame
    //     0xc64b54: stp             fp, lr, [SP, #-0x10]!
    //     0xc64b58: mov             fp, SP
    // 0xc64b5c: AllocStack(0x18)
    //     0xc64b5c: sub             SP, SP, #0x18
    // 0xc64b60: SetupParameters(AndroidCamera this /* r1, fp-0x10 */)
    //     0xc64b60: stur            NULL, [fp, #-8]
    //     0xc64b64: mov             x0, #0
    //     0xc64b68: add             x1, fp, w0, sxtw #2
    //     0xc64b6c: ldr             x1, [x1, #0x10]
    //     0xc64b70: stur            x1, [fp, #-0x10]
    // 0xc64b74: CheckStackOverflow
    //     0xc64b74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc64b78: cmp             SP, x16
    //     0xc64b7c: b.ls            #0xc64c10
    // 0xc64b80: InitAsync() -> Future<double>
    //     0xc64b80: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc64b84: bl              #0x4b92e4
    // 0xc64b88: r1 = Null
    //     0xc64b88: mov             x1, NULL
    // 0xc64b8c: r2 = 4
    //     0xc64b8c: mov             x2, #4
    // 0xc64b90: r0 = AllocateArray()
    //     0xc64b90: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc64b94: mov             x2, x0
    // 0xc64b98: r17 = "cameraId"
    //     0xc64b98: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc64b9c: ldr             x17, [x17, #0x890]
    // 0xc64ba0: StoreField: r2->field_f = r17
    //     0xc64ba0: stur            w17, [x2, #0xf]
    // 0xc64ba4: ldur            x3, [fp, #-0x10]
    // 0xc64ba8: r0 = BoxInt64Instr(r3)
    //     0xc64ba8: sbfiz           x0, x3, #1, #0x1f
    //     0xc64bac: cmp             x3, x0, asr #1
    //     0xc64bb0: b.eq            #0xc64bbc
    //     0xc64bb4: bl              #0xd69bb8
    //     0xc64bb8: stur            x3, [x0, #7]
    // 0xc64bbc: StoreField: r2->field_13 = r0
    //     0xc64bbc: stur            w0, [x2, #0x13]
    // 0xc64bc0: r16 = <String, dynamic>
    //     0xc64bc0: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc64bc4: stp             x2, x16, [SP, #-0x10]!
    // 0xc64bc8: r0 = Map._fromLiteral()
    //     0xc64bc8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc64bcc: add             SP, SP, #0x10
    // 0xc64bd0: r16 = <double>
    //     0xc64bd0: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc64bd4: r30 = Instance_MethodChannel
    //     0xc64bd4: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc64bd8: ldr             lr, [lr, #0x378]
    // 0xc64bdc: stp             lr, x16, [SP, #-0x10]!
    // 0xc64be0: r16 = "getMaxExposureOffset"
    //     0xc64be0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d350] "getMaxExposureOffset"
    //     0xc64be4: ldr             x16, [x16, #0x350]
    // 0xc64be8: stp             x0, x16, [SP, #-0x10]!
    // 0xc64bec: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc64bec: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc64bf0: r0 = invokeMethod()
    //     0xc64bf0: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc64bf4: add             SP, SP, #0x20
    // 0xc64bf8: mov             x1, x0
    // 0xc64bfc: stur            x1, [fp, #-0x18]
    // 0xc64c00: r0 = Await()
    //     0xc64c00: bl              #0x4b8e6c  ; AwaitStub
    // 0xc64c04: cmp             w0, NULL
    // 0xc64c08: b.eq            #0xc64c18
    // 0xc64c0c: r0 = ReturnAsync()
    //     0xc64c0c: b               #0x501858  ; ReturnAsyncStub
    // 0xc64c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc64c10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc64c14: b               #0xc64b80
    // 0xc64c18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc64c18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMinExposureOffset(/* No info */) async {
    // ** addr: 0xc65324, size: 0xc8
    // 0xc65324: EnterFrame
    //     0xc65324: stp             fp, lr, [SP, #-0x10]!
    //     0xc65328: mov             fp, SP
    // 0xc6532c: AllocStack(0x18)
    //     0xc6532c: sub             SP, SP, #0x18
    // 0xc65330: SetupParameters(AndroidCamera this /* r1, fp-0x10 */)
    //     0xc65330: stur            NULL, [fp, #-8]
    //     0xc65334: mov             x0, #0
    //     0xc65338: add             x1, fp, w0, sxtw #2
    //     0xc6533c: ldr             x1, [x1, #0x10]
    //     0xc65340: stur            x1, [fp, #-0x10]
    // 0xc65344: CheckStackOverflow
    //     0xc65344: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc65348: cmp             SP, x16
    //     0xc6534c: b.ls            #0xc653e0
    // 0xc65350: InitAsync() -> Future<double>
    //     0xc65350: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc65354: bl              #0x4b92e4
    // 0xc65358: r1 = Null
    //     0xc65358: mov             x1, NULL
    // 0xc6535c: r2 = 4
    //     0xc6535c: mov             x2, #4
    // 0xc65360: r0 = AllocateArray()
    //     0xc65360: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc65364: mov             x2, x0
    // 0xc65368: r17 = "cameraId"
    //     0xc65368: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc6536c: ldr             x17, [x17, #0x890]
    // 0xc65370: StoreField: r2->field_f = r17
    //     0xc65370: stur            w17, [x2, #0xf]
    // 0xc65374: ldur            x3, [fp, #-0x10]
    // 0xc65378: r0 = BoxInt64Instr(r3)
    //     0xc65378: sbfiz           x0, x3, #1, #0x1f
    //     0xc6537c: cmp             x3, x0, asr #1
    //     0xc65380: b.eq            #0xc6538c
    //     0xc65384: bl              #0xd69bb8
    //     0xc65388: stur            x3, [x0, #7]
    // 0xc6538c: StoreField: r2->field_13 = r0
    //     0xc6538c: stur            w0, [x2, #0x13]
    // 0xc65390: r16 = <String, dynamic>
    //     0xc65390: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc65394: stp             x2, x16, [SP, #-0x10]!
    // 0xc65398: r0 = Map._fromLiteral()
    //     0xc65398: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc6539c: add             SP, SP, #0x10
    // 0xc653a0: r16 = <double>
    //     0xc653a0: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc653a4: r30 = Instance_MethodChannel
    //     0xc653a4: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc653a8: ldr             lr, [lr, #0x378]
    // 0xc653ac: stp             lr, x16, [SP, #-0x10]!
    // 0xc653b0: r16 = "getMinExposureOffset"
    //     0xc653b0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d348] "getMinExposureOffset"
    //     0xc653b4: ldr             x16, [x16, #0x348]
    // 0xc653b8: stp             x0, x16, [SP, #-0x10]!
    // 0xc653bc: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc653bc: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc653c0: r0 = invokeMethod()
    //     0xc653c0: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc653c4: add             SP, SP, #0x20
    // 0xc653c8: mov             x1, x0
    // 0xc653cc: stur            x1, [fp, #-0x18]
    // 0xc653d0: r0 = Await()
    //     0xc653d0: bl              #0x4b8e6c  ; AwaitStub
    // 0xc653d4: cmp             w0, NULL
    // 0xc653d8: b.eq            #0xc653e8
    // 0xc653dc: r0 = ReturnAsync()
    //     0xc653dc: b               #0x501858  ; ReturnAsyncStub
    // 0xc653e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc653e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc653e4: b               #0xc65350
    // 0xc653e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc653e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setExposurePoint(/* No info */) {
    // ** addr: 0xc6557c, size: 0x180
    // 0xc6557c: EnterFrame
    //     0xc6557c: stp             fp, lr, [SP, #-0x10]!
    //     0xc65580: mov             fp, SP
    // 0xc65584: CheckStackOverflow
    //     0xc65584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc65588: cmp             SP, x16
    //     0xc6558c: b.ls            #0xc656c0
    // 0xc65590: r1 = Null
    //     0xc65590: mov             x1, NULL
    // 0xc65594: r2 = 16
    //     0xc65594: mov             x2, #0x10
    // 0xc65598: r0 = AllocateArray()
    //     0xc65598: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6559c: mov             x2, x0
    // 0xc655a0: r17 = "cameraId"
    //     0xc655a0: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc655a4: ldr             x17, [x17, #0x890]
    // 0xc655a8: StoreField: r2->field_f = r17
    //     0xc655a8: stur            w17, [x2, #0xf]
    // 0xc655ac: ldr             x3, [fp, #0x18]
    // 0xc655b0: r0 = BoxInt64Instr(r3)
    //     0xc655b0: sbfiz           x0, x3, #1, #0x1f
    //     0xc655b4: cmp             x3, x0, asr #1
    //     0xc655b8: b.eq            #0xc655c4
    //     0xc655bc: bl              #0xd69bb8
    //     0xc655c0: stur            x3, [x0, #7]
    // 0xc655c4: StoreField: r2->field_13 = r0
    //     0xc655c4: stur            w0, [x2, #0x13]
    // 0xc655c8: r17 = "reset"
    //     0xc655c8: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ae0] "reset"
    //     0xc655cc: ldr             x17, [x17, #0xae0]
    // 0xc655d0: StoreField: r2->field_17 = r17
    //     0xc655d0: stur            w17, [x2, #0x17]
    // 0xc655d4: ldr             x0, [fp, #0x10]
    // 0xc655d8: cmp             w0, NULL
    // 0xc655dc: r16 = true
    //     0xc655dc: add             x16, NULL, #0x20  ; true
    // 0xc655e0: r17 = false
    //     0xc655e0: add             x17, NULL, #0x30  ; false
    // 0xc655e4: csel            x1, x16, x17, eq
    // 0xc655e8: StoreField: r2->field_1b = r1
    //     0xc655e8: stur            w1, [x2, #0x1b]
    // 0xc655ec: r17 = "x"
    //     0xc655ec: ldr             x17, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xc655f0: StoreField: r2->field_1f = r17
    //     0xc655f0: stur            w17, [x2, #0x1f]
    // 0xc655f4: cmp             w0, NULL
    // 0xc655f8: b.ne            #0xc65604
    // 0xc655fc: r1 = Null
    //     0xc655fc: mov             x1, NULL
    // 0xc65600: b               #0xc65630
    // 0xc65604: LoadField: d0 = r0->field_b
    //     0xc65604: ldur            d0, [x0, #0xb]
    // 0xc65608: r1 = inline_Allocate_Double()
    //     0xc65608: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xc6560c: add             x1, x1, #0x10
    //     0xc65610: cmp             x3, x1
    //     0xc65614: b.ls            #0xc656c8
    //     0xc65618: str             x1, [THR, #0x60]  ; THR::top
    //     0xc6561c: sub             x1, x1, #0xf
    //     0xc65620: mov             x3, #0xd108
    //     0xc65624: movk            x3, #3, lsl #16
    //     0xc65628: stur            x3, [x1, #-1]
    // 0xc6562c: StoreField: r1->field_7 = d0
    //     0xc6562c: stur            d0, [x1, #7]
    // 0xc65630: StoreField: r2->field_23 = r1
    //     0xc65630: stur            w1, [x2, #0x23]
    // 0xc65634: r17 = "y"
    //     0xc65634: ldr             x17, [PP, #0x78d0]  ; [pp+0x78d0] "y"
    // 0xc65638: StoreField: r2->field_27 = r17
    //     0xc65638: stur            w17, [x2, #0x27]
    // 0xc6563c: cmp             w0, NULL
    // 0xc65640: b.ne            #0xc6564c
    // 0xc65644: r0 = Null
    //     0xc65644: mov             x0, NULL
    // 0xc65648: b               #0xc65678
    // 0xc6564c: LoadField: d0 = r0->field_13
    //     0xc6564c: ldur            d0, [x0, #0x13]
    // 0xc65650: r0 = inline_Allocate_Double()
    //     0xc65650: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc65654: add             x0, x0, #0x10
    //     0xc65658: cmp             x1, x0
    //     0xc6565c: b.ls            #0xc656e4
    //     0xc65660: str             x0, [THR, #0x60]  ; THR::top
    //     0xc65664: sub             x0, x0, #0xf
    //     0xc65668: mov             x1, #0xd108
    //     0xc6566c: movk            x1, #3, lsl #16
    //     0xc65670: stur            x1, [x0, #-1]
    // 0xc65674: StoreField: r0->field_7 = d0
    //     0xc65674: stur            d0, [x0, #7]
    // 0xc65678: StoreField: r2->field_2b = r0
    //     0xc65678: stur            w0, [x2, #0x2b]
    // 0xc6567c: r16 = <String, dynamic>
    //     0xc6567c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc65680: stp             x2, x16, [SP, #-0x10]!
    // 0xc65684: r0 = Map._fromLiteral()
    //     0xc65684: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc65688: add             SP, SP, #0x10
    // 0xc6568c: r16 = <void?>
    //     0xc6568c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc65690: r30 = Instance_MethodChannel
    //     0xc65690: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc65694: ldr             lr, [lr, #0x378]
    // 0xc65698: stp             lr, x16, [SP, #-0x10]!
    // 0xc6569c: r16 = "setExposurePoint"
    //     0xc6569c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53af0] "setExposurePoint"
    //     0xc656a0: ldr             x16, [x16, #0xaf0]
    // 0xc656a4: stp             x0, x16, [SP, #-0x10]!
    // 0xc656a8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc656a8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc656ac: r0 = invokeMethod()
    //     0xc656ac: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc656b0: add             SP, SP, #0x20
    // 0xc656b4: LeaveFrame
    //     0xc656b4: mov             SP, fp
    //     0xc656b8: ldp             fp, lr, [SP], #0x10
    // 0xc656bc: ret
    //     0xc656bc: ret             
    // 0xc656c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc656c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc656c4: b               #0xc65590
    // 0xc656c8: SaveReg d0
    //     0xc656c8: str             q0, [SP, #-0x10]!
    // 0xc656cc: stp             x0, x2, [SP, #-0x10]!
    // 0xc656d0: r0 = AllocateDouble()
    //     0xc656d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc656d4: mov             x1, x0
    // 0xc656d8: ldp             x0, x2, [SP], #0x10
    // 0xc656dc: RestoreReg d0
    //     0xc656dc: ldr             q0, [SP], #0x10
    // 0xc656e0: b               #0xc6562c
    // 0xc656e4: SaveReg d0
    //     0xc656e4: str             q0, [SP, #-0x10]!
    // 0xc656e8: SaveReg r2
    //     0xc656e8: str             x2, [SP, #-8]!
    // 0xc656ec: r0 = AllocateDouble()
    //     0xc656ec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc656f0: RestoreReg r2
    //     0xc656f0: ldr             x2, [SP], #8
    // 0xc656f4: RestoreReg d0
    //     0xc656f4: ldr             q0, [SP], #0x10
    // 0xc656f8: b               #0xc65674
  }
  _ stopVideoRecording(/* No info */) async {
    // ** addr: 0xc6a320, size: 0x1e0
    // 0xc6a320: EnterFrame
    //     0xc6a320: stp             fp, lr, [SP, #-0x10]!
    //     0xc6a324: mov             fp, SP
    // 0xc6a328: AllocStack(0x20)
    //     0xc6a328: sub             SP, SP, #0x20
    // 0xc6a32c: SetupParameters(AndroidCamera this /* r1, fp-0x10 */)
    //     0xc6a32c: stur            NULL, [fp, #-8]
    //     0xc6a330: mov             x0, #0
    //     0xc6a334: add             x1, fp, w0, sxtw #2
    //     0xc6a338: ldr             x1, [x1, #0x10]
    //     0xc6a33c: stur            x1, [fp, #-0x10]
    // 0xc6a340: CheckStackOverflow
    //     0xc6a340: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6a344: cmp             SP, x16
    //     0xc6a348: b.ls            #0xc6a4f8
    // 0xc6a34c: InitAsync() -> Future<XFile>
    //     0xc6a34c: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d698] TypeArguments: <XFile>
    //     0xc6a350: ldr             x0, [x0, #0x698]
    //     0xc6a354: bl              #0x4b92e4
    // 0xc6a358: r1 = Null
    //     0xc6a358: mov             x1, NULL
    // 0xc6a35c: r2 = 4
    //     0xc6a35c: mov             x2, #4
    // 0xc6a360: r0 = AllocateArray()
    //     0xc6a360: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6a364: mov             x2, x0
    // 0xc6a368: r17 = "cameraId"
    //     0xc6a368: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc6a36c: ldr             x17, [x17, #0x890]
    // 0xc6a370: StoreField: r2->field_f = r17
    //     0xc6a370: stur            w17, [x2, #0xf]
    // 0xc6a374: ldur            x3, [fp, #-0x10]
    // 0xc6a378: r0 = BoxInt64Instr(r3)
    //     0xc6a378: sbfiz           x0, x3, #1, #0x1f
    //     0xc6a37c: cmp             x3, x0, asr #1
    //     0xc6a380: b.eq            #0xc6a38c
    //     0xc6a384: bl              #0xd69bb8
    //     0xc6a388: stur            x3, [x0, #7]
    // 0xc6a38c: StoreField: r2->field_13 = r0
    //     0xc6a38c: stur            w0, [x2, #0x13]
    // 0xc6a390: r16 = <String, dynamic>
    //     0xc6a390: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc6a394: stp             x2, x16, [SP, #-0x10]!
    // 0xc6a398: r0 = Map._fromLiteral()
    //     0xc6a398: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc6a39c: add             SP, SP, #0x10
    // 0xc6a3a0: r16 = <String>
    //     0xc6a3a0: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xc6a3a4: r30 = Instance_MethodChannel
    //     0xc6a3a4: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc6a3a8: ldr             lr, [lr, #0x378]
    // 0xc6a3ac: stp             lr, x16, [SP, #-0x10]!
    // 0xc6a3b0: r16 = "stopVideoRecording"
    //     0xc6a3b0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d6a0] "stopVideoRecording"
    //     0xc6a3b4: ldr             x16, [x16, #0x6a0]
    // 0xc6a3b8: stp             x0, x16, [SP, #-0x10]!
    // 0xc6a3bc: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc6a3bc: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6a3c0: r0 = invokeMethod()
    //     0xc6a3c0: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6a3c4: add             SP, SP, #0x20
    // 0xc6a3c8: mov             x1, x0
    // 0xc6a3cc: stur            x1, [fp, #-0x18]
    // 0xc6a3d0: r0 = Await()
    //     0xc6a3d0: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6a3d4: stur            x0, [fp, #-0x20]
    // 0xc6a3d8: cmp             w0, NULL
    // 0xc6a3dc: b.eq            #0xc6a468
    // 0xc6a3e0: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc6a3e0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc6a3e4: ldr             x0, [x0, #0xb58]
    //     0xc6a3e8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc6a3ec: cmp             w0, w16
    //     0xc6a3f0: b.ne            #0xc6a3fc
    //     0xc6a3f4: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc6a3f8: bl              #0xd67d44
    // 0xc6a3fc: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc6a3fc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc6a400: ldr             x0, [x0, #0xdd8]
    //     0xc6a404: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc6a408: cmp             w0, w16
    //     0xc6a40c: b.ne            #0xc6a418
    //     0xc6a410: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc6a414: bl              #0xd67cdc
    // 0xc6a418: r0 = _File()
    //     0xc6a418: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xc6a41c: mov             x1, x0
    // 0xc6a420: ldur            x0, [fp, #-0x20]
    // 0xc6a424: stur            x1, [fp, #-0x18]
    // 0xc6a428: StoreField: r1->field_7 = r0
    //     0xc6a428: stur            w0, [x1, #7]
    // 0xc6a42c: SaveReg r0
    //     0xc6a42c: str             x0, [SP, #-8]!
    // 0xc6a430: r0 = _toUtf8Array()
    //     0xc6a430: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc6a434: add             SP, SP, #8
    // 0xc6a438: ldur            x1, [fp, #-0x18]
    // 0xc6a43c: StoreField: r1->field_b = r0
    //     0xc6a43c: stur            w0, [x1, #0xb]
    //     0xc6a440: ldurb           w16, [x1, #-1]
    //     0xc6a444: ldurb           w17, [x0, #-1]
    //     0xc6a448: and             x16, x17, x16, lsr #2
    //     0xc6a44c: tst             x16, HEAP, lsr #32
    //     0xc6a450: b.eq            #0xc6a458
    //     0xc6a454: bl              #0xd6826c
    // 0xc6a458: r0 = XFile()
    //     0xc6a458: bl              #0xc6a500  ; AllocateXFileStub -> XFile (size=0x10)
    // 0xc6a45c: ldur            x1, [fp, #-0x18]
    // 0xc6a460: StoreField: r0->field_7 = r1
    //     0xc6a460: stur            w1, [x0, #7]
    // 0xc6a464: r0 = ReturnAsyncNotFuture()
    //     0xc6a464: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc6a468: r1 = Null
    //     0xc6a468: mov             x1, NULL
    // 0xc6a46c: r2 = 6
    //     0xc6a46c: mov             x2, #6
    // 0xc6a470: r0 = AllocateArray()
    //     0xc6a470: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6a474: stur            x0, [fp, #-0x18]
    // 0xc6a478: r17 = "The platform \""
    //     0xc6a478: add             x17, PP, #0x53, lsl #12  ; [pp+0x53af8] "The platform \""
    //     0xc6a47c: ldr             x17, [x17, #0xaf8]
    // 0xc6a480: StoreField: r0->field_f = r17
    //     0xc6a480: stur            w17, [x0, #0xf]
    // 0xc6a484: r0 = defaultTargetPlatform()
    //     0xc6a484: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xc6a488: ldur            x1, [fp, #-0x18]
    // 0xc6a48c: ArrayStore: r1[1] = r0  ; List_4
    //     0xc6a48c: add             x25, x1, #0x13
    //     0xc6a490: str             w0, [x25]
    //     0xc6a494: tbz             w0, #0, #0xc6a4b0
    //     0xc6a498: ldurb           w16, [x1, #-1]
    //     0xc6a49c: ldurb           w17, [x0, #-1]
    //     0xc6a4a0: and             x16, x17, x16, lsr #2
    //     0xc6a4a4: tst             x16, HEAP, lsr #32
    //     0xc6a4a8: b.eq            #0xc6a4b0
    //     0xc6a4ac: bl              #0xd67e5c
    // 0xc6a4b0: ldur            x0, [fp, #-0x18]
    // 0xc6a4b4: r17 = "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc6a4b4: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b00] "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc6a4b8: ldr             x17, [x17, #0xb00]
    // 0xc6a4bc: StoreField: r0->field_17 = r17
    //     0xc6a4bc: stur            w17, [x0, #0x17]
    // 0xc6a4c0: SaveReg r0
    //     0xc6a4c0: str             x0, [SP, #-8]!
    // 0xc6a4c4: r0 = _interpolate()
    //     0xc6a4c4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc6a4c8: add             SP, SP, #8
    // 0xc6a4cc: stur            x0, [fp, #-0x18]
    // 0xc6a4d0: r0 = CameraException()
    //     0xc6a4d0: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc6a4d4: mov             x1, x0
    // 0xc6a4d8: r0 = "INVALID_PATH"
    //     0xc6a4d8: add             x0, PP, #0x53, lsl #12  ; [pp+0x53b08] "INVALID_PATH"
    //     0xc6a4dc: ldr             x0, [x0, #0xb08]
    // 0xc6a4e0: StoreField: r1->field_7 = r0
    //     0xc6a4e0: stur            w0, [x1, #7]
    // 0xc6a4e4: ldur            x0, [fp, #-0x18]
    // 0xc6a4e8: StoreField: r1->field_b = r0
    //     0xc6a4e8: stur            w0, [x1, #0xb]
    // 0xc6a4ec: mov             x0, x1
    // 0xc6a4f0: r0 = Throw()
    //     0xc6a4f0: bl              #0xd67e38  ; ThrowStub
    // 0xc6a4f4: brk             #0
    // 0xc6a4f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6a4f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6a4fc: b               #0xc6a34c
  }
  _ startVideoCapturing(/* No info */) async {
    // ** addr: 0xc6aa20, size: 0x168
    // 0xc6aa20: EnterFrame
    //     0xc6aa20: stp             fp, lr, [SP, #-0x10]!
    //     0xc6aa24: mov             fp, SP
    // 0xc6aa28: AllocStack(0x28)
    //     0xc6aa28: sub             SP, SP, #0x28
    // 0xc6aa2c: SetupParameters(AndroidCamera this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xc6aa2c: stur            NULL, [fp, #-8]
    //     0xc6aa30: mov             x0, #0
    //     0xc6aa34: add             x1, fp, w0, sxtw #2
    //     0xc6aa38: ldr             x1, [x1, #0x18]
    //     0xc6aa3c: stur            x1, [fp, #-0x18]
    //     0xc6aa40: add             x2, fp, w0, sxtw #2
    //     0xc6aa44: ldr             x2, [x2, #0x10]
    //     0xc6aa48: stur            x2, [fp, #-0x10]
    // 0xc6aa4c: CheckStackOverflow
    //     0xc6aa4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6aa50: cmp             SP, x16
    //     0xc6aa54: b.ls            #0xc6ab80
    // 0xc6aa58: InitAsync() -> Future<void?>
    //     0xc6aa58: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc6aa5c: bl              #0x4b92e4
    // 0xc6aa60: r1 = Null
    //     0xc6aa60: mov             x1, NULL
    // 0xc6aa64: r2 = 12
    //     0xc6aa64: mov             x2, #0xc
    // 0xc6aa68: r0 = AllocateArray()
    //     0xc6aa68: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6aa6c: mov             x2, x0
    // 0xc6aa70: r17 = "cameraId"
    //     0xc6aa70: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc6aa74: ldr             x17, [x17, #0x890]
    // 0xc6aa78: StoreField: r2->field_f = r17
    //     0xc6aa78: stur            w17, [x2, #0xf]
    // 0xc6aa7c: ldur            x3, [fp, #-0x10]
    // 0xc6aa80: LoadField: r4 = r3->field_7
    //     0xc6aa80: ldur            x4, [x3, #7]
    // 0xc6aa84: r0 = BoxInt64Instr(r4)
    //     0xc6aa84: sbfiz           x0, x4, #1, #0x1f
    //     0xc6aa88: cmp             x4, x0, asr #1
    //     0xc6aa8c: b.eq            #0xc6aa98
    //     0xc6aa90: bl              #0xd69bb8
    //     0xc6aa94: stur            x4, [x0, #7]
    // 0xc6aa98: StoreField: r2->field_13 = r0
    //     0xc6aa98: stur            w0, [x2, #0x13]
    // 0xc6aa9c: r17 = "maxVideoDuration"
    //     0xc6aa9c: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b10] "maxVideoDuration"
    //     0xc6aaa0: ldr             x17, [x17, #0xb10]
    // 0xc6aaa4: StoreField: r2->field_17 = r17
    //     0xc6aaa4: stur            w17, [x2, #0x17]
    // 0xc6aaa8: StoreField: r2->field_1b = rNULL
    //     0xc6aaa8: stur            NULL, [x2, #0x1b]
    // 0xc6aaac: r17 = "enableStream"
    //     0xc6aaac: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b18] "enableStream"
    //     0xc6aab0: ldr             x17, [x17, #0xb18]
    // 0xc6aab4: StoreField: r2->field_1f = r17
    //     0xc6aab4: stur            w17, [x2, #0x1f]
    // 0xc6aab8: LoadField: r0 = r3->field_13
    //     0xc6aab8: ldur            w0, [x3, #0x13]
    // 0xc6aabc: DecompressPointer r0
    //     0xc6aabc: add             x0, x0, HEAP, lsl #32
    // 0xc6aac0: stur            x0, [fp, #-0x20]
    // 0xc6aac4: cmp             w0, NULL
    // 0xc6aac8: r16 = true
    //     0xc6aac8: add             x16, NULL, #0x20  ; true
    // 0xc6aacc: r17 = false
    //     0xc6aacc: add             x17, NULL, #0x30  ; false
    // 0xc6aad0: csel            x1, x16, x17, ne
    // 0xc6aad4: StoreField: r2->field_23 = r1
    //     0xc6aad4: stur            w1, [x2, #0x23]
    // 0xc6aad8: r16 = <String, dynamic>
    //     0xc6aad8: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc6aadc: stp             x2, x16, [SP, #-0x10]!
    // 0xc6aae0: r0 = Map._fromLiteral()
    //     0xc6aae0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc6aae4: add             SP, SP, #0x10
    // 0xc6aae8: r16 = <void?>
    //     0xc6aae8: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc6aaec: r30 = Instance_MethodChannel
    //     0xc6aaec: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc6aaf0: ldr             lr, [lr, #0x378]
    // 0xc6aaf4: stp             lr, x16, [SP, #-0x10]!
    // 0xc6aaf8: r16 = "startVideoRecording"
    //     0xc6aaf8: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d730] "startVideoRecording"
    //     0xc6aafc: ldr             x16, [x16, #0x730]
    // 0xc6ab00: stp             x0, x16, [SP, #-0x10]!
    // 0xc6ab04: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc6ab04: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6ab08: r0 = invokeMethod()
    //     0xc6ab08: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6ab0c: add             SP, SP, #0x20
    // 0xc6ab10: mov             x1, x0
    // 0xc6ab14: stur            x1, [fp, #-0x28]
    // 0xc6ab18: r0 = Await()
    //     0xc6ab18: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6ab1c: ldur            x0, [fp, #-0x20]
    // 0xc6ab20: cmp             w0, NULL
    // 0xc6ab24: b.eq            #0xc6ab78
    // 0xc6ab28: ldur            x16, [fp, #-0x18]
    // 0xc6ab2c: SaveReg r16
    //     0xc6ab2c: str             x16, [SP, #-8]!
    // 0xc6ab30: r0 = _installStreamController()
    //     0xc6ab30: bl              #0xc6b414  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_installStreamController
    // 0xc6ab34: add             SP, SP, #8
    // 0xc6ab38: stur            x0, [fp, #-0x10]
    // 0xc6ab3c: LoadField: r1 = r0->field_7
    //     0xc6ab3c: ldur            w1, [x0, #7]
    // 0xc6ab40: DecompressPointer r1
    //     0xc6ab40: add             x1, x1, HEAP, lsl #32
    // 0xc6ab44: r0 = _ControllerStream()
    //     0xc6ab44: bl              #0x534e34  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x14)
    // 0xc6ab48: mov             x1, x0
    // 0xc6ab4c: ldur            x0, [fp, #-0x10]
    // 0xc6ab50: StoreField: r1->field_f = r0
    //     0xc6ab50: stur            w0, [x1, #0xf]
    // 0xc6ab54: ldur            x16, [fp, #-0x20]
    // 0xc6ab58: stp             x16, x1, [SP, #-0x10]!
    // 0xc6ab5c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc6ab5c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc6ab60: r0 = listen()
    //     0xc6ab60: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xc6ab64: add             SP, SP, #0x10
    // 0xc6ab68: ldur            x16, [fp, #-0x18]
    // 0xc6ab6c: SaveReg r16
    //     0xc6ab6c: str             x16, [SP, #-8]!
    // 0xc6ab70: r0 = _startStreamListener()
    //     0xc6ab70: bl              #0xc6ab88  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_startStreamListener
    // 0xc6ab74: add             SP, SP, #8
    // 0xc6ab78: r0 = Null
    //     0xc6ab78: mov             x0, NULL
    // 0xc6ab7c: r0 = ReturnAsyncNotFuture()
    //     0xc6ab7c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc6ab80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ab80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ab84: b               #0xc6aa58
  }
  _ _startStreamListener(/* No info */) {
    // ** addr: 0xc6ab88, size: 0xa8
    // 0xc6ab88: EnterFrame
    //     0xc6ab88: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ab8c: mov             fp, SP
    // 0xc6ab90: AllocStack(0x8)
    //     0xc6ab90: sub             SP, SP, #8
    // 0xc6ab94: CheckStackOverflow
    //     0xc6ab94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ab98: cmp             SP, x16
    //     0xc6ab9c: b.ls            #0xc6ac28
    // 0xc6aba0: r1 = 1
    //     0xc6aba0: mov             x1, #1
    // 0xc6aba4: r0 = AllocateContext()
    //     0xc6aba4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6aba8: mov             x1, x0
    // 0xc6abac: ldr             x0, [fp, #0x10]
    // 0xc6abb0: stur            x1, [fp, #-8]
    // 0xc6abb4: StoreField: r1->field_f = r0
    //     0xc6abb4: stur            w0, [x1, #0xf]
    // 0xc6abb8: r16 = Instance_EventChannel
    //     0xc6abb8: add             x16, PP, #0x54, lsl #12  ; [pp+0x540c8] Obj!EventChannel@b34a91
    //     0xc6abbc: ldr             x16, [x16, #0xc8]
    // 0xc6abc0: SaveReg r16
    //     0xc6abc0: str             x16, [SP, #-8]!
    // 0xc6abc4: r0 = receiveBroadcastStream()
    //     0xc6abc4: bl              #0x5a24c0  ; [package:flutter/src/services/platform_channel.dart] EventChannel::receiveBroadcastStream
    // 0xc6abc8: add             SP, SP, #8
    // 0xc6abcc: ldur            x2, [fp, #-8]
    // 0xc6abd0: r1 = Function '<anonymous closure>':.
    //     0xc6abd0: add             x1, PP, #0x54, lsl #12  ; [pp+0x540d0] AnonymousClosure: (0xc6ac30), in [package:camera_android/src/android_camera.dart] AndroidCamera::_startStreamListener (0xc6ab88)
    //     0xc6abd4: ldr             x1, [x1, #0xd0]
    // 0xc6abd8: stur            x0, [fp, #-8]
    // 0xc6abdc: r0 = AllocateClosure()
    //     0xc6abdc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6abe0: ldur            x16, [fp, #-8]
    // 0xc6abe4: stp             x0, x16, [SP, #-0x10]!
    // 0xc6abe8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc6abe8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc6abec: r0 = listen()
    //     0xc6abec: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xc6abf0: add             SP, SP, #0x10
    // 0xc6abf4: ldr             x1, [fp, #0x10]
    // 0xc6abf8: StoreField: r1->field_13 = r0
    //     0xc6abf8: stur            w0, [x1, #0x13]
    //     0xc6abfc: tbz             w0, #0, #0xc6ac18
    //     0xc6ac00: ldurb           w16, [x1, #-1]
    //     0xc6ac04: ldurb           w17, [x0, #-1]
    //     0xc6ac08: and             x16, x17, x16, lsr #2
    //     0xc6ac0c: tst             x16, HEAP, lsr #32
    //     0xc6ac10: b.eq            #0xc6ac18
    //     0xc6ac14: bl              #0xd6826c
    // 0xc6ac18: r0 = Null
    //     0xc6ac18: mov             x0, NULL
    // 0xc6ac1c: LeaveFrame
    //     0xc6ac1c: mov             SP, fp
    //     0xc6ac20: ldp             fp, lr, [SP], #0x10
    // 0xc6ac24: ret
    //     0xc6ac24: ret             
    // 0xc6ac28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ac28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ac2c: b               #0xc6aba0
  }
  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xc6ac30, size: 0x98
    // 0xc6ac30: EnterFrame
    //     0xc6ac30: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ac34: mov             fp, SP
    // 0xc6ac38: AllocStack(0x8)
    //     0xc6ac38: sub             SP, SP, #8
    // 0xc6ac3c: SetupParameters()
    //     0xc6ac3c: ldr             x0, [fp, #0x18]
    //     0xc6ac40: ldur            w1, [x0, #0x17]
    //     0xc6ac44: add             x1, x1, HEAP, lsl #32
    // 0xc6ac48: CheckStackOverflow
    //     0xc6ac48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ac4c: cmp             SP, x16
    //     0xc6ac50: b.ls            #0xc6acbc
    // 0xc6ac54: LoadField: r0 = r1->field_f
    //     0xc6ac54: ldur            w0, [x1, #0xf]
    // 0xc6ac58: DecompressPointer r0
    //     0xc6ac58: add             x0, x0, HEAP, lsl #32
    // 0xc6ac5c: LoadField: r3 = r0->field_17
    //     0xc6ac5c: ldur            w3, [x0, #0x17]
    // 0xc6ac60: DecompressPointer r3
    //     0xc6ac60: add             x3, x3, HEAP, lsl #32
    // 0xc6ac64: stur            x3, [fp, #-8]
    // 0xc6ac68: cmp             w3, NULL
    // 0xc6ac6c: b.eq            #0xc6acc4
    // 0xc6ac70: ldr             x0, [fp, #0x10]
    // 0xc6ac74: r2 = Null
    //     0xc6ac74: mov             x2, NULL
    // 0xc6ac78: r1 = Null
    //     0xc6ac78: mov             x1, NULL
    // 0xc6ac7c: r8 = Map
    //     0xc6ac7c: ldr             x8, [PP, #0x2338]  ; [pp+0x2338] Type: Map
    // 0xc6ac80: r3 = Null
    //     0xc6ac80: add             x3, PP, #0x54, lsl #12  ; [pp+0x540d8] Null
    //     0xc6ac84: ldr             x3, [x3, #0xd8]
    // 0xc6ac88: r0 = Map()
    //     0xc6ac88: bl              #0xd747e8  ; IsType_Map_Stub
    // 0xc6ac8c: ldr             x16, [fp, #0x10]
    // 0xc6ac90: SaveReg r16
    //     0xc6ac90: str             x16, [SP, #-8]!
    // 0xc6ac94: r0 = cameraImageFromPlatformData()
    //     0xc6ac94: bl              #0xc6acc8  ; [package:camera_android/src/type_conversion.dart] ::cameraImageFromPlatformData
    // 0xc6ac98: add             SP, SP, #8
    // 0xc6ac9c: ldur            x16, [fp, #-8]
    // 0xc6aca0: stp             x0, x16, [SP, #-0x10]!
    // 0xc6aca4: r0 = add()
    //     0xc6aca4: bl              #0xc23290  ; [dart:async] _StreamController::add
    // 0xc6aca8: add             SP, SP, #0x10
    // 0xc6acac: r0 = Null
    //     0xc6acac: mov             x0, NULL
    // 0xc6acb0: LeaveFrame
    //     0xc6acb0: mov             SP, fp
    //     0xc6acb4: ldp             fp, lr, [SP], #0x10
    // 0xc6acb8: ret
    //     0xc6acb8: ret             
    // 0xc6acbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6acbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6acc0: b               #0xc6ac54
    // 0xc6acc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc6acc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _installStreamController(/* No info */) {
    // ** addr: 0xc6b414, size: 0x128
    // 0xc6b414: EnterFrame
    //     0xc6b414: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b418: mov             fp, SP
    // 0xc6b41c: AllocStack(0x18)
    //     0xc6b41c: sub             SP, SP, #0x18
    // 0xc6b420: CheckStackOverflow
    //     0xc6b420: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6b424: cmp             SP, x16
    //     0xc6b428: b.ls            #0xc6b530
    // 0xc6b42c: r1 = 1
    //     0xc6b42c: mov             x1, #1
    // 0xc6b430: r0 = AllocateContext()
    //     0xc6b430: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6b434: mov             x1, x0
    // 0xc6b438: ldr             x0, [fp, #0x10]
    // 0xc6b43c: stur            x1, [fp, #-8]
    // 0xc6b440: StoreField: r1->field_f = r0
    //     0xc6b440: stur            w0, [x1, #0xf]
    // 0xc6b444: r1 = 1
    //     0xc6b444: mov             x1, #1
    // 0xc6b448: r0 = AllocateContext()
    //     0xc6b448: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6b44c: mov             x1, x0
    // 0xc6b450: ldr             x0, [fp, #0x10]
    // 0xc6b454: stur            x1, [fp, #-0x10]
    // 0xc6b458: StoreField: r1->field_f = r0
    //     0xc6b458: stur            w0, [x1, #0xf]
    // 0xc6b45c: r1 = 1
    //     0xc6b45c: mov             x1, #1
    // 0xc6b460: r0 = AllocateContext()
    //     0xc6b460: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6b464: mov             x3, x0
    // 0xc6b468: ldr             x0, [fp, #0x10]
    // 0xc6b46c: stur            x3, [fp, #-0x18]
    // 0xc6b470: StoreField: r3->field_f = r0
    //     0xc6b470: stur            w0, [x3, #0xf]
    // 0xc6b474: r1 = Function '<anonymous closure>':.
    //     0xc6b474: add             x1, PP, #0x54, lsl #12  ; [pp+0x541b8] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xc6b478: ldr             x1, [x1, #0x1b8]
    // 0xc6b47c: r2 = Null
    //     0xc6b47c: mov             x2, NULL
    // 0xc6b480: r0 = AllocateClosure()
    //     0xc6b480: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6b484: ldur            x2, [fp, #-8]
    // 0xc6b488: r1 = Function '_onFrameStreamPauseResume@172119562':.
    //     0xc6b488: add             x1, PP, #0x54, lsl #12  ; [pp+0x541c0] AnonymousClosure: (0xc6b658), in [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamPauseResume (0xc6b6a0)
    //     0xc6b48c: ldr             x1, [x1, #0x1c0]
    // 0xc6b490: stur            x0, [fp, #-8]
    // 0xc6b494: r0 = AllocateClosure()
    //     0xc6b494: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6b498: ldur            x2, [fp, #-0x10]
    // 0xc6b49c: r1 = Function '_onFrameStreamPauseResume@172119562':.
    //     0xc6b49c: add             x1, PP, #0x54, lsl #12  ; [pp+0x541c0] AnonymousClosure: (0xc6b658), in [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamPauseResume (0xc6b6a0)
    //     0xc6b4a0: ldr             x1, [x1, #0x1c0]
    // 0xc6b4a4: stur            x0, [fp, #-0x10]
    // 0xc6b4a8: r0 = AllocateClosure()
    //     0xc6b4a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6b4ac: ldur            x2, [fp, #-0x18]
    // 0xc6b4b0: r1 = Function '_onFrameStreamCancel@172119562':.
    //     0xc6b4b0: add             x1, PP, #0x54, lsl #12  ; [pp+0x541c8] AnonymousClosure: (0xc6b53c), in [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamCancel (0xc6b584)
    //     0xc6b4b4: ldr             x1, [x1, #0x1c8]
    // 0xc6b4b8: stur            x0, [fp, #-0x18]
    // 0xc6b4bc: r0 = AllocateClosure()
    //     0xc6b4bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6b4c0: r16 = <CameraImageData>
    //     0xc6b4c0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53c80] TypeArguments: <CameraImageData>
    //     0xc6b4c4: ldr             x16, [x16, #0xc80]
    // 0xc6b4c8: ldur            lr, [fp, #-8]
    // 0xc6b4cc: stp             lr, x16, [SP, #-0x10]!
    // 0xc6b4d0: ldur            x16, [fp, #-0x10]
    // 0xc6b4d4: ldur            lr, [fp, #-0x18]
    // 0xc6b4d8: stp             lr, x16, [SP, #-0x10]!
    // 0xc6b4dc: SaveReg r0
    //     0xc6b4dc: str             x0, [SP, #-8]!
    // 0xc6b4e0: r4 = const [0, 0x5, 0x5, 0x1, onCancel, 0x4, onListen, 0x1, onPause, 0x2, onResume, 0x3, null]
    //     0xc6b4e0: add             x4, PP, #0x53, lsl #12  ; [pp+0x53c88] List(13) [0, 0x5, 0x5, 0x1, "onCancel", 0x4, "onListen", 0x1, "onPause", 0x2, "onResume", 0x3, Null]
    //     0xc6b4e4: ldr             x4, [x4, #0xc88]
    // 0xc6b4e8: r0 = StreamController()
    //     0xc6b4e8: bl              #0x534f54  ; [dart:async] StreamController::StreamController
    // 0xc6b4ec: add             SP, SP, #0x28
    // 0xc6b4f0: mov             x2, x0
    // 0xc6b4f4: ldr             x1, [fp, #0x10]
    // 0xc6b4f8: StoreField: r1->field_17 = r0
    //     0xc6b4f8: stur            w0, [x1, #0x17]
    //     0xc6b4fc: tbz             w0, #0, #0xc6b518
    //     0xc6b500: ldurb           w16, [x1, #-1]
    //     0xc6b504: ldurb           w17, [x0, #-1]
    //     0xc6b508: and             x16, x17, x16, lsr #2
    //     0xc6b50c: tst             x16, HEAP, lsr #32
    //     0xc6b510: b.eq            #0xc6b518
    //     0xc6b514: bl              #0xd6826c
    // 0xc6b518: cmp             w2, NULL
    // 0xc6b51c: b.eq            #0xc6b538
    // 0xc6b520: mov             x0, x2
    // 0xc6b524: LeaveFrame
    //     0xc6b524: mov             SP, fp
    //     0xc6b528: ldp             fp, lr, [SP], #0x10
    // 0xc6b52c: ret
    //     0xc6b52c: ret             
    // 0xc6b530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6b530: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6b534: b               #0xc6b42c
    // 0xc6b538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc6b538: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onFrameStreamCancel(dynamic) {
    // ** addr: 0xc6b53c, size: 0x48
    // 0xc6b53c: EnterFrame
    //     0xc6b53c: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b540: mov             fp, SP
    // 0xc6b544: ldr             x0, [fp, #0x10]
    // 0xc6b548: LoadField: r1 = r0->field_17
    //     0xc6b548: ldur            w1, [x0, #0x17]
    // 0xc6b54c: DecompressPointer r1
    //     0xc6b54c: add             x1, x1, HEAP, lsl #32
    // 0xc6b550: CheckStackOverflow
    //     0xc6b550: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6b554: cmp             SP, x16
    //     0xc6b558: b.ls            #0xc6b57c
    // 0xc6b55c: LoadField: r0 = r1->field_f
    //     0xc6b55c: ldur            w0, [x1, #0xf]
    // 0xc6b560: DecompressPointer r0
    //     0xc6b560: add             x0, x0, HEAP, lsl #32
    // 0xc6b564: SaveReg r0
    //     0xc6b564: str             x0, [SP, #-8]!
    // 0xc6b568: r0 = _onFrameStreamCancel()
    //     0xc6b568: bl              #0xc6b584  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamCancel
    // 0xc6b56c: add             SP, SP, #8
    // 0xc6b570: LeaveFrame
    //     0xc6b570: mov             SP, fp
    //     0xc6b574: ldp             fp, lr, [SP], #0x10
    // 0xc6b578: ret
    //     0xc6b578: ret             
    // 0xc6b57c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6b57c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6b580: b               #0xc6b55c
  }
  _ _onFrameStreamCancel(/* No info */) async {
    // ** addr: 0xc6b584, size: 0xd4
    // 0xc6b584: EnterFrame
    //     0xc6b584: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b588: mov             fp, SP
    // 0xc6b58c: AllocStack(0x18)
    //     0xc6b58c: sub             SP, SP, #0x18
    // 0xc6b590: SetupParameters(AndroidCamera this /* r1, fp-0x10 */)
    //     0xc6b590: stur            NULL, [fp, #-8]
    //     0xc6b594: mov             x0, #0
    //     0xc6b598: add             x1, fp, w0, sxtw #2
    //     0xc6b59c: ldr             x1, [x1, #0x10]
    //     0xc6b5a0: stur            x1, [fp, #-0x10]
    // 0xc6b5a4: CheckStackOverflow
    //     0xc6b5a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6b5a8: cmp             SP, x16
    //     0xc6b5ac: b.ls            #0xc6b650
    // 0xc6b5b0: InitAsync() -> Future
    //     0xc6b5b0: mov             x0, NULL
    //     0xc6b5b4: bl              #0x4b92e4
    // 0xc6b5b8: r16 = <void?>
    //     0xc6b5b8: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc6b5bc: r30 = Instance_MethodChannel
    //     0xc6b5bc: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc6b5c0: ldr             lr, [lr, #0x378]
    // 0xc6b5c4: stp             lr, x16, [SP, #-0x10]!
    // 0xc6b5c8: r16 = "stopImageStream"
    //     0xc6b5c8: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d6c0] "stopImageStream"
    //     0xc6b5cc: ldr             x16, [x16, #0x6c0]
    // 0xc6b5d0: SaveReg r16
    //     0xc6b5d0: str             x16, [SP, #-8]!
    // 0xc6b5d4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6b5d4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6b5d8: r0 = invokeMethod()
    //     0xc6b5d8: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6b5dc: add             SP, SP, #0x18
    // 0xc6b5e0: mov             x1, x0
    // 0xc6b5e4: stur            x1, [fp, #-0x18]
    // 0xc6b5e8: r0 = Await()
    //     0xc6b5e8: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6b5ec: ldur            x1, [fp, #-0x10]
    // 0xc6b5f0: LoadField: r0 = r1->field_13
    //     0xc6b5f0: ldur            w0, [x1, #0x13]
    // 0xc6b5f4: DecompressPointer r0
    //     0xc6b5f4: add             x0, x0, HEAP, lsl #32
    // 0xc6b5f8: cmp             w0, NULL
    // 0xc6b5fc: b.ne            #0xc6b608
    // 0xc6b600: r2 = Null
    //     0xc6b600: mov             x2, NULL
    // 0xc6b604: b               #0xc6b630
    // 0xc6b608: r2 = LoadClassIdInstr(r0)
    //     0xc6b608: ldur            x2, [x0, #-1]
    //     0xc6b60c: ubfx            x2, x2, #0xc, #0x14
    // 0xc6b610: SaveReg r0
    //     0xc6b610: str             x0, [SP, #-8]!
    // 0xc6b614: mov             x0, x2
    // 0xc6b618: r0 = GDT[cid_x0 + 0x307]()
    //     0xc6b618: add             lr, x0, #0x307
    //     0xc6b61c: ldr             lr, [x21, lr, lsl #3]
    //     0xc6b620: blr             lr
    // 0xc6b624: add             SP, SP, #8
    // 0xc6b628: mov             x2, x0
    // 0xc6b62c: ldur            x1, [fp, #-0x10]
    // 0xc6b630: mov             x0, x2
    // 0xc6b634: stur            x2, [fp, #-0x18]
    // 0xc6b638: r0 = Await()
    //     0xc6b638: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6b63c: ldur            x1, [fp, #-0x10]
    // 0xc6b640: StoreField: r1->field_13 = rNULL
    //     0xc6b640: stur            NULL, [x1, #0x13]
    // 0xc6b644: StoreField: r1->field_17 = rNULL
    //     0xc6b644: stur            NULL, [x1, #0x17]
    // 0xc6b648: r0 = Null
    //     0xc6b648: mov             x0, NULL
    // 0xc6b64c: r0 = ReturnAsyncNotFuture()
    //     0xc6b64c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc6b650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6b650: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6b654: b               #0xc6b5b0
  }
  [closure] void _onFrameStreamPauseResume(dynamic) {
    // ** addr: 0xc6b658, size: 0x48
    // 0xc6b658: EnterFrame
    //     0xc6b658: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b65c: mov             fp, SP
    // 0xc6b660: ldr             x0, [fp, #0x10]
    // 0xc6b664: LoadField: r1 = r0->field_17
    //     0xc6b664: ldur            w1, [x0, #0x17]
    // 0xc6b668: DecompressPointer r1
    //     0xc6b668: add             x1, x1, HEAP, lsl #32
    // 0xc6b66c: CheckStackOverflow
    //     0xc6b66c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6b670: cmp             SP, x16
    //     0xc6b674: b.ls            #0xc6b698
    // 0xc6b678: LoadField: r0 = r1->field_f
    //     0xc6b678: ldur            w0, [x1, #0xf]
    // 0xc6b67c: DecompressPointer r0
    //     0xc6b67c: add             x0, x0, HEAP, lsl #32
    // 0xc6b680: SaveReg r0
    //     0xc6b680: str             x0, [SP, #-8]!
    // 0xc6b684: r0 = _onFrameStreamPauseResume()
    //     0xc6b684: bl              #0xc6b6a0  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamPauseResume
    // 0xc6b688: add             SP, SP, #8
    // 0xc6b68c: LeaveFrame
    //     0xc6b68c: mov             SP, fp
    //     0xc6b690: ldp             fp, lr, [SP], #0x10
    // 0xc6b694: ret
    //     0xc6b694: ret             
    // 0xc6b698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6b698: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6b69c: b               #0xc6b678
  }
  _ _onFrameStreamPauseResume(/* No info */) {
    // ** addr: 0xc6b6a0, size: 0x34
    // 0xc6b6a0: EnterFrame
    //     0xc6b6a0: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b6a4: mov             fp, SP
    // 0xc6b6a8: r0 = CameraException()
    //     0xc6b6a8: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc6b6ac: mov             x1, x0
    // 0xc6b6b0: r0 = "InvalidCall"
    //     0xc6b6b0: add             x0, PP, #0x53, lsl #12  ; [pp+0x53c90] "InvalidCall"
    //     0xc6b6b4: ldr             x0, [x0, #0xc90]
    // 0xc6b6b8: StoreField: r1->field_7 = r0
    //     0xc6b6b8: stur            w0, [x1, #7]
    // 0xc6b6bc: r0 = "Pause and resume are not supported for onStreamedFrameAvailable"
    //     0xc6b6bc: add             x0, PP, #0x53, lsl #12  ; [pp+0x53c98] "Pause and resume are not supported for onStreamedFrameAvailable"
    //     0xc6b6c0: ldr             x0, [x0, #0xc98]
    // 0xc6b6c4: StoreField: r1->field_b = r0
    //     0xc6b6c4: stur            w0, [x1, #0xb]
    // 0xc6b6c8: mov             x0, x1
    // 0xc6b6cc: r0 = Throw()
    //     0xc6b6cc: bl              #0xd67e38  ; ThrowStub
    // 0xc6b6d0: brk             #0
  }
  _ takePicture(/* No info */) async {
    // ** addr: 0xc72d3c, size: 0x1e0
    // 0xc72d3c: EnterFrame
    //     0xc72d3c: stp             fp, lr, [SP, #-0x10]!
    //     0xc72d40: mov             fp, SP
    // 0xc72d44: AllocStack(0x20)
    //     0xc72d44: sub             SP, SP, #0x20
    // 0xc72d48: SetupParameters(AndroidCamera this /* r1, fp-0x10 */)
    //     0xc72d48: stur            NULL, [fp, #-8]
    //     0xc72d4c: mov             x0, #0
    //     0xc72d50: add             x1, fp, w0, sxtw #2
    //     0xc72d54: ldr             x1, [x1, #0x10]
    //     0xc72d58: stur            x1, [fp, #-0x10]
    // 0xc72d5c: CheckStackOverflow
    //     0xc72d5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc72d60: cmp             SP, x16
    //     0xc72d64: b.ls            #0xc72f14
    // 0xc72d68: InitAsync() -> Future<XFile>
    //     0xc72d68: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d698] TypeArguments: <XFile>
    //     0xc72d6c: ldr             x0, [x0, #0x698]
    //     0xc72d70: bl              #0x4b92e4
    // 0xc72d74: r1 = Null
    //     0xc72d74: mov             x1, NULL
    // 0xc72d78: r2 = 4
    //     0xc72d78: mov             x2, #4
    // 0xc72d7c: r0 = AllocateArray()
    //     0xc72d7c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc72d80: mov             x2, x0
    // 0xc72d84: r17 = "cameraId"
    //     0xc72d84: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc72d88: ldr             x17, [x17, #0x890]
    // 0xc72d8c: StoreField: r2->field_f = r17
    //     0xc72d8c: stur            w17, [x2, #0xf]
    // 0xc72d90: ldur            x3, [fp, #-0x10]
    // 0xc72d94: r0 = BoxInt64Instr(r3)
    //     0xc72d94: sbfiz           x0, x3, #1, #0x1f
    //     0xc72d98: cmp             x3, x0, asr #1
    //     0xc72d9c: b.eq            #0xc72da8
    //     0xc72da0: bl              #0xd69bb8
    //     0xc72da4: stur            x3, [x0, #7]
    // 0xc72da8: StoreField: r2->field_13 = r0
    //     0xc72da8: stur            w0, [x2, #0x13]
    // 0xc72dac: r16 = <String, dynamic>
    //     0xc72dac: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc72db0: stp             x2, x16, [SP, #-0x10]!
    // 0xc72db4: r0 = Map._fromLiteral()
    //     0xc72db4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc72db8: add             SP, SP, #0x10
    // 0xc72dbc: r16 = <String>
    //     0xc72dbc: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xc72dc0: r30 = Instance_MethodChannel
    //     0xc72dc0: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc72dc4: ldr             lr, [lr, #0x378]
    // 0xc72dc8: stp             lr, x16, [SP, #-0x10]!
    // 0xc72dcc: r16 = "takePicture"
    //     0xc72dcc: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d788] "takePicture"
    //     0xc72dd0: ldr             x16, [x16, #0x788]
    // 0xc72dd4: stp             x0, x16, [SP, #-0x10]!
    // 0xc72dd8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc72dd8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc72ddc: r0 = invokeMethod()
    //     0xc72ddc: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc72de0: add             SP, SP, #0x20
    // 0xc72de4: mov             x1, x0
    // 0xc72de8: stur            x1, [fp, #-0x18]
    // 0xc72dec: r0 = Await()
    //     0xc72dec: bl              #0x4b8e6c  ; AwaitStub
    // 0xc72df0: stur            x0, [fp, #-0x20]
    // 0xc72df4: cmp             w0, NULL
    // 0xc72df8: b.eq            #0xc72e84
    // 0xc72dfc: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc72dfc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc72e00: ldr             x0, [x0, #0xb58]
    //     0xc72e04: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc72e08: cmp             w0, w16
    //     0xc72e0c: b.ne            #0xc72e18
    //     0xc72e10: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc72e14: bl              #0xd67d44
    // 0xc72e18: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc72e18: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc72e1c: ldr             x0, [x0, #0xdd8]
    //     0xc72e20: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc72e24: cmp             w0, w16
    //     0xc72e28: b.ne            #0xc72e34
    //     0xc72e2c: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc72e30: bl              #0xd67cdc
    // 0xc72e34: r0 = _File()
    //     0xc72e34: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xc72e38: mov             x1, x0
    // 0xc72e3c: ldur            x0, [fp, #-0x20]
    // 0xc72e40: stur            x1, [fp, #-0x18]
    // 0xc72e44: StoreField: r1->field_7 = r0
    //     0xc72e44: stur            w0, [x1, #7]
    // 0xc72e48: SaveReg r0
    //     0xc72e48: str             x0, [SP, #-8]!
    // 0xc72e4c: r0 = _toUtf8Array()
    //     0xc72e4c: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc72e50: add             SP, SP, #8
    // 0xc72e54: ldur            x1, [fp, #-0x18]
    // 0xc72e58: StoreField: r1->field_b = r0
    //     0xc72e58: stur            w0, [x1, #0xb]
    //     0xc72e5c: ldurb           w16, [x1, #-1]
    //     0xc72e60: ldurb           w17, [x0, #-1]
    //     0xc72e64: and             x16, x17, x16, lsr #2
    //     0xc72e68: tst             x16, HEAP, lsr #32
    //     0xc72e6c: b.eq            #0xc72e74
    //     0xc72e70: bl              #0xd6826c
    // 0xc72e74: r0 = XFile()
    //     0xc72e74: bl              #0xc6a500  ; AllocateXFileStub -> XFile (size=0x10)
    // 0xc72e78: ldur            x1, [fp, #-0x18]
    // 0xc72e7c: StoreField: r0->field_7 = r1
    //     0xc72e7c: stur            w1, [x0, #7]
    // 0xc72e80: r0 = ReturnAsyncNotFuture()
    //     0xc72e80: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc72e84: r1 = Null
    //     0xc72e84: mov             x1, NULL
    // 0xc72e88: r2 = 6
    //     0xc72e88: mov             x2, #6
    // 0xc72e8c: r0 = AllocateArray()
    //     0xc72e8c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc72e90: stur            x0, [fp, #-0x18]
    // 0xc72e94: r17 = "The platform \""
    //     0xc72e94: add             x17, PP, #0x53, lsl #12  ; [pp+0x53af8] "The platform \""
    //     0xc72e98: ldr             x17, [x17, #0xaf8]
    // 0xc72e9c: StoreField: r0->field_f = r17
    //     0xc72e9c: stur            w17, [x0, #0xf]
    // 0xc72ea0: r0 = defaultTargetPlatform()
    //     0xc72ea0: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xc72ea4: ldur            x1, [fp, #-0x18]
    // 0xc72ea8: ArrayStore: r1[1] = r0  ; List_4
    //     0xc72ea8: add             x25, x1, #0x13
    //     0xc72eac: str             w0, [x25]
    //     0xc72eb0: tbz             w0, #0, #0xc72ecc
    //     0xc72eb4: ldurb           w16, [x1, #-1]
    //     0xc72eb8: ldurb           w17, [x0, #-1]
    //     0xc72ebc: and             x16, x17, x16, lsr #2
    //     0xc72ec0: tst             x16, HEAP, lsr #32
    //     0xc72ec4: b.eq            #0xc72ecc
    //     0xc72ec8: bl              #0xd67e5c
    // 0xc72ecc: ldur            x0, [fp, #-0x18]
    // 0xc72ed0: r17 = "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc72ed0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b00] "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc72ed4: ldr             x17, [x17, #0xb00]
    // 0xc72ed8: StoreField: r0->field_17 = r17
    //     0xc72ed8: stur            w17, [x0, #0x17]
    // 0xc72edc: SaveReg r0
    //     0xc72edc: str             x0, [SP, #-8]!
    // 0xc72ee0: r0 = _interpolate()
    //     0xc72ee0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc72ee4: add             SP, SP, #8
    // 0xc72ee8: stur            x0, [fp, #-0x18]
    // 0xc72eec: r0 = CameraException()
    //     0xc72eec: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc72ef0: mov             x1, x0
    // 0xc72ef4: r0 = "INVALID_PATH"
    //     0xc72ef4: add             x0, PP, #0x53, lsl #12  ; [pp+0x53b08] "INVALID_PATH"
    //     0xc72ef8: ldr             x0, [x0, #0xb08]
    // 0xc72efc: StoreField: r1->field_7 = r0
    //     0xc72efc: stur            w0, [x1, #7]
    // 0xc72f00: ldur            x0, [fp, #-0x18]
    // 0xc72f04: StoreField: r1->field_b = r0
    //     0xc72f04: stur            w0, [x1, #0xb]
    // 0xc72f08: mov             x0, x1
    // 0xc72f0c: r0 = Throw()
    //     0xc72f0c: bl              #0xd67e38  ; ThrowStub
    // 0xc72f10: brk             #0
    // 0xc72f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc72f14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc72f18: b               #0xc72d68
  }
  _ onCameraInitialized(/* No info */) {
    // ** addr: 0xc758ac, size: 0x58
    // 0xc758ac: EnterFrame
    //     0xc758ac: stp             fp, lr, [SP, #-0x10]!
    //     0xc758b0: mov             fp, SP
    // 0xc758b4: CheckStackOverflow
    //     0xc758b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc758b8: cmp             SP, x16
    //     0xc758bc: b.ls            #0xc758fc
    // 0xc758c0: ldr             x16, [fp, #0x18]
    // 0xc758c4: SaveReg r16
    //     0xc758c4: str             x16, [SP, #-8]!
    // 0xc758c8: ldr             x0, [fp, #0x10]
    // 0xc758cc: SaveReg r0
    //     0xc758cc: str             x0, [SP, #-8]!
    // 0xc758d0: r0 = _cameraEvents()
    //     0xc758d0: bl              #0x5aa63c  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_cameraEvents
    // 0xc758d4: add             SP, SP, #0x10
    // 0xc758d8: r16 = <CameraEvent, CameraInitializedEvent>
    //     0xc758d8: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d3a8] TypeArguments: <CameraEvent, CameraInitializedEvent>
    //     0xc758dc: ldr             x16, [x16, #0x3a8]
    // 0xc758e0: stp             x0, x16, [SP, #-0x10]!
    // 0xc758e4: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xc758e4: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xc758e8: r0 = Where.whereType()
    //     0xc758e8: bl              #0x5aa93c  ; [package:stream_transform/src/where.dart] ::Where.whereType
    // 0xc758ec: add             SP, SP, #0x10
    // 0xc758f0: LeaveFrame
    //     0xc758f0: mov             SP, fp
    //     0xc758f4: ldp             fp, lr, [SP], #0x10
    // 0xc758f8: ret
    //     0xc758f8: ret             
    // 0xc758fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc758fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc75900: b               #0xc758c0
  }
  _ dispose(/* No info */) async {
    // ** addr: 0xc76344, size: 0x14c
    // 0xc76344: EnterFrame
    //     0xc76344: stp             fp, lr, [SP, #-0x10]!
    //     0xc76348: mov             fp, SP
    // 0xc7634c: AllocStack(0x20)
    //     0xc7634c: sub             SP, SP, #0x20
    // 0xc76350: SetupParameters(AndroidCamera this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xc76350: stur            NULL, [fp, #-8]
    //     0xc76354: mov             x0, #0
    //     0xc76358: add             x1, fp, w0, sxtw #2
    //     0xc7635c: ldr             x1, [x1, #0x18]
    //     0xc76360: stur            x1, [fp, #-0x18]
    //     0xc76364: add             x2, fp, w0, sxtw #2
    //     0xc76368: ldr             x2, [x2, #0x10]
    //     0xc7636c: stur            x2, [fp, #-0x10]
    // 0xc76370: CheckStackOverflow
    //     0xc76370: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc76374: cmp             SP, x16
    //     0xc76378: b.ls            #0xc76488
    // 0xc7637c: InitAsync() -> Future<void?>
    //     0xc7637c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc76380: bl              #0x4b92e4
    // 0xc76384: ldur            x0, [fp, #-0x18]
    // 0xc76388: LoadField: r2 = r0->field_7
    //     0xc76388: ldur            w2, [x0, #7]
    // 0xc7638c: DecompressPointer r2
    //     0xc7638c: add             x2, x2, HEAP, lsl #32
    // 0xc76390: ldur            x3, [fp, #-0x10]
    // 0xc76394: stur            x2, [fp, #-0x20]
    // 0xc76398: r0 = BoxInt64Instr(r3)
    //     0xc76398: sbfiz           x0, x3, #1, #0x1f
    //     0xc7639c: cmp             x3, x0, asr #1
    //     0xc763a0: b.eq            #0xc763ac
    //     0xc763a4: bl              #0xd69bb8
    //     0xc763a8: stur            x3, [x0, #7]
    // 0xc763ac: stur            x0, [fp, #-0x18]
    // 0xc763b0: stp             x0, x2, [SP, #-0x10]!
    // 0xc763b4: r0 = containsKey()
    //     0xc763b4: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xc763b8: add             SP, SP, #0x10
    // 0xc763bc: tbnz            w0, #4, #0xc76418
    // 0xc763c0: ldur            x0, [fp, #-0x20]
    // 0xc763c4: ldur            x16, [fp, #-0x18]
    // 0xc763c8: stp             x16, x0, [SP, #-0x10]!
    // 0xc763cc: r0 = _getValueOrData()
    //     0xc763cc: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc763d0: add             SP, SP, #0x10
    // 0xc763d4: mov             x1, x0
    // 0xc763d8: ldur            x0, [fp, #-0x20]
    // 0xc763dc: LoadField: r2 = r0->field_f
    //     0xc763dc: ldur            w2, [x0, #0xf]
    // 0xc763e0: DecompressPointer r2
    //     0xc763e0: add             x2, x2, HEAP, lsl #32
    // 0xc763e4: cmp             w2, w1
    // 0xc763e8: b.ne            #0xc763f0
    // 0xc763ec: r1 = Null
    //     0xc763ec: mov             x1, NULL
    // 0xc763f0: cmp             w1, NULL
    // 0xc763f4: b.eq            #0xc76404
    // 0xc763f8: stp             NULL, x1, [SP, #-0x10]!
    // 0xc763fc: r0 = setMethodCallHandler()
    //     0xc763fc: bl              #0x5a84a0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0xc76400: add             SP, SP, #0x10
    // 0xc76404: ldur            x16, [fp, #-0x20]
    // 0xc76408: ldur            lr, [fp, #-0x18]
    // 0xc7640c: stp             lr, x16, [SP, #-0x10]!
    // 0xc76410: r0 = remove()
    //     0xc76410: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc76414: add             SP, SP, #0x10
    // 0xc76418: ldur            x0, [fp, #-0x18]
    // 0xc7641c: r1 = Null
    //     0xc7641c: mov             x1, NULL
    // 0xc76420: r2 = 4
    //     0xc76420: mov             x2, #4
    // 0xc76424: r0 = AllocateArray()
    //     0xc76424: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc76428: r17 = "cameraId"
    //     0xc76428: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc7642c: ldr             x17, [x17, #0x890]
    // 0xc76430: StoreField: r0->field_f = r17
    //     0xc76430: stur            w17, [x0, #0xf]
    // 0xc76434: ldur            x1, [fp, #-0x18]
    // 0xc76438: StoreField: r0->field_13 = r1
    //     0xc76438: stur            w1, [x0, #0x13]
    // 0xc7643c: r16 = <String, dynamic>
    //     0xc7643c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc76440: stp             x0, x16, [SP, #-0x10]!
    // 0xc76444: r0 = Map._fromLiteral()
    //     0xc76444: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc76448: add             SP, SP, #0x10
    // 0xc7644c: r16 = <void?>
    //     0xc7644c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc76450: r30 = Instance_MethodChannel
    //     0xc76450: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc76454: ldr             lr, [lr, #0x378]
    // 0xc76458: stp             lr, x16, [SP, #-0x10]!
    // 0xc7645c: r16 = "dispose"
    //     0xc7645c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f010] "dispose"
    //     0xc76460: ldr             x16, [x16, #0x10]
    // 0xc76464: stp             x0, x16, [SP, #-0x10]!
    // 0xc76468: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc76468: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc7646c: r0 = invokeMethod()
    //     0xc7646c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc76470: add             SP, SP, #0x20
    // 0xc76474: mov             x1, x0
    // 0xc76478: stur            x1, [fp, #-0x18]
    // 0xc7647c: r0 = Await()
    //     0xc7647c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc76480: r0 = Null
    //     0xc76480: mov             x0, NULL
    // 0xc76484: r0 = ReturnAsyncNotFuture()
    //     0xc76484: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc76488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc76488: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7648c: b               #0xc7637c
  }
  _ initializeCamera(/* No info */) {
    // ** addr: 0xc76834, size: 0x20c
    // 0xc76834: EnterFrame
    //     0xc76834: stp             fp, lr, [SP, #-0x10]!
    //     0xc76838: mov             fp, SP
    // 0xc7683c: AllocStack(0x18)
    //     0xc7683c: sub             SP, SP, #0x18
    // 0xc76840: CheckStackOverflow
    //     0xc76840: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc76844: cmp             SP, x16
    //     0xc76848: b.ls            #0xc76a38
    // 0xc7684c: r1 = 3
    //     0xc7684c: mov             x1, #3
    // 0xc76850: r0 = AllocateContext()
    //     0xc76850: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc76854: mov             x4, x0
    // 0xc76858: ldr             x3, [fp, #0x20]
    // 0xc7685c: stur            x4, [fp, #-0x18]
    // 0xc76860: StoreField: r4->field_f = r3
    //     0xc76860: stur            w3, [x4, #0xf]
    // 0xc76864: ldr             x2, [fp, #0x18]
    // 0xc76868: r0 = BoxInt64Instr(r2)
    //     0xc76868: sbfiz           x0, x2, #1, #0x1f
    //     0xc7686c: cmp             x2, x0, asr #1
    //     0xc76870: b.eq            #0xc7687c
    //     0xc76874: bl              #0xd69bb8
    //     0xc76878: stur            x2, [x0, #7]
    // 0xc7687c: stur            x0, [fp, #-0x10]
    // 0xc76880: StoreField: r4->field_13 = r0
    //     0xc76880: stur            w0, [x4, #0x13]
    // 0xc76884: LoadField: r5 = r3->field_7
    //     0xc76884: ldur            w5, [x3, #7]
    // 0xc76888: DecompressPointer r5
    //     0xc76888: add             x5, x5, HEAP, lsl #32
    // 0xc7688c: mov             x2, x4
    // 0xc76890: stur            x5, [fp, #-8]
    // 0xc76894: r1 = Function '<anonymous closure>':.
    //     0xc76894: add             x1, PP, #0x54, lsl #12  ; [pp+0x541d0] AnonymousClosure: (0xc76afc), in [package:camera_android/src/android_camera.dart] AndroidCamera::initializeCamera (0xc76834)
    //     0xc76898: ldr             x1, [x1, #0x1d0]
    // 0xc7689c: r0 = AllocateClosure()
    //     0xc7689c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc768a0: ldur            x16, [fp, #-8]
    // 0xc768a4: ldur            lr, [fp, #-0x10]
    // 0xc768a8: stp             lr, x16, [SP, #-0x10]!
    // 0xc768ac: SaveReg r0
    //     0xc768ac: str             x0, [SP, #-8]!
    // 0xc768b0: r0 = putIfAbsent()
    //     0xc768b0: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xc768b4: add             SP, SP, #0x18
    // 0xc768b8: r1 = <void?>
    //     0xc768b8: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc768bc: r0 = _Future()
    //     0xc768bc: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xc768c0: mov             x1, x0
    // 0xc768c4: r0 = 0
    //     0xc768c4: mov             x0, #0
    // 0xc768c8: stur            x1, [fp, #-8]
    // 0xc768cc: StoreField: r1->field_b = r0
    //     0xc768cc: stur            x0, [x1, #0xb]
    // 0xc768d0: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc768d0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc768d4: ldr             x0, [x0, #0xb58]
    //     0xc768d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc768dc: cmp             w0, w16
    //     0xc768e0: b.ne            #0xc768ec
    //     0xc768e4: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc768e8: bl              #0xd67d44
    // 0xc768ec: mov             x1, x0
    // 0xc768f0: ldur            x0, [fp, #-8]
    // 0xc768f4: StoreField: r0->field_13 = r1
    //     0xc768f4: stur            w1, [x0, #0x13]
    // 0xc768f8: r1 = <void?>
    //     0xc768f8: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc768fc: r0 = _AsyncCompleter()
    //     0xc768fc: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xc76900: ldur            x1, [fp, #-8]
    // 0xc76904: StoreField: r0->field_b = r1
    //     0xc76904: stur            w1, [x0, #0xb]
    // 0xc76908: ldur            x2, [fp, #-0x18]
    // 0xc7690c: StoreField: r2->field_17 = r0
    //     0xc7690c: stur            w0, [x2, #0x17]
    //     0xc76910: ldurb           w16, [x2, #-1]
    //     0xc76914: ldurb           w17, [x0, #-1]
    //     0xc76918: and             x16, x17, x16, lsr #2
    //     0xc7691c: tst             x16, HEAP, lsr #32
    //     0xc76920: b.eq            #0xc76928
    //     0xc76924: bl              #0xd6828c
    // 0xc76928: LoadField: r0 = r2->field_13
    //     0xc76928: ldur            w0, [x2, #0x13]
    // 0xc7692c: DecompressPointer r0
    //     0xc7692c: add             x0, x0, HEAP, lsl #32
    // 0xc76930: r3 = LoadInt32Instr(r0)
    //     0xc76930: sbfx            x3, x0, #1, #0x1f
    //     0xc76934: tbz             w0, #0, #0xc7693c
    //     0xc76938: ldur            x3, [x0, #7]
    // 0xc7693c: ldr             x16, [fp, #0x20]
    // 0xc76940: stp             x3, x16, [SP, #-0x10]!
    // 0xc76944: r0 = onCameraInitialized()
    //     0xc76944: bl              #0xc758ac  ; [package:camera_android/src/android_camera.dart] AndroidCamera::onCameraInitialized
    // 0xc76948: add             SP, SP, #0x10
    // 0xc7694c: SaveReg r0
    //     0xc7694c: str             x0, [SP, #-8]!
    // 0xc76950: r0 = first()
    //     0xc76950: bl              #0x5aa0d4  ; [dart:async] Stream::first
    // 0xc76954: add             SP, SP, #8
    // 0xc76958: ldur            x2, [fp, #-0x18]
    // 0xc7695c: r1 = Function '<anonymous closure>':.
    //     0xc7695c: add             x1, PP, #0x54, lsl #12  ; [pp+0x541d8] AnonymousClosure: (0x9ec1e4), in [package:flutter3_frame/modules/chat/chat_user_logic.dart] ChatUserLogic::getUserFromServer (0x9ebfe8)
    //     0xc76960: ldr             x1, [x1, #0x1d8]
    // 0xc76964: stur            x0, [fp, #-0x10]
    // 0xc76968: r0 = AllocateClosure()
    //     0xc76968: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc7696c: r16 = <Null?>
    //     0xc7696c: ldr             x16, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    // 0xc76970: ldur            lr, [fp, #-0x10]
    // 0xc76974: stp             lr, x16, [SP, #-0x10]!
    // 0xc76978: SaveReg r0
    //     0xc76978: str             x0, [SP, #-8]!
    // 0xc7697c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc7697c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc76980: r0 = then()
    //     0xc76980: bl              #0xca6124  ; [dart:async] _Future::then
    // 0xc76984: add             SP, SP, #0x18
    // 0xc76988: r1 = Null
    //     0xc76988: mov             x1, NULL
    // 0xc7698c: r2 = 8
    //     0xc7698c: mov             x2, #8
    // 0xc76990: r0 = AllocateArray()
    //     0xc76990: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc76994: r17 = "cameraId"
    //     0xc76994: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc76998: ldr             x17, [x17, #0x890]
    // 0xc7699c: StoreField: r0->field_f = r17
    //     0xc7699c: stur            w17, [x0, #0xf]
    // 0xc769a0: ldur            x2, [fp, #-0x18]
    // 0xc769a4: LoadField: r1 = r2->field_13
    //     0xc769a4: ldur            w1, [x2, #0x13]
    // 0xc769a8: DecompressPointer r1
    //     0xc769a8: add             x1, x1, HEAP, lsl #32
    // 0xc769ac: StoreField: r0->field_13 = r1
    //     0xc769ac: stur            w1, [x0, #0x13]
    // 0xc769b0: r17 = "imageFormatGroup"
    //     0xc769b0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53cb0] "imageFormatGroup"
    //     0xc769b4: ldr             x17, [x17, #0xcb0]
    // 0xc769b8: StoreField: r0->field_17 = r17
    //     0xc769b8: stur            w17, [x0, #0x17]
    // 0xc769bc: r17 = "unknown"
    //     0xc769bc: add             x17, PP, #0x14, lsl #12  ; [pp+0x14af8] "unknown"
    //     0xc769c0: ldr             x17, [x17, #0xaf8]
    // 0xc769c4: StoreField: r0->field_1b = r17
    //     0xc769c4: stur            w17, [x0, #0x1b]
    // 0xc769c8: r16 = <String, dynamic>
    //     0xc769c8: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc769cc: stp             x0, x16, [SP, #-0x10]!
    // 0xc769d0: r0 = Map._fromLiteral()
    //     0xc769d0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc769d4: add             SP, SP, #0x10
    // 0xc769d8: r16 = <String, dynamic>
    //     0xc769d8: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc769dc: r30 = Instance_MethodChannel
    //     0xc769dc: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc769e0: ldr             lr, [lr, #0x378]
    // 0xc769e4: stp             lr, x16, [SP, #-0x10]!
    // 0xc769e8: r16 = "initialize"
    //     0xc769e8: add             x16, PP, #0x53, lsl #12  ; [pp+0x53cb8] "initialize"
    //     0xc769ec: ldr             x16, [x16, #0xcb8]
    // 0xc769f0: stp             x0, x16, [SP, #-0x10]!
    // 0xc769f4: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0xc769f4: ldr             x4, [PP, #0x8c0]  ; [pp+0x8c0] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0xc769f8: r0 = invokeMapMethod()
    //     0xc769f8: bl              #0x5a21c4  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0xc769fc: add             SP, SP, #0x20
    // 0xc76a00: ldur            x2, [fp, #-0x18]
    // 0xc76a04: r1 = Function '<anonymous closure>':.
    //     0xc76a04: add             x1, PP, #0x54, lsl #12  ; [pp+0x541e0] AnonymousClosure: (0xc76a40), in [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::initializeCamera (0xc78354)
    //     0xc76a08: ldr             x1, [x1, #0x1e0]
    // 0xc76a0c: stur            x0, [fp, #-0x10]
    // 0xc76a10: r0 = AllocateClosure()
    //     0xc76a10: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc76a14: ldur            x16, [fp, #-0x10]
    // 0xc76a18: stp             x0, x16, [SP, #-0x10]!
    // 0xc76a1c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc76a1c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc76a20: r0 = catchError()
    //     0xc76a20: bl              #0xca5bb8  ; [dart:async] _Future::catchError
    // 0xc76a24: add             SP, SP, #0x10
    // 0xc76a28: ldur            x0, [fp, #-8]
    // 0xc76a2c: LeaveFrame
    //     0xc76a2c: mov             SP, fp
    //     0xc76a30: ldp             fp, lr, [SP], #0x10
    // 0xc76a34: ret
    //     0xc76a34: ret             
    // 0xc76a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc76a38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc76a3c: b               #0xc7684c
  }
  [closure] MethodChannel <anonymous closure>(dynamic) {
    // ** addr: 0xc76afc, size: 0xb8
    // 0xc76afc: EnterFrame
    //     0xc76afc: stp             fp, lr, [SP, #-0x10]!
    //     0xc76b00: mov             fp, SP
    // 0xc76b04: AllocStack(0x18)
    //     0xc76b04: sub             SP, SP, #0x18
    // 0xc76b08: SetupParameters()
    //     0xc76b08: ldr             x0, [fp, #0x10]
    //     0xc76b0c: ldur            w3, [x0, #0x17]
    //     0xc76b10: add             x3, x3, HEAP, lsl #32
    //     0xc76b14: stur            x3, [fp, #-8]
    // 0xc76b18: CheckStackOverflow
    //     0xc76b18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc76b1c: cmp             SP, x16
    //     0xc76b20: b.ls            #0xc76bac
    // 0xc76b24: r1 = Null
    //     0xc76b24: mov             x1, NULL
    // 0xc76b28: r2 = 4
    //     0xc76b28: mov             x2, #4
    // 0xc76b2c: r0 = AllocateArray()
    //     0xc76b2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc76b30: r17 = "plugins.flutter.io/camera_android/camera"
    //     0xc76b30: add             x17, PP, #0x54, lsl #12  ; [pp+0x541e8] "plugins.flutter.io/camera_android/camera"
    //     0xc76b34: ldr             x17, [x17, #0x1e8]
    // 0xc76b38: StoreField: r0->field_f = r17
    //     0xc76b38: stur            w17, [x0, #0xf]
    // 0xc76b3c: ldur            x2, [fp, #-8]
    // 0xc76b40: LoadField: r1 = r2->field_13
    //     0xc76b40: ldur            w1, [x2, #0x13]
    // 0xc76b44: DecompressPointer r1
    //     0xc76b44: add             x1, x1, HEAP, lsl #32
    // 0xc76b48: StoreField: r0->field_13 = r1
    //     0xc76b48: stur            w1, [x0, #0x13]
    // 0xc76b4c: SaveReg r0
    //     0xc76b4c: str             x0, [SP, #-8]!
    // 0xc76b50: r0 = _interpolate()
    //     0xc76b50: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc76b54: add             SP, SP, #8
    // 0xc76b58: stur            x0, [fp, #-0x10]
    // 0xc76b5c: r0 = MethodChannel()
    //     0xc76b5c: bl              #0x5a2760  ; AllocateMethodChannelStub -> MethodChannel (size=0x14)
    // 0xc76b60: mov             x3, x0
    // 0xc76b64: ldur            x0, [fp, #-0x10]
    // 0xc76b68: stur            x3, [fp, #-0x18]
    // 0xc76b6c: StoreField: r3->field_7 = r0
    //     0xc76b6c: stur            w0, [x3, #7]
    // 0xc76b70: r0 = Instance_StandardMethodCodec
    //     0xc76b70: add             x0, PP, #0x14, lsl #12  ; [pp+0x14cc0] Obj!StandardMethodCodec@b35011
    //     0xc76b74: ldr             x0, [x0, #0xcc0]
    // 0xc76b78: StoreField: r3->field_b = r0
    //     0xc76b78: stur            w0, [x3, #0xb]
    // 0xc76b7c: ldur            x2, [fp, #-8]
    // 0xc76b80: r1 = Function '<anonymous closure>':.
    //     0xc76b80: add             x1, PP, #0x54, lsl #12  ; [pp+0x541f0] AnonymousClosure: (0xc76bb4), in [package:camera_android/src/android_camera.dart] AndroidCamera::initializeCamera (0xc76834)
    //     0xc76b84: ldr             x1, [x1, #0x1f0]
    // 0xc76b88: r0 = AllocateClosure()
    //     0xc76b88: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc76b8c: ldur            x16, [fp, #-0x18]
    // 0xc76b90: stp             x0, x16, [SP, #-0x10]!
    // 0xc76b94: r0 = setMethodCallHandler()
    //     0xc76b94: bl              #0x5a84a0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0xc76b98: add             SP, SP, #0x10
    // 0xc76b9c: ldur            x0, [fp, #-0x18]
    // 0xc76ba0: LeaveFrame
    //     0xc76ba0: mov             SP, fp
    //     0xc76ba4: ldp             fp, lr, [SP], #0x10
    // 0xc76ba8: ret
    //     0xc76ba8: ret             
    // 0xc76bac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc76bac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc76bb0: b               #0xc76b24
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, MethodCall) {
    // ** addr: 0xc76bb4, size: 0x64
    // 0xc76bb4: EnterFrame
    //     0xc76bb4: stp             fp, lr, [SP, #-0x10]!
    //     0xc76bb8: mov             fp, SP
    // 0xc76bbc: ldr             x0, [fp, #0x18]
    // 0xc76bc0: LoadField: r1 = r0->field_17
    //     0xc76bc0: ldur            w1, [x0, #0x17]
    // 0xc76bc4: DecompressPointer r1
    //     0xc76bc4: add             x1, x1, HEAP, lsl #32
    // 0xc76bc8: CheckStackOverflow
    //     0xc76bc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc76bcc: cmp             SP, x16
    //     0xc76bd0: b.ls            #0xc76c10
    // 0xc76bd4: LoadField: r0 = r1->field_f
    //     0xc76bd4: ldur            w0, [x1, #0xf]
    // 0xc76bd8: DecompressPointer r0
    //     0xc76bd8: add             x0, x0, HEAP, lsl #32
    // 0xc76bdc: LoadField: r2 = r1->field_13
    //     0xc76bdc: ldur            w2, [x1, #0x13]
    // 0xc76be0: DecompressPointer r2
    //     0xc76be0: add             x2, x2, HEAP, lsl #32
    // 0xc76be4: r1 = LoadInt32Instr(r2)
    //     0xc76be4: sbfx            x1, x2, #1, #0x1f
    //     0xc76be8: tbz             w2, #0, #0xc76bf0
    //     0xc76bec: ldur            x1, [x2, #7]
    // 0xc76bf0: ldr             x16, [fp, #0x10]
    // 0xc76bf4: stp             x16, x0, [SP, #-0x10]!
    // 0xc76bf8: SaveReg r1
    //     0xc76bf8: str             x1, [SP, #-8]!
    // 0xc76bfc: r0 = handleCameraMethodCall()
    //     0xc76bfc: bl              #0xc76c18  ; [package:camera_android/src/android_camera.dart] AndroidCamera::handleCameraMethodCall
    // 0xc76c00: add             SP, SP, #0x18
    // 0xc76c04: LeaveFrame
    //     0xc76c04: mov             SP, fp
    //     0xc76c08: ldp             fp, lr, [SP], #0x10
    // 0xc76c0c: ret
    //     0xc76c0c: ret             
    // 0xc76c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc76c10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc76c14: b               #0xc76bd4
  }
  _ handleCameraMethodCall(/* No info */) async {
    // ** addr: 0xc76c18, size: 0x90c
    // 0xc76c18: EnterFrame
    //     0xc76c18: stp             fp, lr, [SP, #-0x10]!
    //     0xc76c1c: mov             fp, SP
    // 0xc76c20: AllocStack(0x70)
    //     0xc76c20: sub             SP, SP, #0x70
    // 0xc76c24: SetupParameters(AndroidCamera this /* r1, fp-0x20 */, dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0xc76c24: stur            NULL, [fp, #-8]
    //     0xc76c28: mov             x0, #0
    //     0xc76c2c: add             x1, fp, w0, sxtw #2
    //     0xc76c30: ldr             x1, [x1, #0x20]
    //     0xc76c34: stur            x1, [fp, #-0x20]
    //     0xc76c38: add             x2, fp, w0, sxtw #2
    //     0xc76c3c: ldr             x2, [x2, #0x18]
    //     0xc76c40: stur            x2, [fp, #-0x18]
    //     0xc76c44: add             x3, fp, w0, sxtw #2
    //     0xc76c48: ldr             x3, [x3, #0x10]
    //     0xc76c4c: stur            x3, [fp, #-0x10]
    // 0xc76c50: CheckStackOverflow
    //     0xc76c50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc76c54: cmp             SP, x16
    //     0xc76c58: b.ls            #0xc774f0
    // 0xc76c5c: InitAsync() -> Future
    //     0xc76c5c: mov             x0, NULL
    //     0xc76c60: bl              #0x4b92e4
    // 0xc76c64: ldur            x0, [fp, #-0x18]
    // 0xc76c68: LoadField: r1 = r0->field_7
    //     0xc76c68: ldur            w1, [x0, #7]
    // 0xc76c6c: DecompressPointer r1
    //     0xc76c6c: add             x1, x1, HEAP, lsl #32
    // 0xc76c70: stur            x1, [fp, #-0x28]
    // 0xc76c74: r16 = "initialized"
    //     0xc76c74: add             x16, PP, #0x49, lsl #12  ; [pp+0x49548] "initialized"
    //     0xc76c78: ldr             x16, [x16, #0x548]
    // 0xc76c7c: stp             x1, x16, [SP, #-0x10]!
    // 0xc76c80: r0 = ==()
    //     0xc76c80: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc76c84: add             SP, SP, #0x10
    // 0xc76c88: tbnz            w0, #4, #0xc76fdc
    // 0xc76c8c: ldur            x0, [fp, #-0x20]
    // 0xc76c90: ldur            x1, [fp, #-0x10]
    // 0xc76c94: ldur            x16, [fp, #-0x18]
    // 0xc76c98: stp             x16, x0, [SP, #-0x10]!
    // 0xc76c9c: r0 = _getArgumentDictionary()
    //     0xc76c9c: bl              #0x5ababc  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_getArgumentDictionary
    // 0xc76ca0: add             SP, SP, #0x10
    // 0xc76ca4: mov             x1, x0
    // 0xc76ca8: ldur            x0, [fp, #-0x20]
    // 0xc76cac: stur            x1, [fp, #-0x38]
    // 0xc76cb0: LoadField: r2 = r0->field_b
    //     0xc76cb0: ldur            w2, [x0, #0xb]
    // 0xc76cb4: DecompressPointer r2
    //     0xc76cb4: add             x2, x2, HEAP, lsl #32
    // 0xc76cb8: stur            x2, [fp, #-0x30]
    // 0xc76cbc: r0 = LoadClassIdInstr(r1)
    //     0xc76cbc: ldur            x0, [x1, #-1]
    //     0xc76cc0: ubfx            x0, x0, #0xc, #0x14
    // 0xc76cc4: r16 = "previewWidth"
    //     0xc76cc4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53cd8] "previewWidth"
    //     0xc76cc8: ldr             x16, [x16, #0xcd8]
    // 0xc76ccc: stp             x16, x1, [SP, #-0x10]!
    // 0xc76cd0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc76cd0: sub             lr, x0, #0xef
    //     0xc76cd4: ldr             lr, [x21, lr, lsl #3]
    //     0xc76cd8: blr             lr
    // 0xc76cdc: add             SP, SP, #0x10
    // 0xc76ce0: mov             x3, x0
    // 0xc76ce4: stur            x3, [fp, #-0x40]
    // 0xc76ce8: cmp             w3, NULL
    // 0xc76cec: b.eq            #0xc774f8
    // 0xc76cf0: mov             x0, x3
    // 0xc76cf4: r2 = Null
    //     0xc76cf4: mov             x2, NULL
    // 0xc76cf8: r1 = Null
    //     0xc76cf8: mov             x1, NULL
    // 0xc76cfc: r4 = 59
    //     0xc76cfc: mov             x4, #0x3b
    // 0xc76d00: branchIfSmi(r0, 0xc76d0c)
    //     0xc76d00: tbz             w0, #0, #0xc76d0c
    // 0xc76d04: r4 = LoadClassIdInstr(r0)
    //     0xc76d04: ldur            x4, [x0, #-1]
    //     0xc76d08: ubfx            x4, x4, #0xc, #0x14
    // 0xc76d0c: cmp             x4, #0x3d
    // 0xc76d10: b.eq            #0xc76d24
    // 0xc76d14: r8 = double
    //     0xc76d14: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc76d18: r3 = Null
    //     0xc76d18: add             x3, PP, #0x54, lsl #12  ; [pp+0x541f8] Null
    //     0xc76d1c: ldr             x3, [x3, #0x1f8]
    // 0xc76d20: r0 = double()
    //     0xc76d20: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc76d24: ldur            x1, [fp, #-0x38]
    // 0xc76d28: r0 = LoadClassIdInstr(r1)
    //     0xc76d28: ldur            x0, [x1, #-1]
    //     0xc76d2c: ubfx            x0, x0, #0xc, #0x14
    // 0xc76d30: r16 = "previewHeight"
    //     0xc76d30: add             x16, PP, #0x53, lsl #12  ; [pp+0x53cf0] "previewHeight"
    //     0xc76d34: ldr             x16, [x16, #0xcf0]
    // 0xc76d38: stp             x16, x1, [SP, #-0x10]!
    // 0xc76d3c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc76d3c: sub             lr, x0, #0xef
    //     0xc76d40: ldr             lr, [x21, lr, lsl #3]
    //     0xc76d44: blr             lr
    // 0xc76d48: add             SP, SP, #0x10
    // 0xc76d4c: mov             x3, x0
    // 0xc76d50: stur            x3, [fp, #-0x48]
    // 0xc76d54: cmp             w3, NULL
    // 0xc76d58: b.eq            #0xc774fc
    // 0xc76d5c: mov             x0, x3
    // 0xc76d60: r2 = Null
    //     0xc76d60: mov             x2, NULL
    // 0xc76d64: r1 = Null
    //     0xc76d64: mov             x1, NULL
    // 0xc76d68: r4 = 59
    //     0xc76d68: mov             x4, #0x3b
    // 0xc76d6c: branchIfSmi(r0, 0xc76d78)
    //     0xc76d6c: tbz             w0, #0, #0xc76d78
    // 0xc76d70: r4 = LoadClassIdInstr(r0)
    //     0xc76d70: ldur            x4, [x0, #-1]
    //     0xc76d74: ubfx            x4, x4, #0xc, #0x14
    // 0xc76d78: cmp             x4, #0x3d
    // 0xc76d7c: b.eq            #0xc76d90
    // 0xc76d80: r8 = double
    //     0xc76d80: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc76d84: r3 = Null
    //     0xc76d84: add             x3, PP, #0x54, lsl #12  ; [pp+0x54208] Null
    //     0xc76d88: ldr             x3, [x3, #0x208]
    // 0xc76d8c: r0 = double()
    //     0xc76d8c: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc76d90: ldur            x1, [fp, #-0x38]
    // 0xc76d94: r0 = LoadClassIdInstr(r1)
    //     0xc76d94: ldur            x0, [x1, #-1]
    //     0xc76d98: ubfx            x0, x0, #0xc, #0x14
    // 0xc76d9c: r16 = "exposureMode"
    //     0xc76d9c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d478] "exposureMode"
    //     0xc76da0: ldr             x16, [x16, #0x478]
    // 0xc76da4: stp             x16, x1, [SP, #-0x10]!
    // 0xc76da8: r0 = GDT[cid_x0 + -0xef]()
    //     0xc76da8: sub             lr, x0, #0xef
    //     0xc76dac: ldr             lr, [x21, lr, lsl #3]
    //     0xc76db0: blr             lr
    // 0xc76db4: add             SP, SP, #0x10
    // 0xc76db8: mov             x3, x0
    // 0xc76dbc: stur            x3, [fp, #-0x50]
    // 0xc76dc0: cmp             w3, NULL
    // 0xc76dc4: b.eq            #0xc77500
    // 0xc76dc8: mov             x0, x3
    // 0xc76dcc: r2 = Null
    //     0xc76dcc: mov             x2, NULL
    // 0xc76dd0: r1 = Null
    //     0xc76dd0: mov             x1, NULL
    // 0xc76dd4: r4 = 59
    //     0xc76dd4: mov             x4, #0x3b
    // 0xc76dd8: branchIfSmi(r0, 0xc76de4)
    //     0xc76dd8: tbz             w0, #0, #0xc76de4
    // 0xc76ddc: r4 = LoadClassIdInstr(r0)
    //     0xc76ddc: ldur            x4, [x0, #-1]
    //     0xc76de0: ubfx            x4, x4, #0xc, #0x14
    // 0xc76de4: sub             x4, x4, #0x5d
    // 0xc76de8: cmp             x4, #3
    // 0xc76dec: b.ls            #0xc76e00
    // 0xc76df0: r8 = String
    //     0xc76df0: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc76df4: r3 = Null
    //     0xc76df4: add             x3, PP, #0x54, lsl #12  ; [pp+0x54218] Null
    //     0xc76df8: ldr             x3, [x3, #0x218]
    // 0xc76dfc: r0 = String()
    //     0xc76dfc: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc76e00: ldur            x16, [fp, #-0x50]
    // 0xc76e04: SaveReg r16
    //     0xc76e04: str             x16, [SP, #-8]!
    // 0xc76e08: r0 = deserializeExposureMode()
    //     0xc76e08: bl              #0xc77640  ; [package:camera_platform_interface/src/types/exposure_mode.dart] ::deserializeExposureMode
    // 0xc76e0c: add             SP, SP, #8
    // 0xc76e10: mov             x2, x0
    // 0xc76e14: ldur            x1, [fp, #-0x38]
    // 0xc76e18: stur            x2, [fp, #-0x50]
    // 0xc76e1c: r0 = LoadClassIdInstr(r1)
    //     0xc76e1c: ldur            x0, [x1, #-1]
    //     0xc76e20: ubfx            x0, x0, #0xc, #0x14
    // 0xc76e24: r16 = "exposurePointSupported"
    //     0xc76e24: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d480] "exposurePointSupported"
    //     0xc76e28: ldr             x16, [x16, #0x480]
    // 0xc76e2c: stp             x16, x1, [SP, #-0x10]!
    // 0xc76e30: r0 = GDT[cid_x0 + -0xef]()
    //     0xc76e30: sub             lr, x0, #0xef
    //     0xc76e34: ldr             lr, [x21, lr, lsl #3]
    //     0xc76e38: blr             lr
    // 0xc76e3c: add             SP, SP, #0x10
    // 0xc76e40: mov             x3, x0
    // 0xc76e44: stur            x3, [fp, #-0x58]
    // 0xc76e48: cmp             w3, NULL
    // 0xc76e4c: b.eq            #0xc77504
    // 0xc76e50: mov             x0, x3
    // 0xc76e54: r2 = Null
    //     0xc76e54: mov             x2, NULL
    // 0xc76e58: r1 = Null
    //     0xc76e58: mov             x1, NULL
    // 0xc76e5c: r4 = 59
    //     0xc76e5c: mov             x4, #0x3b
    // 0xc76e60: branchIfSmi(r0, 0xc76e6c)
    //     0xc76e60: tbz             w0, #0, #0xc76e6c
    // 0xc76e64: r4 = LoadClassIdInstr(r0)
    //     0xc76e64: ldur            x4, [x0, #-1]
    //     0xc76e68: ubfx            x4, x4, #0xc, #0x14
    // 0xc76e6c: cmp             x4, #0x3e
    // 0xc76e70: b.eq            #0xc76e84
    // 0xc76e74: r8 = bool
    //     0xc76e74: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0xc76e78: r3 = Null
    //     0xc76e78: add             x3, PP, #0x54, lsl #12  ; [pp+0x54228] Null
    //     0xc76e7c: ldr             x3, [x3, #0x228]
    // 0xc76e80: r0 = bool()
    //     0xc76e80: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0xc76e84: ldur            x1, [fp, #-0x38]
    // 0xc76e88: r0 = LoadClassIdInstr(r1)
    //     0xc76e88: ldur            x0, [x1, #-1]
    //     0xc76e8c: ubfx            x0, x0, #0xc, #0x14
    // 0xc76e90: r16 = "focusMode"
    //     0xc76e90: add             x16, PP, #0x45, lsl #12  ; [pp+0x45988] "focusMode"
    //     0xc76e94: ldr             x16, [x16, #0x988]
    // 0xc76e98: stp             x16, x1, [SP, #-0x10]!
    // 0xc76e9c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc76e9c: sub             lr, x0, #0xef
    //     0xc76ea0: ldr             lr, [x21, lr, lsl #3]
    //     0xc76ea4: blr             lr
    // 0xc76ea8: add             SP, SP, #0x10
    // 0xc76eac: mov             x3, x0
    // 0xc76eb0: stur            x3, [fp, #-0x60]
    // 0xc76eb4: cmp             w3, NULL
    // 0xc76eb8: b.eq            #0xc77508
    // 0xc76ebc: mov             x0, x3
    // 0xc76ec0: r2 = Null
    //     0xc76ec0: mov             x2, NULL
    // 0xc76ec4: r1 = Null
    //     0xc76ec4: mov             x1, NULL
    // 0xc76ec8: r4 = 59
    //     0xc76ec8: mov             x4, #0x3b
    // 0xc76ecc: branchIfSmi(r0, 0xc76ed8)
    //     0xc76ecc: tbz             w0, #0, #0xc76ed8
    // 0xc76ed0: r4 = LoadClassIdInstr(r0)
    //     0xc76ed0: ldur            x4, [x0, #-1]
    //     0xc76ed4: ubfx            x4, x4, #0xc, #0x14
    // 0xc76ed8: sub             x4, x4, #0x5d
    // 0xc76edc: cmp             x4, #3
    // 0xc76ee0: b.ls            #0xc76ef4
    // 0xc76ee4: r8 = String
    //     0xc76ee4: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc76ee8: r3 = Null
    //     0xc76ee8: add             x3, PP, #0x54, lsl #12  ; [pp+0x54238] Null
    //     0xc76eec: ldr             x3, [x3, #0x238]
    // 0xc76ef0: r0 = String()
    //     0xc76ef0: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc76ef4: ldur            x16, [fp, #-0x60]
    // 0xc76ef8: SaveReg r16
    //     0xc76ef8: str             x16, [SP, #-8]!
    // 0xc76efc: r0 = deserializeFocusMode()
    //     0xc76efc: bl              #0xc77560  ; [package:camera_platform_interface/src/types/focus_mode.dart] ::deserializeFocusMode
    // 0xc76f00: add             SP, SP, #8
    // 0xc76f04: mov             x1, x0
    // 0xc76f08: ldur            x0, [fp, #-0x38]
    // 0xc76f0c: stur            x1, [fp, #-0x60]
    // 0xc76f10: r2 = LoadClassIdInstr(r0)
    //     0xc76f10: ldur            x2, [x0, #-1]
    //     0xc76f14: ubfx            x2, x2, #0xc, #0x14
    // 0xc76f18: r16 = "focusPointSupported"
    //     0xc76f18: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d490] "focusPointSupported"
    //     0xc76f1c: ldr             x16, [x16, #0x490]
    // 0xc76f20: stp             x16, x0, [SP, #-0x10]!
    // 0xc76f24: mov             x0, x2
    // 0xc76f28: r0 = GDT[cid_x0 + -0xef]()
    //     0xc76f28: sub             lr, x0, #0xef
    //     0xc76f2c: ldr             lr, [x21, lr, lsl #3]
    //     0xc76f30: blr             lr
    // 0xc76f34: add             SP, SP, #0x10
    // 0xc76f38: mov             x3, x0
    // 0xc76f3c: stur            x3, [fp, #-0x38]
    // 0xc76f40: cmp             w3, NULL
    // 0xc76f44: b.eq            #0xc7750c
    // 0xc76f48: mov             x0, x3
    // 0xc76f4c: r2 = Null
    //     0xc76f4c: mov             x2, NULL
    // 0xc76f50: r1 = Null
    //     0xc76f50: mov             x1, NULL
    // 0xc76f54: r4 = 59
    //     0xc76f54: mov             x4, #0x3b
    // 0xc76f58: branchIfSmi(r0, 0xc76f64)
    //     0xc76f58: tbz             w0, #0, #0xc76f64
    // 0xc76f5c: r4 = LoadClassIdInstr(r0)
    //     0xc76f5c: ldur            x4, [x0, #-1]
    //     0xc76f60: ubfx            x4, x4, #0xc, #0x14
    // 0xc76f64: cmp             x4, #0x3e
    // 0xc76f68: b.eq            #0xc76f7c
    // 0xc76f6c: r8 = bool
    //     0xc76f6c: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0xc76f70: r3 = Null
    //     0xc76f70: add             x3, PP, #0x54, lsl #12  ; [pp+0x54248] Null
    //     0xc76f74: ldr             x3, [x3, #0x248]
    // 0xc76f78: r0 = bool()
    //     0xc76f78: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0xc76f7c: ldur            x0, [fp, #-0x40]
    // 0xc76f80: LoadField: d0 = r0->field_7
    //     0xc76f80: ldur            d0, [x0, #7]
    // 0xc76f84: stur            d0, [fp, #-0x70]
    // 0xc76f88: r0 = CameraInitializedEvent()
    //     0xc76f88: bl              #0xc77554  ; AllocateCameraInitializedEventStub -> CameraInitializedEvent (size=0x30)
    // 0xc76f8c: ldur            d0, [fp, #-0x70]
    // 0xc76f90: StoreField: r0->field_f = d0
    //     0xc76f90: stur            d0, [x0, #0xf]
    // 0xc76f94: ldur            x1, [fp, #-0x48]
    // 0xc76f98: LoadField: d0 = r1->field_7
    //     0xc76f98: ldur            d0, [x1, #7]
    // 0xc76f9c: StoreField: r0->field_17 = d0
    //     0xc76f9c: stur            d0, [x0, #0x17]
    // 0xc76fa0: ldur            x1, [fp, #-0x50]
    // 0xc76fa4: StoreField: r0->field_1f = r1
    //     0xc76fa4: stur            w1, [x0, #0x1f]
    // 0xc76fa8: ldur            x1, [fp, #-0x58]
    // 0xc76fac: StoreField: r0->field_27 = r1
    //     0xc76fac: stur            w1, [x0, #0x27]
    // 0xc76fb0: ldur            x1, [fp, #-0x60]
    // 0xc76fb4: StoreField: r0->field_23 = r1
    //     0xc76fb4: stur            w1, [x0, #0x23]
    // 0xc76fb8: ldur            x1, [fp, #-0x38]
    // 0xc76fbc: StoreField: r0->field_2b = r1
    //     0xc76fbc: stur            w1, [x0, #0x2b]
    // 0xc76fc0: ldur            x1, [fp, #-0x10]
    // 0xc76fc4: StoreField: r0->field_7 = r1
    //     0xc76fc4: stur            x1, [x0, #7]
    // 0xc76fc8: ldur            x16, [fp, #-0x30]
    // 0xc76fcc: stp             x0, x16, [SP, #-0x10]!
    // 0xc76fd0: r0 = add()
    //     0xc76fd0: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc76fd4: add             SP, SP, #0x10
    // 0xc76fd8: b               #0xc774dc
    // 0xc76fdc: ldur            x0, [fp, #-0x20]
    // 0xc76fe0: ldur            x1, [fp, #-0x10]
    // 0xc76fe4: r16 = "resolution_changed"
    //     0xc76fe4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d48] "resolution_changed"
    //     0xc76fe8: ldr             x16, [x16, #0xd48]
    // 0xc76fec: ldur            lr, [fp, #-0x28]
    // 0xc76ff0: stp             lr, x16, [SP, #-0x10]!
    // 0xc76ff4: r0 = ==()
    //     0xc76ff4: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc76ff8: add             SP, SP, #0x10
    // 0xc76ffc: tbnz            w0, #4, #0xc77148
    // 0xc77000: ldur            x0, [fp, #-0x20]
    // 0xc77004: ldur            x1, [fp, #-0x10]
    // 0xc77008: ldur            x16, [fp, #-0x18]
    // 0xc7700c: stp             x16, x0, [SP, #-0x10]!
    // 0xc77010: r0 = _getArgumentDictionary()
    //     0xc77010: bl              #0x5ababc  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_getArgumentDictionary
    // 0xc77014: add             SP, SP, #0x10
    // 0xc77018: mov             x1, x0
    // 0xc7701c: ldur            x0, [fp, #-0x20]
    // 0xc77020: stur            x1, [fp, #-0x38]
    // 0xc77024: LoadField: r2 = r0->field_b
    //     0xc77024: ldur            w2, [x0, #0xb]
    // 0xc77028: DecompressPointer r2
    //     0xc77028: add             x2, x2, HEAP, lsl #32
    // 0xc7702c: stur            x2, [fp, #-0x30]
    // 0xc77030: r0 = LoadClassIdInstr(r1)
    //     0xc77030: ldur            x0, [x1, #-1]
    //     0xc77034: ubfx            x0, x0, #0xc, #0x14
    // 0xc77038: r16 = "captureWidth"
    //     0xc77038: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d50] "captureWidth"
    //     0xc7703c: ldr             x16, [x16, #0xd50]
    // 0xc77040: stp             x16, x1, [SP, #-0x10]!
    // 0xc77044: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77044: sub             lr, x0, #0xef
    //     0xc77048: ldr             lr, [x21, lr, lsl #3]
    //     0xc7704c: blr             lr
    // 0xc77050: add             SP, SP, #0x10
    // 0xc77054: mov             x3, x0
    // 0xc77058: stur            x3, [fp, #-0x40]
    // 0xc7705c: cmp             w3, NULL
    // 0xc77060: b.eq            #0xc77510
    // 0xc77064: mov             x0, x3
    // 0xc77068: r2 = Null
    //     0xc77068: mov             x2, NULL
    // 0xc7706c: r1 = Null
    //     0xc7706c: mov             x1, NULL
    // 0xc77070: r4 = 59
    //     0xc77070: mov             x4, #0x3b
    // 0xc77074: branchIfSmi(r0, 0xc77080)
    //     0xc77074: tbz             w0, #0, #0xc77080
    // 0xc77078: r4 = LoadClassIdInstr(r0)
    //     0xc77078: ldur            x4, [x0, #-1]
    //     0xc7707c: ubfx            x4, x4, #0xc, #0x14
    // 0xc77080: cmp             x4, #0x3d
    // 0xc77084: b.eq            #0xc77098
    // 0xc77088: r8 = double
    //     0xc77088: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc7708c: r3 = Null
    //     0xc7708c: add             x3, PP, #0x54, lsl #12  ; [pp+0x54258] Null
    //     0xc77090: ldr             x3, [x3, #0x258]
    // 0xc77094: r0 = double()
    //     0xc77094: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc77098: ldur            x0, [fp, #-0x38]
    // 0xc7709c: r1 = LoadClassIdInstr(r0)
    //     0xc7709c: ldur            x1, [x0, #-1]
    //     0xc770a0: ubfx            x1, x1, #0xc, #0x14
    // 0xc770a4: r16 = "captureHeight"
    //     0xc770a4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d68] "captureHeight"
    //     0xc770a8: ldr             x16, [x16, #0xd68]
    // 0xc770ac: stp             x16, x0, [SP, #-0x10]!
    // 0xc770b0: mov             x0, x1
    // 0xc770b4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc770b4: sub             lr, x0, #0xef
    //     0xc770b8: ldr             lr, [x21, lr, lsl #3]
    //     0xc770bc: blr             lr
    // 0xc770c0: add             SP, SP, #0x10
    // 0xc770c4: mov             x3, x0
    // 0xc770c8: stur            x3, [fp, #-0x38]
    // 0xc770cc: cmp             w3, NULL
    // 0xc770d0: b.eq            #0xc77514
    // 0xc770d4: mov             x0, x3
    // 0xc770d8: r2 = Null
    //     0xc770d8: mov             x2, NULL
    // 0xc770dc: r1 = Null
    //     0xc770dc: mov             x1, NULL
    // 0xc770e0: r4 = 59
    //     0xc770e0: mov             x4, #0x3b
    // 0xc770e4: branchIfSmi(r0, 0xc770f0)
    //     0xc770e4: tbz             w0, #0, #0xc770f0
    // 0xc770e8: r4 = LoadClassIdInstr(r0)
    //     0xc770e8: ldur            x4, [x0, #-1]
    //     0xc770ec: ubfx            x4, x4, #0xc, #0x14
    // 0xc770f0: cmp             x4, #0x3d
    // 0xc770f4: b.eq            #0xc77108
    // 0xc770f8: r8 = double
    //     0xc770f8: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc770fc: r3 = Null
    //     0xc770fc: add             x3, PP, #0x54, lsl #12  ; [pp+0x54268] Null
    //     0xc77100: ldr             x3, [x3, #0x268]
    // 0xc77104: r0 = double()
    //     0xc77104: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc77108: ldur            x0, [fp, #-0x40]
    // 0xc7710c: LoadField: d0 = r0->field_7
    //     0xc7710c: ldur            d0, [x0, #7]
    // 0xc77110: stur            d0, [fp, #-0x70]
    // 0xc77114: r0 = CameraResolutionChangedEvent()
    //     0xc77114: bl              #0xc77548  ; AllocateCameraResolutionChangedEventStub -> CameraResolutionChangedEvent (size=0x20)
    // 0xc77118: ldur            d0, [fp, #-0x70]
    // 0xc7711c: StoreField: r0->field_f = d0
    //     0xc7711c: stur            d0, [x0, #0xf]
    // 0xc77120: ldur            x1, [fp, #-0x38]
    // 0xc77124: LoadField: d0 = r1->field_7
    //     0xc77124: ldur            d0, [x1, #7]
    // 0xc77128: StoreField: r0->field_17 = d0
    //     0xc77128: stur            d0, [x0, #0x17]
    // 0xc7712c: ldur            x1, [fp, #-0x10]
    // 0xc77130: StoreField: r0->field_7 = r1
    //     0xc77130: stur            x1, [x0, #7]
    // 0xc77134: ldur            x16, [fp, #-0x30]
    // 0xc77138: stp             x0, x16, [SP, #-0x10]!
    // 0xc7713c: r0 = add()
    //     0xc7713c: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc77140: add             SP, SP, #0x10
    // 0xc77144: b               #0xc774dc
    // 0xc77148: ldur            x0, [fp, #-0x20]
    // 0xc7714c: ldur            x1, [fp, #-0x10]
    // 0xc77150: r16 = "camera_closing"
    //     0xc77150: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d80] "camera_closing"
    //     0xc77154: ldr             x16, [x16, #0xd80]
    // 0xc77158: ldur            lr, [fp, #-0x28]
    // 0xc7715c: stp             lr, x16, [SP, #-0x10]!
    // 0xc77160: r0 = ==()
    //     0xc77160: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc77164: add             SP, SP, #0x10
    // 0xc77168: tbnz            w0, #4, #0xc771a0
    // 0xc7716c: ldur            x0, [fp, #-0x20]
    // 0xc77170: ldur            x1, [fp, #-0x10]
    // 0xc77174: LoadField: r2 = r0->field_b
    //     0xc77174: ldur            w2, [x0, #0xb]
    // 0xc77178: DecompressPointer r2
    //     0xc77178: add             x2, x2, HEAP, lsl #32
    // 0xc7717c: stur            x2, [fp, #-0x30]
    // 0xc77180: r0 = CameraClosingEvent()
    //     0xc77180: bl              #0xc7753c  ; AllocateCameraClosingEventStub -> CameraClosingEvent (size=0x10)
    // 0xc77184: ldur            x1, [fp, #-0x10]
    // 0xc77188: StoreField: r0->field_7 = r1
    //     0xc77188: stur            x1, [x0, #7]
    // 0xc7718c: ldur            x16, [fp, #-0x30]
    // 0xc77190: stp             x0, x16, [SP, #-0x10]!
    // 0xc77194: r0 = add()
    //     0xc77194: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc77198: add             SP, SP, #0x10
    // 0xc7719c: b               #0xc774dc
    // 0xc771a0: ldur            x0, [fp, #-0x20]
    // 0xc771a4: ldur            x1, [fp, #-0x10]
    // 0xc771a8: r16 = "video_recorded"
    //     0xc771a8: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d88] "video_recorded"
    //     0xc771ac: ldr             x16, [x16, #0xd88]
    // 0xc771b0: ldur            lr, [fp, #-0x28]
    // 0xc771b4: stp             lr, x16, [SP, #-0x10]!
    // 0xc771b8: r0 = ==()
    //     0xc771b8: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc771bc: add             SP, SP, #0x10
    // 0xc771c0: tbnz            w0, #4, #0xc773fc
    // 0xc771c4: ldur            x0, [fp, #-0x20]
    // 0xc771c8: ldur            x16, [fp, #-0x18]
    // 0xc771cc: stp             x16, x0, [SP, #-0x10]!
    // 0xc771d0: r0 = _getArgumentDictionary()
    //     0xc771d0: bl              #0x5ababc  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_getArgumentDictionary
    // 0xc771d4: add             SP, SP, #0x10
    // 0xc771d8: mov             x1, x0
    // 0xc771dc: ldur            x0, [fp, #-0x20]
    // 0xc771e0: stur            x1, [fp, #-0x38]
    // 0xc771e4: LoadField: r2 = r0->field_b
    //     0xc771e4: ldur            w2, [x0, #0xb]
    // 0xc771e8: DecompressPointer r2
    //     0xc771e8: add             x2, x2, HEAP, lsl #32
    // 0xc771ec: stur            x2, [fp, #-0x30]
    // 0xc771f0: r0 = LoadClassIdInstr(r1)
    //     0xc771f0: ldur            x0, [x1, #-1]
    //     0xc771f4: ubfx            x0, x0, #0xc, #0x14
    // 0xc771f8: r16 = "path"
    //     0xc771f8: ldr             x16, [PP, #0x518]  ; [pp+0x518] "path"
    // 0xc771fc: stp             x16, x1, [SP, #-0x10]!
    // 0xc77200: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77200: sub             lr, x0, #0xef
    //     0xc77204: ldr             lr, [x21, lr, lsl #3]
    //     0xc77208: blr             lr
    // 0xc7720c: add             SP, SP, #0x10
    // 0xc77210: mov             x3, x0
    // 0xc77214: stur            x3, [fp, #-0x40]
    // 0xc77218: cmp             w3, NULL
    // 0xc7721c: b.eq            #0xc77518
    // 0xc77220: mov             x0, x3
    // 0xc77224: r2 = Null
    //     0xc77224: mov             x2, NULL
    // 0xc77228: r1 = Null
    //     0xc77228: mov             x1, NULL
    // 0xc7722c: r4 = 59
    //     0xc7722c: mov             x4, #0x3b
    // 0xc77230: branchIfSmi(r0, 0xc7723c)
    //     0xc77230: tbz             w0, #0, #0xc7723c
    // 0xc77234: r4 = LoadClassIdInstr(r0)
    //     0xc77234: ldur            x4, [x0, #-1]
    //     0xc77238: ubfx            x4, x4, #0xc, #0x14
    // 0xc7723c: sub             x4, x4, #0x5d
    // 0xc77240: cmp             x4, #3
    // 0xc77244: b.ls            #0xc77258
    // 0xc77248: r8 = String
    //     0xc77248: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc7724c: r3 = Null
    //     0xc7724c: add             x3, PP, #0x54, lsl #12  ; [pp+0x54278] Null
    //     0xc77250: ldr             x3, [x3, #0x278]
    // 0xc77254: r0 = String()
    //     0xc77254: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc77258: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc77258: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc7725c: ldr             x0, [x0, #0xb58]
    //     0xc77260: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc77264: cmp             w0, w16
    //     0xc77268: b.ne            #0xc77274
    //     0xc7726c: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc77270: bl              #0xd67d44
    // 0xc77274: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc77274: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc77278: ldr             x0, [x0, #0xdd8]
    //     0xc7727c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc77280: cmp             w0, w16
    //     0xc77284: b.ne            #0xc77290
    //     0xc77288: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc7728c: bl              #0xd67cdc
    // 0xc77290: r0 = _File()
    //     0xc77290: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xc77294: mov             x1, x0
    // 0xc77298: ldur            x0, [fp, #-0x40]
    // 0xc7729c: stur            x1, [fp, #-0x48]
    // 0xc772a0: StoreField: r1->field_7 = r0
    //     0xc772a0: stur            w0, [x1, #7]
    // 0xc772a4: SaveReg r0
    //     0xc772a4: str             x0, [SP, #-8]!
    // 0xc772a8: r0 = _toUtf8Array()
    //     0xc772a8: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc772ac: add             SP, SP, #8
    // 0xc772b0: ldur            x1, [fp, #-0x48]
    // 0xc772b4: StoreField: r1->field_b = r0
    //     0xc772b4: stur            w0, [x1, #0xb]
    //     0xc772b8: ldurb           w16, [x1, #-1]
    //     0xc772bc: ldurb           w17, [x0, #-1]
    //     0xc772c0: and             x16, x17, x16, lsr #2
    //     0xc772c4: tst             x16, HEAP, lsr #32
    //     0xc772c8: b.eq            #0xc772d0
    //     0xc772cc: bl              #0xd6826c
    // 0xc772d0: r0 = XFile()
    //     0xc772d0: bl              #0xc6a500  ; AllocateXFileStub -> XFile (size=0x10)
    // 0xc772d4: mov             x1, x0
    // 0xc772d8: ldur            x0, [fp, #-0x48]
    // 0xc772dc: stur            x1, [fp, #-0x40]
    // 0xc772e0: StoreField: r1->field_7 = r0
    //     0xc772e0: stur            w0, [x1, #7]
    // 0xc772e4: ldur            x2, [fp, #-0x38]
    // 0xc772e8: r0 = LoadClassIdInstr(r2)
    //     0xc772e8: ldur            x0, [x2, #-1]
    //     0xc772ec: ubfx            x0, x0, #0xc, #0x14
    // 0xc772f0: r16 = "maxVideoDuration"
    //     0xc772f0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b10] "maxVideoDuration"
    //     0xc772f4: ldr             x16, [x16, #0xb10]
    // 0xc772f8: stp             x16, x2, [SP, #-0x10]!
    // 0xc772fc: r0 = GDT[cid_x0 + -0xef]()
    //     0xc772fc: sub             lr, x0, #0xef
    //     0xc77300: ldr             lr, [x21, lr, lsl #3]
    //     0xc77304: blr             lr
    // 0xc77308: add             SP, SP, #0x10
    // 0xc7730c: cmp             w0, NULL
    // 0xc77310: b.eq            #0xc773b8
    // 0xc77314: ldur            x0, [fp, #-0x38]
    // 0xc77318: r1 = LoadClassIdInstr(r0)
    //     0xc77318: ldur            x1, [x0, #-1]
    //     0xc7731c: ubfx            x1, x1, #0xc, #0x14
    // 0xc77320: r16 = "maxVideoDuration"
    //     0xc77320: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b10] "maxVideoDuration"
    //     0xc77324: ldr             x16, [x16, #0xb10]
    // 0xc77328: stp             x16, x0, [SP, #-0x10]!
    // 0xc7732c: mov             x0, x1
    // 0xc77330: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77330: sub             lr, x0, #0xef
    //     0xc77334: ldr             lr, [x21, lr, lsl #3]
    //     0xc77338: blr             lr
    // 0xc7733c: add             SP, SP, #0x10
    // 0xc77340: mov             x3, x0
    // 0xc77344: stur            x3, [fp, #-0x38]
    // 0xc77348: cmp             w3, NULL
    // 0xc7734c: b.eq            #0xc7751c
    // 0xc77350: r3 as int
    //     0xc77350: mov             x0, x3
    //     0xc77354: mov             x2, NULL
    //     0xc77358: mov             x1, NULL
    //     0xc7735c: tbz             w0, #0, #0xc77384
    //     0xc77360: ldur            x4, [x0, #-1]
    //     0xc77364: ubfx            x4, x4, #0xc, #0x14
    //     0xc77368: sub             x4, x4, #0x3b
    //     0xc7736c: cmp             x4, #1
    //     0xc77370: b.ls            #0xc77384
    //     0xc77374: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xc77378: add             x3, PP, #0x54, lsl #12  ; [pp+0x54288] Null
    //     0xc7737c: ldr             x3, [x3, #0x288]
    //     0xc77380: bl              #0xd73714
    // 0xc77384: ldur            x0, [fp, #-0x38]
    // 0xc77388: r1 = LoadInt32Instr(r0)
    //     0xc77388: sbfx            x1, x0, #1, #0x1f
    //     0xc7738c: tbz             w0, #0, #0xc77394
    //     0xc77390: ldur            x1, [x0, #7]
    // 0xc77394: r16 = 1000
    //     0xc77394: mov             x16, #0x3e8
    // 0xc77398: mul             x0, x1, x16
    // 0xc7739c: stur            x0, [fp, #-0x68]
    // 0xc773a0: r0 = Duration()
    //     0xc773a0: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xc773a4: mov             x1, x0
    // 0xc773a8: ldur            x0, [fp, #-0x68]
    // 0xc773ac: StoreField: r1->field_7 = r0
    //     0xc773ac: stur            x0, [x1, #7]
    // 0xc773b0: mov             x2, x1
    // 0xc773b4: b               #0xc773bc
    // 0xc773b8: r2 = Null
    //     0xc773b8: mov             x2, NULL
    // 0xc773bc: ldur            x1, [fp, #-0x10]
    // 0xc773c0: ldur            x0, [fp, #-0x40]
    // 0xc773c4: stur            x2, [fp, #-0x38]
    // 0xc773c8: r0 = VideoRecordedEvent()
    //     0xc773c8: bl              #0xc77530  ; AllocateVideoRecordedEventStub -> VideoRecordedEvent (size=0x18)
    // 0xc773cc: mov             x1, x0
    // 0xc773d0: ldur            x0, [fp, #-0x40]
    // 0xc773d4: StoreField: r1->field_f = r0
    //     0xc773d4: stur            w0, [x1, #0xf]
    // 0xc773d8: ldur            x0, [fp, #-0x38]
    // 0xc773dc: StoreField: r1->field_13 = r0
    //     0xc773dc: stur            w0, [x1, #0x13]
    // 0xc773e0: ldur            x2, [fp, #-0x10]
    // 0xc773e4: StoreField: r1->field_7 = r2
    //     0xc773e4: stur            x2, [x1, #7]
    // 0xc773e8: ldur            x16, [fp, #-0x30]
    // 0xc773ec: stp             x1, x16, [SP, #-0x10]!
    // 0xc773f0: r0 = add()
    //     0xc773f0: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc773f4: add             SP, SP, #0x10
    // 0xc773f8: b               #0xc774dc
    // 0xc773fc: ldur            x0, [fp, #-0x20]
    // 0xc77400: ldur            x2, [fp, #-0x10]
    // 0xc77404: r16 = "error"
    //     0xc77404: ldr             x16, [PP, #0xeb8]  ; [pp+0xeb8] "error"
    // 0xc77408: ldur            lr, [fp, #-0x28]
    // 0xc7740c: stp             lr, x16, [SP, #-0x10]!
    // 0xc77410: r0 = ==()
    //     0xc77410: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc77414: add             SP, SP, #0x10
    // 0xc77418: tbnz            w0, #4, #0xc774e4
    // 0xc7741c: ldur            x0, [fp, #-0x20]
    // 0xc77420: ldur            x1, [fp, #-0x10]
    // 0xc77424: ldur            x16, [fp, #-0x18]
    // 0xc77428: stp             x16, x0, [SP, #-0x10]!
    // 0xc7742c: r0 = _getArgumentDictionary()
    //     0xc7742c: bl              #0x5ababc  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_getArgumentDictionary
    // 0xc77430: add             SP, SP, #0x10
    // 0xc77434: mov             x1, x0
    // 0xc77438: ldur            x0, [fp, #-0x20]
    // 0xc7743c: LoadField: r2 = r0->field_b
    //     0xc7743c: ldur            w2, [x0, #0xb]
    // 0xc77440: DecompressPointer r2
    //     0xc77440: add             x2, x2, HEAP, lsl #32
    // 0xc77444: stur            x2, [fp, #-0x18]
    // 0xc77448: r0 = LoadClassIdInstr(r1)
    //     0xc77448: ldur            x0, [x1, #-1]
    //     0xc7744c: ubfx            x0, x0, #0xc, #0x14
    // 0xc77450: r16 = "description"
    //     0xc77450: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b70] "description"
    //     0xc77454: ldr             x16, [x16, #0xb70]
    // 0xc77458: stp             x16, x1, [SP, #-0x10]!
    // 0xc7745c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7745c: sub             lr, x0, #0xef
    //     0xc77460: ldr             lr, [x21, lr, lsl #3]
    //     0xc77464: blr             lr
    // 0xc77468: add             SP, SP, #0x10
    // 0xc7746c: mov             x3, x0
    // 0xc77470: stur            x3, [fp, #-0x20]
    // 0xc77474: cmp             w3, NULL
    // 0xc77478: b.eq            #0xc77520
    // 0xc7747c: mov             x0, x3
    // 0xc77480: r2 = Null
    //     0xc77480: mov             x2, NULL
    // 0xc77484: r1 = Null
    //     0xc77484: mov             x1, NULL
    // 0xc77488: r4 = 59
    //     0xc77488: mov             x4, #0x3b
    // 0xc7748c: branchIfSmi(r0, 0xc77498)
    //     0xc7748c: tbz             w0, #0, #0xc77498
    // 0xc77490: r4 = LoadClassIdInstr(r0)
    //     0xc77490: ldur            x4, [x0, #-1]
    //     0xc77494: ubfx            x4, x4, #0xc, #0x14
    // 0xc77498: sub             x4, x4, #0x5d
    // 0xc7749c: cmp             x4, #3
    // 0xc774a0: b.ls            #0xc774b4
    // 0xc774a4: r8 = String
    //     0xc774a4: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc774a8: r3 = Null
    //     0xc774a8: add             x3, PP, #0x54, lsl #12  ; [pp+0x54298] Null
    //     0xc774ac: ldr             x3, [x3, #0x298]
    // 0xc774b0: r0 = String()
    //     0xc774b0: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc774b4: r0 = CameraErrorEvent()
    //     0xc774b4: bl              #0xc77524  ; AllocateCameraErrorEventStub -> CameraErrorEvent (size=0x14)
    // 0xc774b8: mov             x1, x0
    // 0xc774bc: ldur            x0, [fp, #-0x20]
    // 0xc774c0: StoreField: r1->field_f = r0
    //     0xc774c0: stur            w0, [x1, #0xf]
    // 0xc774c4: ldur            x0, [fp, #-0x10]
    // 0xc774c8: StoreField: r1->field_7 = r0
    //     0xc774c8: stur            x0, [x1, #7]
    // 0xc774cc: ldur            x16, [fp, #-0x18]
    // 0xc774d0: stp             x1, x16, [SP, #-0x10]!
    // 0xc774d4: r0 = add()
    //     0xc774d4: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc774d8: add             SP, SP, #0x10
    // 0xc774dc: r0 = Null
    //     0xc774dc: mov             x0, NULL
    // 0xc774e0: r0 = ReturnAsyncNotFuture()
    //     0xc774e0: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc774e4: r0 = MissingPluginException()
    //     0xc774e4: bl              #0x501aa4  ; AllocateMissingPluginExceptionStub -> MissingPluginException (size=0xc)
    // 0xc774e8: r0 = Throw()
    //     0xc774e8: bl              #0xd67e38  ; ThrowStub
    // 0xc774ec: brk             #0
    // 0xc774f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc774f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc774f4: b               #0xc76c5c
    // 0xc774f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc774f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc774fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc774fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc77500: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc77500: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc77504: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc77504: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc77508: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc77508: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7750c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7750c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc77510: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc77510: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc77514: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc77514: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc77518: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc77518: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7751c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7751c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc77520: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc77520: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ createCamera(/* No info */) async {
    // ** addr: 0xc79ec0, size: 0x278
    // 0xc79ec0: EnterFrame
    //     0xc79ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xc79ec4: mov             fp, SP
    // 0xc79ec8: AllocStack(0x78)
    //     0xc79ec8: sub             SP, SP, #0x78
    // 0xc79ecc: SetupParameters(AndroidCamera this /* r1, fp-0x78 */, dynamic _ /* r2, fp-0x70 */, dynamic _ /* r3, fp-0x68 */, dynamic _ /* r4, fp-0x60 */)
    //     0xc79ecc: stur            NULL, [fp, #-8]
    //     0xc79ed0: mov             x0, #0
    //     0xc79ed4: add             x1, fp, w0, sxtw #2
    //     0xc79ed8: ldr             x1, [x1, #0x28]
    //     0xc79edc: stur            x1, [fp, #-0x78]
    //     0xc79ee0: add             x2, fp, w0, sxtw #2
    //     0xc79ee4: ldr             x2, [x2, #0x20]
    //     0xc79ee8: stur            x2, [fp, #-0x70]
    //     0xc79eec: add             x3, fp, w0, sxtw #2
    //     0xc79ef0: ldr             x3, [x3, #0x18]
    //     0xc79ef4: stur            x3, [fp, #-0x68]
    //     0xc79ef8: add             x4, fp, w0, sxtw #2
    //     0xc79efc: ldr             x4, [x4, #0x10]
    //     0xc79f00: stur            x4, [fp, #-0x60]
    // 0xc79f04: CheckStackOverflow
    //     0xc79f04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc79f08: cmp             SP, x16
    //     0xc79f0c: b.ls            #0xc7a128
    // 0xc79f10: InitAsync() -> Future<int>
    //     0xc79f10: ldr             x0, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    //     0xc79f14: bl              #0x4b92e4
    // 0xc79f18: ldur            x0, [fp, #-0x70]
    // 0xc79f1c: ldur            x3, [fp, #-0x68]
    // 0xc79f20: r1 = Null
    //     0xc79f20: mov             x1, NULL
    // 0xc79f24: r2 = 12
    //     0xc79f24: mov             x2, #0xc
    // 0xc79f28: r0 = AllocateArray()
    //     0xc79f28: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc79f2c: r17 = "cameraName"
    //     0xc79f2c: add             x17, PP, #0x53, lsl #12  ; [pp+0x53dd8] "cameraName"
    //     0xc79f30: ldr             x17, [x17, #0xdd8]
    // 0xc79f34: StoreField: r0->field_f = r17
    //     0xc79f34: stur            w17, [x0, #0xf]
    // 0xc79f38: ldur            x1, [fp, #-0x70]
    // 0xc79f3c: LoadField: r2 = r1->field_7
    //     0xc79f3c: ldur            w2, [x1, #7]
    // 0xc79f40: DecompressPointer r2
    //     0xc79f40: add             x2, x2, HEAP, lsl #32
    // 0xc79f44: StoreField: r0->field_13 = r2
    //     0xc79f44: stur            w2, [x0, #0x13]
    // 0xc79f48: r17 = "resolutionPreset"
    //     0xc79f48: add             x17, PP, #0x53, lsl #12  ; [pp+0x53de0] "resolutionPreset"
    //     0xc79f4c: ldr             x17, [x17, #0xde0]
    // 0xc79f50: StoreField: r0->field_17 = r17
    //     0xc79f50: stur            w17, [x0, #0x17]
    // 0xc79f54: ldur            x1, [fp, #-0x68]
    // 0xc79f58: r2 = LoadClassIdInstr(r1)
    //     0xc79f58: ldur            x2, [x1, #-1]
    //     0xc79f5c: ubfx            x2, x2, #0xc, #0x14
    // 0xc79f60: lsl             x2, x2, #1
    // 0xc79f64: r17 = 12036
    //     0xc79f64: mov             x17, #0x2f04
    // 0xc79f68: cmp             w2, w17
    // 0xc79f6c: b.ne            #0xc79fe4
    // 0xc79f70: LoadField: r2 = r1->field_7
    //     0xc79f70: ldur            x2, [x1, #7]
    // 0xc79f74: cmp             x2, #2
    // 0xc79f78: b.gt            #0xc79fb0
    // 0xc79f7c: cmp             x2, #1
    // 0xc79f80: b.gt            #0xc79fa4
    // 0xc79f84: cmp             x2, #0
    // 0xc79f88: b.gt            #0xc79f98
    // 0xc79f8c: r2 = "low"
    //     0xc79f8c: add             x2, PP, #0x53, lsl #12  ; [pp+0x53de8] "low"
    //     0xc79f90: ldr             x2, [x2, #0xde8]
    // 0xc79f94: b               #0xc79fec
    // 0xc79f98: r2 = "medium"
    //     0xc79f98: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c7e0] "medium"
    //     0xc79f9c: ldr             x2, [x2, #0x7e0]
    // 0xc79fa0: b               #0xc79fec
    // 0xc79fa4: r2 = "high"
    //     0xc79fa4: add             x2, PP, #0x53, lsl #12  ; [pp+0x53df0] "high"
    //     0xc79fa8: ldr             x2, [x2, #0xdf0]
    // 0xc79fac: b               #0xc79fec
    // 0xc79fb0: cmp             x2, #4
    // 0xc79fb4: b.gt            #0xc79fd8
    // 0xc79fb8: cmp             x2, #3
    // 0xc79fbc: b.gt            #0xc79fcc
    // 0xc79fc0: r2 = "veryHigh"
    //     0xc79fc0: add             x2, PP, #0x53, lsl #12  ; [pp+0x53df8] "veryHigh"
    //     0xc79fc4: ldr             x2, [x2, #0xdf8]
    // 0xc79fc8: b               #0xc79fec
    // 0xc79fcc: r2 = "ultraHigh"
    //     0xc79fcc: add             x2, PP, #0x53, lsl #12  ; [pp+0x53e00] "ultraHigh"
    //     0xc79fd0: ldr             x2, [x2, #0xe00]
    // 0xc79fd4: b               #0xc79fec
    // 0xc79fd8: r2 = "max"
    //     0xc79fd8: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] "max"
    //     0xc79fdc: ldr             x2, [x2, #0x8e0]
    // 0xc79fe0: b               #0xc79fec
    // 0xc79fe4: r2 = "max"
    //     0xc79fe4: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] "max"
    //     0xc79fe8: ldr             x2, [x2, #0x8e0]
    // 0xc79fec: ldur            x1, [fp, #-0x60]
    // 0xc79ff0: StoreField: r0->field_1b = r2
    //     0xc79ff0: stur            w2, [x0, #0x1b]
    // 0xc79ff4: r17 = "enableAudio"
    //     0xc79ff4: add             x17, PP, #0x53, lsl #12  ; [pp+0x53e08] "enableAudio"
    //     0xc79ff8: ldr             x17, [x17, #0xe08]
    // 0xc79ffc: StoreField: r0->field_1f = r17
    //     0xc79ffc: stur            w17, [x0, #0x1f]
    // 0xc7a000: StoreField: r0->field_23 = r1
    //     0xc7a000: stur            w1, [x0, #0x23]
    // 0xc7a004: r16 = <String, dynamic>
    //     0xc7a004: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc7a008: stp             x0, x16, [SP, #-0x10]!
    // 0xc7a00c: r0 = Map._fromLiteral()
    //     0xc7a00c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc7a010: add             SP, SP, #0x10
    // 0xc7a014: r16 = <String, dynamic>
    //     0xc7a014: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc7a018: r30 = Instance_MethodChannel
    //     0xc7a018: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc7a01c: ldr             lr, [lr, #0x378]
    // 0xc7a020: stp             lr, x16, [SP, #-0x10]!
    // 0xc7a024: r16 = "create"
    //     0xc7a024: add             x16, PP, #0x36, lsl #12  ; [pp+0x36fe8] "create"
    //     0xc7a028: ldr             x16, [x16, #0xfe8]
    // 0xc7a02c: stp             x0, x16, [SP, #-0x10]!
    // 0xc7a030: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0xc7a030: ldr             x4, [PP, #0x8c0]  ; [pp+0x8c0] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0xc7a034: r0 = invokeMapMethod()
    //     0xc7a034: bl              #0x5a21c4  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0xc7a038: add             SP, SP, #0x20
    // 0xc7a03c: mov             x1, x0
    // 0xc7a040: stur            x1, [fp, #-0x60]
    // 0xc7a044: r0 = Await()
    //     0xc7a044: bl              #0x4b8e6c  ; AwaitStub
    // 0xc7a048: cmp             w0, NULL
    // 0xc7a04c: b.eq            #0xc7a130
    // 0xc7a050: r1 = LoadClassIdInstr(r0)
    //     0xc7a050: ldur            x1, [x0, #-1]
    //     0xc7a054: ubfx            x1, x1, #0xc, #0x14
    // 0xc7a058: r16 = "cameraId"
    //     0xc7a058: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc7a05c: ldr             x16, [x16, #0x890]
    // 0xc7a060: stp             x16, x0, [SP, #-0x10]!
    // 0xc7a064: mov             x0, x1
    // 0xc7a068: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7a068: sub             lr, x0, #0xef
    //     0xc7a06c: ldr             lr, [x21, lr, lsl #3]
    //     0xc7a070: blr             lr
    // 0xc7a074: add             SP, SP, #0x10
    // 0xc7a078: mov             x3, x0
    // 0xc7a07c: stur            x3, [fp, #-0x60]
    // 0xc7a080: cmp             w3, NULL
    // 0xc7a084: b.eq            #0xc7a134
    // 0xc7a088: r3 as int
    //     0xc7a088: mov             x0, x3
    //     0xc7a08c: mov             x2, NULL
    //     0xc7a090: mov             x1, NULL
    //     0xc7a094: tbz             w0, #0, #0xc7a0bc
    //     0xc7a098: ldur            x4, [x0, #-1]
    //     0xc7a09c: ubfx            x4, x4, #0xc, #0x14
    //     0xc7a0a0: sub             x4, x4, #0x3b
    //     0xc7a0a4: cmp             x4, #1
    //     0xc7a0a8: b.ls            #0xc7a0bc
    //     0xc7a0ac: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xc7a0b0: add             x3, PP, #0x54, lsl #12  ; [pp+0x542a8] Null
    //     0xc7a0b4: ldr             x3, [x3, #0x2a8]
    //     0xc7a0b8: bl              #0xd73714
    // 0xc7a0bc: ldur            x0, [fp, #-0x60]
    // 0xc7a0c0: r0 = ReturnAsyncNotFuture()
    //     0xc7a0c0: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc7a0c4: sub             SP, fp, #0x78
    // 0xc7a0c8: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc7a0c8: mov             x2, #0x76
    //     0xc7a0cc: tbz             w0, #0, #0xc7a0dc
    //     0xc7a0d0: ldur            x2, [x0, #-1]
    //     0xc7a0d4: ubfx            x2, x2, #0xc, #0x14
    //     0xc7a0d8: lsl             x2, x2, #1
    // 0xc7a0dc: cmp             w2, #0xf28
    // 0xc7a0e0: b.ne            #0xc7a120
    // 0xc7a0e4: LoadField: r1 = r0->field_7
    //     0xc7a0e4: ldur            w1, [x0, #7]
    // 0xc7a0e8: DecompressPointer r1
    //     0xc7a0e8: add             x1, x1, HEAP, lsl #32
    // 0xc7a0ec: stur            x1, [fp, #-0x68]
    // 0xc7a0f0: LoadField: r2 = r0->field_b
    //     0xc7a0f0: ldur            w2, [x0, #0xb]
    // 0xc7a0f4: DecompressPointer r2
    //     0xc7a0f4: add             x2, x2, HEAP, lsl #32
    // 0xc7a0f8: stur            x2, [fp, #-0x60]
    // 0xc7a0fc: r0 = CameraException()
    //     0xc7a0fc: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc7a100: mov             x1, x0
    // 0xc7a104: ldur            x0, [fp, #-0x68]
    // 0xc7a108: StoreField: r1->field_7 = r0
    //     0xc7a108: stur            w0, [x1, #7]
    // 0xc7a10c: ldur            x0, [fp, #-0x60]
    // 0xc7a110: StoreField: r1->field_b = r0
    //     0xc7a110: stur            w0, [x1, #0xb]
    // 0xc7a114: mov             x0, x1
    // 0xc7a118: r0 = Throw()
    //     0xc7a118: bl              #0xd67e38  ; ThrowStub
    // 0xc7a11c: brk             #0
    // 0xc7a120: r0 = ReThrow()
    //     0xc7a120: bl              #0xd67e14  ; ReThrowStub
    // 0xc7a124: brk             #0
    // 0xc7a128: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7a128: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7a12c: b               #0xc79f10
    // 0xc7a130: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7a130: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7a134: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7a134: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ availableCameras(/* No info */) async {
    // ** addr: 0xc7b2c0, size: 0x178
    // 0xc7b2c0: EnterFrame
    //     0xc7b2c0: stp             fp, lr, [SP, #-0x10]!
    //     0xc7b2c4: mov             fp, SP
    // 0xc7b2c8: AllocStack(0x50)
    //     0xc7b2c8: sub             SP, SP, #0x50
    // 0xc7b2cc: SetupParameters(AndroidCamera this /* r1, fp-0x48 */)
    //     0xc7b2cc: stur            NULL, [fp, #-8]
    //     0xc7b2d0: mov             x0, #0
    //     0xc7b2d4: add             x1, fp, w0, sxtw #2
    //     0xc7b2d8: ldr             x1, [x1, #0x10]
    //     0xc7b2dc: stur            x1, [fp, #-0x48]
    // 0xc7b2e0: CheckStackOverflow
    //     0xc7b2e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7b2e4: cmp             SP, x16
    //     0xc7b2e8: b.ls            #0xc7b430
    // 0xc7b2ec: InitAsync() -> Future<List<CameraDescription>>
    //     0xc7b2ec: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d590] TypeArguments: <List<CameraDescription>>
    //     0xc7b2f0: ldr             x0, [x0, #0x590]
    //     0xc7b2f4: bl              #0x4b92e4
    // 0xc7b2f8: r16 = <Map>
    //     0xc7b2f8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14cb0] TypeArguments: <Map>
    //     0xc7b2fc: ldr             x16, [x16, #0xcb0]
    // 0xc7b300: r30 = Instance_MethodChannel
    //     0xc7b300: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0xc7b304: ldr             lr, [lr, #0x378]
    // 0xc7b308: stp             lr, x16, [SP, #-0x10]!
    // 0xc7b30c: r16 = "availableCameras"
    //     0xc7b30c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e20] "availableCameras"
    //     0xc7b310: ldr             x16, [x16, #0xe20]
    // 0xc7b314: SaveReg r16
    //     0xc7b314: str             x16, [SP, #-8]!
    // 0xc7b318: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc7b318: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc7b31c: r0 = invokeListMethod()
    //     0xc7b31c: bl              #0x799418  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeListMethod
    // 0xc7b320: add             SP, SP, #0x18
    // 0xc7b324: mov             x1, x0
    // 0xc7b328: stur            x1, [fp, #-0x48]
    // 0xc7b32c: r0 = Await()
    //     0xc7b32c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc7b330: stur            x0, [fp, #-0x48]
    // 0xc7b334: cmp             w0, NULL
    // 0xc7b338: b.ne            #0xc7b354
    // 0xc7b33c: r16 = <CameraDescription>
    //     0xc7b33c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e28] TypeArguments: <CameraDescription>
    //     0xc7b340: ldr             x16, [x16, #0xe28]
    // 0xc7b344: stp             xzr, x16, [SP, #-0x10]!
    // 0xc7b348: r0 = _GrowableList()
    //     0xc7b348: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xc7b34c: add             SP, SP, #0x10
    // 0xc7b350: r0 = ReturnAsyncNotFuture()
    //     0xc7b350: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc7b354: r1 = Function '<anonymous closure>':.
    //     0xc7b354: add             x1, PP, #0x54, lsl #12  ; [pp+0x542b8] AnonymousClosure: (0xc7b438), in [package:camera_android/src/android_camera.dart] AndroidCamera::availableCameras (0xc7b2c0)
    //     0xc7b358: ldr             x1, [x1, #0x2b8]
    // 0xc7b35c: r2 = Null
    //     0xc7b35c: mov             x2, NULL
    // 0xc7b360: r0 = AllocateClosure()
    //     0xc7b360: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc7b364: mov             x1, x0
    // 0xc7b368: ldur            x0, [fp, #-0x48]
    // 0xc7b36c: r2 = LoadClassIdInstr(r0)
    //     0xc7b36c: ldur            x2, [x0, #-1]
    //     0xc7b370: ubfx            x2, x2, #0xc, #0x14
    // 0xc7b374: r16 = <CameraDescription>
    //     0xc7b374: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e28] TypeArguments: <CameraDescription>
    //     0xc7b378: ldr             x16, [x16, #0xe28]
    // 0xc7b37c: stp             x0, x16, [SP, #-0x10]!
    // 0xc7b380: SaveReg r1
    //     0xc7b380: str             x1, [SP, #-8]!
    // 0xc7b384: mov             x0, x2
    // 0xc7b388: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc7b388: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc7b38c: r0 = GDT[cid_x0 + 0xc934]()
    //     0xc7b38c: mov             x17, #0xc934
    //     0xc7b390: add             lr, x0, x17
    //     0xc7b394: ldr             lr, [x21, lr, lsl #3]
    //     0xc7b398: blr             lr
    // 0xc7b39c: add             SP, SP, #0x18
    // 0xc7b3a0: r1 = LoadClassIdInstr(r0)
    //     0xc7b3a0: ldur            x1, [x0, #-1]
    //     0xc7b3a4: ubfx            x1, x1, #0xc, #0x14
    // 0xc7b3a8: SaveReg r0
    //     0xc7b3a8: str             x0, [SP, #-8]!
    // 0xc7b3ac: mov             x0, x1
    // 0xc7b3b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc7b3b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc7b3b4: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0xc7b3b4: mov             x17, #0xc8a1
    //     0xc7b3b8: add             lr, x0, x17
    //     0xc7b3bc: ldr             lr, [x21, lr, lsl #3]
    //     0xc7b3c0: blr             lr
    // 0xc7b3c4: add             SP, SP, #8
    // 0xc7b3c8: r0 = ReturnAsync()
    //     0xc7b3c8: b               #0x501858  ; ReturnAsyncStub
    // 0xc7b3cc: sub             SP, fp, #0x50
    // 0xc7b3d0: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc7b3d0: mov             x2, #0x76
    //     0xc7b3d4: tbz             w0, #0, #0xc7b3e4
    //     0xc7b3d8: ldur            x2, [x0, #-1]
    //     0xc7b3dc: ubfx            x2, x2, #0xc, #0x14
    //     0xc7b3e0: lsl             x2, x2, #1
    // 0xc7b3e4: cmp             w2, #0xf28
    // 0xc7b3e8: b.ne            #0xc7b428
    // 0xc7b3ec: LoadField: r1 = r0->field_7
    //     0xc7b3ec: ldur            w1, [x0, #7]
    // 0xc7b3f0: DecompressPointer r1
    //     0xc7b3f0: add             x1, x1, HEAP, lsl #32
    // 0xc7b3f4: stur            x1, [fp, #-0x50]
    // 0xc7b3f8: LoadField: r2 = r0->field_b
    //     0xc7b3f8: ldur            w2, [x0, #0xb]
    // 0xc7b3fc: DecompressPointer r2
    //     0xc7b3fc: add             x2, x2, HEAP, lsl #32
    // 0xc7b400: stur            x2, [fp, #-0x48]
    // 0xc7b404: r0 = CameraException()
    //     0xc7b404: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc7b408: mov             x1, x0
    // 0xc7b40c: ldur            x0, [fp, #-0x50]
    // 0xc7b410: StoreField: r1->field_7 = r0
    //     0xc7b410: stur            w0, [x1, #7]
    // 0xc7b414: ldur            x0, [fp, #-0x48]
    // 0xc7b418: StoreField: r1->field_b = r0
    //     0xc7b418: stur            w0, [x1, #0xb]
    // 0xc7b41c: mov             x0, x1
    // 0xc7b420: r0 = Throw()
    //     0xc7b420: bl              #0xd67e38  ; ThrowStub
    // 0xc7b424: brk             #0
    // 0xc7b428: r0 = ReThrow()
    //     0xc7b428: bl              #0xd67e14  ; ReThrowStub
    // 0xc7b42c: brk             #0
    // 0xc7b430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7b430: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7b434: b               #0xc7b2ec
  }
  [closure] CameraDescription <anonymous closure>(dynamic, Map<dynamic, dynamic>) {
    // ** addr: 0xc7b438, size: 0x1c4
    // 0xc7b438: EnterFrame
    //     0xc7b438: stp             fp, lr, [SP, #-0x10]!
    //     0xc7b43c: mov             fp, SP
    // 0xc7b440: AllocStack(0x18)
    //     0xc7b440: sub             SP, SP, #0x18
    // 0xc7b444: CheckStackOverflow
    //     0xc7b444: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7b448: cmp             SP, x16
    //     0xc7b44c: b.ls            #0xc7b5e8
    // 0xc7b450: ldr             x1, [fp, #0x10]
    // 0xc7b454: r0 = LoadClassIdInstr(r1)
    //     0xc7b454: ldur            x0, [x1, #-1]
    //     0xc7b458: ubfx            x0, x0, #0xc, #0x14
    // 0xc7b45c: r16 = "name"
    //     0xc7b45c: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xc7b460: stp             x16, x1, [SP, #-0x10]!
    // 0xc7b464: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7b464: sub             lr, x0, #0xef
    //     0xc7b468: ldr             lr, [x21, lr, lsl #3]
    //     0xc7b46c: blr             lr
    // 0xc7b470: add             SP, SP, #0x10
    // 0xc7b474: mov             x3, x0
    // 0xc7b478: stur            x3, [fp, #-8]
    // 0xc7b47c: cmp             w3, NULL
    // 0xc7b480: b.eq            #0xc7b5f0
    // 0xc7b484: mov             x0, x3
    // 0xc7b488: r2 = Null
    //     0xc7b488: mov             x2, NULL
    // 0xc7b48c: r1 = Null
    //     0xc7b48c: mov             x1, NULL
    // 0xc7b490: r4 = 59
    //     0xc7b490: mov             x4, #0x3b
    // 0xc7b494: branchIfSmi(r0, 0xc7b4a0)
    //     0xc7b494: tbz             w0, #0, #0xc7b4a0
    // 0xc7b498: r4 = LoadClassIdInstr(r0)
    //     0xc7b498: ldur            x4, [x0, #-1]
    //     0xc7b49c: ubfx            x4, x4, #0xc, #0x14
    // 0xc7b4a0: sub             x4, x4, #0x5d
    // 0xc7b4a4: cmp             x4, #3
    // 0xc7b4a8: b.ls            #0xc7b4bc
    // 0xc7b4ac: r8 = String
    //     0xc7b4ac: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc7b4b0: r3 = Null
    //     0xc7b4b0: add             x3, PP, #0x54, lsl #12  ; [pp+0x542c0] Null
    //     0xc7b4b4: ldr             x3, [x3, #0x2c0]
    // 0xc7b4b8: r0 = String()
    //     0xc7b4b8: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc7b4bc: ldr             x1, [fp, #0x10]
    // 0xc7b4c0: r0 = LoadClassIdInstr(r1)
    //     0xc7b4c0: ldur            x0, [x1, #-1]
    //     0xc7b4c4: ubfx            x0, x0, #0xc, #0x14
    // 0xc7b4c8: r16 = "lensFacing"
    //     0xc7b4c8: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e48] "lensFacing"
    //     0xc7b4cc: ldr             x16, [x16, #0xe48]
    // 0xc7b4d0: stp             x16, x1, [SP, #-0x10]!
    // 0xc7b4d4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7b4d4: sub             lr, x0, #0xef
    //     0xc7b4d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc7b4dc: blr             lr
    // 0xc7b4e0: add             SP, SP, #0x10
    // 0xc7b4e4: mov             x3, x0
    // 0xc7b4e8: stur            x3, [fp, #-0x10]
    // 0xc7b4ec: cmp             w3, NULL
    // 0xc7b4f0: b.eq            #0xc7b5f4
    // 0xc7b4f4: mov             x0, x3
    // 0xc7b4f8: r2 = Null
    //     0xc7b4f8: mov             x2, NULL
    // 0xc7b4fc: r1 = Null
    //     0xc7b4fc: mov             x1, NULL
    // 0xc7b500: r4 = 59
    //     0xc7b500: mov             x4, #0x3b
    // 0xc7b504: branchIfSmi(r0, 0xc7b510)
    //     0xc7b504: tbz             w0, #0, #0xc7b510
    // 0xc7b508: r4 = LoadClassIdInstr(r0)
    //     0xc7b508: ldur            x4, [x0, #-1]
    //     0xc7b50c: ubfx            x4, x4, #0xc, #0x14
    // 0xc7b510: sub             x4, x4, #0x5d
    // 0xc7b514: cmp             x4, #3
    // 0xc7b518: b.ls            #0xc7b52c
    // 0xc7b51c: r8 = String
    //     0xc7b51c: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc7b520: r3 = Null
    //     0xc7b520: add             x3, PP, #0x54, lsl #12  ; [pp+0x542d0] Null
    //     0xc7b524: ldr             x3, [x3, #0x2d0]
    // 0xc7b528: r0 = String()
    //     0xc7b528: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc7b52c: ldur            x16, [fp, #-0x10]
    // 0xc7b530: SaveReg r16
    //     0xc7b530: str             x16, [SP, #-8]!
    // 0xc7b534: r0 = parseCameraLensDirection()
    //     0xc7b534: bl              #0xc7b608  ; [package:camera_android/src/utils.dart] ::parseCameraLensDirection
    // 0xc7b538: add             SP, SP, #8
    // 0xc7b53c: mov             x1, x0
    // 0xc7b540: ldr             x0, [fp, #0x10]
    // 0xc7b544: stur            x1, [fp, #-0x10]
    // 0xc7b548: r2 = LoadClassIdInstr(r0)
    //     0xc7b548: ldur            x2, [x0, #-1]
    //     0xc7b54c: ubfx            x2, x2, #0xc, #0x14
    // 0xc7b550: r16 = "sensorOrientation"
    //     0xc7b550: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e60] "sensorOrientation"
    //     0xc7b554: ldr             x16, [x16, #0xe60]
    // 0xc7b558: stp             x16, x0, [SP, #-0x10]!
    // 0xc7b55c: mov             x0, x2
    // 0xc7b560: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7b560: sub             lr, x0, #0xef
    //     0xc7b564: ldr             lr, [x21, lr, lsl #3]
    //     0xc7b568: blr             lr
    // 0xc7b56c: add             SP, SP, #0x10
    // 0xc7b570: mov             x3, x0
    // 0xc7b574: stur            x3, [fp, #-0x18]
    // 0xc7b578: cmp             w3, NULL
    // 0xc7b57c: b.eq            #0xc7b5f8
    // 0xc7b580: r3 as int
    //     0xc7b580: mov             x0, x3
    //     0xc7b584: mov             x2, NULL
    //     0xc7b588: mov             x1, NULL
    //     0xc7b58c: tbz             w0, #0, #0xc7b5b4
    //     0xc7b590: ldur            x4, [x0, #-1]
    //     0xc7b594: ubfx            x4, x4, #0xc, #0x14
    //     0xc7b598: sub             x4, x4, #0x3b
    //     0xc7b59c: cmp             x4, #1
    //     0xc7b5a0: b.ls            #0xc7b5b4
    //     0xc7b5a4: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xc7b5a8: add             x3, PP, #0x54, lsl #12  ; [pp+0x542e0] Null
    //     0xc7b5ac: ldr             x3, [x3, #0x2e0]
    //     0xc7b5b0: bl              #0xd73714
    // 0xc7b5b4: r0 = CameraDescription()
    //     0xc7b5b4: bl              #0xc7b5fc  ; AllocateCameraDescriptionStub -> CameraDescription (size=0x18)
    // 0xc7b5b8: ldur            x1, [fp, #-8]
    // 0xc7b5bc: StoreField: r0->field_7 = r1
    //     0xc7b5bc: stur            w1, [x0, #7]
    // 0xc7b5c0: ldur            x1, [fp, #-0x10]
    // 0xc7b5c4: StoreField: r0->field_b = r1
    //     0xc7b5c4: stur            w1, [x0, #0xb]
    // 0xc7b5c8: ldur            x1, [fp, #-0x18]
    // 0xc7b5cc: r2 = LoadInt32Instr(r1)
    //     0xc7b5cc: sbfx            x2, x1, #1, #0x1f
    //     0xc7b5d0: tbz             w1, #0, #0xc7b5d8
    //     0xc7b5d4: ldur            x2, [x1, #7]
    // 0xc7b5d8: StoreField: r0->field_f = r2
    //     0xc7b5d8: stur            x2, [x0, #0xf]
    // 0xc7b5dc: LeaveFrame
    //     0xc7b5dc: mov             SP, fp
    //     0xc7b5e0: ldp             fp, lr, [SP], #0x10
    // 0xc7b5e4: ret
    //     0xc7b5e4: ret             
    // 0xc7b5e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7b5e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7b5ec: b               #0xc7b450
    // 0xc7b5f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7b5f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7b5f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7b5f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7b5f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7b5f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ AndroidCamera(/* No info */) {
    // ** addr: 0xd70074, size: 0x100
    // 0xd70074: EnterFrame
    //     0xd70074: stp             fp, lr, [SP, #-0x10]!
    //     0xd70078: mov             fp, SP
    // 0xd7007c: AllocStack(0x8)
    //     0xd7007c: sub             SP, SP, #8
    // 0xd70080: r0 = Sentinel
    //     0xd70080: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd70084: CheckStackOverflow
    //     0xd70084: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd70088: cmp             SP, x16
    //     0xd7008c: b.ls            #0xd7016c
    // 0xd70090: ldr             x1, [fp, #0x10]
    // 0xd70094: StoreField: r1->field_f = r0
    //     0xd70094: stur            w0, [x1, #0xf]
    // 0xd70098: r16 = <int, MethodChannel>
    //     0xd70098: ldr             x16, [PP, #0xdb0]  ; [pp+0xdb0] TypeArguments: <int, MethodChannel>
    // 0xd7009c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xd700a0: stp             lr, x16, [SP, #-0x10]!
    // 0xd700a4: r0 = Map._fromLiteral()
    //     0xd700a4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xd700a8: add             SP, SP, #0x10
    // 0xd700ac: ldr             x1, [fp, #0x10]
    // 0xd700b0: StoreField: r1->field_7 = r0
    //     0xd700b0: stur            w0, [x1, #7]
    //     0xd700b4: tbz             w0, #0, #0xd700d0
    //     0xd700b8: ldurb           w16, [x1, #-1]
    //     0xd700bc: ldurb           w17, [x0, #-1]
    //     0xd700c0: and             x16, x17, x16, lsr #2
    //     0xd700c4: tst             x16, HEAP, lsr #32
    //     0xd700c8: b.eq            #0xd700d0
    //     0xd700cc: bl              #0xd6826c
    // 0xd700d0: r16 = <CameraEvent>
    //     0xd700d0: ldr             x16, [PP, #0xdb8]  ; [pp+0xdb8] TypeArguments: <CameraEvent>
    // 0xd700d4: SaveReg r16
    //     0xd700d4: str             x16, [SP, #-8]!
    // 0xd700d8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xd700d8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xd700dc: r0 = StreamController.broadcast()
    //     0xd700dc: bl              #0x5a25d4  ; [dart:async] StreamController::StreamController.broadcast
    // 0xd700e0: add             SP, SP, #8
    // 0xd700e4: ldr             x1, [fp, #0x10]
    // 0xd700e8: StoreField: r1->field_b = r0
    //     0xd700e8: stur            w0, [x1, #0xb]
    //     0xd700ec: tbz             w0, #0, #0xd70108
    //     0xd700f0: ldurb           w16, [x1, #-1]
    //     0xd700f4: ldurb           w17, [x0, #-1]
    //     0xd700f8: and             x16, x17, x16, lsr #2
    //     0xd700fc: tst             x16, HEAP, lsr #32
    //     0xd70100: b.eq            #0xd70108
    //     0xd70104: bl              #0xd6826c
    // 0xd70108: r0 = InitLateStaticField(0xac4) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_token
    //     0xd70108: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd7010c: ldr             x0, [x0, #0x1588]
    //     0xd70110: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd70114: cmp             w0, w16
    //     0xd70118: b.ne            #0xd70124
    //     0xd7011c: ldr             x2, [PP, #0xda8]  ; [pp+0xda8] Field <CameraPlatform._token@176219459>: static late final (offset: 0xac4)
    //     0xd70120: bl              #0xd67cdc
    // 0xd70124: stur            x0, [fp, #-8]
    // 0xd70128: r0 = InitLateStaticField(0xa64) // [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::_instanceTokens
    //     0xd70128: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd7012c: ldr             x0, [x0, #0x14c8]
    //     0xd70130: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd70134: cmp             w0, w16
    //     0xd70138: b.ne            #0xd70144
    //     0xd7013c: ldr             x2, [PP, #0x170]  ; [pp+0x170] Field <PlatformInterface._instanceTokens@187304592>: static late final (offset: 0xa64)
    //     0xd70140: bl              #0xd67cdc
    // 0xd70144: ldr             x16, [fp, #0x10]
    // 0xd70148: stp             x16, x0, [SP, #-0x10]!
    // 0xd7014c: ldur            x16, [fp, #-8]
    // 0xd70150: SaveReg r16
    //     0xd70150: str             x16, [SP, #-8]!
    // 0xd70154: r0 = []=()
    //     0xd70154: bl              #0x4b97f8  ; [dart:core] Expando::[]=
    // 0xd70158: add             SP, SP, #0x18
    // 0xd7015c: r0 = Null
    //     0xd7015c: mov             x0, NULL
    // 0xd70160: LeaveFrame
    //     0xd70160: mov             SP, fp
    //     0xd70164: ldp             fp, lr, [SP], #0x10
    // 0xd70168: ret
    //     0xd70168: ret             
    // 0xd7016c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd7016c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd70170: b               #0xd70090
  }
  static void registerWith() {
    // ** addr: 0xd70700, size: 0x7c
    // 0xd70700: EnterFrame
    //     0xd70700: stp             fp, lr, [SP, #-0x10]!
    //     0xd70704: mov             fp, SP
    // 0xd70708: AllocStack(0x8)
    //     0xd70708: sub             SP, SP, #8
    // 0xd7070c: CheckStackOverflow
    //     0xd7070c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd70710: cmp             SP, x16
    //     0xd70714: b.ls            #0xd70774
    // 0xd70718: r0 = AndroidCamera()
    //     0xd70718: bl              #0xd7077c  ; AllocateAndroidCameraStub -> AndroidCamera (size=0x1c)
    // 0xd7071c: stur            x0, [fp, #-8]
    // 0xd70720: SaveReg r0
    //     0xd70720: str             x0, [SP, #-8]!
    // 0xd70724: r0 = AndroidCamera()
    //     0xd70724: bl              #0xd70074  ; [package:camera_android/src/android_camera.dart] AndroidCamera::AndroidCamera
    // 0xd70728: add             SP, SP, #8
    // 0xd7072c: r0 = InitLateStaticField(0xac4) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_token
    //     0xd7072c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd70730: ldr             x0, [x0, #0x1588]
    //     0xd70734: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd70738: cmp             w0, w16
    //     0xd7073c: b.ne            #0xd70748
    //     0xd70740: ldr             x2, [PP, #0xda8]  ; [pp+0xda8] Field <CameraPlatform._token@176219459>: static late final (offset: 0xac4)
    //     0xd70744: bl              #0xd67cdc
    // 0xd70748: ldur            x16, [fp, #-8]
    // 0xd7074c: stp             x0, x16, [SP, #-0x10]!
    // 0xd70750: r0 = verify()
    //     0xd70750: bl              #0x942d7c  ; [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::verify
    // 0xd70754: add             SP, SP, #0x10
    // 0xd70758: ldur            x1, [fp, #-8]
    // 0xd7075c: StoreStaticField(0xac8, r1)
    //     0xd7075c: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0xd70760: str             x1, [x2, #0x1590]
    // 0xd70764: r0 = Null
    //     0xd70764: mov             x0, NULL
    // 0xd70768: LeaveFrame
    //     0xd70768: mov             SP, fp
    //     0xd7076c: ldp             fp, lr, [SP], #0x10
    // 0xd70770: ret
    //     0xd70770: ret             
    // 0xd70774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd70774: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd70778: b               #0xd70718
  }
}

// lib: , url: package:camera_android/src/type_conversion.dart

// class id: 1048706, size: 0x8
class :: {

  static _ cameraImageFromPlatformData(/* No info */) {
    // ** addr: 0xc6acc8, size: 0x38c
    // 0xc6acc8: EnterFrame
    //     0xc6acc8: stp             fp, lr, [SP, #-0x10]!
    //     0xc6accc: mov             fp, SP
    // 0xc6acd0: AllocStack(0x38)
    //     0xc6acd0: sub             SP, SP, #0x38
    // 0xc6acd4: CheckStackOverflow
    //     0xc6acd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6acd8: cmp             SP, x16
    //     0xc6acdc: b.ls            #0xc6b04c
    // 0xc6ace0: ldr             x1, [fp, #0x10]
    // 0xc6ace4: r0 = LoadClassIdInstr(r1)
    //     0xc6ace4: ldur            x0, [x1, #-1]
    //     0xc6ace8: ubfx            x0, x0, #0xc, #0x14
    // 0xc6acec: r16 = "format"
    //     0xc6acec: add             x16, PP, #0x25, lsl #12  ; [pp+0x25d08] "format"
    //     0xc6acf0: ldr             x16, [x16, #0xd08]
    // 0xc6acf4: stp             x16, x1, [SP, #-0x10]!
    // 0xc6acf8: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6acf8: sub             lr, x0, #0xef
    //     0xc6acfc: ldr             lr, [x21, lr, lsl #3]
    //     0xc6ad00: blr             lr
    // 0xc6ad04: add             SP, SP, #0x10
    // 0xc6ad08: SaveReg r0
    //     0xc6ad08: str             x0, [SP, #-8]!
    // 0xc6ad0c: r0 = _cameraImageFormatFromPlatformData()
    //     0xc6ad0c: bl              #0xc6b084  ; [package:camera_android/src/type_conversion.dart] ::_cameraImageFormatFromPlatformData
    // 0xc6ad10: add             SP, SP, #8
    // 0xc6ad14: mov             x2, x0
    // 0xc6ad18: ldr             x1, [fp, #0x10]
    // 0xc6ad1c: stur            x2, [fp, #-8]
    // 0xc6ad20: r0 = LoadClassIdInstr(r1)
    //     0xc6ad20: ldur            x0, [x1, #-1]
    //     0xc6ad24: ubfx            x0, x0, #0xc, #0x14
    // 0xc6ad28: r16 = "height"
    //     0xc6ad28: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb08] "height"
    //     0xc6ad2c: ldr             x16, [x16, #0xb08]
    // 0xc6ad30: stp             x16, x1, [SP, #-0x10]!
    // 0xc6ad34: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6ad34: sub             lr, x0, #0xef
    //     0xc6ad38: ldr             lr, [x21, lr, lsl #3]
    //     0xc6ad3c: blr             lr
    // 0xc6ad40: add             SP, SP, #0x10
    // 0xc6ad44: mov             x3, x0
    // 0xc6ad48: r2 = Null
    //     0xc6ad48: mov             x2, NULL
    // 0xc6ad4c: r1 = Null
    //     0xc6ad4c: mov             x1, NULL
    // 0xc6ad50: stur            x3, [fp, #-0x10]
    // 0xc6ad54: branchIfSmi(r0, 0xc6ad7c)
    //     0xc6ad54: tbz             w0, #0, #0xc6ad7c
    // 0xc6ad58: r4 = LoadClassIdInstr(r0)
    //     0xc6ad58: ldur            x4, [x0, #-1]
    //     0xc6ad5c: ubfx            x4, x4, #0xc, #0x14
    // 0xc6ad60: sub             x4, x4, #0x3b
    // 0xc6ad64: cmp             x4, #1
    // 0xc6ad68: b.ls            #0xc6ad7c
    // 0xc6ad6c: r8 = int
    //     0xc6ad6c: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc6ad70: r3 = Null
    //     0xc6ad70: add             x3, PP, #0x54, lsl #12  ; [pp+0x540e8] Null
    //     0xc6ad74: ldr             x3, [x3, #0xe8]
    // 0xc6ad78: r0 = int()
    //     0xc6ad78: bl              #0xd73714  ; IsType_int_Stub
    // 0xc6ad7c: ldr             x1, [fp, #0x10]
    // 0xc6ad80: r0 = LoadClassIdInstr(r1)
    //     0xc6ad80: ldur            x0, [x1, #-1]
    //     0xc6ad84: ubfx            x0, x0, #0xc, #0x14
    // 0xc6ad88: r16 = "width"
    //     0xc6ad88: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb30] "width"
    //     0xc6ad8c: ldr             x16, [x16, #0xb30]
    // 0xc6ad90: stp             x16, x1, [SP, #-0x10]!
    // 0xc6ad94: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6ad94: sub             lr, x0, #0xef
    //     0xc6ad98: ldr             lr, [x21, lr, lsl #3]
    //     0xc6ad9c: blr             lr
    // 0xc6ada0: add             SP, SP, #0x10
    // 0xc6ada4: mov             x3, x0
    // 0xc6ada8: r2 = Null
    //     0xc6ada8: mov             x2, NULL
    // 0xc6adac: r1 = Null
    //     0xc6adac: mov             x1, NULL
    // 0xc6adb0: stur            x3, [fp, #-0x18]
    // 0xc6adb4: branchIfSmi(r0, 0xc6addc)
    //     0xc6adb4: tbz             w0, #0, #0xc6addc
    // 0xc6adb8: r4 = LoadClassIdInstr(r0)
    //     0xc6adb8: ldur            x4, [x0, #-1]
    //     0xc6adbc: ubfx            x4, x4, #0xc, #0x14
    // 0xc6adc0: sub             x4, x4, #0x3b
    // 0xc6adc4: cmp             x4, #1
    // 0xc6adc8: b.ls            #0xc6addc
    // 0xc6adcc: r8 = int
    //     0xc6adcc: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc6add0: r3 = Null
    //     0xc6add0: add             x3, PP, #0x54, lsl #12  ; [pp+0x540f8] Null
    //     0xc6add4: ldr             x3, [x3, #0xf8]
    // 0xc6add8: r0 = int()
    //     0xc6add8: bl              #0xd73714  ; IsType_int_Stub
    // 0xc6addc: ldr             x1, [fp, #0x10]
    // 0xc6ade0: r0 = LoadClassIdInstr(r1)
    //     0xc6ade0: ldur            x0, [x1, #-1]
    //     0xc6ade4: ubfx            x0, x0, #0xc, #0x14
    // 0xc6ade8: r16 = "lensAperture"
    //     0xc6ade8: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b68] "lensAperture"
    //     0xc6adec: ldr             x16, [x16, #0xb68]
    // 0xc6adf0: stp             x16, x1, [SP, #-0x10]!
    // 0xc6adf4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6adf4: sub             lr, x0, #0xef
    //     0xc6adf8: ldr             lr, [x21, lr, lsl #3]
    //     0xc6adfc: blr             lr
    // 0xc6ae00: add             SP, SP, #0x10
    // 0xc6ae04: mov             x3, x0
    // 0xc6ae08: r2 = Null
    //     0xc6ae08: mov             x2, NULL
    // 0xc6ae0c: r1 = Null
    //     0xc6ae0c: mov             x1, NULL
    // 0xc6ae10: stur            x3, [fp, #-0x20]
    // 0xc6ae14: r4 = 59
    //     0xc6ae14: mov             x4, #0x3b
    // 0xc6ae18: branchIfSmi(r0, 0xc6ae24)
    //     0xc6ae18: tbz             w0, #0, #0xc6ae24
    // 0xc6ae1c: r4 = LoadClassIdInstr(r0)
    //     0xc6ae1c: ldur            x4, [x0, #-1]
    //     0xc6ae20: ubfx            x4, x4, #0xc, #0x14
    // 0xc6ae24: cmp             x4, #0x3d
    // 0xc6ae28: b.eq            #0xc6ae3c
    // 0xc6ae2c: r8 = double?
    //     0xc6ae2c: ldr             x8, [PP, #0x21e0]  ; [pp+0x21e0] Type: double?
    // 0xc6ae30: r3 = Null
    //     0xc6ae30: add             x3, PP, #0x54, lsl #12  ; [pp+0x54108] Null
    //     0xc6ae34: ldr             x3, [x3, #0x108]
    // 0xc6ae38: r0 = double?()
    //     0xc6ae38: bl              #0xd72b80  ; IsType_double?_Stub
    // 0xc6ae3c: ldr             x1, [fp, #0x10]
    // 0xc6ae40: r0 = LoadClassIdInstr(r1)
    //     0xc6ae40: ldur            x0, [x1, #-1]
    //     0xc6ae44: ubfx            x0, x0, #0xc, #0x14
    // 0xc6ae48: r16 = "sensorExposureTime"
    //     0xc6ae48: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b80] "sensorExposureTime"
    //     0xc6ae4c: ldr             x16, [x16, #0xb80]
    // 0xc6ae50: stp             x16, x1, [SP, #-0x10]!
    // 0xc6ae54: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6ae54: sub             lr, x0, #0xef
    //     0xc6ae58: ldr             lr, [x21, lr, lsl #3]
    //     0xc6ae5c: blr             lr
    // 0xc6ae60: add             SP, SP, #0x10
    // 0xc6ae64: mov             x3, x0
    // 0xc6ae68: r2 = Null
    //     0xc6ae68: mov             x2, NULL
    // 0xc6ae6c: r1 = Null
    //     0xc6ae6c: mov             x1, NULL
    // 0xc6ae70: stur            x3, [fp, #-0x28]
    // 0xc6ae74: branchIfSmi(r0, 0xc6ae9c)
    //     0xc6ae74: tbz             w0, #0, #0xc6ae9c
    // 0xc6ae78: r4 = LoadClassIdInstr(r0)
    //     0xc6ae78: ldur            x4, [x0, #-1]
    //     0xc6ae7c: ubfx            x4, x4, #0xc, #0x14
    // 0xc6ae80: sub             x4, x4, #0x3b
    // 0xc6ae84: cmp             x4, #1
    // 0xc6ae88: b.ls            #0xc6ae9c
    // 0xc6ae8c: r8 = int?
    //     0xc6ae8c: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6ae90: r3 = Null
    //     0xc6ae90: add             x3, PP, #0x54, lsl #12  ; [pp+0x54118] Null
    //     0xc6ae94: ldr             x3, [x3, #0x118]
    // 0xc6ae98: r0 = int?()
    //     0xc6ae98: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6ae9c: ldr             x1, [fp, #0x10]
    // 0xc6aea0: r0 = LoadClassIdInstr(r1)
    //     0xc6aea0: ldur            x0, [x1, #-1]
    //     0xc6aea4: ubfx            x0, x0, #0xc, #0x14
    // 0xc6aea8: r16 = "sensorSensitivity"
    //     0xc6aea8: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b98] "sensorSensitivity"
    //     0xc6aeac: ldr             x16, [x16, #0xb98]
    // 0xc6aeb0: stp             x16, x1, [SP, #-0x10]!
    // 0xc6aeb4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6aeb4: sub             lr, x0, #0xef
    //     0xc6aeb8: ldr             lr, [x21, lr, lsl #3]
    //     0xc6aebc: blr             lr
    // 0xc6aec0: add             SP, SP, #0x10
    // 0xc6aec4: mov             x3, x0
    // 0xc6aec8: r2 = Null
    //     0xc6aec8: mov             x2, NULL
    // 0xc6aecc: r1 = Null
    //     0xc6aecc: mov             x1, NULL
    // 0xc6aed0: stur            x3, [fp, #-0x30]
    // 0xc6aed4: r4 = 59
    //     0xc6aed4: mov             x4, #0x3b
    // 0xc6aed8: branchIfSmi(r0, 0xc6aee4)
    //     0xc6aed8: tbz             w0, #0, #0xc6aee4
    // 0xc6aedc: r4 = LoadClassIdInstr(r0)
    //     0xc6aedc: ldur            x4, [x0, #-1]
    //     0xc6aee0: ubfx            x4, x4, #0xc, #0x14
    // 0xc6aee4: cmp             x4, #0x3d
    // 0xc6aee8: b.eq            #0xc6aefc
    // 0xc6aeec: r8 = double?
    //     0xc6aeec: ldr             x8, [PP, #0x21e0]  ; [pp+0x21e0] Type: double?
    // 0xc6aef0: r3 = Null
    //     0xc6aef0: add             x3, PP, #0x54, lsl #12  ; [pp+0x54128] Null
    //     0xc6aef4: ldr             x3, [x3, #0x128]
    // 0xc6aef8: r0 = double?()
    //     0xc6aef8: bl              #0xd72b80  ; IsType_double?_Stub
    // 0xc6aefc: ldr             x0, [fp, #0x10]
    // 0xc6af00: r1 = LoadClassIdInstr(r0)
    //     0xc6af00: ldur            x1, [x0, #-1]
    //     0xc6af04: ubfx            x1, x1, #0xc, #0x14
    // 0xc6af08: r16 = "planes"
    //     0xc6af08: add             x16, PP, #0x42, lsl #12  ; [pp+0x42f30] "planes"
    //     0xc6af0c: ldr             x16, [x16, #0xf30]
    // 0xc6af10: stp             x16, x0, [SP, #-0x10]!
    // 0xc6af14: mov             x0, x1
    // 0xc6af18: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6af18: sub             lr, x0, #0xef
    //     0xc6af1c: ldr             lr, [x21, lr, lsl #3]
    //     0xc6af20: blr             lr
    // 0xc6af24: add             SP, SP, #0x10
    // 0xc6af28: mov             x3, x0
    // 0xc6af2c: r2 = Null
    //     0xc6af2c: mov             x2, NULL
    // 0xc6af30: r1 = Null
    //     0xc6af30: mov             x1, NULL
    // 0xc6af34: stur            x3, [fp, #-0x38]
    // 0xc6af38: r4 = 59
    //     0xc6af38: mov             x4, #0x3b
    // 0xc6af3c: branchIfSmi(r0, 0xc6af48)
    //     0xc6af3c: tbz             w0, #0, #0xc6af48
    // 0xc6af40: r4 = LoadClassIdInstr(r0)
    //     0xc6af40: ldur            x4, [x0, #-1]
    //     0xc6af44: ubfx            x4, x4, #0xc, #0x14
    // 0xc6af48: sub             x4, x4, #0x59
    // 0xc6af4c: cmp             x4, #2
    // 0xc6af50: b.ls            #0xc6af64
    // 0xc6af54: r8 = List
    //     0xc6af54: ldr             x8, [PP, #0x2248]  ; [pp+0x2248] Type: List
    // 0xc6af58: r3 = Null
    //     0xc6af58: add             x3, PP, #0x54, lsl #12  ; [pp+0x54138] Null
    //     0xc6af5c: ldr             x3, [x3, #0x138]
    // 0xc6af60: r0 = List()
    //     0xc6af60: bl              #0xd74840  ; IsType_List_Stub
    // 0xc6af64: r1 = Function '<anonymous closure>': static.
    //     0xc6af64: add             x1, PP, #0x54, lsl #12  ; [pp+0x54148] AnonymousClosure: static (0xc6b140), in [package:camera_android/src/type_conversion.dart] ::cameraImageFromPlatformData (0xc6acc8)
    //     0xc6af68: ldr             x1, [x1, #0x148]
    // 0xc6af6c: r2 = Null
    //     0xc6af6c: mov             x2, NULL
    // 0xc6af70: r0 = AllocateClosure()
    //     0xc6af70: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6af74: mov             x1, x0
    // 0xc6af78: ldur            x0, [fp, #-0x38]
    // 0xc6af7c: r2 = LoadClassIdInstr(r0)
    //     0xc6af7c: ldur            x2, [x0, #-1]
    //     0xc6af80: ubfx            x2, x2, #0xc, #0x14
    // 0xc6af84: r16 = <CameraImagePlane>
    //     0xc6af84: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bc8] TypeArguments: <CameraImagePlane>
    //     0xc6af88: ldr             x16, [x16, #0xbc8]
    // 0xc6af8c: stp             x0, x16, [SP, #-0x10]!
    // 0xc6af90: SaveReg r1
    //     0xc6af90: str             x1, [SP, #-8]!
    // 0xc6af94: mov             x0, x2
    // 0xc6af98: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6af98: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6af9c: r0 = GDT[cid_x0 + 0xc934]()
    //     0xc6af9c: mov             x17, #0xc934
    //     0xc6afa0: add             lr, x0, x17
    //     0xc6afa4: ldr             lr, [x21, lr, lsl #3]
    //     0xc6afa8: blr             lr
    // 0xc6afac: add             SP, SP, #0x18
    // 0xc6afb0: r16 = <CameraImagePlane>
    //     0xc6afb0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bc8] TypeArguments: <CameraImagePlane>
    //     0xc6afb4: ldr             x16, [x16, #0xbc8]
    // 0xc6afb8: stp             x0, x16, [SP, #-0x10]!
    // 0xc6afbc: r16 = false
    //     0xc6afbc: add             x16, NULL, #0x30  ; false
    // 0xc6afc0: SaveReg r16
    //     0xc6afc0: str             x16, [SP, #-8]!
    // 0xc6afc4: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0xc6afc4: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0xc6afc8: r0 = List.from()
    //     0xc6afc8: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0xc6afcc: add             SP, SP, #0x18
    // 0xc6afd0: r16 = <CameraImagePlane>
    //     0xc6afd0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bc8] TypeArguments: <CameraImagePlane>
    //     0xc6afd4: ldr             x16, [x16, #0xbc8]
    // 0xc6afd8: stp             x0, x16, [SP, #-0x10]!
    // 0xc6afdc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc6afdc: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc6afe0: r0 = makeFixedListUnmodifiable()
    //     0xc6afe0: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0xc6afe4: add             SP, SP, #0x10
    // 0xc6afe8: stur            x0, [fp, #-0x38]
    // 0xc6afec: r0 = CameraImageData()
    //     0xc6afec: bl              #0xc6b054  ; AllocateCameraImageDataStub -> CameraImageData (size=0x2c)
    // 0xc6aff0: ldur            x1, [fp, #-8]
    // 0xc6aff4: StoreField: r0->field_7 = r1
    //     0xc6aff4: stur            w1, [x0, #7]
    // 0xc6aff8: ldur            x1, [fp, #-0x38]
    // 0xc6affc: StoreField: r0->field_1b = r1
    //     0xc6affc: stur            w1, [x0, #0x1b]
    // 0xc6b000: ldur            x1, [fp, #-0x10]
    // 0xc6b004: r2 = LoadInt32Instr(r1)
    //     0xc6b004: sbfx            x2, x1, #1, #0x1f
    //     0xc6b008: tbz             w1, #0, #0xc6b010
    //     0xc6b00c: ldur            x2, [x1, #7]
    // 0xc6b010: StoreField: r0->field_b = r2
    //     0xc6b010: stur            x2, [x0, #0xb]
    // 0xc6b014: ldur            x1, [fp, #-0x18]
    // 0xc6b018: r2 = LoadInt32Instr(r1)
    //     0xc6b018: sbfx            x2, x1, #1, #0x1f
    //     0xc6b01c: tbz             w1, #0, #0xc6b024
    //     0xc6b020: ldur            x2, [x1, #7]
    // 0xc6b024: StoreField: r0->field_13 = r2
    //     0xc6b024: stur            x2, [x0, #0x13]
    // 0xc6b028: ldur            x1, [fp, #-0x20]
    // 0xc6b02c: StoreField: r0->field_1f = r1
    //     0xc6b02c: stur            w1, [x0, #0x1f]
    // 0xc6b030: ldur            x1, [fp, #-0x28]
    // 0xc6b034: StoreField: r0->field_23 = r1
    //     0xc6b034: stur            w1, [x0, #0x23]
    // 0xc6b038: ldur            x1, [fp, #-0x30]
    // 0xc6b03c: StoreField: r0->field_27 = r1
    //     0xc6b03c: stur            w1, [x0, #0x27]
    // 0xc6b040: LeaveFrame
    //     0xc6b040: mov             SP, fp
    //     0xc6b044: ldp             fp, lr, [SP], #0x10
    // 0xc6b048: ret
    //     0xc6b048: ret             
    // 0xc6b04c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6b04c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6b050: b               #0xc6ace0
  }
  static _ _cameraImageFormatFromPlatformData(/* No info */) {
    // ** addr: 0xc6b084, size: 0xb0
    // 0xc6b084: EnterFrame
    //     0xc6b084: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b088: mov             fp, SP
    // 0xc6b08c: AllocStack(0x8)
    //     0xc6b08c: sub             SP, SP, #8
    // 0xc6b090: ldr             x0, [fp, #0x10]
    // 0xc6b094: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6b094: mov             x1, #0x76
    //     0xc6b098: tbz             w0, #0, #0xc6b0a8
    //     0xc6b09c: ldur            x1, [x0, #-1]
    //     0xc6b0a0: ubfx            x1, x1, #0xc, #0x14
    //     0xc6b0a4: lsl             x1, x1, #1
    // 0xc6b0a8: cmp             w1, #0x76
    // 0xc6b0ac: b.ne            #0xc6b108
    // 0xc6b0b0: r1 = LoadInt32Instr(r0)
    //     0xc6b0b0: sbfx            x1, x0, #1, #0x1f
    // 0xc6b0b4: cmp             x1, #0x23
    // 0xc6b0b8: b.gt            #0xc6b0ec
    // 0xc6b0bc: cmp             x1, #0x11
    // 0xc6b0c0: b.gt            #0xc6b0d8
    // 0xc6b0c4: cmp             w0, #0x22
    // 0xc6b0c8: b.ne            #0xc6b108
    // 0xc6b0cc: r1 = Instance_ImageFormatGroup
    //     0xc6b0cc: add             x1, PP, #0x54, lsl #12  ; [pp+0x541b0] Obj!ImageFormatGroup@b66a51
    //     0xc6b0d0: ldr             x1, [x1, #0x1b0]
    // 0xc6b0d4: b               #0xc6b110
    // 0xc6b0d8: cmp             x1, #0x23
    // 0xc6b0dc: b.lt            #0xc6b108
    // 0xc6b0e0: r1 = Instance_ImageFormatGroup
    //     0xc6b0e0: add             x1, PP, #0x53, lsl #12  ; [pp+0x53c48] Obj!ImageFormatGroup@b66a91
    //     0xc6b0e4: ldr             x1, [x1, #0xc48]
    // 0xc6b0e8: b               #0xc6b110
    // 0xc6b0ec: cmp             x1, #0x100
    // 0xc6b0f0: b.lt            #0xc6b108
    // 0xc6b0f4: cmp             w0, #0x200
    // 0xc6b0f8: b.ne            #0xc6b108
    // 0xc6b0fc: r1 = Instance_ImageFormatGroup
    //     0xc6b0fc: add             x1, PP, #0x53, lsl #12  ; [pp+0x53c50] Obj!ImageFormatGroup@b66a71
    //     0xc6b100: ldr             x1, [x1, #0xc50]
    // 0xc6b104: b               #0xc6b110
    // 0xc6b108: r1 = Instance_ImageFormatGroup
    //     0xc6b108: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d3b8] Obj!ImageFormatGroup@b66a31
    //     0xc6b10c: ldr             x1, [x1, #0x3b8]
    // 0xc6b110: stur            x1, [fp, #-8]
    // 0xc6b114: r0 = CameraImageFormat()
    //     0xc6b114: bl              #0xc6b134  ; AllocateCameraImageFormatStub -> CameraImageFormat (size=0x10)
    // 0xc6b118: ldur            x1, [fp, #-8]
    // 0xc6b11c: StoreField: r0->field_7 = r1
    //     0xc6b11c: stur            w1, [x0, #7]
    // 0xc6b120: ldr             x1, [fp, #0x10]
    // 0xc6b124: StoreField: r0->field_b = r1
    //     0xc6b124: stur            w1, [x0, #0xb]
    // 0xc6b128: LeaveFrame
    //     0xc6b128: mov             SP, fp
    //     0xc6b12c: ldp             fp, lr, [SP], #0x10
    // 0xc6b130: ret
    //     0xc6b130: ret             
  }
  [closure] static CameraImagePlane <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xc6b140, size: 0x54
    // 0xc6b140: EnterFrame
    //     0xc6b140: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b144: mov             fp, SP
    // 0xc6b148: CheckStackOverflow
    //     0xc6b148: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6b14c: cmp             SP, x16
    //     0xc6b150: b.ls            #0xc6b18c
    // 0xc6b154: ldr             x0, [fp, #0x10]
    // 0xc6b158: r2 = Null
    //     0xc6b158: mov             x2, NULL
    // 0xc6b15c: r1 = Null
    //     0xc6b15c: mov             x1, NULL
    // 0xc6b160: r8 = Map
    //     0xc6b160: ldr             x8, [PP, #0x2338]  ; [pp+0x2338] Type: Map
    // 0xc6b164: r3 = Null
    //     0xc6b164: add             x3, PP, #0x54, lsl #12  ; [pp+0x54150] Null
    //     0xc6b168: ldr             x3, [x3, #0x150]
    // 0xc6b16c: r0 = Map()
    //     0xc6b16c: bl              #0xd747e8  ; IsType_Map_Stub
    // 0xc6b170: ldr             x16, [fp, #0x10]
    // 0xc6b174: SaveReg r16
    //     0xc6b174: str             x16, [SP, #-8]!
    // 0xc6b178: r0 = _cameraImagePlaneFromPlatformData()
    //     0xc6b178: bl              #0xc6b194  ; [package:camera_android/src/type_conversion.dart] ::_cameraImagePlaneFromPlatformData
    // 0xc6b17c: add             SP, SP, #8
    // 0xc6b180: LeaveFrame
    //     0xc6b180: mov             SP, fp
    //     0xc6b184: ldp             fp, lr, [SP], #0x10
    // 0xc6b188: ret
    //     0xc6b188: ret             
    // 0xc6b18c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6b18c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6b190: b               #0xc6b154
  }
  static _ _cameraImagePlaneFromPlatformData(/* No info */) {
    // ** addr: 0xc6b194, size: 0x250
    // 0xc6b194: EnterFrame
    //     0xc6b194: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b198: mov             fp, SP
    // 0xc6b19c: AllocStack(0x28)
    //     0xc6b19c: sub             SP, SP, #0x28
    // 0xc6b1a0: CheckStackOverflow
    //     0xc6b1a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6b1a4: cmp             SP, x16
    //     0xc6b1a8: b.ls            #0xc6b3dc
    // 0xc6b1ac: ldr             x1, [fp, #0x10]
    // 0xc6b1b0: r0 = LoadClassIdInstr(r1)
    //     0xc6b1b0: ldur            x0, [x1, #-1]
    //     0xc6b1b4: ubfx            x0, x0, #0xc, #0x14
    // 0xc6b1b8: r16 = "bytes"
    //     0xc6b1b8: add             x16, PP, #0x53, lsl #12  ; [pp+0x53be0] "bytes"
    //     0xc6b1bc: ldr             x16, [x16, #0xbe0]
    // 0xc6b1c0: stp             x16, x1, [SP, #-0x10]!
    // 0xc6b1c4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6b1c4: sub             lr, x0, #0xef
    //     0xc6b1c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc6b1cc: blr             lr
    // 0xc6b1d0: add             SP, SP, #0x10
    // 0xc6b1d4: mov             x3, x0
    // 0xc6b1d8: r2 = Null
    //     0xc6b1d8: mov             x2, NULL
    // 0xc6b1dc: r1 = Null
    //     0xc6b1dc: mov             x1, NULL
    // 0xc6b1e0: stur            x3, [fp, #-8]
    // 0xc6b1e4: r4 = 59
    //     0xc6b1e4: mov             x4, #0x3b
    // 0xc6b1e8: branchIfSmi(r0, 0xc6b1f4)
    //     0xc6b1e8: tbz             w0, #0, #0xc6b1f4
    // 0xc6b1ec: r4 = LoadClassIdInstr(r0)
    //     0xc6b1ec: ldur            x4, [x0, #-1]
    //     0xc6b1f0: ubfx            x4, x4, #0xc, #0x14
    // 0xc6b1f4: sub             x4, x4, #0x75
    // 0xc6b1f8: cmp             x4, #3
    // 0xc6b1fc: b.ls            #0xc6b214
    // 0xc6b200: r8 = Uint8List
    //     0xc6b200: add             x8, PP, #8, lsl #12  ; [pp+0x8760] Type: Uint8List
    //     0xc6b204: ldr             x8, [x8, #0x760]
    // 0xc6b208: r3 = Null
    //     0xc6b208: add             x3, PP, #0x54, lsl #12  ; [pp+0x54160] Null
    //     0xc6b20c: ldr             x3, [x3, #0x160]
    // 0xc6b210: r0 = Uint8List()
    //     0xc6b210: bl              #0x4b2828  ; IsType_Uint8List_Stub
    // 0xc6b214: ldr             x1, [fp, #0x10]
    // 0xc6b218: r0 = LoadClassIdInstr(r1)
    //     0xc6b218: ldur            x0, [x1, #-1]
    //     0xc6b21c: ubfx            x0, x0, #0xc, #0x14
    // 0xc6b220: r16 = "bytesPerPixel"
    //     0xc6b220: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bf8] "bytesPerPixel"
    //     0xc6b224: ldr             x16, [x16, #0xbf8]
    // 0xc6b228: stp             x16, x1, [SP, #-0x10]!
    // 0xc6b22c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6b22c: sub             lr, x0, #0xef
    //     0xc6b230: ldr             lr, [x21, lr, lsl #3]
    //     0xc6b234: blr             lr
    // 0xc6b238: add             SP, SP, #0x10
    // 0xc6b23c: mov             x3, x0
    // 0xc6b240: r2 = Null
    //     0xc6b240: mov             x2, NULL
    // 0xc6b244: r1 = Null
    //     0xc6b244: mov             x1, NULL
    // 0xc6b248: stur            x3, [fp, #-0x10]
    // 0xc6b24c: branchIfSmi(r0, 0xc6b274)
    //     0xc6b24c: tbz             w0, #0, #0xc6b274
    // 0xc6b250: r4 = LoadClassIdInstr(r0)
    //     0xc6b250: ldur            x4, [x0, #-1]
    //     0xc6b254: ubfx            x4, x4, #0xc, #0x14
    // 0xc6b258: sub             x4, x4, #0x3b
    // 0xc6b25c: cmp             x4, #1
    // 0xc6b260: b.ls            #0xc6b274
    // 0xc6b264: r8 = int?
    //     0xc6b264: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6b268: r3 = Null
    //     0xc6b268: add             x3, PP, #0x54, lsl #12  ; [pp+0x54170] Null
    //     0xc6b26c: ldr             x3, [x3, #0x170]
    // 0xc6b270: r0 = int?()
    //     0xc6b270: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6b274: ldr             x1, [fp, #0x10]
    // 0xc6b278: r0 = LoadClassIdInstr(r1)
    //     0xc6b278: ldur            x0, [x1, #-1]
    //     0xc6b27c: ubfx            x0, x0, #0xc, #0x14
    // 0xc6b280: r16 = "bytesPerRow"
    //     0xc6b280: add             x16, PP, #0x53, lsl #12  ; [pp+0x53c10] "bytesPerRow"
    //     0xc6b284: ldr             x16, [x16, #0xc10]
    // 0xc6b288: stp             x16, x1, [SP, #-0x10]!
    // 0xc6b28c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6b28c: sub             lr, x0, #0xef
    //     0xc6b290: ldr             lr, [x21, lr, lsl #3]
    //     0xc6b294: blr             lr
    // 0xc6b298: add             SP, SP, #0x10
    // 0xc6b29c: mov             x3, x0
    // 0xc6b2a0: r2 = Null
    //     0xc6b2a0: mov             x2, NULL
    // 0xc6b2a4: r1 = Null
    //     0xc6b2a4: mov             x1, NULL
    // 0xc6b2a8: stur            x3, [fp, #-0x18]
    // 0xc6b2ac: branchIfSmi(r0, 0xc6b2d4)
    //     0xc6b2ac: tbz             w0, #0, #0xc6b2d4
    // 0xc6b2b0: r4 = LoadClassIdInstr(r0)
    //     0xc6b2b0: ldur            x4, [x0, #-1]
    //     0xc6b2b4: ubfx            x4, x4, #0xc, #0x14
    // 0xc6b2b8: sub             x4, x4, #0x3b
    // 0xc6b2bc: cmp             x4, #1
    // 0xc6b2c0: b.ls            #0xc6b2d4
    // 0xc6b2c4: r8 = int
    //     0xc6b2c4: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc6b2c8: r3 = Null
    //     0xc6b2c8: add             x3, PP, #0x54, lsl #12  ; [pp+0x54180] Null
    //     0xc6b2cc: ldr             x3, [x3, #0x180]
    // 0xc6b2d0: r0 = int()
    //     0xc6b2d0: bl              #0xd73714  ; IsType_int_Stub
    // 0xc6b2d4: ldr             x1, [fp, #0x10]
    // 0xc6b2d8: r0 = LoadClassIdInstr(r1)
    //     0xc6b2d8: ldur            x0, [x1, #-1]
    //     0xc6b2dc: ubfx            x0, x0, #0xc, #0x14
    // 0xc6b2e0: r16 = "height"
    //     0xc6b2e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb08] "height"
    //     0xc6b2e4: ldr             x16, [x16, #0xb08]
    // 0xc6b2e8: stp             x16, x1, [SP, #-0x10]!
    // 0xc6b2ec: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6b2ec: sub             lr, x0, #0xef
    //     0xc6b2f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc6b2f4: blr             lr
    // 0xc6b2f8: add             SP, SP, #0x10
    // 0xc6b2fc: mov             x3, x0
    // 0xc6b300: r2 = Null
    //     0xc6b300: mov             x2, NULL
    // 0xc6b304: r1 = Null
    //     0xc6b304: mov             x1, NULL
    // 0xc6b308: stur            x3, [fp, #-0x20]
    // 0xc6b30c: branchIfSmi(r0, 0xc6b334)
    //     0xc6b30c: tbz             w0, #0, #0xc6b334
    // 0xc6b310: r4 = LoadClassIdInstr(r0)
    //     0xc6b310: ldur            x4, [x0, #-1]
    //     0xc6b314: ubfx            x4, x4, #0xc, #0x14
    // 0xc6b318: sub             x4, x4, #0x3b
    // 0xc6b31c: cmp             x4, #1
    // 0xc6b320: b.ls            #0xc6b334
    // 0xc6b324: r8 = int?
    //     0xc6b324: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6b328: r3 = Null
    //     0xc6b328: add             x3, PP, #0x54, lsl #12  ; [pp+0x54190] Null
    //     0xc6b32c: ldr             x3, [x3, #0x190]
    // 0xc6b330: r0 = int?()
    //     0xc6b330: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6b334: ldr             x0, [fp, #0x10]
    // 0xc6b338: r1 = LoadClassIdInstr(r0)
    //     0xc6b338: ldur            x1, [x0, #-1]
    //     0xc6b33c: ubfx            x1, x1, #0xc, #0x14
    // 0xc6b340: r16 = "width"
    //     0xc6b340: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb30] "width"
    //     0xc6b344: ldr             x16, [x16, #0xb30]
    // 0xc6b348: stp             x16, x0, [SP, #-0x10]!
    // 0xc6b34c: mov             x0, x1
    // 0xc6b350: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6b350: sub             lr, x0, #0xef
    //     0xc6b354: ldr             lr, [x21, lr, lsl #3]
    //     0xc6b358: blr             lr
    // 0xc6b35c: add             SP, SP, #0x10
    // 0xc6b360: mov             x3, x0
    // 0xc6b364: r2 = Null
    //     0xc6b364: mov             x2, NULL
    // 0xc6b368: r1 = Null
    //     0xc6b368: mov             x1, NULL
    // 0xc6b36c: stur            x3, [fp, #-0x28]
    // 0xc6b370: branchIfSmi(r0, 0xc6b398)
    //     0xc6b370: tbz             w0, #0, #0xc6b398
    // 0xc6b374: r4 = LoadClassIdInstr(r0)
    //     0xc6b374: ldur            x4, [x0, #-1]
    //     0xc6b378: ubfx            x4, x4, #0xc, #0x14
    // 0xc6b37c: sub             x4, x4, #0x3b
    // 0xc6b380: cmp             x4, #1
    // 0xc6b384: b.ls            #0xc6b398
    // 0xc6b388: r8 = int?
    //     0xc6b388: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6b38c: r3 = Null
    //     0xc6b38c: add             x3, PP, #0x54, lsl #12  ; [pp+0x541a0] Null
    //     0xc6b390: ldr             x3, [x3, #0x1a0]
    // 0xc6b394: r0 = int?()
    //     0xc6b394: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6b398: r0 = CameraImagePlane()
    //     0xc6b398: bl              #0xc6b3e4  ; AllocateCameraImagePlaneStub -> CameraImagePlane (size=0x20)
    // 0xc6b39c: ldur            x1, [fp, #-8]
    // 0xc6b3a0: StoreField: r0->field_7 = r1
    //     0xc6b3a0: stur            w1, [x0, #7]
    // 0xc6b3a4: ldur            x1, [fp, #-0x18]
    // 0xc6b3a8: r2 = LoadInt32Instr(r1)
    //     0xc6b3a8: sbfx            x2, x1, #1, #0x1f
    //     0xc6b3ac: tbz             w1, #0, #0xc6b3b4
    //     0xc6b3b0: ldur            x2, [x1, #7]
    // 0xc6b3b4: StoreField: r0->field_b = r2
    //     0xc6b3b4: stur            x2, [x0, #0xb]
    // 0xc6b3b8: ldur            x1, [fp, #-0x10]
    // 0xc6b3bc: StoreField: r0->field_13 = r1
    //     0xc6b3bc: stur            w1, [x0, #0x13]
    // 0xc6b3c0: ldur            x1, [fp, #-0x20]
    // 0xc6b3c4: StoreField: r0->field_17 = r1
    //     0xc6b3c4: stur            w1, [x0, #0x17]
    // 0xc6b3c8: ldur            x1, [fp, #-0x28]
    // 0xc6b3cc: StoreField: r0->field_1b = r1
    //     0xc6b3cc: stur            w1, [x0, #0x1b]
    // 0xc6b3d0: LeaveFrame
    //     0xc6b3d0: mov             SP, fp
    //     0xc6b3d4: ldp             fp, lr, [SP], #0x10
    // 0xc6b3d8: ret
    //     0xc6b3d8: ret             
    // 0xc6b3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6b3dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6b3e0: b               #0xc6b1ac
  }
}

// lib: , url: package:camera_android/src/utils.dart

// class id: 1048707, size: 0x8
class :: {

  static _ deserializeDeviceOrientation(/* No info */) {
    // ** addr: 0x5a89d0, size: 0x11c
    // 0x5a89d0: EnterFrame
    //     0x5a89d0: stp             fp, lr, [SP, #-0x10]!
    //     0x5a89d4: mov             fp, SP
    // 0x5a89d8: AllocStack(0x8)
    //     0x5a89d8: sub             SP, SP, #8
    // 0x5a89dc: CheckStackOverflow
    //     0x5a89dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a89e0: cmp             SP, x16
    //     0x5a89e4: b.ls            #0x5a8ae4
    // 0x5a89e8: r16 = "portraitUp"
    //     0x5a89e8: ldr             x16, [PP, #0xe20]  ; [pp+0xe20] "portraitUp"
    // 0x5a89ec: ldr             lr, [fp, #0x10]
    // 0x5a89f0: stp             lr, x16, [SP, #-0x10]!
    // 0x5a89f4: r0 = ==()
    //     0x5a89f4: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x5a89f8: add             SP, SP, #0x10
    // 0x5a89fc: tbnz            w0, #4, #0x5a8a10
    // 0x5a8a00: r0 = Instance_DeviceOrientation
    //     0x5a8a00: ldr             x0, [PP, #0xe28]  ; [pp+0xe28] Obj!DeviceOrientation@b64311
    // 0x5a8a04: LeaveFrame
    //     0x5a8a04: mov             SP, fp
    //     0x5a8a08: ldp             fp, lr, [SP], #0x10
    // 0x5a8a0c: ret
    //     0x5a8a0c: ret             
    // 0x5a8a10: r16 = "portraitDown"
    //     0x5a8a10: ldr             x16, [PP, #0xe30]  ; [pp+0xe30] "portraitDown"
    // 0x5a8a14: ldr             lr, [fp, #0x10]
    // 0x5a8a18: stp             lr, x16, [SP, #-0x10]!
    // 0x5a8a1c: r0 = ==()
    //     0x5a8a1c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x5a8a20: add             SP, SP, #0x10
    // 0x5a8a24: tbnz            w0, #4, #0x5a8a38
    // 0x5a8a28: r0 = Instance_DeviceOrientation
    //     0x5a8a28: ldr             x0, [PP, #0xe38]  ; [pp+0xe38] Obj!DeviceOrientation@b642f1
    // 0x5a8a2c: LeaveFrame
    //     0x5a8a2c: mov             SP, fp
    //     0x5a8a30: ldp             fp, lr, [SP], #0x10
    // 0x5a8a34: ret
    //     0x5a8a34: ret             
    // 0x5a8a38: r16 = "landscapeRight"
    //     0x5a8a38: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "landscapeRight"
    // 0x5a8a3c: ldr             lr, [fp, #0x10]
    // 0x5a8a40: stp             lr, x16, [SP, #-0x10]!
    // 0x5a8a44: r0 = ==()
    //     0x5a8a44: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x5a8a48: add             SP, SP, #0x10
    // 0x5a8a4c: tbnz            w0, #4, #0x5a8a60
    // 0x5a8a50: r0 = Instance_DeviceOrientation
    //     0x5a8a50: ldr             x0, [PP, #0xe48]  ; [pp+0xe48] Obj!DeviceOrientation@b642d1
    // 0x5a8a54: LeaveFrame
    //     0x5a8a54: mov             SP, fp
    //     0x5a8a58: ldp             fp, lr, [SP], #0x10
    // 0x5a8a5c: ret
    //     0x5a8a5c: ret             
    // 0x5a8a60: r16 = "landscapeLeft"
    //     0x5a8a60: ldr             x16, [PP, #0xe50]  ; [pp+0xe50] "landscapeLeft"
    // 0x5a8a64: ldr             lr, [fp, #0x10]
    // 0x5a8a68: stp             lr, x16, [SP, #-0x10]!
    // 0x5a8a6c: r0 = ==()
    //     0x5a8a6c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x5a8a70: add             SP, SP, #0x10
    // 0x5a8a74: tbnz            w0, #4, #0x5a8a88
    // 0x5a8a78: r0 = Instance_DeviceOrientation
    //     0x5a8a78: ldr             x0, [PP, #0xe58]  ; [pp+0xe58] Obj!DeviceOrientation@b642b1
    // 0x5a8a7c: LeaveFrame
    //     0x5a8a7c: mov             SP, fp
    //     0x5a8a80: ldp             fp, lr, [SP], #0x10
    // 0x5a8a84: ret
    //     0x5a8a84: ret             
    // 0x5a8a88: ldr             x0, [fp, #0x10]
    // 0x5a8a8c: r1 = Null
    //     0x5a8a8c: mov             x1, NULL
    // 0x5a8a90: r2 = 6
    //     0x5a8a90: mov             x2, #6
    // 0x5a8a94: r0 = AllocateArray()
    //     0x5a8a94: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5a8a98: r17 = "\""
    //     0x5a8a98: ldr             x17, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0x5a8a9c: StoreField: r0->field_f = r17
    //     0x5a8a9c: stur            w17, [x0, #0xf]
    // 0x5a8aa0: ldr             x1, [fp, #0x10]
    // 0x5a8aa4: StoreField: r0->field_13 = r1
    //     0x5a8aa4: stur            w1, [x0, #0x13]
    // 0x5a8aa8: r17 = "\" is not a valid DeviceOrientation value"
    //     0x5a8aa8: ldr             x17, [PP, #0xe68]  ; [pp+0xe68] "\" is not a valid DeviceOrientation value"
    // 0x5a8aac: StoreField: r0->field_17 = r17
    //     0x5a8aac: stur            w17, [x0, #0x17]
    // 0x5a8ab0: SaveReg r0
    //     0x5a8ab0: str             x0, [SP, #-8]!
    // 0x5a8ab4: r0 = _interpolate()
    //     0x5a8ab4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x5a8ab8: add             SP, SP, #8
    // 0x5a8abc: stur            x0, [fp, #-8]
    // 0x5a8ac0: r0 = ArgumentError()
    //     0x5a8ac0: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x5a8ac4: mov             x1, x0
    // 0x5a8ac8: ldur            x0, [fp, #-8]
    // 0x5a8acc: StoreField: r1->field_17 = r0
    //     0x5a8acc: stur            w0, [x1, #0x17]
    // 0x5a8ad0: r0 = false
    //     0x5a8ad0: add             x0, NULL, #0x30  ; false
    // 0x5a8ad4: StoreField: r1->field_b = r0
    //     0x5a8ad4: stur            w0, [x1, #0xb]
    // 0x5a8ad8: mov             x0, x1
    // 0x5a8adc: r0 = Throw()
    //     0x5a8adc: bl              #0xd67e38  ; ThrowStub
    // 0x5a8ae0: brk             #0
    // 0x5a8ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a8ae4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a8ae8: b               #0x5a89e8
  }
  static _ parseCameraLensDirection(/* No info */) {
    // ** addr: 0xc7b608, size: 0xd4
    // 0xc7b608: EnterFrame
    //     0xc7b608: stp             fp, lr, [SP, #-0x10]!
    //     0xc7b60c: mov             fp, SP
    // 0xc7b610: CheckStackOverflow
    //     0xc7b610: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7b614: cmp             SP, x16
    //     0xc7b618: b.ls            #0xc7b6d4
    // 0xc7b61c: r16 = "front"
    //     0xc7b61c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e78] "front"
    //     0xc7b620: ldr             x16, [x16, #0xe78]
    // 0xc7b624: ldr             lr, [fp, #0x10]
    // 0xc7b628: stp             lr, x16, [SP, #-0x10]!
    // 0xc7b62c: r0 = ==()
    //     0xc7b62c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc7b630: add             SP, SP, #0x10
    // 0xc7b634: tbnz            w0, #4, #0xc7b64c
    // 0xc7b638: r0 = Instance_CameraLensDirection
    //     0xc7b638: add             x0, PP, #0x53, lsl #12  ; [pp+0x53e80] Obj!CameraLensDirection@b66c11
    //     0xc7b63c: ldr             x0, [x0, #0xe80]
    // 0xc7b640: LeaveFrame
    //     0xc7b640: mov             SP, fp
    //     0xc7b644: ldp             fp, lr, [SP], #0x10
    // 0xc7b648: ret
    //     0xc7b648: ret             
    // 0xc7b64c: r16 = "back"
    //     0xc7b64c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e88] "back"
    //     0xc7b650: ldr             x16, [x16, #0xe88]
    // 0xc7b654: ldr             lr, [fp, #0x10]
    // 0xc7b658: stp             lr, x16, [SP, #-0x10]!
    // 0xc7b65c: r0 = ==()
    //     0xc7b65c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc7b660: add             SP, SP, #0x10
    // 0xc7b664: tbnz            w0, #4, #0xc7b67c
    // 0xc7b668: r0 = Instance_CameraLensDirection
    //     0xc7b668: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d330] Obj!CameraLensDirection@b66bd1
    //     0xc7b66c: ldr             x0, [x0, #0x330]
    // 0xc7b670: LeaveFrame
    //     0xc7b670: mov             SP, fp
    //     0xc7b674: ldp             fp, lr, [SP], #0x10
    // 0xc7b678: ret
    //     0xc7b678: ret             
    // 0xc7b67c: r16 = "external"
    //     0xc7b67c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e90] "external"
    //     0xc7b680: ldr             x16, [x16, #0xe90]
    // 0xc7b684: ldr             lr, [fp, #0x10]
    // 0xc7b688: stp             lr, x16, [SP, #-0x10]!
    // 0xc7b68c: r0 = ==()
    //     0xc7b68c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc7b690: add             SP, SP, #0x10
    // 0xc7b694: tbnz            w0, #4, #0xc7b6ac
    // 0xc7b698: r0 = Instance_CameraLensDirection
    //     0xc7b698: add             x0, PP, #0x53, lsl #12  ; [pp+0x53e98] Obj!CameraLensDirection@b66bf1
    //     0xc7b69c: ldr             x0, [x0, #0xe98]
    // 0xc7b6a0: LeaveFrame
    //     0xc7b6a0: mov             SP, fp
    //     0xc7b6a4: ldp             fp, lr, [SP], #0x10
    // 0xc7b6a8: ret
    //     0xc7b6a8: ret             
    // 0xc7b6ac: r0 = ArgumentError()
    //     0xc7b6ac: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xc7b6b0: mov             x1, x0
    // 0xc7b6b4: r0 = "Unknown CameraLensDirection value"
    //     0xc7b6b4: add             x0, PP, #0x53, lsl #12  ; [pp+0x53ea0] "Unknown CameraLensDirection value"
    //     0xc7b6b8: ldr             x0, [x0, #0xea0]
    // 0xc7b6bc: StoreField: r1->field_17 = r0
    //     0xc7b6bc: stur            w0, [x1, #0x17]
    // 0xc7b6c0: r0 = false
    //     0xc7b6c0: add             x0, NULL, #0x30  ; false
    // 0xc7b6c4: StoreField: r1->field_b = r0
    //     0xc7b6c4: stur            w0, [x1, #0xb]
    // 0xc7b6c8: mov             x0, x1
    // 0xc7b6cc: r0 = Throw()
    //     0xc7b6cc: bl              #0xd67e38  ; ThrowStub
    // 0xc7b6d0: brk             #0
    // 0xc7b6d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7b6d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7b6d8: b               #0xc7b61c
  }
}

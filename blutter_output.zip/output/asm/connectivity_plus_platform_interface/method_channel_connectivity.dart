// lib: , url: package:connectivity_plus_platform_interface/method_channel_connectivity.dart

// class id: 1048789, size: 0x8
class :: {
}

// class id: 4954, size: 0x10, field offset: 0x8
class MethodChannelConnectivity extends ConnectivityPlatform {
}

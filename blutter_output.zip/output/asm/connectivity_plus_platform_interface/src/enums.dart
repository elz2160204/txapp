// lib: , url: package:connectivity_plus_platform_interface/src/enums.dart

// class id: 1048790, size: 0x8
class :: {
}

// class id: 6015, size: 0x14, field offset: 0x14
enum ConnectivityResult extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb1527c, size: 0x5c
    // 0xb1527c: EnterFrame
    //     0xb1527c: stp             fp, lr, [SP, #-0x10]!
    //     0xb15280: mov             fp, SP
    // 0xb15284: CheckStackOverflow
    //     0xb15284: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15288: cmp             SP, x16
    //     0xb1528c: b.ls            #0xb152d0
    // 0xb15290: r1 = Null
    //     0xb15290: mov             x1, NULL
    // 0xb15294: r2 = 4
    //     0xb15294: mov             x2, #4
    // 0xb15298: r0 = AllocateArray()
    //     0xb15298: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1529c: r17 = "ConnectivityResult."
    //     0xb1529c: add             x17, PP, #0x29, lsl #12  ; [pp+0x292c0] "ConnectivityResult."
    //     0xb152a0: ldr             x17, [x17, #0x2c0]
    // 0xb152a4: StoreField: r0->field_f = r17
    //     0xb152a4: stur            w17, [x0, #0xf]
    // 0xb152a8: ldr             x1, [fp, #0x10]
    // 0xb152ac: LoadField: r2 = r1->field_f
    //     0xb152ac: ldur            w2, [x1, #0xf]
    // 0xb152b0: DecompressPointer r2
    //     0xb152b0: add             x2, x2, HEAP, lsl #32
    // 0xb152b4: StoreField: r0->field_13 = r2
    //     0xb152b4: stur            w2, [x0, #0x13]
    // 0xb152b8: SaveReg r0
    //     0xb152b8: str             x0, [SP, #-8]!
    // 0xb152bc: r0 = _interpolate()
    //     0xb152bc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb152c0: add             SP, SP, #8
    // 0xb152c4: LeaveFrame
    //     0xb152c4: mov             SP, fp
    //     0xb152c8: ldp             fp, lr, [SP], #0x10
    // 0xb152cc: ret
    //     0xb152cc: ret             
    // 0xb152d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb152d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb152d4: b               #0xb15290
  }
}

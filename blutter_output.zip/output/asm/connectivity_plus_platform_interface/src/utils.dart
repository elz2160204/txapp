// lib: , url: package:connectivity_plus_platform_interface/src/utils.dart

// class id: 1048791, size: 0x8
class :: {

  [closure] static ConnectivityResult parseConnectivityResult(dynamic, String) {
    // ** addr: 0xa0fa74, size: 0x38
    // 0xa0fa74: EnterFrame
    //     0xa0fa74: stp             fp, lr, [SP, #-0x10]!
    //     0xa0fa78: mov             fp, SP
    // 0xa0fa7c: CheckStackOverflow
    //     0xa0fa7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0fa80: cmp             SP, x16
    //     0xa0fa84: b.ls            #0xa0faa4
    // 0xa0fa88: ldr             x16, [fp, #0x10]
    // 0xa0fa8c: SaveReg r16
    //     0xa0fa8c: str             x16, [SP, #-8]!
    // 0xa0fa90: r0 = parseConnectivityResult()
    //     0xa0fa90: bl              #0xa0faac  ; [package:connectivity_plus_platform_interface/src/utils.dart] ::parseConnectivityResult
    // 0xa0fa94: add             SP, SP, #8
    // 0xa0fa98: LeaveFrame
    //     0xa0fa98: mov             SP, fp
    //     0xa0fa9c: ldp             fp, lr, [SP], #0x10
    // 0xa0faa0: ret
    //     0xa0faa0: ret             
    // 0xa0faa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0faa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0faa8: b               #0xa0fa88
  }
  static _ parseConnectivityResult(/* No info */) {
    // ** addr: 0xa0faac, size: 0x150
    // 0xa0faac: EnterFrame
    //     0xa0faac: stp             fp, lr, [SP, #-0x10]!
    //     0xa0fab0: mov             fp, SP
    // 0xa0fab4: CheckStackOverflow
    //     0xa0fab4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0fab8: cmp             SP, x16
    //     0xa0fabc: b.ls            #0xa0fbf4
    // 0xa0fac0: r16 = "bluetooth"
    //     0xa0fac0: add             x16, PP, #0x21, lsl #12  ; [pp+0x210a0] "bluetooth"
    //     0xa0fac4: ldr             x16, [x16, #0xa0]
    // 0xa0fac8: ldr             lr, [fp, #0x10]
    // 0xa0facc: stp             lr, x16, [SP, #-0x10]!
    // 0xa0fad0: r0 = ==()
    //     0xa0fad0: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0fad4: add             SP, SP, #0x10
    // 0xa0fad8: tbnz            w0, #4, #0xa0faf0
    // 0xa0fadc: r0 = Instance_ConnectivityResult
    //     0xa0fadc: add             x0, PP, #0x21, lsl #12  ; [pp+0x210a8] Obj!ConnectivityResult@b66911
    //     0xa0fae0: ldr             x0, [x0, #0xa8]
    // 0xa0fae4: LeaveFrame
    //     0xa0fae4: mov             SP, fp
    //     0xa0fae8: ldp             fp, lr, [SP], #0x10
    // 0xa0faec: ret
    //     0xa0faec: ret             
    // 0xa0faf0: r16 = "wifi"
    //     0xa0faf0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21290] "wifi"
    //     0xa0faf4: ldr             x16, [x16, #0x290]
    // 0xa0faf8: ldr             lr, [fp, #0x10]
    // 0xa0fafc: stp             lr, x16, [SP, #-0x10]!
    // 0xa0fb00: r0 = ==()
    //     0xa0fb00: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0fb04: add             SP, SP, #0x10
    // 0xa0fb08: tbnz            w0, #4, #0xa0fb20
    // 0xa0fb0c: r0 = Instance_ConnectivityResult
    //     0xa0fb0c: add             x0, PP, #0x21, lsl #12  ; [pp+0x21078] Obj!ConnectivityResult@b66971
    //     0xa0fb10: ldr             x0, [x0, #0x78]
    // 0xa0fb14: LeaveFrame
    //     0xa0fb14: mov             SP, fp
    //     0xa0fb18: ldp             fp, lr, [SP], #0x10
    // 0xa0fb1c: ret
    //     0xa0fb1c: ret             
    // 0xa0fb20: r16 = "ethernet"
    //     0xa0fb20: add             x16, PP, #0x21, lsl #12  ; [pp+0x21080] "ethernet"
    //     0xa0fb24: ldr             x16, [x16, #0x80]
    // 0xa0fb28: ldr             lr, [fp, #0x10]
    // 0xa0fb2c: stp             lr, x16, [SP, #-0x10]!
    // 0xa0fb30: r0 = ==()
    //     0xa0fb30: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0fb34: add             SP, SP, #0x10
    // 0xa0fb38: tbnz            w0, #4, #0xa0fb50
    // 0xa0fb3c: r0 = Instance_ConnectivityResult
    //     0xa0fb3c: add             x0, PP, #0x21, lsl #12  ; [pp+0x21088] Obj!ConnectivityResult@b66951
    //     0xa0fb40: ldr             x0, [x0, #0x88]
    // 0xa0fb44: LeaveFrame
    //     0xa0fb44: mov             SP, fp
    //     0xa0fb48: ldp             fp, lr, [SP], #0x10
    // 0xa0fb4c: ret
    //     0xa0fb4c: ret             
    // 0xa0fb50: r16 = "mobile"
    //     0xa0fb50: add             x16, PP, #0x21, lsl #12  ; [pp+0x21298] "mobile"
    //     0xa0fb54: ldr             x16, [x16, #0x298]
    // 0xa0fb58: ldr             lr, [fp, #0x10]
    // 0xa0fb5c: stp             lr, x16, [SP, #-0x10]!
    // 0xa0fb60: r0 = ==()
    //     0xa0fb60: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0fb64: add             SP, SP, #0x10
    // 0xa0fb68: tbnz            w0, #4, #0xa0fb80
    // 0xa0fb6c: r0 = Instance_ConnectivityResult
    //     0xa0fb6c: add             x0, PP, #0x21, lsl #12  ; [pp+0x210b0] Obj!ConnectivityResult@b668f1
    //     0xa0fb70: ldr             x0, [x0, #0xb0]
    // 0xa0fb74: LeaveFrame
    //     0xa0fb74: mov             SP, fp
    //     0xa0fb78: ldp             fp, lr, [SP], #0x10
    // 0xa0fb7c: ret
    //     0xa0fb7c: ret             
    // 0xa0fb80: r16 = "vpn"
    //     0xa0fb80: add             x16, PP, #0x21, lsl #12  ; [pp+0x21090] "vpn"
    //     0xa0fb84: ldr             x16, [x16, #0x90]
    // 0xa0fb88: ldr             lr, [fp, #0x10]
    // 0xa0fb8c: stp             lr, x16, [SP, #-0x10]!
    // 0xa0fb90: r0 = ==()
    //     0xa0fb90: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0fb94: add             SP, SP, #0x10
    // 0xa0fb98: tbnz            w0, #4, #0xa0fbb0
    // 0xa0fb9c: r0 = Instance_ConnectivityResult
    //     0xa0fb9c: add             x0, PP, #0x21, lsl #12  ; [pp+0x21098] Obj!ConnectivityResult@b66931
    //     0xa0fba0: ldr             x0, [x0, #0x98]
    // 0xa0fba4: LeaveFrame
    //     0xa0fba4: mov             SP, fp
    //     0xa0fba8: ldp             fp, lr, [SP], #0x10
    // 0xa0fbac: ret
    //     0xa0fbac: ret             
    // 0xa0fbb0: r16 = "other"
    //     0xa0fbb0: add             x16, PP, #0xe, lsl #12  ; [pp+0xeca8] "other"
    //     0xa0fbb4: ldr             x16, [x16, #0xca8]
    // 0xa0fbb8: ldr             lr, [fp, #0x10]
    // 0xa0fbbc: stp             lr, x16, [SP, #-0x10]!
    // 0xa0fbc0: r0 = ==()
    //     0xa0fbc0: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0fbc4: add             SP, SP, #0x10
    // 0xa0fbc8: tbnz            w0, #4, #0xa0fbe0
    // 0xa0fbcc: r0 = Instance_ConnectivityResult
    //     0xa0fbcc: add             x0, PP, #0x21, lsl #12  ; [pp+0x212a0] Obj!ConnectivityResult@b669b1
    //     0xa0fbd0: ldr             x0, [x0, #0x2a0]
    // 0xa0fbd4: LeaveFrame
    //     0xa0fbd4: mov             SP, fp
    //     0xa0fbd8: ldp             fp, lr, [SP], #0x10
    // 0xa0fbdc: ret
    //     0xa0fbdc: ret             
    // 0xa0fbe0: r0 = Instance_ConnectivityResult
    //     0xa0fbe0: add             x0, PP, #0x21, lsl #12  ; [pp+0x21068] Obj!ConnectivityResult@b66991
    //     0xa0fbe4: ldr             x0, [x0, #0x68]
    // 0xa0fbe8: LeaveFrame
    //     0xa0fbe8: mov             SP, fp
    //     0xa0fbec: ldp             fp, lr, [SP], #0x10
    // 0xa0fbf0: ret
    //     0xa0fbf0: ret             
    // 0xa0fbf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0fbf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0fbf8: b               #0xa0fac0
  }
}

// lib: , url: package:connectivity_plus_platform_interface/connectivity_plus_platform_interface.dart

// class id: 1048788, size: 0x8
class :: {
}

// class id: 4953, size: 0x8, field offset: 0x8
abstract class ConnectivityPlatform extends PlatformInterface {

  static late final Object _token; // offset: 0xb0c
  static late ConnectivityPlatform _instance; // offset: 0xb10

  static ConnectivityPlatform _instance() {
    // ** addr: 0xa0fbfc, size: 0x98
    // 0xa0fbfc: EnterFrame
    //     0xa0fbfc: stp             fp, lr, [SP, #-0x10]!
    //     0xa0fc00: mov             fp, SP
    // 0xa0fc04: AllocStack(0x10)
    //     0xa0fc04: sub             SP, SP, #0x10
    // 0xa0fc08: CheckStackOverflow
    //     0xa0fc08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0fc0c: cmp             SP, x16
    //     0xa0fc10: b.ls            #0xa0fc8c
    // 0xa0fc14: r0 = MethodChannelConnectivity()
    //     0xa0fc14: bl              #0xa0fc94  ; AllocateMethodChannelConnectivityStub -> MethodChannelConnectivity (size=0x10)
    // 0xa0fc18: mov             x1, x0
    // 0xa0fc1c: r0 = Instance_EventChannel
    //     0xa0fc1c: ldr             x0, [PP, #0x358]  ; [pp+0x358] Obj!EventChannel@b34a51
    // 0xa0fc20: stur            x1, [fp, #-8]
    // 0xa0fc24: StoreField: r1->field_7 = r0
    //     0xa0fc24: stur            w0, [x1, #7]
    // 0xa0fc28: r0 = InitLateStaticField(0xb0c) // [package:connectivity_plus_platform_interface/connectivity_plus_platform_interface.dart] ConnectivityPlatform::_token
    //     0xa0fc28: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0fc2c: ldr             x0, [x0, #0x1618]
    //     0xa0fc30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0fc34: cmp             w0, w16
    //     0xa0fc38: b.ne            #0xa0fc44
    //     0xa0fc3c: ldr             x2, [PP, #0x350]  ; [pp+0x350] Field <ConnectivityPlatform._token@257483631>: static late final (offset: 0xb0c)
    //     0xa0fc40: bl              #0xd67cdc
    // 0xa0fc44: stur            x0, [fp, #-0x10]
    // 0xa0fc48: r0 = InitLateStaticField(0xa64) // [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::_instanceTokens
    //     0xa0fc48: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0fc4c: ldr             x0, [x0, #0x14c8]
    //     0xa0fc50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0fc54: cmp             w0, w16
    //     0xa0fc58: b.ne            #0xa0fc64
    //     0xa0fc5c: ldr             x2, [PP, #0x170]  ; [pp+0x170] Field <PlatformInterface._instanceTokens@187304592>: static late final (offset: 0xa64)
    //     0xa0fc60: bl              #0xd67cdc
    // 0xa0fc64: ldur            x16, [fp, #-8]
    // 0xa0fc68: stp             x16, x0, [SP, #-0x10]!
    // 0xa0fc6c: ldur            x16, [fp, #-0x10]
    // 0xa0fc70: SaveReg r16
    //     0xa0fc70: str             x16, [SP, #-8]!
    // 0xa0fc74: r0 = []=()
    //     0xa0fc74: bl              #0x4b97f8  ; [dart:core] Expando::[]=
    // 0xa0fc78: add             SP, SP, #0x18
    // 0xa0fc7c: ldur            x0, [fp, #-8]
    // 0xa0fc80: LeaveFrame
    //     0xa0fc80: mov             SP, fp
    //     0xa0fc84: ldp             fp, lr, [SP], #0x10
    // 0xa0fc88: ret
    //     0xa0fc88: ret             
    // 0xa0fc8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0fc8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0fc90: b               #0xa0fc14
  }
  set _ instance=(/* No info */) {
    // ** addr: 0xd6e26c, size: 0x64
    // 0xd6e26c: EnterFrame
    //     0xd6e26c: stp             fp, lr, [SP, #-0x10]!
    //     0xd6e270: mov             fp, SP
    // 0xd6e274: CheckStackOverflow
    //     0xd6e274: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6e278: cmp             SP, x16
    //     0xd6e27c: b.ls            #0xd6e2c8
    // 0xd6e280: r0 = InitLateStaticField(0xb0c) // [package:connectivity_plus_platform_interface/connectivity_plus_platform_interface.dart] ConnectivityPlatform::_token
    //     0xd6e280: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6e284: ldr             x0, [x0, #0x1618]
    //     0xd6e288: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6e28c: cmp             w0, w16
    //     0xd6e290: b.ne            #0xd6e29c
    //     0xd6e294: ldr             x2, [PP, #0x350]  ; [pp+0x350] Field <ConnectivityPlatform._token@257483631>: static late final (offset: 0xb0c)
    //     0xd6e298: bl              #0xd67cdc
    // 0xd6e29c: ldr             x16, [fp, #0x10]
    // 0xd6e2a0: stp             x0, x16, [SP, #-0x10]!
    // 0xd6e2a4: r0 = verifyToken()
    //     0xd6e2a4: bl              #0xd6da00  ; [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::verifyToken
    // 0xd6e2a8: add             SP, SP, #0x10
    // 0xd6e2ac: ldr             x1, [fp, #0x10]
    // 0xd6e2b0: StoreStaticField(0xb10, r1)
    //     0xd6e2b0: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0xd6e2b4: str             x1, [x2, #0x1620]
    // 0xd6e2b8: r0 = Null
    //     0xd6e2b8: mov             x0, NULL
    // 0xd6e2bc: LeaveFrame
    //     0xd6e2bc: mov             SP, fp
    //     0xd6e2c0: ldp             fp, lr, [SP], #0x10
    // 0xd6e2c4: ret
    //     0xd6e2c4: ret             
    // 0xd6e2c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6e2c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6e2cc: b               #0xd6e280
  }
}

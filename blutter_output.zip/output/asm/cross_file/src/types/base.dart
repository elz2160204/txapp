// lib: , url: package:cross_file/src/types/base.dart

// class id: 1048808, size: 0x8
class :: {
}

// class id: 4761, size: 0x8, field offset: 0x8
abstract class XFileBase extends Object {
}

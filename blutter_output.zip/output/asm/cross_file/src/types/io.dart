// lib: , url: package:cross_file/src/types/io.dart

// class id: 1048809, size: 0x8
class :: {
}

// class id: 4762, size: 0x10, field offset: 0x8
class XFile extends XFileBase {

  dynamic length(dynamic) {
    // ** addr: 0x9b22dc, size: 0x30
    // 0x9b22dc: r4 = 0
    //     0x9b22dc: mov             x4, #0
    // 0x9b22e0: r1 = Function 'length':.
    //     0x9b22e0: add             x17, PP, #0x55, lsl #12  ; [pp+0x55ca8] AnonymousClosure: (0x9b22f4), in [package:cross_file/src/types/io.dart] XFile::length (0x9b233c)
    //     0x9b22e4: ldr             x1, [x17, #0xca8]
    // 0x9b22e8: r24 = BuildNonGenericMethodExtractorStub
    //     0x9b22e8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x9b22ec: LoadField: r0 = r24->field_17
    //     0x9b22ec: ldur            x0, [x24, #0x17]
    // 0x9b22f0: br              x0
  }
  [closure] Future<int> length(dynamic) {
    // ** addr: 0x9b22f4, size: 0x48
    // 0x9b22f4: EnterFrame
    //     0x9b22f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9b22f8: mov             fp, SP
    // 0x9b22fc: ldr             x0, [fp, #0x10]
    // 0x9b2300: LoadField: r1 = r0->field_17
    //     0x9b2300: ldur            w1, [x0, #0x17]
    // 0x9b2304: DecompressPointer r1
    //     0x9b2304: add             x1, x1, HEAP, lsl #32
    // 0x9b2308: CheckStackOverflow
    //     0x9b2308: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b230c: cmp             SP, x16
    //     0x9b2310: b.ls            #0x9b2334
    // 0x9b2314: LoadField: r0 = r1->field_f
    //     0x9b2314: ldur            w0, [x1, #0xf]
    // 0x9b2318: DecompressPointer r0
    //     0x9b2318: add             x0, x0, HEAP, lsl #32
    // 0x9b231c: SaveReg r0
    //     0x9b231c: str             x0, [SP, #-8]!
    // 0x9b2320: r0 = length()
    //     0x9b2320: bl              #0x9b233c  ; [package:cross_file/src/types/io.dart] XFile::length
    // 0x9b2324: add             SP, SP, #8
    // 0x9b2328: LeaveFrame
    //     0x9b2328: mov             SP, fp
    //     0x9b232c: ldp             fp, lr, [SP], #0x10
    // 0x9b2330: ret
    //     0x9b2330: ret             
    // 0x9b2334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b2334: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b2338: b               #0x9b2314
  }
  _ length(/* No info */) {
    // ** addr: 0x9b233c, size: 0x40
    // 0x9b233c: EnterFrame
    //     0x9b233c: stp             fp, lr, [SP, #-0x10]!
    //     0x9b2340: mov             fp, SP
    // 0x9b2344: CheckStackOverflow
    //     0x9b2344: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b2348: cmp             SP, x16
    //     0x9b234c: b.ls            #0x9b2374
    // 0x9b2350: ldr             x0, [fp, #0x10]
    // 0x9b2354: LoadField: r1 = r0->field_7
    //     0x9b2354: ldur            w1, [x0, #7]
    // 0x9b2358: DecompressPointer r1
    //     0x9b2358: add             x1, x1, HEAP, lsl #32
    // 0x9b235c: SaveReg r1
    //     0x9b235c: str             x1, [SP, #-8]!
    // 0x9b2360: r0 = length()
    //     0x9b2360: bl              #0xcac350  ; [dart:io] _File::length
    // 0x9b2364: add             SP, SP, #8
    // 0x9b2368: LeaveFrame
    //     0x9b2368: mov             SP, fp
    //     0x9b236c: ldp             fp, lr, [SP], #0x10
    // 0x9b2370: ret
    //     0x9b2370: ret             
    // 0x9b2374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b2374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b2378: b               #0x9b2350
  }
}

// lib: , url: package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart

// class id: 1049024, size: 0x8
class :: {
}

// class id: 4946, size: 0x8, field offset: 0x8
class MethodChannelFFmpegKit extends FFmpegKitPlatform {

  _ ffmpegKitConfigFFmpegExecute(/* No info */) async {
    // ** addr: 0xa35510, size: 0x9c
    // 0xa35510: EnterFrame
    //     0xa35510: stp             fp, lr, [SP, #-0x10]!
    //     0xa35514: mov             fp, SP
    // 0xa35518: AllocStack(0x10)
    //     0xa35518: sub             SP, SP, #0x10
    // 0xa3551c: SetupParameters(MethodChannelFFmpegKit this /* r1, fp-0x10 */)
    //     0xa3551c: stur            NULL, [fp, #-8]
    //     0xa35520: mov             x0, #0
    //     0xa35524: add             x1, fp, w0, sxtw #2
    //     0xa35528: ldr             x1, [x1, #0x10]
    //     0xa3552c: stur            x1, [fp, #-0x10]
    // 0xa35530: CheckStackOverflow
    //     0xa35530: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35534: cmp             SP, x16
    //     0xa35538: b.ls            #0xa355a4
    // 0xa3553c: InitAsync() -> Future<void?>
    //     0xa3553c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa35540: bl              #0x4b92e4
    // 0xa35544: r1 = Null
    //     0xa35544: mov             x1, NULL
    // 0xa35548: r2 = 4
    //     0xa35548: mov             x2, #4
    // 0xa3554c: r0 = AllocateArray()
    //     0xa3554c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa35550: r17 = "sessionId"
    //     0xa35550: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xa35554: ldr             x17, [x17, #0xd10]
    // 0xa35558: StoreField: r0->field_f = r17
    //     0xa35558: stur            w17, [x0, #0xf]
    // 0xa3555c: ldur            x1, [fp, #-0x10]
    // 0xa35560: StoreField: r0->field_13 = r1
    //     0xa35560: stur            w1, [x0, #0x13]
    // 0xa35564: r16 = <String, int?>
    //     0xa35564: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ff98] TypeArguments: <String, int?>
    //     0xa35568: ldr             x16, [x16, #0xf98]
    // 0xa3556c: stp             x0, x16, [SP, #-0x10]!
    // 0xa35570: r0 = Map._fromLiteral()
    //     0xa35570: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa35574: add             SP, SP, #0x10
    // 0xa35578: r16 = <void?>
    //     0xa35578: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xa3557c: r30 = Instance_MethodChannel
    //     0xa3557c: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa35580: ldr             lr, [lr, #0xd18]
    // 0xa35584: stp             lr, x16, [SP, #-0x10]!
    // 0xa35588: r16 = "ffmpegSessionExecute"
    //     0xa35588: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ffc8] "ffmpegSessionExecute"
    //     0xa3558c: ldr             x16, [x16, #0xfc8]
    // 0xa35590: stp             x0, x16, [SP, #-0x10]!
    // 0xa35594: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa35594: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa35598: r0 = invokeMethod()
    //     0xa35598: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa3559c: add             SP, SP, #0x20
    // 0xa355a0: r0 = ReturnAsync()
    //     0xa355a0: b               #0x501858  ; ReturnAsyncStub
    // 0xa355a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa355a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa355a8: b               #0xa3553c
  }
  _ ffmpegKitConfigIsLTSBuild(/* No info */) async {
    // ** addr: 0xa35a1c, size: 0x5c
    // 0xa35a1c: EnterFrame
    //     0xa35a1c: stp             fp, lr, [SP, #-0x10]!
    //     0xa35a20: mov             fp, SP
    // 0xa35a24: AllocStack(0x8)
    //     0xa35a24: sub             SP, SP, #8
    // 0xa35a28: SetupParameters()
    //     0xa35a28: stur            NULL, [fp, #-8]
    // 0xa35a2c: CheckStackOverflow
    //     0xa35a2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35a30: cmp             SP, x16
    //     0xa35a34: b.ls            #0xa35a70
    // 0xa35a38: InitAsync() -> Future<bool?>
    //     0xa35a38: add             x0, PP, #0xe, lsl #12  ; [pp+0xe630] TypeArguments: <bool?>
    //     0xa35a3c: ldr             x0, [x0, #0x630]
    //     0xa35a40: bl              #0x4b92e4
    // 0xa35a44: r16 = <bool>
    //     0xa35a44: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0xa35a48: r30 = Instance_MethodChannel
    //     0xa35a48: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa35a4c: ldr             lr, [lr, #0xd18]
    // 0xa35a50: stp             lr, x16, [SP, #-0x10]!
    // 0xa35a54: r16 = "isLTSBuild"
    //     0xa35a54: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd78] "isLTSBuild"
    //     0xa35a58: ldr             x16, [x16, #0xd78]
    // 0xa35a5c: SaveReg r16
    //     0xa35a5c: str             x16, [SP, #-8]!
    // 0xa35a60: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa35a60: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa35a64: r0 = invokeMethod()
    //     0xa35a64: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa35a68: add             SP, SP, #0x18
    // 0xa35a6c: r0 = ReturnAsync()
    //     0xa35a6c: b               #0x501858  ; ReturnAsyncStub
    // 0xa35a70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35a70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35a74: b               #0xa35a38
  }
  _ ffmpegKitConfigEnableRedirection(/* No info */) async {
    // ** addr: 0xa35ba8, size: 0x58
    // 0xa35ba8: EnterFrame
    //     0xa35ba8: stp             fp, lr, [SP, #-0x10]!
    //     0xa35bac: mov             fp, SP
    // 0xa35bb0: AllocStack(0x8)
    //     0xa35bb0: sub             SP, SP, #8
    // 0xa35bb4: SetupParameters()
    //     0xa35bb4: stur            NULL, [fp, #-8]
    // 0xa35bb8: CheckStackOverflow
    //     0xa35bb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35bbc: cmp             SP, x16
    //     0xa35bc0: b.ls            #0xa35bf8
    // 0xa35bc4: InitAsync() -> Future<void?>
    //     0xa35bc4: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa35bc8: bl              #0x4b92e4
    // 0xa35bcc: r16 = <void?>
    //     0xa35bcc: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xa35bd0: r30 = Instance_MethodChannel
    //     0xa35bd0: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa35bd4: ldr             lr, [lr, #0xd18]
    // 0xa35bd8: stp             lr, x16, [SP, #-0x10]!
    // 0xa35bdc: r16 = "enableRedirection"
    //     0xa35bdc: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fda0] "enableRedirection"
    //     0xa35be0: ldr             x16, [x16, #0xda0]
    // 0xa35be4: SaveReg r16
    //     0xa35be4: str             x16, [SP, #-8]!
    // 0xa35be8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa35be8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa35bec: r0 = invokeMethod()
    //     0xa35bec: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa35bf0: add             SP, SP, #0x18
    // 0xa35bf4: r0 = ReturnAsync()
    //     0xa35bf4: b               #0x501858  ; ReturnAsyncStub
    // 0xa35bf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35bf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35bfc: b               #0xa35bc4
  }
  _ getPackageName(/* No info */) async {
    // ** addr: 0xa35d18, size: 0x58
    // 0xa35d18: EnterFrame
    //     0xa35d18: stp             fp, lr, [SP, #-0x10]!
    //     0xa35d1c: mov             fp, SP
    // 0xa35d20: AllocStack(0x8)
    //     0xa35d20: sub             SP, SP, #8
    // 0xa35d24: SetupParameters()
    //     0xa35d24: stur            NULL, [fp, #-8]
    // 0xa35d28: CheckStackOverflow
    //     0xa35d28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35d2c: cmp             SP, x16
    //     0xa35d30: b.ls            #0xa35d68
    // 0xa35d34: InitAsync() -> Future<String?>
    //     0xa35d34: ldr             x0, [PP, #0x1020]  ; [pp+0x1020] TypeArguments: <String?>
    //     0xa35d38: bl              #0x4b92e4
    // 0xa35d3c: r16 = <String>
    //     0xa35d3c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xa35d40: r30 = Instance_MethodChannel
    //     0xa35d40: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa35d44: ldr             lr, [lr, #0xd18]
    // 0xa35d48: stp             lr, x16, [SP, #-0x10]!
    // 0xa35d4c: r16 = "getPackageName"
    //     0xa35d4c: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fdc0] "getPackageName"
    //     0xa35d50: ldr             x16, [x16, #0xdc0]
    // 0xa35d54: SaveReg r16
    //     0xa35d54: str             x16, [SP, #-8]!
    // 0xa35d58: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa35d58: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa35d5c: r0 = invokeMethod()
    //     0xa35d5c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa35d60: add             SP, SP, #0x18
    // 0xa35d64: r0 = ReturnAsync()
    //     0xa35d64: b               #0x501858  ; ReturnAsyncStub
    // 0xa35d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35d68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35d6c: b               #0xa35d34
  }
  _ archDetectGetArch(/* No info */) async {
    // ** addr: 0xa35f70, size: 0x88
    // 0xa35f70: EnterFrame
    //     0xa35f70: stp             fp, lr, [SP, #-0x10]!
    //     0xa35f74: mov             fp, SP
    // 0xa35f78: AllocStack(0x10)
    //     0xa35f78: sub             SP, SP, #0x10
    // 0xa35f7c: SetupParameters()
    //     0xa35f7c: stur            NULL, [fp, #-8]
    // 0xa35f80: CheckStackOverflow
    //     0xa35f80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35f84: cmp             SP, x16
    //     0xa35f88: b.ls            #0xa35ff0
    // 0xa35f8c: InitAsync() -> Future<String>
    //     0xa35f8c: ldr             x0, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    //     0xa35f90: bl              #0x4b92e4
    // 0xa35f94: r16 = <String>
    //     0xa35f94: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xa35f98: r30 = Instance_MethodChannel
    //     0xa35f98: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa35f9c: ldr             lr, [lr, #0xd18]
    // 0xa35fa0: stp             lr, x16, [SP, #-0x10]!
    // 0xa35fa4: r16 = "getArch"
    //     0xa35fa4: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fde0] "getArch"
    //     0xa35fa8: ldr             x16, [x16, #0xde0]
    // 0xa35fac: SaveReg r16
    //     0xa35fac: str             x16, [SP, #-8]!
    // 0xa35fb0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa35fb0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa35fb4: r0 = invokeMethod()
    //     0xa35fb4: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa35fb8: add             SP, SP, #0x18
    // 0xa35fbc: r1 = Function '<anonymous closure>':.
    //     0xa35fbc: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2fde8] AnonymousClosure: (0xa35ff8), in [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::archDetectGetArch (0xa35f70)
    //     0xa35fc0: ldr             x1, [x1, #0xde8]
    // 0xa35fc4: r2 = Null
    //     0xa35fc4: mov             x2, NULL
    // 0xa35fc8: stur            x0, [fp, #-0x10]
    // 0xa35fcc: r0 = AllocateClosure()
    //     0xa35fcc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa35fd0: r16 = <String>
    //     0xa35fd0: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xa35fd4: ldur            lr, [fp, #-0x10]
    // 0xa35fd8: stp             lr, x16, [SP, #-0x10]!
    // 0xa35fdc: SaveReg r0
    //     0xa35fdc: str             x0, [SP, #-8]!
    // 0xa35fe0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa35fe0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa35fe4: r0 = then()
    //     0xa35fe4: bl              #0xca6124  ; [dart:async] _Future::then
    // 0xa35fe8: add             SP, SP, #0x18
    // 0xa35fec: r0 = ReturnAsync()
    //     0xa35fec: b               #0x501858  ; ReturnAsyncStub
    // 0xa35ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35ff0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35ff4: b               #0xa35f8c
  }
  [closure] String <anonymous closure>(dynamic, String?) {
    // ** addr: 0xa35ff8, size: 0x1c
    // 0xa35ff8: ldr             x1, [SP]
    // 0xa35ffc: cmp             w1, NULL
    // 0xa36000: b.ne            #0xa3600c
    // 0xa36004: r0 = ""
    //     0xa36004: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa36008: b               #0xa36010
    // 0xa3600c: mov             x0, x1
    // 0xa36010: ret
    //     0xa36010: ret             
  }
  _ ffmpegKitConfigGetPlatform(/* No info */) async {
    // ** addr: 0xa3612c, size: 0x58
    // 0xa3612c: EnterFrame
    //     0xa3612c: stp             fp, lr, [SP, #-0x10]!
    //     0xa36130: mov             fp, SP
    // 0xa36134: AllocStack(0x8)
    //     0xa36134: sub             SP, SP, #8
    // 0xa36138: SetupParameters()
    //     0xa36138: stur            NULL, [fp, #-8]
    // 0xa3613c: CheckStackOverflow
    //     0xa3613c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa36140: cmp             SP, x16
    //     0xa36144: b.ls            #0xa3617c
    // 0xa36148: InitAsync() -> Future<String?>
    //     0xa36148: ldr             x0, [PP, #0x1020]  ; [pp+0x1020] TypeArguments: <String?>
    //     0xa3614c: bl              #0x4b92e4
    // 0xa36150: r16 = <String>
    //     0xa36150: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xa36154: r30 = Instance_MethodChannel
    //     0xa36154: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa36158: ldr             lr, [lr, #0xd18]
    // 0xa3615c: stp             lr, x16, [SP, #-0x10]!
    // 0xa36160: r16 = "getPlatform"
    //     0xa36160: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fe00] "getPlatform"
    //     0xa36164: ldr             x16, [x16, #0xe00]
    // 0xa36168: SaveReg r16
    //     0xa36168: str             x16, [SP, #-8]!
    // 0xa3616c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa3616c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa36170: r0 = invokeMethod()
    //     0xa36170: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa36174: add             SP, SP, #0x18
    // 0xa36178: r0 = ReturnAsync()
    //     0xa36178: b               #0x501858  ; ReturnAsyncStub
    // 0xa3617c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3617c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa36180: b               #0xa36148
  }
  _ ffmpegKitConfigSetLogLevel(/* No info */) async {
    // ** addr: 0xa362d4, size: 0xb0
    // 0xa362d4: EnterFrame
    //     0xa362d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa362d8: mov             fp, SP
    // 0xa362dc: AllocStack(0x10)
    //     0xa362dc: sub             SP, SP, #0x10
    // 0xa362e0: SetupParameters(MethodChannelFFmpegKit this /* r1, fp-0x10 */)
    //     0xa362e0: stur            NULL, [fp, #-8]
    //     0xa362e4: mov             x0, #0
    //     0xa362e8: add             x1, fp, w0, sxtw #2
    //     0xa362ec: ldr             x1, [x1, #0x10]
    //     0xa362f0: stur            x1, [fp, #-0x10]
    // 0xa362f4: CheckStackOverflow
    //     0xa362f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa362f8: cmp             SP, x16
    //     0xa362fc: b.ls            #0xa3637c
    // 0xa36300: InitAsync() -> Future<void?>
    //     0xa36300: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa36304: bl              #0x4b92e4
    // 0xa36308: r1 = Null
    //     0xa36308: mov             x1, NULL
    // 0xa3630c: r2 = 4
    //     0xa3630c: mov             x2, #4
    // 0xa36310: r0 = AllocateArray()
    //     0xa36310: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa36314: mov             x2, x0
    // 0xa36318: r17 = "level"
    //     0xa36318: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fe18] "level"
    //     0xa3631c: ldr             x17, [x17, #0xe18]
    // 0xa36320: StoreField: r2->field_f = r17
    //     0xa36320: stur            w17, [x2, #0xf]
    // 0xa36324: ldur            x3, [fp, #-0x10]
    // 0xa36328: r0 = BoxInt64Instr(r3)
    //     0xa36328: sbfiz           x0, x3, #1, #0x1f
    //     0xa3632c: cmp             x3, x0, asr #1
    //     0xa36330: b.eq            #0xa3633c
    //     0xa36334: bl              #0xd69bb8
    //     0xa36338: stur            x3, [x0, #7]
    // 0xa3633c: StoreField: r2->field_13 = r0
    //     0xa3633c: stur            w0, [x2, #0x13]
    // 0xa36340: r16 = <String, int>
    //     0xa36340: ldr             x16, [PP, #0x7b0]  ; [pp+0x7b0] TypeArguments: <String, int>
    // 0xa36344: stp             x2, x16, [SP, #-0x10]!
    // 0xa36348: r0 = Map._fromLiteral()
    //     0xa36348: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa3634c: add             SP, SP, #0x10
    // 0xa36350: r16 = <void?>
    //     0xa36350: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xa36354: r30 = Instance_MethodChannel
    //     0xa36354: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa36358: ldr             lr, [lr, #0xd18]
    // 0xa3635c: stp             lr, x16, [SP, #-0x10]!
    // 0xa36360: r16 = "setLogLevel"
    //     0xa36360: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fe20] "setLogLevel"
    //     0xa36364: ldr             x16, [x16, #0xe20]
    // 0xa36368: stp             x0, x16, [SP, #-0x10]!
    // 0xa3636c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa3636c: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa36370: r0 = invokeMethod()
    //     0xa36370: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa36374: add             SP, SP, #0x20
    // 0xa36378: r0 = ReturnAsync()
    //     0xa36378: b               #0x501858  ; ReturnAsyncStub
    // 0xa3637c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3637c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa36380: b               #0xa36300
  }
  _ ffmpegKitFlutterInitializerGetLogLevel(/* No info */) async {
    // ** addr: 0xa364a4, size: 0x5c
    // 0xa364a4: EnterFrame
    //     0xa364a4: stp             fp, lr, [SP, #-0x10]!
    //     0xa364a8: mov             fp, SP
    // 0xa364ac: AllocStack(0x8)
    //     0xa364ac: sub             SP, SP, #8
    // 0xa364b0: SetupParameters()
    //     0xa364b0: stur            NULL, [fp, #-8]
    // 0xa364b4: CheckStackOverflow
    //     0xa364b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa364b8: cmp             SP, x16
    //     0xa364bc: b.ls            #0xa364f8
    // 0xa364c0: InitAsync() -> Future<int?>
    //     0xa364c0: add             x0, PP, #0x10, lsl #12  ; [pp+0x10fd8] TypeArguments: <int?>
    //     0xa364c4: ldr             x0, [x0, #0xfd8]
    //     0xa364c8: bl              #0x4b92e4
    // 0xa364cc: r16 = <int>
    //     0xa364cc: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xa364d0: r30 = Instance_MethodChannel
    //     0xa364d0: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa364d4: ldr             lr, [lr, #0xd18]
    // 0xa364d8: stp             lr, x16, [SP, #-0x10]!
    // 0xa364dc: r16 = "getLogLevel"
    //     0xa364dc: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fe40] "getLogLevel"
    //     0xa364e0: ldr             x16, [x16, #0xe40]
    // 0xa364e4: SaveReg r16
    //     0xa364e4: str             x16, [SP, #-8]!
    // 0xa364e8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa364e8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa364ec: r0 = invokeMethod()
    //     0xa364ec: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa364f0: add             SP, SP, #0x18
    // 0xa364f4: r0 = ReturnAsync()
    //     0xa364f4: b               #0x501858  ; ReturnAsyncStub
    // 0xa364f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa364f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa364fc: b               #0xa364c0
  }
  _ abstractSessionCreateFFmpegSession(/* No info */) async {
    // ** addr: 0xa369fc, size: 0xa0
    // 0xa369fc: EnterFrame
    //     0xa369fc: stp             fp, lr, [SP, #-0x10]!
    //     0xa36a00: mov             fp, SP
    // 0xa36a04: AllocStack(0x10)
    //     0xa36a04: sub             SP, SP, #0x10
    // 0xa36a08: SetupParameters(MethodChannelFFmpegKit this /* r1, fp-0x10 */)
    //     0xa36a08: stur            NULL, [fp, #-8]
    //     0xa36a0c: mov             x0, #0
    //     0xa36a10: add             x1, fp, w0, sxtw #2
    //     0xa36a14: ldr             x1, [x1, #0x10]
    //     0xa36a18: stur            x1, [fp, #-0x10]
    // 0xa36a1c: CheckStackOverflow
    //     0xa36a1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa36a20: cmp             SP, x16
    //     0xa36a24: b.ls            #0xa36a94
    // 0xa36a28: InitAsync() -> Future<Map?>
    //     0xa36a28: add             x0, PP, #0x30, lsl #12  ; [pp+0x30038] TypeArguments: <Map?>
    //     0xa36a2c: ldr             x0, [x0, #0x38]
    //     0xa36a30: bl              #0x4b92e4
    // 0xa36a34: r1 = Null
    //     0xa36a34: mov             x1, NULL
    // 0xa36a38: r2 = 4
    //     0xa36a38: mov             x2, #4
    // 0xa36a3c: r0 = AllocateArray()
    //     0xa36a3c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa36a40: r17 = "arguments"
    //     0xa36a40: ldr             x17, [PP, #0x36d8]  ; [pp+0x36d8] "arguments"
    // 0xa36a44: StoreField: r0->field_f = r17
    //     0xa36a44: stur            w17, [x0, #0xf]
    // 0xa36a48: ldur            x1, [fp, #-0x10]
    // 0xa36a4c: StoreField: r0->field_13 = r1
    //     0xa36a4c: stur            w1, [x0, #0x13]
    // 0xa36a50: r16 = <String, List<String>>
    //     0xa36a50: add             x16, PP, #0x13, lsl #12  ; [pp+0x13010] TypeArguments: <String, List<String>>
    //     0xa36a54: ldr             x16, [x16, #0x10]
    // 0xa36a58: stp             x0, x16, [SP, #-0x10]!
    // 0xa36a5c: r0 = Map._fromLiteral()
    //     0xa36a5c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa36a60: add             SP, SP, #0x10
    // 0xa36a64: r16 = <Map>
    //     0xa36a64: add             x16, PP, #0x14, lsl #12  ; [pp+0x14cb0] TypeArguments: <Map>
    //     0xa36a68: ldr             x16, [x16, #0xcb0]
    // 0xa36a6c: r30 = Instance_MethodChannel
    //     0xa36a6c: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa36a70: ldr             lr, [lr, #0xd18]
    // 0xa36a74: stp             lr, x16, [SP, #-0x10]!
    // 0xa36a78: r16 = "ffmpegSession"
    //     0xa36a78: add             x16, PP, #0x30, lsl #12  ; [pp+0x30040] "ffmpegSession"
    //     0xa36a7c: ldr             x16, [x16, #0x40]
    // 0xa36a80: stp             x0, x16, [SP, #-0x10]!
    // 0xa36a84: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa36a84: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa36a88: r0 = invokeMethod()
    //     0xa36a88: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa36a8c: add             SP, SP, #0x20
    // 0xa36a90: r0 = ReturnAsync()
    //     0xa36a90: b               #0x501858  ; ReturnAsyncStub
    // 0xa36a94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa36a94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa36a98: b               #0xa36a28
  }
  _ abstractSessionGetReturnCode(/* No info */) async {
    // ** addr: 0xa37828, size: 0xa0
    // 0xa37828: EnterFrame
    //     0xa37828: stp             fp, lr, [SP, #-0x10]!
    //     0xa3782c: mov             fp, SP
    // 0xa37830: AllocStack(0x10)
    //     0xa37830: sub             SP, SP, #0x10
    // 0xa37834: SetupParameters(MethodChannelFFmpegKit this /* r1, fp-0x10 */)
    //     0xa37834: stur            NULL, [fp, #-8]
    //     0xa37838: mov             x0, #0
    //     0xa3783c: add             x1, fp, w0, sxtw #2
    //     0xa37840: ldr             x1, [x1, #0x10]
    //     0xa37844: stur            x1, [fp, #-0x10]
    // 0xa37848: CheckStackOverflow
    //     0xa37848: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3784c: cmp             SP, x16
    //     0xa37850: b.ls            #0xa378c0
    // 0xa37854: InitAsync() -> Future<int?>
    //     0xa37854: add             x0, PP, #0x10, lsl #12  ; [pp+0x10fd8] TypeArguments: <int?>
    //     0xa37858: ldr             x0, [x0, #0xfd8]
    //     0xa3785c: bl              #0x4b92e4
    // 0xa37860: r1 = Null
    //     0xa37860: mov             x1, NULL
    // 0xa37864: r2 = 4
    //     0xa37864: mov             x2, #4
    // 0xa37868: r0 = AllocateArray()
    //     0xa37868: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa3786c: r17 = "sessionId"
    //     0xa3786c: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xa37870: ldr             x17, [x17, #0xd10]
    // 0xa37874: StoreField: r0->field_f = r17
    //     0xa37874: stur            w17, [x0, #0xf]
    // 0xa37878: ldur            x1, [fp, #-0x10]
    // 0xa3787c: StoreField: r0->field_13 = r1
    //     0xa3787c: stur            w1, [x0, #0x13]
    // 0xa37880: r16 = <String, int?>
    //     0xa37880: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ff98] TypeArguments: <String, int?>
    //     0xa37884: ldr             x16, [x16, #0xf98]
    // 0xa37888: stp             x0, x16, [SP, #-0x10]!
    // 0xa3788c: r0 = Map._fromLiteral()
    //     0xa3788c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa37890: add             SP, SP, #0x10
    // 0xa37894: r16 = <int>
    //     0xa37894: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xa37898: r30 = Instance_MethodChannel
    //     0xa37898: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa3789c: ldr             lr, [lr, #0xd18]
    // 0xa378a0: stp             lr, x16, [SP, #-0x10]!
    // 0xa378a4: r16 = "abstractSessionGetReturnCode"
    //     0xa378a4: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ffa0] "abstractSessionGetReturnCode"
    //     0xa378a8: ldr             x16, [x16, #0xfa0]
    // 0xa378ac: stp             x0, x16, [SP, #-0x10]!
    // 0xa378b0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa378b0: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa378b4: r0 = invokeMethod()
    //     0xa378b4: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa378b8: add             SP, SP, #0x20
    // 0xa378bc: r0 = ReturnAsync()
    //     0xa378bc: b               #0x501858  ; ReturnAsyncStub
    // 0xa378c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa378c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa378c4: b               #0xa37854
  }
  _ ffmpegKitCancelSession(/* No info */) async {
    // ** addr: 0xa59ca4, size: 0xb0
    // 0xa59ca4: EnterFrame
    //     0xa59ca4: stp             fp, lr, [SP, #-0x10]!
    //     0xa59ca8: mov             fp, SP
    // 0xa59cac: AllocStack(0x10)
    //     0xa59cac: sub             SP, SP, #0x10
    // 0xa59cb0: SetupParameters(MethodChannelFFmpegKit this /* r1, fp-0x10 */)
    //     0xa59cb0: stur            NULL, [fp, #-8]
    //     0xa59cb4: mov             x0, #0
    //     0xa59cb8: add             x1, fp, w0, sxtw #2
    //     0xa59cbc: ldr             x1, [x1, #0x10]
    //     0xa59cc0: stur            x1, [fp, #-0x10]
    // 0xa59cc4: CheckStackOverflow
    //     0xa59cc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa59cc8: cmp             SP, x16
    //     0xa59ccc: b.ls            #0xa59d4c
    // 0xa59cd0: InitAsync() -> Future<void?>
    //     0xa59cd0: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa59cd4: bl              #0x4b92e4
    // 0xa59cd8: r1 = Null
    //     0xa59cd8: mov             x1, NULL
    // 0xa59cdc: r2 = 4
    //     0xa59cdc: mov             x2, #4
    // 0xa59ce0: r0 = AllocateArray()
    //     0xa59ce0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa59ce4: mov             x2, x0
    // 0xa59ce8: r17 = "sessionId"
    //     0xa59ce8: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xa59cec: ldr             x17, [x17, #0xd10]
    // 0xa59cf0: StoreField: r2->field_f = r17
    //     0xa59cf0: stur            w17, [x2, #0xf]
    // 0xa59cf4: ldur            x3, [fp, #-0x10]
    // 0xa59cf8: r0 = BoxInt64Instr(r3)
    //     0xa59cf8: sbfiz           x0, x3, #1, #0x1f
    //     0xa59cfc: cmp             x3, x0, asr #1
    //     0xa59d00: b.eq            #0xa59d0c
    //     0xa59d04: bl              #0xd69bb8
    //     0xa59d08: stur            x3, [x0, #7]
    // 0xa59d0c: StoreField: r2->field_13 = r0
    //     0xa59d0c: stur            w0, [x2, #0x13]
    // 0xa59d10: r16 = <String, int>
    //     0xa59d10: ldr             x16, [PP, #0x7b0]  ; [pp+0x7b0] TypeArguments: <String, int>
    // 0xa59d14: stp             x2, x16, [SP, #-0x10]!
    // 0xa59d18: r0 = Map._fromLiteral()
    //     0xa59d18: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa59d1c: add             SP, SP, #0x10
    // 0xa59d20: r16 = <void?>
    //     0xa59d20: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xa59d24: r30 = Instance_MethodChannel
    //     0xa59d24: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xa59d28: ldr             lr, [lr, #0xd18]
    // 0xa59d2c: stp             lr, x16, [SP, #-0x10]!
    // 0xa59d30: r16 = "cancelSession"
    //     0xa59d30: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd20] "cancelSession"
    //     0xa59d34: ldr             x16, [x16, #0xd20]
    // 0xa59d38: stp             x0, x16, [SP, #-0x10]!
    // 0xa59d3c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa59d3c: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa59d40: r0 = invokeMethod()
    //     0xa59d40: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa59d44: add             SP, SP, #0x20
    // 0xa59d48: r0 = ReturnAsync()
    //     0xa59d48: b               #0x501858  ; ReturnAsyncStub
    // 0xa59d4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa59d4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa59d50: b               #0xa59cd0
  }
  _ ffmpegKitConfigGetSession(/* No info */) async {
    // ** addr: 0xcb7164, size: 0xb8
    // 0xcb7164: EnterFrame
    //     0xcb7164: stp             fp, lr, [SP, #-0x10]!
    //     0xcb7168: mov             fp, SP
    // 0xcb716c: AllocStack(0x10)
    //     0xcb716c: sub             SP, SP, #0x10
    // 0xcb7170: SetupParameters(MethodChannelFFmpegKit this /* r1, fp-0x10 */)
    //     0xcb7170: stur            NULL, [fp, #-8]
    //     0xcb7174: mov             x0, #0
    //     0xcb7178: add             x1, fp, w0, sxtw #2
    //     0xcb717c: ldr             x1, [x1, #0x10]
    //     0xcb7180: stur            x1, [fp, #-0x10]
    // 0xcb7184: CheckStackOverflow
    //     0xcb7184: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb7188: cmp             SP, x16
    //     0xcb718c: b.ls            #0xcb7214
    // 0xcb7190: InitAsync() -> Future<Map?>
    //     0xcb7190: add             x0, PP, #0x30, lsl #12  ; [pp+0x30038] TypeArguments: <Map?>
    //     0xcb7194: ldr             x0, [x0, #0x38]
    //     0xcb7198: bl              #0x4b92e4
    // 0xcb719c: r1 = Null
    //     0xcb719c: mov             x1, NULL
    // 0xcb71a0: r2 = 4
    //     0xcb71a0: mov             x2, #4
    // 0xcb71a4: r0 = AllocateArray()
    //     0xcb71a4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcb71a8: mov             x2, x0
    // 0xcb71ac: r17 = "sessionId"
    //     0xcb71ac: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xcb71b0: ldr             x17, [x17, #0xd10]
    // 0xcb71b4: StoreField: r2->field_f = r17
    //     0xcb71b4: stur            w17, [x2, #0xf]
    // 0xcb71b8: ldur            x3, [fp, #-0x10]
    // 0xcb71bc: r0 = BoxInt64Instr(r3)
    //     0xcb71bc: sbfiz           x0, x3, #1, #0x1f
    //     0xcb71c0: cmp             x3, x0, asr #1
    //     0xcb71c4: b.eq            #0xcb71d0
    //     0xcb71c8: bl              #0xd69bb8
    //     0xcb71cc: stur            x3, [x0, #7]
    // 0xcb71d0: StoreField: r2->field_13 = r0
    //     0xcb71d0: stur            w0, [x2, #0x13]
    // 0xcb71d4: r16 = <String, int>
    //     0xcb71d4: ldr             x16, [PP, #0x7b0]  ; [pp+0x7b0] TypeArguments: <String, int>
    // 0xcb71d8: stp             x2, x16, [SP, #-0x10]!
    // 0xcb71dc: r0 = Map._fromLiteral()
    //     0xcb71dc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xcb71e0: add             SP, SP, #0x10
    // 0xcb71e4: r16 = <Map>
    //     0xcb71e4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14cb0] TypeArguments: <Map>
    //     0xcb71e8: ldr             x16, [x16, #0xcb0]
    // 0xcb71ec: r30 = Instance_MethodChannel
    //     0xcb71ec: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd18] Obj!MethodChannel@b34dd1
    //     0xcb71f0: ldr             lr, [lr, #0xd18]
    // 0xcb71f4: stp             lr, x16, [SP, #-0x10]!
    // 0xcb71f8: r16 = "getSession"
    //     0xcb71f8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40860] "getSession"
    //     0xcb71fc: ldr             x16, [x16, #0x860]
    // 0xcb7200: stp             x0, x16, [SP, #-0x10]!
    // 0xcb7204: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xcb7204: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xcb7208: r0 = invokeMethod()
    //     0xcb7208: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xcb720c: add             SP, SP, #0x20
    // 0xcb7210: r0 = ReturnAsync()
    //     0xcb7210: b               #0x501858  ; ReturnAsyncStub
    // 0xcb7214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb7214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb7218: b               #0xcb7190
  }
}

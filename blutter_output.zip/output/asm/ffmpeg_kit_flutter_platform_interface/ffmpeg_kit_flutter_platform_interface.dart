// lib: , url: package:ffmpeg_kit_flutter_platform_interface/ffmpeg_kit_flutter_platform_interface.dart

// class id: 1049023, size: 0x8
class :: {
}

// class id: 4945, size: 0x8, field offset: 0x8
abstract class FFmpegKitPlatform extends PlatformInterface {

  static late FFmpegKitPlatform _instance; // offset: 0xc4c
  static late final Object _token; // offset: 0xc48

  static FFmpegKitPlatform _instance() {
    // ** addr: 0xa35db8, size: 0x94
    // 0xa35db8: EnterFrame
    //     0xa35db8: stp             fp, lr, [SP, #-0x10]!
    //     0xa35dbc: mov             fp, SP
    // 0xa35dc0: AllocStack(0x18)
    //     0xa35dc0: sub             SP, SP, #0x18
    // 0xa35dc4: CheckStackOverflow
    //     0xa35dc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35dc8: cmp             SP, x16
    //     0xa35dcc: b.ls            #0xa35e44
    // 0xa35dd0: r0 = InitLateStaticField(0xc48) // [package:ffmpeg_kit_flutter_platform_interface/ffmpeg_kit_flutter_platform_interface.dart] FFmpegKitPlatform::_token
    //     0xa35dd0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa35dd4: ldr             x0, [x0, #0x1890]
    //     0xa35dd8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa35ddc: cmp             w0, w16
    //     0xa35de0: b.ne            #0xa35df0
    //     0xa35de4: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fd88] Field <FFmpegKitPlatform._token@516490792>: static late final (offset: 0xc48)
    //     0xa35de8: ldr             x2, [x2, #0xd88]
    //     0xa35dec: bl              #0xd67cdc
    // 0xa35df0: stur            x0, [fp, #-8]
    // 0xa35df4: r0 = InitLateStaticField(0xa64) // [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::_instanceTokens
    //     0xa35df4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa35df8: ldr             x0, [x0, #0x14c8]
    //     0xa35dfc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa35e00: cmp             w0, w16
    //     0xa35e04: b.ne            #0xa35e10
    //     0xa35e08: ldr             x2, [PP, #0x170]  ; [pp+0x170] Field <PlatformInterface._instanceTokens@187304592>: static late final (offset: 0xa64)
    //     0xa35e0c: bl              #0xd67cdc
    // 0xa35e10: stur            x0, [fp, #-0x10]
    // 0xa35e14: r0 = MethodChannelFFmpegKit()
    //     0xa35e14: bl              #0xa35e4c  ; AllocateMethodChannelFFmpegKitStub -> MethodChannelFFmpegKit (size=0x8)
    // 0xa35e18: stur            x0, [fp, #-0x18]
    // 0xa35e1c: ldur            x16, [fp, #-0x10]
    // 0xa35e20: stp             x0, x16, [SP, #-0x10]!
    // 0xa35e24: ldur            x16, [fp, #-8]
    // 0xa35e28: SaveReg r16
    //     0xa35e28: str             x16, [SP, #-8]!
    // 0xa35e2c: r0 = []=()
    //     0xa35e2c: bl              #0x4b97f8  ; [dart:core] Expando::[]=
    // 0xa35e30: add             SP, SP, #0x18
    // 0xa35e34: ldur            x0, [fp, #-0x18]
    // 0xa35e38: LeaveFrame
    //     0xa35e38: mov             SP, fp
    //     0xa35e3c: ldp             fp, lr, [SP], #0x10
    // 0xa35e40: ret
    //     0xa35e40: ret             
    // 0xa35e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35e48: b               #0xa35dd0
  }
}

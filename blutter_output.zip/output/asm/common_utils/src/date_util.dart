// lib: , url: package:common_utils/src/date_util.dart

// class id: 1048775, size: 0x8
class :: {
}

// class id: 4766, size: 0x8, field offset: 0x8
abstract class DateUtil extends Object {

  static int getNowDateMs() {
    // ** addr: 0x8f92f8, size: 0x40
    // 0x8f92f8: EnterFrame
    //     0x8f92f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8f92fc: mov             fp, SP
    // 0x8f9300: CheckStackOverflow
    //     0x8f9300: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8f9304: cmp             SP, x16
    //     0x8f9308: b.ls            #0x8f9330
    // 0x8f930c: r0 = _getCurrentMicros()
    //     0x8f930c: bl              #0x589be8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8f9310: r1 = LoadInt32Instr(r0)
    //     0x8f9310: sbfx            x1, x0, #1, #0x1f
    //     0x8f9314: tbz             w0, #0, #0x8f931c
    //     0x8f9318: ldur            x1, [x0, #7]
    // 0x8f931c: r2 = 1000
    //     0x8f931c: mov             x2, #0x3e8
    // 0x8f9320: sdiv            x0, x1, x2
    // 0x8f9324: LeaveFrame
    //     0x8f9324: mov             SP, fp
    //     0x8f9328: ldp             fp, lr, [SP], #0x10
    // 0x8f932c: ret
    //     0x8f932c: ret             
    // 0x8f9330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9330: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f9334: b               #0x8f930c
  }
  static String formatDateMs(int) {
    // ** addr: 0xa47190, size: 0x4c
    // 0xa47190: EnterFrame
    //     0xa47190: stp             fp, lr, [SP, #-0x10]!
    //     0xa47194: mov             fp, SP
    // 0xa47198: CheckStackOverflow
    //     0xa47198: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4719c: cmp             SP, x16
    //     0xa471a0: b.ls            #0xa471d4
    // 0xa471a4: ldr             x0, [fp, #0x10]
    // 0xa471a8: SaveReg r0
    //     0xa471a8: str             x0, [SP, #-8]!
    // 0xa471ac: r0 = getDateTimeByMs()
    //     0xa471ac: bl              #0xa477f8  ; [package:common_utils/src/date_util.dart] DateUtil::getDateTimeByMs
    // 0xa471b0: add             SP, SP, #8
    // 0xa471b4: r16 = "yyyy-MM-dd"
    //     0xa471b4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ed48] "yyyy-MM-dd"
    //     0xa471b8: ldr             x16, [x16, #0xd48]
    // 0xa471bc: stp             x16, x0, [SP, #-0x10]!
    // 0xa471c0: r0 = formatDate()
    //     0xa471c0: bl              #0xa471dc  ; [package:common_utils/src/date_util.dart] DateUtil::formatDate
    // 0xa471c4: add             SP, SP, #0x10
    // 0xa471c8: LeaveFrame
    //     0xa471c8: mov             SP, fp
    //     0xa471cc: ldp             fp, lr, [SP], #0x10
    // 0xa471d0: ret
    //     0xa471d0: ret             
    // 0xa471d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa471d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa471d8: b               #0xa471a4
  }
  static _ formatDate(/* No info */) {
    // ** addr: 0xa471dc, size: 0x408
    // 0xa471dc: EnterFrame
    //     0xa471dc: stp             fp, lr, [SP, #-0x10]!
    //     0xa471e0: mov             fp, SP
    // 0xa471e4: AllocStack(0x8)
    //     0xa471e4: sub             SP, SP, #8
    // 0xa471e8: CheckStackOverflow
    //     0xa471e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa471ec: cmp             SP, x16
    //     0xa471f0: b.ls            #0xa475c0
    // 0xa471f4: ldr             x1, [fp, #0x10]
    // 0xa471f8: r0 = LoadClassIdInstr(r1)
    //     0xa471f8: ldur            x0, [x1, #-1]
    //     0xa471fc: ubfx            x0, x0, #0xc, #0x14
    // 0xa47200: r16 = "yy"
    //     0xa47200: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ebf8] "yy"
    //     0xa47204: ldr             x16, [x16, #0xbf8]
    // 0xa47208: stp             x16, x1, [SP, #-0x10]!
    // 0xa4720c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa4720c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa47210: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa47210: sub             lr, x0, #0xffc
    //     0xa47214: ldr             lr, [x21, lr, lsl #3]
    //     0xa47218: blr             lr
    // 0xa4721c: add             SP, SP, #0x10
    // 0xa47220: tbnz            w0, #4, #0xa47334
    // 0xa47224: ldr             x0, [fp, #0x10]
    // 0xa47228: ldr             x16, [fp, #0x18]
    // 0xa4722c: SaveReg r16
    //     0xa4722c: str             x16, [SP, #-8]!
    // 0xa47230: r0 = _parts()
    //     0xa47230: bl              #0x5315d8  ; [dart:core] DateTime::_parts
    // 0xa47234: add             SP, SP, #8
    // 0xa47238: mov             x2, x0
    // 0xa4723c: LoadField: r0 = r2->field_b
    //     0xa4723c: ldur            w0, [x2, #0xb]
    // 0xa47240: DecompressPointer r0
    //     0xa47240: add             x0, x0, HEAP, lsl #32
    // 0xa47244: r1 = LoadInt32Instr(r0)
    //     0xa47244: sbfx            x1, x0, #1, #0x1f
    // 0xa47248: mov             x0, x1
    // 0xa4724c: r1 = 8
    //     0xa4724c: mov             x1, #8
    // 0xa47250: cmp             x1, x0
    // 0xa47254: b.hs            #0xa475c8
    // 0xa47258: LoadField: r0 = r2->field_2f
    //     0xa47258: ldur            w0, [x2, #0x2f]
    // 0xa4725c: DecompressPointer r0
    //     0xa4725c: add             x0, x0, HEAP, lsl #32
    // 0xa47260: r1 = 59
    //     0xa47260: mov             x1, #0x3b
    // 0xa47264: branchIfSmi(r0, 0xa47270)
    //     0xa47264: tbz             w0, #0, #0xa47270
    // 0xa47268: r1 = LoadClassIdInstr(r0)
    //     0xa47268: ldur            x1, [x0, #-1]
    //     0xa4726c: ubfx            x1, x1, #0xc, #0x14
    // 0xa47270: SaveReg r0
    //     0xa47270: str             x0, [SP, #-8]!
    // 0xa47274: mov             x0, x1
    // 0xa47278: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa47278: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa4727c: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xa4727c: mov             x17, #0x3f73
    //     0xa47280: add             lr, x0, x17
    //     0xa47284: ldr             lr, [x21, lr, lsl #3]
    //     0xa47288: blr             lr
    // 0xa4728c: add             SP, SP, #8
    // 0xa47290: mov             x2, x0
    // 0xa47294: ldr             x1, [fp, #0x10]
    // 0xa47298: stur            x2, [fp, #-8]
    // 0xa4729c: r0 = LoadClassIdInstr(r1)
    //     0xa4729c: ldur            x0, [x1, #-1]
    //     0xa472a0: ubfx            x0, x0, #0xc, #0x14
    // 0xa472a4: r16 = "yyyy"
    //     0xa472a4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ec00] "yyyy"
    //     0xa472a8: ldr             x16, [x16, #0xc00]
    // 0xa472ac: stp             x16, x1, [SP, #-0x10]!
    // 0xa472b0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa472b0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa472b4: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa472b4: sub             lr, x0, #0xffc
    //     0xa472b8: ldr             lr, [x21, lr, lsl #3]
    //     0xa472bc: blr             lr
    // 0xa472c0: add             SP, SP, #0x10
    // 0xa472c4: tbnz            w0, #4, #0xa472ec
    // 0xa472c8: ldr             x16, [fp, #0x10]
    // 0xa472cc: r30 = "yyyy"
    //     0xa472cc: add             lr, PP, #0x3e, lsl #12  ; [pp+0x3ec00] "yyyy"
    //     0xa472d0: ldr             lr, [lr, #0xc00]
    // 0xa472d4: stp             lr, x16, [SP, #-0x10]!
    // 0xa472d8: ldur            x16, [fp, #-8]
    // 0xa472dc: SaveReg r16
    //     0xa472dc: str             x16, [SP, #-8]!
    // 0xa472e0: r0 = replaceAll()
    //     0xa472e0: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0xa472e4: add             SP, SP, #0x18
    // 0xa472e8: b               #0xa47338
    // 0xa472ec: ldur            x0, [fp, #-8]
    // 0xa472f0: LoadField: r1 = r0->field_7
    //     0xa472f0: ldur            w1, [x0, #7]
    // 0xa472f4: DecompressPointer r1
    //     0xa472f4: add             x1, x1, HEAP, lsl #32
    // 0xa472f8: r2 = LoadInt32Instr(r1)
    //     0xa472f8: sbfx            x2, x1, #1, #0x1f
    // 0xa472fc: sub             x3, x2, #2
    // 0xa47300: stp             x3, x0, [SP, #-0x10]!
    // 0xa47304: SaveReg r1
    //     0xa47304: str             x1, [SP, #-8]!
    // 0xa47308: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa47308: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa4730c: r0 = substring()
    //     0xa4730c: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xa47310: add             SP, SP, #0x18
    // 0xa47314: ldr             x16, [fp, #0x10]
    // 0xa47318: r30 = "yy"
    //     0xa47318: add             lr, PP, #0x3e, lsl #12  ; [pp+0x3ebf8] "yy"
    //     0xa4731c: ldr             lr, [lr, #0xbf8]
    // 0xa47320: stp             lr, x16, [SP, #-0x10]!
    // 0xa47324: SaveReg r0
    //     0xa47324: str             x0, [SP, #-8]!
    // 0xa47328: r0 = replaceAll()
    //     0xa47328: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0xa4732c: add             SP, SP, #0x18
    // 0xa47330: b               #0xa47338
    // 0xa47334: ldr             x0, [fp, #0x10]
    // 0xa47338: stur            x0, [fp, #-8]
    // 0xa4733c: ldr             x16, [fp, #0x18]
    // 0xa47340: SaveReg r16
    //     0xa47340: str             x16, [SP, #-8]!
    // 0xa47344: r0 = _parts()
    //     0xa47344: bl              #0x5315d8  ; [dart:core] DateTime::_parts
    // 0xa47348: add             SP, SP, #8
    // 0xa4734c: mov             x2, x0
    // 0xa47350: LoadField: r0 = r2->field_b
    //     0xa47350: ldur            w0, [x2, #0xb]
    // 0xa47354: DecompressPointer r0
    //     0xa47354: add             x0, x0, HEAP, lsl #32
    // 0xa47358: r1 = LoadInt32Instr(r0)
    //     0xa47358: sbfx            x1, x0, #1, #0x1f
    // 0xa4735c: mov             x0, x1
    // 0xa47360: r1 = 7
    //     0xa47360: mov             x1, #7
    // 0xa47364: cmp             x1, x0
    // 0xa47368: b.hs            #0xa475cc
    // 0xa4736c: LoadField: r0 = r2->field_2b
    //     0xa4736c: ldur            w0, [x2, #0x2b]
    // 0xa47370: DecompressPointer r0
    //     0xa47370: add             x0, x0, HEAP, lsl #32
    // 0xa47374: r1 = LoadInt32Instr(r0)
    //     0xa47374: sbfx            x1, x0, #1, #0x1f
    //     0xa47378: tbz             w0, #0, #0xa47380
    //     0xa4737c: ldur            x1, [x0, #7]
    // 0xa47380: ldur            x16, [fp, #-8]
    // 0xa47384: stp             x16, x1, [SP, #-0x10]!
    // 0xa47388: r16 = "M"
    //     0xa47388: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "M"
    //     0xa4738c: ldr             x16, [x16, #0x2f0]
    // 0xa47390: r30 = "MM"
    //     0xa47390: add             lr, PP, #0xe, lsl #12  ; [pp+0xef98] "MM"
    //     0xa47394: ldr             lr, [lr, #0xf98]
    // 0xa47398: stp             lr, x16, [SP, #-0x10]!
    // 0xa4739c: r0 = _comFormat()
    //     0xa4739c: bl              #0xa47650  ; [package:common_utils/src/date_util.dart] DateUtil::_comFormat
    // 0xa473a0: add             SP, SP, #0x20
    // 0xa473a4: stur            x0, [fp, #-8]
    // 0xa473a8: ldr             x16, [fp, #0x18]
    // 0xa473ac: SaveReg r16
    //     0xa473ac: str             x16, [SP, #-8]!
    // 0xa473b0: r0 = _parts()
    //     0xa473b0: bl              #0x5315d8  ; [dart:core] DateTime::_parts
    // 0xa473b4: add             SP, SP, #8
    // 0xa473b8: mov             x2, x0
    // 0xa473bc: LoadField: r0 = r2->field_b
    //     0xa473bc: ldur            w0, [x2, #0xb]
    // 0xa473c0: DecompressPointer r0
    //     0xa473c0: add             x0, x0, HEAP, lsl #32
    // 0xa473c4: r1 = LoadInt32Instr(r0)
    //     0xa473c4: sbfx            x1, x0, #1, #0x1f
    // 0xa473c8: mov             x0, x1
    // 0xa473cc: r1 = 5
    //     0xa473cc: mov             x1, #5
    // 0xa473d0: cmp             x1, x0
    // 0xa473d4: b.hs            #0xa475d0
    // 0xa473d8: LoadField: r0 = r2->field_23
    //     0xa473d8: ldur            w0, [x2, #0x23]
    // 0xa473dc: DecompressPointer r0
    //     0xa473dc: add             x0, x0, HEAP, lsl #32
    // 0xa473e0: r1 = LoadInt32Instr(r0)
    //     0xa473e0: sbfx            x1, x0, #1, #0x1f
    //     0xa473e4: tbz             w0, #0, #0xa473ec
    //     0xa473e8: ldur            x1, [x0, #7]
    // 0xa473ec: ldur            x16, [fp, #-8]
    // 0xa473f0: stp             x16, x1, [SP, #-0x10]!
    // 0xa473f4: r16 = "d"
    //     0xa473f4: ldr             x16, [PP, #0x7908]  ; [pp+0x7908] "d"
    // 0xa473f8: r30 = "dd"
    //     0xa473f8: add             lr, PP, #0x3d, lsl #12  ; [pp+0x3d300] "dd"
    //     0xa473fc: ldr             lr, [lr, #0x300]
    // 0xa47400: stp             lr, x16, [SP, #-0x10]!
    // 0xa47404: r0 = _comFormat()
    //     0xa47404: bl              #0xa47650  ; [package:common_utils/src/date_util.dart] DateUtil::_comFormat
    // 0xa47408: add             SP, SP, #0x20
    // 0xa4740c: stur            x0, [fp, #-8]
    // 0xa47410: ldr             x16, [fp, #0x18]
    // 0xa47414: SaveReg r16
    //     0xa47414: str             x16, [SP, #-8]!
    // 0xa47418: r0 = _parts()
    //     0xa47418: bl              #0x5315d8  ; [dart:core] DateTime::_parts
    // 0xa4741c: add             SP, SP, #8
    // 0xa47420: mov             x2, x0
    // 0xa47424: LoadField: r0 = r2->field_b
    //     0xa47424: ldur            w0, [x2, #0xb]
    // 0xa47428: DecompressPointer r0
    //     0xa47428: add             x0, x0, HEAP, lsl #32
    // 0xa4742c: r1 = LoadInt32Instr(r0)
    //     0xa4742c: sbfx            x1, x0, #1, #0x1f
    // 0xa47430: mov             x0, x1
    // 0xa47434: r1 = 4
    //     0xa47434: mov             x1, #4
    // 0xa47438: cmp             x1, x0
    // 0xa4743c: b.hs            #0xa475d4
    // 0xa47440: LoadField: r0 = r2->field_1f
    //     0xa47440: ldur            w0, [x2, #0x1f]
    // 0xa47444: DecompressPointer r0
    //     0xa47444: add             x0, x0, HEAP, lsl #32
    // 0xa47448: r1 = LoadInt32Instr(r0)
    //     0xa47448: sbfx            x1, x0, #1, #0x1f
    //     0xa4744c: tbz             w0, #0, #0xa47454
    //     0xa47450: ldur            x1, [x0, #7]
    // 0xa47454: ldur            x16, [fp, #-8]
    // 0xa47458: stp             x16, x1, [SP, #-0x10]!
    // 0xa4745c: r16 = "H"
    //     0xa4745c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2d0] "H"
    //     0xa47460: ldr             x16, [x16, #0x2d0]
    // 0xa47464: r30 = "HH"
    //     0xa47464: add             lr, PP, #0x3e, lsl #12  ; [pp+0x3ec08] "HH"
    //     0xa47468: ldr             lr, [lr, #0xc08]
    // 0xa4746c: stp             lr, x16, [SP, #-0x10]!
    // 0xa47470: r0 = _comFormat()
    //     0xa47470: bl              #0xa47650  ; [package:common_utils/src/date_util.dart] DateUtil::_comFormat
    // 0xa47474: add             SP, SP, #0x20
    // 0xa47478: stur            x0, [fp, #-8]
    // 0xa4747c: ldr             x16, [fp, #0x18]
    // 0xa47480: SaveReg r16
    //     0xa47480: str             x16, [SP, #-8]!
    // 0xa47484: r0 = _parts()
    //     0xa47484: bl              #0x5315d8  ; [dart:core] DateTime::_parts
    // 0xa47488: add             SP, SP, #8
    // 0xa4748c: mov             x2, x0
    // 0xa47490: LoadField: r0 = r2->field_b
    //     0xa47490: ldur            w0, [x2, #0xb]
    // 0xa47494: DecompressPointer r0
    //     0xa47494: add             x0, x0, HEAP, lsl #32
    // 0xa47498: r1 = LoadInt32Instr(r0)
    //     0xa47498: sbfx            x1, x0, #1, #0x1f
    // 0xa4749c: mov             x0, x1
    // 0xa474a0: r1 = 3
    //     0xa474a0: mov             x1, #3
    // 0xa474a4: cmp             x1, x0
    // 0xa474a8: b.hs            #0xa475d8
    // 0xa474ac: LoadField: r0 = r2->field_1b
    //     0xa474ac: ldur            w0, [x2, #0x1b]
    // 0xa474b0: DecompressPointer r0
    //     0xa474b0: add             x0, x0, HEAP, lsl #32
    // 0xa474b4: r1 = LoadInt32Instr(r0)
    //     0xa474b4: sbfx            x1, x0, #1, #0x1f
    //     0xa474b8: tbz             w0, #0, #0xa474c0
    //     0xa474bc: ldur            x1, [x0, #7]
    // 0xa474c0: ldur            x16, [fp, #-8]
    // 0xa474c4: stp             x16, x1, [SP, #-0x10]!
    // 0xa474c8: r16 = "m"
    //     0xa474c8: ldr             x16, [PP, #0x448]  ; [pp+0x448] "m"
    // 0xa474cc: r30 = "mm"
    //     0xa474cc: add             lr, PP, #0x39, lsl #12  ; [pp+0x39f30] "mm"
    //     0xa474d0: ldr             lr, [lr, #0xf30]
    // 0xa474d4: stp             lr, x16, [SP, #-0x10]!
    // 0xa474d8: r0 = _comFormat()
    //     0xa474d8: bl              #0xa47650  ; [package:common_utils/src/date_util.dart] DateUtil::_comFormat
    // 0xa474dc: add             SP, SP, #0x20
    // 0xa474e0: stur            x0, [fp, #-8]
    // 0xa474e4: ldr             x16, [fp, #0x18]
    // 0xa474e8: SaveReg r16
    //     0xa474e8: str             x16, [SP, #-8]!
    // 0xa474ec: r0 = _parts()
    //     0xa474ec: bl              #0x5315d8  ; [dart:core] DateTime::_parts
    // 0xa474f0: add             SP, SP, #8
    // 0xa474f4: mov             x2, x0
    // 0xa474f8: LoadField: r0 = r2->field_b
    //     0xa474f8: ldur            w0, [x2, #0xb]
    // 0xa474fc: DecompressPointer r0
    //     0xa474fc: add             x0, x0, HEAP, lsl #32
    // 0xa47500: r1 = LoadInt32Instr(r0)
    //     0xa47500: sbfx            x1, x0, #1, #0x1f
    // 0xa47504: mov             x0, x1
    // 0xa47508: r1 = 2
    //     0xa47508: mov             x1, #2
    // 0xa4750c: cmp             x1, x0
    // 0xa47510: b.hs            #0xa475dc
    // 0xa47514: LoadField: r0 = r2->field_17
    //     0xa47514: ldur            w0, [x2, #0x17]
    // 0xa47518: DecompressPointer r0
    //     0xa47518: add             x0, x0, HEAP, lsl #32
    // 0xa4751c: r1 = LoadInt32Instr(r0)
    //     0xa4751c: sbfx            x1, x0, #1, #0x1f
    //     0xa47520: tbz             w0, #0, #0xa47528
    //     0xa47524: ldur            x1, [x0, #7]
    // 0xa47528: ldur            x16, [fp, #-8]
    // 0xa4752c: stp             x16, x1, [SP, #-0x10]!
    // 0xa47530: r16 = "s"
    //     0xa47530: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa47534: r30 = "ss"
    //     0xa47534: add             lr, PP, #0x3e, lsl #12  ; [pp+0x3ec10] "ss"
    //     0xa47538: ldr             lr, [lr, #0xc10]
    // 0xa4753c: stp             lr, x16, [SP, #-0x10]!
    // 0xa47540: r0 = _comFormat()
    //     0xa47540: bl              #0xa47650  ; [package:common_utils/src/date_util.dart] DateUtil::_comFormat
    // 0xa47544: add             SP, SP, #0x20
    // 0xa47548: stur            x0, [fp, #-8]
    // 0xa4754c: ldr             x16, [fp, #0x18]
    // 0xa47550: SaveReg r16
    //     0xa47550: str             x16, [SP, #-8]!
    // 0xa47554: r0 = _parts()
    //     0xa47554: bl              #0x5315d8  ; [dart:core] DateTime::_parts
    // 0xa47558: add             SP, SP, #8
    // 0xa4755c: mov             x2, x0
    // 0xa47560: LoadField: r0 = r2->field_b
    //     0xa47560: ldur            w0, [x2, #0xb]
    // 0xa47564: DecompressPointer r0
    //     0xa47564: add             x0, x0, HEAP, lsl #32
    // 0xa47568: r1 = LoadInt32Instr(r0)
    //     0xa47568: sbfx            x1, x0, #1, #0x1f
    // 0xa4756c: mov             x0, x1
    // 0xa47570: r1 = 1
    //     0xa47570: mov             x1, #1
    // 0xa47574: cmp             x1, x0
    // 0xa47578: b.hs            #0xa475e0
    // 0xa4757c: LoadField: r0 = r2->field_13
    //     0xa4757c: ldur            w0, [x2, #0x13]
    // 0xa47580: DecompressPointer r0
    //     0xa47580: add             x0, x0, HEAP, lsl #32
    // 0xa47584: r1 = LoadInt32Instr(r0)
    //     0xa47584: sbfx            x1, x0, #1, #0x1f
    //     0xa47588: tbz             w0, #0, #0xa47590
    //     0xa4758c: ldur            x1, [x0, #7]
    // 0xa47590: ldur            x16, [fp, #-8]
    // 0xa47594: stp             x16, x1, [SP, #-0x10]!
    // 0xa47598: r16 = "S"
    //     0xa47598: add             x16, PP, #0xf, lsl #12  ; [pp+0xf300] "S"
    //     0xa4759c: ldr             x16, [x16, #0x300]
    // 0xa475a0: r30 = "SSS"
    //     0xa475a0: add             lr, PP, #0x3e, lsl #12  ; [pp+0x3ec18] "SSS"
    //     0xa475a4: ldr             lr, [lr, #0xc18]
    // 0xa475a8: stp             lr, x16, [SP, #-0x10]!
    // 0xa475ac: r0 = _comFormat()
    //     0xa475ac: bl              #0xa47650  ; [package:common_utils/src/date_util.dart] DateUtil::_comFormat
    // 0xa475b0: add             SP, SP, #0x20
    // 0xa475b4: LeaveFrame
    //     0xa475b4: mov             SP, fp
    //     0xa475b8: ldp             fp, lr, [SP], #0x10
    // 0xa475bc: ret
    //     0xa475bc: ret             
    // 0xa475c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa475c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa475c4: b               #0xa471f4
    // 0xa475c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa475c8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa475cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa475cc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa475d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa475d0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa475d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa475d4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa475d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa475d8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa475dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa475dc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa475e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa475e0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ _comFormat(/* No info */) {
    // ** addr: 0xa47650, size: 0x1a8
    // 0xa47650: EnterFrame
    //     0xa47650: stp             fp, lr, [SP, #-0x10]!
    //     0xa47654: mov             fp, SP
    // 0xa47658: CheckStackOverflow
    //     0xa47658: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4765c: cmp             SP, x16
    //     0xa47660: b.ls            #0xa477f0
    // 0xa47664: ldr             x1, [fp, #0x20]
    // 0xa47668: r0 = LoadClassIdInstr(r1)
    //     0xa47668: ldur            x0, [x1, #-1]
    //     0xa4766c: ubfx            x0, x0, #0xc, #0x14
    // 0xa47670: ldr             x16, [fp, #0x18]
    // 0xa47674: stp             x16, x1, [SP, #-0x10]!
    // 0xa47678: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa47678: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa4767c: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa4767c: sub             lr, x0, #0xffc
    //     0xa47680: ldr             lr, [x21, lr, lsl #3]
    //     0xa47684: blr             lr
    // 0xa47688: add             SP, SP, #0x10
    // 0xa4768c: tbnz            w0, #4, #0xa477e0
    // 0xa47690: ldr             x1, [fp, #0x20]
    // 0xa47694: r0 = LoadClassIdInstr(r1)
    //     0xa47694: ldur            x0, [x1, #-1]
    //     0xa47698: ubfx            x0, x0, #0xc, #0x14
    // 0xa4769c: ldr             x16, [fp, #0x10]
    // 0xa476a0: stp             x16, x1, [SP, #-0x10]!
    // 0xa476a4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa476a4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa476a8: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa476a8: sub             lr, x0, #0xffc
    //     0xa476ac: ldr             lr, [x21, lr, lsl #3]
    //     0xa476b0: blr             lr
    // 0xa476b4: add             SP, SP, #0x10
    // 0xa476b8: tbnz            w0, #4, #0xa47774
    // 0xa476bc: ldr             x0, [fp, #0x28]
    // 0xa476c0: cmp             x0, #0xa
    // 0xa476c4: b.ge            #0xa4770c
    // 0xa476c8: r1 = Null
    //     0xa476c8: mov             x1, NULL
    // 0xa476cc: r2 = 4
    //     0xa476cc: mov             x2, #4
    // 0xa476d0: r0 = AllocateArray()
    //     0xa476d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa476d4: mov             x2, x0
    // 0xa476d8: r17 = "0"
    //     0xa476d8: ldr             x17, [PP, #0x3af8]  ; [pp+0x3af8] "0"
    // 0xa476dc: StoreField: r2->field_f = r17
    //     0xa476dc: stur            w17, [x2, #0xf]
    // 0xa476e0: ldr             x3, [fp, #0x28]
    // 0xa476e4: r0 = BoxInt64Instr(r3)
    //     0xa476e4: sbfiz           x0, x3, #1, #0x1f
    //     0xa476e8: cmp             x3, x0, asr #1
    //     0xa476ec: b.eq            #0xa476f8
    //     0xa476f0: bl              #0xd69bb8
    //     0xa476f4: stur            x3, [x0, #7]
    // 0xa476f8: StoreField: r2->field_13 = r0
    //     0xa476f8: stur            w0, [x2, #0x13]
    // 0xa476fc: SaveReg r2
    //     0xa476fc: str             x2, [SP, #-8]!
    // 0xa47700: r0 = _interpolate()
    //     0xa47700: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa47704: add             SP, SP, #8
    // 0xa47708: b               #0xa47754
    // 0xa4770c: mov             x3, x0
    // 0xa47710: r0 = BoxInt64Instr(r3)
    //     0xa47710: sbfiz           x0, x3, #1, #0x1f
    //     0xa47714: cmp             x3, x0, asr #1
    //     0xa47718: b.eq            #0xa47724
    //     0xa4771c: bl              #0xd69bb8
    //     0xa47720: stur            x3, [x0, #7]
    // 0xa47724: r1 = 59
    //     0xa47724: mov             x1, #0x3b
    // 0xa47728: branchIfSmi(r0, 0xa47734)
    //     0xa47728: tbz             w0, #0, #0xa47734
    // 0xa4772c: r1 = LoadClassIdInstr(r0)
    //     0xa4772c: ldur            x1, [x0, #-1]
    //     0xa47730: ubfx            x1, x1, #0xc, #0x14
    // 0xa47734: SaveReg r0
    //     0xa47734: str             x0, [SP, #-8]!
    // 0xa47738: mov             x0, x1
    // 0xa4773c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa4773c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa47740: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xa47740: mov             x17, #0x3f73
    //     0xa47744: add             lr, x0, x17
    //     0xa47748: ldr             lr, [x21, lr, lsl #3]
    //     0xa4774c: blr             lr
    // 0xa47750: add             SP, SP, #8
    // 0xa47754: ldr             x16, [fp, #0x20]
    // 0xa47758: ldr             lr, [fp, #0x10]
    // 0xa4775c: stp             lr, x16, [SP, #-0x10]!
    // 0xa47760: SaveReg r0
    //     0xa47760: str             x0, [SP, #-8]!
    // 0xa47764: r0 = replaceAll()
    //     0xa47764: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0xa47768: add             SP, SP, #0x18
    // 0xa4776c: mov             x1, x0
    // 0xa47770: b               #0xa477d8
    // 0xa47774: ldr             x3, [fp, #0x28]
    // 0xa47778: r0 = BoxInt64Instr(r3)
    //     0xa47778: sbfiz           x0, x3, #1, #0x1f
    //     0xa4777c: cmp             x3, x0, asr #1
    //     0xa47780: b.eq            #0xa4778c
    //     0xa47784: bl              #0xd69bb8
    //     0xa47788: stur            x3, [x0, #7]
    // 0xa4778c: r1 = 59
    //     0xa4778c: mov             x1, #0x3b
    // 0xa47790: branchIfSmi(r0, 0xa4779c)
    //     0xa47790: tbz             w0, #0, #0xa4779c
    // 0xa47794: r1 = LoadClassIdInstr(r0)
    //     0xa47794: ldur            x1, [x0, #-1]
    //     0xa47798: ubfx            x1, x1, #0xc, #0x14
    // 0xa4779c: SaveReg r0
    //     0xa4779c: str             x0, [SP, #-8]!
    // 0xa477a0: mov             x0, x1
    // 0xa477a4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa477a4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa477a8: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xa477a8: mov             x17, #0x3f73
    //     0xa477ac: add             lr, x0, x17
    //     0xa477b0: ldr             lr, [x21, lr, lsl #3]
    //     0xa477b4: blr             lr
    // 0xa477b8: add             SP, SP, #8
    // 0xa477bc: ldr             x16, [fp, #0x20]
    // 0xa477c0: ldr             lr, [fp, #0x18]
    // 0xa477c4: stp             lr, x16, [SP, #-0x10]!
    // 0xa477c8: SaveReg r0
    //     0xa477c8: str             x0, [SP, #-8]!
    // 0xa477cc: r0 = replaceAll()
    //     0xa477cc: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0xa477d0: add             SP, SP, #0x18
    // 0xa477d4: mov             x1, x0
    // 0xa477d8: mov             x0, x1
    // 0xa477dc: b               #0xa477e4
    // 0xa477e0: ldr             x0, [fp, #0x20]
    // 0xa477e4: LeaveFrame
    //     0xa477e4: mov             SP, fp
    //     0xa477e8: ldp             fp, lr, [SP], #0x10
    // 0xa477ec: ret
    //     0xa477ec: ret             
    // 0xa477f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa477f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa477f4: b               #0xa47664
  }
  static _ getDateTimeByMs(/* No info */) {
    // ** addr: 0xa477f8, size: 0x6c
    // 0xa477f8: EnterFrame
    //     0xa477f8: stp             fp, lr, [SP, #-0x10]!
    //     0xa477fc: mov             fp, SP
    // 0xa47800: AllocStack(0x10)
    //     0xa47800: sub             SP, SP, #0x10
    // 0xa47804: CheckStackOverflow
    //     0xa47804: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa47808: cmp             SP, x16
    //     0xa4780c: b.ls            #0xa4785c
    // 0xa47810: ldr             x0, [fp, #0x10]
    // 0xa47814: SaveReg r0
    //     0xa47814: str             x0, [SP, #-8]!
    // 0xa47818: r0 = _validateMilliseconds()
    //     0xa47818: bl              #0x8f5234  ; [dart:core] DateTime::_validateMilliseconds
    // 0xa4781c: add             SP, SP, #8
    // 0xa47820: r16 = 1000
    //     0xa47820: mov             x16, #0x3e8
    // 0xa47824: mul             x1, x0, x16
    // 0xa47828: stur            x1, [fp, #-8]
    // 0xa4782c: r0 = DateTime()
    //     0xa4782c: bl              #0x5321bc  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xa47830: stur            x0, [fp, #-0x10]
    // 0xa47834: SaveReg r0
    //     0xa47834: str             x0, [SP, #-8]!
    // 0xa47838: ldur            x1, [fp, #-8]
    // 0xa4783c: r16 = false
    //     0xa4783c: add             x16, NULL, #0x30  ; false
    // 0xa47840: stp             x16, x1, [SP, #-0x10]!
    // 0xa47844: r0 = DateTime._withValue()
    //     0xa47844: bl              #0x53205c  ; [dart:core] DateTime::DateTime._withValue
    // 0xa47848: add             SP, SP, #0x18
    // 0xa4784c: ldur            x0, [fp, #-0x10]
    // 0xa47850: LeaveFrame
    //     0xa47850: mov             SP, fp
    //     0xa47854: ldp             fp, lr, [SP], #0x10
    // 0xa47858: ret
    //     0xa47858: ret             
    // 0xa4785c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4785c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa47860: b               #0xa47810
  }
  static _ getWeekday(/* No info */) {
    // ** addr: 0xb2f010, size: 0x118
    // 0xb2f010: EnterFrame
    //     0xb2f010: stp             fp, lr, [SP, #-0x10]!
    //     0xb2f014: mov             fp, SP
    // 0xb2f018: CheckStackOverflow
    //     0xb2f018: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2f01c: cmp             SP, x16
    //     0xb2f020: b.ls            #0xb2f11c
    // 0xb2f024: ldr             x16, [fp, #0x10]
    // 0xb2f028: SaveReg r16
    //     0xb2f028: str             x16, [SP, #-8]!
    // 0xb2f02c: r0 = _parts()
    //     0xb2f02c: bl              #0x5315d8  ; [dart:core] DateTime::_parts
    // 0xb2f030: add             SP, SP, #8
    // 0xb2f034: mov             x2, x0
    // 0xb2f038: LoadField: r3 = r2->field_b
    //     0xb2f038: ldur            w3, [x2, #0xb]
    // 0xb2f03c: DecompressPointer r3
    //     0xb2f03c: add             x3, x3, HEAP, lsl #32
    // 0xb2f040: r0 = LoadInt32Instr(r3)
    //     0xb2f040: sbfx            x0, x3, #1, #0x1f
    // 0xb2f044: r1 = 6
    //     0xb2f044: mov             x1, #6
    // 0xb2f048: cmp             x1, x0
    // 0xb2f04c: b.hs            #0xb2f124
    // 0xb2f050: LoadField: r1 = r2->field_27
    //     0xb2f050: ldur            w1, [x2, #0x27]
    // 0xb2f054: DecompressPointer r1
    //     0xb2f054: add             x1, x1, HEAP, lsl #32
    // 0xb2f058: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xb2f058: mov             x2, #0x76
    //     0xb2f05c: tbz             w1, #0, #0xb2f06c
    //     0xb2f060: ldur            x2, [x1, #-1]
    //     0xb2f064: ubfx            x2, x2, #0xc, #0x14
    //     0xb2f068: lsl             x2, x2, #1
    // 0xb2f06c: cmp             w2, #0x76
    // 0xb2f070: b.ne            #0xb2f10c
    // 0xb2f074: r2 = LoadInt32Instr(r1)
    //     0xb2f074: sbfx            x2, x1, #1, #0x1f
    // 0xb2f078: cmp             x2, #4
    // 0xb2f07c: b.gt            #0xb2f0d0
    // 0xb2f080: cmp             x2, #2
    // 0xb2f084: b.gt            #0xb2f0b0
    // 0xb2f088: cmp             x2, #1
    // 0xb2f08c: b.gt            #0xb2f0a4
    // 0xb2f090: cmp             w1, #2
    // 0xb2f094: b.ne            #0xb2f10c
    // 0xb2f098: r0 = "星期一"
    //     0xb2f098: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ebc0] "星期一"
    //     0xb2f09c: ldr             x0, [x0, #0xbc0]
    // 0xb2f0a0: b               #0xb2f110
    // 0xb2f0a4: r0 = "星期二"
    //     0xb2f0a4: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ebc8] "星期二"
    //     0xb2f0a8: ldr             x0, [x0, #0xbc8]
    // 0xb2f0ac: b               #0xb2f110
    // 0xb2f0b0: cmp             x2, #3
    // 0xb2f0b4: b.gt            #0xb2f0c4
    // 0xb2f0b8: r0 = "星期三"
    //     0xb2f0b8: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ebd0] "星期三"
    //     0xb2f0bc: ldr             x0, [x0, #0xbd0]
    // 0xb2f0c0: b               #0xb2f110
    // 0xb2f0c4: r0 = "星期四"
    //     0xb2f0c4: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ebd8] "星期四"
    //     0xb2f0c8: ldr             x0, [x0, #0xbd8]
    // 0xb2f0cc: b               #0xb2f110
    // 0xb2f0d0: cmp             x2, #6
    // 0xb2f0d4: b.gt            #0xb2f0f8
    // 0xb2f0d8: cmp             x2, #5
    // 0xb2f0dc: b.gt            #0xb2f0ec
    // 0xb2f0e0: r0 = "星期五"
    //     0xb2f0e0: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ebe0] "星期五"
    //     0xb2f0e4: ldr             x0, [x0, #0xbe0]
    // 0xb2f0e8: b               #0xb2f110
    // 0xb2f0ec: r0 = "星期六"
    //     0xb2f0ec: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ebe8] "星期六"
    //     0xb2f0f0: ldr             x0, [x0, #0xbe8]
    // 0xb2f0f4: b               #0xb2f110
    // 0xb2f0f8: cmp             w1, #0xe
    // 0xb2f0fc: b.ne            #0xb2f10c
    // 0xb2f100: r0 = "星期日"
    //     0xb2f100: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ebf0] "星期日"
    //     0xb2f104: ldr             x0, [x0, #0xbf0]
    // 0xb2f108: b               #0xb2f110
    // 0xb2f10c: r0 = ""
    //     0xb2f10c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xb2f110: LeaveFrame
    //     0xb2f110: mov             SP, fp
    //     0xb2f114: ldp             fp, lr, [SP], #0x10
    // 0xb2f118: ret
    //     0xb2f118: ret             
    // 0xb2f11c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2f11c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2f120: b               #0xb2f024
    // 0xb2f124: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb2f124: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:common_utils/src/log_util.dart

// class id: 1048778, size: 0x8
class :: {
}

// class id: 4765, size: 0x8, field offset: 0x8
abstract class LogUtil extends Object {

  static late String _tagValue; // offset: 0xb08

  static _ e(/* No info */) {
    // ** addr: 0x526b70, size: 0x88
    // 0x526b70: EnterFrame
    //     0x526b70: stp             fp, lr, [SP, #-0x10]!
    //     0x526b74: mov             fp, SP
    // 0x526b78: mov             x0, x4
    // 0x526b7c: LoadField: r1 = r0->field_13
    //     0x526b7c: ldur            w1, [x0, #0x13]
    // 0x526b80: DecompressPointer r1
    //     0x526b80: add             x1, x1, HEAP, lsl #32
    // 0x526b84: sub             x2, x1, #2
    // 0x526b88: add             x3, fp, w2, sxtw #2
    // 0x526b8c: ldr             x3, [x3, #0x10]
    // 0x526b90: LoadField: r2 = r0->field_1f
    //     0x526b90: ldur            w2, [x0, #0x1f]
    // 0x526b94: DecompressPointer r2
    //     0x526b94: add             x2, x2, HEAP, lsl #32
    // 0x526b98: r16 = "tag"
    //     0x526b98: add             x16, PP, #0xd, lsl #12  ; [pp+0xd418] "tag"
    //     0x526b9c: ldr             x16, [x16, #0x418]
    // 0x526ba0: cmp             w2, w16
    // 0x526ba4: b.ne            #0x526bc4
    // 0x526ba8: LoadField: r2 = r0->field_23
    //     0x526ba8: ldur            w2, [x0, #0x23]
    // 0x526bac: DecompressPointer r2
    //     0x526bac: add             x2, x2, HEAP, lsl #32
    // 0x526bb0: sub             w0, w1, w2
    // 0x526bb4: add             x1, fp, w0, sxtw #2
    // 0x526bb8: ldr             x1, [x1, #8]
    // 0x526bbc: mov             x0, x1
    // 0x526bc0: b               #0x526bc8
    // 0x526bc4: r0 = Null
    //     0x526bc4: mov             x0, NULL
    // 0x526bc8: CheckStackOverflow
    //     0x526bc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x526bcc: cmp             SP, x16
    //     0x526bd0: b.ls            #0x526bf0
    // 0x526bd4: stp             x3, x0, [SP, #-0x10]!
    // 0x526bd8: r0 = _printLog()
    //     0x526bd8: bl              #0x526bf8  ; [package:common_utils/src/log_util.dart] LogUtil::_printLog
    // 0x526bdc: add             SP, SP, #0x10
    // 0x526be0: r0 = Null
    //     0x526be0: mov             x0, NULL
    // 0x526be4: LeaveFrame
    //     0x526be4: mov             SP, fp
    //     0x526be8: ldp             fp, lr, [SP], #0x10
    // 0x526bec: ret
    //     0x526bec: ret             
    // 0x526bf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x526bf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x526bf4: b               #0x526bd4
  }
  static _ _printLog(/* No info */) {
    // ** addr: 0x526bf8, size: 0x338
    // 0x526bf8: EnterFrame
    //     0x526bf8: stp             fp, lr, [SP, #-0x10]!
    //     0x526bfc: mov             fp, SP
    // 0x526c00: AllocStack(0x28)
    //     0x526c00: sub             SP, SP, #0x28
    // 0x526c04: CheckStackOverflow
    //     0x526c04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x526c08: cmp             SP, x16
    //     0x526c0c: b.ls            #0x526f20
    // 0x526c10: ldr             x0, [fp, #0x10]
    // 0x526c14: r1 = 59
    //     0x526c14: mov             x1, #0x3b
    // 0x526c18: branchIfSmi(r0, 0x526c24)
    //     0x526c18: tbz             w0, #0, #0x526c24
    // 0x526c1c: r1 = LoadClassIdInstr(r0)
    //     0x526c1c: ldur            x1, [x0, #-1]
    //     0x526c20: ubfx            x1, x1, #0xc, #0x14
    // 0x526c24: SaveReg r0
    //     0x526c24: str             x0, [SP, #-8]!
    // 0x526c28: mov             x0, x1
    // 0x526c2c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x526c2c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x526c30: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x526c30: mov             x17, #0x3f73
    //     0x526c34: add             lr, x0, x17
    //     0x526c38: ldr             lr, [x21, lr, lsl #3]
    //     0x526c3c: blr             lr
    // 0x526c40: add             SP, SP, #8
    // 0x526c44: mov             x1, x0
    // 0x526c48: ldr             x0, [fp, #0x18]
    // 0x526c4c: stur            x1, [fp, #-8]
    // 0x526c50: cmp             w0, NULL
    // 0x526c54: b.ne            #0x526c80
    // 0x526c58: r0 = InitLateStaticField(0xb08) // [package:common_utils/src/log_util.dart] LogUtil::_tagValue
    //     0x526c58: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x526c5c: ldr             x0, [x0, #0x1610]
    //     0x526c60: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x526c64: cmp             w0, w16
    //     0x526c68: b.ne            #0x526c78
    //     0x526c6c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12c00] Field <LogUtil._tagValue@246306883>: static late (offset: 0xb08)
    //     0x526c70: ldr             x2, [x2, #0xc00]
    //     0x526c74: bl              #0xd67d44
    // 0x526c78: mov             x3, x0
    // 0x526c7c: b               #0x526c84
    // 0x526c80: mov             x3, x0
    // 0x526c84: ldur            x0, [fp, #-8]
    // 0x526c88: stur            x3, [fp, #-0x10]
    // 0x526c8c: LoadField: r1 = r0->field_7
    //     0x526c8c: ldur            w1, [x0, #7]
    // 0x526c90: DecompressPointer r1
    //     0x526c90: add             x1, x1, HEAP, lsl #32
    // 0x526c94: r2 = LoadInt32Instr(r1)
    //     0x526c94: sbfx            x2, x1, #1, #0x1f
    // 0x526c98: cmp             x2, #0x80
    // 0x526c9c: b.gt            #0x526cfc
    // 0x526ca0: r1 = Null
    //     0x526ca0: mov             x1, NULL
    // 0x526ca4: r2 = 8
    //     0x526ca4: mov             x2, #8
    // 0x526ca8: r0 = AllocateArray()
    //     0x526ca8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x526cac: mov             x1, x0
    // 0x526cb0: ldur            x0, [fp, #-0x10]
    // 0x526cb4: StoreField: r1->field_f = r0
    //     0x526cb4: stur            w0, [x1, #0xf]
    // 0x526cb8: r17 = " e "
    //     0x526cb8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c08] " e "
    //     0x526cbc: ldr             x17, [x17, #0xc08]
    // 0x526cc0: StoreField: r1->field_13 = r17
    //     0x526cc0: stur            w17, [x1, #0x13]
    // 0x526cc4: r17 = " "
    //     0x526cc4: ldr             x17, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x526cc8: StoreField: r1->field_17 = r17
    //     0x526cc8: stur            w17, [x1, #0x17]
    // 0x526ccc: ldur            x3, [fp, #-8]
    // 0x526cd0: StoreField: r1->field_1b = r3
    //     0x526cd0: stur            w3, [x1, #0x1b]
    // 0x526cd4: SaveReg r1
    //     0x526cd4: str             x1, [SP, #-8]!
    // 0x526cd8: r0 = _interpolate()
    //     0x526cd8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x526cdc: add             SP, SP, #8
    // 0x526ce0: SaveReg r0
    //     0x526ce0: str             x0, [SP, #-8]!
    // 0x526ce4: r0 = print()
    //     0x526ce4: bl              #0x4ff92c  ; [dart:core] ::print
    // 0x526ce8: add             SP, SP, #8
    // 0x526cec: r0 = Null
    //     0x526cec: mov             x0, NULL
    // 0x526cf0: LeaveFrame
    //     0x526cf0: mov             SP, fp
    //     0x526cf4: ldp             fp, lr, [SP], #0x10
    // 0x526cf8: ret
    //     0x526cf8: ret             
    // 0x526cfc: mov             x16, x3
    // 0x526d00: mov             x3, x0
    // 0x526d04: mov             x0, x16
    // 0x526d08: r1 = Null
    //     0x526d08: mov             x1, NULL
    // 0x526d0c: r2 = 6
    //     0x526d0c: mov             x2, #6
    // 0x526d10: r0 = AllocateArray()
    //     0x526d10: bl              #0xd6987c  ; AllocateArrayStub
    // 0x526d14: mov             x1, x0
    // 0x526d18: ldur            x0, [fp, #-0x10]
    // 0x526d1c: StoreField: r1->field_f = r0
    //     0x526d1c: stur            w0, [x1, #0xf]
    // 0x526d20: r17 = " e "
    //     0x526d20: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c08] " e "
    //     0x526d24: ldr             x17, [x17, #0xc08]
    // 0x526d28: StoreField: r1->field_13 = r17
    //     0x526d28: stur            w17, [x1, #0x13]
    // 0x526d2c: r17 = " — — — — — — — — — — — — — — — — st — — — — — — — — — — — — — — — —"
    //     0x526d2c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c10] " — — — — — — — — — — — — — — — — st — — — — — — — — — — — — — — — —"
    //     0x526d30: ldr             x17, [x17, #0xc10]
    // 0x526d34: StoreField: r1->field_17 = r17
    //     0x526d34: stur            w17, [x1, #0x17]
    // 0x526d38: SaveReg r1
    //     0x526d38: str             x1, [SP, #-8]!
    // 0x526d3c: r0 = _interpolate()
    //     0x526d3c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x526d40: add             SP, SP, #8
    // 0x526d44: SaveReg r0
    //     0x526d44: str             x0, [SP, #-8]!
    // 0x526d48: r0 = print()
    //     0x526d48: bl              #0x4ff92c  ; [dart:core] ::print
    // 0x526d4c: add             SP, SP, #8
    // 0x526d50: ldur            x3, [fp, #-8]
    // 0x526d54: ldur            x0, [fp, #-0x10]
    // 0x526d58: stur            x3, [fp, #-0x20]
    // 0x526d5c: CheckStackOverflow
    //     0x526d5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x526d60: cmp             SP, x16
    //     0x526d64: b.ls            #0x526f28
    // 0x526d68: LoadField: r4 = r3->field_7
    //     0x526d68: ldur            w4, [x3, #7]
    // 0x526d6c: DecompressPointer r4
    //     0x526d6c: add             x4, x4, HEAP, lsl #32
    // 0x526d70: stur            x4, [fp, #-8]
    // 0x526d74: cbz             w4, #0x526ec8
    // 0x526d78: r5 = LoadInt32Instr(r4)
    //     0x526d78: sbfx            x5, x4, #1, #0x1f
    // 0x526d7c: stur            x5, [fp, #-0x18]
    // 0x526d80: cmp             x5, #0x80
    // 0x526d84: b.le            #0x526e70
    // 0x526d88: r1 = Null
    //     0x526d88: mov             x1, NULL
    // 0x526d8c: r2 = 8
    //     0x526d8c: mov             x2, #8
    // 0x526d90: r0 = AllocateArray()
    //     0x526d90: bl              #0xd6987c  ; AllocateArrayStub
    // 0x526d94: mov             x1, x0
    // 0x526d98: ldur            x0, [fp, #-0x10]
    // 0x526d9c: stur            x1, [fp, #-0x28]
    // 0x526da0: StoreField: r1->field_f = r0
    //     0x526da0: stur            w0, [x1, #0xf]
    // 0x526da4: r17 = " e "
    //     0x526da4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c08] " e "
    //     0x526da8: ldr             x17, [x17, #0xc08]
    // 0x526dac: StoreField: r1->field_13 = r17
    //     0x526dac: stur            w17, [x1, #0x13]
    // 0x526db0: r17 = "| "
    //     0x526db0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c18] "| "
    //     0x526db4: ldr             x17, [x17, #0xc18]
    // 0x526db8: StoreField: r1->field_17 = r17
    //     0x526db8: stur            w17, [x1, #0x17]
    // 0x526dbc: r16 = 256
    //     0x526dbc: mov             x16, #0x100
    // 0x526dc0: stp             x16, xzr, [SP, #-0x10]!
    // 0x526dc4: ldur            x2, [fp, #-0x18]
    // 0x526dc8: SaveReg r2
    //     0x526dc8: str             x2, [SP, #-8]!
    // 0x526dcc: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x526dcc: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x526dd0: r0 = checkValidRange()
    //     0x526dd0: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0x526dd4: add             SP, SP, #0x18
    // 0x526dd8: ldur            x16, [fp, #-0x20]
    // 0x526ddc: stp             xzr, x16, [SP, #-0x10]!
    // 0x526de0: SaveReg r0
    //     0x526de0: str             x0, [SP, #-8]!
    // 0x526de4: r0 = _substringUnchecked()
    //     0x526de4: bl              #0x4d0ab0  ; [dart:core] _StringBase::_substringUnchecked
    // 0x526de8: add             SP, SP, #0x18
    // 0x526dec: ldur            x1, [fp, #-0x28]
    // 0x526df0: ArrayStore: r1[3] = r0  ; List_4
    //     0x526df0: add             x25, x1, #0x1b
    //     0x526df4: str             w0, [x25]
    //     0x526df8: tbz             w0, #0, #0x526e14
    //     0x526dfc: ldurb           w16, [x1, #-1]
    //     0x526e00: ldurb           w17, [x0, #-1]
    //     0x526e04: and             x16, x17, x16, lsr #2
    //     0x526e08: tst             x16, HEAP, lsr #32
    //     0x526e0c: b.eq            #0x526e14
    //     0x526e10: bl              #0xd67e5c
    // 0x526e14: ldur            x16, [fp, #-0x28]
    // 0x526e18: SaveReg r16
    //     0x526e18: str             x16, [SP, #-8]!
    // 0x526e1c: r0 = _interpolate()
    //     0x526e1c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x526e20: add             SP, SP, #8
    // 0x526e24: SaveReg r0
    //     0x526e24: str             x0, [SP, #-8]!
    // 0x526e28: r0 = printToConsole()
    //     0x526e28: bl              #0x4ffa98  ; [dart:_internal] ::printToConsole
    // 0x526e2c: add             SP, SP, #8
    // 0x526e30: r16 = 256
    //     0x526e30: mov             x16, #0x100
    // 0x526e34: ldur            lr, [fp, #-8]
    // 0x526e38: stp             lr, x16, [SP, #-0x10]!
    // 0x526e3c: ldur            x0, [fp, #-0x18]
    // 0x526e40: SaveReg r0
    //     0x526e40: str             x0, [SP, #-8]!
    // 0x526e44: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x526e44: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x526e48: r0 = checkValidRange()
    //     0x526e48: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0x526e4c: add             SP, SP, #0x18
    // 0x526e50: ldur            x16, [fp, #-0x20]
    // 0x526e54: r30 = 256
    //     0x526e54: mov             lr, #0x100
    // 0x526e58: stp             lr, x16, [SP, #-0x10]!
    // 0x526e5c: SaveReg r0
    //     0x526e5c: str             x0, [SP, #-8]!
    // 0x526e60: r0 = _substringUnchecked()
    //     0x526e60: bl              #0x4d0ab0  ; [dart:core] _StringBase::_substringUnchecked
    // 0x526e64: add             SP, SP, #0x18
    // 0x526e68: mov             x3, x0
    // 0x526e6c: b               #0x526d54
    // 0x526e70: r1 = Null
    //     0x526e70: mov             x1, NULL
    // 0x526e74: r2 = 8
    //     0x526e74: mov             x2, #8
    // 0x526e78: r0 = AllocateArray()
    //     0x526e78: bl              #0xd6987c  ; AllocateArrayStub
    // 0x526e7c: mov             x1, x0
    // 0x526e80: ldur            x0, [fp, #-0x10]
    // 0x526e84: StoreField: r1->field_f = r0
    //     0x526e84: stur            w0, [x1, #0xf]
    // 0x526e88: r17 = " e "
    //     0x526e88: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c08] " e "
    //     0x526e8c: ldr             x17, [x17, #0xc08]
    // 0x526e90: StoreField: r1->field_13 = r17
    //     0x526e90: stur            w17, [x1, #0x13]
    // 0x526e94: r17 = "| "
    //     0x526e94: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c18] "| "
    //     0x526e98: ldr             x17, [x17, #0xc18]
    // 0x526e9c: StoreField: r1->field_17 = r17
    //     0x526e9c: stur            w17, [x1, #0x17]
    // 0x526ea0: ldur            x2, [fp, #-0x20]
    // 0x526ea4: StoreField: r1->field_1b = r2
    //     0x526ea4: stur            w2, [x1, #0x1b]
    // 0x526ea8: SaveReg r1
    //     0x526ea8: str             x1, [SP, #-8]!
    // 0x526eac: r0 = _interpolate()
    //     0x526eac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x526eb0: add             SP, SP, #8
    // 0x526eb4: SaveReg r0
    //     0x526eb4: str             x0, [SP, #-8]!
    // 0x526eb8: r0 = printToConsole()
    //     0x526eb8: bl              #0x4ffa98  ; [dart:_internal] ::printToConsole
    // 0x526ebc: add             SP, SP, #8
    // 0x526ec0: r3 = ""
    //     0x526ec0: ldr             x3, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x526ec4: b               #0x526d54
    // 0x526ec8: r1 = Null
    //     0x526ec8: mov             x1, NULL
    // 0x526ecc: r2 = 6
    //     0x526ecc: mov             x2, #6
    // 0x526ed0: r0 = AllocateArray()
    //     0x526ed0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x526ed4: mov             x1, x0
    // 0x526ed8: ldur            x0, [fp, #-0x10]
    // 0x526edc: StoreField: r1->field_f = r0
    //     0x526edc: stur            w0, [x1, #0xf]
    // 0x526ee0: r17 = " e "
    //     0x526ee0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c08] " e "
    //     0x526ee4: ldr             x17, [x17, #0xc08]
    // 0x526ee8: StoreField: r1->field_13 = r17
    //     0x526ee8: stur            w17, [x1, #0x13]
    // 0x526eec: r17 = " — — — — — — — — — — — — — — — — ed — — — — — — — — — — — — — — — —"
    //     0x526eec: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c20] " — — — — — — — — — — — — — — — — ed — — — — — — — — — — — — — — — —"
    //     0x526ef0: ldr             x17, [x17, #0xc20]
    // 0x526ef4: StoreField: r1->field_17 = r17
    //     0x526ef4: stur            w17, [x1, #0x17]
    // 0x526ef8: SaveReg r1
    //     0x526ef8: str             x1, [SP, #-8]!
    // 0x526efc: r0 = _interpolate()
    //     0x526efc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x526f00: add             SP, SP, #8
    // 0x526f04: SaveReg r0
    //     0x526f04: str             x0, [SP, #-8]!
    // 0x526f08: r0 = print()
    //     0x526f08: bl              #0x4ff92c  ; [dart:core] ::print
    // 0x526f0c: add             SP, SP, #8
    // 0x526f10: r0 = Null
    //     0x526f10: mov             x0, NULL
    // 0x526f14: LeaveFrame
    //     0x526f14: mov             SP, fp
    //     0x526f18: ldp             fp, lr, [SP], #0x10
    // 0x526f1c: ret
    //     0x526f1c: ret             
    // 0x526f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x526f20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x526f24: b               #0x526c10
    // 0x526f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x526f28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x526f2c: b               #0x526d68
  }
  static String _tagValue() {
    // ** addr: 0x526f30, size: 0x8
    // 0x526f30: r0 = "common_utils"
    //     0x526f30: ldr             x0, [PP, #0x3590]  ; [pp+0x3590] "common_utils"
    // 0x526f34: ret
    //     0x526f34: ret             
  }
}

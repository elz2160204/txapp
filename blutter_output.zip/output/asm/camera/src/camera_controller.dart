// lib: , url: package:camera/src/camera_controller.dart

// class id: 1048701, size: 0x8
class :: {

  static _ availableCameras(/* No info */) async {
    // ** addr: 0x5ac1ac, size: 0x74
    // 0x5ac1ac: EnterFrame
    //     0x5ac1ac: stp             fp, lr, [SP, #-0x10]!
    //     0x5ac1b0: mov             fp, SP
    // 0x5ac1b4: AllocStack(0x8)
    //     0x5ac1b4: sub             SP, SP, #8
    // 0x5ac1b8: SetupParameters()
    //     0x5ac1b8: stur            NULL, [fp, #-8]
    // 0x5ac1bc: CheckStackOverflow
    //     0x5ac1bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ac1c0: cmp             SP, x16
    //     0x5ac1c4: b.ls            #0x5ac218
    // 0x5ac1c8: InitAsync() -> Future<List<CameraDescription>>
    //     0x5ac1c8: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d590] TypeArguments: <List<CameraDescription>>
    //     0x5ac1cc: ldr             x0, [x0, #0x590]
    //     0x5ac1d0: bl              #0x4b92e4
    // 0x5ac1d4: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x5ac1d4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5ac1d8: ldr             x0, [x0, #0x1590]
    //     0x5ac1dc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5ac1e0: cmp             w0, w16
    //     0x5ac1e4: b.ne            #0x5ac1f4
    //     0x5ac1e8: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x5ac1ec: ldr             x2, [x2, #0x270]
    //     0x5ac1f0: bl              #0xd67d44
    // 0x5ac1f4: r1 = LoadClassIdInstr(r0)
    //     0x5ac1f4: ldur            x1, [x0, #-1]
    //     0x5ac1f8: ubfx            x1, x1, #0xc, #0x14
    // 0x5ac1fc: SaveReg r0
    //     0x5ac1fc: str             x0, [SP, #-8]!
    // 0x5ac200: mov             x0, x1
    // 0x5ac204: r0 = GDT[cid_x0 + -0x6b4]()
    //     0x5ac204: sub             lr, x0, #0x6b4
    //     0x5ac208: ldr             lr, [x21, lr, lsl #3]
    //     0x5ac20c: blr             lr
    // 0x5ac210: add             SP, SP, #8
    // 0x5ac214: r0 = ReturnAsync()
    //     0x5ac214: b               #0x501858  ; ReturnAsyncStub
    // 0x5ac218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ac218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ac21c: b               #0x5ac1c8
  }
}

// class id: 4875, size: 0x50, field offset: 0x2c
class CameraController extends ValueNotifier<CameraValue> {

  _ getMinZoomLevel(/* No info */) {
    // ** addr: 0x5a80f8, size: 0xf4
    // 0x5a80f8: EnterFrame
    //     0x5a80f8: stp             fp, lr, [SP, #-0x10]!
    //     0x5a80fc: mov             fp, SP
    // 0x5a8100: AllocStack(0x40)
    //     0x5a8100: sub             SP, SP, #0x40
    // 0x5a8104: CheckStackOverflow
    //     0x5a8104: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a8108: cmp             SP, x16
    //     0x5a810c: b.ls            #0x5a81e4
    // 0x5a8110: ldr             x16, [fp, #0x10]
    // 0x5a8114: r30 = "getMinZoomLevel"
    //     0x5a8114: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d338] "getMinZoomLevel"
    //     0x5a8118: ldr             lr, [lr, #0x338]
    // 0x5a811c: stp             lr, x16, [SP, #-0x10]!
    // 0x5a8120: r0 = _throwIfNotInitialized()
    //     0x5a8120: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0x5a8124: add             SP, SP, #0x10
    // 0x5a8128: ldr             x0, [fp, #0x10]
    // 0x5a812c: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x5a812c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a8130: ldr             x0, [x0, #0x1590]
    //     0x5a8134: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5a8138: cmp             w0, w16
    //     0x5a813c: b.ne            #0x5a814c
    //     0x5a8140: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x5a8144: ldr             x2, [x2, #0x270]
    //     0x5a8148: bl              #0xd67d44
    // 0x5a814c: mov             x1, x0
    // 0x5a8150: ldr             x0, [fp, #0x10]
    // 0x5a8154: LoadField: r2 = r0->field_37
    //     0x5a8154: ldur            x2, [x0, #0x37]
    // 0x5a8158: r0 = LoadClassIdInstr(r1)
    //     0x5a8158: ldur            x0, [x1, #-1]
    //     0x5a815c: ubfx            x0, x0, #0xc, #0x14
    // 0x5a8160: stp             x2, x1, [SP, #-0x10]!
    // 0x5a8164: r0 = GDT[cid_x0 + 0x168]()
    //     0x5a8164: add             lr, x0, #0x168
    //     0x5a8168: ldr             lr, [x21, lr, lsl #3]
    //     0x5a816c: blr             lr
    // 0x5a8170: add             SP, SP, #0x10
    // 0x5a8174: LeaveFrame
    //     0x5a8174: mov             SP, fp
    //     0x5a8178: ldp             fp, lr, [SP], #0x10
    // 0x5a817c: ret
    //     0x5a817c: ret             
    // 0x5a8180: sub             SP, fp, #0x40
    // 0x5a8184: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x5a8184: mov             x2, #0x76
    //     0x5a8188: tbz             w0, #0, #0x5a8198
    //     0x5a818c: ldur            x2, [x0, #-1]
    //     0x5a8190: ubfx            x2, x2, #0xc, #0x14
    //     0x5a8194: lsl             x2, x2, #1
    // 0x5a8198: cmp             w2, #0xf28
    // 0x5a819c: b.ne            #0x5a81dc
    // 0x5a81a0: LoadField: r1 = r0->field_7
    //     0x5a81a0: ldur            w1, [x0, #7]
    // 0x5a81a4: DecompressPointer r1
    //     0x5a81a4: add             x1, x1, HEAP, lsl #32
    // 0x5a81a8: stur            x1, [fp, #-0x40]
    // 0x5a81ac: LoadField: r2 = r0->field_b
    //     0x5a81ac: ldur            w2, [x0, #0xb]
    // 0x5a81b0: DecompressPointer r2
    //     0x5a81b0: add             x2, x2, HEAP, lsl #32
    // 0x5a81b4: stur            x2, [fp, #-0x38]
    // 0x5a81b8: r0 = CameraException()
    //     0x5a81b8: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x5a81bc: mov             x1, x0
    // 0x5a81c0: ldur            x0, [fp, #-0x40]
    // 0x5a81c4: StoreField: r1->field_7 = r0
    //     0x5a81c4: stur            w0, [x1, #7]
    // 0x5a81c8: ldur            x0, [fp, #-0x38]
    // 0x5a81cc: StoreField: r1->field_b = r0
    //     0x5a81cc: stur            w0, [x1, #0xb]
    // 0x5a81d0: mov             x0, x1
    // 0x5a81d4: r0 = Throw()
    //     0x5a81d4: bl              #0xd67e38  ; ThrowStub
    // 0x5a81d8: brk             #0
    // 0x5a81dc: r0 = ReThrow()
    //     0x5a81dc: bl              #0xd67e14  ; ReThrowStub
    // 0x5a81e0: brk             #0
    // 0x5a81e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a81e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a81e8: b               #0x5a8110
  }
  _ _throwIfNotInitialized(/* No info */) {
    // ** addr: 0x5a81ec, size: 0x110
    // 0x5a81ec: EnterFrame
    //     0x5a81ec: stp             fp, lr, [SP, #-0x10]!
    //     0x5a81f0: mov             fp, SP
    // 0x5a81f4: AllocStack(0x8)
    //     0x5a81f4: sub             SP, SP, #8
    // 0x5a81f8: CheckStackOverflow
    //     0x5a81f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a81fc: cmp             SP, x16
    //     0x5a8200: b.ls            #0x5a82f4
    // 0x5a8204: ldr             x0, [fp, #0x18]
    // 0x5a8208: LoadField: r1 = r0->field_27
    //     0x5a8208: ldur            w1, [x0, #0x27]
    // 0x5a820c: DecompressPointer r1
    //     0x5a820c: add             x1, x1, HEAP, lsl #32
    // 0x5a8210: LoadField: r2 = r1->field_7
    //     0x5a8210: ldur            w2, [x1, #7]
    // 0x5a8214: DecompressPointer r2
    //     0x5a8214: add             x2, x2, HEAP, lsl #32
    // 0x5a8218: tbnz            w2, #4, #0x5a823c
    // 0x5a821c: ldr             x3, [fp, #0x10]
    // 0x5a8220: LoadField: r1 = r0->field_3f
    //     0x5a8220: ldur            w1, [x0, #0x3f]
    // 0x5a8224: DecompressPointer r1
    //     0x5a8224: add             x1, x1, HEAP, lsl #32
    // 0x5a8228: tbz             w1, #4, #0x5a8298
    // 0x5a822c: r0 = Null
    //     0x5a822c: mov             x0, NULL
    // 0x5a8230: LeaveFrame
    //     0x5a8230: mov             SP, fp
    //     0x5a8234: ldp             fp, lr, [SP], #0x10
    // 0x5a8238: ret
    //     0x5a8238: ret             
    // 0x5a823c: ldr             x0, [fp, #0x10]
    // 0x5a8240: r1 = Null
    //     0x5a8240: mov             x1, NULL
    // 0x5a8244: r2 = 4
    //     0x5a8244: mov             x2, #4
    // 0x5a8248: r0 = AllocateArray()
    //     0x5a8248: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5a824c: ldr             x3, [fp, #0x10]
    // 0x5a8250: StoreField: r0->field_f = r3
    //     0x5a8250: stur            w3, [x0, #0xf]
    // 0x5a8254: r17 = "() was called on an uninitialized CameraController."
    //     0x5a8254: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d278] "() was called on an uninitialized CameraController."
    //     0x5a8258: ldr             x17, [x17, #0x278]
    // 0x5a825c: StoreField: r0->field_13 = r17
    //     0x5a825c: stur            w17, [x0, #0x13]
    // 0x5a8260: SaveReg r0
    //     0x5a8260: str             x0, [SP, #-8]!
    // 0x5a8264: r0 = _interpolate()
    //     0x5a8264: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x5a8268: add             SP, SP, #8
    // 0x5a826c: stur            x0, [fp, #-8]
    // 0x5a8270: r0 = CameraException()
    //     0x5a8270: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x5a8274: mov             x1, x0
    // 0x5a8278: r0 = "Uninitialized CameraController"
    //     0x5a8278: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d280] "Uninitialized CameraController"
    //     0x5a827c: ldr             x0, [x0, #0x280]
    // 0x5a8280: StoreField: r1->field_7 = r0
    //     0x5a8280: stur            w0, [x1, #7]
    // 0x5a8284: ldur            x0, [fp, #-8]
    // 0x5a8288: StoreField: r1->field_b = r0
    //     0x5a8288: stur            w0, [x1, #0xb]
    // 0x5a828c: mov             x0, x1
    // 0x5a8290: r0 = Throw()
    //     0x5a8290: bl              #0xd67e38  ; ThrowStub
    // 0x5a8294: brk             #0
    // 0x5a8298: r1 = Null
    //     0x5a8298: mov             x1, NULL
    // 0x5a829c: r2 = 4
    //     0x5a829c: mov             x2, #4
    // 0x5a82a0: r0 = AllocateArray()
    //     0x5a82a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5a82a4: mov             x1, x0
    // 0x5a82a8: ldr             x0, [fp, #0x10]
    // 0x5a82ac: StoreField: r1->field_f = r0
    //     0x5a82ac: stur            w0, [x1, #0xf]
    // 0x5a82b0: r17 = "() was called on a disposed CameraController."
    //     0x5a82b0: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d288] "() was called on a disposed CameraController."
    //     0x5a82b4: ldr             x17, [x17, #0x288]
    // 0x5a82b8: StoreField: r1->field_13 = r17
    //     0x5a82b8: stur            w17, [x1, #0x13]
    // 0x5a82bc: SaveReg r1
    //     0x5a82bc: str             x1, [SP, #-8]!
    // 0x5a82c0: r0 = _interpolate()
    //     0x5a82c0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x5a82c4: add             SP, SP, #8
    // 0x5a82c8: stur            x0, [fp, #-8]
    // 0x5a82cc: r0 = CameraException()
    //     0x5a82cc: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x5a82d0: mov             x1, x0
    // 0x5a82d4: r0 = "Disposed CameraController"
    //     0x5a82d4: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d290] "Disposed CameraController"
    //     0x5a82d8: ldr             x0, [x0, #0x290]
    // 0x5a82dc: StoreField: r1->field_7 = r0
    //     0x5a82dc: stur            w0, [x1, #7]
    // 0x5a82e0: ldur            x0, [fp, #-8]
    // 0x5a82e4: StoreField: r1->field_b = r0
    //     0x5a82e4: stur            w0, [x1, #0xb]
    // 0x5a82e8: mov             x0, x1
    // 0x5a82ec: r0 = Throw()
    //     0x5a82ec: bl              #0xd67e38  ; ThrowStub
    // 0x5a82f0: brk             #0
    // 0x5a82f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a82f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a82f8: b               #0x5a8204
  }
  _ getMaxZoomLevel(/* No info */) {
    // ** addr: 0x5a8c1c, size: 0xf4
    // 0x5a8c1c: EnterFrame
    //     0x5a8c1c: stp             fp, lr, [SP, #-0x10]!
    //     0x5a8c20: mov             fp, SP
    // 0x5a8c24: AllocStack(0x40)
    //     0x5a8c24: sub             SP, SP, #0x40
    // 0x5a8c28: CheckStackOverflow
    //     0x5a8c28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a8c2c: cmp             SP, x16
    //     0x5a8c30: b.ls            #0x5a8d08
    // 0x5a8c34: ldr             x16, [fp, #0x10]
    // 0x5a8c38: r30 = "getMaxZoomLevel"
    //     0x5a8c38: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d340] "getMaxZoomLevel"
    //     0x5a8c3c: ldr             lr, [lr, #0x340]
    // 0x5a8c40: stp             lr, x16, [SP, #-0x10]!
    // 0x5a8c44: r0 = _throwIfNotInitialized()
    //     0x5a8c44: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0x5a8c48: add             SP, SP, #0x10
    // 0x5a8c4c: ldr             x0, [fp, #0x10]
    // 0x5a8c50: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x5a8c50: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a8c54: ldr             x0, [x0, #0x1590]
    //     0x5a8c58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5a8c5c: cmp             w0, w16
    //     0x5a8c60: b.ne            #0x5a8c70
    //     0x5a8c64: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x5a8c68: ldr             x2, [x2, #0x270]
    //     0x5a8c6c: bl              #0xd67d44
    // 0x5a8c70: mov             x1, x0
    // 0x5a8c74: ldr             x0, [fp, #0x10]
    // 0x5a8c78: LoadField: r2 = r0->field_37
    //     0x5a8c78: ldur            x2, [x0, #0x37]
    // 0x5a8c7c: r0 = LoadClassIdInstr(r1)
    //     0x5a8c7c: ldur            x0, [x1, #-1]
    //     0x5a8c80: ubfx            x0, x0, #0xc, #0x14
    // 0x5a8c84: stp             x2, x1, [SP, #-0x10]!
    // 0x5a8c88: r0 = GDT[cid_x0 + 0x158]()
    //     0x5a8c88: add             lr, x0, #0x158
    //     0x5a8c8c: ldr             lr, [x21, lr, lsl #3]
    //     0x5a8c90: blr             lr
    // 0x5a8c94: add             SP, SP, #0x10
    // 0x5a8c98: LeaveFrame
    //     0x5a8c98: mov             SP, fp
    //     0x5a8c9c: ldp             fp, lr, [SP], #0x10
    // 0x5a8ca0: ret
    //     0x5a8ca0: ret             
    // 0x5a8ca4: sub             SP, fp, #0x40
    // 0x5a8ca8: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x5a8ca8: mov             x2, #0x76
    //     0x5a8cac: tbz             w0, #0, #0x5a8cbc
    //     0x5a8cb0: ldur            x2, [x0, #-1]
    //     0x5a8cb4: ubfx            x2, x2, #0xc, #0x14
    //     0x5a8cb8: lsl             x2, x2, #1
    // 0x5a8cbc: cmp             w2, #0xf28
    // 0x5a8cc0: b.ne            #0x5a8d00
    // 0x5a8cc4: LoadField: r1 = r0->field_7
    //     0x5a8cc4: ldur            w1, [x0, #7]
    // 0x5a8cc8: DecompressPointer r1
    //     0x5a8cc8: add             x1, x1, HEAP, lsl #32
    // 0x5a8ccc: stur            x1, [fp, #-0x40]
    // 0x5a8cd0: LoadField: r2 = r0->field_b
    //     0x5a8cd0: ldur            w2, [x0, #0xb]
    // 0x5a8cd4: DecompressPointer r2
    //     0x5a8cd4: add             x2, x2, HEAP, lsl #32
    // 0x5a8cd8: stur            x2, [fp, #-0x38]
    // 0x5a8cdc: r0 = CameraException()
    //     0x5a8cdc: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x5a8ce0: mov             x1, x0
    // 0x5a8ce4: ldur            x0, [fp, #-0x40]
    // 0x5a8ce8: StoreField: r1->field_7 = r0
    //     0x5a8ce8: stur            w0, [x1, #7]
    // 0x5a8cec: ldur            x0, [fp, #-0x38]
    // 0x5a8cf0: StoreField: r1->field_b = r0
    //     0x5a8cf0: stur            w0, [x1, #0xb]
    // 0x5a8cf4: mov             x0, x1
    // 0x5a8cf8: r0 = Throw()
    //     0x5a8cf8: bl              #0xd67e38  ; ThrowStub
    // 0x5a8cfc: brk             #0
    // 0x5a8d00: r0 = ReThrow()
    //     0x5a8d00: bl              #0xd67e14  ; ReThrowStub
    // 0x5a8d04: brk             #0
    // 0x5a8d08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a8d08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a8d0c: b               #0x5a8c34
  }
  _ getMinExposureOffset(/* No info */) async {
    // ** addr: 0x5a8d10, size: 0x108
    // 0x5a8d10: EnterFrame
    //     0x5a8d10: stp             fp, lr, [SP, #-0x10]!
    //     0x5a8d14: mov             fp, SP
    // 0x5a8d18: AllocStack(0x50)
    //     0x5a8d18: sub             SP, SP, #0x50
    // 0x5a8d1c: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x48 */)
    //     0x5a8d1c: stur            NULL, [fp, #-8]
    //     0x5a8d20: mov             x0, #0
    //     0x5a8d24: add             x1, fp, w0, sxtw #2
    //     0x5a8d28: ldr             x1, [x1, #0x10]
    //     0x5a8d2c: stur            x1, [fp, #-0x48]
    // 0x5a8d30: CheckStackOverflow
    //     0x5a8d30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a8d34: cmp             SP, x16
    //     0x5a8d38: b.ls            #0x5a8e10
    // 0x5a8d3c: InitAsync() -> Future<double>
    //     0x5a8d3c: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0x5a8d40: bl              #0x4b92e4
    // 0x5a8d44: ldur            x16, [fp, #-0x48]
    // 0x5a8d48: r30 = "getMinExposureOffset"
    //     0x5a8d48: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d348] "getMinExposureOffset"
    //     0x5a8d4c: ldr             lr, [lr, #0x348]
    // 0x5a8d50: stp             lr, x16, [SP, #-0x10]!
    // 0x5a8d54: r0 = _throwIfNotInitialized()
    //     0x5a8d54: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0x5a8d58: add             SP, SP, #0x10
    // 0x5a8d5c: ldur            x0, [fp, #-0x48]
    // 0x5a8d60: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x5a8d60: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a8d64: ldr             x0, [x0, #0x1590]
    //     0x5a8d68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5a8d6c: cmp             w0, w16
    //     0x5a8d70: b.ne            #0x5a8d80
    //     0x5a8d74: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x5a8d78: ldr             x2, [x2, #0x270]
    //     0x5a8d7c: bl              #0xd67d44
    // 0x5a8d80: mov             x1, x0
    // 0x5a8d84: ldur            x0, [fp, #-0x48]
    // 0x5a8d88: LoadField: r2 = r0->field_37
    //     0x5a8d88: ldur            x2, [x0, #0x37]
    // 0x5a8d8c: r0 = LoadClassIdInstr(r1)
    //     0x5a8d8c: ldur            x0, [x1, #-1]
    //     0x5a8d90: ubfx            x0, x0, #0xc, #0x14
    // 0x5a8d94: stp             x2, x1, [SP, #-0x10]!
    // 0x5a8d98: r0 = GDT[cid_x0 + 0xc0]()
    //     0x5a8d98: add             lr, x0, #0xc0
    //     0x5a8d9c: ldr             lr, [x21, lr, lsl #3]
    //     0x5a8da0: blr             lr
    // 0x5a8da4: add             SP, SP, #0x10
    // 0x5a8da8: r0 = ReturnAsync()
    //     0x5a8da8: b               #0x501858  ; ReturnAsyncStub
    // 0x5a8dac: sub             SP, fp, #0x50
    // 0x5a8db0: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x5a8db0: mov             x2, #0x76
    //     0x5a8db4: tbz             w0, #0, #0x5a8dc4
    //     0x5a8db8: ldur            x2, [x0, #-1]
    //     0x5a8dbc: ubfx            x2, x2, #0xc, #0x14
    //     0x5a8dc0: lsl             x2, x2, #1
    // 0x5a8dc4: cmp             w2, #0xf28
    // 0x5a8dc8: b.ne            #0x5a8e08
    // 0x5a8dcc: LoadField: r1 = r0->field_7
    //     0x5a8dcc: ldur            w1, [x0, #7]
    // 0x5a8dd0: DecompressPointer r1
    //     0x5a8dd0: add             x1, x1, HEAP, lsl #32
    // 0x5a8dd4: stur            x1, [fp, #-0x50]
    // 0x5a8dd8: LoadField: r2 = r0->field_b
    //     0x5a8dd8: ldur            w2, [x0, #0xb]
    // 0x5a8ddc: DecompressPointer r2
    //     0x5a8ddc: add             x2, x2, HEAP, lsl #32
    // 0x5a8de0: stur            x2, [fp, #-0x48]
    // 0x5a8de4: r0 = CameraException()
    //     0x5a8de4: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x5a8de8: mov             x1, x0
    // 0x5a8dec: ldur            x0, [fp, #-0x50]
    // 0x5a8df0: StoreField: r1->field_7 = r0
    //     0x5a8df0: stur            w0, [x1, #7]
    // 0x5a8df4: ldur            x0, [fp, #-0x48]
    // 0x5a8df8: StoreField: r1->field_b = r0
    //     0x5a8df8: stur            w0, [x1, #0xb]
    // 0x5a8dfc: mov             x0, x1
    // 0x5a8e00: r0 = Throw()
    //     0x5a8e00: bl              #0xd67e38  ; ThrowStub
    // 0x5a8e04: brk             #0
    // 0x5a8e08: r0 = ReThrow()
    //     0x5a8e08: bl              #0xd67e14  ; ReThrowStub
    // 0x5a8e0c: brk             #0
    // 0x5a8e10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a8e10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a8e14: b               #0x5a8d3c
  }
  _ getMaxExposureOffset(/* No info */) async {
    // ** addr: 0x5a8e18, size: 0x108
    // 0x5a8e18: EnterFrame
    //     0x5a8e18: stp             fp, lr, [SP, #-0x10]!
    //     0x5a8e1c: mov             fp, SP
    // 0x5a8e20: AllocStack(0x50)
    //     0x5a8e20: sub             SP, SP, #0x50
    // 0x5a8e24: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x48 */)
    //     0x5a8e24: stur            NULL, [fp, #-8]
    //     0x5a8e28: mov             x0, #0
    //     0x5a8e2c: add             x1, fp, w0, sxtw #2
    //     0x5a8e30: ldr             x1, [x1, #0x10]
    //     0x5a8e34: stur            x1, [fp, #-0x48]
    // 0x5a8e38: CheckStackOverflow
    //     0x5a8e38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a8e3c: cmp             SP, x16
    //     0x5a8e40: b.ls            #0x5a8f18
    // 0x5a8e44: InitAsync() -> Future<double>
    //     0x5a8e44: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0x5a8e48: bl              #0x4b92e4
    // 0x5a8e4c: ldur            x16, [fp, #-0x48]
    // 0x5a8e50: r30 = "getMaxExposureOffset"
    //     0x5a8e50: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d350] "getMaxExposureOffset"
    //     0x5a8e54: ldr             lr, [lr, #0x350]
    // 0x5a8e58: stp             lr, x16, [SP, #-0x10]!
    // 0x5a8e5c: r0 = _throwIfNotInitialized()
    //     0x5a8e5c: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0x5a8e60: add             SP, SP, #0x10
    // 0x5a8e64: ldur            x0, [fp, #-0x48]
    // 0x5a8e68: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x5a8e68: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a8e6c: ldr             x0, [x0, #0x1590]
    //     0x5a8e70: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5a8e74: cmp             w0, w16
    //     0x5a8e78: b.ne            #0x5a8e88
    //     0x5a8e7c: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x5a8e80: ldr             x2, [x2, #0x270]
    //     0x5a8e84: bl              #0xd67d44
    // 0x5a8e88: mov             x1, x0
    // 0x5a8e8c: ldur            x0, [fp, #-0x48]
    // 0x5a8e90: LoadField: r2 = r0->field_37
    //     0x5a8e90: ldur            x2, [x0, #0x37]
    // 0x5a8e94: r0 = LoadClassIdInstr(r1)
    //     0x5a8e94: ldur            x0, [x1, #-1]
    //     0x5a8e98: ubfx            x0, x0, #0xc, #0x14
    // 0x5a8e9c: stp             x2, x1, [SP, #-0x10]!
    // 0x5a8ea0: r0 = GDT[cid_x0 + 0xe0]()
    //     0x5a8ea0: add             lr, x0, #0xe0
    //     0x5a8ea4: ldr             lr, [x21, lr, lsl #3]
    //     0x5a8ea8: blr             lr
    // 0x5a8eac: add             SP, SP, #0x10
    // 0x5a8eb0: r0 = ReturnAsync()
    //     0x5a8eb0: b               #0x501858  ; ReturnAsyncStub
    // 0x5a8eb4: sub             SP, fp, #0x50
    // 0x5a8eb8: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x5a8eb8: mov             x2, #0x76
    //     0x5a8ebc: tbz             w0, #0, #0x5a8ecc
    //     0x5a8ec0: ldur            x2, [x0, #-1]
    //     0x5a8ec4: ubfx            x2, x2, #0xc, #0x14
    //     0x5a8ec8: lsl             x2, x2, #1
    // 0x5a8ecc: cmp             w2, #0xf28
    // 0x5a8ed0: b.ne            #0x5a8f10
    // 0x5a8ed4: LoadField: r1 = r0->field_7
    //     0x5a8ed4: ldur            w1, [x0, #7]
    // 0x5a8ed8: DecompressPointer r1
    //     0x5a8ed8: add             x1, x1, HEAP, lsl #32
    // 0x5a8edc: stur            x1, [fp, #-0x50]
    // 0x5a8ee0: LoadField: r2 = r0->field_b
    //     0x5a8ee0: ldur            w2, [x0, #0xb]
    // 0x5a8ee4: DecompressPointer r2
    //     0x5a8ee4: add             x2, x2, HEAP, lsl #32
    // 0x5a8ee8: stur            x2, [fp, #-0x48]
    // 0x5a8eec: r0 = CameraException()
    //     0x5a8eec: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x5a8ef0: mov             x1, x0
    // 0x5a8ef4: ldur            x0, [fp, #-0x50]
    // 0x5a8ef8: StoreField: r1->field_7 = r0
    //     0x5a8ef8: stur            w0, [x1, #7]
    // 0x5a8efc: ldur            x0, [fp, #-0x48]
    // 0x5a8f00: StoreField: r1->field_b = r0
    //     0x5a8f00: stur            w0, [x1, #0xb]
    // 0x5a8f04: mov             x0, x1
    // 0x5a8f08: r0 = Throw()
    //     0x5a8f08: bl              #0xd67e38  ; ThrowStub
    // 0x5a8f0c: brk             #0
    // 0x5a8f10: r0 = ReThrow()
    //     0x5a8f10: bl              #0xd67e14  ; ReThrowStub
    // 0x5a8f14: brk             #0
    // 0x5a8f18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a8f18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a8f1c: b               #0x5a8e44
  }
  _ getExposureOffsetStepSize(/* No info */) async {
    // ** addr: 0x5a8f20, size: 0x108
    // 0x5a8f20: EnterFrame
    //     0x5a8f20: stp             fp, lr, [SP, #-0x10]!
    //     0x5a8f24: mov             fp, SP
    // 0x5a8f28: AllocStack(0x50)
    //     0x5a8f28: sub             SP, SP, #0x50
    // 0x5a8f2c: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x48 */)
    //     0x5a8f2c: stur            NULL, [fp, #-8]
    //     0x5a8f30: mov             x0, #0
    //     0x5a8f34: add             x1, fp, w0, sxtw #2
    //     0x5a8f38: ldr             x1, [x1, #0x10]
    //     0x5a8f3c: stur            x1, [fp, #-0x48]
    // 0x5a8f40: CheckStackOverflow
    //     0x5a8f40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a8f44: cmp             SP, x16
    //     0x5a8f48: b.ls            #0x5a9020
    // 0x5a8f4c: InitAsync() -> Future<double>
    //     0x5a8f4c: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0x5a8f50: bl              #0x4b92e4
    // 0x5a8f54: ldur            x16, [fp, #-0x48]
    // 0x5a8f58: r30 = "getExposureOffsetStepSize"
    //     0x5a8f58: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d358] "getExposureOffsetStepSize"
    //     0x5a8f5c: ldr             lr, [lr, #0x358]
    // 0x5a8f60: stp             lr, x16, [SP, #-0x10]!
    // 0x5a8f64: r0 = _throwIfNotInitialized()
    //     0x5a8f64: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0x5a8f68: add             SP, SP, #0x10
    // 0x5a8f6c: ldur            x0, [fp, #-0x48]
    // 0x5a8f70: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x5a8f70: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a8f74: ldr             x0, [x0, #0x1590]
    //     0x5a8f78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5a8f7c: cmp             w0, w16
    //     0x5a8f80: b.ne            #0x5a8f90
    //     0x5a8f84: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x5a8f88: ldr             x2, [x2, #0x270]
    //     0x5a8f8c: bl              #0xd67d44
    // 0x5a8f90: mov             x1, x0
    // 0x5a8f94: ldur            x0, [fp, #-0x48]
    // 0x5a8f98: LoadField: r2 = r0->field_37
    //     0x5a8f98: ldur            x2, [x0, #0x37]
    // 0x5a8f9c: r0 = LoadClassIdInstr(r1)
    //     0x5a8f9c: ldur            x0, [x1, #-1]
    //     0x5a8fa0: ubfx            x0, x0, #0xc, #0x14
    // 0x5a8fa4: stp             x2, x1, [SP, #-0x10]!
    // 0x5a8fa8: r0 = GDT[cid_x0 + 0x112]()
    //     0x5a8fa8: add             lr, x0, #0x112
    //     0x5a8fac: ldr             lr, [x21, lr, lsl #3]
    //     0x5a8fb0: blr             lr
    // 0x5a8fb4: add             SP, SP, #0x10
    // 0x5a8fb8: r0 = ReturnAsync()
    //     0x5a8fb8: b               #0x501858  ; ReturnAsyncStub
    // 0x5a8fbc: sub             SP, fp, #0x50
    // 0x5a8fc0: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x5a8fc0: mov             x2, #0x76
    //     0x5a8fc4: tbz             w0, #0, #0x5a8fd4
    //     0x5a8fc8: ldur            x2, [x0, #-1]
    //     0x5a8fcc: ubfx            x2, x2, #0xc, #0x14
    //     0x5a8fd0: lsl             x2, x2, #1
    // 0x5a8fd4: cmp             w2, #0xf28
    // 0x5a8fd8: b.ne            #0x5a9018
    // 0x5a8fdc: LoadField: r1 = r0->field_7
    //     0x5a8fdc: ldur            w1, [x0, #7]
    // 0x5a8fe0: DecompressPointer r1
    //     0x5a8fe0: add             x1, x1, HEAP, lsl #32
    // 0x5a8fe4: stur            x1, [fp, #-0x50]
    // 0x5a8fe8: LoadField: r2 = r0->field_b
    //     0x5a8fe8: ldur            w2, [x0, #0xb]
    // 0x5a8fec: DecompressPointer r2
    //     0x5a8fec: add             x2, x2, HEAP, lsl #32
    // 0x5a8ff0: stur            x2, [fp, #-0x48]
    // 0x5a8ff4: r0 = CameraException()
    //     0x5a8ff4: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x5a8ff8: mov             x1, x0
    // 0x5a8ffc: ldur            x0, [fp, #-0x50]
    // 0x5a9000: StoreField: r1->field_7 = r0
    //     0x5a9000: stur            w0, [x1, #7]
    // 0x5a9004: ldur            x0, [fp, #-0x48]
    // 0x5a9008: StoreField: r1->field_b = r0
    //     0x5a9008: stur            w0, [x1, #0xb]
    // 0x5a900c: mov             x0, x1
    // 0x5a9010: r0 = Throw()
    //     0x5a9010: bl              #0xd67e38  ; ThrowStub
    // 0x5a9014: brk             #0
    // 0x5a9018: r0 = ReThrow()
    //     0x5a9018: bl              #0xd67e14  ; ReThrowStub
    // 0x5a901c: brk             #0
    // 0x5a9020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a9020: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a9024: b               #0x5a8f4c
  }
  _ prepareForVideoRecording(/* No info */) async {
    // ** addr: 0x5a9028, size: 0x110
    // 0x5a9028: EnterFrame
    //     0x5a9028: stp             fp, lr, [SP, #-0x10]!
    //     0x5a902c: mov             fp, SP
    // 0x5a9030: AllocStack(0x10)
    //     0x5a9030: sub             SP, SP, #0x10
    // 0x5a9034: SetupParameters()
    //     0x5a9034: stur            NULL, [fp, #-8]
    // 0x5a9038: CheckStackOverflow
    //     0x5a9038: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a903c: cmp             SP, x16
    //     0x5a9040: b.ls            #0x5a9130
    // 0x5a9044: InitAsync() -> Future<void?>
    //     0x5a9044: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x5a9048: bl              #0x4b92e4
    // 0x5a904c: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x5a904c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a9050: ldr             x0, [x0, #0x1590]
    //     0x5a9054: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5a9058: cmp             w0, w16
    //     0x5a905c: b.ne            #0x5a906c
    //     0x5a9060: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x5a9064: ldr             x2, [x2, #0x270]
    //     0x5a9068: bl              #0xd67d44
    // 0x5a906c: r1 = LoadClassIdInstr(r0)
    //     0x5a906c: ldur            x1, [x0, #-1]
    //     0x5a9070: ubfx            x1, x1, #0xc, #0x14
    // 0x5a9074: lsl             x1, x1, #1
    // 0x5a9078: r17 = 9914
    //     0x5a9078: mov             x17, #0x26ba
    // 0x5a907c: cmp             w1, w17
    // 0x5a9080: b.ne            #0x5a90b4
    // 0x5a9084: r16 = <void?>
    //     0x5a9084: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x5a9088: r30 = Instance_MethodChannel
    //     0x5a9088: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0x5a908c: ldr             lr, [lr, #0x360]
    // 0x5a9090: stp             lr, x16, [SP, #-0x10]!
    // 0x5a9094: r16 = "prepareForVideoRecording"
    //     0x5a9094: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d368] "prepareForVideoRecording"
    //     0x5a9098: ldr             x16, [x16, #0x368]
    // 0x5a909c: SaveReg r16
    //     0x5a909c: str             x16, [SP, #-8]!
    // 0x5a90a0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a90a0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a90a4: r0 = invokeMethod()
    //     0x5a90a4: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x5a90a8: add             SP, SP, #0x18
    // 0x5a90ac: mov             x1, x0
    // 0x5a90b0: b               #0x5a911c
    // 0x5a90b4: r17 = 9916
    //     0x5a90b4: mov             x17, #0x26bc
    // 0x5a90b8: cmp             w1, w17
    // 0x5a90bc: b.ne            #0x5a90f0
    // 0x5a90c0: r16 = <void?>
    //     0x5a90c0: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x5a90c4: r30 = Instance_MethodChannel
    //     0x5a90c4: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0x5a90c8: ldr             lr, [lr, #0x370]
    // 0x5a90cc: stp             lr, x16, [SP, #-0x10]!
    // 0x5a90d0: r16 = "prepareForVideoRecording"
    //     0x5a90d0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d368] "prepareForVideoRecording"
    //     0x5a90d4: ldr             x16, [x16, #0x368]
    // 0x5a90d8: SaveReg r16
    //     0x5a90d8: str             x16, [SP, #-8]!
    // 0x5a90dc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a90dc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a90e0: r0 = invokeMethod()
    //     0x5a90e0: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x5a90e4: add             SP, SP, #0x18
    // 0x5a90e8: mov             x1, x0
    // 0x5a90ec: b               #0x5a911c
    // 0x5a90f0: r16 = <void?>
    //     0x5a90f0: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x5a90f4: r30 = Instance_MethodChannel
    //     0x5a90f4: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0x5a90f8: ldr             lr, [lr, #0x378]
    // 0x5a90fc: stp             lr, x16, [SP, #-0x10]!
    // 0x5a9100: r16 = "prepareForVideoRecording"
    //     0x5a9100: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d368] "prepareForVideoRecording"
    //     0x5a9104: ldr             x16, [x16, #0x368]
    // 0x5a9108: SaveReg r16
    //     0x5a9108: str             x16, [SP, #-8]!
    // 0x5a910c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a910c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a9110: r0 = invokeMethod()
    //     0x5a9110: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x5a9114: add             SP, SP, #0x18
    // 0x5a9118: mov             x1, x0
    // 0x5a911c: mov             x0, x1
    // 0x5a9120: stur            x1, [fp, #-0x10]
    // 0x5a9124: r0 = Await()
    //     0x5a9124: bl              #0x4b8e6c  ; AwaitStub
    // 0x5a9128: r0 = Null
    //     0x5a9128: mov             x0, NULL
    // 0x5a912c: r0 = ReturnAsyncNotFuture()
    //     0x5a912c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x5a9130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a9130: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a9134: b               #0x5a9044
  }
  _ initialize(/* No info */) {
    // ** addr: 0x5a9194, size: 0x48
    // 0x5a9194: EnterFrame
    //     0x5a9194: stp             fp, lr, [SP, #-0x10]!
    //     0x5a9198: mov             fp, SP
    // 0x5a919c: CheckStackOverflow
    //     0x5a919c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a91a0: cmp             SP, x16
    //     0x5a91a4: b.ls            #0x5a91d4
    // 0x5a91a8: ldr             x16, [fp, #0x10]
    // 0x5a91ac: SaveReg r16
    //     0x5a91ac: str             x16, [SP, #-8]!
    // 0x5a91b0: r0 = description()
    //     0x5a91b0: bl              #0x5abe58  ; [package:camera/src/camera_controller.dart] CameraController::description
    // 0x5a91b4: add             SP, SP, #8
    // 0x5a91b8: ldr             x16, [fp, #0x10]
    // 0x5a91bc: stp             x0, x16, [SP, #-0x10]!
    // 0x5a91c0: r0 = _initializeWithDescription()
    //     0x5a91c0: bl              #0x5a91dc  ; [package:camera/src/camera_controller.dart] CameraController::_initializeWithDescription
    // 0x5a91c4: add             SP, SP, #0x10
    // 0x5a91c8: LeaveFrame
    //     0x5a91c8: mov             SP, fp
    //     0x5a91cc: ldp             fp, lr, [SP], #0x10
    // 0x5a91d0: ret
    //     0x5a91d0: ret             
    // 0x5a91d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a91d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a91d8: b               #0x5a91a8
  }
  _ _initializeWithDescription(/* No info */) async {
    // ** addr: 0x5a91dc, size: 0x68c
    // 0x5a91dc: EnterFrame
    //     0x5a91dc: stp             fp, lr, [SP, #-0x10]!
    //     0x5a91e0: mov             fp, SP
    // 0x5a91e4: AllocStack(0xb0)
    //     0x5a91e4: sub             SP, SP, #0xb0
    // 0x5a91e8: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x78 */, dynamic _ /* r2, fp-0x70 */)
    //     0x5a91e8: stur            NULL, [fp, #-8]
    //     0x5a91ec: mov             x0, #0
    //     0x5a91f0: add             x1, fp, w0, sxtw #2
    //     0x5a91f4: ldr             x1, [x1, #0x18]
    //     0x5a91f8: stur            x1, [fp, #-0x78]
    //     0x5a91fc: add             x2, fp, w0, sxtw #2
    //     0x5a9200: ldr             x2, [x2, #0x10]
    //     0x5a9204: stur            x2, [fp, #-0x70]
    // 0x5a9208: CheckStackOverflow
    //     0x5a9208: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a920c: cmp             SP, x16
    //     0x5a9210: b.ls            #0x5a9860
    // 0x5a9214: r1 = 2
    //     0x5a9214: mov             x1, #2
    // 0x5a9218: r0 = AllocateContext()
    //     0x5a9218: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5a921c: mov             x2, x0
    // 0x5a9220: ldur            x1, [fp, #-0x78]
    // 0x5a9224: stur            x2, [fp, #-0x80]
    // 0x5a9228: StoreField: r2->field_f = r1
    //     0x5a9228: stur            w1, [x2, #0xf]
    // 0x5a922c: InitAsync() -> Future<void?>
    //     0x5a922c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x5a9230: bl              #0x4b92e4
    // 0x5a9234: ldur            x0, [fp, #-0x78]
    // 0x5a9238: LoadField: r1 = r0->field_3f
    //     0x5a9238: ldur            w1, [x0, #0x3f]
    // 0x5a923c: DecompressPointer r1
    //     0x5a923c: add             x1, x1, HEAP, lsl #32
    // 0x5a9240: tbz             w1, #4, #0x5a97f0
    // 0x5a9244: ldur            x2, [fp, #-0x80]
    // 0x5a9248: r1 = <CameraInitializedEvent>
    //     0x5a9248: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d380] TypeArguments: <CameraInitializedEvent>
    //     0x5a924c: ldr             x1, [x1, #0x380]
    // 0x5a9250: r0 = _AsyncCompleter()
    //     0x5a9250: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x5a9254: r1 = <CameraInitializedEvent>
    //     0x5a9254: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d380] TypeArguments: <CameraInitializedEvent>
    //     0x5a9258: ldr             x1, [x1, #0x380]
    // 0x5a925c: stur            x0, [fp, #-0x88]
    // 0x5a9260: r0 = _Future()
    //     0x5a9260: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x5a9264: mov             x1, x0
    // 0x5a9268: r0 = 0
    //     0x5a9268: mov             x0, #0
    // 0x5a926c: stur            x1, [fp, #-0x90]
    // 0x5a9270: StoreField: r1->field_b = r0
    //     0x5a9270: stur            x0, [x1, #0xb]
    // 0x5a9274: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x5a9274: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a9278: ldr             x0, [x0, #0xb58]
    //     0x5a927c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5a9280: cmp             w0, w16
    //     0x5a9284: b.ne            #0x5a9290
    //     0x5a9288: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x5a928c: bl              #0xd67d44
    // 0x5a9290: ldur            x1, [fp, #-0x90]
    // 0x5a9294: StoreField: r1->field_13 = r0
    //     0x5a9294: stur            w0, [x1, #0x13]
    // 0x5a9298: ldur            x0, [fp, #-0x88]
    // 0x5a929c: StoreField: r0->field_b = r1
    //     0x5a929c: stur            w1, [x0, #0xb]
    // 0x5a92a0: ldur            x2, [fp, #-0x80]
    // 0x5a92a4: StoreField: r2->field_13 = r0
    //     0x5a92a4: stur            w0, [x2, #0x13]
    //     0x5a92a8: ldurb           w16, [x2, #-1]
    //     0x5a92ac: ldurb           w17, [x0, #-1]
    //     0x5a92b0: and             x16, x17, x16, lsr #2
    //     0x5a92b4: tst             x16, HEAP, lsr #32
    //     0x5a92b8: b.eq            #0x5a92c0
    //     0x5a92bc: bl              #0xd6828c
    // 0x5a92c0: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x5a92c0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a92c4: ldr             x0, [x0, #0x1590]
    //     0x5a92c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5a92cc: cmp             w0, w16
    //     0x5a92d0: b.ne            #0x5a92e0
    //     0x5a92d4: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x5a92d8: ldr             x2, [x2, #0x270]
    //     0x5a92dc: bl              #0xd67d44
    // 0x5a92e0: stur            x0, [fp, #-0xa0]
    // 0x5a92e4: r1 = LoadClassIdInstr(r0)
    //     0x5a92e4: ldur            x1, [x0, #-1]
    //     0x5a92e8: ubfx            x1, x1, #0xc, #0x14
    // 0x5a92ec: lsl             x1, x1, #1
    // 0x5a92f0: r17 = 9914
    //     0x5a92f0: mov             x17, #0x26ba
    // 0x5a92f4: cmp             w1, w17
    // 0x5a92f8: b.ne            #0x5a9348
    // 0x5a92fc: LoadField: r2 = r0->field_f
    //     0x5a92fc: ldur            w2, [x0, #0xf]
    // 0x5a9300: DecompressPointer r2
    //     0x5a9300: add             x2, x2, HEAP, lsl #32
    // 0x5a9304: stur            x2, [fp, #-0x98]
    // 0x5a9308: LoadField: r3 = r2->field_7
    //     0x5a9308: ldur            w3, [x2, #7]
    // 0x5a930c: DecompressPointer r3
    //     0x5a930c: add             x3, x3, HEAP, lsl #32
    // 0x5a9310: mov             x1, x3
    // 0x5a9314: stur            x3, [fp, #-0x88]
    // 0x5a9318: r0 = _BroadcastStream()
    //     0x5a9318: bl              #0x5a25c8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x14)
    // 0x5a931c: mov             x1, x0
    // 0x5a9320: ldur            x0, [fp, #-0x98]
    // 0x5a9324: StoreField: r1->field_f = r0
    //     0x5a9324: stur            w0, [x1, #0xf]
    // 0x5a9328: r16 = <DeviceEvent, DeviceOrientationChangedEvent>
    //     0x5a9328: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d388] TypeArguments: <DeviceEvent, DeviceOrientationChangedEvent>
    //     0x5a932c: ldr             x16, [x16, #0x388]
    // 0x5a9330: stp             x1, x16, [SP, #-0x10]!
    // 0x5a9334: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x5a9334: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x5a9338: r0 = Where.whereType()
    //     0x5a9338: bl              #0x5aa93c  ; [package:stream_transform/src/where.dart] ::Where.whereType
    // 0x5a933c: add             SP, SP, #0x10
    // 0x5a9340: mov             x3, x0
    // 0x5a9344: b               #0x5a9420
    // 0x5a9348: r17 = 9916
    //     0x5a9348: mov             x17, #0x26bc
    // 0x5a934c: cmp             w1, w17
    // 0x5a9350: b.ne            #0x5a93bc
    // 0x5a9354: ldur            x1, [fp, #-0xa0]
    // 0x5a9358: LoadField: r0 = r1->field_f
    //     0x5a9358: ldur            w0, [x1, #0xf]
    // 0x5a935c: DecompressPointer r0
    //     0x5a935c: add             x0, x0, HEAP, lsl #32
    // 0x5a9360: r16 = Sentinel
    //     0x5a9360: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5a9364: cmp             w0, w16
    // 0x5a9368: b.ne            #0x5a9378
    // 0x5a936c: r2 = _deviceEventStreamController
    //     0x5a936c: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d390] Field <AVFoundationCamera._deviceEventStreamController@177501818>: late final (offset: 0x10)
    //     0x5a9370: ldr             x2, [x2, #0x390]
    // 0x5a9374: r0 = InitLateFinalInstanceField()
    //     0x5a9374: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x5a9378: stur            x0, [fp, #-0x98]
    // 0x5a937c: LoadField: r2 = r0->field_7
    //     0x5a937c: ldur            w2, [x0, #7]
    // 0x5a9380: DecompressPointer r2
    //     0x5a9380: add             x2, x2, HEAP, lsl #32
    // 0x5a9384: mov             x1, x2
    // 0x5a9388: stur            x2, [fp, #-0x88]
    // 0x5a938c: r0 = _BroadcastStream()
    //     0x5a938c: bl              #0x5a25c8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x14)
    // 0x5a9390: mov             x1, x0
    // 0x5a9394: ldur            x0, [fp, #-0x98]
    // 0x5a9398: StoreField: r1->field_f = r0
    //     0x5a9398: stur            w0, [x1, #0xf]
    // 0x5a939c: r16 = <DeviceEvent, DeviceOrientationChangedEvent>
    //     0x5a939c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d388] TypeArguments: <DeviceEvent, DeviceOrientationChangedEvent>
    //     0x5a93a0: ldr             x16, [x16, #0x388]
    // 0x5a93a4: stp             x1, x16, [SP, #-0x10]!
    // 0x5a93a8: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x5a93a8: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x5a93ac: r0 = Where.whereType()
    //     0x5a93ac: bl              #0x5aa93c  ; [package:stream_transform/src/where.dart] ::Where.whereType
    // 0x5a93b0: add             SP, SP, #0x10
    // 0x5a93b4: mov             x3, x0
    // 0x5a93b8: b               #0x5a9420
    // 0x5a93bc: ldur            x1, [fp, #-0xa0]
    // 0x5a93c0: LoadField: r0 = r1->field_f
    //     0x5a93c0: ldur            w0, [x1, #0xf]
    // 0x5a93c4: DecompressPointer r0
    //     0x5a93c4: add             x0, x0, HEAP, lsl #32
    // 0x5a93c8: r16 = Sentinel
    //     0x5a93c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5a93cc: cmp             w0, w16
    // 0x5a93d0: b.ne            #0x5a93e0
    // 0x5a93d4: r2 = _deviceEventStreamController
    //     0x5a93d4: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d398] Field <AndroidCamera._deviceEventStreamController@172119562>: late final (offset: 0x10)
    //     0x5a93d8: ldr             x2, [x2, #0x398]
    // 0x5a93dc: r0 = InitLateFinalInstanceField()
    //     0x5a93dc: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x5a93e0: stur            x0, [fp, #-0x98]
    // 0x5a93e4: LoadField: r2 = r0->field_7
    //     0x5a93e4: ldur            w2, [x0, #7]
    // 0x5a93e8: DecompressPointer r2
    //     0x5a93e8: add             x2, x2, HEAP, lsl #32
    // 0x5a93ec: mov             x1, x2
    // 0x5a93f0: stur            x2, [fp, #-0x88]
    // 0x5a93f4: r0 = _BroadcastStream()
    //     0x5a93f4: bl              #0x5a25c8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x14)
    // 0x5a93f8: mov             x1, x0
    // 0x5a93fc: ldur            x0, [fp, #-0x98]
    // 0x5a9400: StoreField: r1->field_f = r0
    //     0x5a9400: stur            w0, [x1, #0xf]
    // 0x5a9404: r16 = <DeviceEvent, DeviceOrientationChangedEvent>
    //     0x5a9404: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d388] TypeArguments: <DeviceEvent, DeviceOrientationChangedEvent>
    //     0x5a9408: ldr             x16, [x16, #0x388]
    // 0x5a940c: stp             x1, x16, [SP, #-0x10]!
    // 0x5a9410: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x5a9410: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x5a9414: r0 = Where.whereType()
    //     0x5a9414: bl              #0x5aa93c  ; [package:stream_transform/src/where.dart] ::Where.whereType
    // 0x5a9418: add             SP, SP, #0x10
    // 0x5a941c: mov             x3, x0
    // 0x5a9420: ldur            x0, [fp, #-0x78]
    // 0x5a9424: ldur            x2, [fp, #-0x80]
    // 0x5a9428: stur            x3, [fp, #-0x88]
    // 0x5a942c: r1 = Function '<anonymous closure>':.
    //     0x5a942c: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d3a0] AnonymousClosure: (0x5ab7dc), in [package:camera/src/camera_controller.dart] CameraController::_initializeWithDescription (0x5a91dc)
    //     0x5a9430: ldr             x1, [x1, #0x3a0]
    // 0x5a9434: r0 = AllocateClosure()
    //     0x5a9434: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5a9438: ldur            x16, [fp, #-0x88]
    // 0x5a943c: stp             x0, x16, [SP, #-0x10]!
    // 0x5a9440: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x5a9440: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x5a9444: r0 = listen()
    //     0x5a9444: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0x5a9448: add             SP, SP, #0x10
    // 0x5a944c: ldur            x1, [fp, #-0x78]
    // 0x5a9450: StoreField: r1->field_4b = r0
    //     0x5a9450: stur            w0, [x1, #0x4b]
    //     0x5a9454: tbz             w0, #0, #0x5a9470
    //     0x5a9458: ldurb           w16, [x1, #-1]
    //     0x5a945c: ldurb           w17, [x0, #-1]
    //     0x5a9460: and             x16, x17, x16, lsr #2
    //     0x5a9464: tst             x16, HEAP, lsr #32
    //     0x5a9468: b.eq            #0x5a9470
    //     0x5a946c: bl              #0xd6826c
    // 0x5a9470: r0 = LoadStaticField(0xac8)
    //     0x5a9470: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a9474: ldr             x0, [x0, #0x1590]
    // 0x5a9478: LoadField: r2 = r1->field_2b
    //     0x5a9478: ldur            w2, [x1, #0x2b]
    // 0x5a947c: DecompressPointer r2
    //     0x5a947c: add             x2, x2, HEAP, lsl #32
    // 0x5a9480: LoadField: r3 = r1->field_2f
    //     0x5a9480: ldur            w3, [x1, #0x2f]
    // 0x5a9484: DecompressPointer r3
    //     0x5a9484: add             x3, x3, HEAP, lsl #32
    // 0x5a9488: r4 = LoadClassIdInstr(r0)
    //     0x5a9488: ldur            x4, [x0, #-1]
    //     0x5a948c: ubfx            x4, x4, #0xc, #0x14
    // 0x5a9490: ldur            x16, [fp, #-0x70]
    // 0x5a9494: stp             x16, x0, [SP, #-0x10]!
    // 0x5a9498: stp             x3, x2, [SP, #-0x10]!
    // 0x5a949c: mov             x0, x4
    // 0x5a94a0: r0 = GDT[cid_x0 + -0x610]()
    //     0x5a94a0: sub             lr, x0, #0x610
    //     0x5a94a4: ldr             lr, [x21, lr, lsl #3]
    //     0x5a94a8: blr             lr
    // 0x5a94ac: add             SP, SP, #0x20
    // 0x5a94b0: mov             x1, x0
    // 0x5a94b4: stur            x1, [fp, #-0x88]
    // 0x5a94b8: r0 = Await()
    //     0x5a94b8: bl              #0x4b8e6c  ; AwaitStub
    // 0x5a94bc: r1 = LoadInt32Instr(r0)
    //     0x5a94bc: sbfx            x1, x0, #1, #0x1f
    //     0x5a94c0: tbz             w0, #0, #0x5a94c8
    //     0x5a94c4: ldur            x1, [x0, #7]
    // 0x5a94c8: ldur            x0, [fp, #-0x78]
    // 0x5a94cc: stur            x1, [fp, #-0xa8]
    // 0x5a94d0: StoreField: r0->field_37 = r1
    //     0x5a94d0: stur            x1, [x0, #0x37]
    // 0x5a94d4: r2 = LoadStaticField(0xac8)
    //     0x5a94d4: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0x5a94d8: ldr             x2, [x2, #0x1590]
    // 0x5a94dc: stur            x2, [fp, #-0x88]
    // 0x5a94e0: r3 = LoadClassIdInstr(r2)
    //     0x5a94e0: ldur            x3, [x2, #-1]
    //     0x5a94e4: ubfx            x3, x3, #0xc, #0x14
    // 0x5a94e8: lsl             x3, x3, #1
    // 0x5a94ec: r17 = 9914
    //     0x5a94ec: mov             x17, #0x26ba
    // 0x5a94f0: cmp             w3, w17
    // 0x5a94f4: b.ne            #0x5a9524
    // 0x5a94f8: stp             x1, x2, [SP, #-0x10]!
    // 0x5a94fc: r0 = _cameraEvents()
    //     0x5a94fc: bl              #0x5aa890  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_cameraEvents
    // 0x5a9500: add             SP, SP, #0x10
    // 0x5a9504: r16 = <CameraEvent, CameraInitializedEvent>
    //     0x5a9504: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d3a8] TypeArguments: <CameraEvent, CameraInitializedEvent>
    //     0x5a9508: ldr             x16, [x16, #0x3a8]
    // 0x5a950c: stp             x0, x16, [SP, #-0x10]!
    // 0x5a9510: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x5a9510: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x5a9514: r0 = Where.whereType()
    //     0x5a9514: bl              #0x5aa93c  ; [package:stream_transform/src/where.dart] ::Where.whereType
    // 0x5a9518: add             SP, SP, #0x10
    // 0x5a951c: mov             x1, x0
    // 0x5a9520: b               #0x5a9594
    // 0x5a9524: r17 = 9916
    //     0x5a9524: mov             x17, #0x26bc
    // 0x5a9528: cmp             w3, w17
    // 0x5a952c: b.ne            #0x5a9564
    // 0x5a9530: ldur            x0, [fp, #-0xa8]
    // 0x5a9534: ldur            x16, [fp, #-0x88]
    // 0x5a9538: stp             x0, x16, [SP, #-0x10]!
    // 0x5a953c: r0 = _cameraEvents()
    //     0x5a953c: bl              #0x5aa7e4  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_cameraEvents
    // 0x5a9540: add             SP, SP, #0x10
    // 0x5a9544: r16 = <CameraEvent, CameraInitializedEvent>
    //     0x5a9544: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d3a8] TypeArguments: <CameraEvent, CameraInitializedEvent>
    //     0x5a9548: ldr             x16, [x16, #0x3a8]
    // 0x5a954c: stp             x0, x16, [SP, #-0x10]!
    // 0x5a9550: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x5a9550: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x5a9554: r0 = Where.whereType()
    //     0x5a9554: bl              #0x5aa93c  ; [package:stream_transform/src/where.dart] ::Where.whereType
    // 0x5a9558: add             SP, SP, #0x10
    // 0x5a955c: mov             x1, x0
    // 0x5a9560: b               #0x5a9594
    // 0x5a9564: ldur            x0, [fp, #-0xa8]
    // 0x5a9568: ldur            x16, [fp, #-0x88]
    // 0x5a956c: stp             x0, x16, [SP, #-0x10]!
    // 0x5a9570: r0 = _cameraEvents()
    //     0x5a9570: bl              #0x5aa63c  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_cameraEvents
    // 0x5a9574: add             SP, SP, #0x10
    // 0x5a9578: r16 = <CameraEvent, CameraInitializedEvent>
    //     0x5a9578: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d3a8] TypeArguments: <CameraEvent, CameraInitializedEvent>
    //     0x5a957c: ldr             x16, [x16, #0x3a8]
    // 0x5a9580: stp             x0, x16, [SP, #-0x10]!
    // 0x5a9584: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x5a9584: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x5a9588: r0 = Where.whereType()
    //     0x5a9588: bl              #0x5aa93c  ; [package:stream_transform/src/where.dart] ::Where.whereType
    // 0x5a958c: add             SP, SP, #0x10
    // 0x5a9590: mov             x1, x0
    // 0x5a9594: ldur            x0, [fp, #-0x78]
    // 0x5a9598: SaveReg r1
    //     0x5a9598: str             x1, [SP, #-8]!
    // 0x5a959c: r0 = first()
    //     0x5a959c: bl              #0x5aa0d4  ; [dart:async] Stream::first
    // 0x5a95a0: add             SP, SP, #8
    // 0x5a95a4: ldur            x2, [fp, #-0x80]
    // 0x5a95a8: r1 = Function '<anonymous closure>':.
    //     0x5a95a8: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d3b0] AnonymousClosure: (0x5ab788), in [package:camera/src/camera_controller.dart] CameraController::_initializeWithDescription (0x5a91dc)
    //     0x5a95ac: ldr             x1, [x1, #0x3b0]
    // 0x5a95b0: stur            x0, [fp, #-0x88]
    // 0x5a95b4: r0 = AllocateClosure()
    //     0x5a95b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5a95b8: r16 = <void?>
    //     0x5a95b8: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x5a95bc: ldur            lr, [fp, #-0x88]
    // 0x5a95c0: stp             lr, x16, [SP, #-0x10]!
    // 0x5a95c4: SaveReg r0
    //     0x5a95c4: str             x0, [SP, #-8]!
    // 0x5a95c8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a95c8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a95cc: r0 = then()
    //     0x5a95cc: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x5a95d0: add             SP, SP, #0x18
    // 0x5a95d4: r0 = LoadStaticField(0xac8)
    //     0x5a95d4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a95d8: ldr             x0, [x0, #0x1590]
    // 0x5a95dc: ldur            x1, [fp, #-0x78]
    // 0x5a95e0: LoadField: r2 = r1->field_37
    //     0x5a95e0: ldur            x2, [x1, #0x37]
    // 0x5a95e4: r3 = LoadClassIdInstr(r0)
    //     0x5a95e4: ldur            x3, [x0, #-1]
    //     0x5a95e8: ubfx            x3, x3, #0xc, #0x14
    // 0x5a95ec: stp             x2, x0, [SP, #-0x10]!
    // 0x5a95f0: r16 = Instance_ImageFormatGroup
    //     0x5a95f0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d3b8] Obj!ImageFormatGroup@b66a31
    //     0x5a95f4: ldr             x16, [x16, #0x3b8]
    // 0x5a95f8: SaveReg r16
    //     0x5a95f8: str             x16, [SP, #-8]!
    // 0x5a95fc: mov             x0, x3
    // 0x5a9600: r0 = GDT[cid_x0 + -0x5f8]()
    //     0x5a9600: sub             lr, x0, #0x5f8
    //     0x5a9604: ldr             lr, [x21, lr, lsl #3]
    //     0x5a9608: blr             lr
    // 0x5a960c: add             SP, SP, #0x18
    // 0x5a9610: mov             x1, x0
    // 0x5a9614: stur            x1, [fp, #-0x80]
    // 0x5a9618: r0 = Await()
    //     0x5a9618: bl              #0x4b8e6c  ; AwaitStub
    // 0x5a961c: ldur            x0, [fp, #-0x78]
    // 0x5a9620: LoadField: r3 = r0->field_27
    //     0x5a9620: ldur            w3, [x0, #0x27]
    // 0x5a9624: DecompressPointer r3
    //     0x5a9624: add             x3, x3, HEAP, lsl #32
    // 0x5a9628: stur            x3, [fp, #-0x80]
    // 0x5a962c: r1 = Function '<anonymous closure>':.
    //     0x5a962c: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d3c0] AnonymousClosure: (0x5ab748), in [package:camera/src/camera_controller.dart] CameraController::_initializeWithDescription (0x5a91dc)
    //     0x5a9630: ldr             x1, [x1, #0x3c0]
    // 0x5a9634: r2 = Null
    //     0x5a9634: mov             x2, NULL
    // 0x5a9638: r0 = AllocateClosure()
    //     0x5a9638: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5a963c: r16 = <Size?>
    //     0x5a963c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0x5a9640: ldr             x16, [x16, #0xba8]
    // 0x5a9644: ldur            lr, [fp, #-0x90]
    // 0x5a9648: stp             lr, x16, [SP, #-0x10]!
    // 0x5a964c: SaveReg r0
    //     0x5a964c: str             x0, [SP, #-8]!
    // 0x5a9650: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a9650: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a9654: r0 = then()
    //     0x5a9654: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x5a9658: add             SP, SP, #0x18
    // 0x5a965c: mov             x1, x0
    // 0x5a9660: stur            x1, [fp, #-0x88]
    // 0x5a9664: r0 = Await()
    //     0x5a9664: bl              #0x4b8e6c  ; AwaitStub
    // 0x5a9668: r1 = Function '<anonymous closure>':.
    //     0x5a9668: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d3c8] AnonymousClosure: (0xcec1c8), in [package:camera/src/camera_controller.dart] CameraController::_initializeWithDescription (0x5a91dc)
    //     0x5a966c: ldr             x1, [x1, #0x3c8]
    // 0x5a9670: r2 = Null
    //     0x5a9670: mov             x2, NULL
    // 0x5a9674: stur            x0, [fp, #-0x88]
    // 0x5a9678: r0 = AllocateClosure()
    //     0x5a9678: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5a967c: r16 = <ExposureMode?>
    //     0x5a967c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d3d0] TypeArguments: <ExposureMode?>
    //     0x5a9680: ldr             x16, [x16, #0x3d0]
    // 0x5a9684: ldur            lr, [fp, #-0x90]
    // 0x5a9688: stp             lr, x16, [SP, #-0x10]!
    // 0x5a968c: SaveReg r0
    //     0x5a968c: str             x0, [SP, #-8]!
    // 0x5a9690: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a9690: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a9694: r0 = then()
    //     0x5a9694: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x5a9698: add             SP, SP, #0x18
    // 0x5a969c: mov             x1, x0
    // 0x5a96a0: stur            x1, [fp, #-0x98]
    // 0x5a96a4: r0 = Await()
    //     0x5a96a4: bl              #0x4b8e6c  ; AwaitStub
    // 0x5a96a8: r1 = Function '<anonymous closure>':.
    //     0x5a96a8: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d3d8] AnonymousClosure: (0xd1d87c), in [package:camera/src/camera_controller.dart] CameraController::_initializeWithDescription (0x5a91dc)
    //     0x5a96ac: ldr             x1, [x1, #0x3d8]
    // 0x5a96b0: r2 = Null
    //     0x5a96b0: mov             x2, NULL
    // 0x5a96b4: stur            x0, [fp, #-0x98]
    // 0x5a96b8: r0 = AllocateClosure()
    //     0x5a96b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5a96bc: r16 = <FocusMode?>
    //     0x5a96bc: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d3e0] TypeArguments: <FocusMode?>
    //     0x5a96c0: ldr             x16, [x16, #0x3e0]
    // 0x5a96c4: ldur            lr, [fp, #-0x90]
    // 0x5a96c8: stp             lr, x16, [SP, #-0x10]!
    // 0x5a96cc: SaveReg r0
    //     0x5a96cc: str             x0, [SP, #-8]!
    // 0x5a96d0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a96d0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a96d4: r0 = then()
    //     0x5a96d4: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x5a96d8: add             SP, SP, #0x18
    // 0x5a96dc: mov             x1, x0
    // 0x5a96e0: stur            x1, [fp, #-0xa0]
    // 0x5a96e4: r0 = Await()
    //     0x5a96e4: bl              #0x4b8e6c  ; AwaitStub
    // 0x5a96e8: r1 = Function '<anonymous closure>':.
    //     0x5a96e8: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d3e8] AnonymousClosure: (0xcec0bc), in [package:camera/src/camera_controller.dart] CameraController::_initializeWithDescription (0x5a91dc)
    //     0x5a96ec: ldr             x1, [x1, #0x3e8]
    // 0x5a96f0: r2 = Null
    //     0x5a96f0: mov             x2, NULL
    // 0x5a96f4: stur            x0, [fp, #-0xa0]
    // 0x5a96f8: r0 = AllocateClosure()
    //     0x5a96f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5a96fc: r16 = <bool?>
    //     0x5a96fc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe630] TypeArguments: <bool?>
    //     0x5a9700: ldr             x16, [x16, #0x630]
    // 0x5a9704: ldur            lr, [fp, #-0x90]
    // 0x5a9708: stp             lr, x16, [SP, #-0x10]!
    // 0x5a970c: SaveReg r0
    //     0x5a970c: str             x0, [SP, #-8]!
    // 0x5a9710: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a9710: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a9714: r0 = then()
    //     0x5a9714: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x5a9718: add             SP, SP, #0x18
    // 0x5a971c: mov             x1, x0
    // 0x5a9720: stur            x1, [fp, #-0xb0]
    // 0x5a9724: r0 = Await()
    //     0x5a9724: bl              #0x4b8e6c  ; AwaitStub
    // 0x5a9728: r1 = Function '<anonymous closure>':.
    //     0x5a9728: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d3f0] AnonymousClosure: (0xcec048), in [package:camera/src/camera_controller.dart] CameraController::_initializeWithDescription (0x5a91dc)
    //     0x5a972c: ldr             x1, [x1, #0x3f0]
    // 0x5a9730: r2 = Null
    //     0x5a9730: mov             x2, NULL
    // 0x5a9734: stur            x0, [fp, #-0xb0]
    // 0x5a9738: r0 = AllocateClosure()
    //     0x5a9738: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5a973c: r16 = <bool?>
    //     0x5a973c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe630] TypeArguments: <bool?>
    //     0x5a9740: ldr             x16, [x16, #0x630]
    // 0x5a9744: ldur            lr, [fp, #-0x90]
    // 0x5a9748: stp             lr, x16, [SP, #-0x10]!
    // 0x5a974c: SaveReg r0
    //     0x5a974c: str             x0, [SP, #-8]!
    // 0x5a9750: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a9750: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a9754: r0 = then()
    //     0x5a9754: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x5a9758: add             SP, SP, #0x18
    // 0x5a975c: mov             x1, x0
    // 0x5a9760: stur            x1, [fp, #-0x90]
    // 0x5a9764: r0 = Await()
    //     0x5a9764: bl              #0x4b8e6c  ; AwaitStub
    // 0x5a9768: ldur            x16, [fp, #-0x80]
    // 0x5a976c: r30 = true
    //     0x5a976c: add             lr, NULL, #0x20  ; true
    // 0x5a9770: stp             lr, x16, [SP, #-0x10]!
    // 0x5a9774: ldur            x16, [fp, #-0x70]
    // 0x5a9778: ldur            lr, [fp, #-0x88]
    // 0x5a977c: stp             lr, x16, [SP, #-0x10]!
    // 0x5a9780: ldur            x16, [fp, #-0x98]
    // 0x5a9784: ldur            lr, [fp, #-0xa0]
    // 0x5a9788: stp             lr, x16, [SP, #-0x10]!
    // 0x5a978c: ldur            x16, [fp, #-0xb0]
    // 0x5a9790: stp             x0, x16, [SP, #-0x10]!
    // 0x5a9794: r4 = const [0, 0x8, 0x8, 0x1, description, 0x2, exposureMode, 0x4, exposurePointSupported, 0x6, focusMode, 0x5, focusPointSupported, 0x7, isInitialized, 0x1, previewSize, 0x3, null]
    //     0x5a9794: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d3f8] List(19) [0, 0x8, 0x8, 0x1, "description", 0x2, "exposureMode", 0x4, "exposurePointSupported", 0x6, "focusMode", 0x5, "focusPointSupported", 0x7, "isInitialized", 0x1, "previewSize", 0x3, Null]
    //     0x5a9798: ldr             x4, [x4, #0x3f8]
    // 0x5a979c: r0 = copyWith()
    //     0x5a979c: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x5a97a0: add             SP, SP, #0x40
    // 0x5a97a4: stur            x0, [fp, #-0x70]
    // 0x5a97a8: ldur            x16, [fp, #-0x78]
    // 0x5a97ac: stp             x0, x16, [SP, #-0x10]!
    // 0x5a97b0: r0 = value=()
    //     0x5a97b0: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x5a97b4: add             SP, SP, #0x10
    // 0x5a97b8: ldur            x0, [fp, #-0x78]
    // 0x5a97bc: r1 = true
    //     0x5a97bc: add             x1, NULL, #0x20  ; true
    // 0x5a97c0: StoreField: r0->field_47 = r1
    //     0x5a97c0: stur            w1, [x0, #0x47]
    // 0x5a97c4: r0 = Null
    //     0x5a97c4: mov             x0, NULL
    // 0x5a97c8: r0 = ReturnAsyncNotFuture()
    //     0x5a97c8: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x5a97cc: sub             SP, fp, #0xb0
    // 0x5a97d0: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x5a97d0: mov             x2, #0x76
    //     0x5a97d4: tbz             w0, #0, #0x5a97e4
    //     0x5a97d8: ldur            x2, [x0, #-1]
    //     0x5a97dc: ubfx            x2, x2, #0xc, #0x14
    //     0x5a97e0: lsl             x2, x2, #1
    // 0x5a97e4: cmp             w2, #0xf28
    // 0x5a97e8: b.ne            #0x5a9858
    // 0x5a97ec: b               #0x5a981c
    // 0x5a97f0: r0 = CameraException()
    //     0x5a97f0: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x5a97f4: mov             x1, x0
    // 0x5a97f8: r0 = "Disposed CameraController"
    //     0x5a97f8: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d290] "Disposed CameraController"
    //     0x5a97fc: ldr             x0, [x0, #0x290]
    // 0x5a9800: StoreField: r1->field_7 = r0
    //     0x5a9800: stur            w0, [x1, #7]
    // 0x5a9804: r0 = "initialize was called on a disposed CameraController"
    //     0x5a9804: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d400] "initialize was called on a disposed CameraController"
    //     0x5a9808: ldr             x0, [x0, #0x400]
    // 0x5a980c: StoreField: r1->field_b = r0
    //     0x5a980c: stur            w0, [x1, #0xb]
    // 0x5a9810: mov             x0, x1
    // 0x5a9814: r0 = Throw()
    //     0x5a9814: bl              #0xd67e38  ; ThrowStub
    // 0x5a9818: brk             #0
    // 0x5a981c: LoadField: r1 = r0->field_7
    //     0x5a981c: ldur            w1, [x0, #7]
    // 0x5a9820: DecompressPointer r1
    //     0x5a9820: add             x1, x1, HEAP, lsl #32
    // 0x5a9824: stur            x1, [fp, #-0x78]
    // 0x5a9828: LoadField: r2 = r0->field_b
    //     0x5a9828: ldur            w2, [x0, #0xb]
    // 0x5a982c: DecompressPointer r2
    //     0x5a982c: add             x2, x2, HEAP, lsl #32
    // 0x5a9830: stur            x2, [fp, #-0x70]
    // 0x5a9834: r0 = CameraException()
    //     0x5a9834: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x5a9838: mov             x1, x0
    // 0x5a983c: ldur            x0, [fp, #-0x78]
    // 0x5a9840: StoreField: r1->field_7 = r0
    //     0x5a9840: stur            w0, [x1, #7]
    // 0x5a9844: ldur            x0, [fp, #-0x70]
    // 0x5a9848: StoreField: r1->field_b = r0
    //     0x5a9848: stur            w0, [x1, #0xb]
    // 0x5a984c: mov             x0, x1
    // 0x5a9850: r0 = Throw()
    //     0x5a9850: bl              #0xd67e38  ; ThrowStub
    // 0x5a9854: brk             #0
    // 0x5a9858: r0 = ReThrow()
    //     0x5a9858: bl              #0xd67e14  ; ReThrowStub
    // 0x5a985c: brk             #0
    // 0x5a9860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a9860: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a9864: b               #0x5a9214
  }
  [closure] Size <anonymous closure>(dynamic, CameraInitializedEvent) {
    // ** addr: 0x5ab748, size: 0x40
    // 0x5ab748: EnterFrame
    //     0x5ab748: stp             fp, lr, [SP, #-0x10]!
    //     0x5ab74c: mov             fp, SP
    // 0x5ab750: AllocStack(0x10)
    //     0x5ab750: sub             SP, SP, #0x10
    // 0x5ab754: ldr             x0, [fp, #0x10]
    // 0x5ab758: LoadField: d0 = r0->field_f
    //     0x5ab758: ldur            d0, [x0, #0xf]
    // 0x5ab75c: stur            d0, [fp, #-0x10]
    // 0x5ab760: LoadField: d1 = r0->field_17
    //     0x5ab760: ldur            d1, [x0, #0x17]
    // 0x5ab764: stur            d1, [fp, #-8]
    // 0x5ab768: r0 = Size()
    //     0x5ab768: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x5ab76c: ldur            d0, [fp, #-0x10]
    // 0x5ab770: StoreField: r0->field_7 = d0
    //     0x5ab770: stur            d0, [x0, #7]
    // 0x5ab774: ldur            d0, [fp, #-8]
    // 0x5ab778: StoreField: r0->field_f = d0
    //     0x5ab778: stur            d0, [x0, #0xf]
    // 0x5ab77c: LeaveFrame
    //     0x5ab77c: mov             SP, fp
    //     0x5ab780: ldp             fp, lr, [SP], #0x10
    // 0x5ab784: ret
    //     0x5ab784: ret             
  }
  [closure] Null <anonymous closure>(dynamic, CameraInitializedEvent) {
    // ** addr: 0x5ab788, size: 0x54
    // 0x5ab788: EnterFrame
    //     0x5ab788: stp             fp, lr, [SP, #-0x10]!
    //     0x5ab78c: mov             fp, SP
    // 0x5ab790: ldr             x0, [fp, #0x18]
    // 0x5ab794: LoadField: r1 = r0->field_17
    //     0x5ab794: ldur            w1, [x0, #0x17]
    // 0x5ab798: DecompressPointer r1
    //     0x5ab798: add             x1, x1, HEAP, lsl #32
    // 0x5ab79c: CheckStackOverflow
    //     0x5ab79c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ab7a0: cmp             SP, x16
    //     0x5ab7a4: b.ls            #0x5ab7d4
    // 0x5ab7a8: LoadField: r0 = r1->field_13
    //     0x5ab7a8: ldur            w0, [x1, #0x13]
    // 0x5ab7ac: DecompressPointer r0
    //     0x5ab7ac: add             x0, x0, HEAP, lsl #32
    // 0x5ab7b0: ldr             x16, [fp, #0x10]
    // 0x5ab7b4: stp             x16, x0, [SP, #-0x10]!
    // 0x5ab7b8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x5ab7b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x5ab7bc: r0 = complete()
    //     0x5ab7bc: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x5ab7c0: add             SP, SP, #0x10
    // 0x5ab7c4: r0 = Null
    //     0x5ab7c4: mov             x0, NULL
    // 0x5ab7c8: LeaveFrame
    //     0x5ab7c8: mov             SP, fp
    //     0x5ab7cc: ldp             fp, lr, [SP], #0x10
    // 0x5ab7d0: ret
    //     0x5ab7d0: ret             
    // 0x5ab7d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ab7d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ab7d8: b               #0x5ab7a8
  }
  [closure] void <anonymous closure>(dynamic, DeviceOrientationChangedEvent) {
    // ** addr: 0x5ab7dc, size: 0x80
    // 0x5ab7dc: EnterFrame
    //     0x5ab7dc: stp             fp, lr, [SP, #-0x10]!
    //     0x5ab7e0: mov             fp, SP
    // 0x5ab7e4: AllocStack(0x8)
    //     0x5ab7e4: sub             SP, SP, #8
    // 0x5ab7e8: SetupParameters()
    //     0x5ab7e8: ldr             x0, [fp, #0x18]
    //     0x5ab7ec: ldur            w1, [x0, #0x17]
    //     0x5ab7f0: add             x1, x1, HEAP, lsl #32
    // 0x5ab7f4: CheckStackOverflow
    //     0x5ab7f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ab7f8: cmp             SP, x16
    //     0x5ab7fc: b.ls            #0x5ab854
    // 0x5ab800: LoadField: r0 = r1->field_f
    //     0x5ab800: ldur            w0, [x1, #0xf]
    // 0x5ab804: DecompressPointer r0
    //     0x5ab804: add             x0, x0, HEAP, lsl #32
    // 0x5ab808: stur            x0, [fp, #-8]
    // 0x5ab80c: LoadField: r1 = r0->field_27
    //     0x5ab80c: ldur            w1, [x0, #0x27]
    // 0x5ab810: DecompressPointer r1
    //     0x5ab810: add             x1, x1, HEAP, lsl #32
    // 0x5ab814: ldr             x2, [fp, #0x10]
    // 0x5ab818: LoadField: r3 = r2->field_7
    //     0x5ab818: ldur            w3, [x2, #7]
    // 0x5ab81c: DecompressPointer r3
    //     0x5ab81c: add             x3, x3, HEAP, lsl #32
    // 0x5ab820: stp             x3, x1, [SP, #-0x10]!
    // 0x5ab824: r4 = const [0, 0x2, 0x2, 0x1, deviceOrientation, 0x1, null]
    //     0x5ab824: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d408] List(7) [0, 0x2, 0x2, 0x1, "deviceOrientation", 0x1, Null]
    //     0x5ab828: ldr             x4, [x4, #0x408]
    // 0x5ab82c: r0 = copyWith()
    //     0x5ab82c: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x5ab830: add             SP, SP, #0x10
    // 0x5ab834: ldur            x16, [fp, #-8]
    // 0x5ab838: stp             x0, x16, [SP, #-0x10]!
    // 0x5ab83c: r0 = value=()
    //     0x5ab83c: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x5ab840: add             SP, SP, #0x10
    // 0x5ab844: r0 = Null
    //     0x5ab844: mov             x0, NULL
    // 0x5ab848: LeaveFrame
    //     0x5ab848: mov             SP, fp
    //     0x5ab84c: ldp             fp, lr, [SP], #0x10
    // 0x5ab850: ret
    //     0x5ab850: ret             
    // 0x5ab854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ab854: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ab858: b               #0x5ab800
  }
  get _ description(/* No info */) {
    // ** addr: 0x5abe58, size: 0x18
    // 0x5abe58: ldr             x1, [SP]
    // 0x5abe5c: LoadField: r2 = r1->field_27
    //     0x5abe5c: ldur            w2, [x1, #0x27]
    // 0x5abe60: DecompressPointer r2
    //     0x5abe60: add             x2, x2, HEAP, lsl #32
    // 0x5abe64: LoadField: r0 = r2->field_4b
    //     0x5abe64: ldur            w0, [x2, #0x4b]
    // 0x5abe68: DecompressPointer r0
    //     0x5abe68: add             x0, x0, HEAP, lsl #32
    // 0x5abe6c: ret
    //     0x5abe6c: ret             
  }
  _ CameraController(/* No info */) {
    // ** addr: 0x5abe70, size: 0x144
    // 0x5abe70: EnterFrame
    //     0x5abe70: stp             fp, lr, [SP, #-0x10]!
    //     0x5abe74: mov             fp, SP
    // 0x5abe78: r2 = false
    //     0x5abe78: add             x2, NULL, #0x30  ; false
    // 0x5abe7c: r1 = Instance_ImageFormatGroup
    //     0x5abe7c: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d3b8] Obj!ImageFormatGroup@b66a31
    //     0x5abe80: ldr             x1, [x1, #0x3b8]
    // 0x5abe84: r0 = -1
    //     0x5abe84: mov             x0, #-1
    // 0x5abe88: CheckStackOverflow
    //     0x5abe88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5abe8c: cmp             SP, x16
    //     0x5abe90: b.ls            #0x5abfac
    // 0x5abe94: ldr             x3, [fp, #0x28]
    // 0x5abe98: StoreField: r3->field_37 = r0
    //     0x5abe98: stur            x0, [x3, #0x37]
    // 0x5abe9c: StoreField: r3->field_3f = r2
    //     0x5abe9c: stur            w2, [x3, #0x3f]
    // 0x5abea0: ldr             x0, [fp, #0x18]
    // 0x5abea4: StoreField: r3->field_2b = r0
    //     0x5abea4: stur            w0, [x3, #0x2b]
    //     0x5abea8: ldurb           w16, [x3, #-1]
    //     0x5abeac: ldurb           w17, [x0, #-1]
    //     0x5abeb0: and             x16, x17, x16, lsr #2
    //     0x5abeb4: tst             x16, HEAP, lsr #32
    //     0x5abeb8: b.eq            #0x5abec0
    //     0x5abebc: bl              #0xd682ac
    // 0x5abec0: ldr             x0, [fp, #0x10]
    // 0x5abec4: StoreField: r3->field_2f = r0
    //     0x5abec4: stur            w0, [x3, #0x2f]
    // 0x5abec8: StoreField: r3->field_33 = r1
    //     0x5abec8: stur            w1, [x3, #0x33]
    // 0x5abecc: r0 = CameraValue()
    //     0x5abecc: bl              #0x5aa0c8  ; AllocateCameraValueStub -> CameraValue (size=0x50)
    // 0x5abed0: mov             x1, x0
    // 0x5abed4: r0 = false
    //     0x5abed4: add             x0, NULL, #0x30  ; false
    // 0x5abed8: StoreField: r1->field_7 = r0
    //     0x5abed8: stur            w0, [x1, #7]
    // 0x5abedc: StoreField: r1->field_f = r0
    //     0x5abedc: stur            w0, [x1, #0xf]
    // 0x5abee0: StoreField: r1->field_b = r0
    //     0x5abee0: stur            w0, [x1, #0xb]
    // 0x5abee4: StoreField: r1->field_13 = r0
    //     0x5abee4: stur            w0, [x1, #0x13]
    // 0x5abee8: r2 = Instance_FlashMode
    //     0x5abee8: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d558] Obj!FlashMode@b66b11
    //     0x5abeec: ldr             x2, [x2, #0x558]
    // 0x5abef0: StoreField: r1->field_2b = r2
    //     0x5abef0: stur            w2, [x1, #0x2b]
    // 0x5abef4: r2 = Instance_ExposureMode
    //     0x5abef4: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d560] Obj!ExposureMode@b66b91
    //     0x5abef8: ldr             x2, [x2, #0x560]
    // 0x5abefc: StoreField: r1->field_2f = r2
    //     0x5abefc: stur            w2, [x1, #0x2f]
    // 0x5abf00: r2 = Instance_FocusMode
    //     0x5abf00: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d568] Obj!FocusMode@b66ad1
    //     0x5abf04: ldr             x2, [x2, #0x568]
    // 0x5abf08: StoreField: r1->field_33 = r2
    //     0x5abf08: stur            w2, [x1, #0x33]
    // 0x5abf0c: StoreField: r1->field_37 = r0
    //     0x5abf0c: stur            w0, [x1, #0x37]
    // 0x5abf10: StoreField: r1->field_3b = r0
    //     0x5abf10: stur            w0, [x1, #0x3b]
    // 0x5abf14: r2 = Instance_DeviceOrientation
    //     0x5abf14: ldr             x2, [PP, #0xe28]  ; [pp+0xe28] Obj!DeviceOrientation@b64311
    // 0x5abf18: StoreField: r1->field_3f = r2
    //     0x5abf18: stur            w2, [x1, #0x3f]
    // 0x5abf1c: ldr             x2, [fp, #0x20]
    // 0x5abf20: StoreField: r1->field_4b = r2
    //     0x5abf20: stur            w2, [x1, #0x4b]
    // 0x5abf24: StoreField: r1->field_1b = r0
    //     0x5abf24: stur            w0, [x1, #0x1b]
    // 0x5abf28: StoreField: r1->field_17 = r0
    //     0x5abf28: stur            w0, [x1, #0x17]
    // 0x5abf2c: mov             x0, x1
    // 0x5abf30: ldr             x1, [fp, #0x28]
    // 0x5abf34: StoreField: r1->field_27 = r0
    //     0x5abf34: stur            w0, [x1, #0x27]
    //     0x5abf38: ldurb           w16, [x1, #-1]
    //     0x5abf3c: ldurb           w17, [x0, #-1]
    //     0x5abf40: and             x16, x17, x16, lsr #2
    //     0x5abf44: tst             x16, HEAP, lsr #32
    //     0x5abf48: b.eq            #0x5abf50
    //     0x5abf4c: bl              #0xd6826c
    // 0x5abf50: r0 = 0
    //     0x5abf50: mov             x0, #0
    // 0x5abf54: StoreField: r1->field_7 = r0
    //     0x5abf54: stur            x0, [x1, #7]
    // 0x5abf58: StoreField: r1->field_13 = r0
    //     0x5abf58: stur            x0, [x1, #0x13]
    // 0x5abf5c: StoreField: r1->field_1b = r0
    //     0x5abf5c: stur            x0, [x1, #0x1b]
    // 0x5abf60: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x5abf60: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5abf64: ldr             x0, [x0, #0x1580]
    //     0x5abf68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5abf6c: cmp             w0, w16
    //     0x5abf70: b.ne            #0x5abf7c
    //     0x5abf74: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x5abf78: bl              #0xd67cdc
    // 0x5abf7c: ldr             x1, [fp, #0x28]
    // 0x5abf80: StoreField: r1->field_f = r0
    //     0x5abf80: stur            w0, [x1, #0xf]
    //     0x5abf84: ldurb           w16, [x1, #-1]
    //     0x5abf88: ldurb           w17, [x0, #-1]
    //     0x5abf8c: and             x16, x17, x16, lsr #2
    //     0x5abf90: tst             x16, HEAP, lsr #32
    //     0x5abf94: b.eq            #0x5abf9c
    //     0x5abf98: bl              #0xd6826c
    // 0x5abf9c: r0 = Null
    //     0x5abf9c: mov             x0, NULL
    // 0x5abfa0: LeaveFrame
    //     0x5abfa0: mov             SP, fp
    //     0x5abfa4: ldp             fp, lr, [SP], #0x10
    // 0x5abfa8: ret
    //     0x5abfa8: ret             
    // 0x5abfac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5abfac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5abfb0: b               #0x5abe94
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6e7e60, size: 0x4c
    // 0x6e7e60: EnterFrame
    //     0x6e7e60: stp             fp, lr, [SP, #-0x10]!
    //     0x6e7e64: mov             fp, SP
    // 0x6e7e68: CheckStackOverflow
    //     0x6e7e68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e7e6c: cmp             SP, x16
    //     0x6e7e70: b.ls            #0x6e7ea4
    // 0x6e7e74: ldr             x0, [fp, #0x18]
    // 0x6e7e78: LoadField: r1 = r0->field_3f
    //     0x6e7e78: ldur            w1, [x0, #0x3f]
    // 0x6e7e7c: DecompressPointer r1
    //     0x6e7e7c: add             x1, x1, HEAP, lsl #32
    // 0x6e7e80: tbz             w1, #4, #0x6e7e94
    // 0x6e7e84: ldr             x16, [fp, #0x10]
    // 0x6e7e88: stp             x16, x0, [SP, #-0x10]!
    // 0x6e7e8c: r0 = removeListener()
    //     0x6e7e8c: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x6e7e90: add             SP, SP, #0x10
    // 0x6e7e94: r0 = Null
    //     0x6e7e94: mov             x0, NULL
    // 0x6e7e98: LeaveFrame
    //     0x6e7e98: mov             SP, fp
    //     0x6e7e9c: ldp             fp, lr, [SP], #0x10
    // 0x6e7ea0: ret
    //     0x6e7ea0: ret             
    // 0x6e7ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e7ea4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e7ea8: b               #0x6e7e74
  }
  _ setZoomLevel(/* No info */) {
    // ** addr: 0x9b11d4, size: 0x118
    // 0x9b11d4: EnterFrame
    //     0x9b11d4: stp             fp, lr, [SP, #-0x10]!
    //     0x9b11d8: mov             fp, SP
    // 0x9b11dc: AllocStack(0x40)
    //     0x9b11dc: sub             SP, SP, #0x40
    // 0x9b11e0: CheckStackOverflow
    //     0x9b11e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b11e4: cmp             SP, x16
    //     0x9b11e8: b.ls            #0x9b12e4
    // 0x9b11ec: ldr             x16, [fp, #0x18]
    // 0x9b11f0: r30 = "setZoomLevel"
    //     0x9b11f0: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d268] "setZoomLevel"
    //     0x9b11f4: ldr             lr, [lr, #0x268]
    // 0x9b11f8: stp             lr, x16, [SP, #-0x10]!
    // 0x9b11fc: r0 = _throwIfNotInitialized()
    //     0x9b11fc: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0x9b1200: add             SP, SP, #0x10
    // 0x9b1204: ldr             x0, [fp, #0x18]
    // 0x9b1208: ldr             d0, [fp, #0x10]
    // 0x9b120c: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9b120c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9b1210: ldr             x0, [x0, #0x1590]
    //     0x9b1214: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9b1218: cmp             w0, w16
    //     0x9b121c: b.ne            #0x9b122c
    //     0x9b1220: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9b1224: ldr             x2, [x2, #0x270]
    //     0x9b1228: bl              #0xd67d44
    // 0x9b122c: mov             x2, x0
    // 0x9b1230: ldr             x0, [fp, #0x18]
    // 0x9b1234: LoadField: r3 = r0->field_37
    //     0x9b1234: ldur            x3, [x0, #0x37]
    // 0x9b1238: r0 = BoxInt64Instr(r3)
    //     0x9b1238: sbfiz           x0, x3, #1, #0x1f
    //     0x9b123c: cmp             x3, x0, asr #1
    //     0x9b1240: b.eq            #0x9b124c
    //     0x9b1244: bl              #0xd69bb8
    //     0x9b1248: stur            x3, [x0, #7]
    // 0x9b124c: r1 = LoadClassIdInstr(r2)
    //     0x9b124c: ldur            x1, [x2, #-1]
    //     0x9b1250: ubfx            x1, x1, #0xc, #0x14
    // 0x9b1254: stp             x0, x2, [SP, #-0x10]!
    // 0x9b1258: ldr             d0, [fp, #0x10]
    // 0x9b125c: SaveReg d0
    //     0x9b125c: str             d0, [SP, #-8]!
    // 0x9b1260: mov             x0, x1
    // 0x9b1264: r0 = GDT[cid_x0 + 0x16e]()
    //     0x9b1264: add             lr, x0, #0x16e
    //     0x9b1268: ldr             lr, [x21, lr, lsl #3]
    //     0x9b126c: blr             lr
    // 0x9b1270: add             SP, SP, #0x18
    // 0x9b1274: LeaveFrame
    //     0x9b1274: mov             SP, fp
    //     0x9b1278: ldp             fp, lr, [SP], #0x10
    // 0x9b127c: ret
    //     0x9b127c: ret             
    // 0x9b1280: sub             SP, fp, #0x40
    // 0x9b1284: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b1284: mov             x2, #0x76
    //     0x9b1288: tbz             w0, #0, #0x9b1298
    //     0x9b128c: ldur            x2, [x0, #-1]
    //     0x9b1290: ubfx            x2, x2, #0xc, #0x14
    //     0x9b1294: lsl             x2, x2, #1
    // 0x9b1298: cmp             w2, #0xf28
    // 0x9b129c: b.ne            #0x9b12dc
    // 0x9b12a0: LoadField: r1 = r0->field_7
    //     0x9b12a0: ldur            w1, [x0, #7]
    // 0x9b12a4: DecompressPointer r1
    //     0x9b12a4: add             x1, x1, HEAP, lsl #32
    // 0x9b12a8: stur            x1, [fp, #-0x40]
    // 0x9b12ac: LoadField: r2 = r0->field_b
    //     0x9b12ac: ldur            w2, [x0, #0xb]
    // 0x9b12b0: DecompressPointer r2
    //     0x9b12b0: add             x2, x2, HEAP, lsl #32
    // 0x9b12b4: stur            x2, [fp, #-0x38]
    // 0x9b12b8: r0 = CameraException()
    //     0x9b12b8: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b12bc: mov             x1, x0
    // 0x9b12c0: ldur            x0, [fp, #-0x40]
    // 0x9b12c4: StoreField: r1->field_7 = r0
    //     0x9b12c4: stur            w0, [x1, #7]
    // 0x9b12c8: ldur            x0, [fp, #-0x38]
    // 0x9b12cc: StoreField: r1->field_b = r0
    //     0x9b12cc: stur            w0, [x1, #0xb]
    // 0x9b12d0: mov             x0, x1
    // 0x9b12d4: r0 = Throw()
    //     0x9b12d4: bl              #0xd67e38  ; ThrowStub
    // 0x9b12d8: brk             #0
    // 0x9b12dc: r0 = ReThrow()
    //     0x9b12dc: bl              #0xd67e14  ; ReThrowStub
    // 0x9b12e0: brk             #0
    // 0x9b12e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b12e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b12e8: b               #0x9b11ec
  }
  _ resumePreview(/* No info */) async {
    // ** addr: 0x9b1958, size: 0x160
    // 0x9b1958: EnterFrame
    //     0x9b1958: stp             fp, lr, [SP, #-0x10]!
    //     0x9b195c: mov             fp, SP
    // 0x9b1960: AllocStack(0x50)
    //     0x9b1960: sub             SP, SP, #0x50
    // 0x9b1964: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x48 */)
    //     0x9b1964: stur            NULL, [fp, #-8]
    //     0x9b1968: mov             x0, #0
    //     0x9b196c: add             x1, fp, w0, sxtw #2
    //     0x9b1970: ldr             x1, [x1, #0x10]
    //     0x9b1974: stur            x1, [fp, #-0x48]
    // 0x9b1978: CheckStackOverflow
    //     0x9b1978: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b197c: cmp             SP, x16
    //     0x9b1980: b.ls            #0x9b1ab0
    // 0x9b1984: InitAsync() -> Future<void?>
    //     0x9b1984: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9b1988: bl              #0x4b92e4
    // 0x9b198c: ldur            x0, [fp, #-0x48]
    // 0x9b1990: LoadField: r1 = r0->field_27
    //     0x9b1990: ldur            w1, [x0, #0x27]
    // 0x9b1994: DecompressPointer r1
    //     0x9b1994: add             x1, x1, HEAP, lsl #32
    // 0x9b1998: LoadField: r2 = r1->field_1b
    //     0x9b1998: ldur            w2, [x1, #0x1b]
    // 0x9b199c: DecompressPointer r2
    //     0x9b199c: add             x2, x2, HEAP, lsl #32
    // 0x9b19a0: tbz             w2, #4, #0x9b19ac
    // 0x9b19a4: r0 = Null
    //     0x9b19a4: mov             x0, NULL
    // 0x9b19a8: r0 = ReturnAsyncNotFuture()
    //     0x9b19a8: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9b19ac: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9b19ac: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9b19b0: ldr             x0, [x0, #0x1590]
    //     0x9b19b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9b19b8: cmp             w0, w16
    //     0x9b19bc: b.ne            #0x9b19cc
    //     0x9b19c0: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9b19c4: ldr             x2, [x2, #0x270]
    //     0x9b19c8: bl              #0xd67d44
    // 0x9b19cc: ldur            x1, [fp, #-0x48]
    // 0x9b19d0: LoadField: r2 = r1->field_37
    //     0x9b19d0: ldur            x2, [x1, #0x37]
    // 0x9b19d4: r3 = LoadClassIdInstr(r0)
    //     0x9b19d4: ldur            x3, [x0, #-1]
    //     0x9b19d8: ubfx            x3, x3, #0xc, #0x14
    // 0x9b19dc: stp             x2, x0, [SP, #-0x10]!
    // 0x9b19e0: mov             x0, x3
    // 0x9b19e4: r0 = GDT[cid_x0 + 0x1d8]()
    //     0x9b19e4: add             lr, x0, #0x1d8
    //     0x9b19e8: ldr             lr, [x21, lr, lsl #3]
    //     0x9b19ec: blr             lr
    // 0x9b19f0: add             SP, SP, #0x10
    // 0x9b19f4: mov             x1, x0
    // 0x9b19f8: stur            x1, [fp, #-0x50]
    // 0x9b19fc: r0 = Await()
    //     0x9b19fc: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b1a00: ldur            x0, [fp, #-0x48]
    // 0x9b1a04: LoadField: r1 = r0->field_27
    //     0x9b1a04: ldur            w1, [x0, #0x27]
    // 0x9b1a08: DecompressPointer r1
    //     0x9b1a08: add             x1, x1, HEAP, lsl #32
    // 0x9b1a0c: r16 = false
    //     0x9b1a0c: add             x16, NULL, #0x30  ; false
    // 0x9b1a10: stp             x16, x1, [SP, #-0x10]!
    // 0x9b1a14: r16 = Instance_Optional
    //     0x9b1a14: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d660] Obj!Optional<DeviceOrientation>@b67d01
    //     0x9b1a18: ldr             x16, [x16, #0x660]
    // 0x9b1a1c: SaveReg r16
    //     0x9b1a1c: str             x16, [SP, #-8]!
    // 0x9b1a20: r4 = const [0, 0x3, 0x3, 0x1, isPreviewPaused, 0x1, previewPauseOrientation, 0x2, null]
    //     0x9b1a20: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d668] List(9) [0, 0x3, 0x3, 0x1, "isPreviewPaused", 0x1, "previewPauseOrientation", 0x2, Null]
    //     0x9b1a24: ldr             x4, [x4, #0x668]
    // 0x9b1a28: r0 = copyWith()
    //     0x9b1a28: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x9b1a2c: add             SP, SP, #0x18
    // 0x9b1a30: stur            x0, [fp, #-0x50]
    // 0x9b1a34: ldur            x16, [fp, #-0x48]
    // 0x9b1a38: stp             x0, x16, [SP, #-0x10]!
    // 0x9b1a3c: r0 = value=()
    //     0x9b1a3c: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x9b1a40: add             SP, SP, #0x10
    // 0x9b1a44: r0 = Null
    //     0x9b1a44: mov             x0, NULL
    // 0x9b1a48: r0 = ReturnAsyncNotFuture()
    //     0x9b1a48: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9b1a4c: sub             SP, fp, #0x50
    // 0x9b1a50: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b1a50: mov             x2, #0x76
    //     0x9b1a54: tbz             w0, #0, #0x9b1a64
    //     0x9b1a58: ldur            x2, [x0, #-1]
    //     0x9b1a5c: ubfx            x2, x2, #0xc, #0x14
    //     0x9b1a60: lsl             x2, x2, #1
    // 0x9b1a64: cmp             w2, #0xf28
    // 0x9b1a68: b.ne            #0x9b1aa8
    // 0x9b1a6c: LoadField: r1 = r0->field_7
    //     0x9b1a6c: ldur            w1, [x0, #7]
    // 0x9b1a70: DecompressPointer r1
    //     0x9b1a70: add             x1, x1, HEAP, lsl #32
    // 0x9b1a74: stur            x1, [fp, #-0x50]
    // 0x9b1a78: LoadField: r2 = r0->field_b
    //     0x9b1a78: ldur            w2, [x0, #0xb]
    // 0x9b1a7c: DecompressPointer r2
    //     0x9b1a7c: add             x2, x2, HEAP, lsl #32
    // 0x9b1a80: stur            x2, [fp, #-0x48]
    // 0x9b1a84: r0 = CameraException()
    //     0x9b1a84: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b1a88: mov             x1, x0
    // 0x9b1a8c: ldur            x0, [fp, #-0x50]
    // 0x9b1a90: StoreField: r1->field_7 = r0
    //     0x9b1a90: stur            w0, [x1, #7]
    // 0x9b1a94: ldur            x0, [fp, #-0x48]
    // 0x9b1a98: StoreField: r1->field_b = r0
    //     0x9b1a98: stur            w0, [x1, #0xb]
    // 0x9b1a9c: mov             x0, x1
    // 0x9b1aa0: r0 = Throw()
    //     0x9b1aa0: bl              #0xd67e38  ; ThrowStub
    // 0x9b1aa4: brk             #0
    // 0x9b1aa8: r0 = ReThrow()
    //     0x9b1aa8: bl              #0xd67e14  ; ReThrowStub
    // 0x9b1aac: brk             #0
    // 0x9b1ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b1ab0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b1ab4: b               #0x9b1984
  }
  _ pausePreview(/* No info */) async {
    // ** addr: 0x9b1de4, size: 0x18c
    // 0x9b1de4: EnterFrame
    //     0x9b1de4: stp             fp, lr, [SP, #-0x10]!
    //     0x9b1de8: mov             fp, SP
    // 0x9b1dec: AllocStack(0x58)
    //     0x9b1dec: sub             SP, SP, #0x58
    // 0x9b1df0: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x50 */)
    //     0x9b1df0: stur            NULL, [fp, #-8]
    //     0x9b1df4: mov             x0, #0
    //     0x9b1df8: add             x1, fp, w0, sxtw #2
    //     0x9b1dfc: ldr             x1, [x1, #0x10]
    //     0x9b1e00: stur            x1, [fp, #-0x50]
    // 0x9b1e04: CheckStackOverflow
    //     0x9b1e04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b1e08: cmp             SP, x16
    //     0x9b1e0c: b.ls            #0x9b1f68
    // 0x9b1e10: InitAsync() -> Future<void?>
    //     0x9b1e10: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9b1e14: bl              #0x4b92e4
    // 0x9b1e18: ldur            x0, [fp, #-0x50]
    // 0x9b1e1c: LoadField: r1 = r0->field_27
    //     0x9b1e1c: ldur            w1, [x0, #0x27]
    // 0x9b1e20: DecompressPointer r1
    //     0x9b1e20: add             x1, x1, HEAP, lsl #32
    // 0x9b1e24: LoadField: r2 = r1->field_1b
    //     0x9b1e24: ldur            w2, [x1, #0x1b]
    // 0x9b1e28: DecompressPointer r2
    //     0x9b1e28: add             x2, x2, HEAP, lsl #32
    // 0x9b1e2c: tbnz            w2, #4, #0x9b1e38
    // 0x9b1e30: r0 = Null
    //     0x9b1e30: mov             x0, NULL
    // 0x9b1e34: r0 = ReturnAsyncNotFuture()
    //     0x9b1e34: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9b1e38: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9b1e38: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9b1e3c: ldr             x0, [x0, #0x1590]
    //     0x9b1e40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9b1e44: cmp             w0, w16
    //     0x9b1e48: b.ne            #0x9b1e58
    //     0x9b1e4c: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9b1e50: ldr             x2, [x2, #0x270]
    //     0x9b1e54: bl              #0xd67d44
    // 0x9b1e58: ldur            x1, [fp, #-0x50]
    // 0x9b1e5c: LoadField: r2 = r1->field_37
    //     0x9b1e5c: ldur            x2, [x1, #0x37]
    // 0x9b1e60: r3 = LoadClassIdInstr(r0)
    //     0x9b1e60: ldur            x3, [x0, #-1]
    //     0x9b1e64: ubfx            x3, x3, #0xc, #0x14
    // 0x9b1e68: stp             x2, x0, [SP, #-0x10]!
    // 0x9b1e6c: mov             x0, x3
    // 0x9b1e70: r0 = GDT[cid_x0 + 0x17e]()
    //     0x9b1e70: add             lr, x0, #0x17e
    //     0x9b1e74: ldr             lr, [x21, lr, lsl #3]
    //     0x9b1e78: blr             lr
    // 0x9b1e7c: add             SP, SP, #0x10
    // 0x9b1e80: mov             x1, x0
    // 0x9b1e84: stur            x1, [fp, #-0x58]
    // 0x9b1e88: r0 = Await()
    //     0x9b1e88: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b1e8c: ldur            x0, [fp, #-0x50]
    // 0x9b1e90: LoadField: r2 = r0->field_27
    //     0x9b1e90: ldur            w2, [x0, #0x27]
    // 0x9b1e94: DecompressPointer r2
    //     0x9b1e94: add             x2, x2, HEAP, lsl #32
    // 0x9b1e98: stur            x2, [fp, #-0x58]
    // 0x9b1e9c: r1 = <DeviceOrientation>
    //     0x9b1e9c: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d690] TypeArguments: <DeviceOrientation>
    //     0x9b1ea0: ldr             x1, [x1, #0x690]
    // 0x9b1ea4: r0 = Optional()
    //     0x9b1ea4: bl              #0x9b1f70  ; AllocateOptionalStub -> Optional<X0> (size=0x10)
    // 0x9b1ea8: mov             x1, x0
    // 0x9b1eac: ldur            x0, [fp, #-0x58]
    // 0x9b1eb0: LoadField: r2 = r0->field_43
    //     0x9b1eb0: ldur            w2, [x0, #0x43]
    // 0x9b1eb4: DecompressPointer r2
    //     0x9b1eb4: add             x2, x2, HEAP, lsl #32
    // 0x9b1eb8: cmp             w2, NULL
    // 0x9b1ebc: b.ne            #0x9b1ec8
    // 0x9b1ec0: LoadField: r2 = r0->field_3f
    //     0x9b1ec0: ldur            w2, [x0, #0x3f]
    // 0x9b1ec4: DecompressPointer r2
    //     0x9b1ec4: add             x2, x2, HEAP, lsl #32
    // 0x9b1ec8: StoreField: r1->field_b = r2
    //     0x9b1ec8: stur            w2, [x1, #0xb]
    // 0x9b1ecc: r16 = true
    //     0x9b1ecc: add             x16, NULL, #0x20  ; true
    // 0x9b1ed0: stp             x16, x0, [SP, #-0x10]!
    // 0x9b1ed4: SaveReg r1
    //     0x9b1ed4: str             x1, [SP, #-8]!
    // 0x9b1ed8: r4 = const [0, 0x3, 0x3, 0x1, isPreviewPaused, 0x1, previewPauseOrientation, 0x2, null]
    //     0x9b1ed8: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d668] List(9) [0, 0x3, 0x3, 0x1, "isPreviewPaused", 0x1, "previewPauseOrientation", 0x2, Null]
    //     0x9b1edc: ldr             x4, [x4, #0x668]
    // 0x9b1ee0: r0 = copyWith()
    //     0x9b1ee0: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x9b1ee4: add             SP, SP, #0x18
    // 0x9b1ee8: stur            x0, [fp, #-0x58]
    // 0x9b1eec: ldur            x16, [fp, #-0x50]
    // 0x9b1ef0: stp             x0, x16, [SP, #-0x10]!
    // 0x9b1ef4: r0 = value=()
    //     0x9b1ef4: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x9b1ef8: add             SP, SP, #0x10
    // 0x9b1efc: r0 = Null
    //     0x9b1efc: mov             x0, NULL
    // 0x9b1f00: r0 = ReturnAsyncNotFuture()
    //     0x9b1f00: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9b1f04: sub             SP, fp, #0x58
    // 0x9b1f08: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b1f08: mov             x2, #0x76
    //     0x9b1f0c: tbz             w0, #0, #0x9b1f1c
    //     0x9b1f10: ldur            x2, [x0, #-1]
    //     0x9b1f14: ubfx            x2, x2, #0xc, #0x14
    //     0x9b1f18: lsl             x2, x2, #1
    // 0x9b1f1c: cmp             w2, #0xf28
    // 0x9b1f20: b.ne            #0x9b1f60
    // 0x9b1f24: LoadField: r1 = r0->field_7
    //     0x9b1f24: ldur            w1, [x0, #7]
    // 0x9b1f28: DecompressPointer r1
    //     0x9b1f28: add             x1, x1, HEAP, lsl #32
    // 0x9b1f2c: stur            x1, [fp, #-0x58]
    // 0x9b1f30: LoadField: r2 = r0->field_b
    //     0x9b1f30: ldur            w2, [x0, #0xb]
    // 0x9b1f34: DecompressPointer r2
    //     0x9b1f34: add             x2, x2, HEAP, lsl #32
    // 0x9b1f38: stur            x2, [fp, #-0x50]
    // 0x9b1f3c: r0 = CameraException()
    //     0x9b1f3c: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b1f40: mov             x1, x0
    // 0x9b1f44: ldur            x0, [fp, #-0x58]
    // 0x9b1f48: StoreField: r1->field_7 = r0
    //     0x9b1f48: stur            w0, [x1, #7]
    // 0x9b1f4c: ldur            x0, [fp, #-0x50]
    // 0x9b1f50: StoreField: r1->field_b = r0
    //     0x9b1f50: stur            w0, [x1, #0xb]
    // 0x9b1f54: mov             x0, x1
    // 0x9b1f58: r0 = Throw()
    //     0x9b1f58: bl              #0xd67e38  ; ThrowStub
    // 0x9b1f5c: brk             #0
    // 0x9b1f60: r0 = ReThrow()
    //     0x9b1f60: bl              #0xd67e14  ; ReThrowStub
    // 0x9b1f64: brk             #0
    // 0x9b1f68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b1f68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b1f6c: b               #0x9b1e10
  }
  _ stopVideoRecording(/* No info */) async {
    // ** addr: 0x9b1fac, size: 0x1d4
    // 0x9b1fac: EnterFrame
    //     0x9b1fac: stp             fp, lr, [SP, #-0x10]!
    //     0x9b1fb0: mov             fp, SP
    // 0x9b1fb4: AllocStack(0x58)
    //     0x9b1fb4: sub             SP, SP, #0x58
    // 0x9b1fb8: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x48 */)
    //     0x9b1fb8: stur            NULL, [fp, #-8]
    //     0x9b1fbc: mov             x0, #0
    //     0x9b1fc0: add             x1, fp, w0, sxtw #2
    //     0x9b1fc4: ldr             x1, [x1, #0x10]
    //     0x9b1fc8: stur            x1, [fp, #-0x48]
    // 0x9b1fcc: CheckStackOverflow
    //     0x9b1fcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b1fd0: cmp             SP, x16
    //     0x9b1fd4: b.ls            #0x9b2178
    // 0x9b1fd8: InitAsync() -> Future<XFile>
    //     0x9b1fd8: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d698] TypeArguments: <XFile>
    //     0x9b1fdc: ldr             x0, [x0, #0x698]
    //     0x9b1fe0: bl              #0x4b92e4
    // 0x9b1fe4: ldur            x16, [fp, #-0x48]
    // 0x9b1fe8: r30 = "stopVideoRecording"
    //     0x9b1fe8: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d6a0] "stopVideoRecording"
    //     0x9b1fec: ldr             lr, [lr, #0x6a0]
    // 0x9b1ff0: stp             lr, x16, [SP, #-0x10]!
    // 0x9b1ff4: r0 = _throwIfNotInitialized()
    //     0x9b1ff4: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0x9b1ff8: add             SP, SP, #0x10
    // 0x9b1ffc: ldur            x0, [fp, #-0x48]
    // 0x9b2000: LoadField: r1 = r0->field_27
    //     0x9b2000: ldur            w1, [x0, #0x27]
    // 0x9b2004: DecompressPointer r1
    //     0x9b2004: add             x1, x1, HEAP, lsl #32
    // 0x9b2008: LoadField: r2 = r1->field_f
    //     0x9b2008: ldur            w2, [x1, #0xf]
    // 0x9b200c: DecompressPointer r2
    //     0x9b200c: add             x2, x2, HEAP, lsl #32
    // 0x9b2010: tbnz            w2, #4, #0x9b2108
    // 0x9b2014: LoadField: r2 = r1->field_13
    //     0x9b2014: ldur            w2, [x1, #0x13]
    // 0x9b2018: DecompressPointer r2
    //     0x9b2018: add             x2, x2, HEAP, lsl #32
    // 0x9b201c: tbnz            w2, #4, #0x9b2038
    // 0x9b2020: SaveReg r0
    //     0x9b2020: str             x0, [SP, #-8]!
    // 0x9b2024: r0 = stopImageStream()
    //     0x9b2024: bl              #0x9b2180  ; [package:camera/src/camera_controller.dart] CameraController::stopImageStream
    // 0x9b2028: add             SP, SP, #8
    // 0x9b202c: mov             x1, x0
    // 0x9b2030: stur            x1, [fp, #-0x50]
    // 0x9b2034: r0 = Await()
    //     0x9b2034: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b2038: ldur            x0, [fp, #-0x48]
    // 0x9b203c: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9b203c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9b2040: ldr             x0, [x0, #0x1590]
    //     0x9b2044: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9b2048: cmp             w0, w16
    //     0x9b204c: b.ne            #0x9b205c
    //     0x9b2050: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9b2054: ldr             x2, [x2, #0x270]
    //     0x9b2058: bl              #0xd67d44
    // 0x9b205c: ldur            x1, [fp, #-0x48]
    // 0x9b2060: LoadField: r2 = r1->field_37
    //     0x9b2060: ldur            x2, [x1, #0x37]
    // 0x9b2064: r3 = LoadClassIdInstr(r0)
    //     0x9b2064: ldur            x3, [x0, #-1]
    //     0x9b2068: ubfx            x3, x3, #0xc, #0x14
    // 0x9b206c: stp             x2, x0, [SP, #-0x10]!
    // 0x9b2070: mov             x0, x3
    // 0x9b2074: r0 = GDT[cid_x0 + -0x75]()
    //     0x9b2074: sub             lr, x0, #0x75
    //     0x9b2078: ldr             lr, [x21, lr, lsl #3]
    //     0x9b207c: blr             lr
    // 0x9b2080: add             SP, SP, #0x10
    // 0x9b2084: mov             x1, x0
    // 0x9b2088: stur            x1, [fp, #-0x50]
    // 0x9b208c: r0 = Await()
    //     0x9b208c: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b2090: mov             x1, x0
    // 0x9b2094: ldur            x0, [fp, #-0x48]
    // 0x9b2098: stur            x1, [fp, #-0x50]
    // 0x9b209c: LoadField: r2 = r0->field_27
    //     0x9b209c: ldur            w2, [x0, #0x27]
    // 0x9b20a0: DecompressPointer r2
    //     0x9b20a0: add             x2, x2, HEAP, lsl #32
    // 0x9b20a4: r16 = false
    //     0x9b20a4: add             x16, NULL, #0x30  ; false
    // 0x9b20a8: stp             x16, x2, [SP, #-0x10]!
    // 0x9b20ac: r16 = Instance_Optional
    //     0x9b20ac: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d660] Obj!Optional<DeviceOrientation>@b67d01
    //     0x9b20b0: ldr             x16, [x16, #0x660]
    // 0x9b20b4: SaveReg r16
    //     0x9b20b4: str             x16, [SP, #-8]!
    // 0x9b20b8: r4 = const [0, 0x3, 0x3, 0x1, isRecordingVideo, 0x1, recordingOrientation, 0x2, null]
    //     0x9b20b8: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d6a8] List(9) [0, 0x3, 0x3, 0x1, "isRecordingVideo", 0x1, "recordingOrientation", 0x2, Null]
    //     0x9b20bc: ldr             x4, [x4, #0x6a8]
    // 0x9b20c0: r0 = copyWith()
    //     0x9b20c0: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x9b20c4: add             SP, SP, #0x18
    // 0x9b20c8: stur            x0, [fp, #-0x58]
    // 0x9b20cc: ldur            x16, [fp, #-0x48]
    // 0x9b20d0: stp             x0, x16, [SP, #-0x10]!
    // 0x9b20d4: r0 = value=()
    //     0x9b20d4: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x9b20d8: add             SP, SP, #0x10
    // 0x9b20dc: ldur            x0, [fp, #-0x50]
    // 0x9b20e0: r0 = ReturnAsync()
    //     0x9b20e0: b               #0x501858  ; ReturnAsyncStub
    // 0x9b20e4: sub             SP, fp, #0x58
    // 0x9b20e8: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b20e8: mov             x2, #0x76
    //     0x9b20ec: tbz             w0, #0, #0x9b20fc
    //     0x9b20f0: ldur            x2, [x0, #-1]
    //     0x9b20f4: ubfx            x2, x2, #0xc, #0x14
    //     0x9b20f8: lsl             x2, x2, #1
    // 0x9b20fc: cmp             w2, #0xf28
    // 0x9b2100: b.ne            #0x9b2170
    // 0x9b2104: b               #0x9b2134
    // 0x9b2108: r0 = CameraException()
    //     0x9b2108: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b210c: mov             x1, x0
    // 0x9b2110: r0 = "No video is recording"
    //     0x9b2110: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d6b0] "No video is recording"
    //     0x9b2114: ldr             x0, [x0, #0x6b0]
    // 0x9b2118: StoreField: r1->field_7 = r0
    //     0x9b2118: stur            w0, [x1, #7]
    // 0x9b211c: r0 = "stopVideoRecording was called when no video is recording."
    //     0x9b211c: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d6b8] "stopVideoRecording was called when no video is recording."
    //     0x9b2120: ldr             x0, [x0, #0x6b8]
    // 0x9b2124: StoreField: r1->field_b = r0
    //     0x9b2124: stur            w0, [x1, #0xb]
    // 0x9b2128: mov             x0, x1
    // 0x9b212c: r0 = Throw()
    //     0x9b212c: bl              #0xd67e38  ; ThrowStub
    // 0x9b2130: brk             #0
    // 0x9b2134: LoadField: r1 = r0->field_7
    //     0x9b2134: ldur            w1, [x0, #7]
    // 0x9b2138: DecompressPointer r1
    //     0x9b2138: add             x1, x1, HEAP, lsl #32
    // 0x9b213c: stur            x1, [fp, #-0x50]
    // 0x9b2140: LoadField: r2 = r0->field_b
    //     0x9b2140: ldur            w2, [x0, #0xb]
    // 0x9b2144: DecompressPointer r2
    //     0x9b2144: add             x2, x2, HEAP, lsl #32
    // 0x9b2148: stur            x2, [fp, #-0x48]
    // 0x9b214c: r0 = CameraException()
    //     0x9b214c: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b2150: mov             x1, x0
    // 0x9b2154: ldur            x0, [fp, #-0x50]
    // 0x9b2158: StoreField: r1->field_7 = r0
    //     0x9b2158: stur            w0, [x1, #7]
    // 0x9b215c: ldur            x0, [fp, #-0x48]
    // 0x9b2160: StoreField: r1->field_b = r0
    //     0x9b2160: stur            w0, [x1, #0xb]
    // 0x9b2164: mov             x0, x1
    // 0x9b2168: r0 = Throw()
    //     0x9b2168: bl              #0xd67e38  ; ThrowStub
    // 0x9b216c: brk             #0
    // 0x9b2170: r0 = ReThrow()
    //     0x9b2170: bl              #0xd67e14  ; ReThrowStub
    // 0x9b2174: brk             #0
    // 0x9b2178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b2178: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b217c: b               #0x9b1fd8
  }
  _ stopImageStream(/* No info */) async {
    // ** addr: 0x9b2180, size: 0x144
    // 0x9b2180: EnterFrame
    //     0x9b2180: stp             fp, lr, [SP, #-0x10]!
    //     0x9b2184: mov             fp, SP
    // 0x9b2188: AllocStack(0x50)
    //     0x9b2188: sub             SP, SP, #0x50
    // 0x9b218c: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x48 */)
    //     0x9b218c: stur            NULL, [fp, #-8]
    //     0x9b2190: mov             x0, #0
    //     0x9b2194: add             x1, fp, w0, sxtw #2
    //     0x9b2198: ldr             x1, [x1, #0x10]
    //     0x9b219c: stur            x1, [fp, #-0x48]
    // 0x9b21a0: CheckStackOverflow
    //     0x9b21a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b21a4: cmp             SP, x16
    //     0x9b21a8: b.ls            #0x9b22bc
    // 0x9b21ac: InitAsync() -> Future<void?>
    //     0x9b21ac: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9b21b0: bl              #0x4b92e4
    // 0x9b21b4: ldur            x16, [fp, #-0x48]
    // 0x9b21b8: r30 = "stopImageStream"
    //     0x9b21b8: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d6c0] "stopImageStream"
    //     0x9b21bc: ldr             lr, [lr, #0x6c0]
    // 0x9b21c0: stp             lr, x16, [SP, #-0x10]!
    // 0x9b21c4: r0 = _throwIfNotInitialized()
    //     0x9b21c4: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0x9b21c8: add             SP, SP, #0x10
    // 0x9b21cc: ldur            x0, [fp, #-0x48]
    // 0x9b21d0: LoadField: r1 = r0->field_27
    //     0x9b21d0: ldur            w1, [x0, #0x27]
    // 0x9b21d4: DecompressPointer r1
    //     0x9b21d4: add             x1, x1, HEAP, lsl #32
    // 0x9b21d8: LoadField: r2 = r1->field_13
    //     0x9b21d8: ldur            w2, [x1, #0x13]
    // 0x9b21dc: DecompressPointer r2
    //     0x9b21dc: add             x2, x2, HEAP, lsl #32
    // 0x9b21e0: tbnz            w2, #4, #0x9b224c
    // 0x9b21e4: r16 = false
    //     0x9b21e4: add             x16, NULL, #0x30  ; false
    // 0x9b21e8: stp             x16, x1, [SP, #-0x10]!
    // 0x9b21ec: r4 = const [0, 0x2, 0x2, 0x1, isStreamingImages, 0x1, null]
    //     0x9b21ec: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d6c8] List(7) [0, 0x2, 0x2, 0x1, "isStreamingImages", 0x1, Null]
    //     0x9b21f0: ldr             x4, [x4, #0x6c8]
    // 0x9b21f4: r0 = copyWith()
    //     0x9b21f4: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x9b21f8: add             SP, SP, #0x10
    // 0x9b21fc: stur            x0, [fp, #-0x50]
    // 0x9b2200: ldur            x16, [fp, #-0x48]
    // 0x9b2204: stp             x0, x16, [SP, #-0x10]!
    // 0x9b2208: r0 = value=()
    //     0x9b2208: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x9b220c: add             SP, SP, #0x10
    // 0x9b2210: r0 = Null
    //     0x9b2210: mov             x0, NULL
    // 0x9b2214: r0 = Await()
    //     0x9b2214: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b2218: ldur            x0, [fp, #-0x48]
    // 0x9b221c: StoreField: r0->field_43 = rNULL
    //     0x9b221c: stur            NULL, [x0, #0x43]
    // 0x9b2220: r0 = Null
    //     0x9b2220: mov             x0, NULL
    // 0x9b2224: r0 = ReturnAsyncNotFuture()
    //     0x9b2224: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9b2228: sub             SP, fp, #0x50
    // 0x9b222c: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b222c: mov             x2, #0x76
    //     0x9b2230: tbz             w0, #0, #0x9b2240
    //     0x9b2234: ldur            x2, [x0, #-1]
    //     0x9b2238: ubfx            x2, x2, #0xc, #0x14
    //     0x9b223c: lsl             x2, x2, #1
    // 0x9b2240: cmp             w2, #0xf28
    // 0x9b2244: b.ne            #0x9b22b4
    // 0x9b2248: b               #0x9b2278
    // 0x9b224c: r0 = CameraException()
    //     0x9b224c: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b2250: mov             x1, x0
    // 0x9b2254: r0 = "No camera is streaming images"
    //     0x9b2254: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d6d0] "No camera is streaming images"
    //     0x9b2258: ldr             x0, [x0, #0x6d0]
    // 0x9b225c: StoreField: r1->field_7 = r0
    //     0x9b225c: stur            w0, [x1, #7]
    // 0x9b2260: r0 = "stopImageStream was called when no camera is streaming images."
    //     0x9b2260: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d6d8] "stopImageStream was called when no camera is streaming images."
    //     0x9b2264: ldr             x0, [x0, #0x6d8]
    // 0x9b2268: StoreField: r1->field_b = r0
    //     0x9b2268: stur            w0, [x1, #0xb]
    // 0x9b226c: mov             x0, x1
    // 0x9b2270: r0 = Throw()
    //     0x9b2270: bl              #0xd67e38  ; ThrowStub
    // 0x9b2274: brk             #0
    // 0x9b2278: LoadField: r1 = r0->field_7
    //     0x9b2278: ldur            w1, [x0, #7]
    // 0x9b227c: DecompressPointer r1
    //     0x9b227c: add             x1, x1, HEAP, lsl #32
    // 0x9b2280: stur            x1, [fp, #-0x50]
    // 0x9b2284: LoadField: r2 = r0->field_b
    //     0x9b2284: ldur            w2, [x0, #0xb]
    // 0x9b2288: DecompressPointer r2
    //     0x9b2288: add             x2, x2, HEAP, lsl #32
    // 0x9b228c: stur            x2, [fp, #-0x48]
    // 0x9b2290: r0 = CameraException()
    //     0x9b2290: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b2294: mov             x1, x0
    // 0x9b2298: ldur            x0, [fp, #-0x50]
    // 0x9b229c: StoreField: r1->field_7 = r0
    //     0x9b229c: stur            w0, [x1, #7]
    // 0x9b22a0: ldur            x0, [fp, #-0x48]
    // 0x9b22a4: StoreField: r1->field_b = r0
    //     0x9b22a4: stur            w0, [x1, #0xb]
    // 0x9b22a8: mov             x0, x1
    // 0x9b22ac: r0 = Throw()
    //     0x9b22ac: bl              #0xd67e38  ; ThrowStub
    // 0x9b22b0: brk             #0
    // 0x9b22b4: r0 = ReThrow()
    //     0x9b22b4: bl              #0xd67e14  ; ReThrowStub
    // 0x9b22b8: brk             #0
    // 0x9b22bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b22bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b22c0: b               #0x9b21ac
  }
  _ startVideoRecording(/* No info */) async {
    // ** addr: 0x9b29b8, size: 0x1e8
    // 0x9b29b8: EnterFrame
    //     0x9b29b8: stp             fp, lr, [SP, #-0x10]!
    //     0x9b29bc: mov             fp, SP
    // 0x9b29c0: AllocStack(0x60)
    //     0x9b29c0: sub             SP, SP, #0x60
    // 0x9b29c4: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x58 */)
    //     0x9b29c4: stur            NULL, [fp, #-8]
    //     0x9b29c8: mov             x0, #0
    //     0x9b29cc: add             x1, fp, w0, sxtw #2
    //     0x9b29d0: ldr             x1, [x1, #0x10]
    //     0x9b29d4: stur            x1, [fp, #-0x58]
    // 0x9b29d8: CheckStackOverflow
    //     0x9b29d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b29dc: cmp             SP, x16
    //     0x9b29e0: b.ls            #0x9b2b98
    // 0x9b29e4: InitAsync() -> Future<void?>
    //     0x9b29e4: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9b29e8: bl              #0x4b92e4
    // 0x9b29ec: ldur            x16, [fp, #-0x58]
    // 0x9b29f0: r30 = "startVideoRecording"
    //     0x9b29f0: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d730] "startVideoRecording"
    //     0x9b29f4: ldr             lr, [lr, #0x730]
    // 0x9b29f8: stp             lr, x16, [SP, #-0x10]!
    // 0x9b29fc: r0 = _throwIfNotInitialized()
    //     0x9b29fc: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0x9b2a00: add             SP, SP, #0x10
    // 0x9b2a04: ldur            x0, [fp, #-0x58]
    // 0x9b2a08: LoadField: r1 = r0->field_27
    //     0x9b2a08: ldur            w1, [x0, #0x27]
    // 0x9b2a0c: DecompressPointer r1
    //     0x9b2a0c: add             x1, x1, HEAP, lsl #32
    // 0x9b2a10: LoadField: r2 = r1->field_f
    //     0x9b2a10: ldur            w2, [x1, #0xf]
    // 0x9b2a14: DecompressPointer r2
    //     0x9b2a14: add             x2, x2, HEAP, lsl #32
    // 0x9b2a18: tbz             w2, #4, #0x9b2b28
    // 0x9b2a1c: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9b2a1c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9b2a20: ldr             x0, [x0, #0x1590]
    //     0x9b2a24: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9b2a28: cmp             w0, w16
    //     0x9b2a2c: b.ne            #0x9b2a3c
    //     0x9b2a30: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9b2a34: ldr             x2, [x2, #0x270]
    //     0x9b2a38: bl              #0xd67d44
    // 0x9b2a3c: stur            x0, [fp, #-0x60]
    // 0x9b2a40: r0 = VideoCaptureOptions()
    //     0x9b2a40: bl              #0x9b2ba0  ; AllocateVideoCaptureOptionsStub -> VideoCaptureOptions (size=0x1c)
    // 0x9b2a44: ldur            x1, [fp, #-0x58]
    // 0x9b2a48: LoadField: r2 = r1->field_37
    //     0x9b2a48: ldur            x2, [x1, #0x37]
    // 0x9b2a4c: StoreField: r0->field_7 = r2
    //     0x9b2a4c: stur            x2, [x0, #7]
    // 0x9b2a50: ldur            x2, [fp, #-0x60]
    // 0x9b2a54: r3 = LoadClassIdInstr(r2)
    //     0x9b2a54: ldur            x3, [x2, #-1]
    //     0x9b2a58: ubfx            x3, x3, #0xc, #0x14
    // 0x9b2a5c: stp             x0, x2, [SP, #-0x10]!
    // 0x9b2a60: mov             x0, x3
    // 0x9b2a64: r0 = GDT[cid_x0 + -0x97]()
    //     0x9b2a64: sub             lr, x0, #0x97
    //     0x9b2a68: ldr             lr, [x21, lr, lsl #3]
    //     0x9b2a6c: blr             lr
    // 0x9b2a70: add             SP, SP, #0x10
    // 0x9b2a74: mov             x1, x0
    // 0x9b2a78: stur            x1, [fp, #-0x60]
    // 0x9b2a7c: r0 = Await()
    //     0x9b2a7c: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b2a80: ldur            x0, [fp, #-0x58]
    // 0x9b2a84: LoadField: r2 = r0->field_27
    //     0x9b2a84: ldur            w2, [x0, #0x27]
    // 0x9b2a88: DecompressPointer r2
    //     0x9b2a88: add             x2, x2, HEAP, lsl #32
    // 0x9b2a8c: stur            x2, [fp, #-0x60]
    // 0x9b2a90: r1 = <DeviceOrientation>
    //     0x9b2a90: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d690] TypeArguments: <DeviceOrientation>
    //     0x9b2a94: ldr             x1, [x1, #0x690]
    // 0x9b2a98: r0 = Optional()
    //     0x9b2a98: bl              #0x9b1f70  ; AllocateOptionalStub -> Optional<X0> (size=0x10)
    // 0x9b2a9c: mov             x1, x0
    // 0x9b2aa0: ldur            x0, [fp, #-0x60]
    // 0x9b2aa4: LoadField: r2 = r0->field_43
    //     0x9b2aa4: ldur            w2, [x0, #0x43]
    // 0x9b2aa8: DecompressPointer r2
    //     0x9b2aa8: add             x2, x2, HEAP, lsl #32
    // 0x9b2aac: cmp             w2, NULL
    // 0x9b2ab0: b.ne            #0x9b2abc
    // 0x9b2ab4: LoadField: r2 = r0->field_3f
    //     0x9b2ab4: ldur            w2, [x0, #0x3f]
    // 0x9b2ab8: DecompressPointer r2
    //     0x9b2ab8: add             x2, x2, HEAP, lsl #32
    // 0x9b2abc: StoreField: r1->field_b = r2
    //     0x9b2abc: stur            w2, [x1, #0xb]
    // 0x9b2ac0: r16 = true
    //     0x9b2ac0: add             x16, NULL, #0x20  ; true
    // 0x9b2ac4: stp             x16, x0, [SP, #-0x10]!
    // 0x9b2ac8: r16 = false
    //     0x9b2ac8: add             x16, NULL, #0x30  ; false
    // 0x9b2acc: stp             x1, x16, [SP, #-0x10]!
    // 0x9b2ad0: r16 = false
    //     0x9b2ad0: add             x16, NULL, #0x30  ; false
    // 0x9b2ad4: SaveReg r16
    //     0x9b2ad4: str             x16, [SP, #-8]!
    // 0x9b2ad8: r4 = const [0, 0x5, 0x5, 0x1, isRecordingPaused, 0x2, isRecordingVideo, 0x1, isStreamingImages, 0x4, recordingOrientation, 0x3, null]
    //     0x9b2ad8: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d738] List(13) [0, 0x5, 0x5, 0x1, "isRecordingPaused", 0x2, "isRecordingVideo", 0x1, "isStreamingImages", 0x4, "recordingOrientation", 0x3, Null]
    //     0x9b2adc: ldr             x4, [x4, #0x738]
    // 0x9b2ae0: r0 = copyWith()
    //     0x9b2ae0: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x9b2ae4: add             SP, SP, #0x28
    // 0x9b2ae8: stur            x0, [fp, #-0x60]
    // 0x9b2aec: ldur            x16, [fp, #-0x58]
    // 0x9b2af0: stp             x0, x16, [SP, #-0x10]!
    // 0x9b2af4: r0 = value=()
    //     0x9b2af4: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x9b2af8: add             SP, SP, #0x10
    // 0x9b2afc: r0 = Null
    //     0x9b2afc: mov             x0, NULL
    // 0x9b2b00: r0 = ReturnAsyncNotFuture()
    //     0x9b2b00: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9b2b04: sub             SP, fp, #0x60
    // 0x9b2b08: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b2b08: mov             x2, #0x76
    //     0x9b2b0c: tbz             w0, #0, #0x9b2b1c
    //     0x9b2b10: ldur            x2, [x0, #-1]
    //     0x9b2b14: ubfx            x2, x2, #0xc, #0x14
    //     0x9b2b18: lsl             x2, x2, #1
    // 0x9b2b1c: cmp             w2, #0xf28
    // 0x9b2b20: b.ne            #0x9b2b90
    // 0x9b2b24: b               #0x9b2b54
    // 0x9b2b28: r0 = CameraException()
    //     0x9b2b28: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b2b2c: mov             x1, x0
    // 0x9b2b30: r0 = "A video recording is already started."
    //     0x9b2b30: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d740] "A video recording is already started."
    //     0x9b2b34: ldr             x0, [x0, #0x740]
    // 0x9b2b38: StoreField: r1->field_7 = r0
    //     0x9b2b38: stur            w0, [x1, #7]
    // 0x9b2b3c: r0 = "startVideoRecording was called when a recording is already started."
    //     0x9b2b3c: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d748] "startVideoRecording was called when a recording is already started."
    //     0x9b2b40: ldr             x0, [x0, #0x748]
    // 0x9b2b44: StoreField: r1->field_b = r0
    //     0x9b2b44: stur            w0, [x1, #0xb]
    // 0x9b2b48: mov             x0, x1
    // 0x9b2b4c: r0 = Throw()
    //     0x9b2b4c: bl              #0xd67e38  ; ThrowStub
    // 0x9b2b50: brk             #0
    // 0x9b2b54: LoadField: r1 = r0->field_7
    //     0x9b2b54: ldur            w1, [x0, #7]
    // 0x9b2b58: DecompressPointer r1
    //     0x9b2b58: add             x1, x1, HEAP, lsl #32
    // 0x9b2b5c: stur            x1, [fp, #-0x60]
    // 0x9b2b60: LoadField: r2 = r0->field_b
    //     0x9b2b60: ldur            w2, [x0, #0xb]
    // 0x9b2b64: DecompressPointer r2
    //     0x9b2b64: add             x2, x2, HEAP, lsl #32
    // 0x9b2b68: stur            x2, [fp, #-0x58]
    // 0x9b2b6c: r0 = CameraException()
    //     0x9b2b6c: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b2b70: mov             x1, x0
    // 0x9b2b74: ldur            x0, [fp, #-0x60]
    // 0x9b2b78: StoreField: r1->field_7 = r0
    //     0x9b2b78: stur            w0, [x1, #7]
    // 0x9b2b7c: ldur            x0, [fp, #-0x58]
    // 0x9b2b80: StoreField: r1->field_b = r0
    //     0x9b2b80: stur            w0, [x1, #0xb]
    // 0x9b2b84: mov             x0, x1
    // 0x9b2b88: r0 = Throw()
    //     0x9b2b88: bl              #0xd67e38  ; ThrowStub
    // 0x9b2b8c: brk             #0
    // 0x9b2b90: r0 = ReThrow()
    //     0x9b2b90: bl              #0xd67e14  ; ReThrowStub
    // 0x9b2b94: brk             #0
    // 0x9b2b98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b2b98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b2b9c: b               #0x9b29e4
  }
  _ takePicture(/* No info */) async {
    // ** addr: 0x9b2fa0, size: 0x208
    // 0x9b2fa0: EnterFrame
    //     0x9b2fa0: stp             fp, lr, [SP, #-0x10]!
    //     0x9b2fa4: mov             fp, SP
    // 0x9b2fa8: AllocStack(0x58)
    //     0x9b2fa8: sub             SP, SP, #0x58
    // 0x9b2fac: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x48 */)
    //     0x9b2fac: stur            NULL, [fp, #-8]
    //     0x9b2fb0: mov             x0, #0
    //     0x9b2fb4: add             x1, fp, w0, sxtw #2
    //     0x9b2fb8: ldr             x1, [x1, #0x10]
    //     0x9b2fbc: stur            x1, [fp, #-0x48]
    // 0x9b2fc0: CheckStackOverflow
    //     0x9b2fc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b2fc4: cmp             SP, x16
    //     0x9b2fc8: b.ls            #0x9b31a0
    // 0x9b2fcc: InitAsync() -> Future<XFile>
    //     0x9b2fcc: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d698] TypeArguments: <XFile>
    //     0x9b2fd0: ldr             x0, [x0, #0x698]
    //     0x9b2fd4: bl              #0x4b92e4
    // 0x9b2fd8: ldur            x16, [fp, #-0x48]
    // 0x9b2fdc: r30 = "takePicture"
    //     0x9b2fdc: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d788] "takePicture"
    //     0x9b2fe0: ldr             lr, [lr, #0x788]
    // 0x9b2fe4: stp             lr, x16, [SP, #-0x10]!
    // 0x9b2fe8: r0 = _throwIfNotInitialized()
    //     0x9b2fe8: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0x9b2fec: add             SP, SP, #0x10
    // 0x9b2ff0: ldur            x0, [fp, #-0x48]
    // 0x9b2ff4: LoadField: r1 = r0->field_27
    //     0x9b2ff4: ldur            w1, [x0, #0x27]
    // 0x9b2ff8: DecompressPointer r1
    //     0x9b2ff8: add             x1, x1, HEAP, lsl #32
    // 0x9b2ffc: LoadField: r2 = r1->field_b
    //     0x9b2ffc: ldur            w2, [x1, #0xb]
    // 0x9b3000: DecompressPointer r2
    //     0x9b3000: add             x2, x2, HEAP, lsl #32
    // 0x9b3004: tbz             w2, #4, #0x9b30f8
    // 0x9b3008: r16 = true
    //     0x9b3008: add             x16, NULL, #0x20  ; true
    // 0x9b300c: stp             x16, x1, [SP, #-0x10]!
    // 0x9b3010: r4 = const [0, 0x2, 0x2, 0x1, isTakingPicture, 0x1, null]
    //     0x9b3010: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d790] List(7) [0, 0x2, 0x2, 0x1, "isTakingPicture", 0x1, Null]
    //     0x9b3014: ldr             x4, [x4, #0x790]
    // 0x9b3018: r0 = copyWith()
    //     0x9b3018: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x9b301c: add             SP, SP, #0x10
    // 0x9b3020: stur            x0, [fp, #-0x50]
    // 0x9b3024: ldur            x16, [fp, #-0x48]
    // 0x9b3028: stp             x0, x16, [SP, #-0x10]!
    // 0x9b302c: r0 = value=()
    //     0x9b302c: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x9b3030: add             SP, SP, #0x10
    // 0x9b3034: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9b3034: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9b3038: ldr             x0, [x0, #0x1590]
    //     0x9b303c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9b3040: cmp             w0, w16
    //     0x9b3044: b.ne            #0x9b3054
    //     0x9b3048: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9b304c: ldr             x2, [x2, #0x270]
    //     0x9b3050: bl              #0xd67d44
    // 0x9b3054: ldur            x1, [fp, #-0x48]
    // 0x9b3058: LoadField: r2 = r1->field_37
    //     0x9b3058: ldur            x2, [x1, #0x37]
    // 0x9b305c: r3 = LoadClassIdInstr(r0)
    //     0x9b305c: ldur            x3, [x0, #-1]
    //     0x9b3060: ubfx            x3, x3, #0xc, #0x14
    // 0x9b3064: stp             x2, x0, [SP, #-0x10]!
    // 0x9b3068: mov             x0, x3
    // 0x9b306c: r0 = GDT[cid_x0 + -0x229]()
    //     0x9b306c: sub             lr, x0, #0x229
    //     0x9b3070: ldr             lr, [x21, lr, lsl #3]
    //     0x9b3074: blr             lr
    // 0x9b3078: add             SP, SP, #0x10
    // 0x9b307c: mov             x1, x0
    // 0x9b3080: stur            x1, [fp, #-0x50]
    // 0x9b3084: r0 = Await()
    //     0x9b3084: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b3088: mov             x1, x0
    // 0x9b308c: ldur            x0, [fp, #-0x48]
    // 0x9b3090: stur            x1, [fp, #-0x50]
    // 0x9b3094: LoadField: r2 = r0->field_27
    //     0x9b3094: ldur            w2, [x0, #0x27]
    // 0x9b3098: DecompressPointer r2
    //     0x9b3098: add             x2, x2, HEAP, lsl #32
    // 0x9b309c: r16 = false
    //     0x9b309c: add             x16, NULL, #0x30  ; false
    // 0x9b30a0: stp             x16, x2, [SP, #-0x10]!
    // 0x9b30a4: r4 = const [0, 0x2, 0x2, 0x1, isTakingPicture, 0x1, null]
    //     0x9b30a4: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d790] List(7) [0, 0x2, 0x2, 0x1, "isTakingPicture", 0x1, Null]
    //     0x9b30a8: ldr             x4, [x4, #0x790]
    // 0x9b30ac: r0 = copyWith()
    //     0x9b30ac: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x9b30b0: add             SP, SP, #0x10
    // 0x9b30b4: stur            x0, [fp, #-0x58]
    // 0x9b30b8: ldur            x16, [fp, #-0x48]
    // 0x9b30bc: stp             x0, x16, [SP, #-0x10]!
    // 0x9b30c0: r0 = value=()
    //     0x9b30c0: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x9b30c4: add             SP, SP, #0x10
    // 0x9b30c8: ldur            x0, [fp, #-0x50]
    // 0x9b30cc: r0 = ReturnAsync()
    //     0x9b30cc: b               #0x501858  ; ReturnAsyncStub
    // 0x9b30d0: sub             SP, fp, #0x58
    // 0x9b30d4: stur            x0, [fp, #-0x48]
    // 0x9b30d8: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b30d8: mov             x2, #0x76
    //     0x9b30dc: tbz             w0, #0, #0x9b30ec
    //     0x9b30e0: ldur            x2, [x0, #-1]
    //     0x9b30e4: ubfx            x2, x2, #0xc, #0x14
    //     0x9b30e8: lsl             x2, x2, #1
    // 0x9b30ec: cmp             w2, #0xf28
    // 0x9b30f0: b.ne            #0x9b3198
    // 0x9b30f4: b               #0x9b3124
    // 0x9b30f8: r0 = CameraException()
    //     0x9b30f8: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b30fc: mov             x1, x0
    // 0x9b3100: r0 = "Previous capture has not returned yet."
    //     0x9b3100: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d798] "Previous capture has not returned yet."
    //     0x9b3104: ldr             x0, [x0, #0x798]
    // 0x9b3108: StoreField: r1->field_7 = r0
    //     0x9b3108: stur            w0, [x1, #7]
    // 0x9b310c: r0 = "takePicture was called before the previous capture returned."
    //     0x9b310c: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d7a0] "takePicture was called before the previous capture returned."
    //     0x9b3110: ldr             x0, [x0, #0x7a0]
    // 0x9b3114: StoreField: r1->field_b = r0
    //     0x9b3114: stur            w0, [x1, #0xb]
    // 0x9b3118: mov             x0, x1
    // 0x9b311c: r0 = Throw()
    //     0x9b311c: bl              #0xd67e38  ; ThrowStub
    // 0x9b3120: brk             #0
    // 0x9b3124: ldur            x1, [fp, #-0x10]
    // 0x9b3128: LoadField: r2 = r1->field_27
    //     0x9b3128: ldur            w2, [x1, #0x27]
    // 0x9b312c: DecompressPointer r2
    //     0x9b312c: add             x2, x2, HEAP, lsl #32
    // 0x9b3130: r16 = false
    //     0x9b3130: add             x16, NULL, #0x30  ; false
    // 0x9b3134: stp             x16, x2, [SP, #-0x10]!
    // 0x9b3138: r4 = const [0, 0x2, 0x2, 0x1, isTakingPicture, 0x1, null]
    //     0x9b3138: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d790] List(7) [0, 0x2, 0x2, 0x1, "isTakingPicture", 0x1, Null]
    //     0x9b313c: ldr             x4, [x4, #0x790]
    // 0x9b3140: r0 = copyWith()
    //     0x9b3140: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x9b3144: add             SP, SP, #0x10
    // 0x9b3148: ldur            x16, [fp, #-0x10]
    // 0x9b314c: stp             x0, x16, [SP, #-0x10]!
    // 0x9b3150: r0 = value=()
    //     0x9b3150: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x9b3154: add             SP, SP, #0x10
    // 0x9b3158: ldur            x0, [fp, #-0x48]
    // 0x9b315c: LoadField: r1 = r0->field_7
    //     0x9b315c: ldur            w1, [x0, #7]
    // 0x9b3160: DecompressPointer r1
    //     0x9b3160: add             x1, x1, HEAP, lsl #32
    // 0x9b3164: stur            x1, [fp, #-0x58]
    // 0x9b3168: LoadField: r2 = r0->field_b
    //     0x9b3168: ldur            w2, [x0, #0xb]
    // 0x9b316c: DecompressPointer r2
    //     0x9b316c: add             x2, x2, HEAP, lsl #32
    // 0x9b3170: stur            x2, [fp, #-0x50]
    // 0x9b3174: r0 = CameraException()
    //     0x9b3174: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b3178: mov             x1, x0
    // 0x9b317c: ldur            x0, [fp, #-0x58]
    // 0x9b3180: StoreField: r1->field_7 = r0
    //     0x9b3180: stur            w0, [x1, #7]
    // 0x9b3184: ldur            x0, [fp, #-0x50]
    // 0x9b3188: StoreField: r1->field_b = r0
    //     0x9b3188: stur            w0, [x1, #0xb]
    // 0x9b318c: mov             x0, x1
    // 0x9b3190: r0 = Throw()
    //     0x9b3190: bl              #0xd67e38  ; ThrowStub
    // 0x9b3194: brk             #0
    // 0x9b3198: r0 = ReThrow()
    //     0x9b3198: bl              #0xd67e14  ; ReThrowStub
    // 0x9b319c: brk             #0
    // 0x9b31a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b31a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b31a4: b               #0x9b2fcc
  }
  _ setFlashMode(/* No info */) async {
    // ** addr: 0x9b3df8, size: 0x3e4
    // 0x9b3df8: EnterFrame
    //     0x9b3df8: stp             fp, lr, [SP, #-0x10]!
    //     0x9b3dfc: mov             fp, SP
    // 0x9b3e00: AllocStack(0x68)
    //     0x9b3e00: sub             SP, SP, #0x68
    // 0x9b3e04: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x58 */, dynamic _ /* r2, fp-0x50 */)
    //     0x9b3e04: stur            NULL, [fp, #-8]
    //     0x9b3e08: mov             x0, #0
    //     0x9b3e0c: add             x1, fp, w0, sxtw #2
    //     0x9b3e10: ldr             x1, [x1, #0x18]
    //     0x9b3e14: stur            x1, [fp, #-0x58]
    //     0x9b3e18: add             x2, fp, w0, sxtw #2
    //     0x9b3e1c: ldr             x2, [x2, #0x10]
    //     0x9b3e20: stur            x2, [fp, #-0x50]
    // 0x9b3e24: CheckStackOverflow
    //     0x9b3e24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b3e28: cmp             SP, x16
    //     0x9b3e2c: b.ls            #0x9b41d4
    // 0x9b3e30: InitAsync() -> Future<void?>
    //     0x9b3e30: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9b3e34: bl              #0x4b92e4
    // 0x9b3e38: ldur            x0, [fp, #-0x58]
    // 0x9b3e3c: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9b3e3c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9b3e40: ldr             x0, [x0, #0x1590]
    //     0x9b3e44: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9b3e48: cmp             w0, w16
    //     0x9b3e4c: b.ne            #0x9b3e5c
    //     0x9b3e50: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9b3e54: ldr             x2, [x2, #0x270]
    //     0x9b3e58: bl              #0xd67d44
    // 0x9b3e5c: mov             x3, x0
    // 0x9b3e60: ldur            x0, [fp, #-0x58]
    // 0x9b3e64: stur            x3, [fp, #-0x68]
    // 0x9b3e68: LoadField: r4 = r0->field_37
    //     0x9b3e68: ldur            x4, [x0, #0x37]
    // 0x9b3e6c: stur            x4, [fp, #-0x60]
    // 0x9b3e70: r1 = LoadClassIdInstr(r3)
    //     0x9b3e70: ldur            x1, [x3, #-1]
    //     0x9b3e74: ubfx            x1, x1, #0xc, #0x14
    // 0x9b3e78: lsl             x1, x1, #1
    // 0x9b3e7c: r17 = 9914
    //     0x9b3e7c: mov             x17, #0x26ba
    // 0x9b3e80: cmp             w1, w17
    // 0x9b3e84: b.ne            #0x9b3f60
    // 0x9b3e88: ldur            x5, [fp, #-0x50]
    // 0x9b3e8c: r1 = Null
    //     0x9b3e8c: mov             x1, NULL
    // 0x9b3e90: r2 = 8
    //     0x9b3e90: mov             x2, #8
    // 0x9b3e94: r0 = AllocateArray()
    //     0x9b3e94: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9b3e98: mov             x2, x0
    // 0x9b3e9c: r17 = "cameraId"
    //     0x9b3e9c: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0x9b3ea0: ldr             x17, [x17, #0x890]
    // 0x9b3ea4: StoreField: r2->field_f = r17
    //     0x9b3ea4: stur            w17, [x2, #0xf]
    // 0x9b3ea8: ldur            x3, [fp, #-0x60]
    // 0x9b3eac: r0 = BoxInt64Instr(r3)
    //     0x9b3eac: sbfiz           x0, x3, #1, #0x1f
    //     0x9b3eb0: cmp             x3, x0, asr #1
    //     0x9b3eb4: b.eq            #0x9b3ec0
    //     0x9b3eb8: bl              #0xd69bb8
    //     0x9b3ebc: stur            x3, [x0, #7]
    // 0x9b3ec0: StoreField: r2->field_13 = r0
    //     0x9b3ec0: stur            w0, [x2, #0x13]
    // 0x9b3ec4: r17 = "mode"
    //     0x9b3ec4: add             x17, PP, #8, lsl #12  ; [pp+0x8f18] "mode"
    //     0x9b3ec8: ldr             x17, [x17, #0xf18]
    // 0x9b3ecc: StoreField: r2->field_17 = r17
    //     0x9b3ecc: stur            w17, [x2, #0x17]
    // 0x9b3ed0: ldur            x0, [fp, #-0x50]
    // 0x9b3ed4: LoadField: r1 = r0->field_7
    //     0x9b3ed4: ldur            x1, [x0, #7]
    // 0x9b3ed8: cmp             x1, #1
    // 0x9b3edc: b.gt            #0x9b3f00
    // 0x9b3ee0: cmp             x1, #0
    // 0x9b3ee4: b.gt            #0x9b3ef4
    // 0x9b3ee8: r1 = "off"
    //     0x9b3ee8: add             x1, PP, #0x26, lsl #12  ; [pp+0x269e8] "off"
    //     0x9b3eec: ldr             x1, [x1, #0x9e8]
    // 0x9b3ef0: b               #0x9b3f1c
    // 0x9b3ef4: r1 = "auto"
    //     0x9b3ef4: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c7d0] "auto"
    //     0x9b3ef8: ldr             x1, [x1, #0x7d0]
    // 0x9b3efc: b               #0x9b3f1c
    // 0x9b3f00: cmp             x1, #2
    // 0x9b3f04: b.gt            #0x9b3f14
    // 0x9b3f08: r1 = "always"
    //     0x9b3f08: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d898] "always"
    //     0x9b3f0c: ldr             x1, [x1, #0x898]
    // 0x9b3f10: b               #0x9b3f1c
    // 0x9b3f14: r1 = "torch"
    //     0x9b3f14: add             x1, PP, #0x39, lsl #12  ; [pp+0x39b28] "torch"
    //     0x9b3f18: ldr             x1, [x1, #0xb28]
    // 0x9b3f1c: StoreField: r2->field_1b = r1
    //     0x9b3f1c: stur            w1, [x2, #0x1b]
    // 0x9b3f20: r16 = <String, dynamic>
    //     0x9b3f20: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x9b3f24: stp             x2, x16, [SP, #-0x10]!
    // 0x9b3f28: r0 = Map._fromLiteral()
    //     0x9b3f28: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9b3f2c: add             SP, SP, #0x10
    // 0x9b3f30: r16 = <void?>
    //     0x9b3f30: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x9b3f34: r30 = Instance_MethodChannel
    //     0x9b3f34: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0x9b3f38: ldr             lr, [lr, #0x360]
    // 0x9b3f3c: stp             lr, x16, [SP, #-0x10]!
    // 0x9b3f40: r16 = "setFlashMode"
    //     0x9b3f40: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d8a0] "setFlashMode"
    //     0x9b3f44: ldr             x16, [x16, #0x8a0]
    // 0x9b3f48: stp             x0, x16, [SP, #-0x10]!
    // 0x9b3f4c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x9b3f4c: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x9b3f50: r0 = invokeMethod()
    //     0x9b3f50: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x9b3f54: add             SP, SP, #0x20
    // 0x9b3f58: mov             x2, x0
    // 0x9b3f5c: b               #0x9b4120
    // 0x9b3f60: r17 = 9916
    //     0x9b3f60: mov             x17, #0x26bc
    // 0x9b3f64: cmp             w1, w17
    // 0x9b3f68: b.ne            #0x9b4048
    // 0x9b3f6c: ldur            x3, [fp, #-0x50]
    // 0x9b3f70: ldur            x0, [fp, #-0x60]
    // 0x9b3f74: r1 = Null
    //     0x9b3f74: mov             x1, NULL
    // 0x9b3f78: r2 = 8
    //     0x9b3f78: mov             x2, #8
    // 0x9b3f7c: r0 = AllocateArray()
    //     0x9b3f7c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9b3f80: mov             x2, x0
    // 0x9b3f84: r17 = "cameraId"
    //     0x9b3f84: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0x9b3f88: ldr             x17, [x17, #0x890]
    // 0x9b3f8c: StoreField: r2->field_f = r17
    //     0x9b3f8c: stur            w17, [x2, #0xf]
    // 0x9b3f90: ldur            x3, [fp, #-0x60]
    // 0x9b3f94: r0 = BoxInt64Instr(r3)
    //     0x9b3f94: sbfiz           x0, x3, #1, #0x1f
    //     0x9b3f98: cmp             x3, x0, asr #1
    //     0x9b3f9c: b.eq            #0x9b3fa8
    //     0x9b3fa0: bl              #0xd69bb8
    //     0x9b3fa4: stur            x3, [x0, #7]
    // 0x9b3fa8: StoreField: r2->field_13 = r0
    //     0x9b3fa8: stur            w0, [x2, #0x13]
    // 0x9b3fac: r17 = "mode"
    //     0x9b3fac: add             x17, PP, #8, lsl #12  ; [pp+0x8f18] "mode"
    //     0x9b3fb0: ldr             x17, [x17, #0xf18]
    // 0x9b3fb4: StoreField: r2->field_17 = r17
    //     0x9b3fb4: stur            w17, [x2, #0x17]
    // 0x9b3fb8: ldur            x0, [fp, #-0x50]
    // 0x9b3fbc: LoadField: r1 = r0->field_7
    //     0x9b3fbc: ldur            x1, [x0, #7]
    // 0x9b3fc0: cmp             x1, #1
    // 0x9b3fc4: b.gt            #0x9b3fe8
    // 0x9b3fc8: cmp             x1, #0
    // 0x9b3fcc: b.gt            #0x9b3fdc
    // 0x9b3fd0: r1 = "off"
    //     0x9b3fd0: add             x1, PP, #0x26, lsl #12  ; [pp+0x269e8] "off"
    //     0x9b3fd4: ldr             x1, [x1, #0x9e8]
    // 0x9b3fd8: b               #0x9b4004
    // 0x9b3fdc: r1 = "auto"
    //     0x9b3fdc: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c7d0] "auto"
    //     0x9b3fe0: ldr             x1, [x1, #0x7d0]
    // 0x9b3fe4: b               #0x9b4004
    // 0x9b3fe8: cmp             x1, #2
    // 0x9b3fec: b.gt            #0x9b3ffc
    // 0x9b3ff0: r1 = "always"
    //     0x9b3ff0: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d898] "always"
    //     0x9b3ff4: ldr             x1, [x1, #0x898]
    // 0x9b3ff8: b               #0x9b4004
    // 0x9b3ffc: r1 = "torch"
    //     0x9b3ffc: add             x1, PP, #0x39, lsl #12  ; [pp+0x39b28] "torch"
    //     0x9b4000: ldr             x1, [x1, #0xb28]
    // 0x9b4004: StoreField: r2->field_1b = r1
    //     0x9b4004: stur            w1, [x2, #0x1b]
    // 0x9b4008: r16 = <String, dynamic>
    //     0x9b4008: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x9b400c: stp             x2, x16, [SP, #-0x10]!
    // 0x9b4010: r0 = Map._fromLiteral()
    //     0x9b4010: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9b4014: add             SP, SP, #0x10
    // 0x9b4018: r16 = <void?>
    //     0x9b4018: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x9b401c: r30 = Instance_MethodChannel
    //     0x9b401c: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0x9b4020: ldr             lr, [lr, #0x370]
    // 0x9b4024: stp             lr, x16, [SP, #-0x10]!
    // 0x9b4028: r16 = "setFlashMode"
    //     0x9b4028: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d8a0] "setFlashMode"
    //     0x9b402c: ldr             x16, [x16, #0x8a0]
    // 0x9b4030: stp             x0, x16, [SP, #-0x10]!
    // 0x9b4034: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x9b4034: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x9b4038: r0 = invokeMethod()
    //     0x9b4038: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x9b403c: add             SP, SP, #0x20
    // 0x9b4040: mov             x2, x0
    // 0x9b4044: b               #0x9b4120
    // 0x9b4048: ldur            x3, [fp, #-0x50]
    // 0x9b404c: ldur            x0, [fp, #-0x60]
    // 0x9b4050: r1 = Null
    //     0x9b4050: mov             x1, NULL
    // 0x9b4054: r2 = 8
    //     0x9b4054: mov             x2, #8
    // 0x9b4058: r0 = AllocateArray()
    //     0x9b4058: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9b405c: mov             x2, x0
    // 0x9b4060: r17 = "cameraId"
    //     0x9b4060: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0x9b4064: ldr             x17, [x17, #0x890]
    // 0x9b4068: StoreField: r2->field_f = r17
    //     0x9b4068: stur            w17, [x2, #0xf]
    // 0x9b406c: ldur            x3, [fp, #-0x60]
    // 0x9b4070: r0 = BoxInt64Instr(r3)
    //     0x9b4070: sbfiz           x0, x3, #1, #0x1f
    //     0x9b4074: cmp             x3, x0, asr #1
    //     0x9b4078: b.eq            #0x9b4084
    //     0x9b407c: bl              #0xd69bb8
    //     0x9b4080: stur            x3, [x0, #7]
    // 0x9b4084: StoreField: r2->field_13 = r0
    //     0x9b4084: stur            w0, [x2, #0x13]
    // 0x9b4088: r17 = "mode"
    //     0x9b4088: add             x17, PP, #8, lsl #12  ; [pp+0x8f18] "mode"
    //     0x9b408c: ldr             x17, [x17, #0xf18]
    // 0x9b4090: StoreField: r2->field_17 = r17
    //     0x9b4090: stur            w17, [x2, #0x17]
    // 0x9b4094: ldur            x0, [fp, #-0x50]
    // 0x9b4098: LoadField: r1 = r0->field_7
    //     0x9b4098: ldur            x1, [x0, #7]
    // 0x9b409c: cmp             x1, #1
    // 0x9b40a0: b.gt            #0x9b40c4
    // 0x9b40a4: cmp             x1, #0
    // 0x9b40a8: b.gt            #0x9b40b8
    // 0x9b40ac: r1 = "off"
    //     0x9b40ac: add             x1, PP, #0x26, lsl #12  ; [pp+0x269e8] "off"
    //     0x9b40b0: ldr             x1, [x1, #0x9e8]
    // 0x9b40b4: b               #0x9b40e0
    // 0x9b40b8: r1 = "auto"
    //     0x9b40b8: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c7d0] "auto"
    //     0x9b40bc: ldr             x1, [x1, #0x7d0]
    // 0x9b40c0: b               #0x9b40e0
    // 0x9b40c4: cmp             x1, #2
    // 0x9b40c8: b.gt            #0x9b40d8
    // 0x9b40cc: r1 = "always"
    //     0x9b40cc: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d898] "always"
    //     0x9b40d0: ldr             x1, [x1, #0x898]
    // 0x9b40d4: b               #0x9b40e0
    // 0x9b40d8: r1 = "torch"
    //     0x9b40d8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39b28] "torch"
    //     0x9b40dc: ldr             x1, [x1, #0xb28]
    // 0x9b40e0: StoreField: r2->field_1b = r1
    //     0x9b40e0: stur            w1, [x2, #0x1b]
    // 0x9b40e4: r16 = <String, dynamic>
    //     0x9b40e4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x9b40e8: stp             x2, x16, [SP, #-0x10]!
    // 0x9b40ec: r0 = Map._fromLiteral()
    //     0x9b40ec: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9b40f0: add             SP, SP, #0x10
    // 0x9b40f4: r16 = <void?>
    //     0x9b40f4: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x9b40f8: r30 = Instance_MethodChannel
    //     0x9b40f8: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0x9b40fc: ldr             lr, [lr, #0x378]
    // 0x9b4100: stp             lr, x16, [SP, #-0x10]!
    // 0x9b4104: r16 = "setFlashMode"
    //     0x9b4104: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d8a0] "setFlashMode"
    //     0x9b4108: ldr             x16, [x16, #0x8a0]
    // 0x9b410c: stp             x0, x16, [SP, #-0x10]!
    // 0x9b4110: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x9b4110: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x9b4114: r0 = invokeMethod()
    //     0x9b4114: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x9b4118: add             SP, SP, #0x20
    // 0x9b411c: mov             x2, x0
    // 0x9b4120: ldur            x1, [fp, #-0x58]
    // 0x9b4124: mov             x0, x2
    // 0x9b4128: stur            x2, [fp, #-0x68]
    // 0x9b412c: r0 = Await()
    //     0x9b412c: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b4130: ldur            x0, [fp, #-0x58]
    // 0x9b4134: LoadField: r1 = r0->field_27
    //     0x9b4134: ldur            w1, [x0, #0x27]
    // 0x9b4138: DecompressPointer r1
    //     0x9b4138: add             x1, x1, HEAP, lsl #32
    // 0x9b413c: ldur            x16, [fp, #-0x50]
    // 0x9b4140: stp             x16, x1, [SP, #-0x10]!
    // 0x9b4144: r4 = const [0, 0x2, 0x2, 0x1, flashMode, 0x1, null]
    //     0x9b4144: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d8a8] List(7) [0, 0x2, 0x2, 0x1, "flashMode", 0x1, Null]
    //     0x9b4148: ldr             x4, [x4, #0x8a8]
    // 0x9b414c: r0 = copyWith()
    //     0x9b414c: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x9b4150: add             SP, SP, #0x10
    // 0x9b4154: stur            x0, [fp, #-0x50]
    // 0x9b4158: ldur            x16, [fp, #-0x58]
    // 0x9b415c: stp             x0, x16, [SP, #-0x10]!
    // 0x9b4160: r0 = value=()
    //     0x9b4160: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x9b4164: add             SP, SP, #0x10
    // 0x9b4168: r0 = Null
    //     0x9b4168: mov             x0, NULL
    // 0x9b416c: r0 = ReturnAsyncNotFuture()
    //     0x9b416c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9b4170: sub             SP, fp, #0x68
    // 0x9b4174: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b4174: mov             x2, #0x76
    //     0x9b4178: tbz             w0, #0, #0x9b4188
    //     0x9b417c: ldur            x2, [x0, #-1]
    //     0x9b4180: ubfx            x2, x2, #0xc, #0x14
    //     0x9b4184: lsl             x2, x2, #1
    // 0x9b4188: cmp             w2, #0xf28
    // 0x9b418c: b.ne            #0x9b41cc
    // 0x9b4190: LoadField: r1 = r0->field_7
    //     0x9b4190: ldur            w1, [x0, #7]
    // 0x9b4194: DecompressPointer r1
    //     0x9b4194: add             x1, x1, HEAP, lsl #32
    // 0x9b4198: stur            x1, [fp, #-0x58]
    // 0x9b419c: LoadField: r2 = r0->field_b
    //     0x9b419c: ldur            w2, [x0, #0xb]
    // 0x9b41a0: DecompressPointer r2
    //     0x9b41a0: add             x2, x2, HEAP, lsl #32
    // 0x9b41a4: stur            x2, [fp, #-0x50]
    // 0x9b41a8: r0 = CameraException()
    //     0x9b41a8: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b41ac: mov             x1, x0
    // 0x9b41b0: ldur            x0, [fp, #-0x58]
    // 0x9b41b4: StoreField: r1->field_7 = r0
    //     0x9b41b4: stur            w0, [x1, #7]
    // 0x9b41b8: ldur            x0, [fp, #-0x50]
    // 0x9b41bc: StoreField: r1->field_b = r0
    //     0x9b41bc: stur            w0, [x1, #0xb]
    // 0x9b41c0: mov             x0, x1
    // 0x9b41c4: r0 = Throw()
    //     0x9b41c4: bl              #0xd67e38  ; ThrowStub
    // 0x9b41c8: brk             #0
    // 0x9b41cc: r0 = ReThrow()
    //     0x9b41cc: bl              #0xd67e14  ; ReThrowStub
    // 0x9b41d0: brk             #0
    // 0x9b41d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b41d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b41d8: b               #0x9b3e30
  }
  _ setFocusPoint(/* No info */) async {
    // ** addr: 0x9b4f04, size: 0x1dc
    // 0x9b4f04: EnterFrame
    //     0x9b4f04: stp             fp, lr, [SP, #-0x10]!
    //     0x9b4f08: mov             fp, SP
    // 0x9b4f0c: AllocStack(0x80)
    //     0x9b4f0c: sub             SP, SP, #0x80
    // 0x9b4f10: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x60 */, dynamic _ /* r2, fp-0x58 */)
    //     0x9b4f10: stur            NULL, [fp, #-8]
    //     0x9b4f14: mov             x0, #0
    //     0x9b4f18: add             x1, fp, w0, sxtw #2
    //     0x9b4f1c: ldr             x1, [x1, #0x18]
    //     0x9b4f20: stur            x1, [fp, #-0x60]
    //     0x9b4f24: add             x2, fp, w0, sxtw #2
    //     0x9b4f28: ldr             x2, [x2, #0x10]
    //     0x9b4f2c: stur            x2, [fp, #-0x58]
    // 0x9b4f30: CheckStackOverflow
    //     0x9b4f30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b4f34: cmp             SP, x16
    //     0x9b4f38: b.ls            #0x9b50d8
    // 0x9b4f3c: InitAsync() -> Future<void?>
    //     0x9b4f3c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9b4f40: bl              #0x4b92e4
    // 0x9b4f44: ldur            x0, [fp, #-0x58]
    // 0x9b4f48: LoadField: d0 = r0->field_7
    //     0x9b4f48: ldur            d0, [x0, #7]
    // 0x9b4f4c: stur            d0, [fp, #-0x80]
    // 0x9b4f50: d1 = 0.000000
    //     0x9b4f50: eor             v1.16b, v1.16b, v1.16b
    // 0x9b4f54: fcmp            d0, d1
    // 0x9b4f58: b.vs            #0x9b4f60
    // 0x9b4f5c: b.lt            #0x9b506c
    // 0x9b4f60: d2 = 1.000000
    //     0x9b4f60: fmov            d2, #1.00000000
    // 0x9b4f64: fcmp            d0, d2
    // 0x9b4f68: b.vs            #0x9b4f70
    // 0x9b4f6c: b.gt            #0x9b506c
    // 0x9b4f70: LoadField: d3 = r0->field_f
    //     0x9b4f70: ldur            d3, [x0, #0xf]
    // 0x9b4f74: stur            d3, [fp, #-0x78]
    // 0x9b4f78: fcmp            d3, d1
    // 0x9b4f7c: b.vs            #0x9b4f84
    // 0x9b4f80: b.lt            #0x9b506c
    // 0x9b4f84: fcmp            d3, d2
    // 0x9b4f88: b.vs            #0x9b4f90
    // 0x9b4f8c: b.gt            #0x9b506c
    // 0x9b4f90: ldur            x1, [fp, #-0x60]
    // 0x9b4f94: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9b4f94: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9b4f98: ldr             x0, [x0, #0x1590]
    //     0x9b4f9c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9b4fa0: cmp             w0, w16
    //     0x9b4fa4: b.ne            #0x9b4fb4
    //     0x9b4fa8: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9b4fac: ldr             x2, [x2, #0x270]
    //     0x9b4fb0: bl              #0xd67d44
    // 0x9b4fb4: mov             x2, x0
    // 0x9b4fb8: ldur            x0, [fp, #-0x60]
    // 0x9b4fbc: stur            x2, [fp, #-0x70]
    // 0x9b4fc0: LoadField: r3 = r0->field_37
    //     0x9b4fc0: ldur            x3, [x0, #0x37]
    // 0x9b4fc4: ldur            x0, [fp, #-0x58]
    // 0x9b4fc8: stur            x3, [fp, #-0x68]
    // 0x9b4fcc: cmp             w0, NULL
    // 0x9b4fd0: b.ne            #0x9b4fe4
    // 0x9b4fd4: mov             x1, x3
    // 0x9b4fd8: mov             x0, x2
    // 0x9b4fdc: r2 = Null
    //     0x9b4fdc: mov             x2, NULL
    // 0x9b4fe0: b               #0x9b5010
    // 0x9b4fe4: ldur            d1, [fp, #-0x78]
    // 0x9b4fe8: ldur            d0, [fp, #-0x80]
    // 0x9b4fec: r1 = <double>
    //     0x9b4fec: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9b4ff0: r0 = Point()
    //     0x9b4ff0: bl              #0x9b50e0  ; AllocatePointStub -> Point<X0 bound num> (size=0x1c)
    // 0x9b4ff4: ldur            d0, [fp, #-0x80]
    // 0x9b4ff8: StoreField: r0->field_b = d0
    //     0x9b4ff8: stur            d0, [x0, #0xb]
    // 0x9b4ffc: ldur            d0, [fp, #-0x78]
    // 0x9b5000: StoreField: r0->field_13 = d0
    //     0x9b5000: stur            d0, [x0, #0x13]
    // 0x9b5004: mov             x2, x0
    // 0x9b5008: ldur            x1, [fp, #-0x68]
    // 0x9b500c: ldur            x0, [fp, #-0x70]
    // 0x9b5010: r3 = LoadClassIdInstr(r0)
    //     0x9b5010: ldur            x3, [x0, #-1]
    //     0x9b5014: ubfx            x3, x3, #0xc, #0x14
    // 0x9b5018: stp             x1, x0, [SP, #-0x10]!
    // 0x9b501c: SaveReg r2
    //     0x9b501c: str             x2, [SP, #-8]!
    // 0x9b5020: mov             x0, x3
    // 0x9b5024: r0 = GDT[cid_x0 + 0x14f]()
    //     0x9b5024: add             lr, x0, #0x14f
    //     0x9b5028: ldr             lr, [x21, lr, lsl #3]
    //     0x9b502c: blr             lr
    // 0x9b5030: add             SP, SP, #0x18
    // 0x9b5034: mov             x1, x0
    // 0x9b5038: stur            x1, [fp, #-0x58]
    // 0x9b503c: r0 = Await()
    //     0x9b503c: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b5040: r0 = Null
    //     0x9b5040: mov             x0, NULL
    // 0x9b5044: r0 = ReturnAsyncNotFuture()
    //     0x9b5044: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9b5048: sub             SP, fp, #0x80
    // 0x9b504c: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b504c: mov             x2, #0x76
    //     0x9b5050: tbz             w0, #0, #0x9b5060
    //     0x9b5054: ldur            x2, [x0, #-1]
    //     0x9b5058: ubfx            x2, x2, #0xc, #0x14
    //     0x9b505c: lsl             x2, x2, #1
    // 0x9b5060: cmp             w2, #0xf28
    // 0x9b5064: b.ne            #0x9b50d0
    // 0x9b5068: b               #0x9b5094
    // 0x9b506c: r0 = ArgumentError()
    //     0x9b506c: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x9b5070: mov             x1, x0
    // 0x9b5074: r0 = "The values of point should be anywhere between (0,0) and (1,1)."
    //     0x9b5074: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d970] "The values of point should be anywhere between (0,0) and (1,1)."
    //     0x9b5078: ldr             x0, [x0, #0x970]
    // 0x9b507c: StoreField: r1->field_17 = r0
    //     0x9b507c: stur            w0, [x1, #0x17]
    // 0x9b5080: r0 = false
    //     0x9b5080: add             x0, NULL, #0x30  ; false
    // 0x9b5084: StoreField: r1->field_b = r0
    //     0x9b5084: stur            w0, [x1, #0xb]
    // 0x9b5088: mov             x0, x1
    // 0x9b508c: r0 = Throw()
    //     0x9b508c: bl              #0xd67e38  ; ThrowStub
    // 0x9b5090: brk             #0
    // 0x9b5094: LoadField: r1 = r0->field_7
    //     0x9b5094: ldur            w1, [x0, #7]
    // 0x9b5098: DecompressPointer r1
    //     0x9b5098: add             x1, x1, HEAP, lsl #32
    // 0x9b509c: stur            x1, [fp, #-0x60]
    // 0x9b50a0: LoadField: r2 = r0->field_b
    //     0x9b50a0: ldur            w2, [x0, #0xb]
    // 0x9b50a4: DecompressPointer r2
    //     0x9b50a4: add             x2, x2, HEAP, lsl #32
    // 0x9b50a8: stur            x2, [fp, #-0x58]
    // 0x9b50ac: r0 = CameraException()
    //     0x9b50ac: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b50b0: mov             x1, x0
    // 0x9b50b4: ldur            x0, [fp, #-0x60]
    // 0x9b50b8: StoreField: r1->field_7 = r0
    //     0x9b50b8: stur            w0, [x1, #7]
    // 0x9b50bc: ldur            x0, [fp, #-0x58]
    // 0x9b50c0: StoreField: r1->field_b = r0
    //     0x9b50c0: stur            w0, [x1, #0xb]
    // 0x9b50c4: mov             x0, x1
    // 0x9b50c8: r0 = Throw()
    //     0x9b50c8: bl              #0xd67e38  ; ThrowStub
    // 0x9b50cc: brk             #0
    // 0x9b50d0: r0 = ReThrow()
    //     0x9b50d0: bl              #0xd67e14  ; ReThrowStub
    // 0x9b50d4: brk             #0
    // 0x9b50d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b50d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b50dc: b               #0x9b4f3c
  }
  _ setExposurePoint(/* No info */) async {
    // ** addr: 0x9b56a0, size: 0x1dc
    // 0x9b56a0: EnterFrame
    //     0x9b56a0: stp             fp, lr, [SP, #-0x10]!
    //     0x9b56a4: mov             fp, SP
    // 0x9b56a8: AllocStack(0x80)
    //     0x9b56a8: sub             SP, SP, #0x80
    // 0x9b56ac: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x60 */, dynamic _ /* r2, fp-0x58 */)
    //     0x9b56ac: stur            NULL, [fp, #-8]
    //     0x9b56b0: mov             x0, #0
    //     0x9b56b4: add             x1, fp, w0, sxtw #2
    //     0x9b56b8: ldr             x1, [x1, #0x18]
    //     0x9b56bc: stur            x1, [fp, #-0x60]
    //     0x9b56c0: add             x2, fp, w0, sxtw #2
    //     0x9b56c4: ldr             x2, [x2, #0x10]
    //     0x9b56c8: stur            x2, [fp, #-0x58]
    // 0x9b56cc: CheckStackOverflow
    //     0x9b56cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b56d0: cmp             SP, x16
    //     0x9b56d4: b.ls            #0x9b5874
    // 0x9b56d8: InitAsync() -> Future<void?>
    //     0x9b56d8: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9b56dc: bl              #0x4b92e4
    // 0x9b56e0: ldur            x0, [fp, #-0x58]
    // 0x9b56e4: LoadField: d0 = r0->field_7
    //     0x9b56e4: ldur            d0, [x0, #7]
    // 0x9b56e8: stur            d0, [fp, #-0x80]
    // 0x9b56ec: d1 = 0.000000
    //     0x9b56ec: eor             v1.16b, v1.16b, v1.16b
    // 0x9b56f0: fcmp            d0, d1
    // 0x9b56f4: b.vs            #0x9b56fc
    // 0x9b56f8: b.lt            #0x9b5808
    // 0x9b56fc: d2 = 1.000000
    //     0x9b56fc: fmov            d2, #1.00000000
    // 0x9b5700: fcmp            d0, d2
    // 0x9b5704: b.vs            #0x9b570c
    // 0x9b5708: b.gt            #0x9b5808
    // 0x9b570c: LoadField: d3 = r0->field_f
    //     0x9b570c: ldur            d3, [x0, #0xf]
    // 0x9b5710: stur            d3, [fp, #-0x78]
    // 0x9b5714: fcmp            d3, d1
    // 0x9b5718: b.vs            #0x9b5720
    // 0x9b571c: b.lt            #0x9b5808
    // 0x9b5720: fcmp            d3, d2
    // 0x9b5724: b.vs            #0x9b572c
    // 0x9b5728: b.gt            #0x9b5808
    // 0x9b572c: ldur            x1, [fp, #-0x60]
    // 0x9b5730: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9b5730: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9b5734: ldr             x0, [x0, #0x1590]
    //     0x9b5738: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9b573c: cmp             w0, w16
    //     0x9b5740: b.ne            #0x9b5750
    //     0x9b5744: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9b5748: ldr             x2, [x2, #0x270]
    //     0x9b574c: bl              #0xd67d44
    // 0x9b5750: mov             x2, x0
    // 0x9b5754: ldur            x0, [fp, #-0x60]
    // 0x9b5758: stur            x2, [fp, #-0x70]
    // 0x9b575c: LoadField: r3 = r0->field_37
    //     0x9b575c: ldur            x3, [x0, #0x37]
    // 0x9b5760: ldur            x0, [fp, #-0x58]
    // 0x9b5764: stur            x3, [fp, #-0x68]
    // 0x9b5768: cmp             w0, NULL
    // 0x9b576c: b.ne            #0x9b5780
    // 0x9b5770: mov             x1, x3
    // 0x9b5774: mov             x0, x2
    // 0x9b5778: r2 = Null
    //     0x9b5778: mov             x2, NULL
    // 0x9b577c: b               #0x9b57ac
    // 0x9b5780: ldur            d1, [fp, #-0x78]
    // 0x9b5784: ldur            d0, [fp, #-0x80]
    // 0x9b5788: r1 = <double>
    //     0x9b5788: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9b578c: r0 = Point()
    //     0x9b578c: bl              #0x9b50e0  ; AllocatePointStub -> Point<X0 bound num> (size=0x1c)
    // 0x9b5790: ldur            d0, [fp, #-0x80]
    // 0x9b5794: StoreField: r0->field_b = d0
    //     0x9b5794: stur            d0, [x0, #0xb]
    // 0x9b5798: ldur            d0, [fp, #-0x78]
    // 0x9b579c: StoreField: r0->field_13 = d0
    //     0x9b579c: stur            d0, [x0, #0x13]
    // 0x9b57a0: mov             x2, x0
    // 0x9b57a4: ldur            x1, [fp, #-0x68]
    // 0x9b57a8: ldur            x0, [fp, #-0x70]
    // 0x9b57ac: r3 = LoadClassIdInstr(r0)
    //     0x9b57ac: ldur            x3, [x0, #-1]
    //     0x9b57b0: ubfx            x3, x3, #0xc, #0x14
    // 0x9b57b4: stp             x1, x0, [SP, #-0x10]!
    // 0x9b57b8: SaveReg r2
    //     0x9b57b8: str             x2, [SP, #-8]!
    // 0x9b57bc: mov             x0, x3
    // 0x9b57c0: r0 = GDT[cid_x0 + 0xb7]()
    //     0x9b57c0: add             lr, x0, #0xb7
    //     0x9b57c4: ldr             lr, [x21, lr, lsl #3]
    //     0x9b57c8: blr             lr
    // 0x9b57cc: add             SP, SP, #0x18
    // 0x9b57d0: mov             x1, x0
    // 0x9b57d4: stur            x1, [fp, #-0x58]
    // 0x9b57d8: r0 = Await()
    //     0x9b57d8: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b57dc: r0 = Null
    //     0x9b57dc: mov             x0, NULL
    // 0x9b57e0: r0 = ReturnAsyncNotFuture()
    //     0x9b57e0: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9b57e4: sub             SP, fp, #0x80
    // 0x9b57e8: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b57e8: mov             x2, #0x76
    //     0x9b57ec: tbz             w0, #0, #0x9b57fc
    //     0x9b57f0: ldur            x2, [x0, #-1]
    //     0x9b57f4: ubfx            x2, x2, #0xc, #0x14
    //     0x9b57f8: lsl             x2, x2, #1
    // 0x9b57fc: cmp             w2, #0xf28
    // 0x9b5800: b.ne            #0x9b586c
    // 0x9b5804: b               #0x9b5830
    // 0x9b5808: r0 = ArgumentError()
    //     0x9b5808: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x9b580c: mov             x1, x0
    // 0x9b5810: r0 = "The values of point should be anywhere between (0,0) and (1,1)."
    //     0x9b5810: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d970] "The values of point should be anywhere between (0,0) and (1,1)."
    //     0x9b5814: ldr             x0, [x0, #0x970]
    // 0x9b5818: StoreField: r1->field_17 = r0
    //     0x9b5818: stur            w0, [x1, #0x17]
    // 0x9b581c: r0 = false
    //     0x9b581c: add             x0, NULL, #0x30  ; false
    // 0x9b5820: StoreField: r1->field_b = r0
    //     0x9b5820: stur            w0, [x1, #0xb]
    // 0x9b5824: mov             x0, x1
    // 0x9b5828: r0 = Throw()
    //     0x9b5828: bl              #0xd67e38  ; ThrowStub
    // 0x9b582c: brk             #0
    // 0x9b5830: LoadField: r1 = r0->field_7
    //     0x9b5830: ldur            w1, [x0, #7]
    // 0x9b5834: DecompressPointer r1
    //     0x9b5834: add             x1, x1, HEAP, lsl #32
    // 0x9b5838: stur            x1, [fp, #-0x60]
    // 0x9b583c: LoadField: r2 = r0->field_b
    //     0x9b583c: ldur            w2, [x0, #0xb]
    // 0x9b5840: DecompressPointer r2
    //     0x9b5840: add             x2, x2, HEAP, lsl #32
    // 0x9b5844: stur            x2, [fp, #-0x58]
    // 0x9b5848: r0 = CameraException()
    //     0x9b5848: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b584c: mov             x1, x0
    // 0x9b5850: ldur            x0, [fp, #-0x60]
    // 0x9b5854: StoreField: r1->field_7 = r0
    //     0x9b5854: stur            w0, [x1, #7]
    // 0x9b5858: ldur            x0, [fp, #-0x58]
    // 0x9b585c: StoreField: r1->field_b = r0
    //     0x9b585c: stur            w0, [x1, #0xb]
    // 0x9b5860: mov             x0, x1
    // 0x9b5864: r0 = Throw()
    //     0x9b5864: bl              #0xd67e38  ; ThrowStub
    // 0x9b5868: brk             #0
    // 0x9b586c: r0 = ReThrow()
    //     0x9b586c: bl              #0xd67e14  ; ReThrowStub
    // 0x9b5870: brk             #0
    // 0x9b5874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b5874: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b5878: b               #0x9b56d8
  }
  _ setExposureMode(/* No info */) async {
    // ** addr: 0x9b58d0, size: 0x36c
    // 0x9b58d0: EnterFrame
    //     0x9b58d0: stp             fp, lr, [SP, #-0x10]!
    //     0x9b58d4: mov             fp, SP
    // 0x9b58d8: AllocStack(0x68)
    //     0x9b58d8: sub             SP, SP, #0x68
    // 0x9b58dc: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x58 */, dynamic _ /* r2, fp-0x50 */)
    //     0x9b58dc: stur            NULL, [fp, #-8]
    //     0x9b58e0: mov             x0, #0
    //     0x9b58e4: add             x1, fp, w0, sxtw #2
    //     0x9b58e8: ldr             x1, [x1, #0x18]
    //     0x9b58ec: stur            x1, [fp, #-0x58]
    //     0x9b58f0: add             x2, fp, w0, sxtw #2
    //     0x9b58f4: ldr             x2, [x2, #0x10]
    //     0x9b58f8: stur            x2, [fp, #-0x50]
    // 0x9b58fc: CheckStackOverflow
    //     0x9b58fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b5900: cmp             SP, x16
    //     0x9b5904: b.ls            #0x9b5c34
    // 0x9b5908: InitAsync() -> Future<void?>
    //     0x9b5908: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9b590c: bl              #0x4b92e4
    // 0x9b5910: ldur            x0, [fp, #-0x58]
    // 0x9b5914: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9b5914: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9b5918: ldr             x0, [x0, #0x1590]
    //     0x9b591c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9b5920: cmp             w0, w16
    //     0x9b5924: b.ne            #0x9b5934
    //     0x9b5928: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9b592c: ldr             x2, [x2, #0x270]
    //     0x9b5930: bl              #0xd67d44
    // 0x9b5934: mov             x3, x0
    // 0x9b5938: ldur            x0, [fp, #-0x58]
    // 0x9b593c: stur            x3, [fp, #-0x68]
    // 0x9b5940: LoadField: r4 = r0->field_37
    //     0x9b5940: ldur            x4, [x0, #0x37]
    // 0x9b5944: stur            x4, [fp, #-0x60]
    // 0x9b5948: r1 = LoadClassIdInstr(r3)
    //     0x9b5948: ldur            x1, [x3, #-1]
    //     0x9b594c: ubfx            x1, x1, #0xc, #0x14
    // 0x9b5950: lsl             x1, x1, #1
    // 0x9b5954: r17 = 9914
    //     0x9b5954: mov             x17, #0x26ba
    // 0x9b5958: cmp             w1, w17
    // 0x9b595c: b.ne            #0x9b5a10
    // 0x9b5960: ldur            x5, [fp, #-0x50]
    // 0x9b5964: r1 = Null
    //     0x9b5964: mov             x1, NULL
    // 0x9b5968: r2 = 8
    //     0x9b5968: mov             x2, #8
    // 0x9b596c: r0 = AllocateArray()
    //     0x9b596c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9b5970: mov             x2, x0
    // 0x9b5974: r17 = "cameraId"
    //     0x9b5974: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0x9b5978: ldr             x17, [x17, #0x890]
    // 0x9b597c: StoreField: r2->field_f = r17
    //     0x9b597c: stur            w17, [x2, #0xf]
    // 0x9b5980: ldur            x3, [fp, #-0x60]
    // 0x9b5984: r0 = BoxInt64Instr(r3)
    //     0x9b5984: sbfiz           x0, x3, #1, #0x1f
    //     0x9b5988: cmp             x3, x0, asr #1
    //     0x9b598c: b.eq            #0x9b5998
    //     0x9b5990: bl              #0xd69bb8
    //     0x9b5994: stur            x3, [x0, #7]
    // 0x9b5998: StoreField: r2->field_13 = r0
    //     0x9b5998: stur            w0, [x2, #0x13]
    // 0x9b599c: r17 = "mode"
    //     0x9b599c: add             x17, PP, #8, lsl #12  ; [pp+0x8f18] "mode"
    //     0x9b59a0: ldr             x17, [x17, #0xf18]
    // 0x9b59a4: StoreField: r2->field_17 = r17
    //     0x9b59a4: stur            w17, [x2, #0x17]
    // 0x9b59a8: ldur            x0, [fp, #-0x50]
    // 0x9b59ac: LoadField: r1 = r0->field_7
    //     0x9b59ac: ldur            x1, [x0, #7]
    // 0x9b59b0: cmp             x1, #0
    // 0x9b59b4: b.gt            #0x9b59c4
    // 0x9b59b8: r1 = "auto"
    //     0x9b59b8: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c7d0] "auto"
    //     0x9b59bc: ldr             x1, [x1, #0x7d0]
    // 0x9b59c0: b               #0x9b59cc
    // 0x9b59c4: r1 = "locked"
    //     0x9b59c4: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d978] "locked"
    //     0x9b59c8: ldr             x1, [x1, #0x978]
    // 0x9b59cc: StoreField: r2->field_1b = r1
    //     0x9b59cc: stur            w1, [x2, #0x1b]
    // 0x9b59d0: r16 = <String, dynamic>
    //     0x9b59d0: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x9b59d4: stp             x2, x16, [SP, #-0x10]!
    // 0x9b59d8: r0 = Map._fromLiteral()
    //     0x9b59d8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9b59dc: add             SP, SP, #0x10
    // 0x9b59e0: r16 = <void?>
    //     0x9b59e0: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x9b59e4: r30 = Instance_MethodChannel
    //     0x9b59e4: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0x9b59e8: ldr             lr, [lr, #0x360]
    // 0x9b59ec: stp             lr, x16, [SP, #-0x10]!
    // 0x9b59f0: r16 = "setExposureMode"
    //     0x9b59f0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d980] "setExposureMode"
    //     0x9b59f4: ldr             x16, [x16, #0x980]
    // 0x9b59f8: stp             x0, x16, [SP, #-0x10]!
    // 0x9b59fc: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x9b59fc: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x9b5a00: r0 = invokeMethod()
    //     0x9b5a00: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x9b5a04: add             SP, SP, #0x20
    // 0x9b5a08: mov             x2, x0
    // 0x9b5a0c: b               #0x9b5b80
    // 0x9b5a10: r17 = 9916
    //     0x9b5a10: mov             x17, #0x26bc
    // 0x9b5a14: cmp             w1, w17
    // 0x9b5a18: b.ne            #0x9b5ad0
    // 0x9b5a1c: ldur            x3, [fp, #-0x50]
    // 0x9b5a20: ldur            x0, [fp, #-0x60]
    // 0x9b5a24: r1 = Null
    //     0x9b5a24: mov             x1, NULL
    // 0x9b5a28: r2 = 8
    //     0x9b5a28: mov             x2, #8
    // 0x9b5a2c: r0 = AllocateArray()
    //     0x9b5a2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9b5a30: mov             x2, x0
    // 0x9b5a34: r17 = "cameraId"
    //     0x9b5a34: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0x9b5a38: ldr             x17, [x17, #0x890]
    // 0x9b5a3c: StoreField: r2->field_f = r17
    //     0x9b5a3c: stur            w17, [x2, #0xf]
    // 0x9b5a40: ldur            x3, [fp, #-0x60]
    // 0x9b5a44: r0 = BoxInt64Instr(r3)
    //     0x9b5a44: sbfiz           x0, x3, #1, #0x1f
    //     0x9b5a48: cmp             x3, x0, asr #1
    //     0x9b5a4c: b.eq            #0x9b5a58
    //     0x9b5a50: bl              #0xd69bb8
    //     0x9b5a54: stur            x3, [x0, #7]
    // 0x9b5a58: StoreField: r2->field_13 = r0
    //     0x9b5a58: stur            w0, [x2, #0x13]
    // 0x9b5a5c: r17 = "mode"
    //     0x9b5a5c: add             x17, PP, #8, lsl #12  ; [pp+0x8f18] "mode"
    //     0x9b5a60: ldr             x17, [x17, #0xf18]
    // 0x9b5a64: StoreField: r2->field_17 = r17
    //     0x9b5a64: stur            w17, [x2, #0x17]
    // 0x9b5a68: ldur            x0, [fp, #-0x50]
    // 0x9b5a6c: LoadField: r1 = r0->field_7
    //     0x9b5a6c: ldur            x1, [x0, #7]
    // 0x9b5a70: cmp             x1, #0
    // 0x9b5a74: b.gt            #0x9b5a84
    // 0x9b5a78: r1 = "auto"
    //     0x9b5a78: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c7d0] "auto"
    //     0x9b5a7c: ldr             x1, [x1, #0x7d0]
    // 0x9b5a80: b               #0x9b5a8c
    // 0x9b5a84: r1 = "locked"
    //     0x9b5a84: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d978] "locked"
    //     0x9b5a88: ldr             x1, [x1, #0x978]
    // 0x9b5a8c: StoreField: r2->field_1b = r1
    //     0x9b5a8c: stur            w1, [x2, #0x1b]
    // 0x9b5a90: r16 = <String, dynamic>
    //     0x9b5a90: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x9b5a94: stp             x2, x16, [SP, #-0x10]!
    // 0x9b5a98: r0 = Map._fromLiteral()
    //     0x9b5a98: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9b5a9c: add             SP, SP, #0x10
    // 0x9b5aa0: r16 = <void?>
    //     0x9b5aa0: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x9b5aa4: r30 = Instance_MethodChannel
    //     0x9b5aa4: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0x9b5aa8: ldr             lr, [lr, #0x370]
    // 0x9b5aac: stp             lr, x16, [SP, #-0x10]!
    // 0x9b5ab0: r16 = "setExposureMode"
    //     0x9b5ab0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d980] "setExposureMode"
    //     0x9b5ab4: ldr             x16, [x16, #0x980]
    // 0x9b5ab8: stp             x0, x16, [SP, #-0x10]!
    // 0x9b5abc: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x9b5abc: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x9b5ac0: r0 = invokeMethod()
    //     0x9b5ac0: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x9b5ac4: add             SP, SP, #0x20
    // 0x9b5ac8: mov             x2, x0
    // 0x9b5acc: b               #0x9b5b80
    // 0x9b5ad0: ldur            x3, [fp, #-0x50]
    // 0x9b5ad4: ldur            x0, [fp, #-0x60]
    // 0x9b5ad8: r1 = Null
    //     0x9b5ad8: mov             x1, NULL
    // 0x9b5adc: r2 = 8
    //     0x9b5adc: mov             x2, #8
    // 0x9b5ae0: r0 = AllocateArray()
    //     0x9b5ae0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9b5ae4: mov             x2, x0
    // 0x9b5ae8: r17 = "cameraId"
    //     0x9b5ae8: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0x9b5aec: ldr             x17, [x17, #0x890]
    // 0x9b5af0: StoreField: r2->field_f = r17
    //     0x9b5af0: stur            w17, [x2, #0xf]
    // 0x9b5af4: ldur            x3, [fp, #-0x60]
    // 0x9b5af8: r0 = BoxInt64Instr(r3)
    //     0x9b5af8: sbfiz           x0, x3, #1, #0x1f
    //     0x9b5afc: cmp             x3, x0, asr #1
    //     0x9b5b00: b.eq            #0x9b5b0c
    //     0x9b5b04: bl              #0xd69bb8
    //     0x9b5b08: stur            x3, [x0, #7]
    // 0x9b5b0c: StoreField: r2->field_13 = r0
    //     0x9b5b0c: stur            w0, [x2, #0x13]
    // 0x9b5b10: r17 = "mode"
    //     0x9b5b10: add             x17, PP, #8, lsl #12  ; [pp+0x8f18] "mode"
    //     0x9b5b14: ldr             x17, [x17, #0xf18]
    // 0x9b5b18: StoreField: r2->field_17 = r17
    //     0x9b5b18: stur            w17, [x2, #0x17]
    // 0x9b5b1c: ldur            x0, [fp, #-0x50]
    // 0x9b5b20: LoadField: r1 = r0->field_7
    //     0x9b5b20: ldur            x1, [x0, #7]
    // 0x9b5b24: cmp             x1, #0
    // 0x9b5b28: b.gt            #0x9b5b38
    // 0x9b5b2c: r1 = "auto"
    //     0x9b5b2c: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c7d0] "auto"
    //     0x9b5b30: ldr             x1, [x1, #0x7d0]
    // 0x9b5b34: b               #0x9b5b40
    // 0x9b5b38: r1 = "locked"
    //     0x9b5b38: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d978] "locked"
    //     0x9b5b3c: ldr             x1, [x1, #0x978]
    // 0x9b5b40: StoreField: r2->field_1b = r1
    //     0x9b5b40: stur            w1, [x2, #0x1b]
    // 0x9b5b44: r16 = <String, dynamic>
    //     0x9b5b44: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x9b5b48: stp             x2, x16, [SP, #-0x10]!
    // 0x9b5b4c: r0 = Map._fromLiteral()
    //     0x9b5b4c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9b5b50: add             SP, SP, #0x10
    // 0x9b5b54: r16 = <void?>
    //     0x9b5b54: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x9b5b58: r30 = Instance_MethodChannel
    //     0x9b5b58: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d378] Obj!MethodChannel@b34b71
    //     0x9b5b5c: ldr             lr, [lr, #0x378]
    // 0x9b5b60: stp             lr, x16, [SP, #-0x10]!
    // 0x9b5b64: r16 = "setExposureMode"
    //     0x9b5b64: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d980] "setExposureMode"
    //     0x9b5b68: ldr             x16, [x16, #0x980]
    // 0x9b5b6c: stp             x0, x16, [SP, #-0x10]!
    // 0x9b5b70: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x9b5b70: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x9b5b74: r0 = invokeMethod()
    //     0x9b5b74: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x9b5b78: add             SP, SP, #0x20
    // 0x9b5b7c: mov             x2, x0
    // 0x9b5b80: ldur            x1, [fp, #-0x58]
    // 0x9b5b84: mov             x0, x2
    // 0x9b5b88: stur            x2, [fp, #-0x68]
    // 0x9b5b8c: r0 = Await()
    //     0x9b5b8c: bl              #0x4b8e6c  ; AwaitStub
    // 0x9b5b90: ldur            x0, [fp, #-0x58]
    // 0x9b5b94: LoadField: r1 = r0->field_27
    //     0x9b5b94: ldur            w1, [x0, #0x27]
    // 0x9b5b98: DecompressPointer r1
    //     0x9b5b98: add             x1, x1, HEAP, lsl #32
    // 0x9b5b9c: ldur            x16, [fp, #-0x50]
    // 0x9b5ba0: stp             x16, x1, [SP, #-0x10]!
    // 0x9b5ba4: r4 = const [0, 0x2, 0x2, 0x1, exposureMode, 0x1, null]
    //     0x9b5ba4: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d988] List(7) [0, 0x2, 0x2, 0x1, "exposureMode", 0x1, Null]
    //     0x9b5ba8: ldr             x4, [x4, #0x988]
    // 0x9b5bac: r0 = copyWith()
    //     0x9b5bac: bl              #0x5a9868  ; [package:camera/src/camera_controller.dart] CameraValue::copyWith
    // 0x9b5bb0: add             SP, SP, #0x10
    // 0x9b5bb4: stur            x0, [fp, #-0x50]
    // 0x9b5bb8: ldur            x16, [fp, #-0x58]
    // 0x9b5bbc: stp             x0, x16, [SP, #-0x10]!
    // 0x9b5bc0: r0 = value=()
    //     0x9b5bc0: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x9b5bc4: add             SP, SP, #0x10
    // 0x9b5bc8: r0 = Null
    //     0x9b5bc8: mov             x0, NULL
    // 0x9b5bcc: r0 = ReturnAsyncNotFuture()
    //     0x9b5bcc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9b5bd0: sub             SP, fp, #0x68
    // 0x9b5bd4: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9b5bd4: mov             x2, #0x76
    //     0x9b5bd8: tbz             w0, #0, #0x9b5be8
    //     0x9b5bdc: ldur            x2, [x0, #-1]
    //     0x9b5be0: ubfx            x2, x2, #0xc, #0x14
    //     0x9b5be4: lsl             x2, x2, #1
    // 0x9b5be8: cmp             w2, #0xf28
    // 0x9b5bec: b.ne            #0x9b5c2c
    // 0x9b5bf0: LoadField: r1 = r0->field_7
    //     0x9b5bf0: ldur            w1, [x0, #7]
    // 0x9b5bf4: DecompressPointer r1
    //     0x9b5bf4: add             x1, x1, HEAP, lsl #32
    // 0x9b5bf8: stur            x1, [fp, #-0x58]
    // 0x9b5bfc: LoadField: r2 = r0->field_b
    //     0x9b5bfc: ldur            w2, [x0, #0xb]
    // 0x9b5c00: DecompressPointer r2
    //     0x9b5c00: add             x2, x2, HEAP, lsl #32
    // 0x9b5c04: stur            x2, [fp, #-0x50]
    // 0x9b5c08: r0 = CameraException()
    //     0x9b5c08: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0x9b5c0c: mov             x1, x0
    // 0x9b5c10: ldur            x0, [fp, #-0x58]
    // 0x9b5c14: StoreField: r1->field_7 = r0
    //     0x9b5c14: stur            w0, [x1, #7]
    // 0x9b5c18: ldur            x0, [fp, #-0x50]
    // 0x9b5c1c: StoreField: r1->field_b = r0
    //     0x9b5c1c: stur            w0, [x1, #0xb]
    // 0x9b5c20: mov             x0, x1
    // 0x9b5c24: r0 = Throw()
    //     0x9b5c24: bl              #0xd67e38  ; ThrowStub
    // 0x9b5c28: brk             #0
    // 0x9b5c2c: r0 = ReThrow()
    //     0x9b5c2c: bl              #0xd67e14  ; ReThrowStub
    // 0x9b5c30: brk             #0
    // 0x9b5c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b5c34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b5c38: b               #0x9b5908
  }
  dynamic dispose(dynamic) {
    // ** addr: 0x9b9e48, size: 0x18
    // 0x9b9e48: r4 = 35
    //     0x9b9e48: mov             x4, #0x23
    // 0x9b9e4c: r1 = Function 'dispose':.
    //     0x9b9e4c: add             x17, PP, #0x54, lsl #12  ; [pp+0x54388] AnonymousClosure: (0x9b9e60), in [package:camera/src/camera_controller.dart] CameraController::dispose (0x9c15c0)
    //     0x9b9e50: ldr             x1, [x17, #0x388]
    // 0x9b9e54: r24 = BuildNonGenericMethodExtractorStub
    //     0x9b9e54: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x9b9e58: LoadField: r0 = r24->field_17
    //     0x9b9e58: ldur            x0, [x24, #0x17]
    // 0x9b9e5c: br              x0
  }
  [closure] Future<void> dispose(dynamic) {
    // ** addr: 0x9b9e60, size: 0x48
    // 0x9b9e60: EnterFrame
    //     0x9b9e60: stp             fp, lr, [SP, #-0x10]!
    //     0x9b9e64: mov             fp, SP
    // 0x9b9e68: ldr             x0, [fp, #0x10]
    // 0x9b9e6c: LoadField: r1 = r0->field_17
    //     0x9b9e6c: ldur            w1, [x0, #0x17]
    // 0x9b9e70: DecompressPointer r1
    //     0x9b9e70: add             x1, x1, HEAP, lsl #32
    // 0x9b9e74: CheckStackOverflow
    //     0x9b9e74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9b9e78: cmp             SP, x16
    //     0x9b9e7c: b.ls            #0x9b9ea0
    // 0x9b9e80: LoadField: r0 = r1->field_f
    //     0x9b9e80: ldur            w0, [x1, #0xf]
    // 0x9b9e84: DecompressPointer r0
    //     0x9b9e84: add             x0, x0, HEAP, lsl #32
    // 0x9b9e88: SaveReg r0
    //     0x9b9e88: str             x0, [SP, #-8]!
    // 0x9b9e8c: r0 = dispose()
    //     0x9b9e8c: bl              #0x9c15c0  ; [package:camera/src/camera_controller.dart] CameraController::dispose
    // 0x9b9e90: add             SP, SP, #8
    // 0x9b9e94: LeaveFrame
    //     0x9b9e94: mov             SP, fp
    //     0x9b9e98: ldp             fp, lr, [SP], #0x10
    // 0x9b9e9c: ret
    //     0x9b9e9c: ret             
    // 0x9b9ea0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b9ea0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b9ea4: b               #0x9b9e80
  }
  _ dispose(/* No info */) async {
    // ** addr: 0x9c15c0, size: 0x120
    // 0x9c15c0: EnterFrame
    //     0x9c15c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c15c4: mov             fp, SP
    // 0x9c15c8: AllocStack(0x18)
    //     0x9c15c8: sub             SP, SP, #0x18
    // 0x9c15cc: SetupParameters(CameraController<CameraValue> this /* r1, fp-0x10 */)
    //     0x9c15cc: stur            NULL, [fp, #-8]
    //     0x9c15d0: mov             x0, #0
    //     0x9c15d4: add             x1, fp, w0, sxtw #2
    //     0x9c15d8: ldr             x1, [x1, #0x10]
    //     0x9c15dc: stur            x1, [fp, #-0x10]
    // 0x9c15e0: CheckStackOverflow
    //     0x9c15e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9c15e4: cmp             SP, x16
    //     0x9c15e8: b.ls            #0x9c16d8
    // 0x9c15ec: InitAsync() -> Future<void?>
    //     0x9c15ec: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9c15f0: bl              #0x4b92e4
    // 0x9c15f4: ldur            x1, [fp, #-0x10]
    // 0x9c15f8: LoadField: r0 = r1->field_3f
    //     0x9c15f8: ldur            w0, [x1, #0x3f]
    // 0x9c15fc: DecompressPointer r0
    //     0x9c15fc: add             x0, x0, HEAP, lsl #32
    // 0x9c1600: tbnz            w0, #4, #0x9c160c
    // 0x9c1604: r0 = Null
    //     0x9c1604: mov             x0, NULL
    // 0x9c1608: r0 = ReturnAsyncNotFuture()
    //     0x9c1608: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9c160c: LoadField: r0 = r1->field_4b
    //     0x9c160c: ldur            w0, [x1, #0x4b]
    // 0x9c1610: DecompressPointer r0
    //     0x9c1610: add             x0, x0, HEAP, lsl #32
    // 0x9c1614: cmp             w0, NULL
    // 0x9c1618: b.ne            #0x9c1624
    // 0x9c161c: mov             x0, x1
    // 0x9c1620: b               #0x9c1648
    // 0x9c1624: r2 = LoadClassIdInstr(r0)
    //     0x9c1624: ldur            x2, [x0, #-1]
    //     0x9c1628: ubfx            x2, x2, #0xc, #0x14
    // 0x9c162c: SaveReg r0
    //     0x9c162c: str             x0, [SP, #-8]!
    // 0x9c1630: mov             x0, x2
    // 0x9c1634: r0 = GDT[cid_x0 + 0x307]()
    //     0x9c1634: add             lr, x0, #0x307
    //     0x9c1638: ldr             lr, [x21, lr, lsl #3]
    //     0x9c163c: blr             lr
    // 0x9c1640: add             SP, SP, #8
    // 0x9c1644: ldur            x0, [fp, #-0x10]
    // 0x9c1648: r1 = true
    //     0x9c1648: add             x1, NULL, #0x20  ; true
    // 0x9c164c: StoreField: r0->field_3f = r1
    //     0x9c164c: stur            w1, [x0, #0x3f]
    // 0x9c1650: SaveReg r0
    //     0x9c1650: str             x0, [SP, #-8]!
    // 0x9c1654: r0 = dispose()
    //     0x9c1654: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x9c1658: add             SP, SP, #8
    // 0x9c165c: ldur            x1, [fp, #-0x10]
    // 0x9c1660: LoadField: r2 = r1->field_47
    //     0x9c1660: ldur            w2, [x1, #0x47]
    // 0x9c1664: DecompressPointer r2
    //     0x9c1664: add             x2, x2, HEAP, lsl #32
    // 0x9c1668: stur            x2, [fp, #-0x18]
    // 0x9c166c: cmp             w2, NULL
    // 0x9c1670: b.eq            #0x9c16d0
    // 0x9c1674: mov             x0, x2
    // 0x9c1678: r0 = Await()
    //     0x9c1678: bl              #0x4b8e6c  ; AwaitStub
    // 0x9c167c: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0x9c167c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9c1680: ldr             x0, [x0, #0x1590]
    //     0x9c1684: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9c1688: cmp             w0, w16
    //     0x9c168c: b.ne            #0x9c169c
    //     0x9c1690: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0x9c1694: ldr             x2, [x2, #0x270]
    //     0x9c1698: bl              #0xd67d44
    // 0x9c169c: mov             x1, x0
    // 0x9c16a0: ldur            x0, [fp, #-0x10]
    // 0x9c16a4: LoadField: r2 = r0->field_37
    //     0x9c16a4: ldur            x2, [x0, #0x37]
    // 0x9c16a8: r0 = LoadClassIdInstr(r1)
    //     0x9c16a8: ldur            x0, [x1, #-1]
    //     0x9c16ac: ubfx            x0, x0, #0xc, #0x14
    // 0x9c16b0: stp             x2, x1, [SP, #-0x10]!
    // 0x9c16b4: r0 = GDT[cid_x0 + -0x5ee]()
    //     0x9c16b4: sub             lr, x0, #0x5ee
    //     0x9c16b8: ldr             lr, [x21, lr, lsl #3]
    //     0x9c16bc: blr             lr
    // 0x9c16c0: add             SP, SP, #0x10
    // 0x9c16c4: mov             x1, x0
    // 0x9c16c8: stur            x1, [fp, #-0x10]
    // 0x9c16cc: r0 = Await()
    //     0x9c16cc: bl              #0x4b8e6c  ; AwaitStub
    // 0x9c16d0: r0 = Null
    //     0x9c16d0: mov             x0, NULL
    // 0x9c16d4: r0 = ReturnAsyncNotFuture()
    //     0x9c16d4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9c16d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c16d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c16dc: b               #0x9c15ec
  }
  _ buildPreview(/* No info */) {
    // ** addr: 0xb1be88, size: 0x190
    // 0xb1be88: EnterFrame
    //     0xb1be88: stp             fp, lr, [SP, #-0x10]!
    //     0xb1be8c: mov             fp, SP
    // 0xb1be90: AllocStack(0x48)
    //     0xb1be90: sub             SP, SP, #0x48
    // 0xb1be94: CheckStackOverflow
    //     0xb1be94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1be98: cmp             SP, x16
    //     0xb1be9c: b.ls            #0xb1c010
    // 0xb1bea0: ldr             x16, [fp, #0x10]
    // 0xb1bea4: r30 = "buildPreview"
    //     0xb1bea4: add             lr, PP, #0x54, lsl #12  ; [pp+0x54300] "buildPreview"
    //     0xb1bea8: ldr             lr, [lr, #0x300]
    // 0xb1beac: stp             lr, x16, [SP, #-0x10]!
    // 0xb1beb0: r0 = _throwIfNotInitialized()
    //     0xb1beb0: bl              #0x5a81ec  ; [package:camera/src/camera_controller.dart] CameraController::_throwIfNotInitialized
    // 0xb1beb4: add             SP, SP, #0x10
    // 0xb1beb8: ldr             x0, [fp, #0x10]
    // 0xb1bebc: r0 = InitLateStaticField(0xac8) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_instance
    //     0xb1bebc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xb1bec0: ldr             x0, [x0, #0x1590]
    //     0xb1bec4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xb1bec8: cmp             w0, w16
    //     0xb1becc: b.ne            #0xb1bedc
    //     0xb1bed0: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d270] Field <CameraPlatform._instance@176219459>: static late (offset: 0xac8)
    //     0xb1bed4: ldr             x2, [x2, #0x270]
    //     0xb1bed8: bl              #0xd67d44
    // 0xb1bedc: mov             x1, x0
    // 0xb1bee0: ldr             x0, [fp, #0x10]
    // 0xb1bee4: stur            x1, [fp, #-0x40]
    // 0xb1bee8: LoadField: r2 = r0->field_37
    //     0xb1bee8: ldur            x2, [x0, #0x37]
    // 0xb1beec: stur            x2, [fp, #-0x38]
    // 0xb1bef0: r0 = LoadClassIdInstr(r1)
    //     0xb1bef0: ldur            x0, [x1, #-1]
    //     0xb1bef4: ubfx            x0, x0, #0xc, #0x14
    // 0xb1bef8: lsl             x0, x0, #1
    // 0xb1befc: r17 = 9914
    //     0xb1befc: mov             x17, #0x26ba
    // 0xb1bf00: cmp             w0, w17
    // 0xb1bf04: b.ne            #0xb1bf2c
    // 0xb1bf08: r0 = Texture()
    //     0xb1bf08: bl              #0x98d3c4  ; AllocateTextureStub -> Texture (size=0x1c)
    // 0xb1bf0c: ldur            x1, [fp, #-0x38]
    // 0xb1bf10: StoreField: r0->field_b = r1
    //     0xb1bf10: stur            x1, [x0, #0xb]
    // 0xb1bf14: r2 = false
    //     0xb1bf14: add             x2, NULL, #0x30  ; false
    // 0xb1bf18: StoreField: r0->field_13 = r2
    //     0xb1bf18: stur            w2, [x0, #0x13]
    // 0xb1bf1c: r3 = Instance_FilterQuality
    //     0xb1bf1c: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0xb1bf20: ldr             x3, [x3, #0x548]
    // 0xb1bf24: StoreField: r0->field_17 = r3
    //     0xb1bf24: stur            w3, [x0, #0x17]
    // 0xb1bf28: b               #0xb1bfa0
    // 0xb1bf2c: mov             x1, x2
    // 0xb1bf30: r2 = false
    //     0xb1bf30: add             x2, NULL, #0x30  ; false
    // 0xb1bf34: r3 = Instance_FilterQuality
    //     0xb1bf34: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0xb1bf38: ldr             x3, [x3, #0x548]
    // 0xb1bf3c: r17 = 9916
    //     0xb1bf3c: mov             x17, #0x26bc
    // 0xb1bf40: cmp             w0, w17
    // 0xb1bf44: b.ne            #0xb1bf74
    // 0xb1bf48: r0 = Texture()
    //     0xb1bf48: bl              #0x98d3c4  ; AllocateTextureStub -> Texture (size=0x1c)
    // 0xb1bf4c: mov             x1, x0
    // 0xb1bf50: ldur            x0, [fp, #-0x38]
    // 0xb1bf54: StoreField: r1->field_b = r0
    //     0xb1bf54: stur            x0, [x1, #0xb]
    // 0xb1bf58: r2 = false
    //     0xb1bf58: add             x2, NULL, #0x30  ; false
    // 0xb1bf5c: StoreField: r1->field_13 = r2
    //     0xb1bf5c: stur            w2, [x1, #0x13]
    // 0xb1bf60: r3 = Instance_FilterQuality
    //     0xb1bf60: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0xb1bf64: ldr             x3, [x3, #0x548]
    // 0xb1bf68: StoreField: r1->field_17 = r3
    //     0xb1bf68: stur            w3, [x1, #0x17]
    // 0xb1bf6c: mov             x0, x1
    // 0xb1bf70: b               #0xb1bfa0
    // 0xb1bf74: mov             x0, x1
    // 0xb1bf78: r0 = Texture()
    //     0xb1bf78: bl              #0x98d3c4  ; AllocateTextureStub -> Texture (size=0x1c)
    // 0xb1bf7c: mov             x1, x0
    // 0xb1bf80: ldur            x0, [fp, #-0x38]
    // 0xb1bf84: StoreField: r1->field_b = r0
    //     0xb1bf84: stur            x0, [x1, #0xb]
    // 0xb1bf88: r0 = false
    //     0xb1bf88: add             x0, NULL, #0x30  ; false
    // 0xb1bf8c: StoreField: r1->field_13 = r0
    //     0xb1bf8c: stur            w0, [x1, #0x13]
    // 0xb1bf90: r0 = Instance_FilterQuality
    //     0xb1bf90: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0xb1bf94: ldr             x0, [x0, #0x548]
    // 0xb1bf98: StoreField: r1->field_17 = r0
    //     0xb1bf98: stur            w0, [x1, #0x17]
    // 0xb1bf9c: mov             x0, x1
    // 0xb1bfa0: LeaveFrame
    //     0xb1bfa0: mov             SP, fp
    //     0xb1bfa4: ldp             fp, lr, [SP], #0x10
    // 0xb1bfa8: ret
    //     0xb1bfa8: ret             
    // 0xb1bfac: sub             SP, fp, #0x48
    // 0xb1bfb0: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xb1bfb0: mov             x2, #0x76
    //     0xb1bfb4: tbz             w0, #0, #0xb1bfc4
    //     0xb1bfb8: ldur            x2, [x0, #-1]
    //     0xb1bfbc: ubfx            x2, x2, #0xc, #0x14
    //     0xb1bfc0: lsl             x2, x2, #1
    // 0xb1bfc4: cmp             w2, #0xf28
    // 0xb1bfc8: b.ne            #0xb1c008
    // 0xb1bfcc: LoadField: r1 = r0->field_7
    //     0xb1bfcc: ldur            w1, [x0, #7]
    // 0xb1bfd0: DecompressPointer r1
    //     0xb1bfd0: add             x1, x1, HEAP, lsl #32
    // 0xb1bfd4: stur            x1, [fp, #-0x48]
    // 0xb1bfd8: LoadField: r2 = r0->field_b
    //     0xb1bfd8: ldur            w2, [x0, #0xb]
    // 0xb1bfdc: DecompressPointer r2
    //     0xb1bfdc: add             x2, x2, HEAP, lsl #32
    // 0xb1bfe0: stur            x2, [fp, #-0x40]
    // 0xb1bfe4: r0 = CameraException()
    //     0xb1bfe4: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xb1bfe8: mov             x1, x0
    // 0xb1bfec: ldur            x0, [fp, #-0x48]
    // 0xb1bff0: StoreField: r1->field_7 = r0
    //     0xb1bff0: stur            w0, [x1, #7]
    // 0xb1bff4: ldur            x0, [fp, #-0x40]
    // 0xb1bff8: StoreField: r1->field_b = r0
    //     0xb1bff8: stur            w0, [x1, #0xb]
    // 0xb1bffc: mov             x0, x1
    // 0xb1c000: r0 = Throw()
    //     0xb1c000: bl              #0xd67e38  ; ThrowStub
    // 0xb1c004: brk             #0
    // 0xb1c008: r0 = ReThrow()
    //     0xb1c008: bl              #0xd67e14  ; ReThrowStub
    // 0xb1c00c: brk             #0
    // 0xb1c010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c010: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c014: b               #0xb1bea0
  }
  [closure] bool <anonymous closure>(dynamic, CameraInitializedEvent) {
    // ** addr: 0xcec048, size: 0x10
    // 0xcec048: ldr             x1, [SP]
    // 0xcec04c: LoadField: r0 = r1->field_2b
    //     0xcec04c: ldur            w0, [x1, #0x2b]
    // 0xcec050: DecompressPointer r0
    //     0xcec050: add             x0, x0, HEAP, lsl #32
    // 0xcec054: ret
    //     0xcec054: ret             
  }
  [closure] bool <anonymous closure>(dynamic, CameraInitializedEvent) {
    // ** addr: 0xcec0bc, size: 0x10
    // 0xcec0bc: ldr             x1, [SP]
    // 0xcec0c0: LoadField: r0 = r1->field_27
    //     0xcec0c0: ldur            w0, [x1, #0x27]
    // 0xcec0c4: DecompressPointer r0
    //     0xcec0c4: add             x0, x0, HEAP, lsl #32
    // 0xcec0c8: ret
    //     0xcec0c8: ret             
  }
  [closure] ExposureMode <anonymous closure>(dynamic, CameraInitializedEvent) {
    // ** addr: 0xcec1c8, size: 0x10
    // 0xcec1c8: ldr             x1, [SP]
    // 0xcec1cc: LoadField: r0 = r1->field_1f
    //     0xcec1cc: ldur            w0, [x1, #0x1f]
    // 0xcec1d0: DecompressPointer r0
    //     0xcec1d0: add             x0, x0, HEAP, lsl #32
    // 0xcec1d4: ret
    //     0xcec1d4: ret             
  }
  [closure] FocusMode <anonymous closure>(dynamic, CameraInitializedEvent) {
    // ** addr: 0xd1d87c, size: 0x10
    // 0xd1d87c: ldr             x1, [SP]
    // 0xd1d880: LoadField: r0 = r1->field_23
    //     0xd1d880: ldur            w0, [x1, #0x23]
    // 0xd1d884: DecompressPointer r0
    //     0xd1d884: add             x0, x0, HEAP, lsl #32
    // 0xd1d888: ret
    //     0xd1d888: ret             
  }
}

// class id: 4971, size: 0x50, field offset: 0x8
//   const constructor, 
class CameraValue extends Object {

  _ copyWith(/* No info */) {
    // ** addr: 0x5a9868, size: 0x83c
    // 0x5a9868: EnterFrame
    //     0x5a9868: stp             fp, lr, [SP, #-0x10]!
    //     0x5a986c: mov             fp, SP
    // 0x5a9870: AllocStack(0x88)
    //     0x5a9870: sub             SP, SP, #0x88
    // 0x5a9874: SetupParameters(CameraValue this /* r3 */, {dynamic description = Null /* fp-0x8 */, dynamic deviceOrientation = Null /* r5 */, dynamic exposureMode = Null /* r6 */, dynamic exposurePointSupported = Null /* r7 */, dynamic flashMode = Null /* r8 */, dynamic focusMode = Null /* r9 */, dynamic focusPointSupported = Null /* r10 */, dynamic isInitialized = Null /* r11 */, dynamic isPreviewPaused = Null /* r12 */, dynamic isRecordingPaused, dynamic isRecordingVideo = Null /* r13 */, dynamic isStreamingImages = Null /* r14 */, dynamic isTakingPicture = Null /* r19 */, dynamic lockedCaptureOrientation = Null /* r20 */, dynamic previewPauseOrientation = Null /* fp-0x10 */, dynamic previewSize = Null /* r4 */, dynamic recordingOrientation = Null /* r0 */})
    //     0x5a9874: mov             x0, x4
    //     0x5a9878: ldur            w1, [x0, #0x13]
    //     0x5a987c: add             x1, x1, HEAP, lsl #32
    //     0x5a9880: sub             x2, x1, #2
    //     0x5a9884: add             x3, fp, w2, sxtw #2
    //     0x5a9888: ldr             x3, [x3, #0x10]
    //     0x5a988c: ldur            w2, [x0, #0x1f]
    //     0x5a9890: add             x2, x2, HEAP, lsl #32
    //     0x5a9894: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b70] "description"
    //     0x5a9898: ldr             x16, [x16, #0xb70]
    //     0x5a989c: cmp             w2, w16
    //     0x5a98a0: b.ne            #0x5a98c4
    //     0x5a98a4: ldur            w2, [x0, #0x23]
    //     0x5a98a8: add             x2, x2, HEAP, lsl #32
    //     0x5a98ac: sub             w4, w1, w2
    //     0x5a98b0: add             x2, fp, w4, sxtw #2
    //     0x5a98b4: ldr             x2, [x2, #8]
    //     0x5a98b8: mov             x4, x2
    //     0x5a98bc: mov             x2, #1
    //     0x5a98c0: b               #0x5a98cc
    //     0x5a98c4: mov             x4, NULL
    //     0x5a98c8: mov             x2, #0
    //     0x5a98cc: stur            x4, [fp, #-8]
    //     0x5a98d0: lsl             x5, x2, #1
    //     0x5a98d4: lsl             w6, w5, #1
    //     0x5a98d8: add             w7, w6, #8
    //     0x5a98dc: add             x16, x0, w7, sxtw #1
    //     0x5a98e0: ldur            w8, [x16, #0xf]
    //     0x5a98e4: add             x8, x8, HEAP, lsl #32
    //     0x5a98e8: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d470] "deviceOrientation"
    //     0x5a98ec: ldr             x16, [x16, #0x470]
    //     0x5a98f0: cmp             w8, w16
    //     0x5a98f4: b.ne            #0x5a9928
    //     0x5a98f8: add             w2, w6, #0xa
    //     0x5a98fc: add             x16, x0, w2, sxtw #1
    //     0x5a9900: ldur            w6, [x16, #0xf]
    //     0x5a9904: add             x6, x6, HEAP, lsl #32
    //     0x5a9908: sub             w2, w1, w6
    //     0x5a990c: add             x6, fp, w2, sxtw #2
    //     0x5a9910: ldr             x6, [x6, #8]
    //     0x5a9914: add             w2, w5, #2
    //     0x5a9918: sbfx            x5, x2, #1, #0x1f
    //     0x5a991c: mov             x2, x5
    //     0x5a9920: mov             x5, x6
    //     0x5a9924: b               #0x5a992c
    //     0x5a9928: mov             x5, NULL
    //     0x5a992c: lsl             x6, x2, #1
    //     0x5a9930: lsl             w7, w6, #1
    //     0x5a9934: add             w8, w7, #8
    //     0x5a9938: add             x16, x0, w8, sxtw #1
    //     0x5a993c: ldur            w9, [x16, #0xf]
    //     0x5a9940: add             x9, x9, HEAP, lsl #32
    //     0x5a9944: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d478] "exposureMode"
    //     0x5a9948: ldr             x16, [x16, #0x478]
    //     0x5a994c: cmp             w9, w16
    //     0x5a9950: b.ne            #0x5a9984
    //     0x5a9954: add             w2, w7, #0xa
    //     0x5a9958: add             x16, x0, w2, sxtw #1
    //     0x5a995c: ldur            w7, [x16, #0xf]
    //     0x5a9960: add             x7, x7, HEAP, lsl #32
    //     0x5a9964: sub             w2, w1, w7
    //     0x5a9968: add             x7, fp, w2, sxtw #2
    //     0x5a996c: ldr             x7, [x7, #8]
    //     0x5a9970: add             w2, w6, #2
    //     0x5a9974: sbfx            x6, x2, #1, #0x1f
    //     0x5a9978: mov             x2, x6
    //     0x5a997c: mov             x6, x7
    //     0x5a9980: b               #0x5a9988
    //     0x5a9984: mov             x6, NULL
    //     0x5a9988: lsl             x7, x2, #1
    //     0x5a998c: lsl             w8, w7, #1
    //     0x5a9990: add             w9, w8, #8
    //     0x5a9994: add             x16, x0, w9, sxtw #1
    //     0x5a9998: ldur            w10, [x16, #0xf]
    //     0x5a999c: add             x10, x10, HEAP, lsl #32
    //     0x5a99a0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d480] "exposurePointSupported"
    //     0x5a99a4: ldr             x16, [x16, #0x480]
    //     0x5a99a8: cmp             w10, w16
    //     0x5a99ac: b.ne            #0x5a99e0
    //     0x5a99b0: add             w2, w8, #0xa
    //     0x5a99b4: add             x16, x0, w2, sxtw #1
    //     0x5a99b8: ldur            w8, [x16, #0xf]
    //     0x5a99bc: add             x8, x8, HEAP, lsl #32
    //     0x5a99c0: sub             w2, w1, w8
    //     0x5a99c4: add             x8, fp, w2, sxtw #2
    //     0x5a99c8: ldr             x8, [x8, #8]
    //     0x5a99cc: add             w2, w7, #2
    //     0x5a99d0: sbfx            x7, x2, #1, #0x1f
    //     0x5a99d4: mov             x2, x7
    //     0x5a99d8: mov             x7, x8
    //     0x5a99dc: b               #0x5a99e4
    //     0x5a99e0: mov             x7, NULL
    //     0x5a99e4: lsl             x8, x2, #1
    //     0x5a99e8: lsl             w9, w8, #1
    //     0x5a99ec: add             w10, w9, #8
    //     0x5a99f0: add             x16, x0, w10, sxtw #1
    //     0x5a99f4: ldur            w11, [x16, #0xf]
    //     0x5a99f8: add             x11, x11, HEAP, lsl #32
    //     0x5a99fc: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d488] "flashMode"
    //     0x5a9a00: ldr             x16, [x16, #0x488]
    //     0x5a9a04: cmp             w11, w16
    //     0x5a9a08: b.ne            #0x5a9a3c
    //     0x5a9a0c: add             w2, w9, #0xa
    //     0x5a9a10: add             x16, x0, w2, sxtw #1
    //     0x5a9a14: ldur            w9, [x16, #0xf]
    //     0x5a9a18: add             x9, x9, HEAP, lsl #32
    //     0x5a9a1c: sub             w2, w1, w9
    //     0x5a9a20: add             x9, fp, w2, sxtw #2
    //     0x5a9a24: ldr             x9, [x9, #8]
    //     0x5a9a28: add             w2, w8, #2
    //     0x5a9a2c: sbfx            x8, x2, #1, #0x1f
    //     0x5a9a30: mov             x2, x8
    //     0x5a9a34: mov             x8, x9
    //     0x5a9a38: b               #0x5a9a40
    //     0x5a9a3c: mov             x8, NULL
    //     0x5a9a40: lsl             x9, x2, #1
    //     0x5a9a44: lsl             w10, w9, #1
    //     0x5a9a48: add             w11, w10, #8
    //     0x5a9a4c: add             x16, x0, w11, sxtw #1
    //     0x5a9a50: ldur            w12, [x16, #0xf]
    //     0x5a9a54: add             x12, x12, HEAP, lsl #32
    //     0x5a9a58: add             x16, PP, #0x45, lsl #12  ; [pp+0x45988] "focusMode"
    //     0x5a9a5c: ldr             x16, [x16, #0x988]
    //     0x5a9a60: cmp             w12, w16
    //     0x5a9a64: b.ne            #0x5a9a98
    //     0x5a9a68: add             w2, w10, #0xa
    //     0x5a9a6c: add             x16, x0, w2, sxtw #1
    //     0x5a9a70: ldur            w10, [x16, #0xf]
    //     0x5a9a74: add             x10, x10, HEAP, lsl #32
    //     0x5a9a78: sub             w2, w1, w10
    //     0x5a9a7c: add             x10, fp, w2, sxtw #2
    //     0x5a9a80: ldr             x10, [x10, #8]
    //     0x5a9a84: add             w2, w9, #2
    //     0x5a9a88: sbfx            x9, x2, #1, #0x1f
    //     0x5a9a8c: mov             x2, x9
    //     0x5a9a90: mov             x9, x10
    //     0x5a9a94: b               #0x5a9a9c
    //     0x5a9a98: mov             x9, NULL
    //     0x5a9a9c: lsl             x10, x2, #1
    //     0x5a9aa0: lsl             w11, w10, #1
    //     0x5a9aa4: add             w12, w11, #8
    //     0x5a9aa8: add             x16, x0, w12, sxtw #1
    //     0x5a9aac: ldur            w13, [x16, #0xf]
    //     0x5a9ab0: add             x13, x13, HEAP, lsl #32
    //     0x5a9ab4: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d490] "focusPointSupported"
    //     0x5a9ab8: ldr             x16, [x16, #0x490]
    //     0x5a9abc: cmp             w13, w16
    //     0x5a9ac0: b.ne            #0x5a9af4
    //     0x5a9ac4: add             w2, w11, #0xa
    //     0x5a9ac8: add             x16, x0, w2, sxtw #1
    //     0x5a9acc: ldur            w11, [x16, #0xf]
    //     0x5a9ad0: add             x11, x11, HEAP, lsl #32
    //     0x5a9ad4: sub             w2, w1, w11
    //     0x5a9ad8: add             x11, fp, w2, sxtw #2
    //     0x5a9adc: ldr             x11, [x11, #8]
    //     0x5a9ae0: add             w2, w10, #2
    //     0x5a9ae4: sbfx            x10, x2, #1, #0x1f
    //     0x5a9ae8: mov             x2, x10
    //     0x5a9aec: mov             x10, x11
    //     0x5a9af0: b               #0x5a9af8
    //     0x5a9af4: mov             x10, NULL
    //     0x5a9af8: lsl             x11, x2, #1
    //     0x5a9afc: lsl             w12, w11, #1
    //     0x5a9b00: add             w13, w12, #8
    //     0x5a9b04: add             x16, x0, w13, sxtw #1
    //     0x5a9b08: ldur            w14, [x16, #0xf]
    //     0x5a9b0c: add             x14, x14, HEAP, lsl #32
    //     0x5a9b10: add             x16, PP, #0x27, lsl #12  ; [pp+0x27798] "isInitialized"
    //     0x5a9b14: ldr             x16, [x16, #0x798]
    //     0x5a9b18: cmp             w14, w16
    //     0x5a9b1c: b.ne            #0x5a9b50
    //     0x5a9b20: add             w2, w12, #0xa
    //     0x5a9b24: add             x16, x0, w2, sxtw #1
    //     0x5a9b28: ldur            w12, [x16, #0xf]
    //     0x5a9b2c: add             x12, x12, HEAP, lsl #32
    //     0x5a9b30: sub             w2, w1, w12
    //     0x5a9b34: add             x12, fp, w2, sxtw #2
    //     0x5a9b38: ldr             x12, [x12, #8]
    //     0x5a9b3c: add             w2, w11, #2
    //     0x5a9b40: sbfx            x11, x2, #1, #0x1f
    //     0x5a9b44: mov             x2, x11
    //     0x5a9b48: mov             x11, x12
    //     0x5a9b4c: b               #0x5a9b54
    //     0x5a9b50: mov             x11, NULL
    //     0x5a9b54: lsl             x12, x2, #1
    //     0x5a9b58: lsl             w13, w12, #1
    //     0x5a9b5c: add             w14, w13, #8
    //     0x5a9b60: add             x16, x0, w14, sxtw #1
    //     0x5a9b64: ldur            w19, [x16, #0xf]
    //     0x5a9b68: add             x19, x19, HEAP, lsl #32
    //     0x5a9b6c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d498] "isPreviewPaused"
    //     0x5a9b70: ldr             x16, [x16, #0x498]
    //     0x5a9b74: cmp             w19, w16
    //     0x5a9b78: b.ne            #0x5a9bac
    //     0x5a9b7c: add             w2, w13, #0xa
    //     0x5a9b80: add             x16, x0, w2, sxtw #1
    //     0x5a9b84: ldur            w13, [x16, #0xf]
    //     0x5a9b88: add             x13, x13, HEAP, lsl #32
    //     0x5a9b8c: sub             w2, w1, w13
    //     0x5a9b90: add             x13, fp, w2, sxtw #2
    //     0x5a9b94: ldr             x13, [x13, #8]
    //     0x5a9b98: add             w2, w12, #2
    //     0x5a9b9c: sbfx            x12, x2, #1, #0x1f
    //     0x5a9ba0: mov             x2, x12
    //     0x5a9ba4: mov             x12, x13
    //     0x5a9ba8: b               #0x5a9bb0
    //     0x5a9bac: mov             x12, NULL
    //     0x5a9bb0: lsl             x13, x2, #1
    //     0x5a9bb4: lsl             w14, w13, #1
    //     0x5a9bb8: add             w19, w14, #8
    //     0x5a9bbc: add             x16, x0, w19, sxtw #1
    //     0x5a9bc0: ldur            w14, [x16, #0xf]
    //     0x5a9bc4: add             x14, x14, HEAP, lsl #32
    //     0x5a9bc8: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d4a0] "isRecordingPaused"
    //     0x5a9bcc: ldr             x16, [x16, #0x4a0]
    //     0x5a9bd0: cmp             w14, w16
    //     0x5a9bd4: b.ne            #0x5a9be4
    //     0x5a9bd8: add             w2, w13, #2
    //     0x5a9bdc: sbfx            x13, x2, #1, #0x1f
    //     0x5a9be0: mov             x2, x13
    //     0x5a9be4: lsl             x13, x2, #1
    //     0x5a9be8: lsl             w14, w13, #1
    //     0x5a9bec: add             w19, w14, #8
    //     0x5a9bf0: add             x16, x0, w19, sxtw #1
    //     0x5a9bf4: ldur            w20, [x16, #0xf]
    //     0x5a9bf8: add             x20, x20, HEAP, lsl #32
    //     0x5a9bfc: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d4a8] "isRecordingVideo"
    //     0x5a9c00: ldr             x16, [x16, #0x4a8]
    //     0x5a9c04: cmp             w20, w16
    //     0x5a9c08: b.ne            #0x5a9c3c
    //     0x5a9c0c: add             w2, w14, #0xa
    //     0x5a9c10: add             x16, x0, w2, sxtw #1
    //     0x5a9c14: ldur            w14, [x16, #0xf]
    //     0x5a9c18: add             x14, x14, HEAP, lsl #32
    //     0x5a9c1c: sub             w2, w1, w14
    //     0x5a9c20: add             x14, fp, w2, sxtw #2
    //     0x5a9c24: ldr             x14, [x14, #8]
    //     0x5a9c28: add             w2, w13, #2
    //     0x5a9c2c: sbfx            x13, x2, #1, #0x1f
    //     0x5a9c30: mov             x2, x13
    //     0x5a9c34: mov             x13, x14
    //     0x5a9c38: b               #0x5a9c40
    //     0x5a9c3c: mov             x13, NULL
    //     0x5a9c40: lsl             x14, x2, #1
    //     0x5a9c44: lsl             w19, w14, #1
    //     0x5a9c48: add             w20, w19, #8
    //     0x5a9c4c: add             x16, x0, w20, sxtw #1
    //     0x5a9c50: ldur            w23, [x16, #0xf]
    //     0x5a9c54: add             x23, x23, HEAP, lsl #32
    //     0x5a9c58: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d4b0] "isStreamingImages"
    //     0x5a9c5c: ldr             x16, [x16, #0x4b0]
    //     0x5a9c60: cmp             w23, w16
    //     0x5a9c64: b.ne            #0x5a9c98
    //     0x5a9c68: add             w2, w19, #0xa
    //     0x5a9c6c: add             x16, x0, w2, sxtw #1
    //     0x5a9c70: ldur            w19, [x16, #0xf]
    //     0x5a9c74: add             x19, x19, HEAP, lsl #32
    //     0x5a9c78: sub             w2, w1, w19
    //     0x5a9c7c: add             x19, fp, w2, sxtw #2
    //     0x5a9c80: ldr             x19, [x19, #8]
    //     0x5a9c84: add             w2, w14, #2
    //     0x5a9c88: sbfx            x14, x2, #1, #0x1f
    //     0x5a9c8c: mov             x2, x14
    //     0x5a9c90: mov             x14, x19
    //     0x5a9c94: b               #0x5a9c9c
    //     0x5a9c98: mov             x14, NULL
    //     0x5a9c9c: lsl             x19, x2, #1
    //     0x5a9ca0: lsl             w20, w19, #1
    //     0x5a9ca4: add             w23, w20, #8
    //     0x5a9ca8: add             x16, x0, w23, sxtw #1
    //     0x5a9cac: ldur            w24, [x16, #0xf]
    //     0x5a9cb0: add             x24, x24, HEAP, lsl #32
    //     0x5a9cb4: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d4b8] "isTakingPicture"
    //     0x5a9cb8: ldr             x16, [x16, #0x4b8]
    //     0x5a9cbc: cmp             w24, w16
    //     0x5a9cc0: b.ne            #0x5a9cf4
    //     0x5a9cc4: add             w2, w20, #0xa
    //     0x5a9cc8: add             x16, x0, w2, sxtw #1
    //     0x5a9ccc: ldur            w20, [x16, #0xf]
    //     0x5a9cd0: add             x20, x20, HEAP, lsl #32
    //     0x5a9cd4: sub             w2, w1, w20
    //     0x5a9cd8: add             x20, fp, w2, sxtw #2
    //     0x5a9cdc: ldr             x20, [x20, #8]
    //     0x5a9ce0: add             w2, w19, #2
    //     0x5a9ce4: sbfx            x19, x2, #1, #0x1f
    //     0x5a9ce8: mov             x2, x19
    //     0x5a9cec: mov             x19, x20
    //     0x5a9cf0: b               #0x5a9cf8
    //     0x5a9cf4: mov             x19, NULL
    //     0x5a9cf8: lsl             x20, x2, #1
    //     0x5a9cfc: lsl             w23, w20, #1
    //     0x5a9d00: add             w24, w23, #8
    //     0x5a9d04: add             x16, x0, w24, sxtw #1
    //     0x5a9d08: ldur            w25, [x16, #0xf]
    //     0x5a9d0c: add             x25, x25, HEAP, lsl #32
    //     0x5a9d10: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d4c0] "lockedCaptureOrientation"
    //     0x5a9d14: ldr             x16, [x16, #0x4c0]
    //     0x5a9d18: cmp             w25, w16
    //     0x5a9d1c: b.ne            #0x5a9d50
    //     0x5a9d20: add             w2, w23, #0xa
    //     0x5a9d24: add             x16, x0, w2, sxtw #1
    //     0x5a9d28: ldur            w23, [x16, #0xf]
    //     0x5a9d2c: add             x23, x23, HEAP, lsl #32
    //     0x5a9d30: sub             w2, w1, w23
    //     0x5a9d34: add             x23, fp, w2, sxtw #2
    //     0x5a9d38: ldr             x23, [x23, #8]
    //     0x5a9d3c: add             w2, w20, #2
    //     0x5a9d40: sbfx            x20, x2, #1, #0x1f
    //     0x5a9d44: mov             x2, x20
    //     0x5a9d48: mov             x20, x23
    //     0x5a9d4c: b               #0x5a9d54
    //     0x5a9d50: mov             x20, NULL
    //     0x5a9d54: lsl             x23, x2, #1
    //     0x5a9d58: lsl             w24, w23, #1
    //     0x5a9d5c: add             w25, w24, #8
    //     0x5a9d60: add             x16, x0, w25, sxtw #1
    //     0x5a9d64: ldur            w4, [x16, #0xf]
    //     0x5a9d68: add             x4, x4, HEAP, lsl #32
    //     0x5a9d6c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d4c8] "previewPauseOrientation"
    //     0x5a9d70: ldr             x16, [x16, #0x4c8]
    //     0x5a9d74: cmp             w4, w16
    //     0x5a9d78: b.ne            #0x5a9da8
    //     0x5a9d7c: add             w2, w24, #0xa
    //     0x5a9d80: add             x16, x0, w2, sxtw #1
    //     0x5a9d84: ldur            w4, [x16, #0xf]
    //     0x5a9d88: add             x4, x4, HEAP, lsl #32
    //     0x5a9d8c: sub             w2, w1, w4
    //     0x5a9d90: add             x4, fp, w2, sxtw #2
    //     0x5a9d94: ldr             x4, [x4, #8]
    //     0x5a9d98: add             w2, w23, #2
    //     0x5a9d9c: sbfx            x23, x2, #1, #0x1f
    //     0x5a9da0: mov             x2, x23
    //     0x5a9da4: b               #0x5a9dac
    //     0x5a9da8: mov             x4, NULL
    //     0x5a9dac: stur            x4, [fp, #-0x10]
    //     0x5a9db0: lsl             x23, x2, #1
    //     0x5a9db4: lsl             w24, w23, #1
    //     0x5a9db8: add             w25, w24, #8
    //     0x5a9dbc: add             x16, x0, w25, sxtw #1
    //     0x5a9dc0: ldur            w4, [x16, #0xf]
    //     0x5a9dc4: add             x4, x4, HEAP, lsl #32
    //     0x5a9dc8: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d4d0] "previewSize"
    //     0x5a9dcc: ldr             x16, [x16, #0x4d0]
    //     0x5a9dd0: cmp             w4, w16
    //     0x5a9dd4: b.ne            #0x5a9e04
    //     0x5a9dd8: add             w2, w24, #0xa
    //     0x5a9ddc: add             x16, x0, w2, sxtw #1
    //     0x5a9de0: ldur            w4, [x16, #0xf]
    //     0x5a9de4: add             x4, x4, HEAP, lsl #32
    //     0x5a9de8: sub             w2, w1, w4
    //     0x5a9dec: add             x4, fp, w2, sxtw #2
    //     0x5a9df0: ldr             x4, [x4, #8]
    //     0x5a9df4: add             w2, w23, #2
    //     0x5a9df8: sbfx            x23, x2, #1, #0x1f
    //     0x5a9dfc: mov             x2, x23
    //     0x5a9e00: b               #0x5a9e08
    //     0x5a9e04: mov             x4, NULL
    //     0x5a9e08: lsl             x23, x2, #1
    //     0x5a9e0c: lsl             w2, w23, #1
    //     0x5a9e10: add             w23, w2, #8
    //     0x5a9e14: add             x16, x0, w23, sxtw #1
    //     0x5a9e18: ldur            w24, [x16, #0xf]
    //     0x5a9e1c: add             x24, x24, HEAP, lsl #32
    //     0x5a9e20: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d4d8] "recordingOrientation"
    //     0x5a9e24: ldr             x16, [x16, #0x4d8]
    //     0x5a9e28: cmp             w24, w16
    //     0x5a9e2c: b.ne            #0x5a9e54
    //     0x5a9e30: add             w23, w2, #0xa
    //     0x5a9e34: add             x16, x0, w23, sxtw #1
    //     0x5a9e38: ldur            w2, [x16, #0xf]
    //     0x5a9e3c: add             x2, x2, HEAP, lsl #32
    //     0x5a9e40: sub             w0, w1, w2
    //     0x5a9e44: add             x1, fp, w0, sxtw #2
    //     0x5a9e48: ldr             x1, [x1, #8]
    //     0x5a9e4c: mov             x0, x1
    //     0x5a9e50: b               #0x5a9e58
    //     0x5a9e54: mov             x0, NULL
    // 0x5a9e58: cmp             w11, NULL
    // 0x5a9e5c: b.ne            #0x5a9e6c
    // 0x5a9e60: LoadField: r1 = r3->field_7
    //     0x5a9e60: ldur            w1, [x3, #7]
    // 0x5a9e64: DecompressPointer r1
    //     0x5a9e64: add             x1, x1, HEAP, lsl #32
    // 0x5a9e68: b               #0x5a9e70
    // 0x5a9e6c: mov             x1, x11
    // 0x5a9e70: stur            x1, [fp, #-0x88]
    // 0x5a9e74: cmp             w4, NULL
    // 0x5a9e78: b.ne            #0x5a9e88
    // 0x5a9e7c: LoadField: r2 = r3->field_27
    //     0x5a9e7c: ldur            w2, [x3, #0x27]
    // 0x5a9e80: DecompressPointer r2
    //     0x5a9e80: add             x2, x2, HEAP, lsl #32
    // 0x5a9e84: b               #0x5a9e8c
    // 0x5a9e88: mov             x2, x4
    // 0x5a9e8c: stur            x2, [fp, #-0x80]
    // 0x5a9e90: cmp             w13, NULL
    // 0x5a9e94: b.ne            #0x5a9ea4
    // 0x5a9e98: LoadField: r4 = r3->field_f
    //     0x5a9e98: ldur            w4, [x3, #0xf]
    // 0x5a9e9c: DecompressPointer r4
    //     0x5a9e9c: add             x4, x4, HEAP, lsl #32
    // 0x5a9ea0: b               #0x5a9ea8
    // 0x5a9ea4: mov             x4, x13
    // 0x5a9ea8: stur            x4, [fp, #-0x78]
    // 0x5a9eac: cmp             w19, NULL
    // 0x5a9eb0: b.ne            #0x5a9ec0
    // 0x5a9eb4: LoadField: r11 = r3->field_b
    //     0x5a9eb4: ldur            w11, [x3, #0xb]
    // 0x5a9eb8: DecompressPointer r11
    //     0x5a9eb8: add             x11, x11, HEAP, lsl #32
    // 0x5a9ebc: b               #0x5a9ec4
    // 0x5a9ec0: mov             x11, x19
    // 0x5a9ec4: stur            x11, [fp, #-0x70]
    // 0x5a9ec8: cmp             w14, NULL
    // 0x5a9ecc: b.ne            #0x5a9edc
    // 0x5a9ed0: LoadField: r13 = r3->field_13
    //     0x5a9ed0: ldur            w13, [x3, #0x13]
    // 0x5a9ed4: DecompressPointer r13
    //     0x5a9ed4: add             x13, x13, HEAP, lsl #32
    // 0x5a9ed8: b               #0x5a9ee0
    // 0x5a9edc: mov             x13, x14
    // 0x5a9ee0: stur            x13, [fp, #-0x68]
    // 0x5a9ee4: cmp             w8, NULL
    // 0x5a9ee8: b.ne            #0x5a9ef4
    // 0x5a9eec: LoadField: r8 = r3->field_2b
    //     0x5a9eec: ldur            w8, [x3, #0x2b]
    // 0x5a9ef0: DecompressPointer r8
    //     0x5a9ef0: add             x8, x8, HEAP, lsl #32
    // 0x5a9ef4: stur            x8, [fp, #-0x60]
    // 0x5a9ef8: cmp             w6, NULL
    // 0x5a9efc: b.ne            #0x5a9f08
    // 0x5a9f00: LoadField: r6 = r3->field_2f
    //     0x5a9f00: ldur            w6, [x3, #0x2f]
    // 0x5a9f04: DecompressPointer r6
    //     0x5a9f04: add             x6, x6, HEAP, lsl #32
    // 0x5a9f08: stur            x6, [fp, #-0x58]
    // 0x5a9f0c: cmp             w9, NULL
    // 0x5a9f10: b.ne            #0x5a9f1c
    // 0x5a9f14: LoadField: r9 = r3->field_33
    //     0x5a9f14: ldur            w9, [x3, #0x33]
    // 0x5a9f18: DecompressPointer r9
    //     0x5a9f18: add             x9, x9, HEAP, lsl #32
    // 0x5a9f1c: stur            x9, [fp, #-0x50]
    // 0x5a9f20: cmp             w7, NULL
    // 0x5a9f24: b.ne            #0x5a9f30
    // 0x5a9f28: LoadField: r7 = r3->field_37
    //     0x5a9f28: ldur            w7, [x3, #0x37]
    // 0x5a9f2c: DecompressPointer r7
    //     0x5a9f2c: add             x7, x7, HEAP, lsl #32
    // 0x5a9f30: stur            x7, [fp, #-0x48]
    // 0x5a9f34: cmp             w10, NULL
    // 0x5a9f38: b.ne            #0x5a9f44
    // 0x5a9f3c: LoadField: r10 = r3->field_3b
    //     0x5a9f3c: ldur            w10, [x3, #0x3b]
    // 0x5a9f40: DecompressPointer r10
    //     0x5a9f40: add             x10, x10, HEAP, lsl #32
    // 0x5a9f44: stur            x10, [fp, #-0x40]
    // 0x5a9f48: cmp             w5, NULL
    // 0x5a9f4c: b.ne            #0x5a9f58
    // 0x5a9f50: LoadField: r5 = r3->field_3f
    //     0x5a9f50: ldur            w5, [x3, #0x3f]
    // 0x5a9f54: DecompressPointer r5
    //     0x5a9f54: add             x5, x5, HEAP, lsl #32
    // 0x5a9f58: stur            x5, [fp, #-0x38]
    // 0x5a9f5c: cmp             w20, NULL
    // 0x5a9f60: b.ne            #0x5a9f70
    // 0x5a9f64: LoadField: r14 = r3->field_43
    //     0x5a9f64: ldur            w14, [x3, #0x43]
    // 0x5a9f68: DecompressPointer r14
    //     0x5a9f68: add             x14, x14, HEAP, lsl #32
    // 0x5a9f6c: b               #0x5a9f78
    // 0x5a9f70: LoadField: r14 = r20->field_b
    //     0x5a9f70: ldur            w14, [x20, #0xb]
    // 0x5a9f74: DecompressPointer r14
    //     0x5a9f74: add             x14, x14, HEAP, lsl #32
    // 0x5a9f78: stur            x14, [fp, #-0x30]
    // 0x5a9f7c: cmp             w0, NULL
    // 0x5a9f80: b.ne            #0x5a9f90
    // 0x5a9f84: LoadField: r0 = r3->field_47
    //     0x5a9f84: ldur            w0, [x3, #0x47]
    // 0x5a9f88: DecompressPointer r0
    //     0x5a9f88: add             x0, x0, HEAP, lsl #32
    // 0x5a9f8c: b               #0x5a9f9c
    // 0x5a9f90: LoadField: r19 = r0->field_b
    //     0x5a9f90: ldur            w19, [x0, #0xb]
    // 0x5a9f94: DecompressPointer r19
    //     0x5a9f94: add             x19, x19, HEAP, lsl #32
    // 0x5a9f98: mov             x0, x19
    // 0x5a9f9c: stur            x0, [fp, #-0x28]
    // 0x5a9fa0: cmp             w12, NULL
    // 0x5a9fa4: b.ne            #0x5a9fb8
    // 0x5a9fa8: LoadField: r12 = r3->field_1b
    //     0x5a9fa8: ldur            w12, [x3, #0x1b]
    // 0x5a9fac: DecompressPointer r12
    //     0x5a9fac: add             x12, x12, HEAP, lsl #32
    // 0x5a9fb0: mov             x19, x12
    // 0x5a9fb4: b               #0x5a9fbc
    // 0x5a9fb8: mov             x19, x12
    // 0x5a9fbc: ldur            x12, [fp, #-8]
    // 0x5a9fc0: stur            x19, [fp, #-0x20]
    // 0x5a9fc4: cmp             w12, NULL
    // 0x5a9fc8: b.ne            #0x5a9fdc
    // 0x5a9fcc: LoadField: r12 = r3->field_4b
    //     0x5a9fcc: ldur            w12, [x3, #0x4b]
    // 0x5a9fd0: DecompressPointer r12
    //     0x5a9fd0: add             x12, x12, HEAP, lsl #32
    // 0x5a9fd4: mov             x20, x12
    // 0x5a9fd8: b               #0x5a9fe0
    // 0x5a9fdc: mov             x20, x12
    // 0x5a9fe0: ldur            x12, [fp, #-0x10]
    // 0x5a9fe4: stur            x20, [fp, #-0x18]
    // 0x5a9fe8: cmp             w12, NULL
    // 0x5a9fec: b.ne            #0x5aa000
    // 0x5a9ff0: LoadField: r12 = r3->field_1f
    //     0x5a9ff0: ldur            w12, [x3, #0x1f]
    // 0x5a9ff4: DecompressPointer r12
    //     0x5a9ff4: add             x12, x12, HEAP, lsl #32
    // 0x5a9ff8: mov             x3, x12
    // 0x5a9ffc: b               #0x5aa008
    // 0x5aa000: LoadField: r3 = r12->field_b
    //     0x5aa000: ldur            w3, [x12, #0xb]
    // 0x5aa004: DecompressPointer r3
    //     0x5aa004: add             x3, x3, HEAP, lsl #32
    // 0x5aa008: stur            x3, [fp, #-8]
    // 0x5aa00c: r0 = CameraValue()
    //     0x5aa00c: bl              #0x5aa0c8  ; AllocateCameraValueStub -> CameraValue (size=0x50)
    // 0x5aa010: ldur            x1, [fp, #-0x88]
    // 0x5aa014: StoreField: r0->field_7 = r1
    //     0x5aa014: stur            w1, [x0, #7]
    // 0x5aa018: ldur            x1, [fp, #-0x80]
    // 0x5aa01c: StoreField: r0->field_27 = r1
    //     0x5aa01c: stur            w1, [x0, #0x27]
    // 0x5aa020: ldur            x1, [fp, #-0x78]
    // 0x5aa024: StoreField: r0->field_f = r1
    //     0x5aa024: stur            w1, [x0, #0xf]
    // 0x5aa028: ldur            x1, [fp, #-0x70]
    // 0x5aa02c: StoreField: r0->field_b = r1
    //     0x5aa02c: stur            w1, [x0, #0xb]
    // 0x5aa030: ldur            x1, [fp, #-0x68]
    // 0x5aa034: StoreField: r0->field_13 = r1
    //     0x5aa034: stur            w1, [x0, #0x13]
    // 0x5aa038: ldur            x1, [fp, #-0x60]
    // 0x5aa03c: StoreField: r0->field_2b = r1
    //     0x5aa03c: stur            w1, [x0, #0x2b]
    // 0x5aa040: ldur            x1, [fp, #-0x58]
    // 0x5aa044: StoreField: r0->field_2f = r1
    //     0x5aa044: stur            w1, [x0, #0x2f]
    // 0x5aa048: ldur            x1, [fp, #-0x50]
    // 0x5aa04c: StoreField: r0->field_33 = r1
    //     0x5aa04c: stur            w1, [x0, #0x33]
    // 0x5aa050: ldur            x1, [fp, #-0x48]
    // 0x5aa054: StoreField: r0->field_37 = r1
    //     0x5aa054: stur            w1, [x0, #0x37]
    // 0x5aa058: ldur            x1, [fp, #-0x40]
    // 0x5aa05c: StoreField: r0->field_3b = r1
    //     0x5aa05c: stur            w1, [x0, #0x3b]
    // 0x5aa060: ldur            x1, [fp, #-0x38]
    // 0x5aa064: StoreField: r0->field_3f = r1
    //     0x5aa064: stur            w1, [x0, #0x3f]
    // 0x5aa068: ldur            x1, [fp, #-0x18]
    // 0x5aa06c: StoreField: r0->field_4b = r1
    //     0x5aa06c: stur            w1, [x0, #0x4b]
    // 0x5aa070: ldur            x1, [fp, #-0x30]
    // 0x5aa074: StoreField: r0->field_43 = r1
    //     0x5aa074: stur            w1, [x0, #0x43]
    // 0x5aa078: ldur            x1, [fp, #-0x28]
    // 0x5aa07c: StoreField: r0->field_47 = r1
    //     0x5aa07c: stur            w1, [x0, #0x47]
    // 0x5aa080: ldur            x1, [fp, #-0x20]
    // 0x5aa084: StoreField: r0->field_1b = r1
    //     0x5aa084: stur            w1, [x0, #0x1b]
    // 0x5aa088: ldur            x1, [fp, #-8]
    // 0x5aa08c: StoreField: r0->field_1f = r1
    //     0x5aa08c: stur            w1, [x0, #0x1f]
    // 0x5aa090: r1 = false
    //     0x5aa090: add             x1, NULL, #0x30  ; false
    // 0x5aa094: StoreField: r0->field_17 = r1
    //     0x5aa094: stur            w1, [x0, #0x17]
    // 0x5aa098: LeaveFrame
    //     0x5aa098: mov             SP, fp
    //     0x5aa09c: ldp             fp, lr, [SP], #0x10
    // 0x5aa0a0: ret
    //     0x5aa0a0: ret             
  }
  get _ aspectRatio(/* No info */) {
    // ** addr: 0x9b7674, size: 0x38
    // 0x9b7674: EnterFrame
    //     0x9b7674: stp             fp, lr, [SP, #-0x10]!
    //     0x9b7678: mov             fp, SP
    // 0x9b767c: ldr             x0, [fp, #0x10]
    // 0x9b7680: LoadField: r1 = r0->field_27
    //     0x9b7680: ldur            w1, [x0, #0x27]
    // 0x9b7684: DecompressPointer r1
    //     0x9b7684: add             x1, x1, HEAP, lsl #32
    // 0x9b7688: cmp             w1, NULL
    // 0x9b768c: b.eq            #0x9b76a8
    // 0x9b7690: LoadField: d1 = r1->field_7
    //     0x9b7690: ldur            d1, [x1, #7]
    // 0x9b7694: LoadField: d2 = r1->field_f
    //     0x9b7694: ldur            d2, [x1, #0xf]
    // 0x9b7698: fdiv            d0, d1, d2
    // 0x9b769c: LeaveFrame
    //     0x9b769c: mov             SP, fp
    //     0x9b76a0: ldp             fp, lr, [SP], #0x10
    // 0x9b76a4: ret
    //     0x9b76a4: ret             
    // 0x9b76a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9b76a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0xac3f1c, size: 0x1d8
    // 0xac3f1c: EnterFrame
    //     0xac3f1c: stp             fp, lr, [SP, #-0x10]!
    //     0xac3f20: mov             fp, SP
    // 0xac3f24: CheckStackOverflow
    //     0xac3f24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xac3f28: cmp             SP, x16
    //     0xac3f2c: b.ls            #0xac40ec
    // 0xac3f30: r1 = Null
    //     0xac3f30: mov             x1, NULL
    // 0xac3f34: r2 = 68
    //     0xac3f34: mov             x2, #0x44
    // 0xac3f38: r0 = AllocateArray()
    //     0xac3f38: bl              #0xd6987c  ; AllocateArrayStub
    // 0xac3f3c: r17 = "CameraValue"
    //     0xac3f3c: add             x17, PP, #0x54, lsl #12  ; [pp+0x54308] "CameraValue"
    //     0xac3f40: ldr             x17, [x17, #0x308]
    // 0xac3f44: StoreField: r0->field_f = r17
    //     0xac3f44: stur            w17, [x0, #0xf]
    // 0xac3f48: r17 = "(isRecordingVideo: "
    //     0xac3f48: add             x17, PP, #0x54, lsl #12  ; [pp+0x54310] "(isRecordingVideo: "
    //     0xac3f4c: ldr             x17, [x17, #0x310]
    // 0xac3f50: StoreField: r0->field_13 = r17
    //     0xac3f50: stur            w17, [x0, #0x13]
    // 0xac3f54: ldr             x1, [fp, #0x10]
    // 0xac3f58: LoadField: r2 = r1->field_f
    //     0xac3f58: ldur            w2, [x1, #0xf]
    // 0xac3f5c: DecompressPointer r2
    //     0xac3f5c: add             x2, x2, HEAP, lsl #32
    // 0xac3f60: StoreField: r0->field_17 = r2
    //     0xac3f60: stur            w2, [x0, #0x17]
    // 0xac3f64: r17 = ", isInitialized: "
    //     0xac3f64: add             x17, PP, #0x54, lsl #12  ; [pp+0x54318] ", isInitialized: "
    //     0xac3f68: ldr             x17, [x17, #0x318]
    // 0xac3f6c: StoreField: r0->field_1b = r17
    //     0xac3f6c: stur            w17, [x0, #0x1b]
    // 0xac3f70: LoadField: r2 = r1->field_7
    //     0xac3f70: ldur            w2, [x1, #7]
    // 0xac3f74: DecompressPointer r2
    //     0xac3f74: add             x2, x2, HEAP, lsl #32
    // 0xac3f78: StoreField: r0->field_1f = r2
    //     0xac3f78: stur            w2, [x0, #0x1f]
    // 0xac3f7c: r17 = ", errorDescription: "
    //     0xac3f7c: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2cc38] ", errorDescription: "
    //     0xac3f80: ldr             x17, [x17, #0xc38]
    // 0xac3f84: StoreField: r0->field_23 = r17
    //     0xac3f84: stur            w17, [x0, #0x23]
    // 0xac3f88: LoadField: r2 = r1->field_23
    //     0xac3f88: ldur            w2, [x1, #0x23]
    // 0xac3f8c: DecompressPointer r2
    //     0xac3f8c: add             x2, x2, HEAP, lsl #32
    // 0xac3f90: StoreField: r0->field_27 = r2
    //     0xac3f90: stur            w2, [x0, #0x27]
    // 0xac3f94: r17 = ", previewSize: "
    //     0xac3f94: add             x17, PP, #0x54, lsl #12  ; [pp+0x54320] ", previewSize: "
    //     0xac3f98: ldr             x17, [x17, #0x320]
    // 0xac3f9c: StoreField: r0->field_2b = r17
    //     0xac3f9c: stur            w17, [x0, #0x2b]
    // 0xac3fa0: LoadField: r2 = r1->field_27
    //     0xac3fa0: ldur            w2, [x1, #0x27]
    // 0xac3fa4: DecompressPointer r2
    //     0xac3fa4: add             x2, x2, HEAP, lsl #32
    // 0xac3fa8: StoreField: r0->field_2f = r2
    //     0xac3fa8: stur            w2, [x0, #0x2f]
    // 0xac3fac: r17 = ", isStreamingImages: "
    //     0xac3fac: add             x17, PP, #0x54, lsl #12  ; [pp+0x54328] ", isStreamingImages: "
    //     0xac3fb0: ldr             x17, [x17, #0x328]
    // 0xac3fb4: StoreField: r0->field_33 = r17
    //     0xac3fb4: stur            w17, [x0, #0x33]
    // 0xac3fb8: LoadField: r2 = r1->field_13
    //     0xac3fb8: ldur            w2, [x1, #0x13]
    // 0xac3fbc: DecompressPointer r2
    //     0xac3fbc: add             x2, x2, HEAP, lsl #32
    // 0xac3fc0: StoreField: r0->field_37 = r2
    //     0xac3fc0: stur            w2, [x0, #0x37]
    // 0xac3fc4: r17 = ", flashMode: "
    //     0xac3fc4: add             x17, PP, #0x54, lsl #12  ; [pp+0x54330] ", flashMode: "
    //     0xac3fc8: ldr             x17, [x17, #0x330]
    // 0xac3fcc: StoreField: r0->field_3b = r17
    //     0xac3fcc: stur            w17, [x0, #0x3b]
    // 0xac3fd0: LoadField: r2 = r1->field_2b
    //     0xac3fd0: ldur            w2, [x1, #0x2b]
    // 0xac3fd4: DecompressPointer r2
    //     0xac3fd4: add             x2, x2, HEAP, lsl #32
    // 0xac3fd8: StoreField: r0->field_3f = r2
    //     0xac3fd8: stur            w2, [x0, #0x3f]
    // 0xac3fdc: r17 = ", exposureMode: "
    //     0xac3fdc: add             x17, PP, #0x54, lsl #12  ; [pp+0x54338] ", exposureMode: "
    //     0xac3fe0: ldr             x17, [x17, #0x338]
    // 0xac3fe4: StoreField: r0->field_43 = r17
    //     0xac3fe4: stur            w17, [x0, #0x43]
    // 0xac3fe8: LoadField: r2 = r1->field_2f
    //     0xac3fe8: ldur            w2, [x1, #0x2f]
    // 0xac3fec: DecompressPointer r2
    //     0xac3fec: add             x2, x2, HEAP, lsl #32
    // 0xac3ff0: StoreField: r0->field_47 = r2
    //     0xac3ff0: stur            w2, [x0, #0x47]
    // 0xac3ff4: r17 = ", focusMode: "
    //     0xac3ff4: add             x17, PP, #0x54, lsl #12  ; [pp+0x54340] ", focusMode: "
    //     0xac3ff8: ldr             x17, [x17, #0x340]
    // 0xac3ffc: StoreField: r0->field_4b = r17
    //     0xac3ffc: stur            w17, [x0, #0x4b]
    // 0xac4000: LoadField: r2 = r1->field_33
    //     0xac4000: ldur            w2, [x1, #0x33]
    // 0xac4004: DecompressPointer r2
    //     0xac4004: add             x2, x2, HEAP, lsl #32
    // 0xac4008: StoreField: r0->field_4f = r2
    //     0xac4008: stur            w2, [x0, #0x4f]
    // 0xac400c: r17 = ", exposurePointSupported: "
    //     0xac400c: add             x17, PP, #0x54, lsl #12  ; [pp+0x54348] ", exposurePointSupported: "
    //     0xac4010: ldr             x17, [x17, #0x348]
    // 0xac4014: StoreField: r0->field_53 = r17
    //     0xac4014: stur            w17, [x0, #0x53]
    // 0xac4018: LoadField: r2 = r1->field_37
    //     0xac4018: ldur            w2, [x1, #0x37]
    // 0xac401c: DecompressPointer r2
    //     0xac401c: add             x2, x2, HEAP, lsl #32
    // 0xac4020: StoreField: r0->field_57 = r2
    //     0xac4020: stur            w2, [x0, #0x57]
    // 0xac4024: r17 = ", focusPointSupported: "
    //     0xac4024: add             x17, PP, #0x54, lsl #12  ; [pp+0x54350] ", focusPointSupported: "
    //     0xac4028: ldr             x17, [x17, #0x350]
    // 0xac402c: StoreField: r0->field_5b = r17
    //     0xac402c: stur            w17, [x0, #0x5b]
    // 0xac4030: LoadField: r2 = r1->field_3b
    //     0xac4030: ldur            w2, [x1, #0x3b]
    // 0xac4034: DecompressPointer r2
    //     0xac4034: add             x2, x2, HEAP, lsl #32
    // 0xac4038: StoreField: r0->field_5f = r2
    //     0xac4038: stur            w2, [x0, #0x5f]
    // 0xac403c: r17 = ", deviceOrientation: "
    //     0xac403c: add             x17, PP, #0x54, lsl #12  ; [pp+0x54358] ", deviceOrientation: "
    //     0xac4040: ldr             x17, [x17, #0x358]
    // 0xac4044: StoreField: r0->field_63 = r17
    //     0xac4044: stur            w17, [x0, #0x63]
    // 0xac4048: LoadField: r2 = r1->field_3f
    //     0xac4048: ldur            w2, [x1, #0x3f]
    // 0xac404c: DecompressPointer r2
    //     0xac404c: add             x2, x2, HEAP, lsl #32
    // 0xac4050: StoreField: r0->field_67 = r2
    //     0xac4050: stur            w2, [x0, #0x67]
    // 0xac4054: r17 = ", lockedCaptureOrientation: "
    //     0xac4054: add             x17, PP, #0x54, lsl #12  ; [pp+0x54360] ", lockedCaptureOrientation: "
    //     0xac4058: ldr             x17, [x17, #0x360]
    // 0xac405c: StoreField: r0->field_6b = r17
    //     0xac405c: stur            w17, [x0, #0x6b]
    // 0xac4060: LoadField: r2 = r1->field_43
    //     0xac4060: ldur            w2, [x1, #0x43]
    // 0xac4064: DecompressPointer r2
    //     0xac4064: add             x2, x2, HEAP, lsl #32
    // 0xac4068: StoreField: r0->field_6f = r2
    //     0xac4068: stur            w2, [x0, #0x6f]
    // 0xac406c: r17 = ", recordingOrientation: "
    //     0xac406c: add             x17, PP, #0x54, lsl #12  ; [pp+0x54368] ", recordingOrientation: "
    //     0xac4070: ldr             x17, [x17, #0x368]
    // 0xac4074: StoreField: r0->field_73 = r17
    //     0xac4074: stur            w17, [x0, #0x73]
    // 0xac4078: LoadField: r2 = r1->field_47
    //     0xac4078: ldur            w2, [x1, #0x47]
    // 0xac407c: DecompressPointer r2
    //     0xac407c: add             x2, x2, HEAP, lsl #32
    // 0xac4080: StoreField: r0->field_77 = r2
    //     0xac4080: stur            w2, [x0, #0x77]
    // 0xac4084: r17 = ", isPreviewPaused: "
    //     0xac4084: add             x17, PP, #0x54, lsl #12  ; [pp+0x54370] ", isPreviewPaused: "
    //     0xac4088: ldr             x17, [x17, #0x370]
    // 0xac408c: StoreField: r0->field_7b = r17
    //     0xac408c: stur            w17, [x0, #0x7b]
    // 0xac4090: LoadField: r2 = r1->field_1b
    //     0xac4090: ldur            w2, [x1, #0x1b]
    // 0xac4094: DecompressPointer r2
    //     0xac4094: add             x2, x2, HEAP, lsl #32
    // 0xac4098: StoreField: r0->field_7f = r2
    //     0xac4098: stur            w2, [x0, #0x7f]
    // 0xac409c: r17 = ", previewPausedOrientation: "
    //     0xac409c: add             x17, PP, #0x54, lsl #12  ; [pp+0x54378] ", previewPausedOrientation: "
    //     0xac40a0: ldr             x17, [x17, #0x378]
    // 0xac40a4: StoreField: r0->field_83 = r17
    //     0xac40a4: stur            w17, [x0, #0x83]
    // 0xac40a8: LoadField: r2 = r1->field_1f
    //     0xac40a8: ldur            w2, [x1, #0x1f]
    // 0xac40ac: DecompressPointer r2
    //     0xac40ac: add             x2, x2, HEAP, lsl #32
    // 0xac40b0: StoreField: r0->field_87 = r2
    //     0xac40b0: stur            w2, [x0, #0x87]
    // 0xac40b4: r17 = ", description: "
    //     0xac40b4: add             x17, PP, #0x54, lsl #12  ; [pp+0x54380] ", description: "
    //     0xac40b8: ldr             x17, [x17, #0x380]
    // 0xac40bc: StoreField: r0->field_8b = r17
    //     0xac40bc: stur            w17, [x0, #0x8b]
    // 0xac40c0: LoadField: r2 = r1->field_4b
    //     0xac40c0: ldur            w2, [x1, #0x4b]
    // 0xac40c4: DecompressPointer r2
    //     0xac40c4: add             x2, x2, HEAP, lsl #32
    // 0xac40c8: StoreField: r0->field_8f = r2
    //     0xac40c8: stur            w2, [x0, #0x8f]
    // 0xac40cc: r17 = ")"
    //     0xac40cc: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xac40d0: StoreField: r0->field_93 = r17
    //     0xac40d0: stur            w17, [x0, #0x93]
    // 0xac40d4: SaveReg r0
    //     0xac40d4: str             x0, [SP, #-8]!
    // 0xac40d8: r0 = _interpolate()
    //     0xac40d8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xac40dc: add             SP, SP, #8
    // 0xac40e0: LeaveFrame
    //     0xac40e0: mov             SP, fp
    //     0xac40e4: ldp             fp, lr, [SP], #0x10
    // 0xac40e8: ret
    //     0xac40e8: ret             
    // 0xac40ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xac40ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xac40f0: b               #0xac3f30
  }
}

// class id: 6115, size: 0x10, field offset: 0xc
//   const constructor, 
class Optional<X0> extends IterableBase<X0> {

  get _ iterator(/* No info */) {
    // ** addr: 0x6fba18, size: 0xa8
    // 0x6fba18: EnterFrame
    //     0x6fba18: stp             fp, lr, [SP, #-0x10]!
    //     0x6fba1c: mov             fp, SP
    // 0x6fba20: AllocStack(0x18)
    //     0x6fba20: sub             SP, SP, #0x18
    // 0x6fba24: ldr             x0, [fp, #0x10]
    // 0x6fba28: LoadField: r3 = r0->field_b
    //     0x6fba28: ldur            w3, [x0, #0xb]
    // 0x6fba2c: DecompressPointer r3
    //     0x6fba2c: add             x3, x3, HEAP, lsl #32
    // 0x6fba30: stur            x3, [fp, #-0x10]
    // 0x6fba34: cmp             w3, NULL
    // 0x6fba38: b.eq            #0x6fbaac
    // 0x6fba3c: r4 = 2
    //     0x6fba3c: mov             x4, #2
    // 0x6fba40: LoadField: r5 = r0->field_7
    //     0x6fba40: ldur            w5, [x0, #7]
    // 0x6fba44: DecompressPointer r5
    //     0x6fba44: add             x5, x5, HEAP, lsl #32
    // 0x6fba48: mov             x2, x4
    // 0x6fba4c: stur            x5, [fp, #-8]
    // 0x6fba50: r1 = Null
    //     0x6fba50: mov             x1, NULL
    // 0x6fba54: r0 = AllocateArray()
    //     0x6fba54: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6fba58: mov             x2, x0
    // 0x6fba5c: ldur            x0, [fp, #-0x10]
    // 0x6fba60: stur            x2, [fp, #-0x18]
    // 0x6fba64: StoreField: r2->field_f = r0
    //     0x6fba64: stur            w0, [x2, #0xf]
    // 0x6fba68: ldur            x1, [fp, #-8]
    // 0x6fba6c: r0 = AllocateGrowableArray()
    //     0x6fba6c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x6fba70: mov             x2, x0
    // 0x6fba74: ldur            x0, [fp, #-0x18]
    // 0x6fba78: stur            x2, [fp, #-0x10]
    // 0x6fba7c: StoreField: r2->field_f = r0
    //     0x6fba7c: stur            w0, [x2, #0xf]
    // 0x6fba80: r0 = 2
    //     0x6fba80: mov             x0, #2
    // 0x6fba84: StoreField: r2->field_b = r0
    //     0x6fba84: stur            w0, [x2, #0xb]
    // 0x6fba88: ldur            x1, [fp, #-8]
    // 0x6fba8c: r0 = ListIterator()
    //     0x6fba8c: bl              #0x50a2a0  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x6fba90: ldur            x1, [fp, #-0x10]
    // 0x6fba94: StoreField: r0->field_b = r1
    //     0x6fba94: stur            w1, [x0, #0xb]
    // 0x6fba98: r1 = 1
    //     0x6fba98: mov             x1, #1
    // 0x6fba9c: StoreField: r0->field_f = r1
    //     0x6fba9c: stur            x1, [x0, #0xf]
    // 0x6fbaa0: r1 = 0
    //     0x6fbaa0: mov             x1, #0
    // 0x6fbaa4: StoreField: r0->field_17 = r1
    //     0x6fbaa4: stur            x1, [x0, #0x17]
    // 0x6fbaa8: b               #0x6fbab4
    // 0x6fbaac: r0 = Instance_EmptyIterator
    //     0x6fbaac: add             x0, PP, #9, lsl #12  ; [pp+0x9160] Obj!EmptyIterator<Never>@b5f5e1
    //     0x6fbab0: ldr             x0, [x0, #0x160]
    // 0x6fbab4: LeaveFrame
    //     0x6fbab4: mov             SP, fp
    //     0x6fbab8: ldp             fp, lr, [SP], #0x10
    // 0x6fbabc: ret
    //     0x6fbabc: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xab7cd8, size: 0x88
    // 0xab7cd8: EnterFrame
    //     0xab7cd8: stp             fp, lr, [SP, #-0x10]!
    //     0xab7cdc: mov             fp, SP
    // 0xab7ce0: AllocStack(0x8)
    //     0xab7ce0: sub             SP, SP, #8
    // 0xab7ce4: CheckStackOverflow
    //     0xab7ce4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xab7ce8: cmp             SP, x16
    //     0xab7cec: b.ls            #0xab7d58
    // 0xab7cf0: ldr             x0, [fp, #0x10]
    // 0xab7cf4: LoadField: r3 = r0->field_b
    //     0xab7cf4: ldur            w3, [x0, #0xb]
    // 0xab7cf8: DecompressPointer r3
    //     0xab7cf8: add             x3, x3, HEAP, lsl #32
    // 0xab7cfc: stur            x3, [fp, #-8]
    // 0xab7d00: cmp             w3, NULL
    // 0xab7d04: b.ne            #0xab7d14
    // 0xab7d08: r0 = "Optional { absent }"
    //     0xab7d08: add             x0, PP, #0x54, lsl #12  ; [pp+0x54390] "Optional { absent }"
    //     0xab7d0c: ldr             x0, [x0, #0x390]
    // 0xab7d10: b               #0xab7d4c
    // 0xab7d14: r1 = Null
    //     0xab7d14: mov             x1, NULL
    // 0xab7d18: r2 = 6
    //     0xab7d18: mov             x2, #6
    // 0xab7d1c: r0 = AllocateArray()
    //     0xab7d1c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xab7d20: r17 = "Optional { value: "
    //     0xab7d20: add             x17, PP, #0x54, lsl #12  ; [pp+0x54398] "Optional { value: "
    //     0xab7d24: ldr             x17, [x17, #0x398]
    // 0xab7d28: StoreField: r0->field_f = r17
    //     0xab7d28: stur            w17, [x0, #0xf]
    // 0xab7d2c: ldur            x1, [fp, #-8]
    // 0xab7d30: StoreField: r0->field_13 = r1
    //     0xab7d30: stur            w1, [x0, #0x13]
    // 0xab7d34: r17 = " }"
    //     0xab7d34: add             x17, PP, #0x23, lsl #12  ; [pp+0x23090] " }"
    //     0xab7d38: ldr             x17, [x17, #0x90]
    // 0xab7d3c: StoreField: r0->field_17 = r17
    //     0xab7d3c: stur            w17, [x0, #0x17]
    // 0xab7d40: SaveReg r0
    //     0xab7d40: str             x0, [SP, #-8]!
    // 0xab7d44: r0 = _interpolate()
    //     0xab7d44: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xab7d48: add             SP, SP, #8
    // 0xab7d4c: LeaveFrame
    //     0xab7d4c: mov             SP, fp
    //     0xab7d50: ldp             fp, lr, [SP], #0x10
    // 0xab7d54: ret
    //     0xab7d54: ret             
    // 0xab7d58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xab7d58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xab7d5c: b               #0xab7cf0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc5b664, size: 0xe0
    // 0xc5b664: EnterFrame
    //     0xc5b664: stp             fp, lr, [SP, #-0x10]!
    //     0xc5b668: mov             fp, SP
    // 0xc5b66c: ldr             x3, [fp, #0x10]
    // 0xc5b670: cmp             w3, NULL
    // 0xc5b674: b.ne            #0xc5b688
    // 0xc5b678: r0 = false
    //     0xc5b678: add             x0, NULL, #0x30  ; false
    // 0xc5b67c: LeaveFrame
    //     0xc5b67c: mov             SP, fp
    //     0xc5b680: ldp             fp, lr, [SP], #0x10
    // 0xc5b684: ret
    //     0xc5b684: ret             
    // 0xc5b688: ldr             x4, [fp, #0x18]
    // 0xc5b68c: LoadField: r2 = r4->field_7
    //     0xc5b68c: ldur            w2, [x4, #7]
    // 0xc5b690: DecompressPointer r2
    //     0xc5b690: add             x2, x2, HEAP, lsl #32
    // 0xc5b694: mov             x0, x3
    // 0xc5b698: r1 = Null
    //     0xc5b698: mov             x1, NULL
    // 0xc5b69c: cmp             w0, NULL
    // 0xc5b6a0: b.eq            #0xc5b6f4
    // 0xc5b6a4: branchIfSmi(r0, 0xc5b6f4)
    //     0xc5b6a4: tbz             w0, #0, #0xc5b6f4
    // 0xc5b6a8: r8 = Optional<X0>
    //     0xc5b6a8: add             x8, PP, #0x54, lsl #12  ; [pp+0x543a0] Type: Optional<X0>
    //     0xc5b6ac: ldr             x8, [x8, #0x3a0]
    // 0xc5b6b0: r3 = SubtypeTestCache
    //     0xc5b6b0: add             x3, PP, #0x54, lsl #12  ; [pp+0x543a8] SubtypeTestCache
    //     0xc5b6b4: ldr             x3, [x3, #0x3a8]
    // 0xc5b6b8: r24 = Subtype5TestCacheStub
    //     0xc5b6b8: ldr             x24, [PP, #0xc78]  ; [pp+0xc78] Stub: Subtype5TestCache (0x4ae1bc)
    // 0xc5b6bc: LoadField: r30 = r24->field_7
    //     0xc5b6bc: ldur            lr, [x24, #7]
    // 0xc5b6c0: blr             lr
    // 0xc5b6c4: cmp             w7, NULL
    // 0xc5b6c8: b.eq            #0xc5b6d4
    // 0xc5b6cc: tbnz            w7, #4, #0xc5b6f4
    // 0xc5b6d0: b               #0xc5b6fc
    // 0xc5b6d4: r8 = Optional<X0>
    //     0xc5b6d4: add             x8, PP, #0x54, lsl #12  ; [pp+0x543b0] Type: Optional<X0>
    //     0xc5b6d8: ldr             x8, [x8, #0x3b0]
    // 0xc5b6dc: r3 = SubtypeTestCache
    //     0xc5b6dc: add             x3, PP, #0x54, lsl #12  ; [pp+0x543b8] SubtypeTestCache
    //     0xc5b6e0: ldr             x3, [x3, #0x3b8]
    // 0xc5b6e4: r24 = InstanceOfStub
    //     0xc5b6e4: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc5b6e8: LoadField: r30 = r24->field_7
    //     0xc5b6e8: ldur            lr, [x24, #7]
    // 0xc5b6ec: blr             lr
    // 0xc5b6f0: b               #0xc5b700
    // 0xc5b6f4: r0 = false
    //     0xc5b6f4: add             x0, NULL, #0x30  ; false
    // 0xc5b6f8: b               #0xc5b700
    // 0xc5b6fc: r0 = true
    //     0xc5b6fc: add             x0, NULL, #0x20  ; true
    // 0xc5b700: tbnz            w0, #4, #0xc5b734
    // 0xc5b704: ldr             x2, [fp, #0x18]
    // 0xc5b708: ldr             x1, [fp, #0x10]
    // 0xc5b70c: LoadField: r3 = r1->field_b
    //     0xc5b70c: ldur            w3, [x1, #0xb]
    // 0xc5b710: DecompressPointer r3
    //     0xc5b710: add             x3, x3, HEAP, lsl #32
    // 0xc5b714: LoadField: r1 = r2->field_b
    //     0xc5b714: ldur            w1, [x2, #0xb]
    // 0xc5b718: DecompressPointer r1
    //     0xc5b718: add             x1, x1, HEAP, lsl #32
    // 0xc5b71c: cmp             w3, w1
    // 0xc5b720: r16 = true
    //     0xc5b720: add             x16, NULL, #0x20  ; true
    // 0xc5b724: r17 = false
    //     0xc5b724: add             x17, NULL, #0x30  ; false
    // 0xc5b728: csel            x2, x16, x17, eq
    // 0xc5b72c: mov             x0, x2
    // 0xc5b730: b               #0xc5b738
    // 0xc5b734: r0 = false
    //     0xc5b734: add             x0, NULL, #0x30  ; false
    // 0xc5b738: LeaveFrame
    //     0xc5b738: mov             SP, fp
    //     0xc5b73c: ldp             fp, lr, [SP], #0x10
    // 0xc5b740: ret
    //     0xc5b740: ret             
  }
}

// lib: , url: package:camera/src/camera_preview.dart

// class id: 1048703, size: 0x8
class :: {
}

// class id: 3885, size: 0x14, field offset: 0xc
//   const constructor, 
class CameraPreview extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1b9f8, size: 0xbc
    // 0xb1b9f8: EnterFrame
    //     0xb1b9f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb1b9fc: mov             fp, SP
    // 0xb1ba00: AllocStack(0x18)
    //     0xb1ba00: sub             SP, SP, #0x18
    // 0xb1ba04: CheckStackOverflow
    //     0xb1ba04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1ba08: cmp             SP, x16
    //     0xb1ba0c: b.ls            #0xb1baac
    // 0xb1ba10: r1 = 1
    //     0xb1ba10: mov             x1, #1
    // 0xb1ba14: r0 = AllocateContext()
    //     0xb1ba14: bl              #0xd68aa4  ; AllocateContextStub
    // 0xb1ba18: mov             x2, x0
    // 0xb1ba1c: ldr             x0, [fp, #0x18]
    // 0xb1ba20: stur            x2, [fp, #-0x10]
    // 0xb1ba24: StoreField: r2->field_f = r0
    //     0xb1ba24: stur            w0, [x2, #0xf]
    // 0xb1ba28: LoadField: r3 = r0->field_b
    //     0xb1ba28: ldur            w3, [x0, #0xb]
    // 0xb1ba2c: DecompressPointer r3
    //     0xb1ba2c: add             x3, x3, HEAP, lsl #32
    // 0xb1ba30: stur            x3, [fp, #-8]
    // 0xb1ba34: LoadField: r0 = r3->field_27
    //     0xb1ba34: ldur            w0, [x3, #0x27]
    // 0xb1ba38: DecompressPointer r0
    //     0xb1ba38: add             x0, x0, HEAP, lsl #32
    // 0xb1ba3c: LoadField: r1 = r0->field_7
    //     0xb1ba3c: ldur            w1, [x0, #7]
    // 0xb1ba40: DecompressPointer r1
    //     0xb1ba40: add             x1, x1, HEAP, lsl #32
    // 0xb1ba44: tbnz            w1, #4, #0xb1ba84
    // 0xb1ba48: r1 = <CameraValue>
    //     0xb1ba48: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d2c8] TypeArguments: <CameraValue>
    //     0xb1ba4c: ldr             x1, [x1, #0x2c8]
    // 0xb1ba50: r0 = ValueListenableBuilder()
    //     0xb1ba50: bl              #0x8b8574  ; AllocateValueListenableBuilderStub -> ValueListenableBuilder<X0> (size=0x1c)
    // 0xb1ba54: mov             x3, x0
    // 0xb1ba58: ldur            x0, [fp, #-8]
    // 0xb1ba5c: stur            x3, [fp, #-0x18]
    // 0xb1ba60: StoreField: r3->field_f = r0
    //     0xb1ba60: stur            w0, [x3, #0xf]
    // 0xb1ba64: ldur            x2, [fp, #-0x10]
    // 0xb1ba68: r1 = Function '<anonymous closure>':.
    //     0xb1ba68: add             x1, PP, #0x54, lsl #12  ; [pp+0x542f0] AnonymousClosure: (0xb1bab4), in [package:camera/src/camera_preview.dart] CameraPreview::build (0xb1b9f8)
    //     0xb1ba6c: ldr             x1, [x1, #0x2f0]
    // 0xb1ba70: r0 = AllocateClosure()
    //     0xb1ba70: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb1ba74: mov             x1, x0
    // 0xb1ba78: ldur            x0, [fp, #-0x18]
    // 0xb1ba7c: StoreField: r0->field_13 = r1
    //     0xb1ba7c: stur            w1, [x0, #0x13]
    // 0xb1ba80: b               #0xb1baa0
    // 0xb1ba84: r0 = Container()
    //     0xb1ba84: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xb1ba88: stur            x0, [fp, #-8]
    // 0xb1ba8c: SaveReg r0
    //     0xb1ba8c: str             x0, [SP, #-8]!
    // 0xb1ba90: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xb1ba90: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xb1ba94: r0 = Container()
    //     0xb1ba94: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xb1ba98: add             SP, SP, #8
    // 0xb1ba9c: ldur            x0, [fp, #-8]
    // 0xb1baa0: LeaveFrame
    //     0xb1baa0: mov             SP, fp
    //     0xb1baa4: ldp             fp, lr, [SP], #0x10
    // 0xb1baa8: ret
    //     0xb1baa8: ret             
    // 0xb1baac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1baac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1bab0: b               #0xb1ba10
  }
  [closure] AspectRatio <anonymous closure>(dynamic, BuildContext, Object?, Widget?) {
    // ** addr: 0xb1bab4, size: 0x1ec
    // 0xb1bab4: EnterFrame
    //     0xb1bab4: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bab8: mov             fp, SP
    // 0xb1babc: AllocStack(0x20)
    //     0xb1babc: sub             SP, SP, #0x20
    // 0xb1bac0: SetupParameters()
    //     0xb1bac0: ldr             x0, [fp, #0x28]
    //     0xb1bac4: ldur            w1, [x0, #0x17]
    //     0xb1bac8: add             x1, x1, HEAP, lsl #32
    //     0xb1bacc: stur            x1, [fp, #-8]
    // 0xb1bad0: CheckStackOverflow
    //     0xb1bad0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1bad4: cmp             SP, x16
    //     0xb1bad8: b.ls            #0xb1bc90
    // 0xb1badc: LoadField: r0 = r1->field_f
    //     0xb1badc: ldur            w0, [x1, #0xf]
    // 0xb1bae0: DecompressPointer r0
    //     0xb1bae0: add             x0, x0, HEAP, lsl #32
    // 0xb1bae4: SaveReg r0
    //     0xb1bae4: str             x0, [SP, #-8]!
    // 0xb1bae8: r0 = _isLandscape()
    //     0xb1bae8: bl              #0xb1c018  ; [package:camera/src/camera_preview.dart] CameraPreview::_isLandscape
    // 0xb1baec: add             SP, SP, #8
    // 0xb1baf0: tbnz            w0, #4, #0xb1bb34
    // 0xb1baf4: ldur            x0, [fp, #-8]
    // 0xb1baf8: LoadField: r1 = r0->field_f
    //     0xb1baf8: ldur            w1, [x0, #0xf]
    // 0xb1bafc: DecompressPointer r1
    //     0xb1bafc: add             x1, x1, HEAP, lsl #32
    // 0xb1bb00: LoadField: r2 = r1->field_b
    //     0xb1bb00: ldur            w2, [x1, #0xb]
    // 0xb1bb04: DecompressPointer r2
    //     0xb1bb04: add             x2, x2, HEAP, lsl #32
    // 0xb1bb08: LoadField: r1 = r2->field_27
    //     0xb1bb08: ldur            w1, [x2, #0x27]
    // 0xb1bb0c: DecompressPointer r1
    //     0xb1bb0c: add             x1, x1, HEAP, lsl #32
    // 0xb1bb10: LoadField: r3 = r1->field_27
    //     0xb1bb10: ldur            w3, [x1, #0x27]
    // 0xb1bb14: DecompressPointer r3
    //     0xb1bb14: add             x3, x3, HEAP, lsl #32
    // 0xb1bb18: cmp             w3, NULL
    // 0xb1bb1c: b.eq            #0xb1bc98
    // 0xb1bb20: LoadField: d0 = r3->field_7
    //     0xb1bb20: ldur            d0, [x3, #7]
    // 0xb1bb24: LoadField: d1 = r3->field_f
    //     0xb1bb24: ldur            d1, [x3, #0xf]
    // 0xb1bb28: fdiv            d2, d0, d1
    // 0xb1bb2c: mov             v0.16b, v2.16b
    // 0xb1bb30: b               #0xb1bb78
    // 0xb1bb34: ldur            x0, [fp, #-8]
    // 0xb1bb38: d0 = 1.000000
    //     0xb1bb38: fmov            d0, #1.00000000
    // 0xb1bb3c: LoadField: r1 = r0->field_f
    //     0xb1bb3c: ldur            w1, [x0, #0xf]
    // 0xb1bb40: DecompressPointer r1
    //     0xb1bb40: add             x1, x1, HEAP, lsl #32
    // 0xb1bb44: LoadField: r2 = r1->field_b
    //     0xb1bb44: ldur            w2, [x1, #0xb]
    // 0xb1bb48: DecompressPointer r2
    //     0xb1bb48: add             x2, x2, HEAP, lsl #32
    // 0xb1bb4c: LoadField: r1 = r2->field_27
    //     0xb1bb4c: ldur            w1, [x2, #0x27]
    // 0xb1bb50: DecompressPointer r1
    //     0xb1bb50: add             x1, x1, HEAP, lsl #32
    // 0xb1bb54: LoadField: r3 = r1->field_27
    //     0xb1bb54: ldur            w3, [x1, #0x27]
    // 0xb1bb58: DecompressPointer r3
    //     0xb1bb58: add             x3, x3, HEAP, lsl #32
    // 0xb1bb5c: cmp             w3, NULL
    // 0xb1bb60: b.eq            #0xb1bc9c
    // 0xb1bb64: LoadField: d1 = r3->field_7
    //     0xb1bb64: ldur            d1, [x3, #7]
    // 0xb1bb68: LoadField: d2 = r3->field_f
    //     0xb1bb68: ldur            d2, [x3, #0xf]
    // 0xb1bb6c: fdiv            d3, d1, d2
    // 0xb1bb70: fdiv            d1, d0, d3
    // 0xb1bb74: mov             v0.16b, v1.16b
    // 0xb1bb78: ldr             x1, [fp, #0x10]
    // 0xb1bb7c: stur            d0, [fp, #-0x20]
    // 0xb1bb80: SaveReg r2
    //     0xb1bb80: str             x2, [SP, #-8]!
    // 0xb1bb84: r0 = buildPreview()
    //     0xb1bb84: bl              #0xb1be88  ; [package:camera/src/camera_controller.dart] CameraController::buildPreview
    // 0xb1bb88: add             SP, SP, #8
    // 0xb1bb8c: mov             x1, x0
    // 0xb1bb90: ldur            x0, [fp, #-8]
    // 0xb1bb94: LoadField: r2 = r0->field_f
    //     0xb1bb94: ldur            w2, [x0, #0xf]
    // 0xb1bb98: DecompressPointer r2
    //     0xb1bb98: add             x2, x2, HEAP, lsl #32
    // 0xb1bb9c: stp             x1, x2, [SP, #-0x10]!
    // 0xb1bba0: r0 = _wrapInRotatedBox()
    //     0xb1bba0: bl              #0xb1bca0  ; [package:camera/src/camera_preview.dart] CameraPreview::_wrapInRotatedBox
    // 0xb1bba4: add             SP, SP, #0x10
    // 0xb1bba8: mov             x1, x0
    // 0xb1bbac: ldr             x0, [fp, #0x10]
    // 0xb1bbb0: stur            x1, [fp, #-8]
    // 0xb1bbb4: cmp             w0, NULL
    // 0xb1bbb8: b.ne            #0xb1bbdc
    // 0xb1bbbc: r0 = Container()
    //     0xb1bbbc: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xb1bbc0: stur            x0, [fp, #-0x10]
    // 0xb1bbc4: SaveReg r0
    //     0xb1bbc4: str             x0, [SP, #-8]!
    // 0xb1bbc8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xb1bbc8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xb1bbcc: r0 = Container()
    //     0xb1bbcc: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xb1bbd0: add             SP, SP, #8
    // 0xb1bbd4: ldur            x4, [fp, #-0x10]
    // 0xb1bbd8: b               #0xb1bbe0
    // 0xb1bbdc: mov             x4, x0
    // 0xb1bbe0: ldur            d0, [fp, #-0x20]
    // 0xb1bbe4: ldur            x0, [fp, #-8]
    // 0xb1bbe8: r3 = 4
    //     0xb1bbe8: mov             x3, #4
    // 0xb1bbec: mov             x2, x3
    // 0xb1bbf0: stur            x4, [fp, #-0x10]
    // 0xb1bbf4: r1 = Null
    //     0xb1bbf4: mov             x1, NULL
    // 0xb1bbf8: r0 = AllocateArray()
    //     0xb1bbf8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1bbfc: mov             x2, x0
    // 0xb1bc00: ldur            x0, [fp, #-8]
    // 0xb1bc04: stur            x2, [fp, #-0x18]
    // 0xb1bc08: StoreField: r2->field_f = r0
    //     0xb1bc08: stur            w0, [x2, #0xf]
    // 0xb1bc0c: ldur            x0, [fp, #-0x10]
    // 0xb1bc10: StoreField: r2->field_13 = r0
    //     0xb1bc10: stur            w0, [x2, #0x13]
    // 0xb1bc14: r1 = <Widget>
    //     0xb1bc14: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0xb1bc18: ldr             x1, [x1, #0xea8]
    // 0xb1bc1c: r0 = AllocateGrowableArray()
    //     0xb1bc1c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xb1bc20: mov             x1, x0
    // 0xb1bc24: ldur            x0, [fp, #-0x18]
    // 0xb1bc28: stur            x1, [fp, #-8]
    // 0xb1bc2c: StoreField: r1->field_f = r0
    //     0xb1bc2c: stur            w0, [x1, #0xf]
    // 0xb1bc30: r0 = 4
    //     0xb1bc30: mov             x0, #4
    // 0xb1bc34: StoreField: r1->field_b = r0
    //     0xb1bc34: stur            w0, [x1, #0xb]
    // 0xb1bc38: r0 = Stack()
    //     0xb1bc38: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0xb1bc3c: mov             x1, x0
    // 0xb1bc40: r0 = Instance_AlignmentDirectional
    //     0xb1bc40: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0xb1bc44: ldr             x0, [x0, #0xf70]
    // 0xb1bc48: stur            x1, [fp, #-0x10]
    // 0xb1bc4c: StoreField: r1->field_f = r0
    //     0xb1bc4c: stur            w0, [x1, #0xf]
    // 0xb1bc50: r0 = Instance_StackFit
    //     0xb1bc50: add             x0, PP, #0x30, lsl #12  ; [pp+0x30a28] Obj!StackFit@b647b1
    //     0xb1bc54: ldr             x0, [x0, #0xa28]
    // 0xb1bc58: StoreField: r1->field_17 = r0
    //     0xb1bc58: stur            w0, [x1, #0x17]
    // 0xb1bc5c: r0 = Instance_Clip
    //     0xb1bc5c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0xb1bc60: ldr             x0, [x0, #0x678]
    // 0xb1bc64: StoreField: r1->field_1b = r0
    //     0xb1bc64: stur            w0, [x1, #0x1b]
    // 0xb1bc68: ldur            x0, [fp, #-8]
    // 0xb1bc6c: StoreField: r1->field_b = r0
    //     0xb1bc6c: stur            w0, [x1, #0xb]
    // 0xb1bc70: r0 = AspectRatio()
    //     0xb1bc70: bl              #0x88cc5c  ; AllocateAspectRatioStub -> AspectRatio (size=0x18)
    // 0xb1bc74: ldur            d0, [fp, #-0x20]
    // 0xb1bc78: StoreField: r0->field_f = d0
    //     0xb1bc78: stur            d0, [x0, #0xf]
    // 0xb1bc7c: ldur            x1, [fp, #-0x10]
    // 0xb1bc80: StoreField: r0->field_b = r1
    //     0xb1bc80: stur            w1, [x0, #0xb]
    // 0xb1bc84: LeaveFrame
    //     0xb1bc84: mov             SP, fp
    //     0xb1bc88: ldp             fp, lr, [SP], #0x10
    // 0xb1bc8c: ret
    //     0xb1bc8c: ret             
    // 0xb1bc90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1bc90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1bc94: b               #0xb1badc
    // 0xb1bc98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1bc98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1bc9c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb1bc9c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _wrapInRotatedBox(/* No info */) {
    // ** addr: 0xb1bca0, size: 0x78
    // 0xb1bca0: EnterFrame
    //     0xb1bca0: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bca4: mov             fp, SP
    // 0xb1bca8: AllocStack(0x8)
    //     0xb1bca8: sub             SP, SP, #8
    // 0xb1bcac: CheckStackOverflow
    //     0xb1bcac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1bcb0: cmp             SP, x16
    //     0xb1bcb4: b.ls            #0xb1bd10
    // 0xb1bcb8: r0 = defaultTargetPlatform()
    //     0xb1bcb8: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xb1bcbc: r16 = Instance_TargetPlatform
    //     0xb1bcbc: ldr             x16, [PP, #0x43a8]  ; [pp+0x43a8] Obj!TargetPlatform@b65d71
    // 0xb1bcc0: cmp             w0, w16
    // 0xb1bcc4: b.eq            #0xb1bcd8
    // 0xb1bcc8: ldr             x0, [fp, #0x10]
    // 0xb1bccc: LeaveFrame
    //     0xb1bccc: mov             SP, fp
    //     0xb1bcd0: ldp             fp, lr, [SP], #0x10
    // 0xb1bcd4: ret
    //     0xb1bcd4: ret             
    // 0xb1bcd8: ldr             x0, [fp, #0x10]
    // 0xb1bcdc: ldr             x16, [fp, #0x18]
    // 0xb1bce0: SaveReg r16
    //     0xb1bce0: str             x16, [SP, #-8]!
    // 0xb1bce4: r0 = _getQuarterTurns()
    //     0xb1bce4: bl              #0xb1bd18  ; [package:camera/src/camera_preview.dart] CameraPreview::_getQuarterTurns
    // 0xb1bce8: add             SP, SP, #8
    // 0xb1bcec: stur            x0, [fp, #-8]
    // 0xb1bcf0: r0 = RotatedBox()
    //     0xb1bcf0: bl              #0x98d8cc  ; AllocateRotatedBoxStub -> RotatedBox (size=0x18)
    // 0xb1bcf4: ldur            x1, [fp, #-8]
    // 0xb1bcf8: StoreField: r0->field_f = r1
    //     0xb1bcf8: stur            x1, [x0, #0xf]
    // 0xb1bcfc: ldr             x1, [fp, #0x10]
    // 0xb1bd00: StoreField: r0->field_b = r1
    //     0xb1bd00: stur            w1, [x0, #0xb]
    // 0xb1bd04: LeaveFrame
    //     0xb1bd04: mov             SP, fp
    //     0xb1bd08: ldp             fp, lr, [SP], #0x10
    // 0xb1bd0c: ret
    //     0xb1bd0c: ret             
    // 0xb1bd10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1bd10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1bd14: b               #0xb1bcb8
  }
  _ _getQuarterTurns(/* No info */) {
    // ** addr: 0xb1bd18, size: 0xe4
    // 0xb1bd18: EnterFrame
    //     0xb1bd18: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bd1c: mov             fp, SP
    // 0xb1bd20: AllocStack(0x8)
    //     0xb1bd20: sub             SP, SP, #8
    // 0xb1bd24: CheckStackOverflow
    //     0xb1bd24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1bd28: cmp             SP, x16
    //     0xb1bd2c: b.ls            #0xb1bdf0
    // 0xb1bd30: r1 = Null
    //     0xb1bd30: mov             x1, NULL
    // 0xb1bd34: r2 = 16
    //     0xb1bd34: mov             x2, #0x10
    // 0xb1bd38: r0 = AllocateArray()
    //     0xb1bd38: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1bd3c: r17 = Instance_DeviceOrientation
    //     0xb1bd3c: ldr             x17, [PP, #0xe28]  ; [pp+0xe28] Obj!DeviceOrientation@b64311
    // 0xb1bd40: StoreField: r0->field_f = r17
    //     0xb1bd40: stur            w17, [x0, #0xf]
    // 0xb1bd44: StoreField: r0->field_13 = rZR
    //     0xb1bd44: stur            wzr, [x0, #0x13]
    // 0xb1bd48: r17 = Instance_DeviceOrientation
    //     0xb1bd48: ldr             x17, [PP, #0xe48]  ; [pp+0xe48] Obj!DeviceOrientation@b642d1
    // 0xb1bd4c: StoreField: r0->field_17 = r17
    //     0xb1bd4c: stur            w17, [x0, #0x17]
    // 0xb1bd50: r17 = 2
    //     0xb1bd50: mov             x17, #2
    // 0xb1bd54: StoreField: r0->field_1b = r17
    //     0xb1bd54: stur            w17, [x0, #0x1b]
    // 0xb1bd58: r17 = Instance_DeviceOrientation
    //     0xb1bd58: ldr             x17, [PP, #0xe38]  ; [pp+0xe38] Obj!DeviceOrientation@b642f1
    // 0xb1bd5c: StoreField: r0->field_1f = r17
    //     0xb1bd5c: stur            w17, [x0, #0x1f]
    // 0xb1bd60: r17 = 4
    //     0xb1bd60: mov             x17, #4
    // 0xb1bd64: StoreField: r0->field_23 = r17
    //     0xb1bd64: stur            w17, [x0, #0x23]
    // 0xb1bd68: r17 = Instance_DeviceOrientation
    //     0xb1bd68: ldr             x17, [PP, #0xe58]  ; [pp+0xe58] Obj!DeviceOrientation@b642b1
    // 0xb1bd6c: StoreField: r0->field_27 = r17
    //     0xb1bd6c: stur            w17, [x0, #0x27]
    // 0xb1bd70: r17 = 6
    //     0xb1bd70: mov             x17, #6
    // 0xb1bd74: StoreField: r0->field_2b = r17
    //     0xb1bd74: stur            w17, [x0, #0x2b]
    // 0xb1bd78: r16 = <DeviceOrientation, int>
    //     0xb1bd78: add             x16, PP, #0x54, lsl #12  ; [pp+0x542f8] TypeArguments: <DeviceOrientation, int>
    //     0xb1bd7c: ldr             x16, [x16, #0x2f8]
    // 0xb1bd80: stp             x0, x16, [SP, #-0x10]!
    // 0xb1bd84: r0 = Map._fromLiteral()
    //     0xb1bd84: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xb1bd88: add             SP, SP, #0x10
    // 0xb1bd8c: stur            x0, [fp, #-8]
    // 0xb1bd90: ldr             x16, [fp, #0x10]
    // 0xb1bd94: SaveReg r16
    //     0xb1bd94: str             x16, [SP, #-8]!
    // 0xb1bd98: r0 = _getApplicableOrientation()
    //     0xb1bd98: bl              #0xb1bdfc  ; [package:camera/src/camera_preview.dart] CameraPreview::_getApplicableOrientation
    // 0xb1bd9c: add             SP, SP, #8
    // 0xb1bda0: ldur            x16, [fp, #-8]
    // 0xb1bda4: stp             x0, x16, [SP, #-0x10]!
    // 0xb1bda8: r0 = _getValueOrData()
    //     0xb1bda8: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xb1bdac: add             SP, SP, #0x10
    // 0xb1bdb0: ldur            x1, [fp, #-8]
    // 0xb1bdb4: LoadField: r2 = r1->field_f
    //     0xb1bdb4: ldur            w2, [x1, #0xf]
    // 0xb1bdb8: DecompressPointer r2
    //     0xb1bdb8: add             x2, x2, HEAP, lsl #32
    // 0xb1bdbc: cmp             w2, w0
    // 0xb1bdc0: b.ne            #0xb1bdcc
    // 0xb1bdc4: r1 = Null
    //     0xb1bdc4: mov             x1, NULL
    // 0xb1bdc8: b               #0xb1bdd0
    // 0xb1bdcc: mov             x1, x0
    // 0xb1bdd0: cmp             w1, NULL
    // 0xb1bdd4: b.eq            #0xb1bdf8
    // 0xb1bdd8: r0 = LoadInt32Instr(r1)
    //     0xb1bdd8: sbfx            x0, x1, #1, #0x1f
    //     0xb1bddc: tbz             w1, #0, #0xb1bde4
    //     0xb1bde0: ldur            x0, [x1, #7]
    // 0xb1bde4: LeaveFrame
    //     0xb1bde4: mov             SP, fp
    //     0xb1bde8: ldp             fp, lr, [SP], #0x10
    // 0xb1bdec: ret
    //     0xb1bdec: ret             
    // 0xb1bdf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1bdf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1bdf4: b               #0xb1bd30
    // 0xb1bdf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1bdf8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getApplicableOrientation(/* No info */) {
    // ** addr: 0xb1bdfc, size: 0x8c
    // 0xb1bdfc: EnterFrame
    //     0xb1bdfc: stp             fp, lr, [SP, #-0x10]!
    //     0xb1be00: mov             fp, SP
    // 0xb1be04: ldr             x1, [fp, #0x10]
    // 0xb1be08: LoadField: r2 = r1->field_b
    //     0xb1be08: ldur            w2, [x1, #0xb]
    // 0xb1be0c: DecompressPointer r2
    //     0xb1be0c: add             x2, x2, HEAP, lsl #32
    // 0xb1be10: LoadField: r1 = r2->field_27
    //     0xb1be10: ldur            w1, [x2, #0x27]
    // 0xb1be14: DecompressPointer r1
    //     0xb1be14: add             x1, x1, HEAP, lsl #32
    // 0xb1be18: LoadField: r2 = r1->field_f
    //     0xb1be18: ldur            w2, [x1, #0xf]
    // 0xb1be1c: DecompressPointer r2
    //     0xb1be1c: add             x2, x2, HEAP, lsl #32
    // 0xb1be20: tbnz            w2, #4, #0xb1be3c
    // 0xb1be24: LoadField: r2 = r1->field_47
    //     0xb1be24: ldur            w2, [x1, #0x47]
    // 0xb1be28: DecompressPointer r2
    //     0xb1be28: add             x2, x2, HEAP, lsl #32
    // 0xb1be2c: cmp             w2, NULL
    // 0xb1be30: b.eq            #0xb1be84
    // 0xb1be34: mov             x0, x2
    // 0xb1be38: b               #0xb1be78
    // 0xb1be3c: LoadField: r2 = r1->field_1f
    //     0xb1be3c: ldur            w2, [x1, #0x1f]
    // 0xb1be40: DecompressPointer r2
    //     0xb1be40: add             x2, x2, HEAP, lsl #32
    // 0xb1be44: cmp             w2, NULL
    // 0xb1be48: b.ne            #0xb1be58
    // 0xb1be4c: LoadField: r3 = r1->field_43
    //     0xb1be4c: ldur            w3, [x1, #0x43]
    // 0xb1be50: DecompressPointer r3
    //     0xb1be50: add             x3, x3, HEAP, lsl #32
    // 0xb1be54: mov             x2, x3
    // 0xb1be58: cmp             w2, NULL
    // 0xb1be5c: b.ne            #0xb1be70
    // 0xb1be60: LoadField: r3 = r1->field_3f
    //     0xb1be60: ldur            w3, [x1, #0x3f]
    // 0xb1be64: DecompressPointer r3
    //     0xb1be64: add             x3, x3, HEAP, lsl #32
    // 0xb1be68: mov             x1, x3
    // 0xb1be6c: b               #0xb1be74
    // 0xb1be70: mov             x1, x2
    // 0xb1be74: mov             x0, x1
    // 0xb1be78: LeaveFrame
    //     0xb1be78: mov             SP, fp
    //     0xb1be7c: ldp             fp, lr, [SP], #0x10
    // 0xb1be80: ret
    //     0xb1be80: ret             
    // 0xb1be84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1be84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _isLandscape(/* No info */) {
    // ** addr: 0xb1c018, size: 0x94
    // 0xb1c018: EnterFrame
    //     0xb1c018: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c01c: mov             fp, SP
    // 0xb1c020: AllocStack(0x10)
    //     0xb1c020: sub             SP, SP, #0x10
    // 0xb1c024: r0 = 4
    //     0xb1c024: mov             x0, #4
    // 0xb1c028: CheckStackOverflow
    //     0xb1c028: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1c02c: cmp             SP, x16
    //     0xb1c030: b.ls            #0xb1c0a4
    // 0xb1c034: mov             x2, x0
    // 0xb1c038: r1 = Null
    //     0xb1c038: mov             x1, NULL
    // 0xb1c03c: r0 = AllocateArray()
    //     0xb1c03c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1c040: stur            x0, [fp, #-8]
    // 0xb1c044: r17 = Instance_DeviceOrientation
    //     0xb1c044: ldr             x17, [PP, #0xe58]  ; [pp+0xe58] Obj!DeviceOrientation@b642b1
    // 0xb1c048: StoreField: r0->field_f = r17
    //     0xb1c048: stur            w17, [x0, #0xf]
    // 0xb1c04c: r17 = Instance_DeviceOrientation
    //     0xb1c04c: ldr             x17, [PP, #0xe48]  ; [pp+0xe48] Obj!DeviceOrientation@b642d1
    // 0xb1c050: StoreField: r0->field_13 = r17
    //     0xb1c050: stur            w17, [x0, #0x13]
    // 0xb1c054: r1 = <DeviceOrientation>
    //     0xb1c054: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d690] TypeArguments: <DeviceOrientation>
    //     0xb1c058: ldr             x1, [x1, #0x690]
    // 0xb1c05c: r0 = AllocateGrowableArray()
    //     0xb1c05c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xb1c060: mov             x1, x0
    // 0xb1c064: ldur            x0, [fp, #-8]
    // 0xb1c068: stur            x1, [fp, #-0x10]
    // 0xb1c06c: StoreField: r1->field_f = r0
    //     0xb1c06c: stur            w0, [x1, #0xf]
    // 0xb1c070: r0 = 4
    //     0xb1c070: mov             x0, #4
    // 0xb1c074: StoreField: r1->field_b = r0
    //     0xb1c074: stur            w0, [x1, #0xb]
    // 0xb1c078: ldr             x16, [fp, #0x10]
    // 0xb1c07c: SaveReg r16
    //     0xb1c07c: str             x16, [SP, #-8]!
    // 0xb1c080: r0 = _getApplicableOrientation()
    //     0xb1c080: bl              #0xb1bdfc  ; [package:camera/src/camera_preview.dart] CameraPreview::_getApplicableOrientation
    // 0xb1c084: add             SP, SP, #8
    // 0xb1c088: ldur            x16, [fp, #-0x10]
    // 0xb1c08c: stp             x0, x16, [SP, #-0x10]!
    // 0xb1c090: r0 = contains()
    //     0xb1c090: bl              #0x786724  ; [dart:collection] _ListBase&Object&ListMixin::contains
    // 0xb1c094: add             SP, SP, #0x10
    // 0xb1c098: LeaveFrame
    //     0xb1c098: mov             SP, fp
    //     0xb1c09c: ldp             fp, lr, [SP], #0x10
    // 0xb1c0a0: ret
    //     0xb1c0a0: ret             
    // 0xb1c0a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c0a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c0a8: b               #0xb1c034
  }
}

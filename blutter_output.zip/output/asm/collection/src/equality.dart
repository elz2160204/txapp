// lib: , url: package:collection/src/equality.dart

// class id: 1048760, size: 0x8
class :: {
}

// class id: 4773, size: 0x10, field offset: 0x8
//   const constructor, 
class DeepCollectionEquality extends Object
    implements Equality<X0> {

  DefaultEquality<Never> field_8;
  bool field_c;

  _ hash(/* No info */) {
    // ** addr: 0xc05368, size: 0x404
    // 0xc05368: EnterFrame
    //     0xc05368: stp             fp, lr, [SP, #-0x10]!
    //     0xc0536c: mov             fp, SP
    // 0xc05370: CheckStackOverflow
    //     0xc05370: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc05374: cmp             SP, x16
    //     0xc05378: b.ls            #0xc05764
    // 0xc0537c: ldr             x0, [fp, #0x10]
    // 0xc05380: r2 = Null
    //     0xc05380: mov             x2, NULL
    // 0xc05384: r1 = Null
    //     0xc05384: mov             x1, NULL
    // 0xc05388: cmp             w0, NULL
    // 0xc0538c: b.eq            #0xc05424
    // 0xc05390: branchIfSmi(r0, 0xc05424)
    //     0xc05390: tbz             w0, #0, #0xc05424
    // 0xc05394: r3 = LoadClassIdInstr(r0)
    //     0xc05394: ldur            x3, [x0, #-1]
    //     0xc05398: ubfx            x3, x3, #0xc, #0x14
    // 0xc0539c: r17 = 6134
    //     0xc0539c: mov             x17, #0x17f6
    // 0xc053a0: cmp             x3, x17
    // 0xc053a4: b.eq            #0xc0542c
    // 0xc053a8: r4 = LoadClassIdInstr(r0)
    //     0xc053a8: ldur            x4, [x0, #-1]
    //     0xc053ac: ubfx            x4, x4, #0xc, #0x14
    // 0xc053b0: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc053b4: ldr             x3, [x3, #0x18]
    // 0xc053b8: ldr             x3, [x3, x4, lsl #3]
    // 0xc053bc: LoadField: r3 = r3->field_2b
    //     0xc053bc: ldur            w3, [x3, #0x2b]
    // 0xc053c0: DecompressPointer r3
    //     0xc053c0: add             x3, x3, HEAP, lsl #32
    // 0xc053c4: cmp             w3, NULL
    // 0xc053c8: b.eq            #0xc05424
    // 0xc053cc: LoadField: r3 = r3->field_f
    //     0xc053cc: ldur            w3, [x3, #0xf]
    // 0xc053d0: lsr             x3, x3, #4
    // 0xc053d4: r17 = 6134
    //     0xc053d4: mov             x17, #0x17f6
    // 0xc053d8: cmp             x3, x17
    // 0xc053dc: b.eq            #0xc0542c
    // 0xc053e0: r3 = SubtypeTestCache
    //     0xc053e0: add             x3, PP, #0x42, lsl #12  ; [pp+0x42770] SubtypeTestCache
    //     0xc053e4: ldr             x3, [x3, #0x770]
    // 0xc053e8: r24 = Subtype1TestCacheStub
    //     0xc053e8: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc053ec: LoadField: r30 = r24->field_7
    //     0xc053ec: ldur            lr, [x24, #7]
    // 0xc053f0: blr             lr
    // 0xc053f4: cmp             w7, NULL
    // 0xc053f8: b.eq            #0xc05404
    // 0xc053fc: tbnz            w7, #4, #0xc05424
    // 0xc05400: b               #0xc0542c
    // 0xc05404: r8 = Set
    //     0xc05404: add             x8, PP, #0x42, lsl #12  ; [pp+0x42778] Type: Set
    //     0xc05408: ldr             x8, [x8, #0x778]
    // 0xc0540c: r3 = SubtypeTestCache
    //     0xc0540c: add             x3, PP, #0x42, lsl #12  ; [pp+0x42780] SubtypeTestCache
    //     0xc05410: ldr             x3, [x3, #0x780]
    // 0xc05414: r24 = InstanceOfStub
    //     0xc05414: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc05418: LoadField: r30 = r24->field_7
    //     0xc05418: ldur            lr, [x24, #7]
    // 0xc0541c: blr             lr
    // 0xc05420: b               #0xc05430
    // 0xc05424: r0 = false
    //     0xc05424: add             x0, NULL, #0x30  ; false
    // 0xc05428: b               #0xc05430
    // 0xc0542c: r0 = true
    //     0xc0542c: add             x0, NULL, #0x20  ; true
    // 0xc05430: tbnz            w0, #4, #0xc05468
    // 0xc05434: ldr             x0, [fp, #0x18]
    // 0xc05438: r1 = <dynamic, Set, dynamic>
    //     0xc05438: add             x1, PP, #0x42, lsl #12  ; [pp+0x425d8] TypeArguments: <dynamic, Set, dynamic>
    //     0xc0543c: ldr             x1, [x1, #0x5d8]
    // 0xc05440: r0 = SetEquality()
    //     0xc05440: bl              #0xc057f4  ; AllocateSetEqualityStub -> SetEquality<C2X0> (size=0x10)
    // 0xc05444: ldr             x3, [fp, #0x18]
    // 0xc05448: StoreField: r0->field_b = r3
    //     0xc05448: stur            w3, [x0, #0xb]
    // 0xc0544c: ldr             x16, [fp, #0x10]
    // 0xc05450: stp             x16, x0, [SP, #-0x10]!
    // 0xc05454: r0 = hash()
    //     0xc05454: bl              #0xc04d20  ; [package:collection/src/equality.dart] _UnorderedEquality::hash
    // 0xc05458: add             SP, SP, #0x10
    // 0xc0545c: LeaveFrame
    //     0xc0545c: mov             SP, fp
    //     0xc05460: ldp             fp, lr, [SP], #0x10
    // 0xc05464: ret
    //     0xc05464: ret             
    // 0xc05468: ldr             x3, [fp, #0x18]
    // 0xc0546c: ldr             x0, [fp, #0x10]
    // 0xc05470: r2 = Null
    //     0xc05470: mov             x2, NULL
    // 0xc05474: r1 = Null
    //     0xc05474: mov             x1, NULL
    // 0xc05478: cmp             w0, NULL
    // 0xc0547c: b.eq            #0xc05514
    // 0xc05480: branchIfSmi(r0, 0xc05514)
    //     0xc05480: tbz             w0, #0, #0xc05514
    // 0xc05484: r3 = LoadClassIdInstr(r0)
    //     0xc05484: ldur            x3, [x0, #-1]
    //     0xc05488: ubfx            x3, x3, #0xc, #0x14
    // 0xc0548c: r17 = 5696
    //     0xc0548c: mov             x17, #0x1640
    // 0xc05490: cmp             x3, x17
    // 0xc05494: b.eq            #0xc0551c
    // 0xc05498: r4 = LoadClassIdInstr(r0)
    //     0xc05498: ldur            x4, [x0, #-1]
    //     0xc0549c: ubfx            x4, x4, #0xc, #0x14
    // 0xc054a0: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc054a4: ldr             x3, [x3, #0x18]
    // 0xc054a8: ldr             x3, [x3, x4, lsl #3]
    // 0xc054ac: LoadField: r3 = r3->field_2b
    //     0xc054ac: ldur            w3, [x3, #0x2b]
    // 0xc054b0: DecompressPointer r3
    //     0xc054b0: add             x3, x3, HEAP, lsl #32
    // 0xc054b4: cmp             w3, NULL
    // 0xc054b8: b.eq            #0xc05514
    // 0xc054bc: LoadField: r3 = r3->field_f
    //     0xc054bc: ldur            w3, [x3, #0xf]
    // 0xc054c0: lsr             x3, x3, #4
    // 0xc054c4: r17 = 5696
    //     0xc054c4: mov             x17, #0x1640
    // 0xc054c8: cmp             x3, x17
    // 0xc054cc: b.eq            #0xc0551c
    // 0xc054d0: r3 = SubtypeTestCache
    //     0xc054d0: add             x3, PP, #0x42, lsl #12  ; [pp+0x42788] SubtypeTestCache
    //     0xc054d4: ldr             x3, [x3, #0x788]
    // 0xc054d8: r24 = Subtype1TestCacheStub
    //     0xc054d8: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc054dc: LoadField: r30 = r24->field_7
    //     0xc054dc: ldur            lr, [x24, #7]
    // 0xc054e0: blr             lr
    // 0xc054e4: cmp             w7, NULL
    // 0xc054e8: b.eq            #0xc054f4
    // 0xc054ec: tbnz            w7, #4, #0xc05514
    // 0xc054f0: b               #0xc0551c
    // 0xc054f4: r8 = Map
    //     0xc054f4: add             x8, PP, #0x42, lsl #12  ; [pp+0x42790] Type: Map
    //     0xc054f8: ldr             x8, [x8, #0x790]
    // 0xc054fc: r3 = SubtypeTestCache
    //     0xc054fc: add             x3, PP, #0x42, lsl #12  ; [pp+0x42798] SubtypeTestCache
    //     0xc05500: ldr             x3, [x3, #0x798]
    // 0xc05504: r24 = InstanceOfStub
    //     0xc05504: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc05508: LoadField: r30 = r24->field_7
    //     0xc05508: ldur            lr, [x24, #7]
    // 0xc0550c: blr             lr
    // 0xc05510: b               #0xc05520
    // 0xc05514: r0 = false
    //     0xc05514: add             x0, NULL, #0x30  ; false
    // 0xc05518: b               #0xc05520
    // 0xc0551c: r0 = true
    //     0xc0551c: add             x0, NULL, #0x20  ; true
    // 0xc05520: tbnz            w0, #4, #0xc05558
    // 0xc05524: ldr             x0, [fp, #0x18]
    // 0xc05528: r1 = Null
    //     0xc05528: mov             x1, NULL
    // 0xc0552c: r0 = MapEquality()
    //     0xc0552c: bl              #0xc057e8  ; AllocateMapEqualityStub -> MapEquality<X0, X1> (size=0x14)
    // 0xc05530: ldr             x3, [fp, #0x18]
    // 0xc05534: StoreField: r0->field_b = r3
    //     0xc05534: stur            w3, [x0, #0xb]
    // 0xc05538: StoreField: r0->field_f = r3
    //     0xc05538: stur            w3, [x0, #0xf]
    // 0xc0553c: ldr             x16, [fp, #0x10]
    // 0xc05540: stp             x16, x0, [SP, #-0x10]!
    // 0xc05544: r0 = hash()
    //     0xc05544: bl              #0xc04f28  ; [package:collection/src/equality.dart] MapEquality::hash
    // 0xc05548: add             SP, SP, #0x10
    // 0xc0554c: LeaveFrame
    //     0xc0554c: mov             SP, fp
    //     0xc05550: ldp             fp, lr, [SP], #0x10
    // 0xc05554: ret
    //     0xc05554: ret             
    // 0xc05558: ldr             x3, [fp, #0x18]
    // 0xc0555c: ldr             x0, [fp, #0x10]
    // 0xc05560: r2 = Null
    //     0xc05560: mov             x2, NULL
    // 0xc05564: r1 = Null
    //     0xc05564: mov             x1, NULL
    // 0xc05568: cmp             w0, NULL
    // 0xc0556c: b.eq            #0xc05610
    // 0xc05570: branchIfSmi(r0, 0xc05610)
    //     0xc05570: tbz             w0, #0, #0xc05610
    // 0xc05574: r3 = LoadClassIdInstr(r0)
    //     0xc05574: ldur            x3, [x0, #-1]
    //     0xc05578: ubfx            x3, x3, #0xc, #0x14
    // 0xc0557c: r17 = 5697
    //     0xc0557c: mov             x17, #0x1641
    // 0xc05580: cmp             x3, x17
    // 0xc05584: b.eq            #0xc05618
    // 0xc05588: sub             x3, x3, #0x59
    // 0xc0558c: cmp             x3, #2
    // 0xc05590: b.ls            #0xc05618
    // 0xc05594: r4 = LoadClassIdInstr(r0)
    //     0xc05594: ldur            x4, [x0, #-1]
    //     0xc05598: ubfx            x4, x4, #0xc, #0x14
    // 0xc0559c: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc055a0: ldr             x3, [x3, #0x18]
    // 0xc055a4: ldr             x3, [x3, x4, lsl #3]
    // 0xc055a8: LoadField: r3 = r3->field_2b
    //     0xc055a8: ldur            w3, [x3, #0x2b]
    // 0xc055ac: DecompressPointer r3
    //     0xc055ac: add             x3, x3, HEAP, lsl #32
    // 0xc055b0: cmp             w3, NULL
    // 0xc055b4: b.eq            #0xc05610
    // 0xc055b8: LoadField: r3 = r3->field_f
    //     0xc055b8: ldur            w3, [x3, #0xf]
    // 0xc055bc: lsr             x3, x3, #4
    // 0xc055c0: r17 = 5697
    //     0xc055c0: mov             x17, #0x1641
    // 0xc055c4: cmp             x3, x17
    // 0xc055c8: b.eq            #0xc05618
    // 0xc055cc: r3 = SubtypeTestCache
    //     0xc055cc: add             x3, PP, #0x42, lsl #12  ; [pp+0x427a0] SubtypeTestCache
    //     0xc055d0: ldr             x3, [x3, #0x7a0]
    // 0xc055d4: r24 = Subtype1TestCacheStub
    //     0xc055d4: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc055d8: LoadField: r30 = r24->field_7
    //     0xc055d8: ldur            lr, [x24, #7]
    // 0xc055dc: blr             lr
    // 0xc055e0: cmp             w7, NULL
    // 0xc055e4: b.eq            #0xc055f0
    // 0xc055e8: tbnz            w7, #4, #0xc05610
    // 0xc055ec: b               #0xc05618
    // 0xc055f0: r8 = List
    //     0xc055f0: add             x8, PP, #0x42, lsl #12  ; [pp+0x427a8] Type: List
    //     0xc055f4: ldr             x8, [x8, #0x7a8]
    // 0xc055f8: r3 = SubtypeTestCache
    //     0xc055f8: add             x3, PP, #0x42, lsl #12  ; [pp+0x427b0] SubtypeTestCache
    //     0xc055fc: ldr             x3, [x3, #0x7b0]
    // 0xc05600: r24 = InstanceOfStub
    //     0xc05600: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc05604: LoadField: r30 = r24->field_7
    //     0xc05604: ldur            lr, [x24, #7]
    // 0xc05608: blr             lr
    // 0xc0560c: b               #0xc0561c
    // 0xc05610: r0 = false
    //     0xc05610: add             x0, NULL, #0x30  ; false
    // 0xc05614: b               #0xc0561c
    // 0xc05618: r0 = true
    //     0xc05618: add             x0, NULL, #0x20  ; true
    // 0xc0561c: tbnz            w0, #4, #0xc05650
    // 0xc05620: ldr             x0, [fp, #0x18]
    // 0xc05624: r1 = Null
    //     0xc05624: mov             x1, NULL
    // 0xc05628: r0 = ListEquality()
    //     0xc05628: bl              #0xc057dc  ; AllocateListEqualityStub -> ListEquality<X0> (size=0x10)
    // 0xc0562c: ldr             x3, [fp, #0x18]
    // 0xc05630: StoreField: r0->field_b = r3
    //     0xc05630: stur            w3, [x0, #0xb]
    // 0xc05634: ldr             x16, [fp, #0x10]
    // 0xc05638: stp             x16, x0, [SP, #-0x10]!
    // 0xc0563c: r0 = hash()
    //     0xc0563c: bl              #0xc04b70  ; [package:collection/src/equality.dart] ListEquality::hash
    // 0xc05640: add             SP, SP, #0x10
    // 0xc05644: LeaveFrame
    //     0xc05644: mov             SP, fp
    //     0xc05648: ldp             fp, lr, [SP], #0x10
    // 0xc0564c: ret
    //     0xc0564c: ret             
    // 0xc05650: ldr             x3, [fp, #0x18]
    // 0xc05654: ldr             x0, [fp, #0x10]
    // 0xc05658: r2 = Null
    //     0xc05658: mov             x2, NULL
    // 0xc0565c: r1 = Null
    //     0xc0565c: mov             x1, NULL
    // 0xc05660: cmp             w0, NULL
    // 0xc05664: b.eq            #0xc056fc
    // 0xc05668: branchIfSmi(r0, 0xc056fc)
    //     0xc05668: tbz             w0, #0, #0xc056fc
    // 0xc0566c: r3 = LoadClassIdInstr(r0)
    //     0xc0566c: ldur            x3, [x0, #-1]
    //     0xc05670: ubfx            x3, x3, #0xc, #0x14
    // 0xc05674: r17 = 6076
    //     0xc05674: mov             x17, #0x17bc
    // 0xc05678: cmp             x3, x17
    // 0xc0567c: b.eq            #0xc05704
    // 0xc05680: r4 = LoadClassIdInstr(r0)
    //     0xc05680: ldur            x4, [x0, #-1]
    //     0xc05684: ubfx            x4, x4, #0xc, #0x14
    // 0xc05688: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc0568c: ldr             x3, [x3, #0x18]
    // 0xc05690: ldr             x3, [x3, x4, lsl #3]
    // 0xc05694: LoadField: r3 = r3->field_2b
    //     0xc05694: ldur            w3, [x3, #0x2b]
    // 0xc05698: DecompressPointer r3
    //     0xc05698: add             x3, x3, HEAP, lsl #32
    // 0xc0569c: cmp             w3, NULL
    // 0xc056a0: b.eq            #0xc056fc
    // 0xc056a4: LoadField: r3 = r3->field_f
    //     0xc056a4: ldur            w3, [x3, #0xf]
    // 0xc056a8: lsr             x3, x3, #4
    // 0xc056ac: r17 = 6076
    //     0xc056ac: mov             x17, #0x17bc
    // 0xc056b0: cmp             x3, x17
    // 0xc056b4: b.eq            #0xc05704
    // 0xc056b8: r3 = SubtypeTestCache
    //     0xc056b8: add             x3, PP, #0x42, lsl #12  ; [pp+0x427b8] SubtypeTestCache
    //     0xc056bc: ldr             x3, [x3, #0x7b8]
    // 0xc056c0: r24 = Subtype1TestCacheStub
    //     0xc056c0: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc056c4: LoadField: r30 = r24->field_7
    //     0xc056c4: ldur            lr, [x24, #7]
    // 0xc056c8: blr             lr
    // 0xc056cc: cmp             w7, NULL
    // 0xc056d0: b.eq            #0xc056dc
    // 0xc056d4: tbnz            w7, #4, #0xc056fc
    // 0xc056d8: b               #0xc05704
    // 0xc056dc: r8 = Iterable
    //     0xc056dc: add             x8, PP, #0x42, lsl #12  ; [pp+0x427c0] Type: Iterable
    //     0xc056e0: ldr             x8, [x8, #0x7c0]
    // 0xc056e4: r3 = SubtypeTestCache
    //     0xc056e4: add             x3, PP, #0x42, lsl #12  ; [pp+0x427c8] SubtypeTestCache
    //     0xc056e8: ldr             x3, [x3, #0x7c8]
    // 0xc056ec: r24 = InstanceOfStub
    //     0xc056ec: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc056f0: LoadField: r30 = r24->field_7
    //     0xc056f0: ldur            lr, [x24, #7]
    // 0xc056f4: blr             lr
    // 0xc056f8: b               #0xc05708
    // 0xc056fc: r0 = false
    //     0xc056fc: add             x0, NULL, #0x30  ; false
    // 0xc05700: b               #0xc05708
    // 0xc05704: r0 = true
    //     0xc05704: add             x0, NULL, #0x20  ; true
    // 0xc05708: tbnz            w0, #4, #0xc05740
    // 0xc0570c: ldr             x0, [fp, #0x18]
    // 0xc05710: r1 = Null
    //     0xc05710: mov             x1, NULL
    // 0xc05714: r0 = IterableEquality()
    //     0xc05714: bl              #0xc057d0  ; AllocateIterableEqualityStub -> IterableEquality<X0> (size=0x10)
    // 0xc05718: mov             x1, x0
    // 0xc0571c: ldr             x0, [fp, #0x18]
    // 0xc05720: StoreField: r1->field_b = r0
    //     0xc05720: stur            w0, [x1, #0xb]
    // 0xc05724: ldr             x16, [fp, #0x10]
    // 0xc05728: stp             x16, x1, [SP, #-0x10]!
    // 0xc0572c: r0 = hash()
    //     0xc0572c: bl              #0xc048a4  ; [package:collection/src/equality.dart] IterableEquality::hash
    // 0xc05730: add             SP, SP, #0x10
    // 0xc05734: LeaveFrame
    //     0xc05734: mov             SP, fp
    //     0xc05738: ldp             fp, lr, [SP], #0x10
    // 0xc0573c: ret
    //     0xc0573c: ret             
    // 0xc05740: r16 = Instance_DefaultEquality
    //     0xc05740: add             x16, PP, #0x42, lsl #12  ; [pp+0x42670] Obj!DefaultEquality<Never>@b5c801
    //     0xc05744: ldr             x16, [x16, #0x670]
    // 0xc05748: ldr             lr, [fp, #0x10]
    // 0xc0574c: stp             lr, x16, [SP, #-0x10]!
    // 0xc05750: r0 = hash()
    //     0xc05750: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0xc05754: add             SP, SP, #0x10
    // 0xc05758: LeaveFrame
    //     0xc05758: mov             SP, fp
    //     0xc0575c: ldp             fp, lr, [SP], #0x10
    // 0xc05760: ret
    //     0xc05760: ret             
    // 0xc05764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05764: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05768: b               #0xc0537c
  }
  [closure] int hash(dynamic, Object?) {
    // ** addr: 0xc0576c, size: 0x64
    // 0xc0576c: EnterFrame
    //     0xc0576c: stp             fp, lr, [SP, #-0x10]!
    //     0xc05770: mov             fp, SP
    // 0xc05774: ldr             x0, [fp, #0x18]
    // 0xc05778: LoadField: r1 = r0->field_17
    //     0xc05778: ldur            w1, [x0, #0x17]
    // 0xc0577c: DecompressPointer r1
    //     0xc0577c: add             x1, x1, HEAP, lsl #32
    // 0xc05780: CheckStackOverflow
    //     0xc05780: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc05784: cmp             SP, x16
    //     0xc05788: b.ls            #0xc057c8
    // 0xc0578c: LoadField: r0 = r1->field_f
    //     0xc0578c: ldur            w0, [x1, #0xf]
    // 0xc05790: DecompressPointer r0
    //     0xc05790: add             x0, x0, HEAP, lsl #32
    // 0xc05794: ldr             x16, [fp, #0x10]
    // 0xc05798: stp             x16, x0, [SP, #-0x10]!
    // 0xc0579c: r0 = hash()
    //     0xc0579c: bl              #0xc05368  ; [package:collection/src/equality.dart] DeepCollectionEquality::hash
    // 0xc057a0: add             SP, SP, #0x10
    // 0xc057a4: mov             x2, x0
    // 0xc057a8: r0 = BoxInt64Instr(r2)
    //     0xc057a8: sbfiz           x0, x2, #1, #0x1f
    //     0xc057ac: cmp             x2, x0, asr #1
    //     0xc057b0: b.eq            #0xc057bc
    //     0xc057b4: bl              #0xd69bb8
    //     0xc057b8: stur            x2, [x0, #7]
    // 0xc057bc: LeaveFrame
    //     0xc057bc: mov             SP, fp
    //     0xc057c0: ldp             fp, lr, [SP], #0x10
    // 0xc057c4: ret
    //     0xc057c4: ret             
    // 0xc057c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc057c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc057cc: b               #0xc0578c
  }
  [closure] bool isValidKey(dynamic, Object?) {
    // ** addr: 0xc07558, size: 0x4c
    // 0xc07558: EnterFrame
    //     0xc07558: stp             fp, lr, [SP, #-0x10]!
    //     0xc0755c: mov             fp, SP
    // 0xc07560: ldr             x0, [fp, #0x18]
    // 0xc07564: LoadField: r1 = r0->field_17
    //     0xc07564: ldur            w1, [x0, #0x17]
    // 0xc07568: DecompressPointer r1
    //     0xc07568: add             x1, x1, HEAP, lsl #32
    // 0xc0756c: CheckStackOverflow
    //     0xc0756c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc07570: cmp             SP, x16
    //     0xc07574: b.ls            #0xc0759c
    // 0xc07578: LoadField: r0 = r1->field_f
    //     0xc07578: ldur            w0, [x1, #0xf]
    // 0xc0757c: DecompressPointer r0
    //     0xc0757c: add             x0, x0, HEAP, lsl #32
    // 0xc07580: ldr             x16, [fp, #0x10]
    // 0xc07584: stp             x16, x0, [SP, #-0x10]!
    // 0xc07588: r0 = isValidKey()
    //     0xc07588: bl              #0xc075a4  ; [package:collection/src/equality.dart] DeepCollectionEquality::isValidKey
    // 0xc0758c: add             SP, SP, #0x10
    // 0xc07590: LeaveFrame
    //     0xc07590: mov             SP, fp
    //     0xc07594: ldp             fp, lr, [SP], #0x10
    // 0xc07598: ret
    //     0xc07598: ret             
    // 0xc0759c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0759c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc075a0: b               #0xc07578
  }
  _ isValidKey(/* No info */) {
    // ** addr: 0xc075a4, size: 0x188
    // 0xc075a4: EnterFrame
    //     0xc075a4: stp             fp, lr, [SP, #-0x10]!
    //     0xc075a8: mov             fp, SP
    // 0xc075ac: ldr             x0, [fp, #0x10]
    // 0xc075b0: r2 = Null
    //     0xc075b0: mov             x2, NULL
    // 0xc075b4: r1 = Null
    //     0xc075b4: mov             x1, NULL
    // 0xc075b8: cmp             w0, NULL
    // 0xc075bc: b.eq            #0xc07654
    // 0xc075c0: branchIfSmi(r0, 0xc07654)
    //     0xc075c0: tbz             w0, #0, #0xc07654
    // 0xc075c4: r3 = LoadClassIdInstr(r0)
    //     0xc075c4: ldur            x3, [x0, #-1]
    //     0xc075c8: ubfx            x3, x3, #0xc, #0x14
    // 0xc075cc: r17 = 6076
    //     0xc075cc: mov             x17, #0x17bc
    // 0xc075d0: cmp             x3, x17
    // 0xc075d4: b.eq            #0xc0765c
    // 0xc075d8: r4 = LoadClassIdInstr(r0)
    //     0xc075d8: ldur            x4, [x0, #-1]
    //     0xc075dc: ubfx            x4, x4, #0xc, #0x14
    // 0xc075e0: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc075e4: ldr             x3, [x3, #0x18]
    // 0xc075e8: ldr             x3, [x3, x4, lsl #3]
    // 0xc075ec: LoadField: r3 = r3->field_2b
    //     0xc075ec: ldur            w3, [x3, #0x2b]
    // 0xc075f0: DecompressPointer r3
    //     0xc075f0: add             x3, x3, HEAP, lsl #32
    // 0xc075f4: cmp             w3, NULL
    // 0xc075f8: b.eq            #0xc07654
    // 0xc075fc: LoadField: r3 = r3->field_f
    //     0xc075fc: ldur            w3, [x3, #0xf]
    // 0xc07600: lsr             x3, x3, #4
    // 0xc07604: r17 = 6076
    //     0xc07604: mov             x17, #0x17bc
    // 0xc07608: cmp             x3, x17
    // 0xc0760c: b.eq            #0xc0765c
    // 0xc07610: r3 = SubtypeTestCache
    //     0xc07610: add             x3, PP, #0x42, lsl #12  ; [pp+0x42740] SubtypeTestCache
    //     0xc07614: ldr             x3, [x3, #0x740]
    // 0xc07618: r24 = Subtype1TestCacheStub
    //     0xc07618: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc0761c: LoadField: r30 = r24->field_7
    //     0xc0761c: ldur            lr, [x24, #7]
    // 0xc07620: blr             lr
    // 0xc07624: cmp             w7, NULL
    // 0xc07628: b.eq            #0xc07634
    // 0xc0762c: tbnz            w7, #4, #0xc07654
    // 0xc07630: b               #0xc0765c
    // 0xc07634: r8 = Iterable
    //     0xc07634: add             x8, PP, #0x42, lsl #12  ; [pp+0x42748] Type: Iterable
    //     0xc07638: ldr             x8, [x8, #0x748]
    // 0xc0763c: r3 = SubtypeTestCache
    //     0xc0763c: add             x3, PP, #0x42, lsl #12  ; [pp+0x42750] SubtypeTestCache
    //     0xc07640: ldr             x3, [x3, #0x750]
    // 0xc07644: r24 = InstanceOfStub
    //     0xc07644: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc07648: LoadField: r30 = r24->field_7
    //     0xc07648: ldur            lr, [x24, #7]
    // 0xc0764c: blr             lr
    // 0xc07650: b               #0xc07660
    // 0xc07654: r0 = false
    //     0xc07654: add             x0, NULL, #0x30  ; false
    // 0xc07658: b               #0xc07660
    // 0xc0765c: r0 = true
    //     0xc0765c: add             x0, NULL, #0x20  ; true
    // 0xc07660: tbz             w0, #4, #0xc0771c
    // 0xc07664: ldr             x0, [fp, #0x10]
    // 0xc07668: r2 = Null
    //     0xc07668: mov             x2, NULL
    // 0xc0766c: r1 = Null
    //     0xc0766c: mov             x1, NULL
    // 0xc07670: cmp             w0, NULL
    // 0xc07674: b.eq            #0xc0770c
    // 0xc07678: branchIfSmi(r0, 0xc0770c)
    //     0xc07678: tbz             w0, #0, #0xc0770c
    // 0xc0767c: r3 = LoadClassIdInstr(r0)
    //     0xc0767c: ldur            x3, [x0, #-1]
    //     0xc07680: ubfx            x3, x3, #0xc, #0x14
    // 0xc07684: r17 = 5696
    //     0xc07684: mov             x17, #0x1640
    // 0xc07688: cmp             x3, x17
    // 0xc0768c: b.eq            #0xc07714
    // 0xc07690: r4 = LoadClassIdInstr(r0)
    //     0xc07690: ldur            x4, [x0, #-1]
    //     0xc07694: ubfx            x4, x4, #0xc, #0x14
    // 0xc07698: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc0769c: ldr             x3, [x3, #0x18]
    // 0xc076a0: ldr             x3, [x3, x4, lsl #3]
    // 0xc076a4: LoadField: r3 = r3->field_2b
    //     0xc076a4: ldur            w3, [x3, #0x2b]
    // 0xc076a8: DecompressPointer r3
    //     0xc076a8: add             x3, x3, HEAP, lsl #32
    // 0xc076ac: cmp             w3, NULL
    // 0xc076b0: b.eq            #0xc0770c
    // 0xc076b4: LoadField: r3 = r3->field_f
    //     0xc076b4: ldur            w3, [x3, #0xf]
    // 0xc076b8: lsr             x3, x3, #4
    // 0xc076bc: r17 = 5696
    //     0xc076bc: mov             x17, #0x1640
    // 0xc076c0: cmp             x3, x17
    // 0xc076c4: b.eq            #0xc07714
    // 0xc076c8: r3 = SubtypeTestCache
    //     0xc076c8: add             x3, PP, #0x42, lsl #12  ; [pp+0x42758] SubtypeTestCache
    //     0xc076cc: ldr             x3, [x3, #0x758]
    // 0xc076d0: r24 = Subtype1TestCacheStub
    //     0xc076d0: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc076d4: LoadField: r30 = r24->field_7
    //     0xc076d4: ldur            lr, [x24, #7]
    // 0xc076d8: blr             lr
    // 0xc076dc: cmp             w7, NULL
    // 0xc076e0: b.eq            #0xc076ec
    // 0xc076e4: tbnz            w7, #4, #0xc0770c
    // 0xc076e8: b               #0xc07714
    // 0xc076ec: r8 = Map
    //     0xc076ec: add             x8, PP, #0x42, lsl #12  ; [pp+0x42760] Type: Map
    //     0xc076f0: ldr             x8, [x8, #0x760]
    // 0xc076f4: r3 = SubtypeTestCache
    //     0xc076f4: add             x3, PP, #0x42, lsl #12  ; [pp+0x42768] SubtypeTestCache
    //     0xc076f8: ldr             x3, [x3, #0x768]
    // 0xc076fc: r24 = InstanceOfStub
    //     0xc076fc: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc07700: LoadField: r30 = r24->field_7
    //     0xc07700: ldur            lr, [x24, #7]
    // 0xc07704: blr             lr
    // 0xc07708: b               #0xc07718
    // 0xc0770c: r0 = false
    //     0xc0770c: add             x0, NULL, #0x30  ; false
    // 0xc07710: b               #0xc07718
    // 0xc07714: r0 = true
    //     0xc07714: add             x0, NULL, #0x20  ; true
    // 0xc07718: tbz             w0, #4, #0xc0771c
    // 0xc0771c: r0 = true
    //     0xc0771c: add             x0, NULL, #0x20  ; true
    // 0xc07720: LeaveFrame
    //     0xc07720: mov             SP, fp
    //     0xc07724: ldp             fp, lr, [SP], #0x10
    // 0xc07728: ret
    //     0xc07728: ret             
  }
  [closure] bool equals(dynamic, Object?, Object?) {
    // ** addr: 0xc0772c, size: 0x54
    // 0xc0772c: EnterFrame
    //     0xc0772c: stp             fp, lr, [SP, #-0x10]!
    //     0xc07730: mov             fp, SP
    // 0xc07734: ldr             x0, [fp, #0x20]
    // 0xc07738: LoadField: r1 = r0->field_17
    //     0xc07738: ldur            w1, [x0, #0x17]
    // 0xc0773c: DecompressPointer r1
    //     0xc0773c: add             x1, x1, HEAP, lsl #32
    // 0xc07740: CheckStackOverflow
    //     0xc07740: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc07744: cmp             SP, x16
    //     0xc07748: b.ls            #0xc07778
    // 0xc0774c: LoadField: r0 = r1->field_f
    //     0xc0774c: ldur            w0, [x1, #0xf]
    // 0xc07750: DecompressPointer r0
    //     0xc07750: add             x0, x0, HEAP, lsl #32
    // 0xc07754: ldr             x16, [fp, #0x18]
    // 0xc07758: stp             x16, x0, [SP, #-0x10]!
    // 0xc0775c: ldr             x16, [fp, #0x10]
    // 0xc07760: SaveReg r16
    //     0xc07760: str             x16, [SP, #-8]!
    // 0xc07764: r0 = equals()
    //     0xc07764: bl              #0xc07d34  ; [package:collection/src/equality.dart] DeepCollectionEquality::equals
    // 0xc07768: add             SP, SP, #0x18
    // 0xc0776c: LeaveFrame
    //     0xc0776c: mov             SP, fp
    //     0xc07770: ldp             fp, lr, [SP], #0x10
    // 0xc07774: ret
    //     0xc07774: ret             
    // 0xc07778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc07778: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0777c: b               #0xc0774c
  }
  _ equals(/* No info */) {
    // ** addr: 0xc07d34, size: 0x750
    // 0xc07d34: EnterFrame
    //     0xc07d34: stp             fp, lr, [SP, #-0x10]!
    //     0xc07d38: mov             fp, SP
    // 0xc07d3c: AllocStack(0x8)
    //     0xc07d3c: sub             SP, SP, #8
    // 0xc07d40: CheckStackOverflow
    //     0xc07d40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc07d44: cmp             SP, x16
    //     0xc07d48: b.ls            #0xc0847c
    // 0xc07d4c: ldr             x0, [fp, #0x18]
    // 0xc07d50: r2 = Null
    //     0xc07d50: mov             x2, NULL
    // 0xc07d54: r1 = Null
    //     0xc07d54: mov             x1, NULL
    // 0xc07d58: cmp             w0, NULL
    // 0xc07d5c: b.eq            #0xc07df4
    // 0xc07d60: branchIfSmi(r0, 0xc07df4)
    //     0xc07d60: tbz             w0, #0, #0xc07df4
    // 0xc07d64: r3 = LoadClassIdInstr(r0)
    //     0xc07d64: ldur            x3, [x0, #-1]
    //     0xc07d68: ubfx            x3, x3, #0xc, #0x14
    // 0xc07d6c: r17 = 6134
    //     0xc07d6c: mov             x17, #0x17f6
    // 0xc07d70: cmp             x3, x17
    // 0xc07d74: b.eq            #0xc07dfc
    // 0xc07d78: r4 = LoadClassIdInstr(r0)
    //     0xc07d78: ldur            x4, [x0, #-1]
    //     0xc07d7c: ubfx            x4, x4, #0xc, #0x14
    // 0xc07d80: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc07d84: ldr             x3, [x3, #0x18]
    // 0xc07d88: ldr             x3, [x3, x4, lsl #3]
    // 0xc07d8c: LoadField: r3 = r3->field_2b
    //     0xc07d8c: ldur            w3, [x3, #0x2b]
    // 0xc07d90: DecompressPointer r3
    //     0xc07d90: add             x3, x3, HEAP, lsl #32
    // 0xc07d94: cmp             w3, NULL
    // 0xc07d98: b.eq            #0xc07df4
    // 0xc07d9c: LoadField: r3 = r3->field_f
    //     0xc07d9c: ldur            w3, [x3, #0xf]
    // 0xc07da0: lsr             x3, x3, #4
    // 0xc07da4: r17 = 6134
    //     0xc07da4: mov             x17, #0x17f6
    // 0xc07da8: cmp             x3, x17
    // 0xc07dac: b.eq            #0xc07dfc
    // 0xc07db0: r3 = SubtypeTestCache
    //     0xc07db0: add             x3, PP, #0x42, lsl #12  ; [pp+0x425a8] SubtypeTestCache
    //     0xc07db4: ldr             x3, [x3, #0x5a8]
    // 0xc07db8: r24 = Subtype1TestCacheStub
    //     0xc07db8: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc07dbc: LoadField: r30 = r24->field_7
    //     0xc07dbc: ldur            lr, [x24, #7]
    // 0xc07dc0: blr             lr
    // 0xc07dc4: cmp             w7, NULL
    // 0xc07dc8: b.eq            #0xc07dd4
    // 0xc07dcc: tbnz            w7, #4, #0xc07df4
    // 0xc07dd0: b               #0xc07dfc
    // 0xc07dd4: r8 = Set
    //     0xc07dd4: add             x8, PP, #0x42, lsl #12  ; [pp+0x425b0] Type: Set
    //     0xc07dd8: ldr             x8, [x8, #0x5b0]
    // 0xc07ddc: r3 = SubtypeTestCache
    //     0xc07ddc: add             x3, PP, #0x42, lsl #12  ; [pp+0x425b8] SubtypeTestCache
    //     0xc07de0: ldr             x3, [x3, #0x5b8]
    // 0xc07de4: r24 = InstanceOfStub
    //     0xc07de4: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc07de8: LoadField: r30 = r24->field_7
    //     0xc07de8: ldur            lr, [x24, #7]
    // 0xc07dec: blr             lr
    // 0xc07df0: b               #0xc07e00
    // 0xc07df4: r0 = false
    //     0xc07df4: add             x0, NULL, #0x30  ; false
    // 0xc07df8: b               #0xc07e00
    // 0xc07dfc: r0 = true
    //     0xc07dfc: add             x0, NULL, #0x20  ; true
    // 0xc07e00: tbnz            w0, #4, #0xc07f00
    // 0xc07e04: ldr             x0, [fp, #0x10]
    // 0xc07e08: r2 = Null
    //     0xc07e08: mov             x2, NULL
    // 0xc07e0c: r1 = Null
    //     0xc07e0c: mov             x1, NULL
    // 0xc07e10: cmp             w0, NULL
    // 0xc07e14: b.eq            #0xc07eac
    // 0xc07e18: branchIfSmi(r0, 0xc07eac)
    //     0xc07e18: tbz             w0, #0, #0xc07eac
    // 0xc07e1c: r3 = LoadClassIdInstr(r0)
    //     0xc07e1c: ldur            x3, [x0, #-1]
    //     0xc07e20: ubfx            x3, x3, #0xc, #0x14
    // 0xc07e24: r17 = 6134
    //     0xc07e24: mov             x17, #0x17f6
    // 0xc07e28: cmp             x3, x17
    // 0xc07e2c: b.eq            #0xc07eb4
    // 0xc07e30: r4 = LoadClassIdInstr(r0)
    //     0xc07e30: ldur            x4, [x0, #-1]
    //     0xc07e34: ubfx            x4, x4, #0xc, #0x14
    // 0xc07e38: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc07e3c: ldr             x3, [x3, #0x18]
    // 0xc07e40: ldr             x3, [x3, x4, lsl #3]
    // 0xc07e44: LoadField: r3 = r3->field_2b
    //     0xc07e44: ldur            w3, [x3, #0x2b]
    // 0xc07e48: DecompressPointer r3
    //     0xc07e48: add             x3, x3, HEAP, lsl #32
    // 0xc07e4c: cmp             w3, NULL
    // 0xc07e50: b.eq            #0xc07eac
    // 0xc07e54: LoadField: r3 = r3->field_f
    //     0xc07e54: ldur            w3, [x3, #0xf]
    // 0xc07e58: lsr             x3, x3, #4
    // 0xc07e5c: r17 = 6134
    //     0xc07e5c: mov             x17, #0x17f6
    // 0xc07e60: cmp             x3, x17
    // 0xc07e64: b.eq            #0xc07eb4
    // 0xc07e68: r3 = SubtypeTestCache
    //     0xc07e68: add             x3, PP, #0x42, lsl #12  ; [pp+0x425c0] SubtypeTestCache
    //     0xc07e6c: ldr             x3, [x3, #0x5c0]
    // 0xc07e70: r24 = Subtype1TestCacheStub
    //     0xc07e70: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc07e74: LoadField: r30 = r24->field_7
    //     0xc07e74: ldur            lr, [x24, #7]
    // 0xc07e78: blr             lr
    // 0xc07e7c: cmp             w7, NULL
    // 0xc07e80: b.eq            #0xc07e8c
    // 0xc07e84: tbnz            w7, #4, #0xc07eac
    // 0xc07e88: b               #0xc07eb4
    // 0xc07e8c: r8 = Set
    //     0xc07e8c: add             x8, PP, #0x42, lsl #12  ; [pp+0x425c8] Type: Set
    //     0xc07e90: ldr             x8, [x8, #0x5c8]
    // 0xc07e94: r3 = SubtypeTestCache
    //     0xc07e94: add             x3, PP, #0x42, lsl #12  ; [pp+0x425d0] SubtypeTestCache
    //     0xc07e98: ldr             x3, [x3, #0x5d0]
    // 0xc07e9c: r24 = InstanceOfStub
    //     0xc07e9c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc07ea0: LoadField: r30 = r24->field_7
    //     0xc07ea0: ldur            lr, [x24, #7]
    // 0xc07ea4: blr             lr
    // 0xc07ea8: b               #0xc07eb8
    // 0xc07eac: r0 = false
    //     0xc07eac: add             x0, NULL, #0x30  ; false
    // 0xc07eb0: b               #0xc07eb8
    // 0xc07eb4: r0 = true
    //     0xc07eb4: add             x0, NULL, #0x20  ; true
    // 0xc07eb8: tbnz            w0, #4, #0xc07ef0
    // 0xc07ebc: ldr             x0, [fp, #0x20]
    // 0xc07ec0: r1 = <dynamic, Set, dynamic>
    //     0xc07ec0: add             x1, PP, #0x42, lsl #12  ; [pp+0x425d8] TypeArguments: <dynamic, Set, dynamic>
    //     0xc07ec4: ldr             x1, [x1, #0x5d8]
    // 0xc07ec8: r0 = SetEquality()
    //     0xc07ec8: bl              #0xc057f4  ; AllocateSetEqualityStub -> SetEquality<C2X0> (size=0x10)
    // 0xc07ecc: ldr             x3, [fp, #0x20]
    // 0xc07ed0: StoreField: r0->field_b = r3
    //     0xc07ed0: stur            w3, [x0, #0xb]
    // 0xc07ed4: ldr             x16, [fp, #0x18]
    // 0xc07ed8: stp             x16, x0, [SP, #-0x10]!
    // 0xc07edc: ldr             x16, [fp, #0x10]
    // 0xc07ee0: SaveReg r16
    //     0xc07ee0: str             x16, [SP, #-8]!
    // 0xc07ee4: r0 = equals()
    //     0xc07ee4: bl              #0xc06ffc  ; [package:collection/src/equality.dart] _UnorderedEquality::equals
    // 0xc07ee8: add             SP, SP, #0x18
    // 0xc07eec: b               #0xc07ef4
    // 0xc07ef0: r0 = false
    //     0xc07ef0: add             x0, NULL, #0x30  ; false
    // 0xc07ef4: LeaveFrame
    //     0xc07ef4: mov             SP, fp
    //     0xc07ef8: ldp             fp, lr, [SP], #0x10
    // 0xc07efc: ret
    //     0xc07efc: ret             
    // 0xc07f00: ldr             x3, [fp, #0x20]
    // 0xc07f04: ldr             x0, [fp, #0x18]
    // 0xc07f08: r2 = Null
    //     0xc07f08: mov             x2, NULL
    // 0xc07f0c: r1 = Null
    //     0xc07f0c: mov             x1, NULL
    // 0xc07f10: cmp             w0, NULL
    // 0xc07f14: b.eq            #0xc07fac
    // 0xc07f18: branchIfSmi(r0, 0xc07fac)
    //     0xc07f18: tbz             w0, #0, #0xc07fac
    // 0xc07f1c: r3 = LoadClassIdInstr(r0)
    //     0xc07f1c: ldur            x3, [x0, #-1]
    //     0xc07f20: ubfx            x3, x3, #0xc, #0x14
    // 0xc07f24: r17 = 5696
    //     0xc07f24: mov             x17, #0x1640
    // 0xc07f28: cmp             x3, x17
    // 0xc07f2c: b.eq            #0xc07fb4
    // 0xc07f30: r4 = LoadClassIdInstr(r0)
    //     0xc07f30: ldur            x4, [x0, #-1]
    //     0xc07f34: ubfx            x4, x4, #0xc, #0x14
    // 0xc07f38: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc07f3c: ldr             x3, [x3, #0x18]
    // 0xc07f40: ldr             x3, [x3, x4, lsl #3]
    // 0xc07f44: LoadField: r3 = r3->field_2b
    //     0xc07f44: ldur            w3, [x3, #0x2b]
    // 0xc07f48: DecompressPointer r3
    //     0xc07f48: add             x3, x3, HEAP, lsl #32
    // 0xc07f4c: cmp             w3, NULL
    // 0xc07f50: b.eq            #0xc07fac
    // 0xc07f54: LoadField: r3 = r3->field_f
    //     0xc07f54: ldur            w3, [x3, #0xf]
    // 0xc07f58: lsr             x3, x3, #4
    // 0xc07f5c: r17 = 5696
    //     0xc07f5c: mov             x17, #0x1640
    // 0xc07f60: cmp             x3, x17
    // 0xc07f64: b.eq            #0xc07fb4
    // 0xc07f68: r3 = SubtypeTestCache
    //     0xc07f68: add             x3, PP, #0x42, lsl #12  ; [pp+0x425e0] SubtypeTestCache
    //     0xc07f6c: ldr             x3, [x3, #0x5e0]
    // 0xc07f70: r24 = Subtype1TestCacheStub
    //     0xc07f70: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc07f74: LoadField: r30 = r24->field_7
    //     0xc07f74: ldur            lr, [x24, #7]
    // 0xc07f78: blr             lr
    // 0xc07f7c: cmp             w7, NULL
    // 0xc07f80: b.eq            #0xc07f8c
    // 0xc07f84: tbnz            w7, #4, #0xc07fac
    // 0xc07f88: b               #0xc07fb4
    // 0xc07f8c: r8 = Map
    //     0xc07f8c: add             x8, PP, #0x42, lsl #12  ; [pp+0x425e8] Type: Map
    //     0xc07f90: ldr             x8, [x8, #0x5e8]
    // 0xc07f94: r3 = SubtypeTestCache
    //     0xc07f94: add             x3, PP, #0x42, lsl #12  ; [pp+0x425f0] SubtypeTestCache
    //     0xc07f98: ldr             x3, [x3, #0x5f0]
    // 0xc07f9c: r24 = InstanceOfStub
    //     0xc07f9c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc07fa0: LoadField: r30 = r24->field_7
    //     0xc07fa0: ldur            lr, [x24, #7]
    // 0xc07fa4: blr             lr
    // 0xc07fa8: b               #0xc07fb8
    // 0xc07fac: r0 = false
    //     0xc07fac: add             x0, NULL, #0x30  ; false
    // 0xc07fb0: b               #0xc07fb8
    // 0xc07fb4: r0 = true
    //     0xc07fb4: add             x0, NULL, #0x20  ; true
    // 0xc07fb8: tbnz            w0, #4, #0xc080b8
    // 0xc07fbc: ldr             x0, [fp, #0x10]
    // 0xc07fc0: r2 = Null
    //     0xc07fc0: mov             x2, NULL
    // 0xc07fc4: r1 = Null
    //     0xc07fc4: mov             x1, NULL
    // 0xc07fc8: cmp             w0, NULL
    // 0xc07fcc: b.eq            #0xc08064
    // 0xc07fd0: branchIfSmi(r0, 0xc08064)
    //     0xc07fd0: tbz             w0, #0, #0xc08064
    // 0xc07fd4: r3 = LoadClassIdInstr(r0)
    //     0xc07fd4: ldur            x3, [x0, #-1]
    //     0xc07fd8: ubfx            x3, x3, #0xc, #0x14
    // 0xc07fdc: r17 = 5696
    //     0xc07fdc: mov             x17, #0x1640
    // 0xc07fe0: cmp             x3, x17
    // 0xc07fe4: b.eq            #0xc0806c
    // 0xc07fe8: r4 = LoadClassIdInstr(r0)
    //     0xc07fe8: ldur            x4, [x0, #-1]
    //     0xc07fec: ubfx            x4, x4, #0xc, #0x14
    // 0xc07ff0: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc07ff4: ldr             x3, [x3, #0x18]
    // 0xc07ff8: ldr             x3, [x3, x4, lsl #3]
    // 0xc07ffc: LoadField: r3 = r3->field_2b
    //     0xc07ffc: ldur            w3, [x3, #0x2b]
    // 0xc08000: DecompressPointer r3
    //     0xc08000: add             x3, x3, HEAP, lsl #32
    // 0xc08004: cmp             w3, NULL
    // 0xc08008: b.eq            #0xc08064
    // 0xc0800c: LoadField: r3 = r3->field_f
    //     0xc0800c: ldur            w3, [x3, #0xf]
    // 0xc08010: lsr             x3, x3, #4
    // 0xc08014: r17 = 5696
    //     0xc08014: mov             x17, #0x1640
    // 0xc08018: cmp             x3, x17
    // 0xc0801c: b.eq            #0xc0806c
    // 0xc08020: r3 = SubtypeTestCache
    //     0xc08020: add             x3, PP, #0x42, lsl #12  ; [pp+0x425f8] SubtypeTestCache
    //     0xc08024: ldr             x3, [x3, #0x5f8]
    // 0xc08028: r24 = Subtype1TestCacheStub
    //     0xc08028: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc0802c: LoadField: r30 = r24->field_7
    //     0xc0802c: ldur            lr, [x24, #7]
    // 0xc08030: blr             lr
    // 0xc08034: cmp             w7, NULL
    // 0xc08038: b.eq            #0xc08044
    // 0xc0803c: tbnz            w7, #4, #0xc08064
    // 0xc08040: b               #0xc0806c
    // 0xc08044: r8 = Map
    //     0xc08044: add             x8, PP, #0x42, lsl #12  ; [pp+0x42600] Type: Map
    //     0xc08048: ldr             x8, [x8, #0x600]
    // 0xc0804c: r3 = SubtypeTestCache
    //     0xc0804c: add             x3, PP, #0x42, lsl #12  ; [pp+0x42608] SubtypeTestCache
    //     0xc08050: ldr             x3, [x3, #0x608]
    // 0xc08054: r24 = InstanceOfStub
    //     0xc08054: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc08058: LoadField: r30 = r24->field_7
    //     0xc08058: ldur            lr, [x24, #7]
    // 0xc0805c: blr             lr
    // 0xc08060: b               #0xc08070
    // 0xc08064: r0 = false
    //     0xc08064: add             x0, NULL, #0x30  ; false
    // 0xc08068: b               #0xc08070
    // 0xc0806c: r0 = true
    //     0xc0806c: add             x0, NULL, #0x20  ; true
    // 0xc08070: tbnz            w0, #4, #0xc080a8
    // 0xc08074: ldr             x0, [fp, #0x20]
    // 0xc08078: r1 = Null
    //     0xc08078: mov             x1, NULL
    // 0xc0807c: r0 = MapEquality()
    //     0xc0807c: bl              #0xc057e8  ; AllocateMapEqualityStub -> MapEquality<X0, X1> (size=0x14)
    // 0xc08080: ldr             x3, [fp, #0x20]
    // 0xc08084: StoreField: r0->field_b = r3
    //     0xc08084: stur            w3, [x0, #0xb]
    // 0xc08088: StoreField: r0->field_f = r3
    //     0xc08088: stur            w3, [x0, #0xf]
    // 0xc0808c: ldr             x16, [fp, #0x18]
    // 0xc08090: stp             x16, x0, [SP, #-0x10]!
    // 0xc08094: ldr             x16, [fp, #0x10]
    // 0xc08098: SaveReg r16
    //     0xc08098: str             x16, [SP, #-8]!
    // 0xc0809c: r0 = equals()
    //     0xc0809c: bl              #0xc077e0  ; [package:collection/src/equality.dart] MapEquality::equals
    // 0xc080a0: add             SP, SP, #0x18
    // 0xc080a4: b               #0xc080ac
    // 0xc080a8: r0 = false
    //     0xc080a8: add             x0, NULL, #0x30  ; false
    // 0xc080ac: LeaveFrame
    //     0xc080ac: mov             SP, fp
    //     0xc080b0: ldp             fp, lr, [SP], #0x10
    // 0xc080b4: ret
    //     0xc080b4: ret             
    // 0xc080b8: ldr             x3, [fp, #0x20]
    // 0xc080bc: ldr             x0, [fp, #0x18]
    // 0xc080c0: r2 = Null
    //     0xc080c0: mov             x2, NULL
    // 0xc080c4: r1 = Null
    //     0xc080c4: mov             x1, NULL
    // 0xc080c8: cmp             w0, NULL
    // 0xc080cc: b.eq            #0xc08170
    // 0xc080d0: branchIfSmi(r0, 0xc08170)
    //     0xc080d0: tbz             w0, #0, #0xc08170
    // 0xc080d4: r3 = LoadClassIdInstr(r0)
    //     0xc080d4: ldur            x3, [x0, #-1]
    //     0xc080d8: ubfx            x3, x3, #0xc, #0x14
    // 0xc080dc: r17 = 5697
    //     0xc080dc: mov             x17, #0x1641
    // 0xc080e0: cmp             x3, x17
    // 0xc080e4: b.eq            #0xc08178
    // 0xc080e8: sub             x3, x3, #0x59
    // 0xc080ec: cmp             x3, #2
    // 0xc080f0: b.ls            #0xc08178
    // 0xc080f4: r4 = LoadClassIdInstr(r0)
    //     0xc080f4: ldur            x4, [x0, #-1]
    //     0xc080f8: ubfx            x4, x4, #0xc, #0x14
    // 0xc080fc: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc08100: ldr             x3, [x3, #0x18]
    // 0xc08104: ldr             x3, [x3, x4, lsl #3]
    // 0xc08108: LoadField: r3 = r3->field_2b
    //     0xc08108: ldur            w3, [x3, #0x2b]
    // 0xc0810c: DecompressPointer r3
    //     0xc0810c: add             x3, x3, HEAP, lsl #32
    // 0xc08110: cmp             w3, NULL
    // 0xc08114: b.eq            #0xc08170
    // 0xc08118: LoadField: r3 = r3->field_f
    //     0xc08118: ldur            w3, [x3, #0xf]
    // 0xc0811c: lsr             x3, x3, #4
    // 0xc08120: r17 = 5697
    //     0xc08120: mov             x17, #0x1641
    // 0xc08124: cmp             x3, x17
    // 0xc08128: b.eq            #0xc08178
    // 0xc0812c: r3 = SubtypeTestCache
    //     0xc0812c: add             x3, PP, #0x42, lsl #12  ; [pp+0x42610] SubtypeTestCache
    //     0xc08130: ldr             x3, [x3, #0x610]
    // 0xc08134: r24 = Subtype1TestCacheStub
    //     0xc08134: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc08138: LoadField: r30 = r24->field_7
    //     0xc08138: ldur            lr, [x24, #7]
    // 0xc0813c: blr             lr
    // 0xc08140: cmp             w7, NULL
    // 0xc08144: b.eq            #0xc08150
    // 0xc08148: tbnz            w7, #4, #0xc08170
    // 0xc0814c: b               #0xc08178
    // 0xc08150: r8 = List
    //     0xc08150: add             x8, PP, #0x42, lsl #12  ; [pp+0x42618] Type: List
    //     0xc08154: ldr             x8, [x8, #0x618]
    // 0xc08158: r3 = SubtypeTestCache
    //     0xc08158: add             x3, PP, #0x42, lsl #12  ; [pp+0x42620] SubtypeTestCache
    //     0xc0815c: ldr             x3, [x3, #0x620]
    // 0xc08160: r24 = InstanceOfStub
    //     0xc08160: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc08164: LoadField: r30 = r24->field_7
    //     0xc08164: ldur            lr, [x24, #7]
    // 0xc08168: blr             lr
    // 0xc0816c: b               #0xc0817c
    // 0xc08170: r0 = false
    //     0xc08170: add             x0, NULL, #0x30  ; false
    // 0xc08174: b               #0xc0817c
    // 0xc08178: r0 = true
    //     0xc08178: add             x0, NULL, #0x20  ; true
    // 0xc0817c: tbnz            w0, #4, #0xc08284
    // 0xc08180: ldr             x0, [fp, #0x10]
    // 0xc08184: r2 = Null
    //     0xc08184: mov             x2, NULL
    // 0xc08188: r1 = Null
    //     0xc08188: mov             x1, NULL
    // 0xc0818c: cmp             w0, NULL
    // 0xc08190: b.eq            #0xc08234
    // 0xc08194: branchIfSmi(r0, 0xc08234)
    //     0xc08194: tbz             w0, #0, #0xc08234
    // 0xc08198: r3 = LoadClassIdInstr(r0)
    //     0xc08198: ldur            x3, [x0, #-1]
    //     0xc0819c: ubfx            x3, x3, #0xc, #0x14
    // 0xc081a0: r17 = 5697
    //     0xc081a0: mov             x17, #0x1641
    // 0xc081a4: cmp             x3, x17
    // 0xc081a8: b.eq            #0xc0823c
    // 0xc081ac: sub             x3, x3, #0x59
    // 0xc081b0: cmp             x3, #2
    // 0xc081b4: b.ls            #0xc0823c
    // 0xc081b8: r4 = LoadClassIdInstr(r0)
    //     0xc081b8: ldur            x4, [x0, #-1]
    //     0xc081bc: ubfx            x4, x4, #0xc, #0x14
    // 0xc081c0: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc081c4: ldr             x3, [x3, #0x18]
    // 0xc081c8: ldr             x3, [x3, x4, lsl #3]
    // 0xc081cc: LoadField: r3 = r3->field_2b
    //     0xc081cc: ldur            w3, [x3, #0x2b]
    // 0xc081d0: DecompressPointer r3
    //     0xc081d0: add             x3, x3, HEAP, lsl #32
    // 0xc081d4: cmp             w3, NULL
    // 0xc081d8: b.eq            #0xc08234
    // 0xc081dc: LoadField: r3 = r3->field_f
    //     0xc081dc: ldur            w3, [x3, #0xf]
    // 0xc081e0: lsr             x3, x3, #4
    // 0xc081e4: r17 = 5697
    //     0xc081e4: mov             x17, #0x1641
    // 0xc081e8: cmp             x3, x17
    // 0xc081ec: b.eq            #0xc0823c
    // 0xc081f0: r3 = SubtypeTestCache
    //     0xc081f0: add             x3, PP, #0x42, lsl #12  ; [pp+0x42628] SubtypeTestCache
    //     0xc081f4: ldr             x3, [x3, #0x628]
    // 0xc081f8: r24 = Subtype1TestCacheStub
    //     0xc081f8: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc081fc: LoadField: r30 = r24->field_7
    //     0xc081fc: ldur            lr, [x24, #7]
    // 0xc08200: blr             lr
    // 0xc08204: cmp             w7, NULL
    // 0xc08208: b.eq            #0xc08214
    // 0xc0820c: tbnz            w7, #4, #0xc08234
    // 0xc08210: b               #0xc0823c
    // 0xc08214: r8 = List
    //     0xc08214: add             x8, PP, #0x42, lsl #12  ; [pp+0x42630] Type: List
    //     0xc08218: ldr             x8, [x8, #0x630]
    // 0xc0821c: r3 = SubtypeTestCache
    //     0xc0821c: add             x3, PP, #0x42, lsl #12  ; [pp+0x42638] SubtypeTestCache
    //     0xc08220: ldr             x3, [x3, #0x638]
    // 0xc08224: r24 = InstanceOfStub
    //     0xc08224: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc08228: LoadField: r30 = r24->field_7
    //     0xc08228: ldur            lr, [x24, #7]
    // 0xc0822c: blr             lr
    // 0xc08230: b               #0xc08240
    // 0xc08234: r0 = false
    //     0xc08234: add             x0, NULL, #0x30  ; false
    // 0xc08238: b               #0xc08240
    // 0xc0823c: r0 = true
    //     0xc0823c: add             x0, NULL, #0x20  ; true
    // 0xc08240: tbnz            w0, #4, #0xc08274
    // 0xc08244: ldr             x0, [fp, #0x20]
    // 0xc08248: r1 = Null
    //     0xc08248: mov             x1, NULL
    // 0xc0824c: r0 = ListEquality()
    //     0xc0824c: bl              #0xc057dc  ; AllocateListEqualityStub -> ListEquality<X0> (size=0x10)
    // 0xc08250: ldr             x3, [fp, #0x20]
    // 0xc08254: StoreField: r0->field_b = r3
    //     0xc08254: stur            w3, [x0, #0xb]
    // 0xc08258: ldr             x16, [fp, #0x18]
    // 0xc0825c: stp             x16, x0, [SP, #-0x10]!
    // 0xc08260: ldr             x16, [fp, #0x10]
    // 0xc08264: SaveReg r16
    //     0xc08264: str             x16, [SP, #-8]!
    // 0xc08268: r0 = equals()
    //     0xc08268: bl              #0xc06dd8  ; [package:collection/src/equality.dart] ListEquality::equals
    // 0xc0826c: add             SP, SP, #0x18
    // 0xc08270: b               #0xc08278
    // 0xc08274: r0 = false
    //     0xc08274: add             x0, NULL, #0x30  ; false
    // 0xc08278: LeaveFrame
    //     0xc08278: mov             SP, fp
    //     0xc0827c: ldp             fp, lr, [SP], #0x10
    // 0xc08280: ret
    //     0xc08280: ret             
    // 0xc08284: ldr             x3, [fp, #0x20]
    // 0xc08288: ldr             x0, [fp, #0x18]
    // 0xc0828c: r2 = Null
    //     0xc0828c: mov             x2, NULL
    // 0xc08290: r1 = Null
    //     0xc08290: mov             x1, NULL
    // 0xc08294: cmp             w0, NULL
    // 0xc08298: b.eq            #0xc08330
    // 0xc0829c: branchIfSmi(r0, 0xc08330)
    //     0xc0829c: tbz             w0, #0, #0xc08330
    // 0xc082a0: r3 = LoadClassIdInstr(r0)
    //     0xc082a0: ldur            x3, [x0, #-1]
    //     0xc082a4: ubfx            x3, x3, #0xc, #0x14
    // 0xc082a8: r17 = 6076
    //     0xc082a8: mov             x17, #0x17bc
    // 0xc082ac: cmp             x3, x17
    // 0xc082b0: b.eq            #0xc08338
    // 0xc082b4: r4 = LoadClassIdInstr(r0)
    //     0xc082b4: ldur            x4, [x0, #-1]
    //     0xc082b8: ubfx            x4, x4, #0xc, #0x14
    // 0xc082bc: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc082c0: ldr             x3, [x3, #0x18]
    // 0xc082c4: ldr             x3, [x3, x4, lsl #3]
    // 0xc082c8: LoadField: r3 = r3->field_2b
    //     0xc082c8: ldur            w3, [x3, #0x2b]
    // 0xc082cc: DecompressPointer r3
    //     0xc082cc: add             x3, x3, HEAP, lsl #32
    // 0xc082d0: cmp             w3, NULL
    // 0xc082d4: b.eq            #0xc08330
    // 0xc082d8: LoadField: r3 = r3->field_f
    //     0xc082d8: ldur            w3, [x3, #0xf]
    // 0xc082dc: lsr             x3, x3, #4
    // 0xc082e0: r17 = 6076
    //     0xc082e0: mov             x17, #0x17bc
    // 0xc082e4: cmp             x3, x17
    // 0xc082e8: b.eq            #0xc08338
    // 0xc082ec: r3 = SubtypeTestCache
    //     0xc082ec: add             x3, PP, #0x42, lsl #12  ; [pp+0x42640] SubtypeTestCache
    //     0xc082f0: ldr             x3, [x3, #0x640]
    // 0xc082f4: r24 = Subtype1TestCacheStub
    //     0xc082f4: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc082f8: LoadField: r30 = r24->field_7
    //     0xc082f8: ldur            lr, [x24, #7]
    // 0xc082fc: blr             lr
    // 0xc08300: cmp             w7, NULL
    // 0xc08304: b.eq            #0xc08310
    // 0xc08308: tbnz            w7, #4, #0xc08330
    // 0xc0830c: b               #0xc08338
    // 0xc08310: r8 = Iterable
    //     0xc08310: add             x8, PP, #0x42, lsl #12  ; [pp+0x42648] Type: Iterable
    //     0xc08314: ldr             x8, [x8, #0x648]
    // 0xc08318: r3 = SubtypeTestCache
    //     0xc08318: add             x3, PP, #0x42, lsl #12  ; [pp+0x42650] SubtypeTestCache
    //     0xc0831c: ldr             x3, [x3, #0x650]
    // 0xc08320: r24 = InstanceOfStub
    //     0xc08320: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc08324: LoadField: r30 = r24->field_7
    //     0xc08324: ldur            lr, [x24, #7]
    // 0xc08328: blr             lr
    // 0xc0832c: b               #0xc0833c
    // 0xc08330: r0 = false
    //     0xc08330: add             x0, NULL, #0x30  ; false
    // 0xc08334: b               #0xc0833c
    // 0xc08338: r0 = true
    //     0xc08338: add             x0, NULL, #0x20  ; true
    // 0xc0833c: tbnz            w0, #4, #0xc08450
    // 0xc08340: ldr             x0, [fp, #0x10]
    // 0xc08344: r2 = Null
    //     0xc08344: mov             x2, NULL
    // 0xc08348: r1 = Null
    //     0xc08348: mov             x1, NULL
    // 0xc0834c: cmp             w0, NULL
    // 0xc08350: b.eq            #0xc083e8
    // 0xc08354: branchIfSmi(r0, 0xc083e8)
    //     0xc08354: tbz             w0, #0, #0xc083e8
    // 0xc08358: r3 = LoadClassIdInstr(r0)
    //     0xc08358: ldur            x3, [x0, #-1]
    //     0xc0835c: ubfx            x3, x3, #0xc, #0x14
    // 0xc08360: r17 = 6076
    //     0xc08360: mov             x17, #0x17bc
    // 0xc08364: cmp             x3, x17
    // 0xc08368: b.eq            #0xc083f0
    // 0xc0836c: r4 = LoadClassIdInstr(r0)
    //     0xc0836c: ldur            x4, [x0, #-1]
    //     0xc08370: ubfx            x4, x4, #0xc, #0x14
    // 0xc08374: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xc08378: ldr             x3, [x3, #0x18]
    // 0xc0837c: ldr             x3, [x3, x4, lsl #3]
    // 0xc08380: LoadField: r3 = r3->field_2b
    //     0xc08380: ldur            w3, [x3, #0x2b]
    // 0xc08384: DecompressPointer r3
    //     0xc08384: add             x3, x3, HEAP, lsl #32
    // 0xc08388: cmp             w3, NULL
    // 0xc0838c: b.eq            #0xc083e8
    // 0xc08390: LoadField: r3 = r3->field_f
    //     0xc08390: ldur            w3, [x3, #0xf]
    // 0xc08394: lsr             x3, x3, #4
    // 0xc08398: r17 = 6076
    //     0xc08398: mov             x17, #0x17bc
    // 0xc0839c: cmp             x3, x17
    // 0xc083a0: b.eq            #0xc083f0
    // 0xc083a4: r3 = SubtypeTestCache
    //     0xc083a4: add             x3, PP, #0x42, lsl #12  ; [pp+0x42658] SubtypeTestCache
    //     0xc083a8: ldr             x3, [x3, #0x658]
    // 0xc083ac: r24 = Subtype1TestCacheStub
    //     0xc083ac: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xc083b0: LoadField: r30 = r24->field_7
    //     0xc083b0: ldur            lr, [x24, #7]
    // 0xc083b4: blr             lr
    // 0xc083b8: cmp             w7, NULL
    // 0xc083bc: b.eq            #0xc083c8
    // 0xc083c0: tbnz            w7, #4, #0xc083e8
    // 0xc083c4: b               #0xc083f0
    // 0xc083c8: r8 = Iterable
    //     0xc083c8: add             x8, PP, #0x42, lsl #12  ; [pp+0x42660] Type: Iterable
    //     0xc083cc: ldr             x8, [x8, #0x660]
    // 0xc083d0: r3 = SubtypeTestCache
    //     0xc083d0: add             x3, PP, #0x42, lsl #12  ; [pp+0x42668] SubtypeTestCache
    //     0xc083d4: ldr             x3, [x3, #0x668]
    // 0xc083d8: r24 = InstanceOfStub
    //     0xc083d8: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc083dc: LoadField: r30 = r24->field_7
    //     0xc083dc: ldur            lr, [x24, #7]
    // 0xc083e0: blr             lr
    // 0xc083e4: b               #0xc083f4
    // 0xc083e8: r0 = false
    //     0xc083e8: add             x0, NULL, #0x30  ; false
    // 0xc083ec: b               #0xc083f4
    // 0xc083f0: r0 = true
    //     0xc083f0: add             x0, NULL, #0x20  ; true
    // 0xc083f4: tbnz            w0, #4, #0xc08440
    // 0xc083f8: ldr             x0, [fp, #0x20]
    // 0xc083fc: r1 = Null
    //     0xc083fc: mov             x1, NULL
    // 0xc08400: r0 = IterableEquality()
    //     0xc08400: bl              #0xc057d0  ; AllocateIterableEqualityStub -> IterableEquality<X0> (size=0x10)
    // 0xc08404: mov             x1, x0
    // 0xc08408: ldr             x0, [fp, #0x20]
    // 0xc0840c: StoreField: r1->field_b = r0
    //     0xc0840c: stur            w0, [x1, #0xb]
    // 0xc08410: ldr             x16, [fp, #0x18]
    // 0xc08414: stp             x16, x1, [SP, #-0x10]!
    // 0xc08418: ldr             x16, [fp, #0x10]
    // 0xc0841c: SaveReg r16
    //     0xc0841c: str             x16, [SP, #-8]!
    // 0xc08420: r0 = equals()
    //     0xc08420: bl              #0xc06bc4  ; [package:collection/src/equality.dart] IterableEquality::equals
    // 0xc08424: add             SP, SP, #0x18
    // 0xc08428: mov             x1, x0
    // 0xc0842c: stur            x1, [fp, #-8]
    // 0xc08430: tbnz            w0, #5, #0xc08438
    // 0xc08434: r0 = AssertBoolean()
    //     0xc08434: bl              #0xd67df0  ; AssertBooleanStub
    // 0xc08438: ldur            x0, [fp, #-8]
    // 0xc0843c: b               #0xc08444
    // 0xc08440: r0 = false
    //     0xc08440: add             x0, NULL, #0x30  ; false
    // 0xc08444: LeaveFrame
    //     0xc08444: mov             SP, fp
    //     0xc08448: ldp             fp, lr, [SP], #0x10
    // 0xc0844c: ret
    //     0xc0844c: ret             
    // 0xc08450: r16 = Instance_DefaultEquality
    //     0xc08450: add             x16, PP, #0x42, lsl #12  ; [pp+0x42670] Obj!DefaultEquality<Never>@b5c801
    //     0xc08454: ldr             x16, [x16, #0x670]
    // 0xc08458: ldr             lr, [fp, #0x18]
    // 0xc0845c: stp             lr, x16, [SP, #-0x10]!
    // 0xc08460: ldr             x16, [fp, #0x10]
    // 0xc08464: SaveReg r16
    //     0xc08464: str             x16, [SP, #-8]!
    // 0xc08468: r0 = _objectEquals()
    //     0xc08468: bl              #0xc06b6c  ; [dart:core] ::_objectEquals
    // 0xc0846c: add             SP, SP, #0x18
    // 0xc08470: LeaveFrame
    //     0xc08470: mov             SP, fp
    //     0xc08474: ldp             fp, lr, [SP], #0x10
    // 0xc08478: ret
    //     0xc08478: ret             
    // 0xc0847c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0847c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc08480: b               #0xc07d4c
  }
}

// class id: 4774, size: 0x14, field offset: 0x8
//   const constructor, 
class MapEquality<X0, X1> extends Object
    implements Equality<X0> {

  _ hash(/* No info */) {
    // ** addr: 0xc04f28, size: 0x1fc
    // 0xc04f28: EnterFrame
    //     0xc04f28: stp             fp, lr, [SP, #-0x10]!
    //     0xc04f2c: mov             fp, SP
    // 0xc04f30: AllocStack(0x30)
    //     0xc04f30: sub             SP, SP, #0x30
    // 0xc04f34: CheckStackOverflow
    //     0xc04f34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc04f38: cmp             SP, x16
    //     0xc04f3c: b.ls            #0xc05114
    // 0xc04f40: ldr             x3, [fp, #0x18]
    // 0xc04f44: LoadField: r2 = r3->field_7
    //     0xc04f44: ldur            w2, [x3, #7]
    // 0xc04f48: DecompressPointer r2
    //     0xc04f48: add             x2, x2, HEAP, lsl #32
    // 0xc04f4c: ldr             x0, [fp, #0x10]
    // 0xc04f50: r1 = Null
    //     0xc04f50: mov             x1, NULL
    // 0xc04f54: r8 = Map<X0, X1>?
    //     0xc04f54: add             x8, PP, #0x42, lsl #12  ; [pp+0x42698] Type: Map<X0, X1>?
    //     0xc04f58: ldr             x8, [x8, #0x698]
    // 0xc04f5c: LoadField: r9 = r8->field_7
    //     0xc04f5c: ldur            x9, [x8, #7]
    // 0xc04f60: r3 = Null
    //     0xc04f60: add             x3, PP, #0x42, lsl #12  ; [pp+0x427f0] Null
    //     0xc04f64: ldr             x3, [x3, #0x7f0]
    // 0xc04f68: blr             x9
    // 0xc04f6c: ldr             x1, [fp, #0x10]
    // 0xc04f70: r0 = LoadClassIdInstr(r1)
    //     0xc04f70: ldur            x0, [x1, #-1]
    //     0xc04f74: ubfx            x0, x0, #0xc, #0x14
    // 0xc04f78: SaveReg r1
    //     0xc04f78: str             x1, [SP, #-8]!
    // 0xc04f7c: r0 = GDT[cid_x0 + 0x6d7]()
    //     0xc04f7c: add             lr, x0, #0x6d7
    //     0xc04f80: ldr             lr, [x21, lr, lsl #3]
    //     0xc04f84: blr             lr
    // 0xc04f88: add             SP, SP, #8
    // 0xc04f8c: r1 = LoadClassIdInstr(r0)
    //     0xc04f8c: ldur            x1, [x0, #-1]
    //     0xc04f90: ubfx            x1, x1, #0xc, #0x14
    // 0xc04f94: SaveReg r0
    //     0xc04f94: str             x0, [SP, #-8]!
    // 0xc04f98: mov             x0, x1
    // 0xc04f9c: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc04f9c: mov             x17, #0xb940
    //     0xc04fa0: add             lr, x0, x17
    //     0xc04fa4: ldr             lr, [x21, lr, lsl #3]
    //     0xc04fa8: blr             lr
    // 0xc04fac: add             SP, SP, #8
    // 0xc04fb0: mov             x1, x0
    // 0xc04fb4: ldr             x0, [fp, #0x18]
    // 0xc04fb8: stur            x1, [fp, #-0x20]
    // 0xc04fbc: LoadField: r2 = r0->field_b
    //     0xc04fbc: ldur            w2, [x0, #0xb]
    // 0xc04fc0: DecompressPointer r2
    //     0xc04fc0: add             x2, x2, HEAP, lsl #32
    // 0xc04fc4: stur            x2, [fp, #-0x18]
    // 0xc04fc8: LoadField: r3 = r0->field_f
    //     0xc04fc8: ldur            w3, [x0, #0xf]
    // 0xc04fcc: DecompressPointer r3
    //     0xc04fcc: add             x3, x3, HEAP, lsl #32
    // 0xc04fd0: stur            x3, [fp, #-0x10]
    // 0xc04fd4: r5 = 0
    //     0xc04fd4: mov             x5, #0
    // 0xc04fd8: ldr             x4, [fp, #0x10]
    // 0xc04fdc: stur            x5, [fp, #-8]
    // 0xc04fe0: CheckStackOverflow
    //     0xc04fe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc04fe4: cmp             SP, x16
    //     0xc04fe8: b.ls            #0xc0511c
    // 0xc04fec: r0 = LoadClassIdInstr(r1)
    //     0xc04fec: ldur            x0, [x1, #-1]
    //     0xc04ff0: ubfx            x0, x0, #0xc, #0x14
    // 0xc04ff4: SaveReg r1
    //     0xc04ff4: str             x1, [SP, #-8]!
    // 0xc04ff8: r0 = GDT[cid_x0 + 0x541]()
    //     0xc04ff8: add             lr, x0, #0x541
    //     0xc04ffc: ldr             lr, [x21, lr, lsl #3]
    //     0xc05000: blr             lr
    // 0xc05004: add             SP, SP, #8
    // 0xc05008: tbnz            w0, #4, #0xc050cc
    // 0xc0500c: ldr             x2, [fp, #0x10]
    // 0xc05010: ldur            x1, [fp, #-0x20]
    // 0xc05014: r0 = LoadClassIdInstr(r1)
    //     0xc05014: ldur            x0, [x1, #-1]
    //     0xc05018: ubfx            x0, x0, #0xc, #0x14
    // 0xc0501c: SaveReg r1
    //     0xc0501c: str             x1, [SP, #-8]!
    // 0xc05020: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc05020: add             lr, x0, #0x5ca
    //     0xc05024: ldr             lr, [x21, lr, lsl #3]
    //     0xc05028: blr             lr
    // 0xc0502c: add             SP, SP, #8
    // 0xc05030: stur            x0, [fp, #-0x28]
    // 0xc05034: ldur            x16, [fp, #-0x18]
    // 0xc05038: stp             x0, x16, [SP, #-0x10]!
    // 0xc0503c: r0 = hash()
    //     0xc0503c: bl              #0xc05368  ; [package:collection/src/equality.dart] DeepCollectionEquality::hash
    // 0xc05040: add             SP, SP, #0x10
    // 0xc05044: mov             x2, x0
    // 0xc05048: ldr             x1, [fp, #0x10]
    // 0xc0504c: stur            x2, [fp, #-0x30]
    // 0xc05050: r0 = LoadClassIdInstr(r1)
    //     0xc05050: ldur            x0, [x1, #-1]
    //     0xc05054: ubfx            x0, x0, #0xc, #0x14
    // 0xc05058: ldur            x16, [fp, #-0x28]
    // 0xc0505c: stp             x16, x1, [SP, #-0x10]!
    // 0xc05060: r0 = GDT[cid_x0 + -0xef]()
    //     0xc05060: sub             lr, x0, #0xef
    //     0xc05064: ldr             lr, [x21, lr, lsl #3]
    //     0xc05068: blr             lr
    // 0xc0506c: add             SP, SP, #0x10
    // 0xc05070: ldur            x16, [fp, #-0x10]
    // 0xc05074: stp             x0, x16, [SP, #-0x10]!
    // 0xc05078: r0 = hash()
    //     0xc05078: bl              #0xc05368  ; [package:collection/src/equality.dart] DeepCollectionEquality::hash
    // 0xc0507c: add             SP, SP, #0x10
    // 0xc05080: ldur            x1, [fp, #-0x30]
    // 0xc05084: ubfx            x1, x1, #0, #0x20
    // 0xc05088: r2 = 3
    //     0xc05088: mov             x2, #3
    // 0xc0508c: mul             x3, x1, x2
    // 0xc05090: ldur            x1, [fp, #-8]
    // 0xc05094: ubfx            x1, x1, #0, #0x20
    // 0xc05098: add             w4, w1, w3
    // 0xc0509c: ubfx            x0, x0, #0, #0x20
    // 0xc050a0: r1 = 7
    //     0xc050a0: mov             x1, #7
    // 0xc050a4: mul             x3, x0, x1
    // 0xc050a8: add             w5, w4, w3
    // 0xc050ac: r3 = 2147483647
    //     0xc050ac: mov             x3, #0x7fffffff
    // 0xc050b0: and             x4, x5, x3
    // 0xc050b4: ubfx            x4, x4, #0, #0x20
    // 0xc050b8: mov             x5, x4
    // 0xc050bc: ldur            x1, [fp, #-0x20]
    // 0xc050c0: ldur            x2, [fp, #-0x18]
    // 0xc050c4: ldur            x3, [fp, #-0x10]
    // 0xc050c8: b               #0xc04fd8
    // 0xc050cc: r3 = 2147483647
    //     0xc050cc: mov             x3, #0x7fffffff
    // 0xc050d0: ldur            x1, [fp, #-8]
    // 0xc050d4: ubfx            x1, x1, #0, #0x20
    // 0xc050d8: lsl             w2, w1, #3
    // 0xc050dc: ldur            x1, [fp, #-8]
    // 0xc050e0: ubfx            x1, x1, #0, #0x20
    // 0xc050e4: add             w4, w1, w2
    // 0xc050e8: and             x1, x4, x3
    // 0xc050ec: lsr             w2, w1, #0xb
    // 0xc050f0: eor             x4, x1, x2
    // 0xc050f4: lsl             w1, w4, #0xf
    // 0xc050f8: add             w2, w4, w1
    // 0xc050fc: and             x1, x2, x3
    // 0xc05100: ubfx            x1, x1, #0, #0x20
    // 0xc05104: mov             x0, x1
    // 0xc05108: LeaveFrame
    //     0xc05108: mov             SP, fp
    //     0xc0510c: ldp             fp, lr, [SP], #0x10
    // 0xc05110: ret
    //     0xc05110: ret             
    // 0xc05114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05114: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05118: b               #0xc04f40
    // 0xc0511c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0511c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05120: b               #0xc04fec
  }
  _ equals(/* No info */) {
    // ** addr: 0xc077e0, size: 0x440
    // 0xc077e0: EnterFrame
    //     0xc077e0: stp             fp, lr, [SP, #-0x10]!
    //     0xc077e4: mov             fp, SP
    // 0xc077e8: AllocStack(0x28)
    //     0xc077e8: sub             SP, SP, #0x28
    // 0xc077ec: CheckStackOverflow
    //     0xc077ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc077f0: cmp             SP, x16
    //     0xc077f4: b.ls            #0xc07c08
    // 0xc077f8: ldr             x3, [fp, #0x20]
    // 0xc077fc: LoadField: r4 = r3->field_7
    //     0xc077fc: ldur            w4, [x3, #7]
    // 0xc07800: DecompressPointer r4
    //     0xc07800: add             x4, x4, HEAP, lsl #32
    // 0xc07804: ldr             x0, [fp, #0x18]
    // 0xc07808: mov             x2, x4
    // 0xc0780c: stur            x4, [fp, #-8]
    // 0xc07810: r1 = Null
    //     0xc07810: mov             x1, NULL
    // 0xc07814: r8 = Map<X0, X1>?
    //     0xc07814: add             x8, PP, #0x42, lsl #12  ; [pp+0x42698] Type: Map<X0, X1>?
    //     0xc07818: ldr             x8, [x8, #0x698]
    // 0xc0781c: LoadField: r9 = r8->field_7
    //     0xc0781c: ldur            x9, [x8, #7]
    // 0xc07820: r3 = Null
    //     0xc07820: add             x3, PP, #0x42, lsl #12  ; [pp+0x426a0] Null
    //     0xc07824: ldr             x3, [x3, #0x6a0]
    // 0xc07828: blr             x9
    // 0xc0782c: ldr             x0, [fp, #0x10]
    // 0xc07830: ldur            x2, [fp, #-8]
    // 0xc07834: r1 = Null
    //     0xc07834: mov             x1, NULL
    // 0xc07838: r8 = Map<X0, X1>?
    //     0xc07838: add             x8, PP, #0x42, lsl #12  ; [pp+0x42698] Type: Map<X0, X1>?
    //     0xc0783c: ldr             x8, [x8, #0x698]
    // 0xc07840: LoadField: r9 = r8->field_7
    //     0xc07840: ldur            x9, [x8, #7]
    // 0xc07844: r3 = Null
    //     0xc07844: add             x3, PP, #0x42, lsl #12  ; [pp+0x426b0] Null
    //     0xc07848: ldr             x3, [x3, #0x6b0]
    // 0xc0784c: blr             x9
    // 0xc07850: ldr             x2, [fp, #0x18]
    // 0xc07854: ldr             x1, [fp, #0x10]
    // 0xc07858: cmp             w2, w1
    // 0xc0785c: b.ne            #0xc07870
    // 0xc07860: r0 = true
    //     0xc07860: add             x0, NULL, #0x20  ; true
    // 0xc07864: LeaveFrame
    //     0xc07864: mov             SP, fp
    //     0xc07868: ldp             fp, lr, [SP], #0x10
    // 0xc0786c: ret
    //     0xc0786c: ret             
    // 0xc07870: r0 = LoadClassIdInstr(r2)
    //     0xc07870: ldur            x0, [x2, #-1]
    //     0xc07874: ubfx            x0, x0, #0xc, #0x14
    // 0xc07878: SaveReg r2
    //     0xc07878: str             x2, [SP, #-8]!
    // 0xc0787c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc0787c: mov             x17, #0xb8ea
    //     0xc07880: add             lr, x0, x17
    //     0xc07884: ldr             lr, [x21, lr, lsl #3]
    //     0xc07888: blr             lr
    // 0xc0788c: add             SP, SP, #8
    // 0xc07890: mov             x2, x0
    // 0xc07894: ldr             x1, [fp, #0x10]
    // 0xc07898: stur            x2, [fp, #-8]
    // 0xc0789c: r0 = LoadClassIdInstr(r1)
    //     0xc0789c: ldur            x0, [x1, #-1]
    //     0xc078a0: ubfx            x0, x0, #0xc, #0x14
    // 0xc078a4: SaveReg r1
    //     0xc078a4: str             x1, [SP, #-8]!
    // 0xc078a8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc078a8: mov             x17, #0xb8ea
    //     0xc078ac: add             lr, x0, x17
    //     0xc078b0: ldr             lr, [x21, lr, lsl #3]
    //     0xc078b4: blr             lr
    // 0xc078b8: add             SP, SP, #8
    // 0xc078bc: mov             x1, x0
    // 0xc078c0: ldur            x0, [fp, #-8]
    // 0xc078c4: r2 = LoadInt32Instr(r0)
    //     0xc078c4: sbfx            x2, x0, #1, #0x1f
    //     0xc078c8: tbz             w0, #0, #0xc078d0
    //     0xc078cc: ldur            x2, [x0, #7]
    // 0xc078d0: r0 = LoadInt32Instr(r1)
    //     0xc078d0: sbfx            x0, x1, #1, #0x1f
    //     0xc078d4: tbz             w1, #0, #0xc078dc
    //     0xc078d8: ldur            x0, [x1, #7]
    // 0xc078dc: cmp             x2, x0
    // 0xc078e0: b.eq            #0xc078f4
    // 0xc078e4: r0 = false
    //     0xc078e4: add             x0, NULL, #0x30  ; false
    // 0xc078e8: LeaveFrame
    //     0xc078e8: mov             SP, fp
    //     0xc078ec: ldp             fp, lr, [SP], #0x10
    // 0xc078f0: ret
    //     0xc078f0: ret             
    // 0xc078f4: ldr             x0, [fp, #0x18]
    // 0xc078f8: r1 = <_MapEntry, int>
    //     0xc078f8: add             x1, PP, #0x42, lsl #12  ; [pp+0x426c0] TypeArguments: <_MapEntry, int>
    //     0xc078fc: ldr             x1, [x1, #0x6c0]
    // 0xc07900: r0 = _HashMap()
    //     0xc07900: bl              #0x4d9d7c  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0xc07904: mov             x3, x0
    // 0xc07908: r0 = 0
    //     0xc07908: mov             x0, #0
    // 0xc0790c: stur            x3, [fp, #-8]
    // 0xc07910: StoreField: r3->field_b = r0
    //     0xc07910: stur            x0, [x3, #0xb]
    // 0xc07914: StoreField: r3->field_17 = r0
    //     0xc07914: stur            x0, [x3, #0x17]
    // 0xc07918: r1 = <_HashMapEntry<_MapEntry, int>?>
    //     0xc07918: add             x1, PP, #0x42, lsl #12  ; [pp+0x426c8] TypeArguments: <_HashMapEntry<_MapEntry, int>?>
    //     0xc0791c: ldr             x1, [x1, #0x6c8]
    // 0xc07920: r2 = 16
    //     0xc07920: mov             x2, #0x10
    // 0xc07924: r0 = AllocateArray()
    //     0xc07924: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc07928: ldur            x1, [fp, #-8]
    // 0xc0792c: StoreField: r1->field_13 = r0
    //     0xc0792c: stur            w0, [x1, #0x13]
    // 0xc07930: ldr             x2, [fp, #0x18]
    // 0xc07934: r0 = LoadClassIdInstr(r2)
    //     0xc07934: ldur            x0, [x2, #-1]
    //     0xc07938: ubfx            x0, x0, #0xc, #0x14
    // 0xc0793c: SaveReg r2
    //     0xc0793c: str             x2, [SP, #-8]!
    // 0xc07940: r0 = GDT[cid_x0 + 0x6d7]()
    //     0xc07940: add             lr, x0, #0x6d7
    //     0xc07944: ldr             lr, [x21, lr, lsl #3]
    //     0xc07948: blr             lr
    // 0xc0794c: add             SP, SP, #8
    // 0xc07950: r1 = LoadClassIdInstr(r0)
    //     0xc07950: ldur            x1, [x0, #-1]
    //     0xc07954: ubfx            x1, x1, #0xc, #0x14
    // 0xc07958: SaveReg r0
    //     0xc07958: str             x0, [SP, #-8]!
    // 0xc0795c: mov             x0, x1
    // 0xc07960: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc07960: mov             x17, #0xb940
    //     0xc07964: add             lr, x0, x17
    //     0xc07968: ldr             lr, [x21, lr, lsl #3]
    //     0xc0796c: blr             lr
    // 0xc07970: add             SP, SP, #8
    // 0xc07974: mov             x1, x0
    // 0xc07978: stur            x1, [fp, #-0x10]
    // 0xc0797c: ldr             x3, [fp, #0x20]
    // 0xc07980: ldr             x2, [fp, #0x18]
    // 0xc07984: CheckStackOverflow
    //     0xc07984: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc07988: cmp             SP, x16
    //     0xc0798c: b.ls            #0xc07c10
    // 0xc07990: r0 = LoadClassIdInstr(r1)
    //     0xc07990: ldur            x0, [x1, #-1]
    //     0xc07994: ubfx            x0, x0, #0xc, #0x14
    // 0xc07998: SaveReg r1
    //     0xc07998: str             x1, [SP, #-8]!
    // 0xc0799c: r0 = GDT[cid_x0 + 0x541]()
    //     0xc0799c: add             lr, x0, #0x541
    //     0xc079a0: ldr             lr, [x21, lr, lsl #3]
    //     0xc079a4: blr             lr
    // 0xc079a8: add             SP, SP, #8
    // 0xc079ac: tbnz            w0, #4, #0xc07a90
    // 0xc079b0: ldr             x3, [fp, #0x20]
    // 0xc079b4: ldr             x2, [fp, #0x18]
    // 0xc079b8: ldur            x1, [fp, #-0x10]
    // 0xc079bc: r0 = LoadClassIdInstr(r1)
    //     0xc079bc: ldur            x0, [x1, #-1]
    //     0xc079c0: ubfx            x0, x0, #0xc, #0x14
    // 0xc079c4: SaveReg r1
    //     0xc079c4: str             x1, [SP, #-8]!
    // 0xc079c8: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc079c8: add             lr, x0, #0x5ca
    //     0xc079cc: ldr             lr, [x21, lr, lsl #3]
    //     0xc079d0: blr             lr
    // 0xc079d4: add             SP, SP, #8
    // 0xc079d8: mov             x2, x0
    // 0xc079dc: ldr             x1, [fp, #0x18]
    // 0xc079e0: stur            x2, [fp, #-0x18]
    // 0xc079e4: r0 = LoadClassIdInstr(r1)
    //     0xc079e4: ldur            x0, [x1, #-1]
    //     0xc079e8: ubfx            x0, x0, #0xc, #0x14
    // 0xc079ec: stp             x2, x1, [SP, #-0x10]!
    // 0xc079f0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc079f0: sub             lr, x0, #0xef
    //     0xc079f4: ldr             lr, [x21, lr, lsl #3]
    //     0xc079f8: blr             lr
    // 0xc079fc: add             SP, SP, #0x10
    // 0xc07a00: stur            x0, [fp, #-0x20]
    // 0xc07a04: r0 = _MapEntry()
    //     0xc07a04: bl              #0xc07c20  ; Allocate_MapEntryStub -> _MapEntry (size=0x14)
    // 0xc07a08: mov             x1, x0
    // 0xc07a0c: ldr             x0, [fp, #0x20]
    // 0xc07a10: stur            x1, [fp, #-0x28]
    // 0xc07a14: StoreField: r1->field_7 = r0
    //     0xc07a14: stur            w0, [x1, #7]
    // 0xc07a18: ldur            x2, [fp, #-0x18]
    // 0xc07a1c: StoreField: r1->field_b = r2
    //     0xc07a1c: stur            w2, [x1, #0xb]
    // 0xc07a20: ldur            x2, [fp, #-0x20]
    // 0xc07a24: StoreField: r1->field_f = r2
    //     0xc07a24: stur            w2, [x1, #0xf]
    // 0xc07a28: ldur            x16, [fp, #-8]
    // 0xc07a2c: stp             x1, x16, [SP, #-0x10]!
    // 0xc07a30: r0 = []()
    //     0xc07a30: bl              #0xc63c90  ; [dart:collection] _HashMap::[]
    // 0xc07a34: add             SP, SP, #0x10
    // 0xc07a38: cmp             w0, NULL
    // 0xc07a3c: b.ne            #0xc07a48
    // 0xc07a40: r0 = 0
    //     0xc07a40: mov             x0, #0
    // 0xc07a44: b               #0xc07a58
    // 0xc07a48: r1 = LoadInt32Instr(r0)
    //     0xc07a48: sbfx            x1, x0, #1, #0x1f
    //     0xc07a4c: tbz             w0, #0, #0xc07a54
    //     0xc07a50: ldur            x1, [x0, #7]
    // 0xc07a54: mov             x0, x1
    // 0xc07a58: add             x2, x0, #1
    // 0xc07a5c: r0 = BoxInt64Instr(r2)
    //     0xc07a5c: sbfiz           x0, x2, #1, #0x1f
    //     0xc07a60: cmp             x2, x0, asr #1
    //     0xc07a64: b.eq            #0xc07a70
    //     0xc07a68: bl              #0xd69bb8
    //     0xc07a6c: stur            x2, [x0, #7]
    // 0xc07a70: ldur            x16, [fp, #-8]
    // 0xc07a74: ldur            lr, [fp, #-0x28]
    // 0xc07a78: stp             lr, x16, [SP, #-0x10]!
    // 0xc07a7c: SaveReg r0
    //     0xc07a7c: str             x0, [SP, #-8]!
    // 0xc07a80: r0 = []=()
    //     0xc07a80: bl              #0xc53e5c  ; [dart:collection] _HashMap::[]=
    // 0xc07a84: add             SP, SP, #0x18
    // 0xc07a88: ldur            x1, [fp, #-0x10]
    // 0xc07a8c: b               #0xc0797c
    // 0xc07a90: ldr             x1, [fp, #0x10]
    // 0xc07a94: r0 = LoadClassIdInstr(r1)
    //     0xc07a94: ldur            x0, [x1, #-1]
    //     0xc07a98: ubfx            x0, x0, #0xc, #0x14
    // 0xc07a9c: SaveReg r1
    //     0xc07a9c: str             x1, [SP, #-8]!
    // 0xc07aa0: r0 = GDT[cid_x0 + 0x6d7]()
    //     0xc07aa0: add             lr, x0, #0x6d7
    //     0xc07aa4: ldr             lr, [x21, lr, lsl #3]
    //     0xc07aa8: blr             lr
    // 0xc07aac: add             SP, SP, #8
    // 0xc07ab0: r1 = LoadClassIdInstr(r0)
    //     0xc07ab0: ldur            x1, [x0, #-1]
    //     0xc07ab4: ubfx            x1, x1, #0xc, #0x14
    // 0xc07ab8: SaveReg r0
    //     0xc07ab8: str             x0, [SP, #-8]!
    // 0xc07abc: mov             x0, x1
    // 0xc07ac0: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc07ac0: mov             x17, #0xb940
    //     0xc07ac4: add             lr, x0, x17
    //     0xc07ac8: ldr             lr, [x21, lr, lsl #3]
    //     0xc07acc: blr             lr
    // 0xc07ad0: add             SP, SP, #8
    // 0xc07ad4: mov             x1, x0
    // 0xc07ad8: stur            x1, [fp, #-0x10]
    // 0xc07adc: ldr             x3, [fp, #0x20]
    // 0xc07ae0: ldr             x2, [fp, #0x10]
    // 0xc07ae4: CheckStackOverflow
    //     0xc07ae4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc07ae8: cmp             SP, x16
    //     0xc07aec: b.ls            #0xc07c18
    // 0xc07af0: r0 = LoadClassIdInstr(r1)
    //     0xc07af0: ldur            x0, [x1, #-1]
    //     0xc07af4: ubfx            x0, x0, #0xc, #0x14
    // 0xc07af8: SaveReg r1
    //     0xc07af8: str             x1, [SP, #-8]!
    // 0xc07afc: r0 = GDT[cid_x0 + 0x541]()
    //     0xc07afc: add             lr, x0, #0x541
    //     0xc07b00: ldr             lr, [x21, lr, lsl #3]
    //     0xc07b04: blr             lr
    // 0xc07b08: add             SP, SP, #8
    // 0xc07b0c: tbnz            w0, #4, #0xc07bf8
    // 0xc07b10: ldr             x3, [fp, #0x20]
    // 0xc07b14: ldr             x2, [fp, #0x10]
    // 0xc07b18: ldur            x1, [fp, #-0x10]
    // 0xc07b1c: r0 = LoadClassIdInstr(r1)
    //     0xc07b1c: ldur            x0, [x1, #-1]
    //     0xc07b20: ubfx            x0, x0, #0xc, #0x14
    // 0xc07b24: SaveReg r1
    //     0xc07b24: str             x1, [SP, #-8]!
    // 0xc07b28: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc07b28: add             lr, x0, #0x5ca
    //     0xc07b2c: ldr             lr, [x21, lr, lsl #3]
    //     0xc07b30: blr             lr
    // 0xc07b34: add             SP, SP, #8
    // 0xc07b38: mov             x2, x0
    // 0xc07b3c: ldr             x1, [fp, #0x10]
    // 0xc07b40: stur            x2, [fp, #-0x18]
    // 0xc07b44: r0 = LoadClassIdInstr(r1)
    //     0xc07b44: ldur            x0, [x1, #-1]
    //     0xc07b48: ubfx            x0, x0, #0xc, #0x14
    // 0xc07b4c: stp             x2, x1, [SP, #-0x10]!
    // 0xc07b50: r0 = GDT[cid_x0 + -0xef]()
    //     0xc07b50: sub             lr, x0, #0xef
    //     0xc07b54: ldr             lr, [x21, lr, lsl #3]
    //     0xc07b58: blr             lr
    // 0xc07b5c: add             SP, SP, #0x10
    // 0xc07b60: stur            x0, [fp, #-0x20]
    // 0xc07b64: r0 = _MapEntry()
    //     0xc07b64: bl              #0xc07c20  ; Allocate_MapEntryStub -> _MapEntry (size=0x14)
    // 0xc07b68: mov             x1, x0
    // 0xc07b6c: ldr             x0, [fp, #0x20]
    // 0xc07b70: stur            x1, [fp, #-0x28]
    // 0xc07b74: StoreField: r1->field_7 = r0
    //     0xc07b74: stur            w0, [x1, #7]
    // 0xc07b78: ldur            x2, [fp, #-0x18]
    // 0xc07b7c: StoreField: r1->field_b = r2
    //     0xc07b7c: stur            w2, [x1, #0xb]
    // 0xc07b80: ldur            x2, [fp, #-0x20]
    // 0xc07b84: StoreField: r1->field_f = r2
    //     0xc07b84: stur            w2, [x1, #0xf]
    // 0xc07b88: ldur            x16, [fp, #-8]
    // 0xc07b8c: stp             x1, x16, [SP, #-0x10]!
    // 0xc07b90: r0 = []()
    //     0xc07b90: bl              #0xc63c90  ; [dart:collection] _HashMap::[]
    // 0xc07b94: add             SP, SP, #0x10
    // 0xc07b98: cmp             w0, NULL
    // 0xc07b9c: b.eq            #0xc07ba4
    // 0xc07ba0: cbnz            w0, #0xc07bb4
    // 0xc07ba4: r0 = false
    //     0xc07ba4: add             x0, NULL, #0x30  ; false
    // 0xc07ba8: LeaveFrame
    //     0xc07ba8: mov             SP, fp
    //     0xc07bac: ldp             fp, lr, [SP], #0x10
    // 0xc07bb0: ret
    //     0xc07bb0: ret             
    // 0xc07bb4: r1 = LoadInt32Instr(r0)
    //     0xc07bb4: sbfx            x1, x0, #1, #0x1f
    //     0xc07bb8: tbz             w0, #0, #0xc07bc0
    //     0xc07bbc: ldur            x1, [x0, #7]
    // 0xc07bc0: sub             x2, x1, #1
    // 0xc07bc4: r0 = BoxInt64Instr(r2)
    //     0xc07bc4: sbfiz           x0, x2, #1, #0x1f
    //     0xc07bc8: cmp             x2, x0, asr #1
    //     0xc07bcc: b.eq            #0xc07bd8
    //     0xc07bd0: bl              #0xd69bb8
    //     0xc07bd4: stur            x2, [x0, #7]
    // 0xc07bd8: ldur            x16, [fp, #-8]
    // 0xc07bdc: ldur            lr, [fp, #-0x28]
    // 0xc07be0: stp             lr, x16, [SP, #-0x10]!
    // 0xc07be4: SaveReg r0
    //     0xc07be4: str             x0, [SP, #-8]!
    // 0xc07be8: r0 = []=()
    //     0xc07be8: bl              #0xc53e5c  ; [dart:collection] _HashMap::[]=
    // 0xc07bec: add             SP, SP, #0x18
    // 0xc07bf0: ldur            x1, [fp, #-0x10]
    // 0xc07bf4: b               #0xc07adc
    // 0xc07bf8: r0 = true
    //     0xc07bf8: add             x0, NULL, #0x20  ; true
    // 0xc07bfc: LeaveFrame
    //     0xc07bfc: mov             SP, fp
    //     0xc07c00: ldp             fp, lr, [SP], #0x10
    // 0xc07c04: ret
    //     0xc07c04: ret             
    // 0xc07c08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc07c08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc07c0c: b               #0xc077f8
    // 0xc07c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc07c10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc07c14: b               #0xc07990
    // 0xc07c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc07c18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc07c1c: b               #0xc07af0
  }
}

// class id: 4775, size: 0x14, field offset: 0x8
class _MapEntry extends Object {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafa504, size: 0xf0
    // 0xafa504: EnterFrame
    //     0xafa504: stp             fp, lr, [SP, #-0x10]!
    //     0xafa508: mov             fp, SP
    // 0xafa50c: AllocStack(0x10)
    //     0xafa50c: sub             SP, SP, #0x10
    // 0xafa510: CheckStackOverflow
    //     0xafa510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafa514: cmp             SP, x16
    //     0xafa518: b.ls            #0xafa5dc
    // 0xafa51c: ldr             x0, [fp, #0x10]
    // 0xafa520: LoadField: r1 = r0->field_7
    //     0xafa520: ldur            w1, [x0, #7]
    // 0xafa524: DecompressPointer r1
    //     0xafa524: add             x1, x1, HEAP, lsl #32
    // 0xafa528: stur            x1, [fp, #-8]
    // 0xafa52c: LoadField: r2 = r1->field_b
    //     0xafa52c: ldur            w2, [x1, #0xb]
    // 0xafa530: DecompressPointer r2
    //     0xafa530: add             x2, x2, HEAP, lsl #32
    // 0xafa534: LoadField: r3 = r0->field_b
    //     0xafa534: ldur            w3, [x0, #0xb]
    // 0xafa538: DecompressPointer r3
    //     0xafa538: add             x3, x3, HEAP, lsl #32
    // 0xafa53c: stp             x3, x2, [SP, #-0x10]!
    // 0xafa540: r0 = hash()
    //     0xafa540: bl              #0xc05368  ; [package:collection/src/equality.dart] DeepCollectionEquality::hash
    // 0xafa544: add             SP, SP, #0x10
    // 0xafa548: r16 = 3
    //     0xafa548: mov             x16, #3
    // 0xafa54c: mul             x1, x0, x16
    // 0xafa550: ldur            x0, [fp, #-8]
    // 0xafa554: stur            x1, [fp, #-0x10]
    // 0xafa558: LoadField: r2 = r0->field_f
    //     0xafa558: ldur            w2, [x0, #0xf]
    // 0xafa55c: DecompressPointer r2
    //     0xafa55c: add             x2, x2, HEAP, lsl #32
    // 0xafa560: ldr             x0, [fp, #0x10]
    // 0xafa564: LoadField: r3 = r0->field_f
    //     0xafa564: ldur            w3, [x0, #0xf]
    // 0xafa568: DecompressPointer r3
    //     0xafa568: add             x3, x3, HEAP, lsl #32
    // 0xafa56c: stp             x3, x2, [SP, #-0x10]!
    // 0xafa570: r0 = hash()
    //     0xafa570: bl              #0xc05368  ; [package:collection/src/equality.dart] DeepCollectionEquality::hash
    // 0xafa574: add             SP, SP, #0x10
    // 0xafa578: ubfx            x0, x0, #0, #0x20
    // 0xafa57c: r1 = 7
    //     0xafa57c: mov             x1, #7
    // 0xafa580: mul             x2, x0, x1
    // 0xafa584: ldur            x1, [fp, #-0x10]
    // 0xafa588: ubfx            x1, x1, #0, #0x20
    // 0xafa58c: add             w3, w1, w2
    // 0xafa590: r1 = 2147483647
    //     0xafa590: mov             x1, #0x7fffffff
    // 0xafa594: and             x2, x3, x1
    // 0xafa598: lsl             w0, w2, #1
    // 0xafa59c: tst             x2, #0xc0000000
    // 0xafa5a0: b.eq            #0xafa5d0
    // 0xafa5a4: r0 = inline_Allocate_Mint()
    //     0xafa5a4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xafa5a8: add             x0, x0, #0x10
    //     0xafa5ac: cmp             x1, x0
    //     0xafa5b0: b.ls            #0xafa5e4
    //     0xafa5b4: str             x0, [THR, #0x60]  ; THR::top
    //     0xafa5b8: sub             x0, x0, #0xf
    //     0xafa5bc: mov             x1, #0xc108
    //     0xafa5c0: movk            x1, #3, lsl #16
    //     0xafa5c4: stur            x1, [x0, #-1]
    // 0xafa5c8: ubfx            x1, x2, #0, #0x20
    // 0xafa5cc: StoreField: r0->field_7 = r1
    //     0xafa5cc: stur            x1, [x0, #7]
    // 0xafa5d0: LeaveFrame
    //     0xafa5d0: mov             SP, fp
    //     0xafa5d4: ldp             fp, lr, [SP], #0x10
    // 0xafa5d8: ret
    //     0xafa5d8: ret             
    // 0xafa5dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa5dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa5e0: b               #0xafa51c
    // 0xafa5e4: SaveReg r2
    //     0xafa5e4: str             x2, [SP, #-8]!
    // 0xafa5e8: r0 = AllocateMint()
    //     0xafa5e8: bl              #0xd69828  ; AllocateMintStub
    // 0xafa5ec: RestoreReg r2
    //     0xafa5ec: ldr             x2, [SP], #8
    // 0xafa5f0: b               #0xafa5c8
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6d0d4, size: 0xe0
    // 0xc6d0d4: EnterFrame
    //     0xc6d0d4: stp             fp, lr, [SP, #-0x10]!
    //     0xc6d0d8: mov             fp, SP
    // 0xc6d0dc: AllocStack(0x8)
    //     0xc6d0dc: sub             SP, SP, #8
    // 0xc6d0e0: CheckStackOverflow
    //     0xc6d0e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6d0e4: cmp             SP, x16
    //     0xc6d0e8: b.ls            #0xc6d1ac
    // 0xc6d0ec: ldr             x0, [fp, #0x10]
    // 0xc6d0f0: cmp             w0, NULL
    // 0xc6d0f4: b.ne            #0xc6d108
    // 0xc6d0f8: r0 = false
    //     0xc6d0f8: add             x0, NULL, #0x30  ; false
    // 0xc6d0fc: LeaveFrame
    //     0xc6d0fc: mov             SP, fp
    //     0xc6d100: ldp             fp, lr, [SP], #0x10
    // 0xc6d104: ret
    //     0xc6d104: ret             
    // 0xc6d108: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6d108: mov             x1, #0x76
    //     0xc6d10c: tbz             w0, #0, #0xc6d11c
    //     0xc6d110: ldur            x1, [x0, #-1]
    //     0xc6d114: ubfx            x1, x1, #0xc, #0x14
    //     0xc6d118: lsl             x1, x1, #1
    // 0xc6d11c: r17 = 9550
    //     0xc6d11c: mov             x17, #0x254e
    // 0xc6d120: cmp             w1, w17
    // 0xc6d124: b.ne            #0xc6d19c
    // 0xc6d128: ldr             x1, [fp, #0x18]
    // 0xc6d12c: LoadField: r2 = r1->field_7
    //     0xc6d12c: ldur            w2, [x1, #7]
    // 0xc6d130: DecompressPointer r2
    //     0xc6d130: add             x2, x2, HEAP, lsl #32
    // 0xc6d134: stur            x2, [fp, #-8]
    // 0xc6d138: LoadField: r3 = r2->field_b
    //     0xc6d138: ldur            w3, [x2, #0xb]
    // 0xc6d13c: DecompressPointer r3
    //     0xc6d13c: add             x3, x3, HEAP, lsl #32
    // 0xc6d140: LoadField: r4 = r1->field_b
    //     0xc6d140: ldur            w4, [x1, #0xb]
    // 0xc6d144: DecompressPointer r4
    //     0xc6d144: add             x4, x4, HEAP, lsl #32
    // 0xc6d148: LoadField: r5 = r0->field_b
    //     0xc6d148: ldur            w5, [x0, #0xb]
    // 0xc6d14c: DecompressPointer r5
    //     0xc6d14c: add             x5, x5, HEAP, lsl #32
    // 0xc6d150: stp             x4, x3, [SP, #-0x10]!
    // 0xc6d154: SaveReg r5
    //     0xc6d154: str             x5, [SP, #-8]!
    // 0xc6d158: r0 = equals()
    //     0xc6d158: bl              #0xc07d34  ; [package:collection/src/equality.dart] DeepCollectionEquality::equals
    // 0xc6d15c: add             SP, SP, #0x18
    // 0xc6d160: tbnz            w0, #4, #0xc6d19c
    // 0xc6d164: ldr             x1, [fp, #0x18]
    // 0xc6d168: ldr             x0, [fp, #0x10]
    // 0xc6d16c: ldur            x2, [fp, #-8]
    // 0xc6d170: LoadField: r3 = r2->field_f
    //     0xc6d170: ldur            w3, [x2, #0xf]
    // 0xc6d174: DecompressPointer r3
    //     0xc6d174: add             x3, x3, HEAP, lsl #32
    // 0xc6d178: LoadField: r2 = r1->field_f
    //     0xc6d178: ldur            w2, [x1, #0xf]
    // 0xc6d17c: DecompressPointer r2
    //     0xc6d17c: add             x2, x2, HEAP, lsl #32
    // 0xc6d180: LoadField: r1 = r0->field_f
    //     0xc6d180: ldur            w1, [x0, #0xf]
    // 0xc6d184: DecompressPointer r1
    //     0xc6d184: add             x1, x1, HEAP, lsl #32
    // 0xc6d188: stp             x2, x3, [SP, #-0x10]!
    // 0xc6d18c: SaveReg r1
    //     0xc6d18c: str             x1, [SP, #-8]!
    // 0xc6d190: r0 = equals()
    //     0xc6d190: bl              #0xc07d34  ; [package:collection/src/equality.dart] DeepCollectionEquality::equals
    // 0xc6d194: add             SP, SP, #0x18
    // 0xc6d198: b               #0xc6d1a0
    // 0xc6d19c: r0 = false
    //     0xc6d19c: add             x0, NULL, #0x30  ; false
    // 0xc6d1a0: LeaveFrame
    //     0xc6d1a0: mov             SP, fp
    //     0xc6d1a4: ldp             fp, lr, [SP], #0x10
    // 0xc6d1a8: ret
    //     0xc6d1a8: ret             
    // 0xc6d1ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6d1ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6d1b0: b               #0xc6d0ec
  }
}

// class id: 4776, size: 0x10, field offset: 0x8
//   const constructor, 
abstract class _UnorderedEquality<X0, X1 bound Iterable<X0>> extends Object
    implements Equality<X0> {

  _ hash(/* No info */) {
    // ** addr: 0xc04d20, size: 0x184
    // 0xc04d20: EnterFrame
    //     0xc04d20: stp             fp, lr, [SP, #-0x10]!
    //     0xc04d24: mov             fp, SP
    // 0xc04d28: AllocStack(0x18)
    //     0xc04d28: sub             SP, SP, #0x18
    // 0xc04d2c: CheckStackOverflow
    //     0xc04d2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc04d30: cmp             SP, x16
    //     0xc04d34: b.ls            #0xc04e94
    // 0xc04d38: ldr             x3, [fp, #0x18]
    // 0xc04d3c: LoadField: r2 = r3->field_7
    //     0xc04d3c: ldur            w2, [x3, #7]
    // 0xc04d40: DecompressPointer r2
    //     0xc04d40: add             x2, x2, HEAP, lsl #32
    // 0xc04d44: ldr             x0, [fp, #0x10]
    // 0xc04d48: r1 = Null
    //     0xc04d48: mov             x1, NULL
    // 0xc04d4c: cmp             w0, NULL
    // 0xc04d50: b.eq            #0xc04d7c
    // 0xc04d54: cmp             w2, NULL
    // 0xc04d58: b.eq            #0xc04d7c
    // 0xc04d5c: LoadField: r4 = r2->field_1b
    //     0xc04d5c: ldur            w4, [x2, #0x1b]
    // 0xc04d60: DecompressPointer r4
    //     0xc04d60: add             x4, x4, HEAP, lsl #32
    // 0xc04d64: r8 = X1? bound Iterable<X0>
    //     0xc04d64: add             x8, PP, #0x42, lsl #12  ; [pp+0x426d0] TypeParameter: X1? bound Iterable<X0>
    //     0xc04d68: ldr             x8, [x8, #0x6d0]
    // 0xc04d6c: LoadField: r9 = r4->field_7
    //     0xc04d6c: ldur            x9, [x4, #7]
    // 0xc04d70: r3 = Null
    //     0xc04d70: add             x3, PP, #0x42, lsl #12  ; [pp+0x42800] Null
    //     0xc04d74: ldr             x3, [x3, #0x800]
    // 0xc04d78: blr             x9
    // 0xc04d7c: ldr             x0, [fp, #0x10]
    // 0xc04d80: r1 = LoadClassIdInstr(r0)
    //     0xc04d80: ldur            x1, [x0, #-1]
    //     0xc04d84: ubfx            x1, x1, #0xc, #0x14
    // 0xc04d88: SaveReg r0
    //     0xc04d88: str             x0, [SP, #-8]!
    // 0xc04d8c: mov             x0, x1
    // 0xc04d90: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc04d90: mov             x17, #0xb940
    //     0xc04d94: add             lr, x0, x17
    //     0xc04d98: ldr             lr, [x21, lr, lsl #3]
    //     0xc04d9c: blr             lr
    // 0xc04da0: add             SP, SP, #8
    // 0xc04da4: mov             x1, x0
    // 0xc04da8: ldr             x0, [fp, #0x18]
    // 0xc04dac: stur            x1, [fp, #-0x18]
    // 0xc04db0: LoadField: r2 = r0->field_b
    //     0xc04db0: ldur            w2, [x0, #0xb]
    // 0xc04db4: DecompressPointer r2
    //     0xc04db4: add             x2, x2, HEAP, lsl #32
    // 0xc04db8: stur            x2, [fp, #-0x10]
    // 0xc04dbc: r3 = 0
    //     0xc04dbc: mov             x3, #0
    // 0xc04dc0: stur            x3, [fp, #-8]
    // 0xc04dc4: CheckStackOverflow
    //     0xc04dc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc04dc8: cmp             SP, x16
    //     0xc04dcc: b.ls            #0xc04e9c
    // 0xc04dd0: r0 = LoadClassIdInstr(r1)
    //     0xc04dd0: ldur            x0, [x1, #-1]
    //     0xc04dd4: ubfx            x0, x0, #0xc, #0x14
    // 0xc04dd8: SaveReg r1
    //     0xc04dd8: str             x1, [SP, #-8]!
    // 0xc04ddc: r0 = GDT[cid_x0 + 0x541]()
    //     0xc04ddc: add             lr, x0, #0x541
    //     0xc04de0: ldr             lr, [x21, lr, lsl #3]
    //     0xc04de4: blr             lr
    // 0xc04de8: add             SP, SP, #8
    // 0xc04dec: tbnz            w0, #4, #0xc04e4c
    // 0xc04df0: ldur            x1, [fp, #-0x18]
    // 0xc04df4: r0 = LoadClassIdInstr(r1)
    //     0xc04df4: ldur            x0, [x1, #-1]
    //     0xc04df8: ubfx            x0, x0, #0xc, #0x14
    // 0xc04dfc: SaveReg r1
    //     0xc04dfc: str             x1, [SP, #-8]!
    // 0xc04e00: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc04e00: add             lr, x0, #0x5ca
    //     0xc04e04: ldr             lr, [x21, lr, lsl #3]
    //     0xc04e08: blr             lr
    // 0xc04e0c: add             SP, SP, #8
    // 0xc04e10: ldur            x16, [fp, #-0x10]
    // 0xc04e14: stp             x0, x16, [SP, #-0x10]!
    // 0xc04e18: r0 = hash()
    //     0xc04e18: bl              #0xc05368  ; [package:collection/src/equality.dart] DeepCollectionEquality::hash
    // 0xc04e1c: add             SP, SP, #0x10
    // 0xc04e20: ldur            x1, [fp, #-8]
    // 0xc04e24: ubfx            x1, x1, #0, #0x20
    // 0xc04e28: ubfx            x0, x0, #0, #0x20
    // 0xc04e2c: add             w2, w1, w0
    // 0xc04e30: r1 = 2147483647
    //     0xc04e30: mov             x1, #0x7fffffff
    // 0xc04e34: and             x0, x2, x1
    // 0xc04e38: ubfx            x0, x0, #0, #0x20
    // 0xc04e3c: mov             x3, x0
    // 0xc04e40: ldur            x1, [fp, #-0x18]
    // 0xc04e44: ldur            x2, [fp, #-0x10]
    // 0xc04e48: b               #0xc04dc0
    // 0xc04e4c: r1 = 2147483647
    //     0xc04e4c: mov             x1, #0x7fffffff
    // 0xc04e50: ldur            x2, [fp, #-8]
    // 0xc04e54: ubfx            x2, x2, #0, #0x20
    // 0xc04e58: lsl             w3, w2, #3
    // 0xc04e5c: ldur            x2, [fp, #-8]
    // 0xc04e60: ubfx            x2, x2, #0, #0x20
    // 0xc04e64: add             w4, w2, w3
    // 0xc04e68: and             x2, x4, x1
    // 0xc04e6c: lsr             w3, w2, #0xb
    // 0xc04e70: eor             x4, x2, x3
    // 0xc04e74: lsl             w2, w4, #0xf
    // 0xc04e78: add             w3, w4, w2
    // 0xc04e7c: and             x2, x3, x1
    // 0xc04e80: ubfx            x2, x2, #0, #0x20
    // 0xc04e84: mov             x0, x2
    // 0xc04e88: LeaveFrame
    //     0xc04e88: mov             SP, fp
    //     0xc04e8c: ldp             fp, lr, [SP], #0x10
    // 0xc04e90: ret
    //     0xc04e90: ret             
    // 0xc04e94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc04e94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc04e98: b               #0xc04d38
    // 0xc04e9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc04e9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc04ea0: b               #0xc04dd0
  }
  _ equals(/* No info */) {
    // ** addr: 0xc06ffc, size: 0x42c
    // 0xc06ffc: EnterFrame
    //     0xc06ffc: stp             fp, lr, [SP, #-0x10]!
    //     0xc07000: mov             fp, SP
    // 0xc07004: AllocStack(0x28)
    //     0xc07004: sub             SP, SP, #0x28
    // 0xc07008: CheckStackOverflow
    //     0xc07008: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0700c: cmp             SP, x16
    //     0xc07010: b.ls            #0xc07410
    // 0xc07014: ldr             x3, [fp, #0x20]
    // 0xc07018: LoadField: r4 = r3->field_7
    //     0xc07018: ldur            w4, [x3, #7]
    // 0xc0701c: DecompressPointer r4
    //     0xc0701c: add             x4, x4, HEAP, lsl #32
    // 0xc07020: ldr             x0, [fp, #0x18]
    // 0xc07024: mov             x2, x4
    // 0xc07028: stur            x4, [fp, #-8]
    // 0xc0702c: r1 = Null
    //     0xc0702c: mov             x1, NULL
    // 0xc07030: cmp             w0, NULL
    // 0xc07034: b.eq            #0xc07060
    // 0xc07038: cmp             w2, NULL
    // 0xc0703c: b.eq            #0xc07060
    // 0xc07040: LoadField: r4 = r2->field_1b
    //     0xc07040: ldur            w4, [x2, #0x1b]
    // 0xc07044: DecompressPointer r4
    //     0xc07044: add             x4, x4, HEAP, lsl #32
    // 0xc07048: r8 = X1? bound Iterable<X0>
    //     0xc07048: add             x8, PP, #0x42, lsl #12  ; [pp+0x426d0] TypeParameter: X1? bound Iterable<X0>
    //     0xc0704c: ldr             x8, [x8, #0x6d0]
    // 0xc07050: LoadField: r9 = r4->field_7
    //     0xc07050: ldur            x9, [x4, #7]
    // 0xc07054: r3 = Null
    //     0xc07054: add             x3, PP, #0x42, lsl #12  ; [pp+0x426d8] Null
    //     0xc07058: ldr             x3, [x3, #0x6d8]
    // 0xc0705c: blr             x9
    // 0xc07060: ldr             x0, [fp, #0x10]
    // 0xc07064: ldur            x2, [fp, #-8]
    // 0xc07068: r1 = Null
    //     0xc07068: mov             x1, NULL
    // 0xc0706c: cmp             w0, NULL
    // 0xc07070: b.eq            #0xc0709c
    // 0xc07074: cmp             w2, NULL
    // 0xc07078: b.eq            #0xc0709c
    // 0xc0707c: LoadField: r4 = r2->field_1b
    //     0xc0707c: ldur            w4, [x2, #0x1b]
    // 0xc07080: DecompressPointer r4
    //     0xc07080: add             x4, x4, HEAP, lsl #32
    // 0xc07084: r8 = X1? bound Iterable<X0>
    //     0xc07084: add             x8, PP, #0x42, lsl #12  ; [pp+0x426d0] TypeParameter: X1? bound Iterable<X0>
    //     0xc07088: ldr             x8, [x8, #0x6d0]
    // 0xc0708c: LoadField: r9 = r4->field_7
    //     0xc0708c: ldur            x9, [x4, #7]
    // 0xc07090: r3 = Null
    //     0xc07090: add             x3, PP, #0x42, lsl #12  ; [pp+0x426e8] Null
    //     0xc07094: ldr             x3, [x3, #0x6e8]
    // 0xc07098: blr             x9
    // 0xc0709c: ldr             x0, [fp, #0x18]
    // 0xc070a0: ldr             x1, [fp, #0x10]
    // 0xc070a4: stp             x1, x0, [SP, #-0x10]!
    // 0xc070a8: r24 = OptimizedIdenticalWithNumberCheckStub
    //     0xc070a8: ldr             x24, [PP, #0x198]  ; [pp+0x198] Stub: OptimizedIdenticalWithNumberCheck (0x4ae5e4)
    // 0xc070ac: LoadField: r30 = r24->field_7
    //     0xc070ac: ldur            lr, [x24, #7]
    // 0xc070b0: blr             lr
    // 0xc070b4: ldp             x1, x0, [SP], #0x10
    // 0xc070b8: b.ne            #0xc070cc
    // 0xc070bc: r0 = true
    //     0xc070bc: add             x0, NULL, #0x20  ; true
    // 0xc070c0: LeaveFrame
    //     0xc070c0: mov             SP, fp
    //     0xc070c4: ldp             fp, lr, [SP], #0x10
    // 0xc070c8: ret
    //     0xc070c8: ret             
    // 0xc070cc: ldr             x0, [fp, #0x20]
    // 0xc070d0: ldr             x4, [fp, #0x18]
    // 0xc070d4: ldur            x2, [fp, #-8]
    // 0xc070d8: r1 = Null
    //     0xc070d8: mov             x1, NULL
    // 0xc070dc: r3 = <X0, int>
    //     0xc070dc: ldr             x3, [PP, #0x44c8]  ; [pp+0x44c8] TypeArguments: <X0, int>
    // 0xc070e0: r24 = InstantiateTypeArgumentsStub
    //     0xc070e0: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xc070e4: LoadField: r30 = r24->field_7
    //     0xc070e4: ldur            lr, [x24, #7]
    // 0xc070e8: blr             lr
    // 0xc070ec: mov             x1, x0
    // 0xc070f0: ldr             x0, [fp, #0x20]
    // 0xc070f4: stur            x1, [fp, #-0x18]
    // 0xc070f8: LoadField: r2 = r0->field_b
    //     0xc070f8: ldur            w2, [x0, #0xb]
    // 0xc070fc: DecompressPointer r2
    //     0xc070fc: add             x2, x2, HEAP, lsl #32
    // 0xc07100: stur            x2, [fp, #-0x10]
    // 0xc07104: r1 = 1
    //     0xc07104: mov             x1, #1
    // 0xc07108: r0 = AllocateContext()
    //     0xc07108: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc0710c: mov             x1, x0
    // 0xc07110: ldur            x0, [fp, #-0x10]
    // 0xc07114: StoreField: r1->field_f = r0
    //     0xc07114: stur            w0, [x1, #0xf]
    // 0xc07118: mov             x2, x1
    // 0xc0711c: r1 = Function 'equals':.
    //     0xc0711c: add             x1, PP, #0x42, lsl #12  ; [pp+0x426f8] AnonymousClosure: (0xc0772c), in [package:collection/src/equality.dart] DeepCollectionEquality::equals (0xc07d34)
    //     0xc07120: ldr             x1, [x1, #0x6f8]
    // 0xc07124: r0 = AllocateClosure()
    //     0xc07124: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc07128: ldur            x2, [fp, #-8]
    // 0xc0712c: mov             x3, x0
    // 0xc07130: r1 = Null
    //     0xc07130: mov             x1, NULL
    // 0xc07134: stur            x3, [fp, #-0x20]
    // 0xc07138: r8 = (dynamic this, X0, X0) => bool
    //     0xc07138: add             x8, PP, #0x42, lsl #12  ; [pp+0x42700] FunctionType: (dynamic this, X0, X0) => bool
    //     0xc0713c: ldr             x8, [x8, #0x700]
    // 0xc07140: LoadField: r9 = r8->field_7
    //     0xc07140: ldur            x9, [x8, #7]
    // 0xc07144: r3 = Null
    //     0xc07144: add             x3, PP, #0x42, lsl #12  ; [pp+0x42708] Null
    //     0xc07148: ldr             x3, [x3, #0x708]
    // 0xc0714c: blr             x9
    // 0xc07150: r1 = 1
    //     0xc07150: mov             x1, #1
    // 0xc07154: r0 = AllocateContext()
    //     0xc07154: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc07158: mov             x1, x0
    // 0xc0715c: ldur            x0, [fp, #-0x10]
    // 0xc07160: StoreField: r1->field_f = r0
    //     0xc07160: stur            w0, [x1, #0xf]
    // 0xc07164: mov             x2, x1
    // 0xc07168: r1 = Function 'hash':.
    //     0xc07168: add             x1, PP, #0x42, lsl #12  ; [pp+0x42718] AnonymousClosure: (0xc0576c), in [package:collection/src/equality.dart] DeepCollectionEquality::hash (0xc05368)
    //     0xc0716c: ldr             x1, [x1, #0x718]
    // 0xc07170: r0 = AllocateClosure()
    //     0xc07170: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc07174: ldur            x2, [fp, #-8]
    // 0xc07178: mov             x3, x0
    // 0xc0717c: r1 = Null
    //     0xc0717c: mov             x1, NULL
    // 0xc07180: stur            x3, [fp, #-8]
    // 0xc07184: r8 = (dynamic this, X0) => int
    //     0xc07184: add             x8, PP, #0x42, lsl #12  ; [pp+0x42720] FunctionType: (dynamic this, X0) => int
    //     0xc07188: ldr             x8, [x8, #0x720]
    // 0xc0718c: LoadField: r9 = r8->field_7
    //     0xc0718c: ldur            x9, [x8, #7]
    // 0xc07190: r3 = Null
    //     0xc07190: add             x3, PP, #0x42, lsl #12  ; [pp+0x42728] Null
    //     0xc07194: ldr             x3, [x3, #0x728]
    // 0xc07198: blr             x9
    // 0xc0719c: r1 = 1
    //     0xc0719c: mov             x1, #1
    // 0xc071a0: r0 = AllocateContext()
    //     0xc071a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc071a4: mov             x1, x0
    // 0xc071a8: ldur            x0, [fp, #-0x10]
    // 0xc071ac: StoreField: r1->field_f = r0
    //     0xc071ac: stur            w0, [x1, #0xf]
    // 0xc071b0: mov             x2, x1
    // 0xc071b4: r1 = Function 'isValidKey':.
    //     0xc071b4: add             x1, PP, #0x42, lsl #12  ; [pp+0x42738] AnonymousClosure: (0xc07558), in [package:collection/src/equality.dart] DeepCollectionEquality::isValidKey (0xc075a4)
    //     0xc071b8: ldr             x1, [x1, #0x738]
    // 0xc071bc: r0 = AllocateClosure()
    //     0xc071bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc071c0: ldur            x1, [fp, #-0x18]
    // 0xc071c4: stur            x0, [fp, #-0x10]
    // 0xc071c8: r0 = _CustomHashMap()
    //     0xc071c8: bl              #0xc0754c  ; Allocate_CustomHashMapStub -> _CustomHashMap<X0, X1> (size=0x2c)
    // 0xc071cc: stur            x0, [fp, #-0x18]
    // 0xc071d0: ldur            x16, [fp, #-0x20]
    // 0xc071d4: stp             x16, x0, [SP, #-0x10]!
    // 0xc071d8: ldur            x16, [fp, #-8]
    // 0xc071dc: ldur            lr, [fp, #-0x10]
    // 0xc071e0: stp             lr, x16, [SP, #-0x10]!
    // 0xc071e4: r0 = _CustomHashMap()
    //     0xc071e4: bl              #0xc07428  ; [dart:collection] _CustomHashMap::_CustomHashMap
    // 0xc071e8: add             SP, SP, #0x20
    // 0xc071ec: ldr             x0, [fp, #0x18]
    // 0xc071f0: r1 = LoadClassIdInstr(r0)
    //     0xc071f0: ldur            x1, [x0, #-1]
    //     0xc071f4: ubfx            x1, x1, #0xc, #0x14
    // 0xc071f8: SaveReg r0
    //     0xc071f8: str             x0, [SP, #-8]!
    // 0xc071fc: mov             x0, x1
    // 0xc07200: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc07200: mov             x17, #0xb940
    //     0xc07204: add             lr, x0, x17
    //     0xc07208: ldr             lr, [x21, lr, lsl #3]
    //     0xc0720c: blr             lr
    // 0xc07210: add             SP, SP, #8
    // 0xc07214: mov             x1, x0
    // 0xc07218: stur            x1, [fp, #-8]
    // 0xc0721c: r2 = 0
    //     0xc0721c: mov             x2, #0
    // 0xc07220: stur            x2, [fp, #-0x28]
    // 0xc07224: CheckStackOverflow
    //     0xc07224: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc07228: cmp             SP, x16
    //     0xc0722c: b.ls            #0xc07418
    // 0xc07230: r0 = LoadClassIdInstr(r1)
    //     0xc07230: ldur            x0, [x1, #-1]
    //     0xc07234: ubfx            x0, x0, #0xc, #0x14
    // 0xc07238: SaveReg r1
    //     0xc07238: str             x1, [SP, #-8]!
    // 0xc0723c: r0 = GDT[cid_x0 + 0x541]()
    //     0xc0723c: add             lr, x0, #0x541
    //     0xc07240: ldr             lr, [x21, lr, lsl #3]
    //     0xc07244: blr             lr
    // 0xc07248: add             SP, SP, #8
    // 0xc0724c: tbnz            w0, #4, #0xc072e8
    // 0xc07250: ldur            x1, [fp, #-8]
    // 0xc07254: r0 = LoadClassIdInstr(r1)
    //     0xc07254: ldur            x0, [x1, #-1]
    //     0xc07258: ubfx            x0, x0, #0xc, #0x14
    // 0xc0725c: SaveReg r1
    //     0xc0725c: str             x1, [SP, #-8]!
    // 0xc07260: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc07260: add             lr, x0, #0x5ca
    //     0xc07264: ldr             lr, [x21, lr, lsl #3]
    //     0xc07268: blr             lr
    // 0xc0726c: add             SP, SP, #8
    // 0xc07270: stur            x0, [fp, #-0x10]
    // 0xc07274: ldur            x16, [fp, #-0x18]
    // 0xc07278: stp             x0, x16, [SP, #-0x10]!
    // 0xc0727c: r0 = []()
    //     0xc0727c: bl              #0xc63a80  ; [dart:collection] _CustomHashMap::[]
    // 0xc07280: add             SP, SP, #0x10
    // 0xc07284: cmp             w0, NULL
    // 0xc07288: b.ne            #0xc07294
    // 0xc0728c: r0 = 0
    //     0xc0728c: mov             x0, #0
    // 0xc07290: b               #0xc072a4
    // 0xc07294: r1 = LoadInt32Instr(r0)
    //     0xc07294: sbfx            x1, x0, #1, #0x1f
    //     0xc07298: tbz             w0, #0, #0xc072a0
    //     0xc0729c: ldur            x1, [x0, #7]
    // 0xc072a0: mov             x0, x1
    // 0xc072a4: ldur            x2, [fp, #-0x28]
    // 0xc072a8: add             x3, x0, #1
    // 0xc072ac: r0 = BoxInt64Instr(r3)
    //     0xc072ac: sbfiz           x0, x3, #1, #0x1f
    //     0xc072b0: cmp             x3, x0, asr #1
    //     0xc072b4: b.eq            #0xc072c0
    //     0xc072b8: bl              #0xd69bb8
    //     0xc072bc: stur            x3, [x0, #7]
    // 0xc072c0: ldur            x16, [fp, #-0x18]
    // 0xc072c4: ldur            lr, [fp, #-0x10]
    // 0xc072c8: stp             lr, x16, [SP, #-0x10]!
    // 0xc072cc: SaveReg r0
    //     0xc072cc: str             x0, [SP, #-8]!
    // 0xc072d0: r0 = []=()
    //     0xc072d0: bl              #0xc53b9c  ; [dart:collection] _CustomHashMap::[]=
    // 0xc072d4: add             SP, SP, #0x18
    // 0xc072d8: ldur            x1, [fp, #-0x28]
    // 0xc072dc: add             x2, x1, #1
    // 0xc072e0: ldur            x1, [fp, #-8]
    // 0xc072e4: b               #0xc07220
    // 0xc072e8: ldr             x0, [fp, #0x10]
    // 0xc072ec: ldur            x1, [fp, #-0x28]
    // 0xc072f0: r2 = LoadClassIdInstr(r0)
    //     0xc072f0: ldur            x2, [x0, #-1]
    //     0xc072f4: ubfx            x2, x2, #0xc, #0x14
    // 0xc072f8: SaveReg r0
    //     0xc072f8: str             x0, [SP, #-8]!
    // 0xc072fc: mov             x0, x2
    // 0xc07300: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc07300: mov             x17, #0xb940
    //     0xc07304: add             lr, x0, x17
    //     0xc07308: ldr             lr, [x21, lr, lsl #3]
    //     0xc0730c: blr             lr
    // 0xc07310: add             SP, SP, #8
    // 0xc07314: mov             x1, x0
    // 0xc07318: stur            x1, [fp, #-8]
    // 0xc0731c: ldur            x2, [fp, #-0x28]
    // 0xc07320: stur            x2, [fp, #-0x28]
    // 0xc07324: CheckStackOverflow
    //     0xc07324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc07328: cmp             SP, x16
    //     0xc0732c: b.ls            #0xc07420
    // 0xc07330: r0 = LoadClassIdInstr(r1)
    //     0xc07330: ldur            x0, [x1, #-1]
    //     0xc07334: ubfx            x0, x0, #0xc, #0x14
    // 0xc07338: SaveReg r1
    //     0xc07338: str             x1, [SP, #-8]!
    // 0xc0733c: r0 = GDT[cid_x0 + 0x541]()
    //     0xc0733c: add             lr, x0, #0x541
    //     0xc07340: ldr             lr, [x21, lr, lsl #3]
    //     0xc07344: blr             lr
    // 0xc07348: add             SP, SP, #8
    // 0xc0734c: tbnz            w0, #4, #0xc073f0
    // 0xc07350: ldur            x1, [fp, #-8]
    // 0xc07354: r0 = LoadClassIdInstr(r1)
    //     0xc07354: ldur            x0, [x1, #-1]
    //     0xc07358: ubfx            x0, x0, #0xc, #0x14
    // 0xc0735c: SaveReg r1
    //     0xc0735c: str             x1, [SP, #-8]!
    // 0xc07360: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc07360: add             lr, x0, #0x5ca
    //     0xc07364: ldr             lr, [x21, lr, lsl #3]
    //     0xc07368: blr             lr
    // 0xc0736c: add             SP, SP, #8
    // 0xc07370: stur            x0, [fp, #-0x10]
    // 0xc07374: ldur            x16, [fp, #-0x18]
    // 0xc07378: stp             x0, x16, [SP, #-0x10]!
    // 0xc0737c: r0 = []()
    //     0xc0737c: bl              #0xc63a80  ; [dart:collection] _CustomHashMap::[]
    // 0xc07380: add             SP, SP, #0x10
    // 0xc07384: cmp             w0, NULL
    // 0xc07388: b.eq            #0xc07390
    // 0xc0738c: cbnz            w0, #0xc073a0
    // 0xc07390: r0 = false
    //     0xc07390: add             x0, NULL, #0x30  ; false
    // 0xc07394: LeaveFrame
    //     0xc07394: mov             SP, fp
    //     0xc07398: ldp             fp, lr, [SP], #0x10
    // 0xc0739c: ret
    //     0xc0739c: ret             
    // 0xc073a0: ldur            x2, [fp, #-0x28]
    // 0xc073a4: r1 = LoadInt32Instr(r0)
    //     0xc073a4: sbfx            x1, x0, #1, #0x1f
    //     0xc073a8: tbz             w0, #0, #0xc073b0
    //     0xc073ac: ldur            x1, [x0, #7]
    // 0xc073b0: sub             x3, x1, #1
    // 0xc073b4: r0 = BoxInt64Instr(r3)
    //     0xc073b4: sbfiz           x0, x3, #1, #0x1f
    //     0xc073b8: cmp             x3, x0, asr #1
    //     0xc073bc: b.eq            #0xc073c8
    //     0xc073c0: bl              #0xd69bb8
    //     0xc073c4: stur            x3, [x0, #7]
    // 0xc073c8: ldur            x16, [fp, #-0x18]
    // 0xc073cc: ldur            lr, [fp, #-0x10]
    // 0xc073d0: stp             lr, x16, [SP, #-0x10]!
    // 0xc073d4: SaveReg r0
    //     0xc073d4: str             x0, [SP, #-8]!
    // 0xc073d8: r0 = []=()
    //     0xc073d8: bl              #0xc53b9c  ; [dart:collection] _CustomHashMap::[]=
    // 0xc073dc: add             SP, SP, #0x18
    // 0xc073e0: ldur            x1, [fp, #-0x28]
    // 0xc073e4: sub             x2, x1, #1
    // 0xc073e8: ldur            x1, [fp, #-8]
    // 0xc073ec: b               #0xc07320
    // 0xc073f0: ldur            x1, [fp, #-0x28]
    // 0xc073f4: cbz             x1, #0xc07400
    // 0xc073f8: r0 = false
    //     0xc073f8: add             x0, NULL, #0x30  ; false
    // 0xc073fc: b               #0xc07404
    // 0xc07400: r0 = true
    //     0xc07400: add             x0, NULL, #0x20  ; true
    // 0xc07404: LeaveFrame
    //     0xc07404: mov             SP, fp
    //     0xc07408: ldp             fp, lr, [SP], #0x10
    // 0xc0740c: ret
    //     0xc0740c: ret             
    // 0xc07410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc07410: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc07414: b               #0xc07014
    // 0xc07418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc07418: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0741c: b               #0xc07230
    // 0xc07420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc07420: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc07424: b               #0xc07330
  }
}

// class id: 4777, size: 0x10, field offset: 0x10
//   const constructor, 
class SetEquality<C2X0> extends _UnorderedEquality<C2X0, Set<C2X0>> {
}

// class id: 4779, size: 0x10, field offset: 0x8
//   const constructor, 
class ListEquality<X0> extends Object
    implements Equality<X0> {

  DefaultEquality<Never> field_c;

  _ hash(/* No info */) {
    // ** addr: 0xc04b70, size: 0x1b0
    // 0xc04b70: EnterFrame
    //     0xc04b70: stp             fp, lr, [SP, #-0x10]!
    //     0xc04b74: mov             fp, SP
    // 0xc04b78: AllocStack(0x18)
    //     0xc04b78: sub             SP, SP, #0x18
    // 0xc04b7c: CheckStackOverflow
    //     0xc04b7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc04b80: cmp             SP, x16
    //     0xc04b84: b.ls            #0xc04d10
    // 0xc04b88: ldr             x3, [fp, #0x18]
    // 0xc04b8c: LoadField: r2 = r3->field_7
    //     0xc04b8c: ldur            w2, [x3, #7]
    // 0xc04b90: DecompressPointer r2
    //     0xc04b90: add             x2, x2, HEAP, lsl #32
    // 0xc04b94: ldr             x0, [fp, #0x10]
    // 0xc04b98: r1 = Null
    //     0xc04b98: mov             x1, NULL
    // 0xc04b9c: r8 = List<X0>?
    //     0xc04b9c: add             x8, PP, #0xd, lsl #12  ; [pp+0xd740] Type: List<X0>?
    //     0xc04ba0: ldr             x8, [x8, #0x740]
    // 0xc04ba4: LoadField: r9 = r8->field_7
    //     0xc04ba4: ldur            x9, [x8, #7]
    // 0xc04ba8: r3 = Null
    //     0xc04ba8: add             x3, PP, #0x42, lsl #12  ; [pp+0x427e0] Null
    //     0xc04bac: ldr             x3, [x3, #0x7e0]
    // 0xc04bb0: blr             x9
    // 0xc04bb4: ldr             x0, [fp, #0x18]
    // 0xc04bb8: LoadField: r1 = r0->field_b
    //     0xc04bb8: ldur            w1, [x0, #0xb]
    // 0xc04bbc: DecompressPointer r1
    //     0xc04bbc: add             x1, x1, HEAP, lsl #32
    // 0xc04bc0: stur            x1, [fp, #-0x18]
    // 0xc04bc4: r4 = 0
    //     0xc04bc4: mov             x4, #0
    // 0xc04bc8: r3 = 0
    //     0xc04bc8: mov             x3, #0
    // 0xc04bcc: ldr             x2, [fp, #0x10]
    // 0xc04bd0: stur            x4, [fp, #-8]
    // 0xc04bd4: stur            x3, [fp, #-0x10]
    // 0xc04bd8: CheckStackOverflow
    //     0xc04bd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc04bdc: cmp             SP, x16
    //     0xc04be0: b.ls            #0xc04d18
    // 0xc04be4: r0 = LoadClassIdInstr(r2)
    //     0xc04be4: ldur            x0, [x2, #-1]
    //     0xc04be8: ubfx            x0, x0, #0xc, #0x14
    // 0xc04bec: SaveReg r2
    //     0xc04bec: str             x2, [SP, #-8]!
    // 0xc04bf0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc04bf0: mov             x17, #0xb8ea
    //     0xc04bf4: add             lr, x0, x17
    //     0xc04bf8: ldr             lr, [x21, lr, lsl #3]
    //     0xc04bfc: blr             lr
    // 0xc04c00: add             SP, SP, #8
    // 0xc04c04: r1 = LoadInt32Instr(r0)
    //     0xc04c04: sbfx            x1, x0, #1, #0x1f
    //     0xc04c08: tbz             w0, #0, #0xc04c10
    //     0xc04c0c: ldur            x1, [x0, #7]
    // 0xc04c10: ldur            x2, [fp, #-0x10]
    // 0xc04c14: cmp             x2, x1
    // 0xc04c18: b.ge            #0xc04cc8
    // 0xc04c1c: ldr             x4, [fp, #0x10]
    // 0xc04c20: ldur            x3, [fp, #-0x18]
    // 0xc04c24: r0 = BoxInt64Instr(r2)
    //     0xc04c24: sbfiz           x0, x2, #1, #0x1f
    //     0xc04c28: cmp             x2, x0, asr #1
    //     0xc04c2c: b.eq            #0xc04c38
    //     0xc04c30: bl              #0xd69bb8
    //     0xc04c34: stur            x2, [x0, #7]
    // 0xc04c38: r1 = LoadClassIdInstr(r4)
    //     0xc04c38: ldur            x1, [x4, #-1]
    //     0xc04c3c: ubfx            x1, x1, #0xc, #0x14
    // 0xc04c40: stp             x0, x4, [SP, #-0x10]!
    // 0xc04c44: mov             x0, x1
    // 0xc04c48: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc04c48: sub             lr, x0, #0xd83
    //     0xc04c4c: ldr             lr, [x21, lr, lsl #3]
    //     0xc04c50: blr             lr
    // 0xc04c54: add             SP, SP, #0x10
    // 0xc04c58: ldur            x1, [fp, #-0x18]
    // 0xc04c5c: r2 = LoadClassIdInstr(r1)
    //     0xc04c5c: ldur            x2, [x1, #-1]
    //     0xc04c60: ubfx            x2, x2, #0xc, #0x14
    // 0xc04c64: stp             x0, x1, [SP, #-0x10]!
    // 0xc04c68: mov             x0, x2
    // 0xc04c6c: r0 = GDT[cid_x0 + 0xbf9]()
    //     0xc04c6c: add             lr, x0, #0xbf9
    //     0xc04c70: ldr             lr, [x21, lr, lsl #3]
    //     0xc04c74: blr             lr
    // 0xc04c78: add             SP, SP, #0x10
    // 0xc04c7c: ldur            x1, [fp, #-8]
    // 0xc04c80: ubfx            x1, x1, #0, #0x20
    // 0xc04c84: ubfx            x0, x0, #0, #0x20
    // 0xc04c88: add             w2, w1, w0
    // 0xc04c8c: r1 = 2147483647
    //     0xc04c8c: mov             x1, #0x7fffffff
    // 0xc04c90: and             x3, x2, x1
    // 0xc04c94: lsl             w2, w3, #0xa
    // 0xc04c98: add             w4, w3, w2
    // 0xc04c9c: and             x2, x4, x1
    // 0xc04ca0: mov             x3, x2
    // 0xc04ca4: ubfx            x3, x3, #0, #0x20
    // 0xc04ca8: asr             x4, x3, #6
    // 0xc04cac: ubfx            x2, x2, #0, #0x20
    // 0xc04cb0: eor             x0, x2, x4
    // 0xc04cb4: ldur            x2, [fp, #-0x10]
    // 0xc04cb8: add             x3, x2, #1
    // 0xc04cbc: mov             x4, x0
    // 0xc04cc0: ldur            x1, [fp, #-0x18]
    // 0xc04cc4: b               #0xc04bcc
    // 0xc04cc8: r1 = 2147483647
    //     0xc04cc8: mov             x1, #0x7fffffff
    // 0xc04ccc: ldur            x2, [fp, #-8]
    // 0xc04cd0: ubfx            x2, x2, #0, #0x20
    // 0xc04cd4: lsl             w3, w2, #3
    // 0xc04cd8: ldur            x2, [fp, #-8]
    // 0xc04cdc: ubfx            x2, x2, #0, #0x20
    // 0xc04ce0: add             w4, w2, w3
    // 0xc04ce4: and             x2, x4, x1
    // 0xc04ce8: lsr             w3, w2, #0xb
    // 0xc04cec: eor             x4, x2, x3
    // 0xc04cf0: lsl             w2, w4, #0xf
    // 0xc04cf4: add             w3, w4, w2
    // 0xc04cf8: and             x2, x3, x1
    // 0xc04cfc: ubfx            x2, x2, #0, #0x20
    // 0xc04d00: mov             x0, x2
    // 0xc04d04: LeaveFrame
    //     0xc04d04: mov             SP, fp
    //     0xc04d08: ldp             fp, lr, [SP], #0x10
    // 0xc04d0c: ret
    //     0xc04d0c: ret             
    // 0xc04d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc04d10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc04d14: b               #0xc04b88
    // 0xc04d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc04d18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc04d1c: b               #0xc04be4
  }
  _ equals(/* No info */) {
    // ** addr: 0xc06dd8, size: 0x224
    // 0xc06dd8: EnterFrame
    //     0xc06dd8: stp             fp, lr, [SP, #-0x10]!
    //     0xc06ddc: mov             fp, SP
    // 0xc06de0: AllocStack(0x28)
    //     0xc06de0: sub             SP, SP, #0x28
    // 0xc06de4: CheckStackOverflow
    //     0xc06de4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc06de8: cmp             SP, x16
    //     0xc06dec: b.ls            #0xc06fec
    // 0xc06df0: ldr             x3, [fp, #0x20]
    // 0xc06df4: LoadField: r4 = r3->field_7
    //     0xc06df4: ldur            w4, [x3, #7]
    // 0xc06df8: DecompressPointer r4
    //     0xc06df8: add             x4, x4, HEAP, lsl #32
    // 0xc06dfc: ldr             x0, [fp, #0x18]
    // 0xc06e00: mov             x2, x4
    // 0xc06e04: stur            x4, [fp, #-8]
    // 0xc06e08: r1 = Null
    //     0xc06e08: mov             x1, NULL
    // 0xc06e0c: r8 = List<X0>?
    //     0xc06e0c: add             x8, PP, #0xd, lsl #12  ; [pp+0xd740] Type: List<X0>?
    //     0xc06e10: ldr             x8, [x8, #0x740]
    // 0xc06e14: LoadField: r9 = r8->field_7
    //     0xc06e14: ldur            x9, [x8, #7]
    // 0xc06e18: r3 = Null
    //     0xc06e18: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d558] Null
    //     0xc06e1c: ldr             x3, [x3, #0x558]
    // 0xc06e20: blr             x9
    // 0xc06e24: ldr             x0, [fp, #0x10]
    // 0xc06e28: ldur            x2, [fp, #-8]
    // 0xc06e2c: r1 = Null
    //     0xc06e2c: mov             x1, NULL
    // 0xc06e30: r8 = List<X0>?
    //     0xc06e30: add             x8, PP, #0xd, lsl #12  ; [pp+0xd740] Type: List<X0>?
    //     0xc06e34: ldr             x8, [x8, #0x740]
    // 0xc06e38: LoadField: r9 = r8->field_7
    //     0xc06e38: ldur            x9, [x8, #7]
    // 0xc06e3c: r3 = Null
    //     0xc06e3c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d568] Null
    //     0xc06e40: ldr             x3, [x3, #0x568]
    // 0xc06e44: blr             x9
    // 0xc06e48: ldr             x2, [fp, #0x18]
    // 0xc06e4c: ldr             x1, [fp, #0x10]
    // 0xc06e50: cmp             w2, w1
    // 0xc06e54: b.ne            #0xc06e68
    // 0xc06e58: r0 = true
    //     0xc06e58: add             x0, NULL, #0x20  ; true
    // 0xc06e5c: LeaveFrame
    //     0xc06e5c: mov             SP, fp
    //     0xc06e60: ldp             fp, lr, [SP], #0x10
    // 0xc06e64: ret
    //     0xc06e64: ret             
    // 0xc06e68: r0 = LoadClassIdInstr(r2)
    //     0xc06e68: ldur            x0, [x2, #-1]
    //     0xc06e6c: ubfx            x0, x0, #0xc, #0x14
    // 0xc06e70: SaveReg r2
    //     0xc06e70: str             x2, [SP, #-8]!
    // 0xc06e74: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc06e74: mov             x17, #0xb8ea
    //     0xc06e78: add             lr, x0, x17
    //     0xc06e7c: ldr             lr, [x21, lr, lsl #3]
    //     0xc06e80: blr             lr
    // 0xc06e84: add             SP, SP, #8
    // 0xc06e88: mov             x2, x0
    // 0xc06e8c: ldr             x1, [fp, #0x10]
    // 0xc06e90: stur            x2, [fp, #-8]
    // 0xc06e94: r0 = LoadClassIdInstr(r1)
    //     0xc06e94: ldur            x0, [x1, #-1]
    //     0xc06e98: ubfx            x0, x0, #0xc, #0x14
    // 0xc06e9c: SaveReg r1
    //     0xc06e9c: str             x1, [SP, #-8]!
    // 0xc06ea0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc06ea0: mov             x17, #0xb8ea
    //     0xc06ea4: add             lr, x0, x17
    //     0xc06ea8: ldr             lr, [x21, lr, lsl #3]
    //     0xc06eac: blr             lr
    // 0xc06eb0: add             SP, SP, #8
    // 0xc06eb4: mov             x1, x0
    // 0xc06eb8: ldur            x0, [fp, #-8]
    // 0xc06ebc: r2 = LoadInt32Instr(r0)
    //     0xc06ebc: sbfx            x2, x0, #1, #0x1f
    //     0xc06ec0: tbz             w0, #0, #0xc06ec8
    //     0xc06ec4: ldur            x2, [x0, #7]
    // 0xc06ec8: stur            x2, [fp, #-0x20]
    // 0xc06ecc: r0 = LoadInt32Instr(r1)
    //     0xc06ecc: sbfx            x0, x1, #1, #0x1f
    //     0xc06ed0: tbz             w1, #0, #0xc06ed8
    //     0xc06ed4: ldur            x0, [x1, #7]
    // 0xc06ed8: cmp             x2, x0
    // 0xc06edc: b.eq            #0xc06ef0
    // 0xc06ee0: r0 = false
    //     0xc06ee0: add             x0, NULL, #0x30  ; false
    // 0xc06ee4: LeaveFrame
    //     0xc06ee4: mov             SP, fp
    //     0xc06ee8: ldp             fp, lr, [SP], #0x10
    // 0xc06eec: ret
    //     0xc06eec: ret             
    // 0xc06ef0: ldr             x0, [fp, #0x20]
    // 0xc06ef4: LoadField: r3 = r0->field_b
    //     0xc06ef4: ldur            w3, [x0, #0xb]
    // 0xc06ef8: DecompressPointer r3
    //     0xc06ef8: add             x3, x3, HEAP, lsl #32
    // 0xc06efc: stur            x3, [fp, #-0x18]
    // 0xc06f00: r6 = 0
    //     0xc06f00: mov             x6, #0
    // 0xc06f04: ldr             x5, [fp, #0x18]
    // 0xc06f08: ldr             x4, [fp, #0x10]
    // 0xc06f0c: stur            x6, [fp, #-0x10]
    // 0xc06f10: CheckStackOverflow
    //     0xc06f10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc06f14: cmp             SP, x16
    //     0xc06f18: b.ls            #0xc06ff4
    // 0xc06f1c: cmp             x6, x2
    // 0xc06f20: b.ge            #0xc06fdc
    // 0xc06f24: r0 = BoxInt64Instr(r6)
    //     0xc06f24: sbfiz           x0, x6, #1, #0x1f
    //     0xc06f28: cmp             x6, x0, asr #1
    //     0xc06f2c: b.eq            #0xc06f38
    //     0xc06f30: bl              #0xd69bb8
    //     0xc06f34: stur            x6, [x0, #7]
    // 0xc06f38: mov             x1, x0
    // 0xc06f3c: stur            x1, [fp, #-8]
    // 0xc06f40: r0 = LoadClassIdInstr(r5)
    //     0xc06f40: ldur            x0, [x5, #-1]
    //     0xc06f44: ubfx            x0, x0, #0xc, #0x14
    // 0xc06f48: stp             x1, x5, [SP, #-0x10]!
    // 0xc06f4c: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc06f4c: sub             lr, x0, #0xd83
    //     0xc06f50: ldr             lr, [x21, lr, lsl #3]
    //     0xc06f54: blr             lr
    // 0xc06f58: add             SP, SP, #0x10
    // 0xc06f5c: mov             x2, x0
    // 0xc06f60: ldr             x1, [fp, #0x10]
    // 0xc06f64: stur            x2, [fp, #-0x28]
    // 0xc06f68: r0 = LoadClassIdInstr(r1)
    //     0xc06f68: ldur            x0, [x1, #-1]
    //     0xc06f6c: ubfx            x0, x0, #0xc, #0x14
    // 0xc06f70: ldur            x16, [fp, #-8]
    // 0xc06f74: stp             x16, x1, [SP, #-0x10]!
    // 0xc06f78: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc06f78: sub             lr, x0, #0xd83
    //     0xc06f7c: ldr             lr, [x21, lr, lsl #3]
    //     0xc06f80: blr             lr
    // 0xc06f84: add             SP, SP, #0x10
    // 0xc06f88: ldur            x1, [fp, #-0x18]
    // 0xc06f8c: r2 = LoadClassIdInstr(r1)
    //     0xc06f8c: ldur            x2, [x1, #-1]
    //     0xc06f90: ubfx            x2, x2, #0xc, #0x14
    // 0xc06f94: ldur            x16, [fp, #-0x28]
    // 0xc06f98: stp             x16, x1, [SP, #-0x10]!
    // 0xc06f9c: SaveReg r0
    //     0xc06f9c: str             x0, [SP, #-8]!
    // 0xc06fa0: mov             x0, x2
    // 0xc06fa4: r0 = GDT[cid_x0 + 0xbc2]()
    //     0xc06fa4: add             lr, x0, #0xbc2
    //     0xc06fa8: ldr             lr, [x21, lr, lsl #3]
    //     0xc06fac: blr             lr
    // 0xc06fb0: add             SP, SP, #0x18
    // 0xc06fb4: tbz             w0, #4, #0xc06fc8
    // 0xc06fb8: r0 = false
    //     0xc06fb8: add             x0, NULL, #0x30  ; false
    // 0xc06fbc: LeaveFrame
    //     0xc06fbc: mov             SP, fp
    //     0xc06fc0: ldp             fp, lr, [SP], #0x10
    // 0xc06fc4: ret
    //     0xc06fc4: ret             
    // 0xc06fc8: ldur            x1, [fp, #-0x10]
    // 0xc06fcc: add             x6, x1, #1
    // 0xc06fd0: ldur            x3, [fp, #-0x18]
    // 0xc06fd4: ldur            x2, [fp, #-0x20]
    // 0xc06fd8: b               #0xc06f04
    // 0xc06fdc: r0 = true
    //     0xc06fdc: add             x0, NULL, #0x20  ; true
    // 0xc06fe0: LeaveFrame
    //     0xc06fe0: mov             SP, fp
    //     0xc06fe4: ldp             fp, lr, [SP], #0x10
    // 0xc06fe8: ret
    //     0xc06fe8: ret             
    // 0xc06fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06fec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06ff0: b               #0xc06df0
    // 0xc06ff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06ff4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06ff8: b               #0xc06f1c
  }
}

// class id: 4780, size: 0x10, field offset: 0x8
//   const constructor, 
class IterableEquality<X0> extends Object
    implements Equality<X0> {

  _ hash(/* No info */) {
    // ** addr: 0xc048a4, size: 0x180
    // 0xc048a4: EnterFrame
    //     0xc048a4: stp             fp, lr, [SP, #-0x10]!
    //     0xc048a8: mov             fp, SP
    // 0xc048ac: AllocStack(0x18)
    //     0xc048ac: sub             SP, SP, #0x18
    // 0xc048b0: CheckStackOverflow
    //     0xc048b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc048b4: cmp             SP, x16
    //     0xc048b8: b.ls            #0xc04a14
    // 0xc048bc: ldr             x3, [fp, #0x18]
    // 0xc048c0: LoadField: r2 = r3->field_7
    //     0xc048c0: ldur            w2, [x3, #7]
    // 0xc048c4: DecompressPointer r2
    //     0xc048c4: add             x2, x2, HEAP, lsl #32
    // 0xc048c8: ldr             x0, [fp, #0x10]
    // 0xc048cc: r1 = Null
    //     0xc048cc: mov             x1, NULL
    // 0xc048d0: r8 = Iterable<X0>?
    //     0xc048d0: ldr             x8, [PP, #0x3150]  ; [pp+0x3150] Type: Iterable<X0>?
    // 0xc048d4: LoadField: r9 = r8->field_7
    //     0xc048d4: ldur            x9, [x8, #7]
    // 0xc048d8: r3 = Null
    //     0xc048d8: add             x3, PP, #0x42, lsl #12  ; [pp+0x427d0] Null
    //     0xc048dc: ldr             x3, [x3, #0x7d0]
    // 0xc048e0: blr             x9
    // 0xc048e4: ldr             x0, [fp, #0x10]
    // 0xc048e8: r1 = LoadClassIdInstr(r0)
    //     0xc048e8: ldur            x1, [x0, #-1]
    //     0xc048ec: ubfx            x1, x1, #0xc, #0x14
    // 0xc048f0: SaveReg r0
    //     0xc048f0: str             x0, [SP, #-8]!
    // 0xc048f4: mov             x0, x1
    // 0xc048f8: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc048f8: mov             x17, #0xb940
    //     0xc048fc: add             lr, x0, x17
    //     0xc04900: ldr             lr, [x21, lr, lsl #3]
    //     0xc04904: blr             lr
    // 0xc04908: add             SP, SP, #8
    // 0xc0490c: mov             x1, x0
    // 0xc04910: ldr             x0, [fp, #0x18]
    // 0xc04914: stur            x1, [fp, #-0x18]
    // 0xc04918: LoadField: r2 = r0->field_b
    //     0xc04918: ldur            w2, [x0, #0xb]
    // 0xc0491c: DecompressPointer r2
    //     0xc0491c: add             x2, x2, HEAP, lsl #32
    // 0xc04920: stur            x2, [fp, #-0x10]
    // 0xc04924: r3 = 0
    //     0xc04924: mov             x3, #0
    // 0xc04928: stur            x3, [fp, #-8]
    // 0xc0492c: CheckStackOverflow
    //     0xc0492c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc04930: cmp             SP, x16
    //     0xc04934: b.ls            #0xc04a1c
    // 0xc04938: r0 = LoadClassIdInstr(r1)
    //     0xc04938: ldur            x0, [x1, #-1]
    //     0xc0493c: ubfx            x0, x0, #0xc, #0x14
    // 0xc04940: SaveReg r1
    //     0xc04940: str             x1, [SP, #-8]!
    // 0xc04944: r0 = GDT[cid_x0 + 0x541]()
    //     0xc04944: add             lr, x0, #0x541
    //     0xc04948: ldr             lr, [x21, lr, lsl #3]
    //     0xc0494c: blr             lr
    // 0xc04950: add             SP, SP, #8
    // 0xc04954: tbnz            w0, #4, #0xc049cc
    // 0xc04958: ldur            x1, [fp, #-0x18]
    // 0xc0495c: r0 = LoadClassIdInstr(r1)
    //     0xc0495c: ldur            x0, [x1, #-1]
    //     0xc04960: ubfx            x0, x0, #0xc, #0x14
    // 0xc04964: SaveReg r1
    //     0xc04964: str             x1, [SP, #-8]!
    // 0xc04968: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc04968: add             lr, x0, #0x5ca
    //     0xc0496c: ldr             lr, [x21, lr, lsl #3]
    //     0xc04970: blr             lr
    // 0xc04974: add             SP, SP, #8
    // 0xc04978: ldur            x16, [fp, #-0x10]
    // 0xc0497c: stp             x0, x16, [SP, #-0x10]!
    // 0xc04980: r0 = hash()
    //     0xc04980: bl              #0xc05368  ; [package:collection/src/equality.dart] DeepCollectionEquality::hash
    // 0xc04984: add             SP, SP, #0x10
    // 0xc04988: ldur            x1, [fp, #-8]
    // 0xc0498c: ubfx            x1, x1, #0, #0x20
    // 0xc04990: ubfx            x0, x0, #0, #0x20
    // 0xc04994: add             w2, w1, w0
    // 0xc04998: r1 = 2147483647
    //     0xc04998: mov             x1, #0x7fffffff
    // 0xc0499c: and             x3, x2, x1
    // 0xc049a0: lsl             w2, w3, #0xa
    // 0xc049a4: add             w4, w3, w2
    // 0xc049a8: and             x2, x4, x1
    // 0xc049ac: mov             x3, x2
    // 0xc049b0: ubfx            x3, x3, #0, #0x20
    // 0xc049b4: asr             x4, x3, #6
    // 0xc049b8: ubfx            x2, x2, #0, #0x20
    // 0xc049bc: eor             x3, x2, x4
    // 0xc049c0: ldur            x1, [fp, #-0x18]
    // 0xc049c4: ldur            x2, [fp, #-0x10]
    // 0xc049c8: b               #0xc04928
    // 0xc049cc: r1 = 2147483647
    //     0xc049cc: mov             x1, #0x7fffffff
    // 0xc049d0: ldur            x2, [fp, #-8]
    // 0xc049d4: ubfx            x2, x2, #0, #0x20
    // 0xc049d8: lsl             w3, w2, #3
    // 0xc049dc: ldur            x2, [fp, #-8]
    // 0xc049e0: ubfx            x2, x2, #0, #0x20
    // 0xc049e4: add             w4, w2, w3
    // 0xc049e8: and             x2, x4, x1
    // 0xc049ec: lsr             w3, w2, #0xb
    // 0xc049f0: eor             x4, x2, x3
    // 0xc049f4: lsl             w2, w4, #0xf
    // 0xc049f8: add             w3, w4, w2
    // 0xc049fc: and             x2, x3, x1
    // 0xc04a00: ubfx            x2, x2, #0, #0x20
    // 0xc04a04: mov             x0, x2
    // 0xc04a08: LeaveFrame
    //     0xc04a08: mov             SP, fp
    //     0xc04a0c: ldp             fp, lr, [SP], #0x10
    // 0xc04a10: ret
    //     0xc04a10: ret             
    // 0xc04a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc04a14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc04a18: b               #0xc048bc
    // 0xc04a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc04a1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc04a20: b               #0xc04938
  }
  _ equals(/* No info */) {
    // ** addr: 0xc06bc4, size: 0x214
    // 0xc06bc4: EnterFrame
    //     0xc06bc4: stp             fp, lr, [SP, #-0x10]!
    //     0xc06bc8: mov             fp, SP
    // 0xc06bcc: AllocStack(0x20)
    //     0xc06bcc: sub             SP, SP, #0x20
    // 0xc06bd0: CheckStackOverflow
    //     0xc06bd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc06bd4: cmp             SP, x16
    //     0xc06bd8: b.ls            #0xc06dc8
    // 0xc06bdc: ldr             x3, [fp, #0x20]
    // 0xc06be0: LoadField: r4 = r3->field_7
    //     0xc06be0: ldur            w4, [x3, #7]
    // 0xc06be4: DecompressPointer r4
    //     0xc06be4: add             x4, x4, HEAP, lsl #32
    // 0xc06be8: ldr             x0, [fp, #0x18]
    // 0xc06bec: mov             x2, x4
    // 0xc06bf0: stur            x4, [fp, #-8]
    // 0xc06bf4: r1 = Null
    //     0xc06bf4: mov             x1, NULL
    // 0xc06bf8: r8 = Iterable<X0>?
    //     0xc06bf8: ldr             x8, [PP, #0x3150]  ; [pp+0x3150] Type: Iterable<X0>?
    // 0xc06bfc: LoadField: r9 = r8->field_7
    //     0xc06bfc: ldur            x9, [x8, #7]
    // 0xc06c00: r3 = Null
    //     0xc06c00: add             x3, PP, #0x42, lsl #12  ; [pp+0x42678] Null
    //     0xc06c04: ldr             x3, [x3, #0x678]
    // 0xc06c08: blr             x9
    // 0xc06c0c: ldr             x0, [fp, #0x10]
    // 0xc06c10: ldur            x2, [fp, #-8]
    // 0xc06c14: r1 = Null
    //     0xc06c14: mov             x1, NULL
    // 0xc06c18: r8 = Iterable<X0>?
    //     0xc06c18: ldr             x8, [PP, #0x3150]  ; [pp+0x3150] Type: Iterable<X0>?
    // 0xc06c1c: LoadField: r9 = r8->field_7
    //     0xc06c1c: ldur            x9, [x8, #7]
    // 0xc06c20: r3 = Null
    //     0xc06c20: add             x3, PP, #0x42, lsl #12  ; [pp+0x42688] Null
    //     0xc06c24: ldr             x3, [x3, #0x688]
    // 0xc06c28: blr             x9
    // 0xc06c2c: ldr             x0, [fp, #0x18]
    // 0xc06c30: ldr             x1, [fp, #0x10]
    // 0xc06c34: cmp             w0, w1
    // 0xc06c38: b.ne            #0xc06c4c
    // 0xc06c3c: r0 = true
    //     0xc06c3c: add             x0, NULL, #0x20  ; true
    // 0xc06c40: LeaveFrame
    //     0xc06c40: mov             SP, fp
    //     0xc06c44: ldp             fp, lr, [SP], #0x10
    // 0xc06c48: ret
    //     0xc06c48: ret             
    // 0xc06c4c: ldr             x2, [fp, #0x20]
    // 0xc06c50: r3 = LoadClassIdInstr(r0)
    //     0xc06c50: ldur            x3, [x0, #-1]
    //     0xc06c54: ubfx            x3, x3, #0xc, #0x14
    // 0xc06c58: SaveReg r0
    //     0xc06c58: str             x0, [SP, #-8]!
    // 0xc06c5c: mov             x0, x3
    // 0xc06c60: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc06c60: mov             x17, #0xb940
    //     0xc06c64: add             lr, x0, x17
    //     0xc06c68: ldr             lr, [x21, lr, lsl #3]
    //     0xc06c6c: blr             lr
    // 0xc06c70: add             SP, SP, #8
    // 0xc06c74: mov             x1, x0
    // 0xc06c78: ldr             x0, [fp, #0x10]
    // 0xc06c7c: stur            x1, [fp, #-8]
    // 0xc06c80: r2 = LoadClassIdInstr(r0)
    //     0xc06c80: ldur            x2, [x0, #-1]
    //     0xc06c84: ubfx            x2, x2, #0xc, #0x14
    // 0xc06c88: SaveReg r0
    //     0xc06c88: str             x0, [SP, #-8]!
    // 0xc06c8c: mov             x0, x2
    // 0xc06c90: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc06c90: mov             x17, #0xb940
    //     0xc06c94: add             lr, x0, x17
    //     0xc06c98: ldr             lr, [x21, lr, lsl #3]
    //     0xc06c9c: blr             lr
    // 0xc06ca0: add             SP, SP, #8
    // 0xc06ca4: mov             x1, x0
    // 0xc06ca8: ldr             x0, [fp, #0x20]
    // 0xc06cac: stur            x1, [fp, #-0x18]
    // 0xc06cb0: LoadField: r2 = r0->field_b
    //     0xc06cb0: ldur            w2, [x0, #0xb]
    // 0xc06cb4: DecompressPointer r2
    //     0xc06cb4: add             x2, x2, HEAP, lsl #32
    // 0xc06cb8: stur            x2, [fp, #-0x10]
    // 0xc06cbc: ldur            x3, [fp, #-8]
    // 0xc06cc0: CheckStackOverflow
    //     0xc06cc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc06cc4: cmp             SP, x16
    //     0xc06cc8: b.ls            #0xc06dd0
    // 0xc06ccc: r0 = LoadClassIdInstr(r3)
    //     0xc06ccc: ldur            x0, [x3, #-1]
    //     0xc06cd0: ubfx            x0, x0, #0xc, #0x14
    // 0xc06cd4: SaveReg r3
    //     0xc06cd4: str             x3, [SP, #-8]!
    // 0xc06cd8: r0 = GDT[cid_x0 + 0x541]()
    //     0xc06cd8: add             lr, x0, #0x541
    //     0xc06cdc: ldr             lr, [x21, lr, lsl #3]
    //     0xc06ce0: blr             lr
    // 0xc06ce4: add             SP, SP, #8
    // 0xc06ce8: mov             x2, x0
    // 0xc06cec: ldur            x1, [fp, #-0x18]
    // 0xc06cf0: stur            x2, [fp, #-0x20]
    // 0xc06cf4: r0 = LoadClassIdInstr(r1)
    //     0xc06cf4: ldur            x0, [x1, #-1]
    //     0xc06cf8: ubfx            x0, x0, #0xc, #0x14
    // 0xc06cfc: SaveReg r1
    //     0xc06cfc: str             x1, [SP, #-8]!
    // 0xc06d00: r0 = GDT[cid_x0 + 0x541]()
    //     0xc06d00: add             lr, x0, #0x541
    //     0xc06d04: ldr             lr, [x21, lr, lsl #3]
    //     0xc06d08: blr             lr
    // 0xc06d0c: add             SP, SP, #8
    // 0xc06d10: mov             x1, x0
    // 0xc06d14: ldur            x0, [fp, #-0x20]
    // 0xc06d18: cmp             w0, w1
    // 0xc06d1c: b.eq            #0xc06d30
    // 0xc06d20: r0 = false
    //     0xc06d20: add             x0, NULL, #0x30  ; false
    // 0xc06d24: LeaveFrame
    //     0xc06d24: mov             SP, fp
    //     0xc06d28: ldp             fp, lr, [SP], #0x10
    // 0xc06d2c: ret
    //     0xc06d2c: ret             
    // 0xc06d30: tbz             w0, #4, #0xc06d44
    // 0xc06d34: r0 = true
    //     0xc06d34: add             x0, NULL, #0x20  ; true
    // 0xc06d38: LeaveFrame
    //     0xc06d38: mov             SP, fp
    //     0xc06d3c: ldp             fp, lr, [SP], #0x10
    // 0xc06d40: ret
    //     0xc06d40: ret             
    // 0xc06d44: ldur            x2, [fp, #-8]
    // 0xc06d48: ldur            x1, [fp, #-0x18]
    // 0xc06d4c: r0 = LoadClassIdInstr(r2)
    //     0xc06d4c: ldur            x0, [x2, #-1]
    //     0xc06d50: ubfx            x0, x0, #0xc, #0x14
    // 0xc06d54: SaveReg r2
    //     0xc06d54: str             x2, [SP, #-8]!
    // 0xc06d58: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc06d58: add             lr, x0, #0x5ca
    //     0xc06d5c: ldr             lr, [x21, lr, lsl #3]
    //     0xc06d60: blr             lr
    // 0xc06d64: add             SP, SP, #8
    // 0xc06d68: mov             x2, x0
    // 0xc06d6c: ldur            x1, [fp, #-0x18]
    // 0xc06d70: stur            x2, [fp, #-0x20]
    // 0xc06d74: r0 = LoadClassIdInstr(r1)
    //     0xc06d74: ldur            x0, [x1, #-1]
    //     0xc06d78: ubfx            x0, x0, #0xc, #0x14
    // 0xc06d7c: SaveReg r1
    //     0xc06d7c: str             x1, [SP, #-8]!
    // 0xc06d80: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc06d80: add             lr, x0, #0x5ca
    //     0xc06d84: ldr             lr, [x21, lr, lsl #3]
    //     0xc06d88: blr             lr
    // 0xc06d8c: add             SP, SP, #8
    // 0xc06d90: ldur            x16, [fp, #-0x10]
    // 0xc06d94: ldur            lr, [fp, #-0x20]
    // 0xc06d98: stp             lr, x16, [SP, #-0x10]!
    // 0xc06d9c: SaveReg r0
    //     0xc06d9c: str             x0, [SP, #-8]!
    // 0xc06da0: r0 = equals()
    //     0xc06da0: bl              #0xc07d34  ; [package:collection/src/equality.dart] DeepCollectionEquality::equals
    // 0xc06da4: add             SP, SP, #0x18
    // 0xc06da8: tbz             w0, #4, #0xc06dbc
    // 0xc06dac: r0 = false
    //     0xc06dac: add             x0, NULL, #0x30  ; false
    // 0xc06db0: LeaveFrame
    //     0xc06db0: mov             SP, fp
    //     0xc06db4: ldp             fp, lr, [SP], #0x10
    // 0xc06db8: ret
    //     0xc06db8: ret             
    // 0xc06dbc: ldur            x1, [fp, #-0x18]
    // 0xc06dc0: ldur            x2, [fp, #-0x10]
    // 0xc06dc4: b               #0xc06cbc
    // 0xc06dc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06dc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06dcc: b               #0xc06bdc
    // 0xc06dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06dd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06dd4: b               #0xc06ccc
  }
}

// class id: 4781, size: 0xc, field offset: 0x8
//   const constructor, 
class DefaultEquality<X0> extends Object
    implements Equality<X0> {

  _ hash(/* No info */) {
    // ** addr: 0xc0483c, size: 0x68
    // 0xc0483c: EnterFrame
    //     0xc0483c: stp             fp, lr, [SP, #-0x10]!
    //     0xc04840: mov             fp, SP
    // 0xc04844: CheckStackOverflow
    //     0xc04844: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc04848: cmp             SP, x16
    //     0xc0484c: b.ls            #0xc0489c
    // 0xc04850: ldr             x0, [fp, #0x10]
    // 0xc04854: r1 = 59
    //     0xc04854: mov             x1, #0x3b
    // 0xc04858: branchIfSmi(r0, 0xc04864)
    //     0xc04858: tbz             w0, #0, #0xc04864
    // 0xc0485c: r1 = LoadClassIdInstr(r0)
    //     0xc0485c: ldur            x1, [x0, #-1]
    //     0xc04860: ubfx            x1, x1, #0xc, #0x14
    // 0xc04864: SaveReg r0
    //     0xc04864: str             x0, [SP, #-8]!
    // 0xc04868: mov             x0, x1
    // 0xc0486c: r0 = GDT[cid_x0 + 0x2721]()
    //     0xc0486c: mov             x17, #0x2721
    //     0xc04870: add             lr, x0, x17
    //     0xc04874: ldr             lr, [x21, lr, lsl #3]
    //     0xc04878: blr             lr
    // 0xc0487c: add             SP, SP, #8
    // 0xc04880: r1 = LoadInt32Instr(r0)
    //     0xc04880: sbfx            x1, x0, #1, #0x1f
    //     0xc04884: tbz             w0, #0, #0xc0488c
    //     0xc04888: ldur            x1, [x0, #7]
    // 0xc0488c: mov             x0, x1
    // 0xc04890: LeaveFrame
    //     0xc04890: mov             SP, fp
    //     0xc04894: ldp             fp, lr, [SP], #0x10
    // 0xc04898: ret
    //     0xc04898: ret             
    // 0xc0489c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0489c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc048a0: b               #0xc04850
  }
}

// class id: 4782, size: 0xc, field offset: 0x8
abstract class Equality<X0> extends Object {
}

// lib: , url: package:collection/src/canonicalized_map.dart

// class id: 1048753, size: 0x8
class :: {
}

// class id: 4783, size: 0x18, field offset: 0x8
abstract class CanonicalizedMap<X0, X1, X2> extends Object
    implements Map<X0, X1> {

  X2? [](CanonicalizedMap<X0, X1, X2>, Object?) {
    // ** addr: 0xc6f130, size: 0x1e8
    // 0xc6f130: EnterFrame
    //     0xc6f130: stp             fp, lr, [SP, #-0x10]!
    //     0xc6f134: mov             fp, SP
    // 0xc6f138: AllocStack(0x10)
    //     0xc6f138: sub             SP, SP, #0x10
    // 0xc6f13c: CheckStackOverflow
    //     0xc6f13c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6f140: cmp             SP, x16
    //     0xc6f144: b.ls            #0xc6f2f8
    // 0xc6f148: ldr             x3, [fp, #0x18]
    // 0xc6f14c: LoadField: r4 = r3->field_7
    //     0xc6f14c: ldur            w4, [x3, #7]
    // 0xc6f150: DecompressPointer r4
    //     0xc6f150: add             x4, x4, HEAP, lsl #32
    // 0xc6f154: ldr             x0, [fp, #0x10]
    // 0xc6f158: mov             x2, x4
    // 0xc6f15c: stur            x4, [fp, #-8]
    // 0xc6f160: r1 = Null
    //     0xc6f160: mov             x1, NULL
    // 0xc6f164: cmp             w2, NULL
    // 0xc6f168: b.eq            #0xc6f208
    // 0xc6f16c: LoadField: r3 = r2->field_1b
    //     0xc6f16c: ldur            w3, [x2, #0x1b]
    // 0xc6f170: DecompressPointer r3
    //     0xc6f170: add             x3, x3, HEAP, lsl #32
    // 0xc6f174: ldr             x16, [THR, #0xf0]  ; THR::dynamic_type
    // 0xc6f178: cmp             w3, w16
    // 0xc6f17c: b.eq            #0xc6f208
    // 0xc6f180: r16 = Object?
    //     0xc6f180: ldr             x16, [PP, #0x1878]  ; [pp+0x1878] Type: Object?
    // 0xc6f184: cmp             w3, w16
    // 0xc6f188: b.eq            #0xc6f208
    // 0xc6f18c: r16 = void?
    //     0xc6f18c: ldr             x16, [PP, #0x1880]  ; [pp+0x1880] Type: void?
    // 0xc6f190: cmp             w3, w16
    // 0xc6f194: b.eq            #0xc6f208
    // 0xc6f198: tbnz            w0, #0, #0xc6f1b4
    // 0xc6f19c: r16 = int
    //     0xc6f19c: ldr             x16, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc6f1a0: cmp             w3, w16
    // 0xc6f1a4: b.eq            #0xc6f208
    // 0xc6f1a8: r16 = num
    //     0xc6f1a8: ldr             x16, [PP, #0x1888]  ; [pp+0x1888] Type: num
    // 0xc6f1ac: cmp             w3, w16
    // 0xc6f1b0: b.eq            #0xc6f208
    // 0xc6f1b4: r8 = X1
    //     0xc6f1b4: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d7c8] TypeParameter: X1
    //     0xc6f1b8: ldr             x8, [x8, #0x7c8]
    // 0xc6f1bc: r3 = SubtypeTestCache
    //     0xc6f1bc: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d7d0] SubtypeTestCache
    //     0xc6f1c0: ldr             x3, [x3, #0x7d0]
    // 0xc6f1c4: r24 = Subtype7TestCacheStub
    //     0xc6f1c4: ldr             x24, [PP, #0x18]  ; [pp+0x18] Stub: Subtype7TestCache (0x4ae0ac)
    // 0xc6f1c8: LoadField: r30 = r24->field_7
    //     0xc6f1c8: ldur            lr, [x24, #7]
    // 0xc6f1cc: blr             lr
    // 0xc6f1d0: cmp             w7, NULL
    // 0xc6f1d4: b.eq            #0xc6f1e0
    // 0xc6f1d8: tbnz            w7, #4, #0xc6f200
    // 0xc6f1dc: b               #0xc6f208
    // 0xc6f1e0: r8 = X1
    //     0xc6f1e0: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d7d8] TypeParameter: X1
    //     0xc6f1e4: ldr             x8, [x8, #0x7d8]
    // 0xc6f1e8: r3 = SubtypeTestCache
    //     0xc6f1e8: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d7e0] SubtypeTestCache
    //     0xc6f1ec: ldr             x3, [x3, #0x7e0]
    // 0xc6f1f0: r24 = InstanceOfStub
    //     0xc6f1f0: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc6f1f4: LoadField: r30 = r24->field_7
    //     0xc6f1f4: ldur            lr, [x24, #7]
    // 0xc6f1f8: blr             lr
    // 0xc6f1fc: b               #0xc6f20c
    // 0xc6f200: r0 = false
    //     0xc6f200: add             x0, NULL, #0x30  ; false
    // 0xc6f204: b               #0xc6f20c
    // 0xc6f208: r0 = true
    //     0xc6f208: add             x0, NULL, #0x20  ; true
    // 0xc6f20c: tbnz            w0, #4, #0xc6f2e8
    // 0xc6f210: ldr             x3, [fp, #0x18]
    // 0xc6f214: LoadField: r4 = r3->field_13
    //     0xc6f214: ldur            w4, [x3, #0x13]
    // 0xc6f218: DecompressPointer r4
    //     0xc6f218: add             x4, x4, HEAP, lsl #32
    // 0xc6f21c: ldr             x0, [fp, #0x10]
    // 0xc6f220: ldur            x2, [fp, #-8]
    // 0xc6f224: stur            x4, [fp, #-0x10]
    // 0xc6f228: r1 = Null
    //     0xc6f228: mov             x1, NULL
    // 0xc6f22c: cmp             w2, NULL
    // 0xc6f230: b.eq            #0xc6f250
    // 0xc6f234: LoadField: r4 = r2->field_1b
    //     0xc6f234: ldur            w4, [x2, #0x1b]
    // 0xc6f238: DecompressPointer r4
    //     0xc6f238: add             x4, x4, HEAP, lsl #32
    // 0xc6f23c: r8 = X1
    //     0xc6f23c: ldr             x8, [PP, #0x9a0]  ; [pp+0x9a0] TypeParameter: X1
    // 0xc6f240: LoadField: r9 = r4->field_7
    //     0xc6f240: ldur            x9, [x4, #7]
    // 0xc6f244: r3 = Null
    //     0xc6f244: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d7e8] Null
    //     0xc6f248: ldr             x3, [x3, #0x7e8]
    // 0xc6f24c: blr             x9
    // 0xc6f250: ldr             x0, [fp, #0x18]
    // 0xc6f254: LoadField: r1 = r0->field_b
    //     0xc6f254: ldur            w1, [x0, #0xb]
    // 0xc6f258: DecompressPointer r1
    //     0xc6f258: add             x1, x1, HEAP, lsl #32
    // 0xc6f25c: ldr             x16, [fp, #0x10]
    // 0xc6f260: stp             x16, x1, [SP, #-0x10]!
    // 0xc6f264: mov             x0, x1
    // 0xc6f268: ClosureCall
    //     0xc6f268: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc6f26c: ldur            x2, [x0, #0x1f]
    //     0xc6f270: blr             x2
    // 0xc6f274: add             SP, SP, #0x10
    // 0xc6f278: ldur            x16, [fp, #-0x10]
    // 0xc6f27c: stp             x0, x16, [SP, #-0x10]!
    // 0xc6f280: r0 = _getValueOrData()
    //     0xc6f280: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc6f284: add             SP, SP, #0x10
    // 0xc6f288: mov             x1, x0
    // 0xc6f28c: ldur            x0, [fp, #-0x10]
    // 0xc6f290: LoadField: r2 = r0->field_f
    //     0xc6f290: ldur            w2, [x0, #0xf]
    // 0xc6f294: DecompressPointer r2
    //     0xc6f294: add             x2, x2, HEAP, lsl #32
    // 0xc6f298: cmp             w2, w1
    // 0xc6f29c: b.ne            #0xc6f2a8
    // 0xc6f2a0: r0 = Null
    //     0xc6f2a0: mov             x0, NULL
    // 0xc6f2a4: b               #0xc6f2ac
    // 0xc6f2a8: mov             x0, x1
    // 0xc6f2ac: cmp             w0, NULL
    // 0xc6f2b0: b.ne            #0xc6f2bc
    // 0xc6f2b4: r0 = Null
    //     0xc6f2b4: mov             x0, NULL
    // 0xc6f2b8: b               #0xc6f2dc
    // 0xc6f2bc: r1 = LoadClassIdInstr(r0)
    //     0xc6f2bc: ldur            x1, [x0, #-1]
    //     0xc6f2c0: ubfx            x1, x1, #0xc, #0x14
    // 0xc6f2c4: SaveReg r0
    //     0xc6f2c4: str             x0, [SP, #-8]!
    // 0xc6f2c8: mov             x0, x1
    // 0xc6f2cc: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xc6f2cc: sub             lr, x0, #0xfc4
    //     0xc6f2d0: ldr             lr, [x21, lr, lsl #3]
    //     0xc6f2d4: blr             lr
    // 0xc6f2d8: add             SP, SP, #8
    // 0xc6f2dc: LeaveFrame
    //     0xc6f2dc: mov             SP, fp
    //     0xc6f2e0: ldp             fp, lr, [SP], #0x10
    // 0xc6f2e4: ret
    //     0xc6f2e4: ret             
    // 0xc6f2e8: r0 = Null
    //     0xc6f2e8: mov             x0, NULL
    // 0xc6f2ec: LeaveFrame
    //     0xc6f2ec: mov             SP, fp
    //     0xc6f2f0: ldp             fp, lr, [SP], #0x10
    // 0xc6f2f4: ret
    //     0xc6f2f4: ret             
    // 0xc6f2f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6f2f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6f2fc: b               #0xc6f148
  }
  void []=(CanonicalizedMap<X0, X1, X2>, X1, X2) {
    // ** addr: 0xc5cd38, size: 0x21c
    // 0xc5cd38: EnterFrame
    //     0xc5cd38: stp             fp, lr, [SP, #-0x10]!
    //     0xc5cd3c: mov             fp, SP
    // 0xc5cd40: AllocStack(0x10)
    //     0xc5cd40: sub             SP, SP, #0x10
    // 0xc5cd44: CheckStackOverflow
    //     0xc5cd44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5cd48: cmp             SP, x16
    //     0xc5cd4c: b.ls            #0xc5cf34
    // 0xc5cd50: ldr             x3, [fp, #0x20]
    // 0xc5cd54: LoadField: r4 = r3->field_7
    //     0xc5cd54: ldur            w4, [x3, #7]
    // 0xc5cd58: DecompressPointer r4
    //     0xc5cd58: add             x4, x4, HEAP, lsl #32
    // 0xc5cd5c: ldr             x0, [fp, #0x18]
    // 0xc5cd60: mov             x2, x4
    // 0xc5cd64: stur            x4, [fp, #-8]
    // 0xc5cd68: r1 = Null
    //     0xc5cd68: mov             x1, NULL
    // 0xc5cd6c: cmp             w2, NULL
    // 0xc5cd70: b.eq            #0xc5cd90
    // 0xc5cd74: LoadField: r4 = r2->field_1b
    //     0xc5cd74: ldur            w4, [x2, #0x1b]
    // 0xc5cd78: DecompressPointer r4
    //     0xc5cd78: add             x4, x4, HEAP, lsl #32
    // 0xc5cd7c: r8 = X1
    //     0xc5cd7c: ldr             x8, [PP, #0x9a0]  ; [pp+0x9a0] TypeParameter: X1
    // 0xc5cd80: LoadField: r9 = r4->field_7
    //     0xc5cd80: ldur            x9, [x4, #7]
    // 0xc5cd84: r3 = Null
    //     0xc5cd84: add             x3, PP, #0x13, lsl #12  ; [pp+0x13200] Null
    //     0xc5cd88: ldr             x3, [x3, #0x200]
    // 0xc5cd8c: blr             x9
    // 0xc5cd90: ldr             x0, [fp, #0x10]
    // 0xc5cd94: ldur            x2, [fp, #-8]
    // 0xc5cd98: r1 = Null
    //     0xc5cd98: mov             x1, NULL
    // 0xc5cd9c: cmp             w2, NULL
    // 0xc5cda0: b.eq            #0xc5cdc4
    // 0xc5cda4: LoadField: r4 = r2->field_1f
    //     0xc5cda4: ldur            w4, [x2, #0x1f]
    // 0xc5cda8: DecompressPointer r4
    //     0xc5cda8: add             x4, x4, HEAP, lsl #32
    // 0xc5cdac: r8 = X2
    //     0xc5cdac: add             x8, PP, #0x13, lsl #12  ; [pp+0x13210] TypeParameter: X2
    //     0xc5cdb0: ldr             x8, [x8, #0x210]
    // 0xc5cdb4: LoadField: r9 = r4->field_7
    //     0xc5cdb4: ldur            x9, [x4, #7]
    // 0xc5cdb8: r3 = Null
    //     0xc5cdb8: add             x3, PP, #0x13, lsl #12  ; [pp+0x13218] Null
    //     0xc5cdbc: ldr             x3, [x3, #0x218]
    // 0xc5cdc0: blr             x9
    // 0xc5cdc4: ldr             x0, [fp, #0x18]
    // 0xc5cdc8: ldur            x2, [fp, #-8]
    // 0xc5cdcc: r1 = Null
    //     0xc5cdcc: mov             x1, NULL
    // 0xc5cdd0: cmp             w2, NULL
    // 0xc5cdd4: b.eq            #0xc5ce74
    // 0xc5cdd8: LoadField: r3 = r2->field_1b
    //     0xc5cdd8: ldur            w3, [x2, #0x1b]
    // 0xc5cddc: DecompressPointer r3
    //     0xc5cddc: add             x3, x3, HEAP, lsl #32
    // 0xc5cde0: ldr             x16, [THR, #0xf0]  ; THR::dynamic_type
    // 0xc5cde4: cmp             w3, w16
    // 0xc5cde8: b.eq            #0xc5ce74
    // 0xc5cdec: r16 = Object?
    //     0xc5cdec: ldr             x16, [PP, #0x1878]  ; [pp+0x1878] Type: Object?
    // 0xc5cdf0: cmp             w3, w16
    // 0xc5cdf4: b.eq            #0xc5ce74
    // 0xc5cdf8: r16 = void?
    //     0xc5cdf8: ldr             x16, [PP, #0x1880]  ; [pp+0x1880] Type: void?
    // 0xc5cdfc: cmp             w3, w16
    // 0xc5ce00: b.eq            #0xc5ce74
    // 0xc5ce04: tbnz            w0, #0, #0xc5ce20
    // 0xc5ce08: r16 = int
    //     0xc5ce08: ldr             x16, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc5ce0c: cmp             w3, w16
    // 0xc5ce10: b.eq            #0xc5ce74
    // 0xc5ce14: r16 = num
    //     0xc5ce14: ldr             x16, [PP, #0x1888]  ; [pp+0x1888] Type: num
    // 0xc5ce18: cmp             w3, w16
    // 0xc5ce1c: b.eq            #0xc5ce74
    // 0xc5ce20: r8 = X1
    //     0xc5ce20: add             x8, PP, #0x13, lsl #12  ; [pp+0x13228] TypeParameter: X1
    //     0xc5ce24: ldr             x8, [x8, #0x228]
    // 0xc5ce28: r3 = SubtypeTestCache
    //     0xc5ce28: add             x3, PP, #0x13, lsl #12  ; [pp+0x13230] SubtypeTestCache
    //     0xc5ce2c: ldr             x3, [x3, #0x230]
    // 0xc5ce30: r24 = Subtype7TestCacheStub
    //     0xc5ce30: ldr             x24, [PP, #0x18]  ; [pp+0x18] Stub: Subtype7TestCache (0x4ae0ac)
    // 0xc5ce34: LoadField: r30 = r24->field_7
    //     0xc5ce34: ldur            lr, [x24, #7]
    // 0xc5ce38: blr             lr
    // 0xc5ce3c: cmp             w7, NULL
    // 0xc5ce40: b.eq            #0xc5ce4c
    // 0xc5ce44: tbnz            w7, #4, #0xc5ce6c
    // 0xc5ce48: b               #0xc5ce74
    // 0xc5ce4c: r8 = X1
    //     0xc5ce4c: add             x8, PP, #0x13, lsl #12  ; [pp+0x13238] TypeParameter: X1
    //     0xc5ce50: ldr             x8, [x8, #0x238]
    // 0xc5ce54: r3 = SubtypeTestCache
    //     0xc5ce54: add             x3, PP, #0x13, lsl #12  ; [pp+0x13240] SubtypeTestCache
    //     0xc5ce58: ldr             x3, [x3, #0x240]
    // 0xc5ce5c: r24 = InstanceOfStub
    //     0xc5ce5c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc5ce60: LoadField: r30 = r24->field_7
    //     0xc5ce60: ldur            lr, [x24, #7]
    // 0xc5ce64: blr             lr
    // 0xc5ce68: b               #0xc5ce78
    // 0xc5ce6c: r0 = false
    //     0xc5ce6c: add             x0, NULL, #0x30  ; false
    // 0xc5ce70: b               #0xc5ce78
    // 0xc5ce74: r0 = true
    //     0xc5ce74: add             x0, NULL, #0x20  ; true
    // 0xc5ce78: tbnz            w0, #4, #0xc5cf24
    // 0xc5ce7c: ldr             x0, [fp, #0x20]
    // 0xc5ce80: ldr             x2, [fp, #0x18]
    // 0xc5ce84: ldr             x1, [fp, #0x10]
    // 0xc5ce88: LoadField: r3 = r0->field_13
    //     0xc5ce88: ldur            w3, [x0, #0x13]
    // 0xc5ce8c: DecompressPointer r3
    //     0xc5ce8c: add             x3, x3, HEAP, lsl #32
    // 0xc5ce90: stur            x3, [fp, #-0x10]
    // 0xc5ce94: LoadField: r4 = r0->field_b
    //     0xc5ce94: ldur            w4, [x0, #0xb]
    // 0xc5ce98: DecompressPointer r4
    //     0xc5ce98: add             x4, x4, HEAP, lsl #32
    // 0xc5ce9c: stp             x2, x4, [SP, #-0x10]!
    // 0xc5cea0: mov             x0, x4
    // 0xc5cea4: ClosureCall
    //     0xc5cea4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc5cea8: ldur            x2, [x0, #0x1f]
    //     0xc5ceac: blr             x2
    // 0xc5ceb0: add             SP, SP, #0x10
    // 0xc5ceb4: ldur            x2, [fp, #-8]
    // 0xc5ceb8: r1 = Null
    //     0xc5ceb8: mov             x1, NULL
    // 0xc5cebc: r3 = <X1, X2>
    //     0xc5cebc: add             x3, PP, #0x13, lsl #12  ; [pp+0x13248] TypeArguments: <X1, X2>
    //     0xc5cec0: ldr             x3, [x3, #0x248]
    // 0xc5cec4: stur            x0, [fp, #-8]
    // 0xc5cec8: r0 = Null
    //     0xc5cec8: mov             x0, NULL
    // 0xc5cecc: cmp             x2, x0
    // 0xc5ced0: b.eq            #0xc5cee0
    // 0xc5ced4: r24 = InstantiateTypeArgumentsStub
    //     0xc5ced4: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xc5ced8: LoadField: r30 = r24->field_7
    //     0xc5ced8: ldur            lr, [x24, #7]
    // 0xc5cedc: blr             lr
    // 0xc5cee0: mov             x1, x0
    // 0xc5cee4: r0 = MapEntry()
    //     0xc5cee4: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xc5cee8: mov             x1, x0
    // 0xc5ceec: ldr             x0, [fp, #0x18]
    // 0xc5cef0: StoreField: r1->field_b = r0
    //     0xc5cef0: stur            w0, [x1, #0xb]
    // 0xc5cef4: ldr             x0, [fp, #0x10]
    // 0xc5cef8: StoreField: r1->field_f = r0
    //     0xc5cef8: stur            w0, [x1, #0xf]
    // 0xc5cefc: ldur            x16, [fp, #-0x10]
    // 0xc5cf00: ldur            lr, [fp, #-8]
    // 0xc5cf04: stp             lr, x16, [SP, #-0x10]!
    // 0xc5cf08: SaveReg r1
    //     0xc5cf08: str             x1, [SP, #-8]!
    // 0xc5cf0c: r0 = []=()
    //     0xc5cf0c: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xc5cf10: add             SP, SP, #0x18
    // 0xc5cf14: r0 = Null
    //     0xc5cf14: mov             x0, NULL
    // 0xc5cf18: LeaveFrame
    //     0xc5cf18: mov             SP, fp
    //     0xc5cf1c: ldp             fp, lr, [SP], #0x10
    // 0xc5cf20: ret
    //     0xc5cf20: ret             
    // 0xc5cf24: r0 = Null
    //     0xc5cf24: mov             x0, NULL
    // 0xc5cf28: LeaveFrame
    //     0xc5cf28: mov             SP, fp
    //     0xc5cf2c: ldp             fp, lr, [SP], #0x10
    // 0xc5cf30: ret
    //     0xc5cf30: ret             
    // 0xc5cf34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5cf34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5cf38: b               #0xc5cd50
  }
  Map<Y0, Y1> cast<Y0, Y1>(CanonicalizedMap<X0, X1, X2>) {
    // ** addr: 0xc5cc28, size: 0x70
    // 0xc5cc28: EnterFrame
    //     0xc5cc28: stp             fp, lr, [SP, #-0x10]!
    //     0xc5cc2c: mov             fp, SP
    // 0xc5cc30: mov             x0, x4
    // 0xc5cc34: LoadField: r1 = r0->field_f
    //     0xc5cc34: ldur            w1, [x0, #0xf]
    // 0xc5cc38: DecompressPointer r1
    //     0xc5cc38: add             x1, x1, HEAP, lsl #32
    // 0xc5cc3c: cbnz            w1, #0xc5cc48
    // 0xc5cc40: r1 = Null
    //     0xc5cc40: mov             x1, NULL
    // 0xc5cc44: b               #0xc5cc5c
    // 0xc5cc48: LoadField: r1 = r0->field_17
    //     0xc5cc48: ldur            w1, [x0, #0x17]
    // 0xc5cc4c: DecompressPointer r1
    //     0xc5cc4c: add             x1, x1, HEAP, lsl #32
    // 0xc5cc50: add             x0, fp, w1, sxtw #2
    // 0xc5cc54: ldr             x0, [x0, #0x10]
    // 0xc5cc58: mov             x1, x0
    // 0xc5cc5c: ldr             x0, [fp, #0x10]
    // 0xc5cc60: CheckStackOverflow
    //     0xc5cc60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5cc64: cmp             SP, x16
    //     0xc5cc68: b.ls            #0xc5cc90
    // 0xc5cc6c: LoadField: r2 = r0->field_13
    //     0xc5cc6c: ldur            w2, [x0, #0x13]
    // 0xc5cc70: DecompressPointer r2
    //     0xc5cc70: add             x2, x2, HEAP, lsl #32
    // 0xc5cc74: stp             x2, x1, [SP, #-0x10]!
    // 0xc5cc78: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xc5cc78: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xc5cc7c: r0 = cast()
    //     0xc5cc7c: bl              #0xcae624  ; [dart:collection] MapMixin::cast
    // 0xc5cc80: add             SP, SP, #0x10
    // 0xc5cc84: LeaveFrame
    //     0xc5cc84: mov             SP, fp
    //     0xc5cc88: ldp             fp, lr, [SP], #0x10
    // 0xc5cc8c: ret
    //     0xc5cc8c: ret             
    // 0xc5cc90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5cc90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5cc94: b               #0xc5cc6c
  }
  bool containsKey(CanonicalizedMap<X0, X1, X2>, Object?) {
    // ** addr: 0xc5b2bc, size: 0x194
    // 0xc5b2bc: EnterFrame
    //     0xc5b2bc: stp             fp, lr, [SP, #-0x10]!
    //     0xc5b2c0: mov             fp, SP
    // 0xc5b2c4: AllocStack(0x10)
    //     0xc5b2c4: sub             SP, SP, #0x10
    // 0xc5b2c8: CheckStackOverflow
    //     0xc5b2c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5b2cc: cmp             SP, x16
    //     0xc5b2d0: b.ls            #0xc5b430
    // 0xc5b2d4: ldr             x3, [fp, #0x18]
    // 0xc5b2d8: LoadField: r4 = r3->field_7
    //     0xc5b2d8: ldur            w4, [x3, #7]
    // 0xc5b2dc: DecompressPointer r4
    //     0xc5b2dc: add             x4, x4, HEAP, lsl #32
    // 0xc5b2e0: ldr             x0, [fp, #0x10]
    // 0xc5b2e4: mov             x2, x4
    // 0xc5b2e8: stur            x4, [fp, #-8]
    // 0xc5b2ec: r1 = Null
    //     0xc5b2ec: mov             x1, NULL
    // 0xc5b2f0: cmp             w2, NULL
    // 0xc5b2f4: b.eq            #0xc5b394
    // 0xc5b2f8: LoadField: r3 = r2->field_1b
    //     0xc5b2f8: ldur            w3, [x2, #0x1b]
    // 0xc5b2fc: DecompressPointer r3
    //     0xc5b2fc: add             x3, x3, HEAP, lsl #32
    // 0xc5b300: ldr             x16, [THR, #0xf0]  ; THR::dynamic_type
    // 0xc5b304: cmp             w3, w16
    // 0xc5b308: b.eq            #0xc5b394
    // 0xc5b30c: r16 = Object?
    //     0xc5b30c: ldr             x16, [PP, #0x1878]  ; [pp+0x1878] Type: Object?
    // 0xc5b310: cmp             w3, w16
    // 0xc5b314: b.eq            #0xc5b394
    // 0xc5b318: r16 = void?
    //     0xc5b318: ldr             x16, [PP, #0x1880]  ; [pp+0x1880] Type: void?
    // 0xc5b31c: cmp             w3, w16
    // 0xc5b320: b.eq            #0xc5b394
    // 0xc5b324: tbnz            w0, #0, #0xc5b340
    // 0xc5b328: r16 = int
    //     0xc5b328: ldr             x16, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc5b32c: cmp             w3, w16
    // 0xc5b330: b.eq            #0xc5b394
    // 0xc5b334: r16 = num
    //     0xc5b334: ldr             x16, [PP, #0x1888]  ; [pp+0x1888] Type: num
    // 0xc5b338: cmp             w3, w16
    // 0xc5b33c: b.eq            #0xc5b394
    // 0xc5b340: r8 = X1
    //     0xc5b340: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d798] TypeParameter: X1
    //     0xc5b344: ldr             x8, [x8, #0x798]
    // 0xc5b348: r3 = SubtypeTestCache
    //     0xc5b348: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d7a0] SubtypeTestCache
    //     0xc5b34c: ldr             x3, [x3, #0x7a0]
    // 0xc5b350: r24 = Subtype7TestCacheStub
    //     0xc5b350: ldr             x24, [PP, #0x18]  ; [pp+0x18] Stub: Subtype7TestCache (0x4ae0ac)
    // 0xc5b354: LoadField: r30 = r24->field_7
    //     0xc5b354: ldur            lr, [x24, #7]
    // 0xc5b358: blr             lr
    // 0xc5b35c: cmp             w7, NULL
    // 0xc5b360: b.eq            #0xc5b36c
    // 0xc5b364: tbnz            w7, #4, #0xc5b38c
    // 0xc5b368: b               #0xc5b394
    // 0xc5b36c: r8 = X1
    //     0xc5b36c: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d7a8] TypeParameter: X1
    //     0xc5b370: ldr             x8, [x8, #0x7a8]
    // 0xc5b374: r3 = SubtypeTestCache
    //     0xc5b374: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d7b0] SubtypeTestCache
    //     0xc5b378: ldr             x3, [x3, #0x7b0]
    // 0xc5b37c: r24 = InstanceOfStub
    //     0xc5b37c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc5b380: LoadField: r30 = r24->field_7
    //     0xc5b380: ldur            lr, [x24, #7]
    // 0xc5b384: blr             lr
    // 0xc5b388: b               #0xc5b398
    // 0xc5b38c: r0 = false
    //     0xc5b38c: add             x0, NULL, #0x30  ; false
    // 0xc5b390: b               #0xc5b398
    // 0xc5b394: r0 = true
    //     0xc5b394: add             x0, NULL, #0x20  ; true
    // 0xc5b398: tbnz            w0, #4, #0xc5b420
    // 0xc5b39c: ldr             x3, [fp, #0x18]
    // 0xc5b3a0: LoadField: r4 = r3->field_13
    //     0xc5b3a0: ldur            w4, [x3, #0x13]
    // 0xc5b3a4: DecompressPointer r4
    //     0xc5b3a4: add             x4, x4, HEAP, lsl #32
    // 0xc5b3a8: ldr             x0, [fp, #0x10]
    // 0xc5b3ac: ldur            x2, [fp, #-8]
    // 0xc5b3b0: stur            x4, [fp, #-0x10]
    // 0xc5b3b4: r1 = Null
    //     0xc5b3b4: mov             x1, NULL
    // 0xc5b3b8: cmp             w2, NULL
    // 0xc5b3bc: b.eq            #0xc5b3dc
    // 0xc5b3c0: LoadField: r4 = r2->field_1b
    //     0xc5b3c0: ldur            w4, [x2, #0x1b]
    // 0xc5b3c4: DecompressPointer r4
    //     0xc5b3c4: add             x4, x4, HEAP, lsl #32
    // 0xc5b3c8: r8 = X1
    //     0xc5b3c8: ldr             x8, [PP, #0x9a0]  ; [pp+0x9a0] TypeParameter: X1
    // 0xc5b3cc: LoadField: r9 = r4->field_7
    //     0xc5b3cc: ldur            x9, [x4, #7]
    // 0xc5b3d0: r3 = Null
    //     0xc5b3d0: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d7b8] Null
    //     0xc5b3d4: ldr             x3, [x3, #0x7b8]
    // 0xc5b3d8: blr             x9
    // 0xc5b3dc: ldr             x0, [fp, #0x18]
    // 0xc5b3e0: LoadField: r1 = r0->field_b
    //     0xc5b3e0: ldur            w1, [x0, #0xb]
    // 0xc5b3e4: DecompressPointer r1
    //     0xc5b3e4: add             x1, x1, HEAP, lsl #32
    // 0xc5b3e8: ldr             x16, [fp, #0x10]
    // 0xc5b3ec: stp             x16, x1, [SP, #-0x10]!
    // 0xc5b3f0: mov             x0, x1
    // 0xc5b3f4: ClosureCall
    //     0xc5b3f4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc5b3f8: ldur            x2, [x0, #0x1f]
    //     0xc5b3fc: blr             x2
    // 0xc5b400: add             SP, SP, #0x10
    // 0xc5b404: ldur            x16, [fp, #-0x10]
    // 0xc5b408: stp             x0, x16, [SP, #-0x10]!
    // 0xc5b40c: r0 = containsKey()
    //     0xc5b40c: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xc5b410: add             SP, SP, #0x10
    // 0xc5b414: LeaveFrame
    //     0xc5b414: mov             SP, fp
    //     0xc5b418: ldp             fp, lr, [SP], #0x10
    // 0xc5b41c: ret
    //     0xc5b41c: ret             
    // 0xc5b420: r0 = false
    //     0xc5b420: add             x0, NULL, #0x30  ; false
    // 0xc5b424: LeaveFrame
    //     0xc5b424: mov             SP, fp
    //     0xc5b428: ldp             fp, lr, [SP], #0x10
    // 0xc5b42c: ret
    //     0xc5b42c: ret             
    // 0xc5b430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5b430: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5b434: b               #0xc5b2d4
  }
  bool isEmpty(CanonicalizedMap<X0, X1, X2>) {
    // ** addr: 0xc4559c, size: 0x68
    // 0xc4559c: EnterFrame
    //     0xc4559c: stp             fp, lr, [SP, #-0x10]!
    //     0xc455a0: mov             fp, SP
    // 0xc455a4: ldr             x1, [fp, #0x10]
    // 0xc455a8: LoadField: r2 = r1->field_13
    //     0xc455a8: ldur            w2, [x1, #0x13]
    // 0xc455ac: DecompressPointer r2
    //     0xc455ac: add             x2, x2, HEAP, lsl #32
    // 0xc455b0: LoadField: r1 = r2->field_13
    //     0xc455b0: ldur            w1, [x2, #0x13]
    // 0xc455b4: DecompressPointer r1
    //     0xc455b4: add             x1, x1, HEAP, lsl #32
    // 0xc455b8: r3 = LoadInt32Instr(r1)
    //     0xc455b8: sbfx            x3, x1, #1, #0x1f
    // 0xc455bc: asr             x1, x3, #1
    // 0xc455c0: LoadField: r3 = r2->field_17
    //     0xc455c0: ldur            w3, [x2, #0x17]
    // 0xc455c4: DecompressPointer r3
    //     0xc455c4: add             x3, x3, HEAP, lsl #32
    // 0xc455c8: r2 = LoadInt32Instr(r3)
    //     0xc455c8: sbfx            x2, x3, #1, #0x1f
    // 0xc455cc: sub             x3, x1, x2
    // 0xc455d0: cbz             x3, #0xc455dc
    // 0xc455d4: r0 = false
    //     0xc455d4: add             x0, NULL, #0x30  ; false
    // 0xc455d8: b               #0xc455e0
    // 0xc455dc: r0 = true
    //     0xc455dc: add             x0, NULL, #0x20  ; true
    // 0xc455e0: LeaveFrame
    //     0xc455e0: mov             SP, fp
    //     0xc455e4: ldp             fp, lr, [SP], #0x10
    // 0xc455e8: ret
    //     0xc455e8: ret             
  }
  bool isNotEmpty(CanonicalizedMap<X0, X1, X2>) {
    // ** addr: 0xc27480, size: 0x68
    // 0xc27480: EnterFrame
    //     0xc27480: stp             fp, lr, [SP, #-0x10]!
    //     0xc27484: mov             fp, SP
    // 0xc27488: ldr             x1, [fp, #0x10]
    // 0xc2748c: LoadField: r2 = r1->field_13
    //     0xc2748c: ldur            w2, [x1, #0x13]
    // 0xc27490: DecompressPointer r2
    //     0xc27490: add             x2, x2, HEAP, lsl #32
    // 0xc27494: LoadField: r1 = r2->field_13
    //     0xc27494: ldur            w1, [x2, #0x13]
    // 0xc27498: DecompressPointer r1
    //     0xc27498: add             x1, x1, HEAP, lsl #32
    // 0xc2749c: r3 = LoadInt32Instr(r1)
    //     0xc2749c: sbfx            x3, x1, #1, #0x1f
    // 0xc274a0: asr             x1, x3, #1
    // 0xc274a4: LoadField: r3 = r2->field_17
    //     0xc274a4: ldur            w3, [x2, #0x17]
    // 0xc274a8: DecompressPointer r3
    //     0xc274a8: add             x3, x3, HEAP, lsl #32
    // 0xc274ac: r2 = LoadInt32Instr(r3)
    //     0xc274ac: sbfx            x2, x3, #1, #0x1f
    // 0xc274b0: sub             x3, x1, x2
    // 0xc274b4: cbnz            x3, #0xc274c0
    // 0xc274b8: r0 = false
    //     0xc274b8: add             x0, NULL, #0x30  ; false
    // 0xc274bc: b               #0xc274c4
    // 0xc274c0: r0 = true
    //     0xc274c0: add             x0, NULL, #0x20  ; true
    // 0xc274c4: LeaveFrame
    //     0xc274c4: mov             SP, fp
    //     0xc274c8: ldp             fp, lr, [SP], #0x10
    // 0xc274cc: ret
    //     0xc274cc: ret             
  }
  int length(CanonicalizedMap<X0, X1, X2>) {
    // ** addr: 0x717420, size: 0x5c
    // 0x717420: EnterFrame
    //     0x717420: stp             fp, lr, [SP, #-0x10]!
    //     0x717424: mov             fp, SP
    // 0x717428: ldr             x1, [fp, #0x10]
    // 0x71742c: LoadField: r2 = r1->field_13
    //     0x71742c: ldur            w2, [x1, #0x13]
    // 0x717430: DecompressPointer r2
    //     0x717430: add             x2, x2, HEAP, lsl #32
    // 0x717434: LoadField: r1 = r2->field_13
    //     0x717434: ldur            w1, [x2, #0x13]
    // 0x717438: DecompressPointer r1
    //     0x717438: add             x1, x1, HEAP, lsl #32
    // 0x71743c: r3 = LoadInt32Instr(r1)
    //     0x71743c: sbfx            x3, x1, #1, #0x1f
    // 0x717440: asr             x1, x3, #1
    // 0x717444: LoadField: r3 = r2->field_17
    //     0x717444: ldur            w3, [x2, #0x17]
    // 0x717448: DecompressPointer r3
    //     0x717448: add             x3, x3, HEAP, lsl #32
    // 0x71744c: r2 = LoadInt32Instr(r3)
    //     0x71744c: sbfx            x2, x3, #1, #0x1f
    // 0x717450: sub             x3, x1, x2
    // 0x717454: lsl             x0, x3, #1
    // 0x717458: LeaveFrame
    //     0x717458: mov             SP, fp
    //     0x71745c: ldp             fp, lr, [SP], #0x10
    // 0x717460: ret
    //     0x717460: ret             
  }
  Map<Y0, Y1> map<Y0, Y1>(CanonicalizedMap<X0, X1, X2>, (dynamic, X1, X2) => MapEntry<Y0, Y1>) {
    // ** addr: 0x52c4c0, size: 0xac
    // 0x52c4c0: EnterFrame
    //     0x52c4c0: stp             fp, lr, [SP, #-0x10]!
    //     0x52c4c4: mov             fp, SP
    // 0x52c4c8: AllocStack(0x8)
    //     0x52c4c8: sub             SP, SP, #8
    // 0x52c4cc: SetupParameters()
    //     0x52c4cc: mov             x0, x4
    //     0x52c4d0: ldur            w1, [x0, #0xf]
    //     0x52c4d4: add             x1, x1, HEAP, lsl #32
    //     0x52c4d8: cbnz            w1, #0x52c4e4
    //     0x52c4dc: mov             x4, NULL
    //     0x52c4e0: b               #0x52c4f8
    //     0x52c4e4: ldur            w1, [x0, #0x17]
    //     0x52c4e8: add             x1, x1, HEAP, lsl #32
    //     0x52c4ec: add             x0, fp, w1, sxtw #2
    //     0x52c4f0: ldr             x0, [x0, #0x10]
    //     0x52c4f4: mov             x4, x0
    //     0x52c4f8: ldr             x3, [fp, #0x18]
    //     0x52c4fc: stur            x4, [fp, #-8]
    // 0x52c500: CheckStackOverflow
    //     0x52c500: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52c504: cmp             SP, x16
    //     0x52c508: b.ls            #0x52c564
    // 0x52c50c: LoadField: r2 = r3->field_7
    //     0x52c50c: ldur            w2, [x3, #7]
    // 0x52c510: DecompressPointer r2
    //     0x52c510: add             x2, x2, HEAP, lsl #32
    // 0x52c514: ldr             x0, [fp, #0x10]
    // 0x52c518: mov             x1, x4
    // 0x52c51c: r8 = (dynamic this, X1, X2) => MapEntry<Y0, Y1>
    //     0x52c51c: add             x8, PP, #0x38, lsl #12  ; [pp+0x38678] FunctionType: (dynamic this, X1, X2) => MapEntry<Y0, Y1>
    //     0x52c520: ldr             x8, [x8, #0x678]
    // 0x52c524: LoadField: r9 = r8->field_7
    //     0x52c524: ldur            x9, [x8, #7]
    // 0x52c528: r3 = Null
    //     0x52c528: add             x3, PP, #0x38, lsl #12  ; [pp+0x38680] Null
    //     0x52c52c: ldr             x3, [x3, #0x680]
    // 0x52c530: blr             x9
    // 0x52c534: ldur            x16, [fp, #-8]
    // 0x52c538: ldr             lr, [fp, #0x18]
    // 0x52c53c: stp             lr, x16, [SP, #-0x10]!
    // 0x52c540: ldr             x16, [fp, #0x10]
    // 0x52c544: SaveReg r16
    //     0x52c544: str             x16, [SP, #-8]!
    // 0x52c548: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x52c548: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0x52c54c: ldr             x4, [x4, #0x4d8]
    // 0x52c550: r0 = map()
    //     0x52c550: bl              #0xc02d74  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::map
    // 0x52c554: add             SP, SP, #0x18
    // 0x52c558: LeaveFrame
    //     0x52c558: mov             SP, fp
    //     0x52c55c: ldp             fp, lr, [SP], #0x10
    // 0x52c560: ret
    //     0x52c560: ret             
    // 0x52c564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52c564: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52c568: b               #0x52c50c
  }
  void forEach(CanonicalizedMap<X0, X1, X2>, (dynamic, X1, X2) => void) {
    // ** addr: 0x52c584, size: 0x80
    // 0x52c584: EnterFrame
    //     0x52c584: stp             fp, lr, [SP, #-0x10]!
    //     0x52c588: mov             fp, SP
    // 0x52c58c: CheckStackOverflow
    //     0x52c58c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52c590: cmp             SP, x16
    //     0x52c594: b.ls            #0x52c5e4
    // 0x52c598: ldr             x3, [fp, #0x18]
    // 0x52c59c: LoadField: r2 = r3->field_7
    //     0x52c59c: ldur            w2, [x3, #7]
    // 0x52c5a0: DecompressPointer r2
    //     0x52c5a0: add             x2, x2, HEAP, lsl #32
    // 0x52c5a4: ldr             x0, [fp, #0x10]
    // 0x52c5a8: r1 = Null
    //     0x52c5a8: mov             x1, NULL
    // 0x52c5ac: r8 = (dynamic this, X1, X2) => void?
    //     0x52c5ac: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d778] FunctionType: (dynamic this, X1, X2) => void?
    //     0x52c5b0: ldr             x8, [x8, #0x778]
    // 0x52c5b4: LoadField: r9 = r8->field_7
    //     0x52c5b4: ldur            x9, [x8, #7]
    // 0x52c5b8: r3 = Null
    //     0x52c5b8: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d780] Null
    //     0x52c5bc: ldr             x3, [x3, #0x780]
    // 0x52c5c0: blr             x9
    // 0x52c5c4: ldr             x16, [fp, #0x18]
    // 0x52c5c8: ldr             lr, [fp, #0x10]
    // 0x52c5cc: stp             lr, x16, [SP, #-0x10]!
    // 0x52c5d0: r0 = forEach()
    //     0x52c5d0: bl              #0xc52604  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::forEach
    // 0x52c5d4: add             SP, SP, #0x10
    // 0x52c5d8: LeaveFrame
    //     0x52c5d8: mov             SP, fp
    //     0x52c5dc: ldp             fp, lr, [SP], #0x10
    // 0x52c5e0: ret
    //     0x52c5e0: ret             
    // 0x52c5e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52c5e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52c5e8: b               #0x52c598
  }
  _ CanonicalizedMap.from(/* No info */) {
    // ** addr: 0x52c95c, size: 0xb4
    // 0x52c95c: EnterFrame
    //     0x52c95c: stp             fp, lr, [SP, #-0x10]!
    //     0x52c960: mov             fp, SP
    // 0x52c964: CheckStackOverflow
    //     0x52c964: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52c968: cmp             SP, x16
    //     0x52c96c: b.ls            #0x52ca08
    // 0x52c970: ldr             x0, [fp, #0x20]
    // 0x52c974: LoadField: r2 = r0->field_7
    //     0x52c974: ldur            w2, [x0, #7]
    // 0x52c978: DecompressPointer r2
    //     0x52c978: add             x2, x2, HEAP, lsl #32
    // 0x52c97c: r1 = Null
    //     0x52c97c: mov             x1, NULL
    // 0x52c980: r3 = <X0, MapEntry<X1, X2>>
    //     0x52c980: add             x3, PP, #0x13, lsl #12  ; [pp+0x131d8] TypeArguments: <X0, MapEntry<X1, X2>>
    //     0x52c984: ldr             x3, [x3, #0x1d8]
    // 0x52c988: r24 = InstantiateTypeArgumentsStub
    //     0x52c988: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x52c98c: LoadField: r30 = r24->field_7
    //     0x52c98c: ldur            lr, [x24, #7]
    // 0x52c990: blr             lr
    // 0x52c994: ldr             x16, [THR, #0xe8]  ; THR::empty_array
    // 0x52c998: stp             x16, x0, [SP, #-0x10]!
    // 0x52c99c: r0 = Map._fromLiteral()
    //     0x52c99c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x52c9a0: add             SP, SP, #0x10
    // 0x52c9a4: ldr             x1, [fp, #0x20]
    // 0x52c9a8: StoreField: r1->field_13 = r0
    //     0x52c9a8: stur            w0, [x1, #0x13]
    //     0x52c9ac: tbz             w0, #0, #0x52c9c8
    //     0x52c9b0: ldurb           w16, [x1, #-1]
    //     0x52c9b4: ldurb           w17, [x0, #-1]
    //     0x52c9b8: and             x16, x17, x16, lsr #2
    //     0x52c9bc: tst             x16, HEAP, lsr #32
    //     0x52c9c0: b.eq            #0x52c9c8
    //     0x52c9c4: bl              #0xd6826c
    // 0x52c9c8: ldr             x0, [fp, #0x10]
    // 0x52c9cc: StoreField: r1->field_b = r0
    //     0x52c9cc: stur            w0, [x1, #0xb]
    //     0x52c9d0: ldurb           w16, [x1, #-1]
    //     0x52c9d4: ldurb           w17, [x0, #-1]
    //     0x52c9d8: and             x16, x17, x16, lsr #2
    //     0x52c9dc: tst             x16, HEAP, lsr #32
    //     0x52c9e0: b.eq            #0x52c9e8
    //     0x52c9e4: bl              #0xd6826c
    // 0x52c9e8: ldr             x16, [fp, #0x18]
    // 0x52c9ec: stp             x16, x1, [SP, #-0x10]!
    // 0x52c9f0: r0 = addAll()
    //     0x52c9f0: bl              #0xbfdcc0  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::addAll
    // 0x52c9f4: add             SP, SP, #0x10
    // 0x52c9f8: r0 = Null
    //     0x52c9f8: mov             x0, NULL
    // 0x52c9fc: LeaveFrame
    //     0x52c9fc: mov             SP, fp
    //     0x52ca00: ldp             fp, lr, [SP], #0x10
    // 0x52ca04: ret
    //     0x52ca04: ret             
    // 0x52ca08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52ca08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52ca0c: b               #0x52c970
  }
  get _ entries(/* No info */) {
    // ** addr: 0xbfc924, size: 0xc8
    // 0xbfc924: EnterFrame
    //     0xbfc924: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc928: mov             fp, SP
    // 0xbfc92c: AllocStack(0x18)
    //     0xbfc92c: sub             SP, SP, #0x18
    // 0xbfc930: CheckStackOverflow
    //     0xbfc930: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfc934: cmp             SP, x16
    //     0xbfc938: b.ls            #0xbfc9e4
    // 0xbfc93c: r1 = 1
    //     0xbfc93c: mov             x1, #1
    // 0xbfc940: r0 = AllocateContext()
    //     0xbfc940: bl              #0xd68aa4  ; AllocateContextStub
    // 0xbfc944: mov             x4, x0
    // 0xbfc948: ldr             x0, [fp, #0x10]
    // 0xbfc94c: stur            x4, [fp, #-0x10]
    // 0xbfc950: StoreField: r4->field_f = r0
    //     0xbfc950: stur            w0, [x4, #0xf]
    // 0xbfc954: LoadField: r5 = r0->field_7
    //     0xbfc954: ldur            w5, [x0, #7]
    // 0xbfc958: DecompressPointer r5
    //     0xbfc958: add             x5, x5, HEAP, lsl #32
    // 0xbfc95c: mov             x2, x5
    // 0xbfc960: stur            x5, [fp, #-8]
    // 0xbfc964: r1 = Null
    //     0xbfc964: mov             x1, NULL
    // 0xbfc968: r3 = <MapEntry<X1, X2>>
    //     0xbfc968: add             x3, PP, #0x22, lsl #12  ; [pp+0x22960] TypeArguments: <MapEntry<X1, X2>>
    //     0xbfc96c: ldr             x3, [x3, #0x960]
    // 0xbfc970: r24 = InstantiateTypeArgumentsStub
    //     0xbfc970: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xbfc974: LoadField: r30 = r24->field_7
    //     0xbfc974: ldur            lr, [x24, #7]
    // 0xbfc978: blr             lr
    // 0xbfc97c: mov             x1, x0
    // 0xbfc980: ldr             x0, [fp, #0x10]
    // 0xbfc984: stur            x1, [fp, #-0x18]
    // 0xbfc988: LoadField: r2 = r0->field_13
    //     0xbfc988: ldur            w2, [x0, #0x13]
    // 0xbfc98c: DecompressPointer r2
    //     0xbfc98c: add             x2, x2, HEAP, lsl #32
    // 0xbfc990: SaveReg r2
    //     0xbfc990: str             x2, [SP, #-8]!
    // 0xbfc994: r0 = entries()
    //     0xbfc994: bl              #0xc761a0  ; [dart:collection] __Map&_HashVMBase&MapMixin::entries
    // 0xbfc998: add             SP, SP, #8
    // 0xbfc99c: ldur            x2, [fp, #-0x10]
    // 0xbfc9a0: r1 = Function '<anonymous closure>':.
    //     0xbfc9a0: add             x1, PP, #0x22, lsl #12  ; [pp+0x22968] AnonymousClosure: (0xbfc9ec), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::entries (0xbfc924)
    //     0xbfc9a4: ldr             x1, [x1, #0x968]
    // 0xbfc9a8: stur            x0, [fp, #-0x10]
    // 0xbfc9ac: r0 = AllocateClosure()
    //     0xbfc9ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbfc9b0: mov             x1, x0
    // 0xbfc9b4: ldur            x0, [fp, #-8]
    // 0xbfc9b8: StoreField: r1->field_7 = r0
    //     0xbfc9b8: stur            w0, [x1, #7]
    // 0xbfc9bc: ldur            x16, [fp, #-0x18]
    // 0xbfc9c0: ldur            lr, [fp, #-0x10]
    // 0xbfc9c4: stp             lr, x16, [SP, #-0x10]!
    // 0xbfc9c8: SaveReg r1
    //     0xbfc9c8: str             x1, [SP, #-8]!
    // 0xbfc9cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbfc9cc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbfc9d0: r0 = map()
    //     0xbfc9d0: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0xbfc9d4: add             SP, SP, #0x18
    // 0xbfc9d8: LeaveFrame
    //     0xbfc9d8: mov             SP, fp
    //     0xbfc9dc: ldp             fp, lr, [SP], #0x10
    // 0xbfc9e0: ret
    //     0xbfc9e0: ret             
    // 0xbfc9e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc9e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc9e8: b               #0xbfc93c
  }
  [closure] MapEntry<X1, X2> <anonymous closure>(dynamic, MapEntry<X0, MapEntry<X1, X2>>) {
    // ** addr: 0xbfc9ec, size: 0x11c
    // 0xbfc9ec: EnterFrame
    //     0xbfc9ec: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc9f0: mov             fp, SP
    // 0xbfc9f4: AllocStack(0x10)
    //     0xbfc9f4: sub             SP, SP, #0x10
    // 0xbfc9f8: SetupParameters()
    //     0xbfc9f8: ldr             x0, [fp, #0x18]
    //     0xbfc9fc: ldur            w1, [x0, #0x17]
    //     0xbfca00: add             x1, x1, HEAP, lsl #32
    // 0xbfca04: CheckStackOverflow
    //     0xbfca04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfca08: cmp             SP, x16
    //     0xbfca0c: b.ls            #0xbfcb00
    // 0xbfca10: LoadField: r0 = r1->field_f
    //     0xbfca10: ldur            w0, [x1, #0xf]
    // 0xbfca14: DecompressPointer r0
    //     0xbfca14: add             x0, x0, HEAP, lsl #32
    // 0xbfca18: LoadField: r2 = r0->field_7
    //     0xbfca18: ldur            w2, [x0, #7]
    // 0xbfca1c: DecompressPointer r2
    //     0xbfca1c: add             x2, x2, HEAP, lsl #32
    // 0xbfca20: r1 = Null
    //     0xbfca20: mov             x1, NULL
    // 0xbfca24: r3 = <X1, X2>
    //     0xbfca24: add             x3, PP, #0x13, lsl #12  ; [pp+0x13248] TypeArguments: <X1, X2>
    //     0xbfca28: ldr             x3, [x3, #0x248]
    // 0xbfca2c: r0 = Null
    //     0xbfca2c: mov             x0, NULL
    // 0xbfca30: cmp             x2, x0
    // 0xbfca34: b.eq            #0xbfca44
    // 0xbfca38: r24 = InstantiateTypeArgumentsStub
    //     0xbfca38: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xbfca3c: LoadField: r30 = r24->field_7
    //     0xbfca3c: ldur            lr, [x24, #7]
    // 0xbfca40: blr             lr
    // 0xbfca44: mov             x2, x0
    // 0xbfca48: ldr             x1, [fp, #0x10]
    // 0xbfca4c: stur            x2, [fp, #-8]
    // 0xbfca50: r0 = LoadClassIdInstr(r1)
    //     0xbfca50: ldur            x0, [x1, #-1]
    //     0xbfca54: ubfx            x0, x0, #0xc, #0x14
    // 0xbfca58: SaveReg r1
    //     0xbfca58: str             x1, [SP, #-8]!
    // 0xbfca5c: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xbfca5c: sub             lr, x0, #0xfc4
    //     0xbfca60: ldr             lr, [x21, lr, lsl #3]
    //     0xbfca64: blr             lr
    // 0xbfca68: add             SP, SP, #8
    // 0xbfca6c: r1 = LoadClassIdInstr(r0)
    //     0xbfca6c: ldur            x1, [x0, #-1]
    //     0xbfca70: ubfx            x1, x1, #0xc, #0x14
    // 0xbfca74: SaveReg r0
    //     0xbfca74: str             x0, [SP, #-8]!
    // 0xbfca78: mov             x0, x1
    // 0xbfca7c: r0 = GDT[cid_x0 + -0xfba]()
    //     0xbfca7c: sub             lr, x0, #0xfba
    //     0xbfca80: ldr             lr, [x21, lr, lsl #3]
    //     0xbfca84: blr             lr
    // 0xbfca88: add             SP, SP, #8
    // 0xbfca8c: mov             x1, x0
    // 0xbfca90: ldr             x0, [fp, #0x10]
    // 0xbfca94: stur            x1, [fp, #-0x10]
    // 0xbfca98: r2 = LoadClassIdInstr(r0)
    //     0xbfca98: ldur            x2, [x0, #-1]
    //     0xbfca9c: ubfx            x2, x2, #0xc, #0x14
    // 0xbfcaa0: SaveReg r0
    //     0xbfcaa0: str             x0, [SP, #-8]!
    // 0xbfcaa4: mov             x0, x2
    // 0xbfcaa8: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xbfcaa8: sub             lr, x0, #0xfc4
    //     0xbfcaac: ldr             lr, [x21, lr, lsl #3]
    //     0xbfcab0: blr             lr
    // 0xbfcab4: add             SP, SP, #8
    // 0xbfcab8: r1 = LoadClassIdInstr(r0)
    //     0xbfcab8: ldur            x1, [x0, #-1]
    //     0xbfcabc: ubfx            x1, x1, #0xc, #0x14
    // 0xbfcac0: SaveReg r0
    //     0xbfcac0: str             x0, [SP, #-8]!
    // 0xbfcac4: mov             x0, x1
    // 0xbfcac8: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xbfcac8: sub             lr, x0, #0xfc4
    //     0xbfcacc: ldr             lr, [x21, lr, lsl #3]
    //     0xbfcad0: blr             lr
    // 0xbfcad4: add             SP, SP, #8
    // 0xbfcad8: ldur            x1, [fp, #-8]
    // 0xbfcadc: stur            x0, [fp, #-8]
    // 0xbfcae0: r0 = MapEntry()
    //     0xbfcae0: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xbfcae4: ldur            x1, [fp, #-0x10]
    // 0xbfcae8: StoreField: r0->field_b = r1
    //     0xbfcae8: stur            w1, [x0, #0xb]
    // 0xbfcaec: ldur            x1, [fp, #-8]
    // 0xbfcaf0: StoreField: r0->field_f = r1
    //     0xbfcaf0: stur            w1, [x0, #0xf]
    // 0xbfcaf4: LeaveFrame
    //     0xbfcaf4: mov             SP, fp
    //     0xbfcaf8: ldp             fp, lr, [SP], #0x10
    // 0xbfcafc: ret
    //     0xbfcafc: ret             
    // 0xbfcb00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfcb00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfcb04: b               #0xbfca10
  }
  _ addAll(/* No info */) {
    // ** addr: 0xbfdcc0, size: 0xa4
    // 0xbfdcc0: EnterFrame
    //     0xbfdcc0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfdcc4: mov             fp, SP
    // 0xbfdcc8: AllocStack(0x10)
    //     0xbfdcc8: sub             SP, SP, #0x10
    // 0xbfdccc: CheckStackOverflow
    //     0xbfdccc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfdcd0: cmp             SP, x16
    //     0xbfdcd4: b.ls            #0xbfdd5c
    // 0xbfdcd8: r1 = 1
    //     0xbfdcd8: mov             x1, #1
    // 0xbfdcdc: r0 = AllocateContext()
    //     0xbfdcdc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xbfdce0: mov             x3, x0
    // 0xbfdce4: ldr             x0, [fp, #0x18]
    // 0xbfdce8: stur            x3, [fp, #-0x10]
    // 0xbfdcec: StoreField: r3->field_f = r0
    //     0xbfdcec: stur            w0, [x3, #0xf]
    // 0xbfdcf0: LoadField: r4 = r0->field_7
    //     0xbfdcf0: ldur            w4, [x0, #7]
    // 0xbfdcf4: DecompressPointer r4
    //     0xbfdcf4: add             x4, x4, HEAP, lsl #32
    // 0xbfdcf8: ldr             x0, [fp, #0x10]
    // 0xbfdcfc: mov             x2, x4
    // 0xbfdd00: stur            x4, [fp, #-8]
    // 0xbfdd04: r1 = Null
    //     0xbfdd04: mov             x1, NULL
    // 0xbfdd08: r8 = Map<X1, X2>
    //     0xbfdd08: add             x8, PP, #0x13, lsl #12  ; [pp+0x131e0] Type: Map<X1, X2>
    //     0xbfdd0c: ldr             x8, [x8, #0x1e0]
    // 0xbfdd10: LoadField: r9 = r8->field_7
    //     0xbfdd10: ldur            x9, [x8, #7]
    // 0xbfdd14: r3 = Null
    //     0xbfdd14: add             x3, PP, #0x13, lsl #12  ; [pp+0x131e8] Null
    //     0xbfdd18: ldr             x3, [x3, #0x1e8]
    // 0xbfdd1c: blr             x9
    // 0xbfdd20: ldur            x2, [fp, #-0x10]
    // 0xbfdd24: r1 = Function '<anonymous closure>':.
    //     0xbfdd24: add             x1, PP, #0x13, lsl #12  ; [pp+0x131f8] AnonymousClosure: (0xbfdd64), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::addAll (0xbfdcc0)
    //     0xbfdd28: ldr             x1, [x1, #0x1f8]
    // 0xbfdd2c: r0 = AllocateClosure()
    //     0xbfdd2c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbfdd30: mov             x1, x0
    // 0xbfdd34: ldur            x0, [fp, #-8]
    // 0xbfdd38: StoreField: r1->field_7 = r0
    //     0xbfdd38: stur            w0, [x1, #7]
    // 0xbfdd3c: ldr             x16, [fp, #0x10]
    // 0xbfdd40: stp             x1, x16, [SP, #-0x10]!
    // 0xbfdd44: r0 = forEach()
    //     0xbfdd44: bl              #0xca3d28  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0xbfdd48: add             SP, SP, #0x10
    // 0xbfdd4c: r0 = Null
    //     0xbfdd4c: mov             x0, NULL
    // 0xbfdd50: LeaveFrame
    //     0xbfdd50: mov             SP, fp
    //     0xbfdd54: ldp             fp, lr, [SP], #0x10
    // 0xbfdd58: ret
    //     0xbfdd58: ret             
    // 0xbfdd5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfdd5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfdd60: b               #0xbfdcd8
  }
  [closure] void <anonymous closure>(dynamic, X1, X2) {
    // ** addr: 0xbfdd64, size: 0x58
    // 0xbfdd64: EnterFrame
    //     0xbfdd64: stp             fp, lr, [SP, #-0x10]!
    //     0xbfdd68: mov             fp, SP
    // 0xbfdd6c: ldr             x0, [fp, #0x20]
    // 0xbfdd70: LoadField: r1 = r0->field_17
    //     0xbfdd70: ldur            w1, [x0, #0x17]
    // 0xbfdd74: DecompressPointer r1
    //     0xbfdd74: add             x1, x1, HEAP, lsl #32
    // 0xbfdd78: CheckStackOverflow
    //     0xbfdd78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfdd7c: cmp             SP, x16
    //     0xbfdd80: b.ls            #0xbfddb4
    // 0xbfdd84: LoadField: r0 = r1->field_f
    //     0xbfdd84: ldur            w0, [x1, #0xf]
    // 0xbfdd88: DecompressPointer r0
    //     0xbfdd88: add             x0, x0, HEAP, lsl #32
    // 0xbfdd8c: ldr             x16, [fp, #0x18]
    // 0xbfdd90: stp             x16, x0, [SP, #-0x10]!
    // 0xbfdd94: ldr             x16, [fp, #0x10]
    // 0xbfdd98: SaveReg r16
    //     0xbfdd98: str             x16, [SP, #-8]!
    // 0xbfdd9c: r0 = []=()
    //     0xbfdd9c: bl              #0xc5cd38  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::[]=
    // 0xbfdda0: add             SP, SP, #0x18
    // 0xbfdda4: ldr             x0, [fp, #0x10]
    // 0xbfdda8: LeaveFrame
    //     0xbfdda8: mov             SP, fp
    //     0xbfddac: ldp             fp, lr, [SP], #0x10
    // 0xbfddb0: ret
    //     0xbfddb0: ret             
    // 0xbfddb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfddb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfddb8: b               #0xbfdd84
  }
  _ putIfAbsent(/* No info */) {
    // ** addr: 0xc00874, size: 0x140
    // 0xc00874: EnterFrame
    //     0xc00874: stp             fp, lr, [SP, #-0x10]!
    //     0xc00878: mov             fp, SP
    // 0xc0087c: AllocStack(0x18)
    //     0xc0087c: sub             SP, SP, #0x18
    // 0xc00880: CheckStackOverflow
    //     0xc00880: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc00884: cmp             SP, x16
    //     0xc00888: b.ls            #0xc009ac
    // 0xc0088c: r1 = 3
    //     0xc0088c: mov             x1, #3
    // 0xc00890: r0 = AllocateContext()
    //     0xc00890: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc00894: mov             x4, x0
    // 0xc00898: ldr             x3, [fp, #0x20]
    // 0xc0089c: stur            x4, [fp, #-0x10]
    // 0xc008a0: StoreField: r4->field_f = r3
    //     0xc008a0: stur            w3, [x4, #0xf]
    // 0xc008a4: ldr             x5, [fp, #0x18]
    // 0xc008a8: StoreField: r4->field_13 = r5
    //     0xc008a8: stur            w5, [x4, #0x13]
    // 0xc008ac: ldr             x6, [fp, #0x10]
    // 0xc008b0: StoreField: r4->field_17 = r6
    //     0xc008b0: stur            w6, [x4, #0x17]
    // 0xc008b4: LoadField: r7 = r3->field_7
    //     0xc008b4: ldur            w7, [x3, #7]
    // 0xc008b8: DecompressPointer r7
    //     0xc008b8: add             x7, x7, HEAP, lsl #32
    // 0xc008bc: mov             x0, x5
    // 0xc008c0: mov             x2, x7
    // 0xc008c4: stur            x7, [fp, #-8]
    // 0xc008c8: r1 = Null
    //     0xc008c8: mov             x1, NULL
    // 0xc008cc: cmp             w2, NULL
    // 0xc008d0: b.eq            #0xc008f0
    // 0xc008d4: LoadField: r4 = r2->field_1b
    //     0xc008d4: ldur            w4, [x2, #0x1b]
    // 0xc008d8: DecompressPointer r4
    //     0xc008d8: add             x4, x4, HEAP, lsl #32
    // 0xc008dc: r8 = X1
    //     0xc008dc: ldr             x8, [PP, #0x9a0]  ; [pp+0x9a0] TypeParameter: X1
    // 0xc008e0: LoadField: r9 = r4->field_7
    //     0xc008e0: ldur            x9, [x4, #7]
    // 0xc008e4: r3 = Null
    //     0xc008e4: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d738] Null
    //     0xc008e8: ldr             x3, [x3, #0x738]
    // 0xc008ec: blr             x9
    // 0xc008f0: ldr             x0, [fp, #0x10]
    // 0xc008f4: ldur            x2, [fp, #-8]
    // 0xc008f8: r1 = Null
    //     0xc008f8: mov             x1, NULL
    // 0xc008fc: r8 = (dynamic this) => X2
    //     0xc008fc: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d748] FunctionType: (dynamic this) => X2
    //     0xc00900: ldr             x8, [x8, #0x748]
    // 0xc00904: LoadField: r9 = r8->field_7
    //     0xc00904: ldur            x9, [x8, #7]
    // 0xc00908: r3 = Null
    //     0xc00908: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d750] Null
    //     0xc0090c: ldr             x3, [x3, #0x750]
    // 0xc00910: blr             x9
    // 0xc00914: ldr             x0, [fp, #0x20]
    // 0xc00918: LoadField: r1 = r0->field_13
    //     0xc00918: ldur            w1, [x0, #0x13]
    // 0xc0091c: DecompressPointer r1
    //     0xc0091c: add             x1, x1, HEAP, lsl #32
    // 0xc00920: stur            x1, [fp, #-0x18]
    // 0xc00924: LoadField: r2 = r0->field_b
    //     0xc00924: ldur            w2, [x0, #0xb]
    // 0xc00928: DecompressPointer r2
    //     0xc00928: add             x2, x2, HEAP, lsl #32
    // 0xc0092c: ldr             x16, [fp, #0x18]
    // 0xc00930: stp             x16, x2, [SP, #-0x10]!
    // 0xc00934: mov             x0, x2
    // 0xc00938: ClosureCall
    //     0xc00938: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc0093c: ldur            x2, [x0, #0x1f]
    //     0xc00940: blr             x2
    // 0xc00944: add             SP, SP, #0x10
    // 0xc00948: ldur            x2, [fp, #-0x10]
    // 0xc0094c: r1 = Function '<anonymous closure>':.
    //     0xc0094c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d760] AnonymousClosure: (0xc009b4), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::putIfAbsent (0xc00874)
    //     0xc00950: ldr             x1, [x1, #0x760]
    // 0xc00954: stur            x0, [fp, #-0x10]
    // 0xc00958: r0 = AllocateClosure()
    //     0xc00958: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc0095c: mov             x1, x0
    // 0xc00960: ldur            x0, [fp, #-8]
    // 0xc00964: StoreField: r1->field_7 = r0
    //     0xc00964: stur            w0, [x1, #7]
    // 0xc00968: ldur            x16, [fp, #-0x18]
    // 0xc0096c: ldur            lr, [fp, #-0x10]
    // 0xc00970: stp             lr, x16, [SP, #-0x10]!
    // 0xc00974: SaveReg r1
    //     0xc00974: str             x1, [SP, #-8]!
    // 0xc00978: r0 = putIfAbsent()
    //     0xc00978: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xc0097c: add             SP, SP, #0x18
    // 0xc00980: r1 = LoadClassIdInstr(r0)
    //     0xc00980: ldur            x1, [x0, #-1]
    //     0xc00984: ubfx            x1, x1, #0xc, #0x14
    // 0xc00988: SaveReg r0
    //     0xc00988: str             x0, [SP, #-8]!
    // 0xc0098c: mov             x0, x1
    // 0xc00990: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xc00990: sub             lr, x0, #0xfc4
    //     0xc00994: ldr             lr, [x21, lr, lsl #3]
    //     0xc00998: blr             lr
    // 0xc0099c: add             SP, SP, #8
    // 0xc009a0: LeaveFrame
    //     0xc009a0: mov             SP, fp
    //     0xc009a4: ldp             fp, lr, [SP], #0x10
    // 0xc009a8: ret
    //     0xc009a8: ret             
    // 0xc009ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc009ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc009b0: b               #0xc0088c
  }
  [closure] MapEntry<X1, X2> <anonymous closure>(dynamic) {
    // ** addr: 0xc009b4, size: 0xd0
    // 0xc009b4: EnterFrame
    //     0xc009b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc009b8: mov             fp, SP
    // 0xc009bc: AllocStack(0x18)
    //     0xc009bc: sub             SP, SP, #0x18
    // 0xc009c0: SetupParameters()
    //     0xc009c0: ldr             x0, [fp, #0x10]
    //     0xc009c4: ldur            w4, [x0, #0x17]
    //     0xc009c8: add             x4, x4, HEAP, lsl #32
    //     0xc009cc: stur            x4, [fp, #-8]
    // 0xc009d0: CheckStackOverflow
    //     0xc009d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc009d4: cmp             SP, x16
    //     0xc009d8: b.ls            #0xc00a78
    // 0xc009dc: LoadField: r0 = r4->field_f
    //     0xc009dc: ldur            w0, [x4, #0xf]
    // 0xc009e0: DecompressPointer r0
    //     0xc009e0: add             x0, x0, HEAP, lsl #32
    // 0xc009e4: LoadField: r2 = r0->field_7
    //     0xc009e4: ldur            w2, [x0, #7]
    // 0xc009e8: DecompressPointer r2
    //     0xc009e8: add             x2, x2, HEAP, lsl #32
    // 0xc009ec: r1 = Null
    //     0xc009ec: mov             x1, NULL
    // 0xc009f0: r3 = <X1, X2>
    //     0xc009f0: add             x3, PP, #0x13, lsl #12  ; [pp+0x13248] TypeArguments: <X1, X2>
    //     0xc009f4: ldr             x3, [x3, #0x248]
    // 0xc009f8: r0 = Null
    //     0xc009f8: mov             x0, NULL
    // 0xc009fc: cmp             x2, x0
    // 0xc00a00: b.eq            #0xc00a10
    // 0xc00a04: r24 = InstantiateTypeArgumentsStub
    //     0xc00a04: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xc00a08: LoadField: r30 = r24->field_7
    //     0xc00a08: ldur            lr, [x24, #7]
    // 0xc00a0c: blr             lr
    // 0xc00a10: mov             x1, x0
    // 0xc00a14: ldur            x0, [fp, #-8]
    // 0xc00a18: stur            x1, [fp, #-0x18]
    // 0xc00a1c: LoadField: r2 = r0->field_13
    //     0xc00a1c: ldur            w2, [x0, #0x13]
    // 0xc00a20: DecompressPointer r2
    //     0xc00a20: add             x2, x2, HEAP, lsl #32
    // 0xc00a24: stur            x2, [fp, #-0x10]
    // 0xc00a28: LoadField: r3 = r0->field_17
    //     0xc00a28: ldur            w3, [x0, #0x17]
    // 0xc00a2c: DecompressPointer r3
    //     0xc00a2c: add             x3, x3, HEAP, lsl #32
    // 0xc00a30: cmp             w3, NULL
    // 0xc00a34: b.eq            #0xc00a80
    // 0xc00a38: SaveReg r3
    //     0xc00a38: str             x3, [SP, #-8]!
    // 0xc00a3c: mov             x0, x3
    // 0xc00a40: ClosureCall
    //     0xc00a40: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xc00a44: ldur            x2, [x0, #0x1f]
    //     0xc00a48: blr             x2
    // 0xc00a4c: add             SP, SP, #8
    // 0xc00a50: ldur            x1, [fp, #-0x18]
    // 0xc00a54: stur            x0, [fp, #-8]
    // 0xc00a58: r0 = MapEntry()
    //     0xc00a58: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xc00a5c: ldur            x1, [fp, #-0x10]
    // 0xc00a60: StoreField: r0->field_b = r1
    //     0xc00a60: stur            w1, [x0, #0xb]
    // 0xc00a64: ldur            x1, [fp, #-8]
    // 0xc00a68: StoreField: r0->field_f = r1
    //     0xc00a68: stur            w1, [x0, #0xf]
    // 0xc00a6c: LeaveFrame
    //     0xc00a6c: mov             SP, fp
    //     0xc00a70: ldp             fp, lr, [SP], #0x10
    // 0xc00a74: ret
    //     0xc00a74: ret             
    // 0xc00a78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc00a78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc00a7c: b               #0xc009dc
    // 0xc00a80: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc00a80: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  Map<Y0, Y1> map<Y0, Y1>(CanonicalizedMap<X0, X1, X2>, (dynamic, X1, X2) => MapEntry<Y0, Y1>) {
    // ** addr: 0xc02d74, size: 0xd8
    // 0xc02d74: EnterFrame
    //     0xc02d74: stp             fp, lr, [SP, #-0x10]!
    //     0xc02d78: mov             fp, SP
    // 0xc02d7c: AllocStack(0x18)
    //     0xc02d7c: sub             SP, SP, #0x18
    // 0xc02d80: SetupParameters()
    //     0xc02d80: mov             x0, x4
    //     0xc02d84: ldur            w1, [x0, #0xf]
    //     0xc02d88: add             x1, x1, HEAP, lsl #32
    //     0xc02d8c: cbnz            w1, #0xc02d98
    //     0xc02d90: mov             x2, NULL
    //     0xc02d94: b               #0xc02dac
    //     0xc02d98: ldur            w1, [x0, #0x17]
    //     0xc02d9c: add             x1, x1, HEAP, lsl #32
    //     0xc02da0: add             x0, fp, w1, sxtw #2
    //     0xc02da4: ldr             x0, [x0, #0x10]
    //     0xc02da8: mov             x2, x0
    //     0xc02dac: ldr             x1, [fp, #0x18]
    //     0xc02db0: ldr             x0, [fp, #0x10]
    //     0xc02db4: stur            x2, [fp, #-8]
    // 0xc02db8: CheckStackOverflow
    //     0xc02db8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc02dbc: cmp             SP, x16
    //     0xc02dc0: b.ls            #0xc02e44
    // 0xc02dc4: r1 = 2
    //     0xc02dc4: mov             x1, #2
    // 0xc02dc8: r0 = AllocateContext()
    //     0xc02dc8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc02dcc: mov             x1, x0
    // 0xc02dd0: ldr             x0, [fp, #0x18]
    // 0xc02dd4: StoreField: r1->field_f = r0
    //     0xc02dd4: stur            w0, [x1, #0xf]
    // 0xc02dd8: ldr             x2, [fp, #0x10]
    // 0xc02ddc: StoreField: r1->field_13 = r2
    //     0xc02ddc: stur            w2, [x1, #0x13]
    // 0xc02de0: LoadField: r3 = r0->field_13
    //     0xc02de0: ldur            w3, [x0, #0x13]
    // 0xc02de4: DecompressPointer r3
    //     0xc02de4: add             x3, x3, HEAP, lsl #32
    // 0xc02de8: stur            x3, [fp, #-0x18]
    // 0xc02dec: LoadField: r4 = r0->field_7
    //     0xc02dec: ldur            w4, [x0, #7]
    // 0xc02df0: DecompressPointer r4
    //     0xc02df0: add             x4, x4, HEAP, lsl #32
    // 0xc02df4: mov             x2, x1
    // 0xc02df8: stur            x4, [fp, #-0x10]
    // 0xc02dfc: r1 = Function '<anonymous closure>':.
    //     0xc02dfc: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d768] AnonymousClosure: (0xc02e4c), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::map (0xc02d74)
    //     0xc02e00: ldr             x1, [x1, #0x768]
    // 0xc02e04: r0 = AllocateClosure()
    //     0xc02e04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc02e08: mov             x1, x0
    // 0xc02e0c: ldur            x0, [fp, #-0x10]
    // 0xc02e10: StoreField: r1->field_7 = r0
    //     0xc02e10: stur            w0, [x1, #7]
    // 0xc02e14: ldur            x0, [fp, #-8]
    // 0xc02e18: StoreField: r1->field_b = r0
    //     0xc02e18: stur            w0, [x1, #0xb]
    // 0xc02e1c: ldur            x16, [fp, #-0x18]
    // 0xc02e20: stp             x16, x0, [SP, #-0x10]!
    // 0xc02e24: SaveReg r1
    //     0xc02e24: str             x1, [SP, #-8]!
    // 0xc02e28: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xc02e28: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0xc02e2c: ldr             x4, [x4, #0x4d8]
    // 0xc02e30: r0 = map()
    //     0xc02e30: bl              #0xc7ae6c  ; [dart:collection] __Map&_HashVMBase&MapMixin::map
    // 0xc02e34: add             SP, SP, #0x18
    // 0xc02e38: LeaveFrame
    //     0xc02e38: mov             SP, fp
    //     0xc02e3c: ldp             fp, lr, [SP], #0x10
    // 0xc02e40: ret
    //     0xc02e40: ret             
    // 0xc02e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02e48: b               #0xc02dc4
  }
  [closure] MapEntry<Y0, Y1> <anonymous closure>(dynamic, X0, MapEntry<X1, X2>) {
    // ** addr: 0xc02e4c, size: 0xc0
    // 0xc02e4c: EnterFrame
    //     0xc02e4c: stp             fp, lr, [SP, #-0x10]!
    //     0xc02e50: mov             fp, SP
    // 0xc02e54: AllocStack(0x10)
    //     0xc02e54: sub             SP, SP, #0x10
    // 0xc02e58: SetupParameters()
    //     0xc02e58: ldr             x0, [fp, #0x20]
    //     0xc02e5c: ldur            w1, [x0, #0x17]
    //     0xc02e60: add             x1, x1, HEAP, lsl #32
    // 0xc02e64: CheckStackOverflow
    //     0xc02e64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc02e68: cmp             SP, x16
    //     0xc02e6c: b.ls            #0xc02f00
    // 0xc02e70: LoadField: r2 = r1->field_13
    //     0xc02e70: ldur            w2, [x1, #0x13]
    // 0xc02e74: DecompressPointer r2
    //     0xc02e74: add             x2, x2, HEAP, lsl #32
    // 0xc02e78: ldr             x1, [fp, #0x10]
    // 0xc02e7c: stur            x2, [fp, #-8]
    // 0xc02e80: r0 = LoadClassIdInstr(r1)
    //     0xc02e80: ldur            x0, [x1, #-1]
    //     0xc02e84: ubfx            x0, x0, #0xc, #0x14
    // 0xc02e88: SaveReg r1
    //     0xc02e88: str             x1, [SP, #-8]!
    // 0xc02e8c: r0 = GDT[cid_x0 + -0xfba]()
    //     0xc02e8c: sub             lr, x0, #0xfba
    //     0xc02e90: ldr             lr, [x21, lr, lsl #3]
    //     0xc02e94: blr             lr
    // 0xc02e98: add             SP, SP, #8
    // 0xc02e9c: mov             x1, x0
    // 0xc02ea0: ldr             x0, [fp, #0x10]
    // 0xc02ea4: stur            x1, [fp, #-0x10]
    // 0xc02ea8: r2 = LoadClassIdInstr(r0)
    //     0xc02ea8: ldur            x2, [x0, #-1]
    //     0xc02eac: ubfx            x2, x2, #0xc, #0x14
    // 0xc02eb0: SaveReg r0
    //     0xc02eb0: str             x0, [SP, #-8]!
    // 0xc02eb4: mov             x0, x2
    // 0xc02eb8: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xc02eb8: sub             lr, x0, #0xfc4
    //     0xc02ebc: ldr             lr, [x21, lr, lsl #3]
    //     0xc02ec0: blr             lr
    // 0xc02ec4: add             SP, SP, #8
    // 0xc02ec8: mov             x1, x0
    // 0xc02ecc: ldur            x0, [fp, #-8]
    // 0xc02ed0: cmp             w0, NULL
    // 0xc02ed4: b.eq            #0xc02f08
    // 0xc02ed8: ldur            x16, [fp, #-0x10]
    // 0xc02edc: stp             x16, x0, [SP, #-0x10]!
    // 0xc02ee0: SaveReg r1
    //     0xc02ee0: str             x1, [SP, #-8]!
    // 0xc02ee4: ClosureCall
    //     0xc02ee4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc02ee8: ldur            x2, [x0, #0x1f]
    //     0xc02eec: blr             x2
    // 0xc02ef0: add             SP, SP, #0x18
    // 0xc02ef4: LeaveFrame
    //     0xc02ef4: mov             SP, fp
    //     0xc02ef8: ldp             fp, lr, [SP], #0x10
    // 0xc02efc: ret
    //     0xc02efc: ret             
    // 0xc02f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02f00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02f04: b               #0xc02e70
    // 0xc02f08: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc02f08: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  get _ values(/* No info */) {
    // ** addr: 0xc4183c, size: 0xd4
    // 0xc4183c: EnterFrame
    //     0xc4183c: stp             fp, lr, [SP, #-0x10]!
    //     0xc41840: mov             fp, SP
    // 0xc41844: AllocStack(0x18)
    //     0xc41844: sub             SP, SP, #0x18
    // 0xc41848: CheckStackOverflow
    //     0xc41848: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4184c: cmp             SP, x16
    //     0xc41850: b.ls            #0xc41908
    // 0xc41854: r1 = 1
    //     0xc41854: mov             x1, #1
    // 0xc41858: r0 = AllocateContext()
    //     0xc41858: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc4185c: mov             x4, x0
    // 0xc41860: ldr             x0, [fp, #0x10]
    // 0xc41864: stur            x4, [fp, #-0x10]
    // 0xc41868: StoreField: r4->field_f = r0
    //     0xc41868: stur            w0, [x4, #0xf]
    // 0xc4186c: LoadField: r5 = r0->field_7
    //     0xc4186c: ldur            w5, [x0, #7]
    // 0xc41870: DecompressPointer r5
    //     0xc41870: add             x5, x5, HEAP, lsl #32
    // 0xc41874: mov             x2, x5
    // 0xc41878: stur            x5, [fp, #-8]
    // 0xc4187c: r1 = Null
    //     0xc4187c: mov             x1, NULL
    // 0xc41880: r3 = <X2>
    //     0xc41880: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d6f8] TypeArguments: <X2>
    //     0xc41884: ldr             x3, [x3, #0x6f8]
    // 0xc41888: r0 = Null
    //     0xc41888: mov             x0, NULL
    // 0xc4188c: cmp             x2, x0
    // 0xc41890: b.eq            #0xc418a0
    // 0xc41894: r24 = InstantiateTypeArgumentsStub
    //     0xc41894: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xc41898: LoadField: r30 = r24->field_7
    //     0xc41898: ldur            lr, [x24, #7]
    // 0xc4189c: blr             lr
    // 0xc418a0: mov             x1, x0
    // 0xc418a4: ldr             x0, [fp, #0x10]
    // 0xc418a8: stur            x1, [fp, #-0x18]
    // 0xc418ac: LoadField: r2 = r0->field_13
    //     0xc418ac: ldur            w2, [x0, #0x13]
    // 0xc418b0: DecompressPointer r2
    //     0xc418b0: add             x2, x2, HEAP, lsl #32
    // 0xc418b4: SaveReg r2
    //     0xc418b4: str             x2, [SP, #-8]!
    // 0xc418b8: r0 = values()
    //     0xc418b8: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0xc418bc: add             SP, SP, #8
    // 0xc418c0: ldur            x2, [fp, #-0x10]
    // 0xc418c4: r1 = Function '<anonymous closure>':.
    //     0xc418c4: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d700] AnonymousClosure: (0xc41910), in [package:get/get_navigation/src/root/parse_route.dart] ParseRouteTree::matchRoute (0xc4195c)
    //     0xc418c8: ldr             x1, [x1, #0x700]
    // 0xc418cc: stur            x0, [fp, #-0x10]
    // 0xc418d0: r0 = AllocateClosure()
    //     0xc418d0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc418d4: mov             x1, x0
    // 0xc418d8: ldur            x0, [fp, #-8]
    // 0xc418dc: StoreField: r1->field_7 = r0
    //     0xc418dc: stur            w0, [x1, #7]
    // 0xc418e0: ldur            x16, [fp, #-0x18]
    // 0xc418e4: ldur            lr, [fp, #-0x10]
    // 0xc418e8: stp             lr, x16, [SP, #-0x10]!
    // 0xc418ec: SaveReg r1
    //     0xc418ec: str             x1, [SP, #-8]!
    // 0xc418f0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc418f0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc418f4: r0 = map()
    //     0xc418f4: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0xc418f8: add             SP, SP, #0x18
    // 0xc418fc: LeaveFrame
    //     0xc418fc: mov             SP, fp
    //     0xc41900: ldp             fp, lr, [SP], #0x10
    // 0xc41904: ret
    //     0xc41904: ret             
    // 0xc41908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc41908: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4190c: b               #0xc41854
  }
  X2? remove(CanonicalizedMap<X0, X1, X2>, Object?) {
    // ** addr: 0xc4ce68, size: 0x1ac
    // 0xc4ce68: EnterFrame
    //     0xc4ce68: stp             fp, lr, [SP, #-0x10]!
    //     0xc4ce6c: mov             fp, SP
    // 0xc4ce70: AllocStack(0x10)
    //     0xc4ce70: sub             SP, SP, #0x10
    // 0xc4ce74: CheckStackOverflow
    //     0xc4ce74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4ce78: cmp             SP, x16
    //     0xc4ce7c: b.ls            #0xc4d00c
    // 0xc4ce80: ldr             x3, [fp, #0x18]
    // 0xc4ce84: LoadField: r4 = r3->field_7
    //     0xc4ce84: ldur            w4, [x3, #7]
    // 0xc4ce88: DecompressPointer r4
    //     0xc4ce88: add             x4, x4, HEAP, lsl #32
    // 0xc4ce8c: ldr             x0, [fp, #0x10]
    // 0xc4ce90: mov             x2, x4
    // 0xc4ce94: stur            x4, [fp, #-8]
    // 0xc4ce98: r1 = Null
    //     0xc4ce98: mov             x1, NULL
    // 0xc4ce9c: cmp             w2, NULL
    // 0xc4cea0: b.eq            #0xc4cf40
    // 0xc4cea4: LoadField: r3 = r2->field_1b
    //     0xc4cea4: ldur            w3, [x2, #0x1b]
    // 0xc4cea8: DecompressPointer r3
    //     0xc4cea8: add             x3, x3, HEAP, lsl #32
    // 0xc4ceac: ldr             x16, [THR, #0xf0]  ; THR::dynamic_type
    // 0xc4ceb0: cmp             w3, w16
    // 0xc4ceb4: b.eq            #0xc4cf40
    // 0xc4ceb8: r16 = Object?
    //     0xc4ceb8: ldr             x16, [PP, #0x1878]  ; [pp+0x1878] Type: Object?
    // 0xc4cebc: cmp             w3, w16
    // 0xc4cec0: b.eq            #0xc4cf40
    // 0xc4cec4: r16 = void?
    //     0xc4cec4: ldr             x16, [PP, #0x1880]  ; [pp+0x1880] Type: void?
    // 0xc4cec8: cmp             w3, w16
    // 0xc4cecc: b.eq            #0xc4cf40
    // 0xc4ced0: tbnz            w0, #0, #0xc4ceec
    // 0xc4ced4: r16 = int
    //     0xc4ced4: ldr             x16, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc4ced8: cmp             w3, w16
    // 0xc4cedc: b.eq            #0xc4cf40
    // 0xc4cee0: r16 = num
    //     0xc4cee0: ldr             x16, [PP, #0x1888]  ; [pp+0x1888] Type: num
    // 0xc4cee4: cmp             w3, w16
    // 0xc4cee8: b.eq            #0xc4cf40
    // 0xc4ceec: r8 = X1
    //     0xc4ceec: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d708] TypeParameter: X1
    //     0xc4cef0: ldr             x8, [x8, #0x708]
    // 0xc4cef4: r3 = SubtypeTestCache
    //     0xc4cef4: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d710] SubtypeTestCache
    //     0xc4cef8: ldr             x3, [x3, #0x710]
    // 0xc4cefc: r24 = Subtype7TestCacheStub
    //     0xc4cefc: ldr             x24, [PP, #0x18]  ; [pp+0x18] Stub: Subtype7TestCache (0x4ae0ac)
    // 0xc4cf00: LoadField: r30 = r24->field_7
    //     0xc4cf00: ldur            lr, [x24, #7]
    // 0xc4cf04: blr             lr
    // 0xc4cf08: cmp             w7, NULL
    // 0xc4cf0c: b.eq            #0xc4cf18
    // 0xc4cf10: tbnz            w7, #4, #0xc4cf38
    // 0xc4cf14: b               #0xc4cf40
    // 0xc4cf18: r8 = X1
    //     0xc4cf18: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d718] TypeParameter: X1
    //     0xc4cf1c: ldr             x8, [x8, #0x718]
    // 0xc4cf20: r3 = SubtypeTestCache
    //     0xc4cf20: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d720] SubtypeTestCache
    //     0xc4cf24: ldr             x3, [x3, #0x720]
    // 0xc4cf28: r24 = InstanceOfStub
    //     0xc4cf28: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc4cf2c: LoadField: r30 = r24->field_7
    //     0xc4cf2c: ldur            lr, [x24, #7]
    // 0xc4cf30: blr             lr
    // 0xc4cf34: b               #0xc4cf44
    // 0xc4cf38: r0 = false
    //     0xc4cf38: add             x0, NULL, #0x30  ; false
    // 0xc4cf3c: b               #0xc4cf44
    // 0xc4cf40: r0 = true
    //     0xc4cf40: add             x0, NULL, #0x20  ; true
    // 0xc4cf44: tbnz            w0, #4, #0xc4cffc
    // 0xc4cf48: ldr             x3, [fp, #0x18]
    // 0xc4cf4c: LoadField: r4 = r3->field_13
    //     0xc4cf4c: ldur            w4, [x3, #0x13]
    // 0xc4cf50: DecompressPointer r4
    //     0xc4cf50: add             x4, x4, HEAP, lsl #32
    // 0xc4cf54: ldr             x0, [fp, #0x10]
    // 0xc4cf58: ldur            x2, [fp, #-8]
    // 0xc4cf5c: stur            x4, [fp, #-0x10]
    // 0xc4cf60: r1 = Null
    //     0xc4cf60: mov             x1, NULL
    // 0xc4cf64: cmp             w2, NULL
    // 0xc4cf68: b.eq            #0xc4cf88
    // 0xc4cf6c: LoadField: r4 = r2->field_1b
    //     0xc4cf6c: ldur            w4, [x2, #0x1b]
    // 0xc4cf70: DecompressPointer r4
    //     0xc4cf70: add             x4, x4, HEAP, lsl #32
    // 0xc4cf74: r8 = X1
    //     0xc4cf74: ldr             x8, [PP, #0x9a0]  ; [pp+0x9a0] TypeParameter: X1
    // 0xc4cf78: LoadField: r9 = r4->field_7
    //     0xc4cf78: ldur            x9, [x4, #7]
    // 0xc4cf7c: r3 = Null
    //     0xc4cf7c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d728] Null
    //     0xc4cf80: ldr             x3, [x3, #0x728]
    // 0xc4cf84: blr             x9
    // 0xc4cf88: ldr             x0, [fp, #0x18]
    // 0xc4cf8c: LoadField: r1 = r0->field_b
    //     0xc4cf8c: ldur            w1, [x0, #0xb]
    // 0xc4cf90: DecompressPointer r1
    //     0xc4cf90: add             x1, x1, HEAP, lsl #32
    // 0xc4cf94: ldr             x16, [fp, #0x10]
    // 0xc4cf98: stp             x16, x1, [SP, #-0x10]!
    // 0xc4cf9c: mov             x0, x1
    // 0xc4cfa0: ClosureCall
    //     0xc4cfa0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc4cfa4: ldur            x2, [x0, #0x1f]
    //     0xc4cfa8: blr             x2
    // 0xc4cfac: add             SP, SP, #0x10
    // 0xc4cfb0: ldur            x16, [fp, #-0x10]
    // 0xc4cfb4: stp             x0, x16, [SP, #-0x10]!
    // 0xc4cfb8: r0 = remove()
    //     0xc4cfb8: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc4cfbc: add             SP, SP, #0x10
    // 0xc4cfc0: cmp             w0, NULL
    // 0xc4cfc4: b.ne            #0xc4cfd0
    // 0xc4cfc8: r0 = Null
    //     0xc4cfc8: mov             x0, NULL
    // 0xc4cfcc: b               #0xc4cff0
    // 0xc4cfd0: r1 = LoadClassIdInstr(r0)
    //     0xc4cfd0: ldur            x1, [x0, #-1]
    //     0xc4cfd4: ubfx            x1, x1, #0xc, #0x14
    // 0xc4cfd8: SaveReg r0
    //     0xc4cfd8: str             x0, [SP, #-8]!
    // 0xc4cfdc: mov             x0, x1
    // 0xc4cfe0: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xc4cfe0: sub             lr, x0, #0xfc4
    //     0xc4cfe4: ldr             lr, [x21, lr, lsl #3]
    //     0xc4cfe8: blr             lr
    // 0xc4cfec: add             SP, SP, #8
    // 0xc4cff0: LeaveFrame
    //     0xc4cff0: mov             SP, fp
    //     0xc4cff4: ldp             fp, lr, [SP], #0x10
    // 0xc4cff8: ret
    //     0xc4cff8: ret             
    // 0xc4cffc: r0 = Null
    //     0xc4cffc: mov             x0, NULL
    // 0xc4d000: LeaveFrame
    //     0xc4d000: mov             SP, fp
    //     0xc4d004: ldp             fp, lr, [SP], #0x10
    // 0xc4d008: ret
    //     0xc4d008: ret             
    // 0xc4d00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4d00c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4d010: b               #0xc4ce80
  }
  get _ keys(/* No info */) {
    // ** addr: 0xc4d904, size: 0xd0
    // 0xc4d904: EnterFrame
    //     0xc4d904: stp             fp, lr, [SP, #-0x10]!
    //     0xc4d908: mov             fp, SP
    // 0xc4d90c: AllocStack(0x18)
    //     0xc4d90c: sub             SP, SP, #0x18
    // 0xc4d910: CheckStackOverflow
    //     0xc4d910: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4d914: cmp             SP, x16
    //     0xc4d918: b.ls            #0xc4d9cc
    // 0xc4d91c: r1 = 1
    //     0xc4d91c: mov             x1, #1
    // 0xc4d920: r0 = AllocateContext()
    //     0xc4d920: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc4d924: mov             x4, x0
    // 0xc4d928: ldr             x0, [fp, #0x10]
    // 0xc4d92c: stur            x4, [fp, #-0x10]
    // 0xc4d930: StoreField: r4->field_f = r0
    //     0xc4d930: stur            w0, [x4, #0xf]
    // 0xc4d934: LoadField: r5 = r0->field_7
    //     0xc4d934: ldur            w5, [x0, #7]
    // 0xc4d938: DecompressPointer r5
    //     0xc4d938: add             x5, x5, HEAP, lsl #32
    // 0xc4d93c: mov             x2, x5
    // 0xc4d940: stur            x5, [fp, #-8]
    // 0xc4d944: r1 = Null
    //     0xc4d944: mov             x1, NULL
    // 0xc4d948: r3 = <X1>
    //     0xc4d948: ldr             x3, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <X1>
    // 0xc4d94c: r0 = Null
    //     0xc4d94c: mov             x0, NULL
    // 0xc4d950: cmp             x2, x0
    // 0xc4d954: b.eq            #0xc4d964
    // 0xc4d958: r24 = InstantiateTypeArgumentsStub
    //     0xc4d958: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xc4d95c: LoadField: r30 = r24->field_7
    //     0xc4d95c: ldur            lr, [x24, #7]
    // 0xc4d960: blr             lr
    // 0xc4d964: mov             x1, x0
    // 0xc4d968: ldr             x0, [fp, #0x10]
    // 0xc4d96c: stur            x1, [fp, #-0x18]
    // 0xc4d970: LoadField: r2 = r0->field_13
    //     0xc4d970: ldur            w2, [x0, #0x13]
    // 0xc4d974: DecompressPointer r2
    //     0xc4d974: add             x2, x2, HEAP, lsl #32
    // 0xc4d978: SaveReg r2
    //     0xc4d978: str             x2, [SP, #-8]!
    // 0xc4d97c: r0 = values()
    //     0xc4d97c: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0xc4d980: add             SP, SP, #8
    // 0xc4d984: ldur            x2, [fp, #-0x10]
    // 0xc4d988: r1 = Function '<anonymous closure>':.
    //     0xc4d988: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d770] AnonymousClosure: (0xc4d9d4), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::keys (0xc4d904)
    //     0xc4d98c: ldr             x1, [x1, #0x770]
    // 0xc4d990: stur            x0, [fp, #-0x10]
    // 0xc4d994: r0 = AllocateClosure()
    //     0xc4d994: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc4d998: mov             x1, x0
    // 0xc4d99c: ldur            x0, [fp, #-8]
    // 0xc4d9a0: StoreField: r1->field_7 = r0
    //     0xc4d9a0: stur            w0, [x1, #7]
    // 0xc4d9a4: ldur            x16, [fp, #-0x18]
    // 0xc4d9a8: ldur            lr, [fp, #-0x10]
    // 0xc4d9ac: stp             lr, x16, [SP, #-0x10]!
    // 0xc4d9b0: SaveReg r1
    //     0xc4d9b0: str             x1, [SP, #-8]!
    // 0xc4d9b4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc4d9b4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc4d9b8: r0 = map()
    //     0xc4d9b8: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0xc4d9bc: add             SP, SP, #0x18
    // 0xc4d9c0: LeaveFrame
    //     0xc4d9c0: mov             SP, fp
    //     0xc4d9c4: ldp             fp, lr, [SP], #0x10
    // 0xc4d9c8: ret
    //     0xc4d9c8: ret             
    // 0xc4d9cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4d9cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4d9d0: b               #0xc4d91c
  }
  [closure] X1 <anonymous closure>(dynamic, MapEntry<X1, X2>) {
    // ** addr: 0xc4d9d4, size: 0x4c
    // 0xc4d9d4: EnterFrame
    //     0xc4d9d4: stp             fp, lr, [SP, #-0x10]!
    //     0xc4d9d8: mov             fp, SP
    // 0xc4d9dc: CheckStackOverflow
    //     0xc4d9dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4d9e0: cmp             SP, x16
    //     0xc4d9e4: b.ls            #0xc4da18
    // 0xc4d9e8: ldr             x0, [fp, #0x10]
    // 0xc4d9ec: r1 = LoadClassIdInstr(r0)
    //     0xc4d9ec: ldur            x1, [x0, #-1]
    //     0xc4d9f0: ubfx            x1, x1, #0xc, #0x14
    // 0xc4d9f4: SaveReg r0
    //     0xc4d9f4: str             x0, [SP, #-8]!
    // 0xc4d9f8: mov             x0, x1
    // 0xc4d9fc: r0 = GDT[cid_x0 + -0xfba]()
    //     0xc4d9fc: sub             lr, x0, #0xfba
    //     0xc4da00: ldr             lr, [x21, lr, lsl #3]
    //     0xc4da04: blr             lr
    // 0xc4da08: add             SP, SP, #8
    // 0xc4da0c: LeaveFrame
    //     0xc4da0c: mov             SP, fp
    //     0xc4da10: ldp             fp, lr, [SP], #0x10
    // 0xc4da14: ret
    //     0xc4da14: ret             
    // 0xc4da18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4da18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4da1c: b               #0xc4d9e8
  }
  void forEach(CanonicalizedMap<X0, X1, X2>, (dynamic, X1, X2) => void) {
    // ** addr: 0xc52604, size: 0x90
    // 0xc52604: EnterFrame
    //     0xc52604: stp             fp, lr, [SP, #-0x10]!
    //     0xc52608: mov             fp, SP
    // 0xc5260c: AllocStack(0x10)
    //     0xc5260c: sub             SP, SP, #0x10
    // 0xc52610: CheckStackOverflow
    //     0xc52610: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc52614: cmp             SP, x16
    //     0xc52618: b.ls            #0xc5268c
    // 0xc5261c: r1 = 2
    //     0xc5261c: mov             x1, #2
    // 0xc52620: r0 = AllocateContext()
    //     0xc52620: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc52624: mov             x1, x0
    // 0xc52628: ldr             x0, [fp, #0x18]
    // 0xc5262c: StoreField: r1->field_f = r0
    //     0xc5262c: stur            w0, [x1, #0xf]
    // 0xc52630: ldr             x2, [fp, #0x10]
    // 0xc52634: StoreField: r1->field_13 = r2
    //     0xc52634: stur            w2, [x1, #0x13]
    // 0xc52638: LoadField: r3 = r0->field_13
    //     0xc52638: ldur            w3, [x0, #0x13]
    // 0xc5263c: DecompressPointer r3
    //     0xc5263c: add             x3, x3, HEAP, lsl #32
    // 0xc52640: stur            x3, [fp, #-0x10]
    // 0xc52644: LoadField: r4 = r0->field_7
    //     0xc52644: ldur            w4, [x0, #7]
    // 0xc52648: DecompressPointer r4
    //     0xc52648: add             x4, x4, HEAP, lsl #32
    // 0xc5264c: mov             x2, x1
    // 0xc52650: stur            x4, [fp, #-8]
    // 0xc52654: r1 = Function '<anonymous closure>':.
    //     0xc52654: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d790] AnonymousClosure: (0xc02e4c), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::map (0xc02d74)
    //     0xc52658: ldr             x1, [x1, #0x790]
    // 0xc5265c: r0 = AllocateClosure()
    //     0xc5265c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc52660: mov             x1, x0
    // 0xc52664: ldur            x0, [fp, #-8]
    // 0xc52668: StoreField: r1->field_7 = r0
    //     0xc52668: stur            w0, [x1, #7]
    // 0xc5266c: ldur            x16, [fp, #-0x10]
    // 0xc52670: stp             x1, x16, [SP, #-0x10]!
    // 0xc52674: r0 = forEach()
    //     0xc52674: bl              #0xca3d28  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0xc52678: add             SP, SP, #0x10
    // 0xc5267c: r0 = Null
    //     0xc5267c: mov             x0, NULL
    // 0xc52680: LeaveFrame
    //     0xc52680: mov             SP, fp
    //     0xc52684: ldp             fp, lr, [SP], #0x10
    // 0xc52688: ret
    //     0xc52688: ret             
    // 0xc5268c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5268c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc52690: b               #0xc5261c
  }
}

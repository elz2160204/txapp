// lib: , url: package:collection/src/wrappers.dart

// class id: 1048773, size: 0x8
class :: {
}

// class id: 4768, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class _DelegatingIterableBase<X0> extends Object
    implements Iterable<X0> {

  bool isEmpty(_DelegatingIterableBase<X0>) {
    // ** addr: 0x6bc248, size: 0x40
    // 0x6bc248: ldr             x1, [SP]
    // 0x6bc24c: LoadField: r2 = r1->field_b
    //     0x6bc24c: ldur            w2, [x1, #0xb]
    // 0x6bc250: DecompressPointer r2
    //     0x6bc250: add             x2, x2, HEAP, lsl #32
    // 0x6bc254: LoadField: r1 = r2->field_b
    //     0x6bc254: ldur            w1, [x2, #0xb]
    // 0x6bc258: DecompressPointer r1
    //     0x6bc258: add             x1, x1, HEAP, lsl #32
    // 0x6bc25c: cbz             w1, #0x6bc268
    // 0x6bc260: r0 = false
    //     0x6bc260: add             x0, NULL, #0x30  ; false
    // 0x6bc264: b               #0x6bc26c
    // 0x6bc268: r0 = true
    //     0x6bc268: add             x0, NULL, #0x20  ; true
    // 0x6bc26c: ret
    //     0x6bc26c: ret             
  }
  bool isNotEmpty(_DelegatingIterableBase<X0>) {
    // ** addr: 0x6bc968, size: 0x40
    // 0x6bc968: ldr             x1, [SP]
    // 0x6bc96c: LoadField: r2 = r1->field_b
    //     0x6bc96c: ldur            w2, [x1, #0xb]
    // 0x6bc970: DecompressPointer r2
    //     0x6bc970: add             x2, x2, HEAP, lsl #32
    // 0x6bc974: LoadField: r1 = r2->field_b
    //     0x6bc974: ldur            w1, [x2, #0xb]
    // 0x6bc978: DecompressPointer r1
    //     0x6bc978: add             x1, x1, HEAP, lsl #32
    // 0x6bc97c: cbnz            w1, #0x6bc988
    // 0x6bc980: r0 = false
    //     0x6bc980: add             x0, NULL, #0x30  ; false
    // 0x6bc984: b               #0x6bc98c
    // 0x6bc988: r0 = true
    //     0x6bc988: add             x0, NULL, #0x20  ; true
    // 0x6bc98c: ret
    //     0x6bc98c: ret             
  }
  int length(_DelegatingIterableBase<X0>) {
    // ** addr: 0x7174d0, size: 0x30
    // 0x7174d0: ldr             x1, [SP]
    // 0x7174d4: LoadField: r2 = r1->field_b
    //     0x7174d4: ldur            w2, [x1, #0xb]
    // 0x7174d8: DecompressPointer r2
    //     0x7174d8: add             x2, x2, HEAP, lsl #32
    // 0x7174dc: LoadField: r0 = r2->field_b
    //     0x7174dc: ldur            w0, [x2, #0xb]
    // 0x7174e0: DecompressPointer r0
    //     0x7174e0: add             x0, x0, HEAP, lsl #32
    // 0x7174e4: ret
    //     0x7174e4: ret             
  }
  Iterable<Y0> map<Y0>(_DelegatingIterableBase<X0>, (dynamic, X0) => Y0) {
    // ** addr: 0x4c4c54, size: 0xa8
    // 0x4c4c54: EnterFrame
    //     0x4c4c54: stp             fp, lr, [SP, #-0x10]!
    //     0x4c4c58: mov             fp, SP
    // 0x4c4c5c: AllocStack(0x8)
    //     0x4c4c5c: sub             SP, SP, #8
    // 0x4c4c60: SetupParameters()
    //     0x4c4c60: mov             x0, x4
    //     0x4c4c64: ldur            w1, [x0, #0xf]
    //     0x4c4c68: add             x1, x1, HEAP, lsl #32
    //     0x4c4c6c: cbnz            w1, #0x4c4c78
    //     0x4c4c70: mov             x4, NULL
    //     0x4c4c74: b               #0x4c4c8c
    //     0x4c4c78: ldur            w1, [x0, #0x17]
    //     0x4c4c7c: add             x1, x1, HEAP, lsl #32
    //     0x4c4c80: add             x0, fp, w1, sxtw #2
    //     0x4c4c84: ldr             x0, [x0, #0x10]
    //     0x4c4c88: mov             x4, x0
    //     0x4c4c8c: ldr             x3, [fp, #0x18]
    //     0x4c4c90: stur            x4, [fp, #-8]
    // 0x4c4c94: CheckStackOverflow
    //     0x4c4c94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c4c98: cmp             SP, x16
    //     0x4c4c9c: b.ls            #0x4c4cf4
    // 0x4c4ca0: LoadField: r2 = r3->field_7
    //     0x4c4ca0: ldur            w2, [x3, #7]
    // 0x4c4ca4: DecompressPointer r2
    //     0x4c4ca4: add             x2, x2, HEAP, lsl #32
    // 0x4c4ca8: ldr             x0, [fp, #0x10]
    // 0x4c4cac: mov             x1, x4
    // 0x4c4cb0: r8 = (dynamic this, X0) => Y0
    //     0x4c4cb0: add             x8, PP, #0x38, lsl #12  ; [pp+0x38660] FunctionType: (dynamic this, X0) => Y0
    //     0x4c4cb4: ldr             x8, [x8, #0x660]
    // 0x4c4cb8: LoadField: r9 = r8->field_7
    //     0x4c4cb8: ldur            x9, [x8, #7]
    // 0x4c4cbc: r3 = Null
    //     0x4c4cbc: add             x3, PP, #0x38, lsl #12  ; [pp+0x38668] Null
    //     0x4c4cc0: ldr             x3, [x3, #0x668]
    // 0x4c4cc4: blr             x9
    // 0x4c4cc8: ldur            x16, [fp, #-8]
    // 0x4c4ccc: ldr             lr, [fp, #0x18]
    // 0x4c4cd0: stp             lr, x16, [SP, #-0x10]!
    // 0x4c4cd4: ldr             x16, [fp, #0x10]
    // 0x4c4cd8: SaveReg r16
    //     0x4c4cd8: str             x16, [SP, #-8]!
    // 0x4c4cdc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x4c4cdc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x4c4ce0: r0 = map()
    //     0x4c4ce0: bl              #0x6c0800  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::map
    // 0x4c4ce4: add             SP, SP, #0x18
    // 0x4c4ce8: LeaveFrame
    //     0x4c4ce8: mov             SP, fp
    //     0x4c4cec: ldp             fp, lr, [SP], #0x10
    // 0x4c4cf0: ret
    //     0x4c4cf0: ret             
    // 0x4c4cf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c4cf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c4cf8: b               #0x4c4ca0
  }
  void forEach(_DelegatingIterableBase<X0>, (dynamic, X0) => void) {
    // ** addr: 0x4c4d14, size: 0x154
    // 0x4c4d14: EnterFrame
    //     0x4c4d14: stp             fp, lr, [SP, #-0x10]!
    //     0x4c4d18: mov             fp, SP
    // 0x4c4d1c: AllocStack(0x18)
    //     0x4c4d1c: sub             SP, SP, #0x18
    // 0x4c4d20: CheckStackOverflow
    //     0x4c4d20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c4d24: cmp             SP, x16
    //     0x4c4d28: b.ls            #0x4c4e3c
    // 0x4c4d2c: ldr             x3, [fp, #0x18]
    // 0x4c4d30: LoadField: r2 = r3->field_7
    //     0x4c4d30: ldur            w2, [x3, #7]
    // 0x4c4d34: DecompressPointer r2
    //     0x4c4d34: add             x2, x2, HEAP, lsl #32
    // 0x4c4d38: ldr             x0, [fp, #0x10]
    // 0x4c4d3c: r1 = Null
    //     0x4c4d3c: mov             x1, NULL
    // 0x4c4d40: r8 = (dynamic this, X0) => void?
    //     0x4c4d40: add             x8, PP, #9, lsl #12  ; [pp+0x9b48] FunctionType: (dynamic this, X0) => void?
    //     0x4c4d44: ldr             x8, [x8, #0xb48]
    // 0x4c4d48: LoadField: r9 = r8->field_7
    //     0x4c4d48: ldur            x9, [x8, #7]
    // 0x4c4d4c: r3 = Null
    //     0x4c4d4c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d6e8] Null
    //     0x4c4d50: ldr             x3, [x3, #0x6e8]
    // 0x4c4d54: blr             x9
    // 0x4c4d58: ldr             x0, [fp, #0x18]
    // 0x4c4d5c: LoadField: r2 = r0->field_b
    //     0x4c4d5c: ldur            w2, [x0, #0xb]
    // 0x4c4d60: DecompressPointer r2
    //     0x4c4d60: add             x2, x2, HEAP, lsl #32
    // 0x4c4d64: stur            x2, [fp, #-0x18]
    // 0x4c4d68: LoadField: r3 = r2->field_b
    //     0x4c4d68: ldur            w3, [x2, #0xb]
    // 0x4c4d6c: DecompressPointer r3
    //     0x4c4d6c: add             x3, x3, HEAP, lsl #32
    // 0x4c4d70: stur            x3, [fp, #-0x10]
    // 0x4c4d74: r0 = LoadInt32Instr(r3)
    //     0x4c4d74: sbfx            x0, x3, #1, #0x1f
    // 0x4c4d78: r4 = 0
    //     0x4c4d78: mov             x4, #0
    // 0x4c4d7c: stur            x4, [fp, #-8]
    // 0x4c4d80: CheckStackOverflow
    //     0x4c4d80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c4d84: cmp             SP, x16
    //     0x4c4d88: b.ls            #0x4c4e44
    // 0x4c4d8c: cmp             x4, x0
    // 0x4c4d90: b.ge            #0x4c4e10
    // 0x4c4d94: mov             x1, x4
    // 0x4c4d98: cmp             x1, x0
    // 0x4c4d9c: b.hs            #0x4c4e4c
    // 0x4c4da0: LoadField: r0 = r2->field_f
    //     0x4c4da0: ldur            w0, [x2, #0xf]
    // 0x4c4da4: DecompressPointer r0
    //     0x4c4da4: add             x0, x0, HEAP, lsl #32
    // 0x4c4da8: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x4c4da8: add             x16, x0, x4, lsl #2
    //     0x4c4dac: ldur            w1, [x16, #0xf]
    // 0x4c4db0: DecompressPointer r1
    //     0x4c4db0: add             x1, x1, HEAP, lsl #32
    // 0x4c4db4: ldr             x16, [fp, #0x10]
    // 0x4c4db8: stp             x1, x16, [SP, #-0x10]!
    // 0x4c4dbc: ldr             x0, [fp, #0x10]
    // 0x4c4dc0: ClosureCall
    //     0x4c4dc0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4c4dc4: ldur            x2, [x0, #0x1f]
    //     0x4c4dc8: blr             x2
    // 0x4c4dcc: add             SP, SP, #0x10
    // 0x4c4dd0: ldur            x0, [fp, #-0x18]
    // 0x4c4dd4: LoadField: r1 = r0->field_b
    //     0x4c4dd4: ldur            w1, [x0, #0xb]
    // 0x4c4dd8: DecompressPointer r1
    //     0x4c4dd8: add             x1, x1, HEAP, lsl #32
    // 0x4c4ddc: ldur            x2, [fp, #-0x10]
    // 0x4c4de0: cmp             w1, w2
    // 0x4c4de4: b.ne            #0x4c4e20
    // 0x4c4de8: ldur            x3, [fp, #-8]
    // 0x4c4dec: add             x4, x3, #1
    // 0x4c4df0: r3 = LoadInt32Instr(r1)
    //     0x4c4df0: sbfx            x3, x1, #1, #0x1f
    // 0x4c4df4: mov             x16, x2
    // 0x4c4df8: mov             x2, x3
    // 0x4c4dfc: mov             x3, x16
    // 0x4c4e00: mov             x16, x0
    // 0x4c4e04: mov             x0, x2
    // 0x4c4e08: mov             x2, x16
    // 0x4c4e0c: b               #0x4c4d7c
    // 0x4c4e10: r0 = Null
    //     0x4c4e10: mov             x0, NULL
    // 0x4c4e14: LeaveFrame
    //     0x4c4e14: mov             SP, fp
    //     0x4c4e18: ldp             fp, lr, [SP], #0x10
    // 0x4c4e1c: ret
    //     0x4c4e1c: ret             
    // 0x4c4e20: r0 = ConcurrentModificationError()
    //     0x4c4e20: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x4c4e24: mov             x1, x0
    // 0x4c4e28: ldur            x0, [fp, #-0x18]
    // 0x4c4e2c: StoreField: r1->field_b = r0
    //     0x4c4e2c: stur            w0, [x1, #0xb]
    // 0x4c4e30: mov             x0, x1
    // 0x4c4e34: r0 = Throw()
    //     0x4c4e34: bl              #0xd67e38  ; ThrowStub
    // 0x4c4e38: brk             #0
    // 0x4c4e3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c4e3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c4e40: b               #0x4c4d2c
    // 0x4c4e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c4e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c4e48: b               #0x4c4d8c
    // 0x4c4e4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4c4e4c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ takeWhile(/* No info */) {
    // ** addr: 0x4c7278, size: 0x44
    // 0x4c7278: EnterFrame
    //     0x4c7278: stp             fp, lr, [SP, #-0x10]!
    //     0x4c727c: mov             fp, SP
    // 0x4c7280: CheckStackOverflow
    //     0x4c7280: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c7284: cmp             SP, x16
    //     0x4c7288: b.ls            #0x4c72b4
    // 0x4c728c: ldr             x0, [fp, #0x18]
    // 0x4c7290: LoadField: r1 = r0->field_b
    //     0x4c7290: ldur            w1, [x0, #0xb]
    // 0x4c7294: DecompressPointer r1
    //     0x4c7294: add             x1, x1, HEAP, lsl #32
    // 0x4c7298: ldr             x16, [fp, #0x10]
    // 0x4c729c: stp             x16, x1, [SP, #-0x10]!
    // 0x4c72a0: r0 = takeWhile()
    //     0x4c72a0: bl              #0x5ebb24  ; [dart:collection] _ListBase&Object&ListMixin::takeWhile
    // 0x4c72a4: add             SP, SP, #0x10
    // 0x4c72a8: LeaveFrame
    //     0x4c72a8: mov             SP, fp
    //     0x4c72ac: ldp             fp, lr, [SP], #0x10
    // 0x4c72b0: ret
    //     0x4c72b0: ret             
    // 0x4c72b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c72b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c72b8: b               #0x4c728c
  }
  get _ last(/* No info */) {
    // ** addr: 0x5aca64, size: 0x40
    // 0x5aca64: EnterFrame
    //     0x5aca64: stp             fp, lr, [SP, #-0x10]!
    //     0x5aca68: mov             fp, SP
    // 0x5aca6c: CheckStackOverflow
    //     0x5aca6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5aca70: cmp             SP, x16
    //     0x5aca74: b.ls            #0x5aca9c
    // 0x5aca78: ldr             x0, [fp, #0x10]
    // 0x5aca7c: LoadField: r1 = r0->field_b
    //     0x5aca7c: ldur            w1, [x0, #0xb]
    // 0x5aca80: DecompressPointer r1
    //     0x5aca80: add             x1, x1, HEAP, lsl #32
    // 0x5aca84: SaveReg r1
    //     0x5aca84: str             x1, [SP, #-8]!
    // 0x5aca88: r0 = last()
    //     0x5aca88: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0x5aca8c: add             SP, SP, #8
    // 0x5aca90: LeaveFrame
    //     0x5aca90: mov             SP, fp
    //     0x5aca94: ldp             fp, lr, [SP], #0x10
    // 0x5aca98: ret
    //     0x5aca98: ret             
    // 0x5aca9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5aca9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5acaa0: b               #0x5aca78
  }
  _ take(/* No info */) {
    // ** addr: 0x5acc48, size: 0x48
    // 0x5acc48: EnterFrame
    //     0x5acc48: stp             fp, lr, [SP, #-0x10]!
    //     0x5acc4c: mov             fp, SP
    // 0x5acc50: CheckStackOverflow
    //     0x5acc50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5acc54: cmp             SP, x16
    //     0x5acc58: b.ls            #0x5acc88
    // 0x5acc5c: ldr             x0, [fp, #0x18]
    // 0x5acc60: LoadField: r1 = r0->field_b
    //     0x5acc60: ldur            w1, [x0, #0xb]
    // 0x5acc64: DecompressPointer r1
    //     0x5acc64: add             x1, x1, HEAP, lsl #32
    // 0x5acc68: SaveReg r1
    //     0x5acc68: str             x1, [SP, #-8]!
    // 0x5acc6c: ldr             x0, [fp, #0x10]
    // 0x5acc70: SaveReg r0
    //     0x5acc70: str             x0, [SP, #-8]!
    // 0x5acc74: r0 = take()
    //     0x5acc74: bl              #0x622048  ; [dart:collection] _ListBase&Object&ListMixin::take
    // 0x5acc78: add             SP, SP, #0x10
    // 0x5acc7c: LeaveFrame
    //     0x5acc7c: mov             SP, fp
    //     0x5acc80: ldp             fp, lr, [SP], #0x10
    // 0x5acc84: ret
    //     0x5acc84: ret             
    // 0x5acc88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5acc88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5acc8c: b               #0x5acc5c
  }
  _ whereType(/* No info */) {
    // ** addr: 0x63bff4, size: 0x70
    // 0x63bff4: EnterFrame
    //     0x63bff4: stp             fp, lr, [SP, #-0x10]!
    //     0x63bff8: mov             fp, SP
    // 0x63bffc: mov             x0, x4
    // 0x63c000: LoadField: r1 = r0->field_f
    //     0x63c000: ldur            w1, [x0, #0xf]
    // 0x63c004: DecompressPointer r1
    //     0x63c004: add             x1, x1, HEAP, lsl #32
    // 0x63c008: cbnz            w1, #0x63c014
    // 0x63c00c: r1 = Null
    //     0x63c00c: mov             x1, NULL
    // 0x63c010: b               #0x63c028
    // 0x63c014: LoadField: r1 = r0->field_17
    //     0x63c014: ldur            w1, [x0, #0x17]
    // 0x63c018: DecompressPointer r1
    //     0x63c018: add             x1, x1, HEAP, lsl #32
    // 0x63c01c: add             x0, fp, w1, sxtw #2
    // 0x63c020: ldr             x0, [x0, #0x10]
    // 0x63c024: mov             x1, x0
    // 0x63c028: ldr             x0, [fp, #0x10]
    // 0x63c02c: CheckStackOverflow
    //     0x63c02c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63c030: cmp             SP, x16
    //     0x63c034: b.ls            #0x63c05c
    // 0x63c038: LoadField: r2 = r0->field_b
    //     0x63c038: ldur            w2, [x0, #0xb]
    // 0x63c03c: DecompressPointer r2
    //     0x63c03c: add             x2, x2, HEAP, lsl #32
    // 0x63c040: stp             x2, x1, [SP, #-0x10]!
    // 0x63c044: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x63c044: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x63c048: r0 = whereType()
    //     0x63c048: bl              #0x6a7924  ; [dart:collection] _ListBase&Object&ListMixin::whereType
    // 0x63c04c: add             SP, SP, #0x10
    // 0x63c050: LeaveFrame
    //     0x63c050: mov             SP, fp
    //     0x63c054: ldp             fp, lr, [SP], #0x10
    // 0x63c058: ret
    //     0x63c058: ret             
    // 0x63c05c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63c05c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63c060: b               #0x63c038
  }
  _ firstWhere(/* No info */) {
    // ** addr: 0x63e718, size: 0xa0
    // 0x63e718: EnterFrame
    //     0x63e718: stp             fp, lr, [SP, #-0x10]!
    //     0x63e71c: mov             fp, SP
    // 0x63e720: AllocStack(0x10)
    //     0x63e720: sub             SP, SP, #0x10
    // 0x63e724: SetupParameters(_DelegatingIterableBase<X0> this /* r3, fp-0x10 */, dynamic _ /* r4, fp-0x8 */)
    //     0x63e724: mov             x0, x4
    //     0x63e728: ldur            w1, [x0, #0x13]
    //     0x63e72c: add             x1, x1, HEAP, lsl #32
    //     0x63e730: sub             x0, x1, #4
    //     0x63e734: add             x3, fp, w0, sxtw #2
    //     0x63e738: ldr             x3, [x3, #0x18]
    //     0x63e73c: stur            x3, [fp, #-0x10]
    //     0x63e740: add             x4, fp, w0, sxtw #2
    //     0x63e744: ldr             x4, [x4, #0x10]
    //     0x63e748: stur            x4, [fp, #-8]
    // 0x63e74c: CheckStackOverflow
    //     0x63e74c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63e750: cmp             SP, x16
    //     0x63e754: b.ls            #0x63e7b0
    // 0x63e758: LoadField: r2 = r3->field_7
    //     0x63e758: ldur            w2, [x3, #7]
    // 0x63e75c: DecompressPointer r2
    //     0x63e75c: add             x2, x2, HEAP, lsl #32
    // 0x63e760: r0 = Null
    //     0x63e760: mov             x0, NULL
    // 0x63e764: r1 = Null
    //     0x63e764: mov             x1, NULL
    // 0x63e768: r8 = ((dynamic this) => X0)?
    //     0x63e768: add             x8, PP, #0xd, lsl #12  ; [pp+0xd350] FunctionType: ((dynamic this) => X0)?
    //     0x63e76c: ldr             x8, [x8, #0x350]
    // 0x63e770: LoadField: r9 = r8->field_7
    //     0x63e770: ldur            x9, [x8, #7]
    // 0x63e774: r3 = Null
    //     0x63e774: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4ca10] Null
    //     0x63e778: ldr             x3, [x3, #0xa10]
    // 0x63e77c: blr             x9
    // 0x63e780: ldur            x0, [fp, #-0x10]
    // 0x63e784: LoadField: r1 = r0->field_b
    //     0x63e784: ldur            w1, [x0, #0xb]
    // 0x63e788: DecompressPointer r1
    //     0x63e788: add             x1, x1, HEAP, lsl #32
    // 0x63e78c: ldur            x16, [fp, #-8]
    // 0x63e790: stp             x16, x1, [SP, #-0x10]!
    // 0x63e794: SaveReg rNULL
    //     0x63e794: str             NULL, [SP, #-8]!
    // 0x63e798: r4 = const [0, 0x3, 0x3, 0x2, orElse, 0x2, null]
    //     0x63e798: ldr             x4, [PP, #0x6bc8]  ; [pp+0x6bc8] List(7) [0, 0x3, 0x3, 0x2, "orElse", 0x2, Null]
    // 0x63e79c: r0 = firstWhere()
    //     0x63e79c: bl              #0x6a8bc0  ; [dart:collection] _ListBase&Object&ListMixin::firstWhere
    // 0x63e7a0: add             SP, SP, #0x18
    // 0x63e7a4: LeaveFrame
    //     0x63e7a4: mov             SP, fp
    //     0x63e7a8: ldp             fp, lr, [SP], #0x10
    // 0x63e7ac: ret
    //     0x63e7ac: ret             
    // 0x63e7b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e7b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e7b4: b               #0x63e758
  }
  _ toSet(/* No info */) {
    // ** addr: 0x640e34, size: 0x40
    // 0x640e34: EnterFrame
    //     0x640e34: stp             fp, lr, [SP, #-0x10]!
    //     0x640e38: mov             fp, SP
    // 0x640e3c: CheckStackOverflow
    //     0x640e3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640e40: cmp             SP, x16
    //     0x640e44: b.ls            #0x640e6c
    // 0x640e48: ldr             x0, [fp, #0x10]
    // 0x640e4c: LoadField: r1 = r0->field_b
    //     0x640e4c: ldur            w1, [x0, #0xb]
    // 0x640e50: DecompressPointer r1
    //     0x640e50: add             x1, x1, HEAP, lsl #32
    // 0x640e54: SaveReg r1
    //     0x640e54: str             x1, [SP, #-8]!
    // 0x640e58: r0 = toSet()
    //     0x640e58: bl              #0x6aa2c4  ; [dart:core] _GrowableList::toSet
    // 0x640e5c: add             SP, SP, #8
    // 0x640e60: LeaveFrame
    //     0x640e60: mov             SP, fp
    //     0x640e64: ldp             fp, lr, [SP], #0x10
    // 0x640e68: ret
    //     0x640e68: ret             
    // 0x640e6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640e6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640e70: b               #0x640e48
  }
  _ any(/* No info */) {
    // ** addr: 0x6abbe0, size: 0x44
    // 0x6abbe0: EnterFrame
    //     0x6abbe0: stp             fp, lr, [SP, #-0x10]!
    //     0x6abbe4: mov             fp, SP
    // 0x6abbe8: CheckStackOverflow
    //     0x6abbe8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6abbec: cmp             SP, x16
    //     0x6abbf0: b.ls            #0x6abc1c
    // 0x6abbf4: ldr             x0, [fp, #0x18]
    // 0x6abbf8: LoadField: r1 = r0->field_b
    //     0x6abbf8: ldur            w1, [x0, #0xb]
    // 0x6abbfc: DecompressPointer r1
    //     0x6abbfc: add             x1, x1, HEAP, lsl #32
    // 0x6abc00: ldr             x16, [fp, #0x10]
    // 0x6abc04: stp             x16, x1, [SP, #-0x10]!
    // 0x6abc08: r0 = any()
    //     0x6abc08: bl              #0x6f72b8  ; [dart:collection] _ListBase&Object&ListMixin::any
    // 0x6abc0c: add             SP, SP, #0x10
    // 0x6abc10: LeaveFrame
    //     0x6abc10: mov             SP, fp
    //     0x6abc14: ldp             fp, lr, [SP], #0x10
    // 0x6abc18: ret
    //     0x6abc18: ret             
    // 0x6abc1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6abc1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6abc20: b               #0x6abbf4
  }
  dynamic contains(dynamic) {
    // ** addr: 0x6abe20, size: 0x18
    // 0x6abe20: r4 = 7
    //     0x6abe20: mov             x4, #7
    // 0x6abe24: r1 = Function 'contains':.
    //     0x6abe24: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca08] AnonymousClosure: (0x6abe38), in [package:collection/src/wrappers.dart] _DelegatingIterableBase::contains (0x6c055c)
    //     0x6abe28: ldr             x1, [x17, #0xa08]
    // 0x6abe2c: r24 = BuildNonGenericMethodExtractorStub
    //     0x6abe2c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6abe30: LoadField: r0 = r24->field_17
    //     0x6abe30: ldur            x0, [x24, #0x17]
    // 0x6abe34: br              x0
  }
  [closure] bool contains(dynamic, Object?) {
    // ** addr: 0x6abe38, size: 0x4c
    // 0x6abe38: EnterFrame
    //     0x6abe38: stp             fp, lr, [SP, #-0x10]!
    //     0x6abe3c: mov             fp, SP
    // 0x6abe40: ldr             x0, [fp, #0x18]
    // 0x6abe44: LoadField: r1 = r0->field_17
    //     0x6abe44: ldur            w1, [x0, #0x17]
    // 0x6abe48: DecompressPointer r1
    //     0x6abe48: add             x1, x1, HEAP, lsl #32
    // 0x6abe4c: CheckStackOverflow
    //     0x6abe4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6abe50: cmp             SP, x16
    //     0x6abe54: b.ls            #0x6abe7c
    // 0x6abe58: LoadField: r0 = r1->field_f
    //     0x6abe58: ldur            w0, [x1, #0xf]
    // 0x6abe5c: DecompressPointer r0
    //     0x6abe5c: add             x0, x0, HEAP, lsl #32
    // 0x6abe60: ldr             x16, [fp, #0x10]
    // 0x6abe64: stp             x16, x0, [SP, #-0x10]!
    // 0x6abe68: r0 = contains()
    //     0x6abe68: bl              #0x6c055c  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::contains
    // 0x6abe6c: add             SP, SP, #0x10
    // 0x6abe70: LeaveFrame
    //     0x6abe70: mov             SP, fp
    //     0x6abe74: ldp             fp, lr, [SP], #0x10
    // 0x6abe78: ret
    //     0x6abe78: ret             
    // 0x6abe7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6abe7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6abe80: b               #0x6abe58
  }
  get _ single(/* No info */) {
    // ** addr: 0x6aceb8, size: 0x40
    // 0x6aceb8: EnterFrame
    //     0x6aceb8: stp             fp, lr, [SP, #-0x10]!
    //     0x6acebc: mov             fp, SP
    // 0x6acec0: CheckStackOverflow
    //     0x6acec0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6acec4: cmp             SP, x16
    //     0x6acec8: b.ls            #0x6acef0
    // 0x6acecc: ldr             x0, [fp, #0x10]
    // 0x6aced0: LoadField: r1 = r0->field_b
    //     0x6aced0: ldur            w1, [x0, #0xb]
    // 0x6aced4: DecompressPointer r1
    //     0x6aced4: add             x1, x1, HEAP, lsl #32
    // 0x6aced8: SaveReg r1
    //     0x6aced8: str             x1, [SP, #-8]!
    // 0x6acedc: r0 = single()
    //     0x6acedc: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x6acee0: add             SP, SP, #8
    // 0x6acee4: LeaveFrame
    //     0x6acee4: mov             SP, fp
    //     0x6acee8: ldp             fp, lr, [SP], #0x10
    // 0x6aceec: ret
    //     0x6aceec: ret             
    // 0x6acef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6acef0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6acef4: b               #0x6acecc
  }
  _ where(/* No info */) {
    // ** addr: 0x6ad4d4, size: 0x44
    // 0x6ad4d4: EnterFrame
    //     0x6ad4d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6ad4d8: mov             fp, SP
    // 0x6ad4dc: CheckStackOverflow
    //     0x6ad4dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ad4e0: cmp             SP, x16
    //     0x6ad4e4: b.ls            #0x6ad510
    // 0x6ad4e8: ldr             x0, [fp, #0x18]
    // 0x6ad4ec: LoadField: r1 = r0->field_b
    //     0x6ad4ec: ldur            w1, [x0, #0xb]
    // 0x6ad4f0: DecompressPointer r1
    //     0x6ad4f0: add             x1, x1, HEAP, lsl #32
    // 0x6ad4f4: ldr             x16, [fp, #0x10]
    // 0x6ad4f8: stp             x16, x1, [SP, #-0x10]!
    // 0x6ad4fc: r0 = where()
    //     0x6ad4fc: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0x6ad500: add             SP, SP, #0x10
    // 0x6ad504: LeaveFrame
    //     0x6ad504: mov             SP, fp
    //     0x6ad508: ldp             fp, lr, [SP], #0x10
    // 0x6ad50c: ret
    //     0x6ad50c: ret             
    // 0x6ad510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ad510: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ad514: b               #0x6ad4e8
  }
  _ join(/* No info */) {
    // ** addr: 0x6b84e4, size: 0x74
    // 0x6b84e4: EnterFrame
    //     0x6b84e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6b84e8: mov             fp, SP
    // 0x6b84ec: mov             x0, x4
    // 0x6b84f0: LoadField: r1 = r0->field_13
    //     0x6b84f0: ldur            w1, [x0, #0x13]
    // 0x6b84f4: DecompressPointer r1
    //     0x6b84f4: add             x1, x1, HEAP, lsl #32
    // 0x6b84f8: sub             x0, x1, #2
    // 0x6b84fc: add             x1, fp, w0, sxtw #2
    // 0x6b8500: ldr             x1, [x1, #0x10]
    // 0x6b8504: cmp             w0, #2
    // 0x6b8508: b.lt            #0x6b851c
    // 0x6b850c: add             x2, fp, w0, sxtw #2
    // 0x6b8510: ldr             x2, [x2, #8]
    // 0x6b8514: mov             x0, x2
    // 0x6b8518: b               #0x6b8520
    // 0x6b851c: r0 = ""
    //     0x6b851c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x6b8520: CheckStackOverflow
    //     0x6b8520: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b8524: cmp             SP, x16
    //     0x6b8528: b.ls            #0x6b8550
    // 0x6b852c: LoadField: r2 = r1->field_b
    //     0x6b852c: ldur            w2, [x1, #0xb]
    // 0x6b8530: DecompressPointer r2
    //     0x6b8530: add             x2, x2, HEAP, lsl #32
    // 0x6b8534: stp             x0, x2, [SP, #-0x10]!
    // 0x6b8538: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6b8538: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6b853c: r0 = join()
    //     0x6b853c: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0x6b8540: add             SP, SP, #0x10
    // 0x6b8544: LeaveFrame
    //     0x6b8544: mov             SP, fp
    //     0x6b8548: ldp             fp, lr, [SP], #0x10
    // 0x6b854c: ret
    //     0x6b854c: ret             
    // 0x6b8550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b8550: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b8554: b               #0x6b852c
  }
  void forEach(_DelegatingIterableBase<X0>, (dynamic, X0) => void) {
    // ** addr: 0x6ba3c0, size: 0x110
    // 0x6ba3c0: EnterFrame
    //     0x6ba3c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6ba3c4: mov             fp, SP
    // 0x6ba3c8: AllocStack(0x18)
    //     0x6ba3c8: sub             SP, SP, #0x18
    // 0x6ba3cc: CheckStackOverflow
    //     0x6ba3cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ba3d0: cmp             SP, x16
    //     0x6ba3d4: b.ls            #0x6ba4bc
    // 0x6ba3d8: ldr             x0, [fp, #0x18]
    // 0x6ba3dc: LoadField: r2 = r0->field_b
    //     0x6ba3dc: ldur            w2, [x0, #0xb]
    // 0x6ba3e0: DecompressPointer r2
    //     0x6ba3e0: add             x2, x2, HEAP, lsl #32
    // 0x6ba3e4: stur            x2, [fp, #-0x18]
    // 0x6ba3e8: LoadField: r3 = r2->field_b
    //     0x6ba3e8: ldur            w3, [x2, #0xb]
    // 0x6ba3ec: DecompressPointer r3
    //     0x6ba3ec: add             x3, x3, HEAP, lsl #32
    // 0x6ba3f0: stur            x3, [fp, #-0x10]
    // 0x6ba3f4: r0 = LoadInt32Instr(r3)
    //     0x6ba3f4: sbfx            x0, x3, #1, #0x1f
    // 0x6ba3f8: r4 = 0
    //     0x6ba3f8: mov             x4, #0
    // 0x6ba3fc: stur            x4, [fp, #-8]
    // 0x6ba400: CheckStackOverflow
    //     0x6ba400: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ba404: cmp             SP, x16
    //     0x6ba408: b.ls            #0x6ba4c4
    // 0x6ba40c: cmp             x4, x0
    // 0x6ba410: b.ge            #0x6ba490
    // 0x6ba414: mov             x1, x4
    // 0x6ba418: cmp             x1, x0
    // 0x6ba41c: b.hs            #0x6ba4cc
    // 0x6ba420: LoadField: r0 = r2->field_f
    //     0x6ba420: ldur            w0, [x2, #0xf]
    // 0x6ba424: DecompressPointer r0
    //     0x6ba424: add             x0, x0, HEAP, lsl #32
    // 0x6ba428: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x6ba428: add             x16, x0, x4, lsl #2
    //     0x6ba42c: ldur            w1, [x16, #0xf]
    // 0x6ba430: DecompressPointer r1
    //     0x6ba430: add             x1, x1, HEAP, lsl #32
    // 0x6ba434: ldr             x16, [fp, #0x10]
    // 0x6ba438: stp             x1, x16, [SP, #-0x10]!
    // 0x6ba43c: ldr             x0, [fp, #0x10]
    // 0x6ba440: ClosureCall
    //     0x6ba440: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6ba444: ldur            x2, [x0, #0x1f]
    //     0x6ba448: blr             x2
    // 0x6ba44c: add             SP, SP, #0x10
    // 0x6ba450: ldur            x0, [fp, #-0x18]
    // 0x6ba454: LoadField: r1 = r0->field_b
    //     0x6ba454: ldur            w1, [x0, #0xb]
    // 0x6ba458: DecompressPointer r1
    //     0x6ba458: add             x1, x1, HEAP, lsl #32
    // 0x6ba45c: ldur            x2, [fp, #-0x10]
    // 0x6ba460: cmp             w1, w2
    // 0x6ba464: b.ne            #0x6ba4a0
    // 0x6ba468: ldur            x3, [fp, #-8]
    // 0x6ba46c: add             x4, x3, #1
    // 0x6ba470: r3 = LoadInt32Instr(r1)
    //     0x6ba470: sbfx            x3, x1, #1, #0x1f
    // 0x6ba474: mov             x16, x2
    // 0x6ba478: mov             x2, x3
    // 0x6ba47c: mov             x3, x16
    // 0x6ba480: mov             x16, x0
    // 0x6ba484: mov             x0, x2
    // 0x6ba488: mov             x2, x16
    // 0x6ba48c: b               #0x6ba3fc
    // 0x6ba490: r0 = Null
    //     0x6ba490: mov             x0, NULL
    // 0x6ba494: LeaveFrame
    //     0x6ba494: mov             SP, fp
    //     0x6ba498: ldp             fp, lr, [SP], #0x10
    // 0x6ba49c: ret
    //     0x6ba49c: ret             
    // 0x6ba4a0: r0 = ConcurrentModificationError()
    //     0x6ba4a0: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6ba4a4: mov             x1, x0
    // 0x6ba4a8: ldur            x0, [fp, #-0x18]
    // 0x6ba4ac: StoreField: r1->field_b = r0
    //     0x6ba4ac: stur            w0, [x1, #0xb]
    // 0x6ba4b0: mov             x0, x1
    // 0x6ba4b4: r0 = Throw()
    //     0x6ba4b4: bl              #0xd67e38  ; ThrowStub
    // 0x6ba4b8: brk             #0
    // 0x6ba4bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ba4bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ba4c0: b               #0x6ba3d8
    // 0x6ba4c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ba4c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ba4c8: b               #0x6ba40c
    // 0x6ba4cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6ba4cc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ skip(/* No info */) {
    // ** addr: 0x6bb4c0, size: 0x48
    // 0x6bb4c0: EnterFrame
    //     0x6bb4c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6bb4c4: mov             fp, SP
    // 0x6bb4c8: CheckStackOverflow
    //     0x6bb4c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bb4cc: cmp             SP, x16
    //     0x6bb4d0: b.ls            #0x6bb500
    // 0x6bb4d4: ldr             x0, [fp, #0x18]
    // 0x6bb4d8: LoadField: r1 = r0->field_b
    //     0x6bb4d8: ldur            w1, [x0, #0xb]
    // 0x6bb4dc: DecompressPointer r1
    //     0x6bb4dc: add             x1, x1, HEAP, lsl #32
    // 0x6bb4e0: SaveReg r1
    //     0x6bb4e0: str             x1, [SP, #-8]!
    // 0x6bb4e4: ldr             x0, [fp, #0x10]
    // 0x6bb4e8: SaveReg r0
    //     0x6bb4e8: str             x0, [SP, #-8]!
    // 0x6bb4ec: r0 = skip()
    //     0x6bb4ec: bl              #0x7118b4  ; [dart:collection] _ListBase&Object&ListMixin::skip
    // 0x6bb4f0: add             SP, SP, #0x10
    // 0x6bb4f4: LeaveFrame
    //     0x6bb4f4: mov             SP, fp
    //     0x6bb4f8: ldp             fp, lr, [SP], #0x10
    // 0x6bb4fc: ret
    //     0x6bb4fc: ret             
    // 0x6bb500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bb500: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bb504: b               #0x6bb4d4
  }
  get _ first(/* No info */) {
    // ** addr: 0x6bf0fc, size: 0x40
    // 0x6bf0fc: EnterFrame
    //     0x6bf0fc: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf100: mov             fp, SP
    // 0x6bf104: CheckStackOverflow
    //     0x6bf104: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf108: cmp             SP, x16
    //     0x6bf10c: b.ls            #0x6bf134
    // 0x6bf110: ldr             x0, [fp, #0x10]
    // 0x6bf114: LoadField: r1 = r0->field_b
    //     0x6bf114: ldur            w1, [x0, #0xb]
    // 0x6bf118: DecompressPointer r1
    //     0x6bf118: add             x1, x1, HEAP, lsl #32
    // 0x6bf11c: SaveReg r1
    //     0x6bf11c: str             x1, [SP, #-8]!
    // 0x6bf120: r0 = first()
    //     0x6bf120: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0x6bf124: add             SP, SP, #8
    // 0x6bf128: LeaveFrame
    //     0x6bf128: mov             SP, fp
    //     0x6bf12c: ldp             fp, lr, [SP], #0x10
    // 0x6bf130: ret
    //     0x6bf130: ret             
    // 0x6bf134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf134: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf138: b               #0x6bf110
  }
  _ contains(/* No info */) {
    // ** addr: 0x6c055c, size: 0x44
    // 0x6c055c: EnterFrame
    //     0x6c055c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0560: mov             fp, SP
    // 0x6c0564: CheckStackOverflow
    //     0x6c0564: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c0568: cmp             SP, x16
    //     0x6c056c: b.ls            #0x6c0598
    // 0x6c0570: ldr             x0, [fp, #0x18]
    // 0x6c0574: LoadField: r1 = r0->field_b
    //     0x6c0574: ldur            w1, [x0, #0xb]
    // 0x6c0578: DecompressPointer r1
    //     0x6c0578: add             x1, x1, HEAP, lsl #32
    // 0x6c057c: ldr             x16, [fp, #0x10]
    // 0x6c0580: stp             x16, x1, [SP, #-0x10]!
    // 0x6c0584: r0 = contains()
    //     0x6c0584: bl              #0x786724  ; [dart:collection] _ListBase&Object&ListMixin::contains
    // 0x6c0588: add             SP, SP, #0x10
    // 0x6c058c: LeaveFrame
    //     0x6c058c: mov             SP, fp
    //     0x6c0590: ldp             fp, lr, [SP], #0x10
    // 0x6c0594: ret
    //     0x6c0594: ret             
    // 0x6c0598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0598: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c059c: b               #0x6c0570
  }
  Iterable<Y0> map<Y0>(_DelegatingIterableBase<X0>, (dynamic, X0) => Y0) {
    // ** addr: 0x6c0800, size: 0x78
    // 0x6c0800: EnterFrame
    //     0x6c0800: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0804: mov             fp, SP
    // 0x6c0808: mov             x0, x4
    // 0x6c080c: LoadField: r1 = r0->field_f
    //     0x6c080c: ldur            w1, [x0, #0xf]
    // 0x6c0810: DecompressPointer r1
    //     0x6c0810: add             x1, x1, HEAP, lsl #32
    // 0x6c0814: cbnz            w1, #0x6c0820
    // 0x6c0818: r1 = Null
    //     0x6c0818: mov             x1, NULL
    // 0x6c081c: b               #0x6c0834
    // 0x6c0820: LoadField: r1 = r0->field_17
    //     0x6c0820: ldur            w1, [x0, #0x17]
    // 0x6c0824: DecompressPointer r1
    //     0x6c0824: add             x1, x1, HEAP, lsl #32
    // 0x6c0828: add             x0, fp, w1, sxtw #2
    // 0x6c082c: ldr             x0, [x0, #0x10]
    // 0x6c0830: mov             x1, x0
    // 0x6c0834: ldr             x0, [fp, #0x18]
    // 0x6c0838: CheckStackOverflow
    //     0x6c0838: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c083c: cmp             SP, x16
    //     0x6c0840: b.ls            #0x6c0870
    // 0x6c0844: LoadField: r2 = r0->field_b
    //     0x6c0844: ldur            w2, [x0, #0xb]
    // 0x6c0848: DecompressPointer r2
    //     0x6c0848: add             x2, x2, HEAP, lsl #32
    // 0x6c084c: stp             x2, x1, [SP, #-0x10]!
    // 0x6c0850: ldr             x16, [fp, #0x10]
    // 0x6c0854: SaveReg r16
    //     0x6c0854: str             x16, [SP, #-8]!
    // 0x6c0858: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6c0858: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6c085c: r0 = map()
    //     0x6c085c: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x6c0860: add             SP, SP, #0x18
    // 0x6c0864: LeaveFrame
    //     0x6c0864: mov             SP, fp
    //     0x6c0868: ldp             fp, lr, [SP], #0x10
    // 0x6c086c: ret
    //     0x6c086c: ret             
    // 0x6c0870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0870: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0874: b               #0x6c0844
  }
  _ toList(/* No info */) {
    // ** addr: 0x6c0b5c, size: 0x8c
    // 0x6c0b5c: EnterFrame
    //     0x6c0b5c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0b60: mov             fp, SP
    // 0x6c0b64: mov             x0, x4
    // 0x6c0b68: LoadField: r1 = r0->field_13
    //     0x6c0b68: ldur            w1, [x0, #0x13]
    // 0x6c0b6c: DecompressPointer r1
    //     0x6c0b6c: add             x1, x1, HEAP, lsl #32
    // 0x6c0b70: sub             x2, x1, #2
    // 0x6c0b74: add             x3, fp, w2, sxtw #2
    // 0x6c0b78: ldr             x3, [x3, #0x10]
    // 0x6c0b7c: LoadField: r2 = r0->field_1f
    //     0x6c0b7c: ldur            w2, [x0, #0x1f]
    // 0x6c0b80: DecompressPointer r2
    //     0x6c0b80: add             x2, x2, HEAP, lsl #32
    // 0x6c0b84: r16 = "growable"
    //     0x6c0b84: ldr             x16, [PP, #0xc60]  ; [pp+0xc60] "growable"
    // 0x6c0b88: cmp             w2, w16
    // 0x6c0b8c: b.ne            #0x6c0bac
    // 0x6c0b90: LoadField: r2 = r0->field_23
    //     0x6c0b90: ldur            w2, [x0, #0x23]
    // 0x6c0b94: DecompressPointer r2
    //     0x6c0b94: add             x2, x2, HEAP, lsl #32
    // 0x6c0b98: sub             w0, w1, w2
    // 0x6c0b9c: add             x1, fp, w0, sxtw #2
    // 0x6c0ba0: ldr             x1, [x1, #8]
    // 0x6c0ba4: mov             x0, x1
    // 0x6c0ba8: b               #0x6c0bb0
    // 0x6c0bac: r0 = true
    //     0x6c0bac: add             x0, NULL, #0x20  ; true
    // 0x6c0bb0: CheckStackOverflow
    //     0x6c0bb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c0bb4: cmp             SP, x16
    //     0x6c0bb8: b.ls            #0x6c0be0
    // 0x6c0bbc: LoadField: r1 = r3->field_b
    //     0x6c0bbc: ldur            w1, [x3, #0xb]
    // 0x6c0bc0: DecompressPointer r1
    //     0x6c0bc0: add             x1, x1, HEAP, lsl #32
    // 0x6c0bc4: stp             x0, x1, [SP, #-0x10]!
    // 0x6c0bc8: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0x6c0bc8: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0x6c0bcc: r0 = toList()
    //     0x6c0bcc: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0x6c0bd0: add             SP, SP, #0x10
    // 0x6c0bd4: LeaveFrame
    //     0x6c0bd4: mov             SP, fp
    //     0x6c0bd8: ldp             fp, lr, [SP], #0x10
    // 0x6c0bdc: ret
    //     0x6c0bdc: ret             
    // 0x6c0be0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0be0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0be4: b               #0x6c0bbc
  }
  get _ iterator(/* No info */) {
    // ** addr: 0x717244, size: 0x54
    // 0x717244: EnterFrame
    //     0x717244: stp             fp, lr, [SP, #-0x10]!
    //     0x717248: mov             fp, SP
    // 0x71724c: AllocStack(0x8)
    //     0x71724c: sub             SP, SP, #8
    // 0x717250: ldr             x0, [fp, #0x10]
    // 0x717254: LoadField: r2 = r0->field_b
    //     0x717254: ldur            w2, [x0, #0xb]
    // 0x717258: DecompressPointer r2
    //     0x717258: add             x2, x2, HEAP, lsl #32
    // 0x71725c: stur            x2, [fp, #-8]
    // 0x717260: LoadField: r1 = r2->field_7
    //     0x717260: ldur            w1, [x2, #7]
    // 0x717264: DecompressPointer r1
    //     0x717264: add             x1, x1, HEAP, lsl #32
    // 0x717268: r0 = ListIterator()
    //     0x717268: bl              #0x50a2a0  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x71726c: ldur            x1, [fp, #-8]
    // 0x717270: StoreField: r0->field_b = r1
    //     0x717270: stur            w1, [x0, #0xb]
    // 0x717274: LoadField: r2 = r1->field_b
    //     0x717274: ldur            w2, [x1, #0xb]
    // 0x717278: DecompressPointer r2
    //     0x717278: add             x2, x2, HEAP, lsl #32
    // 0x71727c: r1 = LoadInt32Instr(r2)
    //     0x71727c: sbfx            x1, x2, #1, #0x1f
    // 0x717280: StoreField: r0->field_f = r1
    //     0x717280: stur            x1, [x0, #0xf]
    // 0x717284: r1 = 0
    //     0x717284: mov             x1, #0
    // 0x717288: StoreField: r0->field_17 = r1
    //     0x717288: stur            x1, [x0, #0x17]
    // 0x71728c: LeaveFrame
    //     0x71728c: mov             SP, fp
    //     0x717290: ldp             fp, lr, [SP], #0x10
    // 0x717294: ret
    //     0x717294: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xac4ad0, size: 0x40
    // 0xac4ad0: EnterFrame
    //     0xac4ad0: stp             fp, lr, [SP, #-0x10]!
    //     0xac4ad4: mov             fp, SP
    // 0xac4ad8: CheckStackOverflow
    //     0xac4ad8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xac4adc: cmp             SP, x16
    //     0xac4ae0: b.ls            #0xac4b08
    // 0xac4ae4: ldr             x0, [fp, #0x10]
    // 0xac4ae8: LoadField: r1 = r0->field_b
    //     0xac4ae8: ldur            w1, [x0, #0xb]
    // 0xac4aec: DecompressPointer r1
    //     0xac4aec: add             x1, x1, HEAP, lsl #32
    // 0xac4af0: SaveReg r1
    //     0xac4af0: str             x1, [SP, #-8]!
    // 0xac4af4: r0 = toString()
    //     0xac4af4: bl              #0xaf5ed0  ; [dart:collection] _ListBase&Object&ListMixin::toString
    // 0xac4af8: add             SP, SP, #8
    // 0xac4afc: LeaveFrame
    //     0xac4afc: mov             SP, fp
    //     0xac4b00: ldp             fp, lr, [SP], #0x10
    // 0xac4b04: ret
    //     0xac4b04: ret             
    // 0xac4b08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xac4b08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xac4b0c: b               #0xac4ae4
  }
}

// class id: 4769, size: 0x10, field offset: 0xc
//   const constructor, 
abstract class DelegatingList<X0> extends _DelegatingIterableBase<X0>
    implements List<X0> {

  List<X0> +(DelegatingList<X0>, List<X0>) {
    // ** addr: 0x4c4e68, size: 0x58
    // 0x4c4e68: EnterFrame
    //     0x4c4e68: stp             fp, lr, [SP, #-0x10]!
    //     0x4c4e6c: mov             fp, SP
    // 0x4c4e70: ldr             x0, [fp, #0x18]
    // 0x4c4e74: LoadField: r2 = r0->field_7
    //     0x4c4e74: ldur            w2, [x0, #7]
    // 0x4c4e78: DecompressPointer r2
    //     0x4c4e78: add             x2, x2, HEAP, lsl #32
    // 0x4c4e7c: ldr             x0, [fp, #0x10]
    // 0x4c4e80: r1 = Null
    //     0x4c4e80: mov             x1, NULL
    // 0x4c4e84: r8 = List<X0>
    //     0x4c4e84: add             x8, PP, #0xd, lsl #12  ; [pp+0xd758] Type: List<X0>
    //     0x4c4e88: ldr             x8, [x8, #0x758]
    // 0x4c4e8c: LoadField: r9 = r8->field_7
    //     0x4c4e8c: ldur            x9, [x8, #7]
    // 0x4c4e90: r3 = Null
    //     0x4c4e90: add             x3, PP, #0x29, lsl #12  ; [pp+0x292c8] Null
    //     0x4c4e94: ldr             x3, [x3, #0x2c8]
    // 0x4c4e98: blr             x9
    // 0x4c4e9c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x4c4e9c: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x4c4ea0: r0 = Throw()
    //     0x4c4ea0: bl              #0xd67e38  ; ThrowStub
    // 0x4c4ea4: brk             #0
  }
  List<Y0> cast<Y0>(DelegatingList<X0>) {
    // ** addr: 0x6b1658, size: 0x70
    // 0x6b1658: EnterFrame
    //     0x6b1658: stp             fp, lr, [SP, #-0x10]!
    //     0x6b165c: mov             fp, SP
    // 0x6b1660: mov             x0, x4
    // 0x6b1664: LoadField: r1 = r0->field_f
    //     0x6b1664: ldur            w1, [x0, #0xf]
    // 0x6b1668: DecompressPointer r1
    //     0x6b1668: add             x1, x1, HEAP, lsl #32
    // 0x6b166c: cbnz            w1, #0x6b1678
    // 0x6b1670: r1 = Null
    //     0x6b1670: mov             x1, NULL
    // 0x6b1674: b               #0x6b168c
    // 0x6b1678: LoadField: r1 = r0->field_17
    //     0x6b1678: ldur            w1, [x0, #0x17]
    // 0x6b167c: DecompressPointer r1
    //     0x6b167c: add             x1, x1, HEAP, lsl #32
    // 0x6b1680: add             x0, fp, w1, sxtw #2
    // 0x6b1684: ldr             x0, [x0, #0x10]
    // 0x6b1688: mov             x1, x0
    // 0x6b168c: ldr             x0, [fp, #0x10]
    // 0x6b1690: CheckStackOverflow
    //     0x6b1690: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b1694: cmp             SP, x16
    //     0x6b1698: b.ls            #0x6b16c0
    // 0x6b169c: LoadField: r2 = r0->field_b
    //     0x6b169c: ldur            w2, [x0, #0xb]
    // 0x6b16a0: DecompressPointer r2
    //     0x6b16a0: add             x2, x2, HEAP, lsl #32
    // 0x6b16a4: stp             x2, x1, [SP, #-0x10]!
    // 0x6b16a8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6b16a8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6b16ac: r0 = cast()
    //     0x6b16ac: bl              #0x6fad9c  ; [dart:collection] ListMixin::cast
    // 0x6b16b0: add             SP, SP, #0x10
    // 0x6b16b4: LeaveFrame
    //     0x6b16b4: mov             SP, fp
    //     0x6b16b8: ldp             fp, lr, [SP], #0x10
    // 0x6b16bc: ret
    //     0x6b16bc: ret             
    // 0x6b16c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b16c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b16c4: b               #0x6b169c
  }
  _ asMap(/* No info */) {
    // ** addr: 0x4c4b68, size: 0x40
    // 0x4c4b68: EnterFrame
    //     0x4c4b68: stp             fp, lr, [SP, #-0x10]!
    //     0x4c4b6c: mov             fp, SP
    // 0x4c4b70: CheckStackOverflow
    //     0x4c4b70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c4b74: cmp             SP, x16
    //     0x4c4b78: b.ls            #0x4c4ba0
    // 0x4c4b7c: ldr             x0, [fp, #0x10]
    // 0x4c4b80: LoadField: r1 = r0->field_b
    //     0x4c4b80: ldur            w1, [x0, #0xb]
    // 0x4c4b84: DecompressPointer r1
    //     0x4c4b84: add             x1, x1, HEAP, lsl #32
    // 0x4c4b88: SaveReg r1
    //     0x4c4b88: str             x1, [SP, #-8]!
    // 0x4c4b8c: r0 = asMap()
    //     0x4c4b8c: bl              #0x5eb608  ; [dart:collection] _ListBase&Object&ListMixin::asMap
    // 0x4c4b90: add             SP, SP, #8
    // 0x4c4b94: LeaveFrame
    //     0x4c4b94: mov             SP, fp
    //     0x4c4b98: ldp             fp, lr, [SP], #0x10
    // 0x4c4b9c: ret
    //     0x4c4b9c: ret             
    // 0x4c4ba0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c4ba0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c4ba4: b               #0x4c4b7c
  }
  X0 [](DelegatingList<X0>, int) {
    // ** addr: 0x4c4bc0, size: 0xac
    // 0x4c4bc0: EnterFrame
    //     0x4c4bc0: stp             fp, lr, [SP, #-0x10]!
    //     0x4c4bc4: mov             fp, SP
    // 0x4c4bc8: ldr             x0, [fp, #0x10]
    // 0x4c4bcc: r2 = Null
    //     0x4c4bcc: mov             x2, NULL
    // 0x4c4bd0: r1 = Null
    //     0x4c4bd0: mov             x1, NULL
    // 0x4c4bd4: branchIfSmi(r0, 0x4c4bfc)
    //     0x4c4bd4: tbz             w0, #0, #0x4c4bfc
    // 0x4c4bd8: r4 = LoadClassIdInstr(r0)
    //     0x4c4bd8: ldur            x4, [x0, #-1]
    //     0x4c4bdc: ubfx            x4, x4, #0xc, #0x14
    // 0x4c4be0: sub             x4, x4, #0x3b
    // 0x4c4be4: cmp             x4, #1
    // 0x4c4be8: b.ls            #0x4c4bfc
    // 0x4c4bec: r8 = int
    //     0x4c4bec: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0x4c4bf0: r3 = Null
    //     0x4c4bf0: add             x3, PP, #0xb, lsl #12  ; [pp+0xb5b0] Null
    //     0x4c4bf4: ldr             x3, [x3, #0x5b0]
    // 0x4c4bf8: r0 = int()
    //     0x4c4bf8: bl              #0xd73714  ; IsType_int_Stub
    // 0x4c4bfc: ldr             x2, [fp, #0x18]
    // 0x4c4c00: LoadField: r3 = r2->field_b
    //     0x4c4c00: ldur            w3, [x2, #0xb]
    // 0x4c4c04: DecompressPointer r3
    //     0x4c4c04: add             x3, x3, HEAP, lsl #32
    // 0x4c4c08: LoadField: r2 = r3->field_b
    //     0x4c4c08: ldur            w2, [x3, #0xb]
    // 0x4c4c0c: DecompressPointer r2
    //     0x4c4c0c: add             x2, x2, HEAP, lsl #32
    // 0x4c4c10: ldr             x4, [fp, #0x10]
    // 0x4c4c14: r5 = LoadInt32Instr(r4)
    //     0x4c4c14: sbfx            x5, x4, #1, #0x1f
    //     0x4c4c18: tbz             w4, #0, #0x4c4c20
    //     0x4c4c1c: ldur            x5, [x4, #7]
    // 0x4c4c20: r0 = LoadInt32Instr(r2)
    //     0x4c4c20: sbfx            x0, x2, #1, #0x1f
    // 0x4c4c24: mov             x1, x5
    // 0x4c4c28: cmp             x1, x0
    // 0x4c4c2c: b.hs            #0x4c4c50
    // 0x4c4c30: LoadField: r1 = r3->field_f
    //     0x4c4c30: ldur            w1, [x3, #0xf]
    // 0x4c4c34: DecompressPointer r1
    //     0x4c4c34: add             x1, x1, HEAP, lsl #32
    // 0x4c4c38: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0x4c4c38: add             x16, x1, x5, lsl #2
    //     0x4c4c3c: ldur            w0, [x16, #0xf]
    // 0x4c4c40: DecompressPointer r0
    //     0x4c4c40: add             x0, x0, HEAP, lsl #32
    // 0x4c4c44: LeaveFrame
    //     0x4c4c44: mov             SP, fp
    //     0x4c4c48: ldp             fp, lr, [SP], #0x10
    // 0x4c4c4c: ret
    //     0x4c4c4c: ret             
    // 0x4c4c50: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4c4c50: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ indexOf(/* No info */) {
    // ** addr: 0x4c73dc, size: 0xac
    // 0x4c73dc: EnterFrame
    //     0x4c73dc: stp             fp, lr, [SP, #-0x10]!
    //     0x4c73e0: mov             fp, SP
    // 0x4c73e4: AllocStack(0x10)
    //     0x4c73e4: sub             SP, SP, #0x10
    // 0x4c73e8: SetupParameters(DelegatingList<X0> this /* r3, fp-0x10 */, dynamic _ /* r4, fp-0x8 */)
    //     0x4c73e8: mov             x0, x4
    //     0x4c73ec: ldur            w1, [x0, #0x13]
    //     0x4c73f0: add             x1, x1, HEAP, lsl #32
    //     0x4c73f4: sub             x0, x1, #4
    //     0x4c73f8: add             x3, fp, w0, sxtw #2
    //     0x4c73fc: ldr             x3, [x3, #0x18]
    //     0x4c7400: stur            x3, [fp, #-0x10]
    //     0x4c7404: add             x4, fp, w0, sxtw #2
    //     0x4c7408: ldr             x4, [x4, #0x10]
    //     0x4c740c: stur            x4, [fp, #-8]
    // 0x4c7410: CheckStackOverflow
    //     0x4c7410: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c7414: cmp             SP, x16
    //     0x4c7418: b.ls            #0x4c7480
    // 0x4c741c: LoadField: r2 = r3->field_7
    //     0x4c741c: ldur            w2, [x3, #7]
    // 0x4c7420: DecompressPointer r2
    //     0x4c7420: add             x2, x2, HEAP, lsl #32
    // 0x4c7424: mov             x0, x4
    // 0x4c7428: r1 = Null
    //     0x4c7428: mov             x1, NULL
    // 0x4c742c: cmp             w2, NULL
    // 0x4c7430: b.eq            #0x4c7450
    // 0x4c7434: LoadField: r4 = r2->field_17
    //     0x4c7434: ldur            w4, [x2, #0x17]
    // 0x4c7438: DecompressPointer r4
    //     0x4c7438: add             x4, x4, HEAP, lsl #32
    // 0x4c743c: r8 = X0
    //     0x4c743c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x4c7440: LoadField: r9 = r4->field_7
    //     0x4c7440: ldur            x9, [x4, #7]
    // 0x4c7444: r3 = Null
    //     0x4c7444: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c9f8] Null
    //     0x4c7448: ldr             x3, [x3, #0x9f8]
    // 0x4c744c: blr             x9
    // 0x4c7450: ldur            x0, [fp, #-0x10]
    // 0x4c7454: LoadField: r1 = r0->field_b
    //     0x4c7454: ldur            w1, [x0, #0xb]
    // 0x4c7458: DecompressPointer r1
    //     0x4c7458: add             x1, x1, HEAP, lsl #32
    // 0x4c745c: ldur            x16, [fp, #-8]
    // 0x4c7460: stp             x16, x1, [SP, #-0x10]!
    // 0x4c7464: SaveReg rZR
    //     0x4c7464: str             xzr, [SP, #-8]!
    // 0x4c7468: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x4c7468: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x4c746c: r0 = indexOf()
    //     0x4c746c: bl              #0x5ed104  ; [dart:collection] _ListBase&Object&ListMixin::indexOf
    // 0x4c7470: add             SP, SP, #0x18
    // 0x4c7474: LeaveFrame
    //     0x4c7474: mov             SP, fp
    //     0x4c7478: ldp             fp, lr, [SP], #0x10
    // 0x4c747c: ret
    //     0x4c747c: ret             
    // 0x4c7480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c7480: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c7484: b               #0x4c741c
  }
  _ retainWhere(/* No info */) {
    // ** addr: 0x4c78b8, size: 0x48
    // 0x4c78b8: EnterFrame
    //     0x4c78b8: stp             fp, lr, [SP, #-0x10]!
    //     0x4c78bc: mov             fp, SP
    // 0x4c78c0: CheckStackOverflow
    //     0x4c78c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c78c4: cmp             SP, x16
    //     0x4c78c8: b.ls            #0x4c78f8
    // 0x4c78cc: ldr             x0, [fp, #0x18]
    // 0x4c78d0: LoadField: r1 = r0->field_b
    //     0x4c78d0: ldur            w1, [x0, #0xb]
    // 0x4c78d4: DecompressPointer r1
    //     0x4c78d4: add             x1, x1, HEAP, lsl #32
    // 0x4c78d8: ldr             x16, [fp, #0x10]
    // 0x4c78dc: stp             x16, x1, [SP, #-0x10]!
    // 0x4c78e0: r0 = retainWhere()
    //     0x4c78e0: bl              #0x5ed240  ; [dart:collection] _ListBase&Object&ListMixin::retainWhere
    // 0x4c78e4: add             SP, SP, #0x10
    // 0x4c78e8: r0 = Null
    //     0x4c78e8: mov             x0, NULL
    // 0x4c78ec: LeaveFrame
    //     0x4c78ec: mov             SP, fp
    //     0x4c78f0: ldp             fp, lr, [SP], #0x10
    // 0x4c78f4: ret
    //     0x4c78f4: ret             
    // 0x4c78f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c78f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c78fc: b               #0x4c78cc
  }
  _ sort(/* No info */) {
    // ** addr: 0x4ca7c8, size: 0x78
    // 0x4ca7c8: EnterFrame
    //     0x4ca7c8: stp             fp, lr, [SP, #-0x10]!
    //     0x4ca7cc: mov             fp, SP
    // 0x4ca7d0: mov             x0, x4
    // 0x4ca7d4: LoadField: r1 = r0->field_13
    //     0x4ca7d4: ldur            w1, [x0, #0x13]
    // 0x4ca7d8: DecompressPointer r1
    //     0x4ca7d8: add             x1, x1, HEAP, lsl #32
    // 0x4ca7dc: sub             x0, x1, #2
    // 0x4ca7e0: add             x1, fp, w0, sxtw #2
    // 0x4ca7e4: ldr             x1, [x1, #0x10]
    // 0x4ca7e8: cmp             w0, #2
    // 0x4ca7ec: b.lt            #0x4ca800
    // 0x4ca7f0: add             x2, fp, w0, sxtw #2
    // 0x4ca7f4: ldr             x2, [x2, #8]
    // 0x4ca7f8: mov             x0, x2
    // 0x4ca7fc: b               #0x4ca804
    // 0x4ca800: r0 = Null
    //     0x4ca800: mov             x0, NULL
    // 0x4ca804: CheckStackOverflow
    //     0x4ca804: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ca808: cmp             SP, x16
    //     0x4ca80c: b.ls            #0x4ca838
    // 0x4ca810: LoadField: r2 = r1->field_b
    //     0x4ca810: ldur            w2, [x1, #0xb]
    // 0x4ca814: DecompressPointer r2
    //     0x4ca814: add             x2, x2, HEAP, lsl #32
    // 0x4ca818: stp             x0, x2, [SP, #-0x10]!
    // 0x4ca81c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4ca81c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4ca820: r0 = sort()
    //     0x4ca820: bl              #0x5edd6c  ; [dart:collection] _ListBase&Object&ListMixin::sort
    // 0x4ca824: add             SP, SP, #0x10
    // 0x4ca828: r0 = Null
    //     0x4ca828: mov             x0, NULL
    // 0x4ca82c: LeaveFrame
    //     0x4ca82c: mov             SP, fp
    //     0x4ca830: ldp             fp, lr, [SP], #0x10
    // 0x4ca834: ret
    //     0x4ca834: ret             
    // 0x4ca838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ca838: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ca83c: b               #0x4ca810
  }
  get _ reversed(/* No info */) {
    // ** addr: 0x4f8814, size: 0x3c
    // 0x4f8814: EnterFrame
    //     0x4f8814: stp             fp, lr, [SP, #-0x10]!
    //     0x4f8818: mov             fp, SP
    // 0x4f881c: AllocStack(0x8)
    //     0x4f881c: sub             SP, SP, #8
    // 0x4f8820: ldr             x0, [fp, #0x10]
    // 0x4f8824: LoadField: r2 = r0->field_b
    //     0x4f8824: ldur            w2, [x0, #0xb]
    // 0x4f8828: DecompressPointer r2
    //     0x4f8828: add             x2, x2, HEAP, lsl #32
    // 0x4f882c: stur            x2, [fp, #-8]
    // 0x4f8830: LoadField: r1 = r2->field_7
    //     0x4f8830: ldur            w1, [x2, #7]
    // 0x4f8834: DecompressPointer r1
    //     0x4f8834: add             x1, x1, HEAP, lsl #32
    // 0x4f8838: r0 = ReversedListIterable()
    //     0x4f8838: bl              #0x4c1784  ; AllocateReversedListIterableStub -> ReversedListIterable<X0> (size=0x10)
    // 0x4f883c: ldur            x1, [fp, #-8]
    // 0x4f8840: StoreField: r0->field_b = r1
    //     0x4f8840: stur            w1, [x0, #0xb]
    // 0x4f8844: LeaveFrame
    //     0x4f8844: mov             SP, fp
    //     0x4f8848: ldp             fp, lr, [SP], #0x10
    // 0x4f884c: ret
    //     0x4f884c: ret             
  }
  _ indexWhere(/* No info */) {
    // ** addr: 0x4f95ac, size: 0x64
    // 0x4f95ac: EnterFrame
    //     0x4f95ac: stp             fp, lr, [SP, #-0x10]!
    //     0x4f95b0: mov             fp, SP
    // 0x4f95b4: mov             x0, x4
    // 0x4f95b8: LoadField: r1 = r0->field_13
    //     0x4f95b8: ldur            w1, [x0, #0x13]
    // 0x4f95bc: DecompressPointer r1
    //     0x4f95bc: add             x1, x1, HEAP, lsl #32
    // 0x4f95c0: sub             x0, x1, #4
    // 0x4f95c4: add             x1, fp, w0, sxtw #2
    // 0x4f95c8: ldr             x1, [x1, #0x18]
    // 0x4f95cc: add             x2, fp, w0, sxtw #2
    // 0x4f95d0: ldr             x2, [x2, #0x10]
    // 0x4f95d4: CheckStackOverflow
    //     0x4f95d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4f95d8: cmp             SP, x16
    //     0x4f95dc: b.ls            #0x4f9608
    // 0x4f95e0: LoadField: r0 = r1->field_b
    //     0x4f95e0: ldur            w0, [x1, #0xb]
    // 0x4f95e4: DecompressPointer r0
    //     0x4f95e4: add             x0, x0, HEAP, lsl #32
    // 0x4f95e8: stp             x2, x0, [SP, #-0x10]!
    // 0x4f95ec: SaveReg rZR
    //     0x4f95ec: str             xzr, [SP, #-8]!
    // 0x4f95f0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x4f95f0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x4f95f4: r0 = indexWhere()
    //     0x4f95f4: bl              #0x5ee3a4  ; [dart:collection] _ListBase&Object&ListMixin::indexWhere
    // 0x4f95f8: add             SP, SP, #0x18
    // 0x4f95fc: LeaveFrame
    //     0x4f95fc: mov             SP, fp
    //     0x4f9600: ldp             fp, lr, [SP], #0x10
    // 0x4f9604: ret
    //     0x4f9604: ret             
    // 0x4f9608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f9608: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f960c: b               #0x4f95e0
  }
  _ insertAll(/* No info */) {
    // ** addr: 0x4faa70, size: 0x4c
    // 0x4faa70: EnterFrame
    //     0x4faa70: stp             fp, lr, [SP, #-0x10]!
    //     0x4faa74: mov             fp, SP
    // 0x4faa78: CheckStackOverflow
    //     0x4faa78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4faa7c: cmp             SP, x16
    //     0x4faa80: b.ls            #0x4faab4
    // 0x4faa84: ldr             x0, [fp, #0x20]
    // 0x4faa88: LoadField: r1 = r0->field_b
    //     0x4faa88: ldur            w1, [x0, #0xb]
    // 0x4faa8c: DecompressPointer r1
    //     0x4faa8c: add             x1, x1, HEAP, lsl #32
    // 0x4faa90: stp             xzr, x1, [SP, #-0x10]!
    // 0x4faa94: ldr             x16, [fp, #0x10]
    // 0x4faa98: SaveReg r16
    //     0x4faa98: str             x16, [SP, #-8]!
    // 0x4faa9c: r0 = insertAll()
    //     0x4faa9c: bl              #0x5ef59c  ; [dart:core] _GrowableList::insertAll
    // 0x4faaa0: add             SP, SP, #0x18
    // 0x4faaa4: r0 = Null
    //     0x4faaa4: mov             x0, NULL
    // 0x4faaa8: LeaveFrame
    //     0x4faaa8: mov             SP, fp
    //     0x4faaac: ldp             fp, lr, [SP], #0x10
    // 0x4faab0: ret
    //     0x4faab0: ret             
    // 0x4faab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4faab4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4faab8: b               #0x4faa84
  }
  _ removeLast(/* No info */) {
    // ** addr: 0x502f04, size: 0x84
    // 0x502f04: EnterFrame
    //     0x502f04: stp             fp, lr, [SP, #-0x10]!
    //     0x502f08: mov             fp, SP
    // 0x502f0c: AllocStack(0x8)
    //     0x502f0c: sub             SP, SP, #8
    // 0x502f10: CheckStackOverflow
    //     0x502f10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x502f14: cmp             SP, x16
    //     0x502f18: b.ls            #0x502f7c
    // 0x502f1c: ldr             x0, [fp, #0x10]
    // 0x502f20: LoadField: r2 = r0->field_b
    //     0x502f20: ldur            w2, [x0, #0xb]
    // 0x502f24: DecompressPointer r2
    //     0x502f24: add             x2, x2, HEAP, lsl #32
    // 0x502f28: LoadField: r0 = r2->field_b
    //     0x502f28: ldur            w0, [x2, #0xb]
    // 0x502f2c: DecompressPointer r0
    //     0x502f2c: add             x0, x0, HEAP, lsl #32
    // 0x502f30: r1 = LoadInt32Instr(r0)
    //     0x502f30: sbfx            x1, x0, #1, #0x1f
    // 0x502f34: sub             x3, x1, #1
    // 0x502f38: mov             x0, x1
    // 0x502f3c: mov             x1, x3
    // 0x502f40: cmp             x1, x0
    // 0x502f44: b.hs            #0x502f84
    // 0x502f48: LoadField: r0 = r2->field_f
    //     0x502f48: ldur            w0, [x2, #0xf]
    // 0x502f4c: DecompressPointer r0
    //     0x502f4c: add             x0, x0, HEAP, lsl #32
    // 0x502f50: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x502f50: add             x16, x0, x3, lsl #2
    //     0x502f54: ldur            w1, [x16, #0xf]
    // 0x502f58: DecompressPointer r1
    //     0x502f58: add             x1, x1, HEAP, lsl #32
    // 0x502f5c: stur            x1, [fp, #-8]
    // 0x502f60: stp             x3, x2, [SP, #-0x10]!
    // 0x502f64: r0 = length=()
    //     0x502f64: bl              #0x5efc5c  ; [dart:core] _GrowableList::length=
    // 0x502f68: add             SP, SP, #0x10
    // 0x502f6c: ldur            x0, [fp, #-8]
    // 0x502f70: LeaveFrame
    //     0x502f70: mov             SP, fp
    //     0x502f74: ldp             fp, lr, [SP], #0x10
    // 0x502f78: ret
    //     0x502f78: ret             
    // 0x502f7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x502f7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x502f80: b               #0x502f1c
    // 0x502f84: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x502f84: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ insert(/* No info */) {
    // ** addr: 0x503f58, size: 0x4c
    // 0x503f58: EnterFrame
    //     0x503f58: stp             fp, lr, [SP, #-0x10]!
    //     0x503f5c: mov             fp, SP
    // 0x503f60: CheckStackOverflow
    //     0x503f60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x503f64: cmp             SP, x16
    //     0x503f68: b.ls            #0x503f9c
    // 0x503f6c: ldr             x0, [fp, #0x20]
    // 0x503f70: LoadField: r1 = r0->field_b
    //     0x503f70: ldur            w1, [x0, #0xb]
    // 0x503f74: DecompressPointer r1
    //     0x503f74: add             x1, x1, HEAP, lsl #32
    // 0x503f78: stp             xzr, x1, [SP, #-0x10]!
    // 0x503f7c: ldr             x16, [fp, #0x10]
    // 0x503f80: SaveReg r16
    //     0x503f80: str             x16, [SP, #-8]!
    // 0x503f84: r0 = insert()
    //     0x503f84: bl              #0x5f0388  ; [dart:core] _GrowableList::insert
    // 0x503f88: add             SP, SP, #0x18
    // 0x503f8c: r0 = Null
    //     0x503f8c: mov             x0, NULL
    // 0x503f90: LeaveFrame
    //     0x503f90: mov             SP, fp
    //     0x503f94: ldp             fp, lr, [SP], #0x10
    // 0x503f98: ret
    //     0x503f98: ret             
    // 0x503f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x503f9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x503fa0: b               #0x503f6c
  }
  _ setRange(/* No info */) {
    // ** addr: 0x505440, size: 0xb8
    // 0x505440: EnterFrame
    //     0x505440: stp             fp, lr, [SP, #-0x10]!
    //     0x505444: mov             fp, SP
    // 0x505448: mov             x0, x4
    // 0x50544c: LoadField: r1 = r0->field_13
    //     0x50544c: ldur            w1, [x0, #0x13]
    // 0x505450: DecompressPointer r1
    //     0x505450: add             x1, x1, HEAP, lsl #32
    // 0x505454: sub             x0, x1, #8
    // 0x505458: add             x1, fp, w0, sxtw #2
    // 0x50545c: ldr             x1, [x1, #0x28]
    // 0x505460: add             x2, fp, w0, sxtw #2
    // 0x505464: ldr             x2, [x2, #0x20]
    // 0x505468: add             x3, fp, w0, sxtw #2
    // 0x50546c: ldr             x3, [x3, #0x18]
    // 0x505470: add             x4, fp, w0, sxtw #2
    // 0x505474: ldr             x4, [x4, #0x10]
    // 0x505478: cmp             w0, #2
    // 0x50547c: b.lt            #0x50549c
    // 0x505480: add             x5, fp, w0, sxtw #2
    // 0x505484: ldr             x5, [x5, #8]
    // 0x505488: r0 = LoadInt32Instr(r5)
    //     0x505488: sbfx            x0, x5, #1, #0x1f
    //     0x50548c: tbz             w5, #0, #0x505494
    //     0x505490: ldur            x0, [x5, #7]
    // 0x505494: mov             x5, x0
    // 0x505498: b               #0x5054a0
    // 0x50549c: r5 = 0
    //     0x50549c: mov             x5, #0
    // 0x5054a0: CheckStackOverflow
    //     0x5054a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5054a4: cmp             SP, x16
    //     0x5054a8: b.ls            #0x5054f0
    // 0x5054ac: LoadField: r6 = r1->field_b
    //     0x5054ac: ldur            w6, [x1, #0xb]
    // 0x5054b0: DecompressPointer r6
    //     0x5054b0: add             x6, x6, HEAP, lsl #32
    // 0x5054b4: r0 = BoxInt64Instr(r5)
    //     0x5054b4: sbfiz           x0, x5, #1, #0x1f
    //     0x5054b8: cmp             x5, x0, asr #1
    //     0x5054bc: b.eq            #0x5054c8
    //     0x5054c0: bl              #0xd69bb8
    //     0x5054c4: stur            x5, [x0, #7]
    // 0x5054c8: stp             x2, x6, [SP, #-0x10]!
    // 0x5054cc: stp             x4, x3, [SP, #-0x10]!
    // 0x5054d0: SaveReg r0
    //     0x5054d0: str             x0, [SP, #-8]!
    // 0x5054d4: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x5054d4: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x5054d8: r0 = setRange()
    //     0x5054d8: bl              #0x608030  ; [dart:collection] _ListBase&Object&ListMixin::setRange
    // 0x5054dc: add             SP, SP, #0x28
    // 0x5054e0: r0 = Null
    //     0x5054e0: mov             x0, NULL
    // 0x5054e4: LeaveFrame
    //     0x5054e4: mov             SP, fp
    //     0x5054e8: ldp             fp, lr, [SP], #0x10
    // 0x5054ec: ret
    //     0x5054ec: ret             
    // 0x5054f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5054f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5054f4: b               #0x5054ac
  }
  _ addAll(/* No info */) {
    // ** addr: 0x507904, size: 0x48
    // 0x507904: EnterFrame
    //     0x507904: stp             fp, lr, [SP, #-0x10]!
    //     0x507908: mov             fp, SP
    // 0x50790c: CheckStackOverflow
    //     0x50790c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x507910: cmp             SP, x16
    //     0x507914: b.ls            #0x507944
    // 0x507918: ldr             x0, [fp, #0x18]
    // 0x50791c: LoadField: r1 = r0->field_b
    //     0x50791c: ldur            w1, [x0, #0xb]
    // 0x507920: DecompressPointer r1
    //     0x507920: add             x1, x1, HEAP, lsl #32
    // 0x507924: ldr             x16, [fp, #0x10]
    // 0x507928: stp             x16, x1, [SP, #-0x10]!
    // 0x50792c: r0 = addAll()
    //     0x50792c: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x507930: add             SP, SP, #0x10
    // 0x507934: r0 = Null
    //     0x507934: mov             x0, NULL
    // 0x507938: LeaveFrame
    //     0x507938: mov             SP, fp
    //     0x50793c: ldp             fp, lr, [SP], #0x10
    // 0x507940: ret
    //     0x507940: ret             
    // 0x507944: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x507944: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x507948: b               #0x507918
  }
  _ sublist(/* No info */) {
    // ** addr: 0x508c48, size: 0x80
    // 0x508c48: EnterFrame
    //     0x508c48: stp             fp, lr, [SP, #-0x10]!
    //     0x508c4c: mov             fp, SP
    // 0x508c50: mov             x0, x4
    // 0x508c54: LoadField: r1 = r0->field_13
    //     0x508c54: ldur            w1, [x0, #0x13]
    // 0x508c58: DecompressPointer r1
    //     0x508c58: add             x1, x1, HEAP, lsl #32
    // 0x508c5c: sub             x0, x1, #4
    // 0x508c60: add             x1, fp, w0, sxtw #2
    // 0x508c64: ldr             x1, [x1, #0x18]
    // 0x508c68: add             x2, fp, w0, sxtw #2
    // 0x508c6c: ldr             x2, [x2, #0x10]
    // 0x508c70: cmp             w0, #2
    // 0x508c74: b.lt            #0x508c88
    // 0x508c78: add             x3, fp, w0, sxtw #2
    // 0x508c7c: ldr             x3, [x3, #8]
    // 0x508c80: mov             x0, x3
    // 0x508c84: b               #0x508c8c
    // 0x508c88: r0 = Null
    //     0x508c88: mov             x0, NULL
    // 0x508c8c: CheckStackOverflow
    //     0x508c8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x508c90: cmp             SP, x16
    //     0x508c94: b.ls            #0x508cc0
    // 0x508c98: LoadField: r3 = r1->field_b
    //     0x508c98: ldur            w3, [x1, #0xb]
    // 0x508c9c: DecompressPointer r3
    //     0x508c9c: add             x3, x3, HEAP, lsl #32
    // 0x508ca0: stp             x2, x3, [SP, #-0x10]!
    // 0x508ca4: SaveReg r0
    //     0x508ca4: str             x0, [SP, #-8]!
    // 0x508ca8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x508ca8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x508cac: r0 = sublist()
    //     0x508cac: bl              #0x60b5d8  ; [dart:core] _GrowableList::sublist
    // 0x508cb0: add             SP, SP, #0x18
    // 0x508cb4: LeaveFrame
    //     0x508cb4: mov             SP, fp
    //     0x508cb8: ldp             fp, lr, [SP], #0x10
    // 0x508cbc: ret
    //     0x508cbc: ret             
    // 0x508cc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x508cc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x508cc4: b               #0x508c98
  }
  _ add(/* No info */) {
    // ** addr: 0x515ca4, size: 0x104
    // 0x515ca4: EnterFrame
    //     0x515ca4: stp             fp, lr, [SP, #-0x10]!
    //     0x515ca8: mov             fp, SP
    // 0x515cac: AllocStack(0x10)
    //     0x515cac: sub             SP, SP, #0x10
    // 0x515cb0: CheckStackOverflow
    //     0x515cb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x515cb4: cmp             SP, x16
    //     0x515cb8: b.ls            #0x515d9c
    // 0x515cbc: ldr             x0, [fp, #0x18]
    // 0x515cc0: LoadField: r3 = r0->field_b
    //     0x515cc0: ldur            w3, [x0, #0xb]
    // 0x515cc4: DecompressPointer r3
    //     0x515cc4: add             x3, x3, HEAP, lsl #32
    // 0x515cc8: stur            x3, [fp, #-8]
    // 0x515ccc: LoadField: r2 = r3->field_7
    //     0x515ccc: ldur            w2, [x3, #7]
    // 0x515cd0: DecompressPointer r2
    //     0x515cd0: add             x2, x2, HEAP, lsl #32
    // 0x515cd4: ldr             x0, [fp, #0x10]
    // 0x515cd8: r1 = Null
    //     0x515cd8: mov             x1, NULL
    // 0x515cdc: cmp             w2, NULL
    // 0x515ce0: b.eq            #0x515d00
    // 0x515ce4: LoadField: r4 = r2->field_17
    //     0x515ce4: ldur            w4, [x2, #0x17]
    // 0x515ce8: DecompressPointer r4
    //     0x515ce8: add             x4, x4, HEAP, lsl #32
    // 0x515cec: r8 = X0
    //     0x515cec: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x515cf0: LoadField: r9 = r4->field_7
    //     0x515cf0: ldur            x9, [x4, #7]
    // 0x515cf4: r3 = Null
    //     0x515cf4: add             x3, PP, #0xb, lsl #12  ; [pp+0xb590] Null
    //     0x515cf8: ldr             x3, [x3, #0x590]
    // 0x515cfc: blr             x9
    // 0x515d00: ldur            x0, [fp, #-8]
    // 0x515d04: LoadField: r1 = r0->field_b
    //     0x515d04: ldur            w1, [x0, #0xb]
    // 0x515d08: DecompressPointer r1
    //     0x515d08: add             x1, x1, HEAP, lsl #32
    // 0x515d0c: stur            x1, [fp, #-0x10]
    // 0x515d10: LoadField: r2 = r0->field_f
    //     0x515d10: ldur            w2, [x0, #0xf]
    // 0x515d14: DecompressPointer r2
    //     0x515d14: add             x2, x2, HEAP, lsl #32
    // 0x515d18: LoadField: r3 = r2->field_b
    //     0x515d18: ldur            w3, [x2, #0xb]
    // 0x515d1c: DecompressPointer r3
    //     0x515d1c: add             x3, x3, HEAP, lsl #32
    // 0x515d20: cmp             w1, w3
    // 0x515d24: b.ne            #0x515d34
    // 0x515d28: SaveReg r0
    //     0x515d28: str             x0, [SP, #-8]!
    // 0x515d2c: r0 = _growToNextCapacity()
    //     0x515d2c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x515d30: add             SP, SP, #8
    // 0x515d34: ldur            x2, [fp, #-8]
    // 0x515d38: ldur            x3, [fp, #-0x10]
    // 0x515d3c: r4 = LoadInt32Instr(r3)
    //     0x515d3c: sbfx            x4, x3, #1, #0x1f
    // 0x515d40: add             x0, x4, #1
    // 0x515d44: lsl             x3, x0, #1
    // 0x515d48: StoreField: r2->field_b = r3
    //     0x515d48: stur            w3, [x2, #0xb]
    // 0x515d4c: mov             x1, x4
    // 0x515d50: cmp             x1, x0
    // 0x515d54: b.hs            #0x515da4
    // 0x515d58: LoadField: r1 = r2->field_f
    //     0x515d58: ldur            w1, [x2, #0xf]
    // 0x515d5c: DecompressPointer r1
    //     0x515d5c: add             x1, x1, HEAP, lsl #32
    // 0x515d60: ldr             x0, [fp, #0x10]
    // 0x515d64: ArrayStore: r1[r4] = r0  ; List_4
    //     0x515d64: add             x25, x1, x4, lsl #2
    //     0x515d68: add             x25, x25, #0xf
    //     0x515d6c: str             w0, [x25]
    //     0x515d70: tbz             w0, #0, #0x515d8c
    //     0x515d74: ldurb           w16, [x1, #-1]
    //     0x515d78: ldurb           w17, [x0, #-1]
    //     0x515d7c: and             x16, x17, x16, lsr #2
    //     0x515d80: tst             x16, HEAP, lsr #32
    //     0x515d84: b.eq            #0x515d8c
    //     0x515d88: bl              #0xd67e5c
    // 0x515d8c: r0 = Null
    //     0x515d8c: mov             x0, NULL
    // 0x515d90: LeaveFrame
    //     0x515d90: mov             SP, fp
    //     0x515d94: ldp             fp, lr, [SP], #0x10
    // 0x515d98: ret
    //     0x515d98: ret             
    // 0x515d9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x515d9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x515da0: b               #0x515cbc
    // 0x515da4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x515da4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0x515da8, size: 0x114
    // 0x515da8: EnterFrame
    //     0x515da8: stp             fp, lr, [SP, #-0x10]!
    //     0x515dac: mov             fp, SP
    // 0x515db0: AllocStack(0x10)
    //     0x515db0: sub             SP, SP, #0x10
    // 0x515db4: SetupParameters()
    //     0x515db4: ldr             x0, [fp, #0x18]
    //     0x515db8: ldur            w1, [x0, #0x17]
    //     0x515dbc: add             x1, x1, HEAP, lsl #32
    // 0x515dc0: CheckStackOverflow
    //     0x515dc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x515dc4: cmp             SP, x16
    //     0x515dc8: b.ls            #0x515eb0
    // 0x515dcc: LoadField: r0 = r1->field_f
    //     0x515dcc: ldur            w0, [x1, #0xf]
    // 0x515dd0: DecompressPointer r0
    //     0x515dd0: add             x0, x0, HEAP, lsl #32
    // 0x515dd4: LoadField: r3 = r0->field_b
    //     0x515dd4: ldur            w3, [x0, #0xb]
    // 0x515dd8: DecompressPointer r3
    //     0x515dd8: add             x3, x3, HEAP, lsl #32
    // 0x515ddc: stur            x3, [fp, #-8]
    // 0x515de0: LoadField: r2 = r3->field_7
    //     0x515de0: ldur            w2, [x3, #7]
    // 0x515de4: DecompressPointer r2
    //     0x515de4: add             x2, x2, HEAP, lsl #32
    // 0x515de8: ldr             x0, [fp, #0x10]
    // 0x515dec: r1 = Null
    //     0x515dec: mov             x1, NULL
    // 0x515df0: cmp             w2, NULL
    // 0x515df4: b.eq            #0x515e14
    // 0x515df8: LoadField: r4 = r2->field_17
    //     0x515df8: ldur            w4, [x2, #0x17]
    // 0x515dfc: DecompressPointer r4
    //     0x515dfc: add             x4, x4, HEAP, lsl #32
    // 0x515e00: r8 = X0
    //     0x515e00: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x515e04: LoadField: r9 = r4->field_7
    //     0x515e04: ldur            x9, [x4, #7]
    // 0x515e08: r3 = Null
    //     0x515e08: add             x3, PP, #0x38, lsl #12  ; [pp+0x38650] Null
    //     0x515e0c: ldr             x3, [x3, #0x650]
    // 0x515e10: blr             x9
    // 0x515e14: ldur            x0, [fp, #-8]
    // 0x515e18: LoadField: r1 = r0->field_b
    //     0x515e18: ldur            w1, [x0, #0xb]
    // 0x515e1c: DecompressPointer r1
    //     0x515e1c: add             x1, x1, HEAP, lsl #32
    // 0x515e20: stur            x1, [fp, #-0x10]
    // 0x515e24: LoadField: r2 = r0->field_f
    //     0x515e24: ldur            w2, [x0, #0xf]
    // 0x515e28: DecompressPointer r2
    //     0x515e28: add             x2, x2, HEAP, lsl #32
    // 0x515e2c: LoadField: r3 = r2->field_b
    //     0x515e2c: ldur            w3, [x2, #0xb]
    // 0x515e30: DecompressPointer r3
    //     0x515e30: add             x3, x3, HEAP, lsl #32
    // 0x515e34: cmp             w1, w3
    // 0x515e38: b.ne            #0x515e48
    // 0x515e3c: SaveReg r0
    //     0x515e3c: str             x0, [SP, #-8]!
    // 0x515e40: r0 = _growToNextCapacity()
    //     0x515e40: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x515e44: add             SP, SP, #8
    // 0x515e48: ldur            x2, [fp, #-8]
    // 0x515e4c: ldur            x3, [fp, #-0x10]
    // 0x515e50: r4 = LoadInt32Instr(r3)
    //     0x515e50: sbfx            x4, x3, #1, #0x1f
    // 0x515e54: add             x0, x4, #1
    // 0x515e58: lsl             x3, x0, #1
    // 0x515e5c: StoreField: r2->field_b = r3
    //     0x515e5c: stur            w3, [x2, #0xb]
    // 0x515e60: mov             x1, x4
    // 0x515e64: cmp             x1, x0
    // 0x515e68: b.hs            #0x515eb8
    // 0x515e6c: LoadField: r1 = r2->field_f
    //     0x515e6c: ldur            w1, [x2, #0xf]
    // 0x515e70: DecompressPointer r1
    //     0x515e70: add             x1, x1, HEAP, lsl #32
    // 0x515e74: ldr             x0, [fp, #0x10]
    // 0x515e78: ArrayStore: r1[r4] = r0  ; List_4
    //     0x515e78: add             x25, x1, x4, lsl #2
    //     0x515e7c: add             x25, x25, #0xf
    //     0x515e80: str             w0, [x25]
    //     0x515e84: tbz             w0, #0, #0x515ea0
    //     0x515e88: ldurb           w16, [x1, #-1]
    //     0x515e8c: ldurb           w17, [x0, #-1]
    //     0x515e90: and             x16, x17, x16, lsr #2
    //     0x515e94: tst             x16, HEAP, lsr #32
    //     0x515e98: b.eq            #0x515ea0
    //     0x515e9c: bl              #0xd67e5c
    // 0x515ea0: r0 = Null
    //     0x515ea0: mov             x0, NULL
    // 0x515ea4: LeaveFrame
    //     0x515ea4: mov             SP, fp
    //     0x515ea8: ldp             fp, lr, [SP], #0x10
    // 0x515eac: ret
    //     0x515eac: ret             
    // 0x515eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x515eb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x515eb4: b               #0x515dcc
    // 0x515eb8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x515eb8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ []=(/* No info */) {
    // ** addr: 0x516a24, size: 0xc4
    // 0x516a24: EnterFrame
    //     0x516a24: stp             fp, lr, [SP, #-0x10]!
    //     0x516a28: mov             fp, SP
    // 0x516a2c: AllocStack(0x8)
    //     0x516a2c: sub             SP, SP, #8
    // 0x516a30: ldr             x0, [fp, #0x20]
    // 0x516a34: LoadField: r3 = r0->field_b
    //     0x516a34: ldur            w3, [x0, #0xb]
    // 0x516a38: DecompressPointer r3
    //     0x516a38: add             x3, x3, HEAP, lsl #32
    // 0x516a3c: stur            x3, [fp, #-8]
    // 0x516a40: LoadField: r2 = r3->field_7
    //     0x516a40: ldur            w2, [x3, #7]
    // 0x516a44: DecompressPointer r2
    //     0x516a44: add             x2, x2, HEAP, lsl #32
    // 0x516a48: ldr             x0, [fp, #0x10]
    // 0x516a4c: r1 = Null
    //     0x516a4c: mov             x1, NULL
    // 0x516a50: cmp             w2, NULL
    // 0x516a54: b.eq            #0x516a74
    // 0x516a58: LoadField: r4 = r2->field_17
    //     0x516a58: ldur            w4, [x2, #0x17]
    // 0x516a5c: DecompressPointer r4
    //     0x516a5c: add             x4, x4, HEAP, lsl #32
    // 0x516a60: r8 = X0
    //     0x516a60: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x516a64: LoadField: r9 = r4->field_7
    //     0x516a64: ldur            x9, [x4, #7]
    // 0x516a68: r3 = Null
    //     0x516a68: add             x3, PP, #0xb, lsl #12  ; [pp+0xb5a0] Null
    //     0x516a6c: ldr             x3, [x3, #0x5a0]
    // 0x516a70: blr             x9
    // 0x516a74: ldur            x2, [fp, #-8]
    // 0x516a78: LoadField: r3 = r2->field_b
    //     0x516a78: ldur            w3, [x2, #0xb]
    // 0x516a7c: DecompressPointer r3
    //     0x516a7c: add             x3, x3, HEAP, lsl #32
    // 0x516a80: ldr             x4, [fp, #0x18]
    // 0x516a84: r5 = LoadInt32Instr(r4)
    //     0x516a84: sbfx            x5, x4, #1, #0x1f
    //     0x516a88: tbz             w4, #0, #0x516a90
    //     0x516a8c: ldur            x5, [x4, #7]
    // 0x516a90: r0 = LoadInt32Instr(r3)
    //     0x516a90: sbfx            x0, x3, #1, #0x1f
    // 0x516a94: mov             x1, x5
    // 0x516a98: cmp             x1, x0
    // 0x516a9c: b.hs            #0x516ae4
    // 0x516aa0: LoadField: r1 = r2->field_f
    //     0x516aa0: ldur            w1, [x2, #0xf]
    // 0x516aa4: DecompressPointer r1
    //     0x516aa4: add             x1, x1, HEAP, lsl #32
    // 0x516aa8: ldr             x0, [fp, #0x10]
    // 0x516aac: ArrayStore: r1[r5] = r0  ; List_4
    //     0x516aac: add             x25, x1, x5, lsl #2
    //     0x516ab0: add             x25, x25, #0xf
    //     0x516ab4: str             w0, [x25]
    //     0x516ab8: tbz             w0, #0, #0x516ad4
    //     0x516abc: ldurb           w16, [x1, #-1]
    //     0x516ac0: ldurb           w17, [x0, #-1]
    //     0x516ac4: and             x16, x17, x16, lsr #2
    //     0x516ac8: tst             x16, HEAP, lsr #32
    //     0x516acc: b.eq            #0x516ad4
    //     0x516ad0: bl              #0xd67e5c
    // 0x516ad4: r0 = Null
    //     0x516ad4: mov             x0, NULL
    // 0x516ad8: LeaveFrame
    //     0x516ad8: mov             SP, fp
    //     0x516adc: ldp             fp, lr, [SP], #0x10
    // 0x516ae0: ret
    //     0x516ae0: ret             
    // 0x516ae4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x516ae4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ replaceRange(/* No info */) {
    // ** addr: 0x516de0, size: 0x54
    // 0x516de0: EnterFrame
    //     0x516de0: stp             fp, lr, [SP, #-0x10]!
    //     0x516de4: mov             fp, SP
    // 0x516de8: CheckStackOverflow
    //     0x516de8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x516dec: cmp             SP, x16
    //     0x516df0: b.ls            #0x516e2c
    // 0x516df4: ldr             x0, [fp, #0x28]
    // 0x516df8: LoadField: r1 = r0->field_b
    //     0x516df8: ldur            w1, [x0, #0xb]
    // 0x516dfc: DecompressPointer r1
    //     0x516dfc: add             x1, x1, HEAP, lsl #32
    // 0x516e00: ldr             x16, [fp, #0x20]
    // 0x516e04: stp             x16, x1, [SP, #-0x10]!
    // 0x516e08: ldr             x0, [fp, #0x18]
    // 0x516e0c: ldr             x16, [fp, #0x10]
    // 0x516e10: stp             x16, x0, [SP, #-0x10]!
    // 0x516e14: r0 = replaceRange()
    //     0x516e14: bl              #0x516e34  ; [dart:collection] _ListBase&Object&ListMixin::replaceRange
    // 0x516e18: add             SP, SP, #0x20
    // 0x516e1c: r0 = Null
    //     0x516e1c: mov             x0, NULL
    // 0x516e20: LeaveFrame
    //     0x516e20: mov             SP, fp
    //     0x516e24: ldp             fp, lr, [SP], #0x10
    // 0x516e28: ret
    //     0x516e28: ret             
    // 0x516e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x516e2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x516e30: b               #0x516df4
  }
  X0 [](DelegatingList<X0>, int) {
    // ** addr: 0xca793c, size: 0x60
    // 0xca793c: EnterFrame
    //     0xca793c: stp             fp, lr, [SP, #-0x10]!
    //     0xca7940: mov             fp, SP
    // 0xca7944: ldr             x2, [fp, #0x18]
    // 0xca7948: LoadField: r3 = r2->field_b
    //     0xca7948: ldur            w3, [x2, #0xb]
    // 0xca794c: DecompressPointer r3
    //     0xca794c: add             x3, x3, HEAP, lsl #32
    // 0xca7950: LoadField: r2 = r3->field_b
    //     0xca7950: ldur            w2, [x3, #0xb]
    // 0xca7954: DecompressPointer r2
    //     0xca7954: add             x2, x2, HEAP, lsl #32
    // 0xca7958: ldr             x4, [fp, #0x10]
    // 0xca795c: r5 = LoadInt32Instr(r4)
    //     0xca795c: sbfx            x5, x4, #1, #0x1f
    //     0xca7960: tbz             w4, #0, #0xca7968
    //     0xca7964: ldur            x5, [x4, #7]
    // 0xca7968: r0 = LoadInt32Instr(r2)
    //     0xca7968: sbfx            x0, x2, #1, #0x1f
    // 0xca796c: mov             x1, x5
    // 0xca7970: cmp             x1, x0
    // 0xca7974: b.hs            #0xca7998
    // 0xca7978: LoadField: r1 = r3->field_f
    //     0xca7978: ldur            w1, [x3, #0xf]
    // 0xca797c: DecompressPointer r1
    //     0xca797c: add             x1, x1, HEAP, lsl #32
    // 0xca7980: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0xca7980: add             x16, x1, x5, lsl #2
    //     0xca7984: ldur            w0, [x16, #0xf]
    // 0xca7988: DecompressPointer r0
    //     0xca7988: add             x0, x0, HEAP, lsl #32
    // 0xca798c: LeaveFrame
    //     0xca798c: mov             SP, fp
    //     0xca7990: ldp             fp, lr, [SP], #0x10
    // 0xca7994: ret
    //     0xca7994: ret             
    // 0xca7998: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xca7998: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

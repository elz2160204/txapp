// lib: , url: package:collection/src/priority_queue.dart

// class id: 1048767, size: 0x8
class :: {
}

// class id: 4771, size: 0x24, field offset: 0x8
class HeapPriorityQueue<X0> extends Object
    implements PriorityQueue<X0> {

  bool isEmpty(HeapPriorityQueue<X0>) {
    // ** addr: 0x6ad0f8, size: 0x34
    // 0x6ad0f8: ldr             x1, [SP]
    // 0x6ad0fc: LoadField: r2 = r1->field_13
    //     0x6ad0fc: ldur            x2, [x1, #0x13]
    // 0x6ad100: cbz             x2, #0x6ad10c
    // 0x6ad104: r0 = false
    //     0x6ad104: add             x0, NULL, #0x30  ; false
    // 0x6ad108: b               #0x6ad110
    // 0x6ad10c: r0 = true
    //     0x6ad10c: add             x0, NULL, #0x20  ; true
    // 0x6ad110: ret
    //     0x6ad110: ret             
  }
  bool isNotEmpty(HeapPriorityQueue<X0>) {
    // ** addr: 0x5b84c4, size: 0x34
    // 0x5b84c4: ldr             x1, [SP]
    // 0x5b84c8: LoadField: r2 = r1->field_13
    //     0x5b84c8: ldur            x2, [x1, #0x13]
    // 0x5b84cc: cbnz            x2, #0x5b84d8
    // 0x5b84d0: r0 = false
    //     0x5b84d0: add             x0, NULL, #0x30  ; false
    // 0x5b84d4: b               #0x5b84dc
    // 0x5b84d8: r0 = true
    //     0x5b84d8: add             x0, NULL, #0x20  ; true
    // 0x5b84dc: ret
    //     0x5b84dc: ret             
  }
  _ removeFirst(/* No info */) {
    // ** addr: 0x5b839c, size: 0x110
    // 0x5b839c: EnterFrame
    //     0x5b839c: stp             fp, lr, [SP, #-0x10]!
    //     0x5b83a0: mov             fp, SP
    // 0x5b83a4: AllocStack(0x8)
    //     0x5b83a4: sub             SP, SP, #8
    // 0x5b83a8: CheckStackOverflow
    //     0x5b83a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b83ac: cmp             SP, x16
    //     0x5b83b0: b.ls            #0x5b84a0
    // 0x5b83b4: ldr             x3, [fp, #0x10]
    // 0x5b83b8: LoadField: r0 = r3->field_13
    //     0x5b83b8: ldur            x0, [x3, #0x13]
    // 0x5b83bc: cbz             x0, #0x5b8484
    // 0x5b83c0: LoadField: r0 = r3->field_1b
    //     0x5b83c0: ldur            x0, [x3, #0x1b]
    // 0x5b83c4: add             x1, x0, #1
    // 0x5b83c8: StoreField: r3->field_1b = r1
    //     0x5b83c8: stur            x1, [x3, #0x1b]
    // 0x5b83cc: LoadField: r2 = r3->field_f
    //     0x5b83cc: ldur            w2, [x3, #0xf]
    // 0x5b83d0: DecompressPointer r2
    //     0x5b83d0: add             x2, x2, HEAP, lsl #32
    // 0x5b83d4: LoadField: r0 = r2->field_b
    //     0x5b83d4: ldur            w0, [x2, #0xb]
    // 0x5b83d8: DecompressPointer r0
    //     0x5b83d8: add             x0, x0, HEAP, lsl #32
    // 0x5b83dc: r1 = LoadInt32Instr(r0)
    //     0x5b83dc: sbfx            x1, x0, #1, #0x1f
    // 0x5b83e0: mov             x0, x1
    // 0x5b83e4: r1 = 0
    //     0x5b83e4: mov             x1, #0
    // 0x5b83e8: cmp             x1, x0
    // 0x5b83ec: b.hs            #0x5b84a8
    // 0x5b83f0: LoadField: r0 = r2->field_f
    //     0x5b83f0: ldur            w0, [x2, #0xf]
    // 0x5b83f4: DecompressPointer r0
    //     0x5b83f4: add             x0, x0, HEAP, lsl #32
    // 0x5b83f8: cmp             w0, NULL
    // 0x5b83fc: b.ne            #0x5b8438
    // 0x5b8400: LoadField: r2 = r3->field_7
    //     0x5b8400: ldur            w2, [x3, #7]
    // 0x5b8404: DecompressPointer r2
    //     0x5b8404: add             x2, x2, HEAP, lsl #32
    // 0x5b8408: r0 = Null
    //     0x5b8408: mov             x0, NULL
    // 0x5b840c: r1 = Null
    //     0x5b840c: mov             x1, NULL
    // 0x5b8410: cmp             w2, NULL
    // 0x5b8414: b.eq            #0x5b8430
    // 0x5b8418: LoadField: r4 = r2->field_17
    //     0x5b8418: ldur            w4, [x2, #0x17]
    // 0x5b841c: DecompressPointer r4
    //     0x5b841c: add             x4, x4, HEAP, lsl #32
    // 0x5b8420: r8 = X0
    //     0x5b8420: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b8424: LoadField: r9 = r4->field_7
    //     0x5b8424: ldur            x9, [x4, #7]
    // 0x5b8428: r3 = Null
    //     0x5b8428: ldr             x3, [PP, #0x3810]  ; [pp+0x3810] Null
    // 0x5b842c: blr             x9
    // 0x5b8430: r1 = Null
    //     0x5b8430: mov             x1, NULL
    // 0x5b8434: b               #0x5b843c
    // 0x5b8438: mov             x1, x0
    // 0x5b843c: ldr             x0, [fp, #0x10]
    // 0x5b8440: stur            x1, [fp, #-8]
    // 0x5b8444: SaveReg r0
    //     0x5b8444: str             x0, [SP, #-8]!
    // 0x5b8448: r0 = _removeLast()
    //     0x5b8448: bl              #0x5b8a84  ; [package:collection/src/priority_queue.dart] HeapPriorityQueue::_removeLast
    // 0x5b844c: add             SP, SP, #8
    // 0x5b8450: mov             x1, x0
    // 0x5b8454: ldr             x0, [fp, #0x10]
    // 0x5b8458: LoadField: r2 = r0->field_13
    //     0x5b8458: ldur            x2, [x0, #0x13]
    // 0x5b845c: cmp             x2, #0
    // 0x5b8460: b.le            #0x5b8474
    // 0x5b8464: stp             x1, x0, [SP, #-0x10]!
    // 0x5b8468: SaveReg rZR
    //     0x5b8468: str             xzr, [SP, #-8]!
    // 0x5b846c: r0 = _bubbleDown()
    //     0x5b846c: bl              #0x5b84e0  ; [package:collection/src/priority_queue.dart] HeapPriorityQueue::_bubbleDown
    // 0x5b8470: add             SP, SP, #0x18
    // 0x5b8474: ldur            x0, [fp, #-8]
    // 0x5b8478: LeaveFrame
    //     0x5b8478: mov             SP, fp
    //     0x5b847c: ldp             fp, lr, [SP], #0x10
    // 0x5b8480: ret
    //     0x5b8480: ret             
    // 0x5b8484: r0 = StateError()
    //     0x5b8484: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x5b8488: mov             x1, x0
    // 0x5b848c: r0 = "No element"
    //     0x5b848c: ldr             x0, [PP, #0x10b8]  ; [pp+0x10b8] "No element"
    // 0x5b8490: StoreField: r1->field_b = r0
    //     0x5b8490: stur            w0, [x1, #0xb]
    // 0x5b8494: mov             x0, x1
    // 0x5b8498: r0 = Throw()
    //     0x5b8498: bl              #0xd67e38  ; ThrowStub
    // 0x5b849c: brk             #0
    // 0x5b84a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b84a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b84a4: b               #0x5b83b4
    // 0x5b84a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b84a8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _bubbleDown(/* No info */) {
    // ** addr: 0x5b84e0, size: 0x5a4
    // 0x5b84e0: EnterFrame
    //     0x5b84e0: stp             fp, lr, [SP, #-0x10]!
    //     0x5b84e4: mov             fp, SP
    // 0x5b84e8: AllocStack(0x40)
    //     0x5b84e8: sub             SP, SP, #0x40
    // 0x5b84ec: CheckStackOverflow
    //     0x5b84ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b84f0: cmp             SP, x16
    //     0x5b84f4: b.ls            #0x5b8a4c
    // 0x5b84f8: ldr             x3, [fp, #0x20]
    // 0x5b84fc: LoadField: r4 = r3->field_b
    //     0x5b84fc: ldur            w4, [x3, #0xb]
    // 0x5b8500: DecompressPointer r4
    //     0x5b8500: add             x4, x4, HEAP, lsl #32
    // 0x5b8504: stur            x4, [fp, #-0x38]
    // 0x5b8508: LoadField: r5 = r3->field_7
    //     0x5b8508: ldur            w5, [x3, #7]
    // 0x5b850c: DecompressPointer r5
    //     0x5b850c: add             x5, x5, HEAP, lsl #32
    // 0x5b8510: stur            x5, [fp, #-0x30]
    // 0x5b8514: r7 = 0
    //     0x5b8514: mov             x7, #0
    // 0x5b8518: r6 = 2
    //     0x5b8518: mov             x6, #2
    // 0x5b851c: stur            x7, [fp, #-0x20]
    // 0x5b8520: stur            x6, [fp, #-0x28]
    // 0x5b8524: CheckStackOverflow
    //     0x5b8524: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b8528: cmp             SP, x16
    //     0x5b852c: b.ls            #0x5b8a54
    // 0x5b8530: LoadField: r0 = r3->field_13
    //     0x5b8530: ldur            x0, [x3, #0x13]
    // 0x5b8534: cmp             x6, x0
    // 0x5b8538: b.ge            #0x5b8820
    // 0x5b853c: sub             x8, x6, #1
    // 0x5b8540: stur            x8, [fp, #-0x18]
    // 0x5b8544: LoadField: r9 = r3->field_f
    //     0x5b8544: ldur            w9, [x3, #0xf]
    // 0x5b8548: DecompressPointer r9
    //     0x5b8548: add             x9, x9, HEAP, lsl #32
    // 0x5b854c: stur            x9, [fp, #-0x10]
    // 0x5b8550: LoadField: r0 = r9->field_b
    //     0x5b8550: ldur            w0, [x9, #0xb]
    // 0x5b8554: DecompressPointer r0
    //     0x5b8554: add             x0, x0, HEAP, lsl #32
    // 0x5b8558: r10 = LoadInt32Instr(r0)
    //     0x5b8558: sbfx            x10, x0, #1, #0x1f
    // 0x5b855c: mov             x0, x10
    // 0x5b8560: mov             x1, x8
    // 0x5b8564: stur            x10, [fp, #-8]
    // 0x5b8568: cmp             x1, x0
    // 0x5b856c: b.hs            #0x5b8a5c
    // 0x5b8570: ArrayLoad: r0 = r9[r8]  ; Unknown_4
    //     0x5b8570: add             x16, x9, x8, lsl #2
    //     0x5b8574: ldur            w0, [x16, #0xf]
    // 0x5b8578: DecompressPointer r0
    //     0x5b8578: add             x0, x0, HEAP, lsl #32
    // 0x5b857c: cmp             w0, NULL
    // 0x5b8580: b.ne            #0x5b85b8
    // 0x5b8584: mov             x2, x5
    // 0x5b8588: r0 = Null
    //     0x5b8588: mov             x0, NULL
    // 0x5b858c: r1 = Null
    //     0x5b858c: mov             x1, NULL
    // 0x5b8590: cmp             w2, NULL
    // 0x5b8594: b.eq            #0x5b85b0
    // 0x5b8598: LoadField: r4 = r2->field_17
    //     0x5b8598: ldur            w4, [x2, #0x17]
    // 0x5b859c: DecompressPointer r4
    //     0x5b859c: add             x4, x4, HEAP, lsl #32
    // 0x5b85a0: r8 = X0
    //     0x5b85a0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b85a4: LoadField: r9 = r4->field_7
    //     0x5b85a4: ldur            x9, [x4, #7]
    // 0x5b85a8: r3 = Null
    //     0x5b85a8: ldr             x3, [PP, #0x3820]  ; [pp+0x3820] Null
    // 0x5b85ac: blr             x9
    // 0x5b85b0: r4 = Null
    //     0x5b85b0: mov             x4, NULL
    // 0x5b85b4: b               #0x5b85bc
    // 0x5b85b8: mov             x4, x0
    // 0x5b85bc: ldur            x3, [fp, #-0x28]
    // 0x5b85c0: ldur            x2, [fp, #-0x10]
    // 0x5b85c4: ldur            x0, [fp, #-8]
    // 0x5b85c8: mov             x1, x3
    // 0x5b85cc: stur            x4, [fp, #-0x40]
    // 0x5b85d0: cmp             x1, x0
    // 0x5b85d4: b.hs            #0x5b8a60
    // 0x5b85d8: ArrayLoad: r0 = r2[r3]  ; Unknown_4
    //     0x5b85d8: add             x16, x2, x3, lsl #2
    //     0x5b85dc: ldur            w0, [x16, #0xf]
    // 0x5b85e0: DecompressPointer r0
    //     0x5b85e0: add             x0, x0, HEAP, lsl #32
    // 0x5b85e4: cmp             w0, NULL
    // 0x5b85e8: b.ne            #0x5b8620
    // 0x5b85ec: ldur            x2, [fp, #-0x30]
    // 0x5b85f0: r0 = Null
    //     0x5b85f0: mov             x0, NULL
    // 0x5b85f4: r1 = Null
    //     0x5b85f4: mov             x1, NULL
    // 0x5b85f8: cmp             w2, NULL
    // 0x5b85fc: b.eq            #0x5b8618
    // 0x5b8600: LoadField: r4 = r2->field_17
    //     0x5b8600: ldur            w4, [x2, #0x17]
    // 0x5b8604: DecompressPointer r4
    //     0x5b8604: add             x4, x4, HEAP, lsl #32
    // 0x5b8608: r8 = X0
    //     0x5b8608: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b860c: LoadField: r9 = r4->field_7
    //     0x5b860c: ldur            x9, [x4, #7]
    // 0x5b8610: r3 = Null
    //     0x5b8610: ldr             x3, [PP, #0x3830]  ; [pp+0x3830] Null
    // 0x5b8614: blr             x9
    // 0x5b8618: r1 = Null
    //     0x5b8618: mov             x1, NULL
    // 0x5b861c: b               #0x5b8624
    // 0x5b8620: mov             x1, x0
    // 0x5b8624: stur            x1, [fp, #-0x10]
    // 0x5b8628: ldur            x16, [fp, #-0x38]
    // 0x5b862c: ldur            lr, [fp, #-0x40]
    // 0x5b8630: stp             lr, x16, [SP, #-0x10]!
    // 0x5b8634: SaveReg r1
    //     0x5b8634: str             x1, [SP, #-8]!
    // 0x5b8638: ldur            x0, [fp, #-0x38]
    // 0x5b863c: ClosureCall
    //     0x5b863c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x5b8640: ldur            x2, [x0, #0x1f]
    //     0x5b8644: blr             x2
    // 0x5b8648: add             SP, SP, #0x18
    // 0x5b864c: cmp             w0, NULL
    // 0x5b8650: b.eq            #0x5b8a64
    // 0x5b8654: r1 = LoadInt32Instr(r0)
    //     0x5b8654: sbfx            x1, x0, #1, #0x1f
    //     0x5b8658: tbz             w0, #0, #0x5b8660
    //     0x5b865c: ldur            x1, [x0, #7]
    // 0x5b8660: tbz             x1, #0x3f, #0x5b8670
    // 0x5b8664: ldur            x7, [fp, #-0x18]
    // 0x5b8668: ldur            x1, [fp, #-0x40]
    // 0x5b866c: b               #0x5b8678
    // 0x5b8670: ldur            x7, [fp, #-0x28]
    // 0x5b8674: ldur            x1, [fp, #-0x10]
    // 0x5b8678: stur            x7, [fp, #-8]
    // 0x5b867c: stur            x1, [fp, #-0x10]
    // 0x5b8680: ldur            x16, [fp, #-0x38]
    // 0x5b8684: ldr             lr, [fp, #0x18]
    // 0x5b8688: stp             lr, x16, [SP, #-0x10]!
    // 0x5b868c: SaveReg r1
    //     0x5b868c: str             x1, [SP, #-8]!
    // 0x5b8690: ldur            x0, [fp, #-0x38]
    // 0x5b8694: ClosureCall
    //     0x5b8694: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x5b8698: ldur            x2, [x0, #0x1f]
    //     0x5b869c: blr             x2
    // 0x5b86a0: add             SP, SP, #0x18
    // 0x5b86a4: cmp             w0, NULL
    // 0x5b86a8: b.eq            #0x5b8a68
    // 0x5b86ac: r1 = LoadInt32Instr(r0)
    //     0x5b86ac: sbfx            x1, x0, #1, #0x1f
    //     0x5b86b0: tbz             w0, #0, #0x5b86b8
    //     0x5b86b4: ldur            x1, [x0, #7]
    // 0x5b86b8: cmp             x1, #0
    // 0x5b86bc: b.gt            #0x5b8768
    // 0x5b86c0: ldr             x3, [fp, #0x20]
    // 0x5b86c4: ldur            x4, [fp, #-0x20]
    // 0x5b86c8: LoadField: r5 = r3->field_f
    //     0x5b86c8: ldur            w5, [x3, #0xf]
    // 0x5b86cc: DecompressPointer r5
    //     0x5b86cc: add             x5, x5, HEAP, lsl #32
    // 0x5b86d0: stur            x5, [fp, #-0x40]
    // 0x5b86d4: LoadField: r2 = r5->field_7
    //     0x5b86d4: ldur            w2, [x5, #7]
    // 0x5b86d8: DecompressPointer r2
    //     0x5b86d8: add             x2, x2, HEAP, lsl #32
    // 0x5b86dc: ldr             x0, [fp, #0x18]
    // 0x5b86e0: r1 = Null
    //     0x5b86e0: mov             x1, NULL
    // 0x5b86e4: cmp             w2, NULL
    // 0x5b86e8: b.eq            #0x5b8704
    // 0x5b86ec: LoadField: r4 = r2->field_17
    //     0x5b86ec: ldur            w4, [x2, #0x17]
    // 0x5b86f0: DecompressPointer r4
    //     0x5b86f0: add             x4, x4, HEAP, lsl #32
    // 0x5b86f4: r8 = X0
    //     0x5b86f4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b86f8: LoadField: r9 = r4->field_7
    //     0x5b86f8: ldur            x9, [x4, #7]
    // 0x5b86fc: r3 = Null
    //     0x5b86fc: ldr             x3, [PP, #0x3840]  ; [pp+0x3840] Null
    // 0x5b8700: blr             x9
    // 0x5b8704: ldur            x2, [fp, #-0x40]
    // 0x5b8708: LoadField: r0 = r2->field_b
    //     0x5b8708: ldur            w0, [x2, #0xb]
    // 0x5b870c: DecompressPointer r0
    //     0x5b870c: add             x0, x0, HEAP, lsl #32
    // 0x5b8710: r1 = LoadInt32Instr(r0)
    //     0x5b8710: sbfx            x1, x0, #1, #0x1f
    // 0x5b8714: mov             x0, x1
    // 0x5b8718: ldur            x1, [fp, #-0x20]
    // 0x5b871c: cmp             x1, x0
    // 0x5b8720: b.hs            #0x5b8a6c
    // 0x5b8724: mov             x1, x2
    // 0x5b8728: ldr             x0, [fp, #0x18]
    // 0x5b872c: ldur            x4, [fp, #-0x20]
    // 0x5b8730: ArrayStore: r1[r4] = r0  ; List_4
    //     0x5b8730: add             x25, x1, x4, lsl #2
    //     0x5b8734: add             x25, x25, #0xf
    //     0x5b8738: str             w0, [x25]
    //     0x5b873c: tbz             w0, #0, #0x5b8758
    //     0x5b8740: ldurb           w16, [x1, #-1]
    //     0x5b8744: ldurb           w17, [x0, #-1]
    //     0x5b8748: and             x16, x17, x16, lsr #2
    //     0x5b874c: tst             x16, HEAP, lsr #32
    //     0x5b8750: b.eq            #0x5b8758
    //     0x5b8754: bl              #0xd67e5c
    // 0x5b8758: r0 = Null
    //     0x5b8758: mov             x0, NULL
    // 0x5b875c: LeaveFrame
    //     0x5b875c: mov             SP, fp
    //     0x5b8760: ldp             fp, lr, [SP], #0x10
    // 0x5b8764: ret
    //     0x5b8764: ret             
    // 0x5b8768: ldr             x3, [fp, #0x20]
    // 0x5b876c: ldur            x4, [fp, #-0x20]
    // 0x5b8770: ldur            x7, [fp, #-8]
    // 0x5b8774: LoadField: r5 = r3->field_f
    //     0x5b8774: ldur            w5, [x3, #0xf]
    // 0x5b8778: DecompressPointer r5
    //     0x5b8778: add             x5, x5, HEAP, lsl #32
    // 0x5b877c: stur            x5, [fp, #-0x40]
    // 0x5b8780: LoadField: r2 = r5->field_7
    //     0x5b8780: ldur            w2, [x5, #7]
    // 0x5b8784: DecompressPointer r2
    //     0x5b8784: add             x2, x2, HEAP, lsl #32
    // 0x5b8788: ldur            x0, [fp, #-0x10]
    // 0x5b878c: r1 = Null
    //     0x5b878c: mov             x1, NULL
    // 0x5b8790: cmp             w2, NULL
    // 0x5b8794: b.eq            #0x5b87b0
    // 0x5b8798: LoadField: r4 = r2->field_17
    //     0x5b8798: ldur            w4, [x2, #0x17]
    // 0x5b879c: DecompressPointer r4
    //     0x5b879c: add             x4, x4, HEAP, lsl #32
    // 0x5b87a0: r8 = X0
    //     0x5b87a0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b87a4: LoadField: r9 = r4->field_7
    //     0x5b87a4: ldur            x9, [x4, #7]
    // 0x5b87a8: r3 = Null
    //     0x5b87a8: ldr             x3, [PP, #0x3850]  ; [pp+0x3850] Null
    // 0x5b87ac: blr             x9
    // 0x5b87b0: ldur            x2, [fp, #-0x40]
    // 0x5b87b4: LoadField: r0 = r2->field_b
    //     0x5b87b4: ldur            w0, [x2, #0xb]
    // 0x5b87b8: DecompressPointer r0
    //     0x5b87b8: add             x0, x0, HEAP, lsl #32
    // 0x5b87bc: r1 = LoadInt32Instr(r0)
    //     0x5b87bc: sbfx            x1, x0, #1, #0x1f
    // 0x5b87c0: mov             x0, x1
    // 0x5b87c4: ldur            x1, [fp, #-0x20]
    // 0x5b87c8: cmp             x1, x0
    // 0x5b87cc: b.hs            #0x5b8a70
    // 0x5b87d0: mov             x1, x2
    // 0x5b87d4: ldur            x0, [fp, #-0x10]
    // 0x5b87d8: ldur            x3, [fp, #-0x20]
    // 0x5b87dc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x5b87dc: add             x25, x1, x3, lsl #2
    //     0x5b87e0: add             x25, x25, #0xf
    //     0x5b87e4: str             w0, [x25]
    //     0x5b87e8: tbz             w0, #0, #0x5b8804
    //     0x5b87ec: ldurb           w16, [x1, #-1]
    //     0x5b87f0: ldurb           w17, [x0, #-1]
    //     0x5b87f4: and             x16, x17, x16, lsr #2
    //     0x5b87f8: tst             x16, HEAP, lsr #32
    //     0x5b87fc: b.eq            #0x5b8804
    //     0x5b8800: bl              #0xd67e5c
    // 0x5b8804: ldur            x7, [fp, #-8]
    // 0x5b8808: lsl             x0, x7, #1
    // 0x5b880c: add             x6, x0, #2
    // 0x5b8810: ldr             x3, [fp, #0x20]
    // 0x5b8814: ldur            x4, [fp, #-0x38]
    // 0x5b8818: ldur            x5, [fp, #-0x30]
    // 0x5b881c: b               #0x5b851c
    // 0x5b8820: mov             x3, x7
    // 0x5b8824: mov             x1, x6
    // 0x5b8828: sub             x4, x1, #1
    // 0x5b882c: stur            x4, [fp, #-8]
    // 0x5b8830: cmp             x4, x0
    // 0x5b8834: b.ge            #0x5b89a0
    // 0x5b8838: ldr             x5, [fp, #0x20]
    // 0x5b883c: LoadField: r2 = r5->field_f
    //     0x5b883c: ldur            w2, [x5, #0xf]
    // 0x5b8840: DecompressPointer r2
    //     0x5b8840: add             x2, x2, HEAP, lsl #32
    // 0x5b8844: LoadField: r0 = r2->field_b
    //     0x5b8844: ldur            w0, [x2, #0xb]
    // 0x5b8848: DecompressPointer r0
    //     0x5b8848: add             x0, x0, HEAP, lsl #32
    // 0x5b884c: r1 = LoadInt32Instr(r0)
    //     0x5b884c: sbfx            x1, x0, #1, #0x1f
    // 0x5b8850: mov             x0, x1
    // 0x5b8854: mov             x1, x4
    // 0x5b8858: cmp             x1, x0
    // 0x5b885c: b.hs            #0x5b8a74
    // 0x5b8860: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x5b8860: add             x16, x2, x4, lsl #2
    //     0x5b8864: ldur            w0, [x16, #0xf]
    // 0x5b8868: DecompressPointer r0
    //     0x5b8868: add             x0, x0, HEAP, lsl #32
    // 0x5b886c: cmp             w0, NULL
    // 0x5b8870: b.ne            #0x5b88a8
    // 0x5b8874: ldur            x2, [fp, #-0x30]
    // 0x5b8878: r0 = Null
    //     0x5b8878: mov             x0, NULL
    // 0x5b887c: r1 = Null
    //     0x5b887c: mov             x1, NULL
    // 0x5b8880: cmp             w2, NULL
    // 0x5b8884: b.eq            #0x5b88a0
    // 0x5b8888: LoadField: r4 = r2->field_17
    //     0x5b8888: ldur            w4, [x2, #0x17]
    // 0x5b888c: DecompressPointer r4
    //     0x5b888c: add             x4, x4, HEAP, lsl #32
    // 0x5b8890: r8 = X0
    //     0x5b8890: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b8894: LoadField: r9 = r4->field_7
    //     0x5b8894: ldur            x9, [x4, #7]
    // 0x5b8898: r3 = Null
    //     0x5b8898: ldr             x3, [PP, #0x3860]  ; [pp+0x3860] Null
    // 0x5b889c: blr             x9
    // 0x5b88a0: r1 = Null
    //     0x5b88a0: mov             x1, NULL
    // 0x5b88a4: b               #0x5b88ac
    // 0x5b88a8: mov             x1, x0
    // 0x5b88ac: stur            x1, [fp, #-0x10]
    // 0x5b88b0: ldur            x16, [fp, #-0x38]
    // 0x5b88b4: ldr             lr, [fp, #0x18]
    // 0x5b88b8: stp             lr, x16, [SP, #-0x10]!
    // 0x5b88bc: SaveReg r1
    //     0x5b88bc: str             x1, [SP, #-8]!
    // 0x5b88c0: ldur            x0, [fp, #-0x38]
    // 0x5b88c4: ClosureCall
    //     0x5b88c4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x5b88c8: ldur            x2, [x0, #0x1f]
    //     0x5b88cc: blr             x2
    // 0x5b88d0: add             SP, SP, #0x18
    // 0x5b88d4: cmp             w0, NULL
    // 0x5b88d8: b.eq            #0x5b8a78
    // 0x5b88dc: r1 = LoadInt32Instr(r0)
    //     0x5b88dc: sbfx            x1, x0, #1, #0x1f
    //     0x5b88e0: tbz             w0, #0, #0x5b88e8
    //     0x5b88e4: ldur            x1, [x0, #7]
    // 0x5b88e8: cmp             x1, #0
    // 0x5b88ec: b.le            #0x5b8990
    // 0x5b88f0: ldr             x4, [fp, #0x20]
    // 0x5b88f4: ldur            x3, [fp, #-0x20]
    // 0x5b88f8: LoadField: r5 = r4->field_f
    //     0x5b88f8: ldur            w5, [x4, #0xf]
    // 0x5b88fc: DecompressPointer r5
    //     0x5b88fc: add             x5, x5, HEAP, lsl #32
    // 0x5b8900: stur            x5, [fp, #-0x30]
    // 0x5b8904: LoadField: r2 = r5->field_7
    //     0x5b8904: ldur            w2, [x5, #7]
    // 0x5b8908: DecompressPointer r2
    //     0x5b8908: add             x2, x2, HEAP, lsl #32
    // 0x5b890c: ldur            x0, [fp, #-0x10]
    // 0x5b8910: r1 = Null
    //     0x5b8910: mov             x1, NULL
    // 0x5b8914: cmp             w2, NULL
    // 0x5b8918: b.eq            #0x5b8934
    // 0x5b891c: LoadField: r4 = r2->field_17
    //     0x5b891c: ldur            w4, [x2, #0x17]
    // 0x5b8920: DecompressPointer r4
    //     0x5b8920: add             x4, x4, HEAP, lsl #32
    // 0x5b8924: r8 = X0
    //     0x5b8924: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b8928: LoadField: r9 = r4->field_7
    //     0x5b8928: ldur            x9, [x4, #7]
    // 0x5b892c: r3 = Null
    //     0x5b892c: ldr             x3, [PP, #0x3870]  ; [pp+0x3870] Null
    // 0x5b8930: blr             x9
    // 0x5b8934: ldur            x2, [fp, #-0x30]
    // 0x5b8938: LoadField: r0 = r2->field_b
    //     0x5b8938: ldur            w0, [x2, #0xb]
    // 0x5b893c: DecompressPointer r0
    //     0x5b893c: add             x0, x0, HEAP, lsl #32
    // 0x5b8940: r1 = LoadInt32Instr(r0)
    //     0x5b8940: sbfx            x1, x0, #1, #0x1f
    // 0x5b8944: mov             x0, x1
    // 0x5b8948: ldur            x1, [fp, #-0x20]
    // 0x5b894c: cmp             x1, x0
    // 0x5b8950: b.hs            #0x5b8a7c
    // 0x5b8954: mov             x1, x2
    // 0x5b8958: ldur            x0, [fp, #-0x10]
    // 0x5b895c: ldur            x2, [fp, #-0x20]
    // 0x5b8960: ArrayStore: r1[r2] = r0  ; List_4
    //     0x5b8960: add             x25, x1, x2, lsl #2
    //     0x5b8964: add             x25, x25, #0xf
    //     0x5b8968: str             w0, [x25]
    //     0x5b896c: tbz             w0, #0, #0x5b8988
    //     0x5b8970: ldurb           w16, [x1, #-1]
    //     0x5b8974: ldurb           w17, [x0, #-1]
    //     0x5b8978: and             x16, x17, x16, lsr #2
    //     0x5b897c: tst             x16, HEAP, lsr #32
    //     0x5b8980: b.eq            #0x5b8988
    //     0x5b8984: bl              #0xd67e5c
    // 0x5b8988: ldur            x0, [fp, #-8]
    // 0x5b898c: b               #0x5b8998
    // 0x5b8990: ldur            x2, [fp, #-0x20]
    // 0x5b8994: mov             x0, x2
    // 0x5b8998: mov             x3, x0
    // 0x5b899c: b               #0x5b89a8
    // 0x5b89a0: mov             x2, x3
    // 0x5b89a4: mov             x3, x2
    // 0x5b89a8: ldr             x0, [fp, #0x20]
    // 0x5b89ac: stur            x3, [fp, #-8]
    // 0x5b89b0: LoadField: r4 = r0->field_f
    //     0x5b89b0: ldur            w4, [x0, #0xf]
    // 0x5b89b4: DecompressPointer r4
    //     0x5b89b4: add             x4, x4, HEAP, lsl #32
    // 0x5b89b8: stur            x4, [fp, #-0x10]
    // 0x5b89bc: LoadField: r2 = r4->field_7
    //     0x5b89bc: ldur            w2, [x4, #7]
    // 0x5b89c0: DecompressPointer r2
    //     0x5b89c0: add             x2, x2, HEAP, lsl #32
    // 0x5b89c4: ldr             x0, [fp, #0x18]
    // 0x5b89c8: r1 = Null
    //     0x5b89c8: mov             x1, NULL
    // 0x5b89cc: cmp             w2, NULL
    // 0x5b89d0: b.eq            #0x5b89ec
    // 0x5b89d4: LoadField: r4 = r2->field_17
    //     0x5b89d4: ldur            w4, [x2, #0x17]
    // 0x5b89d8: DecompressPointer r4
    //     0x5b89d8: add             x4, x4, HEAP, lsl #32
    // 0x5b89dc: r8 = X0
    //     0x5b89dc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b89e0: LoadField: r9 = r4->field_7
    //     0x5b89e0: ldur            x9, [x4, #7]
    // 0x5b89e4: r3 = Null
    //     0x5b89e4: ldr             x3, [PP, #0x3880]  ; [pp+0x3880] Null
    // 0x5b89e8: blr             x9
    // 0x5b89ec: ldur            x2, [fp, #-0x10]
    // 0x5b89f0: LoadField: r3 = r2->field_b
    //     0x5b89f0: ldur            w3, [x2, #0xb]
    // 0x5b89f4: DecompressPointer r3
    //     0x5b89f4: add             x3, x3, HEAP, lsl #32
    // 0x5b89f8: r0 = LoadInt32Instr(r3)
    //     0x5b89f8: sbfx            x0, x3, #1, #0x1f
    // 0x5b89fc: ldur            x1, [fp, #-8]
    // 0x5b8a00: cmp             x1, x0
    // 0x5b8a04: b.hs            #0x5b8a80
    // 0x5b8a08: mov             x1, x2
    // 0x5b8a0c: ldr             x0, [fp, #0x18]
    // 0x5b8a10: ldur            x2, [fp, #-8]
    // 0x5b8a14: ArrayStore: r1[r2] = r0  ; List_4
    //     0x5b8a14: add             x25, x1, x2, lsl #2
    //     0x5b8a18: add             x25, x25, #0xf
    //     0x5b8a1c: str             w0, [x25]
    //     0x5b8a20: tbz             w0, #0, #0x5b8a3c
    //     0x5b8a24: ldurb           w16, [x1, #-1]
    //     0x5b8a28: ldurb           w17, [x0, #-1]
    //     0x5b8a2c: and             x16, x17, x16, lsr #2
    //     0x5b8a30: tst             x16, HEAP, lsr #32
    //     0x5b8a34: b.eq            #0x5b8a3c
    //     0x5b8a38: bl              #0xd67e5c
    // 0x5b8a3c: r0 = Null
    //     0x5b8a3c: mov             x0, NULL
    // 0x5b8a40: LeaveFrame
    //     0x5b8a40: mov             SP, fp
    //     0x5b8a44: ldp             fp, lr, [SP], #0x10
    // 0x5b8a48: ret
    //     0x5b8a48: ret             
    // 0x5b8a4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b8a4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b8a50: b               #0x5b84f8
    // 0x5b8a54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b8a54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b8a58: b               #0x5b8530
    // 0x5b8a5c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b8a5c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5b8a60: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b8a60: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5b8a64: r0 = NullErrorSharedWithoutFPURegs()
    //     0x5b8a64: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x5b8a68: r0 = NullErrorSharedWithoutFPURegs()
    //     0x5b8a68: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x5b8a6c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b8a6c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5b8a70: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b8a70: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5b8a74: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b8a74: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5b8a78: r0 = NullErrorSharedWithoutFPURegs()
    //     0x5b8a78: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x5b8a7c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b8a7c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5b8a80: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b8a80: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _removeLast(/* No info */) {
    // ** addr: 0x5b8a84, size: 0xb4
    // 0x5b8a84: EnterFrame
    //     0x5b8a84: stp             fp, lr, [SP, #-0x10]!
    //     0x5b8a88: mov             fp, SP
    // 0x5b8a8c: AllocStack(0x10)
    //     0x5b8a8c: sub             SP, SP, #0x10
    // 0x5b8a90: ldr             x3, [fp, #0x10]
    // 0x5b8a94: LoadField: r0 = r3->field_13
    //     0x5b8a94: ldur            x0, [x3, #0x13]
    // 0x5b8a98: sub             x4, x0, #1
    // 0x5b8a9c: stur            x4, [fp, #-0x10]
    // 0x5b8aa0: LoadField: r5 = r3->field_f
    //     0x5b8aa0: ldur            w5, [x3, #0xf]
    // 0x5b8aa4: DecompressPointer r5
    //     0x5b8aa4: add             x5, x5, HEAP, lsl #32
    // 0x5b8aa8: stur            x5, [fp, #-8]
    // 0x5b8aac: LoadField: r0 = r5->field_b
    //     0x5b8aac: ldur            w0, [x5, #0xb]
    // 0x5b8ab0: DecompressPointer r0
    //     0x5b8ab0: add             x0, x0, HEAP, lsl #32
    // 0x5b8ab4: r1 = LoadInt32Instr(r0)
    //     0x5b8ab4: sbfx            x1, x0, #1, #0x1f
    // 0x5b8ab8: mov             x0, x1
    // 0x5b8abc: mov             x1, x4
    // 0x5b8ac0: cmp             x1, x0
    // 0x5b8ac4: b.hs            #0x5b8b34
    // 0x5b8ac8: ArrayLoad: r0 = r5[r4]  ; Unknown_4
    //     0x5b8ac8: add             x16, x5, x4, lsl #2
    //     0x5b8acc: ldur            w0, [x16, #0xf]
    // 0x5b8ad0: DecompressPointer r0
    //     0x5b8ad0: add             x0, x0, HEAP, lsl #32
    // 0x5b8ad4: cmp             w0, NULL
    // 0x5b8ad8: b.ne            #0x5b8b10
    // 0x5b8adc: LoadField: r2 = r3->field_7
    //     0x5b8adc: ldur            w2, [x3, #7]
    // 0x5b8ae0: DecompressPointer r2
    //     0x5b8ae0: add             x2, x2, HEAP, lsl #32
    // 0x5b8ae4: r0 = Null
    //     0x5b8ae4: mov             x0, NULL
    // 0x5b8ae8: r1 = Null
    //     0x5b8ae8: mov             x1, NULL
    // 0x5b8aec: cmp             w2, NULL
    // 0x5b8af0: b.eq            #0x5b8b0c
    // 0x5b8af4: LoadField: r4 = r2->field_17
    //     0x5b8af4: ldur            w4, [x2, #0x17]
    // 0x5b8af8: DecompressPointer r4
    //     0x5b8af8: add             x4, x4, HEAP, lsl #32
    // 0x5b8afc: r8 = X0
    //     0x5b8afc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b8b00: LoadField: r9 = r4->field_7
    //     0x5b8b00: ldur            x9, [x4, #7]
    // 0x5b8b04: r3 = Null
    //     0x5b8b04: ldr             x3, [PP, #0x3890]  ; [pp+0x3890] Null
    // 0x5b8b08: blr             x9
    // 0x5b8b0c: r0 = Null
    //     0x5b8b0c: mov             x0, NULL
    // 0x5b8b10: ldr             x1, [fp, #0x10]
    // 0x5b8b14: ldur            x2, [fp, #-0x10]
    // 0x5b8b18: ldur            x3, [fp, #-8]
    // 0x5b8b1c: ArrayStore: r3[r2] = rNULL  ; Unknown_4
    //     0x5b8b1c: add             x4, x3, x2, lsl #2
    //     0x5b8b20: stur            NULL, [x4, #0xf]
    // 0x5b8b24: StoreField: r1->field_13 = r2
    //     0x5b8b24: stur            x2, [x1, #0x13]
    // 0x5b8b28: LeaveFrame
    //     0x5b8b28: mov             SP, fp
    //     0x5b8b2c: ldp             fp, lr, [SP], #0x10
    // 0x5b8b30: ret
    //     0x5b8b30: ret             
    // 0x5b8b34: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b8b34: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ first(/* No info */) {
    // ** addr: 0x5b8b38, size: 0xac
    // 0x5b8b38: EnterFrame
    //     0x5b8b38: stp             fp, lr, [SP, #-0x10]!
    //     0x5b8b3c: mov             fp, SP
    // 0x5b8b40: ldr             x2, [fp, #0x10]
    // 0x5b8b44: LoadField: r0 = r2->field_13
    //     0x5b8b44: ldur            x0, [x2, #0x13]
    // 0x5b8b48: cbz             x0, #0x5b8bc4
    // 0x5b8b4c: LoadField: r3 = r2->field_f
    //     0x5b8b4c: ldur            w3, [x2, #0xf]
    // 0x5b8b50: DecompressPointer r3
    //     0x5b8b50: add             x3, x3, HEAP, lsl #32
    // 0x5b8b54: LoadField: r0 = r3->field_b
    //     0x5b8b54: ldur            w0, [x3, #0xb]
    // 0x5b8b58: DecompressPointer r0
    //     0x5b8b58: add             x0, x0, HEAP, lsl #32
    // 0x5b8b5c: r1 = LoadInt32Instr(r0)
    //     0x5b8b5c: sbfx            x1, x0, #1, #0x1f
    // 0x5b8b60: mov             x0, x1
    // 0x5b8b64: r1 = 0
    //     0x5b8b64: mov             x1, #0
    // 0x5b8b68: cmp             x1, x0
    // 0x5b8b6c: b.hs            #0x5b8be0
    // 0x5b8b70: LoadField: r0 = r3->field_f
    //     0x5b8b70: ldur            w0, [x3, #0xf]
    // 0x5b8b74: DecompressPointer r0
    //     0x5b8b74: add             x0, x0, HEAP, lsl #32
    // 0x5b8b78: cmp             w0, NULL
    // 0x5b8b7c: b.ne            #0x5b8bb8
    // 0x5b8b80: LoadField: r0 = r2->field_7
    //     0x5b8b80: ldur            w0, [x2, #7]
    // 0x5b8b84: DecompressPointer r0
    //     0x5b8b84: add             x0, x0, HEAP, lsl #32
    // 0x5b8b88: mov             x2, x0
    // 0x5b8b8c: r0 = Null
    //     0x5b8b8c: mov             x0, NULL
    // 0x5b8b90: r1 = Null
    //     0x5b8b90: mov             x1, NULL
    // 0x5b8b94: cmp             w2, NULL
    // 0x5b8b98: b.eq            #0x5b8bb4
    // 0x5b8b9c: LoadField: r4 = r2->field_17
    //     0x5b8b9c: ldur            w4, [x2, #0x17]
    // 0x5b8ba0: DecompressPointer r4
    //     0x5b8ba0: add             x4, x4, HEAP, lsl #32
    // 0x5b8ba4: r8 = X0
    //     0x5b8ba4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b8ba8: LoadField: r9 = r4->field_7
    //     0x5b8ba8: ldur            x9, [x4, #7]
    // 0x5b8bac: r3 = Null
    //     0x5b8bac: ldr             x3, [PP, #0x38a0]  ; [pp+0x38a0] Null
    // 0x5b8bb0: blr             x9
    // 0x5b8bb4: r0 = Null
    //     0x5b8bb4: mov             x0, NULL
    // 0x5b8bb8: LeaveFrame
    //     0x5b8bb8: mov             SP, fp
    //     0x5b8bbc: ldp             fp, lr, [SP], #0x10
    // 0x5b8bc0: ret
    //     0x5b8bc0: ret             
    // 0x5b8bc4: r0 = StateError()
    //     0x5b8bc4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x5b8bc8: mov             x1, x0
    // 0x5b8bcc: r0 = "No element"
    //     0x5b8bcc: ldr             x0, [PP, #0x10b8]  ; [pp+0x10b8] "No element"
    // 0x5b8bd0: StoreField: r1->field_b = r0
    //     0x5b8bd0: stur            w0, [x1, #0xb]
    // 0x5b8bd4: mov             x0, x1
    // 0x5b8bd8: r0 = Throw()
    //     0x5b8bd8: bl              #0xd67e38  ; ThrowStub
    // 0x5b8bdc: brk             #0
    // 0x5b8be0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b8be0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ add(/* No info */) {
    // ** addr: 0x9bfd74, size: 0x84
    // 0x9bfd74: EnterFrame
    //     0x9bfd74: stp             fp, lr, [SP, #-0x10]!
    //     0x9bfd78: mov             fp, SP
    // 0x9bfd7c: CheckStackOverflow
    //     0x9bfd7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bfd80: cmp             SP, x16
    //     0x9bfd84: b.ls            #0x9bfdf0
    // 0x9bfd88: ldr             x3, [fp, #0x18]
    // 0x9bfd8c: LoadField: r2 = r3->field_7
    //     0x9bfd8c: ldur            w2, [x3, #7]
    // 0x9bfd90: DecompressPointer r2
    //     0x9bfd90: add             x2, x2, HEAP, lsl #32
    // 0x9bfd94: ldr             x0, [fp, #0x10]
    // 0x9bfd98: r1 = Null
    //     0x9bfd98: mov             x1, NULL
    // 0x9bfd9c: cmp             w2, NULL
    // 0x9bfda0: b.eq            #0x9bfdc0
    // 0x9bfda4: LoadField: r4 = r2->field_17
    //     0x9bfda4: ldur            w4, [x2, #0x17]
    // 0x9bfda8: DecompressPointer r4
    //     0x9bfda8: add             x4, x4, HEAP, lsl #32
    // 0x9bfdac: r8 = X0
    //     0x9bfdac: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x9bfdb0: LoadField: r9 = r4->field_7
    //     0x9bfdb0: ldur            x9, [x4, #7]
    // 0x9bfdb4: r3 = Null
    //     0x9bfdb4: add             x3, PP, #0x4e, lsl #12  ; [pp+0x4e000] Null
    //     0x9bfdb8: ldr             x3, [x3]
    // 0x9bfdbc: blr             x9
    // 0x9bfdc0: ldr             x0, [fp, #0x18]
    // 0x9bfdc4: LoadField: r1 = r0->field_1b
    //     0x9bfdc4: ldur            x1, [x0, #0x1b]
    // 0x9bfdc8: add             x2, x1, #1
    // 0x9bfdcc: StoreField: r0->field_1b = r2
    //     0x9bfdcc: stur            x2, [x0, #0x1b]
    // 0x9bfdd0: ldr             x16, [fp, #0x10]
    // 0x9bfdd4: stp             x16, x0, [SP, #-0x10]!
    // 0x9bfdd8: r0 = _add()
    //     0x9bfdd8: bl              #0x9bfdf8  ; [package:collection/src/priority_queue.dart] HeapPriorityQueue::_add
    // 0x9bfddc: add             SP, SP, #0x10
    // 0x9bfde0: r0 = Null
    //     0x9bfde0: mov             x0, NULL
    // 0x9bfde4: LeaveFrame
    //     0x9bfde4: mov             SP, fp
    //     0x9bfde8: ldp             fp, lr, [SP], #0x10
    // 0x9bfdec: ret
    //     0x9bfdec: ret             
    // 0x9bfdf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bfdf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bfdf4: b               #0x9bfd88
  }
  _ _add(/* No info */) {
    // ** addr: 0x9bfdf8, size: 0x80
    // 0x9bfdf8: EnterFrame
    //     0x9bfdf8: stp             fp, lr, [SP, #-0x10]!
    //     0x9bfdfc: mov             fp, SP
    // 0x9bfe00: CheckStackOverflow
    //     0x9bfe00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bfe04: cmp             SP, x16
    //     0x9bfe08: b.ls            #0x9bfe70
    // 0x9bfe0c: ldr             x0, [fp, #0x18]
    // 0x9bfe10: LoadField: r1 = r0->field_13
    //     0x9bfe10: ldur            x1, [x0, #0x13]
    // 0x9bfe14: LoadField: r2 = r0->field_f
    //     0x9bfe14: ldur            w2, [x0, #0xf]
    // 0x9bfe18: DecompressPointer r2
    //     0x9bfe18: add             x2, x2, HEAP, lsl #32
    // 0x9bfe1c: LoadField: r3 = r2->field_b
    //     0x9bfe1c: ldur            w3, [x2, #0xb]
    // 0x9bfe20: DecompressPointer r3
    //     0x9bfe20: add             x3, x3, HEAP, lsl #32
    // 0x9bfe24: r2 = LoadInt32Instr(r3)
    //     0x9bfe24: sbfx            x2, x3, #1, #0x1f
    // 0x9bfe28: cmp             x1, x2
    // 0x9bfe2c: b.ne            #0x9bfe3c
    // 0x9bfe30: SaveReg r0
    //     0x9bfe30: str             x0, [SP, #-8]!
    // 0x9bfe34: r0 = _grow()
    //     0x9bfe34: bl              #0x9c0114  ; [package:collection/src/priority_queue.dart] HeapPriorityQueue::_grow
    // 0x9bfe38: add             SP, SP, #8
    // 0x9bfe3c: ldr             x0, [fp, #0x18]
    // 0x9bfe40: LoadField: r1 = r0->field_13
    //     0x9bfe40: ldur            x1, [x0, #0x13]
    // 0x9bfe44: add             x2, x1, #1
    // 0x9bfe48: StoreField: r0->field_13 = r2
    //     0x9bfe48: stur            x2, [x0, #0x13]
    // 0x9bfe4c: ldr             x16, [fp, #0x10]
    // 0x9bfe50: stp             x16, x0, [SP, #-0x10]!
    // 0x9bfe54: SaveReg r1
    //     0x9bfe54: str             x1, [SP, #-8]!
    // 0x9bfe58: r0 = _bubbleUp()
    //     0x9bfe58: bl              #0x9bfe78  ; [package:collection/src/priority_queue.dart] HeapPriorityQueue::_bubbleUp
    // 0x9bfe5c: add             SP, SP, #0x18
    // 0x9bfe60: r0 = Null
    //     0x9bfe60: mov             x0, NULL
    // 0x9bfe64: LeaveFrame
    //     0x9bfe64: mov             SP, fp
    //     0x9bfe68: ldp             fp, lr, [SP], #0x10
    // 0x9bfe6c: ret
    //     0x9bfe6c: ret             
    // 0x9bfe70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bfe70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bfe74: b               #0x9bfe0c
  }
  _ _bubbleUp(/* No info */) {
    // ** addr: 0x9bfe78, size: 0x29c
    // 0x9bfe78: EnterFrame
    //     0x9bfe78: stp             fp, lr, [SP, #-0x10]!
    //     0x9bfe7c: mov             fp, SP
    // 0x9bfe80: AllocStack(0x30)
    //     0x9bfe80: sub             SP, SP, #0x30
    // 0x9bfe84: CheckStackOverflow
    //     0x9bfe84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bfe88: cmp             SP, x16
    //     0x9bfe8c: b.ls            #0x9c00f4
    // 0x9bfe90: ldr             x3, [fp, #0x20]
    // 0x9bfe94: LoadField: r4 = r3->field_b
    //     0x9bfe94: ldur            w4, [x3, #0xb]
    // 0x9bfe98: DecompressPointer r4
    //     0x9bfe98: add             x4, x4, HEAP, lsl #32
    // 0x9bfe9c: stur            x4, [fp, #-0x20]
    // 0x9bfea0: LoadField: r5 = r3->field_7
    //     0x9bfea0: ldur            w5, [x3, #7]
    // 0x9bfea4: DecompressPointer r5
    //     0x9bfea4: add             x5, x5, HEAP, lsl #32
    // 0x9bfea8: ldr             x0, [fp, #0x10]
    // 0x9bfeac: stur            x5, [fp, #-0x18]
    // 0x9bfeb0: mov             x7, x0
    // 0x9bfeb4: r6 = 2
    //     0x9bfeb4: mov             x6, #2
    // 0x9bfeb8: stur            x7, [fp, #-0x10]
    // 0x9bfebc: CheckStackOverflow
    //     0x9bfebc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bfec0: cmp             SP, x16
    //     0x9bfec4: b.ls            #0x9c00fc
    // 0x9bfec8: cmp             x7, #0
    // 0x9bfecc: b.le            #0x9c004c
    // 0x9bfed0: sub             x0, x7, #1
    // 0x9bfed4: sdiv            x8, x0, x6
    // 0x9bfed8: stur            x8, [fp, #-8]
    // 0x9bfedc: LoadField: r2 = r3->field_f
    //     0x9bfedc: ldur            w2, [x3, #0xf]
    // 0x9bfee0: DecompressPointer r2
    //     0x9bfee0: add             x2, x2, HEAP, lsl #32
    // 0x9bfee4: LoadField: r0 = r2->field_b
    //     0x9bfee4: ldur            w0, [x2, #0xb]
    // 0x9bfee8: DecompressPointer r0
    //     0x9bfee8: add             x0, x0, HEAP, lsl #32
    // 0x9bfeec: r1 = LoadInt32Instr(r0)
    //     0x9bfeec: sbfx            x1, x0, #1, #0x1f
    // 0x9bfef0: mov             x0, x1
    // 0x9bfef4: mov             x1, x8
    // 0x9bfef8: cmp             x1, x0
    // 0x9bfefc: b.hs            #0x9c0104
    // 0x9bff00: ArrayLoad: r0 = r2[r8]  ; Unknown_4
    //     0x9bff00: add             x16, x2, x8, lsl #2
    //     0x9bff04: ldur            w0, [x16, #0xf]
    // 0x9bff08: DecompressPointer r0
    //     0x9bff08: add             x0, x0, HEAP, lsl #32
    // 0x9bff0c: cmp             w0, NULL
    // 0x9bff10: b.ne            #0x9bff4c
    // 0x9bff14: mov             x2, x5
    // 0x9bff18: r0 = Null
    //     0x9bff18: mov             x0, NULL
    // 0x9bff1c: r1 = Null
    //     0x9bff1c: mov             x1, NULL
    // 0x9bff20: cmp             w2, NULL
    // 0x9bff24: b.eq            #0x9bff44
    // 0x9bff28: LoadField: r4 = r2->field_17
    //     0x9bff28: ldur            w4, [x2, #0x17]
    // 0x9bff2c: DecompressPointer r4
    //     0x9bff2c: add             x4, x4, HEAP, lsl #32
    // 0x9bff30: r8 = X0
    //     0x9bff30: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x9bff34: LoadField: r9 = r4->field_7
    //     0x9bff34: ldur            x9, [x4, #7]
    // 0x9bff38: r3 = Null
    //     0x9bff38: add             x3, PP, #0x4e, lsl #12  ; [pp+0x4e010] Null
    //     0x9bff3c: ldr             x3, [x3, #0x10]
    // 0x9bff40: blr             x9
    // 0x9bff44: r1 = Null
    //     0x9bff44: mov             x1, NULL
    // 0x9bff48: b               #0x9bff50
    // 0x9bff4c: mov             x1, x0
    // 0x9bff50: stur            x1, [fp, #-0x28]
    // 0x9bff54: ldur            x16, [fp, #-0x20]
    // 0x9bff58: ldr             lr, [fp, #0x18]
    // 0x9bff5c: stp             lr, x16, [SP, #-0x10]!
    // 0x9bff60: SaveReg r1
    //     0x9bff60: str             x1, [SP, #-8]!
    // 0x9bff64: ldur            x0, [fp, #-0x20]
    // 0x9bff68: ClosureCall
    //     0x9bff68: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x9bff6c: ldur            x2, [x0, #0x1f]
    //     0x9bff70: blr             x2
    // 0x9bff74: add             SP, SP, #0x18
    // 0x9bff78: cmp             w0, NULL
    // 0x9bff7c: b.eq            #0x9c0108
    // 0x9bff80: r1 = LoadInt32Instr(r0)
    //     0x9bff80: sbfx            x1, x0, #1, #0x1f
    //     0x9bff84: tbz             w0, #0, #0x9bff8c
    //     0x9bff88: ldur            x1, [x0, #7]
    // 0x9bff8c: cmp             x1, #0
    // 0x9bff90: b.le            #0x9bff9c
    // 0x9bff94: ldur            x3, [fp, #-0x10]
    // 0x9bff98: b               #0x9c0050
    // 0x9bff9c: ldr             x3, [fp, #0x20]
    // 0x9bffa0: ldur            x4, [fp, #-0x10]
    // 0x9bffa4: LoadField: r5 = r3->field_f
    //     0x9bffa4: ldur            w5, [x3, #0xf]
    // 0x9bffa8: DecompressPointer r5
    //     0x9bffa8: add             x5, x5, HEAP, lsl #32
    // 0x9bffac: stur            x5, [fp, #-0x30]
    // 0x9bffb0: LoadField: r2 = r5->field_7
    //     0x9bffb0: ldur            w2, [x5, #7]
    // 0x9bffb4: DecompressPointer r2
    //     0x9bffb4: add             x2, x2, HEAP, lsl #32
    // 0x9bffb8: ldur            x0, [fp, #-0x28]
    // 0x9bffbc: r1 = Null
    //     0x9bffbc: mov             x1, NULL
    // 0x9bffc0: cmp             w2, NULL
    // 0x9bffc4: b.eq            #0x9bffe4
    // 0x9bffc8: LoadField: r4 = r2->field_17
    //     0x9bffc8: ldur            w4, [x2, #0x17]
    // 0x9bffcc: DecompressPointer r4
    //     0x9bffcc: add             x4, x4, HEAP, lsl #32
    // 0x9bffd0: r8 = X0
    //     0x9bffd0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x9bffd4: LoadField: r9 = r4->field_7
    //     0x9bffd4: ldur            x9, [x4, #7]
    // 0x9bffd8: r3 = Null
    //     0x9bffd8: add             x3, PP, #0x4e, lsl #12  ; [pp+0x4e020] Null
    //     0x9bffdc: ldr             x3, [x3, #0x20]
    // 0x9bffe0: blr             x9
    // 0x9bffe4: ldur            x2, [fp, #-0x30]
    // 0x9bffe8: LoadField: r0 = r2->field_b
    //     0x9bffe8: ldur            w0, [x2, #0xb]
    // 0x9bffec: DecompressPointer r0
    //     0x9bffec: add             x0, x0, HEAP, lsl #32
    // 0x9bfff0: r1 = LoadInt32Instr(r0)
    //     0x9bfff0: sbfx            x1, x0, #1, #0x1f
    // 0x9bfff4: mov             x0, x1
    // 0x9bfff8: ldur            x1, [fp, #-0x10]
    // 0x9bfffc: cmp             x1, x0
    // 0x9c0000: b.hs            #0x9c010c
    // 0x9c0004: mov             x1, x2
    // 0x9c0008: ldur            x0, [fp, #-0x28]
    // 0x9c000c: ldur            x3, [fp, #-0x10]
    // 0x9c0010: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9c0010: add             x25, x1, x3, lsl #2
    //     0x9c0014: add             x25, x25, #0xf
    //     0x9c0018: str             w0, [x25]
    //     0x9c001c: tbz             w0, #0, #0x9c0038
    //     0x9c0020: ldurb           w16, [x1, #-1]
    //     0x9c0024: ldurb           w17, [x0, #-1]
    //     0x9c0028: and             x16, x17, x16, lsr #2
    //     0x9c002c: tst             x16, HEAP, lsr #32
    //     0x9c0030: b.eq            #0x9c0038
    //     0x9c0034: bl              #0xd67e5c
    // 0x9c0038: ldur            x7, [fp, #-8]
    // 0x9c003c: ldr             x3, [fp, #0x20]
    // 0x9c0040: ldur            x4, [fp, #-0x20]
    // 0x9c0044: ldur            x5, [fp, #-0x18]
    // 0x9c0048: b               #0x9bfeb4
    // 0x9c004c: mov             x3, x7
    // 0x9c0050: ldr             x0, [fp, #0x20]
    // 0x9c0054: LoadField: r4 = r0->field_f
    //     0x9c0054: ldur            w4, [x0, #0xf]
    // 0x9c0058: DecompressPointer r4
    //     0x9c0058: add             x4, x4, HEAP, lsl #32
    // 0x9c005c: stur            x4, [fp, #-0x18]
    // 0x9c0060: LoadField: r2 = r4->field_7
    //     0x9c0060: ldur            w2, [x4, #7]
    // 0x9c0064: DecompressPointer r2
    //     0x9c0064: add             x2, x2, HEAP, lsl #32
    // 0x9c0068: ldr             x0, [fp, #0x18]
    // 0x9c006c: r1 = Null
    //     0x9c006c: mov             x1, NULL
    // 0x9c0070: cmp             w2, NULL
    // 0x9c0074: b.eq            #0x9c0094
    // 0x9c0078: LoadField: r4 = r2->field_17
    //     0x9c0078: ldur            w4, [x2, #0x17]
    // 0x9c007c: DecompressPointer r4
    //     0x9c007c: add             x4, x4, HEAP, lsl #32
    // 0x9c0080: r8 = X0
    //     0x9c0080: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x9c0084: LoadField: r9 = r4->field_7
    //     0x9c0084: ldur            x9, [x4, #7]
    // 0x9c0088: r3 = Null
    //     0x9c0088: add             x3, PP, #0x4e, lsl #12  ; [pp+0x4e030] Null
    //     0x9c008c: ldr             x3, [x3, #0x30]
    // 0x9c0090: blr             x9
    // 0x9c0094: ldur            x2, [fp, #-0x18]
    // 0x9c0098: LoadField: r3 = r2->field_b
    //     0x9c0098: ldur            w3, [x2, #0xb]
    // 0x9c009c: DecompressPointer r3
    //     0x9c009c: add             x3, x3, HEAP, lsl #32
    // 0x9c00a0: r0 = LoadInt32Instr(r3)
    //     0x9c00a0: sbfx            x0, x3, #1, #0x1f
    // 0x9c00a4: ldur            x1, [fp, #-0x10]
    // 0x9c00a8: cmp             x1, x0
    // 0x9c00ac: b.hs            #0x9c0110
    // 0x9c00b0: mov             x1, x2
    // 0x9c00b4: ldr             x0, [fp, #0x18]
    // 0x9c00b8: ldur            x2, [fp, #-0x10]
    // 0x9c00bc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9c00bc: add             x25, x1, x2, lsl #2
    //     0x9c00c0: add             x25, x25, #0xf
    //     0x9c00c4: str             w0, [x25]
    //     0x9c00c8: tbz             w0, #0, #0x9c00e4
    //     0x9c00cc: ldurb           w16, [x1, #-1]
    //     0x9c00d0: ldurb           w17, [x0, #-1]
    //     0x9c00d4: and             x16, x17, x16, lsr #2
    //     0x9c00d8: tst             x16, HEAP, lsr #32
    //     0x9c00dc: b.eq            #0x9c00e4
    //     0x9c00e0: bl              #0xd67e5c
    // 0x9c00e4: r0 = Null
    //     0x9c00e4: mov             x0, NULL
    // 0x9c00e8: LeaveFrame
    //     0x9c00e8: mov             SP, fp
    //     0x9c00ec: ldp             fp, lr, [SP], #0x10
    // 0x9c00f0: ret
    //     0x9c00f0: ret             
    // 0x9c00f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c00f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c00f8: b               #0x9bfe90
    // 0x9c00fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c00fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c0100: b               #0x9bfec8
    // 0x9c0104: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9c0104: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9c0108: r0 = NullErrorSharedWithoutFPURegs()
    //     0x9c0108: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x9c010c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9c010c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9c0110: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9c0110: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _grow(/* No info */) {
    // ** addr: 0x9c0114, size: 0xf4
    // 0x9c0114: EnterFrame
    //     0x9c0114: stp             fp, lr, [SP, #-0x10]!
    //     0x9c0118: mov             fp, SP
    // 0x9c011c: AllocStack(0x18)
    //     0x9c011c: sub             SP, SP, #0x18
    // 0x9c0120: CheckStackOverflow
    //     0x9c0120: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9c0124: cmp             SP, x16
    //     0x9c0128: b.ls            #0x9c0200
    // 0x9c012c: ldr             x0, [fp, #0x10]
    // 0x9c0130: LoadField: r4 = r0->field_f
    //     0x9c0130: ldur            w4, [x0, #0xf]
    // 0x9c0134: DecompressPointer r4
    //     0x9c0134: add             x4, x4, HEAP, lsl #32
    // 0x9c0138: stur            x4, [fp, #-0x10]
    // 0x9c013c: LoadField: r1 = r4->field_b
    //     0x9c013c: ldur            w1, [x4, #0xb]
    // 0x9c0140: DecompressPointer r1
    //     0x9c0140: add             x1, x1, HEAP, lsl #32
    // 0x9c0144: r2 = LoadInt32Instr(r1)
    //     0x9c0144: sbfx            x2, x1, #1, #0x1f
    // 0x9c0148: lsl             x1, x2, #1
    // 0x9c014c: add             x2, x1, #1
    // 0x9c0150: cmp             x2, #7
    // 0x9c0154: b.ge            #0x9c0160
    // 0x9c0158: r5 = 7
    //     0x9c0158: mov             x5, #7
    // 0x9c015c: b               #0x9c0164
    // 0x9c0160: mov             x5, x2
    // 0x9c0164: stur            x5, [fp, #-8]
    // 0x9c0168: LoadField: r2 = r0->field_7
    //     0x9c0168: ldur            w2, [x0, #7]
    // 0x9c016c: DecompressPointer r2
    //     0x9c016c: add             x2, x2, HEAP, lsl #32
    // 0x9c0170: r1 = Null
    //     0x9c0170: mov             x1, NULL
    // 0x9c0174: r3 = <X0?>
    //     0x9c0174: ldr             x3, [PP, #0x1bd0]  ; [pp+0x1bd0] TypeArguments: <X0?>
    // 0x9c0178: r0 = Null
    //     0x9c0178: mov             x0, NULL
    // 0x9c017c: cmp             x2, x0
    // 0x9c0180: b.eq            #0x9c0190
    // 0x9c0184: r24 = InstantiateTypeArgumentsMayShareInstantiatorTAStub
    //     0x9c0184: ldr             x24, [PP, #0x1bd8]  ; [pp+0x1bd8] Stub: InstantiateTypeArgumentsMayShareInstantiatorTA (0x4aca90)
    // 0x9c0188: LoadField: r30 = r24->field_7
    //     0x9c0188: ldur            lr, [x24, #7]
    // 0x9c018c: blr             lr
    // 0x9c0190: mov             x1, x0
    // 0x9c0194: ldur            x0, [fp, #-8]
    // 0x9c0198: lsl             x2, x0, #1
    // 0x9c019c: ldr             x0, [fp, #0x10]
    // 0x9c01a0: LoadField: r3 = r0->field_13
    //     0x9c01a0: ldur            x3, [x0, #0x13]
    // 0x9c01a4: stur            x3, [fp, #-8]
    // 0x9c01a8: r0 = AllocateArray()
    //     0x9c01a8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9c01ac: stur            x0, [fp, #-0x18]
    // 0x9c01b0: stp             xzr, x0, [SP, #-0x10]!
    // 0x9c01b4: ldur            x1, [fp, #-8]
    // 0x9c01b8: ldur            x16, [fp, #-0x10]
    // 0x9c01bc: stp             x16, x1, [SP, #-0x10]!
    // 0x9c01c0: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x9c01c0: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x9c01c4: r0 = setRange()
    //     0x9c01c4: bl              #0x6084fc  ; [dart:core] _List::setRange
    // 0x9c01c8: add             SP, SP, #0x20
    // 0x9c01cc: ldur            x0, [fp, #-0x18]
    // 0x9c01d0: ldr             x1, [fp, #0x10]
    // 0x9c01d4: StoreField: r1->field_f = r0
    //     0x9c01d4: stur            w0, [x1, #0xf]
    //     0x9c01d8: ldurb           w16, [x1, #-1]
    //     0x9c01dc: ldurb           w17, [x0, #-1]
    //     0x9c01e0: and             x16, x17, x16, lsr #2
    //     0x9c01e4: tst             x16, HEAP, lsr #32
    //     0x9c01e8: b.eq            #0x9c01f0
    //     0x9c01ec: bl              #0xd6826c
    // 0x9c01f0: r0 = Null
    //     0x9c01f0: mov             x0, NULL
    // 0x9c01f4: LeaveFrame
    //     0x9c01f4: mov             SP, fp
    //     0x9c01f8: ldp             fp, lr, [SP], #0x10
    // 0x9c01fc: ret
    //     0x9c01fc: ret             
    // 0x9c0200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c0200: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c0204: b               #0x9c012c
  }
  _ toString(/* No info */) {
    // ** addr: 0xac4a80, size: 0x50
    // 0xac4a80: EnterFrame
    //     0xac4a80: stp             fp, lr, [SP, #-0x10]!
    //     0xac4a84: mov             fp, SP
    // 0xac4a88: CheckStackOverflow
    //     0xac4a88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xac4a8c: cmp             SP, x16
    //     0xac4a90: b.ls            #0xac4ac8
    // 0xac4a94: ldr             x0, [fp, #0x10]
    // 0xac4a98: LoadField: r1 = r0->field_f
    //     0xac4a98: ldur            w1, [x0, #0xf]
    // 0xac4a9c: DecompressPointer r1
    //     0xac4a9c: add             x1, x1, HEAP, lsl #32
    // 0xac4aa0: LoadField: r2 = r0->field_13
    //     0xac4aa0: ldur            x2, [x0, #0x13]
    // 0xac4aa4: stp             x2, x1, [SP, #-0x10]!
    // 0xac4aa8: r0 = take()
    //     0xac4aa8: bl              #0x622048  ; [dart:collection] _ListBase&Object&ListMixin::take
    // 0xac4aac: add             SP, SP, #0x10
    // 0xac4ab0: SaveReg r0
    //     0xac4ab0: str             x0, [SP, #-8]!
    // 0xac4ab4: r0 = iterableToShortString()
    //     0xac4ab4: bl              #0xab7e64  ; [dart:collection] IterableBase::iterableToShortString
    // 0xac4ab8: add             SP, SP, #8
    // 0xac4abc: LeaveFrame
    //     0xac4abc: mov             SP, fp
    //     0xac4ac0: ldp             fp, lr, [SP], #0x10
    // 0xac4ac4: ret
    //     0xac4ac4: ret             
    // 0xac4ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xac4ac8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xac4acc: b               #0xac4a94
  }
}

// class id: 4772, size: 0xc, field offset: 0x8
abstract class PriorityQueue<X0> extends Object {
}

// lib: , url: package:collection/src/list_extensions.dart

// class id: 1048766, size: 0x8
class :: {

  static _ ListExtensions.expandIndexed(/* No info */) {
    // ** addr: 0x98191c, size: 0x194
    // 0x98191c: EnterFrame
    //     0x98191c: stp             fp, lr, [SP, #-0x10]!
    //     0x981920: mov             fp, SP
    // 0x981924: AllocStack(0x28)
    //     0x981924: sub             SP, SP, #0x28
    // 0x981928: SetupParameters(dynamic _ /* r4, fp-0x18 */, dynamic _ /* r5, fp-0x10 */)
    //     0x981928: stur            NULL, [fp, #-8]
    //     0x98192c: mov             x0, #0
    //     0x981930: mov             x1, x4
    //     0x981934: add             x4, fp, w0, sxtw #2
    //     0x981938: ldr             x4, [x4, #0x18]
    //     0x98193c: stur            x4, [fp, #-0x18]
    //     0x981940: add             x5, fp, w0, sxtw #2
    //     0x981944: ldr             x5, [x5, #0x10]
    //     0x981948: stur            x5, [fp, #-0x10]
    //     0x98194c: ldur            w2, [x1, #0xf]
    //     0x981950: add             x2, x2, HEAP, lsl #32
    //     0x981954: cbnz            w2, #0x981960
    //     0x981958: mov             x1, NULL
    //     0x98195c: b               #0x981970
    //     0x981960: ldur            w2, [x1, #0x17]
    //     0x981964: add             x2, x2, HEAP, lsl #32
    //     0x981968: add             x1, fp, w2, sxtw #2
    //     0x98196c: ldr             x1, [x1, #0x10]
    // 0x981970: CheckStackOverflow
    //     0x981970: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x981974: cmp             SP, x16
    //     0x981978: b.ls            #0x981a9c
    // 0x98197c: r2 = Null
    //     0x98197c: mov             x2, NULL
    // 0x981980: r3 = <Y1>
    //     0x981980: ldr             x3, [PP, #0x50f0]  ; [pp+0x50f0] TypeArguments: <Y1>
    // 0x981984: r0 = Null
    //     0x981984: mov             x0, NULL
    // 0x981988: cmp             x2, x0
    // 0x98198c: b.ne            #0x981998
    // 0x981990: cmp             x1, x0
    // 0x981994: b.eq            #0x9819a4
    // 0x981998: r24 = InstantiateTypeArgumentsStub
    //     0x981998: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x98199c: LoadField: r30 = r24->field_7
    //     0x98199c: ldur            lr, [x24, #7]
    // 0x9819a0: blr             lr
    // 0x9819a4: mov             x1, x0
    // 0x9819a8: stur            x1, [fp, #-0x20]
    // 0x9819ac: r0 = InitAsync()
    //     0x9819ac: bl              #0x505ad0  ; InitAsyncStub
    // 0x9819b0: r0 = Null
    //     0x9819b0: mov             x0, NULL
    // 0x9819b4: r0 = SuspendSyncStarAtStart()
    //     0x9819b4: bl              #0x505954  ; SuspendSyncStarAtStartStub
    // 0x9819b8: r4 = 0
    //     0x9819b8: mov             x4, #0
    // 0x9819bc: ldur            x3, [fp, #-0x18]
    // 0x9819c0: r2 = 0
    //     0x9819c0: mov             x2, #0
    // 0x9819c4: stur            x4, [fp, #-0x28]
    // 0x9819c8: CheckStackOverflow
    //     0x9819c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9819cc: cmp             SP, x16
    //     0x9819d0: b.ls            #0x981aa4
    // 0x9819d4: LoadField: r0 = r3->field_b
    //     0x9819d4: ldur            w0, [x3, #0xb]
    // 0x9819d8: DecompressPointer r0
    //     0x9819d8: add             x0, x0, HEAP, lsl #32
    // 0x9819dc: r1 = LoadInt32Instr(r0)
    //     0x9819dc: sbfx            x1, x0, #1, #0x1f
    // 0x9819e0: cmp             x4, x1
    // 0x9819e4: b.ge            #0x981a8c
    // 0x9819e8: add             x0, fp, w2, sxtw #2
    // 0x9819ec: LoadField: r0 = r0->field_fffffff8
    //     0x9819ec: ldur            x0, [x0, #-8]
    // 0x9819f0: LoadField: r5 = r0->field_17
    //     0x9819f0: ldur            w5, [x0, #0x17]
    // 0x9819f4: DecompressPointer r5
    //     0x9819f4: add             x5, x5, HEAP, lsl #32
    // 0x9819f8: mov             x0, x1
    // 0x9819fc: mov             x1, x4
    // 0x981a00: stur            x5, [fp, #-0x20]
    // 0x981a04: cmp             x1, x0
    // 0x981a08: b.hs            #0x981aac
    // 0x981a0c: LoadField: r6 = r3->field_f
    //     0x981a0c: ldur            w6, [x3, #0xf]
    // 0x981a10: DecompressPointer r6
    //     0x981a10: add             x6, x6, HEAP, lsl #32
    // 0x981a14: r0 = BoxInt64Instr(r4)
    //     0x981a14: sbfiz           x0, x4, #1, #0x1f
    //     0x981a18: cmp             x4, x0, asr #1
    //     0x981a1c: b.eq            #0x981a28
    //     0x981a20: bl              #0xd69bb8
    //     0x981a24: stur            x4, [x0, #7]
    // 0x981a28: ArrayLoad: r1 = r6[r4]  ; Unknown_4
    //     0x981a28: add             x16, x6, x4, lsl #2
    //     0x981a2c: ldur            w1, [x16, #0xf]
    // 0x981a30: DecompressPointer r1
    //     0x981a30: add             x1, x1, HEAP, lsl #32
    // 0x981a34: ldur            x16, [fp, #-0x10]
    // 0x981a38: stp             x0, x16, [SP, #-0x10]!
    // 0x981a3c: SaveReg r1
    //     0x981a3c: str             x1, [SP, #-8]!
    // 0x981a40: ldur            x0, [fp, #-0x10]
    // 0x981a44: ClosureCall
    //     0x981a44: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x981a48: ldur            x2, [x0, #0x1f]
    //     0x981a4c: blr             x2
    // 0x981a50: add             SP, SP, #0x18
    // 0x981a54: ldur            x1, [fp, #-0x20]
    // 0x981a58: StoreField: r1->field_1b = r0
    //     0x981a58: stur            w0, [x1, #0x1b]
    //     0x981a5c: tbz             w0, #0, #0x981a78
    //     0x981a60: ldurb           w16, [x1, #-1]
    //     0x981a64: ldurb           w17, [x0, #-1]
    //     0x981a68: and             x16, x17, x16, lsr #2
    //     0x981a6c: tst             x16, HEAP, lsr #32
    //     0x981a70: b.eq            #0x981a78
    //     0x981a74: bl              #0xd6826c
    // 0x981a78: r0 = true
    //     0x981a78: add             x0, NULL, #0x20  ; true
    // 0x981a7c: r0 = SuspendSyncStarAtYield()
    //     0x981a7c: bl              #0x5057dc  ; SuspendSyncStarAtYieldStub
    // 0x981a80: ldur            x1, [fp, #-0x28]
    // 0x981a84: add             x4, x1, #1
    // 0x981a88: b               #0x9819bc
    // 0x981a8c: r0 = false
    //     0x981a8c: add             x0, NULL, #0x30  ; false
    // 0x981a90: LeaveFrame
    //     0x981a90: mov             SP, fp
    //     0x981a94: ldp             fp, lr, [SP], #0x10
    // 0x981a98: ret
    //     0x981a98: ret             
    // 0x981a9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x981a9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x981aa0: b               #0x98197c
    // 0x981aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x981aa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x981aa8: b               #0x9819d4
    // 0x981aac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x981aac: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ ListExtensions.forEachIndexed(/* No info */) {
    // ** addr: 0xb5951c, size: 0xcc
    // 0xb5951c: EnterFrame
    //     0xb5951c: stp             fp, lr, [SP, #-0x10]!
    //     0xb59520: mov             fp, SP
    // 0xb59524: AllocStack(0x8)
    //     0xb59524: sub             SP, SP, #8
    // 0xb59528: CheckStackOverflow
    //     0xb59528: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb5952c: cmp             SP, x16
    //     0xb59530: b.ls            #0xb595d4
    // 0xb59534: r3 = 0
    //     0xb59534: mov             x3, #0
    // 0xb59538: ldr             x2, [fp, #0x18]
    // 0xb5953c: stur            x3, [fp, #-8]
    // 0xb59540: CheckStackOverflow
    //     0xb59540: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb59544: cmp             SP, x16
    //     0xb59548: b.ls            #0xb595dc
    // 0xb5954c: LoadField: r0 = r2->field_b
    //     0xb5954c: ldur            w0, [x2, #0xb]
    // 0xb59550: DecompressPointer r0
    //     0xb59550: add             x0, x0, HEAP, lsl #32
    // 0xb59554: r1 = LoadInt32Instr(r0)
    //     0xb59554: sbfx            x1, x0, #1, #0x1f
    // 0xb59558: cmp             x3, x1
    // 0xb5955c: b.ge            #0xb595c4
    // 0xb59560: mov             x0, x1
    // 0xb59564: mov             x1, x3
    // 0xb59568: cmp             x1, x0
    // 0xb5956c: b.hs            #0xb595e4
    // 0xb59570: LoadField: r4 = r2->field_f
    //     0xb59570: ldur            w4, [x2, #0xf]
    // 0xb59574: DecompressPointer r4
    //     0xb59574: add             x4, x4, HEAP, lsl #32
    // 0xb59578: r0 = BoxInt64Instr(r3)
    //     0xb59578: sbfiz           x0, x3, #1, #0x1f
    //     0xb5957c: cmp             x3, x0, asr #1
    //     0xb59580: b.eq            #0xb5958c
    //     0xb59584: bl              #0xd69bb8
    //     0xb59588: stur            x3, [x0, #7]
    // 0xb5958c: ArrayLoad: r1 = r4[r3]  ; Unknown_4
    //     0xb5958c: add             x16, x4, x3, lsl #2
    //     0xb59590: ldur            w1, [x16, #0xf]
    // 0xb59594: DecompressPointer r1
    //     0xb59594: add             x1, x1, HEAP, lsl #32
    // 0xb59598: ldr             x16, [fp, #0x10]
    // 0xb5959c: stp             x0, x16, [SP, #-0x10]!
    // 0xb595a0: SaveReg r1
    //     0xb595a0: str             x1, [SP, #-8]!
    // 0xb595a4: ldr             x0, [fp, #0x10]
    // 0xb595a8: ClosureCall
    //     0xb595a8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb595ac: ldur            x2, [x0, #0x1f]
    //     0xb595b0: blr             x2
    // 0xb595b4: add             SP, SP, #0x18
    // 0xb595b8: ldur            x1, [fp, #-8]
    // 0xb595bc: add             x3, x1, #1
    // 0xb595c0: b               #0xb59538
    // 0xb595c4: r0 = Null
    //     0xb595c4: mov             x0, NULL
    // 0xb595c8: LeaveFrame
    //     0xb595c8: mov             SP, fp
    //     0xb595cc: ldp             fp, lr, [SP], #0x10
    // 0xb595d0: ret
    //     0xb595d0: ret             
    // 0xb595d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb595d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb595d8: b               #0xb59534
    // 0xb595dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb595dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb595e0: b               #0xb5954c
    // 0xb595e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb595e4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

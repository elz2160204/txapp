// lib: , url: package:collection/src/boollist.dart

// class id: 1048752, size: 0x8
class :: {
}

// class id: 4785, size: 0x8, field offset: 0x8
//   const constructor, transformed mixin,
abstract class _BoolList&Object&ListMixin extends Object
     with ListMixin<X0> {

  bool isEmpty(_BoolList&Object&ListMixin) {
    // ** addr: 0xc212a4, size: 0x34
    // 0xc212a4: ldr             x1, [SP]
    // 0xc212a8: LoadField: r2 = r1->field_b
    //     0xc212a8: ldur            x2, [x1, #0xb]
    // 0xc212ac: cbz             x2, #0xc212b8
    // 0xc212b0: r0 = false
    //     0xc212b0: add             x0, NULL, #0x30  ; false
    // 0xc212b4: b               #0xc212bc
    // 0xc212b8: r0 = true
    //     0xc212b8: add             x0, NULL, #0x20  ; true
    // 0xc212bc: ret
    //     0xc212bc: ret             
  }
  bool isNotEmpty(_BoolList&Object&ListMixin) {
    // ** addr: 0xc03478, size: 0x34
    // 0xc03478: ldr             x1, [SP]
    // 0xc0347c: LoadField: r2 = r1->field_b
    //     0xc0347c: ldur            x2, [x1, #0xb]
    // 0xc03480: cbnz            x2, #0xc0348c
    // 0xc03484: r0 = false
    //     0xc03484: add             x0, NULL, #0x30  ; false
    // 0xc03488: b               #0xc03490
    // 0xc0348c: r0 = true
    //     0xc0348c: add             x0, NULL, #0x20  ; true
    // 0xc03490: ret
    //     0xc03490: ret             
  }
  List<Y0> cast<Y0>(_BoolList&Object&ListMixin) {
    // ** addr: 0x6b0ddc, size: 0x80
    // 0x6b0ddc: EnterFrame
    //     0x6b0ddc: stp             fp, lr, [SP, #-0x10]!
    //     0x6b0de0: mov             fp, SP
    // 0x6b0de4: mov             x0, x4
    // 0x6b0de8: LoadField: r1 = r0->field_f
    //     0x6b0de8: ldur            w1, [x0, #0xf]
    // 0x6b0dec: DecompressPointer r1
    //     0x6b0dec: add             x1, x1, HEAP, lsl #32
    // 0x6b0df0: cbnz            w1, #0x6b0dfc
    // 0x6b0df4: r1 = Null
    //     0x6b0df4: mov             x1, NULL
    // 0x6b0df8: b               #0x6b0e10
    // 0x6b0dfc: LoadField: r1 = r0->field_17
    //     0x6b0dfc: ldur            w1, [x0, #0x17]
    // 0x6b0e00: DecompressPointer r1
    //     0x6b0e00: add             x1, x1, HEAP, lsl #32
    // 0x6b0e04: add             x0, fp, w1, sxtw #2
    // 0x6b0e08: ldr             x0, [x0, #0x10]
    // 0x6b0e0c: mov             x1, x0
    // 0x6b0e10: CheckStackOverflow
    //     0x6b0e10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b0e14: cmp             SP, x16
    //     0x6b0e18: b.ls            #0x6b0e54
    // 0x6b0e1c: r2 = Null
    //     0x6b0e1c: mov             x2, NULL
    // 0x6b0e20: r3 = <bool, Y0>
    //     0x6b0e20: add             x3, PP, #0x41, lsl #12  ; [pp+0x41390] TypeArguments: <bool, Y0>
    //     0x6b0e24: ldr             x3, [x3, #0x390]
    // 0x6b0e28: r24 = InstantiateTypeArgumentsStub
    //     0x6b0e28: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x6b0e2c: LoadField: r30 = r24->field_7
    //     0x6b0e2c: ldur            lr, [x24, #7]
    // 0x6b0e30: blr             lr
    // 0x6b0e34: ldr             x16, [fp, #0x10]
    // 0x6b0e38: stp             x16, x0, [SP, #-0x10]!
    // 0x6b0e3c: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x6b0e3c: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x6b0e40: r0 = castFrom()
    //     0x6b0e40: bl              #0x6a7010  ; [dart:core] List::castFrom
    // 0x6b0e44: add             SP, SP, #0x10
    // 0x6b0e48: LeaveFrame
    //     0x6b0e48: mov             SP, fp
    //     0x6b0e4c: ldp             fp, lr, [SP], #0x10
    // 0x6b0e50: ret
    //     0x6b0e50: ret             
    // 0x6b0e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b0e54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b0e58: b               #0x6b0e1c
  }
  List<bool> +(_BoolList&Object&ListMixin, List<bool>) {
    // ** addr: 0x4c4838, size: 0x74
    // 0x4c4838: EnterFrame
    //     0x4c4838: stp             fp, lr, [SP, #-0x10]!
    //     0x4c483c: mov             fp, SP
    // 0x4c4840: CheckStackOverflow
    //     0x4c4840: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c4844: cmp             SP, x16
    //     0x4c4848: b.ls            #0x4c488c
    // 0x4c484c: ldr             x0, [fp, #0x10]
    // 0x4c4850: r2 = Null
    //     0x4c4850: mov             x2, NULL
    // 0x4c4854: r1 = Null
    //     0x4c4854: mov             x1, NULL
    // 0x4c4858: r8 = List<bool>
    //     0x4c4858: add             x8, PP, #0x41, lsl #12  ; [pp+0x41378] Type: List<bool>
    //     0x4c485c: ldr             x8, [x8, #0x378]
    // 0x4c4860: r3 = Null
    //     0x4c4860: add             x3, PP, #0x41, lsl #12  ; [pp+0x41380] Null
    //     0x4c4864: ldr             x3, [x3, #0x380]
    // 0x4c4868: r0 = List<bool>()
    //     0x4c4868: bl              #0x4c4894  ; IsType_List<bool>_Stub
    // 0x4c486c: r16 = <bool>
    //     0x4c486c: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x4c4870: ldr             lr, [fp, #0x18]
    // 0x4c4874: stp             lr, x16, [SP, #-0x10]!
    // 0x4c4878: r0 = _GrowableList.of()
    //     0x4c4878: bl              #0x4bfaf0  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x4c487c: add             SP, SP, #0x10
    // 0x4c4880: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x4c4880: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x4c4884: r0 = Throw()
    //     0x4c4884: bl              #0xd67e38  ; ThrowStub
    // 0x4c4888: brk             #0
    // 0x4c488c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c488c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c4890: b               #0x4c484c
  }
  _ getRange(/* No info */) {
    // ** addr: 0x4c44d4, size: 0xa8
    // 0x4c44d4: EnterFrame
    //     0x4c44d4: stp             fp, lr, [SP, #-0x10]!
    //     0x4c44d8: mov             fp, SP
    // 0x4c44dc: AllocStack(0x18)
    //     0x4c44dc: sub             SP, SP, #0x18
    // 0x4c44e0: CheckStackOverflow
    //     0x4c44e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c44e4: cmp             SP, x16
    //     0x4c44e8: b.ls            #0x4c4574
    // 0x4c44ec: ldr             x2, [fp, #0x20]
    // 0x4c44f0: LoadField: r3 = r2->field_b
    //     0x4c44f0: ldur            x3, [x2, #0xb]
    // 0x4c44f4: ldr             x4, [fp, #0x10]
    // 0x4c44f8: r0 = BoxInt64Instr(r4)
    //     0x4c44f8: sbfiz           x0, x4, #1, #0x1f
    //     0x4c44fc: cmp             x4, x0, asr #1
    //     0x4c4500: b.eq            #0x4c450c
    //     0x4c4504: bl              #0xd69bb8
    //     0x4c4508: stur            x4, [x0, #7]
    // 0x4c450c: stur            x0, [fp, #-8]
    // 0x4c4510: ldr             x16, [fp, #0x18]
    // 0x4c4514: stp             x0, x16, [SP, #-0x10]!
    // 0x4c4518: SaveReg r3
    //     0x4c4518: str             x3, [SP, #-8]!
    // 0x4c451c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x4c451c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x4c4520: r0 = checkValidRange()
    //     0x4c4520: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0x4c4524: add             SP, SP, #0x18
    // 0x4c4528: ldr             x0, [fp, #0x18]
    // 0x4c452c: r2 = LoadInt32Instr(r0)
    //     0x4c452c: sbfx            x2, x0, #1, #0x1f
    //     0x4c4530: tbz             w0, #0, #0x4c4538
    //     0x4c4534: ldur            x2, [x0, #7]
    // 0x4c4538: stur            x2, [fp, #-0x10]
    // 0x4c453c: r1 = <bool>
    //     0x4c453c: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x4c4540: r0 = SubListIterable()
    //     0x4c4540: bl              #0x4c2748  ; AllocateSubListIterableStub -> SubListIterable<X0> (size=0x1c)
    // 0x4c4544: stur            x0, [fp, #-0x18]
    // 0x4c4548: ldr             x16, [fp, #0x20]
    // 0x4c454c: stp             x16, x0, [SP, #-0x10]!
    // 0x4c4550: ldur            x1, [fp, #-0x10]
    // 0x4c4554: ldur            x16, [fp, #-8]
    // 0x4c4558: stp             x16, x1, [SP, #-0x10]!
    // 0x4c455c: r0 = SubListIterable()
    //     0x4c455c: bl              #0x4c25b4  ; [dart:_internal] SubListIterable::SubListIterable
    // 0x4c4560: add             SP, SP, #0x20
    // 0x4c4564: ldur            x0, [fp, #-0x18]
    // 0x4c4568: LeaveFrame
    //     0x4c4568: mov             SP, fp
    //     0x4c456c: ldp             fp, lr, [SP], #0x10
    // 0x4c4570: ret
    //     0x4c4570: ret             
    // 0x4c4574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c4574: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c4578: b               #0x4c44ec
  }
  Iterable<Y0> map<Y0>(_BoolList&Object&ListMixin, (dynamic, bool) => Y0) {
    // ** addr: 0x4c470c, size: 0xa0
    // 0x4c470c: EnterFrame
    //     0x4c470c: stp             fp, lr, [SP, #-0x10]!
    //     0x4c4710: mov             fp, SP
    // 0x4c4714: AllocStack(0x8)
    //     0x4c4714: sub             SP, SP, #8
    // 0x4c4718: SetupParameters()
    //     0x4c4718: mov             x0, x4
    //     0x4c471c: ldur            w1, [x0, #0xf]
    //     0x4c4720: add             x1, x1, HEAP, lsl #32
    //     0x4c4724: cbnz            w1, #0x4c4730
    //     0x4c4728: mov             x3, NULL
    //     0x4c472c: b               #0x4c4744
    //     0x4c4730: ldur            w1, [x0, #0x17]
    //     0x4c4734: add             x1, x1, HEAP, lsl #32
    //     0x4c4738: add             x0, fp, w1, sxtw #2
    //     0x4c473c: ldr             x0, [x0, #0x10]
    //     0x4c4740: mov             x3, x0
    //     0x4c4744: stur            x3, [fp, #-8]
    // 0x4c4748: CheckStackOverflow
    //     0x4c4748: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c474c: cmp             SP, x16
    //     0x4c4750: b.ls            #0x4c47a4
    // 0x4c4754: ldr             x0, [fp, #0x10]
    // 0x4c4758: mov             x1, x3
    // 0x4c475c: r2 = Null
    //     0x4c475c: mov             x2, NULL
    // 0x4c4760: r8 = (dynamic this, bool) => Y0
    //     0x4c4760: add             x8, PP, #0x41, lsl #12  ; [pp+0x413b8] FunctionType: (dynamic this, bool) => Y0
    //     0x4c4764: ldr             x8, [x8, #0x3b8]
    // 0x4c4768: LoadField: r9 = r8->field_7
    //     0x4c4768: ldur            x9, [x8, #7]
    // 0x4c476c: r3 = Null
    //     0x4c476c: add             x3, PP, #0x41, lsl #12  ; [pp+0x413c0] Null
    //     0x4c4770: ldr             x3, [x3, #0x3c0]
    // 0x4c4774: blr             x9
    // 0x4c4778: ldur            x16, [fp, #-8]
    // 0x4c477c: ldr             lr, [fp, #0x18]
    // 0x4c4780: stp             lr, x16, [SP, #-0x10]!
    // 0x4c4784: ldr             x16, [fp, #0x10]
    // 0x4c4788: SaveReg r16
    //     0x4c4788: str             x16, [SP, #-8]!
    // 0x4c478c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x4c478c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x4c4790: r0 = map()
    //     0x4c4790: bl              #0x6c0788  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::map
    // 0x4c4794: add             SP, SP, #0x18
    // 0x4c4798: LeaveFrame
    //     0x4c4798: mov             SP, fp
    //     0x4c479c: ldp             fp, lr, [SP], #0x10
    // 0x4c47a0: ret
    //     0x4c47a0: ret             
    // 0x4c47a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c47a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c47a8: b               #0x4c4754
  }
  void forEach(_BoolList&Object&ListMixin, (dynamic, bool) => void) {
    // ** addr: 0x4c47c4, size: 0x74
    // 0x4c47c4: EnterFrame
    //     0x4c47c4: stp             fp, lr, [SP, #-0x10]!
    //     0x4c47c8: mov             fp, SP
    // 0x4c47cc: CheckStackOverflow
    //     0x4c47cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c47d0: cmp             SP, x16
    //     0x4c47d4: b.ls            #0x4c4818
    // 0x4c47d8: ldr             x0, [fp, #0x10]
    // 0x4c47dc: r2 = Null
    //     0x4c47dc: mov             x2, NULL
    // 0x4c47e0: r1 = Null
    //     0x4c47e0: mov             x1, NULL
    // 0x4c47e4: r8 = (dynamic this, bool) => void?
    //     0x4c47e4: add             x8, PP, #0x41, lsl #12  ; [pp+0x413d8] FunctionType: (dynamic this, bool) => void?
    //     0x4c47e8: ldr             x8, [x8, #0x3d8]
    // 0x4c47ec: r3 = Null
    //     0x4c47ec: add             x3, PP, #0x41, lsl #12  ; [pp+0x413e0] Null
    //     0x4c47f0: ldr             x3, [x3, #0x3e0]
    // 0x4c47f4: r0 = DefaultTypeTest()
    //     0x4c47f4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x4c47f8: ldr             x16, [fp, #0x18]
    // 0x4c47fc: ldr             lr, [fp, #0x10]
    // 0x4c4800: stp             lr, x16, [SP, #-0x10]!
    // 0x4c4804: r0 = forEach()
    //     0x4c4804: bl              #0x6ba174  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::forEach
    // 0x4c4808: add             SP, SP, #0x10
    // 0x4c480c: LeaveFrame
    //     0x4c480c: mov             SP, fp
    //     0x4c4810: ldp             fp, lr, [SP], #0x10
    // 0x4c4814: ret
    //     0x4c4814: ret             
    // 0x4c4818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c4818: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c481c: b               #0x4c47d8
  }
  _ asMap(/* No info */) {
    // ** addr: 0x4c4b40, size: 0x28
    // 0x4c4b40: EnterFrame
    //     0x4c4b40: stp             fp, lr, [SP, #-0x10]!
    //     0x4c4b44: mov             fp, SP
    // 0x4c4b48: r1 = <int, bool>
    //     0x4c4b48: add             x1, PP, #0x55, lsl #12  ; [pp+0x55cb0] TypeArguments: <int, bool>
    //     0x4c4b4c: ldr             x1, [x1, #0xcb0]
    // 0x4c4b50: r0 = ListMapView()
    //     0x4c4b50: bl              #0x4c0978  ; AllocateListMapViewStub -> ListMapView<int> (size=0x10)
    // 0x4c4b54: ldr             x1, [fp, #0x10]
    // 0x4c4b58: StoreField: r0->field_b = r1
    //     0x4c4b58: stur            w1, [x0, #0xb]
    // 0x4c4b5c: LeaveFrame
    //     0x4c4b5c: mov             SP, fp
    //     0x4c4b60: ldp             fp, lr, [SP], #0x10
    // 0x4c4b64: ret
    //     0x4c4b64: ret             
  }
  dynamic remove(dynamic) {
    // ** addr: 0x4c5284, size: 0x18
    // 0x4c5284: r4 = 0
    //     0x4c5284: mov             x4, #0
    // 0x4c5288: r1 = Function 'remove':.
    //     0x4c5288: add             x17, PP, #0x51, lsl #12  ; [pp+0x514a0] AnonymousClosure: (0x4c529c), in [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::remove (0x504688)
    //     0x4c528c: ldr             x1, [x17, #0x4a0]
    // 0x4c5290: r24 = BuildNonGenericMethodExtractorStub
    //     0x4c5290: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x4c5294: LoadField: r0 = r24->field_17
    //     0x4c5294: ldur            x0, [x24, #0x17]
    // 0x4c5298: br              x0
  }
  [closure] bool remove(dynamic, Object?) {
    // ** addr: 0x4c529c, size: 0x4c
    // 0x4c529c: EnterFrame
    //     0x4c529c: stp             fp, lr, [SP, #-0x10]!
    //     0x4c52a0: mov             fp, SP
    // 0x4c52a4: ldr             x0, [fp, #0x18]
    // 0x4c52a8: LoadField: r1 = r0->field_17
    //     0x4c52a8: ldur            w1, [x0, #0x17]
    // 0x4c52ac: DecompressPointer r1
    //     0x4c52ac: add             x1, x1, HEAP, lsl #32
    // 0x4c52b0: CheckStackOverflow
    //     0x4c52b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c52b4: cmp             SP, x16
    //     0x4c52b8: b.ls            #0x4c52e0
    // 0x4c52bc: LoadField: r0 = r1->field_f
    //     0x4c52bc: ldur            w0, [x1, #0xf]
    // 0x4c52c0: DecompressPointer r0
    //     0x4c52c0: add             x0, x0, HEAP, lsl #32
    // 0x4c52c4: ldr             x16, [fp, #0x10]
    // 0x4c52c8: stp             x16, x0, [SP, #-0x10]!
    // 0x4c52cc: r0 = remove()
    //     0x4c52cc: bl              #0x504688  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::remove
    // 0x4c52d0: add             SP, SP, #0x10
    // 0x4c52d4: LeaveFrame
    //     0x4c52d4: mov             SP, fp
    //     0x4c52d8: ldp             fp, lr, [SP], #0x10
    // 0x4c52dc: ret
    //     0x4c52dc: ret             
    // 0x4c52e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c52e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c52e4: b               #0x4c52bc
  }
  _ takeWhile(/* No info */) {
    // ** addr: 0x4c70d8, size: 0x2c
    // 0x4c70d8: EnterFrame
    //     0x4c70d8: stp             fp, lr, [SP, #-0x10]!
    //     0x4c70dc: mov             fp, SP
    // 0x4c70e0: r1 = <bool>
    //     0x4c70e0: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x4c70e4: r0 = TakeWhileIterable()
    //     0x4c70e4: bl              #0x4c0b44  ; AllocateTakeWhileIterableStub -> TakeWhileIterable<X0> (size=0x14)
    // 0x4c70e8: ldr             x1, [fp, #0x18]
    // 0x4c70ec: StoreField: r0->field_b = r1
    //     0x4c70ec: stur            w1, [x0, #0xb]
    // 0x4c70f0: ldr             x1, [fp, #0x10]
    // 0x4c70f4: StoreField: r0->field_f = r1
    //     0x4c70f4: stur            w1, [x0, #0xf]
    // 0x4c70f8: LeaveFrame
    //     0x4c70f8: mov             SP, fp
    //     0x4c70fc: ldp             fp, lr, [SP], #0x10
    // 0x4c7100: ret
    //     0x4c7100: ret             
  }
  _ indexOf(/* No info */) {
    // ** addr: 0x4c72bc, size: 0x120
    // 0x4c72bc: EnterFrame
    //     0x4c72bc: stp             fp, lr, [SP, #-0x10]!
    //     0x4c72c0: mov             fp, SP
    // 0x4c72c4: mov             x2, x4
    // 0x4c72c8: LoadField: r3 = r2->field_13
    //     0x4c72c8: ldur            w3, [x2, #0x13]
    // 0x4c72cc: DecompressPointer r3
    //     0x4c72cc: add             x3, x3, HEAP, lsl #32
    // 0x4c72d0: sub             x2, x3, #4
    // 0x4c72d4: add             x3, fp, w2, sxtw #2
    // 0x4c72d8: ldr             x3, [x3, #0x18]
    // 0x4c72dc: add             x4, fp, w2, sxtw #2
    // 0x4c72e0: ldr             x4, [x4, #0x10]
    // 0x4c72e4: LoadField: r2 = r3->field_b
    //     0x4c72e4: ldur            x2, [x3, #0xb]
    // 0x4c72e8: LoadField: r5 = r3->field_7
    //     0x4c72e8: ldur            w5, [x3, #7]
    // 0x4c72ec: DecompressPointer r5
    //     0x4c72ec: add             x5, x5, HEAP, lsl #32
    // 0x4c72f0: LoadField: r3 = r5->field_b
    //     0x4c72f0: ldur            w3, [x5, #0xb]
    // 0x4c72f4: DecompressPointer r3
    //     0x4c72f4: add             x3, x3, HEAP, lsl #32
    // 0x4c72f8: r6 = LoadInt32Instr(r3)
    //     0x4c72f8: sbfx            x6, x3, #1, #0x1f
    // 0x4c72fc: LoadField: r3 = r5->field_f
    //     0x4c72fc: ldur            w3, [x5, #0xf]
    // 0x4c7300: DecompressPointer r3
    //     0x4c7300: add             x3, x3, HEAP, lsl #32
    // 0x4c7304: r10 = 0
    //     0x4c7304: mov             x10, #0
    // 0x4c7308: r9 = 8
    //     0x4c7308: mov             x9, #8
    // 0x4c730c: r8 = 7
    //     0x4c730c: mov             x8, #7
    // 0x4c7310: r7 = 7
    //     0x4c7310: mov             x7, #7
    // 0x4c7314: r5 = 1
    //     0x4c7314: mov             x5, #1
    // 0x4c7318: CheckStackOverflow
    //     0x4c7318: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c731c: cmp             SP, x16
    //     0x4c7320: b.ls            #0x4c73d0
    // 0x4c7324: cmp             x10, x2
    // 0x4c7328: b.ge            #0x4c73c0
    // 0x4c732c: sdiv            x11, x10, x9
    // 0x4c7330: mov             x0, x6
    // 0x4c7334: mov             x1, x11
    // 0x4c7338: cmp             x1, x0
    // 0x4c733c: b.hs            #0x4c73d8
    // 0x4c7340: ArrayLoad: r12 = r3[r11]  ; Unknown_4
    //     0x4c7340: add             x16, x3, x11, lsl #2
    //     0x4c7344: ldur            w12, [x16, #0xf]
    // 0x4c7348: DecompressPointer r12
    //     0x4c7348: add             x12, x12, HEAP, lsl #32
    // 0x4c734c: mov             x11, x10
    // 0x4c7350: ubfx            x11, x11, #0, #0x20
    // 0x4c7354: and             x13, x11, x7
    // 0x4c7358: ubfx            x13, x13, #0, #0x20
    // 0x4c735c: sub             x11, x8, x13
    // 0x4c7360: r13 = LoadInt32Instr(r12)
    //     0x4c7360: sbfx            x13, x12, #1, #0x1f
    //     0x4c7364: tbz             w12, #0, #0x4c736c
    //     0x4c7368: ldur            x13, [x12, #7]
    // 0x4c736c: asr             x12, x13, x11
    // 0x4c7370: ubfx            x12, x12, #0, #0x20
    // 0x4c7374: and             x11, x12, x5
    // 0x4c7378: ubfx            x11, x11, #0, #0x20
    // 0x4c737c: cmp             x11, #1
    // 0x4c7380: r16 = true
    //     0x4c7380: add             x16, NULL, #0x20  ; true
    // 0x4c7384: r17 = false
    //     0x4c7384: add             x17, NULL, #0x30  ; false
    // 0x4c7388: csel            x12, x16, x17, eq
    // 0x4c738c: cmp             w12, w4
    // 0x4c7390: b.ne            #0x4c73b4
    // 0x4c7394: r0 = BoxInt64Instr(r10)
    //     0x4c7394: sbfiz           x0, x10, #1, #0x1f
    //     0x4c7398: cmp             x10, x0, asr #1
    //     0x4c739c: b.eq            #0x4c73a8
    //     0x4c73a0: bl              #0xd69bb8
    //     0x4c73a4: stur            x10, [x0, #7]
    // 0x4c73a8: LeaveFrame
    //     0x4c73a8: mov             SP, fp
    //     0x4c73ac: ldp             fp, lr, [SP], #0x10
    // 0x4c73b0: ret
    //     0x4c73b0: ret             
    // 0x4c73b4: add             x0, x10, #1
    // 0x4c73b8: mov             x10, x0
    // 0x4c73bc: b               #0x4c7318
    // 0x4c73c0: r0 = -2
    //     0x4c73c0: mov             x0, #-2
    // 0x4c73c4: LeaveFrame
    //     0x4c73c4: mov             SP, fp
    //     0x4c73c8: ldp             fp, lr, [SP], #0x10
    // 0x4c73cc: ret
    //     0x4c73cc: ret             
    // 0x4c73d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c73d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c73d4: b               #0x4c7324
    // 0x4c73d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4c73d8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ retainWhere(/* No info */) {
    // ** addr: 0x4c759c, size: 0x48
    // 0x4c759c: EnterFrame
    //     0x4c759c: stp             fp, lr, [SP, #-0x10]!
    //     0x4c75a0: mov             fp, SP
    // 0x4c75a4: CheckStackOverflow
    //     0x4c75a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c75a8: cmp             SP, x16
    //     0x4c75ac: b.ls            #0x4c75dc
    // 0x4c75b0: ldr             x16, [fp, #0x18]
    // 0x4c75b4: ldr             lr, [fp, #0x10]
    // 0x4c75b8: stp             lr, x16, [SP, #-0x10]!
    // 0x4c75bc: r16 = true
    //     0x4c75bc: add             x16, NULL, #0x20  ; true
    // 0x4c75c0: SaveReg r16
    //     0x4c75c0: str             x16, [SP, #-8]!
    // 0x4c75c4: r0 = _filter()
    //     0x4c75c4: bl              #0x4c75e4  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::_filter
    // 0x4c75c8: add             SP, SP, #0x18
    // 0x4c75cc: r0 = Null
    //     0x4c75cc: mov             x0, NULL
    // 0x4c75d0: LeaveFrame
    //     0x4c75d0: mov             SP, fp
    //     0x4c75d4: ldp             fp, lr, [SP], #0x10
    // 0x4c75d8: ret
    //     0x4c75d8: ret             
    // 0x4c75dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c75dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c75e0: b               #0x4c75b0
  }
  _ _filter(/* No info */) {
    // ** addr: 0x4c75e4, size: 0x250
    // 0x4c75e4: EnterFrame
    //     0x4c75e4: stp             fp, lr, [SP, #-0x10]!
    //     0x4c75e8: mov             fp, SP
    // 0x4c75ec: AllocStack(0x30)
    //     0x4c75ec: sub             SP, SP, #0x30
    // 0x4c75f0: CheckStackOverflow
    //     0x4c75f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c75f4: cmp             SP, x16
    //     0x4c75f8: b.ls            #0x4c781c
    // 0x4c75fc: r16 = <bool>
    //     0x4c75fc: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x4c7600: stp             xzr, x16, [SP, #-0x10]!
    // 0x4c7604: r0 = _GrowableList()
    //     0x4c7604: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x4c7608: add             SP, SP, #0x10
    // 0x4c760c: mov             x3, x0
    // 0x4c7610: ldr             x2, [fp, #0x20]
    // 0x4c7614: stur            x3, [fp, #-0x28]
    // 0x4c7618: LoadField: r4 = r2->field_b
    //     0x4c7618: ldur            x4, [x2, #0xb]
    // 0x4c761c: stur            x4, [fp, #-0x20]
    // 0x4c7620: LoadField: r5 = r2->field_7
    //     0x4c7620: ldur            w5, [x2, #7]
    // 0x4c7624: DecompressPointer r5
    //     0x4c7624: add             x5, x5, HEAP, lsl #32
    // 0x4c7628: stur            x5, [fp, #-0x18]
    // 0x4c762c: mov             x0, x4
    // 0x4c7630: r10 = 0
    //     0x4c7630: mov             x10, #0
    // 0x4c7634: r9 = 8
    //     0x4c7634: mov             x9, #8
    // 0x4c7638: r8 = 7
    //     0x4c7638: mov             x8, #7
    // 0x4c763c: r7 = 7
    //     0x4c763c: mov             x7, #7
    // 0x4c7640: r6 = 1
    //     0x4c7640: mov             x6, #1
    // 0x4c7644: stur            x10, [fp, #-0x10]
    // 0x4c7648: CheckStackOverflow
    //     0x4c7648: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c764c: cmp             SP, x16
    //     0x4c7650: b.ls            #0x4c7824
    // 0x4c7654: cmp             x10, x4
    // 0x4c7658: b.ge            #0x4c77a8
    // 0x4c765c: sdiv            x11, x10, x9
    // 0x4c7660: LoadField: r0 = r5->field_b
    //     0x4c7660: ldur            w0, [x5, #0xb]
    // 0x4c7664: DecompressPointer r0
    //     0x4c7664: add             x0, x0, HEAP, lsl #32
    // 0x4c7668: r1 = LoadInt32Instr(r0)
    //     0x4c7668: sbfx            x1, x0, #1, #0x1f
    // 0x4c766c: mov             x0, x1
    // 0x4c7670: mov             x1, x11
    // 0x4c7674: cmp             x1, x0
    // 0x4c7678: b.hs            #0x4c782c
    // 0x4c767c: LoadField: r0 = r5->field_f
    //     0x4c767c: ldur            w0, [x5, #0xf]
    // 0x4c7680: DecompressPointer r0
    //     0x4c7680: add             x0, x0, HEAP, lsl #32
    // 0x4c7684: ArrayLoad: r1 = r0[r11]  ; Unknown_4
    //     0x4c7684: add             x16, x0, x11, lsl #2
    //     0x4c7688: ldur            w1, [x16, #0xf]
    // 0x4c768c: DecompressPointer r1
    //     0x4c768c: add             x1, x1, HEAP, lsl #32
    // 0x4c7690: mov             x0, x10
    // 0x4c7694: ubfx            x0, x0, #0, #0x20
    // 0x4c7698: and             x11, x0, x7
    // 0x4c769c: ubfx            x11, x11, #0, #0x20
    // 0x4c76a0: sub             x0, x8, x11
    // 0x4c76a4: r11 = LoadInt32Instr(r1)
    //     0x4c76a4: sbfx            x11, x1, #1, #0x1f
    //     0x4c76a8: tbz             w1, #0, #0x4c76b0
    //     0x4c76ac: ldur            x11, [x1, #7]
    // 0x4c76b0: asr             x1, x11, x0
    // 0x4c76b4: ubfx            x1, x1, #0, #0x20
    // 0x4c76b8: and             x0, x1, x6
    // 0x4c76bc: ubfx            x0, x0, #0, #0x20
    // 0x4c76c0: cmp             x0, #1
    // 0x4c76c4: r16 = true
    //     0x4c76c4: add             x16, NULL, #0x20  ; true
    // 0x4c76c8: r17 = false
    //     0x4c76c8: add             x17, NULL, #0x30  ; false
    // 0x4c76cc: csel            x1, x16, x17, eq
    // 0x4c76d0: stur            x1, [fp, #-8]
    // 0x4c76d4: ldr             x16, [fp, #0x18]
    // 0x4c76d8: stp             x1, x16, [SP, #-0x10]!
    // 0x4c76dc: ldr             x0, [fp, #0x18]
    // 0x4c76e0: ClosureCall
    //     0x4c76e0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4c76e4: ldur            x2, [x0, #0x1f]
    //     0x4c76e8: blr             x2
    // 0x4c76ec: add             SP, SP, #0x10
    // 0x4c76f0: r16 = true
    //     0x4c76f0: add             x16, NULL, #0x20  ; true
    // 0x4c76f4: cmp             w0, w16
    // 0x4c76f8: b.ne            #0x4c776c
    // 0x4c76fc: ldur            x0, [fp, #-0x28]
    // 0x4c7700: LoadField: r1 = r0->field_b
    //     0x4c7700: ldur            w1, [x0, #0xb]
    // 0x4c7704: DecompressPointer r1
    //     0x4c7704: add             x1, x1, HEAP, lsl #32
    // 0x4c7708: stur            x1, [fp, #-0x30]
    // 0x4c770c: LoadField: r2 = r0->field_f
    //     0x4c770c: ldur            w2, [x0, #0xf]
    // 0x4c7710: DecompressPointer r2
    //     0x4c7710: add             x2, x2, HEAP, lsl #32
    // 0x4c7714: LoadField: r3 = r2->field_b
    //     0x4c7714: ldur            w3, [x2, #0xb]
    // 0x4c7718: DecompressPointer r3
    //     0x4c7718: add             x3, x3, HEAP, lsl #32
    // 0x4c771c: cmp             w1, w3
    // 0x4c7720: b.ne            #0x4c7730
    // 0x4c7724: SaveReg r0
    //     0x4c7724: str             x0, [SP, #-8]!
    // 0x4c7728: r0 = _growToNextCapacity()
    //     0x4c7728: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4c772c: add             SP, SP, #8
    // 0x4c7730: ldur            x2, [fp, #-0x28]
    // 0x4c7734: ldur            x3, [fp, #-8]
    // 0x4c7738: ldur            x0, [fp, #-0x30]
    // 0x4c773c: r4 = LoadInt32Instr(r0)
    //     0x4c773c: sbfx            x4, x0, #1, #0x1f
    // 0x4c7740: add             x0, x4, #1
    // 0x4c7744: lsl             x1, x0, #1
    // 0x4c7748: StoreField: r2->field_b = r1
    //     0x4c7748: stur            w1, [x2, #0xb]
    // 0x4c774c: mov             x1, x4
    // 0x4c7750: cmp             x1, x0
    // 0x4c7754: b.hs            #0x4c7830
    // 0x4c7758: LoadField: r0 = r2->field_f
    //     0x4c7758: ldur            w0, [x2, #0xf]
    // 0x4c775c: DecompressPointer r0
    //     0x4c775c: add             x0, x0, HEAP, lsl #32
    // 0x4c7760: ArrayStore: r0[r4] = r3  ; Unknown_4
    //     0x4c7760: add             x1, x0, x4, lsl #2
    //     0x4c7764: stur            w3, [x1, #0xf]
    // 0x4c7768: b               #0x4c7770
    // 0x4c776c: ldur            x2, [fp, #-0x28]
    // 0x4c7770: ldr             x0, [fp, #0x20]
    // 0x4c7774: ldur            x1, [fp, #-0x20]
    // 0x4c7778: LoadField: r3 = r0->field_b
    //     0x4c7778: ldur            x3, [x0, #0xb]
    // 0x4c777c: cmp             x1, x3
    // 0x4c7780: b.ne            #0x4c77d4
    // 0x4c7784: mov             x4, x0
    // 0x4c7788: ldur            x0, [fp, #-0x10]
    // 0x4c778c: add             x10, x0, #1
    // 0x4c7790: mov             x0, x3
    // 0x4c7794: mov             x3, x2
    // 0x4c7798: mov             x2, x4
    // 0x4c779c: ldur            x5, [fp, #-0x18]
    // 0x4c77a0: mov             x4, x1
    // 0x4c77a4: b               #0x4c7634
    // 0x4c77a8: mov             x4, x2
    // 0x4c77ac: mov             x2, x3
    // 0x4c77b0: LoadField: r1 = r2->field_b
    //     0x4c77b0: ldur            w1, [x2, #0xb]
    // 0x4c77b4: DecompressPointer r1
    //     0x4c77b4: add             x1, x1, HEAP, lsl #32
    // 0x4c77b8: r3 = LoadInt32Instr(r1)
    //     0x4c77b8: sbfx            x3, x1, #1, #0x1f
    // 0x4c77bc: cmp             x3, x0
    // 0x4c77c0: b.ne            #0x4c77e8
    // 0x4c77c4: r0 = Null
    //     0x4c77c4: mov             x0, NULL
    // 0x4c77c8: LeaveFrame
    //     0x4c77c8: mov             SP, fp
    //     0x4c77cc: ldp             fp, lr, [SP], #0x10
    // 0x4c77d0: ret
    //     0x4c77d0: ret             
    // 0x4c77d4: r0 = ConcurrentModificationError()
    //     0x4c77d4: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x4c77d8: ldr             x4, [fp, #0x20]
    // 0x4c77dc: StoreField: r0->field_b = r4
    //     0x4c77dc: stur            w4, [x0, #0xb]
    // 0x4c77e0: r0 = Throw()
    //     0x4c77e0: bl              #0xd67e38  ; ThrowStub
    // 0x4c77e4: brk             #0
    // 0x4c77e8: stp             xzr, x4, [SP, #-0x10]!
    // 0x4c77ec: stp             x2, x3, [SP, #-0x10]!
    // 0x4c77f0: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x4c77f0: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x4c77f4: r0 = setRange()
    //     0x4c77f4: bl              #0x504b04  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::setRange
    // 0x4c77f8: add             SP, SP, #0x20
    // 0x4c77fc: r0 = UnsupportedError()
    //     0x4c77fc: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x4c7800: mov             x1, x0
    // 0x4c7804: r0 = "Cannot change"
    //     0x4c7804: add             x0, PP, #0x38, lsl #12  ; [pp+0x38ed8] "Cannot change"
    //     0x4c7808: ldr             x0, [x0, #0xed8]
    // 0x4c780c: StoreField: r1->field_b = r0
    //     0x4c780c: stur            w0, [x1, #0xb]
    // 0x4c7810: mov             x0, x1
    // 0x4c7814: r0 = Throw()
    //     0x4c7814: bl              #0xd67e38  ; ThrowStub
    // 0x4c7818: brk             #0
    // 0x4c781c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c781c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c7820: b               #0x4c75fc
    // 0x4c7824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c7824: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c7828: b               #0x4c7654
    // 0x4c782c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4c782c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4c7830: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4c7830: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  dynamic add(dynamic) {
    // ** addr: 0x4c7e00, size: 0x18
    // 0x4c7e00: r4 = 0
    //     0x4c7e00: mov             x4, #0
    // 0x4c7e04: r1 = Function 'add':.
    //     0x4c7e04: add             x17, PP, #0x41, lsl #12  ; [pp+0x412e8] AnonymousClosure: (0x4c7e18), in [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::add (0x515a34)
    //     0x4c7e08: ldr             x1, [x17, #0x2e8]
    // 0x4c7e0c: r24 = BuildNonGenericMethodExtractorStub
    //     0x4c7e0c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x4c7e10: LoadField: r0 = r24->field_17
    //     0x4c7e10: ldur            x0, [x24, #0x17]
    // 0x4c7e14: br              x0
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0x4c7e18, size: 0x4c
    // 0x4c7e18: EnterFrame
    //     0x4c7e18: stp             fp, lr, [SP, #-0x10]!
    //     0x4c7e1c: mov             fp, SP
    // 0x4c7e20: ldr             x0, [fp, #0x18]
    // 0x4c7e24: LoadField: r1 = r0->field_17
    //     0x4c7e24: ldur            w1, [x0, #0x17]
    // 0x4c7e28: DecompressPointer r1
    //     0x4c7e28: add             x1, x1, HEAP, lsl #32
    // 0x4c7e2c: CheckStackOverflow
    //     0x4c7e2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c7e30: cmp             SP, x16
    //     0x4c7e34: b.ls            #0x4c7e5c
    // 0x4c7e38: LoadField: r0 = r1->field_f
    //     0x4c7e38: ldur            w0, [x1, #0xf]
    // 0x4c7e3c: DecompressPointer r0
    //     0x4c7e3c: add             x0, x0, HEAP, lsl #32
    // 0x4c7e40: ldr             x16, [fp, #0x10]
    // 0x4c7e44: stp             x16, x0, [SP, #-0x10]!
    // 0x4c7e48: r0 = add()
    //     0x4c7e48: bl              #0x515a34  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::add
    // 0x4c7e4c: add             SP, SP, #0x10
    // 0x4c7e50: LeaveFrame
    //     0x4c7e50: mov             SP, fp
    //     0x4c7e54: ldp             fp, lr, [SP], #0x10
    // 0x4c7e58: ret
    //     0x4c7e58: ret             
    // 0x4c7e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c7e5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c7e60: b               #0x4c7e38
  }
  _ sort(/* No info */) {
    // ** addr: 0x4c88b4, size: 0x84
    // 0x4c88b4: EnterFrame
    //     0x4c88b4: stp             fp, lr, [SP, #-0x10]!
    //     0x4c88b8: mov             fp, SP
    // 0x4c88bc: mov             x0, x4
    // 0x4c88c0: LoadField: r1 = r0->field_13
    //     0x4c88c0: ldur            w1, [x0, #0x13]
    // 0x4c88c4: DecompressPointer r1
    //     0x4c88c4: add             x1, x1, HEAP, lsl #32
    // 0x4c88c8: sub             x0, x1, #2
    // 0x4c88cc: add             x1, fp, w0, sxtw #2
    // 0x4c88d0: ldr             x1, [x1, #0x10]
    // 0x4c88d4: cmp             w0, #2
    // 0x4c88d8: b.lt            #0x4c88ec
    // 0x4c88dc: add             x2, fp, w0, sxtw #2
    // 0x4c88e0: ldr             x2, [x2, #8]
    // 0x4c88e4: mov             x0, x2
    // 0x4c88e8: b               #0x4c88f0
    // 0x4c88ec: r0 = Null
    //     0x4c88ec: mov             x0, NULL
    // 0x4c88f0: CheckStackOverflow
    //     0x4c88f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4c88f4: cmp             SP, x16
    //     0x4c88f8: b.ls            #0x4c8930
    // 0x4c88fc: cmp             w0, NULL
    // 0x4c8900: b.ne            #0x4c8908
    // 0x4c8904: r0 = Closure: (dynamic, dynamic) => int from Function '_compareAny@3220832': static.
    //     0x4c8904: ldr             x0, [PP, #0x10c8]  ; [pp+0x10c8] Closure: (dynamic, dynamic) => int from Function '_compareAny@3220832': static. (0x7fe6e1cca5cc)
    // 0x4c8908: r16 = <bool>
    //     0x4c8908: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x4c890c: stp             x1, x16, [SP, #-0x10]!
    // 0x4c8910: SaveReg r0
    //     0x4c8910: str             x0, [SP, #-8]!
    // 0x4c8914: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x4c8914: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x4c8918: r0 = sort()
    //     0x4c8918: bl              #0x4c8938  ; [dart:_internal] Sort::sort
    // 0x4c891c: add             SP, SP, #0x18
    // 0x4c8920: r0 = Null
    //     0x4c8920: mov             x0, NULL
    // 0x4c8924: LeaveFrame
    //     0x4c8924: mov             SP, fp
    //     0x4c8928: ldp             fp, lr, [SP], #0x10
    // 0x4c892c: ret
    //     0x4c892c: ret             
    // 0x4c8930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4c8930: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4c8934: b               #0x4c88fc
  }
  get _ reversed(/* No info */) {
    // ** addr: 0x4f87f0, size: 0x24
    // 0x4f87f0: EnterFrame
    //     0x4f87f0: stp             fp, lr, [SP, #-0x10]!
    //     0x4f87f4: mov             fp, SP
    // 0x4f87f8: r1 = <bool>
    //     0x4f87f8: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x4f87fc: r0 = ReversedListIterable()
    //     0x4f87fc: bl              #0x4c1784  ; AllocateReversedListIterableStub -> ReversedListIterable<X0> (size=0x10)
    // 0x4f8800: ldr             x1, [fp, #0x10]
    // 0x4f8804: StoreField: r0->field_b = r1
    //     0x4f8804: stur            w1, [x0, #0xb]
    // 0x4f8808: LeaveFrame
    //     0x4f8808: mov             SP, fp
    //     0x4f880c: ldp             fp, lr, [SP], #0x10
    // 0x4f8810: ret
    //     0x4f8810: ret             
  }
  _ indexWhere(/* No info */) {
    // ** addr: 0x4f9440, size: 0x16c
    // 0x4f9440: EnterFrame
    //     0x4f9440: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9444: mov             fp, SP
    // 0x4f9448: AllocStack(0x28)
    //     0x4f9448: sub             SP, SP, #0x28
    // 0x4f944c: SetupParameters(_BoolList&Object&ListMixin this /* r2, fp-0x20 */, dynamic _ /* r3, fp-0x18 */)
    //     0x4f944c: mov             x0, x4
    //     0x4f9450: ldur            w1, [x0, #0x13]
    //     0x4f9454: add             x1, x1, HEAP, lsl #32
    //     0x4f9458: sub             x0, x1, #4
    //     0x4f945c: add             x2, fp, w0, sxtw #2
    //     0x4f9460: ldr             x2, [x2, #0x18]
    //     0x4f9464: stur            x2, [fp, #-0x20]
    //     0x4f9468: add             x3, fp, w0, sxtw #2
    //     0x4f946c: ldr             x3, [x3, #0x10]
    //     0x4f9470: stur            x3, [fp, #-0x18]
    // 0x4f9474: CheckStackOverflow
    //     0x4f9474: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4f9478: cmp             SP, x16
    //     0x4f947c: b.ls            #0x4f9598
    // 0x4f9480: LoadField: r4 = r2->field_7
    //     0x4f9480: ldur            w4, [x2, #7]
    // 0x4f9484: DecompressPointer r4
    //     0x4f9484: add             x4, x4, HEAP, lsl #32
    // 0x4f9488: stur            x4, [fp, #-0x10]
    // 0x4f948c: r9 = 0
    //     0x4f948c: mov             x9, #0
    // 0x4f9490: r8 = 8
    //     0x4f9490: mov             x8, #8
    // 0x4f9494: r7 = 7
    //     0x4f9494: mov             x7, #7
    // 0x4f9498: r6 = 7
    //     0x4f9498: mov             x6, #7
    // 0x4f949c: r5 = 1
    //     0x4f949c: mov             x5, #1
    // 0x4f94a0: stur            x9, [fp, #-8]
    // 0x4f94a4: CheckStackOverflow
    //     0x4f94a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4f94a8: cmp             SP, x16
    //     0x4f94ac: b.ls            #0x4f95a0
    // 0x4f94b0: LoadField: r0 = r2->field_b
    //     0x4f94b0: ldur            x0, [x2, #0xb]
    // 0x4f94b4: cmp             x9, x0
    // 0x4f94b8: b.ge            #0x4f9588
    // 0x4f94bc: sdiv            x10, x9, x8
    // 0x4f94c0: LoadField: r0 = r4->field_b
    //     0x4f94c0: ldur            w0, [x4, #0xb]
    // 0x4f94c4: DecompressPointer r0
    //     0x4f94c4: add             x0, x0, HEAP, lsl #32
    // 0x4f94c8: r1 = LoadInt32Instr(r0)
    //     0x4f94c8: sbfx            x1, x0, #1, #0x1f
    // 0x4f94cc: mov             x0, x1
    // 0x4f94d0: mov             x1, x10
    // 0x4f94d4: cmp             x1, x0
    // 0x4f94d8: b.hs            #0x4f95a8
    // 0x4f94dc: LoadField: r0 = r4->field_f
    //     0x4f94dc: ldur            w0, [x4, #0xf]
    // 0x4f94e0: DecompressPointer r0
    //     0x4f94e0: add             x0, x0, HEAP, lsl #32
    // 0x4f94e4: ArrayLoad: r1 = r0[r10]  ; Unknown_4
    //     0x4f94e4: add             x16, x0, x10, lsl #2
    //     0x4f94e8: ldur            w1, [x16, #0xf]
    // 0x4f94ec: DecompressPointer r1
    //     0x4f94ec: add             x1, x1, HEAP, lsl #32
    // 0x4f94f0: mov             x0, x9
    // 0x4f94f4: ubfx            x0, x0, #0, #0x20
    // 0x4f94f8: and             x10, x0, x6
    // 0x4f94fc: ubfx            x10, x10, #0, #0x20
    // 0x4f9500: sub             x0, x7, x10
    // 0x4f9504: r10 = LoadInt32Instr(r1)
    //     0x4f9504: sbfx            x10, x1, #1, #0x1f
    //     0x4f9508: tbz             w1, #0, #0x4f9510
    //     0x4f950c: ldur            x10, [x1, #7]
    // 0x4f9510: asr             x1, x10, x0
    // 0x4f9514: ubfx            x1, x1, #0, #0x20
    // 0x4f9518: and             x0, x1, x5
    // 0x4f951c: ubfx            x0, x0, #0, #0x20
    // 0x4f9520: cmp             x0, #1
    // 0x4f9524: r16 = true
    //     0x4f9524: add             x16, NULL, #0x20  ; true
    // 0x4f9528: r17 = false
    //     0x4f9528: add             x17, NULL, #0x30  ; false
    // 0x4f952c: csel            x1, x16, x17, eq
    // 0x4f9530: stp             x1, x3, [SP, #-0x10]!
    // 0x4f9534: mov             x0, x3
    // 0x4f9538: ClosureCall
    //     0x4f9538: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4f953c: ldur            x2, [x0, #0x1f]
    //     0x4f9540: blr             x2
    // 0x4f9544: add             SP, SP, #0x10
    // 0x4f9548: mov             x1, x0
    // 0x4f954c: stur            x1, [fp, #-0x28]
    // 0x4f9550: tbnz            w0, #5, #0x4f9558
    // 0x4f9554: r0 = AssertBoolean()
    //     0x4f9554: bl              #0xd67df0  ; AssertBooleanStub
    // 0x4f9558: ldur            x1, [fp, #-0x28]
    // 0x4f955c: tbnz            w1, #4, #0x4f9570
    // 0x4f9560: ldur            x0, [fp, #-8]
    // 0x4f9564: LeaveFrame
    //     0x4f9564: mov             SP, fp
    //     0x4f9568: ldp             fp, lr, [SP], #0x10
    // 0x4f956c: ret
    //     0x4f956c: ret             
    // 0x4f9570: ldur            x1, [fp, #-8]
    // 0x4f9574: add             x9, x1, #1
    // 0x4f9578: ldur            x2, [fp, #-0x20]
    // 0x4f957c: ldur            x3, [fp, #-0x18]
    // 0x4f9580: ldur            x4, [fp, #-0x10]
    // 0x4f9584: b               #0x4f9490
    // 0x4f9588: r0 = -1
    //     0x4f9588: mov             x0, #-1
    // 0x4f958c: LeaveFrame
    //     0x4f958c: mov             SP, fp
    //     0x4f9590: ldp             fp, lr, [SP], #0x10
    // 0x4f9594: ret
    //     0x4f9594: ret             
    // 0x4f9598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f9598: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f959c: b               #0x4f9480
    // 0x4f95a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f95a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f95a4: b               #0x4f94b0
    // 0x4f95a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4f95a8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ fillRange(/* No info */) {
    // ** addr: 0x4f9610, size: 0x48
    // 0x4f9610: EnterFrame
    //     0x4f9610: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9614: mov             fp, SP
    // 0x4f9618: ldr             x0, [fp, #0x10]
    // 0x4f961c: r2 = Null
    //     0x4f961c: mov             x2, NULL
    // 0x4f9620: r1 = Null
    //     0x4f9620: mov             x1, NULL
    // 0x4f9624: r4 = 59
    //     0x4f9624: mov             x4, #0x3b
    // 0x4f9628: branchIfSmi(r0, 0x4f9634)
    //     0x4f9628: tbz             w0, #0, #0x4f9634
    // 0x4f962c: r4 = LoadClassIdInstr(r0)
    //     0x4f962c: ldur            x4, [x0, #-1]
    //     0x4f9630: ubfx            x4, x4, #0xc, #0x14
    // 0x4f9634: cmp             x4, #0x3e
    // 0x4f9638: b.eq            #0x4f964c
    // 0x4f963c: r8 = bool?
    //     0x4f963c: ldr             x8, [PP, #0x20f0]  ; [pp+0x20f0] Type: bool?
    // 0x4f9640: r3 = Null
    //     0x4f9640: add             x3, PP, #0x41, lsl #12  ; [pp+0x413f0] Null
    //     0x4f9644: ldr             x3, [x3, #0x3f0]
    // 0x4f9648: r0 = bool?()
    //     0x4f9648: bl              #0x4e1de0  ; IsType_bool?_Stub
    // 0x4f964c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x4f964c: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x4f9650: r0 = Throw()
    //     0x4f9650: bl              #0xd67e38  ; ThrowStub
    // 0x4f9654: brk             #0
  }
  _ insertAll(/* No info */) {
    // ** addr: 0x4f9e18, size: 0x328
    // 0x4f9e18: EnterFrame
    //     0x4f9e18: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9e1c: mov             fp, SP
    // 0x4f9e20: AllocStack(0x20)
    //     0x4f9e20: sub             SP, SP, #0x20
    // 0x4f9e24: CheckStackOverflow
    //     0x4f9e24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4f9e28: cmp             SP, x16
    //     0x4f9e2c: b.ls            #0x4fa12c
    // 0x4f9e30: ldr             x0, [fp, #0x10]
    // 0x4f9e34: r2 = Null
    //     0x4f9e34: mov             x2, NULL
    // 0x4f9e38: r1 = Null
    //     0x4f9e38: mov             x1, NULL
    // 0x4f9e3c: r8 = Iterable<bool>
    //     0x4f9e3c: add             x8, PP, #0x41, lsl #12  ; [pp+0x412f0] Type: Iterable<bool>
    //     0x4f9e40: ldr             x8, [x8, #0x2f0]
    // 0x4f9e44: r3 = Null
    //     0x4f9e44: add             x3, PP, #0x41, lsl #12  ; [pp+0x412f8] Null
    //     0x4f9e48: ldr             x3, [x3, #0x2f8]
    // 0x4f9e4c: r0 = Iterable<bool>()
    //     0x4f9e4c: bl              #0x4fa324  ; IsType_Iterable<bool>_Stub
    // 0x4f9e50: ldr             x0, [fp, #0x20]
    // 0x4f9e54: LoadField: r1 = r0->field_b
    //     0x4f9e54: ldur            x1, [x0, #0xb]
    // 0x4f9e58: stp             xzr, xzr, [SP, #-0x10]!
    // 0x4f9e5c: r16 = "index"
    //     0x4f9e5c: ldr             x16, [PP, #0xd38]  ; [pp+0xd38] "index"
    // 0x4f9e60: stp             x16, x1, [SP, #-0x10]!
    // 0x4f9e64: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x4f9e64: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x4f9e68: r0 = checkValueInInterval()
    //     0x4f9e68: bl              #0x4c6ec8  ; [dart:core] RangeError::checkValueInInterval
    // 0x4f9e6c: add             SP, SP, #0x20
    // 0x4f9e70: ldr             x3, [fp, #0x20]
    // 0x4f9e74: LoadField: r0 = r3->field_b
    //     0x4f9e74: ldur            x0, [x3, #0xb]
    // 0x4f9e78: cbnz            x0, #0x4f9e9c
    // 0x4f9e7c: ldr             x16, [fp, #0x10]
    // 0x4f9e80: stp             x16, x3, [SP, #-0x10]!
    // 0x4f9e84: r0 = addAll()
    //     0x4f9e84: bl              #0x507618  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::addAll
    // 0x4f9e88: add             SP, SP, #0x10
    // 0x4f9e8c: r0 = Null
    //     0x4f9e8c: mov             x0, NULL
    // 0x4f9e90: LeaveFrame
    //     0x4f9e90: mov             SP, fp
    //     0x4f9e94: ldp             fp, lr, [SP], #0x10
    // 0x4f9e98: ret
    //     0x4f9e98: ret             
    // 0x4f9e9c: ldr             x0, [fp, #0x10]
    // 0x4f9ea0: r2 = Null
    //     0x4f9ea0: mov             x2, NULL
    // 0x4f9ea4: r1 = Null
    //     0x4f9ea4: mov             x1, NULL
    // 0x4f9ea8: cmp             w0, NULL
    // 0x4f9eac: b.eq            #0x4f9f44
    // 0x4f9eb0: branchIfSmi(r0, 0x4f9f44)
    //     0x4f9eb0: tbz             w0, #0, #0x4f9f44
    // 0x4f9eb4: r3 = LoadClassIdInstr(r0)
    //     0x4f9eb4: ldur            x3, [x0, #-1]
    //     0x4f9eb8: ubfx            x3, x3, #0xc, #0x14
    // 0x4f9ebc: r17 = 6119
    //     0x4f9ebc: mov             x17, #0x17e7
    // 0x4f9ec0: cmp             x3, x17
    // 0x4f9ec4: b.eq            #0x4f9f4c
    // 0x4f9ec8: r4 = LoadClassIdInstr(r0)
    //     0x4f9ec8: ldur            x4, [x0, #-1]
    //     0x4f9ecc: ubfx            x4, x4, #0xc, #0x14
    // 0x4f9ed0: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x4f9ed4: ldr             x3, [x3, #0x18]
    // 0x4f9ed8: ldr             x3, [x3, x4, lsl #3]
    // 0x4f9edc: LoadField: r3 = r3->field_2b
    //     0x4f9edc: ldur            w3, [x3, #0x2b]
    // 0x4f9ee0: DecompressPointer r3
    //     0x4f9ee0: add             x3, x3, HEAP, lsl #32
    // 0x4f9ee4: cmp             w3, NULL
    // 0x4f9ee8: b.eq            #0x4f9f44
    // 0x4f9eec: LoadField: r3 = r3->field_f
    //     0x4f9eec: ldur            w3, [x3, #0xf]
    // 0x4f9ef0: lsr             x3, x3, #4
    // 0x4f9ef4: r17 = 6119
    //     0x4f9ef4: mov             x17, #0x17e7
    // 0x4f9ef8: cmp             x3, x17
    // 0x4f9efc: b.eq            #0x4f9f4c
    // 0x4f9f00: r3 = SubtypeTestCache
    //     0x4f9f00: add             x3, PP, #0x41, lsl #12  ; [pp+0x41308] SubtypeTestCache
    //     0x4f9f04: ldr             x3, [x3, #0x308]
    // 0x4f9f08: r24 = Subtype1TestCacheStub
    //     0x4f9f08: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x4f9f0c: LoadField: r30 = r24->field_7
    //     0x4f9f0c: ldur            lr, [x24, #7]
    // 0x4f9f10: blr             lr
    // 0x4f9f14: cmp             w7, NULL
    // 0x4f9f18: b.eq            #0x4f9f24
    // 0x4f9f1c: tbnz            w7, #4, #0x4f9f44
    // 0x4f9f20: b               #0x4f9f4c
    // 0x4f9f24: r8 = EfficientLengthIterable
    //     0x4f9f24: add             x8, PP, #0x41, lsl #12  ; [pp+0x41310] Type: EfficientLengthIterable
    //     0x4f9f28: ldr             x8, [x8, #0x310]
    // 0x4f9f2c: r3 = SubtypeTestCache
    //     0x4f9f2c: add             x3, PP, #0x41, lsl #12  ; [pp+0x41318] SubtypeTestCache
    //     0x4f9f30: ldr             x3, [x3, #0x318]
    // 0x4f9f34: r24 = InstanceOfStub
    //     0x4f9f34: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x4f9f38: LoadField: r30 = r24->field_7
    //     0x4f9f38: ldur            lr, [x24, #7]
    // 0x4f9f3c: blr             lr
    // 0x4f9f40: b               #0x4f9f50
    // 0x4f9f44: r0 = false
    //     0x4f9f44: add             x0, NULL, #0x30  ; false
    // 0x4f9f48: b               #0x4f9f50
    // 0x4f9f4c: r0 = true
    //     0x4f9f4c: add             x0, NULL, #0x20  ; true
    // 0x4f9f50: tbz             w0, #4, #0x4f9f60
    // 0x4f9f54: ldr             x1, [fp, #0x20]
    // 0x4f9f58: ldr             x0, [fp, #0x10]
    // 0x4f9f5c: b               #0x4f9f70
    // 0x4f9f60: ldr             x1, [fp, #0x20]
    // 0x4f9f64: ldr             x0, [fp, #0x10]
    // 0x4f9f68: cmp             w0, w1
    // 0x4f9f6c: b.ne            #0x4f9fa0
    // 0x4f9f70: r2 = LoadClassIdInstr(r0)
    //     0x4f9f70: ldur            x2, [x0, #-1]
    //     0x4f9f74: ubfx            x2, x2, #0xc, #0x14
    // 0x4f9f78: SaveReg r0
    //     0x4f9f78: str             x0, [SP, #-8]!
    // 0x4f9f7c: mov             x0, x2
    // 0x4f9f80: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4f9f80: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4f9f84: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0x4f9f84: mov             x17, #0xc8a1
    //     0x4f9f88: add             lr, x0, x17
    //     0x4f9f8c: ldr             lr, [x21, lr, lsl #3]
    //     0x4f9f90: blr             lr
    // 0x4f9f94: add             SP, SP, #8
    // 0x4f9f98: mov             x1, x0
    // 0x4f9f9c: b               #0x4f9fa4
    // 0x4f9fa0: mov             x1, x0
    // 0x4f9fa4: stur            x1, [fp, #-8]
    // 0x4f9fa8: r0 = LoadClassIdInstr(r1)
    //     0x4f9fa8: ldur            x0, [x1, #-1]
    //     0x4f9fac: ubfx            x0, x0, #0xc, #0x14
    // 0x4f9fb0: SaveReg r1
    //     0x4f9fb0: str             x1, [SP, #-8]!
    // 0x4f9fb4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x4f9fb4: mov             x17, #0xb8ea
    //     0x4f9fb8: add             lr, x0, x17
    //     0x4f9fbc: ldr             lr, [x21, lr, lsl #3]
    //     0x4f9fc0: blr             lr
    // 0x4f9fc4: add             SP, SP, #8
    // 0x4f9fc8: mov             x1, x0
    // 0x4f9fcc: stur            x1, [fp, #-0x20]
    // 0x4f9fd0: r2 = LoadInt32Instr(r1)
    //     0x4f9fd0: sbfx            x2, x1, #1, #0x1f
    //     0x4f9fd4: tbz             w1, #0, #0x4f9fdc
    //     0x4f9fd8: ldur            x2, [x1, #7]
    // 0x4f9fdc: stur            x2, [fp, #-0x18]
    // 0x4f9fe0: cbnz            x2, #0x4f9ff4
    // 0x4f9fe4: r0 = Null
    //     0x4f9fe4: mov             x0, NULL
    // 0x4f9fe8: LeaveFrame
    //     0x4f9fe8: mov             SP, fp
    //     0x4f9fec: ldp             fp, lr, [SP], #0x10
    // 0x4f9ff0: ret
    //     0x4f9ff0: ret             
    // 0x4f9ff4: ldr             x3, [fp, #0x20]
    // 0x4f9ff8: LoadField: r4 = r3->field_b
    //     0x4f9ff8: ldur            x4, [x3, #0xb]
    // 0x4f9ffc: stur            x4, [fp, #-0x10]
    // 0x4fa000: sub             x0, x4, x2
    // 0x4fa004: CheckStackOverflow
    //     0x4fa004: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fa008: cmp             SP, x16
    //     0x4fa00c: b.ls            #0x4fa134
    // 0x4fa010: cmp             x0, x4
    // 0x4fa014: b.ge            #0x4fa024
    // 0x4fa018: cmp             x0, #0
    // 0x4fa01c: b.le            #0x4fa0c8
    // 0x4fa020: b               #0x4fa0c0
    // 0x4fa024: ldur            x6, [fp, #-8]
    // 0x4fa028: r5 = "Cannot change"
    //     0x4fa028: add             x5, PP, #0x38, lsl #12  ; [pp+0x38ed8] "Cannot change"
    //     0x4fa02c: ldr             x5, [x5, #0xed8]
    // 0x4fa030: r0 = LoadClassIdInstr(r6)
    //     0x4fa030: ldur            x0, [x6, #-1]
    //     0x4fa034: ubfx            x0, x0, #0xc, #0x14
    // 0x4fa038: SaveReg r6
    //     0x4fa038: str             x6, [SP, #-8]!
    // 0x4fa03c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x4fa03c: mov             x17, #0xb8ea
    //     0x4fa040: add             lr, x0, x17
    //     0x4fa044: ldr             lr, [x21, lr, lsl #3]
    //     0x4fa048: blr             lr
    // 0x4fa04c: add             SP, SP, #8
    // 0x4fa050: r1 = LoadInt32Instr(r0)
    //     0x4fa050: sbfx            x1, x0, #1, #0x1f
    //     0x4fa054: tbz             w0, #0, #0x4fa05c
    //     0x4fa058: ldur            x1, [x0, #7]
    // 0x4fa05c: ldur            x0, [fp, #-0x18]
    // 0x4fa060: cmp             x1, x0
    // 0x4fa064: b.ne            #0x4fa10c
    // 0x4fa068: ldur            x1, [fp, #-0x10]
    // 0x4fa06c: cmp             x0, x1
    // 0x4fa070: b.ge            #0x4fa098
    // 0x4fa074: ldr             x16, [fp, #0x20]
    // 0x4fa078: ldur            lr, [fp, #-0x20]
    // 0x4fa07c: stp             lr, x16, [SP, #-0x10]!
    // 0x4fa080: ldr             x16, [fp, #0x20]
    // 0x4fa084: stp             x16, x1, [SP, #-0x10]!
    // 0x4fa088: SaveReg rZR
    //     0x4fa088: str             xzr, [SP, #-8]!
    // 0x4fa08c: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x4fa08c: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x4fa090: r0 = setRange()
    //     0x4fa090: bl              #0x504b04  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::setRange
    // 0x4fa094: add             SP, SP, #0x28
    // 0x4fa098: ldr             x16, [fp, #0x20]
    // 0x4fa09c: stp             xzr, x16, [SP, #-0x10]!
    // 0x4fa0a0: ldur            x16, [fp, #-8]
    // 0x4fa0a4: SaveReg r16
    //     0x4fa0a4: str             x16, [SP, #-8]!
    // 0x4fa0a8: r0 = setAll()
    //     0x4fa0a8: bl              #0x4fa140  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::setAll
    // 0x4fa0ac: add             SP, SP, #0x18
    // 0x4fa0b0: r0 = Null
    //     0x4fa0b0: mov             x0, NULL
    // 0x4fa0b4: LeaveFrame
    //     0x4fa0b4: mov             SP, fp
    //     0x4fa0b8: ldp             fp, lr, [SP], #0x10
    // 0x4fa0bc: ret
    //     0x4fa0bc: ret             
    // 0x4fa0c0: mov             x1, x0
    // 0x4fa0c4: b               #0x4fa0cc
    // 0x4fa0c8: r1 = 0
    //     0x4fa0c8: mov             x1, #0
    // 0x4fa0cc: r0 = 8
    //     0x4fa0cc: mov             x0, #8
    // 0x4fa0d0: sdiv            x2, x1, x0
    // 0x4fa0d4: LoadField: r0 = r3->field_7
    //     0x4fa0d4: ldur            w0, [x3, #7]
    // 0x4fa0d8: DecompressPointer r0
    //     0x4fa0d8: add             x0, x0, HEAP, lsl #32
    // 0x4fa0dc: LoadField: r1 = r0->field_b
    //     0x4fa0dc: ldur            w1, [x0, #0xb]
    // 0x4fa0e0: DecompressPointer r1
    //     0x4fa0e0: add             x1, x1, HEAP, lsl #32
    // 0x4fa0e4: r0 = LoadInt32Instr(r1)
    //     0x4fa0e4: sbfx            x0, x1, #1, #0x1f
    // 0x4fa0e8: mov             x1, x2
    // 0x4fa0ec: cmp             x1, x0
    // 0x4fa0f0: b.hs            #0x4fa13c
    // 0x4fa0f4: r0 = UnsupportedError()
    //     0x4fa0f4: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x4fa0f8: r5 = "Cannot change"
    //     0x4fa0f8: add             x5, PP, #0x38, lsl #12  ; [pp+0x38ed8] "Cannot change"
    //     0x4fa0fc: ldr             x5, [x5, #0xed8]
    // 0x4fa100: StoreField: r0->field_b = r5
    //     0x4fa100: stur            w5, [x0, #0xb]
    // 0x4fa104: r0 = Throw()
    //     0x4fa104: bl              #0xd67e38  ; ThrowStub
    // 0x4fa108: brk             #0
    // 0x4fa10c: r0 = UnsupportedError()
    //     0x4fa10c: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x4fa110: mov             x1, x0
    // 0x4fa114: r0 = "Cannot change"
    //     0x4fa114: add             x0, PP, #0x38, lsl #12  ; [pp+0x38ed8] "Cannot change"
    //     0x4fa118: ldr             x0, [x0, #0xed8]
    // 0x4fa11c: StoreField: r1->field_b = r0
    //     0x4fa11c: stur            w0, [x1, #0xb]
    // 0x4fa120: mov             x0, x1
    // 0x4fa124: r0 = Throw()
    //     0x4fa124: bl              #0xd67e38  ; ThrowStub
    // 0x4fa128: brk             #0
    // 0x4fa12c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fa12c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fa130: b               #0x4f9e30
    // 0x4fa134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fa134: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fa138: b               #0x4fa010
    // 0x4fa13c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fa13c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ setAll(/* No info */) {
    // ** addr: 0x4fa140, size: 0x1e4
    // 0x4fa140: EnterFrame
    //     0x4fa140: stp             fp, lr, [SP, #-0x10]!
    //     0x4fa144: mov             fp, SP
    // 0x4fa148: AllocStack(0x8)
    //     0x4fa148: sub             SP, SP, #8
    // 0x4fa14c: CheckStackOverflow
    //     0x4fa14c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fa150: cmp             SP, x16
    //     0x4fa154: b.ls            #0x4fa314
    // 0x4fa158: ldr             x0, [fp, #0x10]
    // 0x4fa15c: r2 = Null
    //     0x4fa15c: mov             x2, NULL
    // 0x4fa160: r1 = Null
    //     0x4fa160: mov             x1, NULL
    // 0x4fa164: cmp             w0, NULL
    // 0x4fa168: b.eq            #0x4fa20c
    // 0x4fa16c: branchIfSmi(r0, 0x4fa20c)
    //     0x4fa16c: tbz             w0, #0, #0x4fa20c
    // 0x4fa170: r3 = LoadClassIdInstr(r0)
    //     0x4fa170: ldur            x3, [x0, #-1]
    //     0x4fa174: ubfx            x3, x3, #0xc, #0x14
    // 0x4fa178: r17 = 5697
    //     0x4fa178: mov             x17, #0x1641
    // 0x4fa17c: cmp             x3, x17
    // 0x4fa180: b.eq            #0x4fa214
    // 0x4fa184: sub             x3, x3, #0x59
    // 0x4fa188: cmp             x3, #2
    // 0x4fa18c: b.ls            #0x4fa214
    // 0x4fa190: r4 = LoadClassIdInstr(r0)
    //     0x4fa190: ldur            x4, [x0, #-1]
    //     0x4fa194: ubfx            x4, x4, #0xc, #0x14
    // 0x4fa198: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x4fa19c: ldr             x3, [x3, #0x18]
    // 0x4fa1a0: ldr             x3, [x3, x4, lsl #3]
    // 0x4fa1a4: LoadField: r3 = r3->field_2b
    //     0x4fa1a4: ldur            w3, [x3, #0x2b]
    // 0x4fa1a8: DecompressPointer r3
    //     0x4fa1a8: add             x3, x3, HEAP, lsl #32
    // 0x4fa1ac: cmp             w3, NULL
    // 0x4fa1b0: b.eq            #0x4fa20c
    // 0x4fa1b4: LoadField: r3 = r3->field_f
    //     0x4fa1b4: ldur            w3, [x3, #0xf]
    // 0x4fa1b8: lsr             x3, x3, #4
    // 0x4fa1bc: r17 = 5697
    //     0x4fa1bc: mov             x17, #0x1641
    // 0x4fa1c0: cmp             x3, x17
    // 0x4fa1c4: b.eq            #0x4fa214
    // 0x4fa1c8: r3 = SubtypeTestCache
    //     0x4fa1c8: add             x3, PP, #0x41, lsl #12  ; [pp+0x41320] SubtypeTestCache
    //     0x4fa1cc: ldr             x3, [x3, #0x320]
    // 0x4fa1d0: r24 = Subtype1TestCacheStub
    //     0x4fa1d0: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x4fa1d4: LoadField: r30 = r24->field_7
    //     0x4fa1d4: ldur            lr, [x24, #7]
    // 0x4fa1d8: blr             lr
    // 0x4fa1dc: cmp             w7, NULL
    // 0x4fa1e0: b.eq            #0x4fa1ec
    // 0x4fa1e4: tbnz            w7, #4, #0x4fa20c
    // 0x4fa1e8: b               #0x4fa214
    // 0x4fa1ec: r8 = List
    //     0x4fa1ec: add             x8, PP, #0x41, lsl #12  ; [pp+0x41328] Type: List
    //     0x4fa1f0: ldr             x8, [x8, #0x328]
    // 0x4fa1f4: r3 = SubtypeTestCache
    //     0x4fa1f4: add             x3, PP, #0x41, lsl #12  ; [pp+0x41330] SubtypeTestCache
    //     0x4fa1f8: ldr             x3, [x3, #0x330]
    // 0x4fa1fc: r24 = InstanceOfStub
    //     0x4fa1fc: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x4fa200: LoadField: r30 = r24->field_7
    //     0x4fa200: ldur            lr, [x24, #7]
    // 0x4fa204: blr             lr
    // 0x4fa208: b               #0x4fa218
    // 0x4fa20c: r0 = false
    //     0x4fa20c: add             x0, NULL, #0x30  ; false
    // 0x4fa210: b               #0x4fa218
    // 0x4fa214: r0 = true
    //     0x4fa214: add             x0, NULL, #0x20  ; true
    // 0x4fa218: tbnz            w0, #4, #0x4fa264
    // 0x4fa21c: ldr             x1, [fp, #0x10]
    // 0x4fa220: r0 = LoadClassIdInstr(r1)
    //     0x4fa220: ldur            x0, [x1, #-1]
    //     0x4fa224: ubfx            x0, x0, #0xc, #0x14
    // 0x4fa228: SaveReg r1
    //     0x4fa228: str             x1, [SP, #-8]!
    // 0x4fa22c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x4fa22c: mov             x17, #0xb8ea
    //     0x4fa230: add             lr, x0, x17
    //     0x4fa234: ldr             lr, [x21, lr, lsl #3]
    //     0x4fa238: blr             lr
    // 0x4fa23c: add             SP, SP, #8
    // 0x4fa240: r1 = LoadInt32Instr(r0)
    //     0x4fa240: sbfx            x1, x0, #1, #0x1f
    // 0x4fa244: ldr             x16, [fp, #0x20]
    // 0x4fa248: stp             xzr, x16, [SP, #-0x10]!
    // 0x4fa24c: ldr             x16, [fp, #0x10]
    // 0x4fa250: stp             x16, x1, [SP, #-0x10]!
    // 0x4fa254: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x4fa254: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x4fa258: r0 = setRange()
    //     0x4fa258: bl              #0x504b04  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::setRange
    // 0x4fa25c: add             SP, SP, #0x20
    // 0x4fa260: b               #0x4fa2c0
    // 0x4fa264: ldr             x0, [fp, #0x10]
    // 0x4fa268: r1 = LoadClassIdInstr(r0)
    //     0x4fa268: ldur            x1, [x0, #-1]
    //     0x4fa26c: ubfx            x1, x1, #0xc, #0x14
    // 0x4fa270: SaveReg r0
    //     0x4fa270: str             x0, [SP, #-8]!
    // 0x4fa274: mov             x0, x1
    // 0x4fa278: r0 = GDT[cid_x0 + 0xb940]()
    //     0x4fa278: mov             x17, #0xb940
    //     0x4fa27c: add             lr, x0, x17
    //     0x4fa280: ldr             lr, [x21, lr, lsl #3]
    //     0x4fa284: blr             lr
    // 0x4fa288: add             SP, SP, #8
    // 0x4fa28c: mov             x1, x0
    // 0x4fa290: stur            x1, [fp, #-8]
    // 0x4fa294: CheckStackOverflow
    //     0x4fa294: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fa298: cmp             SP, x16
    //     0x4fa29c: b.ls            #0x4fa31c
    // 0x4fa2a0: r0 = LoadClassIdInstr(r1)
    //     0x4fa2a0: ldur            x0, [x1, #-1]
    //     0x4fa2a4: ubfx            x0, x0, #0xc, #0x14
    // 0x4fa2a8: SaveReg r1
    //     0x4fa2a8: str             x1, [SP, #-8]!
    // 0x4fa2ac: r0 = GDT[cid_x0 + 0x541]()
    //     0x4fa2ac: add             lr, x0, #0x541
    //     0x4fa2b0: ldr             lr, [x21, lr, lsl #3]
    //     0x4fa2b4: blr             lr
    // 0x4fa2b8: add             SP, SP, #8
    // 0x4fa2bc: tbz             w0, #4, #0x4fa2d0
    // 0x4fa2c0: r0 = Null
    //     0x4fa2c0: mov             x0, NULL
    // 0x4fa2c4: LeaveFrame
    //     0x4fa2c4: mov             SP, fp
    //     0x4fa2c8: ldp             fp, lr, [SP], #0x10
    // 0x4fa2cc: ret
    //     0x4fa2cc: ret             
    // 0x4fa2d0: ldur            x0, [fp, #-8]
    // 0x4fa2d4: r1 = LoadClassIdInstr(r0)
    //     0x4fa2d4: ldur            x1, [x0, #-1]
    //     0x4fa2d8: ubfx            x1, x1, #0xc, #0x14
    // 0x4fa2dc: SaveReg r0
    //     0x4fa2dc: str             x0, [SP, #-8]!
    // 0x4fa2e0: mov             x0, x1
    // 0x4fa2e4: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x4fa2e4: add             lr, x0, #0x5ca
    //     0x4fa2e8: ldr             lr, [x21, lr, lsl #3]
    //     0x4fa2ec: blr             lr
    // 0x4fa2f0: add             SP, SP, #8
    // 0x4fa2f4: r0 = UnsupportedError()
    //     0x4fa2f4: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x4fa2f8: mov             x1, x0
    // 0x4fa2fc: r0 = "cannot change"
    //     0x4fa2fc: add             x0, PP, #0x38, lsl #12  ; [pp+0x38f10] "cannot change"
    //     0x4fa300: ldr             x0, [x0, #0xf10]
    // 0x4fa304: StoreField: r1->field_b = r0
    //     0x4fa304: stur            w0, [x1, #0xb]
    // 0x4fa308: mov             x0, x1
    // 0x4fa30c: r0 = Throw()
    //     0x4fa30c: bl              #0xd67e38  ; ThrowStub
    // 0x4fa310: brk             #0
    // 0x4fa314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fa314: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fa318: b               #0x4fa158
    // 0x4fa31c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fa31c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fa320: b               #0x4fa2a0
  }
  bool removeLast(_BoolList&Object&ListMixin) {
    // ** addr: 0x502dbc, size: 0x84
    // 0x502dbc: EnterFrame
    //     0x502dbc: stp             fp, lr, [SP, #-0x10]!
    //     0x502dc0: mov             fp, SP
    // 0x502dc4: CheckStackOverflow
    //     0x502dc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x502dc8: cmp             SP, x16
    //     0x502dcc: b.ls            #0x502e34
    // 0x502dd0: ldr             x0, [fp, #0x10]
    // 0x502dd4: LoadField: r1 = r0->field_b
    //     0x502dd4: ldur            x1, [x0, #0xb]
    // 0x502dd8: cbnz            x1, #0x502de8
    // 0x502ddc: r0 = noElement()
    //     0x502ddc: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x502de0: r0 = Throw()
    //     0x502de0: bl              #0xd67e38  ; ThrowStub
    // 0x502de4: brk             #0
    // 0x502de8: r2 = 8
    //     0x502de8: mov             x2, #8
    // 0x502dec: sub             x3, x1, #1
    // 0x502df0: sdiv            x1, x3, x2
    // 0x502df4: LoadField: r2 = r0->field_7
    //     0x502df4: ldur            w2, [x0, #7]
    // 0x502df8: DecompressPointer r2
    //     0x502df8: add             x2, x2, HEAP, lsl #32
    // 0x502dfc: LoadField: r0 = r2->field_b
    //     0x502dfc: ldur            w0, [x2, #0xb]
    // 0x502e00: DecompressPointer r0
    //     0x502e00: add             x0, x0, HEAP, lsl #32
    // 0x502e04: r2 = LoadInt32Instr(r0)
    //     0x502e04: sbfx            x2, x0, #1, #0x1f
    // 0x502e08: mov             x0, x2
    // 0x502e0c: cmp             x1, x0
    // 0x502e10: b.hs            #0x502e3c
    // 0x502e14: r0 = UnsupportedError()
    //     0x502e14: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x502e18: mov             x1, x0
    // 0x502e1c: r0 = "Cannot change"
    //     0x502e1c: add             x0, PP, #0x38, lsl #12  ; [pp+0x38ed8] "Cannot change"
    //     0x502e20: ldr             x0, [x0, #0xed8]
    // 0x502e24: StoreField: r1->field_b = r0
    //     0x502e24: stur            w0, [x1, #0xb]
    // 0x502e28: mov             x0, x1
    // 0x502e2c: r0 = Throw()
    //     0x502e2c: bl              #0xd67e38  ; ThrowStub
    // 0x502e30: brk             #0
    // 0x502e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x502e34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x502e38: b               #0x502dd0
    // 0x502e3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x502e3c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ insert(/* No info */) {
    // ** addr: 0x503d14, size: 0xec
    // 0x503d14: EnterFrame
    //     0x503d14: stp             fp, lr, [SP, #-0x10]!
    //     0x503d18: mov             fp, SP
    // 0x503d1c: AllocStack(0x8)
    //     0x503d1c: sub             SP, SP, #8
    // 0x503d20: CheckStackOverflow
    //     0x503d20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x503d24: cmp             SP, x16
    //     0x503d28: b.ls            #0x503df8
    // 0x503d2c: ldr             x0, [fp, #0x10]
    // 0x503d30: r2 = Null
    //     0x503d30: mov             x2, NULL
    // 0x503d34: r1 = Null
    //     0x503d34: mov             x1, NULL
    // 0x503d38: r4 = 59
    //     0x503d38: mov             x4, #0x3b
    // 0x503d3c: branchIfSmi(r0, 0x503d48)
    //     0x503d3c: tbz             w0, #0, #0x503d48
    // 0x503d40: r4 = LoadClassIdInstr(r0)
    //     0x503d40: ldur            x4, [x0, #-1]
    //     0x503d44: ubfx            x4, x4, #0xc, #0x14
    // 0x503d48: cmp             x4, #0x3e
    // 0x503d4c: b.eq            #0x503d60
    // 0x503d50: r8 = bool
    //     0x503d50: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0x503d54: r3 = Null
    //     0x503d54: add             x3, PP, #0x41, lsl #12  ; [pp+0x41338] Null
    //     0x503d58: ldr             x3, [x3, #0x338]
    // 0x503d5c: r0 = bool()
    //     0x503d5c: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0x503d60: ldr             x0, [fp, #0x20]
    // 0x503d64: LoadField: r1 = r0->field_b
    //     0x503d64: ldur            x1, [x0, #0xb]
    // 0x503d68: stur            x1, [fp, #-8]
    // 0x503d6c: stp             xzr, xzr, [SP, #-0x10]!
    // 0x503d70: r16 = "index"
    //     0x503d70: ldr             x16, [PP, #0xd38]  ; [pp+0xd38] "index"
    // 0x503d74: stp             x16, x1, [SP, #-0x10]!
    // 0x503d78: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x503d78: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x503d7c: r0 = checkValueInInterval()
    //     0x503d7c: bl              #0x4c6ec8  ; [dart:core] RangeError::checkValueInInterval
    // 0x503d80: add             SP, SP, #0x20
    // 0x503d84: ldr             x16, [fp, #0x20]
    // 0x503d88: ldr             lr, [fp, #0x10]
    // 0x503d8c: stp             lr, x16, [SP, #-0x10]!
    // 0x503d90: r0 = add()
    //     0x503d90: bl              #0x515a34  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::add
    // 0x503d94: add             SP, SP, #0x10
    // 0x503d98: ldur            x0, [fp, #-8]
    // 0x503d9c: cbnz            x0, #0x503db0
    // 0x503da0: r0 = Null
    //     0x503da0: mov             x0, NULL
    // 0x503da4: LeaveFrame
    //     0x503da4: mov             SP, fp
    //     0x503da8: ldp             fp, lr, [SP], #0x10
    // 0x503dac: ret
    //     0x503dac: ret             
    // 0x503db0: add             x1, x0, #1
    // 0x503db4: ldr             x16, [fp, #0x20]
    // 0x503db8: r30 = 2
    //     0x503db8: mov             lr, #2
    // 0x503dbc: stp             lr, x16, [SP, #-0x10]!
    // 0x503dc0: ldr             x16, [fp, #0x20]
    // 0x503dc4: stp             x16, x1, [SP, #-0x10]!
    // 0x503dc8: SaveReg rZR
    //     0x503dc8: str             xzr, [SP, #-8]!
    // 0x503dcc: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x503dcc: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x503dd0: r0 = setRange()
    //     0x503dd0: bl              #0x504b04  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::setRange
    // 0x503dd4: add             SP, SP, #0x28
    // 0x503dd8: r0 = UnsupportedError()
    //     0x503dd8: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x503ddc: mov             x1, x0
    // 0x503de0: r0 = "cannot change"
    //     0x503de0: add             x0, PP, #0x38, lsl #12  ; [pp+0x38f10] "cannot change"
    //     0x503de4: ldr             x0, [x0, #0xf10]
    // 0x503de8: StoreField: r1->field_b = r0
    //     0x503de8: stur            w0, [x1, #0xb]
    // 0x503dec: mov             x0, x1
    // 0x503df0: r0 = Throw()
    //     0x503df0: bl              #0xd67e38  ; ThrowStub
    // 0x503df4: brk             #0
    // 0x503df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x503df8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x503dfc: b               #0x503d2c
  }
  _ remove(/* No info */) {
    // ** addr: 0x504688, size: 0x134
    // 0x504688: EnterFrame
    //     0x504688: stp             fp, lr, [SP, #-0x10]!
    //     0x50468c: mov             fp, SP
    // 0x504690: CheckStackOverflow
    //     0x504690: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x504694: cmp             SP, x16
    //     0x504698: b.ls            #0x5047a8
    // 0x50469c: ldr             x2, [fp, #0x18]
    // 0x5046a0: LoadField: r3 = r2->field_b
    //     0x5046a0: ldur            x3, [x2, #0xb]
    // 0x5046a4: LoadField: r0 = r2->field_7
    //     0x5046a4: ldur            w0, [x2, #7]
    // 0x5046a8: DecompressPointer r0
    //     0x5046a8: add             x0, x0, HEAP, lsl #32
    // 0x5046ac: LoadField: r1 = r0->field_b
    //     0x5046ac: ldur            w1, [x0, #0xb]
    // 0x5046b0: DecompressPointer r1
    //     0x5046b0: add             x1, x1, HEAP, lsl #32
    // 0x5046b4: r4 = LoadInt32Instr(r1)
    //     0x5046b4: sbfx            x4, x1, #1, #0x1f
    // 0x5046b8: LoadField: r5 = r0->field_f
    //     0x5046b8: ldur            w5, [x0, #0xf]
    // 0x5046bc: DecompressPointer r5
    //     0x5046bc: add             x5, x5, HEAP, lsl #32
    // 0x5046c0: ldr             x10, [fp, #0x10]
    // 0x5046c4: r11 = 0
    //     0x5046c4: mov             x11, #0
    // 0x5046c8: r9 = 8
    //     0x5046c8: mov             x9, #8
    // 0x5046cc: r8 = 7
    //     0x5046cc: mov             x8, #7
    // 0x5046d0: r7 = 7
    //     0x5046d0: mov             x7, #7
    // 0x5046d4: r6 = 1
    //     0x5046d4: mov             x6, #1
    // 0x5046d8: CheckStackOverflow
    //     0x5046d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5046dc: cmp             SP, x16
    //     0x5046e0: b.ls            #0x5047b0
    // 0x5046e4: cmp             x11, x3
    // 0x5046e8: b.ge            #0x504798
    // 0x5046ec: sdiv            x12, x11, x9
    // 0x5046f0: mov             x0, x4
    // 0x5046f4: mov             x1, x12
    // 0x5046f8: cmp             x1, x0
    // 0x5046fc: b.hs            #0x5047b8
    // 0x504700: ArrayLoad: r0 = r5[r12]  ; Unknown_4
    //     0x504700: add             x16, x5, x12, lsl #2
    //     0x504704: ldur            w0, [x16, #0xf]
    // 0x504708: DecompressPointer r0
    //     0x504708: add             x0, x0, HEAP, lsl #32
    // 0x50470c: mov             x1, x11
    // 0x504710: ubfx            x1, x1, #0, #0x20
    // 0x504714: and             x12, x1, x7
    // 0x504718: ubfx            x12, x12, #0, #0x20
    // 0x50471c: sub             x1, x8, x12
    // 0x504720: r12 = LoadInt32Instr(r0)
    //     0x504720: sbfx            x12, x0, #1, #0x1f
    //     0x504724: tbz             w0, #0, #0x50472c
    //     0x504728: ldur            x12, [x0, #7]
    // 0x50472c: asr             x0, x12, x1
    // 0x504730: ubfx            x0, x0, #0, #0x20
    // 0x504734: and             x1, x0, x6
    // 0x504738: ubfx            x1, x1, #0, #0x20
    // 0x50473c: cmp             x1, #1
    // 0x504740: r16 = true
    //     0x504740: add             x16, NULL, #0x20  ; true
    // 0x504744: r17 = false
    //     0x504744: add             x17, NULL, #0x30  ; false
    // 0x504748: csel            x0, x16, x17, eq
    // 0x50474c: cmp             w0, w10
    // 0x504750: b.ne            #0x50478c
    // 0x504754: add             x3, x11, #1
    // 0x504758: r0 = BoxInt64Instr(r11)
    //     0x504758: sbfiz           x0, x11, #1, #0x1f
    //     0x50475c: cmp             x11, x0, asr #1
    //     0x504760: b.eq            #0x50476c
    //     0x504764: bl              #0xd69bb8
    //     0x504768: stur            x11, [x0, #7]
    // 0x50476c: stp             x0, x2, [SP, #-0x10]!
    // 0x504770: SaveReg r3
    //     0x504770: str             x3, [SP, #-8]!
    // 0x504774: r0 = _closeGap()
    //     0x504774: bl              #0x5047bc  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::_closeGap
    // 0x504778: add             SP, SP, #0x18
    // 0x50477c: r0 = true
    //     0x50477c: add             x0, NULL, #0x20  ; true
    // 0x504780: LeaveFrame
    //     0x504780: mov             SP, fp
    //     0x504784: ldp             fp, lr, [SP], #0x10
    // 0x504788: ret
    //     0x504788: ret             
    // 0x50478c: add             x0, x11, #1
    // 0x504790: mov             x11, x0
    // 0x504794: b               #0x5046d8
    // 0x504798: r0 = false
    //     0x504798: add             x0, NULL, #0x30  ; false
    // 0x50479c: LeaveFrame
    //     0x50479c: mov             SP, fp
    //     0x5047a0: ldp             fp, lr, [SP], #0x10
    // 0x5047a4: ret
    //     0x5047a4: ret             
    // 0x5047a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5047a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5047ac: b               #0x50469c
    // 0x5047b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5047b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5047b4: b               #0x5046e4
    // 0x5047b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5047b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _closeGap(/* No info */) {
    // ** addr: 0x5047bc, size: 0xa0
    // 0x5047bc: EnterFrame
    //     0x5047bc: stp             fp, lr, [SP, #-0x10]!
    //     0x5047c0: mov             fp, SP
    // 0x5047c4: ldr             x0, [fp, #0x20]
    // 0x5047c8: LoadField: r1 = r0->field_b
    //     0x5047c8: ldur            x1, [x0, #0xb]
    // 0x5047cc: CheckStackOverflow
    //     0x5047cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5047d0: cmp             SP, x16
    //     0x5047d4: b.ls            #0x504850
    // 0x5047d8: ldr             x2, [fp, #0x10]
    // 0x5047dc: cmp             x2, x1
    // 0x5047e0: b.ge            #0x504830
    // 0x5047e4: r1 = 8
    //     0x5047e4: mov             x1, #8
    // 0x5047e8: sdiv            x3, x2, x1
    // 0x5047ec: LoadField: r1 = r0->field_7
    //     0x5047ec: ldur            w1, [x0, #7]
    // 0x5047f0: DecompressPointer r1
    //     0x5047f0: add             x1, x1, HEAP, lsl #32
    // 0x5047f4: LoadField: r0 = r1->field_b
    //     0x5047f4: ldur            w0, [x1, #0xb]
    // 0x5047f8: DecompressPointer r0
    //     0x5047f8: add             x0, x0, HEAP, lsl #32
    // 0x5047fc: r1 = LoadInt32Instr(r0)
    //     0x5047fc: sbfx            x1, x0, #1, #0x1f
    // 0x504800: mov             x0, x1
    // 0x504804: mov             x1, x3
    // 0x504808: cmp             x1, x0
    // 0x50480c: b.hs            #0x504858
    // 0x504810: r0 = UnsupportedError()
    //     0x504810: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x504814: mov             x1, x0
    // 0x504818: r0 = "cannot change"
    //     0x504818: add             x0, PP, #0x38, lsl #12  ; [pp+0x38f10] "cannot change"
    //     0x50481c: ldr             x0, [x0, #0xf10]
    // 0x504820: StoreField: r1->field_b = r0
    //     0x504820: stur            w0, [x1, #0xb]
    // 0x504824: mov             x0, x1
    // 0x504828: r0 = Throw()
    //     0x504828: bl              #0xd67e38  ; ThrowStub
    // 0x50482c: brk             #0
    // 0x504830: r0 = UnsupportedError()
    //     0x504830: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x504834: mov             x1, x0
    // 0x504838: r0 = "Cannot change"
    //     0x504838: add             x0, PP, #0x38, lsl #12  ; [pp+0x38ed8] "Cannot change"
    //     0x50483c: ldr             x0, [x0, #0xed8]
    // 0x504840: StoreField: r1->field_b = r0
    //     0x504840: stur            w0, [x1, #0xb]
    // 0x504844: mov             x0, x1
    // 0x504848: r0 = Throw()
    //     0x504848: bl              #0xd67e38  ; ThrowStub
    // 0x50484c: brk             #0
    // 0x504850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x504850: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x504854: b               #0x5047d8
    // 0x504858: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x504858: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ setRange(/* No info */) {
    // ** addr: 0x504b04, size: 0x37c
    // 0x504b04: EnterFrame
    //     0x504b04: stp             fp, lr, [SP, #-0x10]!
    //     0x504b08: mov             fp, SP
    // 0x504b0c: AllocStack(0x38)
    //     0x504b0c: sub             SP, SP, #0x38
    // 0x504b10: SetupParameters(_BoolList&Object&ListMixin this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, dynamic _ /* r5, fp-0x18 */, dynamic _ /* r6, fp-0x10 */, [int _ = 0 /* r7, fp-0x8 */])
    //     0x504b10: mov             x0, x4
    //     0x504b14: ldur            w1, [x0, #0x13]
    //     0x504b18: add             x1, x1, HEAP, lsl #32
    //     0x504b1c: sub             x0, x1, #8
    //     0x504b20: add             x3, fp, w0, sxtw #2
    //     0x504b24: ldr             x3, [x3, #0x28]
    //     0x504b28: stur            x3, [fp, #-0x28]
    //     0x504b2c: add             x4, fp, w0, sxtw #2
    //     0x504b30: ldr             x4, [x4, #0x20]
    //     0x504b34: stur            x4, [fp, #-0x20]
    //     0x504b38: add             x5, fp, w0, sxtw #2
    //     0x504b3c: ldr             x5, [x5, #0x18]
    //     0x504b40: stur            x5, [fp, #-0x18]
    //     0x504b44: add             x6, fp, w0, sxtw #2
    //     0x504b48: ldr             x6, [x6, #0x10]
    //     0x504b4c: stur            x6, [fp, #-0x10]
    //     0x504b50: cmp             w0, #2
    //     0x504b54: b.lt            #0x504b74
    //     0x504b58: add             x1, fp, w0, sxtw #2
    //     0x504b5c: ldr             x1, [x1, #8]
    //     0x504b60: sbfx            x0, x1, #1, #0x1f
    //     0x504b64: tbz             w1, #0, #0x504b6c
    //     0x504b68: ldur            x0, [x1, #7]
    //     0x504b6c: mov             x7, x0
    //     0x504b70: b               #0x504b78
    //     0x504b74: mov             x7, #0
    //     0x504b78: stur            x7, [fp, #-8]
    // 0x504b7c: CheckStackOverflow
    //     0x504b7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x504b80: cmp             SP, x16
    //     0x504b84: b.ls            #0x504e68
    // 0x504b88: mov             x0, x6
    // 0x504b8c: r2 = Null
    //     0x504b8c: mov             x2, NULL
    // 0x504b90: r1 = Null
    //     0x504b90: mov             x1, NULL
    // 0x504b94: r8 = Iterable<bool>
    //     0x504b94: add             x8, PP, #0x41, lsl #12  ; [pp+0x412f0] Type: Iterable<bool>
    //     0x504b98: ldr             x8, [x8, #0x2f0]
    // 0x504b9c: r3 = Null
    //     0x504b9c: add             x3, PP, #0x41, lsl #12  ; [pp+0x41348] Null
    //     0x504ba0: ldr             x3, [x3, #0x348]
    // 0x504ba4: r0 = Iterable<bool>()
    //     0x504ba4: bl              #0x4fa324  ; IsType_Iterable<bool>_Stub
    // 0x504ba8: ldur            x0, [fp, #-0x28]
    // 0x504bac: LoadField: r2 = r0->field_b
    //     0x504bac: ldur            x2, [x0, #0xb]
    // 0x504bb0: ldur            x3, [fp, #-0x18]
    // 0x504bb4: r0 = BoxInt64Instr(r3)
    //     0x504bb4: sbfiz           x0, x3, #1, #0x1f
    //     0x504bb8: cmp             x3, x0, asr #1
    //     0x504bbc: b.eq            #0x504bc8
    //     0x504bc0: bl              #0xd69bb8
    //     0x504bc4: stur            x3, [x0, #7]
    // 0x504bc8: ldur            x16, [fp, #-0x20]
    // 0x504bcc: stp             x0, x16, [SP, #-0x10]!
    // 0x504bd0: SaveReg r2
    //     0x504bd0: str             x2, [SP, #-8]!
    // 0x504bd4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x504bd4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x504bd8: r0 = checkValidRange()
    //     0x504bd8: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0x504bdc: add             SP, SP, #0x18
    // 0x504be0: ldur            x0, [fp, #-0x20]
    // 0x504be4: r1 = LoadInt32Instr(r0)
    //     0x504be4: sbfx            x1, x0, #1, #0x1f
    //     0x504be8: tbz             w0, #0, #0x504bf0
    //     0x504bec: ldur            x1, [x0, #7]
    // 0x504bf0: ldur            x0, [fp, #-0x18]
    // 0x504bf4: stur            x1, [fp, #-0x38]
    // 0x504bf8: sub             x2, x0, x1
    // 0x504bfc: stur            x2, [fp, #-0x30]
    // 0x504c00: cbnz            x2, #0x504c14
    // 0x504c04: r0 = Null
    //     0x504c04: mov             x0, NULL
    // 0x504c08: LeaveFrame
    //     0x504c08: mov             SP, fp
    //     0x504c0c: ldp             fp, lr, [SP], #0x10
    // 0x504c10: ret
    //     0x504c10: ret             
    // 0x504c14: ldur            x0, [fp, #-8]
    // 0x504c18: r16 = "skipCount"
    //     0x504c18: ldr             x16, [PP, #0x13c0]  ; [pp+0x13c0] "skipCount"
    // 0x504c1c: stp             x16, x0, [SP, #-0x10]!
    // 0x504c20: r0 = checkNotNegative()
    //     0x504c20: bl              #0x4c26d4  ; [dart:core] RangeError::checkNotNegative
    // 0x504c24: add             SP, SP, #0x10
    // 0x504c28: ldur            x0, [fp, #-0x10]
    // 0x504c2c: r2 = Null
    //     0x504c2c: mov             x2, NULL
    // 0x504c30: r1 = Null
    //     0x504c30: mov             x1, NULL
    // 0x504c34: cmp             w0, NULL
    // 0x504c38: b.eq            #0x504c8c
    // 0x504c3c: branchIfSmi(r0, 0x504c8c)
    //     0x504c3c: tbz             w0, #0, #0x504c8c
    // 0x504c40: r8 = List<bool>
    //     0x504c40: add             x8, PP, #0x41, lsl #12  ; [pp+0x41358] Type: List<bool>
    //     0x504c44: ldr             x8, [x8, #0x358]
    // 0x504c48: r3 = SubtypeTestCache
    //     0x504c48: add             x3, PP, #0x41, lsl #12  ; [pp+0x41360] SubtypeTestCache
    //     0x504c4c: ldr             x3, [x3, #0x360]
    // 0x504c50: r24 = Subtype3TestCacheStub
    //     0x504c50: ldr             x24, [PP, #0x10]  ; [pp+0x10] Stub: Subtype3TestCache (0x4ae294)
    // 0x504c54: LoadField: r30 = r24->field_7
    //     0x504c54: ldur            lr, [x24, #7]
    // 0x504c58: blr             lr
    // 0x504c5c: cmp             w7, NULL
    // 0x504c60: b.eq            #0x504c6c
    // 0x504c64: tbnz            w7, #4, #0x504c8c
    // 0x504c68: b               #0x504c94
    // 0x504c6c: r8 = List<bool>
    //     0x504c6c: add             x8, PP, #0x41, lsl #12  ; [pp+0x41368] Type: List<bool>
    //     0x504c70: ldr             x8, [x8, #0x368]
    // 0x504c74: r3 = SubtypeTestCache
    //     0x504c74: add             x3, PP, #0x41, lsl #12  ; [pp+0x41370] SubtypeTestCache
    //     0x504c78: ldr             x3, [x3, #0x370]
    // 0x504c7c: r24 = InstanceOfStub
    //     0x504c7c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x504c80: LoadField: r30 = r24->field_7
    //     0x504c80: ldur            lr, [x24, #7]
    // 0x504c84: blr             lr
    // 0x504c88: b               #0x504c98
    // 0x504c8c: r0 = false
    //     0x504c8c: add             x0, NULL, #0x30  ; false
    // 0x504c90: b               #0x504c98
    // 0x504c94: r0 = true
    //     0x504c94: add             x0, NULL, #0x20  ; true
    // 0x504c98: tbnz            w0, #4, #0x504ca8
    // 0x504c9c: ldur            x3, [fp, #-0x10]
    // 0x504ca0: ldur            x2, [fp, #-8]
    // 0x504ca4: b               #0x504d08
    // 0x504ca8: ldur            x1, [fp, #-0x10]
    // 0x504cac: ldur            x0, [fp, #-8]
    // 0x504cb0: r2 = LoadClassIdInstr(r1)
    //     0x504cb0: ldur            x2, [x1, #-1]
    //     0x504cb4: ubfx            x2, x2, #0xc, #0x14
    // 0x504cb8: stp             x0, x1, [SP, #-0x10]!
    // 0x504cbc: mov             x0, x2
    // 0x504cc0: r0 = GDT[cid_x0 + 0xcd65]()
    //     0x504cc0: mov             x17, #0xcd65
    //     0x504cc4: add             lr, x0, x17
    //     0x504cc8: ldr             lr, [x21, lr, lsl #3]
    //     0x504ccc: blr             lr
    // 0x504cd0: add             SP, SP, #0x10
    // 0x504cd4: r1 = LoadClassIdInstr(r0)
    //     0x504cd4: ldur            x1, [x0, #-1]
    //     0x504cd8: ubfx            x1, x1, #0xc, #0x14
    // 0x504cdc: r16 = false
    //     0x504cdc: add             x16, NULL, #0x30  ; false
    // 0x504ce0: stp             x16, x0, [SP, #-0x10]!
    // 0x504ce4: mov             x0, x1
    // 0x504ce8: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0x504ce8: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0x504cec: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0x504cec: mov             x17, #0xc8a1
    //     0x504cf0: add             lr, x0, x17
    //     0x504cf4: ldr             lr, [x21, lr, lsl #3]
    //     0x504cf8: blr             lr
    // 0x504cfc: add             SP, SP, #0x10
    // 0x504d00: mov             x3, x0
    // 0x504d04: r2 = 0
    //     0x504d04: mov             x2, #0
    // 0x504d08: ldur            x1, [fp, #-0x30]
    // 0x504d0c: stur            x3, [fp, #-0x10]
    // 0x504d10: stur            x2, [fp, #-0x18]
    // 0x504d14: add             x4, x2, x1
    // 0x504d18: stur            x4, [fp, #-8]
    // 0x504d1c: r0 = LoadClassIdInstr(r3)
    //     0x504d1c: ldur            x0, [x3, #-1]
    //     0x504d20: ubfx            x0, x0, #0xc, #0x14
    // 0x504d24: SaveReg r3
    //     0x504d24: str             x3, [SP, #-8]!
    // 0x504d28: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x504d28: mov             x17, #0xb8ea
    //     0x504d2c: add             lr, x0, x17
    //     0x504d30: ldr             lr, [x21, lr, lsl #3]
    //     0x504d34: blr             lr
    // 0x504d38: add             SP, SP, #8
    // 0x504d3c: r1 = LoadInt32Instr(r0)
    //     0x504d3c: sbfx            x1, x0, #1, #0x1f
    //     0x504d40: tbz             w0, #0, #0x504d48
    //     0x504d44: ldur            x1, [x0, #7]
    // 0x504d48: ldur            x0, [fp, #-8]
    // 0x504d4c: cmp             x0, x1
    // 0x504d50: b.gt            #0x504db4
    // 0x504d54: ldur            x2, [fp, #-0x18]
    // 0x504d58: ldur            x0, [fp, #-0x38]
    // 0x504d5c: cmp             x2, x0
    // 0x504d60: b.ge            #0x504d80
    // 0x504d64: ldur            x0, [fp, #-0x30]
    // 0x504d68: sub             x1, x0, #1
    // 0x504d6c: CheckStackOverflow
    //     0x504d6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x504d70: cmp             SP, x16
    //     0x504d74: b.ls            #0x504e70
    // 0x504d78: tbnz            x1, #0x3f, #0x504da4
    // 0x504d7c: b               #0x504dc0
    // 0x504d80: ldur            x0, [fp, #-0x30]
    // 0x504d84: ldur            x3, [fp, #-0x10]
    // 0x504d88: r4 = "cannot change"
    //     0x504d88: add             x4, PP, #0x38, lsl #12  ; [pp+0x38f10] "cannot change"
    //     0x504d8c: ldr             x4, [x4, #0xf10]
    // 0x504d90: CheckStackOverflow
    //     0x504d90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x504d94: cmp             SP, x16
    //     0x504d98: b.ls            #0x504e78
    // 0x504d9c: cmp             x0, #0
    // 0x504da0: b.gt            #0x504e14
    // 0x504da4: r0 = Null
    //     0x504da4: mov             x0, NULL
    // 0x504da8: LeaveFrame
    //     0x504da8: mov             SP, fp
    //     0x504dac: ldp             fp, lr, [SP], #0x10
    // 0x504db0: ret
    //     0x504db0: ret             
    // 0x504db4: r0 = tooFew()
    //     0x504db4: bl              #0x4fa850  ; [dart:_internal] IterableElementError::tooFew
    // 0x504db8: r0 = Throw()
    //     0x504db8: bl              #0xd67e38  ; ThrowStub
    // 0x504dbc: brk             #0
    // 0x504dc0: ldur            x3, [fp, #-0x10]
    // 0x504dc4: add             x4, x2, x1
    // 0x504dc8: r0 = BoxInt64Instr(r4)
    //     0x504dc8: sbfiz           x0, x4, #1, #0x1f
    //     0x504dcc: cmp             x4, x0, asr #1
    //     0x504dd0: b.eq            #0x504ddc
    //     0x504dd4: bl              #0xd69bb8
    //     0x504dd8: stur            x4, [x0, #7]
    // 0x504ddc: r1 = LoadClassIdInstr(r3)
    //     0x504ddc: ldur            x1, [x3, #-1]
    //     0x504de0: ubfx            x1, x1, #0xc, #0x14
    // 0x504de4: stp             x0, x3, [SP, #-0x10]!
    // 0x504de8: mov             x0, x1
    // 0x504dec: r0 = GDT[cid_x0 + -0xd83]()
    //     0x504dec: sub             lr, x0, #0xd83
    //     0x504df0: ldr             lr, [x21, lr, lsl #3]
    //     0x504df4: blr             lr
    // 0x504df8: add             SP, SP, #0x10
    // 0x504dfc: r0 = UnsupportedError()
    //     0x504dfc: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x504e00: r4 = "cannot change"
    //     0x504e00: add             x4, PP, #0x38, lsl #12  ; [pp+0x38f10] "cannot change"
    //     0x504e04: ldr             x4, [x4, #0xf10]
    // 0x504e08: StoreField: r0->field_b = r4
    //     0x504e08: stur            w4, [x0, #0xb]
    // 0x504e0c: r0 = Throw()
    //     0x504e0c: bl              #0xd67e38  ; ThrowStub
    // 0x504e10: brk             #0
    // 0x504e14: r0 = BoxInt64Instr(r2)
    //     0x504e14: sbfiz           x0, x2, #1, #0x1f
    //     0x504e18: cmp             x2, x0, asr #1
    //     0x504e1c: b.eq            #0x504e28
    //     0x504e20: bl              #0xd69bb8
    //     0x504e24: stur            x2, [x0, #7]
    // 0x504e28: r1 = LoadClassIdInstr(r3)
    //     0x504e28: ldur            x1, [x3, #-1]
    //     0x504e2c: ubfx            x1, x1, #0xc, #0x14
    // 0x504e30: stp             x0, x3, [SP, #-0x10]!
    // 0x504e34: mov             x0, x1
    // 0x504e38: r0 = GDT[cid_x0 + -0xd83]()
    //     0x504e38: sub             lr, x0, #0xd83
    //     0x504e3c: ldr             lr, [x21, lr, lsl #3]
    //     0x504e40: blr             lr
    // 0x504e44: add             SP, SP, #0x10
    // 0x504e48: r0 = UnsupportedError()
    //     0x504e48: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x504e4c: mov             x1, x0
    // 0x504e50: r0 = "cannot change"
    //     0x504e50: add             x0, PP, #0x38, lsl #12  ; [pp+0x38f10] "cannot change"
    //     0x504e54: ldr             x0, [x0, #0xf10]
    // 0x504e58: StoreField: r1->field_b = r0
    //     0x504e58: stur            w0, [x1, #0xb]
    // 0x504e5c: mov             x0, x1
    // 0x504e60: r0 = Throw()
    //     0x504e60: bl              #0xd67e38  ; ThrowStub
    // 0x504e64: brk             #0
    // 0x504e68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x504e68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x504e6c: b               #0x504b88
    // 0x504e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x504e70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x504e74: b               #0x504d78
    // 0x504e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x504e78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x504e7c: b               #0x504d9c
  }
  _ removeAt(/* No info */) {
    // ** addr: 0x50744c, size: 0xf4
    // 0x50744c: EnterFrame
    //     0x50744c: stp             fp, lr, [SP, #-0x10]!
    //     0x507450: mov             fp, SP
    // 0x507454: AllocStack(0x8)
    //     0x507454: sub             SP, SP, #8
    // 0x507458: r0 = 8
    //     0x507458: mov             x0, #8
    // 0x50745c: r4 = 7
    //     0x50745c: mov             x4, #7
    // 0x507460: r3 = 7
    //     0x507460: mov             x3, #7
    // 0x507464: r2 = 1
    //     0x507464: mov             x2, #1
    // 0x507468: CheckStackOverflow
    //     0x507468: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50746c: cmp             SP, x16
    //     0x507470: b.ls            #0x507534
    // 0x507474: ldr             x5, [fp, #0x10]
    // 0x507478: sdiv            x6, x5, x0
    // 0x50747c: ldr             x7, [fp, #0x18]
    // 0x507480: LoadField: r8 = r7->field_7
    //     0x507480: ldur            w8, [x7, #7]
    // 0x507484: DecompressPointer r8
    //     0x507484: add             x8, x8, HEAP, lsl #32
    // 0x507488: LoadField: r0 = r8->field_b
    //     0x507488: ldur            w0, [x8, #0xb]
    // 0x50748c: DecompressPointer r0
    //     0x50748c: add             x0, x0, HEAP, lsl #32
    // 0x507490: r1 = LoadInt32Instr(r0)
    //     0x507490: sbfx            x1, x0, #1, #0x1f
    // 0x507494: mov             x0, x1
    // 0x507498: mov             x1, x6
    // 0x50749c: cmp             x1, x0
    // 0x5074a0: b.hs            #0x50753c
    // 0x5074a4: LoadField: r0 = r8->field_f
    //     0x5074a4: ldur            w0, [x8, #0xf]
    // 0x5074a8: DecompressPointer r0
    //     0x5074a8: add             x0, x0, HEAP, lsl #32
    // 0x5074ac: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0x5074ac: add             x16, x0, x6, lsl #2
    //     0x5074b0: ldur            w1, [x16, #0xf]
    // 0x5074b4: DecompressPointer r1
    //     0x5074b4: add             x1, x1, HEAP, lsl #32
    // 0x5074b8: mov             x0, x5
    // 0x5074bc: ubfx            x0, x0, #0, #0x20
    // 0x5074c0: and             x6, x0, x3
    // 0x5074c4: ubfx            x6, x6, #0, #0x20
    // 0x5074c8: sub             x0, x4, x6
    // 0x5074cc: r3 = LoadInt32Instr(r1)
    //     0x5074cc: sbfx            x3, x1, #1, #0x1f
    //     0x5074d0: tbz             w1, #0, #0x5074d8
    //     0x5074d4: ldur            x3, [x1, #7]
    // 0x5074d8: asr             x1, x3, x0
    // 0x5074dc: ubfx            x1, x1, #0, #0x20
    // 0x5074e0: and             x0, x1, x2
    // 0x5074e4: ubfx            x0, x0, #0, #0x20
    // 0x5074e8: cmp             x0, #1
    // 0x5074ec: r16 = true
    //     0x5074ec: add             x16, NULL, #0x20  ; true
    // 0x5074f0: r17 = false
    //     0x5074f0: add             x17, NULL, #0x30  ; false
    // 0x5074f4: csel            x2, x16, x17, eq
    // 0x5074f8: stur            x2, [fp, #-8]
    // 0x5074fc: add             x3, x5, #1
    // 0x507500: r0 = BoxInt64Instr(r5)
    //     0x507500: sbfiz           x0, x5, #1, #0x1f
    //     0x507504: cmp             x5, x0, asr #1
    //     0x507508: b.eq            #0x507514
    //     0x50750c: bl              #0xd69bb8
    //     0x507510: stur            x5, [x0, #7]
    // 0x507514: stp             x0, x7, [SP, #-0x10]!
    // 0x507518: SaveReg r3
    //     0x507518: str             x3, [SP, #-8]!
    // 0x50751c: r0 = _closeGap()
    //     0x50751c: bl              #0x5047bc  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::_closeGap
    // 0x507520: add             SP, SP, #0x18
    // 0x507524: ldur            x0, [fp, #-8]
    // 0x507528: LeaveFrame
    //     0x507528: mov             SP, fp
    //     0x50752c: ldp             fp, lr, [SP], #0x10
    // 0x507530: ret
    //     0x507530: ret             
    // 0x507534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x507534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x507538: b               #0x507474
    // 0x50753c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x50753c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ addAll(/* No info */) {
    // ** addr: 0x507618, size: 0xf8
    // 0x507618: EnterFrame
    //     0x507618: stp             fp, lr, [SP, #-0x10]!
    //     0x50761c: mov             fp, SP
    // 0x507620: AllocStack(0x8)
    //     0x507620: sub             SP, SP, #8
    // 0x507624: CheckStackOverflow
    //     0x507624: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x507628: cmp             SP, x16
    //     0x50762c: b.ls            #0x507700
    // 0x507630: ldr             x0, [fp, #0x10]
    // 0x507634: r2 = Null
    //     0x507634: mov             x2, NULL
    // 0x507638: r1 = Null
    //     0x507638: mov             x1, NULL
    // 0x50763c: r8 = Iterable<bool>
    //     0x50763c: add             x8, PP, #0x41, lsl #12  ; [pp+0x412f0] Type: Iterable<bool>
    //     0x507640: ldr             x8, [x8, #0x2f0]
    // 0x507644: r3 = Null
    //     0x507644: add             x3, PP, #0x41, lsl #12  ; [pp+0x41398] Null
    //     0x507648: ldr             x3, [x3, #0x398]
    // 0x50764c: r0 = Iterable<bool>()
    //     0x50764c: bl              #0x4fa324  ; IsType_Iterable<bool>_Stub
    // 0x507650: ldr             x0, [fp, #0x10]
    // 0x507654: r1 = LoadClassIdInstr(r0)
    //     0x507654: ldur            x1, [x0, #-1]
    //     0x507658: ubfx            x1, x1, #0xc, #0x14
    // 0x50765c: SaveReg r0
    //     0x50765c: str             x0, [SP, #-8]!
    // 0x507660: mov             x0, x1
    // 0x507664: r0 = GDT[cid_x0 + 0xb940]()
    //     0x507664: mov             x17, #0xb940
    //     0x507668: add             lr, x0, x17
    //     0x50766c: ldr             lr, [x21, lr, lsl #3]
    //     0x507670: blr             lr
    // 0x507674: add             SP, SP, #8
    // 0x507678: mov             x1, x0
    // 0x50767c: stur            x1, [fp, #-8]
    // 0x507680: CheckStackOverflow
    //     0x507680: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x507684: cmp             SP, x16
    //     0x507688: b.ls            #0x507708
    // 0x50768c: r0 = LoadClassIdInstr(r1)
    //     0x50768c: ldur            x0, [x1, #-1]
    //     0x507690: ubfx            x0, x0, #0xc, #0x14
    // 0x507694: SaveReg r1
    //     0x507694: str             x1, [SP, #-8]!
    // 0x507698: r0 = GDT[cid_x0 + 0x541]()
    //     0x507698: add             lr, x0, #0x541
    //     0x50769c: ldr             lr, [x21, lr, lsl #3]
    //     0x5076a0: blr             lr
    // 0x5076a4: add             SP, SP, #8
    // 0x5076a8: tbz             w0, #4, #0x5076bc
    // 0x5076ac: r0 = Null
    //     0x5076ac: mov             x0, NULL
    // 0x5076b0: LeaveFrame
    //     0x5076b0: mov             SP, fp
    //     0x5076b4: ldp             fp, lr, [SP], #0x10
    // 0x5076b8: ret
    //     0x5076b8: ret             
    // 0x5076bc: ldur            x0, [fp, #-8]
    // 0x5076c0: r1 = LoadClassIdInstr(r0)
    //     0x5076c0: ldur            x1, [x0, #-1]
    //     0x5076c4: ubfx            x1, x1, #0xc, #0x14
    // 0x5076c8: SaveReg r0
    //     0x5076c8: str             x0, [SP, #-8]!
    // 0x5076cc: mov             x0, x1
    // 0x5076d0: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x5076d0: add             lr, x0, #0x5ca
    //     0x5076d4: ldr             lr, [x21, lr, lsl #3]
    //     0x5076d8: blr             lr
    // 0x5076dc: add             SP, SP, #8
    // 0x5076e0: r0 = UnsupportedError()
    //     0x5076e0: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x5076e4: mov             x1, x0
    // 0x5076e8: r0 = "Cannot change"
    //     0x5076e8: add             x0, PP, #0x38, lsl #12  ; [pp+0x38ed8] "Cannot change"
    //     0x5076ec: ldr             x0, [x0, #0xed8]
    // 0x5076f0: StoreField: r1->field_b = r0
    //     0x5076f0: stur            w0, [x1, #0xb]
    // 0x5076f4: mov             x0, x1
    // 0x5076f8: r0 = Throw()
    //     0x5076f8: bl              #0xd67e38  ; ThrowStub
    // 0x5076fc: brk             #0
    // 0x507700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x507700: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x507704: b               #0x507630
    // 0x507708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x507708: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50770c: b               #0x50768c
  }
  _ sublist(/* No info */) {
    // ** addr: 0x508b40, size: 0x108
    // 0x508b40: EnterFrame
    //     0x508b40: stp             fp, lr, [SP, #-0x10]!
    //     0x508b44: mov             fp, SP
    // 0x508b48: AllocStack(0x18)
    //     0x508b48: sub             SP, SP, #0x18
    // 0x508b4c: SetupParameters(_BoolList&Object&ListMixin this /* r2, fp-0x18 */, dynamic _ /* r3 */, [dynamic _ = Null /* r0 */])
    //     0x508b4c: mov             x0, x4
    //     0x508b50: ldur            w1, [x0, #0x13]
    //     0x508b54: add             x1, x1, HEAP, lsl #32
    //     0x508b58: sub             x0, x1, #4
    //     0x508b5c: add             x2, fp, w0, sxtw #2
    //     0x508b60: ldr             x2, [x2, #0x18]
    //     0x508b64: stur            x2, [fp, #-0x18]
    //     0x508b68: add             x3, fp, w0, sxtw #2
    //     0x508b6c: ldr             x3, [x3, #0x10]
    //     0x508b70: cmp             w0, #2
    //     0x508b74: b.lt            #0x508b88
    //     0x508b78: add             x1, fp, w0, sxtw #2
    //     0x508b7c: ldr             x1, [x1, #8]
    //     0x508b80: mov             x0, x1
    //     0x508b84: b               #0x508b8c
    //     0x508b88: mov             x0, NULL
    // 0x508b8c: CheckStackOverflow
    //     0x508b8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x508b90: cmp             SP, x16
    //     0x508b94: b.ls            #0x508c40
    // 0x508b98: LoadField: r4 = r2->field_b
    //     0x508b98: ldur            x4, [x2, #0xb]
    // 0x508b9c: cmp             w0, NULL
    // 0x508ba0: b.ne            #0x508bac
    // 0x508ba4: mov             x5, x4
    // 0x508ba8: b               #0x508bbc
    // 0x508bac: r1 = LoadInt32Instr(r0)
    //     0x508bac: sbfx            x1, x0, #1, #0x1f
    //     0x508bb0: tbz             w0, #0, #0x508bb8
    //     0x508bb4: ldur            x1, [x0, #7]
    // 0x508bb8: mov             x5, x1
    // 0x508bbc: stur            x5, [fp, #-0x10]
    // 0x508bc0: r0 = BoxInt64Instr(r3)
    //     0x508bc0: sbfiz           x0, x3, #1, #0x1f
    //     0x508bc4: cmp             x3, x0, asr #1
    //     0x508bc8: b.eq            #0x508bd4
    //     0x508bcc: bl              #0xd69bb8
    //     0x508bd0: stur            x3, [x0, #7]
    // 0x508bd4: mov             x3, x0
    // 0x508bd8: stur            x3, [fp, #-8]
    // 0x508bdc: r0 = BoxInt64Instr(r5)
    //     0x508bdc: sbfiz           x0, x5, #1, #0x1f
    //     0x508be0: cmp             x5, x0, asr #1
    //     0x508be4: b.eq            #0x508bf0
    //     0x508be8: bl              #0xd69bb8
    //     0x508bec: stur            x5, [x0, #7]
    // 0x508bf0: stp             x0, x3, [SP, #-0x10]!
    // 0x508bf4: SaveReg r4
    //     0x508bf4: str             x4, [SP, #-8]!
    // 0x508bf8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x508bf8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x508bfc: r0 = checkValidRange()
    //     0x508bfc: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0x508c00: add             SP, SP, #0x18
    // 0x508c04: ldur            x16, [fp, #-0x18]
    // 0x508c08: ldur            lr, [fp, #-8]
    // 0x508c0c: stp             lr, x16, [SP, #-0x10]!
    // 0x508c10: ldur            x0, [fp, #-0x10]
    // 0x508c14: SaveReg r0
    //     0x508c14: str             x0, [SP, #-8]!
    // 0x508c18: r0 = getRange()
    //     0x508c18: bl              #0x4c44d4  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::getRange
    // 0x508c1c: add             SP, SP, #0x18
    // 0x508c20: r16 = <bool>
    //     0x508c20: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x508c24: stp             x0, x16, [SP, #-0x10]!
    // 0x508c28: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x508c28: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x508c2c: r0 = List.from()
    //     0x508c2c: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0x508c30: add             SP, SP, #0x10
    // 0x508c34: LeaveFrame
    //     0x508c34: mov             SP, fp
    //     0x508c38: ldp             fp, lr, [SP], #0x10
    // 0x508c3c: ret
    //     0x508c3c: ret             
    // 0x508c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x508c40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x508c44: b               #0x508b98
  }
  _ add(/* No info */) {
    // ** addr: 0x515a34, size: 0x5c
    // 0x515a34: EnterFrame
    //     0x515a34: stp             fp, lr, [SP, #-0x10]!
    //     0x515a38: mov             fp, SP
    // 0x515a3c: ldr             x0, [fp, #0x10]
    // 0x515a40: r2 = Null
    //     0x515a40: mov             x2, NULL
    // 0x515a44: r1 = Null
    //     0x515a44: mov             x1, NULL
    // 0x515a48: r4 = 59
    //     0x515a48: mov             x4, #0x3b
    // 0x515a4c: branchIfSmi(r0, 0x515a58)
    //     0x515a4c: tbz             w0, #0, #0x515a58
    // 0x515a50: r4 = LoadClassIdInstr(r0)
    //     0x515a50: ldur            x4, [x0, #-1]
    //     0x515a54: ubfx            x4, x4, #0xc, #0x14
    // 0x515a58: cmp             x4, #0x3e
    // 0x515a5c: b.eq            #0x515a70
    // 0x515a60: r8 = bool
    //     0x515a60: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0x515a64: r3 = Null
    //     0x515a64: add             x3, PP, #0x41, lsl #12  ; [pp+0x413a8] Null
    //     0x515a68: ldr             x3, [x3, #0x3a8]
    // 0x515a6c: r0 = bool()
    //     0x515a6c: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0x515a70: r0 = UnsupportedError()
    //     0x515a70: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x515a74: mov             x1, x0
    // 0x515a78: r0 = "Cannot change"
    //     0x515a78: add             x0, PP, #0x38, lsl #12  ; [pp+0x38ed8] "Cannot change"
    //     0x515a7c: ldr             x0, [x0, #0xed8]
    // 0x515a80: StoreField: r1->field_b = r0
    //     0x515a80: stur            w0, [x1, #0xb]
    // 0x515a84: mov             x0, x1
    // 0x515a88: r0 = Throw()
    //     0x515a88: bl              #0xd67e38  ; ThrowStub
    // 0x515a8c: brk             #0
  }
  bool last(_BoolList&Object&ListMixin) {
    // ** addr: 0x5ac998, size: 0xcc
    // 0x5ac998: EnterFrame
    //     0x5ac998: stp             fp, lr, [SP, #-0x10]!
    //     0x5ac99c: mov             fp, SP
    // 0x5ac9a0: CheckStackOverflow
    //     0x5ac9a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ac9a4: cmp             SP, x16
    //     0x5ac9a8: b.ls            #0x5aca58
    // 0x5ac9ac: ldr             x0, [fp, #0x10]
    // 0x5ac9b0: LoadField: r1 = r0->field_b
    //     0x5ac9b0: ldur            x1, [x0, #0xb]
    // 0x5ac9b4: cbz             x1, #0x5aca4c
    // 0x5ac9b8: r5 = 8
    //     0x5ac9b8: mov             x5, #8
    // 0x5ac9bc: r4 = 7
    //     0x5ac9bc: mov             x4, #7
    // 0x5ac9c0: r3 = 7
    //     0x5ac9c0: mov             x3, #7
    // 0x5ac9c4: r2 = 1
    //     0x5ac9c4: mov             x2, #1
    // 0x5ac9c8: sub             x6, x1, #1
    // 0x5ac9cc: sdiv            x7, x6, x5
    // 0x5ac9d0: LoadField: r5 = r0->field_7
    //     0x5ac9d0: ldur            w5, [x0, #7]
    // 0x5ac9d4: DecompressPointer r5
    //     0x5ac9d4: add             x5, x5, HEAP, lsl #32
    // 0x5ac9d8: LoadField: r8 = r5->field_b
    //     0x5ac9d8: ldur            w8, [x5, #0xb]
    // 0x5ac9dc: DecompressPointer r8
    //     0x5ac9dc: add             x8, x8, HEAP, lsl #32
    // 0x5ac9e0: r0 = LoadInt32Instr(r8)
    //     0x5ac9e0: sbfx            x0, x8, #1, #0x1f
    // 0x5ac9e4: mov             x1, x7
    // 0x5ac9e8: cmp             x1, x0
    // 0x5ac9ec: b.hs            #0x5aca60
    // 0x5ac9f0: LoadField: r1 = r5->field_f
    //     0x5ac9f0: ldur            w1, [x5, #0xf]
    // 0x5ac9f4: DecompressPointer r1
    //     0x5ac9f4: add             x1, x1, HEAP, lsl #32
    // 0x5ac9f8: ArrayLoad: r5 = r1[r7]  ; Unknown_4
    //     0x5ac9f8: add             x16, x1, x7, lsl #2
    //     0x5ac9fc: ldur            w5, [x16, #0xf]
    // 0x5aca00: DecompressPointer r5
    //     0x5aca00: add             x5, x5, HEAP, lsl #32
    // 0x5aca04: ubfx            x6, x6, #0, #0x20
    // 0x5aca08: and             x1, x6, x3
    // 0x5aca0c: ubfx            x1, x1, #0, #0x20
    // 0x5aca10: sub             x3, x4, x1
    // 0x5aca14: r1 = LoadInt32Instr(r5)
    //     0x5aca14: sbfx            x1, x5, #1, #0x1f
    //     0x5aca18: tbz             w5, #0, #0x5aca20
    //     0x5aca1c: ldur            x1, [x5, #7]
    // 0x5aca20: asr             x4, x1, x3
    // 0x5aca24: ubfx            x4, x4, #0, #0x20
    // 0x5aca28: and             x1, x4, x2
    // 0x5aca2c: ubfx            x1, x1, #0, #0x20
    // 0x5aca30: cmp             x1, #1
    // 0x5aca34: r16 = true
    //     0x5aca34: add             x16, NULL, #0x20  ; true
    // 0x5aca38: r17 = false
    //     0x5aca38: add             x17, NULL, #0x30  ; false
    // 0x5aca3c: csel            x0, x16, x17, eq
    // 0x5aca40: LeaveFrame
    //     0x5aca40: mov             SP, fp
    //     0x5aca44: ldp             fp, lr, [SP], #0x10
    // 0x5aca48: ret
    //     0x5aca48: ret             
    // 0x5aca4c: r0 = noElement()
    //     0x5aca4c: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x5aca50: r0 = Throw()
    //     0x5aca50: bl              #0xd67e38  ; ThrowStub
    // 0x5aca54: brk             #0
    // 0x5aca58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5aca58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5aca5c: b               #0x5ac9ac
    // 0x5aca60: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5aca60: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ take(/* No info */) {
    // ** addr: 0x5acbd8, size: 0x70
    // 0x5acbd8: EnterFrame
    //     0x5acbd8: stp             fp, lr, [SP, #-0x10]!
    //     0x5acbdc: mov             fp, SP
    // 0x5acbe0: AllocStack(0x10)
    //     0x5acbe0: sub             SP, SP, #0x10
    // 0x5acbe4: CheckStackOverflow
    //     0x5acbe4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5acbe8: cmp             SP, x16
    //     0x5acbec: b.ls            #0x5acc40
    // 0x5acbf0: ldr             x2, [fp, #0x10]
    // 0x5acbf4: r0 = BoxInt64Instr(r2)
    //     0x5acbf4: sbfiz           x0, x2, #1, #0x1f
    //     0x5acbf8: cmp             x2, x0, asr #1
    //     0x5acbfc: b.eq            #0x5acc08
    //     0x5acc00: bl              #0xd69bb8
    //     0x5acc04: stur            x2, [x0, #7]
    // 0x5acc08: r1 = <bool>
    //     0x5acc08: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x5acc0c: stur            x0, [fp, #-8]
    // 0x5acc10: r0 = SubListIterable()
    //     0x5acc10: bl              #0x4c2748  ; AllocateSubListIterableStub -> SubListIterable<X0> (size=0x1c)
    // 0x5acc14: stur            x0, [fp, #-0x10]
    // 0x5acc18: ldr             x16, [fp, #0x18]
    // 0x5acc1c: stp             x16, x0, [SP, #-0x10]!
    // 0x5acc20: ldur            x16, [fp, #-8]
    // 0x5acc24: stp             x16, xzr, [SP, #-0x10]!
    // 0x5acc28: r0 = SubListIterable()
    //     0x5acc28: bl              #0x4c25b4  ; [dart:_internal] SubListIterable::SubListIterable
    // 0x5acc2c: add             SP, SP, #0x20
    // 0x5acc30: ldur            x0, [fp, #-0x10]
    // 0x5acc34: LeaveFrame
    //     0x5acc34: mov             SP, fp
    //     0x5acc38: ldp             fp, lr, [SP], #0x10
    // 0x5acc3c: ret
    //     0x5acc3c: ret             
    // 0x5acc40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5acc40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5acc44: b               #0x5acbf0
  }
  _ firstWhere(/* No info */) {
    // ** addr: 0x63e290, size: 0x1a4
    // 0x63e290: EnterFrame
    //     0x63e290: stp             fp, lr, [SP, #-0x10]!
    //     0x63e294: mov             fp, SP
    // 0x63e298: AllocStack(0x38)
    //     0x63e298: sub             SP, SP, #0x38
    // 0x63e29c: SetupParameters(_BoolList&Object&ListMixin this /* r2, fp-0x30 */, dynamic _ /* r3, fp-0x28 */)
    //     0x63e29c: mov             x0, x4
    //     0x63e2a0: ldur            w1, [x0, #0x13]
    //     0x63e2a4: add             x1, x1, HEAP, lsl #32
    //     0x63e2a8: sub             x0, x1, #4
    //     0x63e2ac: add             x2, fp, w0, sxtw #2
    //     0x63e2b0: ldr             x2, [x2, #0x18]
    //     0x63e2b4: stur            x2, [fp, #-0x30]
    //     0x63e2b8: add             x3, fp, w0, sxtw #2
    //     0x63e2bc: ldr             x3, [x3, #0x10]
    //     0x63e2c0: stur            x3, [fp, #-0x28]
    // 0x63e2c4: CheckStackOverflow
    //     0x63e2c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63e2c8: cmp             SP, x16
    //     0x63e2cc: b.ls            #0x63e420
    // 0x63e2d0: LoadField: r4 = r2->field_b
    //     0x63e2d0: ldur            x4, [x2, #0xb]
    // 0x63e2d4: stur            x4, [fp, #-0x20]
    // 0x63e2d8: LoadField: r5 = r2->field_7
    //     0x63e2d8: ldur            w5, [x2, #7]
    // 0x63e2dc: DecompressPointer r5
    //     0x63e2dc: add             x5, x5, HEAP, lsl #32
    // 0x63e2e0: stur            x5, [fp, #-0x18]
    // 0x63e2e4: r10 = 0
    //     0x63e2e4: mov             x10, #0
    // 0x63e2e8: r9 = 8
    //     0x63e2e8: mov             x9, #8
    // 0x63e2ec: r8 = 7
    //     0x63e2ec: mov             x8, #7
    // 0x63e2f0: r7 = 7
    //     0x63e2f0: mov             x7, #7
    // 0x63e2f4: r6 = 1
    //     0x63e2f4: mov             x6, #1
    // 0x63e2f8: stur            x10, [fp, #-0x10]
    // 0x63e2fc: CheckStackOverflow
    //     0x63e2fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63e300: cmp             SP, x16
    //     0x63e304: b.ls            #0x63e428
    // 0x63e308: cmp             x10, x4
    // 0x63e30c: b.ge            #0x63e414
    // 0x63e310: sdiv            x11, x10, x9
    // 0x63e314: LoadField: r0 = r5->field_b
    //     0x63e314: ldur            w0, [x5, #0xb]
    // 0x63e318: DecompressPointer r0
    //     0x63e318: add             x0, x0, HEAP, lsl #32
    // 0x63e31c: r1 = LoadInt32Instr(r0)
    //     0x63e31c: sbfx            x1, x0, #1, #0x1f
    // 0x63e320: mov             x0, x1
    // 0x63e324: mov             x1, x11
    // 0x63e328: cmp             x1, x0
    // 0x63e32c: b.hs            #0x63e430
    // 0x63e330: LoadField: r0 = r5->field_f
    //     0x63e330: ldur            w0, [x5, #0xf]
    // 0x63e334: DecompressPointer r0
    //     0x63e334: add             x0, x0, HEAP, lsl #32
    // 0x63e338: ArrayLoad: r1 = r0[r11]  ; Unknown_4
    //     0x63e338: add             x16, x0, x11, lsl #2
    //     0x63e33c: ldur            w1, [x16, #0xf]
    // 0x63e340: DecompressPointer r1
    //     0x63e340: add             x1, x1, HEAP, lsl #32
    // 0x63e344: mov             x0, x10
    // 0x63e348: ubfx            x0, x0, #0, #0x20
    // 0x63e34c: and             x11, x0, x7
    // 0x63e350: ubfx            x11, x11, #0, #0x20
    // 0x63e354: sub             x0, x8, x11
    // 0x63e358: r11 = LoadInt32Instr(r1)
    //     0x63e358: sbfx            x11, x1, #1, #0x1f
    //     0x63e35c: tbz             w1, #0, #0x63e364
    //     0x63e360: ldur            x11, [x1, #7]
    // 0x63e364: asr             x1, x11, x0
    // 0x63e368: ubfx            x1, x1, #0, #0x20
    // 0x63e36c: and             x0, x1, x6
    // 0x63e370: ubfx            x0, x0, #0, #0x20
    // 0x63e374: cmp             x0, #1
    // 0x63e378: r16 = true
    //     0x63e378: add             x16, NULL, #0x20  ; true
    // 0x63e37c: r17 = false
    //     0x63e37c: add             x17, NULL, #0x30  ; false
    // 0x63e380: csel            x1, x16, x17, eq
    // 0x63e384: stur            x1, [fp, #-8]
    // 0x63e388: stp             x1, x3, [SP, #-0x10]!
    // 0x63e38c: mov             x0, x3
    // 0x63e390: ClosureCall
    //     0x63e390: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x63e394: ldur            x2, [x0, #0x1f]
    //     0x63e398: blr             x2
    // 0x63e39c: add             SP, SP, #0x10
    // 0x63e3a0: mov             x1, x0
    // 0x63e3a4: stur            x1, [fp, #-0x38]
    // 0x63e3a8: tbnz            w0, #5, #0x63e3b0
    // 0x63e3ac: r0 = AssertBoolean()
    //     0x63e3ac: bl              #0xd67df0  ; AssertBooleanStub
    // 0x63e3b0: ldur            x0, [fp, #-0x38]
    // 0x63e3b4: tbnz            w0, #4, #0x63e3c8
    // 0x63e3b8: ldur            x0, [fp, #-8]
    // 0x63e3bc: LeaveFrame
    //     0x63e3bc: mov             SP, fp
    //     0x63e3c0: ldp             fp, lr, [SP], #0x10
    // 0x63e3c4: ret
    //     0x63e3c4: ret             
    // 0x63e3c8: ldur            x0, [fp, #-0x30]
    // 0x63e3cc: ldur            x1, [fp, #-0x20]
    // 0x63e3d0: LoadField: r2 = r0->field_b
    //     0x63e3d0: ldur            x2, [x0, #0xb]
    // 0x63e3d4: cmp             x1, x2
    // 0x63e3d8: b.ne            #0x63e3f8
    // 0x63e3dc: ldur            x2, [fp, #-0x10]
    // 0x63e3e0: add             x10, x2, #1
    // 0x63e3e4: mov             x2, x0
    // 0x63e3e8: ldur            x3, [fp, #-0x28]
    // 0x63e3ec: ldur            x5, [fp, #-0x18]
    // 0x63e3f0: mov             x4, x1
    // 0x63e3f4: b               #0x63e2e8
    // 0x63e3f8: r0 = ConcurrentModificationError()
    //     0x63e3f8: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x63e3fc: mov             x1, x0
    // 0x63e400: ldur            x0, [fp, #-0x30]
    // 0x63e404: StoreField: r1->field_b = r0
    //     0x63e404: stur            w0, [x1, #0xb]
    // 0x63e408: mov             x0, x1
    // 0x63e40c: r0 = Throw()
    //     0x63e40c: bl              #0xd67e38  ; ThrowStub
    // 0x63e410: brk             #0
    // 0x63e414: r0 = noElement()
    //     0x63e414: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x63e418: r0 = Throw()
    //     0x63e418: bl              #0xd67e38  ; ThrowStub
    // 0x63e41c: brk             #0
    // 0x63e420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e420: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e424: b               #0x63e2d0
    // 0x63e428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e428: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e42c: b               #0x63e308
    // 0x63e430: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x63e430: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ toSet(/* No info */) {
    // ** addr: 0x640c98, size: 0x19c
    // 0x640c98: EnterFrame
    //     0x640c98: stp             fp, lr, [SP, #-0x10]!
    //     0x640c9c: mov             fp, SP
    // 0x640ca0: AllocStack(0x18)
    //     0x640ca0: sub             SP, SP, #0x18
    // 0x640ca4: CheckStackOverflow
    //     0x640ca4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640ca8: cmp             SP, x16
    //     0x640cac: b.ls            #0x640e20
    // 0x640cb0: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x640cb0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x640cb4: ldr             x0, [x0, #0x598]
    //     0x640cb8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x640cbc: cmp             w0, w16
    //     0x640cc0: b.ne            #0x640ccc
    //     0x640cc4: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x640cc8: bl              #0xd67cdc
    // 0x640ccc: r1 = <bool>
    //     0x640ccc: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x640cd0: stur            x0, [fp, #-8]
    // 0x640cd4: r0 = _Set()
    //     0x640cd4: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x640cd8: mov             x1, x0
    // 0x640cdc: ldur            x0, [fp, #-8]
    // 0x640ce0: stur            x1, [fp, #-0x10]
    // 0x640ce4: StoreField: r1->field_1b = r0
    //     0x640ce4: stur            w0, [x1, #0x1b]
    // 0x640ce8: StoreField: r1->field_b = rZR
    //     0x640ce8: stur            wzr, [x1, #0xb]
    // 0x640cec: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x640cec: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x640cf0: ldr             x0, [x0, #0x5a0]
    //     0x640cf4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x640cf8: cmp             w0, w16
    //     0x640cfc: b.ne            #0x640d08
    //     0x640d00: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x640d04: bl              #0xd67cdc
    // 0x640d08: ldur            x2, [fp, #-0x10]
    // 0x640d0c: StoreField: r2->field_f = r0
    //     0x640d0c: stur            w0, [x2, #0xf]
    // 0x640d10: StoreField: r2->field_13 = rZR
    //     0x640d10: stur            wzr, [x2, #0x13]
    // 0x640d14: StoreField: r2->field_17 = rZR
    //     0x640d14: stur            wzr, [x2, #0x17]
    // 0x640d18: ldr             x3, [fp, #0x10]
    // 0x640d1c: LoadField: r4 = r3->field_7
    //     0x640d1c: ldur            w4, [x3, #7]
    // 0x640d20: DecompressPointer r4
    //     0x640d20: add             x4, x4, HEAP, lsl #32
    // 0x640d24: stur            x4, [fp, #-8]
    // 0x640d28: r9 = 0
    //     0x640d28: mov             x9, #0
    // 0x640d2c: r8 = 8
    //     0x640d2c: mov             x8, #8
    // 0x640d30: r7 = 7
    //     0x640d30: mov             x7, #7
    // 0x640d34: r6 = 7
    //     0x640d34: mov             x6, #7
    // 0x640d38: r5 = 1
    //     0x640d38: mov             x5, #1
    // 0x640d3c: stur            x9, [fp, #-0x18]
    // 0x640d40: CheckStackOverflow
    //     0x640d40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640d44: cmp             SP, x16
    //     0x640d48: b.ls            #0x640e28
    // 0x640d4c: LoadField: r0 = r3->field_b
    //     0x640d4c: ldur            x0, [x3, #0xb]
    // 0x640d50: cmp             x9, x0
    // 0x640d54: b.ge            #0x640e10
    // 0x640d58: sdiv            x10, x9, x8
    // 0x640d5c: LoadField: r0 = r4->field_b
    //     0x640d5c: ldur            w0, [x4, #0xb]
    // 0x640d60: DecompressPointer r0
    //     0x640d60: add             x0, x0, HEAP, lsl #32
    // 0x640d64: r1 = LoadInt32Instr(r0)
    //     0x640d64: sbfx            x1, x0, #1, #0x1f
    // 0x640d68: mov             x0, x1
    // 0x640d6c: mov             x1, x10
    // 0x640d70: cmp             x1, x0
    // 0x640d74: b.hs            #0x640e30
    // 0x640d78: LoadField: r0 = r4->field_f
    //     0x640d78: ldur            w0, [x4, #0xf]
    // 0x640d7c: DecompressPointer r0
    //     0x640d7c: add             x0, x0, HEAP, lsl #32
    // 0x640d80: ArrayLoad: r1 = r0[r10]  ; Unknown_4
    //     0x640d80: add             x16, x0, x10, lsl #2
    //     0x640d84: ldur            w1, [x16, #0xf]
    // 0x640d88: DecompressPointer r1
    //     0x640d88: add             x1, x1, HEAP, lsl #32
    // 0x640d8c: mov             x0, x9
    // 0x640d90: ubfx            x0, x0, #0, #0x20
    // 0x640d94: and             x10, x0, x6
    // 0x640d98: ubfx            x10, x10, #0, #0x20
    // 0x640d9c: sub             x0, x7, x10
    // 0x640da0: r10 = LoadInt32Instr(r1)
    //     0x640da0: sbfx            x10, x1, #1, #0x1f
    //     0x640da4: tbz             w1, #0, #0x640dac
    //     0x640da8: ldur            x10, [x1, #7]
    // 0x640dac: asr             x1, x10, x0
    // 0x640db0: ubfx            x1, x1, #0, #0x20
    // 0x640db4: and             x0, x1, x5
    // 0x640db8: ubfx            x0, x0, #0, #0x20
    // 0x640dbc: cmp             x0, #1
    // 0x640dc0: r16 = true
    //     0x640dc0: add             x16, NULL, #0x20  ; true
    // 0x640dc4: r17 = false
    //     0x640dc4: add             x17, NULL, #0x30  ; false
    // 0x640dc8: csel            x1, x16, x17, eq
    // 0x640dcc: tst             x1, #0x10
    // 0x640dd0: cset            x0, ne
    // 0x640dd4: sub             x0, x0, #1
    // 0x640dd8: r16 = -12
    //     0x640dd8: mov             x16, #-0xc
    // 0x640ddc: and             x0, x0, x16
    // 0x640de0: add             x0, x0, #0x9aa
    // 0x640de4: r10 = LoadInt32Instr(r0)
    //     0x640de4: sbfx            x10, x0, #1, #0x1f
    // 0x640de8: stp             x1, x2, [SP, #-0x10]!
    // 0x640dec: SaveReg r10
    //     0x640dec: str             x10, [SP, #-8]!
    // 0x640df0: r0 = _add()
    //     0x640df0: bl              #0x5c1840  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x640df4: add             SP, SP, #0x18
    // 0x640df8: ldur            x1, [fp, #-0x18]
    // 0x640dfc: add             x9, x1, #1
    // 0x640e00: ldr             x3, [fp, #0x10]
    // 0x640e04: ldur            x2, [fp, #-0x10]
    // 0x640e08: ldur            x4, [fp, #-8]
    // 0x640e0c: b               #0x640d2c
    // 0x640e10: ldur            x0, [fp, #-0x10]
    // 0x640e14: LeaveFrame
    //     0x640e14: mov             SP, fp
    //     0x640e18: ldp             fp, lr, [SP], #0x10
    // 0x640e1c: ret
    //     0x640e1c: ret             
    // 0x640e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640e20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640e24: b               #0x640cb0
    // 0x640e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640e28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640e2c: b               #0x640d4c
    // 0x640e30: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x640e30: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ any(/* No info */) {
    // ** addr: 0x6aba48, size: 0x180
    // 0x6aba48: EnterFrame
    //     0x6aba48: stp             fp, lr, [SP, #-0x10]!
    //     0x6aba4c: mov             fp, SP
    // 0x6aba50: AllocStack(0x20)
    //     0x6aba50: sub             SP, SP, #0x20
    // 0x6aba54: CheckStackOverflow
    //     0x6aba54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6aba58: cmp             SP, x16
    //     0x6aba5c: b.ls            #0x6abbb4
    // 0x6aba60: ldr             x2, [fp, #0x18]
    // 0x6aba64: LoadField: r3 = r2->field_b
    //     0x6aba64: ldur            x3, [x2, #0xb]
    // 0x6aba68: stur            x3, [fp, #-0x18]
    // 0x6aba6c: LoadField: r4 = r2->field_7
    //     0x6aba6c: ldur            w4, [x2, #7]
    // 0x6aba70: DecompressPointer r4
    //     0x6aba70: add             x4, x4, HEAP, lsl #32
    // 0x6aba74: stur            x4, [fp, #-0x10]
    // 0x6aba78: r9 = 0
    //     0x6aba78: mov             x9, #0
    // 0x6aba7c: r8 = 8
    //     0x6aba7c: mov             x8, #8
    // 0x6aba80: r7 = 7
    //     0x6aba80: mov             x7, #7
    // 0x6aba84: r6 = 7
    //     0x6aba84: mov             x6, #7
    // 0x6aba88: r5 = 1
    //     0x6aba88: mov             x5, #1
    // 0x6aba8c: stur            x9, [fp, #-8]
    // 0x6aba90: CheckStackOverflow
    //     0x6aba90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6aba94: cmp             SP, x16
    //     0x6aba98: b.ls            #0x6abbbc
    // 0x6aba9c: cmp             x9, x3
    // 0x6abaa0: b.ge            #0x6abb88
    // 0x6abaa4: sdiv            x10, x9, x8
    // 0x6abaa8: LoadField: r0 = r4->field_b
    //     0x6abaa8: ldur            w0, [x4, #0xb]
    // 0x6abaac: DecompressPointer r0
    //     0x6abaac: add             x0, x0, HEAP, lsl #32
    // 0x6abab0: r1 = LoadInt32Instr(r0)
    //     0x6abab0: sbfx            x1, x0, #1, #0x1f
    // 0x6abab4: mov             x0, x1
    // 0x6abab8: mov             x1, x10
    // 0x6ababc: cmp             x1, x0
    // 0x6abac0: b.hs            #0x6abbc4
    // 0x6abac4: LoadField: r0 = r4->field_f
    //     0x6abac4: ldur            w0, [x4, #0xf]
    // 0x6abac8: DecompressPointer r0
    //     0x6abac8: add             x0, x0, HEAP, lsl #32
    // 0x6abacc: ArrayLoad: r1 = r0[r10]  ; Unknown_4
    //     0x6abacc: add             x16, x0, x10, lsl #2
    //     0x6abad0: ldur            w1, [x16, #0xf]
    // 0x6abad4: DecompressPointer r1
    //     0x6abad4: add             x1, x1, HEAP, lsl #32
    // 0x6abad8: mov             x0, x9
    // 0x6abadc: ubfx            x0, x0, #0, #0x20
    // 0x6abae0: and             x10, x0, x6
    // 0x6abae4: ubfx            x10, x10, #0, #0x20
    // 0x6abae8: sub             x0, x7, x10
    // 0x6abaec: r10 = LoadInt32Instr(r1)
    //     0x6abaec: sbfx            x10, x1, #1, #0x1f
    //     0x6abaf0: tbz             w1, #0, #0x6abaf8
    //     0x6abaf4: ldur            x10, [x1, #7]
    // 0x6abaf8: asr             x1, x10, x0
    // 0x6abafc: ubfx            x1, x1, #0, #0x20
    // 0x6abb00: and             x0, x1, x5
    // 0x6abb04: ubfx            x0, x0, #0, #0x20
    // 0x6abb08: cmp             x0, #1
    // 0x6abb0c: r16 = true
    //     0x6abb0c: add             x16, NULL, #0x20  ; true
    // 0x6abb10: r17 = false
    //     0x6abb10: add             x17, NULL, #0x30  ; false
    // 0x6abb14: csel            x1, x16, x17, eq
    // 0x6abb18: ldr             x16, [fp, #0x10]
    // 0x6abb1c: stp             x1, x16, [SP, #-0x10]!
    // 0x6abb20: ldr             x0, [fp, #0x10]
    // 0x6abb24: ClosureCall
    //     0x6abb24: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6abb28: ldur            x2, [x0, #0x1f]
    //     0x6abb2c: blr             x2
    // 0x6abb30: add             SP, SP, #0x10
    // 0x6abb34: mov             x1, x0
    // 0x6abb38: stur            x1, [fp, #-0x20]
    // 0x6abb3c: tbnz            w0, #5, #0x6abb44
    // 0x6abb40: r0 = AssertBoolean()
    //     0x6abb40: bl              #0xd67df0  ; AssertBooleanStub
    // 0x6abb44: ldur            x0, [fp, #-0x20]
    // 0x6abb48: tbnz            w0, #4, #0x6abb5c
    // 0x6abb4c: r0 = true
    //     0x6abb4c: add             x0, NULL, #0x20  ; true
    // 0x6abb50: LeaveFrame
    //     0x6abb50: mov             SP, fp
    //     0x6abb54: ldp             fp, lr, [SP], #0x10
    // 0x6abb58: ret
    //     0x6abb58: ret             
    // 0x6abb5c: ldr             x0, [fp, #0x18]
    // 0x6abb60: ldur            x1, [fp, #-0x18]
    // 0x6abb64: LoadField: r2 = r0->field_b
    //     0x6abb64: ldur            x2, [x0, #0xb]
    // 0x6abb68: cmp             x1, x2
    // 0x6abb6c: b.ne            #0x6abb98
    // 0x6abb70: ldur            x2, [fp, #-8]
    // 0x6abb74: add             x9, x2, #1
    // 0x6abb78: mov             x2, x0
    // 0x6abb7c: ldur            x4, [fp, #-0x10]
    // 0x6abb80: mov             x3, x1
    // 0x6abb84: b               #0x6aba7c
    // 0x6abb88: r0 = false
    //     0x6abb88: add             x0, NULL, #0x30  ; false
    // 0x6abb8c: LeaveFrame
    //     0x6abb8c: mov             SP, fp
    //     0x6abb90: ldp             fp, lr, [SP], #0x10
    // 0x6abb94: ret
    //     0x6abb94: ret             
    // 0x6abb98: r0 = ConcurrentModificationError()
    //     0x6abb98: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6abb9c: mov             x1, x0
    // 0x6abba0: ldr             x0, [fp, #0x18]
    // 0x6abba4: StoreField: r1->field_b = r0
    //     0x6abba4: stur            w0, [x1, #0xb]
    // 0x6abba8: mov             x0, x1
    // 0x6abbac: r0 = Throw()
    //     0x6abbac: bl              #0xd67e38  ; ThrowStub
    // 0x6abbb0: brk             #0
    // 0x6abbb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6abbb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6abbb8: b               #0x6aba60
    // 0x6abbbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6abbbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6abbc0: b               #0x6aba9c
    // 0x6abbc4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6abbc4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  dynamic contains(dynamic) {
    // ** addr: 0x6abdbc, size: 0x18
    // 0x6abdbc: r4 = 0
    //     0x6abdbc: mov             x4, #0
    // 0x6abdc0: r1 = Function 'contains':.
    //     0x6abdc0: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca20] AnonymousClosure: (0x6abdd4), in [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::contains (0x6c0408)
    //     0x6abdc4: ldr             x1, [x17, #0xa20]
    // 0x6abdc8: r24 = BuildNonGenericMethodExtractorStub
    //     0x6abdc8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6abdcc: LoadField: r0 = r24->field_17
    //     0x6abdcc: ldur            x0, [x24, #0x17]
    // 0x6abdd0: br              x0
  }
  [closure] bool contains(dynamic, Object?) {
    // ** addr: 0x6abdd4, size: 0x4c
    // 0x6abdd4: EnterFrame
    //     0x6abdd4: stp             fp, lr, [SP, #-0x10]!
    //     0x6abdd8: mov             fp, SP
    // 0x6abddc: ldr             x0, [fp, #0x18]
    // 0x6abde0: LoadField: r1 = r0->field_17
    //     0x6abde0: ldur            w1, [x0, #0x17]
    // 0x6abde4: DecompressPointer r1
    //     0x6abde4: add             x1, x1, HEAP, lsl #32
    // 0x6abde8: CheckStackOverflow
    //     0x6abde8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6abdec: cmp             SP, x16
    //     0x6abdf0: b.ls            #0x6abe18
    // 0x6abdf4: LoadField: r0 = r1->field_f
    //     0x6abdf4: ldur            w0, [x1, #0xf]
    // 0x6abdf8: DecompressPointer r0
    //     0x6abdf8: add             x0, x0, HEAP, lsl #32
    // 0x6abdfc: ldr             x16, [fp, #0x10]
    // 0x6abe00: stp             x16, x0, [SP, #-0x10]!
    // 0x6abe04: r0 = contains()
    //     0x6abe04: bl              #0x6c0408  ; [package:collection/src/boollist.dart] _BoolList&Object&ListMixin::contains
    // 0x6abe08: add             SP, SP, #0x10
    // 0x6abe0c: LeaveFrame
    //     0x6abe0c: mov             SP, fp
    //     0x6abe10: ldp             fp, lr, [SP], #0x10
    // 0x6abe14: ret
    //     0x6abe14: ret             
    // 0x6abe18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6abe18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6abe1c: b               #0x6abdf4
  }
  bool single(_BoolList&Object&ListMixin) {
    // ** addr: 0x6acbd0, size: 0xb8
    // 0x6acbd0: EnterFrame
    //     0x6acbd0: stp             fp, lr, [SP, #-0x10]!
    //     0x6acbd4: mov             fp, SP
    // 0x6acbd8: CheckStackOverflow
    //     0x6acbd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6acbdc: cmp             SP, x16
    //     0x6acbe0: b.ls            #0x6acc7c
    // 0x6acbe4: ldr             x0, [fp, #0x10]
    // 0x6acbe8: LoadField: r1 = r0->field_b
    //     0x6acbe8: ldur            x1, [x0, #0xb]
    // 0x6acbec: cbz             x1, #0x6acc64
    // 0x6acbf0: cmp             x1, #1
    // 0x6acbf4: b.gt            #0x6acc70
    // 0x6acbf8: r2 = 1
    //     0x6acbf8: mov             x2, #1
    // 0x6acbfc: LoadField: r3 = r0->field_7
    //     0x6acbfc: ldur            w3, [x0, #7]
    // 0x6acc00: DecompressPointer r3
    //     0x6acc00: add             x3, x3, HEAP, lsl #32
    // 0x6acc04: LoadField: r4 = r3->field_b
    //     0x6acc04: ldur            w4, [x3, #0xb]
    // 0x6acc08: DecompressPointer r4
    //     0x6acc08: add             x4, x4, HEAP, lsl #32
    // 0x6acc0c: r0 = LoadInt32Instr(r4)
    //     0x6acc0c: sbfx            x0, x4, #1, #0x1f
    // 0x6acc10: r1 = 0
    //     0x6acc10: mov             x1, #0
    // 0x6acc14: cmp             x1, x0
    // 0x6acc18: b.hs            #0x6acc84
    // 0x6acc1c: LoadField: r1 = r3->field_f
    //     0x6acc1c: ldur            w1, [x3, #0xf]
    // 0x6acc20: DecompressPointer r1
    //     0x6acc20: add             x1, x1, HEAP, lsl #32
    // 0x6acc24: LoadField: r3 = r1->field_f
    //     0x6acc24: ldur            w3, [x1, #0xf]
    // 0x6acc28: DecompressPointer r3
    //     0x6acc28: add             x3, x3, HEAP, lsl #32
    // 0x6acc2c: r1 = LoadInt32Instr(r3)
    //     0x6acc2c: sbfx            x1, x3, #1, #0x1f
    //     0x6acc30: tbz             w3, #0, #0x6acc38
    //     0x6acc34: ldur            x1, [x3, #7]
    // 0x6acc38: asr             x3, x1, #7
    // 0x6acc3c: ubfx            x3, x3, #0, #0x20
    // 0x6acc40: and             x1, x3, x2
    // 0x6acc44: ubfx            x1, x1, #0, #0x20
    // 0x6acc48: cmp             x1, #1
    // 0x6acc4c: r16 = true
    //     0x6acc4c: add             x16, NULL, #0x20  ; true
    // 0x6acc50: r17 = false
    //     0x6acc50: add             x17, NULL, #0x30  ; false
    // 0x6acc54: csel            x0, x16, x17, eq
    // 0x6acc58: LeaveFrame
    //     0x6acc58: mov             SP, fp
    //     0x6acc5c: ldp             fp, lr, [SP], #0x10
    // 0x6acc60: ret
    //     0x6acc60: ret             
    // 0x6acc64: r0 = noElement()
    //     0x6acc64: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x6acc68: r0 = Throw()
    //     0x6acc68: bl              #0xd67e38  ; ThrowStub
    // 0x6acc6c: brk             #0
    // 0x6acc70: r0 = tooMany()
    //     0x6acc70: bl              #0x6a5cbc  ; [dart:_internal] IterableElementError::tooMany
    // 0x6acc74: r0 = Throw()
    //     0x6acc74: bl              #0xd67e38  ; ThrowStub
    // 0x6acc78: brk             #0
    // 0x6acc7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6acc7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6acc80: b               #0x6acbe4
    // 0x6acc84: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6acc84: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ where(/* No info */) {
    // ** addr: 0x6ad4a8, size: 0x2c
    // 0x6ad4a8: EnterFrame
    //     0x6ad4a8: stp             fp, lr, [SP, #-0x10]!
    //     0x6ad4ac: mov             fp, SP
    // 0x6ad4b0: r1 = <bool>
    //     0x6ad4b0: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x6ad4b4: r0 = WhereIterable()
    //     0x6ad4b4: bl              #0x5dbe54  ; AllocateWhereIterableStub -> WhereIterable<X0> (size=0x14)
    // 0x6ad4b8: ldr             x1, [fp, #0x18]
    // 0x6ad4bc: StoreField: r0->field_b = r1
    //     0x6ad4bc: stur            w1, [x0, #0xb]
    // 0x6ad4c0: ldr             x1, [fp, #0x10]
    // 0x6ad4c4: StoreField: r0->field_f = r1
    //     0x6ad4c4: stur            w1, [x0, #0xf]
    // 0x6ad4c8: LeaveFrame
    //     0x6ad4c8: mov             SP, fp
    //     0x6ad4cc: ldp             fp, lr, [SP], #0x10
    // 0x6ad4d0: ret
    //     0x6ad4d0: ret             
  }
  _ join(/* No info */) {
    // ** addr: 0x6b8420, size: 0xc4
    // 0x6b8420: EnterFrame
    //     0x6b8420: stp             fp, lr, [SP, #-0x10]!
    //     0x6b8424: mov             fp, SP
    // 0x6b8428: AllocStack(0x18)
    //     0x6b8428: sub             SP, SP, #0x18
    // 0x6b842c: SetupParameters(_BoolList&Object&ListMixin this /* r1, fp-0x10 */, [dynamic _ = "" /* r0, fp-0x8 */])
    //     0x6b842c: mov             x0, x4
    //     0x6b8430: ldur            w1, [x0, #0x13]
    //     0x6b8434: add             x1, x1, HEAP, lsl #32
    //     0x6b8438: sub             x0, x1, #2
    //     0x6b843c: add             x1, fp, w0, sxtw #2
    //     0x6b8440: ldr             x1, [x1, #0x10]
    //     0x6b8444: stur            x1, [fp, #-0x10]
    //     0x6b8448: cmp             w0, #2
    //     0x6b844c: b.lt            #0x6b8460
    //     0x6b8450: add             x2, fp, w0, sxtw #2
    //     0x6b8454: ldr             x2, [x2, #8]
    //     0x6b8458: mov             x0, x2
    //     0x6b845c: b               #0x6b8464
    //     0x6b8460: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    //     0x6b8464: stur            x0, [fp, #-8]
    // 0x6b8468: CheckStackOverflow
    //     0x6b8468: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b846c: cmp             SP, x16
    //     0x6b8470: b.ls            #0x6b84dc
    // 0x6b8474: LoadField: r2 = r1->field_b
    //     0x6b8474: ldur            x2, [x1, #0xb]
    // 0x6b8478: cbnz            x2, #0x6b848c
    // 0x6b847c: r0 = ""
    //     0x6b847c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x6b8480: LeaveFrame
    //     0x6b8480: mov             SP, fp
    //     0x6b8484: ldp             fp, lr, [SP], #0x10
    // 0x6b8488: ret
    //     0x6b8488: ret             
    // 0x6b848c: r0 = StringBuffer()
    //     0x6b848c: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x6b8490: stur            x0, [fp, #-0x18]
    // 0x6b8494: SaveReg r0
    //     0x6b8494: str             x0, [SP, #-8]!
    // 0x6b8498: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6b8498: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6b849c: r0 = StringBuffer()
    //     0x6b849c: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0x6b84a0: add             SP, SP, #8
    // 0x6b84a4: ldur            x16, [fp, #-0x18]
    // 0x6b84a8: ldur            lr, [fp, #-0x10]
    // 0x6b84ac: stp             lr, x16, [SP, #-0x10]!
    // 0x6b84b0: ldur            x16, [fp, #-8]
    // 0x6b84b4: SaveReg r16
    //     0x6b84b4: str             x16, [SP, #-8]!
    // 0x6b84b8: r0 = writeAll()
    //     0x6b84b8: bl              #0x6a9898  ; [dart:core] StringBuffer::writeAll
    // 0x6b84bc: add             SP, SP, #0x18
    // 0x6b84c0: ldur            x16, [fp, #-0x18]
    // 0x6b84c4: SaveReg r16
    //     0x6b84c4: str             x16, [SP, #-8]!
    // 0x6b84c8: r0 = toString()
    //     0x6b84c8: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0x6b84cc: add             SP, SP, #8
    // 0x6b84d0: LeaveFrame
    //     0x6b84d0: mov             SP, fp
    //     0x6b84d4: ldp             fp, lr, [SP], #0x10
    // 0x6b84d8: ret
    //     0x6b84d8: ret             
    // 0x6b84dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b84dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b84e0: b               #0x6b8474
  }
  void forEach(_BoolList&Object&ListMixin, (dynamic, bool) => void) {
    // ** addr: 0x6ba174, size: 0x158
    // 0x6ba174: EnterFrame
    //     0x6ba174: stp             fp, lr, [SP, #-0x10]!
    //     0x6ba178: mov             fp, SP
    // 0x6ba17c: AllocStack(0x18)
    //     0x6ba17c: sub             SP, SP, #0x18
    // 0x6ba180: CheckStackOverflow
    //     0x6ba180: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ba184: cmp             SP, x16
    //     0x6ba188: b.ls            #0x6ba2b8
    // 0x6ba18c: ldr             x2, [fp, #0x18]
    // 0x6ba190: LoadField: r3 = r2->field_b
    //     0x6ba190: ldur            x3, [x2, #0xb]
    // 0x6ba194: stur            x3, [fp, #-0x18]
    // 0x6ba198: LoadField: r4 = r2->field_7
    //     0x6ba198: ldur            w4, [x2, #7]
    // 0x6ba19c: DecompressPointer r4
    //     0x6ba19c: add             x4, x4, HEAP, lsl #32
    // 0x6ba1a0: stur            x4, [fp, #-0x10]
    // 0x6ba1a4: r9 = 0
    //     0x6ba1a4: mov             x9, #0
    // 0x6ba1a8: r8 = 8
    //     0x6ba1a8: mov             x8, #8
    // 0x6ba1ac: r7 = 7
    //     0x6ba1ac: mov             x7, #7
    // 0x6ba1b0: r6 = 7
    //     0x6ba1b0: mov             x6, #7
    // 0x6ba1b4: r5 = 1
    //     0x6ba1b4: mov             x5, #1
    // 0x6ba1b8: stur            x9, [fp, #-8]
    // 0x6ba1bc: CheckStackOverflow
    //     0x6ba1bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ba1c0: cmp             SP, x16
    //     0x6ba1c4: b.ls            #0x6ba2c0
    // 0x6ba1c8: cmp             x9, x3
    // 0x6ba1cc: b.ge            #0x6ba28c
    // 0x6ba1d0: sdiv            x10, x9, x8
    // 0x6ba1d4: LoadField: r0 = r4->field_b
    //     0x6ba1d4: ldur            w0, [x4, #0xb]
    // 0x6ba1d8: DecompressPointer r0
    //     0x6ba1d8: add             x0, x0, HEAP, lsl #32
    // 0x6ba1dc: r1 = LoadInt32Instr(r0)
    //     0x6ba1dc: sbfx            x1, x0, #1, #0x1f
    // 0x6ba1e0: mov             x0, x1
    // 0x6ba1e4: mov             x1, x10
    // 0x6ba1e8: cmp             x1, x0
    // 0x6ba1ec: b.hs            #0x6ba2c8
    // 0x6ba1f0: LoadField: r0 = r4->field_f
    //     0x6ba1f0: ldur            w0, [x4, #0xf]
    // 0x6ba1f4: DecompressPointer r0
    //     0x6ba1f4: add             x0, x0, HEAP, lsl #32
    // 0x6ba1f8: ArrayLoad: r1 = r0[r10]  ; Unknown_4
    //     0x6ba1f8: add             x16, x0, x10, lsl #2
    //     0x6ba1fc: ldur            w1, [x16, #0xf]
    // 0x6ba200: DecompressPointer r1
    //     0x6ba200: add             x1, x1, HEAP, lsl #32
    // 0x6ba204: mov             x0, x9
    // 0x6ba208: ubfx            x0, x0, #0, #0x20
    // 0x6ba20c: and             x10, x0, x6
    // 0x6ba210: ubfx            x10, x10, #0, #0x20
    // 0x6ba214: sub             x0, x7, x10
    // 0x6ba218: r10 = LoadInt32Instr(r1)
    //     0x6ba218: sbfx            x10, x1, #1, #0x1f
    //     0x6ba21c: tbz             w1, #0, #0x6ba224
    //     0x6ba220: ldur            x10, [x1, #7]
    // 0x6ba224: asr             x1, x10, x0
    // 0x6ba228: ubfx            x1, x1, #0, #0x20
    // 0x6ba22c: and             x0, x1, x5
    // 0x6ba230: ubfx            x0, x0, #0, #0x20
    // 0x6ba234: cmp             x0, #1
    // 0x6ba238: r16 = true
    //     0x6ba238: add             x16, NULL, #0x20  ; true
    // 0x6ba23c: r17 = false
    //     0x6ba23c: add             x17, NULL, #0x30  ; false
    // 0x6ba240: csel            x1, x16, x17, eq
    // 0x6ba244: ldr             x16, [fp, #0x10]
    // 0x6ba248: stp             x1, x16, [SP, #-0x10]!
    // 0x6ba24c: ldr             x0, [fp, #0x10]
    // 0x6ba250: ClosureCall
    //     0x6ba250: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6ba254: ldur            x2, [x0, #0x1f]
    //     0x6ba258: blr             x2
    // 0x6ba25c: add             SP, SP, #0x10
    // 0x6ba260: ldr             x0, [fp, #0x18]
    // 0x6ba264: LoadField: r1 = r0->field_b
    //     0x6ba264: ldur            x1, [x0, #0xb]
    // 0x6ba268: ldur            x2, [fp, #-0x18]
    // 0x6ba26c: cmp             x2, x1
    // 0x6ba270: b.ne            #0x6ba29c
    // 0x6ba274: ldur            x1, [fp, #-8]
    // 0x6ba278: add             x9, x1, #1
    // 0x6ba27c: mov             x3, x2
    // 0x6ba280: mov             x2, x0
    // 0x6ba284: ldur            x4, [fp, #-0x10]
    // 0x6ba288: b               #0x6ba1a8
    // 0x6ba28c: r0 = Null
    //     0x6ba28c: mov             x0, NULL
    // 0x6ba290: LeaveFrame
    //     0x6ba290: mov             SP, fp
    //     0x6ba294: ldp             fp, lr, [SP], #0x10
    // 0x6ba298: ret
    //     0x6ba298: ret             
    // 0x6ba29c: r0 = ConcurrentModificationError()
    //     0x6ba29c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6ba2a0: mov             x1, x0
    // 0x6ba2a4: ldr             x0, [fp, #0x18]
    // 0x6ba2a8: StoreField: r1->field_b = r0
    //     0x6ba2a8: stur            w0, [x1, #0xb]
    // 0x6ba2ac: mov             x0, x1
    // 0x6ba2b0: r0 = Throw()
    //     0x6ba2b0: bl              #0xd67e38  ; ThrowStub
    // 0x6ba2b4: brk             #0
    // 0x6ba2b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ba2b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ba2bc: b               #0x6ba18c
    // 0x6ba2c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ba2c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ba2c4: b               #0x6ba1c8
    // 0x6ba2c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6ba2c8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ skip(/* No info */) {
    // ** addr: 0x6bb390, size: 0x54
    // 0x6bb390: EnterFrame
    //     0x6bb390: stp             fp, lr, [SP, #-0x10]!
    //     0x6bb394: mov             fp, SP
    // 0x6bb398: AllocStack(0x8)
    //     0x6bb398: sub             SP, SP, #8
    // 0x6bb39c: CheckStackOverflow
    //     0x6bb39c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bb3a0: cmp             SP, x16
    //     0x6bb3a4: b.ls            #0x6bb3dc
    // 0x6bb3a8: r1 = <bool>
    //     0x6bb3a8: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x6bb3ac: r0 = SubListIterable()
    //     0x6bb3ac: bl              #0x4c2748  ; AllocateSubListIterableStub -> SubListIterable<X0> (size=0x1c)
    // 0x6bb3b0: stur            x0, [fp, #-8]
    // 0x6bb3b4: ldr             x16, [fp, #0x18]
    // 0x6bb3b8: stp             x16, x0, [SP, #-0x10]!
    // 0x6bb3bc: ldr             x1, [fp, #0x10]
    // 0x6bb3c0: stp             NULL, x1, [SP, #-0x10]!
    // 0x6bb3c4: r0 = SubListIterable()
    //     0x6bb3c4: bl              #0x4c25b4  ; [dart:_internal] SubListIterable::SubListIterable
    // 0x6bb3c8: add             SP, SP, #0x20
    // 0x6bb3cc: ldur            x0, [fp, #-8]
    // 0x6bb3d0: LeaveFrame
    //     0x6bb3d0: mov             SP, fp
    //     0x6bb3d4: ldp             fp, lr, [SP], #0x10
    // 0x6bb3d8: ret
    //     0x6bb3d8: ret             
    // 0x6bb3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bb3dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bb3e0: b               #0x6bb3a8
  }
  bool first(_BoolList&Object&ListMixin) {
    // ** addr: 0x6bf058, size: 0xa4
    // 0x6bf058: EnterFrame
    //     0x6bf058: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf05c: mov             fp, SP
    // 0x6bf060: CheckStackOverflow
    //     0x6bf060: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf064: cmp             SP, x16
    //     0x6bf068: b.ls            #0x6bf0f0
    // 0x6bf06c: ldr             x0, [fp, #0x10]
    // 0x6bf070: LoadField: r1 = r0->field_b
    //     0x6bf070: ldur            x1, [x0, #0xb]
    // 0x6bf074: cbz             x1, #0x6bf0e4
    // 0x6bf078: r2 = 1
    //     0x6bf078: mov             x2, #1
    // 0x6bf07c: LoadField: r3 = r0->field_7
    //     0x6bf07c: ldur            w3, [x0, #7]
    // 0x6bf080: DecompressPointer r3
    //     0x6bf080: add             x3, x3, HEAP, lsl #32
    // 0x6bf084: LoadField: r4 = r3->field_b
    //     0x6bf084: ldur            w4, [x3, #0xb]
    // 0x6bf088: DecompressPointer r4
    //     0x6bf088: add             x4, x4, HEAP, lsl #32
    // 0x6bf08c: r0 = LoadInt32Instr(r4)
    //     0x6bf08c: sbfx            x0, x4, #1, #0x1f
    // 0x6bf090: r1 = 0
    //     0x6bf090: mov             x1, #0
    // 0x6bf094: cmp             x1, x0
    // 0x6bf098: b.hs            #0x6bf0f8
    // 0x6bf09c: LoadField: r1 = r3->field_f
    //     0x6bf09c: ldur            w1, [x3, #0xf]
    // 0x6bf0a0: DecompressPointer r1
    //     0x6bf0a0: add             x1, x1, HEAP, lsl #32
    // 0x6bf0a4: LoadField: r3 = r1->field_f
    //     0x6bf0a4: ldur            w3, [x1, #0xf]
    // 0x6bf0a8: DecompressPointer r3
    //     0x6bf0a8: add             x3, x3, HEAP, lsl #32
    // 0x6bf0ac: r1 = LoadInt32Instr(r3)
    //     0x6bf0ac: sbfx            x1, x3, #1, #0x1f
    //     0x6bf0b0: tbz             w3, #0, #0x6bf0b8
    //     0x6bf0b4: ldur            x1, [x3, #7]
    // 0x6bf0b8: asr             x3, x1, #7
    // 0x6bf0bc: ubfx            x3, x3, #0, #0x20
    // 0x6bf0c0: and             x1, x3, x2
    // 0x6bf0c4: ubfx            x1, x1, #0, #0x20
    // 0x6bf0c8: cmp             x1, #1
    // 0x6bf0cc: r16 = true
    //     0x6bf0cc: add             x16, NULL, #0x20  ; true
    // 0x6bf0d0: r17 = false
    //     0x6bf0d0: add             x17, NULL, #0x30  ; false
    // 0x6bf0d4: csel            x0, x16, x17, eq
    // 0x6bf0d8: LeaveFrame
    //     0x6bf0d8: mov             SP, fp
    //     0x6bf0dc: ldp             fp, lr, [SP], #0x10
    // 0x6bf0e0: ret
    //     0x6bf0e0: ret             
    // 0x6bf0e4: r0 = noElement()
    //     0x6bf0e4: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x6bf0e8: r0 = Throw()
    //     0x6bf0e8: bl              #0xd67e38  ; ThrowStub
    // 0x6bf0ec: brk             #0
    // 0x6bf0f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf0f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf0f4: b               #0x6bf06c
    // 0x6bf0f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6bf0f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ contains(/* No info */) {
    // ** addr: 0x6c0408, size: 0xf8
    // 0x6c0408: EnterFrame
    //     0x6c0408: stp             fp, lr, [SP, #-0x10]!
    //     0x6c040c: mov             fp, SP
    // 0x6c0410: ldr             x2, [fp, #0x18]
    // 0x6c0414: LoadField: r3 = r2->field_b
    //     0x6c0414: ldur            x3, [x2, #0xb]
    // 0x6c0418: LoadField: r4 = r2->field_7
    //     0x6c0418: ldur            w4, [x2, #7]
    // 0x6c041c: DecompressPointer r4
    //     0x6c041c: add             x4, x4, HEAP, lsl #32
    // 0x6c0420: LoadField: r2 = r4->field_b
    //     0x6c0420: ldur            w2, [x4, #0xb]
    // 0x6c0424: DecompressPointer r2
    //     0x6c0424: add             x2, x2, HEAP, lsl #32
    // 0x6c0428: r5 = LoadInt32Instr(r2)
    //     0x6c0428: sbfx            x5, x2, #1, #0x1f
    // 0x6c042c: LoadField: r2 = r4->field_f
    //     0x6c042c: ldur            w2, [x4, #0xf]
    // 0x6c0430: DecompressPointer r2
    //     0x6c0430: add             x2, x2, HEAP, lsl #32
    // 0x6c0434: ldr             x9, [fp, #0x10]
    // 0x6c0438: r10 = 0
    //     0x6c0438: mov             x10, #0
    // 0x6c043c: r8 = 8
    //     0x6c043c: mov             x8, #8
    // 0x6c0440: r7 = 7
    //     0x6c0440: mov             x7, #7
    // 0x6c0444: r6 = 7
    //     0x6c0444: mov             x6, #7
    // 0x6c0448: r4 = 1
    //     0x6c0448: mov             x4, #1
    // 0x6c044c: CheckStackOverflow
    //     0x6c044c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c0450: cmp             SP, x16
    //     0x6c0454: b.ls            #0x6c04f4
    // 0x6c0458: cmp             x10, x3
    // 0x6c045c: b.ge            #0x6c04e4
    // 0x6c0460: sdiv            x11, x10, x8
    // 0x6c0464: mov             x0, x5
    // 0x6c0468: mov             x1, x11
    // 0x6c046c: cmp             x1, x0
    // 0x6c0470: b.hs            #0x6c04fc
    // 0x6c0474: ArrayLoad: r1 = r2[r11]  ; Unknown_4
    //     0x6c0474: add             x16, x2, x11, lsl #2
    //     0x6c0478: ldur            w1, [x16, #0xf]
    // 0x6c047c: DecompressPointer r1
    //     0x6c047c: add             x1, x1, HEAP, lsl #32
    // 0x6c0480: mov             x11, x10
    // 0x6c0484: ubfx            x11, x11, #0, #0x20
    // 0x6c0488: and             x12, x11, x6
    // 0x6c048c: ubfx            x12, x12, #0, #0x20
    // 0x6c0490: sub             x11, x7, x12
    // 0x6c0494: r12 = LoadInt32Instr(r1)
    //     0x6c0494: sbfx            x12, x1, #1, #0x1f
    //     0x6c0498: tbz             w1, #0, #0x6c04a0
    //     0x6c049c: ldur            x12, [x1, #7]
    // 0x6c04a0: asr             x1, x12, x11
    // 0x6c04a4: ubfx            x1, x1, #0, #0x20
    // 0x6c04a8: and             x11, x1, x4
    // 0x6c04ac: ubfx            x11, x11, #0, #0x20
    // 0x6c04b0: cmp             x11, #1
    // 0x6c04b4: r16 = true
    //     0x6c04b4: add             x16, NULL, #0x20  ; true
    // 0x6c04b8: r17 = false
    //     0x6c04b8: add             x17, NULL, #0x30  ; false
    // 0x6c04bc: csel            x1, x16, x17, eq
    // 0x6c04c0: cmp             w1, w9
    // 0x6c04c4: b.ne            #0x6c04d8
    // 0x6c04c8: r0 = true
    //     0x6c04c8: add             x0, NULL, #0x20  ; true
    // 0x6c04cc: LeaveFrame
    //     0x6c04cc: mov             SP, fp
    //     0x6c04d0: ldp             fp, lr, [SP], #0x10
    // 0x6c04d4: ret
    //     0x6c04d4: ret             
    // 0x6c04d8: add             x0, x10, #1
    // 0x6c04dc: mov             x10, x0
    // 0x6c04e0: b               #0x6c044c
    // 0x6c04e4: r0 = false
    //     0x6c04e4: add             x0, NULL, #0x30  ; false
    // 0x6c04e8: LeaveFrame
    //     0x6c04e8: mov             SP, fp
    //     0x6c04ec: ldp             fp, lr, [SP], #0x10
    // 0x6c04f0: ret
    //     0x6c04f0: ret             
    // 0x6c04f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c04f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c04f8: b               #0x6c0458
    // 0x6c04fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6c04fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  Iterable<Y0> map<Y0>(_BoolList&Object&ListMixin, (dynamic, bool) => Y0) {
    // ** addr: 0x6c0788, size: 0x78
    // 0x6c0788: EnterFrame
    //     0x6c0788: stp             fp, lr, [SP, #-0x10]!
    //     0x6c078c: mov             fp, SP
    // 0x6c0790: mov             x0, x4
    // 0x6c0794: LoadField: r1 = r0->field_f
    //     0x6c0794: ldur            w1, [x0, #0xf]
    // 0x6c0798: DecompressPointer r1
    //     0x6c0798: add             x1, x1, HEAP, lsl #32
    // 0x6c079c: cbnz            w1, #0x6c07a8
    // 0x6c07a0: r1 = Null
    //     0x6c07a0: mov             x1, NULL
    // 0x6c07a4: b               #0x6c07bc
    // 0x6c07a8: LoadField: r1 = r0->field_17
    //     0x6c07a8: ldur            w1, [x0, #0x17]
    // 0x6c07ac: DecompressPointer r1
    //     0x6c07ac: add             x1, x1, HEAP, lsl #32
    // 0x6c07b0: add             x0, fp, w1, sxtw #2
    // 0x6c07b4: ldr             x0, [x0, #0x10]
    // 0x6c07b8: mov             x1, x0
    // 0x6c07bc: ldr             x4, [fp, #0x18]
    // 0x6c07c0: ldr             x0, [fp, #0x10]
    // 0x6c07c4: r2 = Null
    //     0x6c07c4: mov             x2, NULL
    // 0x6c07c8: r3 = <Y0, bool, Y0>
    //     0x6c07c8: add             x3, PP, #0x41, lsl #12  ; [pp+0x413d0] TypeArguments: <Y0, bool, Y0>
    //     0x6c07cc: ldr             x3, [x3, #0x3d0]
    // 0x6c07d0: r24 = InstantiateTypeArgumentsStub
    //     0x6c07d0: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x6c07d4: LoadField: r30 = r24->field_7
    //     0x6c07d4: ldur            lr, [x24, #7]
    // 0x6c07d8: blr             lr
    // 0x6c07dc: mov             x1, x0
    // 0x6c07e0: r0 = MappedListIterable()
    //     0x6c07e0: bl              #0x6ba55c  ; AllocateMappedListIterableStub -> MappedListIterable<C1X1, C1X0> (size=0x14)
    // 0x6c07e4: ldr             x1, [fp, #0x18]
    // 0x6c07e8: StoreField: r0->field_b = r1
    //     0x6c07e8: stur            w1, [x0, #0xb]
    // 0x6c07ec: ldr             x1, [fp, #0x10]
    // 0x6c07f0: StoreField: r0->field_f = r1
    //     0x6c07f0: stur            w1, [x0, #0xf]
    // 0x6c07f4: LeaveFrame
    //     0x6c07f4: mov             SP, fp
    //     0x6c07f8: ldp             fp, lr, [SP], #0x10
    // 0x6c07fc: ret
    //     0x6c07fc: ret             
  }
  _ toList(/* No info */) {
    // ** addr: 0x6c0914, size: 0x248
    // 0x6c0914: EnterFrame
    //     0x6c0914: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0918: mov             fp, SP
    // 0x6c091c: AllocStack(0x20)
    //     0x6c091c: sub             SP, SP, #0x20
    // 0x6c0920: SetupParameters(_BoolList&Object&ListMixin this /* r3, fp-0x10 */, {dynamic growable = true /* r2 */})
    //     0x6c0920: mov             x0, x4
    //     0x6c0924: ldur            w1, [x0, #0x13]
    //     0x6c0928: add             x1, x1, HEAP, lsl #32
    //     0x6c092c: sub             x2, x1, #2
    //     0x6c0930: add             x3, fp, w2, sxtw #2
    //     0x6c0934: ldr             x3, [x3, #0x10]
    //     0x6c0938: stur            x3, [fp, #-0x10]
    //     0x6c093c: ldur            w2, [x0, #0x1f]
    //     0x6c0940: add             x2, x2, HEAP, lsl #32
    //     0x6c0944: ldr             x16, [PP, #0xc60]  ; [pp+0xc60] "growable"
    //     0x6c0948: cmp             w2, w16
    //     0x6c094c: b.ne            #0x6c096c
    //     0x6c0950: ldur            w2, [x0, #0x23]
    //     0x6c0954: add             x2, x2, HEAP, lsl #32
    //     0x6c0958: sub             w0, w1, w2
    //     0x6c095c: add             x1, fp, w0, sxtw #2
    //     0x6c0960: ldr             x1, [x1, #8]
    //     0x6c0964: mov             x2, x1
    //     0x6c0968: b               #0x6c0970
    //     0x6c096c: add             x2, NULL, #0x20  ; true
    // 0x6c0970: CheckStackOverflow
    //     0x6c0970: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c0974: cmp             SP, x16
    //     0x6c0978: b.ls            #0x6c0b44
    // 0x6c097c: LoadField: r4 = r3->field_b
    //     0x6c097c: ldur            x4, [x3, #0xb]
    // 0x6c0980: cbnz            x4, #0x6c09b4
    // 0x6c0984: tbnz            w2, #4, #0x6c099c
    // 0x6c0988: r16 = <bool>
    //     0x6c0988: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x6c098c: stp             xzr, x16, [SP, #-0x10]!
    // 0x6c0990: r0 = _GrowableList()
    //     0x6c0990: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6c0994: add             SP, SP, #0x10
    // 0x6c0998: b               #0x6c09a8
    // 0x6c099c: r1 = <bool>
    //     0x6c099c: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x6c09a0: r2 = 0
    //     0x6c09a0: mov             x2, #0
    // 0x6c09a4: r0 = AllocateArray()
    //     0x6c09a4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6c09a8: LeaveFrame
    //     0x6c09a8: mov             SP, fp
    //     0x6c09ac: ldp             fp, lr, [SP], #0x10
    // 0x6c09b0: ret
    //     0x6c09b0: ret             
    // 0x6c09b4: r5 = 1
    //     0x6c09b4: mov             x5, #1
    // 0x6c09b8: LoadField: r6 = r3->field_7
    //     0x6c09b8: ldur            w6, [x3, #7]
    // 0x6c09bc: DecompressPointer r6
    //     0x6c09bc: add             x6, x6, HEAP, lsl #32
    // 0x6c09c0: stur            x6, [fp, #-8]
    // 0x6c09c4: LoadField: r0 = r6->field_b
    //     0x6c09c4: ldur            w0, [x6, #0xb]
    // 0x6c09c8: DecompressPointer r0
    //     0x6c09c8: add             x0, x0, HEAP, lsl #32
    // 0x6c09cc: r1 = LoadInt32Instr(r0)
    //     0x6c09cc: sbfx            x1, x0, #1, #0x1f
    // 0x6c09d0: mov             x0, x1
    // 0x6c09d4: r1 = 0
    //     0x6c09d4: mov             x1, #0
    // 0x6c09d8: cmp             x1, x0
    // 0x6c09dc: b.hs            #0x6c0b4c
    // 0x6c09e0: LoadField: r0 = r6->field_f
    //     0x6c09e0: ldur            w0, [x6, #0xf]
    // 0x6c09e4: DecompressPointer r0
    //     0x6c09e4: add             x0, x0, HEAP, lsl #32
    // 0x6c09e8: LoadField: r1 = r0->field_f
    //     0x6c09e8: ldur            w1, [x0, #0xf]
    // 0x6c09ec: DecompressPointer r1
    //     0x6c09ec: add             x1, x1, HEAP, lsl #32
    // 0x6c09f0: r0 = LoadInt32Instr(r1)
    //     0x6c09f0: sbfx            x0, x1, #1, #0x1f
    //     0x6c09f4: tbz             w1, #0, #0x6c09fc
    //     0x6c09f8: ldur            x0, [x1, #7]
    // 0x6c09fc: asr             x1, x0, #7
    // 0x6c0a00: ubfx            x1, x1, #0, #0x20
    // 0x6c0a04: and             x0, x1, x5
    // 0x6c0a08: ubfx            x0, x0, #0, #0x20
    // 0x6c0a0c: cmp             x0, #1
    // 0x6c0a10: r16 = true
    //     0x6c0a10: add             x16, NULL, #0x20  ; true
    // 0x6c0a14: r17 = false
    //     0x6c0a14: add             x17, NULL, #0x30  ; false
    // 0x6c0a18: csel            x1, x16, x17, eq
    // 0x6c0a1c: r16 = <bool>
    //     0x6c0a1c: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x6c0a20: stp             x4, x16, [SP, #-0x10]!
    // 0x6c0a24: stp             x2, x1, [SP, #-0x10]!
    // 0x6c0a28: r0 = List.filled()
    //     0x6c0a28: bl              #0x6baa54  ; [dart:core] List::List.filled
    // 0x6c0a2c: add             SP, SP, #0x20
    // 0x6c0a30: mov             x2, x0
    // 0x6c0a34: stur            x2, [fp, #-0x20]
    // 0x6c0a38: r9 = 1
    //     0x6c0a38: mov             x9, #1
    // 0x6c0a3c: ldur            x3, [fp, #-0x10]
    // 0x6c0a40: ldur            x5, [fp, #-8]
    // 0x6c0a44: r8 = 7
    //     0x6c0a44: mov             x8, #7
    // 0x6c0a48: r7 = 8
    //     0x6c0a48: mov             x7, #8
    // 0x6c0a4c: r4 = 1
    //     0x6c0a4c: mov             x4, #1
    // 0x6c0a50: r6 = 7
    //     0x6c0a50: mov             x6, #7
    // 0x6c0a54: stur            x9, [fp, #-0x18]
    // 0x6c0a58: CheckStackOverflow
    //     0x6c0a58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c0a5c: cmp             SP, x16
    //     0x6c0a60: b.ls            #0x6c0b50
    // 0x6c0a64: LoadField: r0 = r3->field_b
    //     0x6c0a64: ldur            x0, [x3, #0xb]
    // 0x6c0a68: cmp             x9, x0
    // 0x6c0a6c: b.ge            #0x6c0b34
    // 0x6c0a70: sdiv            x10, x9, x7
    // 0x6c0a74: LoadField: r0 = r5->field_b
    //     0x6c0a74: ldur            w0, [x5, #0xb]
    // 0x6c0a78: DecompressPointer r0
    //     0x6c0a78: add             x0, x0, HEAP, lsl #32
    // 0x6c0a7c: r1 = LoadInt32Instr(r0)
    //     0x6c0a7c: sbfx            x1, x0, #1, #0x1f
    // 0x6c0a80: mov             x0, x1
    // 0x6c0a84: mov             x1, x10
    // 0x6c0a88: cmp             x1, x0
    // 0x6c0a8c: b.hs            #0x6c0b58
    // 0x6c0a90: LoadField: r0 = r5->field_f
    //     0x6c0a90: ldur            w0, [x5, #0xf]
    // 0x6c0a94: DecompressPointer r0
    //     0x6c0a94: add             x0, x0, HEAP, lsl #32
    // 0x6c0a98: ArrayLoad: r1 = r0[r10]  ; Unknown_4
    //     0x6c0a98: add             x16, x0, x10, lsl #2
    //     0x6c0a9c: ldur            w1, [x16, #0xf]
    // 0x6c0aa0: DecompressPointer r1
    //     0x6c0aa0: add             x1, x1, HEAP, lsl #32
    // 0x6c0aa4: mov             x0, x9
    // 0x6c0aa8: ubfx            x0, x0, #0, #0x20
    // 0x6c0aac: and             x10, x0, x6
    // 0x6c0ab0: ubfx            x10, x10, #0, #0x20
    // 0x6c0ab4: sub             x0, x8, x10
    // 0x6c0ab8: r10 = LoadInt32Instr(r1)
    //     0x6c0ab8: sbfx            x10, x1, #1, #0x1f
    //     0x6c0abc: tbz             w1, #0, #0x6c0ac4
    //     0x6c0ac0: ldur            x10, [x1, #7]
    // 0x6c0ac4: asr             x1, x10, x0
    // 0x6c0ac8: ubfx            x1, x1, #0, #0x20
    // 0x6c0acc: and             x0, x1, x4
    // 0x6c0ad0: ubfx            x0, x0, #0, #0x20
    // 0x6c0ad4: cmp             x0, #1
    // 0x6c0ad8: r16 = true
    //     0x6c0ad8: add             x16, NULL, #0x20  ; true
    // 0x6c0adc: r17 = false
    //     0x6c0adc: add             x17, NULL, #0x30  ; false
    // 0x6c0ae0: csel            x10, x16, x17, eq
    // 0x6c0ae4: r0 = BoxInt64Instr(r9)
    //     0x6c0ae4: sbfiz           x0, x9, #1, #0x1f
    //     0x6c0ae8: cmp             x9, x0, asr #1
    //     0x6c0aec: b.eq            #0x6c0af8
    //     0x6c0af0: bl              #0xd69bb8
    //     0x6c0af4: stur            x9, [x0, #7]
    // 0x6c0af8: r1 = LoadClassIdInstr(r2)
    //     0x6c0af8: ldur            x1, [x2, #-1]
    //     0x6c0afc: ubfx            x1, x1, #0xc, #0x14
    // 0x6c0b00: stp             x0, x2, [SP, #-0x10]!
    // 0x6c0b04: SaveReg r10
    //     0x6c0b04: str             x10, [SP, #-8]!
    // 0x6c0b08: mov             x0, x1
    // 0x6c0b0c: r0 = GDT[cid_x0 + 0x1015e]()
    //     0x6c0b0c: mov             x17, #0x15e
    //     0x6c0b10: movk            x17, #1, lsl #16
    //     0x6c0b14: add             lr, x0, x17
    //     0x6c0b18: ldr             lr, [x21, lr, lsl #3]
    //     0x6c0b1c: blr             lr
    // 0x6c0b20: add             SP, SP, #0x18
    // 0x6c0b24: ldur            x1, [fp, #-0x18]
    // 0x6c0b28: add             x9, x1, #1
    // 0x6c0b2c: ldur            x2, [fp, #-0x20]
    // 0x6c0b30: b               #0x6c0a3c
    // 0x6c0b34: ldur            x0, [fp, #-0x20]
    // 0x6c0b38: LeaveFrame
    //     0x6c0b38: mov             SP, fp
    //     0x6c0b3c: ldp             fp, lr, [SP], #0x10
    // 0x6c0b40: ret
    //     0x6c0b40: ret             
    // 0x6c0b44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0b44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0b48: b               #0x6c097c
    // 0x6c0b4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6c0b4c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6c0b50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0b50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0b54: b               #0x6c0a64
    // 0x6c0b58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6c0b58: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ iterator(/* No info */) {
    // ** addr: 0x717084, size: 0x34
    // 0x717084: EnterFrame
    //     0x717084: stp             fp, lr, [SP, #-0x10]!
    //     0x717088: mov             fp, SP
    // 0x71708c: r1 = <bool>
    //     0x71708c: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x717090: r0 = ListIterator()
    //     0x717090: bl              #0x50a2a0  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x717094: ldr             x1, [fp, #0x10]
    // 0x717098: StoreField: r0->field_b = r1
    //     0x717098: stur            w1, [x0, #0xb]
    // 0x71709c: LoadField: r2 = r1->field_b
    //     0x71709c: ldur            x2, [x1, #0xb]
    // 0x7170a0: StoreField: r0->field_f = r2
    //     0x7170a0: stur            x2, [x0, #0xf]
    // 0x7170a4: r1 = 0
    //     0x7170a4: mov             x1, #0
    // 0x7170a8: StoreField: r0->field_17 = r1
    //     0x7170a8: stur            x1, [x0, #0x17]
    // 0x7170ac: LeaveFrame
    //     0x7170ac: mov             SP, fp
    //     0x7170b0: ldp             fp, lr, [SP], #0x10
    // 0x7170b4: ret
    //     0x7170b4: ret             
  }
}

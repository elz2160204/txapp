// lib: , url: package:collection/src/iterable_extensions.dart

// class id: 1048764, size: 0x8
class :: {

  static _ IterableExtension.firstWhereOrNull(/* No info */) {
    // ** addr: 0x568cc4, size: 0x108
    // 0x568cc4: EnterFrame
    //     0x568cc4: stp             fp, lr, [SP, #-0x10]!
    //     0x568cc8: mov             fp, SP
    // 0x568ccc: AllocStack(0x18)
    //     0x568ccc: sub             SP, SP, #0x18
    // 0x568cd0: CheckStackOverflow
    //     0x568cd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x568cd4: cmp             SP, x16
    //     0x568cd8: b.ls            #0x568dbc
    // 0x568cdc: ldr             x0, [fp, #0x18]
    // 0x568ce0: r1 = LoadClassIdInstr(r0)
    //     0x568ce0: ldur            x1, [x0, #-1]
    //     0x568ce4: ubfx            x1, x1, #0xc, #0x14
    // 0x568ce8: SaveReg r0
    //     0x568ce8: str             x0, [SP, #-8]!
    // 0x568cec: mov             x0, x1
    // 0x568cf0: r0 = GDT[cid_x0 + 0xb940]()
    //     0x568cf0: mov             x17, #0xb940
    //     0x568cf4: add             lr, x0, x17
    //     0x568cf8: ldr             lr, [x21, lr, lsl #3]
    //     0x568cfc: blr             lr
    // 0x568d00: add             SP, SP, #8
    // 0x568d04: mov             x1, x0
    // 0x568d08: stur            x1, [fp, #-8]
    // 0x568d0c: CheckStackOverflow
    //     0x568d0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x568d10: cmp             SP, x16
    //     0x568d14: b.ls            #0x568dc4
    // 0x568d18: r0 = LoadClassIdInstr(r1)
    //     0x568d18: ldur            x0, [x1, #-1]
    //     0x568d1c: ubfx            x0, x0, #0xc, #0x14
    // 0x568d20: SaveReg r1
    //     0x568d20: str             x1, [SP, #-8]!
    // 0x568d24: r0 = GDT[cid_x0 + 0x541]()
    //     0x568d24: add             lr, x0, #0x541
    //     0x568d28: ldr             lr, [x21, lr, lsl #3]
    //     0x568d2c: blr             lr
    // 0x568d30: add             SP, SP, #8
    // 0x568d34: tbnz            w0, #4, #0x568dac
    // 0x568d38: ldur            x1, [fp, #-8]
    // 0x568d3c: r0 = LoadClassIdInstr(r1)
    //     0x568d3c: ldur            x0, [x1, #-1]
    //     0x568d40: ubfx            x0, x0, #0xc, #0x14
    // 0x568d44: SaveReg r1
    //     0x568d44: str             x1, [SP, #-8]!
    // 0x568d48: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x568d48: add             lr, x0, #0x5ca
    //     0x568d4c: ldr             lr, [x21, lr, lsl #3]
    //     0x568d50: blr             lr
    // 0x568d54: add             SP, SP, #8
    // 0x568d58: mov             x1, x0
    // 0x568d5c: stur            x1, [fp, #-0x10]
    // 0x568d60: ldr             x16, [fp, #0x10]
    // 0x568d64: stp             x1, x16, [SP, #-0x10]!
    // 0x568d68: ldr             x0, [fp, #0x10]
    // 0x568d6c: ClosureCall
    //     0x568d6c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x568d70: ldur            x2, [x0, #0x1f]
    //     0x568d74: blr             x2
    // 0x568d78: add             SP, SP, #0x10
    // 0x568d7c: mov             x1, x0
    // 0x568d80: stur            x1, [fp, #-0x18]
    // 0x568d84: tbnz            w0, #5, #0x568d8c
    // 0x568d88: r0 = AssertBoolean()
    //     0x568d88: bl              #0xd67df0  ; AssertBooleanStub
    // 0x568d8c: ldur            x1, [fp, #-0x18]
    // 0x568d90: tbnz            w1, #4, #0x568da4
    // 0x568d94: ldur            x0, [fp, #-0x10]
    // 0x568d98: LeaveFrame
    //     0x568d98: mov             SP, fp
    //     0x568d9c: ldp             fp, lr, [SP], #0x10
    // 0x568da0: ret
    //     0x568da0: ret             
    // 0x568da4: ldur            x1, [fp, #-8]
    // 0x568da8: b               #0x568d0c
    // 0x568dac: r0 = Null
    //     0x568dac: mov             x0, NULL
    // 0x568db0: LeaveFrame
    //     0x568db0: mov             SP, fp
    //     0x568db4: ldp             fp, lr, [SP], #0x10
    // 0x568db8: ret
    //     0x568db8: ret             
    // 0x568dbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x568dbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x568dc0: b               #0x568cdc
    // 0x568dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x568dc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x568dc8: b               #0x568d18
  }
  static _ IterableExtension.firstOrNull(/* No info */) {
    // ** addr: 0xb63160, size: 0xb0
    // 0xb63160: EnterFrame
    //     0xb63160: stp             fp, lr, [SP, #-0x10]!
    //     0xb63164: mov             fp, SP
    // 0xb63168: AllocStack(0x8)
    //     0xb63168: sub             SP, SP, #8
    // 0xb6316c: CheckStackOverflow
    //     0xb6316c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb63170: cmp             SP, x16
    //     0xb63174: b.ls            #0xb63208
    // 0xb63178: ldr             x0, [fp, #0x10]
    // 0xb6317c: r1 = LoadClassIdInstr(r0)
    //     0xb6317c: ldur            x1, [x0, #-1]
    //     0xb63180: ubfx            x1, x1, #0xc, #0x14
    // 0xb63184: SaveReg r0
    //     0xb63184: str             x0, [SP, #-8]!
    // 0xb63188: mov             x0, x1
    // 0xb6318c: r0 = GDT[cid_x0 + 0xb940]()
    //     0xb6318c: mov             x17, #0xb940
    //     0xb63190: add             lr, x0, x17
    //     0xb63194: ldr             lr, [x21, lr, lsl #3]
    //     0xb63198: blr             lr
    // 0xb6319c: add             SP, SP, #8
    // 0xb631a0: mov             x1, x0
    // 0xb631a4: stur            x1, [fp, #-8]
    // 0xb631a8: r0 = LoadClassIdInstr(r1)
    //     0xb631a8: ldur            x0, [x1, #-1]
    //     0xb631ac: ubfx            x0, x0, #0xc, #0x14
    // 0xb631b0: SaveReg r1
    //     0xb631b0: str             x1, [SP, #-8]!
    // 0xb631b4: r0 = GDT[cid_x0 + 0x541]()
    //     0xb631b4: add             lr, x0, #0x541
    //     0xb631b8: ldr             lr, [x21, lr, lsl #3]
    //     0xb631bc: blr             lr
    // 0xb631c0: add             SP, SP, #8
    // 0xb631c4: tbnz            w0, #4, #0xb631f8
    // 0xb631c8: ldur            x0, [fp, #-8]
    // 0xb631cc: r1 = LoadClassIdInstr(r0)
    //     0xb631cc: ldur            x1, [x0, #-1]
    //     0xb631d0: ubfx            x1, x1, #0xc, #0x14
    // 0xb631d4: SaveReg r0
    //     0xb631d4: str             x0, [SP, #-8]!
    // 0xb631d8: mov             x0, x1
    // 0xb631dc: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xb631dc: add             lr, x0, #0x5ca
    //     0xb631e0: ldr             lr, [x21, lr, lsl #3]
    //     0xb631e4: blr             lr
    // 0xb631e8: add             SP, SP, #8
    // 0xb631ec: LeaveFrame
    //     0xb631ec: mov             SP, fp
    //     0xb631f0: ldp             fp, lr, [SP], #0x10
    // 0xb631f4: ret
    //     0xb631f4: ret             
    // 0xb631f8: r0 = Null
    //     0xb631f8: mov             x0, NULL
    // 0xb631fc: LeaveFrame
    //     0xb631fc: mov             SP, fp
    //     0xb63200: ldp             fp, lr, [SP], #0x10
    // 0xb63204: ret
    //     0xb63204: ret             
    // 0xb63208: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb63208: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6320c: b               #0xb63178
  }
}

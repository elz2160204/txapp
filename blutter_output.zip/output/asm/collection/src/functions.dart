// lib: , url: package:collection/src/functions.dart

// class id: 1048763, size: 0x8
class :: {

  static _ groupBy(/* No info */) {
    // ** addr: 0xacb160, size: 0x340
    // 0xacb160: EnterFrame
    //     0xacb160: stp             fp, lr, [SP, #-0x10]!
    //     0xacb164: mov             fp, SP
    // 0xacb168: AllocStack(0x58)
    //     0xacb168: sub             SP, SP, #0x58
    // 0xacb16c: SetupParameters()
    //     0xacb16c: mov             x0, x4
    //     0xacb170: ldur            w1, [x0, #0xf]
    //     0xacb174: add             x1, x1, HEAP, lsl #32
    //     0xacb178: cbnz            w1, #0xacb184
    //     0xacb17c: mov             x4, NULL
    //     0xacb180: b               #0xacb198
    //     0xacb184: ldur            w1, [x0, #0x17]
    //     0xacb188: add             x1, x1, HEAP, lsl #32
    //     0xacb18c: add             x0, fp, w1, sxtw #2
    //     0xacb190: ldr             x0, [x0, #0x10]
    //     0xacb194: mov             x4, x0
    //     0xacb198: ldr             x0, [fp, #0x18]
    //     0xacb19c: stur            x4, [fp, #-8]
    // 0xacb1a0: CheckStackOverflow
    //     0xacb1a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacb1a4: cmp             SP, x16
    //     0xacb1a8: b.ls            #0xacb490
    // 0xacb1ac: mov             x1, x4
    // 0xacb1b0: r2 = Null
    //     0xacb1b0: mov             x2, NULL
    // 0xacb1b4: r3 = <Y1, List<Y0>>
    //     0xacb1b4: add             x3, PP, #0x1b, lsl #12  ; [pp+0x1bf68] TypeArguments: <Y1, List<Y0>>
    //     0xacb1b8: ldr             x3, [x3, #0xf68]
    // 0xacb1bc: r24 = InstantiateTypeArgumentsStub
    //     0xacb1bc: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xacb1c0: LoadField: r30 = r24->field_7
    //     0xacb1c0: ldur            lr, [x24, #7]
    // 0xacb1c4: blr             lr
    // 0xacb1c8: ldr             x16, [THR, #0xe8]  ; THR::empty_array
    // 0xacb1cc: stp             x16, x0, [SP, #-0x10]!
    // 0xacb1d0: r0 = Map._fromLiteral()
    //     0xacb1d0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xacb1d4: add             SP, SP, #0x10
    // 0xacb1d8: mov             x2, x0
    // 0xacb1dc: ldr             x1, [fp, #0x18]
    // 0xacb1e0: stur            x2, [fp, #-0x30]
    // 0xacb1e4: LoadField: r3 = r1->field_7
    //     0xacb1e4: ldur            w3, [x1, #7]
    // 0xacb1e8: DecompressPointer r3
    //     0xacb1e8: add             x3, x3, HEAP, lsl #32
    // 0xacb1ec: stur            x3, [fp, #-0x28]
    // 0xacb1f0: LoadField: r0 = r1->field_b
    //     0xacb1f0: ldur            w0, [x1, #0xb]
    // 0xacb1f4: DecompressPointer r0
    //     0xacb1f4: add             x0, x0, HEAP, lsl #32
    // 0xacb1f8: r4 = LoadInt32Instr(r0)
    //     0xacb1f8: sbfx            x4, x0, #1, #0x1f
    // 0xacb1fc: stur            x4, [fp, #-0x20]
    // 0xacb200: LoadField: r5 = r2->field_7
    //     0xacb200: ldur            w5, [x2, #7]
    // 0xacb204: DecompressPointer r5
    //     0xacb204: add             x5, x5, HEAP, lsl #32
    // 0xacb208: stur            x5, [fp, #-0x18]
    // 0xacb20c: r6 = 0
    //     0xacb20c: mov             x6, #0
    // 0xacb210: stur            x6, [fp, #-0x10]
    // 0xacb214: CheckStackOverflow
    //     0xacb214: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacb218: cmp             SP, x16
    //     0xacb21c: b.ls            #0xacb498
    // 0xacb220: r0 = LoadClassIdInstr(r1)
    //     0xacb220: ldur            x0, [x1, #-1]
    //     0xacb224: ubfx            x0, x0, #0xc, #0x14
    // 0xacb228: SaveReg r1
    //     0xacb228: str             x1, [SP, #-8]!
    // 0xacb22c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xacb22c: mov             x17, #0xb8ea
    //     0xacb230: add             lr, x0, x17
    //     0xacb234: ldr             lr, [x21, lr, lsl #3]
    //     0xacb238: blr             lr
    // 0xacb23c: add             SP, SP, #8
    // 0xacb240: r1 = LoadInt32Instr(r0)
    //     0xacb240: sbfx            x1, x0, #1, #0x1f
    //     0xacb244: tbz             w0, #0, #0xacb24c
    //     0xacb248: ldur            x1, [x0, #7]
    // 0xacb24c: ldur            x2, [fp, #-0x20]
    // 0xacb250: cmp             x2, x1
    // 0xacb254: b.ne            #0xacb478
    // 0xacb258: ldr             x3, [fp, #0x18]
    // 0xacb25c: ldur            x4, [fp, #-0x10]
    // 0xacb260: cmp             x4, x1
    // 0xacb264: b.lt            #0xacb278
    // 0xacb268: ldur            x0, [fp, #-0x30]
    // 0xacb26c: LeaveFrame
    //     0xacb26c: mov             SP, fp
    //     0xacb270: ldp             fp, lr, [SP], #0x10
    // 0xacb274: ret
    //     0xacb274: ret             
    // 0xacb278: r0 = BoxInt64Instr(r4)
    //     0xacb278: sbfiz           x0, x4, #1, #0x1f
    //     0xacb27c: cmp             x4, x0, asr #1
    //     0xacb280: b.eq            #0xacb28c
    //     0xacb284: bl              #0xd69bb8
    //     0xacb288: stur            x4, [x0, #7]
    // 0xacb28c: r1 = LoadClassIdInstr(r3)
    //     0xacb28c: ldur            x1, [x3, #-1]
    //     0xacb290: ubfx            x1, x1, #0xc, #0x14
    // 0xacb294: stp             x0, x3, [SP, #-0x10]!
    // 0xacb298: mov             x0, x1
    // 0xacb29c: r0 = GDT[cid_x0 + 0xd175]()
    //     0xacb29c: mov             x17, #0xd175
    //     0xacb2a0: add             lr, x0, x17
    //     0xacb2a4: ldr             lr, [x21, lr, lsl #3]
    //     0xacb2a8: blr             lr
    // 0xacb2ac: add             SP, SP, #0x10
    // 0xacb2b0: mov             x3, x0
    // 0xacb2b4: ldur            x0, [fp, #-0x10]
    // 0xacb2b8: stur            x3, [fp, #-0x40]
    // 0xacb2bc: add             x6, x0, #1
    // 0xacb2c0: stur            x6, [fp, #-0x38]
    // 0xacb2c4: cmp             w3, NULL
    // 0xacb2c8: b.ne            #0xacb2fc
    // 0xacb2cc: mov             x0, x3
    // 0xacb2d0: ldur            x2, [fp, #-0x28]
    // 0xacb2d4: r1 = Null
    //     0xacb2d4: mov             x1, NULL
    // 0xacb2d8: cmp             w2, NULL
    // 0xacb2dc: b.eq            #0xacb2fc
    // 0xacb2e0: LoadField: r4 = r2->field_17
    //     0xacb2e0: ldur            w4, [x2, #0x17]
    // 0xacb2e4: DecompressPointer r4
    //     0xacb2e4: add             x4, x4, HEAP, lsl #32
    // 0xacb2e8: r8 = X0
    //     0xacb2e8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xacb2ec: LoadField: r9 = r4->field_7
    //     0xacb2ec: ldur            x9, [x4, #7]
    // 0xacb2f0: r3 = Null
    //     0xacb2f0: add             x3, PP, #0x1b, lsl #12  ; [pp+0x1bf70] Null
    //     0xacb2f4: ldr             x3, [x3, #0xf70]
    // 0xacb2f8: blr             x9
    // 0xacb2fc: ldur            x1, [fp, #-0x30]
    // 0xacb300: ldr             x16, [fp, #0x10]
    // 0xacb304: ldur            lr, [fp, #-0x40]
    // 0xacb308: stp             lr, x16, [SP, #-0x10]!
    // 0xacb30c: ldr             x0, [fp, #0x10]
    // 0xacb310: ClosureCall
    //     0xacb310: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xacb314: ldur            x2, [x0, #0x1f]
    //     0xacb318: blr             x2
    // 0xacb31c: add             SP, SP, #0x10
    // 0xacb320: stur            x0, [fp, #-0x48]
    // 0xacb324: ldur            x16, [fp, #-0x30]
    // 0xacb328: stp             x0, x16, [SP, #-0x10]!
    // 0xacb32c: r0 = _getValueOrData()
    //     0xacb32c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xacb330: add             SP, SP, #0x10
    // 0xacb334: mov             x1, x0
    // 0xacb338: ldur            x0, [fp, #-0x30]
    // 0xacb33c: LoadField: r2 = r0->field_f
    //     0xacb33c: ldur            w2, [x0, #0xf]
    // 0xacb340: DecompressPointer r2
    //     0xacb340: add             x2, x2, HEAP, lsl #32
    // 0xacb344: cmp             w2, w1
    // 0xacb348: b.ne            #0xacb350
    // 0xacb34c: r1 = Null
    //     0xacb34c: mov             x1, NULL
    // 0xacb350: cmp             w1, NULL
    // 0xacb354: b.ne            #0xacb42c
    // 0xacb358: r0 = InitLateStaticField(0x0) // [dart:core] _GrowableList<X0>::_emptyList
    //     0xacb358: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xacb35c: ldr             x0, [x0]
    //     0xacb360: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xacb364: cmp             w0, w16
    //     0xacb368: b.ne            #0xacb374
    //     0xacb36c: ldr             x2, [PP, #0x7c8]  ; [pp+0x7c8] Field <_GrowableList@0150898._emptyList@0150898>: static late final (offset: 0x0)
    //     0xacb370: bl              #0xd67cdc
    // 0xacb374: ldur            x1, [fp, #-8]
    // 0xacb378: stur            x0, [fp, #-0x50]
    // 0xacb37c: r0 = AllocateGrowableArray()
    //     0xacb37c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xacb380: mov             x3, x0
    // 0xacb384: ldur            x0, [fp, #-0x50]
    // 0xacb388: stur            x3, [fp, #-0x58]
    // 0xacb38c: StoreField: r3->field_f = r0
    //     0xacb38c: stur            w0, [x3, #0xf]
    // 0xacb390: StoreField: r3->field_b = rZR
    //     0xacb390: stur            wzr, [x3, #0xb]
    // 0xacb394: ldur            x0, [fp, #-0x48]
    // 0xacb398: ldur            x2, [fp, #-0x18]
    // 0xacb39c: r1 = Null
    //     0xacb39c: mov             x1, NULL
    // 0xacb3a0: cmp             w2, NULL
    // 0xacb3a4: b.eq            #0xacb3c4
    // 0xacb3a8: LoadField: r4 = r2->field_17
    //     0xacb3a8: ldur            w4, [x2, #0x17]
    // 0xacb3ac: DecompressPointer r4
    //     0xacb3ac: add             x4, x4, HEAP, lsl #32
    // 0xacb3b0: r8 = X0
    //     0xacb3b0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xacb3b4: LoadField: r9 = r4->field_7
    //     0xacb3b4: ldur            x9, [x4, #7]
    // 0xacb3b8: r3 = Null
    //     0xacb3b8: add             x3, PP, #0x1b, lsl #12  ; [pp+0x1bf80] Null
    //     0xacb3bc: ldr             x3, [x3, #0xf80]
    // 0xacb3c0: blr             x9
    // 0xacb3c4: ldur            x0, [fp, #-0x58]
    // 0xacb3c8: ldur            x2, [fp, #-0x18]
    // 0xacb3cc: r1 = Null
    //     0xacb3cc: mov             x1, NULL
    // 0xacb3d0: cmp             w2, NULL
    // 0xacb3d4: b.eq            #0xacb3f4
    // 0xacb3d8: LoadField: r4 = r2->field_1b
    //     0xacb3d8: ldur            w4, [x2, #0x1b]
    // 0xacb3dc: DecompressPointer r4
    //     0xacb3dc: add             x4, x4, HEAP, lsl #32
    // 0xacb3e0: r8 = X1
    //     0xacb3e0: ldr             x8, [PP, #0x9a0]  ; [pp+0x9a0] TypeParameter: X1
    // 0xacb3e4: LoadField: r9 = r4->field_7
    //     0xacb3e4: ldur            x9, [x4, #7]
    // 0xacb3e8: r3 = Null
    //     0xacb3e8: add             x3, PP, #0x1b, lsl #12  ; [pp+0x1bf90] Null
    //     0xacb3ec: ldr             x3, [x3, #0xf90]
    // 0xacb3f0: blr             x9
    // 0xacb3f4: ldur            x16, [fp, #-0x30]
    // 0xacb3f8: ldur            lr, [fp, #-0x48]
    // 0xacb3fc: stp             lr, x16, [SP, #-0x10]!
    // 0xacb400: r0 = hash()
    //     0xacb400: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0xacb404: add             SP, SP, #0x10
    // 0xacb408: ldur            x16, [fp, #-0x30]
    // 0xacb40c: ldur            lr, [fp, #-0x48]
    // 0xacb410: stp             lr, x16, [SP, #-0x10]!
    // 0xacb414: ldur            x16, [fp, #-0x58]
    // 0xacb418: stp             x0, x16, [SP, #-0x10]!
    // 0xacb41c: r0 = _set()
    //     0xacb41c: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xacb420: add             SP, SP, #0x20
    // 0xacb424: ldur            x0, [fp, #-0x58]
    // 0xacb428: b               #0xacb430
    // 0xacb42c: mov             x0, x1
    // 0xacb430: r1 = LoadClassIdInstr(r0)
    //     0xacb430: ldur            x1, [x0, #-1]
    //     0xacb434: ubfx            x1, x1, #0xc, #0x14
    // 0xacb438: ldur            x16, [fp, #-0x40]
    // 0xacb43c: stp             x16, x0, [SP, #-0x10]!
    // 0xacb440: mov             x0, x1
    // 0xacb444: r0 = GDT[cid_x0 + 0x101bb]()
    //     0xacb444: mov             x17, #0x1bb
    //     0xacb448: movk            x17, #1, lsl #16
    //     0xacb44c: add             lr, x0, x17
    //     0xacb450: ldr             lr, [x21, lr, lsl #3]
    //     0xacb454: blr             lr
    // 0xacb458: add             SP, SP, #0x10
    // 0xacb45c: ldur            x6, [fp, #-0x38]
    // 0xacb460: ldr             x1, [fp, #0x18]
    // 0xacb464: ldur            x2, [fp, #-0x30]
    // 0xacb468: ldur            x5, [fp, #-0x18]
    // 0xacb46c: ldur            x3, [fp, #-0x28]
    // 0xacb470: ldur            x4, [fp, #-0x20]
    // 0xacb474: b               #0xacb210
    // 0xacb478: ldr             x0, [fp, #0x18]
    // 0xacb47c: r0 = ConcurrentModificationError()
    //     0xacb47c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xacb480: ldr             x3, [fp, #0x18]
    // 0xacb484: StoreField: r0->field_b = r3
    //     0xacb484: stur            w3, [x0, #0xb]
    // 0xacb488: r0 = Throw()
    //     0xacb488: bl              #0xd67e38  ; ThrowStub
    // 0xacb48c: brk             #0
    // 0xacb490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacb490: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacb494: b               #0xacb1ac
    // 0xacb498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacb498: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacb49c: b               #0xacb220
  }
}

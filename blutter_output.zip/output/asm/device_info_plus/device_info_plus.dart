// lib: , url: package:device_info_plus/device_info_plus.dart

// class id: 1048866, size: 0x8
class :: {
}

// class id: 4560, size: 0xc, field offset: 0x8
class DeviceInfoPlugin extends Object {

  get _ androidInfo(/* No info */) async {
    // ** addr: 0x92b1b4, size: 0x1d0
    // 0x92b1b4: EnterFrame
    //     0x92b1b4: stp             fp, lr, [SP, #-0x10]!
    //     0x92b1b8: mov             fp, SP
    // 0x92b1bc: AllocStack(0x28)
    //     0x92b1bc: sub             SP, SP, #0x28
    // 0x92b1c0: SetupParameters(DeviceInfoPlugin this /* r1, fp-0x10 */)
    //     0x92b1c0: stur            NULL, [fp, #-8]
    //     0x92b1c4: mov             x0, #0
    //     0x92b1c8: add             x1, fp, w0, sxtw #2
    //     0x92b1cc: ldr             x1, [x1, #0x10]
    //     0x92b1d0: stur            x1, [fp, #-0x10]
    // 0x92b1d4: CheckStackOverflow
    //     0x92b1d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92b1d8: cmp             SP, x16
    //     0x92b1dc: b.ls            #0x92b37c
    // 0x92b1e0: InitAsync() -> Future<AndroidDeviceInfo>
    //     0x92b1e0: add             x0, PP, #0x33, lsl #12  ; [pp+0x33c10] TypeArguments: <AndroidDeviceInfo>
    //     0x92b1e4: ldr             x0, [x0, #0xc10]
    //     0x92b1e8: bl              #0x4b92e4
    // 0x92b1ec: ldur            x0, [fp, #-0x10]
    // 0x92b1f0: LoadField: r1 = r0->field_7
    //     0x92b1f0: ldur            w1, [x0, #7]
    // 0x92b1f4: DecompressPointer r1
    //     0x92b1f4: add             x1, x1, HEAP, lsl #32
    // 0x92b1f8: cmp             w1, NULL
    // 0x92b1fc: b.ne            #0x92b374
    // 0x92b200: r0 = InitLateStaticField(0xb3c) // [package:device_info_plus_platform_interface/device_info_plus_platform_interface.dart] DeviceInfoPlatform::_instance
    //     0x92b200: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92b204: ldr             x0, [x0, #0x1678]
    //     0x92b208: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92b20c: cmp             w0, w16
    //     0x92b210: b.ne            #0x92b220
    //     0x92b214: add             x2, PP, #0x33, lsl #12  ; [pp+0x33c18] Field <DeviceInfoPlatform._instance@337502559>: static late (offset: 0xb3c)
    //     0x92b218: ldr             x2, [x2, #0xc18]
    //     0x92b21c: bl              #0xd67d44
    // 0x92b220: stur            x0, [fp, #-0x18]
    // 0x92b224: r1 = LoadClassIdInstr(r0)
    //     0x92b224: ldur            x1, [x0, #-1]
    //     0x92b228: ubfx            x1, x1, #0xc, #0x14
    // 0x92b22c: lsl             x1, x1, #1
    // 0x92b230: r17 = 9898
    //     0x92b230: mov             x17, #0x26aa
    // 0x92b234: cmp             w1, w17
    // 0x92b238: b.ne            #0x92b2e8
    // 0x92b23c: LoadField: r1 = r0->field_7
    //     0x92b23c: ldur            w1, [x0, #7]
    // 0x92b240: DecompressPointer r1
    //     0x92b240: add             x1, x1, HEAP, lsl #32
    // 0x92b244: cmp             w1, NULL
    // 0x92b248: b.ne            #0x92b284
    // 0x92b24c: SaveReg r0
    //     0x92b24c: str             x0, [SP, #-8]!
    // 0x92b250: r0 = getInfo()
    //     0x92b250: bl              #0x92c424  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getInfo
    // 0x92b254: add             SP, SP, #8
    // 0x92b258: mov             x2, x0
    // 0x92b25c: ldur            x1, [fp, #-0x18]
    // 0x92b260: StoreField: r1->field_7 = r0
    //     0x92b260: stur            w0, [x1, #7]
    //     0x92b264: ldurb           w16, [x1, #-1]
    //     0x92b268: ldurb           w17, [x0, #-1]
    //     0x92b26c: and             x16, x17, x16, lsr #2
    //     0x92b270: tst             x16, HEAP, lsr #32
    //     0x92b274: b.eq            #0x92b27c
    //     0x92b278: bl              #0xd6826c
    // 0x92b27c: mov             x0, x2
    // 0x92b280: b               #0x92b288
    // 0x92b284: mov             x0, x1
    // 0x92b288: stur            x0, [fp, #-0x20]
    // 0x92b28c: r1 = <BaseDeviceInfo>
    //     0x92b28c: add             x1, PP, #0x33, lsl #12  ; [pp+0x33c20] TypeArguments: <BaseDeviceInfo>
    //     0x92b290: ldr             x1, [x1, #0xc20]
    // 0x92b294: r0 = _Future()
    //     0x92b294: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x92b298: mov             x1, x0
    // 0x92b29c: r0 = 0
    //     0x92b29c: mov             x0, #0
    // 0x92b2a0: stur            x1, [fp, #-0x28]
    // 0x92b2a4: StoreField: r1->field_b = r0
    //     0x92b2a4: stur            x0, [x1, #0xb]
    // 0x92b2a8: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x92b2a8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92b2ac: ldr             x0, [x0, #0xb58]
    //     0x92b2b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92b2b4: cmp             w0, w16
    //     0x92b2b8: b.ne            #0x92b2c4
    //     0x92b2bc: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x92b2c0: bl              #0xd67d44
    // 0x92b2c4: mov             x1, x0
    // 0x92b2c8: ldur            x0, [fp, #-0x28]
    // 0x92b2cc: StoreField: r0->field_13 = r1
    //     0x92b2cc: stur            w1, [x0, #0x13]
    // 0x92b2d0: ldur            x16, [fp, #-0x20]
    // 0x92b2d4: stp             x16, x0, [SP, #-0x10]!
    // 0x92b2d8: r0 = _asyncComplete()
    //     0x92b2d8: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x92b2dc: add             SP, SP, #0x10
    // 0x92b2e0: ldur            x2, [fp, #-0x28]
    // 0x92b2e4: b               #0x92b30c
    // 0x92b2e8: mov             x1, x0
    // 0x92b2ec: r0 = LoadClassIdInstr(r1)
    //     0x92b2ec: ldur            x0, [x1, #-1]
    //     0x92b2f0: ubfx            x0, x0, #0xc, #0x14
    // 0x92b2f4: SaveReg r1
    //     0x92b2f4: str             x1, [SP, #-8]!
    // 0x92b2f8: r0 = GDT[cid_x0 + 0x553]()
    //     0x92b2f8: add             lr, x0, #0x553
    //     0x92b2fc: ldr             lr, [x21, lr, lsl #3]
    //     0x92b300: blr             lr
    // 0x92b304: add             SP, SP, #8
    // 0x92b308: mov             x2, x0
    // 0x92b30c: ldur            x1, [fp, #-0x10]
    // 0x92b310: mov             x0, x2
    // 0x92b314: stur            x2, [fp, #-0x18]
    // 0x92b318: r0 = Await()
    //     0x92b318: bl              #0x4b8e6c  ; AwaitStub
    // 0x92b31c: r1 = LoadClassIdInstr(r0)
    //     0x92b31c: ldur            x1, [x0, #-1]
    //     0x92b320: ubfx            x1, x1, #0xc, #0x14
    // 0x92b324: SaveReg r0
    //     0x92b324: str             x0, [SP, #-8]!
    // 0x92b328: mov             x0, x1
    // 0x92b32c: r0 = GDT[cid_x0 + -0x7eb]()
    //     0x92b32c: sub             lr, x0, #0x7eb
    //     0x92b330: ldr             lr, [x21, lr, lsl #3]
    //     0x92b334: blr             lr
    // 0x92b338: add             SP, SP, #8
    // 0x92b33c: SaveReg r0
    //     0x92b33c: str             x0, [SP, #-8]!
    // 0x92b340: r0 = fromMap()
    //     0x92b340: bl              #0x92b384  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::fromMap
    // 0x92b344: add             SP, SP, #8
    // 0x92b348: mov             x1, x0
    // 0x92b34c: ldur            x2, [fp, #-0x10]
    // 0x92b350: StoreField: r2->field_7 = r0
    //     0x92b350: stur            w0, [x2, #7]
    //     0x92b354: ldurb           w16, [x2, #-1]
    //     0x92b358: ldurb           w17, [x0, #-1]
    //     0x92b35c: and             x16, x17, x16, lsr #2
    //     0x92b360: tst             x16, HEAP, lsr #32
    //     0x92b364: b.eq            #0x92b36c
    //     0x92b368: bl              #0xd6828c
    // 0x92b36c: mov             x0, x1
    // 0x92b370: b               #0x92b378
    // 0x92b374: mov             x0, x1
    // 0x92b378: r0 = ReturnAsyncNotFuture()
    //     0x92b378: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x92b37c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92b37c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92b380: b               #0x92b1e0
  }
}

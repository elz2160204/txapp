// lib: , url: package:device_info_plus/src/device_info_plus_linux.dart

// class id: 1048867, size: 0x8
class :: {

  static _ _KeyValues.toKeyValues(/* No info */) {
    // ** addr: 0xc56378, size: 0x84
    // 0xc56378: EnterFrame
    //     0xc56378: stp             fp, lr, [SP, #-0x10]!
    //     0xc5637c: mov             fp, SP
    // 0xc56380: CheckStackOverflow
    //     0xc56380: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc56384: cmp             SP, x16
    //     0xc56388: b.ls            #0xc563f4
    // 0xc5638c: r1 = Function '<anonymous closure>': static.
    //     0xc5638c: add             x1, PP, #0x41, lsl #12  ; [pp+0x411d8] AnonymousClosure: static (0xc56454), in [package:device_info_plus/src/device_info_plus_linux.dart] ::_KeyValues.toKeyValues (0xc56378)
    //     0xc56390: ldr             x1, [x1, #0x1d8]
    // 0xc56394: r2 = Null
    //     0xc56394: mov             x2, NULL
    // 0xc56398: r0 = AllocateClosure()
    //     0xc56398: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc5639c: mov             x1, x0
    // 0xc563a0: ldr             x0, [fp, #0x10]
    // 0xc563a4: r2 = LoadClassIdInstr(r0)
    //     0xc563a4: ldur            x2, [x0, #-1]
    //     0xc563a8: ubfx            x2, x2, #0xc, #0x14
    // 0xc563ac: r16 = <MapEntry<String, String?>>
    //     0xc563ac: add             x16, PP, #0x41, lsl #12  ; [pp+0x411e0] TypeArguments: <MapEntry<String, String?>>
    //     0xc563b0: ldr             x16, [x16, #0x1e0]
    // 0xc563b4: stp             x0, x16, [SP, #-0x10]!
    // 0xc563b8: SaveReg r1
    //     0xc563b8: str             x1, [SP, #-8]!
    // 0xc563bc: mov             x0, x2
    // 0xc563c0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc563c0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc563c4: r0 = GDT[cid_x0 + 0xc934]()
    //     0xc563c4: mov             x17, #0xc934
    //     0xc563c8: add             lr, x0, x17
    //     0xc563cc: ldr             lr, [x21, lr, lsl #3]
    //     0xc563d0: blr             lr
    // 0xc563d4: add             SP, SP, #0x18
    // 0xc563d8: r16 = <String, String?>
    //     0xc563d8: ldr             x16, [PP, #0x7650]  ; [pp+0x7650] TypeArguments: <String, String?>
    // 0xc563dc: stp             x0, x16, [SP, #-0x10]!
    // 0xc563e0: r0 = Map.fromEntries()
    //     0xc563e0: bl              #0xc563fc  ; [dart:core] Map::Map.fromEntries
    // 0xc563e4: add             SP, SP, #0x10
    // 0xc563e8: LeaveFrame
    //     0xc563e8: mov             SP, fp
    //     0xc563ec: ldp             fp, lr, [SP], #0x10
    // 0xc563f0: ret
    //     0xc563f0: ret             
    // 0xc563f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc563f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc563f8: b               #0xc5638c
  }
  [closure] static MapEntry<String, String?> <anonymous closure>(dynamic, String) {
    // ** addr: 0xc56454, size: 0xd4
    // 0xc56454: EnterFrame
    //     0xc56454: stp             fp, lr, [SP, #-0x10]!
    //     0xc56458: mov             fp, SP
    // 0xc5645c: AllocStack(0x10)
    //     0xc5645c: sub             SP, SP, #0x10
    // 0xc56460: CheckStackOverflow
    //     0xc56460: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc56464: cmp             SP, x16
    //     0xc56468: b.ls            #0xc56520
    // 0xc5646c: ldr             x1, [fp, #0x10]
    // 0xc56470: r0 = LoadClassIdInstr(r1)
    //     0xc56470: ldur            x0, [x1, #-1]
    //     0xc56474: ubfx            x0, x0, #0xc, #0x14
    // 0xc56478: r16 = "="
    //     0xc56478: ldr             x16, [PP, #0x2a8]  ; [pp+0x2a8] "="
    // 0xc5647c: stp             x16, x1, [SP, #-0x10]!
    // 0xc56480: r0 = GDT[cid_x0 + -0xff8]()
    //     0xc56480: sub             lr, x0, #0xff8
    //     0xc56484: ldr             lr, [x21, lr, lsl #3]
    //     0xc56488: blr             lr
    // 0xc5648c: add             SP, SP, #0x10
    // 0xc56490: stur            x0, [fp, #-8]
    // 0xc56494: LoadField: r1 = r0->field_b
    //     0xc56494: ldur            w1, [x0, #0xb]
    // 0xc56498: DecompressPointer r1
    //     0xc56498: add             x1, x1, HEAP, lsl #32
    // 0xc5649c: cmp             w1, #4
    // 0xc564a0: b.eq            #0xc564cc
    // 0xc564a4: ldr             x0, [fp, #0x10]
    // 0xc564a8: r1 = <String, String?>
    //     0xc564a8: ldr             x1, [PP, #0x7650]  ; [pp+0x7650] TypeArguments: <String, String?>
    // 0xc564ac: r0 = MapEntry()
    //     0xc564ac: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xc564b0: mov             x1, x0
    // 0xc564b4: ldr             x0, [fp, #0x10]
    // 0xc564b8: StoreField: r1->field_b = r0
    //     0xc564b8: stur            w0, [x1, #0xb]
    // 0xc564bc: mov             x0, x1
    // 0xc564c0: LeaveFrame
    //     0xc564c0: mov             SP, fp
    //     0xc564c4: ldp             fp, lr, [SP], #0x10
    // 0xc564c8: ret
    //     0xc564c8: ret             
    // 0xc564cc: SaveReg r0
    //     0xc564cc: str             x0, [SP, #-8]!
    // 0xc564d0: r0 = first()
    //     0xc564d0: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xc564d4: add             SP, SP, #8
    // 0xc564d8: stur            x0, [fp, #-0x10]
    // 0xc564dc: ldur            x16, [fp, #-8]
    // 0xc564e0: SaveReg r16
    //     0xc564e0: str             x16, [SP, #-8]!
    // 0xc564e4: r0 = last()
    //     0xc564e4: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0xc564e8: add             SP, SP, #8
    // 0xc564ec: SaveReg r0
    //     0xc564ec: str             x0, [SP, #-8]!
    // 0xc564f0: r0 = _Unquote.unquote()
    //     0xc564f0: bl              #0xc56528  ; [package:device_info_plus/src/device_info_plus_linux.dart] ::_Unquote.unquote
    // 0xc564f4: add             SP, SP, #8
    // 0xc564f8: r1 = <String, String?>
    //     0xc564f8: ldr             x1, [PP, #0x7650]  ; [pp+0x7650] TypeArguments: <String, String?>
    // 0xc564fc: stur            x0, [fp, #-8]
    // 0xc56500: r0 = MapEntry()
    //     0xc56500: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xc56504: ldur            x1, [fp, #-0x10]
    // 0xc56508: StoreField: r0->field_b = r1
    //     0xc56508: stur            w1, [x0, #0xb]
    // 0xc5650c: ldur            x1, [fp, #-8]
    // 0xc56510: StoreField: r0->field_f = r1
    //     0xc56510: stur            w1, [x0, #0xf]
    // 0xc56514: LeaveFrame
    //     0xc56514: mov             SP, fp
    //     0xc56518: ldp             fp, lr, [SP], #0x10
    // 0xc5651c: ret
    //     0xc5651c: ret             
    // 0xc56520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc56524: b               #0xc5646c
  }
  static _ _Unquote.unquote(/* No info */) {
    // ** addr: 0xc56528, size: 0x44
    // 0xc56528: EnterFrame
    //     0xc56528: stp             fp, lr, [SP, #-0x10]!
    //     0xc5652c: mov             fp, SP
    // 0xc56530: CheckStackOverflow
    //     0xc56530: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc56534: cmp             SP, x16
    //     0xc56538: b.ls            #0xc56564
    // 0xc5653c: ldr             x16, [fp, #0x10]
    // 0xc56540: SaveReg r16
    //     0xc56540: str             x16, [SP, #-8]!
    // 0xc56544: r0 = _Unquote.removePrefix()
    //     0xc56544: bl              #0xc565e8  ; [package:device_info_plus/src/device_info_plus_linux.dart] ::_Unquote.removePrefix
    // 0xc56548: add             SP, SP, #8
    // 0xc5654c: SaveReg r0
    //     0xc5654c: str             x0, [SP, #-8]!
    // 0xc56550: r0 = _Unquote.removeSuffix()
    //     0xc56550: bl              #0xc5656c  ; [package:device_info_plus/src/device_info_plus_linux.dart] ::_Unquote.removeSuffix
    // 0xc56554: add             SP, SP, #8
    // 0xc56558: LeaveFrame
    //     0xc56558: mov             SP, fp
    //     0xc5655c: ldp             fp, lr, [SP], #0x10
    // 0xc56560: ret
    //     0xc56560: ret             
    // 0xc56564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56564: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc56568: b               #0xc5653c
  }
  static _ _Unquote.removeSuffix(/* No info */) {
    // ** addr: 0xc5656c, size: 0x7c
    // 0xc5656c: EnterFrame
    //     0xc5656c: stp             fp, lr, [SP, #-0x10]!
    //     0xc56570: mov             fp, SP
    // 0xc56574: CheckStackOverflow
    //     0xc56574: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc56578: cmp             SP, x16
    //     0xc5657c: b.ls            #0xc565e0
    // 0xc56580: ldr             x16, [fp, #0x10]
    // 0xc56584: r30 = "\""
    //     0xc56584: ldr             lr, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0xc56588: stp             lr, x16, [SP, #-0x10]!
    // 0xc5658c: r0 = endsWith()
    //     0xc5658c: bl              #0x52b7ec  ; [dart:core] _StringBase::endsWith
    // 0xc56590: add             SP, SP, #0x10
    // 0xc56594: tbz             w0, #4, #0xc565a8
    // 0xc56598: ldr             x0, [fp, #0x10]
    // 0xc5659c: LeaveFrame
    //     0xc5659c: mov             SP, fp
    //     0xc565a0: ldp             fp, lr, [SP], #0x10
    // 0xc565a4: ret
    //     0xc565a4: ret             
    // 0xc565a8: ldr             x0, [fp, #0x10]
    // 0xc565ac: LoadField: r1 = r0->field_7
    //     0xc565ac: ldur            w1, [x0, #7]
    // 0xc565b0: DecompressPointer r1
    //     0xc565b0: add             x1, x1, HEAP, lsl #32
    // 0xc565b4: r2 = LoadInt32Instr(r1)
    //     0xc565b4: sbfx            x2, x1, #1, #0x1f
    // 0xc565b8: sub             x1, x2, #1
    // 0xc565bc: lsl             x2, x1, #1
    // 0xc565c0: stp             xzr, x0, [SP, #-0x10]!
    // 0xc565c4: SaveReg r2
    //     0xc565c4: str             x2, [SP, #-8]!
    // 0xc565c8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xc565c8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xc565cc: r0 = substring()
    //     0xc565cc: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xc565d0: add             SP, SP, #0x18
    // 0xc565d4: LeaveFrame
    //     0xc565d4: mov             SP, fp
    //     0xc565d8: ldp             fp, lr, [SP], #0x10
    // 0xc565dc: ret
    //     0xc565dc: ret             
    // 0xc565e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc565e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc565e4: b               #0xc56580
  }
  static _ _Unquote.removePrefix(/* No info */) {
    // ** addr: 0xc565e8, size: 0x6c
    // 0xc565e8: EnterFrame
    //     0xc565e8: stp             fp, lr, [SP, #-0x10]!
    //     0xc565ec: mov             fp, SP
    // 0xc565f0: CheckStackOverflow
    //     0xc565f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc565f4: cmp             SP, x16
    //     0xc565f8: b.ls            #0xc5664c
    // 0xc565fc: ldr             x16, [fp, #0x10]
    // 0xc56600: r30 = "\""
    //     0xc56600: ldr             lr, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0xc56604: stp             lr, x16, [SP, #-0x10]!
    // 0xc56608: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc56608: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc5660c: r0 = startsWith()
    //     0xc5660c: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0xc56610: add             SP, SP, #0x10
    // 0xc56614: tbz             w0, #4, #0xc56628
    // 0xc56618: ldr             x0, [fp, #0x10]
    // 0xc5661c: LeaveFrame
    //     0xc5661c: mov             SP, fp
    //     0xc56620: ldp             fp, lr, [SP], #0x10
    // 0xc56624: ret
    //     0xc56624: ret             
    // 0xc56628: r0 = 1
    //     0xc56628: mov             x0, #1
    // 0xc5662c: ldr             x16, [fp, #0x10]
    // 0xc56630: stp             x0, x16, [SP, #-0x10]!
    // 0xc56634: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc56634: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc56638: r0 = substring()
    //     0xc56638: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xc5663c: add             SP, SP, #0x10
    // 0xc56640: LeaveFrame
    //     0xc56640: mov             SP, fp
    //     0xc56644: ldp             fp, lr, [SP], #0x10
    // 0xc56648: ret
    //     0xc56648: ret             
    // 0xc5664c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5664c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc56650: b               #0xc565fc
  }
}

// class id: 4950, size: 0x10, field offset: 0x8
class DeviceInfoPlusLinuxPlugin extends DeviceInfoPlatform {

  _ deviceInfo(/* No info */) async {
    // ** addr: 0xc55c2c, size: 0xa4
    // 0xc55c2c: EnterFrame
    //     0xc55c2c: stp             fp, lr, [SP, #-0x10]!
    //     0xc55c30: mov             fp, SP
    // 0xc55c34: AllocStack(0x18)
    //     0xc55c34: sub             SP, SP, #0x18
    // 0xc55c38: SetupParameters(DeviceInfoPlusLinuxPlugin this /* r1, fp-0x10 */)
    //     0xc55c38: stur            NULL, [fp, #-8]
    //     0xc55c3c: mov             x0, #0
    //     0xc55c40: add             x1, fp, w0, sxtw #2
    //     0xc55c44: ldr             x1, [x1, #0x10]
    //     0xc55c48: stur            x1, [fp, #-0x10]
    // 0xc55c4c: CheckStackOverflow
    //     0xc55c4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc55c50: cmp             SP, x16
    //     0xc55c54: b.ls            #0xc55cc8
    // 0xc55c58: InitAsync() -> Future<BaseDeviceInfo>
    //     0xc55c58: add             x0, PP, #0x33, lsl #12  ; [pp+0x33c20] TypeArguments: <BaseDeviceInfo>
    //     0xc55c5c: ldr             x0, [x0, #0xc20]
    //     0xc55c60: bl              #0x4b92e4
    // 0xc55c64: ldur            x0, [fp, #-0x10]
    // 0xc55c68: LoadField: r1 = r0->field_7
    //     0xc55c68: ldur            w1, [x0, #7]
    // 0xc55c6c: DecompressPointer r1
    //     0xc55c6c: add             x1, x1, HEAP, lsl #32
    // 0xc55c70: cmp             w1, NULL
    // 0xc55c74: b.ne            #0xc55cc0
    // 0xc55c78: SaveReg r0
    //     0xc55c78: str             x0, [SP, #-8]!
    // 0xc55c7c: r0 = _getInfo()
    //     0xc55c7c: bl              #0xc55cd0  ; [package:device_info_plus/src/device_info_plus_linux.dart] DeviceInfoPlusLinuxPlugin::_getInfo
    // 0xc55c80: add             SP, SP, #8
    // 0xc55c84: mov             x1, x0
    // 0xc55c88: stur            x1, [fp, #-0x18]
    // 0xc55c8c: r0 = Await()
    //     0xc55c8c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc55c90: mov             x1, x0
    // 0xc55c94: ldur            x2, [fp, #-0x10]
    // 0xc55c98: StoreField: r2->field_7 = r0
    //     0xc55c98: stur            w0, [x2, #7]
    //     0xc55c9c: tbz             w0, #0, #0xc55cb8
    //     0xc55ca0: ldurb           w16, [x2, #-1]
    //     0xc55ca4: ldurb           w17, [x0, #-1]
    //     0xc55ca8: and             x16, x17, x16, lsr #2
    //     0xc55cac: tst             x16, HEAP, lsr #32
    //     0xc55cb0: b.eq            #0xc55cb8
    //     0xc55cb4: bl              #0xd6828c
    // 0xc55cb8: mov             x0, x1
    // 0xc55cbc: b               #0xc55cc4
    // 0xc55cc0: mov             x0, x1
    // 0xc55cc4: r0 = ReturnAsync()
    //     0xc55cc4: b               #0x501858  ; ReturnAsyncStub
    // 0xc55cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc55cc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc55ccc: b               #0xc55c58
  }
  _ _getInfo(/* No info */) async {
    // ** addr: 0xc55cd0, size: 0x4c0
    // 0xc55cd0: EnterFrame
    //     0xc55cd0: stp             fp, lr, [SP, #-0x10]!
    //     0xc55cd4: mov             fp, SP
    // 0xc55cd8: AllocStack(0x60)
    //     0xc55cd8: sub             SP, SP, #0x60
    // 0xc55cdc: SetupParameters(DeviceInfoPlusLinuxPlugin this /* r1, fp-0x10 */)
    //     0xc55cdc: stur            NULL, [fp, #-8]
    //     0xc55ce0: mov             x0, #0
    //     0xc55ce4: add             x1, fp, w0, sxtw #2
    //     0xc55ce8: ldr             x1, [x1, #0x10]
    //     0xc55cec: stur            x1, [fp, #-0x10]
    // 0xc55cf0: CheckStackOverflow
    //     0xc55cf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc55cf4: cmp             SP, x16
    //     0xc55cf8: b.ls            #0xc56188
    // 0xc55cfc: InitAsync() -> Future<LinuxDeviceInfo>
    //     0xc55cfc: add             x0, PP, #0x41, lsl #12  ; [pp+0x41120] TypeArguments: <LinuxDeviceInfo>
    //     0xc55d00: ldr             x0, [x0, #0x120]
    //     0xc55d04: bl              #0x4b92e4
    // 0xc55d08: ldur            x16, [fp, #-0x10]
    // 0xc55d0c: SaveReg r16
    //     0xc55d0c: str             x16, [SP, #-8]!
    // 0xc55d10: r0 = _getOsRelease()
    //     0xc55d10: bl              #0xc56654  ; [package:device_info_plus/src/device_info_plus_linux.dart] DeviceInfoPlusLinuxPlugin::_getOsRelease
    // 0xc55d14: add             SP, SP, #8
    // 0xc55d18: mov             x1, x0
    // 0xc55d1c: stur            x1, [fp, #-0x18]
    // 0xc55d20: r0 = Await()
    //     0xc55d20: bl              #0x4b8e6c  ; AwaitStub
    // 0xc55d24: cmp             w0, NULL
    // 0xc55d28: b.ne            #0xc55d40
    // 0xc55d2c: r16 = <String, String?>
    //     0xc55d2c: ldr             x16, [PP, #0x7650]  ; [pp+0x7650] TypeArguments: <String, String?>
    // 0xc55d30: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xc55d34: stp             lr, x16, [SP, #-0x10]!
    // 0xc55d38: r0 = Map._fromLiteral()
    //     0xc55d38: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc55d3c: add             SP, SP, #0x10
    // 0xc55d40: stur            x0, [fp, #-0x18]
    // 0xc55d44: ldur            x16, [fp, #-0x10]
    // 0xc55d48: SaveReg r16
    //     0xc55d48: str             x16, [SP, #-8]!
    // 0xc55d4c: r0 = _getLsbRelease()
    //     0xc55d4c: bl              #0xc5624c  ; [package:device_info_plus/src/device_info_plus_linux.dart] DeviceInfoPlusLinuxPlugin::_getLsbRelease
    // 0xc55d50: add             SP, SP, #8
    // 0xc55d54: mov             x1, x0
    // 0xc55d58: stur            x1, [fp, #-0x20]
    // 0xc55d5c: r0 = Await()
    //     0xc55d5c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc55d60: cmp             w0, NULL
    // 0xc55d64: b.ne            #0xc55d84
    // 0xc55d68: r16 = <String, String?>
    //     0xc55d68: ldr             x16, [PP, #0x7650]  ; [pp+0x7650] TypeArguments: <String, String?>
    // 0xc55d6c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xc55d70: stp             lr, x16, [SP, #-0x10]!
    // 0xc55d74: r0 = Map._fromLiteral()
    //     0xc55d74: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc55d78: add             SP, SP, #0x10
    // 0xc55d7c: mov             x1, x0
    // 0xc55d80: b               #0xc55d88
    // 0xc55d84: mov             x1, x0
    // 0xc55d88: ldur            x0, [fp, #-0x18]
    // 0xc55d8c: stur            x1, [fp, #-0x20]
    // 0xc55d90: ldur            x16, [fp, #-0x10]
    // 0xc55d94: SaveReg r16
    //     0xc55d94: str             x16, [SP, #-8]!
    // 0xc55d98: r0 = _tryReadValue()
    //     0xc55d98: bl              #0xc5619c  ; [package:device_info_plus/src/device_info_plus_linux.dart] DeviceInfoPlusLinuxPlugin::_tryReadValue
    // 0xc55d9c: add             SP, SP, #8
    // 0xc55da0: mov             x1, x0
    // 0xc55da4: stur            x1, [fp, #-0x10]
    // 0xc55da8: r0 = Await()
    //     0xc55da8: bl              #0x4b8e6c  ; AwaitStub
    // 0xc55dac: mov             x2, x0
    // 0xc55db0: ldur            x1, [fp, #-0x18]
    // 0xc55db4: stur            x2, [fp, #-0x10]
    // 0xc55db8: r0 = LoadClassIdInstr(r1)
    //     0xc55db8: ldur            x0, [x1, #-1]
    //     0xc55dbc: ubfx            x0, x0, #0xc, #0x14
    // 0xc55dc0: r16 = "NAME"
    //     0xc55dc0: add             x16, PP, #0x41, lsl #12  ; [pp+0x41128] "NAME"
    //     0xc55dc4: ldr             x16, [x16, #0x128]
    // 0xc55dc8: stp             x16, x1, [SP, #-0x10]!
    // 0xc55dcc: r0 = GDT[cid_x0 + -0xef]()
    //     0xc55dcc: sub             lr, x0, #0xef
    //     0xc55dd0: ldr             lr, [x21, lr, lsl #3]
    //     0xc55dd4: blr             lr
    // 0xc55dd8: add             SP, SP, #0x10
    // 0xc55ddc: cmp             w0, NULL
    // 0xc55de0: b.ne            #0xc55df0
    // 0xc55de4: r2 = "Linux"
    //     0xc55de4: add             x2, PP, #0x41, lsl #12  ; [pp+0x41130] "Linux"
    //     0xc55de8: ldr             x2, [x2, #0x130]
    // 0xc55dec: b               #0xc55df4
    // 0xc55df0: mov             x2, x0
    // 0xc55df4: ldur            x1, [fp, #-0x18]
    // 0xc55df8: stur            x2, [fp, #-0x28]
    // 0xc55dfc: r0 = LoadClassIdInstr(r1)
    //     0xc55dfc: ldur            x0, [x1, #-1]
    //     0xc55e00: ubfx            x0, x0, #0xc, #0x14
    // 0xc55e04: r16 = "VERSION"
    //     0xc55e04: add             x16, PP, #0x41, lsl #12  ; [pp+0x41138] "VERSION"
    //     0xc55e08: ldr             x16, [x16, #0x138]
    // 0xc55e0c: stp             x16, x1, [SP, #-0x10]!
    // 0xc55e10: r0 = GDT[cid_x0 + -0xef]()
    //     0xc55e10: sub             lr, x0, #0xef
    //     0xc55e14: ldr             lr, [x21, lr, lsl #3]
    //     0xc55e18: blr             lr
    // 0xc55e1c: add             SP, SP, #0x10
    // 0xc55e20: cmp             w0, NULL
    // 0xc55e24: b.ne            #0xc55e58
    // 0xc55e28: ldur            x1, [fp, #-0x20]
    // 0xc55e2c: r0 = LoadClassIdInstr(r1)
    //     0xc55e2c: ldur            x0, [x1, #-1]
    //     0xc55e30: ubfx            x0, x0, #0xc, #0x14
    // 0xc55e34: r16 = "LSB_VERSION"
    //     0xc55e34: add             x16, PP, #0x41, lsl #12  ; [pp+0x41140] "LSB_VERSION"
    //     0xc55e38: ldr             x16, [x16, #0x140]
    // 0xc55e3c: stp             x16, x1, [SP, #-0x10]!
    // 0xc55e40: r0 = GDT[cid_x0 + -0xef]()
    //     0xc55e40: sub             lr, x0, #0xef
    //     0xc55e44: ldr             lr, [x21, lr, lsl #3]
    //     0xc55e48: blr             lr
    // 0xc55e4c: add             SP, SP, #0x10
    // 0xc55e50: mov             x2, x0
    // 0xc55e54: b               #0xc55e5c
    // 0xc55e58: mov             x2, x0
    // 0xc55e5c: ldur            x1, [fp, #-0x18]
    // 0xc55e60: stur            x2, [fp, #-0x30]
    // 0xc55e64: r0 = LoadClassIdInstr(r1)
    //     0xc55e64: ldur            x0, [x1, #-1]
    //     0xc55e68: ubfx            x0, x0, #0xc, #0x14
    // 0xc55e6c: r16 = "ID"
    //     0xc55e6c: add             x16, PP, #0x41, lsl #12  ; [pp+0x41148] "ID"
    //     0xc55e70: ldr             x16, [x16, #0x148]
    // 0xc55e74: stp             x16, x1, [SP, #-0x10]!
    // 0xc55e78: r0 = GDT[cid_x0 + -0xef]()
    //     0xc55e78: sub             lr, x0, #0xef
    //     0xc55e7c: ldr             lr, [x21, lr, lsl #3]
    //     0xc55e80: blr             lr
    // 0xc55e84: add             SP, SP, #0x10
    // 0xc55e88: cmp             w0, NULL
    // 0xc55e8c: b.ne            #0xc55eb8
    // 0xc55e90: ldur            x1, [fp, #-0x20]
    // 0xc55e94: r0 = LoadClassIdInstr(r1)
    //     0xc55e94: ldur            x0, [x1, #-1]
    //     0xc55e98: ubfx            x0, x0, #0xc, #0x14
    // 0xc55e9c: r16 = "DISTRIB_ID"
    //     0xc55e9c: add             x16, PP, #0x41, lsl #12  ; [pp+0x41150] "DISTRIB_ID"
    //     0xc55ea0: ldr             x16, [x16, #0x150]
    // 0xc55ea4: stp             x16, x1, [SP, #-0x10]!
    // 0xc55ea8: r0 = GDT[cid_x0 + -0xef]()
    //     0xc55ea8: sub             lr, x0, #0xef
    //     0xc55eac: ldr             lr, [x21, lr, lsl #3]
    //     0xc55eb0: blr             lr
    // 0xc55eb4: add             SP, SP, #0x10
    // 0xc55eb8: cmp             w0, NULL
    // 0xc55ebc: b.ne            #0xc55ec8
    // 0xc55ec0: r2 = "linux"
    //     0xc55ec0: ldr             x2, [PP, #0x1d20]  ; [pp+0x1d20] "linux"
    // 0xc55ec4: b               #0xc55ecc
    // 0xc55ec8: mov             x2, x0
    // 0xc55ecc: ldur            x1, [fp, #-0x18]
    // 0xc55ed0: stur            x2, [fp, #-0x38]
    // 0xc55ed4: r0 = LoadClassIdInstr(r1)
    //     0xc55ed4: ldur            x0, [x1, #-1]
    //     0xc55ed8: ubfx            x0, x0, #0xc, #0x14
    // 0xc55edc: r16 = "ID_LIKE"
    //     0xc55edc: add             x16, PP, #0x41, lsl #12  ; [pp+0x41158] "ID_LIKE"
    //     0xc55ee0: ldr             x16, [x16, #0x158]
    // 0xc55ee4: stp             x16, x1, [SP, #-0x10]!
    // 0xc55ee8: r0 = GDT[cid_x0 + -0xef]()
    //     0xc55ee8: sub             lr, x0, #0xef
    //     0xc55eec: ldr             lr, [x21, lr, lsl #3]
    //     0xc55ef0: blr             lr
    // 0xc55ef4: add             SP, SP, #0x10
    // 0xc55ef8: cmp             w0, NULL
    // 0xc55efc: b.ne            #0xc55f08
    // 0xc55f00: r2 = Null
    //     0xc55f00: mov             x2, NULL
    // 0xc55f04: b               #0xc55f30
    // 0xc55f08: r1 = LoadClassIdInstr(r0)
    //     0xc55f08: ldur            x1, [x0, #-1]
    //     0xc55f0c: ubfx            x1, x1, #0xc, #0x14
    // 0xc55f10: r16 = " "
    //     0xc55f10: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xc55f14: stp             x16, x0, [SP, #-0x10]!
    // 0xc55f18: mov             x0, x1
    // 0xc55f1c: r0 = GDT[cid_x0 + -0xff8]()
    //     0xc55f1c: sub             lr, x0, #0xff8
    //     0xc55f20: ldr             lr, [x21, lr, lsl #3]
    //     0xc55f24: blr             lr
    // 0xc55f28: add             SP, SP, #0x10
    // 0xc55f2c: mov             x2, x0
    // 0xc55f30: ldur            x1, [fp, #-0x18]
    // 0xc55f34: stur            x2, [fp, #-0x40]
    // 0xc55f38: r0 = LoadClassIdInstr(r1)
    //     0xc55f38: ldur            x0, [x1, #-1]
    //     0xc55f3c: ubfx            x0, x0, #0xc, #0x14
    // 0xc55f40: r16 = "VERSION_CODENAME"
    //     0xc55f40: add             x16, PP, #0x41, lsl #12  ; [pp+0x41160] "VERSION_CODENAME"
    //     0xc55f44: ldr             x16, [x16, #0x160]
    // 0xc55f48: stp             x16, x1, [SP, #-0x10]!
    // 0xc55f4c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc55f4c: sub             lr, x0, #0xef
    //     0xc55f50: ldr             lr, [x21, lr, lsl #3]
    //     0xc55f54: blr             lr
    // 0xc55f58: add             SP, SP, #0x10
    // 0xc55f5c: cmp             w0, NULL
    // 0xc55f60: b.ne            #0xc55f94
    // 0xc55f64: ldur            x1, [fp, #-0x20]
    // 0xc55f68: r0 = LoadClassIdInstr(r1)
    //     0xc55f68: ldur            x0, [x1, #-1]
    //     0xc55f6c: ubfx            x0, x0, #0xc, #0x14
    // 0xc55f70: r16 = "DISTRIB_CODENAME"
    //     0xc55f70: add             x16, PP, #0x41, lsl #12  ; [pp+0x41168] "DISTRIB_CODENAME"
    //     0xc55f74: ldr             x16, [x16, #0x168]
    // 0xc55f78: stp             x16, x1, [SP, #-0x10]!
    // 0xc55f7c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc55f7c: sub             lr, x0, #0xef
    //     0xc55f80: ldr             lr, [x21, lr, lsl #3]
    //     0xc55f84: blr             lr
    // 0xc55f88: add             SP, SP, #0x10
    // 0xc55f8c: mov             x2, x0
    // 0xc55f90: b               #0xc55f98
    // 0xc55f94: mov             x2, x0
    // 0xc55f98: ldur            x1, [fp, #-0x18]
    // 0xc55f9c: stur            x2, [fp, #-0x48]
    // 0xc55fa0: r0 = LoadClassIdInstr(r1)
    //     0xc55fa0: ldur            x0, [x1, #-1]
    //     0xc55fa4: ubfx            x0, x0, #0xc, #0x14
    // 0xc55fa8: r16 = "VERSION_ID"
    //     0xc55fa8: add             x16, PP, #0x41, lsl #12  ; [pp+0x41170] "VERSION_ID"
    //     0xc55fac: ldr             x16, [x16, #0x170]
    // 0xc55fb0: stp             x16, x1, [SP, #-0x10]!
    // 0xc55fb4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc55fb4: sub             lr, x0, #0xef
    //     0xc55fb8: ldr             lr, [x21, lr, lsl #3]
    //     0xc55fbc: blr             lr
    // 0xc55fc0: add             SP, SP, #0x10
    // 0xc55fc4: cmp             w0, NULL
    // 0xc55fc8: b.ne            #0xc55ffc
    // 0xc55fcc: ldur            x1, [fp, #-0x20]
    // 0xc55fd0: r0 = LoadClassIdInstr(r1)
    //     0xc55fd0: ldur            x0, [x1, #-1]
    //     0xc55fd4: ubfx            x0, x0, #0xc, #0x14
    // 0xc55fd8: r16 = "DISTRIB_RELEASE"
    //     0xc55fd8: add             x16, PP, #0x41, lsl #12  ; [pp+0x41178] "DISTRIB_RELEASE"
    //     0xc55fdc: ldr             x16, [x16, #0x178]
    // 0xc55fe0: stp             x16, x1, [SP, #-0x10]!
    // 0xc55fe4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc55fe4: sub             lr, x0, #0xef
    //     0xc55fe8: ldr             lr, [x21, lr, lsl #3]
    //     0xc55fec: blr             lr
    // 0xc55ff0: add             SP, SP, #0x10
    // 0xc55ff4: mov             x2, x0
    // 0xc55ff8: b               #0xc56000
    // 0xc55ffc: mov             x2, x0
    // 0xc56000: ldur            x1, [fp, #-0x18]
    // 0xc56004: stur            x2, [fp, #-0x50]
    // 0xc56008: r0 = LoadClassIdInstr(r1)
    //     0xc56008: ldur            x0, [x1, #-1]
    //     0xc5600c: ubfx            x0, x0, #0xc, #0x14
    // 0xc56010: r16 = "PRETTY_NAME"
    //     0xc56010: add             x16, PP, #0x41, lsl #12  ; [pp+0x41180] "PRETTY_NAME"
    //     0xc56014: ldr             x16, [x16, #0x180]
    // 0xc56018: stp             x16, x1, [SP, #-0x10]!
    // 0xc5601c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc5601c: sub             lr, x0, #0xef
    //     0xc56020: ldr             lr, [x21, lr, lsl #3]
    //     0xc56024: blr             lr
    // 0xc56028: add             SP, SP, #0x10
    // 0xc5602c: cmp             w0, NULL
    // 0xc56030: b.ne            #0xc56060
    // 0xc56034: ldur            x0, [fp, #-0x20]
    // 0xc56038: r1 = LoadClassIdInstr(r0)
    //     0xc56038: ldur            x1, [x0, #-1]
    //     0xc5603c: ubfx            x1, x1, #0xc, #0x14
    // 0xc56040: r16 = "DISTRIB_DESCRIPTION"
    //     0xc56040: add             x16, PP, #0x41, lsl #12  ; [pp+0x41188] "DISTRIB_DESCRIPTION"
    //     0xc56044: ldr             x16, [x16, #0x188]
    // 0xc56048: stp             x16, x0, [SP, #-0x10]!
    // 0xc5604c: mov             x0, x1
    // 0xc56050: r0 = GDT[cid_x0 + -0xef]()
    //     0xc56050: sub             lr, x0, #0xef
    //     0xc56054: ldr             lr, [x21, lr, lsl #3]
    //     0xc56058: blr             lr
    // 0xc5605c: add             SP, SP, #0x10
    // 0xc56060: cmp             w0, NULL
    // 0xc56064: b.ne            #0xc56074
    // 0xc56068: r9 = "Linux"
    //     0xc56068: add             x9, PP, #0x41, lsl #12  ; [pp+0x41130] "Linux"
    //     0xc5606c: ldr             x9, [x9, #0x130]
    // 0xc56070: b               #0xc56078
    // 0xc56074: mov             x9, x0
    // 0xc56078: ldur            x1, [fp, #-0x18]
    // 0xc5607c: ldur            x8, [fp, #-0x10]
    // 0xc56080: ldur            x7, [fp, #-0x28]
    // 0xc56084: ldur            x6, [fp, #-0x30]
    // 0xc56088: ldur            x5, [fp, #-0x38]
    // 0xc5608c: ldur            x4, [fp, #-0x40]
    // 0xc56090: ldur            x3, [fp, #-0x48]
    // 0xc56094: ldur            x2, [fp, #-0x50]
    // 0xc56098: stur            x9, [fp, #-0x20]
    // 0xc5609c: r0 = LoadClassIdInstr(r1)
    //     0xc5609c: ldur            x0, [x1, #-1]
    //     0xc560a0: ubfx            x0, x0, #0xc, #0x14
    // 0xc560a4: r16 = "BUILD_ID"
    //     0xc560a4: add             x16, PP, #0x41, lsl #12  ; [pp+0x41190] "BUILD_ID"
    //     0xc560a8: ldr             x16, [x16, #0x190]
    // 0xc560ac: stp             x16, x1, [SP, #-0x10]!
    // 0xc560b0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc560b0: sub             lr, x0, #0xef
    //     0xc560b4: ldr             lr, [x21, lr, lsl #3]
    //     0xc560b8: blr             lr
    // 0xc560bc: add             SP, SP, #0x10
    // 0xc560c0: mov             x2, x0
    // 0xc560c4: ldur            x1, [fp, #-0x18]
    // 0xc560c8: stur            x2, [fp, #-0x58]
    // 0xc560cc: r0 = LoadClassIdInstr(r1)
    //     0xc560cc: ldur            x0, [x1, #-1]
    //     0xc560d0: ubfx            x0, x0, #0xc, #0x14
    // 0xc560d4: r16 = "VARIANT"
    //     0xc560d4: add             x16, PP, #0x41, lsl #12  ; [pp+0x41198] "VARIANT"
    //     0xc560d8: ldr             x16, [x16, #0x198]
    // 0xc560dc: stp             x16, x1, [SP, #-0x10]!
    // 0xc560e0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc560e0: sub             lr, x0, #0xef
    //     0xc560e4: ldr             lr, [x21, lr, lsl #3]
    //     0xc560e8: blr             lr
    // 0xc560ec: add             SP, SP, #0x10
    // 0xc560f0: mov             x1, x0
    // 0xc560f4: ldur            x0, [fp, #-0x18]
    // 0xc560f8: stur            x1, [fp, #-0x60]
    // 0xc560fc: r2 = LoadClassIdInstr(r0)
    //     0xc560fc: ldur            x2, [x0, #-1]
    //     0xc56100: ubfx            x2, x2, #0xc, #0x14
    // 0xc56104: r16 = "VARIANT_ID"
    //     0xc56104: add             x16, PP, #0x41, lsl #12  ; [pp+0x411a0] "VARIANT_ID"
    //     0xc56108: ldr             x16, [x16, #0x1a0]
    // 0xc5610c: stp             x16, x0, [SP, #-0x10]!
    // 0xc56110: mov             x0, x2
    // 0xc56114: r0 = GDT[cid_x0 + -0xef]()
    //     0xc56114: sub             lr, x0, #0xef
    //     0xc56118: ldr             lr, [x21, lr, lsl #3]
    //     0xc5611c: blr             lr
    // 0xc56120: add             SP, SP, #0x10
    // 0xc56124: stur            x0, [fp, #-0x18]
    // 0xc56128: r0 = LinuxDeviceInfo()
    //     0xc56128: bl              #0xc56190  ; AllocateLinuxDeviceInfoStub -> LinuxDeviceInfo (size=0x34)
    // 0xc5612c: ldur            x1, [fp, #-0x28]
    // 0xc56130: StoreField: r0->field_7 = r1
    //     0xc56130: stur            w1, [x0, #7]
    // 0xc56134: ldur            x1, [fp, #-0x30]
    // 0xc56138: StoreField: r0->field_b = r1
    //     0xc56138: stur            w1, [x0, #0xb]
    // 0xc5613c: ldur            x1, [fp, #-0x38]
    // 0xc56140: StoreField: r0->field_f = r1
    //     0xc56140: stur            w1, [x0, #0xf]
    // 0xc56144: ldur            x1, [fp, #-0x40]
    // 0xc56148: StoreField: r0->field_13 = r1
    //     0xc56148: stur            w1, [x0, #0x13]
    // 0xc5614c: ldur            x1, [fp, #-0x48]
    // 0xc56150: StoreField: r0->field_17 = r1
    //     0xc56150: stur            w1, [x0, #0x17]
    // 0xc56154: ldur            x1, [fp, #-0x50]
    // 0xc56158: StoreField: r0->field_1b = r1
    //     0xc56158: stur            w1, [x0, #0x1b]
    // 0xc5615c: ldur            x1, [fp, #-0x20]
    // 0xc56160: StoreField: r0->field_1f = r1
    //     0xc56160: stur            w1, [x0, #0x1f]
    // 0xc56164: ldur            x1, [fp, #-0x58]
    // 0xc56168: StoreField: r0->field_23 = r1
    //     0xc56168: stur            w1, [x0, #0x23]
    // 0xc5616c: ldur            x1, [fp, #-0x60]
    // 0xc56170: StoreField: r0->field_27 = r1
    //     0xc56170: stur            w1, [x0, #0x27]
    // 0xc56174: ldur            x1, [fp, #-0x18]
    // 0xc56178: StoreField: r0->field_2b = r1
    //     0xc56178: stur            w1, [x0, #0x2b]
    // 0xc5617c: ldur            x1, [fp, #-0x10]
    // 0xc56180: StoreField: r0->field_2f = r1
    //     0xc56180: stur            w1, [x0, #0x2f]
    // 0xc56184: r0 = ReturnAsyncNotFuture()
    //     0xc56184: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc56188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56188: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5618c: b               #0xc55cfc
  }
  _ _tryReadValue(/* No info */) {
    // ** addr: 0xc5619c, size: 0xb0
    // 0xc5619c: EnterFrame
    //     0xc5619c: stp             fp, lr, [SP, #-0x10]!
    //     0xc561a0: mov             fp, SP
    // 0xc561a4: AllocStack(0x10)
    //     0xc561a4: sub             SP, SP, #0x10
    // 0xc561a8: CheckStackOverflow
    //     0xc561a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc561ac: cmp             SP, x16
    //     0xc561b0: b.ls            #0xc56244
    // 0xc561b4: r16 = Instance_LocalFileSystem
    //     0xc561b4: ldr             x16, [PP, #0x218]  ; [pp+0x218] Obj!LocalFileSystem@b4fce1
    // 0xc561b8: r30 = "/etc/machine-id"
    //     0xc561b8: ldr             lr, [PP, #0x7f38]  ; [pp+0x7f38] "/etc/machine-id"
    // 0xc561bc: stp             lr, x16, [SP, #-0x10]!
    // 0xc561c0: r0 = file()
    //     0xc561c0: bl              #0xc188f4  ; [package:file/src/backends/local/local_file_system.dart] LocalFileSystem::file
    // 0xc561c4: add             SP, SP, #0x10
    // 0xc561c8: SaveReg r0
    //     0xc561c8: str             x0, [SP, #-8]!
    // 0xc561cc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc561cc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc561d0: r0 = readAsString()
    //     0xc561d0: bl              #0xcb2c30  ; [package:file/src/backends/local/local_file.dart] _LocalFile&LocalFileSystemEntity&ForwardingFile::readAsString
    // 0xc561d4: add             SP, SP, #8
    // 0xc561d8: r1 = Function '<anonymous closure>':.
    //     0xc561d8: add             x1, PP, #0x41, lsl #12  ; [pp+0x411a8] AnonymousClosure: static (0x55640c), in [dart:_http] _HttpClient::_findProxyFromEnvironment (0x555484)
    //     0xc561dc: ldr             x1, [x1, #0x1a8]
    // 0xc561e0: r2 = Null
    //     0xc561e0: mov             x2, NULL
    // 0xc561e4: stur            x0, [fp, #-8]
    // 0xc561e8: r0 = AllocateClosure()
    //     0xc561e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc561ec: r1 = Function '<anonymous closure>':.
    //     0xc561ec: add             x1, PP, #0x41, lsl #12  ; [pp+0x411b0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xc561f0: ldr             x1, [x1, #0x1b0]
    // 0xc561f4: r2 = Null
    //     0xc561f4: mov             x2, NULL
    // 0xc561f8: stur            x0, [fp, #-0x10]
    // 0xc561fc: r0 = AllocateClosure()
    //     0xc561fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc56200: mov             x1, x0
    // 0xc56204: ldur            x0, [fp, #-8]
    // 0xc56208: r2 = LoadClassIdInstr(r0)
    //     0xc56208: ldur            x2, [x0, #-1]
    //     0xc5620c: ubfx            x2, x2, #0xc, #0x14
    // 0xc56210: r16 = <String?>
    //     0xc56210: ldr             x16, [PP, #0x1020]  ; [pp+0x1020] TypeArguments: <String?>
    // 0xc56214: stp             x0, x16, [SP, #-0x10]!
    // 0xc56218: ldur            x16, [fp, #-0x10]
    // 0xc5621c: stp             x1, x16, [SP, #-0x10]!
    // 0xc56220: mov             x0, x2
    // 0xc56224: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0xc56224: ldr             x4, [PP, #0x1a30]  ; [pp+0x1a30] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0xc56228: r0 = GDT[cid_x0 + -0xffe]()
    //     0xc56228: sub             lr, x0, #0xffe
    //     0xc5622c: ldr             lr, [x21, lr, lsl #3]
    //     0xc56230: blr             lr
    // 0xc56234: add             SP, SP, #0x20
    // 0xc56238: LeaveFrame
    //     0xc56238: mov             SP, fp
    //     0xc5623c: ldp             fp, lr, [SP], #0x10
    // 0xc56240: ret
    //     0xc56240: ret             
    // 0xc56244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56244: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc56248: b               #0xc561b4
  }
  _ _getLsbRelease(/* No info */) {
    // ** addr: 0xc5624c, size: 0x40
    // 0xc5624c: EnterFrame
    //     0xc5624c: stp             fp, lr, [SP, #-0x10]!
    //     0xc56250: mov             fp, SP
    // 0xc56254: CheckStackOverflow
    //     0xc56254: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc56258: cmp             SP, x16
    //     0xc5625c: b.ls            #0xc56284
    // 0xc56260: ldr             x16, [fp, #0x10]
    // 0xc56264: r30 = "/etc/lsb-release"
    //     0xc56264: add             lr, PP, #0x41, lsl #12  ; [pp+0x411b8] "/etc/lsb-release"
    //     0xc56268: ldr             lr, [lr, #0x1b8]
    // 0xc5626c: stp             lr, x16, [SP, #-0x10]!
    // 0xc56270: r0 = _tryReadKeyValues()
    //     0xc56270: bl              #0xc5628c  ; [package:device_info_plus/src/device_info_plus_linux.dart] DeviceInfoPlusLinuxPlugin::_tryReadKeyValues
    // 0xc56274: add             SP, SP, #0x10
    // 0xc56278: LeaveFrame
    //     0xc56278: mov             SP, fp
    //     0xc5627c: ldp             fp, lr, [SP], #0x10
    // 0xc56280: ret
    //     0xc56280: ret             
    // 0xc56284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56284: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc56288: b               #0xc56260
  }
  _ _tryReadKeyValues(/* No info */) {
    // ** addr: 0xc5628c, size: 0xb4
    // 0xc5628c: EnterFrame
    //     0xc5628c: stp             fp, lr, [SP, #-0x10]!
    //     0xc56290: mov             fp, SP
    // 0xc56294: AllocStack(0x10)
    //     0xc56294: sub             SP, SP, #0x10
    // 0xc56298: CheckStackOverflow
    //     0xc56298: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5629c: cmp             SP, x16
    //     0xc562a0: b.ls            #0xc56338
    // 0xc562a4: r16 = Instance_LocalFileSystem
    //     0xc562a4: ldr             x16, [PP, #0x218]  ; [pp+0x218] Obj!LocalFileSystem@b4fce1
    // 0xc562a8: ldr             lr, [fp, #0x10]
    // 0xc562ac: stp             lr, x16, [SP, #-0x10]!
    // 0xc562b0: r0 = file()
    //     0xc562b0: bl              #0xc188f4  ; [package:file/src/backends/local/local_file_system.dart] LocalFileSystem::file
    // 0xc562b4: add             SP, SP, #0x10
    // 0xc562b8: SaveReg r0
    //     0xc562b8: str             x0, [SP, #-8]!
    // 0xc562bc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc562bc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc562c0: r0 = readAsLines()
    //     0xc562c0: bl              #0xcb29f0  ; [package:file/src/backends/local/local_file.dart] _LocalFile&LocalFileSystemEntity&ForwardingFile::readAsLines
    // 0xc562c4: add             SP, SP, #8
    // 0xc562c8: r1 = Function '<anonymous closure>':.
    //     0xc562c8: add             x1, PP, #0x41, lsl #12  ; [pp+0x411c0] AnonymousClosure: (0xc56340), in [package:device_info_plus/src/device_info_plus_linux.dart] DeviceInfoPlusLinuxPlugin::_tryReadKeyValues (0xc5628c)
    //     0xc562cc: ldr             x1, [x1, #0x1c0]
    // 0xc562d0: r2 = Null
    //     0xc562d0: mov             x2, NULL
    // 0xc562d4: stur            x0, [fp, #-8]
    // 0xc562d8: r0 = AllocateClosure()
    //     0xc562d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc562dc: r1 = Function '<anonymous closure>':.
    //     0xc562dc: add             x1, PP, #0x41, lsl #12  ; [pp+0x411c8] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xc562e0: ldr             x1, [x1, #0x1c8]
    // 0xc562e4: r2 = Null
    //     0xc562e4: mov             x2, NULL
    // 0xc562e8: stur            x0, [fp, #-0x10]
    // 0xc562ec: r0 = AllocateClosure()
    //     0xc562ec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc562f0: mov             x1, x0
    // 0xc562f4: ldur            x0, [fp, #-8]
    // 0xc562f8: r2 = LoadClassIdInstr(r0)
    //     0xc562f8: ldur            x2, [x0, #-1]
    //     0xc562fc: ubfx            x2, x2, #0xc, #0x14
    // 0xc56300: r16 = <Map<String, String?>?>
    //     0xc56300: add             x16, PP, #0x41, lsl #12  ; [pp+0x411d0] TypeArguments: <Map<String, String?>?>
    //     0xc56304: ldr             x16, [x16, #0x1d0]
    // 0xc56308: stp             x0, x16, [SP, #-0x10]!
    // 0xc5630c: ldur            x16, [fp, #-0x10]
    // 0xc56310: stp             x1, x16, [SP, #-0x10]!
    // 0xc56314: mov             x0, x2
    // 0xc56318: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0xc56318: ldr             x4, [PP, #0x1a30]  ; [pp+0x1a30] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0xc5631c: r0 = GDT[cid_x0 + -0xffe]()
    //     0xc5631c: sub             lr, x0, #0xffe
    //     0xc56320: ldr             lr, [x21, lr, lsl #3]
    //     0xc56324: blr             lr
    // 0xc56328: add             SP, SP, #0x20
    // 0xc5632c: LeaveFrame
    //     0xc5632c: mov             SP, fp
    //     0xc56330: ldp             fp, lr, [SP], #0x10
    // 0xc56334: ret
    //     0xc56334: ret             
    // 0xc56338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56338: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5633c: b               #0xc562a4
  }
  [closure] Map<String, String?> <anonymous closure>(dynamic, List<String>) {
    // ** addr: 0xc56340, size: 0x38
    // 0xc56340: EnterFrame
    //     0xc56340: stp             fp, lr, [SP, #-0x10]!
    //     0xc56344: mov             fp, SP
    // 0xc56348: CheckStackOverflow
    //     0xc56348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5634c: cmp             SP, x16
    //     0xc56350: b.ls            #0xc56370
    // 0xc56354: ldr             x16, [fp, #0x10]
    // 0xc56358: SaveReg r16
    //     0xc56358: str             x16, [SP, #-8]!
    // 0xc5635c: r0 = _KeyValues.toKeyValues()
    //     0xc5635c: bl              #0xc56378  ; [package:device_info_plus/src/device_info_plus_linux.dart] ::_KeyValues.toKeyValues
    // 0xc56360: add             SP, SP, #8
    // 0xc56364: LeaveFrame
    //     0xc56364: mov             SP, fp
    //     0xc56368: ldp             fp, lr, [SP], #0x10
    // 0xc5636c: ret
    //     0xc5636c: ret             
    // 0xc56370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56370: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc56374: b               #0xc56354
  }
  _ _getOsRelease(/* No info */) {
    // ** addr: 0xc56654, size: 0xa4
    // 0xc56654: EnterFrame
    //     0xc56654: stp             fp, lr, [SP, #-0x10]!
    //     0xc56658: mov             fp, SP
    // 0xc5665c: AllocStack(0x8)
    //     0xc5665c: sub             SP, SP, #8
    // 0xc56660: CheckStackOverflow
    //     0xc56660: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc56664: cmp             SP, x16
    //     0xc56668: b.ls            #0xc566f0
    // 0xc5666c: r1 = 1
    //     0xc5666c: mov             x1, #1
    // 0xc56670: r0 = AllocateContext()
    //     0xc56670: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc56674: mov             x1, x0
    // 0xc56678: ldr             x0, [fp, #0x10]
    // 0xc5667c: stur            x1, [fp, #-8]
    // 0xc56680: StoreField: r1->field_f = r0
    //     0xc56680: stur            w0, [x1, #0xf]
    // 0xc56684: r16 = "/etc/os-release"
    //     0xc56684: add             x16, PP, #0x41, lsl #12  ; [pp+0x411e8] "/etc/os-release"
    //     0xc56688: ldr             x16, [x16, #0x1e8]
    // 0xc5668c: stp             x16, x0, [SP, #-0x10]!
    // 0xc56690: r0 = _tryReadKeyValues()
    //     0xc56690: bl              #0xc5628c  ; [package:device_info_plus/src/device_info_plus_linux.dart] DeviceInfoPlusLinuxPlugin::_tryReadKeyValues
    // 0xc56694: add             SP, SP, #0x10
    // 0xc56698: ldur            x2, [fp, #-8]
    // 0xc5669c: r1 = Function '<anonymous closure>':.
    //     0xc5669c: add             x1, PP, #0x41, lsl #12  ; [pp+0x411f0] AnonymousClosure: (0xc566f8), in [package:device_info_plus/src/device_info_plus_linux.dart] DeviceInfoPlusLinuxPlugin::_getOsRelease (0xc56654)
    //     0xc566a0: ldr             x1, [x1, #0x1f0]
    // 0xc566a4: stur            x0, [fp, #-8]
    // 0xc566a8: r0 = AllocateClosure()
    //     0xc566a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc566ac: mov             x1, x0
    // 0xc566b0: ldur            x0, [fp, #-8]
    // 0xc566b4: r2 = LoadClassIdInstr(r0)
    //     0xc566b4: ldur            x2, [x0, #-1]
    //     0xc566b8: ubfx            x2, x2, #0xc, #0x14
    // 0xc566bc: r16 = <Map<String, String?>?>
    //     0xc566bc: add             x16, PP, #0x41, lsl #12  ; [pp+0x411d0] TypeArguments: <Map<String, String?>?>
    //     0xc566c0: ldr             x16, [x16, #0x1d0]
    // 0xc566c4: stp             x0, x16, [SP, #-0x10]!
    // 0xc566c8: SaveReg r1
    //     0xc566c8: str             x1, [SP, #-8]!
    // 0xc566cc: mov             x0, x2
    // 0xc566d0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc566d0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc566d4: r0 = GDT[cid_x0 + -0xffe]()
    //     0xc566d4: sub             lr, x0, #0xffe
    //     0xc566d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc566dc: blr             lr
    // 0xc566e0: add             SP, SP, #0x18
    // 0xc566e4: LeaveFrame
    //     0xc566e4: mov             SP, fp
    //     0xc566e8: ldp             fp, lr, [SP], #0x10
    // 0xc566ec: ret
    //     0xc566ec: ret             
    // 0xc566f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc566f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc566f4: b               #0xc5666c
  }
  [closure] Future<Map<String, String?>?> <anonymous closure>(dynamic, Map<String, String?>?) async {
    // ** addr: 0xc566f8, size: 0x90
    // 0xc566f8: EnterFrame
    //     0xc566f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc566fc: mov             fp, SP
    // 0xc56700: AllocStack(0x20)
    //     0xc56700: sub             SP, SP, #0x20
    // 0xc56704: SetupParameters(DeviceInfoPlusLinuxPlugin this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0xc56704: stur            NULL, [fp, #-8]
    //     0xc56708: mov             x0, #0
    //     0xc5670c: add             x1, fp, w0, sxtw #2
    //     0xc56710: ldr             x1, [x1, #0x18]
    //     0xc56714: add             x2, fp, w0, sxtw #2
    //     0xc56718: ldr             x2, [x2, #0x10]
    //     0xc5671c: stur            x2, [fp, #-0x18]
    //     0xc56720: ldur            w3, [x1, #0x17]
    //     0xc56724: add             x3, x3, HEAP, lsl #32
    //     0xc56728: stur            x3, [fp, #-0x10]
    // 0xc5672c: CheckStackOverflow
    //     0xc5672c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc56730: cmp             SP, x16
    //     0xc56734: b.ls            #0xc56780
    // 0xc56738: InitAsync() -> Future<Map<String, String?>?>
    //     0xc56738: add             x0, PP, #0x41, lsl #12  ; [pp+0x411d0] TypeArguments: <Map<String, String?>?>
    //     0xc5673c: ldr             x0, [x0, #0x1d0]
    //     0xc56740: bl              #0x4b92e4
    // 0xc56744: ldur            x0, [fp, #-0x18]
    // 0xc56748: cmp             w0, NULL
    // 0xc5674c: b.ne            #0xc5677c
    // 0xc56750: ldur            x0, [fp, #-0x10]
    // 0xc56754: LoadField: r1 = r0->field_f
    //     0xc56754: ldur            w1, [x0, #0xf]
    // 0xc56758: DecompressPointer r1
    //     0xc56758: add             x1, x1, HEAP, lsl #32
    // 0xc5675c: r16 = "/usr/lib/os-release"
    //     0xc5675c: add             x16, PP, #0x41, lsl #12  ; [pp+0x411f8] "/usr/lib/os-release"
    //     0xc56760: ldr             x16, [x16, #0x1f8]
    // 0xc56764: stp             x16, x1, [SP, #-0x10]!
    // 0xc56768: r0 = _tryReadKeyValues()
    //     0xc56768: bl              #0xc5628c  ; [package:device_info_plus/src/device_info_plus_linux.dart] DeviceInfoPlusLinuxPlugin::_tryReadKeyValues
    // 0xc5676c: add             SP, SP, #0x10
    // 0xc56770: mov             x1, x0
    // 0xc56774: stur            x1, [fp, #-0x20]
    // 0xc56778: r0 = Await()
    //     0xc56778: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5677c: r0 = ReturnAsync()
    //     0xc5677c: b               #0x501858  ; ReturnAsyncStub
    // 0xc56780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc56784: b               #0xc56738
  }
  static void registerWith() {
    // ** addr: 0xd6e154, size: 0xb8
    // 0xd6e154: EnterFrame
    //     0xd6e154: stp             fp, lr, [SP, #-0x10]!
    //     0xd6e158: mov             fp, SP
    // 0xd6e15c: AllocStack(0x10)
    //     0xd6e15c: sub             SP, SP, #0x10
    // 0xd6e160: CheckStackOverflow
    //     0xd6e160: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6e164: cmp             SP, x16
    //     0xd6e168: b.ls            #0xd6e204
    // 0xd6e16c: r0 = DeviceInfoPlusLinuxPlugin()
    //     0xd6e16c: bl              #0xd6e20c  ; AllocateDeviceInfoPlusLinuxPluginStub -> DeviceInfoPlusLinuxPlugin (size=0x10)
    // 0xd6e170: mov             x1, x0
    // 0xd6e174: r0 = Instance_LocalFileSystem
    //     0xd6e174: ldr             x0, [PP, #0x218]  ; [pp+0x218] Obj!LocalFileSystem@b4fce1
    // 0xd6e178: stur            x1, [fp, #-8]
    // 0xd6e17c: StoreField: r1->field_b = r0
    //     0xd6e17c: stur            w0, [x1, #0xb]
    // 0xd6e180: r0 = InitLateStaticField(0xb38) // [package:device_info_plus_platform_interface/device_info_plus_platform_interface.dart] DeviceInfoPlatform::_token
    //     0xd6e180: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6e184: ldr             x0, [x0, #0x1670]
    //     0xd6e188: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6e18c: cmp             w0, w16
    //     0xd6e190: b.ne            #0xd6e19c
    //     0xd6e194: ldr             x2, [PP, #0x240]  ; [pp+0x240] Field <DeviceInfoPlatform._token@337502559>: static late final (offset: 0xb38)
    //     0xd6e198: bl              #0xd67cdc
    // 0xd6e19c: stur            x0, [fp, #-0x10]
    // 0xd6e1a0: r0 = InitLateStaticField(0xa64) // [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::_instanceTokens
    //     0xd6e1a0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6e1a4: ldr             x0, [x0, #0x14c8]
    //     0xd6e1a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6e1ac: cmp             w0, w16
    //     0xd6e1b0: b.ne            #0xd6e1bc
    //     0xd6e1b4: ldr             x2, [PP, #0x170]  ; [pp+0x170] Field <PlatformInterface._instanceTokens@187304592>: static late final (offset: 0xa64)
    //     0xd6e1b8: bl              #0xd67cdc
    // 0xd6e1bc: ldur            x16, [fp, #-8]
    // 0xd6e1c0: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e1c4: ldur            x16, [fp, #-0x10]
    // 0xd6e1c8: SaveReg r16
    //     0xd6e1c8: str             x16, [SP, #-8]!
    // 0xd6e1cc: r0 = []=()
    //     0xd6e1cc: bl              #0x4b97f8  ; [dart:core] Expando::[]=
    // 0xd6e1d0: add             SP, SP, #0x18
    // 0xd6e1d4: ldur            x16, [fp, #-8]
    // 0xd6e1d8: ldur            lr, [fp, #-0x10]
    // 0xd6e1dc: stp             lr, x16, [SP, #-0x10]!
    // 0xd6e1e0: r0 = verifyToken()
    //     0xd6e1e0: bl              #0xd6da00  ; [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::verifyToken
    // 0xd6e1e4: add             SP, SP, #0x10
    // 0xd6e1e8: ldur            x1, [fp, #-8]
    // 0xd6e1ec: StoreStaticField(0xb3c, r1)
    //     0xd6e1ec: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0xd6e1f0: str             x1, [x2, #0x1678]
    // 0xd6e1f4: r0 = Null
    //     0xd6e1f4: mov             x0, NULL
    // 0xd6e1f8: LeaveFrame
    //     0xd6e1f8: mov             SP, fp
    //     0xd6e1fc: ldp             fp, lr, [SP], #0x10
    // 0xd6e200: ret
    //     0xd6e200: ret             
    // 0xd6e204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6e204: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6e208: b               #0xd6e16c
  }
}

// lib: device_info_plus_windows, url: package:device_info_plus/src/device_info_plus_windows.dart

// class id: 1048868, size: 0x8
class :: {
}

// class id: 4949, size: 0x10, field offset: 0x8
class DeviceInfoPlusWindowsPlugin extends DeviceInfoPlatform {

  _ getInfo(/* No info */) {
    // ** addr: 0x92c424, size: 0x8e0
    // 0x92c424: EnterFrame
    //     0x92c424: stp             fp, lr, [SP, #-0x10]!
    //     0x92c428: mov             fp, SP
    // 0x92c42c: AllocStack(0xe0)
    //     0x92c42c: sub             SP, SP, #0xe0
    // 0x92c430: CheckStackOverflow
    //     0x92c430: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92c434: cmp             SP, x16
    //     0x92c438: b.ls            #0x92ccf8
    // 0x92c43c: ldr             x0, [fp, #0x10]
    // 0x92c440: LoadField: r1 = r0->field_b
    //     0x92c440: ldur            w1, [x0, #0xb]
    // 0x92c444: DecompressPointer r1
    //     0x92c444: add             x1, x1, HEAP, lsl #32
    // 0x92c448: cmp             w1, NULL
    // 0x92c44c: b.ne            #0x92c4d4
    // 0x92c450: r16 = "ntdll.dll"
    //     0x92c450: add             x16, PP, #0x33, lsl #12  ; [pp+0x33e90] "ntdll.dll"
    //     0x92c454: ldr             x16, [x16, #0xe90]
    // 0x92c458: SaveReg r16
    //     0x92c458: str             x16, [SP, #-8]!
    // 0x92c45c: r0 = _open()
    //     0x92c45c: bl              #0x930078  ; [dart:ffi] ::_open
    // 0x92c460: add             SP, SP, #8
    // 0x92c464: r16 = <NativeFunction<(dynamic this, Pointer<OSVERSIONINFOEX>) => Void>>
    //     0x92c464: add             x16, PP, #0x33, lsl #12  ; [pp+0x33e98] TypeArguments: <NativeFunction<(dynamic this, Pointer<OSVERSIONINFOEX>) => Void>>
    //     0x92c468: ldr             x16, [x16, #0xe98]
    // 0x92c46c: stp             x0, x16, [SP, #-0x10]!
    // 0x92c470: r16 = "RtlGetVersion"
    //     0x92c470: add             x16, PP, #0x33, lsl #12  ; [pp+0x33ea0] "RtlGetVersion"
    //     0x92c474: ldr             x16, [x16, #0xea0]
    // 0x92c478: SaveReg r16
    //     0x92c478: str             x16, [SP, #-8]!
    // 0x92c47c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92c47c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92c480: r0 = lookup()
    //     0x92c480: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0x92c484: add             SP, SP, #0x18
    // 0x92c488: stur            x0, [fp, #-8]
    // 0x92c48c: r1 = 1
    //     0x92c48c: mov             x1, #1
    // 0x92c490: r0 = AllocateContext()
    //     0x92c490: bl              #0xd68aa4  ; AllocateContextStub
    // 0x92c494: mov             x1, x0
    // 0x92c498: ldur            x0, [fp, #-8]
    // 0x92c49c: StoreField: r1->field_f = r0
    //     0x92c49c: stur            w0, [x1, #0xf]
    // 0x92c4a0: mov             x2, x1
    // 0x92c4a4: r1 = Function 'FfiTrampoline_getInfo': static ffi-trampoline-function.
    //     0x92c4a4: add             x1, PP, #0x33, lsl #12  ; [pp+0x33ea8] Function: [dart:ffi] ::FfiTrampoline__dispose$Method$FfiNative$Ptr (0x5dd2fc)
    //     0x92c4a8: ldr             x1, [x1, #0xea8]
    // 0x92c4ac: r0 = AllocateClosure()
    //     0x92c4ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x92c4b0: ldr             x1, [fp, #0x10]
    // 0x92c4b4: StoreField: r1->field_b = r0
    //     0x92c4b4: stur            w0, [x1, #0xb]
    //     0x92c4b8: ldurb           w16, [x1, #-1]
    //     0x92c4bc: ldurb           w17, [x0, #-1]
    //     0x92c4c0: and             x16, x17, x16, lsr #2
    //     0x92c4c4: tst             x16, HEAP, lsr #32
    //     0x92c4c8: b.eq            #0x92c4d0
    //     0x92c4cc: bl              #0xd6826c
    // 0x92c4d0: b               #0x92c4d8
    // 0x92c4d4: mov             x1, x0
    // 0x92c4d8: SaveReg r1
    //     0x92c4d8: str             x1, [SP, #-8]!
    // 0x92c4dc: r0 = getSYSTEMINFOPointer()
    //     0x92c4dc: bl              #0x92fd04  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getSYSTEMINFOPointer
    // 0x92c4e0: add             SP, SP, #8
    // 0x92c4e4: stur            x0, [fp, #-8]
    // 0x92c4e8: ldr             x16, [fp, #0x10]
    // 0x92c4ec: SaveReg r16
    //     0x92c4ec: str             x16, [SP, #-8]!
    // 0x92c4f0: r0 = getOSVERSIONINFOEXPointer()
    //     0x92c4f0: bl              #0x92fa80  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getOSVERSIONINFOEXPointer
    // 0x92c4f4: add             SP, SP, #8
    // 0x92c4f8: stur            x0, [fp, #-0x10]
    // 0x92c4fc: ldr             x16, [fp, #0x10]
    // 0x92c500: SaveReg r16
    //     0x92c500: str             x16, [SP, #-8]!
    // 0x92c504: r1 = 2147483650
    //     0x92c504: mov             x1, #2
    //     0x92c508: movk            x1, #0x8000, lsl #16
    // 0x92c50c: r16 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c50c: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb0] "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c510: ldr             x16, [x16, #0xeb0]
    // 0x92c514: stp             x16, x1, [SP, #-0x10]!
    // 0x92c518: r16 = "BuildLab"
    //     0x92c518: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb8] "BuildLab"
    //     0x92c51c: ldr             x16, [x16, #0xeb8]
    // 0x92c520: r30 = ""
    //     0x92c520: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x92c524: stp             lr, x16, [SP, #-0x10]!
    // 0x92c528: r0 = getRegistryValue()
    //     0x92c528: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c52c: add             SP, SP, #0x28
    // 0x92c530: mov             x3, x0
    // 0x92c534: r2 = Null
    //     0x92c534: mov             x2, NULL
    // 0x92c538: r1 = Null
    //     0x92c538: mov             x1, NULL
    // 0x92c53c: stur            x3, [fp, #-0x18]
    // 0x92c540: r4 = 59
    //     0x92c540: mov             x4, #0x3b
    // 0x92c544: branchIfSmi(r0, 0x92c550)
    //     0x92c544: tbz             w0, #0, #0x92c550
    // 0x92c548: r4 = LoadClassIdInstr(r0)
    //     0x92c548: ldur            x4, [x0, #-1]
    //     0x92c54c: ubfx            x4, x4, #0xc, #0x14
    // 0x92c550: sub             x4, x4, #0x5d
    // 0x92c554: cmp             x4, #3
    // 0x92c558: b.ls            #0x92c56c
    // 0x92c55c: r8 = String
    //     0x92c55c: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c560: r3 = Null
    //     0x92c560: add             x3, PP, #0x33, lsl #12  ; [pp+0x33ec0] Null
    //     0x92c564: ldr             x3, [x3, #0xec0]
    // 0x92c568: r0 = String()
    //     0x92c568: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c56c: ldr             x16, [fp, #0x10]
    // 0x92c570: SaveReg r16
    //     0x92c570: str             x16, [SP, #-8]!
    // 0x92c574: r0 = 2147483650
    //     0x92c574: mov             x0, #2
    //     0x92c578: movk            x0, #0x8000, lsl #16
    // 0x92c57c: r16 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c57c: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb0] "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c580: ldr             x16, [x16, #0xeb0]
    // 0x92c584: stp             x16, x0, [SP, #-0x10]!
    // 0x92c588: r16 = "BuildLabEx"
    //     0x92c588: add             x16, PP, #0x33, lsl #12  ; [pp+0x33ed0] "BuildLabEx"
    //     0x92c58c: ldr             x16, [x16, #0xed0]
    // 0x92c590: r30 = ""
    //     0x92c590: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x92c594: stp             lr, x16, [SP, #-0x10]!
    // 0x92c598: r0 = getRegistryValue()
    //     0x92c598: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c59c: add             SP, SP, #0x28
    // 0x92c5a0: mov             x3, x0
    // 0x92c5a4: r2 = Null
    //     0x92c5a4: mov             x2, NULL
    // 0x92c5a8: r1 = Null
    //     0x92c5a8: mov             x1, NULL
    // 0x92c5ac: stur            x3, [fp, #-0x20]
    // 0x92c5b0: r4 = 59
    //     0x92c5b0: mov             x4, #0x3b
    // 0x92c5b4: branchIfSmi(r0, 0x92c5c0)
    //     0x92c5b4: tbz             w0, #0, #0x92c5c0
    // 0x92c5b8: r4 = LoadClassIdInstr(r0)
    //     0x92c5b8: ldur            x4, [x0, #-1]
    //     0x92c5bc: ubfx            x4, x4, #0xc, #0x14
    // 0x92c5c0: sub             x4, x4, #0x5d
    // 0x92c5c4: cmp             x4, #3
    // 0x92c5c8: b.ls            #0x92c5dc
    // 0x92c5cc: r8 = String
    //     0x92c5cc: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c5d0: r3 = Null
    //     0x92c5d0: add             x3, PP, #0x33, lsl #12  ; [pp+0x33ed8] Null
    //     0x92c5d4: ldr             x3, [x3, #0xed8]
    // 0x92c5d8: r0 = String()
    //     0x92c5d8: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c5dc: r16 = <int>
    //     0x92c5dc: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x92c5e0: stp             xzr, x16, [SP, #-0x10]!
    // 0x92c5e4: r0 = _GrowableList()
    //     0x92c5e4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x92c5e8: add             SP, SP, #0x10
    // 0x92c5ec: stp             x0, NULL, [SP, #-0x10]!
    // 0x92c5f0: r0 = Uint8List.fromList()
    //     0x92c5f0: bl              #0x540140  ; [dart:typed_data] Uint8List::Uint8List.fromList
    // 0x92c5f4: add             SP, SP, #0x10
    // 0x92c5f8: ldr             x16, [fp, #0x10]
    // 0x92c5fc: SaveReg r16
    //     0x92c5fc: str             x16, [SP, #-8]!
    // 0x92c600: r1 = 2147483650
    //     0x92c600: mov             x1, #2
    //     0x92c604: movk            x1, #0x8000, lsl #16
    // 0x92c608: r16 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c608: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb0] "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c60c: ldr             x16, [x16, #0xeb0]
    // 0x92c610: stp             x16, x1, [SP, #-0x10]!
    // 0x92c614: r16 = "DigitalProductId"
    //     0x92c614: add             x16, PP, #0x33, lsl #12  ; [pp+0x33ee8] "DigitalProductId"
    //     0x92c618: ldr             x16, [x16, #0xee8]
    // 0x92c61c: stp             x0, x16, [SP, #-0x10]!
    // 0x92c620: r0 = getRegistryValue()
    //     0x92c620: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c624: add             SP, SP, #0x28
    // 0x92c628: mov             x3, x0
    // 0x92c62c: r2 = Null
    //     0x92c62c: mov             x2, NULL
    // 0x92c630: r1 = Null
    //     0x92c630: mov             x1, NULL
    // 0x92c634: stur            x3, [fp, #-0x28]
    // 0x92c638: r4 = 59
    //     0x92c638: mov             x4, #0x3b
    // 0x92c63c: branchIfSmi(r0, 0x92c648)
    //     0x92c63c: tbz             w0, #0, #0x92c648
    // 0x92c640: r4 = LoadClassIdInstr(r0)
    //     0x92c640: ldur            x4, [x0, #-1]
    //     0x92c644: ubfx            x4, x4, #0xc, #0x14
    // 0x92c648: sub             x4, x4, #0x75
    // 0x92c64c: cmp             x4, #3
    // 0x92c650: b.ls            #0x92c668
    // 0x92c654: r8 = Uint8List
    //     0x92c654: add             x8, PP, #8, lsl #12  ; [pp+0x8760] Type: Uint8List
    //     0x92c658: ldr             x8, [x8, #0x760]
    // 0x92c65c: r3 = Null
    //     0x92c65c: add             x3, PP, #0x33, lsl #12  ; [pp+0x33ef0] Null
    //     0x92c660: ldr             x3, [x3, #0xef0]
    // 0x92c664: r0 = Uint8List()
    //     0x92c664: bl              #0x4b2828  ; IsType_Uint8List_Stub
    // 0x92c668: ldr             x16, [fp, #0x10]
    // 0x92c66c: SaveReg r16
    //     0x92c66c: str             x16, [SP, #-8]!
    // 0x92c670: r0 = 2147483650
    //     0x92c670: mov             x0, #2
    //     0x92c674: movk            x0, #0x8000, lsl #16
    // 0x92c678: r16 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c678: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb0] "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c67c: ldr             x16, [x16, #0xeb0]
    // 0x92c680: stp             x16, x0, [SP, #-0x10]!
    // 0x92c684: r16 = "DisplayVersion"
    //     0x92c684: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f00] "DisplayVersion"
    //     0x92c688: ldr             x16, [x16, #0xf00]
    // 0x92c68c: r30 = ""
    //     0x92c68c: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x92c690: stp             lr, x16, [SP, #-0x10]!
    // 0x92c694: r0 = getRegistryValue()
    //     0x92c694: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c698: add             SP, SP, #0x28
    // 0x92c69c: mov             x3, x0
    // 0x92c6a0: r2 = Null
    //     0x92c6a0: mov             x2, NULL
    // 0x92c6a4: r1 = Null
    //     0x92c6a4: mov             x1, NULL
    // 0x92c6a8: stur            x3, [fp, #-0x30]
    // 0x92c6ac: r4 = 59
    //     0x92c6ac: mov             x4, #0x3b
    // 0x92c6b0: branchIfSmi(r0, 0x92c6bc)
    //     0x92c6b0: tbz             w0, #0, #0x92c6bc
    // 0x92c6b4: r4 = LoadClassIdInstr(r0)
    //     0x92c6b4: ldur            x4, [x0, #-1]
    //     0x92c6b8: ubfx            x4, x4, #0xc, #0x14
    // 0x92c6bc: sub             x4, x4, #0x5d
    // 0x92c6c0: cmp             x4, #3
    // 0x92c6c4: b.ls            #0x92c6d8
    // 0x92c6c8: r8 = String
    //     0x92c6c8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c6cc: r3 = Null
    //     0x92c6cc: add             x3, PP, #0x33, lsl #12  ; [pp+0x33f08] Null
    //     0x92c6d0: ldr             x3, [x3, #0xf08]
    // 0x92c6d4: r0 = String()
    //     0x92c6d4: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c6d8: ldr             x16, [fp, #0x10]
    // 0x92c6dc: SaveReg r16
    //     0x92c6dc: str             x16, [SP, #-8]!
    // 0x92c6e0: r0 = 2147483650
    //     0x92c6e0: mov             x0, #2
    //     0x92c6e4: movk            x0, #0x8000, lsl #16
    // 0x92c6e8: r16 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c6e8: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb0] "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c6ec: ldr             x16, [x16, #0xeb0]
    // 0x92c6f0: stp             x16, x0, [SP, #-0x10]!
    // 0x92c6f4: r16 = "EditionID"
    //     0x92c6f4: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f18] "EditionID"
    //     0x92c6f8: ldr             x16, [x16, #0xf18]
    // 0x92c6fc: r30 = ""
    //     0x92c6fc: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x92c700: stp             lr, x16, [SP, #-0x10]!
    // 0x92c704: r0 = getRegistryValue()
    //     0x92c704: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c708: add             SP, SP, #0x28
    // 0x92c70c: mov             x3, x0
    // 0x92c710: r2 = Null
    //     0x92c710: mov             x2, NULL
    // 0x92c714: r1 = Null
    //     0x92c714: mov             x1, NULL
    // 0x92c718: stur            x3, [fp, #-0x38]
    // 0x92c71c: r4 = 59
    //     0x92c71c: mov             x4, #0x3b
    // 0x92c720: branchIfSmi(r0, 0x92c72c)
    //     0x92c720: tbz             w0, #0, #0x92c72c
    // 0x92c724: r4 = LoadClassIdInstr(r0)
    //     0x92c724: ldur            x4, [x0, #-1]
    //     0x92c728: ubfx            x4, x4, #0xc, #0x14
    // 0x92c72c: sub             x4, x4, #0x5d
    // 0x92c730: cmp             x4, #3
    // 0x92c734: b.ls            #0x92c748
    // 0x92c738: r8 = String
    //     0x92c738: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c73c: r3 = Null
    //     0x92c73c: add             x3, PP, #0x33, lsl #12  ; [pp+0x33f20] Null
    //     0x92c740: ldr             x3, [x3, #0xf20]
    // 0x92c744: r0 = String()
    //     0x92c744: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c748: ldr             x16, [fp, #0x10]
    // 0x92c74c: SaveReg r16
    //     0x92c74c: str             x16, [SP, #-8]!
    // 0x92c750: r0 = 2147483650
    //     0x92c750: mov             x0, #2
    //     0x92c754: movk            x0, #0x8000, lsl #16
    // 0x92c758: r16 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c758: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb0] "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c75c: ldr             x16, [x16, #0xeb0]
    // 0x92c760: stp             x16, x0, [SP, #-0x10]!
    // 0x92c764: r16 = "InstallDate"
    //     0x92c764: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f30] "InstallDate"
    //     0x92c768: ldr             x16, [x16, #0xf30]
    // 0x92c76c: stp             xzr, x16, [SP, #-0x10]!
    // 0x92c770: r0 = getRegistryValue()
    //     0x92c770: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c774: add             SP, SP, #0x28
    // 0x92c778: mov             x3, x0
    // 0x92c77c: r2 = Null
    //     0x92c77c: mov             x2, NULL
    // 0x92c780: r1 = Null
    //     0x92c780: mov             x1, NULL
    // 0x92c784: stur            x3, [fp, #-0x40]
    // 0x92c788: branchIfSmi(r0, 0x92c7b0)
    //     0x92c788: tbz             w0, #0, #0x92c7b0
    // 0x92c78c: r4 = LoadClassIdInstr(r0)
    //     0x92c78c: ldur            x4, [x0, #-1]
    //     0x92c790: ubfx            x4, x4, #0xc, #0x14
    // 0x92c794: sub             x4, x4, #0x3b
    // 0x92c798: cmp             x4, #2
    // 0x92c79c: b.ls            #0x92c7b0
    // 0x92c7a0: r8 = num
    //     0x92c7a0: ldr             x8, [PP, #0x1888]  ; [pp+0x1888] Type: num
    // 0x92c7a4: r3 = Null
    //     0x92c7a4: add             x3, PP, #0x33, lsl #12  ; [pp+0x33f38] Null
    //     0x92c7a8: ldr             x3, [x3, #0xf38]
    // 0x92c7ac: r0 = num()
    //     0x92c7ac: bl              #0xd73744  ; IsType_num_Stub
    // 0x92c7b0: r16 = 2000
    //     0x92c7b0: mov             x16, #0x7d0
    // 0x92c7b4: ldur            lr, [fp, #-0x40]
    // 0x92c7b8: stp             lr, x16, [SP, #-0x10]!
    // 0x92c7bc: r0 = *()
    //     0x92c7bc: bl              #0xd67688  ; [dart:core] _IntegerImplementation::*
    // 0x92c7c0: add             SP, SP, #0x10
    // 0x92c7c4: r1 = LoadInt32Instr(r0)
    //     0x92c7c4: sbfx            x1, x0, #1, #0x1f
    //     0x92c7c8: tbz             w0, #0, #0x92c7d0
    //     0x92c7cc: ldur            x1, [x0, #7]
    // 0x92c7d0: SaveReg r1
    //     0x92c7d0: str             x1, [SP, #-8]!
    // 0x92c7d4: r0 = _validateMilliseconds()
    //     0x92c7d4: bl              #0x8f5234  ; [dart:core] DateTime::_validateMilliseconds
    // 0x92c7d8: add             SP, SP, #8
    // 0x92c7dc: r16 = 1000
    //     0x92c7dc: mov             x16, #0x3e8
    // 0x92c7e0: mul             x1, x0, x16
    // 0x92c7e4: stur            x1, [fp, #-0x48]
    // 0x92c7e8: r0 = DateTime()
    //     0x92c7e8: bl              #0x5321bc  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x92c7ec: stur            x0, [fp, #-0x40]
    // 0x92c7f0: SaveReg r0
    //     0x92c7f0: str             x0, [SP, #-8]!
    // 0x92c7f4: ldur            x1, [fp, #-0x48]
    // 0x92c7f8: r16 = false
    //     0x92c7f8: add             x16, NULL, #0x30  ; false
    // 0x92c7fc: stp             x16, x1, [SP, #-0x10]!
    // 0x92c800: r0 = DateTime._withValue()
    //     0x92c800: bl              #0x53205c  ; [dart:core] DateTime::DateTime._withValue
    // 0x92c804: add             SP, SP, #0x18
    // 0x92c808: ldr             x16, [fp, #0x10]
    // 0x92c80c: SaveReg r16
    //     0x92c80c: str             x16, [SP, #-8]!
    // 0x92c810: r0 = 2147483650
    //     0x92c810: mov             x0, #2
    //     0x92c814: movk            x0, #0x8000, lsl #16
    // 0x92c818: r16 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c818: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb0] "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c81c: ldr             x16, [x16, #0xeb0]
    // 0x92c820: stp             x16, x0, [SP, #-0x10]!
    // 0x92c824: r16 = "ProductId"
    //     0x92c824: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f48] "ProductId"
    //     0x92c828: ldr             x16, [x16, #0xf48]
    // 0x92c82c: r30 = ""
    //     0x92c82c: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x92c830: stp             lr, x16, [SP, #-0x10]!
    // 0x92c834: r0 = getRegistryValue()
    //     0x92c834: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c838: add             SP, SP, #0x28
    // 0x92c83c: mov             x3, x0
    // 0x92c840: r2 = Null
    //     0x92c840: mov             x2, NULL
    // 0x92c844: r1 = Null
    //     0x92c844: mov             x1, NULL
    // 0x92c848: stur            x3, [fp, #-0x50]
    // 0x92c84c: r4 = 59
    //     0x92c84c: mov             x4, #0x3b
    // 0x92c850: branchIfSmi(r0, 0x92c85c)
    //     0x92c850: tbz             w0, #0, #0x92c85c
    // 0x92c854: r4 = LoadClassIdInstr(r0)
    //     0x92c854: ldur            x4, [x0, #-1]
    //     0x92c858: ubfx            x4, x4, #0xc, #0x14
    // 0x92c85c: sub             x4, x4, #0x5d
    // 0x92c860: cmp             x4, #3
    // 0x92c864: b.ls            #0x92c878
    // 0x92c868: r8 = String
    //     0x92c868: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c86c: r3 = Null
    //     0x92c86c: add             x3, PP, #0x33, lsl #12  ; [pp+0x33f50] Null
    //     0x92c870: ldr             x3, [x3, #0xf50]
    // 0x92c874: r0 = String()
    //     0x92c874: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c878: ldr             x16, [fp, #0x10]
    // 0x92c87c: SaveReg r16
    //     0x92c87c: str             x16, [SP, #-8]!
    // 0x92c880: r0 = 2147483650
    //     0x92c880: mov             x0, #2
    //     0x92c884: movk            x0, #0x8000, lsl #16
    // 0x92c888: r16 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c888: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb0] "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c88c: ldr             x16, [x16, #0xeb0]
    // 0x92c890: stp             x16, x0, [SP, #-0x10]!
    // 0x92c894: r16 = "ProductName"
    //     0x92c894: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f60] "ProductName"
    //     0x92c898: ldr             x16, [x16, #0xf60]
    // 0x92c89c: r30 = ""
    //     0x92c89c: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x92c8a0: stp             lr, x16, [SP, #-0x10]!
    // 0x92c8a4: r0 = getRegistryValue()
    //     0x92c8a4: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c8a8: add             SP, SP, #0x28
    // 0x92c8ac: mov             x3, x0
    // 0x92c8b0: r2 = Null
    //     0x92c8b0: mov             x2, NULL
    // 0x92c8b4: r1 = Null
    //     0x92c8b4: mov             x1, NULL
    // 0x92c8b8: stur            x3, [fp, #-0x58]
    // 0x92c8bc: r4 = 59
    //     0x92c8bc: mov             x4, #0x3b
    // 0x92c8c0: branchIfSmi(r0, 0x92c8cc)
    //     0x92c8c0: tbz             w0, #0, #0x92c8cc
    // 0x92c8c4: r4 = LoadClassIdInstr(r0)
    //     0x92c8c4: ldur            x4, [x0, #-1]
    //     0x92c8c8: ubfx            x4, x4, #0xc, #0x14
    // 0x92c8cc: sub             x4, x4, #0x5d
    // 0x92c8d0: cmp             x4, #3
    // 0x92c8d4: b.ls            #0x92c8e8
    // 0x92c8d8: r8 = String
    //     0x92c8d8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c8dc: r3 = Null
    //     0x92c8dc: add             x3, PP, #0x33, lsl #12  ; [pp+0x33f68] Null
    //     0x92c8e0: ldr             x3, [x3, #0xf68]
    // 0x92c8e4: r0 = String()
    //     0x92c8e4: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c8e8: ldr             x16, [fp, #0x10]
    // 0x92c8ec: SaveReg r16
    //     0x92c8ec: str             x16, [SP, #-8]!
    // 0x92c8f0: r0 = 2147483650
    //     0x92c8f0: mov             x0, #2
    //     0x92c8f4: movk            x0, #0x8000, lsl #16
    // 0x92c8f8: r16 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c8f8: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb0] "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c8fc: ldr             x16, [x16, #0xeb0]
    // 0x92c900: stp             x16, x0, [SP, #-0x10]!
    // 0x92c904: r16 = "RegisteredOwner"
    //     0x92c904: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f78] "RegisteredOwner"
    //     0x92c908: ldr             x16, [x16, #0xf78]
    // 0x92c90c: r30 = ""
    //     0x92c90c: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x92c910: stp             lr, x16, [SP, #-0x10]!
    // 0x92c914: r0 = getRegistryValue()
    //     0x92c914: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c918: add             SP, SP, #0x28
    // 0x92c91c: mov             x3, x0
    // 0x92c920: r2 = Null
    //     0x92c920: mov             x2, NULL
    // 0x92c924: r1 = Null
    //     0x92c924: mov             x1, NULL
    // 0x92c928: stur            x3, [fp, #-0x60]
    // 0x92c92c: r4 = 59
    //     0x92c92c: mov             x4, #0x3b
    // 0x92c930: branchIfSmi(r0, 0x92c93c)
    //     0x92c930: tbz             w0, #0, #0x92c93c
    // 0x92c934: r4 = LoadClassIdInstr(r0)
    //     0x92c934: ldur            x4, [x0, #-1]
    //     0x92c938: ubfx            x4, x4, #0xc, #0x14
    // 0x92c93c: sub             x4, x4, #0x5d
    // 0x92c940: cmp             x4, #3
    // 0x92c944: b.ls            #0x92c958
    // 0x92c948: r8 = String
    //     0x92c948: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c94c: r3 = Null
    //     0x92c94c: add             x3, PP, #0x33, lsl #12  ; [pp+0x33f80] Null
    //     0x92c950: ldr             x3, [x3, #0xf80]
    // 0x92c954: r0 = String()
    //     0x92c954: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c958: ldr             x16, [fp, #0x10]
    // 0x92c95c: SaveReg r16
    //     0x92c95c: str             x16, [SP, #-8]!
    // 0x92c960: r0 = 2147483650
    //     0x92c960: mov             x0, #2
    //     0x92c964: movk            x0, #0x8000, lsl #16
    // 0x92c968: r16 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c968: add             x16, PP, #0x33, lsl #12  ; [pp+0x33eb0] "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\"
    //     0x92c96c: ldr             x16, [x16, #0xeb0]
    // 0x92c970: stp             x16, x0, [SP, #-0x10]!
    // 0x92c974: r16 = "ReleaseId"
    //     0x92c974: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f90] "ReleaseId"
    //     0x92c978: ldr             x16, [x16, #0xf90]
    // 0x92c97c: r30 = ""
    //     0x92c97c: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x92c980: stp             lr, x16, [SP, #-0x10]!
    // 0x92c984: r0 = getRegistryValue()
    //     0x92c984: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c988: add             SP, SP, #0x28
    // 0x92c98c: mov             x3, x0
    // 0x92c990: r2 = Null
    //     0x92c990: mov             x2, NULL
    // 0x92c994: r1 = Null
    //     0x92c994: mov             x1, NULL
    // 0x92c998: stur            x3, [fp, #-0x68]
    // 0x92c99c: r4 = 59
    //     0x92c99c: mov             x4, #0x3b
    // 0x92c9a0: branchIfSmi(r0, 0x92c9ac)
    //     0x92c9a0: tbz             w0, #0, #0x92c9ac
    // 0x92c9a4: r4 = LoadClassIdInstr(r0)
    //     0x92c9a4: ldur            x4, [x0, #-1]
    //     0x92c9a8: ubfx            x4, x4, #0xc, #0x14
    // 0x92c9ac: sub             x4, x4, #0x5d
    // 0x92c9b0: cmp             x4, #3
    // 0x92c9b4: b.ls            #0x92c9c8
    // 0x92c9b8: r8 = String
    //     0x92c9b8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c9bc: r3 = Null
    //     0x92c9bc: add             x3, PP, #0x33, lsl #12  ; [pp+0x33f98] Null
    //     0x92c9c0: ldr             x3, [x3, #0xf98]
    // 0x92c9c4: r0 = String()
    //     0x92c9c4: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c9c8: ldr             x16, [fp, #0x10]
    // 0x92c9cc: SaveReg r16
    //     0x92c9cc: str             x16, [SP, #-8]!
    // 0x92c9d0: r0 = 2147483650
    //     0x92c9d0: mov             x0, #2
    //     0x92c9d4: movk            x0, #0x8000, lsl #16
    // 0x92c9d8: r16 = "SOFTWARE\\Microsoft\\SQMClient\\"
    //     0x92c9d8: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fa8] "SOFTWARE\\Microsoft\\SQMClient\\"
    //     0x92c9dc: ldr             x16, [x16, #0xfa8]
    // 0x92c9e0: stp             x16, x0, [SP, #-0x10]!
    // 0x92c9e4: r16 = "MachineId"
    //     0x92c9e4: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fb0] "MachineId"
    //     0x92c9e8: ldr             x16, [x16, #0xfb0]
    // 0x92c9ec: r30 = ""
    //     0x92c9ec: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x92c9f0: stp             lr, x16, [SP, #-0x10]!
    // 0x92c9f4: r0 = getRegistryValue()
    //     0x92c9f4: bl              #0x92e90c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getRegistryValue
    // 0x92c9f8: add             SP, SP, #0x28
    // 0x92c9fc: mov             x3, x0
    // 0x92ca00: r2 = Null
    //     0x92ca00: mov             x2, NULL
    // 0x92ca04: r1 = Null
    //     0x92ca04: mov             x1, NULL
    // 0x92ca08: stur            x3, [fp, #-0x70]
    // 0x92ca0c: r4 = 59
    //     0x92ca0c: mov             x4, #0x3b
    // 0x92ca10: branchIfSmi(r0, 0x92ca1c)
    //     0x92ca10: tbz             w0, #0, #0x92ca1c
    // 0x92ca14: r4 = LoadClassIdInstr(r0)
    //     0x92ca14: ldur            x4, [x0, #-1]
    //     0x92ca18: ubfx            x4, x4, #0xc, #0x14
    // 0x92ca1c: sub             x4, x4, #0x5d
    // 0x92ca20: cmp             x4, #3
    // 0x92ca24: b.ls            #0x92ca38
    // 0x92ca28: r8 = String
    //     0x92ca28: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92ca2c: r3 = Null
    //     0x92ca2c: add             x3, PP, #0x33, lsl #12  ; [pp+0x33fb8] Null
    //     0x92ca30: ldr             x3, [x3, #0xfb8]
    // 0x92ca34: r0 = String()
    //     0x92ca34: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92ca38: ldur            x16, [fp, #-8]
    // 0x92ca3c: SaveReg r16
    //     0x92ca3c: str             x16, [SP, #-8]!
    // 0x92ca40: r0 = GetSystemInfo()
    //     0x92ca40: bl              #0x92e818  ; [package:win32/src/win32/kernel32.g.dart] ::GetSystemInfo
    // 0x92ca44: add             SP, SP, #8
    // 0x92ca48: ldr             x1, [fp, #0x10]
    // 0x92ca4c: LoadField: r0 = r1->field_b
    //     0x92ca4c: ldur            w0, [x1, #0xb]
    // 0x92ca50: DecompressPointer r0
    //     0x92ca50: add             x0, x0, HEAP, lsl #32
    // 0x92ca54: cmp             w0, NULL
    // 0x92ca58: b.eq            #0x92cd00
    // 0x92ca5c: ldur            x16, [fp, #-0x10]
    // 0x92ca60: stp             x16, x0, [SP, #-0x10]!
    // 0x92ca64: ClosureCall
    //     0x92ca64: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x92ca68: ldur            x2, [x0, #0x1f]
    //     0x92ca6c: blr             x2
    // 0x92ca70: add             SP, SP, #0x10
    // 0x92ca74: ldur            x0, [fp, #-0x10]
    // 0x92ca78: LoadField: r1 = r0->field_7
    //     0x92ca78: ldur            x1, [x0, #7]
    // 0x92ca7c: ldr             w2, [x1, #0xc]
    // 0x92ca80: ubfx            x2, x2, #0, #0x20
    // 0x92ca84: r17 = 22000
    //     0x92ca84: mov             x17, #0x55f0
    // 0x92ca88: cmp             x2, x17
    // 0x92ca8c: b.lt            #0x92cabc
    // 0x92ca90: ldur            x16, [fp, #-0x58]
    // 0x92ca94: r30 = "10"
    //     0x92ca94: add             lr, PP, #0x33, lsl #12  ; [pp+0x33fc8] "10"
    //     0x92ca98: ldr             lr, [lr, #0xfc8]
    // 0x92ca9c: stp             lr, x16, [SP, #-0x10]!
    // 0x92caa0: r16 = "11"
    //     0x92caa0: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fd0] "11"
    //     0x92caa4: ldr             x16, [x16, #0xfd0]
    // 0x92caa8: SaveReg r16
    //     0x92caa8: str             x16, [SP, #-8]!
    // 0x92caac: r0 = replaceAll()
    //     0x92caac: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0x92cab0: add             SP, SP, #0x18
    // 0x92cab4: mov             x12, x0
    // 0x92cab8: b               #0x92cac0
    // 0x92cabc: ldur            x12, [fp, #-0x58]
    // 0x92cac0: ldur            x11, [fp, #-8]
    // 0x92cac4: ldur            x0, [fp, #-0x10]
    // 0x92cac8: ldur            x10, [fp, #-0x18]
    // 0x92cacc: ldur            x9, [fp, #-0x20]
    // 0x92cad0: ldur            x8, [fp, #-0x28]
    // 0x92cad4: ldur            x7, [fp, #-0x30]
    // 0x92cad8: ldur            x6, [fp, #-0x38]
    // 0x92cadc: ldur            x5, [fp, #-0x40]
    // 0x92cae0: ldur            x4, [fp, #-0x50]
    // 0x92cae4: ldur            x3, [fp, #-0x60]
    // 0x92cae8: ldur            x2, [fp, #-0x68]
    // 0x92caec: ldur            x1, [fp, #-0x70]
    // 0x92caf0: stur            x12, [fp, #-0x58]
    // 0x92caf4: LoadField: r13 = r11->field_7
    //     0x92caf4: ldur            x13, [x11, #7]
    // 0x92caf8: ldr             w14, [x13, #0x20]
    // 0x92cafc: stur            x14, [fp, #-0x48]
    // 0x92cb00: ldr             x16, [fp, #0x10]
    // 0x92cb04: SaveReg r16
    //     0x92cb04: str             x16, [SP, #-8]!
    // 0x92cb08: r0 = getComputerName()
    //     0x92cb08: bl              #0x92e448  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getComputerName
    // 0x92cb0c: add             SP, SP, #8
    // 0x92cb10: stur            x0, [fp, #-0x78]
    // 0x92cb14: ldr             x16, [fp, #0x10]
    // 0x92cb18: SaveReg r16
    //     0x92cb18: str             x16, [SP, #-8]!
    // 0x92cb1c: r0 = getSystemMemoryInMegabytes()
    //     0x92cb1c: bl              #0x92e154  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getSystemMemoryInMegabytes
    // 0x92cb20: add             SP, SP, #8
    // 0x92cb24: stur            x0, [fp, #-0x80]
    // 0x92cb28: ldr             x16, [fp, #0x10]
    // 0x92cb2c: SaveReg r16
    //     0x92cb2c: str             x16, [SP, #-8]!
    // 0x92cb30: r0 = getUserName()
    //     0x92cb30: bl              #0x92d34c  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getUserName
    // 0x92cb34: add             SP, SP, #8
    // 0x92cb38: mov             x1, x0
    // 0x92cb3c: ldur            x0, [fp, #-0x10]
    // 0x92cb40: stur            x1, [fp, #-0xa8]
    // 0x92cb44: LoadField: r2 = r0->field_7
    //     0x92cb44: ldur            x2, [x0, #7]
    // 0x92cb48: ldr             w3, [x2, #4]
    // 0x92cb4c: stur            x3, [fp, #-0xa0]
    // 0x92cb50: LoadField: r2 = r0->field_7
    //     0x92cb50: ldur            x2, [x0, #7]
    // 0x92cb54: ldr             w4, [x2, #8]
    // 0x92cb58: stur            x4, [fp, #-0x98]
    // 0x92cb5c: LoadField: r2 = r0->field_7
    //     0x92cb5c: ldur            x2, [x0, #7]
    // 0x92cb60: ldr             w5, [x2, #0xc]
    // 0x92cb64: stur            x5, [fp, #-0x90]
    // 0x92cb68: LoadField: r2 = r0->field_7
    //     0x92cb68: ldur            x2, [x0, #7]
    // 0x92cb6c: ldr             w6, [x2, #0x10]
    // 0x92cb70: stur            x6, [fp, #-0x88]
    // 0x92cb74: r0 = OSVERSIONINFOEX()
    //     0x92cb74: bl              #0x92d340  ; AllocateOSVERSIONINFOEXStub -> OSVERSIONINFOEX (size=0xc)
    // 0x92cb78: mov             x1, x0
    // 0x92cb7c: ldur            x0, [fp, #-0x10]
    // 0x92cb80: StoreField: r1->field_7 = r0
    //     0x92cb80: stur            w0, [x1, #7]
    // 0x92cb84: SaveReg r1
    //     0x92cb84: str             x1, [SP, #-8]!
    // 0x92cb88: r0 = szCSDVersion()
    //     0x92cb88: bl              #0x92cfa8  ; [package:win32/src/structs.g.dart] OSVERSIONINFOEX::szCSDVersion
    // 0x92cb8c: add             SP, SP, #8
    // 0x92cb90: mov             x1, x0
    // 0x92cb94: ldur            x0, [fp, #-0x10]
    // 0x92cb98: stur            x1, [fp, #-0xd8]
    // 0x92cb9c: LoadField: r2 = r0->field_7
    //     0x92cb9c: ldur            x2, [x0, #7]
    // 0x92cba0: ArrayLoad: r3 = r2[126]  ; TypedUnsigned_2
    //     0x92cba0: ldrh            w3, [x2, #0x114]
    // 0x92cba4: stur            x3, [fp, #-0xd0]
    // 0x92cba8: LoadField: r2 = r0->field_7
    //     0x92cba8: ldur            x2, [x0, #7]
    // 0x92cbac: ArrayLoad: r4 = r2[127]  ; TypedUnsigned_2
    //     0x92cbac: ldrh            w4, [x2, #0x116]
    // 0x92cbb0: stur            x4, [fp, #-0xc8]
    // 0x92cbb4: LoadField: r2 = r0->field_7
    //     0x92cbb4: ldur            x2, [x0, #7]
    // 0x92cbb8: ArrayLoad: r5 = r2[128]  ; TypedUnsigned_2
    //     0x92cbb8: ldrh            w5, [x2, #0x118]
    // 0x92cbbc: stur            x5, [fp, #-0xc0]
    // 0x92cbc0: LoadField: r2 = r0->field_7
    //     0x92cbc0: ldur            x2, [x0, #7]
    // 0x92cbc4: ArrayLoad: r6 = r2[259]  ; TypedUnsigned_1
    //     0x92cbc4: ldrb            w6, [x2, #0x11a]
    // 0x92cbc8: stur            x6, [fp, #-0xb8]
    // 0x92cbcc: LoadField: r2 = r0->field_7
    //     0x92cbcc: ldur            x2, [x0, #7]
    // 0x92cbd0: ArrayLoad: r7 = r2[260]  ; TypedUnsigned_1
    //     0x92cbd0: ldrb            w7, [x2, #0x11b]
    // 0x92cbd4: stur            x7, [fp, #-0xb0]
    // 0x92cbd8: r0 = WindowsDeviceInfo()
    //     0x92cbd8: bl              #0x92cf9c  ; AllocateWindowsDeviceInfoStub -> WindowsDeviceInfo (size=0x98)
    // 0x92cbdc: mov             x1, x0
    // 0x92cbe0: ldur            x0, [fp, #-0x78]
    // 0x92cbe4: stur            x1, [fp, #-0xe0]
    // 0x92cbe8: StoreField: r1->field_7 = r0
    //     0x92cbe8: stur            w0, [x1, #7]
    // 0x92cbec: ldur            x0, [fp, #-0x48]
    // 0x92cbf0: ubfx            x0, x0, #0, #0x20
    // 0x92cbf4: StoreField: r1->field_b = r0
    //     0x92cbf4: stur            x0, [x1, #0xb]
    // 0x92cbf8: ldur            x0, [fp, #-0x80]
    // 0x92cbfc: StoreField: r1->field_13 = r0
    //     0x92cbfc: stur            x0, [x1, #0x13]
    // 0x92cc00: ldur            x0, [fp, #-0xa8]
    // 0x92cc04: StoreField: r1->field_1b = r0
    //     0x92cc04: stur            w0, [x1, #0x1b]
    // 0x92cc08: ldur            x0, [fp, #-0xa0]
    // 0x92cc0c: ubfx            x0, x0, #0, #0x20
    // 0x92cc10: StoreField: r1->field_1f = r0
    //     0x92cc10: stur            x0, [x1, #0x1f]
    // 0x92cc14: ldur            x0, [fp, #-0x98]
    // 0x92cc18: ubfx            x0, x0, #0, #0x20
    // 0x92cc1c: StoreField: r1->field_27 = r0
    //     0x92cc1c: stur            x0, [x1, #0x27]
    // 0x92cc20: ldur            x0, [fp, #-0x90]
    // 0x92cc24: ubfx            x0, x0, #0, #0x20
    // 0x92cc28: StoreField: r1->field_2f = r0
    //     0x92cc28: stur            x0, [x1, #0x2f]
    // 0x92cc2c: ldur            x0, [fp, #-0x88]
    // 0x92cc30: ubfx            x0, x0, #0, #0x20
    // 0x92cc34: StoreField: r1->field_37 = r0
    //     0x92cc34: stur            x0, [x1, #0x37]
    // 0x92cc38: ldur            x0, [fp, #-0xd8]
    // 0x92cc3c: StoreField: r1->field_3f = r0
    //     0x92cc3c: stur            w0, [x1, #0x3f]
    // 0x92cc40: ldur            x0, [fp, #-0xd0]
    // 0x92cc44: StoreField: r1->field_43 = r0
    //     0x92cc44: stur            x0, [x1, #0x43]
    // 0x92cc48: ldur            x0, [fp, #-0xc8]
    // 0x92cc4c: StoreField: r1->field_4b = r0
    //     0x92cc4c: stur            x0, [x1, #0x4b]
    // 0x92cc50: ldur            x0, [fp, #-0xc0]
    // 0x92cc54: StoreField: r1->field_53 = r0
    //     0x92cc54: stur            x0, [x1, #0x53]
    // 0x92cc58: ldur            x0, [fp, #-0xb8]
    // 0x92cc5c: StoreField: r1->field_5b = r0
    //     0x92cc5c: stur            x0, [x1, #0x5b]
    // 0x92cc60: ldur            x0, [fp, #-0xb0]
    // 0x92cc64: StoreField: r1->field_63 = r0
    //     0x92cc64: stur            x0, [x1, #0x63]
    // 0x92cc68: ldur            x0, [fp, #-0x18]
    // 0x92cc6c: StoreField: r1->field_6b = r0
    //     0x92cc6c: stur            w0, [x1, #0x6b]
    // 0x92cc70: ldur            x0, [fp, #-0x20]
    // 0x92cc74: StoreField: r1->field_6f = r0
    //     0x92cc74: stur            w0, [x1, #0x6f]
    // 0x92cc78: ldur            x0, [fp, #-0x28]
    // 0x92cc7c: StoreField: r1->field_73 = r0
    //     0x92cc7c: stur            w0, [x1, #0x73]
    // 0x92cc80: ldur            x0, [fp, #-0x30]
    // 0x92cc84: StoreField: r1->field_77 = r0
    //     0x92cc84: stur            w0, [x1, #0x77]
    // 0x92cc88: ldur            x0, [fp, #-0x38]
    // 0x92cc8c: StoreField: r1->field_7b = r0
    //     0x92cc8c: stur            w0, [x1, #0x7b]
    // 0x92cc90: ldur            x0, [fp, #-0x40]
    // 0x92cc94: StoreField: r1->field_7f = r0
    //     0x92cc94: stur            w0, [x1, #0x7f]
    // 0x92cc98: ldur            x0, [fp, #-0x50]
    // 0x92cc9c: StoreField: r1->field_83 = r0
    //     0x92cc9c: stur            w0, [x1, #0x83]
    // 0x92cca0: ldur            x0, [fp, #-0x58]
    // 0x92cca4: StoreField: r1->field_87 = r0
    //     0x92cca4: stur            w0, [x1, #0x87]
    // 0x92cca8: ldur            x0, [fp, #-0x60]
    // 0x92ccac: StoreField: r1->field_8b = r0
    //     0x92ccac: stur            w0, [x1, #0x8b]
    // 0x92ccb0: ldur            x0, [fp, #-0x68]
    // 0x92ccb4: StoreField: r1->field_8f = r0
    //     0x92ccb4: stur            w0, [x1, #0x8f]
    // 0x92ccb8: ldur            x0, [fp, #-0x70]
    // 0x92ccbc: StoreField: r1->field_93 = r0
    //     0x92ccbc: stur            w0, [x1, #0x93]
    // 0x92ccc0: r16 = Instance__CallocAllocator
    //     0x92ccc0: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92ccc4: ldur            lr, [fp, #-8]
    // 0x92ccc8: stp             lr, x16, [SP, #-0x10]!
    // 0x92cccc: r0 = free()
    //     0x92cccc: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0x92ccd0: add             SP, SP, #0x10
    // 0x92ccd4: r16 = Instance__CallocAllocator
    //     0x92ccd4: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92ccd8: ldur            lr, [fp, #-0x10]
    // 0x92ccdc: stp             lr, x16, [SP, #-0x10]!
    // 0x92cce0: r0 = free()
    //     0x92cce0: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0x92cce4: add             SP, SP, #0x10
    // 0x92cce8: ldur            x0, [fp, #-0xe0]
    // 0x92ccec: LeaveFrame
    //     0x92ccec: mov             SP, fp
    //     0x92ccf0: ldp             fp, lr, [SP], #0x10
    // 0x92ccf4: ret
    //     0x92ccf4: ret             
    // 0x92ccf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92ccf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92ccfc: b               #0x92c43c
    // 0x92cd00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x92cd00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getUserName(/* No info */) {
    // ** addr: 0x92d34c, size: 0x128
    // 0x92d34c: EnterFrame
    //     0x92d34c: stp             fp, lr, [SP, #-0x10]!
    //     0x92d350: mov             fp, SP
    // 0x92d354: AllocStack(0x60)
    //     0x92d354: sub             SP, SP, #0x60
    // 0x92d358: r0 = 4
    //     0x92d358: mov             x0, #4
    // 0x92d35c: CheckStackOverflow
    //     0x92d35c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92d360: cmp             SP, x16
    //     0x92d364: b.ls            #0x92d46c
    // 0x92d368: r16 = <Uint32>
    //     0x92d368: add             x16, PP, #8, lsl #12  ; [pp+0x8340] TypeArguments: <Uint32>
    //     0x92d36c: ldr             x16, [x16, #0x340]
    // 0x92d370: r30 = Instance__CallocAllocator
    //     0x92d370: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92d374: stp             lr, x16, [SP, #-0x10]!
    // 0x92d378: SaveReg r0
    //     0x92d378: str             x0, [SP, #-8]!
    // 0x92d37c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92d37c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92d380: r0 = allocate()
    //     0x92d380: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0x92d384: add             SP, SP, #0x18
    // 0x92d388: stur            x0, [fp, #-0x50]
    // 0x92d38c: LoadField: r1 = r0->field_7
    //     0x92d38c: ldur            x1, [x0, #7]
    // 0x92d390: r2 = 257
    //     0x92d390: mov             x2, #0x101
    // 0x92d394: str             w2, [x1]
    // 0x92d398: r1 = 257
    //     0x92d398: mov             x1, #0x101
    // 0x92d39c: SaveReg r1
    //     0x92d39c: str             x1, [SP, #-8]!
    // 0x92d3a0: r0 = wsalloc()
    //     0x92d3a0: bl              #0x92dbb0  ; [package:win32/src/utils.dart] ::wsalloc
    // 0x92d3a4: add             SP, SP, #8
    // 0x92d3a8: stur            x0, [fp, #-0x58]
    // 0x92d3ac: ldur            x16, [fp, #-0x50]
    // 0x92d3b0: stp             x16, x0, [SP, #-0x10]!
    // 0x92d3b4: r0 = GetUserName()
    //     0x92d3b4: bl              #0x92d95c  ; [package:win32/src/win32/advapi32.g.dart] ::GetUserName
    // 0x92d3b8: add             SP, SP, #0x10
    // 0x92d3bc: cbz             x0, #0x92d404
    // 0x92d3c0: ldur            x16, [fp, #-0x58]
    // 0x92d3c4: SaveReg r16
    //     0x92d3c4: str             x16, [SP, #-8]!
    // 0x92d3c8: r0 = Utf16Pointer.toDartString()
    //     0x92d3c8: bl              #0x92d72c  ; [package:ffi/src/utf16.dart] ::Utf16Pointer.toDartString
    // 0x92d3cc: add             SP, SP, #8
    // 0x92d3d0: stur            x0, [fp, #-0x60]
    // 0x92d3d4: ldur            x16, [fp, #-0x50]
    // 0x92d3d8: SaveReg r16
    //     0x92d3d8: str             x16, [SP, #-8]!
    // 0x92d3dc: r0 = free()
    //     0x92d3dc: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92d3e0: add             SP, SP, #8
    // 0x92d3e4: ldur            x16, [fp, #-0x58]
    // 0x92d3e8: SaveReg r16
    //     0x92d3e8: str             x16, [SP, #-8]!
    // 0x92d3ec: r0 = free()
    //     0x92d3ec: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92d3f0: add             SP, SP, #8
    // 0x92d3f4: ldur            x0, [fp, #-0x60]
    // 0x92d3f8: LeaveFrame
    //     0x92d3f8: mov             SP, fp
    //     0x92d3fc: ldp             fp, lr, [SP], #0x10
    // 0x92d400: ret
    //     0x92d400: ret             
    // 0x92d404: r0 = WindowsException()
    //     0x92d404: bl              #0x92d6e0  ; AllocateWindowsExceptionStub -> WindowsException (size=0x14)
    // 0x92d408: stur            x0, [fp, #-0x60]
    // 0x92d40c: r0 = GetLastError()
    //     0x92d40c: bl              #0x92d4c8  ; [package:win32/src/win32/kernel32.g.dart] ::GetLastError
    // 0x92d410: SaveReg r0
    //     0x92d410: str             x0, [SP, #-8]!
    // 0x92d414: r0 = HRESULT_FROM_WIN32()
    //     0x92d414: bl              #0x92d474  ; [package:win32/src/macros.dart] ::HRESULT_FROM_WIN32
    // 0x92d418: add             SP, SP, #8
    // 0x92d41c: ldur            x1, [fp, #-0x60]
    // 0x92d420: StoreField: r1->field_7 = r0
    //     0x92d420: stur            x0, [x1, #7]
    // 0x92d424: mov             x0, x1
    // 0x92d428: r0 = Throw()
    //     0x92d428: bl              #0xd67e38  ; ThrowStub
    // 0x92d42c: brk             #0
    // 0x92d430: sub             SP, fp, #0x60
    // 0x92d434: stur            x0, [fp, #-0x50]
    // 0x92d438: stur            x1, [fp, #-0x58]
    // 0x92d43c: ldur            x16, [fp, #-0x38]
    // 0x92d440: SaveReg r16
    //     0x92d440: str             x16, [SP, #-8]!
    // 0x92d444: r0 = free()
    //     0x92d444: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92d448: add             SP, SP, #8
    // 0x92d44c: ldur            x16, [fp, #-0x40]
    // 0x92d450: SaveReg r16
    //     0x92d450: str             x16, [SP, #-8]!
    // 0x92d454: r0 = free()
    //     0x92d454: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92d458: add             SP, SP, #8
    // 0x92d45c: ldur            x0, [fp, #-0x50]
    // 0x92d460: ldur            x1, [fp, #-0x58]
    // 0x92d464: r0 = ReThrow()
    //     0x92d464: bl              #0xd67e14  ; ReThrowStub
    // 0x92d468: brk             #0
    // 0x92d46c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92d46c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92d470: b               #0x92d368
  }
  _ getSystemMemoryInMegabytes(/* No info */) {
    // ** addr: 0x92e154, size: 0xfc
    // 0x92e154: EnterFrame
    //     0x92e154: stp             fp, lr, [SP, #-0x10]!
    //     0x92e158: mov             fp, SP
    // 0x92e15c: AllocStack(0x60)
    //     0x92e15c: sub             SP, SP, #0x60
    // 0x92e160: r0 = 8
    //     0x92e160: mov             x0, #8
    // 0x92e164: CheckStackOverflow
    //     0x92e164: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92e168: cmp             SP, x16
    //     0x92e16c: b.ls            #0x92e248
    // 0x92e170: r16 = <Uint64>
    //     0x92e170: add             x16, PP, #0x34, lsl #12  ; [pp+0x34008] TypeArguments: <Uint64>
    //     0x92e174: ldr             x16, [x16, #8]
    // 0x92e178: r30 = Instance__CallocAllocator
    //     0x92e178: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e17c: stp             lr, x16, [SP, #-0x10]!
    // 0x92e180: SaveReg r0
    //     0x92e180: str             x0, [SP, #-8]!
    // 0x92e184: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92e184: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92e188: r0 = allocate()
    //     0x92e188: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0x92e18c: add             SP, SP, #0x18
    // 0x92e190: stur            x0, [fp, #-0x50]
    // 0x92e194: SaveReg r0
    //     0x92e194: str             x0, [SP, #-8]!
    // 0x92e198: r0 = GetPhysicallyInstalledSystemMemory()
    //     0x92e198: bl              #0x92e250  ; [package:win32/src/win32/kernel32.g.dart] ::GetPhysicallyInstalledSystemMemory
    // 0x92e19c: add             SP, SP, #8
    // 0x92e1a0: cbz             x0, #0x92e1dc
    // 0x92e1a4: ldur            x0, [fp, #-0x50]
    // 0x92e1a8: r1 = 1024
    //     0x92e1a8: mov             x1, #0x400
    // 0x92e1ac: LoadField: r2 = r0->field_7
    //     0x92e1ac: ldur            x2, [x0, #7]
    // 0x92e1b0: ldr             x3, [x2]
    // 0x92e1b4: sdiv            x2, x3, x1
    // 0x92e1b8: stur            x2, [fp, #-0x58]
    // 0x92e1bc: r16 = Instance__CallocAllocator
    //     0x92e1bc: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e1c0: stp             x0, x16, [SP, #-0x10]!
    // 0x92e1c4: r0 = free()
    //     0x92e1c4: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0x92e1c8: add             SP, SP, #0x10
    // 0x92e1cc: ldur            x0, [fp, #-0x58]
    // 0x92e1d0: LeaveFrame
    //     0x92e1d0: mov             SP, fp
    //     0x92e1d4: ldp             fp, lr, [SP], #0x10
    // 0x92e1d8: ret
    //     0x92e1d8: ret             
    // 0x92e1dc: ldur            x0, [fp, #-0x50]
    // 0x92e1e0: r0 = GetLastError()
    //     0x92e1e0: bl              #0x92d4c8  ; [package:win32/src/win32/kernel32.g.dart] ::GetLastError
    // 0x92e1e4: stur            x0, [fp, #-0x58]
    // 0x92e1e8: r0 = WindowsException()
    //     0x92e1e8: bl              #0x92d6e0  ; AllocateWindowsExceptionStub -> WindowsException (size=0x14)
    // 0x92e1ec: mov             x1, x0
    // 0x92e1f0: ldur            x0, [fp, #-0x58]
    // 0x92e1f4: stur            x1, [fp, #-0x60]
    // 0x92e1f8: SaveReg r0
    //     0x92e1f8: str             x0, [SP, #-8]!
    // 0x92e1fc: r0 = HRESULT_FROM_WIN32()
    //     0x92e1fc: bl              #0x92d474  ; [package:win32/src/macros.dart] ::HRESULT_FROM_WIN32
    // 0x92e200: add             SP, SP, #8
    // 0x92e204: ldur            x1, [fp, #-0x60]
    // 0x92e208: StoreField: r1->field_7 = r0
    //     0x92e208: stur            x0, [x1, #7]
    // 0x92e20c: mov             x0, x1
    // 0x92e210: r0 = Throw()
    //     0x92e210: bl              #0xd67e38  ; ThrowStub
    // 0x92e214: brk             #0
    // 0x92e218: sub             SP, fp, #0x60
    // 0x92e21c: stur            x0, [fp, #-0x50]
    // 0x92e220: stur            x1, [fp, #-0x60]
    // 0x92e224: r16 = Instance__CallocAllocator
    //     0x92e224: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e228: ldur            lr, [fp, #-0x38]
    // 0x92e22c: stp             lr, x16, [SP, #-0x10]!
    // 0x92e230: r0 = free()
    //     0x92e230: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0x92e234: add             SP, SP, #0x10
    // 0x92e238: ldur            x0, [fp, #-0x50]
    // 0x92e23c: ldur            x1, [fp, #-0x60]
    // 0x92e240: r0 = ReThrow()
    //     0x92e240: bl              #0xd67e14  ; ReThrowStub
    // 0x92e244: brk             #0
    // 0x92e248: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92e248: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92e24c: b               #0x92e170
  }
  _ getComputerName(/* No info */) {
    // ** addr: 0x92e448, size: 0x190
    // 0x92e448: EnterFrame
    //     0x92e448: stp             fp, lr, [SP, #-0x10]!
    //     0x92e44c: mov             fp, SP
    // 0x92e450: AllocStack(0x60)
    //     0x92e450: sub             SP, SP, #0x60
    // 0x92e454: r0 = 4
    //     0x92e454: mov             x0, #4
    // 0x92e458: CheckStackOverflow
    //     0x92e458: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92e45c: cmp             SP, x16
    //     0x92e460: b.ls            #0x92e5d0
    // 0x92e464: r16 = <Uint32>
    //     0x92e464: add             x16, PP, #8, lsl #12  ; [pp+0x8340] TypeArguments: <Uint32>
    //     0x92e468: ldr             x16, [x16, #0x340]
    // 0x92e46c: r30 = Instance__CallocAllocator
    //     0x92e46c: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e470: stp             lr, x16, [SP, #-0x10]!
    // 0x92e474: SaveReg r0
    //     0x92e474: str             x0, [SP, #-8]!
    // 0x92e478: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92e478: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92e47c: r0 = allocate()
    //     0x92e47c: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0x92e480: add             SP, SP, #0x18
    // 0x92e484: stur            x0, [fp, #-0x50]
    // 0x92e488: r0 = InitLateStaticField(0x2d8) // [dart:ffi] ::nullptr
    //     0x92e488: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92e48c: ldr             x0, [x0, #0x5b0]
    //     0x92e490: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92e494: cmp             w0, w16
    //     0x92e498: b.ne            #0x92e4a4
    //     0x92e49c: ldr             x2, [PP, #0x63c8]  ; [pp+0x63c8] Field <::.nullptr>: static late final (offset: 0x2d8)
    //     0x92e4a0: bl              #0xd67cdc
    // 0x92e4a4: ldur            x16, [fp, #-0x50]
    // 0x92e4a8: stp             x16, x0, [SP, #-0x10]!
    // 0x92e4ac: r0 = GetComputerNameEx()
    //     0x92e4ac: bl              #0x92e5d8  ; [package:win32/src/win32/kernel32.g.dart] ::GetComputerNameEx
    // 0x92e4b0: add             SP, SP, #0x10
    // 0x92e4b4: ldur            x0, [fp, #-0x50]
    // 0x92e4b8: LoadField: r1 = r0->field_7
    //     0x92e4b8: ldur            x1, [x0, #7]
    // 0x92e4bc: ldr             w2, [x1]
    // 0x92e4c0: ubfx            x2, x2, #0, #0x20
    // 0x92e4c4: lsl             x1, x2, #1
    // 0x92e4c8: r16 = <Uint16>
    //     0x92e4c8: ldr             x16, [PP, #0x63c0]  ; [pp+0x63c0] TypeArguments: <Uint16>
    // 0x92e4cc: r30 = Instance__CallocAllocator
    //     0x92e4cc: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e4d0: stp             lr, x16, [SP, #-0x10]!
    // 0x92e4d4: SaveReg r1
    //     0x92e4d4: str             x1, [SP, #-8]!
    // 0x92e4d8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92e4d8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92e4dc: r0 = allocate()
    //     0x92e4dc: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0x92e4e0: add             SP, SP, #0x18
    // 0x92e4e4: r16 = <Utf16>
    //     0x92e4e4: add             x16, PP, #0xa, lsl #12  ; [pp+0xab70] TypeArguments: <Utf16>
    //     0x92e4e8: ldr             x16, [x16, #0xb70]
    // 0x92e4ec: stp             x0, x16, [SP, #-0x10]!
    // 0x92e4f0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92e4f0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92e4f4: r0 = cast()
    //     0x92e4f4: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92e4f8: add             SP, SP, #0x10
    // 0x92e4fc: stur            x0, [fp, #-0x58]
    // 0x92e500: ldur            x16, [fp, #-0x50]
    // 0x92e504: stp             x16, x0, [SP, #-0x10]!
    // 0x92e508: r0 = GetComputerNameEx()
    //     0x92e508: bl              #0x92e5d8  ; [package:win32/src/win32/kernel32.g.dart] ::GetComputerNameEx
    // 0x92e50c: add             SP, SP, #0x10
    // 0x92e510: cbz             x0, #0x92e560
    // 0x92e514: ldur            x16, [fp, #-0x58]
    // 0x92e518: SaveReg r16
    //     0x92e518: str             x16, [SP, #-8]!
    // 0x92e51c: r0 = Utf16Pointer.toDartString()
    //     0x92e51c: bl              #0x92d72c  ; [package:ffi/src/utf16.dart] ::Utf16Pointer.toDartString
    // 0x92e520: add             SP, SP, #8
    // 0x92e524: stur            x0, [fp, #-0x60]
    // 0x92e528: r16 = Instance__CallocAllocator
    //     0x92e528: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e52c: ldur            lr, [fp, #-0x58]
    // 0x92e530: stp             lr, x16, [SP, #-0x10]!
    // 0x92e534: r0 = free()
    //     0x92e534: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0x92e538: add             SP, SP, #0x10
    // 0x92e53c: r16 = Instance__CallocAllocator
    //     0x92e53c: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e540: ldur            lr, [fp, #-0x50]
    // 0x92e544: stp             lr, x16, [SP, #-0x10]!
    // 0x92e548: r0 = free()
    //     0x92e548: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0x92e54c: add             SP, SP, #0x10
    // 0x92e550: ldur            x0, [fp, #-0x60]
    // 0x92e554: LeaveFrame
    //     0x92e554: mov             SP, fp
    //     0x92e558: ldp             fp, lr, [SP], #0x10
    // 0x92e55c: ret
    //     0x92e55c: ret             
    // 0x92e560: r0 = WindowsException()
    //     0x92e560: bl              #0x92d6e0  ; AllocateWindowsExceptionStub -> WindowsException (size=0x14)
    // 0x92e564: stur            x0, [fp, #-0x60]
    // 0x92e568: r0 = GetLastError()
    //     0x92e568: bl              #0x92d4c8  ; [package:win32/src/win32/kernel32.g.dart] ::GetLastError
    // 0x92e56c: SaveReg r0
    //     0x92e56c: str             x0, [SP, #-8]!
    // 0x92e570: r0 = HRESULT_FROM_WIN32()
    //     0x92e570: bl              #0x92d474  ; [package:win32/src/macros.dart] ::HRESULT_FROM_WIN32
    // 0x92e574: add             SP, SP, #8
    // 0x92e578: ldur            x1, [fp, #-0x60]
    // 0x92e57c: StoreField: r1->field_7 = r0
    //     0x92e57c: stur            x0, [x1, #7]
    // 0x92e580: mov             x0, x1
    // 0x92e584: r0 = Throw()
    //     0x92e584: bl              #0xd67e38  ; ThrowStub
    // 0x92e588: brk             #0
    // 0x92e58c: sub             SP, fp, #0x60
    // 0x92e590: stur            x0, [fp, #-0x50]
    // 0x92e594: stur            x1, [fp, #-0x58]
    // 0x92e598: r16 = Instance__CallocAllocator
    //     0x92e598: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e59c: ldur            lr, [fp, #-0x40]
    // 0x92e5a0: stp             lr, x16, [SP, #-0x10]!
    // 0x92e5a4: r0 = free()
    //     0x92e5a4: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0x92e5a8: add             SP, SP, #0x10
    // 0x92e5ac: r16 = Instance__CallocAllocator
    //     0x92e5ac: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e5b0: ldur            lr, [fp, #-0x30]
    // 0x92e5b4: stp             lr, x16, [SP, #-0x10]!
    // 0x92e5b8: r0 = free()
    //     0x92e5b8: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0x92e5bc: add             SP, SP, #0x10
    // 0x92e5c0: ldur            x0, [fp, #-0x50]
    // 0x92e5c4: ldur            x1, [fp, #-0x58]
    // 0x92e5c8: r0 = ReThrow()
    //     0x92e5c8: bl              #0xd67e14  ; ReThrowStub
    // 0x92e5cc: brk             #0
    // 0x92e5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92e5d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92e5d4: b               #0x92e464
  }
  _ getRegistryValue(/* No info */) {
    // ** addr: 0x92e90c, size: 0x56c
    // 0x92e90c: EnterFrame
    //     0x92e90c: stp             fp, lr, [SP, #-0x10]!
    //     0x92e910: mov             fp, SP
    // 0x92e914: AllocStack(0x50)
    //     0x92e914: sub             SP, SP, #0x50
    // 0x92e918: CheckStackOverflow
    //     0x92e918: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92e91c: cmp             SP, x16
    //     0x92e920: b.ls            #0x92ee50
    // 0x92e924: ldr             x16, [fp, #0x20]
    // 0x92e928: SaveReg r16
    //     0x92e928: str             x16, [SP, #-8]!
    // 0x92e92c: r0 = StringUtf16Pointer.toNativeUtf16()
    //     0x92e92c: bl              #0x92f608  ; [package:ffi/src/utf16.dart] ::StringUtf16Pointer.toNativeUtf16
    // 0x92e930: add             SP, SP, #8
    // 0x92e934: stur            x0, [fp, #-8]
    // 0x92e938: ldr             x16, [fp, #0x18]
    // 0x92e93c: SaveReg r16
    //     0x92e93c: str             x16, [SP, #-8]!
    // 0x92e940: r0 = StringUtf16Pointer.toNativeUtf16()
    //     0x92e940: bl              #0x92f608  ; [package:ffi/src/utf16.dart] ::StringUtf16Pointer.toNativeUtf16
    // 0x92e944: add             SP, SP, #8
    // 0x92e948: stur            x0, [fp, #-0x10]
    // 0x92e94c: r16 = <IntPtr>
    //     0x92e94c: add             x16, PP, #8, lsl #12  ; [pp+0x8338] TypeArguments: <IntPtr>
    //     0x92e950: ldr             x16, [x16, #0x338]
    // 0x92e954: r30 = Instance__CallocAllocator
    //     0x92e954: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e958: stp             lr, x16, [SP, #-0x10]!
    // 0x92e95c: r1 = 8
    //     0x92e95c: mov             x1, #8
    // 0x92e960: SaveReg r1
    //     0x92e960: str             x1, [SP, #-8]!
    // 0x92e964: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92e964: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92e968: r0 = allocate()
    //     0x92e968: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0x92e96c: add             SP, SP, #0x18
    // 0x92e970: stur            x0, [fp, #-0x18]
    // 0x92e974: r16 = <Uint32>
    //     0x92e974: add             x16, PP, #8, lsl #12  ; [pp+0x8340] TypeArguments: <Uint32>
    //     0x92e978: ldr             x16, [x16, #0x340]
    // 0x92e97c: r30 = Instance__CallocAllocator
    //     0x92e97c: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e980: stp             lr, x16, [SP, #-0x10]!
    // 0x92e984: r1 = 4
    //     0x92e984: mov             x1, #4
    // 0x92e988: SaveReg r1
    //     0x92e988: str             x1, [SP, #-8]!
    // 0x92e98c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92e98c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92e990: r0 = allocate()
    //     0x92e990: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0x92e994: add             SP, SP, #0x18
    // 0x92e998: stur            x0, [fp, #-0x20]
    // 0x92e99c: r16 = <Uint8>
    //     0x92e99c: ldr             x16, [PP, #0x64e0]  ; [pp+0x64e0] TypeArguments: <Uint8>
    // 0x92e9a0: r30 = Instance__CallocAllocator
    //     0x92e9a0: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e9a4: stp             lr, x16, [SP, #-0x10]!
    // 0x92e9a8: r1 = 256
    //     0x92e9a8: mov             x1, #0x100
    // 0x92e9ac: SaveReg r1
    //     0x92e9ac: str             x1, [SP, #-8]!
    // 0x92e9b0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92e9b0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92e9b4: r0 = allocate()
    //     0x92e9b4: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0x92e9b8: add             SP, SP, #0x18
    // 0x92e9bc: stur            x0, [fp, #-0x28]
    // 0x92e9c0: r16 = <Uint32>
    //     0x92e9c0: add             x16, PP, #8, lsl #12  ; [pp+0x8340] TypeArguments: <Uint32>
    //     0x92e9c4: ldr             x16, [x16, #0x340]
    // 0x92e9c8: r30 = Instance__CallocAllocator
    //     0x92e9c8: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92e9cc: stp             lr, x16, [SP, #-0x10]!
    // 0x92e9d0: r1 = 4
    //     0x92e9d0: mov             x1, #4
    // 0x92e9d4: SaveReg r1
    //     0x92e9d4: str             x1, [SP, #-8]!
    // 0x92e9d8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92e9d8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92e9dc: r0 = allocate()
    //     0x92e9dc: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0x92e9e0: add             SP, SP, #0x18
    // 0x92e9e4: stur            x0, [fp, #-0x30]
    // 0x92e9e8: LoadField: r1 = r0->field_7
    //     0x92e9e8: ldur            x1, [x0, #7]
    // 0x92e9ec: r2 = 512
    //     0x92e9ec: mov             x2, #0x200
    // 0x92e9f0: str             w2, [x1]
    // 0x92e9f4: ldr             x1, [fp, #0x28]
    // 0x92e9f8: ldur            x16, [fp, #-8]
    // 0x92e9fc: stp             x16, x1, [SP, #-0x10]!
    // 0x92ea00: ldur            x16, [fp, #-0x18]
    // 0x92ea04: SaveReg r16
    //     0x92ea04: str             x16, [SP, #-8]!
    // 0x92ea08: r0 = RegOpenKeyEx()
    //     0x92ea08: bl              #0x92f34c  ; [package:win32/src/win32/advapi32.g.dart] ::RegOpenKeyEx
    // 0x92ea0c: add             SP, SP, #0x18
    // 0x92ea10: cbnz            x0, #0x92eda4
    // 0x92ea14: ldur            x0, [fp, #-0x18]
    // 0x92ea18: LoadField: r1 = r0->field_7
    //     0x92ea18: ldur            x1, [x0, #7]
    // 0x92ea1c: ldr             x2, [x1]
    // 0x92ea20: stur            x2, [fp, #-0x38]
    // 0x92ea24: r0 = InitLateStaticField(0x2d8) // [dart:ffi] ::nullptr
    //     0x92ea24: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92ea28: ldr             x0, [x0, #0x5b0]
    //     0x92ea2c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92ea30: cmp             w0, w16
    //     0x92ea34: b.ne            #0x92ea40
    //     0x92ea38: ldr             x2, [PP, #0x63c8]  ; [pp+0x63c8] Field <::.nullptr>: static late final (offset: 0x2d8)
    //     0x92ea3c: bl              #0xd67cdc
    // 0x92ea40: mov             x1, x0
    // 0x92ea44: ldur            x0, [fp, #-0x38]
    // 0x92ea48: ldur            x16, [fp, #-0x10]
    // 0x92ea4c: stp             x16, x0, [SP, #-0x10]!
    // 0x92ea50: ldur            x16, [fp, #-0x20]
    // 0x92ea54: stp             x16, x1, [SP, #-0x10]!
    // 0x92ea58: ldur            x16, [fp, #-0x28]
    // 0x92ea5c: ldur            lr, [fp, #-0x30]
    // 0x92ea60: stp             lr, x16, [SP, #-0x10]!
    // 0x92ea64: r0 = RegQueryValueEx()
    //     0x92ea64: bl              #0x92f09c  ; [package:win32/src/win32/advapi32.g.dart] ::RegQueryValueEx
    // 0x92ea68: add             SP, SP, #0x30
    // 0x92ea6c: cbnz            x0, #0x92ed28
    // 0x92ea70: ldur            x0, [fp, #-0x20]
    // 0x92ea74: LoadField: r1 = r0->field_7
    //     0x92ea74: ldur            x1, [x0, #7]
    // 0x92ea78: ldr             w2, [x1]
    // 0x92ea7c: ubfx            x2, x2, #0, #0x20
    // 0x92ea80: cmp             x2, #4
    // 0x92ea84: b.ne            #0x92eae8
    // 0x92ea88: r16 = <Uint32>
    //     0x92ea88: add             x16, PP, #8, lsl #12  ; [pp+0x8340] TypeArguments: <Uint32>
    //     0x92ea8c: ldr             x16, [x16, #0x340]
    // 0x92ea90: ldur            lr, [fp, #-0x28]
    // 0x92ea94: stp             lr, x16, [SP, #-0x10]!
    // 0x92ea98: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92ea98: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92ea9c: r0 = cast()
    //     0x92ea9c: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92eaa0: add             SP, SP, #0x10
    // 0x92eaa4: LoadField: r1 = r0->field_7
    //     0x92eaa4: ldur            x1, [x0, #7]
    // 0x92eaa8: ldr             w0, [x1]
    // 0x92eaac: lsl             w1, w0, #1
    // 0x92eab0: tst             x0, #0xc0000000
    // 0x92eab4: b.eq            #0x92eae4
    // 0x92eab8: r1 = inline_Allocate_Mint()
    //     0x92eab8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x92eabc: add             x1, x1, #0x10
    //     0x92eac0: cmp             x2, x1
    //     0x92eac4: b.ls            #0x92ee58
    //     0x92eac8: str             x1, [THR, #0x60]  ; THR::top
    //     0x92eacc: sub             x1, x1, #0xf
    //     0x92ead0: mov             x2, #0xc108
    //     0x92ead4: movk            x2, #3, lsl #16
    //     0x92ead8: stur            x2, [x1, #-1]
    // 0x92eadc: ubfx            x2, x0, #0, #0x20
    // 0x92eae0: StoreField: r1->field_7 = r2
    //     0x92eae0: stur            x2, [x1, #7]
    // 0x92eae4: b               #0x92eca8
    // 0x92eae8: LoadField: r1 = r0->field_7
    //     0x92eae8: ldur            x1, [x0, #7]
    // 0x92eaec: ldr             w2, [x1]
    // 0x92eaf0: ubfx            x2, x2, #0, #0x20
    // 0x92eaf4: cmp             x2, #0xb
    // 0x92eaf8: b.ne            #0x92eb38
    // 0x92eafc: r16 = <Uint64>
    //     0x92eafc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34008] TypeArguments: <Uint64>
    //     0x92eb00: ldr             x16, [x16, #8]
    // 0x92eb04: ldur            lr, [fp, #-0x28]
    // 0x92eb08: stp             lr, x16, [SP, #-0x10]!
    // 0x92eb0c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92eb0c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92eb10: r0 = cast()
    //     0x92eb10: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92eb14: add             SP, SP, #0x10
    // 0x92eb18: LoadField: r1 = r0->field_7
    //     0x92eb18: ldur            x1, [x0, #7]
    // 0x92eb1c: ldr             x2, [x1]
    // 0x92eb20: r0 = BoxInt64Instr(r2)
    //     0x92eb20: sbfiz           x0, x2, #1, #0x1f
    //     0x92eb24: cmp             x2, x0, asr #1
    //     0x92eb28: b.eq            #0x92eb34
    //     0x92eb2c: bl              #0xd69bb8
    //     0x92eb30: stur            x2, [x0, #7]
    // 0x92eb34: b               #0x92eca4
    // 0x92eb38: LoadField: r1 = r0->field_7
    //     0x92eb38: ldur            x1, [x0, #7]
    // 0x92eb3c: ldr             w2, [x1]
    // 0x92eb40: ubfx            x2, x2, #0, #0x20
    // 0x92eb44: cmp             x2, #1
    // 0x92eb48: b.ne            #0x92eb78
    // 0x92eb4c: r16 = <Utf16>
    //     0x92eb4c: add             x16, PP, #0xa, lsl #12  ; [pp+0xab70] TypeArguments: <Utf16>
    //     0x92eb50: ldr             x16, [x16, #0xb70]
    // 0x92eb54: ldur            lr, [fp, #-0x28]
    // 0x92eb58: stp             lr, x16, [SP, #-0x10]!
    // 0x92eb5c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92eb5c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92eb60: r0 = cast()
    //     0x92eb60: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92eb64: add             SP, SP, #0x10
    // 0x92eb68: SaveReg r0
    //     0x92eb68: str             x0, [SP, #-8]!
    // 0x92eb6c: r0 = Utf16Pointer.toDartString()
    //     0x92eb6c: bl              #0x92d72c  ; [package:ffi/src/utf16.dart] ::Utf16Pointer.toDartString
    // 0x92eb70: add             SP, SP, #8
    // 0x92eb74: b               #0x92eca4
    // 0x92eb78: LoadField: r1 = r0->field_7
    //     0x92eb78: ldur            x1, [x0, #7]
    // 0x92eb7c: ldr             w0, [x1]
    // 0x92eb80: ubfx            x0, x0, #0, #0x20
    // 0x92eb84: cmp             x0, #3
    // 0x92eb88: b.ne            #0x92ee20
    // 0x92eb8c: r16 = <int>
    //     0x92eb8c: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x92eb90: stp             xzr, x16, [SP, #-0x10]!
    // 0x92eb94: r0 = _GrowableList()
    //     0x92eb94: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x92eb98: add             SP, SP, #0x10
    // 0x92eb9c: stur            x0, [fp, #-0x20]
    // 0x92eba0: r3 = 0
    //     0x92eba0: mov             x3, #0
    // 0x92eba4: ldur            x2, [fp, #-0x28]
    // 0x92eba8: stur            x3, [fp, #-0x40]
    // 0x92ebac: CheckStackOverflow
    //     0x92ebac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92ebb0: cmp             SP, x16
    //     0x92ebb4: b.ls            #0x92ee6c
    // 0x92ebb8: cmp             x3, #0x100
    // 0x92ebbc: b.ge            #0x92ec94
    // 0x92ebc0: LoadField: r1 = r2->field_7
    //     0x92ebc0: ldur            x1, [x2, #7]
    // 0x92ebc4: mov             x4, x1
    // 0x92ebc8: stur            x4, [fp, #-0x38]
    // 0x92ebcc: r1 = <Never>
    //     0x92ebcc: ldr             x1, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    // 0x92ebd0: r0 = Pointer()
    //     0x92ebd0: bl              #0x4ba128  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x92ebd4: mov             x1, x0
    // 0x92ebd8: ldur            x0, [fp, #-0x38]
    // 0x92ebdc: StoreField: r1->field_7 = r0
    //     0x92ebdc: stur            x0, [x1, #7]
    // 0x92ebe0: LoadField: r0 = r1->field_7
    //     0x92ebe0: ldur            x0, [x1, #7]
    // 0x92ebe4: ldur            x2, [fp, #-0x40]
    // 0x92ebe8: add             x3, x0, x2
    // 0x92ebec: stur            x3, [fp, #-0x38]
    // 0x92ebf0: r1 = <Never>
    //     0x92ebf0: ldr             x1, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    // 0x92ebf4: r0 = Pointer()
    //     0x92ebf4: bl              #0x4ba128  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x92ebf8: mov             x1, x0
    // 0x92ebfc: ldur            x0, [fp, #-0x38]
    // 0x92ec00: StoreField: r1->field_7 = r0
    //     0x92ec00: stur            x0, [x1, #7]
    // 0x92ec04: LoadField: r0 = r1->field_7
    //     0x92ec04: ldur            x0, [x1, #7]
    // 0x92ec08: ldrb            w1, [x0]
    // 0x92ec0c: lsl             x0, x1, #1
    // 0x92ec10: ldur            x1, [fp, #-0x20]
    // 0x92ec14: stur            x0, [fp, #-0x50]
    // 0x92ec18: LoadField: r2 = r1->field_b
    //     0x92ec18: ldur            w2, [x1, #0xb]
    // 0x92ec1c: DecompressPointer r2
    //     0x92ec1c: add             x2, x2, HEAP, lsl #32
    // 0x92ec20: stur            x2, [fp, #-0x48]
    // 0x92ec24: LoadField: r3 = r1->field_f
    //     0x92ec24: ldur            w3, [x1, #0xf]
    // 0x92ec28: DecompressPointer r3
    //     0x92ec28: add             x3, x3, HEAP, lsl #32
    // 0x92ec2c: LoadField: r4 = r3->field_b
    //     0x92ec2c: ldur            w4, [x3, #0xb]
    // 0x92ec30: DecompressPointer r4
    //     0x92ec30: add             x4, x4, HEAP, lsl #32
    // 0x92ec34: cmp             w2, w4
    // 0x92ec38: b.ne            #0x92ec48
    // 0x92ec3c: SaveReg r1
    //     0x92ec3c: str             x1, [SP, #-8]!
    // 0x92ec40: r0 = _growToNextCapacity()
    //     0x92ec40: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x92ec44: add             SP, SP, #8
    // 0x92ec48: ldur            x4, [fp, #-0x20]
    // 0x92ec4c: ldur            x3, [fp, #-0x40]
    // 0x92ec50: ldur            x2, [fp, #-0x50]
    // 0x92ec54: ldur            x0, [fp, #-0x48]
    // 0x92ec58: r5 = LoadInt32Instr(r0)
    //     0x92ec58: sbfx            x5, x0, #1, #0x1f
    // 0x92ec5c: add             x0, x5, #1
    // 0x92ec60: lsl             x1, x0, #1
    // 0x92ec64: StoreField: r4->field_b = r1
    //     0x92ec64: stur            w1, [x4, #0xb]
    // 0x92ec68: mov             x1, x5
    // 0x92ec6c: cmp             x1, x0
    // 0x92ec70: b.hs            #0x92ee74
    // 0x92ec74: LoadField: r0 = r4->field_f
    //     0x92ec74: ldur            w0, [x4, #0xf]
    // 0x92ec78: DecompressPointer r0
    //     0x92ec78: add             x0, x0, HEAP, lsl #32
    // 0x92ec7c: ArrayStore: r0[r5] = r2  ; Unknown_4
    //     0x92ec7c: add             x1, x0, x5, lsl #2
    //     0x92ec80: stur            w2, [x1, #0xf]
    // 0x92ec84: add             x0, x3, #1
    // 0x92ec88: mov             x3, x0
    // 0x92ec8c: mov             x0, x4
    // 0x92ec90: b               #0x92eba4
    // 0x92ec94: mov             x4, x0
    // 0x92ec98: stp             x4, NULL, [SP, #-0x10]!
    // 0x92ec9c: r0 = Uint8List.fromList()
    //     0x92ec9c: bl              #0x540140  ; [dart:typed_data] Uint8List::Uint8List.fromList
    // 0x92eca0: add             SP, SP, #0x10
    // 0x92eca4: mov             x1, x0
    // 0x92eca8: ldur            x0, [fp, #-0x18]
    // 0x92ecac: stur            x1, [fp, #-0x20]
    // 0x92ecb0: ldur            x16, [fp, #-8]
    // 0x92ecb4: SaveReg r16
    //     0x92ecb4: str             x16, [SP, #-8]!
    // 0x92ecb8: r0 = free()
    //     0x92ecb8: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92ecbc: add             SP, SP, #8
    // 0x92ecc0: ldur            x16, [fp, #-0x10]
    // 0x92ecc4: SaveReg r16
    //     0x92ecc4: str             x16, [SP, #-8]!
    // 0x92ecc8: r0 = free()
    //     0x92ecc8: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92eccc: add             SP, SP, #8
    // 0x92ecd0: ldur            x16, [fp, #-0x18]
    // 0x92ecd4: SaveReg r16
    //     0x92ecd4: str             x16, [SP, #-8]!
    // 0x92ecd8: r0 = free()
    //     0x92ecd8: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92ecdc: add             SP, SP, #8
    // 0x92ece0: ldur            x16, [fp, #-0x28]
    // 0x92ece4: SaveReg r16
    //     0x92ece4: str             x16, [SP, #-8]!
    // 0x92ece8: r0 = free()
    //     0x92ece8: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92ecec: add             SP, SP, #8
    // 0x92ecf0: ldur            x16, [fp, #-0x30]
    // 0x92ecf4: SaveReg r16
    //     0x92ecf4: str             x16, [SP, #-8]!
    // 0x92ecf8: r0 = free()
    //     0x92ecf8: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92ecfc: add             SP, SP, #8
    // 0x92ed00: ldur            x0, [fp, #-0x18]
    // 0x92ed04: LoadField: r1 = r0->field_7
    //     0x92ed04: ldur            x1, [x0, #7]
    // 0x92ed08: ldr             x0, [x1]
    // 0x92ed0c: SaveReg r0
    //     0x92ed0c: str             x0, [SP, #-8]!
    // 0x92ed10: r0 = RegCloseKey()
    //     0x92ed10: bl              #0x92ee78  ; [package:win32/src/win32/advapi32.g.dart] ::RegCloseKey
    // 0x92ed14: add             SP, SP, #8
    // 0x92ed18: ldur            x0, [fp, #-0x20]
    // 0x92ed1c: LeaveFrame
    //     0x92ed1c: mov             SP, fp
    //     0x92ed20: ldp             fp, lr, [SP], #0x10
    // 0x92ed24: ret
    //     0x92ed24: ret             
    // 0x92ed28: ldur            x0, [fp, #-0x18]
    // 0x92ed2c: ldur            x16, [fp, #-8]
    // 0x92ed30: SaveReg r16
    //     0x92ed30: str             x16, [SP, #-8]!
    // 0x92ed34: r0 = free()
    //     0x92ed34: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92ed38: add             SP, SP, #8
    // 0x92ed3c: ldur            x16, [fp, #-0x10]
    // 0x92ed40: SaveReg r16
    //     0x92ed40: str             x16, [SP, #-8]!
    // 0x92ed44: r0 = free()
    //     0x92ed44: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92ed48: add             SP, SP, #8
    // 0x92ed4c: ldur            x16, [fp, #-0x18]
    // 0x92ed50: SaveReg r16
    //     0x92ed50: str             x16, [SP, #-8]!
    // 0x92ed54: r0 = free()
    //     0x92ed54: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92ed58: add             SP, SP, #8
    // 0x92ed5c: ldur            x16, [fp, #-0x28]
    // 0x92ed60: SaveReg r16
    //     0x92ed60: str             x16, [SP, #-8]!
    // 0x92ed64: r0 = free()
    //     0x92ed64: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92ed68: add             SP, SP, #8
    // 0x92ed6c: ldur            x16, [fp, #-0x30]
    // 0x92ed70: SaveReg r16
    //     0x92ed70: str             x16, [SP, #-8]!
    // 0x92ed74: r0 = free()
    //     0x92ed74: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92ed78: add             SP, SP, #8
    // 0x92ed7c: ldur            x0, [fp, #-0x18]
    // 0x92ed80: LoadField: r1 = r0->field_7
    //     0x92ed80: ldur            x1, [x0, #7]
    // 0x92ed84: ldr             x0, [x1]
    // 0x92ed88: SaveReg r0
    //     0x92ed88: str             x0, [SP, #-8]!
    // 0x92ed8c: r0 = RegCloseKey()
    //     0x92ed8c: bl              #0x92ee78  ; [package:win32/src/win32/advapi32.g.dart] ::RegCloseKey
    // 0x92ed90: add             SP, SP, #8
    // 0x92ed94: ldr             x0, [fp, #0x10]
    // 0x92ed98: LeaveFrame
    //     0x92ed98: mov             SP, fp
    //     0x92ed9c: ldp             fp, lr, [SP], #0x10
    // 0x92eda0: ret
    //     0x92eda0: ret             
    // 0x92eda4: ldur            x0, [fp, #-0x18]
    // 0x92eda8: ldur            x16, [fp, #-8]
    // 0x92edac: SaveReg r16
    //     0x92edac: str             x16, [SP, #-8]!
    // 0x92edb0: r0 = free()
    //     0x92edb0: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92edb4: add             SP, SP, #8
    // 0x92edb8: ldur            x16, [fp, #-0x10]
    // 0x92edbc: SaveReg r16
    //     0x92edbc: str             x16, [SP, #-8]!
    // 0x92edc0: r0 = free()
    //     0x92edc0: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92edc4: add             SP, SP, #8
    // 0x92edc8: ldur            x16, [fp, #-0x18]
    // 0x92edcc: SaveReg r16
    //     0x92edcc: str             x16, [SP, #-8]!
    // 0x92edd0: r0 = free()
    //     0x92edd0: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92edd4: add             SP, SP, #8
    // 0x92edd8: ldur            x16, [fp, #-0x28]
    // 0x92eddc: SaveReg r16
    //     0x92eddc: str             x16, [SP, #-8]!
    // 0x92ede0: r0 = free()
    //     0x92ede0: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92ede4: add             SP, SP, #8
    // 0x92ede8: ldur            x16, [fp, #-0x30]
    // 0x92edec: SaveReg r16
    //     0x92edec: str             x16, [SP, #-8]!
    // 0x92edf0: r0 = free()
    //     0x92edf0: bl              #0x92d6ec  ; [package:win32/src/utils.dart] ::free
    // 0x92edf4: add             SP, SP, #8
    // 0x92edf8: ldur            x0, [fp, #-0x18]
    // 0x92edfc: LoadField: r1 = r0->field_7
    //     0x92edfc: ldur            x1, [x0, #7]
    // 0x92ee00: ldr             x0, [x1]
    // 0x92ee04: SaveReg r0
    //     0x92ee04: str             x0, [SP, #-8]!
    // 0x92ee08: r0 = RegCloseKey()
    //     0x92ee08: bl              #0x92ee78  ; [package:win32/src/win32/advapi32.g.dart] ::RegCloseKey
    // 0x92ee0c: add             SP, SP, #8
    // 0x92ee10: ldr             x0, [fp, #0x10]
    // 0x92ee14: LeaveFrame
    //     0x92ee14: mov             SP, fp
    //     0x92ee18: ldp             fp, lr, [SP], #0x10
    // 0x92ee1c: ret
    //     0x92ee1c: ret             
    // 0x92ee20: r0 = 13
    //     0x92ee20: mov             x0, #0xd
    // 0x92ee24: SaveReg r0
    //     0x92ee24: str             x0, [SP, #-8]!
    // 0x92ee28: r0 = HRESULT_FROM_WIN32()
    //     0x92ee28: bl              #0x92d474  ; [package:win32/src/macros.dart] ::HRESULT_FROM_WIN32
    // 0x92ee2c: add             SP, SP, #8
    // 0x92ee30: stur            x0, [fp, #-0x38]
    // 0x92ee34: r0 = WindowsException()
    //     0x92ee34: bl              #0x92d6e0  ; AllocateWindowsExceptionStub -> WindowsException (size=0x14)
    // 0x92ee38: mov             x1, x0
    // 0x92ee3c: ldur            x0, [fp, #-0x38]
    // 0x92ee40: StoreField: r1->field_7 = r0
    //     0x92ee40: stur            x0, [x1, #7]
    // 0x92ee44: mov             x0, x1
    // 0x92ee48: r0 = Throw()
    //     0x92ee48: bl              #0xd67e38  ; ThrowStub
    // 0x92ee4c: brk             #0
    // 0x92ee50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92ee50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92ee54: b               #0x92e924
    // 0x92ee58: SaveReg r0
    //     0x92ee58: str             x0, [SP, #-8]!
    // 0x92ee5c: r0 = AllocateMint()
    //     0x92ee5c: bl              #0xd69828  ; AllocateMintStub
    // 0x92ee60: mov             x1, x0
    // 0x92ee64: RestoreReg r0
    //     0x92ee64: ldr             x0, [SP], #8
    // 0x92ee68: b               #0x92eadc
    // 0x92ee6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92ee6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92ee70: b               #0x92ebb8
    // 0x92ee74: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x92ee74: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getOSVERSIONINFOEXPointer(/* No info */) {
    // ** addr: 0x92fa80, size: 0xcc
    // 0x92fa80: EnterFrame
    //     0x92fa80: stp             fp, lr, [SP, #-0x10]!
    //     0x92fa84: mov             fp, SP
    // 0x92fa88: AllocStack(0x8)
    //     0x92fa88: sub             SP, SP, #8
    // 0x92fa8c: r0 = 284
    //     0x92fa8c: mov             x0, #0x11c
    // 0x92fa90: CheckStackOverflow
    //     0x92fa90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92fa94: cmp             SP, x16
    //     0x92fa98: b.ls            #0x92fb44
    // 0x92fa9c: r16 = <OSVERSIONINFOEX>
    //     0x92fa9c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34108] TypeArguments: <OSVERSIONINFOEX>
    //     0x92faa0: ldr             x16, [x16, #0x108]
    // 0x92faa4: r30 = Instance__CallocAllocator
    //     0x92faa4: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92faa8: stp             lr, x16, [SP, #-0x10]!
    // 0x92faac: SaveReg r0
    //     0x92faac: str             x0, [SP, #-8]!
    // 0x92fab0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92fab0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92fab4: r0 = allocate()
    //     0x92fab4: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0x92fab8: add             SP, SP, #0x18
    // 0x92fabc: stur            x0, [fp, #-8]
    // 0x92fac0: r0 = OSVERSIONINFOEX()
    //     0x92fac0: bl              #0x92d340  ; AllocateOSVERSIONINFOEXStub -> OSVERSIONINFOEX (size=0xc)
    // 0x92fac4: mov             x1, x0
    // 0x92fac8: ldur            x0, [fp, #-8]
    // 0x92facc: StoreField: r1->field_7 = r0
    //     0x92facc: stur            w0, [x1, #7]
    // 0x92fad0: LoadField: r2 = r0->field_7
    //     0x92fad0: ldur            x2, [x0, #7]
    // 0x92fad4: r3 = 284
    //     0x92fad4: mov             x3, #0x11c
    // 0x92fad8: str             w3, [x2]
    // 0x92fadc: LoadField: r2 = r0->field_7
    //     0x92fadc: ldur            x2, [x0, #7]
    // 0x92fae0: str             wzr, [x2, #0xc]
    // 0x92fae4: LoadField: r2 = r0->field_7
    //     0x92fae4: ldur            x2, [x0, #7]
    // 0x92fae8: str             wzr, [x2, #4]
    // 0x92faec: LoadField: r2 = r0->field_7
    //     0x92faec: ldur            x2, [x0, #7]
    // 0x92faf0: str             wzr, [x2, #8]
    // 0x92faf4: LoadField: r2 = r0->field_7
    //     0x92faf4: ldur            x2, [x0, #7]
    // 0x92faf8: str             wzr, [x2, #0x10]
    // 0x92fafc: r16 = ""
    //     0x92fafc: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x92fb00: stp             x16, x1, [SP, #-0x10]!
    // 0x92fb04: r0 = szCSDVersion=()
    //     0x92fb04: bl              #0x92fb4c  ; [package:win32/src/structs.g.dart] OSVERSIONINFOEX::szCSDVersion=
    // 0x92fb08: add             SP, SP, #0x10
    // 0x92fb0c: ldur            x0, [fp, #-8]
    // 0x92fb10: LoadField: r1 = r0->field_7
    //     0x92fb10: ldur            x1, [x0, #7]
    // 0x92fb14: strh            wzr, [x1, #0x114]
    // 0x92fb18: LoadField: r1 = r0->field_7
    //     0x92fb18: ldur            x1, [x0, #7]
    // 0x92fb1c: strh            wzr, [x1, #0x116]
    // 0x92fb20: LoadField: r1 = r0->field_7
    //     0x92fb20: ldur            x1, [x0, #7]
    // 0x92fb24: strh            wzr, [x1, #0x118]
    // 0x92fb28: LoadField: r1 = r0->field_7
    //     0x92fb28: ldur            x1, [x0, #7]
    // 0x92fb2c: ArrayStore: r1[259] = rZR  ; TypeUnknown_1
    //     0x92fb2c: strb            wzr, [x1, #0x11a]
    // 0x92fb30: LoadField: r1 = r0->field_7
    //     0x92fb30: ldur            x1, [x0, #7]
    // 0x92fb34: ArrayStore: r1[260] = rZR  ; TypeUnknown_1
    //     0x92fb34: strb            wzr, [x1, #0x11b]
    // 0x92fb38: LeaveFrame
    //     0x92fb38: mov             SP, fp
    //     0x92fb3c: ldp             fp, lr, [SP], #0x10
    // 0x92fb40: ret
    //     0x92fb40: ret             
    // 0x92fb44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92fb44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92fb48: b               #0x92fa9c
  }
  _ getSYSTEMINFOPointer(/* No info */) {
    // ** addr: 0x92fd04, size: 0xfc
    // 0x92fd04: EnterFrame
    //     0x92fd04: stp             fp, lr, [SP, #-0x10]!
    //     0x92fd08: mov             fp, SP
    // 0x92fd0c: AllocStack(0x10)
    //     0x92fd0c: sub             SP, SP, #0x10
    // 0x92fd10: r0 = 48
    //     0x92fd10: mov             x0, #0x30
    // 0x92fd14: CheckStackOverflow
    //     0x92fd14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92fd18: cmp             SP, x16
    //     0x92fd1c: b.ls            #0x92fdf8
    // 0x92fd20: r16 = <SYSTEM_INFO>
    //     0x92fd20: add             x16, PP, #0x34, lsl #12  ; [pp+0x34110] TypeArguments: <SYSTEM_INFO>
    //     0x92fd24: ldr             x16, [x16, #0x110]
    // 0x92fd28: r30 = Instance__CallocAllocator
    //     0x92fd28: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0x92fd2c: stp             lr, x16, [SP, #-0x10]!
    // 0x92fd30: SaveReg r0
    //     0x92fd30: str             x0, [SP, #-8]!
    // 0x92fd34: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92fd34: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92fd38: r0 = allocate()
    //     0x92fd38: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0x92fd3c: add             SP, SP, #0x18
    // 0x92fd40: stur            x0, [fp, #-8]
    // 0x92fd44: r0 = SYSTEM_INFO()
    //     0x92fd44: bl              #0x92ffc8  ; AllocateSYSTEM_INFOStub -> SYSTEM_INFO (size=0xc)
    // 0x92fd48: mov             x1, x0
    // 0x92fd4c: ldur            x0, [fp, #-8]
    // 0x92fd50: stur            x1, [fp, #-0x10]
    // 0x92fd54: StoreField: r1->field_7 = r0
    //     0x92fd54: stur            w0, [x1, #7]
    // 0x92fd58: SaveReg r1
    //     0x92fd58: str             x1, [SP, #-8]!
    // 0x92fd5c: r0 = SYSTEM_INFO__Anonymous_e__Union_Extension.wProcessorArchitecture=()
    //     0x92fd5c: bl              #0x92ff70  ; [package:win32/src/structs.g.dart] ::SYSTEM_INFO__Anonymous_e__Union_Extension.wProcessorArchitecture=
    // 0x92fd60: add             SP, SP, #8
    // 0x92fd64: ldur            x16, [fp, #-0x10]
    // 0x92fd68: SaveReg r16
    //     0x92fd68: str             x16, [SP, #-8]!
    // 0x92fd6c: r0 = SYSTEM_INFO__Anonymous_e__Union_Extension.wReserved=()
    //     0x92fd6c: bl              #0x92fe00  ; [package:win32/src/structs.g.dart] ::SYSTEM_INFO__Anonymous_e__Union_Extension.wReserved=
    // 0x92fd70: add             SP, SP, #8
    // 0x92fd74: ldur            x0, [fp, #-8]
    // 0x92fd78: LoadField: r1 = r0->field_7
    //     0x92fd78: ldur            x1, [x0, #7]
    // 0x92fd7c: str             wzr, [x1, #4]
    // 0x92fd80: r0 = InitLateStaticField(0x2d8) // [dart:ffi] ::nullptr
    //     0x92fd80: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92fd84: ldr             x0, [x0, #0x5b0]
    //     0x92fd88: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92fd8c: cmp             w0, w16
    //     0x92fd90: b.ne            #0x92fd9c
    //     0x92fd94: ldr             x2, [PP, #0x63c8]  ; [pp+0x63c8] Field <::.nullptr>: static late final (offset: 0x2d8)
    //     0x92fd98: bl              #0xd67cdc
    // 0x92fd9c: LoadField: r1 = r0->field_7
    //     0x92fd9c: ldur            x1, [x0, #7]
    // 0x92fda0: ldur            x2, [fp, #-8]
    // 0x92fda4: LoadField: r3 = r2->field_7
    //     0x92fda4: ldur            x3, [x2, #7]
    // 0x92fda8: str             x1, [x3, #0x10]
    // 0x92fdac: LoadField: r1 = r0->field_7
    //     0x92fdac: ldur            x1, [x0, #7]
    // 0x92fdb0: LoadField: r3 = r2->field_7
    //     0x92fdb0: ldur            x3, [x2, #7]
    // 0x92fdb4: str             x1, [x3, #0x10]
    // 0x92fdb8: LoadField: r1 = r2->field_7
    //     0x92fdb8: ldur            x1, [x2, #7]
    // 0x92fdbc: str             xzr, [x1, #0x18]
    // 0x92fdc0: LoadField: r1 = r2->field_7
    //     0x92fdc0: ldur            x1, [x2, #7]
    // 0x92fdc4: str             wzr, [x1, #0x20]
    // 0x92fdc8: LoadField: r1 = r2->field_7
    //     0x92fdc8: ldur            x1, [x2, #7]
    // 0x92fdcc: str             wzr, [x1, #0x24]
    // 0x92fdd0: LoadField: r1 = r2->field_7
    //     0x92fdd0: ldur            x1, [x2, #7]
    // 0x92fdd4: str             wzr, [x1, #0x28]
    // 0x92fdd8: LoadField: r1 = r2->field_7
    //     0x92fdd8: ldur            x1, [x2, #7]
    // 0x92fddc: strh            wzr, [x1, #0x2c]
    // 0x92fde0: LoadField: r1 = r2->field_7
    //     0x92fde0: ldur            x1, [x2, #7]
    // 0x92fde4: strh            wzr, [x1, #0x2e]
    // 0x92fde8: mov             x0, x2
    // 0x92fdec: LeaveFrame
    //     0x92fdec: mov             SP, fp
    //     0x92fdf0: ldp             fp, lr, [SP], #0x10
    // 0x92fdf4: ret
    //     0x92fdf4: ret             
    // 0x92fdf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92fdf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92fdfc: b               #0x92fd20
  }
  _ deviceInfo(/* No info */) {
    // ** addr: 0xc56788, size: 0xd8
    // 0xc56788: EnterFrame
    //     0xc56788: stp             fp, lr, [SP, #-0x10]!
    //     0xc5678c: mov             fp, SP
    // 0xc56790: AllocStack(0x10)
    //     0xc56790: sub             SP, SP, #0x10
    // 0xc56794: CheckStackOverflow
    //     0xc56794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc56798: cmp             SP, x16
    //     0xc5679c: b.ls            #0xc56858
    // 0xc567a0: ldr             x0, [fp, #0x10]
    // 0xc567a4: LoadField: r1 = r0->field_7
    //     0xc567a4: ldur            w1, [x0, #7]
    // 0xc567a8: DecompressPointer r1
    //     0xc567a8: add             x1, x1, HEAP, lsl #32
    // 0xc567ac: cmp             w1, NULL
    // 0xc567b0: b.ne            #0xc567ec
    // 0xc567b4: SaveReg r0
    //     0xc567b4: str             x0, [SP, #-8]!
    // 0xc567b8: r0 = getInfo()
    //     0xc567b8: bl              #0x92c424  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::getInfo
    // 0xc567bc: add             SP, SP, #8
    // 0xc567c0: mov             x2, x0
    // 0xc567c4: ldr             x1, [fp, #0x10]
    // 0xc567c8: StoreField: r1->field_7 = r0
    //     0xc567c8: stur            w0, [x1, #7]
    //     0xc567cc: ldurb           w16, [x1, #-1]
    //     0xc567d0: ldurb           w17, [x0, #-1]
    //     0xc567d4: and             x16, x17, x16, lsr #2
    //     0xc567d8: tst             x16, HEAP, lsr #32
    //     0xc567dc: b.eq            #0xc567e4
    //     0xc567e0: bl              #0xd6826c
    // 0xc567e4: mov             x0, x2
    // 0xc567e8: b               #0xc567f0
    // 0xc567ec: mov             x0, x1
    // 0xc567f0: stur            x0, [fp, #-8]
    // 0xc567f4: r1 = <BaseDeviceInfo>
    //     0xc567f4: add             x1, PP, #0x33, lsl #12  ; [pp+0x33c20] TypeArguments: <BaseDeviceInfo>
    //     0xc567f8: ldr             x1, [x1, #0xc20]
    // 0xc567fc: r0 = _Future()
    //     0xc567fc: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xc56800: mov             x1, x0
    // 0xc56804: r0 = 0
    //     0xc56804: mov             x0, #0
    // 0xc56808: stur            x1, [fp, #-0x10]
    // 0xc5680c: StoreField: r1->field_b = r0
    //     0xc5680c: stur            x0, [x1, #0xb]
    // 0xc56810: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc56810: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc56814: ldr             x0, [x0, #0xb58]
    //     0xc56818: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc5681c: cmp             w0, w16
    //     0xc56820: b.ne            #0xc5682c
    //     0xc56824: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc56828: bl              #0xd67d44
    // 0xc5682c: mov             x1, x0
    // 0xc56830: ldur            x0, [fp, #-0x10]
    // 0xc56834: StoreField: r0->field_13 = r1
    //     0xc56834: stur            w1, [x0, #0x13]
    // 0xc56838: ldur            x16, [fp, #-8]
    // 0xc5683c: stp             x16, x0, [SP, #-0x10]!
    // 0xc56840: r0 = _asyncComplete()
    //     0xc56840: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0xc56844: add             SP, SP, #0x10
    // 0xc56848: ldur            x0, [fp, #-0x10]
    // 0xc5684c: LeaveFrame
    //     0xc5684c: mov             SP, fp
    //     0xc56850: ldp             fp, lr, [SP], #0x10
    // 0xc56854: ret
    //     0xc56854: ret             
    // 0xc56858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56858: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5685c: b               #0xc567a0
  }
  static void registerWith() {
    // ** addr: 0xd6da54, size: 0xa0
    // 0xd6da54: EnterFrame
    //     0xd6da54: stp             fp, lr, [SP, #-0x10]!
    //     0xd6da58: mov             fp, SP
    // 0xd6da5c: AllocStack(0x18)
    //     0xd6da5c: sub             SP, SP, #0x18
    // 0xd6da60: CheckStackOverflow
    //     0xd6da60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6da64: cmp             SP, x16
    //     0xd6da68: b.ls            #0xd6daec
    // 0xd6da6c: r0 = InitLateStaticField(0xb38) // [package:device_info_plus_platform_interface/device_info_plus_platform_interface.dart] DeviceInfoPlatform::_token
    //     0xd6da6c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6da70: ldr             x0, [x0, #0x1670]
    //     0xd6da74: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6da78: cmp             w0, w16
    //     0xd6da7c: b.ne            #0xd6da88
    //     0xd6da80: ldr             x2, [PP, #0x240]  ; [pp+0x240] Field <DeviceInfoPlatform._token@337502559>: static late final (offset: 0xb38)
    //     0xd6da84: bl              #0xd67cdc
    // 0xd6da88: stur            x0, [fp, #-8]
    // 0xd6da8c: r0 = InitLateStaticField(0xa64) // [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::_instanceTokens
    //     0xd6da8c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6da90: ldr             x0, [x0, #0x14c8]
    //     0xd6da94: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6da98: cmp             w0, w16
    //     0xd6da9c: b.ne            #0xd6daa8
    //     0xd6daa0: ldr             x2, [PP, #0x170]  ; [pp+0x170] Field <PlatformInterface._instanceTokens@187304592>: static late final (offset: 0xa64)
    //     0xd6daa4: bl              #0xd67cdc
    // 0xd6daa8: stur            x0, [fp, #-0x10]
    // 0xd6daac: r0 = DeviceInfoPlusWindowsPlugin()
    //     0xd6daac: bl              #0xd6db58  ; AllocateDeviceInfoPlusWindowsPluginStub -> DeviceInfoPlusWindowsPlugin (size=0x10)
    // 0xd6dab0: stur            x0, [fp, #-0x18]
    // 0xd6dab4: ldur            x16, [fp, #-0x10]
    // 0xd6dab8: stp             x0, x16, [SP, #-0x10]!
    // 0xd6dabc: ldur            x16, [fp, #-8]
    // 0xd6dac0: SaveReg r16
    //     0xd6dac0: str             x16, [SP, #-8]!
    // 0xd6dac4: r0 = []=()
    //     0xd6dac4: bl              #0x4b97f8  ; [dart:core] Expando::[]=
    // 0xd6dac8: add             SP, SP, #0x18
    // 0xd6dacc: ldur            x16, [fp, #-0x18]
    // 0xd6dad0: SaveReg r16
    //     0xd6dad0: str             x16, [SP, #-8]!
    // 0xd6dad4: r0 = instance=()
    //     0xd6dad4: bl              #0xd6daf4  ; [package:device_info_plus_platform_interface/device_info_plus_platform_interface.dart] DeviceInfoPlatform::instance=
    // 0xd6dad8: add             SP, SP, #8
    // 0xd6dadc: r0 = Null
    //     0xd6dadc: mov             x0, NULL
    // 0xd6dae0: LeaveFrame
    //     0xd6dae0: mov             SP, fp
    //     0xd6dae4: ldp             fp, lr, [SP], #0x10
    // 0xd6dae8: ret
    //     0xd6dae8: ret             
    // 0xd6daec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6daec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6daf0: b               #0xd6da6c
  }
}

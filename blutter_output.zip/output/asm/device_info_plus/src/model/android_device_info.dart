// lib: , url: package:device_info_plus/src/model/android_device_info.dart

// class id: 1048869, size: 0x8
class :: {
}

// class id: 4556, size: 0x8, field offset: 0x8
//   const constructor, 
class AndroidDisplayMetrics extends Object {

  static _ _fromMap(/* No info */) {
    // ** addr: 0x92bf1c, size: 0x190
    // 0x92bf1c: EnterFrame
    //     0x92bf1c: stp             fp, lr, [SP, #-0x10]!
    //     0x92bf20: mov             fp, SP
    // 0x92bf24: CheckStackOverflow
    //     0x92bf24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92bf28: cmp             SP, x16
    //     0x92bf2c: b.ls            #0x92c0a4
    // 0x92bf30: ldr             x1, [fp, #0x10]
    // 0x92bf34: r0 = LoadClassIdInstr(r1)
    //     0x92bf34: ldur            x0, [x1, #-1]
    //     0x92bf38: ubfx            x0, x0, #0xc, #0x14
    // 0x92bf3c: r16 = "widthPx"
    //     0x92bf3c: add             x16, PP, #0x33, lsl #12  ; [pp+0x33db8] "widthPx"
    //     0x92bf40: ldr             x16, [x16, #0xdb8]
    // 0x92bf44: stp             x16, x1, [SP, #-0x10]!
    // 0x92bf48: r0 = GDT[cid_x0 + -0xef]()
    //     0x92bf48: sub             lr, x0, #0xef
    //     0x92bf4c: ldr             lr, [x21, lr, lsl #3]
    //     0x92bf50: blr             lr
    // 0x92bf54: add             SP, SP, #0x10
    // 0x92bf58: r2 = Null
    //     0x92bf58: mov             x2, NULL
    // 0x92bf5c: r1 = Null
    //     0x92bf5c: mov             x1, NULL
    // 0x92bf60: r4 = 59
    //     0x92bf60: mov             x4, #0x3b
    // 0x92bf64: branchIfSmi(r0, 0x92bf70)
    //     0x92bf64: tbz             w0, #0, #0x92bf70
    // 0x92bf68: r4 = LoadClassIdInstr(r0)
    //     0x92bf68: ldur            x4, [x0, #-1]
    //     0x92bf6c: ubfx            x4, x4, #0xc, #0x14
    // 0x92bf70: cmp             x4, #0x3d
    // 0x92bf74: b.eq            #0x92bf88
    // 0x92bf78: r8 = double
    //     0x92bf78: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x92bf7c: r3 = Null
    //     0x92bf7c: add             x3, PP, #0x33, lsl #12  ; [pp+0x33dc0] Null
    //     0x92bf80: ldr             x3, [x3, #0xdc0]
    // 0x92bf84: r0 = double()
    //     0x92bf84: bl              #0xd72bac  ; IsType_double_Stub
    // 0x92bf88: ldr             x1, [fp, #0x10]
    // 0x92bf8c: r0 = LoadClassIdInstr(r1)
    //     0x92bf8c: ldur            x0, [x1, #-1]
    //     0x92bf90: ubfx            x0, x0, #0xc, #0x14
    // 0x92bf94: r16 = "heightPx"
    //     0x92bf94: add             x16, PP, #0x33, lsl #12  ; [pp+0x33dd0] "heightPx"
    //     0x92bf98: ldr             x16, [x16, #0xdd0]
    // 0x92bf9c: stp             x16, x1, [SP, #-0x10]!
    // 0x92bfa0: r0 = GDT[cid_x0 + -0xef]()
    //     0x92bfa0: sub             lr, x0, #0xef
    //     0x92bfa4: ldr             lr, [x21, lr, lsl #3]
    //     0x92bfa8: blr             lr
    // 0x92bfac: add             SP, SP, #0x10
    // 0x92bfb0: r2 = Null
    //     0x92bfb0: mov             x2, NULL
    // 0x92bfb4: r1 = Null
    //     0x92bfb4: mov             x1, NULL
    // 0x92bfb8: r4 = 59
    //     0x92bfb8: mov             x4, #0x3b
    // 0x92bfbc: branchIfSmi(r0, 0x92bfc8)
    //     0x92bfbc: tbz             w0, #0, #0x92bfc8
    // 0x92bfc0: r4 = LoadClassIdInstr(r0)
    //     0x92bfc0: ldur            x4, [x0, #-1]
    //     0x92bfc4: ubfx            x4, x4, #0xc, #0x14
    // 0x92bfc8: cmp             x4, #0x3d
    // 0x92bfcc: b.eq            #0x92bfe0
    // 0x92bfd0: r8 = double
    //     0x92bfd0: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x92bfd4: r3 = Null
    //     0x92bfd4: add             x3, PP, #0x33, lsl #12  ; [pp+0x33dd8] Null
    //     0x92bfd8: ldr             x3, [x3, #0xdd8]
    // 0x92bfdc: r0 = double()
    //     0x92bfdc: bl              #0xd72bac  ; IsType_double_Stub
    // 0x92bfe0: ldr             x1, [fp, #0x10]
    // 0x92bfe4: r0 = LoadClassIdInstr(r1)
    //     0x92bfe4: ldur            x0, [x1, #-1]
    //     0x92bfe8: ubfx            x0, x0, #0xc, #0x14
    // 0x92bfec: r16 = "xDpi"
    //     0x92bfec: add             x16, PP, #0x33, lsl #12  ; [pp+0x33de8] "xDpi"
    //     0x92bff0: ldr             x16, [x16, #0xde8]
    // 0x92bff4: stp             x16, x1, [SP, #-0x10]!
    // 0x92bff8: r0 = GDT[cid_x0 + -0xef]()
    //     0x92bff8: sub             lr, x0, #0xef
    //     0x92bffc: ldr             lr, [x21, lr, lsl #3]
    //     0x92c000: blr             lr
    // 0x92c004: add             SP, SP, #0x10
    // 0x92c008: r2 = Null
    //     0x92c008: mov             x2, NULL
    // 0x92c00c: r1 = Null
    //     0x92c00c: mov             x1, NULL
    // 0x92c010: r4 = 59
    //     0x92c010: mov             x4, #0x3b
    // 0x92c014: branchIfSmi(r0, 0x92c020)
    //     0x92c014: tbz             w0, #0, #0x92c020
    // 0x92c018: r4 = LoadClassIdInstr(r0)
    //     0x92c018: ldur            x4, [x0, #-1]
    //     0x92c01c: ubfx            x4, x4, #0xc, #0x14
    // 0x92c020: cmp             x4, #0x3d
    // 0x92c024: b.eq            #0x92c038
    // 0x92c028: r8 = double
    //     0x92c028: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x92c02c: r3 = Null
    //     0x92c02c: add             x3, PP, #0x33, lsl #12  ; [pp+0x33df0] Null
    //     0x92c030: ldr             x3, [x3, #0xdf0]
    // 0x92c034: r0 = double()
    //     0x92c034: bl              #0xd72bac  ; IsType_double_Stub
    // 0x92c038: ldr             x0, [fp, #0x10]
    // 0x92c03c: r1 = LoadClassIdInstr(r0)
    //     0x92c03c: ldur            x1, [x0, #-1]
    //     0x92c040: ubfx            x1, x1, #0xc, #0x14
    // 0x92c044: r16 = "yDpi"
    //     0x92c044: add             x16, PP, #0x33, lsl #12  ; [pp+0x33e00] "yDpi"
    //     0x92c048: ldr             x16, [x16, #0xe00]
    // 0x92c04c: stp             x16, x0, [SP, #-0x10]!
    // 0x92c050: mov             x0, x1
    // 0x92c054: r0 = GDT[cid_x0 + -0xef]()
    //     0x92c054: sub             lr, x0, #0xef
    //     0x92c058: ldr             lr, [x21, lr, lsl #3]
    //     0x92c05c: blr             lr
    // 0x92c060: add             SP, SP, #0x10
    // 0x92c064: r2 = Null
    //     0x92c064: mov             x2, NULL
    // 0x92c068: r1 = Null
    //     0x92c068: mov             x1, NULL
    // 0x92c06c: r4 = 59
    //     0x92c06c: mov             x4, #0x3b
    // 0x92c070: branchIfSmi(r0, 0x92c07c)
    //     0x92c070: tbz             w0, #0, #0x92c07c
    // 0x92c074: r4 = LoadClassIdInstr(r0)
    //     0x92c074: ldur            x4, [x0, #-1]
    //     0x92c078: ubfx            x4, x4, #0xc, #0x14
    // 0x92c07c: cmp             x4, #0x3d
    // 0x92c080: b.eq            #0x92c094
    // 0x92c084: r8 = double
    //     0x92c084: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x92c088: r3 = Null
    //     0x92c088: add             x3, PP, #0x33, lsl #12  ; [pp+0x33e08] Null
    //     0x92c08c: ldr             x3, [x3, #0xe08]
    // 0x92c090: r0 = double()
    //     0x92c090: bl              #0xd72bac  ; IsType_double_Stub
    // 0x92c094: r0 = AndroidDisplayMetrics()
    //     0x92c094: bl              #0x92c0ac  ; AllocateAndroidDisplayMetricsStub -> AndroidDisplayMetrics (size=0x8)
    // 0x92c098: LeaveFrame
    //     0x92c098: mov             SP, fp
    //     0x92c09c: ldp             fp, lr, [SP], #0x10
    // 0x92c0a0: ret
    //     0x92c0a0: ret             
    // 0x92c0a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92c0a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92c0a8: b               #0x92bf30
  }
}

// class id: 4557, size: 0x10, field offset: 0x8
//   const constructor, 
class AndroidBuildVersion extends Object {

  static _ _fromMap(/* No info */) {
    // ** addr: 0x92c144, size: 0x2d4
    // 0x92c144: EnterFrame
    //     0x92c144: stp             fp, lr, [SP, #-0x10]!
    //     0x92c148: mov             fp, SP
    // 0x92c14c: AllocStack(0x10)
    //     0x92c14c: sub             SP, SP, #0x10
    // 0x92c150: CheckStackOverflow
    //     0x92c150: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92c154: cmp             SP, x16
    //     0x92c158: b.ls            #0x92c410
    // 0x92c15c: ldr             x1, [fp, #0x10]
    // 0x92c160: r0 = LoadClassIdInstr(r1)
    //     0x92c160: ldur            x0, [x1, #-1]
    //     0x92c164: ubfx            x0, x0, #0xc, #0x14
    // 0x92c168: r16 = "baseOS"
    //     0x92c168: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e90] "baseOS"
    //     0x92c16c: ldr             x16, [x16, #0xe90]
    // 0x92c170: stp             x16, x1, [SP, #-0x10]!
    // 0x92c174: r0 = GDT[cid_x0 + -0xef]()
    //     0x92c174: sub             lr, x0, #0xef
    //     0x92c178: ldr             lr, [x21, lr, lsl #3]
    //     0x92c17c: blr             lr
    // 0x92c180: add             SP, SP, #0x10
    // 0x92c184: r2 = Null
    //     0x92c184: mov             x2, NULL
    // 0x92c188: r1 = Null
    //     0x92c188: mov             x1, NULL
    // 0x92c18c: r4 = 59
    //     0x92c18c: mov             x4, #0x3b
    // 0x92c190: branchIfSmi(r0, 0x92c19c)
    //     0x92c190: tbz             w0, #0, #0x92c19c
    // 0x92c194: r4 = LoadClassIdInstr(r0)
    //     0x92c194: ldur            x4, [x0, #-1]
    //     0x92c198: ubfx            x4, x4, #0xc, #0x14
    // 0x92c19c: sub             x4, x4, #0x5d
    // 0x92c1a0: cmp             x4, #3
    // 0x92c1a4: b.ls            #0x92c1b8
    // 0x92c1a8: r8 = String?
    //     0x92c1a8: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0x92c1ac: r3 = Null
    //     0x92c1ac: add             x3, PP, #0x33, lsl #12  ; [pp+0x33e20] Null
    //     0x92c1b0: ldr             x3, [x3, #0xe20]
    // 0x92c1b4: r0 = String?()
    //     0x92c1b4: bl              #0x4b2994  ; IsType_String?_Stub
    // 0x92c1b8: ldr             x1, [fp, #0x10]
    // 0x92c1bc: r0 = LoadClassIdInstr(r1)
    //     0x92c1bc: ldur            x0, [x1, #-1]
    //     0x92c1c0: ubfx            x0, x0, #0xc, #0x14
    // 0x92c1c4: r16 = "codename"
    //     0x92c1c4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ed8] "codename"
    //     0x92c1c8: ldr             x16, [x16, #0xed8]
    // 0x92c1cc: stp             x16, x1, [SP, #-0x10]!
    // 0x92c1d0: r0 = GDT[cid_x0 + -0xef]()
    //     0x92c1d0: sub             lr, x0, #0xef
    //     0x92c1d4: ldr             lr, [x21, lr, lsl #3]
    //     0x92c1d8: blr             lr
    // 0x92c1dc: add             SP, SP, #0x10
    // 0x92c1e0: r2 = Null
    //     0x92c1e0: mov             x2, NULL
    // 0x92c1e4: r1 = Null
    //     0x92c1e4: mov             x1, NULL
    // 0x92c1e8: r4 = 59
    //     0x92c1e8: mov             x4, #0x3b
    // 0x92c1ec: branchIfSmi(r0, 0x92c1f8)
    //     0x92c1ec: tbz             w0, #0, #0x92c1f8
    // 0x92c1f0: r4 = LoadClassIdInstr(r0)
    //     0x92c1f0: ldur            x4, [x0, #-1]
    //     0x92c1f4: ubfx            x4, x4, #0xc, #0x14
    // 0x92c1f8: sub             x4, x4, #0x5d
    // 0x92c1fc: cmp             x4, #3
    // 0x92c200: b.ls            #0x92c214
    // 0x92c204: r8 = String
    //     0x92c204: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c208: r3 = Null
    //     0x92c208: add             x3, PP, #0x33, lsl #12  ; [pp+0x33e30] Null
    //     0x92c20c: ldr             x3, [x3, #0xe30]
    // 0x92c210: r0 = String()
    //     0x92c210: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c214: ldr             x1, [fp, #0x10]
    // 0x92c218: r0 = LoadClassIdInstr(r1)
    //     0x92c218: ldur            x0, [x1, #-1]
    //     0x92c21c: ubfx            x0, x0, #0xc, #0x14
    // 0x92c220: r16 = "incremental"
    //     0x92c220: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ef0] "incremental"
    //     0x92c224: ldr             x16, [x16, #0xef0]
    // 0x92c228: stp             x16, x1, [SP, #-0x10]!
    // 0x92c22c: r0 = GDT[cid_x0 + -0xef]()
    //     0x92c22c: sub             lr, x0, #0xef
    //     0x92c230: ldr             lr, [x21, lr, lsl #3]
    //     0x92c234: blr             lr
    // 0x92c238: add             SP, SP, #0x10
    // 0x92c23c: r2 = Null
    //     0x92c23c: mov             x2, NULL
    // 0x92c240: r1 = Null
    //     0x92c240: mov             x1, NULL
    // 0x92c244: r4 = 59
    //     0x92c244: mov             x4, #0x3b
    // 0x92c248: branchIfSmi(r0, 0x92c254)
    //     0x92c248: tbz             w0, #0, #0x92c254
    // 0x92c24c: r4 = LoadClassIdInstr(r0)
    //     0x92c24c: ldur            x4, [x0, #-1]
    //     0x92c250: ubfx            x4, x4, #0xc, #0x14
    // 0x92c254: sub             x4, x4, #0x5d
    // 0x92c258: cmp             x4, #3
    // 0x92c25c: b.ls            #0x92c270
    // 0x92c260: r8 = String
    //     0x92c260: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c264: r3 = Null
    //     0x92c264: add             x3, PP, #0x33, lsl #12  ; [pp+0x33e40] Null
    //     0x92c268: ldr             x3, [x3, #0xe40]
    // 0x92c26c: r0 = String()
    //     0x92c26c: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c270: ldr             x1, [fp, #0x10]
    // 0x92c274: r0 = LoadClassIdInstr(r1)
    //     0x92c274: ldur            x0, [x1, #-1]
    //     0x92c278: ubfx            x0, x0, #0xc, #0x14
    // 0x92c27c: r16 = "previewSdkInt"
    //     0x92c27c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ea8] "previewSdkInt"
    //     0x92c280: ldr             x16, [x16, #0xea8]
    // 0x92c284: stp             x16, x1, [SP, #-0x10]!
    // 0x92c288: r0 = GDT[cid_x0 + -0xef]()
    //     0x92c288: sub             lr, x0, #0xef
    //     0x92c28c: ldr             lr, [x21, lr, lsl #3]
    //     0x92c290: blr             lr
    // 0x92c294: add             SP, SP, #0x10
    // 0x92c298: r2 = Null
    //     0x92c298: mov             x2, NULL
    // 0x92c29c: r1 = Null
    //     0x92c29c: mov             x1, NULL
    // 0x92c2a0: branchIfSmi(r0, 0x92c2c8)
    //     0x92c2a0: tbz             w0, #0, #0x92c2c8
    // 0x92c2a4: r4 = LoadClassIdInstr(r0)
    //     0x92c2a4: ldur            x4, [x0, #-1]
    //     0x92c2a8: ubfx            x4, x4, #0xc, #0x14
    // 0x92c2ac: sub             x4, x4, #0x3b
    // 0x92c2b0: cmp             x4, #1
    // 0x92c2b4: b.ls            #0x92c2c8
    // 0x92c2b8: r8 = int?
    //     0x92c2b8: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0x92c2bc: r3 = Null
    //     0x92c2bc: add             x3, PP, #0x33, lsl #12  ; [pp+0x33e50] Null
    //     0x92c2c0: ldr             x3, [x3, #0xe50]
    // 0x92c2c4: r0 = int?()
    //     0x92c2c4: bl              #0xd736d8  ; IsType_int?_Stub
    // 0x92c2c8: ldr             x1, [fp, #0x10]
    // 0x92c2cc: r0 = LoadClassIdInstr(r1)
    //     0x92c2cc: ldur            x0, [x1, #-1]
    //     0x92c2d0: ubfx            x0, x0, #0xc, #0x14
    // 0x92c2d4: r16 = "release"
    //     0x92c2d4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c68] "release"
    //     0x92c2d8: ldr             x16, [x16, #0xc68]
    // 0x92c2dc: stp             x16, x1, [SP, #-0x10]!
    // 0x92c2e0: r0 = GDT[cid_x0 + -0xef]()
    //     0x92c2e0: sub             lr, x0, #0xef
    //     0x92c2e4: ldr             lr, [x21, lr, lsl #3]
    //     0x92c2e8: blr             lr
    // 0x92c2ec: add             SP, SP, #0x10
    // 0x92c2f0: r2 = Null
    //     0x92c2f0: mov             x2, NULL
    // 0x92c2f4: r1 = Null
    //     0x92c2f4: mov             x1, NULL
    // 0x92c2f8: r4 = 59
    //     0x92c2f8: mov             x4, #0x3b
    // 0x92c2fc: branchIfSmi(r0, 0x92c308)
    //     0x92c2fc: tbz             w0, #0, #0x92c308
    // 0x92c300: r4 = LoadClassIdInstr(r0)
    //     0x92c300: ldur            x4, [x0, #-1]
    //     0x92c304: ubfx            x4, x4, #0xc, #0x14
    // 0x92c308: sub             x4, x4, #0x5d
    // 0x92c30c: cmp             x4, #3
    // 0x92c310: b.ls            #0x92c324
    // 0x92c314: r8 = String
    //     0x92c314: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92c318: r3 = Null
    //     0x92c318: add             x3, PP, #0x33, lsl #12  ; [pp+0x33e60] Null
    //     0x92c31c: ldr             x3, [x3, #0xe60]
    // 0x92c320: r0 = String()
    //     0x92c320: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92c324: ldr             x1, [fp, #0x10]
    // 0x92c328: r0 = LoadClassIdInstr(r1)
    //     0x92c328: ldur            x0, [x1, #-1]
    //     0x92c32c: ubfx            x0, x0, #0xc, #0x14
    // 0x92c330: r16 = "sdkInt"
    //     0x92c330: add             x16, PP, #0x14, lsl #12  ; [pp+0x14f18] "sdkInt"
    //     0x92c334: ldr             x16, [x16, #0xf18]
    // 0x92c338: stp             x16, x1, [SP, #-0x10]!
    // 0x92c33c: r0 = GDT[cid_x0 + -0xef]()
    //     0x92c33c: sub             lr, x0, #0xef
    //     0x92c340: ldr             lr, [x21, lr, lsl #3]
    //     0x92c344: blr             lr
    // 0x92c348: add             SP, SP, #0x10
    // 0x92c34c: mov             x3, x0
    // 0x92c350: r2 = Null
    //     0x92c350: mov             x2, NULL
    // 0x92c354: r1 = Null
    //     0x92c354: mov             x1, NULL
    // 0x92c358: stur            x3, [fp, #-8]
    // 0x92c35c: branchIfSmi(r0, 0x92c384)
    //     0x92c35c: tbz             w0, #0, #0x92c384
    // 0x92c360: r4 = LoadClassIdInstr(r0)
    //     0x92c360: ldur            x4, [x0, #-1]
    //     0x92c364: ubfx            x4, x4, #0xc, #0x14
    // 0x92c368: sub             x4, x4, #0x3b
    // 0x92c36c: cmp             x4, #1
    // 0x92c370: b.ls            #0x92c384
    // 0x92c374: r8 = int
    //     0x92c374: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0x92c378: r3 = Null
    //     0x92c378: add             x3, PP, #0x33, lsl #12  ; [pp+0x33e70] Null
    //     0x92c37c: ldr             x3, [x3, #0xe70]
    // 0x92c380: r0 = int()
    //     0x92c380: bl              #0xd73714  ; IsType_int_Stub
    // 0x92c384: ldr             x0, [fp, #0x10]
    // 0x92c388: r1 = LoadClassIdInstr(r0)
    //     0x92c388: ldur            x1, [x0, #-1]
    //     0x92c38c: ubfx            x1, x1, #0xc, #0x14
    // 0x92c390: r16 = "securityPatch"
    //     0x92c390: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ec0] "securityPatch"
    //     0x92c394: ldr             x16, [x16, #0xec0]
    // 0x92c398: stp             x16, x0, [SP, #-0x10]!
    // 0x92c39c: mov             x0, x1
    // 0x92c3a0: r0 = GDT[cid_x0 + -0xef]()
    //     0x92c3a0: sub             lr, x0, #0xef
    //     0x92c3a4: ldr             lr, [x21, lr, lsl #3]
    //     0x92c3a8: blr             lr
    // 0x92c3ac: add             SP, SP, #0x10
    // 0x92c3b0: r2 = Null
    //     0x92c3b0: mov             x2, NULL
    // 0x92c3b4: r1 = Null
    //     0x92c3b4: mov             x1, NULL
    // 0x92c3b8: r4 = 59
    //     0x92c3b8: mov             x4, #0x3b
    // 0x92c3bc: branchIfSmi(r0, 0x92c3c8)
    //     0x92c3bc: tbz             w0, #0, #0x92c3c8
    // 0x92c3c0: r4 = LoadClassIdInstr(r0)
    //     0x92c3c0: ldur            x4, [x0, #-1]
    //     0x92c3c4: ubfx            x4, x4, #0xc, #0x14
    // 0x92c3c8: sub             x4, x4, #0x5d
    // 0x92c3cc: cmp             x4, #3
    // 0x92c3d0: b.ls            #0x92c3e4
    // 0x92c3d4: r8 = String?
    //     0x92c3d4: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0x92c3d8: r3 = Null
    //     0x92c3d8: add             x3, PP, #0x33, lsl #12  ; [pp+0x33e80] Null
    //     0x92c3dc: ldr             x3, [x3, #0xe80]
    // 0x92c3e0: r0 = String?()
    //     0x92c3e0: bl              #0x4b2994  ; IsType_String?_Stub
    // 0x92c3e4: ldur            x0, [fp, #-8]
    // 0x92c3e8: r1 = LoadInt32Instr(r0)
    //     0x92c3e8: sbfx            x1, x0, #1, #0x1f
    //     0x92c3ec: tbz             w0, #0, #0x92c3f4
    //     0x92c3f0: ldur            x1, [x0, #7]
    // 0x92c3f4: stur            x1, [fp, #-0x10]
    // 0x92c3f8: r0 = AndroidBuildVersion()
    //     0x92c3f8: bl              #0x92c418  ; AllocateAndroidBuildVersionStub -> AndroidBuildVersion (size=0x10)
    // 0x92c3fc: ldur            x1, [fp, #-0x10]
    // 0x92c400: StoreField: r0->field_7 = r1
    //     0x92c400: stur            x1, [x0, #7]
    // 0x92c404: LeaveFrame
    //     0x92c404: mov             SP, fp
    //     0x92c408: ldp             fp, lr, [SP], #0x10
    // 0x92c40c: ret
    //     0x92c40c: ret             
    // 0x92c410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92c410: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92c414: b               #0x92c15c
  }
}

// class id: 4559, size: 0x10, field offset: 0xc
class AndroidDeviceInfo extends BaseDeviceInfo {

  static _ fromMap(/* No info */) {
    // ** addr: 0x92b384, size: 0xa14
    // 0x92b384: EnterFrame
    //     0x92b384: stp             fp, lr, [SP, #-0x10]!
    //     0x92b388: mov             fp, SP
    // 0x92b38c: AllocStack(0x30)
    //     0x92b38c: sub             SP, SP, #0x30
    // 0x92b390: CheckStackOverflow
    //     0x92b390: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92b394: cmp             SP, x16
    //     0x92b398: b.ls            #0x92bd90
    // 0x92b39c: ldr             x1, [fp, #0x10]
    // 0x92b3a0: r0 = LoadClassIdInstr(r1)
    //     0x92b3a0: ldur            x0, [x1, #-1]
    //     0x92b3a4: ubfx            x0, x0, #0xc, #0x14
    // 0x92b3a8: r16 = "version"
    //     0x92b3a8: add             x16, PP, #0xa, lsl #12  ; [pp+0xaca8] "version"
    //     0x92b3ac: ldr             x16, [x16, #0xca8]
    // 0x92b3b0: stp             x16, x1, [SP, #-0x10]!
    // 0x92b3b4: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b3b4: sub             lr, x0, #0xef
    //     0x92b3b8: ldr             lr, [x21, lr, lsl #3]
    //     0x92b3bc: blr             lr
    // 0x92b3c0: add             SP, SP, #0x10
    // 0x92b3c4: cmp             w0, NULL
    // 0x92b3c8: b.ne            #0x92b3d4
    // 0x92b3cc: r0 = Null
    //     0x92b3cc: mov             x0, NULL
    // 0x92b3d0: b               #0x92b3f8
    // 0x92b3d4: r16 = <String, dynamic>
    //     0x92b3d4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x92b3d8: stp             x0, x16, [SP, #-0x10]!
    // 0x92b3dc: r4 = 0
    //     0x92b3dc: mov             x4, #0
    // 0x92b3e0: ldr             x0, [SP]
    // 0x92b3e4: r16 = UnlinkedCall_0x4aeefc
    //     0x92b3e4: add             x16, PP, #0x33, lsl #12  ; [pp+0x33c28] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x92b3e8: add             x16, x16, #0xc28
    // 0x92b3ec: ldp             x5, lr, [x16]
    // 0x92b3f0: blr             lr
    // 0x92b3f4: add             SP, SP, #0x10
    // 0x92b3f8: cmp             w0, NULL
    // 0x92b3fc: b.ne            #0x92b41c
    // 0x92b400: r16 = <String, dynamic>
    //     0x92b400: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x92b404: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x92b408: stp             lr, x16, [SP, #-0x10]!
    // 0x92b40c: r0 = Map._fromLiteral()
    //     0x92b40c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x92b410: add             SP, SP, #0x10
    // 0x92b414: mov             x4, x0
    // 0x92b418: b               #0x92b420
    // 0x92b41c: mov             x4, x0
    // 0x92b420: ldr             x3, [fp, #0x10]
    // 0x92b424: mov             x0, x4
    // 0x92b428: stur            x4, [fp, #-8]
    // 0x92b42c: r2 = Null
    //     0x92b42c: mov             x2, NULL
    // 0x92b430: r1 = Null
    //     0x92b430: mov             x1, NULL
    // 0x92b434: r8 = Map<String, dynamic>
    //     0x92b434: ldr             x8, [PP, #0x3da0]  ; [pp+0x3da0] Type: Map<String, dynamic>
    // 0x92b438: r3 = Null
    //     0x92b438: add             x3, PP, #0x33, lsl #12  ; [pp+0x33c38] Null
    //     0x92b43c: ldr             x3, [x3, #0xc38]
    // 0x92b440: r0 = Map<String, dynamic>()
    //     0x92b440: bl              #0x4e3b2c  ; IsType_Map<String, dynamic>_Stub
    // 0x92b444: ldur            x16, [fp, #-8]
    // 0x92b448: SaveReg r16
    //     0x92b448: str             x16, [SP, #-8]!
    // 0x92b44c: r0 = _fromMap()
    //     0x92b44c: bl              #0x92c144  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidBuildVersion::_fromMap
    // 0x92b450: add             SP, SP, #8
    // 0x92b454: mov             x2, x0
    // 0x92b458: ldr             x1, [fp, #0x10]
    // 0x92b45c: stur            x2, [fp, #-8]
    // 0x92b460: r0 = LoadClassIdInstr(r1)
    //     0x92b460: ldur            x0, [x1, #-1]
    //     0x92b464: ubfx            x0, x0, #0xc, #0x14
    // 0x92b468: r16 = "board"
    //     0x92b468: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d00] "board"
    //     0x92b46c: ldr             x16, [x16, #0xd00]
    // 0x92b470: stp             x16, x1, [SP, #-0x10]!
    // 0x92b474: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b474: sub             lr, x0, #0xef
    //     0x92b478: ldr             lr, [x21, lr, lsl #3]
    //     0x92b47c: blr             lr
    // 0x92b480: add             SP, SP, #0x10
    // 0x92b484: r2 = Null
    //     0x92b484: mov             x2, NULL
    // 0x92b488: r1 = Null
    //     0x92b488: mov             x1, NULL
    // 0x92b48c: r4 = 59
    //     0x92b48c: mov             x4, #0x3b
    // 0x92b490: branchIfSmi(r0, 0x92b49c)
    //     0x92b490: tbz             w0, #0, #0x92b49c
    // 0x92b494: r4 = LoadClassIdInstr(r0)
    //     0x92b494: ldur            x4, [x0, #-1]
    //     0x92b498: ubfx            x4, x4, #0xc, #0x14
    // 0x92b49c: sub             x4, x4, #0x5d
    // 0x92b4a0: cmp             x4, #3
    // 0x92b4a4: b.ls            #0x92b4b8
    // 0x92b4a8: r8 = String
    //     0x92b4a8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b4ac: r3 = Null
    //     0x92b4ac: add             x3, PP, #0x33, lsl #12  ; [pp+0x33c48] Null
    //     0x92b4b0: ldr             x3, [x3, #0xc48]
    // 0x92b4b4: r0 = String()
    //     0x92b4b4: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b4b8: ldr             x1, [fp, #0x10]
    // 0x92b4bc: r0 = LoadClassIdInstr(r1)
    //     0x92b4bc: ldur            x0, [x1, #-1]
    //     0x92b4c0: ubfx            x0, x0, #0xc, #0x14
    // 0x92b4c4: r16 = "bootloader"
    //     0x92b4c4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d18] "bootloader"
    //     0x92b4c8: ldr             x16, [x16, #0xd18]
    // 0x92b4cc: stp             x16, x1, [SP, #-0x10]!
    // 0x92b4d0: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b4d0: sub             lr, x0, #0xef
    //     0x92b4d4: ldr             lr, [x21, lr, lsl #3]
    //     0x92b4d8: blr             lr
    // 0x92b4dc: add             SP, SP, #0x10
    // 0x92b4e0: r2 = Null
    //     0x92b4e0: mov             x2, NULL
    // 0x92b4e4: r1 = Null
    //     0x92b4e4: mov             x1, NULL
    // 0x92b4e8: r4 = 59
    //     0x92b4e8: mov             x4, #0x3b
    // 0x92b4ec: branchIfSmi(r0, 0x92b4f8)
    //     0x92b4ec: tbz             w0, #0, #0x92b4f8
    // 0x92b4f0: r4 = LoadClassIdInstr(r0)
    //     0x92b4f0: ldur            x4, [x0, #-1]
    //     0x92b4f4: ubfx            x4, x4, #0xc, #0x14
    // 0x92b4f8: sub             x4, x4, #0x5d
    // 0x92b4fc: cmp             x4, #3
    // 0x92b500: b.ls            #0x92b514
    // 0x92b504: r8 = String
    //     0x92b504: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b508: r3 = Null
    //     0x92b508: add             x3, PP, #0x33, lsl #12  ; [pp+0x33c58] Null
    //     0x92b50c: ldr             x3, [x3, #0xc58]
    // 0x92b510: r0 = String()
    //     0x92b510: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b514: ldr             x1, [fp, #0x10]
    // 0x92b518: r0 = LoadClassIdInstr(r1)
    //     0x92b518: ldur            x0, [x1, #-1]
    //     0x92b51c: ubfx            x0, x0, #0xc, #0x14
    // 0x92b520: r16 = "brand"
    //     0x92b520: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d30] "brand"
    //     0x92b524: ldr             x16, [x16, #0xd30]
    // 0x92b528: stp             x16, x1, [SP, #-0x10]!
    // 0x92b52c: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b52c: sub             lr, x0, #0xef
    //     0x92b530: ldr             lr, [x21, lr, lsl #3]
    //     0x92b534: blr             lr
    // 0x92b538: add             SP, SP, #0x10
    // 0x92b53c: r2 = Null
    //     0x92b53c: mov             x2, NULL
    // 0x92b540: r1 = Null
    //     0x92b540: mov             x1, NULL
    // 0x92b544: r4 = 59
    //     0x92b544: mov             x4, #0x3b
    // 0x92b548: branchIfSmi(r0, 0x92b554)
    //     0x92b548: tbz             w0, #0, #0x92b554
    // 0x92b54c: r4 = LoadClassIdInstr(r0)
    //     0x92b54c: ldur            x4, [x0, #-1]
    //     0x92b550: ubfx            x4, x4, #0xc, #0x14
    // 0x92b554: sub             x4, x4, #0x5d
    // 0x92b558: cmp             x4, #3
    // 0x92b55c: b.ls            #0x92b570
    // 0x92b560: r8 = String
    //     0x92b560: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b564: r3 = Null
    //     0x92b564: add             x3, PP, #0x33, lsl #12  ; [pp+0x33c68] Null
    //     0x92b568: ldr             x3, [x3, #0xc68]
    // 0x92b56c: r0 = String()
    //     0x92b56c: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b570: ldr             x1, [fp, #0x10]
    // 0x92b574: r0 = LoadClassIdInstr(r1)
    //     0x92b574: ldur            x0, [x1, #-1]
    //     0x92b578: ubfx            x0, x0, #0xc, #0x14
    // 0x92b57c: r16 = "device"
    //     0x92b57c: ldr             x16, [PP, #0x3990]  ; [pp+0x3990] "device"
    // 0x92b580: stp             x16, x1, [SP, #-0x10]!
    // 0x92b584: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b584: sub             lr, x0, #0xef
    //     0x92b588: ldr             lr, [x21, lr, lsl #3]
    //     0x92b58c: blr             lr
    // 0x92b590: add             SP, SP, #0x10
    // 0x92b594: r2 = Null
    //     0x92b594: mov             x2, NULL
    // 0x92b598: r1 = Null
    //     0x92b598: mov             x1, NULL
    // 0x92b59c: r4 = 59
    //     0x92b59c: mov             x4, #0x3b
    // 0x92b5a0: branchIfSmi(r0, 0x92b5ac)
    //     0x92b5a0: tbz             w0, #0, #0x92b5ac
    // 0x92b5a4: r4 = LoadClassIdInstr(r0)
    //     0x92b5a4: ldur            x4, [x0, #-1]
    //     0x92b5a8: ubfx            x4, x4, #0xc, #0x14
    // 0x92b5ac: sub             x4, x4, #0x5d
    // 0x92b5b0: cmp             x4, #3
    // 0x92b5b4: b.ls            #0x92b5c8
    // 0x92b5b8: r8 = String
    //     0x92b5b8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b5bc: r3 = Null
    //     0x92b5bc: add             x3, PP, #0x33, lsl #12  ; [pp+0x33c78] Null
    //     0x92b5c0: ldr             x3, [x3, #0xc78]
    // 0x92b5c4: r0 = String()
    //     0x92b5c4: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b5c8: ldr             x1, [fp, #0x10]
    // 0x92b5cc: r0 = LoadClassIdInstr(r1)
    //     0x92b5cc: ldur            x0, [x1, #-1]
    //     0x92b5d0: ubfx            x0, x0, #0xc, #0x14
    // 0x92b5d4: r16 = "display"
    //     0x92b5d4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d58] "display"
    //     0x92b5d8: ldr             x16, [x16, #0xd58]
    // 0x92b5dc: stp             x16, x1, [SP, #-0x10]!
    // 0x92b5e0: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b5e0: sub             lr, x0, #0xef
    //     0x92b5e4: ldr             lr, [x21, lr, lsl #3]
    //     0x92b5e8: blr             lr
    // 0x92b5ec: add             SP, SP, #0x10
    // 0x92b5f0: r2 = Null
    //     0x92b5f0: mov             x2, NULL
    // 0x92b5f4: r1 = Null
    //     0x92b5f4: mov             x1, NULL
    // 0x92b5f8: r4 = 59
    //     0x92b5f8: mov             x4, #0x3b
    // 0x92b5fc: branchIfSmi(r0, 0x92b608)
    //     0x92b5fc: tbz             w0, #0, #0x92b608
    // 0x92b600: r4 = LoadClassIdInstr(r0)
    //     0x92b600: ldur            x4, [x0, #-1]
    //     0x92b604: ubfx            x4, x4, #0xc, #0x14
    // 0x92b608: sub             x4, x4, #0x5d
    // 0x92b60c: cmp             x4, #3
    // 0x92b610: b.ls            #0x92b624
    // 0x92b614: r8 = String
    //     0x92b614: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b618: r3 = Null
    //     0x92b618: add             x3, PP, #0x33, lsl #12  ; [pp+0x33c88] Null
    //     0x92b61c: ldr             x3, [x3, #0xc88]
    // 0x92b620: r0 = String()
    //     0x92b620: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b624: ldr             x1, [fp, #0x10]
    // 0x92b628: r0 = LoadClassIdInstr(r1)
    //     0x92b628: ldur            x0, [x1, #-1]
    //     0x92b62c: ubfx            x0, x0, #0xc, #0x14
    // 0x92b630: r16 = "fingerprint"
    //     0x92b630: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d70] "fingerprint"
    //     0x92b634: ldr             x16, [x16, #0xd70]
    // 0x92b638: stp             x16, x1, [SP, #-0x10]!
    // 0x92b63c: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b63c: sub             lr, x0, #0xef
    //     0x92b640: ldr             lr, [x21, lr, lsl #3]
    //     0x92b644: blr             lr
    // 0x92b648: add             SP, SP, #0x10
    // 0x92b64c: r2 = Null
    //     0x92b64c: mov             x2, NULL
    // 0x92b650: r1 = Null
    //     0x92b650: mov             x1, NULL
    // 0x92b654: r4 = 59
    //     0x92b654: mov             x4, #0x3b
    // 0x92b658: branchIfSmi(r0, 0x92b664)
    //     0x92b658: tbz             w0, #0, #0x92b664
    // 0x92b65c: r4 = LoadClassIdInstr(r0)
    //     0x92b65c: ldur            x4, [x0, #-1]
    //     0x92b660: ubfx            x4, x4, #0xc, #0x14
    // 0x92b664: sub             x4, x4, #0x5d
    // 0x92b668: cmp             x4, #3
    // 0x92b66c: b.ls            #0x92b680
    // 0x92b670: r8 = String
    //     0x92b670: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b674: r3 = Null
    //     0x92b674: add             x3, PP, #0x33, lsl #12  ; [pp+0x33c98] Null
    //     0x92b678: ldr             x3, [x3, #0xc98]
    // 0x92b67c: r0 = String()
    //     0x92b67c: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b680: ldr             x1, [fp, #0x10]
    // 0x92b684: r0 = LoadClassIdInstr(r1)
    //     0x92b684: ldur            x0, [x1, #-1]
    //     0x92b688: ubfx            x0, x0, #0xc, #0x14
    // 0x92b68c: r16 = "hardware"
    //     0x92b68c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d88] "hardware"
    //     0x92b690: ldr             x16, [x16, #0xd88]
    // 0x92b694: stp             x16, x1, [SP, #-0x10]!
    // 0x92b698: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b698: sub             lr, x0, #0xef
    //     0x92b69c: ldr             lr, [x21, lr, lsl #3]
    //     0x92b6a0: blr             lr
    // 0x92b6a4: add             SP, SP, #0x10
    // 0x92b6a8: r2 = Null
    //     0x92b6a8: mov             x2, NULL
    // 0x92b6ac: r1 = Null
    //     0x92b6ac: mov             x1, NULL
    // 0x92b6b0: r4 = 59
    //     0x92b6b0: mov             x4, #0x3b
    // 0x92b6b4: branchIfSmi(r0, 0x92b6c0)
    //     0x92b6b4: tbz             w0, #0, #0x92b6c0
    // 0x92b6b8: r4 = LoadClassIdInstr(r0)
    //     0x92b6b8: ldur            x4, [x0, #-1]
    //     0x92b6bc: ubfx            x4, x4, #0xc, #0x14
    // 0x92b6c0: sub             x4, x4, #0x5d
    // 0x92b6c4: cmp             x4, #3
    // 0x92b6c8: b.ls            #0x92b6dc
    // 0x92b6cc: r8 = String
    //     0x92b6cc: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b6d0: r3 = Null
    //     0x92b6d0: add             x3, PP, #0x33, lsl #12  ; [pp+0x33ca8] Null
    //     0x92b6d4: ldr             x3, [x3, #0xca8]
    // 0x92b6d8: r0 = String()
    //     0x92b6d8: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b6dc: ldr             x1, [fp, #0x10]
    // 0x92b6e0: r0 = LoadClassIdInstr(r1)
    //     0x92b6e0: ldur            x0, [x1, #-1]
    //     0x92b6e4: ubfx            x0, x0, #0xc, #0x14
    // 0x92b6e8: r16 = "host"
    //     0x92b6e8: ldr             x16, [PP, #0x2680]  ; [pp+0x2680] "host"
    // 0x92b6ec: stp             x16, x1, [SP, #-0x10]!
    // 0x92b6f0: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b6f0: sub             lr, x0, #0xef
    //     0x92b6f4: ldr             lr, [x21, lr, lsl #3]
    //     0x92b6f8: blr             lr
    // 0x92b6fc: add             SP, SP, #0x10
    // 0x92b700: r2 = Null
    //     0x92b700: mov             x2, NULL
    // 0x92b704: r1 = Null
    //     0x92b704: mov             x1, NULL
    // 0x92b708: r4 = 59
    //     0x92b708: mov             x4, #0x3b
    // 0x92b70c: branchIfSmi(r0, 0x92b718)
    //     0x92b70c: tbz             w0, #0, #0x92b718
    // 0x92b710: r4 = LoadClassIdInstr(r0)
    //     0x92b710: ldur            x4, [x0, #-1]
    //     0x92b714: ubfx            x4, x4, #0xc, #0x14
    // 0x92b718: sub             x4, x4, #0x5d
    // 0x92b71c: cmp             x4, #3
    // 0x92b720: b.ls            #0x92b734
    // 0x92b724: r8 = String
    //     0x92b724: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b728: r3 = Null
    //     0x92b728: add             x3, PP, #0x33, lsl #12  ; [pp+0x33cb8] Null
    //     0x92b72c: ldr             x3, [x3, #0xcb8]
    // 0x92b730: r0 = String()
    //     0x92b730: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b734: ldr             x1, [fp, #0x10]
    // 0x92b738: r0 = LoadClassIdInstr(r1)
    //     0x92b738: ldur            x0, [x1, #-1]
    //     0x92b73c: ubfx            x0, x0, #0xc, #0x14
    // 0x92b740: r16 = "id"
    //     0x92b740: ldr             x16, [PP, #0x2a60]  ; [pp+0x2a60] "id"
    // 0x92b744: stp             x16, x1, [SP, #-0x10]!
    // 0x92b748: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b748: sub             lr, x0, #0xef
    //     0x92b74c: ldr             lr, [x21, lr, lsl #3]
    //     0x92b750: blr             lr
    // 0x92b754: add             SP, SP, #0x10
    // 0x92b758: r2 = Null
    //     0x92b758: mov             x2, NULL
    // 0x92b75c: r1 = Null
    //     0x92b75c: mov             x1, NULL
    // 0x92b760: r4 = 59
    //     0x92b760: mov             x4, #0x3b
    // 0x92b764: branchIfSmi(r0, 0x92b770)
    //     0x92b764: tbz             w0, #0, #0x92b770
    // 0x92b768: r4 = LoadClassIdInstr(r0)
    //     0x92b768: ldur            x4, [x0, #-1]
    //     0x92b76c: ubfx            x4, x4, #0xc, #0x14
    // 0x92b770: sub             x4, x4, #0x5d
    // 0x92b774: cmp             x4, #3
    // 0x92b778: b.ls            #0x92b78c
    // 0x92b77c: r8 = String
    //     0x92b77c: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b780: r3 = Null
    //     0x92b780: add             x3, PP, #0x33, lsl #12  ; [pp+0x33cc8] Null
    //     0x92b784: ldr             x3, [x3, #0xcc8]
    // 0x92b788: r0 = String()
    //     0x92b788: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b78c: ldr             x1, [fp, #0x10]
    // 0x92b790: r0 = LoadClassIdInstr(r1)
    //     0x92b790: ldur            x0, [x1, #-1]
    //     0x92b794: ubfx            x0, x0, #0xc, #0x14
    // 0x92b798: r16 = "manufacturer"
    //     0x92b798: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dc0] "manufacturer"
    //     0x92b79c: ldr             x16, [x16, #0xdc0]
    // 0x92b7a0: stp             x16, x1, [SP, #-0x10]!
    // 0x92b7a4: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b7a4: sub             lr, x0, #0xef
    //     0x92b7a8: ldr             lr, [x21, lr, lsl #3]
    //     0x92b7ac: blr             lr
    // 0x92b7b0: add             SP, SP, #0x10
    // 0x92b7b4: r2 = Null
    //     0x92b7b4: mov             x2, NULL
    // 0x92b7b8: r1 = Null
    //     0x92b7b8: mov             x1, NULL
    // 0x92b7bc: r4 = 59
    //     0x92b7bc: mov             x4, #0x3b
    // 0x92b7c0: branchIfSmi(r0, 0x92b7cc)
    //     0x92b7c0: tbz             w0, #0, #0x92b7cc
    // 0x92b7c4: r4 = LoadClassIdInstr(r0)
    //     0x92b7c4: ldur            x4, [x0, #-1]
    //     0x92b7c8: ubfx            x4, x4, #0xc, #0x14
    // 0x92b7cc: sub             x4, x4, #0x5d
    // 0x92b7d0: cmp             x4, #3
    // 0x92b7d4: b.ls            #0x92b7e8
    // 0x92b7d8: r8 = String
    //     0x92b7d8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b7dc: r3 = Null
    //     0x92b7dc: add             x3, PP, #0x33, lsl #12  ; [pp+0x33cd8] Null
    //     0x92b7e0: ldr             x3, [x3, #0xcd8]
    // 0x92b7e4: r0 = String()
    //     0x92b7e4: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b7e8: ldr             x1, [fp, #0x10]
    // 0x92b7ec: r0 = LoadClassIdInstr(r1)
    //     0x92b7ec: ldur            x0, [x1, #-1]
    //     0x92b7f0: ubfx            x0, x0, #0xc, #0x14
    // 0x92b7f4: r16 = "model"
    //     0x92b7f4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14bc0] "model"
    //     0x92b7f8: ldr             x16, [x16, #0xbc0]
    // 0x92b7fc: stp             x16, x1, [SP, #-0x10]!
    // 0x92b800: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b800: sub             lr, x0, #0xef
    //     0x92b804: ldr             lr, [x21, lr, lsl #3]
    //     0x92b808: blr             lr
    // 0x92b80c: add             SP, SP, #0x10
    // 0x92b810: r2 = Null
    //     0x92b810: mov             x2, NULL
    // 0x92b814: r1 = Null
    //     0x92b814: mov             x1, NULL
    // 0x92b818: r4 = 59
    //     0x92b818: mov             x4, #0x3b
    // 0x92b81c: branchIfSmi(r0, 0x92b828)
    //     0x92b81c: tbz             w0, #0, #0x92b828
    // 0x92b820: r4 = LoadClassIdInstr(r0)
    //     0x92b820: ldur            x4, [x0, #-1]
    //     0x92b824: ubfx            x4, x4, #0xc, #0x14
    // 0x92b828: sub             x4, x4, #0x5d
    // 0x92b82c: cmp             x4, #3
    // 0x92b830: b.ls            #0x92b844
    // 0x92b834: r8 = String
    //     0x92b834: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b838: r3 = Null
    //     0x92b838: add             x3, PP, #0x33, lsl #12  ; [pp+0x33ce8] Null
    //     0x92b83c: ldr             x3, [x3, #0xce8]
    // 0x92b840: r0 = String()
    //     0x92b840: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b844: ldr             x1, [fp, #0x10]
    // 0x92b848: r0 = LoadClassIdInstr(r1)
    //     0x92b848: ldur            x0, [x1, #-1]
    //     0x92b84c: ubfx            x0, x0, #0xc, #0x14
    // 0x92b850: r16 = "product"
    //     0x92b850: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de8] "product"
    //     0x92b854: ldr             x16, [x16, #0xde8]
    // 0x92b858: stp             x16, x1, [SP, #-0x10]!
    // 0x92b85c: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b85c: sub             lr, x0, #0xef
    //     0x92b860: ldr             lr, [x21, lr, lsl #3]
    //     0x92b864: blr             lr
    // 0x92b868: add             SP, SP, #0x10
    // 0x92b86c: r2 = Null
    //     0x92b86c: mov             x2, NULL
    // 0x92b870: r1 = Null
    //     0x92b870: mov             x1, NULL
    // 0x92b874: r4 = 59
    //     0x92b874: mov             x4, #0x3b
    // 0x92b878: branchIfSmi(r0, 0x92b884)
    //     0x92b878: tbz             w0, #0, #0x92b884
    // 0x92b87c: r4 = LoadClassIdInstr(r0)
    //     0x92b87c: ldur            x4, [x0, #-1]
    //     0x92b880: ubfx            x4, x4, #0xc, #0x14
    // 0x92b884: sub             x4, x4, #0x5d
    // 0x92b888: cmp             x4, #3
    // 0x92b88c: b.ls            #0x92b8a0
    // 0x92b890: r8 = String
    //     0x92b890: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92b894: r3 = Null
    //     0x92b894: add             x3, PP, #0x33, lsl #12  ; [pp+0x33cf8] Null
    //     0x92b898: ldr             x3, [x3, #0xcf8]
    // 0x92b89c: r0 = String()
    //     0x92b89c: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92b8a0: ldr             x1, [fp, #0x10]
    // 0x92b8a4: r0 = LoadClassIdInstr(r1)
    //     0x92b8a4: ldur            x0, [x1, #-1]
    //     0x92b8a8: ubfx            x0, x0, #0xc, #0x14
    // 0x92b8ac: r16 = "supported32BitAbis"
    //     0x92b8ac: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e00] "supported32BitAbis"
    //     0x92b8b0: ldr             x16, [x16, #0xe00]
    // 0x92b8b4: stp             x16, x1, [SP, #-0x10]!
    // 0x92b8b8: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b8b8: sub             lr, x0, #0xef
    //     0x92b8bc: ldr             lr, [x21, lr, lsl #3]
    //     0x92b8c0: blr             lr
    // 0x92b8c4: add             SP, SP, #0x10
    // 0x92b8c8: cmp             w0, NULL
    // 0x92b8cc: b.ne            #0x92b8e8
    // 0x92b8d0: r16 = <String>
    //     0x92b8d0: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92b8d4: stp             xzr, x16, [SP, #-0x10]!
    // 0x92b8d8: r0 = _GrowableList()
    //     0x92b8d8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x92b8dc: add             SP, SP, #0x10
    // 0x92b8e0: mov             x4, x0
    // 0x92b8e4: b               #0x92b8ec
    // 0x92b8e8: mov             x4, x0
    // 0x92b8ec: ldr             x3, [fp, #0x10]
    // 0x92b8f0: mov             x0, x4
    // 0x92b8f4: stur            x4, [fp, #-0x10]
    // 0x92b8f8: r2 = Null
    //     0x92b8f8: mov             x2, NULL
    // 0x92b8fc: r1 = Null
    //     0x92b8fc: mov             x1, NULL
    // 0x92b900: r4 = 59
    //     0x92b900: mov             x4, #0x3b
    // 0x92b904: branchIfSmi(r0, 0x92b910)
    //     0x92b904: tbz             w0, #0, #0x92b910
    // 0x92b908: r4 = LoadClassIdInstr(r0)
    //     0x92b908: ldur            x4, [x0, #-1]
    //     0x92b90c: ubfx            x4, x4, #0xc, #0x14
    // 0x92b910: sub             x4, x4, #0x59
    // 0x92b914: cmp             x4, #2
    // 0x92b918: b.ls            #0x92b92c
    // 0x92b91c: r8 = List
    //     0x92b91c: ldr             x8, [PP, #0x2248]  ; [pp+0x2248] Type: List
    // 0x92b920: r3 = Null
    //     0x92b920: add             x3, PP, #0x33, lsl #12  ; [pp+0x33d08] Null
    //     0x92b924: ldr             x3, [x3, #0xd08]
    // 0x92b928: r0 = List()
    //     0x92b928: bl              #0xd74840  ; IsType_List_Stub
    // 0x92b92c: ldur            x16, [fp, #-0x10]
    // 0x92b930: SaveReg r16
    //     0x92b930: str             x16, [SP, #-8]!
    // 0x92b934: r0 = _fromList()
    //     0x92b934: bl              #0x92c0b8  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0x92b938: add             SP, SP, #8
    // 0x92b93c: mov             x2, x0
    // 0x92b940: ldr             x1, [fp, #0x10]
    // 0x92b944: stur            x2, [fp, #-0x10]
    // 0x92b948: r0 = LoadClassIdInstr(r1)
    //     0x92b948: ldur            x0, [x1, #-1]
    //     0x92b94c: ubfx            x0, x0, #0xc, #0x14
    // 0x92b950: r16 = "supported64BitAbis"
    //     0x92b950: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e08] "supported64BitAbis"
    //     0x92b954: ldr             x16, [x16, #0xe08]
    // 0x92b958: stp             x16, x1, [SP, #-0x10]!
    // 0x92b95c: r0 = GDT[cid_x0 + -0xef]()
    //     0x92b95c: sub             lr, x0, #0xef
    //     0x92b960: ldr             lr, [x21, lr, lsl #3]
    //     0x92b964: blr             lr
    // 0x92b968: add             SP, SP, #0x10
    // 0x92b96c: cmp             w0, NULL
    // 0x92b970: b.ne            #0x92b98c
    // 0x92b974: r16 = <String>
    //     0x92b974: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92b978: stp             xzr, x16, [SP, #-0x10]!
    // 0x92b97c: r0 = _GrowableList()
    //     0x92b97c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x92b980: add             SP, SP, #0x10
    // 0x92b984: mov             x4, x0
    // 0x92b988: b               #0x92b990
    // 0x92b98c: mov             x4, x0
    // 0x92b990: ldr             x3, [fp, #0x10]
    // 0x92b994: mov             x0, x4
    // 0x92b998: stur            x4, [fp, #-0x18]
    // 0x92b99c: r2 = Null
    //     0x92b99c: mov             x2, NULL
    // 0x92b9a0: r1 = Null
    //     0x92b9a0: mov             x1, NULL
    // 0x92b9a4: r4 = 59
    //     0x92b9a4: mov             x4, #0x3b
    // 0x92b9a8: branchIfSmi(r0, 0x92b9b4)
    //     0x92b9a8: tbz             w0, #0, #0x92b9b4
    // 0x92b9ac: r4 = LoadClassIdInstr(r0)
    //     0x92b9ac: ldur            x4, [x0, #-1]
    //     0x92b9b0: ubfx            x4, x4, #0xc, #0x14
    // 0x92b9b4: sub             x4, x4, #0x59
    // 0x92b9b8: cmp             x4, #2
    // 0x92b9bc: b.ls            #0x92b9d0
    // 0x92b9c0: r8 = List
    //     0x92b9c0: ldr             x8, [PP, #0x2248]  ; [pp+0x2248] Type: List
    // 0x92b9c4: r3 = Null
    //     0x92b9c4: add             x3, PP, #0x33, lsl #12  ; [pp+0x33d18] Null
    //     0x92b9c8: ldr             x3, [x3, #0xd18]
    // 0x92b9cc: r0 = List()
    //     0x92b9cc: bl              #0xd74840  ; IsType_List_Stub
    // 0x92b9d0: ldur            x16, [fp, #-0x18]
    // 0x92b9d4: SaveReg r16
    //     0x92b9d4: str             x16, [SP, #-8]!
    // 0x92b9d8: r0 = _fromList()
    //     0x92b9d8: bl              #0x92c0b8  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0x92b9dc: add             SP, SP, #8
    // 0x92b9e0: mov             x2, x0
    // 0x92b9e4: ldr             x1, [fp, #0x10]
    // 0x92b9e8: stur            x2, [fp, #-0x18]
    // 0x92b9ec: r0 = LoadClassIdInstr(r1)
    //     0x92b9ec: ldur            x0, [x1, #-1]
    //     0x92b9f0: ubfx            x0, x0, #0xc, #0x14
    // 0x92b9f4: r16 = "supportedAbis"
    //     0x92b9f4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e10] "supportedAbis"
    //     0x92b9f8: ldr             x16, [x16, #0xe10]
    // 0x92b9fc: stp             x16, x1, [SP, #-0x10]!
    // 0x92ba00: r0 = GDT[cid_x0 + -0xef]()
    //     0x92ba00: sub             lr, x0, #0xef
    //     0x92ba04: ldr             lr, [x21, lr, lsl #3]
    //     0x92ba08: blr             lr
    // 0x92ba0c: add             SP, SP, #0x10
    // 0x92ba10: cmp             w0, NULL
    // 0x92ba14: b.ne            #0x92ba2c
    // 0x92ba18: stp             xzr, NULL, [SP, #-0x10]!
    // 0x92ba1c: r0 = _GrowableList()
    //     0x92ba1c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x92ba20: add             SP, SP, #0x10
    // 0x92ba24: mov             x4, x0
    // 0x92ba28: b               #0x92ba30
    // 0x92ba2c: mov             x4, x0
    // 0x92ba30: ldr             x3, [fp, #0x10]
    // 0x92ba34: mov             x0, x4
    // 0x92ba38: stur            x4, [fp, #-0x20]
    // 0x92ba3c: r2 = Null
    //     0x92ba3c: mov             x2, NULL
    // 0x92ba40: r1 = Null
    //     0x92ba40: mov             x1, NULL
    // 0x92ba44: r4 = 59
    //     0x92ba44: mov             x4, #0x3b
    // 0x92ba48: branchIfSmi(r0, 0x92ba54)
    //     0x92ba48: tbz             w0, #0, #0x92ba54
    // 0x92ba4c: r4 = LoadClassIdInstr(r0)
    //     0x92ba4c: ldur            x4, [x0, #-1]
    //     0x92ba50: ubfx            x4, x4, #0xc, #0x14
    // 0x92ba54: sub             x4, x4, #0x59
    // 0x92ba58: cmp             x4, #2
    // 0x92ba5c: b.ls            #0x92ba70
    // 0x92ba60: r8 = List
    //     0x92ba60: ldr             x8, [PP, #0x2248]  ; [pp+0x2248] Type: List
    // 0x92ba64: r3 = Null
    //     0x92ba64: add             x3, PP, #0x33, lsl #12  ; [pp+0x33d28] Null
    //     0x92ba68: ldr             x3, [x3, #0xd28]
    // 0x92ba6c: r0 = List()
    //     0x92ba6c: bl              #0xd74840  ; IsType_List_Stub
    // 0x92ba70: ldur            x16, [fp, #-0x20]
    // 0x92ba74: SaveReg r16
    //     0x92ba74: str             x16, [SP, #-8]!
    // 0x92ba78: r0 = _fromList()
    //     0x92ba78: bl              #0x92c0b8  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0x92ba7c: add             SP, SP, #8
    // 0x92ba80: mov             x2, x0
    // 0x92ba84: ldr             x1, [fp, #0x10]
    // 0x92ba88: stur            x2, [fp, #-0x20]
    // 0x92ba8c: r0 = LoadClassIdInstr(r1)
    //     0x92ba8c: ldur            x0, [x1, #-1]
    //     0x92ba90: ubfx            x0, x0, #0xc, #0x14
    // 0x92ba94: r16 = "tags"
    //     0x92ba94: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e18] "tags"
    //     0x92ba98: ldr             x16, [x16, #0xe18]
    // 0x92ba9c: stp             x16, x1, [SP, #-0x10]!
    // 0x92baa0: r0 = GDT[cid_x0 + -0xef]()
    //     0x92baa0: sub             lr, x0, #0xef
    //     0x92baa4: ldr             lr, [x21, lr, lsl #3]
    //     0x92baa8: blr             lr
    // 0x92baac: add             SP, SP, #0x10
    // 0x92bab0: r2 = Null
    //     0x92bab0: mov             x2, NULL
    // 0x92bab4: r1 = Null
    //     0x92bab4: mov             x1, NULL
    // 0x92bab8: r4 = 59
    //     0x92bab8: mov             x4, #0x3b
    // 0x92babc: branchIfSmi(r0, 0x92bac8)
    //     0x92babc: tbz             w0, #0, #0x92bac8
    // 0x92bac0: r4 = LoadClassIdInstr(r0)
    //     0x92bac0: ldur            x4, [x0, #-1]
    //     0x92bac4: ubfx            x4, x4, #0xc, #0x14
    // 0x92bac8: sub             x4, x4, #0x5d
    // 0x92bacc: cmp             x4, #3
    // 0x92bad0: b.ls            #0x92bae4
    // 0x92bad4: r8 = String
    //     0x92bad4: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92bad8: r3 = Null
    //     0x92bad8: add             x3, PP, #0x33, lsl #12  ; [pp+0x33d38] Null
    //     0x92badc: ldr             x3, [x3, #0xd38]
    // 0x92bae0: r0 = String()
    //     0x92bae0: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92bae4: ldr             x1, [fp, #0x10]
    // 0x92bae8: r0 = LoadClassIdInstr(r1)
    //     0x92bae8: ldur            x0, [x1, #-1]
    //     0x92baec: ubfx            x0, x0, #0xc, #0x14
    // 0x92baf0: r16 = "type"
    //     0x92baf0: ldr             x16, [PP, #0x1db8]  ; [pp+0x1db8] "type"
    // 0x92baf4: stp             x16, x1, [SP, #-0x10]!
    // 0x92baf8: r0 = GDT[cid_x0 + -0xef]()
    //     0x92baf8: sub             lr, x0, #0xef
    //     0x92bafc: ldr             lr, [x21, lr, lsl #3]
    //     0x92bb00: blr             lr
    // 0x92bb04: add             SP, SP, #0x10
    // 0x92bb08: r2 = Null
    //     0x92bb08: mov             x2, NULL
    // 0x92bb0c: r1 = Null
    //     0x92bb0c: mov             x1, NULL
    // 0x92bb10: r4 = 59
    //     0x92bb10: mov             x4, #0x3b
    // 0x92bb14: branchIfSmi(r0, 0x92bb20)
    //     0x92bb14: tbz             w0, #0, #0x92bb20
    // 0x92bb18: r4 = LoadClassIdInstr(r0)
    //     0x92bb18: ldur            x4, [x0, #-1]
    //     0x92bb1c: ubfx            x4, x4, #0xc, #0x14
    // 0x92bb20: sub             x4, x4, #0x5d
    // 0x92bb24: cmp             x4, #3
    // 0x92bb28: b.ls            #0x92bb3c
    // 0x92bb2c: r8 = String
    //     0x92bb2c: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92bb30: r3 = Null
    //     0x92bb30: add             x3, PP, #0x33, lsl #12  ; [pp+0x33d48] Null
    //     0x92bb34: ldr             x3, [x3, #0xd48]
    // 0x92bb38: r0 = String()
    //     0x92bb38: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92bb3c: ldr             x1, [fp, #0x10]
    // 0x92bb40: r0 = LoadClassIdInstr(r1)
    //     0x92bb40: ldur            x0, [x1, #-1]
    //     0x92bb44: ubfx            x0, x0, #0xc, #0x14
    // 0x92bb48: r16 = "isPhysicalDevice"
    //     0x92bb48: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c08] "isPhysicalDevice"
    //     0x92bb4c: ldr             x16, [x16, #0xc08]
    // 0x92bb50: stp             x16, x1, [SP, #-0x10]!
    // 0x92bb54: r0 = GDT[cid_x0 + -0xef]()
    //     0x92bb54: sub             lr, x0, #0xef
    //     0x92bb58: ldr             lr, [x21, lr, lsl #3]
    //     0x92bb5c: blr             lr
    // 0x92bb60: add             SP, SP, #0x10
    // 0x92bb64: r2 = Null
    //     0x92bb64: mov             x2, NULL
    // 0x92bb68: r1 = Null
    //     0x92bb68: mov             x1, NULL
    // 0x92bb6c: r4 = 59
    //     0x92bb6c: mov             x4, #0x3b
    // 0x92bb70: branchIfSmi(r0, 0x92bb7c)
    //     0x92bb70: tbz             w0, #0, #0x92bb7c
    // 0x92bb74: r4 = LoadClassIdInstr(r0)
    //     0x92bb74: ldur            x4, [x0, #-1]
    //     0x92bb78: ubfx            x4, x4, #0xc, #0x14
    // 0x92bb7c: cmp             x4, #0x3e
    // 0x92bb80: b.eq            #0x92bb94
    // 0x92bb84: r8 = bool
    //     0x92bb84: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0x92bb88: r3 = Null
    //     0x92bb88: add             x3, PP, #0x33, lsl #12  ; [pp+0x33d58] Null
    //     0x92bb8c: ldr             x3, [x3, #0xd58]
    // 0x92bb90: r0 = bool()
    //     0x92bb90: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0x92bb94: ldr             x1, [fp, #0x10]
    // 0x92bb98: r0 = LoadClassIdInstr(r1)
    //     0x92bb98: ldur            x0, [x1, #-1]
    //     0x92bb9c: ubfx            x0, x0, #0xc, #0x14
    // 0x92bba0: r16 = "systemFeatures"
    //     0x92bba0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e68] "systemFeatures"
    //     0x92bba4: ldr             x16, [x16, #0xe68]
    // 0x92bba8: stp             x16, x1, [SP, #-0x10]!
    // 0x92bbac: r0 = GDT[cid_x0 + -0xef]()
    //     0x92bbac: sub             lr, x0, #0xef
    //     0x92bbb0: ldr             lr, [x21, lr, lsl #3]
    //     0x92bbb4: blr             lr
    // 0x92bbb8: add             SP, SP, #0x10
    // 0x92bbbc: cmp             w0, NULL
    // 0x92bbc0: b.ne            #0x92bbd8
    // 0x92bbc4: stp             xzr, NULL, [SP, #-0x10]!
    // 0x92bbc8: r0 = _GrowableList()
    //     0x92bbc8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x92bbcc: add             SP, SP, #0x10
    // 0x92bbd0: mov             x4, x0
    // 0x92bbd4: b               #0x92bbdc
    // 0x92bbd8: mov             x4, x0
    // 0x92bbdc: ldr             x3, [fp, #0x10]
    // 0x92bbe0: mov             x0, x4
    // 0x92bbe4: stur            x4, [fp, #-0x28]
    // 0x92bbe8: r2 = Null
    //     0x92bbe8: mov             x2, NULL
    // 0x92bbec: r1 = Null
    //     0x92bbec: mov             x1, NULL
    // 0x92bbf0: r4 = 59
    //     0x92bbf0: mov             x4, #0x3b
    // 0x92bbf4: branchIfSmi(r0, 0x92bc00)
    //     0x92bbf4: tbz             w0, #0, #0x92bc00
    // 0x92bbf8: r4 = LoadClassIdInstr(r0)
    //     0x92bbf8: ldur            x4, [x0, #-1]
    //     0x92bbfc: ubfx            x4, x4, #0xc, #0x14
    // 0x92bc00: sub             x4, x4, #0x59
    // 0x92bc04: cmp             x4, #2
    // 0x92bc08: b.ls            #0x92bc1c
    // 0x92bc0c: r8 = List
    //     0x92bc0c: ldr             x8, [PP, #0x2248]  ; [pp+0x2248] Type: List
    // 0x92bc10: r3 = Null
    //     0x92bc10: add             x3, PP, #0x33, lsl #12  ; [pp+0x33d68] Null
    //     0x92bc14: ldr             x3, [x3, #0xd68]
    // 0x92bc18: r0 = List()
    //     0x92bc18: bl              #0xd74840  ; IsType_List_Stub
    // 0x92bc1c: ldur            x16, [fp, #-0x28]
    // 0x92bc20: SaveReg r16
    //     0x92bc20: str             x16, [SP, #-8]!
    // 0x92bc24: r0 = _fromList()
    //     0x92bc24: bl              #0x92c0b8  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0x92bc28: add             SP, SP, #8
    // 0x92bc2c: mov             x2, x0
    // 0x92bc30: ldr             x1, [fp, #0x10]
    // 0x92bc34: stur            x2, [fp, #-0x28]
    // 0x92bc38: r0 = LoadClassIdInstr(r1)
    //     0x92bc38: ldur            x0, [x1, #-1]
    //     0x92bc3c: ubfx            x0, x0, #0xc, #0x14
    // 0x92bc40: r16 = "displayMetrics"
    //     0x92bc40: add             x16, PP, #0x33, lsl #12  ; [pp+0x33d78] "displayMetrics"
    //     0x92bc44: ldr             x16, [x16, #0xd78]
    // 0x92bc48: stp             x16, x1, [SP, #-0x10]!
    // 0x92bc4c: r0 = GDT[cid_x0 + -0xef]()
    //     0x92bc4c: sub             lr, x0, #0xef
    //     0x92bc50: ldr             lr, [x21, lr, lsl #3]
    //     0x92bc54: blr             lr
    // 0x92bc58: add             SP, SP, #0x10
    // 0x92bc5c: cmp             w0, NULL
    // 0x92bc60: b.ne            #0x92bc6c
    // 0x92bc64: r0 = Null
    //     0x92bc64: mov             x0, NULL
    // 0x92bc68: b               #0x92bc90
    // 0x92bc6c: r16 = <String, dynamic>
    //     0x92bc6c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x92bc70: stp             x0, x16, [SP, #-0x10]!
    // 0x92bc74: r4 = 0
    //     0x92bc74: mov             x4, #0
    // 0x92bc78: ldr             x0, [SP]
    // 0x92bc7c: r16 = UnlinkedCall_0x4aeefc
    //     0x92bc7c: add             x16, PP, #0x33, lsl #12  ; [pp+0x33d80] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x92bc80: add             x16, x16, #0xd80
    // 0x92bc84: ldp             x5, lr, [x16]
    // 0x92bc88: blr             lr
    // 0x92bc8c: add             SP, SP, #0x10
    // 0x92bc90: cmp             w0, NULL
    // 0x92bc94: b.ne            #0x92bcb4
    // 0x92bc98: r16 = <String, dynamic>
    //     0x92bc98: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x92bc9c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x92bca0: stp             lr, x16, [SP, #-0x10]!
    // 0x92bca4: r0 = Map._fromLiteral()
    //     0x92bca4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x92bca8: add             SP, SP, #0x10
    // 0x92bcac: mov             x4, x0
    // 0x92bcb0: b               #0x92bcb8
    // 0x92bcb4: mov             x4, x0
    // 0x92bcb8: ldr             x3, [fp, #0x10]
    // 0x92bcbc: mov             x0, x4
    // 0x92bcc0: stur            x4, [fp, #-0x30]
    // 0x92bcc4: r2 = Null
    //     0x92bcc4: mov             x2, NULL
    // 0x92bcc8: r1 = Null
    //     0x92bcc8: mov             x1, NULL
    // 0x92bccc: r8 = Map<String, dynamic>
    //     0x92bccc: ldr             x8, [PP, #0x3da0]  ; [pp+0x3da0] Type: Map<String, dynamic>
    // 0x92bcd0: r3 = Null
    //     0x92bcd0: add             x3, PP, #0x33, lsl #12  ; [pp+0x33d90] Null
    //     0x92bcd4: ldr             x3, [x3, #0xd90]
    // 0x92bcd8: r0 = Map<String, dynamic>()
    //     0x92bcd8: bl              #0x4e3b2c  ; IsType_Map<String, dynamic>_Stub
    // 0x92bcdc: ldur            x16, [fp, #-0x30]
    // 0x92bce0: SaveReg r16
    //     0x92bce0: str             x16, [SP, #-8]!
    // 0x92bce4: r0 = _fromMap()
    //     0x92bce4: bl              #0x92bf1c  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDisplayMetrics::_fromMap
    // 0x92bce8: add             SP, SP, #8
    // 0x92bcec: ldr             x1, [fp, #0x10]
    // 0x92bcf0: r0 = LoadClassIdInstr(r1)
    //     0x92bcf0: ldur            x0, [x1, #-1]
    //     0x92bcf4: ubfx            x0, x0, #0xc, #0x14
    // 0x92bcf8: r16 = "serialNumber"
    //     0x92bcf8: add             x16, PP, #0x33, lsl #12  ; [pp+0x33da0] "serialNumber"
    //     0x92bcfc: ldr             x16, [x16, #0xda0]
    // 0x92bd00: stp             x16, x1, [SP, #-0x10]!
    // 0x92bd04: r0 = GDT[cid_x0 + -0xef]()
    //     0x92bd04: sub             lr, x0, #0xef
    //     0x92bd08: ldr             lr, [x21, lr, lsl #3]
    //     0x92bd0c: blr             lr
    // 0x92bd10: add             SP, SP, #0x10
    // 0x92bd14: r2 = Null
    //     0x92bd14: mov             x2, NULL
    // 0x92bd18: r1 = Null
    //     0x92bd18: mov             x1, NULL
    // 0x92bd1c: r4 = 59
    //     0x92bd1c: mov             x4, #0x3b
    // 0x92bd20: branchIfSmi(r0, 0x92bd2c)
    //     0x92bd20: tbz             w0, #0, #0x92bd2c
    // 0x92bd24: r4 = LoadClassIdInstr(r0)
    //     0x92bd24: ldur            x4, [x0, #-1]
    //     0x92bd28: ubfx            x4, x4, #0xc, #0x14
    // 0x92bd2c: sub             x4, x4, #0x5d
    // 0x92bd30: cmp             x4, #3
    // 0x92bd34: b.ls            #0x92bd48
    // 0x92bd38: r8 = String
    //     0x92bd38: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x92bd3c: r3 = Null
    //     0x92bd3c: add             x3, PP, #0x33, lsl #12  ; [pp+0x33da8] Null
    //     0x92bd40: ldr             x3, [x3, #0xda8]
    // 0x92bd44: r0 = String()
    //     0x92bd44: bl              #0xd72afc  ; IsType_String_Stub
    // 0x92bd48: r0 = AndroidDeviceInfo()
    //     0x92bd48: bl              #0x92bf10  ; AllocateAndroidDeviceInfoStub -> AndroidDeviceInfo (size=0x10)
    // 0x92bd4c: stur            x0, [fp, #-0x30]
    // 0x92bd50: ldr             x16, [fp, #0x10]
    // 0x92bd54: stp             x16, x0, [SP, #-0x10]!
    // 0x92bd58: ldur            x16, [fp, #-0x10]
    // 0x92bd5c: ldur            lr, [fp, #-0x18]
    // 0x92bd60: stp             lr, x16, [SP, #-0x10]!
    // 0x92bd64: ldur            x16, [fp, #-0x20]
    // 0x92bd68: ldur            lr, [fp, #-0x28]
    // 0x92bd6c: stp             lr, x16, [SP, #-0x10]!
    // 0x92bd70: ldur            x16, [fp, #-8]
    // 0x92bd74: SaveReg r16
    //     0x92bd74: str             x16, [SP, #-8]!
    // 0x92bd78: r0 = AndroidDeviceInfo._()
    //     0x92bd78: bl              #0x92bdcc  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::AndroidDeviceInfo._
    // 0x92bd7c: add             SP, SP, #0x38
    // 0x92bd80: ldur            x0, [fp, #-0x30]
    // 0x92bd84: LeaveFrame
    //     0x92bd84: mov             SP, fp
    //     0x92bd88: ldp             fp, lr, [SP], #0x10
    // 0x92bd8c: ret
    //     0x92bd8c: ret             
    // 0x92bd90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92bd90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92bd94: b               #0x92b39c
  }
  _ AndroidDeviceInfo._(/* No info */) {
    // ** addr: 0x92bdcc, size: 0x144
    // 0x92bdcc: EnterFrame
    //     0x92bdcc: stp             fp, lr, [SP, #-0x10]!
    //     0x92bdd0: mov             fp, SP
    // 0x92bdd4: CheckStackOverflow
    //     0x92bdd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92bdd8: cmp             SP, x16
    //     0x92bddc: b.ls            #0x92bf08
    // 0x92bde0: ldr             x0, [fp, #0x10]
    // 0x92bde4: ldr             x1, [fp, #0x40]
    // 0x92bde8: StoreField: r1->field_b = r0
    //     0x92bde8: stur            w0, [x1, #0xb]
    //     0x92bdec: ldurb           w16, [x1, #-1]
    //     0x92bdf0: ldurb           w17, [x0, #-1]
    //     0x92bdf4: and             x16, x17, x16, lsr #2
    //     0x92bdf8: tst             x16, HEAP, lsr #32
    //     0x92bdfc: b.eq            #0x92be04
    //     0x92be00: bl              #0xd6826c
    // 0x92be04: r16 = <String>
    //     0x92be04: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92be08: ldr             lr, [fp, #0x30]
    // 0x92be0c: stp             lr, x16, [SP, #-0x10]!
    // 0x92be10: r16 = false
    //     0x92be10: add             x16, NULL, #0x30  ; false
    // 0x92be14: SaveReg r16
    //     0x92be14: str             x16, [SP, #-8]!
    // 0x92be18: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0x92be18: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0x92be1c: r0 = List.from()
    //     0x92be1c: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0x92be20: add             SP, SP, #0x18
    // 0x92be24: r16 = <String>
    //     0x92be24: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92be28: stp             x0, x16, [SP, #-0x10]!
    // 0x92be2c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92be2c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92be30: r0 = makeFixedListUnmodifiable()
    //     0x92be30: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0x92be34: add             SP, SP, #0x10
    // 0x92be38: r16 = <String>
    //     0x92be38: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92be3c: ldr             lr, [fp, #0x28]
    // 0x92be40: stp             lr, x16, [SP, #-0x10]!
    // 0x92be44: r16 = false
    //     0x92be44: add             x16, NULL, #0x30  ; false
    // 0x92be48: SaveReg r16
    //     0x92be48: str             x16, [SP, #-8]!
    // 0x92be4c: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0x92be4c: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0x92be50: r0 = List.from()
    //     0x92be50: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0x92be54: add             SP, SP, #0x18
    // 0x92be58: r16 = <String>
    //     0x92be58: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92be5c: stp             x0, x16, [SP, #-0x10]!
    // 0x92be60: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92be60: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92be64: r0 = makeFixedListUnmodifiable()
    //     0x92be64: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0x92be68: add             SP, SP, #0x10
    // 0x92be6c: r16 = <String>
    //     0x92be6c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92be70: ldr             lr, [fp, #0x20]
    // 0x92be74: stp             lr, x16, [SP, #-0x10]!
    // 0x92be78: r16 = false
    //     0x92be78: add             x16, NULL, #0x30  ; false
    // 0x92be7c: SaveReg r16
    //     0x92be7c: str             x16, [SP, #-8]!
    // 0x92be80: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0x92be80: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0x92be84: r0 = List.from()
    //     0x92be84: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0x92be88: add             SP, SP, #0x18
    // 0x92be8c: r16 = <String>
    //     0x92be8c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92be90: stp             x0, x16, [SP, #-0x10]!
    // 0x92be94: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92be94: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92be98: r0 = makeFixedListUnmodifiable()
    //     0x92be98: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0x92be9c: add             SP, SP, #0x10
    // 0x92bea0: r16 = <String>
    //     0x92bea0: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92bea4: ldr             lr, [fp, #0x18]
    // 0x92bea8: stp             lr, x16, [SP, #-0x10]!
    // 0x92beac: r16 = false
    //     0x92beac: add             x16, NULL, #0x30  ; false
    // 0x92beb0: SaveReg r16
    //     0x92beb0: str             x16, [SP, #-8]!
    // 0x92beb4: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0x92beb4: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0x92beb8: r0 = List.from()
    //     0x92beb8: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0x92bebc: add             SP, SP, #0x18
    // 0x92bec0: r16 = <String>
    //     0x92bec0: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92bec4: stp             x0, x16, [SP, #-0x10]!
    // 0x92bec8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92bec8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92becc: r0 = makeFixedListUnmodifiable()
    //     0x92becc: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0x92bed0: add             SP, SP, #0x10
    // 0x92bed4: ldr             x0, [fp, #0x38]
    // 0x92bed8: ldr             x1, [fp, #0x40]
    // 0x92bedc: StoreField: r1->field_7 = r0
    //     0x92bedc: stur            w0, [x1, #7]
    //     0x92bee0: ldurb           w16, [x1, #-1]
    //     0x92bee4: ldurb           w17, [x0, #-1]
    //     0x92bee8: and             x16, x17, x16, lsr #2
    //     0x92beec: tst             x16, HEAP, lsr #32
    //     0x92bef0: b.eq            #0x92bef8
    //     0x92bef4: bl              #0xd6826c
    // 0x92bef8: r0 = Null
    //     0x92bef8: mov             x0, NULL
    // 0x92befc: LeaveFrame
    //     0x92befc: mov             SP, fp
    //     0x92bf00: ldp             fp, lr, [SP], #0x10
    // 0x92bf04: ret
    //     0x92bf04: ret             
    // 0x92bf08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92bf08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92bf0c: b               #0x92bde0
  }
  static _ _fromList(/* No info */) {
    // ** addr: 0x92c0b8, size: 0x8c
    // 0x92c0b8: EnterFrame
    //     0x92c0b8: stp             fp, lr, [SP, #-0x10]!
    //     0x92c0bc: mov             fp, SP
    // 0x92c0c0: CheckStackOverflow
    //     0x92c0c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92c0c4: cmp             SP, x16
    //     0x92c0c8: b.ls            #0x92c13c
    // 0x92c0cc: r1 = Function '<anonymous closure>': static.
    //     0x92c0cc: add             x1, PP, #0x33, lsl #12  ; [pp+0x33e18] AnonymousClosure: (0x7b22e8), in [package:flutter/src/material/ink_well.dart] _InkResponseState::highlightsExist (0x7b224c)
    //     0x92c0d0: ldr             x1, [x1, #0xe18]
    // 0x92c0d4: r2 = Null
    //     0x92c0d4: mov             x2, NULL
    // 0x92c0d8: r0 = AllocateClosure()
    //     0x92c0d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x92c0dc: mov             x1, x0
    // 0x92c0e0: ldr             x0, [fp, #0x10]
    // 0x92c0e4: r2 = LoadClassIdInstr(r0)
    //     0x92c0e4: ldur            x2, [x0, #-1]
    //     0x92c0e8: ubfx            x2, x2, #0xc, #0x14
    // 0x92c0ec: stp             x1, x0, [SP, #-0x10]!
    // 0x92c0f0: mov             x0, x2
    // 0x92c0f4: r0 = GDT[cid_x0 + 0x10854]()
    //     0x92c0f4: mov             x17, #0x854
    //     0x92c0f8: movk            x17, #1, lsl #16
    //     0x92c0fc: add             lr, x0, x17
    //     0x92c100: ldr             lr, [x21, lr, lsl #3]
    //     0x92c104: blr             lr
    // 0x92c108: add             SP, SP, #0x10
    // 0x92c10c: SaveReg r0
    //     0x92c10c: str             x0, [SP, #-8]!
    // 0x92c110: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x92c110: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x92c114: r0 = toList()
    //     0x92c114: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x92c118: add             SP, SP, #8
    // 0x92c11c: r16 = <String>
    //     0x92c11c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x92c120: stp             x0, x16, [SP, #-0x10]!
    // 0x92c124: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x92c124: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x92c128: r0 = List.from()
    //     0x92c128: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0x92c12c: add             SP, SP, #0x10
    // 0x92c130: LeaveFrame
    //     0x92c130: mov             SP, fp
    //     0x92c134: ldp             fp, lr, [SP], #0x10
    // 0x92c138: ret
    //     0x92c138: ret             
    // 0x92c13c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92c13c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92c140: b               #0x92c0cc
  }
}

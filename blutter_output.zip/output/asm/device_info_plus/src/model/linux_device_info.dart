// lib: , url: package:device_info_plus/src/model/linux_device_info.dart

// class id: 1048871, size: 0x8
class :: {
}

// class id: 4555, size: 0x34, field offset: 0x8
class LinuxDeviceInfo extends Object
    implements BaseDeviceInfo {

  get _ data(/* No info */) {
    // ** addr: 0xc96294, size: 0x38
    // 0xc96294: EnterFrame
    //     0xc96294: stp             fp, lr, [SP, #-0x10]!
    //     0xc96298: mov             fp, SP
    // 0xc9629c: CheckStackOverflow
    //     0xc9629c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc962a0: cmp             SP, x16
    //     0xc962a4: b.ls            #0xc962c4
    // 0xc962a8: ldr             x16, [fp, #0x10]
    // 0xc962ac: SaveReg r16
    //     0xc962ac: str             x16, [SP, #-8]!
    // 0xc962b0: r0 = toMap()
    //     0xc962b0: bl              #0xc962cc  ; [package:device_info_plus/src/model/linux_device_info.dart] LinuxDeviceInfo::toMap
    // 0xc962b4: add             SP, SP, #8
    // 0xc962b8: LeaveFrame
    //     0xc962b8: mov             SP, fp
    //     0xc962bc: ldp             fp, lr, [SP], #0x10
    // 0xc962c0: ret
    //     0xc962c0: ret             
    // 0xc962c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc962c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc962c8: b               #0xc962a8
  }
  _ toMap(/* No info */) {
    // ** addr: 0xc962cc, size: 0x148
    // 0xc962cc: EnterFrame
    //     0xc962cc: stp             fp, lr, [SP, #-0x10]!
    //     0xc962d0: mov             fp, SP
    // 0xc962d4: CheckStackOverflow
    //     0xc962d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc962d8: cmp             SP, x16
    //     0xc962dc: b.ls            #0xc9640c
    // 0xc962e0: r1 = Null
    //     0xc962e0: mov             x1, NULL
    // 0xc962e4: r2 = 44
    //     0xc962e4: mov             x2, #0x2c
    // 0xc962e8: r0 = AllocateArray()
    //     0xc962e8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc962ec: r17 = "name"
    //     0xc962ec: ldr             x17, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xc962f0: StoreField: r0->field_f = r17
    //     0xc962f0: stur            w17, [x0, #0xf]
    // 0xc962f4: ldr             x1, [fp, #0x10]
    // 0xc962f8: LoadField: r2 = r1->field_7
    //     0xc962f8: ldur            w2, [x1, #7]
    // 0xc962fc: DecompressPointer r2
    //     0xc962fc: add             x2, x2, HEAP, lsl #32
    // 0xc96300: StoreField: r0->field_13 = r2
    //     0xc96300: stur            w2, [x0, #0x13]
    // 0xc96304: r17 = "version"
    //     0xc96304: add             x17, PP, #0xa, lsl #12  ; [pp+0xaca8] "version"
    //     0xc96308: ldr             x17, [x17, #0xca8]
    // 0xc9630c: StoreField: r0->field_17 = r17
    //     0xc9630c: stur            w17, [x0, #0x17]
    // 0xc96310: LoadField: r2 = r1->field_b
    //     0xc96310: ldur            w2, [x1, #0xb]
    // 0xc96314: DecompressPointer r2
    //     0xc96314: add             x2, x2, HEAP, lsl #32
    // 0xc96318: StoreField: r0->field_1b = r2
    //     0xc96318: stur            w2, [x0, #0x1b]
    // 0xc9631c: r17 = "id"
    //     0xc9631c: ldr             x17, [PP, #0x2a60]  ; [pp+0x2a60] "id"
    // 0xc96320: StoreField: r0->field_1f = r17
    //     0xc96320: stur            w17, [x0, #0x1f]
    // 0xc96324: LoadField: r2 = r1->field_f
    //     0xc96324: ldur            w2, [x1, #0xf]
    // 0xc96328: DecompressPointer r2
    //     0xc96328: add             x2, x2, HEAP, lsl #32
    // 0xc9632c: StoreField: r0->field_23 = r2
    //     0xc9632c: stur            w2, [x0, #0x23]
    // 0xc96330: r17 = "idLike"
    //     0xc96330: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c960] "idLike"
    //     0xc96334: ldr             x17, [x17, #0x960]
    // 0xc96338: StoreField: r0->field_27 = r17
    //     0xc96338: stur            w17, [x0, #0x27]
    // 0xc9633c: LoadField: r2 = r1->field_13
    //     0xc9633c: ldur            w2, [x1, #0x13]
    // 0xc96340: DecompressPointer r2
    //     0xc96340: add             x2, x2, HEAP, lsl #32
    // 0xc96344: StoreField: r0->field_2b = r2
    //     0xc96344: stur            w2, [x0, #0x2b]
    // 0xc96348: r17 = "versionCodename"
    //     0xc96348: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c968] "versionCodename"
    //     0xc9634c: ldr             x17, [x17, #0x968]
    // 0xc96350: StoreField: r0->field_2f = r17
    //     0xc96350: stur            w17, [x0, #0x2f]
    // 0xc96354: LoadField: r2 = r1->field_17
    //     0xc96354: ldur            w2, [x1, #0x17]
    // 0xc96358: DecompressPointer r2
    //     0xc96358: add             x2, x2, HEAP, lsl #32
    // 0xc9635c: StoreField: r0->field_33 = r2
    //     0xc9635c: stur            w2, [x0, #0x33]
    // 0xc96360: r17 = "versionId"
    //     0xc96360: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c970] "versionId"
    //     0xc96364: ldr             x17, [x17, #0x970]
    // 0xc96368: StoreField: r0->field_37 = r17
    //     0xc96368: stur            w17, [x0, #0x37]
    // 0xc9636c: LoadField: r2 = r1->field_1b
    //     0xc9636c: ldur            w2, [x1, #0x1b]
    // 0xc96370: DecompressPointer r2
    //     0xc96370: add             x2, x2, HEAP, lsl #32
    // 0xc96374: StoreField: r0->field_3b = r2
    //     0xc96374: stur            w2, [x0, #0x3b]
    // 0xc96378: r17 = "prettyName"
    //     0xc96378: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c978] "prettyName"
    //     0xc9637c: ldr             x17, [x17, #0x978]
    // 0xc96380: StoreField: r0->field_3f = r17
    //     0xc96380: stur            w17, [x0, #0x3f]
    // 0xc96384: LoadField: r2 = r1->field_1f
    //     0xc96384: ldur            w2, [x1, #0x1f]
    // 0xc96388: DecompressPointer r2
    //     0xc96388: add             x2, x2, HEAP, lsl #32
    // 0xc9638c: StoreField: r0->field_43 = r2
    //     0xc9638c: stur            w2, [x0, #0x43]
    // 0xc96390: r17 = "buildId"
    //     0xc96390: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c980] "buildId"
    //     0xc96394: ldr             x17, [x17, #0x980]
    // 0xc96398: StoreField: r0->field_47 = r17
    //     0xc96398: stur            w17, [x0, #0x47]
    // 0xc9639c: LoadField: r2 = r1->field_23
    //     0xc9639c: ldur            w2, [x1, #0x23]
    // 0xc963a0: DecompressPointer r2
    //     0xc963a0: add             x2, x2, HEAP, lsl #32
    // 0xc963a4: StoreField: r0->field_4b = r2
    //     0xc963a4: stur            w2, [x0, #0x4b]
    // 0xc963a8: r17 = "variant"
    //     0xc963a8: add             x17, PP, #0x3d, lsl #12  ; [pp+0x3dbf0] "variant"
    //     0xc963ac: ldr             x17, [x17, #0xbf0]
    // 0xc963b0: StoreField: r0->field_4f = r17
    //     0xc963b0: stur            w17, [x0, #0x4f]
    // 0xc963b4: LoadField: r2 = r1->field_27
    //     0xc963b4: ldur            w2, [x1, #0x27]
    // 0xc963b8: DecompressPointer r2
    //     0xc963b8: add             x2, x2, HEAP, lsl #32
    // 0xc963bc: StoreField: r0->field_53 = r2
    //     0xc963bc: stur            w2, [x0, #0x53]
    // 0xc963c0: r17 = "variantId"
    //     0xc963c0: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c988] "variantId"
    //     0xc963c4: ldr             x17, [x17, #0x988]
    // 0xc963c8: StoreField: r0->field_57 = r17
    //     0xc963c8: stur            w17, [x0, #0x57]
    // 0xc963cc: LoadField: r2 = r1->field_2b
    //     0xc963cc: ldur            w2, [x1, #0x2b]
    // 0xc963d0: DecompressPointer r2
    //     0xc963d0: add             x2, x2, HEAP, lsl #32
    // 0xc963d4: StoreField: r0->field_5b = r2
    //     0xc963d4: stur            w2, [x0, #0x5b]
    // 0xc963d8: r17 = "machineId"
    //     0xc963d8: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c990] "machineId"
    //     0xc963dc: ldr             x17, [x17, #0x990]
    // 0xc963e0: StoreField: r0->field_5f = r17
    //     0xc963e0: stur            w17, [x0, #0x5f]
    // 0xc963e4: LoadField: r2 = r1->field_2f
    //     0xc963e4: ldur            w2, [x1, #0x2f]
    // 0xc963e8: DecompressPointer r2
    //     0xc963e8: add             x2, x2, HEAP, lsl #32
    // 0xc963ec: StoreField: r0->field_63 = r2
    //     0xc963ec: stur            w2, [x0, #0x63]
    // 0xc963f0: r16 = <String, dynamic>
    //     0xc963f0: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc963f4: stp             x0, x16, [SP, #-0x10]!
    // 0xc963f8: r0 = Map._fromLiteral()
    //     0xc963f8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc963fc: add             SP, SP, #0x10
    // 0xc96400: LeaveFrame
    //     0xc96400: mov             SP, fp
    //     0xc96404: ldp             fp, lr, [SP], #0x10
    // 0xc96408: ret
    //     0xc96408: ret             
    // 0xc9640c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9640c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc96410: b               #0xc962e0
  }
}

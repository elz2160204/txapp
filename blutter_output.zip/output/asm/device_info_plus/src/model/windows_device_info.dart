// lib: , url: package:device_info_plus/src/model/windows_device_info.dart

// class id: 1048874, size: 0x8
class :: {
}

// class id: 4554, size: 0x98, field offset: 0x8
class WindowsDeviceInfo extends Object
    implements BaseDeviceInfo {

  get _ data(/* No info */) {
    // ** addr: 0xc96414, size: 0x38
    // 0xc96414: EnterFrame
    //     0xc96414: stp             fp, lr, [SP, #-0x10]!
    //     0xc96418: mov             fp, SP
    // 0xc9641c: CheckStackOverflow
    //     0xc9641c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc96420: cmp             SP, x16
    //     0xc96424: b.ls            #0xc96444
    // 0xc96428: ldr             x16, [fp, #0x10]
    // 0xc9642c: SaveReg r16
    //     0xc9642c: str             x16, [SP, #-8]!
    // 0xc96430: r0 = toMap()
    //     0xc96430: bl              #0xc9644c  ; [package:device_info_plus/src/model/windows_device_info.dart] WindowsDeviceInfo::toMap
    // 0xc96434: add             SP, SP, #8
    // 0xc96438: LeaveFrame
    //     0xc96438: mov             SP, fp
    //     0xc9643c: ldp             fp, lr, [SP], #0x10
    // 0xc96440: ret
    //     0xc96440: ret             
    // 0xc96444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc96444: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc96448: b               #0xc96428
  }
  _ toMap(/* No info */) {
    // ** addr: 0xc9644c, size: 0x6ac
    // 0xc9644c: EnterFrame
    //     0xc9644c: stp             fp, lr, [SP, #-0x10]!
    //     0xc96450: mov             fp, SP
    // 0xc96454: CheckStackOverflow
    //     0xc96454: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc96458: cmp             SP, x16
    //     0xc9645c: b.ls            #0xc96af0
    // 0xc96460: r1 = Null
    //     0xc96460: mov             x1, NULL
    // 0xc96464: r2 = 100
    //     0xc96464: mov             x2, #0x64
    // 0xc96468: r0 = AllocateArray()
    //     0xc96468: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc9646c: mov             x2, x0
    // 0xc96470: r17 = "computerName"
    //     0xc96470: add             x17, PP, #0x41, lsl #12  ; [pp+0x41200] "computerName"
    //     0xc96474: ldr             x17, [x17, #0x200]
    // 0xc96478: StoreField: r2->field_f = r17
    //     0xc96478: stur            w17, [x2, #0xf]
    // 0xc9647c: ldr             x3, [fp, #0x10]
    // 0xc96480: LoadField: r0 = r3->field_7
    //     0xc96480: ldur            w0, [x3, #7]
    // 0xc96484: DecompressPointer r0
    //     0xc96484: add             x0, x0, HEAP, lsl #32
    // 0xc96488: StoreField: r2->field_13 = r0
    //     0xc96488: stur            w0, [x2, #0x13]
    // 0xc9648c: r17 = "numberOfCores"
    //     0xc9648c: add             x17, PP, #0x41, lsl #12  ; [pp+0x41208] "numberOfCores"
    //     0xc96490: ldr             x17, [x17, #0x208]
    // 0xc96494: StoreField: r2->field_17 = r17
    //     0xc96494: stur            w17, [x2, #0x17]
    // 0xc96498: LoadField: r4 = r3->field_b
    //     0xc96498: ldur            x4, [x3, #0xb]
    // 0xc9649c: r0 = BoxInt64Instr(r4)
    //     0xc9649c: sbfiz           x0, x4, #1, #0x1f
    //     0xc964a0: cmp             x4, x0, asr #1
    //     0xc964a4: b.eq            #0xc964b0
    //     0xc964a8: bl              #0xd69bb8
    //     0xc964ac: stur            x4, [x0, #7]
    // 0xc964b0: mov             x1, x2
    // 0xc964b4: ArrayStore: r1[3] = r0  ; List_4
    //     0xc964b4: add             x25, x1, #0x1b
    //     0xc964b8: str             w0, [x25]
    //     0xc964bc: tbz             w0, #0, #0xc964d8
    //     0xc964c0: ldurb           w16, [x1, #-1]
    //     0xc964c4: ldurb           w17, [x0, #-1]
    //     0xc964c8: and             x16, x17, x16, lsr #2
    //     0xc964cc: tst             x16, HEAP, lsr #32
    //     0xc964d0: b.eq            #0xc964d8
    //     0xc964d4: bl              #0xd67e5c
    // 0xc964d8: r17 = "systemMemoryInMegabytes"
    //     0xc964d8: add             x17, PP, #0x41, lsl #12  ; [pp+0x41210] "systemMemoryInMegabytes"
    //     0xc964dc: ldr             x17, [x17, #0x210]
    // 0xc964e0: StoreField: r2->field_1f = r17
    //     0xc964e0: stur            w17, [x2, #0x1f]
    // 0xc964e4: LoadField: r4 = r3->field_13
    //     0xc964e4: ldur            x4, [x3, #0x13]
    // 0xc964e8: r0 = BoxInt64Instr(r4)
    //     0xc964e8: sbfiz           x0, x4, #1, #0x1f
    //     0xc964ec: cmp             x4, x0, asr #1
    //     0xc964f0: b.eq            #0xc964fc
    //     0xc964f4: bl              #0xd69bb8
    //     0xc964f8: stur            x4, [x0, #7]
    // 0xc964fc: mov             x1, x2
    // 0xc96500: ArrayStore: r1[5] = r0  ; List_4
    //     0xc96500: add             x25, x1, #0x23
    //     0xc96504: str             w0, [x25]
    //     0xc96508: tbz             w0, #0, #0xc96524
    //     0xc9650c: ldurb           w16, [x1, #-1]
    //     0xc96510: ldurb           w17, [x0, #-1]
    //     0xc96514: and             x16, x17, x16, lsr #2
    //     0xc96518: tst             x16, HEAP, lsr #32
    //     0xc9651c: b.eq            #0xc96524
    //     0xc96520: bl              #0xd67e5c
    // 0xc96524: r17 = "userName"
    //     0xc96524: add             x17, PP, #0x41, lsl #12  ; [pp+0x41218] "userName"
    //     0xc96528: ldr             x17, [x17, #0x218]
    // 0xc9652c: StoreField: r2->field_27 = r17
    //     0xc9652c: stur            w17, [x2, #0x27]
    // 0xc96530: LoadField: r0 = r3->field_1b
    //     0xc96530: ldur            w0, [x3, #0x1b]
    // 0xc96534: DecompressPointer r0
    //     0xc96534: add             x0, x0, HEAP, lsl #32
    // 0xc96538: mov             x1, x2
    // 0xc9653c: ArrayStore: r1[7] = r0  ; List_4
    //     0xc9653c: add             x25, x1, #0x2b
    //     0xc96540: str             w0, [x25]
    //     0xc96544: tbz             w0, #0, #0xc96560
    //     0xc96548: ldurb           w16, [x1, #-1]
    //     0xc9654c: ldurb           w17, [x0, #-1]
    //     0xc96550: and             x16, x17, x16, lsr #2
    //     0xc96554: tst             x16, HEAP, lsr #32
    //     0xc96558: b.eq            #0xc96560
    //     0xc9655c: bl              #0xd67e5c
    // 0xc96560: r17 = "majorVersion"
    //     0xc96560: add             x17, PP, #0x41, lsl #12  ; [pp+0x41220] "majorVersion"
    //     0xc96564: ldr             x17, [x17, #0x220]
    // 0xc96568: StoreField: r2->field_2f = r17
    //     0xc96568: stur            w17, [x2, #0x2f]
    // 0xc9656c: LoadField: r4 = r3->field_1f
    //     0xc9656c: ldur            x4, [x3, #0x1f]
    // 0xc96570: r0 = BoxInt64Instr(r4)
    //     0xc96570: sbfiz           x0, x4, #1, #0x1f
    //     0xc96574: cmp             x4, x0, asr #1
    //     0xc96578: b.eq            #0xc96584
    //     0xc9657c: bl              #0xd69bb8
    //     0xc96580: stur            x4, [x0, #7]
    // 0xc96584: mov             x1, x2
    // 0xc96588: ArrayStore: r1[9] = r0  ; List_4
    //     0xc96588: add             x25, x1, #0x33
    //     0xc9658c: str             w0, [x25]
    //     0xc96590: tbz             w0, #0, #0xc965ac
    //     0xc96594: ldurb           w16, [x1, #-1]
    //     0xc96598: ldurb           w17, [x0, #-1]
    //     0xc9659c: and             x16, x17, x16, lsr #2
    //     0xc965a0: tst             x16, HEAP, lsr #32
    //     0xc965a4: b.eq            #0xc965ac
    //     0xc965a8: bl              #0xd67e5c
    // 0xc965ac: r17 = "minorVersion"
    //     0xc965ac: add             x17, PP, #0x41, lsl #12  ; [pp+0x41228] "minorVersion"
    //     0xc965b0: ldr             x17, [x17, #0x228]
    // 0xc965b4: StoreField: r2->field_37 = r17
    //     0xc965b4: stur            w17, [x2, #0x37]
    // 0xc965b8: LoadField: r4 = r3->field_27
    //     0xc965b8: ldur            x4, [x3, #0x27]
    // 0xc965bc: r0 = BoxInt64Instr(r4)
    //     0xc965bc: sbfiz           x0, x4, #1, #0x1f
    //     0xc965c0: cmp             x4, x0, asr #1
    //     0xc965c4: b.eq            #0xc965d0
    //     0xc965c8: bl              #0xd69bb8
    //     0xc965cc: stur            x4, [x0, #7]
    // 0xc965d0: mov             x1, x2
    // 0xc965d4: ArrayStore: r1[11] = r0  ; List_4
    //     0xc965d4: add             x25, x1, #0x3b
    //     0xc965d8: str             w0, [x25]
    //     0xc965dc: tbz             w0, #0, #0xc965f8
    //     0xc965e0: ldurb           w16, [x1, #-1]
    //     0xc965e4: ldurb           w17, [x0, #-1]
    //     0xc965e8: and             x16, x17, x16, lsr #2
    //     0xc965ec: tst             x16, HEAP, lsr #32
    //     0xc965f0: b.eq            #0xc965f8
    //     0xc965f4: bl              #0xd67e5c
    // 0xc965f8: r17 = "buildNumber"
    //     0xc965f8: add             x17, PP, #0x41, lsl #12  ; [pp+0x41230] "buildNumber"
    //     0xc965fc: ldr             x17, [x17, #0x230]
    // 0xc96600: StoreField: r2->field_3f = r17
    //     0xc96600: stur            w17, [x2, #0x3f]
    // 0xc96604: LoadField: r4 = r3->field_2f
    //     0xc96604: ldur            x4, [x3, #0x2f]
    // 0xc96608: r0 = BoxInt64Instr(r4)
    //     0xc96608: sbfiz           x0, x4, #1, #0x1f
    //     0xc9660c: cmp             x4, x0, asr #1
    //     0xc96610: b.eq            #0xc9661c
    //     0xc96614: bl              #0xd69bb8
    //     0xc96618: stur            x4, [x0, #7]
    // 0xc9661c: mov             x1, x2
    // 0xc96620: ArrayStore: r1[13] = r0  ; List_4
    //     0xc96620: add             x25, x1, #0x43
    //     0xc96624: str             w0, [x25]
    //     0xc96628: tbz             w0, #0, #0xc96644
    //     0xc9662c: ldurb           w16, [x1, #-1]
    //     0xc96630: ldurb           w17, [x0, #-1]
    //     0xc96634: and             x16, x17, x16, lsr #2
    //     0xc96638: tst             x16, HEAP, lsr #32
    //     0xc9663c: b.eq            #0xc96644
    //     0xc96640: bl              #0xd67e5c
    // 0xc96644: r17 = "platformId"
    //     0xc96644: add             x17, PP, #0x41, lsl #12  ; [pp+0x41238] "platformId"
    //     0xc96648: ldr             x17, [x17, #0x238]
    // 0xc9664c: StoreField: r2->field_47 = r17
    //     0xc9664c: stur            w17, [x2, #0x47]
    // 0xc96650: LoadField: r4 = r3->field_37
    //     0xc96650: ldur            x4, [x3, #0x37]
    // 0xc96654: r0 = BoxInt64Instr(r4)
    //     0xc96654: sbfiz           x0, x4, #1, #0x1f
    //     0xc96658: cmp             x4, x0, asr #1
    //     0xc9665c: b.eq            #0xc96668
    //     0xc96660: bl              #0xd69bb8
    //     0xc96664: stur            x4, [x0, #7]
    // 0xc96668: mov             x1, x2
    // 0xc9666c: ArrayStore: r1[15] = r0  ; List_4
    //     0xc9666c: add             x25, x1, #0x4b
    //     0xc96670: str             w0, [x25]
    //     0xc96674: tbz             w0, #0, #0xc96690
    //     0xc96678: ldurb           w16, [x1, #-1]
    //     0xc9667c: ldurb           w17, [x0, #-1]
    //     0xc96680: and             x16, x17, x16, lsr #2
    //     0xc96684: tst             x16, HEAP, lsr #32
    //     0xc96688: b.eq            #0xc96690
    //     0xc9668c: bl              #0xd67e5c
    // 0xc96690: r17 = "csdVersion"
    //     0xc96690: add             x17, PP, #0x41, lsl #12  ; [pp+0x41240] "csdVersion"
    //     0xc96694: ldr             x17, [x17, #0x240]
    // 0xc96698: StoreField: r2->field_4f = r17
    //     0xc96698: stur            w17, [x2, #0x4f]
    // 0xc9669c: LoadField: r0 = r3->field_3f
    //     0xc9669c: ldur            w0, [x3, #0x3f]
    // 0xc966a0: DecompressPointer r0
    //     0xc966a0: add             x0, x0, HEAP, lsl #32
    // 0xc966a4: mov             x1, x2
    // 0xc966a8: ArrayStore: r1[17] = r0  ; List_4
    //     0xc966a8: add             x25, x1, #0x53
    //     0xc966ac: str             w0, [x25]
    //     0xc966b0: tbz             w0, #0, #0xc966cc
    //     0xc966b4: ldurb           w16, [x1, #-1]
    //     0xc966b8: ldurb           w17, [x0, #-1]
    //     0xc966bc: and             x16, x17, x16, lsr #2
    //     0xc966c0: tst             x16, HEAP, lsr #32
    //     0xc966c4: b.eq            #0xc966cc
    //     0xc966c8: bl              #0xd67e5c
    // 0xc966cc: r17 = "servicePackMajor"
    //     0xc966cc: add             x17, PP, #0x41, lsl #12  ; [pp+0x41248] "servicePackMajor"
    //     0xc966d0: ldr             x17, [x17, #0x248]
    // 0xc966d4: StoreField: r2->field_57 = r17
    //     0xc966d4: stur            w17, [x2, #0x57]
    // 0xc966d8: LoadField: r4 = r3->field_43
    //     0xc966d8: ldur            x4, [x3, #0x43]
    // 0xc966dc: r0 = BoxInt64Instr(r4)
    //     0xc966dc: sbfiz           x0, x4, #1, #0x1f
    //     0xc966e0: cmp             x4, x0, asr #1
    //     0xc966e4: b.eq            #0xc966f0
    //     0xc966e8: bl              #0xd69bb8
    //     0xc966ec: stur            x4, [x0, #7]
    // 0xc966f0: mov             x1, x2
    // 0xc966f4: ArrayStore: r1[19] = r0  ; List_4
    //     0xc966f4: add             x25, x1, #0x5b
    //     0xc966f8: str             w0, [x25]
    //     0xc966fc: tbz             w0, #0, #0xc96718
    //     0xc96700: ldurb           w16, [x1, #-1]
    //     0xc96704: ldurb           w17, [x0, #-1]
    //     0xc96708: and             x16, x17, x16, lsr #2
    //     0xc9670c: tst             x16, HEAP, lsr #32
    //     0xc96710: b.eq            #0xc96718
    //     0xc96714: bl              #0xd67e5c
    // 0xc96718: r17 = "servicePackMinor"
    //     0xc96718: add             x17, PP, #0x41, lsl #12  ; [pp+0x41250] "servicePackMinor"
    //     0xc9671c: ldr             x17, [x17, #0x250]
    // 0xc96720: StoreField: r2->field_5f = r17
    //     0xc96720: stur            w17, [x2, #0x5f]
    // 0xc96724: LoadField: r4 = r3->field_4b
    //     0xc96724: ldur            x4, [x3, #0x4b]
    // 0xc96728: r0 = BoxInt64Instr(r4)
    //     0xc96728: sbfiz           x0, x4, #1, #0x1f
    //     0xc9672c: cmp             x4, x0, asr #1
    //     0xc96730: b.eq            #0xc9673c
    //     0xc96734: bl              #0xd69bb8
    //     0xc96738: stur            x4, [x0, #7]
    // 0xc9673c: mov             x1, x2
    // 0xc96740: ArrayStore: r1[21] = r0  ; List_4
    //     0xc96740: add             x25, x1, #0x63
    //     0xc96744: str             w0, [x25]
    //     0xc96748: tbz             w0, #0, #0xc96764
    //     0xc9674c: ldurb           w16, [x1, #-1]
    //     0xc96750: ldurb           w17, [x0, #-1]
    //     0xc96754: and             x16, x17, x16, lsr #2
    //     0xc96758: tst             x16, HEAP, lsr #32
    //     0xc9675c: b.eq            #0xc96764
    //     0xc96760: bl              #0xd67e5c
    // 0xc96764: r17 = "suitMask"
    //     0xc96764: add             x17, PP, #0x41, lsl #12  ; [pp+0x41258] "suitMask"
    //     0xc96768: ldr             x17, [x17, #0x258]
    // 0xc9676c: StoreField: r2->field_67 = r17
    //     0xc9676c: stur            w17, [x2, #0x67]
    // 0xc96770: LoadField: r4 = r3->field_53
    //     0xc96770: ldur            x4, [x3, #0x53]
    // 0xc96774: r0 = BoxInt64Instr(r4)
    //     0xc96774: sbfiz           x0, x4, #1, #0x1f
    //     0xc96778: cmp             x4, x0, asr #1
    //     0xc9677c: b.eq            #0xc96788
    //     0xc96780: bl              #0xd69bb8
    //     0xc96784: stur            x4, [x0, #7]
    // 0xc96788: mov             x1, x2
    // 0xc9678c: ArrayStore: r1[23] = r0  ; List_4
    //     0xc9678c: add             x25, x1, #0x6b
    //     0xc96790: str             w0, [x25]
    //     0xc96794: tbz             w0, #0, #0xc967b0
    //     0xc96798: ldurb           w16, [x1, #-1]
    //     0xc9679c: ldurb           w17, [x0, #-1]
    //     0xc967a0: and             x16, x17, x16, lsr #2
    //     0xc967a4: tst             x16, HEAP, lsr #32
    //     0xc967a8: b.eq            #0xc967b0
    //     0xc967ac: bl              #0xd67e5c
    // 0xc967b0: r17 = "productType"
    //     0xc967b0: add             x17, PP, #0x41, lsl #12  ; [pp+0x41260] "productType"
    //     0xc967b4: ldr             x17, [x17, #0x260]
    // 0xc967b8: StoreField: r2->field_6f = r17
    //     0xc967b8: stur            w17, [x2, #0x6f]
    // 0xc967bc: LoadField: r4 = r3->field_5b
    //     0xc967bc: ldur            x4, [x3, #0x5b]
    // 0xc967c0: r0 = BoxInt64Instr(r4)
    //     0xc967c0: sbfiz           x0, x4, #1, #0x1f
    //     0xc967c4: cmp             x4, x0, asr #1
    //     0xc967c8: b.eq            #0xc967d4
    //     0xc967cc: bl              #0xd69bb8
    //     0xc967d0: stur            x4, [x0, #7]
    // 0xc967d4: mov             x1, x2
    // 0xc967d8: ArrayStore: r1[25] = r0  ; List_4
    //     0xc967d8: add             x25, x1, #0x73
    //     0xc967dc: str             w0, [x25]
    //     0xc967e0: tbz             w0, #0, #0xc967fc
    //     0xc967e4: ldurb           w16, [x1, #-1]
    //     0xc967e8: ldurb           w17, [x0, #-1]
    //     0xc967ec: and             x16, x17, x16, lsr #2
    //     0xc967f0: tst             x16, HEAP, lsr #32
    //     0xc967f4: b.eq            #0xc967fc
    //     0xc967f8: bl              #0xd67e5c
    // 0xc967fc: r17 = "reserved"
    //     0xc967fc: add             x17, PP, #0x41, lsl #12  ; [pp+0x41268] "reserved"
    //     0xc96800: ldr             x17, [x17, #0x268]
    // 0xc96804: StoreField: r2->field_77 = r17
    //     0xc96804: stur            w17, [x2, #0x77]
    // 0xc96808: LoadField: r4 = r3->field_63
    //     0xc96808: ldur            x4, [x3, #0x63]
    // 0xc9680c: r0 = BoxInt64Instr(r4)
    //     0xc9680c: sbfiz           x0, x4, #1, #0x1f
    //     0xc96810: cmp             x4, x0, asr #1
    //     0xc96814: b.eq            #0xc96820
    //     0xc96818: bl              #0xd69bb8
    //     0xc9681c: stur            x4, [x0, #7]
    // 0xc96820: mov             x1, x2
    // 0xc96824: ArrayStore: r1[27] = r0  ; List_4
    //     0xc96824: add             x25, x1, #0x7b
    //     0xc96828: str             w0, [x25]
    //     0xc9682c: tbz             w0, #0, #0xc96848
    //     0xc96830: ldurb           w16, [x1, #-1]
    //     0xc96834: ldurb           w17, [x0, #-1]
    //     0xc96838: and             x16, x17, x16, lsr #2
    //     0xc9683c: tst             x16, HEAP, lsr #32
    //     0xc96840: b.eq            #0xc96848
    //     0xc96844: bl              #0xd67e5c
    // 0xc96848: r17 = "buildLab"
    //     0xc96848: add             x17, PP, #0x41, lsl #12  ; [pp+0x41270] "buildLab"
    //     0xc9684c: ldr             x17, [x17, #0x270]
    // 0xc96850: StoreField: r2->field_7f = r17
    //     0xc96850: stur            w17, [x2, #0x7f]
    // 0xc96854: LoadField: r0 = r3->field_6b
    //     0xc96854: ldur            w0, [x3, #0x6b]
    // 0xc96858: DecompressPointer r0
    //     0xc96858: add             x0, x0, HEAP, lsl #32
    // 0xc9685c: mov             x1, x2
    // 0xc96860: ArrayStore: r1[29] = r0  ; List_4
    //     0xc96860: add             x25, x1, #0x83
    //     0xc96864: str             w0, [x25]
    //     0xc96868: tbz             w0, #0, #0xc96884
    //     0xc9686c: ldurb           w16, [x1, #-1]
    //     0xc96870: ldurb           w17, [x0, #-1]
    //     0xc96874: and             x16, x17, x16, lsr #2
    //     0xc96878: tst             x16, HEAP, lsr #32
    //     0xc9687c: b.eq            #0xc96884
    //     0xc96880: bl              #0xd67e5c
    // 0xc96884: r17 = "buildLabEx"
    //     0xc96884: add             x17, PP, #0x41, lsl #12  ; [pp+0x41278] "buildLabEx"
    //     0xc96888: ldr             x17, [x17, #0x278]
    // 0xc9688c: StoreField: r2->field_87 = r17
    //     0xc9688c: stur            w17, [x2, #0x87]
    // 0xc96890: LoadField: r0 = r3->field_6f
    //     0xc96890: ldur            w0, [x3, #0x6f]
    // 0xc96894: DecompressPointer r0
    //     0xc96894: add             x0, x0, HEAP, lsl #32
    // 0xc96898: mov             x1, x2
    // 0xc9689c: ArrayStore: r1[31] = r0  ; List_4
    //     0xc9689c: add             x25, x1, #0x8b
    //     0xc968a0: str             w0, [x25]
    //     0xc968a4: tbz             w0, #0, #0xc968c0
    //     0xc968a8: ldurb           w16, [x1, #-1]
    //     0xc968ac: ldurb           w17, [x0, #-1]
    //     0xc968b0: and             x16, x17, x16, lsr #2
    //     0xc968b4: tst             x16, HEAP, lsr #32
    //     0xc968b8: b.eq            #0xc968c0
    //     0xc968bc: bl              #0xd67e5c
    // 0xc968c0: r17 = "digitalProductId"
    //     0xc968c0: add             x17, PP, #0x41, lsl #12  ; [pp+0x41280] "digitalProductId"
    //     0xc968c4: ldr             x17, [x17, #0x280]
    // 0xc968c8: StoreField: r2->field_8f = r17
    //     0xc968c8: stur            w17, [x2, #0x8f]
    // 0xc968cc: LoadField: r0 = r3->field_73
    //     0xc968cc: ldur            w0, [x3, #0x73]
    // 0xc968d0: DecompressPointer r0
    //     0xc968d0: add             x0, x0, HEAP, lsl #32
    // 0xc968d4: mov             x1, x2
    // 0xc968d8: ArrayStore: r1[33] = r0  ; List_4
    //     0xc968d8: add             x25, x1, #0x93
    //     0xc968dc: str             w0, [x25]
    //     0xc968e0: tbz             w0, #0, #0xc968fc
    //     0xc968e4: ldurb           w16, [x1, #-1]
    //     0xc968e8: ldurb           w17, [x0, #-1]
    //     0xc968ec: and             x16, x17, x16, lsr #2
    //     0xc968f0: tst             x16, HEAP, lsr #32
    //     0xc968f4: b.eq            #0xc968fc
    //     0xc968f8: bl              #0xd67e5c
    // 0xc968fc: r17 = "displayVersion"
    //     0xc968fc: add             x17, PP, #0x41, lsl #12  ; [pp+0x41288] "displayVersion"
    //     0xc96900: ldr             x17, [x17, #0x288]
    // 0xc96904: StoreField: r2->field_97 = r17
    //     0xc96904: stur            w17, [x2, #0x97]
    // 0xc96908: LoadField: r0 = r3->field_77
    //     0xc96908: ldur            w0, [x3, #0x77]
    // 0xc9690c: DecompressPointer r0
    //     0xc9690c: add             x0, x0, HEAP, lsl #32
    // 0xc96910: mov             x1, x2
    // 0xc96914: ArrayStore: r1[35] = r0  ; List_4
    //     0xc96914: add             x25, x1, #0x9b
    //     0xc96918: str             w0, [x25]
    //     0xc9691c: tbz             w0, #0, #0xc96938
    //     0xc96920: ldurb           w16, [x1, #-1]
    //     0xc96924: ldurb           w17, [x0, #-1]
    //     0xc96928: and             x16, x17, x16, lsr #2
    //     0xc9692c: tst             x16, HEAP, lsr #32
    //     0xc96930: b.eq            #0xc96938
    //     0xc96934: bl              #0xd67e5c
    // 0xc96938: r17 = "editionId"
    //     0xc96938: add             x17, PP, #0x41, lsl #12  ; [pp+0x41290] "editionId"
    //     0xc9693c: ldr             x17, [x17, #0x290]
    // 0xc96940: StoreField: r2->field_9f = r17
    //     0xc96940: stur            w17, [x2, #0x9f]
    // 0xc96944: LoadField: r0 = r3->field_7b
    //     0xc96944: ldur            w0, [x3, #0x7b]
    // 0xc96948: DecompressPointer r0
    //     0xc96948: add             x0, x0, HEAP, lsl #32
    // 0xc9694c: mov             x1, x2
    // 0xc96950: ArrayStore: r1[37] = r0  ; List_4
    //     0xc96950: add             x25, x1, #0xa3
    //     0xc96954: str             w0, [x25]
    //     0xc96958: tbz             w0, #0, #0xc96974
    //     0xc9695c: ldurb           w16, [x1, #-1]
    //     0xc96960: ldurb           w17, [x0, #-1]
    //     0xc96964: and             x16, x17, x16, lsr #2
    //     0xc96968: tst             x16, HEAP, lsr #32
    //     0xc9696c: b.eq            #0xc96974
    //     0xc96970: bl              #0xd67e5c
    // 0xc96974: r17 = "installDate"
    //     0xc96974: add             x17, PP, #0x41, lsl #12  ; [pp+0x41298] "installDate"
    //     0xc96978: ldr             x17, [x17, #0x298]
    // 0xc9697c: StoreField: r2->field_a7 = r17
    //     0xc9697c: stur            w17, [x2, #0xa7]
    // 0xc96980: LoadField: r0 = r3->field_7f
    //     0xc96980: ldur            w0, [x3, #0x7f]
    // 0xc96984: DecompressPointer r0
    //     0xc96984: add             x0, x0, HEAP, lsl #32
    // 0xc96988: mov             x1, x2
    // 0xc9698c: ArrayStore: r1[39] = r0  ; List_4
    //     0xc9698c: add             x25, x1, #0xab
    //     0xc96990: str             w0, [x25]
    //     0xc96994: tbz             w0, #0, #0xc969b0
    //     0xc96998: ldurb           w16, [x1, #-1]
    //     0xc9699c: ldurb           w17, [x0, #-1]
    //     0xc969a0: and             x16, x17, x16, lsr #2
    //     0xc969a4: tst             x16, HEAP, lsr #32
    //     0xc969a8: b.eq            #0xc969b0
    //     0xc969ac: bl              #0xd67e5c
    // 0xc969b0: r17 = "productId"
    //     0xc969b0: ldr             x17, [PP, #0x5708]  ; [pp+0x5708] "productId"
    // 0xc969b4: StoreField: r2->field_af = r17
    //     0xc969b4: stur            w17, [x2, #0xaf]
    // 0xc969b8: LoadField: r0 = r3->field_83
    //     0xc969b8: ldur            w0, [x3, #0x83]
    // 0xc969bc: DecompressPointer r0
    //     0xc969bc: add             x0, x0, HEAP, lsl #32
    // 0xc969c0: mov             x1, x2
    // 0xc969c4: ArrayStore: r1[41] = r0  ; List_4
    //     0xc969c4: add             x25, x1, #0xb3
    //     0xc969c8: str             w0, [x25]
    //     0xc969cc: tbz             w0, #0, #0xc969e8
    //     0xc969d0: ldurb           w16, [x1, #-1]
    //     0xc969d4: ldurb           w17, [x0, #-1]
    //     0xc969d8: and             x16, x17, x16, lsr #2
    //     0xc969dc: tst             x16, HEAP, lsr #32
    //     0xc969e0: b.eq            #0xc969e8
    //     0xc969e4: bl              #0xd67e5c
    // 0xc969e8: r17 = "productName"
    //     0xc969e8: add             x17, PP, #0x41, lsl #12  ; [pp+0x412a0] "productName"
    //     0xc969ec: ldr             x17, [x17, #0x2a0]
    // 0xc969f0: StoreField: r2->field_b7 = r17
    //     0xc969f0: stur            w17, [x2, #0xb7]
    // 0xc969f4: LoadField: r0 = r3->field_87
    //     0xc969f4: ldur            w0, [x3, #0x87]
    // 0xc969f8: DecompressPointer r0
    //     0xc969f8: add             x0, x0, HEAP, lsl #32
    // 0xc969fc: mov             x1, x2
    // 0xc96a00: ArrayStore: r1[43] = r0  ; List_4
    //     0xc96a00: add             x25, x1, #0xbb
    //     0xc96a04: str             w0, [x25]
    //     0xc96a08: tbz             w0, #0, #0xc96a24
    //     0xc96a0c: ldurb           w16, [x1, #-1]
    //     0xc96a10: ldurb           w17, [x0, #-1]
    //     0xc96a14: and             x16, x17, x16, lsr #2
    //     0xc96a18: tst             x16, HEAP, lsr #32
    //     0xc96a1c: b.eq            #0xc96a24
    //     0xc96a20: bl              #0xd67e5c
    // 0xc96a24: r17 = "registeredOwner"
    //     0xc96a24: add             x17, PP, #0x41, lsl #12  ; [pp+0x412a8] "registeredOwner"
    //     0xc96a28: ldr             x17, [x17, #0x2a8]
    // 0xc96a2c: StoreField: r2->field_bf = r17
    //     0xc96a2c: stur            w17, [x2, #0xbf]
    // 0xc96a30: LoadField: r0 = r3->field_8b
    //     0xc96a30: ldur            w0, [x3, #0x8b]
    // 0xc96a34: DecompressPointer r0
    //     0xc96a34: add             x0, x0, HEAP, lsl #32
    // 0xc96a38: mov             x1, x2
    // 0xc96a3c: ArrayStore: r1[45] = r0  ; List_4
    //     0xc96a3c: add             x25, x1, #0xc3
    //     0xc96a40: str             w0, [x25]
    //     0xc96a44: tbz             w0, #0, #0xc96a60
    //     0xc96a48: ldurb           w16, [x1, #-1]
    //     0xc96a4c: ldurb           w17, [x0, #-1]
    //     0xc96a50: and             x16, x17, x16, lsr #2
    //     0xc96a54: tst             x16, HEAP, lsr #32
    //     0xc96a58: b.eq            #0xc96a60
    //     0xc96a5c: bl              #0xd67e5c
    // 0xc96a60: r17 = "releaseId"
    //     0xc96a60: add             x17, PP, #0x41, lsl #12  ; [pp+0x412b0] "releaseId"
    //     0xc96a64: ldr             x17, [x17, #0x2b0]
    // 0xc96a68: StoreField: r2->field_c7 = r17
    //     0xc96a68: stur            w17, [x2, #0xc7]
    // 0xc96a6c: LoadField: r0 = r3->field_8f
    //     0xc96a6c: ldur            w0, [x3, #0x8f]
    // 0xc96a70: DecompressPointer r0
    //     0xc96a70: add             x0, x0, HEAP, lsl #32
    // 0xc96a74: mov             x1, x2
    // 0xc96a78: ArrayStore: r1[47] = r0  ; List_4
    //     0xc96a78: add             x25, x1, #0xcb
    //     0xc96a7c: str             w0, [x25]
    //     0xc96a80: tbz             w0, #0, #0xc96a9c
    //     0xc96a84: ldurb           w16, [x1, #-1]
    //     0xc96a88: ldurb           w17, [x0, #-1]
    //     0xc96a8c: and             x16, x17, x16, lsr #2
    //     0xc96a90: tst             x16, HEAP, lsr #32
    //     0xc96a94: b.eq            #0xc96a9c
    //     0xc96a98: bl              #0xd67e5c
    // 0xc96a9c: r17 = "deviceId"
    //     0xc96a9c: ldr             x17, [PP, #0x5720]  ; [pp+0x5720] "deviceId"
    // 0xc96aa0: StoreField: r2->field_cf = r17
    //     0xc96aa0: stur            w17, [x2, #0xcf]
    // 0xc96aa4: LoadField: r0 = r3->field_93
    //     0xc96aa4: ldur            w0, [x3, #0x93]
    // 0xc96aa8: DecompressPointer r0
    //     0xc96aa8: add             x0, x0, HEAP, lsl #32
    // 0xc96aac: mov             x1, x2
    // 0xc96ab0: ArrayStore: r1[49] = r0  ; List_4
    //     0xc96ab0: add             x25, x1, #0xd3
    //     0xc96ab4: str             w0, [x25]
    //     0xc96ab8: tbz             w0, #0, #0xc96ad4
    //     0xc96abc: ldurb           w16, [x1, #-1]
    //     0xc96ac0: ldurb           w17, [x0, #-1]
    //     0xc96ac4: and             x16, x17, x16, lsr #2
    //     0xc96ac8: tst             x16, HEAP, lsr #32
    //     0xc96acc: b.eq            #0xc96ad4
    //     0xc96ad0: bl              #0xd67e5c
    // 0xc96ad4: r16 = <String, dynamic>
    //     0xc96ad4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc96ad8: stp             x2, x16, [SP, #-0x10]!
    // 0xc96adc: r0 = Map._fromLiteral()
    //     0xc96adc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc96ae0: add             SP, SP, #0x10
    // 0xc96ae4: LeaveFrame
    //     0xc96ae4: mov             SP, fp
    //     0xc96ae8: ldp             fp, lr, [SP], #0x10
    // 0xc96aec: ret
    //     0xc96aec: ret             
    // 0xc96af0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc96af0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc96af4: b               #0xc96460
  }
}

// lib: , url: package:crypto/src/hmac.dart

// class id: 1048816, size: 0x8
class :: {
}

// class id: 5384, size: 0x1c, field offset: 0xc
class _HmacSink extends ByteConversionSink {

  late final ByteConversionSink _innerSink; // offset: 0x14

  dynamic close(dynamic) {
    // ** addr: 0xbce728, size: 0x18
    // 0xbce728: r4 = 7
    //     0xbce728: mov             x4, #7
    // 0xbce72c: r1 = Function 'close':.
    //     0xbce72c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d6a0] AnonymousClosure: (0xbce740), in [package:crypto/src/hmac.dart] _HmacSink::close (0xc0ab08)
    //     0xbce730: ldr             x1, [x17, #0x6a0]
    // 0xbce734: r24 = BuildNonGenericMethodExtractorStub
    //     0xbce734: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xbce738: LoadField: r0 = r24->field_17
    //     0xbce738: ldur            x0, [x24, #0x17]
    // 0xbce73c: br              x0
  }
  [closure] void close(dynamic) {
    // ** addr: 0xbce740, size: 0x48
    // 0xbce740: EnterFrame
    //     0xbce740: stp             fp, lr, [SP, #-0x10]!
    //     0xbce744: mov             fp, SP
    // 0xbce748: ldr             x0, [fp, #0x10]
    // 0xbce74c: LoadField: r1 = r0->field_17
    //     0xbce74c: ldur            w1, [x0, #0x17]
    // 0xbce750: DecompressPointer r1
    //     0xbce750: add             x1, x1, HEAP, lsl #32
    // 0xbce754: CheckStackOverflow
    //     0xbce754: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbce758: cmp             SP, x16
    //     0xbce75c: b.ls            #0xbce780
    // 0xbce760: LoadField: r0 = r1->field_f
    //     0xbce760: ldur            w0, [x1, #0xf]
    // 0xbce764: DecompressPointer r0
    //     0xbce764: add             x0, x0, HEAP, lsl #32
    // 0xbce768: SaveReg r0
    //     0xbce768: str             x0, [SP, #-8]!
    // 0xbce76c: r0 = close()
    //     0xbce76c: bl              #0xc0ab08  ; [package:crypto/src/hmac.dart] _HmacSink::close
    // 0xbce770: add             SP, SP, #8
    // 0xbce774: LeaveFrame
    //     0xbce774: mov             SP, fp
    //     0xbce778: ldp             fp, lr, [SP], #0x10
    // 0xbce77c: ret
    //     0xbce77c: ret             
    // 0xbce780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbce780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbce784: b               #0xbce760
  }
  dynamic add(dynamic) {
    // ** addr: 0xbcf844, size: 0x18
    // 0xbcf844: r4 = 7
    //     0xbcf844: mov             x4, #7
    // 0xbcf848: r1 = Function 'add':.
    //     0xbcf848: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d6a8] AnonymousClosure: (0xbcf85c), in [package:crypto/src/hmac.dart] _HmacSink::add (0xc2fbdc)
    //     0xbcf84c: ldr             x1, [x17, #0x6a8]
    // 0xbcf850: r24 = BuildNonGenericMethodExtractorStub
    //     0xbcf850: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xbcf854: LoadField: r0 = r24->field_17
    //     0xbcf854: ldur            x0, [x24, #0x17]
    // 0xbcf858: br              x0
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0xbcf85c, size: 0x4c
    // 0xbcf85c: EnterFrame
    //     0xbcf85c: stp             fp, lr, [SP, #-0x10]!
    //     0xbcf860: mov             fp, SP
    // 0xbcf864: ldr             x0, [fp, #0x18]
    // 0xbcf868: LoadField: r1 = r0->field_17
    //     0xbcf868: ldur            w1, [x0, #0x17]
    // 0xbcf86c: DecompressPointer r1
    //     0xbcf86c: add             x1, x1, HEAP, lsl #32
    // 0xbcf870: CheckStackOverflow
    //     0xbcf870: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbcf874: cmp             SP, x16
    //     0xbcf878: b.ls            #0xbcf8a0
    // 0xbcf87c: LoadField: r0 = r1->field_f
    //     0xbcf87c: ldur            w0, [x1, #0xf]
    // 0xbcf880: DecompressPointer r0
    //     0xbcf880: add             x0, x0, HEAP, lsl #32
    // 0xbcf884: ldr             x16, [fp, #0x10]
    // 0xbcf888: stp             x16, x0, [SP, #-0x10]!
    // 0xbcf88c: r0 = add()
    //     0xbcf88c: bl              #0xc2fbdc  ; [package:crypto/src/hmac.dart] _HmacSink::add
    // 0xbcf890: add             SP, SP, #0x10
    // 0xbcf894: LeaveFrame
    //     0xbcf894: mov             SP, fp
    //     0xbcf898: ldp             fp, lr, [SP], #0x10
    // 0xbcf89c: ret
    //     0xbcf89c: ret             
    // 0xbcf8a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcf8a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcf8a4: b               #0xbcf87c
  }
  _ close(/* No info */) {
    // ** addr: 0xc0ab08, size: 0xd4
    // 0xc0ab08: EnterFrame
    //     0xc0ab08: stp             fp, lr, [SP, #-0x10]!
    //     0xc0ab0c: mov             fp, SP
    // 0xc0ab10: AllocStack(0x8)
    //     0xc0ab10: sub             SP, SP, #8
    // 0xc0ab14: CheckStackOverflow
    //     0xc0ab14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0ab18: cmp             SP, x16
    //     0xc0ab1c: b.ls            #0xc0abc4
    // 0xc0ab20: ldr             x0, [fp, #0x10]
    // 0xc0ab24: LoadField: r1 = r0->field_17
    //     0xc0ab24: ldur            w1, [x0, #0x17]
    // 0xc0ab28: DecompressPointer r1
    //     0xc0ab28: add             x1, x1, HEAP, lsl #32
    // 0xc0ab2c: tbnz            w1, #4, #0xc0ab40
    // 0xc0ab30: r0 = Null
    //     0xc0ab30: mov             x0, NULL
    // 0xc0ab34: LeaveFrame
    //     0xc0ab34: mov             SP, fp
    //     0xc0ab38: ldp             fp, lr, [SP], #0x10
    // 0xc0ab3c: ret
    //     0xc0ab3c: ret             
    // 0xc0ab40: r1 = true
    //     0xc0ab40: add             x1, NULL, #0x20  ; true
    // 0xc0ab44: StoreField: r0->field_17 = r1
    //     0xc0ab44: stur            w1, [x0, #0x17]
    // 0xc0ab48: LoadField: r1 = r0->field_13
    //     0xc0ab48: ldur            w1, [x0, #0x13]
    // 0xc0ab4c: DecompressPointer r1
    //     0xc0ab4c: add             x1, x1, HEAP, lsl #32
    // 0xc0ab50: r16 = Sentinel
    //     0xc0ab50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc0ab54: cmp             w1, w16
    // 0xc0ab58: b.eq            #0xc0abcc
    // 0xc0ab5c: SaveReg r1
    //     0xc0ab5c: str             x1, [SP, #-8]!
    // 0xc0ab60: r0 = close()
    //     0xc0ab60: bl              #0xc0a49c  ; [dart:convert] _ByteAdapterSink::close
    // 0xc0ab64: add             SP, SP, #8
    // 0xc0ab68: ldr             x0, [fp, #0x10]
    // 0xc0ab6c: LoadField: r1 = r0->field_b
    //     0xc0ab6c: ldur            w1, [x0, #0xb]
    // 0xc0ab70: DecompressPointer r1
    //     0xc0ab70: add             x1, x1, HEAP, lsl #32
    // 0xc0ab74: stur            x1, [fp, #-8]
    // 0xc0ab78: LoadField: r2 = r0->field_f
    //     0xc0ab78: ldur            w2, [x0, #0xf]
    // 0xc0ab7c: DecompressPointer r2
    //     0xc0ab7c: add             x2, x2, HEAP, lsl #32
    // 0xc0ab80: LoadField: r0 = r2->field_7
    //     0xc0ab80: ldur            w0, [x2, #7]
    // 0xc0ab84: DecompressPointer r0
    //     0xc0ab84: add             x0, x0, HEAP, lsl #32
    // 0xc0ab88: cmp             w0, NULL
    // 0xc0ab8c: b.eq            #0xc0abd8
    // 0xc0ab90: LoadField: r2 = r0->field_7
    //     0xc0ab90: ldur            w2, [x0, #7]
    // 0xc0ab94: DecompressPointer r2
    //     0xc0ab94: add             x2, x2, HEAP, lsl #32
    // 0xc0ab98: stp             x2, x1, [SP, #-0x10]!
    // 0xc0ab9c: r0 = add()
    //     0xc0ab9c: bl              #0xc2f4e4  ; [dart:convert] _ByteAdapterSink::add
    // 0xc0aba0: add             SP, SP, #0x10
    // 0xc0aba4: ldur            x16, [fp, #-8]
    // 0xc0aba8: SaveReg r16
    //     0xc0aba8: str             x16, [SP, #-8]!
    // 0xc0abac: r0 = close()
    //     0xc0abac: bl              #0xc0a49c  ; [dart:convert] _ByteAdapterSink::close
    // 0xc0abb0: add             SP, SP, #8
    // 0xc0abb4: r0 = Null
    //     0xc0abb4: mov             x0, NULL
    // 0xc0abb8: LeaveFrame
    //     0xc0abb8: mov             SP, fp
    //     0xc0abbc: ldp             fp, lr, [SP], #0x10
    // 0xc0abc0: ret
    //     0xc0abc0: ret             
    // 0xc0abc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0abc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0abc8: b               #0xc0ab20
    // 0xc0abcc: r9 = _innerSink
    //     0xc0abcc: add             x9, PP, #0x12, lsl #12  ; [pp+0x12d48] Field <_HmacSink@283383428._innerSink@283383428>: late final (offset: 0x14)
    //     0xc0abd0: ldr             x9, [x9, #0xd48]
    // 0xc0abd4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0abd4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc0abd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc0abd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ add(/* No info */) {
    // ** addr: 0xc2fbdc, size: 0x8c
    // 0xc2fbdc: EnterFrame
    //     0xc2fbdc: stp             fp, lr, [SP, #-0x10]!
    //     0xc2fbe0: mov             fp, SP
    // 0xc2fbe4: CheckStackOverflow
    //     0xc2fbe4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2fbe8: cmp             SP, x16
    //     0xc2fbec: b.ls            #0xc2fc54
    // 0xc2fbf0: ldr             x0, [fp, #0x18]
    // 0xc2fbf4: LoadField: r1 = r0->field_17
    //     0xc2fbf4: ldur            w1, [x0, #0x17]
    // 0xc2fbf8: DecompressPointer r1
    //     0xc2fbf8: add             x1, x1, HEAP, lsl #32
    // 0xc2fbfc: tbz             w1, #4, #0xc2fc34
    // 0xc2fc00: LoadField: r1 = r0->field_13
    //     0xc2fc00: ldur            w1, [x0, #0x13]
    // 0xc2fc04: DecompressPointer r1
    //     0xc2fc04: add             x1, x1, HEAP, lsl #32
    // 0xc2fc08: r16 = Sentinel
    //     0xc2fc08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc2fc0c: cmp             w1, w16
    // 0xc2fc10: b.eq            #0xc2fc5c
    // 0xc2fc14: ldr             x16, [fp, #0x10]
    // 0xc2fc18: stp             x16, x1, [SP, #-0x10]!
    // 0xc2fc1c: r0 = add()
    //     0xc2fc1c: bl              #0xc2f4e4  ; [dart:convert] _ByteAdapterSink::add
    // 0xc2fc20: add             SP, SP, #0x10
    // 0xc2fc24: r0 = Null
    //     0xc2fc24: mov             x0, NULL
    // 0xc2fc28: LeaveFrame
    //     0xc2fc28: mov             SP, fp
    //     0xc2fc2c: ldp             fp, lr, [SP], #0x10
    // 0xc2fc30: ret
    //     0xc2fc30: ret             
    // 0xc2fc34: r0 = StateError()
    //     0xc2fc34: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc2fc38: mov             x1, x0
    // 0xc2fc3c: r0 = "HMAC is closed"
    //     0xc2fc3c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12d50] "HMAC is closed"
    //     0xc2fc40: ldr             x0, [x0, #0xd50]
    // 0xc2fc44: StoreField: r1->field_b = r0
    //     0xc2fc44: stur            w0, [x1, #0xb]
    // 0xc2fc48: mov             x0, x1
    // 0xc2fc4c: r0 = Throw()
    //     0xc2fc4c: bl              #0xd67e38  ; ThrowStub
    // 0xc2fc50: brk             #0
    // 0xc2fc54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2fc54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2fc58: b               #0xc2fbf0
    // 0xc2fc5c: r9 = _innerSink
    //     0xc2fc5c: add             x9, PP, #0x12, lsl #12  ; [pp+0x12d48] Field <_HmacSink@283383428._innerSink@283383428>: late final (offset: 0x14)
    //     0xc2fc60: ldr             x9, [x9, #0xd48]
    // 0xc2fc64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc2fc64: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _HmacSink(/* No info */) {
    // ** addr: 0xc739e4, size: 0x22c
    // 0xc739e4: EnterFrame
    //     0xc739e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc739e8: mov             fp, SP
    // 0xc739ec: AllocStack(0x20)
    //     0xc739ec: sub             SP, SP, #0x20
    // 0xc739f0: r1 = Sentinel
    //     0xc739f0: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc739f4: r0 = false
    //     0xc739f4: add             x0, NULL, #0x30  ; false
    // 0xc739f8: CheckStackOverflow
    //     0xc739f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc739fc: cmp             SP, x16
    //     0xc73a00: b.ls            #0xc73bec
    // 0xc73a04: ldr             x2, [fp, #0x20]
    // 0xc73a08: StoreField: r2->field_13 = r1
    //     0xc73a08: stur            w1, [x2, #0x13]
    // 0xc73a0c: StoreField: r2->field_17 = r0
    //     0xc73a0c: stur            w0, [x2, #0x17]
    // 0xc73a10: r0 = DigestSink()
    //     0xc73a10: bl              #0xc21168  ; AllocateDigestSinkStub -> DigestSink (size=0xc)
    // 0xc73a14: mov             x2, x0
    // 0xc73a18: ldr             x1, [fp, #0x20]
    // 0xc73a1c: stur            x2, [fp, #-8]
    // 0xc73a20: StoreField: r1->field_f = r0
    //     0xc73a20: stur            w0, [x1, #0xf]
    //     0xc73a24: ldurb           w16, [x1, #-1]
    //     0xc73a28: ldurb           w17, [x0, #-1]
    //     0xc73a2c: and             x16, x17, x16, lsr #2
    //     0xc73a30: tst             x16, HEAP, lsr #32
    //     0xc73a34: b.eq            #0xc73a3c
    //     0xc73a38: bl              #0xd6826c
    // 0xc73a3c: r16 = Instance__Sha256
    //     0xc73a3c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12d58] Obj!_Sha256<List<int>, Digest>@b5f701
    //     0xc73a40: ldr             x16, [x16, #0xd58]
    // 0xc73a44: ldr             lr, [fp, #0x18]
    // 0xc73a48: stp             lr, x16, [SP, #-0x10]!
    // 0xc73a4c: r0 = startChunkedConversion()
    //     0xc73a4c: bl              #0xc7392c  ; [package:crypto/src/sha256.dart] _Sha256::startChunkedConversion
    // 0xc73a50: add             SP, SP, #0x10
    // 0xc73a54: mov             x2, x0
    // 0xc73a58: ldr             x1, [fp, #0x20]
    // 0xc73a5c: stur            x2, [fp, #-0x10]
    // 0xc73a60: StoreField: r1->field_b = r0
    //     0xc73a60: stur            w0, [x1, #0xb]
    //     0xc73a64: ldurb           w16, [x1, #-1]
    //     0xc73a68: ldurb           w17, [x0, #-1]
    //     0xc73a6c: and             x16, x17, x16, lsr #2
    //     0xc73a70: tst             x16, HEAP, lsr #32
    //     0xc73a74: b.eq            #0xc73a7c
    //     0xc73a78: bl              #0xd6826c
    // 0xc73a7c: r16 = Instance__Sha256
    //     0xc73a7c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12d58] Obj!_Sha256<List<int>, Digest>@b5f701
    //     0xc73a80: ldr             x16, [x16, #0xd58]
    // 0xc73a84: ldur            lr, [fp, #-8]
    // 0xc73a88: stp             lr, x16, [SP, #-0x10]!
    // 0xc73a8c: r0 = startChunkedConversion()
    //     0xc73a8c: bl              #0xc7392c  ; [package:crypto/src/sha256.dart] _Sha256::startChunkedConversion
    // 0xc73a90: add             SP, SP, #0x10
    // 0xc73a94: mov             x1, x0
    // 0xc73a98: ldr             x0, [fp, #0x20]
    // 0xc73a9c: stur            x1, [fp, #-8]
    // 0xc73aa0: LoadField: r2 = r0->field_13
    //     0xc73aa0: ldur            w2, [x0, #0x13]
    // 0xc73aa4: DecompressPointer r2
    //     0xc73aa4: add             x2, x2, HEAP, lsl #32
    // 0xc73aa8: r16 = Sentinel
    //     0xc73aa8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc73aac: cmp             w2, w16
    // 0xc73ab0: b.ne            #0xc73abc
    // 0xc73ab4: mov             x1, x0
    // 0xc73ab8: b               #0xc73ad4
    // 0xc73abc: r16 = "_innerSink@283383428"
    //     0xc73abc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12d60] "_innerSink@283383428"
    //     0xc73ac0: ldr             x16, [x16, #0xd60]
    // 0xc73ac4: SaveReg r16
    //     0xc73ac4: str             x16, [SP, #-8]!
    // 0xc73ac8: r0 = _throwFieldAlreadyInitialized()
    //     0xc73ac8: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xc73acc: add             SP, SP, #8
    // 0xc73ad0: ldr             x1, [fp, #0x20]
    // 0xc73ad4: ldr             x2, [fp, #0x10]
    // 0xc73ad8: ldur            x0, [fp, #-8]
    // 0xc73adc: StoreField: r1->field_13 = r0
    //     0xc73adc: stur            w0, [x1, #0x13]
    //     0xc73ae0: ldurb           w16, [x1, #-1]
    //     0xc73ae4: ldurb           w17, [x0, #-1]
    //     0xc73ae8: and             x16, x17, x16, lsr #2
    //     0xc73aec: tst             x16, HEAP, lsr #32
    //     0xc73af0: b.eq            #0xc73af8
    //     0xc73af4: bl              #0xd6826c
    // 0xc73af8: LoadField: r0 = r2->field_13
    //     0xc73af8: ldur            w0, [x2, #0x13]
    // 0xc73afc: DecompressPointer r0
    //     0xc73afc: add             x0, x0, HEAP, lsl #32
    // 0xc73b00: mov             x4, x0
    // 0xc73b04: stur            x0, [fp, #-8]
    // 0xc73b08: r0 = AllocateUint8Array()
    //     0xc73b08: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xc73b0c: mov             x1, x0
    // 0xc73b10: ldur            x0, [fp, #-8]
    // 0xc73b14: stur            x1, [fp, #-0x20]
    // 0xc73b18: r2 = LoadInt32Instr(r0)
    //     0xc73b18: sbfx            x2, x0, #1, #0x1f
    // 0xc73b1c: stur            x2, [fp, #-0x18]
    // 0xc73b20: ldr             x0, [fp, #0x10]
    // 0xc73b24: r3 = 0
    //     0xc73b24: mov             x3, #0
    // 0xc73b28: CheckStackOverflow
    //     0xc73b28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc73b2c: cmp             SP, x16
    //     0xc73b30: b.ls            #0xc73bf4
    // 0xc73b34: cmp             x3, x2
    // 0xc73b38: b.ge            #0xc73b60
    // 0xc73b3c: ArrayLoad: r4 = r0[r3]  ; TypedUnsigned_1
    //     0xc73b3c: add             x16, x0, x3
    //     0xc73b40: ldrb            w4, [x16, #0x17]
    // 0xc73b44: r16 = 92
    //     0xc73b44: mov             x16, #0x5c
    // 0xc73b48: eor             x5, x4, x16
    // 0xc73b4c: ArrayStore: r1[r3] = r5  ; TypeUnknown_1
    //     0xc73b4c: add             x4, x1, x3
    //     0xc73b50: strb            w5, [x4, #0x17]
    // 0xc73b54: add             x4, x3, #1
    // 0xc73b58: mov             x3, x4
    // 0xc73b5c: b               #0xc73b28
    // 0xc73b60: ldur            x16, [fp, #-0x10]
    // 0xc73b64: stp             x1, x16, [SP, #-0x10]!
    // 0xc73b68: r0 = add()
    //     0xc73b68: bl              #0xc2f4e4  ; [dart:convert] _ByteAdapterSink::add
    // 0xc73b6c: add             SP, SP, #0x10
    // 0xc73b70: ldr             x2, [fp, #0x10]
    // 0xc73b74: ldur            x0, [fp, #-0x20]
    // 0xc73b78: ldur            x1, [fp, #-0x18]
    // 0xc73b7c: r3 = 0
    //     0xc73b7c: mov             x3, #0
    // 0xc73b80: CheckStackOverflow
    //     0xc73b80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc73b84: cmp             SP, x16
    //     0xc73b88: b.ls            #0xc73bfc
    // 0xc73b8c: cmp             x3, x1
    // 0xc73b90: b.ge            #0xc73bb8
    // 0xc73b94: ArrayLoad: r4 = r2[r3]  ; TypedUnsigned_1
    //     0xc73b94: add             x16, x2, x3
    //     0xc73b98: ldrb            w4, [x16, #0x17]
    // 0xc73b9c: r16 = 54
    //     0xc73b9c: mov             x16, #0x36
    // 0xc73ba0: eor             x5, x4, x16
    // 0xc73ba4: ArrayStore: r0[r3] = r5  ; TypeUnknown_1
    //     0xc73ba4: add             x4, x0, x3
    //     0xc73ba8: strb            w5, [x4, #0x17]
    // 0xc73bac: add             x4, x3, #1
    // 0xc73bb0: mov             x3, x4
    // 0xc73bb4: b               #0xc73b80
    // 0xc73bb8: ldr             x1, [fp, #0x20]
    // 0xc73bbc: LoadField: r2 = r1->field_13
    //     0xc73bbc: ldur            w2, [x1, #0x13]
    // 0xc73bc0: DecompressPointer r2
    //     0xc73bc0: add             x2, x2, HEAP, lsl #32
    // 0xc73bc4: r16 = Sentinel
    //     0xc73bc4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc73bc8: cmp             w2, w16
    // 0xc73bcc: b.eq            #0xc73c04
    // 0xc73bd0: stp             x0, x2, [SP, #-0x10]!
    // 0xc73bd4: r0 = add()
    //     0xc73bd4: bl              #0xc2f4e4  ; [dart:convert] _ByteAdapterSink::add
    // 0xc73bd8: add             SP, SP, #0x10
    // 0xc73bdc: r0 = Null
    //     0xc73bdc: mov             x0, NULL
    // 0xc73be0: LeaveFrame
    //     0xc73be0: mov             SP, fp
    //     0xc73be4: ldp             fp, lr, [SP], #0x10
    // 0xc73be8: ret
    //     0xc73be8: ret             
    // 0xc73bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc73bec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc73bf0: b               #0xc73a04
    // 0xc73bf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc73bf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc73bf8: b               #0xc73b34
    // 0xc73bfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc73bfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc73c00: b               #0xc73b8c
    // 0xc73c04: r9 = _innerSink
    //     0xc73c04: add             x9, PP, #0x12, lsl #12  ; [pp+0x12d48] Field <_HmacSink@283383428._innerSink@283383428>: late final (offset: 0x14)
    //     0xc73c08: ldr             x9, [x9, #0xd48]
    // 0xc73c0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc73c0c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5592, size: 0x14, field offset: 0xc
class Hmac extends Converter<List<int>, Digest> {

  _ Hmac(/* No info */) {
    // ** addr: 0x58771c, size: 0xcc
    // 0x58771c: EnterFrame
    //     0x58771c: stp             fp, lr, [SP, #-0x10]!
    //     0x587720: mov             fp, SP
    // 0x587724: AllocStack(0x8)
    //     0x587724: sub             SP, SP, #8
    // 0x587728: r0 = Instance__Sha256
    //     0x587728: add             x0, PP, #0x12, lsl #12  ; [pp+0x12d58] Obj!_Sha256<List<int>, Digest>@b5f701
    //     0x58772c: ldr             x0, [x0, #0xd58]
    // 0x587730: CheckStackOverflow
    //     0x587730: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x587734: cmp             SP, x16
    //     0x587738: b.ls            #0x5877e0
    // 0x58773c: ldr             x1, [fp, #0x18]
    // 0x587740: StoreField: r1->field_b = r0
    //     0x587740: stur            w0, [x1, #0xb]
    // 0x587744: r4 = 128
    //     0x587744: mov             x4, #0x80
    // 0x587748: r0 = AllocateUint8Array()
    //     0x587748: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x58774c: mov             x2, x0
    // 0x587750: ldr             x1, [fp, #0x18]
    // 0x587754: stur            x2, [fp, #-8]
    // 0x587758: StoreField: r1->field_f = r0
    //     0x587758: stur            w0, [x1, #0xf]
    //     0x58775c: ldurb           w16, [x1, #-1]
    //     0x587760: ldurb           w17, [x0, #-1]
    //     0x587764: and             x16, x17, x16, lsr #2
    //     0x587768: tst             x16, HEAP, lsr #32
    //     0x58776c: b.eq            #0x587774
    //     0x587770: bl              #0xd6826c
    // 0x587774: ldr             x0, [fp, #0x10]
    // 0x587778: LoadField: r1 = r0->field_13
    //     0x587778: ldur            w1, [x0, #0x13]
    // 0x58777c: DecompressPointer r1
    //     0x58777c: add             x1, x1, HEAP, lsl #32
    // 0x587780: r3 = LoadInt32Instr(r1)
    //     0x587780: sbfx            x3, x1, #1, #0x1f
    // 0x587784: cmp             x3, #0x40
    // 0x587788: b.le            #0x5877ac
    // 0x58778c: r16 = Instance__Sha256
    //     0x58778c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12d58] Obj!_Sha256<List<int>, Digest>@b5f701
    //     0x587790: ldr             x16, [x16, #0xd58]
    // 0x587794: stp             x0, x16, [SP, #-0x10]!
    // 0x587798: r0 = convert()
    //     0x587798: bl              #0xc20d20  ; [package:crypto/src/hash.dart] Hash::convert
    // 0x58779c: add             SP, SP, #0x10
    // 0x5877a0: LoadField: r1 = r0->field_7
    //     0x5877a0: ldur            w1, [x0, #7]
    // 0x5877a4: DecompressPointer r1
    //     0x5877a4: add             x1, x1, HEAP, lsl #32
    // 0x5877a8: mov             x0, x1
    // 0x5877ac: LoadField: r1 = r0->field_13
    //     0x5877ac: ldur            w1, [x0, #0x13]
    // 0x5877b0: DecompressPointer r1
    //     0x5877b0: add             x1, x1, HEAP, lsl #32
    // 0x5877b4: r2 = LoadInt32Instr(r1)
    //     0x5877b4: sbfx            x2, x1, #1, #0x1f
    // 0x5877b8: ldur            x16, [fp, #-8]
    // 0x5877bc: stp             xzr, x16, [SP, #-0x10]!
    // 0x5877c0: stp             x0, x2, [SP, #-0x10]!
    // 0x5877c4: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x5877c4: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x5877c8: r0 = setRange()
    //     0x5877c8: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0x5877cc: add             SP, SP, #0x20
    // 0x5877d0: r0 = Null
    //     0x5877d0: mov             x0, NULL
    // 0x5877d4: LeaveFrame
    //     0x5877d4: mov             SP, fp
    //     0x5877d8: ldp             fp, lr, [SP], #0x10
    // 0x5877dc: ret
    //     0x5877dc: ret             
    // 0x5877e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5877e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5877e4: b               #0x58773c
  }
  _ convert(/* No info */) {
    // ** addr: 0xc2120c, size: 0x80
    // 0xc2120c: EnterFrame
    //     0xc2120c: stp             fp, lr, [SP, #-0x10]!
    //     0xc21210: mov             fp, SP
    // 0xc21214: AllocStack(0x10)
    //     0xc21214: sub             SP, SP, #0x10
    // 0xc21218: CheckStackOverflow
    //     0xc21218: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2121c: cmp             SP, x16
    //     0xc21220: b.ls            #0xc21280
    // 0xc21224: r0 = DigestSink()
    //     0xc21224: bl              #0xc21168  ; AllocateDigestSinkStub -> DigestSink (size=0xc)
    // 0xc21228: stur            x0, [fp, #-8]
    // 0xc2122c: ldr             x16, [fp, #0x18]
    // 0xc21230: stp             x0, x16, [SP, #-0x10]!
    // 0xc21234: r0 = startChunkedConversion()
    //     0xc21234: bl              #0xc73980  ; [package:crypto/src/hmac.dart] Hmac::startChunkedConversion
    // 0xc21238: add             SP, SP, #0x10
    // 0xc2123c: stur            x0, [fp, #-0x10]
    // 0xc21240: ldr             x16, [fp, #0x10]
    // 0xc21244: stp             x16, x0, [SP, #-0x10]!
    // 0xc21248: r0 = add()
    //     0xc21248: bl              #0xc2fbdc  ; [package:crypto/src/hmac.dart] _HmacSink::add
    // 0xc2124c: add             SP, SP, #0x10
    // 0xc21250: ldur            x16, [fp, #-0x10]
    // 0xc21254: SaveReg r16
    //     0xc21254: str             x16, [SP, #-8]!
    // 0xc21258: r0 = close()
    //     0xc21258: bl              #0xc0ab08  ; [package:crypto/src/hmac.dart] _HmacSink::close
    // 0xc2125c: add             SP, SP, #8
    // 0xc21260: ldur            x1, [fp, #-8]
    // 0xc21264: LoadField: r0 = r1->field_7
    //     0xc21264: ldur            w0, [x1, #7]
    // 0xc21268: DecompressPointer r0
    //     0xc21268: add             x0, x0, HEAP, lsl #32
    // 0xc2126c: cmp             w0, NULL
    // 0xc21270: b.eq            #0xc21288
    // 0xc21274: LeaveFrame
    //     0xc21274: mov             SP, fp
    //     0xc21278: ldp             fp, lr, [SP], #0x10
    // 0xc2127c: ret
    //     0xc2127c: ret             
    // 0xc21280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc21280: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc21284: b               #0xc21224
    // 0xc21288: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc21288: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ startChunkedConversion(/* No info */) {
    // ** addr: 0xc73980, size: 0x64
    // 0xc73980: EnterFrame
    //     0xc73980: stp             fp, lr, [SP, #-0x10]!
    //     0xc73984: mov             fp, SP
    // 0xc73988: AllocStack(0x10)
    //     0xc73988: sub             SP, SP, #0x10
    // 0xc7398c: CheckStackOverflow
    //     0xc7398c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc73990: cmp             SP, x16
    //     0xc73994: b.ls            #0xc739dc
    // 0xc73998: ldr             x0, [fp, #0x18]
    // 0xc7399c: LoadField: r2 = r0->field_f
    //     0xc7399c: ldur            w2, [x0, #0xf]
    // 0xc739a0: DecompressPointer r2
    //     0xc739a0: add             x2, x2, HEAP, lsl #32
    // 0xc739a4: stur            x2, [fp, #-8]
    // 0xc739a8: r1 = <List<int>>
    //     0xc739a8: ldr             x1, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0xc739ac: r0 = _HmacSink()
    //     0xc739ac: bl              #0xc73c10  ; Allocate_HmacSinkStub -> _HmacSink (size=0x1c)
    // 0xc739b0: stur            x0, [fp, #-0x10]
    // 0xc739b4: ldr             x16, [fp, #0x10]
    // 0xc739b8: stp             x16, x0, [SP, #-0x10]!
    // 0xc739bc: ldur            x16, [fp, #-8]
    // 0xc739c0: SaveReg r16
    //     0xc739c0: str             x16, [SP, #-8]!
    // 0xc739c4: r0 = _HmacSink()
    //     0xc739c4: bl              #0xc739e4  ; [package:crypto/src/hmac.dart] _HmacSink::_HmacSink
    // 0xc739c8: add             SP, SP, #0x18
    // 0xc739cc: ldur            x0, [fp, #-0x10]
    // 0xc739d0: LeaveFrame
    //     0xc739d0: mov             SP, fp
    //     0xc739d4: ldp             fp, lr, [SP], #0x10
    // 0xc739d8: ret
    //     0xc739d8: ret             
    // 0xc739dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc739dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc739e0: b               #0xc73998
  }
}

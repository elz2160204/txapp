// lib: , url: package:crypto/src/sha256.dart

// class id: 1048819, size: 0x8
class :: {
}

// class id: 4756, size: 0x34, field offset: 0x2c
abstract class _Sha32BitSink extends HashSink {

  _ updateHash(/* No info */) {
    // ** addr: 0xcb1df4, size: 0x6e8
    // 0xcb1df4: EnterFrame
    //     0xcb1df4: stp             fp, lr, [SP, #-0x10]!
    //     0xcb1df8: mov             fp, SP
    // 0xcb1dfc: AllocStack(0x58)
    //     0xcb1dfc: sub             SP, SP, #0x58
    // 0xcb1e00: ldr             x2, [fp, #0x18]
    // 0xcb1e04: LoadField: r3 = r2->field_2f
    //     0xcb1e04: ldur            w3, [x2, #0x2f]
    // 0xcb1e08: DecompressPointer r3
    //     0xcb1e08: add             x3, x3, HEAP, lsl #32
    // 0xcb1e0c: ldr             x4, [fp, #0x10]
    // 0xcb1e10: LoadField: r5 = r4->field_13
    //     0xcb1e10: ldur            w5, [x4, #0x13]
    // 0xcb1e14: DecompressPointer r5
    //     0xcb1e14: add             x5, x5, HEAP, lsl #32
    // 0xcb1e18: r6 = LoadInt32Instr(r5)
    //     0xcb1e18: sbfx            x6, x5, #1, #0x1f
    // 0xcb1e1c: LoadField: r5 = r3->field_13
    //     0xcb1e1c: ldur            w5, [x3, #0x13]
    // 0xcb1e20: DecompressPointer r5
    //     0xcb1e20: add             x5, x5, HEAP, lsl #32
    // 0xcb1e24: r7 = LoadInt32Instr(r5)
    //     0xcb1e24: sbfx            x7, x5, #1, #0x1f
    // 0xcb1e28: r5 = 0
    //     0xcb1e28: mov             x5, #0
    // 0xcb1e2c: CheckStackOverflow
    //     0xcb1e2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb1e30: cmp             SP, x16
    //     0xcb1e34: b.ls            #0xcb23c8
    // 0xcb1e38: cmp             x5, #0x10
    // 0xcb1e3c: b.ge            #0xcb1e7c
    // 0xcb1e40: mov             x0, x6
    // 0xcb1e44: mov             x1, x5
    // 0xcb1e48: cmp             x1, x0
    // 0xcb1e4c: b.hs            #0xcb23d0
    // 0xcb1e50: ArrayLoad: r8 = r4[r5]  ; Unknown_4
    //     0xcb1e50: add             x16, x4, x5, lsl #2
    //     0xcb1e54: ldur            w8, [x16, #0x17]
    // 0xcb1e58: mov             x0, x7
    // 0xcb1e5c: mov             x1, x5
    // 0xcb1e60: cmp             x1, x0
    // 0xcb1e64: b.hs            #0xcb23d4
    // 0xcb1e68: ArrayStore: r3[r5] = r8  ; Unknown_4
    //     0xcb1e68: add             x9, x3, x5, lsl #2
    //     0xcb1e6c: stur            w8, [x9, #0x17]
    // 0xcb1e70: add             x0, x5, #1
    // 0xcb1e74: mov             x5, x0
    // 0xcb1e78: b               #0xcb1e2c
    // 0xcb1e7c: LoadField: r4 = r3->field_13
    //     0xcb1e7c: ldur            w4, [x3, #0x13]
    // 0xcb1e80: DecompressPointer r4
    //     0xcb1e80: add             x4, x4, HEAP, lsl #32
    // 0xcb1e84: r5 = LoadInt32Instr(r4)
    //     0xcb1e84: sbfx            x5, x4, #1, #0x1f
    // 0xcb1e88: r4 = 16
    //     0xcb1e88: mov             x4, #0x10
    // 0xcb1e8c: CheckStackOverflow
    //     0xcb1e8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb1e90: cmp             SP, x16
    //     0xcb1e94: b.ls            #0xcb23d8
    // 0xcb1e98: cmp             x4, #0x40
    // 0xcb1e9c: b.ge            #0xcb1fb0
    // 0xcb1ea0: sub             x6, x4, #2
    // 0xcb1ea4: mov             x0, x5
    // 0xcb1ea8: mov             x1, x6
    // 0xcb1eac: cmp             x1, x0
    // 0xcb1eb0: b.hs            #0xcb23e0
    // 0xcb1eb4: ArrayLoad: r7 = r3[r6]  ; Unknown_4
    //     0xcb1eb4: add             x16, x3, x6, lsl #2
    //     0xcb1eb8: ldur            w7, [x16, #0x17]
    // 0xcb1ebc: mov             x6, x7
    // 0xcb1ec0: ubfx            x6, x6, #0, #0x20
    // 0xcb1ec4: asr             x8, x6, #0x11
    // 0xcb1ec8: lsl             w9, w7, #0xf
    // 0xcb1ecc: ubfx            x9, x9, #0, #0x20
    // 0xcb1ed0: orr             x10, x8, x9
    // 0xcb1ed4: asr             x8, x6, #0x13
    // 0xcb1ed8: lsl             w9, w7, #0xd
    // 0xcb1edc: ubfx            x9, x9, #0, #0x20
    // 0xcb1ee0: orr             x7, x8, x9
    // 0xcb1ee4: eor             x8, x10, x7
    // 0xcb1ee8: asr             x7, x6, #0xa
    // 0xcb1eec: eor             x6, x8, x7
    // 0xcb1ef0: sub             x7, x4, #7
    // 0xcb1ef4: mov             x0, x5
    // 0xcb1ef8: mov             x1, x7
    // 0xcb1efc: cmp             x1, x0
    // 0xcb1f00: b.hs            #0xcb23e4
    // 0xcb1f04: ArrayLoad: r8 = r3[r7]  ; Unknown_4
    //     0xcb1f04: add             x16, x3, x7, lsl #2
    //     0xcb1f08: ldur            w8, [x16, #0x17]
    // 0xcb1f0c: ubfx            x6, x6, #0, #0x20
    // 0xcb1f10: add             w7, w6, w8
    // 0xcb1f14: sub             x6, x4, #0xf
    // 0xcb1f18: mov             x0, x5
    // 0xcb1f1c: mov             x1, x6
    // 0xcb1f20: cmp             x1, x0
    // 0xcb1f24: b.hs            #0xcb23e8
    // 0xcb1f28: ArrayLoad: r8 = r3[r6]  ; Unknown_4
    //     0xcb1f28: add             x16, x3, x6, lsl #2
    //     0xcb1f2c: ldur            w8, [x16, #0x17]
    // 0xcb1f30: mov             x6, x8
    // 0xcb1f34: ubfx            x6, x6, #0, #0x20
    // 0xcb1f38: asr             x9, x6, #7
    // 0xcb1f3c: lsl             w10, w8, #0x19
    // 0xcb1f40: ubfx            x10, x10, #0, #0x20
    // 0xcb1f44: orr             x11, x9, x10
    // 0xcb1f48: asr             x9, x6, #0x12
    // 0xcb1f4c: lsl             w10, w8, #0xe
    // 0xcb1f50: ubfx            x10, x10, #0, #0x20
    // 0xcb1f54: orr             x8, x9, x10
    // 0xcb1f58: eor             x9, x11, x8
    // 0xcb1f5c: asr             x8, x6, #3
    // 0xcb1f60: eor             x6, x9, x8
    // 0xcb1f64: sub             x8, x4, #0x10
    // 0xcb1f68: mov             x0, x5
    // 0xcb1f6c: mov             x1, x8
    // 0xcb1f70: cmp             x1, x0
    // 0xcb1f74: b.hs            #0xcb23ec
    // 0xcb1f78: ArrayLoad: r9 = r3[r8]  ; Unknown_4
    //     0xcb1f78: add             x16, x3, x8, lsl #2
    //     0xcb1f7c: ldur            w9, [x16, #0x17]
    // 0xcb1f80: ubfx            x6, x6, #0, #0x20
    // 0xcb1f84: add             w8, w6, w9
    // 0xcb1f88: add             w6, w7, w8
    // 0xcb1f8c: mov             x0, x5
    // 0xcb1f90: mov             x1, x4
    // 0xcb1f94: cmp             x1, x0
    // 0xcb1f98: b.hs            #0xcb23f0
    // 0xcb1f9c: ArrayStore: r3[r4] = r6  ; Unknown_4
    //     0xcb1f9c: add             x7, x3, x4, lsl #2
    //     0xcb1fa0: stur            w6, [x7, #0x17]
    // 0xcb1fa4: add             x0, x4, #1
    // 0xcb1fa8: mov             x4, x0
    // 0xcb1fac: b               #0xcb1e8c
    // 0xcb1fb0: LoadField: r4 = r2->field_2b
    //     0xcb1fb0: ldur            w4, [x2, #0x2b]
    // 0xcb1fb4: DecompressPointer r4
    //     0xcb1fb4: add             x4, x4, HEAP, lsl #32
    // 0xcb1fb8: LoadField: r5 = r4->field_13
    //     0xcb1fb8: ldur            w5, [x4, #0x13]
    // 0xcb1fbc: DecompressPointer r5
    //     0xcb1fbc: add             x5, x5, HEAP, lsl #32
    // 0xcb1fc0: r6 = LoadInt32Instr(r5)
    //     0xcb1fc0: sbfx            x6, x5, #1, #0x1f
    // 0xcb1fc4: mov             x0, x6
    // 0xcb1fc8: r1 = 0
    //     0xcb1fc8: mov             x1, #0
    // 0xcb1fcc: cmp             x1, x0
    // 0xcb1fd0: b.hs            #0xcb23f4
    // 0xcb1fd4: LoadField: r5 = r4->field_17
    //     0xcb1fd4: ldur            w5, [x4, #0x17]
    // 0xcb1fd8: mov             x0, x6
    // 0xcb1fdc: r1 = 1
    //     0xcb1fdc: mov             x1, #1
    // 0xcb1fe0: cmp             x1, x0
    // 0xcb1fe4: b.hs            #0xcb23f8
    // 0xcb1fe8: LoadField: r7 = r4->field_1b
    //     0xcb1fe8: ldur            w7, [x4, #0x1b]
    // 0xcb1fec: mov             x0, x6
    // 0xcb1ff0: r1 = 2
    //     0xcb1ff0: mov             x1, #2
    // 0xcb1ff4: cmp             x1, x0
    // 0xcb1ff8: b.hs            #0xcb23fc
    // 0xcb1ffc: LoadField: r8 = r4->field_1f
    //     0xcb1ffc: ldur            w8, [x4, #0x1f]
    // 0xcb2000: mov             x0, x6
    // 0xcb2004: stur            x8, [fp, #-0x48]
    // 0xcb2008: r1 = 3
    //     0xcb2008: mov             x1, #3
    // 0xcb200c: cmp             x1, x0
    // 0xcb2010: b.hs            #0xcb2400
    // 0xcb2014: LoadField: r9 = r4->field_23
    //     0xcb2014: ldur            w9, [x4, #0x23]
    // 0xcb2018: mov             x0, x6
    // 0xcb201c: stur            x9, [fp, #-0x38]
    // 0xcb2020: r1 = 4
    //     0xcb2020: mov             x1, #4
    // 0xcb2024: cmp             x1, x0
    // 0xcb2028: b.hs            #0xcb2404
    // 0xcb202c: LoadField: r10 = r4->field_27
    //     0xcb202c: ldur            w10, [x4, #0x27]
    // 0xcb2030: mov             x0, x6
    // 0xcb2034: stur            x10, [fp, #-0x30]
    // 0xcb2038: r1 = 5
    //     0xcb2038: mov             x1, #5
    // 0xcb203c: cmp             x1, x0
    // 0xcb2040: b.hs            #0xcb2408
    // 0xcb2044: LoadField: r11 = r4->field_2b
    //     0xcb2044: ldur            w11, [x4, #0x2b]
    // 0xcb2048: mov             x0, x6
    // 0xcb204c: stur            x11, [fp, #-0x28]
    // 0xcb2050: r1 = 6
    //     0xcb2050: mov             x1, #6
    // 0xcb2054: cmp             x1, x0
    // 0xcb2058: b.hs            #0xcb240c
    // 0xcb205c: LoadField: r12 = r4->field_2f
    //     0xcb205c: ldur            w12, [x4, #0x2f]
    // 0xcb2060: mov             x0, x6
    // 0xcb2064: stur            x12, [fp, #-0x18]
    // 0xcb2068: r1 = 7
    //     0xcb2068: mov             x1, #7
    // 0xcb206c: cmp             x1, x0
    // 0xcb2070: b.hs            #0xcb2410
    // 0xcb2074: LoadField: r6 = r4->field_33
    //     0xcb2074: ldur            w6, [x4, #0x33]
    // 0xcb2078: stur            x6, [fp, #-8]
    // 0xcb207c: mov             x13, x5
    // 0xcb2080: ubfx            x13, x13, #0, #0x20
    // 0xcb2084: mov             x14, x7
    // 0xcb2088: ubfx            x14, x14, #0, #0x20
    // 0xcb208c: mov             x19, x8
    // 0xcb2090: ubfx            x19, x19, #0, #0x20
    // 0xcb2094: mov             x20, x9
    // 0xcb2098: ubfx            x20, x20, #0, #0x20
    // 0xcb209c: mov             x23, x10
    // 0xcb20a0: ubfx            x23, x23, #0, #0x20
    // 0xcb20a4: mov             x24, x11
    // 0xcb20a8: ubfx            x24, x24, #0, #0x20
    // 0xcb20ac: mov             x25, x12
    // 0xcb20b0: ubfx            x25, x25, #0, #0x20
    // 0xcb20b4: mov             x0, x6
    // 0xcb20b8: ubfx            x0, x0, #0, #0x20
    // 0xcb20bc: LoadField: r1 = r3->field_13
    //     0xcb20bc: ldur            w1, [x3, #0x13]
    // 0xcb20c0: DecompressPointer r1
    //     0xcb20c0: add             x1, x1, HEAP, lsl #32
    // 0xcb20c4: r6 = LoadInt32Instr(r1)
    //     0xcb20c4: sbfx            x6, x1, #1, #0x1f
    // 0xcb20c8: mov             x11, x13
    // 0xcb20cc: stur            x25, [fp, #-0x20]
    // 0xcb20d0: mov             x25, x14
    // 0xcb20d4: mov             x12, x19
    // 0xcb20d8: stur            x0, [fp, #-0x10]
    // 0xcb20dc: mov             x0, x24
    // 0xcb20e0: mov             x24, x20
    // 0xcb20e4: mov             x1, x23
    // 0xcb20e8: r23 = 0
    //     0xcb20e8: mov             x23, #0
    // 0xcb20ec: r20 = const [1116352408, 1899447441, 3049323471, 3921009573, 0x3956c25b, 1508970993, 2453635748, 2870763221, 3624381080, 0x12835b01, 0x243185be, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 0xfc19dc6, 0x240ca1cc, 0x2de92c6f, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 0x6ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298]
    //     0xcb20ec: add             x20, PP, #0x1d, lsl #12  ; [pp+0x1d688] List<int>(64)
    //     0xcb20f0: ldr             x20, [x20, #0x688]
    // 0xcb20f4: r19 = 2
    //     0xcb20f4: mov             x19, #2
    // 0xcb20f8: r14 = 7
    //     0xcb20f8: mov             x14, #7
    // 0xcb20fc: r13 = 6
    //     0xcb20fc: mov             x13, #6
    // 0xcb2100: stur            x24, [fp, #-0x40]
    // 0xcb2104: stur            x12, [fp, #-0x50]
    // 0xcb2108: stur            x0, [fp, #-0x58]
    // 0xcb210c: CheckStackOverflow
    //     0xcb210c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb2110: cmp             SP, x16
    //     0xcb2114: b.ls            #0xcb2414
    // 0xcb2118: cmp             x23, #0x40
    // 0xcb211c: b.ge            #0xcb2328
    // 0xcb2120: mov             x10, x1
    // 0xcb2124: ubfx            x10, x10, #0, #0x20
    // 0xcb2128: tbnz            x13, #0x3f, #0xcb241c
    // 0xcb212c: lsr             w9, w10, w13
    // 0xcb2130: cmp             x13, #0x1f
    // 0xcb2134: csel            x9, x9, xzr, le
    // 0xcb2138: mov             x10, x1
    // 0xcb213c: ubfx            x10, x10, #0, #0x20
    // 0xcb2140: lsl             w24, w10, #0x1a
    // 0xcb2144: orr             x10, x9, x24
    // 0xcb2148: mov             x9, x1
    // 0xcb214c: ubfx            x9, x9, #0, #0x20
    // 0xcb2150: lsr             w24, w9, #0xb
    // 0xcb2154: mov             x9, x1
    // 0xcb2158: ubfx            x9, x9, #0, #0x20
    // 0xcb215c: lsl             w8, w9, #0x15
    // 0xcb2160: orr             x9, x24, x8
    // 0xcb2164: eor             x8, x10, x9
    // 0xcb2168: mov             x9, x1
    // 0xcb216c: ubfx            x9, x9, #0, #0x20
    // 0xcb2170: lsr             w10, w9, #0x19
    // 0xcb2174: mov             x9, x1
    // 0xcb2178: ubfx            x9, x9, #0, #0x20
    // 0xcb217c: tbnz            x14, #0x3f, #0xcb245c
    // 0xcb2180: lsl             w24, w9, w14
    // 0xcb2184: cmp             x14, #0x1f
    // 0xcb2188: csel            x24, x24, xzr, le
    // 0xcb218c: orr             x9, x10, x24
    // 0xcb2190: eor             x10, x8, x9
    // 0xcb2194: ldur            x8, [fp, #-0x10]
    // 0xcb2198: ubfx            x8, x8, #0, #0x20
    // 0xcb219c: add             w9, w8, w10
    // 0xcb21a0: mov             x8, x1
    // 0xcb21a4: ubfx            x8, x8, #0, #0x20
    // 0xcb21a8: mov             x10, x0
    // 0xcb21ac: ubfx            x10, x10, #0, #0x20
    // 0xcb21b0: and             x24, x8, x10
    // 0xcb21b4: mov             x8, x1
    // 0xcb21b8: ubfx            x8, x8, #0, #0x20
    // 0xcb21bc: mvn             w10, w8
    // 0xcb21c0: ldur            x8, [fp, #-0x20]
    // 0xcb21c4: ubfx            x8, x8, #0, #0x20
    // 0xcb21c8: and             x12, x10, x8
    // 0xcb21cc: ubfx            x24, x24, #0, #0x20
    // 0xcb21d0: ubfx            x12, x12, #0, #0x20
    // 0xcb21d4: eor             x8, x24, x12
    // 0xcb21d8: ArrayLoad: r10 = r20[r23]  ; Unknown_4
    //     0xcb21d8: add             x16, x20, x23, lsl #2
    //     0xcb21dc: ldur            w10, [x16, #0xf]
    // 0xcb21e0: DecompressPointer r10
    //     0xcb21e0: add             x10, x10, HEAP, lsl #32
    // 0xcb21e4: mov             x24, x0
    // 0xcb21e8: mov             x0, x6
    // 0xcb21ec: mov             x12, x1
    // 0xcb21f0: mov             x1, x23
    // 0xcb21f4: cmp             x1, x0
    // 0xcb21f8: b.hs            #0xcb249c
    // 0xcb21fc: ArrayLoad: r1 = r3[r23]  ; Unknown_4
    //     0xcb21fc: add             x16, x3, x23, lsl #2
    //     0xcb2200: ldur            w1, [x16, #0x17]
    // 0xcb2204: r0 = LoadInt32Instr(r10)
    //     0xcb2204: sbfx            x0, x10, #1, #0x1f
    //     0xcb2208: tbz             w10, #0, #0xcb2210
    //     0xcb220c: ldur            x0, [x10, #7]
    // 0xcb2210: add             w10, w0, w1
    // 0xcb2214: ubfx            x8, x8, #0, #0x20
    // 0xcb2218: add             w1, w8, w10
    // 0xcb221c: add             w8, w9, w1
    // 0xcb2220: mov             x1, x11
    // 0xcb2224: ubfx            x1, x1, #0, #0x20
    // 0xcb2228: tbnz            x19, #0x3f, #0xcb24a0
    // 0xcb222c: lsr             w9, w1, w19
    // 0xcb2230: cmp             x19, #0x1f
    // 0xcb2234: csel            x9, x9, xzr, le
    // 0xcb2238: mov             x1, x11
    // 0xcb223c: ubfx            x1, x1, #0, #0x20
    // 0xcb2240: lsl             w10, w1, #0x1e
    // 0xcb2244: orr             x1, x9, x10
    // 0xcb2248: mov             x9, x11
    // 0xcb224c: ubfx            x9, x9, #0, #0x20
    // 0xcb2250: lsr             w10, w9, #0xd
    // 0xcb2254: mov             x9, x11
    // 0xcb2258: ubfx            x9, x9, #0, #0x20
    // 0xcb225c: lsl             w0, w9, #0x13
    // 0xcb2260: orr             x9, x10, x0
    // 0xcb2264: eor             x10, x1, x9
    // 0xcb2268: mov             x1, x11
    // 0xcb226c: ubfx            x1, x1, #0, #0x20
    // 0xcb2270: lsr             w9, w1, #0x16
    // 0xcb2274: mov             x1, x11
    // 0xcb2278: ubfx            x1, x1, #0, #0x20
    // 0xcb227c: lsl             w0, w1, #0xa
    // 0xcb2280: orr             x1, x9, x0
    // 0xcb2284: eor             x9, x10, x1
    // 0xcb2288: mov             x1, x11
    // 0xcb228c: ubfx            x1, x1, #0, #0x20
    // 0xcb2290: mov             x10, x25
    // 0xcb2294: ubfx            x10, x10, #0, #0x20
    // 0xcb2298: and             x0, x1, x10
    // 0xcb229c: mov             x1, x11
    // 0xcb22a0: ubfx            x1, x1, #0, #0x20
    // 0xcb22a4: ldur            x10, [fp, #-0x50]
    // 0xcb22a8: ubfx            x10, x10, #0, #0x20
    // 0xcb22ac: and             x24, x1, x10
    // 0xcb22b0: eor             x1, x0, x24
    // 0xcb22b4: mov             x10, x25
    // 0xcb22b8: ubfx            x10, x10, #0, #0x20
    // 0xcb22bc: ldur            x24, [fp, #-0x50]
    // 0xcb22c0: ubfx            x24, x24, #0, #0x20
    // 0xcb22c4: and             x0, x10, x24
    // 0xcb22c8: eor             x10, x1, x0
    // 0xcb22cc: add             w1, w9, w10
    // 0xcb22d0: ldur            x9, [fp, #-0x40]
    // 0xcb22d4: ubfx            x9, x9, #0, #0x20
    // 0xcb22d8: add             w10, w9, w8
    // 0xcb22dc: add             w9, w8, w1
    // 0xcb22e0: add             x8, x23, #1
    // 0xcb22e4: ubfx            x10, x10, #0, #0x20
    // 0xcb22e8: ubfx            x9, x9, #0, #0x20
    // 0xcb22ec: mov             x0, x12
    // 0xcb22f0: mov             x12, x25
    // 0xcb22f4: mov             x25, x11
    // 0xcb22f8: mov             x11, x9
    // 0xcb22fc: ldur            x24, [fp, #-0x50]
    // 0xcb2300: mov             x1, x10
    // 0xcb2304: ldur            x9, [fp, #-0x20]
    // 0xcb2308: stur            x9, [fp, #-0x10]
    // 0xcb230c: ldur            x9, [fp, #-0x58]
    // 0xcb2310: stur            x9, [fp, #-0x20]
    // 0xcb2314: mov             x23, x8
    // 0xcb2318: ldur            x8, [fp, #-0x48]
    // 0xcb231c: ldur            x9, [fp, #-0x38]
    // 0xcb2320: ldur            x10, [fp, #-0x30]
    // 0xcb2324: b               #0xcb2100
    // 0xcb2328: mov             x12, x1
    // 0xcb232c: mov             x1, x8
    // 0xcb2330: mov             x2, x9
    // 0xcb2334: ldur            x3, [fp, #-0x30]
    // 0xcb2338: ldur            x6, [fp, #-0x28]
    // 0xcb233c: ldur            x8, [fp, #-0x18]
    // 0xcb2340: ldur            x9, [fp, #-8]
    // 0xcb2344: ubfx            x11, x11, #0, #0x20
    // 0xcb2348: add             w10, w11, w5
    // 0xcb234c: StoreField: r4->field_17 = r10
    //     0xcb234c: stur            w10, [x4, #0x17]
    // 0xcb2350: ubfx            x25, x25, #0, #0x20
    // 0xcb2354: add             w5, w25, w7
    // 0xcb2358: StoreField: r4->field_1b = r5
    //     0xcb2358: stur            w5, [x4, #0x1b]
    // 0xcb235c: ldur            x5, [fp, #-0x50]
    // 0xcb2360: ubfx            x5, x5, #0, #0x20
    // 0xcb2364: add             w7, w5, w1
    // 0xcb2368: StoreField: r4->field_1f = r7
    //     0xcb2368: stur            w7, [x4, #0x1f]
    // 0xcb236c: ldur            x1, [fp, #-0x40]
    // 0xcb2370: ubfx            x1, x1, #0, #0x20
    // 0xcb2374: add             w5, w1, w2
    // 0xcb2378: StoreField: r4->field_23 = r5
    //     0xcb2378: stur            w5, [x4, #0x23]
    // 0xcb237c: ubfx            x12, x12, #0, #0x20
    // 0xcb2380: add             w1, w12, w3
    // 0xcb2384: StoreField: r4->field_27 = r1
    //     0xcb2384: stur            w1, [x4, #0x27]
    // 0xcb2388: ldur            x1, [fp, #-0x58]
    // 0xcb238c: ubfx            x1, x1, #0, #0x20
    // 0xcb2390: add             w2, w1, w6
    // 0xcb2394: StoreField: r4->field_2b = r2
    //     0xcb2394: stur            w2, [x4, #0x2b]
    // 0xcb2398: ldur            x1, [fp, #-0x20]
    // 0xcb239c: ubfx            x1, x1, #0, #0x20
    // 0xcb23a0: add             w2, w1, w8
    // 0xcb23a4: StoreField: r4->field_2f = r2
    //     0xcb23a4: stur            w2, [x4, #0x2f]
    // 0xcb23a8: ldur            x1, [fp, #-0x10]
    // 0xcb23ac: ubfx            x1, x1, #0, #0x20
    // 0xcb23b0: add             w2, w1, w9
    // 0xcb23b4: StoreField: r4->field_33 = r2
    //     0xcb23b4: stur            w2, [x4, #0x33]
    // 0xcb23b8: r0 = Null
    //     0xcb23b8: mov             x0, NULL
    // 0xcb23bc: LeaveFrame
    //     0xcb23bc: mov             SP, fp
    //     0xcb23c0: ldp             fp, lr, [SP], #0x10
    // 0xcb23c4: ret
    //     0xcb23c4: ret             
    // 0xcb23c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb23c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb23cc: b               #0xcb1e38
    // 0xcb23d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb23d0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb23d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb23d4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb23d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb23d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb23dc: b               #0xcb1e98
    // 0xcb23e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb23e0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb23e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb23e4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb23e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb23e8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb23ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb23ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb23f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb23f0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb23f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb23f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb23f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb23f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb23fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb23fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb2400: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb2400: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb2404: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb2404: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb2408: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb2408: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb240c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb240c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb2410: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb2410: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb2414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb2414: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb2418: b               #0xcb2118
    // 0xcb241c: str             x13, [THR, #0xc0]  ; THR::
    // 0xcb2420: stp             x24, x25, [SP, #-0x10]!
    // 0xcb2424: stp             x20, x23, [SP, #-0x10]!
    // 0xcb2428: stp             x14, x19, [SP, #-0x10]!
    // 0xcb242c: stp             x12, x13, [SP, #-0x10]!
    // 0xcb2430: stp             x10, x11, [SP, #-0x10]!
    // 0xcb2434: stp             x7, x8, [SP, #-0x10]!
    // 0xcb2438: stp             x5, x6, [SP, #-0x10]!
    // 0xcb243c: stp             x3, x4, [SP, #-0x10]!
    // 0xcb2440: stp             x1, x2, [SP, #-0x10]!
    // 0xcb2444: SaveReg r0
    //     0xcb2444: str             x0, [SP, #-8]!
    // 0xcb2448: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcb244c: r4 = 0
    //     0xcb244c: mov             x4, #0
    // 0xcb2450: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcb2454: blr             lr
    // 0xcb2458: brk             #0
    // 0xcb245c: str             x14, [THR, #0xc0]  ; THR::
    // 0xcb2460: stp             x23, x25, [SP, #-0x10]!
    // 0xcb2464: stp             x19, x20, [SP, #-0x10]!
    // 0xcb2468: stp             x13, x14, [SP, #-0x10]!
    // 0xcb246c: stp             x11, x12, [SP, #-0x10]!
    // 0xcb2470: stp             x9, x10, [SP, #-0x10]!
    // 0xcb2474: stp             x7, x8, [SP, #-0x10]!
    // 0xcb2478: stp             x5, x6, [SP, #-0x10]!
    // 0xcb247c: stp             x3, x4, [SP, #-0x10]!
    // 0xcb2480: stp             x1, x2, [SP, #-0x10]!
    // 0xcb2484: SaveReg r0
    //     0xcb2484: str             x0, [SP, #-8]!
    // 0xcb2488: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcb248c: r4 = 0
    //     0xcb248c: mov             x4, #0
    // 0xcb2490: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcb2494: blr             lr
    // 0xcb2498: brk             #0
    // 0xcb249c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb249c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb24a0: str             x19, [THR, #0xc0]  ; THR::
    // 0xcb24a4: stp             x24, x25, [SP, #-0x10]!
    // 0xcb24a8: stp             x20, x23, [SP, #-0x10]!
    // 0xcb24ac: stp             x14, x19, [SP, #-0x10]!
    // 0xcb24b0: stp             x12, x13, [SP, #-0x10]!
    // 0xcb24b4: stp             x8, x11, [SP, #-0x10]!
    // 0xcb24b8: stp             x6, x7, [SP, #-0x10]!
    // 0xcb24bc: stp             x4, x5, [SP, #-0x10]!
    // 0xcb24c0: stp             x2, x3, [SP, #-0x10]!
    // 0xcb24c4: SaveReg r1
    //     0xcb24c4: str             x1, [SP, #-8]!
    // 0xcb24c8: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcb24cc: r4 = 0
    //     0xcb24cc: mov             x4, #0
    // 0xcb24d0: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcb24d4: blr             lr
    // 0xcb24d8: brk             #0
  }
}

// class id: 4757, size: 0x34, field offset: 0x34
class _Sha256Sink extends _Sha32BitSink {

  _ _Sha256Sink(/* No info */) {
    // ** addr: 0xc21030, size: 0x12c
    // 0xc21030: EnterFrame
    //     0xc21030: stp             fp, lr, [SP, #-0x10]!
    //     0xc21034: mov             fp, SP
    // 0xc21038: AllocStack(0x8)
    //     0xc21038: sub             SP, SP, #8
    // 0xc2103c: r0 = 16
    //     0xc2103c: mov             x0, #0x10
    // 0xc21040: CheckStackOverflow
    //     0xc21040: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc21044: cmp             SP, x16
    //     0xc21048: b.ls            #0xc21154
    // 0xc2104c: mov             x2, x0
    // 0xc21050: r1 = Null
    //     0xc21050: mov             x1, NULL
    // 0xc21054: r0 = AllocateArray()
    //     0xc21054: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc21058: stur            x0, [fp, #-8]
    // 0xc2105c: r17 = 1779033703
    //     0xc2105c: add             x17, PP, #0xe, lsl #12  ; [pp+0xefd0] 0x6a09e667
    //     0xc21060: ldr             x17, [x17, #0xfd0]
    // 0xc21064: StoreField: r0->field_f = r17
    //     0xc21064: stur            w17, [x0, #0xf]
    // 0xc21068: r17 = 3144134277
    //     0xc21068: add             x17, PP, #0xe, lsl #12  ; [pp+0xefd8] 0xbb67ae85
    //     0xc2106c: ldr             x17, [x17, #0xfd8]
    // 0xc21070: StoreField: r0->field_13 = r17
    //     0xc21070: stur            w17, [x0, #0x13]
    // 0xc21074: r17 = 2027808484
    //     0xc21074: mov             x17, #0xe6e4
    //     0xc21078: movk            x17, #0x78dd, lsl #16
    // 0xc2107c: StoreField: r0->field_17 = r17
    //     0xc2107c: stur            w17, [x0, #0x17]
    // 0xc21080: r17 = 2773480762
    //     0xc21080: add             x17, PP, #0xe, lsl #12  ; [pp+0xefe0] 0xa54ff53a
    //     0xc21084: ldr             x17, [x17, #0xfe0]
    // 0xc21088: StoreField: r0->field_1b = r17
    //     0xc21088: stur            w17, [x0, #0x1b]
    // 0xc2108c: r17 = 1359893119
    //     0xc2108c: add             x17, PP, #0xe, lsl #12  ; [pp+0xefe8] 0x510e527f
    //     0xc21090: ldr             x17, [x17, #0xfe8]
    // 0xc21094: StoreField: r0->field_1f = r17
    //     0xc21094: stur            w17, [x0, #0x1f]
    // 0xc21098: r17 = 2600822924
    //     0xc21098: add             x17, PP, #0xe, lsl #12  ; [pp+0xeff0] 0x9b05688c
    //     0xc2109c: ldr             x17, [x17, #0xff0]
    // 0xc210a0: StoreField: r0->field_23 = r17
    //     0xc210a0: stur            w17, [x0, #0x23]
    // 0xc210a4: r17 = 1057469270
    //     0xc210a4: mov             x17, #0xb356
    //     0xc210a8: movk            x17, #0x3f07, lsl #16
    // 0xc210ac: StoreField: r0->field_27 = r17
    //     0xc210ac: stur            w17, [x0, #0x27]
    // 0xc210b0: r17 = 1541459225
    //     0xc210b0: add             x17, PP, #0xe, lsl #12  ; [pp+0xeff8] 0x5be0cd19
    //     0xc210b4: ldr             x17, [x17, #0xff8]
    // 0xc210b8: StoreField: r0->field_2b = r17
    //     0xc210b8: stur            w17, [x0, #0x2b]
    // 0xc210bc: r1 = <int>
    //     0xc210bc: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xc210c0: r0 = AllocateGrowableArray()
    //     0xc210c0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xc210c4: mov             x1, x0
    // 0xc210c8: ldur            x0, [fp, #-8]
    // 0xc210cc: StoreField: r1->field_f = r0
    //     0xc210cc: stur            w0, [x1, #0xf]
    // 0xc210d0: r0 = 16
    //     0xc210d0: mov             x0, #0x10
    // 0xc210d4: StoreField: r1->field_b = r0
    //     0xc210d4: stur            w0, [x1, #0xb]
    // 0xc210d8: stp             x1, NULL, [SP, #-0x10]!
    // 0xc210dc: r0 = Uint32List.fromList()
    //     0xc210dc: bl              #0x52da08  ; [dart:typed_data] Uint32List::Uint32List.fromList
    // 0xc210e0: add             SP, SP, #0x10
    // 0xc210e4: r4 = 128
    //     0xc210e4: mov             x4, #0x80
    // 0xc210e8: stur            x0, [fp, #-8]
    // 0xc210ec: r0 = AllocateUint32Array()
    //     0xc210ec: bl              #0xd691a0  ; AllocateUint32ArrayStub
    // 0xc210f0: ldr             x1, [fp, #0x18]
    // 0xc210f4: StoreField: r1->field_2f = r0
    //     0xc210f4: stur            w0, [x1, #0x2f]
    //     0xc210f8: ldurb           w16, [x1, #-1]
    //     0xc210fc: ldurb           w17, [x0, #-1]
    //     0xc21100: and             x16, x17, x16, lsr #2
    //     0xc21104: tst             x16, HEAP, lsr #32
    //     0xc21108: b.eq            #0xc21110
    //     0xc2110c: bl              #0xd6826c
    // 0xc21110: ldur            x0, [fp, #-8]
    // 0xc21114: StoreField: r1->field_2b = r0
    //     0xc21114: stur            w0, [x1, #0x2b]
    //     0xc21118: ldurb           w16, [x1, #-1]
    //     0xc2111c: ldurb           w17, [x0, #-1]
    //     0xc21120: and             x16, x17, x16, lsr #2
    //     0xc21124: tst             x16, HEAP, lsr #32
    //     0xc21128: b.eq            #0xc21130
    //     0xc2112c: bl              #0xd6826c
    // 0xc21130: ldr             x16, [fp, #0x10]
    // 0xc21134: stp             x16, x1, [SP, #-0x10]!
    // 0xc21138: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc21138: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc2113c: r0 = HashSink()
    //     0xc2113c: bl              #0xc20ec4  ; [package:crypto/src/hash_sink.dart] HashSink::HashSink
    // 0xc21140: add             SP, SP, #0x10
    // 0xc21144: r0 = Null
    //     0xc21144: mov             x0, NULL
    // 0xc21148: LeaveFrame
    //     0xc21148: mov             SP, fp
    //     0xc2114c: ldp             fp, lr, [SP], #0x10
    // 0xc21150: ret
    //     0xc21150: ret             
    // 0xc21154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc21154: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc21158: b               #0xc2104c
  }
}

// class id: 5594, size: 0x14, field offset: 0xc
//   const constructor, 
class _Sha256 extends Hash {

  _Mint field_c;

  _ startChunkedConversion(/* No info */) {
    // ** addr: 0xc7392c, size: 0x54
    // 0xc7392c: EnterFrame
    //     0xc7392c: stp             fp, lr, [SP, #-0x10]!
    //     0xc73930: mov             fp, SP
    // 0xc73934: AllocStack(0x8)
    //     0xc73934: sub             SP, SP, #8
    // 0xc73938: CheckStackOverflow
    //     0xc73938: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7393c: cmp             SP, x16
    //     0xc73940: b.ls            #0xc73978
    // 0xc73944: r0 = _Sha256Sink()
    //     0xc73944: bl              #0xc2115c  ; Allocate_Sha256SinkStub -> _Sha256Sink (size=0x34)
    // 0xc73948: stur            x0, [fp, #-8]
    // 0xc7394c: ldr             x16, [fp, #0x10]
    // 0xc73950: stp             x16, x0, [SP, #-0x10]!
    // 0xc73954: r0 = _Sha256Sink()
    //     0xc73954: bl              #0xc21030  ; [package:crypto/src/sha256.dart] _Sha256Sink::_Sha256Sink
    // 0xc73958: add             SP, SP, #0x10
    // 0xc7395c: r1 = <List<int>>
    //     0xc7395c: ldr             x1, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0xc73960: r0 = _ByteAdapterSink()
    //     0xc73960: bl              #0xc21024  ; Allocate_ByteAdapterSinkStub -> _ByteAdapterSink (size=0x10)
    // 0xc73964: ldur            x1, [fp, #-8]
    // 0xc73968: StoreField: r0->field_b = r1
    //     0xc73968: stur            w1, [x0, #0xb]
    // 0xc7396c: LeaveFrame
    //     0xc7396c: mov             SP, fp
    //     0xc73970: ldp             fp, lr, [SP], #0x10
    // 0xc73974: ret
    //     0xc73974: ret             
    // 0xc73978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc73978: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7397c: b               #0xc73944
  }
}

// lib: , url: package:crypto/src/digest_sink.dart

// class id: 1048813, size: 0x8
class :: {
}

// class id: 4759, size: 0xc, field offset: 0x8
class DigestSink extends Object
    implements Sink<X0> {

  dynamic close(dynamic) {
    // ** addr: 0xbe39dc, size: 0x18
    // 0xbe39dc: r4 = 0
    //     0xbe39dc: mov             x4, #0
    // 0xbe39e0: r1 = Function 'close':.
    //     0xbe39e0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15480] AnonymousClosure: (0xbe3abc), in [package:crypto/src/digest_sink.dart] DigestSink::close (0xc39ec0)
    //     0xbe39e4: ldr             x1, [x17, #0x480]
    // 0xbe39e8: r24 = BuildNonGenericMethodExtractorStub
    //     0xbe39e8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xbe39ec: LoadField: r0 = r24->field_17
    //     0xbe39ec: ldur            x0, [x24, #0x17]
    // 0xbe39f0: br              x0
  }
  [closure] void close(dynamic) {
    // ** addr: 0xbe3abc, size: 0x48
    // 0xbe3abc: EnterFrame
    //     0xbe3abc: stp             fp, lr, [SP, #-0x10]!
    //     0xbe3ac0: mov             fp, SP
    // 0xbe3ac4: ldr             x0, [fp, #0x10]
    // 0xbe3ac8: LoadField: r1 = r0->field_17
    //     0xbe3ac8: ldur            w1, [x0, #0x17]
    // 0xbe3acc: DecompressPointer r1
    //     0xbe3acc: add             x1, x1, HEAP, lsl #32
    // 0xbe3ad0: CheckStackOverflow
    //     0xbe3ad0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe3ad4: cmp             SP, x16
    //     0xbe3ad8: b.ls            #0xbe3afc
    // 0xbe3adc: LoadField: r0 = r1->field_f
    //     0xbe3adc: ldur            w0, [x1, #0xf]
    // 0xbe3ae0: DecompressPointer r0
    //     0xbe3ae0: add             x0, x0, HEAP, lsl #32
    // 0xbe3ae4: SaveReg r0
    //     0xbe3ae4: str             x0, [SP, #-8]!
    // 0xbe3ae8: r0 = close()
    //     0xbe3ae8: bl              #0xc39ec0  ; [package:crypto/src/digest_sink.dart] DigestSink::close
    // 0xbe3aec: add             SP, SP, #8
    // 0xbe3af0: LeaveFrame
    //     0xbe3af0: mov             SP, fp
    //     0xbe3af4: ldp             fp, lr, [SP], #0x10
    // 0xbe3af8: ret
    //     0xbe3af8: ret             
    // 0xbe3afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe3afc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe3b00: b               #0xbe3adc
  }
  dynamic add(dynamic) {
    // ** addr: 0xbe6cc4, size: 0x18
    // 0xbe6cc4: r4 = 0
    //     0xbe6cc4: mov             x4, #0
    // 0xbe6cc8: r1 = Function 'add':.
    //     0xbe6cc8: add             x17, PP, #0x15, lsl #12  ; [pp+0x15488] AnonymousClosure: (0xbe6cdc), in [package:crypto/src/digest_sink.dart] DigestSink::add (0xc4df2c)
    //     0xbe6ccc: ldr             x1, [x17, #0x488]
    // 0xbe6cd0: r24 = BuildNonGenericMethodExtractorStub
    //     0xbe6cd0: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xbe6cd4: LoadField: r0 = r24->field_17
    //     0xbe6cd4: ldur            x0, [x24, #0x17]
    // 0xbe6cd8: br              x0
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0xbe6cdc, size: 0x4c
    // 0xbe6cdc: EnterFrame
    //     0xbe6cdc: stp             fp, lr, [SP, #-0x10]!
    //     0xbe6ce0: mov             fp, SP
    // 0xbe6ce4: ldr             x0, [fp, #0x18]
    // 0xbe6ce8: LoadField: r1 = r0->field_17
    //     0xbe6ce8: ldur            w1, [x0, #0x17]
    // 0xbe6cec: DecompressPointer r1
    //     0xbe6cec: add             x1, x1, HEAP, lsl #32
    // 0xbe6cf0: CheckStackOverflow
    //     0xbe6cf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe6cf4: cmp             SP, x16
    //     0xbe6cf8: b.ls            #0xbe6d20
    // 0xbe6cfc: LoadField: r0 = r1->field_f
    //     0xbe6cfc: ldur            w0, [x1, #0xf]
    // 0xbe6d00: DecompressPointer r0
    //     0xbe6d00: add             x0, x0, HEAP, lsl #32
    // 0xbe6d04: ldr             x16, [fp, #0x10]
    // 0xbe6d08: stp             x16, x0, [SP, #-0x10]!
    // 0xbe6d0c: r0 = add()
    //     0xbe6d0c: bl              #0xc4df2c  ; [package:crypto/src/digest_sink.dart] DigestSink::add
    // 0xbe6d10: add             SP, SP, #0x10
    // 0xbe6d14: LeaveFrame
    //     0xbe6d14: mov             SP, fp
    //     0xbe6d18: ldp             fp, lr, [SP], #0x10
    // 0xbe6d1c: ret
    //     0xbe6d1c: ret             
    // 0xbe6d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe6d20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe6d24: b               #0xbe6cfc
  }
  _ close(/* No info */) {
    // ** addr: 0xc39ec0, size: 0x4c
    // 0xc39ec0: EnterFrame
    //     0xc39ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xc39ec4: mov             fp, SP
    // 0xc39ec8: ldr             x0, [fp, #0x10]
    // 0xc39ecc: LoadField: r1 = r0->field_7
    //     0xc39ecc: ldur            w1, [x0, #7]
    // 0xc39ed0: DecompressPointer r1
    //     0xc39ed0: add             x1, x1, HEAP, lsl #32
    // 0xc39ed4: cmp             w1, NULL
    // 0xc39ed8: b.eq            #0xc39eec
    // 0xc39edc: r0 = Null
    //     0xc39edc: mov             x0, NULL
    // 0xc39ee0: LeaveFrame
    //     0xc39ee0: mov             SP, fp
    //     0xc39ee4: ldp             fp, lr, [SP], #0x10
    // 0xc39ee8: ret
    //     0xc39ee8: ret             
    // 0xc39eec: r0 = StateError()
    //     0xc39eec: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc39ef0: mov             x1, x0
    // 0xc39ef4: r0 = "add must be called once."
    //     0xc39ef4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15490] "add must be called once."
    //     0xc39ef8: ldr             x0, [x0, #0x490]
    // 0xc39efc: StoreField: r1->field_b = r0
    //     0xc39efc: stur            w0, [x1, #0xb]
    // 0xc39f00: mov             x0, x1
    // 0xc39f04: r0 = Throw()
    //     0xc39f04: bl              #0xd67e38  ; ThrowStub
    // 0xc39f08: brk             #0
  }
  _ add(/* No info */) {
    // ** addr: 0xc4df2c, size: 0x6c
    // 0xc4df2c: EnterFrame
    //     0xc4df2c: stp             fp, lr, [SP, #-0x10]!
    //     0xc4df30: mov             fp, SP
    // 0xc4df34: ldr             x1, [fp, #0x18]
    // 0xc4df38: LoadField: r0 = r1->field_7
    //     0xc4df38: ldur            w0, [x1, #7]
    // 0xc4df3c: DecompressPointer r0
    //     0xc4df3c: add             x0, x0, HEAP, lsl #32
    // 0xc4df40: cmp             w0, NULL
    // 0xc4df44: b.ne            #0xc4df78
    // 0xc4df48: ldr             x0, [fp, #0x10]
    // 0xc4df4c: StoreField: r1->field_7 = r0
    //     0xc4df4c: stur            w0, [x1, #7]
    //     0xc4df50: ldurb           w16, [x1, #-1]
    //     0xc4df54: ldurb           w17, [x0, #-1]
    //     0xc4df58: and             x16, x17, x16, lsr #2
    //     0xc4df5c: tst             x16, HEAP, lsr #32
    //     0xc4df60: b.eq            #0xc4df68
    //     0xc4df64: bl              #0xd6826c
    // 0xc4df68: r0 = Null
    //     0xc4df68: mov             x0, NULL
    // 0xc4df6c: LeaveFrame
    //     0xc4df6c: mov             SP, fp
    //     0xc4df70: ldp             fp, lr, [SP], #0x10
    // 0xc4df74: ret
    //     0xc4df74: ret             
    // 0xc4df78: r0 = StateError()
    //     0xc4df78: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc4df7c: mov             x1, x0
    // 0xc4df80: r0 = "add may only be called once."
    //     0xc4df80: add             x0, PP, #0x15, lsl #12  ; [pp+0x15498] "add may only be called once."
    //     0xc4df84: ldr             x0, [x0, #0x498]
    // 0xc4df88: StoreField: r1->field_b = r0
    //     0xc4df88: stur            w0, [x1, #0xb]
    // 0xc4df8c: mov             x0, x1
    // 0xc4df90: r0 = Throw()
    //     0xc4df90: bl              #0xd67e38  ; ThrowStub
    // 0xc4df94: brk             #0
  }
}

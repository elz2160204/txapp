// lib: , url: package:crypto/src/hash.dart

// class id: 1048814, size: 0x8
class :: {
}

// class id: 5593, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class Hash extends Converter<List<int>, Digest> {

  _ convert(/* No info */) {
    // ** addr: 0xc20d20, size: 0xf0
    // 0xc20d20: EnterFrame
    //     0xc20d20: stp             fp, lr, [SP, #-0x10]!
    //     0xc20d24: mov             fp, SP
    // 0xc20d28: AllocStack(0x10)
    //     0xc20d28: sub             SP, SP, #0x10
    // 0xc20d2c: CheckStackOverflow
    //     0xc20d2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc20d30: cmp             SP, x16
    //     0xc20d34: b.ls            #0xc20e04
    // 0xc20d38: r0 = DigestSink()
    //     0xc20d38: bl              #0xc21168  ; AllocateDigestSinkStub -> DigestSink (size=0xc)
    // 0xc20d3c: mov             x1, x0
    // 0xc20d40: ldr             x0, [fp, #0x18]
    // 0xc20d44: stur            x1, [fp, #-8]
    // 0xc20d48: r2 = LoadClassIdInstr(r0)
    //     0xc20d48: ldur            x2, [x0, #-1]
    //     0xc20d4c: ubfx            x2, x2, #0xc, #0x14
    // 0xc20d50: lsl             x2, x2, #1
    // 0xc20d54: r17 = 11188
    //     0xc20d54: mov             x17, #0x2bb4
    // 0xc20d58: cmp             w2, w17
    // 0xc20d5c: b.ne            #0xc20d90
    // 0xc20d60: r0 = _Sha256Sink()
    //     0xc20d60: bl              #0xc2115c  ; Allocate_Sha256SinkStub -> _Sha256Sink (size=0x34)
    // 0xc20d64: stur            x0, [fp, #-0x10]
    // 0xc20d68: ldur            x16, [fp, #-8]
    // 0xc20d6c: stp             x16, x0, [SP, #-0x10]!
    // 0xc20d70: r0 = _Sha256Sink()
    //     0xc20d70: bl              #0xc21030  ; [package:crypto/src/sha256.dart] _Sha256Sink::_Sha256Sink
    // 0xc20d74: add             SP, SP, #0x10
    // 0xc20d78: r1 = <List<int>>
    //     0xc20d78: ldr             x1, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0xc20d7c: r0 = _ByteAdapterSink()
    //     0xc20d7c: bl              #0xc21024  ; Allocate_ByteAdapterSinkStub -> _ByteAdapterSink (size=0x10)
    // 0xc20d80: mov             x1, x0
    // 0xc20d84: ldur            x0, [fp, #-0x10]
    // 0xc20d88: StoreField: r1->field_b = r0
    //     0xc20d88: stur            w0, [x1, #0xb]
    // 0xc20d8c: b               #0xc20dbc
    // 0xc20d90: r0 = _MD5Sink()
    //     0xc20d90: bl              #0xc21018  ; Allocate_MD5SinkStub -> _MD5Sink (size=0x30)
    // 0xc20d94: stur            x0, [fp, #-0x10]
    // 0xc20d98: ldur            x16, [fp, #-8]
    // 0xc20d9c: stp             x16, x0, [SP, #-0x10]!
    // 0xc20da0: r0 = _MD5Sink()
    //     0xc20da0: bl              #0xc20e10  ; [package:crypto/src/md5.dart] _MD5Sink::_MD5Sink
    // 0xc20da4: add             SP, SP, #0x10
    // 0xc20da8: r1 = <List<int>>
    //     0xc20da8: ldr             x1, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0xc20dac: r0 = _ByteAdapterSink()
    //     0xc20dac: bl              #0xc21024  ; Allocate_ByteAdapterSinkStub -> _ByteAdapterSink (size=0x10)
    // 0xc20db0: mov             x1, x0
    // 0xc20db4: ldur            x0, [fp, #-0x10]
    // 0xc20db8: StoreField: r1->field_b = r0
    //     0xc20db8: stur            w0, [x1, #0xb]
    // 0xc20dbc: ldur            x0, [fp, #-8]
    // 0xc20dc0: stur            x1, [fp, #-0x10]
    // 0xc20dc4: ldr             x16, [fp, #0x10]
    // 0xc20dc8: stp             x16, x1, [SP, #-0x10]!
    // 0xc20dcc: r0 = add()
    //     0xc20dcc: bl              #0xc2f4e4  ; [dart:convert] _ByteAdapterSink::add
    // 0xc20dd0: add             SP, SP, #0x10
    // 0xc20dd4: ldur            x16, [fp, #-0x10]
    // 0xc20dd8: SaveReg r16
    //     0xc20dd8: str             x16, [SP, #-8]!
    // 0xc20ddc: r0 = close()
    //     0xc20ddc: bl              #0xc0a49c  ; [dart:convert] _ByteAdapterSink::close
    // 0xc20de0: add             SP, SP, #8
    // 0xc20de4: ldur            x1, [fp, #-8]
    // 0xc20de8: LoadField: r0 = r1->field_7
    //     0xc20de8: ldur            w0, [x1, #7]
    // 0xc20dec: DecompressPointer r0
    //     0xc20dec: add             x0, x0, HEAP, lsl #32
    // 0xc20df0: cmp             w0, NULL
    // 0xc20df4: b.eq            #0xc20e0c
    // 0xc20df8: LeaveFrame
    //     0xc20df8: mov             SP, fp
    //     0xc20dfc: ldp             fp, lr, [SP], #0x10
    // 0xc20e00: ret
    //     0xc20e00: ret             
    // 0xc20e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20e04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20e08: b               #0xc20d38
    // 0xc20e0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc20e0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:crypto/src/hash_sink.dart

// class id: 1048815, size: 0x8
class :: {
}

// class id: 4755, size: 0x2c, field offset: 0x8
abstract class HashSink extends Object
    implements Sink<X0> {

  dynamic close(dynamic) {
    // ** addr: 0xbe3b04, size: 0x18
    // 0xbe3b04: r4 = 0
    //     0xbe3b04: mov             x4, #0
    // 0xbe3b08: r1 = Function 'close':.
    //     0xbe3b08: add             x17, PP, #0x15, lsl #12  ; [pp+0x15410] AnonymousClosure: (0xbe3b1c), in [package:crypto/src/hash_sink.dart] HashSink::close (0xc39f0c)
    //     0xbe3b0c: ldr             x1, [x17, #0x410]
    // 0xbe3b10: r24 = BuildNonGenericMethodExtractorStub
    //     0xbe3b10: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xbe3b14: LoadField: r0 = r24->field_17
    //     0xbe3b14: ldur            x0, [x24, #0x17]
    // 0xbe3b18: br              x0
  }
  [closure] void close(dynamic) {
    // ** addr: 0xbe3b1c, size: 0x48
    // 0xbe3b1c: EnterFrame
    //     0xbe3b1c: stp             fp, lr, [SP, #-0x10]!
    //     0xbe3b20: mov             fp, SP
    // 0xbe3b24: ldr             x0, [fp, #0x10]
    // 0xbe3b28: LoadField: r1 = r0->field_17
    //     0xbe3b28: ldur            w1, [x0, #0x17]
    // 0xbe3b2c: DecompressPointer r1
    //     0xbe3b2c: add             x1, x1, HEAP, lsl #32
    // 0xbe3b30: CheckStackOverflow
    //     0xbe3b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe3b34: cmp             SP, x16
    //     0xbe3b38: b.ls            #0xbe3b5c
    // 0xbe3b3c: LoadField: r0 = r1->field_f
    //     0xbe3b3c: ldur            w0, [x1, #0xf]
    // 0xbe3b40: DecompressPointer r0
    //     0xbe3b40: add             x0, x0, HEAP, lsl #32
    // 0xbe3b44: SaveReg r0
    //     0xbe3b44: str             x0, [SP, #-8]!
    // 0xbe3b48: r0 = close()
    //     0xbe3b48: bl              #0xc39f0c  ; [package:crypto/src/hash_sink.dart] HashSink::close
    // 0xbe3b4c: add             SP, SP, #8
    // 0xbe3b50: LeaveFrame
    //     0xbe3b50: mov             SP, fp
    //     0xbe3b54: ldp             fp, lr, [SP], #0x10
    // 0xbe3b58: ret
    //     0xbe3b58: ret             
    // 0xbe3b5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe3b5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe3b60: b               #0xbe3b3c
  }
  dynamic add(dynamic) {
    // ** addr: 0xbe6d28, size: 0x18
    // 0xbe6d28: r4 = 0
    //     0xbe6d28: mov             x4, #0
    // 0xbe6d2c: r1 = Function 'add':.
    //     0xbe6d2c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15418] AnonymousClosure: (0xbe6d40), in [package:crypto/src/hash_sink.dart] HashSink::add (0xc4df98)
    //     0xbe6d30: ldr             x1, [x17, #0x418]
    // 0xbe6d34: r24 = BuildNonGenericMethodExtractorStub
    //     0xbe6d34: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xbe6d38: LoadField: r0 = r24->field_17
    //     0xbe6d38: ldur            x0, [x24, #0x17]
    // 0xbe6d3c: br              x0
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0xbe6d40, size: 0x4c
    // 0xbe6d40: EnterFrame
    //     0xbe6d40: stp             fp, lr, [SP, #-0x10]!
    //     0xbe6d44: mov             fp, SP
    // 0xbe6d48: ldr             x0, [fp, #0x18]
    // 0xbe6d4c: LoadField: r1 = r0->field_17
    //     0xbe6d4c: ldur            w1, [x0, #0x17]
    // 0xbe6d50: DecompressPointer r1
    //     0xbe6d50: add             x1, x1, HEAP, lsl #32
    // 0xbe6d54: CheckStackOverflow
    //     0xbe6d54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe6d58: cmp             SP, x16
    //     0xbe6d5c: b.ls            #0xbe6d84
    // 0xbe6d60: LoadField: r0 = r1->field_f
    //     0xbe6d60: ldur            w0, [x1, #0xf]
    // 0xbe6d64: DecompressPointer r0
    //     0xbe6d64: add             x0, x0, HEAP, lsl #32
    // 0xbe6d68: ldr             x16, [fp, #0x10]
    // 0xbe6d6c: stp             x16, x0, [SP, #-0x10]!
    // 0xbe6d70: r0 = add()
    //     0xbe6d70: bl              #0xc4df98  ; [package:crypto/src/hash_sink.dart] HashSink::add
    // 0xbe6d74: add             SP, SP, #0x10
    // 0xbe6d78: LeaveFrame
    //     0xbe6d78: mov             SP, fp
    //     0xbe6d7c: ldp             fp, lr, [SP], #0x10
    // 0xbe6d80: ret
    //     0xbe6d80: ret             
    // 0xbe6d84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe6d84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe6d88: b               #0xbe6d60
  }
  _ HashSink(/* No info */) {
    // ** addr: 0xc20ec4, size: 0x148
    // 0xc20ec4: EnterFrame
    //     0xc20ec4: stp             fp, lr, [SP, #-0x10]!
    //     0xc20ec8: mov             fp, SP
    // 0xc20ecc: AllocStack(0x20)
    //     0xc20ecc: sub             SP, SP, #0x20
    // 0xc20ed0: SetupParameters(HashSink this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic endian = Instance_Endian /* r2 */})
    //     0xc20ed0: mov             x0, x4
    //     0xc20ed4: ldur            w1, [x0, #0x13]
    //     0xc20ed8: add             x1, x1, HEAP, lsl #32
    //     0xc20edc: sub             x2, x1, #4
    //     0xc20ee0: add             x3, fp, w2, sxtw #2
    //     0xc20ee4: ldr             x3, [x3, #0x18]
    //     0xc20ee8: stur            x3, [fp, #-0x18]
    //     0xc20eec: add             x4, fp, w2, sxtw #2
    //     0xc20ef0: ldr             x4, [x4, #0x10]
    //     0xc20ef4: stur            x4, [fp, #-0x10]
    //     0xc20ef8: ldur            w2, [x0, #0x1f]
    //     0xc20efc: add             x2, x2, HEAP, lsl #32
    //     0xc20f00: add             x16, PP, #0xe, lsl #12  ; [pp+0xefc8] "endian"
    //     0xc20f04: ldr             x16, [x16, #0xfc8]
    //     0xc20f08: cmp             w2, w16
    //     0xc20f0c: b.ne            #0xc20f2c
    //     0xc20f10: ldur            w2, [x0, #0x23]
    //     0xc20f14: add             x2, x2, HEAP, lsl #32
    //     0xc20f18: sub             w0, w1, w2
    //     0xc20f1c: add             x1, fp, w0, sxtw #2
    //     0xc20f20: ldr             x1, [x1, #8]
    //     0xc20f24: mov             x2, x1
    //     0xc20f28: b               #0xc20f30
    //     0xc20f2c: ldr             x2, [PP, #0x7f78]  ; [pp+0x7f78] Obj!Endian@b5f5b1
    // 0xc20f30: r1 = false
    //     0xc20f30: add             x1, NULL, #0x30  ; false
    // 0xc20f34: r0 = 0
    //     0xc20f34: mov             x0, #0
    // 0xc20f38: stur            x2, [fp, #-8]
    // 0xc20f3c: StoreField: r3->field_13 = r0
    //     0xc20f3c: stur            x0, [x3, #0x13]
    // 0xc20f40: StoreField: r3->field_1f = r1
    //     0xc20f40: stur            w1, [x3, #0x1f]
    // 0xc20f44: r1 = <int>
    //     0xc20f44: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xc20f48: r0 = Uint8Buffer()
    //     0xc20f48: bl              #0xc2100c  ; AllocateUint8BufferStub -> Uint8Buffer (size=0x18)
    // 0xc20f4c: r4 = 0
    //     0xc20f4c: mov             x4, #0
    // 0xc20f50: stur            x0, [fp, #-0x20]
    // 0xc20f54: r0 = AllocateUint8Array()
    //     0xc20f54: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xc20f58: mov             x1, x0
    // 0xc20f5c: ldur            x0, [fp, #-0x20]
    // 0xc20f60: StoreField: r0->field_b = r1
    //     0xc20f60: stur            w1, [x0, #0xb]
    // 0xc20f64: r1 = 0
    //     0xc20f64: mov             x1, #0
    // 0xc20f68: StoreField: r0->field_f = r1
    //     0xc20f68: stur            x1, [x0, #0xf]
    // 0xc20f6c: ldur            x1, [fp, #-0x18]
    // 0xc20f70: StoreField: r1->field_1b = r0
    //     0xc20f70: stur            w0, [x1, #0x1b]
    //     0xc20f74: ldurb           w16, [x1, #-1]
    //     0xc20f78: ldurb           w17, [x0, #-1]
    //     0xc20f7c: and             x16, x17, x16, lsr #2
    //     0xc20f80: tst             x16, HEAP, lsr #32
    //     0xc20f84: b.eq            #0xc20f8c
    //     0xc20f88: bl              #0xd6826c
    // 0xc20f8c: ldur            x0, [fp, #-0x10]
    // 0xc20f90: StoreField: r1->field_7 = r0
    //     0xc20f90: stur            w0, [x1, #7]
    //     0xc20f94: ldurb           w16, [x1, #-1]
    //     0xc20f98: ldurb           w17, [x0, #-1]
    //     0xc20f9c: and             x16, x17, x16, lsr #2
    //     0xc20fa0: tst             x16, HEAP, lsr #32
    //     0xc20fa4: b.eq            #0xc20fac
    //     0xc20fa8: bl              #0xd6826c
    // 0xc20fac: ldur            x0, [fp, #-8]
    // 0xc20fb0: StoreField: r1->field_b = r0
    //     0xc20fb0: stur            w0, [x1, #0xb]
    //     0xc20fb4: ldurb           w16, [x1, #-1]
    //     0xc20fb8: ldurb           w17, [x0, #-1]
    //     0xc20fbc: and             x16, x17, x16, lsr #2
    //     0xc20fc0: tst             x16, HEAP, lsr #32
    //     0xc20fc4: b.eq            #0xc20fcc
    //     0xc20fc8: bl              #0xd6826c
    // 0xc20fcc: r0 = 8
    //     0xc20fcc: mov             x0, #8
    // 0xc20fd0: StoreField: r1->field_23 = r0
    //     0xc20fd0: stur            x0, [x1, #0x23]
    // 0xc20fd4: r4 = 32
    //     0xc20fd4: mov             x4, #0x20
    // 0xc20fd8: r0 = AllocateUint32Array()
    //     0xc20fd8: bl              #0xd691a0  ; AllocateUint32ArrayStub
    // 0xc20fdc: ldur            x1, [fp, #-0x18]
    // 0xc20fe0: StoreField: r1->field_f = r0
    //     0xc20fe0: stur            w0, [x1, #0xf]
    //     0xc20fe4: ldurb           w16, [x1, #-1]
    //     0xc20fe8: ldurb           w17, [x0, #-1]
    //     0xc20fec: and             x16, x17, x16, lsr #2
    //     0xc20ff0: tst             x16, HEAP, lsr #32
    //     0xc20ff4: b.eq            #0xc20ffc
    //     0xc20ff8: bl              #0xd6826c
    // 0xc20ffc: r0 = Null
    //     0xc20ffc: mov             x0, NULL
    // 0xc21000: LeaveFrame
    //     0xc21000: mov             SP, fp
    //     0xc21004: ldp             fp, lr, [SP], #0x10
    // 0xc21008: ret
    //     0xc21008: ret             
  }
  _ close(/* No info */) {
    // ** addr: 0xc39f0c, size: 0xec
    // 0xc39f0c: EnterFrame
    //     0xc39f0c: stp             fp, lr, [SP, #-0x10]!
    //     0xc39f10: mov             fp, SP
    // 0xc39f14: AllocStack(0x10)
    //     0xc39f14: sub             SP, SP, #0x10
    // 0xc39f18: CheckStackOverflow
    //     0xc39f18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc39f1c: cmp             SP, x16
    //     0xc39f20: b.ls            #0xc39ff0
    // 0xc39f24: ldr             x0, [fp, #0x10]
    // 0xc39f28: LoadField: r1 = r0->field_1f
    //     0xc39f28: ldur            w1, [x0, #0x1f]
    // 0xc39f2c: DecompressPointer r1
    //     0xc39f2c: add             x1, x1, HEAP, lsl #32
    // 0xc39f30: tbnz            w1, #4, #0xc39f44
    // 0xc39f34: r0 = Null
    //     0xc39f34: mov             x0, NULL
    // 0xc39f38: LeaveFrame
    //     0xc39f38: mov             SP, fp
    //     0xc39f3c: ldp             fp, lr, [SP], #0x10
    // 0xc39f40: ret
    //     0xc39f40: ret             
    // 0xc39f44: r1 = true
    //     0xc39f44: add             x1, NULL, #0x20  ; true
    // 0xc39f48: StoreField: r0->field_1f = r1
    //     0xc39f48: stur            w1, [x0, #0x1f]
    // 0xc39f4c: SaveReg r0
    //     0xc39f4c: str             x0, [SP, #-8]!
    // 0xc39f50: r0 = _finalizeData()
    //     0xc39f50: bl              #0xc3a570  ; [package:crypto/src/hash_sink.dart] HashSink::_finalizeData
    // 0xc39f54: add             SP, SP, #8
    // 0xc39f58: ldr             x16, [fp, #0x10]
    // 0xc39f5c: SaveReg r16
    //     0xc39f5c: str             x16, [SP, #-8]!
    // 0xc39f60: r0 = _iterate()
    //     0xc39f60: bl              #0xc3a278  ; [package:crypto/src/hash_sink.dart] HashSink::_iterate
    // 0xc39f64: add             SP, SP, #8
    // 0xc39f68: ldr             x0, [fp, #0x10]
    // 0xc39f6c: LoadField: r1 = r0->field_7
    //     0xc39f6c: ldur            w1, [x0, #7]
    // 0xc39f70: DecompressPointer r1
    //     0xc39f70: add             x1, x1, HEAP, lsl #32
    // 0xc39f74: stur            x1, [fp, #-8]
    // 0xc39f78: SaveReg r0
    //     0xc39f78: str             x0, [SP, #-8]!
    // 0xc39f7c: r0 = _byteDigest()
    //     0xc39f7c: bl              #0xc3a004  ; [package:crypto/src/hash_sink.dart] HashSink::_byteDigest
    // 0xc39f80: add             SP, SP, #8
    // 0xc39f84: stur            x0, [fp, #-0x10]
    // 0xc39f88: r0 = Digest()
    //     0xc39f88: bl              #0xc39ff8  ; AllocateDigestStub -> Digest (size=0xc)
    // 0xc39f8c: mov             x1, x0
    // 0xc39f90: ldur            x0, [fp, #-0x10]
    // 0xc39f94: StoreField: r1->field_7 = r0
    //     0xc39f94: stur            w0, [x1, #7]
    // 0xc39f98: ldur            x2, [fp, #-8]
    // 0xc39f9c: r0 = LoadClassIdInstr(r2)
    //     0xc39f9c: ldur            x0, [x2, #-1]
    //     0xc39fa0: ubfx            x0, x0, #0xc, #0x14
    // 0xc39fa4: stp             x1, x2, [SP, #-0x10]!
    // 0xc39fa8: r0 = GDT[cid_x0 + 0x6e6]()
    //     0xc39fa8: add             lr, x0, #0x6e6
    //     0xc39fac: ldr             lr, [x21, lr, lsl #3]
    //     0xc39fb0: blr             lr
    // 0xc39fb4: add             SP, SP, #0x10
    // 0xc39fb8: ldur            x0, [fp, #-8]
    // 0xc39fbc: r1 = LoadClassIdInstr(r0)
    //     0xc39fbc: ldur            x1, [x0, #-1]
    //     0xc39fc0: ubfx            x1, x1, #0xc, #0x14
    // 0xc39fc4: SaveReg r0
    //     0xc39fc4: str             x0, [SP, #-8]!
    // 0xc39fc8: mov             x0, x1
    // 0xc39fcc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc39fcc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc39fd0: r0 = GDT[cid_x0 + 0x8a8]()
    //     0xc39fd0: add             lr, x0, #0x8a8
    //     0xc39fd4: ldr             lr, [x21, lr, lsl #3]
    //     0xc39fd8: blr             lr
    // 0xc39fdc: add             SP, SP, #8
    // 0xc39fe0: r0 = Null
    //     0xc39fe0: mov             x0, NULL
    // 0xc39fe4: LeaveFrame
    //     0xc39fe4: mov             SP, fp
    //     0xc39fe8: ldp             fp, lr, [SP], #0x10
    // 0xc39fec: ret
    //     0xc39fec: ret             
    // 0xc39ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc39ff0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc39ff4: b               #0xc39f24
  }
  _ _byteDigest(/* No info */) {
    // ** addr: 0xc3a004, size: 0x274
    // 0xc3a004: EnterFrame
    //     0xc3a004: stp             fp, lr, [SP, #-0x10]!
    //     0xc3a008: mov             fp, SP
    // 0xc3a00c: AllocStack(0x30)
    //     0xc3a00c: sub             SP, SP, #0x30
    // 0xc3a010: CheckStackOverflow
    //     0xc3a010: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3a014: cmp             SP, x16
    //     0xc3a018: b.ls            #0xc3a268
    // 0xc3a01c: ldr             x0, [fp, #0x10]
    // 0xc3a020: LoadField: r1 = r0->field_b
    //     0xc3a020: ldur            w1, [x0, #0xb]
    // 0xc3a024: DecompressPointer r1
    //     0xc3a024: add             x1, x1, HEAP, lsl #32
    // 0xc3a028: r16 = Instance_Endian
    //     0xc3a028: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xc3a02c: cmp             w1, w16
    // 0xc3a030: b.ne            #0xc3a098
    // 0xc3a034: r1 = LoadClassIdInstr(r0)
    //     0xc3a034: ldur            x1, [x0, #-1]
    //     0xc3a038: ubfx            x1, x1, #0xc, #0x14
    // 0xc3a03c: lsl             x1, x1, #1
    // 0xc3a040: r17 = 9514
    //     0xc3a040: mov             x17, #0x252a
    // 0xc3a044: cmp             w1, w17
    // 0xc3a048: b.ne            #0xc3a05c
    // 0xc3a04c: LoadField: r1 = r0->field_2b
    //     0xc3a04c: ldur            w1, [x0, #0x2b]
    // 0xc3a050: DecompressPointer r1
    //     0xc3a050: add             x1, x1, HEAP, lsl #32
    // 0xc3a054: mov             x0, x1
    // 0xc3a058: b               #0xc3a068
    // 0xc3a05c: LoadField: r1 = r0->field_2b
    //     0xc3a05c: ldur            w1, [x0, #0x2b]
    // 0xc3a060: DecompressPointer r1
    //     0xc3a060: add             x1, x1, HEAP, lsl #32
    // 0xc3a064: mov             x0, x1
    // 0xc3a068: stur            x0, [fp, #-8]
    // 0xc3a06c: r0 = _ByteBuffer()
    //     0xc3a06c: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0xc3a070: mov             x1, x0
    // 0xc3a074: ldur            x0, [fp, #-8]
    // 0xc3a078: StoreField: r1->field_7 = r0
    //     0xc3a078: stur            w0, [x1, #7]
    // 0xc3a07c: SaveReg r1
    //     0xc3a07c: str             x1, [SP, #-8]!
    // 0xc3a080: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc3a080: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc3a084: r0 = asUint8List()
    //     0xc3a084: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0xc3a088: add             SP, SP, #8
    // 0xc3a08c: LeaveFrame
    //     0xc3a08c: mov             SP, fp
    //     0xc3a090: ldp             fp, lr, [SP], #0x10
    // 0xc3a094: ret
    //     0xc3a094: ret             
    // 0xc3a098: r1 = LoadClassIdInstr(r0)
    //     0xc3a098: ldur            x1, [x0, #-1]
    //     0xc3a09c: ubfx            x1, x1, #0xc, #0x14
    // 0xc3a0a0: lsl             x1, x1, #1
    // 0xc3a0a4: r17 = 9514
    //     0xc3a0a4: mov             x17, #0x252a
    // 0xc3a0a8: cmp             w1, w17
    // 0xc3a0ac: b.ne            #0xc3a0c0
    // 0xc3a0b0: LoadField: r1 = r0->field_2b
    //     0xc3a0b0: ldur            w1, [x0, #0x2b]
    // 0xc3a0b4: DecompressPointer r1
    //     0xc3a0b4: add             x1, x1, HEAP, lsl #32
    // 0xc3a0b8: mov             x2, x1
    // 0xc3a0bc: b               #0xc3a0cc
    // 0xc3a0c0: LoadField: r1 = r0->field_2b
    //     0xc3a0c0: ldur            w1, [x0, #0x2b]
    // 0xc3a0c4: DecompressPointer r1
    //     0xc3a0c4: add             x1, x1, HEAP, lsl #32
    // 0xc3a0c8: mov             x2, x1
    // 0xc3a0cc: stur            x2, [fp, #-8]
    // 0xc3a0d0: LoadField: r0 = r2->field_13
    //     0xc3a0d0: ldur            w0, [x2, #0x13]
    // 0xc3a0d4: DecompressPointer r0
    //     0xc3a0d4: add             x0, x0, HEAP, lsl #32
    // 0xc3a0d8: r3 = LoadInt32Instr(r0)
    //     0xc3a0d8: sbfx            x3, x0, #1, #0x1f
    // 0xc3a0dc: stur            x3, [fp, #-0x10]
    // 0xc3a0e0: lsl             x4, x3, #2
    // 0xc3a0e4: r0 = BoxInt64Instr(r4)
    //     0xc3a0e4: sbfiz           x0, x4, #1, #0x1f
    //     0xc3a0e8: cmp             x4, x0, asr #1
    //     0xc3a0ec: b.eq            #0xc3a0f8
    //     0xc3a0f0: bl              #0xd69bb8
    //     0xc3a0f4: stur            x4, [x0, #7]
    // 0xc3a0f8: mov             x4, x0
    // 0xc3a0fc: r0 = AllocateUint8Array()
    //     0xc3a0fc: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xc3a100: stur            x0, [fp, #-0x18]
    // 0xc3a104: r0 = _ByteBuffer()
    //     0xc3a104: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0xc3a108: mov             x1, x0
    // 0xc3a10c: ldur            x0, [fp, #-0x18]
    // 0xc3a110: StoreField: r1->field_7 = r0
    //     0xc3a110: stur            w0, [x1, #7]
    // 0xc3a114: SaveReg r1
    //     0xc3a114: str             x1, [SP, #-8]!
    // 0xc3a118: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc3a118: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc3a11c: r0 = asByteData()
    //     0xc3a11c: bl              #0xd64334  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0xc3a120: add             SP, SP, #8
    // 0xc3a124: LoadField: r1 = r0->field_13
    //     0xc3a124: ldur            w1, [x0, #0x13]
    // 0xc3a128: DecompressPointer r1
    //     0xc3a128: add             x1, x1, HEAP, lsl #32
    // 0xc3a12c: r2 = LoadInt32Instr(r1)
    //     0xc3a12c: sbfx            x2, x1, #1, #0x1f
    // 0xc3a130: LoadField: r3 = r0->field_17
    //     0xc3a130: ldur            w3, [x0, #0x17]
    // 0xc3a134: DecompressPointer r3
    //     0xc3a134: add             x3, x3, HEAP, lsl #32
    // 0xc3a138: LoadField: r4 = r0->field_1b
    //     0xc3a138: ldur            w4, [x0, #0x1b]
    // 0xc3a13c: DecompressPointer r4
    //     0xc3a13c: add             x4, x4, HEAP, lsl #32
    // 0xc3a140: r5 = LoadInt32Instr(r4)
    //     0xc3a140: sbfx            x5, x4, #1, #0x1f
    // 0xc3a144: ldur            x4, [fp, #-8]
    // 0xc3a148: ldur            x6, [fp, #-0x10]
    // 0xc3a14c: r11 = 0
    //     0xc3a14c: mov             x11, #0
    // 0xc3a150: r10 = 4278255360
    //     0xc3a150: mov             x10, #0xff00
    //     0xc3a154: movk            x10, #0xff00, lsl #16
    // 0xc3a158: r9 = 16711935
    //     0xc3a158: mov             x9, #0xff
    //     0xc3a15c: movk            x9, #0xff, lsl #16
    // 0xc3a160: r8 = 4294901760
    //     0xc3a160: mov             x8, #0xffff0000
    // 0xc3a164: r7 = 65535
    //     0xc3a164: mov             x7, #0xffff
    // 0xc3a168: CheckStackOverflow
    //     0xc3a168: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3a16c: cmp             SP, x16
    //     0xc3a170: b.ls            #0xc3a270
    // 0xc3a174: cmp             x11, x6
    // 0xc3a178: b.ge            #0xc3a1f8
    // 0xc3a17c: lsl             x12, x11, #2
    // 0xc3a180: ArrayLoad: r13 = r4[r11]  ; Unknown_4
    //     0xc3a180: add             x16, x4, x11, lsl #2
    //     0xc3a184: ldur            w13, [x16, #0x17]
    // 0xc3a188: tbnz            x12, #0x3f, #0xc3a208
    // 0xc3a18c: add             x14, x12, #3
    // 0xc3a190: cmp             x14, x2
    // 0xc3a194: b.ge            #0xc3a208
    // 0xc3a198: add             x14, x5, x12
    // 0xc3a19c: and             x12, x13, x10
    // 0xc3a1a0: ubfx            x12, x12, #0, #0x20
    // 0xc3a1a4: asr             x19, x12, #8
    // 0xc3a1a8: and             x12, x13, x9
    // 0xc3a1ac: ubfx            x12, x12, #0, #0x20
    // 0xc3a1b0: lsl             x13, x12, #8
    // 0xc3a1b4: orr             x12, x19, x13
    // 0xc3a1b8: mov             x13, x12
    // 0xc3a1bc: ubfx            x13, x13, #0, #0x20
    // 0xc3a1c0: and             x19, x13, x8
    // 0xc3a1c4: ubfx            x19, x19, #0, #0x20
    // 0xc3a1c8: asr             x13, x19, #0x10
    // 0xc3a1cc: ubfx            x12, x12, #0, #0x20
    // 0xc3a1d0: and             x19, x12, x7
    // 0xc3a1d4: ubfx            x19, x19, #0, #0x20
    // 0xc3a1d8: lsl             x12, x19, #0x10
    // 0xc3a1dc: orr             x19, x13, x12
    // 0xc3a1e0: ubfx            x19, x19, #0, #0x20
    // 0xc3a1e4: LoadField: r12 = r3->field_7
    //     0xc3a1e4: ldur            x12, [x3, #7]
    // 0xc3a1e8: str             w19, [x12, x14]
    // 0xc3a1ec: add             x12, x11, #1
    // 0xc3a1f0: mov             x11, x12
    // 0xc3a1f4: b               #0xc3a168
    // 0xc3a1f8: ldur            x0, [fp, #-0x18]
    // 0xc3a1fc: LeaveFrame
    //     0xc3a1fc: mov             SP, fp
    //     0xc3a200: ldp             fp, lr, [SP], #0x10
    // 0xc3a204: ret
    //     0xc3a204: ret             
    // 0xc3a208: r0 = LoadInt32Instr(r1)
    //     0xc3a208: sbfx            x0, x1, #1, #0x1f
    // 0xc3a20c: sub             x2, x0, #4
    // 0xc3a210: r0 = BoxInt64Instr(r12)
    //     0xc3a210: sbfiz           x0, x12, #1, #0x1f
    //     0xc3a214: cmp             x12, x0, asr #1
    //     0xc3a218: b.eq            #0xc3a224
    //     0xc3a21c: bl              #0xd69bb8
    //     0xc3a220: stur            x12, [x0, #7]
    // 0xc3a224: stur            x0, [fp, #-0x28]
    // 0xc3a228: lsl             x1, x2, #1
    // 0xc3a22c: stur            x1, [fp, #-0x20]
    // 0xc3a230: r0 = RangeError()
    //     0xc3a230: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xc3a234: stur            x0, [fp, #-0x30]
    // 0xc3a238: ldur            x16, [fp, #-0x28]
    // 0xc3a23c: stp             x16, x0, [SP, #-0x10]!
    // 0xc3a240: ldur            x16, [fp, #-0x20]
    // 0xc3a244: stp             x16, xzr, [SP, #-0x10]!
    // 0xc3a248: r16 = "byteOffset"
    //     0xc3a248: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xc3a24c: SaveReg r16
    //     0xc3a24c: str             x16, [SP, #-8]!
    // 0xc3a250: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xc3a250: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xc3a254: r0 = RangeError.range()
    //     0xc3a254: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xc3a258: add             SP, SP, #0x28
    // 0xc3a25c: ldur            x0, [fp, #-0x30]
    // 0xc3a260: r0 = Throw()
    //     0xc3a260: bl              #0xd67e38  ; ThrowStub
    // 0xc3a264: brk             #0
    // 0xc3a268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3a268: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3a26c: b               #0xc3a01c
    // 0xc3a270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3a270: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3a274: b               #0xc3a174
  }
  _ _iterate(/* No info */) {
    // ** addr: 0xc3a278, size: 0x2c4
    // 0xc3a278: EnterFrame
    //     0xc3a278: stp             fp, lr, [SP, #-0x10]!
    //     0xc3a27c: mov             fp, SP
    // 0xc3a280: AllocStack(0x70)
    //     0xc3a280: sub             SP, SP, #0x70
    // 0xc3a284: CheckStackOverflow
    //     0xc3a284: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3a288: cmp             SP, x16
    //     0xc3a28c: b.ls            #0xc3a500
    // 0xc3a290: ldr             x0, [fp, #0x10]
    // 0xc3a294: LoadField: r1 = r0->field_1b
    //     0xc3a294: ldur            w1, [x0, #0x1b]
    // 0xc3a298: DecompressPointer r1
    //     0xc3a298: add             x1, x1, HEAP, lsl #32
    // 0xc3a29c: stur            x1, [fp, #-8]
    // 0xc3a2a0: SaveReg r1
    //     0xc3a2a0: str             x1, [SP, #-8]!
    // 0xc3a2a4: r0 = buffer()
    //     0xc3a2a4: bl              #0xc3a53c  ; [package:typed_data/src/typed_buffer.dart] TypedDataBuffer::buffer
    // 0xc3a2a8: add             SP, SP, #8
    // 0xc3a2ac: SaveReg r0
    //     0xc3a2ac: str             x0, [SP, #-8]!
    // 0xc3a2b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc3a2b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc3a2b4: r0 = asByteData()
    //     0xc3a2b4: bl              #0xd64334  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0xc3a2b8: add             SP, SP, #8
    // 0xc3a2bc: ldur            x1, [fp, #-8]
    // 0xc3a2c0: LoadField: r2 = r1->field_f
    //     0xc3a2c0: ldur            x2, [x1, #0xf]
    // 0xc3a2c4: ldr             x3, [fp, #0x10]
    // 0xc3a2c8: LoadField: r4 = r3->field_f
    //     0xc3a2c8: ldur            w4, [x3, #0xf]
    // 0xc3a2cc: DecompressPointer r4
    //     0xc3a2cc: add             x4, x4, HEAP, lsl #32
    // 0xc3a2d0: stur            x4, [fp, #-0x70]
    // 0xc3a2d4: LoadField: r5 = r4->field_13
    //     0xc3a2d4: ldur            w5, [x4, #0x13]
    // 0xc3a2d8: DecompressPointer r5
    //     0xc3a2d8: add             x5, x5, HEAP, lsl #32
    // 0xc3a2dc: r6 = LoadInt32Instr(r5)
    //     0xc3a2dc: sbfx            x6, x5, #1, #0x1f
    // 0xc3a2e0: stur            x6, [fp, #-0x68]
    // 0xc3a2e4: lsl             x5, x6, #2
    // 0xc3a2e8: stur            x5, [fp, #-0x60]
    // 0xc3a2ec: cbz             x5, #0xc3a508
    // 0xc3a2f0: sdiv            x7, x2, x5
    // 0xc3a2f4: stur            x7, [fp, #-0x58]
    // 0xc3a2f8: LoadField: r2 = r3->field_b
    //     0xc3a2f8: ldur            w2, [x3, #0xb]
    // 0xc3a2fc: DecompressPointer r2
    //     0xc3a2fc: add             x2, x2, HEAP, lsl #32
    // 0xc3a300: stur            x2, [fp, #-0x50]
    // 0xc3a304: LoadField: r8 = r0->field_13
    //     0xc3a304: ldur            w8, [x0, #0x13]
    // 0xc3a308: DecompressPointer r8
    //     0xc3a308: add             x8, x8, HEAP, lsl #32
    // 0xc3a30c: stur            x8, [fp, #-0x48]
    // 0xc3a310: r9 = LoadInt32Instr(r8)
    //     0xc3a310: sbfx            x9, x8, #1, #0x1f
    // 0xc3a314: stur            x9, [fp, #-0x40]
    // 0xc3a318: LoadField: r10 = r0->field_17
    //     0xc3a318: ldur            w10, [x0, #0x17]
    // 0xc3a31c: DecompressPointer r10
    //     0xc3a31c: add             x10, x10, HEAP, lsl #32
    // 0xc3a320: stur            x10, [fp, #-0x38]
    // 0xc3a324: LoadField: r11 = r0->field_1b
    //     0xc3a324: ldur            w11, [x0, #0x1b]
    // 0xc3a328: DecompressPointer r11
    //     0xc3a328: add             x11, x11, HEAP, lsl #32
    // 0xc3a32c: r12 = LoadInt32Instr(r11)
    //     0xc3a32c: sbfx            x12, x11, #1, #0x1f
    // 0xc3a330: stur            x12, [fp, #-0x30]
    // 0xc3a334: r20 = 0
    //     0xc3a334: mov             x20, #0
    // 0xc3a338: r19 = 4278255360
    //     0xc3a338: mov             x19, #0xff00
    //     0xc3a33c: movk            x19, #0xff00, lsl #16
    // 0xc3a340: r14 = 16711935
    //     0xc3a340: mov             x14, #0xff
    //     0xc3a344: movk            x14, #0xff, lsl #16
    // 0xc3a348: r13 = 4294901760
    //     0xc3a348: mov             x13, #0xffff0000
    // 0xc3a34c: r11 = 65535
    //     0xc3a34c: mov             x11, #0xffff
    // 0xc3a350: stur            x20, [fp, #-0x28]
    // 0xc3a354: CheckStackOverflow
    //     0xc3a354: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3a358: cmp             SP, x16
    //     0xc3a35c: b.ls            #0xc3a52c
    // 0xc3a360: cmp             x20, x7
    // 0xc3a364: b.ge            #0xc3a470
    // 0xc3a368: mul             x0, x20, x5
    // 0xc3a36c: r23 = 0
    //     0xc3a36c: mov             x23, #0
    // 0xc3a370: CheckStackOverflow
    //     0xc3a370: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3a374: cmp             SP, x16
    //     0xc3a378: b.ls            #0xc3a534
    // 0xc3a37c: cmp             x23, x6
    // 0xc3a380: b.ge            #0xc3a41c
    // 0xc3a384: lsl             x24, x23, #2
    // 0xc3a388: add             x25, x0, x24
    // 0xc3a38c: tbnz            x25, #0x3f, #0xc3a4a0
    // 0xc3a390: add             x24, x25, #3
    // 0xc3a394: cmp             x24, x9
    // 0xc3a398: b.ge            #0xc3a4a0
    // 0xc3a39c: add             x24, x12, x25
    // 0xc3a3a0: LoadField: r25 = r10->field_7
    //     0xc3a3a0: ldur            x25, [x10, #7]
    // 0xc3a3a4: ldr             w1, [x25, x24]
    // 0xc3a3a8: r16 = Instance_Endian
    //     0xc3a3a8: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xc3a3ac: cmp             w2, w16
    // 0xc3a3b0: b.ne            #0xc3a3bc
    // 0xc3a3b4: ubfx            x1, x1, #0, #0x20
    // 0xc3a3b8: b               #0xc3a404
    // 0xc3a3bc: and             x24, x1, x19
    // 0xc3a3c0: ubfx            x24, x24, #0, #0x20
    // 0xc3a3c4: asr             x25, x24, #8
    // 0xc3a3c8: and             x24, x1, x14
    // 0xc3a3cc: ubfx            x24, x24, #0, #0x20
    // 0xc3a3d0: lsl             x1, x24, #8
    // 0xc3a3d4: orr             x24, x25, x1
    // 0xc3a3d8: mov             x1, x24
    // 0xc3a3dc: ubfx            x1, x1, #0, #0x20
    // 0xc3a3e0: and             x25, x1, x13
    // 0xc3a3e4: ubfx            x25, x25, #0, #0x20
    // 0xc3a3e8: asr             x1, x25, #0x10
    // 0xc3a3ec: ubfx            x24, x24, #0, #0x20
    // 0xc3a3f0: and             x25, x24, x11
    // 0xc3a3f4: ubfx            x25, x25, #0, #0x20
    // 0xc3a3f8: lsl             x24, x25, #0x10
    // 0xc3a3fc: orr             x25, x1, x24
    // 0xc3a400: mov             x1, x25
    // 0xc3a404: ubfx            x1, x1, #0, #0x20
    // 0xc3a408: ArrayStore: r4[r23] = r1  ; Unknown_4
    //     0xc3a408: add             x24, x4, x23, lsl #2
    //     0xc3a40c: stur            w1, [x24, #0x17]
    // 0xc3a410: add             x1, x23, #1
    // 0xc3a414: mov             x23, x1
    // 0xc3a418: b               #0xc3a370
    // 0xc3a41c: r0 = LoadClassIdInstr(r3)
    //     0xc3a41c: ldur            x0, [x3, #-1]
    //     0xc3a420: ubfx            x0, x0, #0xc, #0x14
    // 0xc3a424: stp             x4, x3, [SP, #-0x10]!
    // 0xc3a428: r0 = GDT[cid_x0 + -0xff3]()
    //     0xc3a428: sub             lr, x0, #0xff3
    //     0xc3a42c: ldr             lr, [x21, lr, lsl #3]
    //     0xc3a430: blr             lr
    // 0xc3a434: add             SP, SP, #0x10
    // 0xc3a438: ldur            x0, [fp, #-0x28]
    // 0xc3a43c: add             x20, x0, #1
    // 0xc3a440: ldr             x3, [fp, #0x10]
    // 0xc3a444: ldur            x1, [fp, #-8]
    // 0xc3a448: ldur            x4, [fp, #-0x70]
    // 0xc3a44c: ldur            x7, [fp, #-0x58]
    // 0xc3a450: ldur            x2, [fp, #-0x50]
    // 0xc3a454: ldur            x10, [fp, #-0x38]
    // 0xc3a458: ldur            x8, [fp, #-0x48]
    // 0xc3a45c: ldur            x6, [fp, #-0x68]
    // 0xc3a460: ldur            x9, [fp, #-0x40]
    // 0xc3a464: ldur            x12, [fp, #-0x30]
    // 0xc3a468: ldur            x5, [fp, #-0x60]
    // 0xc3a46c: b               #0xc3a338
    // 0xc3a470: mov             x1, x7
    // 0xc3a474: mov             x0, x5
    // 0xc3a478: mul             x2, x1, x0
    // 0xc3a47c: ldur            x16, [fp, #-8]
    // 0xc3a480: stp             xzr, x16, [SP, #-0x10]!
    // 0xc3a484: SaveReg r2
    //     0xc3a484: str             x2, [SP, #-8]!
    // 0xc3a488: r0 = removeRange()
    //     0xc3a488: bl              #0xad76f8  ; [dart:collection] _ListBase&Object&ListMixin::removeRange
    // 0xc3a48c: add             SP, SP, #0x18
    // 0xc3a490: r0 = Null
    //     0xc3a490: mov             x0, NULL
    // 0xc3a494: LeaveFrame
    //     0xc3a494: mov             SP, fp
    //     0xc3a498: ldp             fp, lr, [SP], #0x10
    // 0xc3a49c: ret
    //     0xc3a49c: ret             
    // 0xc3a4a0: r0 = LoadInt32Instr(r8)
    //     0xc3a4a0: sbfx            x0, x8, #1, #0x1f
    // 0xc3a4a4: sub             x2, x0, #4
    // 0xc3a4a8: r0 = BoxInt64Instr(r25)
    //     0xc3a4a8: sbfiz           x0, x25, #1, #0x1f
    //     0xc3a4ac: cmp             x25, x0, asr #1
    //     0xc3a4b0: b.eq            #0xc3a4bc
    //     0xc3a4b4: bl              #0xd69bb8
    //     0xc3a4b8: stur            x25, [x0, #7]
    // 0xc3a4bc: stur            x0, [fp, #-0x18]
    // 0xc3a4c0: lsl             x1, x2, #1
    // 0xc3a4c4: stur            x1, [fp, #-0x10]
    // 0xc3a4c8: r0 = RangeError()
    //     0xc3a4c8: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xc3a4cc: stur            x0, [fp, #-0x20]
    // 0xc3a4d0: ldur            x16, [fp, #-0x18]
    // 0xc3a4d4: stp             x16, x0, [SP, #-0x10]!
    // 0xc3a4d8: ldur            x16, [fp, #-0x10]
    // 0xc3a4dc: stp             x16, xzr, [SP, #-0x10]!
    // 0xc3a4e0: r16 = "byteOffset"
    //     0xc3a4e0: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xc3a4e4: SaveReg r16
    //     0xc3a4e4: str             x16, [SP, #-8]!
    // 0xc3a4e8: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xc3a4e8: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xc3a4ec: r0 = RangeError.range()
    //     0xc3a4ec: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xc3a4f0: add             SP, SP, #0x28
    // 0xc3a4f4: ldur            x0, [fp, #-0x20]
    // 0xc3a4f8: r0 = Throw()
    //     0xc3a4f8: bl              #0xd67e38  ; ThrowStub
    // 0xc3a4fc: brk             #0
    // 0xc3a500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3a500: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3a504: b               #0xc3a290
    // 0xc3a508: stp             x5, x6, [SP, #-0x10]!
    // 0xc3a50c: stp             x3, x4, [SP, #-0x10]!
    // 0xc3a510: stp             x1, x2, [SP, #-0x10]!
    // 0xc3a514: SaveReg r0
    //     0xc3a514: str             x0, [SP, #-8]!
    // 0xc3a518: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0xc3a51c: r4 = 0
    //     0xc3a51c: mov             x4, #0
    // 0xc3a520: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xc3a524: blr             lr
    // 0xc3a528: brk             #0
    // 0xc3a52c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3a52c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3a530: b               #0xc3a360
    // 0xc3a534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3a534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3a538: b               #0xc3a37c
  }
  _ _finalizeData(/* No info */) {
    // ** addr: 0xc3a570, size: 0x5b8
    // 0xc3a570: EnterFrame
    //     0xc3a570: stp             fp, lr, [SP, #-0x10]!
    //     0xc3a574: mov             fp, SP
    // 0xc3a578: AllocStack(0x28)
    //     0xc3a578: sub             SP, SP, #0x28
    // 0xc3a57c: CheckStackOverflow
    //     0xc3a57c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3a580: cmp             SP, x16
    //     0xc3a584: b.ls            #0xc3ab18
    // 0xc3a588: ldr             x0, [fp, #0x10]
    // 0xc3a58c: LoadField: r1 = r0->field_1b
    //     0xc3a58c: ldur            w1, [x0, #0x1b]
    // 0xc3a590: DecompressPointer r1
    //     0xc3a590: add             x1, x1, HEAP, lsl #32
    // 0xc3a594: stur            x1, [fp, #-8]
    // 0xc3a598: r16 = 256
    //     0xc3a598: mov             x16, #0x100
    // 0xc3a59c: stp             x16, x1, [SP, #-0x10]!
    // 0xc3a5a0: r0 = _add()
    //     0xc3a5a0: bl              #0x4c65e8  ; [package:typed_data/src/typed_buffer.dart] TypedDataBuffer::_add
    // 0xc3a5a4: add             SP, SP, #0x10
    // 0xc3a5a8: ldr             x0, [fp, #0x10]
    // 0xc3a5ac: LoadField: r1 = r0->field_13
    //     0xc3a5ac: ldur            x1, [x0, #0x13]
    // 0xc3a5b0: add             x2, x1, #1
    // 0xc3a5b4: add             x1, x2, #8
    // 0xc3a5b8: LoadField: r2 = r0->field_f
    //     0xc3a5b8: ldur            w2, [x0, #0xf]
    // 0xc3a5bc: DecompressPointer r2
    //     0xc3a5bc: add             x2, x2, HEAP, lsl #32
    // 0xc3a5c0: LoadField: r3 = r2->field_13
    //     0xc3a5c0: ldur            w3, [x2, #0x13]
    // 0xc3a5c4: DecompressPointer r3
    //     0xc3a5c4: add             x3, x3, HEAP, lsl #32
    // 0xc3a5c8: r2 = LoadInt32Instr(r3)
    //     0xc3a5c8: sbfx            x2, x3, #1, #0x1f
    // 0xc3a5cc: lsl             x3, x2, #2
    // 0xc3a5d0: add             x2, x1, x3
    // 0xc3a5d4: sub             x4, x2, #1
    // 0xc3a5d8: neg             x2, x3
    // 0xc3a5dc: and             x3, x4, x2
    // 0xc3a5e0: sub             x2, x3, x1
    // 0xc3a5e4: stur            x2, [fp, #-0x18]
    // 0xc3a5e8: r1 = 0
    //     0xc3a5e8: mov             x1, #0
    // 0xc3a5ec: stur            x1, [fp, #-0x10]
    // 0xc3a5f0: CheckStackOverflow
    //     0xc3a5f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3a5f4: cmp             SP, x16
    //     0xc3a5f8: b.ls            #0xc3ab20
    // 0xc3a5fc: cmp             x1, x2
    // 0xc3a600: b.ge            #0xc3a628
    // 0xc3a604: ldur            x16, [fp, #-8]
    // 0xc3a608: stp             xzr, x16, [SP, #-0x10]!
    // 0xc3a60c: r0 = _add()
    //     0xc3a60c: bl              #0x4c65e8  ; [package:typed_data/src/typed_buffer.dart] TypedDataBuffer::_add
    // 0xc3a610: add             SP, SP, #0x10
    // 0xc3a614: ldur            x0, [fp, #-0x10]
    // 0xc3a618: add             x1, x0, #1
    // 0xc3a61c: ldr             x0, [fp, #0x10]
    // 0xc3a620: ldur            x2, [fp, #-0x18]
    // 0xc3a624: b               #0xc3a5ec
    // 0xc3a628: LoadField: r1 = r0->field_13
    //     0xc3a628: ldur            x1, [x0, #0x13]
    // 0xc3a62c: r17 = 1125899906842623
    //     0xc3a62c: mov             x17, #0x3ffffffffffff
    // 0xc3a630: cmp             x1, x17
    // 0xc3a634: b.gt            #0xc3a970
    // 0xc3a638: ldur            x2, [fp, #-8]
    // 0xc3a63c: lsl             x3, x1, #3
    // 0xc3a640: stur            x3, [fp, #-0x18]
    // 0xc3a644: LoadField: r1 = r2->field_f
    //     0xc3a644: ldur            x1, [x2, #0xf]
    // 0xc3a648: stur            x1, [fp, #-0x10]
    // 0xc3a64c: r4 = 16
    //     0xc3a64c: mov             x4, #0x10
    // 0xc3a650: r0 = AllocateUint8Array()
    //     0xc3a650: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xc3a654: ldur            x16, [fp, #-8]
    // 0xc3a658: stp             x0, x16, [SP, #-0x10]!
    // 0xc3a65c: r0 = addAll()
    //     0xc3a65c: bl              #0x5029fc  ; [package:typed_data/src/typed_buffer.dart] TypedDataBuffer::addAll
    // 0xc3a660: add             SP, SP, #0x10
    // 0xc3a664: ldur            x0, [fp, #-8]
    // 0xc3a668: LoadField: r1 = r0->field_b
    //     0xc3a668: ldur            w1, [x0, #0xb]
    // 0xc3a66c: DecompressPointer r1
    //     0xc3a66c: add             x1, x1, HEAP, lsl #32
    // 0xc3a670: stur            x1, [fp, #-0x20]
    // 0xc3a674: r0 = _ByteBuffer()
    //     0xc3a674: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0xc3a678: mov             x1, x0
    // 0xc3a67c: ldur            x0, [fp, #-0x20]
    // 0xc3a680: StoreField: r1->field_7 = r0
    //     0xc3a680: stur            w0, [x1, #7]
    // 0xc3a684: SaveReg r1
    //     0xc3a684: str             x1, [SP, #-8]!
    // 0xc3a688: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc3a688: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc3a68c: r0 = asByteData()
    //     0xc3a68c: bl              #0xd64334  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0xc3a690: add             SP, SP, #8
    // 0xc3a694: mov             x2, x0
    // 0xc3a698: ldur            x1, [fp, #-0x18]
    // 0xc3a69c: r0 = 4294967296
    //     0xc3a69c: mov             x0, #0x100000000
    // 0xc3a6a0: sdiv            x3, x1, x0
    // 0xc3a6a4: ubfx            x1, x1, #0, #0x20
    // 0xc3a6a8: ldr             x0, [fp, #0x10]
    // 0xc3a6ac: LoadField: r4 = r0->field_b
    //     0xc3a6ac: ldur            w4, [x0, #0xb]
    // 0xc3a6b0: DecompressPointer r4
    //     0xc3a6b0: add             x4, x4, HEAP, lsl #32
    // 0xc3a6b4: r16 = Instance_Endian
    //     0xc3a6b4: ldr             x16, [PP, #0x7f78]  ; [pp+0x7f78] Obj!Endian@b5f5b1
    // 0xc3a6b8: cmp             w4, w16
    // 0xc3a6bc: b.ne            #0xc3a81c
    // 0xc3a6c0: ldur            x5, [fp, #-0x10]
    // 0xc3a6c4: tbnz            x5, #0x3f, #0xc3a990
    // 0xc3a6c8: add             x0, x5, #3
    // 0xc3a6cc: LoadField: r6 = r2->field_13
    //     0xc3a6cc: ldur            w6, [x2, #0x13]
    // 0xc3a6d0: DecompressPointer r6
    //     0xc3a6d0: add             x6, x6, HEAP, lsl #32
    // 0xc3a6d4: r7 = LoadInt32Instr(r6)
    //     0xc3a6d4: sbfx            x7, x6, #1, #0x1f
    // 0xc3a6d8: cmp             x0, x7
    // 0xc3a6dc: b.ge            #0xc3a990
    // 0xc3a6e0: LoadField: r0 = r2->field_17
    //     0xc3a6e0: ldur            w0, [x2, #0x17]
    // 0xc3a6e4: DecompressPointer r0
    //     0xc3a6e4: add             x0, x0, HEAP, lsl #32
    // 0xc3a6e8: LoadField: r6 = r2->field_1b
    //     0xc3a6e8: ldur            w6, [x2, #0x1b]
    // 0xc3a6ec: DecompressPointer r6
    //     0xc3a6ec: add             x6, x6, HEAP, lsl #32
    // 0xc3a6f0: r2 = LoadInt32Instr(r6)
    //     0xc3a6f0: sbfx            x2, x6, #1, #0x1f
    // 0xc3a6f4: add             x6, x2, x5
    // 0xc3a6f8: r16 = Instance_Endian
    //     0xc3a6f8: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xc3a6fc: cmp             w4, w16
    // 0xc3a700: b.ne            #0xc3a720
    // 0xc3a704: r11 = 4278255360
    //     0xc3a704: mov             x11, #0xff00
    //     0xc3a708: movk            x11, #0xff00, lsl #16
    // 0xc3a70c: r10 = 16711935
    //     0xc3a70c: mov             x10, #0xff
    //     0xc3a710: movk            x10, #0xff, lsl #16
    // 0xc3a714: r9 = 4294901760
    //     0xc3a714: mov             x9, #0xffff0000
    // 0xc3a718: r8 = 65535
    //     0xc3a718: mov             x8, #0xffff
    // 0xc3a71c: b               #0xc3a78c
    // 0xc3a720: r11 = 4278255360
    //     0xc3a720: mov             x11, #0xff00
    //     0xc3a724: movk            x11, #0xff00, lsl #16
    // 0xc3a728: r10 = 16711935
    //     0xc3a728: mov             x10, #0xff
    //     0xc3a72c: movk            x10, #0xff, lsl #16
    // 0xc3a730: r9 = 4294901760
    //     0xc3a730: mov             x9, #0xffff0000
    // 0xc3a734: r8 = 65535
    //     0xc3a734: mov             x8, #0xffff
    // 0xc3a738: mov             x12, x3
    // 0xc3a73c: ubfx            x12, x12, #0, #0x20
    // 0xc3a740: and             x13, x12, x11
    // 0xc3a744: ubfx            x13, x13, #0, #0x20
    // 0xc3a748: asr             x12, x13, #8
    // 0xc3a74c: ubfx            x3, x3, #0, #0x20
    // 0xc3a750: and             x13, x3, x10
    // 0xc3a754: ubfx            x13, x13, #0, #0x20
    // 0xc3a758: lsl             x3, x13, #8
    // 0xc3a75c: orr             x13, x12, x3
    // 0xc3a760: mov             x3, x13
    // 0xc3a764: ubfx            x3, x3, #0, #0x20
    // 0xc3a768: and             x12, x3, x9
    // 0xc3a76c: ubfx            x12, x12, #0, #0x20
    // 0xc3a770: asr             x3, x12, #0x10
    // 0xc3a774: ubfx            x13, x13, #0, #0x20
    // 0xc3a778: and             x12, x13, x8
    // 0xc3a77c: ubfx            x12, x12, #0, #0x20
    // 0xc3a780: lsl             x13, x12, #0x10
    // 0xc3a784: orr             x12, x3, x13
    // 0xc3a788: mov             x3, x12
    // 0xc3a78c: ubfx            x3, x3, #0, #0x20
    // 0xc3a790: LoadField: r12 = r0->field_7
    //     0xc3a790: ldur            x12, [x0, #7]
    // 0xc3a794: str             w3, [x12, x6]
    // 0xc3a798: add             x3, x5, #4
    // 0xc3a79c: tbnz            x3, #0x3f, #0xc3a9f8
    // 0xc3a7a0: add             x5, x3, #3
    // 0xc3a7a4: cmp             x5, x7
    // 0xc3a7a8: b.ge            #0xc3a9f8
    // 0xc3a7ac: add             x5, x2, x3
    // 0xc3a7b0: r16 = Instance_Endian
    //     0xc3a7b0: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xc3a7b4: cmp             w4, w16
    // 0xc3a7b8: b.ne            #0xc3a7c4
    // 0xc3a7bc: ubfx            x1, x1, #0, #0x20
    // 0xc3a7c0: b               #0xc3a80c
    // 0xc3a7c4: and             x2, x1, x11
    // 0xc3a7c8: ubfx            x2, x2, #0, #0x20
    // 0xc3a7cc: asr             x3, x2, #8
    // 0xc3a7d0: and             x2, x1, x10
    // 0xc3a7d4: ubfx            x2, x2, #0, #0x20
    // 0xc3a7d8: lsl             x1, x2, #8
    // 0xc3a7dc: orr             x2, x3, x1
    // 0xc3a7e0: mov             x1, x2
    // 0xc3a7e4: ubfx            x1, x1, #0, #0x20
    // 0xc3a7e8: and             x3, x1, x9
    // 0xc3a7ec: ubfx            x3, x3, #0, #0x20
    // 0xc3a7f0: asr             x1, x3, #0x10
    // 0xc3a7f4: ubfx            x2, x2, #0, #0x20
    // 0xc3a7f8: and             x3, x2, x8
    // 0xc3a7fc: ubfx            x3, x3, #0, #0x20
    // 0xc3a800: lsl             x2, x3, #0x10
    // 0xc3a804: orr             x3, x1, x2
    // 0xc3a808: mov             x1, x3
    // 0xc3a80c: ubfx            x1, x1, #0, #0x20
    // 0xc3a810: LoadField: r2 = r0->field_7
    //     0xc3a810: ldur            x2, [x0, #7]
    // 0xc3a814: str             w1, [x2, x5]
    // 0xc3a818: b               #0xc3a960
    // 0xc3a81c: ldur            x5, [fp, #-0x10]
    // 0xc3a820: r11 = 4278255360
    //     0xc3a820: mov             x11, #0xff00
    //     0xc3a824: movk            x11, #0xff00, lsl #16
    // 0xc3a828: r10 = 16711935
    //     0xc3a828: mov             x10, #0xff
    //     0xc3a82c: movk            x10, #0xff, lsl #16
    // 0xc3a830: r9 = 4294901760
    //     0xc3a830: mov             x9, #0xffff0000
    // 0xc3a834: r8 = 65535
    //     0xc3a834: mov             x8, #0xffff
    // 0xc3a838: tbnz            x5, #0x3f, #0xc3aa54
    // 0xc3a83c: add             x0, x5, #3
    // 0xc3a840: LoadField: r6 = r2->field_13
    //     0xc3a840: ldur            w6, [x2, #0x13]
    // 0xc3a844: DecompressPointer r6
    //     0xc3a844: add             x6, x6, HEAP, lsl #32
    // 0xc3a848: r7 = LoadInt32Instr(r6)
    //     0xc3a848: sbfx            x7, x6, #1, #0x1f
    // 0xc3a84c: cmp             x0, x7
    // 0xc3a850: b.ge            #0xc3aa54
    // 0xc3a854: LoadField: r0 = r2->field_17
    //     0xc3a854: ldur            w0, [x2, #0x17]
    // 0xc3a858: DecompressPointer r0
    //     0xc3a858: add             x0, x0, HEAP, lsl #32
    // 0xc3a85c: LoadField: r6 = r2->field_1b
    //     0xc3a85c: ldur            w6, [x2, #0x1b]
    // 0xc3a860: DecompressPointer r6
    //     0xc3a860: add             x6, x6, HEAP, lsl #32
    // 0xc3a864: r2 = LoadInt32Instr(r6)
    //     0xc3a864: sbfx            x2, x6, #1, #0x1f
    // 0xc3a868: add             x6, x2, x5
    // 0xc3a86c: r16 = Instance_Endian
    //     0xc3a86c: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xc3a870: cmp             w4, w16
    // 0xc3a874: b.ne            #0xc3a880
    // 0xc3a878: ubfx            x1, x1, #0, #0x20
    // 0xc3a87c: b               #0xc3a8c8
    // 0xc3a880: and             x12, x1, x11
    // 0xc3a884: ubfx            x12, x12, #0, #0x20
    // 0xc3a888: asr             x13, x12, #8
    // 0xc3a88c: and             x12, x1, x10
    // 0xc3a890: ubfx            x12, x12, #0, #0x20
    // 0xc3a894: lsl             x1, x12, #8
    // 0xc3a898: orr             x12, x13, x1
    // 0xc3a89c: mov             x1, x12
    // 0xc3a8a0: ubfx            x1, x1, #0, #0x20
    // 0xc3a8a4: and             x13, x1, x9
    // 0xc3a8a8: ubfx            x13, x13, #0, #0x20
    // 0xc3a8ac: asr             x1, x13, #0x10
    // 0xc3a8b0: ubfx            x12, x12, #0, #0x20
    // 0xc3a8b4: and             x13, x12, x8
    // 0xc3a8b8: ubfx            x13, x13, #0, #0x20
    // 0xc3a8bc: lsl             x12, x13, #0x10
    // 0xc3a8c0: orr             x13, x1, x12
    // 0xc3a8c4: mov             x1, x13
    // 0xc3a8c8: ubfx            x1, x1, #0, #0x20
    // 0xc3a8cc: LoadField: r12 = r0->field_7
    //     0xc3a8cc: ldur            x12, [x0, #7]
    // 0xc3a8d0: str             w1, [x12, x6]
    // 0xc3a8d4: add             x6, x5, #4
    // 0xc3a8d8: tbnz            x6, #0x3f, #0xc3aabc
    // 0xc3a8dc: add             x1, x6, #3
    // 0xc3a8e0: cmp             x1, x7
    // 0xc3a8e4: b.ge            #0xc3aabc
    // 0xc3a8e8: add             x1, x2, x6
    // 0xc3a8ec: r16 = Instance_Endian
    //     0xc3a8ec: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xc3a8f0: cmp             w4, w16
    // 0xc3a8f4: b.ne            #0xc3a900
    // 0xc3a8f8: mov             x2, x3
    // 0xc3a8fc: b               #0xc3a954
    // 0xc3a900: mov             x2, x3
    // 0xc3a904: ubfx            x2, x2, #0, #0x20
    // 0xc3a908: and             x4, x2, x11
    // 0xc3a90c: ubfx            x4, x4, #0, #0x20
    // 0xc3a910: asr             x2, x4, #8
    // 0xc3a914: ubfx            x3, x3, #0, #0x20
    // 0xc3a918: and             x4, x3, x10
    // 0xc3a91c: ubfx            x4, x4, #0, #0x20
    // 0xc3a920: lsl             x3, x4, #8
    // 0xc3a924: orr             x4, x2, x3
    // 0xc3a928: mov             x2, x4
    // 0xc3a92c: ubfx            x2, x2, #0, #0x20
    // 0xc3a930: and             x3, x2, x9
    // 0xc3a934: ubfx            x3, x3, #0, #0x20
    // 0xc3a938: asr             x2, x3, #0x10
    // 0xc3a93c: ubfx            x4, x4, #0, #0x20
    // 0xc3a940: and             x3, x4, x8
    // 0xc3a944: ubfx            x3, x3, #0, #0x20
    // 0xc3a948: lsl             x4, x3, #0x10
    // 0xc3a94c: orr             x3, x2, x4
    // 0xc3a950: mov             x2, x3
    // 0xc3a954: ubfx            x2, x2, #0, #0x20
    // 0xc3a958: LoadField: r3 = r0->field_7
    //     0xc3a958: ldur            x3, [x0, #7]
    // 0xc3a95c: str             w2, [x3, x1]
    // 0xc3a960: r0 = Null
    //     0xc3a960: mov             x0, NULL
    // 0xc3a964: LeaveFrame
    //     0xc3a964: mov             SP, fp
    //     0xc3a968: ldp             fp, lr, [SP], #0x10
    // 0xc3a96c: ret
    //     0xc3a96c: ret             
    // 0xc3a970: r0 = UnsupportedError()
    //     0xc3a970: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0xc3a974: mov             x1, x0
    // 0xc3a978: r0 = "Hashing is unsupported for messages with more than 2^53 bits."
    //     0xc3a978: add             x0, PP, #0x15, lsl #12  ; [pp+0x15420] "Hashing is unsupported for messages with more than 2^53 bits."
    //     0xc3a97c: ldr             x0, [x0, #0x420]
    // 0xc3a980: StoreField: r1->field_b = r0
    //     0xc3a980: stur            w0, [x1, #0xb]
    // 0xc3a984: mov             x0, x1
    // 0xc3a988: r0 = Throw()
    //     0xc3a988: bl              #0xd67e38  ; ThrowStub
    // 0xc3a98c: brk             #0
    // 0xc3a990: LoadField: r0 = r2->field_13
    //     0xc3a990: ldur            w0, [x2, #0x13]
    // 0xc3a994: DecompressPointer r0
    //     0xc3a994: add             x0, x0, HEAP, lsl #32
    // 0xc3a998: r1 = LoadInt32Instr(r0)
    //     0xc3a998: sbfx            x1, x0, #1, #0x1f
    // 0xc3a99c: sub             x2, x1, #4
    // 0xc3a9a0: r0 = BoxInt64Instr(r5)
    //     0xc3a9a0: sbfiz           x0, x5, #1, #0x1f
    //     0xc3a9a4: cmp             x5, x0, asr #1
    //     0xc3a9a8: b.eq            #0xc3a9b4
    //     0xc3a9ac: bl              #0xd69bb8
    //     0xc3a9b0: stur            x5, [x0, #7]
    // 0xc3a9b4: stur            x0, [fp, #-0x20]
    // 0xc3a9b8: lsl             x1, x2, #1
    // 0xc3a9bc: stur            x1, [fp, #-8]
    // 0xc3a9c0: r0 = RangeError()
    //     0xc3a9c0: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xc3a9c4: stur            x0, [fp, #-0x28]
    // 0xc3a9c8: ldur            x16, [fp, #-0x20]
    // 0xc3a9cc: stp             x16, x0, [SP, #-0x10]!
    // 0xc3a9d0: ldur            x16, [fp, #-8]
    // 0xc3a9d4: stp             x16, xzr, [SP, #-0x10]!
    // 0xc3a9d8: r16 = "byteOffset"
    //     0xc3a9d8: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xc3a9dc: SaveReg r16
    //     0xc3a9dc: str             x16, [SP, #-8]!
    // 0xc3a9e0: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xc3a9e0: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xc3a9e4: r0 = RangeError.range()
    //     0xc3a9e4: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xc3a9e8: add             SP, SP, #0x28
    // 0xc3a9ec: ldur            x0, [fp, #-0x28]
    // 0xc3a9f0: r0 = Throw()
    //     0xc3a9f0: bl              #0xd67e38  ; ThrowStub
    // 0xc3a9f4: brk             #0
    // 0xc3a9f8: sub             x2, x7, #4
    // 0xc3a9fc: r0 = BoxInt64Instr(r3)
    //     0xc3a9fc: sbfiz           x0, x3, #1, #0x1f
    //     0xc3aa00: cmp             x3, x0, asr #1
    //     0xc3aa04: b.eq            #0xc3aa10
    //     0xc3aa08: bl              #0xd69bb8
    //     0xc3aa0c: stur            x3, [x0, #7]
    // 0xc3aa10: stur            x0, [fp, #-0x20]
    // 0xc3aa14: lsl             x1, x2, #1
    // 0xc3aa18: stur            x1, [fp, #-8]
    // 0xc3aa1c: r0 = RangeError()
    //     0xc3aa1c: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xc3aa20: stur            x0, [fp, #-0x28]
    // 0xc3aa24: ldur            x16, [fp, #-0x20]
    // 0xc3aa28: stp             x16, x0, [SP, #-0x10]!
    // 0xc3aa2c: ldur            x16, [fp, #-8]
    // 0xc3aa30: stp             x16, xzr, [SP, #-0x10]!
    // 0xc3aa34: r16 = "byteOffset"
    //     0xc3aa34: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xc3aa38: SaveReg r16
    //     0xc3aa38: str             x16, [SP, #-8]!
    // 0xc3aa3c: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xc3aa3c: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xc3aa40: r0 = RangeError.range()
    //     0xc3aa40: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xc3aa44: add             SP, SP, #0x28
    // 0xc3aa48: ldur            x0, [fp, #-0x28]
    // 0xc3aa4c: r0 = Throw()
    //     0xc3aa4c: bl              #0xd67e38  ; ThrowStub
    // 0xc3aa50: brk             #0
    // 0xc3aa54: LoadField: r0 = r2->field_13
    //     0xc3aa54: ldur            w0, [x2, #0x13]
    // 0xc3aa58: DecompressPointer r0
    //     0xc3aa58: add             x0, x0, HEAP, lsl #32
    // 0xc3aa5c: r1 = LoadInt32Instr(r0)
    //     0xc3aa5c: sbfx            x1, x0, #1, #0x1f
    // 0xc3aa60: sub             x2, x1, #4
    // 0xc3aa64: r0 = BoxInt64Instr(r5)
    //     0xc3aa64: sbfiz           x0, x5, #1, #0x1f
    //     0xc3aa68: cmp             x5, x0, asr #1
    //     0xc3aa6c: b.eq            #0xc3aa78
    //     0xc3aa70: bl              #0xd69bb8
    //     0xc3aa74: stur            x5, [x0, #7]
    // 0xc3aa78: stur            x0, [fp, #-0x20]
    // 0xc3aa7c: lsl             x1, x2, #1
    // 0xc3aa80: stur            x1, [fp, #-8]
    // 0xc3aa84: r0 = RangeError()
    //     0xc3aa84: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xc3aa88: stur            x0, [fp, #-0x28]
    // 0xc3aa8c: ldur            x16, [fp, #-0x20]
    // 0xc3aa90: stp             x16, x0, [SP, #-0x10]!
    // 0xc3aa94: ldur            x16, [fp, #-8]
    // 0xc3aa98: stp             x16, xzr, [SP, #-0x10]!
    // 0xc3aa9c: r16 = "byteOffset"
    //     0xc3aa9c: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xc3aaa0: SaveReg r16
    //     0xc3aaa0: str             x16, [SP, #-8]!
    // 0xc3aaa4: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xc3aaa4: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xc3aaa8: r0 = RangeError.range()
    //     0xc3aaa8: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xc3aaac: add             SP, SP, #0x28
    // 0xc3aab0: ldur            x0, [fp, #-0x28]
    // 0xc3aab4: r0 = Throw()
    //     0xc3aab4: bl              #0xd67e38  ; ThrowStub
    // 0xc3aab8: brk             #0
    // 0xc3aabc: sub             x2, x7, #4
    // 0xc3aac0: r0 = BoxInt64Instr(r6)
    //     0xc3aac0: sbfiz           x0, x6, #1, #0x1f
    //     0xc3aac4: cmp             x6, x0, asr #1
    //     0xc3aac8: b.eq            #0xc3aad4
    //     0xc3aacc: bl              #0xd69bb8
    //     0xc3aad0: stur            x6, [x0, #7]
    // 0xc3aad4: stur            x0, [fp, #-0x20]
    // 0xc3aad8: lsl             x1, x2, #1
    // 0xc3aadc: stur            x1, [fp, #-8]
    // 0xc3aae0: r0 = RangeError()
    //     0xc3aae0: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xc3aae4: stur            x0, [fp, #-0x28]
    // 0xc3aae8: ldur            x16, [fp, #-0x20]
    // 0xc3aaec: stp             x16, x0, [SP, #-0x10]!
    // 0xc3aaf0: ldur            x16, [fp, #-8]
    // 0xc3aaf4: stp             x16, xzr, [SP, #-0x10]!
    // 0xc3aaf8: r16 = "byteOffset"
    //     0xc3aaf8: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xc3aafc: SaveReg r16
    //     0xc3aafc: str             x16, [SP, #-8]!
    // 0xc3ab00: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xc3ab00: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xc3ab04: r0 = RangeError.range()
    //     0xc3ab04: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xc3ab08: add             SP, SP, #0x28
    // 0xc3ab0c: ldur            x0, [fp, #-0x28]
    // 0xc3ab10: r0 = Throw()
    //     0xc3ab10: bl              #0xd67e38  ; ThrowStub
    // 0xc3ab14: brk             #0
    // 0xc3ab18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3ab18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3ab1c: b               #0xc3a588
    // 0xc3ab20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3ab20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3ab24: b               #0xc3a5fc
  }
  _ add(/* No info */) {
    // ** addr: 0xc4df98, size: 0xec
    // 0xc4df98: EnterFrame
    //     0xc4df98: stp             fp, lr, [SP, #-0x10]!
    //     0xc4df9c: mov             fp, SP
    // 0xc4dfa0: AllocStack(0x8)
    //     0xc4dfa0: sub             SP, SP, #8
    // 0xc4dfa4: CheckStackOverflow
    //     0xc4dfa4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4dfa8: cmp             SP, x16
    //     0xc4dfac: b.ls            #0xc4e07c
    // 0xc4dfb0: ldr             x0, [fp, #0x10]
    // 0xc4dfb4: r2 = Null
    //     0xc4dfb4: mov             x2, NULL
    // 0xc4dfb8: r1 = Null
    //     0xc4dfb8: mov             x1, NULL
    // 0xc4dfbc: r8 = List<int>
    //     0xc4dfbc: ldr             x8, [PP, #0xa60]  ; [pp+0xa60] Type: List<int>
    // 0xc4dfc0: r3 = Null
    //     0xc4dfc0: add             x3, PP, #0x15, lsl #12  ; [pp+0x15468] Null
    //     0xc4dfc4: ldr             x3, [x3, #0x468]
    // 0xc4dfc8: r0 = List<int>()
    //     0xc4dfc8: bl              #0x4b2744  ; IsType_List<int>_Stub
    // 0xc4dfcc: ldr             x1, [fp, #0x18]
    // 0xc4dfd0: LoadField: r0 = r1->field_1f
    //     0xc4dfd0: ldur            w0, [x1, #0x1f]
    // 0xc4dfd4: DecompressPointer r0
    //     0xc4dfd4: add             x0, x0, HEAP, lsl #32
    // 0xc4dfd8: tbz             w0, #4, #0xc4e05c
    // 0xc4dfdc: ldr             x2, [fp, #0x10]
    // 0xc4dfe0: LoadField: r3 = r1->field_13
    //     0xc4dfe0: ldur            x3, [x1, #0x13]
    // 0xc4dfe4: stur            x3, [fp, #-8]
    // 0xc4dfe8: r0 = LoadClassIdInstr(r2)
    //     0xc4dfe8: ldur            x0, [x2, #-1]
    //     0xc4dfec: ubfx            x0, x0, #0xc, #0x14
    // 0xc4dff0: SaveReg r2
    //     0xc4dff0: str             x2, [SP, #-8]!
    // 0xc4dff4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc4dff4: mov             x17, #0xb8ea
    //     0xc4dff8: add             lr, x0, x17
    //     0xc4dffc: ldr             lr, [x21, lr, lsl #3]
    //     0xc4e000: blr             lr
    // 0xc4e004: add             SP, SP, #8
    // 0xc4e008: r1 = LoadInt32Instr(r0)
    //     0xc4e008: sbfx            x1, x0, #1, #0x1f
    //     0xc4e00c: tbz             w0, #0, #0xc4e014
    //     0xc4e010: ldur            x1, [x0, #7]
    // 0xc4e014: ldur            x0, [fp, #-8]
    // 0xc4e018: add             x2, x0, x1
    // 0xc4e01c: ldr             x0, [fp, #0x18]
    // 0xc4e020: StoreField: r0->field_13 = r2
    //     0xc4e020: stur            x2, [x0, #0x13]
    // 0xc4e024: LoadField: r1 = r0->field_1b
    //     0xc4e024: ldur            w1, [x0, #0x1b]
    // 0xc4e028: DecompressPointer r1
    //     0xc4e028: add             x1, x1, HEAP, lsl #32
    // 0xc4e02c: ldr             x16, [fp, #0x10]
    // 0xc4e030: stp             x16, x1, [SP, #-0x10]!
    // 0xc4e034: r0 = addAll()
    //     0xc4e034: bl              #0x5029fc  ; [package:typed_data/src/typed_buffer.dart] TypedDataBuffer::addAll
    // 0xc4e038: add             SP, SP, #0x10
    // 0xc4e03c: ldr             x16, [fp, #0x18]
    // 0xc4e040: SaveReg r16
    //     0xc4e040: str             x16, [SP, #-8]!
    // 0xc4e044: r0 = _iterate()
    //     0xc4e044: bl              #0xc3a278  ; [package:crypto/src/hash_sink.dart] HashSink::_iterate
    // 0xc4e048: add             SP, SP, #8
    // 0xc4e04c: r0 = Null
    //     0xc4e04c: mov             x0, NULL
    // 0xc4e050: LeaveFrame
    //     0xc4e050: mov             SP, fp
    //     0xc4e054: ldp             fp, lr, [SP], #0x10
    // 0xc4e058: ret
    //     0xc4e058: ret             
    // 0xc4e05c: r0 = StateError()
    //     0xc4e05c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc4e060: mov             x1, x0
    // 0xc4e064: r0 = "Hash.add() called after close()."
    //     0xc4e064: add             x0, PP, #0x15, lsl #12  ; [pp+0x15478] "Hash.add() called after close()."
    //     0xc4e068: ldr             x0, [x0, #0x478]
    // 0xc4e06c: StoreField: r1->field_b = r0
    //     0xc4e06c: stur            w0, [x1, #0xb]
    // 0xc4e070: mov             x0, x1
    // 0xc4e074: r0 = Throw()
    //     0xc4e074: bl              #0xd67e38  ; ThrowStub
    // 0xc4e078: brk             #0
    // 0xc4e07c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4e07c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4e080: b               #0xc4dfb0
  }
}

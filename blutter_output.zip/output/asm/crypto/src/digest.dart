// lib: , url: package:crypto/src/digest.dart

// class id: 1048812, size: 0x8
class :: {

  static String _hexEncode(List<int>) {
    // ** addr: 0xac4b50, size: 0x17c
    // 0xac4b50: EnterFrame
    //     0xac4b50: stp             fp, lr, [SP, #-0x10]!
    //     0xac4b54: mov             fp, SP
    // 0xac4b58: AllocStack(0x28)
    //     0xac4b58: sub             SP, SP, #0x28
    // 0xac4b5c: CheckStackOverflow
    //     0xac4b5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xac4b60: cmp             SP, x16
    //     0xac4b64: b.ls            #0xac4cb4
    // 0xac4b68: ldr             x2, [fp, #0x10]
    // 0xac4b6c: LoadField: r0 = r2->field_13
    //     0xac4b6c: ldur            w0, [x2, #0x13]
    // 0xac4b70: DecompressPointer r0
    //     0xac4b70: add             x0, x0, HEAP, lsl #32
    // 0xac4b74: r3 = LoadInt32Instr(r0)
    //     0xac4b74: sbfx            x3, x0, #1, #0x1f
    // 0xac4b78: stur            x3, [fp, #-0x10]
    // 0xac4b7c: lsl             x5, x3, #1
    // 0xac4b80: stur            x5, [fp, #-8]
    // 0xac4b84: r0 = BoxInt64Instr(r5)
    //     0xac4b84: sbfiz           x0, x5, #1, #0x1f
    //     0xac4b88: cmp             x5, x0, asr #1
    //     0xac4b8c: b.eq            #0xac4b98
    //     0xac4b90: bl              #0xd69bb8
    //     0xac4b94: stur            x5, [x0, #7]
    // 0xac4b98: mov             x4, x0
    // 0xac4b9c: r0 = AllocateUint8Array()
    //     0xac4b9c: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xac4ba0: mov             x2, x0
    // 0xac4ba4: stur            x2, [fp, #-0x28]
    // 0xac4ba8: r6 = 0
    //     0xac4ba8: mov             x6, #0
    // 0xac4bac: r5 = 0
    //     0xac4bac: mov             x5, #0
    // 0xac4bb0: ldr             x3, [fp, #0x10]
    // 0xac4bb4: ldur            x4, [fp, #-0x10]
    // 0xac4bb8: stur            x6, [fp, #-0x18]
    // 0xac4bbc: stur            x5, [fp, #-0x20]
    // 0xac4bc0: CheckStackOverflow
    //     0xac4bc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xac4bc4: cmp             SP, x16
    //     0xac4bc8: b.ls            #0xac4cbc
    // 0xac4bcc: cmp             x6, x4
    // 0xac4bd0: b.ge            #0xac4c94
    // 0xac4bd4: r0 = BoxInt64Instr(r6)
    //     0xac4bd4: sbfiz           x0, x6, #1, #0x1f
    //     0xac4bd8: cmp             x6, x0, asr #1
    //     0xac4bdc: b.eq            #0xac4be8
    //     0xac4be0: bl              #0xd69bb8
    //     0xac4be4: stur            x6, [x0, #7]
    // 0xac4be8: r1 = LoadClassIdInstr(r3)
    //     0xac4be8: ldur            x1, [x3, #-1]
    //     0xac4bec: ubfx            x1, x1, #0xc, #0x14
    // 0xac4bf0: stp             x0, x3, [SP, #-0x10]!
    // 0xac4bf4: mov             x0, x1
    // 0xac4bf8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xac4bf8: sub             lr, x0, #0xd83
    //     0xac4bfc: ldr             lr, [x21, lr, lsl #3]
    //     0xac4c00: blr             lr
    // 0xac4c04: add             SP, SP, #0x10
    // 0xac4c08: ldur            x2, [fp, #-0x20]
    // 0xac4c0c: add             x3, x2, #1
    // 0xac4c10: r4 = LoadInt32Instr(r0)
    //     0xac4c10: sbfx            x4, x0, #1, #0x1f
    // 0xac4c14: asr             x0, x4, #4
    // 0xac4c18: ubfx            x0, x0, #0, #0x20
    // 0xac4c1c: r7 = 15
    //     0xac4c1c: mov             x7, #0xf
    // 0xac4c20: and             x1, x0, x7
    // 0xac4c24: ubfx            x1, x1, #0, #0x20
    // 0xac4c28: r8 = "0123456789abcdef"
    //     0xac4c28: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] "0123456789abcdef"
    //     0xac4c2c: ldr             x8, [x8, #0x6b0]
    // 0xac4c30: ArrayLoad: r5 = r8[r1]  ; TypedUnsigned_1
    //     0xac4c30: add             x16, x8, x1
    //     0xac4c34: ldrb            w5, [x16, #0xf]
    // 0xac4c38: ldur            x0, [fp, #-8]
    // 0xac4c3c: mov             x1, x2
    // 0xac4c40: cmp             x1, x0
    // 0xac4c44: b.hs            #0xac4cc4
    // 0xac4c48: ldur            x9, [fp, #-0x28]
    // 0xac4c4c: ArrayStore: r9[r2] = r5  ; TypeUnknown_1
    //     0xac4c4c: add             x0, x9, x2
    //     0xac4c50: strb            w5, [x0, #0x17]
    // 0xac4c54: add             x5, x3, #1
    // 0xac4c58: ubfx            x4, x4, #0, #0x20
    // 0xac4c5c: and             x0, x4, x7
    // 0xac4c60: ubfx            x0, x0, #0, #0x20
    // 0xac4c64: ArrayLoad: r2 = r8[r0]  ; TypedUnsigned_1
    //     0xac4c64: add             x16, x8, x0
    //     0xac4c68: ldrb            w2, [x16, #0xf]
    // 0xac4c6c: ldur            x0, [fp, #-8]
    // 0xac4c70: mov             x1, x3
    // 0xac4c74: cmp             x1, x0
    // 0xac4c78: b.hs            #0xac4cc8
    // 0xac4c7c: ArrayStore: r9[r3] = r2  ; TypeUnknown_1
    //     0xac4c7c: add             x0, x9, x3
    //     0xac4c80: strb            w2, [x0, #0x17]
    // 0xac4c84: ldur            x0, [fp, #-0x18]
    // 0xac4c88: add             x6, x0, #1
    // 0xac4c8c: mov             x2, x9
    // 0xac4c90: b               #0xac4bb0
    // 0xac4c94: mov             x9, x2
    // 0xac4c98: stp             xzr, x9, [SP, #-0x10]!
    // 0xac4c9c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xac4ca0: r0 = createFromCharCodes()
    //     0xac4ca0: bl              #0x4d2124  ; [dart:core] _StringBase::createFromCharCodes
    // 0xac4ca4: add             SP, SP, #0x20
    // 0xac4ca8: LeaveFrame
    //     0xac4ca8: mov             SP, fp
    //     0xac4cac: ldp             fp, lr, [SP], #0x10
    // 0xac4cb0: ret
    //     0xac4cb0: ret             
    // 0xac4cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xac4cb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xac4cb8: b               #0xac4b68
    // 0xac4cbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xac4cbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xac4cc0: b               #0xac4bcc
    // 0xac4cc4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xac4cc4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xac4cc8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xac4cc8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 4760, size: 0xc, field offset: 0x8
class Digest extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xac4b10, size: 0x40
    // 0xac4b10: EnterFrame
    //     0xac4b10: stp             fp, lr, [SP, #-0x10]!
    //     0xac4b14: mov             fp, SP
    // 0xac4b18: CheckStackOverflow
    //     0xac4b18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xac4b1c: cmp             SP, x16
    //     0xac4b20: b.ls            #0xac4b48
    // 0xac4b24: ldr             x0, [fp, #0x10]
    // 0xac4b28: LoadField: r1 = r0->field_7
    //     0xac4b28: ldur            w1, [x0, #7]
    // 0xac4b2c: DecompressPointer r1
    //     0xac4b2c: add             x1, x1, HEAP, lsl #32
    // 0xac4b30: SaveReg r1
    //     0xac4b30: str             x1, [SP, #-8]!
    // 0xac4b34: r0 = _hexEncode()
    //     0xac4b34: bl              #0xac4b50  ; [package:crypto/src/digest.dart] ::_hexEncode
    // 0xac4b38: add             SP, SP, #8
    // 0xac4b3c: LeaveFrame
    //     0xac4b3c: mov             SP, fp
    //     0xac4b40: ldp             fp, lr, [SP], #0x10
    // 0xac4b44: ret
    //     0xac4b44: ret             
    // 0xac4b48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xac4b48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xac4b4c: b               #0xac4b24
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6d244, size: 0x198
    // 0xc6d244: EnterFrame
    //     0xc6d244: stp             fp, lr, [SP, #-0x10]!
    //     0xc6d248: mov             fp, SP
    // 0xc6d24c: AllocStack(0x38)
    //     0xc6d24c: sub             SP, SP, #0x38
    // 0xc6d250: CheckStackOverflow
    //     0xc6d250: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6d254: cmp             SP, x16
    //     0xc6d258: b.ls            #0xc6d3cc
    // 0xc6d25c: ldr             x0, [fp, #0x10]
    // 0xc6d260: cmp             w0, NULL
    // 0xc6d264: b.ne            #0xc6d278
    // 0xc6d268: r0 = false
    //     0xc6d268: add             x0, NULL, #0x30  ; false
    // 0xc6d26c: LeaveFrame
    //     0xc6d26c: mov             SP, fp
    //     0xc6d270: ldp             fp, lr, [SP], #0x10
    // 0xc6d274: ret
    //     0xc6d274: ret             
    // 0xc6d278: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6d278: mov             x1, #0x76
    //     0xc6d27c: tbz             w0, #0, #0xc6d28c
    //     0xc6d280: ldur            x1, [x0, #-1]
    //     0xc6d284: ubfx            x1, x1, #0xc, #0x14
    //     0xc6d288: lsl             x1, x1, #1
    // 0xc6d28c: r17 = 9520
    //     0xc6d28c: mov             x17, #0x2530
    // 0xc6d290: cmp             w1, w17
    // 0xc6d294: b.ne            #0xc6d3bc
    // 0xc6d298: ldr             x1, [fp, #0x18]
    // 0xc6d29c: LoadField: r2 = r1->field_7
    //     0xc6d29c: ldur            w2, [x1, #7]
    // 0xc6d2a0: DecompressPointer r2
    //     0xc6d2a0: add             x2, x2, HEAP, lsl #32
    // 0xc6d2a4: stur            x2, [fp, #-0x30]
    // 0xc6d2a8: LoadField: r3 = r0->field_7
    //     0xc6d2a8: ldur            w3, [x0, #7]
    // 0xc6d2ac: DecompressPointer r3
    //     0xc6d2ac: add             x3, x3, HEAP, lsl #32
    // 0xc6d2b0: stur            x3, [fp, #-0x28]
    // 0xc6d2b4: LoadField: r0 = r2->field_13
    //     0xc6d2b4: ldur            w0, [x2, #0x13]
    // 0xc6d2b8: DecompressPointer r0
    //     0xc6d2b8: add             x0, x0, HEAP, lsl #32
    // 0xc6d2bc: LoadField: r1 = r3->field_13
    //     0xc6d2bc: ldur            w1, [x3, #0x13]
    // 0xc6d2c0: DecompressPointer r1
    //     0xc6d2c0: add             x1, x1, HEAP, lsl #32
    // 0xc6d2c4: cmp             w0, w1
    // 0xc6d2c8: b.eq            #0xc6d2dc
    // 0xc6d2cc: r0 = false
    //     0xc6d2cc: add             x0, NULL, #0x30  ; false
    // 0xc6d2d0: LeaveFrame
    //     0xc6d2d0: mov             SP, fp
    //     0xc6d2d4: ldp             fp, lr, [SP], #0x10
    // 0xc6d2d8: ret
    //     0xc6d2d8: ret             
    // 0xc6d2dc: r4 = LoadInt32Instr(r0)
    //     0xc6d2dc: sbfx            x4, x0, #1, #0x1f
    // 0xc6d2e0: stur            x4, [fp, #-0x20]
    // 0xc6d2e4: r6 = 0
    //     0xc6d2e4: mov             x6, #0
    // 0xc6d2e8: r5 = 0
    //     0xc6d2e8: mov             x5, #0
    // 0xc6d2ec: stur            x6, [fp, #-0x10]
    // 0xc6d2f0: stur            x5, [fp, #-0x18]
    // 0xc6d2f4: CheckStackOverflow
    //     0xc6d2f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6d2f8: cmp             SP, x16
    //     0xc6d2fc: b.ls            #0xc6d3d4
    // 0xc6d300: cmp             x5, x4
    // 0xc6d304: b.ge            #0xc6d39c
    // 0xc6d308: r0 = BoxInt64Instr(r5)
    //     0xc6d308: sbfiz           x0, x5, #1, #0x1f
    //     0xc6d30c: cmp             x5, x0, asr #1
    //     0xc6d310: b.eq            #0xc6d31c
    //     0xc6d314: bl              #0xd69bb8
    //     0xc6d318: stur            x5, [x0, #7]
    // 0xc6d31c: mov             x1, x0
    // 0xc6d320: stur            x1, [fp, #-8]
    // 0xc6d324: r0 = LoadClassIdInstr(r2)
    //     0xc6d324: ldur            x0, [x2, #-1]
    //     0xc6d328: ubfx            x0, x0, #0xc, #0x14
    // 0xc6d32c: stp             x1, x2, [SP, #-0x10]!
    // 0xc6d330: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc6d330: sub             lr, x0, #0xd83
    //     0xc6d334: ldr             lr, [x21, lr, lsl #3]
    //     0xc6d338: blr             lr
    // 0xc6d33c: add             SP, SP, #0x10
    // 0xc6d340: mov             x2, x0
    // 0xc6d344: ldur            x1, [fp, #-0x28]
    // 0xc6d348: stur            x2, [fp, #-0x38]
    // 0xc6d34c: r0 = LoadClassIdInstr(r1)
    //     0xc6d34c: ldur            x0, [x1, #-1]
    //     0xc6d350: ubfx            x0, x0, #0xc, #0x14
    // 0xc6d354: ldur            x16, [fp, #-8]
    // 0xc6d358: stp             x16, x1, [SP, #-0x10]!
    // 0xc6d35c: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc6d35c: sub             lr, x0, #0xd83
    //     0xc6d360: ldr             lr, [x21, lr, lsl #3]
    //     0xc6d364: blr             lr
    // 0xc6d368: add             SP, SP, #0x10
    // 0xc6d36c: ldur            x1, [fp, #-0x38]
    // 0xc6d370: r2 = LoadInt32Instr(r1)
    //     0xc6d370: sbfx            x2, x1, #1, #0x1f
    // 0xc6d374: r1 = LoadInt32Instr(r0)
    //     0xc6d374: sbfx            x1, x0, #1, #0x1f
    // 0xc6d378: eor             x3, x2, x1
    // 0xc6d37c: ldur            x1, [fp, #-0x10]
    // 0xc6d380: orr             x6, x1, x3
    // 0xc6d384: ldur            x2, [fp, #-0x18]
    // 0xc6d388: add             x5, x2, #1
    // 0xc6d38c: ldur            x2, [fp, #-0x30]
    // 0xc6d390: ldur            x3, [fp, #-0x28]
    // 0xc6d394: ldur            x4, [fp, #-0x20]
    // 0xc6d398: b               #0xc6d2ec
    // 0xc6d39c: mov             x1, x6
    // 0xc6d3a0: cbz             x1, #0xc6d3ac
    // 0xc6d3a4: r0 = false
    //     0xc6d3a4: add             x0, NULL, #0x30  ; false
    // 0xc6d3a8: b               #0xc6d3b0
    // 0xc6d3ac: r0 = true
    //     0xc6d3ac: add             x0, NULL, #0x20  ; true
    // 0xc6d3b0: LeaveFrame
    //     0xc6d3b0: mov             SP, fp
    //     0xc6d3b4: ldp             fp, lr, [SP], #0x10
    // 0xc6d3b8: ret
    //     0xc6d3b8: ret             
    // 0xc6d3bc: r0 = false
    //     0xc6d3bc: add             x0, NULL, #0x30  ; false
    // 0xc6d3c0: LeaveFrame
    //     0xc6d3c0: mov             SP, fp
    //     0xc6d3c4: ldp             fp, lr, [SP], #0x10
    // 0xc6d3c8: ret
    //     0xc6d3c8: ret             
    // 0xc6d3cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6d3cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6d3d0: b               #0xc6d25c
    // 0xc6d3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6d3d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6d3d8: b               #0xc6d300
  }
}

// lib: , url: package:crypto/src/md5.dart

// class id: 1048817, size: 0x8
class :: {
}

// class id: 4758, size: 0x30, field offset: 0x2c
class _MD5Sink extends HashSink {

  _ _MD5Sink(/* No info */) {
    // ** addr: 0xc20e10, size: 0xb4
    // 0xc20e10: EnterFrame
    //     0xc20e10: stp             fp, lr, [SP, #-0x10]!
    //     0xc20e14: mov             fp, SP
    // 0xc20e18: AllocStack(0x8)
    //     0xc20e18: sub             SP, SP, #8
    // 0xc20e1c: CheckStackOverflow
    //     0xc20e1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc20e20: cmp             SP, x16
    //     0xc20e24: b.ls            #0xc20ebc
    // 0xc20e28: r4 = 8
    //     0xc20e28: mov             x4, #8
    // 0xc20e2c: r0 = AllocateUint32Array()
    //     0xc20e2c: bl              #0xd691a0  ; AllocateUint32ArrayStub
    // 0xc20e30: mov             x2, x0
    // 0xc20e34: ldr             x1, [fp, #0x18]
    // 0xc20e38: stur            x2, [fp, #-8]
    // 0xc20e3c: StoreField: r1->field_2b = r0
    //     0xc20e3c: stur            w0, [x1, #0x2b]
    //     0xc20e40: ldurb           w16, [x1, #-1]
    //     0xc20e44: ldurb           w17, [x0, #-1]
    //     0xc20e48: and             x16, x17, x16, lsr #2
    //     0xc20e4c: tst             x16, HEAP, lsr #32
    //     0xc20e50: b.eq            #0xc20e58
    //     0xc20e54: bl              #0xd6826c
    // 0xc20e58: ldr             x16, [fp, #0x10]
    // 0xc20e5c: stp             x16, x1, [SP, #-0x10]!
    // 0xc20e60: r16 = Instance_Endian
    //     0xc20e60: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xc20e64: SaveReg r16
    //     0xc20e64: str             x16, [SP, #-8]!
    // 0xc20e68: r4 = const [0, 0x3, 0x3, 0x2, endian, 0x2, null]
    //     0xc20e68: add             x4, PP, #0xe, lsl #12  ; [pp+0xefc0] List(7) [0, 0x3, 0x3, 0x2, "endian", 0x2, Null]
    //     0xc20e6c: ldr             x4, [x4, #0xfc0]
    // 0xc20e70: r0 = HashSink()
    //     0xc20e70: bl              #0xc20ec4  ; [package:crypto/src/hash_sink.dart] HashSink::HashSink
    // 0xc20e74: add             SP, SP, #0x18
    // 0xc20e78: ldur            x1, [fp, #-8]
    // 0xc20e7c: r2 = 1732584193
    //     0xc20e7c: mov             x2, #0x2301
    //     0xc20e80: movk            x2, #0x6745, lsl #16
    // 0xc20e84: StoreField: r1->field_17 = r2
    //     0xc20e84: stur            w2, [x1, #0x17]
    // 0xc20e88: r2 = 4023233417
    //     0xc20e88: mov             x2, #0xab89
    //     0xc20e8c: movk            x2, #0xefcd, lsl #16
    // 0xc20e90: StoreField: r1->field_1b = r2
    //     0xc20e90: stur            w2, [x1, #0x1b]
    // 0xc20e94: r2 = 2562383102
    //     0xc20e94: mov             x2, #0xdcfe
    //     0xc20e98: movk            x2, #0x98ba, lsl #16
    // 0xc20e9c: StoreField: r1->field_1f = r2
    //     0xc20e9c: stur            w2, [x1, #0x1f]
    // 0xc20ea0: r2 = 271733878
    //     0xc20ea0: mov             x2, #0x5476
    //     0xc20ea4: movk            x2, #0x1032, lsl #16
    // 0xc20ea8: StoreField: r1->field_23 = r2
    //     0xc20ea8: stur            w2, [x1, #0x23]
    // 0xc20eac: r0 = Null
    //     0xc20eac: mov             x0, NULL
    // 0xc20eb0: LeaveFrame
    //     0xc20eb0: mov             SP, fp
    //     0xc20eb4: ldp             fp, lr, [SP], #0x10
    // 0xc20eb8: ret
    //     0xc20eb8: ret             
    // 0xc20ebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20ebc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20ec0: b               #0xc20e28
  }
  _ updateHash(/* No info */) {
    // ** addr: 0xcb1a0c, size: 0x3e8
    // 0xcb1a0c: EnterFrame
    //     0xcb1a0c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb1a10: mov             fp, SP
    // 0xcb1a14: AllocStack(0x38)
    //     0xcb1a14: sub             SP, SP, #0x38
    // 0xcb1a18: ldr             x2, [fp, #0x18]
    // 0xcb1a1c: LoadField: r3 = r2->field_2b
    //     0xcb1a1c: ldur            w3, [x2, #0x2b]
    // 0xcb1a20: DecompressPointer r3
    //     0xcb1a20: add             x3, x3, HEAP, lsl #32
    // 0xcb1a24: stur            x3, [fp, #-0x20]
    // 0xcb1a28: LoadField: r4 = r3->field_13
    //     0xcb1a28: ldur            w4, [x3, #0x13]
    // 0xcb1a2c: DecompressPointer r4
    //     0xcb1a2c: add             x4, x4, HEAP, lsl #32
    // 0xcb1a30: r5 = LoadInt32Instr(r4)
    //     0xcb1a30: sbfx            x5, x4, #1, #0x1f
    // 0xcb1a34: mov             x0, x5
    // 0xcb1a38: r1 = 0
    //     0xcb1a38: mov             x1, #0
    // 0xcb1a3c: cmp             x1, x0
    // 0xcb1a40: b.hs            #0xcb1d60
    // 0xcb1a44: LoadField: r4 = r3->field_17
    //     0xcb1a44: ldur            w4, [x3, #0x17]
    // 0xcb1a48: mov             x0, x5
    // 0xcb1a4c: stur            x4, [fp, #-0x28]
    // 0xcb1a50: r1 = 1
    //     0xcb1a50: mov             x1, #1
    // 0xcb1a54: cmp             x1, x0
    // 0xcb1a58: b.hs            #0xcb1d64
    // 0xcb1a5c: LoadField: r6 = r3->field_1b
    //     0xcb1a5c: ldur            w6, [x3, #0x1b]
    // 0xcb1a60: mov             x0, x5
    // 0xcb1a64: stur            x6, [fp, #-0x18]
    // 0xcb1a68: r1 = 2
    //     0xcb1a68: mov             x1, #2
    // 0xcb1a6c: cmp             x1, x0
    // 0xcb1a70: b.hs            #0xcb1d68
    // 0xcb1a74: LoadField: r7 = r3->field_1f
    //     0xcb1a74: ldur            w7, [x3, #0x1f]
    // 0xcb1a78: mov             x0, x5
    // 0xcb1a7c: stur            x7, [fp, #-0x10]
    // 0xcb1a80: r1 = 3
    //     0xcb1a80: mov             x1, #3
    // 0xcb1a84: cmp             x1, x0
    // 0xcb1a88: b.hs            #0xcb1d6c
    // 0xcb1a8c: LoadField: r5 = r3->field_23
    //     0xcb1a8c: ldur            w5, [x3, #0x23]
    // 0xcb1a90: stur            x5, [fp, #-8]
    // 0xcb1a94: mov             x8, x4
    // 0xcb1a98: ubfx            x8, x8, #0, #0x20
    // 0xcb1a9c: mov             x9, x6
    // 0xcb1aa0: ubfx            x9, x9, #0, #0x20
    // 0xcb1aa4: mov             x10, x7
    // 0xcb1aa8: ubfx            x10, x10, #0, #0x20
    // 0xcb1aac: mov             x11, x5
    // 0xcb1ab0: ubfx            x11, x11, #0, #0x20
    // 0xcb1ab4: ldr             x12, [fp, #0x10]
    // 0xcb1ab8: LoadField: r13 = r12->field_13
    //     0xcb1ab8: ldur            w13, [x12, #0x13]
    // 0xcb1abc: DecompressPointer r13
    //     0xcb1abc: add             x13, x13, HEAP, lsl #32
    // 0xcb1ac0: r14 = LoadInt32Instr(r13)
    //     0xcb1ac0: sbfx            x14, x13, #1, #0x1f
    // 0xcb1ac4: mov             x7, x8
    // 0xcb1ac8: mov             x5, x9
    // 0xcb1acc: mov             x1, x10
    // 0xcb1ad0: mov             x0, x11
    // 0xcb1ad4: r25 = 0
    //     0xcb1ad4: mov             x25, #0
    // 0xcb1ad8: r24 = const [3614090360, 3905402710, 0x242070db, 3250441966, 4118548399, 1200080426, 2821735955, 4249261313, 1770035416, 2336552879, 4294925233, 2304563134, 1804603682, 4254626195, 2792965006, 1236535329, 4129170786, 3225465664, 0x265e5a51, 3921069994, 3593408605, 0x2441453, 3634488961, 3889429448, 0x21e1cde6, 3275163606, 4107603335, 1163531501, 2850285829, 4243563512, 1735328473, 2368359562, 4294588738, 2272392833, 1839030562, 4259657740, 2763975236, 1272893353, 4139469664, 3200236656, 0x289b7ec6, 3936430074, 3572445317, 0x4881d05, 3654602809, 3873151461, 0x1fa27cf8, 3299628645, 4096336452, 1126891415, 2878612391, 4237533241, 1700485571, 2399980690, 4293915773, 2240044497, 1873313359, 4264355552, 2734768916, 1309151649, 4149444226, 3174756917, 0x2ad7d2bb, 3951481745]
    //     0xcb1ad8: add             x24, PP, #0x1d, lsl #12  ; [pp+0x1d690] List<int>(64)
    //     0xcb1adc: ldr             x24, [x24, #0x690]
    // 0xcb1ae0: r23 = const [0x7, 0xc, 0x11, 0x16, 0x7, 0xc, 0x11, 0x16, 0x7, 0xc, 0x11, 0x16, 0x7, 0xc, 0x11, 0x16, 0x5, 0x9, 0xe, 0x14, 0x5, 0x9, 0xe, 0x14, 0x5, 0x9, 0xe, 0x14, 0x5, 0x9, 0xe, 0x14, 0x4, 0xb, 0x10, 0x17, 0x4, 0xb, 0x10, 0x17, 0x4, 0xb, 0x10, 0x17, 0x4, 0xb, 0x10, 0x17, 0x6, 0xa, 0xf, 0x15, 0x6, 0xa, 0xf, 0x15, 0x6, 0xa, 0xf, 0x15, 0x6, 0xa, 0xf, 0x15]
    //     0xcb1ae0: add             x23, PP, #0x1d, lsl #12  ; [pp+0x1d698] List<int>(64)
    //     0xcb1ae4: ldr             x23, [x23, #0x698]
    // 0xcb1ae8: r20 = 32
    //     0xcb1ae8: mov             x20, #0x20
    // 0xcb1aec: r19 = 5
    //     0xcb1aec: mov             x19, #5
    // 0xcb1af0: r13 = 15
    //     0xcb1af0: mov             x13, #0xf
    // 0xcb1af4: r11 = 7
    //     0xcb1af4: mov             x11, #7
    // 0xcb1af8: r10 = 31
    //     0xcb1af8: mov             x10, #0x1f
    // 0xcb1afc: r9 = 1
    //     0xcb1afc: mov             x9, #1
    // 0xcb1b00: r8 = 3
    //     0xcb1b00: mov             x8, #3
    // 0xcb1b04: stur            x7, [fp, #-0x30]
    // 0xcb1b08: stur            x0, [fp, #-0x38]
    // 0xcb1b0c: CheckStackOverflow
    //     0xcb1b0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb1b10: cmp             SP, x16
    //     0xcb1b14: b.ls            #0xcb1d70
    // 0xcb1b18: cmp             x25, #0x40
    // 0xcb1b1c: b.ge            #0xcb1d00
    // 0xcb1b20: cmp             x25, #0x10
    // 0xcb1b24: b.ge            #0xcb1b6c
    // 0xcb1b28: mov             x6, x5
    // 0xcb1b2c: ubfx            x6, x6, #0, #0x20
    // 0xcb1b30: mov             x3, x1
    // 0xcb1b34: ubfx            x3, x3, #0, #0x20
    // 0xcb1b38: and             x4, x6, x3
    // 0xcb1b3c: mov             x3, x5
    // 0xcb1b40: ubfx            x3, x3, #0, #0x20
    // 0xcb1b44: mvn             w6, w3
    // 0xcb1b48: mov             x3, x0
    // 0xcb1b4c: ubfx            x3, x3, #0, #0x20
    // 0xcb1b50: and             x7, x6, x3
    // 0xcb1b54: ubfx            x4, x4, #0, #0x20
    // 0xcb1b58: ubfx            x7, x7, #0, #0x20
    // 0xcb1b5c: orr             x3, x4, x7
    // 0xcb1b60: mov             x4, x3
    // 0xcb1b64: mov             x3, x25
    // 0xcb1b68: b               #0xcb1c2c
    // 0xcb1b6c: cmp             x25, #0x20
    // 0xcb1b70: b.ge            #0xcb1bd0
    // 0xcb1b74: mov             x3, x5
    // 0xcb1b78: ubfx            x3, x3, #0, #0x20
    // 0xcb1b7c: mov             x4, x0
    // 0xcb1b80: ubfx            x4, x4, #0, #0x20
    // 0xcb1b84: and             x6, x4, x3
    // 0xcb1b88: mov             x3, x0
    // 0xcb1b8c: ubfx            x3, x3, #0, #0x20
    // 0xcb1b90: mvn             w4, w3
    // 0xcb1b94: mov             x3, x1
    // 0xcb1b98: ubfx            x3, x3, #0, #0x20
    // 0xcb1b9c: and             x7, x4, x3
    // 0xcb1ba0: ubfx            x6, x6, #0, #0x20
    // 0xcb1ba4: ubfx            x7, x7, #0, #0x20
    // 0xcb1ba8: orr             x3, x6, x7
    // 0xcb1bac: mov             x4, x25
    // 0xcb1bb0: ubfx            x4, x4, #0, #0x20
    // 0xcb1bb4: mul             x6, x4, x19
    // 0xcb1bb8: add             w4, w6, w9
    // 0xcb1bbc: and             x6, x4, x13
    // 0xcb1bc0: ubfx            x6, x6, #0, #0x20
    // 0xcb1bc4: mov             x4, x3
    // 0xcb1bc8: mov             x3, x6
    // 0xcb1bcc: b               #0xcb1c2c
    // 0xcb1bd0: cmp             x25, #0x30
    // 0xcb1bd4: b.ge            #0xcb1c00
    // 0xcb1bd8: eor             x3, x5, x1
    // 0xcb1bdc: eor             x4, x3, x0
    // 0xcb1be0: mov             x3, x25
    // 0xcb1be4: ubfx            x3, x3, #0, #0x20
    // 0xcb1be8: mul             x6, x3, x8
    // 0xcb1bec: add             w3, w6, w19
    // 0xcb1bf0: and             x6, x3, x13
    // 0xcb1bf4: ubfx            x6, x6, #0, #0x20
    // 0xcb1bf8: mov             x3, x6
    // 0xcb1bfc: b               #0xcb1c2c
    // 0xcb1c00: mov             x3, x0
    // 0xcb1c04: ubfx            x3, x3, #0, #0x20
    // 0xcb1c08: mvn             w4, w3
    // 0xcb1c0c: ubfx            x4, x4, #0, #0x20
    // 0xcb1c10: orr             x3, x5, x4
    // 0xcb1c14: eor             x4, x1, x3
    // 0xcb1c18: mov             x3, x25
    // 0xcb1c1c: ubfx            x3, x3, #0, #0x20
    // 0xcb1c20: mul             x6, x3, x11
    // 0xcb1c24: and             x3, x6, x13
    // 0xcb1c28: ubfx            x3, x3, #0, #0x20
    // 0xcb1c2c: ldur            x6, [fp, #-0x30]
    // 0xcb1c30: ubfx            x6, x6, #0, #0x20
    // 0xcb1c34: ubfx            x4, x4, #0, #0x20
    // 0xcb1c38: add             w7, w6, w4
    // 0xcb1c3c: ArrayLoad: r4 = r24[r25]  ; Unknown_4
    //     0xcb1c3c: add             x16, x24, x25, lsl #2
    //     0xcb1c40: ldur            w4, [x16, #0xf]
    // 0xcb1c44: DecompressPointer r4
    //     0xcb1c44: add             x4, x4, HEAP, lsl #32
    // 0xcb1c48: mov             x0, x14
    // 0xcb1c4c: mov             x6, x1
    // 0xcb1c50: mov             x1, x3
    // 0xcb1c54: cmp             x1, x0
    // 0xcb1c58: b.hs            #0xcb1d78
    // 0xcb1c5c: ArrayLoad: r1 = r12[r3]  ; Unknown_4
    //     0xcb1c5c: add             x16, x12, x3, lsl #2
    //     0xcb1c60: ldur            w1, [x16, #0x17]
    // 0xcb1c64: r3 = LoadInt32Instr(r4)
    //     0xcb1c64: sbfx            x3, x4, #1, #0x1f
    //     0xcb1c68: tbz             w4, #0, #0xcb1c70
    //     0xcb1c6c: ldur            x3, [x4, #7]
    // 0xcb1c70: add             w4, w3, w1
    // 0xcb1c74: add             w1, w7, w4
    // 0xcb1c78: ArrayLoad: r3 = r23[r25]  ; Unknown_4
    //     0xcb1c78: add             x16, x23, x25, lsl #2
    //     0xcb1c7c: ldur            w3, [x16, #0xf]
    // 0xcb1c80: DecompressPointer r3
    //     0xcb1c80: add             x3, x3, HEAP, lsl #32
    // 0xcb1c84: r4 = LoadInt32Instr(r3)
    //     0xcb1c84: sbfx            x4, x3, #1, #0x1f
    //     0xcb1c88: tbz             w3, #0, #0xcb1c90
    //     0xcb1c8c: ldur            x4, [x3, #7]
    // 0xcb1c90: and             x3, x4, x10
    // 0xcb1c94: mov             x4, x3
    // 0xcb1c98: ubfx            x4, x4, #0, #0x20
    // 0xcb1c9c: tbnz            x4, #0x3f, #0xcb1d7c
    // 0xcb1ca0: lsl             w7, w1, w4
    // 0xcb1ca4: cmp             x4, #0x1f
    // 0xcb1ca8: csel            x7, x7, xzr, le
    // 0xcb1cac: ubfx            x3, x3, #0, #0x20
    // 0xcb1cb0: sub             x4, x20, x3
    // 0xcb1cb4: tbnz            x4, #0x3f, #0xcb1db8
    // 0xcb1cb8: lsr             w3, w1, w4
    // 0xcb1cbc: cmp             x4, #0x1f
    // 0xcb1cc0: csel            x3, x3, xzr, le
    // 0xcb1cc4: orr             x1, x7, x3
    // 0xcb1cc8: mov             x3, x5
    // 0xcb1ccc: ubfx            x3, x3, #0, #0x20
    // 0xcb1cd0: add             w4, w3, w1
    // 0xcb1cd4: add             x3, x25, #1
    // 0xcb1cd8: ubfx            x4, x4, #0, #0x20
    // 0xcb1cdc: ldur            x7, [fp, #-0x38]
    // 0xcb1ce0: mov             x1, x5
    // 0xcb1ce4: mov             x5, x4
    // 0xcb1ce8: mov             x0, x6
    // 0xcb1cec: mov             x25, x3
    // 0xcb1cf0: ldur            x3, [fp, #-0x20]
    // 0xcb1cf4: ldur            x4, [fp, #-0x28]
    // 0xcb1cf8: ldur            x6, [fp, #-0x18]
    // 0xcb1cfc: b               #0xcb1b04
    // 0xcb1d00: mov             x2, x3
    // 0xcb1d04: mov             x6, x1
    // 0xcb1d08: mov             x1, x4
    // 0xcb1d0c: ldur            x3, [fp, #-0x18]
    // 0xcb1d10: ldur            x4, [fp, #-0x10]
    // 0xcb1d14: ldur            x7, [fp, #-8]
    // 0xcb1d18: ldur            x8, [fp, #-0x30]
    // 0xcb1d1c: ubfx            x8, x8, #0, #0x20
    // 0xcb1d20: add             w9, w8, w1
    // 0xcb1d24: StoreField: r2->field_17 = r9
    //     0xcb1d24: stur            w9, [x2, #0x17]
    // 0xcb1d28: ubfx            x5, x5, #0, #0x20
    // 0xcb1d2c: add             w1, w5, w3
    // 0xcb1d30: StoreField: r2->field_1b = r1
    //     0xcb1d30: stur            w1, [x2, #0x1b]
    // 0xcb1d34: ubfx            x6, x6, #0, #0x20
    // 0xcb1d38: add             w1, w6, w4
    // 0xcb1d3c: StoreField: r2->field_1f = r1
    //     0xcb1d3c: stur            w1, [x2, #0x1f]
    // 0xcb1d40: ldur            x1, [fp, #-0x38]
    // 0xcb1d44: ubfx            x1, x1, #0, #0x20
    // 0xcb1d48: add             w3, w1, w7
    // 0xcb1d4c: StoreField: r2->field_23 = r3
    //     0xcb1d4c: stur            w3, [x2, #0x23]
    // 0xcb1d50: r0 = Null
    //     0xcb1d50: mov             x0, NULL
    // 0xcb1d54: LeaveFrame
    //     0xcb1d54: mov             SP, fp
    //     0xcb1d58: ldp             fp, lr, [SP], #0x10
    // 0xcb1d5c: ret
    //     0xcb1d5c: ret             
    // 0xcb1d60: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb1d60: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb1d64: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb1d64: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb1d68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb1d68: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb1d6c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb1d6c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb1d70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb1d70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb1d74: b               #0xcb1b18
    // 0xcb1d78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb1d78: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb1d7c: str             x4, [THR, #0xc0]  ; THR::
    // 0xcb1d80: stp             x24, x25, [SP, #-0x10]!
    // 0xcb1d84: stp             x20, x23, [SP, #-0x10]!
    // 0xcb1d88: stp             x14, x19, [SP, #-0x10]!
    // 0xcb1d8c: stp             x12, x13, [SP, #-0x10]!
    // 0xcb1d90: stp             x10, x11, [SP, #-0x10]!
    // 0xcb1d94: stp             x8, x9, [SP, #-0x10]!
    // 0xcb1d98: stp             x5, x6, [SP, #-0x10]!
    // 0xcb1d9c: stp             x3, x4, [SP, #-0x10]!
    // 0xcb1da0: stp             x1, x2, [SP, #-0x10]!
    // 0xcb1da4: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcb1da8: r4 = 0
    //     0xcb1da8: mov             x4, #0
    // 0xcb1dac: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcb1db0: blr             lr
    // 0xcb1db4: brk             #0
    // 0xcb1db8: str             x4, [THR, #0xc0]  ; THR::
    // 0xcb1dbc: stp             x24, x25, [SP, #-0x10]!
    // 0xcb1dc0: stp             x20, x23, [SP, #-0x10]!
    // 0xcb1dc4: stp             x14, x19, [SP, #-0x10]!
    // 0xcb1dc8: stp             x12, x13, [SP, #-0x10]!
    // 0xcb1dcc: stp             x10, x11, [SP, #-0x10]!
    // 0xcb1dd0: stp             x8, x9, [SP, #-0x10]!
    // 0xcb1dd4: stp             x6, x7, [SP, #-0x10]!
    // 0xcb1dd8: stp             x4, x5, [SP, #-0x10]!
    // 0xcb1ddc: stp             x1, x2, [SP, #-0x10]!
    // 0xcb1de0: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcb1de4: r4 = 0
    //     0xcb1de4: mov             x4, #0
    // 0xcb1de8: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcb1dec: blr             lr
    // 0xcb1df0: brk             #0
  }
}

// class id: 5595, size: 0x14, field offset: 0xc
//   const constructor, 
class _MD5 extends Hash {

  _Mint field_c;

  _ startChunkedConversion(/* No info */) {
    // ** addr: 0xc738b8, size: 0x74
    // 0xc738b8: EnterFrame
    //     0xc738b8: stp             fp, lr, [SP, #-0x10]!
    //     0xc738bc: mov             fp, SP
    // 0xc738c0: AllocStack(0x8)
    //     0xc738c0: sub             SP, SP, #8
    // 0xc738c4: CheckStackOverflow
    //     0xc738c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc738c8: cmp             SP, x16
    //     0xc738cc: b.ls            #0xc73924
    // 0xc738d0: ldr             x0, [fp, #0x10]
    // 0xc738d4: r2 = Null
    //     0xc738d4: mov             x2, NULL
    // 0xc738d8: r1 = Null
    //     0xc738d8: mov             x1, NULL
    // 0xc738dc: r8 = Sink<Digest>
    //     0xc738dc: add             x8, PP, #0x22, lsl #12  ; [pp+0x22948] Type: Sink<Digest>
    //     0xc738e0: ldr             x8, [x8, #0x948]
    // 0xc738e4: r3 = Null
    //     0xc738e4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22950] Null
    //     0xc738e8: ldr             x3, [x3, #0x950]
    // 0xc738ec: r0 = Sink<Digest>()
    //     0xc738ec: bl              #0xbe39f4  ; IsType_Sink<Digest>_Stub
    // 0xc738f0: r0 = _MD5Sink()
    //     0xc738f0: bl              #0xc21018  ; Allocate_MD5SinkStub -> _MD5Sink (size=0x30)
    // 0xc738f4: stur            x0, [fp, #-8]
    // 0xc738f8: ldr             x16, [fp, #0x10]
    // 0xc738fc: stp             x16, x0, [SP, #-0x10]!
    // 0xc73900: r0 = _MD5Sink()
    //     0xc73900: bl              #0xc20e10  ; [package:crypto/src/md5.dart] _MD5Sink::_MD5Sink
    // 0xc73904: add             SP, SP, #0x10
    // 0xc73908: r1 = <List<int>>
    //     0xc73908: ldr             x1, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0xc7390c: r0 = _ByteAdapterSink()
    //     0xc7390c: bl              #0xc21024  ; Allocate_ByteAdapterSinkStub -> _ByteAdapterSink (size=0x10)
    // 0xc73910: ldur            x1, [fp, #-8]
    // 0xc73914: StoreField: r0->field_b = r1
    //     0xc73914: stur            w1, [x0, #0xb]
    // 0xc73918: LeaveFrame
    //     0xc73918: mov             SP, fp
    //     0xc7391c: ldp             fp, lr, [SP], #0x10
    // 0xc73920: ret
    //     0xc73920: ret             
    // 0xc73924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc73924: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc73928: b               #0xc738d0
  }
}

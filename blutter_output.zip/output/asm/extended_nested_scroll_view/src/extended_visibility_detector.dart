// lib: , url: package:extended_nested_scroll_view/src/extended_visibility_detector.dart

// class id: 1048960, size: 0x8
class :: {
}

// class id: 3382, size: 0x14, field offset: 0x14
abstract class _ExtendedVisibilityDetectorState extends State<ExtendedVisibilityDetector> {
}

// class id: 4204, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class ExtendedVisibilityDetector extends StatefulWidget {

  static _ of(/* No info */) {
    // ** addr: 0x8319f8, size: 0x48
    // 0x8319f8: EnterFrame
    //     0x8319f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8319fc: mov             fp, SP
    // 0x831a00: CheckStackOverflow
    //     0x831a00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x831a04: cmp             SP, x16
    //     0x831a08: b.ls            #0x831a38
    // 0x831a0c: r16 = <_ExtendedVisibilityDetectorState<ExtendedVisibilityDetector>>
    //     0x831a0c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2ef98] TypeArguments: <_ExtendedVisibilityDetectorState<ExtendedVisibilityDetector>>
    //     0x831a10: ldr             x16, [x16, #0xf98]
    // 0x831a14: ldr             lr, [fp, #0x10]
    // 0x831a18: stp             lr, x16, [SP, #-0x10]!
    // 0x831a1c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x831a1c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x831a20: r0 = findAncestorStateOfType()
    //     0x831a20: bl              #0x594348  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorStateOfType
    // 0x831a24: add             SP, SP, #0x10
    // 0x831a28: r0 = Null
    //     0x831a28: mov             x0, NULL
    // 0x831a2c: LeaveFrame
    //     0x831a2c: mov             SP, fp
    //     0x831a30: ldp             fp, lr, [SP], #0x10
    // 0x831a34: ret
    //     0x831a34: ret             
    // 0x831a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x831a38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x831a3c: b               #0x831a0c
  }
}

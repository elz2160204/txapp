// lib: , url: package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart

// class id: 1048959, size: 0x8
class :: {

  static _ DoubleEx.notZero(/* No info */) {
    // ** addr: 0xc140b8, size: 0x5c
    // 0xc140b8: d0 = 0.000000
    //     0xc140b8: eor             v0.16b, v0.16b, v0.16b
    // 0xc140bc: ldr             d1, [SP]
    // 0xc140c0: fcmp            d1, d0
    // 0xc140c4: b.vs            #0xc140d4
    // 0xc140c8: b.ne            #0xc140d4
    // 0xc140cc: d1 = 0.000000
    //     0xc140cc: eor             v1.16b, v1.16b, v1.16b
    // 0xc140d0: b               #0xc140f0
    // 0xc140d4: fcmp            d1, d0
    // 0xc140d8: b.vs            #0xc140e8
    // 0xc140dc: b.ge            #0xc140e8
    // 0xc140e0: fneg            d0, d1
    // 0xc140e4: b               #0xc140ec
    // 0xc140e8: mov             v0.16b, v1.16b
    // 0xc140ec: mov             v1.16b, v0.16b
    // 0xc140f0: d0 = 0.000000
    //     0xc140f0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0xc140f4: ldr             d0, [x17, #0x1e0]
    // 0xc140f8: fcmp            d1, d0
    // 0xc140fc: b.vs            #0xc14104
    // 0xc14100: b.gt            #0xc1410c
    // 0xc14104: r0 = false
    //     0xc14104: add             x0, NULL, #0x30  ; false
    // 0xc14108: b               #0xc14110
    // 0xc1410c: r0 = true
    //     0xc1410c: add             x0, NULL, #0x20  ; true
    // 0xc14110: ret
    //     0xc14110: ret             
  }
  static _ DoubleEx.isZero(/* No info */) {
    // ** addr: 0xd0cd24, size: 0x5c
    // 0xd0cd24: d0 = 0.000000
    //     0xd0cd24: eor             v0.16b, v0.16b, v0.16b
    // 0xd0cd28: ldr             d1, [SP]
    // 0xd0cd2c: fcmp            d1, d0
    // 0xd0cd30: b.vs            #0xd0cd40
    // 0xd0cd34: b.ne            #0xd0cd40
    // 0xd0cd38: d1 = 0.000000
    //     0xd0cd38: eor             v1.16b, v1.16b, v1.16b
    // 0xd0cd3c: b               #0xd0cd5c
    // 0xd0cd40: fcmp            d1, d0
    // 0xd0cd44: b.vs            #0xd0cd54
    // 0xd0cd48: b.ge            #0xd0cd54
    // 0xd0cd4c: fneg            d0, d1
    // 0xd0cd50: b               #0xd0cd58
    // 0xd0cd54: mov             v0.16b, v1.16b
    // 0xd0cd58: mov             v1.16b, v0.16b
    // 0xd0cd5c: d0 = 0.000000
    //     0xd0cd5c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0xd0cd60: ldr             d0, [x17, #0x1e0]
    // 0xd0cd64: fcmp            d1, d0
    // 0xd0cd68: b.vs            #0xd0cd70
    // 0xd0cd6c: b.lt            #0xd0cd78
    // 0xd0cd70: r0 = false
    //     0xd0cd70: add             x0, NULL, #0x30  ; false
    // 0xd0cd74: b               #0xd0cd7c
    // 0xd0cd78: r0 = true
    //     0xd0cd78: add             x0, NULL, #0x20  ; true
    // 0xd0cd7c: ret
    //     0xd0cd7c: ret             
  }
}

// class id: 1707, size: 0x34, field offset: 0x1c
class _NestedScrollMetrics extends FixedScrollMetrics {
}

// class id: 1721, size: 0x1c, field offset: 0x14
class _NestedOuterBallisticScrollActivity extends BallisticScrollActivity {

  _ resetActivity(/* No info */) {
    // ** addr: 0xbd09b8, size: 0xd8
    // 0xbd09b8: EnterFrame
    //     0xbd09b8: stp             fp, lr, [SP, #-0x10]!
    //     0xbd09bc: mov             fp, SP
    // 0xbd09c0: AllocStack(0x10)
    //     0xbd09c0: sub             SP, SP, #0x10
    // 0xbd09c4: CheckStackOverflow
    //     0xbd09c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd09c8: cmp             SP, x16
    //     0xbd09cc: b.ls            #0xbd0a7c
    // 0xbd09d0: ldr             x3, [fp, #0x10]
    // 0xbd09d4: LoadField: r4 = r3->field_7
    //     0xbd09d4: ldur            w4, [x3, #7]
    // 0xbd09d8: DecompressPointer r4
    //     0xbd09d8: add             x4, x4, HEAP, lsl #32
    // 0xbd09dc: mov             x0, x4
    // 0xbd09e0: stur            x4, [fp, #-8]
    // 0xbd09e4: r2 = Null
    //     0xbd09e4: mov             x2, NULL
    // 0xbd09e8: r1 = Null
    //     0xbd09e8: mov             x1, NULL
    // 0xbd09ec: r4 = LoadClassIdInstr(r0)
    //     0xbd09ec: ldur            x4, [x0, #-1]
    //     0xbd09f0: ubfx            x4, x4, #0xc, #0x14
    // 0xbd09f4: r17 = -4844
    //     0xbd09f4: mov             x17, #-0x12ec
    // 0xbd09f8: add             x4, x4, x17
    // 0xbd09fc: cmp             x4, #1
    // 0xbd0a00: b.ls            #0xbd0a18
    // 0xbd0a04: r8 = _NestedScrollPosition
    //     0xbd0a04: add             x8, PP, #0x38, lsl #12  ; [pp+0x381e8] Type: _NestedScrollPosition
    //     0xbd0a08: ldr             x8, [x8, #0x1e8]
    // 0xbd0a0c: r3 = Null
    //     0xbd0a0c: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c0a8] Null
    //     0xbd0a10: ldr             x3, [x3, #0xa8]
    // 0xbd0a14: r0 = _NestedScrollPosition()
    //     0xbd0a14: bl              #0x7d2824  ; IsType__NestedScrollPosition_Stub
    // 0xbd0a18: ldr             x0, [fp, #0x10]
    // 0xbd0a1c: LoadField: r1 = r0->field_13
    //     0xbd0a1c: ldur            w1, [x0, #0x13]
    // 0xbd0a20: DecompressPointer r1
    //     0xbd0a20: add             x1, x1, HEAP, lsl #32
    // 0xbd0a24: stur            x1, [fp, #-0x10]
    // 0xbd0a28: LoadField: r2 = r0->field_b
    //     0xbd0a28: ldur            w2, [x0, #0xb]
    // 0xbd0a2c: DecompressPointer r2
    //     0xbd0a2c: add             x2, x2, HEAP, lsl #32
    // 0xbd0a30: r16 = Sentinel
    //     0xbd0a30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbd0a34: cmp             w2, w16
    // 0xbd0a38: b.eq            #0xbd0a84
    // 0xbd0a3c: SaveReg r2
    //     0xbd0a3c: str             x2, [SP, #-8]!
    // 0xbd0a40: r0 = velocity()
    //     0xbd0a40: bl              #0xae9d58  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::velocity
    // 0xbd0a44: add             SP, SP, #8
    // 0xbd0a48: ldur            x16, [fp, #-0x10]
    // 0xbd0a4c: SaveReg r16
    //     0xbd0a4c: str             x16, [SP, #-8]!
    // 0xbd0a50: SaveReg d0
    //     0xbd0a50: str             d0, [SP, #-8]!
    // 0xbd0a54: r0 = createOuterBallisticScrollActivity()
    //     0xbd0a54: bl              #0xbd0a90  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::createOuterBallisticScrollActivity
    // 0xbd0a58: add             SP, SP, #0x10
    // 0xbd0a5c: ldur            x16, [fp, #-8]
    // 0xbd0a60: stp             x0, x16, [SP, #-0x10]!
    // 0xbd0a64: r0 = beginActivity()
    //     0xbd0a64: bl              #0xbff1c4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::beginActivity
    // 0xbd0a68: add             SP, SP, #0x10
    // 0xbd0a6c: r0 = Null
    //     0xbd0a6c: mov             x0, NULL
    // 0xbd0a70: LeaveFrame
    //     0xbd0a70: mov             SP, fp
    //     0xbd0a74: ldp             fp, lr, [SP], #0x10
    // 0xbd0a78: ret
    //     0xbd0a78: ret             
    // 0xbd0a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd0a7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd0a80: b               #0xbd09d0
    // 0xbd0a84: r9 = _controller
    //     0xbd0a84: add             x9, PP, #0x33, lsl #12  ; [pp+0x33140] Field <BallisticScrollActivity._controller@460498029>: late (offset: 0xc)
    //     0xbd0a88: ldr             x9, [x9, #0x140]
    // 0xbd0a8c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbd0a8c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ applyNewDimensions(/* No info */) {
    // ** addr: 0xd0d26c, size: 0xa8
    // 0xd0d26c: EnterFrame
    //     0xd0d26c: stp             fp, lr, [SP, #-0x10]!
    //     0xd0d270: mov             fp, SP
    // 0xd0d274: AllocStack(0x10)
    //     0xd0d274: sub             SP, SP, #0x10
    // 0xd0d278: CheckStackOverflow
    //     0xd0d278: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd0d27c: cmp             SP, x16
    //     0xd0d280: b.ls            #0xd0d300
    // 0xd0d284: ldr             x16, [fp, #0x10]
    // 0xd0d288: SaveReg r16
    //     0xd0d288: str             x16, [SP, #-8]!
    // 0xd0d28c: r0 = delegate()
    //     0xd0d28c: bl              #0xd0e2cc  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedOuterBallisticScrollActivity::delegate
    // 0xd0d290: add             SP, SP, #8
    // 0xd0d294: mov             x1, x0
    // 0xd0d298: ldr             x0, [fp, #0x10]
    // 0xd0d29c: stur            x1, [fp, #-0x10]
    // 0xd0d2a0: LoadField: r2 = r0->field_13
    //     0xd0d2a0: ldur            w2, [x0, #0x13]
    // 0xd0d2a4: DecompressPointer r2
    //     0xd0d2a4: add             x2, x2, HEAP, lsl #32
    // 0xd0d2a8: stur            x2, [fp, #-8]
    // 0xd0d2ac: LoadField: r3 = r0->field_b
    //     0xd0d2ac: ldur            w3, [x0, #0xb]
    // 0xd0d2b0: DecompressPointer r3
    //     0xd0d2b0: add             x3, x3, HEAP, lsl #32
    // 0xd0d2b4: r16 = Sentinel
    //     0xd0d2b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd0d2b8: cmp             w3, w16
    // 0xd0d2bc: b.eq            #0xd0d308
    // 0xd0d2c0: SaveReg r3
    //     0xd0d2c0: str             x3, [SP, #-8]!
    // 0xd0d2c4: r0 = velocity()
    //     0xd0d2c4: bl              #0xae9d58  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::velocity
    // 0xd0d2c8: add             SP, SP, #8
    // 0xd0d2cc: ldur            x16, [fp, #-8]
    // 0xd0d2d0: SaveReg r16
    //     0xd0d2d0: str             x16, [SP, #-8]!
    // 0xd0d2d4: SaveReg d0
    //     0xd0d2d4: str             d0, [SP, #-8]!
    // 0xd0d2d8: r0 = createOuterBallisticScrollActivity()
    //     0xd0d2d8: bl              #0xbd0a90  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::createOuterBallisticScrollActivity
    // 0xd0d2dc: add             SP, SP, #0x10
    // 0xd0d2e0: ldur            x16, [fp, #-0x10]
    // 0xd0d2e4: stp             x0, x16, [SP, #-0x10]!
    // 0xd0d2e8: r0 = beginActivity()
    //     0xd0d2e8: bl              #0xbff1c4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::beginActivity
    // 0xd0d2ec: add             SP, SP, #0x10
    // 0xd0d2f0: r0 = Null
    //     0xd0d2f0: mov             x0, NULL
    // 0xd0d2f4: LeaveFrame
    //     0xd0d2f4: mov             SP, fp
    //     0xd0d2f8: ldp             fp, lr, [SP], #0x10
    // 0xd0d2fc: ret
    //     0xd0d2fc: ret             
    // 0xd0d300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0d300: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0d304: b               #0xd0d284
    // 0xd0d308: r9 = _controller
    //     0xd0d308: add             x9, PP, #0x33, lsl #12  ; [pp+0x33140] Field <BallisticScrollActivity._controller@460498029>: late (offset: 0xc)
    //     0xd0d30c: ldr             x9, [x9, #0x140]
    // 0xd0d310: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd0d310: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ delegate(/* No info */) {
    // ** addr: 0xd0e2cc, size: 0x64
    // 0xd0e2cc: EnterFrame
    //     0xd0e2cc: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e2d0: mov             fp, SP
    // 0xd0e2d4: AllocStack(0x8)
    //     0xd0e2d4: sub             SP, SP, #8
    // 0xd0e2d8: ldr             x0, [fp, #0x10]
    // 0xd0e2dc: LoadField: r3 = r0->field_7
    //     0xd0e2dc: ldur            w3, [x0, #7]
    // 0xd0e2e0: DecompressPointer r3
    //     0xd0e2e0: add             x3, x3, HEAP, lsl #32
    // 0xd0e2e4: mov             x0, x3
    // 0xd0e2e8: stur            x3, [fp, #-8]
    // 0xd0e2ec: r2 = Null
    //     0xd0e2ec: mov             x2, NULL
    // 0xd0e2f0: r1 = Null
    //     0xd0e2f0: mov             x1, NULL
    // 0xd0e2f4: r4 = LoadClassIdInstr(r0)
    //     0xd0e2f4: ldur            x4, [x0, #-1]
    //     0xd0e2f8: ubfx            x4, x4, #0xc, #0x14
    // 0xd0e2fc: r17 = -4844
    //     0xd0e2fc: mov             x17, #-0x12ec
    // 0xd0e300: add             x4, x4, x17
    // 0xd0e304: cmp             x4, #1
    // 0xd0e308: b.ls            #0xd0e320
    // 0xd0e30c: r8 = _NestedScrollPosition
    //     0xd0e30c: add             x8, PP, #0x38, lsl #12  ; [pp+0x381e8] Type: _NestedScrollPosition
    //     0xd0e310: ldr             x8, [x8, #0x1e8]
    // 0xd0e314: r3 = Null
    //     0xd0e314: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c0b8] Null
    //     0xd0e318: ldr             x3, [x3, #0xb8]
    // 0xd0e31c: r0 = _NestedScrollPosition()
    //     0xd0e31c: bl              #0x7d2824  ; IsType__NestedScrollPosition_Stub
    // 0xd0e320: ldur            x0, [fp, #-8]
    // 0xd0e324: LeaveFrame
    //     0xd0e324: mov             SP, fp
    //     0xd0e328: ldp             fp, lr, [SP], #0x10
    // 0xd0e32c: ret
    //     0xd0e32c: ret             
  }
}

// class id: 1722, size: 0x18, field offset: 0x14
abstract class _NestedInnerBallisticScrollActivity extends BallisticScrollActivity {

  _ resetActivity(/* No info */) {
    // ** addr: 0xbcf8a8, size: 0xdc
    // 0xbcf8a8: EnterFrame
    //     0xbcf8a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbcf8ac: mov             fp, SP
    // 0xbcf8b0: AllocStack(0x10)
    //     0xbcf8b0: sub             SP, SP, #0x10
    // 0xbcf8b4: CheckStackOverflow
    //     0xbcf8b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbcf8b8: cmp             SP, x16
    //     0xbcf8bc: b.ls            #0xbcf970
    // 0xbcf8c0: ldr             x3, [fp, #0x10]
    // 0xbcf8c4: LoadField: r4 = r3->field_7
    //     0xbcf8c4: ldur            w4, [x3, #7]
    // 0xbcf8c8: DecompressPointer r4
    //     0xbcf8c8: add             x4, x4, HEAP, lsl #32
    // 0xbcf8cc: mov             x0, x4
    // 0xbcf8d0: stur            x4, [fp, #-8]
    // 0xbcf8d4: r2 = Null
    //     0xbcf8d4: mov             x2, NULL
    // 0xbcf8d8: r1 = Null
    //     0xbcf8d8: mov             x1, NULL
    // 0xbcf8dc: r4 = LoadClassIdInstr(r0)
    //     0xbcf8dc: ldur            x4, [x0, #-1]
    //     0xbcf8e0: ubfx            x4, x4, #0xc, #0x14
    // 0xbcf8e4: r17 = -4844
    //     0xbcf8e4: mov             x17, #-0x12ec
    // 0xbcf8e8: add             x4, x4, x17
    // 0xbcf8ec: cmp             x4, #1
    // 0xbcf8f0: b.ls            #0xbcf908
    // 0xbcf8f4: r8 = _NestedScrollPosition
    //     0xbcf8f4: add             x8, PP, #0x38, lsl #12  ; [pp+0x381e8] Type: _NestedScrollPosition
    //     0xbcf8f8: ldr             x8, [x8, #0x1e8]
    // 0xbcf8fc: r3 = Null
    //     0xbcf8fc: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c058] Null
    //     0xbcf900: ldr             x3, [x3, #0x58]
    // 0xbcf904: r0 = _NestedScrollPosition()
    //     0xbcf904: bl              #0x7d2824  ; IsType__NestedScrollPosition_Stub
    // 0xbcf908: ldr             x0, [fp, #0x10]
    // 0xbcf90c: LoadField: r1 = r0->field_13
    //     0xbcf90c: ldur            w1, [x0, #0x13]
    // 0xbcf910: DecompressPointer r1
    //     0xbcf910: add             x1, x1, HEAP, lsl #32
    // 0xbcf914: stur            x1, [fp, #-0x10]
    // 0xbcf918: LoadField: r2 = r0->field_b
    //     0xbcf918: ldur            w2, [x0, #0xb]
    // 0xbcf91c: DecompressPointer r2
    //     0xbcf91c: add             x2, x2, HEAP, lsl #32
    // 0xbcf920: r16 = Sentinel
    //     0xbcf920: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbcf924: cmp             w2, w16
    // 0xbcf928: b.eq            #0xbcf978
    // 0xbcf92c: SaveReg r2
    //     0xbcf92c: str             x2, [SP, #-8]!
    // 0xbcf930: r0 = velocity()
    //     0xbcf930: bl              #0xae9d58  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::velocity
    // 0xbcf934: add             SP, SP, #8
    // 0xbcf938: ldur            x16, [fp, #-0x10]
    // 0xbcf93c: ldur            lr, [fp, #-8]
    // 0xbcf940: stp             lr, x16, [SP, #-0x10]!
    // 0xbcf944: SaveReg d0
    //     0xbcf944: str             d0, [SP, #-8]!
    // 0xbcf948: r0 = createInnerBallisticScrollActivity()
    //     0xbcf948: bl              #0xbcf984  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::createInnerBallisticScrollActivity
    // 0xbcf94c: add             SP, SP, #0x18
    // 0xbcf950: ldur            x16, [fp, #-8]
    // 0xbcf954: stp             x0, x16, [SP, #-0x10]!
    // 0xbcf958: r0 = beginActivity()
    //     0xbcf958: bl              #0xbff1c4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::beginActivity
    // 0xbcf95c: add             SP, SP, #0x10
    // 0xbcf960: r0 = Null
    //     0xbcf960: mov             x0, NULL
    // 0xbcf964: LeaveFrame
    //     0xbcf964: mov             SP, fp
    //     0xbcf968: ldp             fp, lr, [SP], #0x10
    // 0xbcf96c: ret
    //     0xbcf96c: ret             
    // 0xbcf970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcf970: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcf974: b               #0xbcf8c0
    // 0xbcf978: r9 = _controller
    //     0xbcf978: add             x9, PP, #0x33, lsl #12  ; [pp+0x33140] Field <BallisticScrollActivity._controller@460498029>: late (offset: 0xc)
    //     0xbcf97c: ldr             x9, [x9, #0x140]
    // 0xbcf980: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbcf980: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ applyNewDimensions(/* No info */) {
    // ** addr: 0xd0d0fc, size: 0xf4
    // 0xd0d0fc: EnterFrame
    //     0xd0d0fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd0d100: mov             fp, SP
    // 0xd0d104: AllocStack(0x18)
    //     0xd0d104: sub             SP, SP, #0x18
    // 0xd0d108: CheckStackOverflow
    //     0xd0d108: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd0d10c: cmp             SP, x16
    //     0xd0d110: b.ls            #0xd0d1dc
    // 0xd0d114: ldr             x16, [fp, #0x10]
    // 0xd0d118: SaveReg r16
    //     0xd0d118: str             x16, [SP, #-8]!
    // 0xd0d11c: r0 = delegate()
    //     0xd0d11c: bl              #0xd0e22c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedInnerBallisticScrollActivity::delegate
    // 0xd0d120: add             SP, SP, #8
    // 0xd0d124: mov             x4, x0
    // 0xd0d128: ldr             x3, [fp, #0x10]
    // 0xd0d12c: stur            x4, [fp, #-0x18]
    // 0xd0d130: LoadField: r5 = r3->field_13
    //     0xd0d130: ldur            w5, [x3, #0x13]
    // 0xd0d134: DecompressPointer r5
    //     0xd0d134: add             x5, x5, HEAP, lsl #32
    // 0xd0d138: stur            x5, [fp, #-0x10]
    // 0xd0d13c: LoadField: r6 = r3->field_7
    //     0xd0d13c: ldur            w6, [x3, #7]
    // 0xd0d140: DecompressPointer r6
    //     0xd0d140: add             x6, x6, HEAP, lsl #32
    // 0xd0d144: mov             x0, x6
    // 0xd0d148: stur            x6, [fp, #-8]
    // 0xd0d14c: r2 = Null
    //     0xd0d14c: mov             x2, NULL
    // 0xd0d150: r1 = Null
    //     0xd0d150: mov             x1, NULL
    // 0xd0d154: r4 = LoadClassIdInstr(r0)
    //     0xd0d154: ldur            x4, [x0, #-1]
    //     0xd0d158: ubfx            x4, x4, #0xc, #0x14
    // 0xd0d15c: r17 = -4844
    //     0xd0d15c: mov             x17, #-0x12ec
    // 0xd0d160: add             x4, x4, x17
    // 0xd0d164: cmp             x4, #1
    // 0xd0d168: b.ls            #0xd0d180
    // 0xd0d16c: r8 = _NestedScrollPosition
    //     0xd0d16c: add             x8, PP, #0x38, lsl #12  ; [pp+0x381e8] Type: _NestedScrollPosition
    //     0xd0d170: ldr             x8, [x8, #0x1e8]
    // 0xd0d174: r3 = Null
    //     0xd0d174: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c048] Null
    //     0xd0d178: ldr             x3, [x3, #0x48]
    // 0xd0d17c: r0 = _NestedScrollPosition()
    //     0xd0d17c: bl              #0x7d2824  ; IsType__NestedScrollPosition_Stub
    // 0xd0d180: ldr             x0, [fp, #0x10]
    // 0xd0d184: LoadField: r1 = r0->field_b
    //     0xd0d184: ldur            w1, [x0, #0xb]
    // 0xd0d188: DecompressPointer r1
    //     0xd0d188: add             x1, x1, HEAP, lsl #32
    // 0xd0d18c: r16 = Sentinel
    //     0xd0d18c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd0d190: cmp             w1, w16
    // 0xd0d194: b.eq            #0xd0d1e4
    // 0xd0d198: SaveReg r1
    //     0xd0d198: str             x1, [SP, #-8]!
    // 0xd0d19c: r0 = velocity()
    //     0xd0d19c: bl              #0xae9d58  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::velocity
    // 0xd0d1a0: add             SP, SP, #8
    // 0xd0d1a4: ldur            x16, [fp, #-0x10]
    // 0xd0d1a8: ldur            lr, [fp, #-8]
    // 0xd0d1ac: stp             lr, x16, [SP, #-0x10]!
    // 0xd0d1b0: SaveReg d0
    //     0xd0d1b0: str             d0, [SP, #-8]!
    // 0xd0d1b4: r0 = createInnerBallisticScrollActivity()
    //     0xd0d1b4: bl              #0xbcf984  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::createInnerBallisticScrollActivity
    // 0xd0d1b8: add             SP, SP, #0x18
    // 0xd0d1bc: ldur            x16, [fp, #-0x18]
    // 0xd0d1c0: stp             x0, x16, [SP, #-0x10]!
    // 0xd0d1c4: r0 = beginActivity()
    //     0xd0d1c4: bl              #0xbff1c4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::beginActivity
    // 0xd0d1c8: add             SP, SP, #0x10
    // 0xd0d1cc: r0 = Null
    //     0xd0d1cc: mov             x0, NULL
    // 0xd0d1d0: LeaveFrame
    //     0xd0d1d0: mov             SP, fp
    //     0xd0d1d4: ldp             fp, lr, [SP], #0x10
    // 0xd0d1d8: ret
    //     0xd0d1d8: ret             
    // 0xd0d1dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0d1dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0d1e0: b               #0xd0d114
    // 0xd0d1e4: r9 = _controller
    //     0xd0d1e4: add             x9, PP, #0x33, lsl #12  ; [pp+0x33140] Field <BallisticScrollActivity._controller@460498029>: late (offset: 0xc)
    //     0xd0d1e8: ldr             x9, [x9, #0x140]
    // 0xd0d1ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd0d1ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ delegate(/* No info */) {
    // ** addr: 0xd0e22c, size: 0x64
    // 0xd0e22c: EnterFrame
    //     0xd0e22c: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e230: mov             fp, SP
    // 0xd0e234: AllocStack(0x8)
    //     0xd0e234: sub             SP, SP, #8
    // 0xd0e238: ldr             x0, [fp, #0x10]
    // 0xd0e23c: LoadField: r3 = r0->field_7
    //     0xd0e23c: ldur            w3, [x0, #7]
    // 0xd0e240: DecompressPointer r3
    //     0xd0e240: add             x3, x3, HEAP, lsl #32
    // 0xd0e244: mov             x0, x3
    // 0xd0e248: stur            x3, [fp, #-8]
    // 0xd0e24c: r2 = Null
    //     0xd0e24c: mov             x2, NULL
    // 0xd0e250: r1 = Null
    //     0xd0e250: mov             x1, NULL
    // 0xd0e254: r4 = LoadClassIdInstr(r0)
    //     0xd0e254: ldur            x4, [x0, #-1]
    //     0xd0e258: ubfx            x4, x4, #0xc, #0x14
    // 0xd0e25c: r17 = -4844
    //     0xd0e25c: mov             x17, #-0x12ec
    // 0xd0e260: add             x4, x4, x17
    // 0xd0e264: cmp             x4, #1
    // 0xd0e268: b.ls            #0xd0e280
    // 0xd0e26c: r8 = _NestedScrollPosition
    //     0xd0e26c: add             x8, PP, #0x38, lsl #12  ; [pp+0x381e8] Type: _NestedScrollPosition
    //     0xd0e270: ldr             x8, [x8, #0x1e8]
    // 0xd0e274: r3 = Null
    //     0xd0e274: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c068] Null
    //     0xd0e278: ldr             x3, [x3, #0x68]
    // 0xd0e27c: r0 = _NestedScrollPosition()
    //     0xd0e27c: bl              #0x7d2824  ; IsType__NestedScrollPosition_Stub
    // 0xd0e280: ldur            x0, [fp, #-8]
    // 0xd0e284: LeaveFrame
    //     0xd0e284: mov             SP, fp
    //     0xd0e288: ldp             fp, lr, [SP], #0x10
    // 0xd0e28c: ret
    //     0xd0e28c: ret             
  }
}

// class id: 1723, size: 0x18, field offset: 0x18
class _ExtendedNestedInnerBallisticScrollActivity extends _NestedInnerBallisticScrollActivity {

  _ applyMoveTo(/* No info */) {
    // ** addr: 0xd0cc68, size: 0xbc
    // 0xd0cc68: EnterFrame
    //     0xd0cc68: stp             fp, lr, [SP, #-0x10]!
    //     0xd0cc6c: mov             fp, SP
    // 0xd0cc70: AllocStack(0x8)
    //     0xd0cc70: sub             SP, SP, #8
    // 0xd0cc74: CheckStackOverflow
    //     0xd0cc74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd0cc78: cmp             SP, x16
    //     0xd0cc7c: b.ls            #0xd0cd1c
    // 0xd0cc80: ldr             x3, [fp, #0x18]
    // 0xd0cc84: LoadField: r4 = r3->field_7
    //     0xd0cc84: ldur            w4, [x3, #7]
    // 0xd0cc88: DecompressPointer r4
    //     0xd0cc88: add             x4, x4, HEAP, lsl #32
    // 0xd0cc8c: mov             x0, x4
    // 0xd0cc90: stur            x4, [fp, #-8]
    // 0xd0cc94: r2 = Null
    //     0xd0cc94: mov             x2, NULL
    // 0xd0cc98: r1 = Null
    //     0xd0cc98: mov             x1, NULL
    // 0xd0cc9c: r4 = LoadClassIdInstr(r0)
    //     0xd0cc9c: ldur            x4, [x0, #-1]
    //     0xd0cca0: ubfx            x4, x4, #0xc, #0x14
    // 0xd0cca4: r17 = -4844
    //     0xd0cca4: mov             x17, #-0x12ec
    // 0xd0cca8: add             x4, x4, x17
    // 0xd0ccac: cmp             x4, #1
    // 0xd0ccb0: b.ls            #0xd0ccc8
    // 0xd0ccb4: r8 = _NestedScrollPosition
    //     0xd0ccb4: add             x8, PP, #0x38, lsl #12  ; [pp+0x381e8] Type: _NestedScrollPosition
    //     0xd0ccb8: ldr             x8, [x8, #0x1e8]
    // 0xd0ccbc: r3 = Null
    //     0xd0ccbc: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c080] Null
    //     0xd0ccc0: ldr             x3, [x3, #0x80]
    // 0xd0ccc4: r0 = _NestedScrollPosition()
    //     0xd0ccc4: bl              #0x7d2824  ; IsType__NestedScrollPosition_Stub
    // 0xd0ccc8: ldr             x0, [fp, #0x18]
    // 0xd0cccc: LoadField: r1 = r0->field_13
    //     0xd0cccc: ldur            w1, [x0, #0x13]
    // 0xd0ccd0: DecompressPointer r1
    //     0xd0ccd0: add             x1, x1, HEAP, lsl #32
    // 0xd0ccd4: SaveReg r1
    //     0xd0ccd4: str             x1, [SP, #-8]!
    // 0xd0ccd8: ldr             d0, [fp, #0x10]
    // 0xd0ccdc: SaveReg d0
    //     0xd0ccdc: str             d0, [SP, #-8]!
    // 0xd0cce0: ldur            x16, [fp, #-8]
    // 0xd0cce4: SaveReg r16
    //     0xd0cce4: str             x16, [SP, #-8]!
    // 0xd0cce8: r0 = nestOffset()
    //     0xd0cce8: bl              #0xc51994  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::nestOffset
    // 0xd0ccec: add             SP, SP, #0x18
    // 0xd0ccf0: ldur            x16, [fp, #-8]
    // 0xd0ccf4: SaveReg r16
    //     0xd0ccf4: str             x16, [SP, #-8]!
    // 0xd0ccf8: SaveReg d0
    //     0xd0ccf8: str             d0, [SP, #-8]!
    // 0xd0ccfc: r0 = setPixels()
    //     0xd0ccfc: bl              #0xc36880  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::setPixels
    // 0xd0cd00: add             SP, SP, #0x10
    // 0xd0cd04: SaveReg d0
    //     0xd0cd04: str             d0, [SP, #-8]!
    // 0xd0cd08: r0 = DoubleEx.isZero()
    //     0xd0cd08: bl              #0xd0cd24  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ::DoubleEx.isZero
    // 0xd0cd0c: add             SP, SP, #8
    // 0xd0cd10: LeaveFrame
    //     0xd0cd10: mov             SP, fp
    //     0xd0cd14: ldp             fp, lr, [SP], #0x10
    // 0xd0cd18: ret
    //     0xd0cd18: ret             
    // 0xd0cd1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0cd1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0cd20: b               #0xd0cc80
  }
}

// class id: 2574, size: 0x58, field offset: 0x58
class _ExtendedRenderSliverFillRemainingWithScrollable extends RenderSliverFillRemainingWithScrollable {
}

// class id: 3383, size: 0x20, field offset: 0x14
class ExtendedNestedScrollViewState extends State<ExtendedNestedScrollView> {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x79ea98, size: 0xa8
    // 0x79ea98: EnterFrame
    //     0x79ea98: stp             fp, lr, [SP, #-0x10]!
    //     0x79ea9c: mov             fp, SP
    // 0x79eaa0: ldr             x0, [fp, #0x10]
    // 0x79eaa4: r2 = Null
    //     0x79eaa4: mov             x2, NULL
    // 0x79eaa8: r1 = Null
    //     0x79eaa8: mov             x1, NULL
    // 0x79eaac: r4 = 59
    //     0x79eaac: mov             x4, #0x3b
    // 0x79eab0: branchIfSmi(r0, 0x79eabc)
    //     0x79eab0: tbz             w0, #0, #0x79eabc
    // 0x79eab4: r4 = LoadClassIdInstr(r0)
    //     0x79eab4: ldur            x4, [x0, #-1]
    //     0x79eab8: ubfx            x4, x4, #0xc, #0x14
    // 0x79eabc: r17 = 4205
    //     0x79eabc: mov             x17, #0x106d
    // 0x79eac0: cmp             x4, x17
    // 0x79eac4: b.eq            #0x79eadc
    // 0x79eac8: r8 = ExtendedNestedScrollView
    //     0x79eac8: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2efb8] Type: ExtendedNestedScrollView
    //     0x79eacc: ldr             x8, [x8, #0xfb8]
    // 0x79ead0: r3 = Null
    //     0x79ead0: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2efc0] Null
    //     0x79ead4: ldr             x3, [x3, #0xfc0]
    // 0x79ead8: r0 = ExtendedNestedScrollView()
    //     0x79ead8: bl              #0x79eb40  ; IsType_ExtendedNestedScrollView_Stub
    // 0x79eadc: ldr             x3, [fp, #0x18]
    // 0x79eae0: LoadField: r2 = r3->field_7
    //     0x79eae0: ldur            w2, [x3, #7]
    // 0x79eae4: DecompressPointer r2
    //     0x79eae4: add             x2, x2, HEAP, lsl #32
    // 0x79eae8: ldr             x0, [fp, #0x10]
    // 0x79eaec: r1 = Null
    //     0x79eaec: mov             x1, NULL
    // 0x79eaf0: cmp             w2, NULL
    // 0x79eaf4: b.eq            #0x79eb18
    // 0x79eaf8: LoadField: r4 = r2->field_17
    //     0x79eaf8: ldur            w4, [x2, #0x17]
    // 0x79eafc: DecompressPointer r4
    //     0x79eafc: add             x4, x4, HEAP, lsl #32
    // 0x79eb00: r8 = X0 bound StatefulWidget
    //     0x79eb00: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x79eb04: ldr             x8, [x8, #0x858]
    // 0x79eb08: LoadField: r9 = r4->field_7
    //     0x79eb08: ldur            x9, [x4, #7]
    // 0x79eb0c: r3 = Null
    //     0x79eb0c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2efd0] Null
    //     0x79eb10: ldr             x3, [x3, #0xfd0]
    // 0x79eb14: blr             x9
    // 0x79eb18: ldr             x1, [fp, #0x18]
    // 0x79eb1c: LoadField: r2 = r1->field_b
    //     0x79eb1c: ldur            w2, [x1, #0xb]
    // 0x79eb20: DecompressPointer r2
    //     0x79eb20: add             x2, x2, HEAP, lsl #32
    // 0x79eb24: cmp             w2, NULL
    // 0x79eb28: b.eq            #0x79eb3c
    // 0x79eb2c: r0 = Null
    //     0x79eb2c: mov             x0, NULL
    // 0x79eb30: LeaveFrame
    //     0x79eb30: mov             SP, fp
    //     0x79eb34: ldp             fp, lr, [SP], #0x10
    // 0x79eb38: ret
    //     0x79eb38: ret             
    // 0x79eb3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79eb3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x830b98, size: 0x118
    // 0x830b98: EnterFrame
    //     0x830b98: stp             fp, lr, [SP, #-0x10]!
    //     0x830b9c: mov             fp, SP
    // 0x830ba0: AllocStack(0x10)
    //     0x830ba0: sub             SP, SP, #0x10
    // 0x830ba4: CheckStackOverflow
    //     0x830ba4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x830ba8: cmp             SP, x16
    //     0x830bac: b.ls            #0x830ca0
    // 0x830bb0: r1 = 2
    //     0x830bb0: mov             x1, #2
    // 0x830bb4: r0 = AllocateContext()
    //     0x830bb4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x830bb8: mov             x1, x0
    // 0x830bbc: ldr             x0, [fp, #0x18]
    // 0x830bc0: stur            x1, [fp, #-8]
    // 0x830bc4: StoreField: r1->field_f = r0
    //     0x830bc4: stur            w0, [x1, #0xf]
    // 0x830bc8: LoadField: r2 = r0->field_b
    //     0x830bc8: ldur            w2, [x0, #0xb]
    // 0x830bcc: DecompressPointer r2
    //     0x830bcc: add             x2, x2, HEAP, lsl #32
    // 0x830bd0: cmp             w2, NULL
    // 0x830bd4: b.eq            #0x830ca8
    // 0x830bd8: LoadField: r3 = r2->field_1f
    //     0x830bd8: ldur            w3, [x2, #0x1f]
    // 0x830bdc: DecompressPointer r3
    //     0x830bdc: add             x3, x3, HEAP, lsl #32
    // 0x830be0: cmp             w3, NULL
    // 0x830be4: b.ne            #0x830bf0
    // 0x830be8: r0 = Null
    //     0x830be8: mov             x0, NULL
    // 0x830bec: b               #0x830c04
    // 0x830bf0: r16 = Instance_ClampingScrollPhysics
    //     0x830bf0: add             x16, PP, #0x20, lsl #12  ; [pp+0x20200] Obj!ClampingScrollPhysics@b4fd31
    //     0x830bf4: ldr             x16, [x16, #0x200]
    // 0x830bf8: stp             x16, x3, [SP, #-0x10]!
    // 0x830bfc: r0 = applyTo()
    //     0x830bfc: bl              #0xc3b4ec  ; [package:flutter/src/widgets/scroll_physics.dart] ClampingScrollPhysics::applyTo
    // 0x830c00: add             SP, SP, #0x10
    // 0x830c04: cmp             w0, NULL
    // 0x830c08: b.ne            #0x830c28
    // 0x830c0c: ldr             x3, [fp, #0x18]
    // 0x830c10: LoadField: r0 = r3->field_b
    //     0x830c10: ldur            w0, [x3, #0xb]
    // 0x830c14: DecompressPointer r0
    //     0x830c14: add             x0, x0, HEAP, lsl #32
    // 0x830c18: cmp             w0, NULL
    // 0x830c1c: b.eq            #0x830cac
    // 0x830c20: r0 = Null
    //     0x830c20: mov             x0, NULL
    // 0x830c24: b               #0x830c2c
    // 0x830c28: ldr             x3, [fp, #0x18]
    // 0x830c2c: cmp             w0, NULL
    // 0x830c30: b.ne            #0x830c3c
    // 0x830c34: r0 = Instance_ClampingScrollPhysics
    //     0x830c34: add             x0, PP, #0x20, lsl #12  ; [pp+0x20200] Obj!ClampingScrollPhysics@b4fd31
    //     0x830c38: ldr             x0, [x0, #0x200]
    // 0x830c3c: ldur            x2, [fp, #-8]
    // 0x830c40: StoreField: r2->field_13 = r0
    //     0x830c40: stur            w0, [x2, #0x13]
    //     0x830c44: ldurb           w16, [x2, #-1]
    //     0x830c48: ldurb           w17, [x0, #-1]
    //     0x830c4c: and             x16, x17, x16, lsr #2
    //     0x830c50: tst             x16, HEAP, lsr #32
    //     0x830c54: b.eq            #0x830c5c
    //     0x830c58: bl              #0xd6828c
    // 0x830c5c: r1 = Function '<anonymous closure>':.
    //     0x830c5c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2ee50] AnonymousClosure: (0x830cc8), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ExtendedNestedScrollViewState::build (0x830b98)
    //     0x830c60: ldr             x1, [x1, #0xe50]
    // 0x830c64: r0 = AllocateClosure()
    //     0x830c64: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x830c68: stur            x0, [fp, #-8]
    // 0x830c6c: r0 = Builder()
    //     0x830c6c: bl              #0x830cbc  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0x830c70: mov             x1, x0
    // 0x830c74: ldur            x0, [fp, #-8]
    // 0x830c78: stur            x1, [fp, #-0x10]
    // 0x830c7c: StoreField: r1->field_b = r0
    //     0x830c7c: stur            w0, [x1, #0xb]
    // 0x830c80: r0 = _InheritedNestedScrollView()
    //     0x830c80: bl              #0x830cb0  ; Allocate_InheritedNestedScrollViewStub -> _InheritedNestedScrollView (size=0x14)
    // 0x830c84: ldr             x1, [fp, #0x18]
    // 0x830c88: StoreField: r0->field_f = r1
    //     0x830c88: stur            w1, [x0, #0xf]
    // 0x830c8c: ldur            x1, [fp, #-0x10]
    // 0x830c90: StoreField: r0->field_b = r1
    //     0x830c90: stur            w1, [x0, #0xb]
    // 0x830c94: LeaveFrame
    //     0x830c94: mov             SP, fp
    //     0x830c98: ldp             fp, lr, [SP], #0x10
    // 0x830c9c: ret
    //     0x830c9c: ret             
    // 0x830ca0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x830ca0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x830ca4: b               #0x830bb0
    // 0x830ca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x830ca8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x830cac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x830cac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] _NestedScrollViewCustomScrollView <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x830cc8, size: 0x220
    // 0x830cc8: EnterFrame
    //     0x830cc8: stp             fp, lr, [SP, #-0x10]!
    //     0x830ccc: mov             fp, SP
    // 0x830cd0: AllocStack(0x30)
    //     0x830cd0: sub             SP, SP, #0x30
    // 0x830cd4: SetupParameters()
    //     0x830cd4: ldr             x0, [fp, #0x18]
    //     0x830cd8: ldur            w1, [x0, #0x17]
    //     0x830cdc: add             x1, x1, HEAP, lsl #32
    //     0x830ce0: stur            x1, [fp, #-0x10]
    // 0x830ce4: CheckStackOverflow
    //     0x830ce4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x830ce8: cmp             SP, x16
    //     0x830cec: b.ls            #0x830ebc
    // 0x830cf0: LoadField: r0 = r1->field_f
    //     0x830cf0: ldur            w0, [x1, #0xf]
    // 0x830cf4: DecompressPointer r0
    //     0x830cf4: add             x0, x0, HEAP, lsl #32
    // 0x830cf8: stur            x0, [fp, #-8]
    // 0x830cfc: LoadField: r2 = r0->field_17
    //     0x830cfc: ldur            w2, [x0, #0x17]
    // 0x830d00: DecompressPointer r2
    //     0x830d00: add             x2, x2, HEAP, lsl #32
    // 0x830d04: cmp             w2, NULL
    // 0x830d08: b.eq            #0x830ec4
    // 0x830d0c: SaveReg r2
    //     0x830d0c: str             x2, [SP, #-8]!
    // 0x830d10: r0 = hasScrolledBody()
    //     0x830d10: bl              #0x831074  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::hasScrolledBody
    // 0x830d14: add             SP, SP, #8
    // 0x830d18: mov             x1, x0
    // 0x830d1c: ldur            x0, [fp, #-8]
    // 0x830d20: StoreField: r0->field_1b = r1
    //     0x830d20: stur            w1, [x0, #0x1b]
    // 0x830d24: ldur            x0, [fp, #-0x10]
    // 0x830d28: LoadField: r1 = r0->field_f
    //     0x830d28: ldur            w1, [x0, #0xf]
    // 0x830d2c: DecompressPointer r1
    //     0x830d2c: add             x1, x1, HEAP, lsl #32
    // 0x830d30: LoadField: r2 = r1->field_b
    //     0x830d30: ldur            w2, [x1, #0xb]
    // 0x830d34: DecompressPointer r2
    //     0x830d34: add             x2, x2, HEAP, lsl #32
    // 0x830d38: cmp             w2, NULL
    // 0x830d3c: b.eq            #0x830ec8
    // 0x830d40: ldr             x16, [fp, #0x10]
    // 0x830d44: SaveReg r16
    //     0x830d44: str             x16, [SP, #-8]!
    // 0x830d48: r0 = of()
    //     0x830d48: bl              #0x79d574  ; [package:flutter/src/widgets/scroll_configuration.dart] ScrollConfiguration::of
    // 0x830d4c: add             SP, SP, #8
    // 0x830d50: r16 = false
    //     0x830d50: add             x16, NULL, #0x30  ; false
    // 0x830d54: stp             x16, x0, [SP, #-0x10]!
    // 0x830d58: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x830d58: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x830d5c: r0 = copyWith()
    //     0x830d5c: bl              #0x82f864  ; [package:flutter/src/widgets/scroll_configuration.dart] ScrollBehavior::copyWith
    // 0x830d60: add             SP, SP, #0x10
    // 0x830d64: mov             x1, x0
    // 0x830d68: ldur            x0, [fp, #-0x10]
    // 0x830d6c: stur            x1, [fp, #-0x20]
    // 0x830d70: LoadField: r2 = r0->field_f
    //     0x830d70: ldur            w2, [x0, #0xf]
    // 0x830d74: DecompressPointer r2
    //     0x830d74: add             x2, x2, HEAP, lsl #32
    // 0x830d78: LoadField: r3 = r2->field_17
    //     0x830d78: ldur            w3, [x2, #0x17]
    // 0x830d7c: DecompressPointer r3
    //     0x830d7c: add             x3, x3, HEAP, lsl #32
    // 0x830d80: cmp             w3, NULL
    // 0x830d84: b.eq            #0x830ecc
    // 0x830d88: LoadField: r4 = r3->field_17
    //     0x830d88: ldur            w4, [x3, #0x17]
    // 0x830d8c: DecompressPointer r4
    //     0x830d8c: add             x4, x4, HEAP, lsl #32
    // 0x830d90: r16 = Sentinel
    //     0x830d90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x830d94: cmp             w4, w16
    // 0x830d98: b.eq            #0x830ed0
    // 0x830d9c: stur            x4, [fp, #-0x18]
    // 0x830da0: LoadField: r5 = r2->field_b
    //     0x830da0: ldur            w5, [x2, #0xb]
    // 0x830da4: DecompressPointer r5
    //     0x830da4: add             x5, x5, HEAP, lsl #32
    // 0x830da8: stur            x5, [fp, #-8]
    // 0x830dac: cmp             w5, NULL
    // 0x830db0: b.eq            #0x830edc
    // 0x830db4: SaveReg r3
    //     0x830db4: str             x3, [SP, #-8]!
    // 0x830db8: r0 = _innerController()
    //     0x830db8: bl              #0x830ffc  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerController
    // 0x830dbc: add             SP, SP, #8
    // 0x830dc0: mov             x1, x0
    // 0x830dc4: ldur            x0, [fp, #-0x10]
    // 0x830dc8: LoadField: r2 = r0->field_f
    //     0x830dc8: ldur            w2, [x0, #0xf]
    // 0x830dcc: DecompressPointer r2
    //     0x830dcc: add             x2, x2, HEAP, lsl #32
    // 0x830dd0: LoadField: r3 = r2->field_1b
    //     0x830dd0: ldur            w3, [x2, #0x1b]
    // 0x830dd4: DecompressPointer r3
    //     0x830dd4: add             x3, x3, HEAP, lsl #32
    // 0x830dd8: cmp             w3, NULL
    // 0x830ddc: b.eq            #0x830ee0
    // 0x830de0: ldur            x16, [fp, #-8]
    // 0x830de4: ldr             lr, [fp, #0x10]
    // 0x830de8: stp             lr, x16, [SP, #-0x10]!
    // 0x830dec: stp             x3, x1, [SP, #-0x10]!
    // 0x830df0: r0 = _buildSlivers()
    //     0x830df0: bl              #0x830ef4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ExtendedNestedScrollView::_buildSlivers
    // 0x830df4: add             SP, SP, #0x20
    // 0x830df8: mov             x1, x0
    // 0x830dfc: ldur            x0, [fp, #-0x10]
    // 0x830e00: stur            x1, [fp, #-0x30]
    // 0x830e04: LoadField: r2 = r0->field_f
    //     0x830e04: ldur            w2, [x0, #0xf]
    // 0x830e08: DecompressPointer r2
    //     0x830e08: add             x2, x2, HEAP, lsl #32
    // 0x830e0c: LoadField: r3 = r2->field_13
    //     0x830e0c: ldur            w3, [x2, #0x13]
    // 0x830e10: DecompressPointer r3
    //     0x830e10: add             x3, x3, HEAP, lsl #32
    // 0x830e14: stur            x3, [fp, #-0x28]
    // 0x830e18: LoadField: r4 = r2->field_b
    //     0x830e18: ldur            w4, [x2, #0xb]
    // 0x830e1c: DecompressPointer r4
    //     0x830e1c: add             x4, x4, HEAP, lsl #32
    // 0x830e20: cmp             w4, NULL
    // 0x830e24: b.eq            #0x830ee4
    // 0x830e28: LoadField: r2 = r0->field_13
    //     0x830e28: ldur            w2, [x0, #0x13]
    // 0x830e2c: DecompressPointer r2
    //     0x830e2c: add             x2, x2, HEAP, lsl #32
    // 0x830e30: stur            x2, [fp, #-8]
    // 0x830e34: r0 = _NestedScrollViewCustomScrollView()
    //     0x830e34: bl              #0x830ee8  ; Allocate_NestedScrollViewCustomScrollViewStub -> _NestedScrollViewCustomScrollView (size=0x54)
    // 0x830e38: ldur            x1, [fp, #-0x28]
    // 0x830e3c: StoreField: r0->field_4f = r1
    //     0x830e3c: stur            w1, [x0, #0x4f]
    // 0x830e40: ldur            x1, [fp, #-0x30]
    // 0x830e44: StoreField: r0->field_4b = r1
    //     0x830e44: stur            w1, [x0, #0x4b]
    // 0x830e48: r1 = Instance_Axis
    //     0x830e48: add             x1, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x830e4c: ldr             x1, [x1, #0xf00]
    // 0x830e50: StoreField: r0->field_b = r1
    //     0x830e50: stur            w1, [x0, #0xb]
    // 0x830e54: r1 = false
    //     0x830e54: add             x1, NULL, #0x30  ; false
    // 0x830e58: StoreField: r0->field_f = r1
    //     0x830e58: stur            w1, [x0, #0xf]
    // 0x830e5c: ldur            x2, [fp, #-0x18]
    // 0x830e60: StoreField: r0->field_13 = r2
    //     0x830e60: stur            w2, [x0, #0x13]
    // 0x830e64: ldur            x2, [fp, #-0x20]
    // 0x830e68: StoreField: r0->field_1f = r2
    //     0x830e68: stur            w2, [x0, #0x1f]
    // 0x830e6c: StoreField: r0->field_23 = r1
    //     0x830e6c: stur            w1, [x0, #0x23]
    // 0x830e70: d0 = 0.000000
    //     0x830e70: eor             v0.16b, v0.16b, v0.16b
    // 0x830e74: StoreField: r0->field_2b = d0
    //     0x830e74: stur            d0, [x0, #0x2b]
    // 0x830e78: r1 = Instance_DragStartBehavior
    //     0x830e78: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x830e7c: ldr             x1, [x1, #0xf88]
    // 0x830e80: StoreField: r0->field_3b = r1
    //     0x830e80: stur            w1, [x0, #0x3b]
    // 0x830e84: r1 = Instance_ScrollViewKeyboardDismissBehavior
    //     0x830e84: add             x1, PP, #0x20, lsl #12  ; [pp+0x20210] Obj!ScrollViewKeyboardDismissBehavior@b63571
    //     0x830e88: ldr             x1, [x1, #0x210]
    // 0x830e8c: StoreField: r0->field_3f = r1
    //     0x830e8c: stur            w1, [x0, #0x3f]
    // 0x830e90: r1 = Instance_Clip
    //     0x830e90: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x830e94: ldr             x1, [x1, #0x678]
    // 0x830e98: StoreField: r0->field_47 = r1
    //     0x830e98: stur            w1, [x0, #0x47]
    // 0x830e9c: ldur            x1, [fp, #-8]
    // 0x830ea0: cmp             w1, NULL
    // 0x830ea4: b.ne            #0x830eac
    // 0x830ea8: r1 = Null
    //     0x830ea8: mov             x1, NULL
    // 0x830eac: StoreField: r0->field_1b = r1
    //     0x830eac: stur            w1, [x0, #0x1b]
    // 0x830eb0: LeaveFrame
    //     0x830eb0: mov             SP, fp
    //     0x830eb4: ldp             fp, lr, [SP], #0x10
    // 0x830eb8: ret
    //     0x830eb8: ret             
    // 0x830ebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x830ebc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x830ec0: b               #0x830cf0
    // 0x830ec4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x830ec4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x830ec8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x830ec8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x830ecc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x830ecc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x830ed0: r9 = _outerController
    //     0x830ed0: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2ee58] Field <_NestedScrollCoordinator@454231548._outerController@454231548>: late (offset: 0x18)
    //     0x830ed4: ldr             x9, [x9, #0xe58]
    // 0x830ed8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x830ed8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x830edc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x830edc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x830ee0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x830ee0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x830ee4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x830ee4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d63e4, size: 0xb4
    // 0x9d63e4: EnterFrame
    //     0x9d63e4: stp             fp, lr, [SP, #-0x10]!
    //     0x9d63e8: mov             fp, SP
    // 0x9d63ec: AllocStack(0x10)
    //     0x9d63ec: sub             SP, SP, #0x10
    // 0x9d63f0: CheckStackOverflow
    //     0x9d63f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d63f4: cmp             SP, x16
    //     0x9d63f8: b.ls            #0x9d648c
    // 0x9d63fc: ldr             x0, [fp, #0x10]
    // 0x9d6400: LoadField: r1 = r0->field_b
    //     0x9d6400: ldur            w1, [x0, #0xb]
    // 0x9d6404: DecompressPointer r1
    //     0x9d6404: add             x1, x1, HEAP, lsl #32
    // 0x9d6408: cmp             w1, NULL
    // 0x9d640c: b.eq            #0x9d6494
    // 0x9d6410: r1 = 1
    //     0x9d6410: mov             x1, #1
    // 0x9d6414: r0 = AllocateContext()
    //     0x9d6414: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d6418: mov             x1, x0
    // 0x9d641c: ldr             x0, [fp, #0x10]
    // 0x9d6420: StoreField: r1->field_f = r0
    //     0x9d6420: stur            w0, [x1, #0xf]
    // 0x9d6424: mov             x2, x1
    // 0x9d6428: r1 = Function '_handleHasScrolledBodyChanged@454231548':.
    //     0x9d6428: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2efe8] AnonymousClosure: (0x9d66f0), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ExtendedNestedScrollViewState::_handleHasScrolledBodyChanged (0x9d6738)
    //     0x9d642c: ldr             x1, [x1, #0xfe8]
    // 0x9d6430: r0 = AllocateClosure()
    //     0x9d6430: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d6434: stur            x0, [fp, #-8]
    // 0x9d6438: r0 = _ExtendedNestedScrollCoordinator()
    //     0x9d6438: bl              #0x9d66e4  ; Allocate_ExtendedNestedScrollCoordinatorStub -> _ExtendedNestedScrollCoordinator (size=0x34)
    // 0x9d643c: stur            x0, [fp, #-0x10]
    // 0x9d6440: ldr             x16, [fp, #0x10]
    // 0x9d6444: stp             x16, x0, [SP, #-0x10]!
    // 0x9d6448: ldur            x16, [fp, #-8]
    // 0x9d644c: SaveReg r16
    //     0x9d644c: str             x16, [SP, #-8]!
    // 0x9d6450: r0 = _ExtendedNestedScrollCoordinator()
    //     0x9d6450: bl              #0x9d6498  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_ExtendedNestedScrollCoordinator
    // 0x9d6454: add             SP, SP, #0x18
    // 0x9d6458: ldur            x0, [fp, #-0x10]
    // 0x9d645c: ldr             x1, [fp, #0x10]
    // 0x9d6460: StoreField: r1->field_17 = r0
    //     0x9d6460: stur            w0, [x1, #0x17]
    //     0x9d6464: ldurb           w16, [x1, #-1]
    //     0x9d6468: ldurb           w17, [x0, #-1]
    //     0x9d646c: and             x16, x17, x16, lsr #2
    //     0x9d6470: tst             x16, HEAP, lsr #32
    //     0x9d6474: b.eq            #0x9d647c
    //     0x9d6478: bl              #0xd6826c
    // 0x9d647c: r0 = Null
    //     0x9d647c: mov             x0, NULL
    // 0x9d6480: LeaveFrame
    //     0x9d6480: mov             SP, fp
    //     0x9d6484: ldp             fp, lr, [SP], #0x10
    // 0x9d6488: ret
    //     0x9d6488: ret             
    // 0x9d648c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d648c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d6490: b               #0x9d63fc
    // 0x9d6494: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d6494: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleHasScrolledBodyChanged(dynamic) {
    // ** addr: 0x9d66f0, size: 0x48
    // 0x9d66f0: EnterFrame
    //     0x9d66f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9d66f4: mov             fp, SP
    // 0x9d66f8: ldr             x0, [fp, #0x10]
    // 0x9d66fc: LoadField: r1 = r0->field_17
    //     0x9d66fc: ldur            w1, [x0, #0x17]
    // 0x9d6700: DecompressPointer r1
    //     0x9d6700: add             x1, x1, HEAP, lsl #32
    // 0x9d6704: CheckStackOverflow
    //     0x9d6704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d6708: cmp             SP, x16
    //     0x9d670c: b.ls            #0x9d6730
    // 0x9d6710: LoadField: r0 = r1->field_f
    //     0x9d6710: ldur            w0, [x1, #0xf]
    // 0x9d6714: DecompressPointer r0
    //     0x9d6714: add             x0, x0, HEAP, lsl #32
    // 0x9d6718: SaveReg r0
    //     0x9d6718: str             x0, [SP, #-8]!
    // 0x9d671c: r0 = _handleHasScrolledBodyChanged()
    //     0x9d671c: bl              #0x9d6738  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ExtendedNestedScrollViewState::_handleHasScrolledBodyChanged
    // 0x9d6720: add             SP, SP, #8
    // 0x9d6724: LeaveFrame
    //     0x9d6724: mov             SP, fp
    //     0x9d6728: ldp             fp, lr, [SP], #0x10
    // 0x9d672c: ret
    //     0x9d672c: ret             
    // 0x9d6730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d6730: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d6734: b               #0x9d6710
  }
  _ _handleHasScrolledBodyChanged(/* No info */) {
    // ** addr: 0x9d6738, size: 0xa8
    // 0x9d6738: EnterFrame
    //     0x9d6738: stp             fp, lr, [SP, #-0x10]!
    //     0x9d673c: mov             fp, SP
    // 0x9d6740: CheckStackOverflow
    //     0x9d6740: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d6744: cmp             SP, x16
    //     0x9d6748: b.ls            #0x9d67d4
    // 0x9d674c: ldr             x0, [fp, #0x10]
    // 0x9d6750: LoadField: r1 = r0->field_f
    //     0x9d6750: ldur            w1, [x0, #0xf]
    // 0x9d6754: DecompressPointer r1
    //     0x9d6754: add             x1, x1, HEAP, lsl #32
    // 0x9d6758: cmp             w1, NULL
    // 0x9d675c: b.ne            #0x9d6770
    // 0x9d6760: r0 = Null
    //     0x9d6760: mov             x0, NULL
    // 0x9d6764: LeaveFrame
    //     0x9d6764: mov             SP, fp
    //     0x9d6768: ldp             fp, lr, [SP], #0x10
    // 0x9d676c: ret
    //     0x9d676c: ret             
    // 0x9d6770: LoadField: r1 = r0->field_17
    //     0x9d6770: ldur            w1, [x0, #0x17]
    // 0x9d6774: DecompressPointer r1
    //     0x9d6774: add             x1, x1, HEAP, lsl #32
    // 0x9d6778: cmp             w1, NULL
    // 0x9d677c: b.eq            #0x9d67dc
    // 0x9d6780: SaveReg r1
    //     0x9d6780: str             x1, [SP, #-8]!
    // 0x9d6784: r0 = hasScrolledBody()
    //     0x9d6784: bl              #0x831074  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::hasScrolledBody
    // 0x9d6788: add             SP, SP, #8
    // 0x9d678c: mov             x1, x0
    // 0x9d6790: ldr             x0, [fp, #0x10]
    // 0x9d6794: LoadField: r2 = r0->field_1b
    //     0x9d6794: ldur            w2, [x0, #0x1b]
    // 0x9d6798: DecompressPointer r2
    //     0x9d6798: add             x2, x2, HEAP, lsl #32
    // 0x9d679c: cmp             w2, w1
    // 0x9d67a0: b.eq            #0x9d67c4
    // 0x9d67a4: r1 = Function '<anonymous closure>':.
    //     0x9d67a4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2eff0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x9d67a8: ldr             x1, [x1, #0xff0]
    // 0x9d67ac: r2 = Null
    //     0x9d67ac: mov             x2, NULL
    // 0x9d67b0: r0 = AllocateClosure()
    //     0x9d67b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d67b4: ldr             x16, [fp, #0x10]
    // 0x9d67b8: stp             x0, x16, [SP, #-0x10]!
    // 0x9d67bc: r0 = setState()
    //     0x9d67bc: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9d67c0: add             SP, SP, #0x10
    // 0x9d67c4: r0 = Null
    //     0x9d67c4: mov             x0, NULL
    // 0x9d67c8: LeaveFrame
    //     0x9d67c8: mov             SP, fp
    //     0x9d67cc: ldp             fp, lr, [SP], #0x10
    // 0x9d67d0: ret
    //     0x9d67d0: ret             
    // 0x9d67d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d67d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d67d8: b               #0x9d674c
    // 0x9d67dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d67dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a288, size: 0x18
    // 0xa4a288: r4 = 7
    //     0xa4a288: mov             x4, #7
    // 0xa4a28c: r1 = Function 'dispose':.
    //     0xa4a28c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c078] AnonymousClosure: (0xa4a2a0), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ExtendedNestedScrollViewState::dispose (0xa4f690)
    //     0xa4a290: ldr             x1, [x17, #0x78]
    // 0xa4a294: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a294: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a298: LoadField: r0 = r24->field_17
    //     0xa4a298: ldur            x0, [x24, #0x17]
    // 0xa4a29c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a2a0, size: 0x48
    // 0xa4a2a0: EnterFrame
    //     0xa4a2a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a2a4: mov             fp, SP
    // 0xa4a2a8: ldr             x0, [fp, #0x10]
    // 0xa4a2ac: LoadField: r1 = r0->field_17
    //     0xa4a2ac: ldur            w1, [x0, #0x17]
    // 0xa4a2b0: DecompressPointer r1
    //     0xa4a2b0: add             x1, x1, HEAP, lsl #32
    // 0xa4a2b4: CheckStackOverflow
    //     0xa4a2b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a2b8: cmp             SP, x16
    //     0xa4a2bc: b.ls            #0xa4a2e0
    // 0xa4a2c0: LoadField: r0 = r1->field_f
    //     0xa4a2c0: ldur            w0, [x1, #0xf]
    // 0xa4a2c4: DecompressPointer r0
    //     0xa4a2c4: add             x0, x0, HEAP, lsl #32
    // 0xa4a2c8: SaveReg r0
    //     0xa4a2c8: str             x0, [SP, #-8]!
    // 0xa4a2cc: r0 = dispose()
    //     0xa4a2cc: bl              #0xa4f690  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ExtendedNestedScrollViewState::dispose
    // 0xa4a2d0: add             SP, SP, #8
    // 0xa4a2d4: LeaveFrame
    //     0xa4a2d4: mov             SP, fp
    //     0xa4a2d8: ldp             fp, lr, [SP], #0x10
    // 0xa4a2dc: ret
    //     0xa4a2dc: ret             
    // 0xa4a2e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a2e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a2e4: b               #0xa4a2c0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4f690, size: 0x58
    // 0xa4f690: EnterFrame
    //     0xa4f690: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f694: mov             fp, SP
    // 0xa4f698: CheckStackOverflow
    //     0xa4f698: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f69c: cmp             SP, x16
    //     0xa4f6a0: b.ls            #0xa4f6dc
    // 0xa4f6a4: ldr             x0, [fp, #0x10]
    // 0xa4f6a8: LoadField: r1 = r0->field_17
    //     0xa4f6a8: ldur            w1, [x0, #0x17]
    // 0xa4f6ac: DecompressPointer r1
    //     0xa4f6ac: add             x1, x1, HEAP, lsl #32
    // 0xa4f6b0: cmp             w1, NULL
    // 0xa4f6b4: b.eq            #0xa4f6e4
    // 0xa4f6b8: SaveReg r1
    //     0xa4f6b8: str             x1, [SP, #-8]!
    // 0xa4f6bc: r0 = dispose()
    //     0xa4f6bc: bl              #0xa4f6e8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::dispose
    // 0xa4f6c0: add             SP, SP, #8
    // 0xa4f6c4: ldr             x1, [fp, #0x10]
    // 0xa4f6c8: StoreField: r1->field_17 = rNULL
    //     0xa4f6c8: stur            NULL, [x1, #0x17]
    // 0xa4f6cc: r0 = Null
    //     0xa4f6cc: mov             x0, NULL
    // 0xa4f6d0: LeaveFrame
    //     0xa4f6d0: mov             SP, fp
    //     0xa4f6d4: ldp             fp, lr, [SP], #0x10
    // 0xa4f6d8: ret
    //     0xa4f6d8: ret             
    // 0xa4f6dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f6dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f6e0: b               #0xa4f6a4
    // 0xa4f6e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4f6e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa602b8, size: 0x64
    // 0xa602b8: EnterFrame
    //     0xa602b8: stp             fp, lr, [SP, #-0x10]!
    //     0xa602bc: mov             fp, SP
    // 0xa602c0: CheckStackOverflow
    //     0xa602c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa602c4: cmp             SP, x16
    //     0xa602c8: b.ls            #0xa6030c
    // 0xa602cc: ldr             x0, [fp, #0x10]
    // 0xa602d0: LoadField: r1 = r0->field_17
    //     0xa602d0: ldur            w1, [x0, #0x17]
    // 0xa602d4: DecompressPointer r1
    //     0xa602d4: add             x1, x1, HEAP, lsl #32
    // 0xa602d8: cmp             w1, NULL
    // 0xa602dc: b.eq            #0xa60314
    // 0xa602e0: LoadField: r2 = r0->field_b
    //     0xa602e0: ldur            w2, [x0, #0xb]
    // 0xa602e4: DecompressPointer r2
    //     0xa602e4: add             x2, x2, HEAP, lsl #32
    // 0xa602e8: cmp             w2, NULL
    // 0xa602ec: b.eq            #0xa60318
    // 0xa602f0: SaveReg r1
    //     0xa602f0: str             x1, [SP, #-8]!
    // 0xa602f4: r0 = setParent()
    //     0xa602f4: bl              #0xa6031c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::setParent
    // 0xa602f8: add             SP, SP, #8
    // 0xa602fc: r0 = Null
    //     0xa602fc: mov             x0, NULL
    // 0xa60300: LeaveFrame
    //     0xa60300: mov             SP, fp
    //     0xa60304: ldp             fp, lr, [SP], #0x10
    // 0xa60308: ret
    //     0xa60308: ret             
    // 0xa6030c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6030c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60310: b               #0xa602cc
    // 0xa60314: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa60314: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa60318: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa60318: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3553, size: 0x14, field offset: 0x10
//   const constructor, 
class _InheritedNestedScrollView extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xa87694, size: 0x74
    // 0xa87694: EnterFrame
    //     0xa87694: stp             fp, lr, [SP, #-0x10]!
    //     0xa87698: mov             fp, SP
    // 0xa8769c: ldr             x0, [fp, #0x10]
    // 0xa876a0: r2 = Null
    //     0xa876a0: mov             x2, NULL
    // 0xa876a4: r1 = Null
    //     0xa876a4: mov             x1, NULL
    // 0xa876a8: r4 = 59
    //     0xa876a8: mov             x4, #0x3b
    // 0xa876ac: branchIfSmi(r0, 0xa876b8)
    //     0xa876ac: tbz             w0, #0, #0xa876b8
    // 0xa876b0: r4 = LoadClassIdInstr(r0)
    //     0xa876b0: ldur            x4, [x0, #-1]
    //     0xa876b4: ubfx            x4, x4, #0xc, #0x14
    // 0xa876b8: cmp             x4, #0xde1
    // 0xa876bc: b.eq            #0xa876d4
    // 0xa876c0: r8 = _InheritedNestedScrollView
    //     0xa876c0: add             x8, PP, #0x38, lsl #12  ; [pp+0x382a0] Type: _InheritedNestedScrollView
    //     0xa876c4: ldr             x8, [x8, #0x2a0]
    // 0xa876c8: r3 = Null
    //     0xa876c8: add             x3, PP, #0x38, lsl #12  ; [pp+0x382a8] Null
    //     0xa876cc: ldr             x3, [x3, #0x2a8]
    // 0xa876d0: r0 = DefaultTypeTest()
    //     0xa876d0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa876d4: ldr             x1, [fp, #0x18]
    // 0xa876d8: LoadField: r2 = r1->field_f
    //     0xa876d8: ldur            w2, [x1, #0xf]
    // 0xa876dc: DecompressPointer r2
    //     0xa876dc: add             x2, x2, HEAP, lsl #32
    // 0xa876e0: ldr             x1, [fp, #0x10]
    // 0xa876e4: LoadField: r3 = r1->field_f
    //     0xa876e4: ldur            w3, [x1, #0xf]
    // 0xa876e8: DecompressPointer r3
    //     0xa876e8: add             x3, x3, HEAP, lsl #32
    // 0xa876ec: cmp             w2, w3
    // 0xa876f0: r16 = true
    //     0xa876f0: add             x16, NULL, #0x20  ; true
    // 0xa876f4: r17 = false
    //     0xa876f4: add             x17, NULL, #0x30  ; false
    // 0xa876f8: csel            x0, x16, x17, ne
    // 0xa876fc: LeaveFrame
    //     0xa876fc: mov             SP, fp
    //     0xa87700: ldp             fp, lr, [SP], #0x10
    // 0xa87704: ret
    //     0xa87704: ret             
  }
}

// class id: 3678, size: 0x10, field offset: 0x10
//   const constructor, 
class _ExtendedSliverFillRemainingWithScrollable extends SingleChildRenderObjectWidget {

  _ createRenderObject(/* No info */) {
    // ** addr: 0x6e9f60, size: 0x54
    // 0x6e9f60: EnterFrame
    //     0x6e9f60: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9f64: mov             fp, SP
    // 0x6e9f68: AllocStack(0x8)
    //     0x6e9f68: sub             SP, SP, #8
    // 0x6e9f6c: CheckStackOverflow
    //     0x6e9f6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9f70: cmp             SP, x16
    //     0x6e9f74: b.ls            #0x6e9fac
    // 0x6e9f78: r0 = _ExtendedRenderSliverFillRemainingWithScrollable()
    //     0x6e9f78: bl              #0x6e9fb4  ; Allocate_ExtendedRenderSliverFillRemainingWithScrollableStub -> _ExtendedRenderSliverFillRemainingWithScrollable (size=0x58)
    // 0x6e9f7c: stur            x0, [fp, #-8]
    // 0x6e9f80: SaveReg r0
    //     0x6e9f80: str             x0, [SP, #-8]!
    // 0x6e9f84: r0 = RenderObject()
    //     0x6e9f84: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6e9f88: add             SP, SP, #8
    // 0x6e9f8c: ldur            x16, [fp, #-8]
    // 0x6e9f90: stp             NULL, x16, [SP, #-0x10]!
    // 0x6e9f94: r0 = child=()
    //     0x6e9f94: bl              #0x6e7ce0  ; [package:flutter/src/rendering/sliver_persistent_header.dart] _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin::child=
    // 0x6e9f98: add             SP, SP, #0x10
    // 0x6e9f9c: ldur            x0, [fp, #-8]
    // 0x6e9fa0: LeaveFrame
    //     0x6e9fa0: mov             SP, fp
    //     0x6e9fa4: ldp             fp, lr, [SP], #0x10
    // 0x6e9fa8: ret
    //     0x6e9fa8: ret             
    // 0x6e9fac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9fac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9fb0: b               #0x6e9f78
  }
}

// class id: 3881, size: 0x54, field offset: 0x50
//   const constructor, 
class _NestedScrollViewCustomScrollView extends CustomScrollView {

  _ buildViewport(/* No info */) {
    // ** addr: 0xc0923c, size: 0x6c
    // 0xc0923c: EnterFrame
    //     0xc0923c: stp             fp, lr, [SP, #-0x10]!
    //     0xc09240: mov             fp, SP
    // 0xc09244: AllocStack(0x10)
    //     0xc09244: sub             SP, SP, #0x10
    // 0xc09248: CheckStackOverflow
    //     0xc09248: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0924c: cmp             SP, x16
    //     0xc09250: b.ls            #0xc092a0
    // 0xc09254: ldr             x0, [fp, #0x28]
    // 0xc09258: LoadField: r1 = r0->field_4f
    //     0xc09258: ldur            w1, [x0, #0x4f]
    // 0xc0925c: DecompressPointer r1
    //     0xc0925c: add             x1, x1, HEAP, lsl #32
    // 0xc09260: stur            x1, [fp, #-8]
    // 0xc09264: r0 = NestedScrollViewViewport()
    //     0xc09264: bl              #0xc09364  ; AllocateNestedScrollViewViewportStub -> NestedScrollViewViewport (size=0x38)
    // 0xc09268: stur            x0, [fp, #-0x10]
    // 0xc0926c: ldr             x16, [fp, #0x18]
    // 0xc09270: stp             x16, x0, [SP, #-0x10]!
    // 0xc09274: ldur            x16, [fp, #-8]
    // 0xc09278: ldr             lr, [fp, #0x20]
    // 0xc0927c: stp             lr, x16, [SP, #-0x10]!
    // 0xc09280: ldr             x16, [fp, #0x10]
    // 0xc09284: SaveReg r16
    //     0xc09284: str             x16, [SP, #-8]!
    // 0xc09288: r0 = NestedScrollViewViewport()
    //     0xc09288: bl              #0xc092a8  ; [package:flutter/src/widgets/nested_scroll_view.dart] NestedScrollViewViewport::NestedScrollViewViewport
    // 0xc0928c: add             SP, SP, #0x28
    // 0xc09290: ldur            x0, [fp, #-0x10]
    // 0xc09294: LeaveFrame
    //     0xc09294: mov             SP, fp
    //     0xc09298: ldp             fp, lr, [SP], #0x10
    // 0xc0929c: ret
    //     0xc0929c: ret             
    // 0xc092a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc092a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc092a4: b               #0xc09254
  }
}

// class id: 4205, size: 0x44, field offset: 0xc
//   const constructor, 
class ExtendedNestedScrollView extends StatefulWidget {

  _ _buildSlivers(/* No info */) {
    // ** addr: 0x830ef4, size: 0xf0
    // 0x830ef4: EnterFrame
    //     0x830ef4: stp             fp, lr, [SP, #-0x10]!
    //     0x830ef8: mov             fp, SP
    // 0x830efc: AllocStack(0x20)
    //     0x830efc: sub             SP, SP, #0x20
    // 0x830f00: CheckStackOverflow
    //     0x830f00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x830f04: cmp             SP, x16
    //     0x830f08: b.ls            #0x830fdc
    // 0x830f0c: ldr             x1, [fp, #0x28]
    // 0x830f10: LoadField: r0 = r1->field_23
    //     0x830f10: ldur            w0, [x1, #0x23]
    // 0x830f14: DecompressPointer r0
    //     0x830f14: add             x0, x0, HEAP, lsl #32
    // 0x830f18: ldr             x16, [fp, #0x20]
    // 0x830f1c: stp             x16, x0, [SP, #-0x10]!
    // 0x830f20: ldr             x16, [fp, #0x10]
    // 0x830f24: SaveReg r16
    //     0x830f24: str             x16, [SP, #-8]!
    // 0x830f28: ClosureCall
    //     0x830f28: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x830f2c: ldur            x2, [x0, #0x1f]
    //     0x830f30: blr             x2
    // 0x830f34: add             SP, SP, #0x18
    // 0x830f38: r16 = <Widget>
    //     0x830f38: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x830f3c: ldr             x16, [x16, #0xea8]
    // 0x830f40: stp             x0, x16, [SP, #-0x10]!
    // 0x830f44: r0 = _GrowableList.of()
    //     0x830f44: bl              #0x4bfaf0  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x830f48: add             SP, SP, #0x10
    // 0x830f4c: stur            x0, [fp, #-8]
    // 0x830f50: r16 = const [Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform']
    //     0x830f50: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1b0] List<TargetPlatform>(6)
    //     0x830f54: ldr             x16, [x16, #0x1b0]
    // 0x830f58: SaveReg r16
    //     0x830f58: str             x16, [SP, #-8]!
    // 0x830f5c: r0 = toSet()
    //     0x830f5c: bl              #0x6aa304  ; [dart:collection] _ListBase&Object&ListMixin::toSet
    // 0x830f60: add             SP, SP, #8
    // 0x830f64: mov             x1, x0
    // 0x830f68: ldr             x0, [fp, #0x28]
    // 0x830f6c: stur            x1, [fp, #-0x18]
    // 0x830f70: LoadField: r2 = r0->field_27
    //     0x830f70: ldur            w2, [x0, #0x27]
    // 0x830f74: DecompressPointer r2
    //     0x830f74: add             x2, x2, HEAP, lsl #32
    // 0x830f78: stur            x2, [fp, #-0x10]
    // 0x830f7c: r0 = PrimaryScrollController()
    //     0x830f7c: bl              #0x830ff0  ; AllocatePrimaryScrollControllerStub -> PrimaryScrollController (size=0x1c)
    // 0x830f80: mov             x1, x0
    // 0x830f84: ldr             x0, [fp, #0x18]
    // 0x830f88: stur            x1, [fp, #-0x20]
    // 0x830f8c: StoreField: r1->field_f = r0
    //     0x830f8c: stur            w0, [x1, #0xf]
    // 0x830f90: ldur            x0, [fp, #-0x18]
    // 0x830f94: StoreField: r1->field_17 = r0
    //     0x830f94: stur            w0, [x1, #0x17]
    // 0x830f98: r0 = Instance_Axis
    //     0x830f98: add             x0, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x830f9c: ldr             x0, [x0, #0xf00]
    // 0x830fa0: StoreField: r1->field_13 = r0
    //     0x830fa0: stur            w0, [x1, #0x13]
    // 0x830fa4: ldur            x0, [fp, #-0x10]
    // 0x830fa8: StoreField: r1->field_b = r0
    //     0x830fa8: stur            w0, [x1, #0xb]
    // 0x830fac: r0 = _ExtendedSliverFillRemainingWithScrollable()
    //     0x830fac: bl              #0x830fe4  ; Allocate_ExtendedSliverFillRemainingWithScrollableStub -> _ExtendedSliverFillRemainingWithScrollable (size=0x10)
    // 0x830fb0: mov             x1, x0
    // 0x830fb4: ldur            x0, [fp, #-0x20]
    // 0x830fb8: StoreField: r1->field_b = r0
    //     0x830fb8: stur            w0, [x1, #0xb]
    // 0x830fbc: ldur            x16, [fp, #-8]
    // 0x830fc0: stp             x1, x16, [SP, #-0x10]!
    // 0x830fc4: r0 = add()
    //     0x830fc4: bl              #0x60bf60  ; [dart:core] _GrowableList::add
    // 0x830fc8: add             SP, SP, #0x10
    // 0x830fcc: ldur            x0, [fp, #-8]
    // 0x830fd0: LeaveFrame
    //     0x830fd0: mov             SP, fp
    //     0x830fd4: ldp             fp, lr, [SP], #0x10
    // 0x830fd8: ret
    //     0x830fd8: ret             
    // 0x830fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x830fdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x830fe0: b               #0x830f0c
  }
  _ createState(/* No info */) {
    // ** addr: 0xa3f6cc, size: 0x88
    // 0xa3f6cc: EnterFrame
    //     0xa3f6cc: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f6d0: mov             fp, SP
    // 0xa3f6d4: AllocStack(0x8)
    //     0xa3f6d4: sub             SP, SP, #8
    // 0xa3f6d8: CheckStackOverflow
    //     0xa3f6d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3f6dc: cmp             SP, x16
    //     0xa3f6e0: b.ls            #0xa3f74c
    // 0xa3f6e4: r0 = SliverOverlapAbsorberHandle()
    //     0xa3f6e4: bl              #0xa3f760  ; AllocateSliverOverlapAbsorberHandleStub -> SliverOverlapAbsorberHandle (size=0x30)
    // 0xa3f6e8: mov             x1, x0
    // 0xa3f6ec: r0 = 0
    //     0xa3f6ec: mov             x0, #0
    // 0xa3f6f0: stur            x1, [fp, #-8]
    // 0xa3f6f4: StoreField: r1->field_23 = r0
    //     0xa3f6f4: stur            x0, [x1, #0x23]
    // 0xa3f6f8: StoreField: r1->field_7 = r0
    //     0xa3f6f8: stur            x0, [x1, #7]
    // 0xa3f6fc: StoreField: r1->field_13 = r0
    //     0xa3f6fc: stur            x0, [x1, #0x13]
    // 0xa3f700: StoreField: r1->field_1b = r0
    //     0xa3f700: stur            x0, [x1, #0x1b]
    // 0xa3f704: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0xa3f704: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa3f708: ldr             x0, [x0, #0x1580]
    //     0xa3f70c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa3f710: cmp             w0, w16
    //     0xa3f714: b.ne            #0xa3f720
    //     0xa3f718: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0xa3f71c: bl              #0xd67cdc
    // 0xa3f720: mov             x1, x0
    // 0xa3f724: ldur            x0, [fp, #-8]
    // 0xa3f728: StoreField: r0->field_f = r1
    //     0xa3f728: stur            w1, [x0, #0xf]
    // 0xa3f72c: r1 = <ExtendedNestedScrollView>
    //     0xa3f72c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29220] TypeArguments: <ExtendedNestedScrollView>
    //     0xa3f730: ldr             x1, [x1, #0x220]
    // 0xa3f734: r0 = ExtendedNestedScrollViewState()
    //     0xa3f734: bl              #0xa3f754  ; AllocateExtendedNestedScrollViewStateStub -> ExtendedNestedScrollViewState (size=0x20)
    // 0xa3f738: ldur            x1, [fp, #-8]
    // 0xa3f73c: StoreField: r0->field_13 = r1
    //     0xa3f73c: stur            w1, [x0, #0x13]
    // 0xa3f740: LeaveFrame
    //     0xa3f740: mov             SP, fp
    //     0xa3f744: ldp             fp, lr, [SP], #0x10
    // 0xa3f748: ret
    //     0xa3f748: ret             
    // 0xa3f74c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3f74c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3f750: b               #0xa3f6e4
  }
}

// class id: 4453, size: 0x28, field offset: 0x8
abstract class _NestedScrollCoordinator extends Object
    implements ScrollActivityDelegate, ScrollHoldController {

  late _NestedScrollController _outerController; // offset: 0x18
  late _NestedScrollController _innerController; // offset: 0x1c

  get _ hasScrolledBody(/* No info */) {
    // ** addr: 0x831074, size: 0x11c
    // 0x831074: EnterFrame
    //     0x831074: stp             fp, lr, [SP, #-0x10]!
    //     0x831078: mov             fp, SP
    // 0x83107c: AllocStack(0x8)
    //     0x83107c: sub             SP, SP, #8
    // 0x831080: CheckStackOverflow
    //     0x831080: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x831084: cmp             SP, x16
    //     0x831088: b.ls            #0x831180
    // 0x83108c: ldr             x16, [fp, #0x10]
    // 0x831090: SaveReg r16
    //     0x831090: str             x16, [SP, #-8]!
    // 0x831094: r0 = _innerPositions()
    //     0x831094: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0x831098: add             SP, SP, #8
    // 0x83109c: r1 = LoadClassIdInstr(r0)
    //     0x83109c: ldur            x1, [x0, #-1]
    //     0x8310a0: ubfx            x1, x1, #0xc, #0x14
    // 0x8310a4: SaveReg r0
    //     0x8310a4: str             x0, [SP, #-8]!
    // 0x8310a8: mov             x0, x1
    // 0x8310ac: r0 = GDT[cid_x0 + 0xb940]()
    //     0x8310ac: mov             x17, #0xb940
    //     0x8310b0: add             lr, x0, x17
    //     0x8310b4: ldr             lr, [x21, lr, lsl #3]
    //     0x8310b8: blr             lr
    // 0x8310bc: add             SP, SP, #8
    // 0x8310c0: mov             x1, x0
    // 0x8310c4: stur            x1, [fp, #-8]
    // 0x8310c8: CheckStackOverflow
    //     0x8310c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8310cc: cmp             SP, x16
    //     0x8310d0: b.ls            #0x831188
    // 0x8310d4: r0 = LoadClassIdInstr(r1)
    //     0x8310d4: ldur            x0, [x1, #-1]
    //     0x8310d8: ubfx            x0, x0, #0xc, #0x14
    // 0x8310dc: SaveReg r1
    //     0x8310dc: str             x1, [SP, #-8]!
    // 0x8310e0: r0 = GDT[cid_x0 + 0x541]()
    //     0x8310e0: add             lr, x0, #0x541
    //     0x8310e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8310e8: blr             lr
    // 0x8310ec: add             SP, SP, #8
    // 0x8310f0: tbnz            w0, #4, #0x831170
    // 0x8310f4: ldur            x1, [fp, #-8]
    // 0x8310f8: r0 = LoadClassIdInstr(r1)
    //     0x8310f8: ldur            x0, [x1, #-1]
    //     0x8310fc: ubfx            x0, x0, #0xc, #0x14
    // 0x831100: SaveReg r1
    //     0x831100: str             x1, [SP, #-8]!
    // 0x831104: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x831104: add             lr, x0, #0x5ca
    //     0x831108: ldr             lr, [x21, lr, lsl #3]
    //     0x83110c: blr             lr
    // 0x831110: add             SP, SP, #8
    // 0x831114: LoadField: r1 = r0->field_33
    //     0x831114: ldur            w1, [x0, #0x33]
    // 0x831118: DecompressPointer r1
    //     0x831118: add             x1, x1, HEAP, lsl #32
    // 0x83111c: cmp             w1, NULL
    // 0x831120: b.eq            #0x831168
    // 0x831124: LoadField: r2 = r0->field_37
    //     0x831124: ldur            w2, [x0, #0x37]
    // 0x831128: DecompressPointer r2
    //     0x831128: add             x2, x2, HEAP, lsl #32
    // 0x83112c: cmp             w2, NULL
    // 0x831130: b.eq            #0x831168
    // 0x831134: LoadField: r2 = r0->field_43
    //     0x831134: ldur            w2, [x0, #0x43]
    // 0x831138: DecompressPointer r2
    //     0x831138: add             x2, x2, HEAP, lsl #32
    // 0x83113c: cmp             w2, NULL
    // 0x831140: b.eq            #0x831168
    // 0x831144: LoadField: d0 = r2->field_7
    //     0x831144: ldur            d0, [x2, #7]
    // 0x831148: LoadField: d1 = r1->field_7
    //     0x831148: ldur            d1, [x1, #7]
    // 0x83114c: fcmp            d0, d1
    // 0x831150: b.vs            #0x831168
    // 0x831154: b.le            #0x831168
    // 0x831158: r0 = true
    //     0x831158: add             x0, NULL, #0x20  ; true
    // 0x83115c: LeaveFrame
    //     0x83115c: mov             SP, fp
    //     0x831160: ldp             fp, lr, [SP], #0x10
    // 0x831164: ret
    //     0x831164: ret             
    // 0x831168: ldur            x1, [fp, #-8]
    // 0x83116c: b               #0x8310c8
    // 0x831170: r0 = false
    //     0x831170: add             x0, NULL, #0x30  ; false
    // 0x831174: LeaveFrame
    //     0x831174: mov             SP, fp
    //     0x831178: ldp             fp, lr, [SP], #0x10
    // 0x83117c: ret
    //     0x83117c: ret             
    // 0x831180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x831180: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x831184: b               #0x83108c
    // 0x831188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x831188: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83118c: b               #0x8310d4
  }
  _ _NestedScrollCoordinator(/* No info */) {
    // ** addr: 0x9d65a4, size: 0x134
    // 0x9d65a4: EnterFrame
    //     0x9d65a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9d65a8: mov             fp, SP
    // 0x9d65ac: AllocStack(0x8)
    //     0x9d65ac: sub             SP, SP, #8
    // 0x9d65b0: r2 = Sentinel
    //     0x9d65b0: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d65b4: r0 = Instance_ScrollDirection
    //     0x9d65b4: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f8c0] Obj!ScrollDirection@b646f1
    //     0x9d65b8: ldr             x0, [x0, #0x8c0]
    // 0x9d65bc: r1 = false
    //     0x9d65bc: add             x1, NULL, #0x30  ; false
    // 0x9d65c0: CheckStackOverflow
    //     0x9d65c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d65c4: cmp             SP, x16
    //     0x9d65c8: b.ls            #0x9d66d0
    // 0x9d65cc: ldr             x3, [fp, #0x20]
    // 0x9d65d0: StoreField: r3->field_17 = r2
    //     0x9d65d0: stur            w2, [x3, #0x17]
    // 0x9d65d4: StoreField: r3->field_1b = r2
    //     0x9d65d4: stur            w2, [x3, #0x1b]
    // 0x9d65d8: StoreField: r3->field_1f = r0
    //     0x9d65d8: stur            w0, [x3, #0x1f]
    // 0x9d65dc: ldr             x0, [fp, #0x18]
    // 0x9d65e0: StoreField: r3->field_7 = r0
    //     0x9d65e0: stur            w0, [x3, #7]
    //     0x9d65e4: ldurb           w16, [x3, #-1]
    //     0x9d65e8: ldurb           w17, [x0, #-1]
    //     0x9d65ec: and             x16, x17, x16, lsr #2
    //     0x9d65f0: tst             x16, HEAP, lsr #32
    //     0x9d65f4: b.eq            #0x9d65fc
    //     0x9d65f8: bl              #0xd682ac
    // 0x9d65fc: ldr             x0, [fp, #0x10]
    // 0x9d6600: StoreField: r3->field_f = r0
    //     0x9d6600: stur            w0, [x3, #0xf]
    //     0x9d6604: ldurb           w16, [x3, #-1]
    //     0x9d6608: ldurb           w17, [x0, #-1]
    //     0x9d660c: and             x16, x17, x16, lsr #2
    //     0x9d6610: tst             x16, HEAP, lsr #32
    //     0x9d6614: b.eq            #0x9d661c
    //     0x9d6618: bl              #0xd682ac
    // 0x9d661c: StoreField: r3->field_13 = r1
    //     0x9d661c: stur            w1, [x3, #0x13]
    // 0x9d6620: r0 = _NestedScrollController()
    //     0x9d6620: bl              #0x9d66d8  ; Allocate_NestedScrollControllerStub -> _NestedScrollController (size=0x3c)
    // 0x9d6624: mov             x1, x0
    // 0x9d6628: ldr             x0, [fp, #0x20]
    // 0x9d662c: stur            x1, [fp, #-8]
    // 0x9d6630: StoreField: r1->field_37 = r0
    //     0x9d6630: stur            w0, [x1, #0x37]
    // 0x9d6634: r16 = "outer"
    //     0x9d6634: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2eff8] "outer"
    //     0x9d6638: ldr             x16, [x16, #0xff8]
    // 0x9d663c: stp             x16, x1, [SP, #-0x10]!
    // 0x9d6640: r4 = const [0, 0x2, 0x2, 0x1, debugLabel, 0x1, null]
    //     0x9d6640: ldr             x4, [PP, #0x4490]  ; [pp+0x4490] List(7) [0, 0x2, 0x2, 0x1, "debugLabel", 0x1, Null]
    // 0x9d6644: r0 = ScrollController()
    //     0x9d6644: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9d6648: add             SP, SP, #0x10
    // 0x9d664c: ldur            x0, [fp, #-8]
    // 0x9d6650: ldr             x1, [fp, #0x20]
    // 0x9d6654: StoreField: r1->field_17 = r0
    //     0x9d6654: stur            w0, [x1, #0x17]
    //     0x9d6658: ldurb           w16, [x1, #-1]
    //     0x9d665c: ldurb           w17, [x0, #-1]
    //     0x9d6660: and             x16, x17, x16, lsr #2
    //     0x9d6664: tst             x16, HEAP, lsr #32
    //     0x9d6668: b.eq            #0x9d6670
    //     0x9d666c: bl              #0xd6826c
    // 0x9d6670: r0 = _NestedScrollController()
    //     0x9d6670: bl              #0x9d66d8  ; Allocate_NestedScrollControllerStub -> _NestedScrollController (size=0x3c)
    // 0x9d6674: mov             x1, x0
    // 0x9d6678: ldr             x0, [fp, #0x20]
    // 0x9d667c: stur            x1, [fp, #-8]
    // 0x9d6680: StoreField: r1->field_37 = r0
    //     0x9d6680: stur            w0, [x1, #0x37]
    // 0x9d6684: r16 = "inner"
    //     0x9d6684: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f000] "inner"
    //     0x9d6688: ldr             x16, [x16]
    // 0x9d668c: stp             x16, x1, [SP, #-0x10]!
    // 0x9d6690: r4 = const [0, 0x2, 0x2, 0x1, debugLabel, 0x1, null]
    //     0x9d6690: ldr             x4, [PP, #0x4490]  ; [pp+0x4490] List(7) [0, 0x2, 0x2, 0x1, "debugLabel", 0x1, Null]
    // 0x9d6694: r0 = ScrollController()
    //     0x9d6694: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9d6698: add             SP, SP, #0x10
    // 0x9d669c: ldur            x0, [fp, #-8]
    // 0x9d66a0: ldr             x1, [fp, #0x20]
    // 0x9d66a4: StoreField: r1->field_1b = r0
    //     0x9d66a4: stur            w0, [x1, #0x1b]
    //     0x9d66a8: ldurb           w16, [x1, #-1]
    //     0x9d66ac: ldurb           w17, [x0, #-1]
    //     0x9d66b0: and             x16, x17, x16, lsr #2
    //     0x9d66b4: tst             x16, HEAP, lsr #32
    //     0x9d66b8: b.eq            #0x9d66c0
    //     0x9d66bc: bl              #0xd6826c
    // 0x9d66c0: r0 = Null
    //     0x9d66c0: mov             x0, NULL
    // 0x9d66c4: LeaveFrame
    //     0x9d66c4: mov             SP, fp
    //     0x9d66c8: ldp             fp, lr, [SP], #0x10
    // 0x9d66cc: ret
    //     0x9d66cc: ret             
    // 0x9d66d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d66d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d66d4: b               #0x9d65cc
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4f6e8, size: 0xf0
    // 0xa4f6e8: EnterFrame
    //     0xa4f6e8: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f6ec: mov             fp, SP
    // 0xa4f6f0: AllocStack(0x8)
    //     0xa4f6f0: sub             SP, SP, #8
    // 0xa4f6f4: CheckStackOverflow
    //     0xa4f6f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f6f8: cmp             SP, x16
    //     0xa4f6fc: b.ls            #0xa4f7b8
    // 0xa4f700: ldr             x0, [fp, #0x10]
    // 0xa4f704: LoadField: r1 = r0->field_23
    //     0xa4f704: ldur            w1, [x0, #0x23]
    // 0xa4f708: DecompressPointer r1
    //     0xa4f708: add             x1, x1, HEAP, lsl #32
    // 0xa4f70c: cmp             w1, NULL
    // 0xa4f710: b.eq            #0xa4f724
    // 0xa4f714: SaveReg r1
    //     0xa4f714: str             x1, [SP, #-8]!
    // 0xa4f718: r0 = dispose()
    //     0xa4f718: bl              #0x9c2270  ; [package:flutter/src/widgets/scroll_activity.dart] ScrollDragController::dispose
    // 0xa4f71c: add             SP, SP, #8
    // 0xa4f720: ldr             x0, [fp, #0x10]
    // 0xa4f724: StoreField: r0->field_23 = rNULL
    //     0xa4f724: stur            NULL, [x0, #0x23]
    // 0xa4f728: LoadField: r1 = r0->field_17
    //     0xa4f728: ldur            w1, [x0, #0x17]
    // 0xa4f72c: DecompressPointer r1
    //     0xa4f72c: add             x1, x1, HEAP, lsl #32
    // 0xa4f730: r16 = Sentinel
    //     0xa4f730: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4f734: cmp             w1, w16
    // 0xa4f738: b.eq            #0xa4f7c0
    // 0xa4f73c: SaveReg r1
    //     0xa4f73c: str             x1, [SP, #-8]!
    // 0xa4f740: r0 = dispose()
    //     0xa4f740: bl              #0x9c2054  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0xa4f744: add             SP, SP, #8
    // 0xa4f748: ldr             x0, [fp, #0x10]
    // 0xa4f74c: LoadField: r3 = r0->field_1b
    //     0xa4f74c: ldur            w3, [x0, #0x1b]
    // 0xa4f750: DecompressPointer r3
    //     0xa4f750: add             x3, x3, HEAP, lsl #32
    // 0xa4f754: r16 = Sentinel
    //     0xa4f754: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4f758: cmp             w3, w16
    // 0xa4f75c: b.eq            #0xa4f7cc
    // 0xa4f760: mov             x0, x3
    // 0xa4f764: stur            x3, [fp, #-8]
    // 0xa4f768: r2 = Null
    //     0xa4f768: mov             x2, NULL
    // 0xa4f76c: r1 = Null
    //     0xa4f76c: mov             x1, NULL
    // 0xa4f770: r4 = LoadClassIdInstr(r0)
    //     0xa4f770: ldur            x4, [x0, #-1]
    //     0xa4f774: ubfx            x4, x4, #0xc, #0x14
    // 0xa4f778: r17 = 4858
    //     0xa4f778: mov             x17, #0x12fa
    // 0xa4f77c: cmp             x4, x17
    // 0xa4f780: b.eq            #0xa4f798
    // 0xa4f784: r8 = _ExtendedNestedScrollController
    //     0xa4f784: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2ee70] Type: _ExtendedNestedScrollController
    //     0xa4f788: ldr             x8, [x8, #0xe70]
    // 0xa4f78c: r3 = Null
    //     0xa4f78c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2efa8] Null
    //     0xa4f790: ldr             x3, [x3, #0xfa8]
    // 0xa4f794: r0 = DefaultTypeTest()
    //     0xa4f794: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa4f798: ldur            x16, [fp, #-8]
    // 0xa4f79c: SaveReg r16
    //     0xa4f79c: str             x16, [SP, #-8]!
    // 0xa4f7a0: r0 = dispose()
    //     0xa4f7a0: bl              #0x9c2054  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0xa4f7a4: add             SP, SP, #8
    // 0xa4f7a8: r0 = Null
    //     0xa4f7a8: mov             x0, NULL
    // 0xa4f7ac: LeaveFrame
    //     0xa4f7ac: mov             SP, fp
    //     0xa4f7b0: ldp             fp, lr, [SP], #0x10
    // 0xa4f7b4: ret
    //     0xa4f7b4: ret             
    // 0xa4f7b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f7b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f7bc: b               #0xa4f700
    // 0xa4f7c0: r9 = _outerController
    //     0xa4f7c0: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2ee58] Field <_NestedScrollCoordinator@454231548._outerController@454231548>: late (offset: 0x18)
    //     0xa4f7c4: ldr             x9, [x9, #0xe58]
    // 0xa4f7c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4f7c8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa4f7cc: r9 = _innerController
    //     0xa4f7cc: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2ee88] Field <_NestedScrollCoordinator@454231548._innerController@454231548>: late (offset: 0x1c)
    //     0xa4f7d0: ldr             x9, [x9, #0xe88]
    // 0xa4f7d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4f7d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ setParent(/* No info */) {
    // ** addr: 0xa6031c, size: 0x40
    // 0xa6031c: EnterFrame
    //     0xa6031c: stp             fp, lr, [SP, #-0x10]!
    //     0xa60320: mov             fp, SP
    // 0xa60324: CheckStackOverflow
    //     0xa60324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60328: cmp             SP, x16
    //     0xa6032c: b.ls            #0xa60354
    // 0xa60330: ldr             x0, [fp, #0x10]
    // 0xa60334: StoreField: r0->field_b = rNULL
    //     0xa60334: stur            NULL, [x0, #0xb]
    // 0xa60338: SaveReg r0
    //     0xa60338: str             x0, [SP, #-8]!
    // 0xa6033c: r0 = updateParent()
    //     0xa6033c: bl              #0xa6035c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::updateParent
    // 0xa60340: add             SP, SP, #8
    // 0xa60344: r0 = Null
    //     0xa60344: mov             x0, NULL
    // 0xa60348: LeaveFrame
    //     0xa60348: mov             SP, fp
    //     0xa6034c: ldp             fp, lr, [SP], #0x10
    // 0xa60350: ret
    //     0xa60350: ret             
    // 0xa60354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60354: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60358: b               #0xa60330
  }
  _ updateParent(/* No info */) {
    // ** addr: 0xa6035c, size: 0x88
    // 0xa6035c: EnterFrame
    //     0xa6035c: stp             fp, lr, [SP, #-0x10]!
    //     0xa60360: mov             fp, SP
    // 0xa60364: AllocStack(0x8)
    //     0xa60364: sub             SP, SP, #8
    // 0xa60368: CheckStackOverflow
    //     0xa60368: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6036c: cmp             SP, x16
    //     0xa60370: b.ls            #0xa603d8
    // 0xa60374: ldr             x16, [fp, #0x10]
    // 0xa60378: SaveReg r16
    //     0xa60378: str             x16, [SP, #-8]!
    // 0xa6037c: r0 = _outerPosition()
    //     0xa6037c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xa60380: add             SP, SP, #8
    // 0xa60384: stur            x0, [fp, #-8]
    // 0xa60388: cmp             w0, NULL
    // 0xa6038c: b.eq            #0xa603c8
    // 0xa60390: ldr             x1, [fp, #0x10]
    // 0xa60394: LoadField: r2 = r1->field_7
    //     0xa60394: ldur            w2, [x1, #7]
    // 0xa60398: DecompressPointer r2
    //     0xa60398: add             x2, x2, HEAP, lsl #32
    // 0xa6039c: LoadField: r1 = r2->field_f
    //     0xa6039c: ldur            w1, [x2, #0xf]
    // 0xa603a0: DecompressPointer r1
    //     0xa603a0: add             x1, x1, HEAP, lsl #32
    // 0xa603a4: cmp             w1, NULL
    // 0xa603a8: b.eq            #0xa603e0
    // 0xa603ac: SaveReg r1
    //     0xa603ac: str             x1, [SP, #-8]!
    // 0xa603b0: r0 = maybeOf()
    //     0xa603b0: bl              #0x841aac  ; [package:flutter/src/widgets/primary_scroll_controller.dart] PrimaryScrollController::maybeOf
    // 0xa603b4: add             SP, SP, #8
    // 0xa603b8: ldur            x16, [fp, #-8]
    // 0xa603bc: stp             x0, x16, [SP, #-0x10]!
    // 0xa603c0: r0 = setParent()
    //     0xa603c0: bl              #0x7d2778  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::setParent
    // 0xa603c4: add             SP, SP, #0x10
    // 0xa603c8: r0 = Null
    //     0xa603c8: mov             x0, NULL
    // 0xa603cc: LeaveFrame
    //     0xa603cc: mov             SP, fp
    //     0xa603d0: ldp             fp, lr, [SP], #0x10
    // 0xa603d4: ret
    //     0xa603d4: ret             
    // 0xa603d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa603d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa603dc: b               #0xa60374
    // 0xa603e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa603e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _outerPosition(/* No info */) {
    // ** addr: 0xa603e4, size: 0xd0
    // 0xa603e4: EnterFrame
    //     0xa603e4: stp             fp, lr, [SP, #-0x10]!
    //     0xa603e8: mov             fp, SP
    // 0xa603ec: CheckStackOverflow
    //     0xa603ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa603f0: cmp             SP, x16
    //     0xa603f4: b.ls            #0xa604a0
    // 0xa603f8: ldr             x0, [fp, #0x10]
    // 0xa603fc: LoadField: r1 = r0->field_17
    //     0xa603fc: ldur            w1, [x0, #0x17]
    // 0xa60400: DecompressPointer r1
    //     0xa60400: add             x1, x1, HEAP, lsl #32
    // 0xa60404: r16 = Sentinel
    //     0xa60404: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa60408: cmp             w1, w16
    // 0xa6040c: b.eq            #0xa604a8
    // 0xa60410: LoadField: r0 = r1->field_33
    //     0xa60410: ldur            w0, [x1, #0x33]
    // 0xa60414: DecompressPointer r0
    //     0xa60414: add             x0, x0, HEAP, lsl #32
    // 0xa60418: LoadField: r2 = r0->field_b
    //     0xa60418: ldur            w2, [x0, #0xb]
    // 0xa6041c: DecompressPointer r2
    //     0xa6041c: add             x2, x2, HEAP, lsl #32
    // 0xa60420: cbnz            w2, #0xa60434
    // 0xa60424: r0 = Null
    //     0xa60424: mov             x0, NULL
    // 0xa60428: LeaveFrame
    //     0xa60428: mov             SP, fp
    //     0xa6042c: ldp             fp, lr, [SP], #0x10
    // 0xa60430: ret
    //     0xa60430: ret             
    // 0xa60434: r2 = LoadClassIdInstr(r1)
    //     0xa60434: ldur            x2, [x1, #-1]
    //     0xa60438: ubfx            x2, x2, #0xc, #0x14
    // 0xa6043c: lsl             x2, x2, #1
    // 0xa60440: r17 = 9714
    //     0xa60440: mov             x17, #0x25f2
    // 0xa60444: cmp             w2, w17
    // 0xa60448: b.ne            #0xa60464
    // 0xa6044c: r16 = <_NestedScrollPosition, ScrollPosition, _NestedScrollPosition>
    //     0xa6044c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2efe0] TypeArguments: <_NestedScrollPosition, ScrollPosition, _NestedScrollPosition>
    //     0xa60450: ldr             x16, [x16, #0xfe0]
    // 0xa60454: stp             x0, x16, [SP, #-0x10]!
    // 0xa60458: r0 = CastIterable()
    //     0xa60458: bl              #0x4c0874  ; [dart:_internal] CastIterable::CastIterable
    // 0xa6045c: add             SP, SP, #0x10
    // 0xa60460: b               #0xa60470
    // 0xa60464: SaveReg r1
    //     0xa60464: str             x1, [SP, #-8]!
    // 0xa60468: r0 = _releaseNestedPositions()
    //     0xa60468: bl              #0x831a40  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollController::_releaseNestedPositions
    // 0xa6046c: add             SP, SP, #8
    // 0xa60470: r1 = LoadClassIdInstr(r0)
    //     0xa60470: ldur            x1, [x0, #-1]
    //     0xa60474: ubfx            x1, x1, #0xc, #0x14
    // 0xa60478: SaveReg r0
    //     0xa60478: str             x0, [SP, #-8]!
    // 0xa6047c: mov             x0, x1
    // 0xa60480: r0 = GDT[cid_x0 + 0xd22c]()
    //     0xa60480: mov             x17, #0xd22c
    //     0xa60484: add             lr, x0, x17
    //     0xa60488: ldr             lr, [x21, lr, lsl #3]
    //     0xa6048c: blr             lr
    // 0xa60490: add             SP, SP, #8
    // 0xa60494: LeaveFrame
    //     0xa60494: mov             SP, fp
    //     0xa60498: ldp             fp, lr, [SP], #0x10
    // 0xa6049c: ret
    //     0xa6049c: ret             
    // 0xa604a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa604a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa604a4: b               #0xa603f8
    // 0xa604a8: r9 = _outerController
    //     0xa604a8: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2ee58] Field <_NestedScrollCoordinator@454231548._outerController@454231548>: late (offset: 0x18)
    //     0xa604ac: ldr             x9, [x9, #0xe58]
    // 0xa604b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa604b0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0xad4060, size: 0x104
    // 0xad4060: EnterFrame
    //     0xad4060: stp             fp, lr, [SP, #-0x10]!
    //     0xad4064: mov             fp, SP
    // 0xad4068: AllocStack(0x10)
    //     0xad4068: sub             SP, SP, #0x10
    // 0xad406c: CheckStackOverflow
    //     0xad406c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4070: cmp             SP, x16
    //     0xad4074: b.ls            #0xad4144
    // 0xad4078: r1 = Null
    //     0xad4078: mov             x1, NULL
    // 0xad407c: r2 = 12
    //     0xad407c: mov             x2, #0xc
    // 0xad4080: r0 = AllocateArray()
    //     0xad4080: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4084: mov             x3, x0
    // 0xad4088: stur            x3, [fp, #-0x10]
    // 0xad408c: r17 = "_NestedScrollCoordinator"
    //     0xad408c: add             x17, PP, #0x38, lsl #12  ; [pp+0x38278] "_NestedScrollCoordinator"
    //     0xad4090: ldr             x17, [x17, #0x278]
    // 0xad4094: StoreField: r3->field_f = r17
    //     0xad4094: stur            w17, [x3, #0xf]
    // 0xad4098: r17 = "(outer="
    //     0xad4098: add             x17, PP, #0x38, lsl #12  ; [pp+0x38280] "(outer="
    //     0xad409c: ldr             x17, [x17, #0x280]
    // 0xad40a0: StoreField: r3->field_13 = r17
    //     0xad40a0: stur            w17, [x3, #0x13]
    // 0xad40a4: ldr             x0, [fp, #0x10]
    // 0xad40a8: LoadField: r1 = r0->field_17
    //     0xad40a8: ldur            w1, [x0, #0x17]
    // 0xad40ac: DecompressPointer r1
    //     0xad40ac: add             x1, x1, HEAP, lsl #32
    // 0xad40b0: r16 = Sentinel
    //     0xad40b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xad40b4: cmp             w1, w16
    // 0xad40b8: b.eq            #0xad414c
    // 0xad40bc: StoreField: r3->field_17 = r1
    //     0xad40bc: stur            w1, [x3, #0x17]
    // 0xad40c0: r17 = "; inner="
    //     0xad40c0: add             x17, PP, #0x38, lsl #12  ; [pp+0x38288] "; inner="
    //     0xad40c4: ldr             x17, [x17, #0x288]
    // 0xad40c8: StoreField: r3->field_1b = r17
    //     0xad40c8: stur            w17, [x3, #0x1b]
    // 0xad40cc: LoadField: r4 = r0->field_1b
    //     0xad40cc: ldur            w4, [x0, #0x1b]
    // 0xad40d0: DecompressPointer r4
    //     0xad40d0: add             x4, x4, HEAP, lsl #32
    // 0xad40d4: r16 = Sentinel
    //     0xad40d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xad40d8: cmp             w4, w16
    // 0xad40dc: b.eq            #0xad4158
    // 0xad40e0: mov             x0, x4
    // 0xad40e4: stur            x4, [fp, #-8]
    // 0xad40e8: r2 = Null
    //     0xad40e8: mov             x2, NULL
    // 0xad40ec: r1 = Null
    //     0xad40ec: mov             x1, NULL
    // 0xad40f0: r4 = LoadClassIdInstr(r0)
    //     0xad40f0: ldur            x4, [x0, #-1]
    //     0xad40f4: ubfx            x4, x4, #0xc, #0x14
    // 0xad40f8: r17 = 4858
    //     0xad40f8: mov             x17, #0x12fa
    // 0xad40fc: cmp             x4, x17
    // 0xad4100: b.eq            #0xad4118
    // 0xad4104: r8 = _ExtendedNestedScrollController
    //     0xad4104: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2ee70] Type: _ExtendedNestedScrollController
    //     0xad4108: ldr             x8, [x8, #0xe70]
    // 0xad410c: r3 = Null
    //     0xad410c: add             x3, PP, #0x38, lsl #12  ; [pp+0x38290] Null
    //     0xad4110: ldr             x3, [x3, #0x290]
    // 0xad4114: r0 = DefaultTypeTest()
    //     0xad4114: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad4118: ldur            x0, [fp, #-0x10]
    // 0xad411c: ldur            x1, [fp, #-8]
    // 0xad4120: StoreField: r0->field_1f = r1
    //     0xad4120: stur            w1, [x0, #0x1f]
    // 0xad4124: r17 = ")"
    //     0xad4124: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad4128: StoreField: r0->field_23 = r17
    //     0xad4128: stur            w17, [x0, #0x23]
    // 0xad412c: SaveReg r0
    //     0xad412c: str             x0, [SP, #-8]!
    // 0xad4130: r0 = _interpolate()
    //     0xad4130: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad4134: add             SP, SP, #8
    // 0xad4138: LeaveFrame
    //     0xad4138: mov             SP, fp
    //     0xad413c: ldp             fp, lr, [SP], #0x10
    // 0xad4140: ret
    //     0xad4140: ret             
    // 0xad4144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4144: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4148: b               #0xad4078
    // 0xad414c: r9 = _outerController
    //     0xad414c: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2ee58] Field <_NestedScrollCoordinator@454231548._outerController@454231548>: late (offset: 0x18)
    //     0xad4150: ldr             x9, [x9, #0xe58]
    // 0xad4154: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xad4154: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xad4158: r9 = _innerController
    //     0xad4158: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2ee88] Field <_NestedScrollCoordinator@454231548._innerController@454231548>: late (offset: 0x1c)
    //     0xad415c: ldr             x9, [x9, #0xe88]
    // 0xad4160: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xad4160: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ createInnerBallisticScrollActivity(/* No info */) {
    // ** addr: 0xbcf984, size: 0xa4
    // 0xbcf984: EnterFrame
    //     0xbcf984: stp             fp, lr, [SP, #-0x10]!
    //     0xbcf988: mov             fp, SP
    // 0xbcf98c: AllocStack(0x8)
    //     0xbcf98c: sub             SP, SP, #8
    // 0xbcf990: CheckStackOverflow
    //     0xbcf990: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbcf994: cmp             SP, x16
    //     0xbcf998: b.ls            #0xbcfa20
    // 0xbcf99c: ldr             x0, [fp, #0x18]
    // 0xbcf9a0: LoadField: r1 = r0->field_23
    //     0xbcf9a0: ldur            w1, [x0, #0x23]
    // 0xbcf9a4: DecompressPointer r1
    //     0xbcf9a4: add             x1, x1, HEAP, lsl #32
    // 0xbcf9a8: stur            x1, [fp, #-8]
    // 0xbcf9ac: ldr             x16, [fp, #0x20]
    // 0xbcf9b0: stp             x0, x16, [SP, #-0x10]!
    // 0xbcf9b4: ldr             d0, [fp, #0x10]
    // 0xbcf9b8: SaveReg d0
    //     0xbcf9b8: str             d0, [SP, #-8]!
    // 0xbcf9bc: r0 = _getMetrics()
    //     0xbcf9bc: bl              #0xbd0098  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_getMetrics
    // 0xbcf9c0: add             SP, SP, #0x18
    // 0xbcf9c4: mov             x1, x0
    // 0xbcf9c8: ldur            x0, [fp, #-8]
    // 0xbcf9cc: r2 = LoadClassIdInstr(r0)
    //     0xbcf9cc: ldur            x2, [x0, #-1]
    //     0xbcf9d0: ubfx            x2, x2, #0xc, #0x14
    // 0xbcf9d4: stp             x1, x0, [SP, #-0x10]!
    // 0xbcf9d8: ldr             d0, [fp, #0x10]
    // 0xbcf9dc: SaveReg d0
    //     0xbcf9dc: str             d0, [SP, #-8]!
    // 0xbcf9e0: mov             x0, x2
    // 0xbcf9e4: r0 = GDT[cid_x0 + 0x31d]()
    //     0xbcf9e4: add             lr, x0, #0x31d
    //     0xbcf9e8: ldr             lr, [x21, lr, lsl #3]
    //     0xbcf9ec: blr             lr
    // 0xbcf9f0: add             SP, SP, #0x18
    // 0xbcf9f4: ldr             x16, [fp, #0x18]
    // 0xbcf9f8: stp             x0, x16, [SP, #-0x10]!
    // 0xbcf9fc: r16 = Instance__NestedBallisticScrollActivityMode
    //     0xbcf9fc: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d98] Obj!_NestedBallisticScrollActivityMode@b65fb1
    //     0xbcfa00: ldr             x16, [x16, #0xd98]
    // 0xbcfa04: SaveReg r16
    //     0xbcfa04: str             x16, [SP, #-8]!
    // 0xbcfa08: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbcfa08: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbcfa0c: r0 = createBallisticScrollActivity()
    //     0xbcfa0c: bl              #0xbcfa28  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::createBallisticScrollActivity
    // 0xbcfa10: add             SP, SP, #0x18
    // 0xbcfa14: LeaveFrame
    //     0xbcfa14: mov             SP, fp
    //     0xbcfa18: ldp             fp, lr, [SP], #0x10
    // 0xbcfa1c: ret
    //     0xbcfa1c: ret             
    // 0xbcfa20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcfa20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcfa24: b               #0xbcf99c
  }
  _ _getMetrics(/* No info */) {
    // ** addr: 0xbd0098, size: 0x8b0
    // 0xbd0098: EnterFrame
    //     0xbd0098: stp             fp, lr, [SP, #-0x10]!
    //     0xbd009c: mov             fp, SP
    // 0xbd00a0: AllocStack(0x48)
    //     0xbd00a0: sub             SP, SP, #0x48
    // 0xbd00a4: CheckStackOverflow
    //     0xbd00a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd00a8: cmp             SP, x16
    //     0xbd00ac: b.ls            #0xbd082c
    // 0xbd00b0: ldr             x0, [fp, #0x18]
    // 0xbd00b4: LoadField: r1 = r0->field_43
    //     0xbd00b4: ldur            w1, [x0, #0x43]
    // 0xbd00b8: DecompressPointer r1
    //     0xbd00b8: add             x1, x1, HEAP, lsl #32
    // 0xbd00bc: cmp             w1, NULL
    // 0xbd00c0: b.eq            #0xbd0834
    // 0xbd00c4: LoadField: r2 = r0->field_33
    //     0xbd00c4: ldur            w2, [x0, #0x33]
    // 0xbd00c8: DecompressPointer r2
    //     0xbd00c8: add             x2, x2, HEAP, lsl #32
    // 0xbd00cc: cmp             w2, NULL
    // 0xbd00d0: b.eq            #0xbd0838
    // 0xbd00d4: LoadField: d0 = r1->field_7
    //     0xbd00d4: ldur            d0, [x1, #7]
    // 0xbd00d8: LoadField: d1 = r2->field_7
    //     0xbd00d8: ldur            d1, [x2, #7]
    // 0xbd00dc: fcmp            d0, d1
    // 0xbd00e0: b.vs            #0xbd0230
    // 0xbd00e4: b.ne            #0xbd0230
    // 0xbd00e8: ldr             x16, [fp, #0x20]
    // 0xbd00ec: SaveReg r16
    //     0xbd00ec: str             x16, [SP, #-8]!
    // 0xbd00f0: r0 = _outerPosition()
    //     0xbd00f0: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd00f4: add             SP, SP, #8
    // 0xbd00f8: cmp             w0, NULL
    // 0xbd00fc: b.eq            #0xbd083c
    // 0xbd0100: LoadField: r1 = r0->field_43
    //     0xbd0100: ldur            w1, [x0, #0x43]
    // 0xbd0104: DecompressPointer r1
    //     0xbd0104: add             x1, x1, HEAP, lsl #32
    // 0xbd0108: stur            x1, [fp, #-8]
    // 0xbd010c: cmp             w1, NULL
    // 0xbd0110: b.eq            #0xbd0840
    // 0xbd0114: ldr             x16, [fp, #0x20]
    // 0xbd0118: SaveReg r16
    //     0xbd0118: str             x16, [SP, #-8]!
    // 0xbd011c: r0 = _outerPosition()
    //     0xbd011c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0120: add             SP, SP, #8
    // 0xbd0124: cmp             w0, NULL
    // 0xbd0128: b.eq            #0xbd0844
    // 0xbd012c: LoadField: r1 = r0->field_33
    //     0xbd012c: ldur            w1, [x0, #0x33]
    // 0xbd0130: DecompressPointer r1
    //     0xbd0130: add             x1, x1, HEAP, lsl #32
    // 0xbd0134: stur            x1, [fp, #-0x10]
    // 0xbd0138: cmp             w1, NULL
    // 0xbd013c: b.eq            #0xbd0848
    // 0xbd0140: ldr             x16, [fp, #0x20]
    // 0xbd0144: SaveReg r16
    //     0xbd0144: str             x16, [SP, #-8]!
    // 0xbd0148: r0 = _outerPosition()
    //     0xbd0148: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd014c: add             SP, SP, #8
    // 0xbd0150: cmp             w0, NULL
    // 0xbd0154: b.eq            #0xbd084c
    // 0xbd0158: LoadField: r1 = r0->field_37
    //     0xbd0158: ldur            w1, [x0, #0x37]
    // 0xbd015c: DecompressPointer r1
    //     0xbd015c: add             x1, x1, HEAP, lsl #32
    // 0xbd0160: cmp             w1, NULL
    // 0xbd0164: b.eq            #0xbd0850
    // 0xbd0168: ldur            x0, [fp, #-8]
    // 0xbd016c: LoadField: d0 = r0->field_7
    //     0xbd016c: ldur            d0, [x0, #7]
    // 0xbd0170: ldur            x2, [fp, #-0x10]
    // 0xbd0174: LoadField: d1 = r2->field_7
    //     0xbd0174: ldur            d1, [x2, #7]
    // 0xbd0178: fcmp            d0, d1
    // 0xbd017c: b.vs            #0xbd018c
    // 0xbd0180: b.ge            #0xbd018c
    // 0xbd0184: mov             v0.16b, v1.16b
    // 0xbd0188: b               #0xbd01b4
    // 0xbd018c: LoadField: d1 = r1->field_7
    //     0xbd018c: ldur            d1, [x1, #7]
    // 0xbd0190: fcmp            d0, d1
    // 0xbd0194: b.vs            #0xbd01a4
    // 0xbd0198: b.le            #0xbd01a4
    // 0xbd019c: mov             v0.16b, v1.16b
    // 0xbd01a0: b               #0xbd01b4
    // 0xbd01a4: LoadField: d2 = r0->field_7
    //     0xbd01a4: ldur            d2, [x0, #7]
    // 0xbd01a8: fcmp            d2, d2
    // 0xbd01ac: b.vc            #0xbd01b4
    // 0xbd01b0: mov             v0.16b, v1.16b
    // 0xbd01b4: stur            d0, [fp, #-0x20]
    // 0xbd01b8: ldr             x16, [fp, #0x20]
    // 0xbd01bc: SaveReg r16
    //     0xbd01bc: str             x16, [SP, #-8]!
    // 0xbd01c0: r0 = _outerPosition()
    //     0xbd01c0: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd01c4: add             SP, SP, #8
    // 0xbd01c8: cmp             w0, NULL
    // 0xbd01cc: b.eq            #0xbd0854
    // 0xbd01d0: LoadField: r1 = r0->field_33
    //     0xbd01d0: ldur            w1, [x0, #0x33]
    // 0xbd01d4: DecompressPointer r1
    //     0xbd01d4: add             x1, x1, HEAP, lsl #32
    // 0xbd01d8: stur            x1, [fp, #-8]
    // 0xbd01dc: cmp             w1, NULL
    // 0xbd01e0: b.eq            #0xbd0858
    // 0xbd01e4: ldr             x16, [fp, #0x20]
    // 0xbd01e8: SaveReg r16
    //     0xbd01e8: str             x16, [SP, #-8]!
    // 0xbd01ec: r0 = _outerPosition()
    //     0xbd01ec: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd01f0: add             SP, SP, #8
    // 0xbd01f4: cmp             w0, NULL
    // 0xbd01f8: b.eq            #0xbd085c
    // 0xbd01fc: LoadField: r1 = r0->field_37
    //     0xbd01fc: ldur            w1, [x0, #0x37]
    // 0xbd0200: DecompressPointer r1
    //     0xbd0200: add             x1, x1, HEAP, lsl #32
    // 0xbd0204: cmp             w1, NULL
    // 0xbd0208: b.eq            #0xbd0860
    // 0xbd020c: ldur            x0, [fp, #-8]
    // 0xbd0210: LoadField: d0 = r0->field_7
    //     0xbd0210: ldur            d0, [x0, #7]
    // 0xbd0214: LoadField: d1 = r1->field_7
    //     0xbd0214: ldur            d1, [x1, #7]
    // 0xbd0218: ldur            d4, [fp, #-0x20]
    // 0xbd021c: mov             v3.16b, v0.16b
    // 0xbd0220: mov             v2.16b, v1.16b
    // 0xbd0224: d1 = 0.000000
    //     0xbd0224: eor             v1.16b, v1.16b, v1.16b
    // 0xbd0228: d0 = 0.000000
    //     0xbd0228: eor             v0.16b, v0.16b, v0.16b
    // 0xbd022c: b               #0xbd0688
    // 0xbd0230: fcmp            d0, d1
    // 0xbd0234: b.vs            #0xbd027c
    // 0xbd0238: b.ge            #0xbd027c
    // 0xbd023c: fsub            d2, d0, d1
    // 0xbd0240: stur            d2, [fp, #-0x20]
    // 0xbd0244: ldr             x16, [fp, #0x20]
    // 0xbd0248: SaveReg r16
    //     0xbd0248: str             x16, [SP, #-8]!
    // 0xbd024c: r0 = _outerPosition()
    //     0xbd024c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0250: add             SP, SP, #8
    // 0xbd0254: cmp             w0, NULL
    // 0xbd0258: b.eq            #0xbd0864
    // 0xbd025c: LoadField: r1 = r0->field_33
    //     0xbd025c: ldur            w1, [x0, #0x33]
    // 0xbd0260: DecompressPointer r1
    //     0xbd0260: add             x1, x1, HEAP, lsl #32
    // 0xbd0264: cmp             w1, NULL
    // 0xbd0268: b.eq            #0xbd0868
    // 0xbd026c: LoadField: d0 = r1->field_7
    //     0xbd026c: ldur            d0, [x1, #7]
    // 0xbd0270: ldur            d1, [fp, #-0x20]
    // 0xbd0274: fadd            d2, d1, d0
    // 0xbd0278: b               #0xbd02b8
    // 0xbd027c: fsub            d2, d0, d1
    // 0xbd0280: stur            d2, [fp, #-0x20]
    // 0xbd0284: ldr             x16, [fp, #0x20]
    // 0xbd0288: SaveReg r16
    //     0xbd0288: str             x16, [SP, #-8]!
    // 0xbd028c: r0 = _outerPosition()
    //     0xbd028c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0290: add             SP, SP, #8
    // 0xbd0294: cmp             w0, NULL
    // 0xbd0298: b.eq            #0xbd086c
    // 0xbd029c: LoadField: r1 = r0->field_37
    //     0xbd029c: ldur            w1, [x0, #0x37]
    // 0xbd02a0: DecompressPointer r1
    //     0xbd02a0: add             x1, x1, HEAP, lsl #32
    // 0xbd02a4: cmp             w1, NULL
    // 0xbd02a8: b.eq            #0xbd0870
    // 0xbd02ac: LoadField: d0 = r1->field_7
    //     0xbd02ac: ldur            d0, [x1, #7]
    // 0xbd02b0: ldur            d1, [fp, #-0x20]
    // 0xbd02b4: fadd            d2, d1, d0
    // 0xbd02b8: ldr             d1, [fp, #0x10]
    // 0xbd02bc: d0 = 0.000000
    //     0xbd02bc: eor             v0.16b, v0.16b, v0.16b
    // 0xbd02c0: stur            d2, [fp, #-0x20]
    // 0xbd02c4: fcmp            d1, d0
    // 0xbd02c8: b.vs            #0xbd02d0
    // 0xbd02cc: b.gt            #0xbd02d8
    // 0xbd02d0: r0 = false
    //     0xbd02d0: add             x0, NULL, #0x30  ; false
    // 0xbd02d4: b               #0xbd02dc
    // 0xbd02d8: r0 = true
    //     0xbd02d8: add             x0, NULL, #0x20  ; true
    // 0xbd02dc: tbnz            w0, #4, #0xbd03d0
    // 0xbd02e0: ldr             x1, [fp, #0x18]
    // 0xbd02e4: LoadField: r2 = r1->field_43
    //     0xbd02e4: ldur            w2, [x1, #0x43]
    // 0xbd02e8: DecompressPointer r2
    //     0xbd02e8: add             x2, x2, HEAP, lsl #32
    // 0xbd02ec: cmp             w2, NULL
    // 0xbd02f0: b.eq            #0xbd0874
    // 0xbd02f4: LoadField: r3 = r1->field_33
    //     0xbd02f4: ldur            w3, [x1, #0x33]
    // 0xbd02f8: DecompressPointer r3
    //     0xbd02f8: add             x3, x3, HEAP, lsl #32
    // 0xbd02fc: cmp             w3, NULL
    // 0xbd0300: b.eq            #0xbd0878
    // 0xbd0304: LoadField: d3 = r2->field_7
    //     0xbd0304: ldur            d3, [x2, #7]
    // 0xbd0308: LoadField: d4 = r3->field_7
    //     0xbd0308: ldur            d4, [x3, #7]
    // 0xbd030c: fcmp            d3, d4
    // 0xbd0310: b.vs            #0xbd03d0
    // 0xbd0314: b.le            #0xbd03d0
    // 0xbd0318: ldr             x16, [fp, #0x20]
    // 0xbd031c: SaveReg r16
    //     0xbd031c: str             x16, [SP, #-8]!
    // 0xbd0320: r0 = _outerPosition()
    //     0xbd0320: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0324: add             SP, SP, #8
    // 0xbd0328: cmp             w0, NULL
    // 0xbd032c: b.eq            #0xbd087c
    // 0xbd0330: LoadField: r1 = r0->field_37
    //     0xbd0330: ldur            w1, [x0, #0x37]
    // 0xbd0334: DecompressPointer r1
    //     0xbd0334: add             x1, x1, HEAP, lsl #32
    // 0xbd0338: stur            x1, [fp, #-8]
    // 0xbd033c: cmp             w1, NULL
    // 0xbd0340: b.eq            #0xbd0880
    // 0xbd0344: ldr             x16, [fp, #0x20]
    // 0xbd0348: SaveReg r16
    //     0xbd0348: str             x16, [SP, #-8]!
    // 0xbd034c: r0 = _outerPosition()
    //     0xbd034c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0350: add             SP, SP, #8
    // 0xbd0354: cmp             w0, NULL
    // 0xbd0358: b.eq            #0xbd0884
    // 0xbd035c: LoadField: r1 = r0->field_43
    //     0xbd035c: ldur            w1, [x0, #0x43]
    // 0xbd0360: DecompressPointer r1
    //     0xbd0360: add             x1, x1, HEAP, lsl #32
    // 0xbd0364: cmp             w1, NULL
    // 0xbd0368: b.eq            #0xbd0888
    // 0xbd036c: ldur            x0, [fp, #-8]
    // 0xbd0370: LoadField: d0 = r0->field_7
    //     0xbd0370: ldur            d0, [x0, #7]
    // 0xbd0374: LoadField: d1 = r1->field_7
    //     0xbd0374: ldur            d1, [x1, #7]
    // 0xbd0378: fsub            d2, d0, d1
    // 0xbd037c: ldur            d0, [fp, #-0x20]
    // 0xbd0380: stur            d2, [fp, #-0x30]
    // 0xbd0384: fadd            d1, d0, d2
    // 0xbd0388: stur            d1, [fp, #-0x28]
    // 0xbd038c: ldr             x16, [fp, #0x20]
    // 0xbd0390: SaveReg r16
    //     0xbd0390: str             x16, [SP, #-8]!
    // 0xbd0394: r0 = _outerPosition()
    //     0xbd0394: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0398: add             SP, SP, #8
    // 0xbd039c: cmp             w0, NULL
    // 0xbd03a0: b.eq            #0xbd088c
    // 0xbd03a4: LoadField: r1 = r0->field_43
    //     0xbd03a4: ldur            w1, [x0, #0x43]
    // 0xbd03a8: DecompressPointer r1
    //     0xbd03a8: add             x1, x1, HEAP, lsl #32
    // 0xbd03ac: cmp             w1, NULL
    // 0xbd03b0: b.eq            #0xbd0890
    // 0xbd03b4: LoadField: d0 = r1->field_7
    //     0xbd03b4: ldur            d0, [x1, #7]
    // 0xbd03b8: ldur            d2, [fp, #-0x20]
    // 0xbd03bc: fsub            d1, d0, d2
    // 0xbd03c0: mov             v3.16b, v2.16b
    // 0xbd03c4: ldur            d2, [fp, #-0x28]
    // 0xbd03c8: ldur            d0, [fp, #-0x30]
    // 0xbd03cc: b               #0xbd0684
    // 0xbd03d0: fcmp            d1, d0
    // 0xbd03d4: b.vs            #0xbd03dc
    // 0xbd03d8: b.lt            #0xbd03e4
    // 0xbd03dc: r1 = false
    //     0xbd03dc: add             x1, NULL, #0x30  ; false
    // 0xbd03e0: b               #0xbd03e8
    // 0xbd03e4: r1 = true
    //     0xbd03e4: add             x1, NULL, #0x20  ; true
    // 0xbd03e8: tbnz            w1, #4, #0xbd04ec
    // 0xbd03ec: ldr             x2, [fp, #0x18]
    // 0xbd03f0: LoadField: r3 = r2->field_43
    //     0xbd03f0: ldur            w3, [x2, #0x43]
    // 0xbd03f4: DecompressPointer r3
    //     0xbd03f4: add             x3, x3, HEAP, lsl #32
    // 0xbd03f8: cmp             w3, NULL
    // 0xbd03fc: b.eq            #0xbd0894
    // 0xbd0400: LoadField: r4 = r2->field_33
    //     0xbd0400: ldur            w4, [x2, #0x33]
    // 0xbd0404: DecompressPointer r4
    //     0xbd0404: add             x4, x4, HEAP, lsl #32
    // 0xbd0408: cmp             w4, NULL
    // 0xbd040c: b.eq            #0xbd0898
    // 0xbd0410: LoadField: d0 = r3->field_7
    //     0xbd0410: ldur            d0, [x3, #7]
    // 0xbd0414: LoadField: d1 = r4->field_7
    //     0xbd0414: ldur            d1, [x4, #7]
    // 0xbd0418: fcmp            d0, d1
    // 0xbd041c: b.vs            #0xbd04e4
    // 0xbd0420: b.ge            #0xbd04e4
    // 0xbd0424: ldr             x16, [fp, #0x20]
    // 0xbd0428: SaveReg r16
    //     0xbd0428: str             x16, [SP, #-8]!
    // 0xbd042c: r0 = _outerPosition()
    //     0xbd042c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0430: add             SP, SP, #8
    // 0xbd0434: cmp             w0, NULL
    // 0xbd0438: b.eq            #0xbd089c
    // 0xbd043c: LoadField: r1 = r0->field_43
    //     0xbd043c: ldur            w1, [x0, #0x43]
    // 0xbd0440: DecompressPointer r1
    //     0xbd0440: add             x1, x1, HEAP, lsl #32
    // 0xbd0444: stur            x1, [fp, #-8]
    // 0xbd0448: cmp             w1, NULL
    // 0xbd044c: b.eq            #0xbd08a0
    // 0xbd0450: ldr             x16, [fp, #0x20]
    // 0xbd0454: SaveReg r16
    //     0xbd0454: str             x16, [SP, #-8]!
    // 0xbd0458: r0 = _outerPosition()
    //     0xbd0458: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd045c: add             SP, SP, #8
    // 0xbd0460: cmp             w0, NULL
    // 0xbd0464: b.eq            #0xbd08a4
    // 0xbd0468: LoadField: r1 = r0->field_33
    //     0xbd0468: ldur            w1, [x0, #0x33]
    // 0xbd046c: DecompressPointer r1
    //     0xbd046c: add             x1, x1, HEAP, lsl #32
    // 0xbd0470: cmp             w1, NULL
    // 0xbd0474: b.eq            #0xbd08a8
    // 0xbd0478: ldur            x0, [fp, #-8]
    // 0xbd047c: LoadField: d0 = r0->field_7
    //     0xbd047c: ldur            d0, [x0, #7]
    // 0xbd0480: LoadField: d1 = r1->field_7
    //     0xbd0480: ldur            d1, [x1, #7]
    // 0xbd0484: fsub            d2, d0, d1
    // 0xbd0488: ldur            d0, [fp, #-0x20]
    // 0xbd048c: stur            d2, [fp, #-0x30]
    // 0xbd0490: fsub            d1, d0, d2
    // 0xbd0494: stur            d1, [fp, #-0x28]
    // 0xbd0498: ldr             x16, [fp, #0x20]
    // 0xbd049c: SaveReg r16
    //     0xbd049c: str             x16, [SP, #-8]!
    // 0xbd04a0: r0 = _outerPosition()
    //     0xbd04a0: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd04a4: add             SP, SP, #8
    // 0xbd04a8: cmp             w0, NULL
    // 0xbd04ac: b.eq            #0xbd08ac
    // 0xbd04b0: LoadField: r1 = r0->field_43
    //     0xbd04b0: ldur            w1, [x0, #0x43]
    // 0xbd04b4: DecompressPointer r1
    //     0xbd04b4: add             x1, x1, HEAP, lsl #32
    // 0xbd04b8: cmp             w1, NULL
    // 0xbd04bc: b.eq            #0xbd08b0
    // 0xbd04c0: LoadField: d0 = r1->field_7
    //     0xbd04c0: ldur            d0, [x1, #7]
    // 0xbd04c4: ldur            d1, [fp, #-0x20]
    // 0xbd04c8: fsub            d2, d0, d1
    // 0xbd04cc: ldur            d3, [fp, #-0x28]
    // 0xbd04d0: mov             v31.16b, v2.16b
    // 0xbd04d4: mov             v2.16b, v1.16b
    // 0xbd04d8: mov             v1.16b, v31.16b
    // 0xbd04dc: ldur            d0, [fp, #-0x30]
    // 0xbd04e0: b               #0xbd0684
    // 0xbd04e4: mov             v1.16b, v2.16b
    // 0xbd04e8: b               #0xbd04f0
    // 0xbd04ec: mov             v1.16b, v2.16b
    // 0xbd04f0: tbnz            w0, #4, #0xbd0560
    // 0xbd04f4: ldr             x16, [fp, #0x20]
    // 0xbd04f8: SaveReg r16
    //     0xbd04f8: str             x16, [SP, #-8]!
    // 0xbd04fc: r0 = _outerPosition()
    //     0xbd04fc: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0500: add             SP, SP, #8
    // 0xbd0504: cmp             w0, NULL
    // 0xbd0508: b.eq            #0xbd08b4
    // 0xbd050c: LoadField: r1 = r0->field_33
    //     0xbd050c: ldur            w1, [x0, #0x33]
    // 0xbd0510: DecompressPointer r1
    //     0xbd0510: add             x1, x1, HEAP, lsl #32
    // 0xbd0514: stur            x1, [fp, #-8]
    // 0xbd0518: cmp             w1, NULL
    // 0xbd051c: b.eq            #0xbd08b8
    // 0xbd0520: ldr             x16, [fp, #0x20]
    // 0xbd0524: SaveReg r16
    //     0xbd0524: str             x16, [SP, #-8]!
    // 0xbd0528: r0 = _outerPosition()
    //     0xbd0528: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd052c: add             SP, SP, #8
    // 0xbd0530: cmp             w0, NULL
    // 0xbd0534: b.eq            #0xbd08bc
    // 0xbd0538: LoadField: r1 = r0->field_43
    //     0xbd0538: ldur            w1, [x0, #0x43]
    // 0xbd053c: DecompressPointer r1
    //     0xbd053c: add             x1, x1, HEAP, lsl #32
    // 0xbd0540: cmp             w1, NULL
    // 0xbd0544: b.eq            #0xbd08c0
    // 0xbd0548: ldur            x0, [fp, #-8]
    // 0xbd054c: LoadField: d0 = r0->field_7
    //     0xbd054c: ldur            d0, [x0, #7]
    // 0xbd0550: LoadField: d1 = r1->field_7
    //     0xbd0550: ldur            d1, [x1, #7]
    // 0xbd0554: fsub            d2, d0, d1
    // 0xbd0558: mov             v0.16b, v2.16b
    // 0xbd055c: b               #0xbd060c
    // 0xbd0560: tbnz            w1, #4, #0xbd0608
    // 0xbd0564: ldr             x16, [fp, #0x20]
    // 0xbd0568: SaveReg r16
    //     0xbd0568: str             x16, [SP, #-8]!
    // 0xbd056c: r0 = _outerPosition()
    //     0xbd056c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0570: add             SP, SP, #8
    // 0xbd0574: cmp             w0, NULL
    // 0xbd0578: b.eq            #0xbd08c4
    // 0xbd057c: LoadField: r1 = r0->field_43
    //     0xbd057c: ldur            w1, [x0, #0x43]
    // 0xbd0580: DecompressPointer r1
    //     0xbd0580: add             x1, x1, HEAP, lsl #32
    // 0xbd0584: stur            x1, [fp, #-8]
    // 0xbd0588: cmp             w1, NULL
    // 0xbd058c: b.eq            #0xbd08c8
    // 0xbd0590: ldr             x16, [fp, #0x20]
    // 0xbd0594: SaveReg r16
    //     0xbd0594: str             x16, [SP, #-8]!
    // 0xbd0598: r0 = _outerPosition()
    //     0xbd0598: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd059c: add             SP, SP, #8
    // 0xbd05a0: cmp             w0, NULL
    // 0xbd05a4: b.eq            #0xbd08cc
    // 0xbd05a8: LoadField: r1 = r0->field_37
    //     0xbd05a8: ldur            w1, [x0, #0x37]
    // 0xbd05ac: DecompressPointer r1
    //     0xbd05ac: add             x1, x1, HEAP, lsl #32
    // 0xbd05b0: stur            x1, [fp, #-0x10]
    // 0xbd05b4: cmp             w1, NULL
    // 0xbd05b8: b.eq            #0xbd08d0
    // 0xbd05bc: ldr             x16, [fp, #0x20]
    // 0xbd05c0: SaveReg r16
    //     0xbd05c0: str             x16, [SP, #-8]!
    // 0xbd05c4: r0 = _outerPosition()
    //     0xbd05c4: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd05c8: add             SP, SP, #8
    // 0xbd05cc: cmp             w0, NULL
    // 0xbd05d0: b.eq            #0xbd08d4
    // 0xbd05d4: LoadField: r1 = r0->field_33
    //     0xbd05d4: ldur            w1, [x0, #0x33]
    // 0xbd05d8: DecompressPointer r1
    //     0xbd05d8: add             x1, x1, HEAP, lsl #32
    // 0xbd05dc: cmp             w1, NULL
    // 0xbd05e0: b.eq            #0xbd08d8
    // 0xbd05e4: ldur            x0, [fp, #-0x10]
    // 0xbd05e8: LoadField: d0 = r0->field_7
    //     0xbd05e8: ldur            d0, [x0, #7]
    // 0xbd05ec: LoadField: d1 = r1->field_7
    //     0xbd05ec: ldur            d1, [x1, #7]
    // 0xbd05f0: fsub            d2, d0, d1
    // 0xbd05f4: ldur            x0, [fp, #-8]
    // 0xbd05f8: LoadField: d0 = r0->field_7
    //     0xbd05f8: ldur            d0, [x0, #7]
    // 0xbd05fc: fsub            d1, d0, d2
    // 0xbd0600: mov             v0.16b, v1.16b
    // 0xbd0604: b               #0xbd060c
    // 0xbd0608: d0 = 0.000000
    //     0xbd0608: eor             v0.16b, v0.16b, v0.16b
    // 0xbd060c: stur            d0, [fp, #-0x28]
    // 0xbd0610: ldr             x16, [fp, #0x20]
    // 0xbd0614: SaveReg r16
    //     0xbd0614: str             x16, [SP, #-8]!
    // 0xbd0618: r0 = _outerPosition()
    //     0xbd0618: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd061c: add             SP, SP, #8
    // 0xbd0620: cmp             w0, NULL
    // 0xbd0624: b.eq            #0xbd08dc
    // 0xbd0628: LoadField: r1 = r0->field_33
    //     0xbd0628: ldur            w1, [x0, #0x33]
    // 0xbd062c: DecompressPointer r1
    //     0xbd062c: add             x1, x1, HEAP, lsl #32
    // 0xbd0630: stur            x1, [fp, #-8]
    // 0xbd0634: cmp             w1, NULL
    // 0xbd0638: b.eq            #0xbd08e0
    // 0xbd063c: ldr             x16, [fp, #0x20]
    // 0xbd0640: SaveReg r16
    //     0xbd0640: str             x16, [SP, #-8]!
    // 0xbd0644: r0 = _outerPosition()
    //     0xbd0644: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0648: add             SP, SP, #8
    // 0xbd064c: cmp             w0, NULL
    // 0xbd0650: b.eq            #0xbd08e4
    // 0xbd0654: LoadField: r1 = r0->field_37
    //     0xbd0654: ldur            w1, [x0, #0x37]
    // 0xbd0658: DecompressPointer r1
    //     0xbd0658: add             x1, x1, HEAP, lsl #32
    // 0xbd065c: cmp             w1, NULL
    // 0xbd0660: b.eq            #0xbd08e8
    // 0xbd0664: LoadField: d0 = r1->field_7
    //     0xbd0664: ldur            d0, [x1, #7]
    // 0xbd0668: ldur            d1, [fp, #-0x28]
    // 0xbd066c: fadd            d2, d0, d1
    // 0xbd0670: ldur            x0, [fp, #-8]
    // 0xbd0674: LoadField: d0 = r0->field_7
    //     0xbd0674: ldur            d0, [x0, #7]
    // 0xbd0678: mov             v3.16b, v0.16b
    // 0xbd067c: mov             v0.16b, v1.16b
    // 0xbd0680: d1 = 0.000000
    //     0xbd0680: eor             v1.16b, v1.16b, v1.16b
    // 0xbd0684: ldur            d4, [fp, #-0x20]
    // 0xbd0688: ldr             x0, [fp, #0x18]
    // 0xbd068c: stur            d4, [fp, #-0x20]
    // 0xbd0690: stur            d3, [fp, #-0x28]
    // 0xbd0694: stur            d2, [fp, #-0x30]
    // 0xbd0698: stur            d1, [fp, #-0x38]
    // 0xbd069c: stur            d0, [fp, #-0x40]
    // 0xbd06a0: ldr             x16, [fp, #0x20]
    // 0xbd06a4: SaveReg r16
    //     0xbd06a4: str             x16, [SP, #-8]!
    // 0xbd06a8: r0 = _outerPosition()
    //     0xbd06a8: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd06ac: add             SP, SP, #8
    // 0xbd06b0: cmp             w0, NULL
    // 0xbd06b4: b.eq            #0xbd08ec
    // 0xbd06b8: LoadField: r1 = r0->field_33
    //     0xbd06b8: ldur            w1, [x0, #0x33]
    // 0xbd06bc: DecompressPointer r1
    //     0xbd06bc: add             x1, x1, HEAP, lsl #32
    // 0xbd06c0: stur            x1, [fp, #-8]
    // 0xbd06c4: cmp             w1, NULL
    // 0xbd06c8: b.eq            #0xbd08f0
    // 0xbd06cc: ldr             x16, [fp, #0x20]
    // 0xbd06d0: SaveReg r16
    //     0xbd06d0: str             x16, [SP, #-8]!
    // 0xbd06d4: r0 = _outerPosition()
    //     0xbd06d4: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd06d8: add             SP, SP, #8
    // 0xbd06dc: cmp             w0, NULL
    // 0xbd06e0: b.eq            #0xbd08f4
    // 0xbd06e4: LoadField: r1 = r0->field_37
    //     0xbd06e4: ldur            w1, [x0, #0x37]
    // 0xbd06e8: DecompressPointer r1
    //     0xbd06e8: add             x1, x1, HEAP, lsl #32
    // 0xbd06ec: cmp             w1, NULL
    // 0xbd06f0: b.eq            #0xbd08f8
    // 0xbd06f4: ldr             x0, [fp, #0x18]
    // 0xbd06f8: LoadField: r2 = r0->field_37
    //     0xbd06f8: ldur            w2, [x0, #0x37]
    // 0xbd06fc: DecompressPointer r2
    //     0xbd06fc: add             x2, x2, HEAP, lsl #32
    // 0xbd0700: cmp             w2, NULL
    // 0xbd0704: b.eq            #0xbd08fc
    // 0xbd0708: LoadField: d0 = r1->field_7
    //     0xbd0708: ldur            d0, [x1, #7]
    // 0xbd070c: LoadField: d1 = r2->field_7
    //     0xbd070c: ldur            d1, [x2, #7]
    // 0xbd0710: fadd            d2, d0, d1
    // 0xbd0714: LoadField: r1 = r0->field_33
    //     0xbd0714: ldur            w1, [x0, #0x33]
    // 0xbd0718: DecompressPointer r1
    //     0xbd0718: add             x1, x1, HEAP, lsl #32
    // 0xbd071c: cmp             w1, NULL
    // 0xbd0720: b.eq            #0xbd0900
    // 0xbd0724: LoadField: d0 = r1->field_7
    //     0xbd0724: ldur            d0, [x1, #7]
    // 0xbd0728: fsub            d1, d2, d0
    // 0xbd072c: ldur            d0, [fp, #-0x40]
    // 0xbd0730: fadd            d2, d1, d0
    // 0xbd0734: stur            d2, [fp, #-0x48]
    // 0xbd0738: ldr             x16, [fp, #0x20]
    // 0xbd073c: SaveReg r16
    //     0xbd073c: str             x16, [SP, #-8]!
    // 0xbd0740: r0 = _outerPosition()
    //     0xbd0740: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0744: add             SP, SP, #8
    // 0xbd0748: cmp             w0, NULL
    // 0xbd074c: b.eq            #0xbd0904
    // 0xbd0750: LoadField: r1 = r0->field_47
    //     0xbd0750: ldur            w1, [x0, #0x47]
    // 0xbd0754: DecompressPointer r1
    //     0xbd0754: add             x1, x1, HEAP, lsl #32
    // 0xbd0758: stur            x1, [fp, #-0x10]
    // 0xbd075c: cmp             w1, NULL
    // 0xbd0760: b.eq            #0xbd0908
    // 0xbd0764: ldr             x16, [fp, #0x20]
    // 0xbd0768: SaveReg r16
    //     0xbd0768: str             x16, [SP, #-8]!
    // 0xbd076c: r0 = _outerPosition()
    //     0xbd076c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0770: add             SP, SP, #8
    // 0xbd0774: cmp             w0, NULL
    // 0xbd0778: b.eq            #0xbd090c
    // 0xbd077c: SaveReg r0
    //     0xbd077c: str             x0, [SP, #-8]!
    // 0xbd0780: r0 = axisDirection()
    //     0xbd0780: bl              #0xbea01c  ; [package:flutter/src/widgets/nested_scroll_view.dart] _NestedScrollPosition::axisDirection
    // 0xbd0784: add             SP, SP, #8
    // 0xbd0788: stur            x0, [fp, #-0x18]
    // 0xbd078c: r0 = _NestedScrollMetrics()
    //     0xbd078c: bl              #0xbd0948  ; Allocate_NestedScrollMetricsStub -> _NestedScrollMetrics (size=0x34)
    // 0xbd0790: ldur            d0, [fp, #-0x28]
    // 0xbd0794: StoreField: r0->field_1b = d0
    //     0xbd0794: stur            d0, [x0, #0x1b]
    // 0xbd0798: ldur            d0, [fp, #-0x30]
    // 0xbd079c: StoreField: r0->field_23 = d0
    //     0xbd079c: stur            d0, [x0, #0x23]
    // 0xbd07a0: ldur            d0, [fp, #-0x38]
    // 0xbd07a4: StoreField: r0->field_2b = d0
    //     0xbd07a4: stur            d0, [x0, #0x2b]
    // 0xbd07a8: ldur            x1, [fp, #-0x18]
    // 0xbd07ac: StoreField: r0->field_17 = r1
    //     0xbd07ac: stur            w1, [x0, #0x17]
    // 0xbd07b0: ldur            x1, [fp, #-8]
    // 0xbd07b4: StoreField: r0->field_7 = r1
    //     0xbd07b4: stur            w1, [x0, #7]
    // 0xbd07b8: ldur            d0, [fp, #-0x48]
    // 0xbd07bc: r1 = inline_Allocate_Double()
    //     0xbd07bc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbd07c0: add             x1, x1, #0x10
    //     0xbd07c4: cmp             x2, x1
    //     0xbd07c8: b.ls            #0xbd0910
    //     0xbd07cc: str             x1, [THR, #0x60]  ; THR::top
    //     0xbd07d0: sub             x1, x1, #0xf
    //     0xbd07d4: mov             x2, #0xd108
    //     0xbd07d8: movk            x2, #3, lsl #16
    //     0xbd07dc: stur            x2, [x1, #-1]
    // 0xbd07e0: StoreField: r1->field_7 = d0
    //     0xbd07e0: stur            d0, [x1, #7]
    // 0xbd07e4: StoreField: r0->field_b = r1
    //     0xbd07e4: stur            w1, [x0, #0xb]
    // 0xbd07e8: ldur            d0, [fp, #-0x20]
    // 0xbd07ec: r1 = inline_Allocate_Double()
    //     0xbd07ec: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbd07f0: add             x1, x1, #0x10
    //     0xbd07f4: cmp             x2, x1
    //     0xbd07f8: b.ls            #0xbd092c
    //     0xbd07fc: str             x1, [THR, #0x60]  ; THR::top
    //     0xbd0800: sub             x1, x1, #0xf
    //     0xbd0804: mov             x2, #0xd108
    //     0xbd0808: movk            x2, #3, lsl #16
    //     0xbd080c: stur            x2, [x1, #-1]
    // 0xbd0810: StoreField: r1->field_7 = d0
    //     0xbd0810: stur            d0, [x1, #7]
    // 0xbd0814: StoreField: r0->field_f = r1
    //     0xbd0814: stur            w1, [x0, #0xf]
    // 0xbd0818: ldur            x1, [fp, #-0x10]
    // 0xbd081c: StoreField: r0->field_13 = r1
    //     0xbd081c: stur            w1, [x0, #0x13]
    // 0xbd0820: LeaveFrame
    //     0xbd0820: mov             SP, fp
    //     0xbd0824: ldp             fp, lr, [SP], #0x10
    // 0xbd0828: ret
    //     0xbd0828: ret             
    // 0xbd082c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd082c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd0830: b               #0xbd00b0
    // 0xbd0834: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0834: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0838: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0838: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd083c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd083c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0840: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0840: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0844: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0844: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0848: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0848: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd084c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd084c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0850: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0850: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0854: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0854: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0858: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0858: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd085c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd085c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0860: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0860: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0864: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0864: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0868: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0868: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd086c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd086c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0870: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0870: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0874: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbd0874: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbd0878: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbd0878: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbd087c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd087c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0880: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0880: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0884: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0884: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0888: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0888: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd088c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd088c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0890: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0890: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0894: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbd0894: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbd0898: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbd0898: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbd089c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd089c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd08fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd08fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0900: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbd0900: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbd0904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0904: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0908: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd090c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd090c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0910: SaveReg d0
    //     0xbd0910: str             q0, [SP, #-0x10]!
    // 0xbd0914: SaveReg r0
    //     0xbd0914: str             x0, [SP, #-8]!
    // 0xbd0918: r0 = AllocateDouble()
    //     0xbd0918: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbd091c: mov             x1, x0
    // 0xbd0920: RestoreReg r0
    //     0xbd0920: ldr             x0, [SP], #8
    // 0xbd0924: RestoreReg d0
    //     0xbd0924: ldr             q0, [SP], #0x10
    // 0xbd0928: b               #0xbd07e0
    // 0xbd092c: SaveReg d0
    //     0xbd092c: str             q0, [SP, #-0x10]!
    // 0xbd0930: SaveReg r0
    //     0xbd0930: str             x0, [SP, #-8]!
    // 0xbd0934: r0 = AllocateDouble()
    //     0xbd0934: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbd0938: mov             x1, x0
    // 0xbd093c: RestoreReg r0
    //     0xbd093c: ldr             x0, [SP], #8
    // 0xbd0940: RestoreReg d0
    //     0xbd0940: ldr             q0, [SP], #0x10
    // 0xbd0944: b               #0xbd0810
  }
  _ createOuterBallisticScrollActivity(/* No info */) {
    // ** addr: 0xbd0a90, size: 0x324
    // 0xbd0a90: EnterFrame
    //     0xbd0a90: stp             fp, lr, [SP, #-0x10]!
    //     0xbd0a94: mov             fp, SP
    // 0xbd0a98: AllocStack(0x10)
    //     0xbd0a98: sub             SP, SP, #0x10
    // 0xbd0a9c: d0 = 0.000000
    //     0xbd0a9c: eor             v0.16b, v0.16b, v0.16b
    // 0xbd0aa0: CheckStackOverflow
    //     0xbd0aa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd0aa4: cmp             SP, x16
    //     0xbd0aa8: b.ls            #0xbd0d80
    // 0xbd0aac: ldr             d1, [fp, #0x10]
    // 0xbd0ab0: fcmp            d1, d0
    // 0xbd0ab4: b.eq            #0xbd0c10
    // 0xbd0ab8: ldr             x16, [fp, #0x18]
    // 0xbd0abc: SaveReg r16
    //     0xbd0abc: str             x16, [SP, #-8]!
    // 0xbd0ac0: r0 = _innerPositions()
    //     0xbd0ac0: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xbd0ac4: add             SP, SP, #8
    // 0xbd0ac8: r1 = LoadClassIdInstr(r0)
    //     0xbd0ac8: ldur            x1, [x0, #-1]
    //     0xbd0acc: ubfx            x1, x1, #0xc, #0x14
    // 0xbd0ad0: SaveReg r0
    //     0xbd0ad0: str             x0, [SP, #-8]!
    // 0xbd0ad4: mov             x0, x1
    // 0xbd0ad8: r0 = GDT[cid_x0 + 0xb940]()
    //     0xbd0ad8: mov             x17, #0xb940
    //     0xbd0adc: add             lr, x0, x17
    //     0xbd0ae0: ldr             lr, [x21, lr, lsl #3]
    //     0xbd0ae4: blr             lr
    // 0xbd0ae8: add             SP, SP, #8
    // 0xbd0aec: mov             x1, x0
    // 0xbd0af0: stur            x1, [fp, #-0x10]
    // 0xbd0af4: ldr             d0, [fp, #0x10]
    // 0xbd0af8: r2 = Null
    //     0xbd0af8: mov             x2, NULL
    // 0xbd0afc: stur            x2, [fp, #-8]
    // 0xbd0b00: CheckStackOverflow
    //     0xbd0b00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd0b04: cmp             SP, x16
    //     0xbd0b08: b.ls            #0xbd0d88
    // 0xbd0b0c: r0 = LoadClassIdInstr(r1)
    //     0xbd0b0c: ldur            x0, [x1, #-1]
    //     0xbd0b10: ubfx            x0, x0, #0xc, #0x14
    // 0xbd0b14: SaveReg r1
    //     0xbd0b14: str             x1, [SP, #-8]!
    // 0xbd0b18: r0 = GDT[cid_x0 + 0x541]()
    //     0xbd0b18: add             lr, x0, #0x541
    //     0xbd0b1c: ldr             lr, [x21, lr, lsl #3]
    //     0xbd0b20: blr             lr
    // 0xbd0b24: add             SP, SP, #8
    // 0xbd0b28: tbnz            w0, #4, #0xbd0c04
    // 0xbd0b2c: ldur            x1, [fp, #-0x10]
    // 0xbd0b30: ldur            x2, [fp, #-8]
    // 0xbd0b34: r0 = LoadClassIdInstr(r1)
    //     0xbd0b34: ldur            x0, [x1, #-1]
    //     0xbd0b38: ubfx            x0, x0, #0xc, #0x14
    // 0xbd0b3c: SaveReg r1
    //     0xbd0b3c: str             x1, [SP, #-8]!
    // 0xbd0b40: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xbd0b40: add             lr, x0, #0x5ca
    //     0xbd0b44: ldr             lr, [x21, lr, lsl #3]
    //     0xbd0b48: blr             lr
    // 0xbd0b4c: add             SP, SP, #8
    // 0xbd0b50: mov             x1, x0
    // 0xbd0b54: ldur            x0, [fp, #-8]
    // 0xbd0b58: cmp             w0, NULL
    // 0xbd0b5c: b.eq            #0xbd0bec
    // 0xbd0b60: ldr             d1, [fp, #0x10]
    // 0xbd0b64: d0 = 0.000000
    //     0xbd0b64: eor             v0.16b, v0.16b, v0.16b
    // 0xbd0b68: fcmp            d1, d0
    // 0xbd0b6c: b.vs            #0xbd0bb0
    // 0xbd0b70: b.le            #0xbd0bb0
    // 0xbd0b74: LoadField: r2 = r0->field_43
    //     0xbd0b74: ldur            w2, [x0, #0x43]
    // 0xbd0b78: DecompressPointer r2
    //     0xbd0b78: add             x2, x2, HEAP, lsl #32
    // 0xbd0b7c: cmp             w2, NULL
    // 0xbd0b80: b.eq            #0xbd0d90
    // 0xbd0b84: LoadField: r3 = r1->field_43
    //     0xbd0b84: ldur            w3, [x1, #0x43]
    // 0xbd0b88: DecompressPointer r3
    //     0xbd0b88: add             x3, x3, HEAP, lsl #32
    // 0xbd0b8c: cmp             w3, NULL
    // 0xbd0b90: b.eq            #0xbd0d94
    // 0xbd0b94: LoadField: d2 = r2->field_7
    //     0xbd0b94: ldur            d2, [x2, #7]
    // 0xbd0b98: LoadField: d3 = r3->field_7
    //     0xbd0b98: ldur            d3, [x3, #7]
    // 0xbd0b9c: fcmp            d2, d3
    // 0xbd0ba0: b.vs            #0xbd0bf4
    // 0xbd0ba4: b.ge            #0xbd0bf4
    // 0xbd0ba8: mov             x2, x0
    // 0xbd0bac: b               #0xbd0bf8
    // 0xbd0bb0: LoadField: r2 = r0->field_43
    //     0xbd0bb0: ldur            w2, [x0, #0x43]
    // 0xbd0bb4: DecompressPointer r2
    //     0xbd0bb4: add             x2, x2, HEAP, lsl #32
    // 0xbd0bb8: cmp             w2, NULL
    // 0xbd0bbc: b.eq            #0xbd0d98
    // 0xbd0bc0: LoadField: r3 = r1->field_43
    //     0xbd0bc0: ldur            w3, [x1, #0x43]
    // 0xbd0bc4: DecompressPointer r3
    //     0xbd0bc4: add             x3, x3, HEAP, lsl #32
    // 0xbd0bc8: cmp             w3, NULL
    // 0xbd0bcc: b.eq            #0xbd0d9c
    // 0xbd0bd0: LoadField: d2 = r2->field_7
    //     0xbd0bd0: ldur            d2, [x2, #7]
    // 0xbd0bd4: LoadField: d3 = r3->field_7
    //     0xbd0bd4: ldur            d3, [x3, #7]
    // 0xbd0bd8: fcmp            d2, d3
    // 0xbd0bdc: b.vs            #0xbd0bf4
    // 0xbd0be0: b.le            #0xbd0bf4
    // 0xbd0be4: mov             x2, x0
    // 0xbd0be8: b               #0xbd0bf8
    // 0xbd0bec: ldr             d1, [fp, #0x10]
    // 0xbd0bf0: d0 = 0.000000
    //     0xbd0bf0: eor             v0.16b, v0.16b, v0.16b
    // 0xbd0bf4: mov             x2, x1
    // 0xbd0bf8: mov             v0.16b, v1.16b
    // 0xbd0bfc: ldur            x1, [fp, #-0x10]
    // 0xbd0c00: b               #0xbd0afc
    // 0xbd0c04: ldr             d1, [fp, #0x10]
    // 0xbd0c08: ldur            x0, [fp, #-8]
    // 0xbd0c0c: b               #0xbd0c14
    // 0xbd0c10: r0 = Null
    //     0xbd0c10: mov             x0, NULL
    // 0xbd0c14: cmp             w0, NULL
    // 0xbd0c18: b.ne            #0xbd0ccc
    // 0xbd0c1c: ldr             x16, [fp, #0x18]
    // 0xbd0c20: SaveReg r16
    //     0xbd0c20: str             x16, [SP, #-8]!
    // 0xbd0c24: r0 = _outerPosition()
    //     0xbd0c24: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0c28: add             SP, SP, #8
    // 0xbd0c2c: stur            x0, [fp, #-8]
    // 0xbd0c30: cmp             w0, NULL
    // 0xbd0c34: b.eq            #0xbd0da0
    // 0xbd0c38: ldr             x16, [fp, #0x18]
    // 0xbd0c3c: SaveReg r16
    //     0xbd0c3c: str             x16, [SP, #-8]!
    // 0xbd0c40: r0 = _outerPosition()
    //     0xbd0c40: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0c44: add             SP, SP, #8
    // 0xbd0c48: cmp             w0, NULL
    // 0xbd0c4c: b.eq            #0xbd0da4
    // 0xbd0c50: LoadField: r1 = r0->field_23
    //     0xbd0c50: ldur            w1, [x0, #0x23]
    // 0xbd0c54: DecompressPointer r1
    //     0xbd0c54: add             x1, x1, HEAP, lsl #32
    // 0xbd0c58: stur            x1, [fp, #-0x10]
    // 0xbd0c5c: ldr             x16, [fp, #0x18]
    // 0xbd0c60: SaveReg r16
    //     0xbd0c60: str             x16, [SP, #-8]!
    // 0xbd0c64: r0 = _outerPosition()
    //     0xbd0c64: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0c68: add             SP, SP, #8
    // 0xbd0c6c: cmp             w0, NULL
    // 0xbd0c70: b.eq            #0xbd0da8
    // 0xbd0c74: ldur            x1, [fp, #-0x10]
    // 0xbd0c78: r2 = LoadClassIdInstr(r1)
    //     0xbd0c78: ldur            x2, [x1, #-1]
    //     0xbd0c7c: ubfx            x2, x2, #0xc, #0x14
    // 0xbd0c80: stp             x0, x1, [SP, #-0x10]!
    // 0xbd0c84: ldr             d0, [fp, #0x10]
    // 0xbd0c88: SaveReg d0
    //     0xbd0c88: str             d0, [SP, #-8]!
    // 0xbd0c8c: mov             x0, x2
    // 0xbd0c90: r0 = GDT[cid_x0 + 0x31d]()
    //     0xbd0c90: add             lr, x0, #0x31d
    //     0xbd0c94: ldr             lr, [x21, lr, lsl #3]
    //     0xbd0c98: blr             lr
    // 0xbd0c9c: add             SP, SP, #0x18
    // 0xbd0ca0: ldur            x16, [fp, #-8]
    // 0xbd0ca4: stp             x0, x16, [SP, #-0x10]!
    // 0xbd0ca8: r16 = Instance__NestedBallisticScrollActivityMode
    //     0xbd0ca8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40da8] Obj!_NestedBallisticScrollActivityMode@b65ff1
    //     0xbd0cac: ldr             x16, [x16, #0xda8]
    // 0xbd0cb0: SaveReg r16
    //     0xbd0cb0: str             x16, [SP, #-8]!
    // 0xbd0cb4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbd0cb4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbd0cb8: r0 = createBallisticScrollActivity()
    //     0xbd0cb8: bl              #0xbcfa28  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::createBallisticScrollActivity
    // 0xbd0cbc: add             SP, SP, #0x18
    // 0xbd0cc0: LeaveFrame
    //     0xbd0cc0: mov             SP, fp
    //     0xbd0cc4: ldp             fp, lr, [SP], #0x10
    // 0xbd0cc8: ret
    //     0xbd0cc8: ret             
    // 0xbd0ccc: mov             v0.16b, v1.16b
    // 0xbd0cd0: ldr             x16, [fp, #0x18]
    // 0xbd0cd4: stp             x0, x16, [SP, #-0x10]!
    // 0xbd0cd8: SaveReg d0
    //     0xbd0cd8: str             d0, [SP, #-8]!
    // 0xbd0cdc: r0 = _getMetrics()
    //     0xbd0cdc: bl              #0xbd0098  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_getMetrics
    // 0xbd0ce0: add             SP, SP, #0x18
    // 0xbd0ce4: stur            x0, [fp, #-8]
    // 0xbd0ce8: ldr             x16, [fp, #0x18]
    // 0xbd0cec: SaveReg r16
    //     0xbd0cec: str             x16, [SP, #-8]!
    // 0xbd0cf0: r0 = _outerPosition()
    //     0xbd0cf0: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0cf4: add             SP, SP, #8
    // 0xbd0cf8: stur            x0, [fp, #-0x10]
    // 0xbd0cfc: cmp             w0, NULL
    // 0xbd0d00: b.eq            #0xbd0dac
    // 0xbd0d04: ldr             x16, [fp, #0x18]
    // 0xbd0d08: SaveReg r16
    //     0xbd0d08: str             x16, [SP, #-8]!
    // 0xbd0d0c: r0 = _outerPosition()
    //     0xbd0d0c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbd0d10: add             SP, SP, #8
    // 0xbd0d14: cmp             w0, NULL
    // 0xbd0d18: b.eq            #0xbd0db0
    // 0xbd0d1c: LoadField: r1 = r0->field_23
    //     0xbd0d1c: ldur            w1, [x0, #0x23]
    // 0xbd0d20: DecompressPointer r1
    //     0xbd0d20: add             x1, x1, HEAP, lsl #32
    // 0xbd0d24: r0 = LoadClassIdInstr(r1)
    //     0xbd0d24: ldur            x0, [x1, #-1]
    //     0xbd0d28: ubfx            x0, x0, #0xc, #0x14
    // 0xbd0d2c: ldur            x16, [fp, #-8]
    // 0xbd0d30: stp             x16, x1, [SP, #-0x10]!
    // 0xbd0d34: ldr             d0, [fp, #0x10]
    // 0xbd0d38: SaveReg d0
    //     0xbd0d38: str             d0, [SP, #-8]!
    // 0xbd0d3c: r0 = GDT[cid_x0 + 0x31d]()
    //     0xbd0d3c: add             lr, x0, #0x31d
    //     0xbd0d40: ldr             lr, [x21, lr, lsl #3]
    //     0xbd0d44: blr             lr
    // 0xbd0d48: add             SP, SP, #0x18
    // 0xbd0d4c: ldur            x16, [fp, #-0x10]
    // 0xbd0d50: stp             x0, x16, [SP, #-0x10]!
    // 0xbd0d54: r16 = Instance__NestedBallisticScrollActivityMode
    //     0xbd0d54: add             x16, PP, #0x40, lsl #12  ; [pp+0x40db0] Obj!_NestedBallisticScrollActivityMode@b65fd1
    //     0xbd0d58: ldr             x16, [x16, #0xdb0]
    // 0xbd0d5c: ldur            lr, [fp, #-8]
    // 0xbd0d60: stp             lr, x16, [SP, #-0x10]!
    // 0xbd0d64: r4 = const [0, 0x4, 0x4, 0x3, metrics, 0x3, null]
    //     0xbd0d64: add             x4, PP, #0x40, lsl #12  ; [pp+0x40db8] List(7) [0, 0x4, 0x4, 0x3, "metrics", 0x3, Null]
    //     0xbd0d68: ldr             x4, [x4, #0xdb8]
    // 0xbd0d6c: r0 = createBallisticScrollActivity()
    //     0xbd0d6c: bl              #0xbcfa28  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::createBallisticScrollActivity
    // 0xbd0d70: add             SP, SP, #0x20
    // 0xbd0d74: LeaveFrame
    //     0xbd0d74: mov             SP, fp
    //     0xbd0d78: ldp             fp, lr, [SP], #0x10
    // 0xbd0d7c: ret
    //     0xbd0d7c: ret             
    // 0xbd0d80: r0 = StackOverflowSharedWithFPURegs()
    //     0xbd0d80: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbd0d84: b               #0xbd0aac
    // 0xbd0d88: r0 = StackOverflowSharedWithFPURegs()
    //     0xbd0d88: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbd0d8c: b               #0xbd0b0c
    // 0xbd0d90: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbd0d90: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbd0d94: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbd0d94: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbd0d98: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbd0d98: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbd0d9c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbd0d9c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbd0da0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0da0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0da4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0da4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0da8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0dac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0dac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd0db0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd0db0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ axisDirection(/* No info */) {
    // ** addr: 0xbfeef0, size: 0x68
    // 0xbfeef0: EnterFrame
    //     0xbfeef0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfeef4: mov             fp, SP
    // 0xbfeef8: CheckStackOverflow
    //     0xbfeef8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfeefc: cmp             SP, x16
    //     0xbfef00: b.ls            #0xbfef48
    // 0xbfef04: ldr             x16, [fp, #0x10]
    // 0xbfef08: SaveReg r16
    //     0xbfef08: str             x16, [SP, #-8]!
    // 0xbfef0c: r0 = _outerPosition()
    //     0xbfef0c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xbfef10: add             SP, SP, #8
    // 0xbfef14: cmp             w0, NULL
    // 0xbfef18: b.eq            #0xbfef50
    // 0xbfef1c: LoadField: r1 = r0->field_27
    //     0xbfef1c: ldur            w1, [x0, #0x27]
    // 0xbfef20: DecompressPointer r1
    //     0xbfef20: add             x1, x1, HEAP, lsl #32
    // 0xbfef24: LoadField: r2 = r1->field_b
    //     0xbfef24: ldur            w2, [x1, #0xb]
    // 0xbfef28: DecompressPointer r2
    //     0xbfef28: add             x2, x2, HEAP, lsl #32
    // 0xbfef2c: cmp             w2, NULL
    // 0xbfef30: b.eq            #0xbfef54
    // 0xbfef34: LoadField: r0 = r2->field_b
    //     0xbfef34: ldur            w0, [x2, #0xb]
    // 0xbfef38: DecompressPointer r0
    //     0xbfef38: add             x0, x0, HEAP, lsl #32
    // 0xbfef3c: LeaveFrame
    //     0xbfef3c: mov             SP, fp
    //     0xbfef40: ldp             fp, lr, [SP], #0x10
    // 0xbfef44: ret
    //     0xbfef44: ret             
    // 0xbfef48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfef48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfef4c: b               #0xbfef04
    // 0xbfef50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfef50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbfef54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfef54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ canScrollBody(/* No info */) {
    // ** addr: 0xc03284, size: 0x94
    // 0xc03284: EnterFrame
    //     0xc03284: stp             fp, lr, [SP, #-0x10]!
    //     0xc03288: mov             fp, SP
    // 0xc0328c: CheckStackOverflow
    //     0xc0328c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc03290: cmp             SP, x16
    //     0xc03294: b.ls            #0xc03310
    // 0xc03298: ldr             x16, [fp, #0x10]
    // 0xc0329c: SaveReg r16
    //     0xc0329c: str             x16, [SP, #-8]!
    // 0xc032a0: r0 = _outerPosition()
    //     0xc032a0: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc032a4: add             SP, SP, #8
    // 0xc032a8: cmp             w0, NULL
    // 0xc032ac: b.ne            #0xc032c0
    // 0xc032b0: r0 = true
    //     0xc032b0: add             x0, NULL, #0x20  ; true
    // 0xc032b4: LeaveFrame
    //     0xc032b4: mov             SP, fp
    //     0xc032b8: ldp             fp, lr, [SP], #0x10
    // 0xc032bc: ret
    //     0xc032bc: ret             
    // 0xc032c0: LoadField: r1 = r0->field_4b
    //     0xc032c0: ldur            w1, [x0, #0x4b]
    // 0xc032c4: DecompressPointer r1
    //     0xc032c4: add             x1, x1, HEAP, lsl #32
    // 0xc032c8: tbnz            w1, #4, #0xc03300
    // 0xc032cc: SaveReg r0
    //     0xc032cc: str             x0, [SP, #-8]!
    // 0xc032d0: r0 = extentAfter()
    //     0xc032d0: bl              #0xa78944  ; [package:flutter/src/widgets/scroll_position.dart] _ScrollPosition&ViewportOffset&ScrollMetrics::extentAfter
    // 0xc032d4: add             SP, SP, #8
    // 0xc032d8: mov             v1.16b, v0.16b
    // 0xc032dc: d0 = 0.000000
    //     0xc032dc: eor             v0.16b, v0.16b, v0.16b
    // 0xc032e0: fcmp            d1, d0
    // 0xc032e4: b.vs            #0xc032ec
    // 0xc032e8: b.eq            #0xc032f4
    // 0xc032ec: r1 = false
    //     0xc032ec: add             x1, NULL, #0x30  ; false
    // 0xc032f0: b               #0xc032f8
    // 0xc032f4: r1 = true
    //     0xc032f4: add             x1, NULL, #0x20  ; true
    // 0xc032f8: mov             x0, x1
    // 0xc032fc: b               #0xc03304
    // 0xc03300: r0 = false
    //     0xc03300: add             x0, NULL, #0x30  ; false
    // 0xc03304: LeaveFrame
    //     0xc03304: mov             SP, fp
    //     0xc03308: ldp             fp, lr, [SP], #0x10
    // 0xc0330c: ret
    //     0xc0330c: ret             
    // 0xc03310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc03310: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc03314: b               #0xc03298
  }
  _ updateUserScrollDirection(/* No info */) {
    // ** addr: 0xc116d0, size: 0x148
    // 0xc116d0: EnterFrame
    //     0xc116d0: stp             fp, lr, [SP, #-0x10]!
    //     0xc116d4: mov             fp, SP
    // 0xc116d8: AllocStack(0x8)
    //     0xc116d8: sub             SP, SP, #8
    // 0xc116dc: CheckStackOverflow
    //     0xc116dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc116e0: cmp             SP, x16
    //     0xc116e4: b.ls            #0xc11804
    // 0xc116e8: ldr             x1, [fp, #0x18]
    // 0xc116ec: LoadField: r0 = r1->field_1f
    //     0xc116ec: ldur            w0, [x1, #0x1f]
    // 0xc116f0: DecompressPointer r0
    //     0xc116f0: add             x0, x0, HEAP, lsl #32
    // 0xc116f4: ldr             x2, [fp, #0x10]
    // 0xc116f8: cmp             w0, w2
    // 0xc116fc: b.ne            #0xc11710
    // 0xc11700: r0 = Null
    //     0xc11700: mov             x0, NULL
    // 0xc11704: LeaveFrame
    //     0xc11704: mov             SP, fp
    //     0xc11708: ldp             fp, lr, [SP], #0x10
    // 0xc1170c: ret
    //     0xc1170c: ret             
    // 0xc11710: mov             x0, x2
    // 0xc11714: StoreField: r1->field_1f = r0
    //     0xc11714: stur            w0, [x1, #0x1f]
    //     0xc11718: ldurb           w16, [x1, #-1]
    //     0xc1171c: ldurb           w17, [x0, #-1]
    //     0xc11720: and             x16, x17, x16, lsr #2
    //     0xc11724: tst             x16, HEAP, lsr #32
    //     0xc11728: b.eq            #0xc11730
    //     0xc1172c: bl              #0xd6826c
    // 0xc11730: SaveReg r1
    //     0xc11730: str             x1, [SP, #-8]!
    // 0xc11734: r0 = _outerPosition()
    //     0xc11734: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc11738: add             SP, SP, #8
    // 0xc1173c: cmp             w0, NULL
    // 0xc11740: b.eq            #0xc1180c
    // 0xc11744: ldr             x16, [fp, #0x10]
    // 0xc11748: stp             x16, x0, [SP, #-0x10]!
    // 0xc1174c: r0 = didUpdateScrollDirection()
    //     0xc1174c: bl              #0xbff0a0  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didUpdateScrollDirection
    // 0xc11750: add             SP, SP, #0x10
    // 0xc11754: ldr             x16, [fp, #0x18]
    // 0xc11758: SaveReg r16
    //     0xc11758: str             x16, [SP, #-8]!
    // 0xc1175c: r0 = _innerPositions()
    //     0xc1175c: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc11760: add             SP, SP, #8
    // 0xc11764: r1 = LoadClassIdInstr(r0)
    //     0xc11764: ldur            x1, [x0, #-1]
    //     0xc11768: ubfx            x1, x1, #0xc, #0x14
    // 0xc1176c: SaveReg r0
    //     0xc1176c: str             x0, [SP, #-8]!
    // 0xc11770: mov             x0, x1
    // 0xc11774: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc11774: mov             x17, #0xb940
    //     0xc11778: add             lr, x0, x17
    //     0xc1177c: ldr             lr, [x21, lr, lsl #3]
    //     0xc11780: blr             lr
    // 0xc11784: add             SP, SP, #8
    // 0xc11788: mov             x1, x0
    // 0xc1178c: stur            x1, [fp, #-8]
    // 0xc11790: CheckStackOverflow
    //     0xc11790: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc11794: cmp             SP, x16
    //     0xc11798: b.ls            #0xc11810
    // 0xc1179c: r0 = LoadClassIdInstr(r1)
    //     0xc1179c: ldur            x0, [x1, #-1]
    //     0xc117a0: ubfx            x0, x0, #0xc, #0x14
    // 0xc117a4: SaveReg r1
    //     0xc117a4: str             x1, [SP, #-8]!
    // 0xc117a8: r0 = GDT[cid_x0 + 0x541]()
    //     0xc117a8: add             lr, x0, #0x541
    //     0xc117ac: ldr             lr, [x21, lr, lsl #3]
    //     0xc117b0: blr             lr
    // 0xc117b4: add             SP, SP, #8
    // 0xc117b8: tbnz            w0, #4, #0xc117f4
    // 0xc117bc: ldur            x1, [fp, #-8]
    // 0xc117c0: r0 = LoadClassIdInstr(r1)
    //     0xc117c0: ldur            x0, [x1, #-1]
    //     0xc117c4: ubfx            x0, x0, #0xc, #0x14
    // 0xc117c8: SaveReg r1
    //     0xc117c8: str             x1, [SP, #-8]!
    // 0xc117cc: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc117cc: add             lr, x0, #0x5ca
    //     0xc117d0: ldr             lr, [x21, lr, lsl #3]
    //     0xc117d4: blr             lr
    // 0xc117d8: add             SP, SP, #8
    // 0xc117dc: ldr             x16, [fp, #0x10]
    // 0xc117e0: stp             x16, x0, [SP, #-0x10]!
    // 0xc117e4: r0 = didUpdateScrollDirection()
    //     0xc117e4: bl              #0xbff0a0  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didUpdateScrollDirection
    // 0xc117e8: add             SP, SP, #0x10
    // 0xc117ec: ldur            x1, [fp, #-8]
    // 0xc117f0: b               #0xc11790
    // 0xc117f4: r0 = Null
    //     0xc117f4: mov             x0, NULL
    // 0xc117f8: LeaveFrame
    //     0xc117f8: mov             SP, fp
    //     0xc117fc: ldp             fp, lr, [SP], #0x10
    // 0xc11800: ret
    //     0xc11800: ret             
    // 0xc11804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc11804: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc11808: b               #0xc116e8
    // 0xc1180c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1180c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc11810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc11810: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc11814: b               #0xc1179c
  }
  _ applyUserOffset(/* No info */) {
    // ** addr: 0xc139a0, size: 0x718
    // 0xc139a0: EnterFrame
    //     0xc139a0: stp             fp, lr, [SP, #-0x10]!
    //     0xc139a4: mov             fp, SP
    // 0xc139a8: AllocStack(0x40)
    //     0xc139a8: sub             SP, SP, #0x40
    // 0xc139ac: d0 = 0.000000
    //     0xc139ac: eor             v0.16b, v0.16b, v0.16b
    // 0xc139b0: CheckStackOverflow
    //     0xc139b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc139b4: cmp             SP, x16
    //     0xc139b8: b.ls            #0xc14058
    // 0xc139bc: ldr             d1, [fp, #0x10]
    // 0xc139c0: fcmp            d1, d0
    // 0xc139c4: b.vs            #0xc139d8
    // 0xc139c8: b.le            #0xc139d8
    // 0xc139cc: r0 = Instance_ScrollDirection
    //     0xc139cc: add             x0, PP, #0x38, lsl #12  ; [pp+0x38f70] Obj!ScrollDirection@b646d1
    //     0xc139d0: ldr             x0, [x0, #0xf70]
    // 0xc139d4: b               #0xc139e0
    // 0xc139d8: r0 = Instance_ScrollDirection
    //     0xc139d8: add             x0, PP, #0x4a, lsl #12  ; [pp+0x4a938] Obj!ScrollDirection@b646b1
    //     0xc139dc: ldr             x0, [x0, #0x938]
    // 0xc139e0: ldr             x16, [fp, #0x18]
    // 0xc139e4: stp             x0, x16, [SP, #-0x10]!
    // 0xc139e8: r0 = updateUserScrollDirection()
    //     0xc139e8: bl              #0xc116d0  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::updateUserScrollDirection
    // 0xc139ec: add             SP, SP, #0x10
    // 0xc139f0: ldr             x16, [fp, #0x18]
    // 0xc139f4: SaveReg r16
    //     0xc139f4: str             x16, [SP, #-8]!
    // 0xc139f8: r0 = _innerPositions()
    //     0xc139f8: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc139fc: add             SP, SP, #8
    // 0xc13a00: r1 = LoadClassIdInstr(r0)
    //     0xc13a00: ldur            x1, [x0, #-1]
    //     0xc13a04: ubfx            x1, x1, #0xc, #0x14
    // 0xc13a08: SaveReg r0
    //     0xc13a08: str             x0, [SP, #-8]!
    // 0xc13a0c: mov             x0, x1
    // 0xc13a10: r0 = GDT[cid_x0 + 0xccd1]()
    //     0xc13a10: mov             x17, #0xccd1
    //     0xc13a14: add             lr, x0, x17
    //     0xc13a18: ldr             lr, [x21, lr, lsl #3]
    //     0xc13a1c: blr             lr
    // 0xc13a20: add             SP, SP, #8
    // 0xc13a24: tbnz            w0, #4, #0xc13a5c
    // 0xc13a28: ldr             d0, [fp, #0x10]
    // 0xc13a2c: ldr             x16, [fp, #0x18]
    // 0xc13a30: SaveReg r16
    //     0xc13a30: str             x16, [SP, #-8]!
    // 0xc13a34: r0 = _outerPosition()
    //     0xc13a34: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc13a38: add             SP, SP, #8
    // 0xc13a3c: cmp             w0, NULL
    // 0xc13a40: b.eq            #0xc14060
    // 0xc13a44: SaveReg r0
    //     0xc13a44: str             x0, [SP, #-8]!
    // 0xc13a48: ldr             d0, [fp, #0x10]
    // 0xc13a4c: SaveReg d0
    //     0xc13a4c: str             d0, [SP, #-8]!
    // 0xc13a50: r0 = applyFullDragUpdate()
    //     0xc13a50: bl              #0xc14718  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyFullDragUpdate
    // 0xc13a54: add             SP, SP, #0x10
    // 0xc13a58: b               #0xc14048
    // 0xc13a5c: ldr             d0, [fp, #0x10]
    // 0xc13a60: d1 = 0.000000
    //     0xc13a60: eor             v1.16b, v1.16b, v1.16b
    // 0xc13a64: fcmp            d0, d1
    // 0xc13a68: b.vs            #0xc13cbc
    // 0xc13a6c: b.ge            #0xc13cbc
    // 0xc13a70: ldr             x16, [fp, #0x18]
    // 0xc13a74: SaveReg r16
    //     0xc13a74: str             x16, [SP, #-8]!
    // 0xc13a78: r0 = _innerPositions()
    //     0xc13a78: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc13a7c: add             SP, SP, #8
    // 0xc13a80: r1 = LoadClassIdInstr(r0)
    //     0xc13a80: ldur            x1, [x0, #-1]
    //     0xc13a84: ubfx            x1, x1, #0xc, #0x14
    // 0xc13a88: SaveReg r0
    //     0xc13a88: str             x0, [SP, #-8]!
    // 0xc13a8c: mov             x0, x1
    // 0xc13a90: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc13a90: mov             x17, #0xb940
    //     0xc13a94: add             lr, x0, x17
    //     0xc13a98: ldr             lr, [x21, lr, lsl #3]
    //     0xc13a9c: blr             lr
    // 0xc13aa0: add             SP, SP, #8
    // 0xc13aa4: mov             x1, x0
    // 0xc13aa8: stur            x1, [fp, #-8]
    // 0xc13aac: ldr             d1, [fp, #0x10]
    // 0xc13ab0: ldr             d0, [fp, #0x10]
    // 0xc13ab4: stur            d1, [fp, #-0x30]
    // 0xc13ab8: CheckStackOverflow
    //     0xc13ab8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc13abc: cmp             SP, x16
    //     0xc13ac0: b.ls            #0xc14064
    // 0xc13ac4: r0 = LoadClassIdInstr(r1)
    //     0xc13ac4: ldur            x0, [x1, #-1]
    //     0xc13ac8: ubfx            x0, x0, #0xc, #0x14
    // 0xc13acc: SaveReg r1
    //     0xc13acc: str             x1, [SP, #-8]!
    // 0xc13ad0: r0 = GDT[cid_x0 + 0x541]()
    //     0xc13ad0: add             lr, x0, #0x541
    //     0xc13ad4: ldr             lr, [x21, lr, lsl #3]
    //     0xc13ad8: blr             lr
    // 0xc13adc: add             SP, SP, #8
    // 0xc13ae0: tbnz            w0, #4, #0xc13bb8
    // 0xc13ae4: ldur            x1, [fp, #-8]
    // 0xc13ae8: r0 = LoadClassIdInstr(r1)
    //     0xc13ae8: ldur            x0, [x1, #-1]
    //     0xc13aec: ubfx            x0, x0, #0xc, #0x14
    // 0xc13af0: SaveReg r1
    //     0xc13af0: str             x1, [SP, #-8]!
    // 0xc13af4: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc13af4: add             lr, x0, #0x5ca
    //     0xc13af8: ldr             lr, [x21, lr, lsl #3]
    //     0xc13afc: blr             lr
    // 0xc13b00: add             SP, SP, #8
    // 0xc13b04: LoadField: r1 = r0->field_43
    //     0xc13b04: ldur            w1, [x0, #0x43]
    // 0xc13b08: DecompressPointer r1
    //     0xc13b08: add             x1, x1, HEAP, lsl #32
    // 0xc13b0c: cmp             w1, NULL
    // 0xc13b10: b.eq            #0xc1406c
    // 0xc13b14: LoadField: d0 = r1->field_7
    //     0xc13b14: ldur            d0, [x1, #7]
    // 0xc13b18: d1 = 0.000000
    //     0xc13b18: eor             v1.16b, v1.16b, v1.16b
    // 0xc13b1c: fcmp            d0, d1
    // 0xc13b20: b.vs            #0xc13ba4
    // 0xc13b24: b.ge            #0xc13ba4
    // 0xc13b28: ldr             d0, [fp, #0x10]
    // 0xc13b2c: ldur            d2, [fp, #-0x30]
    // 0xc13b30: SaveReg r0
    //     0xc13b30: str             x0, [SP, #-8]!
    // 0xc13b34: SaveReg d0
    //     0xc13b34: str             d0, [SP, #-8]!
    // 0xc13b38: r0 = applyClampedDragUpdate()
    //     0xc13b38: bl              #0xc14114  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyClampedDragUpdate
    // 0xc13b3c: add             SP, SP, #0x10
    // 0xc13b40: mov             v1.16b, v0.16b
    // 0xc13b44: ldur            d0, [fp, #-0x30]
    // 0xc13b48: fcmp            d0, d1
    // 0xc13b4c: b.vs            #0xc13b5c
    // 0xc13b50: b.le            #0xc13b5c
    // 0xc13b54: d2 = 0.000000
    //     0xc13b54: eor             v2.16b, v2.16b, v2.16b
    // 0xc13b58: b               #0xc13b9c
    // 0xc13b5c: fcmp            d0, d1
    // 0xc13b60: b.vs            #0xc13b74
    // 0xc13b64: b.ge            #0xc13b74
    // 0xc13b68: mov             v0.16b, v1.16b
    // 0xc13b6c: d2 = 0.000000
    //     0xc13b6c: eor             v2.16b, v2.16b, v2.16b
    // 0xc13b70: b               #0xc13b9c
    // 0xc13b74: d2 = 0.000000
    //     0xc13b74: eor             v2.16b, v2.16b, v2.16b
    // 0xc13b78: fcmp            d0, d2
    // 0xc13b7c: b.vs            #0xc13b90
    // 0xc13b80: b.ne            #0xc13b90
    // 0xc13b84: fadd            d3, d0, d1
    // 0xc13b88: mov             v0.16b, v3.16b
    // 0xc13b8c: b               #0xc13b9c
    // 0xc13b90: fcmp            d1, d1
    // 0xc13b94: b.vc            #0xc13b9c
    // 0xc13b98: mov             v0.16b, v1.16b
    // 0xc13b9c: mov             v1.16b, v0.16b
    // 0xc13ba0: b               #0xc13bb0
    // 0xc13ba4: ldur            d0, [fp, #-0x30]
    // 0xc13ba8: mov             v2.16b, v1.16b
    // 0xc13bac: mov             v1.16b, v0.16b
    // 0xc13bb0: ldur            x1, [fp, #-8]
    // 0xc13bb4: b               #0xc13ab0
    // 0xc13bb8: ldur            d0, [fp, #-0x30]
    // 0xc13bbc: SaveReg d0
    //     0xc13bbc: str             d0, [SP, #-8]!
    // 0xc13bc0: r0 = DoubleEx.notZero()
    //     0xc13bc0: bl              #0xc140b8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ::DoubleEx.notZero
    // 0xc13bc4: add             SP, SP, #8
    // 0xc13bc8: tbnz            w0, #4, #0xc14048
    // 0xc13bcc: ldur            d0, [fp, #-0x30]
    // 0xc13bd0: ldr             x16, [fp, #0x18]
    // 0xc13bd4: SaveReg r16
    //     0xc13bd4: str             x16, [SP, #-8]!
    // 0xc13bd8: r0 = _outerPosition()
    //     0xc13bd8: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc13bdc: add             SP, SP, #8
    // 0xc13be0: cmp             w0, NULL
    // 0xc13be4: b.eq            #0xc14070
    // 0xc13be8: SaveReg r0
    //     0xc13be8: str             x0, [SP, #-8]!
    // 0xc13bec: ldur            d0, [fp, #-0x30]
    // 0xc13bf0: SaveReg d0
    //     0xc13bf0: str             d0, [SP, #-8]!
    // 0xc13bf4: r0 = applyClampedDragUpdate()
    //     0xc13bf4: bl              #0xc14114  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyClampedDragUpdate
    // 0xc13bf8: add             SP, SP, #0x10
    // 0xc13bfc: stur            d0, [fp, #-0x30]
    // 0xc13c00: SaveReg d0
    //     0xc13c00: str             d0, [SP, #-8]!
    // 0xc13c04: r0 = DoubleEx.notZero()
    //     0xc13c04: bl              #0xc140b8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ::DoubleEx.notZero
    // 0xc13c08: add             SP, SP, #8
    // 0xc13c0c: tbnz            w0, #4, #0xc14048
    // 0xc13c10: ldr             x16, [fp, #0x18]
    // 0xc13c14: SaveReg r16
    //     0xc13c14: str             x16, [SP, #-8]!
    // 0xc13c18: r0 = _innerPositions()
    //     0xc13c18: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc13c1c: add             SP, SP, #8
    // 0xc13c20: r1 = LoadClassIdInstr(r0)
    //     0xc13c20: ldur            x1, [x0, #-1]
    //     0xc13c24: ubfx            x1, x1, #0xc, #0x14
    // 0xc13c28: SaveReg r0
    //     0xc13c28: str             x0, [SP, #-8]!
    // 0xc13c2c: mov             x0, x1
    // 0xc13c30: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc13c30: mov             x17, #0xb940
    //     0xc13c34: add             lr, x0, x17
    //     0xc13c38: ldr             lr, [x21, lr, lsl #3]
    //     0xc13c3c: blr             lr
    // 0xc13c40: add             SP, SP, #8
    // 0xc13c44: mov             x1, x0
    // 0xc13c48: stur            x1, [fp, #-8]
    // 0xc13c4c: ldur            d0, [fp, #-0x30]
    // 0xc13c50: CheckStackOverflow
    //     0xc13c50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc13c54: cmp             SP, x16
    //     0xc13c58: b.ls            #0xc14074
    // 0xc13c5c: r0 = LoadClassIdInstr(r1)
    //     0xc13c5c: ldur            x0, [x1, #-1]
    //     0xc13c60: ubfx            x0, x0, #0xc, #0x14
    // 0xc13c64: SaveReg r1
    //     0xc13c64: str             x1, [SP, #-8]!
    // 0xc13c68: r0 = GDT[cid_x0 + 0x541]()
    //     0xc13c68: add             lr, x0, #0x541
    //     0xc13c6c: ldr             lr, [x21, lr, lsl #3]
    //     0xc13c70: blr             lr
    // 0xc13c74: add             SP, SP, #8
    // 0xc13c78: tbnz            w0, #4, #0xc14048
    // 0xc13c7c: ldur            d0, [fp, #-0x30]
    // 0xc13c80: ldur            x1, [fp, #-8]
    // 0xc13c84: r0 = LoadClassIdInstr(r1)
    //     0xc13c84: ldur            x0, [x1, #-1]
    //     0xc13c88: ubfx            x0, x0, #0xc, #0x14
    // 0xc13c8c: SaveReg r1
    //     0xc13c8c: str             x1, [SP, #-8]!
    // 0xc13c90: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc13c90: add             lr, x0, #0x5ca
    //     0xc13c94: ldr             lr, [x21, lr, lsl #3]
    //     0xc13c98: blr             lr
    // 0xc13c9c: add             SP, SP, #8
    // 0xc13ca0: SaveReg r0
    //     0xc13ca0: str             x0, [SP, #-8]!
    // 0xc13ca4: ldur            d0, [fp, #-0x30]
    // 0xc13ca8: SaveReg d0
    //     0xc13ca8: str             d0, [SP, #-8]!
    // 0xc13cac: r0 = applyFullDragUpdate()
    //     0xc13cac: bl              #0xc14718  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyFullDragUpdate
    // 0xc13cb0: add             SP, SP, #0x10
    // 0xc13cb4: ldur            x1, [fp, #-8]
    // 0xc13cb8: b               #0xc13c4c
    // 0xc13cbc: mov             v2.16b, v1.16b
    // 0xc13cc0: SaveReg d0
    //     0xc13cc0: str             d0, [SP, #-8]!
    // 0xc13cc4: r0 = DoubleEx.notZero()
    //     0xc13cc4: bl              #0xc140b8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ::DoubleEx.notZero
    // 0xc13cc8: add             SP, SP, #8
    // 0xc13ccc: tbnz            w0, #4, #0xc14048
    // 0xc13cd0: r16 = <double>
    //     0xc13cd0: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc13cd4: stp             xzr, x16, [SP, #-0x10]!
    // 0xc13cd8: r0 = _GrowableList()
    //     0xc13cd8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xc13cdc: add             SP, SP, #0x10
    // 0xc13ce0: stur            x0, [fp, #-8]
    // 0xc13ce4: ldr             x16, [fp, #0x18]
    // 0xc13ce8: SaveReg r16
    //     0xc13ce8: str             x16, [SP, #-8]!
    // 0xc13cec: r0 = _innerPositions()
    //     0xc13cec: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc13cf0: add             SP, SP, #8
    // 0xc13cf4: r1 = LoadClassIdInstr(r0)
    //     0xc13cf4: ldur            x1, [x0, #-1]
    //     0xc13cf8: ubfx            x1, x1, #0xc, #0x14
    // 0xc13cfc: SaveReg r0
    //     0xc13cfc: str             x0, [SP, #-8]!
    // 0xc13d00: mov             x0, x1
    // 0xc13d04: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc13d04: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc13d08: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0xc13d08: mov             x17, #0xc8a1
    //     0xc13d0c: add             lr, x0, x17
    //     0xc13d10: ldr             lr, [x21, lr, lsl #3]
    //     0xc13d14: blr             lr
    // 0xc13d18: add             SP, SP, #8
    // 0xc13d1c: mov             x1, x0
    // 0xc13d20: stur            x1, [fp, #-0x10]
    // 0xc13d24: r0 = LoadClassIdInstr(r1)
    //     0xc13d24: ldur            x0, [x1, #-1]
    //     0xc13d28: ubfx            x0, x0, #0xc, #0x14
    // 0xc13d2c: SaveReg r1
    //     0xc13d2c: str             x1, [SP, #-8]!
    // 0xc13d30: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc13d30: mov             x17, #0xb940
    //     0xc13d34: add             lr, x0, x17
    //     0xc13d38: ldr             lr, [x21, lr, lsl #3]
    //     0xc13d3c: blr             lr
    // 0xc13d40: add             SP, SP, #8
    // 0xc13d44: mov             x1, x0
    // 0xc13d48: stur            x1, [fp, #-0x18]
    // 0xc13d4c: ldur            x2, [fp, #-8]
    // 0xc13d50: d1 = 0.000000
    //     0xc13d50: eor             v1.16b, v1.16b, v1.16b
    // 0xc13d54: ldr             d0, [fp, #0x10]
    // 0xc13d58: stur            d1, [fp, #-0x30]
    // 0xc13d5c: CheckStackOverflow
    //     0xc13d5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc13d60: cmp             SP, x16
    //     0xc13d64: b.ls            #0xc1407c
    // 0xc13d68: r0 = LoadClassIdInstr(r1)
    //     0xc13d68: ldur            x0, [x1, #-1]
    //     0xc13d6c: ubfx            x0, x0, #0xc, #0x14
    // 0xc13d70: SaveReg r1
    //     0xc13d70: str             x1, [SP, #-8]!
    // 0xc13d74: r0 = GDT[cid_x0 + 0x541]()
    //     0xc13d74: add             lr, x0, #0x541
    //     0xc13d78: ldr             lr, [x21, lr, lsl #3]
    //     0xc13d7c: blr             lr
    // 0xc13d80: add             SP, SP, #8
    // 0xc13d84: tbnz            w0, #4, #0xc13ee8
    // 0xc13d88: ldr             d0, [fp, #0x10]
    // 0xc13d8c: ldur            x1, [fp, #-0x18]
    // 0xc13d90: ldur            d1, [fp, #-0x30]
    // 0xc13d94: r0 = LoadClassIdInstr(r1)
    //     0xc13d94: ldur            x0, [x1, #-1]
    //     0xc13d98: ubfx            x0, x0, #0xc, #0x14
    // 0xc13d9c: SaveReg r1
    //     0xc13d9c: str             x1, [SP, #-8]!
    // 0xc13da0: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc13da0: add             lr, x0, #0x5ca
    //     0xc13da4: ldr             lr, [x21, lr, lsl #3]
    //     0xc13da8: blr             lr
    // 0xc13dac: add             SP, SP, #8
    // 0xc13db0: SaveReg r0
    //     0xc13db0: str             x0, [SP, #-8]!
    // 0xc13db4: ldr             d0, [fp, #0x10]
    // 0xc13db8: SaveReg d0
    //     0xc13db8: str             d0, [SP, #-8]!
    // 0xc13dbc: r0 = applyClampedDragUpdate()
    //     0xc13dbc: bl              #0xc14114  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyClampedDragUpdate
    // 0xc13dc0: add             SP, SP, #0x10
    // 0xc13dc4: mov             v1.16b, v0.16b
    // 0xc13dc8: ldur            d0, [fp, #-0x30]
    // 0xc13dcc: stur            d1, [fp, #-0x40]
    // 0xc13dd0: fcmp            d0, d1
    // 0xc13dd4: b.vs            #0xc13de4
    // 0xc13dd8: b.le            #0xc13de4
    // 0xc13ddc: d2 = 0.000000
    //     0xc13ddc: eor             v2.16b, v2.16b, v2.16b
    // 0xc13de0: b               #0xc13e24
    // 0xc13de4: fcmp            d0, d1
    // 0xc13de8: b.vs            #0xc13dfc
    // 0xc13dec: b.ge            #0xc13dfc
    // 0xc13df0: mov             v0.16b, v1.16b
    // 0xc13df4: d2 = 0.000000
    //     0xc13df4: eor             v2.16b, v2.16b, v2.16b
    // 0xc13df8: b               #0xc13e24
    // 0xc13dfc: d2 = 0.000000
    //     0xc13dfc: eor             v2.16b, v2.16b, v2.16b
    // 0xc13e00: fcmp            d0, d2
    // 0xc13e04: b.vs            #0xc13e18
    // 0xc13e08: b.ne            #0xc13e18
    // 0xc13e0c: fadd            d3, d0, d1
    // 0xc13e10: mov             v0.16b, v3.16b
    // 0xc13e14: b               #0xc13e24
    // 0xc13e18: fcmp            d1, d1
    // 0xc13e1c: b.vc            #0xc13e24
    // 0xc13e20: mov             v0.16b, v1.16b
    // 0xc13e24: ldur            x0, [fp, #-8]
    // 0xc13e28: stur            d0, [fp, #-0x38]
    // 0xc13e2c: LoadField: r1 = r0->field_b
    //     0xc13e2c: ldur            w1, [x0, #0xb]
    // 0xc13e30: DecompressPointer r1
    //     0xc13e30: add             x1, x1, HEAP, lsl #32
    // 0xc13e34: stur            x1, [fp, #-0x20]
    // 0xc13e38: LoadField: r2 = r0->field_f
    //     0xc13e38: ldur            w2, [x0, #0xf]
    // 0xc13e3c: DecompressPointer r2
    //     0xc13e3c: add             x2, x2, HEAP, lsl #32
    // 0xc13e40: LoadField: r3 = r2->field_b
    //     0xc13e40: ldur            w3, [x2, #0xb]
    // 0xc13e44: DecompressPointer r3
    //     0xc13e44: add             x3, x3, HEAP, lsl #32
    // 0xc13e48: cmp             w1, w3
    // 0xc13e4c: b.ne            #0xc13e5c
    // 0xc13e50: SaveReg r0
    //     0xc13e50: str             x0, [SP, #-8]!
    // 0xc13e54: r0 = _growToNextCapacity()
    //     0xc13e54: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc13e58: add             SP, SP, #8
    // 0xc13e5c: ldur            x2, [fp, #-8]
    // 0xc13e60: ldur            d0, [fp, #-0x40]
    // 0xc13e64: ldur            x0, [fp, #-0x20]
    // 0xc13e68: r3 = LoadInt32Instr(r0)
    //     0xc13e68: sbfx            x3, x0, #1, #0x1f
    // 0xc13e6c: add             x0, x3, #1
    // 0xc13e70: lsl             x1, x0, #1
    // 0xc13e74: StoreField: r2->field_b = r1
    //     0xc13e74: stur            w1, [x2, #0xb]
    // 0xc13e78: mov             x1, x3
    // 0xc13e7c: cmp             x1, x0
    // 0xc13e80: b.hs            #0xc14084
    // 0xc13e84: LoadField: r1 = r2->field_f
    //     0xc13e84: ldur            w1, [x2, #0xf]
    // 0xc13e88: DecompressPointer r1
    //     0xc13e88: add             x1, x1, HEAP, lsl #32
    // 0xc13e8c: r0 = inline_Allocate_Double()
    //     0xc13e8c: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xc13e90: add             x0, x0, #0x10
    //     0xc13e94: cmp             x4, x0
    //     0xc13e98: b.ls            #0xc14088
    //     0xc13e9c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc13ea0: sub             x0, x0, #0xf
    //     0xc13ea4: mov             x4, #0xd108
    //     0xc13ea8: movk            x4, #3, lsl #16
    //     0xc13eac: stur            x4, [x0, #-1]
    // 0xc13eb0: StoreField: r0->field_7 = d0
    //     0xc13eb0: stur            d0, [x0, #7]
    // 0xc13eb4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc13eb4: add             x25, x1, x3, lsl #2
    //     0xc13eb8: add             x25, x25, #0xf
    //     0xc13ebc: str             w0, [x25]
    //     0xc13ec0: tbz             w0, #0, #0xc13edc
    //     0xc13ec4: ldurb           w16, [x1, #-1]
    //     0xc13ec8: ldurb           w17, [x0, #-1]
    //     0xc13ecc: and             x16, x17, x16, lsr #2
    //     0xc13ed0: tst             x16, HEAP, lsr #32
    //     0xc13ed4: b.eq            #0xc13edc
    //     0xc13ed8: bl              #0xd67e5c
    // 0xc13edc: ldur            d1, [fp, #-0x38]
    // 0xc13ee0: ldur            x1, [fp, #-0x18]
    // 0xc13ee4: b               #0xc13d54
    // 0xc13ee8: ldur            x2, [fp, #-8]
    // 0xc13eec: ldur            d0, [fp, #-0x30]
    // 0xc13ef0: SaveReg d0
    //     0xc13ef0: str             d0, [SP, #-8]!
    // 0xc13ef4: r0 = DoubleEx.notZero()
    //     0xc13ef4: bl              #0xc140b8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ::DoubleEx.notZero
    // 0xc13ef8: add             SP, SP, #8
    // 0xc13efc: tbnz            w0, #4, #0xc13f44
    // 0xc13f00: ldur            d0, [fp, #-0x30]
    // 0xc13f04: ldr             x16, [fp, #0x18]
    // 0xc13f08: SaveReg r16
    //     0xc13f08: str             x16, [SP, #-8]!
    // 0xc13f0c: r0 = _outerPosition()
    //     0xc13f0c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc13f10: add             SP, SP, #8
    // 0xc13f14: cmp             w0, NULL
    // 0xc13f18: b.eq            #0xc140a8
    // 0xc13f1c: SaveReg r0
    //     0xc13f1c: str             x0, [SP, #-8]!
    // 0xc13f20: ldur            d0, [fp, #-0x30]
    // 0xc13f24: SaveReg d0
    //     0xc13f24: str             d0, [SP, #-8]!
    // 0xc13f28: r0 = applyClampedDragUpdate()
    //     0xc13f28: bl              #0xc14114  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyClampedDragUpdate
    // 0xc13f2c: add             SP, SP, #0x10
    // 0xc13f30: mov             v1.16b, v0.16b
    // 0xc13f34: ldur            d0, [fp, #-0x30]
    // 0xc13f38: fsub            d2, d0, d1
    // 0xc13f3c: mov             v0.16b, v2.16b
    // 0xc13f40: b               #0xc13f48
    // 0xc13f44: ldur            d0, [fp, #-0x30]
    // 0xc13f48: stur            d0, [fp, #-0x30]
    // 0xc13f4c: r3 = 0
    //     0xc13f4c: mov             x3, #0
    // 0xc13f50: ldur            x1, [fp, #-8]
    // 0xc13f54: ldur            x2, [fp, #-0x10]
    // 0xc13f58: stur            x3, [fp, #-0x28]
    // 0xc13f5c: CheckStackOverflow
    //     0xc13f5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc13f60: cmp             SP, x16
    //     0xc13f64: b.ls            #0xc140ac
    // 0xc13f68: r0 = LoadClassIdInstr(r2)
    //     0xc13f68: ldur            x0, [x2, #-1]
    //     0xc13f6c: ubfx            x0, x0, #0xc, #0x14
    // 0xc13f70: SaveReg r2
    //     0xc13f70: str             x2, [SP, #-8]!
    // 0xc13f74: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc13f74: mov             x17, #0xb8ea
    //     0xc13f78: add             lr, x0, x17
    //     0xc13f7c: ldr             lr, [x21, lr, lsl #3]
    //     0xc13f80: blr             lr
    // 0xc13f84: add             SP, SP, #8
    // 0xc13f88: r1 = LoadInt32Instr(r0)
    //     0xc13f88: sbfx            x1, x0, #1, #0x1f
    // 0xc13f8c: ldur            x2, [fp, #-0x28]
    // 0xc13f90: cmp             x2, x1
    // 0xc13f94: b.ge            #0xc14048
    // 0xc13f98: ldur            x3, [fp, #-8]
    // 0xc13f9c: ldur            d0, [fp, #-0x30]
    // 0xc13fa0: d1 = 0.000000
    //     0xc13fa0: eor             v1.16b, v1.16b, v1.16b
    // 0xc13fa4: LoadField: r0 = r3->field_b
    //     0xc13fa4: ldur            w0, [x3, #0xb]
    // 0xc13fa8: DecompressPointer r0
    //     0xc13fa8: add             x0, x0, HEAP, lsl #32
    // 0xc13fac: r1 = LoadInt32Instr(r0)
    //     0xc13fac: sbfx            x1, x0, #1, #0x1f
    // 0xc13fb0: mov             x0, x1
    // 0xc13fb4: mov             x1, x2
    // 0xc13fb8: cmp             x1, x0
    // 0xc13fbc: b.hs            #0xc140b4
    // 0xc13fc0: LoadField: r4 = r3->field_f
    //     0xc13fc0: ldur            w4, [x3, #0xf]
    // 0xc13fc4: DecompressPointer r4
    //     0xc13fc4: add             x4, x4, HEAP, lsl #32
    // 0xc13fc8: r0 = BoxInt64Instr(r2)
    //     0xc13fc8: sbfiz           x0, x2, #1, #0x1f
    //     0xc13fcc: cmp             x2, x0, asr #1
    //     0xc13fd0: b.eq            #0xc13fdc
    //     0xc13fd4: bl              #0xd69c6c
    //     0xc13fd8: stur            x2, [x0, #7]
    // 0xc13fdc: ArrayLoad: r1 = r4[r2]  ; Unknown_4
    //     0xc13fdc: add             x16, x4, x2, lsl #2
    //     0xc13fe0: ldur            w1, [x16, #0xf]
    // 0xc13fe4: DecompressPointer r1
    //     0xc13fe4: add             x1, x1, HEAP, lsl #32
    // 0xc13fe8: LoadField: d2 = r1->field_7
    //     0xc13fe8: ldur            d2, [x1, #7]
    // 0xc13fec: fsub            d3, d2, d0
    // 0xc13ff0: stur            d3, [fp, #-0x38]
    // 0xc13ff4: fcmp            d3, d1
    // 0xc13ff8: b.vs            #0xc14038
    // 0xc13ffc: b.le            #0xc14038
    // 0xc14000: ldur            x1, [fp, #-0x10]
    // 0xc14004: r4 = LoadClassIdInstr(r1)
    //     0xc14004: ldur            x4, [x1, #-1]
    //     0xc14008: ubfx            x4, x4, #0xc, #0x14
    // 0xc1400c: stp             x0, x1, [SP, #-0x10]!
    // 0xc14010: mov             x0, x4
    // 0xc14014: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc14014: sub             lr, x0, #0xd83
    //     0xc14018: ldr             lr, [x21, lr, lsl #3]
    //     0xc1401c: blr             lr
    // 0xc14020: add             SP, SP, #0x10
    // 0xc14024: SaveReg r0
    //     0xc14024: str             x0, [SP, #-8]!
    // 0xc14028: ldur            d0, [fp, #-0x38]
    // 0xc1402c: SaveReg d0
    //     0xc1402c: str             d0, [SP, #-8]!
    // 0xc14030: r0 = applyFullDragUpdate()
    //     0xc14030: bl              #0xc14718  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyFullDragUpdate
    // 0xc14034: add             SP, SP, #0x10
    // 0xc14038: ldur            x1, [fp, #-0x28]
    // 0xc1403c: add             x3, x1, #1
    // 0xc14040: ldur            d0, [fp, #-0x30]
    // 0xc14044: b               #0xc13f50
    // 0xc14048: r0 = Null
    //     0xc14048: mov             x0, NULL
    // 0xc1404c: LeaveFrame
    //     0xc1404c: mov             SP, fp
    //     0xc14050: ldp             fp, lr, [SP], #0x10
    // 0xc14054: ret
    //     0xc14054: ret             
    // 0xc14058: r0 = StackOverflowSharedWithFPURegs()
    //     0xc14058: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc1405c: b               #0xc139bc
    // 0xc14060: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc14060: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc14064: r0 = StackOverflowSharedWithFPURegs()
    //     0xc14064: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc14068: b               #0xc13ac4
    // 0xc1406c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1406c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc14070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc14070: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc14074: r0 = StackOverflowSharedWithFPURegs()
    //     0xc14074: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc14078: b               #0xc13c5c
    // 0xc1407c: r0 = StackOverflowSharedWithFPURegs()
    //     0xc1407c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc14080: b               #0xc13d68
    // 0xc14084: r0 = RangeErrorSharedWithFPURegs()
    //     0xc14084: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xc14088: SaveReg d0
    //     0xc14088: str             q0, [SP, #-0x10]!
    // 0xc1408c: stp             x2, x3, [SP, #-0x10]!
    // 0xc14090: SaveReg r1
    //     0xc14090: str             x1, [SP, #-8]!
    // 0xc14094: r0 = AllocateDouble()
    //     0xc14094: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc14098: RestoreReg r1
    //     0xc14098: ldr             x1, [SP], #8
    // 0xc1409c: ldp             x2, x3, [SP], #0x10
    // 0xc140a0: RestoreReg d0
    //     0xc140a0: ldr             q0, [SP], #0x10
    // 0xc140a4: b               #0xc13eb0
    // 0xc140a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc140a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc140ac: r0 = StackOverflowSharedWithFPURegs()
    //     0xc140ac: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc140b0: b               #0xc13f68
    // 0xc140b4: r0 = RangeErrorSharedWithFPURegs()
    //     0xc140b4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  _ goIdle(/* No info */) {
    // ** addr: 0xc37628, size: 0x70
    // 0xc37628: EnterFrame
    //     0xc37628: stp             fp, lr, [SP, #-0x10]!
    //     0xc3762c: mov             fp, SP
    // 0xc37630: CheckStackOverflow
    //     0xc37630: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc37634: cmp             SP, x16
    //     0xc37638: b.ls            #0xc3768c
    // 0xc3763c: ldr             x16, [fp, #0x10]
    // 0xc37640: SaveReg r16
    //     0xc37640: str             x16, [SP, #-8]!
    // 0xc37644: r0 = _outerPosition()
    //     0xc37644: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc37648: add             SP, SP, #8
    // 0xc3764c: cmp             w0, NULL
    // 0xc37650: b.eq            #0xc37694
    // 0xc37654: SaveReg r0
    //     0xc37654: str             x0, [SP, #-8]!
    // 0xc37658: r0 = _createIdleScrollActivity()
    //     0xc37658: bl              #0xc37878  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_createIdleScrollActivity
    // 0xc3765c: add             SP, SP, #8
    // 0xc37660: ldr             x16, [fp, #0x10]
    // 0xc37664: stp             x0, x16, [SP, #-0x10]!
    // 0xc37668: r16 = Closure: (_NestedScrollPosition) => IdleScrollActivity from Function '_createIdleScrollActivity@454231548': static.
    //     0xc37668: add             x16, PP, #0x40, lsl #12  ; [pp+0x40dc0] Closure: (_NestedScrollPosition) => IdleScrollActivity from Function '_createIdleScrollActivity@454231548': static. (0x7fe6e2437898)
    //     0xc3766c: ldr             x16, [x16, #0xdc0]
    // 0xc37670: SaveReg r16
    //     0xc37670: str             x16, [SP, #-8]!
    // 0xc37674: r0 = beginActivity()
    //     0xc37674: bl              #0xc37698  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::beginActivity
    // 0xc37678: add             SP, SP, #0x18
    // 0xc3767c: r0 = Null
    //     0xc3767c: mov             x0, NULL
    // 0xc37680: LeaveFrame
    //     0xc37680: mov             SP, fp
    //     0xc37684: ldp             fp, lr, [SP], #0x10
    // 0xc37688: ret
    //     0xc37688: ret             
    // 0xc3768c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3768c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc37690: b               #0xc3763c
    // 0xc37694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc37694: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ beginActivity(/* No info */) {
    // ** addr: 0xc37698, size: 0x1e0
    // 0xc37698: EnterFrame
    //     0xc37698: stp             fp, lr, [SP, #-0x10]!
    //     0xc3769c: mov             fp, SP
    // 0xc376a0: AllocStack(0x20)
    //     0xc376a0: sub             SP, SP, #0x20
    // 0xc376a4: CheckStackOverflow
    //     0xc376a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc376a8: cmp             SP, x16
    //     0xc376ac: b.ls            #0xc37864
    // 0xc376b0: ldr             x16, [fp, #0x20]
    // 0xc376b4: SaveReg r16
    //     0xc376b4: str             x16, [SP, #-8]!
    // 0xc376b8: r0 = _outerPosition()
    //     0xc376b8: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc376bc: add             SP, SP, #8
    // 0xc376c0: cmp             w0, NULL
    // 0xc376c4: b.eq            #0xc3786c
    // 0xc376c8: ldr             x16, [fp, #0x18]
    // 0xc376cc: stp             x16, x0, [SP, #-0x10]!
    // 0xc376d0: r0 = beginActivity()
    //     0xc376d0: bl              #0xbff1c4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::beginActivity
    // 0xc376d4: add             SP, SP, #0x10
    // 0xc376d8: ldr             x0, [fp, #0x18]
    // 0xc376dc: r1 = LoadClassIdInstr(r0)
    //     0xc376dc: ldur            x1, [x0, #-1]
    //     0xc376e0: ubfx            x1, x1, #0xc, #0x14
    // 0xc376e4: SaveReg r0
    //     0xc376e4: str             x0, [SP, #-8]!
    // 0xc376e8: mov             x0, x1
    // 0xc376ec: r0 = GDT[cid_x0 + -0x1000]()
    //     0xc376ec: sub             lr, x0, #1, lsl #12
    //     0xc376f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc376f4: blr             lr
    // 0xc376f8: add             SP, SP, #8
    // 0xc376fc: stur            x0, [fp, #-8]
    // 0xc37700: ldr             x16, [fp, #0x20]
    // 0xc37704: SaveReg r16
    //     0xc37704: str             x16, [SP, #-8]!
    // 0xc37708: r0 = _innerPositions()
    //     0xc37708: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc3770c: add             SP, SP, #8
    // 0xc37710: r1 = LoadClassIdInstr(r0)
    //     0xc37710: ldur            x1, [x0, #-1]
    //     0xc37714: ubfx            x1, x1, #0xc, #0x14
    // 0xc37718: SaveReg r0
    //     0xc37718: str             x0, [SP, #-8]!
    // 0xc3771c: mov             x0, x1
    // 0xc37720: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc37720: mov             x17, #0xb940
    //     0xc37724: add             lr, x0, x17
    //     0xc37728: ldr             lr, [x21, lr, lsl #3]
    //     0xc3772c: blr             lr
    // 0xc37730: add             SP, SP, #8
    // 0xc37734: mov             x1, x0
    // 0xc37738: stur            x1, [fp, #-0x10]
    // 0xc3773c: ldur            x2, [fp, #-8]
    // 0xc37740: stur            x2, [fp, #-8]
    // 0xc37744: CheckStackOverflow
    //     0xc37744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc37748: cmp             SP, x16
    //     0xc3774c: b.ls            #0xc37870
    // 0xc37750: r0 = LoadClassIdInstr(r1)
    //     0xc37750: ldur            x0, [x1, #-1]
    //     0xc37754: ubfx            x0, x0, #0xc, #0x14
    // 0xc37758: SaveReg r1
    //     0xc37758: str             x1, [SP, #-8]!
    // 0xc3775c: r0 = GDT[cid_x0 + 0x541]()
    //     0xc3775c: add             lr, x0, #0x541
    //     0xc37760: ldr             lr, [x21, lr, lsl #3]
    //     0xc37764: blr             lr
    // 0xc37768: add             SP, SP, #8
    // 0xc3776c: tbnz            w0, #4, #0xc3780c
    // 0xc37770: ldur            x1, [fp, #-0x10]
    // 0xc37774: ldur            x2, [fp, #-8]
    // 0xc37778: r0 = LoadClassIdInstr(r1)
    //     0xc37778: ldur            x0, [x1, #-1]
    //     0xc3777c: ubfx            x0, x0, #0xc, #0x14
    // 0xc37780: SaveReg r1
    //     0xc37780: str             x1, [SP, #-8]!
    // 0xc37784: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc37784: add             lr, x0, #0x5ca
    //     0xc37788: ldr             lr, [x21, lr, lsl #3]
    //     0xc3778c: blr             lr
    // 0xc37790: add             SP, SP, #8
    // 0xc37794: mov             x1, x0
    // 0xc37798: stur            x1, [fp, #-0x18]
    // 0xc3779c: ldr             x16, [fp, #0x10]
    // 0xc377a0: stp             x1, x16, [SP, #-0x10]!
    // 0xc377a4: ldr             x0, [fp, #0x10]
    // 0xc377a8: ClosureCall
    //     0xc377a8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc377ac: ldur            x2, [x0, #0x1f]
    //     0xc377b0: blr             x2
    // 0xc377b4: add             SP, SP, #0x10
    // 0xc377b8: stur            x0, [fp, #-0x20]
    // 0xc377bc: ldur            x16, [fp, #-0x18]
    // 0xc377c0: stp             x0, x16, [SP, #-0x10]!
    // 0xc377c4: r0 = beginActivity()
    //     0xc377c4: bl              #0xbff1c4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::beginActivity
    // 0xc377c8: add             SP, SP, #0x10
    // 0xc377cc: ldur            x0, [fp, #-8]
    // 0xc377d0: tbnz            w0, #4, #0xc37800
    // 0xc377d4: ldur            x0, [fp, #-0x20]
    // 0xc377d8: r1 = LoadClassIdInstr(r0)
    //     0xc377d8: ldur            x1, [x0, #-1]
    //     0xc377dc: ubfx            x1, x1, #0xc, #0x14
    // 0xc377e0: SaveReg r0
    //     0xc377e0: str             x0, [SP, #-8]!
    // 0xc377e4: mov             x0, x1
    // 0xc377e8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xc377e8: sub             lr, x0, #1, lsl #12
    //     0xc377ec: ldr             lr, [x21, lr, lsl #3]
    //     0xc377f0: blr             lr
    // 0xc377f4: add             SP, SP, #8
    // 0xc377f8: mov             x2, x0
    // 0xc377fc: b               #0xc37804
    // 0xc37800: r2 = false
    //     0xc37800: add             x2, NULL, #0x30  ; false
    // 0xc37804: ldur            x1, [fp, #-0x10]
    // 0xc37808: b               #0xc37740
    // 0xc3780c: ldr             x1, [fp, #0x20]
    // 0xc37810: ldur            x0, [fp, #-8]
    // 0xc37814: LoadField: r2 = r1->field_23
    //     0xc37814: ldur            w2, [x1, #0x23]
    // 0xc37818: DecompressPointer r2
    //     0xc37818: add             x2, x2, HEAP, lsl #32
    // 0xc3781c: cmp             w2, NULL
    // 0xc37820: b.eq            #0xc37838
    // 0xc37824: SaveReg r2
    //     0xc37824: str             x2, [SP, #-8]!
    // 0xc37828: r0 = dispose()
    //     0xc37828: bl              #0x9c2270  ; [package:flutter/src/widgets/scroll_activity.dart] ScrollDragController::dispose
    // 0xc3782c: add             SP, SP, #8
    // 0xc37830: ldr             x1, [fp, #0x20]
    // 0xc37834: ldur            x0, [fp, #-8]
    // 0xc37838: StoreField: r1->field_23 = rNULL
    //     0xc37838: stur            NULL, [x1, #0x23]
    // 0xc3783c: tbz             w0, #4, #0xc37854
    // 0xc37840: r16 = Instance_ScrollDirection
    //     0xc37840: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f8c0] Obj!ScrollDirection@b646f1
    //     0xc37844: ldr             x16, [x16, #0x8c0]
    // 0xc37848: stp             x16, x1, [SP, #-0x10]!
    // 0xc3784c: r0 = updateUserScrollDirection()
    //     0xc3784c: bl              #0xc116d0  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::updateUserScrollDirection
    // 0xc37850: add             SP, SP, #0x10
    // 0xc37854: r0 = Null
    //     0xc37854: mov             x0, NULL
    // 0xc37858: LeaveFrame
    //     0xc37858: mov             SP, fp
    //     0xc3785c: ldp             fp, lr, [SP], #0x10
    // 0xc37860: ret
    //     0xc37860: ret             
    // 0xc37864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc37864: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc37868: b               #0xc376b0
    // 0xc3786c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc3786c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc37870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc37870: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc37874: b               #0xc37750
  }
  static _ _createIdleScrollActivity(/* No info */) {
    // ** addr: 0xc37878, size: 0x20
    // 0xc37878: EnterFrame
    //     0xc37878: stp             fp, lr, [SP, #-0x10]!
    //     0xc3787c: mov             fp, SP
    // 0xc37880: r0 = IdleScrollActivity()
    //     0xc37880: bl              #0x81ce04  ; AllocateIdleScrollActivityStub -> IdleScrollActivity (size=0xc)
    // 0xc37884: ldr             x1, [fp, #0x10]
    // 0xc37888: StoreField: r0->field_7 = r1
    //     0xc37888: stur            w1, [x0, #7]
    // 0xc3788c: LeaveFrame
    //     0xc3788c: mov             SP, fp
    //     0xc37890: ldp             fp, lr, [SP], #0x10
    // 0xc37894: ret
    //     0xc37894: ret             
  }
  [closure] static IdleScrollActivity _createIdleScrollActivity(dynamic, _NestedScrollPosition) {
    // ** addr: 0xc37898, size: 0x38
    // 0xc37898: EnterFrame
    //     0xc37898: stp             fp, lr, [SP, #-0x10]!
    //     0xc3789c: mov             fp, SP
    // 0xc378a0: CheckStackOverflow
    //     0xc378a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc378a4: cmp             SP, x16
    //     0xc378a8: b.ls            #0xc378c8
    // 0xc378ac: ldr             x16, [fp, #0x10]
    // 0xc378b0: SaveReg r16
    //     0xc378b0: str             x16, [SP, #-8]!
    // 0xc378b4: r0 = _createIdleScrollActivity()
    //     0xc378b4: bl              #0xc37878  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_createIdleScrollActivity
    // 0xc378b8: add             SP, SP, #8
    // 0xc378bc: LeaveFrame
    //     0xc378bc: mov             SP, fp
    //     0xc378c0: ldp             fp, lr, [SP], #0x10
    // 0xc378c4: ret
    //     0xc378c4: ret             
    // 0xc378c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc378c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc378cc: b               #0xc378ac
  }
  _ drag(/* No info */) {
    // ** addr: 0xc4365c, size: 0x114
    // 0xc4365c: EnterFrame
    //     0xc4365c: stp             fp, lr, [SP, #-0x10]!
    //     0xc43660: mov             fp, SP
    // 0xc43664: AllocStack(0x20)
    //     0xc43664: sub             SP, SP, #0x20
    // 0xc43668: CheckStackOverflow
    //     0xc43668: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4366c: cmp             SP, x16
    //     0xc43670: b.ls            #0xc43764
    // 0xc43674: r0 = ScrollDragController()
    //     0xc43674: bl              #0xc435cc  ; AllocateScrollDragControllerStub -> ScrollDragController (size=0x2c)
    // 0xc43678: mov             x1, x0
    // 0xc4367c: ldr             x0, [fp, #0x10]
    // 0xc43680: stur            x1, [fp, #-8]
    // 0xc43684: StoreField: r1->field_b = r0
    //     0xc43684: stur            w0, [x1, #0xb]
    // 0xc43688: ldr             x0, [fp, #0x20]
    // 0xc4368c: StoreField: r1->field_7 = r0
    //     0xc4368c: stur            w0, [x1, #7]
    // 0xc43690: ldr             x2, [fp, #0x18]
    // 0xc43694: StoreField: r1->field_27 = r2
    //     0xc43694: stur            w2, [x1, #0x27]
    // 0xc43698: r3 = false
    //     0xc43698: add             x3, NULL, #0x30  ; false
    // 0xc4369c: StoreField: r1->field_1b = r3
    //     0xc4369c: stur            w3, [x1, #0x1b]
    // 0xc436a0: LoadField: r3 = r2->field_7
    //     0xc436a0: ldur            w3, [x2, #7]
    // 0xc436a4: DecompressPointer r3
    //     0xc436a4: add             x3, x3, HEAP, lsl #32
    // 0xc436a8: StoreField: r1->field_17 = r3
    //     0xc436a8: stur            w3, [x1, #0x17]
    // 0xc436ac: LoadField: r3 = r2->field_13
    //     0xc436ac: ldur            w3, [x2, #0x13]
    // 0xc436b0: DecompressPointer r3
    //     0xc436b0: add             x3, x3, HEAP, lsl #32
    // 0xc436b4: StoreField: r1->field_23 = r3
    //     0xc436b4: stur            w3, [x1, #0x23]
    // 0xc436b8: r1 = 1
    //     0xc436b8: mov             x1, #1
    // 0xc436bc: r0 = AllocateContext()
    //     0xc436bc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc436c0: mov             x1, x0
    // 0xc436c4: ldur            x0, [fp, #-8]
    // 0xc436c8: stur            x1, [fp, #-0x10]
    // 0xc436cc: StoreField: r1->field_f = r0
    //     0xc436cc: stur            w0, [x1, #0xf]
    // 0xc436d0: ldr             x16, [fp, #0x20]
    // 0xc436d4: SaveReg r16
    //     0xc436d4: str             x16, [SP, #-8]!
    // 0xc436d8: r0 = _outerPosition()
    //     0xc436d8: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc436dc: add             SP, SP, #8
    // 0xc436e0: stur            x0, [fp, #-0x18]
    // 0xc436e4: cmp             w0, NULL
    // 0xc436e8: b.eq            #0xc4376c
    // 0xc436ec: r0 = DragScrollActivity()
    //     0xc436ec: bl              #0xc435c0  ; AllocateDragScrollActivityStub -> DragScrollActivity (size=0x10)
    // 0xc436f0: mov             x3, x0
    // 0xc436f4: ldur            x0, [fp, #-8]
    // 0xc436f8: stur            x3, [fp, #-0x20]
    // 0xc436fc: StoreField: r3->field_b = r0
    //     0xc436fc: stur            w0, [x3, #0xb]
    // 0xc43700: ldur            x1, [fp, #-0x18]
    // 0xc43704: StoreField: r3->field_7 = r1
    //     0xc43704: stur            w1, [x3, #7]
    // 0xc43708: ldur            x2, [fp, #-0x10]
    // 0xc4370c: r1 = Function '<anonymous closure>':.
    //     0xc4370c: add             x1, PP, #0x51, lsl #12  ; [pp+0x511f8] AnonymousClosure: (0xc43770), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::drag (0xc4365c)
    //     0xc43710: ldr             x1, [x1, #0x1f8]
    // 0xc43714: r0 = AllocateClosure()
    //     0xc43714: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc43718: ldr             x16, [fp, #0x20]
    // 0xc4371c: ldur            lr, [fp, #-0x20]
    // 0xc43720: stp             lr, x16, [SP, #-0x10]!
    // 0xc43724: SaveReg r0
    //     0xc43724: str             x0, [SP, #-8]!
    // 0xc43728: r0 = beginActivity()
    //     0xc43728: bl              #0xc37698  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::beginActivity
    // 0xc4372c: add             SP, SP, #0x18
    // 0xc43730: ldur            x0, [fp, #-8]
    // 0xc43734: ldr             x1, [fp, #0x20]
    // 0xc43738: StoreField: r1->field_23 = r0
    //     0xc43738: stur            w0, [x1, #0x23]
    //     0xc4373c: ldurb           w16, [x1, #-1]
    //     0xc43740: ldurb           w17, [x0, #-1]
    //     0xc43744: and             x16, x17, x16, lsr #2
    //     0xc43748: tst             x16, HEAP, lsr #32
    //     0xc4374c: b.eq            #0xc43754
    //     0xc43750: bl              #0xd6826c
    // 0xc43754: ldur            x0, [fp, #-8]
    // 0xc43758: LeaveFrame
    //     0xc43758: mov             SP, fp
    //     0xc4375c: ldp             fp, lr, [SP], #0x10
    // 0xc43760: ret
    //     0xc43760: ret             
    // 0xc43764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43764: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc43768: b               #0xc43674
    // 0xc4376c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc4376c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] DragScrollActivity <anonymous closure>(dynamic, _NestedScrollPosition) {
    // ** addr: 0xc43770, size: 0x44
    // 0xc43770: EnterFrame
    //     0xc43770: stp             fp, lr, [SP, #-0x10]!
    //     0xc43774: mov             fp, SP
    // 0xc43778: AllocStack(0x8)
    //     0xc43778: sub             SP, SP, #8
    // 0xc4377c: SetupParameters()
    //     0xc4377c: ldr             x0, [fp, #0x18]
    //     0xc43780: ldur            w1, [x0, #0x17]
    //     0xc43784: add             x1, x1, HEAP, lsl #32
    // 0xc43788: LoadField: r0 = r1->field_f
    //     0xc43788: ldur            w0, [x1, #0xf]
    // 0xc4378c: DecompressPointer r0
    //     0xc4378c: add             x0, x0, HEAP, lsl #32
    // 0xc43790: stur            x0, [fp, #-8]
    // 0xc43794: r0 = DragScrollActivity()
    //     0xc43794: bl              #0xc435c0  ; AllocateDragScrollActivityStub -> DragScrollActivity (size=0x10)
    // 0xc43798: ldur            x1, [fp, #-8]
    // 0xc4379c: StoreField: r0->field_b = r1
    //     0xc4379c: stur            w1, [x0, #0xb]
    // 0xc437a0: ldr             x1, [fp, #0x10]
    // 0xc437a4: StoreField: r0->field_7 = r1
    //     0xc437a4: stur            w1, [x0, #7]
    // 0xc437a8: LeaveFrame
    //     0xc437a8: mov             SP, fp
    //     0xc437ac: ldp             fp, lr, [SP], #0x10
    // 0xc437b0: ret
    //     0xc437b0: ret             
  }
  _ hold(/* No info */) {
    // ** addr: 0xc43e3c, size: 0x94
    // 0xc43e3c: EnterFrame
    //     0xc43e3c: stp             fp, lr, [SP, #-0x10]!
    //     0xc43e40: mov             fp, SP
    // 0xc43e44: AllocStack(0x10)
    //     0xc43e44: sub             SP, SP, #0x10
    // 0xc43e48: CheckStackOverflow
    //     0xc43e48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc43e4c: cmp             SP, x16
    //     0xc43e50: b.ls            #0xc43ec4
    // 0xc43e54: ldr             x16, [fp, #0x18]
    // 0xc43e58: SaveReg r16
    //     0xc43e58: str             x16, [SP, #-8]!
    // 0xc43e5c: r0 = _outerPosition()
    //     0xc43e5c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc43e60: add             SP, SP, #8
    // 0xc43e64: stur            x0, [fp, #-8]
    // 0xc43e68: cmp             w0, NULL
    // 0xc43e6c: b.eq            #0xc43ecc
    // 0xc43e70: r0 = HoldScrollActivity()
    //     0xc43e70: bl              #0xc43dc0  ; AllocateHoldScrollActivityStub -> HoldScrollActivity (size=0x10)
    // 0xc43e74: mov             x3, x0
    // 0xc43e78: ldr             x0, [fp, #0x10]
    // 0xc43e7c: stur            x3, [fp, #-0x10]
    // 0xc43e80: StoreField: r3->field_b = r0
    //     0xc43e80: stur            w0, [x3, #0xb]
    // 0xc43e84: ldur            x0, [fp, #-8]
    // 0xc43e88: StoreField: r3->field_7 = r0
    //     0xc43e88: stur            w0, [x3, #7]
    // 0xc43e8c: r1 = Function '<anonymous closure>':.
    //     0xc43e8c: add             x1, PP, #0x51, lsl #12  ; [pp+0x51200] AnonymousClosure: (0xc43ed0), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::hold (0xc43e3c)
    //     0xc43e90: ldr             x1, [x1, #0x200]
    // 0xc43e94: r2 = Null
    //     0xc43e94: mov             x2, NULL
    // 0xc43e98: r0 = AllocateClosure()
    //     0xc43e98: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc43e9c: ldr             x16, [fp, #0x18]
    // 0xc43ea0: ldur            lr, [fp, #-0x10]
    // 0xc43ea4: stp             lr, x16, [SP, #-0x10]!
    // 0xc43ea8: SaveReg r0
    //     0xc43ea8: str             x0, [SP, #-8]!
    // 0xc43eac: r0 = beginActivity()
    //     0xc43eac: bl              #0xc37698  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::beginActivity
    // 0xc43eb0: add             SP, SP, #0x18
    // 0xc43eb4: ldr             x0, [fp, #0x18]
    // 0xc43eb8: LeaveFrame
    //     0xc43eb8: mov             SP, fp
    //     0xc43ebc: ldp             fp, lr, [SP], #0x10
    // 0xc43ec0: ret
    //     0xc43ec0: ret             
    // 0xc43ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43ec4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc43ec8: b               #0xc43e54
    // 0xc43ecc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc43ecc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] HoldScrollActivity <anonymous closure>(dynamic, _NestedScrollPosition) {
    // ** addr: 0xc43ed0, size: 0x20
    // 0xc43ed0: EnterFrame
    //     0xc43ed0: stp             fp, lr, [SP, #-0x10]!
    //     0xc43ed4: mov             fp, SP
    // 0xc43ed8: r0 = HoldScrollActivity()
    //     0xc43ed8: bl              #0xc43dc0  ; AllocateHoldScrollActivityStub -> HoldScrollActivity (size=0x10)
    // 0xc43edc: ldr             x1, [fp, #0x10]
    // 0xc43ee0: StoreField: r0->field_7 = r1
    //     0xc43ee0: stur            w1, [x0, #7]
    // 0xc43ee4: LeaveFrame
    //     0xc43ee4: mov             SP, fp
    //     0xc43ee8: ldp             fp, lr, [SP], #0x10
    // 0xc43eec: ret
    //     0xc43eec: ret             
  }
  _ pointerScroll(/* No info */) {
    // ** addr: 0xc459a4, size: 0x924
    // 0xc459a4: EnterFrame
    //     0xc459a4: stp             fp, lr, [SP, #-0x10]!
    //     0xc459a8: mov             fp, SP
    // 0xc459ac: AllocStack(0x30)
    //     0xc459ac: sub             SP, SP, #0x30
    // 0xc459b0: d0 = 0.000000
    //     0xc459b0: eor             v0.16b, v0.16b, v0.16b
    // 0xc459b4: CheckStackOverflow
    //     0xc459b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc459b8: cmp             SP, x16
    //     0xc459bc: b.ls            #0xc46258
    // 0xc459c0: ldr             d1, [fp, #0x10]
    // 0xc459c4: fcmp            d1, d0
    // 0xc459c8: b.vs            #0xc459f0
    // 0xc459cc: b.ne            #0xc459f0
    // 0xc459d0: ldr             x16, [fp, #0x18]
    // 0xc459d4: stp             xzr, x16, [SP, #-0x10]!
    // 0xc459d8: r0 = goBallistic()
    //     0xc459d8: bl              #0xc5bd20  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::goBallistic
    // 0xc459dc: add             SP, SP, #0x10
    // 0xc459e0: r0 = Null
    //     0xc459e0: mov             x0, NULL
    // 0xc459e4: LeaveFrame
    //     0xc459e4: mov             SP, fp
    //     0xc459e8: ldp             fp, lr, [SP], #0x10
    // 0xc459ec: ret
    //     0xc459ec: ret             
    // 0xc459f0: ldr             x16, [fp, #0x18]
    // 0xc459f4: SaveReg r16
    //     0xc459f4: str             x16, [SP, #-8]!
    // 0xc459f8: r0 = goIdle()
    //     0xc459f8: bl              #0xc37628  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::goIdle
    // 0xc459fc: add             SP, SP, #8
    // 0xc45a00: ldr             d1, [fp, #0x10]
    // 0xc45a04: d0 = 0.000000
    //     0xc45a04: eor             v0.16b, v0.16b, v0.16b
    // 0xc45a08: fcmp            d1, d0
    // 0xc45a0c: b.vs            #0xc45a20
    // 0xc45a10: b.ge            #0xc45a20
    // 0xc45a14: r0 = Instance_ScrollDirection
    //     0xc45a14: add             x0, PP, #0x38, lsl #12  ; [pp+0x38f70] Obj!ScrollDirection@b646d1
    //     0xc45a18: ldr             x0, [x0, #0xf70]
    // 0xc45a1c: b               #0xc45a28
    // 0xc45a20: r0 = Instance_ScrollDirection
    //     0xc45a20: add             x0, PP, #0x4a, lsl #12  ; [pp+0x4a938] Obj!ScrollDirection@b646b1
    //     0xc45a24: ldr             x0, [x0, #0x938]
    // 0xc45a28: ldr             x16, [fp, #0x18]
    // 0xc45a2c: stp             x0, x16, [SP, #-0x10]!
    // 0xc45a30: r0 = updateUserScrollDirection()
    //     0xc45a30: bl              #0xc116d0  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::updateUserScrollDirection
    // 0xc45a34: add             SP, SP, #0x10
    // 0xc45a38: ldr             x16, [fp, #0x18]
    // 0xc45a3c: SaveReg r16
    //     0xc45a3c: str             x16, [SP, #-8]!
    // 0xc45a40: r0 = _outerPosition()
    //     0xc45a40: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc45a44: add             SP, SP, #8
    // 0xc45a48: cmp             w0, NULL
    // 0xc45a4c: b.eq            #0xc46260
    // 0xc45a50: LoadField: r1 = r0->field_67
    //     0xc45a50: ldur            w1, [x0, #0x67]
    // 0xc45a54: DecompressPointer r1
    //     0xc45a54: add             x1, x1, HEAP, lsl #32
    // 0xc45a58: r16 = true
    //     0xc45a58: add             x16, NULL, #0x20  ; true
    // 0xc45a5c: stp             x16, x1, [SP, #-0x10]!
    // 0xc45a60: r0 = value=()
    //     0xc45a60: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xc45a64: add             SP, SP, #0x10
    // 0xc45a68: ldr             x16, [fp, #0x18]
    // 0xc45a6c: SaveReg r16
    //     0xc45a6c: str             x16, [SP, #-8]!
    // 0xc45a70: r0 = _outerPosition()
    //     0xc45a70: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc45a74: add             SP, SP, #8
    // 0xc45a78: cmp             w0, NULL
    // 0xc45a7c: b.eq            #0xc46264
    // 0xc45a80: SaveReg r0
    //     0xc45a80: str             x0, [SP, #-8]!
    // 0xc45a84: r0 = didStartScroll()
    //     0xc45a84: bl              #0xbff488  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didStartScroll
    // 0xc45a88: add             SP, SP, #8
    // 0xc45a8c: ldr             x16, [fp, #0x18]
    // 0xc45a90: SaveReg r16
    //     0xc45a90: str             x16, [SP, #-8]!
    // 0xc45a94: r0 = _innerPositions()
    //     0xc45a94: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc45a98: add             SP, SP, #8
    // 0xc45a9c: r1 = LoadClassIdInstr(r0)
    //     0xc45a9c: ldur            x1, [x0, #-1]
    //     0xc45aa0: ubfx            x1, x1, #0xc, #0x14
    // 0xc45aa4: SaveReg r0
    //     0xc45aa4: str             x0, [SP, #-8]!
    // 0xc45aa8: mov             x0, x1
    // 0xc45aac: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc45aac: mov             x17, #0xb940
    //     0xc45ab0: add             lr, x0, x17
    //     0xc45ab4: ldr             lr, [x21, lr, lsl #3]
    //     0xc45ab8: blr             lr
    // 0xc45abc: add             SP, SP, #8
    // 0xc45ac0: mov             x1, x0
    // 0xc45ac4: stur            x1, [fp, #-8]
    // 0xc45ac8: CheckStackOverflow
    //     0xc45ac8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc45acc: cmp             SP, x16
    //     0xc45ad0: b.ls            #0xc46268
    // 0xc45ad4: r0 = LoadClassIdInstr(r1)
    //     0xc45ad4: ldur            x0, [x1, #-1]
    //     0xc45ad8: ubfx            x0, x0, #0xc, #0x14
    // 0xc45adc: SaveReg r1
    //     0xc45adc: str             x1, [SP, #-8]!
    // 0xc45ae0: r0 = GDT[cid_x0 + 0x541]()
    //     0xc45ae0: add             lr, x0, #0x541
    //     0xc45ae4: ldr             lr, [x21, lr, lsl #3]
    //     0xc45ae8: blr             lr
    // 0xc45aec: add             SP, SP, #8
    // 0xc45af0: tbnz            w0, #4, #0xc45c10
    // 0xc45af4: ldur            x1, [fp, #-8]
    // 0xc45af8: r0 = LoadClassIdInstr(r1)
    //     0xc45af8: ldur            x0, [x1, #-1]
    //     0xc45afc: ubfx            x0, x0, #0xc, #0x14
    // 0xc45b00: SaveReg r1
    //     0xc45b00: str             x1, [SP, #-8]!
    // 0xc45b04: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc45b04: add             lr, x0, #0x5ca
    //     0xc45b08: ldr             lr, [x21, lr, lsl #3]
    //     0xc45b0c: blr             lr
    // 0xc45b10: add             SP, SP, #8
    // 0xc45b14: mov             x1, x0
    // 0xc45b18: stur            x1, [fp, #-0x18]
    // 0xc45b1c: LoadField: r2 = r1->field_67
    //     0xc45b1c: ldur            w2, [x1, #0x67]
    // 0xc45b20: DecompressPointer r2
    //     0xc45b20: add             x2, x2, HEAP, lsl #32
    // 0xc45b24: stur            x2, [fp, #-0x10]
    // 0xc45b28: LoadField: r0 = r2->field_27
    //     0xc45b28: ldur            w0, [x2, #0x27]
    // 0xc45b2c: DecompressPointer r0
    //     0xc45b2c: add             x0, x0, HEAP, lsl #32
    // 0xc45b30: r3 = 59
    //     0xc45b30: mov             x3, #0x3b
    // 0xc45b34: branchIfSmi(r0, 0xc45b40)
    //     0xc45b34: tbz             w0, #0, #0xc45b40
    // 0xc45b38: r3 = LoadClassIdInstr(r0)
    //     0xc45b38: ldur            x3, [x0, #-1]
    //     0xc45b3c: ubfx            x3, x3, #0xc, #0x14
    // 0xc45b40: r16 = true
    //     0xc45b40: add             x16, NULL, #0x20  ; true
    // 0xc45b44: stp             x16, x0, [SP, #-0x10]!
    // 0xc45b48: mov             x0, x3
    // 0xc45b4c: mov             lr, x0
    // 0xc45b50: ldr             lr, [x21, lr, lsl #3]
    // 0xc45b54: blr             lr
    // 0xc45b58: add             SP, SP, #0x10
    // 0xc45b5c: tbz             w0, #4, #0xc45b78
    // 0xc45b60: ldur            x0, [fp, #-0x10]
    // 0xc45b64: r1 = true
    //     0xc45b64: add             x1, NULL, #0x20  ; true
    // 0xc45b68: StoreField: r0->field_27 = r1
    //     0xc45b68: stur            w1, [x0, #0x27]
    // 0xc45b6c: SaveReg r0
    //     0xc45b6c: str             x0, [SP, #-8]!
    // 0xc45b70: r0 = notifyListeners()
    //     0xc45b70: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xc45b74: add             SP, SP, #8
    // 0xc45b78: ldur            x1, [fp, #-0x18]
    // 0xc45b7c: LoadField: r2 = r1->field_6b
    //     0xc45b7c: ldur            w2, [x1, #0x6b]
    // 0xc45b80: DecompressPointer r2
    //     0xc45b80: add             x2, x2, HEAP, lsl #32
    // 0xc45b84: stur            x2, [fp, #-0x10]
    // 0xc45b88: cmp             w2, NULL
    // 0xc45b8c: b.eq            #0xc46270
    // 0xc45b90: r0 = LoadClassIdInstr(r1)
    //     0xc45b90: ldur            x0, [x1, #-1]
    //     0xc45b94: ubfx            x0, x0, #0xc, #0x14
    // 0xc45b98: SaveReg r1
    //     0xc45b98: str             x1, [SP, #-8]!
    // 0xc45b9c: r0 = GDT[cid_x0 + -0x8fa]()
    //     0xc45b9c: sub             lr, x0, #0x8fa
    //     0xc45ba0: ldr             lr, [x21, lr, lsl #3]
    //     0xc45ba4: blr             lr
    // 0xc45ba8: add             SP, SP, #8
    // 0xc45bac: mov             x1, x0
    // 0xc45bb0: ldur            x0, [fp, #-0x18]
    // 0xc45bb4: stur            x1, [fp, #-0x20]
    // 0xc45bb8: LoadField: r2 = r0->field_27
    //     0xc45bb8: ldur            w2, [x0, #0x27]
    // 0xc45bbc: DecompressPointer r2
    //     0xc45bbc: add             x2, x2, HEAP, lsl #32
    // 0xc45bc0: LoadField: r0 = r2->field_47
    //     0xc45bc0: ldur            w0, [x2, #0x47]
    // 0xc45bc4: DecompressPointer r0
    //     0xc45bc4: add             x0, x0, HEAP, lsl #32
    // 0xc45bc8: SaveReg r0
    //     0xc45bc8: str             x0, [SP, #-8]!
    // 0xc45bcc: r0 = _currentElement()
    //     0xc45bcc: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xc45bd0: add             SP, SP, #8
    // 0xc45bd4: mov             x1, x0
    // 0xc45bd8: ldur            x0, [fp, #-0x10]
    // 0xc45bdc: r2 = LoadClassIdInstr(r0)
    //     0xc45bdc: ldur            x2, [x0, #-1]
    //     0xc45be0: ubfx            x2, x2, #0xc, #0x14
    // 0xc45be4: ldur            x16, [fp, #-0x20]
    // 0xc45be8: stp             x16, x0, [SP, #-0x10]!
    // 0xc45bec: SaveReg r1
    //     0xc45bec: str             x1, [SP, #-8]!
    // 0xc45bf0: mov             x0, x2
    // 0xc45bf4: r0 = GDT[cid_x0 + 0x3143]()
    //     0xc45bf4: mov             x17, #0x3143
    //     0xc45bf8: add             lr, x0, x17
    //     0xc45bfc: ldr             lr, [x21, lr, lsl #3]
    //     0xc45c00: blr             lr
    // 0xc45c04: add             SP, SP, #0x18
    // 0xc45c08: ldur            x1, [fp, #-8]
    // 0xc45c0c: b               #0xc45ac8
    // 0xc45c10: ldr             x16, [fp, #0x18]
    // 0xc45c14: SaveReg r16
    //     0xc45c14: str             x16, [SP, #-8]!
    // 0xc45c18: r0 = _innerPositions()
    //     0xc45c18: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc45c1c: add             SP, SP, #8
    // 0xc45c20: r1 = LoadClassIdInstr(r0)
    //     0xc45c20: ldur            x1, [x0, #-1]
    //     0xc45c24: ubfx            x1, x1, #0xc, #0x14
    // 0xc45c28: SaveReg r0
    //     0xc45c28: str             x0, [SP, #-8]!
    // 0xc45c2c: mov             x0, x1
    // 0xc45c30: r0 = GDT[cid_x0 + 0xccd1]()
    //     0xc45c30: mov             x17, #0xccd1
    //     0xc45c34: add             lr, x0, x17
    //     0xc45c38: ldr             lr, [x21, lr, lsl #3]
    //     0xc45c3c: blr             lr
    // 0xc45c40: add             SP, SP, #8
    // 0xc45c44: tbnz            w0, #4, #0xc45c7c
    // 0xc45c48: ldr             d0, [fp, #0x10]
    // 0xc45c4c: ldr             x16, [fp, #0x18]
    // 0xc45c50: SaveReg r16
    //     0xc45c50: str             x16, [SP, #-8]!
    // 0xc45c54: r0 = _outerPosition()
    //     0xc45c54: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc45c58: add             SP, SP, #8
    // 0xc45c5c: cmp             w0, NULL
    // 0xc45c60: b.eq            #0xc46274
    // 0xc45c64: SaveReg r0
    //     0xc45c64: str             x0, [SP, #-8]!
    // 0xc45c68: ldr             d0, [fp, #0x10]
    // 0xc45c6c: SaveReg d0
    //     0xc45c6c: str             d0, [SP, #-8]!
    // 0xc45c70: r0 = applyClampedPointerSignalUpdate()
    //     0xc45c70: bl              #0xc462c8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyClampedPointerSignalUpdate
    // 0xc45c74: add             SP, SP, #0x10
    // 0xc45c78: b               #0xc460a8
    // 0xc45c7c: ldr             d0, [fp, #0x10]
    // 0xc45c80: d1 = 0.000000
    //     0xc45c80: eor             v1.16b, v1.16b, v1.16b
    // 0xc45c84: fcmp            d0, d1
    // 0xc45c88: b.vs            #0xc45edc
    // 0xc45c8c: b.le            #0xc45edc
    // 0xc45c90: ldr             x16, [fp, #0x18]
    // 0xc45c94: SaveReg r16
    //     0xc45c94: str             x16, [SP, #-8]!
    // 0xc45c98: r0 = _innerPositions()
    //     0xc45c98: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc45c9c: add             SP, SP, #8
    // 0xc45ca0: r1 = LoadClassIdInstr(r0)
    //     0xc45ca0: ldur            x1, [x0, #-1]
    //     0xc45ca4: ubfx            x1, x1, #0xc, #0x14
    // 0xc45ca8: SaveReg r0
    //     0xc45ca8: str             x0, [SP, #-8]!
    // 0xc45cac: mov             x0, x1
    // 0xc45cb0: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc45cb0: mov             x17, #0xb940
    //     0xc45cb4: add             lr, x0, x17
    //     0xc45cb8: ldr             lr, [x21, lr, lsl #3]
    //     0xc45cbc: blr             lr
    // 0xc45cc0: add             SP, SP, #8
    // 0xc45cc4: mov             x1, x0
    // 0xc45cc8: stur            x1, [fp, #-8]
    // 0xc45ccc: ldr             d1, [fp, #0x10]
    // 0xc45cd0: ldr             d0, [fp, #0x10]
    // 0xc45cd4: stur            d1, [fp, #-0x28]
    // 0xc45cd8: CheckStackOverflow
    //     0xc45cd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc45cdc: cmp             SP, x16
    //     0xc45ce0: b.ls            #0xc46278
    // 0xc45ce4: r0 = LoadClassIdInstr(r1)
    //     0xc45ce4: ldur            x0, [x1, #-1]
    //     0xc45ce8: ubfx            x0, x0, #0xc, #0x14
    // 0xc45cec: SaveReg r1
    //     0xc45cec: str             x1, [SP, #-8]!
    // 0xc45cf0: r0 = GDT[cid_x0 + 0x541]()
    //     0xc45cf0: add             lr, x0, #0x541
    //     0xc45cf4: ldr             lr, [x21, lr, lsl #3]
    //     0xc45cf8: blr             lr
    // 0xc45cfc: add             SP, SP, #8
    // 0xc45d00: tbnz            w0, #4, #0xc45dd8
    // 0xc45d04: ldur            x1, [fp, #-8]
    // 0xc45d08: r0 = LoadClassIdInstr(r1)
    //     0xc45d08: ldur            x0, [x1, #-1]
    //     0xc45d0c: ubfx            x0, x0, #0xc, #0x14
    // 0xc45d10: SaveReg r1
    //     0xc45d10: str             x1, [SP, #-8]!
    // 0xc45d14: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc45d14: add             lr, x0, #0x5ca
    //     0xc45d18: ldr             lr, [x21, lr, lsl #3]
    //     0xc45d1c: blr             lr
    // 0xc45d20: add             SP, SP, #8
    // 0xc45d24: LoadField: r1 = r0->field_43
    //     0xc45d24: ldur            w1, [x0, #0x43]
    // 0xc45d28: DecompressPointer r1
    //     0xc45d28: add             x1, x1, HEAP, lsl #32
    // 0xc45d2c: cmp             w1, NULL
    // 0xc45d30: b.eq            #0xc46280
    // 0xc45d34: LoadField: d0 = r1->field_7
    //     0xc45d34: ldur            d0, [x1, #7]
    // 0xc45d38: d1 = 0.000000
    //     0xc45d38: eor             v1.16b, v1.16b, v1.16b
    // 0xc45d3c: fcmp            d0, d1
    // 0xc45d40: b.vs            #0xc45dc4
    // 0xc45d44: b.ge            #0xc45dc4
    // 0xc45d48: ldr             d0, [fp, #0x10]
    // 0xc45d4c: ldur            d2, [fp, #-0x28]
    // 0xc45d50: SaveReg r0
    //     0xc45d50: str             x0, [SP, #-8]!
    // 0xc45d54: SaveReg d0
    //     0xc45d54: str             d0, [SP, #-8]!
    // 0xc45d58: r0 = applyClampedPointerSignalUpdate()
    //     0xc45d58: bl              #0xc462c8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyClampedPointerSignalUpdate
    // 0xc45d5c: add             SP, SP, #0x10
    // 0xc45d60: mov             v1.16b, v0.16b
    // 0xc45d64: ldur            d0, [fp, #-0x28]
    // 0xc45d68: fcmp            d0, d1
    // 0xc45d6c: b.vs            #0xc45d7c
    // 0xc45d70: b.le            #0xc45d7c
    // 0xc45d74: d2 = 0.000000
    //     0xc45d74: eor             v2.16b, v2.16b, v2.16b
    // 0xc45d78: b               #0xc45dbc
    // 0xc45d7c: fcmp            d0, d1
    // 0xc45d80: b.vs            #0xc45d94
    // 0xc45d84: b.ge            #0xc45d94
    // 0xc45d88: mov             v0.16b, v1.16b
    // 0xc45d8c: d2 = 0.000000
    //     0xc45d8c: eor             v2.16b, v2.16b, v2.16b
    // 0xc45d90: b               #0xc45dbc
    // 0xc45d94: d2 = 0.000000
    //     0xc45d94: eor             v2.16b, v2.16b, v2.16b
    // 0xc45d98: fcmp            d0, d2
    // 0xc45d9c: b.vs            #0xc45db0
    // 0xc45da0: b.ne            #0xc45db0
    // 0xc45da4: fadd            d3, d0, d1
    // 0xc45da8: mov             v0.16b, v3.16b
    // 0xc45dac: b               #0xc45dbc
    // 0xc45db0: fcmp            d1, d1
    // 0xc45db4: b.vc            #0xc45dbc
    // 0xc45db8: mov             v0.16b, v1.16b
    // 0xc45dbc: mov             v1.16b, v0.16b
    // 0xc45dc0: b               #0xc45dd0
    // 0xc45dc4: ldur            d0, [fp, #-0x28]
    // 0xc45dc8: mov             v2.16b, v1.16b
    // 0xc45dcc: mov             v1.16b, v0.16b
    // 0xc45dd0: ldur            x1, [fp, #-8]
    // 0xc45dd4: b               #0xc45cd0
    // 0xc45dd8: ldur            d0, [fp, #-0x28]
    // 0xc45ddc: SaveReg d0
    //     0xc45ddc: str             d0, [SP, #-8]!
    // 0xc45de0: r0 = DoubleEx.notZero()
    //     0xc45de0: bl              #0xc140b8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ::DoubleEx.notZero
    // 0xc45de4: add             SP, SP, #8
    // 0xc45de8: tbnz            w0, #4, #0xc460a8
    // 0xc45dec: ldur            d0, [fp, #-0x28]
    // 0xc45df0: ldr             x16, [fp, #0x18]
    // 0xc45df4: SaveReg r16
    //     0xc45df4: str             x16, [SP, #-8]!
    // 0xc45df8: r0 = _outerPosition()
    //     0xc45df8: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc45dfc: add             SP, SP, #8
    // 0xc45e00: cmp             w0, NULL
    // 0xc45e04: b.eq            #0xc46284
    // 0xc45e08: SaveReg r0
    //     0xc45e08: str             x0, [SP, #-8]!
    // 0xc45e0c: ldur            d0, [fp, #-0x28]
    // 0xc45e10: SaveReg d0
    //     0xc45e10: str             d0, [SP, #-8]!
    // 0xc45e14: r0 = applyClampedPointerSignalUpdate()
    //     0xc45e14: bl              #0xc462c8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyClampedPointerSignalUpdate
    // 0xc45e18: add             SP, SP, #0x10
    // 0xc45e1c: stur            d0, [fp, #-0x28]
    // 0xc45e20: SaveReg d0
    //     0xc45e20: str             d0, [SP, #-8]!
    // 0xc45e24: r0 = DoubleEx.notZero()
    //     0xc45e24: bl              #0xc140b8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ::DoubleEx.notZero
    // 0xc45e28: add             SP, SP, #8
    // 0xc45e2c: tbnz            w0, #4, #0xc460a8
    // 0xc45e30: ldr             x16, [fp, #0x18]
    // 0xc45e34: SaveReg r16
    //     0xc45e34: str             x16, [SP, #-8]!
    // 0xc45e38: r0 = _innerPositions()
    //     0xc45e38: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc45e3c: add             SP, SP, #8
    // 0xc45e40: r1 = LoadClassIdInstr(r0)
    //     0xc45e40: ldur            x1, [x0, #-1]
    //     0xc45e44: ubfx            x1, x1, #0xc, #0x14
    // 0xc45e48: SaveReg r0
    //     0xc45e48: str             x0, [SP, #-8]!
    // 0xc45e4c: mov             x0, x1
    // 0xc45e50: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc45e50: mov             x17, #0xb940
    //     0xc45e54: add             lr, x0, x17
    //     0xc45e58: ldr             lr, [x21, lr, lsl #3]
    //     0xc45e5c: blr             lr
    // 0xc45e60: add             SP, SP, #8
    // 0xc45e64: mov             x1, x0
    // 0xc45e68: stur            x1, [fp, #-8]
    // 0xc45e6c: ldur            d0, [fp, #-0x28]
    // 0xc45e70: CheckStackOverflow
    //     0xc45e70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc45e74: cmp             SP, x16
    //     0xc45e78: b.ls            #0xc46288
    // 0xc45e7c: r0 = LoadClassIdInstr(r1)
    //     0xc45e7c: ldur            x0, [x1, #-1]
    //     0xc45e80: ubfx            x0, x0, #0xc, #0x14
    // 0xc45e84: SaveReg r1
    //     0xc45e84: str             x1, [SP, #-8]!
    // 0xc45e88: r0 = GDT[cid_x0 + 0x541]()
    //     0xc45e88: add             lr, x0, #0x541
    //     0xc45e8c: ldr             lr, [x21, lr, lsl #3]
    //     0xc45e90: blr             lr
    // 0xc45e94: add             SP, SP, #8
    // 0xc45e98: tbnz            w0, #4, #0xc460a8
    // 0xc45e9c: ldur            d0, [fp, #-0x28]
    // 0xc45ea0: ldur            x1, [fp, #-8]
    // 0xc45ea4: r0 = LoadClassIdInstr(r1)
    //     0xc45ea4: ldur            x0, [x1, #-1]
    //     0xc45ea8: ubfx            x0, x0, #0xc, #0x14
    // 0xc45eac: SaveReg r1
    //     0xc45eac: str             x1, [SP, #-8]!
    // 0xc45eb0: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc45eb0: add             lr, x0, #0x5ca
    //     0xc45eb4: ldr             lr, [x21, lr, lsl #3]
    //     0xc45eb8: blr             lr
    // 0xc45ebc: add             SP, SP, #8
    // 0xc45ec0: SaveReg r0
    //     0xc45ec0: str             x0, [SP, #-8]!
    // 0xc45ec4: ldur            d0, [fp, #-0x28]
    // 0xc45ec8: SaveReg d0
    //     0xc45ec8: str             d0, [SP, #-8]!
    // 0xc45ecc: r0 = applyClampedPointerSignalUpdate()
    //     0xc45ecc: bl              #0xc462c8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyClampedPointerSignalUpdate
    // 0xc45ed0: add             SP, SP, #0x10
    // 0xc45ed4: ldur            x1, [fp, #-8]
    // 0xc45ed8: b               #0xc45e6c
    // 0xc45edc: mov             v2.16b, v1.16b
    // 0xc45ee0: SaveReg d0
    //     0xc45ee0: str             d0, [SP, #-8]!
    // 0xc45ee4: r0 = DoubleEx.notZero()
    //     0xc45ee4: bl              #0xc140b8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ::DoubleEx.notZero
    // 0xc45ee8: add             SP, SP, #8
    // 0xc45eec: tbnz            w0, #4, #0xc460a8
    // 0xc45ef0: ldr             x16, [fp, #0x18]
    // 0xc45ef4: SaveReg r16
    //     0xc45ef4: str             x16, [SP, #-8]!
    // 0xc45ef8: r0 = _innerPositions()
    //     0xc45ef8: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc45efc: add             SP, SP, #8
    // 0xc45f00: r1 = LoadClassIdInstr(r0)
    //     0xc45f00: ldur            x1, [x0, #-1]
    //     0xc45f04: ubfx            x1, x1, #0xc, #0x14
    // 0xc45f08: SaveReg r0
    //     0xc45f08: str             x0, [SP, #-8]!
    // 0xc45f0c: mov             x0, x1
    // 0xc45f10: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc45f10: mov             x17, #0xb940
    //     0xc45f14: add             lr, x0, x17
    //     0xc45f18: ldr             lr, [x21, lr, lsl #3]
    //     0xc45f1c: blr             lr
    // 0xc45f20: add             SP, SP, #8
    // 0xc45f24: mov             x1, x0
    // 0xc45f28: stur            x1, [fp, #-8]
    // 0xc45f2c: d1 = 0.000000
    //     0xc45f2c: eor             v1.16b, v1.16b, v1.16b
    // 0xc45f30: ldr             d0, [fp, #0x10]
    // 0xc45f34: stur            d1, [fp, #-0x28]
    // 0xc45f38: CheckStackOverflow
    //     0xc45f38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc45f3c: cmp             SP, x16
    //     0xc45f40: b.ls            #0xc46290
    // 0xc45f44: r0 = LoadClassIdInstr(r1)
    //     0xc45f44: ldur            x0, [x1, #-1]
    //     0xc45f48: ubfx            x0, x0, #0xc, #0x14
    // 0xc45f4c: SaveReg r1
    //     0xc45f4c: str             x1, [SP, #-8]!
    // 0xc45f50: r0 = GDT[cid_x0 + 0x541]()
    //     0xc45f50: add             lr, x0, #0x541
    //     0xc45f54: ldr             lr, [x21, lr, lsl #3]
    //     0xc45f58: blr             lr
    // 0xc45f5c: add             SP, SP, #8
    // 0xc45f60: tbnz            w0, #4, #0xc46064
    // 0xc45f64: ldr             d0, [fp, #0x10]
    // 0xc45f68: ldur            x1, [fp, #-8]
    // 0xc45f6c: ldur            d1, [fp, #-0x28]
    // 0xc45f70: r0 = LoadClassIdInstr(r1)
    //     0xc45f70: ldur            x0, [x1, #-1]
    //     0xc45f74: ubfx            x0, x0, #0xc, #0x14
    // 0xc45f78: SaveReg r1
    //     0xc45f78: str             x1, [SP, #-8]!
    // 0xc45f7c: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc45f7c: add             lr, x0, #0x5ca
    //     0xc45f80: ldr             lr, [x21, lr, lsl #3]
    //     0xc45f84: blr             lr
    // 0xc45f88: add             SP, SP, #8
    // 0xc45f8c: SaveReg r0
    //     0xc45f8c: str             x0, [SP, #-8]!
    // 0xc45f90: ldr             d0, [fp, #0x10]
    // 0xc45f94: SaveReg d0
    //     0xc45f94: str             d0, [SP, #-8]!
    // 0xc45f98: r0 = applyClampedPointerSignalUpdate()
    //     0xc45f98: bl              #0xc462c8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyClampedPointerSignalUpdate
    // 0xc45f9c: add             SP, SP, #0x10
    // 0xc45fa0: mov             v1.16b, v0.16b
    // 0xc45fa4: ldur            d0, [fp, #-0x28]
    // 0xc45fa8: stur            d1, [fp, #-0x30]
    // 0xc45fac: fcmp            d0, d1
    // 0xc45fb0: b.vs            #0xc45fb8
    // 0xc45fb4: b.gt            #0xc4605c
    // 0xc45fb8: fcmp            d0, d1
    // 0xc45fbc: b.vs            #0xc45fcc
    // 0xc45fc0: b.ge            #0xc45fcc
    // 0xc45fc4: mov             v1.16b, v0.16b
    // 0xc45fc8: b               #0xc4605c
    // 0xc45fcc: d2 = 0.000000
    //     0xc45fcc: eor             v2.16b, v2.16b, v2.16b
    // 0xc45fd0: fcmp            d0, d2
    // 0xc45fd4: b.vs            #0xc45fdc
    // 0xc45fd8: b.eq            #0xc45fe4
    // 0xc45fdc: r0 = false
    //     0xc45fdc: add             x0, NULL, #0x30  ; false
    // 0xc45fe0: b               #0xc45fe8
    // 0xc45fe4: r0 = true
    //     0xc45fe4: add             x0, NULL, #0x20  ; true
    // 0xc45fe8: tbnz            w0, #4, #0xc46000
    // 0xc45fec: fadd            d3, d0, d1
    // 0xc45ff0: fmul            d4, d3, d0
    // 0xc45ff4: fmul            d0, d4, d1
    // 0xc45ff8: mov             v1.16b, v0.16b
    // 0xc45ffc: b               #0xc4605c
    // 0xc46000: tbnz            w0, #4, #0xc46044
    // 0xc46004: r0 = inline_Allocate_Double()
    //     0xc46004: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc46008: add             x0, x0, #0x10
    //     0xc4600c: cmp             x1, x0
    //     0xc46010: b.ls            #0xc46298
    //     0xc46014: str             x0, [THR, #0x60]  ; THR::top
    //     0xc46018: sub             x0, x0, #0xf
    //     0xc4601c: mov             x1, #0xd108
    //     0xc46020: movk            x1, #3, lsl #16
    //     0xc46024: stur            x1, [x0, #-1]
    // 0xc46028: StoreField: r0->field_7 = d1
    //     0xc46028: stur            d1, [x0, #7]
    // 0xc4602c: SaveReg r0
    //     0xc4602c: str             x0, [SP, #-8]!
    // 0xc46030: r0 = isNegative()
    //     0xc46030: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xc46034: add             SP, SP, #8
    // 0xc46038: tbnz            w0, #4, #0xc46044
    // 0xc4603c: ldur            d0, [fp, #-0x30]
    // 0xc46040: b               #0xc46050
    // 0xc46044: ldur            d0, [fp, #-0x30]
    // 0xc46048: fcmp            d0, d0
    // 0xc4604c: b.vc            #0xc46058
    // 0xc46050: mov             v1.16b, v0.16b
    // 0xc46054: b               #0xc4605c
    // 0xc46058: ldur            d1, [fp, #-0x28]
    // 0xc4605c: ldur            x1, [fp, #-8]
    // 0xc46060: b               #0xc45f30
    // 0xc46064: ldur            d0, [fp, #-0x28]
    // 0xc46068: SaveReg d0
    //     0xc46068: str             d0, [SP, #-8]!
    // 0xc4606c: r0 = DoubleEx.notZero()
    //     0xc4606c: bl              #0xc140b8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] ::DoubleEx.notZero
    // 0xc46070: add             SP, SP, #8
    // 0xc46074: tbnz            w0, #4, #0xc460a8
    // 0xc46078: ldur            d0, [fp, #-0x28]
    // 0xc4607c: ldr             x16, [fp, #0x18]
    // 0xc46080: SaveReg r16
    //     0xc46080: str             x16, [SP, #-8]!
    // 0xc46084: r0 = _outerPosition()
    //     0xc46084: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc46088: add             SP, SP, #8
    // 0xc4608c: cmp             w0, NULL
    // 0xc46090: b.eq            #0xc462b0
    // 0xc46094: SaveReg r0
    //     0xc46094: str             x0, [SP, #-8]!
    // 0xc46098: ldur            d0, [fp, #-0x28]
    // 0xc4609c: SaveReg d0
    //     0xc4609c: str             d0, [SP, #-8]!
    // 0xc460a0: r0 = applyClampedPointerSignalUpdate()
    //     0xc460a0: bl              #0xc462c8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyClampedPointerSignalUpdate
    // 0xc460a4: add             SP, SP, #0x10
    // 0xc460a8: ldr             x16, [fp, #0x18]
    // 0xc460ac: SaveReg r16
    //     0xc460ac: str             x16, [SP, #-8]!
    // 0xc460b0: r0 = _outerPosition()
    //     0xc460b0: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc460b4: add             SP, SP, #8
    // 0xc460b8: cmp             w0, NULL
    // 0xc460bc: b.eq            #0xc462b4
    // 0xc460c0: SaveReg r0
    //     0xc460c0: str             x0, [SP, #-8]!
    // 0xc460c4: r0 = didEndScroll()
    //     0xc460c4: bl              #0xbff54c  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didEndScroll
    // 0xc460c8: add             SP, SP, #8
    // 0xc460cc: ldr             x16, [fp, #0x18]
    // 0xc460d0: SaveReg r16
    //     0xc460d0: str             x16, [SP, #-8]!
    // 0xc460d4: r0 = _innerPositions()
    //     0xc460d4: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc460d8: add             SP, SP, #8
    // 0xc460dc: r1 = LoadClassIdInstr(r0)
    //     0xc460dc: ldur            x1, [x0, #-1]
    //     0xc460e0: ubfx            x1, x1, #0xc, #0x14
    // 0xc460e4: SaveReg r0
    //     0xc460e4: str             x0, [SP, #-8]!
    // 0xc460e8: mov             x0, x1
    // 0xc460ec: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc460ec: mov             x17, #0xb940
    //     0xc460f0: add             lr, x0, x17
    //     0xc460f4: ldr             lr, [x21, lr, lsl #3]
    //     0xc460f8: blr             lr
    // 0xc460fc: add             SP, SP, #8
    // 0xc46100: mov             x1, x0
    // 0xc46104: stur            x1, [fp, #-8]
    // 0xc46108: CheckStackOverflow
    //     0xc46108: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4610c: cmp             SP, x16
    //     0xc46110: b.ls            #0xc462b8
    // 0xc46114: r0 = LoadClassIdInstr(r1)
    //     0xc46114: ldur            x0, [x1, #-1]
    //     0xc46118: ubfx            x0, x0, #0xc, #0x14
    // 0xc4611c: SaveReg r1
    //     0xc4611c: str             x1, [SP, #-8]!
    // 0xc46120: r0 = GDT[cid_x0 + 0x541]()
    //     0xc46120: add             lr, x0, #0x541
    //     0xc46124: ldr             lr, [x21, lr, lsl #3]
    //     0xc46128: blr             lr
    // 0xc4612c: add             SP, SP, #8
    // 0xc46130: tbnz            w0, #4, #0xc46238
    // 0xc46134: ldur            x1, [fp, #-8]
    // 0xc46138: r0 = LoadClassIdInstr(r1)
    //     0xc46138: ldur            x0, [x1, #-1]
    //     0xc4613c: ubfx            x0, x0, #0xc, #0x14
    // 0xc46140: SaveReg r1
    //     0xc46140: str             x1, [SP, #-8]!
    // 0xc46144: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc46144: add             lr, x0, #0x5ca
    //     0xc46148: ldr             lr, [x21, lr, lsl #3]
    //     0xc4614c: blr             lr
    // 0xc46150: add             SP, SP, #8
    // 0xc46154: mov             x1, x0
    // 0xc46158: stur            x1, [fp, #-0x18]
    // 0xc4615c: LoadField: r2 = r1->field_6b
    //     0xc4615c: ldur            w2, [x1, #0x6b]
    // 0xc46160: DecompressPointer r2
    //     0xc46160: add             x2, x2, HEAP, lsl #32
    // 0xc46164: stur            x2, [fp, #-0x10]
    // 0xc46168: cmp             w2, NULL
    // 0xc4616c: b.eq            #0xc462c0
    // 0xc46170: r0 = LoadClassIdInstr(r1)
    //     0xc46170: ldur            x0, [x1, #-1]
    //     0xc46174: ubfx            x0, x0, #0xc, #0x14
    // 0xc46178: SaveReg r1
    //     0xc46178: str             x1, [SP, #-8]!
    // 0xc4617c: r0 = GDT[cid_x0 + -0x8fa]()
    //     0xc4617c: sub             lr, x0, #0x8fa
    //     0xc46180: ldr             lr, [x21, lr, lsl #3]
    //     0xc46184: blr             lr
    // 0xc46188: add             SP, SP, #8
    // 0xc4618c: mov             x1, x0
    // 0xc46190: ldur            x0, [fp, #-0x18]
    // 0xc46194: stur            x1, [fp, #-0x20]
    // 0xc46198: LoadField: r2 = r0->field_27
    //     0xc46198: ldur            w2, [x0, #0x27]
    // 0xc4619c: DecompressPointer r2
    //     0xc4619c: add             x2, x2, HEAP, lsl #32
    // 0xc461a0: LoadField: r3 = r2->field_47
    //     0xc461a0: ldur            w3, [x2, #0x47]
    // 0xc461a4: DecompressPointer r3
    //     0xc461a4: add             x3, x3, HEAP, lsl #32
    // 0xc461a8: SaveReg r3
    //     0xc461a8: str             x3, [SP, #-8]!
    // 0xc461ac: r0 = _currentElement()
    //     0xc461ac: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xc461b0: add             SP, SP, #8
    // 0xc461b4: cmp             w0, NULL
    // 0xc461b8: b.eq            #0xc462c4
    // 0xc461bc: ldur            x1, [fp, #-0x10]
    // 0xc461c0: r2 = LoadClassIdInstr(r1)
    //     0xc461c0: ldur            x2, [x1, #-1]
    //     0xc461c4: ubfx            x2, x2, #0xc, #0x14
    // 0xc461c8: ldur            x16, [fp, #-0x20]
    // 0xc461cc: stp             x16, x1, [SP, #-0x10]!
    // 0xc461d0: SaveReg r0
    //     0xc461d0: str             x0, [SP, #-8]!
    // 0xc461d4: mov             x0, x2
    // 0xc461d8: r0 = GDT[cid_x0 + 0x4995]()
    //     0xc461d8: mov             x17, #0x4995
    //     0xc461dc: add             lr, x0, x17
    //     0xc461e0: ldr             lr, [x21, lr, lsl #3]
    //     0xc461e4: blr             lr
    // 0xc461e8: add             SP, SP, #0x18
    // 0xc461ec: ldur            x1, [fp, #-0x18]
    // 0xc461f0: r0 = LoadClassIdInstr(r1)
    //     0xc461f0: ldur            x0, [x1, #-1]
    //     0xc461f4: ubfx            x0, x0, #0xc, #0x14
    // 0xc461f8: SaveReg r1
    //     0xc461f8: str             x1, [SP, #-8]!
    // 0xc461fc: r0 = GDT[cid_x0 + 0xc60]()
    //     0xc461fc: add             lr, x0, #0xc60
    //     0xc46200: ldr             lr, [x21, lr, lsl #3]
    //     0xc46204: blr             lr
    // 0xc46208: add             SP, SP, #8
    // 0xc4620c: ldur            x0, [fp, #-0x18]
    // 0xc46210: r1 = LoadClassIdInstr(r0)
    //     0xc46210: ldur            x1, [x0, #-1]
    //     0xc46214: ubfx            x1, x1, #0xc, #0x14
    // 0xc46218: SaveReg r0
    //     0xc46218: str             x0, [SP, #-8]!
    // 0xc4621c: mov             x0, x1
    // 0xc46220: r0 = GDT[cid_x0 + 0xc58]()
    //     0xc46220: add             lr, x0, #0xc58
    //     0xc46224: ldr             lr, [x21, lr, lsl #3]
    //     0xc46228: blr             lr
    // 0xc4622c: add             SP, SP, #8
    // 0xc46230: ldur            x1, [fp, #-8]
    // 0xc46234: b               #0xc46108
    // 0xc46238: ldr             x16, [fp, #0x18]
    // 0xc4623c: stp             xzr, x16, [SP, #-0x10]!
    // 0xc46240: r0 = goBallistic()
    //     0xc46240: bl              #0xc5bd20  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::goBallistic
    // 0xc46244: add             SP, SP, #0x10
    // 0xc46248: r0 = Null
    //     0xc46248: mov             x0, NULL
    // 0xc4624c: LeaveFrame
    //     0xc4624c: mov             SP, fp
    //     0xc46250: ldp             fp, lr, [SP], #0x10
    // 0xc46254: ret
    //     0xc46254: ret             
    // 0xc46258: r0 = StackOverflowSharedWithFPURegs()
    //     0xc46258: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc4625c: b               #0xc459c0
    // 0xc46260: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc46260: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc46264: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc46264: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc46268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc46268: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4626c: b               #0xc45ad4
    // 0xc46270: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc46270: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc46274: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc46274: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc46278: r0 = StackOverflowSharedWithFPURegs()
    //     0xc46278: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc4627c: b               #0xc45ce4
    // 0xc46280: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc46280: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc46284: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc46284: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc46288: r0 = StackOverflowSharedWithFPURegs()
    //     0xc46288: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc4628c: b               #0xc45e7c
    // 0xc46290: r0 = StackOverflowSharedWithFPURegs()
    //     0xc46290: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc46294: b               #0xc45f44
    // 0xc46298: stp             q1, q2, [SP, #-0x20]!
    // 0xc4629c: SaveReg d0
    //     0xc4629c: str             q0, [SP, #-0x10]!
    // 0xc462a0: r0 = AllocateDouble()
    //     0xc462a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc462a4: RestoreReg d0
    //     0xc462a4: ldr             q0, [SP], #0x10
    // 0xc462a8: ldp             q1, q2, [SP], #0x20
    // 0xc462ac: b               #0xc46028
    // 0xc462b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc462b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc462b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc462b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc462b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc462b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc462bc: b               #0xc46114
    // 0xc462c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc462c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc462c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc462c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ jumpTo(/* No info */) {
    // ** addr: 0xc516cc, size: 0x208
    // 0xc516cc: EnterFrame
    //     0xc516cc: stp             fp, lr, [SP, #-0x10]!
    //     0xc516d0: mov             fp, SP
    // 0xc516d4: AllocStack(0x18)
    //     0xc516d4: sub             SP, SP, #0x18
    // 0xc516d8: CheckStackOverflow
    //     0xc516d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc516dc: cmp             SP, x16
    //     0xc516e0: b.ls            #0xc518b4
    // 0xc516e4: ldr             x16, [fp, #0x18]
    // 0xc516e8: SaveReg r16
    //     0xc516e8: str             x16, [SP, #-8]!
    // 0xc516ec: r0 = goIdle()
    //     0xc516ec: bl              #0xc37628  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::goIdle
    // 0xc516f0: add             SP, SP, #8
    // 0xc516f4: ldr             x16, [fp, #0x18]
    // 0xc516f8: SaveReg r16
    //     0xc516f8: str             x16, [SP, #-8]!
    // 0xc516fc: r0 = _outerPosition()
    //     0xc516fc: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51700: add             SP, SP, #8
    // 0xc51704: stur            x0, [fp, #-8]
    // 0xc51708: cmp             w0, NULL
    // 0xc5170c: b.eq            #0xc518bc
    // 0xc51710: ldr             x16, [fp, #0x18]
    // 0xc51714: SaveReg r16
    //     0xc51714: str             x16, [SP, #-8]!
    // 0xc51718: r0 = _outerPosition()
    //     0xc51718: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc5171c: add             SP, SP, #8
    // 0xc51720: cmp             w0, NULL
    // 0xc51724: b.eq            #0xc518c0
    // 0xc51728: ldr             x16, [fp, #0x18]
    // 0xc5172c: SaveReg r16
    //     0xc5172c: str             x16, [SP, #-8]!
    // 0xc51730: ldr             d0, [fp, #0x10]
    // 0xc51734: SaveReg d0
    //     0xc51734: str             d0, [SP, #-8]!
    // 0xc51738: SaveReg r0
    //     0xc51738: str             x0, [SP, #-8]!
    // 0xc5173c: r0 = nestOffset()
    //     0xc5173c: bl              #0xc51994  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::nestOffset
    // 0xc51740: add             SP, SP, #0x18
    // 0xc51744: ldur            x16, [fp, #-8]
    // 0xc51748: SaveReg r16
    //     0xc51748: str             x16, [SP, #-8]!
    // 0xc5174c: SaveReg d0
    //     0xc5174c: str             d0, [SP, #-8]!
    // 0xc51750: r0 = localJumpTo()
    //     0xc51750: bl              #0xc518d4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::localJumpTo
    // 0xc51754: add             SP, SP, #0x10
    // 0xc51758: ldr             x16, [fp, #0x18]
    // 0xc5175c: SaveReg r16
    //     0xc5175c: str             x16, [SP, #-8]!
    // 0xc51760: r0 = _innerPositions()
    //     0xc51760: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc51764: add             SP, SP, #8
    // 0xc51768: r1 = LoadClassIdInstr(r0)
    //     0xc51768: ldur            x1, [x0, #-1]
    //     0xc5176c: ubfx            x1, x1, #0xc, #0x14
    // 0xc51770: SaveReg r0
    //     0xc51770: str             x0, [SP, #-8]!
    // 0xc51774: mov             x0, x1
    // 0xc51778: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc51778: mov             x17, #0xb940
    //     0xc5177c: add             lr, x0, x17
    //     0xc51780: ldr             lr, [x21, lr, lsl #3]
    //     0xc51784: blr             lr
    // 0xc51788: add             SP, SP, #8
    // 0xc5178c: mov             x1, x0
    // 0xc51790: stur            x1, [fp, #-8]
    // 0xc51794: ldr             d0, [fp, #0x10]
    // 0xc51798: CheckStackOverflow
    //     0xc51798: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5179c: cmp             SP, x16
    //     0xc517a0: b.ls            #0xc518c4
    // 0xc517a4: r0 = LoadClassIdInstr(r1)
    //     0xc517a4: ldur            x0, [x1, #-1]
    //     0xc517a8: ubfx            x0, x0, #0xc, #0x14
    // 0xc517ac: SaveReg r1
    //     0xc517ac: str             x1, [SP, #-8]!
    // 0xc517b0: r0 = GDT[cid_x0 + 0x541]()
    //     0xc517b0: add             lr, x0, #0x541
    //     0xc517b4: ldr             lr, [x21, lr, lsl #3]
    //     0xc517b8: blr             lr
    // 0xc517bc: add             SP, SP, #8
    // 0xc517c0: tbnz            w0, #4, #0xc51894
    // 0xc517c4: ldr             d0, [fp, #0x10]
    // 0xc517c8: ldur            x1, [fp, #-8]
    // 0xc517cc: r0 = LoadClassIdInstr(r1)
    //     0xc517cc: ldur            x0, [x1, #-1]
    //     0xc517d0: ubfx            x0, x0, #0xc, #0x14
    // 0xc517d4: SaveReg r1
    //     0xc517d4: str             x1, [SP, #-8]!
    // 0xc517d8: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc517d8: add             lr, x0, #0x5ca
    //     0xc517dc: ldr             lr, [x21, lr, lsl #3]
    //     0xc517e0: blr             lr
    // 0xc517e4: add             SP, SP, #8
    // 0xc517e8: stur            x0, [fp, #-0x10]
    // 0xc517ec: ldr             x16, [fp, #0x18]
    // 0xc517f0: SaveReg r16
    //     0xc517f0: str             x16, [SP, #-8]!
    // 0xc517f4: ldr             d0, [fp, #0x10]
    // 0xc517f8: SaveReg d0
    //     0xc517f8: str             d0, [SP, #-8]!
    // 0xc517fc: SaveReg r0
    //     0xc517fc: str             x0, [SP, #-8]!
    // 0xc51800: r0 = nestOffset()
    //     0xc51800: bl              #0xc51994  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::nestOffset
    // 0xc51804: add             SP, SP, #0x18
    // 0xc51808: ldur            x0, [fp, #-0x10]
    // 0xc5180c: LoadField: r1 = r0->field_43
    //     0xc5180c: ldur            w1, [x0, #0x43]
    // 0xc51810: DecompressPointer r1
    //     0xc51810: add             x1, x1, HEAP, lsl #32
    // 0xc51814: cmp             w1, NULL
    // 0xc51818: b.eq            #0xc518cc
    // 0xc5181c: LoadField: d1 = r1->field_7
    //     0xc5181c: ldur            d1, [x1, #7]
    // 0xc51820: stur            d1, [fp, #-0x18]
    // 0xc51824: fcmp            d1, d0
    // 0xc51828: b.eq            #0xc5188c
    // 0xc5182c: SaveReg r0
    //     0xc5182c: str             x0, [SP, #-8]!
    // 0xc51830: SaveReg d0
    //     0xc51830: str             d0, [SP, #-8]!
    // 0xc51834: r0 = forcePixels()
    //     0xc51834: bl              #0xc144d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::forcePixels
    // 0xc51838: add             SP, SP, #0x10
    // 0xc5183c: ldur            x16, [fp, #-0x10]
    // 0xc51840: SaveReg r16
    //     0xc51840: str             x16, [SP, #-8]!
    // 0xc51844: r0 = didStartScroll()
    //     0xc51844: bl              #0xbff488  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didStartScroll
    // 0xc51848: add             SP, SP, #8
    // 0xc5184c: ldur            x0, [fp, #-0x10]
    // 0xc51850: LoadField: r1 = r0->field_43
    //     0xc51850: ldur            w1, [x0, #0x43]
    // 0xc51854: DecompressPointer r1
    //     0xc51854: add             x1, x1, HEAP, lsl #32
    // 0xc51858: cmp             w1, NULL
    // 0xc5185c: b.eq            #0xc518d0
    // 0xc51860: LoadField: d0 = r1->field_7
    //     0xc51860: ldur            d0, [x1, #7]
    // 0xc51864: ldur            d1, [fp, #-0x18]
    // 0xc51868: fsub            d2, d0, d1
    // 0xc5186c: SaveReg r0
    //     0xc5186c: str             x0, [SP, #-8]!
    // 0xc51870: SaveReg d2
    //     0xc51870: str             d2, [SP, #-8]!
    // 0xc51874: r0 = didUpdateScrollPositionBy()
    //     0xc51874: bl              #0xc14400  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didUpdateScrollPositionBy
    // 0xc51878: add             SP, SP, #0x10
    // 0xc5187c: ldur            x16, [fp, #-0x10]
    // 0xc51880: SaveReg r16
    //     0xc51880: str             x16, [SP, #-8]!
    // 0xc51884: r0 = didEndScroll()
    //     0xc51884: bl              #0xbff54c  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didEndScroll
    // 0xc51888: add             SP, SP, #8
    // 0xc5188c: ldur            x1, [fp, #-8]
    // 0xc51890: b               #0xc51794
    // 0xc51894: ldr             x16, [fp, #0x18]
    // 0xc51898: stp             xzr, x16, [SP, #-0x10]!
    // 0xc5189c: r0 = goBallistic()
    //     0xc5189c: bl              #0xc5bd20  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::goBallistic
    // 0xc518a0: add             SP, SP, #0x10
    // 0xc518a4: r0 = Null
    //     0xc518a4: mov             x0, NULL
    // 0xc518a8: LeaveFrame
    //     0xc518a8: mov             SP, fp
    //     0xc518ac: ldp             fp, lr, [SP], #0x10
    // 0xc518b0: ret
    //     0xc518b0: ret             
    // 0xc518b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc518b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc518b8: b               #0xc516e4
    // 0xc518bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc518bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc518c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc518c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc518c4: r0 = StackOverflowSharedWithFPURegs()
    //     0xc518c4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc518c8: b               #0xc517a4
    // 0xc518cc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc518cc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc518d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc518d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ nestOffset(/* No info */) {
    // ** addr: 0xc51994, size: 0x27c
    // 0xc51994: EnterFrame
    //     0xc51994: stp             fp, lr, [SP, #-0x10]!
    //     0xc51998: mov             fp, SP
    // 0xc5199c: AllocStack(0x8)
    //     0xc5199c: sub             SP, SP, #8
    // 0xc519a0: CheckStackOverflow
    //     0xc519a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc519a4: cmp             SP, x16
    //     0xc519a8: b.ls            #0xc51bcc
    // 0xc519ac: ldr             x16, [fp, #0x20]
    // 0xc519b0: SaveReg r16
    //     0xc519b0: str             x16, [SP, #-8]!
    // 0xc519b4: r0 = _outerPosition()
    //     0xc519b4: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc519b8: add             SP, SP, #8
    // 0xc519bc: mov             x1, x0
    // 0xc519c0: ldr             x0, [fp, #0x10]
    // 0xc519c4: cmp             w0, w1
    // 0xc519c8: b.ne            #0xc51a64
    // 0xc519cc: ldr             d0, [fp, #0x18]
    // 0xc519d0: ldr             x16, [fp, #0x20]
    // 0xc519d4: SaveReg r16
    //     0xc519d4: str             x16, [SP, #-8]!
    // 0xc519d8: r0 = _outerPosition()
    //     0xc519d8: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc519dc: add             SP, SP, #8
    // 0xc519e0: cmp             w0, NULL
    // 0xc519e4: b.eq            #0xc51bd4
    // 0xc519e8: LoadField: r1 = r0->field_33
    //     0xc519e8: ldur            w1, [x0, #0x33]
    // 0xc519ec: DecompressPointer r1
    //     0xc519ec: add             x1, x1, HEAP, lsl #32
    // 0xc519f0: stur            x1, [fp, #-8]
    // 0xc519f4: cmp             w1, NULL
    // 0xc519f8: b.eq            #0xc51bd8
    // 0xc519fc: ldr             x16, [fp, #0x20]
    // 0xc51a00: SaveReg r16
    //     0xc51a00: str             x16, [SP, #-8]!
    // 0xc51a04: r0 = _outerPosition()
    //     0xc51a04: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51a08: add             SP, SP, #8
    // 0xc51a0c: cmp             w0, NULL
    // 0xc51a10: b.eq            #0xc51bdc
    // 0xc51a14: LoadField: r1 = r0->field_37
    //     0xc51a14: ldur            w1, [x0, #0x37]
    // 0xc51a18: DecompressPointer r1
    //     0xc51a18: add             x1, x1, HEAP, lsl #32
    // 0xc51a1c: cmp             w1, NULL
    // 0xc51a20: b.eq            #0xc51be0
    // 0xc51a24: ldur            x0, [fp, #-8]
    // 0xc51a28: LoadField: d0 = r0->field_7
    //     0xc51a28: ldur            d0, [x0, #7]
    // 0xc51a2c: ldr             d1, [fp, #0x18]
    // 0xc51a30: fcmp            d1, d0
    // 0xc51a34: b.vs            #0xc51a3c
    // 0xc51a38: b.lt            #0xc51a58
    // 0xc51a3c: LoadField: d0 = r1->field_7
    //     0xc51a3c: ldur            d0, [x1, #7]
    // 0xc51a40: fcmp            d1, d0
    // 0xc51a44: b.vs            #0xc51a4c
    // 0xc51a48: b.gt            #0xc51a58
    // 0xc51a4c: fcmp            d1, d1
    // 0xc51a50: b.vs            #0xc51a58
    // 0xc51a54: mov             v0.16b, v1.16b
    // 0xc51a58: LeaveFrame
    //     0xc51a58: mov             SP, fp
    //     0xc51a5c: ldp             fp, lr, [SP], #0x10
    // 0xc51a60: ret
    //     0xc51a60: ret             
    // 0xc51a64: ldr             d1, [fp, #0x18]
    // 0xc51a68: ldr             x16, [fp, #0x20]
    // 0xc51a6c: SaveReg r16
    //     0xc51a6c: str             x16, [SP, #-8]!
    // 0xc51a70: r0 = _outerPosition()
    //     0xc51a70: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51a74: add             SP, SP, #8
    // 0xc51a78: cmp             w0, NULL
    // 0xc51a7c: b.eq            #0xc51be4
    // 0xc51a80: LoadField: r1 = r0->field_33
    //     0xc51a80: ldur            w1, [x0, #0x33]
    // 0xc51a84: DecompressPointer r1
    //     0xc51a84: add             x1, x1, HEAP, lsl #32
    // 0xc51a88: cmp             w1, NULL
    // 0xc51a8c: b.eq            #0xc51be8
    // 0xc51a90: LoadField: d0 = r1->field_7
    //     0xc51a90: ldur            d0, [x1, #7]
    // 0xc51a94: ldr             d1, [fp, #0x18]
    // 0xc51a98: fcmp            d1, d0
    // 0xc51a9c: b.vs            #0xc51b08
    // 0xc51aa0: b.ge            #0xc51b08
    // 0xc51aa4: ldr             x0, [fp, #0x10]
    // 0xc51aa8: ldr             x16, [fp, #0x20]
    // 0xc51aac: SaveReg r16
    //     0xc51aac: str             x16, [SP, #-8]!
    // 0xc51ab0: r0 = _outerPosition()
    //     0xc51ab0: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51ab4: add             SP, SP, #8
    // 0xc51ab8: cmp             w0, NULL
    // 0xc51abc: b.eq            #0xc51bec
    // 0xc51ac0: LoadField: r1 = r0->field_33
    //     0xc51ac0: ldur            w1, [x0, #0x33]
    // 0xc51ac4: DecompressPointer r1
    //     0xc51ac4: add             x1, x1, HEAP, lsl #32
    // 0xc51ac8: cmp             w1, NULL
    // 0xc51acc: b.eq            #0xc51bf0
    // 0xc51ad0: LoadField: d0 = r1->field_7
    //     0xc51ad0: ldur            d0, [x1, #7]
    // 0xc51ad4: ldr             d1, [fp, #0x18]
    // 0xc51ad8: fsub            d2, d1, d0
    // 0xc51adc: ldr             x0, [fp, #0x10]
    // 0xc51ae0: LoadField: r1 = r0->field_33
    //     0xc51ae0: ldur            w1, [x0, #0x33]
    // 0xc51ae4: DecompressPointer r1
    //     0xc51ae4: add             x1, x1, HEAP, lsl #32
    // 0xc51ae8: cmp             w1, NULL
    // 0xc51aec: b.eq            #0xc51bf4
    // 0xc51af0: LoadField: d0 = r1->field_7
    //     0xc51af0: ldur            d0, [x1, #7]
    // 0xc51af4: fadd            d1, d2, d0
    // 0xc51af8: mov             v0.16b, v1.16b
    // 0xc51afc: LeaveFrame
    //     0xc51afc: mov             SP, fp
    //     0xc51b00: ldp             fp, lr, [SP], #0x10
    // 0xc51b04: ret
    //     0xc51b04: ret             
    // 0xc51b08: ldr             x0, [fp, #0x10]
    // 0xc51b0c: ldr             x16, [fp, #0x20]
    // 0xc51b10: SaveReg r16
    //     0xc51b10: str             x16, [SP, #-8]!
    // 0xc51b14: r0 = _outerPosition()
    //     0xc51b14: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51b18: add             SP, SP, #8
    // 0xc51b1c: cmp             w0, NULL
    // 0xc51b20: b.eq            #0xc51bf8
    // 0xc51b24: LoadField: r1 = r0->field_37
    //     0xc51b24: ldur            w1, [x0, #0x37]
    // 0xc51b28: DecompressPointer r1
    //     0xc51b28: add             x1, x1, HEAP, lsl #32
    // 0xc51b2c: cmp             w1, NULL
    // 0xc51b30: b.eq            #0xc51bfc
    // 0xc51b34: LoadField: d0 = r1->field_7
    //     0xc51b34: ldur            d0, [x1, #7]
    // 0xc51b38: ldr             d1, [fp, #0x18]
    // 0xc51b3c: fcmp            d1, d0
    // 0xc51b40: b.vs            #0xc51ba8
    // 0xc51b44: b.le            #0xc51ba8
    // 0xc51b48: ldr             x0, [fp, #0x10]
    // 0xc51b4c: ldr             x16, [fp, #0x20]
    // 0xc51b50: SaveReg r16
    //     0xc51b50: str             x16, [SP, #-8]!
    // 0xc51b54: r0 = _outerPosition()
    //     0xc51b54: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51b58: add             SP, SP, #8
    // 0xc51b5c: cmp             w0, NULL
    // 0xc51b60: b.eq            #0xc51c00
    // 0xc51b64: LoadField: r1 = r0->field_37
    //     0xc51b64: ldur            w1, [x0, #0x37]
    // 0xc51b68: DecompressPointer r1
    //     0xc51b68: add             x1, x1, HEAP, lsl #32
    // 0xc51b6c: cmp             w1, NULL
    // 0xc51b70: b.eq            #0xc51c04
    // 0xc51b74: LoadField: d1 = r1->field_7
    //     0xc51b74: ldur            d1, [x1, #7]
    // 0xc51b78: ldr             d2, [fp, #0x18]
    // 0xc51b7c: fsub            d3, d2, d1
    // 0xc51b80: ldr             x0, [fp, #0x10]
    // 0xc51b84: LoadField: r1 = r0->field_33
    //     0xc51b84: ldur            w1, [x0, #0x33]
    // 0xc51b88: DecompressPointer r1
    //     0xc51b88: add             x1, x1, HEAP, lsl #32
    // 0xc51b8c: cmp             w1, NULL
    // 0xc51b90: b.eq            #0xc51c08
    // 0xc51b94: LoadField: d1 = r1->field_7
    //     0xc51b94: ldur            d1, [x1, #7]
    // 0xc51b98: fadd            d0, d3, d1
    // 0xc51b9c: LeaveFrame
    //     0xc51b9c: mov             SP, fp
    //     0xc51ba0: ldp             fp, lr, [SP], #0x10
    // 0xc51ba4: ret
    //     0xc51ba4: ret             
    // 0xc51ba8: ldr             x0, [fp, #0x10]
    // 0xc51bac: LoadField: r1 = r0->field_33
    //     0xc51bac: ldur            w1, [x0, #0x33]
    // 0xc51bb0: DecompressPointer r1
    //     0xc51bb0: add             x1, x1, HEAP, lsl #32
    // 0xc51bb4: cmp             w1, NULL
    // 0xc51bb8: b.eq            #0xc51c0c
    // 0xc51bbc: LoadField: d0 = r1->field_7
    //     0xc51bbc: ldur            d0, [x1, #7]
    // 0xc51bc0: LeaveFrame
    //     0xc51bc0: mov             SP, fp
    //     0xc51bc4: ldp             fp, lr, [SP], #0x10
    // 0xc51bc8: ret
    //     0xc51bc8: ret             
    // 0xc51bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc51bcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc51bd0: b               #0xc519ac
    // 0xc51bd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51bd4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51bd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51bd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51bdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51bdc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51be0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51be0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51be4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51be4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51be8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51be8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51bec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51bec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51bf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51bf0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51bf4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc51bf4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc51bf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51bf8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51bfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51bfc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51c00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51c00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51c04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51c04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51c08: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc51c08: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc51c0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51c0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ unnestOffset(/* No info */) {
    // ** addr: 0xc51c10, size: 0x1b4
    // 0xc51c10: EnterFrame
    //     0xc51c10: stp             fp, lr, [SP, #-0x10]!
    //     0xc51c14: mov             fp, SP
    // 0xc51c18: AllocStack(0x10)
    //     0xc51c18: sub             SP, SP, #0x10
    // 0xc51c1c: CheckStackOverflow
    //     0xc51c1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc51c20: cmp             SP, x16
    //     0xc51c24: b.ls            #0xc51d98
    // 0xc51c28: ldr             x16, [fp, #0x20]
    // 0xc51c2c: SaveReg r16
    //     0xc51c2c: str             x16, [SP, #-8]!
    // 0xc51c30: r0 = _outerPosition()
    //     0xc51c30: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51c34: add             SP, SP, #8
    // 0xc51c38: mov             x1, x0
    // 0xc51c3c: ldr             x0, [fp, #0x10]
    // 0xc51c40: cmp             w0, w1
    // 0xc51c44: b.ne            #0xc51ce0
    // 0xc51c48: ldr             d0, [fp, #0x18]
    // 0xc51c4c: ldr             x16, [fp, #0x20]
    // 0xc51c50: SaveReg r16
    //     0xc51c50: str             x16, [SP, #-8]!
    // 0xc51c54: r0 = _outerPosition()
    //     0xc51c54: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51c58: add             SP, SP, #8
    // 0xc51c5c: cmp             w0, NULL
    // 0xc51c60: b.eq            #0xc51da0
    // 0xc51c64: LoadField: r1 = r0->field_33
    //     0xc51c64: ldur            w1, [x0, #0x33]
    // 0xc51c68: DecompressPointer r1
    //     0xc51c68: add             x1, x1, HEAP, lsl #32
    // 0xc51c6c: stur            x1, [fp, #-8]
    // 0xc51c70: cmp             w1, NULL
    // 0xc51c74: b.eq            #0xc51da4
    // 0xc51c78: ldr             x16, [fp, #0x20]
    // 0xc51c7c: SaveReg r16
    //     0xc51c7c: str             x16, [SP, #-8]!
    // 0xc51c80: r0 = _outerPosition()
    //     0xc51c80: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51c84: add             SP, SP, #8
    // 0xc51c88: cmp             w0, NULL
    // 0xc51c8c: b.eq            #0xc51da8
    // 0xc51c90: LoadField: r1 = r0->field_37
    //     0xc51c90: ldur            w1, [x0, #0x37]
    // 0xc51c94: DecompressPointer r1
    //     0xc51c94: add             x1, x1, HEAP, lsl #32
    // 0xc51c98: cmp             w1, NULL
    // 0xc51c9c: b.eq            #0xc51dac
    // 0xc51ca0: ldur            x0, [fp, #-8]
    // 0xc51ca4: LoadField: d0 = r0->field_7
    //     0xc51ca4: ldur            d0, [x0, #7]
    // 0xc51ca8: ldr             d1, [fp, #0x18]
    // 0xc51cac: fcmp            d1, d0
    // 0xc51cb0: b.vs            #0xc51cb8
    // 0xc51cb4: b.lt            #0xc51cd4
    // 0xc51cb8: LoadField: d0 = r1->field_7
    //     0xc51cb8: ldur            d0, [x1, #7]
    // 0xc51cbc: fcmp            d1, d0
    // 0xc51cc0: b.vs            #0xc51cc8
    // 0xc51cc4: b.gt            #0xc51cd4
    // 0xc51cc8: fcmp            d1, d1
    // 0xc51ccc: b.vs            #0xc51cd4
    // 0xc51cd0: mov             v0.16b, v1.16b
    // 0xc51cd4: LeaveFrame
    //     0xc51cd4: mov             SP, fp
    //     0xc51cd8: ldp             fp, lr, [SP], #0x10
    // 0xc51cdc: ret
    //     0xc51cdc: ret             
    // 0xc51ce0: ldr             d1, [fp, #0x18]
    // 0xc51ce4: LoadField: r1 = r0->field_33
    //     0xc51ce4: ldur            w1, [x0, #0x33]
    // 0xc51ce8: DecompressPointer r1
    //     0xc51ce8: add             x1, x1, HEAP, lsl #32
    // 0xc51cec: cmp             w1, NULL
    // 0xc51cf0: b.eq            #0xc51db0
    // 0xc51cf4: LoadField: d0 = r1->field_7
    //     0xc51cf4: ldur            d0, [x1, #7]
    // 0xc51cf8: fcmp            d1, d0
    // 0xc51cfc: b.vs            #0xc51d50
    // 0xc51d00: b.ge            #0xc51d50
    // 0xc51d04: fsub            d2, d1, d0
    // 0xc51d08: stur            d2, [fp, #-0x10]
    // 0xc51d0c: ldr             x16, [fp, #0x20]
    // 0xc51d10: SaveReg r16
    //     0xc51d10: str             x16, [SP, #-8]!
    // 0xc51d14: r0 = _outerPosition()
    //     0xc51d14: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51d18: add             SP, SP, #8
    // 0xc51d1c: cmp             w0, NULL
    // 0xc51d20: b.eq            #0xc51db4
    // 0xc51d24: LoadField: r1 = r0->field_33
    //     0xc51d24: ldur            w1, [x0, #0x33]
    // 0xc51d28: DecompressPointer r1
    //     0xc51d28: add             x1, x1, HEAP, lsl #32
    // 0xc51d2c: cmp             w1, NULL
    // 0xc51d30: b.eq            #0xc51db8
    // 0xc51d34: LoadField: d0 = r1->field_7
    //     0xc51d34: ldur            d0, [x1, #7]
    // 0xc51d38: ldur            d1, [fp, #-0x10]
    // 0xc51d3c: fadd            d2, d1, d0
    // 0xc51d40: mov             v0.16b, v2.16b
    // 0xc51d44: LeaveFrame
    //     0xc51d44: mov             SP, fp
    //     0xc51d48: ldp             fp, lr, [SP], #0x10
    // 0xc51d4c: ret
    //     0xc51d4c: ret             
    // 0xc51d50: fsub            d2, d1, d0
    // 0xc51d54: stur            d2, [fp, #-0x10]
    // 0xc51d58: ldr             x16, [fp, #0x20]
    // 0xc51d5c: SaveReg r16
    //     0xc51d5c: str             x16, [SP, #-8]!
    // 0xc51d60: r0 = _outerPosition()
    //     0xc51d60: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc51d64: add             SP, SP, #8
    // 0xc51d68: cmp             w0, NULL
    // 0xc51d6c: b.eq            #0xc51dbc
    // 0xc51d70: LoadField: r1 = r0->field_37
    //     0xc51d70: ldur            w1, [x0, #0x37]
    // 0xc51d74: DecompressPointer r1
    //     0xc51d74: add             x1, x1, HEAP, lsl #32
    // 0xc51d78: cmp             w1, NULL
    // 0xc51d7c: b.eq            #0xc51dc0
    // 0xc51d80: LoadField: d1 = r1->field_7
    //     0xc51d80: ldur            d1, [x1, #7]
    // 0xc51d84: ldur            d2, [fp, #-0x10]
    // 0xc51d88: fadd            d0, d2, d1
    // 0xc51d8c: LeaveFrame
    //     0xc51d8c: mov             SP, fp
    //     0xc51d90: ldp             fp, lr, [SP], #0x10
    // 0xc51d94: ret
    //     0xc51d94: ret             
    // 0xc51d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc51d98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc51d9c: b               #0xc51c28
    // 0xc51da0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51da0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51da4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51da4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51da8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51dac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51dac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51db0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc51db0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc51db4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51db4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51db8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51db8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51dbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51dbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51dc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51dc0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ goBallistic(/* No info */) {
    // ** addr: 0xc5bd20, size: 0xd0
    // 0xc5bd20: EnterFrame
    //     0xc5bd20: stp             fp, lr, [SP, #-0x10]!
    //     0xc5bd24: mov             fp, SP
    // 0xc5bd28: AllocStack(0x8)
    //     0xc5bd28: sub             SP, SP, #8
    // 0xc5bd2c: CheckStackOverflow
    //     0xc5bd2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5bd30: cmp             SP, x16
    //     0xc5bd34: b.ls            #0xc5bdcc
    // 0xc5bd38: r1 = 2
    //     0xc5bd38: mov             x1, #2
    // 0xc5bd3c: r0 = AllocateContext()
    //     0xc5bd3c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc5bd40: mov             x1, x0
    // 0xc5bd44: ldr             x0, [fp, #0x18]
    // 0xc5bd48: stur            x1, [fp, #-8]
    // 0xc5bd4c: StoreField: r1->field_f = r0
    //     0xc5bd4c: stur            w0, [x1, #0xf]
    // 0xc5bd50: ldr             d0, [fp, #0x10]
    // 0xc5bd54: r2 = inline_Allocate_Double()
    //     0xc5bd54: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xc5bd58: add             x2, x2, #0x10
    //     0xc5bd5c: cmp             x3, x2
    //     0xc5bd60: b.ls            #0xc5bdd4
    //     0xc5bd64: str             x2, [THR, #0x60]  ; THR::top
    //     0xc5bd68: sub             x2, x2, #0xf
    //     0xc5bd6c: mov             x3, #0xd108
    //     0xc5bd70: movk            x3, #3, lsl #16
    //     0xc5bd74: stur            x3, [x2, #-1]
    // 0xc5bd78: StoreField: r2->field_7 = d0
    //     0xc5bd78: stur            d0, [x2, #7]
    // 0xc5bd7c: StoreField: r1->field_13 = r2
    //     0xc5bd7c: stur            w2, [x1, #0x13]
    // 0xc5bd80: SaveReg r0
    //     0xc5bd80: str             x0, [SP, #-8]!
    // 0xc5bd84: SaveReg d0
    //     0xc5bd84: str             d0, [SP, #-8]!
    // 0xc5bd88: r0 = createOuterBallisticScrollActivity()
    //     0xc5bd88: bl              #0xbd0a90  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::createOuterBallisticScrollActivity
    // 0xc5bd8c: add             SP, SP, #0x10
    // 0xc5bd90: ldur            x2, [fp, #-8]
    // 0xc5bd94: r1 = Function '<anonymous closure>':.
    //     0xc5bd94: add             x1, PP, #0x40, lsl #12  ; [pp+0x40d90] AnonymousClosure: (0xc5bdf0), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::goBallistic (0xc5bd20)
    //     0xc5bd98: ldr             x1, [x1, #0xd90]
    // 0xc5bd9c: stur            x0, [fp, #-8]
    // 0xc5bda0: r0 = AllocateClosure()
    //     0xc5bda0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc5bda4: ldr             x16, [fp, #0x18]
    // 0xc5bda8: ldur            lr, [fp, #-8]
    // 0xc5bdac: stp             lr, x16, [SP, #-0x10]!
    // 0xc5bdb0: SaveReg r0
    //     0xc5bdb0: str             x0, [SP, #-8]!
    // 0xc5bdb4: r0 = beginActivity()
    //     0xc5bdb4: bl              #0xc37698  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::beginActivity
    // 0xc5bdb8: add             SP, SP, #0x18
    // 0xc5bdbc: r0 = Null
    //     0xc5bdbc: mov             x0, NULL
    // 0xc5bdc0: LeaveFrame
    //     0xc5bdc0: mov             SP, fp
    //     0xc5bdc4: ldp             fp, lr, [SP], #0x10
    // 0xc5bdc8: ret
    //     0xc5bdc8: ret             
    // 0xc5bdcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5bdcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5bdd0: b               #0xc5bd38
    // 0xc5bdd4: SaveReg d0
    //     0xc5bdd4: str             q0, [SP, #-0x10]!
    // 0xc5bdd8: stp             x0, x1, [SP, #-0x10]!
    // 0xc5bddc: r0 = AllocateDouble()
    //     0xc5bddc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc5bde0: mov             x2, x0
    // 0xc5bde4: ldp             x0, x1, [SP], #0x10
    // 0xc5bde8: RestoreReg d0
    //     0xc5bde8: ldr             q0, [SP], #0x10
    // 0xc5bdec: b               #0xc5bd78
  }
  [closure] ScrollActivity <anonymous closure>(dynamic, _NestedScrollPosition) {
    // ** addr: 0xc5bdf0, size: 0x5c
    // 0xc5bdf0: EnterFrame
    //     0xc5bdf0: stp             fp, lr, [SP, #-0x10]!
    //     0xc5bdf4: mov             fp, SP
    // 0xc5bdf8: ldr             x0, [fp, #0x18]
    // 0xc5bdfc: LoadField: r1 = r0->field_17
    //     0xc5bdfc: ldur            w1, [x0, #0x17]
    // 0xc5be00: DecompressPointer r1
    //     0xc5be00: add             x1, x1, HEAP, lsl #32
    // 0xc5be04: CheckStackOverflow
    //     0xc5be04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5be08: cmp             SP, x16
    //     0xc5be0c: b.ls            #0xc5be44
    // 0xc5be10: LoadField: r0 = r1->field_f
    //     0xc5be10: ldur            w0, [x1, #0xf]
    // 0xc5be14: DecompressPointer r0
    //     0xc5be14: add             x0, x0, HEAP, lsl #32
    // 0xc5be18: LoadField: r2 = r1->field_13
    //     0xc5be18: ldur            w2, [x1, #0x13]
    // 0xc5be1c: DecompressPointer r2
    //     0xc5be1c: add             x2, x2, HEAP, lsl #32
    // 0xc5be20: LoadField: d0 = r2->field_7
    //     0xc5be20: ldur            d0, [x2, #7]
    // 0xc5be24: ldr             x16, [fp, #0x10]
    // 0xc5be28: stp             x16, x0, [SP, #-0x10]!
    // 0xc5be2c: SaveReg d0
    //     0xc5be2c: str             d0, [SP, #-8]!
    // 0xc5be30: r0 = createInnerBallisticScrollActivity()
    //     0xc5be30: bl              #0xbcf984  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::createInnerBallisticScrollActivity
    // 0xc5be34: add             SP, SP, #0x18
    // 0xc5be38: LeaveFrame
    //     0xc5be38: mov             SP, fp
    //     0xc5be3c: ldp             fp, lr, [SP], #0x10
    // 0xc5be40: ret
    //     0xc5be40: ret             
    // 0xc5be44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5be44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5be48: b               #0xc5be10
  }
  _ animateTo(/* No info */) async {
    // ** addr: 0xc81c2c, size: 0x250
    // 0xc81c2c: EnterFrame
    //     0xc81c2c: stp             fp, lr, [SP, #-0x10]!
    //     0xc81c30: mov             fp, SP
    // 0xc81c34: AllocStack(0x38)
    //     0xc81c34: sub             SP, SP, #0x38
    // 0xc81c38: SetupParameters(_NestedScrollCoordinator this /* r1, fp-0x20 */, dynamic _ /* d0, fp-0x38 */, dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0xc81c38: stur            NULL, [fp, #-8]
    //     0xc81c3c: mov             x0, #0
    //     0xc81c40: add             x1, fp, w0, sxtw #2
    //     0xc81c44: ldr             x1, [x1, #0x28]
    //     0xc81c48: stur            x1, [fp, #-0x20]
    //     0xc81c4c: add             x2, fp, w0, sxtw #2
    //     0xc81c50: ldr             d0, [x2, #0x20]
    //     0xc81c54: stur            d0, [fp, #-0x38]
    //     0xc81c58: add             x2, fp, w0, sxtw #2
    //     0xc81c5c: ldr             x2, [x2, #0x18]
    //     0xc81c60: stur            x2, [fp, #-0x18]
    //     0xc81c64: add             x3, fp, w0, sxtw #2
    //     0xc81c68: ldr             x3, [x3, #0x10]
    //     0xc81c6c: stur            x3, [fp, #-0x10]
    // 0xc81c70: CheckStackOverflow
    //     0xc81c70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc81c74: cmp             SP, x16
    //     0xc81c78: b.ls            #0xc81e48
    // 0xc81c7c: r1 = 5
    //     0xc81c7c: mov             x1, #5
    // 0xc81c80: r0 = AllocateContext()
    //     0xc81c80: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc81c84: mov             x2, x0
    // 0xc81c88: ldur            x1, [fp, #-0x20]
    // 0xc81c8c: stur            x2, [fp, #-0x28]
    // 0xc81c90: StoreField: r2->field_f = r1
    //     0xc81c90: stur            w1, [x2, #0xf]
    // 0xc81c94: ldur            d0, [fp, #-0x38]
    // 0xc81c98: r0 = inline_Allocate_Double()
    //     0xc81c98: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xc81c9c: add             x0, x0, #0x10
    //     0xc81ca0: cmp             x3, x0
    //     0xc81ca4: b.ls            #0xc81e50
    //     0xc81ca8: str             x0, [THR, #0x60]  ; THR::top
    //     0xc81cac: sub             x0, x0, #0xf
    //     0xc81cb0: mov             x3, #0xd108
    //     0xc81cb4: movk            x3, #3, lsl #16
    //     0xc81cb8: stur            x3, [x0, #-1]
    // 0xc81cbc: StoreField: r0->field_7 = d0
    //     0xc81cbc: stur            d0, [x0, #7]
    // 0xc81cc0: StoreField: r2->field_13 = r0
    //     0xc81cc0: stur            w0, [x2, #0x13]
    // 0xc81cc4: ldur            x0, [fp, #-0x18]
    // 0xc81cc8: StoreField: r2->field_17 = r0
    //     0xc81cc8: stur            w0, [x2, #0x17]
    // 0xc81ccc: ldur            x0, [fp, #-0x10]
    // 0xc81cd0: StoreField: r2->field_1b = r0
    //     0xc81cd0: stur            w0, [x2, #0x1b]
    // 0xc81cd4: InitAsync() -> Future<void?>
    //     0xc81cd4: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc81cd8: bl              #0x4b92e4
    // 0xc81cdc: ldur            x16, [fp, #-0x20]
    // 0xc81ce0: SaveReg r16
    //     0xc81ce0: str             x16, [SP, #-8]!
    // 0xc81ce4: r0 = _outerPosition()
    //     0xc81ce4: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc81ce8: add             SP, SP, #8
    // 0xc81cec: stur            x0, [fp, #-0x18]
    // 0xc81cf0: cmp             w0, NULL
    // 0xc81cf4: b.eq            #0xc81e68
    // 0xc81cf8: ldur            x2, [fp, #-0x28]
    // 0xc81cfc: LoadField: r1 = r2->field_13
    //     0xc81cfc: ldur            w1, [x2, #0x13]
    // 0xc81d00: DecompressPointer r1
    //     0xc81d00: add             x1, x1, HEAP, lsl #32
    // 0xc81d04: stur            x1, [fp, #-0x10]
    // 0xc81d08: ldur            x16, [fp, #-0x20]
    // 0xc81d0c: SaveReg r16
    //     0xc81d0c: str             x16, [SP, #-8]!
    // 0xc81d10: r0 = _outerPosition()
    //     0xc81d10: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc81d14: add             SP, SP, #8
    // 0xc81d18: cmp             w0, NULL
    // 0xc81d1c: b.eq            #0xc81e6c
    // 0xc81d20: ldur            x1, [fp, #-0x10]
    // 0xc81d24: LoadField: d0 = r1->field_7
    //     0xc81d24: ldur            d0, [x1, #7]
    // 0xc81d28: ldur            x16, [fp, #-0x20]
    // 0xc81d2c: SaveReg r16
    //     0xc81d2c: str             x16, [SP, #-8]!
    // 0xc81d30: SaveReg d0
    //     0xc81d30: str             d0, [SP, #-8]!
    // 0xc81d34: SaveReg r0
    //     0xc81d34: str             x0, [SP, #-8]!
    // 0xc81d38: r0 = nestOffset()
    //     0xc81d38: bl              #0xc51994  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::nestOffset
    // 0xc81d3c: add             SP, SP, #0x18
    // 0xc81d40: ldur            x2, [fp, #-0x28]
    // 0xc81d44: LoadField: r0 = r2->field_1b
    //     0xc81d44: ldur            w0, [x2, #0x1b]
    // 0xc81d48: DecompressPointer r0
    //     0xc81d48: add             x0, x0, HEAP, lsl #32
    // 0xc81d4c: LoadField: r1 = r2->field_17
    //     0xc81d4c: ldur            w1, [x2, #0x17]
    // 0xc81d50: DecompressPointer r1
    //     0xc81d50: add             x1, x1, HEAP, lsl #32
    // 0xc81d54: ldur            x16, [fp, #-0x18]
    // 0xc81d58: SaveReg r16
    //     0xc81d58: str             x16, [SP, #-8]!
    // 0xc81d5c: SaveReg d0
    //     0xc81d5c: str             d0, [SP, #-8]!
    // 0xc81d60: stp             x1, x0, [SP, #-0x10]!
    // 0xc81d64: r0 = createDrivenScrollActivity()
    //     0xc81d64: bl              #0xc81e7c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::createDrivenScrollActivity
    // 0xc81d68: add             SP, SP, #0x20
    // 0xc81d6c: stur            x0, [fp, #-0x18]
    // 0xc81d70: LoadField: r1 = r0->field_b
    //     0xc81d70: ldur            w1, [x0, #0xb]
    // 0xc81d74: DecompressPointer r1
    //     0xc81d74: add             x1, x1, HEAP, lsl #32
    // 0xc81d78: r16 = Sentinel
    //     0xc81d78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc81d7c: cmp             w1, w16
    // 0xc81d80: b.eq            #0xc81e70
    // 0xc81d84: LoadField: r3 = r1->field_b
    //     0xc81d84: ldur            w3, [x1, #0xb]
    // 0xc81d88: DecompressPointer r3
    //     0xc81d88: add             x3, x3, HEAP, lsl #32
    // 0xc81d8c: stur            x3, [fp, #-0x10]
    // 0xc81d90: r1 = Null
    //     0xc81d90: mov             x1, NULL
    // 0xc81d94: r2 = 2
    //     0xc81d94: mov             x2, #2
    // 0xc81d98: r0 = AllocateArray()
    //     0xc81d98: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc81d9c: mov             x2, x0
    // 0xc81da0: ldur            x0, [fp, #-0x10]
    // 0xc81da4: stur            x2, [fp, #-0x30]
    // 0xc81da8: StoreField: r2->field_f = r0
    //     0xc81da8: stur            w0, [x2, #0xf]
    // 0xc81dac: r1 = <Future<void?>>
    //     0xc81dac: add             x1, PP, #8, lsl #12  ; [pp+0x8478] TypeArguments: <Future<void?>>
    //     0xc81db0: ldr             x1, [x1, #0x478]
    // 0xc81db4: r0 = AllocateGrowableArray()
    //     0xc81db4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xc81db8: mov             x3, x0
    // 0xc81dbc: ldur            x0, [fp, #-0x30]
    // 0xc81dc0: stur            x3, [fp, #-0x10]
    // 0xc81dc4: StoreField: r3->field_f = r0
    //     0xc81dc4: stur            w0, [x3, #0xf]
    // 0xc81dc8: r0 = 2
    //     0xc81dc8: mov             x0, #2
    // 0xc81dcc: StoreField: r3->field_b = r0
    //     0xc81dcc: stur            w0, [x3, #0xb]
    // 0xc81dd0: mov             x0, x3
    // 0xc81dd4: ldur            x4, [fp, #-0x28]
    // 0xc81dd8: StoreField: r4->field_1f = r0
    //     0xc81dd8: stur            w0, [x4, #0x1f]
    //     0xc81ddc: ldurb           w16, [x4, #-1]
    //     0xc81de0: ldurb           w17, [x0, #-1]
    //     0xc81de4: and             x16, x17, x16, lsr #2
    //     0xc81de8: tst             x16, HEAP, lsr #32
    //     0xc81dec: b.eq            #0xc81df4
    //     0xc81df0: bl              #0xd682cc
    // 0xc81df4: mov             x2, x4
    // 0xc81df8: r1 = Function '<anonymous closure>':.
    //     0xc81df8: add             x1, PP, #0x51, lsl #12  ; [pp+0x51208] AnonymousClosure: (0xc81f14), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::animateTo (0xc81c2c)
    //     0xc81dfc: ldr             x1, [x1, #0x208]
    // 0xc81e00: r0 = AllocateClosure()
    //     0xc81e00: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc81e04: ldur            x16, [fp, #-0x20]
    // 0xc81e08: ldur            lr, [fp, #-0x18]
    // 0xc81e0c: stp             lr, x16, [SP, #-0x10]!
    // 0xc81e10: SaveReg r0
    //     0xc81e10: str             x0, [SP, #-8]!
    // 0xc81e14: r0 = beginActivity()
    //     0xc81e14: bl              #0xc37698  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::beginActivity
    // 0xc81e18: add             SP, SP, #0x18
    // 0xc81e1c: r16 = <void?>
    //     0xc81e1c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc81e20: ldur            lr, [fp, #-0x10]
    // 0xc81e24: stp             lr, x16, [SP, #-0x10]!
    // 0xc81e28: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc81e28: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc81e2c: r0 = wait()
    //     0xc81e2c: bl              #0x518f0c  ; [dart:async] Future::wait
    // 0xc81e30: add             SP, SP, #0x10
    // 0xc81e34: mov             x1, x0
    // 0xc81e38: stur            x1, [fp, #-0x10]
    // 0xc81e3c: r0 = Await()
    //     0xc81e3c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc81e40: r0 = Null
    //     0xc81e40: mov             x0, NULL
    // 0xc81e44: r0 = ReturnAsyncNotFuture()
    //     0xc81e44: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc81e48: r0 = StackOverflowSharedWithFPURegs()
    //     0xc81e48: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc81e4c: b               #0xc81c7c
    // 0xc81e50: SaveReg d0
    //     0xc81e50: str             q0, [SP, #-0x10]!
    // 0xc81e54: stp             x1, x2, [SP, #-0x10]!
    // 0xc81e58: r0 = AllocateDouble()
    //     0xc81e58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc81e5c: ldp             x1, x2, [SP], #0x10
    // 0xc81e60: RestoreReg d0
    //     0xc81e60: ldr             q0, [SP], #0x10
    // 0xc81e64: b               #0xc81cbc
    // 0xc81e68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc81e68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc81e6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc81e6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc81e70: r9 = _completer
    //     0xc81e70: add             x9, PP, #0x38, lsl #12  ; [pp+0x380a0] Field <DrivenScrollActivity._completer@460498029>: late final (offset: 0xc)
    //     0xc81e74: ldr             x9, [x9, #0xa0]
    // 0xc81e78: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc81e78: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] DrivenScrollActivity <anonymous closure>(dynamic, _NestedScrollPosition) {
    // ** addr: 0xc81f14, size: 0x1a0
    // 0xc81f14: EnterFrame
    //     0xc81f14: stp             fp, lr, [SP, #-0x10]!
    //     0xc81f18: mov             fp, SP
    // 0xc81f1c: AllocStack(0x20)
    //     0xc81f1c: sub             SP, SP, #0x20
    // 0xc81f20: SetupParameters()
    //     0xc81f20: ldr             x0, [fp, #0x18]
    //     0xc81f24: ldur            w1, [x0, #0x17]
    //     0xc81f28: add             x1, x1, HEAP, lsl #32
    //     0xc81f2c: stur            x1, [fp, #-8]
    // 0xc81f30: CheckStackOverflow
    //     0xc81f30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc81f34: cmp             SP, x16
    //     0xc81f38: b.ls            #0xc8209c
    // 0xc81f3c: LoadField: r0 = r1->field_f
    //     0xc81f3c: ldur            w0, [x1, #0xf]
    // 0xc81f40: DecompressPointer r0
    //     0xc81f40: add             x0, x0, HEAP, lsl #32
    // 0xc81f44: LoadField: r2 = r1->field_13
    //     0xc81f44: ldur            w2, [x1, #0x13]
    // 0xc81f48: DecompressPointer r2
    //     0xc81f48: add             x2, x2, HEAP, lsl #32
    // 0xc81f4c: LoadField: d0 = r2->field_7
    //     0xc81f4c: ldur            d0, [x2, #7]
    // 0xc81f50: SaveReg r0
    //     0xc81f50: str             x0, [SP, #-8]!
    // 0xc81f54: SaveReg d0
    //     0xc81f54: str             d0, [SP, #-8]!
    // 0xc81f58: ldr             x16, [fp, #0x10]
    // 0xc81f5c: SaveReg r16
    //     0xc81f5c: str             x16, [SP, #-8]!
    // 0xc81f60: r0 = nestOffset()
    //     0xc81f60: bl              #0xc51994  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::nestOffset
    // 0xc81f64: add             SP, SP, #0x18
    // 0xc81f68: ldur            x0, [fp, #-8]
    // 0xc81f6c: LoadField: r1 = r0->field_1b
    //     0xc81f6c: ldur            w1, [x0, #0x1b]
    // 0xc81f70: DecompressPointer r1
    //     0xc81f70: add             x1, x1, HEAP, lsl #32
    // 0xc81f74: LoadField: r2 = r0->field_17
    //     0xc81f74: ldur            w2, [x0, #0x17]
    // 0xc81f78: DecompressPointer r2
    //     0xc81f78: add             x2, x2, HEAP, lsl #32
    // 0xc81f7c: ldr             x16, [fp, #0x10]
    // 0xc81f80: SaveReg r16
    //     0xc81f80: str             x16, [SP, #-8]!
    // 0xc81f84: SaveReg d0
    //     0xc81f84: str             d0, [SP, #-8]!
    // 0xc81f88: stp             x2, x1, [SP, #-0x10]!
    // 0xc81f8c: r0 = createDrivenScrollActivity()
    //     0xc81f8c: bl              #0xc81e7c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::createDrivenScrollActivity
    // 0xc81f90: add             SP, SP, #0x20
    // 0xc81f94: mov             x3, x0
    // 0xc81f98: ldur            x0, [fp, #-8]
    // 0xc81f9c: stur            x3, [fp, #-0x18]
    // 0xc81fa0: LoadField: r4 = r0->field_1f
    //     0xc81fa0: ldur            w4, [x0, #0x1f]
    // 0xc81fa4: DecompressPointer r4
    //     0xc81fa4: add             x4, x4, HEAP, lsl #32
    // 0xc81fa8: stur            x4, [fp, #-0x10]
    // 0xc81fac: LoadField: r0 = r3->field_b
    //     0xc81fac: ldur            w0, [x3, #0xb]
    // 0xc81fb0: DecompressPointer r0
    //     0xc81fb0: add             x0, x0, HEAP, lsl #32
    // 0xc81fb4: r16 = Sentinel
    //     0xc81fb4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc81fb8: cmp             w0, w16
    // 0xc81fbc: b.eq            #0xc820a4
    // 0xc81fc0: LoadField: r5 = r0->field_b
    //     0xc81fc0: ldur            w5, [x0, #0xb]
    // 0xc81fc4: DecompressPointer r5
    //     0xc81fc4: add             x5, x5, HEAP, lsl #32
    // 0xc81fc8: stur            x5, [fp, #-8]
    // 0xc81fcc: LoadField: r2 = r4->field_7
    //     0xc81fcc: ldur            w2, [x4, #7]
    // 0xc81fd0: DecompressPointer r2
    //     0xc81fd0: add             x2, x2, HEAP, lsl #32
    // 0xc81fd4: mov             x0, x5
    // 0xc81fd8: r1 = Null
    //     0xc81fd8: mov             x1, NULL
    // 0xc81fdc: cmp             w2, NULL
    // 0xc81fe0: b.eq            #0xc82000
    // 0xc81fe4: LoadField: r4 = r2->field_17
    //     0xc81fe4: ldur            w4, [x2, #0x17]
    // 0xc81fe8: DecompressPointer r4
    //     0xc81fe8: add             x4, x4, HEAP, lsl #32
    // 0xc81fec: r8 = X0
    //     0xc81fec: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc81ff0: LoadField: r9 = r4->field_7
    //     0xc81ff0: ldur            x9, [x4, #7]
    // 0xc81ff4: r3 = Null
    //     0xc81ff4: add             x3, PP, #0x51, lsl #12  ; [pp+0x51210] Null
    //     0xc81ff8: ldr             x3, [x3, #0x210]
    // 0xc81ffc: blr             x9
    // 0xc82000: ldur            x0, [fp, #-0x10]
    // 0xc82004: LoadField: r1 = r0->field_b
    //     0xc82004: ldur            w1, [x0, #0xb]
    // 0xc82008: DecompressPointer r1
    //     0xc82008: add             x1, x1, HEAP, lsl #32
    // 0xc8200c: stur            x1, [fp, #-0x20]
    // 0xc82010: LoadField: r2 = r0->field_f
    //     0xc82010: ldur            w2, [x0, #0xf]
    // 0xc82014: DecompressPointer r2
    //     0xc82014: add             x2, x2, HEAP, lsl #32
    // 0xc82018: LoadField: r3 = r2->field_b
    //     0xc82018: ldur            w3, [x2, #0xb]
    // 0xc8201c: DecompressPointer r3
    //     0xc8201c: add             x3, x3, HEAP, lsl #32
    // 0xc82020: cmp             w1, w3
    // 0xc82024: b.ne            #0xc82034
    // 0xc82028: SaveReg r0
    //     0xc82028: str             x0, [SP, #-8]!
    // 0xc8202c: r0 = _growToNextCapacity()
    //     0xc8202c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc82030: add             SP, SP, #8
    // 0xc82034: ldur            x2, [fp, #-0x10]
    // 0xc82038: ldur            x3, [fp, #-0x20]
    // 0xc8203c: r4 = LoadInt32Instr(r3)
    //     0xc8203c: sbfx            x4, x3, #1, #0x1f
    // 0xc82040: add             x0, x4, #1
    // 0xc82044: lsl             x3, x0, #1
    // 0xc82048: StoreField: r2->field_b = r3
    //     0xc82048: stur            w3, [x2, #0xb]
    // 0xc8204c: mov             x1, x4
    // 0xc82050: cmp             x1, x0
    // 0xc82054: b.hs            #0xc820b0
    // 0xc82058: LoadField: r1 = r2->field_f
    //     0xc82058: ldur            w1, [x2, #0xf]
    // 0xc8205c: DecompressPointer r1
    //     0xc8205c: add             x1, x1, HEAP, lsl #32
    // 0xc82060: ldur            x0, [fp, #-8]
    // 0xc82064: ArrayStore: r1[r4] = r0  ; List_4
    //     0xc82064: add             x25, x1, x4, lsl #2
    //     0xc82068: add             x25, x25, #0xf
    //     0xc8206c: str             w0, [x25]
    //     0xc82070: tbz             w0, #0, #0xc8208c
    //     0xc82074: ldurb           w16, [x1, #-1]
    //     0xc82078: ldurb           w17, [x0, #-1]
    //     0xc8207c: and             x16, x17, x16, lsr #2
    //     0xc82080: tst             x16, HEAP, lsr #32
    //     0xc82084: b.eq            #0xc8208c
    //     0xc82088: bl              #0xd67e5c
    // 0xc8208c: ldur            x0, [fp, #-0x18]
    // 0xc82090: LeaveFrame
    //     0xc82090: mov             SP, fp
    //     0xc82094: ldp             fp, lr, [SP], #0x10
    // 0xc82098: ret
    //     0xc82098: ret             
    // 0xc8209c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8209c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc820a0: b               #0xc81f3c
    // 0xc820a4: r9 = _completer
    //     0xc820a4: add             x9, PP, #0x38, lsl #12  ; [pp+0x380a0] Field <DrivenScrollActivity._completer@460498029>: late final (offset: 0xc)
    //     0xc820a8: ldr             x9, [x9, #0xa0]
    // 0xc820ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc820ac: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc820b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc820b0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ cancel(/* No info */) {
    // ** addr: 0xcb6c30, size: 0x3c
    // 0xcb6c30: EnterFrame
    //     0xcb6c30: stp             fp, lr, [SP, #-0x10]!
    //     0xcb6c34: mov             fp, SP
    // 0xcb6c38: CheckStackOverflow
    //     0xcb6c38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb6c3c: cmp             SP, x16
    //     0xcb6c40: b.ls            #0xcb6c64
    // 0xcb6c44: ldr             x16, [fp, #0x10]
    // 0xcb6c48: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb6c4c: r0 = goBallistic()
    //     0xcb6c4c: bl              #0xc5bd20  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::goBallistic
    // 0xcb6c50: add             SP, SP, #0x10
    // 0xcb6c54: r0 = Null
    //     0xcb6c54: mov             x0, NULL
    // 0xcb6c58: LeaveFrame
    //     0xcb6c58: mov             SP, fp
    //     0xcb6c5c: ldp             fp, lr, [SP], #0x10
    // 0xcb6c60: ret
    //     0xcb6c60: ret             
    // 0xcb6c64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb6c64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb6c68: b               #0xcb6c44
  }
}

// class id: 4454, size: 0x34, field offset: 0x28
class _ExtendedNestedScrollCoordinator extends _NestedScrollCoordinator {

  get _ _innerController(/* No info */) {
    // ** addr: 0x830ffc, size: 0x78
    // 0x830ffc: EnterFrame
    //     0x830ffc: stp             fp, lr, [SP, #-0x10]!
    //     0x831000: mov             fp, SP
    // 0x831004: AllocStack(0x8)
    //     0x831004: sub             SP, SP, #8
    // 0x831008: ldr             x0, [fp, #0x10]
    // 0x83100c: LoadField: r3 = r0->field_1b
    //     0x83100c: ldur            w3, [x0, #0x1b]
    // 0x831010: DecompressPointer r3
    //     0x831010: add             x3, x3, HEAP, lsl #32
    // 0x831014: r16 = Sentinel
    //     0x831014: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x831018: cmp             w3, w16
    // 0x83101c: b.eq            #0x831068
    // 0x831020: mov             x0, x3
    // 0x831024: stur            x3, [fp, #-8]
    // 0x831028: r2 = Null
    //     0x831028: mov             x2, NULL
    // 0x83102c: r1 = Null
    //     0x83102c: mov             x1, NULL
    // 0x831030: r4 = LoadClassIdInstr(r0)
    //     0x831030: ldur            x4, [x0, #-1]
    //     0x831034: ubfx            x4, x4, #0xc, #0x14
    // 0x831038: r17 = 4858
    //     0x831038: mov             x17, #0x12fa
    // 0x83103c: cmp             x4, x17
    // 0x831040: b.eq            #0x831058
    // 0x831044: r8 = _ExtendedNestedScrollController
    //     0x831044: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2ee70] Type: _ExtendedNestedScrollController
    //     0x831048: ldr             x8, [x8, #0xe70]
    // 0x83104c: r3 = Null
    //     0x83104c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ee78] Null
    //     0x831050: ldr             x3, [x3, #0xe78]
    // 0x831054: r0 = DefaultTypeTest()
    //     0x831054: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x831058: ldur            x0, [fp, #-8]
    // 0x83105c: LeaveFrame
    //     0x83105c: mov             SP, fp
    //     0x831060: ldp             fp, lr, [SP], #0x10
    // 0x831064: ret
    //     0x831064: ret             
    // 0x831068: r9 = _innerController
    //     0x831068: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2ee88] Field <_NestedScrollCoordinator@454231548._innerController@454231548>: late (offset: 0x1c)
    //     0x83106c: ldr             x9, [x9, #0xe88]
    // 0x831070: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x831070: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _innerPositions(/* No info */) {
    // ** addr: 0x831190, size: 0x450
    // 0x831190: EnterFrame
    //     0x831190: stp             fp, lr, [SP, #-0x10]!
    //     0x831194: mov             fp, SP
    // 0x831198: AllocStack(0x80)
    //     0x831198: sub             SP, SP, #0x80
    // 0x83119c: CheckStackOverflow
    //     0x83119c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8311a0: cmp             SP, x16
    //     0x8311a4: b.ls            #0x8315b4
    // 0x8311a8: ldr             x3, [fp, #0x10]
    // 0x8311ac: LoadField: r4 = r3->field_1b
    //     0x8311ac: ldur            w4, [x3, #0x1b]
    // 0x8311b0: DecompressPointer r4
    //     0x8311b0: add             x4, x4, HEAP, lsl #32
    // 0x8311b4: r16 = Sentinel
    //     0x8311b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8311b8: cmp             w4, w16
    // 0x8311bc: b.eq            #0x8315bc
    // 0x8311c0: mov             x0, x4
    // 0x8311c4: stur            x4, [fp, #-0x60]
    // 0x8311c8: r2 = Null
    //     0x8311c8: mov             x2, NULL
    // 0x8311cc: r1 = Null
    //     0x8311cc: mov             x1, NULL
    // 0x8311d0: r4 = LoadClassIdInstr(r0)
    //     0x8311d0: ldur            x4, [x0, #-1]
    //     0x8311d4: ubfx            x4, x4, #0xc, #0x14
    // 0x8311d8: r17 = 4858
    //     0x8311d8: mov             x17, #0x12fa
    // 0x8311dc: cmp             x4, x17
    // 0x8311e0: b.eq            #0x8311f8
    // 0x8311e4: r8 = _ExtendedNestedScrollController
    //     0x8311e4: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2ee70] Type: _ExtendedNestedScrollController
    //     0x8311e8: ldr             x8, [x8, #0xe70]
    // 0x8311ec: r3 = Null
    //     0x8311ec: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ee98] Null
    //     0x8311f0: ldr             x3, [x3, #0xe98]
    // 0x8311f4: r0 = DefaultTypeTest()
    //     0x8311f4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x8311f8: ldur            x16, [fp, #-0x60]
    // 0x8311fc: SaveReg r16
    //     0x8311fc: str             x16, [SP, #-8]!
    // 0x831200: r0 = _releaseNestedPositions()
    //     0x831200: bl              #0x831a40  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollController::_releaseNestedPositions
    // 0x831204: add             SP, SP, #8
    // 0x831208: SaveReg r0
    //     0x831208: str             x0, [SP, #-8]!
    // 0x83120c: r0 = length()
    //     0x83120c: bl              #0x6fd7e0  ; [dart:core] Iterable::length
    // 0x831210: add             SP, SP, #8
    // 0x831214: r1 = LoadInt32Instr(r0)
    //     0x831214: sbfx            x1, x0, #1, #0x1f
    //     0x831218: tbz             w0, #0, #0x831220
    //     0x83121c: ldur            x1, [x0, #7]
    // 0x831220: cmp             x1, #1
    // 0x831224: b.le            #0x831350
    // 0x831228: ldr             x3, [fp, #0x10]
    // 0x83122c: LoadField: r4 = r3->field_1b
    //     0x83122c: ldur            w4, [x3, #0x1b]
    // 0x831230: DecompressPointer r4
    //     0x831230: add             x4, x4, HEAP, lsl #32
    // 0x831234: mov             x0, x4
    // 0x831238: stur            x4, [fp, #-0x60]
    // 0x83123c: r2 = Null
    //     0x83123c: mov             x2, NULL
    // 0x831240: r1 = Null
    //     0x831240: mov             x1, NULL
    // 0x831244: r4 = LoadClassIdInstr(r0)
    //     0x831244: ldur            x4, [x0, #-1]
    //     0x831248: ubfx            x4, x4, #0xc, #0x14
    // 0x83124c: r17 = 4858
    //     0x83124c: mov             x17, #0x12fa
    // 0x831250: cmp             x4, x17
    // 0x831254: b.eq            #0x83126c
    // 0x831258: r8 = _ExtendedNestedScrollController
    //     0x831258: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2ee70] Type: _ExtendedNestedScrollController
    //     0x83125c: ldr             x8, [x8, #0xe70]
    // 0x831260: r3 = Null
    //     0x831260: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eea8] Null
    //     0x831264: ldr             x3, [x3, #0xea8]
    // 0x831268: r0 = DefaultTypeTest()
    //     0x831268: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x83126c: ldur            x16, [fp, #-0x60]
    // 0x831270: SaveReg r16
    //     0x831270: str             x16, [SP, #-8]!
    // 0x831274: r0 = _releaseNestedPositions()
    //     0x831274: bl              #0x831a40  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollController::_releaseNestedPositions
    // 0x831278: add             SP, SP, #8
    // 0x83127c: r1 = Function '<anonymous closure>':.
    //     0x83127c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2eeb8] AnonymousClosure: (0xc64048), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions (0x831190)
    //     0x831280: ldr             x1, [x1, #0xeb8]
    // 0x831284: r2 = Null
    //     0x831284: mov             x2, NULL
    // 0x831288: stur            x0, [fp, #-0x60]
    // 0x83128c: r0 = AllocateClosure()
    //     0x83128c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x831290: ldur            x16, [fp, #-0x60]
    // 0x831294: stp             x0, x16, [SP, #-0x10]!
    // 0x831298: r0 = where()
    //     0x831298: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0x83129c: add             SP, SP, #0x10
    // 0x8312a0: stur            x0, [fp, #-0x60]
    // 0x8312a4: SaveReg r0
    //     0x8312a4: str             x0, [SP, #-8]!
    // 0x8312a8: r0 = iterator()
    //     0x8312a8: bl              #0x6fca1c  ; [dart:_internal] WhereIterable::iterator
    // 0x8312ac: add             SP, SP, #8
    // 0x8312b0: r1 = LoadClassIdInstr(r0)
    //     0x8312b0: ldur            x1, [x0, #-1]
    //     0x8312b4: ubfx            x1, x1, #0xc, #0x14
    // 0x8312b8: SaveReg r0
    //     0x8312b8: str             x0, [SP, #-8]!
    // 0x8312bc: mov             x0, x1
    // 0x8312c0: r0 = GDT[cid_x0 + 0x541]()
    //     0x8312c0: add             lr, x0, #0x541
    //     0x8312c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8312c8: blr             lr
    // 0x8312cc: add             SP, SP, #8
    // 0x8312d0: eor             x1, x0, #0x10
    // 0x8312d4: tbnz            w1, #4, #0x831340
    // 0x8312d8: ldr             x3, [fp, #0x10]
    // 0x8312dc: LoadField: r4 = r3->field_1b
    //     0x8312dc: ldur            w4, [x3, #0x1b]
    // 0x8312e0: DecompressPointer r4
    //     0x8312e0: add             x4, x4, HEAP, lsl #32
    // 0x8312e4: mov             x0, x4
    // 0x8312e8: stur            x4, [fp, #-0x68]
    // 0x8312ec: r2 = Null
    //     0x8312ec: mov             x2, NULL
    // 0x8312f0: r1 = Null
    //     0x8312f0: mov             x1, NULL
    // 0x8312f4: r4 = LoadClassIdInstr(r0)
    //     0x8312f4: ldur            x4, [x0, #-1]
    //     0x8312f8: ubfx            x4, x4, #0xc, #0x14
    // 0x8312fc: r17 = 4858
    //     0x8312fc: mov             x17, #0x12fa
    // 0x831300: cmp             x4, x17
    // 0x831304: b.eq            #0x83131c
    // 0x831308: r8 = _ExtendedNestedScrollController
    //     0x831308: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2ee70] Type: _ExtendedNestedScrollController
    //     0x83130c: ldr             x8, [x8, #0xe70]
    // 0x831310: r3 = Null
    //     0x831310: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eec0] Null
    //     0x831314: ldr             x3, [x3, #0xec0]
    // 0x831318: r0 = DefaultTypeTest()
    //     0x831318: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x83131c: ldur            x16, [fp, #-0x68]
    // 0x831320: SaveReg r16
    //     0x831320: str             x16, [SP, #-8]!
    // 0x831324: r0 = _releaseNestedPositions()
    //     0x831324: bl              #0x831a40  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollController::_releaseNestedPositions
    // 0x831328: add             SP, SP, #8
    // 0x83132c: SaveReg r0
    //     0x83132c: str             x0, [SP, #-8]!
    // 0x831330: r0 = iterator()
    //     0x831330: bl              #0x6fc300  ; [dart:async] _SyncStarIterable::iterator
    // 0x831334: add             SP, SP, #8
    // 0x831338: ldr             x1, [fp, #0x10]
    // 0x83133c: b               #0x8313bc
    // 0x831340: ldur            x0, [fp, #-0x60]
    // 0x831344: LeaveFrame
    //     0x831344: mov             SP, fp
    //     0x831348: ldp             fp, lr, [SP], #0x10
    // 0x83134c: ret
    //     0x83134c: ret             
    // 0x831350: ldr             x0, [fp, #0x10]
    // 0x831354: LoadField: r3 = r0->field_1b
    //     0x831354: ldur            w3, [x0, #0x1b]
    // 0x831358: DecompressPointer r3
    //     0x831358: add             x3, x3, HEAP, lsl #32
    // 0x83135c: mov             x0, x3
    // 0x831360: stur            x3, [fp, #-0x60]
    // 0x831364: r2 = Null
    //     0x831364: mov             x2, NULL
    // 0x831368: r1 = Null
    //     0x831368: mov             x1, NULL
    // 0x83136c: r4 = LoadClassIdInstr(r0)
    //     0x83136c: ldur            x4, [x0, #-1]
    //     0x831370: ubfx            x4, x4, #0xc, #0x14
    // 0x831374: r17 = 4858
    //     0x831374: mov             x17, #0x12fa
    // 0x831378: cmp             x4, x17
    // 0x83137c: b.eq            #0x831394
    // 0x831380: r8 = _ExtendedNestedScrollController
    //     0x831380: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2ee70] Type: _ExtendedNestedScrollController
    //     0x831384: ldr             x8, [x8, #0xe70]
    // 0x831388: r3 = Null
    //     0x831388: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eed0] Null
    //     0x83138c: ldr             x3, [x3, #0xed0]
    // 0x831390: r0 = DefaultTypeTest()
    //     0x831390: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x831394: ldur            x16, [fp, #-0x60]
    // 0x831398: SaveReg r16
    //     0x831398: str             x16, [SP, #-8]!
    // 0x83139c: r0 = _releaseNestedPositions()
    //     0x83139c: bl              #0x831a40  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollController::_releaseNestedPositions
    // 0x8313a0: add             SP, SP, #8
    // 0x8313a4: LeaveFrame
    //     0x8313a4: mov             SP, fp
    //     0x8313a8: ldp             fp, lr, [SP], #0x10
    // 0x8313ac: ret
    //     0x8313ac: ret             
    // 0x8313b0: sub             SP, fp, #0x80
    // 0x8313b4: ldr             x1, [fp, #0x10]
    // 0x8313b8: ldur            x0, [fp, #-0x40]
    // 0x8313bc: stur            x1, [fp, #-0x60]
    // 0x8313c0: stur            x0, [fp, #-0x68]
    // 0x8313c4: CheckStackOverflow
    //     0x8313c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8313c8: cmp             SP, x16
    //     0x8313cc: b.ls            #0x8315c8
    // 0x8313d0: SaveReg r0
    //     0x8313d0: str             x0, [SP, #-8]!
    // 0x8313d4: r0 = moveNext()
    //     0x8313d4: bl              #0xc385b0  ; [dart:async] _SyncStarIterator::moveNext
    // 0x8313d8: add             SP, SP, #8
    // 0x8313dc: mov             x1, x0
    // 0x8313e0: stur            x1, [fp, #-0x70]
    // 0x8313e4: tbnz            w0, #5, #0x8313ec
    // 0x8313e8: r0 = AssertBoolean()
    //     0x8313e8: bl              #0xd67df0  ; AssertBooleanStub
    // 0x8313ec: ldur            x0, [fp, #-0x70]
    // 0x8313f0: tbnz            w0, #4, #0x831548
    // 0x8313f4: ldur            x3, [fp, #-0x68]
    // 0x8313f8: LoadField: r4 = r3->field_17
    //     0x8313f8: ldur            w4, [x3, #0x17]
    // 0x8313fc: DecompressPointer r4
    //     0x8313fc: add             x4, x4, HEAP, lsl #32
    // 0x831400: stur            x4, [fp, #-0x70]
    // 0x831404: cmp             w4, NULL
    // 0x831408: b.ne            #0x831440
    // 0x83140c: LoadField: r2 = r3->field_7
    //     0x83140c: ldur            w2, [x3, #7]
    // 0x831410: DecompressPointer r2
    //     0x831410: add             x2, x2, HEAP, lsl #32
    // 0x831414: mov             x0, x4
    // 0x831418: r1 = Null
    //     0x831418: mov             x1, NULL
    // 0x83141c: cmp             w2, NULL
    // 0x831420: b.eq            #0x831440
    // 0x831424: LoadField: r4 = r2->field_17
    //     0x831424: ldur            w4, [x2, #0x17]
    // 0x831428: DecompressPointer r4
    //     0x831428: add             x4, x4, HEAP, lsl #32
    // 0x83142c: r8 = X0
    //     0x83142c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x831430: LoadField: r9 = r4->field_7
    //     0x831430: ldur            x9, [x4, #7]
    // 0x831434: r3 = Null
    //     0x831434: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eee0] Null
    //     0x831438: ldr             x3, [x3, #0xee0]
    // 0x83143c: blr             x9
    // 0x831440: ldur            x0, [fp, #-0x70]
    // 0x831444: LoadField: r1 = r0->field_27
    //     0x831444: ldur            w1, [x0, #0x27]
    // 0x831448: DecompressPointer r1
    //     0x831448: add             x1, x1, HEAP, lsl #32
    // 0x83144c: stur            x1, [fp, #-0x78]
    // 0x831450: LoadField: r2 = r1->field_f
    //     0x831450: ldur            w2, [x1, #0xf]
    // 0x831454: DecompressPointer r2
    //     0x831454: add             x2, x2, HEAP, lsl #32
    // 0x831458: cmp             w2, NULL
    // 0x83145c: b.ne            #0x83146c
    // 0x831460: ldur            x1, [fp, #-0x60]
    // 0x831464: ldur            x0, [fp, #-0x68]
    // 0x831468: b               #0x8313bc
    // 0x83146c: SaveReg r2
    //     0x83146c: str             x2, [SP, #-8]!
    // 0x831470: r0 = findRenderObject()
    //     0x831470: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x831474: add             SP, SP, #8
    // 0x831478: stur            x0, [fp, #-0x80]
    // 0x83147c: cmp             w0, NULL
    // 0x831480: b.eq            #0x831494
    // 0x831484: LoadField: r1 = r0->field_f
    //     0x831484: ldur            w1, [x0, #0xf]
    // 0x831488: DecompressPointer r1
    //     0x831488: add             x1, x1, HEAP, lsl #32
    // 0x83148c: cmp             w1, NULL
    // 0x831490: b.ne            #0x8314a0
    // 0x831494: ldur            x1, [fp, #-0x60]
    // 0x831498: ldur            x0, [fp, #-0x68]
    // 0x83149c: b               #0x8313bc
    // 0x8314a0: ldur            x1, [fp, #-0x78]
    // 0x8314a4: LoadField: r2 = r1->field_f
    //     0x8314a4: ldur            w2, [x1, #0xf]
    // 0x8314a8: DecompressPointer r2
    //     0x8314a8: add             x2, x2, HEAP, lsl #32
    // 0x8314ac: cmp             w2, NULL
    // 0x8314b0: b.eq            #0x8315d0
    // 0x8314b4: SaveReg r2
    //     0x8314b4: str             x2, [SP, #-8]!
    // 0x8314b8: r0 = of()
    //     0x8314b8: bl              #0x8319f8  ; [package:extended_nested_scroll_view/src/extended_visibility_detector.dart] ExtendedVisibilityDetector::of
    // 0x8314bc: add             SP, SP, #8
    // 0x8314c0: ldur            x16, [fp, #-0x60]
    // 0x8314c4: ldur            lr, [fp, #-0x80]
    // 0x8314c8: stp             lr, x16, [SP, #-0x10]!
    // 0x8314cc: r16 = Instance_Axis
    //     0x8314cc: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x8314d0: ldr             x16, [x16, #0x440]
    // 0x8314d4: SaveReg r16
    //     0x8314d4: str             x16, [SP, #-8]!
    // 0x8314d8: r0 = renderObjectIsVisible()
    //     0x8314d8: bl              #0x8315e0  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::renderObjectIsVisible
    // 0x8314dc: add             SP, SP, #0x18
    // 0x8314e0: tbnz            w0, #4, #0x831538
    // 0x8314e4: ldur            x0, [fp, #-0x70]
    // 0x8314e8: r3 = 2
    //     0x8314e8: mov             x3, #2
    // 0x8314ec: mov             x2, x3
    // 0x8314f0: r1 = Null
    //     0x8314f0: mov             x1, NULL
    // 0x8314f4: r0 = AllocateArray()
    //     0x8314f4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x8314f8: mov             x2, x0
    // 0x8314fc: ldur            x0, [fp, #-0x70]
    // 0x831500: stur            x2, [fp, #-0x78]
    // 0x831504: StoreField: r2->field_f = r0
    //     0x831504: stur            w0, [x2, #0xf]
    // 0x831508: r1 = <_ExtendedNestedScrollPosition>
    //     0x831508: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2eef0] TypeArguments: <_ExtendedNestedScrollPosition>
    //     0x83150c: ldr             x1, [x1, #0xef0]
    // 0x831510: r0 = AllocateGrowableArray()
    //     0x831510: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x831514: mov             x1, x0
    // 0x831518: ldur            x0, [fp, #-0x78]
    // 0x83151c: StoreField: r1->field_f = r0
    //     0x83151c: stur            w0, [x1, #0xf]
    // 0x831520: r0 = 2
    //     0x831520: mov             x0, #2
    // 0x831524: StoreField: r1->field_b = r0
    //     0x831524: stur            w0, [x1, #0xb]
    // 0x831528: mov             x0, x1
    // 0x83152c: LeaveFrame
    //     0x83152c: mov             SP, fp
    //     0x831530: ldp             fp, lr, [SP], #0x10
    // 0x831534: ret
    //     0x831534: ret             
    // 0x831538: r0 = 2
    //     0x831538: mov             x0, #2
    // 0x83153c: ldur            x1, [fp, #-0x60]
    // 0x831540: ldur            x0, [fp, #-0x68]
    // 0x831544: b               #0x8313bc
    // 0x831548: ldur            x0, [fp, #-0x60]
    // 0x83154c: LoadField: r3 = r0->field_1b
    //     0x83154c: ldur            w3, [x0, #0x1b]
    // 0x831550: DecompressPointer r3
    //     0x831550: add             x3, x3, HEAP, lsl #32
    // 0x831554: r16 = Sentinel
    //     0x831554: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x831558: cmp             w3, w16
    // 0x83155c: b.eq            #0x8315d4
    // 0x831560: mov             x0, x3
    // 0x831564: stur            x3, [fp, #-0x68]
    // 0x831568: r2 = Null
    //     0x831568: mov             x2, NULL
    // 0x83156c: r1 = Null
    //     0x83156c: mov             x1, NULL
    // 0x831570: r4 = LoadClassIdInstr(r0)
    //     0x831570: ldur            x4, [x0, #-1]
    //     0x831574: ubfx            x4, x4, #0xc, #0x14
    // 0x831578: r17 = 4858
    //     0x831578: mov             x17, #0x12fa
    // 0x83157c: cmp             x4, x17
    // 0x831580: b.eq            #0x831598
    // 0x831584: r8 = _ExtendedNestedScrollController
    //     0x831584: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2ee70] Type: _ExtendedNestedScrollController
    //     0x831588: ldr             x8, [x8, #0xe70]
    // 0x83158c: r3 = Null
    //     0x83158c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eef8] Null
    //     0x831590: ldr             x3, [x3, #0xef8]
    // 0x831594: r0 = DefaultTypeTest()
    //     0x831594: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x831598: ldur            x16, [fp, #-0x68]
    // 0x83159c: SaveReg r16
    //     0x83159c: str             x16, [SP, #-8]!
    // 0x8315a0: r0 = _releaseNestedPositions()
    //     0x8315a0: bl              #0x831a40  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollController::_releaseNestedPositions
    // 0x8315a4: add             SP, SP, #8
    // 0x8315a8: LeaveFrame
    //     0x8315a8: mov             SP, fp
    //     0x8315ac: ldp             fp, lr, [SP], #0x10
    // 0x8315b0: ret
    //     0x8315b0: ret             
    // 0x8315b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8315b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8315b8: b               #0x8311a8
    // 0x8315bc: r9 = _innerController
    //     0x8315bc: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2ee88] Field <_NestedScrollCoordinator@454231548._innerController@454231548>: late (offset: 0x1c)
    //     0x8315c0: ldr             x9, [x9, #0xe88]
    // 0x8315c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8315c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8315c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8315c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8315cc: b               #0x8313d0
    // 0x8315d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8315d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8315d4: r9 = _innerController
    //     0x8315d4: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2ee88] Field <_NestedScrollCoordinator@454231548._innerController@454231548>: late (offset: 0x1c)
    //     0x8315d8: ldr             x9, [x9, #0xe88]
    // 0x8315dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8315dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ renderObjectIsVisible(/* No info */) {
    // ** addr: 0x8315e0, size: 0x1bc
    // 0x8315e0: EnterFrame
    //     0x8315e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8315e4: mov             fp, SP
    // 0x8315e8: AllocStack(0x20)
    //     0x8315e8: sub             SP, SP, #0x20
    // 0x8315ec: CheckStackOverflow
    //     0x8315ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8315f0: cmp             SP, x16
    //     0x8315f4: b.ls            #0x831794
    // 0x8315f8: ldr             x16, [fp, #0x20]
    // 0x8315fc: ldr             lr, [fp, #0x18]
    // 0x831600: stp             lr, x16, [SP, #-0x10]!
    // 0x831604: r0 = findParentRenderViewport()
    //     0x831604: bl              #0x8318b8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::findParentRenderViewport
    // 0x831608: add             SP, SP, #0x10
    // 0x83160c: stur            x0, [fp, #-8]
    // 0x831610: cmp             w0, NULL
    // 0x831614: b.eq            #0x831764
    // 0x831618: ldr             x1, [fp, #0x10]
    // 0x83161c: SaveReg r0
    //     0x83161c: str             x0, [SP, #-8]!
    // 0x831620: r0 = axis()
    //     0x831620: bl              #0x62ae44  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::axis
    // 0x831624: add             SP, SP, #8
    // 0x831628: mov             x1, x0
    // 0x83162c: ldr             x0, [fp, #0x10]
    // 0x831630: cmp             w1, w0
    // 0x831634: b.ne            #0x831764
    // 0x831638: ldur            x16, [fp, #-8]
    // 0x83163c: SaveReg r16
    //     0x83163c: str             x16, [SP, #-8]!
    // 0x831640: r0 = childrenInHitTestOrder()
    //     0x831640: bl              #0xcbd02c  ; [package:flutter/src/rendering/viewport.dart] RenderViewport::childrenInHitTestOrder
    // 0x831644: add             SP, SP, #8
    // 0x831648: mov             x1, x0
    // 0x83164c: stur            x1, [fp, #-0x20]
    // 0x831650: LoadField: r2 = r1->field_7
    //     0x831650: ldur            w2, [x1, #7]
    // 0x831654: DecompressPointer r2
    //     0x831654: add             x2, x2, HEAP, lsl #32
    // 0x831658: stur            x2, [fp, #-0x18]
    // 0x83165c: LoadField: r0 = r1->field_b
    //     0x83165c: ldur            w0, [x1, #0xb]
    // 0x831660: DecompressPointer r0
    //     0x831660: add             x0, x0, HEAP, lsl #32
    // 0x831664: r3 = LoadInt32Instr(r0)
    //     0x831664: sbfx            x3, x0, #1, #0x1f
    // 0x831668: stur            x3, [fp, #-0x10]
    // 0x83166c: r0 = LoadClassIdInstr(r1)
    //     0x83166c: ldur            x0, [x1, #-1]
    //     0x831670: ubfx            x0, x0, #0xc, #0x14
    // 0x831674: SaveReg r1
    //     0x831674: str             x1, [SP, #-8]!
    // 0x831678: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x831678: mov             x17, #0xb8ea
    //     0x83167c: add             lr, x0, x17
    //     0x831680: ldr             lr, [x21, lr, lsl #3]
    //     0x831684: blr             lr
    // 0x831688: add             SP, SP, #8
    // 0x83168c: r1 = LoadInt32Instr(r0)
    //     0x83168c: sbfx            x1, x0, #1, #0x1f
    //     0x831690: tbz             w0, #0, #0x831698
    //     0x831694: ldur            x1, [x0, #7]
    // 0x831698: ldur            x0, [fp, #-0x10]
    // 0x83169c: cmp             x0, x1
    // 0x8316a0: b.ne            #0x831774
    // 0x8316a4: ldur            x0, [fp, #-0x20]
    // 0x8316a8: cmp             x1, #0
    // 0x8316ac: b.le            #0x831764
    // 0x8316b0: r1 = LoadClassIdInstr(r0)
    //     0x8316b0: ldur            x1, [x0, #-1]
    //     0x8316b4: ubfx            x1, x1, #0xc, #0x14
    // 0x8316b8: stp             xzr, x0, [SP, #-0x10]!
    // 0x8316bc: mov             x0, x1
    // 0x8316c0: r0 = GDT[cid_x0 + 0xd175]()
    //     0x8316c0: mov             x17, #0xd175
    //     0x8316c4: add             lr, x0, x17
    //     0x8316c8: ldr             lr, [x21, lr, lsl #3]
    //     0x8316cc: blr             lr
    // 0x8316d0: add             SP, SP, #0x10
    // 0x8316d4: mov             x3, x0
    // 0x8316d8: stur            x3, [fp, #-0x20]
    // 0x8316dc: cmp             w3, NULL
    // 0x8316e0: b.ne            #0x831714
    // 0x8316e4: mov             x0, x3
    // 0x8316e8: ldur            x2, [fp, #-0x18]
    // 0x8316ec: r1 = Null
    //     0x8316ec: mov             x1, NULL
    // 0x8316f0: cmp             w2, NULL
    // 0x8316f4: b.eq            #0x831714
    // 0x8316f8: LoadField: r4 = r2->field_17
    //     0x8316f8: ldur            w4, [x2, #0x17]
    // 0x8316fc: DecompressPointer r4
    //     0x8316fc: add             x4, x4, HEAP, lsl #32
    // 0x831700: r8 = X0
    //     0x831700: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x831704: LoadField: r9 = r4->field_7
    //     0x831704: ldur            x9, [x4, #7]
    // 0x831708: r3 = Null
    //     0x831708: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ef08] Null
    //     0x83170c: ldr             x3, [x3, #0xf08]
    // 0x831710: blr             x9
    // 0x831714: ldr             x16, [fp, #0x20]
    // 0x831718: ldur            lr, [fp, #-0x20]
    // 0x83171c: stp             lr, x16, [SP, #-0x10]!
    // 0x831720: ldr             x16, [fp, #0x18]
    // 0x831724: SaveReg r16
    //     0x831724: str             x16, [SP, #-8]!
    // 0x831728: r0 = childIsVisible()
    //     0x831728: bl              #0x83179c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::childIsVisible
    // 0x83172c: add             SP, SP, #0x18
    // 0x831730: tbnz            w0, #4, #0x831754
    // 0x831734: ldr             x16, [fp, #0x20]
    // 0x831738: ldur            lr, [fp, #-8]
    // 0x83173c: stp             lr, x16, [SP, #-0x10]!
    // 0x831740: ldr             x16, [fp, #0x10]
    // 0x831744: SaveReg r16
    //     0x831744: str             x16, [SP, #-8]!
    // 0x831748: r0 = renderObjectIsVisible()
    //     0x831748: bl              #0x8315e0  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::renderObjectIsVisible
    // 0x83174c: add             SP, SP, #0x18
    // 0x831750: b               #0x831758
    // 0x831754: r0 = false
    //     0x831754: add             x0, NULL, #0x30  ; false
    // 0x831758: LeaveFrame
    //     0x831758: mov             SP, fp
    //     0x83175c: ldp             fp, lr, [SP], #0x10
    // 0x831760: ret
    //     0x831760: ret             
    // 0x831764: r0 = true
    //     0x831764: add             x0, NULL, #0x20  ; true
    // 0x831768: LeaveFrame
    //     0x831768: mov             SP, fp
    //     0x83176c: ldp             fp, lr, [SP], #0x10
    // 0x831770: ret
    //     0x831770: ret             
    // 0x831774: ldur            x0, [fp, #-0x20]
    // 0x831778: r0 = ConcurrentModificationError()
    //     0x831778: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x83177c: mov             x1, x0
    // 0x831780: ldur            x0, [fp, #-0x20]
    // 0x831784: StoreField: r1->field_b = r0
    //     0x831784: stur            w0, [x1, #0xb]
    // 0x831788: mov             x0, x1
    // 0x83178c: r0 = Throw()
    //     0x83178c: bl              #0xd67e38  ; ThrowStub
    // 0x831790: brk             #0
    // 0x831794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x831794: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x831798: b               #0x8315f8
  }
  _ childIsVisible(/* No info */) {
    // ** addr: 0x83179c, size: 0x9c
    // 0x83179c: EnterFrame
    //     0x83179c: stp             fp, lr, [SP, #-0x10]!
    //     0x8317a0: mov             fp, SP
    // 0x8317a4: AllocStack(0x8)
    //     0x8317a4: sub             SP, SP, #8
    // 0x8317a8: CheckStackOverflow
    //     0x8317a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8317ac: cmp             SP, x16
    //     0x8317b0: b.ls            #0x831830
    // 0x8317b4: r1 = 3
    //     0x8317b4: mov             x1, #3
    // 0x8317b8: r0 = AllocateContext()
    //     0x8317b8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8317bc: mov             x3, x0
    // 0x8317c0: ldr             x0, [fp, #0x20]
    // 0x8317c4: stur            x3, [fp, #-8]
    // 0x8317c8: StoreField: r3->field_f = r0
    //     0x8317c8: stur            w0, [x3, #0xf]
    // 0x8317cc: ldr             x0, [fp, #0x10]
    // 0x8317d0: StoreField: r3->field_13 = r0
    //     0x8317d0: stur            w0, [x3, #0x13]
    // 0x8317d4: r0 = false
    //     0x8317d4: add             x0, NULL, #0x30  ; false
    // 0x8317d8: StoreField: r3->field_17 = r0
    //     0x8317d8: stur            w0, [x3, #0x17]
    // 0x8317dc: mov             x2, x3
    // 0x8317e0: r1 = Function '<anonymous closure>':.
    //     0x8317e0: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2ef18] AnonymousClosure: (0x831838), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::childIsVisible (0x83179c)
    //     0x8317e4: ldr             x1, [x1, #0xf18]
    // 0x8317e8: r0 = AllocateClosure()
    //     0x8317e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8317ec: mov             x1, x0
    // 0x8317f0: ldr             x0, [fp, #0x18]
    // 0x8317f4: r2 = LoadClassIdInstr(r0)
    //     0x8317f4: ldur            x2, [x0, #-1]
    //     0x8317f8: ubfx            x2, x2, #0xc, #0x14
    // 0x8317fc: stp             x1, x0, [SP, #-0x10]!
    // 0x831800: mov             x0, x2
    // 0x831804: r0 = GDT[cid_x0 + 0xe3b8]()
    //     0x831804: mov             x17, #0xe3b8
    //     0x831808: add             lr, x0, x17
    //     0x83180c: ldr             lr, [x21, lr, lsl #3]
    //     0x831810: blr             lr
    // 0x831814: add             SP, SP, #0x10
    // 0x831818: ldur            x1, [fp, #-8]
    // 0x83181c: LoadField: r0 = r1->field_17
    //     0x83181c: ldur            w0, [x1, #0x17]
    // 0x831820: DecompressPointer r0
    //     0x831820: add             x0, x0, HEAP, lsl #32
    // 0x831824: LeaveFrame
    //     0x831824: mov             SP, fp
    //     0x831828: ldp             fp, lr, [SP], #0x10
    // 0x83182c: ret
    //     0x83182c: ret             
    // 0x831830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x831830: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x831834: b               #0x8317b4
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x831838, size: 0x80
    // 0x831838: EnterFrame
    //     0x831838: stp             fp, lr, [SP, #-0x10]!
    //     0x83183c: mov             fp, SP
    // 0x831840: AllocStack(0x8)
    //     0x831840: sub             SP, SP, #8
    // 0x831844: SetupParameters()
    //     0x831844: ldr             x0, [fp, #0x18]
    //     0x831848: ldur            w1, [x0, #0x17]
    //     0x83184c: add             x1, x1, HEAP, lsl #32
    //     0x831850: stur            x1, [fp, #-8]
    // 0x831854: CheckStackOverflow
    //     0x831854: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x831858: cmp             SP, x16
    //     0x83185c: b.ls            #0x8318b0
    // 0x831860: LoadField: r0 = r1->field_13
    //     0x831860: ldur            w0, [x1, #0x13]
    // 0x831864: DecompressPointer r0
    //     0x831864: add             x0, x0, HEAP, lsl #32
    // 0x831868: ldr             x2, [fp, #0x10]
    // 0x83186c: cmp             w0, w2
    // 0x831870: b.ne            #0x831880
    // 0x831874: r0 = true
    //     0x831874: add             x0, NULL, #0x20  ; true
    // 0x831878: StoreField: r1->field_17 = r0
    //     0x831878: stur            w0, [x1, #0x17]
    // 0x83187c: b               #0x8318a0
    // 0x831880: LoadField: r3 = r1->field_f
    //     0x831880: ldur            w3, [x1, #0xf]
    // 0x831884: DecompressPointer r3
    //     0x831884: add             x3, x3, HEAP, lsl #32
    // 0x831888: stp             x2, x3, [SP, #-0x10]!
    // 0x83188c: SaveReg r0
    //     0x83188c: str             x0, [SP, #-8]!
    // 0x831890: r0 = childIsVisible()
    //     0x831890: bl              #0x83179c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::childIsVisible
    // 0x831894: add             SP, SP, #0x18
    // 0x831898: ldur            x1, [fp, #-8]
    // 0x83189c: StoreField: r1->field_17 = r0
    //     0x83189c: stur            w0, [x1, #0x17]
    // 0x8318a0: r0 = Null
    //     0x8318a0: mov             x0, NULL
    // 0x8318a4: LeaveFrame
    //     0x8318a4: mov             SP, fp
    //     0x8318a8: ldp             fp, lr, [SP], #0x10
    // 0x8318ac: ret
    //     0x8318ac: ret             
    // 0x8318b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8318b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8318b4: b               #0x831860
  }
  _ findParentRenderViewport(/* No info */) {
    // ** addr: 0x8318b8, size: 0x140
    // 0x8318b8: EnterFrame
    //     0x8318b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8318bc: mov             fp, SP
    // 0x8318c0: AllocStack(0x8)
    //     0x8318c0: sub             SP, SP, #8
    // 0x8318c4: CheckStackOverflow
    //     0x8318c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8318c8: cmp             SP, x16
    //     0x8318cc: b.ls            #0x8319e8
    // 0x8318d0: ldr             x0, [fp, #0x10]
    // 0x8318d4: LoadField: r3 = r0->field_13
    //     0x8318d4: ldur            w3, [x0, #0x13]
    // 0x8318d8: DecompressPointer r3
    //     0x8318d8: add             x3, x3, HEAP, lsl #32
    // 0x8318dc: mov             x0, x3
    // 0x8318e0: stur            x3, [fp, #-8]
    // 0x8318e4: r2 = Null
    //     0x8318e4: mov             x2, NULL
    // 0x8318e8: r1 = Null
    //     0x8318e8: mov             x1, NULL
    // 0x8318ec: r4 = LoadClassIdInstr(r0)
    //     0x8318ec: ldur            x4, [x0, #-1]
    //     0x8318f0: ubfx            x4, x4, #0xc, #0x14
    // 0x8318f4: sub             x4, x4, #0x961
    // 0x8318f8: cmp             x4, #0xbe
    // 0x8318fc: b.ls            #0x831914
    // 0x831900: r8 = RenderObject?
    //     0x831900: add             x8, PP, #0xb, lsl #12  ; [pp+0xb028] Type: RenderObject?
    //     0x831904: ldr             x8, [x8, #0x28]
    // 0x831908: r3 = Null
    //     0x831908: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ef78] Null
    //     0x83190c: ldr             x3, [x3, #0xf78]
    // 0x831910: r0 = DefaultNullableTypeTest()
    //     0x831910: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x831914: ldur            x0, [fp, #-8]
    // 0x831918: CheckStackOverflow
    //     0x831918: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83191c: cmp             SP, x16
    //     0x831920: b.ls            #0x8319f0
    // 0x831924: cmp             w0, NULL
    // 0x831928: b.eq            #0x8319d8
    // 0x83192c: r1 = LoadClassIdInstr(r0)
    //     0x83192c: ldur            x1, [x0, #-1]
    //     0x831930: ubfx            x1, x1, #0xc, #0x14
    // 0x831934: lsl             x1, x1, #1
    // 0x831938: r17 = 5148
    //     0x831938: mov             x17, #0x141c
    // 0x83193c: cmp             w1, w17
    // 0x831940: b.ne            #0x831954
    // 0x831944: r0 = Null
    //     0x831944: mov             x0, NULL
    // 0x831948: LeaveFrame
    //     0x831948: mov             SP, fp
    //     0x83194c: ldp             fp, lr, [SP], #0x10
    // 0x831950: ret
    //     0x831950: ret             
    // 0x831954: r2 = LoadInt32Instr(r1)
    //     0x831954: sbfx            x2, x1, #1, #0x1f
    // 0x831958: cmp             x2, #0x974
    // 0x83195c: b.lt            #0x831974
    // 0x831960: cmp             x2, #0x975
    // 0x831964: b.gt            #0x831974
    // 0x831968: LeaveFrame
    //     0x831968: mov             SP, fp
    //     0x83196c: ldp             fp, lr, [SP], #0x10
    // 0x831970: ret
    //     0x831970: ret             
    // 0x831974: r1 = LoadClassIdInstr(r0)
    //     0x831974: ldur            x1, [x0, #-1]
    //     0x831978: ubfx            x1, x1, #0xc, #0x14
    // 0x83197c: SaveReg r0
    //     0x83197c: str             x0, [SP, #-8]!
    // 0x831980: mov             x0, x1
    // 0x831984: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x831984: mov             x17, #0xa2f1
    //     0x831988: add             lr, x0, x17
    //     0x83198c: ldr             lr, [x21, lr, lsl #3]
    //     0x831990: blr             lr
    // 0x831994: add             SP, SP, #8
    // 0x831998: mov             x3, x0
    // 0x83199c: r2 = Null
    //     0x83199c: mov             x2, NULL
    // 0x8319a0: r1 = Null
    //     0x8319a0: mov             x1, NULL
    // 0x8319a4: stur            x3, [fp, #-8]
    // 0x8319a8: r4 = LoadClassIdInstr(r0)
    //     0x8319a8: ldur            x4, [x0, #-1]
    //     0x8319ac: ubfx            x4, x4, #0xc, #0x14
    // 0x8319b0: sub             x4, x4, #0x961
    // 0x8319b4: cmp             x4, #0xbe
    // 0x8319b8: b.ls            #0x8319d0
    // 0x8319bc: r8 = RenderObject?
    //     0x8319bc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb028] Type: RenderObject?
    //     0x8319c0: ldr             x8, [x8, #0x28]
    // 0x8319c4: r3 = Null
    //     0x8319c4: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ef88] Null
    //     0x8319c8: ldr             x3, [x3, #0xf88]
    // 0x8319cc: r0 = DefaultNullableTypeTest()
    //     0x8319cc: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x8319d0: ldur            x0, [fp, #-8]
    // 0x8319d4: b               #0x831918
    // 0x8319d8: r0 = Null
    //     0x8319d8: mov             x0, NULL
    // 0x8319dc: LeaveFrame
    //     0x8319dc: mov             SP, fp
    //     0x8319e0: ldp             fp, lr, [SP], #0x10
    // 0x8319e4: ret
    //     0x8319e4: ret             
    // 0x8319e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8319e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8319ec: b               #0x8318d0
    // 0x8319f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8319f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8319f4: b               #0x831924
  }
  _ _ExtendedNestedScrollCoordinator(/* No info */) {
    // ** addr: 0x9d6498, size: 0x100
    // 0x9d6498: EnterFrame
    //     0x9d6498: stp             fp, lr, [SP, #-0x10]!
    //     0x9d649c: mov             fp, SP
    // 0x9d64a0: AllocStack(0x8)
    //     0x9d64a0: sub             SP, SP, #8
    // 0x9d64a4: r1 = true
    //     0x9d64a4: add             x1, NULL, #0x20  ; true
    // 0x9d64a8: r0 = Instance_Axis
    //     0x9d64a8: add             x0, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x9d64ac: ldr             x0, [x0, #0xf00]
    // 0x9d64b0: CheckStackOverflow
    //     0x9d64b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d64b4: cmp             SP, x16
    //     0x9d64b8: b.ls            #0x9d6590
    // 0x9d64bc: ldr             x2, [fp, #0x20]
    // 0x9d64c0: StoreField: r2->field_2b = r1
    //     0x9d64c0: stur            w1, [x2, #0x2b]
    // 0x9d64c4: StoreField: r2->field_2f = r0
    //     0x9d64c4: stur            w0, [x2, #0x2f]
    // 0x9d64c8: ldr             x16, [fp, #0x18]
    // 0x9d64cc: stp             x16, x2, [SP, #-0x10]!
    // 0x9d64d0: ldr             x16, [fp, #0x10]
    // 0x9d64d4: SaveReg r16
    //     0x9d64d4: str             x16, [SP, #-8]!
    // 0x9d64d8: r0 = _NestedScrollCoordinator()
    //     0x9d64d8: bl              #0x9d65a4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_NestedScrollCoordinator
    // 0x9d64dc: add             SP, SP, #0x18
    // 0x9d64e0: r0 = _ExtendedNestedScrollController()
    //     0x9d64e0: bl              #0x9d6598  ; Allocate_ExtendedNestedScrollControllerStub -> _ExtendedNestedScrollController (size=0x3c)
    // 0x9d64e4: mov             x1, x0
    // 0x9d64e8: ldr             x0, [fp, #0x20]
    // 0x9d64ec: stur            x1, [fp, #-8]
    // 0x9d64f0: StoreField: r1->field_37 = r0
    //     0x9d64f0: stur            w0, [x1, #0x37]
    // 0x9d64f4: r16 = "outer"
    //     0x9d64f4: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2eff8] "outer"
    //     0x9d64f8: ldr             x16, [x16, #0xff8]
    // 0x9d64fc: stp             x16, x1, [SP, #-0x10]!
    // 0x9d6500: r4 = const [0, 0x2, 0x2, 0x1, debugLabel, 0x1, null]
    //     0x9d6500: ldr             x4, [PP, #0x4490]  ; [pp+0x4490] List(7) [0, 0x2, 0x2, 0x1, "debugLabel", 0x1, Null]
    // 0x9d6504: r0 = ScrollController()
    //     0x9d6504: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9d6508: add             SP, SP, #0x10
    // 0x9d650c: ldur            x0, [fp, #-8]
    // 0x9d6510: ldr             x1, [fp, #0x20]
    // 0x9d6514: StoreField: r1->field_17 = r0
    //     0x9d6514: stur            w0, [x1, #0x17]
    //     0x9d6518: ldurb           w16, [x1, #-1]
    //     0x9d651c: ldurb           w17, [x0, #-1]
    //     0x9d6520: and             x16, x17, x16, lsr #2
    //     0x9d6524: tst             x16, HEAP, lsr #32
    //     0x9d6528: b.eq            #0x9d6530
    //     0x9d652c: bl              #0xd6826c
    // 0x9d6530: r0 = _ExtendedNestedScrollController()
    //     0x9d6530: bl              #0x9d6598  ; Allocate_ExtendedNestedScrollControllerStub -> _ExtendedNestedScrollController (size=0x3c)
    // 0x9d6534: mov             x1, x0
    // 0x9d6538: ldr             x0, [fp, #0x20]
    // 0x9d653c: stur            x1, [fp, #-8]
    // 0x9d6540: StoreField: r1->field_37 = r0
    //     0x9d6540: stur            w0, [x1, #0x37]
    // 0x9d6544: r16 = "inner"
    //     0x9d6544: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f000] "inner"
    //     0x9d6548: ldr             x16, [x16]
    // 0x9d654c: stp             x16, x1, [SP, #-0x10]!
    // 0x9d6550: r4 = const [0, 0x2, 0x2, 0x1, debugLabel, 0x1, null]
    //     0x9d6550: ldr             x4, [PP, #0x4490]  ; [pp+0x4490] List(7) [0, 0x2, 0x2, 0x1, "debugLabel", 0x1, Null]
    // 0x9d6554: r0 = ScrollController()
    //     0x9d6554: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9d6558: add             SP, SP, #0x10
    // 0x9d655c: ldur            x0, [fp, #-8]
    // 0x9d6560: ldr             x1, [fp, #0x20]
    // 0x9d6564: StoreField: r1->field_1b = r0
    //     0x9d6564: stur            w0, [x1, #0x1b]
    //     0x9d6568: ldurb           w16, [x1, #-1]
    //     0x9d656c: ldurb           w17, [x0, #-1]
    //     0x9d6570: and             x16, x17, x16, lsr #2
    //     0x9d6574: tst             x16, HEAP, lsr #32
    //     0x9d6578: b.eq            #0x9d6580
    //     0x9d657c: bl              #0xd6826c
    // 0x9d6580: r0 = Null
    //     0x9d6580: mov             x0, NULL
    // 0x9d6584: LeaveFrame
    //     0x9d6584: mov             SP, fp
    //     0x9d6588: ldp             fp, lr, [SP], #0x10
    // 0x9d658c: ret
    //     0x9d658c: ret             
    // 0x9d6590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d6590: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d6594: b               #0x9d64bc
  }
  _ updateCanDrag(/* No info */) {
    // ** addr: 0xc02650, size: 0x338
    // 0xc02650: EnterFrame
    //     0xc02650: stp             fp, lr, [SP, #-0x10]!
    //     0xc02654: mov             fp, SP
    // 0xc02658: AllocStack(0x18)
    //     0xc02658: sub             SP, SP, #0x18
    // 0xc0265c: SetupParameters(_ExtendedNestedScrollCoordinator this /* r3, fp-0x10 */, {dynamic position = Null /* r1, fp-0x8 */})
    //     0xc0265c: mov             x0, x4
    //     0xc02660: ldur            w1, [x0, #0x13]
    //     0xc02664: add             x1, x1, HEAP, lsl #32
    //     0xc02668: sub             x2, x1, #2
    //     0xc0266c: add             x3, fp, w2, sxtw #2
    //     0xc02670: ldr             x3, [x3, #0x10]
    //     0xc02674: stur            x3, [fp, #-0x10]
    //     0xc02678: ldur            w2, [x0, #0x1f]
    //     0xc0267c: add             x2, x2, HEAP, lsl #32
    //     0xc02680: add             x16, PP, #0x25, lsl #12  ; [pp+0x25f50] "position"
    //     0xc02684: ldr             x16, [x16, #0xf50]
    //     0xc02688: cmp             w2, w16
    //     0xc0268c: b.ne            #0xc026a8
    //     0xc02690: ldur            w2, [x0, #0x23]
    //     0xc02694: add             x2, x2, HEAP, lsl #32
    //     0xc02698: sub             w0, w1, w2
    //     0xc0269c: add             x1, fp, w0, sxtw #2
    //     0xc026a0: ldr             x1, [x1, #8]
    //     0xc026a4: b               #0xc026ac
    //     0xc026a8: mov             x1, NULL
    //     0xc026ac: stur            x1, [fp, #-8]
    // 0xc026b0: CheckStackOverflow
    //     0xc026b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc026b4: cmp             SP, x16
    //     0xc026b8: b.ls            #0xc02960
    // 0xc026bc: cmp             w1, NULL
    // 0xc026c0: b.eq            #0xc027ac
    // 0xc026c4: LoadField: r0 = r1->field_2f
    //     0xc026c4: ldur            w0, [x1, #0x2f]
    // 0xc026c8: DecompressPointer r0
    //     0xc026c8: add             x0, x0, HEAP, lsl #32
    // 0xc026cc: r2 = LoadClassIdInstr(r0)
    //     0xc026cc: ldur            x2, [x0, #-1]
    //     0xc026d0: ubfx            x2, x2, #0xc, #0x14
    // 0xc026d4: r16 = "inner"
    //     0xc026d4: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f000] "inner"
    //     0xc026d8: ldr             x16, [x16]
    // 0xc026dc: stp             x16, x0, [SP, #-0x10]!
    // 0xc026e0: mov             x0, x2
    // 0xc026e4: mov             lr, x0
    // 0xc026e8: ldr             lr, [x21, lr, lsl #3]
    // 0xc026ec: blr             lr
    // 0xc026f0: add             SP, SP, #0x10
    // 0xc026f4: tbnz            w0, #4, #0xc027ac
    // 0xc026f8: ldur            x0, [fp, #-8]
    // 0xc026fc: LoadField: r1 = r0->field_4b
    //     0xc026fc: ldur            w1, [x0, #0x4b]
    // 0xc02700: DecompressPointer r1
    //     0xc02700: add             x1, x1, HEAP, lsl #32
    // 0xc02704: tbnz            w1, #4, #0xc027a4
    // 0xc02708: d0 = 0.000000
    //     0xc02708: eor             v0.16b, v0.16b, v0.16b
    // 0xc0270c: LoadField: r1 = r0->field_37
    //     0xc0270c: ldur            w1, [x0, #0x37]
    // 0xc02710: DecompressPointer r1
    //     0xc02710: add             x1, x1, HEAP, lsl #32
    // 0xc02714: cmp             w1, NULL
    // 0xc02718: b.eq            #0xc02968
    // 0xc0271c: LoadField: r2 = r0->field_33
    //     0xc0271c: ldur            w2, [x0, #0x33]
    // 0xc02720: DecompressPointer r2
    //     0xc02720: add             x2, x2, HEAP, lsl #32
    // 0xc02724: cmp             w2, NULL
    // 0xc02728: b.eq            #0xc0296c
    // 0xc0272c: LoadField: d1 = r1->field_7
    //     0xc0272c: ldur            d1, [x1, #7]
    // 0xc02730: LoadField: d2 = r2->field_7
    //     0xc02730: ldur            d2, [x2, #7]
    // 0xc02734: fsub            d3, d1, d2
    // 0xc02738: fcmp            d0, d3
    // 0xc0273c: b.vs            #0xc0274c
    // 0xc02740: b.le            #0xc0274c
    // 0xc02744: d1 = 0.000000
    //     0xc02744: eor             v1.16b, v1.16b, v1.16b
    // 0xc02748: b               #0xc02788
    // 0xc0274c: fcmp            d0, d3
    // 0xc02750: b.vs            #0xc02760
    // 0xc02754: b.ge            #0xc02760
    // 0xc02758: mov             v1.16b, v3.16b
    // 0xc0275c: b               #0xc02788
    // 0xc02760: fcmp            d0, d0
    // 0xc02764: b.vs            #0xc02774
    // 0xc02768: b.ne            #0xc02774
    // 0xc0276c: fadd            d1, d0, d3
    // 0xc02770: b               #0xc02788
    // 0xc02774: fcmp            d3, d3
    // 0xc02778: b.vc            #0xc02784
    // 0xc0277c: mov             v1.16b, v3.16b
    // 0xc02780: b               #0xc02788
    // 0xc02784: d1 = 0.000000
    //     0xc02784: eor             v1.16b, v1.16b, v1.16b
    // 0xc02788: stur            d1, [fp, #-0x18]
    // 0xc0278c: SaveReg r0
    //     0xc0278c: str             x0, [SP, #-8]!
    // 0xc02790: SaveReg d1
    //     0xc02790: str             d1, [SP, #-8]!
    // 0xc02794: r0 = updateCanDrag()
    //     0xc02794: bl              #0xc02988  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::updateCanDrag
    // 0xc02798: add             SP, SP, #0x10
    // 0xc0279c: ldur            d0, [fp, #-0x18]
    // 0xc027a0: b               #0xc027b0
    // 0xc027a4: d0 = 0.000000
    //     0xc027a4: eor             v0.16b, v0.16b, v0.16b
    // 0xc027a8: b               #0xc027b0
    // 0xc027ac: d0 = 0.000000
    //     0xc027ac: eor             v0.16b, v0.16b, v0.16b
    // 0xc027b0: stur            d0, [fp, #-0x18]
    // 0xc027b4: ldur            x16, [fp, #-0x10]
    // 0xc027b8: SaveReg r16
    //     0xc027b8: str             x16, [SP, #-8]!
    // 0xc027bc: r0 = _outerPosition()
    //     0xc027bc: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc027c0: add             SP, SP, #8
    // 0xc027c4: cmp             w0, NULL
    // 0xc027c8: b.eq            #0xc02970
    // 0xc027cc: LoadField: r1 = r0->field_4b
    //     0xc027cc: ldur            w1, [x0, #0x4b]
    // 0xc027d0: DecompressPointer r1
    //     0xc027d0: add             x1, x1, HEAP, lsl #32
    // 0xc027d4: tbz             w1, #4, #0xc027e8
    // 0xc027d8: r0 = Null
    //     0xc027d8: mov             x0, NULL
    // 0xc027dc: LeaveFrame
    //     0xc027dc: mov             SP, fp
    //     0xc027e0: ldp             fp, lr, [SP], #0x10
    // 0xc027e4: ret
    //     0xc027e4: ret             
    // 0xc027e8: ldur            x16, [fp, #-0x10]
    // 0xc027ec: SaveReg r16
    //     0xc027ec: str             x16, [SP, #-8]!
    // 0xc027f0: r0 = _innerPositions()
    //     0xc027f0: bl              #0x831190  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::_innerPositions
    // 0xc027f4: add             SP, SP, #8
    // 0xc027f8: r1 = LoadClassIdInstr(r0)
    //     0xc027f8: ldur            x1, [x0, #-1]
    //     0xc027fc: ubfx            x1, x1, #0xc, #0x14
    // 0xc02800: SaveReg r0
    //     0xc02800: str             x0, [SP, #-8]!
    // 0xc02804: mov             x0, x1
    // 0xc02808: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc02808: mov             x17, #0xb940
    //     0xc0280c: add             lr, x0, x17
    //     0xc02810: ldr             lr, [x21, lr, lsl #3]
    //     0xc02814: blr             lr
    // 0xc02818: add             SP, SP, #8
    // 0xc0281c: mov             x1, x0
    // 0xc02820: stur            x1, [fp, #-8]
    // 0xc02824: ldur            d0, [fp, #-0x18]
    // 0xc02828: stur            d0, [fp, #-0x18]
    // 0xc0282c: CheckStackOverflow
    //     0xc0282c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc02830: cmp             SP, x16
    //     0xc02834: b.ls            #0xc02974
    // 0xc02838: r0 = LoadClassIdInstr(r1)
    //     0xc02838: ldur            x0, [x1, #-1]
    //     0xc0283c: ubfx            x0, x0, #0xc, #0x14
    // 0xc02840: SaveReg r1
    //     0xc02840: str             x1, [SP, #-8]!
    // 0xc02844: r0 = GDT[cid_x0 + 0x541]()
    //     0xc02844: add             lr, x0, #0x541
    //     0xc02848: ldr             lr, [x21, lr, lsl #3]
    //     0xc0284c: blr             lr
    // 0xc02850: add             SP, SP, #8
    // 0xc02854: tbnz            w0, #4, #0xc02920
    // 0xc02858: ldur            x1, [fp, #-8]
    // 0xc0285c: r0 = LoadClassIdInstr(r1)
    //     0xc0285c: ldur            x0, [x1, #-1]
    //     0xc02860: ubfx            x0, x0, #0xc, #0x14
    // 0xc02864: SaveReg r1
    //     0xc02864: str             x1, [SP, #-8]!
    // 0xc02868: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc02868: add             lr, x0, #0x5ca
    //     0xc0286c: ldr             lr, [x21, lr, lsl #3]
    //     0xc02870: blr             lr
    // 0xc02874: add             SP, SP, #8
    // 0xc02878: LoadField: r1 = r0->field_4b
    //     0xc02878: ldur            w1, [x0, #0x4b]
    // 0xc0287c: DecompressPointer r1
    //     0xc0287c: add             x1, x1, HEAP, lsl #32
    // 0xc02880: tbz             w1, #4, #0xc02894
    // 0xc02884: r0 = Null
    //     0xc02884: mov             x0, NULL
    // 0xc02888: LeaveFrame
    //     0xc02888: mov             SP, fp
    //     0xc0288c: ldp             fp, lr, [SP], #0x10
    // 0xc02890: ret
    //     0xc02890: ret             
    // 0xc02894: ldur            d0, [fp, #-0x18]
    // 0xc02898: LoadField: r1 = r0->field_37
    //     0xc02898: ldur            w1, [x0, #0x37]
    // 0xc0289c: DecompressPointer r1
    //     0xc0289c: add             x1, x1, HEAP, lsl #32
    // 0xc028a0: cmp             w1, NULL
    // 0xc028a4: b.eq            #0xc0297c
    // 0xc028a8: LoadField: r2 = r0->field_33
    //     0xc028a8: ldur            w2, [x0, #0x33]
    // 0xc028ac: DecompressPointer r2
    //     0xc028ac: add             x2, x2, HEAP, lsl #32
    // 0xc028b0: cmp             w2, NULL
    // 0xc028b4: b.eq            #0xc02980
    // 0xc028b8: LoadField: d1 = r1->field_7
    //     0xc028b8: ldur            d1, [x1, #7]
    // 0xc028bc: LoadField: d2 = r2->field_7
    //     0xc028bc: ldur            d2, [x2, #7]
    // 0xc028c0: fsub            d3, d1, d2
    // 0xc028c4: fcmp            d0, d3
    // 0xc028c8: b.vs            #0xc028d8
    // 0xc028cc: b.le            #0xc028d8
    // 0xc028d0: d1 = 0.000000
    //     0xc028d0: eor             v1.16b, v1.16b, v1.16b
    // 0xc028d4: b               #0xc02918
    // 0xc028d8: fcmp            d0, d3
    // 0xc028dc: b.vs            #0xc028f0
    // 0xc028e0: b.ge            #0xc028f0
    // 0xc028e4: mov             v0.16b, v3.16b
    // 0xc028e8: d1 = 0.000000
    //     0xc028e8: eor             v1.16b, v1.16b, v1.16b
    // 0xc028ec: b               #0xc02918
    // 0xc028f0: d1 = 0.000000
    //     0xc028f0: eor             v1.16b, v1.16b, v1.16b
    // 0xc028f4: fcmp            d0, d1
    // 0xc028f8: b.vs            #0xc0290c
    // 0xc028fc: b.ne            #0xc0290c
    // 0xc02900: fadd            d2, d0, d3
    // 0xc02904: mov             v0.16b, v2.16b
    // 0xc02908: b               #0xc02918
    // 0xc0290c: fcmp            d3, d3
    // 0xc02910: b.vc            #0xc02918
    // 0xc02914: mov             v0.16b, v3.16b
    // 0xc02918: ldur            x1, [fp, #-8]
    // 0xc0291c: b               #0xc02828
    // 0xc02920: ldur            d0, [fp, #-0x18]
    // 0xc02924: ldur            x16, [fp, #-0x10]
    // 0xc02928: SaveReg r16
    //     0xc02928: str             x16, [SP, #-8]!
    // 0xc0292c: r0 = _outerPosition()
    //     0xc0292c: bl              #0xa603e4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::_outerPosition
    // 0xc02930: add             SP, SP, #8
    // 0xc02934: cmp             w0, NULL
    // 0xc02938: b.eq            #0xc02984
    // 0xc0293c: SaveReg r0
    //     0xc0293c: str             x0, [SP, #-8]!
    // 0xc02940: ldur            d0, [fp, #-0x18]
    // 0xc02944: SaveReg d0
    //     0xc02944: str             d0, [SP, #-8]!
    // 0xc02948: r0 = updateCanDrag()
    //     0xc02948: bl              #0xc02988  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::updateCanDrag
    // 0xc0294c: add             SP, SP, #0x10
    // 0xc02950: r0 = Null
    //     0xc02950: mov             x0, NULL
    // 0xc02954: LeaveFrame
    //     0xc02954: mov             SP, fp
    //     0xc02958: ldp             fp, lr, [SP], #0x10
    // 0xc0295c: ret
    //     0xc0295c: ret             
    // 0xc02960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02960: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02964: b               #0xc026bc
    // 0xc02968: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc02968: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc0296c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc0296c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc02970: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc02970: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc02974: r0 = StackOverflowSharedWithFPURegs()
    //     0xc02974: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc02978: b               #0xc02838
    // 0xc0297c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc0297c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc02980: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc02980: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc02984: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc02984: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, _ExtendedNestedScrollPosition) {
    // ** addr: 0xc64048, size: 0x10
    // 0xc64048: ldr             x1, [SP]
    // 0xc6404c: LoadField: r0 = r1->field_77
    //     0xc6404c: ldur            w0, [x1, #0x77]
    // 0xc64050: DecompressPointer r0
    //     0xc64050: add             x0, x0, HEAP, lsl #32
    // 0xc64054: ret
    //     0xc64054: ret             
  }
}

// class id: 4844, size: 0x78, field offset: 0x70
class _NestedScrollPosition extends ScrollPosition
    implements ScrollActivityDelegate {

  _ setParent(/* No info */) {
    // ** addr: 0x7d2778, size: 0xac
    // 0x7d2778: EnterFrame
    //     0x7d2778: stp             fp, lr, [SP, #-0x10]!
    //     0x7d277c: mov             fp, SP
    // 0x7d2780: CheckStackOverflow
    //     0x7d2780: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7d2784: cmp             SP, x16
    //     0x7d2788: b.ls            #0x7d281c
    // 0x7d278c: ldr             x1, [fp, #0x18]
    // 0x7d2790: LoadField: r0 = r1->field_73
    //     0x7d2790: ldur            w0, [x1, #0x73]
    // 0x7d2794: DecompressPointer r0
    //     0x7d2794: add             x0, x0, HEAP, lsl #32
    // 0x7d2798: cmp             w0, NULL
    // 0x7d279c: b.eq            #0x7d27c4
    // 0x7d27a0: r2 = LoadClassIdInstr(r0)
    //     0x7d27a0: ldur            x2, [x0, #-1]
    //     0x7d27a4: ubfx            x2, x2, #0xc, #0x14
    // 0x7d27a8: stp             x1, x0, [SP, #-0x10]!
    // 0x7d27ac: mov             x0, x2
    // 0x7d27b0: r0 = GDT[cid_x0 + 0x6d1]()
    //     0x7d27b0: add             lr, x0, #0x6d1
    //     0x7d27b4: ldr             lr, [x21, lr, lsl #3]
    //     0x7d27b8: blr             lr
    // 0x7d27bc: add             SP, SP, #0x10
    // 0x7d27c0: ldr             x1, [fp, #0x18]
    // 0x7d27c4: ldr             x2, [fp, #0x10]
    // 0x7d27c8: mov             x0, x2
    // 0x7d27cc: StoreField: r1->field_73 = r0
    //     0x7d27cc: stur            w0, [x1, #0x73]
    //     0x7d27d0: ldurb           w16, [x1, #-1]
    //     0x7d27d4: ldurb           w17, [x0, #-1]
    //     0x7d27d8: and             x16, x17, x16, lsr #2
    //     0x7d27dc: tst             x16, HEAP, lsr #32
    //     0x7d27e0: b.eq            #0x7d27e8
    //     0x7d27e4: bl              #0xd6826c
    // 0x7d27e8: cmp             w2, NULL
    // 0x7d27ec: b.eq            #0x7d280c
    // 0x7d27f0: r0 = LoadClassIdInstr(r2)
    //     0x7d27f0: ldur            x0, [x2, #-1]
    //     0x7d27f4: ubfx            x0, x0, #0xc, #0x14
    // 0x7d27f8: stp             x1, x2, [SP, #-0x10]!
    // 0x7d27fc: r0 = GDT[cid_x0 + 0x6db]()
    //     0x7d27fc: add             lr, x0, #0x6db
    //     0x7d2800: ldr             lr, [x21, lr, lsl #3]
    //     0x7d2804: blr             lr
    // 0x7d2808: add             SP, SP, #0x10
    // 0x7d280c: r0 = Null
    //     0x7d280c: mov             x0, NULL
    // 0x7d2810: LeaveFrame
    //     0x7d2810: mov             SP, fp
    //     0x7d2814: ldp             fp, lr, [SP], #0x10
    // 0x7d2818: ret
    //     0x7d2818: ret             
    // 0x7d281c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7d281c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7d2820: b               #0x7d278c
  }
  _ createBallisticScrollActivity(/* No info */) {
    // ** addr: 0xbcfa28, size: 0x348
    // 0xbcfa28: EnterFrame
    //     0xbcfa28: stp             fp, lr, [SP, #-0x10]!
    //     0xbcfa2c: mov             fp, SP
    // 0xbcfa30: AllocStack(0x38)
    //     0xbcfa30: sub             SP, SP, #0x38
    // 0xbcfa34: SetupParameters(_NestedScrollPosition this /* r3, fp-0x8 */, dynamic _ /* r4, fp-0x18 */, dynamic _ /* r5 */, {dynamic metrics = Null /* r1, fp-0x10 */})
    //     0xbcfa34: mov             x0, x4
    //     0xbcfa38: ldur            w1, [x0, #0x13]
    //     0xbcfa3c: add             x1, x1, HEAP, lsl #32
    //     0xbcfa40: sub             x2, x1, #6
    //     0xbcfa44: add             x3, fp, w2, sxtw #2
    //     0xbcfa48: ldr             x3, [x3, #0x20]
    //     0xbcfa4c: stur            x3, [fp, #-8]
    //     0xbcfa50: add             x4, fp, w2, sxtw #2
    //     0xbcfa54: ldr             x4, [x4, #0x18]
    //     0xbcfa58: stur            x4, [fp, #-0x18]
    //     0xbcfa5c: add             x5, fp, w2, sxtw #2
    //     0xbcfa60: ldr             x5, [x5, #0x10]
    //     0xbcfa64: ldur            w2, [x0, #0x1f]
    //     0xbcfa68: add             x2, x2, HEAP, lsl #32
    //     0xbcfa6c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40da0] "metrics"
    //     0xbcfa70: ldr             x16, [x16, #0xda0]
    //     0xbcfa74: cmp             w2, w16
    //     0xbcfa78: b.ne            #0xbcfa94
    //     0xbcfa7c: ldur            w2, [x0, #0x23]
    //     0xbcfa80: add             x2, x2, HEAP, lsl #32
    //     0xbcfa84: sub             w0, w1, w2
    //     0xbcfa88: add             x1, fp, w0, sxtw #2
    //     0xbcfa8c: ldr             x1, [x1, #8]
    //     0xbcfa90: b               #0xbcfa98
    //     0xbcfa94: mov             x1, NULL
    //     0xbcfa98: stur            x1, [fp, #-0x10]
    // 0xbcfa9c: CheckStackOverflow
    //     0xbcfa9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbcfaa0: cmp             SP, x16
    //     0xbcfaa4: b.ls            #0xbcfd64
    // 0xbcfaa8: cmp             w4, NULL
    // 0xbcfaac: b.ne            #0xbcfad0
    // 0xbcfab0: r0 = IdleScrollActivity()
    //     0xbcfab0: bl              #0x81ce04  ; AllocateIdleScrollActivityStub -> IdleScrollActivity (size=0xc)
    // 0xbcfab4: mov             x1, x0
    // 0xbcfab8: ldur            x0, [fp, #-8]
    // 0xbcfabc: StoreField: r1->field_7 = r0
    //     0xbcfabc: stur            w0, [x1, #7]
    // 0xbcfac0: mov             x0, x1
    // 0xbcfac4: LeaveFrame
    //     0xbcfac4: mov             SP, fp
    //     0xbcfac8: ldp             fp, lr, [SP], #0x10
    // 0xbcfacc: ret
    //     0xbcfacc: ret             
    // 0xbcfad0: mov             x0, x3
    // 0xbcfad4: LoadField: r2 = r5->field_7
    //     0xbcfad4: ldur            x2, [x5, #7]
    // 0xbcfad8: cmp             x2, #1
    // 0xbcfadc: b.gt            #0xbcfcd0
    // 0xbcfae0: cmp             x2, #0
    // 0xbcfae4: b.gt            #0xbcfbfc
    // 0xbcfae8: cmp             w1, NULL
    // 0xbcfaec: b.eq            #0xbcfd6c
    // 0xbcfaf0: LoadField: d0 = r1->field_1b
    //     0xbcfaf0: ldur            d0, [x1, #0x1b]
    // 0xbcfaf4: LoadField: d1 = r1->field_23
    //     0xbcfaf4: ldur            d1, [x1, #0x23]
    // 0xbcfaf8: fcmp            d0, d1
    // 0xbcfafc: b.vs            #0xbcfb1c
    // 0xbcfb00: b.ne            #0xbcfb1c
    // 0xbcfb04: r0 = IdleScrollActivity()
    //     0xbcfb04: bl              #0x81ce04  ; AllocateIdleScrollActivityStub -> IdleScrollActivity (size=0xc)
    // 0xbcfb08: ldur            x2, [fp, #-8]
    // 0xbcfb0c: StoreField: r0->field_7 = r2
    //     0xbcfb0c: stur            w2, [x0, #7]
    // 0xbcfb10: LeaveFrame
    //     0xbcfb10: mov             SP, fp
    //     0xbcfb14: ldp             fp, lr, [SP], #0x10
    // 0xbcfb18: ret
    //     0xbcfb18: ret             
    // 0xbcfb1c: mov             x2, x0
    // 0xbcfb20: r0 = LoadClassIdInstr(r2)
    //     0xbcfb20: ldur            x0, [x2, #-1]
    //     0xbcfb24: ubfx            x0, x0, #0xc, #0x14
    // 0xbcfb28: SaveReg r2
    //     0xbcfb28: str             x2, [SP, #-8]!
    // 0xbcfb2c: r0 = GDT[cid_x0 + -0xff5]()
    //     0xbcfb2c: sub             lr, x0, #0xff5
    //     0xbcfb30: ldr             lr, [x21, lr, lsl #3]
    //     0xbcfb34: blr             lr
    // 0xbcfb38: add             SP, SP, #8
    // 0xbcfb3c: mov             x2, x0
    // 0xbcfb40: ldur            x1, [fp, #-8]
    // 0xbcfb44: stur            x2, [fp, #-0x28]
    // 0xbcfb48: LoadField: r3 = r1->field_27
    //     0xbcfb48: ldur            w3, [x1, #0x27]
    // 0xbcfb4c: DecompressPointer r3
    //     0xbcfb4c: add             x3, x3, HEAP, lsl #32
    // 0xbcfb50: stur            x3, [fp, #-0x20]
    // 0xbcfb54: LoadField: r0 = r1->field_6b
    //     0xbcfb54: ldur            w0, [x1, #0x6b]
    // 0xbcfb58: DecompressPointer r0
    //     0xbcfb58: add             x0, x0, HEAP, lsl #32
    // 0xbcfb5c: cmp             w0, NULL
    // 0xbcfb60: b.ne            #0xbcfb6c
    // 0xbcfb64: r0 = Null
    //     0xbcfb64: mov             x0, NULL
    // 0xbcfb68: b               #0xbcfb8c
    // 0xbcfb6c: r4 = LoadClassIdInstr(r0)
    //     0xbcfb6c: ldur            x4, [x0, #-1]
    //     0xbcfb70: ubfx            x4, x4, #0xc, #0x14
    // 0xbcfb74: SaveReg r0
    //     0xbcfb74: str             x0, [SP, #-8]!
    // 0xbcfb78: mov             x0, x4
    // 0xbcfb7c: r0 = GDT[cid_x0 + -0xff4]()
    //     0xbcfb7c: sub             lr, x0, #0xff4
    //     0xbcfb80: ldr             lr, [x21, lr, lsl #3]
    //     0xbcfb84: blr             lr
    // 0xbcfb88: add             SP, SP, #8
    // 0xbcfb8c: cmp             w0, NULL
    // 0xbcfb90: b.ne            #0xbcfb9c
    // 0xbcfb94: r2 = true
    //     0xbcfb94: add             x2, NULL, #0x20  ; true
    // 0xbcfb98: b               #0xbcfba0
    // 0xbcfb9c: mov             x2, x0
    // 0xbcfba0: ldur            x1, [fp, #-0x10]
    // 0xbcfba4: ldur            x0, [fp, #-0x28]
    // 0xbcfba8: stur            x2, [fp, #-0x30]
    // 0xbcfbac: r0 = _NestedOuterBallisticScrollActivity()
    //     0xbcfbac: bl              #0xbd008c  ; Allocate_NestedOuterBallisticScrollActivityStub -> _NestedOuterBallisticScrollActivity (size=0x1c)
    // 0xbcfbb0: mov             x1, x0
    // 0xbcfbb4: ldur            x0, [fp, #-0x28]
    // 0xbcfbb8: stur            x1, [fp, #-0x38]
    // 0xbcfbbc: StoreField: r1->field_13 = r0
    //     0xbcfbbc: stur            w0, [x1, #0x13]
    // 0xbcfbc0: ldur            x0, [fp, #-0x10]
    // 0xbcfbc4: StoreField: r1->field_17 = r0
    //     0xbcfbc4: stur            w0, [x1, #0x17]
    // 0xbcfbc8: ldur            x16, [fp, #-8]
    // 0xbcfbcc: stp             x16, x1, [SP, #-0x10]!
    // 0xbcfbd0: ldur            x16, [fp, #-0x18]
    // 0xbcfbd4: ldur            lr, [fp, #-0x20]
    // 0xbcfbd8: stp             lr, x16, [SP, #-0x10]!
    // 0xbcfbdc: ldur            x16, [fp, #-0x30]
    // 0xbcfbe0: SaveReg r16
    //     0xbcfbe0: str             x16, [SP, #-8]!
    // 0xbcfbe4: r0 = BallisticScrollActivity()
    //     0xbcfbe4: bl              #0xbcfd88  ; [package:flutter/src/widgets/scroll_activity.dart] BallisticScrollActivity::BallisticScrollActivity
    // 0xbcfbe8: add             SP, SP, #0x28
    // 0xbcfbec: ldur            x0, [fp, #-0x38]
    // 0xbcfbf0: LeaveFrame
    //     0xbcfbf0: mov             SP, fp
    //     0xbcfbf4: ldp             fp, lr, [SP], #0x10
    // 0xbcfbf8: ret
    //     0xbcfbf8: ret             
    // 0xbcfbfc: mov             x1, x0
    // 0xbcfc00: r0 = LoadClassIdInstr(r1)
    //     0xbcfc00: ldur            x0, [x1, #-1]
    //     0xbcfc04: ubfx            x0, x0, #0xc, #0x14
    // 0xbcfc08: SaveReg r1
    //     0xbcfc08: str             x1, [SP, #-8]!
    // 0xbcfc0c: r0 = GDT[cid_x0 + -0xff5]()
    //     0xbcfc0c: sub             lr, x0, #0xff5
    //     0xbcfc10: ldr             lr, [x21, lr, lsl #3]
    //     0xbcfc14: blr             lr
    // 0xbcfc18: add             SP, SP, #8
    // 0xbcfc1c: mov             x2, x0
    // 0xbcfc20: ldur            x1, [fp, #-8]
    // 0xbcfc24: stur            x2, [fp, #-0x20]
    // 0xbcfc28: LoadField: r3 = r1->field_27
    //     0xbcfc28: ldur            w3, [x1, #0x27]
    // 0xbcfc2c: DecompressPointer r3
    //     0xbcfc2c: add             x3, x3, HEAP, lsl #32
    // 0xbcfc30: stur            x3, [fp, #-0x10]
    // 0xbcfc34: LoadField: r0 = r1->field_6b
    //     0xbcfc34: ldur            w0, [x1, #0x6b]
    // 0xbcfc38: DecompressPointer r0
    //     0xbcfc38: add             x0, x0, HEAP, lsl #32
    // 0xbcfc3c: cmp             w0, NULL
    // 0xbcfc40: b.ne            #0xbcfc4c
    // 0xbcfc44: r0 = Null
    //     0xbcfc44: mov             x0, NULL
    // 0xbcfc48: b               #0xbcfc6c
    // 0xbcfc4c: r4 = LoadClassIdInstr(r0)
    //     0xbcfc4c: ldur            x4, [x0, #-1]
    //     0xbcfc50: ubfx            x4, x4, #0xc, #0x14
    // 0xbcfc54: SaveReg r0
    //     0xbcfc54: str             x0, [SP, #-8]!
    // 0xbcfc58: mov             x0, x4
    // 0xbcfc5c: r0 = GDT[cid_x0 + -0xff4]()
    //     0xbcfc5c: sub             lr, x0, #0xff4
    //     0xbcfc60: ldr             lr, [x21, lr, lsl #3]
    //     0xbcfc64: blr             lr
    // 0xbcfc68: add             SP, SP, #8
    // 0xbcfc6c: cmp             w0, NULL
    // 0xbcfc70: b.ne            #0xbcfc7c
    // 0xbcfc74: r1 = true
    //     0xbcfc74: add             x1, NULL, #0x20  ; true
    // 0xbcfc78: b               #0xbcfc80
    // 0xbcfc7c: mov             x1, x0
    // 0xbcfc80: ldur            x0, [fp, #-0x20]
    // 0xbcfc84: stur            x1, [fp, #-0x28]
    // 0xbcfc88: r0 = _ExtendedNestedInnerBallisticScrollActivity()
    //     0xbcfc88: bl              #0xbcfd7c  ; Allocate_ExtendedNestedInnerBallisticScrollActivityStub -> _ExtendedNestedInnerBallisticScrollActivity (size=0x18)
    // 0xbcfc8c: mov             x1, x0
    // 0xbcfc90: ldur            x0, [fp, #-0x20]
    // 0xbcfc94: stur            x1, [fp, #-0x30]
    // 0xbcfc98: StoreField: r1->field_13 = r0
    //     0xbcfc98: stur            w0, [x1, #0x13]
    // 0xbcfc9c: ldur            x16, [fp, #-8]
    // 0xbcfca0: stp             x16, x1, [SP, #-0x10]!
    // 0xbcfca4: ldur            x16, [fp, #-0x18]
    // 0xbcfca8: ldur            lr, [fp, #-0x10]
    // 0xbcfcac: stp             lr, x16, [SP, #-0x10]!
    // 0xbcfcb0: ldur            x16, [fp, #-0x28]
    // 0xbcfcb4: SaveReg r16
    //     0xbcfcb4: str             x16, [SP, #-8]!
    // 0xbcfcb8: r0 = BallisticScrollActivity()
    //     0xbcfcb8: bl              #0xbcfd88  ; [package:flutter/src/widgets/scroll_activity.dart] BallisticScrollActivity::BallisticScrollActivity
    // 0xbcfcbc: add             SP, SP, #0x28
    // 0xbcfcc0: ldur            x0, [fp, #-0x30]
    // 0xbcfcc4: LeaveFrame
    //     0xbcfcc4: mov             SP, fp
    //     0xbcfcc8: ldp             fp, lr, [SP], #0x10
    // 0xbcfccc: ret
    //     0xbcfccc: ret             
    // 0xbcfcd0: mov             x1, x0
    // 0xbcfcd4: LoadField: r2 = r1->field_27
    //     0xbcfcd4: ldur            w2, [x1, #0x27]
    // 0xbcfcd8: DecompressPointer r2
    //     0xbcfcd8: add             x2, x2, HEAP, lsl #32
    // 0xbcfcdc: stur            x2, [fp, #-0x10]
    // 0xbcfce0: LoadField: r0 = r1->field_6b
    //     0xbcfce0: ldur            w0, [x1, #0x6b]
    // 0xbcfce4: DecompressPointer r0
    //     0xbcfce4: add             x0, x0, HEAP, lsl #32
    // 0xbcfce8: cmp             w0, NULL
    // 0xbcfcec: b.ne            #0xbcfcf8
    // 0xbcfcf0: r0 = Null
    //     0xbcfcf0: mov             x0, NULL
    // 0xbcfcf4: b               #0xbcfd18
    // 0xbcfcf8: r3 = LoadClassIdInstr(r0)
    //     0xbcfcf8: ldur            x3, [x0, #-1]
    //     0xbcfcfc: ubfx            x3, x3, #0xc, #0x14
    // 0xbcfd00: SaveReg r0
    //     0xbcfd00: str             x0, [SP, #-8]!
    // 0xbcfd04: mov             x0, x3
    // 0xbcfd08: r0 = GDT[cid_x0 + -0xff4]()
    //     0xbcfd08: sub             lr, x0, #0xff4
    //     0xbcfd0c: ldr             lr, [x21, lr, lsl #3]
    //     0xbcfd10: blr             lr
    // 0xbcfd14: add             SP, SP, #8
    // 0xbcfd18: cmp             w0, NULL
    // 0xbcfd1c: b.ne            #0xbcfd24
    // 0xbcfd20: r0 = true
    //     0xbcfd20: add             x0, NULL, #0x20  ; true
    // 0xbcfd24: stur            x0, [fp, #-0x20]
    // 0xbcfd28: r0 = BallisticScrollActivity()
    //     0xbcfd28: bl              #0xbcfd70  ; AllocateBallisticScrollActivityStub -> BallisticScrollActivity (size=0x14)
    // 0xbcfd2c: stur            x0, [fp, #-0x28]
    // 0xbcfd30: ldur            x16, [fp, #-8]
    // 0xbcfd34: stp             x16, x0, [SP, #-0x10]!
    // 0xbcfd38: ldur            x16, [fp, #-0x18]
    // 0xbcfd3c: ldur            lr, [fp, #-0x10]
    // 0xbcfd40: stp             lr, x16, [SP, #-0x10]!
    // 0xbcfd44: ldur            x16, [fp, #-0x20]
    // 0xbcfd48: SaveReg r16
    //     0xbcfd48: str             x16, [SP, #-8]!
    // 0xbcfd4c: r0 = BallisticScrollActivity()
    //     0xbcfd4c: bl              #0xbcfd88  ; [package:flutter/src/widgets/scroll_activity.dart] BallisticScrollActivity::BallisticScrollActivity
    // 0xbcfd50: add             SP, SP, #0x28
    // 0xbcfd54: ldur            x0, [fp, #-0x28]
    // 0xbcfd58: LeaveFrame
    //     0xbcfd58: mov             SP, fp
    //     0xbcfd5c: ldp             fp, lr, [SP], #0x10
    // 0xbcfd60: ret
    //     0xbcfd60: ret             
    // 0xbcfd64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcfd64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcfd68: b               #0xbcfaa8
    // 0xbcfd6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcfd6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _NestedScrollPosition(/* No info */) {
    // ** addr: 0xbebd84, size: 0xbc
    // 0xbebd84: EnterFrame
    //     0xbebd84: stp             fp, lr, [SP, #-0x10]!
    //     0xbebd88: mov             fp, SP
    // 0xbebd8c: CheckStackOverflow
    //     0xbebd8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbebd90: cmp             SP, x16
    //     0xbebd94: b.ls            #0xbebe38
    // 0xbebd98: ldr             x0, [fp, #0x28]
    // 0xbebd9c: ldr             x1, [fp, #0x38]
    // 0xbebda0: StoreField: r1->field_6f = r0
    //     0xbebda0: stur            w0, [x1, #0x6f]
    //     0xbebda4: ldurb           w16, [x1, #-1]
    //     0xbebda8: ldurb           w17, [x0, #-1]
    //     0xbebdac: and             x16, x17, x16, lsr #2
    //     0xbebdb0: tst             x16, HEAP, lsr #32
    //     0xbebdb4: b.eq            #0xbebdbc
    //     0xbebdb8: bl              #0xd6826c
    // 0xbebdbc: ldr             x16, [fp, #0x30]
    // 0xbebdc0: stp             x16, x1, [SP, #-0x10]!
    // 0xbebdc4: ldr             x16, [fp, #0x20]
    // 0xbebdc8: ldr             lr, [fp, #0x18]
    // 0xbebdcc: stp             lr, x16, [SP, #-0x10]!
    // 0xbebdd0: ldr             x16, [fp, #0x10]
    // 0xbebdd4: SaveReg r16
    //     0xbebdd4: str             x16, [SP, #-8]!
    // 0xbebdd8: r0 = ScrollPosition()
    //     0xbebdd8: bl              #0xbeb9e8  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::ScrollPosition
    // 0xbebddc: add             SP, SP, #0x28
    // 0xbebde0: ldr             x0, [fp, #0x38]
    // 0xbebde4: LoadField: r1 = r0->field_43
    //     0xbebde4: ldur            w1, [x0, #0x43]
    // 0xbebde8: DecompressPointer r1
    //     0xbebde8: add             x1, x1, HEAP, lsl #32
    // 0xbebdec: cmp             w1, NULL
    // 0xbebdf0: b.ne            #0xbebdfc
    // 0xbebdf4: r1 = 0.000000
    //     0xbebdf4: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xbebdf8: StoreField: r0->field_43 = r1
    //     0xbebdf8: stur            w1, [x0, #0x43]
    // 0xbebdfc: LoadField: r1 = r0->field_6b
    //     0xbebdfc: ldur            w1, [x0, #0x6b]
    // 0xbebe00: DecompressPointer r1
    //     0xbebe00: add             x1, x1, HEAP, lsl #32
    // 0xbebe04: cmp             w1, NULL
    // 0xbebe08: b.ne            #0xbebe18
    // 0xbebe0c: SaveReg r0
    //     0xbebe0c: str             x0, [SP, #-8]!
    // 0xbebe10: r0 = goIdle()
    //     0xbebe10: bl              #0xc1163c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::goIdle
    // 0xbebe14: add             SP, SP, #8
    // 0xbebe18: ldr             x16, [fp, #0x38]
    // 0xbebe1c: SaveReg r16
    //     0xbebe1c: str             x16, [SP, #-8]!
    // 0xbebe20: r0 = saveScrollOffset()
    //     0xbebe20: bl              #0xc00098  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::saveScrollOffset
    // 0xbebe24: add             SP, SP, #8
    // 0xbebe28: r0 = Null
    //     0xbebe28: mov             x0, NULL
    // 0xbebe2c: LeaveFrame
    //     0xbebe2c: mov             SP, fp
    //     0xbebe30: ldp             fp, lr, [SP], #0x10
    // 0xbebe34: ret
    //     0xbebe34: ret             
    // 0xbebe38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbebe38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbebe3c: b               #0xbebd98
  }
  _ updateCanDrag(/* No info */) {
    // ** addr: 0xc02988, size: 0xb8
    // 0xc02988: EnterFrame
    //     0xc02988: stp             fp, lr, [SP, #-0x10]!
    //     0xc0298c: mov             fp, SP
    // 0xc02990: CheckStackOverflow
    //     0xc02990: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc02994: cmp             SP, x16
    //     0xc02998: b.ls            #0xc02a2c
    // 0xc0299c: ldr             x0, [fp, #0x18]
    // 0xc029a0: LoadField: r1 = r0->field_27
    //     0xc029a0: ldur            w1, [x0, #0x27]
    // 0xc029a4: DecompressPointer r1
    //     0xc029a4: add             x1, x1, HEAP, lsl #32
    // 0xc029a8: LoadField: r2 = r0->field_47
    //     0xc029a8: ldur            w2, [x0, #0x47]
    // 0xc029ac: DecompressPointer r2
    //     0xc029ac: add             x2, x2, HEAP, lsl #32
    // 0xc029b0: cmp             w2, NULL
    // 0xc029b4: b.eq            #0xc02a34
    // 0xc029b8: LoadField: r3 = r0->field_37
    //     0xc029b8: ldur            w3, [x0, #0x37]
    // 0xc029bc: DecompressPointer r3
    //     0xc029bc: add             x3, x3, HEAP, lsl #32
    // 0xc029c0: cmp             w3, NULL
    // 0xc029c4: b.eq            #0xc02a38
    // 0xc029c8: LoadField: d0 = r2->field_7
    //     0xc029c8: ldur            d0, [x2, #7]
    // 0xc029cc: LoadField: d1 = r3->field_7
    //     0xc029cc: ldur            d1, [x3, #7]
    // 0xc029d0: fsub            d2, d0, d1
    // 0xc029d4: ldr             d0, [fp, #0x10]
    // 0xc029d8: fcmp            d0, d2
    // 0xc029dc: b.vs            #0xc029ec
    // 0xc029e0: b.le            #0xc029ec
    // 0xc029e4: r0 = true
    //     0xc029e4: add             x0, NULL, #0x20  ; true
    // 0xc029e8: b               #0xc02a10
    // 0xc029ec: LoadField: r2 = r0->field_33
    //     0xc029ec: ldur            w2, [x0, #0x33]
    // 0xc029f0: DecompressPointer r2
    //     0xc029f0: add             x2, x2, HEAP, lsl #32
    // 0xc029f4: cmp             w2, NULL
    // 0xc029f8: b.eq            #0xc02a3c
    // 0xc029fc: LoadField: d0 = r2->field_7
    //     0xc029fc: ldur            d0, [x2, #7]
    // 0xc02a00: fcmp            d0, d1
    // 0xc02a04: r16 = true
    //     0xc02a04: add             x16, NULL, #0x20  ; true
    // 0xc02a08: r17 = false
    //     0xc02a08: add             x17, NULL, #0x30  ; false
    // 0xc02a0c: csel            x0, x16, x17, ne
    // 0xc02a10: stp             x0, x1, [SP, #-0x10]!
    // 0xc02a14: r0 = setCanDrag()
    //     0xc02a14: bl              #0xc016d4  ; [package:flutter/src/widgets/scrollable.dart] ScrollableState::setCanDrag
    // 0xc02a18: add             SP, SP, #0x10
    // 0xc02a1c: r0 = Null
    //     0xc02a1c: mov             x0, NULL
    // 0xc02a20: LeaveFrame
    //     0xc02a20: mov             SP, fp
    //     0xc02a24: ldp             fp, lr, [SP], #0x10
    // 0xc02a28: ret
    //     0xc02a28: ret             
    // 0xc02a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02a2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02a30: b               #0xc0299c
    // 0xc02a34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc02a34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc02a38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc02a38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc02a3c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc02a3c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ applyNewDimensions(/* No info */) {
    // ** addr: 0xc02a40, size: 0x84
    // 0xc02a40: EnterFrame
    //     0xc02a40: stp             fp, lr, [SP, #-0x10]!
    //     0xc02a44: mov             fp, SP
    // 0xc02a48: CheckStackOverflow
    //     0xc02a48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc02a4c: cmp             SP, x16
    //     0xc02a50: b.ls            #0xc02abc
    // 0xc02a54: ldr             x16, [fp, #0x10]
    // 0xc02a58: SaveReg r16
    //     0xc02a58: str             x16, [SP, #-8]!
    // 0xc02a5c: r0 = applyNewDimensions()
    //     0xc02a5c: bl              #0xc02138  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyNewDimensions
    // 0xc02a60: add             SP, SP, #8
    // 0xc02a64: ldr             x0, [fp, #0x10]
    // 0xc02a68: r1 = LoadClassIdInstr(r0)
    //     0xc02a68: ldur            x1, [x0, #-1]
    //     0xc02a6c: ubfx            x1, x1, #0xc, #0x14
    // 0xc02a70: lsl             x1, x1, #1
    // 0xc02a74: r17 = 9688
    //     0xc02a74: mov             x17, #0x25d8
    // 0xc02a78: cmp             w1, w17
    // 0xc02a7c: b.ne            #0xc02a90
    // 0xc02a80: LoadField: r1 = r0->field_6f
    //     0xc02a80: ldur            w1, [x0, #0x6f]
    // 0xc02a84: DecompressPointer r1
    //     0xc02a84: add             x1, x1, HEAP, lsl #32
    // 0xc02a88: mov             x0, x1
    // 0xc02a8c: b               #0xc02a9c
    // 0xc02a90: LoadField: r1 = r0->field_6f
    //     0xc02a90: ldur            w1, [x0, #0x6f]
    // 0xc02a94: DecompressPointer r1
    //     0xc02a94: add             x1, x1, HEAP, lsl #32
    // 0xc02a98: mov             x0, x1
    // 0xc02a9c: SaveReg r0
    //     0xc02a9c: str             x0, [SP, #-8]!
    // 0xc02aa0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc02aa0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc02aa4: r0 = updateCanDrag()
    //     0xc02aa4: bl              #0xc02650  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::updateCanDrag
    // 0xc02aa8: add             SP, SP, #8
    // 0xc02aac: r0 = Null
    //     0xc02aac: mov             x0, NULL
    // 0xc02ab0: LeaveFrame
    //     0xc02ab0: mov             SP, fp
    //     0xc02ab4: ldp             fp, lr, [SP], #0x10
    // 0xc02ab8: ret
    //     0xc02ab8: ret             
    // 0xc02abc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02abc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02ac0: b               #0xc02a54
  }
  _ restoreScrollOffset(/* No info */) {
    // ** addr: 0xc03208, size: 0x7c
    // 0xc03208: EnterFrame
    //     0xc03208: stp             fp, lr, [SP, #-0x10]!
    //     0xc0320c: mov             fp, SP
    // 0xc03210: CheckStackOverflow
    //     0xc03210: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc03214: cmp             SP, x16
    //     0xc03218: b.ls            #0xc0327c
    // 0xc0321c: ldr             x0, [fp, #0x10]
    // 0xc03220: r1 = LoadClassIdInstr(r0)
    //     0xc03220: ldur            x1, [x0, #-1]
    //     0xc03224: ubfx            x1, x1, #0xc, #0x14
    // 0xc03228: lsl             x1, x1, #1
    // 0xc0322c: r17 = 9688
    //     0xc0322c: mov             x17, #0x25d8
    // 0xc03230: cmp             w1, w17
    // 0xc03234: b.ne            #0xc03244
    // 0xc03238: LoadField: r1 = r0->field_6f
    //     0xc03238: ldur            w1, [x0, #0x6f]
    // 0xc0323c: DecompressPointer r1
    //     0xc0323c: add             x1, x1, HEAP, lsl #32
    // 0xc03240: b               #0xc0324c
    // 0xc03244: LoadField: r1 = r0->field_6f
    //     0xc03244: ldur            w1, [x0, #0x6f]
    // 0xc03248: DecompressPointer r1
    //     0xc03248: add             x1, x1, HEAP, lsl #32
    // 0xc0324c: SaveReg r1
    //     0xc0324c: str             x1, [SP, #-8]!
    // 0xc03250: r0 = canScrollBody()
    //     0xc03250: bl              #0xc03284  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::canScrollBody
    // 0xc03254: add             SP, SP, #8
    // 0xc03258: tbnz            w0, #4, #0xc0326c
    // 0xc0325c: ldr             x16, [fp, #0x10]
    // 0xc03260: SaveReg r16
    //     0xc03260: str             x16, [SP, #-8]!
    // 0xc03264: r0 = restoreScrollOffset()
    //     0xc03264: bl              #0xc030fc  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::restoreScrollOffset
    // 0xc03268: add             SP, SP, #8
    // 0xc0326c: r0 = Null
    //     0xc0326c: mov             x0, NULL
    // 0xc03270: LeaveFrame
    //     0xc03270: mov             SP, fp
    //     0xc03274: ldp             fp, lr, [SP], #0x10
    // 0xc03278: ret
    //     0xc03278: ret             
    // 0xc0327c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0327c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc03280: b               #0xc0321c
  }
  _ goIdle(/* No info */) {
    // ** addr: 0xc1163c, size: 0x94
    // 0xc1163c: EnterFrame
    //     0xc1163c: stp             fp, lr, [SP, #-0x10]!
    //     0xc11640: mov             fp, SP
    // 0xc11644: CheckStackOverflow
    //     0xc11644: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc11648: cmp             SP, x16
    //     0xc1164c: b.ls            #0xc116c8
    // 0xc11650: r0 = IdleScrollActivity()
    //     0xc11650: bl              #0x81ce04  ; AllocateIdleScrollActivityStub -> IdleScrollActivity (size=0xc)
    // 0xc11654: mov             x1, x0
    // 0xc11658: ldr             x0, [fp, #0x10]
    // 0xc1165c: StoreField: r1->field_7 = r0
    //     0xc1165c: stur            w0, [x1, #7]
    // 0xc11660: stp             x1, x0, [SP, #-0x10]!
    // 0xc11664: r0 = beginActivity()
    //     0xc11664: bl              #0xbff1c4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::beginActivity
    // 0xc11668: add             SP, SP, #0x10
    // 0xc1166c: ldr             x0, [fp, #0x10]
    // 0xc11670: r1 = LoadClassIdInstr(r0)
    //     0xc11670: ldur            x1, [x0, #-1]
    //     0xc11674: ubfx            x1, x1, #0xc, #0x14
    // 0xc11678: lsl             x1, x1, #1
    // 0xc1167c: r17 = 9688
    //     0xc1167c: mov             x17, #0x25d8
    // 0xc11680: cmp             w1, w17
    // 0xc11684: b.ne            #0xc11698
    // 0xc11688: LoadField: r1 = r0->field_6f
    //     0xc11688: ldur            w1, [x0, #0x6f]
    // 0xc1168c: DecompressPointer r1
    //     0xc1168c: add             x1, x1, HEAP, lsl #32
    // 0xc11690: mov             x0, x1
    // 0xc11694: b               #0xc116a4
    // 0xc11698: LoadField: r1 = r0->field_6f
    //     0xc11698: ldur            w1, [x0, #0x6f]
    // 0xc1169c: DecompressPointer r1
    //     0xc1169c: add             x1, x1, HEAP, lsl #32
    // 0xc116a0: mov             x0, x1
    // 0xc116a4: r16 = Instance_ScrollDirection
    //     0xc116a4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f8c0] Obj!ScrollDirection@b646f1
    //     0xc116a8: ldr             x16, [x16, #0x8c0]
    // 0xc116ac: stp             x16, x0, [SP, #-0x10]!
    // 0xc116b0: r0 = updateUserScrollDirection()
    //     0xc116b0: bl              #0xc116d0  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::updateUserScrollDirection
    // 0xc116b4: add             SP, SP, #0x10
    // 0xc116b8: r0 = Null
    //     0xc116b8: mov             x0, NULL
    // 0xc116bc: LeaveFrame
    //     0xc116bc: mov             SP, fp
    //     0xc116c0: ldp             fp, lr, [SP], #0x10
    // 0xc116c4: ret
    //     0xc116c4: ret             
    // 0xc116c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc116c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc116cc: b               #0xc11650
  }
  _ applyClampedDragUpdate(/* No info */) {
    // ** addr: 0xc14114, size: 0x2ec
    // 0xc14114: EnterFrame
    //     0xc14114: stp             fp, lr, [SP, #-0x10]!
    //     0xc14118: mov             fp, SP
    // 0xc1411c: AllocStack(0x20)
    //     0xc1411c: sub             SP, SP, #0x20
    // 0xc14120: d0 = 0.000000
    //     0xc14120: eor             v0.16b, v0.16b, v0.16b
    // 0xc14124: CheckStackOverflow
    //     0xc14124: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc14128: cmp             SP, x16
    //     0xc1412c: b.ls            #0xc143e4
    // 0xc14130: ldr             d1, [fp, #0x10]
    // 0xc14134: fcmp            d1, d0
    // 0xc14138: b.vs            #0xc14150
    // 0xc1413c: b.ge            #0xc14150
    // 0xc14140: d2 = inf
    //     0xc14140: ldr             d2, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xc14144: fneg            d3, d2
    // 0xc14148: mov             v2.16b, v3.16b
    // 0xc1414c: b               #0xc1422c
    // 0xc14150: ldr             x0, [fp, #0x18]
    // 0xc14154: LoadField: r1 = r0->field_33
    //     0xc14154: ldur            w1, [x0, #0x33]
    // 0xc14158: DecompressPointer r1
    //     0xc14158: add             x1, x1, HEAP, lsl #32
    // 0xc1415c: stur            x1, [fp, #-0x10]
    // 0xc14160: cmp             w1, NULL
    // 0xc14164: b.eq            #0xc143ec
    // 0xc14168: LoadField: r2 = r0->field_43
    //     0xc14168: ldur            w2, [x0, #0x43]
    // 0xc1416c: DecompressPointer r2
    //     0xc1416c: add             x2, x2, HEAP, lsl #32
    // 0xc14170: stur            x2, [fp, #-8]
    // 0xc14174: cmp             w2, NULL
    // 0xc14178: b.eq            #0xc143f0
    // 0xc1417c: LoadField: d2 = r1->field_7
    //     0xc1417c: ldur            d2, [x1, #7]
    // 0xc14180: LoadField: d3 = r2->field_7
    //     0xc14180: ldur            d3, [x2, #7]
    // 0xc14184: fcmp            d2, d3
    // 0xc14188: b.vs            #0xc1419c
    // 0xc1418c: b.le            #0xc1419c
    // 0xc14190: LoadField: d2 = r2->field_7
    //     0xc14190: ldur            d2, [x2, #7]
    // 0xc14194: mov             v0.16b, v2.16b
    // 0xc14198: b               #0xc14220
    // 0xc1419c: fcmp            d2, d3
    // 0xc141a0: b.vs            #0xc141b4
    // 0xc141a4: b.ge            #0xc141b4
    // 0xc141a8: LoadField: d2 = r1->field_7
    //     0xc141a8: ldur            d2, [x1, #7]
    // 0xc141ac: mov             v0.16b, v2.16b
    // 0xc141b0: b               #0xc14220
    // 0xc141b4: fcmp            d2, d0
    // 0xc141b8: b.vs            #0xc141c0
    // 0xc141bc: b.eq            #0xc141c8
    // 0xc141c0: r3 = false
    //     0xc141c0: add             x3, NULL, #0x30  ; false
    // 0xc141c4: b               #0xc141cc
    // 0xc141c8: r3 = true
    //     0xc141c8: add             x3, NULL, #0x20  ; true
    // 0xc141cc: tbnz            w3, #4, #0xc141e4
    // 0xc141d0: fadd            d4, d2, d3
    // 0xc141d4: fmul            d5, d4, d2
    // 0xc141d8: fmul            d2, d5, d3
    // 0xc141dc: mov             v0.16b, v2.16b
    // 0xc141e0: b               #0xc14220
    // 0xc141e4: tbnz            w3, #4, #0xc14200
    // 0xc141e8: SaveReg r2
    //     0xc141e8: str             x2, [SP, #-8]!
    // 0xc141ec: r0 = isNegative()
    //     0xc141ec: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xc141f0: add             SP, SP, #8
    // 0xc141f4: tbnz            w0, #4, #0xc14200
    // 0xc141f8: ldur            x0, [fp, #-8]
    // 0xc141fc: b               #0xc14210
    // 0xc14200: ldur            x0, [fp, #-8]
    // 0xc14204: LoadField: d0 = r0->field_7
    //     0xc14204: ldur            d0, [x0, #7]
    // 0xc14208: fcmp            d0, d0
    // 0xc1420c: b.vc            #0xc14218
    // 0xc14210: LoadField: d0 = r0->field_7
    //     0xc14210: ldur            d0, [x0, #7]
    // 0xc14214: b               #0xc14220
    // 0xc14218: ldur            x0, [fp, #-0x10]
    // 0xc1421c: LoadField: d0 = r0->field_7
    //     0xc1421c: ldur            d0, [x0, #7]
    // 0xc14220: mov             v2.16b, v0.16b
    // 0xc14224: ldr             d1, [fp, #0x10]
    // 0xc14228: d0 = 0.000000
    //     0xc14228: eor             v0.16b, v0.16b, v0.16b
    // 0xc1422c: fcmp            d1, d0
    // 0xc14230: b.vs            #0xc14244
    // 0xc14234: b.le            #0xc14244
    // 0xc14238: ldr             x1, [fp, #0x18]
    // 0xc1423c: d3 = inf
    //     0xc1423c: ldr             d3, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xc14240: b               #0xc142dc
    // 0xc14244: ldr             x1, [fp, #0x18]
    // 0xc14248: LoadField: r0 = r1->field_43
    //     0xc14248: ldur            w0, [x1, #0x43]
    // 0xc1424c: DecompressPointer r0
    //     0xc1424c: add             x0, x0, HEAP, lsl #32
    // 0xc14250: cmp             w0, NULL
    // 0xc14254: b.eq            #0xc143f4
    // 0xc14258: LoadField: d3 = r0->field_7
    //     0xc14258: ldur            d3, [x0, #7]
    // 0xc1425c: fcmp            d3, d0
    // 0xc14260: b.vs            #0xc14270
    // 0xc14264: b.ge            #0xc14270
    // 0xc14268: d3 = 0.000000
    //     0xc14268: eor             v3.16b, v3.16b, v3.16b
    // 0xc1426c: b               #0xc142dc
    // 0xc14270: LoadField: r2 = r1->field_37
    //     0xc14270: ldur            w2, [x1, #0x37]
    // 0xc14274: DecompressPointer r2
    //     0xc14274: add             x2, x2, HEAP, lsl #32
    // 0xc14278: cmp             w2, NULL
    // 0xc1427c: b.eq            #0xc143f8
    // 0xc14280: LoadField: d4 = r2->field_7
    //     0xc14280: ldur            d4, [x2, #7]
    // 0xc14284: fcmp            d4, d3
    // 0xc14288: b.vs            #0xc14298
    // 0xc1428c: b.le            #0xc14298
    // 0xc14290: LoadField: d3 = r2->field_7
    //     0xc14290: ldur            d3, [x2, #7]
    // 0xc14294: b               #0xc142dc
    // 0xc14298: fcmp            d4, d3
    // 0xc1429c: b.vs            #0xc142ac
    // 0xc142a0: b.ge            #0xc142ac
    // 0xc142a4: LoadField: d3 = r0->field_7
    //     0xc142a4: ldur            d3, [x0, #7]
    // 0xc142a8: b               #0xc142dc
    // 0xc142ac: fcmp            d4, d0
    // 0xc142b0: b.vs            #0xc142c4
    // 0xc142b4: b.ne            #0xc142c4
    // 0xc142b8: fadd            d5, d4, d3
    // 0xc142bc: mov             v3.16b, v5.16b
    // 0xc142c0: b               #0xc142dc
    // 0xc142c4: LoadField: d3 = r0->field_7
    //     0xc142c4: ldur            d3, [x0, #7]
    // 0xc142c8: fcmp            d3, d3
    // 0xc142cc: b.vc            #0xc142d8
    // 0xc142d0: LoadField: d3 = r0->field_7
    //     0xc142d0: ldur            d3, [x0, #7]
    // 0xc142d4: b               #0xc142dc
    // 0xc142d8: LoadField: d3 = r2->field_7
    //     0xc142d8: ldur            d3, [x2, #7]
    // 0xc142dc: LoadField: r0 = r1->field_43
    //     0xc142dc: ldur            w0, [x1, #0x43]
    // 0xc142e0: DecompressPointer r0
    //     0xc142e0: add             x0, x0, HEAP, lsl #32
    // 0xc142e4: cmp             w0, NULL
    // 0xc142e8: b.eq            #0xc143fc
    // 0xc142ec: LoadField: d4 = r0->field_7
    //     0xc142ec: ldur            d4, [x0, #7]
    // 0xc142f0: stur            d4, [fp, #-0x20]
    // 0xc142f4: fsub            d5, d4, d1
    // 0xc142f8: fcmp            d5, d2
    // 0xc142fc: b.vs            #0xc14304
    // 0xc14300: b.lt            #0xc1432c
    // 0xc14304: fcmp            d5, d3
    // 0xc14308: b.vs            #0xc14318
    // 0xc1430c: b.le            #0xc14318
    // 0xc14310: mov             v2.16b, v3.16b
    // 0xc14314: b               #0xc1432c
    // 0xc14318: fcmp            d5, d5
    // 0xc1431c: b.vc            #0xc14328
    // 0xc14320: mov             v2.16b, v3.16b
    // 0xc14324: b               #0xc1432c
    // 0xc14328: mov             v2.16b, v5.16b
    // 0xc1432c: stur            d2, [fp, #-0x18]
    // 0xc14330: fsub            d3, d2, d4
    // 0xc14334: fcmp            d3, d0
    // 0xc14338: b.vs            #0xc14350
    // 0xc1433c: b.ne            #0xc14350
    // 0xc14340: mov             v0.16b, v1.16b
    // 0xc14344: LeaveFrame
    //     0xc14344: mov             SP, fp
    //     0xc14348: ldp             fp, lr, [SP], #0x10
    // 0xc1434c: ret
    //     0xc1434c: ret             
    // 0xc14350: LoadField: r0 = r1->field_23
    //     0xc14350: ldur            w0, [x1, #0x23]
    // 0xc14354: DecompressPointer r0
    //     0xc14354: add             x0, x0, HEAP, lsl #32
    // 0xc14358: r2 = LoadClassIdInstr(r0)
    //     0xc14358: ldur            x2, [x0, #-1]
    //     0xc1435c: ubfx            x2, x2, #0xc, #0x14
    // 0xc14360: stp             x1, x0, [SP, #-0x10]!
    // 0xc14364: SaveReg d2
    //     0xc14364: str             d2, [SP, #-8]!
    // 0xc14368: mov             x0, x2
    // 0xc1436c: r0 = GDT[cid_x0 + 0x7a7]()
    //     0xc1436c: add             lr, x0, #0x7a7
    //     0xc14370: ldr             lr, [x21, lr, lsl #3]
    //     0xc14374: blr             lr
    // 0xc14378: add             SP, SP, #0x18
    // 0xc1437c: mov             v1.16b, v0.16b
    // 0xc14380: ldur            d0, [fp, #-0x18]
    // 0xc14384: fsub            d2, d0, d1
    // 0xc14388: ldur            d0, [fp, #-0x20]
    // 0xc1438c: fsub            d1, d2, d0
    // 0xc14390: stur            d1, [fp, #-0x18]
    // 0xc14394: d0 = 0.000000
    //     0xc14394: eor             v0.16b, v0.16b, v0.16b
    // 0xc14398: fcmp            d1, d0
    // 0xc1439c: b.eq            #0xc143cc
    // 0xc143a0: ldr             x16, [fp, #0x18]
    // 0xc143a4: SaveReg r16
    //     0xc143a4: str             x16, [SP, #-8]!
    // 0xc143a8: SaveReg d2
    //     0xc143a8: str             d2, [SP, #-8]!
    // 0xc143ac: r0 = forcePixels()
    //     0xc143ac: bl              #0xc144d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::forcePixels
    // 0xc143b0: add             SP, SP, #0x10
    // 0xc143b4: ldr             x16, [fp, #0x18]
    // 0xc143b8: SaveReg r16
    //     0xc143b8: str             x16, [SP, #-8]!
    // 0xc143bc: ldur            d0, [fp, #-0x18]
    // 0xc143c0: SaveReg d0
    //     0xc143c0: str             d0, [SP, #-8]!
    // 0xc143c4: r0 = didUpdateScrollPositionBy()
    //     0xc143c4: bl              #0xc14400  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didUpdateScrollPositionBy
    // 0xc143c8: add             SP, SP, #0x10
    // 0xc143cc: ldr             d2, [fp, #0x10]
    // 0xc143d0: ldur            d1, [fp, #-0x18]
    // 0xc143d4: fadd            d0, d2, d1
    // 0xc143d8: LeaveFrame
    //     0xc143d8: mov             SP, fp
    //     0xc143dc: ldp             fp, lr, [SP], #0x10
    // 0xc143e0: ret
    //     0xc143e0: ret             
    // 0xc143e4: r0 = StackOverflowSharedWithFPURegs()
    //     0xc143e4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc143e8: b               #0xc14130
    // 0xc143ec: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc143ec: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc143f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc143f0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc143f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc143f4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc143f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc143f8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc143fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc143fc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ applyFullDragUpdate(/* No info */) {
    // ** addr: 0xc14718, size: 0x160
    // 0xc14718: EnterFrame
    //     0xc14718: stp             fp, lr, [SP, #-0x10]!
    //     0xc1471c: mov             fp, SP
    // 0xc14720: AllocStack(0x30)
    //     0xc14720: sub             SP, SP, #0x30
    // 0xc14724: CheckStackOverflow
    //     0xc14724: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc14728: cmp             SP, x16
    //     0xc1472c: b.ls            #0xc1486c
    // 0xc14730: ldr             x1, [fp, #0x18]
    // 0xc14734: LoadField: r2 = r1->field_43
    //     0xc14734: ldur            w2, [x1, #0x43]
    // 0xc14738: DecompressPointer r2
    //     0xc14738: add             x2, x2, HEAP, lsl #32
    // 0xc1473c: stur            x2, [fp, #-0x10]
    // 0xc14740: cmp             w2, NULL
    // 0xc14744: b.eq            #0xc14874
    // 0xc14748: LoadField: r3 = r1->field_23
    //     0xc14748: ldur            w3, [x1, #0x23]
    // 0xc1474c: DecompressPointer r3
    //     0xc1474c: add             x3, x3, HEAP, lsl #32
    // 0xc14750: stur            x3, [fp, #-8]
    // 0xc14754: r0 = LoadClassIdInstr(r3)
    //     0xc14754: ldur            x0, [x3, #-1]
    //     0xc14758: ubfx            x0, x0, #0xc, #0x14
    // 0xc1475c: stp             x1, x3, [SP, #-0x10]!
    // 0xc14760: ldr             d0, [fp, #0x10]
    // 0xc14764: SaveReg d0
    //     0xc14764: str             d0, [SP, #-8]!
    // 0xc14768: r0 = GDT[cid_x0 + 0x829]()
    //     0xc14768: add             lr, x0, #0x829
    //     0xc1476c: ldr             lr, [x21, lr, lsl #3]
    //     0xc14770: blr             lr
    // 0xc14774: add             SP, SP, #0x18
    // 0xc14778: ldur            x0, [fp, #-0x10]
    // 0xc1477c: LoadField: d1 = r0->field_7
    //     0xc1477c: ldur            d1, [x0, #7]
    // 0xc14780: stur            d1, [fp, #-0x20]
    // 0xc14784: fsub            d2, d1, d0
    // 0xc14788: stur            d2, [fp, #-0x18]
    // 0xc1478c: fcmp            d1, d2
    // 0xc14790: b.vs            #0xc147a8
    // 0xc14794: b.ne            #0xc147a8
    // 0xc14798: d0 = 0.000000
    //     0xc14798: eor             v0.16b, v0.16b, v0.16b
    // 0xc1479c: LeaveFrame
    //     0xc1479c: mov             SP, fp
    //     0xc147a0: ldp             fp, lr, [SP], #0x10
    // 0xc147a4: ret
    //     0xc147a4: ret             
    // 0xc147a8: ldur            x0, [fp, #-8]
    // 0xc147ac: r1 = LoadClassIdInstr(r0)
    //     0xc147ac: ldur            x1, [x0, #-1]
    //     0xc147b0: ubfx            x1, x1, #0xc, #0x14
    // 0xc147b4: ldr             x16, [fp, #0x18]
    // 0xc147b8: stp             x16, x0, [SP, #-0x10]!
    // 0xc147bc: SaveReg d2
    //     0xc147bc: str             d2, [SP, #-8]!
    // 0xc147c0: mov             x0, x1
    // 0xc147c4: r0 = GDT[cid_x0 + 0x7a7]()
    //     0xc147c4: add             lr, x0, #0x7a7
    //     0xc147c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc147cc: blr             lr
    // 0xc147d0: add             SP, SP, #0x18
    // 0xc147d4: mov             v1.16b, v0.16b
    // 0xc147d8: ldur            d0, [fp, #-0x18]
    // 0xc147dc: stur            d1, [fp, #-0x30]
    // 0xc147e0: fsub            d2, d0, d1
    // 0xc147e4: ldur            d0, [fp, #-0x20]
    // 0xc147e8: stur            d2, [fp, #-0x28]
    // 0xc147ec: fcmp            d2, d0
    // 0xc147f0: b.eq            #0xc14828
    // 0xc147f4: ldr             x16, [fp, #0x18]
    // 0xc147f8: SaveReg r16
    //     0xc147f8: str             x16, [SP, #-8]!
    // 0xc147fc: SaveReg d2
    //     0xc147fc: str             d2, [SP, #-8]!
    // 0xc14800: r0 = forcePixels()
    //     0xc14800: bl              #0xc144d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::forcePixels
    // 0xc14804: add             SP, SP, #0x10
    // 0xc14808: ldur            d0, [fp, #-0x28]
    // 0xc1480c: ldur            d1, [fp, #-0x20]
    // 0xc14810: fsub            d2, d0, d1
    // 0xc14814: ldr             x16, [fp, #0x18]
    // 0xc14818: SaveReg r16
    //     0xc14818: str             x16, [SP, #-8]!
    // 0xc1481c: SaveReg d2
    //     0xc1481c: str             d2, [SP, #-8]!
    // 0xc14820: r0 = didUpdateScrollPositionBy()
    //     0xc14820: bl              #0xc14400  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didUpdateScrollPositionBy
    // 0xc14824: add             SP, SP, #0x10
    // 0xc14828: ldur            d0, [fp, #-0x30]
    // 0xc1482c: d1 = 0.000000
    //     0xc1482c: eor             v1.16b, v1.16b, v1.16b
    // 0xc14830: fcmp            d0, d1
    // 0xc14834: b.eq            #0xc1485c
    // 0xc14838: ldr             x16, [fp, #0x18]
    // 0xc1483c: SaveReg r16
    //     0xc1483c: str             x16, [SP, #-8]!
    // 0xc14840: SaveReg d0
    //     0xc14840: str             d0, [SP, #-8]!
    // 0xc14844: r0 = didOverscrollBy()
    //     0xc14844: bl              #0xc14878  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didOverscrollBy
    // 0xc14848: add             SP, SP, #0x10
    // 0xc1484c: ldur            d0, [fp, #-0x30]
    // 0xc14850: LeaveFrame
    //     0xc14850: mov             SP, fp
    //     0xc14854: ldp             fp, lr, [SP], #0x10
    // 0xc14858: ret
    //     0xc14858: ret             
    // 0xc1485c: mov             v0.16b, v1.16b
    // 0xc14860: LeaveFrame
    //     0xc14860: mov             SP, fp
    //     0xc14864: ldp             fp, lr, [SP], #0x10
    // 0xc14868: ret
    //     0xc14868: ret             
    // 0xc1486c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1486c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc14870: b               #0xc14730
    // 0xc14874: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc14874: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ drag(/* No info */) {
    // ** addr: 0xc43830, size: 0x4c
    // 0xc43830: EnterFrame
    //     0xc43830: stp             fp, lr, [SP, #-0x10]!
    //     0xc43834: mov             fp, SP
    // 0xc43838: CheckStackOverflow
    //     0xc43838: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4383c: cmp             SP, x16
    //     0xc43840: b.ls            #0xc43874
    // 0xc43844: ldr             x0, [fp, #0x20]
    // 0xc43848: LoadField: r1 = r0->field_6f
    //     0xc43848: ldur            w1, [x0, #0x6f]
    // 0xc4384c: DecompressPointer r1
    //     0xc4384c: add             x1, x1, HEAP, lsl #32
    // 0xc43850: ldr             x16, [fp, #0x18]
    // 0xc43854: stp             x16, x1, [SP, #-0x10]!
    // 0xc43858: ldr             x16, [fp, #0x10]
    // 0xc4385c: SaveReg r16
    //     0xc4385c: str             x16, [SP, #-8]!
    // 0xc43860: r0 = drag()
    //     0xc43860: bl              #0xc4365c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::drag
    // 0xc43864: add             SP, SP, #0x18
    // 0xc43868: LeaveFrame
    //     0xc43868: mov             SP, fp
    //     0xc4386c: ldp             fp, lr, [SP], #0x10
    // 0xc43870: ret
    //     0xc43870: ret             
    // 0xc43874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43874: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc43878: b               #0xc43844
  }
  _ hold(/* No info */) {
    // ** addr: 0xc43dcc, size: 0x70
    // 0xc43dcc: EnterFrame
    //     0xc43dcc: stp             fp, lr, [SP, #-0x10]!
    //     0xc43dd0: mov             fp, SP
    // 0xc43dd4: CheckStackOverflow
    //     0xc43dd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc43dd8: cmp             SP, x16
    //     0xc43ddc: b.ls            #0xc43e34
    // 0xc43de0: ldr             x0, [fp, #0x18]
    // 0xc43de4: r1 = LoadClassIdInstr(r0)
    //     0xc43de4: ldur            x1, [x0, #-1]
    //     0xc43de8: ubfx            x1, x1, #0xc, #0x14
    // 0xc43dec: lsl             x1, x1, #1
    // 0xc43df0: r17 = 9688
    //     0xc43df0: mov             x17, #0x25d8
    // 0xc43df4: cmp             w1, w17
    // 0xc43df8: b.ne            #0xc43e0c
    // 0xc43dfc: LoadField: r1 = r0->field_6f
    //     0xc43dfc: ldur            w1, [x0, #0x6f]
    // 0xc43e00: DecompressPointer r1
    //     0xc43e00: add             x1, x1, HEAP, lsl #32
    // 0xc43e04: mov             x0, x1
    // 0xc43e08: b               #0xc43e18
    // 0xc43e0c: LoadField: r1 = r0->field_6f
    //     0xc43e0c: ldur            w1, [x0, #0x6f]
    // 0xc43e10: DecompressPointer r1
    //     0xc43e10: add             x1, x1, HEAP, lsl #32
    // 0xc43e14: mov             x0, x1
    // 0xc43e18: ldr             x16, [fp, #0x10]
    // 0xc43e1c: stp             x16, x0, [SP, #-0x10]!
    // 0xc43e20: r0 = hold()
    //     0xc43e20: bl              #0xc43e3c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::hold
    // 0xc43e24: add             SP, SP, #0x10
    // 0xc43e28: LeaveFrame
    //     0xc43e28: mov             SP, fp
    //     0xc43e2c: ldp             fp, lr, [SP], #0x10
    // 0xc43e30: ret
    //     0xc43e30: ret             
    // 0xc43e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43e34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc43e38: b               #0xc43de0
  }
  _ pointerScroll(/* No info */) {
    // ** addr: 0xc4592c, size: 0x78
    // 0xc4592c: EnterFrame
    //     0xc4592c: stp             fp, lr, [SP, #-0x10]!
    //     0xc45930: mov             fp, SP
    // 0xc45934: CheckStackOverflow
    //     0xc45934: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc45938: cmp             SP, x16
    //     0xc4593c: b.ls            #0xc4599c
    // 0xc45940: ldr             x0, [fp, #0x18]
    // 0xc45944: r1 = LoadClassIdInstr(r0)
    //     0xc45944: ldur            x1, [x0, #-1]
    //     0xc45948: ubfx            x1, x1, #0xc, #0x14
    // 0xc4594c: lsl             x1, x1, #1
    // 0xc45950: r17 = 9688
    //     0xc45950: mov             x17, #0x25d8
    // 0xc45954: cmp             w1, w17
    // 0xc45958: b.ne            #0xc4596c
    // 0xc4595c: LoadField: r1 = r0->field_6f
    //     0xc4595c: ldur            w1, [x0, #0x6f]
    // 0xc45960: DecompressPointer r1
    //     0xc45960: add             x1, x1, HEAP, lsl #32
    // 0xc45964: mov             x0, x1
    // 0xc45968: b               #0xc45978
    // 0xc4596c: LoadField: r1 = r0->field_6f
    //     0xc4596c: ldur            w1, [x0, #0x6f]
    // 0xc45970: DecompressPointer r1
    //     0xc45970: add             x1, x1, HEAP, lsl #32
    // 0xc45974: mov             x0, x1
    // 0xc45978: ldr             d0, [fp, #0x10]
    // 0xc4597c: SaveReg r0
    //     0xc4597c: str             x0, [SP, #-8]!
    // 0xc45980: SaveReg d0
    //     0xc45980: str             d0, [SP, #-8]!
    // 0xc45984: r0 = pointerScroll()
    //     0xc45984: bl              #0xc459a4  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::pointerScroll
    // 0xc45988: add             SP, SP, #0x10
    // 0xc4598c: r0 = Null
    //     0xc4598c: mov             x0, NULL
    // 0xc45990: LeaveFrame
    //     0xc45990: mov             SP, fp
    //     0xc45994: ldp             fp, lr, [SP], #0x10
    // 0xc45998: ret
    //     0xc45998: ret             
    // 0xc4599c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4599c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc459a0: b               #0xc45940
  }
  _ applyClampedPointerSignalUpdate(/* No info */) {
    // ** addr: 0xc462c8, size: 0x280
    // 0xc462c8: EnterFrame
    //     0xc462c8: stp             fp, lr, [SP, #-0x10]!
    //     0xc462cc: mov             fp, SP
    // 0xc462d0: AllocStack(0x18)
    //     0xc462d0: sub             SP, SP, #0x18
    // 0xc462d4: d0 = 0.000000
    //     0xc462d4: eor             v0.16b, v0.16b, v0.16b
    // 0xc462d8: CheckStackOverflow
    //     0xc462d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc462dc: cmp             SP, x16
    //     0xc462e0: b.ls            #0xc4652c
    // 0xc462e4: ldr             d1, [fp, #0x10]
    // 0xc462e8: fcmp            d1, d0
    // 0xc462ec: b.vs            #0xc46304
    // 0xc462f0: b.le            #0xc46304
    // 0xc462f4: d2 = inf
    //     0xc462f4: ldr             d2, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xc462f8: fneg            d3, d2
    // 0xc462fc: mov             v2.16b, v3.16b
    // 0xc46300: b               #0xc463e0
    // 0xc46304: ldr             x0, [fp, #0x18]
    // 0xc46308: LoadField: r1 = r0->field_33
    //     0xc46308: ldur            w1, [x0, #0x33]
    // 0xc4630c: DecompressPointer r1
    //     0xc4630c: add             x1, x1, HEAP, lsl #32
    // 0xc46310: stur            x1, [fp, #-0x10]
    // 0xc46314: cmp             w1, NULL
    // 0xc46318: b.eq            #0xc46534
    // 0xc4631c: LoadField: r2 = r0->field_43
    //     0xc4631c: ldur            w2, [x0, #0x43]
    // 0xc46320: DecompressPointer r2
    //     0xc46320: add             x2, x2, HEAP, lsl #32
    // 0xc46324: stur            x2, [fp, #-8]
    // 0xc46328: cmp             w2, NULL
    // 0xc4632c: b.eq            #0xc46538
    // 0xc46330: LoadField: d2 = r1->field_7
    //     0xc46330: ldur            d2, [x1, #7]
    // 0xc46334: LoadField: d3 = r2->field_7
    //     0xc46334: ldur            d3, [x2, #7]
    // 0xc46338: fcmp            d2, d3
    // 0xc4633c: b.vs            #0xc46350
    // 0xc46340: b.le            #0xc46350
    // 0xc46344: LoadField: d2 = r2->field_7
    //     0xc46344: ldur            d2, [x2, #7]
    // 0xc46348: mov             v0.16b, v2.16b
    // 0xc4634c: b               #0xc463d4
    // 0xc46350: fcmp            d2, d3
    // 0xc46354: b.vs            #0xc46368
    // 0xc46358: b.ge            #0xc46368
    // 0xc4635c: LoadField: d2 = r1->field_7
    //     0xc4635c: ldur            d2, [x1, #7]
    // 0xc46360: mov             v0.16b, v2.16b
    // 0xc46364: b               #0xc463d4
    // 0xc46368: fcmp            d2, d0
    // 0xc4636c: b.vs            #0xc46374
    // 0xc46370: b.eq            #0xc4637c
    // 0xc46374: r3 = false
    //     0xc46374: add             x3, NULL, #0x30  ; false
    // 0xc46378: b               #0xc46380
    // 0xc4637c: r3 = true
    //     0xc4637c: add             x3, NULL, #0x20  ; true
    // 0xc46380: tbnz            w3, #4, #0xc46398
    // 0xc46384: fadd            d4, d2, d3
    // 0xc46388: fmul            d5, d4, d2
    // 0xc4638c: fmul            d2, d5, d3
    // 0xc46390: mov             v0.16b, v2.16b
    // 0xc46394: b               #0xc463d4
    // 0xc46398: tbnz            w3, #4, #0xc463b4
    // 0xc4639c: SaveReg r2
    //     0xc4639c: str             x2, [SP, #-8]!
    // 0xc463a0: r0 = isNegative()
    //     0xc463a0: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xc463a4: add             SP, SP, #8
    // 0xc463a8: tbnz            w0, #4, #0xc463b4
    // 0xc463ac: ldur            x0, [fp, #-8]
    // 0xc463b0: b               #0xc463c4
    // 0xc463b4: ldur            x0, [fp, #-8]
    // 0xc463b8: LoadField: d0 = r0->field_7
    //     0xc463b8: ldur            d0, [x0, #7]
    // 0xc463bc: fcmp            d0, d0
    // 0xc463c0: b.vc            #0xc463cc
    // 0xc463c4: LoadField: d0 = r0->field_7
    //     0xc463c4: ldur            d0, [x0, #7]
    // 0xc463c8: b               #0xc463d4
    // 0xc463cc: ldur            x0, [fp, #-0x10]
    // 0xc463d0: LoadField: d0 = r0->field_7
    //     0xc463d0: ldur            d0, [x0, #7]
    // 0xc463d4: mov             v2.16b, v0.16b
    // 0xc463d8: ldr             d1, [fp, #0x10]
    // 0xc463dc: d0 = 0.000000
    //     0xc463dc: eor             v0.16b, v0.16b, v0.16b
    // 0xc463e0: fcmp            d1, d0
    // 0xc463e4: b.vs            #0xc463f8
    // 0xc463e8: b.ge            #0xc463f8
    // 0xc463ec: ldr             x0, [fp, #0x18]
    // 0xc463f0: d3 = inf
    //     0xc463f0: ldr             d3, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xc463f4: b               #0xc4647c
    // 0xc463f8: ldr             x0, [fp, #0x18]
    // 0xc463fc: LoadField: r1 = r0->field_37
    //     0xc463fc: ldur            w1, [x0, #0x37]
    // 0xc46400: DecompressPointer r1
    //     0xc46400: add             x1, x1, HEAP, lsl #32
    // 0xc46404: cmp             w1, NULL
    // 0xc46408: b.eq            #0xc4653c
    // 0xc4640c: LoadField: r2 = r0->field_43
    //     0xc4640c: ldur            w2, [x0, #0x43]
    // 0xc46410: DecompressPointer r2
    //     0xc46410: add             x2, x2, HEAP, lsl #32
    // 0xc46414: cmp             w2, NULL
    // 0xc46418: b.eq            #0xc46540
    // 0xc4641c: LoadField: d3 = r1->field_7
    //     0xc4641c: ldur            d3, [x1, #7]
    // 0xc46420: LoadField: d4 = r2->field_7
    //     0xc46420: ldur            d4, [x2, #7]
    // 0xc46424: fcmp            d3, d4
    // 0xc46428: b.vs            #0xc46438
    // 0xc4642c: b.le            #0xc46438
    // 0xc46430: LoadField: d3 = r1->field_7
    //     0xc46430: ldur            d3, [x1, #7]
    // 0xc46434: b               #0xc4647c
    // 0xc46438: fcmp            d3, d4
    // 0xc4643c: b.vs            #0xc4644c
    // 0xc46440: b.ge            #0xc4644c
    // 0xc46444: LoadField: d3 = r2->field_7
    //     0xc46444: ldur            d3, [x2, #7]
    // 0xc46448: b               #0xc4647c
    // 0xc4644c: fcmp            d3, d0
    // 0xc46450: b.vs            #0xc46464
    // 0xc46454: b.ne            #0xc46464
    // 0xc46458: fadd            d5, d3, d4
    // 0xc4645c: mov             v3.16b, v5.16b
    // 0xc46460: b               #0xc4647c
    // 0xc46464: LoadField: d3 = r2->field_7
    //     0xc46464: ldur            d3, [x2, #7]
    // 0xc46468: fcmp            d3, d3
    // 0xc4646c: b.vc            #0xc46478
    // 0xc46470: LoadField: d3 = r2->field_7
    //     0xc46470: ldur            d3, [x2, #7]
    // 0xc46474: b               #0xc4647c
    // 0xc46478: LoadField: d3 = r1->field_7
    //     0xc46478: ldur            d3, [x1, #7]
    // 0xc4647c: LoadField: r1 = r0->field_43
    //     0xc4647c: ldur            w1, [x0, #0x43]
    // 0xc46480: DecompressPointer r1
    //     0xc46480: add             x1, x1, HEAP, lsl #32
    // 0xc46484: cmp             w1, NULL
    // 0xc46488: b.eq            #0xc46544
    // 0xc4648c: LoadField: d4 = r1->field_7
    //     0xc4648c: ldur            d4, [x1, #7]
    // 0xc46490: fadd            d5, d4, d1
    // 0xc46494: fcmp            d5, d2
    // 0xc46498: b.vs            #0xc464a0
    // 0xc4649c: b.lt            #0xc464c8
    // 0xc464a0: fcmp            d5, d3
    // 0xc464a4: b.vs            #0xc464b4
    // 0xc464a8: b.le            #0xc464b4
    // 0xc464ac: mov             v2.16b, v3.16b
    // 0xc464b0: b               #0xc464c8
    // 0xc464b4: fcmp            d5, d5
    // 0xc464b8: b.vc            #0xc464c4
    // 0xc464bc: mov             v2.16b, v3.16b
    // 0xc464c0: b               #0xc464c8
    // 0xc464c4: mov             v2.16b, v5.16b
    // 0xc464c8: fsub            d3, d2, d4
    // 0xc464cc: stur            d3, [fp, #-0x18]
    // 0xc464d0: fcmp            d3, d0
    // 0xc464d4: b.vs            #0xc464ec
    // 0xc464d8: b.ne            #0xc464ec
    // 0xc464dc: mov             v0.16b, v1.16b
    // 0xc464e0: LeaveFrame
    //     0xc464e0: mov             SP, fp
    //     0xc464e4: ldp             fp, lr, [SP], #0x10
    // 0xc464e8: ret
    //     0xc464e8: ret             
    // 0xc464ec: SaveReg r0
    //     0xc464ec: str             x0, [SP, #-8]!
    // 0xc464f0: SaveReg d2
    //     0xc464f0: str             d2, [SP, #-8]!
    // 0xc464f4: r0 = forcePixels()
    //     0xc464f4: bl              #0xc144d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::forcePixels
    // 0xc464f8: add             SP, SP, #0x10
    // 0xc464fc: ldr             x16, [fp, #0x18]
    // 0xc46500: SaveReg r16
    //     0xc46500: str             x16, [SP, #-8]!
    // 0xc46504: ldur            d0, [fp, #-0x18]
    // 0xc46508: SaveReg d0
    //     0xc46508: str             d0, [SP, #-8]!
    // 0xc4650c: r0 = didUpdateScrollPositionBy()
    //     0xc4650c: bl              #0xc14400  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didUpdateScrollPositionBy
    // 0xc46510: add             SP, SP, #0x10
    // 0xc46514: ldr             d2, [fp, #0x10]
    // 0xc46518: ldur            d1, [fp, #-0x18]
    // 0xc4651c: fsub            d0, d2, d1
    // 0xc46520: LeaveFrame
    //     0xc46520: mov             SP, fp
    //     0xc46524: ldp             fp, lr, [SP], #0x10
    // 0xc46528: ret
    //     0xc46528: ret             
    // 0xc4652c: r0 = StackOverflowSharedWithFPURegs()
    //     0xc4652c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc46530: b               #0xc462e4
    // 0xc46534: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc46534: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc46538: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc46538: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc4653c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc4653c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc46540: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc46540: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc46544: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc46544: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ jumpTo(/* No info */) {
    // ** addr: 0xc51630, size: 0x9c
    // 0xc51630: EnterFrame
    //     0xc51630: stp             fp, lr, [SP, #-0x10]!
    //     0xc51634: mov             fp, SP
    // 0xc51638: AllocStack(0x8)
    //     0xc51638: sub             SP, SP, #8
    // 0xc5163c: CheckStackOverflow
    //     0xc5163c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc51640: cmp             SP, x16
    //     0xc51644: b.ls            #0xc516c4
    // 0xc51648: ldr             x0, [fp, #0x18]
    // 0xc5164c: r1 = LoadClassIdInstr(r0)
    //     0xc5164c: ldur            x1, [x0, #-1]
    //     0xc51650: ubfx            x1, x1, #0xc, #0x14
    // 0xc51654: lsl             x1, x1, #1
    // 0xc51658: r17 = 9688
    //     0xc51658: mov             x17, #0x25d8
    // 0xc5165c: cmp             w1, w17
    // 0xc51660: b.ne            #0xc51674
    // 0xc51664: LoadField: r1 = r0->field_6f
    //     0xc51664: ldur            w1, [x0, #0x6f]
    // 0xc51668: DecompressPointer r1
    //     0xc51668: add             x1, x1, HEAP, lsl #32
    // 0xc5166c: mov             x2, x1
    // 0xc51670: b               #0xc51680
    // 0xc51674: LoadField: r1 = r0->field_6f
    //     0xc51674: ldur            w1, [x0, #0x6f]
    // 0xc51678: DecompressPointer r1
    //     0xc51678: add             x1, x1, HEAP, lsl #32
    // 0xc5167c: mov             x2, x1
    // 0xc51680: ldr             x1, [fp, #0x10]
    // 0xc51684: stur            x2, [fp, #-8]
    // 0xc51688: LoadField: d0 = r1->field_7
    //     0xc51688: ldur            d0, [x1, #7]
    // 0xc5168c: SaveReg r2
    //     0xc5168c: str             x2, [SP, #-8]!
    // 0xc51690: SaveReg d0
    //     0xc51690: str             d0, [SP, #-8]!
    // 0xc51694: SaveReg r0
    //     0xc51694: str             x0, [SP, #-8]!
    // 0xc51698: r0 = unnestOffset()
    //     0xc51698: bl              #0xc51c10  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::unnestOffset
    // 0xc5169c: add             SP, SP, #0x18
    // 0xc516a0: ldur            x16, [fp, #-8]
    // 0xc516a4: SaveReg r16
    //     0xc516a4: str             x16, [SP, #-8]!
    // 0xc516a8: SaveReg d0
    //     0xc516a8: str             d0, [SP, #-8]!
    // 0xc516ac: r0 = jumpTo()
    //     0xc516ac: bl              #0xc516cc  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::jumpTo
    // 0xc516b0: add             SP, SP, #0x10
    // 0xc516b4: r0 = Null
    //     0xc516b4: mov             x0, NULL
    // 0xc516b8: LeaveFrame
    //     0xc516b8: mov             SP, fp
    //     0xc516bc: ldp             fp, lr, [SP], #0x10
    // 0xc516c0: ret
    //     0xc516c0: ret             
    // 0xc516c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc516c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc516c8: b               #0xc51648
  }
  _ localJumpTo(/* No info */) {
    // ** addr: 0xc518d4, size: 0xc0
    // 0xc518d4: EnterFrame
    //     0xc518d4: stp             fp, lr, [SP, #-0x10]!
    //     0xc518d8: mov             fp, SP
    // 0xc518dc: AllocStack(0x8)
    //     0xc518dc: sub             SP, SP, #8
    // 0xc518e0: CheckStackOverflow
    //     0xc518e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc518e4: cmp             SP, x16
    //     0xc518e8: b.ls            #0xc51984
    // 0xc518ec: ldr             x0, [fp, #0x18]
    // 0xc518f0: LoadField: r1 = r0->field_43
    //     0xc518f0: ldur            w1, [x0, #0x43]
    // 0xc518f4: DecompressPointer r1
    //     0xc518f4: add             x1, x1, HEAP, lsl #32
    // 0xc518f8: cmp             w1, NULL
    // 0xc518fc: b.eq            #0xc5198c
    // 0xc51900: LoadField: d0 = r1->field_7
    //     0xc51900: ldur            d0, [x1, #7]
    // 0xc51904: ldr             d1, [fp, #0x10]
    // 0xc51908: stur            d0, [fp, #-8]
    // 0xc5190c: fcmp            d0, d1
    // 0xc51910: b.eq            #0xc51974
    // 0xc51914: SaveReg r0
    //     0xc51914: str             x0, [SP, #-8]!
    // 0xc51918: SaveReg d1
    //     0xc51918: str             d1, [SP, #-8]!
    // 0xc5191c: r0 = forcePixels()
    //     0xc5191c: bl              #0xc144d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::forcePixels
    // 0xc51920: add             SP, SP, #0x10
    // 0xc51924: ldr             x16, [fp, #0x18]
    // 0xc51928: SaveReg r16
    //     0xc51928: str             x16, [SP, #-8]!
    // 0xc5192c: r0 = didStartScroll()
    //     0xc5192c: bl              #0xbff488  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didStartScroll
    // 0xc51930: add             SP, SP, #8
    // 0xc51934: ldr             x0, [fp, #0x18]
    // 0xc51938: LoadField: r1 = r0->field_43
    //     0xc51938: ldur            w1, [x0, #0x43]
    // 0xc5193c: DecompressPointer r1
    //     0xc5193c: add             x1, x1, HEAP, lsl #32
    // 0xc51940: cmp             w1, NULL
    // 0xc51944: b.eq            #0xc51990
    // 0xc51948: LoadField: d0 = r1->field_7
    //     0xc51948: ldur            d0, [x1, #7]
    // 0xc5194c: ldur            d1, [fp, #-8]
    // 0xc51950: fsub            d2, d0, d1
    // 0xc51954: SaveReg r0
    //     0xc51954: str             x0, [SP, #-8]!
    // 0xc51958: SaveReg d2
    //     0xc51958: str             d2, [SP, #-8]!
    // 0xc5195c: r0 = didUpdateScrollPositionBy()
    //     0xc5195c: bl              #0xc14400  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didUpdateScrollPositionBy
    // 0xc51960: add             SP, SP, #0x10
    // 0xc51964: ldr             x16, [fp, #0x18]
    // 0xc51968: SaveReg r16
    //     0xc51968: str             x16, [SP, #-8]!
    // 0xc5196c: r0 = didEndScroll()
    //     0xc5196c: bl              #0xbff54c  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::didEndScroll
    // 0xc51970: add             SP, SP, #8
    // 0xc51974: r0 = Null
    //     0xc51974: mov             x0, NULL
    // 0xc51978: LeaveFrame
    //     0xc51978: mov             SP, fp
    //     0xc5197c: ldp             fp, lr, [SP], #0x10
    // 0xc51980: ret
    //     0xc51980: ret             
    // 0xc51984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc51984: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc51988: b               #0xc518ec
    // 0xc5198c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc5198c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc51990: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc51990: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ goBallistic(/* No info */) {
    // ** addr: 0xc539fc, size: 0xc4
    // 0xc539fc: EnterFrame
    //     0xc539fc: stp             fp, lr, [SP, #-0x10]!
    //     0xc53a00: mov             fp, SP
    // 0xc53a04: d0 = 0.000000
    //     0xc53a04: eor             v0.16b, v0.16b, v0.16b
    // 0xc53a08: CheckStackOverflow
    //     0xc53a08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc53a0c: cmp             SP, x16
    //     0xc53a10: b.ls            #0xc53ab8
    // 0xc53a14: ldr             d1, [fp, #0x10]
    // 0xc53a18: fcmp            d1, d0
    // 0xc53a1c: b.eq            #0xc53a28
    // 0xc53a20: mov             v0.16b, v1.16b
    // 0xc53a24: b               #0xc53a40
    // 0xc53a28: ldr             x16, [fp, #0x18]
    // 0xc53a2c: SaveReg r16
    //     0xc53a2c: str             x16, [SP, #-8]!
    // 0xc53a30: r0 = outOfRange()
    //     0xc53a30: bl              #0xc03724  ; [package:flutter/src/widgets/scroll_position.dart] _ScrollPosition&ViewportOffset&ScrollMetrics::outOfRange
    // 0xc53a34: add             SP, SP, #8
    // 0xc53a38: tbnz            w0, #4, #0xc53a74
    // 0xc53a3c: ldr             d0, [fp, #0x10]
    // 0xc53a40: ldr             x1, [fp, #0x18]
    // 0xc53a44: LoadField: r0 = r1->field_23
    //     0xc53a44: ldur            w0, [x1, #0x23]
    // 0xc53a48: DecompressPointer r0
    //     0xc53a48: add             x0, x0, HEAP, lsl #32
    // 0xc53a4c: r2 = LoadClassIdInstr(r0)
    //     0xc53a4c: ldur            x2, [x0, #-1]
    //     0xc53a50: ubfx            x2, x2, #0xc, #0x14
    // 0xc53a54: stp             x1, x0, [SP, #-0x10]!
    // 0xc53a58: SaveReg d0
    //     0xc53a58: str             d0, [SP, #-8]!
    // 0xc53a5c: mov             x0, x2
    // 0xc53a60: r0 = GDT[cid_x0 + 0x31d]()
    //     0xc53a60: add             lr, x0, #0x31d
    //     0xc53a64: ldr             lr, [x21, lr, lsl #3]
    //     0xc53a68: blr             lr
    // 0xc53a6c: add             SP, SP, #0x18
    // 0xc53a70: b               #0xc53a78
    // 0xc53a74: r0 = Null
    //     0xc53a74: mov             x0, NULL
    // 0xc53a78: ldr             x16, [fp, #0x18]
    // 0xc53a7c: stp             x0, x16, [SP, #-0x10]!
    // 0xc53a80: r16 = Instance__NestedBallisticScrollActivityMode
    //     0xc53a80: add             x16, PP, #0x40, lsl #12  ; [pp+0x40da8] Obj!_NestedBallisticScrollActivityMode@b65ff1
    //     0xc53a84: ldr             x16, [x16, #0xda8]
    // 0xc53a88: SaveReg r16
    //     0xc53a88: str             x16, [SP, #-8]!
    // 0xc53a8c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xc53a8c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xc53a90: r0 = createBallisticScrollActivity()
    //     0xc53a90: bl              #0xbcfa28  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::createBallisticScrollActivity
    // 0xc53a94: add             SP, SP, #0x18
    // 0xc53a98: ldr             x16, [fp, #0x18]
    // 0xc53a9c: stp             x0, x16, [SP, #-0x10]!
    // 0xc53aa0: r0 = beginActivity()
    //     0xc53aa0: bl              #0xbff1c4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::beginActivity
    // 0xc53aa4: add             SP, SP, #0x10
    // 0xc53aa8: r0 = Null
    //     0xc53aa8: mov             x0, NULL
    // 0xc53aac: LeaveFrame
    //     0xc53aac: mov             SP, fp
    //     0xc53ab0: ldp             fp, lr, [SP], #0x10
    // 0xc53ab4: ret
    //     0xc53ab4: ret             
    // 0xc53ab8: r0 = StackOverflowSharedWithFPURegs()
    //     0xc53ab8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc53abc: b               #0xc53a14
  }
  get _ userScrollDirection(/* No info */) {
    // ** addr: 0xc64058, size: 0x44
    // 0xc64058: ldr             x1, [SP]
    // 0xc6405c: r2 = LoadClassIdInstr(r1)
    //     0xc6405c: ldur            x2, [x1, #-1]
    //     0xc64060: ubfx            x2, x2, #0xc, #0x14
    // 0xc64064: lsl             x2, x2, #1
    // 0xc64068: r17 = 9688
    //     0xc64068: mov             x17, #0x25d8
    // 0xc6406c: cmp             w2, w17
    // 0xc64070: b.ne            #0xc64084
    // 0xc64074: LoadField: r2 = r1->field_6f
    //     0xc64074: ldur            w2, [x1, #0x6f]
    // 0xc64078: DecompressPointer r2
    //     0xc64078: add             x2, x2, HEAP, lsl #32
    // 0xc6407c: mov             x1, x2
    // 0xc64080: b               #0xc64090
    // 0xc64084: LoadField: r2 = r1->field_6f
    //     0xc64084: ldur            w2, [x1, #0x6f]
    // 0xc64088: DecompressPointer r2
    //     0xc64088: add             x2, x2, HEAP, lsl #32
    // 0xc6408c: mov             x1, x2
    // 0xc64090: LoadField: r0 = r1->field_1f
    //     0xc64090: ldur            w0, [x1, #0x1f]
    // 0xc64094: DecompressPointer r0
    //     0xc64094: add             x0, x0, HEAP, lsl #32
    // 0xc64098: ret
    //     0xc64098: ret             
  }
  _ animateTo(/* No info */) {
    // ** addr: 0xc81b88, size: 0xa4
    // 0xc81b88: EnterFrame
    //     0xc81b88: stp             fp, lr, [SP, #-0x10]!
    //     0xc81b8c: mov             fp, SP
    // 0xc81b90: AllocStack(0x8)
    //     0xc81b90: sub             SP, SP, #8
    // 0xc81b94: CheckStackOverflow
    //     0xc81b94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc81b98: cmp             SP, x16
    //     0xc81b9c: b.ls            #0xc81c24
    // 0xc81ba0: ldr             x0, [fp, #0x28]
    // 0xc81ba4: r1 = LoadClassIdInstr(r0)
    //     0xc81ba4: ldur            x1, [x0, #-1]
    //     0xc81ba8: ubfx            x1, x1, #0xc, #0x14
    // 0xc81bac: lsl             x1, x1, #1
    // 0xc81bb0: r17 = 9688
    //     0xc81bb0: mov             x17, #0x25d8
    // 0xc81bb4: cmp             w1, w17
    // 0xc81bb8: b.ne            #0xc81bcc
    // 0xc81bbc: LoadField: r1 = r0->field_6f
    //     0xc81bbc: ldur            w1, [x0, #0x6f]
    // 0xc81bc0: DecompressPointer r1
    //     0xc81bc0: add             x1, x1, HEAP, lsl #32
    // 0xc81bc4: mov             x2, x1
    // 0xc81bc8: b               #0xc81bd8
    // 0xc81bcc: LoadField: r1 = r0->field_6f
    //     0xc81bcc: ldur            w1, [x0, #0x6f]
    // 0xc81bd0: DecompressPointer r1
    //     0xc81bd0: add             x1, x1, HEAP, lsl #32
    // 0xc81bd4: mov             x2, x1
    // 0xc81bd8: ldr             x1, [fp, #0x20]
    // 0xc81bdc: stur            x2, [fp, #-8]
    // 0xc81be0: LoadField: d0 = r1->field_7
    //     0xc81be0: ldur            d0, [x1, #7]
    // 0xc81be4: SaveReg r2
    //     0xc81be4: str             x2, [SP, #-8]!
    // 0xc81be8: SaveReg d0
    //     0xc81be8: str             d0, [SP, #-8]!
    // 0xc81bec: SaveReg r0
    //     0xc81bec: str             x0, [SP, #-8]!
    // 0xc81bf0: r0 = unnestOffset()
    //     0xc81bf0: bl              #0xc51c10  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::unnestOffset
    // 0xc81bf4: add             SP, SP, #0x18
    // 0xc81bf8: ldur            x16, [fp, #-8]
    // 0xc81bfc: SaveReg r16
    //     0xc81bfc: str             x16, [SP, #-8]!
    // 0xc81c00: SaveReg d0
    //     0xc81c00: str             d0, [SP, #-8]!
    // 0xc81c04: ldr             x16, [fp, #0x18]
    // 0xc81c08: ldr             lr, [fp, #0x10]
    // 0xc81c0c: stp             lr, x16, [SP, #-0x10]!
    // 0xc81c10: r0 = animateTo()
    //     0xc81c10: bl              #0xc81c2c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::animateTo
    // 0xc81c14: add             SP, SP, #0x20
    // 0xc81c18: LeaveFrame
    //     0xc81c18: mov             SP, fp
    //     0xc81c1c: ldp             fp, lr, [SP], #0x10
    // 0xc81c20: ret
    //     0xc81c20: ret             
    // 0xc81c24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc81c24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc81c28: b               #0xc81ba0
  }
  _ createDrivenScrollActivity(/* No info */) {
    // ** addr: 0xc81e7c, size: 0x98
    // 0xc81e7c: EnterFrame
    //     0xc81e7c: stp             fp, lr, [SP, #-0x10]!
    //     0xc81e80: mov             fp, SP
    // 0xc81e84: AllocStack(0x18)
    //     0xc81e84: sub             SP, SP, #0x18
    // 0xc81e88: CheckStackOverflow
    //     0xc81e88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc81e8c: cmp             SP, x16
    //     0xc81e90: b.ls            #0xc81f08
    // 0xc81e94: ldr             x0, [fp, #0x28]
    // 0xc81e98: LoadField: r1 = r0->field_43
    //     0xc81e98: ldur            w1, [x0, #0x43]
    // 0xc81e9c: DecompressPointer r1
    //     0xc81e9c: add             x1, x1, HEAP, lsl #32
    // 0xc81ea0: stur            x1, [fp, #-8]
    // 0xc81ea4: cmp             w1, NULL
    // 0xc81ea8: b.eq            #0xc81f10
    // 0xc81eac: SaveReg r0
    //     0xc81eac: str             x0, [SP, #-8]!
    // 0xc81eb0: r0 = <anonymous closure>()
    //     0xc81eb0: bl              #0xcec0bc  ; [package:camera/src/camera_controller.dart] CameraController::<anonymous closure>
    // 0xc81eb4: add             SP, SP, #8
    // 0xc81eb8: stur            x0, [fp, #-0x10]
    // 0xc81ebc: r0 = DrivenScrollActivity()
    //     0xc81ebc: bl              #0xc81b7c  ; AllocateDrivenScrollActivityStub -> DrivenScrollActivity (size=0x14)
    // 0xc81ec0: stur            x0, [fp, #-0x18]
    // 0xc81ec4: ldr             x16, [fp, #0x28]
    // 0xc81ec8: stp             x16, x0, [SP, #-0x10]!
    // 0xc81ecc: ldr             x16, [fp, #0x10]
    // 0xc81ed0: ldr             lr, [fp, #0x18]
    // 0xc81ed4: stp             lr, x16, [SP, #-0x10]!
    // 0xc81ed8: ldur            x16, [fp, #-8]
    // 0xc81edc: SaveReg r16
    //     0xc81edc: str             x16, [SP, #-8]!
    // 0xc81ee0: ldr             d0, [fp, #0x20]
    // 0xc81ee4: SaveReg d0
    //     0xc81ee4: str             d0, [SP, #-8]!
    // 0xc81ee8: ldur            x16, [fp, #-0x10]
    // 0xc81eec: SaveReg r16
    //     0xc81eec: str             x16, [SP, #-8]!
    // 0xc81ef0: r0 = DrivenScrollActivity()
    //     0xc81ef0: bl              #0xc81770  ; [package:flutter/src/widgets/scroll_activity.dart] DrivenScrollActivity::DrivenScrollActivity
    // 0xc81ef4: add             SP, SP, #0x38
    // 0xc81ef8: ldur            x0, [fp, #-0x18]
    // 0xc81efc: LeaveFrame
    //     0xc81efc: mov             SP, fp
    //     0xc81f00: ldp             fp, lr, [SP], #0x10
    // 0xc81f04: ret
    //     0xc81f04: ret             
    // 0xc81f08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc81f08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc81f0c: b               #0xc81e94
    // 0xc81f10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc81f10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4845, size: 0x7c, field offset: 0x78
class _ExtendedNestedScrollPosition extends _NestedScrollPosition {

  _ _ExtendedNestedScrollPosition(/* No info */) {
    // ** addr: 0xbebd24, size: 0x60
    // 0xbebd24: EnterFrame
    //     0xbebd24: stp             fp, lr, [SP, #-0x10]!
    //     0xbebd28: mov             fp, SP
    // 0xbebd2c: r0 = false
    //     0xbebd2c: add             x0, NULL, #0x30  ; false
    // 0xbebd30: CheckStackOverflow
    //     0xbebd30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbebd34: cmp             SP, x16
    //     0xbebd38: b.ls            #0xbebd7c
    // 0xbebd3c: ldr             x1, [fp, #0x38]
    // 0xbebd40: StoreField: r1->field_77 = r0
    //     0xbebd40: stur            w0, [x1, #0x77]
    // 0xbebd44: ldr             x16, [fp, #0x30]
    // 0xbebd48: stp             x16, x1, [SP, #-0x10]!
    // 0xbebd4c: ldr             x16, [fp, #0x28]
    // 0xbebd50: ldr             lr, [fp, #0x20]
    // 0xbebd54: stp             lr, x16, [SP, #-0x10]!
    // 0xbebd58: ldr             x16, [fp, #0x18]
    // 0xbebd5c: ldr             lr, [fp, #0x10]
    // 0xbebd60: stp             lr, x16, [SP, #-0x10]!
    // 0xbebd64: r0 = _NestedScrollPosition()
    //     0xbebd64: bl              #0xbebd84  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::_NestedScrollPosition
    // 0xbebd68: add             SP, SP, #0x30
    // 0xbebd6c: r0 = Null
    //     0xbebd6c: mov             x0, NULL
    // 0xbebd70: LeaveFrame
    //     0xbebd70: mov             SP, fp
    //     0xbebd74: ldp             fp, lr, [SP], #0x10
    // 0xbebd78: ret
    //     0xbebd78: ret             
    // 0xbebd7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbebd7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbebd80: b               #0xbebd3c
  }
  _ applyNewDimensions(/* No info */) {
    // ** addr: 0xc025f4, size: 0x5c
    // 0xc025f4: EnterFrame
    //     0xc025f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc025f8: mov             fp, SP
    // 0xc025fc: CheckStackOverflow
    //     0xc025fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc02600: cmp             SP, x16
    //     0xc02604: b.ls            #0xc02648
    // 0xc02608: ldr             x16, [fp, #0x10]
    // 0xc0260c: SaveReg r16
    //     0xc0260c: str             x16, [SP, #-8]!
    // 0xc02610: r0 = applyNewDimensions()
    //     0xc02610: bl              #0xc02a40  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::applyNewDimensions
    // 0xc02614: add             SP, SP, #8
    // 0xc02618: ldr             x0, [fp, #0x10]
    // 0xc0261c: LoadField: r1 = r0->field_6f
    //     0xc0261c: ldur            w1, [x0, #0x6f]
    // 0xc02620: DecompressPointer r1
    //     0xc02620: add             x1, x1, HEAP, lsl #32
    // 0xc02624: stp             x0, x1, [SP, #-0x10]!
    // 0xc02628: r4 = const [0, 0x2, 0x2, 0x1, position, 0x1, null]
    //     0xc02628: add             x4, PP, #0x38, lsl #12  ; [pp+0x38270] List(7) [0, 0x2, 0x2, 0x1, "position", 0x1, Null]
    //     0xc0262c: ldr             x4, [x4, #0x270]
    // 0xc02630: r0 = updateCanDrag()
    //     0xc02630: bl              #0xc02650  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::updateCanDrag
    // 0xc02634: add             SP, SP, #0x10
    // 0xc02638: r0 = Null
    //     0xc02638: mov             x0, NULL
    // 0xc0263c: LeaveFrame
    //     0xc0263c: mov             SP, fp
    //     0xc02640: ldp             fp, lr, [SP], #0x10
    // 0xc02644: ret
    //     0xc02644: ret             
    // 0xc02648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02648: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0264c: b               #0xc02608
  }
  _ drag(/* No info */) {
    // ** addr: 0xc435d8, size: 0x84
    // 0xc435d8: EnterFrame
    //     0xc435d8: stp             fp, lr, [SP, #-0x10]!
    //     0xc435dc: mov             fp, SP
    // 0xc435e0: AllocStack(0x8)
    //     0xc435e0: sub             SP, SP, #8
    // 0xc435e4: CheckStackOverflow
    //     0xc435e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc435e8: cmp             SP, x16
    //     0xc435ec: b.ls            #0xc43654
    // 0xc435f0: r1 = 2
    //     0xc435f0: mov             x1, #2
    // 0xc435f4: r0 = AllocateContext()
    //     0xc435f4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc435f8: mov             x1, x0
    // 0xc435fc: ldr             x0, [fp, #0x20]
    // 0xc43600: StoreField: r1->field_f = r0
    //     0xc43600: stur            w0, [x1, #0xf]
    // 0xc43604: ldr             x2, [fp, #0x10]
    // 0xc43608: StoreField: r1->field_13 = r2
    //     0xc43608: stur            w2, [x1, #0x13]
    // 0xc4360c: r2 = true
    //     0xc4360c: add             x2, NULL, #0x20  ; true
    // 0xc43610: StoreField: r0->field_77 = r2
    //     0xc43610: stur            w2, [x0, #0x77]
    // 0xc43614: LoadField: r3 = r0->field_6f
    //     0xc43614: ldur            w3, [x0, #0x6f]
    // 0xc43618: DecompressPointer r3
    //     0xc43618: add             x3, x3, HEAP, lsl #32
    // 0xc4361c: mov             x2, x1
    // 0xc43620: stur            x3, [fp, #-8]
    // 0xc43624: r1 = Function '<anonymous closure>':.
    //     0xc43624: add             x1, PP, #0x51, lsl #12  ; [pp+0x511f0] AnonymousClosure: (0xc437b4), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollPosition::drag (0xc435d8)
    //     0xc43628: ldr             x1, [x1, #0x1f0]
    // 0xc4362c: r0 = AllocateClosure()
    //     0xc4362c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc43630: ldur            x16, [fp, #-8]
    // 0xc43634: ldr             lr, [fp, #0x18]
    // 0xc43638: stp             lr, x16, [SP, #-0x10]!
    // 0xc4363c: SaveReg r0
    //     0xc4363c: str             x0, [SP, #-8]!
    // 0xc43640: r0 = drag()
    //     0xc43640: bl              #0xc4365c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::drag
    // 0xc43644: add             SP, SP, #0x18
    // 0xc43648: LeaveFrame
    //     0xc43648: mov             SP, fp
    //     0xc4364c: ldp             fp, lr, [SP], #0x10
    // 0xc43650: ret
    //     0xc43650: ret             
    // 0xc43654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43654: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc43658: b               #0xc435f0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc437b4, size: 0x7c
    // 0xc437b4: EnterFrame
    //     0xc437b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc437b8: mov             fp, SP
    // 0xc437bc: AllocStack(0x8)
    //     0xc437bc: sub             SP, SP, #8
    // 0xc437c0: SetupParameters()
    //     0xc437c0: ldr             x0, [fp, #0x10]
    //     0xc437c4: ldur            w1, [x0, #0x17]
    //     0xc437c8: add             x1, x1, HEAP, lsl #32
    //     0xc437cc: stur            x1, [fp, #-8]
    // 0xc437d0: CheckStackOverflow
    //     0xc437d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc437d4: cmp             SP, x16
    //     0xc437d8: b.ls            #0xc43824
    // 0xc437dc: LoadField: r0 = r1->field_13
    //     0xc437dc: ldur            w0, [x1, #0x13]
    // 0xc437e0: DecompressPointer r0
    //     0xc437e0: add             x0, x0, HEAP, lsl #32
    // 0xc437e4: cmp             w0, NULL
    // 0xc437e8: b.eq            #0xc4382c
    // 0xc437ec: SaveReg r0
    //     0xc437ec: str             x0, [SP, #-8]!
    // 0xc437f0: ClosureCall
    //     0xc437f0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xc437f4: ldur            x2, [x0, #0x1f]
    //     0xc437f8: blr             x2
    // 0xc437fc: add             SP, SP, #8
    // 0xc43800: ldur            x1, [fp, #-8]
    // 0xc43804: LoadField: r2 = r1->field_f
    //     0xc43804: ldur            w2, [x1, #0xf]
    // 0xc43808: DecompressPointer r2
    //     0xc43808: add             x2, x2, HEAP, lsl #32
    // 0xc4380c: r1 = false
    //     0xc4380c: add             x1, NULL, #0x30  ; false
    // 0xc43810: StoreField: r2->field_77 = r1
    //     0xc43810: stur            w1, [x2, #0x77]
    // 0xc43814: r0 = Null
    //     0xc43814: mov             x0, NULL
    // 0xc43818: LeaveFrame
    //     0xc43818: mov             SP, fp
    //     0xc4381c: ldp             fp, lr, [SP], #0x10
    // 0xc43820: ret
    //     0xc43820: ret             
    // 0xc43824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43824: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc43828: b               #0xc437dc
    // 0xc4382c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc4382c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ applyContentDimensions(/* No info */) {
    // ** addr: 0xc74258, size: 0x7c
    // 0xc74258: EnterFrame
    //     0xc74258: stp             fp, lr, [SP, #-0x10]!
    //     0xc7425c: mov             fp, SP
    // 0xc74260: CheckStackOverflow
    //     0xc74260: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc74264: cmp             SP, x16
    //     0xc74268: b.ls            #0xc742cc
    // 0xc7426c: ldr             x1, [fp, #0x20]
    // 0xc74270: LoadField: r0 = r1->field_2f
    //     0xc74270: ldur            w0, [x1, #0x2f]
    // 0xc74274: DecompressPointer r0
    //     0xc74274: add             x0, x0, HEAP, lsl #32
    // 0xc74278: r2 = LoadClassIdInstr(r0)
    //     0xc74278: ldur            x2, [x0, #-1]
    //     0xc7427c: ubfx            x2, x2, #0xc, #0x14
    // 0xc74280: r16 = "outer"
    //     0xc74280: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2eff8] "outer"
    //     0xc74284: ldr             x16, [x16, #0xff8]
    // 0xc74288: stp             x16, x0, [SP, #-0x10]!
    // 0xc7428c: mov             x0, x2
    // 0xc74290: mov             lr, x0
    // 0xc74294: ldr             lr, [x21, lr, lsl #3]
    // 0xc74298: blr             lr
    // 0xc7429c: add             SP, SP, #0x10
    // 0xc742a0: ldr             x16, [fp, #0x20]
    // 0xc742a4: SaveReg r16
    //     0xc742a4: str             x16, [SP, #-8]!
    // 0xc742a8: ldr             d0, [fp, #0x18]
    // 0xc742ac: SaveReg d0
    //     0xc742ac: str             d0, [SP, #-8]!
    // 0xc742b0: ldr             x16, [fp, #0x10]
    // 0xc742b4: SaveReg r16
    //     0xc742b4: str             x16, [SP, #-8]!
    // 0xc742b8: r0 = applyContentDimensions()
    //     0xc742b8: bl              #0xc742d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyContentDimensions
    // 0xc742bc: add             SP, SP, #0x18
    // 0xc742c0: LeaveFrame
    //     0xc742c0: mov             SP, fp
    //     0xc742c4: ldp             fp, lr, [SP], #0x10
    // 0xc742c8: ret
    //     0xc742c8: ret             
    // 0xc742cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc742cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc742d0: b               #0xc7426c
  }
}

// class id: 4857, size: 0x3c, field offset: 0x38
class _NestedScrollController extends ScrollController {

  _ createScrollPosition(/* No info */) {
    // ** addr: 0xbebe4c, size: 0x7c
    // 0xbebe4c: EnterFrame
    //     0xbebe4c: stp             fp, lr, [SP, #-0x10]!
    //     0xbebe50: mov             fp, SP
    // 0xbebe54: AllocStack(0x18)
    //     0xbebe54: sub             SP, SP, #0x18
    // 0xbebe58: CheckStackOverflow
    //     0xbebe58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbebe5c: cmp             SP, x16
    //     0xbebe60: b.ls            #0xbebec0
    // 0xbebe64: ldr             x0, [fp, #0x28]
    // 0xbebe68: LoadField: r1 = r0->field_37
    //     0xbebe68: ldur            w1, [x0, #0x37]
    // 0xbebe6c: DecompressPointer r1
    //     0xbebe6c: add             x1, x1, HEAP, lsl #32
    // 0xbebe70: stur            x1, [fp, #-0x10]
    // 0xbebe74: LoadField: r2 = r0->field_2f
    //     0xbebe74: ldur            w2, [x0, #0x2f]
    // 0xbebe78: DecompressPointer r2
    //     0xbebe78: add             x2, x2, HEAP, lsl #32
    // 0xbebe7c: stur            x2, [fp, #-8]
    // 0xbebe80: r0 = _NestedScrollPosition()
    //     0xbebe80: bl              #0xbebec8  ; Allocate_NestedScrollPositionStub -> _NestedScrollPosition (size=0x78)
    // 0xbebe84: stur            x0, [fp, #-0x18]
    // 0xbebe88: ldr             x16, [fp, #0x18]
    // 0xbebe8c: stp             x16, x0, [SP, #-0x10]!
    // 0xbebe90: ldur            x16, [fp, #-0x10]
    // 0xbebe94: ldur            lr, [fp, #-8]
    // 0xbebe98: stp             lr, x16, [SP, #-0x10]!
    // 0xbebe9c: ldr             x16, [fp, #0x10]
    // 0xbebea0: ldr             lr, [fp, #0x20]
    // 0xbebea4: stp             lr, x16, [SP, #-0x10]!
    // 0xbebea8: r0 = _NestedScrollPosition()
    //     0xbebea8: bl              #0xbebd84  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::_NestedScrollPosition
    // 0xbebeac: add             SP, SP, #0x30
    // 0xbebeb0: ldur            x0, [fp, #-0x18]
    // 0xbebeb4: LeaveFrame
    //     0xbebeb4: mov             SP, fp
    //     0xbebeb8: ldp             fp, lr, [SP], #0x10
    // 0xbebebc: ret
    //     0xbebebc: ret             
    // 0xbebec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbebec0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbebec4: b               #0xbebe64
  }
  _ _scheduleUpdateShadow(/* No info */) {
    // ** addr: 0xc48dd8, size: 0x144
    // 0xc48dd8: EnterFrame
    //     0xc48dd8: stp             fp, lr, [SP, #-0x10]!
    //     0xc48ddc: mov             fp, SP
    // 0xc48de0: AllocStack(0x18)
    //     0xc48de0: sub             SP, SP, #0x18
    // 0xc48de4: CheckStackOverflow
    //     0xc48de4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc48de8: cmp             SP, x16
    //     0xc48dec: b.ls            #0xc48f0c
    // 0xc48df0: r1 = 1
    //     0xc48df0: mov             x1, #1
    // 0xc48df4: r0 = AllocateContext()
    //     0xc48df4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc48df8: mov             x1, x0
    // 0xc48dfc: ldr             x0, [fp, #0x10]
    // 0xc48e00: StoreField: r1->field_f = r0
    //     0xc48e00: stur            w0, [x1, #0xf]
    // 0xc48e04: r0 = LoadStaticField(0xf10)
    //     0xc48e04: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc48e08: ldr             x0, [x0, #0x1e20]
    // 0xc48e0c: cmp             w0, NULL
    // 0xc48e10: b.eq            #0xc48f14
    // 0xc48e14: LoadField: r3 = r0->field_57
    //     0xc48e14: ldur            w3, [x0, #0x57]
    // 0xc48e18: DecompressPointer r3
    //     0xc48e18: add             x3, x3, HEAP, lsl #32
    // 0xc48e1c: stur            x3, [fp, #-0x10]
    // 0xc48e20: LoadField: r0 = r3->field_7
    //     0xc48e20: ldur            w0, [x3, #7]
    // 0xc48e24: DecompressPointer r0
    //     0xc48e24: add             x0, x0, HEAP, lsl #32
    // 0xc48e28: mov             x2, x1
    // 0xc48e2c: stur            x0, [fp, #-8]
    // 0xc48e30: r1 = Function '<anonymous closure>':.
    //     0xc48e30: add             x1, PP, #0x38, lsl #12  ; [pp+0x38208] AnonymousClosure: (0xc48f1c), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollController::_scheduleUpdateShadow (0xc48dd8)
    //     0xc48e34: ldr             x1, [x1, #0x208]
    // 0xc48e38: r0 = AllocateClosure()
    //     0xc48e38: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc48e3c: ldur            x2, [fp, #-8]
    // 0xc48e40: mov             x3, x0
    // 0xc48e44: r1 = Null
    //     0xc48e44: mov             x1, NULL
    // 0xc48e48: stur            x3, [fp, #-8]
    // 0xc48e4c: cmp             w2, NULL
    // 0xc48e50: b.eq            #0xc48e70
    // 0xc48e54: LoadField: r4 = r2->field_17
    //     0xc48e54: ldur            w4, [x2, #0x17]
    // 0xc48e58: DecompressPointer r4
    //     0xc48e58: add             x4, x4, HEAP, lsl #32
    // 0xc48e5c: r8 = X0
    //     0xc48e5c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc48e60: LoadField: r9 = r4->field_7
    //     0xc48e60: ldur            x9, [x4, #7]
    // 0xc48e64: r3 = Null
    //     0xc48e64: add             x3, PP, #0x38, lsl #12  ; [pp+0x38210] Null
    //     0xc48e68: ldr             x3, [x3, #0x210]
    // 0xc48e6c: blr             x9
    // 0xc48e70: ldur            x0, [fp, #-0x10]
    // 0xc48e74: LoadField: r1 = r0->field_b
    //     0xc48e74: ldur            w1, [x0, #0xb]
    // 0xc48e78: DecompressPointer r1
    //     0xc48e78: add             x1, x1, HEAP, lsl #32
    // 0xc48e7c: stur            x1, [fp, #-0x18]
    // 0xc48e80: LoadField: r2 = r0->field_f
    //     0xc48e80: ldur            w2, [x0, #0xf]
    // 0xc48e84: DecompressPointer r2
    //     0xc48e84: add             x2, x2, HEAP, lsl #32
    // 0xc48e88: LoadField: r3 = r2->field_b
    //     0xc48e88: ldur            w3, [x2, #0xb]
    // 0xc48e8c: DecompressPointer r3
    //     0xc48e8c: add             x3, x3, HEAP, lsl #32
    // 0xc48e90: cmp             w1, w3
    // 0xc48e94: b.ne            #0xc48ea4
    // 0xc48e98: SaveReg r0
    //     0xc48e98: str             x0, [SP, #-8]!
    // 0xc48e9c: r0 = _growToNextCapacity()
    //     0xc48e9c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc48ea0: add             SP, SP, #8
    // 0xc48ea4: ldur            x2, [fp, #-0x10]
    // 0xc48ea8: ldur            x3, [fp, #-0x18]
    // 0xc48eac: r4 = LoadInt32Instr(r3)
    //     0xc48eac: sbfx            x4, x3, #1, #0x1f
    // 0xc48eb0: add             x0, x4, #1
    // 0xc48eb4: lsl             x3, x0, #1
    // 0xc48eb8: StoreField: r2->field_b = r3
    //     0xc48eb8: stur            w3, [x2, #0xb]
    // 0xc48ebc: mov             x1, x4
    // 0xc48ec0: cmp             x1, x0
    // 0xc48ec4: b.hs            #0xc48f18
    // 0xc48ec8: LoadField: r1 = r2->field_f
    //     0xc48ec8: ldur            w1, [x2, #0xf]
    // 0xc48ecc: DecompressPointer r1
    //     0xc48ecc: add             x1, x1, HEAP, lsl #32
    // 0xc48ed0: ldur            x0, [fp, #-8]
    // 0xc48ed4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xc48ed4: add             x25, x1, x4, lsl #2
    //     0xc48ed8: add             x25, x25, #0xf
    //     0xc48edc: str             w0, [x25]
    //     0xc48ee0: tbz             w0, #0, #0xc48efc
    //     0xc48ee4: ldurb           w16, [x1, #-1]
    //     0xc48ee8: ldurb           w17, [x0, #-1]
    //     0xc48eec: and             x16, x17, x16, lsr #2
    //     0xc48ef0: tst             x16, HEAP, lsr #32
    //     0xc48ef4: b.eq            #0xc48efc
    //     0xc48ef8: bl              #0xd67e5c
    // 0xc48efc: r0 = Null
    //     0xc48efc: mov             x0, NULL
    // 0xc48f00: LeaveFrame
    //     0xc48f00: mov             SP, fp
    //     0xc48f04: ldp             fp, lr, [SP], #0x10
    // 0xc48f08: ret
    //     0xc48f08: ret             
    // 0xc48f0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc48f0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc48f10: b               #0xc48df0
    // 0xc48f14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc48f14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc48f18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc48f18: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0xc48f1c, size: 0x6c
    // 0xc48f1c: EnterFrame
    //     0xc48f1c: stp             fp, lr, [SP, #-0x10]!
    //     0xc48f20: mov             fp, SP
    // 0xc48f24: ldr             x0, [fp, #0x18]
    // 0xc48f28: LoadField: r1 = r0->field_17
    //     0xc48f28: ldur            w1, [x0, #0x17]
    // 0xc48f2c: DecompressPointer r1
    //     0xc48f2c: add             x1, x1, HEAP, lsl #32
    // 0xc48f30: CheckStackOverflow
    //     0xc48f30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc48f34: cmp             SP, x16
    //     0xc48f38: b.ls            #0xc48f80
    // 0xc48f3c: LoadField: r0 = r1->field_f
    //     0xc48f3c: ldur            w0, [x1, #0xf]
    // 0xc48f40: DecompressPointer r0
    //     0xc48f40: add             x0, x0, HEAP, lsl #32
    // 0xc48f44: r1 = LoadClassIdInstr(r0)
    //     0xc48f44: ldur            x1, [x0, #-1]
    //     0xc48f48: ubfx            x1, x1, #0xc, #0x14
    // 0xc48f4c: SaveReg r0
    //     0xc48f4c: str             x0, [SP, #-8]!
    // 0xc48f50: mov             x0, x1
    // 0xc48f54: r0 = GDT[cid_x0 + -0xffe]()
    //     0xc48f54: sub             lr, x0, #0xffe
    //     0xc48f58: ldr             lr, [x21, lr, lsl #3]
    //     0xc48f5c: blr             lr
    // 0xc48f60: add             SP, SP, #8
    // 0xc48f64: SaveReg r0
    //     0xc48f64: str             x0, [SP, #-8]!
    // 0xc48f68: r0 = cancel()
    //     0xc48f68: bl              #0x540888  ; [dart:io] ConnectionTask::cancel
    // 0xc48f6c: add             SP, SP, #8
    // 0xc48f70: r0 = Null
    //     0xc48f70: mov             x0, NULL
    // 0xc48f74: LeaveFrame
    //     0xc48f74: mov             SP, fp
    //     0xc48f78: ldp             fp, lr, [SP], #0x10
    // 0xc48f7c: ret
    //     0xc48f7c: ret             
    // 0xc48f80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc48f80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc48f84: b               #0xc48f3c
  }
  [closure] void _scheduleUpdateShadow(dynamic) {
    // ** addr: 0xc48f88, size: 0x48
    // 0xc48f88: EnterFrame
    //     0xc48f88: stp             fp, lr, [SP, #-0x10]!
    //     0xc48f8c: mov             fp, SP
    // 0xc48f90: ldr             x0, [fp, #0x10]
    // 0xc48f94: LoadField: r1 = r0->field_17
    //     0xc48f94: ldur            w1, [x0, #0x17]
    // 0xc48f98: DecompressPointer r1
    //     0xc48f98: add             x1, x1, HEAP, lsl #32
    // 0xc48f9c: CheckStackOverflow
    //     0xc48f9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc48fa0: cmp             SP, x16
    //     0xc48fa4: b.ls            #0xc48fc8
    // 0xc48fa8: LoadField: r0 = r1->field_f
    //     0xc48fa8: ldur            w0, [x1, #0xf]
    // 0xc48fac: DecompressPointer r0
    //     0xc48fac: add             x0, x0, HEAP, lsl #32
    // 0xc48fb0: SaveReg r0
    //     0xc48fb0: str             x0, [SP, #-8]!
    // 0xc48fb4: r0 = _scheduleUpdateShadow()
    //     0xc48fb4: bl              #0xc48dd8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollController::_scheduleUpdateShadow
    // 0xc48fb8: add             SP, SP, #8
    // 0xc48fbc: LeaveFrame
    //     0xc48fbc: mov             SP, fp
    //     0xc48fc0: ldp             fp, lr, [SP], #0x10
    // 0xc48fc4: ret
    //     0xc48fc4: ret             
    // 0xc48fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc48fc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc48fcc: b               #0xc48fa8
  }
  _ attach(/* No info */) {
    // ** addr: 0xc48fd0, size: 0xdc
    // 0xc48fd0: EnterFrame
    //     0xc48fd0: stp             fp, lr, [SP, #-0x10]!
    //     0xc48fd4: mov             fp, SP
    // 0xc48fd8: AllocStack(0x8)
    //     0xc48fd8: sub             SP, SP, #8
    // 0xc48fdc: CheckStackOverflow
    //     0xc48fdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc48fe0: cmp             SP, x16
    //     0xc48fe4: b.ls            #0xc490a4
    // 0xc48fe8: ldr             x16, [fp, #0x18]
    // 0xc48fec: ldr             lr, [fp, #0x10]
    // 0xc48ff0: stp             lr, x16, [SP, #-0x10]!
    // 0xc48ff4: r0 = attach()
    //     0xc48ff4: bl              #0xc49460  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::attach
    // 0xc48ff8: add             SP, SP, #0x10
    // 0xc48ffc: ldr             x0, [fp, #0x18]
    // 0xc49000: r1 = LoadClassIdInstr(r0)
    //     0xc49000: ldur            x1, [x0, #-1]
    //     0xc49004: ubfx            x1, x1, #0xc, #0x14
    // 0xc49008: lsl             x1, x1, #1
    // 0xc4900c: r17 = 9714
    //     0xc4900c: mov             x17, #0x25f2
    // 0xc49010: cmp             w1, w17
    // 0xc49014: b.ne            #0xc49024
    // 0xc49018: LoadField: r1 = r0->field_37
    //     0xc49018: ldur            w1, [x0, #0x37]
    // 0xc4901c: DecompressPointer r1
    //     0xc4901c: add             x1, x1, HEAP, lsl #32
    // 0xc49020: b               #0xc4902c
    // 0xc49024: LoadField: r1 = r0->field_37
    //     0xc49024: ldur            w1, [x0, #0x37]
    // 0xc49028: DecompressPointer r1
    //     0xc49028: add             x1, x1, HEAP, lsl #32
    // 0xc4902c: stur            x1, [fp, #-8]
    // 0xc49030: SaveReg r1
    //     0xc49030: str             x1, [SP, #-8]!
    // 0xc49034: r0 = updateParent()
    //     0xc49034: bl              #0xa6035c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::updateParent
    // 0xc49038: add             SP, SP, #8
    // 0xc4903c: ldur            x16, [fp, #-8]
    // 0xc49040: SaveReg r16
    //     0xc49040: str             x16, [SP, #-8]!
    // 0xc49044: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc49044: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc49048: r0 = updateCanDrag()
    //     0xc49048: bl              #0xc02650  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::updateCanDrag
    // 0xc4904c: add             SP, SP, #8
    // 0xc49050: r1 = 1
    //     0xc49050: mov             x1, #1
    // 0xc49054: r0 = AllocateContext()
    //     0xc49054: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc49058: mov             x1, x0
    // 0xc4905c: ldr             x0, [fp, #0x18]
    // 0xc49060: StoreField: r1->field_f = r0
    //     0xc49060: stur            w0, [x1, #0xf]
    // 0xc49064: mov             x2, x1
    // 0xc49068: r1 = Function '_scheduleUpdateShadow@454231548':.
    //     0xc49068: add             x1, PP, #0x38, lsl #12  ; [pp+0x38200] AnonymousClosure: (0xc48f88), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollController::_scheduleUpdateShadow (0xc48dd8)
    //     0xc4906c: ldr             x1, [x1, #0x200]
    // 0xc49070: r0 = AllocateClosure()
    //     0xc49070: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc49074: ldr             x16, [fp, #0x10]
    // 0xc49078: stp             x0, x16, [SP, #-0x10]!
    // 0xc4907c: r0 = addListener()
    //     0xc4907c: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xc49080: add             SP, SP, #0x10
    // 0xc49084: ldr             x16, [fp, #0x18]
    // 0xc49088: SaveReg r16
    //     0xc49088: str             x16, [SP, #-8]!
    // 0xc4908c: r0 = _scheduleUpdateShadow()
    //     0xc4908c: bl              #0xc48dd8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollController::_scheduleUpdateShadow
    // 0xc49090: add             SP, SP, #8
    // 0xc49094: r0 = Null
    //     0xc49094: mov             x0, NULL
    // 0xc49098: LeaveFrame
    //     0xc49098: mov             SP, fp
    //     0xc4909c: ldp             fp, lr, [SP], #0x10
    // 0xc490a0: ret
    //     0xc490a0: ret             
    // 0xc490a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc490a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc490a8: b               #0xc48fe8
  }
  _ detach(/* No info */) {
    // ** addr: 0xc49564, size: 0xcc
    // 0xc49564: EnterFrame
    //     0xc49564: stp             fp, lr, [SP, #-0x10]!
    //     0xc49568: mov             fp, SP
    // 0xc4956c: CheckStackOverflow
    //     0xc4956c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc49570: cmp             SP, x16
    //     0xc49574: b.ls            #0xc49628
    // 0xc49578: ldr             x0, [fp, #0x10]
    // 0xc4957c: r2 = Null
    //     0xc4957c: mov             x2, NULL
    // 0xc49580: r1 = Null
    //     0xc49580: mov             x1, NULL
    // 0xc49584: r4 = LoadClassIdInstr(r0)
    //     0xc49584: ldur            x4, [x0, #-1]
    //     0xc49588: ubfx            x4, x4, #0xc, #0x14
    // 0xc4958c: r17 = -4844
    //     0xc4958c: mov             x17, #-0x12ec
    // 0xc49590: add             x4, x4, x17
    // 0xc49594: cmp             x4, #1
    // 0xc49598: b.ls            #0xc495b0
    // 0xc4959c: r8 = _NestedScrollPosition
    //     0xc4959c: add             x8, PP, #0x38, lsl #12  ; [pp+0x381e8] Type: _NestedScrollPosition
    //     0xc495a0: ldr             x8, [x8, #0x1e8]
    // 0xc495a4: r3 = Null
    //     0xc495a4: add             x3, PP, #0x38, lsl #12  ; [pp+0x381f0] Null
    //     0xc495a8: ldr             x3, [x3, #0x1f0]
    // 0xc495ac: r0 = _NestedScrollPosition()
    //     0xc495ac: bl              #0x7d2824  ; IsType__NestedScrollPosition_Stub
    // 0xc495b0: ldr             x16, [fp, #0x10]
    // 0xc495b4: stp             NULL, x16, [SP, #-0x10]!
    // 0xc495b8: r0 = setParent()
    //     0xc495b8: bl              #0x7d2778  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollPosition::setParent
    // 0xc495bc: add             SP, SP, #0x10
    // 0xc495c0: r1 = 1
    //     0xc495c0: mov             x1, #1
    // 0xc495c4: r0 = AllocateContext()
    //     0xc495c4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc495c8: mov             x1, x0
    // 0xc495cc: ldr             x0, [fp, #0x18]
    // 0xc495d0: StoreField: r1->field_f = r0
    //     0xc495d0: stur            w0, [x1, #0xf]
    // 0xc495d4: mov             x2, x1
    // 0xc495d8: r1 = Function '_scheduleUpdateShadow@454231548':.
    //     0xc495d8: add             x1, PP, #0x38, lsl #12  ; [pp+0x38200] AnonymousClosure: (0xc48f88), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollController::_scheduleUpdateShadow (0xc48dd8)
    //     0xc495dc: ldr             x1, [x1, #0x200]
    // 0xc495e0: r0 = AllocateClosure()
    //     0xc495e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc495e4: ldr             x16, [fp, #0x10]
    // 0xc495e8: stp             x0, x16, [SP, #-0x10]!
    // 0xc495ec: r0 = removeListener()
    //     0xc495ec: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xc495f0: add             SP, SP, #0x10
    // 0xc495f4: ldr             x16, [fp, #0x18]
    // 0xc495f8: ldr             lr, [fp, #0x10]
    // 0xc495fc: stp             lr, x16, [SP, #-0x10]!
    // 0xc49600: r0 = detach()
    //     0xc49600: bl              #0xc49a38  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::detach
    // 0xc49604: add             SP, SP, #0x10
    // 0xc49608: ldr             x16, [fp, #0x18]
    // 0xc4960c: SaveReg r16
    //     0xc4960c: str             x16, [SP, #-8]!
    // 0xc49610: r0 = _scheduleUpdateShadow()
    //     0xc49610: bl              #0xc48dd8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollController::_scheduleUpdateShadow
    // 0xc49614: add             SP, SP, #8
    // 0xc49618: r0 = Null
    //     0xc49618: mov             x0, NULL
    // 0xc4961c: LeaveFrame
    //     0xc4961c: mov             SP, fp
    //     0xc49620: ldp             fp, lr, [SP], #0x10
    // 0xc49624: ret
    //     0xc49624: ret             
    // 0xc49628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc49628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4962c: b               #0xc49578
  }
  const get _ coordinator(/* No info */) {
    // ** addr: 0xcb1138, size: 0x10
    // 0xcb1138: ldr             x1, [SP]
    // 0xcb113c: LoadField: r0 = r1->field_37
    //     0xcb113c: ldur            w0, [x1, #0x37]
    // 0xcb1140: DecompressPointer r0
    //     0xcb1140: add             x0, x0, HEAP, lsl #32
    // 0xcb1144: ret
    //     0xcb1144: ret             
  }
}

// class id: 4858, size: 0x3c, field offset: 0x3c
class _ExtendedNestedScrollController extends _NestedScrollController {

  get _ _releaseNestedPositions(/* No info */) {
    // ** addr: 0x831a40, size: 0xbc
    // 0x831a40: EnterFrame
    //     0x831a40: stp             fp, lr, [SP, #-0x10]!
    //     0x831a44: mov             fp, SP
    // 0x831a48: AllocStack(0x18)
    //     0x831a48: sub             SP, SP, #0x18
    // 0x831a4c: SetupParameters(_ExtendedNestedScrollController this /* r2, fp-0x10 */)
    //     0x831a4c: stur            NULL, [fp, #-8]
    //     0x831a50: mov             x1, #0
    //     0x831a54: add             x2, fp, w1, sxtw #2
    //     0x831a58: ldr             x2, [x2, #0x10]
    //     0x831a5c: stur            x2, [fp, #-0x10]
    // 0x831a60: CheckStackOverflow
    //     0x831a60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x831a64: cmp             SP, x16
    //     0x831a68: b.ls            #0x831af4
    // 0x831a6c: InitAsync() -> Future<_ExtendedNestedScrollPosition>
    //     0x831a6c: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2eef0] TypeArguments: <_ExtendedNestedScrollPosition>
    //     0x831a70: ldr             x0, [x0, #0xef0]
    //     0x831a74: bl              #0x505ad0
    // 0x831a78: r0 = Null
    //     0x831a78: mov             x0, NULL
    // 0x831a7c: r0 = SuspendSyncStarAtStart()
    //     0x831a7c: bl              #0x505954  ; SuspendSyncStarAtStartStub
    // 0x831a80: r0 = 0
    //     0x831a80: mov             x0, #0
    // 0x831a84: add             x1, fp, w0, sxtw #2
    // 0x831a88: LoadField: r1 = r1->field_fffffff8
    //     0x831a88: ldur            x1, [x1, #-8]
    // 0x831a8c: LoadField: r0 = r1->field_17
    //     0x831a8c: ldur            w0, [x1, #0x17]
    // 0x831a90: DecompressPointer r0
    //     0x831a90: add             x0, x0, HEAP, lsl #32
    // 0x831a94: ldur            x1, [fp, #-0x10]
    // 0x831a98: stur            x0, [fp, #-0x18]
    // 0x831a9c: LoadField: r2 = r1->field_33
    //     0x831a9c: ldur            w2, [x1, #0x33]
    // 0x831aa0: DecompressPointer r2
    //     0x831aa0: add             x2, x2, HEAP, lsl #32
    // 0x831aa4: r16 = <_ExtendedNestedScrollPosition, ScrollPosition, _ExtendedNestedScrollPosition>
    //     0x831aa4: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2efa0] TypeArguments: <_ExtendedNestedScrollPosition, ScrollPosition, _ExtendedNestedScrollPosition>
    //     0x831aa8: ldr             x16, [x16, #0xfa0]
    // 0x831aac: stp             x2, x16, [SP, #-0x10]!
    // 0x831ab0: r0 = CastIterable()
    //     0x831ab0: bl              #0x4c0874  ; [dart:_internal] CastIterable::CastIterable
    // 0x831ab4: add             SP, SP, #0x10
    // 0x831ab8: ldur            x1, [fp, #-0x18]
    // 0x831abc: StoreField: r1->field_1b = r0
    //     0x831abc: stur            w0, [x1, #0x1b]
    //     0x831ac0: tbz             w0, #0, #0x831adc
    //     0x831ac4: ldurb           w16, [x1, #-1]
    //     0x831ac8: ldurb           w17, [x0, #-1]
    //     0x831acc: and             x16, x17, x16, lsr #2
    //     0x831ad0: tst             x16, HEAP, lsr #32
    //     0x831ad4: b.eq            #0x831adc
    //     0x831ad8: bl              #0xd6826c
    // 0x831adc: r0 = true
    //     0x831adc: add             x0, NULL, #0x20  ; true
    // 0x831ae0: r0 = SuspendSyncStarAtYield()
    //     0x831ae0: bl              #0x5057dc  ; SuspendSyncStarAtYieldStub
    // 0x831ae4: r0 = false
    //     0x831ae4: add             x0, NULL, #0x30  ; false
    // 0x831ae8: LeaveFrame
    //     0x831ae8: mov             SP, fp
    //     0x831aec: ldp             fp, lr, [SP], #0x10
    // 0x831af0: ret
    //     0x831af0: ret             
    // 0x831af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x831af4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x831af8: b               #0x831a6c
  }
  _ createScrollPosition(/* No info */) {
    // ** addr: 0xbebca8, size: 0x7c
    // 0xbebca8: EnterFrame
    //     0xbebca8: stp             fp, lr, [SP, #-0x10]!
    //     0xbebcac: mov             fp, SP
    // 0xbebcb0: AllocStack(0x18)
    //     0xbebcb0: sub             SP, SP, #0x18
    // 0xbebcb4: CheckStackOverflow
    //     0xbebcb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbebcb8: cmp             SP, x16
    //     0xbebcbc: b.ls            #0xbebd1c
    // 0xbebcc0: ldr             x0, [fp, #0x28]
    // 0xbebcc4: LoadField: r1 = r0->field_37
    //     0xbebcc4: ldur            w1, [x0, #0x37]
    // 0xbebcc8: DecompressPointer r1
    //     0xbebcc8: add             x1, x1, HEAP, lsl #32
    // 0xbebccc: stur            x1, [fp, #-0x10]
    // 0xbebcd0: LoadField: r2 = r0->field_2f
    //     0xbebcd0: ldur            w2, [x0, #0x2f]
    // 0xbebcd4: DecompressPointer r2
    //     0xbebcd4: add             x2, x2, HEAP, lsl #32
    // 0xbebcd8: stur            x2, [fp, #-8]
    // 0xbebcdc: r0 = _ExtendedNestedScrollPosition()
    //     0xbebcdc: bl              #0xbebe40  ; Allocate_ExtendedNestedScrollPositionStub -> _ExtendedNestedScrollPosition (size=0x7c)
    // 0xbebce0: stur            x0, [fp, #-0x18]
    // 0xbebce4: ldr             x16, [fp, #0x18]
    // 0xbebce8: stp             x16, x0, [SP, #-0x10]!
    // 0xbebcec: ldur            x16, [fp, #-0x10]
    // 0xbebcf0: ldur            lr, [fp, #-8]
    // 0xbebcf4: stp             lr, x16, [SP, #-0x10]!
    // 0xbebcf8: ldr             x16, [fp, #0x10]
    // 0xbebcfc: ldr             lr, [fp, #0x20]
    // 0xbebd00: stp             lr, x16, [SP, #-0x10]!
    // 0xbebd04: r0 = _ExtendedNestedScrollPosition()
    //     0xbebd04: bl              #0xbebd24  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollPosition::_ExtendedNestedScrollPosition
    // 0xbebd08: add             SP, SP, #0x30
    // 0xbebd0c: ldur            x0, [fp, #-0x18]
    // 0xbebd10: LeaveFrame
    //     0xbebd10: mov             SP, fp
    //     0xbebd14: ldp             fp, lr, [SP], #0x10
    // 0xbebd18: ret
    //     0xbebd18: ret             
    // 0xbebd1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbebd1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbebd20: b               #0xbebcc0
  }
  _ attach(/* No info */) {
    // ** addr: 0xc48ce0, size: 0xf8
    // 0xc48ce0: EnterFrame
    //     0xc48ce0: stp             fp, lr, [SP, #-0x10]!
    //     0xc48ce4: mov             fp, SP
    // 0xc48ce8: AllocStack(0x8)
    //     0xc48ce8: sub             SP, SP, #8
    // 0xc48cec: CheckStackOverflow
    //     0xc48cec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc48cf0: cmp             SP, x16
    //     0xc48cf4: b.ls            #0xc48dd0
    // 0xc48cf8: ldr             x16, [fp, #0x18]
    // 0xc48cfc: ldr             lr, [fp, #0x10]
    // 0xc48d00: stp             lr, x16, [SP, #-0x10]!
    // 0xc48d04: r0 = attach()
    //     0xc48d04: bl              #0xc48fd0  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollController::attach
    // 0xc48d08: add             SP, SP, #0x10
    // 0xc48d0c: ldr             x0, [fp, #0x18]
    // 0xc48d10: LoadField: r1 = r0->field_37
    //     0xc48d10: ldur            w1, [x0, #0x37]
    // 0xc48d14: DecompressPointer r1
    //     0xc48d14: add             x1, x1, HEAP, lsl #32
    // 0xc48d18: stur            x1, [fp, #-8]
    // 0xc48d1c: SaveReg r1
    //     0xc48d1c: str             x1, [SP, #-8]!
    // 0xc48d20: r0 = updateParent()
    //     0xc48d20: bl              #0xa6035c  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollCoordinator::updateParent
    // 0xc48d24: add             SP, SP, #8
    // 0xc48d28: ldr             x0, [fp, #0x10]
    // 0xc48d2c: r2 = Null
    //     0xc48d2c: mov             x2, NULL
    // 0xc48d30: r1 = Null
    //     0xc48d30: mov             x1, NULL
    // 0xc48d34: r4 = LoadClassIdInstr(r0)
    //     0xc48d34: ldur            x4, [x0, #-1]
    //     0xc48d38: ubfx            x4, x4, #0xc, #0x14
    // 0xc48d3c: r17 = -4844
    //     0xc48d3c: mov             x17, #-0x12ec
    // 0xc48d40: add             x4, x4, x17
    // 0xc48d44: cmp             x4, #1
    // 0xc48d48: b.ls            #0xc48d60
    // 0xc48d4c: r8 = _NestedScrollPosition
    //     0xc48d4c: add             x8, PP, #0x38, lsl #12  ; [pp+0x381e8] Type: _NestedScrollPosition
    //     0xc48d50: ldr             x8, [x8, #0x1e8]
    // 0xc48d54: r3 = Null
    //     0xc48d54: add             x3, PP, #0x38, lsl #12  ; [pp+0x38260] Null
    //     0xc48d58: ldr             x3, [x3, #0x260]
    // 0xc48d5c: r0 = _NestedScrollPosition()
    //     0xc48d5c: bl              #0x7d2824  ; IsType__NestedScrollPosition_Stub
    // 0xc48d60: ldur            x16, [fp, #-8]
    // 0xc48d64: ldr             lr, [fp, #0x10]
    // 0xc48d68: stp             lr, x16, [SP, #-0x10]!
    // 0xc48d6c: r4 = const [0, 0x2, 0x2, 0x1, position, 0x1, null]
    //     0xc48d6c: add             x4, PP, #0x38, lsl #12  ; [pp+0x38270] List(7) [0, 0x2, 0x2, 0x1, "position", 0x1, Null]
    //     0xc48d70: ldr             x4, [x4, #0x270]
    // 0xc48d74: r0 = updateCanDrag()
    //     0xc48d74: bl              #0xc02650  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _ExtendedNestedScrollCoordinator::updateCanDrag
    // 0xc48d78: add             SP, SP, #0x10
    // 0xc48d7c: r1 = 1
    //     0xc48d7c: mov             x1, #1
    // 0xc48d80: r0 = AllocateContext()
    //     0xc48d80: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc48d84: mov             x1, x0
    // 0xc48d88: ldr             x0, [fp, #0x18]
    // 0xc48d8c: StoreField: r1->field_f = r0
    //     0xc48d8c: stur            w0, [x1, #0xf]
    // 0xc48d90: mov             x2, x1
    // 0xc48d94: r1 = Function '_scheduleUpdateShadow@454231548':.
    //     0xc48d94: add             x1, PP, #0x38, lsl #12  ; [pp+0x38200] AnonymousClosure: (0xc48f88), in [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollController::_scheduleUpdateShadow (0xc48dd8)
    //     0xc48d98: ldr             x1, [x1, #0x200]
    // 0xc48d9c: r0 = AllocateClosure()
    //     0xc48d9c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc48da0: ldr             x16, [fp, #0x10]
    // 0xc48da4: stp             x0, x16, [SP, #-0x10]!
    // 0xc48da8: r0 = addListener()
    //     0xc48da8: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xc48dac: add             SP, SP, #0x10
    // 0xc48db0: ldr             x16, [fp, #0x18]
    // 0xc48db4: SaveReg r16
    //     0xc48db4: str             x16, [SP, #-8]!
    // 0xc48db8: r0 = _scheduleUpdateShadow()
    //     0xc48db8: bl              #0xc48dd8  ; [package:extended_nested_scroll_view/src/extended_nested_scroll_view.dart] _NestedScrollController::_scheduleUpdateShadow
    // 0xc48dbc: add             SP, SP, #8
    // 0xc48dc0: r0 = Null
    //     0xc48dc0: mov             x0, NULL
    // 0xc48dc4: LeaveFrame
    //     0xc48dc4: mov             SP, fp
    //     0xc48dc8: ldp             fp, lr, [SP], #0x10
    // 0xc48dcc: ret
    //     0xc48dcc: ret             
    // 0xc48dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc48dd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc48dd4: b               #0xc48cf8
  }
}

// class id: 5993, size: 0x14, field offset: 0x14
enum _NestedBallisticScrollActivityMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// lib: , url: package:file/src/backends/local/local_file_system.dart

// class id: 1049030, size: 0x8
class :: {
}

// class id: 4403, size: 0x8, field offset: 0x8
//   const constructor, 
class LocalFileSystem extends FileSystem {

  _ file(/* No info */) {
    // ** addr: 0xc188f4, size: 0xbc
    // 0xc188f4: EnterFrame
    //     0xc188f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc188f8: mov             fp, SP
    // 0xc188fc: AllocStack(0x8)
    //     0xc188fc: sub             SP, SP, #8
    // 0xc18900: CheckStackOverflow
    //     0xc18900: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc18904: cmp             SP, x16
    //     0xc18908: b.ls            #0xc189a8
    // 0xc1890c: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc1890c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc18910: ldr             x0, [x0, #0xb58]
    //     0xc18914: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc18918: cmp             w0, w16
    //     0xc1891c: b.ne            #0xc18928
    //     0xc18920: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc18924: bl              #0xd67d44
    // 0xc18928: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc18928: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc1892c: ldr             x0, [x0, #0xdd8]
    //     0xc18930: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc18934: cmp             w0, w16
    //     0xc18938: b.ne            #0xc18944
    //     0xc1893c: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc18940: bl              #0xd67cdc
    // 0xc18944: r0 = _File()
    //     0xc18944: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xc18948: mov             x1, x0
    // 0xc1894c: ldr             x0, [fp, #0x10]
    // 0xc18950: stur            x1, [fp, #-8]
    // 0xc18954: StoreField: r1->field_7 = r0
    //     0xc18954: stur            w0, [x1, #7]
    // 0xc18958: SaveReg r0
    //     0xc18958: str             x0, [SP, #-8]!
    // 0xc1895c: r0 = _toUtf8Array()
    //     0xc1895c: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc18960: add             SP, SP, #8
    // 0xc18964: ldur            x2, [fp, #-8]
    // 0xc18968: StoreField: r2->field_b = r0
    //     0xc18968: stur            w0, [x2, #0xb]
    //     0xc1896c: ldurb           w16, [x2, #-1]
    //     0xc18970: ldurb           w17, [x0, #-1]
    //     0xc18974: and             x16, x17, x16, lsr #2
    //     0xc18978: tst             x16, HEAP, lsr #32
    //     0xc1897c: b.eq            #0xc18984
    //     0xc18980: bl              #0xd6828c
    // 0xc18984: r1 = <File, File>
    //     0xc18984: ldr             x1, [PP, #0x6b20]  ; [pp+0x6b20] TypeArguments: <File, File>
    // 0xc18988: r0 = LocalFile()
    //     0xc18988: bl              #0xc189b0  ; AllocateLocalFileStub -> LocalFile (size=0x14)
    // 0xc1898c: r1 = Instance_LocalFileSystem
    //     0xc1898c: ldr             x1, [PP, #0x218]  ; [pp+0x218] Obj!LocalFileSystem@b4fce1
    // 0xc18990: StoreField: r0->field_b = r1
    //     0xc18990: stur            w1, [x0, #0xb]
    // 0xc18994: ldur            x1, [fp, #-8]
    // 0xc18998: StoreField: r0->field_f = r1
    //     0xc18998: stur            w1, [x0, #0xf]
    // 0xc1899c: LeaveFrame
    //     0xc1899c: mov             SP, fp
    //     0xc189a0: ldp             fp, lr, [SP], #0x10
    // 0xc189a4: ret
    //     0xc189a4: ret             
    // 0xc189a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc189a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc189ac: b               #0xc1890c
  }
  get _ currentDirectory(/* No info */) {
    // ** addr: 0xc2d3dc, size: 0x44
    // 0xc2d3dc: EnterFrame
    //     0xc2d3dc: stp             fp, lr, [SP, #-0x10]!
    //     0xc2d3e0: mov             fp, SP
    // 0xc2d3e4: CheckStackOverflow
    //     0xc2d3e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2d3e8: cmp             SP, x16
    //     0xc2d3ec: b.ls            #0xc2d418
    // 0xc2d3f0: r0 = current()
    //     0xc2d3f0: bl              #0xc2d4e8  ; [dart:io] Directory::current
    // 0xc2d3f4: LoadField: r1 = r0->field_7
    //     0xc2d3f4: ldur            w1, [x0, #7]
    // 0xc2d3f8: DecompressPointer r1
    //     0xc2d3f8: add             x1, x1, HEAP, lsl #32
    // 0xc2d3fc: ldr             x16, [fp, #0x10]
    // 0xc2d400: stp             x1, x16, [SP, #-0x10]!
    // 0xc2d404: r0 = directory()
    //     0xc2d404: bl              #0xc2d420  ; [package:file/src/backends/local/local_file_system.dart] LocalFileSystem::directory
    // 0xc2d408: add             SP, SP, #0x10
    // 0xc2d40c: LeaveFrame
    //     0xc2d40c: mov             SP, fp
    //     0xc2d410: ldp             fp, lr, [SP], #0x10
    // 0xc2d414: ret
    //     0xc2d414: ret             
    // 0xc2d418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2d418: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2d41c: b               #0xc2d3f0
  }
  _ directory(/* No info */) {
    // ** addr: 0xc2d420, size: 0xbc
    // 0xc2d420: EnterFrame
    //     0xc2d420: stp             fp, lr, [SP, #-0x10]!
    //     0xc2d424: mov             fp, SP
    // 0xc2d428: AllocStack(0x8)
    //     0xc2d428: sub             SP, SP, #8
    // 0xc2d42c: CheckStackOverflow
    //     0xc2d42c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2d430: cmp             SP, x16
    //     0xc2d434: b.ls            #0xc2d4d4
    // 0xc2d438: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc2d438: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc2d43c: ldr             x0, [x0, #0xb58]
    //     0xc2d440: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc2d444: cmp             w0, w16
    //     0xc2d448: b.ne            #0xc2d454
    //     0xc2d44c: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc2d450: bl              #0xd67d44
    // 0xc2d454: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc2d454: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc2d458: ldr             x0, [x0, #0xdd8]
    //     0xc2d45c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc2d460: cmp             w0, w16
    //     0xc2d464: b.ne            #0xc2d470
    //     0xc2d468: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc2d46c: bl              #0xd67cdc
    // 0xc2d470: r0 = _Directory()
    //     0xc2d470: bl              #0x4e1e0c  ; Allocate_DirectoryStub -> _Directory (size=0x10)
    // 0xc2d474: mov             x1, x0
    // 0xc2d478: ldr             x0, [fp, #0x10]
    // 0xc2d47c: stur            x1, [fp, #-8]
    // 0xc2d480: StoreField: r1->field_7 = r0
    //     0xc2d480: stur            w0, [x1, #7]
    // 0xc2d484: SaveReg r0
    //     0xc2d484: str             x0, [SP, #-8]!
    // 0xc2d488: r0 = _toUtf8Array()
    //     0xc2d488: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc2d48c: add             SP, SP, #8
    // 0xc2d490: ldur            x2, [fp, #-8]
    // 0xc2d494: StoreField: r2->field_b = r0
    //     0xc2d494: stur            w0, [x2, #0xb]
    //     0xc2d498: ldurb           w16, [x2, #-1]
    //     0xc2d49c: ldurb           w17, [x0, #-1]
    //     0xc2d4a0: and             x16, x17, x16, lsr #2
    //     0xc2d4a4: tst             x16, HEAP, lsr #32
    //     0xc2d4a8: b.eq            #0xc2d4b0
    //     0xc2d4ac: bl              #0xd6828c
    // 0xc2d4b0: r1 = <LocalDirectory, Directory>
    //     0xc2d4b0: ldr             x1, [PP, #0x6d30]  ; [pp+0x6d30] TypeArguments: <LocalDirectory, Directory>
    // 0xc2d4b4: r0 = LocalDirectory()
    //     0xc2d4b4: bl              #0xc2d4dc  ; AllocateLocalDirectoryStub -> LocalDirectory (size=0x14)
    // 0xc2d4b8: r1 = Instance_LocalFileSystem
    //     0xc2d4b8: ldr             x1, [PP, #0x218]  ; [pp+0x218] Obj!LocalFileSystem@b4fce1
    // 0xc2d4bc: StoreField: r0->field_b = r1
    //     0xc2d4bc: stur            w1, [x0, #0xb]
    // 0xc2d4c0: ldur            x1, [fp, #-8]
    // 0xc2d4c4: StoreField: r0->field_f = r1
    //     0xc2d4c4: stur            w1, [x0, #0xf]
    // 0xc2d4c8: LeaveFrame
    //     0xc2d4c8: mov             SP, fp
    //     0xc2d4cc: ldp             fp, lr, [SP], #0x10
    // 0xc2d4d0: ret
    //     0xc2d4d0: ret             
    // 0xc2d4d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2d4d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2d4d8: b               #0xc2d438
  }
}

// lib: , url: package:file/src/backends/local/local_file_system_entity.dart

// class id: 1049031, size: 0x8
class :: {
}

// class id: 4395, size: 0x14, field offset: 0xc
abstract class LocalFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity> extends ForwardingFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity> {

  _ wrapFile(/* No info */) {
    // ** addr: 0xc94540, size: 0x2c
    // 0xc94540: EnterFrame
    //     0xc94540: stp             fp, lr, [SP, #-0x10]!
    //     0xc94544: mov             fp, SP
    // 0xc94548: r1 = <File, File>
    //     0xc94548: ldr             x1, [PP, #0x6b20]  ; [pp+0x6b20] TypeArguments: <File, File>
    // 0xc9454c: r0 = LocalFile()
    //     0xc9454c: bl              #0xc189b0  ; AllocateLocalFileStub -> LocalFile (size=0x14)
    // 0xc94550: r1 = Instance_LocalFileSystem
    //     0xc94550: ldr             x1, [PP, #0x218]  ; [pp+0x218] Obj!LocalFileSystem@b4fce1
    // 0xc94554: StoreField: r0->field_b = r1
    //     0xc94554: stur            w1, [x0, #0xb]
    // 0xc94558: ldr             x1, [fp, #0x10]
    // 0xc9455c: StoreField: r0->field_f = r1
    //     0xc9455c: stur            w1, [x0, #0xf]
    // 0xc94560: LeaveFrame
    //     0xc94560: mov             SP, fp
    //     0xc94564: ldp             fp, lr, [SP], #0x10
    // 0xc94568: ret
    //     0xc94568: ret             
  }
}

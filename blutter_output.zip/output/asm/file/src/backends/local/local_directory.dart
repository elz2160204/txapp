// lib: , url: package:file/src/backends/local/local_directory.dart

// class id: 1049028, size: 0x8
class :: {
}

// class id: 4398, size: 0x14, field offset: 0x14
//   transformed mixin,
abstract class _LocalDirectory&LocalFileSystemEntity&ForwardingDirectory extends LocalFileSystemEntity<LocalDirectory, Directory>
     with ForwardingDirectory<X0 bound Directory> {
}

// class id: 4399, size: 0x14, field offset: 0x14
//   transformed mixin,
abstract class _LocalDirectory&LocalFileSystemEntity&ForwardingDirectory&DirectoryAddOnsMixin extends _LocalDirectory&LocalFileSystemEntity&ForwardingDirectory
     with DirectoryAddOnsMixin {
}

// class id: 4400, size: 0x14, field offset: 0x14
class LocalDirectory extends _LocalDirectory&LocalFileSystemEntity&ForwardingDirectory&DirectoryAddOnsMixin {

  _ toString(/* No info */) {
    // ** addr: 0xad4230, size: 0xb4
    // 0xad4230: EnterFrame
    //     0xad4230: stp             fp, lr, [SP, #-0x10]!
    //     0xad4234: mov             fp, SP
    // 0xad4238: AllocStack(0x8)
    //     0xad4238: sub             SP, SP, #8
    // 0xad423c: CheckStackOverflow
    //     0xad423c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4240: cmp             SP, x16
    //     0xad4244: b.ls            #0xad42dc
    // 0xad4248: r1 = Null
    //     0xad4248: mov             x1, NULL
    // 0xad424c: r2 = 6
    //     0xad424c: mov             x2, #6
    // 0xad4250: r0 = AllocateArray()
    //     0xad4250: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4254: mov             x1, x0
    // 0xad4258: stur            x1, [fp, #-8]
    // 0xad425c: r17 = "LocalDirectory: \'"
    //     0xad425c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb158] "LocalDirectory: \'"
    //     0xad4260: ldr             x17, [x17, #0x158]
    // 0xad4264: StoreField: r1->field_f = r17
    //     0xad4264: stur            w17, [x1, #0xf]
    // 0xad4268: ldr             x0, [fp, #0x10]
    // 0xad426c: LoadField: r2 = r0->field_f
    //     0xad426c: ldur            w2, [x0, #0xf]
    // 0xad4270: DecompressPointer r2
    //     0xad4270: add             x2, x2, HEAP, lsl #32
    // 0xad4274: r0 = LoadClassIdInstr(r2)
    //     0xad4274: ldur            x0, [x2, #-1]
    //     0xad4278: ubfx            x0, x0, #0xc, #0x14
    // 0xad427c: SaveReg r2
    //     0xad427c: str             x2, [SP, #-8]!
    // 0xad4280: r0 = GDT[cid_x0 + -0xf40]()
    //     0xad4280: sub             lr, x0, #0xf40
    //     0xad4284: ldr             lr, [x21, lr, lsl #3]
    //     0xad4288: blr             lr
    // 0xad428c: add             SP, SP, #8
    // 0xad4290: ldur            x1, [fp, #-8]
    // 0xad4294: ArrayStore: r1[1] = r0  ; List_4
    //     0xad4294: add             x25, x1, #0x13
    //     0xad4298: str             w0, [x25]
    //     0xad429c: tbz             w0, #0, #0xad42b8
    //     0xad42a0: ldurb           w16, [x1, #-1]
    //     0xad42a4: ldurb           w17, [x0, #-1]
    //     0xad42a8: and             x16, x17, x16, lsr #2
    //     0xad42ac: tst             x16, HEAP, lsr #32
    //     0xad42b0: b.eq            #0xad42b8
    //     0xad42b4: bl              #0xd67e5c
    // 0xad42b8: ldur            x0, [fp, #-8]
    // 0xad42bc: r17 = "\'"
    //     0xad42bc: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad42c0: StoreField: r0->field_17 = r17
    //     0xad42c0: stur            w17, [x0, #0x17]
    // 0xad42c4: SaveReg r0
    //     0xad42c4: str             x0, [SP, #-8]!
    // 0xad42c8: r0 = _interpolate()
    //     0xad42c8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad42cc: add             SP, SP, #8
    // 0xad42d0: LeaveFrame
    //     0xad42d0: mov             SP, fp
    //     0xad42d4: ldp             fp, lr, [SP], #0x10
    // 0xad42d8: ret
    //     0xad42d8: ret             
    // 0xad42dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad42dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad42e0: b               #0xad4248
  }
}

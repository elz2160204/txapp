// lib: , url: package:file/src/backends/local/local_file.dart

// class id: 1049029, size: 0x8
class :: {
}

// class id: 4396, size: 0x14, field offset: 0x14
//   transformed mixin,
abstract class _LocalFile&LocalFileSystemEntity&ForwardingFile extends LocalFileSystemEntity<File, File>
     with ForwardingFile {

  dynamic length(dynamic) {
    // ** addr: 0xad43b0, size: 0x30
    // 0xad43b0: r4 = 7
    //     0xad43b0: mov             x4, #7
    // 0xad43b4: r1 = Function 'length':.
    //     0xad43b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc7a8] AnonymousClosure: (0xad43c8), in [package:file/src/backends/local/local_file.dart] _LocalFile&LocalFileSystemEntity&ForwardingFile::length (0xcb6b90)
    //     0xad43b8: ldr             x1, [x17, #0x7a8]
    // 0xad43bc: r24 = BuildNonGenericMethodExtractorStub
    //     0xad43bc: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xad43c0: LoadField: r0 = r24->field_17
    //     0xad43c0: ldur            x0, [x24, #0x17]
    // 0xad43c4: br              x0
  }
  [closure] Future<int> length(dynamic) {
    // ** addr: 0xad43c8, size: 0x48
    // 0xad43c8: EnterFrame
    //     0xad43c8: stp             fp, lr, [SP, #-0x10]!
    //     0xad43cc: mov             fp, SP
    // 0xad43d0: ldr             x0, [fp, #0x10]
    // 0xad43d4: LoadField: r1 = r0->field_17
    //     0xad43d4: ldur            w1, [x0, #0x17]
    // 0xad43d8: DecompressPointer r1
    //     0xad43d8: add             x1, x1, HEAP, lsl #32
    // 0xad43dc: CheckStackOverflow
    //     0xad43dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad43e0: cmp             SP, x16
    //     0xad43e4: b.ls            #0xad4408
    // 0xad43e8: LoadField: r0 = r1->field_f
    //     0xad43e8: ldur            w0, [x1, #0xf]
    // 0xad43ec: DecompressPointer r0
    //     0xad43ec: add             x0, x0, HEAP, lsl #32
    // 0xad43f0: SaveReg r0
    //     0xad43f0: str             x0, [SP, #-8]!
    // 0xad43f4: r0 = length()
    //     0xad43f4: bl              #0xcb6b90  ; [package:file/src/backends/local/local_file.dart] _LocalFile&LocalFileSystemEntity&ForwardingFile::length
    // 0xad43f8: add             SP, SP, #8
    // 0xad43fc: LeaveFrame
    //     0xad43fc: mov             SP, fp
    //     0xad4400: ldp             fp, lr, [SP], #0x10
    // 0xad4404: ret
    //     0xad4404: ret             
    // 0xad4408: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4408: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad440c: b               #0xad43e8
  }
  _ writeAsStringSync(/* No info */) {
    // ** addr: 0xcb27e4, size: 0xdc
    // 0xcb27e4: EnterFrame
    //     0xcb27e4: stp             fp, lr, [SP, #-0x10]!
    //     0xcb27e8: mov             fp, SP
    // 0xcb27ec: mov             x0, x4
    // 0xcb27f0: LoadField: r1 = r0->field_13
    //     0xcb27f0: ldur            w1, [x0, #0x13]
    // 0xcb27f4: DecompressPointer r1
    //     0xcb27f4: add             x1, x1, HEAP, lsl #32
    // 0xcb27f8: sub             x2, x1, #4
    // 0xcb27fc: add             x1, fp, w2, sxtw #2
    // 0xcb2800: ldr             x1, [x1, #0x18]
    // 0xcb2804: add             x3, fp, w2, sxtw #2
    // 0xcb2808: ldr             x3, [x3, #0x10]
    // 0xcb280c: LoadField: r2 = r0->field_1f
    //     0xcb280c: ldur            w2, [x0, #0x1f]
    // 0xcb2810: DecompressPointer r2
    //     0xcb2810: add             x2, x2, HEAP, lsl #32
    // 0xcb2814: r16 = "encoding"
    //     0xcb2814: add             x16, PP, #8, lsl #12  ; [pp+0x8e58] "encoding"
    //     0xcb2818: ldr             x16, [x16, #0xe58]
    // 0xcb281c: cmp             w2, w16
    // 0xcb2820: b.ne            #0xcb282c
    // 0xcb2824: r2 = 1
    //     0xcb2824: mov             x2, #1
    // 0xcb2828: b               #0xcb2830
    // 0xcb282c: r2 = 0
    //     0xcb282c: mov             x2, #0
    // 0xcb2830: lsl             x4, x2, #1
    // 0xcb2834: lsl             w2, w4, #1
    // 0xcb2838: add             w4, w2, #8
    // 0xcb283c: ArrayLoad: r2 = r0[r4]  ; Unknown_4
    //     0xcb283c: add             x16, x0, w4, sxtw #1
    //     0xcb2840: ldur            w2, [x16, #0xf]
    // 0xcb2844: DecompressPointer r2
    //     0xcb2844: add             x2, x2, HEAP, lsl #32
    // 0xcb2848: r16 = "flush"
    //     0xcb2848: add             x16, PP, #8, lsl #12  ; [pp+0x8e70] "flush"
    //     0xcb284c: ldr             x16, [x16, #0xe70]
    // 0xcb2850: cmp             w2, w16
    // 0xcb2854: b.eq            #0xcb2858
    // 0xcb2858: CheckStackOverflow
    //     0xcb2858: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb285c: cmp             SP, x16
    //     0xcb2860: b.ls            #0xcb28b8
    // 0xcb2864: LoadField: r0 = r1->field_f
    //     0xcb2864: ldur            w0, [x1, #0xf]
    // 0xcb2868: DecompressPointer r0
    //     0xcb2868: add             x0, x0, HEAP, lsl #32
    // 0xcb286c: r1 = LoadClassIdInstr(r0)
    //     0xcb286c: ldur            x1, [x0, #-1]
    //     0xcb2870: ubfx            x1, x1, #0xc, #0x14
    // 0xcb2874: stp             x3, x0, [SP, #-0x10]!
    // 0xcb2878: r16 = Instance_FileMode
    //     0xcb2878: add             x16, PP, #8, lsl #12  ; [pp+0x8e60] Obj!FileMode@b5f4b1
    //     0xcb287c: ldr             x16, [x16, #0xe60]
    // 0xcb2880: r30 = Instance_Utf8Codec
    //     0xcb2880: ldr             lr, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xcb2884: stp             lr, x16, [SP, #-0x10]!
    // 0xcb2888: r16 = false
    //     0xcb2888: add             x16, NULL, #0x30  ; false
    // 0xcb288c: SaveReg r16
    //     0xcb288c: str             x16, [SP, #-8]!
    // 0xcb2890: mov             x0, x1
    // 0xcb2894: r4 = const [0, 0x5, 0x5, 0x2, encoding, 0x3, flush, 0x4, mode, 0x2, null]
    //     0xcb2894: add             x4, PP, #0x51, lsl #12  ; [pp+0x514d0] List(11) [0, 0x5, 0x5, 0x2, "encoding", 0x3, "flush", 0x4, "mode", 0x2, Null]
    //     0xcb2898: ldr             x4, [x4, #0x4d0]
    // 0xcb289c: r0 = GDT[cid_x0 + -0xeef]()
    //     0xcb289c: sub             lr, x0, #0xeef
    //     0xcb28a0: ldr             lr, [x21, lr, lsl #3]
    //     0xcb28a4: blr             lr
    // 0xcb28a8: add             SP, SP, #0x28
    // 0xcb28ac: LeaveFrame
    //     0xcb28ac: mov             SP, fp
    //     0xcb28b0: ldp             fp, lr, [SP], #0x10
    // 0xcb28b4: ret
    //     0xcb28b4: ret             
    // 0xcb28b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb28b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb28bc: b               #0xcb2864
  }
  _ readAsLines(/* No info */) {
    // ** addr: 0xcb29f0, size: 0x70
    // 0xcb29f0: EnterFrame
    //     0xcb29f0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb29f4: mov             fp, SP
    // 0xcb29f8: mov             x0, x4
    // 0xcb29fc: LoadField: r1 = r0->field_13
    //     0xcb29fc: ldur            w1, [x0, #0x13]
    // 0xcb2a00: DecompressPointer r1
    //     0xcb2a00: add             x1, x1, HEAP, lsl #32
    // 0xcb2a04: sub             x0, x1, #2
    // 0xcb2a08: add             x1, fp, w0, sxtw #2
    // 0xcb2a0c: ldr             x1, [x1, #0x10]
    // 0xcb2a10: CheckStackOverflow
    //     0xcb2a10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb2a14: cmp             SP, x16
    //     0xcb2a18: b.ls            #0xcb2a58
    // 0xcb2a1c: LoadField: r0 = r1->field_f
    //     0xcb2a1c: ldur            w0, [x1, #0xf]
    // 0xcb2a20: DecompressPointer r0
    //     0xcb2a20: add             x0, x0, HEAP, lsl #32
    // 0xcb2a24: r1 = LoadClassIdInstr(r0)
    //     0xcb2a24: ldur            x1, [x0, #-1]
    //     0xcb2a28: ubfx            x1, x1, #0xc, #0x14
    // 0xcb2a2c: r16 = Instance_Utf8Codec
    //     0xcb2a2c: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xcb2a30: stp             x16, x0, [SP, #-0x10]!
    // 0xcb2a34: mov             x0, x1
    // 0xcb2a38: r4 = const [0, 0x2, 0x2, 0x1, encoding, 0x1, null]
    //     0xcb2a38: ldr             x4, [PP, #0x7f40]  ; [pp+0x7f40] List(7) [0, 0x2, 0x2, 0x1, "encoding", 0x1, Null]
    // 0xcb2a3c: r0 = GDT[cid_x0 + -0xef7]()
    //     0xcb2a3c: sub             lr, x0, #0xef7
    //     0xcb2a40: ldr             lr, [x21, lr, lsl #3]
    //     0xcb2a44: blr             lr
    // 0xcb2a48: add             SP, SP, #0x10
    // 0xcb2a4c: LeaveFrame
    //     0xcb2a4c: mov             SP, fp
    //     0xcb2a50: ldp             fp, lr, [SP], #0x10
    // 0xcb2a54: ret
    //     0xcb2a54: ret             
    // 0xcb2a58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb2a58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb2a5c: b               #0xcb2a1c
  }
  _ readAsStringSync(/* No info */) {
    // ** addr: 0xcb2a60, size: 0x70
    // 0xcb2a60: EnterFrame
    //     0xcb2a60: stp             fp, lr, [SP, #-0x10]!
    //     0xcb2a64: mov             fp, SP
    // 0xcb2a68: mov             x0, x4
    // 0xcb2a6c: LoadField: r1 = r0->field_13
    //     0xcb2a6c: ldur            w1, [x0, #0x13]
    // 0xcb2a70: DecompressPointer r1
    //     0xcb2a70: add             x1, x1, HEAP, lsl #32
    // 0xcb2a74: sub             x0, x1, #2
    // 0xcb2a78: add             x1, fp, w0, sxtw #2
    // 0xcb2a7c: ldr             x1, [x1, #0x10]
    // 0xcb2a80: CheckStackOverflow
    //     0xcb2a80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb2a84: cmp             SP, x16
    //     0xcb2a88: b.ls            #0xcb2ac8
    // 0xcb2a8c: LoadField: r0 = r1->field_f
    //     0xcb2a8c: ldur            w0, [x1, #0xf]
    // 0xcb2a90: DecompressPointer r0
    //     0xcb2a90: add             x0, x0, HEAP, lsl #32
    // 0xcb2a94: r1 = LoadClassIdInstr(r0)
    //     0xcb2a94: ldur            x1, [x0, #-1]
    //     0xcb2a98: ubfx            x1, x1, #0xc, #0x14
    // 0xcb2a9c: r16 = Instance_Utf8Codec
    //     0xcb2a9c: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xcb2aa0: stp             x16, x0, [SP, #-0x10]!
    // 0xcb2aa4: mov             x0, x1
    // 0xcb2aa8: r4 = const [0, 0x2, 0x2, 0x1, encoding, 0x1, null]
    //     0xcb2aa8: ldr             x4, [PP, #0x7f40]  ; [pp+0x7f40] List(7) [0, 0x2, 0x2, 0x1, "encoding", 0x1, Null]
    // 0xcb2aac: r0 = GDT[cid_x0 + -0xf03]()
    //     0xcb2aac: sub             lr, x0, #0xf03
    //     0xcb2ab0: ldr             lr, [x21, lr, lsl #3]
    //     0xcb2ab4: blr             lr
    // 0xcb2ab8: add             SP, SP, #0x10
    // 0xcb2abc: LeaveFrame
    //     0xcb2abc: mov             SP, fp
    //     0xcb2ac0: ldp             fp, lr, [SP], #0x10
    // 0xcb2ac4: ret
    //     0xcb2ac4: ret             
    // 0xcb2ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb2ac8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb2acc: b               #0xcb2a8c
  }
  _ writeAsString(/* No info */) async {
    // ** addr: 0xcb2b50, size: 0xe0
    // 0xcb2b50: EnterFrame
    //     0xcb2b50: stp             fp, lr, [SP, #-0x10]!
    //     0xcb2b54: mov             fp, SP
    // 0xcb2b58: AllocStack(0x18)
    //     0xcb2b58: sub             SP, SP, #0x18
    // 0xcb2b5c: SetupParameters(_LocalFile&LocalFileSystemEntity&ForwardingFile<File, File> this /* r1, fp-0x18 */, dynamic _ /* r3, fp-0x10 */, {dynamic encoding})
    //     0xcb2b5c: stur            NULL, [fp, #-8]
    //     0xcb2b60: mov             x0, x4
    //     0xcb2b64: ldur            w1, [x0, #0x13]
    //     0xcb2b68: add             x1, x1, HEAP, lsl #32
    //     0xcb2b6c: sub             x2, x1, #6
    //     0xcb2b70: add             x1, fp, w2, sxtw #2
    //     0xcb2b74: ldr             x1, [x1, #0x20]
    //     0xcb2b78: stur            x1, [fp, #-0x18]
    //     0xcb2b7c: add             x3, fp, w2, sxtw #2
    //     0xcb2b80: ldr             x3, [x3, #0x18]
    //     0xcb2b84: stur            x3, [fp, #-0x10]
    //     0xcb2b88: ldur            w2, [x0, #0x1f]
    //     0xcb2b8c: add             x2, x2, HEAP, lsl #32
    //     0xcb2b90: add             x16, PP, #8, lsl #12  ; [pp+0x8e58] "encoding"
    //     0xcb2b94: ldr             x16, [x16, #0xe58]
    //     0xcb2b98: cmp             w2, w16
    //     0xcb2b9c: b.eq            #0xcb2ba0
    // 0xcb2ba0: CheckStackOverflow
    //     0xcb2ba0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb2ba4: cmp             SP, x16
    //     0xcb2ba8: b.ls            #0xcb2c28
    // 0xcb2bac: InitAsync() -> Future<File>
    //     0xcb2bac: add             x0, PP, #0xb, lsl #12  ; [pp+0xb148] TypeArguments: <File>
    //     0xcb2bb0: ldr             x0, [x0, #0x148]
    //     0xcb2bb4: bl              #0x4b92e4
    // 0xcb2bb8: ldur            x1, [fp, #-0x18]
    // 0xcb2bbc: LoadField: r0 = r1->field_f
    //     0xcb2bbc: ldur            w0, [x1, #0xf]
    // 0xcb2bc0: DecompressPointer r0
    //     0xcb2bc0: add             x0, x0, HEAP, lsl #32
    // 0xcb2bc4: r2 = LoadClassIdInstr(r0)
    //     0xcb2bc4: ldur            x2, [x0, #-1]
    //     0xcb2bc8: ubfx            x2, x2, #0xc, #0x14
    // 0xcb2bcc: ldur            x16, [fp, #-0x10]
    // 0xcb2bd0: stp             x16, x0, [SP, #-0x10]!
    // 0xcb2bd4: r16 = true
    //     0xcb2bd4: add             x16, NULL, #0x20  ; true
    // 0xcb2bd8: r30 = Instance_FileMode
    //     0xcb2bd8: add             lr, PP, #8, lsl #12  ; [pp+0x8e60] Obj!FileMode@b5f4b1
    //     0xcb2bdc: ldr             lr, [lr, #0xe60]
    // 0xcb2be0: stp             lr, x16, [SP, #-0x10]!
    // 0xcb2be4: r16 = Instance_Utf8Codec
    //     0xcb2be4: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xcb2be8: SaveReg r16
    //     0xcb2be8: str             x16, [SP, #-8]!
    // 0xcb2bec: mov             x0, x2
    // 0xcb2bf0: r4 = const [0, 0x5, 0x5, 0x3, encoding, 0x4, mode, 0x3, null]
    //     0xcb2bf0: add             x4, PP, #0xb, lsl #12  ; [pp+0xb150] List(9) [0, 0x5, 0x5, 0x3, "encoding", 0x4, "mode", 0x3, Null]
    //     0xcb2bf4: ldr             x4, [x4, #0x150]
    // 0xcb2bf8: r0 = GDT[cid_x0 + -0xf12]()
    //     0xcb2bf8: sub             lr, x0, #0xf12
    //     0xcb2bfc: ldr             lr, [x21, lr, lsl #3]
    //     0xcb2c00: blr             lr
    // 0xcb2c04: add             SP, SP, #0x28
    // 0xcb2c08: mov             x1, x0
    // 0xcb2c0c: stur            x1, [fp, #-0x10]
    // 0xcb2c10: r0 = Await()
    //     0xcb2c10: bl              #0x4b8e6c  ; AwaitStub
    // 0xcb2c14: ldur            x16, [fp, #-0x18]
    // 0xcb2c18: stp             x0, x16, [SP, #-0x10]!
    // 0xcb2c1c: r0 = wrapFile()
    //     0xcb2c1c: bl              #0xc94540  ; [package:file/src/backends/local/local_file_system_entity.dart] LocalFileSystemEntity::wrapFile
    // 0xcb2c20: add             SP, SP, #0x10
    // 0xcb2c24: r0 = ReturnAsyncNotFuture()
    //     0xcb2c24: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xcb2c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb2c28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb2c2c: b               #0xcb2bac
  }
  _ readAsString(/* No info */) {
    // ** addr: 0xcb2c30, size: 0x70
    // 0xcb2c30: EnterFrame
    //     0xcb2c30: stp             fp, lr, [SP, #-0x10]!
    //     0xcb2c34: mov             fp, SP
    // 0xcb2c38: mov             x0, x4
    // 0xcb2c3c: LoadField: r1 = r0->field_13
    //     0xcb2c3c: ldur            w1, [x0, #0x13]
    // 0xcb2c40: DecompressPointer r1
    //     0xcb2c40: add             x1, x1, HEAP, lsl #32
    // 0xcb2c44: sub             x0, x1, #2
    // 0xcb2c48: add             x1, fp, w0, sxtw #2
    // 0xcb2c4c: ldr             x1, [x1, #0x10]
    // 0xcb2c50: CheckStackOverflow
    //     0xcb2c50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb2c54: cmp             SP, x16
    //     0xcb2c58: b.ls            #0xcb2c98
    // 0xcb2c5c: LoadField: r0 = r1->field_f
    //     0xcb2c5c: ldur            w0, [x1, #0xf]
    // 0xcb2c60: DecompressPointer r0
    //     0xcb2c60: add             x0, x0, HEAP, lsl #32
    // 0xcb2c64: r1 = LoadClassIdInstr(r0)
    //     0xcb2c64: ldur            x1, [x0, #-1]
    //     0xcb2c68: ubfx            x1, x1, #0xc, #0x14
    // 0xcb2c6c: r16 = Instance_Utf8Codec
    //     0xcb2c6c: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xcb2c70: stp             x16, x0, [SP, #-0x10]!
    // 0xcb2c74: mov             x0, x1
    // 0xcb2c78: r4 = const [0, 0x2, 0x2, 0x1, encoding, 0x1, null]
    //     0xcb2c78: ldr             x4, [PP, #0x7f40]  ; [pp+0x7f40] List(7) [0, 0x2, 0x2, 0x1, "encoding", 0x1, Null]
    // 0xcb2c7c: r0 = GDT[cid_x0 + -0xf15]()
    //     0xcb2c7c: sub             lr, x0, #0xf15
    //     0xcb2c80: ldr             lr, [x21, lr, lsl #3]
    //     0xcb2c84: blr             lr
    // 0xcb2c88: add             SP, SP, #0x10
    // 0xcb2c8c: LeaveFrame
    //     0xcb2c8c: mov             SP, fp
    //     0xcb2c90: ldp             fp, lr, [SP], #0x10
    // 0xcb2c94: ret
    //     0xcb2c94: ret             
    // 0xcb2c98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb2c98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb2c9c: b               #0xcb2c5c
  }
  _ readAsBytesSync(/* No info */) {
    // ** addr: 0xcb2ca0, size: 0x50
    // 0xcb2ca0: EnterFrame
    //     0xcb2ca0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb2ca4: mov             fp, SP
    // 0xcb2ca8: CheckStackOverflow
    //     0xcb2ca8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb2cac: cmp             SP, x16
    //     0xcb2cb0: b.ls            #0xcb2ce8
    // 0xcb2cb4: ldr             x0, [fp, #0x10]
    // 0xcb2cb8: LoadField: r1 = r0->field_f
    //     0xcb2cb8: ldur            w1, [x0, #0xf]
    // 0xcb2cbc: DecompressPointer r1
    //     0xcb2cbc: add             x1, x1, HEAP, lsl #32
    // 0xcb2cc0: r0 = LoadClassIdInstr(r1)
    //     0xcb2cc0: ldur            x0, [x1, #-1]
    //     0xcb2cc4: ubfx            x0, x0, #0xc, #0x14
    // 0xcb2cc8: SaveReg r1
    //     0xcb2cc8: str             x1, [SP, #-8]!
    // 0xcb2ccc: r0 = GDT[cid_x0 + -0xf17]()
    //     0xcb2ccc: sub             lr, x0, #0xf17
    //     0xcb2cd0: ldr             lr, [x21, lr, lsl #3]
    //     0xcb2cd4: blr             lr
    // 0xcb2cd8: add             SP, SP, #8
    // 0xcb2cdc: LeaveFrame
    //     0xcb2cdc: mov             SP, fp
    //     0xcb2ce0: ldp             fp, lr, [SP], #0x10
    // 0xcb2ce4: ret
    //     0xcb2ce4: ret             
    // 0xcb2ce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb2ce8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb2cec: b               #0xcb2cb4
  }
  _ openSync(/* No info */) {
    // ** addr: 0xcb31a8, size: 0x74
    // 0xcb31a8: EnterFrame
    //     0xcb31a8: stp             fp, lr, [SP, #-0x10]!
    //     0xcb31ac: mov             fp, SP
    // 0xcb31b0: mov             x0, x4
    // 0xcb31b4: LoadField: r1 = r0->field_13
    //     0xcb31b4: ldur            w1, [x0, #0x13]
    // 0xcb31b8: DecompressPointer r1
    //     0xcb31b8: add             x1, x1, HEAP, lsl #32
    // 0xcb31bc: sub             x0, x1, #2
    // 0xcb31c0: add             x1, fp, w0, sxtw #2
    // 0xcb31c4: ldr             x1, [x1, #0x10]
    // 0xcb31c8: CheckStackOverflow
    //     0xcb31c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb31cc: cmp             SP, x16
    //     0xcb31d0: b.ls            #0xcb3214
    // 0xcb31d4: LoadField: r0 = r1->field_f
    //     0xcb31d4: ldur            w0, [x1, #0xf]
    // 0xcb31d8: DecompressPointer r0
    //     0xcb31d8: add             x0, x0, HEAP, lsl #32
    // 0xcb31dc: r1 = LoadClassIdInstr(r0)
    //     0xcb31dc: ldur            x1, [x0, #-1]
    //     0xcb31e0: ubfx            x1, x1, #0xc, #0x14
    // 0xcb31e4: r16 = Instance_FileMode
    //     0xcb31e4: add             x16, PP, #8, lsl #12  ; [pp+0x8f20] Obj!FileMode@b5f4c1
    //     0xcb31e8: ldr             x16, [x16, #0xf20]
    // 0xcb31ec: stp             x16, x0, [SP, #-0x10]!
    // 0xcb31f0: mov             x0, x1
    // 0xcb31f4: r4 = const [0, 0x2, 0x2, 0x1, mode, 0x1, null]
    //     0xcb31f4: ldr             x4, [PP, #0x4128]  ; [pp+0x4128] List(7) [0, 0x2, 0x2, 0x1, "mode", 0x1, Null]
    // 0xcb31f8: r0 = GDT[cid_x0 + -0xf2a]()
    //     0xcb31f8: sub             lr, x0, #0xf2a
    //     0xcb31fc: ldr             lr, [x21, lr, lsl #3]
    //     0xcb3200: blr             lr
    // 0xcb3204: add             SP, SP, #0x10
    // 0xcb3208: LeaveFrame
    //     0xcb3208: mov             SP, fp
    //     0xcb320c: ldp             fp, lr, [SP], #0x10
    // 0xcb3210: ret
    //     0xcb3210: ret             
    // 0xcb3214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb3214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb3218: b               #0xcb31d4
  }
  _ open(/* No info */) {
    // ** addr: 0xcb5dac, size: 0x70
    // 0xcb5dac: EnterFrame
    //     0xcb5dac: stp             fp, lr, [SP, #-0x10]!
    //     0xcb5db0: mov             fp, SP
    // 0xcb5db4: mov             x0, x4
    // 0xcb5db8: LoadField: r1 = r0->field_13
    //     0xcb5db8: ldur            w1, [x0, #0x13]
    // 0xcb5dbc: DecompressPointer r1
    //     0xcb5dbc: add             x1, x1, HEAP, lsl #32
    // 0xcb5dc0: sub             x0, x1, #2
    // 0xcb5dc4: add             x1, fp, w0, sxtw #2
    // 0xcb5dc8: ldr             x1, [x1, #0x10]
    // 0xcb5dcc: CheckStackOverflow
    //     0xcb5dcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb5dd0: cmp             SP, x16
    //     0xcb5dd4: b.ls            #0xcb5e14
    // 0xcb5dd8: LoadField: r0 = r1->field_f
    //     0xcb5dd8: ldur            w0, [x1, #0xf]
    // 0xcb5ddc: DecompressPointer r0
    //     0xcb5ddc: add             x0, x0, HEAP, lsl #32
    // 0xcb5de0: r1 = LoadClassIdInstr(r0)
    //     0xcb5de0: ldur            x1, [x0, #-1]
    //     0xcb5de4: ubfx            x1, x1, #0xc, #0x14
    // 0xcb5de8: r16 = Instance_FileMode
    //     0xcb5de8: ldr             x16, [PP, #0x4120]  ; [pp+0x4120] Obj!FileMode@b5f4a1
    // 0xcb5dec: stp             x16, x0, [SP, #-0x10]!
    // 0xcb5df0: mov             x0, x1
    // 0xcb5df4: r4 = const [0, 0x2, 0x2, 0x1, mode, 0x1, null]
    //     0xcb5df4: ldr             x4, [PP, #0x4128]  ; [pp+0x4128] List(7) [0, 0x2, 0x2, 0x1, "mode", 0x1, Null]
    // 0xcb5df8: r0 = GDT[cid_x0 + -0xf53]()
    //     0xcb5df8: sub             lr, x0, #0xf53
    //     0xcb5dfc: ldr             lr, [x21, lr, lsl #3]
    //     0xcb5e00: blr             lr
    // 0xcb5e04: add             SP, SP, #0x10
    // 0xcb5e08: LeaveFrame
    //     0xcb5e08: mov             SP, fp
    //     0xcb5e0c: ldp             fp, lr, [SP], #0x10
    // 0xcb5e10: ret
    //     0xcb5e10: ret             
    // 0xcb5e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb5e14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb5e18: b               #0xcb5dd8
  }
  _ createSync(/* No info */) {
    // ** addr: 0xcb60c8, size: 0x54
    // 0xcb60c8: EnterFrame
    //     0xcb60c8: stp             fp, lr, [SP, #-0x10]!
    //     0xcb60cc: mov             fp, SP
    // 0xcb60d0: CheckStackOverflow
    //     0xcb60d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb60d4: cmp             SP, x16
    //     0xcb60d8: b.ls            #0xcb6114
    // 0xcb60dc: ldr             x0, [fp, #0x18]
    // 0xcb60e0: LoadField: r1 = r0->field_f
    //     0xcb60e0: ldur            w1, [x0, #0xf]
    // 0xcb60e4: DecompressPointer r1
    //     0xcb60e4: add             x1, x1, HEAP, lsl #32
    // 0xcb60e8: r0 = LoadClassIdInstr(r1)
    //     0xcb60e8: ldur            x0, [x1, #-1]
    //     0xcb60ec: ubfx            x0, x0, #0xc, #0x14
    // 0xcb60f0: r16 = true
    //     0xcb60f0: add             x16, NULL, #0x20  ; true
    // 0xcb60f4: stp             x16, x1, [SP, #-0x10]!
    // 0xcb60f8: r0 = GDT[cid_x0 + -0xf56]()
    //     0xcb60f8: sub             lr, x0, #0xf56
    //     0xcb60fc: ldr             lr, [x21, lr, lsl #3]
    //     0xcb6100: blr             lr
    // 0xcb6104: add             SP, SP, #0x10
    // 0xcb6108: LeaveFrame
    //     0xcb6108: mov             SP, fp
    //     0xcb610c: ldp             fp, lr, [SP], #0x10
    // 0xcb6110: ret
    //     0xcb6110: ret             
    // 0xcb6114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb6114: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb6118: b               #0xcb60dc
  }
  _ openRead(/* No info */) {
    // ** addr: 0xcb64e8, size: 0xac
    // 0xcb64e8: EnterFrame
    //     0xcb64e8: stp             fp, lr, [SP, #-0x10]!
    //     0xcb64ec: mov             fp, SP
    // 0xcb64f0: mov             x0, x4
    // 0xcb64f4: LoadField: r1 = r0->field_13
    //     0xcb64f4: ldur            w1, [x0, #0x13]
    // 0xcb64f8: DecompressPointer r1
    //     0xcb64f8: add             x1, x1, HEAP, lsl #32
    // 0xcb64fc: sub             x0, x1, #2
    // 0xcb6500: add             x1, fp, w0, sxtw #2
    // 0xcb6504: ldr             x1, [x1, #0x10]
    // 0xcb6508: cmp             w0, #2
    // 0xcb650c: b.lt            #0xcb6538
    // 0xcb6510: add             x2, fp, w0, sxtw #2
    // 0xcb6514: ldr             x2, [x2, #8]
    // 0xcb6518: cmp             w0, #4
    // 0xcb651c: b.lt            #0xcb6530
    // 0xcb6520: add             x3, fp, w0, sxtw #2
    // 0xcb6524: ldr             x3, [x3]
    // 0xcb6528: mov             x0, x3
    // 0xcb652c: b               #0xcb6544
    // 0xcb6530: mov             x0, x2
    // 0xcb6534: b               #0xcb653c
    // 0xcb6538: r0 = Null
    //     0xcb6538: mov             x0, NULL
    // 0xcb653c: mov             x2, x0
    // 0xcb6540: r0 = Null
    //     0xcb6540: mov             x0, NULL
    // 0xcb6544: CheckStackOverflow
    //     0xcb6544: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb6548: cmp             SP, x16
    //     0xcb654c: b.ls            #0xcb658c
    // 0xcb6550: LoadField: r3 = r1->field_f
    //     0xcb6550: ldur            w3, [x1, #0xf]
    // 0xcb6554: DecompressPointer r3
    //     0xcb6554: add             x3, x3, HEAP, lsl #32
    // 0xcb6558: r1 = LoadClassIdInstr(r3)
    //     0xcb6558: ldur            x1, [x3, #-1]
    //     0xcb655c: ubfx            x1, x1, #0xc, #0x14
    // 0xcb6560: stp             x2, x3, [SP, #-0x10]!
    // 0xcb6564: SaveReg r0
    //     0xcb6564: str             x0, [SP, #-8]!
    // 0xcb6568: mov             x0, x1
    // 0xcb656c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xcb656c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xcb6570: r0 = GDT[cid_x0 + -0xf5a]()
    //     0xcb6570: sub             lr, x0, #0xf5a
    //     0xcb6574: ldr             lr, [x21, lr, lsl #3]
    //     0xcb6578: blr             lr
    // 0xcb657c: add             SP, SP, #0x18
    // 0xcb6580: LeaveFrame
    //     0xcb6580: mov             SP, fp
    //     0xcb6584: ldp             fp, lr, [SP], #0x10
    // 0xcb6588: ret
    //     0xcb6588: ret             
    // 0xcb658c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb658c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb6590: b               #0xcb6550
  }
  _ lengthSync(/* No info */) {
    // ** addr: 0xcb6594, size: 0x50
    // 0xcb6594: EnterFrame
    //     0xcb6594: stp             fp, lr, [SP, #-0x10]!
    //     0xcb6598: mov             fp, SP
    // 0xcb659c: CheckStackOverflow
    //     0xcb659c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb65a0: cmp             SP, x16
    //     0xcb65a4: b.ls            #0xcb65dc
    // 0xcb65a8: ldr             x0, [fp, #0x10]
    // 0xcb65ac: LoadField: r1 = r0->field_f
    //     0xcb65ac: ldur            w1, [x0, #0xf]
    // 0xcb65b0: DecompressPointer r1
    //     0xcb65b0: add             x1, x1, HEAP, lsl #32
    // 0xcb65b4: r0 = LoadClassIdInstr(r1)
    //     0xcb65b4: ldur            x0, [x1, #-1]
    //     0xcb65b8: ubfx            x0, x0, #0xc, #0x14
    // 0xcb65bc: SaveReg r1
    //     0xcb65bc: str             x1, [SP, #-8]!
    // 0xcb65c0: r0 = GDT[cid_x0 + -0xf5e]()
    //     0xcb65c0: sub             lr, x0, #0xf5e
    //     0xcb65c4: ldr             lr, [x21, lr, lsl #3]
    //     0xcb65c8: blr             lr
    // 0xcb65cc: add             SP, SP, #8
    // 0xcb65d0: LeaveFrame
    //     0xcb65d0: mov             SP, fp
    //     0xcb65d4: ldp             fp, lr, [SP], #0x10
    // 0xcb65d8: ret
    //     0xcb65d8: ret             
    // 0xcb65dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb65dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb65e0: b               #0xcb65a8
  }
  _ length(/* No info */) {
    // ** addr: 0xcb6b90, size: 0x50
    // 0xcb6b90: EnterFrame
    //     0xcb6b90: stp             fp, lr, [SP, #-0x10]!
    //     0xcb6b94: mov             fp, SP
    // 0xcb6b98: CheckStackOverflow
    //     0xcb6b98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb6b9c: cmp             SP, x16
    //     0xcb6ba0: b.ls            #0xcb6bd8
    // 0xcb6ba4: ldr             x0, [fp, #0x10]
    // 0xcb6ba8: LoadField: r1 = r0->field_f
    //     0xcb6ba8: ldur            w1, [x0, #0xf]
    // 0xcb6bac: DecompressPointer r1
    //     0xcb6bac: add             x1, x1, HEAP, lsl #32
    // 0xcb6bb0: r0 = LoadClassIdInstr(r1)
    //     0xcb6bb0: ldur            x0, [x1, #-1]
    //     0xcb6bb4: ubfx            x0, x0, #0xc, #0x14
    // 0xcb6bb8: SaveReg r1
    //     0xcb6bb8: str             x1, [SP, #-8]!
    // 0xcb6bbc: r0 = GDT[cid_x0 + -0xf7a]()
    //     0xcb6bbc: sub             lr, x0, #0xf7a
    //     0xcb6bc0: ldr             lr, [x21, lr, lsl #3]
    //     0xcb6bc4: blr             lr
    // 0xcb6bc8: add             SP, SP, #8
    // 0xcb6bcc: LeaveFrame
    //     0xcb6bcc: mov             SP, fp
    //     0xcb6bd0: ldp             fp, lr, [SP], #0x10
    // 0xcb6bd4: ret
    //     0xcb6bd4: ret             
    // 0xcb6bd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb6bd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb6bdc: b               #0xcb6ba4
  }
  _ readAsBytes(/* No info */) {
    // ** addr: 0xcb6be0, size: 0x50
    // 0xcb6be0: EnterFrame
    //     0xcb6be0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb6be4: mov             fp, SP
    // 0xcb6be8: CheckStackOverflow
    //     0xcb6be8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb6bec: cmp             SP, x16
    //     0xcb6bf0: b.ls            #0xcb6c28
    // 0xcb6bf4: ldr             x0, [fp, #0x10]
    // 0xcb6bf8: LoadField: r1 = r0->field_f
    //     0xcb6bf8: ldur            w1, [x0, #0xf]
    // 0xcb6bfc: DecompressPointer r1
    //     0xcb6bfc: add             x1, x1, HEAP, lsl #32
    // 0xcb6c00: r0 = LoadClassIdInstr(r1)
    //     0xcb6c00: ldur            x0, [x1, #-1]
    //     0xcb6c04: ubfx            x0, x0, #0xc, #0x14
    // 0xcb6c08: SaveReg r1
    //     0xcb6c08: str             x1, [SP, #-8]!
    // 0xcb6c0c: r0 = GDT[cid_x0 + -0xfa9]()
    //     0xcb6c0c: sub             lr, x0, #0xfa9
    //     0xcb6c10: ldr             lr, [x21, lr, lsl #3]
    //     0xcb6c14: blr             lr
    // 0xcb6c18: add             SP, SP, #8
    // 0xcb6c1c: LeaveFrame
    //     0xcb6c1c: mov             SP, fp
    //     0xcb6c20: ldp             fp, lr, [SP], #0x10
    // 0xcb6c24: ret
    //     0xcb6c24: ret             
    // 0xcb6c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb6c28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb6c2c: b               #0xcb6bf4
  }
}

// class id: 4397, size: 0x14, field offset: 0x14
class LocalFile extends _LocalFile&LocalFileSystemEntity&ForwardingFile {

  _ toString(/* No info */) {
    // ** addr: 0xad42e4, size: 0xb4
    // 0xad42e4: EnterFrame
    //     0xad42e4: stp             fp, lr, [SP, #-0x10]!
    //     0xad42e8: mov             fp, SP
    // 0xad42ec: AllocStack(0x8)
    //     0xad42ec: sub             SP, SP, #8
    // 0xad42f0: CheckStackOverflow
    //     0xad42f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad42f4: cmp             SP, x16
    //     0xad42f8: b.ls            #0xad4390
    // 0xad42fc: r1 = Null
    //     0xad42fc: mov             x1, NULL
    // 0xad4300: r2 = 6
    //     0xad4300: mov             x2, #6
    // 0xad4304: r0 = AllocateArray()
    //     0xad4304: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4308: mov             x1, x0
    // 0xad430c: stur            x1, [fp, #-8]
    // 0xad4310: r17 = "LocalFile: \'"
    //     0xad4310: add             x17, PP, #0xb, lsl #12  ; [pp+0xb140] "LocalFile: \'"
    //     0xad4314: ldr             x17, [x17, #0x140]
    // 0xad4318: StoreField: r1->field_f = r17
    //     0xad4318: stur            w17, [x1, #0xf]
    // 0xad431c: ldr             x0, [fp, #0x10]
    // 0xad4320: LoadField: r2 = r0->field_f
    //     0xad4320: ldur            w2, [x0, #0xf]
    // 0xad4324: DecompressPointer r2
    //     0xad4324: add             x2, x2, HEAP, lsl #32
    // 0xad4328: r0 = LoadClassIdInstr(r2)
    //     0xad4328: ldur            x0, [x2, #-1]
    //     0xad432c: ubfx            x0, x0, #0xc, #0x14
    // 0xad4330: SaveReg r2
    //     0xad4330: str             x2, [SP, #-8]!
    // 0xad4334: r0 = GDT[cid_x0 + -0xf40]()
    //     0xad4334: sub             lr, x0, #0xf40
    //     0xad4338: ldr             lr, [x21, lr, lsl #3]
    //     0xad433c: blr             lr
    // 0xad4340: add             SP, SP, #8
    // 0xad4344: ldur            x1, [fp, #-8]
    // 0xad4348: ArrayStore: r1[1] = r0  ; List_4
    //     0xad4348: add             x25, x1, #0x13
    //     0xad434c: str             w0, [x25]
    //     0xad4350: tbz             w0, #0, #0xad436c
    //     0xad4354: ldurb           w16, [x1, #-1]
    //     0xad4358: ldurb           w17, [x0, #-1]
    //     0xad435c: and             x16, x17, x16, lsr #2
    //     0xad4360: tst             x16, HEAP, lsr #32
    //     0xad4364: b.eq            #0xad436c
    //     0xad4368: bl              #0xd67e5c
    // 0xad436c: ldur            x0, [fp, #-8]
    // 0xad4370: r17 = "\'"
    //     0xad4370: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad4374: StoreField: r0->field_17 = r17
    //     0xad4374: stur            w17, [x0, #0x17]
    // 0xad4378: SaveReg r0
    //     0xad4378: str             x0, [SP, #-8]!
    // 0xad437c: r0 = _interpolate()
    //     0xad437c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad4380: add             SP, SP, #8
    // 0xad4384: LeaveFrame
    //     0xad4384: mov             SP, fp
    //     0xad4388: ldp             fp, lr, [SP], #0x10
    // 0xad438c: ret
    //     0xad438c: ret             
    // 0xad4390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4394: b               #0xad42fc
  }
}

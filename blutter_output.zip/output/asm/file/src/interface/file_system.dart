// lib: , url: package:file/src/interface/file_system.dart

// class id: 1049046, size: 0x8
class :: {
}

// class id: 4402, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class FileSystem extends Object {
}

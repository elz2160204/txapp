// lib: , url: package:file/src/interface/file_system_entity.dart

// class id: 1049047, size: 0x8
class :: {
}

// class id: 4401, size: 0x8, field offset: 0x8
abstract class FileSystemEntity extends Object
    implements FileSystemEntity {
}

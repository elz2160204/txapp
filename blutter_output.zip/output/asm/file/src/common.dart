// lib: , url: package:file/src/common.dart

// class id: 1049033, size: 0x8
class :: {
}

// class id: 4406, size: 0x8, field offset: 0x8
abstract class DirectoryAddOnsMixin extends Object
    implements Directory {
}

// lib: , url: package:file/src/forwarding/forwarding_file_system_entity.dart

// class id: 1049038, size: 0x8
class :: {
}

// class id: 4394, size: 0xc, field offset: 0x8
abstract class ForwardingFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity> extends Object
    implements FileSystemEntity {

  _ statSync(/* No info */) {
    // ** addr: 0xc3efbc, size: 0x50
    // 0xc3efbc: EnterFrame
    //     0xc3efbc: stp             fp, lr, [SP, #-0x10]!
    //     0xc3efc0: mov             fp, SP
    // 0xc3efc4: CheckStackOverflow
    //     0xc3efc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3efc8: cmp             SP, x16
    //     0xc3efcc: b.ls            #0xc3f004
    // 0xc3efd0: ldr             x0, [fp, #0x10]
    // 0xc3efd4: LoadField: r1 = r0->field_f
    //     0xc3efd4: ldur            w1, [x0, #0xf]
    // 0xc3efd8: DecompressPointer r1
    //     0xc3efd8: add             x1, x1, HEAP, lsl #32
    // 0xc3efdc: r0 = LoadClassIdInstr(r1)
    //     0xc3efdc: ldur            x0, [x1, #-1]
    //     0xc3efe0: ubfx            x0, x0, #0xc, #0x14
    // 0xc3efe4: SaveReg r1
    //     0xc3efe4: str             x1, [SP, #-8]!
    // 0xc3efe8: r0 = GDT[cid_x0 + 0x971]()
    //     0xc3efe8: add             lr, x0, #0x971
    //     0xc3efec: ldr             lr, [x21, lr, lsl #3]
    //     0xc3eff0: blr             lr
    // 0xc3eff4: add             SP, SP, #8
    // 0xc3eff8: LeaveFrame
    //     0xc3eff8: mov             SP, fp
    //     0xc3effc: ldp             fp, lr, [SP], #0x10
    // 0xc3f000: ret
    //     0xc3f000: ret             
    // 0xc3f004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3f004: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3f008: b               #0xc3efd0
  }
  get _ absolute(/* No info */) {
    // ** addr: 0xc94490, size: 0xb0
    // 0xc94490: EnterFrame
    //     0xc94490: stp             fp, lr, [SP, #-0x10]!
    //     0xc94494: mov             fp, SP
    // 0xc94498: AllocStack(0x8)
    //     0xc94498: sub             SP, SP, #8
    // 0xc9449c: CheckStackOverflow
    //     0xc9449c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc944a0: cmp             SP, x16
    //     0xc944a4: b.ls            #0xc94538
    // 0xc944a8: ldr             x1, [fp, #0x10]
    // 0xc944ac: LoadField: r0 = r1->field_f
    //     0xc944ac: ldur            w0, [x1, #0xf]
    // 0xc944b0: DecompressPointer r0
    //     0xc944b0: add             x0, x0, HEAP, lsl #32
    // 0xc944b4: r2 = LoadClassIdInstr(r0)
    //     0xc944b4: ldur            x2, [x0, #-1]
    //     0xc944b8: ubfx            x2, x2, #0xc, #0x14
    // 0xc944bc: SaveReg r0
    //     0xc944bc: str             x0, [SP, #-8]!
    // 0xc944c0: mov             x0, x2
    // 0xc944c4: r0 = GDT[cid_x0 + -0x6bb]()
    //     0xc944c4: sub             lr, x0, #0x6bb
    //     0xc944c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc944cc: blr             lr
    // 0xc944d0: add             SP, SP, #8
    // 0xc944d4: mov             x4, x0
    // 0xc944d8: ldr             x3, [fp, #0x10]
    // 0xc944dc: stur            x4, [fp, #-8]
    // 0xc944e0: LoadField: r2 = r3->field_7
    //     0xc944e0: ldur            w2, [x3, #7]
    // 0xc944e4: DecompressPointer r2
    //     0xc944e4: add             x2, x2, HEAP, lsl #32
    // 0xc944e8: mov             x0, x4
    // 0xc944ec: r1 = Null
    //     0xc944ec: mov             x1, NULL
    // 0xc944f0: cmp             w2, NULL
    // 0xc944f4: b.eq            #0xc94518
    // 0xc944f8: LoadField: r4 = r2->field_1b
    //     0xc944f8: ldur            w4, [x2, #0x1b]
    // 0xc944fc: DecompressPointer r4
    //     0xc944fc: add             x4, x4, HEAP, lsl #32
    // 0xc94500: r8 = X1 bound FileSystemEntity
    //     0xc94500: add             x8, PP, #0x40, lsl #12  ; [pp+0x405e8] TypeParameter: X1 bound FileSystemEntity
    //     0xc94504: ldr             x8, [x8, #0x5e8]
    // 0xc94508: LoadField: r9 = r4->field_7
    //     0xc94508: ldur            x9, [x4, #7]
    // 0xc9450c: r3 = Null
    //     0xc9450c: add             x3, PP, #0x40, lsl #12  ; [pp+0x405f0] Null
    //     0xc94510: ldr             x3, [x3, #0x5f0]
    // 0xc94514: blr             x9
    // 0xc94518: ldr             x16, [fp, #0x10]
    // 0xc9451c: ldur            lr, [fp, #-8]
    // 0xc94520: stp             lr, x16, [SP, #-0x10]!
    // 0xc94524: r0 = wrapFile()
    //     0xc94524: bl              #0xc94540  ; [package:file/src/backends/local/local_file_system_entity.dart] LocalFileSystemEntity::wrapFile
    // 0xc94528: add             SP, SP, #0x10
    // 0xc9452c: LeaveFrame
    //     0xc9452c: mov             SP, fp
    //     0xc94530: ldp             fp, lr, [SP], #0x10
    // 0xc94534: ret
    //     0xc94534: ret             
    // 0xc94538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc94538: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9453c: b               #0xc944a8
  }
  _ existsSync(/* No info */) {
    // ** addr: 0xc98298, size: 0x50
    // 0xc98298: EnterFrame
    //     0xc98298: stp             fp, lr, [SP, #-0x10]!
    //     0xc9829c: mov             fp, SP
    // 0xc982a0: CheckStackOverflow
    //     0xc982a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc982a4: cmp             SP, x16
    //     0xc982a8: b.ls            #0xc982e0
    // 0xc982ac: ldr             x0, [fp, #0x10]
    // 0xc982b0: LoadField: r1 = r0->field_f
    //     0xc982b0: ldur            w1, [x0, #0xf]
    // 0xc982b4: DecompressPointer r1
    //     0xc982b4: add             x1, x1, HEAP, lsl #32
    // 0xc982b8: r0 = LoadClassIdInstr(r1)
    //     0xc982b8: ldur            x0, [x1, #-1]
    //     0xc982bc: ubfx            x0, x0, #0xc, #0x14
    // 0xc982c0: SaveReg r1
    //     0xc982c0: str             x1, [SP, #-8]!
    // 0xc982c4: r0 = GDT[cid_x0 + -0x7e4]()
    //     0xc982c4: sub             lr, x0, #0x7e4
    //     0xc982c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc982cc: blr             lr
    // 0xc982d0: add             SP, SP, #8
    // 0xc982d4: LeaveFrame
    //     0xc982d4: mov             SP, fp
    //     0xc982d8: ldp             fp, lr, [SP], #0x10
    // 0xc982dc: ret
    //     0xc982dc: ret             
    // 0xc982e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc982e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc982e4: b               #0xc982ac
  }
  get _ path(/* No info */) {
    // ** addr: 0xcb5d5c, size: 0x50
    // 0xcb5d5c: EnterFrame
    //     0xcb5d5c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb5d60: mov             fp, SP
    // 0xcb5d64: CheckStackOverflow
    //     0xcb5d64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb5d68: cmp             SP, x16
    //     0xcb5d6c: b.ls            #0xcb5da4
    // 0xcb5d70: ldr             x0, [fp, #0x10]
    // 0xcb5d74: LoadField: r1 = r0->field_f
    //     0xcb5d74: ldur            w1, [x0, #0xf]
    // 0xcb5d78: DecompressPointer r1
    //     0xcb5d78: add             x1, x1, HEAP, lsl #32
    // 0xcb5d7c: r0 = LoadClassIdInstr(r1)
    //     0xcb5d7c: ldur            x0, [x1, #-1]
    //     0xcb5d80: ubfx            x0, x0, #0xc, #0x14
    // 0xcb5d84: SaveReg r1
    //     0xcb5d84: str             x1, [SP, #-8]!
    // 0xcb5d88: r0 = GDT[cid_x0 + -0xf40]()
    //     0xcb5d88: sub             lr, x0, #0xf40
    //     0xcb5d8c: ldr             lr, [x21, lr, lsl #3]
    //     0xcb5d90: blr             lr
    // 0xcb5d94: add             SP, SP, #8
    // 0xcb5d98: LeaveFrame
    //     0xcb5d98: mov             SP, fp
    //     0xcb5d9c: ldp             fp, lr, [SP], #0x10
    // 0xcb5da0: ret
    //     0xcb5da0: ret             
    // 0xcb5da4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb5da4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb5da8: b               #0xcb5d70
  }
}

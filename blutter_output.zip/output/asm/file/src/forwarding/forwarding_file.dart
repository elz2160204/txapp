// lib: , url: package:file/src/forwarding/forwarding_file.dart

// class id: 1049036, size: 0x8
class :: {
}

// class id: 4404, size: 0x8, field offset: 0x8
abstract class ForwardingFile extends Object
    implements ForwardingFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity>, File {
}

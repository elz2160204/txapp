// lib: , url: package:file/src/forwarding/forwarding_directory.dart

// class id: 1049035, size: 0x8
class :: {
}

// class id: 4407, size: 0xc, field offset: 0x8
abstract class ForwardingDirectory<X0 bound Directory> extends Object
    implements ForwardingFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity>, Directory {
}

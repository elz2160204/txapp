// lib: encrypt, url: package:encrypt/encrypt.dart

// class id: 1048924, size: 0x8
class :: {

  static _ decodeHexString(/* No info */) {
    // ** addr: 0xd14c70, size: 0x174
    // 0xd14c70: EnterFrame
    //     0xd14c70: stp             fp, lr, [SP, #-0x10]!
    //     0xd14c74: mov             fp, SP
    // 0xd14c78: AllocStack(0x10)
    //     0xd14c78: sub             SP, SP, #0x10
    // 0xd14c7c: r0 = 2
    //     0xd14c7c: mov             x0, #2
    // 0xd14c80: CheckStackOverflow
    //     0xd14c80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd14c84: cmp             SP, x16
    //     0xd14c88: b.ls            #0xd14dd0
    // 0xd14c8c: ldr             x1, [fp, #0x10]
    // 0xd14c90: LoadField: r2 = r1->field_7
    //     0xd14c90: ldur            w2, [x1, #7]
    // 0xd14c94: DecompressPointer r2
    //     0xd14c94: add             x2, x2, HEAP, lsl #32
    // 0xd14c98: r3 = LoadInt32Instr(r2)
    //     0xd14c98: sbfx            x3, x2, #1, #0x1f
    // 0xd14c9c: sdiv            x2, x3, x0
    // 0xd14ca0: r16 = <int>
    //     0xd14ca0: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xd14ca4: stp             x2, x16, [SP, #-0x10]!
    // 0xd14ca8: r0 = _GrowableList()
    //     0xd14ca8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xd14cac: add             SP, SP, #0x10
    // 0xd14cb0: mov             x2, x0
    // 0xd14cb4: stur            x2, [fp, #-0x10]
    // 0xd14cb8: r3 = 0
    //     0xd14cb8: mov             x3, #0
    // 0xd14cbc: stur            x3, [fp, #-8]
    // 0xd14cc0: CheckStackOverflow
    //     0xd14cc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd14cc4: cmp             SP, x16
    //     0xd14cc8: b.ls            #0xd14dd8
    // 0xd14ccc: LoadField: r0 = r2->field_b
    //     0xd14ccc: ldur            w0, [x2, #0xb]
    // 0xd14cd0: DecompressPointer r0
    //     0xd14cd0: add             x0, x0, HEAP, lsl #32
    // 0xd14cd4: r1 = LoadInt32Instr(r0)
    //     0xd14cd4: sbfx            x1, x0, #1, #0x1f
    // 0xd14cd8: cmp             x3, x1
    // 0xd14cdc: b.ge            #0xd14da8
    // 0xd14ce0: lsl             x4, x3, #1
    // 0xd14ce4: add             x5, x4, #2
    // 0xd14ce8: r0 = BoxInt64Instr(r5)
    //     0xd14ce8: sbfiz           x0, x5, #1, #0x1f
    //     0xd14cec: cmp             x5, x0, asr #1
    //     0xd14cf0: b.eq            #0xd14cfc
    //     0xd14cf4: bl              #0xd69bb8
    //     0xd14cf8: stur            x5, [x0, #7]
    // 0xd14cfc: ldr             x16, [fp, #0x10]
    // 0xd14d00: stp             x4, x16, [SP, #-0x10]!
    // 0xd14d04: SaveReg r0
    //     0xd14d04: str             x0, [SP, #-8]!
    // 0xd14d08: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xd14d08: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xd14d0c: r0 = substring()
    //     0xd14d0c: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xd14d10: add             SP, SP, #0x18
    // 0xd14d14: r16 = 32
    //     0xd14d14: mov             x16, #0x20
    // 0xd14d18: stp             x16, x0, [SP, #-0x10]!
    // 0xd14d1c: r4 = const [0, 0x2, 0x2, 0x1, radix, 0x1, null]
    //     0xd14d1c: ldr             x4, [PP, #0xa50]  ; [pp+0xa50] List(7) [0, 0x2, 0x2, 0x1, "radix", 0x1, Null]
    // 0xd14d20: r0 = parse()
    //     0xd14d20: bl              #0x4d5d84  ; [dart:core] int::parse
    // 0xd14d24: add             SP, SP, #0x10
    // 0xd14d28: mov             x2, x0
    // 0xd14d2c: r0 = BoxInt64Instr(r2)
    //     0xd14d2c: sbfiz           x0, x2, #1, #0x1f
    //     0xd14d30: cmp             x2, x0, asr #1
    //     0xd14d34: b.eq            #0xd14d40
    //     0xd14d38: bl              #0xd69bb8
    //     0xd14d3c: stur            x2, [x0, #7]
    // 0xd14d40: mov             x3, x0
    // 0xd14d44: ldur            x2, [fp, #-0x10]
    // 0xd14d48: LoadField: r0 = r2->field_b
    //     0xd14d48: ldur            w0, [x2, #0xb]
    // 0xd14d4c: DecompressPointer r0
    //     0xd14d4c: add             x0, x0, HEAP, lsl #32
    // 0xd14d50: r1 = LoadInt32Instr(r0)
    //     0xd14d50: sbfx            x1, x0, #1, #0x1f
    // 0xd14d54: mov             x0, x1
    // 0xd14d58: ldur            x1, [fp, #-8]
    // 0xd14d5c: cmp             x1, x0
    // 0xd14d60: b.hs            #0xd14de0
    // 0xd14d64: LoadField: r1 = r2->field_f
    //     0xd14d64: ldur            w1, [x2, #0xf]
    // 0xd14d68: DecompressPointer r1
    //     0xd14d68: add             x1, x1, HEAP, lsl #32
    // 0xd14d6c: mov             x0, x3
    // 0xd14d70: ldur            x3, [fp, #-8]
    // 0xd14d74: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd14d74: add             x25, x1, x3, lsl #2
    //     0xd14d78: add             x25, x25, #0xf
    //     0xd14d7c: str             w0, [x25]
    //     0xd14d80: tbz             w0, #0, #0xd14d9c
    //     0xd14d84: ldurb           w16, [x1, #-1]
    //     0xd14d88: ldurb           w17, [x0, #-1]
    //     0xd14d8c: and             x16, x17, x16, lsr #2
    //     0xd14d90: tst             x16, HEAP, lsr #32
    //     0xd14d94: b.eq            #0xd14d9c
    //     0xd14d98: bl              #0xd67e5c
    // 0xd14d9c: add             x0, x3, #1
    // 0xd14da0: mov             x3, x0
    // 0xd14da4: b               #0xd14cbc
    // 0xd14da8: SaveReg r2
    //     0xd14da8: str             x2, [SP, #-8]!
    // 0xd14dac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xd14dac: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xd14db0: r0 = toList()
    //     0xd14db0: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0xd14db4: add             SP, SP, #8
    // 0xd14db8: stp             x0, NULL, [SP, #-0x10]!
    // 0xd14dbc: r0 = Uint8List.fromList()
    //     0xd14dbc: bl              #0x540140  ; [dart:typed_data] Uint8List::Uint8List.fromList
    // 0xd14dc0: add             SP, SP, #0x10
    // 0xd14dc4: LeaveFrame
    //     0xd14dc4: mov             SP, fp
    //     0xd14dc8: ldp             fp, lr, [SP], #0x10
    // 0xd14dcc: ret
    //     0xd14dcc: ret             
    // 0xd14dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd14dd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd14dd4: b               #0xd14c8c
    // 0xd14dd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd14dd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd14ddc: b               #0xd14ccc
    // 0xd14de0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd14de0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 4501, size: 0xc, field offset: 0x8
class SecureRandom extends Object {

  static late final Random _generator; // offset: 0xb84

  _ SecureRandom(/* No info */) {
    // ** addr: 0x58711c, size: 0x164
    // 0x58711c: EnterFrame
    //     0x58711c: stp             fp, lr, [SP, #-0x10]!
    //     0x587120: mov             fp, SP
    // 0x587124: AllocStack(0x10)
    //     0x587124: sub             SP, SP, #0x10
    // 0x587128: r0 = 16
    //     0x587128: mov             x0, #0x10
    // 0x58712c: CheckStackOverflow
    //     0x58712c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x587130: cmp             SP, x16
    //     0x587134: b.ls            #0x58726c
    // 0x587138: r16 = <int>
    //     0x587138: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x58713c: stp             x0, x16, [SP, #-0x10]!
    // 0x587140: r0 = _GrowableList()
    //     0x587140: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x587144: add             SP, SP, #0x10
    // 0x587148: stur            x0, [fp, #-0x10]
    // 0x58714c: r1 = 0
    //     0x58714c: mov             x1, #0
    // 0x587150: stur            x1, [fp, #-8]
    // 0x587154: CheckStackOverflow
    //     0x587154: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x587158: cmp             SP, x16
    //     0x58715c: b.ls            #0x587274
    // 0x587160: LoadField: r2 = r0->field_b
    //     0x587160: ldur            w2, [x0, #0xb]
    // 0x587164: DecompressPointer r2
    //     0x587164: add             x2, x2, HEAP, lsl #32
    // 0x587168: r3 = LoadInt32Instr(r2)
    //     0x587168: sbfx            x3, x2, #1, #0x1f
    // 0x58716c: cmp             x1, x3
    // 0x587170: b.ge            #0x587228
    // 0x587174: r0 = InitLateStaticField(0xb84) // [package:encrypt/encrypt.dart] SecureRandom::_generator
    //     0x587174: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x587178: ldr             x0, [x0, #0x1708]
    //     0x58717c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x587180: cmp             w0, w16
    //     0x587184: b.ne            #0x587194
    //     0x587188: add             x2, PP, #0x14, lsl #12  ; [pp+0x148d8] Field <SecureRandom._generator@401180997>: static late final (offset: 0xb84)
    //     0x58718c: ldr             x2, [x2, #0x8d8]
    //     0x587190: bl              #0xd67cdc
    // 0x587194: SaveReg r0
    //     0x587194: str             x0, [SP, #-8]!
    // 0x587198: r0 = 256
    //     0x587198: mov             x0, #0x100
    // 0x58719c: SaveReg r0
    //     0x58719c: str             x0, [SP, #-8]!
    // 0x5871a0: r0 = nextInt()
    //     0x5871a0: bl              #0x5872b0  ; [dart:math] _SecureRandom::nextInt
    // 0x5871a4: add             SP, SP, #0x10
    // 0x5871a8: mov             x2, x0
    // 0x5871ac: r0 = BoxInt64Instr(r2)
    //     0x5871ac: sbfiz           x0, x2, #1, #0x1f
    //     0x5871b0: cmp             x2, x0, asr #1
    //     0x5871b4: b.eq            #0x5871c0
    //     0x5871b8: bl              #0xd69bb8
    //     0x5871bc: stur            x2, [x0, #7]
    // 0x5871c0: mov             x3, x0
    // 0x5871c4: ldur            x2, [fp, #-0x10]
    // 0x5871c8: LoadField: r0 = r2->field_b
    //     0x5871c8: ldur            w0, [x2, #0xb]
    // 0x5871cc: DecompressPointer r0
    //     0x5871cc: add             x0, x0, HEAP, lsl #32
    // 0x5871d0: r1 = LoadInt32Instr(r0)
    //     0x5871d0: sbfx            x1, x0, #1, #0x1f
    // 0x5871d4: mov             x0, x1
    // 0x5871d8: ldur            x1, [fp, #-8]
    // 0x5871dc: cmp             x1, x0
    // 0x5871e0: b.hs            #0x58727c
    // 0x5871e4: LoadField: r1 = r2->field_f
    //     0x5871e4: ldur            w1, [x2, #0xf]
    // 0x5871e8: DecompressPointer r1
    //     0x5871e8: add             x1, x1, HEAP, lsl #32
    // 0x5871ec: mov             x0, x3
    // 0x5871f0: ldur            x3, [fp, #-8]
    // 0x5871f4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x5871f4: add             x25, x1, x3, lsl #2
    //     0x5871f8: add             x25, x25, #0xf
    //     0x5871fc: str             w0, [x25]
    //     0x587200: tbz             w0, #0, #0x58721c
    //     0x587204: ldurb           w16, [x1, #-1]
    //     0x587208: ldurb           w17, [x0, #-1]
    //     0x58720c: and             x16, x17, x16, lsr #2
    //     0x587210: tst             x16, HEAP, lsr #32
    //     0x587214: b.eq            #0x58721c
    //     0x587218: bl              #0xd67e5c
    // 0x58721c: add             x1, x3, #1
    // 0x587220: mov             x0, x2
    // 0x587224: b               #0x587150
    // 0x587228: mov             x2, x0
    // 0x58722c: ldr             x0, [fp, #0x10]
    // 0x587230: stp             x2, NULL, [SP, #-0x10]!
    // 0x587234: r0 = Uint8List.fromList()
    //     0x587234: bl              #0x540140  ; [dart:typed_data] Uint8List::Uint8List.fromList
    // 0x587238: add             SP, SP, #0x10
    // 0x58723c: ldr             x1, [fp, #0x10]
    // 0x587240: StoreField: r1->field_7 = r0
    //     0x587240: stur            w0, [x1, #7]
    //     0x587244: ldurb           w16, [x1, #-1]
    //     0x587248: ldurb           w17, [x0, #-1]
    //     0x58724c: and             x16, x17, x16, lsr #2
    //     0x587250: tst             x16, HEAP, lsr #32
    //     0x587254: b.eq            #0x58725c
    //     0x587258: bl              #0xd6826c
    // 0x58725c: r0 = Null
    //     0x58725c: mov             x0, NULL
    // 0x587260: LeaveFrame
    //     0x587260: mov             SP, fp
    //     0x587264: ldp             fp, lr, [SP], #0x10
    // 0x587268: ret
    //     0x587268: ret             
    // 0x58726c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x58726c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x587270: b               #0x587138
    // 0x587274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x587274: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x587278: b               #0x587160
    // 0x58727c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x58727c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  int dyn:get:length(SecureRandom) {
    // ** addr: 0x587298, size: 0x30
    // 0x587298: ldr             x1, [SP]
    // 0x58729c: LoadField: r2 = r1->field_7
    //     0x58729c: ldur            w2, [x1, #7]
    // 0x5872a0: DecompressPointer r2
    //     0x5872a0: add             x2, x2, HEAP, lsl #32
    // 0x5872a4: LoadField: r0 = r2->field_13
    //     0x5872a4: ldur            w0, [x2, #0x13]
    // 0x5872a8: DecompressPointer r0
    //     0x5872a8: add             x0, x0, HEAP, lsl #32
    // 0x5872ac: ret
    //     0x5872ac: ret             
  }
  static Random _generator() {
    // ** addr: 0x5874e4, size: 0x48
    // 0x5874e4: EnterFrame
    //     0x5874e4: stp             fp, lr, [SP, #-0x10]!
    //     0x5874e8: mov             fp, SP
    // 0x5874ec: CheckStackOverflow
    //     0x5874ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5874f0: cmp             SP, x16
    //     0x5874f4: b.ls            #0x587524
    // 0x5874f8: r0 = InitLateStaticField(0x5ec) // [dart:math] Random::_secureRandom
    //     0x5874f8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5874fc: ldr             x0, [x0, #0xbd8]
    //     0x587500: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x587504: cmp             w0, w16
    //     0x587508: b.ne            #0x587518
    //     0x58750c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14910] Field <Random._secureRandom@11383281>: static late final (offset: 0x5ec)
    //     0x587510: ldr             x2, [x2, #0x910]
    //     0x587514: bl              #0xd67cdc
    // 0x587518: LeaveFrame
    //     0x587518: mov             SP, fp
    //     0x58751c: ldp             fp, lr, [SP], #0x10
    // 0x587520: ret
    //     0x587520: ret             
    // 0x587524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x587524: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x587528: b               #0x5874f8
  }
}

// class id: 4502, size: 0xc, field offset: 0x8
class Encrypter extends Object {

  _ encryptBytes(/* No info */) {
    // ** addr: 0x55e868, size: 0x4c
    // 0x55e868: EnterFrame
    //     0x55e868: stp             fp, lr, [SP, #-0x10]!
    //     0x55e86c: mov             fp, SP
    // 0x55e870: CheckStackOverflow
    //     0x55e870: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55e874: cmp             SP, x16
    //     0x55e878: b.ls            #0x55e8ac
    // 0x55e87c: ldr             x0, [fp, #0x20]
    // 0x55e880: LoadField: r1 = r0->field_7
    //     0x55e880: ldur            w1, [x0, #7]
    // 0x55e884: DecompressPointer r1
    //     0x55e884: add             x1, x1, HEAP, lsl #32
    // 0x55e888: ldr             x16, [fp, #0x18]
    // 0x55e88c: stp             x16, x1, [SP, #-0x10]!
    // 0x55e890: ldr             x16, [fp, #0x10]
    // 0x55e894: SaveReg r16
    //     0x55e894: str             x16, [SP, #-8]!
    // 0x55e898: r0 = encrypt()
    //     0x55e898: bl              #0x55e8b4  ; [package:encrypt/encrypt.dart] AES::encrypt
    // 0x55e89c: add             SP, SP, #0x18
    // 0x55e8a0: LeaveFrame
    //     0x55e8a0: mov             SP, fp
    //     0x55e8a4: ldp             fp, lr, [SP], #0x10
    // 0x55e8a8: ret
    //     0x55e8a8: ret             
    // 0x55e8ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55e8ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55e8b0: b               #0x55e87c
  }
  _ encrypt(/* No info */) {
    // ** addr: 0x597084, size: 0x54
    // 0x597084: EnterFrame
    //     0x597084: stp             fp, lr, [SP, #-0x10]!
    //     0x597088: mov             fp, SP
    // 0x59708c: CheckStackOverflow
    //     0x59708c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x597090: cmp             SP, x16
    //     0x597094: b.ls            #0x5970d0
    // 0x597098: r16 = Instance_Utf8Codec
    //     0x597098: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0x59709c: ldr             lr, [fp, #0x18]
    // 0x5970a0: stp             lr, x16, [SP, #-0x10]!
    // 0x5970a4: r0 = encode()
    //     0x5970a4: bl              #0xbfcc28  ; [dart:convert] Codec::encode
    // 0x5970a8: add             SP, SP, #0x10
    // 0x5970ac: ldr             x16, [fp, #0x20]
    // 0x5970b0: stp             x0, x16, [SP, #-0x10]!
    // 0x5970b4: ldr             x16, [fp, #0x10]
    // 0x5970b8: SaveReg r16
    //     0x5970b8: str             x16, [SP, #-8]!
    // 0x5970bc: r0 = encryptBytes()
    //     0x5970bc: bl              #0x55e868  ; [package:encrypt/encrypt.dart] Encrypter::encryptBytes
    // 0x5970c0: add             SP, SP, #0x18
    // 0x5970c4: LeaveFrame
    //     0x5970c4: mov             SP, fp
    //     0x5970c8: ldp             fp, lr, [SP], #0x10
    // 0x5970cc: ret
    //     0x5970cc: ret             
    // 0x5970d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5970d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5970d4: b               #0x597098
  }
  _ decryptBytes(/* No info */) {
    // ** addr: 0x59a77c, size: 0x74
    // 0x59a77c: EnterFrame
    //     0x59a77c: stp             fp, lr, [SP, #-0x10]!
    //     0x59a780: mov             fp, SP
    // 0x59a784: CheckStackOverflow
    //     0x59a784: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x59a788: cmp             SP, x16
    //     0x59a78c: b.ls            #0x59a7e8
    // 0x59a790: ldr             x0, [fp, #0x20]
    // 0x59a794: LoadField: r1 = r0->field_7
    //     0x59a794: ldur            w1, [x0, #7]
    // 0x59a798: DecompressPointer r1
    //     0x59a798: add             x1, x1, HEAP, lsl #32
    // 0x59a79c: ldr             x16, [fp, #0x18]
    // 0x59a7a0: stp             x16, x1, [SP, #-0x10]!
    // 0x59a7a4: ldr             x16, [fp, #0x10]
    // 0x59a7a8: SaveReg r16
    //     0x59a7a8: str             x16, [SP, #-8]!
    // 0x59a7ac: r0 = decrypt()
    //     0x59a7ac: bl              #0x59a7f0  ; [package:encrypt/encrypt.dart] AES::decrypt
    // 0x59a7b0: add             SP, SP, #0x18
    // 0x59a7b4: r1 = LoadClassIdInstr(r0)
    //     0x59a7b4: ldur            x1, [x0, #-1]
    //     0x59a7b8: ubfx            x1, x1, #0xc, #0x14
    // 0x59a7bc: SaveReg r0
    //     0x59a7bc: str             x0, [SP, #-8]!
    // 0x59a7c0: mov             x0, x1
    // 0x59a7c4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x59a7c4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x59a7c8: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0x59a7c8: mov             x17, #0xc8a1
    //     0x59a7cc: add             lr, x0, x17
    //     0x59a7d0: ldr             lr, [x21, lr, lsl #3]
    //     0x59a7d4: blr             lr
    // 0x59a7d8: add             SP, SP, #8
    // 0x59a7dc: LeaveFrame
    //     0x59a7dc: mov             SP, fp
    //     0x59a7e0: ldp             fp, lr, [SP], #0x10
    // 0x59a7e4: ret
    //     0x59a7e4: ret             
    // 0x59a7e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59a7e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59a7ec: b               #0x59a790
  }
  _ decrypt(/* No info */) {
    // ** addr: 0xd14c10, size: 0x60
    // 0xd14c10: EnterFrame
    //     0xd14c10: stp             fp, lr, [SP, #-0x10]!
    //     0xd14c14: mov             fp, SP
    // 0xd14c18: CheckStackOverflow
    //     0xd14c18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd14c1c: cmp             SP, x16
    //     0xd14c20: b.ls            #0xd14c68
    // 0xd14c24: ldr             x16, [fp, #0x20]
    // 0xd14c28: ldr             lr, [fp, #0x18]
    // 0xd14c2c: stp             lr, x16, [SP, #-0x10]!
    // 0xd14c30: ldr             x16, [fp, #0x10]
    // 0xd14c34: SaveReg r16
    //     0xd14c34: str             x16, [SP, #-8]!
    // 0xd14c38: r0 = decryptBytes()
    //     0xd14c38: bl              #0x59a77c  ; [package:encrypt/encrypt.dart] Encrypter::decryptBytes
    // 0xd14c3c: add             SP, SP, #0x18
    // 0xd14c40: r16 = Instance_Utf8Codec
    //     0xd14c40: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xd14c44: stp             x0, x16, [SP, #-0x10]!
    // 0xd14c48: r16 = true
    //     0xd14c48: add             x16, NULL, #0x20  ; true
    // 0xd14c4c: SaveReg r16
    //     0xd14c4c: str             x16, [SP, #-8]!
    // 0xd14c50: r4 = const [0, 0x3, 0x3, 0x2, allowMalformed, 0x2, null]
    //     0xd14c50: ldr             x4, [PP, #0x2818]  ; [pp+0x2818] List(7) [0, 0x3, 0x3, 0x2, "allowMalformed", 0x2, Null]
    // 0xd14c54: r0 = decode()
    //     0xd14c54: bl              #0x4e1c78  ; [dart:convert] Utf8Codec::decode
    // 0xd14c58: add             SP, SP, #0x18
    // 0xd14c5c: LeaveFrame
    //     0xd14c5c: mov             SP, fp
    //     0xd14c60: ldp             fp, lr, [SP], #0x10
    // 0xd14c64: ret
    //     0xd14c64: ret             
    // 0xd14c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd14c68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd14c6c: b               #0xd14c24
  }
}

// class id: 4503, size: 0xc, field offset: 0x8
class Encrypted extends Object {

  get _ base16(/* No info */) {
    // ** addr: 0x596e8c, size: 0x94
    // 0x596e8c: EnterFrame
    //     0x596e8c: stp             fp, lr, [SP, #-0x10]!
    //     0x596e90: mov             fp, SP
    // 0x596e94: AllocStack(0x8)
    //     0x596e94: sub             SP, SP, #8
    // 0x596e98: CheckStackOverflow
    //     0x596e98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x596e9c: cmp             SP, x16
    //     0x596ea0: b.ls            #0x596f18
    // 0x596ea4: ldr             x0, [fp, #0x10]
    // 0x596ea8: LoadField: r3 = r0->field_7
    //     0x596ea8: ldur            w3, [x0, #7]
    // 0x596eac: DecompressPointer r3
    //     0x596eac: add             x3, x3, HEAP, lsl #32
    // 0x596eb0: stur            x3, [fp, #-8]
    // 0x596eb4: r1 = Function '<anonymous closure>':.
    //     0x596eb4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfaf8] AnonymousClosure: (0x596f20), in [dart:ui] KeyData::_quotedCharCode (0x596f74)
    //     0x596eb8: ldr             x1, [x1, #0xaf8]
    // 0x596ebc: r2 = Null
    //     0x596ebc: mov             x2, NULL
    // 0x596ec0: r0 = AllocateClosure()
    //     0x596ec0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x596ec4: mov             x1, x0
    // 0x596ec8: ldur            x0, [fp, #-8]
    // 0x596ecc: r2 = LoadClassIdInstr(r0)
    //     0x596ecc: ldur            x2, [x0, #-1]
    //     0x596ed0: ubfx            x2, x2, #0xc, #0x14
    // 0x596ed4: r16 = <String>
    //     0x596ed4: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x596ed8: stp             x0, x16, [SP, #-0x10]!
    // 0x596edc: SaveReg r1
    //     0x596edc: str             x1, [SP, #-8]!
    // 0x596ee0: mov             x0, x2
    // 0x596ee4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x596ee4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x596ee8: r0 = GDT[cid_x0 + 0xc934]()
    //     0x596ee8: mov             x17, #0xc934
    //     0x596eec: add             lr, x0, x17
    //     0x596ef0: ldr             lr, [x21, lr, lsl #3]
    //     0x596ef4: blr             lr
    // 0x596ef8: add             SP, SP, #0x18
    // 0x596efc: SaveReg r0
    //     0x596efc: str             x0, [SP, #-8]!
    // 0x596f00: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x596f00: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x596f04: r0 = join()
    //     0x596f04: bl              #0x6a9d88  ; [dart:core] Iterable::join
    // 0x596f08: add             SP, SP, #8
    // 0x596f0c: LeaveFrame
    //     0x596f0c: mov             SP, fp
    //     0x596f10: ldp             fp, lr, [SP], #0x10
    // 0x596f14: ret
    //     0x596f14: ret             
    // 0x596f18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x596f18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x596f1c: b               #0x596ea4
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6f540, size: 0xb0
    // 0xc6f540: EnterFrame
    //     0xc6f540: stp             fp, lr, [SP, #-0x10]!
    //     0xc6f544: mov             fp, SP
    // 0xc6f548: CheckStackOverflow
    //     0xc6f548: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6f54c: cmp             SP, x16
    //     0xc6f550: b.ls            #0xc6f5e8
    // 0xc6f554: ldr             x0, [fp, #0x10]
    // 0xc6f558: cmp             w0, NULL
    // 0xc6f55c: b.ne            #0xc6f570
    // 0xc6f560: r0 = false
    //     0xc6f560: add             x0, NULL, #0x30  ; false
    // 0xc6f564: LeaveFrame
    //     0xc6f564: mov             SP, fp
    //     0xc6f568: ldp             fp, lr, [SP], #0x10
    // 0xc6f56c: ret
    //     0xc6f56c: ret             
    // 0xc6f570: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6f570: mov             x1, #0x76
    //     0xc6f574: tbz             w0, #0, #0xc6f584
    //     0xc6f578: ldur            x1, [x0, #-1]
    //     0xc6f57c: ubfx            x1, x1, #0xc, #0x14
    //     0xc6f580: lsl             x1, x1, #1
    // 0xc6f584: r2 = LoadInt32Instr(r1)
    //     0xc6f584: sbfx            x2, x1, #1, #0x1f
    // 0xc6f588: r17 = 4503
    //     0xc6f588: mov             x17, #0x1197
    // 0xc6f58c: cmp             x2, x17
    // 0xc6f590: b.lt            #0xc6f5d8
    // 0xc6f594: r17 = 4505
    //     0xc6f594: mov             x17, #0x1199
    // 0xc6f598: cmp             x2, x17
    // 0xc6f59c: b.gt            #0xc6f5d8
    // 0xc6f5a0: ldr             x1, [fp, #0x18]
    // 0xc6f5a4: LoadField: r2 = r1->field_7
    //     0xc6f5a4: ldur            w2, [x1, #7]
    // 0xc6f5a8: DecompressPointer r2
    //     0xc6f5a8: add             x2, x2, HEAP, lsl #32
    // 0xc6f5ac: LoadField: r1 = r0->field_7
    //     0xc6f5ac: ldur            w1, [x0, #7]
    // 0xc6f5b0: DecompressPointer r1
    //     0xc6f5b0: add             x1, x1, HEAP, lsl #32
    // 0xc6f5b4: r16 = Instance_ListEquality
    //     0xc6f5b4: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d550] Obj!ListEquality@b5c7f1
    //     0xc6f5b8: ldr             x16, [x16, #0x550]
    // 0xc6f5bc: stp             x2, x16, [SP, #-0x10]!
    // 0xc6f5c0: SaveReg r1
    //     0xc6f5c0: str             x1, [SP, #-8]!
    // 0xc6f5c4: r0 = equals()
    //     0xc6f5c4: bl              #0xc06dd8  ; [package:collection/src/equality.dart] ListEquality::equals
    // 0xc6f5c8: add             SP, SP, #0x18
    // 0xc6f5cc: LeaveFrame
    //     0xc6f5cc: mov             SP, fp
    //     0xc6f5d0: ldp             fp, lr, [SP], #0x10
    // 0xc6f5d4: ret
    //     0xc6f5d4: ret             
    // 0xc6f5d8: r0 = false
    //     0xc6f5d8: add             x0, NULL, #0x30  ; false
    // 0xc6f5dc: LeaveFrame
    //     0xc6f5dc: mov             SP, fp
    //     0xc6f5e0: ldp             fp, lr, [SP], #0x10
    // 0xc6f5e4: ret
    //     0xc6f5e4: ret             
    // 0xc6f5e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6f5e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6f5ec: b               #0xc6f554
  }
}

// class id: 4504, size: 0xc, field offset: 0xc
class Key extends Encrypted {

  int dyn:get:length(Key) {
    // ** addr: 0x587678, size: 0x68
    // 0x587678: EnterFrame
    //     0x587678: stp             fp, lr, [SP, #-0x10]!
    //     0x58767c: mov             fp, SP
    // 0x587680: CheckStackOverflow
    //     0x587680: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x587684: cmp             SP, x16
    //     0x587688: b.ls            #0x5876c0
    // 0x58768c: ldr             x16, [fp, #0x10]
    // 0x587690: SaveReg r16
    //     0x587690: str             x16, [SP, #-8]!
    // 0x587694: r0 = length()
    //     0x587694: bl              #0x5876c8  ; [package:encrypt/encrypt.dart] Key::length
    // 0x587698: add             SP, SP, #8
    // 0x58769c: mov             x2, x0
    // 0x5876a0: r0 = BoxInt64Instr(r2)
    //     0x5876a0: sbfiz           x0, x2, #1, #0x1f
    //     0x5876a4: cmp             x2, x0, asr #1
    //     0x5876a8: b.eq            #0x5876b4
    //     0x5876ac: bl              #0xd69bb8
    //     0x5876b0: stur            x2, [x0, #7]
    // 0x5876b4: LeaveFrame
    //     0x5876b4: mov             SP, fp
    //     0x5876b8: ldp             fp, lr, [SP], #0x10
    // 0x5876bc: ret
    //     0x5876bc: ret             
    // 0x5876c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5876c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5876c4: b               #0x58768c
  }
  int length(Key) {
    // ** addr: 0x5876c8, size: 0x54
    // 0x5876c8: EnterFrame
    //     0x5876c8: stp             fp, lr, [SP, #-0x10]!
    //     0x5876cc: mov             fp, SP
    // 0x5876d0: CheckStackOverflow
    //     0x5876d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5876d4: cmp             SP, x16
    //     0x5876d8: b.ls            #0x587714
    // 0x5876dc: ldr             x0, [fp, #0x10]
    // 0x5876e0: LoadField: r1 = r0->field_7
    //     0x5876e0: ldur            w1, [x0, #7]
    // 0x5876e4: DecompressPointer r1
    //     0x5876e4: add             x1, x1, HEAP, lsl #32
    // 0x5876e8: r0 = LoadClassIdInstr(r1)
    //     0x5876e8: ldur            x0, [x1, #-1]
    //     0x5876ec: ubfx            x0, x0, #0xc, #0x14
    // 0x5876f0: SaveReg r1
    //     0x5876f0: str             x1, [SP, #-8]!
    // 0x5876f4: r0 = GDT[cid_x0 + 0x3b2f]()
    //     0x5876f4: mov             x17, #0x3b2f
    //     0x5876f8: add             lr, x0, x17
    //     0x5876fc: ldr             lr, [x21, lr, lsl #3]
    //     0x587700: blr             lr
    // 0x587704: add             SP, SP, #8
    // 0x587708: LeaveFrame
    //     0x587708: mov             SP, fp
    //     0x58770c: ldp             fp, lr, [SP], #0x10
    // 0x587710: ret
    //     0x587710: ret             
    // 0x587714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x587714: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x587718: b               #0x5876dc
  }
}

// class id: 4505, size: 0xc, field offset: 0xc
class IV extends Encrypted {
}

// class id: 4506, size: 0x1c, field offset: 0x8
class AES extends Object
    implements Algorithm {

  _ encrypt(/* No info */) {
    // ** addr: 0x55e8b4, size: 0x184
    // 0x55e8b4: EnterFrame
    //     0x55e8b4: stp             fp, lr, [SP, #-0x10]!
    //     0x55e8b8: mov             fp, SP
    // 0x55e8bc: AllocStack(0x8)
    //     0x55e8bc: sub             SP, SP, #8
    // 0x55e8c0: CheckStackOverflow
    //     0x55e8c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55e8c4: cmp             SP, x16
    //     0x55e8c8: b.ls            #0x55ea30
    // 0x55e8cc: ldr             x1, [fp, #0x20]
    // 0x55e8d0: LoadField: r2 = r1->field_17
    //     0x55e8d0: ldur            w2, [x1, #0x17]
    // 0x55e8d4: DecompressPointer r2
    //     0x55e8d4: add             x2, x2, HEAP, lsl #32
    // 0x55e8d8: stur            x2, [fp, #-8]
    // 0x55e8dc: cmp             w2, NULL
    // 0x55e8e0: b.eq            #0x55e984
    // 0x55e8e4: r0 = LoadClassIdInstr(r2)
    //     0x55e8e4: ldur            x0, [x2, #-1]
    //     0x55e8e8: ubfx            x0, x0, #0xc, #0x14
    // 0x55e8ec: SaveReg r2
    //     0x55e8ec: str             x2, [SP, #-8]!
    // 0x55e8f0: r0 = GDT[cid_x0 + -0xff6]()
    //     0x55e8f0: sub             lr, x0, #0xff6
    //     0x55e8f4: ldr             lr, [x21, lr, lsl #3]
    //     0x55e8f8: blr             lr
    // 0x55e8fc: add             SP, SP, #8
    // 0x55e900: ldr             x16, [fp, #0x20]
    // 0x55e904: ldr             lr, [fp, #0x10]
    // 0x55e908: stp             lr, x16, [SP, #-0x10]!
    // 0x55e90c: r0 = _buildParams()
    //     0x55e90c: bl              #0x55ea44  ; [package:encrypt/encrypt.dart] AES::_buildParams
    // 0x55e910: add             SP, SP, #0x10
    // 0x55e914: ldur            x1, [fp, #-8]
    // 0x55e918: r2 = LoadClassIdInstr(r1)
    //     0x55e918: ldur            x2, [x1, #-1]
    //     0x55e91c: ubfx            x2, x2, #0xc, #0x14
    // 0x55e920: stp             x0, x1, [SP, #-0x10]!
    // 0x55e924: mov             x0, x2
    // 0x55e928: r0 = GDT[cid_x0 + -0xfdf]()
    //     0x55e928: sub             lr, x0, #0xfdf
    //     0x55e92c: ldr             lr, [x21, lr, lsl #3]
    //     0x55e930: blr             lr
    // 0x55e934: add             SP, SP, #0x10
    // 0x55e938: ldur            x0, [fp, #-8]
    // 0x55e93c: r1 = LoadClassIdInstr(r0)
    //     0x55e93c: ldur            x1, [x0, #-1]
    //     0x55e940: ubfx            x1, x1, #0xc, #0x14
    // 0x55e944: ldr             x16, [fp, #0x18]
    // 0x55e948: stp             x16, x0, [SP, #-0x10]!
    // 0x55e94c: mov             x0, x1
    // 0x55e950: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x55e950: sub             lr, x0, #0xfd9
    //     0x55e954: ldr             lr, [x21, lr, lsl #3]
    //     0x55e958: blr             lr
    // 0x55e95c: add             SP, SP, #0x10
    // 0x55e960: stur            x0, [fp, #-8]
    // 0x55e964: r0 = Encrypted()
    //     0x55e964: bl              #0x55ea38  ; AllocateEncryptedStub -> Encrypted (size=0xc)
    // 0x55e968: mov             x1, x0
    // 0x55e96c: ldur            x0, [fp, #-8]
    // 0x55e970: StoreField: r1->field_7 = r0
    //     0x55e970: stur            w0, [x1, #7]
    // 0x55e974: mov             x0, x1
    // 0x55e978: LeaveFrame
    //     0x55e978: mov             SP, fp
    //     0x55e97c: ldp             fp, lr, [SP], #0x10
    // 0x55e980: ret
    //     0x55e980: ret             
    // 0x55e984: LoadField: r2 = r1->field_13
    //     0x55e984: ldur            w2, [x1, #0x13]
    // 0x55e988: DecompressPointer r2
    //     0x55e988: add             x2, x2, HEAP, lsl #32
    // 0x55e98c: stur            x2, [fp, #-8]
    // 0x55e990: r0 = LoadClassIdInstr(r2)
    //     0x55e990: ldur            x0, [x2, #-1]
    //     0x55e994: ubfx            x0, x0, #0xc, #0x14
    // 0x55e998: SaveReg r2
    //     0x55e998: str             x2, [SP, #-8]!
    // 0x55e99c: r0 = GDT[cid_x0 + -0xee7]()
    //     0x55e99c: sub             lr, x0, #0xee7
    //     0x55e9a0: ldr             lr, [x21, lr, lsl #3]
    //     0x55e9a4: blr             lr
    // 0x55e9a8: add             SP, SP, #8
    // 0x55e9ac: ldr             x16, [fp, #0x20]
    // 0x55e9b0: ldr             lr, [fp, #0x10]
    // 0x55e9b4: stp             lr, x16, [SP, #-0x10]!
    // 0x55e9b8: r0 = _buildParams()
    //     0x55e9b8: bl              #0x55ea44  ; [package:encrypt/encrypt.dart] AES::_buildParams
    // 0x55e9bc: add             SP, SP, #0x10
    // 0x55e9c0: ldur            x1, [fp, #-8]
    // 0x55e9c4: r2 = LoadClassIdInstr(r1)
    //     0x55e9c4: ldur            x2, [x1, #-1]
    //     0x55e9c8: ubfx            x2, x2, #0xc, #0x14
    // 0x55e9cc: r16 = true
    //     0x55e9cc: add             x16, NULL, #0x20  ; true
    // 0x55e9d0: stp             x16, x1, [SP, #-0x10]!
    // 0x55e9d4: SaveReg r0
    //     0x55e9d4: str             x0, [SP, #-8]!
    // 0x55e9d8: mov             x0, x2
    // 0x55e9dc: r0 = GDT[cid_x0 + -0xf82]()
    //     0x55e9dc: sub             lr, x0, #0xf82
    //     0x55e9e0: ldr             lr, [x21, lr, lsl #3]
    //     0x55e9e4: blr             lr
    // 0x55e9e8: add             SP, SP, #0x18
    // 0x55e9ec: ldur            x0, [fp, #-8]
    // 0x55e9f0: r1 = LoadClassIdInstr(r0)
    //     0x55e9f0: ldur            x1, [x0, #-1]
    //     0x55e9f4: ubfx            x1, x1, #0xc, #0x14
    // 0x55e9f8: ldr             x16, [fp, #0x18]
    // 0x55e9fc: stp             x16, x0, [SP, #-0x10]!
    // 0x55ea00: mov             x0, x1
    // 0x55ea04: r0 = GDT[cid_x0 + -0xc97]()
    //     0x55ea04: sub             lr, x0, #0xc97
    //     0x55ea08: ldr             lr, [x21, lr, lsl #3]
    //     0x55ea0c: blr             lr
    // 0x55ea10: add             SP, SP, #0x10
    // 0x55ea14: stur            x0, [fp, #-8]
    // 0x55ea18: r0 = Encrypted()
    //     0x55ea18: bl              #0x55ea38  ; AllocateEncryptedStub -> Encrypted (size=0xc)
    // 0x55ea1c: ldur            x1, [fp, #-8]
    // 0x55ea20: StoreField: r0->field_7 = r1
    //     0x55ea20: stur            w1, [x0, #7]
    // 0x55ea24: LeaveFrame
    //     0x55ea24: mov             SP, fp
    //     0x55ea28: ldp             fp, lr, [SP], #0x10
    // 0x55ea2c: ret
    //     0x55ea2c: ret             
    // 0x55ea30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55ea30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55ea34: b               #0x55e8cc
  }
  _ _buildParams(/* No info */) {
    // ** addr: 0x55ea44, size: 0x3c
    // 0x55ea44: EnterFrame
    //     0x55ea44: stp             fp, lr, [SP, #-0x10]!
    //     0x55ea48: mov             fp, SP
    // 0x55ea4c: CheckStackOverflow
    //     0x55ea4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55ea50: cmp             SP, x16
    //     0x55ea54: b.ls            #0x55ea78
    // 0x55ea58: ldr             x16, [fp, #0x18]
    // 0x55ea5c: ldr             lr, [fp, #0x10]
    // 0x55ea60: stp             lr, x16, [SP, #-0x10]!
    // 0x55ea64: r0 = _paddedParams()
    //     0x55ea64: bl              #0x55ea80  ; [package:encrypt/encrypt.dart] AES::_paddedParams
    // 0x55ea68: add             SP, SP, #0x10
    // 0x55ea6c: LeaveFrame
    //     0x55ea6c: mov             SP, fp
    //     0x55ea70: ldp             fp, lr, [SP], #0x10
    // 0x55ea74: ret
    //     0x55ea74: ret             
    // 0x55ea78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55ea78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55ea7c: b               #0x55ea58
  }
  _ _paddedParams(/* No info */) {
    // ** addr: 0x55ea80, size: 0xf8
    // 0x55ea80: EnterFrame
    //     0x55ea80: stp             fp, lr, [SP, #-0x10]!
    //     0x55ea84: mov             fp, SP
    // 0x55ea88: AllocStack(0x18)
    //     0x55ea88: sub             SP, SP, #0x18
    // 0x55ea8c: ldr             x0, [fp, #0x18]
    // 0x55ea90: LoadField: r1 = r0->field_b
    //     0x55ea90: ldur            w1, [x0, #0xb]
    // 0x55ea94: DecompressPointer r1
    //     0x55ea94: add             x1, x1, HEAP, lsl #32
    // 0x55ea98: r16 = Instance_AESMode
    //     0x55ea98: add             x16, PP, #0xf, lsl #12  ; [pp+0xfaf0] Obj!AESMode@b662b1
    //     0x55ea9c: ldr             x16, [x16, #0xaf0]
    // 0x55eaa0: cmp             w1, w16
    // 0x55eaa4: b.ne            #0x55eaf8
    // 0x55eaa8: LoadField: r1 = r0->field_7
    //     0x55eaa8: ldur            w1, [x0, #7]
    // 0x55eaac: DecompressPointer r1
    //     0x55eaac: add             x1, x1, HEAP, lsl #32
    // 0x55eab0: LoadField: r0 = r1->field_7
    //     0x55eab0: ldur            w0, [x1, #7]
    // 0x55eab4: DecompressPointer r0
    //     0x55eab4: add             x0, x0, HEAP, lsl #32
    // 0x55eab8: stur            x0, [fp, #-8]
    // 0x55eabc: r0 = KeyParameter()
    //     0x55eabc: bl              #0x55eb90  ; AllocateKeyParameterStub -> KeyParameter (size=0xc)
    // 0x55eac0: mov             x2, x0
    // 0x55eac4: ldur            x0, [fp, #-8]
    // 0x55eac8: stur            x2, [fp, #-0x10]
    // 0x55eacc: StoreField: r2->field_7 = r0
    //     0x55eacc: stur            w0, [x2, #7]
    // 0x55ead0: r1 = <CipherParameters?, CipherParameters?>
    //     0x55ead0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfb00] TypeArguments: <CipherParameters?, CipherParameters?>
    //     0x55ead4: ldr             x1, [x1, #0xb00]
    // 0x55ead8: r0 = PaddedBlockCipherParameters()
    //     0x55ead8: bl              #0x55eb84  ; AllocatePaddedBlockCipherParametersStub -> PaddedBlockCipherParameters<X0 bound CipherParameters?, X1 bound CipherParameters?> (size=0x14)
    // 0x55eadc: mov             x1, x0
    // 0x55eae0: ldur            x0, [fp, #-0x10]
    // 0x55eae4: StoreField: r1->field_b = r0
    //     0x55eae4: stur            w0, [x1, #0xb]
    // 0x55eae8: mov             x0, x1
    // 0x55eaec: LeaveFrame
    //     0x55eaec: mov             SP, fp
    //     0x55eaf0: ldp             fp, lr, [SP], #0x10
    // 0x55eaf4: ret
    //     0x55eaf4: ret             
    // 0x55eaf8: ldr             x1, [fp, #0x10]
    // 0x55eafc: LoadField: r2 = r0->field_7
    //     0x55eafc: ldur            w2, [x0, #7]
    // 0x55eb00: DecompressPointer r2
    //     0x55eb00: add             x2, x2, HEAP, lsl #32
    // 0x55eb04: LoadField: r0 = r2->field_7
    //     0x55eb04: ldur            w0, [x2, #7]
    // 0x55eb08: DecompressPointer r0
    //     0x55eb08: add             x0, x0, HEAP, lsl #32
    // 0x55eb0c: stur            x0, [fp, #-8]
    // 0x55eb10: r0 = KeyParameter()
    //     0x55eb10: bl              #0x55eb90  ; AllocateKeyParameterStub -> KeyParameter (size=0xc)
    // 0x55eb14: mov             x2, x0
    // 0x55eb18: ldur            x0, [fp, #-8]
    // 0x55eb1c: stur            x2, [fp, #-0x10]
    // 0x55eb20: StoreField: r2->field_7 = r0
    //     0x55eb20: stur            w0, [x2, #7]
    // 0x55eb24: ldr             x0, [fp, #0x10]
    // 0x55eb28: LoadField: r3 = r0->field_7
    //     0x55eb28: ldur            w3, [x0, #7]
    // 0x55eb2c: DecompressPointer r3
    //     0x55eb2c: add             x3, x3, HEAP, lsl #32
    // 0x55eb30: stur            x3, [fp, #-8]
    // 0x55eb34: r1 = <KeyParameter>
    //     0x55eb34: add             x1, PP, #0xf, lsl #12  ; [pp+0xfb08] TypeArguments: <KeyParameter>
    //     0x55eb38: ldr             x1, [x1, #0xb08]
    // 0x55eb3c: r0 = ParametersWithIV()
    //     0x55eb3c: bl              #0x55eb78  ; AllocateParametersWithIVStub -> ParametersWithIV<X0 bound CipherParameters?> (size=0x14)
    // 0x55eb40: mov             x2, x0
    // 0x55eb44: ldur            x0, [fp, #-0x10]
    // 0x55eb48: stur            x2, [fp, #-0x18]
    // 0x55eb4c: StoreField: r2->field_f = r0
    //     0x55eb4c: stur            w0, [x2, #0xf]
    // 0x55eb50: ldur            x0, [fp, #-8]
    // 0x55eb54: StoreField: r2->field_b = r0
    //     0x55eb54: stur            w0, [x2, #0xb]
    // 0x55eb58: r1 = <CipherParameters?, CipherParameters?>
    //     0x55eb58: add             x1, PP, #0xf, lsl #12  ; [pp+0xfb00] TypeArguments: <CipherParameters?, CipherParameters?>
    //     0x55eb5c: ldr             x1, [x1, #0xb00]
    // 0x55eb60: r0 = PaddedBlockCipherParameters()
    //     0x55eb60: bl              #0x55eb84  ; AllocatePaddedBlockCipherParametersStub -> PaddedBlockCipherParameters<X0 bound CipherParameters?, X1 bound CipherParameters?> (size=0x14)
    // 0x55eb64: ldur            x1, [fp, #-0x18]
    // 0x55eb68: StoreField: r0->field_b = r1
    //     0x55eb68: stur            w1, [x0, #0xb]
    // 0x55eb6c: LeaveFrame
    //     0x55eb6c: mov             SP, fp
    //     0x55eb70: ldp             fp, lr, [SP], #0x10
    // 0x55eb74: ret
    //     0x55eb74: ret             
  }
  _ AES(/* No info */) {
    // ** addr: 0x55eba8, size: 0x12c
    // 0x55eba8: EnterFrame
    //     0x55eba8: stp             fp, lr, [SP, #-0x10]!
    //     0x55ebac: mov             fp, SP
    // 0x55ebb0: AllocStack(0x8)
    //     0x55ebb0: sub             SP, SP, #8
    // 0x55ebb4: r1 = "PKCS7"
    //     0x55ebb4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfb10] "PKCS7"
    //     0x55ebb8: ldr             x1, [x1, #0xb10]
    // 0x55ebbc: CheckStackOverflow
    //     0x55ebbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55ebc0: cmp             SP, x16
    //     0x55ebc4: b.ls            #0x55eccc
    // 0x55ebc8: ldr             x0, [fp, #0x18]
    // 0x55ebcc: ldr             x3, [fp, #0x20]
    // 0x55ebd0: StoreField: r3->field_7 = r0
    //     0x55ebd0: stur            w0, [x3, #7]
    //     0x55ebd4: ldurb           w16, [x3, #-1]
    //     0x55ebd8: ldurb           w17, [x0, #-1]
    //     0x55ebdc: and             x16, x17, x16, lsr #2
    //     0x55ebe0: tst             x16, HEAP, lsr #32
    //     0x55ebe4: b.eq            #0x55ebec
    //     0x55ebe8: bl              #0xd682ac
    // 0x55ebec: ldr             x0, [fp, #0x10]
    // 0x55ebf0: StoreField: r3->field_b = r0
    //     0x55ebf0: stur            w0, [x3, #0xb]
    //     0x55ebf4: ldurb           w16, [x3, #-1]
    //     0x55ebf8: ldurb           w17, [x0, #-1]
    //     0x55ebfc: and             x16, x17, x16, lsr #2
    //     0x55ec00: tst             x16, HEAP, lsr #32
    //     0x55ec04: b.eq            #0x55ec0c
    //     0x55ec08: bl              #0xd682ac
    // 0x55ec0c: StoreField: r3->field_f = r1
    //     0x55ec0c: stur            w1, [x3, #0xf]
    // 0x55ec10: r1 = Null
    //     0x55ec10: mov             x1, NULL
    // 0x55ec14: r2 = 8
    //     0x55ec14: mov             x2, #8
    // 0x55ec18: r0 = AllocateArray()
    //     0x55ec18: bl              #0xd6987c  ; AllocateArrayStub
    // 0x55ec1c: stur            x0, [fp, #-8]
    // 0x55ec20: r17 = "AES/"
    //     0x55ec20: add             x17, PP, #0xf, lsl #12  ; [pp+0xfb18] "AES/"
    //     0x55ec24: ldr             x17, [x17, #0xb18]
    // 0x55ec28: StoreField: r0->field_f = r17
    //     0x55ec28: stur            w17, [x0, #0xf]
    // 0x55ec2c: r16 = _ConstMap len:7
    //     0x55ec2c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb20] Map<AESMode, String>(7)
    //     0x55ec30: ldr             x16, [x16, #0xb20]
    // 0x55ec34: ldr             lr, [fp, #0x10]
    // 0x55ec38: stp             lr, x16, [SP, #-0x10]!
    // 0x55ec3c: r0 = []()
    //     0x55ec3c: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x55ec40: add             SP, SP, #0x10
    // 0x55ec44: ldur            x1, [fp, #-8]
    // 0x55ec48: ArrayStore: r1[1] = r0  ; List_4
    //     0x55ec48: add             x25, x1, #0x13
    //     0x55ec4c: str             w0, [x25]
    //     0x55ec50: tbz             w0, #0, #0x55ec6c
    //     0x55ec54: ldurb           w16, [x1, #-1]
    //     0x55ec58: ldurb           w17, [x0, #-1]
    //     0x55ec5c: and             x16, x17, x16, lsr #2
    //     0x55ec60: tst             x16, HEAP, lsr #32
    //     0x55ec64: b.eq            #0x55ec6c
    //     0x55ec68: bl              #0xd67e5c
    // 0x55ec6c: ldur            x0, [fp, #-8]
    // 0x55ec70: r17 = "/"
    //     0x55ec70: ldr             x17, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x55ec74: StoreField: r0->field_17 = r17
    //     0x55ec74: stur            w17, [x0, #0x17]
    // 0x55ec78: r17 = "PKCS7"
    //     0x55ec78: add             x17, PP, #0xf, lsl #12  ; [pp+0xfb10] "PKCS7"
    //     0x55ec7c: ldr             x17, [x17, #0xb10]
    // 0x55ec80: StoreField: r0->field_1b = r17
    //     0x55ec80: stur            w17, [x0, #0x1b]
    // 0x55ec84: SaveReg r0
    //     0x55ec84: str             x0, [SP, #-8]!
    // 0x55ec88: r0 = _interpolate()
    //     0x55ec88: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x55ec8c: add             SP, SP, #8
    // 0x55ec90: stp             x0, NULL, [SP, #-0x10]!
    // 0x55ec94: r0 = PaddedBlockCipher()
    //     0x55ec94: bl              #0x55ecd4  ; [package:pointycastle/api.dart] PaddedBlockCipher::PaddedBlockCipher
    // 0x55ec98: add             SP, SP, #0x10
    // 0x55ec9c: ldr             x1, [fp, #0x20]
    // 0x55eca0: StoreField: r1->field_13 = r0
    //     0x55eca0: stur            w0, [x1, #0x13]
    //     0x55eca4: ldurb           w16, [x1, #-1]
    //     0x55eca8: ldurb           w17, [x0, #-1]
    //     0x55ecac: and             x16, x17, x16, lsr #2
    //     0x55ecb0: tst             x16, HEAP, lsr #32
    //     0x55ecb4: b.eq            #0x55ecbc
    //     0x55ecb8: bl              #0xd6826c
    // 0x55ecbc: r0 = Null
    //     0x55ecbc: mov             x0, NULL
    // 0x55ecc0: LeaveFrame
    //     0x55ecc0: mov             SP, fp
    //     0x55ecc4: ldp             fp, lr, [SP], #0x10
    // 0x55ecc8: ret
    //     0x55ecc8: ret             
    // 0x55eccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55eccc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55ecd0: b               #0x55ebc8
  }
  _ decrypt(/* No info */) {
    // ** addr: 0x59a7f0, size: 0x178
    // 0x59a7f0: EnterFrame
    //     0x59a7f0: stp             fp, lr, [SP, #-0x10]!
    //     0x59a7f4: mov             fp, SP
    // 0x59a7f8: AllocStack(0x8)
    //     0x59a7f8: sub             SP, SP, #8
    // 0x59a7fc: CheckStackOverflow
    //     0x59a7fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x59a800: cmp             SP, x16
    //     0x59a804: b.ls            #0x59a960
    // 0x59a808: ldr             x1, [fp, #0x20]
    // 0x59a80c: LoadField: r2 = r1->field_17
    //     0x59a80c: ldur            w2, [x1, #0x17]
    // 0x59a810: DecompressPointer r2
    //     0x59a810: add             x2, x2, HEAP, lsl #32
    // 0x59a814: stur            x2, [fp, #-8]
    // 0x59a818: cmp             w2, NULL
    // 0x59a81c: b.eq            #0x59a8b4
    // 0x59a820: ldr             x3, [fp, #0x18]
    // 0x59a824: r0 = LoadClassIdInstr(r2)
    //     0x59a824: ldur            x0, [x2, #-1]
    //     0x59a828: ubfx            x0, x0, #0xc, #0x14
    // 0x59a82c: SaveReg r2
    //     0x59a82c: str             x2, [SP, #-8]!
    // 0x59a830: r0 = GDT[cid_x0 + -0xff6]()
    //     0x59a830: sub             lr, x0, #0xff6
    //     0x59a834: ldr             lr, [x21, lr, lsl #3]
    //     0x59a838: blr             lr
    // 0x59a83c: add             SP, SP, #8
    // 0x59a840: ldr             x16, [fp, #0x20]
    // 0x59a844: ldr             lr, [fp, #0x10]
    // 0x59a848: stp             lr, x16, [SP, #-0x10]!
    // 0x59a84c: r0 = _buildParams()
    //     0x59a84c: bl              #0x55ea44  ; [package:encrypt/encrypt.dart] AES::_buildParams
    // 0x59a850: add             SP, SP, #0x10
    // 0x59a854: ldur            x1, [fp, #-8]
    // 0x59a858: r2 = LoadClassIdInstr(r1)
    //     0x59a858: ldur            x2, [x1, #-1]
    //     0x59a85c: ubfx            x2, x2, #0xc, #0x14
    // 0x59a860: stp             x0, x1, [SP, #-0x10]!
    // 0x59a864: mov             x0, x2
    // 0x59a868: r0 = GDT[cid_x0 + -0xfdf]()
    //     0x59a868: sub             lr, x0, #0xfdf
    //     0x59a86c: ldr             lr, [x21, lr, lsl #3]
    //     0x59a870: blr             lr
    // 0x59a874: add             SP, SP, #0x10
    // 0x59a878: ldr             x1, [fp, #0x18]
    // 0x59a87c: LoadField: r0 = r1->field_7
    //     0x59a87c: ldur            w0, [x1, #7]
    // 0x59a880: DecompressPointer r0
    //     0x59a880: add             x0, x0, HEAP, lsl #32
    // 0x59a884: ldur            x1, [fp, #-8]
    // 0x59a888: r2 = LoadClassIdInstr(r1)
    //     0x59a888: ldur            x2, [x1, #-1]
    //     0x59a88c: ubfx            x2, x2, #0xc, #0x14
    // 0x59a890: stp             x0, x1, [SP, #-0x10]!
    // 0x59a894: mov             x0, x2
    // 0x59a898: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x59a898: sub             lr, x0, #0xfd9
    //     0x59a89c: ldr             lr, [x21, lr, lsl #3]
    //     0x59a8a0: blr             lr
    // 0x59a8a4: add             SP, SP, #0x10
    // 0x59a8a8: LeaveFrame
    //     0x59a8a8: mov             SP, fp
    //     0x59a8ac: ldp             fp, lr, [SP], #0x10
    // 0x59a8b0: ret
    //     0x59a8b0: ret             
    // 0x59a8b4: mov             x2, x1
    // 0x59a8b8: ldr             x1, [fp, #0x18]
    // 0x59a8bc: LoadField: r3 = r2->field_13
    //     0x59a8bc: ldur            w3, [x2, #0x13]
    // 0x59a8c0: DecompressPointer r3
    //     0x59a8c0: add             x3, x3, HEAP, lsl #32
    // 0x59a8c4: stur            x3, [fp, #-8]
    // 0x59a8c8: r0 = LoadClassIdInstr(r3)
    //     0x59a8c8: ldur            x0, [x3, #-1]
    //     0x59a8cc: ubfx            x0, x0, #0xc, #0x14
    // 0x59a8d0: SaveReg r3
    //     0x59a8d0: str             x3, [SP, #-8]!
    // 0x59a8d4: r0 = GDT[cid_x0 + -0xee7]()
    //     0x59a8d4: sub             lr, x0, #0xee7
    //     0x59a8d8: ldr             lr, [x21, lr, lsl #3]
    //     0x59a8dc: blr             lr
    // 0x59a8e0: add             SP, SP, #8
    // 0x59a8e4: ldr             x16, [fp, #0x20]
    // 0x59a8e8: ldr             lr, [fp, #0x10]
    // 0x59a8ec: stp             lr, x16, [SP, #-0x10]!
    // 0x59a8f0: r0 = _buildParams()
    //     0x59a8f0: bl              #0x55ea44  ; [package:encrypt/encrypt.dart] AES::_buildParams
    // 0x59a8f4: add             SP, SP, #0x10
    // 0x59a8f8: ldur            x1, [fp, #-8]
    // 0x59a8fc: r2 = LoadClassIdInstr(r1)
    //     0x59a8fc: ldur            x2, [x1, #-1]
    //     0x59a900: ubfx            x2, x2, #0xc, #0x14
    // 0x59a904: r16 = false
    //     0x59a904: add             x16, NULL, #0x30  ; false
    // 0x59a908: stp             x16, x1, [SP, #-0x10]!
    // 0x59a90c: SaveReg r0
    //     0x59a90c: str             x0, [SP, #-8]!
    // 0x59a910: mov             x0, x2
    // 0x59a914: r0 = GDT[cid_x0 + -0xf82]()
    //     0x59a914: sub             lr, x0, #0xf82
    //     0x59a918: ldr             lr, [x21, lr, lsl #3]
    //     0x59a91c: blr             lr
    // 0x59a920: add             SP, SP, #0x18
    // 0x59a924: ldr             x0, [fp, #0x18]
    // 0x59a928: LoadField: r1 = r0->field_7
    //     0x59a928: ldur            w1, [x0, #7]
    // 0x59a92c: DecompressPointer r1
    //     0x59a92c: add             x1, x1, HEAP, lsl #32
    // 0x59a930: ldur            x0, [fp, #-8]
    // 0x59a934: r2 = LoadClassIdInstr(r0)
    //     0x59a934: ldur            x2, [x0, #-1]
    //     0x59a938: ubfx            x2, x2, #0xc, #0x14
    // 0x59a93c: stp             x1, x0, [SP, #-0x10]!
    // 0x59a940: mov             x0, x2
    // 0x59a944: r0 = GDT[cid_x0 + -0xc97]()
    //     0x59a944: sub             lr, x0, #0xc97
    //     0x59a948: ldr             lr, [x21, lr, lsl #3]
    //     0x59a94c: blr             lr
    // 0x59a950: add             SP, SP, #0x10
    // 0x59a954: LeaveFrame
    //     0x59a954: mov             SP, fp
    //     0x59a958: ldp             fp, lr, [SP], #0x10
    // 0x59a95c: ret
    //     0x59a95c: ret             
    // 0x59a960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59a960: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59a964: b               #0x59a808
  }
}

// class id: 4507, size: 0x8, field offset: 0x8
abstract class Algorithm extends Object {
}

// class id: 6002, size: 0x14, field offset: 0x14
enum AESMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15728, size: 0x5c
    // 0xb15728: EnterFrame
    //     0xb15728: stp             fp, lr, [SP, #-0x10]!
    //     0xb1572c: mov             fp, SP
    // 0xb15730: CheckStackOverflow
    //     0xb15730: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15734: cmp             SP, x16
    //     0xb15738: b.ls            #0xb1577c
    // 0xb1573c: r1 = Null
    //     0xb1573c: mov             x1, NULL
    // 0xb15740: r2 = 4
    //     0xb15740: mov             x2, #4
    // 0xb15744: r0 = AllocateArray()
    //     0xb15744: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15748: r17 = "AESMode."
    //     0xb15748: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d548] "AESMode."
    //     0xb1574c: ldr             x17, [x17, #0x548]
    // 0xb15750: StoreField: r0->field_f = r17
    //     0xb15750: stur            w17, [x0, #0xf]
    // 0xb15754: ldr             x1, [fp, #0x10]
    // 0xb15758: LoadField: r2 = r1->field_f
    //     0xb15758: ldur            w2, [x1, #0xf]
    // 0xb1575c: DecompressPointer r2
    //     0xb1575c: add             x2, x2, HEAP, lsl #32
    // 0xb15760: StoreField: r0->field_13 = r2
    //     0xb15760: stur            w2, [x0, #0x13]
    // 0xb15764: SaveReg r0
    //     0xb15764: str             x0, [SP, #-8]!
    // 0xb15768: r0 = _interpolate()
    //     0xb15768: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb1576c: add             SP, SP, #8
    // 0xb15770: LeaveFrame
    //     0xb15770: mov             SP, fp
    //     0xb15774: ldp             fp, lr, [SP], #0x10
    // 0xb15778: ret
    //     0xb15778: ret             
    // 0xb1577c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1577c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15780: b               #0xb1573c
  }
}

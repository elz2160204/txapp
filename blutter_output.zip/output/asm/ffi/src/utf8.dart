// lib: , url: package:ffi/src/utf8.dart

// class id: 1048996, size: 0x8
class :: {

  static _ Utf8Pointer.toDartString(/* No info */) {
    // ** addr: 0xa0d228, size: 0xa0
    // 0xa0d228: EnterFrame
    //     0xa0d228: stp             fp, lr, [SP, #-0x10]!
    //     0xa0d22c: mov             fp, SP
    // 0xa0d230: AllocStack(0x8)
    //     0xa0d230: sub             SP, SP, #8
    // 0xa0d234: SetupParameters(dynamic _ /* r1, fp-0x8 */)
    //     0xa0d234: mov             x0, x4
    //     0xa0d238: ldur            w1, [x0, #0x13]
    //     0xa0d23c: add             x1, x1, HEAP, lsl #32
    //     0xa0d240: sub             x0, x1, #2
    //     0xa0d244: add             x1, fp, w0, sxtw #2
    //     0xa0d248: ldr             x1, [x1, #0x10]
    //     0xa0d24c: stur            x1, [fp, #-8]
    // 0xa0d250: CheckStackOverflow
    //     0xa0d250: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0d254: cmp             SP, x16
    //     0xa0d258: b.ls            #0xa0d2c0
    // 0xa0d25c: SaveReg r1
    //     0xa0d25c: str             x1, [SP, #-8]!
    // 0xa0d260: r0 = Utf8Pointer._ensureNotNullptr()
    //     0xa0d260: bl              #0xa0d3a4  ; [package:ffi/src/utf8.dart] ::Utf8Pointer._ensureNotNullptr
    // 0xa0d264: add             SP, SP, #8
    // 0xa0d268: r16 = <Uint8>
    //     0xa0d268: ldr             x16, [PP, #0x64e0]  ; [pp+0x64e0] TypeArguments: <Uint8>
    // 0xa0d26c: ldur            lr, [fp, #-8]
    // 0xa0d270: stp             lr, x16, [SP, #-0x10]!
    // 0xa0d274: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xa0d274: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xa0d278: r0 = cast()
    //     0xa0d278: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0xa0d27c: add             SP, SP, #0x10
    // 0xa0d280: stur            x0, [fp, #-8]
    // 0xa0d284: SaveReg r0
    //     0xa0d284: str             x0, [SP, #-8]!
    // 0xa0d288: r0 = Utf8Pointer._length()
    //     0xa0d288: bl              #0xa0d35c  ; [package:ffi/src/utf8.dart] ::Utf8Pointer._length
    // 0xa0d28c: add             SP, SP, #8
    // 0xa0d290: ldur            x16, [fp, #-8]
    // 0xa0d294: stp             x0, x16, [SP, #-0x10]!
    // 0xa0d298: r0 = Uint8Pointer.asTypedList()
    //     0xa0d298: bl              #0xa0d2c8  ; [dart:ffi] ::Uint8Pointer.asTypedList
    // 0xa0d29c: add             SP, SP, #0x10
    // 0xa0d2a0: r16 = Instance_Utf8Codec
    //     0xa0d2a0: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xa0d2a4: stp             x0, x16, [SP, #-0x10]!
    // 0xa0d2a8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0d2a8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0d2ac: r0 = decode()
    //     0xa0d2ac: bl              #0x4e1c78  ; [dart:convert] Utf8Codec::decode
    // 0xa0d2b0: add             SP, SP, #0x10
    // 0xa0d2b4: LeaveFrame
    //     0xa0d2b4: mov             SP, fp
    //     0xa0d2b8: ldp             fp, lr, [SP], #0x10
    // 0xa0d2bc: ret
    //     0xa0d2bc: ret             
    // 0xa0d2c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0d2c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0d2c4: b               #0xa0d25c
  }
  static _ Utf8Pointer._length(/* No info */) {
    // ** addr: 0xa0d35c, size: 0x48
    // 0xa0d35c: EnterFrame
    //     0xa0d35c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0d360: mov             fp, SP
    // 0xa0d364: ldr             x1, [fp, #0x10]
    // 0xa0d368: r0 = 0
    //     0xa0d368: mov             x0, #0
    // 0xa0d36c: CheckStackOverflow
    //     0xa0d36c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0d370: cmp             SP, x16
    //     0xa0d374: b.ls            #0xa0d39c
    // 0xa0d378: LoadField: r2 = r1->field_7
    //     0xa0d378: ldur            x2, [x1, #7]
    // 0xa0d37c: ldrb            w3, [x2, x0]
    // 0xa0d380: cbz             x3, #0xa0d390
    // 0xa0d384: add             x2, x0, #1
    // 0xa0d388: mov             x0, x2
    // 0xa0d38c: b               #0xa0d36c
    // 0xa0d390: LeaveFrame
    //     0xa0d390: mov             SP, fp
    //     0xa0d394: ldp             fp, lr, [SP], #0x10
    // 0xa0d398: ret
    //     0xa0d398: ret             
    // 0xa0d39c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0d39c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0d3a0: b               #0xa0d378
  }
  static _ Utf8Pointer._ensureNotNullptr(/* No info */) {
    // ** addr: 0xa0d3a4, size: 0xf8
    // 0xa0d3a4: EnterFrame
    //     0xa0d3a4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0d3a8: mov             fp, SP
    // 0xa0d3ac: AllocStack(0x8)
    //     0xa0d3ac: sub             SP, SP, #8
    // 0xa0d3b0: CheckStackOverflow
    //     0xa0d3b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0d3b4: cmp             SP, x16
    //     0xa0d3b8: b.ls            #0xa0d494
    // 0xa0d3bc: r0 = InitLateStaticField(0x2d8) // [dart:ffi] ::nullptr
    //     0xa0d3bc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0d3c0: ldr             x0, [x0, #0x5b0]
    //     0xa0d3c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0d3c8: cmp             w0, w16
    //     0xa0d3cc: b.ne            #0xa0d3d8
    //     0xa0d3d0: ldr             x2, [PP, #0x63c8]  ; [pp+0x63c8] Field <::.nullptr>: static late final (offset: 0x2d8)
    //     0xa0d3d4: bl              #0xd67cdc
    // 0xa0d3d8: mov             x3, x0
    // 0xa0d3dc: r2 = Null
    //     0xa0d3dc: mov             x2, NULL
    // 0xa0d3e0: r1 = Null
    //     0xa0d3e0: mov             x1, NULL
    // 0xa0d3e4: stur            x3, [fp, #-8]
    // 0xa0d3e8: cmp             w0, NULL
    // 0xa0d3ec: b.eq            #0xa0d440
    // 0xa0d3f0: branchIfSmi(r0, 0xa0d440)
    //     0xa0d3f0: tbz             w0, #0, #0xa0d440
    // 0xa0d3f4: r8 = Pointer<NativeType>
    //     0xa0d3f4: add             x8, PP, #8, lsl #12  ; [pp+0x8380] Type: Pointer<NativeType>
    //     0xa0d3f8: ldr             x8, [x8, #0x380]
    // 0xa0d3fc: r3 = SubtypeTestCache
    //     0xa0d3fc: add             x3, PP, #8, lsl #12  ; [pp+0x8388] SubtypeTestCache
    //     0xa0d400: ldr             x3, [x3, #0x388]
    // 0xa0d404: r24 = Subtype3TestCacheStub
    //     0xa0d404: ldr             x24, [PP, #0x10]  ; [pp+0x10] Stub: Subtype3TestCache (0x4ae294)
    // 0xa0d408: LoadField: r30 = r24->field_7
    //     0xa0d408: ldur            lr, [x24, #7]
    // 0xa0d40c: blr             lr
    // 0xa0d410: cmp             w7, NULL
    // 0xa0d414: b.eq            #0xa0d420
    // 0xa0d418: tbnz            w7, #4, #0xa0d440
    // 0xa0d41c: b               #0xa0d448
    // 0xa0d420: r8 = Pointer<NativeType>
    //     0xa0d420: add             x8, PP, #8, lsl #12  ; [pp+0x8390] Type: Pointer<NativeType>
    //     0xa0d424: ldr             x8, [x8, #0x390]
    // 0xa0d428: r3 = SubtypeTestCache
    //     0xa0d428: add             x3, PP, #8, lsl #12  ; [pp+0x8398] SubtypeTestCache
    //     0xa0d42c: ldr             x3, [x3, #0x398]
    // 0xa0d430: r24 = InstanceOfStub
    //     0xa0d430: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xa0d434: LoadField: r30 = r24->field_7
    //     0xa0d434: ldur            lr, [x24, #7]
    // 0xa0d438: blr             lr
    // 0xa0d43c: b               #0xa0d44c
    // 0xa0d440: r0 = false
    //     0xa0d440: add             x0, NULL, #0x30  ; false
    // 0xa0d444: b               #0xa0d44c
    // 0xa0d448: r0 = true
    //     0xa0d448: add             x0, NULL, #0x20  ; true
    // 0xa0d44c: tbnz            w0, #4, #0xa0d468
    // 0xa0d450: ldr             x1, [fp, #0x10]
    // 0xa0d454: ldur            x0, [fp, #-8]
    // 0xa0d458: LoadField: r2 = r1->field_7
    //     0xa0d458: ldur            x2, [x1, #7]
    // 0xa0d45c: LoadField: r1 = r0->field_7
    //     0xa0d45c: ldur            x1, [x0, #7]
    // 0xa0d460: cmp             x2, x1
    // 0xa0d464: b.eq            #0xa0d478
    // 0xa0d468: r0 = Null
    //     0xa0d468: mov             x0, NULL
    // 0xa0d46c: LeaveFrame
    //     0xa0d46c: mov             SP, fp
    //     0xa0d470: ldp             fp, lr, [SP], #0x10
    // 0xa0d474: ret
    //     0xa0d474: ret             
    // 0xa0d478: r0 = UnsupportedError()
    //     0xa0d478: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0xa0d47c: mov             x1, x0
    // 0xa0d480: r0 = "Operation \'toDartString\' not allowed on a \'nullptr\'."
    //     0xa0d480: ldr             x0, [PP, #0x63f0]  ; [pp+0x63f0] "Operation \'toDartString\' not allowed on a \'nullptr\'."
    // 0xa0d484: StoreField: r1->field_b = r0
    //     0xa0d484: stur            w0, [x1, #0xb]
    // 0xa0d488: mov             x0, x1
    // 0xa0d48c: r0 = Throw()
    //     0xa0d48c: bl              #0xd67e38  ; ThrowStub
    // 0xa0d490: brk             #0
    // 0xa0d494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0d494: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0d498: b               #0xa0d3bc
  }
}

// class id: 6263, size: 0x8, field offset: 0x8
abstract class Utf8 extends Opaque {
}

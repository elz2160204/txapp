// lib: , url: package:ffi/src/allocation.dart

// class id: 1048993, size: 0x8
class :: {

  static late final (dynamic, Pointer<NativeType>) => void winCoTaskMemFree; // offset: 0xc40
  static late final (dynamic, Pointer<NativeType>) => void posixFree; // offset: 0xc38
  static late final DynamicLibrary stdlib; // offset: 0xc2c
  static late final (dynamic, int) => Pointer<NativeType> winCoTaskMemAlloc; // offset: 0xc3c
  static late final (dynamic, int, int) => Pointer<NativeType> posixCalloc; // offset: 0xc34
  static late final (dynamic, int) => Pointer<NativeType> posixMalloc; // offset: 0xc30

  static (dynamic, Pointer<NativeType>) => void posixFree() {
    // ** addr: 0x92cdbc, size: 0x88
    // 0x92cdbc: EnterFrame
    //     0x92cdbc: stp             fp, lr, [SP, #-0x10]!
    //     0x92cdc0: mov             fp, SP
    // 0x92cdc4: AllocStack(0x8)
    //     0x92cdc4: sub             SP, SP, #8
    // 0x92cdc8: CheckStackOverflow
    //     0x92cdc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92cdcc: cmp             SP, x16
    //     0x92cdd0: b.ls            #0x92ce3c
    // 0x92cdd4: r0 = InitLateStaticField(0xc2c) // [package:ffi/src/allocation.dart] ::stdlib
    //     0x92cdd4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92cdd8: ldr             x0, [x0, #0x1858]
    //     0x92cddc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92cde0: cmp             w0, w16
    //     0x92cde4: b.ne            #0x92cdf0
    //     0x92cde8: ldr             x2, [PP, #0x6408]  ; [pp+0x6408] Field <::.stdlib>: static late final (offset: 0xc2c)
    //     0x92cdec: bl              #0xd67cdc
    // 0x92cdf0: r16 = <NativeFunction<(dynamic this, Pointer<NativeType>) => Void>>
    //     0x92cdf0: ldr             x16, [PP, #0x6410]  ; [pp+0x6410] TypeArguments: <NativeFunction<(dynamic this, Pointer<NativeType>) => Void>>
    // 0x92cdf4: stp             x0, x16, [SP, #-0x10]!
    // 0x92cdf8: r16 = "free"
    //     0x92cdf8: ldr             x16, [PP, #0x6418]  ; [pp+0x6418] "free"
    // 0x92cdfc: SaveReg r16
    //     0x92cdfc: str             x16, [SP, #-8]!
    // 0x92ce00: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92ce00: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92ce04: r0 = lookup()
    //     0x92ce04: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0x92ce08: add             SP, SP, #0x18
    // 0x92ce0c: stur            x0, [fp, #-8]
    // 0x92ce10: r1 = 1
    //     0x92ce10: mov             x1, #1
    // 0x92ce14: r0 = AllocateContext()
    //     0x92ce14: bl              #0xd68aa4  ; AllocateContextStub
    // 0x92ce18: mov             x1, x0
    // 0x92ce1c: ldur            x0, [fp, #-8]
    // 0x92ce20: StoreField: r1->field_f = r0
    //     0x92ce20: stur            w0, [x1, #0xf]
    // 0x92ce24: mov             x2, x1
    // 0x92ce28: r1 = Function 'FfiTrampoline_posixFree': static ffi-trampoline-function.
    //     0x92ce28: ldr             x1, [PP, #0x6420]  ; [pp+0x6420] Function: [dart:ffi] ::FfiTrampoline__dispose$Method$FfiNative$Ptr (0x5dd2fc)
    // 0x92ce2c: r0 = AllocateClosure()
    //     0x92ce2c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x92ce30: LeaveFrame
    //     0x92ce30: mov             SP, fp
    //     0x92ce34: ldp             fp, lr, [SP], #0x10
    // 0x92ce38: ret
    //     0x92ce38: ret             
    // 0x92ce3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92ce3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92ce40: b               #0x92cdd4
  }
  static DynamicLibrary stdlib() {
    // ** addr: 0x92ce44, size: 0x60
    // 0x92ce44: EnterFrame
    //     0x92ce44: stp             fp, lr, [SP, #-0x10]!
    //     0x92ce48: mov             fp, SP
    // 0x92ce4c: CheckStackOverflow
    //     0x92ce4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92ce50: cmp             SP, x16
    //     0x92ce54: b.ls            #0x92ce9c
    // 0x92ce58: r0 = InitLateStaticField(0x694) // [dart:io] Platform::isWindows
    //     0x92ce58: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92ce5c: ldr             x0, [x0, #0xd28]
    //     0x92ce60: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92ce64: cmp             w0, w16
    //     0x92ce68: b.ne            #0x92ce74
    //     0x92ce6c: ldr             x2, [PP, #0x80]  ; [pp+0x80] Field <Platform.isWindows>: static late final (offset: 0x694)
    //     0x92ce70: bl              #0xd67cdc
    // 0x92ce74: tbnz            w0, #4, #0x92ce8c
    // 0x92ce78: r16 = "ole32.dll"
    //     0x92ce78: ldr             x16, [PP, #0x6428]  ; [pp+0x6428] "ole32.dll"
    // 0x92ce7c: SaveReg r16
    //     0x92ce7c: str             x16, [SP, #-8]!
    // 0x92ce80: r0 = _open()
    //     0x92ce80: bl              #0x930078  ; [dart:ffi] ::_open
    // 0x92ce84: add             SP, SP, #8
    // 0x92ce88: b               #0x92ce90
    // 0x92ce8c: r0 = _processLibrary()
    //     0x92ce8c: bl              #0x92cea4  ; [dart:ffi] ::_processLibrary
    // 0x92ce90: LeaveFrame
    //     0x92ce90: mov             SP, fp
    //     0x92ce94: ldp             fp, lr, [SP], #0x10
    // 0x92ce98: ret
    //     0x92ce98: ret             
    // 0x92ce9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92ce9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92cea0: b               #0x92ce58
  }
  static (dynamic, Pointer<NativeType>) => void winCoTaskMemFree() {
    // ** addr: 0x92cf14, size: 0x88
    // 0x92cf14: EnterFrame
    //     0x92cf14: stp             fp, lr, [SP, #-0x10]!
    //     0x92cf18: mov             fp, SP
    // 0x92cf1c: AllocStack(0x8)
    //     0x92cf1c: sub             SP, SP, #8
    // 0x92cf20: CheckStackOverflow
    //     0x92cf20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92cf24: cmp             SP, x16
    //     0x92cf28: b.ls            #0x92cf94
    // 0x92cf2c: r0 = InitLateStaticField(0xc2c) // [package:ffi/src/allocation.dart] ::stdlib
    //     0x92cf2c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92cf30: ldr             x0, [x0, #0x1858]
    //     0x92cf34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92cf38: cmp             w0, w16
    //     0x92cf3c: b.ne            #0x92cf48
    //     0x92cf40: ldr             x2, [PP, #0x6408]  ; [pp+0x6408] Field <::.stdlib>: static late final (offset: 0xc2c)
    //     0x92cf44: bl              #0xd67cdc
    // 0x92cf48: r16 = <NativeFunction<(dynamic this, Pointer<NativeType>) => Void>>
    //     0x92cf48: ldr             x16, [PP, #0x6410]  ; [pp+0x6410] TypeArguments: <NativeFunction<(dynamic this, Pointer<NativeType>) => Void>>
    // 0x92cf4c: stp             x0, x16, [SP, #-0x10]!
    // 0x92cf50: r16 = "CoTaskMemFree"
    //     0x92cf50: ldr             x16, [PP, #0x6450]  ; [pp+0x6450] "CoTaskMemFree"
    // 0x92cf54: SaveReg r16
    //     0x92cf54: str             x16, [SP, #-8]!
    // 0x92cf58: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92cf58: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92cf5c: r0 = lookup()
    //     0x92cf5c: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0x92cf60: add             SP, SP, #0x18
    // 0x92cf64: stur            x0, [fp, #-8]
    // 0x92cf68: r1 = 1
    //     0x92cf68: mov             x1, #1
    // 0x92cf6c: r0 = AllocateContext()
    //     0x92cf6c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x92cf70: mov             x1, x0
    // 0x92cf74: ldur            x0, [fp, #-8]
    // 0x92cf78: StoreField: r1->field_f = r0
    //     0x92cf78: stur            w0, [x1, #0xf]
    // 0x92cf7c: mov             x2, x1
    // 0x92cf80: r1 = Function 'FfiTrampoline_winCoTaskMemFree': static ffi-trampoline-function.
    //     0x92cf80: ldr             x1, [PP, #0x6458]  ; [pp+0x6458] Function: [dart:ffi] ::FfiTrampoline__dispose$Method$FfiNative$Ptr (0x5dd2fc)
    // 0x92cf84: r0 = AllocateClosure()
    //     0x92cf84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x92cf88: LeaveFrame
    //     0x92cf88: mov             SP, fp
    //     0x92cf8c: ldp             fp, lr, [SP], #0x10
    // 0x92cf90: ret
    //     0x92cf90: ret             
    // 0x92cf94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92cf94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92cf98: b               #0x92cf2c
  }
  static (dynamic, int, int) => Pointer<NativeType> posixCalloc() {
    // ** addr: 0x92de94, size: 0x88
    // 0x92de94: EnterFrame
    //     0x92de94: stp             fp, lr, [SP, #-0x10]!
    //     0x92de98: mov             fp, SP
    // 0x92de9c: AllocStack(0x8)
    //     0x92de9c: sub             SP, SP, #8
    // 0x92dea0: CheckStackOverflow
    //     0x92dea0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92dea4: cmp             SP, x16
    //     0x92dea8: b.ls            #0x92df14
    // 0x92deac: r0 = InitLateStaticField(0xc2c) // [package:ffi/src/allocation.dart] ::stdlib
    //     0x92deac: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92deb0: ldr             x0, [x0, #0x1858]
    //     0x92deb4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92deb8: cmp             w0, w16
    //     0x92debc: b.ne            #0x92dec8
    //     0x92dec0: ldr             x2, [PP, #0x6408]  ; [pp+0x6408] Field <::.stdlib>: static late final (offset: 0xc2c)
    //     0x92dec4: bl              #0xd67cdc
    // 0x92dec8: r16 = <NativeFunction<(dynamic this, IntPtr, IntPtr) => Pointer<NativeType>>>
    //     0x92dec8: ldr             x16, [PP, #0x64e8]  ; [pp+0x64e8] TypeArguments: <NativeFunction<(dynamic this, IntPtr, IntPtr) => Pointer<NativeType>>>
    // 0x92decc: stp             x0, x16, [SP, #-0x10]!
    // 0x92ded0: r16 = "calloc"
    //     0x92ded0: ldr             x16, [PP, #0x64f0]  ; [pp+0x64f0] "calloc"
    // 0x92ded4: SaveReg r16
    //     0x92ded4: str             x16, [SP, #-8]!
    // 0x92ded8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92ded8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92dedc: r0 = lookup()
    //     0x92dedc: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0x92dee0: add             SP, SP, #0x18
    // 0x92dee4: stur            x0, [fp, #-8]
    // 0x92dee8: r1 = 1
    //     0x92dee8: mov             x1, #1
    // 0x92deec: r0 = AllocateContext()
    //     0x92deec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x92def0: mov             x1, x0
    // 0x92def4: ldur            x0, [fp, #-8]
    // 0x92def8: StoreField: r1->field_f = r0
    //     0x92def8: stur            w0, [x1, #0xf]
    // 0x92defc: mov             x2, x1
    // 0x92df00: r1 = Function 'FfiTrampoline_posixCalloc': static ffi-trampoline-function.
    //     0x92df00: ldr             x1, [PP, #0x64f8]  ; [pp+0x64f8] Function: [dart:ffi] ::FfiTrampoline_posixCalloc (0x92df1c)
    // 0x92df04: r0 = AllocateClosure()
    //     0x92df04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x92df08: LeaveFrame
    //     0x92df08: mov             SP, fp
    //     0x92df0c: ldp             fp, lr, [SP], #0x10
    // 0x92df10: ret
    //     0x92df10: ret             
    // 0x92df14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92df14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92df18: b               #0x92deac
  }
  static (dynamic, int) => Pointer<NativeType> winCoTaskMemAlloc() {
    // ** addr: 0x92e004, size: 0x88
    // 0x92e004: EnterFrame
    //     0x92e004: stp             fp, lr, [SP, #-0x10]!
    //     0x92e008: mov             fp, SP
    // 0x92e00c: AllocStack(0x8)
    //     0x92e00c: sub             SP, SP, #8
    // 0x92e010: CheckStackOverflow
    //     0x92e010: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92e014: cmp             SP, x16
    //     0x92e018: b.ls            #0x92e084
    // 0x92e01c: r0 = InitLateStaticField(0xc2c) // [package:ffi/src/allocation.dart] ::stdlib
    //     0x92e01c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92e020: ldr             x0, [x0, #0x1858]
    //     0x92e024: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92e028: cmp             w0, w16
    //     0x92e02c: b.ne            #0x92e038
    //     0x92e030: ldr             x2, [PP, #0x6408]  ; [pp+0x6408] Field <::.stdlib>: static late final (offset: 0xc2c)
    //     0x92e034: bl              #0xd67cdc
    // 0x92e038: r16 = <NativeFunction<(dynamic this, Size) => Pointer<NativeType>>>
    //     0x92e038: ldr             x16, [PP, #0x6500]  ; [pp+0x6500] TypeArguments: <NativeFunction<(dynamic this, Size) => Pointer<NativeType>>>
    // 0x92e03c: stp             x0, x16, [SP, #-0x10]!
    // 0x92e040: r16 = "CoTaskMemAlloc"
    //     0x92e040: ldr             x16, [PP, #0x6508]  ; [pp+0x6508] "CoTaskMemAlloc"
    // 0x92e044: SaveReg r16
    //     0x92e044: str             x16, [SP, #-8]!
    // 0x92e048: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92e048: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92e04c: r0 = lookup()
    //     0x92e04c: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0x92e050: add             SP, SP, #0x18
    // 0x92e054: stur            x0, [fp, #-8]
    // 0x92e058: r1 = 1
    //     0x92e058: mov             x1, #1
    // 0x92e05c: r0 = AllocateContext()
    //     0x92e05c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x92e060: mov             x1, x0
    // 0x92e064: ldur            x0, [fp, #-8]
    // 0x92e068: StoreField: r1->field_f = r0
    //     0x92e068: stur            w0, [x1, #0xf]
    // 0x92e06c: mov             x2, x1
    // 0x92e070: r1 = Function 'FfiTrampoline_winCoTaskMemAlloc': static ffi-trampoline-function.
    //     0x92e070: ldr             x1, [PP, #0x6510]  ; [pp+0x6510] Function: [dart:ffi] ::FfiTrampoline_winCoTaskMemAlloc (0x92e08c)
    // 0x92e074: r0 = AllocateClosure()
    //     0x92e074: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x92e078: LeaveFrame
    //     0x92e078: mov             SP, fp
    //     0x92e07c: ldp             fp, lr, [SP], #0x10
    // 0x92e080: ret
    //     0x92e080: ret             
    // 0x92e084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92e084: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92e088: b               #0x92e01c
  }
  static (dynamic, int) => Pointer<NativeType> posixMalloc() {
    // ** addr: 0x92f9ec, size: 0x94
    // 0x92f9ec: EnterFrame
    //     0x92f9ec: stp             fp, lr, [SP, #-0x10]!
    //     0x92f9f0: mov             fp, SP
    // 0x92f9f4: AllocStack(0x8)
    //     0x92f9f4: sub             SP, SP, #8
    // 0x92f9f8: CheckStackOverflow
    //     0x92f9f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92f9fc: cmp             SP, x16
    //     0x92fa00: b.ls            #0x92fa78
    // 0x92fa04: r0 = InitLateStaticField(0xc2c) // [package:ffi/src/allocation.dart] ::stdlib
    //     0x92fa04: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92fa08: ldr             x0, [x0, #0x1858]
    //     0x92fa0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92fa10: cmp             w0, w16
    //     0x92fa14: b.ne            #0x92fa20
    //     0x92fa18: ldr             x2, [PP, #0x6408]  ; [pp+0x6408] Field <::.stdlib>: static late final (offset: 0xc2c)
    //     0x92fa1c: bl              #0xd67cdc
    // 0x92fa20: r16 = <NativeFunction<(dynamic this, IntPtr) => Pointer<NativeType>>>
    //     0x92fa20: add             x16, PP, #0x34, lsl #12  ; [pp+0x340f0] TypeArguments: <NativeFunction<(dynamic this, IntPtr) => Pointer<NativeType>>>
    //     0x92fa24: ldr             x16, [x16, #0xf0]
    // 0x92fa28: stp             x0, x16, [SP, #-0x10]!
    // 0x92fa2c: r16 = "malloc"
    //     0x92fa2c: add             x16, PP, #0x34, lsl #12  ; [pp+0x340f8] "malloc"
    //     0x92fa30: ldr             x16, [x16, #0xf8]
    // 0x92fa34: SaveReg r16
    //     0x92fa34: str             x16, [SP, #-8]!
    // 0x92fa38: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92fa38: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92fa3c: r0 = lookup()
    //     0x92fa3c: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0x92fa40: add             SP, SP, #0x18
    // 0x92fa44: stur            x0, [fp, #-8]
    // 0x92fa48: r1 = 1
    //     0x92fa48: mov             x1, #1
    // 0x92fa4c: r0 = AllocateContext()
    //     0x92fa4c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x92fa50: mov             x1, x0
    // 0x92fa54: ldur            x0, [fp, #-8]
    // 0x92fa58: StoreField: r1->field_f = r0
    //     0x92fa58: stur            w0, [x1, #0xf]
    // 0x92fa5c: mov             x2, x1
    // 0x92fa60: r1 = Function 'FfiTrampoline_posixMalloc': static ffi-trampoline-function.
    //     0x92fa60: add             x1, PP, #0x34, lsl #12  ; [pp+0x34100] Function: [dart:ffi] ::FfiTrampoline_winCoTaskMemAlloc (0x92e08c)
    //     0x92fa64: ldr             x1, [x1, #0x100]
    // 0x92fa68: r0 = AllocateClosure()
    //     0x92fa68: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x92fa6c: LeaveFrame
    //     0x92fa6c: mov             SP, fp
    //     0x92fa70: ldp             fp, lr, [SP], #0x10
    // 0x92fa74: ret
    //     0x92fa74: ret             
    // 0x92fa78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92fa78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92fa7c: b               #0x92fa04
  }
}

// class id: 4423, size: 0x8, field offset: 0x8
//   const constructor, 
class _CallocAllocator extends Object
    implements Allocator {

  _ free(/* No info */) {
    // ** addr: 0x92cd04, size: 0xb8
    // 0x92cd04: EnterFrame
    //     0x92cd04: stp             fp, lr, [SP, #-0x10]!
    //     0x92cd08: mov             fp, SP
    // 0x92cd0c: CheckStackOverflow
    //     0x92cd0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92cd10: cmp             SP, x16
    //     0x92cd14: b.ls            #0x92cdb4
    // 0x92cd18: r0 = InitLateStaticField(0x694) // [dart:io] Platform::isWindows
    //     0x92cd18: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92cd1c: ldr             x0, [x0, #0xd28]
    //     0x92cd20: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92cd24: cmp             w0, w16
    //     0x92cd28: b.ne            #0x92cd34
    //     0x92cd2c: ldr             x2, [PP, #0x80]  ; [pp+0x80] Field <Platform.isWindows>: static late final (offset: 0x694)
    //     0x92cd30: bl              #0xd67cdc
    // 0x92cd34: tbnz            w0, #4, #0x92cd70
    // 0x92cd38: r0 = InitLateStaticField(0xc40) // [package:ffi/src/allocation.dart] ::winCoTaskMemFree
    //     0x92cd38: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92cd3c: ldr             x0, [x0, #0x1880]
    //     0x92cd40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92cd44: cmp             w0, w16
    //     0x92cd48: b.ne            #0x92cd54
    //     0x92cd4c: ldr             x2, [PP, #0x63f8]  ; [pp+0x63f8] Field <::.winCoTaskMemFree>: static late final (offset: 0xc40)
    //     0x92cd50: bl              #0xd67cdc
    // 0x92cd54: ldr             x16, [fp, #0x10]
    // 0x92cd58: stp             x16, x0, [SP, #-0x10]!
    // 0x92cd5c: ClosureCall
    //     0x92cd5c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x92cd60: ldur            x2, [x0, #0x1f]
    //     0x92cd64: blr             x2
    // 0x92cd68: add             SP, SP, #0x10
    // 0x92cd6c: b               #0x92cda4
    // 0x92cd70: r0 = InitLateStaticField(0xc38) // [package:ffi/src/allocation.dart] ::posixFree
    //     0x92cd70: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92cd74: ldr             x0, [x0, #0x1870]
    //     0x92cd78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92cd7c: cmp             w0, w16
    //     0x92cd80: b.ne            #0x92cd8c
    //     0x92cd84: ldr             x2, [PP, #0x6400]  ; [pp+0x6400] Field <::.posixFree>: static late final (offset: 0xc38)
    //     0x92cd88: bl              #0xd67cdc
    // 0x92cd8c: ldr             x16, [fp, #0x10]
    // 0x92cd90: stp             x16, x0, [SP, #-0x10]!
    // 0x92cd94: ClosureCall
    //     0x92cd94: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x92cd98: ldur            x2, [x0, #0x1f]
    //     0x92cd9c: blr             x2
    // 0x92cda0: add             SP, SP, #0x10
    // 0x92cda4: r0 = Null
    //     0x92cda4: mov             x0, NULL
    // 0x92cda8: LeaveFrame
    //     0x92cda8: mov             SP, fp
    //     0x92cdac: ldp             fp, lr, [SP], #0x10
    // 0x92cdb0: ret
    //     0x92cdb0: ret             
    // 0x92cdb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92cdb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92cdb8: b               #0x92cd18
  }
  _ allocate(/* No info */) {
    // ** addr: 0x92dc14, size: 0x204
    // 0x92dc14: EnterFrame
    //     0x92dc14: stp             fp, lr, [SP, #-0x10]!
    //     0x92dc18: mov             fp, SP
    // 0x92dc1c: AllocStack(0x18)
    //     0x92dc1c: sub             SP, SP, #0x18
    // 0x92dc20: SetupParameters()
    //     0x92dc20: mov             x0, x4
    //     0x92dc24: ldur            w1, [x0, #0xf]
    //     0x92dc28: add             x1, x1, HEAP, lsl #32
    //     0x92dc2c: cbnz            w1, #0x92dc38
    //     0x92dc30: mov             x0, NULL
    //     0x92dc34: b               #0x92dc48
    //     0x92dc38: ldur            w2, [x0, #0x17]
    //     0x92dc3c: add             x2, x2, HEAP, lsl #32
    //     0x92dc40: add             x0, fp, w2, sxtw #2
    //     0x92dc44: ldr             x0, [x0, #0x10]
    // 0x92dc48: CheckStackOverflow
    //     0x92dc48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92dc4c: cmp             SP, x16
    //     0x92dc50: b.ls            #0x92de10
    // 0x92dc54: cbnz            w1, #0x92dc5c
    // 0x92dc58: r0 = <NativeType>
    //     0x92dc58: ldr             x0, [PP, #0x64b8]  ; [pp+0x64b8] TypeArguments: <NativeType>
    // 0x92dc5c: stur            x0, [fp, #-8]
    // 0x92dc60: r0 = InitLateStaticField(0x694) // [dart:io] Platform::isWindows
    //     0x92dc60: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92dc64: ldr             x0, [x0, #0xd28]
    //     0x92dc68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92dc6c: cmp             w0, w16
    //     0x92dc70: b.ne            #0x92dc7c
    //     0x92dc74: ldr             x2, [PP, #0x80]  ; [pp+0x80] Field <Platform.isWindows>: static late final (offset: 0x694)
    //     0x92dc78: bl              #0xd67cdc
    // 0x92dc7c: stur            x0, [fp, #-0x10]
    // 0x92dc80: tbnz            w0, #4, #0x92dcf0
    // 0x92dc84: ldr             x1, [fp, #0x10]
    // 0x92dc88: r0 = InitLateStaticField(0xc3c) // [package:ffi/src/allocation.dart] ::winCoTaskMemAlloc
    //     0x92dc88: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92dc8c: ldr             x0, [x0, #0x1878]
    //     0x92dc90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92dc94: cmp             w0, w16
    //     0x92dc98: b.ne            #0x92dca4
    //     0x92dc9c: ldr             x2, [PP, #0x64c0]  ; [pp+0x64c0] Field <::.winCoTaskMemAlloc>: static late final (offset: 0xc3c)
    //     0x92dca0: bl              #0xd67cdc
    // 0x92dca4: mov             x3, x0
    // 0x92dca8: ldr             x2, [fp, #0x10]
    // 0x92dcac: r0 = BoxInt64Instr(r2)
    //     0x92dcac: sbfiz           x0, x2, #1, #0x1f
    //     0x92dcb0: cmp             x2, x0, asr #1
    //     0x92dcb4: b.eq            #0x92dcc0
    //     0x92dcb8: bl              #0xd69bb8
    //     0x92dcbc: stur            x2, [x0, #7]
    // 0x92dcc0: stp             x0, x3, [SP, #-0x10]!
    // 0x92dcc4: mov             x0, x3
    // 0x92dcc8: ClosureCall
    //     0x92dcc8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x92dccc: ldur            x2, [x0, #0x1f]
    //     0x92dcd0: blr             x2
    // 0x92dcd4: add             SP, SP, #0x10
    // 0x92dcd8: ldur            x16, [fp, #-8]
    // 0x92dcdc: stp             x0, x16, [SP, #-0x10]!
    // 0x92dce0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92dce0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92dce4: r0 = cast()
    //     0x92dce4: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92dce8: add             SP, SP, #0x10
    // 0x92dcec: b               #0x92dd60
    // 0x92dcf0: ldr             x0, [fp, #0x10]
    // 0x92dcf4: r0 = InitLateStaticField(0xc34) // [package:ffi/src/allocation.dart] ::posixCalloc
    //     0x92dcf4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92dcf8: ldr             x0, [x0, #0x1868]
    //     0x92dcfc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92dd00: cmp             w0, w16
    //     0x92dd04: b.ne            #0x92dd10
    //     0x92dd08: ldr             x2, [PP, #0x64c8]  ; [pp+0x64c8] Field <::.posixCalloc>: static late final (offset: 0xc34)
    //     0x92dd0c: bl              #0xd67cdc
    // 0x92dd10: mov             x3, x0
    // 0x92dd14: ldr             x2, [fp, #0x10]
    // 0x92dd18: r0 = BoxInt64Instr(r2)
    //     0x92dd18: sbfiz           x0, x2, #1, #0x1f
    //     0x92dd1c: cmp             x2, x0, asr #1
    //     0x92dd20: b.eq            #0x92dd2c
    //     0x92dd24: bl              #0xd69bb8
    //     0x92dd28: stur            x2, [x0, #7]
    // 0x92dd2c: stp             x0, x3, [SP, #-0x10]!
    // 0x92dd30: r16 = 2
    //     0x92dd30: mov             x16, #2
    // 0x92dd34: SaveReg r16
    //     0x92dd34: str             x16, [SP, #-8]!
    // 0x92dd38: mov             x0, x3
    // 0x92dd3c: ClosureCall
    //     0x92dd3c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x92dd40: ldur            x2, [x0, #0x1f]
    //     0x92dd44: blr             x2
    // 0x92dd48: add             SP, SP, #0x18
    // 0x92dd4c: ldur            x16, [fp, #-8]
    // 0x92dd50: stp             x0, x16, [SP, #-0x10]!
    // 0x92dd54: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92dd54: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92dd58: r0 = cast()
    //     0x92dd58: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92dd5c: add             SP, SP, #0x10
    // 0x92dd60: stur            x0, [fp, #-0x18]
    // 0x92dd64: LoadField: r1 = r0->field_7
    //     0x92dd64: ldur            x1, [x0, #7]
    // 0x92dd68: cbz             x1, #0x92dd9c
    // 0x92dd6c: ldr             x3, [fp, #0x10]
    // 0x92dd70: ldur            x1, [fp, #-0x10]
    // 0x92dd74: tbnz            w1, #4, #0x92dd8c
    // 0x92dd78: ldr             x16, [fp, #0x18]
    // 0x92dd7c: stp             x0, x16, [SP, #-0x10]!
    // 0x92dd80: SaveReg r3
    //     0x92dd80: str             x3, [SP, #-8]!
    // 0x92dd84: r0 = _fillMemory()
    //     0x92dd84: bl              #0x92de18  ; [package:ffi/src/allocation.dart] _CallocAllocator::_fillMemory
    // 0x92dd88: add             SP, SP, #0x18
    // 0x92dd8c: ldur            x0, [fp, #-0x18]
    // 0x92dd90: LeaveFrame
    //     0x92dd90: mov             SP, fp
    //     0x92dd94: ldp             fp, lr, [SP], #0x10
    // 0x92dd98: ret
    //     0x92dd98: ret             
    // 0x92dd9c: ldr             x0, [fp, #0x10]
    // 0x92dda0: r1 = Null
    //     0x92dda0: mov             x1, NULL
    // 0x92dda4: r2 = 6
    //     0x92dda4: mov             x2, #6
    // 0x92dda8: r0 = AllocateArray()
    //     0x92dda8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x92ddac: mov             x2, x0
    // 0x92ddb0: r17 = "Could not allocate "
    //     0x92ddb0: ldr             x17, [PP, #0x64d0]  ; [pp+0x64d0] "Could not allocate "
    // 0x92ddb4: StoreField: r2->field_f = r17
    //     0x92ddb4: stur            w17, [x2, #0xf]
    // 0x92ddb8: ldr             x3, [fp, #0x10]
    // 0x92ddbc: r0 = BoxInt64Instr(r3)
    //     0x92ddbc: sbfiz           x0, x3, #1, #0x1f
    //     0x92ddc0: cmp             x3, x0, asr #1
    //     0x92ddc4: b.eq            #0x92ddd0
    //     0x92ddc8: bl              #0xd69bb8
    //     0x92ddcc: stur            x3, [x0, #7]
    // 0x92ddd0: StoreField: r2->field_13 = r0
    //     0x92ddd0: stur            w0, [x2, #0x13]
    // 0x92ddd4: r17 = " bytes."
    //     0x92ddd4: ldr             x17, [PP, #0x64d8]  ; [pp+0x64d8] " bytes."
    // 0x92ddd8: StoreField: r2->field_17 = r17
    //     0x92ddd8: stur            w17, [x2, #0x17]
    // 0x92dddc: SaveReg r2
    //     0x92dddc: str             x2, [SP, #-8]!
    // 0x92dde0: r0 = _interpolate()
    //     0x92dde0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x92dde4: add             SP, SP, #8
    // 0x92dde8: stur            x0, [fp, #-8]
    // 0x92ddec: r0 = ArgumentError()
    //     0x92ddec: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x92ddf0: mov             x1, x0
    // 0x92ddf4: ldur            x0, [fp, #-8]
    // 0x92ddf8: StoreField: r1->field_17 = r0
    //     0x92ddf8: stur            w0, [x1, #0x17]
    // 0x92ddfc: r0 = false
    //     0x92ddfc: add             x0, NULL, #0x30  ; false
    // 0x92de00: StoreField: r1->field_b = r0
    //     0x92de00: stur            w0, [x1, #0xb]
    // 0x92de04: mov             x0, x1
    // 0x92de08: r0 = Throw()
    //     0x92de08: bl              #0xd67e38  ; ThrowStub
    // 0x92de0c: brk             #0
    // 0x92de10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92de10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92de14: b               #0x92dc54
  }
  _ _fillMemory(/* No info */) {
    // ** addr: 0x92de18, size: 0x7c
    // 0x92de18: EnterFrame
    //     0x92de18: stp             fp, lr, [SP, #-0x10]!
    //     0x92de1c: mov             fp, SP
    // 0x92de20: CheckStackOverflow
    //     0x92de20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92de24: cmp             SP, x16
    //     0x92de28: b.ls            #0x92de84
    // 0x92de2c: r16 = <Uint8>
    //     0x92de2c: ldr             x16, [PP, #0x64e0]  ; [pp+0x64e0] TypeArguments: <Uint8>
    // 0x92de30: ldr             lr, [fp, #0x18]
    // 0x92de34: stp             lr, x16, [SP, #-0x10]!
    // 0x92de38: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92de38: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92de3c: r0 = cast()
    //     0x92de3c: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92de40: add             SP, SP, #0x10
    // 0x92de44: ldr             x1, [fp, #0x10]
    // 0x92de48: r2 = 0
    //     0x92de48: mov             x2, #0
    // 0x92de4c: CheckStackOverflow
    //     0x92de4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92de50: cmp             SP, x16
    //     0x92de54: b.ls            #0x92de8c
    // 0x92de58: cmp             x2, x1
    // 0x92de5c: b.ge            #0x92de74
    // 0x92de60: LoadField: r3 = r0->field_7
    //     0x92de60: ldur            x3, [x0, #7]
    // 0x92de64: strb            wzr, [x3, x2]
    // 0x92de68: add             x3, x2, #1
    // 0x92de6c: mov             x2, x3
    // 0x92de70: b               #0x92de4c
    // 0x92de74: r0 = Null
    //     0x92de74: mov             x0, NULL
    // 0x92de78: LeaveFrame
    //     0x92de78: mov             SP, fp
    //     0x92de7c: ldp             fp, lr, [SP], #0x10
    // 0x92de80: ret
    //     0x92de80: ret             
    // 0x92de84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92de84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92de88: b               #0x92de2c
    // 0x92de8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92de8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92de90: b               #0x92de58
  }
}

// class id: 4424, size: 0x8, field offset: 0x8
//   const constructor, 
class _MallocAllocator extends Object
    implements Allocator {

  _ allocate(/* No info */) {
    // ** addr: 0x92f818, size: 0x1d4
    // 0x92f818: EnterFrame
    //     0x92f818: stp             fp, lr, [SP, #-0x10]!
    //     0x92f81c: mov             fp, SP
    // 0x92f820: AllocStack(0x8)
    //     0x92f820: sub             SP, SP, #8
    // 0x92f824: SetupParameters()
    //     0x92f824: mov             x0, x4
    //     0x92f828: ldur            w1, [x0, #0xf]
    //     0x92f82c: add             x1, x1, HEAP, lsl #32
    //     0x92f830: cbnz            w1, #0x92f83c
    //     0x92f834: mov             x0, NULL
    //     0x92f838: b               #0x92f84c
    //     0x92f83c: ldur            w2, [x0, #0x17]
    //     0x92f840: add             x2, x2, HEAP, lsl #32
    //     0x92f844: add             x0, fp, w2, sxtw #2
    //     0x92f848: ldr             x0, [x0, #0x10]
    // 0x92f84c: CheckStackOverflow
    //     0x92f84c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92f850: cmp             SP, x16
    //     0x92f854: b.ls            #0x92f9e4
    // 0x92f858: cbnz            w1, #0x92f860
    // 0x92f85c: r0 = <NativeType>
    //     0x92f85c: ldr             x0, [PP, #0x64b8]  ; [pp+0x64b8] TypeArguments: <NativeType>
    // 0x92f860: stur            x0, [fp, #-8]
    // 0x92f864: r0 = InitLateStaticField(0x694) // [dart:io] Platform::isWindows
    //     0x92f864: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92f868: ldr             x0, [x0, #0xd28]
    //     0x92f86c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92f870: cmp             w0, w16
    //     0x92f874: b.ne            #0x92f880
    //     0x92f878: ldr             x2, [PP, #0x80]  ; [pp+0x80] Field <Platform.isWindows>: static late final (offset: 0x694)
    //     0x92f87c: bl              #0xd67cdc
    // 0x92f880: tbnz            w0, #4, #0x92f8f0
    // 0x92f884: ldr             x0, [fp, #0x10]
    // 0x92f888: r0 = InitLateStaticField(0xc3c) // [package:ffi/src/allocation.dart] ::winCoTaskMemAlloc
    //     0x92f888: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92f88c: ldr             x0, [x0, #0x1878]
    //     0x92f890: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92f894: cmp             w0, w16
    //     0x92f898: b.ne            #0x92f8a4
    //     0x92f89c: ldr             x2, [PP, #0x64c0]  ; [pp+0x64c0] Field <::.winCoTaskMemAlloc>: static late final (offset: 0xc3c)
    //     0x92f8a0: bl              #0xd67cdc
    // 0x92f8a4: mov             x3, x0
    // 0x92f8a8: ldr             x2, [fp, #0x10]
    // 0x92f8ac: r0 = BoxInt64Instr(r2)
    //     0x92f8ac: sbfiz           x0, x2, #1, #0x1f
    //     0x92f8b0: cmp             x2, x0, asr #1
    //     0x92f8b4: b.eq            #0x92f8c0
    //     0x92f8b8: bl              #0xd69bb8
    //     0x92f8bc: stur            x2, [x0, #7]
    // 0x92f8c0: stp             x0, x3, [SP, #-0x10]!
    // 0x92f8c4: mov             x0, x3
    // 0x92f8c8: ClosureCall
    //     0x92f8c8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x92f8cc: ldur            x2, [x0, #0x1f]
    //     0x92f8d0: blr             x2
    // 0x92f8d4: add             SP, SP, #0x10
    // 0x92f8d8: ldur            x16, [fp, #-8]
    // 0x92f8dc: stp             x0, x16, [SP, #-0x10]!
    // 0x92f8e0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92f8e0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92f8e4: r0 = cast()
    //     0x92f8e4: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92f8e8: add             SP, SP, #0x10
    // 0x92f8ec: b               #0x92f95c
    // 0x92f8f0: ldr             x0, [fp, #0x10]
    // 0x92f8f4: r0 = InitLateStaticField(0xc30) // [package:ffi/src/allocation.dart] ::posixMalloc
    //     0x92f8f4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92f8f8: ldr             x0, [x0, #0x1860]
    //     0x92f8fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92f900: cmp             w0, w16
    //     0x92f904: b.ne            #0x92f914
    //     0x92f908: add             x2, PP, #0x34, lsl #12  ; [pp+0x340e8] Field <::.posixMalloc>: static late final (offset: 0xc30)
    //     0x92f90c: ldr             x2, [x2, #0xe8]
    //     0x92f910: bl              #0xd67cdc
    // 0x92f914: mov             x3, x0
    // 0x92f918: ldr             x2, [fp, #0x10]
    // 0x92f91c: r0 = BoxInt64Instr(r2)
    //     0x92f91c: sbfiz           x0, x2, #1, #0x1f
    //     0x92f920: cmp             x2, x0, asr #1
    //     0x92f924: b.eq            #0x92f930
    //     0x92f928: bl              #0xd69bb8
    //     0x92f92c: stur            x2, [x0, #7]
    // 0x92f930: stp             x0, x3, [SP, #-0x10]!
    // 0x92f934: mov             x0, x3
    // 0x92f938: ClosureCall
    //     0x92f938: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x92f93c: ldur            x2, [x0, #0x1f]
    //     0x92f940: blr             x2
    // 0x92f944: add             SP, SP, #0x10
    // 0x92f948: ldur            x16, [fp, #-8]
    // 0x92f94c: stp             x0, x16, [SP, #-0x10]!
    // 0x92f950: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92f950: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92f954: r0 = cast()
    //     0x92f954: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92f958: add             SP, SP, #0x10
    // 0x92f95c: LoadField: r1 = r0->field_7
    //     0x92f95c: ldur            x1, [x0, #7]
    // 0x92f960: cbz             x1, #0x92f970
    // 0x92f964: LeaveFrame
    //     0x92f964: mov             SP, fp
    //     0x92f968: ldp             fp, lr, [SP], #0x10
    // 0x92f96c: ret
    //     0x92f96c: ret             
    // 0x92f970: ldr             x0, [fp, #0x10]
    // 0x92f974: r1 = Null
    //     0x92f974: mov             x1, NULL
    // 0x92f978: r2 = 6
    //     0x92f978: mov             x2, #6
    // 0x92f97c: r0 = AllocateArray()
    //     0x92f97c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x92f980: mov             x2, x0
    // 0x92f984: r17 = "Could not allocate "
    //     0x92f984: ldr             x17, [PP, #0x64d0]  ; [pp+0x64d0] "Could not allocate "
    // 0x92f988: StoreField: r2->field_f = r17
    //     0x92f988: stur            w17, [x2, #0xf]
    // 0x92f98c: ldr             x3, [fp, #0x10]
    // 0x92f990: r0 = BoxInt64Instr(r3)
    //     0x92f990: sbfiz           x0, x3, #1, #0x1f
    //     0x92f994: cmp             x3, x0, asr #1
    //     0x92f998: b.eq            #0x92f9a4
    //     0x92f99c: bl              #0xd69bb8
    //     0x92f9a0: stur            x3, [x0, #7]
    // 0x92f9a4: StoreField: r2->field_13 = r0
    //     0x92f9a4: stur            w0, [x2, #0x13]
    // 0x92f9a8: r17 = " bytes."
    //     0x92f9a8: ldr             x17, [PP, #0x64d8]  ; [pp+0x64d8] " bytes."
    // 0x92f9ac: StoreField: r2->field_17 = r17
    //     0x92f9ac: stur            w17, [x2, #0x17]
    // 0x92f9b0: SaveReg r2
    //     0x92f9b0: str             x2, [SP, #-8]!
    // 0x92f9b4: r0 = _interpolate()
    //     0x92f9b4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x92f9b8: add             SP, SP, #8
    // 0x92f9bc: stur            x0, [fp, #-8]
    // 0x92f9c0: r0 = ArgumentError()
    //     0x92f9c0: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x92f9c4: mov             x1, x0
    // 0x92f9c8: ldur            x0, [fp, #-8]
    // 0x92f9cc: StoreField: r1->field_17 = r0
    //     0x92f9cc: stur            w0, [x1, #0x17]
    // 0x92f9d0: r0 = false
    //     0x92f9d0: add             x0, NULL, #0x30  ; false
    // 0x92f9d4: StoreField: r1->field_b = r0
    //     0x92f9d4: stur            w0, [x1, #0xb]
    // 0x92f9d8: mov             x0, x1
    // 0x92f9dc: r0 = Throw()
    //     0x92f9dc: bl              #0xd67e38  ; ThrowStub
    // 0x92f9e0: brk             #0
    // 0x92f9e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92f9e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92f9e8: b               #0x92f858
  }
}

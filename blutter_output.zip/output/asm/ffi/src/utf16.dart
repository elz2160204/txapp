// lib: , url: package:ffi/src/utf16.dart

// class id: 1048995, size: 0x8
class :: {

  static _ Utf16Pointer.toDartString(/* No info */) {
    // ** addr: 0x92d72c, size: 0x5c
    // 0x92d72c: EnterFrame
    //     0x92d72c: stp             fp, lr, [SP, #-0x10]!
    //     0x92d730: mov             fp, SP
    // 0x92d734: CheckStackOverflow
    //     0x92d734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92d738: cmp             SP, x16
    //     0x92d73c: b.ls            #0x92d780
    // 0x92d740: ldr             x16, [fp, #0x10]
    // 0x92d744: SaveReg r16
    //     0x92d744: str             x16, [SP, #-8]!
    // 0x92d748: r0 = Utf16Pointer._ensureNotNullptr()
    //     0x92d748: bl              #0x92d850  ; [package:ffi/src/utf16.dart] ::Utf16Pointer._ensureNotNullptr
    // 0x92d74c: add             SP, SP, #8
    // 0x92d750: r16 = <Uint16>
    //     0x92d750: ldr             x16, [PP, #0x63c0]  ; [pp+0x63c0] TypeArguments: <Uint16>
    // 0x92d754: ldr             lr, [fp, #0x10]
    // 0x92d758: stp             lr, x16, [SP, #-0x10]!
    // 0x92d75c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92d75c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92d760: r0 = cast()
    //     0x92d760: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92d764: add             SP, SP, #0x10
    // 0x92d768: SaveReg r0
    //     0x92d768: str             x0, [SP, #-8]!
    // 0x92d76c: r0 = Utf16Pointer._toUnknownLengthString()
    //     0x92d76c: bl              #0x92d788  ; [package:ffi/src/utf16.dart] ::Utf16Pointer._toUnknownLengthString
    // 0x92d770: add             SP, SP, #8
    // 0x92d774: LeaveFrame
    //     0x92d774: mov             SP, fp
    //     0x92d778: ldp             fp, lr, [SP], #0x10
    // 0x92d77c: ret
    //     0x92d77c: ret             
    // 0x92d780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92d780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92d784: b               #0x92d740
  }
  static _ Utf16Pointer._toUnknownLengthString(/* No info */) {
    // ** addr: 0x92d788, size: 0xc8
    // 0x92d788: EnterFrame
    //     0x92d788: stp             fp, lr, [SP, #-0x10]!
    //     0x92d78c: mov             fp, SP
    // 0x92d790: AllocStack(0x18)
    //     0x92d790: sub             SP, SP, #0x18
    // 0x92d794: CheckStackOverflow
    //     0x92d794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92d798: cmp             SP, x16
    //     0x92d79c: b.ls            #0x92d840
    // 0x92d7a0: r0 = StringBuffer()
    //     0x92d7a0: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x92d7a4: stur            x0, [fp, #-8]
    // 0x92d7a8: SaveReg r0
    //     0x92d7a8: str             x0, [SP, #-8]!
    // 0x92d7ac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x92d7ac: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x92d7b0: r0 = StringBuffer()
    //     0x92d7b0: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0x92d7b4: add             SP, SP, #8
    // 0x92d7b8: r2 = 0
    //     0x92d7b8: mov             x2, #0
    // 0x92d7bc: ldr             x0, [fp, #0x10]
    // 0x92d7c0: stur            x2, [fp, #-0x18]
    // 0x92d7c4: CheckStackOverflow
    //     0x92d7c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92d7c8: cmp             SP, x16
    //     0x92d7cc: b.ls            #0x92d848
    // 0x92d7d0: lsl             x1, x2, #1
    // 0x92d7d4: LoadField: r3 = r0->field_7
    //     0x92d7d4: ldur            x3, [x0, #7]
    // 0x92d7d8: add             x4, x3, x1
    // 0x92d7dc: stur            x4, [fp, #-0x10]
    // 0x92d7e0: r1 = <Never>
    //     0x92d7e0: ldr             x1, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    // 0x92d7e4: r0 = Pointer()
    //     0x92d7e4: bl              #0x4ba128  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x92d7e8: mov             x1, x0
    // 0x92d7ec: ldur            x0, [fp, #-0x10]
    // 0x92d7f0: StoreField: r1->field_7 = r0
    //     0x92d7f0: stur            x0, [x1, #7]
    // 0x92d7f4: LoadField: r0 = r1->field_7
    //     0x92d7f4: ldur            x0, [x1, #7]
    // 0x92d7f8: ldrh            w1, [x0]
    // 0x92d7fc: lsl             x0, x1, #1
    // 0x92d800: cbnz            x1, #0x92d820
    // 0x92d804: ldur            x16, [fp, #-8]
    // 0x92d808: SaveReg r16
    //     0x92d808: str             x16, [SP, #-8]!
    // 0x92d80c: r0 = toString()
    //     0x92d80c: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0x92d810: add             SP, SP, #8
    // 0x92d814: LeaveFrame
    //     0x92d814: mov             SP, fp
    //     0x92d818: ldp             fp, lr, [SP], #0x10
    // 0x92d81c: ret
    //     0x92d81c: ret             
    // 0x92d820: ldur            x1, [fp, #-0x18]
    // 0x92d824: ldur            x16, [fp, #-8]
    // 0x92d828: stp             x0, x16, [SP, #-0x10]!
    // 0x92d82c: r0 = writeCharCode()
    //     0x92d82c: bl              #0x4d3a84  ; [dart:core] StringBuffer::writeCharCode
    // 0x92d830: add             SP, SP, #0x10
    // 0x92d834: ldur            x0, [fp, #-0x18]
    // 0x92d838: add             x2, x0, #1
    // 0x92d83c: b               #0x92d7bc
    // 0x92d840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92d840: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92d844: b               #0x92d7a0
    // 0x92d848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92d848: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92d84c: b               #0x92d7d0
  }
  static _ Utf16Pointer._ensureNotNullptr(/* No info */) {
    // ** addr: 0x92d850, size: 0xe8
    // 0x92d850: EnterFrame
    //     0x92d850: stp             fp, lr, [SP, #-0x10]!
    //     0x92d854: mov             fp, SP
    // 0x92d858: AllocStack(0x8)
    //     0x92d858: sub             SP, SP, #8
    // 0x92d85c: CheckStackOverflow
    //     0x92d85c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92d860: cmp             SP, x16
    //     0x92d864: b.ls            #0x92d930
    // 0x92d868: r0 = InitLateStaticField(0x2d8) // [dart:ffi] ::nullptr
    //     0x92d868: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x92d86c: ldr             x0, [x0, #0x5b0]
    //     0x92d870: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x92d874: cmp             w0, w16
    //     0x92d878: b.ne            #0x92d884
    //     0x92d87c: ldr             x2, [PP, #0x63c8]  ; [pp+0x63c8] Field <::.nullptr>: static late final (offset: 0x2d8)
    //     0x92d880: bl              #0xd67cdc
    // 0x92d884: mov             x3, x0
    // 0x92d888: r2 = Null
    //     0x92d888: mov             x2, NULL
    // 0x92d88c: r1 = Null
    //     0x92d88c: mov             x1, NULL
    // 0x92d890: stur            x3, [fp, #-8]
    // 0x92d894: cmp             w0, NULL
    // 0x92d898: b.eq            #0x92d8dc
    // 0x92d89c: branchIfSmi(r0, 0x92d8dc)
    //     0x92d89c: tbz             w0, #0, #0x92d8dc
    // 0x92d8a0: r8 = Pointer<NativeType>
    //     0x92d8a0: ldr             x8, [PP, #0x63d0]  ; [pp+0x63d0] Type: Pointer<NativeType>
    // 0x92d8a4: r3 = SubtypeTestCache
    //     0x92d8a4: ldr             x3, [PP, #0x63d8]  ; [pp+0x63d8] SubtypeTestCache
    // 0x92d8a8: r24 = Subtype3TestCacheStub
    //     0x92d8a8: ldr             x24, [PP, #0x10]  ; [pp+0x10] Stub: Subtype3TestCache (0x4ae294)
    // 0x92d8ac: LoadField: r30 = r24->field_7
    //     0x92d8ac: ldur            lr, [x24, #7]
    // 0x92d8b0: blr             lr
    // 0x92d8b4: cmp             w7, NULL
    // 0x92d8b8: b.eq            #0x92d8c4
    // 0x92d8bc: tbnz            w7, #4, #0x92d8dc
    // 0x92d8c0: b               #0x92d8e4
    // 0x92d8c4: r8 = Pointer<NativeType>
    //     0x92d8c4: ldr             x8, [PP, #0x63e0]  ; [pp+0x63e0] Type: Pointer<NativeType>
    // 0x92d8c8: r3 = SubtypeTestCache
    //     0x92d8c8: ldr             x3, [PP, #0x63e8]  ; [pp+0x63e8] SubtypeTestCache
    // 0x92d8cc: r24 = InstanceOfStub
    //     0x92d8cc: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x92d8d0: LoadField: r30 = r24->field_7
    //     0x92d8d0: ldur            lr, [x24, #7]
    // 0x92d8d4: blr             lr
    // 0x92d8d8: b               #0x92d8e8
    // 0x92d8dc: r0 = false
    //     0x92d8dc: add             x0, NULL, #0x30  ; false
    // 0x92d8e0: b               #0x92d8e8
    // 0x92d8e4: r0 = true
    //     0x92d8e4: add             x0, NULL, #0x20  ; true
    // 0x92d8e8: tbnz            w0, #4, #0x92d904
    // 0x92d8ec: ldr             x1, [fp, #0x10]
    // 0x92d8f0: ldur            x0, [fp, #-8]
    // 0x92d8f4: LoadField: r2 = r1->field_7
    //     0x92d8f4: ldur            x2, [x1, #7]
    // 0x92d8f8: LoadField: r1 = r0->field_7
    //     0x92d8f8: ldur            x1, [x0, #7]
    // 0x92d8fc: cmp             x2, x1
    // 0x92d900: b.eq            #0x92d914
    // 0x92d904: r0 = Null
    //     0x92d904: mov             x0, NULL
    // 0x92d908: LeaveFrame
    //     0x92d908: mov             SP, fp
    //     0x92d90c: ldp             fp, lr, [SP], #0x10
    // 0x92d910: ret
    //     0x92d910: ret             
    // 0x92d914: r0 = UnsupportedError()
    //     0x92d914: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x92d918: mov             x1, x0
    // 0x92d91c: r0 = "Operation \'toDartString\' not allowed on a \'nullptr\'."
    //     0x92d91c: ldr             x0, [PP, #0x63f0]  ; [pp+0x63f0] "Operation \'toDartString\' not allowed on a \'nullptr\'."
    // 0x92d920: StoreField: r1->field_b = r0
    //     0x92d920: stur            w0, [x1, #0xb]
    // 0x92d924: mov             x0, x1
    // 0x92d928: r0 = Throw()
    //     0x92d928: bl              #0xd67e38  ; ThrowStub
    // 0x92d92c: brk             #0
    // 0x92d930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92d930: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92d934: b               #0x92d868
  }
  static _ StringUtf16Pointer.toNativeUtf16(/* No info */) {
    // ** addr: 0x92f608, size: 0x144
    // 0x92f608: EnterFrame
    //     0x92f608: stp             fp, lr, [SP, #-0x10]!
    //     0x92f60c: mov             fp, SP
    // 0x92f610: AllocStack(0x28)
    //     0x92f610: sub             SP, SP, #0x28
    // 0x92f614: CheckStackOverflow
    //     0x92f614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x92f618: cmp             SP, x16
    //     0x92f61c: b.ls            #0x92f728
    // 0x92f620: r1 = <int>
    //     0x92f620: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x92f624: r0 = CodeUnits()
    //     0x92f624: bl              #0x52dacc  ; AllocateCodeUnitsStub -> CodeUnits (size=0x10)
    // 0x92f628: mov             x1, x0
    // 0x92f62c: ldr             x0, [fp, #0x10]
    // 0x92f630: stur            x1, [fp, #-0x18]
    // 0x92f634: StoreField: r1->field_b = r0
    //     0x92f634: stur            w0, [x1, #0xb]
    // 0x92f638: LoadField: r2 = r0->field_7
    //     0x92f638: ldur            w2, [x0, #7]
    // 0x92f63c: DecompressPointer r2
    //     0x92f63c: add             x2, x2, HEAP, lsl #32
    // 0x92f640: r0 = LoadInt32Instr(r2)
    //     0x92f640: sbfx            x0, x2, #1, #0x1f
    // 0x92f644: stur            x0, [fp, #-0x10]
    // 0x92f648: add             x2, x0, #1
    // 0x92f64c: stur            x2, [fp, #-8]
    // 0x92f650: lsl             x3, x2, #1
    // 0x92f654: r16 = <Uint16>
    //     0x92f654: ldr             x16, [PP, #0x63c0]  ; [pp+0x63c0] TypeArguments: <Uint16>
    // 0x92f658: r30 = Instance__MallocAllocator
    //     0x92f658: add             lr, PP, #0x34, lsl #12  ; [pp+0x340d0] Obj!_MallocAllocator@b4fd01
    //     0x92f65c: ldr             lr, [lr, #0xd0]
    // 0x92f660: stp             lr, x16, [SP, #-0x10]!
    // 0x92f664: SaveReg r3
    //     0x92f664: str             x3, [SP, #-8]!
    // 0x92f668: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x92f668: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x92f66c: r0 = allocate()
    //     0x92f66c: bl              #0x92f818  ; [package:ffi/src/allocation.dart] _MallocAllocator::allocate
    // 0x92f670: add             SP, SP, #0x18
    // 0x92f674: stur            x0, [fp, #-0x20]
    // 0x92f678: SaveReg r0
    //     0x92f678: str             x0, [SP, #-8]!
    // 0x92f67c: ldur            x1, [fp, #-8]
    // 0x92f680: SaveReg r1
    //     0x92f680: str             x1, [SP, #-8]!
    // 0x92f684: r0 = Uint16Pointer.asTypedList()
    //     0x92f684: bl              #0x92f74c  ; [dart:ffi] ::Uint16Pointer.asTypedList
    // 0x92f688: add             SP, SP, #0x10
    // 0x92f68c: mov             x1, x0
    // 0x92f690: stur            x1, [fp, #-0x28]
    // 0x92f694: r0 = LoadClassIdInstr(r1)
    //     0x92f694: ldur            x0, [x1, #-1]
    //     0x92f698: ubfx            x0, x0, #0xc, #0x14
    // 0x92f69c: stp             xzr, x1, [SP, #-0x10]!
    // 0x92f6a0: ldur            x2, [fp, #-0x10]
    // 0x92f6a4: ldur            x16, [fp, #-0x18]
    // 0x92f6a8: stp             x16, x2, [SP, #-0x10]!
    // 0x92f6ac: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x92f6ac: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x92f6b0: r0 = GDT[cid_x0 + 0x10330]()
    //     0x92f6b0: mov             x17, #0x330
    //     0x92f6b4: movk            x17, #1, lsl #16
    //     0x92f6b8: add             lr, x0, x17
    //     0x92f6bc: ldr             lr, [x21, lr, lsl #3]
    //     0x92f6c0: blr             lr
    // 0x92f6c4: add             SP, SP, #0x20
    // 0x92f6c8: ldur            x2, [fp, #-0x28]
    // 0x92f6cc: ldurb           w16, [x2, #-1]
    // 0x92f6d0: tbnz            w16, #6, #0x92f730
    // 0x92f6d4: LoadField: r0 = r2->field_13
    //     0x92f6d4: ldur            w0, [x2, #0x13]
    // 0x92f6d8: DecompressPointer r0
    //     0x92f6d8: add             x0, x0, HEAP, lsl #32
    // 0x92f6dc: r1 = LoadInt32Instr(r0)
    //     0x92f6dc: sbfx            x1, x0, #1, #0x1f
    // 0x92f6e0: mov             x0, x1
    // 0x92f6e4: ldur            x1, [fp, #-0x10]
    // 0x92f6e8: cmp             x1, x0
    // 0x92f6ec: b.hs            #0x92f748
    // 0x92f6f0: LoadField: r0 = r2->field_7
    //     0x92f6f0: ldur            x0, [x2, #7]
    // 0x92f6f4: ldur            x1, [fp, #-0x10]
    // 0x92f6f8: add             x2, x0, x1, lsl #1
    // 0x92f6fc: strh            wzr, [x2]
    // 0x92f700: r16 = <Utf16>
    //     0x92f700: add             x16, PP, #0xa, lsl #12  ; [pp+0xab70] TypeArguments: <Utf16>
    //     0x92f704: ldr             x16, [x16, #0xb70]
    // 0x92f708: ldur            lr, [fp, #-0x20]
    // 0x92f70c: stp             lr, x16, [SP, #-0x10]!
    // 0x92f710: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x92f710: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92f714: r0 = cast()
    //     0x92f714: bl              #0x4ba0f0  ; [dart:ffi] Pointer::cast
    // 0x92f718: add             SP, SP, #0x10
    // 0x92f71c: LeaveFrame
    //     0x92f71c: mov             SP, fp
    //     0x92f720: ldp             fp, lr, [SP], #0x10
    // 0x92f724: ret
    //     0x92f724: ret             
    // 0x92f728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x92f728: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x92f72c: b               #0x92f620
    // 0x92f730: SaveReg r2
    //     0x92f730: str             x2, [SP, #-8]!
    // 0x92f734: ldr             x5, [THR, #0x468]  ; THR::WriteError
    // 0x92f738: r4 = 0
    //     0x92f738: mov             x4, #0
    // 0x92f73c: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x92f740: blr             lr
    // 0x92f744: brk             #0
    // 0x92f748: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x92f748: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 6262, size: 0x8, field offset: 0x8
abstract class Utf16 extends Opaque {
}

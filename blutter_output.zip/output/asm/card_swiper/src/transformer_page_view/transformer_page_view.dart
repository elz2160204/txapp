// lib: transformer_page_view, url: package:card_swiper/src/transformer_page_view/transformer_page_view.dart

// class id: 1048737, size: 0x8
class :: {
}

// class id: 3409, size: 0x38, field offset: 0x14
class _TransformerPageViewState extends State<TransformerPageView> {

  late TransformerPageController _pageController; // offset: 0x30
  late int _fromIndex; // offset: 0x28
  late double _currentPixels; // offset: 0x20

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x797b44, size: 0x4ec
    // 0x797b44: EnterFrame
    //     0x797b44: stp             fp, lr, [SP, #-0x10]!
    //     0x797b48: mov             fp, SP
    // 0x797b4c: AllocStack(0x28)
    //     0x797b4c: sub             SP, SP, #0x28
    // 0x797b50: CheckStackOverflow
    //     0x797b50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x797b54: cmp             SP, x16
    //     0x797b58: b.ls            #0x798004
    // 0x797b5c: ldr             x0, [fp, #0x10]
    // 0x797b60: r2 = Null
    //     0x797b60: mov             x2, NULL
    // 0x797b64: r1 = Null
    //     0x797b64: mov             x1, NULL
    // 0x797b68: r4 = 59
    //     0x797b68: mov             x4, #0x3b
    // 0x797b6c: branchIfSmi(r0, 0x797b78)
    //     0x797b6c: tbz             w0, #0, #0x797b78
    // 0x797b70: r4 = LoadClassIdInstr(r0)
    //     0x797b70: ldur            x4, [x0, #-1]
    //     0x797b74: ubfx            x4, x4, #0xc, #0x14
    // 0x797b78: r17 = 4220
    //     0x797b78: mov             x17, #0x107c
    // 0x797b7c: cmp             x4, x17
    // 0x797b80: b.eq            #0x797b98
    // 0x797b84: r8 = TransformerPageView
    //     0x797b84: add             x8, PP, #0x38, lsl #12  ; [pp+0x386d8] Type: TransformerPageView
    //     0x797b88: ldr             x8, [x8, #0x6d8]
    // 0x797b8c: r3 = Null
    //     0x797b8c: add             x3, PP, #0x38, lsl #12  ; [pp+0x386e0] Null
    //     0x797b90: ldr             x3, [x3, #0x6e0]
    // 0x797b94: r0 = TransformerPageView()
    //     0x797b94: bl              #0x79845c  ; IsType_TransformerPageView_Stub
    // 0x797b98: ldr             x2, [fp, #0x18]
    // 0x797b9c: LoadField: r1 = r2->field_b
    //     0x797b9c: ldur            w1, [x2, #0xb]
    // 0x797ba0: DecompressPointer r1
    //     0x797ba0: add             x1, x1, HEAP, lsl #32
    // 0x797ba4: cmp             w1, NULL
    // 0x797ba8: b.eq            #0x79800c
    // 0x797bac: LoadField: r3 = r1->field_b
    //     0x797bac: ldur            w3, [x1, #0xb]
    // 0x797bb0: DecompressPointer r3
    //     0x797bb0: add             x3, x3, HEAP, lsl #32
    // 0x797bb4: mov             x0, x3
    // 0x797bb8: StoreField: r2->field_2b = r0
    //     0x797bb8: stur            w0, [x2, #0x2b]
    //     0x797bbc: ldurb           w16, [x2, #-1]
    //     0x797bc0: ldurb           w17, [x0, #-1]
    //     0x797bc4: and             x16, x17, x16, lsr #2
    //     0x797bc8: tst             x16, HEAP, lsr #32
    //     0x797bcc: b.eq            #0x797bd4
    //     0x797bd0: bl              #0xd6828c
    // 0x797bd4: LoadField: r4 = r1->field_47
    //     0x797bd4: ldur            x4, [x1, #0x47]
    // 0x797bd8: stur            x4, [fp, #-0x20]
    // 0x797bdc: LoadField: r0 = r2->field_2f
    //     0x797bdc: ldur            w0, [x2, #0x2f]
    // 0x797be0: DecompressPointer r0
    //     0x797be0: add             x0, x0, HEAP, lsl #32
    // 0x797be4: r16 = Sentinel
    //     0x797be4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x797be8: cmp             w0, w16
    // 0x797bec: b.eq            #0x798010
    // 0x797bf0: LoadField: r5 = r1->field_2f
    //     0x797bf0: ldur            w5, [x1, #0x2f]
    // 0x797bf4: DecompressPointer r5
    //     0x797bf4: add             x5, x5, HEAP, lsl #32
    // 0x797bf8: cmp             w0, w5
    // 0x797bfc: b.eq            #0x797cc8
    // 0x797c00: cmp             w5, NULL
    // 0x797c04: b.eq            #0x797c38
    // 0x797c08: mov             x0, x5
    // 0x797c0c: StoreField: r2->field_2f = r0
    //     0x797c0c: stur            w0, [x2, #0x2f]
    //     0x797c10: ldurb           w16, [x2, #-1]
    //     0x797c14: ldurb           w17, [x0, #-1]
    //     0x797c18: and             x16, x17, x16, lsr #2
    //     0x797c1c: tst             x16, HEAP, lsr #32
    //     0x797c20: b.eq            #0x797c28
    //     0x797c24: bl              #0xd6828c
    // 0x797c28: mov             x0, x5
    // 0x797c2c: mov             x1, x2
    // 0x797c30: r2 = false
    //     0x797c30: add             x2, NULL, #0x30  ; false
    // 0x797c34: b               #0x797cbc
    // 0x797c38: LoadField: r5 = r1->field_37
    //     0x797c38: ldur            x5, [x1, #0x37]
    // 0x797c3c: stur            x5, [fp, #-0x18]
    // 0x797c40: LoadField: r6 = r1->field_33
    //     0x797c40: ldur            w6, [x1, #0x33]
    // 0x797c44: DecompressPointer r6
    //     0x797c44: add             x6, x6, HEAP, lsl #32
    // 0x797c48: stur            x6, [fp, #-0x10]
    // 0x797c4c: cmp             w3, NULL
    // 0x797c50: b.eq            #0x797c54
    // 0x797c54: r0 = BoxInt64Instr(r4)
    //     0x797c54: sbfiz           x0, x4, #1, #0x1f
    //     0x797c58: cmp             x4, x0, asr #1
    //     0x797c5c: b.eq            #0x797c68
    //     0x797c60: bl              #0xd69bb8
    //     0x797c64: stur            x4, [x0, #7]
    // 0x797c68: stur            x0, [fp, #-8]
    // 0x797c6c: r0 = TransformerPageController()
    //     0x797c6c: bl              #0x7977a0  ; AllocateTransformerPageControllerStub -> TransformerPageController (size=0x5c)
    // 0x797c70: stur            x0, [fp, #-0x28]
    // 0x797c74: ldur            x16, [fp, #-8]
    // 0x797c78: stp             x16, x0, [SP, #-0x10]!
    // 0x797c7c: ldur            x1, [fp, #-0x18]
    // 0x797c80: ldur            x16, [fp, #-0x10]
    // 0x797c84: stp             x16, x1, [SP, #-0x10]!
    // 0x797c88: r0 = TransformerPageController()
    //     0x797c88: bl              #0x7976fc  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::TransformerPageController
    // 0x797c8c: add             SP, SP, #0x20
    // 0x797c90: ldur            x0, [fp, #-0x28]
    // 0x797c94: ldr             x1, [fp, #0x18]
    // 0x797c98: StoreField: r1->field_2f = r0
    //     0x797c98: stur            w0, [x1, #0x2f]
    //     0x797c9c: ldurb           w16, [x1, #-1]
    //     0x797ca0: ldurb           w17, [x0, #-1]
    //     0x797ca4: and             x16, x17, x16, lsr #2
    //     0x797ca8: tst             x16, HEAP, lsr #32
    //     0x797cac: b.eq            #0x797cb4
    //     0x797cb0: bl              #0xd6826c
    // 0x797cb4: ldur            x0, [fp, #-0x28]
    // 0x797cb8: r2 = true
    //     0x797cb8: add             x2, NULL, #0x20  ; true
    // 0x797cbc: mov             x3, x2
    // 0x797cc0: mov             x2, x0
    // 0x797cc4: b               #0x797cd4
    // 0x797cc8: mov             x1, x2
    // 0x797ccc: mov             x2, x0
    // 0x797cd0: r3 = false
    //     0x797cd0: add             x3, NULL, #0x30  ; false
    // 0x797cd4: ldur            x0, [fp, #-0x20]
    // 0x797cd8: stur            x3, [fp, #-8]
    // 0x797cdc: LoadField: r4 = r1->field_17
    //     0x797cdc: ldur            x4, [x1, #0x17]
    // 0x797ce0: stp             x4, x2, [SP, #-0x10]!
    // 0x797ce4: r0 = getRenderIndexFromRealIndex()
    //     0x797ce4: bl              #0x798338  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::getRenderIndexFromRealIndex
    // 0x797ce8: add             SP, SP, #0x10
    // 0x797cec: ldur            x2, [fp, #-0x20]
    // 0x797cf0: cmp             x0, x2
    // 0x797cf4: b.eq            #0x797da8
    // 0x797cf8: ldr             x3, [fp, #0x18]
    // 0x797cfc: ldur            x4, [fp, #-8]
    // 0x797d00: LoadField: r5 = r3->field_2f
    //     0x797d00: ldur            w5, [x3, #0x2f]
    // 0x797d04: DecompressPointer r5
    //     0x797d04: add             x5, x5, HEAP, lsl #32
    // 0x797d08: LoadField: r6 = r5->field_37
    //     0x797d08: ldur            x6, [x5, #0x37]
    // 0x797d0c: StoreField: r3->field_17 = r6
    //     0x797d0c: stur            x6, [x3, #0x17]
    // 0x797d10: r0 = BoxInt64Instr(r6)
    //     0x797d10: sbfiz           x0, x6, #1, #0x1f
    //     0x797d14: cmp             x6, x0, asr #1
    //     0x797d18: b.eq            #0x797d24
    //     0x797d1c: bl              #0xd69bb8
    //     0x797d20: stur            x6, [x0, #7]
    // 0x797d24: StoreField: r3->field_27 = r0
    //     0x797d24: stur            w0, [x3, #0x27]
    //     0x797d28: tbz             w0, #0, #0x797d44
    //     0x797d2c: ldurb           w16, [x3, #-1]
    //     0x797d30: ldurb           w17, [x0, #-1]
    //     0x797d34: and             x16, x17, x16, lsr #2
    //     0x797d38: tst             x16, HEAP, lsr #32
    //     0x797d3c: b.eq            #0x797d44
    //     0x797d40: bl              #0xd682ac
    // 0x797d44: tbz             w4, #4, #0x797da8
    // 0x797d48: stp             x2, x5, [SP, #-0x10]!
    // 0x797d4c: r0 = getRealIndexFromRenderIndex()
    //     0x797d4c: bl              #0x798304  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::getRealIndexFromRenderIndex
    // 0x797d50: add             SP, SP, #0x10
    // 0x797d54: mov             x1, x0
    // 0x797d58: ldr             x0, [fp, #0x18]
    // 0x797d5c: LoadField: r2 = r0->field_2f
    //     0x797d5c: ldur            w2, [x0, #0x2f]
    // 0x797d60: DecompressPointer r2
    //     0x797d60: add             x2, x2, HEAP, lsl #32
    // 0x797d64: LoadField: r3 = r2->field_33
    //     0x797d64: ldur            w3, [x2, #0x33]
    // 0x797d68: DecompressPointer r3
    //     0x797d68: add             x3, x3, HEAP, lsl #32
    // 0x797d6c: LoadField: r4 = r3->field_b
    //     0x797d6c: ldur            w4, [x3, #0xb]
    // 0x797d70: DecompressPointer r4
    //     0x797d70: add             x4, x4, HEAP, lsl #32
    // 0x797d74: cbz             w4, #0x797da8
    // 0x797d78: LoadField: r3 = r0->field_b
    //     0x797d78: ldur            w3, [x0, #0xb]
    // 0x797d7c: DecompressPointer r3
    //     0x797d7c: add             x3, x3, HEAP, lsl #32
    // 0x797d80: cmp             w3, NULL
    // 0x797d84: b.eq            #0x79801c
    // 0x797d88: LoadField: r4 = r3->field_27
    //     0x797d88: ldur            w4, [x3, #0x27]
    // 0x797d8c: DecompressPointer r4
    //     0x797d8c: add             x4, x4, HEAP, lsl #32
    // 0x797d90: stp             x1, x2, [SP, #-0x10]!
    // 0x797d94: r16 = Instance_Cubic
    //     0x797d94: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x797d98: ldr             x16, [x16, #0xfc8]
    // 0x797d9c: stp             x4, x16, [SP, #-0x10]!
    // 0x797da0: r0 = animateToPage()
    //     0x797da0: bl              #0x798030  ; [package:flutter/src/widgets/page_view.dart] PageController::animateToPage
    // 0x797da4: add             SP, SP, #0x20
    // 0x797da8: ldr             x0, [fp, #0x18]
    // 0x797dac: LoadField: r1 = r0->field_2b
    //     0x797dac: ldur            w1, [x0, #0x2b]
    // 0x797db0: DecompressPointer r1
    //     0x797db0: add             x1, x1, HEAP, lsl #32
    // 0x797db4: cmp             w1, NULL
    // 0x797db8: b.eq            #0x797ed0
    // 0x797dbc: r1 = LoadStaticField(0xbb8)
    //     0x797dbc: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x797dc0: ldr             x1, [x1, #0x1770]
    // 0x797dc4: stur            x1, [fp, #-8]
    // 0x797dc8: cmp             w1, NULL
    // 0x797dcc: b.eq            #0x798020
    // 0x797dd0: r1 = 1
    //     0x797dd0: mov             x1, #1
    // 0x797dd4: r0 = AllocateContext()
    //     0x797dd4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x797dd8: mov             x1, x0
    // 0x797ddc: ldr             x0, [fp, #0x18]
    // 0x797de0: StoreField: r1->field_f = r0
    //     0x797de0: stur            w0, [x1, #0xf]
    // 0x797de4: ldur            x2, [fp, #-8]
    // 0x797de8: LoadField: r3 = r2->field_57
    //     0x797de8: ldur            w3, [x2, #0x57]
    // 0x797dec: DecompressPointer r3
    //     0x797dec: add             x3, x3, HEAP, lsl #32
    // 0x797df0: stur            x3, [fp, #-0x10]
    // 0x797df4: LoadField: r4 = r3->field_7
    //     0x797df4: ldur            w4, [x3, #7]
    // 0x797df8: DecompressPointer r4
    //     0x797df8: add             x4, x4, HEAP, lsl #32
    // 0x797dfc: mov             x2, x1
    // 0x797e00: stur            x4, [fp, #-8]
    // 0x797e04: r1 = Function '_onGetSize@205299810':.
    //     0x797e04: add             x1, PP, #0x38, lsl #12  ; [pp+0x386b8] AnonymousClosure: (0x79876c), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_onGetSize (0x7987b8)
    //     0x797e08: ldr             x1, [x1, #0x6b8]
    // 0x797e0c: r0 = AllocateClosure()
    //     0x797e0c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x797e10: ldur            x2, [fp, #-8]
    // 0x797e14: mov             x3, x0
    // 0x797e18: r1 = Null
    //     0x797e18: mov             x1, NULL
    // 0x797e1c: stur            x3, [fp, #-8]
    // 0x797e20: cmp             w2, NULL
    // 0x797e24: b.eq            #0x797e44
    // 0x797e28: LoadField: r4 = r2->field_17
    //     0x797e28: ldur            w4, [x2, #0x17]
    // 0x797e2c: DecompressPointer r4
    //     0x797e2c: add             x4, x4, HEAP, lsl #32
    // 0x797e30: r8 = X0
    //     0x797e30: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x797e34: LoadField: r9 = r4->field_7
    //     0x797e34: ldur            x9, [x4, #7]
    // 0x797e38: r3 = Null
    //     0x797e38: add             x3, PP, #0x38, lsl #12  ; [pp+0x386f0] Null
    //     0x797e3c: ldr             x3, [x3, #0x6f0]
    // 0x797e40: blr             x9
    // 0x797e44: ldur            x0, [fp, #-0x10]
    // 0x797e48: LoadField: r1 = r0->field_b
    //     0x797e48: ldur            w1, [x0, #0xb]
    // 0x797e4c: DecompressPointer r1
    //     0x797e4c: add             x1, x1, HEAP, lsl #32
    // 0x797e50: stur            x1, [fp, #-0x28]
    // 0x797e54: LoadField: r2 = r0->field_f
    //     0x797e54: ldur            w2, [x0, #0xf]
    // 0x797e58: DecompressPointer r2
    //     0x797e58: add             x2, x2, HEAP, lsl #32
    // 0x797e5c: LoadField: r3 = r2->field_b
    //     0x797e5c: ldur            w3, [x2, #0xb]
    // 0x797e60: DecompressPointer r3
    //     0x797e60: add             x3, x3, HEAP, lsl #32
    // 0x797e64: cmp             w1, w3
    // 0x797e68: b.ne            #0x797e78
    // 0x797e6c: SaveReg r0
    //     0x797e6c: str             x0, [SP, #-8]!
    // 0x797e70: r0 = _growToNextCapacity()
    //     0x797e70: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x797e74: add             SP, SP, #8
    // 0x797e78: ldur            x2, [fp, #-0x10]
    // 0x797e7c: ldur            x0, [fp, #-0x28]
    // 0x797e80: r3 = LoadInt32Instr(r0)
    //     0x797e80: sbfx            x3, x0, #1, #0x1f
    // 0x797e84: add             x0, x3, #1
    // 0x797e88: lsl             x1, x0, #1
    // 0x797e8c: StoreField: r2->field_b = r1
    //     0x797e8c: stur            w1, [x2, #0xb]
    // 0x797e90: mov             x1, x3
    // 0x797e94: cmp             x1, x0
    // 0x797e98: b.hs            #0x798024
    // 0x797e9c: LoadField: r1 = r2->field_f
    //     0x797e9c: ldur            w1, [x2, #0xf]
    // 0x797ea0: DecompressPointer r1
    //     0x797ea0: add             x1, x1, HEAP, lsl #32
    // 0x797ea4: ldur            x0, [fp, #-8]
    // 0x797ea8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x797ea8: add             x25, x1, x3, lsl #2
    //     0x797eac: add             x25, x25, #0xf
    //     0x797eb0: str             w0, [x25]
    //     0x797eb4: tbz             w0, #0, #0x797ed0
    //     0x797eb8: ldurb           w16, [x1, #-1]
    //     0x797ebc: ldurb           w17, [x0, #-1]
    //     0x797ec0: and             x16, x17, x16, lsr #2
    //     0x797ec4: tst             x16, HEAP, lsr #32
    //     0x797ec8: b.eq            #0x797ed0
    //     0x797ecc: bl              #0xd67e5c
    // 0x797ed0: ldr             x0, [fp, #0x18]
    // 0x797ed4: LoadField: r1 = r0->field_33
    //     0x797ed4: ldur            w1, [x0, #0x33]
    // 0x797ed8: DecompressPointer r1
    //     0x797ed8: add             x1, x1, HEAP, lsl #32
    // 0x797edc: stur            x1, [fp, #-8]
    // 0x797ee0: LoadField: r2 = r0->field_b
    //     0x797ee0: ldur            w2, [x0, #0xb]
    // 0x797ee4: DecompressPointer r2
    //     0x797ee4: add             x2, x2, HEAP, lsl #32
    // 0x797ee8: cmp             w2, NULL
    // 0x797eec: b.eq            #0x798028
    // 0x797ef0: LoadField: r3 = r2->field_23
    //     0x797ef0: ldur            w3, [x2, #0x23]
    // 0x797ef4: DecompressPointer r3
    //     0x797ef4: add             x3, x3, HEAP, lsl #32
    // 0x797ef8: cmp             w1, w3
    // 0x797efc: b.eq            #0x797fb8
    // 0x797f00: cmp             w1, NULL
    // 0x797f04: b.ne            #0x797f10
    // 0x797f08: mov             x1, x0
    // 0x797f0c: b               #0x797f48
    // 0x797f10: r1 = 1
    //     0x797f10: mov             x1, #1
    // 0x797f14: r0 = AllocateContext()
    //     0x797f14: bl              #0xd68aa4  ; AllocateContextStub
    // 0x797f18: mov             x1, x0
    // 0x797f1c: ldr             x0, [fp, #0x18]
    // 0x797f20: StoreField: r1->field_f = r0
    //     0x797f20: stur            w0, [x1, #0xf]
    // 0x797f24: mov             x2, x1
    // 0x797f28: r1 = Function 'onChangeNotifier':.
    //     0x797f28: add             x1, PP, #0x38, lsl #12  ; [pp+0x386a0] AnonymousClosure: (0x798480), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::onChangeNotifier (0x7984c8)
    //     0x797f2c: ldr             x1, [x1, #0x6a0]
    // 0x797f30: r0 = AllocateClosure()
    //     0x797f30: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x797f34: ldur            x16, [fp, #-8]
    // 0x797f38: stp             x0, x16, [SP, #-0x10]!
    // 0x797f3c: r0 = removeListener()
    //     0x797f3c: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x797f40: add             SP, SP, #0x10
    // 0x797f44: ldr             x1, [fp, #0x18]
    // 0x797f48: LoadField: r0 = r1->field_b
    //     0x797f48: ldur            w0, [x1, #0xb]
    // 0x797f4c: DecompressPointer r0
    //     0x797f4c: add             x0, x0, HEAP, lsl #32
    // 0x797f50: cmp             w0, NULL
    // 0x797f54: b.eq            #0x79802c
    // 0x797f58: LoadField: r2 = r0->field_23
    //     0x797f58: ldur            w2, [x0, #0x23]
    // 0x797f5c: DecompressPointer r2
    //     0x797f5c: add             x2, x2, HEAP, lsl #32
    // 0x797f60: mov             x0, x2
    // 0x797f64: stur            x2, [fp, #-8]
    // 0x797f68: StoreField: r1->field_33 = r0
    //     0x797f68: stur            w0, [x1, #0x33]
    //     0x797f6c: ldurb           w16, [x1, #-1]
    //     0x797f70: ldurb           w17, [x0, #-1]
    //     0x797f74: and             x16, x17, x16, lsr #2
    //     0x797f78: tst             x16, HEAP, lsr #32
    //     0x797f7c: b.eq            #0x797f84
    //     0x797f80: bl              #0xd6826c
    // 0x797f84: r1 = 1
    //     0x797f84: mov             x1, #1
    // 0x797f88: r0 = AllocateContext()
    //     0x797f88: bl              #0xd68aa4  ; AllocateContextStub
    // 0x797f8c: mov             x1, x0
    // 0x797f90: ldr             x0, [fp, #0x18]
    // 0x797f94: StoreField: r1->field_f = r0
    //     0x797f94: stur            w0, [x1, #0xf]
    // 0x797f98: mov             x2, x1
    // 0x797f9c: r1 = Function 'onChangeNotifier':.
    //     0x797f9c: add             x1, PP, #0x38, lsl #12  ; [pp+0x386a0] AnonymousClosure: (0x798480), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::onChangeNotifier (0x7984c8)
    //     0x797fa0: ldr             x1, [x1, #0x6a0]
    // 0x797fa4: r0 = AllocateClosure()
    //     0x797fa4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x797fa8: ldur            x16, [fp, #-8]
    // 0x797fac: stp             x0, x16, [SP, #-0x10]!
    // 0x797fb0: r0 = addListener()
    //     0x797fb0: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x797fb4: add             SP, SP, #0x10
    // 0x797fb8: ldr             x0, [fp, #0x18]
    // 0x797fbc: LoadField: r2 = r0->field_7
    //     0x797fbc: ldur            w2, [x0, #7]
    // 0x797fc0: DecompressPointer r2
    //     0x797fc0: add             x2, x2, HEAP, lsl #32
    // 0x797fc4: ldr             x0, [fp, #0x10]
    // 0x797fc8: r1 = Null
    //     0x797fc8: mov             x1, NULL
    // 0x797fcc: cmp             w2, NULL
    // 0x797fd0: b.eq            #0x797ff4
    // 0x797fd4: LoadField: r4 = r2->field_17
    //     0x797fd4: ldur            w4, [x2, #0x17]
    // 0x797fd8: DecompressPointer r4
    //     0x797fd8: add             x4, x4, HEAP, lsl #32
    // 0x797fdc: r8 = X0 bound StatefulWidget
    //     0x797fdc: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x797fe0: ldr             x8, [x8, #0x858]
    // 0x797fe4: LoadField: r9 = r4->field_7
    //     0x797fe4: ldur            x9, [x4, #7]
    // 0x797fe8: r3 = Null
    //     0x797fe8: add             x3, PP, #0x38, lsl #12  ; [pp+0x38700] Null
    //     0x797fec: ldr             x3, [x3, #0x700]
    // 0x797ff0: blr             x9
    // 0x797ff4: r0 = Null
    //     0x797ff4: mov             x0, NULL
    // 0x797ff8: LeaveFrame
    //     0x797ff8: mov             SP, fp
    //     0x797ffc: ldp             fp, lr, [SP], #0x10
    // 0x798000: ret
    //     0x798000: ret             
    // 0x798004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x798004: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x798008: b               #0x797b5c
    // 0x79800c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79800c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x798010: r9 = _pageController
    //     0x798010: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x798014: ldr             x9, [x9, #0x6b0]
    // 0x798018: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x798018: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x79801c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79801c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x798020: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x798020: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x798024: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x798024: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x798028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x798028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79802c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79802c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onChangeNotifier(dynamic) {
    // ** addr: 0x798480, size: 0x48
    // 0x798480: EnterFrame
    //     0x798480: stp             fp, lr, [SP, #-0x10]!
    //     0x798484: mov             fp, SP
    // 0x798488: ldr             x0, [fp, #0x10]
    // 0x79848c: LoadField: r1 = r0->field_17
    //     0x79848c: ldur            w1, [x0, #0x17]
    // 0x798490: DecompressPointer r1
    //     0x798490: add             x1, x1, HEAP, lsl #32
    // 0x798494: CheckStackOverflow
    //     0x798494: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x798498: cmp             SP, x16
    //     0x79849c: b.ls            #0x7984c0
    // 0x7984a0: LoadField: r0 = r1->field_f
    //     0x7984a0: ldur            w0, [x1, #0xf]
    // 0x7984a4: DecompressPointer r0
    //     0x7984a4: add             x0, x0, HEAP, lsl #32
    // 0x7984a8: SaveReg r0
    //     0x7984a8: str             x0, [SP, #-8]!
    // 0x7984ac: r0 = onChangeNotifier()
    //     0x7984ac: bl              #0x7984c8  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::onChangeNotifier
    // 0x7984b0: add             SP, SP, #8
    // 0x7984b4: LeaveFrame
    //     0x7984b4: mov             SP, fp
    //     0x7984b8: ldp             fp, lr, [SP], #0x10
    // 0x7984bc: ret
    //     0x7984bc: ret             
    // 0x7984c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7984c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7984c4: b               #0x7984a0
  }
  _ onChangeNotifier(/* No info */) {
    // ** addr: 0x7984c8, size: 0x1a0
    // 0x7984c8: EnterFrame
    //     0x7984c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7984cc: mov             fp, SP
    // 0x7984d0: AllocStack(0x10)
    //     0x7984d0: sub             SP, SP, #0x10
    // 0x7984d4: CheckStackOverflow
    //     0x7984d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7984d8: cmp             SP, x16
    //     0x7984dc: b.ls            #0x79864c
    // 0x7984e0: ldr             x2, [fp, #0x10]
    // 0x7984e4: LoadField: r0 = r2->field_b
    //     0x7984e4: ldur            w0, [x2, #0xb]
    // 0x7984e8: DecompressPointer r0
    //     0x7984e8: add             x0, x0, HEAP, lsl #32
    // 0x7984ec: cmp             w0, NULL
    // 0x7984f0: b.eq            #0x798654
    // 0x7984f4: LoadField: r1 = r0->field_23
    //     0x7984f4: ldur            w1, [x0, #0x23]
    // 0x7984f8: DecompressPointer r1
    //     0x7984f8: add             x1, x1, HEAP, lsl #32
    // 0x7984fc: LoadField: r3 = r1->field_23
    //     0x7984fc: ldur            w3, [x1, #0x23]
    // 0x798500: DecompressPointer r3
    //     0x798500: add             x3, x3, HEAP, lsl #32
    // 0x798504: stur            x3, [fp, #-8]
    // 0x798508: cmp             w3, NULL
    // 0x79850c: b.ne            #0x798520
    // 0x798510: r0 = Null
    //     0x798510: mov             x0, NULL
    // 0x798514: LeaveFrame
    //     0x798514: mov             SP, fp
    //     0x798518: ldp             fp, lr, [SP], #0x10
    // 0x79851c: ret
    //     0x79851c: ret             
    // 0x798520: r0 = LoadClassIdInstr(r3)
    //     0x798520: ldur            x0, [x3, #-1]
    //     0x798524: ubfx            x0, x0, #0xc, #0x14
    // 0x798528: lsl             x0, x0, #1
    // 0x79852c: r17 = 9766
    //     0x79852c: mov             x17, #0x2626
    // 0x798530: cmp             w0, w17
    // 0x798534: b.ne            #0x79863c
    // 0x798538: LoadField: r4 = r2->field_17
    //     0x798538: ldur            x4, [x2, #0x17]
    // 0x79853c: LoadField: r0 = r2->field_2f
    //     0x79853c: ldur            w0, [x2, #0x2f]
    // 0x798540: DecompressPointer r0
    //     0x798540: add             x0, x0, HEAP, lsl #32
    // 0x798544: r16 = Sentinel
    //     0x798544: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x798548: cmp             w0, w16
    // 0x79854c: b.eq            #0x798658
    // 0x798550: LoadField: r5 = r0->field_4f
    //     0x798550: ldur            x5, [x0, #0x4f]
    // 0x798554: LoadField: r6 = r0->field_4b
    //     0x798554: ldur            w6, [x0, #0x4b]
    // 0x798558: DecompressPointer r6
    //     0x798558: add             x6, x6, HEAP, lsl #32
    // 0x79855c: r0 = BoxInt64Instr(r4)
    //     0x79855c: sbfiz           x0, x4, #1, #0x1f
    //     0x798560: cmp             x4, x0, asr #1
    //     0x798564: b.eq            #0x798570
    //     0x798568: bl              #0xd69bb8
    //     0x79856c: stur            x4, [x0, #7]
    // 0x798570: stp             x0, x3, [SP, #-0x10]!
    // 0x798574: stp             x6, x5, [SP, #-0x10]!
    // 0x798578: r16 = false
    //     0x798578: add             x16, NULL, #0x30  ; false
    // 0x79857c: SaveReg r16
    //     0x79857c: str             x16, [SP, #-8]!
    // 0x798580: r0 = calcNextIndex()
    //     0x798580: bl              #0x7986d0  ; [package:card_swiper/src/transformer_page_view/index_controller.dart] _NextIndexControllerEvent&IndexControllerEventBase&TargetedPositionControllerEvent&StepBasedIndexControllerEvent::calcNextIndex
    // 0x798584: add             SP, SP, #0x28
    // 0x798588: mov             x1, x0
    // 0x79858c: ldr             x0, [fp, #0x10]
    // 0x798590: LoadField: r2 = r0->field_2f
    //     0x798590: ldur            w2, [x0, #0x2f]
    // 0x798594: DecompressPointer r2
    //     0x798594: add             x2, x2, HEAP, lsl #32
    // 0x798598: LoadField: r3 = r2->field_33
    //     0x798598: ldur            w3, [x2, #0x33]
    // 0x79859c: DecompressPointer r3
    //     0x79859c: add             x3, x3, HEAP, lsl #32
    // 0x7985a0: LoadField: r4 = r3->field_b
    //     0x7985a0: ldur            w4, [x3, #0xb]
    // 0x7985a4: DecompressPointer r4
    //     0x7985a4: add             x4, x4, HEAP, lsl #32
    // 0x7985a8: cbz             w4, #0x79861c
    // 0x7985ac: ldur            x3, [fp, #-8]
    // 0x7985b0: LoadField: r4 = r0->field_b
    //     0x7985b0: ldur            w4, [x0, #0xb]
    // 0x7985b4: DecompressPointer r4
    //     0x7985b4: add             x4, x4, HEAP, lsl #32
    // 0x7985b8: cmp             w4, NULL
    // 0x7985bc: b.eq            #0x798664
    // 0x7985c0: LoadField: r0 = r4->field_27
    //     0x7985c0: ldur            w0, [x4, #0x27]
    // 0x7985c4: DecompressPointer r0
    //     0x7985c4: add             x0, x0, HEAP, lsl #32
    // 0x7985c8: stp             x1, x2, [SP, #-0x10]!
    // 0x7985cc: r16 = Instance_Cubic
    //     0x7985cc: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x7985d0: ldr             x16, [x16, #0xfc8]
    // 0x7985d4: stp             x0, x16, [SP, #-0x10]!
    // 0x7985d8: r0 = animateToPage()
    //     0x7985d8: bl              #0x798030  ; [package:flutter/src/widgets/page_view.dart] PageController::animateToPage
    // 0x7985dc: add             SP, SP, #0x20
    // 0x7985e0: stur            x0, [fp, #-0x10]
    // 0x7985e4: r1 = 1
    //     0x7985e4: mov             x1, #1
    // 0x7985e8: r0 = AllocateContext()
    //     0x7985e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7985ec: mov             x1, x0
    // 0x7985f0: ldur            x0, [fp, #-8]
    // 0x7985f4: StoreField: r1->field_f = r0
    //     0x7985f4: stur            w0, [x1, #0xf]
    // 0x7985f8: mov             x2, x1
    // 0x7985fc: r1 = Function 'complete':.
    //     0x7985fc: add             x1, PP, #0x38, lsl #12  ; [pp+0x386a8] AnonymousClosure: (0x798724), in [package:card_swiper/src/transformer_page_view/index_controller.dart] IndexControllerEventBase::complete (0x798668)
    //     0x798600: ldr             x1, [x1, #0x6a8]
    // 0x798604: r0 = AllocateClosure()
    //     0x798604: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x798608: ldur            x16, [fp, #-0x10]
    // 0x79860c: stp             x0, x16, [SP, #-0x10]!
    // 0x798610: r0 = whenComplete()
    //     0x798610: bl              #0xca6034  ; [dart:async] _Future::whenComplete
    // 0x798614: add             SP, SP, #0x10
    // 0x798618: b               #0x79862c
    // 0x79861c: ldur            x0, [fp, #-8]
    // 0x798620: SaveReg r0
    //     0x798620: str             x0, [SP, #-8]!
    // 0x798624: r0 = complete()
    //     0x798624: bl              #0x798668  ; [package:card_swiper/src/transformer_page_view/index_controller.dart] IndexControllerEventBase::complete
    // 0x798628: add             SP, SP, #8
    // 0x79862c: r0 = Null
    //     0x79862c: mov             x0, NULL
    // 0x798630: LeaveFrame
    //     0x798630: mov             SP, fp
    //     0x798634: ldp             fp, lr, [SP], #0x10
    // 0x798638: ret
    //     0x798638: ret             
    // 0x79863c: r0 = Null
    //     0x79863c: mov             x0, NULL
    // 0x798640: LeaveFrame
    //     0x798640: mov             SP, fp
    //     0x798644: ldp             fp, lr, [SP], #0x10
    // 0x798648: ret
    //     0x798648: ret             
    // 0x79864c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79864c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x798650: b               #0x7984e0
    // 0x798654: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x798654: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x798658: r9 = _pageController
    //     0x798658: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x79865c: ldr             x9, [x9, #0x6b0]
    // 0x798660: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x798660: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x798664: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x798664: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onGetSize(dynamic, Duration) {
    // ** addr: 0x79876c, size: 0x4c
    // 0x79876c: EnterFrame
    //     0x79876c: stp             fp, lr, [SP, #-0x10]!
    //     0x798770: mov             fp, SP
    // 0x798774: ldr             x0, [fp, #0x18]
    // 0x798778: LoadField: r1 = r0->field_17
    //     0x798778: ldur            w1, [x0, #0x17]
    // 0x79877c: DecompressPointer r1
    //     0x79877c: add             x1, x1, HEAP, lsl #32
    // 0x798780: CheckStackOverflow
    //     0x798780: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x798784: cmp             SP, x16
    //     0x798788: b.ls            #0x7987b0
    // 0x79878c: LoadField: r0 = r1->field_f
    //     0x79878c: ldur            w0, [x1, #0xf]
    // 0x798790: DecompressPointer r0
    //     0x798790: add             x0, x0, HEAP, lsl #32
    // 0x798794: ldr             x16, [fp, #0x10]
    // 0x798798: stp             x16, x0, [SP, #-0x10]!
    // 0x79879c: r0 = _onGetSize()
    //     0x79879c: bl              #0x7987b8  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_onGetSize
    // 0x7987a0: add             SP, SP, #0x10
    // 0x7987a4: LeaveFrame
    //     0x7987a4: mov             SP, fp
    //     0x7987a8: ldp             fp, lr, [SP], #0x10
    // 0x7987ac: ret
    //     0x7987ac: ret             
    // 0x7987b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7987b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7987b4: b               #0x79878c
  }
  _ _onGetSize(/* No info */) {
    // ** addr: 0x7987b8, size: 0xc8
    // 0x7987b8: EnterFrame
    //     0x7987b8: stp             fp, lr, [SP, #-0x10]!
    //     0x7987bc: mov             fp, SP
    // 0x7987c0: AllocStack(0x8)
    //     0x7987c0: sub             SP, SP, #8
    // 0x7987c4: CheckStackOverflow
    //     0x7987c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7987c8: cmp             SP, x16
    //     0x7987cc: b.ls            #0x798878
    // 0x7987d0: ldr             x0, [fp, #0x18]
    // 0x7987d4: LoadField: r1 = r0->field_f
    //     0x7987d4: ldur            w1, [x0, #0xf]
    // 0x7987d8: DecompressPointer r1
    //     0x7987d8: add             x1, x1, HEAP, lsl #32
    // 0x7987dc: cmp             w1, NULL
    // 0x7987e0: b.ne            #0x7987f4
    // 0x7987e4: r0 = Null
    //     0x7987e4: mov             x0, NULL
    // 0x7987e8: LeaveFrame
    //     0x7987e8: mov             SP, fp
    //     0x7987ec: ldp             fp, lr, [SP], #0x10
    // 0x7987f0: ret
    //     0x7987f0: ret             
    // 0x7987f4: SaveReg r1
    //     0x7987f4: str             x1, [SP, #-8]!
    // 0x7987f8: r0 = findRenderObject()
    //     0x7987f8: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x7987fc: add             SP, SP, #8
    // 0x798800: cmp             w0, NULL
    // 0x798804: b.eq            #0x79883c
    // 0x798808: r1 = LoadClassIdInstr(r0)
    //     0x798808: ldur            x1, [x0, #-1]
    //     0x79880c: ubfx            x1, x1, #0xc, #0x14
    // 0x798810: SaveReg r0
    //     0x798810: str             x0, [SP, #-8]!
    // 0x798814: mov             x0, x1
    // 0x798818: r0 = GDT[cid_x0 + 0xd215]()
    //     0x798818: mov             x17, #0xd215
    //     0x79881c: add             lr, x0, x17
    //     0x798820: ldr             lr, [x21, lr, lsl #3]
    //     0x798824: blr             lr
    // 0x798828: add             SP, SP, #8
    // 0x79882c: SaveReg r0
    //     0x79882c: str             x0, [SP, #-8]!
    // 0x798830: r0 = size()
    //     0x798830: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0x798834: add             SP, SP, #8
    // 0x798838: b               #0x798840
    // 0x79883c: r0 = Null
    //     0x79883c: mov             x0, NULL
    // 0x798840: stur            x0, [fp, #-8]
    // 0x798844: ldr             x16, [fp, #0x18]
    // 0x798848: SaveReg r16
    //     0x798848: str             x16, [SP, #-8]!
    // 0x79884c: r0 = _calcCurrentPixels()
    //     0x79884c: bl              #0x798940  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_calcCurrentPixels
    // 0x798850: add             SP, SP, #8
    // 0x798854: ldr             x16, [fp, #0x18]
    // 0x798858: ldur            lr, [fp, #-8]
    // 0x79885c: stp             lr, x16, [SP, #-0x10]!
    // 0x798860: r0 = onGetSize()
    //     0x798860: bl              #0x798880  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::onGetSize
    // 0x798864: add             SP, SP, #0x10
    // 0x798868: r0 = Null
    //     0x798868: mov             x0, NULL
    // 0x79886c: LeaveFrame
    //     0x79886c: mov             SP, fp
    //     0x798870: ldp             fp, lr, [SP], #0x10
    // 0x798874: ret
    //     0x798874: ret             
    // 0x798878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x798878: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79887c: b               #0x7987d0
  }
  _ onGetSize(/* No info */) {
    // ** addr: 0x798880, size: 0x78
    // 0x798880: EnterFrame
    //     0x798880: stp             fp, lr, [SP, #-0x10]!
    //     0x798884: mov             fp, SP
    // 0x798888: CheckStackOverflow
    //     0x798888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79888c: cmp             SP, x16
    //     0x798890: b.ls            #0x7988f0
    // 0x798894: r1 = 2
    //     0x798894: mov             x1, #2
    // 0x798898: r0 = AllocateContext()
    //     0x798898: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79889c: mov             x1, x0
    // 0x7988a0: ldr             x0, [fp, #0x18]
    // 0x7988a4: StoreField: r1->field_f = r0
    //     0x7988a4: stur            w0, [x1, #0xf]
    // 0x7988a8: ldr             x2, [fp, #0x10]
    // 0x7988ac: StoreField: r1->field_13 = r2
    //     0x7988ac: stur            w2, [x1, #0x13]
    // 0x7988b0: LoadField: r2 = r0->field_f
    //     0x7988b0: ldur            w2, [x0, #0xf]
    // 0x7988b4: DecompressPointer r2
    //     0x7988b4: add             x2, x2, HEAP, lsl #32
    // 0x7988b8: cmp             w2, NULL
    // 0x7988bc: b.eq            #0x7988e0
    // 0x7988c0: mov             x2, x1
    // 0x7988c4: r1 = Function '<anonymous closure>':.
    //     0x7988c4: add             x1, PP, #0x38, lsl #12  ; [pp+0x386d0] AnonymousClosure: (0x7988f8), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::onGetSize (0x798880)
    //     0x7988c8: ldr             x1, [x1, #0x6d0]
    // 0x7988cc: r0 = AllocateClosure()
    //     0x7988cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7988d0: ldr             x16, [fp, #0x18]
    // 0x7988d4: stp             x0, x16, [SP, #-0x10]!
    // 0x7988d8: r0 = setState()
    //     0x7988d8: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7988dc: add             SP, SP, #0x10
    // 0x7988e0: r0 = Null
    //     0x7988e0: mov             x0, NULL
    // 0x7988e4: LeaveFrame
    //     0x7988e4: mov             SP, fp
    //     0x7988e8: ldp             fp, lr, [SP], #0x10
    // 0x7988ec: ret
    //     0x7988ec: ret             
    // 0x7988f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7988f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7988f4: b               #0x798894
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7988f8, size: 0x48
    // 0x7988f8: ldr             x1, [SP]
    // 0x7988fc: LoadField: r2 = r1->field_17
    //     0x7988fc: ldur            w2, [x1, #0x17]
    // 0x798900: DecompressPointer r2
    //     0x798900: add             x2, x2, HEAP, lsl #32
    // 0x798904: LoadField: r1 = r2->field_f
    //     0x798904: ldur            w1, [x2, #0xf]
    // 0x798908: DecompressPointer r1
    //     0x798908: add             x1, x1, HEAP, lsl #32
    // 0x79890c: LoadField: r0 = r2->field_13
    //     0x79890c: ldur            w0, [x2, #0x13]
    // 0x798910: DecompressPointer r0
    //     0x798910: add             x0, x0, HEAP, lsl #32
    // 0x798914: StoreField: r1->field_13 = r0
    //     0x798914: stur            w0, [x1, #0x13]
    //     0x798918: ldurb           w16, [x1, #-1]
    //     0x79891c: ldurb           w17, [x0, #-1]
    //     0x798920: and             x16, x17, x16, lsr #2
    //     0x798924: tst             x16, HEAP, lsr #32
    //     0x798928: b.eq            #0x798938
    //     0x79892c: str             lr, [SP, #-8]!
    //     0x798930: bl              #0xd6826c
    //     0x798934: ldr             lr, [SP], #8
    // 0x798938: r0 = Null
    //     0x798938: mov             x0, NULL
    // 0x79893c: ret
    //     0x79893c: ret             
  }
  _ _calcCurrentPixels(/* No info */) {
    // ** addr: 0x798940, size: 0x12c
    // 0x798940: EnterFrame
    //     0x798940: stp             fp, lr, [SP, #-0x10]!
    //     0x798944: mov             fp, SP
    // 0x798948: AllocStack(0x8)
    //     0x798948: sub             SP, SP, #8
    // 0x79894c: CheckStackOverflow
    //     0x79894c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x798950: cmp             SP, x16
    //     0x798954: b.ls            #0x798a3c
    // 0x798958: ldr             x0, [fp, #0x10]
    // 0x79895c: LoadField: r1 = r0->field_2f
    //     0x79895c: ldur            w1, [x0, #0x2f]
    // 0x798960: DecompressPointer r1
    //     0x798960: add             x1, x1, HEAP, lsl #32
    // 0x798964: r16 = Sentinel
    //     0x798964: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x798968: cmp             w1, w16
    // 0x79896c: b.eq            #0x798a44
    // 0x798970: LoadField: r2 = r0->field_17
    //     0x798970: ldur            x2, [x0, #0x17]
    // 0x798974: stp             x2, x1, [SP, #-0x10]!
    // 0x798978: r0 = getRenderIndexFromRealIndex()
    //     0x798978: bl              #0x798338  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::getRenderIndexFromRealIndex
    // 0x79897c: add             SP, SP, #0x10
    // 0x798980: mov             x1, x0
    // 0x798984: ldr             x0, [fp, #0x10]
    // 0x798988: stur            x1, [fp, #-8]
    // 0x79898c: LoadField: r2 = r0->field_2f
    //     0x79898c: ldur            w2, [x0, #0x2f]
    // 0x798990: DecompressPointer r2
    //     0x798990: add             x2, x2, HEAP, lsl #32
    // 0x798994: LoadField: r3 = r2->field_33
    //     0x798994: ldur            w3, [x2, #0x33]
    // 0x798998: DecompressPointer r3
    //     0x798998: add             x3, x3, HEAP, lsl #32
    // 0x79899c: SaveReg r3
    //     0x79899c: str             x3, [SP, #-8]!
    // 0x7989a0: r0 = single()
    //     0x7989a0: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x7989a4: add             SP, SP, #8
    // 0x7989a8: r1 = LoadClassIdInstr(r0)
    //     0x7989a8: ldur            x1, [x0, #-1]
    //     0x7989ac: ubfx            x1, x1, #0xc, #0x14
    // 0x7989b0: SaveReg r0
    //     0x7989b0: str             x0, [SP, #-8]!
    // 0x7989b4: mov             x0, x1
    // 0x7989b8: r0 = GDT[cid_x0 + -0xfa2]()
    //     0x7989b8: sub             lr, x0, #0xfa2
    //     0x7989bc: ldr             lr, [x21, lr, lsl #3]
    //     0x7989c0: blr             lr
    // 0x7989c4: add             SP, SP, #8
    // 0x7989c8: ldur            x1, [fp, #-8]
    // 0x7989cc: scvtf           d1, x1
    // 0x7989d0: fmul            d2, d1, d0
    // 0x7989d4: ldr             x1, [fp, #0x10]
    // 0x7989d8: LoadField: r2 = r1->field_b
    //     0x7989d8: ldur            w2, [x1, #0xb]
    // 0x7989dc: DecompressPointer r2
    //     0x7989dc: add             x2, x2, HEAP, lsl #32
    // 0x7989e0: cmp             w2, NULL
    // 0x7989e4: b.eq            #0x798a50
    // 0x7989e8: r0 = inline_Allocate_Double()
    //     0x7989e8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x7989ec: add             x0, x0, #0x10
    //     0x7989f0: cmp             x2, x0
    //     0x7989f4: b.ls            #0x798a54
    //     0x7989f8: str             x0, [THR, #0x60]  ; THR::top
    //     0x7989fc: sub             x0, x0, #0xf
    //     0x798a00: mov             x2, #0xd108
    //     0x798a04: movk            x2, #3, lsl #16
    //     0x798a08: stur            x2, [x0, #-1]
    // 0x798a0c: StoreField: r0->field_7 = d2
    //     0x798a0c: stur            d2, [x0, #7]
    // 0x798a10: StoreField: r1->field_1f = r0
    //     0x798a10: stur            w0, [x1, #0x1f]
    //     0x798a14: ldurb           w16, [x1, #-1]
    //     0x798a18: ldurb           w17, [x0, #-1]
    //     0x798a1c: and             x16, x17, x16, lsr #2
    //     0x798a20: tst             x16, HEAP, lsr #32
    //     0x798a24: b.eq            #0x798a2c
    //     0x798a28: bl              #0xd6826c
    // 0x798a2c: mov             v0.16b, v2.16b
    // 0x798a30: LeaveFrame
    //     0x798a30: mov             SP, fp
    //     0x798a34: ldp             fp, lr, [SP], #0x10
    // 0x798a38: ret
    //     0x798a38: ret             
    // 0x798a3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x798a3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x798a40: b               #0x798958
    // 0x798a44: r9 = _pageController
    //     0x798a44: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x798a48: ldr             x9, [x9, #0x6b0]
    // 0x798a4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x798a4c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x798a50: r0 = NullCastErrorSharedWithFPURegs()
    //     0x798a50: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x798a54: SaveReg d2
    //     0x798a54: str             q2, [SP, #-0x10]!
    // 0x798a58: SaveReg r1
    //     0x798a58: str             x1, [SP, #-8]!
    // 0x798a5c: r0 = AllocateDouble()
    //     0x798a5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x798a60: RestoreReg r1
    //     0x798a60: ldr             x1, [SP], #8
    // 0x798a64: RestoreReg d2
    //     0x798a64: ldr             q2, [SP], #0x10
    // 0x798a68: b               #0x798a0c
  }
  _ build(/* No info */) {
    // ** addr: 0x823ee4, size: 0x1f4
    // 0x823ee4: EnterFrame
    //     0x823ee4: stp             fp, lr, [SP, #-0x10]!
    //     0x823ee8: mov             fp, SP
    // 0x823eec: AllocStack(0x38)
    //     0x823eec: sub             SP, SP, #0x38
    // 0x823ef0: CheckStackOverflow
    //     0x823ef0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823ef4: cmp             SP, x16
    //     0x823ef8: b.ls            #0x8240c0
    // 0x823efc: r1 = 1
    //     0x823efc: mov             x1, #1
    // 0x823f00: r0 = AllocateContext()
    //     0x823f00: bl              #0xd68aa4  ; AllocateContextStub
    // 0x823f04: mov             x1, x0
    // 0x823f08: ldr             x0, [fp, #0x18]
    // 0x823f0c: stur            x1, [fp, #-8]
    // 0x823f10: StoreField: r1->field_f = r0
    //     0x823f10: stur            w0, [x1, #0xf]
    // 0x823f14: LoadField: r2 = r0->field_2b
    //     0x823f14: ldur            w2, [x0, #0x2b]
    // 0x823f18: DecompressPointer r2
    //     0x823f18: add             x2, x2, HEAP, lsl #32
    // 0x823f1c: cmp             w2, NULL
    // 0x823f20: b.ne            #0x823f50
    // 0x823f24: r1 = 1
    //     0x823f24: mov             x1, #1
    // 0x823f28: r0 = AllocateContext()
    //     0x823f28: bl              #0xd68aa4  ; AllocateContextStub
    // 0x823f2c: mov             x1, x0
    // 0x823f30: ldr             x0, [fp, #0x18]
    // 0x823f34: StoreField: r1->field_f = r0
    //     0x823f34: stur            w0, [x1, #0xf]
    // 0x823f38: mov             x2, x1
    // 0x823f3c: r1 = Function '_buildItemNormal@205299810':.
    //     0x823f3c: add             x1, PP, #0x38, lsl #12  ; [pp+0x38710] AnonymousClosure: (0x824b1c), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_buildItemNormal (0x824b70)
    //     0x823f40: ldr             x1, [x1, #0x710]
    // 0x823f44: r0 = AllocateClosure()
    //     0x823f44: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x823f48: mov             x1, x0
    // 0x823f4c: b               #0x823f78
    // 0x823f50: r1 = 1
    //     0x823f50: mov             x1, #1
    // 0x823f54: r0 = AllocateContext()
    //     0x823f54: bl              #0xd68aa4  ; AllocateContextStub
    // 0x823f58: mov             x1, x0
    // 0x823f5c: ldr             x0, [fp, #0x18]
    // 0x823f60: StoreField: r1->field_f = r0
    //     0x823f60: stur            w0, [x1, #0xf]
    // 0x823f64: mov             x2, x1
    // 0x823f68: r1 = Function '_buildItem@205299810':.
    //     0x823f68: add             x1, PP, #0x38, lsl #12  ; [pp+0x38718] AnonymousClosure: (0x824614), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_buildItem (0x824668)
    //     0x823f6c: ldr             x1, [x1, #0x718]
    // 0x823f70: r0 = AllocateClosure()
    //     0x823f70: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x823f74: mov             x1, x0
    // 0x823f78: ldr             x0, [fp, #0x18]
    // 0x823f7c: stur            x1, [fp, #-0x20]
    // 0x823f80: LoadField: r2 = r0->field_b
    //     0x823f80: ldur            w2, [x0, #0xb]
    // 0x823f84: DecompressPointer r2
    //     0x823f84: add             x2, x2, HEAP, lsl #32
    // 0x823f88: cmp             w2, NULL
    // 0x823f8c: b.eq            #0x8240c8
    // 0x823f90: LoadField: r2 = r0->field_2f
    //     0x823f90: ldur            w2, [x0, #0x2f]
    // 0x823f94: DecompressPointer r2
    //     0x823f94: add             x2, x2, HEAP, lsl #32
    // 0x823f98: r16 = Sentinel
    //     0x823f98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x823f9c: cmp             w2, w16
    // 0x823fa0: b.eq            #0x8240cc
    // 0x823fa4: stur            x2, [fp, #-0x18]
    // 0x823fa8: LoadField: r3 = r2->field_4f
    //     0x823fa8: ldur            x3, [x2, #0x4f]
    // 0x823fac: lsl             x4, x3, #1
    // 0x823fb0: cbnz            w4, #0x823fbc
    // 0x823fb4: r3 = 0
    //     0x823fb4: mov             x3, #0
    // 0x823fb8: b               #0x823fd8
    // 0x823fbc: LoadField: r4 = r2->field_4b
    //     0x823fbc: ldur            w4, [x2, #0x4b]
    // 0x823fc0: DecompressPointer r4
    //     0x823fc0: add             x4, x4, HEAP, lsl #32
    // 0x823fc4: tbnz            w4, #4, #0x823fd8
    // 0x823fc8: r17 = 2000000000
    //     0x823fc8: mov             x17, #0x9400
    //     0x823fcc: movk            x17, #0x7735, lsl #16
    // 0x823fd0: add             x4, x3, x17
    // 0x823fd4: mov             x3, x4
    // 0x823fd8: stur            x3, [fp, #-0x10]
    // 0x823fdc: r1 = 1
    //     0x823fdc: mov             x1, #1
    // 0x823fe0: r0 = AllocateContext()
    //     0x823fe0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x823fe4: mov             x2, x0
    // 0x823fe8: ldr             x3, [fp, #0x18]
    // 0x823fec: StoreField: r2->field_f = r3
    //     0x823fec: stur            w3, [x2, #0xf]
    // 0x823ff0: ldur            x4, [fp, #-0x10]
    // 0x823ff4: r0 = BoxInt64Instr(r4)
    //     0x823ff4: sbfiz           x0, x4, #1, #0x1f
    //     0x823ff8: cmp             x4, x0, asr #1
    //     0x823ffc: b.eq            #0x824008
    //     0x824000: bl              #0xd69bb8
    //     0x824004: stur            x4, [x0, #7]
    // 0x824008: r1 = Function '_onIndexChanged@205299810':.
    //     0x824008: add             x1, PP, #0x38, lsl #12  ; [pp+0x38720] AnonymousClosure: (0x8244f8), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_onIndexChanged (0x824544)
    //     0x82400c: ldr             x1, [x1, #0x720]
    // 0x824010: stur            x0, [fp, #-0x28]
    // 0x824014: r0 = AllocateClosure()
    //     0x824014: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x824018: stur            x0, [fp, #-0x30]
    // 0x82401c: r0 = PageView()
    //     0x82401c: bl              #0x8243b8  ; AllocatePageViewStub -> PageView (size=0x40)
    // 0x824020: stur            x0, [fp, #-0x38]
    // 0x824024: ldur            x16, [fp, #-0x18]
    // 0x824028: stp             x16, x0, [SP, #-0x10]!
    // 0x82402c: ldur            x16, [fp, #-0x20]
    // 0x824030: ldur            lr, [fp, #-0x28]
    // 0x824034: stp             lr, x16, [SP, #-0x10]!
    // 0x824038: ldur            x16, [fp, #-0x30]
    // 0x82403c: r30 = Instance_Axis
    //     0x82403c: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x824040: ldr             lr, [lr, #0x440]
    // 0x824044: stp             lr, x16, [SP, #-0x10]!
    // 0x824048: SaveReg rNULL
    //     0x824048: str             NULL, [SP, #-8]!
    // 0x82404c: r4 = const [0, 0x7, 0x7, 0x5, physics, 0x6, scrollDirection, 0x5, null]
    //     0x82404c: add             x4, PP, #0x38, lsl #12  ; [pp+0x38728] List(9) [0, 0x7, 0x7, 0x5, "physics", 0x6, "scrollDirection", 0x5, Null]
    //     0x824050: ldr             x4, [x4, #0x728]
    // 0x824054: r0 = PageView.builder()
    //     0x824054: bl              #0x8240d8  ; [package:flutter/src/widgets/page_view.dart] PageView::PageView.builder
    // 0x824058: add             SP, SP, #0x38
    // 0x82405c: ldr             x0, [fp, #0x18]
    // 0x824060: LoadField: r1 = r0->field_2b
    //     0x824060: ldur            w1, [x0, #0x2b]
    // 0x824064: DecompressPointer r1
    //     0x824064: add             x1, x1, HEAP, lsl #32
    // 0x824068: cmp             w1, NULL
    // 0x82406c: b.ne            #0x824080
    // 0x824070: ldur            x0, [fp, #-0x38]
    // 0x824074: LeaveFrame
    //     0x824074: mov             SP, fp
    //     0x824078: ldp             fp, lr, [SP], #0x10
    // 0x82407c: ret
    //     0x82407c: ret             
    // 0x824080: ldur            x0, [fp, #-0x38]
    // 0x824084: ldur            x2, [fp, #-8]
    // 0x824088: r1 = Function '<anonymous closure>':.
    //     0x824088: add             x1, PP, #0x38, lsl #12  ; [pp+0x38730] AnonymousClosure: (0x8243c4), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::build (0x823ee4)
    //     0x82408c: ldr             x1, [x1, #0x730]
    // 0x824090: r0 = AllocateClosure()
    //     0x824090: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x824094: r1 = <Notification>
    //     0x824094: add             x1, PP, #0x29, lsl #12  ; [pp+0x293c0] TypeArguments: <Notification>
    //     0x824098: ldr             x1, [x1, #0x3c0]
    // 0x82409c: stur            x0, [fp, #-8]
    // 0x8240a0: r0 = NotificationListener()
    //     0x8240a0: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x8240a4: ldur            x1, [fp, #-8]
    // 0x8240a8: StoreField: r0->field_13 = r1
    //     0x8240a8: stur            w1, [x0, #0x13]
    // 0x8240ac: ldur            x1, [fp, #-0x38]
    // 0x8240b0: StoreField: r0->field_b = r1
    //     0x8240b0: stur            w1, [x0, #0xb]
    // 0x8240b4: LeaveFrame
    //     0x8240b4: mov             SP, fp
    //     0x8240b8: ldp             fp, lr, [SP], #0x10
    // 0x8240bc: ret
    //     0x8240bc: ret             
    // 0x8240c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8240c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8240c4: b               #0x823efc
    // 0x8240c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8240c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8240cc: r9 = _pageController
    //     0x8240cc: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x8240d0: ldr             x9, [x9, #0x6b0]
    // 0x8240d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8240d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, Object?) {
    // ** addr: 0x8243c4, size: 0x134
    // 0x8243c4: EnterFrame
    //     0x8243c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8243c8: mov             fp, SP
    // 0x8243cc: AllocStack(0x8)
    //     0x8243cc: sub             SP, SP, #8
    // 0x8243d0: SetupParameters()
    //     0x8243d0: ldr             x0, [fp, #0x18]
    //     0x8243d4: ldur            w1, [x0, #0x17]
    //     0x8243d8: add             x1, x1, HEAP, lsl #32
    //     0x8243dc: stur            x1, [fp, #-8]
    // 0x8243e0: CheckStackOverflow
    //     0x8243e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8243e4: cmp             SP, x16
    //     0x8243e8: b.ls            #0x8244f0
    // 0x8243ec: ldr             x0, [fp, #0x10]
    // 0x8243f0: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x8243f0: mov             x2, #0x76
    //     0x8243f4: tbz             w0, #0, #0x824404
    //     0x8243f8: ldur            x2, [x0, #-1]
    //     0x8243fc: ubfx            x2, x2, #0xc, #0x14
    //     0x824400: lsl             x2, x2, #1
    // 0x824404: cmp             w2, #0xe66
    // 0x824408: b.ne            #0x824470
    // 0x82440c: LoadField: r0 = r1->field_f
    //     0x82440c: ldur            w0, [x1, #0xf]
    // 0x824410: DecompressPointer r0
    //     0x824410: add             x0, x0, HEAP, lsl #32
    // 0x824414: SaveReg r0
    //     0x824414: str             x0, [SP, #-8]!
    // 0x824418: r0 = _calcCurrentPixels()
    //     0x824418: bl              #0x798940  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_calcCurrentPixels
    // 0x82441c: add             SP, SP, #8
    // 0x824420: ldur            x0, [fp, #-8]
    // 0x824424: LoadField: r2 = r0->field_f
    //     0x824424: ldur            w2, [x0, #0xf]
    // 0x824428: DecompressPointer r2
    //     0x824428: add             x2, x2, HEAP, lsl #32
    // 0x82442c: r3 = false
    //     0x82442c: add             x3, NULL, #0x30  ; false
    // 0x824430: StoreField: r2->field_23 = r3
    //     0x824430: stur            w3, [x2, #0x23]
    // 0x824434: LoadField: r4 = r2->field_17
    //     0x824434: ldur            x4, [x2, #0x17]
    // 0x824438: r0 = BoxInt64Instr(r4)
    //     0x824438: sbfiz           x0, x4, #1, #0x1f
    //     0x82443c: cmp             x4, x0, asr #1
    //     0x824440: b.eq            #0x82444c
    //     0x824444: bl              #0xd69bb8
    //     0x824448: stur            x4, [x0, #7]
    // 0x82444c: StoreField: r2->field_27 = r0
    //     0x82444c: stur            w0, [x2, #0x27]
    //     0x824450: tbz             w0, #0, #0x82446c
    //     0x824454: ldurb           w16, [x2, #-1]
    //     0x824458: ldurb           w17, [x0, #-1]
    //     0x82445c: and             x16, x17, x16, lsr #2
    //     0x824460: tst             x16, HEAP, lsr #32
    //     0x824464: b.eq            #0x82446c
    //     0x824468: bl              #0xd6828c
    // 0x82446c: b               #0x8244e0
    // 0x824470: mov             x0, x1
    // 0x824474: r3 = false
    //     0x824474: add             x3, NULL, #0x30  ; false
    // 0x824478: cmp             w2, #0xe5e
    // 0x82447c: b.ne            #0x8244e0
    // 0x824480: LoadField: r1 = r0->field_f
    //     0x824480: ldur            w1, [x0, #0xf]
    // 0x824484: DecompressPointer r1
    //     0x824484: add             x1, x1, HEAP, lsl #32
    // 0x824488: SaveReg r1
    //     0x824488: str             x1, [SP, #-8]!
    // 0x82448c: r0 = _calcCurrentPixels()
    //     0x82448c: bl              #0x798940  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_calcCurrentPixels
    // 0x824490: add             SP, SP, #8
    // 0x824494: ldur            x2, [fp, #-8]
    // 0x824498: LoadField: r3 = r2->field_f
    //     0x824498: ldur            w3, [x2, #0xf]
    // 0x82449c: DecompressPointer r3
    //     0x82449c: add             x3, x3, HEAP, lsl #32
    // 0x8244a0: LoadField: r2 = r3->field_17
    //     0x8244a0: ldur            x2, [x3, #0x17]
    // 0x8244a4: r0 = BoxInt64Instr(r2)
    //     0x8244a4: sbfiz           x0, x2, #1, #0x1f
    //     0x8244a8: cmp             x2, x0, asr #1
    //     0x8244ac: b.eq            #0x8244b8
    //     0x8244b0: bl              #0xd69bb8
    //     0x8244b4: stur            x2, [x0, #7]
    // 0x8244b8: StoreField: r3->field_27 = r0
    //     0x8244b8: stur            w0, [x3, #0x27]
    //     0x8244bc: tbz             w0, #0, #0x8244d8
    //     0x8244c0: ldurb           w16, [x3, #-1]
    //     0x8244c4: ldurb           w17, [x0, #-1]
    //     0x8244c8: and             x16, x17, x16, lsr #2
    //     0x8244cc: tst             x16, HEAP, lsr #32
    //     0x8244d0: b.eq            #0x8244d8
    //     0x8244d4: bl              #0xd682ac
    // 0x8244d8: r1 = true
    //     0x8244d8: add             x1, NULL, #0x20  ; true
    // 0x8244dc: StoreField: r3->field_23 = r1
    //     0x8244dc: stur            w1, [x3, #0x23]
    // 0x8244e0: r0 = false
    //     0x8244e0: add             x0, NULL, #0x30  ; false
    // 0x8244e4: LeaveFrame
    //     0x8244e4: mov             SP, fp
    //     0x8244e8: ldp             fp, lr, [SP], #0x10
    // 0x8244ec: ret
    //     0x8244ec: ret             
    // 0x8244f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8244f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8244f4: b               #0x8243ec
  }
  [closure] void _onIndexChanged(dynamic, int) {
    // ** addr: 0x8244f8, size: 0x4c
    // 0x8244f8: EnterFrame
    //     0x8244f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8244fc: mov             fp, SP
    // 0x824500: ldr             x0, [fp, #0x18]
    // 0x824504: LoadField: r1 = r0->field_17
    //     0x824504: ldur            w1, [x0, #0x17]
    // 0x824508: DecompressPointer r1
    //     0x824508: add             x1, x1, HEAP, lsl #32
    // 0x82450c: CheckStackOverflow
    //     0x82450c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x824510: cmp             SP, x16
    //     0x824514: b.ls            #0x82453c
    // 0x824518: LoadField: r0 = r1->field_f
    //     0x824518: ldur            w0, [x1, #0xf]
    // 0x82451c: DecompressPointer r0
    //     0x82451c: add             x0, x0, HEAP, lsl #32
    // 0x824520: ldr             x16, [fp, #0x10]
    // 0x824524: stp             x16, x0, [SP, #-0x10]!
    // 0x824528: r0 = _onIndexChanged()
    //     0x824528: bl              #0x824544  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_onIndexChanged
    // 0x82452c: add             SP, SP, #0x10
    // 0x824530: LeaveFrame
    //     0x824530: mov             SP, fp
    //     0x824534: ldp             fp, lr, [SP], #0x10
    // 0x824538: ret
    //     0x824538: ret             
    // 0x82453c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82453c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x824540: b               #0x824518
  }
  _ _onIndexChanged(/* No info */) {
    // ** addr: 0x824544, size: 0xd0
    // 0x824544: EnterFrame
    //     0x824544: stp             fp, lr, [SP, #-0x10]!
    //     0x824548: mov             fp, SP
    // 0x82454c: AllocStack(0x8)
    //     0x82454c: sub             SP, SP, #8
    // 0x824550: CheckStackOverflow
    //     0x824550: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x824554: cmp             SP, x16
    //     0x824558: b.ls            #0x8245fc
    // 0x82455c: ldr             x0, [fp, #0x10]
    // 0x824560: r1 = LoadInt32Instr(r0)
    //     0x824560: sbfx            x1, x0, #1, #0x1f
    //     0x824564: tbz             w0, #0, #0x82456c
    //     0x824568: ldur            x1, [x0, #7]
    // 0x82456c: ldr             x0, [fp, #0x18]
    // 0x824570: StoreField: r0->field_17 = r1
    //     0x824570: stur            x1, [x0, #0x17]
    // 0x824574: LoadField: r2 = r0->field_b
    //     0x824574: ldur            w2, [x0, #0xb]
    // 0x824578: DecompressPointer r2
    //     0x824578: add             x2, x2, HEAP, lsl #32
    // 0x82457c: cmp             w2, NULL
    // 0x824580: b.eq            #0x824604
    // 0x824584: LoadField: r3 = r2->field_1b
    //     0x824584: ldur            w3, [x2, #0x1b]
    // 0x824588: DecompressPointer r3
    //     0x824588: add             x3, x3, HEAP, lsl #32
    // 0x82458c: stur            x3, [fp, #-8]
    // 0x824590: cmp             w3, NULL
    // 0x824594: b.eq            #0x8245ec
    // 0x824598: LoadField: r2 = r0->field_2f
    //     0x824598: ldur            w2, [x0, #0x2f]
    // 0x82459c: DecompressPointer r2
    //     0x82459c: add             x2, x2, HEAP, lsl #32
    // 0x8245a0: r16 = Sentinel
    //     0x8245a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8245a4: cmp             w2, w16
    // 0x8245a8: b.eq            #0x824608
    // 0x8245ac: stp             x1, x2, [SP, #-0x10]!
    // 0x8245b0: r0 = getRenderIndexFromRealIndex()
    //     0x8245b0: bl              #0x798338  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::getRenderIndexFromRealIndex
    // 0x8245b4: add             SP, SP, #0x10
    // 0x8245b8: mov             x2, x0
    // 0x8245bc: r0 = BoxInt64Instr(r2)
    //     0x8245bc: sbfiz           x0, x2, #1, #0x1f
    //     0x8245c0: cmp             x2, x0, asr #1
    //     0x8245c4: b.eq            #0x8245d0
    //     0x8245c8: bl              #0xd69bb8
    //     0x8245cc: stur            x2, [x0, #7]
    // 0x8245d0: ldur            x16, [fp, #-8]
    // 0x8245d4: stp             x0, x16, [SP, #-0x10]!
    // 0x8245d8: ldur            x0, [fp, #-8]
    // 0x8245dc: ClosureCall
    //     0x8245dc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8245e0: ldur            x2, [x0, #0x1f]
    //     0x8245e4: blr             x2
    // 0x8245e8: add             SP, SP, #0x10
    // 0x8245ec: r0 = Null
    //     0x8245ec: mov             x0, NULL
    // 0x8245f0: LeaveFrame
    //     0x8245f0: mov             SP, fp
    //     0x8245f4: ldp             fp, lr, [SP], #0x10
    // 0x8245f8: ret
    //     0x8245f8: ret             
    // 0x8245fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8245fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x824600: b               #0x82455c
    // 0x824604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x824604: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x824608: r9 = _pageController
    //     0x824608: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x82460c: ldr             x9, [x9, #0x6b0]
    // 0x824610: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x824610: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _buildItem(dynamic, BuildContext, int) {
    // ** addr: 0x824614, size: 0x54
    // 0x824614: EnterFrame
    //     0x824614: stp             fp, lr, [SP, #-0x10]!
    //     0x824618: mov             fp, SP
    // 0x82461c: ldr             x0, [fp, #0x20]
    // 0x824620: LoadField: r1 = r0->field_17
    //     0x824620: ldur            w1, [x0, #0x17]
    // 0x824624: DecompressPointer r1
    //     0x824624: add             x1, x1, HEAP, lsl #32
    // 0x824628: CheckStackOverflow
    //     0x824628: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82462c: cmp             SP, x16
    //     0x824630: b.ls            #0x824660
    // 0x824634: LoadField: r0 = r1->field_f
    //     0x824634: ldur            w0, [x1, #0xf]
    // 0x824638: DecompressPointer r0
    //     0x824638: add             x0, x0, HEAP, lsl #32
    // 0x82463c: ldr             x16, [fp, #0x18]
    // 0x824640: stp             x16, x0, [SP, #-0x10]!
    // 0x824644: ldr             x16, [fp, #0x10]
    // 0x824648: SaveReg r16
    //     0x824648: str             x16, [SP, #-8]!
    // 0x82464c: r0 = _buildItem()
    //     0x82464c: bl              #0x824668  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_buildItem
    // 0x824650: add             SP, SP, #0x18
    // 0x824654: LeaveFrame
    //     0x824654: mov             SP, fp
    //     0x824658: ldp             fp, lr, [SP], #0x10
    // 0x82465c: ret
    //     0x82465c: ret             
    // 0x824660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x824660: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x824664: b               #0x824634
  }
  _ _buildItem(/* No info */) {
    // ** addr: 0x824668, size: 0x88
    // 0x824668: EnterFrame
    //     0x824668: stp             fp, lr, [SP, #-0x10]!
    //     0x82466c: mov             fp, SP
    // 0x824670: AllocStack(0x10)
    //     0x824670: sub             SP, SP, #0x10
    // 0x824674: r1 = 3
    //     0x824674: mov             x1, #3
    // 0x824678: r0 = AllocateContext()
    //     0x824678: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82467c: mov             x1, x0
    // 0x824680: ldr             x0, [fp, #0x20]
    // 0x824684: StoreField: r1->field_f = r0
    //     0x824684: stur            w0, [x1, #0xf]
    // 0x824688: ldr             x2, [fp, #0x18]
    // 0x82468c: StoreField: r1->field_13 = r2
    //     0x82468c: stur            w2, [x1, #0x13]
    // 0x824690: ldr             x2, [fp, #0x10]
    // 0x824694: StoreField: r1->field_17 = r2
    //     0x824694: stur            w2, [x1, #0x17]
    // 0x824698: LoadField: r3 = r0->field_2f
    //     0x824698: ldur            w3, [x0, #0x2f]
    // 0x82469c: DecompressPointer r3
    //     0x82469c: add             x3, x3, HEAP, lsl #32
    // 0x8246a0: r16 = Sentinel
    //     0x8246a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8246a4: cmp             w3, w16
    // 0x8246a8: b.eq            #0x8246e4
    // 0x8246ac: mov             x2, x1
    // 0x8246b0: stur            x3, [fp, #-8]
    // 0x8246b4: r1 = Function '<anonymous closure>':.
    //     0x8246b4: add             x1, PP, #0x38, lsl #12  ; [pp+0x38738] AnonymousClosure: (0x8246f0), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_buildItem (0x824668)
    //     0x8246b8: ldr             x1, [x1, #0x738]
    // 0x8246bc: r0 = AllocateClosure()
    //     0x8246bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8246c0: stur            x0, [fp, #-0x10]
    // 0x8246c4: r0 = AnimatedBuilder()
    //     0x8246c4: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x8246c8: ldur            x1, [fp, #-0x10]
    // 0x8246cc: StoreField: r0->field_f = r1
    //     0x8246cc: stur            w1, [x0, #0xf]
    // 0x8246d0: ldur            x1, [fp, #-8]
    // 0x8246d4: StoreField: r0->field_b = r1
    //     0x8246d4: stur            w1, [x0, #0xb]
    // 0x8246d8: LeaveFrame
    //     0x8246d8: mov             SP, fp
    //     0x8246dc: ldp             fp, lr, [SP], #0x10
    // 0x8246e0: ret
    //     0x8246e0: ret             
    // 0x8246e4: r9 = _pageController
    //     0x8246e4: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x8246e8: ldr             x9, [x9, #0x6b0]
    // 0x8246ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8246ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x8246f0, size: 0x388
    // 0x8246f0: EnterFrame
    //     0x8246f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8246f4: mov             fp, SP
    // 0x8246f8: AllocStack(0x10)
    //     0x8246f8: sub             SP, SP, #0x10
    // 0x8246fc: SetupParameters()
    //     0x8246fc: ldr             x0, [fp, #0x20]
    //     0x824700: ldur            w1, [x0, #0x17]
    //     0x824704: add             x1, x1, HEAP, lsl #32
    //     0x824708: stur            x1, [fp, #-8]
    // 0x82470c: CheckStackOverflow
    //     0x82470c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x824710: cmp             SP, x16
    //     0x824714: b.ls            #0x8249d0
    // 0x824718: LoadField: r0 = r1->field_f
    //     0x824718: ldur            w0, [x1, #0xf]
    // 0x82471c: DecompressPointer r0
    //     0x82471c: add             x0, x0, HEAP, lsl #32
    // 0x824720: LoadField: r2 = r0->field_2f
    //     0x824720: ldur            w2, [x0, #0x2f]
    // 0x824724: DecompressPointer r2
    //     0x824724: add             x2, x2, HEAP, lsl #32
    // 0x824728: r16 = Sentinel
    //     0x824728: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82472c: cmp             w2, w16
    // 0x824730: b.eq            #0x8249d8
    // 0x824734: LoadField: r0 = r1->field_17
    //     0x824734: ldur            w0, [x1, #0x17]
    // 0x824738: DecompressPointer r0
    //     0x824738: add             x0, x0, HEAP, lsl #32
    // 0x82473c: r3 = LoadInt32Instr(r0)
    //     0x82473c: sbfx            x3, x0, #1, #0x1f
    //     0x824740: tbz             w0, #0, #0x824748
    //     0x824744: ldur            x3, [x0, #7]
    // 0x824748: stp             x3, x2, [SP, #-0x10]!
    // 0x82474c: r0 = getRenderIndexFromRealIndex()
    //     0x82474c: bl              #0x798338  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::getRenderIndexFromRealIndex
    // 0x824750: add             SP, SP, #0x10
    // 0x824754: mov             x3, x0
    // 0x824758: ldur            x2, [fp, #-8]
    // 0x82475c: LoadField: r0 = r2->field_f
    //     0x82475c: ldur            w0, [x2, #0xf]
    // 0x824760: DecompressPointer r0
    //     0x824760: add             x0, x0, HEAP, lsl #32
    // 0x824764: LoadField: r1 = r0->field_b
    //     0x824764: ldur            w1, [x0, #0xb]
    // 0x824768: DecompressPointer r1
    //     0x824768: add             x1, x1, HEAP, lsl #32
    // 0x82476c: cmp             w1, NULL
    // 0x824770: b.eq            #0x8249e4
    // 0x824774: LoadField: r4 = r1->field_1f
    //     0x824774: ldur            w4, [x1, #0x1f]
    // 0x824778: DecompressPointer r4
    //     0x824778: add             x4, x4, HEAP, lsl #32
    // 0x82477c: cmp             w4, NULL
    // 0x824780: b.ne            #0x82478c
    // 0x824784: r0 = Null
    //     0x824784: mov             x0, NULL
    // 0x824788: b               #0x8247c4
    // 0x82478c: LoadField: r5 = r2->field_13
    //     0x82478c: ldur            w5, [x2, #0x13]
    // 0x824790: DecompressPointer r5
    //     0x824790: add             x5, x5, HEAP, lsl #32
    // 0x824794: r0 = BoxInt64Instr(r3)
    //     0x824794: sbfiz           x0, x3, #1, #0x1f
    //     0x824798: cmp             x3, x0, asr #1
    //     0x82479c: b.eq            #0x8247a8
    //     0x8247a0: bl              #0xd69bb8
    //     0x8247a4: stur            x3, [x0, #7]
    // 0x8247a8: stp             x5, x4, [SP, #-0x10]!
    // 0x8247ac: SaveReg r0
    //     0x8247ac: str             x0, [SP, #-8]!
    // 0x8247b0: mov             x0, x4
    // 0x8247b4: ClosureCall
    //     0x8247b4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x8247b8: ldur            x2, [x0, #0x1f]
    //     0x8247bc: blr             x2
    // 0x8247c0: add             SP, SP, #0x18
    // 0x8247c4: cmp             w0, NULL
    // 0x8247c8: b.ne            #0x8247d8
    // 0x8247cc: r1 = Instance_SizedBox
    //     0x8247cc: add             x1, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x8247d0: ldr             x1, [x1, #0x738]
    // 0x8247d4: b               #0x8247dc
    // 0x8247d8: mov             x1, x0
    // 0x8247dc: ldur            x0, [fp, #-8]
    // 0x8247e0: stur            x1, [fp, #-0x10]
    // 0x8247e4: LoadField: r2 = r0->field_f
    //     0x8247e4: ldur            w2, [x0, #0xf]
    // 0x8247e8: DecompressPointer r2
    //     0x8247e8: add             x2, x2, HEAP, lsl #32
    // 0x8247ec: LoadField: r3 = r2->field_13
    //     0x8247ec: ldur            w3, [x2, #0x13]
    // 0x8247f0: DecompressPointer r3
    //     0x8247f0: add             x3, x3, HEAP, lsl #32
    // 0x8247f4: cmp             w3, NULL
    // 0x8247f8: b.ne            #0x82480c
    // 0x8247fc: mov             x0, x1
    // 0x824800: LeaveFrame
    //     0x824800: mov             SP, fp
    //     0x824804: ldp             fp, lr, [SP], #0x10
    // 0x824808: ret
    //     0x824808: ret             
    // 0x82480c: LoadField: r3 = r2->field_2f
    //     0x82480c: ldur            w3, [x2, #0x2f]
    // 0x824810: DecompressPointer r3
    //     0x824810: add             x3, x3, HEAP, lsl #32
    // 0x824814: r16 = Sentinel
    //     0x824814: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x824818: cmp             w3, w16
    // 0x82481c: b.eq            #0x8249e8
    // 0x824820: SaveReg r3
    //     0x824820: str             x3, [SP, #-8]!
    // 0x824824: r0 = realPage()
    //     0x824824: bl              #0x824a78  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::realPage
    // 0x824828: add             SP, SP, #8
    // 0x82482c: ldur            x0, [fp, #-8]
    // 0x824830: LoadField: r1 = r0->field_f
    //     0x824830: ldur            w1, [x0, #0xf]
    // 0x824834: DecompressPointer r1
    //     0x824834: add             x1, x1, HEAP, lsl #32
    // 0x824838: LoadField: r2 = r1->field_2b
    //     0x824838: ldur            w2, [x1, #0x2b]
    // 0x82483c: DecompressPointer r2
    //     0x82483c: add             x2, x2, HEAP, lsl #32
    // 0x824840: cmp             w2, NULL
    // 0x824844: b.eq            #0x8249f4
    // 0x824848: LoadField: r2 = r0->field_17
    //     0x824848: ldur            w2, [x0, #0x17]
    // 0x82484c: DecompressPointer r2
    //     0x82484c: add             x2, x2, HEAP, lsl #32
    // 0x824850: cmp             w2, NULL
    // 0x824854: b.eq            #0x8249f8
    // 0x824858: r3 = LoadInt32Instr(r2)
    //     0x824858: sbfx            x3, x2, #1, #0x1f
    //     0x82485c: tbz             w2, #0, #0x824864
    //     0x824860: ldur            x3, [x2, #7]
    // 0x824864: scvtf           d1, x3
    // 0x824868: fsub            d2, d1, d0
    // 0x82486c: LoadField: r2 = r1->field_b
    //     0x82486c: ldur            w2, [x1, #0xb]
    // 0x824870: DecompressPointer r2
    //     0x824870: add             x2, x2, HEAP, lsl #32
    // 0x824874: cmp             w2, NULL
    // 0x824878: b.eq            #0x8249fc
    // 0x82487c: LoadField: r2 = r1->field_13
    //     0x82487c: ldur            w2, [x1, #0x13]
    // 0x824880: DecompressPointer r2
    //     0x824880: add             x2, x2, HEAP, lsl #32
    // 0x824884: cmp             w2, NULL
    // 0x824888: b.eq            #0x824a00
    // 0x82488c: d0 = 1.000000
    //     0x82488c: fmov            d0, #1.00000000
    // 0x824890: fneg            d1, d0
    // 0x824894: r1 = inline_Allocate_Double()
    //     0x824894: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x824898: add             x1, x1, #0x10
    //     0x82489c: cmp             x2, x1
    //     0x8248a0: b.ls            #0x824a04
    //     0x8248a4: str             x1, [THR, #0x60]  ; THR::top
    //     0x8248a8: sub             x1, x1, #0xf
    //     0x8248ac: mov             x2, #0xd108
    //     0x8248b0: movk            x2, #3, lsl #16
    //     0x8248b4: stur            x2, [x1, #-1]
    // 0x8248b8: StoreField: r1->field_7 = d2
    //     0x8248b8: stur            d2, [x1, #7]
    // 0x8248bc: r2 = inline_Allocate_Double()
    //     0x8248bc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x8248c0: add             x2, x2, #0x10
    //     0x8248c4: cmp             x3, x2
    //     0x8248c8: b.ls            #0x824a20
    //     0x8248cc: str             x2, [THR, #0x60]  ; THR::top
    //     0x8248d0: sub             x2, x2, #0xf
    //     0x8248d4: mov             x3, #0xd108
    //     0x8248d8: movk            x3, #3, lsl #16
    //     0x8248dc: stur            x3, [x2, #-1]
    // 0x8248e0: StoreField: r2->field_7 = d1
    //     0x8248e0: stur            d1, [x2, #7]
    // 0x8248e4: stp             x2, x1, [SP, #-0x10]!
    // 0x8248e8: r16 = 1.000000
    //     0x8248e8: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x8248ec: SaveReg r16
    //     0x8248ec: str             x16, [SP, #-8]!
    // 0x8248f0: r0 = clamp()
    //     0x8248f0: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x8248f4: add             SP, SP, #0x18
    // 0x8248f8: ldur            x0, [fp, #-8]
    // 0x8248fc: LoadField: r1 = r0->field_f
    //     0x8248fc: ldur            w1, [x0, #0xf]
    // 0x824900: DecompressPointer r1
    //     0x824900: add             x1, x1, HEAP, lsl #32
    // 0x824904: LoadField: r2 = r1->field_2f
    //     0x824904: ldur            w2, [x1, #0x2f]
    // 0x824908: DecompressPointer r2
    //     0x824908: add             x2, x2, HEAP, lsl #32
    // 0x82490c: r16 = Sentinel
    //     0x82490c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x824910: cmp             w2, w16
    // 0x824914: b.eq            #0x824a3c
    // 0x824918: LoadField: r3 = r1->field_17
    //     0x824918: ldur            x3, [x1, #0x17]
    // 0x82491c: stp             x3, x2, [SP, #-0x10]!
    // 0x824920: r0 = getRenderIndexFromRealIndex()
    //     0x824920: bl              #0x798338  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::getRenderIndexFromRealIndex
    // 0x824924: add             SP, SP, #0x10
    // 0x824928: ldur            x0, [fp, #-8]
    // 0x82492c: LoadField: r1 = r0->field_f
    //     0x82492c: ldur            w1, [x0, #0xf]
    // 0x824930: DecompressPointer r1
    //     0x824930: add             x1, x1, HEAP, lsl #32
    // 0x824934: LoadField: r2 = r1->field_27
    //     0x824934: ldur            w2, [x1, #0x27]
    // 0x824938: DecompressPointer r2
    //     0x824938: add             x2, x2, HEAP, lsl #32
    // 0x82493c: r16 = Sentinel
    //     0x82493c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x824940: cmp             w2, w16
    // 0x824944: b.eq            #0x824a48
    // 0x824948: LoadField: r2 = r1->field_2f
    //     0x824948: ldur            w2, [x1, #0x2f]
    // 0x82494c: DecompressPointer r2
    //     0x82494c: add             x2, x2, HEAP, lsl #32
    // 0x824950: r16 = Sentinel
    //     0x824950: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x824954: cmp             w2, w16
    // 0x824958: b.eq            #0x824a54
    // 0x82495c: LoadField: r1 = r2->field_33
    //     0x82495c: ldur            w1, [x2, #0x33]
    // 0x824960: DecompressPointer r1
    //     0x824960: add             x1, x1, HEAP, lsl #32
    // 0x824964: SaveReg r1
    //     0x824964: str             x1, [SP, #-8]!
    // 0x824968: r0 = single()
    //     0x824968: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x82496c: add             SP, SP, #8
    // 0x824970: LoadField: r1 = r0->field_43
    //     0x824970: ldur            w1, [x0, #0x43]
    // 0x824974: DecompressPointer r1
    //     0x824974: add             x1, x1, HEAP, lsl #32
    // 0x824978: cmp             w1, NULL
    // 0x82497c: b.eq            #0x824a60
    // 0x824980: ldur            x1, [fp, #-8]
    // 0x824984: LoadField: r2 = r1->field_f
    //     0x824984: ldur            w2, [x1, #0xf]
    // 0x824988: DecompressPointer r2
    //     0x824988: add             x2, x2, HEAP, lsl #32
    // 0x82498c: LoadField: r1 = r2->field_1f
    //     0x82498c: ldur            w1, [x2, #0x1f]
    // 0x824990: DecompressPointer r1
    //     0x824990: add             x1, x1, HEAP, lsl #32
    // 0x824994: r16 = Sentinel
    //     0x824994: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x824998: cmp             w1, w16
    // 0x82499c: b.eq            #0x824a64
    // 0x8249a0: LoadField: r1 = r2->field_b
    //     0x8249a0: ldur            w1, [x2, #0xb]
    // 0x8249a4: DecompressPointer r1
    //     0x8249a4: add             x1, x1, HEAP, lsl #32
    // 0x8249a8: cmp             w1, NULL
    // 0x8249ac: b.eq            #0x824a70
    // 0x8249b0: LoadField: r1 = r2->field_2b
    //     0x8249b0: ldur            w1, [x2, #0x2b]
    // 0x8249b4: DecompressPointer r1
    //     0x8249b4: add             x1, x1, HEAP, lsl #32
    // 0x8249b8: cmp             w1, NULL
    // 0x8249bc: b.eq            #0x824a74
    // 0x8249c0: ldur            x0, [fp, #-0x10]
    // 0x8249c4: LeaveFrame
    //     0x8249c4: mov             SP, fp
    //     0x8249c8: ldp             fp, lr, [SP], #0x10
    // 0x8249cc: ret
    //     0x8249cc: ret             
    // 0x8249d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8249d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8249d4: b               #0x824718
    // 0x8249d8: r9 = _pageController
    //     0x8249d8: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x8249dc: ldr             x9, [x9, #0x6b0]
    // 0x8249e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8249e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8249e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8249e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8249e8: r9 = _pageController
    //     0x8249e8: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x8249ec: ldr             x9, [x9, #0x6b0]
    // 0x8249f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8249f0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8249f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8249f4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x8249f8: r0 = NullErrorSharedWithFPURegs()
    //     0x8249f8: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x8249fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8249fc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x824a00: r0 = NullCastErrorSharedWithFPURegs()
    //     0x824a00: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x824a04: stp             q1, q2, [SP, #-0x20]!
    // 0x824a08: SaveReg r0
    //     0x824a08: str             x0, [SP, #-8]!
    // 0x824a0c: r0 = AllocateDouble()
    //     0x824a0c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x824a10: mov             x1, x0
    // 0x824a14: RestoreReg r0
    //     0x824a14: ldr             x0, [SP], #8
    // 0x824a18: ldp             q1, q2, [SP], #0x20
    // 0x824a1c: b               #0x8248b8
    // 0x824a20: SaveReg d1
    //     0x824a20: str             q1, [SP, #-0x10]!
    // 0x824a24: stp             x0, x1, [SP, #-0x10]!
    // 0x824a28: r0 = AllocateDouble()
    //     0x824a28: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x824a2c: mov             x2, x0
    // 0x824a30: ldp             x0, x1, [SP], #0x10
    // 0x824a34: RestoreReg d1
    //     0x824a34: ldr             q1, [SP], #0x10
    // 0x824a38: b               #0x8248e0
    // 0x824a3c: r9 = _pageController
    //     0x824a3c: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x824a40: ldr             x9, [x9, #0x6b0]
    // 0x824a44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x824a44: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x824a48: r9 = _fromIndex
    //     0x824a48: add             x9, PP, #0x38, lsl #12  ; [pp+0x38740] Field <_TransformerPageViewState@205299810._fromIndex@205299810>: late (offset: 0x28)
    //     0x824a4c: ldr             x9, [x9, #0x740]
    // 0x824a50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x824a50: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x824a54: r9 = _pageController
    //     0x824a54: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x824a58: ldr             x9, [x9, #0x6b0]
    // 0x824a5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x824a5c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x824a60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x824a60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x824a64: r9 = _currentPixels
    //     0x824a64: add             x9, PP, #0x38, lsl #12  ; [pp+0x38748] Field <_TransformerPageViewState@205299810._currentPixels@205299810>: late (offset: 0x20)
    //     0x824a68: ldr             x9, [x9, #0x748]
    // 0x824a6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x824a6c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x824a70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x824a70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x824a74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x824a74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _buildItemNormal(dynamic, BuildContext, int) {
    // ** addr: 0x824b1c, size: 0x54
    // 0x824b1c: EnterFrame
    //     0x824b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x824b20: mov             fp, SP
    // 0x824b24: ldr             x0, [fp, #0x20]
    // 0x824b28: LoadField: r1 = r0->field_17
    //     0x824b28: ldur            w1, [x0, #0x17]
    // 0x824b2c: DecompressPointer r1
    //     0x824b2c: add             x1, x1, HEAP, lsl #32
    // 0x824b30: CheckStackOverflow
    //     0x824b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x824b34: cmp             SP, x16
    //     0x824b38: b.ls            #0x824b68
    // 0x824b3c: LoadField: r0 = r1->field_f
    //     0x824b3c: ldur            w0, [x1, #0xf]
    // 0x824b40: DecompressPointer r0
    //     0x824b40: add             x0, x0, HEAP, lsl #32
    // 0x824b44: ldr             x16, [fp, #0x18]
    // 0x824b48: stp             x16, x0, [SP, #-0x10]!
    // 0x824b4c: ldr             x16, [fp, #0x10]
    // 0x824b50: SaveReg r16
    //     0x824b50: str             x16, [SP, #-8]!
    // 0x824b54: r0 = _buildItemNormal()
    //     0x824b54: bl              #0x824b70  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_buildItemNormal
    // 0x824b58: add             SP, SP, #0x18
    // 0x824b5c: LeaveFrame
    //     0x824b5c: mov             SP, fp
    //     0x824b60: ldp             fp, lr, [SP], #0x10
    // 0x824b64: ret
    //     0x824b64: ret             
    // 0x824b68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x824b68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x824b6c: b               #0x824b3c
  }
  _ _buildItemNormal(/* No info */) {
    // ** addr: 0x824b70, size: 0xcc
    // 0x824b70: EnterFrame
    //     0x824b70: stp             fp, lr, [SP, #-0x10]!
    //     0x824b74: mov             fp, SP
    // 0x824b78: CheckStackOverflow
    //     0x824b78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x824b7c: cmp             SP, x16
    //     0x824b80: b.ls            #0x824c20
    // 0x824b84: ldr             x0, [fp, #0x20]
    // 0x824b88: LoadField: r1 = r0->field_2f
    //     0x824b88: ldur            w1, [x0, #0x2f]
    // 0x824b8c: DecompressPointer r1
    //     0x824b8c: add             x1, x1, HEAP, lsl #32
    // 0x824b90: r16 = Sentinel
    //     0x824b90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x824b94: cmp             w1, w16
    // 0x824b98: b.eq            #0x824c28
    // 0x824b9c: ldr             x2, [fp, #0x10]
    // 0x824ba0: r3 = LoadInt32Instr(r2)
    //     0x824ba0: sbfx            x3, x2, #1, #0x1f
    //     0x824ba4: tbz             w2, #0, #0x824bac
    //     0x824ba8: ldur            x3, [x2, #7]
    // 0x824bac: stp             x3, x1, [SP, #-0x10]!
    // 0x824bb0: r0 = getRenderIndexFromRealIndex()
    //     0x824bb0: bl              #0x798338  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::getRenderIndexFromRealIndex
    // 0x824bb4: add             SP, SP, #0x10
    // 0x824bb8: mov             x2, x0
    // 0x824bbc: ldr             x0, [fp, #0x20]
    // 0x824bc0: LoadField: r1 = r0->field_b
    //     0x824bc0: ldur            w1, [x0, #0xb]
    // 0x824bc4: DecompressPointer r1
    //     0x824bc4: add             x1, x1, HEAP, lsl #32
    // 0x824bc8: cmp             w1, NULL
    // 0x824bcc: b.eq            #0x824c34
    // 0x824bd0: LoadField: r3 = r1->field_1f
    //     0x824bd0: ldur            w3, [x1, #0x1f]
    // 0x824bd4: DecompressPointer r3
    //     0x824bd4: add             x3, x3, HEAP, lsl #32
    // 0x824bd8: cmp             w3, NULL
    // 0x824bdc: b.eq            #0x824c38
    // 0x824be0: r0 = BoxInt64Instr(r2)
    //     0x824be0: sbfiz           x0, x2, #1, #0x1f
    //     0x824be4: cmp             x2, x0, asr #1
    //     0x824be8: b.eq            #0x824bf4
    //     0x824bec: bl              #0xd69bb8
    //     0x824bf0: stur            x2, [x0, #7]
    // 0x824bf4: ldr             x16, [fp, #0x18]
    // 0x824bf8: stp             x16, x3, [SP, #-0x10]!
    // 0x824bfc: SaveReg r0
    //     0x824bfc: str             x0, [SP, #-8]!
    // 0x824c00: mov             x0, x3
    // 0x824c04: ClosureCall
    //     0x824c04: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x824c08: ldur            x2, [x0, #0x1f]
    //     0x824c0c: blr             x2
    // 0x824c10: add             SP, SP, #0x18
    // 0x824c14: LeaveFrame
    //     0x824c14: mov             SP, fp
    //     0x824c18: ldp             fp, lr, [SP], #0x10
    // 0x824c1c: ret
    //     0x824c1c: ret             
    // 0x824c20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x824c20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x824c24: b               #0x824b84
    // 0x824c28: r9 = _pageController
    //     0x824c28: add             x9, PP, #0x38, lsl #12  ; [pp+0x386b0] Field <_TransformerPageViewState@205299810._pageController@205299810>: late (offset: 0x30)
    //     0x824c2c: ldr             x9, [x9, #0x6b0]
    // 0x824c30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x824c30: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x824c34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x824c34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x824c38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x824c38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d5704, size: 0x1bc
    // 0x9d5704: EnterFrame
    //     0x9d5704: stp             fp, lr, [SP, #-0x10]!
    //     0x9d5708: mov             fp, SP
    // 0x9d570c: AllocStack(0x20)
    //     0x9d570c: sub             SP, SP, #0x20
    // 0x9d5710: CheckStackOverflow
    //     0x9d5710: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d5714: cmp             SP, x16
    //     0x9d5718: b.ls            #0x9d58b0
    // 0x9d571c: ldr             x2, [fp, #0x10]
    // 0x9d5720: LoadField: r1 = r2->field_b
    //     0x9d5720: ldur            w1, [x2, #0xb]
    // 0x9d5724: DecompressPointer r1
    //     0x9d5724: add             x1, x1, HEAP, lsl #32
    // 0x9d5728: cmp             w1, NULL
    // 0x9d572c: b.eq            #0x9d58b8
    // 0x9d5730: LoadField: r3 = r1->field_b
    //     0x9d5730: ldur            w3, [x1, #0xb]
    // 0x9d5734: DecompressPointer r3
    //     0x9d5734: add             x3, x3, HEAP, lsl #32
    // 0x9d5738: mov             x0, x3
    // 0x9d573c: StoreField: r2->field_2b = r0
    //     0x9d573c: stur            w0, [x2, #0x2b]
    //     0x9d5740: ldurb           w16, [x2, #-1]
    //     0x9d5744: ldurb           w17, [x0, #-1]
    //     0x9d5748: and             x16, x17, x16, lsr #2
    //     0x9d574c: tst             x16, HEAP, lsr #32
    //     0x9d5750: b.eq            #0x9d5758
    //     0x9d5754: bl              #0xd6828c
    // 0x9d5758: LoadField: r0 = r1->field_2f
    //     0x9d5758: ldur            w0, [x1, #0x2f]
    // 0x9d575c: DecompressPointer r0
    //     0x9d575c: add             x0, x0, HEAP, lsl #32
    // 0x9d5760: cmp             w0, NULL
    // 0x9d5764: b.ne            #0x9d57cc
    // 0x9d5768: LoadField: r4 = r1->field_47
    //     0x9d5768: ldur            x4, [x1, #0x47]
    // 0x9d576c: LoadField: r5 = r1->field_37
    //     0x9d576c: ldur            x5, [x1, #0x37]
    // 0x9d5770: stur            x5, [fp, #-0x18]
    // 0x9d5774: LoadField: r6 = r1->field_33
    //     0x9d5774: ldur            w6, [x1, #0x33]
    // 0x9d5778: DecompressPointer r6
    //     0x9d5778: add             x6, x6, HEAP, lsl #32
    // 0x9d577c: stur            x6, [fp, #-0x10]
    // 0x9d5780: cmp             w3, NULL
    // 0x9d5784: b.eq            #0x9d5788
    // 0x9d5788: r0 = BoxInt64Instr(r4)
    //     0x9d5788: sbfiz           x0, x4, #1, #0x1f
    //     0x9d578c: cmp             x4, x0, asr #1
    //     0x9d5790: b.eq            #0x9d579c
    //     0x9d5794: bl              #0xd69bb8
    //     0x9d5798: stur            x4, [x0, #7]
    // 0x9d579c: stur            x0, [fp, #-8]
    // 0x9d57a0: r0 = TransformerPageController()
    //     0x9d57a0: bl              #0x7977a0  ; AllocateTransformerPageControllerStub -> TransformerPageController (size=0x5c)
    // 0x9d57a4: stur            x0, [fp, #-0x20]
    // 0x9d57a8: ldur            x16, [fp, #-8]
    // 0x9d57ac: stp             x16, x0, [SP, #-0x10]!
    // 0x9d57b0: ldur            x1, [fp, #-0x18]
    // 0x9d57b4: ldur            x16, [fp, #-0x10]
    // 0x9d57b8: stp             x16, x1, [SP, #-0x10]!
    // 0x9d57bc: r0 = TransformerPageController()
    //     0x9d57bc: bl              #0x7976fc  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::TransformerPageController
    // 0x9d57c0: add             SP, SP, #0x20
    // 0x9d57c4: ldur            x1, [fp, #-0x20]
    // 0x9d57c8: b               #0x9d57d0
    // 0x9d57cc: mov             x1, x0
    // 0x9d57d0: ldr             x2, [fp, #0x10]
    // 0x9d57d4: mov             x0, x1
    // 0x9d57d8: StoreField: r2->field_2f = r0
    //     0x9d57d8: stur            w0, [x2, #0x2f]
    //     0x9d57dc: ldurb           w16, [x2, #-1]
    //     0x9d57e0: ldurb           w17, [x0, #-1]
    //     0x9d57e4: and             x16, x17, x16, lsr #2
    //     0x9d57e8: tst             x16, HEAP, lsr #32
    //     0x9d57ec: b.eq            #0x9d57f4
    //     0x9d57f0: bl              #0xd6828c
    // 0x9d57f4: LoadField: r3 = r1->field_37
    //     0x9d57f4: ldur            x3, [x1, #0x37]
    // 0x9d57f8: StoreField: r2->field_17 = r3
    //     0x9d57f8: stur            x3, [x2, #0x17]
    // 0x9d57fc: r0 = BoxInt64Instr(r3)
    //     0x9d57fc: sbfiz           x0, x3, #1, #0x1f
    //     0x9d5800: cmp             x3, x0, asr #1
    //     0x9d5804: b.eq            #0x9d5810
    //     0x9d5808: bl              #0xd69bb8
    //     0x9d580c: stur            x3, [x0, #7]
    // 0x9d5810: StoreField: r2->field_27 = r0
    //     0x9d5810: stur            w0, [x2, #0x27]
    //     0x9d5814: tbz             w0, #0, #0x9d5830
    //     0x9d5818: ldurb           w16, [x2, #-1]
    //     0x9d581c: ldurb           w17, [x0, #-1]
    //     0x9d5820: and             x16, x17, x16, lsr #2
    //     0x9d5824: tst             x16, HEAP, lsr #32
    //     0x9d5828: b.eq            #0x9d5830
    //     0x9d582c: bl              #0xd6828c
    // 0x9d5830: LoadField: r0 = r2->field_b
    //     0x9d5830: ldur            w0, [x2, #0xb]
    // 0x9d5834: DecompressPointer r0
    //     0x9d5834: add             x0, x0, HEAP, lsl #32
    // 0x9d5838: cmp             w0, NULL
    // 0x9d583c: b.eq            #0x9d58bc
    // 0x9d5840: LoadField: r1 = r0->field_23
    //     0x9d5840: ldur            w1, [x0, #0x23]
    // 0x9d5844: DecompressPointer r1
    //     0x9d5844: add             x1, x1, HEAP, lsl #32
    // 0x9d5848: mov             x0, x1
    // 0x9d584c: stur            x1, [fp, #-8]
    // 0x9d5850: StoreField: r2->field_33 = r0
    //     0x9d5850: stur            w0, [x2, #0x33]
    //     0x9d5854: ldurb           w16, [x2, #-1]
    //     0x9d5858: ldurb           w17, [x0, #-1]
    //     0x9d585c: and             x16, x17, x16, lsr #2
    //     0x9d5860: tst             x16, HEAP, lsr #32
    //     0x9d5864: b.eq            #0x9d586c
    //     0x9d5868: bl              #0xd6828c
    // 0x9d586c: r1 = 1
    //     0x9d586c: mov             x1, #1
    // 0x9d5870: r0 = AllocateContext()
    //     0x9d5870: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d5874: mov             x1, x0
    // 0x9d5878: ldr             x0, [fp, #0x10]
    // 0x9d587c: StoreField: r1->field_f = r0
    //     0x9d587c: stur            w0, [x1, #0xf]
    // 0x9d5880: mov             x2, x1
    // 0x9d5884: r1 = Function 'onChangeNotifier':.
    //     0x9d5884: add             x1, PP, #0x38, lsl #12  ; [pp+0x386a0] AnonymousClosure: (0x798480), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::onChangeNotifier (0x7984c8)
    //     0x9d5888: ldr             x1, [x1, #0x6a0]
    // 0x9d588c: r0 = AllocateClosure()
    //     0x9d588c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d5890: ldur            x16, [fp, #-8]
    // 0x9d5894: stp             x0, x16, [SP, #-0x10]!
    // 0x9d5898: r0 = addListener()
    //     0x9d5898: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9d589c: add             SP, SP, #0x10
    // 0x9d58a0: r0 = Null
    //     0x9d58a0: mov             x0, NULL
    // 0x9d58a4: LeaveFrame
    //     0x9d58a4: mov             SP, fp
    //     0x9d58a8: ldp             fp, lr, [SP], #0x10
    // 0x9d58ac: ret
    //     0x9d58ac: ret             
    // 0x9d58b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d58b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d58b4: b               #0x9d571c
    // 0x9d58b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d58b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d58bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d58bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa49fe8, size: 0x18
    // 0xa49fe8: r4 = 7
    //     0xa49fe8: mov             x4, #7
    // 0xa49fec: r1 = Function 'dispose':.
    //     0xa49fec: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca58] AnonymousClosure: (0xa4a000), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::dispose (0xa4e814)
    //     0xa49ff0: ldr             x1, [x17, #0xa58]
    // 0xa49ff4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa49ff4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa49ff8: LoadField: r0 = r24->field_17
    //     0xa49ff8: ldur            x0, [x24, #0x17]
    // 0xa49ffc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a000, size: 0x48
    // 0xa4a000: EnterFrame
    //     0xa4a000: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a004: mov             fp, SP
    // 0xa4a008: ldr             x0, [fp, #0x10]
    // 0xa4a00c: LoadField: r1 = r0->field_17
    //     0xa4a00c: ldur            w1, [x0, #0x17]
    // 0xa4a010: DecompressPointer r1
    //     0xa4a010: add             x1, x1, HEAP, lsl #32
    // 0xa4a014: CheckStackOverflow
    //     0xa4a014: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a018: cmp             SP, x16
    //     0xa4a01c: b.ls            #0xa4a040
    // 0xa4a020: LoadField: r0 = r1->field_f
    //     0xa4a020: ldur            w0, [x1, #0xf]
    // 0xa4a024: DecompressPointer r0
    //     0xa4a024: add             x0, x0, HEAP, lsl #32
    // 0xa4a028: SaveReg r0
    //     0xa4a028: str             x0, [SP, #-8]!
    // 0xa4a02c: r0 = dispose()
    //     0xa4a02c: bl              #0xa4e814  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::dispose
    // 0xa4a030: add             SP, SP, #8
    // 0xa4a034: LeaveFrame
    //     0xa4a034: mov             SP, fp
    //     0xa4a038: ldp             fp, lr, [SP], #0x10
    // 0xa4a03c: ret
    //     0xa4a03c: ret             
    // 0xa4a040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a040: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a044: b               #0xa4a020
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4e814, size: 0x7c
    // 0xa4e814: EnterFrame
    //     0xa4e814: stp             fp, lr, [SP, #-0x10]!
    //     0xa4e818: mov             fp, SP
    // 0xa4e81c: AllocStack(0x8)
    //     0xa4e81c: sub             SP, SP, #8
    // 0xa4e820: CheckStackOverflow
    //     0xa4e820: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4e824: cmp             SP, x16
    //     0xa4e828: b.ls            #0xa4e888
    // 0xa4e82c: ldr             x0, [fp, #0x10]
    // 0xa4e830: LoadField: r1 = r0->field_33
    //     0xa4e830: ldur            w1, [x0, #0x33]
    // 0xa4e834: DecompressPointer r1
    //     0xa4e834: add             x1, x1, HEAP, lsl #32
    // 0xa4e838: stur            x1, [fp, #-8]
    // 0xa4e83c: cmp             w1, NULL
    // 0xa4e840: b.eq            #0xa4e878
    // 0xa4e844: r1 = 1
    //     0xa4e844: mov             x1, #1
    // 0xa4e848: r0 = AllocateContext()
    //     0xa4e848: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4e84c: mov             x1, x0
    // 0xa4e850: ldr             x0, [fp, #0x10]
    // 0xa4e854: StoreField: r1->field_f = r0
    //     0xa4e854: stur            w0, [x1, #0xf]
    // 0xa4e858: mov             x2, x1
    // 0xa4e85c: r1 = Function 'onChangeNotifier':.
    //     0xa4e85c: add             x1, PP, #0x38, lsl #12  ; [pp+0x386a0] AnonymousClosure: (0x798480), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::onChangeNotifier (0x7984c8)
    //     0xa4e860: ldr             x1, [x1, #0x6a0]
    // 0xa4e864: r0 = AllocateClosure()
    //     0xa4e864: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4e868: ldur            x16, [fp, #-8]
    // 0xa4e86c: stp             x0, x16, [SP, #-0x10]!
    // 0xa4e870: r0 = removeListener()
    //     0xa4e870: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4e874: add             SP, SP, #0x10
    // 0xa4e878: r0 = Null
    //     0xa4e878: mov             x0, NULL
    // 0xa4e87c: LeaveFrame
    //     0xa4e87c: mov             SP, fp
    //     0xa4e880: ldp             fp, lr, [SP], #0x10
    // 0xa4e884: ret
    //     0xa4e884: ret             
    // 0xa4e888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4e888: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4e88c: b               #0xa4e82c
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa5f7b0, size: 0x160
    // 0xa5f7b0: EnterFrame
    //     0xa5f7b0: stp             fp, lr, [SP, #-0x10]!
    //     0xa5f7b4: mov             fp, SP
    // 0xa5f7b8: AllocStack(0x18)
    //     0xa5f7b8: sub             SP, SP, #0x18
    // 0xa5f7bc: CheckStackOverflow
    //     0xa5f7bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5f7c0: cmp             SP, x16
    //     0xa5f7c4: b.ls            #0xa5f900
    // 0xa5f7c8: ldr             x0, [fp, #0x10]
    // 0xa5f7cc: LoadField: r1 = r0->field_2b
    //     0xa5f7cc: ldur            w1, [x0, #0x2b]
    // 0xa5f7d0: DecompressPointer r1
    //     0xa5f7d0: add             x1, x1, HEAP, lsl #32
    // 0xa5f7d4: cmp             w1, NULL
    // 0xa5f7d8: b.eq            #0xa5f8f0
    // 0xa5f7dc: r1 = LoadStaticField(0xbb8)
    //     0xa5f7dc: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0xa5f7e0: ldr             x1, [x1, #0x1770]
    // 0xa5f7e4: stur            x1, [fp, #-8]
    // 0xa5f7e8: cmp             w1, NULL
    // 0xa5f7ec: b.eq            #0xa5f908
    // 0xa5f7f0: r1 = 1
    //     0xa5f7f0: mov             x1, #1
    // 0xa5f7f4: r0 = AllocateContext()
    //     0xa5f7f4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa5f7f8: mov             x1, x0
    // 0xa5f7fc: ldr             x0, [fp, #0x10]
    // 0xa5f800: StoreField: r1->field_f = r0
    //     0xa5f800: stur            w0, [x1, #0xf]
    // 0xa5f804: ldur            x0, [fp, #-8]
    // 0xa5f808: LoadField: r3 = r0->field_57
    //     0xa5f808: ldur            w3, [x0, #0x57]
    // 0xa5f80c: DecompressPointer r3
    //     0xa5f80c: add             x3, x3, HEAP, lsl #32
    // 0xa5f810: stur            x3, [fp, #-0x10]
    // 0xa5f814: LoadField: r0 = r3->field_7
    //     0xa5f814: ldur            w0, [x3, #7]
    // 0xa5f818: DecompressPointer r0
    //     0xa5f818: add             x0, x0, HEAP, lsl #32
    // 0xa5f81c: mov             x2, x1
    // 0xa5f820: stur            x0, [fp, #-8]
    // 0xa5f824: r1 = Function '_onGetSize@205299810':.
    //     0xa5f824: add             x1, PP, #0x38, lsl #12  ; [pp+0x386b8] AnonymousClosure: (0x79876c), in [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] _TransformerPageViewState::_onGetSize (0x7987b8)
    //     0xa5f828: ldr             x1, [x1, #0x6b8]
    // 0xa5f82c: r0 = AllocateClosure()
    //     0xa5f82c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa5f830: ldur            x2, [fp, #-8]
    // 0xa5f834: mov             x3, x0
    // 0xa5f838: r1 = Null
    //     0xa5f838: mov             x1, NULL
    // 0xa5f83c: stur            x3, [fp, #-8]
    // 0xa5f840: cmp             w2, NULL
    // 0xa5f844: b.eq            #0xa5f864
    // 0xa5f848: LoadField: r4 = r2->field_17
    //     0xa5f848: ldur            w4, [x2, #0x17]
    // 0xa5f84c: DecompressPointer r4
    //     0xa5f84c: add             x4, x4, HEAP, lsl #32
    // 0xa5f850: r8 = X0
    //     0xa5f850: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa5f854: LoadField: r9 = r4->field_7
    //     0xa5f854: ldur            x9, [x4, #7]
    // 0xa5f858: r3 = Null
    //     0xa5f858: add             x3, PP, #0x38, lsl #12  ; [pp+0x386c0] Null
    //     0xa5f85c: ldr             x3, [x3, #0x6c0]
    // 0xa5f860: blr             x9
    // 0xa5f864: ldur            x0, [fp, #-0x10]
    // 0xa5f868: LoadField: r1 = r0->field_b
    //     0xa5f868: ldur            w1, [x0, #0xb]
    // 0xa5f86c: DecompressPointer r1
    //     0xa5f86c: add             x1, x1, HEAP, lsl #32
    // 0xa5f870: stur            x1, [fp, #-0x18]
    // 0xa5f874: LoadField: r2 = r0->field_f
    //     0xa5f874: ldur            w2, [x0, #0xf]
    // 0xa5f878: DecompressPointer r2
    //     0xa5f878: add             x2, x2, HEAP, lsl #32
    // 0xa5f87c: LoadField: r3 = r2->field_b
    //     0xa5f87c: ldur            w3, [x2, #0xb]
    // 0xa5f880: DecompressPointer r3
    //     0xa5f880: add             x3, x3, HEAP, lsl #32
    // 0xa5f884: cmp             w1, w3
    // 0xa5f888: b.ne            #0xa5f898
    // 0xa5f88c: SaveReg r0
    //     0xa5f88c: str             x0, [SP, #-8]!
    // 0xa5f890: r0 = _growToNextCapacity()
    //     0xa5f890: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa5f894: add             SP, SP, #8
    // 0xa5f898: ldur            x2, [fp, #-0x10]
    // 0xa5f89c: ldur            x3, [fp, #-0x18]
    // 0xa5f8a0: r4 = LoadInt32Instr(r3)
    //     0xa5f8a0: sbfx            x4, x3, #1, #0x1f
    // 0xa5f8a4: add             x0, x4, #1
    // 0xa5f8a8: lsl             x3, x0, #1
    // 0xa5f8ac: StoreField: r2->field_b = r3
    //     0xa5f8ac: stur            w3, [x2, #0xb]
    // 0xa5f8b0: mov             x1, x4
    // 0xa5f8b4: cmp             x1, x0
    // 0xa5f8b8: b.hs            #0xa5f90c
    // 0xa5f8bc: LoadField: r1 = r2->field_f
    //     0xa5f8bc: ldur            w1, [x2, #0xf]
    // 0xa5f8c0: DecompressPointer r1
    //     0xa5f8c0: add             x1, x1, HEAP, lsl #32
    // 0xa5f8c4: ldur            x0, [fp, #-8]
    // 0xa5f8c8: ArrayStore: r1[r4] = r0  ; List_4
    //     0xa5f8c8: add             x25, x1, x4, lsl #2
    //     0xa5f8cc: add             x25, x25, #0xf
    //     0xa5f8d0: str             w0, [x25]
    //     0xa5f8d4: tbz             w0, #0, #0xa5f8f0
    //     0xa5f8d8: ldurb           w16, [x1, #-1]
    //     0xa5f8dc: ldurb           w17, [x0, #-1]
    //     0xa5f8e0: and             x16, x17, x16, lsr #2
    //     0xa5f8e4: tst             x16, HEAP, lsr #32
    //     0xa5f8e8: b.eq            #0xa5f8f0
    //     0xa5f8ec: bl              #0xd67e5c
    // 0xa5f8f0: r0 = Null
    //     0xa5f8f0: mov             x0, NULL
    // 0xa5f8f4: LeaveFrame
    //     0xa5f8f4: mov             SP, fp
    //     0xa5f8f8: ldp             fp, lr, [SP], #0x10
    // 0xa5f8fc: ret
    //     0xa5f8fc: ret             
    // 0xa5f900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5f900: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5f904: b               #0xa5f7c8
    // 0xa5f908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5f908: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5f90c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa5f90c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 4220, size: 0x54, field offset: 0xc
//   const constructor, 
class TransformerPageView extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3efac, size: 0x40
    // 0xa3efac: EnterFrame
    //     0xa3efac: stp             fp, lr, [SP, #-0x10]!
    //     0xa3efb0: mov             fp, SP
    // 0xa3efb4: r1 = <TransformerPageView>
    //     0xa3efb4: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f0e8] TypeArguments: <TransformerPageView>
    //     0xa3efb8: ldr             x1, [x1, #0xe8]
    // 0xa3efbc: r0 = _TransformerPageViewState()
    //     0xa3efbc: bl              #0xa3efec  ; Allocate_TransformerPageViewStateStub -> _TransformerPageViewState (size=0x38)
    // 0xa3efc0: r1 = 0
    //     0xa3efc0: mov             x1, #0
    // 0xa3efc4: StoreField: r0->field_17 = r1
    //     0xa3efc4: stur            x1, [x0, #0x17]
    // 0xa3efc8: r1 = Sentinel
    //     0xa3efc8: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3efcc: StoreField: r0->field_1f = r1
    //     0xa3efcc: stur            w1, [x0, #0x1f]
    // 0xa3efd0: r2 = false
    //     0xa3efd0: add             x2, NULL, #0x30  ; false
    // 0xa3efd4: StoreField: r0->field_23 = r2
    //     0xa3efd4: stur            w2, [x0, #0x23]
    // 0xa3efd8: StoreField: r0->field_27 = r1
    //     0xa3efd8: stur            w1, [x0, #0x27]
    // 0xa3efdc: StoreField: r0->field_2f = r1
    //     0xa3efdc: stur            w1, [x0, #0x2f]
    // 0xa3efe0: LeaveFrame
    //     0xa3efe0: mov             SP, fp
    //     0xa3efe4: ldp             fp, lr, [SP], #0x10
    // 0xa3efe8: ret
    //     0xa3efe8: ret             
  }
}

// class id: 4863, size: 0x5c, field offset: 0x4c
class TransformerPageController extends PageController {

  _ TransformerPageController(/* No info */) {
    // ** addr: 0x7976fc, size: 0xa4
    // 0x7976fc: EnterFrame
    //     0x7976fc: stp             fp, lr, [SP, #-0x10]!
    //     0x797700: mov             fp, SP
    // 0x797704: r0 = false
    //     0x797704: add             x0, NULL, #0x30  ; false
    // 0x797708: CheckStackOverflow
    //     0x797708: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79770c: cmp             SP, x16
    //     0x797710: b.ls            #0x797798
    // 0x797714: ldr             x2, [fp, #0x28]
    // 0x797718: ldr             x1, [fp, #0x10]
    // 0x79771c: StoreField: r2->field_4b = r1
    //     0x79771c: stur            w1, [x2, #0x4b]
    // 0x797720: ldr             x3, [fp, #0x18]
    // 0x797724: StoreField: r2->field_4f = r3
    //     0x797724: stur            x3, [x2, #0x4f]
    // 0x797728: StoreField: r2->field_57 = r0
    //     0x797728: stur            w0, [x2, #0x57]
    // 0x79772c: tbnz            w1, #4, #0x797754
    // 0x797730: ldr             x0, [fp, #0x20]
    // 0x797734: r1 = LoadInt32Instr(r0)
    //     0x797734: sbfx            x1, x0, #1, #0x1f
    //     0x797738: tbz             w0, #0, #0x797740
    //     0x79773c: ldur            x1, [x0, #7]
    // 0x797740: r17 = 1000000000
    //     0x797740: mov             x17, #0xca00
    //     0x797744: movk            x17, #0x3b9a, lsl #16
    // 0x797748: add             x0, x1, x17
    // 0x79774c: mov             x1, x0
    // 0x797750: b               #0x797764
    // 0x797754: ldr             x0, [fp, #0x20]
    // 0x797758: r1 = LoadInt32Instr(r0)
    //     0x797758: sbfx            x1, x0, #1, #0x1f
    //     0x79775c: tbz             w0, #0, #0x797764
    //     0x797760: ldur            x1, [x0, #7]
    // 0x797764: r0 = true
    //     0x797764: add             x0, NULL, #0x20  ; true
    // 0x797768: d0 = 1.000000
    //     0x797768: fmov            d0, #1.00000000
    // 0x79776c: StoreField: r2->field_37 = r1
    //     0x79776c: stur            x1, [x2, #0x37]
    // 0x797770: StoreField: r2->field_3f = r0
    //     0x797770: stur            w0, [x2, #0x3f]
    // 0x797774: StoreField: r2->field_43 = d0
    //     0x797774: stur            d0, [x2, #0x43]
    // 0x797778: SaveReg r2
    //     0x797778: str             x2, [SP, #-8]!
    // 0x79777c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x79777c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x797780: r0 = ScrollController()
    //     0x797780: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x797784: add             SP, SP, #8
    // 0x797788: r0 = Null
    //     0x797788: mov             x0, NULL
    // 0x79778c: LeaveFrame
    //     0x79778c: mov             SP, fp
    //     0x797790: ldp             fp, lr, [SP], #0x10
    // 0x797794: ret
    //     0x797794: ret             
    // 0x797798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x797798: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79779c: b               #0x797714
  }
  _ getRealIndexFromRenderIndex(/* No info */) {
    // ** addr: 0x798304, size: 0x34
    // 0x798304: ldr             x1, [SP, #8]
    // 0x798308: LoadField: r2 = r1->field_4b
    //     0x798308: ldur            w2, [x1, #0x4b]
    // 0x79830c: DecompressPointer r2
    //     0x79830c: add             x2, x2, HEAP, lsl #32
    // 0x798310: tbnz            w2, #4, #0x79832c
    // 0x798314: ldr             x1, [SP]
    // 0x798318: r17 = 1000000000
    //     0x798318: mov             x17, #0xca00
    //     0x79831c: movk            x17, #0x3b9a, lsl #16
    // 0x798320: add             x2, x1, x17
    // 0x798324: mov             x0, x2
    // 0x798328: b               #0x798334
    // 0x79832c: ldr             x1, [SP]
    // 0x798330: mov             x0, x1
    // 0x798334: ret
    //     0x798334: ret             
  }
  _ getRenderIndexFromRealIndex(/* No info */) {
    // ** addr: 0x798338, size: 0x60
    // 0x798338: EnterFrame
    //     0x798338: stp             fp, lr, [SP, #-0x10]!
    //     0x79833c: mov             fp, SP
    // 0x798340: CheckStackOverflow
    //     0x798340: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x798344: cmp             SP, x16
    //     0x798348: b.ls            #0x798390
    // 0x79834c: ldr             x0, [fp, #0x18]
    // 0x798350: LoadField: r2 = r0->field_4b
    //     0x798350: ldur            w2, [x0, #0x4b]
    // 0x798354: DecompressPointer r2
    //     0x798354: add             x2, x2, HEAP, lsl #32
    // 0x798358: LoadField: r3 = r0->field_4f
    //     0x798358: ldur            x3, [x0, #0x4f]
    // 0x79835c: ldr             x4, [fp, #0x10]
    // 0x798360: r0 = BoxInt64Instr(r4)
    //     0x798360: sbfiz           x0, x4, #1, #0x1f
    //     0x798364: cmp             x4, x0, asr #1
    //     0x798368: b.eq            #0x798374
    //     0x79836c: bl              #0xd69bb8
    //     0x798370: stur            x4, [x0, #7]
    // 0x798374: stp             x2, x0, [SP, #-0x10]!
    // 0x798378: SaveReg r3
    //     0x798378: str             x3, [SP, #-8]!
    // 0x79837c: r0 = _getRenderIndexFromRealIndex()
    //     0x79837c: bl              #0x798398  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::_getRenderIndexFromRealIndex
    // 0x798380: add             SP, SP, #0x18
    // 0x798384: LeaveFrame
    //     0x798384: mov             SP, fp
    //     0x798388: ldp             fp, lr, [SP], #0x10
    // 0x79838c: ret
    //     0x79838c: ret             
    // 0x798390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x798390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x798394: b               #0x79834c
  }
  static _ _getRenderIndexFromRealIndex(/* No info */) {
    // ** addr: 0x798398, size: 0xc4
    // 0x798398: EnterFrame
    //     0x798398: stp             fp, lr, [SP, #-0x10]!
    //     0x79839c: mov             fp, SP
    // 0x7983a0: ldr             x1, [fp, #0x10]
    // 0x7983a4: lsl             x2, x1, #1
    // 0x7983a8: cbnz            w2, #0x7983bc
    // 0x7983ac: r0 = 0
    //     0x7983ac: mov             x0, #0
    // 0x7983b0: LeaveFrame
    //     0x7983b0: mov             SP, fp
    //     0x7983b4: ldp             fp, lr, [SP], #0x10
    // 0x7983b8: ret
    //     0x7983b8: ret             
    // 0x7983bc: ldr             x2, [fp, #0x18]
    // 0x7983c0: tbnz            w2, #4, #0x798410
    // 0x7983c4: ldr             x2, [fp, #0x20]
    // 0x7983c8: r3 = LoadInt32Instr(r2)
    //     0x7983c8: sbfx            x3, x2, #1, #0x1f
    //     0x7983cc: tbz             w2, #0, #0x7983d4
    //     0x7983d0: ldur            x3, [x2, #7]
    // 0x7983d4: r17 = -999948289
    //     0x7983d4: mov             x17, #-0x3b9a0001
    // 0x7983d8: movk            x17, #0x3600
    // 0x7983dc: add             x4, x3, x17
    // 0x7983e0: cbz             x1, #0x798430
    // 0x7983e4: sdiv            x5, x4, x1
    // 0x7983e8: msub            x3, x5, x1, x4
    // 0x7983ec: cmp             x3, xzr
    // 0x7983f0: b.lt            #0x798448
    // 0x7983f4: tbz             x3, #0x3f, #0x798404
    // 0x7983f8: add             x4, x3, x1
    // 0x7983fc: mov             x1, x4
    // 0x798400: b               #0x798408
    // 0x798404: mov             x1, x3
    // 0x798408: mov             x0, x1
    // 0x79840c: b               #0x798424
    // 0x798410: ldr             x2, [fp, #0x20]
    // 0x798414: r1 = LoadInt32Instr(r2)
    //     0x798414: sbfx            x1, x2, #1, #0x1f
    //     0x798418: tbz             w2, #0, #0x798420
    //     0x79841c: ldur            x1, [x2, #7]
    // 0x798420: mov             x0, x1
    // 0x798424: LeaveFrame
    //     0x798424: mov             SP, fp
    //     0x798428: ldp             fp, lr, [SP], #0x10
    // 0x79842c: ret
    //     0x79842c: ret             
    // 0x798430: stp             x1, x4, [SP, #-0x10]!
    // 0x798434: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0x798438: r4 = 0
    //     0x798438: mov             x4, #0
    // 0x79843c: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x798440: blr             lr
    // 0x798444: brk             #0
    // 0x798448: cmp             x1, xzr
    // 0x79844c: sub             x5, x3, x1
    // 0x798450: add             x3, x3, x1
    // 0x798454: csel            x3, x5, x3, lt
    // 0x798458: b               #0x7983f4
  }
  get _ realPage(/* No info */) {
    // ** addr: 0x824a78, size: 0xa4
    // 0x824a78: EnterFrame
    //     0x824a78: stp             fp, lr, [SP, #-0x10]!
    //     0x824a7c: mov             fp, SP
    // 0x824a80: AllocStack(0x8)
    //     0x824a80: sub             SP, SP, #8
    // 0x824a84: CheckStackOverflow
    //     0x824a84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x824a88: cmp             SP, x16
    //     0x824a8c: b.ls            #0x824b14
    // 0x824a90: ldr             x0, [fp, #0x10]
    // 0x824a94: LoadField: r1 = r0->field_33
    //     0x824a94: ldur            w1, [x0, #0x33]
    // 0x824a98: DecompressPointer r1
    //     0x824a98: add             x1, x1, HEAP, lsl #32
    // 0x824a9c: SaveReg r1
    //     0x824a9c: str             x1, [SP, #-8]!
    // 0x824aa0: r0 = single()
    //     0x824aa0: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x824aa4: add             SP, SP, #8
    // 0x824aa8: mov             x3, x0
    // 0x824aac: r2 = Null
    //     0x824aac: mov             x2, NULL
    // 0x824ab0: r1 = Null
    //     0x824ab0: mov             x1, NULL
    // 0x824ab4: stur            x3, [fp, #-8]
    // 0x824ab8: r4 = LoadClassIdInstr(r0)
    //     0x824ab8: ldur            x4, [x0, #-1]
    //     0x824abc: ubfx            x4, x4, #0xc, #0x14
    // 0x824ac0: r17 = 4847
    //     0x824ac0: mov             x17, #0x12ef
    // 0x824ac4: cmp             x4, x17
    // 0x824ac8: b.eq            #0x824ae0
    // 0x824acc: r8 = _PagePosition
    //     0x824acc: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x824ad0: ldr             x8, [x8, #0xf98]
    // 0x824ad4: r3 = Null
    //     0x824ad4: add             x3, PP, #0x38, lsl #12  ; [pp+0x38750] Null
    //     0x824ad8: ldr             x3, [x3, #0x750]
    // 0x824adc: r0 = DefaultTypeTest()
    //     0x824adc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x824ae0: ldur            x16, [fp, #-8]
    // 0x824ae4: SaveReg r16
    //     0x824ae4: str             x16, [SP, #-8]!
    // 0x824ae8: r0 = page()
    //     0x824ae8: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x824aec: add             SP, SP, #8
    // 0x824af0: cmp             w0, NULL
    // 0x824af4: b.ne            #0x824b00
    // 0x824af8: d0 = 0.000000
    //     0x824af8: eor             v0.16b, v0.16b, v0.16b
    // 0x824afc: b               #0x824b08
    // 0x824b00: LoadField: d1 = r0->field_7
    //     0x824b00: ldur            d1, [x0, #7]
    // 0x824b04: mov             v0.16b, v1.16b
    // 0x824b08: LeaveFrame
    //     0x824b08: mov             SP, fp
    //     0x824b0c: ldp             fp, lr, [SP], #0x10
    // 0x824b10: ret
    //     0x824b10: ret             
    // 0x824b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x824b14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x824b18: b               #0x824a90
  }
  static _ _getRenderPageFromRealPage(/* No info */) {
    // ** addr: 0xce7424, size: 0xe0
    // 0xce7424: EnterFrame
    //     0xce7424: stp             fp, lr, [SP, #-0x10]!
    //     0xce7428: mov             fp, SP
    // 0xce742c: AllocStack(0x10)
    //     0xce742c: sub             SP, SP, #0x10
    // 0xce7430: CheckStackOverflow
    //     0xce7430: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce7434: cmp             SP, x16
    //     0xce7438: b.ls            #0xce74fc
    // 0xce743c: ldr             x0, [fp, #0x18]
    // 0xce7440: tbnz            w0, #4, #0xce74e4
    // 0xce7444: ldr             x1, [fp, #0x20]
    // 0xce7448: ldr             x0, [fp, #0x10]
    // 0xce744c: d0 = 1000000000.000000
    //     0xce744c: add             x17, PP, #0x54, lsl #12  ; [pp+0x547a8] IMM: double(1e+09) from 0x41cdcd6500000000
    //     0xce7450: ldr             d0, [x17, #0x7a8]
    // 0xce7454: LoadField: d1 = r1->field_7
    //     0xce7454: ldur            d1, [x1, #7]
    // 0xce7458: fsub            d2, d1, d0
    // 0xce745c: stur            d2, [fp, #-0x10]
    // 0xce7460: lsl             x1, x0, #1
    // 0xce7464: stur            x1, [fp, #-8]
    // 0xce7468: stp             x1, NULL, [SP, #-0x10]!
    // 0xce746c: r0 = _Double.fromInteger()
    //     0xce746c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xce7470: add             SP, SP, #0x10
    // 0xce7474: LoadField: d1 = r0->field_7
    //     0xce7474: ldur            d1, [x0, #7]
    // 0xce7478: ldur            d0, [fp, #-0x10]
    // 0xce747c: stp             fp, lr, [SP, #-0x10]!
    // 0xce7480: mov             fp, SP
    // 0xce7484: CallRuntime_DartModulo(double, double) -> double
    //     0xce7484: and             SP, SP, #0xfffffffffffffff0
    //     0xce7488: mov             sp, SP
    //     0xce748c: ldr             x16, [THR, #0x558]  ; THR::DartModulo
    //     0xce7490: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xce7494: blr             x16
    //     0xce7498: mov             x16, #8
    //     0xce749c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xce74a0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xce74a4: sub             sp, x16, #1, lsl #12
    //     0xce74a8: mov             SP, fp
    //     0xce74ac: ldp             fp, lr, [SP], #0x10
    // 0xce74b0: d1 = 0.000000
    //     0xce74b0: eor             v1.16b, v1.16b, v1.16b
    // 0xce74b4: fcmp            d0, d1
    // 0xce74b8: b.vs            #0xce74d8
    // 0xce74bc: b.ge            #0xce74d8
    // 0xce74c0: ldur            x0, [fp, #-8]
    // 0xce74c4: r16 = LoadInt32Instr(r0)
    //     0xce74c4: sbfx            x16, x0, #1, #0x1f
    // 0xce74c8: scvtf           d1, w16
    // 0xce74cc: fadd            d2, d0, d1
    // 0xce74d0: mov             v1.16b, v2.16b
    // 0xce74d4: b               #0xce74dc
    // 0xce74d8: mov             v1.16b, v0.16b
    // 0xce74dc: mov             v0.16b, v1.16b
    // 0xce74e0: b               #0xce74f0
    // 0xce74e4: ldr             x1, [fp, #0x20]
    // 0xce74e8: LoadField: d1 = r1->field_7
    //     0xce74e8: ldur            d1, [x1, #7]
    // 0xce74ec: mov             v0.16b, v1.16b
    // 0xce74f0: LeaveFrame
    //     0xce74f0: mov             SP, fp
    //     0xce74f4: ldp             fp, lr, [SP], #0x10
    // 0xce74f8: ret
    //     0xce74f8: ret             
    // 0xce74fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce74fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce7500: b               #0xce743c
  }
}

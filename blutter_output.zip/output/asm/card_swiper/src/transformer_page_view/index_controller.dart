// lib: , url: package:card_swiper/src/transformer_page_view/index_controller.dart

// class id: 1048736, size: 0x8
class :: {
}

// class id: 4864, size: 0x28, field offset: 0x24
abstract class IndexController extends ChangeNotifier {

  _ next(/* No info */) {
    // ** addr: 0x823c68, size: 0x84
    // 0x823c68: EnterFrame
    //     0x823c68: stp             fp, lr, [SP, #-0x10]!
    //     0x823c6c: mov             fp, SP
    // 0x823c70: AllocStack(0x8)
    //     0x823c70: sub             SP, SP, #8
    // 0x823c74: CheckStackOverflow
    //     0x823c74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823c78: cmp             SP, x16
    //     0x823c7c: b.ls            #0x823ce4
    // 0x823c80: r0 = NextIndexControllerEvent()
    //     0x823c80: bl              #0x823d64  ; AllocateNextIndexControllerEventStub -> NextIndexControllerEvent (size=0x10)
    // 0x823c84: stur            x0, [fp, #-8]
    // 0x823c88: SaveReg r0
    //     0x823c88: str             x0, [SP, #-8]!
    // 0x823c8c: r0 = NextIndexControllerEvent()
    //     0x823c8c: bl              #0x823cec  ; [package:card_swiper/src/transformer_page_view/index_controller.dart] NextIndexControllerEvent::NextIndexControllerEvent
    // 0x823c90: add             SP, SP, #8
    // 0x823c94: ldur            x0, [fp, #-8]
    // 0x823c98: ldr             x1, [fp, #0x10]
    // 0x823c9c: StoreField: r1->field_23 = r0
    //     0x823c9c: stur            w0, [x1, #0x23]
    //     0x823ca0: ldurb           w16, [x1, #-1]
    //     0x823ca4: ldurb           w17, [x0, #-1]
    //     0x823ca8: and             x16, x17, x16, lsr #2
    //     0x823cac: tst             x16, HEAP, lsr #32
    //     0x823cb0: b.eq            #0x823cb8
    //     0x823cb4: bl              #0xd6826c
    // 0x823cb8: SaveReg r1
    //     0x823cb8: str             x1, [SP, #-8]!
    // 0x823cbc: r0 = notifyListeners()
    //     0x823cbc: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x823cc0: add             SP, SP, #8
    // 0x823cc4: ldur            x1, [fp, #-8]
    // 0x823cc8: LoadField: r2 = r1->field_b
    //     0x823cc8: ldur            w2, [x1, #0xb]
    // 0x823ccc: DecompressPointer r2
    //     0x823ccc: add             x2, x2, HEAP, lsl #32
    // 0x823cd0: LoadField: r0 = r2->field_b
    //     0x823cd0: ldur            w0, [x2, #0xb]
    // 0x823cd4: DecompressPointer r0
    //     0x823cd4: add             x0, x0, HEAP, lsl #32
    // 0x823cd8: LeaveFrame
    //     0x823cd8: mov             SP, fp
    //     0x823cdc: ldp             fp, lr, [SP], #0x10
    // 0x823ce0: ret
    //     0x823ce0: ret             
    // 0x823ce4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x823ce4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x823ce8: b               #0x823c80
  }
}

// class id: 4880, size: 0x10, field offset: 0x8
abstract class IndexControllerEventBase extends Object {

  _ IndexControllerEventBase(/* No info */) {
    // ** addr: 0x797940, size: 0xa8
    // 0x797940: EnterFrame
    //     0x797940: stp             fp, lr, [SP, #-0x10]!
    //     0x797944: mov             fp, SP
    // 0x797948: AllocStack(0x8)
    //     0x797948: sub             SP, SP, #8
    // 0x79794c: CheckStackOverflow
    //     0x79794c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x797950: cmp             SP, x16
    //     0x797954: b.ls            #0x7979e0
    // 0x797958: r1 = <void?>
    //     0x797958: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x79795c: r0 = _Future()
    //     0x79795c: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x797960: mov             x1, x0
    // 0x797964: r0 = 0
    //     0x797964: mov             x0, #0
    // 0x797968: stur            x1, [fp, #-8]
    // 0x79796c: StoreField: r1->field_b = r0
    //     0x79796c: stur            x0, [x1, #0xb]
    // 0x797970: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x797970: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x797974: ldr             x0, [x0, #0xb58]
    //     0x797978: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x79797c: cmp             w0, w16
    //     0x797980: b.ne            #0x79798c
    //     0x797984: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x797988: bl              #0xd67d44
    // 0x79798c: mov             x1, x0
    // 0x797990: ldur            x0, [fp, #-8]
    // 0x797994: StoreField: r0->field_13 = r1
    //     0x797994: stur            w1, [x0, #0x13]
    // 0x797998: r1 = <void?>
    //     0x797998: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x79799c: r0 = _AsyncCompleter()
    //     0x79799c: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x7979a0: ldur            x1, [fp, #-8]
    // 0x7979a4: StoreField: r0->field_b = r1
    //     0x7979a4: stur            w1, [x0, #0xb]
    // 0x7979a8: ldr             x1, [fp, #0x10]
    // 0x7979ac: StoreField: r1->field_b = r0
    //     0x7979ac: stur            w0, [x1, #0xb]
    //     0x7979b0: ldurb           w16, [x1, #-1]
    //     0x7979b4: ldurb           w17, [x0, #-1]
    //     0x7979b8: and             x16, x17, x16, lsr #2
    //     0x7979bc: tst             x16, HEAP, lsr #32
    //     0x7979c0: b.eq            #0x7979c8
    //     0x7979c4: bl              #0xd6826c
    // 0x7979c8: r2 = true
    //     0x7979c8: add             x2, NULL, #0x20  ; true
    // 0x7979cc: StoreField: r1->field_7 = r2
    //     0x7979cc: stur            w2, [x1, #7]
    // 0x7979d0: r0 = Null
    //     0x7979d0: mov             x0, NULL
    // 0x7979d4: LeaveFrame
    //     0x7979d4: mov             SP, fp
    //     0x7979d8: ldp             fp, lr, [SP], #0x10
    // 0x7979dc: ret
    //     0x7979dc: ret             
    // 0x7979e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7979e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7979e4: b               #0x797958
  }
  _ complete(/* No info */) {
    // ** addr: 0x798668, size: 0x68
    // 0x798668: EnterFrame
    //     0x798668: stp             fp, lr, [SP, #-0x10]!
    //     0x79866c: mov             fp, SP
    // 0x798670: r0 = 30
    //     0x798670: mov             x0, #0x1e
    // 0x798674: CheckStackOverflow
    //     0x798674: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x798678: cmp             SP, x16
    //     0x79867c: b.ls            #0x7986c8
    // 0x798680: ldr             x1, [fp, #0x10]
    // 0x798684: LoadField: r2 = r1->field_b
    //     0x798684: ldur            w2, [x1, #0xb]
    // 0x798688: DecompressPointer r2
    //     0x798688: add             x2, x2, HEAP, lsl #32
    // 0x79868c: LoadField: r1 = r2->field_b
    //     0x79868c: ldur            w1, [x2, #0xb]
    // 0x798690: DecompressPointer r1
    //     0x798690: add             x1, x1, HEAP, lsl #32
    // 0x798694: LoadField: r3 = r1->field_b
    //     0x798694: ldur            x3, [x1, #0xb]
    // 0x798698: ubfx            x3, x3, #0, #0x20
    // 0x79869c: and             x1, x3, x0
    // 0x7986a0: ubfx            x1, x1, #0, #0x20
    // 0x7986a4: cbnz            x1, #0x7986b8
    // 0x7986a8: SaveReg r2
    //     0x7986a8: str             x2, [SP, #-8]!
    // 0x7986ac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7986ac: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7986b0: r0 = complete()
    //     0x7986b0: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x7986b4: add             SP, SP, #8
    // 0x7986b8: r0 = Null
    //     0x7986b8: mov             x0, NULL
    // 0x7986bc: LeaveFrame
    //     0x7986bc: mov             SP, fp
    //     0x7986c0: ldp             fp, lr, [SP], #0x10
    // 0x7986c4: ret
    //     0x7986c4: ret             
    // 0x7986c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7986c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7986cc: b               #0x798680
  }
  [closure] void complete(dynamic) {
    // ** addr: 0x798724, size: 0x48
    // 0x798724: EnterFrame
    //     0x798724: stp             fp, lr, [SP, #-0x10]!
    //     0x798728: mov             fp, SP
    // 0x79872c: ldr             x0, [fp, #0x10]
    // 0x798730: LoadField: r1 = r0->field_17
    //     0x798730: ldur            w1, [x0, #0x17]
    // 0x798734: DecompressPointer r1
    //     0x798734: add             x1, x1, HEAP, lsl #32
    // 0x798738: CheckStackOverflow
    //     0x798738: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79873c: cmp             SP, x16
    //     0x798740: b.ls            #0x798764
    // 0x798744: LoadField: r0 = r1->field_f
    //     0x798744: ldur            w0, [x1, #0xf]
    // 0x798748: DecompressPointer r0
    //     0x798748: add             x0, x0, HEAP, lsl #32
    // 0x79874c: SaveReg r0
    //     0x79874c: str             x0, [SP, #-8]!
    // 0x798750: r0 = complete()
    //     0x798750: bl              #0x798668  ; [package:card_swiper/src/transformer_page_view/index_controller.dart] IndexControllerEventBase::complete
    // 0x798754: add             SP, SP, #8
    // 0x798758: LeaveFrame
    //     0x798758: mov             SP, fp
    //     0x79875c: ldp             fp, lr, [SP], #0x10
    // 0x798760: ret
    //     0x798760: ret             
    // 0x798764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x798764: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x798768: b               #0x798744
  }
}

// class id: 4881, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class _NextIndexControllerEvent&IndexControllerEventBase&TargetedPositionControllerEvent extends IndexControllerEventBase
     with TargetedPositionControllerEvent {

  _ _NextIndexControllerEvent&IndexControllerEventBase&TargetedPositionControllerEvent(/* No info */) {
    // ** addr: 0x823d28, size: 0x3c
    // 0x823d28: EnterFrame
    //     0x823d28: stp             fp, lr, [SP, #-0x10]!
    //     0x823d2c: mov             fp, SP
    // 0x823d30: CheckStackOverflow
    //     0x823d30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823d34: cmp             SP, x16
    //     0x823d38: b.ls            #0x823d5c
    // 0x823d3c: ldr             x16, [fp, #0x10]
    // 0x823d40: SaveReg r16
    //     0x823d40: str             x16, [SP, #-8]!
    // 0x823d44: r0 = IndexControllerEventBase()
    //     0x823d44: bl              #0x797940  ; [package:card_swiper/src/transformer_page_view/index_controller.dart] IndexControllerEventBase::IndexControllerEventBase
    // 0x823d48: add             SP, SP, #8
    // 0x823d4c: r0 = Null
    //     0x823d4c: mov             x0, NULL
    // 0x823d50: LeaveFrame
    //     0x823d50: mov             SP, fp
    //     0x823d54: ldp             fp, lr, [SP], #0x10
    // 0x823d58: ret
    //     0x823d58: ret             
    // 0x823d5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x823d5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x823d60: b               #0x823d3c
  }
}

// class id: 4882, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class _NextIndexControllerEvent&IndexControllerEventBase&TargetedPositionControllerEvent&StepBasedIndexControllerEvent extends _NextIndexControllerEvent&IndexControllerEventBase&TargetedPositionControllerEvent
     with StepBasedIndexControllerEvent {

  _ calcNextIndex(/* No info */) {
    // ** addr: 0x7986d0, size: 0x54
    // 0x7986d0: ldr             x1, [SP, #0x18]
    // 0x7986d4: r2 = LoadInt32Instr(r1)
    //     0x7986d4: sbfx            x2, x1, #1, #0x1f
    //     0x7986d8: tbz             w1, #0, #0x7986e0
    //     0x7986dc: ldur            x2, [x1, #7]
    // 0x7986e0: add             x1, x2, #1
    // 0x7986e4: ldr             x2, [SP, #8]
    // 0x7986e8: tbz             w2, #4, #0x79871c
    // 0x7986ec: ldr             x2, [SP, #0x10]
    // 0x7986f0: cmp             x1, x2
    // 0x7986f4: b.lt            #0x798700
    // 0x7986f8: r2 = 0
    //     0x7986f8: mov             x2, #0
    // 0x7986fc: b               #0x798714
    // 0x798700: tbz             x1, #0x3f, #0x798710
    // 0x798704: sub             x3, x2, #1
    // 0x798708: mov             x2, x3
    // 0x79870c: b               #0x798714
    // 0x798710: mov             x2, x1
    // 0x798714: mov             x0, x2
    // 0x798718: b               #0x798720
    // 0x79871c: mov             x0, x1
    // 0x798720: ret
    //     0x798720: ret             
  }
}

// class id: 4883, size: 0x10, field offset: 0x10
class NextIndexControllerEvent extends _NextIndexControllerEvent&IndexControllerEventBase&TargetedPositionControllerEvent&StepBasedIndexControllerEvent {

  _ NextIndexControllerEvent(/* No info */) {
    // ** addr: 0x823cec, size: 0x3c
    // 0x823cec: EnterFrame
    //     0x823cec: stp             fp, lr, [SP, #-0x10]!
    //     0x823cf0: mov             fp, SP
    // 0x823cf4: CheckStackOverflow
    //     0x823cf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823cf8: cmp             SP, x16
    //     0x823cfc: b.ls            #0x823d20
    // 0x823d00: ldr             x16, [fp, #0x10]
    // 0x823d04: SaveReg r16
    //     0x823d04: str             x16, [SP, #-8]!
    // 0x823d08: r0 = _NextIndexControllerEvent&IndexControllerEventBase&TargetedPositionControllerEvent()
    //     0x823d08: bl              #0x823d28  ; [package:card_swiper/src/transformer_page_view/index_controller.dart] _NextIndexControllerEvent&IndexControllerEventBase&TargetedPositionControllerEvent::_NextIndexControllerEvent&IndexControllerEventBase&TargetedPositionControllerEvent
    // 0x823d0c: add             SP, SP, #8
    // 0x823d10: r0 = Null
    //     0x823d10: mov             x0, NULL
    // 0x823d14: LeaveFrame
    //     0x823d14: mov             SP, fp
    //     0x823d18: ldp             fp, lr, [SP], #0x10
    // 0x823d1c: ret
    //     0x823d1c: ret             
    // 0x823d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x823d20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x823d24: b               #0x823d00
  }
}

// class id: 4884, size: 0x10, field offset: 0x10
abstract class TargetedPositionControllerEvent extends IndexControllerEventBase {
}

// class id: 4885, size: 0x10, field offset: 0x10
abstract class StepBasedIndexControllerEvent extends TargetedPositionControllerEvent {
}

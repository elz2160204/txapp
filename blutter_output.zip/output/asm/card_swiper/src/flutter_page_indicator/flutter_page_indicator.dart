// lib: flutter_page_indicator, url: package:card_swiper/src/flutter_page_indicator/flutter_page_indicator.dart

// class id: 1048730, size: 0x8
class :: {
}

// class id: 6017, size: 0x14, field offset: 0x14
enum PageIndicatorLayout extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb151c4, size: 0x5c
    // 0xb151c4: EnterFrame
    //     0xb151c4: stp             fp, lr, [SP, #-0x10]!
    //     0xb151c8: mov             fp, SP
    // 0xb151cc: CheckStackOverflow
    //     0xb151cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb151d0: cmp             SP, x16
    //     0xb151d4: b.ls            #0xb15218
    // 0xb151d8: r1 = Null
    //     0xb151d8: mov             x1, NULL
    // 0xb151dc: r2 = 4
    //     0xb151dc: mov             x2, #4
    // 0xb151e0: r0 = AllocateArray()
    //     0xb151e0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb151e4: r17 = "PageIndicatorLayout."
    //     0xb151e4: add             x17, PP, #0x22, lsl #12  ; [pp+0x22980] "PageIndicatorLayout."
    //     0xb151e8: ldr             x17, [x17, #0x980]
    // 0xb151ec: StoreField: r0->field_f = r17
    //     0xb151ec: stur            w17, [x0, #0xf]
    // 0xb151f0: ldr             x1, [fp, #0x10]
    // 0xb151f4: LoadField: r2 = r1->field_f
    //     0xb151f4: ldur            w2, [x1, #0xf]
    // 0xb151f8: DecompressPointer r2
    //     0xb151f8: add             x2, x2, HEAP, lsl #32
    // 0xb151fc: StoreField: r0->field_13 = r2
    //     0xb151fc: stur            w2, [x0, #0x13]
    // 0xb15200: SaveReg r0
    //     0xb15200: str             x0, [SP, #-8]!
    // 0xb15204: r0 = _interpolate()
    //     0xb15204: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15208: add             SP, SP, #8
    // 0xb1520c: LeaveFrame
    //     0xb1520c: mov             SP, fp
    //     0xb15210: ldp             fp, lr, [SP], #0x10
    // 0xb15214: ret
    //     0xb15214: ret             
    // 0xb15218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1521c: b               #0xb151d8
  }
}

// lib: , url: package:card_swiper/src/swiper_plugin.dart

// class id: 1048735, size: 0x8
class :: {
}

// class id: 4876, size: 0x2c, field offset: 0x8
//   const constructor, 
class SwiperPluginConfig extends Object {
}

// class id: 4877, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SwiperPlugin extends Object {
}

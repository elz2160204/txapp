// lib: , url: package:card_swiper/src/swiper.dart

// class id: 1048731, size: 0x8
class :: {
}

// class id: 3416, size: 0x1c, field offset: 0x14
abstract class _SwiperTimerMixin extends State<Swiper> {

  late SwiperController _controller; // offset: 0x18

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7977ac, size: 0xdc
    // 0x7977ac: EnterFrame
    //     0x7977ac: stp             fp, lr, [SP, #-0x10]!
    //     0x7977b0: mov             fp, SP
    // 0x7977b4: CheckStackOverflow
    //     0x7977b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7977b8: cmp             SP, x16
    //     0x7977bc: b.ls            #0x797870
    // 0x7977c0: ldr             x3, [fp, #0x18]
    // 0x7977c4: LoadField: r2 = r3->field_7
    //     0x7977c4: ldur            w2, [x3, #7]
    // 0x7977c8: DecompressPointer r2
    //     0x7977c8: add             x2, x2, HEAP, lsl #32
    // 0x7977cc: ldr             x0, [fp, #0x10]
    // 0x7977d0: r1 = Null
    //     0x7977d0: mov             x1, NULL
    // 0x7977d4: cmp             w2, NULL
    // 0x7977d8: b.eq            #0x7977fc
    // 0x7977dc: LoadField: r4 = r2->field_17
    //     0x7977dc: ldur            w4, [x2, #0x17]
    // 0x7977e0: DecompressPointer r4
    //     0x7977e0: add             x4, x4, HEAP, lsl #32
    // 0x7977e4: r8 = X0 bound StatefulWidget
    //     0x7977e4: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7977e8: ldr             x8, [x8, #0x858]
    // 0x7977ec: LoadField: r9 = r4->field_7
    //     0x7977ec: ldur            x9, [x4, #7]
    // 0x7977f0: r3 = Null
    //     0x7977f0: add             x3, PP, #0x29, lsl #12  ; [pp+0x29400] Null
    //     0x7977f4: ldr             x3, [x3, #0x400]
    // 0x7977f8: blr             x9
    // 0x7977fc: ldr             x0, [fp, #0x18]
    // 0x797800: LoadField: r1 = r0->field_17
    //     0x797800: ldur            w1, [x0, #0x17]
    // 0x797804: DecompressPointer r1
    //     0x797804: add             x1, x1, HEAP, lsl #32
    // 0x797808: r16 = Sentinel
    //     0x797808: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79780c: cmp             w1, w16
    // 0x797810: b.eq            #0x797878
    // 0x797814: LoadField: r2 = r0->field_b
    //     0x797814: ldur            w2, [x0, #0xb]
    // 0x797818: DecompressPointer r2
    //     0x797818: add             x2, x2, HEAP, lsl #32
    // 0x79781c: cmp             w2, NULL
    // 0x797820: b.eq            #0x797884
    // 0x797824: LoadField: r0 = r2->field_33
    //     0x797824: ldur            w0, [x2, #0x33]
    // 0x797828: DecompressPointer r0
    //     0x797828: add             x0, x0, HEAP, lsl #32
    // 0x79782c: ldr             x2, [fp, #0x10]
    // 0x797830: LoadField: r3 = r2->field_33
    //     0x797830: ldur            w3, [x2, #0x33]
    // 0x797834: DecompressPointer r3
    //     0x797834: add             x3, x3, HEAP, lsl #32
    // 0x797838: cmp             w0, w3
    // 0x79783c: b.eq            #0x797860
    // 0x797840: tbnz            w0, #4, #0x797854
    // 0x797844: SaveReg r1
    //     0x797844: str             x1, [SP, #-8]!
    // 0x797848: r0 = startAutoplay()
    //     0x797848: bl              #0x7979f4  ; [package:card_swiper/src/swiper_controller.dart] SwiperController::startAutoplay
    // 0x79784c: add             SP, SP, #8
    // 0x797850: b               #0x797860
    // 0x797854: SaveReg r1
    //     0x797854: str             x1, [SP, #-8]!
    // 0x797858: r0 = stopAutoplay()
    //     0x797858: bl              #0x797888  ; [package:card_swiper/src/swiper_controller.dart] SwiperController::stopAutoplay
    // 0x79785c: add             SP, SP, #8
    // 0x797860: r0 = Null
    //     0x797860: mov             x0, NULL
    // 0x797864: LeaveFrame
    //     0x797864: mov             SP, fp
    //     0x797868: ldp             fp, lr, [SP], #0x10
    // 0x79786c: ret
    //     0x79786c: ret             
    // 0x797870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x797870: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x797874: b               #0x7977c0
    // 0x797878: r9 = _controller
    //     0x797878: add             x9, PP, #0x29, lsl #12  ; [pp+0x293a8] Field <_SwiperTimerMixin@199212615._controller@199212615>: late (offset: 0x18)
    //     0x79787c: ldr             x9, [x9, #0x3a8]
    // 0x797880: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x797880: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x797884: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x797884: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _startAutoplay(/* No info */) {
    // ** addr: 0x823aec, size: 0xd4
    // 0x823aec: EnterFrame
    //     0x823aec: stp             fp, lr, [SP, #-0x10]!
    //     0x823af0: mov             fp, SP
    // 0x823af4: AllocStack(0x10)
    //     0x823af4: sub             SP, SP, #0x10
    // 0x823af8: CheckStackOverflow
    //     0x823af8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823afc: cmp             SP, x16
    //     0x823b00: b.ls            #0x823bb4
    // 0x823b04: ldr             x16, [fp, #0x10]
    // 0x823b08: SaveReg r16
    //     0x823b08: str             x16, [SP, #-8]!
    // 0x823b0c: r0 = _stopAutoplay()
    //     0x823b0c: bl              #0x823d70  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_stopAutoplay
    // 0x823b10: add             SP, SP, #8
    // 0x823b14: ldr             x0, [fp, #0x10]
    // 0x823b18: LoadField: r1 = r0->field_b
    //     0x823b18: ldur            w1, [x0, #0xb]
    // 0x823b1c: DecompressPointer r1
    //     0x823b1c: add             x1, x1, HEAP, lsl #32
    // 0x823b20: cmp             w1, NULL
    // 0x823b24: b.eq            #0x823bbc
    // 0x823b28: LoadField: r2 = r1->field_37
    //     0x823b28: ldur            x2, [x1, #0x37]
    // 0x823b2c: r16 = 1000
    //     0x823b2c: mov             x16, #0x3e8
    // 0x823b30: mul             x1, x2, x16
    // 0x823b34: stur            x1, [fp, #-8]
    // 0x823b38: r0 = Duration()
    //     0x823b38: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x823b3c: mov             x1, x0
    // 0x823b40: ldur            x0, [fp, #-8]
    // 0x823b44: stur            x1, [fp, #-0x10]
    // 0x823b48: StoreField: r1->field_7 = r0
    //     0x823b48: stur            x0, [x1, #7]
    // 0x823b4c: r1 = 1
    //     0x823b4c: mov             x1, #1
    // 0x823b50: r0 = AllocateContext()
    //     0x823b50: bl              #0xd68aa4  ; AllocateContextStub
    // 0x823b54: mov             x1, x0
    // 0x823b58: ldr             x0, [fp, #0x10]
    // 0x823b5c: StoreField: r1->field_f = r0
    //     0x823b5c: stur            w0, [x1, #0xf]
    // 0x823b60: mov             x2, x1
    // 0x823b64: r1 = Function '_onTimer@199212615':.
    //     0x823b64: add             x1, PP, #0x29, lsl #12  ; [pp+0x293c8] AnonymousClosure: (0x823bc0), in [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_onTimer (0x823c0c)
    //     0x823b68: ldr             x1, [x1, #0x3c8]
    // 0x823b6c: r0 = AllocateClosure()
    //     0x823b6c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x823b70: ldur            x16, [fp, #-0x10]
    // 0x823b74: stp             x16, NULL, [SP, #-0x10]!
    // 0x823b78: SaveReg r0
    //     0x823b78: str             x0, [SP, #-8]!
    // 0x823b7c: r0 = Timer.periodic()
    //     0x823b7c: bl              #0x5e7588  ; [dart:async] Timer::Timer.periodic
    // 0x823b80: add             SP, SP, #0x18
    // 0x823b84: ldr             x1, [fp, #0x10]
    // 0x823b88: StoreField: r1->field_13 = r0
    //     0x823b88: stur            w0, [x1, #0x13]
    //     0x823b8c: ldurb           w16, [x1, #-1]
    //     0x823b90: ldurb           w17, [x0, #-1]
    //     0x823b94: and             x16, x17, x16, lsr #2
    //     0x823b98: tst             x16, HEAP, lsr #32
    //     0x823b9c: b.eq            #0x823ba4
    //     0x823ba0: bl              #0xd6826c
    // 0x823ba4: r0 = Null
    //     0x823ba4: mov             x0, NULL
    // 0x823ba8: LeaveFrame
    //     0x823ba8: mov             SP, fp
    //     0x823bac: ldp             fp, lr, [SP], #0x10
    // 0x823bb0: ret
    //     0x823bb0: ret             
    // 0x823bb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x823bb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x823bb8: b               #0x823b04
    // 0x823bbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x823bbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onTimer(dynamic, Timer) {
    // ** addr: 0x823bc0, size: 0x4c
    // 0x823bc0: EnterFrame
    //     0x823bc0: stp             fp, lr, [SP, #-0x10]!
    //     0x823bc4: mov             fp, SP
    // 0x823bc8: ldr             x0, [fp, #0x18]
    // 0x823bcc: LoadField: r1 = r0->field_17
    //     0x823bcc: ldur            w1, [x0, #0x17]
    // 0x823bd0: DecompressPointer r1
    //     0x823bd0: add             x1, x1, HEAP, lsl #32
    // 0x823bd4: CheckStackOverflow
    //     0x823bd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823bd8: cmp             SP, x16
    //     0x823bdc: b.ls            #0x823c04
    // 0x823be0: LoadField: r0 = r1->field_f
    //     0x823be0: ldur            w0, [x1, #0xf]
    // 0x823be4: DecompressPointer r0
    //     0x823be4: add             x0, x0, HEAP, lsl #32
    // 0x823be8: ldr             x16, [fp, #0x10]
    // 0x823bec: stp             x16, x0, [SP, #-0x10]!
    // 0x823bf0: r0 = _onTimer()
    //     0x823bf0: bl              #0x823c0c  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_onTimer
    // 0x823bf4: add             SP, SP, #0x10
    // 0x823bf8: LeaveFrame
    //     0x823bf8: mov             SP, fp
    //     0x823bfc: ldp             fp, lr, [SP], #0x10
    // 0x823c00: ret
    //     0x823c00: ret             
    // 0x823c04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x823c04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x823c08: b               #0x823be0
  }
  _ _onTimer(/* No info */) {
    // ** addr: 0x823c0c, size: 0x5c
    // 0x823c0c: EnterFrame
    //     0x823c0c: stp             fp, lr, [SP, #-0x10]!
    //     0x823c10: mov             fp, SP
    // 0x823c14: CheckStackOverflow
    //     0x823c14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823c18: cmp             SP, x16
    //     0x823c1c: b.ls            #0x823c54
    // 0x823c20: ldr             x0, [fp, #0x18]
    // 0x823c24: LoadField: r1 = r0->field_17
    //     0x823c24: ldur            w1, [x0, #0x17]
    // 0x823c28: DecompressPointer r1
    //     0x823c28: add             x1, x1, HEAP, lsl #32
    // 0x823c2c: r16 = Sentinel
    //     0x823c2c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x823c30: cmp             w1, w16
    // 0x823c34: b.eq            #0x823c5c
    // 0x823c38: SaveReg r1
    //     0x823c38: str             x1, [SP, #-8]!
    // 0x823c3c: r0 = next()
    //     0x823c3c: bl              #0x823c68  ; [package:card_swiper/src/transformer_page_view/index_controller.dart] IndexController::next
    // 0x823c40: add             SP, SP, #8
    // 0x823c44: r0 = Null
    //     0x823c44: mov             x0, NULL
    // 0x823c48: LeaveFrame
    //     0x823c48: mov             SP, fp
    //     0x823c4c: ldp             fp, lr, [SP], #0x10
    // 0x823c50: ret
    //     0x823c50: ret             
    // 0x823c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x823c54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x823c58: b               #0x823c20
    // 0x823c5c: r9 = _controller
    //     0x823c5c: add             x9, PP, #0x29, lsl #12  ; [pp+0x293a8] Field <_SwiperTimerMixin@199212615._controller@199212615>: late (offset: 0x18)
    //     0x823c60: ldr             x9, [x9, #0x3a8]
    // 0x823c64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x823c64: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _stopAutoplay(/* No info */) {
    // ** addr: 0x823d70, size: 0x5c
    // 0x823d70: EnterFrame
    //     0x823d70: stp             fp, lr, [SP, #-0x10]!
    //     0x823d74: mov             fp, SP
    // 0x823d78: CheckStackOverflow
    //     0x823d78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823d7c: cmp             SP, x16
    //     0x823d80: b.ls            #0x823dc4
    // 0x823d84: ldr             x0, [fp, #0x10]
    // 0x823d88: LoadField: r1 = r0->field_13
    //     0x823d88: ldur            w1, [x0, #0x13]
    // 0x823d8c: DecompressPointer r1
    //     0x823d8c: add             x1, x1, HEAP, lsl #32
    // 0x823d90: cmp             w1, NULL
    // 0x823d94: b.ne            #0x823da0
    // 0x823d98: mov             x1, x0
    // 0x823d9c: b               #0x823db0
    // 0x823da0: SaveReg r1
    //     0x823da0: str             x1, [SP, #-8]!
    // 0x823da4: r0 = cancel()
    //     0x823da4: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x823da8: add             SP, SP, #8
    // 0x823dac: ldr             x1, [fp, #0x10]
    // 0x823db0: StoreField: r1->field_13 = rNULL
    //     0x823db0: stur            NULL, [x1, #0x13]
    // 0x823db4: r0 = Null
    //     0x823db4: mov             x0, NULL
    // 0x823db8: LeaveFrame
    //     0x823db8: mov             SP, fp
    //     0x823dbc: ldp             fp, lr, [SP], #0x10
    // 0x823dc0: ret
    //     0x823dc0: ret             
    // 0x823dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x823dc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x823dc8: b               #0x823d84
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d4efc, size: 0x130
    // 0x9d4efc: EnterFrame
    //     0x9d4efc: stp             fp, lr, [SP, #-0x10]!
    //     0x9d4f00: mov             fp, SP
    // 0x9d4f04: AllocStack(0x8)
    //     0x9d4f04: sub             SP, SP, #8
    // 0x9d4f08: CheckStackOverflow
    //     0x9d4f08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d4f0c: cmp             SP, x16
    //     0x9d4f10: b.ls            #0x9d501c
    // 0x9d4f14: ldr             x0, [fp, #0x10]
    // 0x9d4f18: LoadField: r1 = r0->field_b
    //     0x9d4f18: ldur            w1, [x0, #0xb]
    // 0x9d4f1c: DecompressPointer r1
    //     0x9d4f1c: add             x1, x1, HEAP, lsl #32
    // 0x9d4f20: cmp             w1, NULL
    // 0x9d4f24: b.eq            #0x9d5024
    // 0x9d4f28: r0 = SwiperController()
    //     0x9d4f28: bl              #0x9d502c  ; AllocateSwiperControllerStub -> SwiperController (size=0x28)
    // 0x9d4f2c: mov             x1, x0
    // 0x9d4f30: r0 = 0
    //     0x9d4f30: mov             x0, #0
    // 0x9d4f34: stur            x1, [fp, #-8]
    // 0x9d4f38: StoreField: r1->field_7 = r0
    //     0x9d4f38: stur            x0, [x1, #7]
    // 0x9d4f3c: StoreField: r1->field_13 = r0
    //     0x9d4f3c: stur            x0, [x1, #0x13]
    // 0x9d4f40: StoreField: r1->field_1b = r0
    //     0x9d4f40: stur            x0, [x1, #0x1b]
    // 0x9d4f44: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x9d4f44: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9d4f48: ldr             x0, [x0, #0x1580]
    //     0x9d4f4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9d4f50: cmp             w0, w16
    //     0x9d4f54: b.ne            #0x9d4f60
    //     0x9d4f58: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x9d4f5c: bl              #0xd67cdc
    // 0x9d4f60: ldur            x1, [fp, #-8]
    // 0x9d4f64: StoreField: r1->field_f = r0
    //     0x9d4f64: stur            w0, [x1, #0xf]
    // 0x9d4f68: mov             x0, x1
    // 0x9d4f6c: ldr             x2, [fp, #0x10]
    // 0x9d4f70: StoreField: r2->field_17 = r0
    //     0x9d4f70: stur            w0, [x2, #0x17]
    //     0x9d4f74: ldurb           w16, [x2, #-1]
    //     0x9d4f78: ldurb           w17, [x0, #-1]
    //     0x9d4f7c: and             x16, x17, x16, lsr #2
    //     0x9d4f80: tst             x16, HEAP, lsr #32
    //     0x9d4f84: b.eq            #0x9d4f8c
    //     0x9d4f88: bl              #0xd6828c
    // 0x9d4f8c: r1 = 1
    //     0x9d4f8c: mov             x1, #1
    // 0x9d4f90: r0 = AllocateContext()
    //     0x9d4f90: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d4f94: mov             x1, x0
    // 0x9d4f98: ldr             x0, [fp, #0x10]
    // 0x9d4f9c: StoreField: r1->field_f = r0
    //     0x9d4f9c: stur            w0, [x1, #0xf]
    // 0x9d4fa0: mov             x2, x1
    // 0x9d4fa4: r1 = Function '_onController@199212615':.
    //     0x9d4fa4: add             x1, PP, #0x29, lsl #12  ; [pp+0x293f8] AnonymousClosure: (0x9d5038), in [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_onController (0x9d5080)
    //     0x9d4fa8: ldr             x1, [x1, #0x3f8]
    // 0x9d4fac: r0 = AllocateClosure()
    //     0x9d4fac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d4fb0: ldur            x16, [fp, #-8]
    // 0x9d4fb4: stp             x0, x16, [SP, #-0x10]!
    // 0x9d4fb8: r0 = addListener()
    //     0x9d4fb8: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9d4fbc: add             SP, SP, #0x10
    // 0x9d4fc0: ldr             x0, [fp, #0x10]
    // 0x9d4fc4: LoadField: r1 = r0->field_b
    //     0x9d4fc4: ldur            w1, [x0, #0xb]
    // 0x9d4fc8: DecompressPointer r1
    //     0x9d4fc8: add             x1, x1, HEAP, lsl #32
    // 0x9d4fcc: cmp             w1, NULL
    // 0x9d4fd0: b.eq            #0x9d5028
    // 0x9d4fd4: LoadField: r2 = r1->field_33
    //     0x9d4fd4: ldur            w2, [x1, #0x33]
    // 0x9d4fd8: DecompressPointer r2
    //     0x9d4fd8: add             x2, x2, HEAP, lsl #32
    // 0x9d4fdc: tbnz            w2, #4, #0x9d4ff8
    // 0x9d4fe0: LoadField: r1 = r0->field_17
    //     0x9d4fe0: ldur            w1, [x0, #0x17]
    // 0x9d4fe4: DecompressPointer r1
    //     0x9d4fe4: add             x1, x1, HEAP, lsl #32
    // 0x9d4fe8: SaveReg r1
    //     0x9d4fe8: str             x1, [SP, #-8]!
    // 0x9d4fec: r0 = startAutoplay()
    //     0x9d4fec: bl              #0x7979f4  ; [package:card_swiper/src/swiper_controller.dart] SwiperController::startAutoplay
    // 0x9d4ff0: add             SP, SP, #8
    // 0x9d4ff4: b               #0x9d500c
    // 0x9d4ff8: LoadField: r1 = r0->field_17
    //     0x9d4ff8: ldur            w1, [x0, #0x17]
    // 0x9d4ffc: DecompressPointer r1
    //     0x9d4ffc: add             x1, x1, HEAP, lsl #32
    // 0x9d5000: SaveReg r1
    //     0x9d5000: str             x1, [SP, #-8]!
    // 0x9d5004: r0 = stopAutoplay()
    //     0x9d5004: bl              #0x797888  ; [package:card_swiper/src/swiper_controller.dart] SwiperController::stopAutoplay
    // 0x9d5008: add             SP, SP, #8
    // 0x9d500c: r0 = Null
    //     0x9d500c: mov             x0, NULL
    // 0x9d5010: LeaveFrame
    //     0x9d5010: mov             SP, fp
    //     0x9d5014: ldp             fp, lr, [SP], #0x10
    // 0x9d5018: ret
    //     0x9d5018: ret             
    // 0x9d501c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d501c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d5020: b               #0x9d4f14
    // 0x9d5024: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d5024: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d5028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d5028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onController(dynamic) {
    // ** addr: 0x9d5038, size: 0x48
    // 0x9d5038: EnterFrame
    //     0x9d5038: stp             fp, lr, [SP, #-0x10]!
    //     0x9d503c: mov             fp, SP
    // 0x9d5040: ldr             x0, [fp, #0x10]
    // 0x9d5044: LoadField: r1 = r0->field_17
    //     0x9d5044: ldur            w1, [x0, #0x17]
    // 0x9d5048: DecompressPointer r1
    //     0x9d5048: add             x1, x1, HEAP, lsl #32
    // 0x9d504c: CheckStackOverflow
    //     0x9d504c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d5050: cmp             SP, x16
    //     0x9d5054: b.ls            #0x9d5078
    // 0x9d5058: LoadField: r0 = r1->field_f
    //     0x9d5058: ldur            w0, [x1, #0xf]
    // 0x9d505c: DecompressPointer r0
    //     0x9d505c: add             x0, x0, HEAP, lsl #32
    // 0x9d5060: SaveReg r0
    //     0x9d5060: str             x0, [SP, #-8]!
    // 0x9d5064: r0 = _onController()
    //     0x9d5064: bl              #0x9d5080  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_onController
    // 0x9d5068: add             SP, SP, #8
    // 0x9d506c: LeaveFrame
    //     0x9d506c: mov             SP, fp
    //     0x9d5070: ldp             fp, lr, [SP], #0x10
    // 0x9d5074: ret
    //     0x9d5074: ret             
    // 0x9d5078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d5078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d507c: b               #0x9d5058
  }
  _ _onController(/* No info */) {
    // ** addr: 0x9d5080, size: 0xa8
    // 0x9d5080: EnterFrame
    //     0x9d5080: stp             fp, lr, [SP, #-0x10]!
    //     0x9d5084: mov             fp, SP
    // 0x9d5088: CheckStackOverflow
    //     0x9d5088: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d508c: cmp             SP, x16
    //     0x9d5090: b.ls            #0x9d5114
    // 0x9d5094: ldr             x0, [fp, #0x10]
    // 0x9d5098: LoadField: r1 = r0->field_17
    //     0x9d5098: ldur            w1, [x0, #0x17]
    // 0x9d509c: DecompressPointer r1
    //     0x9d509c: add             x1, x1, HEAP, lsl #32
    // 0x9d50a0: r16 = Sentinel
    //     0x9d50a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d50a4: cmp             w1, w16
    // 0x9d50a8: b.eq            #0x9d511c
    // 0x9d50ac: LoadField: r2 = r1->field_23
    //     0x9d50ac: ldur            w2, [x1, #0x23]
    // 0x9d50b0: DecompressPointer r2
    //     0x9d50b0: add             x2, x2, HEAP, lsl #32
    // 0x9d50b4: r1 = LoadClassIdInstr(r2)
    //     0x9d50b4: ldur            x1, [x2, #-1]
    //     0x9d50b8: ubfx            x1, x1, #0xc, #0x14
    // 0x9d50bc: lsl             x1, x1, #1
    // 0x9d50c0: r17 = 9772
    //     0x9d50c0: mov             x17, #0x262c
    // 0x9d50c4: cmp             w1, w17
    // 0x9d50c8: b.ne            #0x9d5104
    // 0x9d50cc: LoadField: r1 = r2->field_f
    //     0x9d50cc: ldur            w1, [x2, #0xf]
    // 0x9d50d0: DecompressPointer r1
    //     0x9d50d0: add             x1, x1, HEAP, lsl #32
    // 0x9d50d4: tbnz            w1, #4, #0x9d50f8
    // 0x9d50d8: LoadField: r1 = r0->field_13
    //     0x9d50d8: ldur            w1, [x0, #0x13]
    // 0x9d50dc: DecompressPointer r1
    //     0x9d50dc: add             x1, x1, HEAP, lsl #32
    // 0x9d50e0: cmp             w1, NULL
    // 0x9d50e4: b.ne            #0x9d5104
    // 0x9d50e8: SaveReg r0
    //     0x9d50e8: str             x0, [SP, #-8]!
    // 0x9d50ec: r0 = _startAutoplay()
    //     0x9d50ec: bl              #0x823aec  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_startAutoplay
    // 0x9d50f0: add             SP, SP, #8
    // 0x9d50f4: b               #0x9d5104
    // 0x9d50f8: SaveReg r0
    //     0x9d50f8: str             x0, [SP, #-8]!
    // 0x9d50fc: r0 = _stopAutoplay()
    //     0x9d50fc: bl              #0x823d70  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_stopAutoplay
    // 0x9d5100: add             SP, SP, #8
    // 0x9d5104: r0 = Null
    //     0x9d5104: mov             x0, NULL
    // 0x9d5108: LeaveFrame
    //     0x9d5108: mov             SP, fp
    //     0x9d510c: ldp             fp, lr, [SP], #0x10
    // 0x9d5110: ret
    //     0x9d5110: ret             
    // 0x9d5114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d5114: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d5118: b               #0x9d5094
    // 0x9d511c: r9 = _controller
    //     0x9d511c: add             x9, PP, #0x29, lsl #12  ; [pp+0x293a8] Field <_SwiperTimerMixin@199212615._controller@199212615>: late (offset: 0x18)
    //     0x9d5120: ldr             x9, [x9, #0x3a8]
    // 0x9d5124: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9d5124: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa49f88, size: 0x18
    // 0xa49f88: r4 = 7
    //     0xa49f88: mov             x4, #7
    // 0xa49f8c: r1 = Function 'dispose':.
    //     0xa49f8c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca60] AnonymousClosure: (0xa49fa0), in [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::dispose (0xa4e778)
    //     0xa49f90: ldr             x1, [x17, #0xa60]
    // 0xa49f94: r24 = BuildNonGenericMethodExtractorStub
    //     0xa49f94: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa49f98: LoadField: r0 = r24->field_17
    //     0xa49f98: ldur            x0, [x24, #0x17]
    // 0xa49f9c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa49fa0, size: 0x48
    // 0xa49fa0: EnterFrame
    //     0xa49fa0: stp             fp, lr, [SP, #-0x10]!
    //     0xa49fa4: mov             fp, SP
    // 0xa49fa8: ldr             x0, [fp, #0x10]
    // 0xa49fac: LoadField: r1 = r0->field_17
    //     0xa49fac: ldur            w1, [x0, #0x17]
    // 0xa49fb0: DecompressPointer r1
    //     0xa49fb0: add             x1, x1, HEAP, lsl #32
    // 0xa49fb4: CheckStackOverflow
    //     0xa49fb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa49fb8: cmp             SP, x16
    //     0xa49fbc: b.ls            #0xa49fe0
    // 0xa49fc0: LoadField: r0 = r1->field_f
    //     0xa49fc0: ldur            w0, [x1, #0xf]
    // 0xa49fc4: DecompressPointer r0
    //     0xa49fc4: add             x0, x0, HEAP, lsl #32
    // 0xa49fc8: SaveReg r0
    //     0xa49fc8: str             x0, [SP, #-8]!
    // 0xa49fcc: r0 = dispose()
    //     0xa49fcc: bl              #0xa4e778  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::dispose
    // 0xa49fd0: add             SP, SP, #8
    // 0xa49fd4: LeaveFrame
    //     0xa49fd4: mov             SP, fp
    //     0xa49fd8: ldp             fp, lr, [SP], #0x10
    // 0xa49fdc: ret
    //     0xa49fdc: ret             
    // 0xa49fe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa49fe0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa49fe4: b               #0xa49fc0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4e778, size: 0x9c
    // 0xa4e778: EnterFrame
    //     0xa4e778: stp             fp, lr, [SP, #-0x10]!
    //     0xa4e77c: mov             fp, SP
    // 0xa4e780: AllocStack(0x8)
    //     0xa4e780: sub             SP, SP, #8
    // 0xa4e784: CheckStackOverflow
    //     0xa4e784: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4e788: cmp             SP, x16
    //     0xa4e78c: b.ls            #0xa4e800
    // 0xa4e790: ldr             x0, [fp, #0x10]
    // 0xa4e794: LoadField: r1 = r0->field_17
    //     0xa4e794: ldur            w1, [x0, #0x17]
    // 0xa4e798: DecompressPointer r1
    //     0xa4e798: add             x1, x1, HEAP, lsl #32
    // 0xa4e79c: r16 = Sentinel
    //     0xa4e79c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4e7a0: cmp             w1, w16
    // 0xa4e7a4: b.eq            #0xa4e808
    // 0xa4e7a8: stur            x1, [fp, #-8]
    // 0xa4e7ac: r1 = 1
    //     0xa4e7ac: mov             x1, #1
    // 0xa4e7b0: r0 = AllocateContext()
    //     0xa4e7b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4e7b4: mov             x1, x0
    // 0xa4e7b8: ldr             x0, [fp, #0x10]
    // 0xa4e7bc: StoreField: r1->field_f = r0
    //     0xa4e7bc: stur            w0, [x1, #0xf]
    // 0xa4e7c0: mov             x2, x1
    // 0xa4e7c4: r1 = Function '_onController@199212615':.
    //     0xa4e7c4: add             x1, PP, #0x29, lsl #12  ; [pp+0x293f8] AnonymousClosure: (0x9d5038), in [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_onController (0x9d5080)
    //     0xa4e7c8: ldr             x1, [x1, #0x3f8]
    // 0xa4e7cc: r0 = AllocateClosure()
    //     0xa4e7cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4e7d0: ldur            x16, [fp, #-8]
    // 0xa4e7d4: stp             x0, x16, [SP, #-0x10]!
    // 0xa4e7d8: r0 = removeListener()
    //     0xa4e7d8: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4e7dc: add             SP, SP, #0x10
    // 0xa4e7e0: ldr             x16, [fp, #0x10]
    // 0xa4e7e4: SaveReg r16
    //     0xa4e7e4: str             x16, [SP, #-8]!
    // 0xa4e7e8: r0 = _stopAutoplay()
    //     0xa4e7e8: bl              #0x823d70  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_stopAutoplay
    // 0xa4e7ec: add             SP, SP, #8
    // 0xa4e7f0: r0 = Null
    //     0xa4e7f0: mov             x0, NULL
    // 0xa4e7f4: LeaveFrame
    //     0xa4e7f4: mov             SP, fp
    //     0xa4e7f8: ldp             fp, lr, [SP], #0x10
    // 0xa4e7fc: ret
    //     0xa4e7fc: ret             
    // 0xa4e800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4e800: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4e804: b               #0xa4e790
    // 0xa4e808: r9 = _controller
    //     0xa4e808: add             x9, PP, #0x29, lsl #12  ; [pp+0x293a8] Field <_SwiperTimerMixin@199212615._controller@199212615>: late (offset: 0x18)
    //     0xa4e80c: ldr             x9, [x9, #0x3a8]
    // 0xa4e810: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4e810: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3417, size: 0x24, field offset: 0x1c
class _SwiperState extends _SwiperTimerMixin {

  late int _activeIndex; // offset: 0x1c

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x797534, size: 0x1c8
    // 0x797534: EnterFrame
    //     0x797534: stp             fp, lr, [SP, #-0x10]!
    //     0x797538: mov             fp, SP
    // 0x79753c: AllocStack(0x20)
    //     0x79753c: sub             SP, SP, #0x20
    // 0x797540: CheckStackOverflow
    //     0x797540: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x797544: cmp             SP, x16
    //     0x797548: b.ls            #0x7976e8
    // 0x79754c: r1 = 1
    //     0x79754c: mov             x1, #1
    // 0x797550: r0 = AllocateContext()
    //     0x797550: bl              #0xd68aa4  ; AllocateContextStub
    // 0x797554: mov             x4, x0
    // 0x797558: ldr             x3, [fp, #0x18]
    // 0x79755c: stur            x4, [fp, #-8]
    // 0x797560: StoreField: r4->field_f = r3
    //     0x797560: stur            w3, [x4, #0xf]
    // 0x797564: ldr             x0, [fp, #0x10]
    // 0x797568: r2 = Null
    //     0x797568: mov             x2, NULL
    // 0x79756c: r1 = Null
    //     0x79756c: mov             x1, NULL
    // 0x797570: r4 = 59
    //     0x797570: mov             x4, #0x3b
    // 0x797574: branchIfSmi(r0, 0x797580)
    //     0x797574: tbz             w0, #0, #0x797580
    // 0x797578: r4 = LoadClassIdInstr(r0)
    //     0x797578: ldur            x4, [x0, #-1]
    //     0x79757c: ubfx            x4, x4, #0xc, #0x14
    // 0x797580: r17 = 4225
    //     0x797580: mov             x17, #0x1081
    // 0x797584: cmp             x4, x17
    // 0x797588: b.eq            #0x7975a0
    // 0x79758c: r8 = Swiper
    //     0x79758c: add             x8, PP, #0x29, lsl #12  ; [pp+0x293d8] Type: Swiper
    //     0x797590: ldr             x8, [x8, #0x3d8]
    // 0x797594: r3 = Null
    //     0x797594: add             x3, PP, #0x29, lsl #12  ; [pp+0x293e0] Null
    //     0x797598: ldr             x3, [x3, #0x3e0]
    // 0x79759c: r0 = Swiper()
    //     0x79759c: bl              #0x797b20  ; IsType_Swiper_Stub
    // 0x7975a0: ldr             x16, [fp, #0x18]
    // 0x7975a4: ldr             lr, [fp, #0x10]
    // 0x7975a8: stp             lr, x16, [SP, #-0x10]!
    // 0x7975ac: r0 = didUpdateWidget()
    //     0x7975ac: bl              #0x7977ac  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::didUpdateWidget
    // 0x7975b0: add             SP, SP, #0x10
    // 0x7975b4: ldr             x16, [fp, #0x18]
    // 0x7975b8: SaveReg r16
    //     0x7975b8: str             x16, [SP, #-8]!
    // 0x7975bc: r0 = enableGestures()
    //     0x7975bc: bl              #0xce3e54  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::enableGestures
    // 0x7975c0: add             SP, SP, #8
    // 0x7975c4: tbnz            w0, #4, #0x7976a4
    // 0x7975c8: ldr             x0, [fp, #0x18]
    // 0x7975cc: LoadField: r1 = r0->field_1f
    //     0x7975cc: ldur            w1, [x0, #0x1f]
    // 0x7975d0: DecompressPointer r1
    //     0x7975d0: add             x1, x1, HEAP, lsl #32
    // 0x7975d4: cmp             w1, NULL
    // 0x7975d8: b.eq            #0x79762c
    // 0x7975dc: ldr             x1, [fp, #0x10]
    // 0x7975e0: LoadField: r2 = r0->field_b
    //     0x7975e0: ldur            w2, [x0, #0xb]
    // 0x7975e4: DecompressPointer r2
    //     0x7975e4: add             x2, x2, HEAP, lsl #32
    // 0x7975e8: cmp             w2, NULL
    // 0x7975ec: b.eq            #0x7976f0
    // 0x7975f0: LoadField: r3 = r2->field_57
    //     0x7975f0: ldur            w3, [x2, #0x57]
    // 0x7975f4: DecompressPointer r3
    //     0x7975f4: add             x3, x3, HEAP, lsl #32
    // 0x7975f8: LoadField: r4 = r1->field_57
    //     0x7975f8: ldur            w4, [x1, #0x57]
    // 0x7975fc: DecompressPointer r4
    //     0x7975fc: add             x4, x4, HEAP, lsl #32
    // 0x797600: cmp             w3, w4
    // 0x797604: b.ne            #0x79762c
    // 0x797608: LoadField: r3 = r2->field_27
    //     0x797608: ldur            x3, [x2, #0x27]
    // 0x79760c: LoadField: r2 = r1->field_27
    //     0x79760c: ldur            x2, [x1, #0x27]
    // 0x797610: lsl             x1, x3, #1
    // 0x797614: lsl             x3, x2, #1
    // 0x797618: cmp             w1, w3
    // 0x79761c: b.ne            #0x79762c
    // 0x797620: d0 = 1.000000
    //     0x797620: fmov            d0, #1.00000000
    // 0x797624: fcmp            d0, d0
    // 0x797628: b.eq            #0x797698
    // 0x79762c: LoadField: r1 = r0->field_b
    //     0x79762c: ldur            w1, [x0, #0xb]
    // 0x797630: DecompressPointer r1
    //     0x797630: add             x1, x1, HEAP, lsl #32
    // 0x797634: cmp             w1, NULL
    // 0x797638: b.eq            #0x7976f4
    // 0x79763c: LoadField: r2 = r1->field_57
    //     0x79763c: ldur            w2, [x1, #0x57]
    // 0x797640: DecompressPointer r2
    //     0x797640: add             x2, x2, HEAP, lsl #32
    // 0x797644: stur            x2, [fp, #-0x18]
    // 0x797648: LoadField: r3 = r1->field_27
    //     0x797648: ldur            x3, [x1, #0x27]
    // 0x79764c: stur            x3, [fp, #-0x10]
    // 0x797650: r0 = TransformerPageController()
    //     0x797650: bl              #0x7977a0  ; AllocateTransformerPageControllerStub -> TransformerPageController (size=0x5c)
    // 0x797654: stur            x0, [fp, #-0x20]
    // 0x797658: stp             xzr, x0, [SP, #-0x10]!
    // 0x79765c: ldur            x1, [fp, #-0x10]
    // 0x797660: ldur            x16, [fp, #-0x18]
    // 0x797664: stp             x16, x1, [SP, #-0x10]!
    // 0x797668: r0 = TransformerPageController()
    //     0x797668: bl              #0x7976fc  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::TransformerPageController
    // 0x79766c: add             SP, SP, #0x20
    // 0x797670: ldur            x0, [fp, #-0x20]
    // 0x797674: ldr             x3, [fp, #0x18]
    // 0x797678: StoreField: r3->field_1f = r0
    //     0x797678: stur            w0, [x3, #0x1f]
    //     0x79767c: ldurb           w16, [x3, #-1]
    //     0x797680: ldurb           w17, [x0, #-1]
    //     0x797684: and             x16, x17, x16, lsr #2
    //     0x797688: tst             x16, HEAP, lsr #32
    //     0x79768c: b.eq            #0x797694
    //     0x797690: bl              #0xd682ac
    // 0x797694: b               #0x79769c
    // 0x797698: mov             x3, x0
    // 0x79769c: mov             x1, x3
    // 0x7976a0: b               #0x7976c8
    // 0x7976a4: ldr             x3, [fp, #0x18]
    // 0x7976a8: ldur            x2, [fp, #-8]
    // 0x7976ac: r1 = Function '<anonymous closure>':.
    //     0x7976ac: add             x1, PP, #0x29, lsl #12  ; [pp+0x293f0] AnonymousClosure: (0x797aac), in [package:card_swiper/src/swiper.dart] _SwiperState::didUpdateWidget (0x797534)
    //     0x7976b0: ldr             x1, [x1, #0x3f0]
    // 0x7976b4: r0 = AllocateClosure()
    //     0x7976b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7976b8: SaveReg r0
    //     0x7976b8: str             x0, [SP, #-8]!
    // 0x7976bc: r0 = scheduleMicrotask()
    //     0x7976bc: bl              #0x4b5c38  ; [dart:async] ::scheduleMicrotask
    // 0x7976c0: add             SP, SP, #8
    // 0x7976c4: ldr             x1, [fp, #0x18]
    // 0x7976c8: LoadField: r2 = r1->field_b
    //     0x7976c8: ldur            w2, [x1, #0xb]
    // 0x7976cc: DecompressPointer r2
    //     0x7976cc: add             x2, x2, HEAP, lsl #32
    // 0x7976d0: cmp             w2, NULL
    // 0x7976d4: b.eq            #0x7976f8
    // 0x7976d8: r0 = Null
    //     0x7976d8: mov             x0, NULL
    // 0x7976dc: LeaveFrame
    //     0x7976dc: mov             SP, fp
    //     0x7976e0: ldp             fp, lr, [SP], #0x10
    // 0x7976e4: ret
    //     0x7976e4: ret             
    // 0x7976e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7976e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7976ec: b               #0x79754c
    // 0x7976f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7976f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7976f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7976f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7976f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7976f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x797aac, size: 0x74
    // 0x797aac: EnterFrame
    //     0x797aac: stp             fp, lr, [SP, #-0x10]!
    //     0x797ab0: mov             fp, SP
    // 0x797ab4: AllocStack(0x8)
    //     0x797ab4: sub             SP, SP, #8
    // 0x797ab8: SetupParameters()
    //     0x797ab8: ldr             x0, [fp, #0x10]
    //     0x797abc: ldur            w1, [x0, #0x17]
    //     0x797ac0: add             x1, x1, HEAP, lsl #32
    //     0x797ac4: stur            x1, [fp, #-8]
    // 0x797ac8: CheckStackOverflow
    //     0x797ac8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x797acc: cmp             SP, x16
    //     0x797ad0: b.ls            #0x797b18
    // 0x797ad4: LoadField: r0 = r1->field_f
    //     0x797ad4: ldur            w0, [x1, #0xf]
    // 0x797ad8: DecompressPointer r0
    //     0x797ad8: add             x0, x0, HEAP, lsl #32
    // 0x797adc: LoadField: r2 = r0->field_1f
    //     0x797adc: ldur            w2, [x0, #0x1f]
    // 0x797ae0: DecompressPointer r2
    //     0x797ae0: add             x2, x2, HEAP, lsl #32
    // 0x797ae4: cmp             w2, NULL
    // 0x797ae8: b.eq            #0x797b08
    // 0x797aec: SaveReg r2
    //     0x797aec: str             x2, [SP, #-8]!
    // 0x797af0: r0 = dispose()
    //     0x797af0: bl              #0x9c2054  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x797af4: add             SP, SP, #8
    // 0x797af8: ldur            x1, [fp, #-8]
    // 0x797afc: LoadField: r2 = r1->field_f
    //     0x797afc: ldur            w2, [x1, #0xf]
    // 0x797b00: DecompressPointer r2
    //     0x797b00: add             x2, x2, HEAP, lsl #32
    // 0x797b04: StoreField: r2->field_1f = rNULL
    //     0x797b04: stur            NULL, [x2, #0x1f]
    // 0x797b08: r0 = Null
    //     0x797b08: mov             x0, NULL
    // 0x797b0c: LeaveFrame
    //     0x797b0c: mov             SP, fp
    //     0x797b10: ldp             fp, lr, [SP], #0x10
    // 0x797b14: ret
    //     0x797b14: ret             
    // 0x797b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x797b18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x797b1c: b               #0x797ad4
  }
  _ build(/* No info */) {
    // ** addr: 0x822db4, size: 0x120
    // 0x822db4: EnterFrame
    //     0x822db4: stp             fp, lr, [SP, #-0x10]!
    //     0x822db8: mov             fp, SP
    // 0x822dbc: AllocStack(0x10)
    //     0x822dbc: sub             SP, SP, #0x10
    // 0x822dc0: CheckStackOverflow
    //     0x822dc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x822dc4: cmp             SP, x16
    //     0x822dc8: b.ls            #0x822ec0
    // 0x822dcc: ldr             x16, [fp, #0x18]
    // 0x822dd0: SaveReg r16
    //     0x822dd0: str             x16, [SP, #-8]!
    // 0x822dd4: r0 = _buildSwiper()
    //     0x822dd4: bl              #0x8237d4  ; [package:card_swiper/src/swiper.dart] _SwiperState::_buildSwiper
    // 0x822dd8: add             SP, SP, #8
    // 0x822ddc: mov             x1, x0
    // 0x822de0: ldr             x0, [fp, #0x18]
    // 0x822de4: stur            x1, [fp, #-8]
    // 0x822de8: LoadField: r2 = r0->field_b
    //     0x822de8: ldur            w2, [x0, #0xb]
    // 0x822dec: DecompressPointer r2
    //     0x822dec: add             x2, x2, HEAP, lsl #32
    // 0x822df0: cmp             w2, NULL
    // 0x822df4: b.eq            #0x822ec8
    // 0x822df8: LoadField: r3 = r2->field_63
    //     0x822df8: ldur            w3, [x2, #0x63]
    // 0x822dfc: DecompressPointer r3
    //     0x822dfc: add             x3, x3, HEAP, lsl #32
    // 0x822e00: cmp             w3, NULL
    // 0x822e04: b.eq            #0x822e64
    // 0x822e08: stp             NULL, x0, [SP, #-0x10]!
    // 0x822e0c: r0 = _ensureConfig()
    //     0x822e0c: bl              #0x8236e0  ; [package:card_swiper/src/swiper.dart] _SwiperState::_ensureConfig
    // 0x822e10: add             SP, SP, #0x10
    // 0x822e14: mov             x1, x0
    // 0x822e18: ldr             x0, [fp, #0x18]
    // 0x822e1c: LoadField: r2 = r0->field_b
    //     0x822e1c: ldur            w2, [x0, #0xb]
    // 0x822e20: DecompressPointer r2
    //     0x822e20: add             x2, x2, HEAP, lsl #32
    // 0x822e24: cmp             w2, NULL
    // 0x822e28: b.eq            #0x822ecc
    // 0x822e2c: LoadField: r3 = r2->field_63
    //     0x822e2c: ldur            w3, [x2, #0x63]
    // 0x822e30: DecompressPointer r3
    //     0x822e30: add             x3, x3, HEAP, lsl #32
    // 0x822e34: cmp             w3, NULL
    // 0x822e38: b.eq            #0x822ed0
    // 0x822e3c: stp             x1, x3, [SP, #-0x10]!
    // 0x822e40: r0 = build()
    //     0x822e40: bl              #0x822f70  ; [package:card_swiper/src/swiper_pagination.dart] SwiperPagination::build
    // 0x822e44: add             SP, SP, #0x10
    // 0x822e48: ldr             x16, [fp, #0x18]
    // 0x822e4c: ldur            lr, [fp, #-8]
    // 0x822e50: stp             lr, x16, [SP, #-0x10]!
    // 0x822e54: SaveReg r0
    //     0x822e54: str             x0, [SP, #-8]!
    // 0x822e58: r0 = _ensureListForStack()
    //     0x822e58: bl              #0x822ed4  ; [package:card_swiper/src/swiper.dart] _SwiperState::_ensureListForStack
    // 0x822e5c: add             SP, SP, #0x18
    // 0x822e60: b               #0x822e68
    // 0x822e64: r0 = Null
    //     0x822e64: mov             x0, NULL
    // 0x822e68: stur            x0, [fp, #-0x10]
    // 0x822e6c: cmp             w0, NULL
    // 0x822e70: b.eq            #0x822eb0
    // 0x822e74: r0 = Stack()
    //     0x822e74: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x822e78: r1 = Instance_AlignmentDirectional
    //     0x822e78: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0x822e7c: ldr             x1, [x1, #0xf70]
    // 0x822e80: StoreField: r0->field_f = r1
    //     0x822e80: stur            w1, [x0, #0xf]
    // 0x822e84: r1 = Instance_StackFit
    //     0x822e84: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f78] Obj!StackFit@b64771
    //     0x822e88: ldr             x1, [x1, #0xf78]
    // 0x822e8c: StoreField: r0->field_17 = r1
    //     0x822e8c: stur            w1, [x0, #0x17]
    // 0x822e90: r1 = Instance_Clip
    //     0x822e90: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x822e94: ldr             x1, [x1, #0x678]
    // 0x822e98: StoreField: r0->field_1b = r1
    //     0x822e98: stur            w1, [x0, #0x1b]
    // 0x822e9c: ldur            x1, [fp, #-0x10]
    // 0x822ea0: StoreField: r0->field_b = r1
    //     0x822ea0: stur            w1, [x0, #0xb]
    // 0x822ea4: LeaveFrame
    //     0x822ea4: mov             SP, fp
    //     0x822ea8: ldp             fp, lr, [SP], #0x10
    // 0x822eac: ret
    //     0x822eac: ret             
    // 0x822eb0: ldur            x0, [fp, #-8]
    // 0x822eb4: LeaveFrame
    //     0x822eb4: mov             SP, fp
    //     0x822eb8: ldp             fp, lr, [SP], #0x10
    // 0x822ebc: ret
    //     0x822ebc: ret             
    // 0x822ec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x822ec0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x822ec4: b               #0x822dcc
    // 0x822ec8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x822ec8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x822ecc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x822ecc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x822ed0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x822ed0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _ensureListForStack(/* No info */) {
    // ** addr: 0x822ed4, size: 0x9c
    // 0x822ed4: EnterFrame
    //     0x822ed4: stp             fp, lr, [SP, #-0x10]!
    //     0x822ed8: mov             fp, SP
    // 0x822edc: AllocStack(0x10)
    //     0x822edc: sub             SP, SP, #0x10
    // 0x822ee0: CheckStackOverflow
    //     0x822ee0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x822ee4: cmp             SP, x16
    //     0x822ee8: b.ls            #0x822f68
    // 0x822eec: r16 = <Widget>
    //     0x822eec: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x822ef0: ldr             x16, [x16, #0xea8]
    // 0x822ef4: stp             xzr, x16, [SP, #-0x10]!
    // 0x822ef8: r0 = _GrowableList()
    //     0x822ef8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x822efc: add             SP, SP, #0x10
    // 0x822f00: r1 = Null
    //     0x822f00: mov             x1, NULL
    // 0x822f04: r2 = 4
    //     0x822f04: mov             x2, #4
    // 0x822f08: stur            x0, [fp, #-8]
    // 0x822f0c: r0 = AllocateArray()
    //     0x822f0c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x822f10: mov             x2, x0
    // 0x822f14: ldr             x0, [fp, #0x18]
    // 0x822f18: stur            x2, [fp, #-0x10]
    // 0x822f1c: StoreField: r2->field_f = r0
    //     0x822f1c: stur            w0, [x2, #0xf]
    // 0x822f20: ldr             x0, [fp, #0x10]
    // 0x822f24: StoreField: r2->field_13 = r0
    //     0x822f24: stur            w0, [x2, #0x13]
    // 0x822f28: r1 = <Widget>
    //     0x822f28: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x822f2c: ldr             x1, [x1, #0xea8]
    // 0x822f30: r0 = AllocateGrowableArray()
    //     0x822f30: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x822f34: mov             x1, x0
    // 0x822f38: ldur            x0, [fp, #-0x10]
    // 0x822f3c: StoreField: r1->field_f = r0
    //     0x822f3c: stur            w0, [x1, #0xf]
    // 0x822f40: r0 = 4
    //     0x822f40: mov             x0, #4
    // 0x822f44: StoreField: r1->field_b = r0
    //     0x822f44: stur            w0, [x1, #0xb]
    // 0x822f48: ldur            x16, [fp, #-8]
    // 0x822f4c: stp             x1, x16, [SP, #-0x10]!
    // 0x822f50: r0 = addAll()
    //     0x822f50: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x822f54: add             SP, SP, #0x10
    // 0x822f58: ldur            x0, [fp, #-8]
    // 0x822f5c: LeaveFrame
    //     0x822f5c: mov             SP, fp
    //     0x822f60: ldp             fp, lr, [SP], #0x10
    // 0x822f64: ret
    //     0x822f64: ret             
    // 0x822f68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x822f68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x822f6c: b               #0x822eec
  }
  _ _ensureConfig(/* No info */) {
    // ** addr: 0x8236e0, size: 0xe8
    // 0x8236e0: EnterFrame
    //     0x8236e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8236e4: mov             fp, SP
    // 0x8236e8: AllocStack(0x18)
    //     0x8236e8: sub             SP, SP, #0x18
    // 0x8236ec: ldr             x0, [fp, #0x10]
    // 0x8236f0: cmp             w0, NULL
    // 0x8236f4: b.ne            #0x8237a0
    // 0x8236f8: ldr             x0, [fp, #0x18]
    // 0x8236fc: LoadField: r1 = r0->field_b
    //     0x8236fc: ldur            w1, [x0, #0xb]
    // 0x823700: DecompressPointer r1
    //     0x823700: add             x1, x1, HEAP, lsl #32
    // 0x823704: cmp             w1, NULL
    // 0x823708: b.eq            #0x8237ac
    // 0x82370c: LoadField: r2 = r1->field_27
    //     0x82370c: ldur            x2, [x1, #0x27]
    // 0x823710: stur            x2, [fp, #-0x18]
    // 0x823714: LoadField: r1 = r0->field_1f
    //     0x823714: ldur            w1, [x0, #0x1f]
    // 0x823718: DecompressPointer r1
    //     0x823718: add             x1, x1, HEAP, lsl #32
    // 0x82371c: stur            x1, [fp, #-0x10]
    // 0x823720: LoadField: r3 = r0->field_1b
    //     0x823720: ldur            w3, [x0, #0x1b]
    // 0x823724: DecompressPointer r3
    //     0x823724: add             x3, x3, HEAP, lsl #32
    // 0x823728: r16 = Sentinel
    //     0x823728: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82372c: cmp             w3, w16
    // 0x823730: b.eq            #0x8237b0
    // 0x823734: stur            x3, [fp, #-8]
    // 0x823738: LoadField: r4 = r0->field_17
    //     0x823738: ldur            w4, [x0, #0x17]
    // 0x82373c: DecompressPointer r4
    //     0x82373c: add             x4, x4, HEAP, lsl #32
    // 0x823740: r16 = Sentinel
    //     0x823740: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x823744: cmp             w4, w16
    // 0x823748: b.eq            #0x8237bc
    // 0x82374c: r0 = SwiperPluginConfig()
    //     0x82374c: bl              #0x8237c8  ; AllocateSwiperPluginConfigStub -> SwiperPluginConfig (size=0x2c)
    // 0x823750: r1 = Instance_Axis
    //     0x823750: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x823754: ldr             x1, [x1, #0x440]
    // 0x823758: StoreField: r0->field_7 = r1
    //     0x823758: stur            w1, [x0, #7]
    // 0x82375c: ldur            x1, [fp, #-8]
    // 0x823760: r2 = LoadInt32Instr(r1)
    //     0x823760: sbfx            x2, x1, #1, #0x1f
    //     0x823764: tbz             w1, #0, #0x82376c
    //     0x823768: ldur            x2, [x1, #7]
    // 0x82376c: StoreField: r0->field_b = r2
    //     0x82376c: stur            x2, [x0, #0xb]
    // 0x823770: ldur            x1, [fp, #-0x18]
    // 0x823774: StoreField: r0->field_13 = r1
    //     0x823774: stur            x1, [x0, #0x13]
    // 0x823778: r1 = Instance_PageIndicatorLayout
    //     0x823778: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c568] Obj!PageIndicatorLayout@b669f1
    //     0x82377c: ldr             x1, [x1, #0x568]
    // 0x823780: StoreField: r0->field_1b = r1
    //     0x823780: stur            w1, [x0, #0x1b]
    // 0x823784: r1 = false
    //     0x823784: add             x1, NULL, #0x30  ; false
    // 0x823788: StoreField: r0->field_1f = r1
    //     0x823788: stur            w1, [x0, #0x1f]
    // 0x82378c: ldur            x1, [fp, #-0x10]
    // 0x823790: StoreField: r0->field_23 = r1
    //     0x823790: stur            w1, [x0, #0x23]
    // 0x823794: r1 = Instance_SwiperLayout
    //     0x823794: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c570] Obj!SwiperLayout@b669d1
    //     0x823798: ldr             x1, [x1, #0x570]
    // 0x82379c: StoreField: r0->field_27 = r1
    //     0x82379c: stur            w1, [x0, #0x27]
    // 0x8237a0: LeaveFrame
    //     0x8237a0: mov             SP, fp
    //     0x8237a4: ldp             fp, lr, [SP], #0x10
    // 0x8237a8: ret
    //     0x8237a8: ret             
    // 0x8237ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8237ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8237b0: r9 = _activeIndex
    //     0x8237b0: add             x9, PP, #0x29, lsl #12  ; [pp+0x293a0] Field <_SwiperState@199212615._activeIndex@199212615>: late (offset: 0x1c)
    //     0x8237b4: ldr             x9, [x9, #0x3a0]
    // 0x8237b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8237b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8237bc: r9 = _controller
    //     0x8237bc: add             x9, PP, #0x29, lsl #12  ; [pp+0x293a8] Field <_SwiperTimerMixin@199212615._controller@199212615>: late (offset: 0x18)
    //     0x8237c0: ldr             x9, [x9, #0x3a8]
    // 0x8237c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8237c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildSwiper(/* No info */) {
    // ** addr: 0x8237d4, size: 0x250
    // 0x8237d4: EnterFrame
    //     0x8237d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8237d8: mov             fp, SP
    // 0x8237dc: AllocStack(0x58)
    //     0x8237dc: sub             SP, SP, #0x58
    // 0x8237e0: CheckStackOverflow
    //     0x8237e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8237e4: cmp             SP, x16
    //     0x8237e8: b.ls            #0x8239f8
    // 0x8237ec: r1 = 1
    //     0x8237ec: mov             x1, #1
    // 0x8237f0: r0 = AllocateContext()
    //     0x8237f0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8237f4: mov             x1, x0
    // 0x8237f8: ldr             x0, [fp, #0x10]
    // 0x8237fc: stur            x1, [fp, #-0x10]
    // 0x823800: StoreField: r1->field_f = r0
    //     0x823800: stur            w0, [x1, #0xf]
    // 0x823804: LoadField: r2 = r0->field_b
    //     0x823804: ldur            w2, [x0, #0xb]
    // 0x823808: DecompressPointer r2
    //     0x823808: add             x2, x2, HEAP, lsl #32
    // 0x82380c: cmp             w2, NULL
    // 0x823810: b.eq            #0x823a00
    // 0x823814: LoadField: r3 = r2->field_1f
    //     0x823814: ldur            w3, [x2, #0x1f]
    // 0x823818: DecompressPointer r3
    //     0x823818: add             x3, x3, HEAP, lsl #32
    // 0x82381c: stur            x3, [fp, #-8]
    // 0x823820: SaveReg r0
    //     0x823820: str             x0, [SP, #-8]!
    // 0x823824: r0 = enableGestures()
    //     0x823824: bl              #0xce3e54  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::enableGestures
    // 0x823828: add             SP, SP, #8
    // 0x82382c: tbnz            w0, #4, #0x8239d0
    // 0x823830: ldr             x0, [fp, #0x10]
    // 0x823834: ldur            x1, [fp, #-8]
    // 0x823838: LoadField: r2 = r0->field_b
    //     0x823838: ldur            w2, [x0, #0xb]
    // 0x82383c: DecompressPointer r2
    //     0x82383c: add             x2, x2, HEAP, lsl #32
    // 0x823840: stur            x2, [fp, #-0x38]
    // 0x823844: cmp             w2, NULL
    // 0x823848: b.eq            #0x823a04
    // 0x82384c: LoadField: r3 = r0->field_1f
    //     0x82384c: ldur            w3, [x0, #0x1f]
    // 0x823850: DecompressPointer r3
    //     0x823850: add             x3, x3, HEAP, lsl #32
    // 0x823854: stur            x3, [fp, #-0x30]
    // 0x823858: LoadField: r4 = r2->field_57
    //     0x823858: ldur            w4, [x2, #0x57]
    // 0x82385c: DecompressPointer r4
    //     0x82385c: add             x4, x4, HEAP, lsl #32
    // 0x823860: stur            x4, [fp, #-0x28]
    // 0x823864: LoadField: r5 = r2->field_27
    //     0x823864: ldur            x5, [x2, #0x27]
    // 0x823868: stur            x5, [fp, #-0x20]
    // 0x82386c: LoadField: r6 = r0->field_1b
    //     0x82386c: ldur            w6, [x0, #0x1b]
    // 0x823870: DecompressPointer r6
    //     0x823870: add             x6, x6, HEAP, lsl #32
    // 0x823874: r16 = Sentinel
    //     0x823874: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x823878: cmp             w6, w16
    // 0x82387c: b.eq            #0x823a08
    // 0x823880: stur            x6, [fp, #-0x18]
    // 0x823884: r0 = Duration()
    //     0x823884: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x823888: mov             x1, x0
    // 0x82388c: r0 = 300000
    //     0x82388c: mov             x0, #0x93e0
    //     0x823890: movk            x0, #4, lsl #16
    // 0x823894: stur            x1, [fp, #-0x40]
    // 0x823898: StoreField: r1->field_7 = r0
    //     0x823898: stur            x0, [x1, #7]
    // 0x82389c: r1 = 1
    //     0x82389c: mov             x1, #1
    // 0x8238a0: r0 = AllocateContext()
    //     0x8238a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8238a4: mov             x1, x0
    // 0x8238a8: ldr             x0, [fp, #0x10]
    // 0x8238ac: stur            x1, [fp, #-0x58]
    // 0x8238b0: StoreField: r1->field_f = r0
    //     0x8238b0: stur            w0, [x1, #0xf]
    // 0x8238b4: LoadField: r2 = r0->field_17
    //     0x8238b4: ldur            w2, [x0, #0x17]
    // 0x8238b8: DecompressPointer r2
    //     0x8238b8: add             x2, x2, HEAP, lsl #32
    // 0x8238bc: r16 = Sentinel
    //     0x8238bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8238c0: cmp             w2, w16
    // 0x8238c4: b.eq            #0x823a14
    // 0x8238c8: ldur            x0, [fp, #-0x18]
    // 0x8238cc: stur            x2, [fp, #-0x50]
    // 0x8238d0: r3 = LoadInt32Instr(r0)
    //     0x8238d0: sbfx            x3, x0, #1, #0x1f
    //     0x8238d4: tbz             w0, #0, #0x8238dc
    //     0x8238d8: ldur            x3, [x0, #7]
    // 0x8238dc: stur            x3, [fp, #-0x48]
    // 0x8238e0: r0 = TransformerPageView()
    //     0x8238e0: bl              #0x823a24  ; AllocateTransformerPageViewStub -> TransformerPageView (size=0x54)
    // 0x8238e4: mov             x3, x0
    // 0x8238e8: ldur            x0, [fp, #-0x48]
    // 0x8238ec: stur            x3, [fp, #-0x18]
    // 0x8238f0: StoreField: r3->field_47 = r0
    //     0x8238f0: stur            x0, [x3, #0x47]
    // 0x8238f4: r0 = Instance_Cubic
    //     0x8238f4: add             x0, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x8238f8: ldr             x0, [x0, #0xfc8]
    // 0x8238fc: StoreField: r3->field_2b = r0
    //     0x8238fc: stur            w0, [x3, #0x2b]
    // 0x823900: d0 = 1.000000
    //     0x823900: fmov            d0, #1.00000000
    // 0x823904: StoreField: r3->field_3f = d0
    //     0x823904: stur            d0, [x3, #0x3f]
    // 0x823908: ldur            x0, [fp, #-0x28]
    // 0x82390c: StoreField: r3->field_33 = r0
    //     0x82390c: stur            w0, [x3, #0x33]
    // 0x823910: r0 = Instance_Axis
    //     0x823910: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x823914: ldr             x0, [x0, #0x440]
    // 0x823918: StoreField: r3->field_f = r0
    //     0x823918: stur            w0, [x3, #0xf]
    // 0x82391c: r0 = true
    //     0x82391c: add             x0, NULL, #0x20  ; true
    // 0x823920: StoreField: r3->field_17 = r0
    //     0x823920: stur            w0, [x3, #0x17]
    // 0x823924: ldur            x2, [fp, #-0x58]
    // 0x823928: r1 = Function '_onIndexChanged@199212615':.
    //     0x823928: add             x1, PP, #0x29, lsl #12  ; [pp+0x293b0] AnonymousClosure: (0x823dcc), in [package:card_swiper/src/swiper.dart] _SwiperState::_onIndexChanged (0x823e18)
    //     0x82392c: ldr             x1, [x1, #0x3b0]
    // 0x823930: r0 = AllocateClosure()
    //     0x823930: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x823934: mov             x1, x0
    // 0x823938: ldur            x0, [fp, #-0x18]
    // 0x82393c: StoreField: r0->field_1b = r1
    //     0x82393c: stur            w1, [x0, #0x1b]
    // 0x823940: ldur            x1, [fp, #-0x50]
    // 0x823944: StoreField: r0->field_23 = r1
    //     0x823944: stur            w1, [x0, #0x23]
    // 0x823948: r1 = false
    //     0x823948: add             x1, NULL, #0x30  ; false
    // 0x82394c: StoreField: r0->field_4f = r1
    //     0x82394c: stur            w1, [x0, #0x4f]
    // 0x823950: ldur            x1, [fp, #-8]
    // 0x823954: StoreField: r0->field_1f = r1
    //     0x823954: stur            w1, [x0, #0x1f]
    // 0x823958: ldur            x1, [fp, #-0x30]
    // 0x82395c: StoreField: r0->field_2f = r1
    //     0x82395c: stur            w1, [x0, #0x2f]
    // 0x823960: ldur            x1, [fp, #-0x20]
    // 0x823964: StoreField: r0->field_37 = r1
    //     0x823964: stur            x1, [x0, #0x37]
    // 0x823968: ldur            x1, [fp, #-0x40]
    // 0x82396c: StoreField: r0->field_27 = r1
    //     0x82396c: stur            w1, [x0, #0x27]
    // 0x823970: ldur            x1, [fp, #-0x38]
    // 0x823974: LoadField: r2 = r1->field_33
    //     0x823974: ldur            w2, [x1, #0x33]
    // 0x823978: DecompressPointer r2
    //     0x823978: add             x2, x2, HEAP, lsl #32
    // 0x82397c: tbnz            w2, #4, #0x8239bc
    // 0x823980: ldur            x2, [fp, #-0x10]
    // 0x823984: r1 = Function '<anonymous closure>':.
    //     0x823984: add             x1, PP, #0x29, lsl #12  ; [pp+0x293b8] AnonymousClosure: (0x823a30), in [package:card_swiper/src/swiper.dart] _SwiperState::_buildSwiper (0x8237d4)
    //     0x823988: ldr             x1, [x1, #0x3b8]
    // 0x82398c: r0 = AllocateClosure()
    //     0x82398c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x823990: r1 = <Notification>
    //     0x823990: add             x1, PP, #0x29, lsl #12  ; [pp+0x293c0] TypeArguments: <Notification>
    //     0x823994: ldr             x1, [x1, #0x3c0]
    // 0x823998: stur            x0, [fp, #-8]
    // 0x82399c: r0 = NotificationListener()
    //     0x82399c: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x8239a0: ldur            x1, [fp, #-8]
    // 0x8239a4: StoreField: r0->field_13 = r1
    //     0x8239a4: stur            w1, [x0, #0x13]
    // 0x8239a8: ldur            x1, [fp, #-0x18]
    // 0x8239ac: StoreField: r0->field_b = r1
    //     0x8239ac: stur            w1, [x0, #0xb]
    // 0x8239b0: LeaveFrame
    //     0x8239b0: mov             SP, fp
    //     0x8239b4: ldp             fp, lr, [SP], #0x10
    // 0x8239b8: ret
    //     0x8239b8: ret             
    // 0x8239bc: mov             x1, x0
    // 0x8239c0: mov             x0, x1
    // 0x8239c4: LeaveFrame
    //     0x8239c4: mov             SP, fp
    //     0x8239c8: ldp             fp, lr, [SP], #0x10
    // 0x8239cc: ret
    //     0x8239cc: ret             
    // 0x8239d0: ldr             x0, [fp, #0x10]
    // 0x8239d4: LoadField: r1 = r0->field_b
    //     0x8239d4: ldur            w1, [x0, #0xb]
    // 0x8239d8: DecompressPointer r1
    //     0x8239d8: add             x1, x1, HEAP, lsl #32
    // 0x8239dc: cmp             w1, NULL
    // 0x8239e0: b.eq            #0x823a20
    // 0x8239e4: r0 = Instance_SizedBox
    //     0x8239e4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x8239e8: ldr             x0, [x0, #0x738]
    // 0x8239ec: LeaveFrame
    //     0x8239ec: mov             SP, fp
    //     0x8239f0: ldp             fp, lr, [SP], #0x10
    // 0x8239f4: ret
    //     0x8239f4: ret             
    // 0x8239f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8239f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8239fc: b               #0x8237ec
    // 0x823a00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x823a00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x823a04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x823a04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x823a08: r9 = _activeIndex
    //     0x823a08: add             x9, PP, #0x29, lsl #12  ; [pp+0x293a0] Field <_SwiperState@199212615._activeIndex@199212615>: late (offset: 0x1c)
    //     0x823a0c: ldr             x9, [x9, #0x3a0]
    // 0x823a10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x823a10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x823a14: r9 = _controller
    //     0x823a14: add             x9, PP, #0x29, lsl #12  ; [pp+0x293a8] Field <_SwiperTimerMixin@199212615._controller@199212615>: late (offset: 0x18)
    //     0x823a18: ldr             x9, [x9, #0x3a8]
    // 0x823a1c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x823a1c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x823a20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x823a20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, Object?) {
    // ** addr: 0x823a30, size: 0xbc
    // 0x823a30: EnterFrame
    //     0x823a30: stp             fp, lr, [SP, #-0x10]!
    //     0x823a34: mov             fp, SP
    // 0x823a38: ldr             x0, [fp, #0x18]
    // 0x823a3c: LoadField: r1 = r0->field_17
    //     0x823a3c: ldur            w1, [x0, #0x17]
    // 0x823a40: DecompressPointer r1
    //     0x823a40: add             x1, x1, HEAP, lsl #32
    // 0x823a44: CheckStackOverflow
    //     0x823a44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823a48: cmp             SP, x16
    //     0x823a4c: b.ls            #0x823ae4
    // 0x823a50: ldr             x0, [fp, #0x10]
    // 0x823a54: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x823a54: mov             x2, #0x76
    //     0x823a58: tbz             w0, #0, #0x823a68
    //     0x823a5c: ldur            x2, [x0, #-1]
    //     0x823a60: ubfx            x2, x2, #0xc, #0x14
    //     0x823a64: lsl             x2, x2, #1
    // 0x823a68: cmp             w2, #0xe66
    // 0x823a6c: b.ne            #0x823aa8
    // 0x823a70: LoadField: r2 = r0->field_17
    //     0x823a70: ldur            w2, [x0, #0x17]
    // 0x823a74: DecompressPointer r2
    //     0x823a74: add             x2, x2, HEAP, lsl #32
    // 0x823a78: cmp             w2, NULL
    // 0x823a7c: b.eq            #0x823ad4
    // 0x823a80: LoadField: r0 = r1->field_f
    //     0x823a80: ldur            w0, [x1, #0xf]
    // 0x823a84: DecompressPointer r0
    //     0x823a84: add             x0, x0, HEAP, lsl #32
    // 0x823a88: LoadField: r1 = r0->field_13
    //     0x823a88: ldur            w1, [x0, #0x13]
    // 0x823a8c: DecompressPointer r1
    //     0x823a8c: add             x1, x1, HEAP, lsl #32
    // 0x823a90: cmp             w1, NULL
    // 0x823a94: b.eq            #0x823ad4
    // 0x823a98: SaveReg r0
    //     0x823a98: str             x0, [SP, #-8]!
    // 0x823a9c: r0 = _stopAutoplay()
    //     0x823a9c: bl              #0x823d70  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_stopAutoplay
    // 0x823aa0: add             SP, SP, #8
    // 0x823aa4: b               #0x823ad4
    // 0x823aa8: cmp             w2, #0xe5e
    // 0x823aac: b.ne            #0x823ad4
    // 0x823ab0: LoadField: r0 = r1->field_f
    //     0x823ab0: ldur            w0, [x1, #0xf]
    // 0x823ab4: DecompressPointer r0
    //     0x823ab4: add             x0, x0, HEAP, lsl #32
    // 0x823ab8: LoadField: r1 = r0->field_13
    //     0x823ab8: ldur            w1, [x0, #0x13]
    // 0x823abc: DecompressPointer r1
    //     0x823abc: add             x1, x1, HEAP, lsl #32
    // 0x823ac0: cmp             w1, NULL
    // 0x823ac4: b.ne            #0x823ad4
    // 0x823ac8: SaveReg r0
    //     0x823ac8: str             x0, [SP, #-8]!
    // 0x823acc: r0 = _startAutoplay()
    //     0x823acc: bl              #0x823aec  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::_startAutoplay
    // 0x823ad0: add             SP, SP, #8
    // 0x823ad4: r0 = false
    //     0x823ad4: add             x0, NULL, #0x30  ; false
    // 0x823ad8: LeaveFrame
    //     0x823ad8: mov             SP, fp
    //     0x823adc: ldp             fp, lr, [SP], #0x10
    // 0x823ae0: ret
    //     0x823ae0: ret             
    // 0x823ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x823ae4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x823ae8: b               #0x823a50
  }
  [closure] void _onIndexChanged(dynamic, int) {
    // ** addr: 0x823dcc, size: 0x4c
    // 0x823dcc: EnterFrame
    //     0x823dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x823dd0: mov             fp, SP
    // 0x823dd4: ldr             x0, [fp, #0x18]
    // 0x823dd8: LoadField: r1 = r0->field_17
    //     0x823dd8: ldur            w1, [x0, #0x17]
    // 0x823ddc: DecompressPointer r1
    //     0x823ddc: add             x1, x1, HEAP, lsl #32
    // 0x823de0: CheckStackOverflow
    //     0x823de0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823de4: cmp             SP, x16
    //     0x823de8: b.ls            #0x823e10
    // 0x823dec: LoadField: r0 = r1->field_f
    //     0x823dec: ldur            w0, [x1, #0xf]
    // 0x823df0: DecompressPointer r0
    //     0x823df0: add             x0, x0, HEAP, lsl #32
    // 0x823df4: ldr             x16, [fp, #0x10]
    // 0x823df8: stp             x16, x0, [SP, #-0x10]!
    // 0x823dfc: r0 = _onIndexChanged()
    //     0x823dfc: bl              #0x823e18  ; [package:card_swiper/src/swiper.dart] _SwiperState::_onIndexChanged
    // 0x823e00: add             SP, SP, #0x10
    // 0x823e04: LeaveFrame
    //     0x823e04: mov             SP, fp
    //     0x823e08: ldp             fp, lr, [SP], #0x10
    // 0x823e0c: ret
    //     0x823e0c: ret             
    // 0x823e10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x823e10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x823e14: b               #0x823dec
  }
  _ _onIndexChanged(/* No info */) {
    // ** addr: 0x823e18, size: 0x80
    // 0x823e18: EnterFrame
    //     0x823e18: stp             fp, lr, [SP, #-0x10]!
    //     0x823e1c: mov             fp, SP
    // 0x823e20: CheckStackOverflow
    //     0x823e20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823e24: cmp             SP, x16
    //     0x823e28: b.ls            #0x823e8c
    // 0x823e2c: r1 = 2
    //     0x823e2c: mov             x1, #2
    // 0x823e30: r0 = AllocateContext()
    //     0x823e30: bl              #0xd68aa4  ; AllocateContextStub
    // 0x823e34: mov             x1, x0
    // 0x823e38: ldr             x0, [fp, #0x18]
    // 0x823e3c: StoreField: r1->field_f = r0
    //     0x823e3c: stur            w0, [x1, #0xf]
    // 0x823e40: ldr             x2, [fp, #0x10]
    // 0x823e44: StoreField: r1->field_13 = r2
    //     0x823e44: stur            w2, [x1, #0x13]
    // 0x823e48: mov             x2, x1
    // 0x823e4c: r1 = Function '<anonymous closure>':.
    //     0x823e4c: add             x1, PP, #0x29, lsl #12  ; [pp+0x293d0] AnonymousClosure: (0x823e98), in [package:card_swiper/src/swiper.dart] _SwiperState::_onIndexChanged (0x823e18)
    //     0x823e50: ldr             x1, [x1, #0x3d0]
    // 0x823e54: r0 = AllocateClosure()
    //     0x823e54: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x823e58: ldr             x16, [fp, #0x18]
    // 0x823e5c: stp             x0, x16, [SP, #-0x10]!
    // 0x823e60: r0 = setState()
    //     0x823e60: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x823e64: add             SP, SP, #0x10
    // 0x823e68: ldr             x1, [fp, #0x18]
    // 0x823e6c: LoadField: r2 = r1->field_b
    //     0x823e6c: ldur            w2, [x1, #0xb]
    // 0x823e70: DecompressPointer r2
    //     0x823e70: add             x2, x2, HEAP, lsl #32
    // 0x823e74: cmp             w2, NULL
    // 0x823e78: b.eq            #0x823e94
    // 0x823e7c: r0 = Null
    //     0x823e7c: mov             x0, NULL
    // 0x823e80: LeaveFrame
    //     0x823e80: mov             SP, fp
    //     0x823e84: ldp             fp, lr, [SP], #0x10
    // 0x823e88: ret
    //     0x823e88: ret             
    // 0x823e8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x823e8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x823e90: b               #0x823e2c
    // 0x823e94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x823e94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x823e98, size: 0x4c
    // 0x823e98: ldr             x1, [SP]
    // 0x823e9c: LoadField: r2 = r1->field_17
    //     0x823e9c: ldur            w2, [x1, #0x17]
    // 0x823ea0: DecompressPointer r2
    //     0x823ea0: add             x2, x2, HEAP, lsl #32
    // 0x823ea4: LoadField: r1 = r2->field_f
    //     0x823ea4: ldur            w1, [x2, #0xf]
    // 0x823ea8: DecompressPointer r1
    //     0x823ea8: add             x1, x1, HEAP, lsl #32
    // 0x823eac: LoadField: r0 = r2->field_13
    //     0x823eac: ldur            w0, [x2, #0x13]
    // 0x823eb0: DecompressPointer r0
    //     0x823eb0: add             x0, x0, HEAP, lsl #32
    // 0x823eb4: StoreField: r1->field_1b = r0
    //     0x823eb4: stur            w0, [x1, #0x1b]
    //     0x823eb8: tbz             w0, #0, #0x823edc
    //     0x823ebc: ldurb           w16, [x1, #-1]
    //     0x823ec0: ldurb           w17, [x0, #-1]
    //     0x823ec4: and             x16, x17, x16, lsr #2
    //     0x823ec8: tst             x16, HEAP, lsr #32
    //     0x823ecc: b.eq            #0x823edc
    //     0x823ed0: str             lr, [SP, #-8]!
    //     0x823ed4: bl              #0xd6826c
    //     0x823ed8: ldr             lr, [SP], #8
    // 0x823edc: r0 = Null
    //     0x823edc: mov             x0, NULL
    // 0x823ee0: ret
    //     0x823ee0: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d4e20, size: 0xdc
    // 0x9d4e20: EnterFrame
    //     0x9d4e20: stp             fp, lr, [SP, #-0x10]!
    //     0x9d4e24: mov             fp, SP
    // 0x9d4e28: AllocStack(0x18)
    //     0x9d4e28: sub             SP, SP, #0x18
    // 0x9d4e2c: CheckStackOverflow
    //     0x9d4e2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d4e30: cmp             SP, x16
    //     0x9d4e34: b.ls            #0x9d4eec
    // 0x9d4e38: ldr             x16, [fp, #0x10]
    // 0x9d4e3c: SaveReg r16
    //     0x9d4e3c: str             x16, [SP, #-8]!
    // 0x9d4e40: r0 = initState()
    //     0x9d4e40: bl              #0x9d4efc  ; [package:card_swiper/src/swiper.dart] _SwiperTimerMixin::initState
    // 0x9d4e44: add             SP, SP, #8
    // 0x9d4e48: ldr             x0, [fp, #0x10]
    // 0x9d4e4c: LoadField: r1 = r0->field_b
    //     0x9d4e4c: ldur            w1, [x0, #0xb]
    // 0x9d4e50: DecompressPointer r1
    //     0x9d4e50: add             x1, x1, HEAP, lsl #32
    // 0x9d4e54: cmp             w1, NULL
    // 0x9d4e58: b.eq            #0x9d4ef4
    // 0x9d4e5c: StoreField: r0->field_1b = rZR
    //     0x9d4e5c: stur            wzr, [x0, #0x1b]
    // 0x9d4e60: SaveReg r0
    //     0x9d4e60: str             x0, [SP, #-8]!
    // 0x9d4e64: r0 = enableGestures()
    //     0x9d4e64: bl              #0xce3e54  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::enableGestures
    // 0x9d4e68: add             SP, SP, #8
    // 0x9d4e6c: tbnz            w0, #4, #0x9d4edc
    // 0x9d4e70: ldr             x0, [fp, #0x10]
    // 0x9d4e74: LoadField: r1 = r0->field_b
    //     0x9d4e74: ldur            w1, [x0, #0xb]
    // 0x9d4e78: DecompressPointer r1
    //     0x9d4e78: add             x1, x1, HEAP, lsl #32
    // 0x9d4e7c: cmp             w1, NULL
    // 0x9d4e80: b.eq            #0x9d4ef8
    // 0x9d4e84: LoadField: r2 = r1->field_57
    //     0x9d4e84: ldur            w2, [x1, #0x57]
    // 0x9d4e88: DecompressPointer r2
    //     0x9d4e88: add             x2, x2, HEAP, lsl #32
    // 0x9d4e8c: stur            x2, [fp, #-0x10]
    // 0x9d4e90: LoadField: r3 = r1->field_27
    //     0x9d4e90: ldur            x3, [x1, #0x27]
    // 0x9d4e94: stur            x3, [fp, #-8]
    // 0x9d4e98: r0 = TransformerPageController()
    //     0x9d4e98: bl              #0x7977a0  ; AllocateTransformerPageControllerStub -> TransformerPageController (size=0x5c)
    // 0x9d4e9c: stur            x0, [fp, #-0x18]
    // 0x9d4ea0: stp             xzr, x0, [SP, #-0x10]!
    // 0x9d4ea4: ldur            x1, [fp, #-8]
    // 0x9d4ea8: ldur            x16, [fp, #-0x10]
    // 0x9d4eac: stp             x16, x1, [SP, #-0x10]!
    // 0x9d4eb0: r0 = TransformerPageController()
    //     0x9d4eb0: bl              #0x7976fc  ; [package:card_swiper/src/transformer_page_view/transformer_page_view.dart] TransformerPageController::TransformerPageController
    // 0x9d4eb4: add             SP, SP, #0x20
    // 0x9d4eb8: ldur            x0, [fp, #-0x18]
    // 0x9d4ebc: ldr             x1, [fp, #0x10]
    // 0x9d4ec0: StoreField: r1->field_1f = r0
    //     0x9d4ec0: stur            w0, [x1, #0x1f]
    //     0x9d4ec4: ldurb           w16, [x1, #-1]
    //     0x9d4ec8: ldurb           w17, [x0, #-1]
    //     0x9d4ecc: and             x16, x17, x16, lsr #2
    //     0x9d4ed0: tst             x16, HEAP, lsr #32
    //     0x9d4ed4: b.eq            #0x9d4edc
    //     0x9d4ed8: bl              #0xd6826c
    // 0x9d4edc: r0 = Null
    //     0x9d4edc: mov             x0, NULL
    // 0x9d4ee0: LeaveFrame
    //     0x9d4ee0: mov             SP, fp
    //     0x9d4ee4: ldp             fp, lr, [SP], #0x10
    // 0x9d4ee8: ret
    //     0x9d4ee8: ret             
    // 0x9d4eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d4eec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d4ef0: b               #0x9d4e38
    // 0x9d4ef4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d4ef4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d4ef8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d4ef8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4225, size: 0x98, field offset: 0xc
//   const constructor, 
class Swiper extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3ef74, size: 0x2c
    // 0xa3ef74: EnterFrame
    //     0xa3ef74: stp             fp, lr, [SP, #-0x10]!
    //     0xa3ef78: mov             fp, SP
    // 0xa3ef7c: r1 = <Swiper>
    //     0xa3ef7c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22970] TypeArguments: <Swiper>
    //     0xa3ef80: ldr             x1, [x1, #0x970]
    // 0xa3ef84: r0 = _SwiperState()
    //     0xa3ef84: bl              #0xa3efa0  ; Allocate_SwiperStateStub -> _SwiperState (size=0x24)
    // 0xa3ef88: r1 = Sentinel
    //     0xa3ef88: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3ef8c: StoreField: r0->field_1b = r1
    //     0xa3ef8c: stur            w1, [x0, #0x1b]
    // 0xa3ef90: StoreField: r0->field_17 = r1
    //     0xa3ef90: stur            w1, [x0, #0x17]
    // 0xa3ef94: LeaveFrame
    //     0xa3ef94: mov             SP, fp
    //     0xa3ef98: ldp             fp, lr, [SP], #0x10
    // 0xa3ef9c: ret
    //     0xa3ef9c: ret             
  }
}

// class id: 6016, size: 0x14, field offset: 0x14
enum SwiperLayout extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15220, size: 0x5c
    // 0xb15220: EnterFrame
    //     0xb15220: stp             fp, lr, [SP, #-0x10]!
    //     0xb15224: mov             fp, SP
    // 0xb15228: CheckStackOverflow
    //     0xb15228: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1522c: cmp             SP, x16
    //     0xb15230: b.ls            #0xb15274
    // 0xb15234: r1 = Null
    //     0xb15234: mov             x1, NULL
    // 0xb15238: r2 = 4
    //     0xb15238: mov             x2, #4
    // 0xb1523c: r0 = AllocateArray()
    //     0xb1523c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15240: r17 = "SwiperLayout."
    //     0xb15240: add             x17, PP, #0x22, lsl #12  ; [pp+0x22978] "SwiperLayout."
    //     0xb15244: ldr             x17, [x17, #0x978]
    // 0xb15248: StoreField: r0->field_f = r17
    //     0xb15248: stur            w17, [x0, #0xf]
    // 0xb1524c: ldr             x1, [fp, #0x10]
    // 0xb15250: LoadField: r2 = r1->field_f
    //     0xb15250: ldur            w2, [x1, #0xf]
    // 0xb15254: DecompressPointer r2
    //     0xb15254: add             x2, x2, HEAP, lsl #32
    // 0xb15258: StoreField: r0->field_13 = r2
    //     0xb15258: stur            w2, [x0, #0x13]
    // 0xb1525c: SaveReg r0
    //     0xb1525c: str             x0, [SP, #-8]!
    // 0xb15260: r0 = _interpolate()
    //     0xb15260: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15264: add             SP, SP, #8
    // 0xb15268: LeaveFrame
    //     0xb15268: mov             SP, fp
    //     0xb1526c: ldp             fp, lr, [SP], #0x10
    // 0xb15270: ret
    //     0xb15270: ret             
    // 0xb15274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15274: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15278: b               #0xb15234
  }
}

// lib: , url: package:card_swiper/src/swiper_pagination.dart

// class id: 1048734, size: 0x8
class :: {
}

// class id: 4878, size: 0x18, field offset: 0x8
//   const constructor, 
class SwiperPagination extends SwiperPlugin {

  Alignment field_8;
  EdgeInsets field_c;
  DotSwiperPaginationBuilder field_10;

  _ build(/* No info */) {
    // ** addr: 0x822f70, size: 0x8c
    // 0x822f70: EnterFrame
    //     0x822f70: stp             fp, lr, [SP, #-0x10]!
    //     0x822f74: mov             fp, SP
    // 0x822f78: AllocStack(0x10)
    //     0x822f78: sub             SP, SP, #0x10
    // 0x822f7c: CheckStackOverflow
    //     0x822f7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x822f80: cmp             SP, x16
    //     0x822f84: b.ls            #0x822ff4
    // 0x822f88: r16 = Instance_DotSwiperPaginationBuilder
    //     0x822f88: add             x16, PP, #0x29, lsl #12  ; [pp+0x29380] Obj!DotSwiperPaginationBuilder@b5c831
    //     0x822f8c: ldr             x16, [x16, #0x380]
    // 0x822f90: ldr             lr, [fp, #0x10]
    // 0x822f94: stp             lr, x16, [SP, #-0x10]!
    // 0x822f98: r0 = build()
    //     0x822f98: bl              #0x823008  ; [package:card_swiper/src/swiper_pagination.dart] DotSwiperPaginationBuilder::build
    // 0x822f9c: add             SP, SP, #0x10
    // 0x822fa0: stur            x0, [fp, #-8]
    // 0x822fa4: r0 = Container()
    //     0x822fa4: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x822fa8: stur            x0, [fp, #-0x10]
    // 0x822fac: r16 = Instance_EdgeInsets
    //     0x822fac: add             x16, PP, #0x26, lsl #12  ; [pp+0x267b8] Obj!EdgeInsets@b35b71
    //     0x822fb0: ldr             x16, [x16, #0x7b8]
    // 0x822fb4: stp             x16, x0, [SP, #-0x10]!
    // 0x822fb8: ldur            x16, [fp, #-8]
    // 0x822fbc: SaveReg r16
    //     0x822fbc: str             x16, [SP, #-8]!
    // 0x822fc0: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, margin, 0x1, null]
    //     0x822fc0: add             x4, PP, #0xe, lsl #12  ; [pp+0xee98] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "margin", 0x1, Null]
    //     0x822fc4: ldr             x4, [x4, #0xe98]
    // 0x822fc8: r0 = Container()
    //     0x822fc8: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x822fcc: add             SP, SP, #0x18
    // 0x822fd0: r0 = Align()
    //     0x822fd0: bl              #0x822ffc  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x822fd4: r1 = Instance_Alignment
    //     0x822fd4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdca8] Obj!Alignment@b37a91
    //     0x822fd8: ldr             x1, [x1, #0xca8]
    // 0x822fdc: StoreField: r0->field_f = r1
    //     0x822fdc: stur            w1, [x0, #0xf]
    // 0x822fe0: ldur            x1, [fp, #-0x10]
    // 0x822fe4: StoreField: r0->field_b = r1
    //     0x822fe4: stur            w1, [x0, #0xb]
    // 0x822fe8: LeaveFrame
    //     0x822fe8: mov             SP, fp
    //     0x822fec: ldp             fp, lr, [SP], #0x10
    // 0x822ff0: ret
    //     0x822ff0: ret             
    // 0x822ff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x822ff4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x822ff8: b               #0x822f88
  }
}

// class id: 4879, size: 0x2c, field offset: 0x8
//   const constructor, 
class DotSwiperPaginationBuilder extends SwiperPlugin {

  Color field_8;
  Color field_c;
  _Double field_10;
  _Double field_18;
  _Double field_20;

  _ build(/* No info */) {
    // ** addr: 0x823008, size: 0x2c0
    // 0x823008: EnterFrame
    //     0x823008: stp             fp, lr, [SP, #-0x10]!
    //     0x82300c: mov             fp, SP
    // 0x823010: AllocStack(0x40)
    //     0x823010: sub             SP, SP, #0x40
    // 0x823014: CheckStackOverflow
    //     0x823014: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823018: cmp             SP, x16
    //     0x82301c: b.ls            #0x8232b4
    // 0x823020: ldr             x0, [fp, #0x10]
    // 0x823024: LoadField: r1 = r0->field_13
    //     0x823024: ldur            x1, [x0, #0x13]
    // 0x823028: stur            x1, [fp, #-8]
    // 0x82302c: cmp             x1, #0x14
    // 0x823030: b.le            #0x82304c
    // 0x823034: r16 = "The itemCount is too big, we suggest use FractionPaginationBuilder instead of DotSwiperPaginationBuilder in this situation"
    //     0x823034: add             x16, PP, #0x29, lsl #12  ; [pp+0x29388] "The itemCount is too big, we suggest use FractionPaginationBuilder instead of DotSwiperPaginationBuilder in this situation"
    //     0x823038: ldr             x16, [x16, #0x388]
    // 0x82303c: SaveReg r16
    //     0x82303c: str             x16, [SP, #-8]!
    // 0x823040: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x823040: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x823044: r0 = log()
    //     0x823044: bl              #0x59a3dc  ; [dart:developer] ::log
    // 0x823048: add             SP, SP, #8
    // 0x82304c: ldr             x0, [fp, #0x10]
    // 0x823050: r16 = <Widget>
    //     0x823050: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x823054: ldr             x16, [x16, #0xea8]
    // 0x823058: stp             xzr, x16, [SP, #-0x10]!
    // 0x82305c: r0 = _GrowableList()
    //     0x82305c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x823060: add             SP, SP, #0x10
    // 0x823064: mov             x3, x0
    // 0x823068: ldr             x0, [fp, #0x10]
    // 0x82306c: stur            x3, [fp, #-0x20]
    // 0x823070: LoadField: r4 = r0->field_b
    //     0x823070: ldur            x4, [x0, #0xb]
    // 0x823074: stur            x4, [fp, #-0x18]
    // 0x823078: r5 = 0
    //     0x823078: mov             x5, #0
    // 0x82307c: ldur            x0, [fp, #-8]
    // 0x823080: stur            x5, [fp, #-0x10]
    // 0x823084: CheckStackOverflow
    //     0x823084: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x823088: cmp             SP, x16
    //     0x82308c: b.ls            #0x8232bc
    // 0x823090: cmp             x5, x0
    // 0x823094: b.ge            #0x823274
    // 0x823098: r1 = Null
    //     0x823098: mov             x1, NULL
    // 0x82309c: r2 = 4
    //     0x82309c: mov             x2, #4
    // 0x8230a0: r0 = AllocateArray()
    //     0x8230a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x8230a4: mov             x2, x0
    // 0x8230a8: r17 = "pagination_"
    //     0x8230a8: add             x17, PP, #0x29, lsl #12  ; [pp+0x29390] "pagination_"
    //     0x8230ac: ldr             x17, [x17, #0x390]
    // 0x8230b0: StoreField: r2->field_f = r17
    //     0x8230b0: stur            w17, [x2, #0xf]
    // 0x8230b4: ldur            x3, [fp, #-0x10]
    // 0x8230b8: r0 = BoxInt64Instr(r3)
    //     0x8230b8: sbfiz           x0, x3, #1, #0x1f
    //     0x8230bc: cmp             x3, x0, asr #1
    //     0x8230c0: b.eq            #0x8230cc
    //     0x8230c4: bl              #0xd69bb8
    //     0x8230c8: stur            x3, [x0, #7]
    // 0x8230cc: StoreField: r2->field_13 = r0
    //     0x8230cc: stur            w0, [x2, #0x13]
    // 0x8230d0: SaveReg r2
    //     0x8230d0: str             x2, [SP, #-8]!
    // 0x8230d4: r0 = _interpolate()
    //     0x8230d4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x8230d8: add             SP, SP, #8
    // 0x8230dc: r1 = <String>
    //     0x8230dc: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x8230e0: stur            x0, [fp, #-0x28]
    // 0x8230e4: r0 = ValueKey()
    //     0x8230e4: bl              #0x7a155c  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0x8230e8: mov             x1, x0
    // 0x8230ec: ldur            x0, [fp, #-0x28]
    // 0x8230f0: stur            x1, [fp, #-0x30]
    // 0x8230f4: StoreField: r1->field_b = r0
    //     0x8230f4: stur            w0, [x1, #0xb]
    // 0x8230f8: r0 = EdgeInsets()
    //     0x8230f8: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x8230fc: d0 = 2.000000
    //     0x8230fc: fmov            d0, #2.00000000
    // 0x823100: stur            x0, [fp, #-0x38]
    // 0x823104: StoreField: r0->field_7 = d0
    //     0x823104: stur            d0, [x0, #7]
    // 0x823108: StoreField: r0->field_f = d0
    //     0x823108: stur            d0, [x0, #0xf]
    // 0x82310c: StoreField: r0->field_17 = d0
    //     0x82310c: stur            d0, [x0, #0x17]
    // 0x823110: StoreField: r0->field_1f = d0
    //     0x823110: stur            d0, [x0, #0x1f]
    // 0x823114: ldur            x2, [fp, #-0x18]
    // 0x823118: ldur            x1, [fp, #-0x10]
    // 0x82311c: cmp             x1, x2
    // 0x823120: b.ne            #0x823130
    // 0x823124: r5 = Instance_Color
    //     0x823124: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x823128: ldr             x5, [x5, #0xbe8]
    // 0x82312c: b               #0x823138
    // 0x823130: r5 = Instance_Color
    //     0x823130: add             x5, PP, #0x29, lsl #12  ; [pp+0x29398] Obj!Color@b5d6a1
    //     0x823134: ldr             x5, [x5, #0x398]
    // 0x823138: ldur            x4, [fp, #-0x20]
    // 0x82313c: ldur            x3, [fp, #-0x30]
    // 0x823140: stur            x5, [fp, #-0x28]
    // 0x823144: r0 = Container()
    //     0x823144: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x823148: mov             x1, x0
    // 0x82314c: ldur            x0, [fp, #-0x28]
    // 0x823150: stur            x1, [fp, #-0x40]
    // 0x823154: StoreField: r1->field_17 = r0
    //     0x823154: stur            w0, [x1, #0x17]
    // 0x823158: r0 = Instance_Clip
    //     0x823158: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x82315c: ldr             x0, [x0, #0xb38]
    // 0x823160: StoreField: r1->field_33 = r0
    //     0x823160: stur            w0, [x1, #0x33]
    // 0x823164: r0 = BoxConstraints()
    //     0x823164: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x823168: d0 = 4.000000
    //     0x823168: fmov            d0, #4.00000000
    // 0x82316c: StoreField: r0->field_7 = d0
    //     0x82316c: stur            d0, [x0, #7]
    // 0x823170: StoreField: r0->field_f = d0
    //     0x823170: stur            d0, [x0, #0xf]
    // 0x823174: StoreField: r0->field_17 = d0
    //     0x823174: stur            d0, [x0, #0x17]
    // 0x823178: StoreField: r0->field_1f = d0
    //     0x823178: stur            d0, [x0, #0x1f]
    // 0x82317c: ldur            x1, [fp, #-0x40]
    // 0x823180: StoreField: r1->field_23 = r0
    //     0x823180: stur            w0, [x1, #0x23]
    // 0x823184: r0 = ClipOval()
    //     0x823184: bl              #0x8236d4  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x823188: mov             x1, x0
    // 0x82318c: r0 = Instance_Clip
    //     0x82318c: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ad0] Obj!Clip@b676b1
    //     0x823190: ldr             x0, [x0, #0xad0]
    // 0x823194: stur            x1, [fp, #-0x28]
    // 0x823198: StoreField: r1->field_13 = r0
    //     0x823198: stur            w0, [x1, #0x13]
    // 0x82319c: ldur            x2, [fp, #-0x40]
    // 0x8231a0: StoreField: r1->field_b = r2
    //     0x8231a0: stur            w2, [x1, #0xb]
    // 0x8231a4: r0 = Container()
    //     0x8231a4: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8231a8: mov             x1, x0
    // 0x8231ac: ldur            x0, [fp, #-0x38]
    // 0x8231b0: stur            x1, [fp, #-0x40]
    // 0x8231b4: StoreField: r1->field_27 = r0
    //     0x8231b4: stur            w0, [x1, #0x27]
    // 0x8231b8: ldur            x0, [fp, #-0x28]
    // 0x8231bc: StoreField: r1->field_b = r0
    //     0x8231bc: stur            w0, [x1, #0xb]
    // 0x8231c0: r0 = Instance_Clip
    //     0x8231c0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x8231c4: ldr             x0, [x0, #0xb38]
    // 0x8231c8: StoreField: r1->field_33 = r0
    //     0x8231c8: stur            w0, [x1, #0x33]
    // 0x8231cc: ldur            x2, [fp, #-0x30]
    // 0x8231d0: StoreField: r1->field_7 = r2
    //     0x8231d0: stur            w2, [x1, #7]
    // 0x8231d4: ldur            x2, [fp, #-0x20]
    // 0x8231d8: LoadField: r3 = r2->field_b
    //     0x8231d8: ldur            w3, [x2, #0xb]
    // 0x8231dc: DecompressPointer r3
    //     0x8231dc: add             x3, x3, HEAP, lsl #32
    // 0x8231e0: stur            x3, [fp, #-0x28]
    // 0x8231e4: LoadField: r4 = r2->field_f
    //     0x8231e4: ldur            w4, [x2, #0xf]
    // 0x8231e8: DecompressPointer r4
    //     0x8231e8: add             x4, x4, HEAP, lsl #32
    // 0x8231ec: LoadField: r5 = r4->field_b
    //     0x8231ec: ldur            w5, [x4, #0xb]
    // 0x8231f0: DecompressPointer r5
    //     0x8231f0: add             x5, x5, HEAP, lsl #32
    // 0x8231f4: cmp             w3, w5
    // 0x8231f8: b.ne            #0x823208
    // 0x8231fc: SaveReg r2
    //     0x8231fc: str             x2, [SP, #-8]!
    // 0x823200: r0 = _growToNextCapacity()
    //     0x823200: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x823204: add             SP, SP, #8
    // 0x823208: ldur            x2, [fp, #-0x20]
    // 0x82320c: ldur            x3, [fp, #-0x10]
    // 0x823210: ldur            x0, [fp, #-0x28]
    // 0x823214: r4 = LoadInt32Instr(r0)
    //     0x823214: sbfx            x4, x0, #1, #0x1f
    // 0x823218: add             x0, x4, #1
    // 0x82321c: lsl             x1, x0, #1
    // 0x823220: StoreField: r2->field_b = r1
    //     0x823220: stur            w1, [x2, #0xb]
    // 0x823224: mov             x1, x4
    // 0x823228: cmp             x1, x0
    // 0x82322c: b.hs            #0x8232c4
    // 0x823230: LoadField: r1 = r2->field_f
    //     0x823230: ldur            w1, [x2, #0xf]
    // 0x823234: DecompressPointer r1
    //     0x823234: add             x1, x1, HEAP, lsl #32
    // 0x823238: ldur            x0, [fp, #-0x40]
    // 0x82323c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x82323c: add             x25, x1, x4, lsl #2
    //     0x823240: add             x25, x25, #0xf
    //     0x823244: str             w0, [x25]
    //     0x823248: tbz             w0, #0, #0x823264
    //     0x82324c: ldurb           w16, [x1, #-1]
    //     0x823250: ldurb           w17, [x0, #-1]
    //     0x823254: and             x16, x17, x16, lsr #2
    //     0x823258: tst             x16, HEAP, lsr #32
    //     0x82325c: b.eq            #0x823264
    //     0x823260: bl              #0xd67e5c
    // 0x823264: add             x5, x3, #1
    // 0x823268: mov             x3, x2
    // 0x82326c: ldur            x4, [fp, #-0x18]
    // 0x823270: b               #0x82307c
    // 0x823274: mov             x2, x3
    // 0x823278: r0 = Row()
    //     0x823278: bl              #0x8236c8  ; AllocateRowStub -> Row (size=0x30)
    // 0x82327c: stur            x0, [fp, #-0x28]
    // 0x823280: ldur            x16, [fp, #-0x20]
    // 0x823284: stp             x16, x0, [SP, #-0x10]!
    // 0x823288: r16 = Instance_MainAxisSize
    //     0x823288: add             x16, PP, #0xe, lsl #12  ; [pp+0xeeb0] Obj!MainAxisSize@b64b71
    //     0x82328c: ldr             x16, [x16, #0xeb0]
    // 0x823290: SaveReg r16
    //     0x823290: str             x16, [SP, #-8]!
    // 0x823294: r4 = const [0, 0x3, 0x3, 0x2, mainAxisSize, 0x2, null]
    //     0x823294: add             x4, PP, #0xe, lsl #12  ; [pp+0xeeb8] List(7) [0, 0x3, 0x3, 0x2, "mainAxisSize", 0x2, Null]
    //     0x823298: ldr             x4, [x4, #0xeb8]
    // 0x82329c: r0 = Row()
    //     0x82329c: bl              #0x8232c8  ; [package:flutter/src/widgets/basic.dart] Row::Row
    // 0x8232a0: add             SP, SP, #0x18
    // 0x8232a4: ldur            x0, [fp, #-0x28]
    // 0x8232a8: LeaveFrame
    //     0x8232a8: mov             SP, fp
    //     0x8232ac: ldp             fp, lr, [SP], #0x10
    // 0x8232b0: ret
    //     0x8232b0: ret             
    // 0x8232b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8232b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8232b8: b               #0x823020
    // 0x8232bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8232bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8232c0: b               #0x823090
    // 0x8232c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8232c4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

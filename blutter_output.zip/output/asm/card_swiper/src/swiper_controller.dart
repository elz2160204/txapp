// lib: , url: package:card_swiper/src/swiper_controller.dart

// class id: 1048733, size: 0x8
class :: {
}

// class id: 4865, size: 0x28, field offset: 0x28
class SwiperController extends IndexController {

  _ stopAutoplay(/* No info */) {
    // ** addr: 0x797888, size: 0x74
    // 0x797888: EnterFrame
    //     0x797888: stp             fp, lr, [SP, #-0x10]!
    //     0x79788c: mov             fp, SP
    // 0x797890: AllocStack(0x8)
    //     0x797890: sub             SP, SP, #8
    // 0x797894: CheckStackOverflow
    //     0x797894: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x797898: cmp             SP, x16
    //     0x79789c: b.ls            #0x7978f4
    // 0x7978a0: r0 = AutoPlaySwiperControllerEvent()
    //     0x7978a0: bl              #0x7979e8  ; AllocateAutoPlaySwiperControllerEventStub -> AutoPlaySwiperControllerEvent (size=0x14)
    // 0x7978a4: stur            x0, [fp, #-8]
    // 0x7978a8: SaveReg r0
    //     0x7978a8: str             x0, [SP, #-8]!
    // 0x7978ac: r0 = AutoPlaySwiperControllerEvent.stop()
    //     0x7978ac: bl              #0x7978fc  ; [package:card_swiper/src/swiper_controller.dart] AutoPlaySwiperControllerEvent::AutoPlaySwiperControllerEvent.stop
    // 0x7978b0: add             SP, SP, #8
    // 0x7978b4: ldur            x0, [fp, #-8]
    // 0x7978b8: ldr             x1, [fp, #0x10]
    // 0x7978bc: StoreField: r1->field_23 = r0
    //     0x7978bc: stur            w0, [x1, #0x23]
    //     0x7978c0: ldurb           w16, [x1, #-1]
    //     0x7978c4: ldurb           w17, [x0, #-1]
    //     0x7978c8: and             x16, x17, x16, lsr #2
    //     0x7978cc: tst             x16, HEAP, lsr #32
    //     0x7978d0: b.eq            #0x7978d8
    //     0x7978d4: bl              #0xd6826c
    // 0x7978d8: SaveReg r1
    //     0x7978d8: str             x1, [SP, #-8]!
    // 0x7978dc: r0 = notifyListeners()
    //     0x7978dc: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x7978e0: add             SP, SP, #8
    // 0x7978e4: r0 = Null
    //     0x7978e4: mov             x0, NULL
    // 0x7978e8: LeaveFrame
    //     0x7978e8: mov             SP, fp
    //     0x7978ec: ldp             fp, lr, [SP], #0x10
    // 0x7978f0: ret
    //     0x7978f0: ret             
    // 0x7978f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7978f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7978f8: b               #0x7978a0
  }
  _ startAutoplay(/* No info */) {
    // ** addr: 0x7979f4, size: 0x74
    // 0x7979f4: EnterFrame
    //     0x7979f4: stp             fp, lr, [SP, #-0x10]!
    //     0x7979f8: mov             fp, SP
    // 0x7979fc: AllocStack(0x8)
    //     0x7979fc: sub             SP, SP, #8
    // 0x797a00: CheckStackOverflow
    //     0x797a00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x797a04: cmp             SP, x16
    //     0x797a08: b.ls            #0x797a60
    // 0x797a0c: r0 = AutoPlaySwiperControllerEvent()
    //     0x797a0c: bl              #0x7979e8  ; AllocateAutoPlaySwiperControllerEventStub -> AutoPlaySwiperControllerEvent (size=0x14)
    // 0x797a10: stur            x0, [fp, #-8]
    // 0x797a14: SaveReg r0
    //     0x797a14: str             x0, [SP, #-8]!
    // 0x797a18: r0 = AutoPlaySwiperControllerEvent.start()
    //     0x797a18: bl              #0x797a68  ; [package:card_swiper/src/swiper_controller.dart] AutoPlaySwiperControllerEvent::AutoPlaySwiperControllerEvent.start
    // 0x797a1c: add             SP, SP, #8
    // 0x797a20: ldur            x0, [fp, #-8]
    // 0x797a24: ldr             x1, [fp, #0x10]
    // 0x797a28: StoreField: r1->field_23 = r0
    //     0x797a28: stur            w0, [x1, #0x23]
    //     0x797a2c: ldurb           w16, [x1, #-1]
    //     0x797a30: ldurb           w17, [x0, #-1]
    //     0x797a34: and             x16, x17, x16, lsr #2
    //     0x797a38: tst             x16, HEAP, lsr #32
    //     0x797a3c: b.eq            #0x797a44
    //     0x797a40: bl              #0xd6826c
    // 0x797a44: SaveReg r1
    //     0x797a44: str             x1, [SP, #-8]!
    // 0x797a48: r0 = notifyListeners()
    //     0x797a48: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x797a4c: add             SP, SP, #8
    // 0x797a50: r0 = Null
    //     0x797a50: mov             x0, NULL
    // 0x797a54: LeaveFrame
    //     0x797a54: mov             SP, fp
    //     0x797a58: ldp             fp, lr, [SP], #0x10
    // 0x797a5c: ret
    //     0x797a5c: ret             
    // 0x797a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x797a60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x797a64: b               #0x797a0c
  }
}

// class id: 4886, size: 0x14, field offset: 0x10
class AutoPlaySwiperControllerEvent extends IndexControllerEventBase {

  _ AutoPlaySwiperControllerEvent.stop(/* No info */) {
    // ** addr: 0x7978fc, size: 0x44
    // 0x7978fc: EnterFrame
    //     0x7978fc: stp             fp, lr, [SP, #-0x10]!
    //     0x797900: mov             fp, SP
    // 0x797904: r0 = false
    //     0x797904: add             x0, NULL, #0x30  ; false
    // 0x797908: CheckStackOverflow
    //     0x797908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79790c: cmp             SP, x16
    //     0x797910: b.ls            #0x797938
    // 0x797914: ldr             x1, [fp, #0x10]
    // 0x797918: StoreField: r1->field_f = r0
    //     0x797918: stur            w0, [x1, #0xf]
    // 0x79791c: SaveReg r1
    //     0x79791c: str             x1, [SP, #-8]!
    // 0x797920: r0 = IndexControllerEventBase()
    //     0x797920: bl              #0x797940  ; [package:card_swiper/src/transformer_page_view/index_controller.dart] IndexControllerEventBase::IndexControllerEventBase
    // 0x797924: add             SP, SP, #8
    // 0x797928: r0 = Null
    //     0x797928: mov             x0, NULL
    // 0x79792c: LeaveFrame
    //     0x79792c: mov             SP, fp
    //     0x797930: ldp             fp, lr, [SP], #0x10
    // 0x797934: ret
    //     0x797934: ret             
    // 0x797938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x797938: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79793c: b               #0x797914
  }
  _ AutoPlaySwiperControllerEvent.start(/* No info */) {
    // ** addr: 0x797a68, size: 0x44
    // 0x797a68: EnterFrame
    //     0x797a68: stp             fp, lr, [SP, #-0x10]!
    //     0x797a6c: mov             fp, SP
    // 0x797a70: r0 = true
    //     0x797a70: add             x0, NULL, #0x20  ; true
    // 0x797a74: CheckStackOverflow
    //     0x797a74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x797a78: cmp             SP, x16
    //     0x797a7c: b.ls            #0x797aa4
    // 0x797a80: ldr             x1, [fp, #0x10]
    // 0x797a84: StoreField: r1->field_f = r0
    //     0x797a84: stur            w0, [x1, #0xf]
    // 0x797a88: SaveReg r1
    //     0x797a88: str             x1, [SP, #-8]!
    // 0x797a8c: r0 = IndexControllerEventBase()
    //     0x797a8c: bl              #0x797940  ; [package:card_swiper/src/transformer_page_view/index_controller.dart] IndexControllerEventBase::IndexControllerEventBase
    // 0x797a90: add             SP, SP, #8
    // 0x797a94: r0 = Null
    //     0x797a94: mov             x0, NULL
    // 0x797a98: LeaveFrame
    //     0x797a98: mov             SP, fp
    //     0x797a9c: ldp             fp, lr, [SP], #0x10
    // 0x797aa0: ret
    //     0x797aa0: ret             
    // 0x797aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x797aa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x797aa8: b               #0x797a80
  }
}

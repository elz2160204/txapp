// lib: , url: package:camera_avfoundation/src/avfoundation_camera.dart

// class id: 1048709, size: 0x8
class :: {
}

// class id: 4958, size: 0x1c, field offset: 0x8
class AVFoundationCamera extends CameraPlatform {

  late final StreamController<DeviceEvent> _deviceEventStreamController; // offset: 0x10

  _ _cameraEvents(/* No info */) {
    // ** addr: 0x5aa7e4, size: 0xac
    // 0x5aa7e4: EnterFrame
    //     0x5aa7e4: stp             fp, lr, [SP, #-0x10]!
    //     0x5aa7e8: mov             fp, SP
    // 0x5aa7ec: AllocStack(0x18)
    //     0x5aa7ec: sub             SP, SP, #0x18
    // 0x5aa7f0: CheckStackOverflow
    //     0x5aa7f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5aa7f4: cmp             SP, x16
    //     0x5aa7f8: b.ls            #0x5aa888
    // 0x5aa7fc: ldr             x2, [fp, #0x10]
    // 0x5aa800: r0 = BoxInt64Instr(r2)
    //     0x5aa800: sbfiz           x0, x2, #1, #0x1f
    //     0x5aa804: cmp             x2, x0, asr #1
    //     0x5aa808: b.eq            #0x5aa814
    //     0x5aa80c: bl              #0xd69bb8
    //     0x5aa810: stur            x2, [x0, #7]
    // 0x5aa814: stur            x0, [fp, #-8]
    // 0x5aa818: r1 = 1
    //     0x5aa818: mov             x1, #1
    // 0x5aa81c: r0 = AllocateContext()
    //     0x5aa81c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5aa820: mov             x2, x0
    // 0x5aa824: ldur            x0, [fp, #-8]
    // 0x5aa828: stur            x2, [fp, #-0x10]
    // 0x5aa82c: StoreField: r2->field_f = r0
    //     0x5aa82c: stur            w0, [x2, #0xf]
    // 0x5aa830: ldr             x0, [fp, #0x18]
    // 0x5aa834: LoadField: r3 = r0->field_b
    //     0x5aa834: ldur            w3, [x0, #0xb]
    // 0x5aa838: DecompressPointer r3
    //     0x5aa838: add             x3, x3, HEAP, lsl #32
    // 0x5aa83c: stur            x3, [fp, #-8]
    // 0x5aa840: LoadField: r1 = r3->field_7
    //     0x5aa840: ldur            w1, [x3, #7]
    // 0x5aa844: DecompressPointer r1
    //     0x5aa844: add             x1, x1, HEAP, lsl #32
    // 0x5aa848: r0 = _BroadcastStream()
    //     0x5aa848: bl              #0x5a25c8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x14)
    // 0x5aa84c: mov             x3, x0
    // 0x5aa850: ldur            x0, [fp, #-8]
    // 0x5aa854: stur            x3, [fp, #-0x18]
    // 0x5aa858: StoreField: r3->field_f = r0
    //     0x5aa858: stur            w0, [x3, #0xf]
    // 0x5aa85c: ldur            x2, [fp, #-0x10]
    // 0x5aa860: r1 = Function '<anonymous closure>':.
    //     0x5aa860: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d4e8] AnonymousClosure: (0x5aa750), in [package:camera_android/src/android_camera.dart] AndroidCamera::_cameraEvents (0x5aa63c)
    //     0x5aa864: ldr             x1, [x1, #0x4e8]
    // 0x5aa868: r0 = AllocateClosure()
    //     0x5aa868: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5aa86c: ldur            x16, [fp, #-0x18]
    // 0x5aa870: stp             x0, x16, [SP, #-0x10]!
    // 0x5aa874: r0 = where()
    //     0x5aa874: bl              #0x5aa6e8  ; [dart:async] Stream::where
    // 0x5aa878: add             SP, SP, #0x10
    // 0x5aa87c: LeaveFrame
    //     0x5aa87c: mov             SP, fp
    //     0x5aa880: ldp             fp, lr, [SP], #0x10
    // 0x5aa884: ret
    //     0x5aa884: ret             
    // 0x5aa888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5aa888: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5aa88c: b               #0x5aa7fc
  }
  StreamController<DeviceEvent> _deviceEventStreamController(AVFoundationCamera) {
    // ** addr: 0x5abb40, size: 0x38
    // 0x5abb40: EnterFrame
    //     0x5abb40: stp             fp, lr, [SP, #-0x10]!
    //     0x5abb44: mov             fp, SP
    // 0x5abb48: CheckStackOverflow
    //     0x5abb48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5abb4c: cmp             SP, x16
    //     0x5abb50: b.ls            #0x5abb70
    // 0x5abb54: ldr             x16, [fp, #0x10]
    // 0x5abb58: SaveReg r16
    //     0x5abb58: str             x16, [SP, #-8]!
    // 0x5abb5c: r0 = _createDeviceEventStreamController()
    //     0x5abb5c: bl              #0x5abb78  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_createDeviceEventStreamController
    // 0x5abb60: add             SP, SP, #8
    // 0x5abb64: LeaveFrame
    //     0x5abb64: mov             SP, fp
    //     0x5abb68: ldp             fp, lr, [SP], #0x10
    // 0x5abb6c: ret
    //     0x5abb6c: ret             
    // 0x5abb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5abb70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5abb74: b               #0x5abb54
  }
  StreamController<DeviceEvent> _createDeviceEventStreamController(AVFoundationCamera) {
    // ** addr: 0x5abb78, size: 0x74
    // 0x5abb78: EnterFrame
    //     0x5abb78: stp             fp, lr, [SP, #-0x10]!
    //     0x5abb7c: mov             fp, SP
    // 0x5abb80: CheckStackOverflow
    //     0x5abb80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5abb84: cmp             SP, x16
    //     0x5abb88: b.ls            #0x5abbe4
    // 0x5abb8c: r1 = 1
    //     0x5abb8c: mov             x1, #1
    // 0x5abb90: r0 = AllocateContext()
    //     0x5abb90: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5abb94: mov             x1, x0
    // 0x5abb98: ldr             x0, [fp, #0x10]
    // 0x5abb9c: StoreField: r1->field_f = r0
    //     0x5abb9c: stur            w0, [x1, #0xf]
    // 0x5abba0: mov             x2, x1
    // 0x5abba4: r1 = Function '_handleDeviceMethodCall@177501818':.
    //     0x5abba4: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d440] AnonymousClosure: (0x5abbec), in [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_handleDeviceMethodCall (0x5abc38)
    //     0x5abba8: ldr             x1, [x1, #0x440]
    // 0x5abbac: r0 = AllocateClosure()
    //     0x5abbac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5abbb0: r16 = Instance_MethodChannel
    //     0x5abbb0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d448] Obj!MethodChannel@b34bf1
    //     0x5abbb4: ldr             x16, [x16, #0x448]
    // 0x5abbb8: stp             x0, x16, [SP, #-0x10]!
    // 0x5abbbc: r0 = setMethodCallHandler()
    //     0x5abbbc: bl              #0x5a84a0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0x5abbc0: add             SP, SP, #0x10
    // 0x5abbc4: r16 = <DeviceEvent>
    //     0x5abbc4: ldr             x16, [PP, #0xdc0]  ; [pp+0xdc0] TypeArguments: <DeviceEvent>
    // 0x5abbc8: SaveReg r16
    //     0x5abbc8: str             x16, [SP, #-8]!
    // 0x5abbcc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5abbcc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5abbd0: r0 = StreamController.broadcast()
    //     0x5abbd0: bl              #0x5a25d4  ; [dart:async] StreamController::StreamController.broadcast
    // 0x5abbd4: add             SP, SP, #8
    // 0x5abbd8: LeaveFrame
    //     0x5abbd8: mov             SP, fp
    //     0x5abbdc: ldp             fp, lr, [SP], #0x10
    // 0x5abbe0: ret
    //     0x5abbe0: ret             
    // 0x5abbe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5abbe4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5abbe8: b               #0x5abb8c
  }
  [closure] Future<dynamic> _handleDeviceMethodCall(dynamic, MethodCall) {
    // ** addr: 0x5abbec, size: 0x4c
    // 0x5abbec: EnterFrame
    //     0x5abbec: stp             fp, lr, [SP, #-0x10]!
    //     0x5abbf0: mov             fp, SP
    // 0x5abbf4: ldr             x0, [fp, #0x18]
    // 0x5abbf8: LoadField: r1 = r0->field_17
    //     0x5abbf8: ldur            w1, [x0, #0x17]
    // 0x5abbfc: DecompressPointer r1
    //     0x5abbfc: add             x1, x1, HEAP, lsl #32
    // 0x5abc00: CheckStackOverflow
    //     0x5abc00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5abc04: cmp             SP, x16
    //     0x5abc08: b.ls            #0x5abc30
    // 0x5abc0c: LoadField: r0 = r1->field_f
    //     0x5abc0c: ldur            w0, [x1, #0xf]
    // 0x5abc10: DecompressPointer r0
    //     0x5abc10: add             x0, x0, HEAP, lsl #32
    // 0x5abc14: ldr             x16, [fp, #0x10]
    // 0x5abc18: stp             x16, x0, [SP, #-0x10]!
    // 0x5abc1c: r0 = _handleDeviceMethodCall()
    //     0x5abc1c: bl              #0x5abc38  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_handleDeviceMethodCall
    // 0x5abc20: add             SP, SP, #0x10
    // 0x5abc24: LeaveFrame
    //     0x5abc24: mov             SP, fp
    //     0x5abc28: ldp             fp, lr, [SP], #0x10
    // 0x5abc2c: ret
    //     0x5abc2c: ret             
    // 0x5abc30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5abc30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5abc34: b               #0x5abc0c
  }
  _ _handleDeviceMethodCall(/* No info */) async {
    // ** addr: 0x5abc38, size: 0x168
    // 0x5abc38: EnterFrame
    //     0x5abc38: stp             fp, lr, [SP, #-0x10]!
    //     0x5abc3c: mov             fp, SP
    // 0x5abc40: AllocStack(0x18)
    //     0x5abc40: sub             SP, SP, #0x18
    // 0x5abc44: SetupParameters(AVFoundationCamera this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0x5abc44: stur            NULL, [fp, #-8]
    //     0x5abc48: mov             x0, #0
    //     0x5abc4c: add             x1, fp, w0, sxtw #2
    //     0x5abc50: ldr             x1, [x1, #0x18]
    //     0x5abc54: stur            x1, [fp, #-0x18]
    //     0x5abc58: add             x2, fp, w0, sxtw #2
    //     0x5abc5c: ldr             x2, [x2, #0x10]
    //     0x5abc60: stur            x2, [fp, #-0x10]
    // 0x5abc64: CheckStackOverflow
    //     0x5abc64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5abc68: cmp             SP, x16
    //     0x5abc6c: b.ls            #0x5abd94
    // 0x5abc70: InitAsync() -> Future
    //     0x5abc70: mov             x0, NULL
    //     0x5abc74: bl              #0x4b92e4
    // 0x5abc78: ldur            x0, [fp, #-0x10]
    // 0x5abc7c: LoadField: r1 = r0->field_7
    //     0x5abc7c: ldur            w1, [x0, #7]
    // 0x5abc80: DecompressPointer r1
    //     0x5abc80: add             x1, x1, HEAP, lsl #32
    // 0x5abc84: r16 = "orientation_changed"
    //     0x5abc84: ldr             x16, [PP, #0xdd8]  ; [pp+0xdd8] "orientation_changed"
    // 0x5abc88: stp             x1, x16, [SP, #-0x10]!
    // 0x5abc8c: r0 = ==()
    //     0x5abc8c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x5abc90: add             SP, SP, #0x10
    // 0x5abc94: tbnz            w0, #4, #0x5abd88
    // 0x5abc98: ldur            x16, [fp, #-0x18]
    // 0x5abc9c: ldur            lr, [fp, #-0x10]
    // 0x5abca0: stp             lr, x16, [SP, #-0x10]!
    // 0x5abca4: r0 = _getArgumentDictionary()
    //     0x5abca4: bl              #0x5abda0  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_getArgumentDictionary
    // 0x5abca8: add             SP, SP, #0x10
    // 0x5abcac: ldur            x1, [fp, #-0x18]
    // 0x5abcb0: stur            x0, [fp, #-0x10]
    // 0x5abcb4: LoadField: r0 = r1->field_f
    //     0x5abcb4: ldur            w0, [x1, #0xf]
    // 0x5abcb8: DecompressPointer r0
    //     0x5abcb8: add             x0, x0, HEAP, lsl #32
    // 0x5abcbc: r16 = Sentinel
    //     0x5abcbc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5abcc0: cmp             w0, w16
    // 0x5abcc4: b.ne            #0x5abcd4
    // 0x5abcc8: r2 = _deviceEventStreamController
    //     0x5abcc8: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d390] Field <AVFoundationCamera._deviceEventStreamController@177501818>: late final (offset: 0x10)
    //     0x5abccc: ldr             x2, [x2, #0x390]
    // 0x5abcd0: r0 = InitLateFinalInstanceField()
    //     0x5abcd0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x5abcd4: mov             x1, x0
    // 0x5abcd8: ldur            x0, [fp, #-0x10]
    // 0x5abcdc: stur            x1, [fp, #-0x18]
    // 0x5abce0: r2 = LoadClassIdInstr(r0)
    //     0x5abce0: ldur            x2, [x0, #-1]
    //     0x5abce4: ubfx            x2, x2, #0xc, #0x14
    // 0x5abce8: r16 = "orientation"
    //     0x5abce8: ldr             x16, [PP, #0xde0]  ; [pp+0xde0] "orientation"
    // 0x5abcec: stp             x16, x0, [SP, #-0x10]!
    // 0x5abcf0: mov             x0, x2
    // 0x5abcf4: r0 = GDT[cid_x0 + -0xef]()
    //     0x5abcf4: sub             lr, x0, #0xef
    //     0x5abcf8: ldr             lr, [x21, lr, lsl #3]
    //     0x5abcfc: blr             lr
    // 0x5abd00: add             SP, SP, #0x10
    // 0x5abd04: mov             x3, x0
    // 0x5abd08: stur            x3, [fp, #-0x10]
    // 0x5abd0c: cmp             w3, NULL
    // 0x5abd10: b.eq            #0x5abd9c
    // 0x5abd14: mov             x0, x3
    // 0x5abd18: r2 = Null
    //     0x5abd18: mov             x2, NULL
    // 0x5abd1c: r1 = Null
    //     0x5abd1c: mov             x1, NULL
    // 0x5abd20: r4 = 59
    //     0x5abd20: mov             x4, #0x3b
    // 0x5abd24: branchIfSmi(r0, 0x5abd30)
    //     0x5abd24: tbz             w0, #0, #0x5abd30
    // 0x5abd28: r4 = LoadClassIdInstr(r0)
    //     0x5abd28: ldur            x4, [x0, #-1]
    //     0x5abd2c: ubfx            x4, x4, #0xc, #0x14
    // 0x5abd30: sub             x4, x4, #0x5d
    // 0x5abd34: cmp             x4, #3
    // 0x5abd38: b.ls            #0x5abd4c
    // 0x5abd3c: r8 = String
    //     0x5abd3c: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x5abd40: r3 = Null
    //     0x5abd40: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d450] Null
    //     0x5abd44: ldr             x3, [x3, #0x450]
    // 0x5abd48: r0 = String()
    //     0x5abd48: bl              #0xd72afc  ; IsType_String_Stub
    // 0x5abd4c: ldur            x16, [fp, #-0x10]
    // 0x5abd50: SaveReg r16
    //     0x5abd50: str             x16, [SP, #-8]!
    // 0x5abd54: r0 = deserializeDeviceOrientation()
    //     0x5abd54: bl              #0x5a89d0  ; [package:camera_android/src/utils.dart] ::deserializeDeviceOrientation
    // 0x5abd58: add             SP, SP, #8
    // 0x5abd5c: stur            x0, [fp, #-0x10]
    // 0x5abd60: r0 = DeviceOrientationChangedEvent()
    //     0x5abd60: bl              #0x5a88f4  ; AllocateDeviceOrientationChangedEventStub -> DeviceOrientationChangedEvent (size=0xc)
    // 0x5abd64: mov             x1, x0
    // 0x5abd68: ldur            x0, [fp, #-0x10]
    // 0x5abd6c: StoreField: r1->field_7 = r0
    //     0x5abd6c: stur            w0, [x1, #7]
    // 0x5abd70: ldur            x16, [fp, #-0x18]
    // 0x5abd74: stp             x1, x16, [SP, #-0x10]!
    // 0x5abd78: r0 = add()
    //     0x5abd78: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0x5abd7c: add             SP, SP, #0x10
    // 0x5abd80: r0 = Null
    //     0x5abd80: mov             x0, NULL
    // 0x5abd84: r0 = ReturnAsyncNotFuture()
    //     0x5abd84: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x5abd88: r0 = MissingPluginException()
    //     0x5abd88: bl              #0x501aa4  ; AllocateMissingPluginExceptionStub -> MissingPluginException (size=0xc)
    // 0x5abd8c: r0 = Throw()
    //     0x5abd8c: bl              #0xd67e38  ; ThrowStub
    // 0x5abd90: brk             #0
    // 0x5abd94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5abd94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5abd98: b               #0x5abc70
    // 0x5abd9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5abd9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getArgumentDictionary(/* No info */) {
    // ** addr: 0x5abda0, size: 0x84
    // 0x5abda0: EnterFrame
    //     0x5abda0: stp             fp, lr, [SP, #-0x10]!
    //     0x5abda4: mov             fp, SP
    // 0x5abda8: AllocStack(0x8)
    //     0x5abda8: sub             SP, SP, #8
    // 0x5abdac: CheckStackOverflow
    //     0x5abdac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5abdb0: cmp             SP, x16
    //     0x5abdb4: b.ls            #0x5abe1c
    // 0x5abdb8: ldr             x0, [fp, #0x10]
    // 0x5abdbc: LoadField: r3 = r0->field_b
    //     0x5abdbc: ldur            w3, [x0, #0xb]
    // 0x5abdc0: DecompressPointer r3
    //     0x5abdc0: add             x3, x3, HEAP, lsl #32
    // 0x5abdc4: mov             x0, x3
    // 0x5abdc8: stur            x3, [fp, #-8]
    // 0x5abdcc: r2 = Null
    //     0x5abdcc: mov             x2, NULL
    // 0x5abdd0: r1 = Null
    //     0x5abdd0: mov             x1, NULL
    // 0x5abdd4: r8 = Map<Object?, Object?>
    //     0x5abdd4: ldr             x8, [PP, #0xe70]  ; [pp+0xe70] Type: Map<Object?, Object?>
    // 0x5abdd8: r3 = Null
    //     0x5abdd8: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d460] Null
    //     0x5abddc: ldr             x3, [x3, #0x460]
    // 0x5abde0: r0 = Map<Object?, Object?>()
    //     0x5abde0: bl              #0x5a8b90  ; IsType_Map<Object?, Object?>_Stub
    // 0x5abde4: ldur            x0, [fp, #-8]
    // 0x5abde8: r1 = LoadClassIdInstr(r0)
    //     0x5abde8: ldur            x1, [x0, #-1]
    //     0x5abdec: ubfx            x1, x1, #0xc, #0x14
    // 0x5abdf0: r16 = <String, Object?>
    //     0x5abdf0: ldr             x16, [PP, #0xe88]  ; [pp+0xe88] TypeArguments: <String, Object?>
    // 0x5abdf4: stp             x0, x16, [SP, #-0x10]!
    // 0x5abdf8: mov             x0, x1
    // 0x5abdfc: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x5abdfc: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x5abe00: r0 = GDT[cid_x0 + 0x375]()
    //     0x5abe00: add             lr, x0, #0x375
    //     0x5abe04: ldr             lr, [x21, lr, lsl #3]
    //     0x5abe08: blr             lr
    // 0x5abe0c: add             SP, SP, #0x10
    // 0x5abe10: LeaveFrame
    //     0x5abe10: mov             SP, fp
    //     0x5abe14: ldp             fp, lr, [SP], #0x10
    // 0x5abe18: ret
    //     0x5abe18: ret             
    // 0x5abe1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5abe1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5abe20: b               #0x5abdb8
  }
  _ resumePreview(/* No info */) async {
    // ** addr: 0xc5f2d8, size: 0xc0
    // 0xc5f2d8: EnterFrame
    //     0xc5f2d8: stp             fp, lr, [SP, #-0x10]!
    //     0xc5f2dc: mov             fp, SP
    // 0xc5f2e0: AllocStack(0x18)
    //     0xc5f2e0: sub             SP, SP, #0x18
    // 0xc5f2e4: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */)
    //     0xc5f2e4: stur            NULL, [fp, #-8]
    //     0xc5f2e8: mov             x0, #0
    //     0xc5f2ec: add             x1, fp, w0, sxtw #2
    //     0xc5f2f0: ldr             x1, [x1, #0x10]
    //     0xc5f2f4: stur            x1, [fp, #-0x10]
    // 0xc5f2f8: CheckStackOverflow
    //     0xc5f2f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5f2fc: cmp             SP, x16
    //     0xc5f300: b.ls            #0xc5f390
    // 0xc5f304: InitAsync() -> Future<void?>
    //     0xc5f304: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc5f308: bl              #0x4b92e4
    // 0xc5f30c: r1 = Null
    //     0xc5f30c: mov             x1, NULL
    // 0xc5f310: r2 = 4
    //     0xc5f310: mov             x2, #4
    // 0xc5f314: r0 = AllocateArray()
    //     0xc5f314: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5f318: mov             x2, x0
    // 0xc5f31c: r17 = "cameraId"
    //     0xc5f31c: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5f320: ldr             x17, [x17, #0x890]
    // 0xc5f324: StoreField: r2->field_f = r17
    //     0xc5f324: stur            w17, [x2, #0xf]
    // 0xc5f328: ldur            x3, [fp, #-0x10]
    // 0xc5f32c: r0 = BoxInt64Instr(r3)
    //     0xc5f32c: sbfiz           x0, x3, #1, #0x1f
    //     0xc5f330: cmp             x3, x0, asr #1
    //     0xc5f334: b.eq            #0xc5f340
    //     0xc5f338: bl              #0xd69bb8
    //     0xc5f33c: stur            x3, [x0, #7]
    // 0xc5f340: StoreField: r2->field_13 = r0
    //     0xc5f340: stur            w0, [x2, #0x13]
    // 0xc5f344: r16 = <String, dynamic>
    //     0xc5f344: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5f348: stp             x2, x16, [SP, #-0x10]!
    // 0xc5f34c: r0 = Map._fromLiteral()
    //     0xc5f34c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5f350: add             SP, SP, #0x10
    // 0xc5f354: r16 = <double>
    //     0xc5f354: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5f358: r30 = Instance_MethodChannel
    //     0xc5f358: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc5f35c: ldr             lr, [lr, #0x370]
    // 0xc5f360: stp             lr, x16, [SP, #-0x10]!
    // 0xc5f364: r16 = "resumePreview"
    //     0xc5f364: add             x16, PP, #0x53, lsl #12  ; [pp+0x53ac8] "resumePreview"
    //     0xc5f368: ldr             x16, [x16, #0xac8]
    // 0xc5f36c: stp             x0, x16, [SP, #-0x10]!
    // 0xc5f370: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5f370: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5f374: r0 = invokeMethod()
    //     0xc5f374: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5f378: add             SP, SP, #0x20
    // 0xc5f37c: mov             x1, x0
    // 0xc5f380: stur            x1, [fp, #-0x18]
    // 0xc5f384: r0 = Await()
    //     0xc5f384: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5f388: r0 = Null
    //     0xc5f388: mov             x0, NULL
    // 0xc5f38c: r0 = ReturnAsyncNotFuture()
    //     0xc5f38c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc5f390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5f390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5f394: b               #0xc5f304
  }
  _ pausePreview(/* No info */) async {
    // ** addr: 0xc5f518, size: 0xc0
    // 0xc5f518: EnterFrame
    //     0xc5f518: stp             fp, lr, [SP, #-0x10]!
    //     0xc5f51c: mov             fp, SP
    // 0xc5f520: AllocStack(0x18)
    //     0xc5f520: sub             SP, SP, #0x18
    // 0xc5f524: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */)
    //     0xc5f524: stur            NULL, [fp, #-8]
    //     0xc5f528: mov             x0, #0
    //     0xc5f52c: add             x1, fp, w0, sxtw #2
    //     0xc5f530: ldr             x1, [x1, #0x10]
    //     0xc5f534: stur            x1, [fp, #-0x10]
    // 0xc5f538: CheckStackOverflow
    //     0xc5f538: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5f53c: cmp             SP, x16
    //     0xc5f540: b.ls            #0xc5f5d0
    // 0xc5f544: InitAsync() -> Future<void?>
    //     0xc5f544: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc5f548: bl              #0x4b92e4
    // 0xc5f54c: r1 = Null
    //     0xc5f54c: mov             x1, NULL
    // 0xc5f550: r2 = 4
    //     0xc5f550: mov             x2, #4
    // 0xc5f554: r0 = AllocateArray()
    //     0xc5f554: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5f558: mov             x2, x0
    // 0xc5f55c: r17 = "cameraId"
    //     0xc5f55c: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5f560: ldr             x17, [x17, #0x890]
    // 0xc5f564: StoreField: r2->field_f = r17
    //     0xc5f564: stur            w17, [x2, #0xf]
    // 0xc5f568: ldur            x3, [fp, #-0x10]
    // 0xc5f56c: r0 = BoxInt64Instr(r3)
    //     0xc5f56c: sbfiz           x0, x3, #1, #0x1f
    //     0xc5f570: cmp             x3, x0, asr #1
    //     0xc5f574: b.eq            #0xc5f580
    //     0xc5f578: bl              #0xd69bb8
    //     0xc5f57c: stur            x3, [x0, #7]
    // 0xc5f580: StoreField: r2->field_13 = r0
    //     0xc5f580: stur            w0, [x2, #0x13]
    // 0xc5f584: r16 = <String, dynamic>
    //     0xc5f584: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5f588: stp             x2, x16, [SP, #-0x10]!
    // 0xc5f58c: r0 = Map._fromLiteral()
    //     0xc5f58c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5f590: add             SP, SP, #0x10
    // 0xc5f594: r16 = <double>
    //     0xc5f594: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5f598: r30 = Instance_MethodChannel
    //     0xc5f598: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc5f59c: ldr             lr, [lr, #0x370]
    // 0xc5f5a0: stp             lr, x16, [SP, #-0x10]!
    // 0xc5f5a4: r16 = "pausePreview"
    //     0xc5f5a4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53ad0] "pausePreview"
    //     0xc5f5a8: ldr             x16, [x16, #0xad0]
    // 0xc5f5ac: stp             x0, x16, [SP, #-0x10]!
    // 0xc5f5b0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5f5b0: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5f5b4: r0 = invokeMethod()
    //     0xc5f5b4: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5f5b8: add             SP, SP, #0x20
    // 0xc5f5bc: mov             x1, x0
    // 0xc5f5c0: stur            x1, [fp, #-0x18]
    // 0xc5f5c4: r0 = Await()
    //     0xc5f5c4: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5f5c8: r0 = Null
    //     0xc5f5c8: mov             x0, NULL
    // 0xc5f5cc: r0 = ReturnAsyncNotFuture()
    //     0xc5f5cc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc5f5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5f5d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5f5d4: b               #0xc5f544
  }
  _ setZoomLevel(/* No info */) async {
    // ** addr: 0xc5f884, size: 0x184
    // 0xc5f884: EnterFrame
    //     0xc5f884: stp             fp, lr, [SP, #-0x10]!
    //     0xc5f888: mov             fp, SP
    // 0xc5f88c: AllocStack(0x68)
    //     0xc5f88c: sub             SP, SP, #0x68
    // 0xc5f890: SetupParameters(AVFoundationCamera this /* r1, fp-0x60 */, dynamic _ /* r2, fp-0x58 */, dynamic _ /* d0, fp-0x68 */)
    //     0xc5f890: stur            NULL, [fp, #-8]
    //     0xc5f894: mov             x0, #0
    //     0xc5f898: add             x1, fp, w0, sxtw #2
    //     0xc5f89c: ldr             x1, [x1, #0x20]
    //     0xc5f8a0: stur            x1, [fp, #-0x60]
    //     0xc5f8a4: add             x2, fp, w0, sxtw #2
    //     0xc5f8a8: ldr             x2, [x2, #0x18]
    //     0xc5f8ac: stur            x2, [fp, #-0x58]
    //     0xc5f8b0: add             x3, fp, w0, sxtw #2
    //     0xc5f8b4: ldr             d0, [x3, #0x10]
    //     0xc5f8b8: stur            d0, [fp, #-0x68]
    // 0xc5f8bc: CheckStackOverflow
    //     0xc5f8bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5f8c0: cmp             SP, x16
    //     0xc5f8c4: b.ls            #0xc5f9e4
    // 0xc5f8c8: InitAsync() -> Future<void?>
    //     0xc5f8c8: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc5f8cc: bl              #0x4b92e4
    // 0xc5f8d0: ldur            x0, [fp, #-0x58]
    // 0xc5f8d4: ldur            d0, [fp, #-0x68]
    // 0xc5f8d8: r1 = Null
    //     0xc5f8d8: mov             x1, NULL
    // 0xc5f8dc: r2 = 8
    //     0xc5f8dc: mov             x2, #8
    // 0xc5f8e0: r0 = AllocateArray()
    //     0xc5f8e0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5f8e4: r17 = "cameraId"
    //     0xc5f8e4: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5f8e8: ldr             x17, [x17, #0x890]
    // 0xc5f8ec: StoreField: r0->field_f = r17
    //     0xc5f8ec: stur            w17, [x0, #0xf]
    // 0xc5f8f0: ldur            x1, [fp, #-0x58]
    // 0xc5f8f4: StoreField: r0->field_13 = r1
    //     0xc5f8f4: stur            w1, [x0, #0x13]
    // 0xc5f8f8: r17 = "zoom"
    //     0xc5f8f8: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ad8] "zoom"
    //     0xc5f8fc: ldr             x17, [x17, #0xad8]
    // 0xc5f900: StoreField: r0->field_17 = r17
    //     0xc5f900: stur            w17, [x0, #0x17]
    // 0xc5f904: ldur            d0, [fp, #-0x68]
    // 0xc5f908: r1 = inline_Allocate_Double()
    //     0xc5f908: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc5f90c: add             x1, x1, #0x10
    //     0xc5f910: cmp             x2, x1
    //     0xc5f914: b.ls            #0xc5f9ec
    //     0xc5f918: str             x1, [THR, #0x60]  ; THR::top
    //     0xc5f91c: sub             x1, x1, #0xf
    //     0xc5f920: mov             x2, #0xd108
    //     0xc5f924: movk            x2, #3, lsl #16
    //     0xc5f928: stur            x2, [x1, #-1]
    // 0xc5f92c: StoreField: r1->field_7 = d0
    //     0xc5f92c: stur            d0, [x1, #7]
    // 0xc5f930: StoreField: r0->field_1b = r1
    //     0xc5f930: stur            w1, [x0, #0x1b]
    // 0xc5f934: r16 = <String, dynamic>
    //     0xc5f934: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5f938: stp             x0, x16, [SP, #-0x10]!
    // 0xc5f93c: r0 = Map._fromLiteral()
    //     0xc5f93c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5f940: add             SP, SP, #0x10
    // 0xc5f944: r16 = <double>
    //     0xc5f944: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5f948: r30 = Instance_MethodChannel
    //     0xc5f948: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc5f94c: ldr             lr, [lr, #0x370]
    // 0xc5f950: stp             lr, x16, [SP, #-0x10]!
    // 0xc5f954: r16 = "setZoomLevel"
    //     0xc5f954: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d268] "setZoomLevel"
    //     0xc5f958: ldr             x16, [x16, #0x268]
    // 0xc5f95c: stp             x0, x16, [SP, #-0x10]!
    // 0xc5f960: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5f960: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5f964: r0 = invokeMethod()
    //     0xc5f964: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5f968: add             SP, SP, #0x20
    // 0xc5f96c: mov             x1, x0
    // 0xc5f970: stur            x1, [fp, #-0x58]
    // 0xc5f974: r0 = Await()
    //     0xc5f974: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5f978: r0 = Null
    //     0xc5f978: mov             x0, NULL
    // 0xc5f97c: r0 = ReturnAsyncNotFuture()
    //     0xc5f97c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc5f980: sub             SP, fp, #0x68
    // 0xc5f984: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc5f984: mov             x2, #0x76
    //     0xc5f988: tbz             w0, #0, #0xc5f998
    //     0xc5f98c: ldur            x2, [x0, #-1]
    //     0xc5f990: ubfx            x2, x2, #0xc, #0x14
    //     0xc5f994: lsl             x2, x2, #1
    // 0xc5f998: cmp             w2, #0xf28
    // 0xc5f99c: b.ne            #0xc5f9dc
    // 0xc5f9a0: LoadField: r1 = r0->field_7
    //     0xc5f9a0: ldur            w1, [x0, #7]
    // 0xc5f9a4: DecompressPointer r1
    //     0xc5f9a4: add             x1, x1, HEAP, lsl #32
    // 0xc5f9a8: stur            x1, [fp, #-0x60]
    // 0xc5f9ac: LoadField: r2 = r0->field_b
    //     0xc5f9ac: ldur            w2, [x0, #0xb]
    // 0xc5f9b0: DecompressPointer r2
    //     0xc5f9b0: add             x2, x2, HEAP, lsl #32
    // 0xc5f9b4: stur            x2, [fp, #-0x58]
    // 0xc5f9b8: r0 = CameraException()
    //     0xc5f9b8: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc5f9bc: mov             x1, x0
    // 0xc5f9c0: ldur            x0, [fp, #-0x60]
    // 0xc5f9c4: StoreField: r1->field_7 = r0
    //     0xc5f9c4: stur            w0, [x1, #7]
    // 0xc5f9c8: ldur            x0, [fp, #-0x58]
    // 0xc5f9cc: StoreField: r1->field_b = r0
    //     0xc5f9cc: stur            w0, [x1, #0xb]
    // 0xc5f9d0: mov             x0, x1
    // 0xc5f9d4: r0 = Throw()
    //     0xc5f9d4: bl              #0xd67e38  ; ThrowStub
    // 0xc5f9d8: brk             #0
    // 0xc5f9dc: r0 = ReThrow()
    //     0xc5f9dc: bl              #0xd67e14  ; ReThrowStub
    // 0xc5f9e0: brk             #0
    // 0xc5f9e4: r0 = StackOverflowSharedWithFPURegs()
    //     0xc5f9e4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc5f9e8: b               #0xc5f8c8
    // 0xc5f9ec: SaveReg d0
    //     0xc5f9ec: str             q0, [SP, #-0x10]!
    // 0xc5f9f0: SaveReg r0
    //     0xc5f9f0: str             x0, [SP, #-8]!
    // 0xc5f9f4: r0 = AllocateDouble()
    //     0xc5f9f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc5f9f8: mov             x1, x0
    // 0xc5f9fc: RestoreReg r0
    //     0xc5f9fc: ldr             x0, [SP], #8
    // 0xc5fa00: RestoreReg d0
    //     0xc5fa00: ldr             q0, [SP], #0x10
    // 0xc5fa04: b               #0xc5f92c
  }
  _ getMinZoomLevel(/* No info */) async {
    // ** addr: 0xc5fcf0, size: 0xc8
    // 0xc5fcf0: EnterFrame
    //     0xc5fcf0: stp             fp, lr, [SP, #-0x10]!
    //     0xc5fcf4: mov             fp, SP
    // 0xc5fcf8: AllocStack(0x18)
    //     0xc5fcf8: sub             SP, SP, #0x18
    // 0xc5fcfc: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */)
    //     0xc5fcfc: stur            NULL, [fp, #-8]
    //     0xc5fd00: mov             x0, #0
    //     0xc5fd04: add             x1, fp, w0, sxtw #2
    //     0xc5fd08: ldr             x1, [x1, #0x10]
    //     0xc5fd0c: stur            x1, [fp, #-0x10]
    // 0xc5fd10: CheckStackOverflow
    //     0xc5fd10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5fd14: cmp             SP, x16
    //     0xc5fd18: b.ls            #0xc5fdac
    // 0xc5fd1c: InitAsync() -> Future<double>
    //     0xc5fd1c: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc5fd20: bl              #0x4b92e4
    // 0xc5fd24: r1 = Null
    //     0xc5fd24: mov             x1, NULL
    // 0xc5fd28: r2 = 4
    //     0xc5fd28: mov             x2, #4
    // 0xc5fd2c: r0 = AllocateArray()
    //     0xc5fd2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5fd30: mov             x2, x0
    // 0xc5fd34: r17 = "cameraId"
    //     0xc5fd34: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5fd38: ldr             x17, [x17, #0x890]
    // 0xc5fd3c: StoreField: r2->field_f = r17
    //     0xc5fd3c: stur            w17, [x2, #0xf]
    // 0xc5fd40: ldur            x3, [fp, #-0x10]
    // 0xc5fd44: r0 = BoxInt64Instr(r3)
    //     0xc5fd44: sbfiz           x0, x3, #1, #0x1f
    //     0xc5fd48: cmp             x3, x0, asr #1
    //     0xc5fd4c: b.eq            #0xc5fd58
    //     0xc5fd50: bl              #0xd69bb8
    //     0xc5fd54: stur            x3, [x0, #7]
    // 0xc5fd58: StoreField: r2->field_13 = r0
    //     0xc5fd58: stur            w0, [x2, #0x13]
    // 0xc5fd5c: r16 = <String, dynamic>
    //     0xc5fd5c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5fd60: stp             x2, x16, [SP, #-0x10]!
    // 0xc5fd64: r0 = Map._fromLiteral()
    //     0xc5fd64: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5fd68: add             SP, SP, #0x10
    // 0xc5fd6c: r16 = <double>
    //     0xc5fd6c: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5fd70: r30 = Instance_MethodChannel
    //     0xc5fd70: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc5fd74: ldr             lr, [lr, #0x370]
    // 0xc5fd78: stp             lr, x16, [SP, #-0x10]!
    // 0xc5fd7c: r16 = "getMinZoomLevel"
    //     0xc5fd7c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d338] "getMinZoomLevel"
    //     0xc5fd80: ldr             x16, [x16, #0x338]
    // 0xc5fd84: stp             x0, x16, [SP, #-0x10]!
    // 0xc5fd88: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5fd88: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5fd8c: r0 = invokeMethod()
    //     0xc5fd8c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5fd90: add             SP, SP, #0x20
    // 0xc5fd94: mov             x1, x0
    // 0xc5fd98: stur            x1, [fp, #-0x18]
    // 0xc5fd9c: r0 = Await()
    //     0xc5fd9c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5fda0: cmp             w0, NULL
    // 0xc5fda4: b.eq            #0xc5fdb4
    // 0xc5fda8: r0 = ReturnAsync()
    //     0xc5fda8: b               #0x501858  ; ReturnAsyncStub
    // 0xc5fdac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5fdac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5fdb0: b               #0xc5fd1c
    // 0xc5fdb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc5fdb4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMaxZoomLevel(/* No info */) async {
    // ** addr: 0xc60270, size: 0xc8
    // 0xc60270: EnterFrame
    //     0xc60270: stp             fp, lr, [SP, #-0x10]!
    //     0xc60274: mov             fp, SP
    // 0xc60278: AllocStack(0x18)
    //     0xc60278: sub             SP, SP, #0x18
    // 0xc6027c: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */)
    //     0xc6027c: stur            NULL, [fp, #-8]
    //     0xc60280: mov             x0, #0
    //     0xc60284: add             x1, fp, w0, sxtw #2
    //     0xc60288: ldr             x1, [x1, #0x10]
    //     0xc6028c: stur            x1, [fp, #-0x10]
    // 0xc60290: CheckStackOverflow
    //     0xc60290: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc60294: cmp             SP, x16
    //     0xc60298: b.ls            #0xc6032c
    // 0xc6029c: InitAsync() -> Future<double>
    //     0xc6029c: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc602a0: bl              #0x4b92e4
    // 0xc602a4: r1 = Null
    //     0xc602a4: mov             x1, NULL
    // 0xc602a8: r2 = 4
    //     0xc602a8: mov             x2, #4
    // 0xc602ac: r0 = AllocateArray()
    //     0xc602ac: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc602b0: mov             x2, x0
    // 0xc602b4: r17 = "cameraId"
    //     0xc602b4: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc602b8: ldr             x17, [x17, #0x890]
    // 0xc602bc: StoreField: r2->field_f = r17
    //     0xc602bc: stur            w17, [x2, #0xf]
    // 0xc602c0: ldur            x3, [fp, #-0x10]
    // 0xc602c4: r0 = BoxInt64Instr(r3)
    //     0xc602c4: sbfiz           x0, x3, #1, #0x1f
    //     0xc602c8: cmp             x3, x0, asr #1
    //     0xc602cc: b.eq            #0xc602d8
    //     0xc602d0: bl              #0xd69bb8
    //     0xc602d4: stur            x3, [x0, #7]
    // 0xc602d8: StoreField: r2->field_13 = r0
    //     0xc602d8: stur            w0, [x2, #0x13]
    // 0xc602dc: r16 = <String, dynamic>
    //     0xc602dc: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc602e0: stp             x2, x16, [SP, #-0x10]!
    // 0xc602e4: r0 = Map._fromLiteral()
    //     0xc602e4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc602e8: add             SP, SP, #0x10
    // 0xc602ec: r16 = <double>
    //     0xc602ec: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc602f0: r30 = Instance_MethodChannel
    //     0xc602f0: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc602f4: ldr             lr, [lr, #0x370]
    // 0xc602f8: stp             lr, x16, [SP, #-0x10]!
    // 0xc602fc: r16 = "getMaxZoomLevel"
    //     0xc602fc: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d340] "getMaxZoomLevel"
    //     0xc60300: ldr             x16, [x16, #0x340]
    // 0xc60304: stp             x0, x16, [SP, #-0x10]!
    // 0xc60308: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc60308: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6030c: r0 = invokeMethod()
    //     0xc6030c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc60310: add             SP, SP, #0x20
    // 0xc60314: mov             x1, x0
    // 0xc60318: stur            x1, [fp, #-0x18]
    // 0xc6031c: r0 = Await()
    //     0xc6031c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc60320: cmp             w0, NULL
    // 0xc60324: b.eq            #0xc60334
    // 0xc60328: r0 = ReturnAsync()
    //     0xc60328: b               #0x501858  ; ReturnAsyncStub
    // 0xc6032c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6032c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc60330: b               #0xc6029c
    // 0xc60334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc60334: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setFocusPoint(/* No info */) {
    // ** addr: 0xc606ac, size: 0x180
    // 0xc606ac: EnterFrame
    //     0xc606ac: stp             fp, lr, [SP, #-0x10]!
    //     0xc606b0: mov             fp, SP
    // 0xc606b4: CheckStackOverflow
    //     0xc606b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc606b8: cmp             SP, x16
    //     0xc606bc: b.ls            #0xc607f0
    // 0xc606c0: r1 = Null
    //     0xc606c0: mov             x1, NULL
    // 0xc606c4: r2 = 16
    //     0xc606c4: mov             x2, #0x10
    // 0xc606c8: r0 = AllocateArray()
    //     0xc606c8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc606cc: mov             x2, x0
    // 0xc606d0: r17 = "cameraId"
    //     0xc606d0: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc606d4: ldr             x17, [x17, #0x890]
    // 0xc606d8: StoreField: r2->field_f = r17
    //     0xc606d8: stur            w17, [x2, #0xf]
    // 0xc606dc: ldr             x3, [fp, #0x18]
    // 0xc606e0: r0 = BoxInt64Instr(r3)
    //     0xc606e0: sbfiz           x0, x3, #1, #0x1f
    //     0xc606e4: cmp             x3, x0, asr #1
    //     0xc606e8: b.eq            #0xc606f4
    //     0xc606ec: bl              #0xd69bb8
    //     0xc606f0: stur            x3, [x0, #7]
    // 0xc606f4: StoreField: r2->field_13 = r0
    //     0xc606f4: stur            w0, [x2, #0x13]
    // 0xc606f8: r17 = "reset"
    //     0xc606f8: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ae0] "reset"
    //     0xc606fc: ldr             x17, [x17, #0xae0]
    // 0xc60700: StoreField: r2->field_17 = r17
    //     0xc60700: stur            w17, [x2, #0x17]
    // 0xc60704: ldr             x0, [fp, #0x10]
    // 0xc60708: cmp             w0, NULL
    // 0xc6070c: r16 = true
    //     0xc6070c: add             x16, NULL, #0x20  ; true
    // 0xc60710: r17 = false
    //     0xc60710: add             x17, NULL, #0x30  ; false
    // 0xc60714: csel            x1, x16, x17, eq
    // 0xc60718: StoreField: r2->field_1b = r1
    //     0xc60718: stur            w1, [x2, #0x1b]
    // 0xc6071c: r17 = "x"
    //     0xc6071c: ldr             x17, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xc60720: StoreField: r2->field_1f = r17
    //     0xc60720: stur            w17, [x2, #0x1f]
    // 0xc60724: cmp             w0, NULL
    // 0xc60728: b.ne            #0xc60734
    // 0xc6072c: r1 = Null
    //     0xc6072c: mov             x1, NULL
    // 0xc60730: b               #0xc60760
    // 0xc60734: LoadField: d0 = r0->field_b
    //     0xc60734: ldur            d0, [x0, #0xb]
    // 0xc60738: r1 = inline_Allocate_Double()
    //     0xc60738: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xc6073c: add             x1, x1, #0x10
    //     0xc60740: cmp             x3, x1
    //     0xc60744: b.ls            #0xc607f8
    //     0xc60748: str             x1, [THR, #0x60]  ; THR::top
    //     0xc6074c: sub             x1, x1, #0xf
    //     0xc60750: mov             x3, #0xd108
    //     0xc60754: movk            x3, #3, lsl #16
    //     0xc60758: stur            x3, [x1, #-1]
    // 0xc6075c: StoreField: r1->field_7 = d0
    //     0xc6075c: stur            d0, [x1, #7]
    // 0xc60760: StoreField: r2->field_23 = r1
    //     0xc60760: stur            w1, [x2, #0x23]
    // 0xc60764: r17 = "y"
    //     0xc60764: ldr             x17, [PP, #0x78d0]  ; [pp+0x78d0] "y"
    // 0xc60768: StoreField: r2->field_27 = r17
    //     0xc60768: stur            w17, [x2, #0x27]
    // 0xc6076c: cmp             w0, NULL
    // 0xc60770: b.ne            #0xc6077c
    // 0xc60774: r0 = Null
    //     0xc60774: mov             x0, NULL
    // 0xc60778: b               #0xc607a8
    // 0xc6077c: LoadField: d0 = r0->field_13
    //     0xc6077c: ldur            d0, [x0, #0x13]
    // 0xc60780: r0 = inline_Allocate_Double()
    //     0xc60780: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc60784: add             x0, x0, #0x10
    //     0xc60788: cmp             x1, x0
    //     0xc6078c: b.ls            #0xc60814
    //     0xc60790: str             x0, [THR, #0x60]  ; THR::top
    //     0xc60794: sub             x0, x0, #0xf
    //     0xc60798: mov             x1, #0xd108
    //     0xc6079c: movk            x1, #3, lsl #16
    //     0xc607a0: stur            x1, [x0, #-1]
    // 0xc607a4: StoreField: r0->field_7 = d0
    //     0xc607a4: stur            d0, [x0, #7]
    // 0xc607a8: StoreField: r2->field_2b = r0
    //     0xc607a8: stur            w0, [x2, #0x2b]
    // 0xc607ac: r16 = <String, dynamic>
    //     0xc607ac: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc607b0: stp             x2, x16, [SP, #-0x10]!
    // 0xc607b4: r0 = Map._fromLiteral()
    //     0xc607b4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc607b8: add             SP, SP, #0x10
    // 0xc607bc: r16 = <void?>
    //     0xc607bc: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc607c0: r30 = Instance_MethodChannel
    //     0xc607c0: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc607c4: ldr             lr, [lr, #0x370]
    // 0xc607c8: stp             lr, x16, [SP, #-0x10]!
    // 0xc607cc: r16 = "setFocusPoint"
    //     0xc607cc: add             x16, PP, #0x53, lsl #12  ; [pp+0x53ae8] "setFocusPoint"
    //     0xc607d0: ldr             x16, [x16, #0xae8]
    // 0xc607d4: stp             x0, x16, [SP, #-0x10]!
    // 0xc607d8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc607d8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc607dc: r0 = invokeMethod()
    //     0xc607dc: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc607e0: add             SP, SP, #0x20
    // 0xc607e4: LeaveFrame
    //     0xc607e4: mov             SP, fp
    //     0xc607e8: ldp             fp, lr, [SP], #0x10
    // 0xc607ec: ret
    //     0xc607ec: ret             
    // 0xc607f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc607f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc607f4: b               #0xc606c0
    // 0xc607f8: SaveReg d0
    //     0xc607f8: str             q0, [SP, #-0x10]!
    // 0xc607fc: stp             x0, x2, [SP, #-0x10]!
    // 0xc60800: r0 = AllocateDouble()
    //     0xc60800: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc60804: mov             x1, x0
    // 0xc60808: ldp             x0, x2, [SP], #0x10
    // 0xc6080c: RestoreReg d0
    //     0xc6080c: ldr             q0, [SP], #0x10
    // 0xc60810: b               #0xc6075c
    // 0xc60814: SaveReg d0
    //     0xc60814: str             q0, [SP, #-0x10]!
    // 0xc60818: SaveReg r2
    //     0xc60818: str             x2, [SP, #-8]!
    // 0xc6081c: r0 = AllocateDouble()
    //     0xc6081c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc60820: RestoreReg r2
    //     0xc60820: ldr             x2, [SP], #8
    // 0xc60824: RestoreReg d0
    //     0xc60824: ldr             q0, [SP], #0x10
    // 0xc60828: b               #0xc607a4
  }
  _ setExposureOffset(/* No info */) async {
    // ** addr: 0xc641c8, size: 0x114
    // 0xc641c8: EnterFrame
    //     0xc641c8: stp             fp, lr, [SP, #-0x10]!
    //     0xc641cc: mov             fp, SP
    // 0xc641d0: AllocStack(0x18)
    //     0xc641d0: sub             SP, SP, #0x18
    // 0xc641d4: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */, dynamic _ /* d0, fp-0x18 */)
    //     0xc641d4: stur            NULL, [fp, #-8]
    //     0xc641d8: mov             x0, #0
    //     0xc641dc: add             x1, fp, w0, sxtw #2
    //     0xc641e0: ldr             x1, [x1, #0x18]
    //     0xc641e4: stur            x1, [fp, #-0x10]
    //     0xc641e8: add             x2, fp, w0, sxtw #2
    //     0xc641ec: ldr             d0, [x2, #0x10]
    //     0xc641f0: stur            d0, [fp, #-0x18]
    // 0xc641f4: CheckStackOverflow
    //     0xc641f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc641f8: cmp             SP, x16
    //     0xc641fc: b.ls            #0xc642b4
    // 0xc64200: InitAsync() -> Future<double>
    //     0xc64200: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc64204: bl              #0x4b92e4
    // 0xc64208: r1 = Null
    //     0xc64208: mov             x1, NULL
    // 0xc6420c: r2 = 8
    //     0xc6420c: mov             x2, #8
    // 0xc64210: r0 = AllocateArray()
    //     0xc64210: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc64214: r17 = "cameraId"
    //     0xc64214: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc64218: ldr             x17, [x17, #0x890]
    // 0xc6421c: StoreField: r0->field_f = r17
    //     0xc6421c: stur            w17, [x0, #0xf]
    // 0xc64220: ldur            x1, [fp, #-0x10]
    // 0xc64224: StoreField: r0->field_13 = r1
    //     0xc64224: stur            w1, [x0, #0x13]
    // 0xc64228: r17 = "offset"
    //     0xc64228: add             x17, PP, #0x35, lsl #12  ; [pp+0x35530] "offset"
    //     0xc6422c: ldr             x17, [x17, #0x530]
    // 0xc64230: StoreField: r0->field_17 = r17
    //     0xc64230: stur            w17, [x0, #0x17]
    // 0xc64234: ldur            d0, [fp, #-0x18]
    // 0xc64238: r1 = inline_Allocate_Double()
    //     0xc64238: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc6423c: add             x1, x1, #0x10
    //     0xc64240: cmp             x2, x1
    //     0xc64244: b.ls            #0xc642bc
    //     0xc64248: str             x1, [THR, #0x60]  ; THR::top
    //     0xc6424c: sub             x1, x1, #0xf
    //     0xc64250: mov             x2, #0xd108
    //     0xc64254: movk            x2, #3, lsl #16
    //     0xc64258: stur            x2, [x1, #-1]
    // 0xc6425c: StoreField: r1->field_7 = d0
    //     0xc6425c: stur            d0, [x1, #7]
    // 0xc64260: StoreField: r0->field_1b = r1
    //     0xc64260: stur            w1, [x0, #0x1b]
    // 0xc64264: r16 = <String, dynamic>
    //     0xc64264: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc64268: stp             x0, x16, [SP, #-0x10]!
    // 0xc6426c: r0 = Map._fromLiteral()
    //     0xc6426c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc64270: add             SP, SP, #0x10
    // 0xc64274: r16 = <double>
    //     0xc64274: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc64278: r30 = Instance_MethodChannel
    //     0xc64278: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc6427c: ldr             lr, [lr, #0x370]
    // 0xc64280: stp             lr, x16, [SP, #-0x10]!
    // 0xc64284: r16 = "setExposureOffset"
    //     0xc64284: add             x16, PP, #0x55, lsl #12  ; [pp+0x55cc8] "setExposureOffset"
    //     0xc64288: ldr             x16, [x16, #0xcc8]
    // 0xc6428c: stp             x0, x16, [SP, #-0x10]!
    // 0xc64290: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc64290: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc64294: r0 = invokeMethod()
    //     0xc64294: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc64298: add             SP, SP, #0x20
    // 0xc6429c: mov             x1, x0
    // 0xc642a0: stur            x1, [fp, #-0x10]
    // 0xc642a4: r0 = Await()
    //     0xc642a4: bl              #0x4b8e6c  ; AwaitStub
    // 0xc642a8: cmp             w0, NULL
    // 0xc642ac: b.eq            #0xc642d8
    // 0xc642b0: r0 = ReturnAsync()
    //     0xc642b0: b               #0x501858  ; ReturnAsyncStub
    // 0xc642b4: r0 = StackOverflowSharedWithFPURegs()
    //     0xc642b4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc642b8: b               #0xc64200
    // 0xc642bc: SaveReg d0
    //     0xc642bc: str             q0, [SP, #-0x10]!
    // 0xc642c0: SaveReg r0
    //     0xc642c0: str             x0, [SP, #-8]!
    // 0xc642c4: r0 = AllocateDouble()
    //     0xc642c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc642c8: mov             x1, x0
    // 0xc642cc: RestoreReg r0
    //     0xc642cc: ldr             x0, [SP], #8
    // 0xc642d0: RestoreReg d0
    //     0xc642d0: ldr             q0, [SP], #0x10
    // 0xc642d4: b               #0xc6425c
    // 0xc642d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc642d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getExposureOffsetStepSize(/* No info */) async {
    // ** addr: 0xc645b8, size: 0xc8
    // 0xc645b8: EnterFrame
    //     0xc645b8: stp             fp, lr, [SP, #-0x10]!
    //     0xc645bc: mov             fp, SP
    // 0xc645c0: AllocStack(0x18)
    //     0xc645c0: sub             SP, SP, #0x18
    // 0xc645c4: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */)
    //     0xc645c4: stur            NULL, [fp, #-8]
    //     0xc645c8: mov             x0, #0
    //     0xc645cc: add             x1, fp, w0, sxtw #2
    //     0xc645d0: ldr             x1, [x1, #0x10]
    //     0xc645d4: stur            x1, [fp, #-0x10]
    // 0xc645d8: CheckStackOverflow
    //     0xc645d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc645dc: cmp             SP, x16
    //     0xc645e0: b.ls            #0xc64674
    // 0xc645e4: InitAsync() -> Future<double>
    //     0xc645e4: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc645e8: bl              #0x4b92e4
    // 0xc645ec: r1 = Null
    //     0xc645ec: mov             x1, NULL
    // 0xc645f0: r2 = 4
    //     0xc645f0: mov             x2, #4
    // 0xc645f4: r0 = AllocateArray()
    //     0xc645f4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc645f8: mov             x2, x0
    // 0xc645fc: r17 = "cameraId"
    //     0xc645fc: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc64600: ldr             x17, [x17, #0x890]
    // 0xc64604: StoreField: r2->field_f = r17
    //     0xc64604: stur            w17, [x2, #0xf]
    // 0xc64608: ldur            x3, [fp, #-0x10]
    // 0xc6460c: r0 = BoxInt64Instr(r3)
    //     0xc6460c: sbfiz           x0, x3, #1, #0x1f
    //     0xc64610: cmp             x3, x0, asr #1
    //     0xc64614: b.eq            #0xc64620
    //     0xc64618: bl              #0xd69bb8
    //     0xc6461c: stur            x3, [x0, #7]
    // 0xc64620: StoreField: r2->field_13 = r0
    //     0xc64620: stur            w0, [x2, #0x13]
    // 0xc64624: r16 = <String, dynamic>
    //     0xc64624: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc64628: stp             x2, x16, [SP, #-0x10]!
    // 0xc6462c: r0 = Map._fromLiteral()
    //     0xc6462c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc64630: add             SP, SP, #0x10
    // 0xc64634: r16 = <double>
    //     0xc64634: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc64638: r30 = Instance_MethodChannel
    //     0xc64638: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc6463c: ldr             lr, [lr, #0x370]
    // 0xc64640: stp             lr, x16, [SP, #-0x10]!
    // 0xc64644: r16 = "getExposureOffsetStepSize"
    //     0xc64644: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d358] "getExposureOffsetStepSize"
    //     0xc64648: ldr             x16, [x16, #0x358]
    // 0xc6464c: stp             x0, x16, [SP, #-0x10]!
    // 0xc64650: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc64650: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc64654: r0 = invokeMethod()
    //     0xc64654: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc64658: add             SP, SP, #0x20
    // 0xc6465c: mov             x1, x0
    // 0xc64660: stur            x1, [fp, #-0x18]
    // 0xc64664: r0 = Await()
    //     0xc64664: bl              #0x4b8e6c  ; AwaitStub
    // 0xc64668: cmp             w0, NULL
    // 0xc6466c: b.eq            #0xc6467c
    // 0xc64670: r0 = ReturnAsync()
    //     0xc64670: b               #0x501858  ; ReturnAsyncStub
    // 0xc64674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc64674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc64678: b               #0xc645e4
    // 0xc6467c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc6467c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMaxExposureOffset(/* No info */) async {
    // ** addr: 0xc64c1c, size: 0xc8
    // 0xc64c1c: EnterFrame
    //     0xc64c1c: stp             fp, lr, [SP, #-0x10]!
    //     0xc64c20: mov             fp, SP
    // 0xc64c24: AllocStack(0x18)
    //     0xc64c24: sub             SP, SP, #0x18
    // 0xc64c28: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */)
    //     0xc64c28: stur            NULL, [fp, #-8]
    //     0xc64c2c: mov             x0, #0
    //     0xc64c30: add             x1, fp, w0, sxtw #2
    //     0xc64c34: ldr             x1, [x1, #0x10]
    //     0xc64c38: stur            x1, [fp, #-0x10]
    // 0xc64c3c: CheckStackOverflow
    //     0xc64c3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc64c40: cmp             SP, x16
    //     0xc64c44: b.ls            #0xc64cd8
    // 0xc64c48: InitAsync() -> Future<double>
    //     0xc64c48: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc64c4c: bl              #0x4b92e4
    // 0xc64c50: r1 = Null
    //     0xc64c50: mov             x1, NULL
    // 0xc64c54: r2 = 4
    //     0xc64c54: mov             x2, #4
    // 0xc64c58: r0 = AllocateArray()
    //     0xc64c58: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc64c5c: mov             x2, x0
    // 0xc64c60: r17 = "cameraId"
    //     0xc64c60: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc64c64: ldr             x17, [x17, #0x890]
    // 0xc64c68: StoreField: r2->field_f = r17
    //     0xc64c68: stur            w17, [x2, #0xf]
    // 0xc64c6c: ldur            x3, [fp, #-0x10]
    // 0xc64c70: r0 = BoxInt64Instr(r3)
    //     0xc64c70: sbfiz           x0, x3, #1, #0x1f
    //     0xc64c74: cmp             x3, x0, asr #1
    //     0xc64c78: b.eq            #0xc64c84
    //     0xc64c7c: bl              #0xd69bb8
    //     0xc64c80: stur            x3, [x0, #7]
    // 0xc64c84: StoreField: r2->field_13 = r0
    //     0xc64c84: stur            w0, [x2, #0x13]
    // 0xc64c88: r16 = <String, dynamic>
    //     0xc64c88: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc64c8c: stp             x2, x16, [SP, #-0x10]!
    // 0xc64c90: r0 = Map._fromLiteral()
    //     0xc64c90: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc64c94: add             SP, SP, #0x10
    // 0xc64c98: r16 = <double>
    //     0xc64c98: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc64c9c: r30 = Instance_MethodChannel
    //     0xc64c9c: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc64ca0: ldr             lr, [lr, #0x370]
    // 0xc64ca4: stp             lr, x16, [SP, #-0x10]!
    // 0xc64ca8: r16 = "getMaxExposureOffset"
    //     0xc64ca8: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d350] "getMaxExposureOffset"
    //     0xc64cac: ldr             x16, [x16, #0x350]
    // 0xc64cb0: stp             x0, x16, [SP, #-0x10]!
    // 0xc64cb4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc64cb4: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc64cb8: r0 = invokeMethod()
    //     0xc64cb8: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc64cbc: add             SP, SP, #0x20
    // 0xc64cc0: mov             x1, x0
    // 0xc64cc4: stur            x1, [fp, #-0x18]
    // 0xc64cc8: r0 = Await()
    //     0xc64cc8: bl              #0x4b8e6c  ; AwaitStub
    // 0xc64ccc: cmp             w0, NULL
    // 0xc64cd0: b.eq            #0xc64ce0
    // 0xc64cd4: r0 = ReturnAsync()
    //     0xc64cd4: b               #0x501858  ; ReturnAsyncStub
    // 0xc64cd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc64cd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc64cdc: b               #0xc64c48
    // 0xc64ce0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc64ce0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMinExposureOffset(/* No info */) async {
    // ** addr: 0xc653ec, size: 0xc8
    // 0xc653ec: EnterFrame
    //     0xc653ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc653f0: mov             fp, SP
    // 0xc653f4: AllocStack(0x18)
    //     0xc653f4: sub             SP, SP, #0x18
    // 0xc653f8: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */)
    //     0xc653f8: stur            NULL, [fp, #-8]
    //     0xc653fc: mov             x0, #0
    //     0xc65400: add             x1, fp, w0, sxtw #2
    //     0xc65404: ldr             x1, [x1, #0x10]
    //     0xc65408: stur            x1, [fp, #-0x10]
    // 0xc6540c: CheckStackOverflow
    //     0xc6540c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc65410: cmp             SP, x16
    //     0xc65414: b.ls            #0xc654a8
    // 0xc65418: InitAsync() -> Future<double>
    //     0xc65418: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc6541c: bl              #0x4b92e4
    // 0xc65420: r1 = Null
    //     0xc65420: mov             x1, NULL
    // 0xc65424: r2 = 4
    //     0xc65424: mov             x2, #4
    // 0xc65428: r0 = AllocateArray()
    //     0xc65428: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6542c: mov             x2, x0
    // 0xc65430: r17 = "cameraId"
    //     0xc65430: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc65434: ldr             x17, [x17, #0x890]
    // 0xc65438: StoreField: r2->field_f = r17
    //     0xc65438: stur            w17, [x2, #0xf]
    // 0xc6543c: ldur            x3, [fp, #-0x10]
    // 0xc65440: r0 = BoxInt64Instr(r3)
    //     0xc65440: sbfiz           x0, x3, #1, #0x1f
    //     0xc65444: cmp             x3, x0, asr #1
    //     0xc65448: b.eq            #0xc65454
    //     0xc6544c: bl              #0xd69bb8
    //     0xc65450: stur            x3, [x0, #7]
    // 0xc65454: StoreField: r2->field_13 = r0
    //     0xc65454: stur            w0, [x2, #0x13]
    // 0xc65458: r16 = <String, dynamic>
    //     0xc65458: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc6545c: stp             x2, x16, [SP, #-0x10]!
    // 0xc65460: r0 = Map._fromLiteral()
    //     0xc65460: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc65464: add             SP, SP, #0x10
    // 0xc65468: r16 = <double>
    //     0xc65468: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc6546c: r30 = Instance_MethodChannel
    //     0xc6546c: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc65470: ldr             lr, [lr, #0x370]
    // 0xc65474: stp             lr, x16, [SP, #-0x10]!
    // 0xc65478: r16 = "getMinExposureOffset"
    //     0xc65478: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d348] "getMinExposureOffset"
    //     0xc6547c: ldr             x16, [x16, #0x348]
    // 0xc65480: stp             x0, x16, [SP, #-0x10]!
    // 0xc65484: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc65484: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc65488: r0 = invokeMethod()
    //     0xc65488: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6548c: add             SP, SP, #0x20
    // 0xc65490: mov             x1, x0
    // 0xc65494: stur            x1, [fp, #-0x18]
    // 0xc65498: r0 = Await()
    //     0xc65498: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6549c: cmp             w0, NULL
    // 0xc654a0: b.eq            #0xc654b0
    // 0xc654a4: r0 = ReturnAsync()
    //     0xc654a4: b               #0x501858  ; ReturnAsyncStub
    // 0xc654a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc654a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc654ac: b               #0xc65418
    // 0xc654b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc654b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setExposurePoint(/* No info */) {
    // ** addr: 0xc656fc, size: 0x180
    // 0xc656fc: EnterFrame
    //     0xc656fc: stp             fp, lr, [SP, #-0x10]!
    //     0xc65700: mov             fp, SP
    // 0xc65704: CheckStackOverflow
    //     0xc65704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc65708: cmp             SP, x16
    //     0xc6570c: b.ls            #0xc65840
    // 0xc65710: r1 = Null
    //     0xc65710: mov             x1, NULL
    // 0xc65714: r2 = 16
    //     0xc65714: mov             x2, #0x10
    // 0xc65718: r0 = AllocateArray()
    //     0xc65718: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6571c: mov             x2, x0
    // 0xc65720: r17 = "cameraId"
    //     0xc65720: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc65724: ldr             x17, [x17, #0x890]
    // 0xc65728: StoreField: r2->field_f = r17
    //     0xc65728: stur            w17, [x2, #0xf]
    // 0xc6572c: ldr             x3, [fp, #0x18]
    // 0xc65730: r0 = BoxInt64Instr(r3)
    //     0xc65730: sbfiz           x0, x3, #1, #0x1f
    //     0xc65734: cmp             x3, x0, asr #1
    //     0xc65738: b.eq            #0xc65744
    //     0xc6573c: bl              #0xd69bb8
    //     0xc65740: stur            x3, [x0, #7]
    // 0xc65744: StoreField: r2->field_13 = r0
    //     0xc65744: stur            w0, [x2, #0x13]
    // 0xc65748: r17 = "reset"
    //     0xc65748: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ae0] "reset"
    //     0xc6574c: ldr             x17, [x17, #0xae0]
    // 0xc65750: StoreField: r2->field_17 = r17
    //     0xc65750: stur            w17, [x2, #0x17]
    // 0xc65754: ldr             x0, [fp, #0x10]
    // 0xc65758: cmp             w0, NULL
    // 0xc6575c: r16 = true
    //     0xc6575c: add             x16, NULL, #0x20  ; true
    // 0xc65760: r17 = false
    //     0xc65760: add             x17, NULL, #0x30  ; false
    // 0xc65764: csel            x1, x16, x17, eq
    // 0xc65768: StoreField: r2->field_1b = r1
    //     0xc65768: stur            w1, [x2, #0x1b]
    // 0xc6576c: r17 = "x"
    //     0xc6576c: ldr             x17, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xc65770: StoreField: r2->field_1f = r17
    //     0xc65770: stur            w17, [x2, #0x1f]
    // 0xc65774: cmp             w0, NULL
    // 0xc65778: b.ne            #0xc65784
    // 0xc6577c: r1 = Null
    //     0xc6577c: mov             x1, NULL
    // 0xc65780: b               #0xc657b0
    // 0xc65784: LoadField: d0 = r0->field_b
    //     0xc65784: ldur            d0, [x0, #0xb]
    // 0xc65788: r1 = inline_Allocate_Double()
    //     0xc65788: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xc6578c: add             x1, x1, #0x10
    //     0xc65790: cmp             x3, x1
    //     0xc65794: b.ls            #0xc65848
    //     0xc65798: str             x1, [THR, #0x60]  ; THR::top
    //     0xc6579c: sub             x1, x1, #0xf
    //     0xc657a0: mov             x3, #0xd108
    //     0xc657a4: movk            x3, #3, lsl #16
    //     0xc657a8: stur            x3, [x1, #-1]
    // 0xc657ac: StoreField: r1->field_7 = d0
    //     0xc657ac: stur            d0, [x1, #7]
    // 0xc657b0: StoreField: r2->field_23 = r1
    //     0xc657b0: stur            w1, [x2, #0x23]
    // 0xc657b4: r17 = "y"
    //     0xc657b4: ldr             x17, [PP, #0x78d0]  ; [pp+0x78d0] "y"
    // 0xc657b8: StoreField: r2->field_27 = r17
    //     0xc657b8: stur            w17, [x2, #0x27]
    // 0xc657bc: cmp             w0, NULL
    // 0xc657c0: b.ne            #0xc657cc
    // 0xc657c4: r0 = Null
    //     0xc657c4: mov             x0, NULL
    // 0xc657c8: b               #0xc657f8
    // 0xc657cc: LoadField: d0 = r0->field_13
    //     0xc657cc: ldur            d0, [x0, #0x13]
    // 0xc657d0: r0 = inline_Allocate_Double()
    //     0xc657d0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc657d4: add             x0, x0, #0x10
    //     0xc657d8: cmp             x1, x0
    //     0xc657dc: b.ls            #0xc65864
    //     0xc657e0: str             x0, [THR, #0x60]  ; THR::top
    //     0xc657e4: sub             x0, x0, #0xf
    //     0xc657e8: mov             x1, #0xd108
    //     0xc657ec: movk            x1, #3, lsl #16
    //     0xc657f0: stur            x1, [x0, #-1]
    // 0xc657f4: StoreField: r0->field_7 = d0
    //     0xc657f4: stur            d0, [x0, #7]
    // 0xc657f8: StoreField: r2->field_2b = r0
    //     0xc657f8: stur            w0, [x2, #0x2b]
    // 0xc657fc: r16 = <String, dynamic>
    //     0xc657fc: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc65800: stp             x2, x16, [SP, #-0x10]!
    // 0xc65804: r0 = Map._fromLiteral()
    //     0xc65804: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc65808: add             SP, SP, #0x10
    // 0xc6580c: r16 = <void?>
    //     0xc6580c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc65810: r30 = Instance_MethodChannel
    //     0xc65810: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc65814: ldr             lr, [lr, #0x370]
    // 0xc65818: stp             lr, x16, [SP, #-0x10]!
    // 0xc6581c: r16 = "setExposurePoint"
    //     0xc6581c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53af0] "setExposurePoint"
    //     0xc65820: ldr             x16, [x16, #0xaf0]
    // 0xc65824: stp             x0, x16, [SP, #-0x10]!
    // 0xc65828: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc65828: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6582c: r0 = invokeMethod()
    //     0xc6582c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc65830: add             SP, SP, #0x20
    // 0xc65834: LeaveFrame
    //     0xc65834: mov             SP, fp
    //     0xc65838: ldp             fp, lr, [SP], #0x10
    // 0xc6583c: ret
    //     0xc6583c: ret             
    // 0xc65840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc65840: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc65844: b               #0xc65710
    // 0xc65848: SaveReg d0
    //     0xc65848: str             q0, [SP, #-0x10]!
    // 0xc6584c: stp             x0, x2, [SP, #-0x10]!
    // 0xc65850: r0 = AllocateDouble()
    //     0xc65850: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc65854: mov             x1, x0
    // 0xc65858: ldp             x0, x2, [SP], #0x10
    // 0xc6585c: RestoreReg d0
    //     0xc6585c: ldr             q0, [SP], #0x10
    // 0xc65860: b               #0xc657ac
    // 0xc65864: SaveReg d0
    //     0xc65864: str             q0, [SP, #-0x10]!
    // 0xc65868: SaveReg r2
    //     0xc65868: str             x2, [SP, #-8]!
    // 0xc6586c: r0 = AllocateDouble()
    //     0xc6586c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc65870: RestoreReg r2
    //     0xc65870: ldr             x2, [SP], #8
    // 0xc65874: RestoreReg d0
    //     0xc65874: ldr             q0, [SP], #0x10
    // 0xc65878: b               #0xc657f4
  }
  _ stopVideoRecording(/* No info */) async {
    // ** addr: 0xc6a50c, size: 0x1e0
    // 0xc6a50c: EnterFrame
    //     0xc6a50c: stp             fp, lr, [SP, #-0x10]!
    //     0xc6a510: mov             fp, SP
    // 0xc6a514: AllocStack(0x20)
    //     0xc6a514: sub             SP, SP, #0x20
    // 0xc6a518: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */)
    //     0xc6a518: stur            NULL, [fp, #-8]
    //     0xc6a51c: mov             x0, #0
    //     0xc6a520: add             x1, fp, w0, sxtw #2
    //     0xc6a524: ldr             x1, [x1, #0x10]
    //     0xc6a528: stur            x1, [fp, #-0x10]
    // 0xc6a52c: CheckStackOverflow
    //     0xc6a52c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6a530: cmp             SP, x16
    //     0xc6a534: b.ls            #0xc6a6e4
    // 0xc6a538: InitAsync() -> Future<XFile>
    //     0xc6a538: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d698] TypeArguments: <XFile>
    //     0xc6a53c: ldr             x0, [x0, #0x698]
    //     0xc6a540: bl              #0x4b92e4
    // 0xc6a544: r1 = Null
    //     0xc6a544: mov             x1, NULL
    // 0xc6a548: r2 = 4
    //     0xc6a548: mov             x2, #4
    // 0xc6a54c: r0 = AllocateArray()
    //     0xc6a54c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6a550: mov             x2, x0
    // 0xc6a554: r17 = "cameraId"
    //     0xc6a554: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc6a558: ldr             x17, [x17, #0x890]
    // 0xc6a55c: StoreField: r2->field_f = r17
    //     0xc6a55c: stur            w17, [x2, #0xf]
    // 0xc6a560: ldur            x3, [fp, #-0x10]
    // 0xc6a564: r0 = BoxInt64Instr(r3)
    //     0xc6a564: sbfiz           x0, x3, #1, #0x1f
    //     0xc6a568: cmp             x3, x0, asr #1
    //     0xc6a56c: b.eq            #0xc6a578
    //     0xc6a570: bl              #0xd69bb8
    //     0xc6a574: stur            x3, [x0, #7]
    // 0xc6a578: StoreField: r2->field_13 = r0
    //     0xc6a578: stur            w0, [x2, #0x13]
    // 0xc6a57c: r16 = <String, dynamic>
    //     0xc6a57c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc6a580: stp             x2, x16, [SP, #-0x10]!
    // 0xc6a584: r0 = Map._fromLiteral()
    //     0xc6a584: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc6a588: add             SP, SP, #0x10
    // 0xc6a58c: r16 = <String>
    //     0xc6a58c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xc6a590: r30 = Instance_MethodChannel
    //     0xc6a590: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc6a594: ldr             lr, [lr, #0x370]
    // 0xc6a598: stp             lr, x16, [SP, #-0x10]!
    // 0xc6a59c: r16 = "stopVideoRecording"
    //     0xc6a59c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d6a0] "stopVideoRecording"
    //     0xc6a5a0: ldr             x16, [x16, #0x6a0]
    // 0xc6a5a4: stp             x0, x16, [SP, #-0x10]!
    // 0xc6a5a8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc6a5a8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6a5ac: r0 = invokeMethod()
    //     0xc6a5ac: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6a5b0: add             SP, SP, #0x20
    // 0xc6a5b4: mov             x1, x0
    // 0xc6a5b8: stur            x1, [fp, #-0x18]
    // 0xc6a5bc: r0 = Await()
    //     0xc6a5bc: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6a5c0: stur            x0, [fp, #-0x20]
    // 0xc6a5c4: cmp             w0, NULL
    // 0xc6a5c8: b.eq            #0xc6a654
    // 0xc6a5cc: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc6a5cc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc6a5d0: ldr             x0, [x0, #0xb58]
    //     0xc6a5d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc6a5d8: cmp             w0, w16
    //     0xc6a5dc: b.ne            #0xc6a5e8
    //     0xc6a5e0: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc6a5e4: bl              #0xd67d44
    // 0xc6a5e8: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc6a5e8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc6a5ec: ldr             x0, [x0, #0xdd8]
    //     0xc6a5f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc6a5f4: cmp             w0, w16
    //     0xc6a5f8: b.ne            #0xc6a604
    //     0xc6a5fc: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc6a600: bl              #0xd67cdc
    // 0xc6a604: r0 = _File()
    //     0xc6a604: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xc6a608: mov             x1, x0
    // 0xc6a60c: ldur            x0, [fp, #-0x20]
    // 0xc6a610: stur            x1, [fp, #-0x18]
    // 0xc6a614: StoreField: r1->field_7 = r0
    //     0xc6a614: stur            w0, [x1, #7]
    // 0xc6a618: SaveReg r0
    //     0xc6a618: str             x0, [SP, #-8]!
    // 0xc6a61c: r0 = _toUtf8Array()
    //     0xc6a61c: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc6a620: add             SP, SP, #8
    // 0xc6a624: ldur            x1, [fp, #-0x18]
    // 0xc6a628: StoreField: r1->field_b = r0
    //     0xc6a628: stur            w0, [x1, #0xb]
    //     0xc6a62c: ldurb           w16, [x1, #-1]
    //     0xc6a630: ldurb           w17, [x0, #-1]
    //     0xc6a634: and             x16, x17, x16, lsr #2
    //     0xc6a638: tst             x16, HEAP, lsr #32
    //     0xc6a63c: b.eq            #0xc6a644
    //     0xc6a640: bl              #0xd6826c
    // 0xc6a644: r0 = XFile()
    //     0xc6a644: bl              #0xc6a500  ; AllocateXFileStub -> XFile (size=0x10)
    // 0xc6a648: ldur            x1, [fp, #-0x18]
    // 0xc6a64c: StoreField: r0->field_7 = r1
    //     0xc6a64c: stur            w1, [x0, #7]
    // 0xc6a650: r0 = ReturnAsyncNotFuture()
    //     0xc6a650: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc6a654: r1 = Null
    //     0xc6a654: mov             x1, NULL
    // 0xc6a658: r2 = 6
    //     0xc6a658: mov             x2, #6
    // 0xc6a65c: r0 = AllocateArray()
    //     0xc6a65c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6a660: stur            x0, [fp, #-0x18]
    // 0xc6a664: r17 = "The platform \""
    //     0xc6a664: add             x17, PP, #0x53, lsl #12  ; [pp+0x53af8] "The platform \""
    //     0xc6a668: ldr             x17, [x17, #0xaf8]
    // 0xc6a66c: StoreField: r0->field_f = r17
    //     0xc6a66c: stur            w17, [x0, #0xf]
    // 0xc6a670: r0 = defaultTargetPlatform()
    //     0xc6a670: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xc6a674: ldur            x1, [fp, #-0x18]
    // 0xc6a678: ArrayStore: r1[1] = r0  ; List_4
    //     0xc6a678: add             x25, x1, #0x13
    //     0xc6a67c: str             w0, [x25]
    //     0xc6a680: tbz             w0, #0, #0xc6a69c
    //     0xc6a684: ldurb           w16, [x1, #-1]
    //     0xc6a688: ldurb           w17, [x0, #-1]
    //     0xc6a68c: and             x16, x17, x16, lsr #2
    //     0xc6a690: tst             x16, HEAP, lsr #32
    //     0xc6a694: b.eq            #0xc6a69c
    //     0xc6a698: bl              #0xd67e5c
    // 0xc6a69c: ldur            x0, [fp, #-0x18]
    // 0xc6a6a0: r17 = "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc6a6a0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b00] "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc6a6a4: ldr             x17, [x17, #0xb00]
    // 0xc6a6a8: StoreField: r0->field_17 = r17
    //     0xc6a6a8: stur            w17, [x0, #0x17]
    // 0xc6a6ac: SaveReg r0
    //     0xc6a6ac: str             x0, [SP, #-8]!
    // 0xc6a6b0: r0 = _interpolate()
    //     0xc6a6b0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc6a6b4: add             SP, SP, #8
    // 0xc6a6b8: stur            x0, [fp, #-0x18]
    // 0xc6a6bc: r0 = CameraException()
    //     0xc6a6bc: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc6a6c0: mov             x1, x0
    // 0xc6a6c4: r0 = "INVALID_PATH"
    //     0xc6a6c4: add             x0, PP, #0x53, lsl #12  ; [pp+0x53b08] "INVALID_PATH"
    //     0xc6a6c8: ldr             x0, [x0, #0xb08]
    // 0xc6a6cc: StoreField: r1->field_7 = r0
    //     0xc6a6cc: stur            w0, [x1, #7]
    // 0xc6a6d0: ldur            x0, [fp, #-0x18]
    // 0xc6a6d4: StoreField: r1->field_b = r0
    //     0xc6a6d4: stur            w0, [x1, #0xb]
    // 0xc6a6d8: mov             x0, x1
    // 0xc6a6dc: r0 = Throw()
    //     0xc6a6dc: bl              #0xd67e38  ; ThrowStub
    // 0xc6a6e0: brk             #0
    // 0xc6a6e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6a6e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6a6e8: b               #0xc6a538
  }
  _ startVideoCapturing(/* No info */) async {
    // ** addr: 0xc6b6d4, size: 0x18c
    // 0xc6b6d4: EnterFrame
    //     0xc6b6d4: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b6d8: mov             fp, SP
    // 0xc6b6dc: AllocStack(0x28)
    //     0xc6b6dc: sub             SP, SP, #0x28
    // 0xc6b6e0: SetupParameters(AVFoundationCamera this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xc6b6e0: stur            NULL, [fp, #-8]
    //     0xc6b6e4: mov             x0, #0
    //     0xc6b6e8: add             x1, fp, w0, sxtw #2
    //     0xc6b6ec: ldr             x1, [x1, #0x18]
    //     0xc6b6f0: stur            x1, [fp, #-0x18]
    //     0xc6b6f4: add             x2, fp, w0, sxtw #2
    //     0xc6b6f8: ldr             x2, [x2, #0x10]
    //     0xc6b6fc: stur            x2, [fp, #-0x10]
    // 0xc6b700: CheckStackOverflow
    //     0xc6b700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6b704: cmp             SP, x16
    //     0xc6b708: b.ls            #0xc6b858
    // 0xc6b70c: InitAsync() -> Future<void?>
    //     0xc6b70c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc6b710: bl              #0x4b92e4
    // 0xc6b714: r1 = Null
    //     0xc6b714: mov             x1, NULL
    // 0xc6b718: r2 = 12
    //     0xc6b718: mov             x2, #0xc
    // 0xc6b71c: r0 = AllocateArray()
    //     0xc6b71c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6b720: mov             x2, x0
    // 0xc6b724: r17 = "cameraId"
    //     0xc6b724: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc6b728: ldr             x17, [x17, #0x890]
    // 0xc6b72c: StoreField: r2->field_f = r17
    //     0xc6b72c: stur            w17, [x2, #0xf]
    // 0xc6b730: ldur            x3, [fp, #-0x10]
    // 0xc6b734: LoadField: r4 = r3->field_7
    //     0xc6b734: ldur            x4, [x3, #7]
    // 0xc6b738: r0 = BoxInt64Instr(r4)
    //     0xc6b738: sbfiz           x0, x4, #1, #0x1f
    //     0xc6b73c: cmp             x4, x0, asr #1
    //     0xc6b740: b.eq            #0xc6b74c
    //     0xc6b744: bl              #0xd69bb8
    //     0xc6b748: stur            x4, [x0, #7]
    // 0xc6b74c: StoreField: r2->field_13 = r0
    //     0xc6b74c: stur            w0, [x2, #0x13]
    // 0xc6b750: r17 = "maxVideoDuration"
    //     0xc6b750: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b10] "maxVideoDuration"
    //     0xc6b754: ldr             x17, [x17, #0xb10]
    // 0xc6b758: StoreField: r2->field_17 = r17
    //     0xc6b758: stur            w17, [x2, #0x17]
    // 0xc6b75c: StoreField: r2->field_1b = rNULL
    //     0xc6b75c: stur            NULL, [x2, #0x1b]
    // 0xc6b760: r17 = "enableStream"
    //     0xc6b760: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b18] "enableStream"
    //     0xc6b764: ldr             x17, [x17, #0xb18]
    // 0xc6b768: StoreField: r2->field_1f = r17
    //     0xc6b768: stur            w17, [x2, #0x1f]
    // 0xc6b76c: LoadField: r0 = r3->field_13
    //     0xc6b76c: ldur            w0, [x3, #0x13]
    // 0xc6b770: DecompressPointer r0
    //     0xc6b770: add             x0, x0, HEAP, lsl #32
    // 0xc6b774: stur            x0, [fp, #-0x20]
    // 0xc6b778: cmp             w0, NULL
    // 0xc6b77c: r16 = true
    //     0xc6b77c: add             x16, NULL, #0x20  ; true
    // 0xc6b780: r17 = false
    //     0xc6b780: add             x17, NULL, #0x30  ; false
    // 0xc6b784: csel            x1, x16, x17, ne
    // 0xc6b788: StoreField: r2->field_23 = r1
    //     0xc6b788: stur            w1, [x2, #0x23]
    // 0xc6b78c: r16 = <String, dynamic>
    //     0xc6b78c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc6b790: stp             x2, x16, [SP, #-0x10]!
    // 0xc6b794: r0 = Map._fromLiteral()
    //     0xc6b794: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc6b798: add             SP, SP, #0x10
    // 0xc6b79c: r16 = <void?>
    //     0xc6b79c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc6b7a0: r30 = Instance_MethodChannel
    //     0xc6b7a0: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc6b7a4: ldr             lr, [lr, #0x370]
    // 0xc6b7a8: stp             lr, x16, [SP, #-0x10]!
    // 0xc6b7ac: r16 = "startVideoRecording"
    //     0xc6b7ac: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d730] "startVideoRecording"
    //     0xc6b7b0: ldr             x16, [x16, #0x730]
    // 0xc6b7b4: stp             x0, x16, [SP, #-0x10]!
    // 0xc6b7b8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc6b7b8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6b7bc: r0 = invokeMethod()
    //     0xc6b7bc: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6b7c0: add             SP, SP, #0x20
    // 0xc6b7c4: mov             x1, x0
    // 0xc6b7c8: stur            x1, [fp, #-0x28]
    // 0xc6b7cc: r0 = Await()
    //     0xc6b7cc: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6b7d0: ldur            x0, [fp, #-0x20]
    // 0xc6b7d4: cmp             w0, NULL
    // 0xc6b7d8: b.eq            #0xc6b850
    // 0xc6b7dc: ldur            x1, [fp, #-0x18]
    // 0xc6b7e0: SaveReg r1
    //     0xc6b7e0: str             x1, [SP, #-8]!
    // 0xc6b7e4: r0 = _createStreamController()
    //     0xc6b7e4: bl              #0xc6c104  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_createStreamController
    // 0xc6b7e8: add             SP, SP, #8
    // 0xc6b7ec: mov             x3, x0
    // 0xc6b7f0: ldur            x2, [fp, #-0x18]
    // 0xc6b7f4: stur            x3, [fp, #-0x10]
    // 0xc6b7f8: StoreField: r2->field_17 = r0
    //     0xc6b7f8: stur            w0, [x2, #0x17]
    //     0xc6b7fc: ldurb           w16, [x2, #-1]
    //     0xc6b800: ldurb           w17, [x0, #-1]
    //     0xc6b804: and             x16, x17, x16, lsr #2
    //     0xc6b808: tst             x16, HEAP, lsr #32
    //     0xc6b80c: b.eq            #0xc6b814
    //     0xc6b810: bl              #0xd6828c
    // 0xc6b814: LoadField: r1 = r3->field_7
    //     0xc6b814: ldur            w1, [x3, #7]
    // 0xc6b818: DecompressPointer r1
    //     0xc6b818: add             x1, x1, HEAP, lsl #32
    // 0xc6b81c: r0 = _ControllerStream()
    //     0xc6b81c: bl              #0x534e34  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x14)
    // 0xc6b820: mov             x1, x0
    // 0xc6b824: ldur            x0, [fp, #-0x10]
    // 0xc6b828: StoreField: r1->field_f = r0
    //     0xc6b828: stur            w0, [x1, #0xf]
    // 0xc6b82c: ldur            x16, [fp, #-0x20]
    // 0xc6b830: stp             x16, x1, [SP, #-0x10]!
    // 0xc6b834: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc6b834: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc6b838: r0 = listen()
    //     0xc6b838: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xc6b83c: add             SP, SP, #0x10
    // 0xc6b840: ldur            x16, [fp, #-0x18]
    // 0xc6b844: SaveReg r16
    //     0xc6b844: str             x16, [SP, #-8]!
    // 0xc6b848: r0 = _startStreamListener()
    //     0xc6b848: bl              #0xc6b860  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_startStreamListener
    // 0xc6b84c: add             SP, SP, #8
    // 0xc6b850: r0 = Null
    //     0xc6b850: mov             x0, NULL
    // 0xc6b854: r0 = ReturnAsyncNotFuture()
    //     0xc6b854: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc6b858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6b858: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6b85c: b               #0xc6b70c
  }
  _ _startStreamListener(/* No info */) {
    // ** addr: 0xc6b860, size: 0xa8
    // 0xc6b860: EnterFrame
    //     0xc6b860: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b864: mov             fp, SP
    // 0xc6b868: AllocStack(0x8)
    //     0xc6b868: sub             SP, SP, #8
    // 0xc6b86c: CheckStackOverflow
    //     0xc6b86c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6b870: cmp             SP, x16
    //     0xc6b874: b.ls            #0xc6b900
    // 0xc6b878: r1 = 1
    //     0xc6b878: mov             x1, #1
    // 0xc6b87c: r0 = AllocateContext()
    //     0xc6b87c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6b880: mov             x1, x0
    // 0xc6b884: ldr             x0, [fp, #0x10]
    // 0xc6b888: stur            x1, [fp, #-8]
    // 0xc6b88c: StoreField: r1->field_f = r0
    //     0xc6b88c: stur            w0, [x1, #0xf]
    // 0xc6b890: r16 = Instance_EventChannel
    //     0xc6b890: add             x16, PP, #0x53, lsl #12  ; [pp+0x53ea8] Obj!EventChannel@b34ab1
    //     0xc6b894: ldr             x16, [x16, #0xea8]
    // 0xc6b898: SaveReg r16
    //     0xc6b898: str             x16, [SP, #-8]!
    // 0xc6b89c: r0 = receiveBroadcastStream()
    //     0xc6b89c: bl              #0x5a24c0  ; [package:flutter/src/services/platform_channel.dart] EventChannel::receiveBroadcastStream
    // 0xc6b8a0: add             SP, SP, #8
    // 0xc6b8a4: ldur            x2, [fp, #-8]
    // 0xc6b8a8: r1 = Function '<anonymous closure>':.
    //     0xc6b8a8: add             x1, PP, #0x53, lsl #12  ; [pp+0x53eb0] AnonymousClosure: (0xc6b908), in [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_startStreamListener (0xc6b860)
    //     0xc6b8ac: ldr             x1, [x1, #0xeb0]
    // 0xc6b8b0: stur            x0, [fp, #-8]
    // 0xc6b8b4: r0 = AllocateClosure()
    //     0xc6b8b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6b8b8: ldur            x16, [fp, #-8]
    // 0xc6b8bc: stp             x0, x16, [SP, #-0x10]!
    // 0xc6b8c0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc6b8c0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc6b8c4: r0 = listen()
    //     0xc6b8c4: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xc6b8c8: add             SP, SP, #0x10
    // 0xc6b8cc: ldr             x1, [fp, #0x10]
    // 0xc6b8d0: StoreField: r1->field_13 = r0
    //     0xc6b8d0: stur            w0, [x1, #0x13]
    //     0xc6b8d4: tbz             w0, #0, #0xc6b8f0
    //     0xc6b8d8: ldurb           w16, [x1, #-1]
    //     0xc6b8dc: ldurb           w17, [x0, #-1]
    //     0xc6b8e0: and             x16, x17, x16, lsr #2
    //     0xc6b8e4: tst             x16, HEAP, lsr #32
    //     0xc6b8e8: b.eq            #0xc6b8f0
    //     0xc6b8ec: bl              #0xd6826c
    // 0xc6b8f0: r0 = Null
    //     0xc6b8f0: mov             x0, NULL
    // 0xc6b8f4: LeaveFrame
    //     0xc6b8f4: mov             SP, fp
    //     0xc6b8f8: ldp             fp, lr, [SP], #0x10
    // 0xc6b8fc: ret
    //     0xc6b8fc: ret             
    // 0xc6b900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6b900: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6b904: b               #0xc6b878
  }
  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xc6b908, size: 0x12c
    // 0xc6b908: EnterFrame
    //     0xc6b908: stp             fp, lr, [SP, #-0x10]!
    //     0xc6b90c: mov             fp, SP
    // 0xc6b910: AllocStack(0x40)
    //     0xc6b910: sub             SP, SP, #0x40
    // 0xc6b914: SetupParameters()
    //     0xc6b914: ldr             x0, [fp, #0x18]
    //     0xc6b918: ldur            w1, [x0, #0x17]
    //     0xc6b91c: add             x1, x1, HEAP, lsl #32
    //     0xc6b920: stur            x1, [fp, #-0x38]
    // 0xc6b924: CheckStackOverflow
    //     0xc6b924: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6b928: cmp             SP, x16
    //     0xc6b92c: b.ls            #0xc6ba28
    // 0xc6b930: r16 = <void?>
    //     0xc6b930: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc6b934: r30 = Instance_MethodChannel
    //     0xc6b934: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc6b938: ldr             lr, [lr, #0x370]
    // 0xc6b93c: stp             lr, x16, [SP, #-0x10]!
    // 0xc6b940: r16 = "receivedImageStreamData"
    //     0xc6b940: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b30] "receivedImageStreamData"
    //     0xc6b944: ldr             x16, [x16, #0xb30]
    // 0xc6b948: SaveReg r16
    //     0xc6b948: str             x16, [SP, #-8]!
    // 0xc6b94c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6b94c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6b950: r0 = invokeMethod()
    //     0xc6b950: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6b954: add             SP, SP, #0x18
    // 0xc6b958: ldur            x0, [fp, #-0x38]
    // 0xc6b95c: LoadField: r1 = r0->field_f
    //     0xc6b95c: ldur            w1, [x0, #0xf]
    // 0xc6b960: DecompressPointer r1
    //     0xc6b960: add             x1, x1, HEAP, lsl #32
    // 0xc6b964: LoadField: r3 = r1->field_17
    //     0xc6b964: ldur            w3, [x1, #0x17]
    // 0xc6b968: DecompressPointer r3
    //     0xc6b968: add             x3, x3, HEAP, lsl #32
    // 0xc6b96c: stur            x3, [fp, #-0x38]
    // 0xc6b970: cmp             w3, NULL
    // 0xc6b974: b.eq            #0xc6ba30
    // 0xc6b978: ldr             x0, [fp, #0x10]
    // 0xc6b97c: r2 = Null
    //     0xc6b97c: mov             x2, NULL
    // 0xc6b980: r1 = Null
    //     0xc6b980: mov             x1, NULL
    // 0xc6b984: r8 = Map
    //     0xc6b984: ldr             x8, [PP, #0x2338]  ; [pp+0x2338] Type: Map
    // 0xc6b988: r3 = Null
    //     0xc6b988: add             x3, PP, #0x53, lsl #12  ; [pp+0x53eb8] Null
    //     0xc6b98c: ldr             x3, [x3, #0xeb8]
    // 0xc6b990: r0 = Map()
    //     0xc6b990: bl              #0xd747e8  ; IsType_Map_Stub
    // 0xc6b994: ldr             x16, [fp, #0x10]
    // 0xc6b998: SaveReg r16
    //     0xc6b998: str             x16, [SP, #-8]!
    // 0xc6b99c: r0 = cameraImageFromPlatformData()
    //     0xc6b99c: bl              #0xc6ba34  ; [package:camera_avfoundation/src/type_conversion.dart] ::cameraImageFromPlatformData
    // 0xc6b9a0: add             SP, SP, #8
    // 0xc6b9a4: ldur            x16, [fp, #-0x38]
    // 0xc6b9a8: stp             x0, x16, [SP, #-0x10]!
    // 0xc6b9ac: r0 = add()
    //     0xc6b9ac: bl              #0xc23290  ; [dart:async] _StreamController::add
    // 0xc6b9b0: add             SP, SP, #0x10
    // 0xc6b9b4: r0 = Null
    //     0xc6b9b4: mov             x0, NULL
    // 0xc6b9b8: LeaveFrame
    //     0xc6b9b8: mov             SP, fp
    //     0xc6b9bc: ldp             fp, lr, [SP], #0x10
    // 0xc6b9c0: ret
    //     0xc6b9c0: ret             
    // 0xc6b9c4: sub             SP, fp, #0x40
    // 0xc6b9c8: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6b9c8: mov             x2, #0x76
    //     0xc6b9cc: tbz             w0, #0, #0xc6b9dc
    //     0xc6b9d0: ldur            x2, [x0, #-1]
    //     0xc6b9d4: ubfx            x2, x2, #0xc, #0x14
    //     0xc6b9d8: lsl             x2, x2, #1
    // 0xc6b9dc: cmp             w2, #0xf28
    // 0xc6b9e0: b.ne            #0xc6ba20
    // 0xc6b9e4: LoadField: r1 = r0->field_7
    //     0xc6b9e4: ldur            w1, [x0, #7]
    // 0xc6b9e8: DecompressPointer r1
    //     0xc6b9e8: add             x1, x1, HEAP, lsl #32
    // 0xc6b9ec: stur            x1, [fp, #-0x40]
    // 0xc6b9f0: LoadField: r2 = r0->field_b
    //     0xc6b9f0: ldur            w2, [x0, #0xb]
    // 0xc6b9f4: DecompressPointer r2
    //     0xc6b9f4: add             x2, x2, HEAP, lsl #32
    // 0xc6b9f8: stur            x2, [fp, #-0x38]
    // 0xc6b9fc: r0 = CameraException()
    //     0xc6b9fc: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc6ba00: mov             x1, x0
    // 0xc6ba04: ldur            x0, [fp, #-0x40]
    // 0xc6ba08: StoreField: r1->field_7 = r0
    //     0xc6ba08: stur            w0, [x1, #7]
    // 0xc6ba0c: ldur            x0, [fp, #-0x38]
    // 0xc6ba10: StoreField: r1->field_b = r0
    //     0xc6ba10: stur            w0, [x1, #0xb]
    // 0xc6ba14: mov             x0, x1
    // 0xc6ba18: r0 = Throw()
    //     0xc6ba18: bl              #0xd67e38  ; ThrowStub
    // 0xc6ba1c: brk             #0
    // 0xc6ba20: r0 = ReThrow()
    //     0xc6ba20: bl              #0xd67e14  ; ReThrowStub
    // 0xc6ba24: brk             #0
    // 0xc6ba28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ba28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ba2c: b               #0xc6b930
    // 0xc6ba30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc6ba30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _createStreamController(/* No info */) {
    // ** addr: 0xc6c104, size: 0xf0
    // 0xc6c104: EnterFrame
    //     0xc6c104: stp             fp, lr, [SP, #-0x10]!
    //     0xc6c108: mov             fp, SP
    // 0xc6c10c: AllocStack(0x18)
    //     0xc6c10c: sub             SP, SP, #0x18
    // 0xc6c110: CheckStackOverflow
    //     0xc6c110: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6c114: cmp             SP, x16
    //     0xc6c118: b.ls            #0xc6c1ec
    // 0xc6c11c: r1 = 1
    //     0xc6c11c: mov             x1, #1
    // 0xc6c120: r0 = AllocateContext()
    //     0xc6c120: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6c124: mov             x1, x0
    // 0xc6c128: ldr             x0, [fp, #0x10]
    // 0xc6c12c: stur            x1, [fp, #-8]
    // 0xc6c130: StoreField: r1->field_f = r0
    //     0xc6c130: stur            w0, [x1, #0xf]
    // 0xc6c134: r1 = 1
    //     0xc6c134: mov             x1, #1
    // 0xc6c138: r0 = AllocateContext()
    //     0xc6c138: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6c13c: mov             x1, x0
    // 0xc6c140: ldr             x0, [fp, #0x10]
    // 0xc6c144: stur            x1, [fp, #-0x10]
    // 0xc6c148: StoreField: r1->field_f = r0
    //     0xc6c148: stur            w0, [x1, #0xf]
    // 0xc6c14c: r1 = 1
    //     0xc6c14c: mov             x1, #1
    // 0xc6c150: r0 = AllocateContext()
    //     0xc6c150: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6c154: mov             x3, x0
    // 0xc6c158: ldr             x0, [fp, #0x10]
    // 0xc6c15c: stur            x3, [fp, #-0x18]
    // 0xc6c160: StoreField: r3->field_f = r0
    //     0xc6c160: stur            w0, [x3, #0xf]
    // 0xc6c164: r1 = Function '<anonymous closure>':.
    //     0xc6c164: add             x1, PP, #0x53, lsl #12  ; [pp+0x53f90] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xc6c168: ldr             x1, [x1, #0xf90]
    // 0xc6c16c: r2 = Null
    //     0xc6c16c: mov             x2, NULL
    // 0xc6c170: r0 = AllocateClosure()
    //     0xc6c170: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6c174: ldur            x2, [fp, #-8]
    // 0xc6c178: r1 = Function '_onFrameStreamPauseResume@177501818':.
    //     0xc6c178: add             x1, PP, #0x53, lsl #12  ; [pp+0x53f98] AnonymousClosure: (0xc6c310), in [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamPauseResume (0xc6b6a0)
    //     0xc6c17c: ldr             x1, [x1, #0xf98]
    // 0xc6c180: stur            x0, [fp, #-8]
    // 0xc6c184: r0 = AllocateClosure()
    //     0xc6c184: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6c188: ldur            x2, [fp, #-0x10]
    // 0xc6c18c: r1 = Function '_onFrameStreamPauseResume@177501818':.
    //     0xc6c18c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53f98] AnonymousClosure: (0xc6c310), in [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamPauseResume (0xc6b6a0)
    //     0xc6c190: ldr             x1, [x1, #0xf98]
    // 0xc6c194: stur            x0, [fp, #-0x10]
    // 0xc6c198: r0 = AllocateClosure()
    //     0xc6c198: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6c19c: ldur            x2, [fp, #-0x18]
    // 0xc6c1a0: r1 = Function '_onFrameStreamCancel@177501818':.
    //     0xc6c1a0: add             x1, PP, #0x53, lsl #12  ; [pp+0x53fa0] AnonymousClosure: (0xc6c1f4), in [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_onFrameStreamCancel (0xc6c23c)
    //     0xc6c1a4: ldr             x1, [x1, #0xfa0]
    // 0xc6c1a8: stur            x0, [fp, #-0x18]
    // 0xc6c1ac: r0 = AllocateClosure()
    //     0xc6c1ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6c1b0: r16 = <CameraImageData>
    //     0xc6c1b0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53c80] TypeArguments: <CameraImageData>
    //     0xc6c1b4: ldr             x16, [x16, #0xc80]
    // 0xc6c1b8: ldur            lr, [fp, #-8]
    // 0xc6c1bc: stp             lr, x16, [SP, #-0x10]!
    // 0xc6c1c0: ldur            x16, [fp, #-0x10]
    // 0xc6c1c4: ldur            lr, [fp, #-0x18]
    // 0xc6c1c8: stp             lr, x16, [SP, #-0x10]!
    // 0xc6c1cc: SaveReg r0
    //     0xc6c1cc: str             x0, [SP, #-8]!
    // 0xc6c1d0: r4 = const [0, 0x5, 0x5, 0x1, onCancel, 0x4, onListen, 0x1, onPause, 0x2, onResume, 0x3, null]
    //     0xc6c1d0: add             x4, PP, #0x53, lsl #12  ; [pp+0x53c88] List(13) [0, 0x5, 0x5, 0x1, "onCancel", 0x4, "onListen", 0x1, "onPause", 0x2, "onResume", 0x3, Null]
    //     0xc6c1d4: ldr             x4, [x4, #0xc88]
    // 0xc6c1d8: r0 = StreamController()
    //     0xc6c1d8: bl              #0x534f54  ; [dart:async] StreamController::StreamController
    // 0xc6c1dc: add             SP, SP, #0x28
    // 0xc6c1e0: LeaveFrame
    //     0xc6c1e0: mov             SP, fp
    //     0xc6c1e4: ldp             fp, lr, [SP], #0x10
    // 0xc6c1e8: ret
    //     0xc6c1e8: ret             
    // 0xc6c1ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6c1ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6c1f0: b               #0xc6c11c
  }
  [closure] void _onFrameStreamCancel(dynamic) {
    // ** addr: 0xc6c1f4, size: 0x48
    // 0xc6c1f4: EnterFrame
    //     0xc6c1f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc6c1f8: mov             fp, SP
    // 0xc6c1fc: ldr             x0, [fp, #0x10]
    // 0xc6c200: LoadField: r1 = r0->field_17
    //     0xc6c200: ldur            w1, [x0, #0x17]
    // 0xc6c204: DecompressPointer r1
    //     0xc6c204: add             x1, x1, HEAP, lsl #32
    // 0xc6c208: CheckStackOverflow
    //     0xc6c208: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6c20c: cmp             SP, x16
    //     0xc6c210: b.ls            #0xc6c234
    // 0xc6c214: LoadField: r0 = r1->field_f
    //     0xc6c214: ldur            w0, [x1, #0xf]
    // 0xc6c218: DecompressPointer r0
    //     0xc6c218: add             x0, x0, HEAP, lsl #32
    // 0xc6c21c: SaveReg r0
    //     0xc6c21c: str             x0, [SP, #-8]!
    // 0xc6c220: r0 = _onFrameStreamCancel()
    //     0xc6c220: bl              #0xc6c23c  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_onFrameStreamCancel
    // 0xc6c224: add             SP, SP, #8
    // 0xc6c228: LeaveFrame
    //     0xc6c228: mov             SP, fp
    //     0xc6c22c: ldp             fp, lr, [SP], #0x10
    // 0xc6c230: ret
    //     0xc6c230: ret             
    // 0xc6c234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6c234: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6c238: b               #0xc6c214
  }
  _ _onFrameStreamCancel(/* No info */) async {
    // ** addr: 0xc6c23c, size: 0xd4
    // 0xc6c23c: EnterFrame
    //     0xc6c23c: stp             fp, lr, [SP, #-0x10]!
    //     0xc6c240: mov             fp, SP
    // 0xc6c244: AllocStack(0x18)
    //     0xc6c244: sub             SP, SP, #0x18
    // 0xc6c248: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */)
    //     0xc6c248: stur            NULL, [fp, #-8]
    //     0xc6c24c: mov             x0, #0
    //     0xc6c250: add             x1, fp, w0, sxtw #2
    //     0xc6c254: ldr             x1, [x1, #0x10]
    //     0xc6c258: stur            x1, [fp, #-0x10]
    // 0xc6c25c: CheckStackOverflow
    //     0xc6c25c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6c260: cmp             SP, x16
    //     0xc6c264: b.ls            #0xc6c308
    // 0xc6c268: InitAsync() -> Future
    //     0xc6c268: mov             x0, NULL
    //     0xc6c26c: bl              #0x4b92e4
    // 0xc6c270: r16 = <void?>
    //     0xc6c270: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc6c274: r30 = Instance_MethodChannel
    //     0xc6c274: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc6c278: ldr             lr, [lr, #0x370]
    // 0xc6c27c: stp             lr, x16, [SP, #-0x10]!
    // 0xc6c280: r16 = "stopImageStream"
    //     0xc6c280: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d6c0] "stopImageStream"
    //     0xc6c284: ldr             x16, [x16, #0x6c0]
    // 0xc6c288: SaveReg r16
    //     0xc6c288: str             x16, [SP, #-8]!
    // 0xc6c28c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6c28c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6c290: r0 = invokeMethod()
    //     0xc6c290: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6c294: add             SP, SP, #0x18
    // 0xc6c298: mov             x1, x0
    // 0xc6c29c: stur            x1, [fp, #-0x18]
    // 0xc6c2a0: r0 = Await()
    //     0xc6c2a0: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6c2a4: ldur            x1, [fp, #-0x10]
    // 0xc6c2a8: LoadField: r0 = r1->field_13
    //     0xc6c2a8: ldur            w0, [x1, #0x13]
    // 0xc6c2ac: DecompressPointer r0
    //     0xc6c2ac: add             x0, x0, HEAP, lsl #32
    // 0xc6c2b0: cmp             w0, NULL
    // 0xc6c2b4: b.ne            #0xc6c2c0
    // 0xc6c2b8: r2 = Null
    //     0xc6c2b8: mov             x2, NULL
    // 0xc6c2bc: b               #0xc6c2e8
    // 0xc6c2c0: r2 = LoadClassIdInstr(r0)
    //     0xc6c2c0: ldur            x2, [x0, #-1]
    //     0xc6c2c4: ubfx            x2, x2, #0xc, #0x14
    // 0xc6c2c8: SaveReg r0
    //     0xc6c2c8: str             x0, [SP, #-8]!
    // 0xc6c2cc: mov             x0, x2
    // 0xc6c2d0: r0 = GDT[cid_x0 + 0x307]()
    //     0xc6c2d0: add             lr, x0, #0x307
    //     0xc6c2d4: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c2d8: blr             lr
    // 0xc6c2dc: add             SP, SP, #8
    // 0xc6c2e0: mov             x2, x0
    // 0xc6c2e4: ldur            x1, [fp, #-0x10]
    // 0xc6c2e8: mov             x0, x2
    // 0xc6c2ec: stur            x2, [fp, #-0x18]
    // 0xc6c2f0: r0 = Await()
    //     0xc6c2f0: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6c2f4: ldur            x1, [fp, #-0x10]
    // 0xc6c2f8: StoreField: r1->field_13 = rNULL
    //     0xc6c2f8: stur            NULL, [x1, #0x13]
    // 0xc6c2fc: StoreField: r1->field_17 = rNULL
    //     0xc6c2fc: stur            NULL, [x1, #0x17]
    // 0xc6c300: r0 = Null
    //     0xc6c300: mov             x0, NULL
    // 0xc6c304: r0 = ReturnAsyncNotFuture()
    //     0xc6c304: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc6c308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6c308: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6c30c: b               #0xc6c268
  }
  [closure] void _onFrameStreamPauseResume(dynamic) {
    // ** addr: 0xc6c310, size: 0x48
    // 0xc6c310: EnterFrame
    //     0xc6c310: stp             fp, lr, [SP, #-0x10]!
    //     0xc6c314: mov             fp, SP
    // 0xc6c318: ldr             x0, [fp, #0x10]
    // 0xc6c31c: LoadField: r1 = r0->field_17
    //     0xc6c31c: ldur            w1, [x0, #0x17]
    // 0xc6c320: DecompressPointer r1
    //     0xc6c320: add             x1, x1, HEAP, lsl #32
    // 0xc6c324: CheckStackOverflow
    //     0xc6c324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6c328: cmp             SP, x16
    //     0xc6c32c: b.ls            #0xc6c350
    // 0xc6c330: LoadField: r0 = r1->field_f
    //     0xc6c330: ldur            w0, [x1, #0xf]
    // 0xc6c334: DecompressPointer r0
    //     0xc6c334: add             x0, x0, HEAP, lsl #32
    // 0xc6c338: SaveReg r0
    //     0xc6c338: str             x0, [SP, #-8]!
    // 0xc6c33c: r0 = _onFrameStreamPauseResume()
    //     0xc6c33c: bl              #0xc6b6a0  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamPauseResume
    // 0xc6c340: add             SP, SP, #8
    // 0xc6c344: LeaveFrame
    //     0xc6c344: mov             SP, fp
    //     0xc6c348: ldp             fp, lr, [SP], #0x10
    // 0xc6c34c: ret
    //     0xc6c34c: ret             
    // 0xc6c350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6c350: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6c354: b               #0xc6c330
  }
  _ takePicture(/* No info */) async {
    // ** addr: 0xc72f1c, size: 0x1e0
    // 0xc72f1c: EnterFrame
    //     0xc72f1c: stp             fp, lr, [SP, #-0x10]!
    //     0xc72f20: mov             fp, SP
    // 0xc72f24: AllocStack(0x20)
    //     0xc72f24: sub             SP, SP, #0x20
    // 0xc72f28: SetupParameters(AVFoundationCamera this /* r1, fp-0x10 */)
    //     0xc72f28: stur            NULL, [fp, #-8]
    //     0xc72f2c: mov             x0, #0
    //     0xc72f30: add             x1, fp, w0, sxtw #2
    //     0xc72f34: ldr             x1, [x1, #0x10]
    //     0xc72f38: stur            x1, [fp, #-0x10]
    // 0xc72f3c: CheckStackOverflow
    //     0xc72f3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc72f40: cmp             SP, x16
    //     0xc72f44: b.ls            #0xc730f4
    // 0xc72f48: InitAsync() -> Future<XFile>
    //     0xc72f48: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d698] TypeArguments: <XFile>
    //     0xc72f4c: ldr             x0, [x0, #0x698]
    //     0xc72f50: bl              #0x4b92e4
    // 0xc72f54: r1 = Null
    //     0xc72f54: mov             x1, NULL
    // 0xc72f58: r2 = 4
    //     0xc72f58: mov             x2, #4
    // 0xc72f5c: r0 = AllocateArray()
    //     0xc72f5c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc72f60: mov             x2, x0
    // 0xc72f64: r17 = "cameraId"
    //     0xc72f64: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc72f68: ldr             x17, [x17, #0x890]
    // 0xc72f6c: StoreField: r2->field_f = r17
    //     0xc72f6c: stur            w17, [x2, #0xf]
    // 0xc72f70: ldur            x3, [fp, #-0x10]
    // 0xc72f74: r0 = BoxInt64Instr(r3)
    //     0xc72f74: sbfiz           x0, x3, #1, #0x1f
    //     0xc72f78: cmp             x3, x0, asr #1
    //     0xc72f7c: b.eq            #0xc72f88
    //     0xc72f80: bl              #0xd69bb8
    //     0xc72f84: stur            x3, [x0, #7]
    // 0xc72f88: StoreField: r2->field_13 = r0
    //     0xc72f88: stur            w0, [x2, #0x13]
    // 0xc72f8c: r16 = <String, dynamic>
    //     0xc72f8c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc72f90: stp             x2, x16, [SP, #-0x10]!
    // 0xc72f94: r0 = Map._fromLiteral()
    //     0xc72f94: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc72f98: add             SP, SP, #0x10
    // 0xc72f9c: r16 = <String>
    //     0xc72f9c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xc72fa0: r30 = Instance_MethodChannel
    //     0xc72fa0: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc72fa4: ldr             lr, [lr, #0x370]
    // 0xc72fa8: stp             lr, x16, [SP, #-0x10]!
    // 0xc72fac: r16 = "takePicture"
    //     0xc72fac: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d788] "takePicture"
    //     0xc72fb0: ldr             x16, [x16, #0x788]
    // 0xc72fb4: stp             x0, x16, [SP, #-0x10]!
    // 0xc72fb8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc72fb8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc72fbc: r0 = invokeMethod()
    //     0xc72fbc: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc72fc0: add             SP, SP, #0x20
    // 0xc72fc4: mov             x1, x0
    // 0xc72fc8: stur            x1, [fp, #-0x18]
    // 0xc72fcc: r0 = Await()
    //     0xc72fcc: bl              #0x4b8e6c  ; AwaitStub
    // 0xc72fd0: stur            x0, [fp, #-0x20]
    // 0xc72fd4: cmp             w0, NULL
    // 0xc72fd8: b.eq            #0xc73064
    // 0xc72fdc: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc72fdc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc72fe0: ldr             x0, [x0, #0xb58]
    //     0xc72fe4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc72fe8: cmp             w0, w16
    //     0xc72fec: b.ne            #0xc72ff8
    //     0xc72ff0: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc72ff4: bl              #0xd67d44
    // 0xc72ff8: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc72ff8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc72ffc: ldr             x0, [x0, #0xdd8]
    //     0xc73000: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc73004: cmp             w0, w16
    //     0xc73008: b.ne            #0xc73014
    //     0xc7300c: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc73010: bl              #0xd67cdc
    // 0xc73014: r0 = _File()
    //     0xc73014: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xc73018: mov             x1, x0
    // 0xc7301c: ldur            x0, [fp, #-0x20]
    // 0xc73020: stur            x1, [fp, #-0x18]
    // 0xc73024: StoreField: r1->field_7 = r0
    //     0xc73024: stur            w0, [x1, #7]
    // 0xc73028: SaveReg r0
    //     0xc73028: str             x0, [SP, #-8]!
    // 0xc7302c: r0 = _toUtf8Array()
    //     0xc7302c: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc73030: add             SP, SP, #8
    // 0xc73034: ldur            x1, [fp, #-0x18]
    // 0xc73038: StoreField: r1->field_b = r0
    //     0xc73038: stur            w0, [x1, #0xb]
    //     0xc7303c: ldurb           w16, [x1, #-1]
    //     0xc73040: ldurb           w17, [x0, #-1]
    //     0xc73044: and             x16, x17, x16, lsr #2
    //     0xc73048: tst             x16, HEAP, lsr #32
    //     0xc7304c: b.eq            #0xc73054
    //     0xc73050: bl              #0xd6826c
    // 0xc73054: r0 = XFile()
    //     0xc73054: bl              #0xc6a500  ; AllocateXFileStub -> XFile (size=0x10)
    // 0xc73058: ldur            x1, [fp, #-0x18]
    // 0xc7305c: StoreField: r0->field_7 = r1
    //     0xc7305c: stur            w1, [x0, #7]
    // 0xc73060: r0 = ReturnAsyncNotFuture()
    //     0xc73060: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc73064: r1 = Null
    //     0xc73064: mov             x1, NULL
    // 0xc73068: r2 = 6
    //     0xc73068: mov             x2, #6
    // 0xc7306c: r0 = AllocateArray()
    //     0xc7306c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc73070: stur            x0, [fp, #-0x18]
    // 0xc73074: r17 = "The platform \""
    //     0xc73074: add             x17, PP, #0x53, lsl #12  ; [pp+0x53af8] "The platform \""
    //     0xc73078: ldr             x17, [x17, #0xaf8]
    // 0xc7307c: StoreField: r0->field_f = r17
    //     0xc7307c: stur            w17, [x0, #0xf]
    // 0xc73080: r0 = defaultTargetPlatform()
    //     0xc73080: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xc73084: ldur            x1, [fp, #-0x18]
    // 0xc73088: ArrayStore: r1[1] = r0  ; List_4
    //     0xc73088: add             x25, x1, #0x13
    //     0xc7308c: str             w0, [x25]
    //     0xc73090: tbz             w0, #0, #0xc730ac
    //     0xc73094: ldurb           w16, [x1, #-1]
    //     0xc73098: ldurb           w17, [x0, #-1]
    //     0xc7309c: and             x16, x17, x16, lsr #2
    //     0xc730a0: tst             x16, HEAP, lsr #32
    //     0xc730a4: b.eq            #0xc730ac
    //     0xc730a8: bl              #0xd67e5c
    // 0xc730ac: ldur            x0, [fp, #-0x18]
    // 0xc730b0: r17 = "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc730b0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b00] "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc730b4: ldr             x17, [x17, #0xb00]
    // 0xc730b8: StoreField: r0->field_17 = r17
    //     0xc730b8: stur            w17, [x0, #0x17]
    // 0xc730bc: SaveReg r0
    //     0xc730bc: str             x0, [SP, #-8]!
    // 0xc730c0: r0 = _interpolate()
    //     0xc730c0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc730c4: add             SP, SP, #8
    // 0xc730c8: stur            x0, [fp, #-0x18]
    // 0xc730cc: r0 = CameraException()
    //     0xc730cc: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc730d0: mov             x1, x0
    // 0xc730d4: r0 = "INVALID_PATH"
    //     0xc730d4: add             x0, PP, #0x53, lsl #12  ; [pp+0x53b08] "INVALID_PATH"
    //     0xc730d8: ldr             x0, [x0, #0xb08]
    // 0xc730dc: StoreField: r1->field_7 = r0
    //     0xc730dc: stur            w0, [x1, #7]
    // 0xc730e0: ldur            x0, [fp, #-0x18]
    // 0xc730e4: StoreField: r1->field_b = r0
    //     0xc730e4: stur            w0, [x1, #0xb]
    // 0xc730e8: mov             x0, x1
    // 0xc730ec: r0 = Throw()
    //     0xc730ec: bl              #0xd67e38  ; ThrowStub
    // 0xc730f0: brk             #0
    // 0xc730f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc730f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc730f8: b               #0xc72f48
  }
  _ onCameraInitialized(/* No info */) {
    // ** addr: 0xc75904, size: 0x58
    // 0xc75904: EnterFrame
    //     0xc75904: stp             fp, lr, [SP, #-0x10]!
    //     0xc75908: mov             fp, SP
    // 0xc7590c: CheckStackOverflow
    //     0xc7590c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc75910: cmp             SP, x16
    //     0xc75914: b.ls            #0xc75954
    // 0xc75918: ldr             x16, [fp, #0x18]
    // 0xc7591c: SaveReg r16
    //     0xc7591c: str             x16, [SP, #-8]!
    // 0xc75920: ldr             x0, [fp, #0x10]
    // 0xc75924: SaveReg r0
    //     0xc75924: str             x0, [SP, #-8]!
    // 0xc75928: r0 = _cameraEvents()
    //     0xc75928: bl              #0x5aa7e4  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_cameraEvents
    // 0xc7592c: add             SP, SP, #0x10
    // 0xc75930: r16 = <CameraEvent, CameraInitializedEvent>
    //     0xc75930: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d3a8] TypeArguments: <CameraEvent, CameraInitializedEvent>
    //     0xc75934: ldr             x16, [x16, #0x3a8]
    // 0xc75938: stp             x0, x16, [SP, #-0x10]!
    // 0xc7593c: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xc7593c: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xc75940: r0 = Where.whereType()
    //     0xc75940: bl              #0x5aa93c  ; [package:stream_transform/src/where.dart] ::Where.whereType
    // 0xc75944: add             SP, SP, #0x10
    // 0xc75948: LeaveFrame
    //     0xc75948: mov             SP, fp
    //     0xc7594c: ldp             fp, lr, [SP], #0x10
    // 0xc75950: ret
    //     0xc75950: ret             
    // 0xc75954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc75954: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc75958: b               #0xc75918
  }
  _ dispose(/* No info */) async {
    // ** addr: 0xc76490, size: 0x14c
    // 0xc76490: EnterFrame
    //     0xc76490: stp             fp, lr, [SP, #-0x10]!
    //     0xc76494: mov             fp, SP
    // 0xc76498: AllocStack(0x20)
    //     0xc76498: sub             SP, SP, #0x20
    // 0xc7649c: SetupParameters(AVFoundationCamera this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xc7649c: stur            NULL, [fp, #-8]
    //     0xc764a0: mov             x0, #0
    //     0xc764a4: add             x1, fp, w0, sxtw #2
    //     0xc764a8: ldr             x1, [x1, #0x18]
    //     0xc764ac: stur            x1, [fp, #-0x18]
    //     0xc764b0: add             x2, fp, w0, sxtw #2
    //     0xc764b4: ldr             x2, [x2, #0x10]
    //     0xc764b8: stur            x2, [fp, #-0x10]
    // 0xc764bc: CheckStackOverflow
    //     0xc764bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc764c0: cmp             SP, x16
    //     0xc764c4: b.ls            #0xc765d4
    // 0xc764c8: InitAsync() -> Future<void?>
    //     0xc764c8: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc764cc: bl              #0x4b92e4
    // 0xc764d0: ldur            x0, [fp, #-0x18]
    // 0xc764d4: LoadField: r2 = r0->field_7
    //     0xc764d4: ldur            w2, [x0, #7]
    // 0xc764d8: DecompressPointer r2
    //     0xc764d8: add             x2, x2, HEAP, lsl #32
    // 0xc764dc: ldur            x3, [fp, #-0x10]
    // 0xc764e0: stur            x2, [fp, #-0x20]
    // 0xc764e4: r0 = BoxInt64Instr(r3)
    //     0xc764e4: sbfiz           x0, x3, #1, #0x1f
    //     0xc764e8: cmp             x3, x0, asr #1
    //     0xc764ec: b.eq            #0xc764f8
    //     0xc764f0: bl              #0xd69bb8
    //     0xc764f4: stur            x3, [x0, #7]
    // 0xc764f8: stur            x0, [fp, #-0x18]
    // 0xc764fc: stp             x0, x2, [SP, #-0x10]!
    // 0xc76500: r0 = containsKey()
    //     0xc76500: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xc76504: add             SP, SP, #0x10
    // 0xc76508: tbnz            w0, #4, #0xc76564
    // 0xc7650c: ldur            x0, [fp, #-0x20]
    // 0xc76510: ldur            x16, [fp, #-0x18]
    // 0xc76514: stp             x16, x0, [SP, #-0x10]!
    // 0xc76518: r0 = _getValueOrData()
    //     0xc76518: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc7651c: add             SP, SP, #0x10
    // 0xc76520: mov             x1, x0
    // 0xc76524: ldur            x0, [fp, #-0x20]
    // 0xc76528: LoadField: r2 = r0->field_f
    //     0xc76528: ldur            w2, [x0, #0xf]
    // 0xc7652c: DecompressPointer r2
    //     0xc7652c: add             x2, x2, HEAP, lsl #32
    // 0xc76530: cmp             w2, w1
    // 0xc76534: b.ne            #0xc7653c
    // 0xc76538: r1 = Null
    //     0xc76538: mov             x1, NULL
    // 0xc7653c: cmp             w1, NULL
    // 0xc76540: b.eq            #0xc76550
    // 0xc76544: stp             NULL, x1, [SP, #-0x10]!
    // 0xc76548: r0 = setMethodCallHandler()
    //     0xc76548: bl              #0x5a84a0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0xc7654c: add             SP, SP, #0x10
    // 0xc76550: ldur            x16, [fp, #-0x20]
    // 0xc76554: ldur            lr, [fp, #-0x18]
    // 0xc76558: stp             lr, x16, [SP, #-0x10]!
    // 0xc7655c: r0 = remove()
    //     0xc7655c: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc76560: add             SP, SP, #0x10
    // 0xc76564: ldur            x0, [fp, #-0x18]
    // 0xc76568: r1 = Null
    //     0xc76568: mov             x1, NULL
    // 0xc7656c: r2 = 4
    //     0xc7656c: mov             x2, #4
    // 0xc76570: r0 = AllocateArray()
    //     0xc76570: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc76574: r17 = "cameraId"
    //     0xc76574: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc76578: ldr             x17, [x17, #0x890]
    // 0xc7657c: StoreField: r0->field_f = r17
    //     0xc7657c: stur            w17, [x0, #0xf]
    // 0xc76580: ldur            x1, [fp, #-0x18]
    // 0xc76584: StoreField: r0->field_13 = r1
    //     0xc76584: stur            w1, [x0, #0x13]
    // 0xc76588: r16 = <String, dynamic>
    //     0xc76588: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc7658c: stp             x0, x16, [SP, #-0x10]!
    // 0xc76590: r0 = Map._fromLiteral()
    //     0xc76590: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc76594: add             SP, SP, #0x10
    // 0xc76598: r16 = <void?>
    //     0xc76598: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc7659c: r30 = Instance_MethodChannel
    //     0xc7659c: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc765a0: ldr             lr, [lr, #0x370]
    // 0xc765a4: stp             lr, x16, [SP, #-0x10]!
    // 0xc765a8: r16 = "dispose"
    //     0xc765a8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f010] "dispose"
    //     0xc765ac: ldr             x16, [x16, #0x10]
    // 0xc765b0: stp             x0, x16, [SP, #-0x10]!
    // 0xc765b4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc765b4: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc765b8: r0 = invokeMethod()
    //     0xc765b8: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc765bc: add             SP, SP, #0x20
    // 0xc765c0: mov             x1, x0
    // 0xc765c4: stur            x1, [fp, #-0x18]
    // 0xc765c8: r0 = Await()
    //     0xc765c8: bl              #0x4b8e6c  ; AwaitStub
    // 0xc765cc: r0 = Null
    //     0xc765cc: mov             x0, NULL
    // 0xc765d0: r0 = ReturnAsyncNotFuture()
    //     0xc765d0: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc765d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc765d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc765d8: b               #0xc764c8
  }
  _ initializeCamera(/* No info */) {
    // ** addr: 0xc77720, size: 0x20c
    // 0xc77720: EnterFrame
    //     0xc77720: stp             fp, lr, [SP, #-0x10]!
    //     0xc77724: mov             fp, SP
    // 0xc77728: AllocStack(0x18)
    //     0xc77728: sub             SP, SP, #0x18
    // 0xc7772c: CheckStackOverflow
    //     0xc7772c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc77730: cmp             SP, x16
    //     0xc77734: b.ls            #0xc77924
    // 0xc77738: r1 = 3
    //     0xc77738: mov             x1, #3
    // 0xc7773c: r0 = AllocateContext()
    //     0xc7773c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc77740: mov             x4, x0
    // 0xc77744: ldr             x3, [fp, #0x20]
    // 0xc77748: stur            x4, [fp, #-0x18]
    // 0xc7774c: StoreField: r4->field_f = r3
    //     0xc7774c: stur            w3, [x4, #0xf]
    // 0xc77750: ldr             x2, [fp, #0x18]
    // 0xc77754: r0 = BoxInt64Instr(r2)
    //     0xc77754: sbfiz           x0, x2, #1, #0x1f
    //     0xc77758: cmp             x2, x0, asr #1
    //     0xc7775c: b.eq            #0xc77768
    //     0xc77760: bl              #0xd69bb8
    //     0xc77764: stur            x2, [x0, #7]
    // 0xc77768: stur            x0, [fp, #-0x10]
    // 0xc7776c: StoreField: r4->field_13 = r0
    //     0xc7776c: stur            w0, [x4, #0x13]
    // 0xc77770: LoadField: r5 = r3->field_7
    //     0xc77770: ldur            w5, [x3, #7]
    // 0xc77774: DecompressPointer r5
    //     0xc77774: add             x5, x5, HEAP, lsl #32
    // 0xc77778: mov             x2, x4
    // 0xc7777c: stur            x5, [fp, #-8]
    // 0xc77780: r1 = Function '<anonymous closure>':.
    //     0xc77780: add             x1, PP, #0x53, lsl #12  ; [pp+0x53fa8] AnonymousClosure: (0xc7792c), in [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::initializeCamera (0xc77720)
    //     0xc77784: ldr             x1, [x1, #0xfa8]
    // 0xc77788: r0 = AllocateClosure()
    //     0xc77788: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc7778c: ldur            x16, [fp, #-8]
    // 0xc77790: ldur            lr, [fp, #-0x10]
    // 0xc77794: stp             lr, x16, [SP, #-0x10]!
    // 0xc77798: SaveReg r0
    //     0xc77798: str             x0, [SP, #-8]!
    // 0xc7779c: r0 = putIfAbsent()
    //     0xc7779c: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xc777a0: add             SP, SP, #0x18
    // 0xc777a4: r1 = <void?>
    //     0xc777a4: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc777a8: r0 = _Future()
    //     0xc777a8: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xc777ac: mov             x1, x0
    // 0xc777b0: r0 = 0
    //     0xc777b0: mov             x0, #0
    // 0xc777b4: stur            x1, [fp, #-8]
    // 0xc777b8: StoreField: r1->field_b = r0
    //     0xc777b8: stur            x0, [x1, #0xb]
    // 0xc777bc: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc777bc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc777c0: ldr             x0, [x0, #0xb58]
    //     0xc777c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc777c8: cmp             w0, w16
    //     0xc777cc: b.ne            #0xc777d8
    //     0xc777d0: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc777d4: bl              #0xd67d44
    // 0xc777d8: mov             x1, x0
    // 0xc777dc: ldur            x0, [fp, #-8]
    // 0xc777e0: StoreField: r0->field_13 = r1
    //     0xc777e0: stur            w1, [x0, #0x13]
    // 0xc777e4: r1 = <void?>
    //     0xc777e4: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc777e8: r0 = _AsyncCompleter()
    //     0xc777e8: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xc777ec: ldur            x1, [fp, #-8]
    // 0xc777f0: StoreField: r0->field_b = r1
    //     0xc777f0: stur            w1, [x0, #0xb]
    // 0xc777f4: ldur            x2, [fp, #-0x18]
    // 0xc777f8: StoreField: r2->field_17 = r0
    //     0xc777f8: stur            w0, [x2, #0x17]
    //     0xc777fc: ldurb           w16, [x2, #-1]
    //     0xc77800: ldurb           w17, [x0, #-1]
    //     0xc77804: and             x16, x17, x16, lsr #2
    //     0xc77808: tst             x16, HEAP, lsr #32
    //     0xc7780c: b.eq            #0xc77814
    //     0xc77810: bl              #0xd6828c
    // 0xc77814: LoadField: r0 = r2->field_13
    //     0xc77814: ldur            w0, [x2, #0x13]
    // 0xc77818: DecompressPointer r0
    //     0xc77818: add             x0, x0, HEAP, lsl #32
    // 0xc7781c: r3 = LoadInt32Instr(r0)
    //     0xc7781c: sbfx            x3, x0, #1, #0x1f
    //     0xc77820: tbz             w0, #0, #0xc77828
    //     0xc77824: ldur            x3, [x0, #7]
    // 0xc77828: ldr             x16, [fp, #0x20]
    // 0xc7782c: stp             x3, x16, [SP, #-0x10]!
    // 0xc77830: r0 = onCameraInitialized()
    //     0xc77830: bl              #0xc75904  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::onCameraInitialized
    // 0xc77834: add             SP, SP, #0x10
    // 0xc77838: SaveReg r0
    //     0xc77838: str             x0, [SP, #-8]!
    // 0xc7783c: r0 = first()
    //     0xc7783c: bl              #0x5aa0d4  ; [dart:async] Stream::first
    // 0xc77840: add             SP, SP, #8
    // 0xc77844: ldur            x2, [fp, #-0x18]
    // 0xc77848: r1 = Function '<anonymous closure>':.
    //     0xc77848: add             x1, PP, #0x53, lsl #12  ; [pp+0x53fb0] AnonymousClosure: (0x9ec1e4), in [package:flutter3_frame/modules/chat/chat_user_logic.dart] ChatUserLogic::getUserFromServer (0x9ebfe8)
    //     0xc7784c: ldr             x1, [x1, #0xfb0]
    // 0xc77850: stur            x0, [fp, #-0x10]
    // 0xc77854: r0 = AllocateClosure()
    //     0xc77854: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc77858: r16 = <Null?>
    //     0xc77858: ldr             x16, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    // 0xc7785c: ldur            lr, [fp, #-0x10]
    // 0xc77860: stp             lr, x16, [SP, #-0x10]!
    // 0xc77864: SaveReg r0
    //     0xc77864: str             x0, [SP, #-8]!
    // 0xc77868: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc77868: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc7786c: r0 = then()
    //     0xc7786c: bl              #0xca6124  ; [dart:async] _Future::then
    // 0xc77870: add             SP, SP, #0x18
    // 0xc77874: r1 = Null
    //     0xc77874: mov             x1, NULL
    // 0xc77878: r2 = 8
    //     0xc77878: mov             x2, #8
    // 0xc7787c: r0 = AllocateArray()
    //     0xc7787c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc77880: r17 = "cameraId"
    //     0xc77880: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc77884: ldr             x17, [x17, #0x890]
    // 0xc77888: StoreField: r0->field_f = r17
    //     0xc77888: stur            w17, [x0, #0xf]
    // 0xc7788c: ldur            x2, [fp, #-0x18]
    // 0xc77890: LoadField: r1 = r2->field_13
    //     0xc77890: ldur            w1, [x2, #0x13]
    // 0xc77894: DecompressPointer r1
    //     0xc77894: add             x1, x1, HEAP, lsl #32
    // 0xc77898: StoreField: r0->field_13 = r1
    //     0xc77898: stur            w1, [x0, #0x13]
    // 0xc7789c: r17 = "imageFormatGroup"
    //     0xc7789c: add             x17, PP, #0x53, lsl #12  ; [pp+0x53cb0] "imageFormatGroup"
    //     0xc778a0: ldr             x17, [x17, #0xcb0]
    // 0xc778a4: StoreField: r0->field_17 = r17
    //     0xc778a4: stur            w17, [x0, #0x17]
    // 0xc778a8: r17 = "unknown"
    //     0xc778a8: add             x17, PP, #0x14, lsl #12  ; [pp+0x14af8] "unknown"
    //     0xc778ac: ldr             x17, [x17, #0xaf8]
    // 0xc778b0: StoreField: r0->field_1b = r17
    //     0xc778b0: stur            w17, [x0, #0x1b]
    // 0xc778b4: r16 = <String, dynamic>
    //     0xc778b4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc778b8: stp             x0, x16, [SP, #-0x10]!
    // 0xc778bc: r0 = Map._fromLiteral()
    //     0xc778bc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc778c0: add             SP, SP, #0x10
    // 0xc778c4: r16 = <String, dynamic>
    //     0xc778c4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc778c8: r30 = Instance_MethodChannel
    //     0xc778c8: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc778cc: ldr             lr, [lr, #0x370]
    // 0xc778d0: stp             lr, x16, [SP, #-0x10]!
    // 0xc778d4: r16 = "initialize"
    //     0xc778d4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53cb8] "initialize"
    //     0xc778d8: ldr             x16, [x16, #0xcb8]
    // 0xc778dc: stp             x0, x16, [SP, #-0x10]!
    // 0xc778e0: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0xc778e0: ldr             x4, [PP, #0x8c0]  ; [pp+0x8c0] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0xc778e4: r0 = invokeMapMethod()
    //     0xc778e4: bl              #0x5a21c4  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0xc778e8: add             SP, SP, #0x20
    // 0xc778ec: ldur            x2, [fp, #-0x18]
    // 0xc778f0: r1 = Function '<anonymous closure>':.
    //     0xc778f0: add             x1, PP, #0x53, lsl #12  ; [pp+0x53fb8] AnonymousClosure: (0xc76a40), in [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::initializeCamera (0xc78354)
    //     0xc778f4: ldr             x1, [x1, #0xfb8]
    // 0xc778f8: stur            x0, [fp, #-0x10]
    // 0xc778fc: r0 = AllocateClosure()
    //     0xc778fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc77900: ldur            x16, [fp, #-0x10]
    // 0xc77904: stp             x0, x16, [SP, #-0x10]!
    // 0xc77908: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc77908: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc7790c: r0 = catchError()
    //     0xc7790c: bl              #0xca5bb8  ; [dart:async] _Future::catchError
    // 0xc77910: add             SP, SP, #0x10
    // 0xc77914: ldur            x0, [fp, #-8]
    // 0xc77918: LeaveFrame
    //     0xc77918: mov             SP, fp
    //     0xc7791c: ldp             fp, lr, [SP], #0x10
    // 0xc77920: ret
    //     0xc77920: ret             
    // 0xc77924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc77924: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc77928: b               #0xc77738
  }
  [closure] MethodChannel <anonymous closure>(dynamic) {
    // ** addr: 0xc7792c, size: 0xb8
    // 0xc7792c: EnterFrame
    //     0xc7792c: stp             fp, lr, [SP, #-0x10]!
    //     0xc77930: mov             fp, SP
    // 0xc77934: AllocStack(0x18)
    //     0xc77934: sub             SP, SP, #0x18
    // 0xc77938: SetupParameters()
    //     0xc77938: ldr             x0, [fp, #0x10]
    //     0xc7793c: ldur            w3, [x0, #0x17]
    //     0xc77940: add             x3, x3, HEAP, lsl #32
    //     0xc77944: stur            x3, [fp, #-8]
    // 0xc77948: CheckStackOverflow
    //     0xc77948: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7794c: cmp             SP, x16
    //     0xc77950: b.ls            #0xc779dc
    // 0xc77954: r1 = Null
    //     0xc77954: mov             x1, NULL
    // 0xc77958: r2 = 4
    //     0xc77958: mov             x2, #4
    // 0xc7795c: r0 = AllocateArray()
    //     0xc7795c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc77960: r17 = "plugins.flutter.io/camera_avfoundation/camera"
    //     0xc77960: add             x17, PP, #0x53, lsl #12  ; [pp+0x53fc0] "plugins.flutter.io/camera_avfoundation/camera"
    //     0xc77964: ldr             x17, [x17, #0xfc0]
    // 0xc77968: StoreField: r0->field_f = r17
    //     0xc77968: stur            w17, [x0, #0xf]
    // 0xc7796c: ldur            x2, [fp, #-8]
    // 0xc77970: LoadField: r1 = r2->field_13
    //     0xc77970: ldur            w1, [x2, #0x13]
    // 0xc77974: DecompressPointer r1
    //     0xc77974: add             x1, x1, HEAP, lsl #32
    // 0xc77978: StoreField: r0->field_13 = r1
    //     0xc77978: stur            w1, [x0, #0x13]
    // 0xc7797c: SaveReg r0
    //     0xc7797c: str             x0, [SP, #-8]!
    // 0xc77980: r0 = _interpolate()
    //     0xc77980: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc77984: add             SP, SP, #8
    // 0xc77988: stur            x0, [fp, #-0x10]
    // 0xc7798c: r0 = MethodChannel()
    //     0xc7798c: bl              #0x5a2760  ; AllocateMethodChannelStub -> MethodChannel (size=0x14)
    // 0xc77990: mov             x3, x0
    // 0xc77994: ldur            x0, [fp, #-0x10]
    // 0xc77998: stur            x3, [fp, #-0x18]
    // 0xc7799c: StoreField: r3->field_7 = r0
    //     0xc7799c: stur            w0, [x3, #7]
    // 0xc779a0: r0 = Instance_StandardMethodCodec
    //     0xc779a0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14cc0] Obj!StandardMethodCodec@b35011
    //     0xc779a4: ldr             x0, [x0, #0xcc0]
    // 0xc779a8: StoreField: r3->field_b = r0
    //     0xc779a8: stur            w0, [x3, #0xb]
    // 0xc779ac: ldur            x2, [fp, #-8]
    // 0xc779b0: r1 = Function '<anonymous closure>':.
    //     0xc779b0: add             x1, PP, #0x53, lsl #12  ; [pp+0x53fc8] AnonymousClosure: (0xc779e4), in [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::initializeCamera (0xc77720)
    //     0xc779b4: ldr             x1, [x1, #0xfc8]
    // 0xc779b8: r0 = AllocateClosure()
    //     0xc779b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc779bc: ldur            x16, [fp, #-0x18]
    // 0xc779c0: stp             x0, x16, [SP, #-0x10]!
    // 0xc779c4: r0 = setMethodCallHandler()
    //     0xc779c4: bl              #0x5a84a0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0xc779c8: add             SP, SP, #0x10
    // 0xc779cc: ldur            x0, [fp, #-0x18]
    // 0xc779d0: LeaveFrame
    //     0xc779d0: mov             SP, fp
    //     0xc779d4: ldp             fp, lr, [SP], #0x10
    // 0xc779d8: ret
    //     0xc779d8: ret             
    // 0xc779dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc779dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc779e0: b               #0xc77954
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, MethodCall) {
    // ** addr: 0xc779e4, size: 0x64
    // 0xc779e4: EnterFrame
    //     0xc779e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc779e8: mov             fp, SP
    // 0xc779ec: ldr             x0, [fp, #0x18]
    // 0xc779f0: LoadField: r1 = r0->field_17
    //     0xc779f0: ldur            w1, [x0, #0x17]
    // 0xc779f4: DecompressPointer r1
    //     0xc779f4: add             x1, x1, HEAP, lsl #32
    // 0xc779f8: CheckStackOverflow
    //     0xc779f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc779fc: cmp             SP, x16
    //     0xc77a00: b.ls            #0xc77a40
    // 0xc77a04: LoadField: r0 = r1->field_f
    //     0xc77a04: ldur            w0, [x1, #0xf]
    // 0xc77a08: DecompressPointer r0
    //     0xc77a08: add             x0, x0, HEAP, lsl #32
    // 0xc77a0c: LoadField: r2 = r1->field_13
    //     0xc77a0c: ldur            w2, [x1, #0x13]
    // 0xc77a10: DecompressPointer r2
    //     0xc77a10: add             x2, x2, HEAP, lsl #32
    // 0xc77a14: r1 = LoadInt32Instr(r2)
    //     0xc77a14: sbfx            x1, x2, #1, #0x1f
    //     0xc77a18: tbz             w2, #0, #0xc77a20
    //     0xc77a1c: ldur            x1, [x2, #7]
    // 0xc77a20: ldr             x16, [fp, #0x10]
    // 0xc77a24: stp             x16, x0, [SP, #-0x10]!
    // 0xc77a28: SaveReg r1
    //     0xc77a28: str             x1, [SP, #-8]!
    // 0xc77a2c: r0 = handleCameraMethodCall()
    //     0xc77a2c: bl              #0xc77a48  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::handleCameraMethodCall
    // 0xc77a30: add             SP, SP, #0x18
    // 0xc77a34: LeaveFrame
    //     0xc77a34: mov             SP, fp
    //     0xc77a38: ldp             fp, lr, [SP], #0x10
    // 0xc77a3c: ret
    //     0xc77a3c: ret             
    // 0xc77a40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc77a40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc77a44: b               #0xc77a04
  }
  _ handleCameraMethodCall(/* No info */) async {
    // ** addr: 0xc77a48, size: 0x90c
    // 0xc77a48: EnterFrame
    //     0xc77a48: stp             fp, lr, [SP, #-0x10]!
    //     0xc77a4c: mov             fp, SP
    // 0xc77a50: AllocStack(0x70)
    //     0xc77a50: sub             SP, SP, #0x70
    // 0xc77a54: SetupParameters(AVFoundationCamera this /* r1, fp-0x20 */, dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0xc77a54: stur            NULL, [fp, #-8]
    //     0xc77a58: mov             x0, #0
    //     0xc77a5c: add             x1, fp, w0, sxtw #2
    //     0xc77a60: ldr             x1, [x1, #0x20]
    //     0xc77a64: stur            x1, [fp, #-0x20]
    //     0xc77a68: add             x2, fp, w0, sxtw #2
    //     0xc77a6c: ldr             x2, [x2, #0x18]
    //     0xc77a70: stur            x2, [fp, #-0x18]
    //     0xc77a74: add             x3, fp, w0, sxtw #2
    //     0xc77a78: ldr             x3, [x3, #0x10]
    //     0xc77a7c: stur            x3, [fp, #-0x10]
    // 0xc77a80: CheckStackOverflow
    //     0xc77a80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc77a84: cmp             SP, x16
    //     0xc77a88: b.ls            #0xc78320
    // 0xc77a8c: InitAsync() -> Future
    //     0xc77a8c: mov             x0, NULL
    //     0xc77a90: bl              #0x4b92e4
    // 0xc77a94: ldur            x0, [fp, #-0x18]
    // 0xc77a98: LoadField: r1 = r0->field_7
    //     0xc77a98: ldur            w1, [x0, #7]
    // 0xc77a9c: DecompressPointer r1
    //     0xc77a9c: add             x1, x1, HEAP, lsl #32
    // 0xc77aa0: stur            x1, [fp, #-0x28]
    // 0xc77aa4: r16 = "initialized"
    //     0xc77aa4: add             x16, PP, #0x49, lsl #12  ; [pp+0x49548] "initialized"
    //     0xc77aa8: ldr             x16, [x16, #0x548]
    // 0xc77aac: stp             x1, x16, [SP, #-0x10]!
    // 0xc77ab0: r0 = ==()
    //     0xc77ab0: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc77ab4: add             SP, SP, #0x10
    // 0xc77ab8: tbnz            w0, #4, #0xc77e0c
    // 0xc77abc: ldur            x0, [fp, #-0x20]
    // 0xc77ac0: ldur            x1, [fp, #-0x10]
    // 0xc77ac4: ldur            x16, [fp, #-0x18]
    // 0xc77ac8: stp             x16, x0, [SP, #-0x10]!
    // 0xc77acc: r0 = _getArgumentDictionary()
    //     0xc77acc: bl              #0x5abda0  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_getArgumentDictionary
    // 0xc77ad0: add             SP, SP, #0x10
    // 0xc77ad4: mov             x1, x0
    // 0xc77ad8: ldur            x0, [fp, #-0x20]
    // 0xc77adc: stur            x1, [fp, #-0x38]
    // 0xc77ae0: LoadField: r2 = r0->field_b
    //     0xc77ae0: ldur            w2, [x0, #0xb]
    // 0xc77ae4: DecompressPointer r2
    //     0xc77ae4: add             x2, x2, HEAP, lsl #32
    // 0xc77ae8: stur            x2, [fp, #-0x30]
    // 0xc77aec: r0 = LoadClassIdInstr(r1)
    //     0xc77aec: ldur            x0, [x1, #-1]
    //     0xc77af0: ubfx            x0, x0, #0xc, #0x14
    // 0xc77af4: r16 = "previewWidth"
    //     0xc77af4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53cd8] "previewWidth"
    //     0xc77af8: ldr             x16, [x16, #0xcd8]
    // 0xc77afc: stp             x16, x1, [SP, #-0x10]!
    // 0xc77b00: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77b00: sub             lr, x0, #0xef
    //     0xc77b04: ldr             lr, [x21, lr, lsl #3]
    //     0xc77b08: blr             lr
    // 0xc77b0c: add             SP, SP, #0x10
    // 0xc77b10: mov             x3, x0
    // 0xc77b14: stur            x3, [fp, #-0x40]
    // 0xc77b18: cmp             w3, NULL
    // 0xc77b1c: b.eq            #0xc78328
    // 0xc77b20: mov             x0, x3
    // 0xc77b24: r2 = Null
    //     0xc77b24: mov             x2, NULL
    // 0xc77b28: r1 = Null
    //     0xc77b28: mov             x1, NULL
    // 0xc77b2c: r4 = 59
    //     0xc77b2c: mov             x4, #0x3b
    // 0xc77b30: branchIfSmi(r0, 0xc77b3c)
    //     0xc77b30: tbz             w0, #0, #0xc77b3c
    // 0xc77b34: r4 = LoadClassIdInstr(r0)
    //     0xc77b34: ldur            x4, [x0, #-1]
    //     0xc77b38: ubfx            x4, x4, #0xc, #0x14
    // 0xc77b3c: cmp             x4, #0x3d
    // 0xc77b40: b.eq            #0xc77b54
    // 0xc77b44: r8 = double
    //     0xc77b44: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc77b48: r3 = Null
    //     0xc77b48: add             x3, PP, #0x53, lsl #12  ; [pp+0x53fd0] Null
    //     0xc77b4c: ldr             x3, [x3, #0xfd0]
    // 0xc77b50: r0 = double()
    //     0xc77b50: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc77b54: ldur            x1, [fp, #-0x38]
    // 0xc77b58: r0 = LoadClassIdInstr(r1)
    //     0xc77b58: ldur            x0, [x1, #-1]
    //     0xc77b5c: ubfx            x0, x0, #0xc, #0x14
    // 0xc77b60: r16 = "previewHeight"
    //     0xc77b60: add             x16, PP, #0x53, lsl #12  ; [pp+0x53cf0] "previewHeight"
    //     0xc77b64: ldr             x16, [x16, #0xcf0]
    // 0xc77b68: stp             x16, x1, [SP, #-0x10]!
    // 0xc77b6c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77b6c: sub             lr, x0, #0xef
    //     0xc77b70: ldr             lr, [x21, lr, lsl #3]
    //     0xc77b74: blr             lr
    // 0xc77b78: add             SP, SP, #0x10
    // 0xc77b7c: mov             x3, x0
    // 0xc77b80: stur            x3, [fp, #-0x48]
    // 0xc77b84: cmp             w3, NULL
    // 0xc77b88: b.eq            #0xc7832c
    // 0xc77b8c: mov             x0, x3
    // 0xc77b90: r2 = Null
    //     0xc77b90: mov             x2, NULL
    // 0xc77b94: r1 = Null
    //     0xc77b94: mov             x1, NULL
    // 0xc77b98: r4 = 59
    //     0xc77b98: mov             x4, #0x3b
    // 0xc77b9c: branchIfSmi(r0, 0xc77ba8)
    //     0xc77b9c: tbz             w0, #0, #0xc77ba8
    // 0xc77ba0: r4 = LoadClassIdInstr(r0)
    //     0xc77ba0: ldur            x4, [x0, #-1]
    //     0xc77ba4: ubfx            x4, x4, #0xc, #0x14
    // 0xc77ba8: cmp             x4, #0x3d
    // 0xc77bac: b.eq            #0xc77bc0
    // 0xc77bb0: r8 = double
    //     0xc77bb0: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc77bb4: r3 = Null
    //     0xc77bb4: add             x3, PP, #0x53, lsl #12  ; [pp+0x53fe0] Null
    //     0xc77bb8: ldr             x3, [x3, #0xfe0]
    // 0xc77bbc: r0 = double()
    //     0xc77bbc: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc77bc0: ldur            x1, [fp, #-0x38]
    // 0xc77bc4: r0 = LoadClassIdInstr(r1)
    //     0xc77bc4: ldur            x0, [x1, #-1]
    //     0xc77bc8: ubfx            x0, x0, #0xc, #0x14
    // 0xc77bcc: r16 = "exposureMode"
    //     0xc77bcc: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d478] "exposureMode"
    //     0xc77bd0: ldr             x16, [x16, #0x478]
    // 0xc77bd4: stp             x16, x1, [SP, #-0x10]!
    // 0xc77bd8: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77bd8: sub             lr, x0, #0xef
    //     0xc77bdc: ldr             lr, [x21, lr, lsl #3]
    //     0xc77be0: blr             lr
    // 0xc77be4: add             SP, SP, #0x10
    // 0xc77be8: mov             x3, x0
    // 0xc77bec: stur            x3, [fp, #-0x50]
    // 0xc77bf0: cmp             w3, NULL
    // 0xc77bf4: b.eq            #0xc78330
    // 0xc77bf8: mov             x0, x3
    // 0xc77bfc: r2 = Null
    //     0xc77bfc: mov             x2, NULL
    // 0xc77c00: r1 = Null
    //     0xc77c00: mov             x1, NULL
    // 0xc77c04: r4 = 59
    //     0xc77c04: mov             x4, #0x3b
    // 0xc77c08: branchIfSmi(r0, 0xc77c14)
    //     0xc77c08: tbz             w0, #0, #0xc77c14
    // 0xc77c0c: r4 = LoadClassIdInstr(r0)
    //     0xc77c0c: ldur            x4, [x0, #-1]
    //     0xc77c10: ubfx            x4, x4, #0xc, #0x14
    // 0xc77c14: sub             x4, x4, #0x5d
    // 0xc77c18: cmp             x4, #3
    // 0xc77c1c: b.ls            #0xc77c30
    // 0xc77c20: r8 = String
    //     0xc77c20: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc77c24: r3 = Null
    //     0xc77c24: add             x3, PP, #0x53, lsl #12  ; [pp+0x53ff0] Null
    //     0xc77c28: ldr             x3, [x3, #0xff0]
    // 0xc77c2c: r0 = String()
    //     0xc77c2c: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc77c30: ldur            x16, [fp, #-0x50]
    // 0xc77c34: SaveReg r16
    //     0xc77c34: str             x16, [SP, #-8]!
    // 0xc77c38: r0 = deserializeExposureMode()
    //     0xc77c38: bl              #0xc77640  ; [package:camera_platform_interface/src/types/exposure_mode.dart] ::deserializeExposureMode
    // 0xc77c3c: add             SP, SP, #8
    // 0xc77c40: mov             x2, x0
    // 0xc77c44: ldur            x1, [fp, #-0x38]
    // 0xc77c48: stur            x2, [fp, #-0x50]
    // 0xc77c4c: r0 = LoadClassIdInstr(r1)
    //     0xc77c4c: ldur            x0, [x1, #-1]
    //     0xc77c50: ubfx            x0, x0, #0xc, #0x14
    // 0xc77c54: r16 = "exposurePointSupported"
    //     0xc77c54: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d480] "exposurePointSupported"
    //     0xc77c58: ldr             x16, [x16, #0x480]
    // 0xc77c5c: stp             x16, x1, [SP, #-0x10]!
    // 0xc77c60: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77c60: sub             lr, x0, #0xef
    //     0xc77c64: ldr             lr, [x21, lr, lsl #3]
    //     0xc77c68: blr             lr
    // 0xc77c6c: add             SP, SP, #0x10
    // 0xc77c70: mov             x3, x0
    // 0xc77c74: stur            x3, [fp, #-0x58]
    // 0xc77c78: cmp             w3, NULL
    // 0xc77c7c: b.eq            #0xc78334
    // 0xc77c80: mov             x0, x3
    // 0xc77c84: r2 = Null
    //     0xc77c84: mov             x2, NULL
    // 0xc77c88: r1 = Null
    //     0xc77c88: mov             x1, NULL
    // 0xc77c8c: r4 = 59
    //     0xc77c8c: mov             x4, #0x3b
    // 0xc77c90: branchIfSmi(r0, 0xc77c9c)
    //     0xc77c90: tbz             w0, #0, #0xc77c9c
    // 0xc77c94: r4 = LoadClassIdInstr(r0)
    //     0xc77c94: ldur            x4, [x0, #-1]
    //     0xc77c98: ubfx            x4, x4, #0xc, #0x14
    // 0xc77c9c: cmp             x4, #0x3e
    // 0xc77ca0: b.eq            #0xc77cb4
    // 0xc77ca4: r8 = bool
    //     0xc77ca4: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0xc77ca8: r3 = Null
    //     0xc77ca8: add             x3, PP, #0x54, lsl #12  ; [pp+0x54000] Null
    //     0xc77cac: ldr             x3, [x3]
    // 0xc77cb0: r0 = bool()
    //     0xc77cb0: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0xc77cb4: ldur            x1, [fp, #-0x38]
    // 0xc77cb8: r0 = LoadClassIdInstr(r1)
    //     0xc77cb8: ldur            x0, [x1, #-1]
    //     0xc77cbc: ubfx            x0, x0, #0xc, #0x14
    // 0xc77cc0: r16 = "focusMode"
    //     0xc77cc0: add             x16, PP, #0x45, lsl #12  ; [pp+0x45988] "focusMode"
    //     0xc77cc4: ldr             x16, [x16, #0x988]
    // 0xc77cc8: stp             x16, x1, [SP, #-0x10]!
    // 0xc77ccc: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77ccc: sub             lr, x0, #0xef
    //     0xc77cd0: ldr             lr, [x21, lr, lsl #3]
    //     0xc77cd4: blr             lr
    // 0xc77cd8: add             SP, SP, #0x10
    // 0xc77cdc: mov             x3, x0
    // 0xc77ce0: stur            x3, [fp, #-0x60]
    // 0xc77ce4: cmp             w3, NULL
    // 0xc77ce8: b.eq            #0xc78338
    // 0xc77cec: mov             x0, x3
    // 0xc77cf0: r2 = Null
    //     0xc77cf0: mov             x2, NULL
    // 0xc77cf4: r1 = Null
    //     0xc77cf4: mov             x1, NULL
    // 0xc77cf8: r4 = 59
    //     0xc77cf8: mov             x4, #0x3b
    // 0xc77cfc: branchIfSmi(r0, 0xc77d08)
    //     0xc77cfc: tbz             w0, #0, #0xc77d08
    // 0xc77d00: r4 = LoadClassIdInstr(r0)
    //     0xc77d00: ldur            x4, [x0, #-1]
    //     0xc77d04: ubfx            x4, x4, #0xc, #0x14
    // 0xc77d08: sub             x4, x4, #0x5d
    // 0xc77d0c: cmp             x4, #3
    // 0xc77d10: b.ls            #0xc77d24
    // 0xc77d14: r8 = String
    //     0xc77d14: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc77d18: r3 = Null
    //     0xc77d18: add             x3, PP, #0x54, lsl #12  ; [pp+0x54010] Null
    //     0xc77d1c: ldr             x3, [x3, #0x10]
    // 0xc77d20: r0 = String()
    //     0xc77d20: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc77d24: ldur            x16, [fp, #-0x60]
    // 0xc77d28: SaveReg r16
    //     0xc77d28: str             x16, [SP, #-8]!
    // 0xc77d2c: r0 = deserializeFocusMode()
    //     0xc77d2c: bl              #0xc77560  ; [package:camera_platform_interface/src/types/focus_mode.dart] ::deserializeFocusMode
    // 0xc77d30: add             SP, SP, #8
    // 0xc77d34: mov             x1, x0
    // 0xc77d38: ldur            x0, [fp, #-0x38]
    // 0xc77d3c: stur            x1, [fp, #-0x60]
    // 0xc77d40: r2 = LoadClassIdInstr(r0)
    //     0xc77d40: ldur            x2, [x0, #-1]
    //     0xc77d44: ubfx            x2, x2, #0xc, #0x14
    // 0xc77d48: r16 = "focusPointSupported"
    //     0xc77d48: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d490] "focusPointSupported"
    //     0xc77d4c: ldr             x16, [x16, #0x490]
    // 0xc77d50: stp             x16, x0, [SP, #-0x10]!
    // 0xc77d54: mov             x0, x2
    // 0xc77d58: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77d58: sub             lr, x0, #0xef
    //     0xc77d5c: ldr             lr, [x21, lr, lsl #3]
    //     0xc77d60: blr             lr
    // 0xc77d64: add             SP, SP, #0x10
    // 0xc77d68: mov             x3, x0
    // 0xc77d6c: stur            x3, [fp, #-0x38]
    // 0xc77d70: cmp             w3, NULL
    // 0xc77d74: b.eq            #0xc7833c
    // 0xc77d78: mov             x0, x3
    // 0xc77d7c: r2 = Null
    //     0xc77d7c: mov             x2, NULL
    // 0xc77d80: r1 = Null
    //     0xc77d80: mov             x1, NULL
    // 0xc77d84: r4 = 59
    //     0xc77d84: mov             x4, #0x3b
    // 0xc77d88: branchIfSmi(r0, 0xc77d94)
    //     0xc77d88: tbz             w0, #0, #0xc77d94
    // 0xc77d8c: r4 = LoadClassIdInstr(r0)
    //     0xc77d8c: ldur            x4, [x0, #-1]
    //     0xc77d90: ubfx            x4, x4, #0xc, #0x14
    // 0xc77d94: cmp             x4, #0x3e
    // 0xc77d98: b.eq            #0xc77dac
    // 0xc77d9c: r8 = bool
    //     0xc77d9c: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0xc77da0: r3 = Null
    //     0xc77da0: add             x3, PP, #0x54, lsl #12  ; [pp+0x54020] Null
    //     0xc77da4: ldr             x3, [x3, #0x20]
    // 0xc77da8: r0 = bool()
    //     0xc77da8: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0xc77dac: ldur            x0, [fp, #-0x40]
    // 0xc77db0: LoadField: d0 = r0->field_7
    //     0xc77db0: ldur            d0, [x0, #7]
    // 0xc77db4: stur            d0, [fp, #-0x70]
    // 0xc77db8: r0 = CameraInitializedEvent()
    //     0xc77db8: bl              #0xc77554  ; AllocateCameraInitializedEventStub -> CameraInitializedEvent (size=0x30)
    // 0xc77dbc: ldur            d0, [fp, #-0x70]
    // 0xc77dc0: StoreField: r0->field_f = d0
    //     0xc77dc0: stur            d0, [x0, #0xf]
    // 0xc77dc4: ldur            x1, [fp, #-0x48]
    // 0xc77dc8: LoadField: d0 = r1->field_7
    //     0xc77dc8: ldur            d0, [x1, #7]
    // 0xc77dcc: StoreField: r0->field_17 = d0
    //     0xc77dcc: stur            d0, [x0, #0x17]
    // 0xc77dd0: ldur            x1, [fp, #-0x50]
    // 0xc77dd4: StoreField: r0->field_1f = r1
    //     0xc77dd4: stur            w1, [x0, #0x1f]
    // 0xc77dd8: ldur            x1, [fp, #-0x58]
    // 0xc77ddc: StoreField: r0->field_27 = r1
    //     0xc77ddc: stur            w1, [x0, #0x27]
    // 0xc77de0: ldur            x1, [fp, #-0x60]
    // 0xc77de4: StoreField: r0->field_23 = r1
    //     0xc77de4: stur            w1, [x0, #0x23]
    // 0xc77de8: ldur            x1, [fp, #-0x38]
    // 0xc77dec: StoreField: r0->field_2b = r1
    //     0xc77dec: stur            w1, [x0, #0x2b]
    // 0xc77df0: ldur            x1, [fp, #-0x10]
    // 0xc77df4: StoreField: r0->field_7 = r1
    //     0xc77df4: stur            x1, [x0, #7]
    // 0xc77df8: ldur            x16, [fp, #-0x30]
    // 0xc77dfc: stp             x0, x16, [SP, #-0x10]!
    // 0xc77e00: r0 = add()
    //     0xc77e00: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc77e04: add             SP, SP, #0x10
    // 0xc77e08: b               #0xc7830c
    // 0xc77e0c: ldur            x0, [fp, #-0x20]
    // 0xc77e10: ldur            x1, [fp, #-0x10]
    // 0xc77e14: r16 = "resolution_changed"
    //     0xc77e14: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d48] "resolution_changed"
    //     0xc77e18: ldr             x16, [x16, #0xd48]
    // 0xc77e1c: ldur            lr, [fp, #-0x28]
    // 0xc77e20: stp             lr, x16, [SP, #-0x10]!
    // 0xc77e24: r0 = ==()
    //     0xc77e24: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc77e28: add             SP, SP, #0x10
    // 0xc77e2c: tbnz            w0, #4, #0xc77f78
    // 0xc77e30: ldur            x0, [fp, #-0x20]
    // 0xc77e34: ldur            x1, [fp, #-0x10]
    // 0xc77e38: ldur            x16, [fp, #-0x18]
    // 0xc77e3c: stp             x16, x0, [SP, #-0x10]!
    // 0xc77e40: r0 = _getArgumentDictionary()
    //     0xc77e40: bl              #0x5abda0  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_getArgumentDictionary
    // 0xc77e44: add             SP, SP, #0x10
    // 0xc77e48: mov             x1, x0
    // 0xc77e4c: ldur            x0, [fp, #-0x20]
    // 0xc77e50: stur            x1, [fp, #-0x38]
    // 0xc77e54: LoadField: r2 = r0->field_b
    //     0xc77e54: ldur            w2, [x0, #0xb]
    // 0xc77e58: DecompressPointer r2
    //     0xc77e58: add             x2, x2, HEAP, lsl #32
    // 0xc77e5c: stur            x2, [fp, #-0x30]
    // 0xc77e60: r0 = LoadClassIdInstr(r1)
    //     0xc77e60: ldur            x0, [x1, #-1]
    //     0xc77e64: ubfx            x0, x0, #0xc, #0x14
    // 0xc77e68: r16 = "captureWidth"
    //     0xc77e68: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d50] "captureWidth"
    //     0xc77e6c: ldr             x16, [x16, #0xd50]
    // 0xc77e70: stp             x16, x1, [SP, #-0x10]!
    // 0xc77e74: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77e74: sub             lr, x0, #0xef
    //     0xc77e78: ldr             lr, [x21, lr, lsl #3]
    //     0xc77e7c: blr             lr
    // 0xc77e80: add             SP, SP, #0x10
    // 0xc77e84: mov             x3, x0
    // 0xc77e88: stur            x3, [fp, #-0x40]
    // 0xc77e8c: cmp             w3, NULL
    // 0xc77e90: b.eq            #0xc78340
    // 0xc77e94: mov             x0, x3
    // 0xc77e98: r2 = Null
    //     0xc77e98: mov             x2, NULL
    // 0xc77e9c: r1 = Null
    //     0xc77e9c: mov             x1, NULL
    // 0xc77ea0: r4 = 59
    //     0xc77ea0: mov             x4, #0x3b
    // 0xc77ea4: branchIfSmi(r0, 0xc77eb0)
    //     0xc77ea4: tbz             w0, #0, #0xc77eb0
    // 0xc77ea8: r4 = LoadClassIdInstr(r0)
    //     0xc77ea8: ldur            x4, [x0, #-1]
    //     0xc77eac: ubfx            x4, x4, #0xc, #0x14
    // 0xc77eb0: cmp             x4, #0x3d
    // 0xc77eb4: b.eq            #0xc77ec8
    // 0xc77eb8: r8 = double
    //     0xc77eb8: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc77ebc: r3 = Null
    //     0xc77ebc: add             x3, PP, #0x54, lsl #12  ; [pp+0x54030] Null
    //     0xc77ec0: ldr             x3, [x3, #0x30]
    // 0xc77ec4: r0 = double()
    //     0xc77ec4: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc77ec8: ldur            x0, [fp, #-0x38]
    // 0xc77ecc: r1 = LoadClassIdInstr(r0)
    //     0xc77ecc: ldur            x1, [x0, #-1]
    //     0xc77ed0: ubfx            x1, x1, #0xc, #0x14
    // 0xc77ed4: r16 = "captureHeight"
    //     0xc77ed4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d68] "captureHeight"
    //     0xc77ed8: ldr             x16, [x16, #0xd68]
    // 0xc77edc: stp             x16, x0, [SP, #-0x10]!
    // 0xc77ee0: mov             x0, x1
    // 0xc77ee4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc77ee4: sub             lr, x0, #0xef
    //     0xc77ee8: ldr             lr, [x21, lr, lsl #3]
    //     0xc77eec: blr             lr
    // 0xc77ef0: add             SP, SP, #0x10
    // 0xc77ef4: mov             x3, x0
    // 0xc77ef8: stur            x3, [fp, #-0x38]
    // 0xc77efc: cmp             w3, NULL
    // 0xc77f00: b.eq            #0xc78344
    // 0xc77f04: mov             x0, x3
    // 0xc77f08: r2 = Null
    //     0xc77f08: mov             x2, NULL
    // 0xc77f0c: r1 = Null
    //     0xc77f0c: mov             x1, NULL
    // 0xc77f10: r4 = 59
    //     0xc77f10: mov             x4, #0x3b
    // 0xc77f14: branchIfSmi(r0, 0xc77f20)
    //     0xc77f14: tbz             w0, #0, #0xc77f20
    // 0xc77f18: r4 = LoadClassIdInstr(r0)
    //     0xc77f18: ldur            x4, [x0, #-1]
    //     0xc77f1c: ubfx            x4, x4, #0xc, #0x14
    // 0xc77f20: cmp             x4, #0x3d
    // 0xc77f24: b.eq            #0xc77f38
    // 0xc77f28: r8 = double
    //     0xc77f28: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc77f2c: r3 = Null
    //     0xc77f2c: add             x3, PP, #0x54, lsl #12  ; [pp+0x54040] Null
    //     0xc77f30: ldr             x3, [x3, #0x40]
    // 0xc77f34: r0 = double()
    //     0xc77f34: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc77f38: ldur            x0, [fp, #-0x40]
    // 0xc77f3c: LoadField: d0 = r0->field_7
    //     0xc77f3c: ldur            d0, [x0, #7]
    // 0xc77f40: stur            d0, [fp, #-0x70]
    // 0xc77f44: r0 = CameraResolutionChangedEvent()
    //     0xc77f44: bl              #0xc77548  ; AllocateCameraResolutionChangedEventStub -> CameraResolutionChangedEvent (size=0x20)
    // 0xc77f48: ldur            d0, [fp, #-0x70]
    // 0xc77f4c: StoreField: r0->field_f = d0
    //     0xc77f4c: stur            d0, [x0, #0xf]
    // 0xc77f50: ldur            x1, [fp, #-0x38]
    // 0xc77f54: LoadField: d0 = r1->field_7
    //     0xc77f54: ldur            d0, [x1, #7]
    // 0xc77f58: StoreField: r0->field_17 = d0
    //     0xc77f58: stur            d0, [x0, #0x17]
    // 0xc77f5c: ldur            x1, [fp, #-0x10]
    // 0xc77f60: StoreField: r0->field_7 = r1
    //     0xc77f60: stur            x1, [x0, #7]
    // 0xc77f64: ldur            x16, [fp, #-0x30]
    // 0xc77f68: stp             x0, x16, [SP, #-0x10]!
    // 0xc77f6c: r0 = add()
    //     0xc77f6c: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc77f70: add             SP, SP, #0x10
    // 0xc77f74: b               #0xc7830c
    // 0xc77f78: ldur            x0, [fp, #-0x20]
    // 0xc77f7c: ldur            x1, [fp, #-0x10]
    // 0xc77f80: r16 = "camera_closing"
    //     0xc77f80: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d80] "camera_closing"
    //     0xc77f84: ldr             x16, [x16, #0xd80]
    // 0xc77f88: ldur            lr, [fp, #-0x28]
    // 0xc77f8c: stp             lr, x16, [SP, #-0x10]!
    // 0xc77f90: r0 = ==()
    //     0xc77f90: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc77f94: add             SP, SP, #0x10
    // 0xc77f98: tbnz            w0, #4, #0xc77fd0
    // 0xc77f9c: ldur            x0, [fp, #-0x20]
    // 0xc77fa0: ldur            x1, [fp, #-0x10]
    // 0xc77fa4: LoadField: r2 = r0->field_b
    //     0xc77fa4: ldur            w2, [x0, #0xb]
    // 0xc77fa8: DecompressPointer r2
    //     0xc77fa8: add             x2, x2, HEAP, lsl #32
    // 0xc77fac: stur            x2, [fp, #-0x30]
    // 0xc77fb0: r0 = CameraClosingEvent()
    //     0xc77fb0: bl              #0xc7753c  ; AllocateCameraClosingEventStub -> CameraClosingEvent (size=0x10)
    // 0xc77fb4: ldur            x1, [fp, #-0x10]
    // 0xc77fb8: StoreField: r0->field_7 = r1
    //     0xc77fb8: stur            x1, [x0, #7]
    // 0xc77fbc: ldur            x16, [fp, #-0x30]
    // 0xc77fc0: stp             x0, x16, [SP, #-0x10]!
    // 0xc77fc4: r0 = add()
    //     0xc77fc4: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc77fc8: add             SP, SP, #0x10
    // 0xc77fcc: b               #0xc7830c
    // 0xc77fd0: ldur            x0, [fp, #-0x20]
    // 0xc77fd4: ldur            x1, [fp, #-0x10]
    // 0xc77fd8: r16 = "video_recorded"
    //     0xc77fd8: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d88] "video_recorded"
    //     0xc77fdc: ldr             x16, [x16, #0xd88]
    // 0xc77fe0: ldur            lr, [fp, #-0x28]
    // 0xc77fe4: stp             lr, x16, [SP, #-0x10]!
    // 0xc77fe8: r0 = ==()
    //     0xc77fe8: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc77fec: add             SP, SP, #0x10
    // 0xc77ff0: tbnz            w0, #4, #0xc7822c
    // 0xc77ff4: ldur            x0, [fp, #-0x20]
    // 0xc77ff8: ldur            x16, [fp, #-0x18]
    // 0xc77ffc: stp             x16, x0, [SP, #-0x10]!
    // 0xc78000: r0 = _getArgumentDictionary()
    //     0xc78000: bl              #0x5abda0  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_getArgumentDictionary
    // 0xc78004: add             SP, SP, #0x10
    // 0xc78008: mov             x1, x0
    // 0xc7800c: ldur            x0, [fp, #-0x20]
    // 0xc78010: stur            x1, [fp, #-0x38]
    // 0xc78014: LoadField: r2 = r0->field_b
    //     0xc78014: ldur            w2, [x0, #0xb]
    // 0xc78018: DecompressPointer r2
    //     0xc78018: add             x2, x2, HEAP, lsl #32
    // 0xc7801c: stur            x2, [fp, #-0x30]
    // 0xc78020: r0 = LoadClassIdInstr(r1)
    //     0xc78020: ldur            x0, [x1, #-1]
    //     0xc78024: ubfx            x0, x0, #0xc, #0x14
    // 0xc78028: r16 = "path"
    //     0xc78028: ldr             x16, [PP, #0x518]  ; [pp+0x518] "path"
    // 0xc7802c: stp             x16, x1, [SP, #-0x10]!
    // 0xc78030: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78030: sub             lr, x0, #0xef
    //     0xc78034: ldr             lr, [x21, lr, lsl #3]
    //     0xc78038: blr             lr
    // 0xc7803c: add             SP, SP, #0x10
    // 0xc78040: mov             x3, x0
    // 0xc78044: stur            x3, [fp, #-0x40]
    // 0xc78048: cmp             w3, NULL
    // 0xc7804c: b.eq            #0xc78348
    // 0xc78050: mov             x0, x3
    // 0xc78054: r2 = Null
    //     0xc78054: mov             x2, NULL
    // 0xc78058: r1 = Null
    //     0xc78058: mov             x1, NULL
    // 0xc7805c: r4 = 59
    //     0xc7805c: mov             x4, #0x3b
    // 0xc78060: branchIfSmi(r0, 0xc7806c)
    //     0xc78060: tbz             w0, #0, #0xc7806c
    // 0xc78064: r4 = LoadClassIdInstr(r0)
    //     0xc78064: ldur            x4, [x0, #-1]
    //     0xc78068: ubfx            x4, x4, #0xc, #0x14
    // 0xc7806c: sub             x4, x4, #0x5d
    // 0xc78070: cmp             x4, #3
    // 0xc78074: b.ls            #0xc78088
    // 0xc78078: r8 = String
    //     0xc78078: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc7807c: r3 = Null
    //     0xc7807c: add             x3, PP, #0x54, lsl #12  ; [pp+0x54050] Null
    //     0xc78080: ldr             x3, [x3, #0x50]
    // 0xc78084: r0 = String()
    //     0xc78084: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc78088: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc78088: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc7808c: ldr             x0, [x0, #0xb58]
    //     0xc78090: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc78094: cmp             w0, w16
    //     0xc78098: b.ne            #0xc780a4
    //     0xc7809c: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc780a0: bl              #0xd67d44
    // 0xc780a4: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc780a4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc780a8: ldr             x0, [x0, #0xdd8]
    //     0xc780ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc780b0: cmp             w0, w16
    //     0xc780b4: b.ne            #0xc780c0
    //     0xc780b8: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc780bc: bl              #0xd67cdc
    // 0xc780c0: r0 = _File()
    //     0xc780c0: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xc780c4: mov             x1, x0
    // 0xc780c8: ldur            x0, [fp, #-0x40]
    // 0xc780cc: stur            x1, [fp, #-0x48]
    // 0xc780d0: StoreField: r1->field_7 = r0
    //     0xc780d0: stur            w0, [x1, #7]
    // 0xc780d4: SaveReg r0
    //     0xc780d4: str             x0, [SP, #-8]!
    // 0xc780d8: r0 = _toUtf8Array()
    //     0xc780d8: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc780dc: add             SP, SP, #8
    // 0xc780e0: ldur            x1, [fp, #-0x48]
    // 0xc780e4: StoreField: r1->field_b = r0
    //     0xc780e4: stur            w0, [x1, #0xb]
    //     0xc780e8: ldurb           w16, [x1, #-1]
    //     0xc780ec: ldurb           w17, [x0, #-1]
    //     0xc780f0: and             x16, x17, x16, lsr #2
    //     0xc780f4: tst             x16, HEAP, lsr #32
    //     0xc780f8: b.eq            #0xc78100
    //     0xc780fc: bl              #0xd6826c
    // 0xc78100: r0 = XFile()
    //     0xc78100: bl              #0xc6a500  ; AllocateXFileStub -> XFile (size=0x10)
    // 0xc78104: mov             x1, x0
    // 0xc78108: ldur            x0, [fp, #-0x48]
    // 0xc7810c: stur            x1, [fp, #-0x40]
    // 0xc78110: StoreField: r1->field_7 = r0
    //     0xc78110: stur            w0, [x1, #7]
    // 0xc78114: ldur            x2, [fp, #-0x38]
    // 0xc78118: r0 = LoadClassIdInstr(r2)
    //     0xc78118: ldur            x0, [x2, #-1]
    //     0xc7811c: ubfx            x0, x0, #0xc, #0x14
    // 0xc78120: r16 = "maxVideoDuration"
    //     0xc78120: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b10] "maxVideoDuration"
    //     0xc78124: ldr             x16, [x16, #0xb10]
    // 0xc78128: stp             x16, x2, [SP, #-0x10]!
    // 0xc7812c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7812c: sub             lr, x0, #0xef
    //     0xc78130: ldr             lr, [x21, lr, lsl #3]
    //     0xc78134: blr             lr
    // 0xc78138: add             SP, SP, #0x10
    // 0xc7813c: cmp             w0, NULL
    // 0xc78140: b.eq            #0xc781e8
    // 0xc78144: ldur            x0, [fp, #-0x38]
    // 0xc78148: r1 = LoadClassIdInstr(r0)
    //     0xc78148: ldur            x1, [x0, #-1]
    //     0xc7814c: ubfx            x1, x1, #0xc, #0x14
    // 0xc78150: r16 = "maxVideoDuration"
    //     0xc78150: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b10] "maxVideoDuration"
    //     0xc78154: ldr             x16, [x16, #0xb10]
    // 0xc78158: stp             x16, x0, [SP, #-0x10]!
    // 0xc7815c: mov             x0, x1
    // 0xc78160: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78160: sub             lr, x0, #0xef
    //     0xc78164: ldr             lr, [x21, lr, lsl #3]
    //     0xc78168: blr             lr
    // 0xc7816c: add             SP, SP, #0x10
    // 0xc78170: mov             x3, x0
    // 0xc78174: stur            x3, [fp, #-0x38]
    // 0xc78178: cmp             w3, NULL
    // 0xc7817c: b.eq            #0xc7834c
    // 0xc78180: r3 as int
    //     0xc78180: mov             x0, x3
    //     0xc78184: mov             x2, NULL
    //     0xc78188: mov             x1, NULL
    //     0xc7818c: tbz             w0, #0, #0xc781b4
    //     0xc78190: ldur            x4, [x0, #-1]
    //     0xc78194: ubfx            x4, x4, #0xc, #0x14
    //     0xc78198: sub             x4, x4, #0x3b
    //     0xc7819c: cmp             x4, #1
    //     0xc781a0: b.ls            #0xc781b4
    //     0xc781a4: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xc781a8: add             x3, PP, #0x54, lsl #12  ; [pp+0x54060] Null
    //     0xc781ac: ldr             x3, [x3, #0x60]
    //     0xc781b0: bl              #0xd73714
    // 0xc781b4: ldur            x0, [fp, #-0x38]
    // 0xc781b8: r1 = LoadInt32Instr(r0)
    //     0xc781b8: sbfx            x1, x0, #1, #0x1f
    //     0xc781bc: tbz             w0, #0, #0xc781c4
    //     0xc781c0: ldur            x1, [x0, #7]
    // 0xc781c4: r16 = 1000
    //     0xc781c4: mov             x16, #0x3e8
    // 0xc781c8: mul             x0, x1, x16
    // 0xc781cc: stur            x0, [fp, #-0x68]
    // 0xc781d0: r0 = Duration()
    //     0xc781d0: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xc781d4: mov             x1, x0
    // 0xc781d8: ldur            x0, [fp, #-0x68]
    // 0xc781dc: StoreField: r1->field_7 = r0
    //     0xc781dc: stur            x0, [x1, #7]
    // 0xc781e0: mov             x2, x1
    // 0xc781e4: b               #0xc781ec
    // 0xc781e8: r2 = Null
    //     0xc781e8: mov             x2, NULL
    // 0xc781ec: ldur            x1, [fp, #-0x10]
    // 0xc781f0: ldur            x0, [fp, #-0x40]
    // 0xc781f4: stur            x2, [fp, #-0x38]
    // 0xc781f8: r0 = VideoRecordedEvent()
    //     0xc781f8: bl              #0xc77530  ; AllocateVideoRecordedEventStub -> VideoRecordedEvent (size=0x18)
    // 0xc781fc: mov             x1, x0
    // 0xc78200: ldur            x0, [fp, #-0x40]
    // 0xc78204: StoreField: r1->field_f = r0
    //     0xc78204: stur            w0, [x1, #0xf]
    // 0xc78208: ldur            x0, [fp, #-0x38]
    // 0xc7820c: StoreField: r1->field_13 = r0
    //     0xc7820c: stur            w0, [x1, #0x13]
    // 0xc78210: ldur            x2, [fp, #-0x10]
    // 0xc78214: StoreField: r1->field_7 = r2
    //     0xc78214: stur            x2, [x1, #7]
    // 0xc78218: ldur            x16, [fp, #-0x30]
    // 0xc7821c: stp             x1, x16, [SP, #-0x10]!
    // 0xc78220: r0 = add()
    //     0xc78220: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc78224: add             SP, SP, #0x10
    // 0xc78228: b               #0xc7830c
    // 0xc7822c: ldur            x0, [fp, #-0x20]
    // 0xc78230: ldur            x2, [fp, #-0x10]
    // 0xc78234: r16 = "error"
    //     0xc78234: ldr             x16, [PP, #0xeb8]  ; [pp+0xeb8] "error"
    // 0xc78238: ldur            lr, [fp, #-0x28]
    // 0xc7823c: stp             lr, x16, [SP, #-0x10]!
    // 0xc78240: r0 = ==()
    //     0xc78240: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc78244: add             SP, SP, #0x10
    // 0xc78248: tbnz            w0, #4, #0xc78314
    // 0xc7824c: ldur            x0, [fp, #-0x20]
    // 0xc78250: ldur            x1, [fp, #-0x10]
    // 0xc78254: ldur            x16, [fp, #-0x18]
    // 0xc78258: stp             x16, x0, [SP, #-0x10]!
    // 0xc7825c: r0 = _getArgumentDictionary()
    //     0xc7825c: bl              #0x5abda0  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::_getArgumentDictionary
    // 0xc78260: add             SP, SP, #0x10
    // 0xc78264: mov             x1, x0
    // 0xc78268: ldur            x0, [fp, #-0x20]
    // 0xc7826c: LoadField: r2 = r0->field_b
    //     0xc7826c: ldur            w2, [x0, #0xb]
    // 0xc78270: DecompressPointer r2
    //     0xc78270: add             x2, x2, HEAP, lsl #32
    // 0xc78274: stur            x2, [fp, #-0x18]
    // 0xc78278: r0 = LoadClassIdInstr(r1)
    //     0xc78278: ldur            x0, [x1, #-1]
    //     0xc7827c: ubfx            x0, x0, #0xc, #0x14
    // 0xc78280: r16 = "description"
    //     0xc78280: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b70] "description"
    //     0xc78284: ldr             x16, [x16, #0xb70]
    // 0xc78288: stp             x16, x1, [SP, #-0x10]!
    // 0xc7828c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7828c: sub             lr, x0, #0xef
    //     0xc78290: ldr             lr, [x21, lr, lsl #3]
    //     0xc78294: blr             lr
    // 0xc78298: add             SP, SP, #0x10
    // 0xc7829c: mov             x3, x0
    // 0xc782a0: stur            x3, [fp, #-0x20]
    // 0xc782a4: cmp             w3, NULL
    // 0xc782a8: b.eq            #0xc78350
    // 0xc782ac: mov             x0, x3
    // 0xc782b0: r2 = Null
    //     0xc782b0: mov             x2, NULL
    // 0xc782b4: r1 = Null
    //     0xc782b4: mov             x1, NULL
    // 0xc782b8: r4 = 59
    //     0xc782b8: mov             x4, #0x3b
    // 0xc782bc: branchIfSmi(r0, 0xc782c8)
    //     0xc782bc: tbz             w0, #0, #0xc782c8
    // 0xc782c0: r4 = LoadClassIdInstr(r0)
    //     0xc782c0: ldur            x4, [x0, #-1]
    //     0xc782c4: ubfx            x4, x4, #0xc, #0x14
    // 0xc782c8: sub             x4, x4, #0x5d
    // 0xc782cc: cmp             x4, #3
    // 0xc782d0: b.ls            #0xc782e4
    // 0xc782d4: r8 = String
    //     0xc782d4: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc782d8: r3 = Null
    //     0xc782d8: add             x3, PP, #0x54, lsl #12  ; [pp+0x54070] Null
    //     0xc782dc: ldr             x3, [x3, #0x70]
    // 0xc782e0: r0 = String()
    //     0xc782e0: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc782e4: r0 = CameraErrorEvent()
    //     0xc782e4: bl              #0xc77524  ; AllocateCameraErrorEventStub -> CameraErrorEvent (size=0x14)
    // 0xc782e8: mov             x1, x0
    // 0xc782ec: ldur            x0, [fp, #-0x20]
    // 0xc782f0: StoreField: r1->field_f = r0
    //     0xc782f0: stur            w0, [x1, #0xf]
    // 0xc782f4: ldur            x0, [fp, #-0x10]
    // 0xc782f8: StoreField: r1->field_7 = r0
    //     0xc782f8: stur            x0, [x1, #7]
    // 0xc782fc: ldur            x16, [fp, #-0x18]
    // 0xc78300: stp             x1, x16, [SP, #-0x10]!
    // 0xc78304: r0 = add()
    //     0xc78304: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc78308: add             SP, SP, #0x10
    // 0xc7830c: r0 = Null
    //     0xc7830c: mov             x0, NULL
    // 0xc78310: r0 = ReturnAsyncNotFuture()
    //     0xc78310: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc78314: r0 = MissingPluginException()
    //     0xc78314: bl              #0x501aa4  ; AllocateMissingPluginExceptionStub -> MissingPluginException (size=0xc)
    // 0xc78318: r0 = Throw()
    //     0xc78318: bl              #0xd67e38  ; ThrowStub
    // 0xc7831c: brk             #0
    // 0xc78320: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc78320: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc78324: b               #0xc77a8c
    // 0xc78328: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78328: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7832c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7832c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78330: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78330: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78334: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78338: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78338: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7833c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7833c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78340: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78340: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78344: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78344: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78348: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78348: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7834c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7834c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78350: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78350: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ createCamera(/* No info */) async {
    // ** addr: 0xc7a138, size: 0x278
    // 0xc7a138: EnterFrame
    //     0xc7a138: stp             fp, lr, [SP, #-0x10]!
    //     0xc7a13c: mov             fp, SP
    // 0xc7a140: AllocStack(0x78)
    //     0xc7a140: sub             SP, SP, #0x78
    // 0xc7a144: SetupParameters(AVFoundationCamera this /* r1, fp-0x78 */, dynamic _ /* r2, fp-0x70 */, dynamic _ /* r3, fp-0x68 */, dynamic _ /* r4, fp-0x60 */)
    //     0xc7a144: stur            NULL, [fp, #-8]
    //     0xc7a148: mov             x0, #0
    //     0xc7a14c: add             x1, fp, w0, sxtw #2
    //     0xc7a150: ldr             x1, [x1, #0x28]
    //     0xc7a154: stur            x1, [fp, #-0x78]
    //     0xc7a158: add             x2, fp, w0, sxtw #2
    //     0xc7a15c: ldr             x2, [x2, #0x20]
    //     0xc7a160: stur            x2, [fp, #-0x70]
    //     0xc7a164: add             x3, fp, w0, sxtw #2
    //     0xc7a168: ldr             x3, [x3, #0x18]
    //     0xc7a16c: stur            x3, [fp, #-0x68]
    //     0xc7a170: add             x4, fp, w0, sxtw #2
    //     0xc7a174: ldr             x4, [x4, #0x10]
    //     0xc7a178: stur            x4, [fp, #-0x60]
    // 0xc7a17c: CheckStackOverflow
    //     0xc7a17c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7a180: cmp             SP, x16
    //     0xc7a184: b.ls            #0xc7a3a0
    // 0xc7a188: InitAsync() -> Future<int>
    //     0xc7a188: ldr             x0, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    //     0xc7a18c: bl              #0x4b92e4
    // 0xc7a190: ldur            x0, [fp, #-0x70]
    // 0xc7a194: ldur            x3, [fp, #-0x68]
    // 0xc7a198: r1 = Null
    //     0xc7a198: mov             x1, NULL
    // 0xc7a19c: r2 = 12
    //     0xc7a19c: mov             x2, #0xc
    // 0xc7a1a0: r0 = AllocateArray()
    //     0xc7a1a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc7a1a4: r17 = "cameraName"
    //     0xc7a1a4: add             x17, PP, #0x53, lsl #12  ; [pp+0x53dd8] "cameraName"
    //     0xc7a1a8: ldr             x17, [x17, #0xdd8]
    // 0xc7a1ac: StoreField: r0->field_f = r17
    //     0xc7a1ac: stur            w17, [x0, #0xf]
    // 0xc7a1b0: ldur            x1, [fp, #-0x70]
    // 0xc7a1b4: LoadField: r2 = r1->field_7
    //     0xc7a1b4: ldur            w2, [x1, #7]
    // 0xc7a1b8: DecompressPointer r2
    //     0xc7a1b8: add             x2, x2, HEAP, lsl #32
    // 0xc7a1bc: StoreField: r0->field_13 = r2
    //     0xc7a1bc: stur            w2, [x0, #0x13]
    // 0xc7a1c0: r17 = "resolutionPreset"
    //     0xc7a1c0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53de0] "resolutionPreset"
    //     0xc7a1c4: ldr             x17, [x17, #0xde0]
    // 0xc7a1c8: StoreField: r0->field_17 = r17
    //     0xc7a1c8: stur            w17, [x0, #0x17]
    // 0xc7a1cc: ldur            x1, [fp, #-0x68]
    // 0xc7a1d0: r2 = LoadClassIdInstr(r1)
    //     0xc7a1d0: ldur            x2, [x1, #-1]
    //     0xc7a1d4: ubfx            x2, x2, #0xc, #0x14
    // 0xc7a1d8: lsl             x2, x2, #1
    // 0xc7a1dc: r17 = 12036
    //     0xc7a1dc: mov             x17, #0x2f04
    // 0xc7a1e0: cmp             w2, w17
    // 0xc7a1e4: b.ne            #0xc7a25c
    // 0xc7a1e8: LoadField: r2 = r1->field_7
    //     0xc7a1e8: ldur            x2, [x1, #7]
    // 0xc7a1ec: cmp             x2, #2
    // 0xc7a1f0: b.gt            #0xc7a228
    // 0xc7a1f4: cmp             x2, #1
    // 0xc7a1f8: b.gt            #0xc7a21c
    // 0xc7a1fc: cmp             x2, #0
    // 0xc7a200: b.gt            #0xc7a210
    // 0xc7a204: r2 = "low"
    //     0xc7a204: add             x2, PP, #0x53, lsl #12  ; [pp+0x53de8] "low"
    //     0xc7a208: ldr             x2, [x2, #0xde8]
    // 0xc7a20c: b               #0xc7a264
    // 0xc7a210: r2 = "medium"
    //     0xc7a210: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c7e0] "medium"
    //     0xc7a214: ldr             x2, [x2, #0x7e0]
    // 0xc7a218: b               #0xc7a264
    // 0xc7a21c: r2 = "high"
    //     0xc7a21c: add             x2, PP, #0x53, lsl #12  ; [pp+0x53df0] "high"
    //     0xc7a220: ldr             x2, [x2, #0xdf0]
    // 0xc7a224: b               #0xc7a264
    // 0xc7a228: cmp             x2, #4
    // 0xc7a22c: b.gt            #0xc7a250
    // 0xc7a230: cmp             x2, #3
    // 0xc7a234: b.gt            #0xc7a244
    // 0xc7a238: r2 = "veryHigh"
    //     0xc7a238: add             x2, PP, #0x53, lsl #12  ; [pp+0x53df8] "veryHigh"
    //     0xc7a23c: ldr             x2, [x2, #0xdf8]
    // 0xc7a240: b               #0xc7a264
    // 0xc7a244: r2 = "ultraHigh"
    //     0xc7a244: add             x2, PP, #0x53, lsl #12  ; [pp+0x53e00] "ultraHigh"
    //     0xc7a248: ldr             x2, [x2, #0xe00]
    // 0xc7a24c: b               #0xc7a264
    // 0xc7a250: r2 = "max"
    //     0xc7a250: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] "max"
    //     0xc7a254: ldr             x2, [x2, #0x8e0]
    // 0xc7a258: b               #0xc7a264
    // 0xc7a25c: r2 = "max"
    //     0xc7a25c: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] "max"
    //     0xc7a260: ldr             x2, [x2, #0x8e0]
    // 0xc7a264: ldur            x1, [fp, #-0x60]
    // 0xc7a268: StoreField: r0->field_1b = r2
    //     0xc7a268: stur            w2, [x0, #0x1b]
    // 0xc7a26c: r17 = "enableAudio"
    //     0xc7a26c: add             x17, PP, #0x53, lsl #12  ; [pp+0x53e08] "enableAudio"
    //     0xc7a270: ldr             x17, [x17, #0xe08]
    // 0xc7a274: StoreField: r0->field_1f = r17
    //     0xc7a274: stur            w17, [x0, #0x1f]
    // 0xc7a278: StoreField: r0->field_23 = r1
    //     0xc7a278: stur            w1, [x0, #0x23]
    // 0xc7a27c: r16 = <String, dynamic>
    //     0xc7a27c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc7a280: stp             x0, x16, [SP, #-0x10]!
    // 0xc7a284: r0 = Map._fromLiteral()
    //     0xc7a284: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc7a288: add             SP, SP, #0x10
    // 0xc7a28c: r16 = <String, dynamic>
    //     0xc7a28c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc7a290: r30 = Instance_MethodChannel
    //     0xc7a290: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc7a294: ldr             lr, [lr, #0x370]
    // 0xc7a298: stp             lr, x16, [SP, #-0x10]!
    // 0xc7a29c: r16 = "create"
    //     0xc7a29c: add             x16, PP, #0x36, lsl #12  ; [pp+0x36fe8] "create"
    //     0xc7a2a0: ldr             x16, [x16, #0xfe8]
    // 0xc7a2a4: stp             x0, x16, [SP, #-0x10]!
    // 0xc7a2a8: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0xc7a2a8: ldr             x4, [PP, #0x8c0]  ; [pp+0x8c0] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0xc7a2ac: r0 = invokeMapMethod()
    //     0xc7a2ac: bl              #0x5a21c4  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0xc7a2b0: add             SP, SP, #0x20
    // 0xc7a2b4: mov             x1, x0
    // 0xc7a2b8: stur            x1, [fp, #-0x60]
    // 0xc7a2bc: r0 = Await()
    //     0xc7a2bc: bl              #0x4b8e6c  ; AwaitStub
    // 0xc7a2c0: cmp             w0, NULL
    // 0xc7a2c4: b.eq            #0xc7a3a8
    // 0xc7a2c8: r1 = LoadClassIdInstr(r0)
    //     0xc7a2c8: ldur            x1, [x0, #-1]
    //     0xc7a2cc: ubfx            x1, x1, #0xc, #0x14
    // 0xc7a2d0: r16 = "cameraId"
    //     0xc7a2d0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc7a2d4: ldr             x16, [x16, #0x890]
    // 0xc7a2d8: stp             x16, x0, [SP, #-0x10]!
    // 0xc7a2dc: mov             x0, x1
    // 0xc7a2e0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7a2e0: sub             lr, x0, #0xef
    //     0xc7a2e4: ldr             lr, [x21, lr, lsl #3]
    //     0xc7a2e8: blr             lr
    // 0xc7a2ec: add             SP, SP, #0x10
    // 0xc7a2f0: mov             x3, x0
    // 0xc7a2f4: stur            x3, [fp, #-0x60]
    // 0xc7a2f8: cmp             w3, NULL
    // 0xc7a2fc: b.eq            #0xc7a3ac
    // 0xc7a300: r3 as int
    //     0xc7a300: mov             x0, x3
    //     0xc7a304: mov             x2, NULL
    //     0xc7a308: mov             x1, NULL
    //     0xc7a30c: tbz             w0, #0, #0xc7a334
    //     0xc7a310: ldur            x4, [x0, #-1]
    //     0xc7a314: ubfx            x4, x4, #0xc, #0x14
    //     0xc7a318: sub             x4, x4, #0x3b
    //     0xc7a31c: cmp             x4, #1
    //     0xc7a320: b.ls            #0xc7a334
    //     0xc7a324: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xc7a328: add             x3, PP, #0x54, lsl #12  ; [pp+0x54080] Null
    //     0xc7a32c: ldr             x3, [x3, #0x80]
    //     0xc7a330: bl              #0xd73714
    // 0xc7a334: ldur            x0, [fp, #-0x60]
    // 0xc7a338: r0 = ReturnAsyncNotFuture()
    //     0xc7a338: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc7a33c: sub             SP, fp, #0x78
    // 0xc7a340: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc7a340: mov             x2, #0x76
    //     0xc7a344: tbz             w0, #0, #0xc7a354
    //     0xc7a348: ldur            x2, [x0, #-1]
    //     0xc7a34c: ubfx            x2, x2, #0xc, #0x14
    //     0xc7a350: lsl             x2, x2, #1
    // 0xc7a354: cmp             w2, #0xf28
    // 0xc7a358: b.ne            #0xc7a398
    // 0xc7a35c: LoadField: r1 = r0->field_7
    //     0xc7a35c: ldur            w1, [x0, #7]
    // 0xc7a360: DecompressPointer r1
    //     0xc7a360: add             x1, x1, HEAP, lsl #32
    // 0xc7a364: stur            x1, [fp, #-0x68]
    // 0xc7a368: LoadField: r2 = r0->field_b
    //     0xc7a368: ldur            w2, [x0, #0xb]
    // 0xc7a36c: DecompressPointer r2
    //     0xc7a36c: add             x2, x2, HEAP, lsl #32
    // 0xc7a370: stur            x2, [fp, #-0x60]
    // 0xc7a374: r0 = CameraException()
    //     0xc7a374: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc7a378: mov             x1, x0
    // 0xc7a37c: ldur            x0, [fp, #-0x68]
    // 0xc7a380: StoreField: r1->field_7 = r0
    //     0xc7a380: stur            w0, [x1, #7]
    // 0xc7a384: ldur            x0, [fp, #-0x60]
    // 0xc7a388: StoreField: r1->field_b = r0
    //     0xc7a388: stur            w0, [x1, #0xb]
    // 0xc7a38c: mov             x0, x1
    // 0xc7a390: r0 = Throw()
    //     0xc7a390: bl              #0xd67e38  ; ThrowStub
    // 0xc7a394: brk             #0
    // 0xc7a398: r0 = ReThrow()
    //     0xc7a398: bl              #0xd67e14  ; ReThrowStub
    // 0xc7a39c: brk             #0
    // 0xc7a3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7a3a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7a3a4: b               #0xc7a188
    // 0xc7a3a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7a3a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7a3ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7a3ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ availableCameras(/* No info */) async {
    // ** addr: 0xc7b6dc, size: 0x178
    // 0xc7b6dc: EnterFrame
    //     0xc7b6dc: stp             fp, lr, [SP, #-0x10]!
    //     0xc7b6e0: mov             fp, SP
    // 0xc7b6e4: AllocStack(0x50)
    //     0xc7b6e4: sub             SP, SP, #0x50
    // 0xc7b6e8: SetupParameters(AVFoundationCamera this /* r1, fp-0x48 */)
    //     0xc7b6e8: stur            NULL, [fp, #-8]
    //     0xc7b6ec: mov             x0, #0
    //     0xc7b6f0: add             x1, fp, w0, sxtw #2
    //     0xc7b6f4: ldr             x1, [x1, #0x10]
    //     0xc7b6f8: stur            x1, [fp, #-0x48]
    // 0xc7b6fc: CheckStackOverflow
    //     0xc7b6fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7b700: cmp             SP, x16
    //     0xc7b704: b.ls            #0xc7b84c
    // 0xc7b708: InitAsync() -> Future<List<CameraDescription>>
    //     0xc7b708: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d590] TypeArguments: <List<CameraDescription>>
    //     0xc7b70c: ldr             x0, [x0, #0x590]
    //     0xc7b710: bl              #0x4b92e4
    // 0xc7b714: r16 = <Map>
    //     0xc7b714: add             x16, PP, #0x14, lsl #12  ; [pp+0x14cb0] TypeArguments: <Map>
    //     0xc7b718: ldr             x16, [x16, #0xcb0]
    // 0xc7b71c: r30 = Instance_MethodChannel
    //     0xc7b71c: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d370] Obj!MethodChannel@b34b91
    //     0xc7b720: ldr             lr, [lr, #0x370]
    // 0xc7b724: stp             lr, x16, [SP, #-0x10]!
    // 0xc7b728: r16 = "availableCameras"
    //     0xc7b728: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e20] "availableCameras"
    //     0xc7b72c: ldr             x16, [x16, #0xe20]
    // 0xc7b730: SaveReg r16
    //     0xc7b730: str             x16, [SP, #-8]!
    // 0xc7b734: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc7b734: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc7b738: r0 = invokeListMethod()
    //     0xc7b738: bl              #0x799418  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeListMethod
    // 0xc7b73c: add             SP, SP, #0x18
    // 0xc7b740: mov             x1, x0
    // 0xc7b744: stur            x1, [fp, #-0x48]
    // 0xc7b748: r0 = Await()
    //     0xc7b748: bl              #0x4b8e6c  ; AwaitStub
    // 0xc7b74c: stur            x0, [fp, #-0x48]
    // 0xc7b750: cmp             w0, NULL
    // 0xc7b754: b.ne            #0xc7b770
    // 0xc7b758: r16 = <CameraDescription>
    //     0xc7b758: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e28] TypeArguments: <CameraDescription>
    //     0xc7b75c: ldr             x16, [x16, #0xe28]
    // 0xc7b760: stp             xzr, x16, [SP, #-0x10]!
    // 0xc7b764: r0 = _GrowableList()
    //     0xc7b764: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xc7b768: add             SP, SP, #0x10
    // 0xc7b76c: r0 = ReturnAsyncNotFuture()
    //     0xc7b76c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc7b770: r1 = Function '<anonymous closure>':.
    //     0xc7b770: add             x1, PP, #0x54, lsl #12  ; [pp+0x54090] AnonymousClosure: (0xc7b854), in [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::availableCameras (0xc7b6dc)
    //     0xc7b774: ldr             x1, [x1, #0x90]
    // 0xc7b778: r2 = Null
    //     0xc7b778: mov             x2, NULL
    // 0xc7b77c: r0 = AllocateClosure()
    //     0xc7b77c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc7b780: mov             x1, x0
    // 0xc7b784: ldur            x0, [fp, #-0x48]
    // 0xc7b788: r2 = LoadClassIdInstr(r0)
    //     0xc7b788: ldur            x2, [x0, #-1]
    //     0xc7b78c: ubfx            x2, x2, #0xc, #0x14
    // 0xc7b790: r16 = <CameraDescription>
    //     0xc7b790: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e28] TypeArguments: <CameraDescription>
    //     0xc7b794: ldr             x16, [x16, #0xe28]
    // 0xc7b798: stp             x0, x16, [SP, #-0x10]!
    // 0xc7b79c: SaveReg r1
    //     0xc7b79c: str             x1, [SP, #-8]!
    // 0xc7b7a0: mov             x0, x2
    // 0xc7b7a4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc7b7a4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc7b7a8: r0 = GDT[cid_x0 + 0xc934]()
    //     0xc7b7a8: mov             x17, #0xc934
    //     0xc7b7ac: add             lr, x0, x17
    //     0xc7b7b0: ldr             lr, [x21, lr, lsl #3]
    //     0xc7b7b4: blr             lr
    // 0xc7b7b8: add             SP, SP, #0x18
    // 0xc7b7bc: r1 = LoadClassIdInstr(r0)
    //     0xc7b7bc: ldur            x1, [x0, #-1]
    //     0xc7b7c0: ubfx            x1, x1, #0xc, #0x14
    // 0xc7b7c4: SaveReg r0
    //     0xc7b7c4: str             x0, [SP, #-8]!
    // 0xc7b7c8: mov             x0, x1
    // 0xc7b7cc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc7b7cc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc7b7d0: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0xc7b7d0: mov             x17, #0xc8a1
    //     0xc7b7d4: add             lr, x0, x17
    //     0xc7b7d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc7b7dc: blr             lr
    // 0xc7b7e0: add             SP, SP, #8
    // 0xc7b7e4: r0 = ReturnAsync()
    //     0xc7b7e4: b               #0x501858  ; ReturnAsyncStub
    // 0xc7b7e8: sub             SP, fp, #0x50
    // 0xc7b7ec: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc7b7ec: mov             x2, #0x76
    //     0xc7b7f0: tbz             w0, #0, #0xc7b800
    //     0xc7b7f4: ldur            x2, [x0, #-1]
    //     0xc7b7f8: ubfx            x2, x2, #0xc, #0x14
    //     0xc7b7fc: lsl             x2, x2, #1
    // 0xc7b800: cmp             w2, #0xf28
    // 0xc7b804: b.ne            #0xc7b844
    // 0xc7b808: LoadField: r1 = r0->field_7
    //     0xc7b808: ldur            w1, [x0, #7]
    // 0xc7b80c: DecompressPointer r1
    //     0xc7b80c: add             x1, x1, HEAP, lsl #32
    // 0xc7b810: stur            x1, [fp, #-0x50]
    // 0xc7b814: LoadField: r2 = r0->field_b
    //     0xc7b814: ldur            w2, [x0, #0xb]
    // 0xc7b818: DecompressPointer r2
    //     0xc7b818: add             x2, x2, HEAP, lsl #32
    // 0xc7b81c: stur            x2, [fp, #-0x48]
    // 0xc7b820: r0 = CameraException()
    //     0xc7b820: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc7b824: mov             x1, x0
    // 0xc7b828: ldur            x0, [fp, #-0x50]
    // 0xc7b82c: StoreField: r1->field_7 = r0
    //     0xc7b82c: stur            w0, [x1, #7]
    // 0xc7b830: ldur            x0, [fp, #-0x48]
    // 0xc7b834: StoreField: r1->field_b = r0
    //     0xc7b834: stur            w0, [x1, #0xb]
    // 0xc7b838: mov             x0, x1
    // 0xc7b83c: r0 = Throw()
    //     0xc7b83c: bl              #0xd67e38  ; ThrowStub
    // 0xc7b840: brk             #0
    // 0xc7b844: r0 = ReThrow()
    //     0xc7b844: bl              #0xd67e14  ; ReThrowStub
    // 0xc7b848: brk             #0
    // 0xc7b84c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7b84c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7b850: b               #0xc7b708
  }
  [closure] CameraDescription <anonymous closure>(dynamic, Map<dynamic, dynamic>) {
    // ** addr: 0xc7b854, size: 0x1c4
    // 0xc7b854: EnterFrame
    //     0xc7b854: stp             fp, lr, [SP, #-0x10]!
    //     0xc7b858: mov             fp, SP
    // 0xc7b85c: AllocStack(0x18)
    //     0xc7b85c: sub             SP, SP, #0x18
    // 0xc7b860: CheckStackOverflow
    //     0xc7b860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7b864: cmp             SP, x16
    //     0xc7b868: b.ls            #0xc7ba04
    // 0xc7b86c: ldr             x1, [fp, #0x10]
    // 0xc7b870: r0 = LoadClassIdInstr(r1)
    //     0xc7b870: ldur            x0, [x1, #-1]
    //     0xc7b874: ubfx            x0, x0, #0xc, #0x14
    // 0xc7b878: r16 = "name"
    //     0xc7b878: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xc7b87c: stp             x16, x1, [SP, #-0x10]!
    // 0xc7b880: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7b880: sub             lr, x0, #0xef
    //     0xc7b884: ldr             lr, [x21, lr, lsl #3]
    //     0xc7b888: blr             lr
    // 0xc7b88c: add             SP, SP, #0x10
    // 0xc7b890: mov             x3, x0
    // 0xc7b894: stur            x3, [fp, #-8]
    // 0xc7b898: cmp             w3, NULL
    // 0xc7b89c: b.eq            #0xc7ba0c
    // 0xc7b8a0: mov             x0, x3
    // 0xc7b8a4: r2 = Null
    //     0xc7b8a4: mov             x2, NULL
    // 0xc7b8a8: r1 = Null
    //     0xc7b8a8: mov             x1, NULL
    // 0xc7b8ac: r4 = 59
    //     0xc7b8ac: mov             x4, #0x3b
    // 0xc7b8b0: branchIfSmi(r0, 0xc7b8bc)
    //     0xc7b8b0: tbz             w0, #0, #0xc7b8bc
    // 0xc7b8b4: r4 = LoadClassIdInstr(r0)
    //     0xc7b8b4: ldur            x4, [x0, #-1]
    //     0xc7b8b8: ubfx            x4, x4, #0xc, #0x14
    // 0xc7b8bc: sub             x4, x4, #0x5d
    // 0xc7b8c0: cmp             x4, #3
    // 0xc7b8c4: b.ls            #0xc7b8d8
    // 0xc7b8c8: r8 = String
    //     0xc7b8c8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc7b8cc: r3 = Null
    //     0xc7b8cc: add             x3, PP, #0x54, lsl #12  ; [pp+0x54098] Null
    //     0xc7b8d0: ldr             x3, [x3, #0x98]
    // 0xc7b8d4: r0 = String()
    //     0xc7b8d4: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc7b8d8: ldr             x1, [fp, #0x10]
    // 0xc7b8dc: r0 = LoadClassIdInstr(r1)
    //     0xc7b8dc: ldur            x0, [x1, #-1]
    //     0xc7b8e0: ubfx            x0, x0, #0xc, #0x14
    // 0xc7b8e4: r16 = "lensFacing"
    //     0xc7b8e4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e48] "lensFacing"
    //     0xc7b8e8: ldr             x16, [x16, #0xe48]
    // 0xc7b8ec: stp             x16, x1, [SP, #-0x10]!
    // 0xc7b8f0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7b8f0: sub             lr, x0, #0xef
    //     0xc7b8f4: ldr             lr, [x21, lr, lsl #3]
    //     0xc7b8f8: blr             lr
    // 0xc7b8fc: add             SP, SP, #0x10
    // 0xc7b900: mov             x3, x0
    // 0xc7b904: stur            x3, [fp, #-0x10]
    // 0xc7b908: cmp             w3, NULL
    // 0xc7b90c: b.eq            #0xc7ba10
    // 0xc7b910: mov             x0, x3
    // 0xc7b914: r2 = Null
    //     0xc7b914: mov             x2, NULL
    // 0xc7b918: r1 = Null
    //     0xc7b918: mov             x1, NULL
    // 0xc7b91c: r4 = 59
    //     0xc7b91c: mov             x4, #0x3b
    // 0xc7b920: branchIfSmi(r0, 0xc7b92c)
    //     0xc7b920: tbz             w0, #0, #0xc7b92c
    // 0xc7b924: r4 = LoadClassIdInstr(r0)
    //     0xc7b924: ldur            x4, [x0, #-1]
    //     0xc7b928: ubfx            x4, x4, #0xc, #0x14
    // 0xc7b92c: sub             x4, x4, #0x5d
    // 0xc7b930: cmp             x4, #3
    // 0xc7b934: b.ls            #0xc7b948
    // 0xc7b938: r8 = String
    //     0xc7b938: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc7b93c: r3 = Null
    //     0xc7b93c: add             x3, PP, #0x54, lsl #12  ; [pp+0x540a8] Null
    //     0xc7b940: ldr             x3, [x3, #0xa8]
    // 0xc7b944: r0 = String()
    //     0xc7b944: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc7b948: ldur            x16, [fp, #-0x10]
    // 0xc7b94c: SaveReg r16
    //     0xc7b94c: str             x16, [SP, #-8]!
    // 0xc7b950: r0 = parseCameraLensDirection()
    //     0xc7b950: bl              #0xc7b608  ; [package:camera_android/src/utils.dart] ::parseCameraLensDirection
    // 0xc7b954: add             SP, SP, #8
    // 0xc7b958: mov             x1, x0
    // 0xc7b95c: ldr             x0, [fp, #0x10]
    // 0xc7b960: stur            x1, [fp, #-0x10]
    // 0xc7b964: r2 = LoadClassIdInstr(r0)
    //     0xc7b964: ldur            x2, [x0, #-1]
    //     0xc7b968: ubfx            x2, x2, #0xc, #0x14
    // 0xc7b96c: r16 = "sensorOrientation"
    //     0xc7b96c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e60] "sensorOrientation"
    //     0xc7b970: ldr             x16, [x16, #0xe60]
    // 0xc7b974: stp             x16, x0, [SP, #-0x10]!
    // 0xc7b978: mov             x0, x2
    // 0xc7b97c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7b97c: sub             lr, x0, #0xef
    //     0xc7b980: ldr             lr, [x21, lr, lsl #3]
    //     0xc7b984: blr             lr
    // 0xc7b988: add             SP, SP, #0x10
    // 0xc7b98c: mov             x3, x0
    // 0xc7b990: stur            x3, [fp, #-0x18]
    // 0xc7b994: cmp             w3, NULL
    // 0xc7b998: b.eq            #0xc7ba14
    // 0xc7b99c: r3 as int
    //     0xc7b99c: mov             x0, x3
    //     0xc7b9a0: mov             x2, NULL
    //     0xc7b9a4: mov             x1, NULL
    //     0xc7b9a8: tbz             w0, #0, #0xc7b9d0
    //     0xc7b9ac: ldur            x4, [x0, #-1]
    //     0xc7b9b0: ubfx            x4, x4, #0xc, #0x14
    //     0xc7b9b4: sub             x4, x4, #0x3b
    //     0xc7b9b8: cmp             x4, #1
    //     0xc7b9bc: b.ls            #0xc7b9d0
    //     0xc7b9c0: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xc7b9c4: add             x3, PP, #0x54, lsl #12  ; [pp+0x540b8] Null
    //     0xc7b9c8: ldr             x3, [x3, #0xb8]
    //     0xc7b9cc: bl              #0xd73714
    // 0xc7b9d0: r0 = CameraDescription()
    //     0xc7b9d0: bl              #0xc7b5fc  ; AllocateCameraDescriptionStub -> CameraDescription (size=0x18)
    // 0xc7b9d4: ldur            x1, [fp, #-8]
    // 0xc7b9d8: StoreField: r0->field_7 = r1
    //     0xc7b9d8: stur            w1, [x0, #7]
    // 0xc7b9dc: ldur            x1, [fp, #-0x10]
    // 0xc7b9e0: StoreField: r0->field_b = r1
    //     0xc7b9e0: stur            w1, [x0, #0xb]
    // 0xc7b9e4: ldur            x1, [fp, #-0x18]
    // 0xc7b9e8: r2 = LoadInt32Instr(r1)
    //     0xc7b9e8: sbfx            x2, x1, #1, #0x1f
    //     0xc7b9ec: tbz             w1, #0, #0xc7b9f4
    //     0xc7b9f0: ldur            x2, [x1, #7]
    // 0xc7b9f4: StoreField: r0->field_f = r2
    //     0xc7b9f4: stur            x2, [x0, #0xf]
    // 0xc7b9f8: LeaveFrame
    //     0xc7b9f8: mov             SP, fp
    //     0xc7b9fc: ldp             fp, lr, [SP], #0x10
    // 0xc7ba00: ret
    //     0xc7ba00: ret             
    // 0xc7ba04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7ba04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7ba08: b               #0xc7b86c
    // 0xc7ba0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7ba0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7ba10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7ba10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7ba14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7ba14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static void registerWith() {
    // ** addr: 0xd6ffbc, size: 0x54
    // 0xd6ffbc: EnterFrame
    //     0xd6ffbc: stp             fp, lr, [SP, #-0x10]!
    //     0xd6ffc0: mov             fp, SP
    // 0xd6ffc4: AllocStack(0x8)
    //     0xd6ffc4: sub             SP, SP, #8
    // 0xd6ffc8: CheckStackOverflow
    //     0xd6ffc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6ffcc: cmp             SP, x16
    //     0xd6ffd0: b.ls            #0xd70008
    // 0xd6ffd4: r0 = AVFoundationCamera()
    //     0xd6ffd4: bl              #0xd70174  ; AllocateAVFoundationCameraStub -> AVFoundationCamera (size=0x1c)
    // 0xd6ffd8: stur            x0, [fp, #-8]
    // 0xd6ffdc: SaveReg r0
    //     0xd6ffdc: str             x0, [SP, #-8]!
    // 0xd6ffe0: r0 = AndroidCamera()
    //     0xd6ffe0: bl              #0xd70074  ; [package:camera_android/src/android_camera.dart] AndroidCamera::AndroidCamera
    // 0xd6ffe4: add             SP, SP, #8
    // 0xd6ffe8: ldur            x16, [fp, #-8]
    // 0xd6ffec: SaveReg r16
    //     0xd6ffec: str             x16, [SP, #-8]!
    // 0xd6fff0: r0 = instance=()
    //     0xd6fff0: bl              #0xd70010  ; [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::instance=
    // 0xd6fff4: add             SP, SP, #8
    // 0xd6fff8: r0 = Null
    //     0xd6fff8: mov             x0, NULL
    // 0xd6fffc: LeaveFrame
    //     0xd6fffc: mov             SP, fp
    //     0xd70000: ldp             fp, lr, [SP], #0x10
    // 0xd70004: ret
    //     0xd70004: ret             
    // 0xd70008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd70008: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd7000c: b               #0xd6ffd4
  }
}

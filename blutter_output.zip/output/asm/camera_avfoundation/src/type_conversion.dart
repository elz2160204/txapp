// lib: , url: package:camera_avfoundation/src/type_conversion.dart

// class id: 1048710, size: 0x8
class :: {

  static _ cameraImageFromPlatformData(/* No info */) {
    // ** addr: 0xc6ba34, size: 0x38c
    // 0xc6ba34: EnterFrame
    //     0xc6ba34: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ba38: mov             fp, SP
    // 0xc6ba3c: AllocStack(0x38)
    //     0xc6ba3c: sub             SP, SP, #0x38
    // 0xc6ba40: CheckStackOverflow
    //     0xc6ba40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ba44: cmp             SP, x16
    //     0xc6ba48: b.ls            #0xc6bdb8
    // 0xc6ba4c: ldr             x1, [fp, #0x10]
    // 0xc6ba50: r0 = LoadClassIdInstr(r1)
    //     0xc6ba50: ldur            x0, [x1, #-1]
    //     0xc6ba54: ubfx            x0, x0, #0xc, #0x14
    // 0xc6ba58: r16 = "format"
    //     0xc6ba58: add             x16, PP, #0x25, lsl #12  ; [pp+0x25d08] "format"
    //     0xc6ba5c: ldr             x16, [x16, #0xd08]
    // 0xc6ba60: stp             x16, x1, [SP, #-0x10]!
    // 0xc6ba64: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6ba64: sub             lr, x0, #0xef
    //     0xc6ba68: ldr             lr, [x21, lr, lsl #3]
    //     0xc6ba6c: blr             lr
    // 0xc6ba70: add             SP, SP, #0x10
    // 0xc6ba74: SaveReg r0
    //     0xc6ba74: str             x0, [SP, #-8]!
    // 0xc6ba78: r0 = _cameraImageFormatFromPlatformData()
    //     0xc6ba78: bl              #0xc6bdc0  ; [package:camera_avfoundation/src/type_conversion.dart] ::_cameraImageFormatFromPlatformData
    // 0xc6ba7c: add             SP, SP, #8
    // 0xc6ba80: mov             x2, x0
    // 0xc6ba84: ldr             x1, [fp, #0x10]
    // 0xc6ba88: stur            x2, [fp, #-8]
    // 0xc6ba8c: r0 = LoadClassIdInstr(r1)
    //     0xc6ba8c: ldur            x0, [x1, #-1]
    //     0xc6ba90: ubfx            x0, x0, #0xc, #0x14
    // 0xc6ba94: r16 = "height"
    //     0xc6ba94: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb08] "height"
    //     0xc6ba98: ldr             x16, [x16, #0xb08]
    // 0xc6ba9c: stp             x16, x1, [SP, #-0x10]!
    // 0xc6baa0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6baa0: sub             lr, x0, #0xef
    //     0xc6baa4: ldr             lr, [x21, lr, lsl #3]
    //     0xc6baa8: blr             lr
    // 0xc6baac: add             SP, SP, #0x10
    // 0xc6bab0: mov             x3, x0
    // 0xc6bab4: r2 = Null
    //     0xc6bab4: mov             x2, NULL
    // 0xc6bab8: r1 = Null
    //     0xc6bab8: mov             x1, NULL
    // 0xc6babc: stur            x3, [fp, #-0x10]
    // 0xc6bac0: branchIfSmi(r0, 0xc6bae8)
    //     0xc6bac0: tbz             w0, #0, #0xc6bae8
    // 0xc6bac4: r4 = LoadClassIdInstr(r0)
    //     0xc6bac4: ldur            x4, [x0, #-1]
    //     0xc6bac8: ubfx            x4, x4, #0xc, #0x14
    // 0xc6bacc: sub             x4, x4, #0x3b
    // 0xc6bad0: cmp             x4, #1
    // 0xc6bad4: b.ls            #0xc6bae8
    // 0xc6bad8: r8 = int
    //     0xc6bad8: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc6badc: r3 = Null
    //     0xc6badc: add             x3, PP, #0x53, lsl #12  ; [pp+0x53ec8] Null
    //     0xc6bae0: ldr             x3, [x3, #0xec8]
    // 0xc6bae4: r0 = int()
    //     0xc6bae4: bl              #0xd73714  ; IsType_int_Stub
    // 0xc6bae8: ldr             x1, [fp, #0x10]
    // 0xc6baec: r0 = LoadClassIdInstr(r1)
    //     0xc6baec: ldur            x0, [x1, #-1]
    //     0xc6baf0: ubfx            x0, x0, #0xc, #0x14
    // 0xc6baf4: r16 = "width"
    //     0xc6baf4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb30] "width"
    //     0xc6baf8: ldr             x16, [x16, #0xb30]
    // 0xc6bafc: stp             x16, x1, [SP, #-0x10]!
    // 0xc6bb00: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6bb00: sub             lr, x0, #0xef
    //     0xc6bb04: ldr             lr, [x21, lr, lsl #3]
    //     0xc6bb08: blr             lr
    // 0xc6bb0c: add             SP, SP, #0x10
    // 0xc6bb10: mov             x3, x0
    // 0xc6bb14: r2 = Null
    //     0xc6bb14: mov             x2, NULL
    // 0xc6bb18: r1 = Null
    //     0xc6bb18: mov             x1, NULL
    // 0xc6bb1c: stur            x3, [fp, #-0x18]
    // 0xc6bb20: branchIfSmi(r0, 0xc6bb48)
    //     0xc6bb20: tbz             w0, #0, #0xc6bb48
    // 0xc6bb24: r4 = LoadClassIdInstr(r0)
    //     0xc6bb24: ldur            x4, [x0, #-1]
    //     0xc6bb28: ubfx            x4, x4, #0xc, #0x14
    // 0xc6bb2c: sub             x4, x4, #0x3b
    // 0xc6bb30: cmp             x4, #1
    // 0xc6bb34: b.ls            #0xc6bb48
    // 0xc6bb38: r8 = int
    //     0xc6bb38: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc6bb3c: r3 = Null
    //     0xc6bb3c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53ed8] Null
    //     0xc6bb40: ldr             x3, [x3, #0xed8]
    // 0xc6bb44: r0 = int()
    //     0xc6bb44: bl              #0xd73714  ; IsType_int_Stub
    // 0xc6bb48: ldr             x1, [fp, #0x10]
    // 0xc6bb4c: r0 = LoadClassIdInstr(r1)
    //     0xc6bb4c: ldur            x0, [x1, #-1]
    //     0xc6bb50: ubfx            x0, x0, #0xc, #0x14
    // 0xc6bb54: r16 = "lensAperture"
    //     0xc6bb54: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b68] "lensAperture"
    //     0xc6bb58: ldr             x16, [x16, #0xb68]
    // 0xc6bb5c: stp             x16, x1, [SP, #-0x10]!
    // 0xc6bb60: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6bb60: sub             lr, x0, #0xef
    //     0xc6bb64: ldr             lr, [x21, lr, lsl #3]
    //     0xc6bb68: blr             lr
    // 0xc6bb6c: add             SP, SP, #0x10
    // 0xc6bb70: mov             x3, x0
    // 0xc6bb74: r2 = Null
    //     0xc6bb74: mov             x2, NULL
    // 0xc6bb78: r1 = Null
    //     0xc6bb78: mov             x1, NULL
    // 0xc6bb7c: stur            x3, [fp, #-0x20]
    // 0xc6bb80: r4 = 59
    //     0xc6bb80: mov             x4, #0x3b
    // 0xc6bb84: branchIfSmi(r0, 0xc6bb90)
    //     0xc6bb84: tbz             w0, #0, #0xc6bb90
    // 0xc6bb88: r4 = LoadClassIdInstr(r0)
    //     0xc6bb88: ldur            x4, [x0, #-1]
    //     0xc6bb8c: ubfx            x4, x4, #0xc, #0x14
    // 0xc6bb90: cmp             x4, #0x3d
    // 0xc6bb94: b.eq            #0xc6bba8
    // 0xc6bb98: r8 = double?
    //     0xc6bb98: ldr             x8, [PP, #0x21e0]  ; [pp+0x21e0] Type: double?
    // 0xc6bb9c: r3 = Null
    //     0xc6bb9c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53ee8] Null
    //     0xc6bba0: ldr             x3, [x3, #0xee8]
    // 0xc6bba4: r0 = double?()
    //     0xc6bba4: bl              #0xd72b80  ; IsType_double?_Stub
    // 0xc6bba8: ldr             x1, [fp, #0x10]
    // 0xc6bbac: r0 = LoadClassIdInstr(r1)
    //     0xc6bbac: ldur            x0, [x1, #-1]
    //     0xc6bbb0: ubfx            x0, x0, #0xc, #0x14
    // 0xc6bbb4: r16 = "sensorExposureTime"
    //     0xc6bbb4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b80] "sensorExposureTime"
    //     0xc6bbb8: ldr             x16, [x16, #0xb80]
    // 0xc6bbbc: stp             x16, x1, [SP, #-0x10]!
    // 0xc6bbc0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6bbc0: sub             lr, x0, #0xef
    //     0xc6bbc4: ldr             lr, [x21, lr, lsl #3]
    //     0xc6bbc8: blr             lr
    // 0xc6bbcc: add             SP, SP, #0x10
    // 0xc6bbd0: mov             x3, x0
    // 0xc6bbd4: r2 = Null
    //     0xc6bbd4: mov             x2, NULL
    // 0xc6bbd8: r1 = Null
    //     0xc6bbd8: mov             x1, NULL
    // 0xc6bbdc: stur            x3, [fp, #-0x28]
    // 0xc6bbe0: branchIfSmi(r0, 0xc6bc08)
    //     0xc6bbe0: tbz             w0, #0, #0xc6bc08
    // 0xc6bbe4: r4 = LoadClassIdInstr(r0)
    //     0xc6bbe4: ldur            x4, [x0, #-1]
    //     0xc6bbe8: ubfx            x4, x4, #0xc, #0x14
    // 0xc6bbec: sub             x4, x4, #0x3b
    // 0xc6bbf0: cmp             x4, #1
    // 0xc6bbf4: b.ls            #0xc6bc08
    // 0xc6bbf8: r8 = int?
    //     0xc6bbf8: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6bbfc: r3 = Null
    //     0xc6bbfc: add             x3, PP, #0x53, lsl #12  ; [pp+0x53ef8] Null
    //     0xc6bc00: ldr             x3, [x3, #0xef8]
    // 0xc6bc04: r0 = int?()
    //     0xc6bc04: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6bc08: ldr             x1, [fp, #0x10]
    // 0xc6bc0c: r0 = LoadClassIdInstr(r1)
    //     0xc6bc0c: ldur            x0, [x1, #-1]
    //     0xc6bc10: ubfx            x0, x0, #0xc, #0x14
    // 0xc6bc14: r16 = "sensorSensitivity"
    //     0xc6bc14: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b98] "sensorSensitivity"
    //     0xc6bc18: ldr             x16, [x16, #0xb98]
    // 0xc6bc1c: stp             x16, x1, [SP, #-0x10]!
    // 0xc6bc20: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6bc20: sub             lr, x0, #0xef
    //     0xc6bc24: ldr             lr, [x21, lr, lsl #3]
    //     0xc6bc28: blr             lr
    // 0xc6bc2c: add             SP, SP, #0x10
    // 0xc6bc30: mov             x3, x0
    // 0xc6bc34: r2 = Null
    //     0xc6bc34: mov             x2, NULL
    // 0xc6bc38: r1 = Null
    //     0xc6bc38: mov             x1, NULL
    // 0xc6bc3c: stur            x3, [fp, #-0x30]
    // 0xc6bc40: r4 = 59
    //     0xc6bc40: mov             x4, #0x3b
    // 0xc6bc44: branchIfSmi(r0, 0xc6bc50)
    //     0xc6bc44: tbz             w0, #0, #0xc6bc50
    // 0xc6bc48: r4 = LoadClassIdInstr(r0)
    //     0xc6bc48: ldur            x4, [x0, #-1]
    //     0xc6bc4c: ubfx            x4, x4, #0xc, #0x14
    // 0xc6bc50: cmp             x4, #0x3d
    // 0xc6bc54: b.eq            #0xc6bc68
    // 0xc6bc58: r8 = double?
    //     0xc6bc58: ldr             x8, [PP, #0x21e0]  ; [pp+0x21e0] Type: double?
    // 0xc6bc5c: r3 = Null
    //     0xc6bc5c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53f08] Null
    //     0xc6bc60: ldr             x3, [x3, #0xf08]
    // 0xc6bc64: r0 = double?()
    //     0xc6bc64: bl              #0xd72b80  ; IsType_double?_Stub
    // 0xc6bc68: ldr             x0, [fp, #0x10]
    // 0xc6bc6c: r1 = LoadClassIdInstr(r0)
    //     0xc6bc6c: ldur            x1, [x0, #-1]
    //     0xc6bc70: ubfx            x1, x1, #0xc, #0x14
    // 0xc6bc74: r16 = "planes"
    //     0xc6bc74: add             x16, PP, #0x42, lsl #12  ; [pp+0x42f30] "planes"
    //     0xc6bc78: ldr             x16, [x16, #0xf30]
    // 0xc6bc7c: stp             x16, x0, [SP, #-0x10]!
    // 0xc6bc80: mov             x0, x1
    // 0xc6bc84: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6bc84: sub             lr, x0, #0xef
    //     0xc6bc88: ldr             lr, [x21, lr, lsl #3]
    //     0xc6bc8c: blr             lr
    // 0xc6bc90: add             SP, SP, #0x10
    // 0xc6bc94: mov             x3, x0
    // 0xc6bc98: r2 = Null
    //     0xc6bc98: mov             x2, NULL
    // 0xc6bc9c: r1 = Null
    //     0xc6bc9c: mov             x1, NULL
    // 0xc6bca0: stur            x3, [fp, #-0x38]
    // 0xc6bca4: r4 = 59
    //     0xc6bca4: mov             x4, #0x3b
    // 0xc6bca8: branchIfSmi(r0, 0xc6bcb4)
    //     0xc6bca8: tbz             w0, #0, #0xc6bcb4
    // 0xc6bcac: r4 = LoadClassIdInstr(r0)
    //     0xc6bcac: ldur            x4, [x0, #-1]
    //     0xc6bcb0: ubfx            x4, x4, #0xc, #0x14
    // 0xc6bcb4: sub             x4, x4, #0x59
    // 0xc6bcb8: cmp             x4, #2
    // 0xc6bcbc: b.ls            #0xc6bcd0
    // 0xc6bcc0: r8 = List
    //     0xc6bcc0: ldr             x8, [PP, #0x2248]  ; [pp+0x2248] Type: List
    // 0xc6bcc4: r3 = Null
    //     0xc6bcc4: add             x3, PP, #0x53, lsl #12  ; [pp+0x53f18] Null
    //     0xc6bcc8: ldr             x3, [x3, #0xf18]
    // 0xc6bccc: r0 = List()
    //     0xc6bccc: bl              #0xd74840  ; IsType_List_Stub
    // 0xc6bcd0: r1 = Function '<anonymous closure>': static.
    //     0xc6bcd0: add             x1, PP, #0x53, lsl #12  ; [pp+0x53f28] AnonymousClosure: static (0xc6be60), in [package:camera_avfoundation/src/type_conversion.dart] ::cameraImageFromPlatformData (0xc6ba34)
    //     0xc6bcd4: ldr             x1, [x1, #0xf28]
    // 0xc6bcd8: r2 = Null
    //     0xc6bcd8: mov             x2, NULL
    // 0xc6bcdc: r0 = AllocateClosure()
    //     0xc6bcdc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6bce0: mov             x1, x0
    // 0xc6bce4: ldur            x0, [fp, #-0x38]
    // 0xc6bce8: r2 = LoadClassIdInstr(r0)
    //     0xc6bce8: ldur            x2, [x0, #-1]
    //     0xc6bcec: ubfx            x2, x2, #0xc, #0x14
    // 0xc6bcf0: r16 = <CameraImagePlane>
    //     0xc6bcf0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bc8] TypeArguments: <CameraImagePlane>
    //     0xc6bcf4: ldr             x16, [x16, #0xbc8]
    // 0xc6bcf8: stp             x0, x16, [SP, #-0x10]!
    // 0xc6bcfc: SaveReg r1
    //     0xc6bcfc: str             x1, [SP, #-8]!
    // 0xc6bd00: mov             x0, x2
    // 0xc6bd04: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6bd04: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6bd08: r0 = GDT[cid_x0 + 0xc934]()
    //     0xc6bd08: mov             x17, #0xc934
    //     0xc6bd0c: add             lr, x0, x17
    //     0xc6bd10: ldr             lr, [x21, lr, lsl #3]
    //     0xc6bd14: blr             lr
    // 0xc6bd18: add             SP, SP, #0x18
    // 0xc6bd1c: r16 = <CameraImagePlane>
    //     0xc6bd1c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bc8] TypeArguments: <CameraImagePlane>
    //     0xc6bd20: ldr             x16, [x16, #0xbc8]
    // 0xc6bd24: stp             x0, x16, [SP, #-0x10]!
    // 0xc6bd28: r16 = false
    //     0xc6bd28: add             x16, NULL, #0x30  ; false
    // 0xc6bd2c: SaveReg r16
    //     0xc6bd2c: str             x16, [SP, #-8]!
    // 0xc6bd30: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0xc6bd30: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0xc6bd34: r0 = List.from()
    //     0xc6bd34: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0xc6bd38: add             SP, SP, #0x18
    // 0xc6bd3c: r16 = <CameraImagePlane>
    //     0xc6bd3c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bc8] TypeArguments: <CameraImagePlane>
    //     0xc6bd40: ldr             x16, [x16, #0xbc8]
    // 0xc6bd44: stp             x0, x16, [SP, #-0x10]!
    // 0xc6bd48: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc6bd48: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc6bd4c: r0 = makeFixedListUnmodifiable()
    //     0xc6bd4c: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0xc6bd50: add             SP, SP, #0x10
    // 0xc6bd54: stur            x0, [fp, #-0x38]
    // 0xc6bd58: r0 = CameraImageData()
    //     0xc6bd58: bl              #0xc6b054  ; AllocateCameraImageDataStub -> CameraImageData (size=0x2c)
    // 0xc6bd5c: ldur            x1, [fp, #-8]
    // 0xc6bd60: StoreField: r0->field_7 = r1
    //     0xc6bd60: stur            w1, [x0, #7]
    // 0xc6bd64: ldur            x1, [fp, #-0x38]
    // 0xc6bd68: StoreField: r0->field_1b = r1
    //     0xc6bd68: stur            w1, [x0, #0x1b]
    // 0xc6bd6c: ldur            x1, [fp, #-0x10]
    // 0xc6bd70: r2 = LoadInt32Instr(r1)
    //     0xc6bd70: sbfx            x2, x1, #1, #0x1f
    //     0xc6bd74: tbz             w1, #0, #0xc6bd7c
    //     0xc6bd78: ldur            x2, [x1, #7]
    // 0xc6bd7c: StoreField: r0->field_b = r2
    //     0xc6bd7c: stur            x2, [x0, #0xb]
    // 0xc6bd80: ldur            x1, [fp, #-0x18]
    // 0xc6bd84: r2 = LoadInt32Instr(r1)
    //     0xc6bd84: sbfx            x2, x1, #1, #0x1f
    //     0xc6bd88: tbz             w1, #0, #0xc6bd90
    //     0xc6bd8c: ldur            x2, [x1, #7]
    // 0xc6bd90: StoreField: r0->field_13 = r2
    //     0xc6bd90: stur            x2, [x0, #0x13]
    // 0xc6bd94: ldur            x1, [fp, #-0x20]
    // 0xc6bd98: StoreField: r0->field_1f = r1
    //     0xc6bd98: stur            w1, [x0, #0x1f]
    // 0xc6bd9c: ldur            x1, [fp, #-0x28]
    // 0xc6bda0: StoreField: r0->field_23 = r1
    //     0xc6bda0: stur            w1, [x0, #0x23]
    // 0xc6bda4: ldur            x1, [fp, #-0x30]
    // 0xc6bda8: StoreField: r0->field_27 = r1
    //     0xc6bda8: stur            w1, [x0, #0x27]
    // 0xc6bdac: LeaveFrame
    //     0xc6bdac: mov             SP, fp
    //     0xc6bdb0: ldp             fp, lr, [SP], #0x10
    // 0xc6bdb4: ret
    //     0xc6bdb4: ret             
    // 0xc6bdb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6bdb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6bdbc: b               #0xc6ba4c
  }
  static _ _cameraImageFormatFromPlatformData(/* No info */) {
    // ** addr: 0xc6bdc0, size: 0xa0
    // 0xc6bdc0: EnterFrame
    //     0xc6bdc0: stp             fp, lr, [SP, #-0x10]!
    //     0xc6bdc4: mov             fp, SP
    // 0xc6bdc8: AllocStack(0x8)
    //     0xc6bdc8: sub             SP, SP, #8
    // 0xc6bdcc: CheckStackOverflow
    //     0xc6bdcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6bdd0: cmp             SP, x16
    //     0xc6bdd4: b.ls            #0xc6be58
    // 0xc6bdd8: r16 = 1751408876
    //     0xc6bdd8: mov             x16, #0x60ec
    //     0xc6bddc: movk            x16, #0x6864, lsl #16
    // 0xc6bde0: ldr             lr, [fp, #0x10]
    // 0xc6bde4: stp             lr, x16, [SP, #-0x10]!
    // 0xc6bde8: r0 = ==()
    //     0xc6bde8: bl              #0xcbbc60  ; [dart:core] _IntegerImplementation::==
    // 0xc6bdec: add             SP, SP, #0x10
    // 0xc6bdf0: tbnz            w0, #4, #0xc6be00
    // 0xc6bdf4: r1 = Instance_ImageFormatGroup
    //     0xc6bdf4: add             x1, PP, #0x53, lsl #12  ; [pp+0x53c48] Obj!ImageFormatGroup@b66a91
    //     0xc6bdf8: ldr             x1, [x1, #0xc48]
    // 0xc6bdfc: b               #0xc6be30
    // 0xc6be00: r16 = 1111970369
    //     0xc6be00: add             x16, PP, #0x53, lsl #12  ; [pp+0x53c58] 0x42475241
    //     0xc6be04: ldr             x16, [x16, #0xc58]
    // 0xc6be08: ldr             lr, [fp, #0x10]
    // 0xc6be0c: stp             lr, x16, [SP, #-0x10]!
    // 0xc6be10: r0 = ==()
    //     0xc6be10: bl              #0xcbbc60  ; [dart:core] _IntegerImplementation::==
    // 0xc6be14: add             SP, SP, #0x10
    // 0xc6be18: tbnz            w0, #4, #0xc6be28
    // 0xc6be1c: r1 = Instance_ImageFormatGroup
    //     0xc6be1c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53c60] Obj!ImageFormatGroup@b66ab1
    //     0xc6be20: ldr             x1, [x1, #0xc60]
    // 0xc6be24: b               #0xc6be30
    // 0xc6be28: r1 = Instance_ImageFormatGroup
    //     0xc6be28: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d3b8] Obj!ImageFormatGroup@b66a31
    //     0xc6be2c: ldr             x1, [x1, #0x3b8]
    // 0xc6be30: ldr             x0, [fp, #0x10]
    // 0xc6be34: stur            x1, [fp, #-8]
    // 0xc6be38: r0 = CameraImageFormat()
    //     0xc6be38: bl              #0xc6b134  ; AllocateCameraImageFormatStub -> CameraImageFormat (size=0x10)
    // 0xc6be3c: ldur            x1, [fp, #-8]
    // 0xc6be40: StoreField: r0->field_7 = r1
    //     0xc6be40: stur            w1, [x0, #7]
    // 0xc6be44: ldr             x1, [fp, #0x10]
    // 0xc6be48: StoreField: r0->field_b = r1
    //     0xc6be48: stur            w1, [x0, #0xb]
    // 0xc6be4c: LeaveFrame
    //     0xc6be4c: mov             SP, fp
    //     0xc6be50: ldp             fp, lr, [SP], #0x10
    // 0xc6be54: ret
    //     0xc6be54: ret             
    // 0xc6be58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6be58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6be5c: b               #0xc6bdd8
  }
  [closure] static CameraImagePlane <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xc6be60, size: 0x54
    // 0xc6be60: EnterFrame
    //     0xc6be60: stp             fp, lr, [SP, #-0x10]!
    //     0xc6be64: mov             fp, SP
    // 0xc6be68: CheckStackOverflow
    //     0xc6be68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6be6c: cmp             SP, x16
    //     0xc6be70: b.ls            #0xc6beac
    // 0xc6be74: ldr             x0, [fp, #0x10]
    // 0xc6be78: r2 = Null
    //     0xc6be78: mov             x2, NULL
    // 0xc6be7c: r1 = Null
    //     0xc6be7c: mov             x1, NULL
    // 0xc6be80: r8 = Map
    //     0xc6be80: ldr             x8, [PP, #0x2338]  ; [pp+0x2338] Type: Map
    // 0xc6be84: r3 = Null
    //     0xc6be84: add             x3, PP, #0x53, lsl #12  ; [pp+0x53f30] Null
    //     0xc6be88: ldr             x3, [x3, #0xf30]
    // 0xc6be8c: r0 = Map()
    //     0xc6be8c: bl              #0xd747e8  ; IsType_Map_Stub
    // 0xc6be90: ldr             x16, [fp, #0x10]
    // 0xc6be94: SaveReg r16
    //     0xc6be94: str             x16, [SP, #-8]!
    // 0xc6be98: r0 = _cameraImagePlaneFromPlatformData()
    //     0xc6be98: bl              #0xc6beb4  ; [package:camera_avfoundation/src/type_conversion.dart] ::_cameraImagePlaneFromPlatformData
    // 0xc6be9c: add             SP, SP, #8
    // 0xc6bea0: LeaveFrame
    //     0xc6bea0: mov             SP, fp
    //     0xc6bea4: ldp             fp, lr, [SP], #0x10
    // 0xc6bea8: ret
    //     0xc6bea8: ret             
    // 0xc6beac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6beac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6beb0: b               #0xc6be74
  }
  static _ _cameraImagePlaneFromPlatformData(/* No info */) {
    // ** addr: 0xc6beb4, size: 0x250
    // 0xc6beb4: EnterFrame
    //     0xc6beb4: stp             fp, lr, [SP, #-0x10]!
    //     0xc6beb8: mov             fp, SP
    // 0xc6bebc: AllocStack(0x28)
    //     0xc6bebc: sub             SP, SP, #0x28
    // 0xc6bec0: CheckStackOverflow
    //     0xc6bec0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6bec4: cmp             SP, x16
    //     0xc6bec8: b.ls            #0xc6c0fc
    // 0xc6becc: ldr             x1, [fp, #0x10]
    // 0xc6bed0: r0 = LoadClassIdInstr(r1)
    //     0xc6bed0: ldur            x0, [x1, #-1]
    //     0xc6bed4: ubfx            x0, x0, #0xc, #0x14
    // 0xc6bed8: r16 = "bytes"
    //     0xc6bed8: add             x16, PP, #0x53, lsl #12  ; [pp+0x53be0] "bytes"
    //     0xc6bedc: ldr             x16, [x16, #0xbe0]
    // 0xc6bee0: stp             x16, x1, [SP, #-0x10]!
    // 0xc6bee4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6bee4: sub             lr, x0, #0xef
    //     0xc6bee8: ldr             lr, [x21, lr, lsl #3]
    //     0xc6beec: blr             lr
    // 0xc6bef0: add             SP, SP, #0x10
    // 0xc6bef4: mov             x3, x0
    // 0xc6bef8: r2 = Null
    //     0xc6bef8: mov             x2, NULL
    // 0xc6befc: r1 = Null
    //     0xc6befc: mov             x1, NULL
    // 0xc6bf00: stur            x3, [fp, #-8]
    // 0xc6bf04: r4 = 59
    //     0xc6bf04: mov             x4, #0x3b
    // 0xc6bf08: branchIfSmi(r0, 0xc6bf14)
    //     0xc6bf08: tbz             w0, #0, #0xc6bf14
    // 0xc6bf0c: r4 = LoadClassIdInstr(r0)
    //     0xc6bf0c: ldur            x4, [x0, #-1]
    //     0xc6bf10: ubfx            x4, x4, #0xc, #0x14
    // 0xc6bf14: sub             x4, x4, #0x75
    // 0xc6bf18: cmp             x4, #3
    // 0xc6bf1c: b.ls            #0xc6bf34
    // 0xc6bf20: r8 = Uint8List
    //     0xc6bf20: add             x8, PP, #8, lsl #12  ; [pp+0x8760] Type: Uint8List
    //     0xc6bf24: ldr             x8, [x8, #0x760]
    // 0xc6bf28: r3 = Null
    //     0xc6bf28: add             x3, PP, #0x53, lsl #12  ; [pp+0x53f40] Null
    //     0xc6bf2c: ldr             x3, [x3, #0xf40]
    // 0xc6bf30: r0 = Uint8List()
    //     0xc6bf30: bl              #0x4b2828  ; IsType_Uint8List_Stub
    // 0xc6bf34: ldr             x1, [fp, #0x10]
    // 0xc6bf38: r0 = LoadClassIdInstr(r1)
    //     0xc6bf38: ldur            x0, [x1, #-1]
    //     0xc6bf3c: ubfx            x0, x0, #0xc, #0x14
    // 0xc6bf40: r16 = "bytesPerPixel"
    //     0xc6bf40: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bf8] "bytesPerPixel"
    //     0xc6bf44: ldr             x16, [x16, #0xbf8]
    // 0xc6bf48: stp             x16, x1, [SP, #-0x10]!
    // 0xc6bf4c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6bf4c: sub             lr, x0, #0xef
    //     0xc6bf50: ldr             lr, [x21, lr, lsl #3]
    //     0xc6bf54: blr             lr
    // 0xc6bf58: add             SP, SP, #0x10
    // 0xc6bf5c: mov             x3, x0
    // 0xc6bf60: r2 = Null
    //     0xc6bf60: mov             x2, NULL
    // 0xc6bf64: r1 = Null
    //     0xc6bf64: mov             x1, NULL
    // 0xc6bf68: stur            x3, [fp, #-0x10]
    // 0xc6bf6c: branchIfSmi(r0, 0xc6bf94)
    //     0xc6bf6c: tbz             w0, #0, #0xc6bf94
    // 0xc6bf70: r4 = LoadClassIdInstr(r0)
    //     0xc6bf70: ldur            x4, [x0, #-1]
    //     0xc6bf74: ubfx            x4, x4, #0xc, #0x14
    // 0xc6bf78: sub             x4, x4, #0x3b
    // 0xc6bf7c: cmp             x4, #1
    // 0xc6bf80: b.ls            #0xc6bf94
    // 0xc6bf84: r8 = int?
    //     0xc6bf84: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6bf88: r3 = Null
    //     0xc6bf88: add             x3, PP, #0x53, lsl #12  ; [pp+0x53f50] Null
    //     0xc6bf8c: ldr             x3, [x3, #0xf50]
    // 0xc6bf90: r0 = int?()
    //     0xc6bf90: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6bf94: ldr             x1, [fp, #0x10]
    // 0xc6bf98: r0 = LoadClassIdInstr(r1)
    //     0xc6bf98: ldur            x0, [x1, #-1]
    //     0xc6bf9c: ubfx            x0, x0, #0xc, #0x14
    // 0xc6bfa0: r16 = "bytesPerRow"
    //     0xc6bfa0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53c10] "bytesPerRow"
    //     0xc6bfa4: ldr             x16, [x16, #0xc10]
    // 0xc6bfa8: stp             x16, x1, [SP, #-0x10]!
    // 0xc6bfac: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6bfac: sub             lr, x0, #0xef
    //     0xc6bfb0: ldr             lr, [x21, lr, lsl #3]
    //     0xc6bfb4: blr             lr
    // 0xc6bfb8: add             SP, SP, #0x10
    // 0xc6bfbc: mov             x3, x0
    // 0xc6bfc0: r2 = Null
    //     0xc6bfc0: mov             x2, NULL
    // 0xc6bfc4: r1 = Null
    //     0xc6bfc4: mov             x1, NULL
    // 0xc6bfc8: stur            x3, [fp, #-0x18]
    // 0xc6bfcc: branchIfSmi(r0, 0xc6bff4)
    //     0xc6bfcc: tbz             w0, #0, #0xc6bff4
    // 0xc6bfd0: r4 = LoadClassIdInstr(r0)
    //     0xc6bfd0: ldur            x4, [x0, #-1]
    //     0xc6bfd4: ubfx            x4, x4, #0xc, #0x14
    // 0xc6bfd8: sub             x4, x4, #0x3b
    // 0xc6bfdc: cmp             x4, #1
    // 0xc6bfe0: b.ls            #0xc6bff4
    // 0xc6bfe4: r8 = int
    //     0xc6bfe4: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc6bfe8: r3 = Null
    //     0xc6bfe8: add             x3, PP, #0x53, lsl #12  ; [pp+0x53f60] Null
    //     0xc6bfec: ldr             x3, [x3, #0xf60]
    // 0xc6bff0: r0 = int()
    //     0xc6bff0: bl              #0xd73714  ; IsType_int_Stub
    // 0xc6bff4: ldr             x1, [fp, #0x10]
    // 0xc6bff8: r0 = LoadClassIdInstr(r1)
    //     0xc6bff8: ldur            x0, [x1, #-1]
    //     0xc6bffc: ubfx            x0, x0, #0xc, #0x14
    // 0xc6c000: r16 = "height"
    //     0xc6c000: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb08] "height"
    //     0xc6c004: ldr             x16, [x16, #0xb08]
    // 0xc6c008: stp             x16, x1, [SP, #-0x10]!
    // 0xc6c00c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6c00c: sub             lr, x0, #0xef
    //     0xc6c010: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c014: blr             lr
    // 0xc6c018: add             SP, SP, #0x10
    // 0xc6c01c: mov             x3, x0
    // 0xc6c020: r2 = Null
    //     0xc6c020: mov             x2, NULL
    // 0xc6c024: r1 = Null
    //     0xc6c024: mov             x1, NULL
    // 0xc6c028: stur            x3, [fp, #-0x20]
    // 0xc6c02c: branchIfSmi(r0, 0xc6c054)
    //     0xc6c02c: tbz             w0, #0, #0xc6c054
    // 0xc6c030: r4 = LoadClassIdInstr(r0)
    //     0xc6c030: ldur            x4, [x0, #-1]
    //     0xc6c034: ubfx            x4, x4, #0xc, #0x14
    // 0xc6c038: sub             x4, x4, #0x3b
    // 0xc6c03c: cmp             x4, #1
    // 0xc6c040: b.ls            #0xc6c054
    // 0xc6c044: r8 = int?
    //     0xc6c044: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6c048: r3 = Null
    //     0xc6c048: add             x3, PP, #0x53, lsl #12  ; [pp+0x53f70] Null
    //     0xc6c04c: ldr             x3, [x3, #0xf70]
    // 0xc6c050: r0 = int?()
    //     0xc6c050: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6c054: ldr             x0, [fp, #0x10]
    // 0xc6c058: r1 = LoadClassIdInstr(r0)
    //     0xc6c058: ldur            x1, [x0, #-1]
    //     0xc6c05c: ubfx            x1, x1, #0xc, #0x14
    // 0xc6c060: r16 = "width"
    //     0xc6c060: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb30] "width"
    //     0xc6c064: ldr             x16, [x16, #0xb30]
    // 0xc6c068: stp             x16, x0, [SP, #-0x10]!
    // 0xc6c06c: mov             x0, x1
    // 0xc6c070: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6c070: sub             lr, x0, #0xef
    //     0xc6c074: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c078: blr             lr
    // 0xc6c07c: add             SP, SP, #0x10
    // 0xc6c080: mov             x3, x0
    // 0xc6c084: r2 = Null
    //     0xc6c084: mov             x2, NULL
    // 0xc6c088: r1 = Null
    //     0xc6c088: mov             x1, NULL
    // 0xc6c08c: stur            x3, [fp, #-0x28]
    // 0xc6c090: branchIfSmi(r0, 0xc6c0b8)
    //     0xc6c090: tbz             w0, #0, #0xc6c0b8
    // 0xc6c094: r4 = LoadClassIdInstr(r0)
    //     0xc6c094: ldur            x4, [x0, #-1]
    //     0xc6c098: ubfx            x4, x4, #0xc, #0x14
    // 0xc6c09c: sub             x4, x4, #0x3b
    // 0xc6c0a0: cmp             x4, #1
    // 0xc6c0a4: b.ls            #0xc6c0b8
    // 0xc6c0a8: r8 = int?
    //     0xc6c0a8: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6c0ac: r3 = Null
    //     0xc6c0ac: add             x3, PP, #0x53, lsl #12  ; [pp+0x53f80] Null
    //     0xc6c0b0: ldr             x3, [x3, #0xf80]
    // 0xc6c0b4: r0 = int?()
    //     0xc6c0b4: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6c0b8: r0 = CameraImagePlane()
    //     0xc6c0b8: bl              #0xc6b3e4  ; AllocateCameraImagePlaneStub -> CameraImagePlane (size=0x20)
    // 0xc6c0bc: ldur            x1, [fp, #-8]
    // 0xc6c0c0: StoreField: r0->field_7 = r1
    //     0xc6c0c0: stur            w1, [x0, #7]
    // 0xc6c0c4: ldur            x1, [fp, #-0x18]
    // 0xc6c0c8: r2 = LoadInt32Instr(r1)
    //     0xc6c0c8: sbfx            x2, x1, #1, #0x1f
    //     0xc6c0cc: tbz             w1, #0, #0xc6c0d4
    //     0xc6c0d0: ldur            x2, [x1, #7]
    // 0xc6c0d4: StoreField: r0->field_b = r2
    //     0xc6c0d4: stur            x2, [x0, #0xb]
    // 0xc6c0d8: ldur            x1, [fp, #-0x10]
    // 0xc6c0dc: StoreField: r0->field_13 = r1
    //     0xc6c0dc: stur            w1, [x0, #0x13]
    // 0xc6c0e0: ldur            x1, [fp, #-0x20]
    // 0xc6c0e4: StoreField: r0->field_17 = r1
    //     0xc6c0e4: stur            w1, [x0, #0x17]
    // 0xc6c0e8: ldur            x1, [fp, #-0x28]
    // 0xc6c0ec: StoreField: r0->field_1b = r1
    //     0xc6c0ec: stur            w1, [x0, #0x1b]
    // 0xc6c0f0: LeaveFrame
    //     0xc6c0f0: mov             SP, fp
    //     0xc6c0f4: ldp             fp, lr, [SP], #0x10
    // 0xc6c0f8: ret
    //     0xc6c0f8: ret             
    // 0xc6c0fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6c0fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6c100: b               #0xc6becc
  }
}

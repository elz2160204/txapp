// lib: , url: package:device_info_plus_platform_interface/method_channel/method_channel_device_info.dart

// class id: 1048876, size: 0x8
class :: {
}

// class id: 4948, size: 0xc, field offset: 0x8
class MethodChannelDeviceInfo extends DeviceInfoPlatform {

  _ deviceInfo(/* No info */) async {
    // ** addr: 0xc56860, size: 0xe0
    // 0xc56860: EnterFrame
    //     0xc56860: stp             fp, lr, [SP, #-0x10]!
    //     0xc56864: mov             fp, SP
    // 0xc56868: AllocStack(0x18)
    //     0xc56868: sub             SP, SP, #0x18
    // 0xc5686c: SetupParameters(MethodChannelDeviceInfo this /* r1, fp-0x10 */)
    //     0xc5686c: stur            NULL, [fp, #-8]
    //     0xc56870: mov             x0, #0
    //     0xc56874: add             x1, fp, w0, sxtw #2
    //     0xc56878: ldr             x1, [x1, #0x10]
    //     0xc5687c: stur            x1, [fp, #-0x10]
    // 0xc56880: CheckStackOverflow
    //     0xc56880: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc56884: cmp             SP, x16
    //     0xc56888: b.ls            #0xc56938
    // 0xc5688c: InitAsync() -> Future<BaseDeviceInfo>
    //     0xc5688c: add             x0, PP, #0x33, lsl #12  ; [pp+0x33c20] TypeArguments: <BaseDeviceInfo>
    //     0xc56890: ldr             x0, [x0, #0xc20]
    //     0xc56894: bl              #0x4b92e4
    // 0xc56898: r0 = BaseDeviceInfo()
    //     0xc56898: bl              #0xc56940  ; AllocateBaseDeviceInfoStub -> BaseDeviceInfo (size=0xc)
    // 0xc5689c: stur            x0, [fp, #-0x10]
    // 0xc568a0: r16 = Instance_MethodChannel
    //     0xc568a0: ldr             x16, [PP, #0x248]  ; [pp+0x248] Obj!MethodChannel@b34d31
    // 0xc568a4: stp             x16, NULL, [SP, #-0x10]!
    // 0xc568a8: r16 = "getDeviceInfo"
    //     0xc568a8: add             x16, PP, #0x41, lsl #12  ; [pp+0x410f0] "getDeviceInfo"
    //     0xc568ac: ldr             x16, [x16, #0xf0]
    // 0xc568b0: SaveReg r16
    //     0xc568b0: str             x16, [SP, #-8]!
    // 0xc568b4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc568b4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc568b8: r0 = invokeMethod()
    //     0xc568b8: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc568bc: add             SP, SP, #0x18
    // 0xc568c0: mov             x1, x0
    // 0xc568c4: stur            x1, [fp, #-0x18]
    // 0xc568c8: r0 = Await()
    //     0xc568c8: bl              #0x4b8e6c  ; AwaitStub
    // 0xc568cc: r16 = <String, dynamic>
    //     0xc568cc: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc568d0: stp             x0, x16, [SP, #-0x10]!
    // 0xc568d4: r4 = 0
    //     0xc568d4: mov             x4, #0
    // 0xc568d8: ldr             x0, [SP]
    // 0xc568dc: r5 = UnlinkedCall_0x4aeefc
    //     0xc568dc: add             x16, PP, #0x41, lsl #12  ; [pp+0x410f8] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xc568e0: ldp             x5, lr, [x16, #0xf8]
    // 0xc568e4: blr             lr
    // 0xc568e8: add             SP, SP, #0x10
    // 0xc568ec: mov             x3, x0
    // 0xc568f0: r2 = Null
    //     0xc568f0: mov             x2, NULL
    // 0xc568f4: r1 = Null
    //     0xc568f4: mov             x1, NULL
    // 0xc568f8: stur            x3, [fp, #-0x18]
    // 0xc568fc: r8 = Map<String, dynamic>
    //     0xc568fc: ldr             x8, [PP, #0x3da0]  ; [pp+0x3da0] Type: Map<String, dynamic>
    // 0xc56900: r3 = Null
    //     0xc56900: add             x3, PP, #0x41, lsl #12  ; [pp+0x41108] Null
    //     0xc56904: ldr             x3, [x3, #0x108]
    // 0xc56908: r0 = Map<String, dynamic>()
    //     0xc56908: bl              #0x4e3b2c  ; IsType_Map<String, dynamic>_Stub
    // 0xc5690c: ldur            x0, [fp, #-0x18]
    // 0xc56910: ldur            x1, [fp, #-0x10]
    // 0xc56914: StoreField: r1->field_7 = r0
    //     0xc56914: stur            w0, [x1, #7]
    //     0xc56918: ldurb           w16, [x1, #-1]
    //     0xc5691c: ldurb           w17, [x0, #-1]
    //     0xc56920: and             x16, x17, x16, lsr #2
    //     0xc56924: tst             x16, HEAP, lsr #32
    //     0xc56928: b.eq            #0xc56930
    //     0xc5692c: bl              #0xd6826c
    // 0xc56930: mov             x0, x1
    // 0xc56934: r0 = ReturnAsyncNotFuture()
    //     0xc56934: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc56938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56938: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5693c: b               #0xc5688c
  }
}

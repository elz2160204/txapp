// lib: , url: package:device_info_plus_platform_interface/device_info_plus_platform_interface.dart

// class id: 1048875, size: 0x8
class :: {
}

// class id: 4947, size: 0x8, field offset: 0x8
abstract class DeviceInfoPlatform extends PlatformInterface {

  static late final Object _token; // offset: 0xb38
  static late DeviceInfoPlatform _instance; // offset: 0xb3c

  static DeviceInfoPlatform _instance() {
    // ** addr: 0x9300f4, size: 0x98
    // 0x9300f4: EnterFrame
    //     0x9300f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9300f8: mov             fp, SP
    // 0x9300fc: AllocStack(0x10)
    //     0x9300fc: sub             SP, SP, #0x10
    // 0x930100: CheckStackOverflow
    //     0x930100: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x930104: cmp             SP, x16
    //     0x930108: b.ls            #0x930184
    // 0x93010c: r0 = MethodChannelDeviceInfo()
    //     0x93010c: bl              #0x93018c  ; AllocateMethodChannelDeviceInfoStub -> MethodChannelDeviceInfo (size=0xc)
    // 0x930110: mov             x1, x0
    // 0x930114: r0 = Instance_MethodChannel
    //     0x930114: ldr             x0, [PP, #0x248]  ; [pp+0x248] Obj!MethodChannel@b34d31
    // 0x930118: stur            x1, [fp, #-8]
    // 0x93011c: StoreField: r1->field_7 = r0
    //     0x93011c: stur            w0, [x1, #7]
    // 0x930120: r0 = InitLateStaticField(0xb38) // [package:device_info_plus_platform_interface/device_info_plus_platform_interface.dart] DeviceInfoPlatform::_token
    //     0x930120: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x930124: ldr             x0, [x0, #0x1670]
    //     0x930128: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x93012c: cmp             w0, w16
    //     0x930130: b.ne            #0x93013c
    //     0x930134: ldr             x2, [PP, #0x240]  ; [pp+0x240] Field <DeviceInfoPlatform._token@337502559>: static late final (offset: 0xb38)
    //     0x930138: bl              #0xd67cdc
    // 0x93013c: stur            x0, [fp, #-0x10]
    // 0x930140: r0 = InitLateStaticField(0xa64) // [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::_instanceTokens
    //     0x930140: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x930144: ldr             x0, [x0, #0x14c8]
    //     0x930148: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x93014c: cmp             w0, w16
    //     0x930150: b.ne            #0x93015c
    //     0x930154: ldr             x2, [PP, #0x170]  ; [pp+0x170] Field <PlatformInterface._instanceTokens@187304592>: static late final (offset: 0xa64)
    //     0x930158: bl              #0xd67cdc
    // 0x93015c: ldur            x16, [fp, #-8]
    // 0x930160: stp             x16, x0, [SP, #-0x10]!
    // 0x930164: ldur            x16, [fp, #-0x10]
    // 0x930168: SaveReg r16
    //     0x930168: str             x16, [SP, #-8]!
    // 0x93016c: r0 = []=()
    //     0x93016c: bl              #0x4b97f8  ; [dart:core] Expando::[]=
    // 0x930170: add             SP, SP, #0x18
    // 0x930174: ldur            x0, [fp, #-8]
    // 0x930178: LeaveFrame
    //     0x930178: mov             SP, fp
    //     0x93017c: ldp             fp, lr, [SP], #0x10
    // 0x930180: ret
    //     0x930180: ret             
    // 0x930184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x930184: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x930188: b               #0x93010c
  }
  set _ instance=(/* No info */) {
    // ** addr: 0xd6daf4, size: 0x64
    // 0xd6daf4: EnterFrame
    //     0xd6daf4: stp             fp, lr, [SP, #-0x10]!
    //     0xd6daf8: mov             fp, SP
    // 0xd6dafc: CheckStackOverflow
    //     0xd6dafc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6db00: cmp             SP, x16
    //     0xd6db04: b.ls            #0xd6db50
    // 0xd6db08: r0 = InitLateStaticField(0xb38) // [package:device_info_plus_platform_interface/device_info_plus_platform_interface.dart] DeviceInfoPlatform::_token
    //     0xd6db08: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6db0c: ldr             x0, [x0, #0x1670]
    //     0xd6db10: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6db14: cmp             w0, w16
    //     0xd6db18: b.ne            #0xd6db24
    //     0xd6db1c: ldr             x2, [PP, #0x240]  ; [pp+0x240] Field <DeviceInfoPlatform._token@337502559>: static late final (offset: 0xb38)
    //     0xd6db20: bl              #0xd67cdc
    // 0xd6db24: ldr             x16, [fp, #0x10]
    // 0xd6db28: stp             x0, x16, [SP, #-0x10]!
    // 0xd6db2c: r0 = verifyToken()
    //     0xd6db2c: bl              #0xd6da00  ; [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::verifyToken
    // 0xd6db30: add             SP, SP, #0x10
    // 0xd6db34: ldr             x1, [fp, #0x10]
    // 0xd6db38: StoreStaticField(0xb3c, r1)
    //     0xd6db38: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0xd6db3c: str             x1, [x2, #0x1678]
    // 0xd6db40: r0 = Null
    //     0xd6db40: mov             x0, NULL
    // 0xd6db44: LeaveFrame
    //     0xd6db44: mov             SP, fp
    //     0xd6db48: ldp             fp, lr, [SP], #0x10
    // 0xd6db4c: ret
    //     0xd6db4c: ret             
    // 0xd6db50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6db50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6db54: b               #0xd6db08
  }
}

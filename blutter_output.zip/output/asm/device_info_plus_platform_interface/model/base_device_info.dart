// lib: , url: package:device_info_plus_platform_interface/model/base_device_info.dart

// class id: 1048877, size: 0x8
class :: {
}

// class id: 4558, size: 0xc, field offset: 0x8
class BaseDeviceInfo extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad34a0, size: 0x64
    // 0xad34a0: EnterFrame
    //     0xad34a0: stp             fp, lr, [SP, #-0x10]!
    //     0xad34a4: mov             fp, SP
    // 0xad34a8: CheckStackOverflow
    //     0xad34a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad34ac: cmp             SP, x16
    //     0xad34b0: b.ls            #0xad34fc
    // 0xad34b4: r1 = Null
    //     0xad34b4: mov             x1, NULL
    // 0xad34b8: r2 = 6
    //     0xad34b8: mov             x2, #6
    // 0xad34bc: r0 = AllocateArray()
    //     0xad34bc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad34c0: r17 = "BaseDeviceInfo{data: "
    //     0xad34c0: add             x17, PP, #0x41, lsl #12  ; [pp+0x41118] "BaseDeviceInfo{data: "
    //     0xad34c4: ldr             x17, [x17, #0x118]
    // 0xad34c8: StoreField: r0->field_f = r17
    //     0xad34c8: stur            w17, [x0, #0xf]
    // 0xad34cc: ldr             x1, [fp, #0x10]
    // 0xad34d0: LoadField: r2 = r1->field_7
    //     0xad34d0: ldur            w2, [x1, #7]
    // 0xad34d4: DecompressPointer r2
    //     0xad34d4: add             x2, x2, HEAP, lsl #32
    // 0xad34d8: StoreField: r0->field_13 = r2
    //     0xad34d8: stur            w2, [x0, #0x13]
    // 0xad34dc: r17 = "}"
    //     0xad34dc: ldr             x17, [PP, #0x438]  ; [pp+0x438] "}"
    // 0xad34e0: StoreField: r0->field_17 = r17
    //     0xad34e0: stur            w17, [x0, #0x17]
    // 0xad34e4: SaveReg r0
    //     0xad34e4: str             x0, [SP, #-8]!
    // 0xad34e8: r0 = _interpolate()
    //     0xad34e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad34ec: add             SP, SP, #8
    // 0xad34f0: LeaveFrame
    //     0xad34f0: mov             SP, fp
    //     0xad34f4: ldp             fp, lr, [SP], #0x10
    // 0xad34f8: ret
    //     0xad34f8: ret             
    // 0xad34fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad34fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3500: b               #0xad34b4
  }
}

// lib: , url: package:emoji_picker_flutter/src/recent_tab_behavior.dart

// class id: 1048921, size: 0x8
class :: {
}

// class id: 6003, size: 0x14, field offset: 0x14
enum RecentTabBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb156cc, size: 0x5c
    // 0xb156cc: EnterFrame
    //     0xb156cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb156d0: mov             fp, SP
    // 0xb156d4: CheckStackOverflow
    //     0xb156d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb156d8: cmp             SP, x16
    //     0xb156dc: b.ls            #0xb15720
    // 0xb156e0: r1 = Null
    //     0xb156e0: mov             x1, NULL
    // 0xb156e4: r2 = 4
    //     0xb156e4: mov             x2, #4
    // 0xb156e8: r0 = AllocateArray()
    //     0xb156e8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb156ec: r17 = "RecentTabBehavior."
    //     0xb156ec: add             x17, PP, #0x41, lsl #12  ; [pp+0x41060] "RecentTabBehavior."
    //     0xb156f0: ldr             x17, [x17, #0x60]
    // 0xb156f4: StoreField: r0->field_f = r17
    //     0xb156f4: stur            w17, [x0, #0xf]
    // 0xb156f8: ldr             x1, [fp, #0x10]
    // 0xb156fc: LoadField: r2 = r1->field_f
    //     0xb156fc: ldur            w2, [x1, #0xf]
    // 0xb15700: DecompressPointer r2
    //     0xb15700: add             x2, x2, HEAP, lsl #32
    // 0xb15704: StoreField: r0->field_13 = r2
    //     0xb15704: stur            w2, [x0, #0x13]
    // 0xb15708: SaveReg r0
    //     0xb15708: str             x0, [SP, #-8]!
    // 0xb1570c: r0 = _interpolate()
    //     0xb1570c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15710: add             SP, SP, #8
    // 0xb15714: LeaveFrame
    //     0xb15714: mov             SP, fp
    //     0xb15718: ldp             fp, lr, [SP], #0x10
    // 0xb1571c: ret
    //     0xb1571c: ret             
    // 0xb15720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15720: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15724: b               #0xb156e0
  }
}

// lib: , url: package:emoji_picker_flutter/src/skin_tone_overlay.dart

// class id: 1048922, size: 0x8
class :: {
}

// class id: 3405, size: 0x14, field offset: 0x14
abstract class SkinToneOverlayStateMixin<X0 bound StatefulWidget> extends State<X0 bound StatefulWidget> {
}

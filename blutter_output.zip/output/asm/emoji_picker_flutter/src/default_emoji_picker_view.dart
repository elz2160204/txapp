// lib: , url: package:emoji_picker_flutter/src/default_emoji_picker_view.dart

// class id: 1048908, size: 0x8
class :: {
}

// class id: 3406, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin extends State<DefaultEmojiPickerView>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x613350, size: 0x98
    // 0x613350: EnterFrame
    //     0x613350: stp             fp, lr, [SP, #-0x10]!
    //     0x613354: mov             fp, SP
    // 0x613358: CheckStackOverflow
    //     0x613358: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x61335c: cmp             SP, x16
    //     0x613360: b.ls            #0x6133dc
    // 0x613364: r0 = Ticker()
    //     0x613364: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x613368: mov             x1, x0
    // 0x61336c: r0 = false
    //     0x61336c: add             x0, NULL, #0x30  ; false
    // 0x613370: StoreField: r1->field_b = r0
    //     0x613370: stur            w0, [x1, #0xb]
    // 0x613374: ldr             x0, [fp, #0x10]
    // 0x613378: StoreField: r1->field_13 = r0
    //     0x613378: stur            w0, [x1, #0x13]
    // 0x61337c: mov             x0, x1
    // 0x613380: ldr             x1, [fp, #0x18]
    // 0x613384: StoreField: r1->field_13 = r0
    //     0x613384: stur            w0, [x1, #0x13]
    //     0x613388: ldurb           w16, [x1, #-1]
    //     0x61338c: ldurb           w17, [x0, #-1]
    //     0x613390: and             x16, x17, x16, lsr #2
    //     0x613394: tst             x16, HEAP, lsr #32
    //     0x613398: b.eq            #0x6133a0
    //     0x61339c: bl              #0xd6826c
    // 0x6133a0: SaveReg r1
    //     0x6133a0: str             x1, [SP, #-8]!
    // 0x6133a4: r0 = _updateTickerModeNotifier()
    //     0x6133a4: bl              #0x6134c0  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x6133a8: add             SP, SP, #8
    // 0x6133ac: ldr             x16, [fp, #0x18]
    // 0x6133b0: SaveReg r16
    //     0x6133b0: str             x16, [SP, #-8]!
    // 0x6133b4: r0 = _updateTicker()
    //     0x6133b4: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x6133b8: add             SP, SP, #8
    // 0x6133bc: ldr             x1, [fp, #0x18]
    // 0x6133c0: LoadField: r0 = r1->field_13
    //     0x6133c0: ldur            w0, [x1, #0x13]
    // 0x6133c4: DecompressPointer r0
    //     0x6133c4: add             x0, x0, HEAP, lsl #32
    // 0x6133c8: cmp             w0, NULL
    // 0x6133cc: b.eq            #0x6133e4
    // 0x6133d0: LeaveFrame
    //     0x6133d0: mov             SP, fp
    //     0x6133d4: ldp             fp, lr, [SP], #0x10
    // 0x6133d8: ret
    //     0x6133d8: ret             
    // 0x6133dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6133dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6133e0: b               #0x613364
    // 0x6133e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6133e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTicker(/* No info */) {
    // ** addr: 0x61340c, size: 0x6c
    // 0x61340c: EnterFrame
    //     0x61340c: stp             fp, lr, [SP, #-0x10]!
    //     0x613410: mov             fp, SP
    // 0x613414: CheckStackOverflow
    //     0x613414: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613418: cmp             SP, x16
    //     0x61341c: b.ls            #0x61346c
    // 0x613420: ldr             x0, [fp, #0x10]
    // 0x613424: LoadField: r1 = r0->field_13
    //     0x613424: ldur            w1, [x0, #0x13]
    // 0x613428: DecompressPointer r1
    //     0x613428: add             x1, x1, HEAP, lsl #32
    // 0x61342c: cmp             w1, NULL
    // 0x613430: b.eq            #0x61345c
    // 0x613434: LoadField: r2 = r0->field_17
    //     0x613434: ldur            w2, [x0, #0x17]
    // 0x613438: DecompressPointer r2
    //     0x613438: add             x2, x2, HEAP, lsl #32
    // 0x61343c: cmp             w2, NULL
    // 0x613440: b.eq            #0x613474
    // 0x613444: LoadField: r0 = r2->field_27
    //     0x613444: ldur            w0, [x2, #0x27]
    // 0x613448: DecompressPointer r0
    //     0x613448: add             x0, x0, HEAP, lsl #32
    // 0x61344c: eor             x2, x0, #0x10
    // 0x613450: stp             x2, x1, [SP, #-0x10]!
    // 0x613454: r0 = muted=()
    //     0x613454: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x613458: add             SP, SP, #0x10
    // 0x61345c: r0 = Null
    //     0x61345c: mov             x0, NULL
    // 0x613460: LeaveFrame
    //     0x613460: mov             SP, fp
    //     0x613464: ldp             fp, lr, [SP], #0x10
    // 0x613468: ret
    //     0x613468: ret             
    // 0x61346c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61346c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613470: b               #0x613420
    // 0x613474: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x613474: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x613478, size: 0x48
    // 0x613478: EnterFrame
    //     0x613478: stp             fp, lr, [SP, #-0x10]!
    //     0x61347c: mov             fp, SP
    // 0x613480: ldr             x0, [fp, #0x10]
    // 0x613484: LoadField: r1 = r0->field_17
    //     0x613484: ldur            w1, [x0, #0x17]
    // 0x613488: DecompressPointer r1
    //     0x613488: add             x1, x1, HEAP, lsl #32
    // 0x61348c: CheckStackOverflow
    //     0x61348c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613490: cmp             SP, x16
    //     0x613494: b.ls            #0x6134b8
    // 0x613498: LoadField: r0 = r1->field_f
    //     0x613498: ldur            w0, [x1, #0xf]
    // 0x61349c: DecompressPointer r0
    //     0x61349c: add             x0, x0, HEAP, lsl #32
    // 0x6134a0: SaveReg r0
    //     0x6134a0: str             x0, [SP, #-8]!
    // 0x6134a4: r0 = _updateTicker()
    //     0x6134a4: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x6134a8: add             SP, SP, #8
    // 0x6134ac: LeaveFrame
    //     0x6134ac: mov             SP, fp
    //     0x6134b0: ldp             fp, lr, [SP], #0x10
    // 0x6134b4: ret
    //     0x6134b4: ret             
    // 0x6134b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6134b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6134bc: b               #0x613498
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x6134c0, size: 0x11c
    // 0x6134c0: EnterFrame
    //     0x6134c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6134c4: mov             fp, SP
    // 0x6134c8: AllocStack(0x10)
    //     0x6134c8: sub             SP, SP, #0x10
    // 0x6134cc: CheckStackOverflow
    //     0x6134cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6134d0: cmp             SP, x16
    //     0x6134d4: b.ls            #0x6135d0
    // 0x6134d8: ldr             x0, [fp, #0x10]
    // 0x6134dc: LoadField: r1 = r0->field_f
    //     0x6134dc: ldur            w1, [x0, #0xf]
    // 0x6134e0: DecompressPointer r1
    //     0x6134e0: add             x1, x1, HEAP, lsl #32
    // 0x6134e4: cmp             w1, NULL
    // 0x6134e8: b.eq            #0x6135d8
    // 0x6134ec: SaveReg r1
    //     0x6134ec: str             x1, [SP, #-8]!
    // 0x6134f0: r0 = getNotifier()
    //     0x6134f0: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x6134f4: add             SP, SP, #8
    // 0x6134f8: mov             x1, x0
    // 0x6134fc: ldr             x0, [fp, #0x10]
    // 0x613500: stur            x1, [fp, #-0x10]
    // 0x613504: LoadField: r2 = r0->field_17
    //     0x613504: ldur            w2, [x0, #0x17]
    // 0x613508: DecompressPointer r2
    //     0x613508: add             x2, x2, HEAP, lsl #32
    // 0x61350c: stur            x2, [fp, #-8]
    // 0x613510: cmp             w1, w2
    // 0x613514: b.ne            #0x613528
    // 0x613518: r0 = Null
    //     0x613518: mov             x0, NULL
    // 0x61351c: LeaveFrame
    //     0x61351c: mov             SP, fp
    //     0x613520: ldp             fp, lr, [SP], #0x10
    // 0x613524: ret
    //     0x613524: ret             
    // 0x613528: cmp             w2, NULL
    // 0x61352c: b.eq            #0x613568
    // 0x613530: r1 = 1
    //     0x613530: mov             x1, #1
    // 0x613534: r0 = AllocateContext()
    //     0x613534: bl              #0xd68aa4  ; AllocateContextStub
    // 0x613538: mov             x1, x0
    // 0x61353c: ldr             x0, [fp, #0x10]
    // 0x613540: StoreField: r1->field_f = r0
    //     0x613540: stur            w0, [x1, #0xf]
    // 0x613544: mov             x2, x1
    // 0x613548: r1 = Function '_updateTicker@156311458':.
    //     0x613548: add             x1, PP, #0x53, lsl #12  ; [pp+0x539c0] AnonymousClosure: (0x613478), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x61354c: ldr             x1, [x1, #0x9c0]
    // 0x613550: r0 = AllocateClosure()
    //     0x613550: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x613554: ldur            x16, [fp, #-8]
    // 0x613558: stp             x0, x16, [SP, #-0x10]!
    // 0x61355c: r0 = removeListener()
    //     0x61355c: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x613560: add             SP, SP, #0x10
    // 0x613564: ldr             x0, [fp, #0x10]
    // 0x613568: r1 = 1
    //     0x613568: mov             x1, #1
    // 0x61356c: r0 = AllocateContext()
    //     0x61356c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x613570: mov             x1, x0
    // 0x613574: ldr             x0, [fp, #0x10]
    // 0x613578: StoreField: r1->field_f = r0
    //     0x613578: stur            w0, [x1, #0xf]
    // 0x61357c: mov             x2, x1
    // 0x613580: r1 = Function '_updateTicker@156311458':.
    //     0x613580: add             x1, PP, #0x53, lsl #12  ; [pp+0x539c0] AnonymousClosure: (0x613478), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x613584: ldr             x1, [x1, #0x9c0]
    // 0x613588: r0 = AllocateClosure()
    //     0x613588: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x61358c: ldur            x16, [fp, #-0x10]
    // 0x613590: stp             x0, x16, [SP, #-0x10]!
    // 0x613594: r0 = addListener()
    //     0x613594: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x613598: add             SP, SP, #0x10
    // 0x61359c: ldur            x0, [fp, #-0x10]
    // 0x6135a0: ldr             x1, [fp, #0x10]
    // 0x6135a4: StoreField: r1->field_17 = r0
    //     0x6135a4: stur            w0, [x1, #0x17]
    //     0x6135a8: ldurb           w16, [x1, #-1]
    //     0x6135ac: ldurb           w17, [x0, #-1]
    //     0x6135b0: and             x16, x17, x16, lsr #2
    //     0x6135b4: tst             x16, HEAP, lsr #32
    //     0x6135b8: b.eq            #0x6135c0
    //     0x6135bc: bl              #0xd6826c
    // 0x6135c0: r0 = Null
    //     0x6135c0: mov             x0, NULL
    // 0x6135c4: LeaveFrame
    //     0x6135c4: mov             SP, fp
    //     0x6135c8: ldp             fp, lr, [SP], #0x10
    // 0x6135cc: ret
    //     0x6135cc: ret             
    // 0x6135d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6135d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6135d4: b               #0x6134d8
    // 0x6135d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6135d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ activate(/* No info */) {
    // ** addr: 0x81ee6c, size: 0x4c
    // 0x81ee6c: EnterFrame
    //     0x81ee6c: stp             fp, lr, [SP, #-0x10]!
    //     0x81ee70: mov             fp, SP
    // 0x81ee74: CheckStackOverflow
    //     0x81ee74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81ee78: cmp             SP, x16
    //     0x81ee7c: b.ls            #0x81eeb0
    // 0x81ee80: ldr             x16, [fp, #0x10]
    // 0x81ee84: SaveReg r16
    //     0x81ee84: str             x16, [SP, #-8]!
    // 0x81ee88: r0 = _updateTickerModeNotifier()
    //     0x81ee88: bl              #0x6134c0  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81ee8c: add             SP, SP, #8
    // 0x81ee90: ldr             x16, [fp, #0x10]
    // 0x81ee94: SaveReg r16
    //     0x81ee94: str             x16, [SP, #-8]!
    // 0x81ee98: r0 = _updateTicker()
    //     0x81ee98: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81ee9c: add             SP, SP, #8
    // 0x81eea0: r0 = Null
    //     0x81eea0: mov             x0, NULL
    // 0x81eea4: LeaveFrame
    //     0x81eea4: mov             SP, fp
    //     0x81eea8: ldp             fp, lr, [SP], #0x10
    // 0x81eeac: ret
    //     0x81eeac: ret             
    // 0x81eeb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81eeb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81eeb4: b               #0x81ee80
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4e96c, size: 0x8c
    // 0xa4e96c: EnterFrame
    //     0xa4e96c: stp             fp, lr, [SP, #-0x10]!
    //     0xa4e970: mov             fp, SP
    // 0xa4e974: AllocStack(0x8)
    //     0xa4e974: sub             SP, SP, #8
    // 0xa4e978: CheckStackOverflow
    //     0xa4e978: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4e97c: cmp             SP, x16
    //     0xa4e980: b.ls            #0xa4e9f0
    // 0xa4e984: ldr             x0, [fp, #0x10]
    // 0xa4e988: LoadField: r1 = r0->field_17
    //     0xa4e988: ldur            w1, [x0, #0x17]
    // 0xa4e98c: DecompressPointer r1
    //     0xa4e98c: add             x1, x1, HEAP, lsl #32
    // 0xa4e990: stur            x1, [fp, #-8]
    // 0xa4e994: cmp             w1, NULL
    // 0xa4e998: b.ne            #0xa4e9a4
    // 0xa4e99c: mov             x1, x0
    // 0xa4e9a0: b               #0xa4e9dc
    // 0xa4e9a4: r1 = 1
    //     0xa4e9a4: mov             x1, #1
    // 0xa4e9a8: r0 = AllocateContext()
    //     0xa4e9a8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4e9ac: mov             x1, x0
    // 0xa4e9b0: ldr             x0, [fp, #0x10]
    // 0xa4e9b4: StoreField: r1->field_f = r0
    //     0xa4e9b4: stur            w0, [x1, #0xf]
    // 0xa4e9b8: mov             x2, x1
    // 0xa4e9bc: r1 = Function '_updateTicker@156311458':.
    //     0xa4e9bc: add             x1, PP, #0x53, lsl #12  ; [pp+0x539c0] AnonymousClosure: (0x613478), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa4e9c0: ldr             x1, [x1, #0x9c0]
    // 0xa4e9c4: r0 = AllocateClosure()
    //     0xa4e9c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4e9c8: ldur            x16, [fp, #-8]
    // 0xa4e9cc: stp             x0, x16, [SP, #-0x10]!
    // 0xa4e9d0: r0 = removeListener()
    //     0xa4e9d0: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4e9d4: add             SP, SP, #0x10
    // 0xa4e9d8: ldr             x1, [fp, #0x10]
    // 0xa4e9dc: StoreField: r1->field_17 = rNULL
    //     0xa4e9dc: stur            NULL, [x1, #0x17]
    // 0xa4e9e0: r0 = Null
    //     0xa4e9e0: mov             x0, NULL
    // 0xa4e9e4: LeaveFrame
    //     0xa4e9e4: mov             SP, fp
    //     0xa4e9e8: ldp             fp, lr, [SP], #0x10
    // 0xa4e9ec: ret
    //     0xa4e9ec: ret             
    // 0xa4e9f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4e9f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4e9f4: b               #0xa4e984
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4e9f8, size: 0x48
    // 0xa4e9f8: EnterFrame
    //     0xa4e9f8: stp             fp, lr, [SP, #-0x10]!
    //     0xa4e9fc: mov             fp, SP
    // 0xa4ea00: ldr             x0, [fp, #0x10]
    // 0xa4ea04: LoadField: r1 = r0->field_17
    //     0xa4ea04: ldur            w1, [x0, #0x17]
    // 0xa4ea08: DecompressPointer r1
    //     0xa4ea08: add             x1, x1, HEAP, lsl #32
    // 0xa4ea0c: CheckStackOverflow
    //     0xa4ea0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4ea10: cmp             SP, x16
    //     0xa4ea14: b.ls            #0xa4ea38
    // 0xa4ea18: LoadField: r0 = r1->field_f
    //     0xa4ea18: ldur            w0, [x1, #0xf]
    // 0xa4ea1c: DecompressPointer r0
    //     0xa4ea1c: add             x0, x0, HEAP, lsl #32
    // 0xa4ea20: SaveReg r0
    //     0xa4ea20: str             x0, [SP, #-8]!
    // 0xa4ea24: r0 = dispose()
    //     0xa4ea24: bl              #0xa4e96c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::dispose
    // 0xa4ea28: add             SP, SP, #8
    // 0xa4ea2c: LeaveFrame
    //     0xa4ea2c: mov             SP, fp
    //     0xa4ea30: ldp             fp, lr, [SP], #0x10
    // 0xa4ea34: ret
    //     0xa4ea34: ret             
    // 0xa4ea38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4ea38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4ea3c: b               #0xa4ea18
  }
}

// class id: 3407, size: 0x20, field offset: 0x1c
//   transformed mixin,
abstract class __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin&SkinToneOverlayStateMixin extends __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin
     with SkinToneOverlayStateMixin<X0 bound StatefulWidget> {

  _ closeSkinToneOverlay(/* No info */) {
    // ** addr: 0x825644, size: 0x5c
    // 0x825644: EnterFrame
    //     0x825644: stp             fp, lr, [SP, #-0x10]!
    //     0x825648: mov             fp, SP
    // 0x82564c: CheckStackOverflow
    //     0x82564c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x825650: cmp             SP, x16
    //     0x825654: b.ls            #0x825698
    // 0x825658: ldr             x0, [fp, #0x10]
    // 0x82565c: LoadField: r1 = r0->field_1b
    //     0x82565c: ldur            w1, [x0, #0x1b]
    // 0x825660: DecompressPointer r1
    //     0x825660: add             x1, x1, HEAP, lsl #32
    // 0x825664: cmp             w1, NULL
    // 0x825668: b.ne            #0x825674
    // 0x82566c: mov             x1, x0
    // 0x825670: b               #0x825684
    // 0x825674: SaveReg r1
    //     0x825674: str             x1, [SP, #-8]!
    // 0x825678: r0 = remove()
    //     0x825678: bl              #0x511c50  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::remove
    // 0x82567c: add             SP, SP, #8
    // 0x825680: ldr             x1, [fp, #0x10]
    // 0x825684: StoreField: r1->field_1b = rNULL
    //     0x825684: stur            NULL, [x1, #0x1b]
    // 0x825688: r0 = Null
    //     0x825688: mov             x0, NULL
    // 0x82568c: LeaveFrame
    //     0x82568c: mov             SP, fp
    //     0x825690: ldp             fp, lr, [SP], #0x10
    // 0x825694: ret
    //     0x825694: ret             
    // 0x825698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x825698: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82569c: b               #0x825658
  }
  [closure] void closeSkinToneOverlay(dynamic) {
    // ** addr: 0x8256a0, size: 0x48
    // 0x8256a0: EnterFrame
    //     0x8256a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8256a4: mov             fp, SP
    // 0x8256a8: ldr             x0, [fp, #0x10]
    // 0x8256ac: LoadField: r1 = r0->field_17
    //     0x8256ac: ldur            w1, [x0, #0x17]
    // 0x8256b0: DecompressPointer r1
    //     0x8256b0: add             x1, x1, HEAP, lsl #32
    // 0x8256b4: CheckStackOverflow
    //     0x8256b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8256b8: cmp             SP, x16
    //     0x8256bc: b.ls            #0x8256e0
    // 0x8256c0: LoadField: r0 = r1->field_f
    //     0x8256c0: ldur            w0, [x1, #0xf]
    // 0x8256c4: DecompressPointer r0
    //     0x8256c4: add             x0, x0, HEAP, lsl #32
    // 0x8256c8: SaveReg r0
    //     0x8256c8: str             x0, [SP, #-8]!
    // 0x8256cc: r0 = closeSkinToneOverlay()
    //     0x8256cc: bl              #0x825644  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin&SkinToneOverlayStateMixin::closeSkinToneOverlay
    // 0x8256d0: add             SP, SP, #8
    // 0x8256d4: LeaveFrame
    //     0x8256d4: mov             SP, fp
    //     0x8256d8: ldp             fp, lr, [SP], #0x10
    // 0x8256dc: ret
    //     0x8256dc: ret             
    // 0x8256e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8256e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8256e4: b               #0x8256c0
  }
}

// class id: 3408, size: 0x38, field offset: 0x20
class _DefaultEmojiPickerViewState extends __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin&SkinToneOverlayStateMixin {

  late PageController _pageController; // offset: 0x28
  late final ScrollController _scrollController; // offset: 0x30
  late TabController _tabController; // offset: 0x2c

  _ build(/* No info */) {
    // ** addr: 0x824c3c, size: 0x54
    // 0x824c3c: EnterFrame
    //     0x824c3c: stp             fp, lr, [SP, #-0x10]!
    //     0x824c40: mov             fp, SP
    // 0x824c44: AllocStack(0x8)
    //     0x824c44: sub             SP, SP, #8
    // 0x824c48: r1 = 1
    //     0x824c48: mov             x1, #1
    // 0x824c4c: r0 = AllocateContext()
    //     0x824c4c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x824c50: mov             x1, x0
    // 0x824c54: ldr             x0, [fp, #0x18]
    // 0x824c58: StoreField: r1->field_f = r0
    //     0x824c58: stur            w0, [x1, #0xf]
    // 0x824c5c: mov             x2, x1
    // 0x824c60: r1 = Function '<anonymous closure>':.
    //     0x824c60: add             x1, PP, #0x53, lsl #12  ; [pp+0x539d0] AnonymousClosure: (0x824c9c), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::build (0x824c3c)
    //     0x824c64: ldr             x1, [x1, #0x9d0]
    // 0x824c68: r0 = AllocateClosure()
    //     0x824c68: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x824c6c: r1 = <BoxConstraints>
    //     0x824c6c: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f420] TypeArguments: <BoxConstraints>
    //     0x824c70: ldr             x1, [x1, #0x420]
    // 0x824c74: stur            x0, [fp, #-8]
    // 0x824c78: r0 = LayoutBuilder()
    //     0x824c78: bl              #0x824c90  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0x824c7c: ldur            x1, [fp, #-8]
    // 0x824c80: StoreField: r0->field_f = r1
    //     0x824c80: stur            w1, [x0, #0xf]
    // 0x824c84: LeaveFrame
    //     0x824c84: mov             SP, fp
    //     0x824c88: ldp             fp, lr, [SP], #0x10
    // 0x824c8c: ret
    //     0x824c8c: ret             
  }
  [closure] EmojiContainer <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0x824c9c, size: 0x420
    // 0x824c9c: EnterFrame
    //     0x824c9c: stp             fp, lr, [SP, #-0x10]!
    //     0x824ca0: mov             fp, SP
    // 0x824ca4: AllocStack(0x40)
    //     0x824ca4: sub             SP, SP, #0x40
    // 0x824ca8: SetupParameters()
    //     0x824ca8: ldr             x0, [fp, #0x20]
    //     0x824cac: ldur            w1, [x0, #0x17]
    //     0x824cb0: add             x1, x1, HEAP, lsl #32
    //     0x824cb4: stur            x1, [fp, #-8]
    // 0x824cb8: CheckStackOverflow
    //     0x824cb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x824cbc: cmp             SP, x16
    //     0x824cc0: b.ls            #0x825068
    // 0x824cc4: r1 = 1
    //     0x824cc4: mov             x1, #1
    // 0x824cc8: r0 = AllocateContext()
    //     0x824cc8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x824ccc: mov             x1, x0
    // 0x824cd0: ldur            x0, [fp, #-8]
    // 0x824cd4: stur            x1, [fp, #-0x10]
    // 0x824cd8: StoreField: r1->field_b = r0
    //     0x824cd8: stur            w0, [x1, #0xb]
    // 0x824cdc: LoadField: r2 = r0->field_f
    //     0x824cdc: ldur            w2, [x0, #0xf]
    // 0x824ce0: DecompressPointer r2
    //     0x824ce0: add             x2, x2, HEAP, lsl #32
    // 0x824ce4: LoadField: r3 = r2->field_b
    //     0x824ce4: ldur            w3, [x2, #0xb]
    // 0x824ce8: DecompressPointer r3
    //     0x824ce8: add             x3, x3, HEAP, lsl #32
    // 0x824cec: cmp             w3, NULL
    // 0x824cf0: b.eq            #0x825070
    // 0x824cf4: ldr             x2, [fp, #0x10]
    // 0x824cf8: LoadField: d0 = r2->field_f
    //     0x824cf8: ldur            d0, [x2, #0xf]
    // 0x824cfc: d1 = 8.000000
    //     0x824cfc: fmov            d1, #8.00000000
    // 0x824d00: fdiv            d2, d0, d1
    // 0x824d04: stur            d2, [fp, #-0x40]
    // 0x824d08: r2 = Instance_Config
    //     0x824d08: add             x2, PP, #0x32, lsl #12  ; [pp+0x32b10] Obj!Config@b5c6a1
    //     0x824d0c: ldr             x2, [x2, #0xb10]
    // 0x824d10: LoadField: d0 = r2->field_f
    //     0x824d10: ldur            d0, [x2, #0xf]
    // 0x824d14: stur            d0, [fp, #-0x38]
    // 0x824d18: fcmp            d2, d0
    // 0x824d1c: b.vs            #0x824d30
    // 0x824d20: b.le            #0x824d30
    // 0x824d24: mov             x2, x1
    // 0x824d28: mov             x1, x0
    // 0x824d2c: b               #0x824de0
    // 0x824d30: fcmp            d2, d0
    // 0x824d34: b.vs            #0x824d4c
    // 0x824d38: b.ge            #0x824d4c
    // 0x824d3c: mov             v0.16b, v2.16b
    // 0x824d40: mov             x2, x1
    // 0x824d44: mov             x1, x0
    // 0x824d48: b               #0x824de0
    // 0x824d4c: d1 = 0.000000
    //     0x824d4c: eor             v1.16b, v1.16b, v1.16b
    // 0x824d50: fcmp            d2, d1
    // 0x824d54: b.vs            #0x824d5c
    // 0x824d58: b.eq            #0x824d64
    // 0x824d5c: r2 = false
    //     0x824d5c: add             x2, NULL, #0x30  ; false
    // 0x824d60: b               #0x824d68
    // 0x824d64: r2 = true
    //     0x824d64: add             x2, NULL, #0x20  ; true
    // 0x824d68: tbnz            w2, #4, #0x824d88
    // 0x824d6c: fadd            d1, d2, d0
    // 0x824d70: fmul            d3, d1, d2
    // 0x824d74: fmul            d1, d3, d0
    // 0x824d78: mov             v0.16b, v1.16b
    // 0x824d7c: mov             x2, x1
    // 0x824d80: mov             x1, x0
    // 0x824d84: b               #0x824de0
    // 0x824d88: tbnz            w2, #4, #0x824dd4
    // 0x824d8c: r2 = inline_Allocate_Double()
    //     0x824d8c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x824d90: add             x2, x2, #0x10
    //     0x824d94: cmp             x3, x2
    //     0x824d98: b.ls            #0x825074
    //     0x824d9c: str             x2, [THR, #0x60]  ; THR::top
    //     0x824da0: sub             x2, x2, #0xf
    //     0x824da4: mov             x3, #0xd108
    //     0x824da8: movk            x3, #3, lsl #16
    //     0x824dac: stur            x3, [x2, #-1]
    // 0x824db0: StoreField: r2->field_7 = d0
    //     0x824db0: stur            d0, [x2, #7]
    // 0x824db4: SaveReg r2
    //     0x824db4: str             x2, [SP, #-8]!
    // 0x824db8: r0 = isNegative()
    //     0x824db8: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x824dbc: add             SP, SP, #8
    // 0x824dc0: tbnz            w0, #4, #0x824dd4
    // 0x824dc4: ldur            d0, [fp, #-0x38]
    // 0x824dc8: ldur            x1, [fp, #-8]
    // 0x824dcc: ldur            x2, [fp, #-0x10]
    // 0x824dd0: b               #0x824de0
    // 0x824dd4: ldur            d0, [fp, #-0x40]
    // 0x824dd8: ldur            x1, [fp, #-8]
    // 0x824ddc: ldur            x2, [fp, #-0x10]
    // 0x824de0: r0 = inline_Allocate_Double()
    //     0x824de0: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x824de4: add             x0, x0, #0x10
    //     0x824de8: cmp             x3, x0
    //     0x824dec: b.ls            #0x825090
    //     0x824df0: str             x0, [THR, #0x60]  ; THR::top
    //     0x824df4: sub             x0, x0, #0xf
    //     0x824df8: mov             x3, #0xd108
    //     0x824dfc: movk            x3, #3, lsl #16
    //     0x824e00: stur            x3, [x0, #-1]
    // 0x824e04: StoreField: r0->field_7 = d0
    //     0x824e04: stur            d0, [x0, #7]
    // 0x824e08: StoreField: r2->field_f = r0
    //     0x824e08: stur            w0, [x2, #0xf]
    //     0x824e0c: ldurb           w16, [x2, #-1]
    //     0x824e10: ldurb           w17, [x0, #-1]
    //     0x824e14: and             x16, x17, x16, lsr #2
    //     0x824e18: tst             x16, HEAP, lsr #32
    //     0x824e1c: b.eq            #0x824e24
    //     0x824e20: bl              #0xd6828c
    // 0x824e24: LoadField: r0 = r1->field_f
    //     0x824e24: ldur            w0, [x1, #0xf]
    // 0x824e28: DecompressPointer r0
    //     0x824e28: add             x0, x0, HEAP, lsl #32
    // 0x824e2c: LoadField: r3 = r0->field_b
    //     0x824e2c: ldur            w3, [x0, #0xb]
    // 0x824e30: DecompressPointer r3
    //     0x824e30: add             x3, x3, HEAP, lsl #32
    // 0x824e34: cmp             w3, NULL
    // 0x824e38: b.eq            #0x8250a8
    // 0x824e3c: SaveReg r0
    //     0x824e3c: str             x0, [SP, #-8]!
    // 0x824e40: r0 = _buildTabBar()
    //     0x824e40: bl              #0x825410  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_buildTabBar
    // 0x824e44: add             SP, SP, #8
    // 0x824e48: r1 = <FlexParentData<RenderBox>>
    //     0x824e48: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f2f8] TypeArguments: <FlexParentData<RenderBox>>
    //     0x824e4c: ldr             x1, [x1, #0x2f8]
    // 0x824e50: stur            x0, [fp, #-0x18]
    // 0x824e54: r0 = Expanded()
    //     0x824e54: bl              #0x825404  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x824e58: mov             x1, x0
    // 0x824e5c: r0 = 1
    //     0x824e5c: mov             x0, #1
    // 0x824e60: stur            x1, [fp, #-0x20]
    // 0x824e64: StoreField: r1->field_13 = r0
    //     0x824e64: stur            x0, [x1, #0x13]
    // 0x824e68: r2 = Instance_FlexFit
    //     0x824e68: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d2e8] Obj!FlexFit@b64b91
    //     0x824e6c: ldr             x2, [x2, #0x2e8]
    // 0x824e70: StoreField: r1->field_1b = r2
    //     0x824e70: stur            w2, [x1, #0x1b]
    // 0x824e74: ldur            x2, [fp, #-0x18]
    // 0x824e78: StoreField: r1->field_b = r2
    //     0x824e78: stur            w2, [x1, #0xb]
    // 0x824e7c: ldur            x2, [fp, #-8]
    // 0x824e80: LoadField: r3 = r2->field_f
    //     0x824e80: ldur            w3, [x2, #0xf]
    // 0x824e84: DecompressPointer r3
    //     0x824e84: add             x3, x3, HEAP, lsl #32
    // 0x824e88: SaveReg r3
    //     0x824e88: str             x3, [SP, #-8]!
    // 0x824e8c: r0 = _buildBackspaceButton()
    //     0x824e8c: bl              #0x82524c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_buildBackspaceButton
    // 0x824e90: add             SP, SP, #8
    // 0x824e94: r1 = Null
    //     0x824e94: mov             x1, NULL
    // 0x824e98: r2 = 4
    //     0x824e98: mov             x2, #4
    // 0x824e9c: stur            x0, [fp, #-0x18]
    // 0x824ea0: r0 = AllocateArray()
    //     0x824ea0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x824ea4: mov             x2, x0
    // 0x824ea8: ldur            x0, [fp, #-0x20]
    // 0x824eac: stur            x2, [fp, #-0x28]
    // 0x824eb0: StoreField: r2->field_f = r0
    //     0x824eb0: stur            w0, [x2, #0xf]
    // 0x824eb4: ldur            x0, [fp, #-0x18]
    // 0x824eb8: StoreField: r2->field_13 = r0
    //     0x824eb8: stur            w0, [x2, #0x13]
    // 0x824ebc: r1 = <Widget>
    //     0x824ebc: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x824ec0: ldr             x1, [x1, #0xea8]
    // 0x824ec4: r0 = AllocateGrowableArray()
    //     0x824ec4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x824ec8: mov             x1, x0
    // 0x824ecc: ldur            x0, [fp, #-0x28]
    // 0x824ed0: stur            x1, [fp, #-0x18]
    // 0x824ed4: StoreField: r1->field_f = r0
    //     0x824ed4: stur            w0, [x1, #0xf]
    // 0x824ed8: r2 = 4
    //     0x824ed8: mov             x2, #4
    // 0x824edc: StoreField: r1->field_b = r2
    //     0x824edc: stur            w2, [x1, #0xb]
    // 0x824ee0: r0 = Row()
    //     0x824ee0: bl              #0x8236c8  ; AllocateRowStub -> Row (size=0x30)
    // 0x824ee4: stur            x0, [fp, #-0x20]
    // 0x824ee8: ldur            x16, [fp, #-0x18]
    // 0x824eec: stp             x16, x0, [SP, #-0x10]!
    // 0x824ef0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x824ef0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x824ef4: r0 = Row()
    //     0x824ef4: bl              #0x8232c8  ; [package:flutter/src/widgets/basic.dart] Row::Row
    // 0x824ef8: add             SP, SP, #0x10
    // 0x824efc: ldur            x0, [fp, #-8]
    // 0x824f00: LoadField: r1 = r0->field_f
    //     0x824f00: ldur            w1, [x0, #0xf]
    // 0x824f04: DecompressPointer r1
    //     0x824f04: add             x1, x1, HEAP, lsl #32
    // 0x824f08: LoadField: r0 = r1->field_b
    //     0x824f08: ldur            w0, [x1, #0xb]
    // 0x824f0c: DecompressPointer r0
    //     0x824f0c: add             x0, x0, HEAP, lsl #32
    // 0x824f10: cmp             w0, NULL
    // 0x824f14: b.eq            #0x8250ac
    // 0x824f18: LoadField: r2 = r0->field_f
    //     0x824f18: ldur            w2, [x0, #0xf]
    // 0x824f1c: DecompressPointer r2
    //     0x824f1c: add             x2, x2, HEAP, lsl #32
    // 0x824f20: LoadField: r0 = r2->field_7
    //     0x824f20: ldur            w0, [x2, #7]
    // 0x824f24: DecompressPointer r0
    //     0x824f24: add             x0, x0, HEAP, lsl #32
    // 0x824f28: LoadField: r3 = r0->field_b
    //     0x824f28: ldur            w3, [x0, #0xb]
    // 0x824f2c: DecompressPointer r3
    //     0x824f2c: add             x3, x3, HEAP, lsl #32
    // 0x824f30: stur            x3, [fp, #-0x18]
    // 0x824f34: LoadField: r0 = r1->field_27
    //     0x824f34: ldur            w0, [x1, #0x27]
    // 0x824f38: DecompressPointer r0
    //     0x824f38: add             x0, x0, HEAP, lsl #32
    // 0x824f3c: r16 = Sentinel
    //     0x824f3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x824f40: cmp             w0, w16
    // 0x824f44: b.eq            #0x8250b0
    // 0x824f48: ldur            x2, [fp, #-0x10]
    // 0x824f4c: stur            x0, [fp, #-8]
    // 0x824f50: r1 = Function '<anonymous closure>':.
    //     0x824f50: add             x1, PP, #0x53, lsl #12  ; [pp+0x539d8] AnonymousClosure: (0x82621c), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::build (0x824c3c)
    //     0x824f54: ldr             x1, [x1, #0x9d8]
    // 0x824f58: r0 = AllocateClosure()
    //     0x824f58: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x824f5c: ldur            x2, [fp, #-0x10]
    // 0x824f60: r1 = Function '<anonymous closure>':.
    //     0x824f60: add             x1, PP, #0x53, lsl #12  ; [pp+0x539e0] AnonymousClosure: (0x82595c), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::build (0x824c3c)
    //     0x824f64: ldr             x1, [x1, #0x9e0]
    // 0x824f68: stur            x0, [fp, #-0x10]
    // 0x824f6c: r0 = AllocateClosure()
    //     0x824f6c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x824f70: stur            x0, [fp, #-0x28]
    // 0x824f74: r0 = PageView()
    //     0x824f74: bl              #0x8243b8  ; AllocatePageViewStub -> PageView (size=0x40)
    // 0x824f78: stur            x0, [fp, #-0x30]
    // 0x824f7c: ldur            x16, [fp, #-8]
    // 0x824f80: stp             x16, x0, [SP, #-0x10]!
    // 0x824f84: ldur            x16, [fp, #-0x28]
    // 0x824f88: ldur            lr, [fp, #-0x18]
    // 0x824f8c: stp             lr, x16, [SP, #-0x10]!
    // 0x824f90: ldur            x16, [fp, #-0x10]
    // 0x824f94: SaveReg r16
    //     0x824f94: str             x16, [SP, #-8]!
    // 0x824f98: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x824f98: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x824f9c: r0 = PageView.builder()
    //     0x824f9c: bl              #0x8240d8  ; [package:flutter/src/widgets/page_view.dart] PageView::PageView.builder
    // 0x824fa0: add             SP, SP, #0x28
    // 0x824fa4: r1 = <FlexParentData<RenderBox>>
    //     0x824fa4: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f2f8] TypeArguments: <FlexParentData<RenderBox>>
    //     0x824fa8: ldr             x1, [x1, #0x2f8]
    // 0x824fac: r0 = Flexible()
    //     0x824fac: bl              #0x825240  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x824fb0: mov             x3, x0
    // 0x824fb4: r0 = 1
    //     0x824fb4: mov             x0, #1
    // 0x824fb8: stur            x3, [fp, #-8]
    // 0x824fbc: StoreField: r3->field_13 = r0
    //     0x824fbc: stur            x0, [x3, #0x13]
    // 0x824fc0: r0 = Instance_FlexFit
    //     0x824fc0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c48] Obj!FlexFit@b64bb1
    //     0x824fc4: ldr             x0, [x0, #0xc48]
    // 0x824fc8: StoreField: r3->field_1b = r0
    //     0x824fc8: stur            w0, [x3, #0x1b]
    // 0x824fcc: ldur            x0, [fp, #-0x30]
    // 0x824fd0: StoreField: r3->field_b = r0
    //     0x824fd0: stur            w0, [x3, #0xb]
    // 0x824fd4: r1 = Null
    //     0x824fd4: mov             x1, NULL
    // 0x824fd8: r2 = 4
    //     0x824fd8: mov             x2, #4
    // 0x824fdc: r0 = AllocateArray()
    //     0x824fdc: bl              #0xd6987c  ; AllocateArrayStub
    // 0x824fe0: mov             x2, x0
    // 0x824fe4: ldur            x0, [fp, #-0x20]
    // 0x824fe8: stur            x2, [fp, #-0x10]
    // 0x824fec: StoreField: r2->field_f = r0
    //     0x824fec: stur            w0, [x2, #0xf]
    // 0x824ff0: ldur            x0, [fp, #-8]
    // 0x824ff4: StoreField: r2->field_13 = r0
    //     0x824ff4: stur            w0, [x2, #0x13]
    // 0x824ff8: r1 = <Widget>
    //     0x824ff8: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x824ffc: ldr             x1, [x1, #0xea8]
    // 0x825000: r0 = AllocateGrowableArray()
    //     0x825000: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x825004: mov             x1, x0
    // 0x825008: ldur            x0, [fp, #-0x10]
    // 0x82500c: stur            x1, [fp, #-8]
    // 0x825010: StoreField: r1->field_f = r0
    //     0x825010: stur            w0, [x1, #0xf]
    // 0x825014: r0 = 4
    //     0x825014: mov             x0, #4
    // 0x825018: StoreField: r1->field_b = r0
    //     0x825018: stur            w0, [x1, #0xb]
    // 0x82501c: r0 = Column()
    //     0x82501c: bl              #0x825234  ; AllocateColumnStub -> Column (size=0x30)
    // 0x825020: stur            x0, [fp, #-0x10]
    // 0x825024: ldur            x16, [fp, #-8]
    // 0x825028: stp             x16, x0, [SP, #-0x10]!
    // 0x82502c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x82502c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x825030: r0 = Column()
    //     0x825030: bl              #0x8250c8  ; [package:flutter/src/widgets/basic.dart] Column::Column
    // 0x825034: add             SP, SP, #0x10
    // 0x825038: r0 = EmojiContainer()
    //     0x825038: bl              #0x8250bc  ; AllocateEmojiContainerStub -> EmojiContainer (size=0x1c)
    // 0x82503c: r1 = Instance_Color
    //     0x82503c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x825040: ldr             x1, [x1, #0xf38]
    // 0x825044: StoreField: r0->field_b = r1
    //     0x825044: stur            w1, [x0, #0xb]
    // 0x825048: r1 = Instance_ButtonMode
    //     0x825048: add             x1, PP, #0x41, lsl #12  ; [pp+0x410a8] Obj!ButtonMode@b663d1
    //     0x82504c: ldr             x1, [x1, #0xa8]
    // 0x825050: StoreField: r0->field_f = r1
    //     0x825050: stur            w1, [x0, #0xf]
    // 0x825054: ldur            x1, [fp, #-0x10]
    // 0x825058: StoreField: r0->field_17 = r1
    //     0x825058: stur            w1, [x0, #0x17]
    // 0x82505c: LeaveFrame
    //     0x82505c: mov             SP, fp
    //     0x825060: ldp             fp, lr, [SP], #0x10
    // 0x825064: ret
    //     0x825064: ret             
    // 0x825068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x825068: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82506c: b               #0x824cc4
    // 0x825070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x825070: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x825074: stp             q0, q2, [SP, #-0x20]!
    // 0x825078: stp             x0, x1, [SP, #-0x10]!
    // 0x82507c: r0 = AllocateDouble()
    //     0x82507c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x825080: mov             x2, x0
    // 0x825084: ldp             x0, x1, [SP], #0x10
    // 0x825088: ldp             q0, q2, [SP], #0x20
    // 0x82508c: b               #0x824db0
    // 0x825090: SaveReg d0
    //     0x825090: str             q0, [SP, #-0x10]!
    // 0x825094: stp             x1, x2, [SP, #-0x10]!
    // 0x825098: r0 = AllocateDouble()
    //     0x825098: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82509c: ldp             x1, x2, [SP], #0x10
    // 0x8250a0: RestoreReg d0
    //     0x8250a0: ldr             q0, [SP], #0x10
    // 0x8250a4: b               #0x824e04
    // 0x8250a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8250a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8250ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8250ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8250b0: r9 = _pageController
    //     0x8250b0: add             x9, PP, #0x53, lsl #12  ; [pp+0x539e8] Field <_DefaultEmojiPickerViewState@394000349._pageController@394000349>: late (offset: 0x28)
    //     0x8250b4: ldr             x9, [x9, #0x9e8]
    // 0x8250b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8250b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildBackspaceButton(/* No info */) {
    // ** addr: 0x82524c, size: 0x118
    // 0x82524c: EnterFrame
    //     0x82524c: stp             fp, lr, [SP, #-0x10]!
    //     0x825250: mov             fp, SP
    // 0x825254: AllocStack(0x18)
    //     0x825254: sub             SP, SP, #0x18
    // 0x825258: r1 = 1
    //     0x825258: mov             x1, #1
    // 0x82525c: r0 = AllocateContext()
    //     0x82525c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x825260: mov             x1, x0
    // 0x825264: ldr             x0, [fp, #0x10]
    // 0x825268: stur            x1, [fp, #-8]
    // 0x82526c: StoreField: r1->field_f = r0
    //     0x82526c: stur            w0, [x1, #0xf]
    // 0x825270: LoadField: r2 = r0->field_b
    //     0x825270: ldur            w2, [x0, #0xb]
    // 0x825274: DecompressPointer r2
    //     0x825274: add             x2, x2, HEAP, lsl #32
    // 0x825278: cmp             w2, NULL
    // 0x82527c: b.eq            #0x825360
    // 0x825280: LoadField: r0 = r2->field_f
    //     0x825280: ldur            w0, [x2, #0xf]
    // 0x825284: DecompressPointer r0
    //     0x825284: add             x0, x0, HEAP, lsl #32
    // 0x825288: LoadField: r2 = r0->field_f
    //     0x825288: ldur            w2, [x0, #0xf]
    // 0x82528c: DecompressPointer r2
    //     0x82528c: add             x2, x2, HEAP, lsl #32
    // 0x825290: cmp             w2, NULL
    // 0x825294: b.eq            #0x82534c
    // 0x825298: r0 = Icon()
    //     0x825298: bl              #0x825370  ; AllocateIconStub -> Icon (size=0x34)
    // 0x82529c: mov             x1, x0
    // 0x8252a0: r0 = Instance_IconData
    //     0x8252a0: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a20] Obj!IconData@b33c11
    //     0x8252a4: ldr             x0, [x0, #0xa20]
    // 0x8252a8: stur            x1, [fp, #-0x10]
    // 0x8252ac: StoreField: r1->field_b = r0
    //     0x8252ac: stur            w0, [x1, #0xb]
    // 0x8252b0: r0 = Instance_MaterialColor
    //     0x8252b0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0x8252b4: ldr             x0, [x0, #0xf28]
    // 0x8252b8: StoreField: r1->field_23 = r0
    //     0x8252b8: stur            w0, [x1, #0x23]
    // 0x8252bc: r0 = IconButton()
    //     0x8252bc: bl              #0x825364  ; AllocateIconButtonStub -> IconButton (size=0x64)
    // 0x8252c0: mov             x3, x0
    // 0x8252c4: r0 = Instance_EdgeInsets
    //     0x8252c4: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a28] Obj!EdgeInsets@b35ba1
    //     0x8252c8: ldr             x0, [x0, #0xa28]
    // 0x8252cc: stur            x3, [fp, #-0x18]
    // 0x8252d0: StoreField: r3->field_13 = r0
    //     0x8252d0: stur            w0, [x3, #0x13]
    // 0x8252d4: ldur            x2, [fp, #-8]
    // 0x8252d8: r1 = Function '<anonymous closure>':.
    //     0x8252d8: add             x1, PP, #0x53, lsl #12  ; [pp+0x53a30] AnonymousClosure: (0x82537c), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_buildBackspaceButton (0x82524c)
    //     0x8252dc: ldr             x1, [x1, #0xa30]
    // 0x8252e0: r0 = AllocateClosure()
    //     0x8252e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8252e4: mov             x1, x0
    // 0x8252e8: ldur            x0, [fp, #-0x18]
    // 0x8252ec: StoreField: r0->field_3b = r1
    //     0x8252ec: stur            w1, [x0, #0x3b]
    // 0x8252f0: r1 = false
    //     0x8252f0: add             x1, NULL, #0x30  ; false
    // 0x8252f4: StoreField: r0->field_47 = r1
    //     0x8252f4: stur            w1, [x0, #0x47]
    // 0x8252f8: ldur            x1, [fp, #-0x10]
    // 0x8252fc: StoreField: r0->field_1f = r1
    //     0x8252fc: stur            w1, [x0, #0x1f]
    // 0x825300: r0 = Material()
    //     0x825300: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0x825304: r1 = Instance_MaterialType
    //     0x825304: add             x1, PP, #0x15, lsl #12  ; [pp+0x152a8] Obj!MaterialType@b65511
    //     0x825308: ldr             x1, [x1, #0x2a8]
    // 0x82530c: StoreField: r0->field_f = r1
    //     0x82530c: stur            w1, [x0, #0xf]
    // 0x825310: d0 = 0.000000
    //     0x825310: eor             v0.16b, v0.16b, v0.16b
    // 0x825314: StoreField: r0->field_13 = d0
    //     0x825314: stur            d0, [x0, #0x13]
    // 0x825318: r1 = true
    //     0x825318: add             x1, NULL, #0x20  ; true
    // 0x82531c: StoreField: r0->field_2f = r1
    //     0x82531c: stur            w1, [x0, #0x2f]
    // 0x825320: r1 = Instance_Clip
    //     0x825320: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x825324: ldr             x1, [x1, #0xb38]
    // 0x825328: StoreField: r0->field_33 = r1
    //     0x825328: stur            w1, [x0, #0x33]
    // 0x82532c: r1 = Instance_Duration
    //     0x82532c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x825330: ldr             x1, [x1, #0x9e0]
    // 0x825334: StoreField: r0->field_37 = r1
    //     0x825334: stur            w1, [x0, #0x37]
    // 0x825338: ldur            x1, [fp, #-0x18]
    // 0x82533c: StoreField: r0->field_b = r1
    //     0x82533c: stur            w1, [x0, #0xb]
    // 0x825340: LeaveFrame
    //     0x825340: mov             SP, fp
    //     0x825344: ldp             fp, lr, [SP], #0x10
    // 0x825348: ret
    //     0x825348: ret             
    // 0x82534c: r0 = Instance_SizedBox
    //     0x82534c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x825350: ldr             x0, [x0, #0x738]
    // 0x825354: LeaveFrame
    //     0x825354: mov             SP, fp
    //     0x825358: ldp             fp, lr, [SP], #0x10
    // 0x82535c: ret
    //     0x82535c: ret             
    // 0x825360: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x825360: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82537c, size: 0x88
    // 0x82537c: EnterFrame
    //     0x82537c: stp             fp, lr, [SP, #-0x10]!
    //     0x825380: mov             fp, SP
    // 0x825384: ldr             x0, [fp, #0x10]
    // 0x825388: LoadField: r1 = r0->field_17
    //     0x825388: ldur            w1, [x0, #0x17]
    // 0x82538c: DecompressPointer r1
    //     0x82538c: add             x1, x1, HEAP, lsl #32
    // 0x825390: CheckStackOverflow
    //     0x825390: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x825394: cmp             SP, x16
    //     0x825398: b.ls            #0x8253f4
    // 0x82539c: LoadField: r0 = r1->field_f
    //     0x82539c: ldur            w0, [x1, #0xf]
    // 0x8253a0: DecompressPointer r0
    //     0x8253a0: add             x0, x0, HEAP, lsl #32
    // 0x8253a4: LoadField: r1 = r0->field_b
    //     0x8253a4: ldur            w1, [x0, #0xb]
    // 0x8253a8: DecompressPointer r1
    //     0x8253a8: add             x1, x1, HEAP, lsl #32
    // 0x8253ac: cmp             w1, NULL
    // 0x8253b0: b.eq            #0x8253fc
    // 0x8253b4: LoadField: r0 = r1->field_f
    //     0x8253b4: ldur            w0, [x1, #0xf]
    // 0x8253b8: DecompressPointer r0
    //     0x8253b8: add             x0, x0, HEAP, lsl #32
    // 0x8253bc: LoadField: r1 = r0->field_f
    //     0x8253bc: ldur            w1, [x0, #0xf]
    // 0x8253c0: DecompressPointer r1
    //     0x8253c0: add             x1, x1, HEAP, lsl #32
    // 0x8253c4: cmp             w1, NULL
    // 0x8253c8: b.eq            #0x825400
    // 0x8253cc: SaveReg r1
    //     0x8253cc: str             x1, [SP, #-8]!
    // 0x8253d0: mov             x0, x1
    // 0x8253d4: ClosureCall
    //     0x8253d4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8253d8: ldur            x2, [x0, #0x1f]
    //     0x8253dc: blr             x2
    // 0x8253e0: add             SP, SP, #8
    // 0x8253e4: r0 = Null
    //     0x8253e4: mov             x0, NULL
    // 0x8253e8: LeaveFrame
    //     0x8253e8: mov             SP, fp
    //     0x8253ec: ldp             fp, lr, [SP], #0x10
    // 0x8253f0: ret
    //     0x8253f0: ret             
    // 0x8253f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8253f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8253f8: b               #0x82539c
    // 0x8253fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8253fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x825400: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x825400: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildTabBar(/* No info */) {
    // ** addr: 0x825410, size: 0x18c
    // 0x825410: EnterFrame
    //     0x825410: stp             fp, lr, [SP, #-0x10]!
    //     0x825414: mov             fp, SP
    // 0x825418: AllocStack(0x20)
    //     0x825418: sub             SP, SP, #0x20
    // 0x82541c: CheckStackOverflow
    //     0x82541c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x825420: cmp             SP, x16
    //     0x825424: b.ls            #0x825584
    // 0x825428: r1 = 1
    //     0x825428: mov             x1, #1
    // 0x82542c: r0 = AllocateContext()
    //     0x82542c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x825430: mov             x1, x0
    // 0x825434: ldr             x0, [fp, #0x10]
    // 0x825438: stur            x1, [fp, #-0x10]
    // 0x82543c: StoreField: r1->field_f = r0
    //     0x82543c: stur            w0, [x1, #0xf]
    // 0x825440: LoadField: r2 = r0->field_b
    //     0x825440: ldur            w2, [x0, #0xb]
    // 0x825444: DecompressPointer r2
    //     0x825444: add             x2, x2, HEAP, lsl #32
    // 0x825448: cmp             w2, NULL
    // 0x82544c: b.eq            #0x82558c
    // 0x825450: LoadField: r3 = r0->field_2b
    //     0x825450: ldur            w3, [x0, #0x2b]
    // 0x825454: DecompressPointer r3
    //     0x825454: add             x3, x3, HEAP, lsl #32
    // 0x825458: r16 = Sentinel
    //     0x825458: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82545c: cmp             w3, w16
    // 0x825460: b.eq            #0x825590
    // 0x825464: stur            x3, [fp, #-8]
    // 0x825468: LoadField: r0 = r2->field_f
    //     0x825468: ldur            w0, [x2, #0xf]
    // 0x82546c: DecompressPointer r0
    //     0x82546c: add             x0, x0, HEAP, lsl #32
    // 0x825470: LoadField: r2 = r0->field_7
    //     0x825470: ldur            w2, [x0, #7]
    // 0x825474: DecompressPointer r2
    //     0x825474: add             x2, x2, HEAP, lsl #32
    // 0x825478: SaveReg r2
    //     0x825478: str             x2, [SP, #-8]!
    // 0x82547c: r0 = asMap()
    //     0x82547c: bl              #0x5eb608  ; [dart:collection] _ListBase&Object&ListMixin::asMap
    // 0x825480: add             SP, SP, #8
    // 0x825484: SaveReg r0
    //     0x825484: str             x0, [SP, #-8]!
    // 0x825488: r0 = entries()
    //     0x825488: bl              #0xbd7428  ; [dart:collection] MapMixin::entries
    // 0x82548c: add             SP, SP, #8
    // 0x825490: ldur            x2, [fp, #-0x10]
    // 0x825494: r1 = Function '<anonymous closure>':.
    //     0x825494: add             x1, PP, #0x53, lsl #12  ; [pp+0x53a38] AnonymousClosure: (0x8256e8), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_buildTabBar (0x825410)
    //     0x825498: ldr             x1, [x1, #0xa38]
    // 0x82549c: stur            x0, [fp, #-0x18]
    // 0x8254a0: r0 = AllocateClosure()
    //     0x8254a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8254a4: r16 = <Widget>
    //     0x8254a4: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x8254a8: ldr             x16, [x16, #0xea8]
    // 0x8254ac: ldur            lr, [fp, #-0x18]
    // 0x8254b0: stp             lr, x16, [SP, #-0x10]!
    // 0x8254b4: SaveReg r0
    //     0x8254b4: str             x0, [SP, #-8]!
    // 0x8254b8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8254b8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8254bc: r0 = map()
    //     0x8254bc: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x8254c0: add             SP, SP, #0x18
    // 0x8254c4: SaveReg r0
    //     0x8254c4: str             x0, [SP, #-8]!
    // 0x8254c8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8254c8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8254cc: r0 = toList()
    //     0x8254cc: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x8254d0: add             SP, SP, #8
    // 0x8254d4: stur            x0, [fp, #-0x18]
    // 0x8254d8: r0 = TabBar()
    //     0x8254d8: bl              #0x8255a8  ; AllocateTabBarStub -> TabBar (size=0x70)
    // 0x8254dc: mov             x3, x0
    // 0x8254e0: ldur            x0, [fp, #-0x18]
    // 0x8254e4: stur            x3, [fp, #-0x20]
    // 0x8254e8: StoreField: r3->field_b = r0
    //     0x8254e8: stur            w0, [x3, #0xb]
    // 0x8254ec: ldur            x0, [fp, #-8]
    // 0x8254f0: StoreField: r3->field_f = r0
    //     0x8254f0: stur            w0, [x3, #0xf]
    // 0x8254f4: r0 = false
    //     0x8254f4: add             x0, NULL, #0x30  ; false
    // 0x8254f8: StoreField: r3->field_13 = r0
    //     0x8254f8: stur            w0, [x3, #0x13]
    // 0x8254fc: r0 = Instance_MaterialColor
    //     0x8254fc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0x825500: ldr             x0, [x0, #0xf28]
    // 0x825504: StoreField: r3->field_1b = r0
    //     0x825504: stur            w0, [x3, #0x1b]
    // 0x825508: r1 = true
    //     0x825508: add             x1, NULL, #0x20  ; true
    // 0x82550c: StoreField: r3->field_2f = r1
    //     0x82550c: stur            w1, [x3, #0x2f]
    // 0x825510: d0 = 2.000000
    //     0x825510: fmov            d0, #2.00000000
    // 0x825514: StoreField: r3->field_1f = d0
    //     0x825514: stur            d0, [x3, #0x1f]
    // 0x825518: r1 = Instance_EdgeInsets
    //     0x825518: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x82551c: ldr             x1, [x1, #0xbd8]
    // 0x825520: StoreField: r3->field_27 = r1
    //     0x825520: stur            w1, [x3, #0x27]
    // 0x825524: StoreField: r3->field_3b = r0
    //     0x825524: stur            w0, [x3, #0x3b]
    // 0x825528: StoreField: r3->field_47 = r1
    //     0x825528: stur            w1, [x3, #0x47]
    // 0x82552c: r0 = Instance_MaterialColor
    //     0x82552c: add             x0, PP, #0x2f, lsl #12  ; [pp+0x2f8d0] Obj!MaterialColor<int>@b5e3f1
    //     0x825530: ldr             x0, [x0, #0x8d0]
    // 0x825534: StoreField: r3->field_3f = r0
    //     0x825534: stur            w0, [x3, #0x3f]
    // 0x825538: r0 = Instance_DragStartBehavior
    //     0x825538: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x82553c: ldr             x0, [x0, #0xf88]
    // 0x825540: StoreField: r3->field_53 = r0
    //     0x825540: stur            w0, [x3, #0x53]
    // 0x825544: ldur            x2, [fp, #-0x10]
    // 0x825548: r1 = Function '<anonymous closure>':.
    //     0x825548: add             x1, PP, #0x53, lsl #12  ; [pp+0x53a40] AnonymousClosure: (0x8255b4), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_buildTabBar (0x825410)
    //     0x82554c: ldr             x1, [x1, #0xa40]
    // 0x825550: r0 = AllocateClosure()
    //     0x825550: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x825554: mov             x1, x0
    // 0x825558: ldur            x0, [fp, #-0x20]
    // 0x82555c: StoreField: r0->field_5f = r1
    //     0x82555c: stur            w1, [x0, #0x5f]
    // 0x825560: r0 = SizedBox()
    //     0x825560: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x825564: r1 = 46.000000
    //     0x825564: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c590] 46
    //     0x825568: ldr             x1, [x1, #0x590]
    // 0x82556c: StoreField: r0->field_13 = r1
    //     0x82556c: stur            w1, [x0, #0x13]
    // 0x825570: ldur            x1, [fp, #-0x20]
    // 0x825574: StoreField: r0->field_b = r1
    //     0x825574: stur            w1, [x0, #0xb]
    // 0x825578: LeaveFrame
    //     0x825578: mov             SP, fp
    //     0x82557c: ldp             fp, lr, [SP], #0x10
    // 0x825580: ret
    //     0x825580: ret             
    // 0x825584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x825584: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x825588: b               #0x825428
    // 0x82558c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82558c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x825590: r9 = _tabController
    //     0x825590: add             x9, PP, #0x53, lsl #12  ; [pp+0x53a18] Field <_DefaultEmojiPickerViewState@394000349._tabController@394000349>: late (offset: 0x2c)
    //     0x825594: ldr             x9, [x9, #0xa18]
    // 0x825598: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x825598: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x8255b4, size: 0x90
    // 0x8255b4: EnterFrame
    //     0x8255b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8255b8: mov             fp, SP
    // 0x8255bc: AllocStack(0x8)
    //     0x8255bc: sub             SP, SP, #8
    // 0x8255c0: SetupParameters()
    //     0x8255c0: ldr             x0, [fp, #0x18]
    //     0x8255c4: ldur            w1, [x0, #0x17]
    //     0x8255c8: add             x1, x1, HEAP, lsl #32
    //     0x8255cc: stur            x1, [fp, #-8]
    // 0x8255d0: CheckStackOverflow
    //     0x8255d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8255d4: cmp             SP, x16
    //     0x8255d8: b.ls            #0x825630
    // 0x8255dc: LoadField: r0 = r1->field_f
    //     0x8255dc: ldur            w0, [x1, #0xf]
    // 0x8255e0: DecompressPointer r0
    //     0x8255e0: add             x0, x0, HEAP, lsl #32
    // 0x8255e4: SaveReg r0
    //     0x8255e4: str             x0, [SP, #-8]!
    // 0x8255e8: r0 = closeSkinToneOverlay()
    //     0x8255e8: bl              #0x825644  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin&SkinToneOverlayStateMixin::closeSkinToneOverlay
    // 0x8255ec: add             SP, SP, #8
    // 0x8255f0: ldur            x0, [fp, #-8]
    // 0x8255f4: LoadField: r1 = r0->field_f
    //     0x8255f4: ldur            w1, [x0, #0xf]
    // 0x8255f8: DecompressPointer r1
    //     0x8255f8: add             x1, x1, HEAP, lsl #32
    // 0x8255fc: LoadField: r0 = r1->field_27
    //     0x8255fc: ldur            w0, [x1, #0x27]
    // 0x825600: DecompressPointer r0
    //     0x825600: add             x0, x0, HEAP, lsl #32
    // 0x825604: r16 = Sentinel
    //     0x825604: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x825608: cmp             w0, w16
    // 0x82560c: b.eq            #0x825638
    // 0x825610: ldr             x16, [fp, #0x10]
    // 0x825614: stp             x16, x0, [SP, #-0x10]!
    // 0x825618: r0 = jumpToPage()
    //     0x825618: bl              #0x7a1e1c  ; [package:flutter/src/widgets/page_view.dart] PageController::jumpToPage
    // 0x82561c: add             SP, SP, #0x10
    // 0x825620: r0 = Null
    //     0x825620: mov             x0, NULL
    // 0x825624: LeaveFrame
    //     0x825624: mov             SP, fp
    //     0x825628: ldp             fp, lr, [SP], #0x10
    // 0x82562c: ret
    //     0x82562c: ret             
    // 0x825630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x825630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x825634: b               #0x8255dc
    // 0x825638: r9 = _pageController
    //     0x825638: add             x9, PP, #0x53, lsl #12  ; [pp+0x539e8] Field <_DefaultEmojiPickerViewState@394000349._pageController@394000349>: late (offset: 0x28)
    //     0x82563c: ldr             x9, [x9, #0x9e8]
    // 0x825640: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x825640: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, MapEntry<int, CategoryEmoji>) {
    // ** addr: 0x8256e8, size: 0xac
    // 0x8256e8: EnterFrame
    //     0x8256e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8256ec: mov             fp, SP
    // 0x8256f0: AllocStack(0x8)
    //     0x8256f0: sub             SP, SP, #8
    // 0x8256f4: SetupParameters()
    //     0x8256f4: ldr             x0, [fp, #0x18]
    //     0x8256f8: ldur            w1, [x0, #0x17]
    //     0x8256fc: add             x1, x1, HEAP, lsl #32
    //     0x825700: stur            x1, [fp, #-8]
    // 0x825704: CheckStackOverflow
    //     0x825704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x825708: cmp             SP, x16
    //     0x82570c: b.ls            #0x825788
    // 0x825710: ldr             x2, [fp, #0x10]
    // 0x825714: r0 = LoadClassIdInstr(r2)
    //     0x825714: ldur            x0, [x2, #-1]
    //     0x825718: ubfx            x0, x0, #0xc, #0x14
    // 0x82571c: SaveReg r2
    //     0x82571c: str             x2, [SP, #-8]!
    // 0x825720: r0 = GDT[cid_x0 + -0xfba]()
    //     0x825720: sub             lr, x0, #0xfba
    //     0x825724: ldr             lr, [x21, lr, lsl #3]
    //     0x825728: blr             lr
    // 0x82572c: add             SP, SP, #8
    // 0x825730: ldr             x0, [fp, #0x10]
    // 0x825734: r1 = LoadClassIdInstr(r0)
    //     0x825734: ldur            x1, [x0, #-1]
    //     0x825738: ubfx            x1, x1, #0xc, #0x14
    // 0x82573c: SaveReg r0
    //     0x82573c: str             x0, [SP, #-8]!
    // 0x825740: mov             x0, x1
    // 0x825744: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x825744: sub             lr, x0, #0xfc4
    //     0x825748: ldr             lr, [x21, lr, lsl #3]
    //     0x82574c: blr             lr
    // 0x825750: add             SP, SP, #8
    // 0x825754: cmp             w0, NULL
    // 0x825758: b.eq            #0x825790
    // 0x82575c: LoadField: r1 = r0->field_7
    //     0x82575c: ldur            w1, [x0, #7]
    // 0x825760: DecompressPointer r1
    //     0x825760: add             x1, x1, HEAP, lsl #32
    // 0x825764: ldur            x0, [fp, #-8]
    // 0x825768: LoadField: r2 = r0->field_f
    //     0x825768: ldur            w2, [x0, #0xf]
    // 0x82576c: DecompressPointer r2
    //     0x82576c: add             x2, x2, HEAP, lsl #32
    // 0x825770: stp             x1, x2, [SP, #-0x10]!
    // 0x825774: r0 = _buildCategory()
    //     0x825774: bl              #0x825794  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_buildCategory
    // 0x825778: add             SP, SP, #0x10
    // 0x82577c: LeaveFrame
    //     0x82577c: mov             SP, fp
    //     0x825780: ldp             fp, lr, [SP], #0x10
    // 0x825784: ret
    //     0x825784: ret             
    // 0x825788: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x825788: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82578c: b               #0x825710
    // 0x825790: r0 = NullErrorSharedWithoutFPURegs()
    //     0x825790: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _buildCategory(/* No info */) {
    // ** addr: 0x825794, size: 0x8c
    // 0x825794: EnterFrame
    //     0x825794: stp             fp, lr, [SP, #-0x10]!
    //     0x825798: mov             fp, SP
    // 0x82579c: AllocStack(0x10)
    //     0x82579c: sub             SP, SP, #0x10
    // 0x8257a0: CheckStackOverflow
    //     0x8257a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8257a4: cmp             SP, x16
    //     0x8257a8: b.ls            #0x825814
    // 0x8257ac: ldr             x0, [fp, #0x18]
    // 0x8257b0: LoadField: r1 = r0->field_b
    //     0x8257b0: ldur            w1, [x0, #0xb]
    // 0x8257b4: DecompressPointer r1
    //     0x8257b4: add             x1, x1, HEAP, lsl #32
    // 0x8257b8: cmp             w1, NULL
    // 0x8257bc: b.eq            #0x82581c
    // 0x8257c0: r16 = Instance_Config
    //     0x8257c0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b10] Obj!Config@b5c6a1
    //     0x8257c4: ldr             x16, [x16, #0xb10]
    // 0x8257c8: ldr             lr, [fp, #0x10]
    // 0x8257cc: stp             lr, x16, [SP, #-0x10]!
    // 0x8257d0: r0 = getIconForCategory()
    //     0x8257d0: bl              #0x82582c  ; [package:emoji_picker_flutter/src/config.dart] Config::getIconForCategory
    // 0x8257d4: add             SP, SP, #0x10
    // 0x8257d8: stur            x0, [fp, #-8]
    // 0x8257dc: r0 = Icon()
    //     0x8257dc: bl              #0x825370  ; AllocateIconStub -> Icon (size=0x34)
    // 0x8257e0: mov             x1, x0
    // 0x8257e4: ldur            x0, [fp, #-8]
    // 0x8257e8: stur            x1, [fp, #-0x10]
    // 0x8257ec: StoreField: r1->field_b = r0
    //     0x8257ec: stur            w0, [x1, #0xb]
    // 0x8257f0: r0 = Tab()
    //     0x8257f0: bl              #0x825820  ; AllocateTabStub -> Tab (size=0x20)
    // 0x8257f4: ldur            x1, [fp, #-0x10]
    // 0x8257f8: StoreField: r0->field_13 = r1
    //     0x8257f8: stur            w1, [x0, #0x13]
    // 0x8257fc: r1 = Instance_EdgeInsets
    //     0x8257fc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c500] Obj!EdgeInsets@b35bd1
    //     0x825800: ldr             x1, [x1, #0x500]
    // 0x825804: StoreField: r0->field_17 = r1
    //     0x825804: stur            w1, [x0, #0x17]
    // 0x825808: LeaveFrame
    //     0x825808: mov             SP, fp
    //     0x82580c: ldp             fp, lr, [SP], #0x10
    // 0x825810: ret
    //     0x825810: ret             
    // 0x825814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x825814: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x825818: b               #0x8257ac
    // 0x82581c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82581c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x82595c, size: 0xcc
    // 0x82595c: EnterFrame
    //     0x82595c: stp             fp, lr, [SP, #-0x10]!
    //     0x825960: mov             fp, SP
    // 0x825964: ldr             x0, [fp, #0x20]
    // 0x825968: LoadField: r1 = r0->field_17
    //     0x825968: ldur            w1, [x0, #0x17]
    // 0x82596c: DecompressPointer r1
    //     0x82596c: add             x1, x1, HEAP, lsl #32
    // 0x825970: CheckStackOverflow
    //     0x825970: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x825974: cmp             SP, x16
    //     0x825978: b.ls            #0x825a18
    // 0x82597c: LoadField: r0 = r1->field_b
    //     0x82597c: ldur            w0, [x1, #0xb]
    // 0x825980: DecompressPointer r0
    //     0x825980: add             x0, x0, HEAP, lsl #32
    // 0x825984: LoadField: r2 = r0->field_f
    //     0x825984: ldur            w2, [x0, #0xf]
    // 0x825988: DecompressPointer r2
    //     0x825988: add             x2, x2, HEAP, lsl #32
    // 0x82598c: LoadField: r3 = r1->field_f
    //     0x82598c: ldur            w3, [x1, #0xf]
    // 0x825990: DecompressPointer r3
    //     0x825990: add             x3, x3, HEAP, lsl #32
    // 0x825994: LoadField: r0 = r2->field_b
    //     0x825994: ldur            w0, [x2, #0xb]
    // 0x825998: DecompressPointer r0
    //     0x825998: add             x0, x0, HEAP, lsl #32
    // 0x82599c: cmp             w0, NULL
    // 0x8259a0: b.eq            #0x825a20
    // 0x8259a4: LoadField: r1 = r0->field_f
    //     0x8259a4: ldur            w1, [x0, #0xf]
    // 0x8259a8: DecompressPointer r1
    //     0x8259a8: add             x1, x1, HEAP, lsl #32
    // 0x8259ac: LoadField: r4 = r1->field_7
    //     0x8259ac: ldur            w4, [x1, #7]
    // 0x8259b0: DecompressPointer r4
    //     0x8259b0: add             x4, x4, HEAP, lsl #32
    // 0x8259b4: LoadField: r0 = r4->field_b
    //     0x8259b4: ldur            w0, [x4, #0xb]
    // 0x8259b8: DecompressPointer r0
    //     0x8259b8: add             x0, x0, HEAP, lsl #32
    // 0x8259bc: ldr             x1, [fp, #0x10]
    // 0x8259c0: r5 = LoadInt32Instr(r1)
    //     0x8259c0: sbfx            x5, x1, #1, #0x1f
    //     0x8259c4: tbz             w1, #0, #0x8259cc
    //     0x8259c8: ldur            x5, [x1, #7]
    // 0x8259cc: r1 = LoadInt32Instr(r0)
    //     0x8259cc: sbfx            x1, x0, #1, #0x1f
    // 0x8259d0: mov             x0, x1
    // 0x8259d4: mov             x1, x5
    // 0x8259d8: cmp             x1, x0
    // 0x8259dc: b.hs            #0x825a24
    // 0x8259e0: LoadField: r0 = r4->field_f
    //     0x8259e0: ldur            w0, [x4, #0xf]
    // 0x8259e4: DecompressPointer r0
    //     0x8259e4: add             x0, x0, HEAP, lsl #32
    // 0x8259e8: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x8259e8: add             x16, x0, x5, lsl #2
    //     0x8259ec: ldur            w1, [x16, #0xf]
    // 0x8259f0: DecompressPointer r1
    //     0x8259f0: add             x1, x1, HEAP, lsl #32
    // 0x8259f4: LoadField: d0 = r3->field_7
    //     0x8259f4: ldur            d0, [x3, #7]
    // 0x8259f8: SaveReg r2
    //     0x8259f8: str             x2, [SP, #-8]!
    // 0x8259fc: SaveReg d0
    //     0x8259fc: str             d0, [SP, #-8]!
    // 0x825a00: SaveReg r1
    //     0x825a00: str             x1, [SP, #-8]!
    // 0x825a04: r0 = _buildPage()
    //     0x825a04: bl              #0x825a28  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_buildPage
    // 0x825a08: add             SP, SP, #0x18
    // 0x825a0c: LeaveFrame
    //     0x825a0c: mov             SP, fp
    //     0x825a10: ldp             fp, lr, [SP], #0x10
    // 0x825a14: ret
    //     0x825a14: ret             
    // 0x825a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x825a18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x825a1c: b               #0x82597c
    // 0x825a20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x825a20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x825a24: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x825a24: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildPage(/* No info */) {
    // ** addr: 0x825a28, size: 0x398
    // 0x825a28: EnterFrame
    //     0x825a28: stp             fp, lr, [SP, #-0x10]!
    //     0x825a2c: mov             fp, SP
    // 0x825a30: AllocStack(0x48)
    //     0x825a30: sub             SP, SP, #0x48
    // 0x825a34: CheckStackOverflow
    //     0x825a34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x825a38: cmp             SP, x16
    //     0x825a3c: b.ls            #0x825da4
    // 0x825a40: r1 = 1
    //     0x825a40: mov             x1, #1
    // 0x825a44: r0 = AllocateContext()
    //     0x825a44: bl              #0xd68aa4  ; AllocateContextStub
    // 0x825a48: mov             x2, x0
    // 0x825a4c: ldr             x1, [fp, #0x20]
    // 0x825a50: stur            x2, [fp, #-8]
    // 0x825a54: StoreField: r2->field_f = r1
    //     0x825a54: stur            w1, [x2, #0xf]
    // 0x825a58: ldr             x3, [fp, #0x10]
    // 0x825a5c: LoadField: r0 = r3->field_7
    //     0x825a5c: ldur            w0, [x3, #7]
    // 0x825a60: DecompressPointer r0
    //     0x825a60: add             x0, x0, HEAP, lsl #32
    // 0x825a64: r16 = Instance_Category
    //     0x825a64: add             x16, PP, #0x41, lsl #12  ; [pp+0x41090] Obj!Category@b664f1
    //     0x825a68: ldr             x16, [x16, #0x90]
    // 0x825a6c: cmp             w0, w16
    // 0x825a70: b.ne            #0x825ac0
    // 0x825a74: LoadField: r0 = r3->field_b
    //     0x825a74: ldur            w0, [x3, #0xb]
    // 0x825a78: DecompressPointer r0
    //     0x825a78: add             x0, x0, HEAP, lsl #32
    // 0x825a7c: r4 = LoadClassIdInstr(r0)
    //     0x825a7c: ldur            x4, [x0, #-1]
    //     0x825a80: ubfx            x4, x4, #0xc, #0x14
    // 0x825a84: SaveReg r0
    //     0x825a84: str             x0, [SP, #-8]!
    // 0x825a88: mov             x0, x4
    // 0x825a8c: r0 = GDT[cid_x0 + 0xccd1]()
    //     0x825a8c: mov             x17, #0xccd1
    //     0x825a90: add             lr, x0, x17
    //     0x825a94: ldr             lr, [x21, lr, lsl #3]
    //     0x825a98: blr             lr
    // 0x825a9c: add             SP, SP, #8
    // 0x825aa0: tbnz            w0, #4, #0x825ac0
    // 0x825aa4: ldr             x16, [fp, #0x20]
    // 0x825aa8: SaveReg r16
    //     0x825aa8: str             x16, [SP, #-8]!
    // 0x825aac: r0 = _buildNoRecent()
    //     0x825aac: bl              #0x826018  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_buildNoRecent
    // 0x825ab0: add             SP, SP, #8
    // 0x825ab4: LeaveFrame
    //     0x825ab4: mov             SP, fp
    //     0x825ab8: ldp             fp, lr, [SP], #0x10
    // 0x825abc: ret
    //     0x825abc: ret             
    // 0x825ac0: ldr             x1, [fp, #0x20]
    // 0x825ac4: ldr             x0, [fp, #0x10]
    // 0x825ac8: r1 = 1
    //     0x825ac8: mov             x1, #1
    // 0x825acc: r0 = AllocateContext()
    //     0x825acc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x825ad0: mov             x2, x0
    // 0x825ad4: ldr             x0, [fp, #0x20]
    // 0x825ad8: stur            x2, [fp, #-0x10]
    // 0x825adc: StoreField: r2->field_f = r0
    //     0x825adc: stur            w0, [x2, #0xf]
    // 0x825ae0: mov             x1, x0
    // 0x825ae4: LoadField: r0 = r1->field_2f
    //     0x825ae4: ldur            w0, [x1, #0x2f]
    // 0x825ae8: DecompressPointer r0
    //     0x825ae8: add             x0, x0, HEAP, lsl #32
    // 0x825aec: r16 = Sentinel
    //     0x825aec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x825af0: cmp             w0, w16
    // 0x825af4: b.ne            #0x825b04
    // 0x825af8: r2 = _scrollController
    //     0x825af8: add             x2, PP, #0x53, lsl #12  ; [pp+0x539f0] Field <_DefaultEmojiPickerViewState@394000349._scrollController@394000349>: late final (offset: 0x30)
    //     0x825afc: ldr             x2, [x2, #0x9f0]
    // 0x825b00: r0 = InitLateFinalInstanceField()
    //     0x825b00: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x825b04: mov             x1, x0
    // 0x825b08: ldr             x0, [fp, #0x20]
    // 0x825b0c: stur            x1, [fp, #-0x18]
    // 0x825b10: LoadField: r2 = r0->field_b
    //     0x825b10: ldur            w2, [x0, #0xb]
    // 0x825b14: DecompressPointer r2
    //     0x825b14: add             x2, x2, HEAP, lsl #32
    // 0x825b18: cmp             w2, NULL
    // 0x825b1c: b.eq            #0x825dac
    // 0x825b20: r16 = <Widget>
    //     0x825b20: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x825b24: ldr             x16, [x16, #0xea8]
    // 0x825b28: stp             xzr, x16, [SP, #-0x10]!
    // 0x825b2c: r0 = _GrowableList()
    //     0x825b2c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x825b30: add             SP, SP, #0x10
    // 0x825b34: mov             x2, x0
    // 0x825b38: ldr             x1, [fp, #0x10]
    // 0x825b3c: stur            x2, [fp, #-0x30]
    // 0x825b40: LoadField: r3 = r1->field_b
    //     0x825b40: ldur            w3, [x1, #0xb]
    // 0x825b44: DecompressPointer r3
    //     0x825b44: add             x3, x3, HEAP, lsl #32
    // 0x825b48: stur            x3, [fp, #-0x28]
    // 0x825b4c: r5 = 0
    //     0x825b4c: mov             x5, #0
    // 0x825b50: ldr             x4, [fp, #0x20]
    // 0x825b54: ldr             d0, [fp, #0x18]
    // 0x825b58: stur            x5, [fp, #-0x20]
    // 0x825b5c: CheckStackOverflow
    //     0x825b5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x825b60: cmp             SP, x16
    //     0x825b64: b.ls            #0x825db0
    // 0x825b68: r0 = LoadClassIdInstr(r3)
    //     0x825b68: ldur            x0, [x3, #-1]
    //     0x825b6c: ubfx            x0, x0, #0xc, #0x14
    // 0x825b70: SaveReg r3
    //     0x825b70: str             x3, [SP, #-8]!
    // 0x825b74: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x825b74: mov             x17, #0xb8ea
    //     0x825b78: add             lr, x0, x17
    //     0x825b7c: ldr             lr, [x21, lr, lsl #3]
    //     0x825b80: blr             lr
    // 0x825b84: add             SP, SP, #8
    // 0x825b88: r1 = LoadInt32Instr(r0)
    //     0x825b88: sbfx            x1, x0, #1, #0x1f
    // 0x825b8c: ldur            x2, [fp, #-0x20]
    // 0x825b90: cmp             x2, x1
    // 0x825b94: b.ge            #0x825d30
    // 0x825b98: ldr             x6, [fp, #0x20]
    // 0x825b9c: ldr             d0, [fp, #0x18]
    // 0x825ba0: ldr             x3, [fp, #0x10]
    // 0x825ba4: ldur            x4, [fp, #-0x30]
    // 0x825ba8: ldur            x5, [fp, #-0x28]
    // 0x825bac: r0 = BoxInt64Instr(r2)
    //     0x825bac: sbfiz           x0, x2, #1, #0x1f
    //     0x825bb0: cmp             x2, x0, asr #1
    //     0x825bb4: b.eq            #0x825bc0
    //     0x825bb8: bl              #0xd69c6c
    //     0x825bbc: stur            x2, [x0, #7]
    // 0x825bc0: r1 = LoadClassIdInstr(r5)
    //     0x825bc0: ldur            x1, [x5, #-1]
    //     0x825bc4: ubfx            x1, x1, #0xc, #0x14
    // 0x825bc8: stp             x0, x5, [SP, #-0x10]!
    // 0x825bcc: mov             x0, x1
    // 0x825bd0: r0 = GDT[cid_x0 + -0xd83]()
    //     0x825bd0: sub             lr, x0, #0xd83
    //     0x825bd4: ldr             lr, [x21, lr, lsl #3]
    //     0x825bd8: blr             lr
    // 0x825bdc: add             SP, SP, #0x10
    // 0x825be0: stur            x0, [fp, #-0x38]
    // 0x825be4: r1 = 1
    //     0x825be4: mov             x1, #1
    // 0x825be8: r0 = AllocateContext()
    //     0x825be8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x825bec: mov             x1, x0
    // 0x825bf0: ldr             x0, [fp, #0x20]
    // 0x825bf4: stur            x1, [fp, #-0x40]
    // 0x825bf8: StoreField: r1->field_f = r0
    //     0x825bf8: stur            w0, [x1, #0xf]
    // 0x825bfc: LoadField: r2 = r0->field_b
    //     0x825bfc: ldur            w2, [x0, #0xb]
    // 0x825c00: DecompressPointer r2
    //     0x825c00: add             x2, x2, HEAP, lsl #32
    // 0x825c04: cmp             w2, NULL
    // 0x825c08: b.eq            #0x825db8
    // 0x825c0c: r0 = EmojiCell()
    //     0x825c0c: bl              #0x82600c  ; AllocateEmojiCellStub -> EmojiCell (size=0x3c)
    // 0x825c10: mov             x3, x0
    // 0x825c14: ldur            x0, [fp, #-0x38]
    // 0x825c18: stur            x3, [fp, #-0x48]
    // 0x825c1c: StoreField: r3->field_b = r0
    //     0x825c1c: stur            w0, [x3, #0xb]
    // 0x825c20: ldr             d0, [fp, #0x18]
    // 0x825c24: StoreField: r3->field_f = d0
    //     0x825c24: stur            d0, [x3, #0xf]
    // 0x825c28: ldr             x0, [fp, #0x10]
    // 0x825c2c: StoreField: r3->field_17 = r0
    //     0x825c2c: stur            w0, [x3, #0x17]
    // 0x825c30: ldur            x4, [fp, #-0x20]
    // 0x825c34: StoreField: r3->field_1f = r4
    //     0x825c34: stur            x4, [x3, #0x1f]
    // 0x825c38: ldur            x2, [fp, #-8]
    // 0x825c3c: r1 = Function '<anonymous closure>':.
    //     0x825c3c: add             x1, PP, #0x53, lsl #12  ; [pp+0x539f8] AnonymousClosure: (0x826130), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_buildPage (0x825a28)
    //     0x825c40: ldr             x1, [x1, #0x9f8]
    // 0x825c44: r0 = AllocateClosure()
    //     0x825c44: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x825c48: mov             x1, x0
    // 0x825c4c: ldur            x0, [fp, #-0x48]
    // 0x825c50: StoreField: r0->field_37 = r1
    //     0x825c50: stur            w1, [x0, #0x37]
    // 0x825c54: ldur            x2, [fp, #-0x40]
    // 0x825c58: r1 = Function '_openSkinToneDialog@394000349':.
    //     0x825c58: add             x1, PP, #0x53, lsl #12  ; [pp+0x53a00] AnonymousClosure: (0x82606c), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_openSkinToneDialog (0x8260cc)
    //     0x825c5c: ldr             x1, [x1, #0xa00]
    // 0x825c60: r0 = AllocateClosure()
    //     0x825c60: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x825c64: mov             x1, x0
    // 0x825c68: ldur            x0, [fp, #-0x48]
    // 0x825c6c: StoreField: r0->field_33 = r1
    //     0x825c6c: stur            w1, [x0, #0x33]
    // 0x825c70: r1 = Instance_ButtonMode
    //     0x825c70: add             x1, PP, #0x41, lsl #12  ; [pp+0x410a8] Obj!ButtonMode@b663d1
    //     0x825c74: ldr             x1, [x1, #0xa8]
    // 0x825c78: StoreField: r0->field_1b = r1
    //     0x825c78: stur            w1, [x0, #0x1b]
    // 0x825c7c: r2 = false
    //     0x825c7c: add             x2, NULL, #0x30  ; false
    // 0x825c80: StoreField: r0->field_27 = r2
    //     0x825c80: stur            w2, [x0, #0x27]
    // 0x825c84: r3 = Instance_MaterialColor
    //     0x825c84: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f8d0] Obj!MaterialColor<int>@b5e3f1
    //     0x825c88: ldr             x3, [x3, #0x8d0]
    // 0x825c8c: StoreField: r0->field_2f = r3
    //     0x825c8c: stur            w3, [x0, #0x2f]
    // 0x825c90: ldur            x4, [fp, #-0x30]
    // 0x825c94: LoadField: r5 = r4->field_b
    //     0x825c94: ldur            w5, [x4, #0xb]
    // 0x825c98: DecompressPointer r5
    //     0x825c98: add             x5, x5, HEAP, lsl #32
    // 0x825c9c: stur            x5, [fp, #-0x38]
    // 0x825ca0: LoadField: r6 = r4->field_f
    //     0x825ca0: ldur            w6, [x4, #0xf]
    // 0x825ca4: DecompressPointer r6
    //     0x825ca4: add             x6, x6, HEAP, lsl #32
    // 0x825ca8: LoadField: r7 = r6->field_b
    //     0x825ca8: ldur            w7, [x6, #0xb]
    // 0x825cac: DecompressPointer r7
    //     0x825cac: add             x7, x7, HEAP, lsl #32
    // 0x825cb0: cmp             w5, w7
    // 0x825cb4: b.ne            #0x825cc4
    // 0x825cb8: SaveReg r4
    //     0x825cb8: str             x4, [SP, #-8]!
    // 0x825cbc: r0 = _growToNextCapacity()
    //     0x825cbc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x825cc0: add             SP, SP, #8
    // 0x825cc4: ldur            x2, [fp, #-0x30]
    // 0x825cc8: ldur            x3, [fp, #-0x20]
    // 0x825ccc: ldur            x0, [fp, #-0x38]
    // 0x825cd0: r4 = LoadInt32Instr(r0)
    //     0x825cd0: sbfx            x4, x0, #1, #0x1f
    // 0x825cd4: add             x0, x4, #1
    // 0x825cd8: lsl             x1, x0, #1
    // 0x825cdc: StoreField: r2->field_b = r1
    //     0x825cdc: stur            w1, [x2, #0xb]
    // 0x825ce0: mov             x1, x4
    // 0x825ce4: cmp             x1, x0
    // 0x825ce8: b.hs            #0x825dbc
    // 0x825cec: LoadField: r1 = r2->field_f
    //     0x825cec: ldur            w1, [x2, #0xf]
    // 0x825cf0: DecompressPointer r1
    //     0x825cf0: add             x1, x1, HEAP, lsl #32
    // 0x825cf4: ldur            x0, [fp, #-0x48]
    // 0x825cf8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x825cf8: add             x25, x1, x4, lsl #2
    //     0x825cfc: add             x25, x25, #0xf
    //     0x825d00: str             w0, [x25]
    //     0x825d04: tbz             w0, #0, #0x825d20
    //     0x825d08: ldurb           w16, [x1, #-1]
    //     0x825d0c: ldurb           w17, [x0, #-1]
    //     0x825d10: and             x16, x17, x16, lsr #2
    //     0x825d14: tst             x16, HEAP, lsr #32
    //     0x825d18: b.eq            #0x825d20
    //     0x825d1c: bl              #0xd67e5c
    // 0x825d20: add             x5, x3, #1
    // 0x825d24: ldr             x1, [fp, #0x10]
    // 0x825d28: ldur            x3, [fp, #-0x28]
    // 0x825d2c: b               #0x825b50
    // 0x825d30: ldur            x2, [fp, #-0x30]
    // 0x825d34: r0 = GridView()
    //     0x825d34: bl              #0x826000  ; AllocateGridViewStub -> GridView (size=0x58)
    // 0x825d38: stur            x0, [fp, #-8]
    // 0x825d3c: ldur            x16, [fp, #-0x30]
    // 0x825d40: stp             x16, x0, [SP, #-0x10]!
    // 0x825d44: ldur            x16, [fp, #-0x18]
    // 0x825d48: SaveReg r16
    //     0x825d48: str             x16, [SP, #-8]!
    // 0x825d4c: r1 = 8
    //     0x825d4c: mov             x1, #8
    // 0x825d50: SaveReg r1
    //     0x825d50: str             x1, [SP, #-8]!
    // 0x825d54: r0 = GridView.count()
    //     0x825d54: bl              #0x825dc0  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.count
    // 0x825d58: add             SP, SP, #0x20
    // 0x825d5c: r0 = GestureDetector()
    //     0x825d5c: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x825d60: ldur            x2, [fp, #-0x10]
    // 0x825d64: r1 = Function 'closeSkinToneOverlay':.
    //     0x825d64: add             x1, PP, #0x53, lsl #12  ; [pp+0x53a08] AnonymousClosure: (0x8256a0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin&SkinToneOverlayStateMixin::closeSkinToneOverlay (0x825644)
    //     0x825d68: ldr             x1, [x1, #0xa08]
    // 0x825d6c: stur            x0, [fp, #-0x10]
    // 0x825d70: r0 = AllocateClosure()
    //     0x825d70: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x825d74: ldur            x16, [fp, #-0x10]
    // 0x825d78: stp             x0, x16, [SP, #-0x10]!
    // 0x825d7c: ldur            x16, [fp, #-8]
    // 0x825d80: SaveReg r16
    //     0x825d80: str             x16, [SP, #-8]!
    // 0x825d84: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x825d84: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1c378] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x825d88: ldr             x4, [x4, #0x378]
    // 0x825d8c: r0 = GestureDetector()
    //     0x825d8c: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x825d90: add             SP, SP, #0x18
    // 0x825d94: ldur            x0, [fp, #-0x10]
    // 0x825d98: LeaveFrame
    //     0x825d98: mov             SP, fp
    //     0x825d9c: ldp             fp, lr, [SP], #0x10
    // 0x825da0: ret
    //     0x825da0: ret             
    // 0x825da4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x825da4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x825da8: b               #0x825a40
    // 0x825dac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x825dac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x825db0: r0 = StackOverflowSharedWithFPURegs()
    //     0x825db0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x825db4: b               #0x825b68
    // 0x825db8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x825db8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x825dbc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x825dbc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildNoRecent(/* No info */) {
    // ** addr: 0x826018, size: 0x48
    // 0x826018: EnterFrame
    //     0x826018: stp             fp, lr, [SP, #-0x10]!
    //     0x82601c: mov             fp, SP
    // 0x826020: ldr             x0, [fp, #0x10]
    // 0x826024: LoadField: r1 = r0->field_b
    //     0x826024: ldur            w1, [x0, #0xb]
    // 0x826028: DecompressPointer r1
    //     0x826028: add             x1, x1, HEAP, lsl #32
    // 0x82602c: cmp             w1, NULL
    // 0x826030: b.eq            #0x82605c
    // 0x826034: r0 = Center()
    //     0x826034: bl              #0x826060  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x826038: r1 = Instance_Alignment
    //     0x826038: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x82603c: ldr             x1, [x1, #0xc70]
    // 0x826040: StoreField: r0->field_f = r1
    //     0x826040: stur            w1, [x0, #0xf]
    // 0x826044: r1 = Instance_Text
    //     0x826044: add             x1, PP, #0x53, lsl #12  ; [pp+0x53a10] Obj!Text@b4b1b1
    //     0x826048: ldr             x1, [x1, #0xa10]
    // 0x82604c: StoreField: r0->field_b = r1
    //     0x82604c: stur            w1, [x0, #0xb]
    // 0x826050: LeaveFrame
    //     0x826050: mov             SP, fp
    //     0x826054: ldp             fp, lr, [SP], #0x10
    // 0x826058: ret
    //     0x826058: ret             
    // 0x82605c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82605c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _openSkinToneDialog(dynamic, Emoji, double, CategoryEmoji?, int) {
    // ** addr: 0x82606c, size: 0x60
    // 0x82606c: EnterFrame
    //     0x82606c: stp             fp, lr, [SP, #-0x10]!
    //     0x826070: mov             fp, SP
    // 0x826074: ldr             x0, [fp, #0x30]
    // 0x826078: LoadField: r1 = r0->field_17
    //     0x826078: ldur            w1, [x0, #0x17]
    // 0x82607c: DecompressPointer r1
    //     0x82607c: add             x1, x1, HEAP, lsl #32
    // 0x826080: CheckStackOverflow
    //     0x826080: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x826084: cmp             SP, x16
    //     0x826088: b.ls            #0x8260c4
    // 0x82608c: LoadField: r0 = r1->field_f
    //     0x82608c: ldur            w0, [x1, #0xf]
    // 0x826090: DecompressPointer r0
    //     0x826090: add             x0, x0, HEAP, lsl #32
    // 0x826094: ldr             x16, [fp, #0x28]
    // 0x826098: stp             x16, x0, [SP, #-0x10]!
    // 0x82609c: ldr             x16, [fp, #0x20]
    // 0x8260a0: ldr             lr, [fp, #0x18]
    // 0x8260a4: stp             lr, x16, [SP, #-0x10]!
    // 0x8260a8: ldr             x16, [fp, #0x10]
    // 0x8260ac: SaveReg r16
    //     0x8260ac: str             x16, [SP, #-8]!
    // 0x8260b0: r0 = _openSkinToneDialog()
    //     0x8260b0: bl              #0x8260cc  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::_openSkinToneDialog
    // 0x8260b4: add             SP, SP, #0x28
    // 0x8260b8: LeaveFrame
    //     0x8260b8: mov             SP, fp
    //     0x8260bc: ldp             fp, lr, [SP], #0x10
    // 0x8260c0: ret
    //     0x8260c0: ret             
    // 0x8260c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8260c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8260c8: b               #0x82608c
  }
  _ _openSkinToneDialog(/* No info */) {
    // ** addr: 0x8260cc, size: 0x64
    // 0x8260cc: EnterFrame
    //     0x8260cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8260d0: mov             fp, SP
    // 0x8260d4: CheckStackOverflow
    //     0x8260d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8260d8: cmp             SP, x16
    //     0x8260dc: b.ls            #0x826124
    // 0x8260e0: ldr             x16, [fp, #0x30]
    // 0x8260e4: SaveReg r16
    //     0x8260e4: str             x16, [SP, #-8]!
    // 0x8260e8: r0 = closeSkinToneOverlay()
    //     0x8260e8: bl              #0x825644  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin&SkinToneOverlayStateMixin::closeSkinToneOverlay
    // 0x8260ec: add             SP, SP, #8
    // 0x8260f0: ldr             x1, [fp, #0x28]
    // 0x8260f4: LoadField: r2 = r1->field_f
    //     0x8260f4: ldur            w2, [x1, #0xf]
    // 0x8260f8: DecompressPointer r2
    //     0x8260f8: add             x2, x2, HEAP, lsl #32
    // 0x8260fc: tbnz            w2, #4, #0x826114
    // 0x826100: ldr             x1, [fp, #0x30]
    // 0x826104: LoadField: r2 = r1->field_b
    //     0x826104: ldur            w2, [x1, #0xb]
    // 0x826108: DecompressPointer r2
    //     0x826108: add             x2, x2, HEAP, lsl #32
    // 0x82610c: cmp             w2, NULL
    // 0x826110: b.eq            #0x82612c
    // 0x826114: r0 = Null
    //     0x826114: mov             x0, NULL
    // 0x826118: LeaveFrame
    //     0x826118: mov             SP, fp
    //     0x82611c: ldp             fp, lr, [SP], #0x10
    // 0x826120: ret
    //     0x826120: ret             
    // 0x826124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x826124: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x826128: b               #0x8260e0
    // 0x82612c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82612c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Category?, Emoji) {
    // ** addr: 0x826130, size: 0xa4
    // 0x826130: EnterFrame
    //     0x826130: stp             fp, lr, [SP, #-0x10]!
    //     0x826134: mov             fp, SP
    // 0x826138: AllocStack(0x8)
    //     0x826138: sub             SP, SP, #8
    // 0x82613c: SetupParameters()
    //     0x82613c: ldr             x0, [fp, #0x20]
    //     0x826140: ldur            w1, [x0, #0x17]
    //     0x826144: add             x1, x1, HEAP, lsl #32
    //     0x826148: stur            x1, [fp, #-8]
    // 0x82614c: CheckStackOverflow
    //     0x82614c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x826150: cmp             SP, x16
    //     0x826154: b.ls            #0x8261c8
    // 0x826158: LoadField: r0 = r1->field_f
    //     0x826158: ldur            w0, [x1, #0xf]
    // 0x82615c: DecompressPointer r0
    //     0x82615c: add             x0, x0, HEAP, lsl #32
    // 0x826160: SaveReg r0
    //     0x826160: str             x0, [SP, #-8]!
    // 0x826164: r0 = closeSkinToneOverlay()
    //     0x826164: bl              #0x825644  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin&SkinToneOverlayStateMixin::closeSkinToneOverlay
    // 0x826168: add             SP, SP, #8
    // 0x82616c: ldur            x0, [fp, #-8]
    // 0x826170: LoadField: r1 = r0->field_f
    //     0x826170: ldur            w1, [x0, #0xf]
    // 0x826174: DecompressPointer r1
    //     0x826174: add             x1, x1, HEAP, lsl #32
    // 0x826178: LoadField: r0 = r1->field_b
    //     0x826178: ldur            w0, [x1, #0xb]
    // 0x82617c: DecompressPointer r0
    //     0x82617c: add             x0, x0, HEAP, lsl #32
    // 0x826180: cmp             w0, NULL
    // 0x826184: b.eq            #0x8261d0
    // 0x826188: LoadField: r1 = r0->field_f
    //     0x826188: ldur            w1, [x0, #0xf]
    // 0x82618c: DecompressPointer r1
    //     0x82618c: add             x1, x1, HEAP, lsl #32
    // 0x826190: LoadField: r0 = r1->field_b
    //     0x826190: ldur            w0, [x1, #0xb]
    // 0x826194: DecompressPointer r0
    //     0x826194: add             x0, x0, HEAP, lsl #32
    // 0x826198: ldr             x16, [fp, #0x18]
    // 0x82619c: stp             x16, x0, [SP, #-0x10]!
    // 0x8261a0: ldr             x16, [fp, #0x10]
    // 0x8261a4: SaveReg r16
    //     0x8261a4: str             x16, [SP, #-8]!
    // 0x8261a8: ClosureCall
    //     0x8261a8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x8261ac: ldur            x2, [x0, #0x1f]
    //     0x8261b0: blr             x2
    // 0x8261b4: add             SP, SP, #0x18
    // 0x8261b8: r0 = Null
    //     0x8261b8: mov             x0, NULL
    // 0x8261bc: LeaveFrame
    //     0x8261bc: mov             SP, fp
    //     0x8261c0: ldp             fp, lr, [SP], #0x10
    // 0x8261c4: ret
    //     0x8261c4: ret             
    // 0x8261c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8261c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8261cc: b               #0x826158
    // 0x8261d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8261d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  ScrollController _scrollController(_DefaultEmojiPickerViewState) {
    // ** addr: 0x8261d4, size: 0x48
    // 0x8261d4: EnterFrame
    //     0x8261d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8261d8: mov             fp, SP
    // 0x8261dc: AllocStack(0x8)
    //     0x8261dc: sub             SP, SP, #8
    // 0x8261e0: CheckStackOverflow
    //     0x8261e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8261e4: cmp             SP, x16
    //     0x8261e8: b.ls            #0x826214
    // 0x8261ec: r0 = ScrollController()
    //     0x8261ec: bl              #0x51ef50  ; AllocateScrollControllerStub -> ScrollController (size=0x38)
    // 0x8261f0: stur            x0, [fp, #-8]
    // 0x8261f4: SaveReg r0
    //     0x8261f4: str             x0, [SP, #-8]!
    // 0x8261f8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8261f8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8261fc: r0 = ScrollController()
    //     0x8261fc: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x826200: add             SP, SP, #8
    // 0x826204: ldur            x0, [fp, #-8]
    // 0x826208: LeaveFrame
    //     0x826208: mov             SP, fp
    //     0x82620c: ldp             fp, lr, [SP], #0x10
    // 0x826210: ret
    //     0x826210: ret             
    // 0x826214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x826214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x826218: b               #0x8261ec
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x82621c, size: 0xac
    // 0x82621c: EnterFrame
    //     0x82621c: stp             fp, lr, [SP, #-0x10]!
    //     0x826220: mov             fp, SP
    // 0x826224: ldr             x0, [fp, #0x18]
    // 0x826228: LoadField: r1 = r0->field_17
    //     0x826228: ldur            w1, [x0, #0x17]
    // 0x82622c: DecompressPointer r1
    //     0x82622c: add             x1, x1, HEAP, lsl #32
    // 0x826230: CheckStackOverflow
    //     0x826230: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x826234: cmp             SP, x16
    //     0x826238: b.ls            #0x8262b0
    // 0x82623c: LoadField: r0 = r1->field_b
    //     0x82623c: ldur            w0, [x1, #0xb]
    // 0x826240: DecompressPointer r0
    //     0x826240: add             x0, x0, HEAP, lsl #32
    // 0x826244: LoadField: r1 = r0->field_f
    //     0x826244: ldur            w1, [x0, #0xf]
    // 0x826248: DecompressPointer r1
    //     0x826248: add             x1, x1, HEAP, lsl #32
    // 0x82624c: LoadField: r0 = r1->field_2b
    //     0x82624c: ldur            w0, [x1, #0x2b]
    // 0x826250: DecompressPointer r0
    //     0x826250: add             x0, x0, HEAP, lsl #32
    // 0x826254: r16 = Sentinel
    //     0x826254: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x826258: cmp             w0, w16
    // 0x82625c: b.eq            #0x8262b8
    // 0x826260: LoadField: r2 = r1->field_b
    //     0x826260: ldur            w2, [x1, #0xb]
    // 0x826264: DecompressPointer r2
    //     0x826264: add             x2, x2, HEAP, lsl #32
    // 0x826268: cmp             w2, NULL
    // 0x82626c: b.eq            #0x8262c4
    // 0x826270: ldr             x1, [fp, #0x10]
    // 0x826274: r2 = LoadInt32Instr(r1)
    //     0x826274: sbfx            x2, x1, #1, #0x1f
    //     0x826278: tbz             w1, #0, #0x826280
    //     0x82627c: ldur            x2, [x1, #7]
    // 0x826280: stp             x2, x0, [SP, #-0x10]!
    // 0x826284: r16 = Instance_Duration
    //     0x826284: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x826288: ldr             x16, [x16, #0xc88]
    // 0x82628c: SaveReg r16
    //     0x82628c: str             x16, [SP, #-8]!
    // 0x826290: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x826290: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x826294: ldr             x4, [x4, #0xa0]
    // 0x826298: r0 = animateTo()
    //     0x826298: bl              #0x8262c8  ; [package:flutter/src/material/tab_controller.dart] TabController::animateTo
    // 0x82629c: add             SP, SP, #0x18
    // 0x8262a0: r0 = Null
    //     0x8262a0: mov             x0, NULL
    // 0x8262a4: LeaveFrame
    //     0x8262a4: mov             SP, fp
    //     0x8262a8: ldp             fp, lr, [SP], #0x10
    // 0x8262ac: ret
    //     0x8262ac: ret             
    // 0x8262b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8262b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8262b4: b               #0x82623c
    // 0x8262b8: r9 = _tabController
    //     0x8262b8: add             x9, PP, #0x53, lsl #12  ; [pp+0x53a18] Field <_DefaultEmojiPickerViewState@394000349._tabController@394000349>: late (offset: 0x2c)
    //     0x8262bc: ldr             x9, [x9, #0xa18]
    // 0x8262c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8262c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8262c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8262c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d58c0, size: 0x234
    // 0x9d58c0: EnterFrame
    //     0x9d58c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9d58c4: mov             fp, SP
    // 0x9d58c8: AllocStack(0x20)
    //     0x9d58c8: sub             SP, SP, #0x20
    // 0x9d58cc: CheckStackOverflow
    //     0x9d58cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d58d0: cmp             SP, x16
    //     0x9d58d4: b.ls            #0x9d5ae4
    // 0x9d58d8: r1 = 1
    //     0x9d58d8: mov             x1, #1
    // 0x9d58dc: r0 = AllocateContext()
    //     0x9d58dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d58e0: mov             x1, x0
    // 0x9d58e4: ldr             x0, [fp, #0x10]
    // 0x9d58e8: StoreField: r1->field_f = r0
    //     0x9d58e8: stur            w0, [x1, #0xf]
    // 0x9d58ec: LoadField: r2 = r0->field_b
    //     0x9d58ec: ldur            w2, [x0, #0xb]
    // 0x9d58f0: DecompressPointer r2
    //     0x9d58f0: add             x2, x2, HEAP, lsl #32
    // 0x9d58f4: cmp             w2, NULL
    // 0x9d58f8: b.eq            #0x9d5aec
    // 0x9d58fc: LoadField: r3 = r2->field_f
    //     0x9d58fc: ldur            w3, [x2, #0xf]
    // 0x9d5900: DecompressPointer r3
    //     0x9d5900: add             x3, x3, HEAP, lsl #32
    // 0x9d5904: LoadField: r4 = r3->field_7
    //     0x9d5904: ldur            w4, [x3, #7]
    // 0x9d5908: DecompressPointer r4
    //     0x9d5908: add             x4, x4, HEAP, lsl #32
    // 0x9d590c: mov             x2, x1
    // 0x9d5910: stur            x4, [fp, #-8]
    // 0x9d5914: r1 = Function '<anonymous closure>':.
    //     0x9d5914: add             x1, PP, #0x53, lsl #12  ; [pp+0x53aa0] AnonymousClosure: (0x9d5de0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::initState (0x9d58c0)
    //     0x9d5918: ldr             x1, [x1, #0xaa0]
    // 0x9d591c: r0 = AllocateClosure()
    //     0x9d591c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d5920: ldur            x16, [fp, #-8]
    // 0x9d5924: stp             x0, x16, [SP, #-0x10]!
    // 0x9d5928: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9d5928: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9d592c: r0 = indexWhere()
    //     0x9d592c: bl              #0x5ee3a4  ; [dart:collection] _ListBase&Object&ListMixin::indexWhere
    // 0x9d5930: add             SP, SP, #0x10
    // 0x9d5934: cmn             x0, #1
    // 0x9d5938: b.ne            #0x9d5944
    // 0x9d593c: r3 = 0
    //     0x9d593c: mov             x3, #0
    // 0x9d5940: b               #0x9d5948
    // 0x9d5944: mov             x3, x0
    // 0x9d5948: ldr             x2, [fp, #0x10]
    // 0x9d594c: stur            x3, [fp, #-0x18]
    // 0x9d5950: LoadField: r0 = r2->field_b
    //     0x9d5950: ldur            w0, [x2, #0xb]
    // 0x9d5954: DecompressPointer r0
    //     0x9d5954: add             x0, x0, HEAP, lsl #32
    // 0x9d5958: cmp             w0, NULL
    // 0x9d595c: b.eq            #0x9d5af0
    // 0x9d5960: LoadField: r1 = r0->field_f
    //     0x9d5960: ldur            w1, [x0, #0xf]
    // 0x9d5964: DecompressPointer r1
    //     0x9d5964: add             x1, x1, HEAP, lsl #32
    // 0x9d5968: LoadField: r0 = r1->field_7
    //     0x9d5968: ldur            w0, [x1, #7]
    // 0x9d596c: DecompressPointer r0
    //     0x9d596c: add             x0, x0, HEAP, lsl #32
    // 0x9d5970: LoadField: r4 = r0->field_b
    //     0x9d5970: ldur            w4, [x0, #0xb]
    // 0x9d5974: DecompressPointer r4
    //     0x9d5974: add             x4, x4, HEAP, lsl #32
    // 0x9d5978: r0 = BoxInt64Instr(r3)
    //     0x9d5978: sbfiz           x0, x3, #1, #0x1f
    //     0x9d597c: cmp             x3, x0, asr #1
    //     0x9d5980: b.eq            #0x9d598c
    //     0x9d5984: bl              #0xd69bb8
    //     0x9d5988: stur            x3, [x0, #7]
    // 0x9d598c: stur            x0, [fp, #-8]
    // 0x9d5990: r1 = LoadInt32Instr(r4)
    //     0x9d5990: sbfx            x1, x4, #1, #0x1f
    // 0x9d5994: stur            x1, [fp, #-0x10]
    // 0x9d5998: r0 = TabController()
    //     0x9d5998: bl              #0x7bc0ac  ; AllocateTabControllerStub -> TabController (size=0x4c)
    // 0x9d599c: stur            x0, [fp, #-0x20]
    // 0x9d59a0: SaveReg r0
    //     0x9d59a0: str             x0, [SP, #-8]!
    // 0x9d59a4: ldur            x1, [fp, #-0x10]
    // 0x9d59a8: ldr             x16, [fp, #0x10]
    // 0x9d59ac: stp             x16, x1, [SP, #-0x10]!
    // 0x9d59b0: ldur            x16, [fp, #-8]
    // 0x9d59b4: SaveReg r16
    //     0x9d59b4: str             x16, [SP, #-8]!
    // 0x9d59b8: r4 = const [0, 0x4, 0x4, 0x3, initialIndex, 0x3, null]
    //     0x9d59b8: add             x4, PP, #0x27, lsl #12  ; [pp+0x270c8] List(7) [0, 0x4, 0x4, 0x3, "initialIndex", 0x3, Null]
    //     0x9d59bc: ldr             x4, [x4, #0xc8]
    // 0x9d59c0: r0 = TabController()
    //     0x9d59c0: bl              #0x9d5af4  ; [package:flutter/src/material/tab_controller.dart] TabController::TabController
    // 0x9d59c4: add             SP, SP, #0x20
    // 0x9d59c8: ldur            x0, [fp, #-0x20]
    // 0x9d59cc: ldr             x1, [fp, #0x10]
    // 0x9d59d0: StoreField: r1->field_2b = r0
    //     0x9d59d0: stur            w0, [x1, #0x2b]
    //     0x9d59d4: ldurb           w16, [x1, #-1]
    //     0x9d59d8: ldurb           w17, [x0, #-1]
    //     0x9d59dc: and             x16, x17, x16, lsr #2
    //     0x9d59e0: tst             x16, HEAP, lsr #32
    //     0x9d59e4: b.eq            #0x9d59ec
    //     0x9d59e8: bl              #0xd6826c
    // 0x9d59ec: r0 = PageController()
    //     0x9d59ec: bl              #0x8243ac  ; AllocatePageControllerStub -> PageController (size=0x4c)
    // 0x9d59f0: mov             x1, x0
    // 0x9d59f4: ldur            x0, [fp, #-0x18]
    // 0x9d59f8: stur            x1, [fp, #-8]
    // 0x9d59fc: StoreField: r1->field_37 = r0
    //     0x9d59fc: stur            x0, [x1, #0x37]
    // 0x9d5a00: r0 = true
    //     0x9d5a00: add             x0, NULL, #0x20  ; true
    // 0x9d5a04: StoreField: r1->field_3f = r0
    //     0x9d5a04: stur            w0, [x1, #0x3f]
    // 0x9d5a08: d0 = 1.000000
    //     0x9d5a08: fmov            d0, #1.00000000
    // 0x9d5a0c: StoreField: r1->field_43 = d0
    //     0x9d5a0c: stur            d0, [x1, #0x43]
    // 0x9d5a10: SaveReg r1
    //     0x9d5a10: str             x1, [SP, #-8]!
    // 0x9d5a14: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9d5a14: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9d5a18: r0 = ScrollController()
    //     0x9d5a18: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9d5a1c: add             SP, SP, #8
    // 0x9d5a20: r1 = 1
    //     0x9d5a20: mov             x1, #1
    // 0x9d5a24: r0 = AllocateContext()
    //     0x9d5a24: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d5a28: mov             x1, x0
    // 0x9d5a2c: ldr             x0, [fp, #0x10]
    // 0x9d5a30: StoreField: r1->field_f = r0
    //     0x9d5a30: stur            w0, [x1, #0xf]
    // 0x9d5a34: mov             x2, x1
    // 0x9d5a38: r1 = Function 'closeSkinToneOverlay':.
    //     0x9d5a38: add             x1, PP, #0x53, lsl #12  ; [pp+0x53a08] AnonymousClosure: (0x8256a0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin&SkinToneOverlayStateMixin::closeSkinToneOverlay (0x825644)
    //     0x9d5a3c: ldr             x1, [x1, #0xa08]
    // 0x9d5a40: r0 = AllocateClosure()
    //     0x9d5a40: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d5a44: ldur            x16, [fp, #-8]
    // 0x9d5a48: stp             x0, x16, [SP, #-0x10]!
    // 0x9d5a4c: r0 = addListener()
    //     0x9d5a4c: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9d5a50: add             SP, SP, #0x10
    // 0x9d5a54: ldur            x0, [fp, #-8]
    // 0x9d5a58: ldr             x2, [fp, #0x10]
    // 0x9d5a5c: StoreField: r2->field_27 = r0
    //     0x9d5a5c: stur            w0, [x2, #0x27]
    //     0x9d5a60: ldurb           w16, [x2, #-1]
    //     0x9d5a64: ldurb           w17, [x0, #-1]
    //     0x9d5a68: and             x16, x17, x16, lsr #2
    //     0x9d5a6c: tst             x16, HEAP, lsr #32
    //     0x9d5a70: b.eq            #0x9d5a78
    //     0x9d5a74: bl              #0xd6828c
    // 0x9d5a78: mov             x1, x2
    // 0x9d5a7c: LoadField: r0 = r1->field_2f
    //     0x9d5a7c: ldur            w0, [x1, #0x2f]
    // 0x9d5a80: DecompressPointer r0
    //     0x9d5a80: add             x0, x0, HEAP, lsl #32
    // 0x9d5a84: r16 = Sentinel
    //     0x9d5a84: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d5a88: cmp             w0, w16
    // 0x9d5a8c: b.ne            #0x9d5a9c
    // 0x9d5a90: r2 = _scrollController
    //     0x9d5a90: add             x2, PP, #0x53, lsl #12  ; [pp+0x539f0] Field <_DefaultEmojiPickerViewState@394000349._scrollController@394000349>: late final (offset: 0x30)
    //     0x9d5a94: ldr             x2, [x2, #0x9f0]
    // 0x9d5a98: r0 = InitLateFinalInstanceField()
    //     0x9d5a98: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x9d5a9c: stur            x0, [fp, #-8]
    // 0x9d5aa0: r1 = 1
    //     0x9d5aa0: mov             x1, #1
    // 0x9d5aa4: r0 = AllocateContext()
    //     0x9d5aa4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d5aa8: mov             x1, x0
    // 0x9d5aac: ldr             x0, [fp, #0x10]
    // 0x9d5ab0: StoreField: r1->field_f = r0
    //     0x9d5ab0: stur            w0, [x1, #0xf]
    // 0x9d5ab4: mov             x2, x1
    // 0x9d5ab8: r1 = Function 'closeSkinToneOverlay':.
    //     0x9d5ab8: add             x1, PP, #0x53, lsl #12  ; [pp+0x53a08] AnonymousClosure: (0x8256a0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin&SkinToneOverlayStateMixin::closeSkinToneOverlay (0x825644)
    //     0x9d5abc: ldr             x1, [x1, #0xa08]
    // 0x9d5ac0: r0 = AllocateClosure()
    //     0x9d5ac0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d5ac4: ldur            x16, [fp, #-8]
    // 0x9d5ac8: stp             x0, x16, [SP, #-0x10]!
    // 0x9d5acc: r0 = addListener()
    //     0x9d5acc: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9d5ad0: add             SP, SP, #0x10
    // 0x9d5ad4: r0 = Null
    //     0x9d5ad4: mov             x0, NULL
    // 0x9d5ad8: LeaveFrame
    //     0x9d5ad8: mov             SP, fp
    //     0x9d5adc: ldp             fp, lr, [SP], #0x10
    // 0x9d5ae0: ret
    //     0x9d5ae0: ret             
    // 0x9d5ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d5ae4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d5ae8: b               #0x9d58d8
    // 0x9d5aec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d5aec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d5af0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d5af0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, CategoryEmoji) {
    // ** addr: 0x9d5de0, size: 0x60
    // 0x9d5de0: EnterFrame
    //     0x9d5de0: stp             fp, lr, [SP, #-0x10]!
    //     0x9d5de4: mov             fp, SP
    // 0x9d5de8: ldr             x1, [fp, #0x18]
    // 0x9d5dec: LoadField: r2 = r1->field_17
    //     0x9d5dec: ldur            w2, [x1, #0x17]
    // 0x9d5df0: DecompressPointer r2
    //     0x9d5df0: add             x2, x2, HEAP, lsl #32
    // 0x9d5df4: ldr             x1, [fp, #0x10]
    // 0x9d5df8: LoadField: r3 = r1->field_7
    //     0x9d5df8: ldur            w3, [x1, #7]
    // 0x9d5dfc: DecompressPointer r3
    //     0x9d5dfc: add             x3, x3, HEAP, lsl #32
    // 0x9d5e00: LoadField: r1 = r2->field_f
    //     0x9d5e00: ldur            w1, [x2, #0xf]
    // 0x9d5e04: DecompressPointer r1
    //     0x9d5e04: add             x1, x1, HEAP, lsl #32
    // 0x9d5e08: LoadField: r2 = r1->field_b
    //     0x9d5e08: ldur            w2, [x1, #0xb]
    // 0x9d5e0c: DecompressPointer r2
    //     0x9d5e0c: add             x2, x2, HEAP, lsl #32
    // 0x9d5e10: cmp             w2, NULL
    // 0x9d5e14: b.eq            #0x9d5e3c
    // 0x9d5e18: r16 = Instance_Category
    //     0x9d5e18: add             x16, PP, #0x41, lsl #12  ; [pp+0x41090] Obj!Category@b664f1
    //     0x9d5e1c: ldr             x16, [x16, #0x90]
    // 0x9d5e20: cmp             w3, w16
    // 0x9d5e24: r16 = true
    //     0x9d5e24: add             x16, NULL, #0x20  ; true
    // 0x9d5e28: r17 = false
    //     0x9d5e28: add             x17, NULL, #0x30  ; false
    // 0x9d5e2c: csel            x0, x16, x17, eq
    // 0x9d5e30: LeaveFrame
    //     0x9d5e30: mov             SP, fp
    //     0x9d5e34: ldp             fp, lr, [SP], #0x10
    // 0x9d5e38: ret
    //     0x9d5e38: ret             
    // 0x9d5e3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d5e3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a048, size: 0x18
    // 0xa4a048: r4 = 7
    //     0xa4a048: mov             x4, #7
    // 0xa4a04c: r1 = Function 'dispose':.
    //     0xa4a04c: add             x17, PP, #0x53, lsl #12  ; [pp+0x539c8] AnonymousClosure: (0xa4a060), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::dispose (0xa4e890)
    //     0xa4a050: ldr             x1, [x17, #0x9c8]
    // 0xa4a054: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a054: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a058: LoadField: r0 = r24->field_17
    //     0xa4a058: ldur            x0, [x24, #0x17]
    // 0xa4a05c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a060, size: 0x48
    // 0xa4a060: EnterFrame
    //     0xa4a060: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a064: mov             fp, SP
    // 0xa4a068: ldr             x0, [fp, #0x10]
    // 0xa4a06c: LoadField: r1 = r0->field_17
    //     0xa4a06c: ldur            w1, [x0, #0x17]
    // 0xa4a070: DecompressPointer r1
    //     0xa4a070: add             x1, x1, HEAP, lsl #32
    // 0xa4a074: CheckStackOverflow
    //     0xa4a074: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a078: cmp             SP, x16
    //     0xa4a07c: b.ls            #0xa4a0a0
    // 0xa4a080: LoadField: r0 = r1->field_f
    //     0xa4a080: ldur            w0, [x1, #0xf]
    // 0xa4a084: DecompressPointer r0
    //     0xa4a084: add             x0, x0, HEAP, lsl #32
    // 0xa4a088: SaveReg r0
    //     0xa4a088: str             x0, [SP, #-8]!
    // 0xa4a08c: r0 = dispose()
    //     0xa4a08c: bl              #0xa4e890  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] _DefaultEmojiPickerViewState::dispose
    // 0xa4a090: add             SP, SP, #8
    // 0xa4a094: LeaveFrame
    //     0xa4a094: mov             SP, fp
    //     0xa4a098: ldp             fp, lr, [SP], #0x10
    // 0xa4a09c: ret
    //     0xa4a09c: ret             
    // 0xa4a0a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a0a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a0a4: b               #0xa4a080
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4e890, size: 0xdc
    // 0xa4e890: EnterFrame
    //     0xa4e890: stp             fp, lr, [SP, #-0x10]!
    //     0xa4e894: mov             fp, SP
    // 0xa4e898: CheckStackOverflow
    //     0xa4e898: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4e89c: cmp             SP, x16
    //     0xa4e8a0: b.ls            #0xa4e94c
    // 0xa4e8a4: ldr             x16, [fp, #0x10]
    // 0xa4e8a8: SaveReg r16
    //     0xa4e8a8: str             x16, [SP, #-8]!
    // 0xa4e8ac: r0 = closeSkinToneOverlay()
    //     0xa4e8ac: bl              #0x825644  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin&SkinToneOverlayStateMixin::closeSkinToneOverlay
    // 0xa4e8b0: add             SP, SP, #8
    // 0xa4e8b4: ldr             x1, [fp, #0x10]
    // 0xa4e8b8: LoadField: r0 = r1->field_27
    //     0xa4e8b8: ldur            w0, [x1, #0x27]
    // 0xa4e8bc: DecompressPointer r0
    //     0xa4e8bc: add             x0, x0, HEAP, lsl #32
    // 0xa4e8c0: r16 = Sentinel
    //     0xa4e8c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4e8c4: cmp             w0, w16
    // 0xa4e8c8: b.eq            #0xa4e954
    // 0xa4e8cc: SaveReg r0
    //     0xa4e8cc: str             x0, [SP, #-8]!
    // 0xa4e8d0: r0 = dispose()
    //     0xa4e8d0: bl              #0x9c2054  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0xa4e8d4: add             SP, SP, #8
    // 0xa4e8d8: ldr             x1, [fp, #0x10]
    // 0xa4e8dc: LoadField: r0 = r1->field_2b
    //     0xa4e8dc: ldur            w0, [x1, #0x2b]
    // 0xa4e8e0: DecompressPointer r0
    //     0xa4e8e0: add             x0, x0, HEAP, lsl #32
    // 0xa4e8e4: r16 = Sentinel
    //     0xa4e8e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4e8e8: cmp             w0, w16
    // 0xa4e8ec: b.eq            #0xa4e960
    // 0xa4e8f0: SaveReg r0
    //     0xa4e8f0: str             x0, [SP, #-8]!
    // 0xa4e8f4: r0 = dispose()
    //     0xa4e8f4: bl              #0x9c2804  ; [package:flutter/src/material/tab_controller.dart] TabController::dispose
    // 0xa4e8f8: add             SP, SP, #8
    // 0xa4e8fc: ldr             x1, [fp, #0x10]
    // 0xa4e900: LoadField: r0 = r1->field_2f
    //     0xa4e900: ldur            w0, [x1, #0x2f]
    // 0xa4e904: DecompressPointer r0
    //     0xa4e904: add             x0, x0, HEAP, lsl #32
    // 0xa4e908: r16 = Sentinel
    //     0xa4e908: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4e90c: cmp             w0, w16
    // 0xa4e910: b.ne            #0xa4e920
    // 0xa4e914: r2 = _scrollController
    //     0xa4e914: add             x2, PP, #0x53, lsl #12  ; [pp+0x539f0] Field <_DefaultEmojiPickerViewState@394000349._scrollController@394000349>: late final (offset: 0x30)
    //     0xa4e918: ldr             x2, [x2, #0x9f0]
    // 0xa4e91c: r0 = InitLateFinalInstanceField()
    //     0xa4e91c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xa4e920: SaveReg r0
    //     0xa4e920: str             x0, [SP, #-8]!
    // 0xa4e924: r0 = dispose()
    //     0xa4e924: bl              #0x9c2054  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0xa4e928: add             SP, SP, #8
    // 0xa4e92c: ldr             x16, [fp, #0x10]
    // 0xa4e930: SaveReg r16
    //     0xa4e930: str             x16, [SP, #-8]!
    // 0xa4e934: r0 = dispose()
    //     0xa4e934: bl              #0xa4e96c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::dispose
    // 0xa4e938: add             SP, SP, #8
    // 0xa4e93c: r0 = Null
    //     0xa4e93c: mov             x0, NULL
    // 0xa4e940: LeaveFrame
    //     0xa4e940: mov             SP, fp
    //     0xa4e944: ldp             fp, lr, [SP], #0x10
    // 0xa4e948: ret
    //     0xa4e948: ret             
    // 0xa4e94c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4e94c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4e950: b               #0xa4e8a4
    // 0xa4e954: r9 = _pageController
    //     0xa4e954: add             x9, PP, #0x53, lsl #12  ; [pp+0x539e8] Field <_DefaultEmojiPickerViewState@394000349._pageController@394000349>: late (offset: 0x28)
    //     0xa4e958: ldr             x9, [x9, #0x9e8]
    // 0xa4e95c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4e95c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa4e960: r9 = _tabController
    //     0xa4e960: add             x9, PP, #0x53, lsl #12  ; [pp+0x53a18] Field <_DefaultEmojiPickerViewState@394000349._tabController@394000349>: late (offset: 0x2c)
    //     0xa4e964: ldr             x9, [x9, #0xa18]
    // 0xa4e968: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4e968: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4219, size: 0x14, field offset: 0x14
class DefaultEmojiPickerView extends EmojiPickerBuilder {

  _ createState(/* No info */) {
    // ** addr: 0xa3eff8, size: 0x40
    // 0xa3eff8: EnterFrame
    //     0xa3eff8: stp             fp, lr, [SP, #-0x10]!
    //     0xa3effc: mov             fp, SP
    // 0xa3f000: r1 = <DefaultEmojiPickerView>
    //     0xa3f000: add             x1, PP, #0x51, lsl #12  ; [pp+0x51478] TypeArguments: <DefaultEmojiPickerView>
    //     0xa3f004: ldr             x1, [x1, #0x478]
    // 0xa3f008: r0 = _DefaultEmojiPickerViewState()
    //     0xa3f008: bl              #0xa3f038  ; Allocate_DefaultEmojiPickerViewStateStub -> _DefaultEmojiPickerViewState (size=0x38)
    // 0xa3f00c: d0 = 46.000000
    //     0xa3f00c: add             x17, PP, #0x23, lsl #12  ; [pp+0x239f8] IMM: double(46) from 0x4047000000000000
    //     0xa3f010: ldr             d0, [x17, #0x9f8]
    // 0xa3f014: StoreField: r0->field_1f = d0
    //     0xa3f014: stur            d0, [x0, #0x1f]
    // 0xa3f018: r1 = Sentinel
    //     0xa3f018: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3f01c: StoreField: r0->field_27 = r1
    //     0xa3f01c: stur            w1, [x0, #0x27]
    // 0xa3f020: StoreField: r0->field_2b = r1
    //     0xa3f020: stur            w1, [x0, #0x2b]
    // 0xa3f024: StoreField: r0->field_2f = r1
    //     0xa3f024: stur            w1, [x0, #0x2f]
    // 0xa3f028: StoreField: r0->field_33 = r1
    //     0xa3f028: stur            w1, [x0, #0x33]
    // 0xa3f02c: LeaveFrame
    //     0xa3f02c: mov             SP, fp
    //     0xa3f030: ldp             fp, lr, [SP], #0x10
    // 0xa3f034: ret
    //     0xa3f034: ret             
  }
}

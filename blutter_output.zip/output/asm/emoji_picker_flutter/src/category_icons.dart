// lib: , url: package:emoji_picker_flutter/src/category_icons.dart

// class id: 1048906, size: 0x8
class :: {
}

// class id: 4521, size: 0x2c, field offset: 0x8
//   const constructor, 
class CategoryIcons extends Object {

  IconData field_8;
  IconData field_c;
  IconData field_10;
  IconData field_14;
  IconData field_18;
  IconData field_1c;
  IconData field_20;
  IconData field_24;
  IconData field_28;
}

// lib: , url: package:emoji_picker_flutter/src/category_emoji.dart

// class id: 1048904, size: 0x8
class :: {
}

// class id: 4522, size: 0x10, field offset: 0x8
//   const constructor, 
class CategoryEmoji extends Object {

  Category field_8;
  _ImmutableList<Emoji> field_c;

  _ copyWith(/* No info */) {
    // ** addr: 0x7993b8, size: 0x3c
    // 0x7993b8: EnterFrame
    //     0x7993b8: stp             fp, lr, [SP, #-0x10]!
    //     0x7993bc: mov             fp, SP
    // 0x7993c0: AllocStack(0x8)
    //     0x7993c0: sub             SP, SP, #8
    // 0x7993c4: ldr             x0, [fp, #0x18]
    // 0x7993c8: LoadField: r1 = r0->field_7
    //     0x7993c8: ldur            w1, [x0, #7]
    // 0x7993cc: DecompressPointer r1
    //     0x7993cc: add             x1, x1, HEAP, lsl #32
    // 0x7993d0: stur            x1, [fp, #-8]
    // 0x7993d4: r0 = CategoryEmoji()
    //     0x7993d4: bl              #0x7996a4  ; AllocateCategoryEmojiStub -> CategoryEmoji (size=0x10)
    // 0x7993d8: ldur            x1, [fp, #-8]
    // 0x7993dc: StoreField: r0->field_7 = r1
    //     0x7993dc: stur            w1, [x0, #7]
    // 0x7993e0: ldr             x1, [fp, #0x10]
    // 0x7993e4: StoreField: r0->field_b = r1
    //     0x7993e4: stur            w1, [x0, #0xb]
    // 0x7993e8: LeaveFrame
    //     0x7993e8: mov             SP, fp
    //     0x7993ec: ldp             fp, lr, [SP], #0x10
    // 0x7993f0: ret
    //     0x7993f0: ret             
  }
}

// lib: , url: package:emoji_picker_flutter/src/config.dart

// class id: 1048907, size: 0x8
class :: {
}

// class id: 4520, size: 0x80, field offset: 0x8
//   const constructor, 
class Config extends Object {

  _Mint field_8;
  _Double field_10;
  _Mint field_18;
  _Mint field_20;
  Category field_28;
  Color field_2c;
  MaterialColor<int> field_30;
  MaterialColor<int> field_34;
  MaterialColor<int> field_38;
  MaterialColor<int> field_3c;
  Color field_40;
  MaterialColor<int> field_44;
  bool field_48;
  RecentTabBehavior field_4c;
  _Mint field_50;
  Text field_58;
  SizedBox field_5c;
  Duration field_60;
  CategoryIcons field_64;
  ButtonMode field_68;
  EdgeInsets field_6c;
  bool field_70;
  bool field_74;

  _ getIconForCategory(/* No info */) {
    // ** addr: 0x82582c, size: 0x130
    // 0x82582c: EnterFrame
    //     0x82582c: stp             fp, lr, [SP, #-0x10]!
    //     0x825830: mov             fp, SP
    // 0x825834: ldr             x0, [fp, #0x10]
    // 0x825838: LoadField: r1 = r0->field_7
    //     0x825838: ldur            x1, [x0, #7]
    // 0x82583c: cmp             x1, #4
    // 0x825840: b.gt            #0x8258c8
    // 0x825844: cmp             x1, #2
    // 0x825848: b.gt            #0x825898
    // 0x82584c: cmp             x1, #1
    // 0x825850: b.gt            #0x825884
    // 0x825854: cmp             x1, #0
    // 0x825858: b.gt            #0x825870
    // 0x82585c: r0 = Instance_IconData
    //     0x82585c: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a50] Obj!IconData@b33bf1
    //     0x825860: ldr             x0, [x0, #0xa50]
    // 0x825864: LeaveFrame
    //     0x825864: mov             SP, fp
    //     0x825868: ldp             fp, lr, [SP], #0x10
    // 0x82586c: ret
    //     0x82586c: ret             
    // 0x825870: r0 = Instance_IconData
    //     0x825870: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a58] Obj!IconData@b33bd1
    //     0x825874: ldr             x0, [x0, #0xa58]
    // 0x825878: LeaveFrame
    //     0x825878: mov             SP, fp
    //     0x82587c: ldp             fp, lr, [SP], #0x10
    // 0x825880: ret
    //     0x825880: ret             
    // 0x825884: r0 = Instance_IconData
    //     0x825884: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a60] Obj!IconData@b33bb1
    //     0x825888: ldr             x0, [x0, #0xa60]
    // 0x82588c: LeaveFrame
    //     0x82588c: mov             SP, fp
    //     0x825890: ldp             fp, lr, [SP], #0x10
    // 0x825894: ret
    //     0x825894: ret             
    // 0x825898: cmp             x1, #3
    // 0x82589c: b.gt            #0x8258b4
    // 0x8258a0: r0 = Instance_IconData
    //     0x8258a0: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a68] Obj!IconData@b33b91
    //     0x8258a4: ldr             x0, [x0, #0xa68]
    // 0x8258a8: LeaveFrame
    //     0x8258a8: mov             SP, fp
    //     0x8258ac: ldp             fp, lr, [SP], #0x10
    // 0x8258b0: ret
    //     0x8258b0: ret             
    // 0x8258b4: r0 = Instance_IconData
    //     0x8258b4: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a70] Obj!IconData@b33b71
    //     0x8258b8: ldr             x0, [x0, #0xa70]
    // 0x8258bc: LeaveFrame
    //     0x8258bc: mov             SP, fp
    //     0x8258c0: ldp             fp, lr, [SP], #0x10
    // 0x8258c4: ret
    //     0x8258c4: ret             
    // 0x8258c8: cmp             x1, #6
    // 0x8258cc: b.gt            #0x825900
    // 0x8258d0: cmp             x1, #5
    // 0x8258d4: b.gt            #0x8258ec
    // 0x8258d8: r0 = Instance_IconData
    //     0x8258d8: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a78] Obj!IconData@b33b51
    //     0x8258dc: ldr             x0, [x0, #0xa78]
    // 0x8258e0: LeaveFrame
    //     0x8258e0: mov             SP, fp
    //     0x8258e4: ldp             fp, lr, [SP], #0x10
    // 0x8258e8: ret
    //     0x8258e8: ret             
    // 0x8258ec: r0 = Instance_IconData
    //     0x8258ec: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a80] Obj!IconData@b33b31
    //     0x8258f0: ldr             x0, [x0, #0xa80]
    // 0x8258f4: LeaveFrame
    //     0x8258f4: mov             SP, fp
    //     0x8258f8: ldp             fp, lr, [SP], #0x10
    // 0x8258fc: ret
    //     0x8258fc: ret             
    // 0x825900: cmp             x1, #7
    // 0x825904: b.gt            #0x82591c
    // 0x825908: r0 = Instance_IconData
    //     0x825908: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a88] Obj!IconData@b33b11
    //     0x82590c: ldr             x0, [x0, #0xa88]
    // 0x825910: LeaveFrame
    //     0x825910: mov             SP, fp
    //     0x825914: ldp             fp, lr, [SP], #0x10
    // 0x825918: ret
    //     0x825918: ret             
    // 0x82591c: lsl             x0, x1, #1
    // 0x825920: cmp             w0, #0x10
    // 0x825924: b.ne            #0x82593c
    // 0x825928: r0 = Instance_IconData
    //     0x825928: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a90] Obj!IconData@b33af1
    //     0x82592c: ldr             x0, [x0, #0xa90]
    // 0x825930: LeaveFrame
    //     0x825930: mov             SP, fp
    //     0x825934: ldp             fp, lr, [SP], #0x10
    // 0x825938: ret
    //     0x825938: ret             
    // 0x82593c: r0 = _Exception()
    //     0x82593c: bl              #0x4eda04  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x825940: mov             x1, x0
    // 0x825944: r0 = "Unsupported Category"
    //     0x825944: add             x0, PP, #0x53, lsl #12  ; [pp+0x53a98] "Unsupported Category"
    //     0x825948: ldr             x0, [x0, #0xa98]
    // 0x82594c: StoreField: r1->field_7 = r0
    //     0x82594c: stur            w0, [x1, #7]
    // 0x825950: mov             x0, x1
    // 0x825954: r0 = Throw()
    //     0x825954: bl              #0xd67e38  ; ThrowStub
    // 0x825958: brk             #0
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafa9ec, size: 0x3ec
    // 0xafa9ec: EnterFrame
    //     0xafa9ec: stp             fp, lr, [SP, #-0x10]!
    //     0xafa9f0: mov             fp, SP
    // 0xafa9f4: AllocStack(0x10)
    //     0xafa9f4: sub             SP, SP, #0x10
    // 0xafa9f8: d0 = 0.000000
    //     0xafa9f8: eor             v0.16b, v0.16b, v0.16b
    // 0xafa9fc: CheckStackOverflow
    //     0xafa9fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafaa00: cmp             SP, x16
    //     0xafaa04: b.ls            #0xafadd0
    // 0xafaa08: ldr             x0, [fp, #0x10]
    // 0xafaa0c: LoadField: r1 = r0->field_7
    //     0xafaa0c: ldur            x1, [x0, #7]
    // 0xafaa10: lsl             x2, x1, #1
    // 0xafaa14: r16 = LoadInt32Instr(r2)
    //     0xafaa14: sbfx            x16, x2, #1, #0x1f
    // 0xafaa18: r17 = 11601
    //     0xafaa18: mov             x17, #0x2d51
    // 0xafaa1c: mul             x1, x16, x17
    // 0xafaa20: umulh           x16, x16, x17
    // 0xafaa24: eor             x1, x1, x16
    // 0xafaa28: r1 = 0
    //     0xafaa28: eor             x1, x1, x1, lsr #32
    // 0xafaa2c: ubfiz           x1, x1, #1, #0x1e
    // 0xafaa30: LoadField: d1 = r0->field_f
    //     0xafaa30: ldur            d1, [x0, #0xf]
    // 0xafaa34: mov             x16, v1.d[0]
    // 0xafaa38: and             x16, x16, #0x7ff0000000000000
    // 0xafaa3c: r17 = 9218868437227405312
    //     0xafaa3c: mov             x17, #0x7ff0000000000000
    // 0xafaa40: cmp             x16, x17
    // 0xafaa44: b.eq            #0xafaa74
    // 0xafaa48: fcvtzs          x16, d1
    // 0xafaa4c: scvtf           d2, x16
    // 0xafaa50: fcmp            d2, d1
    // 0xafaa54: b.ne            #0xafaa74
    // 0xafaa58: r17 = 11601
    //     0xafaa58: mov             x17, #0x2d51
    // 0xafaa5c: mul             x2, x16, x17
    // 0xafaa60: umulh           x16, x16, x17
    // 0xafaa64: eor             x2, x2, x16
    // 0xafaa68: r2 = 0
    //     0xafaa68: eor             x2, x2, x2, lsr #32
    // 0xafaa6c: and             x2, x2, #0x3fffffff
    // 0xafaa70: b               #0xafaa80
    // 0xafaa74: r2 = 0.000000
    //     0xafaa74: fmov            x2, d1
    // 0xafaa78: r2 = 0
    //     0xafaa78: eor             x2, x2, x2, lsr #32
    // 0xafaa7c: and             x2, x2, #0x3fffffff
    // 0xafaa80: r3 = LoadInt32Instr(r1)
    //     0xafaa80: sbfx            x3, x1, #1, #0x1f
    // 0xafaa84: eor             x1, x3, x2
    // 0xafaa88: mov             x16, v0.d[0]
    // 0xafaa8c: and             x16, x16, #0x7ff0000000000000
    // 0xafaa90: r17 = 9218868437227405312
    //     0xafaa90: mov             x17, #0x7ff0000000000000
    // 0xafaa94: cmp             x16, x17
    // 0xafaa98: b.eq            #0xafaac8
    // 0xafaa9c: fcvtzs          x16, d0
    // 0xafaaa0: scvtf           d1, x16
    // 0xafaaa4: fcmp            d1, d0
    // 0xafaaa8: b.ne            #0xafaac8
    // 0xafaaac: r17 = 11601
    //     0xafaaac: mov             x17, #0x2d51
    // 0xafaab0: mul             x2, x16, x17
    // 0xafaab4: umulh           x16, x16, x17
    // 0xafaab8: eor             x2, x2, x16
    // 0xafaabc: r2 = 0
    //     0xafaabc: eor             x2, x2, x2, lsr #32
    // 0xafaac0: and             x2, x2, #0x3fffffff
    // 0xafaac4: b               #0xafaad4
    // 0xafaac8: r2 = 0.000000
    //     0xafaac8: fmov            x2, d0
    // 0xafaacc: r2 = 0
    //     0xafaacc: eor             x2, x2, x2, lsr #32
    // 0xafaad0: and             x2, x2, #0x3fffffff
    // 0xafaad4: eor             x3, x1, x2
    // 0xafaad8: eor             x1, x3, x2
    // 0xafaadc: stur            x1, [fp, #-8]
    // 0xafaae0: r16 = Instance_Category
    //     0xafaae0: add             x16, PP, #0x41, lsl #12  ; [pp+0x41090] Obj!Category@b664f1
    //     0xafaae4: ldr             x16, [x16, #0x90]
    // 0xafaae8: SaveReg r16
    //     0xafaae8: str             x16, [SP, #-8]!
    // 0xafaaec: r0 = _getHash()
    //     0xafaaec: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xafaaf0: add             SP, SP, #8
    // 0xafaaf4: r1 = LoadInt32Instr(r0)
    //     0xafaaf4: sbfx            x1, x0, #1, #0x1f
    // 0xafaaf8: ldur            x0, [fp, #-8]
    // 0xafaafc: eor             x2, x0, x1
    // 0xafab00: ldr             x0, [fp, #0x10]
    // 0xafab04: stur            x2, [fp, #-0x10]
    // 0xafab08: LoadField: r1 = r0->field_2b
    //     0xafab08: ldur            w1, [x0, #0x2b]
    // 0xafab0c: DecompressPointer r1
    //     0xafab0c: add             x1, x1, HEAP, lsl #32
    // 0xafab10: SaveReg r1
    //     0xafab10: str             x1, [SP, #-8]!
    // 0xafab14: r0 = hashCode()
    //     0xafab14: bl              #0xaf8d28  ; [dart:ui] Color::hashCode
    // 0xafab18: add             SP, SP, #8
    // 0xafab1c: r1 = LoadInt32Instr(r0)
    //     0xafab1c: sbfx            x1, x0, #1, #0x1f
    //     0xafab20: tbz             w0, #0, #0xafab28
    //     0xafab24: ldur            x1, [x0, #7]
    // 0xafab28: ldur            x0, [fp, #-0x10]
    // 0xafab2c: eor             x2, x0, x1
    // 0xafab30: stur            x2, [fp, #-8]
    // 0xafab34: r16 = Instance_MaterialColor
    //     0xafab34: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0xafab38: ldr             x16, [x16, #0xf28]
    // 0xafab3c: SaveReg r16
    //     0xafab3c: str             x16, [SP, #-8]!
    // 0xafab40: r0 = hashCode()
    //     0xafab40: bl              #0xaf8c9c  ; [package:flutter/src/painting/colors.dart] ColorSwatch::hashCode
    // 0xafab44: add             SP, SP, #8
    // 0xafab48: r1 = LoadInt32Instr(r0)
    //     0xafab48: sbfx            x1, x0, #1, #0x1f
    //     0xafab4c: tbz             w0, #0, #0xafab54
    //     0xafab50: ldur            x1, [x0, #7]
    // 0xafab54: ldur            x0, [fp, #-8]
    // 0xafab58: eor             x2, x0, x1
    // 0xafab5c: stur            x2, [fp, #-0x10]
    // 0xafab60: r16 = Instance_MaterialColor
    //     0xafab60: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f8d0] Obj!MaterialColor<int>@b5e3f1
    //     0xafab64: ldr             x16, [x16, #0x8d0]
    // 0xafab68: SaveReg r16
    //     0xafab68: str             x16, [SP, #-8]!
    // 0xafab6c: r0 = hashCode()
    //     0xafab6c: bl              #0xaf8c9c  ; [package:flutter/src/painting/colors.dart] ColorSwatch::hashCode
    // 0xafab70: add             SP, SP, #8
    // 0xafab74: r1 = LoadInt32Instr(r0)
    //     0xafab74: sbfx            x1, x0, #1, #0x1f
    //     0xafab78: tbz             w0, #0, #0xafab80
    //     0xafab7c: ldur            x1, [x0, #7]
    // 0xafab80: ldur            x0, [fp, #-0x10]
    // 0xafab84: eor             x2, x0, x1
    // 0xafab88: stur            x2, [fp, #-8]
    // 0xafab8c: r16 = Instance_MaterialColor
    //     0xafab8c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0xafab90: ldr             x16, [x16, #0xf28]
    // 0xafab94: SaveReg r16
    //     0xafab94: str             x16, [SP, #-8]!
    // 0xafab98: r0 = hashCode()
    //     0xafab98: bl              #0xaf8c9c  ; [package:flutter/src/painting/colors.dart] ColorSwatch::hashCode
    // 0xafab9c: add             SP, SP, #8
    // 0xafaba0: r1 = LoadInt32Instr(r0)
    //     0xafaba0: sbfx            x1, x0, #1, #0x1f
    //     0xafaba4: tbz             w0, #0, #0xafabac
    //     0xafaba8: ldur            x1, [x0, #7]
    // 0xafabac: ldur            x0, [fp, #-8]
    // 0xafabb0: eor             x2, x0, x1
    // 0xafabb4: stur            x2, [fp, #-0x10]
    // 0xafabb8: r16 = Instance_MaterialColor
    //     0xafabb8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0xafabbc: ldr             x16, [x16, #0xf28]
    // 0xafabc0: SaveReg r16
    //     0xafabc0: str             x16, [SP, #-8]!
    // 0xafabc4: r0 = hashCode()
    //     0xafabc4: bl              #0xaf8c9c  ; [package:flutter/src/painting/colors.dart] ColorSwatch::hashCode
    // 0xafabc8: add             SP, SP, #8
    // 0xafabcc: r1 = LoadInt32Instr(r0)
    //     0xafabcc: sbfx            x1, x0, #1, #0x1f
    //     0xafabd0: tbz             w0, #0, #0xafabd8
    //     0xafabd4: ldur            x1, [x0, #7]
    // 0xafabd8: ldur            x0, [fp, #-0x10]
    // 0xafabdc: eor             x2, x0, x1
    // 0xafabe0: stur            x2, [fp, #-8]
    // 0xafabe4: r16 = Instance_Color
    //     0xafabe4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0xafabe8: ldr             x16, [x16, #0xbe8]
    // 0xafabec: SaveReg r16
    //     0xafabec: str             x16, [SP, #-8]!
    // 0xafabf0: r0 = hashCode()
    //     0xafabf0: bl              #0xaf8d28  ; [dart:ui] Color::hashCode
    // 0xafabf4: add             SP, SP, #8
    // 0xafabf8: r1 = LoadInt32Instr(r0)
    //     0xafabf8: sbfx            x1, x0, #1, #0x1f
    //     0xafabfc: tbz             w0, #0, #0xafac04
    //     0xafac00: ldur            x1, [x0, #7]
    // 0xafac04: ldur            x0, [fp, #-8]
    // 0xafac08: eor             x2, x0, x1
    // 0xafac0c: stur            x2, [fp, #-0x10]
    // 0xafac10: r16 = Instance_MaterialColor
    //     0xafac10: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f8d0] Obj!MaterialColor<int>@b5e3f1
    //     0xafac14: ldr             x16, [x16, #0x8d0]
    // 0xafac18: SaveReg r16
    //     0xafac18: str             x16, [SP, #-8]!
    // 0xafac1c: r0 = hashCode()
    //     0xafac1c: bl              #0xaf8c9c  ; [package:flutter/src/painting/colors.dart] ColorSwatch::hashCode
    // 0xafac20: add             SP, SP, #8
    // 0xafac24: r1 = LoadInt32Instr(r0)
    //     0xafac24: sbfx            x1, x0, #1, #0x1f
    //     0xafac28: tbz             w0, #0, #0xafac30
    //     0xafac2c: ldur            x1, [x0, #7]
    // 0xafac30: ldur            x0, [fp, #-0x10]
    // 0xafac34: eor             x2, x0, x1
    // 0xafac38: ldr             x0, [fp, #0x10]
    // 0xafac3c: LoadField: r1 = r0->field_47
    //     0xafac3c: ldur            w1, [x0, #0x47]
    // 0xafac40: DecompressPointer r1
    //     0xafac40: add             x1, x1, HEAP, lsl #32
    // 0xafac44: tst             x1, #0x10
    // 0xafac48: cset            x3, ne
    // 0xafac4c: sub             x3, x3, #1
    // 0xafac50: r16 = -12
    //     0xafac50: mov             x16, #-0xc
    // 0xafac54: and             x3, x3, x16
    // 0xafac58: add             x3, x3, #0x9aa
    // 0xafac5c: r1 = LoadInt32Instr(r3)
    //     0xafac5c: sbfx            x1, x3, #1, #0x1f
    // 0xafac60: eor             x3, x2, x1
    // 0xafac64: stur            x3, [fp, #-8]
    // 0xafac68: r16 = Instance_RecentTabBehavior
    //     0xafac68: add             x16, PP, #0x41, lsl #12  ; [pp+0x41098] Obj!RecentTabBehavior@b663b1
    //     0xafac6c: ldr             x16, [x16, #0x98]
    // 0xafac70: SaveReg r16
    //     0xafac70: str             x16, [SP, #-8]!
    // 0xafac74: r0 = _getHash()
    //     0xafac74: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xafac78: add             SP, SP, #8
    // 0xafac7c: r1 = LoadInt32Instr(r0)
    //     0xafac7c: sbfx            x1, x0, #1, #0x1f
    // 0xafac80: ldur            x0, [fp, #-8]
    // 0xafac84: eor             x2, x0, x1
    // 0xafac88: ldr             x0, [fp, #0x10]
    // 0xafac8c: LoadField: r1 = r0->field_4f
    //     0xafac8c: ldur            x1, [x0, #0x4f]
    // 0xafac90: lsl             x3, x1, #1
    // 0xafac94: r16 = LoadInt32Instr(r3)
    //     0xafac94: sbfx            x16, x3, #1, #0x1f
    // 0xafac98: r17 = 11601
    //     0xafac98: mov             x17, #0x2d51
    // 0xafac9c: mul             x1, x16, x17
    // 0xafaca0: umulh           x16, x16, x17
    // 0xafaca4: eor             x1, x1, x16
    // 0xafaca8: r1 = 0
    //     0xafaca8: eor             x1, x1, x1, lsr #32
    // 0xafacac: ubfiz           x1, x1, #1, #0x1e
    // 0xafacb0: r3 = LoadInt32Instr(r1)
    //     0xafacb0: sbfx            x3, x1, #1, #0x1f
    // 0xafacb4: eor             x1, x2, x3
    // 0xafacb8: stur            x1, [fp, #-8]
    // 0xafacbc: LoadField: r2 = r0->field_57
    //     0xafacbc: ldur            w2, [x0, #0x57]
    // 0xafacc0: DecompressPointer r2
    //     0xafacc0: add             x2, x2, HEAP, lsl #32
    // 0xafacc4: SaveReg r2
    //     0xafacc4: str             x2, [SP, #-8]!
    // 0xafacc8: r0 = _getHash()
    //     0xafacc8: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xafaccc: add             SP, SP, #8
    // 0xafacd0: r1 = LoadInt32Instr(r0)
    //     0xafacd0: sbfx            x1, x0, #1, #0x1f
    // 0xafacd4: ldur            x0, [fp, #-8]
    // 0xafacd8: eor             x2, x0, x1
    // 0xafacdc: stur            x2, [fp, #-0x10]
    // 0xaface0: r16 = Instance_SizedBox
    //     0xaface0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0xaface4: ldr             x16, [x16, #0x738]
    // 0xaface8: SaveReg r16
    //     0xaface8: str             x16, [SP, #-8]!
    // 0xafacec: r0 = _getHash()
    //     0xafacec: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xafacf0: add             SP, SP, #8
    // 0xafacf4: r1 = LoadInt32Instr(r0)
    //     0xafacf4: sbfx            x1, x0, #1, #0x1f
    // 0xafacf8: ldur            x0, [fp, #-0x10]
    // 0xafacfc: eor             x2, x0, x1
    // 0xafad00: r0 = 600000
    //     0xafad00: mov             x0, #0x27c0
    //     0xafad04: movk            x0, #9, lsl #16
    // 0xafad08: r16 = LoadInt32Instr(r0)
    //     0xafad08: sbfx            x16, x0, #1, #0x1f
    // 0xafad0c: r17 = 11601
    //     0xafad0c: mov             x17, #0x2d51
    // 0xafad10: mul             x1, x16, x17
    // 0xafad14: umulh           x16, x16, x17
    // 0xafad18: eor             x1, x1, x16
    // 0xafad1c: r1 = 0
    //     0xafad1c: eor             x1, x1, x1, lsr #32
    // 0xafad20: ubfiz           x1, x1, #1, #0x1e
    // 0xafad24: r0 = LoadInt32Instr(r1)
    //     0xafad24: sbfx            x0, x1, #1, #0x1f
    // 0xafad28: eor             x1, x2, x0
    // 0xafad2c: stur            x1, [fp, #-8]
    // 0xafad30: r16 = Instance_CategoryIcons
    //     0xafad30: add             x16, PP, #0x41, lsl #12  ; [pp+0x410a0] Obj!CategoryIcons@b5c721
    //     0xafad34: ldr             x16, [x16, #0xa0]
    // 0xafad38: SaveReg r16
    //     0xafad38: str             x16, [SP, #-8]!
    // 0xafad3c: r0 = _getHash()
    //     0xafad3c: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xafad40: add             SP, SP, #8
    // 0xafad44: r1 = LoadInt32Instr(r0)
    //     0xafad44: sbfx            x1, x0, #1, #0x1f
    // 0xafad48: ldur            x0, [fp, #-8]
    // 0xafad4c: eor             x2, x0, x1
    // 0xafad50: stur            x2, [fp, #-0x10]
    // 0xafad54: r16 = Instance_ButtonMode
    //     0xafad54: add             x16, PP, #0x41, lsl #12  ; [pp+0x410a8] Obj!ButtonMode@b663d1
    //     0xafad58: ldr             x16, [x16, #0xa8]
    // 0xafad5c: SaveReg r16
    //     0xafad5c: str             x16, [SP, #-8]!
    // 0xafad60: r0 = _getHash()
    //     0xafad60: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xafad64: add             SP, SP, #8
    // 0xafad68: r1 = LoadInt32Instr(r0)
    //     0xafad68: sbfx            x1, x0, #1, #0x1f
    // 0xafad6c: ldur            x0, [fp, #-0x10]
    // 0xafad70: eor             x2, x0, x1
    // 0xafad74: stur            x2, [fp, #-8]
    // 0xafad78: r16 = Instance_EdgeInsets
    //     0xafad78: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xafad7c: ldr             x16, [x16, #0xbd8]
    // 0xafad80: SaveReg r16
    //     0xafad80: str             x16, [SP, #-8]!
    // 0xafad84: r0 = hashCode()
    //     0xafad84: bl              #0xb0e458  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::hashCode
    // 0xafad88: add             SP, SP, #8
    // 0xafad8c: r2 = LoadInt32Instr(r0)
    //     0xafad8c: sbfx            x2, x0, #1, #0x1f
    //     0xafad90: tbz             w0, #0, #0xafad98
    //     0xafad94: ldur            x2, [x0, #7]
    // 0xafad98: ldur            x3, [fp, #-8]
    // 0xafad9c: eor             x4, x3, x2
    // 0xafada0: r16 = 1237
    //     0xafada0: mov             x16, #0x4d5
    // 0xafada4: eor             x2, x4, x16
    // 0xafada8: r16 = 1231
    //     0xafada8: mov             x16, #0x4cf
    // 0xafadac: eor             x3, x2, x16
    // 0xafadb0: r0 = BoxInt64Instr(r3)
    //     0xafadb0: sbfiz           x0, x3, #1, #0x1f
    //     0xafadb4: cmp             x3, x0, asr #1
    //     0xafadb8: b.eq            #0xafadc4
    //     0xafadbc: bl              #0xd69bb8
    //     0xafadc0: stur            x3, [x0, #7]
    // 0xafadc4: LeaveFrame
    //     0xafadc4: mov             SP, fp
    //     0xafadc8: ldp             fp, lr, [SP], #0x10
    // 0xafadcc: ret
    //     0xafadcc: ret             
    // 0xafadd0: r0 = StackOverflowSharedWithFPURegs()
    //     0xafadd0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xafadd4: b               #0xafaa08
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6f310, size: 0x230
    // 0xc6f310: EnterFrame
    //     0xc6f310: stp             fp, lr, [SP, #-0x10]!
    //     0xc6f314: mov             fp, SP
    // 0xc6f318: AllocStack(0x10)
    //     0xc6f318: sub             SP, SP, #0x10
    // 0xc6f31c: CheckStackOverflow
    //     0xc6f31c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6f320: cmp             SP, x16
    //     0xc6f324: b.ls            #0xc6f538
    // 0xc6f328: ldr             x0, [fp, #0x10]
    // 0xc6f32c: cmp             w0, NULL
    // 0xc6f330: b.ne            #0xc6f344
    // 0xc6f334: r0 = false
    //     0xc6f334: add             x0, NULL, #0x30  ; false
    // 0xc6f338: LeaveFrame
    //     0xc6f338: mov             SP, fp
    //     0xc6f33c: ldp             fp, lr, [SP], #0x10
    // 0xc6f340: ret
    //     0xc6f340: ret             
    // 0xc6f344: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6f344: mov             x1, #0x76
    //     0xc6f348: tbz             w0, #0, #0xc6f358
    //     0xc6f34c: ldur            x1, [x0, #-1]
    //     0xc6f350: ubfx            x1, x1, #0xc, #0x14
    //     0xc6f354: lsl             x1, x1, #1
    // 0xc6f358: r17 = 9040
    //     0xc6f358: mov             x17, #0x2350
    // 0xc6f35c: cmp             w1, w17
    // 0xc6f360: b.ne            #0xc6f528
    // 0xc6f364: ldr             x1, [fp, #0x18]
    // 0xc6f368: LoadField: r2 = r0->field_7
    //     0xc6f368: ldur            x2, [x0, #7]
    // 0xc6f36c: LoadField: r3 = r1->field_7
    //     0xc6f36c: ldur            x3, [x1, #7]
    // 0xc6f370: lsl             x4, x2, #1
    // 0xc6f374: lsl             x2, x3, #1
    // 0xc6f378: cmp             w4, w2
    // 0xc6f37c: b.ne            #0xc6f528
    // 0xc6f380: LoadField: d0 = r0->field_f
    //     0xc6f380: ldur            d0, [x0, #0xf]
    // 0xc6f384: LoadField: d1 = r1->field_f
    //     0xc6f384: ldur            d1, [x1, #0xf]
    // 0xc6f388: fcmp            d0, d1
    // 0xc6f38c: b.vs            #0xc6f528
    // 0xc6f390: b.ne            #0xc6f528
    // 0xc6f394: d0 = 0.000000
    //     0xc6f394: eor             v0.16b, v0.16b, v0.16b
    // 0xc6f398: fcmp            d0, d0
    // 0xc6f39c: b.vs            #0xc6f3a4
    // 0xc6f3a0: b.eq            #0xc6f3ac
    // 0xc6f3a4: r2 = false
    //     0xc6f3a4: add             x2, NULL, #0x30  ; false
    // 0xc6f3a8: b               #0xc6f3b0
    // 0xc6f3ac: r2 = true
    //     0xc6f3ac: add             x2, NULL, #0x20  ; true
    // 0xc6f3b0: tbnz            w2, #4, #0xc6f528
    // 0xc6f3b4: tbnz            w2, #4, #0xc6f528
    // 0xc6f3b8: LoadField: r2 = r0->field_2b
    //     0xc6f3b8: ldur            w2, [x0, #0x2b]
    // 0xc6f3bc: DecompressPointer r2
    //     0xc6f3bc: add             x2, x2, HEAP, lsl #32
    // 0xc6f3c0: stur            x2, [fp, #-0x10]
    // 0xc6f3c4: LoadField: r3 = r1->field_2b
    //     0xc6f3c4: ldur            w3, [x1, #0x2b]
    // 0xc6f3c8: DecompressPointer r3
    //     0xc6f3c8: add             x3, x3, HEAP, lsl #32
    // 0xc6f3cc: stur            x3, [fp, #-8]
    // 0xc6f3d0: cmp             w2, w3
    // 0xc6f3d4: b.eq            #0xc6f410
    // 0xc6f3d8: r16 = Color
    //     0xc6f3d8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc6f3dc: ldr             x16, [x16, #0xf18]
    // 0xc6f3e0: r30 = Color
    //     0xc6f3e0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc6f3e4: ldr             lr, [lr, #0xf18]
    // 0xc6f3e8: stp             lr, x16, [SP, #-0x10]!
    // 0xc6f3ec: r0 = ==()
    //     0xc6f3ec: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc6f3f0: add             SP, SP, #0x10
    // 0xc6f3f4: tbnz            w0, #4, #0xc6f528
    // 0xc6f3f8: ldur            x0, [fp, #-0x10]
    // 0xc6f3fc: ldur            x1, [fp, #-8]
    // 0xc6f400: LoadField: r2 = r1->field_7
    //     0xc6f400: ldur            x2, [x1, #7]
    // 0xc6f404: LoadField: r1 = r0->field_7
    //     0xc6f404: ldur            x1, [x0, #7]
    // 0xc6f408: cmp             x2, x1
    // 0xc6f40c: b.ne            #0xc6f528
    // 0xc6f410: r16 = Instance_MaterialColor
    //     0xc6f410: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0xc6f414: ldr             x16, [x16, #0xf28]
    // 0xc6f418: r30 = Instance_MaterialColor
    //     0xc6f418: add             lr, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0xc6f41c: ldr             lr, [lr, #0xf28]
    // 0xc6f420: stp             lr, x16, [SP, #-0x10]!
    // 0xc6f424: r0 = ==()
    //     0xc6f424: bl              #0xc668f8  ; [package:flutter/src/painting/colors.dart] ColorSwatch::==
    // 0xc6f428: add             SP, SP, #0x10
    // 0xc6f42c: tbnz            w0, #4, #0xc6f528
    // 0xc6f430: r16 = Instance_MaterialColor
    //     0xc6f430: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f8d0] Obj!MaterialColor<int>@b5e3f1
    //     0xc6f434: ldr             x16, [x16, #0x8d0]
    // 0xc6f438: r30 = Instance_MaterialColor
    //     0xc6f438: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2f8d0] Obj!MaterialColor<int>@b5e3f1
    //     0xc6f43c: ldr             lr, [lr, #0x8d0]
    // 0xc6f440: stp             lr, x16, [SP, #-0x10]!
    // 0xc6f444: r0 = ==()
    //     0xc6f444: bl              #0xc668f8  ; [package:flutter/src/painting/colors.dart] ColorSwatch::==
    // 0xc6f448: add             SP, SP, #0x10
    // 0xc6f44c: tbnz            w0, #4, #0xc6f528
    // 0xc6f450: r16 = Instance_MaterialColor
    //     0xc6f450: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0xc6f454: ldr             x16, [x16, #0xf28]
    // 0xc6f458: r30 = Instance_MaterialColor
    //     0xc6f458: add             lr, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0xc6f45c: ldr             lr, [lr, #0xf28]
    // 0xc6f460: stp             lr, x16, [SP, #-0x10]!
    // 0xc6f464: r0 = ==()
    //     0xc6f464: bl              #0xc668f8  ; [package:flutter/src/painting/colors.dart] ColorSwatch::==
    // 0xc6f468: add             SP, SP, #0x10
    // 0xc6f46c: tbnz            w0, #4, #0xc6f528
    // 0xc6f470: r16 = Instance_MaterialColor
    //     0xc6f470: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0xc6f474: ldr             x16, [x16, #0xf28]
    // 0xc6f478: r30 = Instance_MaterialColor
    //     0xc6f478: add             lr, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0xc6f47c: ldr             lr, [lr, #0xf28]
    // 0xc6f480: stp             lr, x16, [SP, #-0x10]!
    // 0xc6f484: r0 = ==()
    //     0xc6f484: bl              #0xc668f8  ; [package:flutter/src/painting/colors.dart] ColorSwatch::==
    // 0xc6f488: add             SP, SP, #0x10
    // 0xc6f48c: tbnz            w0, #4, #0xc6f528
    // 0xc6f490: r16 = Instance_MaterialColor
    //     0xc6f490: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f8d0] Obj!MaterialColor<int>@b5e3f1
    //     0xc6f494: ldr             x16, [x16, #0x8d0]
    // 0xc6f498: r30 = Instance_MaterialColor
    //     0xc6f498: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2f8d0] Obj!MaterialColor<int>@b5e3f1
    //     0xc6f49c: ldr             lr, [lr, #0x8d0]
    // 0xc6f4a0: stp             lr, x16, [SP, #-0x10]!
    // 0xc6f4a4: r0 = ==()
    //     0xc6f4a4: bl              #0xc668f8  ; [package:flutter/src/painting/colors.dart] ColorSwatch::==
    // 0xc6f4a8: add             SP, SP, #0x10
    // 0xc6f4ac: tbnz            w0, #4, #0xc6f528
    // 0xc6f4b0: ldr             x1, [fp, #0x18]
    // 0xc6f4b4: ldr             x0, [fp, #0x10]
    // 0xc6f4b8: LoadField: r2 = r0->field_47
    //     0xc6f4b8: ldur            w2, [x0, #0x47]
    // 0xc6f4bc: DecompressPointer r2
    //     0xc6f4bc: add             x2, x2, HEAP, lsl #32
    // 0xc6f4c0: LoadField: r3 = r1->field_47
    //     0xc6f4c0: ldur            w3, [x1, #0x47]
    // 0xc6f4c4: DecompressPointer r3
    //     0xc6f4c4: add             x3, x3, HEAP, lsl #32
    // 0xc6f4c8: cmp             w2, w3
    // 0xc6f4cc: b.ne            #0xc6f528
    // 0xc6f4d0: LoadField: r2 = r0->field_4f
    //     0xc6f4d0: ldur            x2, [x0, #0x4f]
    // 0xc6f4d4: LoadField: r3 = r1->field_4f
    //     0xc6f4d4: ldur            x3, [x1, #0x4f]
    // 0xc6f4d8: lsl             x4, x2, #1
    // 0xc6f4dc: lsl             x2, x3, #1
    // 0xc6f4e0: cmp             w4, w2
    // 0xc6f4e4: b.ne            #0xc6f528
    // 0xc6f4e8: LoadField: r2 = r0->field_57
    //     0xc6f4e8: ldur            w2, [x0, #0x57]
    // 0xc6f4ec: DecompressPointer r2
    //     0xc6f4ec: add             x2, x2, HEAP, lsl #32
    // 0xc6f4f0: LoadField: r0 = r1->field_57
    //     0xc6f4f0: ldur            w0, [x1, #0x57]
    // 0xc6f4f4: DecompressPointer r0
    //     0xc6f4f4: add             x0, x0, HEAP, lsl #32
    // 0xc6f4f8: cmp             w2, w0
    // 0xc6f4fc: b.ne            #0xc6f528
    // 0xc6f500: r16 = Instance_EdgeInsets
    //     0xc6f500: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xc6f504: ldr             x16, [x16, #0xbd8]
    // 0xc6f508: r30 = Instance_EdgeInsets
    //     0xc6f508: add             lr, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xc6f50c: ldr             lr, [lr, #0xbd8]
    // 0xc6f510: stp             lr, x16, [SP, #-0x10]!
    // 0xc6f514: r0 = ==()
    //     0xc6f514: bl              #0xc9d2f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0xc6f518: add             SP, SP, #0x10
    // 0xc6f51c: tbnz            w0, #4, #0xc6f528
    // 0xc6f520: r0 = true
    //     0xc6f520: add             x0, NULL, #0x20  ; true
    // 0xc6f524: b               #0xc6f52c
    // 0xc6f528: r0 = false
    //     0xc6f528: add             x0, NULL, #0x30  ; false
    // 0xc6f52c: LeaveFrame
    //     0xc6f52c: mov             SP, fp
    //     0xc6f530: ldp             fp, lr, [SP], #0x10
    // 0xc6f534: ret
    //     0xc6f534: ret             
    // 0xc6f538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6f538: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6f53c: b               #0xc6f328
  }
}

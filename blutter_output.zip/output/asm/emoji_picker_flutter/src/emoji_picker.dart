// lib: , url: package:emoji_picker_flutter/src/emoji_picker.dart

// class id: 1048913, size: 0x8
class :: {
}

// class id: 3404, size: 0x28, field offset: 0x14
class EmojiPickerState extends State<EmojiPicker> {

  late EmojiViewState _state; // offset: 0x1c

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x798a6c, size: 0xf4
    // 0x798a6c: EnterFrame
    //     0x798a6c: stp             fp, lr, [SP, #-0x10]!
    //     0x798a70: mov             fp, SP
    // 0x798a74: CheckStackOverflow
    //     0x798a74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x798a78: cmp             SP, x16
    //     0x798a7c: b.ls            #0x798b54
    // 0x798a80: ldr             x0, [fp, #0x10]
    // 0x798a84: r2 = Null
    //     0x798a84: mov             x2, NULL
    // 0x798a88: r1 = Null
    //     0x798a88: mov             x1, NULL
    // 0x798a8c: r4 = 59
    //     0x798a8c: mov             x4, #0x3b
    // 0x798a90: branchIfSmi(r0, 0x798a9c)
    //     0x798a90: tbz             w0, #0, #0x798a9c
    // 0x798a94: r4 = LoadClassIdInstr(r0)
    //     0x798a94: ldur            x4, [x0, #-1]
    //     0x798a98: ubfx            x4, x4, #0xc, #0x14
    // 0x798a9c: r17 = 4217
    //     0x798a9c: mov             x17, #0x1079
    // 0x798aa0: cmp             x4, x17
    // 0x798aa4: b.eq            #0x798abc
    // 0x798aa8: r8 = EmojiPicker
    //     0x798aa8: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4c7a8] Type: EmojiPicker
    //     0x798aac: ldr             x8, [x8, #0x7a8]
    // 0x798ab0: r3 = Null
    //     0x798ab0: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c7b0] Null
    //     0x798ab4: ldr             x3, [x3, #0x7b0]
    // 0x798ab8: r0 = EmojiPicker()
    //     0x798ab8: bl              #0x79afc0  ; IsType_EmojiPicker_Stub
    // 0x798abc: ldr             x0, [fp, #0x18]
    // 0x798ac0: LoadField: r1 = r0->field_b
    //     0x798ac0: ldur            w1, [x0, #0xb]
    // 0x798ac4: DecompressPointer r1
    //     0x798ac4: add             x1, x1, HEAP, lsl #32
    // 0x798ac8: cmp             w1, NULL
    // 0x798acc: b.eq            #0x798b5c
    // 0x798ad0: r16 = Instance_Config
    //     0x798ad0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b10] Obj!Config@b5c6a1
    //     0x798ad4: ldr             x16, [x16, #0xb10]
    // 0x798ad8: r30 = Instance_Config
    //     0x798ad8: add             lr, PP, #0x32, lsl #12  ; [pp+0x32b10] Obj!Config@b5c6a1
    //     0x798adc: ldr             lr, [lr, #0xb10]
    // 0x798ae0: stp             lr, x16, [SP, #-0x10]!
    // 0x798ae4: r0 = ==()
    //     0x798ae4: bl              #0xc6f310  ; [package:emoji_picker_flutter/src/config.dart] Config::==
    // 0x798ae8: add             SP, SP, #0x10
    // 0x798aec: tbz             w0, #4, #0x798b08
    // 0x798af0: ldr             x0, [fp, #0x18]
    // 0x798af4: r1 = false
    //     0x798af4: add             x1, NULL, #0x30  ; false
    // 0x798af8: StoreField: r0->field_1f = r1
    //     0x798af8: stur            w1, [x0, #0x1f]
    // 0x798afc: SaveReg r0
    //     0x798afc: str             x0, [SP, #-8]!
    // 0x798b00: r0 = _updateEmojis()
    //     0x798b00: bl              #0x798b60  ; [package:emoji_picker_flutter/src/emoji_picker.dart] EmojiPickerState::_updateEmojis
    // 0x798b04: add             SP, SP, #8
    // 0x798b08: ldr             x0, [fp, #0x18]
    // 0x798b0c: LoadField: r2 = r0->field_7
    //     0x798b0c: ldur            w2, [x0, #7]
    // 0x798b10: DecompressPointer r2
    //     0x798b10: add             x2, x2, HEAP, lsl #32
    // 0x798b14: ldr             x0, [fp, #0x10]
    // 0x798b18: r1 = Null
    //     0x798b18: mov             x1, NULL
    // 0x798b1c: cmp             w2, NULL
    // 0x798b20: b.eq            #0x798b44
    // 0x798b24: LoadField: r4 = r2->field_17
    //     0x798b24: ldur            w4, [x2, #0x17]
    // 0x798b28: DecompressPointer r4
    //     0x798b28: add             x4, x4, HEAP, lsl #32
    // 0x798b2c: r8 = X0 bound StatefulWidget
    //     0x798b2c: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x798b30: ldr             x8, [x8, #0x858]
    // 0x798b34: LoadField: r9 = r4->field_7
    //     0x798b34: ldur            x9, [x4, #7]
    // 0x798b38: r3 = Null
    //     0x798b38: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c7c0] Null
    //     0x798b3c: ldr             x3, [x3, #0x7c0]
    // 0x798b40: blr             x9
    // 0x798b44: r0 = Null
    //     0x798b44: mov             x0, NULL
    // 0x798b48: LeaveFrame
    //     0x798b48: mov             SP, fp
    //     0x798b4c: ldp             fp, lr, [SP], #0x10
    // 0x798b50: ret
    //     0x798b50: ret             
    // 0x798b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x798b54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x798b58: b               #0x798a80
    // 0x798b5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x798b5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateEmojis(/* No info */) async {
    // ** addr: 0x798b60, size: 0x368
    // 0x798b60: EnterFrame
    //     0x798b60: stp             fp, lr, [SP, #-0x10]!
    //     0x798b64: mov             fp, SP
    // 0x798b68: AllocStack(0x30)
    //     0x798b68: sub             SP, SP, #0x30
    // 0x798b6c: SetupParameters(EmojiPickerState<EmojiPicker> this /* r1, fp-0x10 */)
    //     0x798b6c: stur            NULL, [fp, #-8]
    //     0x798b70: mov             x0, #0
    //     0x798b74: add             x1, fp, w0, sxtw #2
    //     0x798b78: ldr             x1, [x1, #0x10]
    //     0x798b7c: stur            x1, [fp, #-0x10]
    // 0x798b80: CheckStackOverflow
    //     0x798b80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x798b84: cmp             SP, x16
    //     0x798b88: b.ls            #0x798eb0
    // 0x798b8c: r1 = 1
    //     0x798b8c: mov             x1, #1
    // 0x798b90: r0 = AllocateContext()
    //     0x798b90: bl              #0xd68aa4  ; AllocateContextStub
    // 0x798b94: mov             x2, x0
    // 0x798b98: ldur            x1, [fp, #-0x10]
    // 0x798b9c: stur            x2, [fp, #-0x18]
    // 0x798ba0: StoreField: r2->field_f = r1
    //     0x798ba0: stur            w1, [x2, #0xf]
    // 0x798ba4: InitAsync() -> Future<void?>
    //     0x798ba4: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x798ba8: bl              #0x4b92e4
    // 0x798bac: ldur            x0, [fp, #-0x10]
    // 0x798bb0: LoadField: r1 = r0->field_13
    //     0x798bb0: ldur            w1, [x0, #0x13]
    // 0x798bb4: DecompressPointer r1
    //     0x798bb4: add             x1, x1, HEAP, lsl #32
    // 0x798bb8: stur            x1, [fp, #-0x20]
    // 0x798bbc: SaveReg r1
    //     0x798bbc: str             x1, [SP, #-8]!
    // 0x798bc0: r0 = clear()
    //     0x798bc0: bl              #0xd281bc  ; [dart:core] _GrowableList::clear
    // 0x798bc4: add             SP, SP, #8
    // 0x798bc8: r1 = Null
    //     0x798bc8: mov             x1, NULL
    // 0x798bcc: r2 = 4
    //     0x798bcc: mov             x2, #4
    // 0x798bd0: r0 = AllocateArray()
    //     0x798bd0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x798bd4: stur            x0, [fp, #-0x28]
    // 0x798bd8: r17 = Instance_RecentTabBehavior
    //     0x798bd8: add             x17, PP, #0x41, lsl #12  ; [pp+0x41098] Obj!RecentTabBehavior@b663b1
    //     0x798bdc: ldr             x17, [x17, #0x98]
    // 0x798be0: StoreField: r0->field_f = r17
    //     0x798be0: stur            w17, [x0, #0xf]
    // 0x798be4: r17 = Instance_RecentTabBehavior
    //     0x798be4: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c7d0] Obj!RecentTabBehavior@b66391
    //     0x798be8: ldr             x17, [x17, #0x7d0]
    // 0x798bec: StoreField: r0->field_13 = r17
    //     0x798bec: stur            w17, [x0, #0x13]
    // 0x798bf0: r1 = <RecentTabBehavior>
    //     0x798bf0: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c7d8] TypeArguments: <RecentTabBehavior>
    //     0x798bf4: ldr             x1, [x1, #0x7d8]
    // 0x798bf8: r0 = AllocateGrowableArray()
    //     0x798bf8: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x798bfc: mov             x1, x0
    // 0x798c00: ldur            x0, [fp, #-0x28]
    // 0x798c04: StoreField: r1->field_f = r0
    //     0x798c04: stur            w0, [x1, #0xf]
    // 0x798c08: r0 = 4
    //     0x798c08: mov             x0, #4
    // 0x798c0c: StoreField: r1->field_b = r0
    //     0x798c0c: stur            w0, [x1, #0xb]
    // 0x798c10: ldur            x0, [fp, #-0x10]
    // 0x798c14: LoadField: r2 = r0->field_b
    //     0x798c14: ldur            w2, [x0, #0xb]
    // 0x798c18: DecompressPointer r2
    //     0x798c18: add             x2, x2, HEAP, lsl #32
    // 0x798c1c: cmp             w2, NULL
    // 0x798c20: b.eq            #0x798eb8
    // 0x798c24: r16 = Instance_RecentTabBehavior
    //     0x798c24: add             x16, PP, #0x41, lsl #12  ; [pp+0x41098] Obj!RecentTabBehavior@b663b1
    //     0x798c28: ldr             x16, [x16, #0x98]
    // 0x798c2c: stp             x16, x1, [SP, #-0x10]!
    // 0x798c30: r0 = contains()
    //     0x798c30: bl              #0x786724  ; [dart:collection] _ListBase&Object&ListMixin::contains
    // 0x798c34: add             SP, SP, #0x10
    // 0x798c38: tbnz            w0, #4, #0x798db8
    // 0x798c3c: ldur            x0, [fp, #-0x10]
    // 0x798c40: ldur            x1, [fp, #-0x20]
    // 0x798c44: LoadField: r2 = r0->field_23
    //     0x798c44: ldur            w2, [x0, #0x23]
    // 0x798c48: DecompressPointer r2
    //     0x798c48: add             x2, x2, HEAP, lsl #32
    // 0x798c4c: SaveReg r2
    //     0x798c4c: str             x2, [SP, #-8]!
    // 0x798c50: r0 = getRecentEmojis()
    //     0x798c50: bl              #0x7996b0  ; [package:emoji_picker_flutter/src/emoji_picker_internal_utils.dart] EmojiPickerInternalUtils::getRecentEmojis
    // 0x798c54: add             SP, SP, #8
    // 0x798c58: mov             x1, x0
    // 0x798c5c: stur            x1, [fp, #-0x28]
    // 0x798c60: r0 = Await()
    //     0x798c60: bl              #0x4b8e6c  ; AwaitStub
    // 0x798c64: mov             x4, x0
    // 0x798c68: ldur            x3, [fp, #-0x10]
    // 0x798c6c: stur            x4, [fp, #-0x28]
    // 0x798c70: StoreField: r3->field_17 = r0
    //     0x798c70: stur            w0, [x3, #0x17]
    //     0x798c74: tbz             w0, #0, #0x798c90
    //     0x798c78: ldurb           w16, [x3, #-1]
    //     0x798c7c: ldurb           w17, [x0, #-1]
    //     0x798c80: and             x16, x17, x16, lsr #2
    //     0x798c84: tst             x16, HEAP, lsr #32
    //     0x798c88: b.eq            #0x798c90
    //     0x798c8c: bl              #0xd682ac
    // 0x798c90: r1 = Function '<anonymous closure>':.
    //     0x798c90: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c7e0] Function: [dart:ui] Image::_image (0xd61d9c)
    //     0x798c94: ldr             x1, [x1, #0x7e0]
    // 0x798c98: r2 = Null
    //     0x798c98: mov             x2, NULL
    // 0x798c9c: r0 = AllocateClosure()
    //     0x798c9c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x798ca0: mov             x1, x0
    // 0x798ca4: ldur            x0, [fp, #-0x28]
    // 0x798ca8: r2 = LoadClassIdInstr(r0)
    //     0x798ca8: ldur            x2, [x0, #-1]
    //     0x798cac: ubfx            x2, x2, #0xc, #0x14
    // 0x798cb0: r16 = <Emoji>
    //     0x798cb0: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c7e8] TypeArguments: <Emoji>
    //     0x798cb4: ldr             x16, [x16, #0x7e8]
    // 0x798cb8: stp             x0, x16, [SP, #-0x10]!
    // 0x798cbc: SaveReg r1
    //     0x798cbc: str             x1, [SP, #-8]!
    // 0x798cc0: mov             x0, x2
    // 0x798cc4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x798cc4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x798cc8: r0 = GDT[cid_x0 + 0xc934]()
    //     0x798cc8: mov             x17, #0xc934
    //     0x798ccc: add             lr, x0, x17
    //     0x798cd0: ldr             lr, [x21, lr, lsl #3]
    //     0x798cd4: blr             lr
    // 0x798cd8: add             SP, SP, #0x18
    // 0x798cdc: r1 = LoadClassIdInstr(r0)
    //     0x798cdc: ldur            x1, [x0, #-1]
    //     0x798ce0: ubfx            x1, x1, #0xc, #0x14
    // 0x798ce4: SaveReg r0
    //     0x798ce4: str             x0, [SP, #-8]!
    // 0x798ce8: mov             x0, x1
    // 0x798cec: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x798cec: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x798cf0: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0x798cf0: mov             x17, #0xc8a1
    //     0x798cf4: add             lr, x0, x17
    //     0x798cf8: ldr             lr, [x21, lr, lsl #3]
    //     0x798cfc: blr             lr
    // 0x798d00: add             SP, SP, #8
    // 0x798d04: stur            x0, [fp, #-0x28]
    // 0x798d08: r0 = CategoryEmoji()
    //     0x798d08: bl              #0x7996a4  ; AllocateCategoryEmojiStub -> CategoryEmoji (size=0x10)
    // 0x798d0c: mov             x1, x0
    // 0x798d10: r0 = Instance_Category
    //     0x798d10: add             x0, PP, #0x41, lsl #12  ; [pp+0x41090] Obj!Category@b664f1
    //     0x798d14: ldr             x0, [x0, #0x90]
    // 0x798d18: stur            x1, [fp, #-0x30]
    // 0x798d1c: StoreField: r1->field_7 = r0
    //     0x798d1c: stur            w0, [x1, #7]
    // 0x798d20: ldur            x0, [fp, #-0x28]
    // 0x798d24: StoreField: r1->field_b = r0
    //     0x798d24: stur            w0, [x1, #0xb]
    // 0x798d28: ldur            x0, [fp, #-0x20]
    // 0x798d2c: LoadField: r2 = r0->field_b
    //     0x798d2c: ldur            w2, [x0, #0xb]
    // 0x798d30: DecompressPointer r2
    //     0x798d30: add             x2, x2, HEAP, lsl #32
    // 0x798d34: stur            x2, [fp, #-0x28]
    // 0x798d38: LoadField: r3 = r0->field_f
    //     0x798d38: ldur            w3, [x0, #0xf]
    // 0x798d3c: DecompressPointer r3
    //     0x798d3c: add             x3, x3, HEAP, lsl #32
    // 0x798d40: LoadField: r4 = r3->field_b
    //     0x798d40: ldur            w4, [x3, #0xb]
    // 0x798d44: DecompressPointer r4
    //     0x798d44: add             x4, x4, HEAP, lsl #32
    // 0x798d48: cmp             w2, w4
    // 0x798d4c: b.ne            #0x798d5c
    // 0x798d50: SaveReg r0
    //     0x798d50: str             x0, [SP, #-8]!
    // 0x798d54: r0 = _growToNextCapacity()
    //     0x798d54: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x798d58: add             SP, SP, #8
    // 0x798d5c: ldur            x2, [fp, #-0x20]
    // 0x798d60: ldur            x0, [fp, #-0x28]
    // 0x798d64: r3 = LoadInt32Instr(r0)
    //     0x798d64: sbfx            x3, x0, #1, #0x1f
    // 0x798d68: add             x0, x3, #1
    // 0x798d6c: lsl             x1, x0, #1
    // 0x798d70: StoreField: r2->field_b = r1
    //     0x798d70: stur            w1, [x2, #0xb]
    // 0x798d74: mov             x1, x3
    // 0x798d78: cmp             x1, x0
    // 0x798d7c: b.hs            #0x798ebc
    // 0x798d80: LoadField: r1 = r2->field_f
    //     0x798d80: ldur            w1, [x2, #0xf]
    // 0x798d84: DecompressPointer r1
    //     0x798d84: add             x1, x1, HEAP, lsl #32
    // 0x798d88: ldur            x0, [fp, #-0x30]
    // 0x798d8c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x798d8c: add             x25, x1, x3, lsl #2
    //     0x798d90: add             x25, x25, #0xf
    //     0x798d94: str             w0, [x25]
    //     0x798d98: tbz             w0, #0, #0x798db4
    //     0x798d9c: ldurb           w16, [x1, #-1]
    //     0x798da0: ldurb           w17, [x0, #-1]
    //     0x798da4: and             x16, x17, x16, lsr #2
    //     0x798da8: tst             x16, HEAP, lsr #32
    //     0x798dac: b.eq            #0x798db4
    //     0x798db0: bl              #0xd67e5c
    // 0x798db4: b               #0x798dbc
    // 0x798db8: ldur            x2, [fp, #-0x20]
    // 0x798dbc: ldur            x0, [fp, #-0x10]
    // 0x798dc0: LoadField: r1 = r0->field_b
    //     0x798dc0: ldur            w1, [x0, #0xb]
    // 0x798dc4: DecompressPointer r1
    //     0x798dc4: add             x1, x1, HEAP, lsl #32
    // 0x798dc8: cmp             w1, NULL
    // 0x798dcc: b.eq            #0x798ec0
    // 0x798dd0: LoadField: r1 = r0->field_23
    //     0x798dd0: ldur            w1, [x0, #0x23]
    // 0x798dd4: DecompressPointer r1
    //     0x798dd4: add             x1, x1, HEAP, lsl #32
    // 0x798dd8: SaveReg r1
    //     0x798dd8: str             x1, [SP, #-8]!
    // 0x798ddc: r0 = filterUnsupported()
    //     0x798ddc: bl              #0x798ed4  ; [package:emoji_picker_flutter/src/emoji_picker_internal_utils.dart] EmojiPickerInternalUtils::filterUnsupported
    // 0x798de0: add             SP, SP, #8
    // 0x798de4: mov             x1, x0
    // 0x798de8: stur            x1, [fp, #-0x28]
    // 0x798dec: r0 = Await()
    //     0x798dec: bl              #0x4b8e6c  ; AwaitStub
    // 0x798df0: ldur            x16, [fp, #-0x20]
    // 0x798df4: stp             x0, x16, [SP, #-0x10]!
    // 0x798df8: r0 = addAll()
    //     0x798df8: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x798dfc: add             SP, SP, #0x10
    // 0x798e00: r1 = 1
    //     0x798e00: mov             x1, #1
    // 0x798e04: r0 = AllocateContext()
    //     0x798e04: bl              #0xd68aa4  ; AllocateContextStub
    // 0x798e08: mov             x1, x0
    // 0x798e0c: ldur            x0, [fp, #-0x10]
    // 0x798e10: stur            x1, [fp, #-0x28]
    // 0x798e14: StoreField: r1->field_f = r0
    //     0x798e14: stur            w0, [x1, #0xf]
    // 0x798e18: LoadField: r2 = r0->field_b
    //     0x798e18: ldur            w2, [x0, #0xb]
    // 0x798e1c: DecompressPointer r2
    //     0x798e1c: add             x2, x2, HEAP, lsl #32
    // 0x798e20: cmp             w2, NULL
    // 0x798e24: b.eq            #0x798ec4
    // 0x798e28: r0 = EmojiViewState()
    //     0x798e28: bl              #0x798ec8  ; AllocateEmojiViewStateStub -> EmojiViewState (size=0x14)
    // 0x798e2c: mov             x3, x0
    // 0x798e30: ldur            x0, [fp, #-0x20]
    // 0x798e34: stur            x3, [fp, #-0x30]
    // 0x798e38: StoreField: r3->field_7 = r0
    //     0x798e38: stur            w0, [x3, #7]
    // 0x798e3c: ldur            x2, [fp, #-0x28]
    // 0x798e40: r1 = Function '<anonymous closure>':.
    //     0x798e40: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c7f0] AnonymousClosure: (0x79a1c4), of [package:emoji_picker_flutter/src/emoji_picker.dart] EmojiPickerState
    //     0x798e44: ldr             x1, [x1, #0x7f0]
    // 0x798e48: r0 = AllocateClosure()
    //     0x798e48: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x798e4c: mov             x1, x0
    // 0x798e50: ldur            x0, [fp, #-0x30]
    // 0x798e54: StoreField: r0->field_b = r1
    //     0x798e54: stur            w1, [x0, #0xb]
    // 0x798e58: ldur            x3, [fp, #-0x10]
    // 0x798e5c: StoreField: r3->field_1b = r0
    //     0x798e5c: stur            w0, [x3, #0x1b]
    //     0x798e60: ldurb           w16, [x3, #-1]
    //     0x798e64: ldurb           w17, [x0, #-1]
    //     0x798e68: and             x16, x17, x16, lsr #2
    //     0x798e6c: tst             x16, HEAP, lsr #32
    //     0x798e70: b.eq            #0x798e78
    //     0x798e74: bl              #0xd682ac
    // 0x798e78: LoadField: r0 = r3->field_f
    //     0x798e78: ldur            w0, [x3, #0xf]
    // 0x798e7c: DecompressPointer r0
    //     0x798e7c: add             x0, x0, HEAP, lsl #32
    // 0x798e80: cmp             w0, NULL
    // 0x798e84: b.eq            #0x798ea8
    // 0x798e88: ldur            x2, [fp, #-0x18]
    // 0x798e8c: r1 = Function '<anonymous closure>':.
    //     0x798e8c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c7f8] AnonymousClosure: (0x79a1a0), in [package:emoji_picker_flutter/src/emoji_picker.dart] EmojiPickerState::_updateEmojis (0x798b60)
    //     0x798e90: ldr             x1, [x1, #0x7f8]
    // 0x798e94: r0 = AllocateClosure()
    //     0x798e94: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x798e98: ldur            x16, [fp, #-0x10]
    // 0x798e9c: stp             x0, x16, [SP, #-0x10]!
    // 0x798ea0: r0 = setState()
    //     0x798ea0: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x798ea4: add             SP, SP, #0x10
    // 0x798ea8: r0 = Null
    //     0x798ea8: mov             x0, NULL
    // 0x798eac: r0 = ReturnAsyncNotFuture()
    //     0x798eac: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x798eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x798eb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x798eb4: b               #0x798b8c
    // 0x798eb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x798eb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x798ebc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x798ebc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x798ec0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x798ec0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x798ec4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x798ec4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x79a1a0, size: 0x24
    // 0x79a1a0: r1 = true
    //     0x79a1a0: add             x1, NULL, #0x20  ; true
    // 0x79a1a4: ldr             x2, [SP]
    // 0x79a1a8: LoadField: r3 = r2->field_17
    //     0x79a1a8: ldur            w3, [x2, #0x17]
    // 0x79a1ac: DecompressPointer r3
    //     0x79a1ac: add             x3, x3, HEAP, lsl #32
    // 0x79a1b0: LoadField: r2 = r3->field_f
    //     0x79a1b0: ldur            w2, [x3, #0xf]
    // 0x79a1b4: DecompressPointer r2
    //     0x79a1b4: add             x2, x2, HEAP, lsl #32
    // 0x79a1b8: StoreField: r2->field_1f = r1
    //     0x79a1b8: stur            w1, [x2, #0x1f]
    // 0x79a1bc: r0 = Null
    //     0x79a1bc: mov             x0, NULL
    // 0x79a1c0: ret
    //     0x79a1c0: ret             
  }
  [closure] void <anonymous closure>(dynamic, Category?, Emoji) {
    // ** addr: 0x79a1c4, size: 0x278
    // 0x79a1c4: EnterFrame
    //     0x79a1c4: stp             fp, lr, [SP, #-0x10]!
    //     0x79a1c8: mov             fp, SP
    // 0x79a1cc: AllocStack(0x30)
    //     0x79a1cc: sub             SP, SP, #0x30
    // 0x79a1d0: SetupParameters()
    //     0x79a1d0: ldr             x0, [fp, #0x20]
    //     0x79a1d4: ldur            w1, [x0, #0x17]
    //     0x79a1d8: add             x1, x1, HEAP, lsl #32
    //     0x79a1dc: stur            x1, [fp, #-8]
    // 0x79a1e0: CheckStackOverflow
    //     0x79a1e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79a1e4: cmp             SP, x16
    //     0x79a1e8: b.ls            #0x79a424
    // 0x79a1ec: r1 = 1
    //     0x79a1ec: mov             x1, #1
    // 0x79a1f0: r0 = AllocateContext()
    //     0x79a1f0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79a1f4: mov             x1, x0
    // 0x79a1f8: ldur            x0, [fp, #-8]
    // 0x79a1fc: stur            x1, [fp, #-0x10]
    // 0x79a200: StoreField: r1->field_b = r0
    //     0x79a200: stur            w0, [x1, #0xb]
    // 0x79a204: ldr             x2, [fp, #0x18]
    // 0x79a208: StoreField: r1->field_f = r2
    //     0x79a208: stur            w2, [x1, #0xf]
    // 0x79a20c: LoadField: r2 = r0->field_f
    //     0x79a20c: ldur            w2, [x0, #0xf]
    // 0x79a210: DecompressPointer r2
    //     0x79a210: add             x2, x2, HEAP, lsl #32
    // 0x79a214: LoadField: r3 = r2->field_b
    //     0x79a214: ldur            w3, [x2, #0xb]
    // 0x79a218: DecompressPointer r3
    //     0x79a218: add             x3, x3, HEAP, lsl #32
    // 0x79a21c: cmp             w3, NULL
    // 0x79a220: b.eq            #0x79a42c
    // 0x79a224: LoadField: r3 = r2->field_23
    //     0x79a224: ldur            w3, [x2, #0x23]
    // 0x79a228: DecompressPointer r3
    //     0x79a228: add             x3, x3, HEAP, lsl #32
    // 0x79a22c: ldr             x16, [fp, #0x10]
    // 0x79a230: stp             x16, x3, [SP, #-0x10]!
    // 0x79a234: r0 = addEmojiToRecentlyUsed()
    //     0x79a234: bl              #0x79a7e8  ; [package:emoji_picker_flutter/src/emoji_picker_internal_utils.dart] EmojiPickerInternalUtils::addEmojiToRecentlyUsed
    // 0x79a238: add             SP, SP, #0x10
    // 0x79a23c: ldur            x2, [fp, #-0x10]
    // 0x79a240: r1 = Function '<anonymous closure>':.
    //     0x79a240: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c800] AnonymousClosure: (0x79acd8), in [package:emoji_picker_flutter/src/emoji_picker.dart] EmojiPickerState::<anonymous closure> (0x79a1c4)
    //     0x79a244: ldr             x1, [x1, #0x800]
    // 0x79a248: stur            x0, [fp, #-0x10]
    // 0x79a24c: r0 = AllocateClosure()
    //     0x79a24c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79a250: r16 = <Set<void?>>
    //     0x79a250: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c808] TypeArguments: <Set<void?>>
    //     0x79a254: ldr             x16, [x16, #0x808]
    // 0x79a258: ldur            lr, [fp, #-0x10]
    // 0x79a25c: stp             lr, x16, [SP, #-0x10]!
    // 0x79a260: SaveReg r0
    //     0x79a260: str             x0, [SP, #-8]!
    // 0x79a264: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x79a264: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x79a268: r0 = then()
    //     0x79a268: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x79a26c: add             SP, SP, #0x18
    // 0x79a270: ldur            x0, [fp, #-8]
    // 0x79a274: LoadField: r1 = r0->field_f
    //     0x79a274: ldur            w1, [x0, #0xf]
    // 0x79a278: DecompressPointer r1
    //     0x79a278: add             x1, x1, HEAP, lsl #32
    // 0x79a27c: LoadField: r2 = r1->field_b
    //     0x79a27c: ldur            w2, [x1, #0xb]
    // 0x79a280: DecompressPointer r2
    //     0x79a280: add             x2, x2, HEAP, lsl #32
    // 0x79a284: cmp             w2, NULL
    // 0x79a288: b.eq            #0x79a430
    // 0x79a28c: LoadField: r1 = r2->field_f
    //     0x79a28c: ldur            w1, [x2, #0xf]
    // 0x79a290: DecompressPointer r1
    //     0x79a290: add             x1, x1, HEAP, lsl #32
    // 0x79a294: stur            x1, [fp, #-0x20]
    // 0x79a298: LoadField: r2 = r1->field_27
    //     0x79a298: ldur            w2, [x1, #0x27]
    // 0x79a29c: DecompressPointer r2
    //     0x79a29c: add             x2, x2, HEAP, lsl #32
    // 0x79a2a0: LoadField: r3 = r2->field_7
    //     0x79a2a0: ldur            w3, [x2, #7]
    // 0x79a2a4: DecompressPointer r3
    //     0x79a2a4: add             x3, x3, HEAP, lsl #32
    // 0x79a2a8: stur            x3, [fp, #-0x18]
    // 0x79a2ac: LoadField: r4 = r2->field_b
    //     0x79a2ac: ldur            w4, [x2, #0xb]
    // 0x79a2b0: DecompressPointer r4
    //     0x79a2b0: add             x4, x4, HEAP, lsl #32
    // 0x79a2b4: stur            x4, [fp, #-0x10]
    // 0x79a2b8: SaveReg r4
    //     0x79a2b8: str             x4, [SP, #-8]!
    // 0x79a2bc: r0 = base()
    //     0x79a2bc: bl              #0x522758  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0x79a2c0: add             SP, SP, #8
    // 0x79a2c4: LoadField: r1 = r0->field_7
    //     0x79a2c4: ldur            x1, [x0, #7]
    // 0x79a2c8: tbz             x1, #0x3f, #0x79a338
    // 0x79a2cc: ldr             x2, [fp, #0x10]
    // 0x79a2d0: ldur            x0, [fp, #-8]
    // 0x79a2d4: ldur            x1, [fp, #-0x20]
    // 0x79a2d8: LoadField: r3 = r1->field_27
    //     0x79a2d8: ldur            w3, [x1, #0x27]
    // 0x79a2dc: DecompressPointer r3
    //     0x79a2dc: add             x3, x3, HEAP, lsl #32
    // 0x79a2e0: LoadField: r4 = r3->field_7
    //     0x79a2e0: ldur            w4, [x3, #7]
    // 0x79a2e4: DecompressPointer r4
    //     0x79a2e4: add             x4, x4, HEAP, lsl #32
    // 0x79a2e8: LoadField: r3 = r2->field_7
    //     0x79a2e8: ldur            w3, [x2, #7]
    // 0x79a2ec: DecompressPointer r3
    //     0x79a2ec: add             x3, x3, HEAP, lsl #32
    // 0x79a2f0: stp             x3, x4, [SP, #-0x10]!
    // 0x79a2f4: r0 = +()
    //     0x79a2f4: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x79a2f8: add             SP, SP, #0x10
    // 0x79a2fc: ldur            x16, [fp, #-0x20]
    // 0x79a300: stp             x0, x16, [SP, #-0x10]!
    // 0x79a304: r0 = text=()
    //     0x79a304: bl              #0x79a774  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x79a308: add             SP, SP, #0x10
    // 0x79a30c: ldur            x3, [fp, #-8]
    // 0x79a310: LoadField: r0 = r3->field_f
    //     0x79a310: ldur            w0, [x3, #0xf]
    // 0x79a314: DecompressPointer r0
    //     0x79a314: add             x0, x0, HEAP, lsl #32
    // 0x79a318: LoadField: r1 = r0->field_b
    //     0x79a318: ldur            w1, [x0, #0xb]
    // 0x79a31c: DecompressPointer r1
    //     0x79a31c: add             x1, x1, HEAP, lsl #32
    // 0x79a320: cmp             w1, NULL
    // 0x79a324: b.eq            #0x79a434
    // 0x79a328: r0 = Null
    //     0x79a328: mov             x0, NULL
    // 0x79a32c: LeaveFrame
    //     0x79a32c: mov             SP, fp
    //     0x79a330: ldp             fp, lr, [SP], #0x10
    // 0x79a334: ret
    //     0x79a334: ret             
    // 0x79a338: ldr             x2, [fp, #0x10]
    // 0x79a33c: ldur            x3, [fp, #-8]
    // 0x79a340: ldur            x4, [fp, #-0x10]
    // 0x79a344: LoadField: r5 = r4->field_7
    //     0x79a344: ldur            x5, [x4, #7]
    // 0x79a348: stur            x5, [fp, #-0x30]
    // 0x79a34c: LoadField: r6 = r4->field_f
    //     0x79a34c: ldur            x6, [x4, #0xf]
    // 0x79a350: LoadField: r7 = r2->field_7
    //     0x79a350: ldur            w7, [x2, #7]
    // 0x79a354: DecompressPointer r7
    //     0x79a354: add             x7, x7, HEAP, lsl #32
    // 0x79a358: stur            x7, [fp, #-0x28]
    // 0x79a35c: r0 = BoxInt64Instr(r6)
    //     0x79a35c: sbfiz           x0, x6, #1, #0x1f
    //     0x79a360: cmp             x6, x0, asr #1
    //     0x79a364: b.eq            #0x79a370
    //     0x79a368: bl              #0xd69bb8
    //     0x79a36c: stur            x6, [x0, #7]
    // 0x79a370: ldur            x16, [fp, #-0x18]
    // 0x79a374: stp             x5, x16, [SP, #-0x10]!
    // 0x79a378: stp             x7, x0, [SP, #-0x10]!
    // 0x79a37c: r0 = replaceRange()
    //     0x79a37c: bl              #0x4d9f60  ; [dart:core] _StringBase::replaceRange
    // 0x79a380: add             SP, SP, #0x20
    // 0x79a384: mov             x1, x0
    // 0x79a388: ldur            x0, [fp, #-0x28]
    // 0x79a38c: LoadField: r2 = r0->field_7
    //     0x79a38c: ldur            w2, [x0, #7]
    // 0x79a390: DecompressPointer r2
    //     0x79a390: add             x2, x2, HEAP, lsl #32
    // 0x79a394: stur            x2, [fp, #-0x18]
    // 0x79a398: ldur            x16, [fp, #-0x20]
    // 0x79a39c: stp             x1, x16, [SP, #-0x10]!
    // 0x79a3a0: r0 = text=()
    //     0x79a3a0: bl              #0x79a774  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x79a3a4: add             SP, SP, #0x10
    // 0x79a3a8: ldur            x0, [fp, #-0x18]
    // 0x79a3ac: r1 = LoadInt32Instr(r0)
    //     0x79a3ac: sbfx            x1, x0, #1, #0x1f
    // 0x79a3b0: ldur            x0, [fp, #-0x30]
    // 0x79a3b4: add             x2, x0, x1
    // 0x79a3b8: r0 = BoxInt64Instr(r2)
    //     0x79a3b8: sbfiz           x0, x2, #1, #0x1f
    //     0x79a3bc: cmp             x2, x0, asr #1
    //     0x79a3c0: b.eq            #0x79a3cc
    //     0x79a3c4: bl              #0xd69bb8
    //     0x79a3c8: stur            x2, [x0, #7]
    // 0x79a3cc: ldur            x16, [fp, #-0x10]
    // 0x79a3d0: stp             x0, x16, [SP, #-0x10]!
    // 0x79a3d4: SaveReg r0
    //     0x79a3d4: str             x0, [SP, #-8]!
    // 0x79a3d8: r4 = const [0, 0x3, 0x3, 0x1, baseOffset, 0x1, extentOffset, 0x2, null]
    //     0x79a3d8: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2de50] List(9) [0, 0x3, 0x3, 0x1, "baseOffset", 0x1, "extentOffset", 0x2, Null]
    //     0x79a3dc: ldr             x4, [x4, #0xe50]
    // 0x79a3e0: r0 = copyWith()
    //     0x79a3e0: bl              #0x5227d4  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0x79a3e4: add             SP, SP, #0x18
    // 0x79a3e8: ldur            x16, [fp, #-0x20]
    // 0x79a3ec: stp             x0, x16, [SP, #-0x10]!
    // 0x79a3f0: r0 = selection=()
    //     0x79a3f0: bl              #0x79a43c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::selection=
    // 0x79a3f4: add             SP, SP, #0x10
    // 0x79a3f8: ldur            x1, [fp, #-8]
    // 0x79a3fc: LoadField: r2 = r1->field_f
    //     0x79a3fc: ldur            w2, [x1, #0xf]
    // 0x79a400: DecompressPointer r2
    //     0x79a400: add             x2, x2, HEAP, lsl #32
    // 0x79a404: LoadField: r1 = r2->field_b
    //     0x79a404: ldur            w1, [x2, #0xb]
    // 0x79a408: DecompressPointer r1
    //     0x79a408: add             x1, x1, HEAP, lsl #32
    // 0x79a40c: cmp             w1, NULL
    // 0x79a410: b.eq            #0x79a438
    // 0x79a414: r0 = Null
    //     0x79a414: mov             x0, NULL
    // 0x79a418: LeaveFrame
    //     0x79a418: mov             SP, fp
    //     0x79a41c: ldp             fp, lr, [SP], #0x10
    // 0x79a420: ret
    //     0x79a420: ret             
    // 0x79a424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79a424: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79a428: b               #0x79a1ec
    // 0x79a42c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79a42c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79a430: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79a430: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79a434: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79a434: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79a438: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79a438: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Set<void> <anonymous closure>(dynamic, List<RecentEmoji>) {
    // ** addr: 0x79acd8, size: 0x118
    // 0x79acd8: EnterFrame
    //     0x79acd8: stp             fp, lr, [SP, #-0x10]!
    //     0x79acdc: mov             fp, SP
    // 0x79ace0: AllocStack(0x18)
    //     0x79ace0: sub             SP, SP, #0x18
    // 0x79ace4: SetupParameters()
    //     0x79ace4: ldr             x0, [fp, #0x18]
    //     0x79ace8: ldur            w1, [x0, #0x17]
    //     0x79acec: add             x1, x1, HEAP, lsl #32
    //     0x79acf0: stur            x1, [fp, #-8]
    // 0x79acf4: CheckStackOverflow
    //     0x79acf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79acf8: cmp             SP, x16
    //     0x79acfc: b.ls            #0x79ade8
    // 0x79ad00: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x79ad00: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x79ad04: ldr             x0, [x0, #0x598]
    //     0x79ad08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x79ad0c: cmp             w0, w16
    //     0x79ad10: b.ne            #0x79ad1c
    //     0x79ad14: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x79ad18: bl              #0xd67cdc
    // 0x79ad1c: r1 = <void?>
    //     0x79ad1c: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x79ad20: stur            x0, [fp, #-0x10]
    // 0x79ad24: r0 = _Set()
    //     0x79ad24: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x79ad28: mov             x1, x0
    // 0x79ad2c: ldur            x0, [fp, #-0x10]
    // 0x79ad30: stur            x1, [fp, #-0x18]
    // 0x79ad34: StoreField: r1->field_1b = r0
    //     0x79ad34: stur            w0, [x1, #0x1b]
    // 0x79ad38: StoreField: r1->field_b = rZR
    //     0x79ad38: stur            wzr, [x1, #0xb]
    // 0x79ad3c: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x79ad3c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x79ad40: ldr             x0, [x0, #0x5a0]
    //     0x79ad44: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x79ad48: cmp             w0, w16
    //     0x79ad4c: b.ne            #0x79ad58
    //     0x79ad50: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x79ad54: bl              #0xd67cdc
    // 0x79ad58: ldur            x1, [fp, #-0x18]
    // 0x79ad5c: StoreField: r1->field_f = r0
    //     0x79ad5c: stur            w0, [x1, #0xf]
    // 0x79ad60: StoreField: r1->field_13 = rZR
    //     0x79ad60: stur            wzr, [x1, #0x13]
    // 0x79ad64: StoreField: r1->field_17 = rZR
    //     0x79ad64: stur            wzr, [x1, #0x17]
    // 0x79ad68: ldur            x2, [fp, #-8]
    // 0x79ad6c: LoadField: r0 = r2->field_f
    //     0x79ad6c: ldur            w0, [x2, #0xf]
    // 0x79ad70: DecompressPointer r0
    //     0x79ad70: add             x0, x0, HEAP, lsl #32
    // 0x79ad74: r3 = LoadClassIdInstr(r0)
    //     0x79ad74: ldur            x3, [x0, #-1]
    //     0x79ad78: ubfx            x3, x3, #0xc, #0x14
    // 0x79ad7c: r16 = Instance_Category
    //     0x79ad7c: add             x16, PP, #0x41, lsl #12  ; [pp+0x41090] Obj!Category@b664f1
    //     0x79ad80: ldr             x16, [x16, #0x90]
    // 0x79ad84: stp             x16, x0, [SP, #-0x10]!
    // 0x79ad88: mov             x0, x3
    // 0x79ad8c: mov             lr, x0
    // 0x79ad90: ldr             lr, [x21, lr, lsl #3]
    // 0x79ad94: blr             lr
    // 0x79ad98: add             SP, SP, #0x10
    // 0x79ad9c: eor             x1, x0, #0x10
    // 0x79ada0: ldur            x0, [fp, #-8]
    // 0x79ada4: LoadField: r2 = r0->field_b
    //     0x79ada4: ldur            w2, [x0, #0xb]
    // 0x79ada8: DecompressPointer r2
    //     0x79ada8: add             x2, x2, HEAP, lsl #32
    // 0x79adac: LoadField: r0 = r2->field_f
    //     0x79adac: ldur            w0, [x2, #0xf]
    // 0x79adb0: DecompressPointer r0
    //     0x79adb0: add             x0, x0, HEAP, lsl #32
    // 0x79adb4: ldr             x16, [fp, #0x10]
    // 0x79adb8: stp             x16, x0, [SP, #-0x10]!
    // 0x79adbc: SaveReg r1
    //     0x79adbc: str             x1, [SP, #-8]!
    // 0x79adc0: r0 = updateRecentEmoji()
    //     0x79adc0: bl              #0x79adf0  ; [package:emoji_picker_flutter/src/emoji_picker.dart] EmojiPickerState::updateRecentEmoji
    // 0x79adc4: add             SP, SP, #0x18
    // 0x79adc8: ldur            x16, [fp, #-0x18]
    // 0x79adcc: stp             NULL, x16, [SP, #-0x10]!
    // 0x79add0: r0 = add()
    //     0x79add0: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x79add4: add             SP, SP, #0x10
    // 0x79add8: ldur            x0, [fp, #-0x18]
    // 0x79addc: LeaveFrame
    //     0x79addc: mov             SP, fp
    //     0x79ade0: ldp             fp, lr, [SP], #0x10
    // 0x79ade4: ret
    //     0x79ade4: ret             
    // 0x79ade8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79ade8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79adec: b               #0x79ad00
  }
  _ updateRecentEmoji(/* No info */) {
    // ** addr: 0x79adf0, size: 0x1ac
    // 0x79adf0: EnterFrame
    //     0x79adf0: stp             fp, lr, [SP, #-0x10]!
    //     0x79adf4: mov             fp, SP
    // 0x79adf8: AllocStack(0x10)
    //     0x79adf8: sub             SP, SP, #0x10
    // 0x79adfc: CheckStackOverflow
    //     0x79adfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79ae00: cmp             SP, x16
    //     0x79ae04: b.ls            #0x79af8c
    // 0x79ae08: ldr             x0, [fp, #0x18]
    // 0x79ae0c: ldr             x3, [fp, #0x20]
    // 0x79ae10: StoreField: r3->field_17 = r0
    //     0x79ae10: stur            w0, [x3, #0x17]
    //     0x79ae14: ldurb           w16, [x3, #-1]
    //     0x79ae18: ldurb           w17, [x0, #-1]
    //     0x79ae1c: and             x16, x17, x16, lsr #2
    //     0x79ae20: tst             x16, HEAP, lsr #32
    //     0x79ae24: b.eq            #0x79ae2c
    //     0x79ae28: bl              #0xd682ac
    // 0x79ae2c: LoadField: r4 = r3->field_13
    //     0x79ae2c: ldur            w4, [x3, #0x13]
    // 0x79ae30: DecompressPointer r4
    //     0x79ae30: add             x4, x4, HEAP, lsl #32
    // 0x79ae34: stur            x4, [fp, #-0x10]
    // 0x79ae38: LoadField: r0 = r4->field_b
    //     0x79ae38: ldur            w0, [x4, #0xb]
    // 0x79ae3c: DecompressPointer r0
    //     0x79ae3c: add             x0, x0, HEAP, lsl #32
    // 0x79ae40: r1 = LoadInt32Instr(r0)
    //     0x79ae40: sbfx            x1, x0, #1, #0x1f
    // 0x79ae44: mov             x0, x1
    // 0x79ae48: r1 = 0
    //     0x79ae48: mov             x1, #0
    // 0x79ae4c: cmp             x1, x0
    // 0x79ae50: b.hs            #0x79af94
    // 0x79ae54: LoadField: r0 = r4->field_f
    //     0x79ae54: ldur            w0, [x4, #0xf]
    // 0x79ae58: DecompressPointer r0
    //     0x79ae58: add             x0, x0, HEAP, lsl #32
    // 0x79ae5c: LoadField: r5 = r0->field_f
    //     0x79ae5c: ldur            w5, [x0, #0xf]
    // 0x79ae60: DecompressPointer r5
    //     0x79ae60: add             x5, x5, HEAP, lsl #32
    // 0x79ae64: stur            x5, [fp, #-8]
    // 0x79ae68: r1 = Function '<anonymous closure>':.
    //     0x79ae68: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c810] Function: [dart:ui] Image::_image (0xd61d9c)
    //     0x79ae6c: ldr             x1, [x1, #0x810]
    // 0x79ae70: r2 = Null
    //     0x79ae70: mov             x2, NULL
    // 0x79ae74: r0 = AllocateClosure()
    //     0x79ae74: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79ae78: mov             x1, x0
    // 0x79ae7c: ldr             x0, [fp, #0x18]
    // 0x79ae80: r2 = LoadClassIdInstr(r0)
    //     0x79ae80: ldur            x2, [x0, #-1]
    //     0x79ae84: ubfx            x2, x2, #0xc, #0x14
    // 0x79ae88: r16 = <Emoji>
    //     0x79ae88: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c7e8] TypeArguments: <Emoji>
    //     0x79ae8c: ldr             x16, [x16, #0x7e8]
    // 0x79ae90: stp             x0, x16, [SP, #-0x10]!
    // 0x79ae94: SaveReg r1
    //     0x79ae94: str             x1, [SP, #-8]!
    // 0x79ae98: mov             x0, x2
    // 0x79ae9c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x79ae9c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x79aea0: r0 = GDT[cid_x0 + 0xc934]()
    //     0x79aea0: mov             x17, #0xc934
    //     0x79aea4: add             lr, x0, x17
    //     0x79aea8: ldr             lr, [x21, lr, lsl #3]
    //     0x79aeac: blr             lr
    // 0x79aeb0: add             SP, SP, #0x18
    // 0x79aeb4: r1 = LoadClassIdInstr(r0)
    //     0x79aeb4: ldur            x1, [x0, #-1]
    //     0x79aeb8: ubfx            x1, x1, #0xc, #0x14
    // 0x79aebc: SaveReg r0
    //     0x79aebc: str             x0, [SP, #-8]!
    // 0x79aec0: mov             x0, x1
    // 0x79aec4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x79aec4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x79aec8: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0x79aec8: mov             x17, #0xc8a1
    //     0x79aecc: add             lr, x0, x17
    //     0x79aed0: ldr             lr, [x21, lr, lsl #3]
    //     0x79aed4: blr             lr
    // 0x79aed8: add             SP, SP, #8
    // 0x79aedc: ldur            x16, [fp, #-8]
    // 0x79aee0: stp             x0, x16, [SP, #-0x10]!
    // 0x79aee4: r0 = copyWith()
    //     0x79aee4: bl              #0x7993b8  ; [package:emoji_picker_flutter/src/category_emoji.dart] CategoryEmoji::copyWith
    // 0x79aee8: add             SP, SP, #0x10
    // 0x79aeec: mov             x3, x0
    // 0x79aef0: ldur            x2, [fp, #-0x10]
    // 0x79aef4: LoadField: r0 = r2->field_b
    //     0x79aef4: ldur            w0, [x2, #0xb]
    // 0x79aef8: DecompressPointer r0
    //     0x79aef8: add             x0, x0, HEAP, lsl #32
    // 0x79aefc: r1 = LoadInt32Instr(r0)
    //     0x79aefc: sbfx            x1, x0, #1, #0x1f
    // 0x79af00: mov             x0, x1
    // 0x79af04: r1 = 0
    //     0x79af04: mov             x1, #0
    // 0x79af08: cmp             x1, x0
    // 0x79af0c: b.hs            #0x79af98
    // 0x79af10: LoadField: r1 = r2->field_f
    //     0x79af10: ldur            w1, [x2, #0xf]
    // 0x79af14: DecompressPointer r1
    //     0x79af14: add             x1, x1, HEAP, lsl #32
    // 0x79af18: mov             x0, x3
    // 0x79af1c: ArrayStore: r1[0] = r0  ; List_4
    //     0x79af1c: add             x25, x1, #0xf
    //     0x79af20: str             w0, [x25]
    //     0x79af24: tbz             w0, #0, #0x79af40
    //     0x79af28: ldurb           w16, [x1, #-1]
    //     0x79af2c: ldurb           w17, [x0, #-1]
    //     0x79af30: and             x16, x17, x16, lsr #2
    //     0x79af34: tst             x16, HEAP, lsr #32
    //     0x79af38: b.eq            #0x79af40
    //     0x79af3c: bl              #0xd67e5c
    // 0x79af40: ldr             x0, [fp, #0x20]
    // 0x79af44: LoadField: r1 = r0->field_f
    //     0x79af44: ldur            w1, [x0, #0xf]
    // 0x79af48: DecompressPointer r1
    //     0x79af48: add             x1, x1, HEAP, lsl #32
    // 0x79af4c: cmp             w1, NULL
    // 0x79af50: b.eq            #0x79af7c
    // 0x79af54: ldr             x1, [fp, #0x10]
    // 0x79af58: tbnz            w1, #4, #0x79af7c
    // 0x79af5c: r1 = Function '<anonymous closure>':.
    //     0x79af5c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c818] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x79af60: ldr             x1, [x1, #0x818]
    // 0x79af64: r2 = Null
    //     0x79af64: mov             x2, NULL
    // 0x79af68: r0 = AllocateClosure()
    //     0x79af68: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79af6c: ldr             x16, [fp, #0x20]
    // 0x79af70: stp             x0, x16, [SP, #-0x10]!
    // 0x79af74: r0 = setState()
    //     0x79af74: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x79af78: add             SP, SP, #0x10
    // 0x79af7c: r0 = Null
    //     0x79af7c: mov             x0, NULL
    // 0x79af80: LeaveFrame
    //     0x79af80: mov             SP, fp
    //     0x79af84: ldp             fp, lr, [SP], #0x10
    // 0x79af88: ret
    //     0x79af88: ret             
    // 0x79af8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79af8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79af90: b               #0x79ae08
    // 0x79af94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x79af94: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x79af98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x79af98: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x82667c, size: 0xa0
    // 0x82667c: EnterFrame
    //     0x82667c: stp             fp, lr, [SP, #-0x10]!
    //     0x826680: mov             fp, SP
    // 0x826684: AllocStack(0x8)
    //     0x826684: sub             SP, SP, #8
    // 0x826688: ldr             x0, [fp, #0x18]
    // 0x82668c: LoadField: r1 = r0->field_1f
    //     0x82668c: ldur            w1, [x0, #0x1f]
    // 0x826690: DecompressPointer r1
    //     0x826690: add             x1, x1, HEAP, lsl #32
    // 0x826694: tbz             w1, #4, #0x8266bc
    // 0x826698: LoadField: r1 = r0->field_b
    //     0x826698: ldur            w1, [x0, #0xb]
    // 0x82669c: DecompressPointer r1
    //     0x82669c: add             x1, x1, HEAP, lsl #32
    // 0x8266a0: cmp             w1, NULL
    // 0x8266a4: b.eq            #0x826708
    // 0x8266a8: r0 = Instance_SizedBox
    //     0x8266a8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x8266ac: ldr             x0, [x0, #0x738]
    // 0x8266b0: LeaveFrame
    //     0x8266b0: mov             SP, fp
    //     0x8266b4: ldp             fp, lr, [SP], #0x10
    // 0x8266b8: ret
    //     0x8266b8: ret             
    // 0x8266bc: LoadField: r1 = r0->field_b
    //     0x8266bc: ldur            w1, [x0, #0xb]
    // 0x8266c0: DecompressPointer r1
    //     0x8266c0: add             x1, x1, HEAP, lsl #32
    // 0x8266c4: cmp             w1, NULL
    // 0x8266c8: b.eq            #0x82670c
    // 0x8266cc: LoadField: r1 = r0->field_1b
    //     0x8266cc: ldur            w1, [x0, #0x1b]
    // 0x8266d0: DecompressPointer r1
    //     0x8266d0: add             x1, x1, HEAP, lsl #32
    // 0x8266d4: r16 = Sentinel
    //     0x8266d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8266d8: cmp             w1, w16
    // 0x8266dc: b.eq            #0x826710
    // 0x8266e0: stur            x1, [fp, #-8]
    // 0x8266e4: r0 = DefaultEmojiPickerView()
    //     0x8266e4: bl              #0x82671c  ; AllocateDefaultEmojiPickerViewStub -> DefaultEmojiPickerView (size=0x14)
    // 0x8266e8: r1 = Instance_Config
    //     0x8266e8: add             x1, PP, #0x32, lsl #12  ; [pp+0x32b10] Obj!Config@b5c6a1
    //     0x8266ec: ldr             x1, [x1, #0xb10]
    // 0x8266f0: StoreField: r0->field_b = r1
    //     0x8266f0: stur            w1, [x0, #0xb]
    // 0x8266f4: ldur            x1, [fp, #-8]
    // 0x8266f8: StoreField: r0->field_f = r1
    //     0x8266f8: stur            w1, [x0, #0xf]
    // 0x8266fc: LeaveFrame
    //     0x8266fc: mov             SP, fp
    //     0x826700: ldp             fp, lr, [SP], #0x10
    // 0x826704: ret
    //     0x826704: ret             
    // 0x826708: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x826708: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82670c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82670c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x826710: r9 = _state
    //     0x826710: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c7a0] Field <EmojiPickerState._state@386147172>: late (offset: 0x1c)
    //     0x826714: ldr             x9, [x9, #0x7a0]
    // 0x826718: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x826718: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d5e40, size: 0x3c
    // 0x9d5e40: EnterFrame
    //     0x9d5e40: stp             fp, lr, [SP, #-0x10]!
    //     0x9d5e44: mov             fp, SP
    // 0x9d5e48: CheckStackOverflow
    //     0x9d5e48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d5e4c: cmp             SP, x16
    //     0x9d5e50: b.ls            #0x9d5e74
    // 0x9d5e54: ldr             x16, [fp, #0x10]
    // 0x9d5e58: SaveReg r16
    //     0x9d5e58: str             x16, [SP, #-8]!
    // 0x9d5e5c: r0 = _updateEmojis()
    //     0x9d5e5c: bl              #0x798b60  ; [package:emoji_picker_flutter/src/emoji_picker.dart] EmojiPickerState::_updateEmojis
    // 0x9d5e60: add             SP, SP, #8
    // 0x9d5e64: r0 = Null
    //     0x9d5e64: mov             x0, NULL
    // 0x9d5e68: LeaveFrame
    //     0x9d5e68: mov             SP, fp
    //     0x9d5e6c: ldp             fp, lr, [SP], #0x10
    // 0x9d5e70: ret
    //     0x9d5e70: ret             
    // 0x9d5e74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d5e74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d5e78: b               #0x9d5e54
  }
  _ EmojiPickerState(/* No info */) {
    // ** addr: 0xa3f090, size: 0x100
    // 0xa3f090: EnterFrame
    //     0xa3f090: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f094: mov             fp, SP
    // 0xa3f098: AllocStack(0x8)
    //     0xa3f098: sub             SP, SP, #8
    // 0xa3f09c: r1 = Sentinel
    //     0xa3f09c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3f0a0: r0 = false
    //     0xa3f0a0: add             x0, NULL, #0x30  ; false
    // 0xa3f0a4: CheckStackOverflow
    //     0xa3f0a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3f0a8: cmp             SP, x16
    //     0xa3f0ac: b.ls            #0xa3f188
    // 0xa3f0b0: ldr             x2, [fp, #0x10]
    // 0xa3f0b4: StoreField: r2->field_1b = r1
    //     0xa3f0b4: stur            w1, [x2, #0x1b]
    // 0xa3f0b8: StoreField: r2->field_1f = r0
    //     0xa3f0b8: stur            w0, [x2, #0x1f]
    // 0xa3f0bc: r0 = InitLateStaticField(0x0) // [dart:core] _GrowableList<X0>::_emptyList
    //     0xa3f0bc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa3f0c0: ldr             x0, [x0]
    //     0xa3f0c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa3f0c8: cmp             w0, w16
    //     0xa3f0cc: b.ne            #0xa3f0d8
    //     0xa3f0d0: ldr             x2, [PP, #0x7c8]  ; [pp+0x7c8] Field <_GrowableList@0150898._emptyList@0150898>: static late final (offset: 0x0)
    //     0xa3f0d4: bl              #0xd67cdc
    // 0xa3f0d8: r1 = <CategoryEmoji>
    //     0xa3f0d8: add             x1, PP, #0x41, lsl #12  ; [pp+0x41078] TypeArguments: <CategoryEmoji>
    //     0xa3f0dc: ldr             x1, [x1, #0x78]
    // 0xa3f0e0: stur            x0, [fp, #-8]
    // 0xa3f0e4: r0 = AllocateGrowableArray()
    //     0xa3f0e4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa3f0e8: ldur            x2, [fp, #-8]
    // 0xa3f0ec: StoreField: r0->field_f = r2
    //     0xa3f0ec: stur            w2, [x0, #0xf]
    // 0xa3f0f0: StoreField: r0->field_b = rZR
    //     0xa3f0f0: stur            wzr, [x0, #0xb]
    // 0xa3f0f4: ldr             x3, [fp, #0x10]
    // 0xa3f0f8: StoreField: r3->field_13 = r0
    //     0xa3f0f8: stur            w0, [x3, #0x13]
    //     0xa3f0fc: ldurb           w16, [x3, #-1]
    //     0xa3f100: ldurb           w17, [x0, #-1]
    //     0xa3f104: and             x16, x17, x16, lsr #2
    //     0xa3f108: tst             x16, HEAP, lsr #32
    //     0xa3f10c: b.eq            #0xa3f114
    //     0xa3f110: bl              #0xd682ac
    // 0xa3f114: r1 = <RecentEmoji>
    //     0xa3f114: add             x1, PP, #0x41, lsl #12  ; [pp+0x41080] TypeArguments: <RecentEmoji>
    //     0xa3f118: ldr             x1, [x1, #0x80]
    // 0xa3f11c: r0 = AllocateGrowableArray()
    //     0xa3f11c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa3f120: mov             x1, x0
    // 0xa3f124: ldur            x0, [fp, #-8]
    // 0xa3f128: StoreField: r1->field_f = r0
    //     0xa3f128: stur            w0, [x1, #0xf]
    // 0xa3f12c: StoreField: r1->field_b = rZR
    //     0xa3f12c: stur            wzr, [x1, #0xb]
    // 0xa3f130: mov             x0, x1
    // 0xa3f134: ldr             x1, [fp, #0x10]
    // 0xa3f138: StoreField: r1->field_17 = r0
    //     0xa3f138: stur            w0, [x1, #0x17]
    //     0xa3f13c: ldurb           w16, [x1, #-1]
    //     0xa3f140: ldurb           w17, [x0, #-1]
    //     0xa3f144: and             x16, x17, x16, lsr #2
    //     0xa3f148: tst             x16, HEAP, lsr #32
    //     0xa3f14c: b.eq            #0xa3f154
    //     0xa3f150: bl              #0xd6826c
    // 0xa3f154: r0 = EmojiPickerInternalUtils()
    //     0xa3f154: bl              #0xa3f190  ; AllocateEmojiPickerInternalUtilsStub -> EmojiPickerInternalUtils (size=0x8)
    // 0xa3f158: ldr             x1, [fp, #0x10]
    // 0xa3f15c: StoreField: r1->field_23 = r0
    //     0xa3f15c: stur            w0, [x1, #0x23]
    //     0xa3f160: ldurb           w16, [x1, #-1]
    //     0xa3f164: ldurb           w17, [x0, #-1]
    //     0xa3f168: and             x16, x17, x16, lsr #2
    //     0xa3f16c: tst             x16, HEAP, lsr #32
    //     0xa3f170: b.eq            #0xa3f178
    //     0xa3f174: bl              #0xd6826c
    // 0xa3f178: r0 = Null
    //     0xa3f178: mov             x0, NULL
    // 0xa3f17c: LeaveFrame
    //     0xa3f17c: mov             SP, fp
    //     0xa3f180: ldp             fp, lr, [SP], #0x10
    // 0xa3f184: ret
    //     0xa3f184: ret             
    // 0xa3f188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3f188: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3f18c: b               #0xa3f0b0
  }
}

// class id: 4217, size: 0x20, field offset: 0xc
//   const constructor, 
class EmojiPicker extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3f044, size: 0x4c
    // 0xa3f044: EnterFrame
    //     0xa3f044: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f048: mov             fp, SP
    // 0xa3f04c: AllocStack(0x8)
    //     0xa3f04c: sub             SP, SP, #8
    // 0xa3f050: CheckStackOverflow
    //     0xa3f050: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3f054: cmp             SP, x16
    //     0xa3f058: b.ls            #0xa3f088
    // 0xa3f05c: r1 = <EmojiPicker>
    //     0xa3f05c: add             x1, PP, #0x41, lsl #12  ; [pp+0x41070] TypeArguments: <EmojiPicker>
    //     0xa3f060: ldr             x1, [x1, #0x70]
    // 0xa3f064: r0 = EmojiPickerState()
    //     0xa3f064: bl              #0xa3f19c  ; AllocateEmojiPickerStateStub -> EmojiPickerState (size=0x28)
    // 0xa3f068: stur            x0, [fp, #-8]
    // 0xa3f06c: SaveReg r0
    //     0xa3f06c: str             x0, [SP, #-8]!
    // 0xa3f070: r0 = EmojiPickerState()
    //     0xa3f070: bl              #0xa3f090  ; [package:emoji_picker_flutter/src/emoji_picker.dart] EmojiPickerState::EmojiPickerState
    // 0xa3f074: add             SP, SP, #8
    // 0xa3f078: ldur            x0, [fp, #-8]
    // 0xa3f07c: LeaveFrame
    //     0xa3f07c: mov             SP, fp
    //     0xa3f080: ldp             fp, lr, [SP], #0x10
    // 0xa3f084: ret
    //     0xa3f084: ret             
    // 0xa3f088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3f088: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3f08c: b               #0xa3f05c
  }
}

// class id: 6004, size: 0x14, field offset: 0x14
enum ButtonMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15670, size: 0x5c
    // 0xb15670: EnterFrame
    //     0xb15670: stp             fp, lr, [SP, #-0x10]!
    //     0xb15674: mov             fp, SP
    // 0xb15678: CheckStackOverflow
    //     0xb15678: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1567c: cmp             SP, x16
    //     0xb15680: b.ls            #0xb156c4
    // 0xb15684: r1 = Null
    //     0xb15684: mov             x1, NULL
    // 0xb15688: r2 = 4
    //     0xb15688: mov             x2, #4
    // 0xb1568c: r0 = AllocateArray()
    //     0xb1568c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15690: r17 = "ButtonMode."
    //     0xb15690: add             x17, PP, #0x41, lsl #12  ; [pp+0x41088] "ButtonMode."
    //     0xb15694: ldr             x17, [x17, #0x88]
    // 0xb15698: StoreField: r0->field_f = r17
    //     0xb15698: stur            w17, [x0, #0xf]
    // 0xb1569c: ldr             x1, [fp, #0x10]
    // 0xb156a0: LoadField: r2 = r1->field_f
    //     0xb156a0: ldur            w2, [x1, #0xf]
    // 0xb156a4: DecompressPointer r2
    //     0xb156a4: add             x2, x2, HEAP, lsl #32
    // 0xb156a8: StoreField: r0->field_13 = r2
    //     0xb156a8: stur            w2, [x0, #0x13]
    // 0xb156ac: SaveReg r0
    //     0xb156ac: str             x0, [SP, #-8]!
    // 0xb156b0: r0 = _interpolate()
    //     0xb156b0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb156b4: add             SP, SP, #8
    // 0xb156b8: LeaveFrame
    //     0xb156b8: mov             SP, fp
    //     0xb156bc: ldp             fp, lr, [SP], #0x10
    // 0xb156c0: ret
    //     0xb156c0: ret             
    // 0xb156c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb156c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb156c8: b               #0xb15684
  }
}

// class id: 6005, size: 0x14, field offset: 0x14
enum Category extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15614, size: 0x5c
    // 0xb15614: EnterFrame
    //     0xb15614: stp             fp, lr, [SP, #-0x10]!
    //     0xb15618: mov             fp, SP
    // 0xb1561c: CheckStackOverflow
    //     0xb1561c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15620: cmp             SP, x16
    //     0xb15624: b.ls            #0xb15668
    // 0xb15628: r1 = Null
    //     0xb15628: mov             x1, NULL
    // 0xb1562c: r2 = 4
    //     0xb1562c: mov             x2, #4
    // 0xb15630: r0 = AllocateArray()
    //     0xb15630: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15634: r17 = "Category."
    //     0xb15634: add             x17, PP, #0x41, lsl #12  ; [pp+0x41068] "Category."
    //     0xb15638: ldr             x17, [x17, #0x68]
    // 0xb1563c: StoreField: r0->field_f = r17
    //     0xb1563c: stur            w17, [x0, #0xf]
    // 0xb15640: ldr             x1, [fp, #0x10]
    // 0xb15644: LoadField: r2 = r1->field_f
    //     0xb15644: ldur            w2, [x1, #0xf]
    // 0xb15648: DecompressPointer r2
    //     0xb15648: add             x2, x2, HEAP, lsl #32
    // 0xb1564c: StoreField: r0->field_13 = r2
    //     0xb1564c: stur            w2, [x0, #0x13]
    // 0xb15650: SaveReg r0
    //     0xb15650: str             x0, [SP, #-8]!
    // 0xb15654: r0 = _interpolate()
    //     0xb15654: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15658: add             SP, SP, #8
    // 0xb1565c: LeaveFrame
    //     0xb1565c: mov             SP, fp
    //     0xb15660: ldp             fp, lr, [SP], #0x10
    // 0xb15664: ret
    //     0xb15664: ret             
    // 0xb15668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1566c: b               #0xb15628
  }
}

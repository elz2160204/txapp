// lib: , url: package:emoji_picker_flutter/src/emoji_picker_builder.dart

// class id: 1048914, size: 0x8
class :: {
}

// class id: 4218, size: 0x14, field offset: 0xc
abstract class EmojiPickerBuilder extends StatefulWidget {
}

// lib: , url: package:emoji_picker_flutter/src/emoji_cell.dart

// class id: 1048911, size: 0x8
class :: {
}

// class id: 3884, size: 0x3c, field offset: 0xc
//   const constructor, 
class EmojiCell extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1c0ac, size: 0x94
    // 0xb1c0ac: EnterFrame
    //     0xb1c0ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c0b0: mov             fp, SP
    // 0xb1c0b4: AllocStack(0x10)
    //     0xb1c0b4: sub             SP, SP, #0x10
    // 0xb1c0b8: CheckStackOverflow
    //     0xb1c0b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1c0bc: cmp             SP, x16
    //     0xb1c0c0: b.ls            #0xb1c138
    // 0xb1c0c4: r1 = 1
    //     0xb1c0c4: mov             x1, #1
    // 0xb1c0c8: r0 = AllocateContext()
    //     0xb1c0c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xb1c0cc: mov             x1, x0
    // 0xb1c0d0: ldr             x0, [fp, #0x18]
    // 0xb1c0d4: stur            x1, [fp, #-8]
    // 0xb1c0d8: StoreField: r1->field_f = r0
    //     0xb1c0d8: stur            w0, [x1, #0xf]
    // 0xb1c0dc: SaveReg r0
    //     0xb1c0dc: str             x0, [SP, #-8]!
    // 0xb1c0e0: r0 = _buildEmoji()
    //     0xb1c0e0: bl              #0xb1c198  ; [package:emoji_picker_flutter/src/emoji_cell.dart] EmojiCell::_buildEmoji
    // 0xb1c0e4: add             SP, SP, #8
    // 0xb1c0e8: ldur            x2, [fp, #-8]
    // 0xb1c0ec: r1 = Function '<anonymous closure>':.
    //     0xb1c0ec: add             x1, PP, #0x55, lsl #12  ; [pp+0x55c98] AnonymousClosure: (0xb1c40c), in [package:emoji_picker_flutter/src/emoji_cell.dart] EmojiCell::build (0xb1c0ac)
    //     0xb1c0f0: ldr             x1, [x1, #0xc98]
    // 0xb1c0f4: stur            x0, [fp, #-0x10]
    // 0xb1c0f8: r0 = AllocateClosure()
    //     0xb1c0f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb1c0fc: ldur            x2, [fp, #-8]
    // 0xb1c100: r1 = Function '<anonymous closure>':.
    //     0xb1c100: add             x1, PP, #0x55, lsl #12  ; [pp+0x55ca0] AnonymousClosure: (0xb1c324), in [package:emoji_picker_flutter/src/emoji_cell.dart] EmojiCell::build (0xb1c0ac)
    //     0xb1c104: ldr             x1, [x1, #0xca0]
    // 0xb1c108: stur            x0, [fp, #-8]
    // 0xb1c10c: r0 = AllocateClosure()
    //     0xb1c10c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb1c110: ldr             x16, [fp, #0x18]
    // 0xb1c114: ldur            lr, [fp, #-0x10]
    // 0xb1c118: stp             lr, x16, [SP, #-0x10]!
    // 0xb1c11c: ldur            x16, [fp, #-8]
    // 0xb1c120: stp             x16, x0, [SP, #-0x10]!
    // 0xb1c124: r0 = _buildButtonWidget()
    //     0xb1c124: bl              #0xb1c140  ; [package:emoji_picker_flutter/src/emoji_cell.dart] EmojiCell::_buildButtonWidget
    // 0xb1c128: add             SP, SP, #0x20
    // 0xb1c12c: LeaveFrame
    //     0xb1c12c: mov             SP, fp
    //     0xb1c130: ldp             fp, lr, [SP], #0x10
    // 0xb1c134: ret
    //     0xb1c134: ret             
    // 0xb1c138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c138: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c13c: b               #0xb1c0c4
  }
  _ _buildButtonWidget(/* No info */) {
    // ** addr: 0xb1c140, size: 0x58
    // 0xb1c140: EnterFrame
    //     0xb1c140: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c144: mov             fp, SP
    // 0xb1c148: r0 = InkWell()
    //     0xb1c148: bl              #0x832ed8  ; AllocateInkWellStub -> InkWell (size=0x7c)
    // 0xb1c14c: ldr             x1, [fp, #0x20]
    // 0xb1c150: StoreField: r0->field_b = r1
    //     0xb1c150: stur            w1, [x0, #0xb]
    // 0xb1c154: ldr             x1, [fp, #0x10]
    // 0xb1c158: StoreField: r0->field_f = r1
    //     0xb1c158: stur            w1, [x0, #0xf]
    // 0xb1c15c: ldr             x1, [fp, #0x18]
    // 0xb1c160: StoreField: r0->field_23 = r1
    //     0xb1c160: stur            w1, [x0, #0x23]
    // 0xb1c164: r1 = true
    //     0xb1c164: add             x1, NULL, #0x20  ; true
    // 0xb1c168: StoreField: r0->field_33 = r1
    //     0xb1c168: stur            w1, [x0, #0x33]
    // 0xb1c16c: r2 = Instance_BoxShape
    //     0xb1c16c: add             x2, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0xb1c170: ldr             x2, [x2, #0xe68]
    // 0xb1c174: StoreField: r0->field_37 = r2
    //     0xb1c174: stur            w2, [x0, #0x37]
    // 0xb1c178: StoreField: r0->field_5f = r1
    //     0xb1c178: stur            w1, [x0, #0x5f]
    // 0xb1c17c: r2 = false
    //     0xb1c17c: add             x2, NULL, #0x30  ; false
    // 0xb1c180: StoreField: r0->field_63 = r2
    //     0xb1c180: stur            w2, [x0, #0x63]
    // 0xb1c184: StoreField: r0->field_73 = r1
    //     0xb1c184: stur            w1, [x0, #0x73]
    // 0xb1c188: StoreField: r0->field_6b = r2
    //     0xb1c188: stur            w2, [x0, #0x6b]
    // 0xb1c18c: LeaveFrame
    //     0xb1c18c: mov             SP, fp
    //     0xb1c190: ldp             fp, lr, [SP], #0x10
    // 0xb1c194: ret
    //     0xb1c194: ret             
  }
  _ _buildEmoji(/* No info */) {
    // ** addr: 0xb1c198, size: 0x180
    // 0xb1c198: EnterFrame
    //     0xb1c198: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c19c: mov             fp, SP
    // 0xb1c1a0: AllocStack(0x28)
    //     0xb1c1a0: sub             SP, SP, #0x28
    // 0xb1c1a4: CheckStackOverflow
    //     0xb1c1a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1c1a8: cmp             SP, x16
    //     0xb1c1ac: b.ls            #0xb1c2f8
    // 0xb1c1b0: ldr             x0, [fp, #0x10]
    // 0xb1c1b4: LoadField: d0 = r0->field_f
    //     0xb1c1b4: ldur            d0, [x0, #0xf]
    // 0xb1c1b8: stur            d0, [fp, #-0x28]
    // 0xb1c1bc: r0 = TextStyle()
    //     0xb1c1bc: bl              #0x6cecec  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xb1c1c0: mov             x1, x0
    // 0xb1c1c4: r0 = true
    //     0xb1c1c4: add             x0, NULL, #0x20  ; true
    // 0xb1c1c8: stur            x1, [fp, #-0x18]
    // 0xb1c1cc: StoreField: r1->field_7 = r0
    //     0xb1c1cc: stur            w0, [x1, #7]
    // 0xb1c1d0: r0 = Instance_Color
    //     0xb1c1d0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xb1c1d4: ldr             x0, [x0, #0xc08]
    // 0xb1c1d8: StoreField: r1->field_f = r0
    //     0xb1c1d8: stur            w0, [x1, #0xf]
    // 0xb1c1dc: ldur            d0, [fp, #-0x28]
    // 0xb1c1e0: r0 = inline_Allocate_Double()
    //     0xb1c1e0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb1c1e4: add             x0, x0, #0x10
    //     0xb1c1e8: cmp             x2, x0
    //     0xb1c1ec: b.ls            #0xb1c300
    //     0xb1c1f0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1c1f4: sub             x0, x0, #0xf
    //     0xb1c1f8: mov             x2, #0xd108
    //     0xb1c1fc: movk            x2, #3, lsl #16
    //     0xb1c200: stur            x2, [x0, #-1]
    // 0xb1c204: StoreField: r0->field_7 = d0
    //     0xb1c204: stur            d0, [x0, #7]
    // 0xb1c208: StoreField: r1->field_1f = r0
    //     0xb1c208: stur            w0, [x1, #0x1f]
    // 0xb1c20c: ldr             x0, [fp, #0x10]
    // 0xb1c210: LoadField: r2 = r0->field_b
    //     0xb1c210: ldur            w2, [x0, #0xb]
    // 0xb1c214: DecompressPointer r2
    //     0xb1c214: add             x2, x2, HEAP, lsl #32
    // 0xb1c218: stur            x2, [fp, #-0x10]
    // 0xb1c21c: LoadField: r3 = r2->field_7
    //     0xb1c21c: ldur            w3, [x2, #7]
    // 0xb1c220: DecompressPointer r3
    //     0xb1c220: add             x3, x3, HEAP, lsl #32
    // 0xb1c224: stur            x3, [fp, #-8]
    // 0xb1c228: r0 = Text()
    //     0xb1c228: bl              #0x596214  ; AllocateTextStub -> Text (size=0x48)
    // 0xb1c22c: mov             x1, x0
    // 0xb1c230: ldur            x0, [fp, #-8]
    // 0xb1c234: stur            x1, [fp, #-0x20]
    // 0xb1c238: StoreField: r1->field_b = r0
    //     0xb1c238: stur            w0, [x1, #0xb]
    // 0xb1c23c: ldur            x0, [fp, #-0x18]
    // 0xb1c240: StoreField: r1->field_13 = r0
    //     0xb1c240: stur            w0, [x1, #0x13]
    // 0xb1c244: r0 = 1.000000
    //     0xb1c244: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xb1c248: StoreField: r1->field_2f = r0
    //     0xb1c248: stur            w0, [x1, #0x2f]
    // 0xb1c24c: ldur            x0, [fp, #-0x10]
    // 0xb1c250: LoadField: r2 = r0->field_f
    //     0xb1c250: ldur            w2, [x0, #0xf]
    // 0xb1c254: DecompressPointer r2
    //     0xb1c254: add             x2, x2, HEAP, lsl #32
    // 0xb1c258: tbnz            w2, #4, #0xb1c2cc
    // 0xb1c25c: ldr             x0, [fp, #0x10]
    // 0xb1c260: LoadField: r2 = r0->field_27
    //     0xb1c260: ldur            w2, [x0, #0x27]
    // 0xb1c264: DecompressPointer r2
    //     0xb1c264: add             x2, x2, HEAP, lsl #32
    // 0xb1c268: tbnz            w2, #4, #0xb1c2cc
    // 0xb1c26c: LoadField: r2 = r0->field_33
    //     0xb1c26c: ldur            w2, [x0, #0x33]
    // 0xb1c270: DecompressPointer r2
    //     0xb1c270: add             x2, x2, HEAP, lsl #32
    // 0xb1c274: cmp             w2, NULL
    // 0xb1c278: b.eq            #0xb1c2cc
    // 0xb1c27c: r0 = TriangleDecoration()
    //     0xb1c27c: bl              #0xb1c318  ; AllocateTriangleDecorationStub -> TriangleDecoration (size=0x14)
    // 0xb1c280: mov             x1, x0
    // 0xb1c284: r0 = Instance_MaterialColor
    //     0xb1c284: add             x0, PP, #0x2f, lsl #12  ; [pp+0x2f8d0] Obj!MaterialColor<int>@b5e3f1
    //     0xb1c288: ldr             x0, [x0, #0x8d0]
    // 0xb1c28c: stur            x1, [fp, #-8]
    // 0xb1c290: StoreField: r1->field_7 = r0
    //     0xb1c290: stur            w0, [x1, #7]
    // 0xb1c294: d0 = 8.000000
    //     0xb1c294: fmov            d0, #8.00000000
    // 0xb1c298: StoreField: r1->field_b = d0
    //     0xb1c298: stur            d0, [x1, #0xb]
    // 0xb1c29c: r0 = Container()
    //     0xb1c29c: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xb1c2a0: stur            x0, [fp, #-0x10]
    // 0xb1c2a4: ldur            x16, [fp, #-8]
    // 0xb1c2a8: stp             x16, x0, [SP, #-0x10]!
    // 0xb1c2ac: ldur            x16, [fp, #-0x20]
    // 0xb1c2b0: SaveReg r16
    //     0xb1c2b0: str             x16, [SP, #-8]!
    // 0xb1c2b4: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, decoration, 0x1, null]
    //     0xb1c2b4: add             x4, PP, #0x27, lsl #12  ; [pp+0x27018] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0xb1c2b8: ldr             x4, [x4, #0x18]
    // 0xb1c2bc: r0 = Container()
    //     0xb1c2bc: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xb1c2c0: add             SP, SP, #0x18
    // 0xb1c2c4: ldur            x0, [fp, #-0x10]
    // 0xb1c2c8: b               #0xb1c2d0
    // 0xb1c2cc: ldur            x0, [fp, #-0x20]
    // 0xb1c2d0: stur            x0, [fp, #-8]
    // 0xb1c2d4: r0 = Center()
    //     0xb1c2d4: bl              #0x826060  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xb1c2d8: r1 = Instance_Alignment
    //     0xb1c2d8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb1c2dc: ldr             x1, [x1, #0xc70]
    // 0xb1c2e0: StoreField: r0->field_f = r1
    //     0xb1c2e0: stur            w1, [x0, #0xf]
    // 0xb1c2e4: ldur            x1, [fp, #-8]
    // 0xb1c2e8: StoreField: r0->field_b = r1
    //     0xb1c2e8: stur            w1, [x0, #0xb]
    // 0xb1c2ec: LeaveFrame
    //     0xb1c2ec: mov             SP, fp
    //     0xb1c2f0: ldp             fp, lr, [SP], #0x10
    // 0xb1c2f4: ret
    //     0xb1c2f4: ret             
    // 0xb1c2f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c2f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c2fc: b               #0xb1c1b0
    // 0xb1c300: SaveReg d0
    //     0xb1c300: str             q0, [SP, #-0x10]!
    // 0xb1c304: SaveReg r1
    //     0xb1c304: str             x1, [SP, #-8]!
    // 0xb1c308: r0 = AllocateDouble()
    //     0xb1c308: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb1c30c: RestoreReg r1
    //     0xb1c30c: ldr             x1, [SP], #8
    // 0xb1c310: RestoreReg d0
    //     0xb1c310: ldr             q0, [SP], #0x10
    // 0xb1c314: b               #0xb1c204
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xb1c324, size: 0xe8
    // 0xb1c324: EnterFrame
    //     0xb1c324: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c328: mov             fp, SP
    // 0xb1c32c: ldr             x0, [fp, #0x10]
    // 0xb1c330: LoadField: r1 = r0->field_17
    //     0xb1c330: ldur            w1, [x0, #0x17]
    // 0xb1c334: DecompressPointer r1
    //     0xb1c334: add             x1, x1, HEAP, lsl #32
    // 0xb1c338: CheckStackOverflow
    //     0xb1c338: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1c33c: cmp             SP, x16
    //     0xb1c340: b.ls            #0xb1c3e0
    // 0xb1c344: LoadField: r0 = r1->field_f
    //     0xb1c344: ldur            w0, [x1, #0xf]
    // 0xb1c348: DecompressPointer r0
    //     0xb1c348: add             x0, x0, HEAP, lsl #32
    // 0xb1c34c: LoadField: r2 = r0->field_33
    //     0xb1c34c: ldur            w2, [x0, #0x33]
    // 0xb1c350: DecompressPointer r2
    //     0xb1c350: add             x2, x2, HEAP, lsl #32
    // 0xb1c354: cmp             w2, NULL
    // 0xb1c358: b.eq            #0xb1c3d0
    // 0xb1c35c: LoadField: r3 = r0->field_b
    //     0xb1c35c: ldur            w3, [x0, #0xb]
    // 0xb1c360: DecompressPointer r3
    //     0xb1c360: add             x3, x3, HEAP, lsl #32
    // 0xb1c364: LoadField: d0 = r0->field_f
    //     0xb1c364: ldur            d0, [x0, #0xf]
    // 0xb1c368: LoadField: r4 = r0->field_17
    //     0xb1c368: ldur            w4, [x0, #0x17]
    // 0xb1c36c: DecompressPointer r4
    //     0xb1c36c: add             x4, x4, HEAP, lsl #32
    // 0xb1c370: LoadField: r5 = r0->field_1f
    //     0xb1c370: ldur            x5, [x0, #0x1f]
    // 0xb1c374: r6 = inline_Allocate_Double()
    //     0xb1c374: ldp             x6, x0, [THR, #0x60]  ; THR::top
    //     0xb1c378: add             x6, x6, #0x10
    //     0xb1c37c: cmp             x0, x6
    //     0xb1c380: b.ls            #0xb1c3e8
    //     0xb1c384: str             x6, [THR, #0x60]  ; THR::top
    //     0xb1c388: sub             x6, x6, #0xf
    //     0xb1c38c: mov             x0, #0xd108
    //     0xb1c390: movk            x0, #3, lsl #16
    //     0xb1c394: stur            x0, [x6, #-1]
    // 0xb1c398: StoreField: r6->field_7 = d0
    //     0xb1c398: stur            d0, [x6, #7]
    // 0xb1c39c: r0 = BoxInt64Instr(r5)
    //     0xb1c39c: sbfiz           x0, x5, #1, #0x1f
    //     0xb1c3a0: cmp             x5, x0, asr #1
    //     0xb1c3a4: b.eq            #0xb1c3b0
    //     0xb1c3a8: bl              #0xd69bb8
    //     0xb1c3ac: stur            x5, [x0, #7]
    // 0xb1c3b0: stp             x3, x2, [SP, #-0x10]!
    // 0xb1c3b4: stp             x4, x6, [SP, #-0x10]!
    // 0xb1c3b8: SaveReg r0
    //     0xb1c3b8: str             x0, [SP, #-8]!
    // 0xb1c3bc: mov             x0, x2
    // 0xb1c3c0: ClosureCall
    //     0xb1c3c0: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    //     0xb1c3c4: ldur            x2, [x0, #0x1f]
    //     0xb1c3c8: blr             x2
    // 0xb1c3cc: add             SP, SP, #0x28
    // 0xb1c3d0: r0 = Null
    //     0xb1c3d0: mov             x0, NULL
    // 0xb1c3d4: LeaveFrame
    //     0xb1c3d4: mov             SP, fp
    //     0xb1c3d8: ldp             fp, lr, [SP], #0x10
    // 0xb1c3dc: ret
    //     0xb1c3dc: ret             
    // 0xb1c3e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c3e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c3e4: b               #0xb1c344
    // 0xb1c3e8: SaveReg d0
    //     0xb1c3e8: str             q0, [SP, #-0x10]!
    // 0xb1c3ec: stp             x4, x5, [SP, #-0x10]!
    // 0xb1c3f0: stp             x2, x3, [SP, #-0x10]!
    // 0xb1c3f4: r0 = AllocateDouble()
    //     0xb1c3f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb1c3f8: mov             x6, x0
    // 0xb1c3fc: ldp             x2, x3, [SP], #0x10
    // 0xb1c400: ldp             x4, x5, [SP], #0x10
    // 0xb1c404: RestoreReg d0
    //     0xb1c404: ldr             q0, [SP], #0x10
    // 0xb1c408: b               #0xb1c398
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xb1c40c, size: 0x90
    // 0xb1c40c: EnterFrame
    //     0xb1c40c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c410: mov             fp, SP
    // 0xb1c414: ldr             x0, [fp, #0x10]
    // 0xb1c418: LoadField: r1 = r0->field_17
    //     0xb1c418: ldur            w1, [x0, #0x17]
    // 0xb1c41c: DecompressPointer r1
    //     0xb1c41c: add             x1, x1, HEAP, lsl #32
    // 0xb1c420: CheckStackOverflow
    //     0xb1c420: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1c424: cmp             SP, x16
    //     0xb1c428: b.ls            #0xb1c494
    // 0xb1c42c: LoadField: r0 = r1->field_f
    //     0xb1c42c: ldur            w0, [x1, #0xf]
    // 0xb1c430: DecompressPointer r0
    //     0xb1c430: add             x0, x0, HEAP, lsl #32
    // 0xb1c434: LoadField: r1 = r0->field_17
    //     0xb1c434: ldur            w1, [x0, #0x17]
    // 0xb1c438: DecompressPointer r1
    //     0xb1c438: add             x1, x1, HEAP, lsl #32
    // 0xb1c43c: cmp             w1, NULL
    // 0xb1c440: b.ne            #0xb1c44c
    // 0xb1c444: r1 = Null
    //     0xb1c444: mov             x1, NULL
    // 0xb1c448: b               #0xb1c458
    // 0xb1c44c: LoadField: r2 = r1->field_7
    //     0xb1c44c: ldur            w2, [x1, #7]
    // 0xb1c450: DecompressPointer r2
    //     0xb1c450: add             x2, x2, HEAP, lsl #32
    // 0xb1c454: mov             x1, x2
    // 0xb1c458: LoadField: r2 = r0->field_b
    //     0xb1c458: ldur            w2, [x0, #0xb]
    // 0xb1c45c: DecompressPointer r2
    //     0xb1c45c: add             x2, x2, HEAP, lsl #32
    // 0xb1c460: LoadField: r3 = r0->field_37
    //     0xb1c460: ldur            w3, [x0, #0x37]
    // 0xb1c464: DecompressPointer r3
    //     0xb1c464: add             x3, x3, HEAP, lsl #32
    // 0xb1c468: stp             x1, x3, [SP, #-0x10]!
    // 0xb1c46c: SaveReg r2
    //     0xb1c46c: str             x2, [SP, #-8]!
    // 0xb1c470: mov             x0, x3
    // 0xb1c474: ClosureCall
    //     0xb1c474: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb1c478: ldur            x2, [x0, #0x1f]
    //     0xb1c47c: blr             x2
    // 0xb1c480: add             SP, SP, #0x18
    // 0xb1c484: r0 = Null
    //     0xb1c484: mov             x0, NULL
    // 0xb1c488: LeaveFrame
    //     0xb1c488: mov             SP, fp
    //     0xb1c48c: ldp             fp, lr, [SP], #0x10
    // 0xb1c490: ret
    //     0xb1c490: ret             
    // 0xb1c494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c494: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c498: b               #0xb1c42c
  }
}

// lib: , url: package:emoji_picker_flutter/src/emoji_view_state.dart

// class id: 1048919, size: 0x8
class :: {
}

// class id: 4516, size: 0x14, field offset: 0x8
class EmojiViewState extends Object {
}

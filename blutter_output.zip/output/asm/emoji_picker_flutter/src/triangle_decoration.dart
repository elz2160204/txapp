// lib: , url: package:emoji_picker_flutter/src/triangle_decoration.dart

// class id: 1048923, size: 0x8
class :: {
}

// class id: 2941, size: 0x14, field offset: 0x8
class TriangleDecoration extends Decoration {

  _ createBoxPainter(/* No info */) {
    // ** addr: 0xccf38c, size: 0x44
    // 0xccf38c: EnterFrame
    //     0xccf38c: stp             fp, lr, [SP, #-0x10]!
    //     0xccf390: mov             fp, SP
    // 0xccf394: AllocStack(0x8)
    //     0xccf394: sub             SP, SP, #8
    // 0xccf398: CheckStackOverflow
    //     0xccf398: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccf39c: cmp             SP, x16
    //     0xccf3a0: b.ls            #0xccf3c8
    // 0xccf3a4: r0 = _TriangleShapePainter()
    //     0xccf3a4: bl              #0xccf4e8  ; Allocate_TriangleShapePainterStub -> _TriangleShapePainter (size=0x14)
    // 0xccf3a8: stur            x0, [fp, #-8]
    // 0xccf3ac: SaveReg r0
    //     0xccf3ac: str             x0, [SP, #-8]!
    // 0xccf3b0: r0 = _TriangleShapePainter()
    //     0xccf3b0: bl              #0xccf3d0  ; [package:emoji_picker_flutter/src/triangle_decoration.dart] _TriangleShapePainter::_TriangleShapePainter
    // 0xccf3b4: add             SP, SP, #8
    // 0xccf3b8: ldur            x0, [fp, #-8]
    // 0xccf3bc: LeaveFrame
    //     0xccf3bc: mov             SP, fp
    //     0xccf3c0: ldp             fp, lr, [SP], #0x10
    // 0xccf3c4: ret
    //     0xccf3c4: ret             
    // 0xccf3c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf3c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf3cc: b               #0xccf3a4
  }
}

// class id: 4514, size: 0x14, field offset: 0xc
class _TriangleShapePainter extends BoxPainter {

  late final double _size; // offset: 0x10
  late final Paint _painter; // offset: 0xc

  _ paint(/* No info */) {
    // ** addr: 0xc70128, size: 0x228
    // 0xc70128: EnterFrame
    //     0xc70128: stp             fp, lr, [SP, #-0x10]!
    //     0xc7012c: mov             fp, SP
    // 0xc70130: AllocStack(0x38)
    //     0xc70130: sub             SP, SP, #0x38
    // 0xc70134: CheckStackOverflow
    //     0xc70134: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc70138: cmp             SP, x16
    //     0xc7013c: b.ls            #0xc702e8
    // 0xc70140: ldr             x0, [fp, #0x10]
    // 0xc70144: LoadField: r1 = r0->field_17
    //     0xc70144: ldur            w1, [x0, #0x17]
    // 0xc70148: DecompressPointer r1
    //     0xc70148: add             x1, x1, HEAP, lsl #32
    // 0xc7014c: stur            x1, [fp, #-8]
    // 0xc70150: cmp             w1, NULL
    // 0xc70154: b.eq            #0xc702f0
    // 0xc70158: r0 = Path()
    //     0xc70158: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xc7015c: stur            x0, [fp, #-0x10]
    // 0xc70160: SaveReg r0
    //     0xc70160: str             x0, [SP, #-8]!
    // 0xc70164: r0 = _constructor()
    //     0xc70164: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xc70168: add             SP, SP, #8
    // 0xc7016c: ldur            x0, [fp, #-8]
    // 0xc70170: LoadField: d0 = r0->field_7
    //     0xc70170: ldur            d0, [x0, #7]
    // 0xc70174: ldr             x1, [fp, #0x18]
    // 0xc70178: stur            d0, [fp, #-0x38]
    // 0xc7017c: LoadField: d1 = r1->field_7
    //     0xc7017c: ldur            d1, [x1, #7]
    // 0xc70180: stur            d1, [fp, #-0x30]
    // 0xc70184: fadd            d2, d0, d1
    // 0xc70188: LoadField: d3 = r0->field_f
    //     0xc70188: ldur            d3, [x0, #0xf]
    // 0xc7018c: ldr             x0, [fp, #0x28]
    // 0xc70190: stur            d3, [fp, #-0x28]
    // 0xc70194: LoadField: r2 = r0->field_f
    //     0xc70194: ldur            w2, [x0, #0xf]
    // 0xc70198: DecompressPointer r2
    //     0xc70198: add             x2, x2, HEAP, lsl #32
    // 0xc7019c: r16 = Sentinel
    //     0xc7019c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc701a0: cmp             w2, w16
    // 0xc701a4: b.eq            #0xc702f4
    // 0xc701a8: d4 = 8.000000
    //     0xc701a8: fmov            d4, #8.00000000
    // 0xc701ac: fsub            d5, d3, d4
    // 0xc701b0: LoadField: d6 = r1->field_f
    //     0xc701b0: ldur            d6, [x1, #0xf]
    // 0xc701b4: stur            d6, [fp, #-0x20]
    // 0xc701b8: fadd            d7, d5, d6
    // 0xc701bc: stur            d7, [fp, #-0x18]
    // 0xc701c0: r1 = inline_Allocate_Double()
    //     0xc701c0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc701c4: add             x1, x1, #0x10
    //     0xc701c8: cmp             x2, x1
    //     0xc701cc: b.ls            #0xc70300
    //     0xc701d0: str             x1, [THR, #0x60]  ; THR::top
    //     0xc701d4: sub             x1, x1, #0xf
    //     0xc701d8: mov             x2, #0xd108
    //     0xc701dc: movk            x2, #3, lsl #16
    //     0xc701e0: stur            x2, [x1, #-1]
    // 0xc701e4: StoreField: r1->field_7 = d2
    //     0xc701e4: stur            d2, [x1, #7]
    // 0xc701e8: stur            x1, [fp, #-8]
    // 0xc701ec: ldur            x16, [fp, #-0x10]
    // 0xc701f0: stp             x1, x16, [SP, #-0x10]!
    // 0xc701f4: SaveReg d7
    //     0xc701f4: str             d7, [SP, #-8]!
    // 0xc701f8: r0 = moveTo()
    //     0xc701f8: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0xc701fc: add             SP, SP, #0x18
    // 0xc70200: ldur            d0, [fp, #-0x38]
    // 0xc70204: d1 = 8.000000
    //     0xc70204: fmov            d1, #8.00000000
    // 0xc70208: fsub            d2, d0, d1
    // 0xc7020c: ldur            d0, [fp, #-0x30]
    // 0xc70210: fadd            d1, d2, d0
    // 0xc70214: ldur            d0, [fp, #-0x28]
    // 0xc70218: ldur            d2, [fp, #-0x20]
    // 0xc7021c: fadd            d3, d0, d2
    // 0xc70220: stur            d3, [fp, #-0x30]
    // 0xc70224: r0 = inline_Allocate_Double()
    //     0xc70224: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc70228: add             x0, x0, #0x10
    //     0xc7022c: cmp             x1, x0
    //     0xc70230: b.ls            #0xc70334
    //     0xc70234: str             x0, [THR, #0x60]  ; THR::top
    //     0xc70238: sub             x0, x0, #0xf
    //     0xc7023c: mov             x1, #0xd108
    //     0xc70240: movk            x1, #3, lsl #16
    //     0xc70244: stur            x1, [x0, #-1]
    // 0xc70248: StoreField: r0->field_7 = d1
    //     0xc70248: stur            d1, [x0, #7]
    // 0xc7024c: ldur            x16, [fp, #-0x10]
    // 0xc70250: stp             x0, x16, [SP, #-0x10]!
    // 0xc70254: SaveReg d3
    //     0xc70254: str             d3, [SP, #-8]!
    // 0xc70258: r0 = lineTo()
    //     0xc70258: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xc7025c: add             SP, SP, #0x18
    // 0xc70260: ldur            x16, [fp, #-0x10]
    // 0xc70264: ldur            lr, [fp, #-8]
    // 0xc70268: stp             lr, x16, [SP, #-0x10]!
    // 0xc7026c: ldur            d0, [fp, #-0x30]
    // 0xc70270: SaveReg d0
    //     0xc70270: str             d0, [SP, #-8]!
    // 0xc70274: r0 = lineTo()
    //     0xc70274: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xc70278: add             SP, SP, #0x18
    // 0xc7027c: ldur            x16, [fp, #-0x10]
    // 0xc70280: ldur            lr, [fp, #-8]
    // 0xc70284: stp             lr, x16, [SP, #-0x10]!
    // 0xc70288: ldur            d0, [fp, #-0x18]
    // 0xc7028c: SaveReg d0
    //     0xc7028c: str             d0, [SP, #-8]!
    // 0xc70290: r0 = lineTo()
    //     0xc70290: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xc70294: add             SP, SP, #0x18
    // 0xc70298: ldur            x16, [fp, #-0x10]
    // 0xc7029c: SaveReg r16
    //     0xc7029c: str             x16, [SP, #-8]!
    // 0xc702a0: r0 = close()
    //     0xc702a0: bl              #0x668e78  ; [dart:ui] Path::close
    // 0xc702a4: add             SP, SP, #8
    // 0xc702a8: ldr             x0, [fp, #0x28]
    // 0xc702ac: LoadField: r1 = r0->field_b
    //     0xc702ac: ldur            w1, [x0, #0xb]
    // 0xc702b0: DecompressPointer r1
    //     0xc702b0: add             x1, x1, HEAP, lsl #32
    // 0xc702b4: r16 = Sentinel
    //     0xc702b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc702b8: cmp             w1, w16
    // 0xc702bc: b.eq            #0xc70344
    // 0xc702c0: ldr             x16, [fp, #0x20]
    // 0xc702c4: ldur            lr, [fp, #-0x10]
    // 0xc702c8: stp             lr, x16, [SP, #-0x10]!
    // 0xc702cc: SaveReg r1
    //     0xc702cc: str             x1, [SP, #-8]!
    // 0xc702d0: r0 = drawPath()
    //     0xc702d0: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xc702d4: add             SP, SP, #0x18
    // 0xc702d8: r0 = Null
    //     0xc702d8: mov             x0, NULL
    // 0xc702dc: LeaveFrame
    //     0xc702dc: mov             SP, fp
    //     0xc702e0: ldp             fp, lr, [SP], #0x10
    // 0xc702e4: ret
    //     0xc702e4: ret             
    // 0xc702e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc702e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc702ec: b               #0xc70140
    // 0xc702f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc702f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc702f4: r9 = _size
    //     0xc702f4: add             x9, PP, #0x56, lsl #12  ; [pp+0x56f88] Field <_TriangleShapePainter@396501433._size@396501433>: late final (offset: 0x10)
    //     0xc702f8: ldr             x9, [x9, #0xf88]
    // 0xc702fc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xc702fc: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xc70300: stp             q6, q7, [SP, #-0x20]!
    // 0xc70304: stp             q3, q4, [SP, #-0x20]!
    // 0xc70308: stp             q1, q2, [SP, #-0x20]!
    // 0xc7030c: SaveReg d0
    //     0xc7030c: str             q0, [SP, #-0x10]!
    // 0xc70310: SaveReg r0
    //     0xc70310: str             x0, [SP, #-8]!
    // 0xc70314: r0 = AllocateDouble()
    //     0xc70314: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc70318: mov             x1, x0
    // 0xc7031c: RestoreReg r0
    //     0xc7031c: ldr             x0, [SP], #8
    // 0xc70320: RestoreReg d0
    //     0xc70320: ldr             q0, [SP], #0x10
    // 0xc70324: ldp             q1, q2, [SP], #0x20
    // 0xc70328: ldp             q3, q4, [SP], #0x20
    // 0xc7032c: ldp             q6, q7, [SP], #0x20
    // 0xc70330: b               #0xc701e4
    // 0xc70334: stp             q1, q3, [SP, #-0x20]!
    // 0xc70338: r0 = AllocateDouble()
    //     0xc70338: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc7033c: ldp             q1, q3, [SP], #0x20
    // 0xc70340: b               #0xc70248
    // 0xc70344: r9 = _painter
    //     0xc70344: add             x9, PP, #0x56, lsl #12  ; [pp+0x56f90] Field <_TriangleShapePainter@396501433._painter@396501433>: late final (offset: 0xc)
    //     0xc70348: ldr             x9, [x9, #0xf90]
    // 0xc7034c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc7034c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _TriangleShapePainter(/* No info */) {
    // ** addr: 0xccf3d0, size: 0x118
    // 0xccf3d0: EnterFrame
    //     0xccf3d0: stp             fp, lr, [SP, #-0x10]!
    //     0xccf3d4: mov             fp, SP
    // 0xccf3d8: AllocStack(0x10)
    //     0xccf3d8: sub             SP, SP, #0x10
    // 0xccf3dc: r0 = Sentinel
    //     0xccf3dc: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xccf3e0: CheckStackOverflow
    //     0xccf3e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccf3e4: cmp             SP, x16
    //     0xccf3e8: b.ls            #0xccf4e0
    // 0xccf3ec: ldr             x1, [fp, #0x10]
    // 0xccf3f0: StoreField: r1->field_b = r0
    //     0xccf3f0: stur            w0, [x1, #0xb]
    // 0xccf3f4: StoreField: r1->field_f = r0
    //     0xccf3f4: stur            w0, [x1, #0xf]
    // 0xccf3f8: r16 = 112
    //     0xccf3f8: mov             x16, #0x70
    // 0xccf3fc: stp             x16, NULL, [SP, #-0x10]!
    // 0xccf400: r0 = ByteData()
    //     0xccf400: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xccf404: add             SP, SP, #0x10
    // 0xccf408: stur            x0, [fp, #-8]
    // 0xccf40c: r0 = Paint()
    //     0xccf40c: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xccf410: mov             x1, x0
    // 0xccf414: ldur            x0, [fp, #-8]
    // 0xccf418: stur            x1, [fp, #-0x10]
    // 0xccf41c: StoreField: r1->field_7 = r0
    //     0xccf41c: stur            w0, [x1, #7]
    // 0xccf420: LoadField: r2 = r0->field_17
    //     0xccf420: ldur            w2, [x0, #0x17]
    // 0xccf424: DecompressPointer r2
    //     0xccf424: add             x2, x2, HEAP, lsl #32
    // 0xccf428: LoadField: r0 = r2->field_7
    //     0xccf428: ldur            x0, [x2, #7]
    // 0xccf42c: r3 = 10395294
    //     0xccf42c: mov             x3, #0x9e9e
    //     0xccf430: movk            x3, #0x9e, lsl #16
    // 0xccf434: str             w3, [x0, #4]
    // 0xccf438: LoadField: r0 = r2->field_7
    //     0xccf438: ldur            x0, [x2, #7]
    // 0xccf43c: str             wzr, [x0, #0xc]
    // 0xccf440: ldr             x0, [fp, #0x10]
    // 0xccf444: LoadField: r2 = r0->field_b
    //     0xccf444: ldur            w2, [x0, #0xb]
    // 0xccf448: DecompressPointer r2
    //     0xccf448: add             x2, x2, HEAP, lsl #32
    // 0xccf44c: r16 = Sentinel
    //     0xccf44c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xccf450: cmp             w2, w16
    // 0xccf454: b.ne            #0xccf460
    // 0xccf458: mov             x1, x0
    // 0xccf45c: b               #0xccf478
    // 0xccf460: r16 = "_painter@396501433"
    //     0xccf460: add             x16, PP, #0x56, lsl #12  ; [pp+0x56958] "_painter@396501433"
    //     0xccf464: ldr             x16, [x16, #0x958]
    // 0xccf468: SaveReg r16
    //     0xccf468: str             x16, [SP, #-8]!
    // 0xccf46c: r0 = _throwFieldAlreadyInitialized()
    //     0xccf46c: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xccf470: add             SP, SP, #8
    // 0xccf474: ldr             x1, [fp, #0x10]
    // 0xccf478: ldur            x0, [fp, #-0x10]
    // 0xccf47c: StoreField: r1->field_b = r0
    //     0xccf47c: stur            w0, [x1, #0xb]
    //     0xccf480: ldurb           w16, [x1, #-1]
    //     0xccf484: ldurb           w17, [x0, #-1]
    //     0xccf488: and             x16, x17, x16, lsr #2
    //     0xccf48c: tst             x16, HEAP, lsr #32
    //     0xccf490: b.eq            #0xccf498
    //     0xccf494: bl              #0xd6826c
    // 0xccf498: LoadField: r0 = r1->field_f
    //     0xccf498: ldur            w0, [x1, #0xf]
    // 0xccf49c: DecompressPointer r0
    //     0xccf49c: add             x0, x0, HEAP, lsl #32
    // 0xccf4a0: r16 = Sentinel
    //     0xccf4a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xccf4a4: cmp             w0, w16
    // 0xccf4a8: b.eq            #0xccf4c4
    // 0xccf4ac: r16 = "_size@396501433"
    //     0xccf4ac: add             x16, PP, #0x56, lsl #12  ; [pp+0x56960] "_size@396501433"
    //     0xccf4b0: ldr             x16, [x16, #0x960]
    // 0xccf4b4: SaveReg r16
    //     0xccf4b4: str             x16, [SP, #-8]!
    // 0xccf4b8: r0 = _throwFieldAlreadyInitialized()
    //     0xccf4b8: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xccf4bc: add             SP, SP, #8
    // 0xccf4c0: ldr             x1, [fp, #0x10]
    // 0xccf4c4: r2 = 8.000000
    //     0xccf4c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26c18] 8
    //     0xccf4c8: ldr             x2, [x2, #0xc18]
    // 0xccf4cc: StoreField: r1->field_f = r2
    //     0xccf4cc: stur            w2, [x1, #0xf]
    // 0xccf4d0: r0 = Null
    //     0xccf4d0: mov             x0, NULL
    // 0xccf4d4: LeaveFrame
    //     0xccf4d4: mov             SP, fp
    //     0xccf4d8: ldp             fp, lr, [SP], #0x10
    // 0xccf4dc: ret
    //     0xccf4dc: ret             
    // 0xccf4e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf4e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf4e4: b               #0xccf3ec
  }
}

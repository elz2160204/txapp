// lib: , url: package:emoji_picker_flutter/src/emoji_picker_internal_utils.dart

// class id: 1048915, size: 0x8
class :: {
}

// class id: 4518, size: 0x8, field offset: 0x8
class EmojiPickerInternalUtils extends Object {

  _ filterUnsupported(/* No info */) async {
    // ** addr: 0x798ed4, size: 0x210
    // 0x798ed4: EnterFrame
    //     0x798ed4: stp             fp, lr, [SP, #-0x10]!
    //     0x798ed8: mov             fp, SP
    // 0x798edc: AllocStack(0x38)
    //     0x798edc: sub             SP, SP, #0x38
    // 0x798ee0: SetupParameters(EmojiPickerInternalUtils this /* r1, fp-0x10 */)
    //     0x798ee0: stur            NULL, [fp, #-8]
    //     0x798ee4: mov             x0, #0
    //     0x798ee8: add             x1, fp, w0, sxtw #2
    //     0x798eec: ldr             x1, [x1, #0x10]
    //     0x798ef0: stur            x1, [fp, #-0x10]
    // 0x798ef4: CheckStackOverflow
    //     0x798ef4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x798ef8: cmp             SP, x16
    //     0x798efc: b.ls            #0x7990cc
    // 0x798f00: InitAsync() -> Future<List<CategoryEmoji>>
    //     0x798f00: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c878] TypeArguments: <List<CategoryEmoji>>
    //     0x798f04: ldr             x0, [x0, #0x878]
    //     0x798f08: bl              #0x4b92e4
    // 0x798f0c: r0 = InitLateStaticField(0x698) // [dart:io] Platform::isAndroid
    //     0x798f0c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x798f10: ldr             x0, [x0, #0xd30]
    //     0x798f14: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x798f18: cmp             w0, w16
    //     0x798f1c: b.ne            #0x798f28
    //     0x798f20: ldr             x2, [PP, #0x60]  ; [pp+0x60] Field <Platform.isAndroid>: static late final (offset: 0x698)
    //     0x798f24: bl              #0xd67cdc
    // 0x798f28: tbz             w0, #4, #0x798f38
    // 0x798f2c: r0 = const [Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji']
    //     0x798f2c: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c880] List<CategoryEmoji>(8)
    //     0x798f30: ldr             x0, [x0, #0x880]
    // 0x798f34: r0 = ReturnAsyncNotFuture()
    //     0x798f34: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x798f38: r16 = <Future<CategoryEmoji>>
    //     0x798f38: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c888] TypeArguments: <Future<CategoryEmoji>>
    //     0x798f3c: ldr             x16, [x16, #0x888]
    // 0x798f40: stp             xzr, x16, [SP, #-0x10]!
    // 0x798f44: r0 = _GrowableList()
    //     0x798f44: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x798f48: add             SP, SP, #0x10
    // 0x798f4c: mov             x4, x0
    // 0x798f50: r3 = const [Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji']
    //     0x798f50: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c880] List<CategoryEmoji>(8)
    //     0x798f54: ldr             x3, [x3, #0x880]
    // 0x798f58: stur            x4, [fp, #-0x30]
    // 0x798f5c: LoadField: r5 = r3->field_7
    //     0x798f5c: ldur            w5, [x3, #7]
    // 0x798f60: DecompressPointer r5
    //     0x798f60: add             x5, x5, HEAP, lsl #32
    // 0x798f64: stur            x5, [fp, #-0x28]
    // 0x798f68: r2 = 0
    //     0x798f68: mov             x2, #0
    // 0x798f6c: CheckStackOverflow
    //     0x798f6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x798f70: cmp             SP, x16
    //     0x798f74: b.ls            #0x7990d4
    // 0x798f78: cmp             x2, #8
    // 0x798f7c: b.lt            #0x798fa8
    // 0x798f80: r16 = <CategoryEmoji>
    //     0x798f80: add             x16, PP, #0x41, lsl #12  ; [pp+0x41078] TypeArguments: <CategoryEmoji>
    //     0x798f84: ldr             x16, [x16, #0x78]
    // 0x798f88: stp             x4, x16, [SP, #-0x10]!
    // 0x798f8c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x798f8c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x798f90: r0 = wait()
    //     0x798f90: bl              #0x518f0c  ; [dart:async] Future::wait
    // 0x798f94: add             SP, SP, #0x10
    // 0x798f98: mov             x1, x0
    // 0x798f9c: stur            x1, [fp, #-0x18]
    // 0x798fa0: r0 = Await()
    //     0x798fa0: bl              #0x4b8e6c  ; AwaitStub
    // 0x798fa4: r0 = ReturnAsync()
    //     0x798fa4: b               #0x501858  ; ReturnAsyncStub
    // 0x798fa8: mov             x1, x2
    // 0x798fac: r0 = 8
    //     0x798fac: mov             x0, #8
    // 0x798fb0: cmp             x1, x0
    // 0x798fb4: b.hs            #0x7990dc
    // 0x798fb8: ArrayLoad: r6 = r3[r2]  ; Unknown_4
    //     0x798fb8: add             x16, x3, x2, lsl #2
    //     0x798fbc: ldur            w6, [x16, #0xf]
    // 0x798fc0: DecompressPointer r6
    //     0x798fc0: add             x6, x6, HEAP, lsl #32
    // 0x798fc4: stur            x6, [fp, #-0x18]
    // 0x798fc8: add             x7, x2, #1
    // 0x798fcc: stur            x7, [fp, #-0x20]
    // 0x798fd0: cmp             w6, NULL
    // 0x798fd4: b.ne            #0x799008
    // 0x798fd8: mov             x0, x6
    // 0x798fdc: mov             x2, x5
    // 0x798fe0: r1 = Null
    //     0x798fe0: mov             x1, NULL
    // 0x798fe4: cmp             w2, NULL
    // 0x798fe8: b.eq            #0x799008
    // 0x798fec: LoadField: r4 = r2->field_17
    //     0x798fec: ldur            w4, [x2, #0x17]
    // 0x798ff0: DecompressPointer r4
    //     0x798ff0: add             x4, x4, HEAP, lsl #32
    // 0x798ff4: r8 = X0
    //     0x798ff4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x798ff8: LoadField: r9 = r4->field_7
    //     0x798ff8: ldur            x9, [x4, #7]
    // 0x798ffc: r3 = Null
    //     0x798ffc: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c890] Null
    //     0x799000: ldr             x3, [x3, #0x890]
    // 0x799004: blr             x9
    // 0x799008: ldur            x0, [fp, #-0x30]
    // 0x79900c: ldur            x16, [fp, #-0x10]
    // 0x799010: ldur            lr, [fp, #-0x18]
    // 0x799014: stp             lr, x16, [SP, #-0x10]!
    // 0x799018: r0 = _getAvailableEmojis()
    //     0x799018: bl              #0x7990e4  ; [package:emoji_picker_flutter/src/emoji_picker_internal_utils.dart] EmojiPickerInternalUtils::_getAvailableEmojis
    // 0x79901c: add             SP, SP, #0x10
    // 0x799020: mov             x1, x0
    // 0x799024: ldur            x0, [fp, #-0x30]
    // 0x799028: stur            x1, [fp, #-0x38]
    // 0x79902c: LoadField: r2 = r0->field_b
    //     0x79902c: ldur            w2, [x0, #0xb]
    // 0x799030: DecompressPointer r2
    //     0x799030: add             x2, x2, HEAP, lsl #32
    // 0x799034: stur            x2, [fp, #-0x18]
    // 0x799038: LoadField: r3 = r0->field_f
    //     0x799038: ldur            w3, [x0, #0xf]
    // 0x79903c: DecompressPointer r3
    //     0x79903c: add             x3, x3, HEAP, lsl #32
    // 0x799040: LoadField: r4 = r3->field_b
    //     0x799040: ldur            w4, [x3, #0xb]
    // 0x799044: DecompressPointer r4
    //     0x799044: add             x4, x4, HEAP, lsl #32
    // 0x799048: cmp             w2, w4
    // 0x79904c: b.ne            #0x79905c
    // 0x799050: SaveReg r0
    //     0x799050: str             x0, [SP, #-8]!
    // 0x799054: r0 = _growToNextCapacity()
    //     0x799054: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x799058: add             SP, SP, #8
    // 0x79905c: ldur            x3, [fp, #-0x30]
    // 0x799060: ldur            x2, [fp, #-0x18]
    // 0x799064: r4 = LoadInt32Instr(r2)
    //     0x799064: sbfx            x4, x2, #1, #0x1f
    // 0x799068: add             x0, x4, #1
    // 0x79906c: lsl             x2, x0, #1
    // 0x799070: StoreField: r3->field_b = r2
    //     0x799070: stur            w2, [x3, #0xb]
    // 0x799074: mov             x1, x4
    // 0x799078: cmp             x1, x0
    // 0x79907c: b.hs            #0x7990e0
    // 0x799080: LoadField: r1 = r3->field_f
    //     0x799080: ldur            w1, [x3, #0xf]
    // 0x799084: DecompressPointer r1
    //     0x799084: add             x1, x1, HEAP, lsl #32
    // 0x799088: ldur            x0, [fp, #-0x38]
    // 0x79908c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x79908c: add             x25, x1, x4, lsl #2
    //     0x799090: add             x25, x25, #0xf
    //     0x799094: str             w0, [x25]
    //     0x799098: tbz             w0, #0, #0x7990b4
    //     0x79909c: ldurb           w16, [x1, #-1]
    //     0x7990a0: ldurb           w17, [x0, #-1]
    //     0x7990a4: and             x16, x17, x16, lsr #2
    //     0x7990a8: tst             x16, HEAP, lsr #32
    //     0x7990ac: b.eq            #0x7990b4
    //     0x7990b0: bl              #0xd67e5c
    // 0x7990b4: ldur            x2, [fp, #-0x20]
    // 0x7990b8: mov             x4, x3
    // 0x7990bc: ldur            x5, [fp, #-0x28]
    // 0x7990c0: r3 = const [Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji', Instance of 'CategoryEmoji']
    //     0x7990c0: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c880] List<CategoryEmoji>(8)
    //     0x7990c4: ldr             x3, [x3, #0x880]
    // 0x7990c8: b               #0x798f6c
    // 0x7990cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7990cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7990d0: b               #0x798f00
    // 0x7990d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7990d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7990d8: b               #0x798f78
    // 0x7990dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7990dc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x7990e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7990e0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _getAvailableEmojis(/* No info */) async {
    // ** addr: 0x7990e4, size: 0x2d4
    // 0x7990e4: EnterFrame
    //     0x7990e4: stp             fp, lr, [SP, #-0x10]!
    //     0x7990e8: mov             fp, SP
    // 0x7990ec: AllocStack(0x40)
    //     0x7990ec: sub             SP, SP, #0x40
    // 0x7990f0: SetupParameters(EmojiPickerInternalUtils this /* r1, fp-0x10 */)
    //     0x7990f0: stur            NULL, [fp, #-8]
    //     0x7990f4: mov             x0, #0
    //     0x7990f8: add             x1, fp, w0, sxtw #2
    //     0x7990fc: ldr             x1, [x1, #0x10]
    //     0x799100: stur            x1, [fp, #-0x10]
    // 0x799104: CheckStackOverflow
    //     0x799104: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x799108: cmp             SP, x16
    //     0x79910c: b.ls            #0x7993a0
    // 0x799110: InitAsync() -> Future<CategoryEmoji>
    //     0x799110: add             x0, PP, #0x41, lsl #12  ; [pp+0x41078] TypeArguments: <CategoryEmoji>
    //     0x799114: ldr             x0, [x0, #0x78]
    //     0x799118: bl              #0x4b92e4
    // 0x79911c: r1 = Null
    //     0x79911c: mov             x1, NULL
    // 0x799120: r2 = 4
    //     0x799120: mov             x2, #4
    // 0x799124: r0 = AllocateArray()
    //     0x799124: bl              #0xd6987c  ; AllocateArrayStub
    // 0x799128: stur            x0, [fp, #-0x20]
    // 0x79912c: r17 = "source"
    //     0x79912c: ldr             x17, [PP, #0x56d8]  ; [pp+0x56d8] "source"
    // 0x799130: StoreField: r0->field_f = r17
    //     0x799130: stur            w17, [x0, #0xf]
    // 0x799134: ldur            x3, [fp, #-0x10]
    // 0x799138: LoadField: r4 = r3->field_b
    //     0x799138: ldur            w4, [x3, #0xb]
    // 0x79913c: DecompressPointer r4
    //     0x79913c: add             x4, x4, HEAP, lsl #32
    // 0x799140: stur            x4, [fp, #-0x18]
    // 0x799144: r1 = Function '<anonymous closure>':.
    //     0x799144: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c8a0] Function: [dart:ui] Image::_image (0xd61d9c)
    //     0x799148: ldr             x1, [x1, #0x8a0]
    // 0x79914c: r2 = Null
    //     0x79914c: mov             x2, NULL
    // 0x799150: r0 = AllocateClosure()
    //     0x799150: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x799154: r16 = <String>
    //     0x799154: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x799158: ldur            lr, [fp, #-0x18]
    // 0x79915c: stp             lr, x16, [SP, #-0x10]!
    // 0x799160: SaveReg r0
    //     0x799160: str             x0, [SP, #-8]!
    // 0x799164: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x799164: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x799168: r0 = map()
    //     0x799168: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x79916c: add             SP, SP, #0x18
    // 0x799170: r16 = false
    //     0x799170: add             x16, NULL, #0x30  ; false
    // 0x799174: stp             x16, x0, [SP, #-0x10]!
    // 0x799178: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0x799178: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0x79917c: r0 = toList()
    //     0x79917c: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x799180: add             SP, SP, #0x10
    // 0x799184: ldur            x1, [fp, #-0x20]
    // 0x799188: ArrayStore: r1[1] = r0  ; List_4
    //     0x799188: add             x25, x1, #0x13
    //     0x79918c: str             w0, [x25]
    //     0x799190: tbz             w0, #0, #0x7991ac
    //     0x799194: ldurb           w16, [x1, #-1]
    //     0x799198: ldurb           w17, [x0, #-1]
    //     0x79919c: and             x16, x17, x16, lsr #2
    //     0x7991a0: tst             x16, HEAP, lsr #32
    //     0x7991a4: b.eq            #0x7991ac
    //     0x7991a8: bl              #0xd67e5c
    // 0x7991ac: r16 = <String, List<String>>
    //     0x7991ac: add             x16, PP, #0x13, lsl #12  ; [pp+0x13010] TypeArguments: <String, List<String>>
    //     0x7991b0: ldr             x16, [x16, #0x10]
    // 0x7991b4: ldur            lr, [fp, #-0x20]
    // 0x7991b8: stp             lr, x16, [SP, #-0x10]!
    // 0x7991bc: r0 = Map._fromLiteral()
    //     0x7991bc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x7991c0: add             SP, SP, #0x10
    // 0x7991c4: r16 = <bool>
    //     0x7991c4: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x7991c8: r30 = Instance_MethodChannel
    //     0x7991c8: add             lr, PP, #0x4c, lsl #12  ; [pp+0x4c8a8] Obj!MethodChannel@b34c31
    //     0x7991cc: ldr             lr, [lr, #0x8a8]
    // 0x7991d0: stp             lr, x16, [SP, #-0x10]!
    // 0x7991d4: r16 = "getSupportedEmojis"
    //     0x7991d4: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c8b0] "getSupportedEmojis"
    //     0x7991d8: ldr             x16, [x16, #0x8b0]
    // 0x7991dc: stp             x0, x16, [SP, #-0x10]!
    // 0x7991e0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x7991e0: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x7991e4: r0 = invokeListMethod()
    //     0x7991e4: bl              #0x799418  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeListMethod
    // 0x7991e8: add             SP, SP, #0x20
    // 0x7991ec: mov             x1, x0
    // 0x7991f0: stur            x1, [fp, #-0x20]
    // 0x7991f4: r0 = Await()
    //     0x7991f4: bl              #0x4b8e6c  ; AwaitStub
    // 0x7991f8: stur            x0, [fp, #-0x20]
    // 0x7991fc: cmp             w0, NULL
    // 0x799200: b.eq            #0x7993a8
    // 0x799204: r16 = <Emoji>
    //     0x799204: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c7e8] TypeArguments: <Emoji>
    //     0x799208: ldr             x16, [x16, #0x7e8]
    // 0x79920c: stp             xzr, x16, [SP, #-0x10]!
    // 0x799210: r0 = _GrowableList()
    //     0x799210: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x799214: add             SP, SP, #0x10
    // 0x799218: mov             x1, x0
    // 0x79921c: stur            x1, [fp, #-0x30]
    // 0x799220: r4 = 0
    //     0x799220: mov             x4, #0
    // 0x799224: ldur            x3, [fp, #-0x18]
    // 0x799228: ldur            x2, [fp, #-0x20]
    // 0x79922c: stur            x4, [fp, #-0x28]
    // 0x799230: CheckStackOverflow
    //     0x799230: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x799234: cmp             SP, x16
    //     0x799238: b.ls            #0x7993ac
    // 0x79923c: r0 = LoadClassIdInstr(r2)
    //     0x79923c: ldur            x0, [x2, #-1]
    //     0x799240: ubfx            x0, x0, #0xc, #0x14
    // 0x799244: SaveReg r2
    //     0x799244: str             x2, [SP, #-8]!
    // 0x799248: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x799248: mov             x17, #0xb8ea
    //     0x79924c: add             lr, x0, x17
    //     0x799250: ldr             lr, [x21, lr, lsl #3]
    //     0x799254: blr             lr
    // 0x799258: add             SP, SP, #8
    // 0x79925c: r1 = LoadInt32Instr(r0)
    //     0x79925c: sbfx            x1, x0, #1, #0x1f
    //     0x799260: tbz             w0, #0, #0x799268
    //     0x799264: ldur            x1, [x0, #7]
    // 0x799268: ldur            x2, [fp, #-0x28]
    // 0x79926c: cmp             x2, x1
    // 0x799270: b.ge            #0x799388
    // 0x799274: ldur            x3, [fp, #-0x20]
    // 0x799278: r0 = BoxInt64Instr(r2)
    //     0x799278: sbfiz           x0, x2, #1, #0x1f
    //     0x79927c: cmp             x2, x0, asr #1
    //     0x799280: b.eq            #0x79928c
    //     0x799284: bl              #0xd69bb8
    //     0x799288: stur            x2, [x0, #7]
    // 0x79928c: mov             x1, x0
    // 0x799290: stur            x1, [fp, #-0x38]
    // 0x799294: r0 = LoadClassIdInstr(r3)
    //     0x799294: ldur            x0, [x3, #-1]
    //     0x799298: ubfx            x0, x0, #0xc, #0x14
    // 0x79929c: stp             x1, x3, [SP, #-0x10]!
    // 0x7992a0: r0 = GDT[cid_x0 + -0xd83]()
    //     0x7992a0: sub             lr, x0, #0xd83
    //     0x7992a4: ldr             lr, [x21, lr, lsl #3]
    //     0x7992a8: blr             lr
    // 0x7992ac: add             SP, SP, #0x10
    // 0x7992b0: tbnz            w0, #4, #0x799374
    // 0x7992b4: ldur            x2, [fp, #-0x18]
    // 0x7992b8: ldur            x1, [fp, #-0x30]
    // 0x7992bc: r0 = LoadClassIdInstr(r2)
    //     0x7992bc: ldur            x0, [x2, #-1]
    //     0x7992c0: ubfx            x0, x0, #0xc, #0x14
    // 0x7992c4: ldur            x16, [fp, #-0x38]
    // 0x7992c8: stp             x16, x2, [SP, #-0x10]!
    // 0x7992cc: r0 = GDT[cid_x0 + -0xd83]()
    //     0x7992cc: sub             lr, x0, #0xd83
    //     0x7992d0: ldr             lr, [x21, lr, lsl #3]
    //     0x7992d4: blr             lr
    // 0x7992d8: add             SP, SP, #0x10
    // 0x7992dc: mov             x1, x0
    // 0x7992e0: ldur            x0, [fp, #-0x30]
    // 0x7992e4: stur            x1, [fp, #-0x40]
    // 0x7992e8: LoadField: r2 = r0->field_b
    //     0x7992e8: ldur            w2, [x0, #0xb]
    // 0x7992ec: DecompressPointer r2
    //     0x7992ec: add             x2, x2, HEAP, lsl #32
    // 0x7992f0: stur            x2, [fp, #-0x38]
    // 0x7992f4: LoadField: r3 = r0->field_f
    //     0x7992f4: ldur            w3, [x0, #0xf]
    // 0x7992f8: DecompressPointer r3
    //     0x7992f8: add             x3, x3, HEAP, lsl #32
    // 0x7992fc: LoadField: r4 = r3->field_b
    //     0x7992fc: ldur            w4, [x3, #0xb]
    // 0x799300: DecompressPointer r4
    //     0x799300: add             x4, x4, HEAP, lsl #32
    // 0x799304: cmp             w2, w4
    // 0x799308: b.ne            #0x799318
    // 0x79930c: SaveReg r0
    //     0x79930c: str             x0, [SP, #-8]!
    // 0x799310: r0 = _growToNextCapacity()
    //     0x799310: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x799314: add             SP, SP, #8
    // 0x799318: ldur            x2, [fp, #-0x30]
    // 0x79931c: ldur            x0, [fp, #-0x38]
    // 0x799320: r3 = LoadInt32Instr(r0)
    //     0x799320: sbfx            x3, x0, #1, #0x1f
    // 0x799324: add             x0, x3, #1
    // 0x799328: lsl             x1, x0, #1
    // 0x79932c: StoreField: r2->field_b = r1
    //     0x79932c: stur            w1, [x2, #0xb]
    // 0x799330: mov             x1, x3
    // 0x799334: cmp             x1, x0
    // 0x799338: b.hs            #0x7993b4
    // 0x79933c: LoadField: r1 = r2->field_f
    //     0x79933c: ldur            w1, [x2, #0xf]
    // 0x799340: DecompressPointer r1
    //     0x799340: add             x1, x1, HEAP, lsl #32
    // 0x799344: ldur            x0, [fp, #-0x40]
    // 0x799348: ArrayStore: r1[r3] = r0  ; List_4
    //     0x799348: add             x25, x1, x3, lsl #2
    //     0x79934c: add             x25, x25, #0xf
    //     0x799350: str             w0, [x25]
    //     0x799354: tbz             w0, #0, #0x799370
    //     0x799358: ldurb           w16, [x1, #-1]
    //     0x79935c: ldurb           w17, [x0, #-1]
    //     0x799360: and             x16, x17, x16, lsr #2
    //     0x799364: tst             x16, HEAP, lsr #32
    //     0x799368: b.eq            #0x799370
    //     0x79936c: bl              #0xd67e5c
    // 0x799370: b               #0x799378
    // 0x799374: ldur            x2, [fp, #-0x30]
    // 0x799378: ldur            x0, [fp, #-0x28]
    // 0x79937c: add             x4, x0, #1
    // 0x799380: mov             x1, x2
    // 0x799384: b               #0x799224
    // 0x799388: ldur            x2, [fp, #-0x30]
    // 0x79938c: ldur            x16, [fp, #-0x10]
    // 0x799390: stp             x2, x16, [SP, #-0x10]!
    // 0x799394: r0 = copyWith()
    //     0x799394: bl              #0x7993b8  ; [package:emoji_picker_flutter/src/category_emoji.dart] CategoryEmoji::copyWith
    // 0x799398: add             SP, SP, #0x10
    // 0x79939c: r0 = ReturnAsyncNotFuture()
    //     0x79939c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x7993a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7993a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7993a4: b               #0x799110
    // 0x7993a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7993a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7993ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7993ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7993b0: b               #0x79923c
    // 0x7993b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7993b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getRecentEmojis(/* No info */) async {
    // ** addr: 0x7996b0, size: 0x124
    // 0x7996b0: EnterFrame
    //     0x7996b0: stp             fp, lr, [SP, #-0x10]!
    //     0x7996b4: mov             fp, SP
    // 0x7996b8: AllocStack(0x10)
    //     0x7996b8: sub             SP, SP, #0x10
    // 0x7996bc: SetupParameters()
    //     0x7996bc: stur            NULL, [fp, #-8]
    // 0x7996c0: CheckStackOverflow
    //     0x7996c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7996c4: cmp             SP, x16
    //     0x7996c8: b.ls            #0x7997cc
    // 0x7996cc: InitAsync() -> Future<List<RecentEmoji>>
    //     0x7996cc: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c820] TypeArguments: <List<RecentEmoji>>
    //     0x7996d0: ldr             x0, [x0, #0x820]
    //     0x7996d4: bl              #0x4b92e4
    // 0x7996d8: r0 = getInstance()
    //     0x7996d8: bl              #0x799970  ; [package:shared_preferences/shared_preferences.dart] SharedPreferences::getInstance
    // 0x7996dc: mov             x1, x0
    // 0x7996e0: stur            x1, [fp, #-0x10]
    // 0x7996e4: r0 = Await()
    //     0x7996e4: bl              #0x4b8e6c  ; AwaitStub
    // 0x7996e8: SaveReg r0
    //     0x7996e8: str             x0, [SP, #-8]!
    // 0x7996ec: r0 = getString()
    //     0x7996ec: bl              #0x7997d4  ; [package:shared_preferences/shared_preferences.dart] SharedPreferences::getString
    // 0x7996f0: add             SP, SP, #8
    // 0x7996f4: cmp             w0, NULL
    // 0x7996f8: b.ne            #0x799714
    // 0x7996fc: r16 = <RecentEmoji>
    //     0x7996fc: add             x16, PP, #0x41, lsl #12  ; [pp+0x41080] TypeArguments: <RecentEmoji>
    //     0x799700: ldr             x16, [x16, #0x80]
    // 0x799704: stp             xzr, x16, [SP, #-0x10]!
    // 0x799708: r0 = _GrowableList()
    //     0x799708: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x79970c: add             SP, SP, #0x10
    // 0x799710: r0 = ReturnAsyncNotFuture()
    //     0x799710: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x799714: SaveReg r0
    //     0x799714: str             x0, [SP, #-8]!
    // 0x799718: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x799718: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x79971c: r0 = jsonDecode()
    //     0x79971c: bl              #0x55c4f8  ; [dart:convert] ::jsonDecode
    // 0x799720: add             SP, SP, #8
    // 0x799724: mov             x3, x0
    // 0x799728: r2 = Null
    //     0x799728: mov             x2, NULL
    // 0x79972c: r1 = Null
    //     0x79972c: mov             x1, NULL
    // 0x799730: stur            x3, [fp, #-0x10]
    // 0x799734: r4 = 59
    //     0x799734: mov             x4, #0x3b
    // 0x799738: branchIfSmi(r0, 0x799744)
    //     0x799738: tbz             w0, #0, #0x799744
    // 0x79973c: r4 = LoadClassIdInstr(r0)
    //     0x79973c: ldur            x4, [x0, #-1]
    //     0x799740: ubfx            x4, x4, #0xc, #0x14
    // 0x799744: sub             x4, x4, #0x59
    // 0x799748: cmp             x4, #2
    // 0x79974c: b.ls            #0x799760
    // 0x799750: r8 = List
    //     0x799750: ldr             x8, [PP, #0x2248]  ; [pp+0x2248] Type: List
    // 0x799754: r3 = Null
    //     0x799754: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c8c0] Null
    //     0x799758: ldr             x3, [x3, #0x8c0]
    // 0x79975c: r0 = List()
    //     0x79975c: bl              #0xd74840  ; IsType_List_Stub
    // 0x799760: ldur            x0, [fp, #-0x10]
    // 0x799764: r1 = LoadClassIdInstr(r0)
    //     0x799764: ldur            x1, [x0, #-1]
    //     0x799768: ubfx            x1, x1, #0xc, #0x14
    // 0x79976c: r16 = <RecentEmoji>
    //     0x79976c: add             x16, PP, #0x41, lsl #12  ; [pp+0x41080] TypeArguments: <RecentEmoji>
    //     0x799770: ldr             x16, [x16, #0x80]
    // 0x799774: stp             x0, x16, [SP, #-0x10]!
    // 0x799778: r16 = Closure: (dynamic) => RecentEmoji from Function 'fromJson': static.
    //     0x799778: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c8d0] Closure: (dynamic) => RecentEmoji from Function 'fromJson': static. (0x7fe6e1f99dc0)
    //     0x79977c: ldr             x16, [x16, #0x8d0]
    // 0x799780: SaveReg r16
    //     0x799780: str             x16, [SP, #-8]!
    // 0x799784: mov             x0, x1
    // 0x799788: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x799788: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x79978c: r0 = GDT[cid_x0 + 0xc934]()
    //     0x79978c: mov             x17, #0xc934
    //     0x799790: add             lr, x0, x17
    //     0x799794: ldr             lr, [x21, lr, lsl #3]
    //     0x799798: blr             lr
    // 0x79979c: add             SP, SP, #0x18
    // 0x7997a0: r1 = LoadClassIdInstr(r0)
    //     0x7997a0: ldur            x1, [x0, #-1]
    //     0x7997a4: ubfx            x1, x1, #0xc, #0x14
    // 0x7997a8: SaveReg r0
    //     0x7997a8: str             x0, [SP, #-8]!
    // 0x7997ac: mov             x0, x1
    // 0x7997b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7997b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7997b4: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0x7997b4: mov             x17, #0xc8a1
    //     0x7997b8: add             lr, x0, x17
    //     0x7997bc: ldr             lr, [x21, lr, lsl #3]
    //     0x7997c0: blr             lr
    // 0x7997c4: add             SP, SP, #8
    // 0x7997c8: r0 = ReturnAsync()
    //     0x7997c8: b               #0x501858  ; ReturnAsyncStub
    // 0x7997cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7997cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7997d0: b               #0x7996cc
  }
  _ addEmojiToRecentlyUsed(/* No info */) async {
    // ** addr: 0x79a7e8, size: 0x29c
    // 0x79a7e8: EnterFrame
    //     0x79a7e8: stp             fp, lr, [SP, #-0x10]!
    //     0x79a7ec: mov             fp, SP
    // 0x79a7f0: AllocStack(0x20)
    //     0x79a7f0: sub             SP, SP, #0x20
    // 0x79a7f4: SetupParameters(EmojiPickerInternalUtils this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0x79a7f4: stur            NULL, [fp, #-8]
    //     0x79a7f8: mov             x0, #0
    //     0x79a7fc: add             x1, fp, w0, sxtw #2
    //     0x79a800: ldr             x1, [x1, #0x18]
    //     0x79a804: stur            x1, [fp, #-0x18]
    //     0x79a808: add             x2, fp, w0, sxtw #2
    //     0x79a80c: ldr             x2, [x2, #0x10]
    //     0x79a810: stur            x2, [fp, #-0x10]
    // 0x79a814: CheckStackOverflow
    //     0x79a814: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79a818: cmp             SP, x16
    //     0x79a81c: b.ls            #0x79aa7c
    // 0x79a820: r1 = 1
    //     0x79a820: mov             x1, #1
    // 0x79a824: r0 = AllocateContext()
    //     0x79a824: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79a828: mov             x1, x0
    // 0x79a82c: ldur            x0, [fp, #-0x10]
    // 0x79a830: stur            x1, [fp, #-0x20]
    // 0x79a834: StoreField: r1->field_f = r0
    //     0x79a834: stur            w0, [x1, #0xf]
    // 0x79a838: InitAsync() -> Future<List<RecentEmoji>>
    //     0x79a838: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c820] TypeArguments: <List<RecentEmoji>>
    //     0x79a83c: ldr             x0, [x0, #0x820]
    //     0x79a840: bl              #0x4b92e4
    // 0x79a844: ldur            x2, [fp, #-0x20]
    // 0x79a848: LoadField: r0 = r2->field_f
    //     0x79a848: ldur            w0, [x2, #0xf]
    // 0x79a84c: DecompressPointer r0
    //     0x79a84c: add             x0, x0, HEAP, lsl #32
    // 0x79a850: LoadField: r1 = r0->field_f
    //     0x79a850: ldur            w1, [x0, #0xf]
    // 0x79a854: DecompressPointer r1
    //     0x79a854: add             x1, x1, HEAP, lsl #32
    // 0x79a858: tbnz            w1, #4, #0x79a88c
    // 0x79a85c: ldur            x16, [fp, #-0x18]
    // 0x79a860: stp             x0, x16, [SP, #-0x10]!
    // 0x79a864: r0 = removeSkinTone()
    //     0x79a864: bl              #0x79ab80  ; [package:emoji_picker_flutter/src/emoji_picker_internal_utils.dart] EmojiPickerInternalUtils::removeSkinTone
    // 0x79a868: add             SP, SP, #0x10
    // 0x79a86c: ldur            x2, [fp, #-0x20]
    // 0x79a870: StoreField: r2->field_f = r0
    //     0x79a870: stur            w0, [x2, #0xf]
    //     0x79a874: ldurb           w16, [x2, #-1]
    //     0x79a878: ldurb           w17, [x0, #-1]
    //     0x79a87c: and             x16, x17, x16, lsr #2
    //     0x79a880: tst             x16, HEAP, lsr #32
    //     0x79a884: b.eq            #0x79a88c
    //     0x79a888: bl              #0xd6828c
    // 0x79a88c: ldur            x16, [fp, #-0x18]
    // 0x79a890: SaveReg r16
    //     0x79a890: str             x16, [SP, #-8]!
    // 0x79a894: r0 = getRecentEmojis()
    //     0x79a894: bl              #0x7996b0  ; [package:emoji_picker_flutter/src/emoji_picker_internal_utils.dart] EmojiPickerInternalUtils::getRecentEmojis
    // 0x79a898: add             SP, SP, #8
    // 0x79a89c: mov             x1, x0
    // 0x79a8a0: stur            x1, [fp, #-0x10]
    // 0x79a8a4: r0 = Await()
    //     0x79a8a4: bl              #0x4b8e6c  ; AwaitStub
    // 0x79a8a8: ldur            x2, [fp, #-0x20]
    // 0x79a8ac: r1 = Function '<anonymous closure>':.
    //     0x79a8ac: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c828] AnonymousClosure: (0x79ac60), in [package:emoji_picker_flutter/src/emoji_picker_internal_utils.dart] EmojiPickerInternalUtils::addEmojiToRecentlyUsed (0x79a7e8)
    //     0x79a8b0: ldr             x1, [x1, #0x828]
    // 0x79a8b4: stur            x0, [fp, #-0x10]
    // 0x79a8b8: r0 = AllocateClosure()
    //     0x79a8b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79a8bc: ldur            x1, [fp, #-0x10]
    // 0x79a8c0: r2 = LoadClassIdInstr(r1)
    //     0x79a8c0: ldur            x2, [x1, #-1]
    //     0x79a8c4: ubfx            x2, x2, #0xc, #0x14
    // 0x79a8c8: stp             x0, x1, [SP, #-0x10]!
    // 0x79a8cc: mov             x0, x2
    // 0x79a8d0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x79a8d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x79a8d4: r0 = GDT[cid_x0 + 0x10674]()
    //     0x79a8d4: mov             x17, #0x674
    //     0x79a8d8: movk            x17, #1, lsl #16
    //     0x79a8dc: add             lr, x0, x17
    //     0x79a8e0: ldr             lr, [x21, lr, lsl #3]
    //     0x79a8e4: blr             lr
    // 0x79a8e8: add             SP, SP, #0x10
    // 0x79a8ec: cmn             x0, #1
    // 0x79a8f0: b.eq            #0x79a920
    // 0x79a8f4: ldur            x1, [fp, #-0x10]
    // 0x79a8f8: r2 = LoadClassIdInstr(r1)
    //     0x79a8f8: ldur            x2, [x1, #-1]
    //     0x79a8fc: ubfx            x2, x2, #0xc, #0x14
    // 0x79a900: stp             x0, x1, [SP, #-0x10]!
    // 0x79a904: mov             x0, x2
    // 0x79a908: r0 = GDT[cid_x0 + 0x102b7]()
    //     0x79a908: mov             x17, #0x2b7
    //     0x79a90c: movk            x17, #1, lsl #16
    //     0x79a910: add             lr, x0, x17
    //     0x79a914: ldr             lr, [x21, lr, lsl #3]
    //     0x79a918: blr             lr
    // 0x79a91c: add             SP, SP, #0x10
    // 0x79a920: ldur            x1, [fp, #-0x20]
    // 0x79a924: ldur            x0, [fp, #-0x10]
    // 0x79a928: LoadField: r2 = r1->field_f
    //     0x79a928: ldur            w2, [x1, #0xf]
    // 0x79a92c: DecompressPointer r2
    //     0x79a92c: add             x2, x2, HEAP, lsl #32
    // 0x79a930: stur            x2, [fp, #-0x18]
    // 0x79a934: r0 = RecentEmoji()
    //     0x79a934: bl              #0x799f08  ; AllocateRecentEmojiStub -> RecentEmoji (size=0x14)
    // 0x79a938: mov             x1, x0
    // 0x79a93c: ldur            x0, [fp, #-0x18]
    // 0x79a940: StoreField: r1->field_7 = r0
    //     0x79a940: stur            w0, [x1, #7]
    // 0x79a944: r0 = 1
    //     0x79a944: mov             x0, #1
    // 0x79a948: StoreField: r1->field_b = r0
    //     0x79a948: stur            x0, [x1, #0xb]
    // 0x79a94c: ldur            x2, [fp, #-0x10]
    // 0x79a950: r0 = LoadClassIdInstr(r2)
    //     0x79a950: ldur            x0, [x2, #-1]
    //     0x79a954: ubfx            x0, x0, #0xc, #0x14
    // 0x79a958: stp             xzr, x2, [SP, #-0x10]!
    // 0x79a95c: SaveReg r1
    //     0x79a95c: str             x1, [SP, #-8]!
    // 0x79a960: r0 = GDT[cid_x0 + 0x1044a]()
    //     0x79a960: mov             x17, #0x44a
    //     0x79a964: movk            x17, #1, lsl #16
    //     0x79a968: add             lr, x0, x17
    //     0x79a96c: ldr             lr, [x21, lr, lsl #3]
    //     0x79a970: blr             lr
    // 0x79a974: add             SP, SP, #0x18
    // 0x79a978: ldur            x1, [fp, #-0x10]
    // 0x79a97c: r0 = LoadClassIdInstr(r1)
    //     0x79a97c: ldur            x0, [x1, #-1]
    //     0x79a980: ubfx            x0, x0, #0xc, #0x14
    // 0x79a984: SaveReg r1
    //     0x79a984: str             x1, [SP, #-8]!
    // 0x79a988: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x79a988: mov             x17, #0xb8ea
    //     0x79a98c: add             lr, x0, x17
    //     0x79a990: ldr             lr, [x21, lr, lsl #3]
    //     0x79a994: blr             lr
    // 0x79a998: add             SP, SP, #8
    // 0x79a99c: r1 = LoadInt32Instr(r0)
    //     0x79a99c: sbfx            x1, x0, #1, #0x1f
    //     0x79a9a0: tbz             w0, #0, #0x79a9a8
    //     0x79a9a4: ldur            x1, [x0, #7]
    // 0x79a9a8: cmp             x1, #0x20
    // 0x79a9ac: b.ge            #0x79a9b8
    // 0x79a9b0: mov             x1, x0
    // 0x79a9b4: b               #0x79aa04
    // 0x79a9b8: cmp             x1, #0x20
    // 0x79a9bc: b.le            #0x79a9c8
    // 0x79a9c0: r1 = 64
    //     0x79a9c0: mov             x1, #0x40
    // 0x79a9c4: b               #0x79aa04
    // 0x79a9c8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x79a9c8: mov             x1, #0x76
    //     0x79a9cc: tbz             w0, #0, #0x79a9dc
    //     0x79a9d0: ldur            x1, [x0, #-1]
    //     0x79a9d4: ubfx            x1, x1, #0xc, #0x14
    //     0x79a9d8: lsl             x1, x1, #1
    // 0x79a9dc: cmp             w1, #0x7a
    // 0x79a9e0: b.ne            #0x79aa00
    // 0x79a9e4: LoadField: d0 = r0->field_7
    //     0x79a9e4: ldur            d0, [x0, #7]
    // 0x79a9e8: fcmp            d0, d0
    // 0x79a9ec: b.vc            #0x79a9f8
    // 0x79a9f0: mov             x1, x0
    // 0x79a9f4: b               #0x79aa04
    // 0x79a9f8: r1 = 64
    //     0x79a9f8: mov             x1, #0x40
    // 0x79a9fc: b               #0x79aa04
    // 0x79aa00: r1 = 64
    //     0x79aa00: mov             x1, #0x40
    // 0x79aa04: ldur            x0, [fp, #-0x10]
    // 0x79aa08: r2 = LoadClassIdInstr(r0)
    //     0x79aa08: ldur            x2, [x0, #-1]
    //     0x79aa0c: ubfx            x2, x2, #0xc, #0x14
    // 0x79aa10: stp             xzr, x0, [SP, #-0x10]!
    // 0x79aa14: SaveReg r1
    //     0x79aa14: str             x1, [SP, #-8]!
    // 0x79aa18: mov             x0, x2
    // 0x79aa1c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x79aa1c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x79aa20: r0 = GDT[cid_x0 + 0x10217]()
    //     0x79aa20: mov             x17, #0x217
    //     0x79aa24: movk            x17, #1, lsl #16
    //     0x79aa28: add             lr, x0, x17
    //     0x79aa2c: ldr             lr, [x21, lr, lsl #3]
    //     0x79aa30: blr             lr
    // 0x79aa34: add             SP, SP, #0x18
    // 0x79aa38: stur            x0, [fp, #-0x10]
    // 0x79aa3c: r0 = getInstance()
    //     0x79aa3c: bl              #0x799970  ; [package:shared_preferences/shared_preferences.dart] SharedPreferences::getInstance
    // 0x79aa40: mov             x1, x0
    // 0x79aa44: stur            x1, [fp, #-0x18]
    // 0x79aa48: r0 = Await()
    //     0x79aa48: bl              #0x4b8e6c  ; AwaitStub
    // 0x79aa4c: stur            x0, [fp, #-0x18]
    // 0x79aa50: ldur            x16, [fp, #-0x10]
    // 0x79aa54: SaveReg r16
    //     0x79aa54: str             x16, [SP, #-8]!
    // 0x79aa58: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x79aa58: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x79aa5c: r0 = jsonEncode()
    //     0x79aa5c: bl              #0x55c39c  ; [dart:convert] ::jsonEncode
    // 0x79aa60: add             SP, SP, #8
    // 0x79aa64: ldur            x16, [fp, #-0x18]
    // 0x79aa68: stp             x0, x16, [SP, #-0x10]!
    // 0x79aa6c: r0 = _setValue()
    //     0x79aa6c: bl              #0x79aa84  ; [package:shared_preferences/shared_preferences.dart] SharedPreferences::_setValue
    // 0x79aa70: add             SP, SP, #0x10
    // 0x79aa74: ldur            x0, [fp, #-0x10]
    // 0x79aa78: r0 = ReturnAsync()
    //     0x79aa78: b               #0x501858  ; ReturnAsyncStub
    // 0x79aa7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79aa7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79aa80: b               #0x79a820
  }
  _ removeSkinTone(/* No info */) {
    // ** addr: 0x79ab80, size: 0x90
    // 0x79ab80: EnterFrame
    //     0x79ab80: stp             fp, lr, [SP, #-0x10]!
    //     0x79ab84: mov             fp, SP
    // 0x79ab88: AllocStack(0x8)
    //     0x79ab88: sub             SP, SP, #8
    // 0x79ab8c: CheckStackOverflow
    //     0x79ab8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79ab90: cmp             SP, x16
    //     0x79ab94: b.ls            #0x79ac08
    // 0x79ab98: ldr             x0, [fp, #0x10]
    // 0x79ab9c: LoadField: r1 = r0->field_7
    //     0x79ab9c: ldur            w1, [x0, #7]
    // 0x79aba0: DecompressPointer r1
    //     0x79aba0: add             x1, x1, HEAP, lsl #32
    // 0x79aba4: stur            x1, [fp, #-8]
    // 0x79aba8: r16 = const [🏻, 🏼, 🏽, 🏾, 🏿]
    //     0x79aba8: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c870] List<String>(5)
    //     0x79abac: ldr             x16, [x16, #0x870]
    // 0x79abb0: r30 = "|"
    //     0x79abb0: ldr             lr, [PP, #0x4878]  ; [pp+0x4878] "|"
    // 0x79abb4: stp             lr, x16, [SP, #-0x10]!
    // 0x79abb8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x79abb8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x79abbc: r0 = join()
    //     0x79abbc: bl              #0x6fe3d4  ; [dart:collection] _ListBase&Object&ListMixin::join
    // 0x79abc0: add             SP, SP, #0x10
    // 0x79abc4: stp             x0, NULL, [SP, #-0x10]!
    // 0x79abc8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x79abc8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x79abcc: r0 = RegExp()
    //     0x79abcc: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0x79abd0: add             SP, SP, #0x10
    // 0x79abd4: ldur            x16, [fp, #-8]
    // 0x79abd8: stp             x0, x16, [SP, #-0x10]!
    // 0x79abdc: r16 = ""
    //     0x79abdc: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x79abe0: SaveReg r16
    //     0x79abe0: str             x16, [SP, #-8]!
    // 0x79abe4: r0 = replaceFirst()
    //     0x79abe4: bl              #0x4fede8  ; [dart:core] _StringBase::replaceFirst
    // 0x79abe8: add             SP, SP, #0x18
    // 0x79abec: ldr             x16, [fp, #0x10]
    // 0x79abf0: stp             x0, x16, [SP, #-0x10]!
    // 0x79abf4: r0 = copyWith()
    //     0x79abf4: bl              #0x79ac10  ; [package:emoji_picker_flutter/src/emoji.dart] Emoji::copyWith
    // 0x79abf8: add             SP, SP, #0x10
    // 0x79abfc: LeaveFrame
    //     0x79abfc: mov             SP, fp
    //     0x79ac00: ldp             fp, lr, [SP], #0x10
    // 0x79ac04: ret
    //     0x79ac04: ret             
    // 0x79ac08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79ac08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79ac0c: b               #0x79ab98
  }
  [closure] bool <anonymous closure>(dynamic, RecentEmoji) {
    // ** addr: 0x79ac60, size: 0x78
    // 0x79ac60: EnterFrame
    //     0x79ac60: stp             fp, lr, [SP, #-0x10]!
    //     0x79ac64: mov             fp, SP
    // 0x79ac68: ldr             x0, [fp, #0x18]
    // 0x79ac6c: LoadField: r1 = r0->field_17
    //     0x79ac6c: ldur            w1, [x0, #0x17]
    // 0x79ac70: DecompressPointer r1
    //     0x79ac70: add             x1, x1, HEAP, lsl #32
    // 0x79ac74: CheckStackOverflow
    //     0x79ac74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79ac78: cmp             SP, x16
    //     0x79ac7c: b.ls            #0x79acd0
    // 0x79ac80: ldr             x0, [fp, #0x10]
    // 0x79ac84: LoadField: r2 = r0->field_7
    //     0x79ac84: ldur            w2, [x0, #7]
    // 0x79ac88: DecompressPointer r2
    //     0x79ac88: add             x2, x2, HEAP, lsl #32
    // 0x79ac8c: LoadField: r0 = r2->field_7
    //     0x79ac8c: ldur            w0, [x2, #7]
    // 0x79ac90: DecompressPointer r0
    //     0x79ac90: add             x0, x0, HEAP, lsl #32
    // 0x79ac94: LoadField: r2 = r1->field_f
    //     0x79ac94: ldur            w2, [x1, #0xf]
    // 0x79ac98: DecompressPointer r2
    //     0x79ac98: add             x2, x2, HEAP, lsl #32
    // 0x79ac9c: LoadField: r1 = r2->field_7
    //     0x79ac9c: ldur            w1, [x2, #7]
    // 0x79aca0: DecompressPointer r1
    //     0x79aca0: add             x1, x1, HEAP, lsl #32
    // 0x79aca4: r2 = LoadClassIdInstr(r0)
    //     0x79aca4: ldur            x2, [x0, #-1]
    //     0x79aca8: ubfx            x2, x2, #0xc, #0x14
    // 0x79acac: stp             x1, x0, [SP, #-0x10]!
    // 0x79acb0: mov             x0, x2
    // 0x79acb4: mov             lr, x0
    // 0x79acb8: ldr             lr, [x21, lr, lsl #3]
    // 0x79acbc: blr             lr
    // 0x79acc0: add             SP, SP, #0x10
    // 0x79acc4: LeaveFrame
    //     0x79acc4: mov             SP, fp
    //     0x79acc8: ldp             fp, lr, [SP], #0x10
    // 0x79accc: ret
    //     0x79accc: ret             
    // 0x79acd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79acd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79acd4: b               #0x79ac80
  }
}

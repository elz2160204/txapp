// lib: , url: package:emoji_picker_flutter/src/emoji_container.dart

// class id: 1048912, size: 0x8
class :: {
}

// class id: 3883, size: 0x1c, field offset: 0xc
//   const constructor, 
class EmojiContainer extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1c49c, size: 0x7c
    // 0xb1c49c: EnterFrame
    //     0xb1c49c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c4a0: mov             fp, SP
    // 0xb1c4a4: AllocStack(0x10)
    //     0xb1c4a4: sub             SP, SP, #0x10
    // 0xb1c4a8: ldr             x0, [fp, #0x18]
    // 0xb1c4ac: LoadField: r1 = r0->field_b
    //     0xb1c4ac: ldur            w1, [x0, #0xb]
    // 0xb1c4b0: DecompressPointer r1
    //     0xb1c4b0: add             x1, x1, HEAP, lsl #32
    // 0xb1c4b4: stur            x1, [fp, #-0x10]
    // 0xb1c4b8: LoadField: r2 = r0->field_17
    //     0xb1c4b8: ldur            w2, [x0, #0x17]
    // 0xb1c4bc: DecompressPointer r2
    //     0xb1c4bc: add             x2, x2, HEAP, lsl #32
    // 0xb1c4c0: stur            x2, [fp, #-8]
    // 0xb1c4c4: r0 = Material()
    //     0xb1c4c4: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0xb1c4c8: r1 = Instance_MaterialType
    //     0xb1c4c8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe6f8] Obj!MaterialType@b65531
    //     0xb1c4cc: ldr             x1, [x1, #0x6f8]
    // 0xb1c4d0: StoreField: r0->field_f = r1
    //     0xb1c4d0: stur            w1, [x0, #0xf]
    // 0xb1c4d4: d0 = 0.000000
    //     0xb1c4d4: eor             v0.16b, v0.16b, v0.16b
    // 0xb1c4d8: StoreField: r0->field_13 = d0
    //     0xb1c4d8: stur            d0, [x0, #0x13]
    // 0xb1c4dc: ldur            x1, [fp, #-0x10]
    // 0xb1c4e0: StoreField: r0->field_1b = r1
    //     0xb1c4e0: stur            w1, [x0, #0x1b]
    // 0xb1c4e4: r1 = true
    //     0xb1c4e4: add             x1, NULL, #0x20  ; true
    // 0xb1c4e8: StoreField: r0->field_2f = r1
    //     0xb1c4e8: stur            w1, [x0, #0x2f]
    // 0xb1c4ec: r1 = Instance_Clip
    //     0xb1c4ec: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0xb1c4f0: ldr             x1, [x1, #0xb38]
    // 0xb1c4f4: StoreField: r0->field_33 = r1
    //     0xb1c4f4: stur            w1, [x0, #0x33]
    // 0xb1c4f8: r1 = Instance_Duration
    //     0xb1c4f8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb1c4fc: ldr             x1, [x1, #0x9e0]
    // 0xb1c500: StoreField: r0->field_37 = r1
    //     0xb1c500: stur            w1, [x0, #0x37]
    // 0xb1c504: ldur            x1, [fp, #-8]
    // 0xb1c508: StoreField: r0->field_b = r1
    //     0xb1c508: stur            w1, [x0, #0xb]
    // 0xb1c50c: LeaveFrame
    //     0xb1c50c: mov             SP, fp
    //     0xb1c510: ldp             fp, lr, [SP], #0x10
    // 0xb1c514: ret
    //     0xb1c514: ret             
  }
}

// lib: , url: package:emoji_picker_flutter/src/recent_emoji.dart

// class id: 1048920, size: 0x8
class :: {
}

// class id: 4515, size: 0x14, field offset: 0x8
class RecentEmoji extends Object {

  Map<String, dynamic> toJson(RecentEmoji) {
    // ** addr: 0x79a114, size: 0xa4
    // 0x79a114: EnterFrame
    //     0x79a114: stp             fp, lr, [SP, #-0x10]!
    //     0x79a118: mov             fp, SP
    // 0x79a11c: CheckStackOverflow
    //     0x79a11c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79a120: cmp             SP, x16
    //     0x79a124: b.ls            #0x79a198
    // 0x79a128: r1 = Null
    //     0x79a128: mov             x1, NULL
    // 0x79a12c: r2 = 8
    //     0x79a12c: mov             x2, #8
    // 0x79a130: r0 = AllocateArray()
    //     0x79a130: bl              #0xd6987c  ; AllocateArrayStub
    // 0x79a134: mov             x2, x0
    // 0x79a138: r17 = "emoji"
    //     0x79a138: add             x17, PP, #0x32, lsl #12  ; [pp+0x326d0] "emoji"
    //     0x79a13c: ldr             x17, [x17, #0x6d0]
    // 0x79a140: StoreField: r2->field_f = r17
    //     0x79a140: stur            w17, [x2, #0xf]
    // 0x79a144: ldr             x0, [fp, #0x10]
    // 0x79a148: LoadField: r1 = r0->field_7
    //     0x79a148: ldur            w1, [x0, #7]
    // 0x79a14c: DecompressPointer r1
    //     0x79a14c: add             x1, x1, HEAP, lsl #32
    // 0x79a150: StoreField: r2->field_13 = r1
    //     0x79a150: stur            w1, [x2, #0x13]
    // 0x79a154: r17 = "counter"
    //     0x79a154: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2c130] "counter"
    //     0x79a158: ldr             x17, [x17, #0x130]
    // 0x79a15c: StoreField: r2->field_17 = r17
    //     0x79a15c: stur            w17, [x2, #0x17]
    // 0x79a160: LoadField: r3 = r0->field_b
    //     0x79a160: ldur            x3, [x0, #0xb]
    // 0x79a164: r0 = BoxInt64Instr(r3)
    //     0x79a164: sbfiz           x0, x3, #1, #0x1f
    //     0x79a168: cmp             x3, x0, asr #1
    //     0x79a16c: b.eq            #0x79a178
    //     0x79a170: bl              #0xd69bb8
    //     0x79a174: stur            x3, [x0, #7]
    // 0x79a178: StoreField: r2->field_1b = r0
    //     0x79a178: stur            w0, [x2, #0x1b]
    // 0x79a17c: r16 = <String, dynamic>
    //     0x79a17c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x79a180: stp             x2, x16, [SP, #-0x10]!
    // 0x79a184: r0 = Map._fromLiteral()
    //     0x79a184: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x79a188: add             SP, SP, #0x10
    // 0x79a18c: LeaveFrame
    //     0x79a18c: mov             SP, fp
    //     0x79a190: ldp             fp, lr, [SP], #0x10
    // 0x79a194: ret
    //     0x79a194: ret             
    // 0x79a198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79a198: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79a19c: b               #0x79a128
  }
  [closure] static RecentEmoji fromJson(dynamic, dynamic) {
    // ** addr: 0x799dc0, size: 0x38
    // 0x799dc0: EnterFrame
    //     0x799dc0: stp             fp, lr, [SP, #-0x10]!
    //     0x799dc4: mov             fp, SP
    // 0x799dc8: CheckStackOverflow
    //     0x799dc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x799dcc: cmp             SP, x16
    //     0x799dd0: b.ls            #0x799df0
    // 0x799dd4: ldr             x16, [fp, #0x10]
    // 0x799dd8: SaveReg r16
    //     0x799dd8: str             x16, [SP, #-8]!
    // 0x799ddc: r0 = fromJson()
    //     0x799ddc: bl              #0x799df8  ; [package:emoji_picker_flutter/src/recent_emoji.dart] RecentEmoji::fromJson
    // 0x799de0: add             SP, SP, #8
    // 0x799de4: LeaveFrame
    //     0x799de4: mov             SP, fp
    //     0x799de8: ldp             fp, lr, [SP], #0x10
    // 0x799dec: ret
    //     0x799dec: ret             
    // 0x799df0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x799df0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x799df4: b               #0x799dd4
  }
  static _ fromJson(/* No info */) {
    // ** addr: 0x799df8, size: 0x110
    // 0x799df8: EnterFrame
    //     0x799df8: stp             fp, lr, [SP, #-0x10]!
    //     0x799dfc: mov             fp, SP
    // 0x799e00: AllocStack(0x10)
    //     0x799e00: sub             SP, SP, #0x10
    // 0x799e04: CheckStackOverflow
    //     0x799e04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x799e08: cmp             SP, x16
    //     0x799e0c: b.ls            #0x799f00
    // 0x799e10: ldr             x16, [fp, #0x10]
    // 0x799e14: r30 = "emoji"
    //     0x799e14: add             lr, PP, #0x32, lsl #12  ; [pp+0x326d0] "emoji"
    //     0x799e18: ldr             lr, [lr, #0x6d0]
    // 0x799e1c: stp             lr, x16, [SP, #-0x10]!
    // 0x799e20: r4 = 0
    //     0x799e20: mov             x4, #0
    // 0x799e24: ldr             x0, [SP, #8]
    // 0x799e28: r16 = UnlinkedCall_0x4aeefc
    //     0x799e28: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c8d8] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x799e2c: add             x16, x16, #0x8d8
    // 0x799e30: ldp             x5, lr, [x16]
    // 0x799e34: blr             lr
    // 0x799e38: add             SP, SP, #0x10
    // 0x799e3c: mov             x3, x0
    // 0x799e40: r2 = Null
    //     0x799e40: mov             x2, NULL
    // 0x799e44: r1 = Null
    //     0x799e44: mov             x1, NULL
    // 0x799e48: stur            x3, [fp, #-8]
    // 0x799e4c: r8 = Map<String, dynamic>
    //     0x799e4c: ldr             x8, [PP, #0x3da0]  ; [pp+0x3da0] Type: Map<String, dynamic>
    // 0x799e50: r3 = Null
    //     0x799e50: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c8e8] Null
    //     0x799e54: ldr             x3, [x3, #0x8e8]
    // 0x799e58: r0 = Map<String, dynamic>()
    //     0x799e58: bl              #0x4e3b2c  ; IsType_Map<String, dynamic>_Stub
    // 0x799e5c: ldur            x16, [fp, #-8]
    // 0x799e60: SaveReg r16
    //     0x799e60: str             x16, [SP, #-8]!
    // 0x799e64: r0 = fromJson()
    //     0x799e64: bl              #0x799f14  ; [package:emoji_picker_flutter/src/emoji.dart] Emoji::fromJson
    // 0x799e68: add             SP, SP, #8
    // 0x799e6c: stur            x0, [fp, #-8]
    // 0x799e70: ldr             x16, [fp, #0x10]
    // 0x799e74: r30 = "counter"
    //     0x799e74: add             lr, PP, #0x2c, lsl #12  ; [pp+0x2c130] "counter"
    //     0x799e78: ldr             lr, [lr, #0x130]
    // 0x799e7c: stp             lr, x16, [SP, #-0x10]!
    // 0x799e80: r4 = 0
    //     0x799e80: mov             x4, #0
    // 0x799e84: ldr             x0, [SP, #8]
    // 0x799e88: r16 = UnlinkedCall_0x4aeefc
    //     0x799e88: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c8f8] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x799e8c: add             x16, x16, #0x8f8
    // 0x799e90: ldp             x5, lr, [x16]
    // 0x799e94: blr             lr
    // 0x799e98: add             SP, SP, #0x10
    // 0x799e9c: mov             x3, x0
    // 0x799ea0: r2 = Null
    //     0x799ea0: mov             x2, NULL
    // 0x799ea4: r1 = Null
    //     0x799ea4: mov             x1, NULL
    // 0x799ea8: stur            x3, [fp, #-0x10]
    // 0x799eac: branchIfSmi(r0, 0x799ed4)
    //     0x799eac: tbz             w0, #0, #0x799ed4
    // 0x799eb0: r4 = LoadClassIdInstr(r0)
    //     0x799eb0: ldur            x4, [x0, #-1]
    //     0x799eb4: ubfx            x4, x4, #0xc, #0x14
    // 0x799eb8: sub             x4, x4, #0x3b
    // 0x799ebc: cmp             x4, #1
    // 0x799ec0: b.ls            #0x799ed4
    // 0x799ec4: r8 = int
    //     0x799ec4: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0x799ec8: r3 = Null
    //     0x799ec8: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c908] Null
    //     0x799ecc: ldr             x3, [x3, #0x908]
    // 0x799ed0: r0 = int()
    //     0x799ed0: bl              #0xd73714  ; IsType_int_Stub
    // 0x799ed4: r0 = RecentEmoji()
    //     0x799ed4: bl              #0x799f08  ; AllocateRecentEmojiStub -> RecentEmoji (size=0x14)
    // 0x799ed8: ldur            x1, [fp, #-8]
    // 0x799edc: StoreField: r0->field_7 = r1
    //     0x799edc: stur            w1, [x0, #7]
    // 0x799ee0: ldur            x1, [fp, #-0x10]
    // 0x799ee4: r2 = LoadInt32Instr(r1)
    //     0x799ee4: sbfx            x2, x1, #1, #0x1f
    //     0x799ee8: tbz             w1, #0, #0x799ef0
    //     0x799eec: ldur            x2, [x1, #7]
    // 0x799ef0: StoreField: r0->field_b = r2
    //     0x799ef0: stur            x2, [x0, #0xb]
    // 0x799ef4: LeaveFrame
    //     0x799ef4: mov             SP, fp
    //     0x799ef8: ldp             fp, lr, [SP], #0x10
    // 0x799efc: ret
    //     0x799efc: ret             
    // 0x799f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x799f00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x799f04: b               #0x799e10
  }
}

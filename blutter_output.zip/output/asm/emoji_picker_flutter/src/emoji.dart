// lib: , url: package:emoji_picker_flutter/src/emoji.dart

// class id: 1048910, size: 0x8
class :: {
}

// class id: 4519, size: 0x14, field offset: 0x8
//   const constructor, 
class Emoji extends Object {

  _TwoByteString field_8;
  _OneByteString field_c;
  bool field_10;

  Map<String, dynamic> toJson(Emoji) {
    // ** addr: 0x79955c, size: 0xa4
    // 0x79955c: EnterFrame
    //     0x79955c: stp             fp, lr, [SP, #-0x10]!
    //     0x799560: mov             fp, SP
    // 0x799564: CheckStackOverflow
    //     0x799564: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x799568: cmp             SP, x16
    //     0x79956c: b.ls            #0x7995e0
    // 0x799570: r1 = Null
    //     0x799570: mov             x1, NULL
    // 0x799574: r2 = 12
    //     0x799574: mov             x2, #0xc
    // 0x799578: r0 = AllocateArray()
    //     0x799578: bl              #0xd6987c  ; AllocateArrayStub
    // 0x79957c: r17 = "emoji"
    //     0x79957c: add             x17, PP, #0x32, lsl #12  ; [pp+0x326d0] "emoji"
    //     0x799580: ldr             x17, [x17, #0x6d0]
    // 0x799584: StoreField: r0->field_f = r17
    //     0x799584: stur            w17, [x0, #0xf]
    // 0x799588: ldr             x1, [fp, #0x10]
    // 0x79958c: LoadField: r2 = r1->field_7
    //     0x79958c: ldur            w2, [x1, #7]
    // 0x799590: DecompressPointer r2
    //     0x799590: add             x2, x2, HEAP, lsl #32
    // 0x799594: StoreField: r0->field_13 = r2
    //     0x799594: stur            w2, [x0, #0x13]
    // 0x799598: r17 = "name"
    //     0x799598: ldr             x17, [PP, #0x510]  ; [pp+0x510] "name"
    // 0x79959c: StoreField: r0->field_17 = r17
    //     0x79959c: stur            w17, [x0, #0x17]
    // 0x7995a0: LoadField: r2 = r1->field_b
    //     0x7995a0: ldur            w2, [x1, #0xb]
    // 0x7995a4: DecompressPointer r2
    //     0x7995a4: add             x2, x2, HEAP, lsl #32
    // 0x7995a8: StoreField: r0->field_1b = r2
    //     0x7995a8: stur            w2, [x0, #0x1b]
    // 0x7995ac: r17 = "hasSkinTone"
    //     0x7995ac: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c938] "hasSkinTone"
    //     0x7995b0: ldr             x17, [x17, #0x938]
    // 0x7995b4: StoreField: r0->field_1f = r17
    //     0x7995b4: stur            w17, [x0, #0x1f]
    // 0x7995b8: LoadField: r2 = r1->field_f
    //     0x7995b8: ldur            w2, [x1, #0xf]
    // 0x7995bc: DecompressPointer r2
    //     0x7995bc: add             x2, x2, HEAP, lsl #32
    // 0x7995c0: StoreField: r0->field_23 = r2
    //     0x7995c0: stur            w2, [x0, #0x23]
    // 0x7995c4: r16 = <String, dynamic>
    //     0x7995c4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x7995c8: stp             x0, x16, [SP, #-0x10]!
    // 0x7995cc: r0 = Map._fromLiteral()
    //     0x7995cc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x7995d0: add             SP, SP, #0x10
    // 0x7995d4: LeaveFrame
    //     0x7995d4: mov             SP, fp
    //     0x7995d8: ldp             fp, lr, [SP], #0x10
    // 0x7995dc: ret
    //     0x7995dc: ret             
    // 0x7995e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7995e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7995e4: b               #0x799570
  }
  static _ fromJson(/* No info */) {
    // ** addr: 0x799f14, size: 0x1b8
    // 0x799f14: EnterFrame
    //     0x799f14: stp             fp, lr, [SP, #-0x10]!
    //     0x799f18: mov             fp, SP
    // 0x799f1c: AllocStack(0x18)
    //     0x799f1c: sub             SP, SP, #0x18
    // 0x799f20: CheckStackOverflow
    //     0x799f20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x799f24: cmp             SP, x16
    //     0x799f28: b.ls            #0x79a0c4
    // 0x799f2c: ldr             x1, [fp, #0x10]
    // 0x799f30: r0 = LoadClassIdInstr(r1)
    //     0x799f30: ldur            x0, [x1, #-1]
    //     0x799f34: ubfx            x0, x0, #0xc, #0x14
    // 0x799f38: r16 = "emoji"
    //     0x799f38: add             x16, PP, #0x32, lsl #12  ; [pp+0x326d0] "emoji"
    //     0x799f3c: ldr             x16, [x16, #0x6d0]
    // 0x799f40: stp             x16, x1, [SP, #-0x10]!
    // 0x799f44: r0 = GDT[cid_x0 + -0xef]()
    //     0x799f44: sub             lr, x0, #0xef
    //     0x799f48: ldr             lr, [x21, lr, lsl #3]
    //     0x799f4c: blr             lr
    // 0x799f50: add             SP, SP, #0x10
    // 0x799f54: mov             x3, x0
    // 0x799f58: r2 = Null
    //     0x799f58: mov             x2, NULL
    // 0x799f5c: r1 = Null
    //     0x799f5c: mov             x1, NULL
    // 0x799f60: stur            x3, [fp, #-8]
    // 0x799f64: r4 = 59
    //     0x799f64: mov             x4, #0x3b
    // 0x799f68: branchIfSmi(r0, 0x799f74)
    //     0x799f68: tbz             w0, #0, #0x799f74
    // 0x799f6c: r4 = LoadClassIdInstr(r0)
    //     0x799f6c: ldur            x4, [x0, #-1]
    //     0x799f70: ubfx            x4, x4, #0xc, #0x14
    // 0x799f74: sub             x4, x4, #0x5d
    // 0x799f78: cmp             x4, #3
    // 0x799f7c: b.ls            #0x799f90
    // 0x799f80: r8 = String
    //     0x799f80: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x799f84: r3 = Null
    //     0x799f84: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c918] Null
    //     0x799f88: ldr             x3, [x3, #0x918]
    // 0x799f8c: r0 = String()
    //     0x799f8c: bl              #0xd72afc  ; IsType_String_Stub
    // 0x799f90: ldr             x1, [fp, #0x10]
    // 0x799f94: r0 = LoadClassIdInstr(r1)
    //     0x799f94: ldur            x0, [x1, #-1]
    //     0x799f98: ubfx            x0, x0, #0xc, #0x14
    // 0x799f9c: r16 = "name"
    //     0x799f9c: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    // 0x799fa0: stp             x16, x1, [SP, #-0x10]!
    // 0x799fa4: r0 = GDT[cid_x0 + -0xef]()
    //     0x799fa4: sub             lr, x0, #0xef
    //     0x799fa8: ldr             lr, [x21, lr, lsl #3]
    //     0x799fac: blr             lr
    // 0x799fb0: add             SP, SP, #0x10
    // 0x799fb4: mov             x3, x0
    // 0x799fb8: r2 = Null
    //     0x799fb8: mov             x2, NULL
    // 0x799fbc: r1 = Null
    //     0x799fbc: mov             x1, NULL
    // 0x799fc0: stur            x3, [fp, #-0x10]
    // 0x799fc4: r4 = 59
    //     0x799fc4: mov             x4, #0x3b
    // 0x799fc8: branchIfSmi(r0, 0x799fd4)
    //     0x799fc8: tbz             w0, #0, #0x799fd4
    // 0x799fcc: r4 = LoadClassIdInstr(r0)
    //     0x799fcc: ldur            x4, [x0, #-1]
    //     0x799fd0: ubfx            x4, x4, #0xc, #0x14
    // 0x799fd4: sub             x4, x4, #0x5d
    // 0x799fd8: cmp             x4, #3
    // 0x799fdc: b.ls            #0x799ff0
    // 0x799fe0: r8 = String
    //     0x799fe0: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x799fe4: r3 = Null
    //     0x799fe4: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c928] Null
    //     0x799fe8: ldr             x3, [x3, #0x928]
    // 0x799fec: r0 = String()
    //     0x799fec: bl              #0xd72afc  ; IsType_String_Stub
    // 0x799ff0: ldr             x1, [fp, #0x10]
    // 0x799ff4: r0 = LoadClassIdInstr(r1)
    //     0x799ff4: ldur            x0, [x1, #-1]
    //     0x799ff8: ubfx            x0, x0, #0xc, #0x14
    // 0x799ffc: r16 = "hasSkinTone"
    //     0x799ffc: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c938] "hasSkinTone"
    //     0x79a000: ldr             x16, [x16, #0x938]
    // 0x79a004: stp             x16, x1, [SP, #-0x10]!
    // 0x79a008: r0 = GDT[cid_x0 + -0xef]()
    //     0x79a008: sub             lr, x0, #0xef
    //     0x79a00c: ldr             lr, [x21, lr, lsl #3]
    //     0x79a010: blr             lr
    // 0x79a014: add             SP, SP, #0x10
    // 0x79a018: cmp             w0, NULL
    // 0x79a01c: b.eq            #0x79a08c
    // 0x79a020: ldr             x0, [fp, #0x10]
    // 0x79a024: r1 = LoadClassIdInstr(r0)
    //     0x79a024: ldur            x1, [x0, #-1]
    //     0x79a028: ubfx            x1, x1, #0xc, #0x14
    // 0x79a02c: r16 = "hasSkinTone"
    //     0x79a02c: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c938] "hasSkinTone"
    //     0x79a030: ldr             x16, [x16, #0x938]
    // 0x79a034: stp             x16, x0, [SP, #-0x10]!
    // 0x79a038: mov             x0, x1
    // 0x79a03c: r0 = GDT[cid_x0 + -0xef]()
    //     0x79a03c: sub             lr, x0, #0xef
    //     0x79a040: ldr             lr, [x21, lr, lsl #3]
    //     0x79a044: blr             lr
    // 0x79a048: add             SP, SP, #0x10
    // 0x79a04c: mov             x3, x0
    // 0x79a050: r2 = Null
    //     0x79a050: mov             x2, NULL
    // 0x79a054: r1 = Null
    //     0x79a054: mov             x1, NULL
    // 0x79a058: stur            x3, [fp, #-0x18]
    // 0x79a05c: r4 = 59
    //     0x79a05c: mov             x4, #0x3b
    // 0x79a060: branchIfSmi(r0, 0x79a06c)
    //     0x79a060: tbz             w0, #0, #0x79a06c
    // 0x79a064: r4 = LoadClassIdInstr(r0)
    //     0x79a064: ldur            x4, [x0, #-1]
    //     0x79a068: ubfx            x4, x4, #0xc, #0x14
    // 0x79a06c: cmp             x4, #0x3e
    // 0x79a070: b.eq            #0x79a084
    // 0x79a074: r8 = bool
    //     0x79a074: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0x79a078: r3 = Null
    //     0x79a078: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c940] Null
    //     0x79a07c: ldr             x3, [x3, #0x940]
    // 0x79a080: r0 = bool()
    //     0x79a080: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0x79a084: ldur            x2, [fp, #-0x18]
    // 0x79a088: b               #0x79a090
    // 0x79a08c: r2 = false
    //     0x79a08c: add             x2, NULL, #0x30  ; false
    // 0x79a090: ldur            x1, [fp, #-8]
    // 0x79a094: ldur            x0, [fp, #-0x10]
    // 0x79a098: stur            x2, [fp, #-0x18]
    // 0x79a09c: r0 = Emoji()
    //     0x79a09c: bl              #0x79a0cc  ; AllocateEmojiStub -> Emoji (size=0x14)
    // 0x79a0a0: ldur            x1, [fp, #-8]
    // 0x79a0a4: StoreField: r0->field_7 = r1
    //     0x79a0a4: stur            w1, [x0, #7]
    // 0x79a0a8: ldur            x1, [fp, #-0x10]
    // 0x79a0ac: StoreField: r0->field_b = r1
    //     0x79a0ac: stur            w1, [x0, #0xb]
    // 0x79a0b0: ldur            x1, [fp, #-0x18]
    // 0x79a0b4: StoreField: r0->field_f = r1
    //     0x79a0b4: stur            w1, [x0, #0xf]
    // 0x79a0b8: LeaveFrame
    //     0x79a0b8: mov             SP, fp
    //     0x79a0bc: ldp             fp, lr, [SP], #0x10
    // 0x79a0c0: ret
    //     0x79a0c0: ret             
    // 0x79a0c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79a0c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79a0c8: b               #0x799f2c
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x79ac10, size: 0x50
    // 0x79ac10: EnterFrame
    //     0x79ac10: stp             fp, lr, [SP, #-0x10]!
    //     0x79ac14: mov             fp, SP
    // 0x79ac18: AllocStack(0x10)
    //     0x79ac18: sub             SP, SP, #0x10
    // 0x79ac1c: ldr             x0, [fp, #0x18]
    // 0x79ac20: LoadField: r1 = r0->field_b
    //     0x79ac20: ldur            w1, [x0, #0xb]
    // 0x79ac24: DecompressPointer r1
    //     0x79ac24: add             x1, x1, HEAP, lsl #32
    // 0x79ac28: stur            x1, [fp, #-0x10]
    // 0x79ac2c: LoadField: r2 = r0->field_f
    //     0x79ac2c: ldur            w2, [x0, #0xf]
    // 0x79ac30: DecompressPointer r2
    //     0x79ac30: add             x2, x2, HEAP, lsl #32
    // 0x79ac34: stur            x2, [fp, #-8]
    // 0x79ac38: r0 = Emoji()
    //     0x79ac38: bl              #0x79a0cc  ; AllocateEmojiStub -> Emoji (size=0x14)
    // 0x79ac3c: ldr             x1, [fp, #0x10]
    // 0x79ac40: StoreField: r0->field_7 = r1
    //     0x79ac40: stur            w1, [x0, #7]
    // 0x79ac44: ldur            x1, [fp, #-0x10]
    // 0x79ac48: StoreField: r0->field_b = r1
    //     0x79ac48: stur            w1, [x0, #0xb]
    // 0x79ac4c: ldur            x1, [fp, #-8]
    // 0x79ac50: StoreField: r0->field_f = r1
    //     0x79ac50: stur            w1, [x0, #0xf]
    // 0x79ac54: LeaveFrame
    //     0x79ac54: mov             SP, fp
    //     0x79ac58: ldp             fp, lr, [SP], #0x10
    // 0x79ac5c: ret
    //     0x79ac5c: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xad39b8, size: 0x8c
    // 0xad39b8: EnterFrame
    //     0xad39b8: stp             fp, lr, [SP, #-0x10]!
    //     0xad39bc: mov             fp, SP
    // 0xad39c0: CheckStackOverflow
    //     0xad39c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad39c4: cmp             SP, x16
    //     0xad39c8: b.ls            #0xad3a3c
    // 0xad39cc: r1 = Null
    //     0xad39cc: mov             x1, NULL
    // 0xad39d0: r2 = 12
    //     0xad39d0: mov             x2, #0xc
    // 0xad39d4: r0 = AllocateArray()
    //     0xad39d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad39d8: r17 = "Emoji: "
    //     0xad39d8: add             x17, PP, #0x51, lsl #12  ; [pp+0x51480] "Emoji: "
    //     0xad39dc: ldr             x17, [x17, #0x480]
    // 0xad39e0: StoreField: r0->field_f = r17
    //     0xad39e0: stur            w17, [x0, #0xf]
    // 0xad39e4: ldr             x1, [fp, #0x10]
    // 0xad39e8: LoadField: r2 = r1->field_7
    //     0xad39e8: ldur            w2, [x1, #7]
    // 0xad39ec: DecompressPointer r2
    //     0xad39ec: add             x2, x2, HEAP, lsl #32
    // 0xad39f0: StoreField: r0->field_13 = r2
    //     0xad39f0: stur            w2, [x0, #0x13]
    // 0xad39f4: r17 = ", Name: "
    //     0xad39f4: add             x17, PP, #0x51, lsl #12  ; [pp+0x51488] ", Name: "
    //     0xad39f8: ldr             x17, [x17, #0x488]
    // 0xad39fc: StoreField: r0->field_17 = r17
    //     0xad39fc: stur            w17, [x0, #0x17]
    // 0xad3a00: LoadField: r2 = r1->field_b
    //     0xad3a00: ldur            w2, [x1, #0xb]
    // 0xad3a04: DecompressPointer r2
    //     0xad3a04: add             x2, x2, HEAP, lsl #32
    // 0xad3a08: StoreField: r0->field_1b = r2
    //     0xad3a08: stur            w2, [x0, #0x1b]
    // 0xad3a0c: r17 = ", HasSkinTone: "
    //     0xad3a0c: add             x17, PP, #0x51, lsl #12  ; [pp+0x51490] ", HasSkinTone: "
    //     0xad3a10: ldr             x17, [x17, #0x490]
    // 0xad3a14: StoreField: r0->field_1f = r17
    //     0xad3a14: stur            w17, [x0, #0x1f]
    // 0xad3a18: LoadField: r2 = r1->field_f
    //     0xad3a18: ldur            w2, [x1, #0xf]
    // 0xad3a1c: DecompressPointer r2
    //     0xad3a1c: add             x2, x2, HEAP, lsl #32
    // 0xad3a20: StoreField: r0->field_23 = r2
    //     0xad3a20: stur            w2, [x0, #0x23]
    // 0xad3a24: SaveReg r0
    //     0xad3a24: str             x0, [SP, #-8]!
    // 0xad3a28: r0 = _interpolate()
    //     0xad3a28: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3a2c: add             SP, SP, #8
    // 0xad3a30: LeaveFrame
    //     0xad3a30: mov             SP, fp
    //     0xad3a34: ldp             fp, lr, [SP], #0x10
    // 0xad3a38: ret
    //     0xad3a38: ret             
    // 0xad3a3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3a3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3a40: b               #0xad39cc
  }
}

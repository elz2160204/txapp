// lib: , url: package:event_bus/event_bus.dart

// class id: 1048925, size: 0x8
class :: {
}

// class id: 4500, size: 0xc, field offset: 0x8
class EventBus extends Object {

  _ fire(/* No info */) {
    // ** addr: 0x876d58, size: 0x48
    // 0x876d58: EnterFrame
    //     0x876d58: stp             fp, lr, [SP, #-0x10]!
    //     0x876d5c: mov             fp, SP
    // 0x876d60: CheckStackOverflow
    //     0x876d60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x876d64: cmp             SP, x16
    //     0x876d68: b.ls            #0x876d98
    // 0x876d6c: ldr             x0, [fp, #0x18]
    // 0x876d70: LoadField: r1 = r0->field_7
    //     0x876d70: ldur            w1, [x0, #7]
    // 0x876d74: DecompressPointer r1
    //     0x876d74: add             x1, x1, HEAP, lsl #32
    // 0x876d78: ldr             x16, [fp, #0x10]
    // 0x876d7c: stp             x16, x1, [SP, #-0x10]!
    // 0x876d80: r0 = add()
    //     0x876d80: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0x876d84: add             SP, SP, #0x10
    // 0x876d88: r0 = Null
    //     0x876d88: mov             x0, NULL
    // 0x876d8c: LeaveFrame
    //     0x876d8c: mov             SP, fp
    //     0x876d90: ldp             fp, lr, [SP], #0x10
    // 0x876d94: ret
    //     0x876d94: ret             
    // 0x876d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x876d98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x876d9c: b               #0x876d6c
  }
  _ on(/* No info */) {
    // ** addr: 0xa108d0, size: 0x16c
    // 0xa108d0: EnterFrame
    //     0xa108d0: stp             fp, lr, [SP, #-0x10]!
    //     0xa108d4: mov             fp, SP
    // 0xa108d8: AllocStack(0x18)
    //     0xa108d8: sub             SP, SP, #0x18
    // 0xa108dc: SetupParameters()
    //     0xa108dc: mov             x0, x4
    //     0xa108e0: ldur            w1, [x0, #0xf]
    //     0xa108e4: add             x1, x1, HEAP, lsl #32
    //     0xa108e8: cbnz            w1, #0xa108f4
    //     0xa108ec: mov             x0, NULL
    //     0xa108f0: b               #0xa10904
    //     0xa108f4: ldur            w1, [x0, #0x17]
    //     0xa108f8: add             x1, x1, HEAP, lsl #32
    //     0xa108fc: add             x0, fp, w1, sxtw #2
    //     0xa10900: ldr             x0, [x0, #0x10]
    //     0xa10904: stur            x0, [fp, #-8]
    // 0xa10908: CheckStackOverflow
    //     0xa10908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa1090c: cmp             SP, x16
    //     0xa10910: b.ls            #0xa10a34
    // 0xa10914: mov             x1, x0
    // 0xa10918: r2 = Null
    //     0xa10918: mov             x2, NULL
    // 0xa1091c: r3 = Y0
    //     0xa1091c: ldr             x3, [PP, #0x51b8]  ; [pp+0x51b8] TypeParameter: Y0
    // 0xa10920: r24 = InstantiateTypeNonNullableFunctionTypeParameterStub
    //     0xa10920: add             x24, PP, #0xd, lsl #12  ; [pp+0xd440] Stub: InstantiateTypeNonNullableFunctionTypeParameter (0x4accb4)
    //     0xa10924: ldr             x24, [x24, #0x440]
    // 0xa10928: LoadField: r30 = r24->field_7
    //     0xa10928: ldur            lr, [x24, #7]
    // 0xa1092c: blr             lr
    // 0xa10930: r1 = LoadClassIdInstr(r0)
    //     0xa10930: ldur            x1, [x0, #-1]
    //     0xa10934: ubfx            x1, x1, #0xc, #0x14
    // 0xa10938: ldr             x16, [THR, #0xf0]  ; THR::dynamic_type
    // 0xa1093c: stp             x16, x0, [SP, #-0x10]!
    // 0xa10940: mov             x0, x1
    // 0xa10944: mov             lr, x0
    // 0xa10948: ldr             lr, [x21, lr, lsl #3]
    // 0xa1094c: blr             lr
    // 0xa10950: add             SP, SP, #0x10
    // 0xa10954: tbnz            w0, #4, #0xa109b8
    // 0xa10958: ldr             x0, [fp, #0x10]
    // 0xa1095c: LoadField: r2 = r0->field_7
    //     0xa1095c: ldur            w2, [x0, #7]
    // 0xa10960: DecompressPointer r2
    //     0xa10960: add             x2, x2, HEAP, lsl #32
    // 0xa10964: stur            x2, [fp, #-0x10]
    // 0xa10968: LoadField: r1 = r2->field_7
    //     0xa10968: ldur            w1, [x2, #7]
    // 0xa1096c: DecompressPointer r1
    //     0xa1096c: add             x1, x1, HEAP, lsl #32
    // 0xa10970: r0 = _BroadcastStream()
    //     0xa10970: bl              #0x5a25c8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x14)
    // 0xa10974: mov             x3, x0
    // 0xa10978: ldur            x0, [fp, #-0x10]
    // 0xa1097c: stur            x3, [fp, #-0x18]
    // 0xa10980: StoreField: r3->field_f = r0
    //     0xa10980: stur            w0, [x3, #0xf]
    // 0xa10984: mov             x0, x3
    // 0xa10988: ldur            x1, [fp, #-8]
    // 0xa1098c: r2 = Null
    //     0xa1098c: mov             x2, NULL
    // 0xa10990: r8 = Stream<Y0>
    //     0xa10990: add             x8, PP, #0x26, lsl #12  ; [pp+0x26160] Type: Stream<Y0>
    //     0xa10994: ldr             x8, [x8, #0x160]
    // 0xa10998: LoadField: r9 = r8->field_7
    //     0xa10998: ldur            x9, [x8, #7]
    // 0xa1099c: r3 = Null
    //     0xa1099c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26168] Null
    //     0xa109a0: ldr             x3, [x3, #0x168]
    // 0xa109a4: blr             x9
    // 0xa109a8: ldur            x0, [fp, #-0x18]
    // 0xa109ac: LeaveFrame
    //     0xa109ac: mov             SP, fp
    //     0xa109b0: ldp             fp, lr, [SP], #0x10
    // 0xa109b4: ret
    //     0xa109b4: ret             
    // 0xa109b8: ldr             x0, [fp, #0x10]
    // 0xa109bc: ldur            x2, [fp, #-8]
    // 0xa109c0: LoadField: r3 = r0->field_7
    //     0xa109c0: ldur            w3, [x0, #7]
    // 0xa109c4: DecompressPointer r3
    //     0xa109c4: add             x3, x3, HEAP, lsl #32
    // 0xa109c8: stur            x3, [fp, #-0x10]
    // 0xa109cc: LoadField: r1 = r3->field_7
    //     0xa109cc: ldur            w1, [x3, #7]
    // 0xa109d0: DecompressPointer r1
    //     0xa109d0: add             x1, x1, HEAP, lsl #32
    // 0xa109d4: r0 = _BroadcastStream()
    //     0xa109d4: bl              #0x5a25c8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x14)
    // 0xa109d8: mov             x3, x0
    // 0xa109dc: ldur            x0, [fp, #-0x10]
    // 0xa109e0: stur            x3, [fp, #-0x18]
    // 0xa109e4: StoreField: r3->field_f = r0
    //     0xa109e4: stur            w0, [x3, #0xf]
    // 0xa109e8: r1 = Function '<anonymous closure>':.
    //     0xa109e8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26178] AnonymousClosure: (0xa10a3c), in [package:event_bus/event_bus.dart] EventBus::on (0xa108d0)
    //     0xa109ec: ldr             x1, [x1, #0x178]
    // 0xa109f0: r2 = Null
    //     0xa109f0: mov             x2, NULL
    // 0xa109f4: r0 = AllocateClosure()
    //     0xa109f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa109f8: mov             x1, x0
    // 0xa109fc: ldur            x0, [fp, #-8]
    // 0xa10a00: StoreField: r1->field_b = r0
    //     0xa10a00: stur            w0, [x1, #0xb]
    // 0xa10a04: ldur            x16, [fp, #-0x18]
    // 0xa10a08: stp             x1, x16, [SP, #-0x10]!
    // 0xa10a0c: r0 = where()
    //     0xa10a0c: bl              #0x5aa6e8  ; [dart:async] Stream::where
    // 0xa10a10: add             SP, SP, #0x10
    // 0xa10a14: ldur            x16, [fp, #-8]
    // 0xa10a18: stp             x0, x16, [SP, #-0x10]!
    // 0xa10a1c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xa10a1c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xa10a20: r0 = cast()
    //     0xa10a20: bl              #0xbd4bf0  ; [dart:async] Stream::cast
    // 0xa10a24: add             SP, SP, #0x10
    // 0xa10a28: LeaveFrame
    //     0xa10a28: mov             SP, fp
    //     0xa10a2c: ldp             fp, lr, [SP], #0x10
    // 0xa10a30: ret
    //     0xa10a30: ret             
    // 0xa10a34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa10a34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa10a38: b               #0xa10914
  }
  [closure] bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xa10a3c, size: 0xd0
    // 0xa10a3c: EnterFrame
    //     0xa10a3c: stp             fp, lr, [SP, #-0x10]!
    //     0xa10a40: mov             fp, SP
    // 0xa10a44: ldr             x0, [fp, #0x18]
    // 0xa10a48: LoadField: r1 = r0->field_b
    //     0xa10a48: ldur            w1, [x0, #0xb]
    // 0xa10a4c: DecompressPointer r1
    //     0xa10a4c: add             x1, x1, HEAP, lsl #32
    // 0xa10a50: ldr             x0, [fp, #0x10]
    // 0xa10a54: r2 = Null
    //     0xa10a54: mov             x2, NULL
    // 0xa10a58: cmp             w1, NULL
    // 0xa10a5c: b.eq            #0xa10afc
    // 0xa10a60: LoadField: r3 = r1->field_17
    //     0xa10a60: ldur            w3, [x1, #0x17]
    // 0xa10a64: DecompressPointer r3
    //     0xa10a64: add             x3, x3, HEAP, lsl #32
    // 0xa10a68: ldr             x16, [THR, #0xf0]  ; THR::dynamic_type
    // 0xa10a6c: cmp             w3, w16
    // 0xa10a70: b.eq            #0xa10afc
    // 0xa10a74: r16 = Object?
    //     0xa10a74: ldr             x16, [PP, #0x1878]  ; [pp+0x1878] Type: Object?
    // 0xa10a78: cmp             w3, w16
    // 0xa10a7c: b.eq            #0xa10afc
    // 0xa10a80: r16 = void?
    //     0xa10a80: ldr             x16, [PP, #0x1880]  ; [pp+0x1880] Type: void?
    // 0xa10a84: cmp             w3, w16
    // 0xa10a88: b.eq            #0xa10afc
    // 0xa10a8c: tbnz            w0, #0, #0xa10aa8
    // 0xa10a90: r16 = int
    //     0xa10a90: ldr             x16, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xa10a94: cmp             w3, w16
    // 0xa10a98: b.eq            #0xa10afc
    // 0xa10a9c: r16 = num
    //     0xa10a9c: ldr             x16, [PP, #0x1888]  ; [pp+0x1888] Type: num
    // 0xa10aa0: cmp             w3, w16
    // 0xa10aa4: b.eq            #0xa10afc
    // 0xa10aa8: r8 = Y0
    //     0xa10aa8: add             x8, PP, #0x26, lsl #12  ; [pp+0x26180] TypeParameter: Y0
    //     0xa10aac: ldr             x8, [x8, #0x180]
    // 0xa10ab0: r3 = SubtypeTestCache
    //     0xa10ab0: add             x3, PP, #0x26, lsl #12  ; [pp+0x26188] SubtypeTestCache
    //     0xa10ab4: ldr             x3, [x3, #0x188]
    // 0xa10ab8: r24 = Subtype7TestCacheStub
    //     0xa10ab8: ldr             x24, [PP, #0x18]  ; [pp+0x18] Stub: Subtype7TestCache (0x4ae0ac)
    // 0xa10abc: LoadField: r30 = r24->field_7
    //     0xa10abc: ldur            lr, [x24, #7]
    // 0xa10ac0: blr             lr
    // 0xa10ac4: cmp             w7, NULL
    // 0xa10ac8: b.eq            #0xa10ad4
    // 0xa10acc: tbnz            w7, #4, #0xa10af4
    // 0xa10ad0: b               #0xa10afc
    // 0xa10ad4: r8 = Y0
    //     0xa10ad4: add             x8, PP, #0x26, lsl #12  ; [pp+0x26190] TypeParameter: Y0
    //     0xa10ad8: ldr             x8, [x8, #0x190]
    // 0xa10adc: r3 = SubtypeTestCache
    //     0xa10adc: add             x3, PP, #0x26, lsl #12  ; [pp+0x26198] SubtypeTestCache
    //     0xa10ae0: ldr             x3, [x3, #0x198]
    // 0xa10ae4: r24 = InstanceOfStub
    //     0xa10ae4: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xa10ae8: LoadField: r30 = r24->field_7
    //     0xa10ae8: ldur            lr, [x24, #7]
    // 0xa10aec: blr             lr
    // 0xa10af0: b               #0xa10b00
    // 0xa10af4: r0 = false
    //     0xa10af4: add             x0, NULL, #0x30  ; false
    // 0xa10af8: b               #0xa10b00
    // 0xa10afc: r0 = true
    //     0xa10afc: add             x0, NULL, #0x20  ; true
    // 0xa10b00: LeaveFrame
    //     0xa10b00: mov             SP, fp
    //     0xa10b04: ldp             fp, lr, [SP], #0x10
    // 0xa10b08: ret
    //     0xa10b08: ret             
  }
}

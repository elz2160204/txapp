// lib: , url: package:extended_image/src/editor/editor.dart

// class id: 1048929, size: 0x8
class :: {
}

// class id: 3401, size: 0x30, field offset: 0x14
class ExtendedImageEditorState extends State<ExtendedImageEditor> {

  late double _startingScale; // offset: 0x1c
  late Offset _startingOffset; // offset: 0x20

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x79b08c, size: 0xb4
    // 0x79b08c: EnterFrame
    //     0x79b08c: stp             fp, lr, [SP, #-0x10]!
    //     0x79b090: mov             fp, SP
    // 0x79b094: CheckStackOverflow
    //     0x79b094: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79b098: cmp             SP, x16
    //     0x79b09c: b.ls            #0x79b138
    // 0x79b0a0: ldr             x0, [fp, #0x10]
    // 0x79b0a4: r2 = Null
    //     0x79b0a4: mov             x2, NULL
    // 0x79b0a8: r1 = Null
    //     0x79b0a8: mov             x1, NULL
    // 0x79b0ac: r4 = 59
    //     0x79b0ac: mov             x4, #0x3b
    // 0x79b0b0: branchIfSmi(r0, 0x79b0bc)
    //     0x79b0b0: tbz             w0, #0, #0x79b0bc
    // 0x79b0b4: r4 = LoadClassIdInstr(r0)
    //     0x79b0b4: ldur            x4, [x0, #-1]
    //     0x79b0b8: ubfx            x4, x4, #0xc, #0x14
    // 0x79b0bc: r17 = 4215
    //     0x79b0bc: mov             x17, #0x1077
    // 0x79b0c0: cmp             x4, x17
    // 0x79b0c4: b.eq            #0x79b0dc
    // 0x79b0c8: r8 = ExtendedImageEditor
    //     0x79b0c8: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4c760] Type: ExtendedImageEditor
    //     0x79b0cc: ldr             x8, [x8, #0x760]
    // 0x79b0d0: r3 = Null
    //     0x79b0d0: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c768] Null
    //     0x79b0d4: ldr             x3, [x3, #0x768]
    // 0x79b0d8: r0 = ExtendedImageEditor()
    //     0x79b0d8: bl              #0x79b368  ; IsType_ExtendedImageEditor_Stub
    // 0x79b0dc: ldr             x16, [fp, #0x18]
    // 0x79b0e0: SaveReg r16
    //     0x79b0e0: str             x16, [SP, #-8]!
    // 0x79b0e4: r0 = _initGestureConfig()
    //     0x79b0e4: bl              #0x79b140  ; [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_initGestureConfig
    // 0x79b0e8: add             SP, SP, #8
    // 0x79b0ec: ldr             x0, [fp, #0x18]
    // 0x79b0f0: LoadField: r2 = r0->field_7
    //     0x79b0f0: ldur            w2, [x0, #7]
    // 0x79b0f4: DecompressPointer r2
    //     0x79b0f4: add             x2, x2, HEAP, lsl #32
    // 0x79b0f8: ldr             x0, [fp, #0x10]
    // 0x79b0fc: r1 = Null
    //     0x79b0fc: mov             x1, NULL
    // 0x79b100: cmp             w2, NULL
    // 0x79b104: b.eq            #0x79b128
    // 0x79b108: LoadField: r4 = r2->field_17
    //     0x79b108: ldur            w4, [x2, #0x17]
    // 0x79b10c: DecompressPointer r4
    //     0x79b10c: add             x4, x4, HEAP, lsl #32
    // 0x79b110: r8 = X0 bound StatefulWidget
    //     0x79b110: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x79b114: ldr             x8, [x8, #0x858]
    // 0x79b118: LoadField: r9 = r4->field_7
    //     0x79b118: ldur            x9, [x4, #7]
    // 0x79b11c: r3 = Null
    //     0x79b11c: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c778] Null
    //     0x79b120: ldr             x3, [x3, #0x778]
    // 0x79b124: blr             x9
    // 0x79b128: r0 = Null
    //     0x79b128: mov             x0, NULL
    // 0x79b12c: LeaveFrame
    //     0x79b12c: mov             SP, fp
    //     0x79b130: ldp             fp, lr, [SP], #0x10
    // 0x79b134: ret
    //     0x79b134: ret             
    // 0x79b138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79b138: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79b13c: b               #0x79b0a0
  }
  _ _initGestureConfig(/* No info */) {
    // ** addr: 0x79b140, size: 0x210
    // 0x79b140: EnterFrame
    //     0x79b140: stp             fp, lr, [SP, #-0x10]!
    //     0x79b144: mov             fp, SP
    // 0x79b148: AllocStack(0x8)
    //     0x79b148: sub             SP, SP, #8
    // 0x79b14c: ldr             x0, [fp, #0x10]
    // 0x79b150: LoadField: r1 = r0->field_b
    //     0x79b150: ldur            w1, [x0, #0xb]
    // 0x79b154: DecompressPointer r1
    //     0x79b154: add             x1, x1, HEAP, lsl #32
    // 0x79b158: cmp             w1, NULL
    // 0x79b15c: b.eq            #0x79b330
    // 0x79b160: LoadField: r2 = r1->field_b
    //     0x79b160: ldur            w2, [x1, #0xb]
    // 0x79b164: DecompressPointer r2
    //     0x79b164: add             x2, x2, HEAP, lsl #32
    // 0x79b168: stur            x2, [fp, #-8]
    // 0x79b16c: LoadField: r1 = r2->field_b
    //     0x79b16c: ldur            w1, [x2, #0xb]
    // 0x79b170: DecompressPointer r1
    //     0x79b170: add             x1, x1, HEAP, lsl #32
    // 0x79b174: cmp             w1, NULL
    // 0x79b178: b.eq            #0x79b334
    // 0x79b17c: r0 = EditorConfig()
    //     0x79b17c: bl              #0x79b35c  ; AllocateEditorConfigStub -> EditorConfig (size=0x60)
    // 0x79b180: d0 = 5.000000
    //     0x79b180: fmov            d0, #5.00000000
    // 0x79b184: StoreField: r0->field_f = d0
    //     0x79b184: stur            d0, [x0, #0xf]
    // 0x79b188: r1 = Instance_EdgeInsets
    //     0x79b188: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f290] Obj!EdgeInsets@b35a21
    //     0x79b18c: ldr             x1, [x1, #0x290]
    // 0x79b190: StoreField: r0->field_17 = r1
    //     0x79b190: stur            w1, [x0, #0x17]
    // 0x79b194: r2 = Instance_Size
    //     0x79b194: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4c788] Obj!Size@b5ec91
    //     0x79b198: ldr             x2, [x2, #0x788]
    // 0x79b19c: StoreField: r0->field_1b = r2
    //     0x79b19c: stur            w2, [x0, #0x1b]
    // 0x79b1a0: d0 = 0.600000
    //     0x79b1a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf90] IMM: double(0.6) from 0x3fe3333333333333
    //     0x79b1a4: ldr             d0, [x17, #0xf90]
    // 0x79b1a8: StoreField: r0->field_27 = d0
    //     0x79b1a8: stur            d0, [x0, #0x27]
    // 0x79b1ac: d0 = 20.000000
    //     0x79b1ac: fmov            d0, #20.00000000
    // 0x79b1b0: StoreField: r0->field_33 = d0
    //     0x79b1b0: stur            d0, [x0, #0x33]
    // 0x79b1b4: r2 = Instance_Duration
    //     0x79b1b4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x79b1b8: ldr             x2, [x2, #0x9e0]
    // 0x79b1bc: StoreField: r0->field_3b = r2
    //     0x79b1bc: stur            w2, [x0, #0x3b]
    // 0x79b1c0: r2 = Instance_Duration
    //     0x79b1c0: add             x2, PP, #0x20, lsl #12  ; [pp+0x20808] Obj!Duration@b67ae1
    //     0x79b1c4: ldr             x2, [x2, #0x808]
    // 0x79b1c8: StoreField: r0->field_3f = r2
    //     0x79b1c8: stur            w2, [x0, #0x3f]
    // 0x79b1cc: r2 = Instance_InitCropRectType
    //     0x79b1cc: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4c790] Obj!InitCropRectType@b66191
    //     0x79b1d0: ldr             x2, [x2, #0x790]
    // 0x79b1d4: StoreField: r0->field_4b = r2
    //     0x79b1d4: stur            w2, [x0, #0x4b]
    // 0x79b1d8: r2 = Instance_EditorCropLayerPainter
    //     0x79b1d8: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4c798] Obj!EditorCropLayerPainter@b4fdd1
    //     0x79b1dc: ldr             x2, [x2, #0x798]
    // 0x79b1e0: StoreField: r0->field_4f = r2
    //     0x79b1e0: stur            w2, [x0, #0x4f]
    // 0x79b1e4: d0 = 1.000000
    //     0x79b1e4: fmov            d0, #1.00000000
    // 0x79b1e8: StoreField: r0->field_53 = d0
    //     0x79b1e8: stur            d0, [x0, #0x53]
    // 0x79b1ec: r2 = Instance_HitTestBehavior
    //     0x79b1ec: add             x2, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!HitTestBehavior@b64931
    //     0x79b1f0: ldr             x2, [x2, #0x780]
    // 0x79b1f4: StoreField: r0->field_b = r2
    //     0x79b1f4: stur            w2, [x0, #0xb]
    // 0x79b1f8: r2 = false
    //     0x79b1f8: add             x2, NULL, #0x30  ; false
    // 0x79b1fc: StoreField: r0->field_5b = r2
    //     0x79b1fc: stur            w2, [x0, #0x5b]
    // 0x79b200: ldr             x3, [fp, #0x10]
    // 0x79b204: StoreField: r3->field_17 = r0
    //     0x79b204: stur            w0, [x3, #0x17]
    //     0x79b208: ldurb           w16, [x3, #-1]
    //     0x79b20c: ldurb           w17, [x0, #-1]
    //     0x79b210: and             x16, x17, x16, lsr #2
    //     0x79b214: tst             x16, HEAP, lsr #32
    //     0x79b218: b.eq            #0x79b220
    //     0x79b21c: bl              #0xd682ac
    // 0x79b220: LoadField: r0 = r3->field_13
    //     0x79b220: ldur            w0, [x3, #0x13]
    // 0x79b224: DecompressPointer r0
    //     0x79b224: add             x0, x0, HEAP, lsl #32
    // 0x79b228: cmp             w0, NULL
    // 0x79b22c: b.ne            #0x79b2a4
    // 0x79b230: r0 = EditActionDetails()
    //     0x79b230: bl              #0x79b350  ; AllocateEditActionDetailsStub -> EditActionDetails (size=0x58)
    // 0x79b234: mov             x1, x0
    // 0x79b238: d0 = 0.000000
    //     0x79b238: eor             v0.16b, v0.16b, v0.16b
    // 0x79b23c: StoreField: r1->field_7 = d0
    //     0x79b23c: stur            d0, [x1, #7]
    // 0x79b240: r2 = false
    //     0x79b240: add             x2, NULL, #0x30  ; false
    // 0x79b244: StoreField: r1->field_f = r2
    //     0x79b244: stur            w2, [x1, #0xf]
    // 0x79b248: StoreField: r1->field_13 = r2
    //     0x79b248: stur            w2, [x1, #0x13]
    // 0x79b24c: StoreField: r1->field_17 = r2
    //     0x79b24c: stur            w2, [x1, #0x17]
    // 0x79b250: StoreField: r1->field_1b = r2
    //     0x79b250: stur            w2, [x1, #0x1b]
    // 0x79b254: StoreField: r1->field_2b = r2
    //     0x79b254: stur            w2, [x1, #0x2b]
    // 0x79b258: d0 = 1.000000
    //     0x79b258: fmov            d0, #1.00000000
    // 0x79b25c: StoreField: r1->field_2f = d0
    //     0x79b25c: stur            d0, [x1, #0x2f]
    // 0x79b260: StoreField: r1->field_37 = d0
    //     0x79b260: stur            d0, [x1, #0x37]
    // 0x79b264: r2 = Instance_Offset
    //     0x79b264: ldr             x2, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x79b268: StoreField: r1->field_3f = r2
    //     0x79b268: stur            w2, [x1, #0x3f]
    // 0x79b26c: r2 = Instance_EdgeInsets
    //     0x79b26c: add             x2, PP, #0x1f, lsl #12  ; [pp+0x1f290] Obj!EdgeInsets@b35a21
    //     0x79b270: ldr             x2, [x2, #0x290]
    // 0x79b274: StoreField: r1->field_47 = r2
    //     0x79b274: stur            w2, [x1, #0x47]
    // 0x79b278: mov             x0, x1
    // 0x79b27c: ldr             x2, [fp, #0x10]
    // 0x79b280: StoreField: r2->field_13 = r0
    //     0x79b280: stur            w0, [x2, #0x13]
    //     0x79b284: ldurb           w16, [x2, #-1]
    //     0x79b288: ldurb           w17, [x0, #-1]
    //     0x79b28c: and             x16, x17, x16, lsr #2
    //     0x79b290: tst             x16, HEAP, lsr #32
    //     0x79b294: b.eq            #0x79b29c
    //     0x79b298: bl              #0xd6828c
    // 0x79b29c: mov             x2, x1
    // 0x79b2a0: b               #0x79b2a8
    // 0x79b2a4: mov             x2, x0
    // 0x79b2a8: ldur            x1, [fp, #-8]
    // 0x79b2ac: LoadField: r3 = r1->field_1f
    //     0x79b2ac: ldur            w3, [x1, #0x1f]
    // 0x79b2b0: DecompressPointer r3
    //     0x79b2b0: add             x3, x3, HEAP, lsl #32
    // 0x79b2b4: cmp             w3, NULL
    // 0x79b2b8: b.eq            #0x79b31c
    // 0x79b2bc: LoadField: r1 = r3->field_7
    //     0x79b2bc: ldur            w1, [x3, #7]
    // 0x79b2c0: DecompressPointer r1
    //     0x79b2c0: add             x1, x1, HEAP, lsl #32
    // 0x79b2c4: LoadField: r3 = r1->field_f
    //     0x79b2c4: ldur            x3, [x1, #0xf]
    // 0x79b2c8: LoadField: r4 = r1->field_17
    //     0x79b2c8: ldur            x4, [x1, #0x17]
    // 0x79b2cc: scvtf           d0, x3
    // 0x79b2d0: scvtf           d1, x4
    // 0x79b2d4: fdiv            d2, d0, d1
    // 0x79b2d8: r0 = inline_Allocate_Double()
    //     0x79b2d8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x79b2dc: add             x0, x0, #0x10
    //     0x79b2e0: cmp             x1, x0
    //     0x79b2e4: b.ls            #0x79b338
    //     0x79b2e8: str             x0, [THR, #0x60]  ; THR::top
    //     0x79b2ec: sub             x0, x0, #0xf
    //     0x79b2f0: mov             x1, #0xd108
    //     0x79b2f4: movk            x1, #3, lsl #16
    //     0x79b2f8: stur            x1, [x0, #-1]
    // 0x79b2fc: StoreField: r0->field_7 = d2
    //     0x79b2fc: stur            d2, [x0, #7]
    // 0x79b300: StoreField: r2->field_4f = r0
    //     0x79b300: stur            w0, [x2, #0x4f]
    //     0x79b304: ldurb           w16, [x2, #-1]
    //     0x79b308: ldurb           w17, [x0, #-1]
    //     0x79b30c: and             x16, x17, x16, lsr #2
    //     0x79b310: tst             x16, HEAP, lsr #32
    //     0x79b314: b.eq            #0x79b31c
    //     0x79b318: bl              #0xd6828c
    // 0x79b31c: StoreField: r2->field_53 = rNULL
    //     0x79b31c: stur            NULL, [x2, #0x53]
    // 0x79b320: r0 = Null
    //     0x79b320: mov             x0, NULL
    // 0x79b324: LeaveFrame
    //     0x79b324: mov             SP, fp
    //     0x79b328: ldp             fp, lr, [SP], #0x10
    // 0x79b32c: ret
    //     0x79b32c: ret             
    // 0x79b330: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b330: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79b334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b334: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79b338: SaveReg d2
    //     0x79b338: str             q2, [SP, #-0x10]!
    // 0x79b33c: SaveReg r2
    //     0x79b33c: str             x2, [SP, #-8]!
    // 0x79b340: r0 = AllocateDouble()
    //     0x79b340: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x79b344: RestoreReg r2
    //     0x79b344: ldr             x2, [SP], #8
    // 0x79b348: RestoreReg d2
    //     0x79b348: ldr             q2, [SP], #0x10
    // 0x79b34c: b               #0x79b2fc
  }
  _ build(/* No info */) {
    // ** addr: 0x82ab50, size: 0x410
    // 0x82ab50: EnterFrame
    //     0x82ab50: stp             fp, lr, [SP, #-0x10]!
    //     0x82ab54: mov             fp, SP
    // 0x82ab58: AllocStack(0x38)
    //     0x82ab58: sub             SP, SP, #0x38
    // 0x82ab5c: CheckStackOverflow
    //     0x82ab5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82ab60: cmp             SP, x16
    //     0x82ab64: b.ls            #0x82af10
    // 0x82ab68: r1 = 1
    //     0x82ab68: mov             x1, #1
    // 0x82ab6c: r0 = AllocateContext()
    //     0x82ab6c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82ab70: mov             x1, x0
    // 0x82ab74: ldr             x0, [fp, #0x18]
    // 0x82ab78: stur            x1, [fp, #-0x28]
    // 0x82ab7c: StoreField: r1->field_f = r0
    //     0x82ab7c: stur            w0, [x1, #0xf]
    // 0x82ab80: LoadField: r2 = r0->field_b
    //     0x82ab80: ldur            w2, [x0, #0xb]
    // 0x82ab84: DecompressPointer r2
    //     0x82ab84: add             x2, x2, HEAP, lsl #32
    // 0x82ab88: cmp             w2, NULL
    // 0x82ab8c: b.eq            #0x82af18
    // 0x82ab90: LoadField: r3 = r2->field_b
    //     0x82ab90: ldur            w3, [x2, #0xb]
    // 0x82ab94: DecompressPointer r3
    //     0x82ab94: add             x3, x3, HEAP, lsl #32
    // 0x82ab98: LoadField: r2 = r3->field_b
    //     0x82ab98: ldur            w2, [x3, #0xb]
    // 0x82ab9c: DecompressPointer r2
    //     0x82ab9c: add             x2, x2, HEAP, lsl #32
    // 0x82aba0: cmp             w2, NULL
    // 0x82aba4: b.eq            #0x82af1c
    // 0x82aba8: LoadField: r4 = r3->field_1f
    //     0x82aba8: ldur            w4, [x3, #0x1f]
    // 0x82abac: DecompressPointer r4
    //     0x82abac: add             x4, x4, HEAP, lsl #32
    // 0x82abb0: cmp             w4, NULL
    // 0x82abb4: b.ne            #0x82abc0
    // 0x82abb8: r5 = Null
    //     0x82abb8: mov             x5, NULL
    // 0x82abbc: b               #0x82abc8
    // 0x82abc0: LoadField: r5 = r4->field_7
    //     0x82abc0: ldur            w5, [x4, #7]
    // 0x82abc4: DecompressPointer r5
    //     0x82abc4: add             x5, x5, HEAP, lsl #32
    // 0x82abc8: stur            x5, [fp, #-0x20]
    // 0x82abcc: cmp             w4, NULL
    // 0x82abd0: b.ne            #0x82abdc
    // 0x82abd4: r4 = Null
    //     0x82abd4: mov             x4, NULL
    // 0x82abd8: b               #0x82ac08
    // 0x82abdc: LoadField: d0 = r4->field_b
    //     0x82abdc: ldur            d0, [x4, #0xb]
    // 0x82abe0: r4 = inline_Allocate_Double()
    //     0x82abe0: ldp             x4, x6, [THR, #0x60]  ; THR::top
    //     0x82abe4: add             x4, x4, #0x10
    //     0x82abe8: cmp             x6, x4
    //     0x82abec: b.ls            #0x82af20
    //     0x82abf0: str             x4, [THR, #0x60]  ; THR::top
    //     0x82abf4: sub             x4, x4, #0xf
    //     0x82abf8: mov             x6, #0xd108
    //     0x82abfc: movk            x6, #3, lsl #16
    //     0x82ac00: stur            x6, [x4, #-1]
    // 0x82ac04: StoreField: r4->field_7 = d0
    //     0x82ac04: stur            d0, [x4, #7]
    // 0x82ac08: cmp             w4, NULL
    // 0x82ac0c: b.ne            #0x82ac18
    // 0x82ac10: d0 = 1.000000
    //     0x82ac10: fmov            d0, #1.00000000
    // 0x82ac14: b               #0x82ac1c
    // 0x82ac18: LoadField: d0 = r4->field_7
    //     0x82ac18: ldur            d0, [x4, #7]
    // 0x82ac1c: stur            d0, [fp, #-0x38]
    // 0x82ac20: LoadField: r4 = r2->field_77
    //     0x82ac20: ldur            w4, [x2, #0x77]
    // 0x82ac24: DecompressPointer r4
    //     0x82ac24: add             x4, x4, HEAP, lsl #32
    // 0x82ac28: stur            x4, [fp, #-0x18]
    // 0x82ac2c: LoadField: r2 = r3->field_27
    //     0x82ac2c: ldur            w2, [x3, #0x27]
    // 0x82ac30: DecompressPointer r2
    //     0x82ac30: add             x2, x2, HEAP, lsl #32
    // 0x82ac34: r16 = Sentinel
    //     0x82ac34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82ac38: cmp             w2, w16
    // 0x82ac3c: b.eq            #0x82af4c
    // 0x82ac40: stur            x2, [fp, #-0x10]
    // 0x82ac44: LoadField: r3 = r0->field_13
    //     0x82ac44: ldur            w3, [x0, #0x13]
    // 0x82ac48: DecompressPointer r3
    //     0x82ac48: add             x3, x3, HEAP, lsl #32
    // 0x82ac4c: stur            x3, [fp, #-8]
    // 0x82ac50: r0 = ExtendedRawImage()
    //     0x82ac50: bl              #0x82af6c  ; AllocateExtendedRawImageStub -> ExtendedRawImage (size=0x68)
    // 0x82ac54: mov             x1, x0
    // 0x82ac58: ldur            x0, [fp, #-0x20]
    // 0x82ac5c: stur            x1, [fp, #-0x30]
    // 0x82ac60: StoreField: r1->field_1f = r0
    //     0x82ac60: stur            w0, [x1, #0x1f]
    // 0x82ac64: ldur            d0, [fp, #-0x38]
    // 0x82ac68: StoreField: r1->field_2b = d0
    //     0x82ac68: stur            d0, [x1, #0x2b]
    // 0x82ac6c: ldur            x0, [fp, #-0x18]
    // 0x82ac70: StoreField: r1->field_43 = r0
    //     0x82ac70: stur            w0, [x1, #0x43]
    // 0x82ac74: r0 = Instance_Alignment
    //     0x82ac74: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x82ac78: ldr             x0, [x0, #0xc70]
    // 0x82ac7c: StoreField: r1->field_47 = r0
    //     0x82ac7c: stur            w0, [x1, #0x47]
    // 0x82ac80: r0 = Instance_ImageRepeat
    //     0x82ac80: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0x82ac84: ldr             x0, [x0, #0x540]
    // 0x82ac88: StoreField: r1->field_4b = r0
    //     0x82ac88: stur            w0, [x1, #0x4b]
    // 0x82ac8c: r0 = false
    //     0x82ac8c: add             x0, NULL, #0x30  ; false
    // 0x82ac90: StoreField: r1->field_53 = r0
    //     0x82ac90: stur            w0, [x1, #0x53]
    // 0x82ac94: ldur            x2, [fp, #-0x10]
    // 0x82ac98: StoreField: r1->field_57 = r2
    //     0x82ac98: stur            w2, [x1, #0x57]
    // 0x82ac9c: r2 = Instance_FilterQuality
    //     0x82ac9c: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0x82aca0: ldr             x2, [x2, #0x548]
    // 0x82aca4: StoreField: r1->field_3b = r2
    //     0x82aca4: stur            w2, [x1, #0x3b]
    // 0x82aca8: ldur            x2, [fp, #-8]
    // 0x82acac: StoreField: r1->field_f = r2
    //     0x82acac: stur            w2, [x1, #0xf]
    // 0x82acb0: StoreField: r1->field_b = r0
    //     0x82acb0: stur            w0, [x1, #0xb]
    // 0x82acb4: r0 = Instance_EdgeInsets
    //     0x82acb4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x82acb8: ldr             x0, [x0, #0xbd8]
    // 0x82acbc: StoreField: r1->field_63 = r0
    //     0x82acbc: stur            w0, [x1, #0x63]
    // 0x82acc0: r1 = 1
    //     0x82acc0: mov             x1, #1
    // 0x82acc4: r0 = AllocateContext()
    //     0x82acc4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82acc8: mov             x1, x0
    // 0x82accc: ldr             x0, [fp, #0x18]
    // 0x82acd0: stur            x1, [fp, #-8]
    // 0x82acd4: StoreField: r1->field_f = r0
    //     0x82acd4: stur            w0, [x1, #0xf]
    // 0x82acd8: r1 = 1
    //     0x82acd8: mov             x1, #1
    // 0x82acdc: r0 = AllocateContext()
    //     0x82acdc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82ace0: mov             x2, x0
    // 0x82ace4: ldr             x0, [fp, #0x18]
    // 0x82ace8: stur            x2, [fp, #-0x10]
    // 0x82acec: StoreField: r2->field_f = r0
    //     0x82acec: stur            w0, [x2, #0xf]
    // 0x82acf0: LoadField: r1 = r0->field_17
    //     0x82acf0: ldur            w1, [x0, #0x17]
    // 0x82acf4: DecompressPointer r1
    //     0x82acf4: add             x1, x1, HEAP, lsl #32
    // 0x82acf8: cmp             w1, NULL
    // 0x82acfc: b.eq            #0x82af58
    // 0x82ad00: r1 = <StackParentData<RenderBox>>
    //     0x82ad00: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x82ad04: ldr             x1, [x1, #0x5a8]
    // 0x82ad08: r0 = Positioned()
    //     0x82ad08: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x82ad0c: mov             x3, x0
    // 0x82ad10: r0 = 0.000000
    //     0x82ad10: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x82ad14: stur            x3, [fp, #-0x18]
    // 0x82ad18: StoreField: r3->field_13 = r0
    //     0x82ad18: stur            w0, [x3, #0x13]
    // 0x82ad1c: StoreField: r3->field_17 = r0
    //     0x82ad1c: stur            w0, [x3, #0x17]
    // 0x82ad20: StoreField: r3->field_1b = r0
    //     0x82ad20: stur            w0, [x3, #0x1b]
    // 0x82ad24: StoreField: r3->field_1f = r0
    //     0x82ad24: stur            w0, [x3, #0x1f]
    // 0x82ad28: ldur            x1, [fp, #-0x30]
    // 0x82ad2c: StoreField: r3->field_b = r1
    //     0x82ad2c: stur            w1, [x3, #0xb]
    // 0x82ad30: ldur            x2, [fp, #-0x28]
    // 0x82ad34: r1 = Function '<anonymous closure>':.
    //     0x82ad34: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c700] AnonymousClosure: (0x82bbe8), in [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::build (0x82ab50)
    //     0x82ad38: ldr             x1, [x1, #0x700]
    // 0x82ad3c: r0 = AllocateClosure()
    //     0x82ad3c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82ad40: r1 = <BoxConstraints>
    //     0x82ad40: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f420] TypeArguments: <BoxConstraints>
    //     0x82ad44: ldr             x1, [x1, #0x420]
    // 0x82ad48: stur            x0, [fp, #-0x20]
    // 0x82ad4c: r0 = LayoutBuilder()
    //     0x82ad4c: bl              #0x824c90  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0x82ad50: mov             x2, x0
    // 0x82ad54: ldur            x0, [fp, #-0x20]
    // 0x82ad58: stur            x2, [fp, #-0x30]
    // 0x82ad5c: StoreField: r2->field_f = r0
    //     0x82ad5c: stur            w0, [x2, #0xf]
    // 0x82ad60: r1 = <StackParentData<RenderBox>>
    //     0x82ad60: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x82ad64: ldr             x1, [x1, #0x5a8]
    // 0x82ad68: r0 = Positioned()
    //     0x82ad68: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x82ad6c: mov             x3, x0
    // 0x82ad70: r0 = 0.000000
    //     0x82ad70: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x82ad74: stur            x3, [fp, #-0x20]
    // 0x82ad78: StoreField: r3->field_13 = r0
    //     0x82ad78: stur            w0, [x3, #0x13]
    // 0x82ad7c: StoreField: r3->field_17 = r0
    //     0x82ad7c: stur            w0, [x3, #0x17]
    // 0x82ad80: StoreField: r3->field_1b = r0
    //     0x82ad80: stur            w0, [x3, #0x1b]
    // 0x82ad84: StoreField: r3->field_1f = r0
    //     0x82ad84: stur            w0, [x3, #0x1f]
    // 0x82ad88: ldur            x0, [fp, #-0x30]
    // 0x82ad8c: StoreField: r3->field_b = r0
    //     0x82ad8c: stur            w0, [x3, #0xb]
    // 0x82ad90: r1 = Null
    //     0x82ad90: mov             x1, NULL
    // 0x82ad94: r2 = 4
    //     0x82ad94: mov             x2, #4
    // 0x82ad98: r0 = AllocateArray()
    //     0x82ad98: bl              #0xd6987c  ; AllocateArrayStub
    // 0x82ad9c: mov             x2, x0
    // 0x82ada0: ldur            x0, [fp, #-0x18]
    // 0x82ada4: stur            x2, [fp, #-0x30]
    // 0x82ada8: StoreField: r2->field_f = r0
    //     0x82ada8: stur            w0, [x2, #0xf]
    // 0x82adac: ldur            x0, [fp, #-0x20]
    // 0x82adb0: StoreField: r2->field_13 = r0
    //     0x82adb0: stur            w0, [x2, #0x13]
    // 0x82adb4: r1 = <Widget>
    //     0x82adb4: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x82adb8: ldr             x1, [x1, #0xea8]
    // 0x82adbc: r0 = AllocateGrowableArray()
    //     0x82adbc: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x82adc0: mov             x1, x0
    // 0x82adc4: ldur            x0, [fp, #-0x30]
    // 0x82adc8: stur            x1, [fp, #-0x18]
    // 0x82adcc: StoreField: r1->field_f = r0
    //     0x82adcc: stur            w0, [x1, #0xf]
    // 0x82add0: r0 = 4
    //     0x82add0: mov             x0, #4
    // 0x82add4: StoreField: r1->field_b = r0
    //     0x82add4: stur            w0, [x1, #0xb]
    // 0x82add8: r0 = Stack()
    //     0x82add8: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x82addc: mov             x1, x0
    // 0x82ade0: r0 = Instance_AlignmentDirectional
    //     0x82ade0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0x82ade4: ldr             x0, [x0, #0xf70]
    // 0x82ade8: stur            x1, [fp, #-0x20]
    // 0x82adec: StoreField: r1->field_f = r0
    //     0x82adec: stur            w0, [x1, #0xf]
    // 0x82adf0: r0 = Instance_StackFit
    //     0x82adf0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f78] Obj!StackFit@b64771
    //     0x82adf4: ldr             x0, [x0, #0xf78]
    // 0x82adf8: StoreField: r1->field_17 = r0
    //     0x82adf8: stur            w0, [x1, #0x17]
    // 0x82adfc: r0 = Instance_Clip
    //     0x82adfc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x82ae00: ldr             x0, [x0, #0x678]
    // 0x82ae04: StoreField: r1->field_1b = r0
    //     0x82ae04: stur            w0, [x1, #0x1b]
    // 0x82ae08: ldur            x0, [fp, #-0x18]
    // 0x82ae0c: StoreField: r1->field_b = r0
    //     0x82ae0c: stur            w0, [x1, #0xb]
    // 0x82ae10: r0 = GestureDetector()
    //     0x82ae10: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x82ae14: ldur            x2, [fp, #-8]
    // 0x82ae18: r1 = Function '_handleScaleStart@406395952':.
    //     0x82ae18: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c708] AnonymousClosure: (0x82bb9c), in [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_handleScaleStart (0x82b94c)
    //     0x82ae1c: ldr             x1, [x1, #0x708]
    // 0x82ae20: stur            x0, [fp, #-8]
    // 0x82ae24: r0 = AllocateClosure()
    //     0x82ae24: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82ae28: ldur            x2, [fp, #-0x10]
    // 0x82ae2c: r1 = Function '_handleScaleUpdate@406395952':.
    //     0x82ae2c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c710] AnonymousClosure: (0x82bb50), in [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_handleScaleUpdate (0x82b228)
    //     0x82ae30: ldr             x1, [x1, #0x710]
    // 0x82ae34: stur            x0, [fp, #-0x10]
    // 0x82ae38: r0 = AllocateClosure()
    //     0x82ae38: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82ae3c: ldur            x16, [fp, #-8]
    // 0x82ae40: ldur            lr, [fp, #-0x10]
    // 0x82ae44: stp             lr, x16, [SP, #-0x10]!
    // 0x82ae48: r16 = Instance_HitTestBehavior
    //     0x82ae48: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!HitTestBehavior@b64931
    //     0x82ae4c: ldr             x16, [x16, #0x780]
    // 0x82ae50: stp             x16, x0, [SP, #-0x10]!
    // 0x82ae54: ldur            x16, [fp, #-0x20]
    // 0x82ae58: SaveReg r16
    //     0x82ae58: str             x16, [SP, #-8]!
    // 0x82ae5c: r4 = const [0, 0x5, 0x5, 0x1, behavior, 0x3, child, 0x4, onScaleStart, 0x1, onScaleUpdate, 0x2, null]
    //     0x82ae5c: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4c718] List(13) [0, 0x5, 0x5, 0x1, "behavior", 0x3, "child", 0x4, "onScaleStart", 0x1, "onScaleUpdate", 0x2, Null]
    //     0x82ae60: ldr             x4, [x4, #0x718]
    // 0x82ae64: r0 = GestureDetector()
    //     0x82ae64: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x82ae68: add             SP, SP, #0x28
    // 0x82ae6c: r1 = 1
    //     0x82ae6c: mov             x1, #1
    // 0x82ae70: r0 = AllocateContext()
    //     0x82ae70: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82ae74: mov             x1, x0
    // 0x82ae78: ldr             x0, [fp, #0x18]
    // 0x82ae7c: stur            x1, [fp, #-0x10]
    // 0x82ae80: StoreField: r1->field_f = r0
    //     0x82ae80: stur            w0, [x1, #0xf]
    // 0x82ae84: LoadField: r2 = r0->field_17
    //     0x82ae84: ldur            w2, [x0, #0x17]
    // 0x82ae88: DecompressPointer r2
    //     0x82ae88: add             x2, x2, HEAP, lsl #32
    // 0x82ae8c: cmp             w2, NULL
    // 0x82ae90: b.eq            #0x82af5c
    // 0x82ae94: r0 = Listener()
    //     0x82ae94: bl              #0x82af60  ; AllocateListenerStub -> Listener (size=0x38)
    // 0x82ae98: ldur            x2, [fp, #-0x28]
    // 0x82ae9c: r1 = Function '<anonymous closure>':.
    //     0x82ae9c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c720] AnonymousClosure: (0x82bae4), in [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::build (0x82ab50)
    //     0x82aea0: ldr             x1, [x1, #0x720]
    // 0x82aea4: stur            x0, [fp, #-0x18]
    // 0x82aea8: r0 = AllocateClosure()
    //     0x82aea8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82aeac: mov             x1, x0
    // 0x82aeb0: ldur            x0, [fp, #-0x18]
    // 0x82aeb4: StoreField: r0->field_f = r1
    //     0x82aeb4: stur            w1, [x0, #0xf]
    // 0x82aeb8: ldur            x2, [fp, #-0x28]
    // 0x82aebc: r1 = Function '<anonymous closure>':.
    //     0x82aebc: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c728] AnonymousClosure: (0x82ba78), in [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::build (0x82ab50)
    //     0x82aec0: ldr             x1, [x1, #0x728]
    // 0x82aec4: r0 = AllocateClosure()
    //     0x82aec4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82aec8: mov             x1, x0
    // 0x82aecc: ldur            x0, [fp, #-0x18]
    // 0x82aed0: StoreField: r0->field_17 = r1
    //     0x82aed0: stur            w1, [x0, #0x17]
    // 0x82aed4: ldur            x2, [fp, #-0x10]
    // 0x82aed8: r1 = Function '_handlePointerSignal@406395952':.
    //     0x82aed8: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c730] AnonymousClosure: (0x82af78), in [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_handlePointerSignal (0x82afc4)
    //     0x82aedc: ldr             x1, [x1, #0x730]
    // 0x82aee0: r0 = AllocateClosure()
    //     0x82aee0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82aee4: mov             x1, x0
    // 0x82aee8: ldur            x0, [fp, #-0x18]
    // 0x82aeec: StoreField: r0->field_2f = r1
    //     0x82aeec: stur            w1, [x0, #0x2f]
    // 0x82aef0: r1 = Instance_HitTestBehavior
    //     0x82aef0: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!HitTestBehavior@b64931
    //     0x82aef4: ldr             x1, [x1, #0x780]
    // 0x82aef8: StoreField: r0->field_33 = r1
    //     0x82aef8: stur            w1, [x0, #0x33]
    // 0x82aefc: ldur            x1, [fp, #-8]
    // 0x82af00: StoreField: r0->field_b = r1
    //     0x82af00: stur            w1, [x0, #0xb]
    // 0x82af04: LeaveFrame
    //     0x82af04: mov             SP, fp
    //     0x82af08: ldp             fp, lr, [SP], #0x10
    // 0x82af0c: ret
    //     0x82af0c: ret             
    // 0x82af10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82af10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82af14: b               #0x82ab68
    // 0x82af18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82af18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82af1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82af1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82af20: SaveReg d0
    //     0x82af20: str             q0, [SP, #-0x10]!
    // 0x82af24: stp             x3, x5, [SP, #-0x10]!
    // 0x82af28: stp             x1, x2, [SP, #-0x10]!
    // 0x82af2c: SaveReg r0
    //     0x82af2c: str             x0, [SP, #-8]!
    // 0x82af30: r0 = AllocateDouble()
    //     0x82af30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82af34: mov             x4, x0
    // 0x82af38: RestoreReg r0
    //     0x82af38: ldr             x0, [SP], #8
    // 0x82af3c: ldp             x1, x2, [SP], #0x10
    // 0x82af40: ldp             x3, x5, [SP], #0x10
    // 0x82af44: RestoreReg d0
    //     0x82af44: ldr             q0, [SP], #0x10
    // 0x82af48: b               #0x82ac04
    // 0x82af4c: r9 = _invertColors
    //     0x82af4c: add             x9, PP, #0x38, lsl #12  ; [pp+0x38510] Field <_ExtendedImageState@408436062._invertColors@408436062>: late (offset: 0x28)
    //     0x82af50: ldr             x9, [x9, #0x510]
    // 0x82af54: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x82af54: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x82af58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82af58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82af5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82af5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handlePointerSignal(dynamic, PointerSignalEvent) {
    // ** addr: 0x82af78, size: 0x4c
    // 0x82af78: EnterFrame
    //     0x82af78: stp             fp, lr, [SP, #-0x10]!
    //     0x82af7c: mov             fp, SP
    // 0x82af80: ldr             x0, [fp, #0x18]
    // 0x82af84: LoadField: r1 = r0->field_17
    //     0x82af84: ldur            w1, [x0, #0x17]
    // 0x82af88: DecompressPointer r1
    //     0x82af88: add             x1, x1, HEAP, lsl #32
    // 0x82af8c: CheckStackOverflow
    //     0x82af8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82af90: cmp             SP, x16
    //     0x82af94: b.ls            #0x82afbc
    // 0x82af98: LoadField: r0 = r1->field_f
    //     0x82af98: ldur            w0, [x1, #0xf]
    // 0x82af9c: DecompressPointer r0
    //     0x82af9c: add             x0, x0, HEAP, lsl #32
    // 0x82afa0: ldr             x16, [fp, #0x10]
    // 0x82afa4: stp             x16, x0, [SP, #-0x10]!
    // 0x82afa8: r0 = _handlePointerSignal()
    //     0x82afa8: bl              #0x82afc4  ; [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_handlePointerSignal
    // 0x82afac: add             SP, SP, #0x10
    // 0x82afb0: LeaveFrame
    //     0x82afb0: mov             SP, fp
    //     0x82afb4: ldp             fp, lr, [SP], #0x10
    // 0x82afb8: ret
    //     0x82afb8: ret             
    // 0x82afbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82afbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82afc0: b               #0x82af98
  }
  _ _handlePointerSignal(/* No info */) {
    // ** addr: 0x82afc4, size: 0x264
    // 0x82afc4: EnterFrame
    //     0x82afc4: stp             fp, lr, [SP, #-0x10]!
    //     0x82afc8: mov             fp, SP
    // 0x82afcc: AllocStack(0x18)
    //     0x82afcc: sub             SP, SP, #0x18
    // 0x82afd0: CheckStackOverflow
    //     0x82afd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82afd4: cmp             SP, x16
    //     0x82afd8: b.ls            #0x82b21c
    // 0x82afdc: ldr             x0, [fp, #0x10]
    // 0x82afe0: r2 = Null
    //     0x82afe0: mov             x2, NULL
    // 0x82afe4: r1 = Null
    //     0x82afe4: mov             x1, NULL
    // 0x82afe8: cmp             w0, NULL
    // 0x82afec: b.eq            #0x82b00c
    // 0x82aff0: branchIfSmi(r0, 0x82b00c)
    //     0x82aff0: tbz             w0, #0, #0x82b00c
    // 0x82aff4: r3 = LoadClassIdInstr(r0)
    //     0x82aff4: ldur            x3, [x0, #-1]
    //     0x82aff8: ubfx            x3, x3, #0xc, #0x14
    // 0x82affc: cmp             x3, #0x904
    // 0x82b000: b.eq            #0x82b014
    // 0x82b004: cmp             x3, #0xb2b
    // 0x82b008: b.eq            #0x82b014
    // 0x82b00c: r0 = false
    //     0x82b00c: add             x0, NULL, #0x30  ; false
    // 0x82b010: b               #0x82b018
    // 0x82b014: r0 = true
    //     0x82b014: add             x0, NULL, #0x20  ; true
    // 0x82b018: tbnz            w0, #4, #0x82b20c
    // 0x82b01c: ldr             x1, [fp, #0x10]
    // 0x82b020: r0 = LoadClassIdInstr(r1)
    //     0x82b020: ldur            x0, [x1, #-1]
    //     0x82b024: ubfx            x0, x0, #0xc, #0x14
    // 0x82b028: SaveReg r1
    //     0x82b028: str             x1, [SP, #-8]!
    // 0x82b02c: r0 = GDT[cid_x0 + -0xf60]()
    //     0x82b02c: sub             lr, x0, #0xf60
    //     0x82b030: ldr             lr, [x21, lr, lsl #3]
    //     0x82b034: blr             lr
    // 0x82b038: add             SP, SP, #8
    // 0x82b03c: r16 = Instance_PointerDeviceKind
    //     0x82b03c: ldr             x16, [PP, #0x3958]  ; [pp+0x3958] Obj!PointerDeviceKind@b67191
    // 0x82b040: cmp             w0, w16
    // 0x82b044: b.ne            #0x82b20c
    // 0x82b048: ldr             x1, [fp, #0x10]
    // 0x82b04c: r0 = LoadClassIdInstr(r1)
    //     0x82b04c: ldur            x0, [x1, #-1]
    //     0x82b050: ubfx            x0, x0, #0xc, #0x14
    // 0x82b054: SaveReg r1
    //     0x82b054: str             x1, [SP, #-8]!
    // 0x82b058: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x82b058: sub             lr, x0, #0xfd9
    //     0x82b05c: ldr             lr, [x21, lr, lsl #3]
    //     0x82b060: blr             lr
    // 0x82b064: add             SP, SP, #8
    // 0x82b068: stur            x0, [fp, #-8]
    // 0x82b06c: r0 = ScaleStartDetails()
    //     0x82b06c: bl              #0x78bd4c  ; AllocateScaleStartDetailsStub -> ScaleStartDetails (size=0x18)
    // 0x82b070: mov             x1, x0
    // 0x82b074: ldur            x0, [fp, #-8]
    // 0x82b078: StoreField: r1->field_7 = r0
    //     0x82b078: stur            w0, [x1, #7]
    // 0x82b07c: r2 = 0
    //     0x82b07c: mov             x2, #0
    // 0x82b080: StoreField: r1->field_f = r2
    //     0x82b080: stur            x2, [x1, #0xf]
    // 0x82b084: StoreField: r1->field_b = r0
    //     0x82b084: stur            w0, [x1, #0xb]
    // 0x82b088: ldr             x16, [fp, #0x18]
    // 0x82b08c: stp             x1, x16, [SP, #-0x10]!
    // 0x82b090: r0 = _handleScaleStart()
    //     0x82b090: bl              #0x82b94c  ; [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_handleScaleStart
    // 0x82b094: add             SP, SP, #0x10
    // 0x82b098: ldr             x1, [fp, #0x10]
    // 0x82b09c: r0 = LoadClassIdInstr(r1)
    //     0x82b09c: ldur            x0, [x1, #-1]
    //     0x82b0a0: ubfx            x0, x0, #0xc, #0x14
    // 0x82b0a4: SaveReg r1
    //     0x82b0a4: str             x1, [SP, #-8]!
    // 0x82b0a8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82b0a8: sub             lr, x0, #1, lsl #12
    //     0x82b0ac: ldr             lr, [x21, lr, lsl #3]
    //     0x82b0b0: blr             lr
    // 0x82b0b4: add             SP, SP, #8
    // 0x82b0b8: LoadField: d0 = r0->field_f
    //     0x82b0b8: ldur            d0, [x0, #0xf]
    // 0x82b0bc: ldr             x1, [fp, #0x10]
    // 0x82b0c0: stur            d0, [fp, #-0x10]
    // 0x82b0c4: r0 = LoadClassIdInstr(r1)
    //     0x82b0c4: ldur            x0, [x1, #-1]
    //     0x82b0c8: ubfx            x0, x0, #0xc, #0x14
    // 0x82b0cc: SaveReg r1
    //     0x82b0cc: str             x1, [SP, #-8]!
    // 0x82b0d0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82b0d0: sub             lr, x0, #1, lsl #12
    //     0x82b0d4: ldr             lr, [x21, lr, lsl #3]
    //     0x82b0d8: blr             lr
    // 0x82b0dc: add             SP, SP, #8
    // 0x82b0e0: LoadField: d0 = r0->field_7
    //     0x82b0e0: ldur            d0, [x0, #7]
    // 0x82b0e4: ldr             x0, [fp, #0x10]
    // 0x82b0e8: stur            d0, [fp, #-0x18]
    // 0x82b0ec: r1 = LoadClassIdInstr(r0)
    //     0x82b0ec: ldur            x1, [x0, #-1]
    //     0x82b0f0: ubfx            x1, x1, #0xc, #0x14
    // 0x82b0f4: SaveReg r0
    //     0x82b0f4: str             x0, [SP, #-8]!
    // 0x82b0f8: mov             x0, x1
    // 0x82b0fc: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x82b0fc: sub             lr, x0, #0xfd9
    //     0x82b100: ldr             lr, [x21, lr, lsl #3]
    //     0x82b104: blr             lr
    // 0x82b108: add             SP, SP, #8
    // 0x82b10c: ldur            d0, [fp, #-0x10]
    // 0x82b110: d1 = 0.000000
    //     0x82b110: eor             v1.16b, v1.16b, v1.16b
    // 0x82b114: stur            x0, [fp, #-8]
    // 0x82b118: fcmp            d0, d1
    // 0x82b11c: b.vs            #0x82b12c
    // 0x82b120: b.ne            #0x82b12c
    // 0x82b124: d3 = 0.000000
    //     0x82b124: eor             v3.16b, v3.16b, v3.16b
    // 0x82b128: b               #0x82b148
    // 0x82b12c: fcmp            d0, d1
    // 0x82b130: b.vs            #0x82b140
    // 0x82b134: b.ge            #0x82b140
    // 0x82b138: fneg            d2, d0
    // 0x82b13c: b               #0x82b144
    // 0x82b140: mov             v2.16b, v0.16b
    // 0x82b144: mov             v3.16b, v2.16b
    // 0x82b148: ldur            d2, [fp, #-0x18]
    // 0x82b14c: fcmp            d2, d1
    // 0x82b150: b.vs            #0x82b160
    // 0x82b154: b.ne            #0x82b160
    // 0x82b158: d4 = 0.000000
    //     0x82b158: eor             v4.16b, v4.16b, v4.16b
    // 0x82b15c: b               #0x82b178
    // 0x82b160: fcmp            d2, d1
    // 0x82b164: b.vs            #0x82b174
    // 0x82b168: b.ge            #0x82b174
    // 0x82b16c: fneg            d4, d2
    // 0x82b170: b               #0x82b178
    // 0x82b174: mov             v4.16b, v2.16b
    // 0x82b178: fcmp            d3, d4
    // 0x82b17c: b.vs            #0x82b18c
    // 0x82b180: b.le            #0x82b18c
    // 0x82b184: mov             v3.16b, v0.16b
    // 0x82b188: b               #0x82b190
    // 0x82b18c: mov             v3.16b, v2.16b
    // 0x82b190: ldr             x1, [fp, #0x18]
    // 0x82b194: d2 = 1.000000
    //     0x82b194: fmov            d2, #1.00000000
    // 0x82b198: d0 = 1000.000000
    //     0x82b198: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0x82b19c: ldr             d0, [x17, #0x3b0]
    // 0x82b1a0: LoadField: r2 = r1->field_17
    //     0x82b1a0: ldur            w2, [x1, #0x17]
    // 0x82b1a4: DecompressPointer r2
    //     0x82b1a4: add             x2, x2, HEAP, lsl #32
    // 0x82b1a8: cmp             w2, NULL
    // 0x82b1ac: b.eq            #0x82b224
    // 0x82b1b0: fdiv            d4, d3, d0
    // 0x82b1b4: fadd            d0, d2, d4
    // 0x82b1b8: stur            d0, [fp, #-0x10]
    // 0x82b1bc: r0 = ScaleUpdateDetails()
    //     0x82b1bc: bl              #0x78c0d8  ; AllocateScaleUpdateDetailsStub -> ScaleUpdateDetails (size=0x3c)
    // 0x82b1c0: mov             x1, x0
    // 0x82b1c4: ldur            x0, [fp, #-8]
    // 0x82b1c8: StoreField: r1->field_b = r0
    //     0x82b1c8: stur            w0, [x1, #0xb]
    // 0x82b1cc: ldur            d0, [fp, #-0x10]
    // 0x82b1d0: StoreField: r1->field_13 = d0
    //     0x82b1d0: stur            d0, [x1, #0x13]
    // 0x82b1d4: d0 = 1.000000
    //     0x82b1d4: fmov            d0, #1.00000000
    // 0x82b1d8: StoreField: r1->field_1b = d0
    //     0x82b1d8: stur            d0, [x1, #0x1b]
    // 0x82b1dc: StoreField: r1->field_23 = d0
    //     0x82b1dc: stur            d0, [x1, #0x23]
    // 0x82b1e0: d0 = 0.000000
    //     0x82b1e0: eor             v0.16b, v0.16b, v0.16b
    // 0x82b1e4: StoreField: r1->field_2b = d0
    //     0x82b1e4: stur            d0, [x1, #0x2b]
    // 0x82b1e8: r2 = 0
    //     0x82b1e8: mov             x2, #0
    // 0x82b1ec: StoreField: r1->field_33 = r2
    //     0x82b1ec: stur            x2, [x1, #0x33]
    // 0x82b1f0: r2 = Instance_Offset
    //     0x82b1f0: ldr             x2, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x82b1f4: StoreField: r1->field_7 = r2
    //     0x82b1f4: stur            w2, [x1, #7]
    // 0x82b1f8: StoreField: r1->field_f = r0
    //     0x82b1f8: stur            w0, [x1, #0xf]
    // 0x82b1fc: ldr             x16, [fp, #0x18]
    // 0x82b200: stp             x1, x16, [SP, #-0x10]!
    // 0x82b204: r0 = _handleScaleUpdate()
    //     0x82b204: bl              #0x82b228  ; [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_handleScaleUpdate
    // 0x82b208: add             SP, SP, #0x10
    // 0x82b20c: r0 = Null
    //     0x82b20c: mov             x0, NULL
    // 0x82b210: LeaveFrame
    //     0x82b210: mov             SP, fp
    //     0x82b214: ldp             fp, lr, [SP], #0x10
    // 0x82b218: ret
    //     0x82b218: ret             
    // 0x82b21c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b21c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b220: b               #0x82afdc
    // 0x82b224: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82b224: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _handleScaleUpdate(/* No info */) {
    // ** addr: 0x82b228, size: 0x54c
    // 0x82b228: EnterFrame
    //     0x82b228: stp             fp, lr, [SP, #-0x10]!
    //     0x82b22c: mov             fp, SP
    // 0x82b230: AllocStack(0x28)
    //     0x82b230: sub             SP, SP, #0x28
    // 0x82b234: CheckStackOverflow
    //     0x82b234: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82b238: cmp             SP, x16
    //     0x82b23c: b.ls            #0x82b6a8
    // 0x82b240: r1 = 3
    //     0x82b240: mov             x1, #3
    // 0x82b244: r0 = AllocateContext()
    //     0x82b244: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82b248: mov             x1, x0
    // 0x82b24c: ldr             x0, [fp, #0x18]
    // 0x82b250: stur            x1, [fp, #-0x10]
    // 0x82b254: StoreField: r1->field_f = r0
    //     0x82b254: stur            w0, [x1, #0xf]
    // 0x82b258: LoadField: r2 = r0->field_2b
    //     0x82b258: ldur            w2, [x0, #0x2b]
    // 0x82b25c: DecompressPointer r2
    //     0x82b25c: add             x2, x2, HEAP, lsl #32
    // 0x82b260: stur            x2, [fp, #-8]
    // 0x82b264: SaveReg r2
    //     0x82b264: str             x2, [SP, #-8]!
    // 0x82b268: r0 = currentState()
    //     0x82b268: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x82b26c: add             SP, SP, #8
    // 0x82b270: cmp             w0, NULL
    // 0x82b274: b.eq            #0x82b6b0
    // 0x82b278: r16 = true
    //     0x82b278: add             x16, NULL, #0x20  ; true
    // 0x82b27c: stp             x16, x0, [SP, #-0x10]!
    // 0x82b280: r0 = pointerDown()
    //     0x82b280: bl              #0x82b7e0  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::pointerDown
    // 0x82b284: add             SP, SP, #0x10
    // 0x82b288: ldur            x16, [fp, #-8]
    // 0x82b28c: SaveReg r16
    //     0x82b28c: str             x16, [SP, #-8]!
    // 0x82b290: r0 = currentState()
    //     0x82b290: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x82b294: add             SP, SP, #8
    // 0x82b298: cmp             w0, NULL
    // 0x82b29c: b.eq            #0x82b6b4
    // 0x82b2a0: SaveReg r0
    //     0x82b2a0: str             x0, [SP, #-8]!
    // 0x82b2a4: r0 = isAnimating()
    //     0x82b2a4: bl              #0x82b774  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::isAnimating
    // 0x82b2a8: add             SP, SP, #8
    // 0x82b2ac: tbz             w0, #4, #0x82b2d8
    // 0x82b2b0: ldur            x16, [fp, #-8]
    // 0x82b2b4: SaveReg r16
    //     0x82b2b4: str             x16, [SP, #-8]!
    // 0x82b2b8: r0 = currentState()
    //     0x82b2b8: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x82b2bc: add             SP, SP, #8
    // 0x82b2c0: cmp             w0, NULL
    // 0x82b2c4: b.eq            #0x82b6b8
    // 0x82b2c8: LoadField: r1 = r0->field_2b
    //     0x82b2c8: ldur            w1, [x0, #0x2b]
    // 0x82b2cc: DecompressPointer r1
    //     0x82b2cc: add             x1, x1, HEAP, lsl #32
    // 0x82b2d0: cmp             w1, NULL
    // 0x82b2d4: b.eq            #0x82b2e8
    // 0x82b2d8: r0 = Null
    //     0x82b2d8: mov             x0, NULL
    // 0x82b2dc: LeaveFrame
    //     0x82b2dc: mov             SP, fp
    //     0x82b2e0: ldp             fp, lr, [SP], #0x10
    // 0x82b2e4: ret
    //     0x82b2e4: ret             
    // 0x82b2e8: ldr             x1, [fp, #0x18]
    // 0x82b2ec: ldr             x3, [fp, #0x10]
    // 0x82b2f0: ldur            x2, [fp, #-0x10]
    // 0x82b2f4: LoadField: r0 = r1->field_1b
    //     0x82b2f4: ldur            w0, [x1, #0x1b]
    // 0x82b2f8: DecompressPointer r0
    //     0x82b2f8: add             x0, x0, HEAP, lsl #32
    // 0x82b2fc: r16 = Sentinel
    //     0x82b2fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82b300: cmp             w0, w16
    // 0x82b304: b.eq            #0x82b6bc
    // 0x82b308: LoadField: d0 = r3->field_13
    //     0x82b308: ldur            d0, [x3, #0x13]
    // 0x82b30c: stur            d0, [fp, #-0x20]
    // 0x82b310: LoadField: d1 = r0->field_7
    //     0x82b310: ldur            d1, [x0, #7]
    // 0x82b314: fmul            d2, d1, d0
    // 0x82b318: LoadField: r0 = r1->field_17
    //     0x82b318: ldur            w0, [x1, #0x17]
    // 0x82b31c: DecompressPointer r0
    //     0x82b31c: add             x0, x0, HEAP, lsl #32
    // 0x82b320: cmp             w0, NULL
    // 0x82b324: b.eq            #0x82b6c8
    // 0x82b328: r0 = inline_Allocate_Double()
    //     0x82b328: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x82b32c: add             x0, x0, #0x10
    //     0x82b330: cmp             x4, x0
    //     0x82b334: b.ls            #0x82b6cc
    //     0x82b338: str             x0, [THR, #0x60]  ; THR::top
    //     0x82b33c: sub             x0, x0, #0xf
    //     0x82b340: mov             x4, #0xd108
    //     0x82b344: movk            x4, #3, lsl #16
    //     0x82b348: stur            x4, [x0, #-1]
    // 0x82b34c: StoreField: r0->field_7 = d2
    //     0x82b34c: stur            d2, [x0, #7]
    // 0x82b350: StoreField: r2->field_13 = r0
    //     0x82b350: stur            w0, [x2, #0x13]
    //     0x82b354: ldurb           w16, [x2, #-1]
    //     0x82b358: ldurb           w17, [x0, #-1]
    //     0x82b35c: and             x16, x17, x16, lsr #2
    //     0x82b360: tst             x16, HEAP, lsr #32
    //     0x82b364: b.eq            #0x82b36c
    //     0x82b368: bl              #0xd6828c
    // 0x82b36c: LoadField: r0 = r3->field_b
    //     0x82b36c: ldur            w0, [x3, #0xb]
    // 0x82b370: DecompressPointer r0
    //     0x82b370: add             x0, x0, HEAP, lsl #32
    // 0x82b374: stur            x0, [fp, #-8]
    // 0x82b378: r16 = 1.000000
    //     0x82b378: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x82b37c: stp             x16, x0, [SP, #-0x10]!
    // 0x82b380: r0 = *()
    //     0x82b380: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x82b384: add             SP, SP, #0x10
    // 0x82b388: mov             x1, x0
    // 0x82b38c: ldr             x0, [fp, #0x18]
    // 0x82b390: LoadField: r2 = r0->field_1f
    //     0x82b390: ldur            w2, [x0, #0x1f]
    // 0x82b394: DecompressPointer r2
    //     0x82b394: add             x2, x2, HEAP, lsl #32
    // 0x82b398: r16 = Sentinel
    //     0x82b398: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82b39c: cmp             w2, w16
    // 0x82b3a0: b.eq            #0x82b6ec
    // 0x82b3a4: stp             x2, x1, [SP, #-0x10]!
    // 0x82b3a8: r0 = -()
    //     0x82b3a8: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x82b3ac: add             SP, SP, #0x10
    // 0x82b3b0: mov             x1, x0
    // 0x82b3b4: ldur            x2, [fp, #-0x10]
    // 0x82b3b8: stur            x1, [fp, #-0x18]
    // 0x82b3bc: StoreField: r2->field_17 = r0
    //     0x82b3bc: stur            w0, [x2, #0x17]
    //     0x82b3c0: ldurb           w16, [x2, #-1]
    //     0x82b3c4: ldurb           w17, [x0, #-1]
    //     0x82b3c8: and             x16, x17, x16, lsr #2
    //     0x82b3cc: tst             x16, HEAP, lsr #32
    //     0x82b3d0: b.eq            #0x82b3d8
    //     0x82b3d4: bl              #0xd6828c
    // 0x82b3d8: ldr             x3, [fp, #0x18]
    // 0x82b3dc: LoadField: d0 = r3->field_23
    //     0x82b3dc: ldur            d0, [x3, #0x23]
    // 0x82b3e0: ldur            d1, [fp, #-0x20]
    // 0x82b3e4: fdiv            d2, d1, d0
    // 0x82b3e8: stur            d2, [fp, #-0x28]
    // 0x82b3ec: StoreField: r3->field_23 = d1
    //     0x82b3ec: stur            d1, [x3, #0x23]
    // 0x82b3f0: ldur            x0, [fp, #-8]
    // 0x82b3f4: StoreField: r3->field_1f = r0
    //     0x82b3f4: stur            w0, [x3, #0x1f]
    //     0x82b3f8: ldurb           w16, [x3, #-1]
    //     0x82b3fc: ldurb           w17, [x0, #-1]
    //     0x82b400: and             x16, x17, x16, lsr #2
    //     0x82b404: tst             x16, HEAP, lsr #32
    //     0x82b408: b.eq            #0x82b410
    //     0x82b40c: bl              #0xd682ac
    // 0x82b410: LoadField: r0 = r3->field_13
    //     0x82b410: ldur            w0, [x3, #0x13]
    // 0x82b414: DecompressPointer r0
    //     0x82b414: add             x0, x0, HEAP, lsl #32
    // 0x82b418: cmp             w0, NULL
    // 0x82b41c: b.eq            #0x82b6f8
    // 0x82b420: LoadField: r4 = r0->field_2b
    //     0x82b420: ldur            w4, [x0, #0x2b]
    // 0x82b424: DecompressPointer r4
    //     0x82b424: add             x4, x4, HEAP, lsl #32
    // 0x82b428: tbnz            w4, #4, #0x82b448
    // 0x82b42c: d0 = 1.000000
    //     0x82b42c: fmov            d0, #1.00000000
    // 0x82b430: fcmp            d2, d0
    // 0x82b434: b.vs            #0x82b44c
    // 0x82b438: b.ge            #0x82b44c
    // 0x82b43c: mov             x1, x3
    // 0x82b440: mov             v0.16b, v1.16b
    // 0x82b444: b               #0x82b4bc
    // 0x82b448: d0 = 1.000000
    //     0x82b448: fmov            d0, #1.00000000
    // 0x82b44c: d3 = 5.000000
    //     0x82b44c: fmov            d3, #5.00000000
    // 0x82b450: LoadField: d4 = r0->field_2f
    //     0x82b450: ldur            d4, [x0, #0x2f]
    // 0x82b454: LoadField: r0 = r3->field_17
    //     0x82b454: ldur            w0, [x3, #0x17]
    // 0x82b458: DecompressPointer r0
    //     0x82b458: add             x0, x0, HEAP, lsl #32
    // 0x82b45c: cmp             w0, NULL
    // 0x82b460: b.eq            #0x82b6fc
    // 0x82b464: r0 = inline_Allocate_Double()
    //     0x82b464: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x82b468: add             x0, x0, #0x10
    //     0x82b46c: cmp             x4, x0
    //     0x82b470: b.ls            #0x82b700
    //     0x82b474: str             x0, [THR, #0x60]  ; THR::top
    //     0x82b478: sub             x0, x0, #0xf
    //     0x82b47c: mov             x4, #0xd108
    //     0x82b480: movk            x4, #3, lsl #16
    //     0x82b484: stur            x4, [x0, #-1]
    // 0x82b488: StoreField: r0->field_7 = d4
    //     0x82b488: stur            d4, [x0, #7]
    // 0x82b48c: SaveReg r0
    //     0x82b48c: str             x0, [SP, #-8]!
    // 0x82b490: SaveReg d3
    //     0x82b490: str             d3, [SP, #-8]!
    // 0x82b494: r0 = DoubleExtension.equalTo()
    //     0x82b494: bl              #0x658bd8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.equalTo
    // 0x82b498: add             SP, SP, #0x10
    // 0x82b49c: tbnz            w0, #4, #0x82b530
    // 0x82b4a0: ldur            d0, [fp, #-0x28]
    // 0x82b4a4: d1 = 1.000000
    //     0x82b4a4: fmov            d1, #1.00000000
    // 0x82b4a8: fcmp            d0, d1
    // 0x82b4ac: b.vs            #0x82b528
    // 0x82b4b0: b.le            #0x82b528
    // 0x82b4b4: ldr             x1, [fp, #0x18]
    // 0x82b4b8: ldur            d0, [fp, #-0x20]
    // 0x82b4bc: LoadField: r0 = r1->field_13
    //     0x82b4bc: ldur            w0, [x1, #0x13]
    // 0x82b4c0: DecompressPointer r0
    //     0x82b4c0: add             x0, x0, HEAP, lsl #32
    // 0x82b4c4: cmp             w0, NULL
    // 0x82b4c8: b.eq            #0x82b730
    // 0x82b4cc: LoadField: d1 = r0->field_2f
    //     0x82b4cc: ldur            d1, [x0, #0x2f]
    // 0x82b4d0: fdiv            d2, d1, d0
    // 0x82b4d4: r0 = inline_Allocate_Double()
    //     0x82b4d4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x82b4d8: add             x0, x0, #0x10
    //     0x82b4dc: cmp             x2, x0
    //     0x82b4e0: b.ls            #0x82b734
    //     0x82b4e4: str             x0, [THR, #0x60]  ; THR::top
    //     0x82b4e8: sub             x0, x0, #0xf
    //     0x82b4ec: mov             x2, #0xd108
    //     0x82b4f0: movk            x2, #3, lsl #16
    //     0x82b4f4: stur            x2, [x0, #-1]
    // 0x82b4f8: StoreField: r0->field_7 = d2
    //     0x82b4f8: stur            d2, [x0, #7]
    // 0x82b4fc: StoreField: r1->field_1b = r0
    //     0x82b4fc: stur            w0, [x1, #0x1b]
    //     0x82b500: ldurb           w16, [x1, #-1]
    //     0x82b504: ldurb           w17, [x0, #-1]
    //     0x82b508: and             x16, x17, x16, lsr #2
    //     0x82b50c: tst             x16, HEAP, lsr #32
    //     0x82b510: b.eq            #0x82b518
    //     0x82b514: bl              #0xd6826c
    // 0x82b518: r0 = Null
    //     0x82b518: mov             x0, NULL
    // 0x82b51c: LeaveFrame
    //     0x82b51c: mov             SP, fp
    //     0x82b520: ldp             fp, lr, [SP], #0x10
    // 0x82b524: ret
    //     0x82b524: ret             
    // 0x82b528: ldr             x1, [fp, #0x18]
    // 0x82b52c: b               #0x82b53c
    // 0x82b530: ldr             x1, [fp, #0x18]
    // 0x82b534: ldur            d0, [fp, #-0x28]
    // 0x82b538: d1 = 1.000000
    //     0x82b538: fmov            d1, #1.00000000
    // 0x82b53c: ldur            x2, [fp, #-0x10]
    // 0x82b540: d2 = 5.000000
    //     0x82b540: fmov            d2, #5.00000000
    // 0x82b544: LoadField: r0 = r2->field_13
    //     0x82b544: ldur            w0, [x2, #0x13]
    // 0x82b548: DecompressPointer r0
    //     0x82b548: add             x0, x0, HEAP, lsl #32
    // 0x82b54c: stur            x0, [fp, #-8]
    // 0x82b550: LoadField: r3 = r1->field_17
    //     0x82b550: ldur            w3, [x1, #0x17]
    // 0x82b554: DecompressPointer r3
    //     0x82b554: add             x3, x3, HEAP, lsl #32
    // 0x82b558: cmp             w3, NULL
    // 0x82b55c: b.eq            #0x82b74c
    // 0x82b560: cmp             w0, NULL
    // 0x82b564: b.eq            #0x82b750
    // 0x82b568: LoadField: d3 = r0->field_7
    //     0x82b568: ldur            d3, [x0, #7]
    // 0x82b56c: fcmp            d3, d2
    // 0x82b570: b.vs            #0x82b584
    // 0x82b574: b.le            #0x82b584
    // 0x82b578: r0 = 5.000000
    //     0x82b578: add             x0, PP, #0x27, lsl #12  ; [pp+0x27190] 5
    //     0x82b57c: ldr             x0, [x0, #0x190]
    // 0x82b580: b               #0x82b624
    // 0x82b584: fcmp            d3, d2
    // 0x82b588: b.vs            #0x82b590
    // 0x82b58c: b.lt            #0x82b624
    // 0x82b590: d4 = 0.000000
    //     0x82b590: eor             v4.16b, v4.16b, v4.16b
    // 0x82b594: fcmp            d3, d4
    // 0x82b598: b.vs            #0x82b5a0
    // 0x82b59c: b.eq            #0x82b5a8
    // 0x82b5a0: r3 = false
    //     0x82b5a0: add             x3, NULL, #0x30  ; false
    // 0x82b5a4: b               #0x82b5ac
    // 0x82b5a8: r3 = true
    //     0x82b5a8: add             x3, NULL, #0x20  ; true
    // 0x82b5ac: tbnz            w3, #4, #0x82b5e8
    // 0x82b5b0: fadd            d4, d3, d2
    // 0x82b5b4: fmul            d5, d4, d3
    // 0x82b5b8: fmul            d3, d5, d2
    // 0x82b5bc: r0 = inline_Allocate_Double()
    //     0x82b5bc: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x82b5c0: add             x0, x0, #0x10
    //     0x82b5c4: cmp             x3, x0
    //     0x82b5c8: b.ls            #0x82b754
    //     0x82b5cc: str             x0, [THR, #0x60]  ; THR::top
    //     0x82b5d0: sub             x0, x0, #0xf
    //     0x82b5d4: mov             x3, #0xd108
    //     0x82b5d8: movk            x3, #3, lsl #16
    //     0x82b5dc: stur            x3, [x0, #-1]
    // 0x82b5e0: StoreField: r0->field_7 = d3
    //     0x82b5e0: stur            d3, [x0, #7]
    // 0x82b5e4: b               #0x82b624
    // 0x82b5e8: tbnz            w3, #4, #0x82b618
    // 0x82b5ec: r16 = 5.000000
    //     0x82b5ec: add             x16, PP, #0x27, lsl #12  ; [pp+0x27190] 5
    //     0x82b5f0: ldr             x16, [x16, #0x190]
    // 0x82b5f4: SaveReg r16
    //     0x82b5f4: str             x16, [SP, #-8]!
    // 0x82b5f8: r0 = isNegative()
    //     0x82b5f8: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x82b5fc: add             SP, SP, #8
    // 0x82b600: tbnz            w0, #4, #0x82b618
    // 0x82b604: ldr             x1, [fp, #0x18]
    // 0x82b608: ldur            x2, [fp, #-0x10]
    // 0x82b60c: r0 = 5.000000
    //     0x82b60c: add             x0, PP, #0x27, lsl #12  ; [pp+0x27190] 5
    //     0x82b610: ldr             x0, [x0, #0x190]
    // 0x82b614: b               #0x82b624
    // 0x82b618: ldur            x0, [fp, #-8]
    // 0x82b61c: ldr             x1, [fp, #0x18]
    // 0x82b620: ldur            x2, [fp, #-0x10]
    // 0x82b624: StoreField: r2->field_13 = r0
    //     0x82b624: stur            w0, [x2, #0x13]
    //     0x82b628: ldurb           w16, [x2, #-1]
    //     0x82b62c: ldurb           w17, [x0, #-1]
    //     0x82b630: and             x16, x17, x16, lsr #2
    //     0x82b634: tst             x16, HEAP, lsr #32
    //     0x82b638: b.eq            #0x82b640
    //     0x82b63c: bl              #0xd6828c
    // 0x82b640: LoadField: r0 = r1->field_f
    //     0x82b640: ldur            w0, [x1, #0xf]
    // 0x82b644: DecompressPointer r0
    //     0x82b644: add             x0, x0, HEAP, lsl #32
    // 0x82b648: cmp             w0, NULL
    // 0x82b64c: b.eq            #0x82b698
    // 0x82b650: ldur            d0, [fp, #-0x28]
    // 0x82b654: d1 = 1.000000
    //     0x82b654: fmov            d1, #1.00000000
    // 0x82b658: fcmp            d0, d1
    // 0x82b65c: b.ne            #0x82b678
    // 0x82b660: ldur            x16, [fp, #-0x18]
    // 0x82b664: r30 = Instance_Offset
    //     0x82b664: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x82b668: stp             lr, x16, [SP, #-0x10]!
    // 0x82b66c: r0 = ==()
    //     0x82b66c: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x82b670: add             SP, SP, #0x10
    // 0x82b674: tbz             w0, #4, #0x82b698
    // 0x82b678: ldur            x2, [fp, #-0x10]
    // 0x82b67c: r1 = Function '<anonymous closure>':.
    //     0x82b67c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c738] AnonymousClosure: (0x82b868), in [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_handleScaleUpdate (0x82b228)
    //     0x82b680: ldr             x1, [x1, #0x738]
    // 0x82b684: r0 = AllocateClosure()
    //     0x82b684: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82b688: ldr             x16, [fp, #0x18]
    // 0x82b68c: stp             x0, x16, [SP, #-0x10]!
    // 0x82b690: r0 = setState()
    //     0x82b690: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82b694: add             SP, SP, #0x10
    // 0x82b698: r0 = Null
    //     0x82b698: mov             x0, NULL
    // 0x82b69c: LeaveFrame
    //     0x82b69c: mov             SP, fp
    //     0x82b6a0: ldp             fp, lr, [SP], #0x10
    // 0x82b6a4: ret
    //     0x82b6a4: ret             
    // 0x82b6a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b6a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b6ac: b               #0x82b240
    // 0x82b6b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82b6b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82b6b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82b6b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82b6b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82b6b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82b6bc: r9 = _startingScale
    //     0x82b6bc: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c740] Field <ExtendedImageEditorState._startingScale@406395952>: late (offset: 0x1c)
    //     0x82b6c0: ldr             x9, [x9, #0x740]
    // 0x82b6c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82b6c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x82b6c8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82b6c8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82b6cc: stp             q0, q2, [SP, #-0x20]!
    // 0x82b6d0: stp             x2, x3, [SP, #-0x10]!
    // 0x82b6d4: SaveReg r1
    //     0x82b6d4: str             x1, [SP, #-8]!
    // 0x82b6d8: r0 = AllocateDouble()
    //     0x82b6d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82b6dc: RestoreReg r1
    //     0x82b6dc: ldr             x1, [SP], #8
    // 0x82b6e0: ldp             x2, x3, [SP], #0x10
    // 0x82b6e4: ldp             q0, q2, [SP], #0x20
    // 0x82b6e8: b               #0x82b34c
    // 0x82b6ec: r9 = _startingOffset
    //     0x82b6ec: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c748] Field <ExtendedImageEditorState._startingOffset@406395952>: late (offset: 0x20)
    //     0x82b6f0: ldr             x9, [x9, #0x748]
    // 0x82b6f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82b6f4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x82b6f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82b6f8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82b6fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82b6fc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82b700: stp             q3, q4, [SP, #-0x20]!
    // 0x82b704: stp             q1, q2, [SP, #-0x20]!
    // 0x82b708: SaveReg d0
    //     0x82b708: str             q0, [SP, #-0x10]!
    // 0x82b70c: stp             x2, x3, [SP, #-0x10]!
    // 0x82b710: SaveReg r1
    //     0x82b710: str             x1, [SP, #-8]!
    // 0x82b714: r0 = AllocateDouble()
    //     0x82b714: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82b718: RestoreReg r1
    //     0x82b718: ldr             x1, [SP], #8
    // 0x82b71c: ldp             x2, x3, [SP], #0x10
    // 0x82b720: RestoreReg d0
    //     0x82b720: ldr             q0, [SP], #0x10
    // 0x82b724: ldp             q1, q2, [SP], #0x20
    // 0x82b728: ldp             q3, q4, [SP], #0x20
    // 0x82b72c: b               #0x82b488
    // 0x82b730: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82b730: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82b734: SaveReg d2
    //     0x82b734: str             q2, [SP, #-0x10]!
    // 0x82b738: SaveReg r1
    //     0x82b738: str             x1, [SP, #-8]!
    // 0x82b73c: r0 = AllocateDouble()
    //     0x82b73c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82b740: RestoreReg r1
    //     0x82b740: ldr             x1, [SP], #8
    // 0x82b744: RestoreReg d2
    //     0x82b744: ldr             q2, [SP], #0x10
    // 0x82b748: b               #0x82b4f8
    // 0x82b74c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82b74c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82b750: r0 = NullErrorSharedWithFPURegs()
    //     0x82b750: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x82b754: stp             q1, q3, [SP, #-0x20]!
    // 0x82b758: SaveReg d0
    //     0x82b758: str             q0, [SP, #-0x10]!
    // 0x82b75c: stp             x1, x2, [SP, #-0x10]!
    // 0x82b760: r0 = AllocateDouble()
    //     0x82b760: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82b764: ldp             x1, x2, [SP], #0x10
    // 0x82b768: RestoreReg d0
    //     0x82b768: ldr             q0, [SP], #0x10
    // 0x82b76c: ldp             q1, q3, [SP], #0x20
    // 0x82b770: b               #0x82b5e0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82b868, size: 0xe4
    // 0x82b868: EnterFrame
    //     0x82b868: stp             fp, lr, [SP, #-0x10]!
    //     0x82b86c: mov             fp, SP
    // 0x82b870: AllocStack(0x10)
    //     0x82b870: sub             SP, SP, #0x10
    // 0x82b874: SetupParameters()
    //     0x82b874: ldr             x0, [fp, #0x10]
    //     0x82b878: ldur            w1, [x0, #0x17]
    //     0x82b87c: add             x1, x1, HEAP, lsl #32
    //     0x82b880: stur            x1, [fp, #-0x10]
    // 0x82b884: CheckStackOverflow
    //     0x82b884: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82b888: cmp             SP, x16
    //     0x82b88c: b.ls            #0x82b930
    // 0x82b890: LoadField: r0 = r1->field_f
    //     0x82b890: ldur            w0, [x1, #0xf]
    // 0x82b894: DecompressPointer r0
    //     0x82b894: add             x0, x0, HEAP, lsl #32
    // 0x82b898: LoadField: r2 = r0->field_13
    //     0x82b898: ldur            w2, [x0, #0x13]
    // 0x82b89c: DecompressPointer r2
    //     0x82b89c: add             x2, x2, HEAP, lsl #32
    // 0x82b8a0: stur            x2, [fp, #-8]
    // 0x82b8a4: cmp             w2, NULL
    // 0x82b8a8: b.eq            #0x82b938
    // 0x82b8ac: LoadField: r0 = r1->field_13
    //     0x82b8ac: ldur            w0, [x1, #0x13]
    // 0x82b8b0: DecompressPointer r0
    //     0x82b8b0: add             x0, x0, HEAP, lsl #32
    // 0x82b8b4: LoadField: d0 = r0->field_7
    //     0x82b8b4: ldur            d0, [x0, #7]
    // 0x82b8b8: StoreField: r2->field_2f = d0
    //     0x82b8b8: stur            d0, [x2, #0x2f]
    // 0x82b8bc: LoadField: r0 = r2->field_3f
    //     0x82b8bc: ldur            w0, [x2, #0x3f]
    // 0x82b8c0: DecompressPointer r0
    //     0x82b8c0: add             x0, x0, HEAP, lsl #32
    // 0x82b8c4: r16 = Sentinel
    //     0x82b8c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82b8c8: cmp             w0, w16
    // 0x82b8cc: b.eq            #0x82b93c
    // 0x82b8d0: LoadField: r3 = r1->field_17
    //     0x82b8d0: ldur            w3, [x1, #0x17]
    // 0x82b8d4: DecompressPointer r3
    //     0x82b8d4: add             x3, x3, HEAP, lsl #32
    // 0x82b8d8: stp             x3, x0, [SP, #-0x10]!
    // 0x82b8dc: r0 = +()
    //     0x82b8dc: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x82b8e0: add             SP, SP, #0x10
    // 0x82b8e4: ldur            x1, [fp, #-8]
    // 0x82b8e8: StoreField: r1->field_3f = r0
    //     0x82b8e8: stur            w0, [x1, #0x3f]
    //     0x82b8ec: ldurb           w16, [x1, #-1]
    //     0x82b8f0: ldurb           w17, [x0, #-1]
    //     0x82b8f4: and             x16, x17, x16, lsr #2
    //     0x82b8f8: tst             x16, HEAP, lsr #32
    //     0x82b8fc: b.eq            #0x82b904
    //     0x82b900: bl              #0xd6826c
    // 0x82b904: ldur            x1, [fp, #-0x10]
    // 0x82b908: LoadField: r2 = r1->field_f
    //     0x82b908: ldur            w2, [x1, #0xf]
    // 0x82b90c: DecompressPointer r2
    //     0x82b90c: add             x2, x2, HEAP, lsl #32
    // 0x82b910: LoadField: r1 = r2->field_17
    //     0x82b910: ldur            w1, [x2, #0x17]
    // 0x82b914: DecompressPointer r1
    //     0x82b914: add             x1, x1, HEAP, lsl #32
    // 0x82b918: cmp             w1, NULL
    // 0x82b91c: b.eq            #0x82b948
    // 0x82b920: r0 = Null
    //     0x82b920: mov             x0, NULL
    // 0x82b924: LeaveFrame
    //     0x82b924: mov             SP, fp
    //     0x82b928: ldp             fp, lr, [SP], #0x10
    // 0x82b92c: ret
    //     0x82b92c: ret             
    // 0x82b930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b930: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b934: b               #0x82b890
    // 0x82b938: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82b938: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82b93c: r9 = delta
    //     0x82b93c: add             x9, PP, #0x38, lsl #12  ; [pp+0x38480] Field <EditActionDetails.delta>: late (offset: 0x40)
    //     0x82b940: ldr             x9, [x9, #0x480]
    // 0x82b944: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82b944: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x82b948: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82b948: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleScaleStart(/* No info */) {
    // ** addr: 0x82b94c, size: 0x12c
    // 0x82b94c: EnterFrame
    //     0x82b94c: stp             fp, lr, [SP, #-0x10]!
    //     0x82b950: mov             fp, SP
    // 0x82b954: CheckStackOverflow
    //     0x82b954: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82b958: cmp             SP, x16
    //     0x82b95c: b.ls            #0x82ba50
    // 0x82b960: ldr             x0, [fp, #0x18]
    // 0x82b964: LoadField: r1 = r0->field_2b
    //     0x82b964: ldur            w1, [x0, #0x2b]
    // 0x82b968: DecompressPointer r1
    //     0x82b968: add             x1, x1, HEAP, lsl #32
    // 0x82b96c: SaveReg r1
    //     0x82b96c: str             x1, [SP, #-8]!
    // 0x82b970: r0 = currentState()
    //     0x82b970: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x82b974: add             SP, SP, #8
    // 0x82b978: cmp             w0, NULL
    // 0x82b97c: b.eq            #0x82ba58
    // 0x82b980: r16 = true
    //     0x82b980: add             x16, NULL, #0x20  ; true
    // 0x82b984: stp             x16, x0, [SP, #-0x10]!
    // 0x82b988: r0 = pointerDown()
    //     0x82b988: bl              #0x82b7e0  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::pointerDown
    // 0x82b98c: add             SP, SP, #0x10
    // 0x82b990: ldr             x1, [fp, #0x10]
    // 0x82b994: LoadField: r2 = r1->field_7
    //     0x82b994: ldur            w2, [x1, #7]
    // 0x82b998: DecompressPointer r2
    //     0x82b998: add             x2, x2, HEAP, lsl #32
    // 0x82b99c: mov             x0, x2
    // 0x82b9a0: ldr             x1, [fp, #0x18]
    // 0x82b9a4: StoreField: r1->field_1f = r0
    //     0x82b9a4: stur            w0, [x1, #0x1f]
    //     0x82b9a8: ldurb           w16, [x1, #-1]
    //     0x82b9ac: ldurb           w17, [x0, #-1]
    //     0x82b9b0: and             x16, x17, x16, lsr #2
    //     0x82b9b4: tst             x16, HEAP, lsr #32
    //     0x82b9b8: b.eq            #0x82b9c0
    //     0x82b9bc: bl              #0xd6826c
    // 0x82b9c0: LoadField: r3 = r1->field_13
    //     0x82b9c0: ldur            w3, [x1, #0x13]
    // 0x82b9c4: DecompressPointer r3
    //     0x82b9c4: add             x3, x3, HEAP, lsl #32
    // 0x82b9c8: cmp             w3, NULL
    // 0x82b9cc: b.eq            #0x82ba5c
    // 0x82b9d0: mov             x0, x2
    // 0x82b9d4: StoreField: r3->field_43 = r0
    //     0x82b9d4: stur            w0, [x3, #0x43]
    //     0x82b9d8: ldurb           w16, [x3, #-1]
    //     0x82b9dc: ldurb           w17, [x0, #-1]
    //     0x82b9e0: and             x16, x17, x16, lsr #2
    //     0x82b9e4: tst             x16, HEAP, lsr #32
    //     0x82b9e8: b.eq            #0x82b9f0
    //     0x82b9ec: bl              #0xd682ac
    // 0x82b9f0: LoadField: d0 = r3->field_2f
    //     0x82b9f0: ldur            d0, [x3, #0x2f]
    // 0x82b9f4: r0 = inline_Allocate_Double()
    //     0x82b9f4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x82b9f8: add             x0, x0, #0x10
    //     0x82b9fc: cmp             x2, x0
    //     0x82ba00: b.ls            #0x82ba60
    //     0x82ba04: str             x0, [THR, #0x60]  ; THR::top
    //     0x82ba08: sub             x0, x0, #0xf
    //     0x82ba0c: mov             x2, #0xd108
    //     0x82ba10: movk            x2, #3, lsl #16
    //     0x82ba14: stur            x2, [x0, #-1]
    // 0x82ba18: StoreField: r0->field_7 = d0
    //     0x82ba18: stur            d0, [x0, #7]
    // 0x82ba1c: StoreField: r1->field_1b = r0
    //     0x82ba1c: stur            w0, [x1, #0x1b]
    //     0x82ba20: ldurb           w16, [x1, #-1]
    //     0x82ba24: ldurb           w17, [x0, #-1]
    //     0x82ba28: and             x16, x17, x16, lsr #2
    //     0x82ba2c: tst             x16, HEAP, lsr #32
    //     0x82ba30: b.eq            #0x82ba38
    //     0x82ba34: bl              #0xd6826c
    // 0x82ba38: d0 = 1.000000
    //     0x82ba38: fmov            d0, #1.00000000
    // 0x82ba3c: StoreField: r1->field_23 = d0
    //     0x82ba3c: stur            d0, [x1, #0x23]
    // 0x82ba40: r0 = Null
    //     0x82ba40: mov             x0, NULL
    // 0x82ba44: LeaveFrame
    //     0x82ba44: mov             SP, fp
    //     0x82ba48: ldp             fp, lr, [SP], #0x10
    // 0x82ba4c: ret
    //     0x82ba4c: ret             
    // 0x82ba50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ba50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ba54: b               #0x82b960
    // 0x82ba58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82ba58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82ba5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82ba5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82ba60: SaveReg d0
    //     0x82ba60: str             q0, [SP, #-0x10]!
    // 0x82ba64: SaveReg r1
    //     0x82ba64: str             x1, [SP, #-8]!
    // 0x82ba68: r0 = AllocateDouble()
    //     0x82ba68: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82ba6c: RestoreReg r1
    //     0x82ba6c: ldr             x1, [SP], #8
    // 0x82ba70: RestoreReg d0
    //     0x82ba70: ldr             q0, [SP], #0x10
    // 0x82ba74: b               #0x82ba18
  }
  [closure] void <anonymous closure>(dynamic, PointerUpEvent) {
    // ** addr: 0x82ba78, size: 0x6c
    // 0x82ba78: EnterFrame
    //     0x82ba78: stp             fp, lr, [SP, #-0x10]!
    //     0x82ba7c: mov             fp, SP
    // 0x82ba80: ldr             x0, [fp, #0x18]
    // 0x82ba84: LoadField: r1 = r0->field_17
    //     0x82ba84: ldur            w1, [x0, #0x17]
    // 0x82ba88: DecompressPointer r1
    //     0x82ba88: add             x1, x1, HEAP, lsl #32
    // 0x82ba8c: CheckStackOverflow
    //     0x82ba8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82ba90: cmp             SP, x16
    //     0x82ba94: b.ls            #0x82badc
    // 0x82ba98: LoadField: r0 = r1->field_f
    //     0x82ba98: ldur            w0, [x1, #0xf]
    // 0x82ba9c: DecompressPointer r0
    //     0x82ba9c: add             x0, x0, HEAP, lsl #32
    // 0x82baa0: LoadField: r1 = r0->field_2b
    //     0x82baa0: ldur            w1, [x0, #0x2b]
    // 0x82baa4: DecompressPointer r1
    //     0x82baa4: add             x1, x1, HEAP, lsl #32
    // 0x82baa8: SaveReg r1
    //     0x82baa8: str             x1, [SP, #-8]!
    // 0x82baac: r0 = currentState()
    //     0x82baac: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x82bab0: add             SP, SP, #8
    // 0x82bab4: cmp             w0, NULL
    // 0x82bab8: b.eq            #0x82bacc
    // 0x82babc: r16 = false
    //     0x82babc: add             x16, NULL, #0x30  ; false
    // 0x82bac0: stp             x16, x0, [SP, #-0x10]!
    // 0x82bac4: r0 = pointerDown()
    //     0x82bac4: bl              #0x82b7e0  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::pointerDown
    // 0x82bac8: add             SP, SP, #0x10
    // 0x82bacc: r0 = Null
    //     0x82bacc: mov             x0, NULL
    // 0x82bad0: LeaveFrame
    //     0x82bad0: mov             SP, fp
    //     0x82bad4: ldp             fp, lr, [SP], #0x10
    // 0x82bad8: ret
    //     0x82bad8: ret             
    // 0x82badc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82badc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bae0: b               #0x82ba98
  }
  [closure] void <anonymous closure>(dynamic, PointerDownEvent) {
    // ** addr: 0x82bae4, size: 0x6c
    // 0x82bae4: EnterFrame
    //     0x82bae4: stp             fp, lr, [SP, #-0x10]!
    //     0x82bae8: mov             fp, SP
    // 0x82baec: ldr             x0, [fp, #0x18]
    // 0x82baf0: LoadField: r1 = r0->field_17
    //     0x82baf0: ldur            w1, [x0, #0x17]
    // 0x82baf4: DecompressPointer r1
    //     0x82baf4: add             x1, x1, HEAP, lsl #32
    // 0x82baf8: CheckStackOverflow
    //     0x82baf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82bafc: cmp             SP, x16
    //     0x82bb00: b.ls            #0x82bb48
    // 0x82bb04: LoadField: r0 = r1->field_f
    //     0x82bb04: ldur            w0, [x1, #0xf]
    // 0x82bb08: DecompressPointer r0
    //     0x82bb08: add             x0, x0, HEAP, lsl #32
    // 0x82bb0c: LoadField: r1 = r0->field_2b
    //     0x82bb0c: ldur            w1, [x0, #0x2b]
    // 0x82bb10: DecompressPointer r1
    //     0x82bb10: add             x1, x1, HEAP, lsl #32
    // 0x82bb14: SaveReg r1
    //     0x82bb14: str             x1, [SP, #-8]!
    // 0x82bb18: r0 = currentState()
    //     0x82bb18: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x82bb1c: add             SP, SP, #8
    // 0x82bb20: cmp             w0, NULL
    // 0x82bb24: b.eq            #0x82bb38
    // 0x82bb28: r16 = true
    //     0x82bb28: add             x16, NULL, #0x20  ; true
    // 0x82bb2c: stp             x16, x0, [SP, #-0x10]!
    // 0x82bb30: r0 = pointerDown()
    //     0x82bb30: bl              #0x82b7e0  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::pointerDown
    // 0x82bb34: add             SP, SP, #0x10
    // 0x82bb38: r0 = Null
    //     0x82bb38: mov             x0, NULL
    // 0x82bb3c: LeaveFrame
    //     0x82bb3c: mov             SP, fp
    //     0x82bb40: ldp             fp, lr, [SP], #0x10
    // 0x82bb44: ret
    //     0x82bb44: ret             
    // 0x82bb48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82bb48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bb4c: b               #0x82bb04
  }
  [closure] void _handleScaleUpdate(dynamic, ScaleUpdateDetails) {
    // ** addr: 0x82bb50, size: 0x4c
    // 0x82bb50: EnterFrame
    //     0x82bb50: stp             fp, lr, [SP, #-0x10]!
    //     0x82bb54: mov             fp, SP
    // 0x82bb58: ldr             x0, [fp, #0x18]
    // 0x82bb5c: LoadField: r1 = r0->field_17
    //     0x82bb5c: ldur            w1, [x0, #0x17]
    // 0x82bb60: DecompressPointer r1
    //     0x82bb60: add             x1, x1, HEAP, lsl #32
    // 0x82bb64: CheckStackOverflow
    //     0x82bb64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82bb68: cmp             SP, x16
    //     0x82bb6c: b.ls            #0x82bb94
    // 0x82bb70: LoadField: r0 = r1->field_f
    //     0x82bb70: ldur            w0, [x1, #0xf]
    // 0x82bb74: DecompressPointer r0
    //     0x82bb74: add             x0, x0, HEAP, lsl #32
    // 0x82bb78: ldr             x16, [fp, #0x10]
    // 0x82bb7c: stp             x16, x0, [SP, #-0x10]!
    // 0x82bb80: r0 = _handleScaleUpdate()
    //     0x82bb80: bl              #0x82b228  ; [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_handleScaleUpdate
    // 0x82bb84: add             SP, SP, #0x10
    // 0x82bb88: LeaveFrame
    //     0x82bb88: mov             SP, fp
    //     0x82bb8c: ldp             fp, lr, [SP], #0x10
    // 0x82bb90: ret
    //     0x82bb90: ret             
    // 0x82bb94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82bb94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bb98: b               #0x82bb70
  }
  [closure] void _handleScaleStart(dynamic, ScaleStartDetails) {
    // ** addr: 0x82bb9c, size: 0x4c
    // 0x82bb9c: EnterFrame
    //     0x82bb9c: stp             fp, lr, [SP, #-0x10]!
    //     0x82bba0: mov             fp, SP
    // 0x82bba4: ldr             x0, [fp, #0x18]
    // 0x82bba8: LoadField: r1 = r0->field_17
    //     0x82bba8: ldur            w1, [x0, #0x17]
    // 0x82bbac: DecompressPointer r1
    //     0x82bbac: add             x1, x1, HEAP, lsl #32
    // 0x82bbb0: CheckStackOverflow
    //     0x82bbb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82bbb4: cmp             SP, x16
    //     0x82bbb8: b.ls            #0x82bbe0
    // 0x82bbbc: LoadField: r0 = r1->field_f
    //     0x82bbbc: ldur            w0, [x1, #0xf]
    // 0x82bbc0: DecompressPointer r0
    //     0x82bbc0: add             x0, x0, HEAP, lsl #32
    // 0x82bbc4: ldr             x16, [fp, #0x10]
    // 0x82bbc8: stp             x16, x0, [SP, #-0x10]!
    // 0x82bbcc: r0 = _handleScaleStart()
    //     0x82bbcc: bl              #0x82b94c  ; [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_handleScaleStart
    // 0x82bbd0: add             SP, SP, #0x10
    // 0x82bbd4: LeaveFrame
    //     0x82bbd4: mov             SP, fp
    //     0x82bbd8: ldp             fp, lr, [SP], #0x10
    // 0x82bbdc: ret
    //     0x82bbdc: ret             
    // 0x82bbe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82bbe0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bbe4: b               #0x82bbbc
  }
  [closure] ExtendedImageCropLayer <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0x82bbe8, size: 0x390
    // 0x82bbe8: EnterFrame
    //     0x82bbe8: stp             fp, lr, [SP, #-0x10]!
    //     0x82bbec: mov             fp, SP
    // 0x82bbf0: AllocStack(0x30)
    //     0x82bbf0: sub             SP, SP, #0x30
    // 0x82bbf4: SetupParameters()
    //     0x82bbf4: ldr             x0, [fp, #0x20]
    //     0x82bbf8: ldur            w1, [x0, #0x17]
    //     0x82bbfc: add             x1, x1, HEAP, lsl #32
    //     0x82bc00: stur            x1, [fp, #-8]
    // 0x82bc04: CheckStackOverflow
    //     0x82bc04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82bc08: cmp             SP, x16
    //     0x82bc0c: b.ls            #0x82bf18
    // 0x82bc10: ldr             x0, [fp, #0x10]
    // 0x82bc14: LoadField: d0 = r0->field_f
    //     0x82bc14: ldur            d0, [x0, #0xf]
    // 0x82bc18: stur            d0, [fp, #-0x30]
    // 0x82bc1c: LoadField: d1 = r0->field_1f
    //     0x82bc1c: ldur            d1, [x0, #0x1f]
    // 0x82bc20: stur            d1, [fp, #-0x28]
    // 0x82bc24: r0 = Size()
    //     0x82bc24: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x82bc28: ldur            d0, [fp, #-0x30]
    // 0x82bc2c: StoreField: r0->field_7 = d0
    //     0x82bc2c: stur            d0, [x0, #7]
    // 0x82bc30: ldur            d0, [fp, #-0x28]
    // 0x82bc34: StoreField: r0->field_f = d0
    //     0x82bc34: stur            d0, [x0, #0xf]
    // 0x82bc38: r16 = Instance_Offset
    //     0x82bc38: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x82bc3c: stp             x0, x16, [SP, #-0x10]!
    // 0x82bc40: r0 = &()
    //     0x82bc40: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x82bc44: add             SP, SP, #0x10
    // 0x82bc48: mov             x1, x0
    // 0x82bc4c: ldur            x0, [fp, #-8]
    // 0x82bc50: LoadField: r2 = r0->field_f
    //     0x82bc50: ldur            w2, [x0, #0xf]
    // 0x82bc54: DecompressPointer r2
    //     0x82bc54: add             x2, x2, HEAP, lsl #32
    // 0x82bc58: LoadField: r3 = r2->field_17
    //     0x82bc58: ldur            w3, [x2, #0x17]
    // 0x82bc5c: DecompressPointer r3
    //     0x82bc5c: add             x3, x3, HEAP, lsl #32
    // 0x82bc60: cmp             w3, NULL
    // 0x82bc64: b.eq            #0x82bf20
    // 0x82bc68: r16 = Instance_EdgeInsets
    //     0x82bc68: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f290] Obj!EdgeInsets@b35a21
    //     0x82bc6c: ldr             x16, [x16, #0x290]
    // 0x82bc70: stp             x1, x16, [SP, #-0x10]!
    // 0x82bc74: r0 = deflateRect()
    //     0x82bc74: bl              #0x65ae60  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRect
    // 0x82bc78: add             SP, SP, #0x10
    // 0x82bc7c: mov             x3, x0
    // 0x82bc80: ldur            x2, [fp, #-8]
    // 0x82bc84: stur            x3, [fp, #-0x10]
    // 0x82bc88: LoadField: r0 = r2->field_f
    //     0x82bc88: ldur            w0, [x2, #0xf]
    // 0x82bc8c: DecompressPointer r0
    //     0x82bc8c: add             x0, x0, HEAP, lsl #32
    // 0x82bc90: LoadField: r1 = r0->field_13
    //     0x82bc90: ldur            w1, [x0, #0x13]
    // 0x82bc94: DecompressPointer r1
    //     0x82bc94: add             x1, x1, HEAP, lsl #32
    // 0x82bc98: cmp             w1, NULL
    // 0x82bc9c: b.eq            #0x82bf24
    // 0x82bca0: LoadField: r4 = r1->field_4b
    //     0x82bca0: ldur            w4, [x1, #0x4b]
    // 0x82bca4: DecompressPointer r4
    //     0x82bca4: add             x4, x4, HEAP, lsl #32
    // 0x82bca8: cmp             w4, NULL
    // 0x82bcac: b.ne            #0x82beb0
    // 0x82bcb0: LoadField: r1 = r0->field_b
    //     0x82bcb0: ldur            w1, [x0, #0xb]
    // 0x82bcb4: DecompressPointer r1
    //     0x82bcb4: add             x1, x1, HEAP, lsl #32
    // 0x82bcb8: cmp             w1, NULL
    // 0x82bcbc: b.eq            #0x82bf28
    // 0x82bcc0: LoadField: r0 = r1->field_b
    //     0x82bcc0: ldur            w0, [x1, #0xb]
    // 0x82bcc4: DecompressPointer r0
    //     0x82bcc4: add             x0, x0, HEAP, lsl #32
    // 0x82bcc8: LoadField: r1 = r0->field_b
    //     0x82bcc8: ldur            w1, [x0, #0xb]
    // 0x82bccc: DecompressPointer r1
    //     0x82bccc: add             x1, x1, HEAP, lsl #32
    // 0x82bcd0: cmp             w1, NULL
    // 0x82bcd4: b.eq            #0x82bf2c
    // 0x82bcd8: LoadField: r1 = r0->field_1f
    //     0x82bcd8: ldur            w1, [x0, #0x1f]
    // 0x82bcdc: DecompressPointer r1
    //     0x82bcdc: add             x1, x1, HEAP, lsl #32
    // 0x82bce0: cmp             w1, NULL
    // 0x82bce4: b.eq            #0x82bf30
    // 0x82bce8: LoadField: r0 = r1->field_7
    //     0x82bce8: ldur            w0, [x1, #7]
    // 0x82bcec: DecompressPointer r0
    //     0x82bcec: add             x0, x0, HEAP, lsl #32
    // 0x82bcf0: LoadField: r4 = r0->field_f
    //     0x82bcf0: ldur            x4, [x0, #0xf]
    // 0x82bcf4: r0 = BoxInt64Instr(r4)
    //     0x82bcf4: sbfiz           x0, x4, #1, #0x1f
    //     0x82bcf8: cmp             x4, x0, asr #1
    //     0x82bcfc: b.eq            #0x82bd08
    //     0x82bd00: bl              #0xd69bb8
    //     0x82bd04: stur            x4, [x0, #7]
    // 0x82bd08: stp             x0, NULL, [SP, #-0x10]!
    // 0x82bd0c: r0 = _Double.fromInteger()
    //     0x82bd0c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x82bd10: add             SP, SP, #0x10
    // 0x82bd14: mov             x3, x0
    // 0x82bd18: ldur            x2, [fp, #-8]
    // 0x82bd1c: stur            x3, [fp, #-0x18]
    // 0x82bd20: LoadField: r0 = r2->field_f
    //     0x82bd20: ldur            w0, [x2, #0xf]
    // 0x82bd24: DecompressPointer r0
    //     0x82bd24: add             x0, x0, HEAP, lsl #32
    // 0x82bd28: LoadField: r1 = r0->field_b
    //     0x82bd28: ldur            w1, [x0, #0xb]
    // 0x82bd2c: DecompressPointer r1
    //     0x82bd2c: add             x1, x1, HEAP, lsl #32
    // 0x82bd30: cmp             w1, NULL
    // 0x82bd34: b.eq            #0x82bf34
    // 0x82bd38: LoadField: r0 = r1->field_b
    //     0x82bd38: ldur            w0, [x1, #0xb]
    // 0x82bd3c: DecompressPointer r0
    //     0x82bd3c: add             x0, x0, HEAP, lsl #32
    // 0x82bd40: LoadField: r1 = r0->field_1f
    //     0x82bd40: ldur            w1, [x0, #0x1f]
    // 0x82bd44: DecompressPointer r1
    //     0x82bd44: add             x1, x1, HEAP, lsl #32
    // 0x82bd48: cmp             w1, NULL
    // 0x82bd4c: b.eq            #0x82bf38
    // 0x82bd50: LoadField: r0 = r1->field_7
    //     0x82bd50: ldur            w0, [x1, #7]
    // 0x82bd54: DecompressPointer r0
    //     0x82bd54: add             x0, x0, HEAP, lsl #32
    // 0x82bd58: LoadField: r4 = r0->field_17
    //     0x82bd58: ldur            x4, [x0, #0x17]
    // 0x82bd5c: r0 = BoxInt64Instr(r4)
    //     0x82bd5c: sbfiz           x0, x4, #1, #0x1f
    //     0x82bd60: cmp             x4, x0, asr #1
    //     0x82bd64: b.eq            #0x82bd70
    //     0x82bd68: bl              #0xd69bb8
    //     0x82bd6c: stur            x4, [x0, #7]
    // 0x82bd70: stp             x0, NULL, [SP, #-0x10]!
    // 0x82bd74: r0 = _Double.fromInteger()
    //     0x82bd74: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x82bd78: add             SP, SP, #0x10
    // 0x82bd7c: mov             x1, x0
    // 0x82bd80: ldur            x0, [fp, #-0x18]
    // 0x82bd84: stur            x1, [fp, #-0x20]
    // 0x82bd88: LoadField: d0 = r0->field_7
    //     0x82bd88: ldur            d0, [x0, #7]
    // 0x82bd8c: stur            d0, [fp, #-0x28]
    // 0x82bd90: r0 = Size()
    //     0x82bd90: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x82bd94: ldur            d0, [fp, #-0x28]
    // 0x82bd98: StoreField: r0->field_7 = d0
    //     0x82bd98: stur            d0, [x0, #7]
    // 0x82bd9c: ldur            x1, [fp, #-0x20]
    // 0x82bda0: LoadField: d0 = r1->field_7
    //     0x82bda0: ldur            d0, [x1, #7]
    // 0x82bda4: StoreField: r0->field_f = d0
    //     0x82bda4: stur            d0, [x0, #0xf]
    // 0x82bda8: ldur            x1, [fp, #-8]
    // 0x82bdac: LoadField: r2 = r1->field_f
    //     0x82bdac: ldur            w2, [x1, #0xf]
    // 0x82bdb0: DecompressPointer r2
    //     0x82bdb0: add             x2, x2, HEAP, lsl #32
    // 0x82bdb4: LoadField: r3 = r2->field_b
    //     0x82bdb4: ldur            w3, [x2, #0xb]
    // 0x82bdb8: DecompressPointer r3
    //     0x82bdb8: add             x3, x3, HEAP, lsl #32
    // 0x82bdbc: cmp             w3, NULL
    // 0x82bdc0: b.eq            #0x82bf3c
    // 0x82bdc4: LoadField: r2 = r3->field_b
    //     0x82bdc4: ldur            w2, [x3, #0xb]
    // 0x82bdc8: DecompressPointer r2
    //     0x82bdc8: add             x2, x2, HEAP, lsl #32
    // 0x82bdcc: LoadField: r3 = r2->field_b
    //     0x82bdcc: ldur            w3, [x2, #0xb]
    // 0x82bdd0: DecompressPointer r3
    //     0x82bdd0: add             x3, x3, HEAP, lsl #32
    // 0x82bdd4: cmp             w3, NULL
    // 0x82bdd8: b.eq            #0x82bf40
    // 0x82bddc: LoadField: r4 = r3->field_77
    //     0x82bddc: ldur            w4, [x3, #0x77]
    // 0x82bde0: DecompressPointer r4
    //     0x82bde0: add             x4, x4, HEAP, lsl #32
    // 0x82bde4: LoadField: r3 = r2->field_1f
    //     0x82bde4: ldur            w3, [x2, #0x1f]
    // 0x82bde8: DecompressPointer r3
    //     0x82bde8: add             x3, x3, HEAP, lsl #32
    // 0x82bdec: cmp             w3, NULL
    // 0x82bdf0: b.eq            #0x82bf44
    // 0x82bdf4: LoadField: d0 = r3->field_b
    //     0x82bdf4: ldur            d0, [x3, #0xb]
    // 0x82bdf8: r2 = inline_Allocate_Double()
    //     0x82bdf8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x82bdfc: add             x2, x2, #0x10
    //     0x82be00: cmp             x3, x2
    //     0x82be04: b.ls            #0x82bf48
    //     0x82be08: str             x2, [THR, #0x60]  ; THR::top
    //     0x82be0c: sub             x2, x2, #0xf
    //     0x82be10: mov             x3, #0xd108
    //     0x82be14: movk            x3, #3, lsl #16
    //     0x82be18: stur            x3, [x2, #-1]
    // 0x82be1c: StoreField: r2->field_7 = d0
    //     0x82be1c: stur            d0, [x2, #7]
    // 0x82be20: stp             x0, x4, [SP, #-0x10]!
    // 0x82be24: ldur            x16, [fp, #-0x10]
    // 0x82be28: stp             x2, x16, [SP, #-0x10]!
    // 0x82be2c: r4 = const [0, 0x4, 0x4, 0x3, scale, 0x3, null]
    //     0x82be2c: add             x4, PP, #0x38, lsl #12  ; [pp+0x38478] List(7) [0, 0x4, 0x4, 0x3, "scale", 0x3, Null]
    //     0x82be30: ldr             x4, [x4, #0x478]
    // 0x82be34: r0 = getDestinationRect()
    //     0x82be34: bl              #0x658e94  ; [package:extended_image/src/editor/editor_utils.dart] ::getDestinationRect
    // 0x82be38: add             SP, SP, #0x20
    // 0x82be3c: mov             x1, x0
    // 0x82be40: ldur            x0, [fp, #-8]
    // 0x82be44: LoadField: r2 = r0->field_f
    //     0x82be44: ldur            w2, [x0, #0xf]
    // 0x82be48: DecompressPointer r2
    //     0x82be48: add             x2, x2, HEAP, lsl #32
    // 0x82be4c: stp             x1, x2, [SP, #-0x10]!
    // 0x82be50: r0 = _initCropRect()
    //     0x82be50: bl              #0x82bf84  ; [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_initCropRect
    // 0x82be54: add             SP, SP, #0x10
    // 0x82be58: mov             x1, x0
    // 0x82be5c: ldur            x0, [fp, #-8]
    // 0x82be60: LoadField: r2 = r0->field_f
    //     0x82be60: ldur            w2, [x0, #0xf]
    // 0x82be64: DecompressPointer r2
    //     0x82be64: add             x2, x2, HEAP, lsl #32
    // 0x82be68: LoadField: r0 = r2->field_17
    //     0x82be68: ldur            w0, [x2, #0x17]
    // 0x82be6c: DecompressPointer r0
    //     0x82be6c: add             x0, x0, HEAP, lsl #32
    // 0x82be70: cmp             w0, NULL
    // 0x82be74: b.eq            #0x82bf6c
    // 0x82be78: LoadField: r3 = r2->field_13
    //     0x82be78: ldur            w3, [x2, #0x13]
    // 0x82be7c: DecompressPointer r3
    //     0x82be7c: add             x3, x3, HEAP, lsl #32
    // 0x82be80: cmp             w3, NULL
    // 0x82be84: b.eq            #0x82bf70
    // 0x82be88: mov             x0, x1
    // 0x82be8c: StoreField: r3->field_4b = r0
    //     0x82be8c: stur            w0, [x3, #0x4b]
    //     0x82be90: ldurb           w16, [x3, #-1]
    //     0x82be94: ldurb           w17, [x0, #-1]
    //     0x82be98: and             x16, x17, x16, lsr #2
    //     0x82be9c: tst             x16, HEAP, lsr #32
    //     0x82bea0: b.eq            #0x82bea8
    //     0x82bea4: bl              #0xd682ac
    // 0x82bea8: mov             x1, x3
    // 0x82beac: b               #0x82beb4
    // 0x82beb0: mov             x2, x0
    // 0x82beb4: ldur            x0, [fp, #-0x10]
    // 0x82beb8: stur            x1, [fp, #-0x20]
    // 0x82bebc: LoadField: r3 = r2->field_17
    //     0x82bebc: ldur            w3, [x2, #0x17]
    // 0x82bec0: DecompressPointer r3
    //     0x82bec0: add             x3, x3, HEAP, lsl #32
    // 0x82bec4: stur            x3, [fp, #-0x18]
    // 0x82bec8: cmp             w3, NULL
    // 0x82becc: b.eq            #0x82bf74
    // 0x82bed0: LoadField: r4 = r2->field_2b
    //     0x82bed0: ldur            w4, [x2, #0x2b]
    // 0x82bed4: DecompressPointer r4
    //     0x82bed4: add             x4, x4, HEAP, lsl #32
    // 0x82bed8: stur            x4, [fp, #-8]
    // 0x82bedc: r0 = ExtendedImageCropLayer()
    //     0x82bedc: bl              #0x82bf78  ; AllocateExtendedImageCropLayerStub -> ExtendedImageCropLayer (size=0x1c)
    // 0x82bee0: ldur            x1, [fp, #-0x20]
    // 0x82bee4: StoreField: r0->field_b = r1
    //     0x82bee4: stur            w1, [x0, #0xb]
    // 0x82bee8: ldur            x1, [fp, #-0x18]
    // 0x82beec: StoreField: r0->field_f = r1
    //     0x82beec: stur            w1, [x0, #0xf]
    // 0x82bef0: ldur            x1, [fp, #-0x10]
    // 0x82bef4: StoreField: r0->field_13 = r1
    //     0x82bef4: stur            w1, [x0, #0x13]
    // 0x82bef8: r1 = Instance_BoxFit
    //     0x82bef8: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c2e0] Obj!BoxFit@b64e11
    //     0x82befc: ldr             x1, [x1, #0x2e0]
    // 0x82bf00: StoreField: r0->field_17 = r1
    //     0x82bf00: stur            w1, [x0, #0x17]
    // 0x82bf04: ldur            x1, [fp, #-8]
    // 0x82bf08: StoreField: r0->field_7 = r1
    //     0x82bf08: stur            w1, [x0, #7]
    // 0x82bf0c: LeaveFrame
    //     0x82bf0c: mov             SP, fp
    //     0x82bf10: ldp             fp, lr, [SP], #0x10
    // 0x82bf14: ret
    //     0x82bf14: ret             
    // 0x82bf18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82bf18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bf1c: b               #0x82bc10
    // 0x82bf20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf48: SaveReg d0
    //     0x82bf48: str             q0, [SP, #-0x10]!
    // 0x82bf4c: stp             x1, x4, [SP, #-0x10]!
    // 0x82bf50: SaveReg r0
    //     0x82bf50: str             x0, [SP, #-8]!
    // 0x82bf54: r0 = AllocateDouble()
    //     0x82bf54: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82bf58: mov             x2, x0
    // 0x82bf5c: RestoreReg r0
    //     0x82bf5c: ldr             x0, [SP], #8
    // 0x82bf60: ldp             x1, x4, [SP], #0x10
    // 0x82bf64: RestoreReg d0
    //     0x82bf64: ldr             q0, [SP], #0x10
    // 0x82bf68: b               #0x82be1c
    // 0x82bf6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82bf74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82bf74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initCropRect(/* No info */) {
    // ** addr: 0x82bf84, size: 0xe8
    // 0x82bf84: EnterFrame
    //     0x82bf84: stp             fp, lr, [SP, #-0x10]!
    //     0x82bf88: mov             fp, SP
    // 0x82bf8c: CheckStackOverflow
    //     0x82bf8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82bf90: cmp             SP, x16
    //     0x82bf94: b.ls            #0x82c050
    // 0x82bf98: ldr             x0, [fp, #0x18]
    // 0x82bf9c: LoadField: r1 = r0->field_13
    //     0x82bf9c: ldur            w1, [x0, #0x13]
    // 0x82bfa0: DecompressPointer r1
    //     0x82bfa0: add             x1, x1, HEAP, lsl #32
    // 0x82bfa4: cmp             w1, NULL
    // 0x82bfa8: b.eq            #0x82c058
    // 0x82bfac: SaveReg r1
    //     0x82bfac: str             x1, [SP, #-8]!
    // 0x82bfb0: r0 = cropAspectRatio()
    //     0x82bfb0: bl              #0x82a41c  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::cropAspectRatio
    // 0x82bfb4: add             SP, SP, #8
    // 0x82bfb8: cmp             w0, NULL
    // 0x82bfbc: b.eq            #0x82c010
    // 0x82bfc0: ldr             x0, [fp, #0x18]
    // 0x82bfc4: LoadField: r1 = r0->field_13
    //     0x82bfc4: ldur            w1, [x0, #0x13]
    // 0x82bfc8: DecompressPointer r1
    //     0x82bfc8: add             x1, x1, HEAP, lsl #32
    // 0x82bfcc: cmp             w1, NULL
    // 0x82bfd0: b.eq            #0x82c05c
    // 0x82bfd4: SaveReg r1
    //     0x82bfd4: str             x1, [SP, #-8]!
    // 0x82bfd8: r0 = cropAspectRatio()
    //     0x82bfd8: bl              #0x82a41c  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::cropAspectRatio
    // 0x82bfdc: add             SP, SP, #8
    // 0x82bfe0: cmp             w0, NULL
    // 0x82bfe4: b.eq            #0x82c060
    // 0x82bfe8: LoadField: d0 = r0->field_7
    //     0x82bfe8: ldur            d0, [x0, #7]
    // 0x82bfec: ldr             x16, [fp, #0x18]
    // 0x82bff0: ldr             lr, [fp, #0x10]
    // 0x82bff4: stp             lr, x16, [SP, #-0x10]!
    // 0x82bff8: SaveReg d0
    //     0x82bff8: str             d0, [SP, #-8]!
    // 0x82bffc: r0 = _calculateCropRectFromAspectRatio()
    //     0x82bffc: bl              #0x82c06c  ; [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_calculateCropRectFromAspectRatio
    // 0x82c000: add             SP, SP, #0x18
    // 0x82c004: LeaveFrame
    //     0x82c004: mov             SP, fp
    //     0x82c008: ldp             fp, lr, [SP], #0x10
    // 0x82c00c: ret
    //     0x82c00c: ret             
    // 0x82c010: ldr             x0, [fp, #0x18]
    // 0x82c014: LoadField: r1 = r0->field_17
    //     0x82c014: ldur            w1, [x0, #0x17]
    // 0x82c018: DecompressPointer r1
    //     0x82c018: add             x1, x1, HEAP, lsl #32
    // 0x82c01c: cmp             w1, NULL
    // 0x82c020: b.eq            #0x82c064
    // 0x82c024: LoadField: r1 = r0->field_13
    //     0x82c024: ldur            w1, [x0, #0x13]
    // 0x82c028: DecompressPointer r1
    //     0x82c028: add             x1, x1, HEAP, lsl #32
    // 0x82c02c: cmp             w1, NULL
    // 0x82c030: b.eq            #0x82c068
    // 0x82c034: ldr             x16, [fp, #0x10]
    // 0x82c038: stp             x16, x1, [SP, #-0x10]!
    // 0x82c03c: r0 = getRectWithScale()
    //     0x82c03c: bl              #0x6582cc  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::getRectWithScale
    // 0x82c040: add             SP, SP, #0x10
    // 0x82c044: LeaveFrame
    //     0x82c044: mov             SP, fp
    //     0x82c048: ldp             fp, lr, [SP], #0x10
    // 0x82c04c: ret
    //     0x82c04c: ret             
    // 0x82c050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c050: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c054: b               #0x82bf98
    // 0x82c058: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c058: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c05c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c05c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c060: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c060: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c064: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c064: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c068: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c068: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _calculateCropRectFromAspectRatio(/* No info */) {
    // ** addr: 0x82c06c, size: 0x1ec
    // 0x82c06c: EnterFrame
    //     0x82c06c: stp             fp, lr, [SP, #-0x10]!
    //     0x82c070: mov             fp, SP
    // 0x82c074: AllocStack(0x20)
    //     0x82c074: sub             SP, SP, #0x20
    // 0x82c078: CheckStackOverflow
    //     0x82c078: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82c07c: cmp             SP, x16
    //     0x82c080: b.ls            #0x82c20c
    // 0x82c084: ldr             x0, [fp, #0x20]
    // 0x82c088: LoadField: r1 = r0->field_13
    //     0x82c088: ldur            w1, [x0, #0x13]
    // 0x82c08c: DecompressPointer r1
    //     0x82c08c: add             x1, x1, HEAP, lsl #32
    // 0x82c090: cmp             w1, NULL
    // 0x82c094: b.eq            #0x82c214
    // 0x82c098: ldr             x16, [fp, #0x18]
    // 0x82c09c: stp             x16, x1, [SP, #-0x10]!
    // 0x82c0a0: r0 = getRectWithScale()
    //     0x82c0a0: bl              #0x6582cc  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::getRectWithScale
    // 0x82c0a4: add             SP, SP, #0x10
    // 0x82c0a8: stur            x0, [fp, #-8]
    // 0x82c0ac: LoadField: d0 = r0->field_1f
    //     0x82c0ac: ldur            d0, [x0, #0x1f]
    // 0x82c0b0: LoadField: d1 = r0->field_f
    //     0x82c0b0: ldur            d1, [x0, #0xf]
    // 0x82c0b4: fsub            d2, d0, d1
    // 0x82c0b8: stur            d2, [fp, #-0x20]
    // 0x82c0bc: LoadField: d0 = r0->field_17
    //     0x82c0bc: ldur            d0, [x0, #0x17]
    // 0x82c0c0: LoadField: d1 = r0->field_7
    //     0x82c0c0: ldur            d1, [x0, #7]
    // 0x82c0c4: fsub            d3, d0, d1
    // 0x82c0c8: ldr             d0, [fp, #0x10]
    // 0x82c0cc: fdiv            d1, d3, d0
    // 0x82c0d0: stur            d1, [fp, #-0x18]
    // 0x82c0d4: fcmp            d2, d1
    // 0x82c0d8: b.vs            #0x82c0e0
    // 0x82c0dc: b.gt            #0x82c18c
    // 0x82c0e0: fcmp            d2, d1
    // 0x82c0e4: b.vs            #0x82c0f4
    // 0x82c0e8: b.ge            #0x82c0f4
    // 0x82c0ec: mov             v1.16b, v2.16b
    // 0x82c0f0: b               #0x82c18c
    // 0x82c0f4: d3 = 0.000000
    //     0x82c0f4: eor             v3.16b, v3.16b, v3.16b
    // 0x82c0f8: fcmp            d2, d3
    // 0x82c0fc: b.vs            #0x82c104
    // 0x82c100: b.eq            #0x82c10c
    // 0x82c104: r1 = false
    //     0x82c104: add             x1, NULL, #0x30  ; false
    // 0x82c108: b               #0x82c110
    // 0x82c10c: r1 = true
    //     0x82c10c: add             x1, NULL, #0x20  ; true
    // 0x82c110: tbnz            w1, #4, #0x82c128
    // 0x82c114: fadd            d3, d2, d1
    // 0x82c118: fmul            d4, d3, d2
    // 0x82c11c: fmul            d2, d4, d1
    // 0x82c120: mov             v1.16b, v2.16b
    // 0x82c124: b               #0x82c18c
    // 0x82c128: tbnz            w1, #4, #0x82c16c
    // 0x82c12c: r1 = inline_Allocate_Double()
    //     0x82c12c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82c130: add             x1, x1, #0x10
    //     0x82c134: cmp             x2, x1
    //     0x82c138: b.ls            #0x82c218
    //     0x82c13c: str             x1, [THR, #0x60]  ; THR::top
    //     0x82c140: sub             x1, x1, #0xf
    //     0x82c144: mov             x2, #0xd108
    //     0x82c148: movk            x2, #3, lsl #16
    //     0x82c14c: stur            x2, [x1, #-1]
    // 0x82c150: StoreField: r1->field_7 = d1
    //     0x82c150: stur            d1, [x1, #7]
    // 0x82c154: SaveReg r1
    //     0x82c154: str             x1, [SP, #-8]!
    // 0x82c158: r0 = isNegative()
    //     0x82c158: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x82c15c: add             SP, SP, #8
    // 0x82c160: tbnz            w0, #4, #0x82c16c
    // 0x82c164: ldur            d0, [fp, #-0x18]
    // 0x82c168: b               #0x82c178
    // 0x82c16c: ldur            d0, [fp, #-0x18]
    // 0x82c170: fcmp            d0, d0
    // 0x82c174: b.vc            #0x82c184
    // 0x82c178: mov             v1.16b, v0.16b
    // 0x82c17c: ldr             d0, [fp, #0x10]
    // 0x82c180: b               #0x82c18c
    // 0x82c184: ldur            d1, [fp, #-0x20]
    // 0x82c188: ldr             d0, [fp, #0x10]
    // 0x82c18c: stur            d1, [fp, #-0x20]
    // 0x82c190: fmul            d2, d1, d0
    // 0x82c194: stur            d2, [fp, #-0x18]
    // 0x82c198: ldur            x16, [fp, #-8]
    // 0x82c19c: SaveReg r16
    //     0x82c19c: str             x16, [SP, #-8]!
    // 0x82c1a0: r0 = center()
    //     0x82c1a0: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x82c1a4: add             SP, SP, #8
    // 0x82c1a8: stur            x0, [fp, #-8]
    // 0x82c1ac: r0 = Rect()
    //     0x82c1ac: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x82c1b0: ldur            d0, [fp, #-0x20]
    // 0x82c1b4: stur            x0, [fp, #-0x10]
    // 0x82c1b8: r1 = inline_Allocate_Double()
    //     0x82c1b8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82c1bc: add             x1, x1, #0x10
    //     0x82c1c0: cmp             x2, x1
    //     0x82c1c4: b.ls            #0x82c23c
    //     0x82c1c8: str             x1, [THR, #0x60]  ; THR::top
    //     0x82c1cc: sub             x1, x1, #0xf
    //     0x82c1d0: mov             x2, #0xd108
    //     0x82c1d4: movk            x2, #3, lsl #16
    //     0x82c1d8: stur            x2, [x1, #-1]
    // 0x82c1dc: StoreField: r1->field_7 = d0
    //     0x82c1dc: stur            d0, [x1, #7]
    // 0x82c1e0: ldur            x16, [fp, #-8]
    // 0x82c1e4: stp             x16, x0, [SP, #-0x10]!
    // 0x82c1e8: SaveReg r1
    //     0x82c1e8: str             x1, [SP, #-8]!
    // 0x82c1ec: ldur            d0, [fp, #-0x18]
    // 0x82c1f0: SaveReg d0
    //     0x82c1f0: str             d0, [SP, #-8]!
    // 0x82c1f4: r0 = Rect.fromCenter()
    //     0x82c1f4: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0x82c1f8: add             SP, SP, #0x20
    // 0x82c1fc: ldur            x0, [fp, #-0x10]
    // 0x82c200: LeaveFrame
    //     0x82c200: mov             SP, fp
    //     0x82c204: ldp             fp, lr, [SP], #0x10
    // 0x82c208: ret
    //     0x82c208: ret             
    // 0x82c20c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c20c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c210: b               #0x82c084
    // 0x82c214: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c214: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c218: stp             q1, q2, [SP, #-0x20]!
    // 0x82c21c: SaveReg d0
    //     0x82c21c: str             q0, [SP, #-0x10]!
    // 0x82c220: SaveReg r0
    //     0x82c220: str             x0, [SP, #-8]!
    // 0x82c224: r0 = AllocateDouble()
    //     0x82c224: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82c228: mov             x1, x0
    // 0x82c22c: RestoreReg r0
    //     0x82c22c: ldr             x0, [SP], #8
    // 0x82c230: RestoreReg d0
    //     0x82c230: ldr             q0, [SP], #0x10
    // 0x82c234: ldp             q1, q2, [SP], #0x20
    // 0x82c238: b               #0x82c150
    // 0x82c23c: SaveReg d0
    //     0x82c23c: str             q0, [SP, #-0x10]!
    // 0x82c240: SaveReg r0
    //     0x82c240: str             x0, [SP, #-8]!
    // 0x82c244: r0 = AllocateDouble()
    //     0x82c244: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82c248: mov             x1, x0
    // 0x82c24c: RestoreReg r0
    //     0x82c24c: ldr             x0, [SP], #8
    // 0x82c250: RestoreReg d0
    //     0x82c250: ldr             q0, [SP], #0x10
    // 0x82c254: b               #0x82c1dc
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d5f54, size: 0x3c
    // 0x9d5f54: EnterFrame
    //     0x9d5f54: stp             fp, lr, [SP, #-0x10]!
    //     0x9d5f58: mov             fp, SP
    // 0x9d5f5c: CheckStackOverflow
    //     0x9d5f5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d5f60: cmp             SP, x16
    //     0x9d5f64: b.ls            #0x9d5f88
    // 0x9d5f68: ldr             x16, [fp, #0x10]
    // 0x9d5f6c: SaveReg r16
    //     0x9d5f6c: str             x16, [SP, #-8]!
    // 0x9d5f70: r0 = _initGestureConfig()
    //     0x9d5f70: bl              #0x79b140  ; [package:extended_image/src/editor/editor.dart] ExtendedImageEditorState::_initGestureConfig
    // 0x9d5f74: add             SP, SP, #8
    // 0x9d5f78: r0 = Null
    //     0x9d5f78: mov             x0, NULL
    // 0x9d5f7c: LeaveFrame
    //     0x9d5f7c: mov             SP, fp
    //     0x9d5f80: ldp             fp, lr, [SP], #0x10
    // 0x9d5f84: ret
    //     0x9d5f84: ret             
    // 0x9d5f88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d5f88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d5f8c: b               #0x9d5f68
  }
}

// class id: 4215, size: 0x10, field offset: 0xc
class ExtendedImageEditor extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3f1e4, size: 0x58
    // 0xa3f1e4: EnterFrame
    //     0xa3f1e4: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f1e8: mov             fp, SP
    // 0xa3f1ec: AllocStack(0x8)
    //     0xa3f1ec: sub             SP, SP, #8
    // 0xa3f1f0: r1 = <ExtendedImageEditor>
    //     0xa3f1f0: add             x1, PP, #0x41, lsl #12  ; [pp+0x41050] TypeArguments: <ExtendedImageEditor>
    //     0xa3f1f4: ldr             x1, [x1, #0x50]
    // 0xa3f1f8: r0 = ExtendedImageEditorState()
    //     0xa3f1f8: bl              #0xa3f23c  ; AllocateExtendedImageEditorStateStub -> ExtendedImageEditorState (size=0x30)
    // 0xa3f1fc: mov             x2, x0
    // 0xa3f200: r0 = Sentinel
    //     0xa3f200: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3f204: stur            x2, [fp, #-8]
    // 0xa3f208: StoreField: r2->field_1b = r0
    //     0xa3f208: stur            w0, [x2, #0x1b]
    // 0xa3f20c: StoreField: r2->field_1f = r0
    //     0xa3f20c: stur            w0, [x2, #0x1f]
    // 0xa3f210: d0 = 1.000000
    //     0xa3f210: fmov            d0, #1.00000000
    // 0xa3f214: StoreField: r2->field_23 = d0
    //     0xa3f214: stur            d0, [x2, #0x23]
    // 0xa3f218: r1 = <ExtendedImageCropLayerState<ExtendedImageCropLayer>>
    //     0xa3f218: add             x1, PP, #0x41, lsl #12  ; [pp+0x41058] TypeArguments: <ExtendedImageCropLayerState<ExtendedImageCropLayer>>
    //     0xa3f21c: ldr             x1, [x1, #0x58]
    // 0xa3f220: r0 = LabeledGlobalKey()
    //     0xa3f220: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa3f224: mov             x1, x0
    // 0xa3f228: ldur            x0, [fp, #-8]
    // 0xa3f22c: StoreField: r0->field_2b = r1
    //     0xa3f22c: stur            w1, [x0, #0x2b]
    // 0xa3f230: LeaveFrame
    //     0xa3f230: mov             SP, fp
    //     0xa3f234: ldp             fp, lr, [SP], #0x10
    // 0xa3f238: ret
    //     0xa3f238: ret             
  }
}

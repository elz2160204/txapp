// lib: , url: package:extended_image/src/editor/editor_utils.dart

// class id: 1048930, size: 0x8
class :: {

  static _ rotateRect(/* No info */) {
    // ** addr: 0x6569c8, size: 0xdc
    // 0x6569c8: EnterFrame
    //     0x6569c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6569cc: mov             fp, SP
    // 0x6569d0: AllocStack(0x28)
    //     0x6569d0: sub             SP, SP, #0x28
    // 0x6569d4: CheckStackOverflow
    //     0x6569d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6569d8: cmp             SP, x16
    //     0x6569dc: b.ls            #0x656a9c
    // 0x6569e0: ldr             x0, [fp, #0x20]
    // 0x6569e4: LoadField: d0 = r0->field_7
    //     0x6569e4: ldur            d0, [x0, #7]
    // 0x6569e8: stur            d0, [fp, #-0x28]
    // 0x6569ec: LoadField: d1 = r0->field_f
    //     0x6569ec: ldur            d1, [x0, #0xf]
    // 0x6569f0: stur            d1, [fp, #-0x20]
    // 0x6569f4: r0 = Offset()
    //     0x6569f4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6569f8: ldur            d0, [fp, #-0x28]
    // 0x6569fc: StoreField: r0->field_7 = d0
    //     0x6569fc: stur            d0, [x0, #7]
    // 0x656a00: ldur            d0, [fp, #-0x20]
    // 0x656a04: StoreField: r0->field_f = d0
    //     0x656a04: stur            d0, [x0, #0xf]
    // 0x656a08: ldr             x16, [fp, #0x18]
    // 0x656a0c: stp             x16, x0, [SP, #-0x10]!
    // 0x656a10: ldr             d0, [fp, #0x10]
    // 0x656a14: SaveReg d0
    //     0x656a14: str             d0, [SP, #-8]!
    // 0x656a18: r0 = rotateOffset()
    //     0x656a18: bl              #0x656da4  ; [package:extended_image/src/editor/editor_utils.dart] ::rotateOffset
    // 0x656a1c: add             SP, SP, #0x18
    // 0x656a20: mov             x1, x0
    // 0x656a24: ldr             x0, [fp, #0x20]
    // 0x656a28: stur            x1, [fp, #-8]
    // 0x656a2c: LoadField: d0 = r0->field_17
    //     0x656a2c: ldur            d0, [x0, #0x17]
    // 0x656a30: stur            d0, [fp, #-0x28]
    // 0x656a34: LoadField: d1 = r0->field_1f
    //     0x656a34: ldur            d1, [x0, #0x1f]
    // 0x656a38: stur            d1, [fp, #-0x20]
    // 0x656a3c: r0 = Offset()
    //     0x656a3c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x656a40: ldur            d0, [fp, #-0x28]
    // 0x656a44: StoreField: r0->field_7 = d0
    //     0x656a44: stur            d0, [x0, #7]
    // 0x656a48: ldur            d0, [fp, #-0x20]
    // 0x656a4c: StoreField: r0->field_f = d0
    //     0x656a4c: stur            d0, [x0, #0xf]
    // 0x656a50: ldr             x16, [fp, #0x18]
    // 0x656a54: stp             x16, x0, [SP, #-0x10]!
    // 0x656a58: ldr             d0, [fp, #0x10]
    // 0x656a5c: SaveReg d0
    //     0x656a5c: str             d0, [SP, #-8]!
    // 0x656a60: r0 = rotateOffset()
    //     0x656a60: bl              #0x656da4  ; [package:extended_image/src/editor/editor_utils.dart] ::rotateOffset
    // 0x656a64: add             SP, SP, #0x18
    // 0x656a68: stur            x0, [fp, #-0x10]
    // 0x656a6c: r0 = Rect()
    //     0x656a6c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x656a70: stur            x0, [fp, #-0x18]
    // 0x656a74: ldur            x16, [fp, #-8]
    // 0x656a78: stp             x16, x0, [SP, #-0x10]!
    // 0x656a7c: ldur            x16, [fp, #-0x10]
    // 0x656a80: SaveReg r16
    //     0x656a80: str             x16, [SP, #-8]!
    // 0x656a84: r0 = Rect.fromPoints()
    //     0x656a84: bl              #0x656aa4  ; [dart:ui] Rect::Rect.fromPoints
    // 0x656a88: add             SP, SP, #0x18
    // 0x656a8c: ldur            x0, [fp, #-0x18]
    // 0x656a90: LeaveFrame
    //     0x656a90: mov             SP, fp
    //     0x656a94: ldp             fp, lr, [SP], #0x10
    // 0x656a98: ret
    //     0x656a98: ret             
    // 0x656a9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x656a9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x656aa0: b               #0x6569e0
  }
  static _ rotateOffset(/* No info */) {
    // ** addr: 0x656da4, size: 0x12c
    // 0x656da4: EnterFrame
    //     0x656da4: stp             fp, lr, [SP, #-0x10]!
    //     0x656da8: mov             fp, SP
    // 0x656dac: AllocStack(0x38)
    //     0x656dac: sub             SP, SP, #0x38
    // 0x656db0: ldr             x0, [fp, #0x20]
    // 0x656db4: LoadField: d0 = r0->field_7
    //     0x656db4: ldur            d0, [x0, #7]
    // 0x656db8: LoadField: d1 = r0->field_f
    //     0x656db8: ldur            d1, [x0, #0xf]
    // 0x656dbc: ldr             x0, [fp, #0x18]
    // 0x656dc0: stur            d1, [fp, #-0x20]
    // 0x656dc4: LoadField: d2 = r0->field_7
    //     0x656dc4: ldur            d2, [x0, #7]
    // 0x656dc8: stur            d2, [fp, #-0x18]
    // 0x656dcc: LoadField: d3 = r0->field_f
    //     0x656dcc: ldur            d3, [x0, #0xf]
    // 0x656dd0: stur            d3, [fp, #-0x10]
    // 0x656dd4: fsub            d4, d0, d2
    // 0x656dd8: ldr             d0, [fp, #0x10]
    // 0x656ddc: stur            d4, [fp, #-8]
    // 0x656de0: stp             fp, lr, [SP, #-0x10]!
    // 0x656de4: mov             fp, SP
    // 0x656de8: CallRuntime_LibcCos(double) -> double
    //     0x656de8: and             SP, SP, #0xfffffffffffffff0
    //     0x656dec: mov             sp, SP
    //     0x656df0: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0x656df4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x656df8: blr             x16
    //     0x656dfc: mov             x16, #8
    //     0x656e00: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x656e04: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x656e08: sub             sp, x16, #1, lsl #12
    //     0x656e0c: mov             SP, fp
    //     0x656e10: ldp             fp, lr, [SP], #0x10
    // 0x656e14: mov             v2.16b, v0.16b
    // 0x656e18: ldur            d1, [fp, #-8]
    // 0x656e1c: stur            d2, [fp, #-0x38]
    // 0x656e20: fmul            d3, d1, d2
    // 0x656e24: ldur            d0, [fp, #-0x20]
    // 0x656e28: ldur            d4, [fp, #-0x10]
    // 0x656e2c: stur            d3, [fp, #-0x30]
    // 0x656e30: fsub            d5, d0, d4
    // 0x656e34: ldr             d0, [fp, #0x10]
    // 0x656e38: stur            d5, [fp, #-0x28]
    // 0x656e3c: stp             fp, lr, [SP, #-0x10]!
    // 0x656e40: mov             fp, SP
    // 0x656e44: CallRuntime_LibcSin(double) -> double
    //     0x656e44: and             SP, SP, #0xfffffffffffffff0
    //     0x656e48: mov             sp, SP
    //     0x656e4c: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0x656e50: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x656e54: blr             x16
    //     0x656e58: mov             x16, #8
    //     0x656e5c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x656e60: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x656e64: sub             sp, x16, #1, lsl #12
    //     0x656e68: mov             SP, fp
    //     0x656e6c: ldp             fp, lr, [SP], #0x10
    // 0x656e70: mov             v1.16b, v0.16b
    // 0x656e74: ldur            d0, [fp, #-0x28]
    // 0x656e78: fmul            d2, d0, d1
    // 0x656e7c: ldur            d3, [fp, #-0x30]
    // 0x656e80: fsub            d4, d3, d2
    // 0x656e84: ldur            d2, [fp, #-0x18]
    // 0x656e88: fadd            d3, d4, d2
    // 0x656e8c: ldur            d2, [fp, #-8]
    // 0x656e90: stur            d3, [fp, #-0x20]
    // 0x656e94: fmul            d4, d2, d1
    // 0x656e98: ldur            d1, [fp, #-0x38]
    // 0x656e9c: fmul            d2, d0, d1
    // 0x656ea0: fadd            d0, d4, d2
    // 0x656ea4: ldur            d1, [fp, #-0x10]
    // 0x656ea8: fadd            d2, d0, d1
    // 0x656eac: stur            d2, [fp, #-8]
    // 0x656eb0: r0 = Offset()
    //     0x656eb0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x656eb4: ldur            d0, [fp, #-0x20]
    // 0x656eb8: StoreField: r0->field_7 = d0
    //     0x656eb8: stur            d0, [x0, #7]
    // 0x656ebc: ldur            d0, [fp, #-8]
    // 0x656ec0: StoreField: r0->field_f = d0
    //     0x656ec0: stur            d0, [x0, #0xf]
    // 0x656ec4: LeaveFrame
    //     0x656ec4: mov             SP, fp
    //     0x656ec8: ldp             fp, lr, [SP], #0x10
    // 0x656ecc: ret
    //     0x656ecc: ret             
  }
  static _ getDestinationRect(/* No info */) {
    // ** addr: 0x658e94, size: 0x260
    // 0x658e94: EnterFrame
    //     0x658e94: stp             fp, lr, [SP, #-0x10]!
    //     0x658e98: mov             fp, SP
    // 0x658e9c: AllocStack(0x48)
    //     0x658e9c: sub             SP, SP, #0x48
    // 0x658ea0: SetupParameters(dynamic _ /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, dynamic _ /* r5, fp-0x8 */, {_Double scale = 1.000000 /* d0, fp-0x30 */})
    //     0x658ea0: mov             x0, x4
    //     0x658ea4: ldur            w1, [x0, #0x13]
    //     0x658ea8: add             x1, x1, HEAP, lsl #32
    //     0x658eac: sub             x2, x1, #6
    //     0x658eb0: add             x3, fp, w2, sxtw #2
    //     0x658eb4: ldr             x3, [x3, #0x20]
    //     0x658eb8: stur            x3, [fp, #-0x18]
    //     0x658ebc: add             x4, fp, w2, sxtw #2
    //     0x658ec0: ldr             x4, [x4, #0x18]
    //     0x658ec4: stur            x4, [fp, #-0x10]
    //     0x658ec8: add             x5, fp, w2, sxtw #2
    //     0x658ecc: ldr             x5, [x5, #0x10]
    //     0x658ed0: stur            x5, [fp, #-8]
    //     0x658ed4: ldur            w2, [x0, #0x1f]
    //     0x658ed8: add             x2, x2, HEAP, lsl #32
    //     0x658edc: add             x16, PP, #0x38, lsl #12  ; [pp+0x38490] "scale"
    //     0x658ee0: ldr             x16, [x16, #0x490]
    //     0x658ee4: cmp             w2, w16
    //     0x658ee8: b.ne            #0x658f08
    //     0x658eec: ldur            w2, [x0, #0x23]
    //     0x658ef0: add             x2, x2, HEAP, lsl #32
    //     0x658ef4: sub             w0, w1, w2
    //     0x658ef8: add             x1, fp, w0, sxtw #2
    //     0x658efc: ldr             x1, [x1, #8]
    //     0x658f00: ldur            d0, [x1, #7]
    //     0x658f04: b               #0x658f0c
    //     0x658f08: fmov            d0, #1.00000000
    //     0x658f0c: stur            d0, [fp, #-0x30]
    // 0x658f10: CheckStackOverflow
    //     0x658f10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x658f14: cmp             SP, x16
    //     0x658f18: b.ls            #0x6590ac
    // 0x658f1c: SaveReg r5
    //     0x658f1c: str             x5, [SP, #-8]!
    // 0x658f20: r0 = size()
    //     0x658f20: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0x658f24: add             SP, SP, #8
    // 0x658f28: mov             x1, x0
    // 0x658f2c: ldur            x0, [fp, #-0x18]
    // 0x658f30: stur            x1, [fp, #-0x28]
    // 0x658f34: cmp             w0, NULL
    // 0x658f38: b.ne            #0x658f48
    // 0x658f3c: r2 = Instance_BoxFit
    //     0x658f3c: add             x2, PP, #0x21, lsl #12  ; [pp+0x21cc8] Obj!BoxFit@b64df1
    //     0x658f40: ldr             x2, [x2, #0xcc8]
    // 0x658f44: b               #0x658f4c
    // 0x658f48: mov             x2, x0
    // 0x658f4c: ldur            x0, [fp, #-8]
    // 0x658f50: ldur            d0, [fp, #-0x30]
    // 0x658f54: stur            x2, [fp, #-0x20]
    // 0x658f58: r3 = inline_Allocate_Double()
    //     0x658f58: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x658f5c: add             x3, x3, #0x10
    //     0x658f60: cmp             x4, x3
    //     0x658f64: b.ls            #0x6590b4
    //     0x658f68: str             x3, [THR, #0x60]  ; THR::top
    //     0x658f6c: sub             x3, x3, #0xf
    //     0x658f70: mov             x4, #0xd108
    //     0x658f74: movk            x4, #3, lsl #16
    //     0x658f78: stur            x4, [x3, #-1]
    // 0x658f7c: StoreField: r3->field_7 = d0
    //     0x658f7c: stur            d0, [x3, #7]
    // 0x658f80: stur            x3, [fp, #-0x18]
    // 0x658f84: ldur            x16, [fp, #-0x10]
    // 0x658f88: stp             x3, x16, [SP, #-0x10]!
    // 0x658f8c: r0 = /()
    //     0x658f8c: bl              #0x50e098  ; [dart:ui] Size::/
    // 0x658f90: add             SP, SP, #0x10
    // 0x658f94: ldur            x16, [fp, #-0x20]
    // 0x658f98: stp             x0, x16, [SP, #-0x10]!
    // 0x658f9c: ldur            x16, [fp, #-0x28]
    // 0x658fa0: SaveReg r16
    //     0x658fa0: str             x16, [SP, #-8]!
    // 0x658fa4: r0 = applyBoxFit()
    //     0x658fa4: bl              #0x626a14  ; [package:flutter/src/painting/box_fit.dart] ::applyBoxFit
    // 0x658fa8: add             SP, SP, #0x18
    // 0x658fac: stur            x0, [fp, #-0x10]
    // 0x658fb0: LoadField: r1 = r0->field_7
    //     0x658fb0: ldur            w1, [x0, #7]
    // 0x658fb4: DecompressPointer r1
    //     0x658fb4: add             x1, x1, HEAP, lsl #32
    // 0x658fb8: ldur            x16, [fp, #-0x18]
    // 0x658fbc: stp             x16, x1, [SP, #-0x10]!
    // 0x658fc0: r0 = *()
    //     0x658fc0: bl              #0x50e17c  ; [dart:ui] Size::*
    // 0x658fc4: add             SP, SP, #0x10
    // 0x658fc8: ldur            x0, [fp, #-0x10]
    // 0x658fcc: LoadField: r1 = r0->field_b
    //     0x658fcc: ldur            w1, [x0, #0xb]
    // 0x658fd0: DecompressPointer r1
    //     0x658fd0: add             x1, x1, HEAP, lsl #32
    // 0x658fd4: ldur            x0, [fp, #-0x28]
    // 0x658fd8: stur            x1, [fp, #-0x18]
    // 0x658fdc: LoadField: d0 = r0->field_7
    //     0x658fdc: ldur            d0, [x0, #7]
    // 0x658fe0: LoadField: d1 = r1->field_7
    //     0x658fe0: ldur            d1, [x1, #7]
    // 0x658fe4: fsub            d2, d0, d1
    // 0x658fe8: d0 = 2.000000
    //     0x658fe8: fmov            d0, #2.00000000
    // 0x658fec: fdiv            d1, d2, d0
    // 0x658ff0: LoadField: d2 = r0->field_f
    //     0x658ff0: ldur            d2, [x0, #0xf]
    // 0x658ff4: LoadField: d3 = r1->field_f
    //     0x658ff4: ldur            d3, [x1, #0xf]
    // 0x658ff8: fsub            d4, d2, d3
    // 0x658ffc: fdiv            d2, d4, d0
    // 0x659000: r0 = Instance_Alignment
    //     0x659000: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x659004: ldr             x0, [x0, #0xc70]
    // 0x659008: LoadField: d0 = r0->field_7
    //     0x659008: ldur            d0, [x0, #7]
    // 0x65900c: fmul            d3, d0, d1
    // 0x659010: fadd            d0, d1, d3
    // 0x659014: stur            d0, [fp, #-0x48]
    // 0x659018: LoadField: d1 = r0->field_f
    //     0x659018: ldur            d1, [x0, #0xf]
    // 0x65901c: fmul            d3, d1, d2
    // 0x659020: fadd            d1, d2, d3
    // 0x659024: ldur            x0, [fp, #-8]
    // 0x659028: stur            d1, [fp, #-0x40]
    // 0x65902c: LoadField: d2 = r0->field_7
    //     0x65902c: ldur            d2, [x0, #7]
    // 0x659030: stur            d2, [fp, #-0x38]
    // 0x659034: LoadField: d3 = r0->field_f
    //     0x659034: ldur            d3, [x0, #0xf]
    // 0x659038: stur            d3, [fp, #-0x30]
    // 0x65903c: r0 = Offset()
    //     0x65903c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x659040: ldur            d0, [fp, #-0x38]
    // 0x659044: StoreField: r0->field_7 = d0
    //     0x659044: stur            d0, [x0, #7]
    // 0x659048: ldur            d0, [fp, #-0x30]
    // 0x65904c: StoreField: r0->field_f = d0
    //     0x65904c: stur            d0, [x0, #0xf]
    // 0x659050: ldur            d0, [fp, #-0x48]
    // 0x659054: r1 = inline_Allocate_Double()
    //     0x659054: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x659058: add             x1, x1, #0x10
    //     0x65905c: cmp             x2, x1
    //     0x659060: b.ls            #0x6590d8
    //     0x659064: str             x1, [THR, #0x60]  ; THR::top
    //     0x659068: sub             x1, x1, #0xf
    //     0x65906c: mov             x2, #0xd108
    //     0x659070: movk            x2, #3, lsl #16
    //     0x659074: stur            x2, [x1, #-1]
    // 0x659078: StoreField: r1->field_7 = d0
    //     0x659078: stur            d0, [x1, #7]
    // 0x65907c: stp             x1, x0, [SP, #-0x10]!
    // 0x659080: ldur            d0, [fp, #-0x40]
    // 0x659084: SaveReg d0
    //     0x659084: str             d0, [SP, #-8]!
    // 0x659088: r0 = translate()
    //     0x659088: bl              #0x65ad6c  ; [dart:ui] Offset::translate
    // 0x65908c: add             SP, SP, #0x18
    // 0x659090: ldur            x16, [fp, #-0x18]
    // 0x659094: stp             x16, x0, [SP, #-0x10]!
    // 0x659098: r0 = &()
    //     0x659098: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x65909c: add             SP, SP, #0x10
    // 0x6590a0: LeaveFrame
    //     0x6590a0: mov             SP, fp
    //     0x6590a4: ldp             fp, lr, [SP], #0x10
    // 0x6590a8: ret
    //     0x6590a8: ret             
    // 0x6590ac: r0 = StackOverflowSharedWithFPURegs()
    //     0x6590ac: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6590b0: b               #0x658f1c
    // 0x6590b4: SaveReg d0
    //     0x6590b4: str             q0, [SP, #-0x10]!
    // 0x6590b8: stp             x1, x2, [SP, #-0x10]!
    // 0x6590bc: SaveReg r0
    //     0x6590bc: str             x0, [SP, #-8]!
    // 0x6590c0: r0 = AllocateDouble()
    //     0x6590c0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6590c4: mov             x3, x0
    // 0x6590c8: RestoreReg r0
    //     0x6590c8: ldr             x0, [SP], #8
    // 0x6590cc: ldp             x1, x2, [SP], #0x10
    // 0x6590d0: RestoreReg d0
    //     0x6590d0: ldr             q0, [SP], #0x10
    // 0x6590d4: b               #0x658f7c
    // 0x6590d8: SaveReg d0
    //     0x6590d8: str             q0, [SP, #-0x10]!
    // 0x6590dc: SaveReg r0
    //     0x6590dc: str             x0, [SP, #-8]!
    // 0x6590e0: r0 = AllocateDouble()
    //     0x6590e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6590e4: mov             x1, x0
    // 0x6590e8: RestoreReg r0
    //     0x6590e8: ldr             x0, [SP], #8
    // 0x6590ec: RestoreReg d0
    //     0x6590ec: ldr             q0, [SP], #0x10
    // 0x6590f0: b               #0x659078
  }
  static _ defaultEditorMaskColorHandler(/* No info */) {
    // ** addr: 0x8278f4, size: 0x6c
    // 0x8278f4: EnterFrame
    //     0x8278f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8278f8: mov             fp, SP
    // 0x8278fc: CheckStackOverflow
    //     0x8278fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x827900: cmp             SP, x16
    //     0x827904: b.ls            #0x827958
    // 0x827908: ldr             x16, [fp, #0x18]
    // 0x82790c: SaveReg r16
    //     0x82790c: str             x16, [SP, #-8]!
    // 0x827910: r0 = of()
    //     0x827910: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x827914: add             SP, SP, #8
    // 0x827918: LoadField: r1 = r0->field_6f
    //     0x827918: ldur            w1, [x0, #0x6f]
    // 0x82791c: DecompressPointer r1
    //     0x82791c: add             x1, x1, HEAP, lsl #32
    // 0x827920: ldr             x0, [fp, #0x10]
    // 0x827924: tbnz            w0, #4, #0x827934
    // 0x827928: d0 = 0.400000
    //     0x827928: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x82792c: ldr             d0, [x17, #0x148]
    // 0x827930: b               #0x82793c
    // 0x827934: d0 = 0.800000
    //     0x827934: add             x17, PP, #0x2b, lsl #12  ; [pp+0x2bf68] IMM: double(0.8) from 0x3fe999999999999a
    //     0x827938: ldr             d0, [x17, #0xf68]
    // 0x82793c: SaveReg r1
    //     0x82793c: str             x1, [SP, #-8]!
    // 0x827940: SaveReg d0
    //     0x827940: str             d0, [SP, #-8]!
    // 0x827944: r0 = withOpacity()
    //     0x827944: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x827948: add             SP, SP, #0x10
    // 0x82794c: LeaveFrame
    //     0x82794c: mov             SP, fp
    //     0x827950: ldp             fp, lr, [SP], #0x10
    // 0x827954: ret
    //     0x827954: ret             
    // 0x827958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827958: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82795c: b               #0x827908
  }
}

// class id: 4381, size: 0x30, field offset: 0xc
class ExtendedImageCropLayerPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xa6ccb8, size: 0x50
    // 0xa6ccb8: EnterFrame
    //     0xa6ccb8: stp             fp, lr, [SP, #-0x10]!
    //     0xa6ccbc: mov             fp, SP
    // 0xa6ccc0: CheckStackOverflow
    //     0xa6ccc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6ccc4: cmp             SP, x16
    //     0xa6ccc8: b.ls            #0xa6cd00
    // 0xa6cccc: r16 = Instance_EditorCropLayerPainter
    //     0xa6cccc: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c798] Obj!EditorCropLayerPainter@b4fdd1
    //     0xa6ccd0: ldr             x16, [x16, #0x798]
    // 0xa6ccd4: ldr             lr, [fp, #0x18]
    // 0xa6ccd8: stp             lr, x16, [SP, #-0x10]!
    // 0xa6ccdc: ldr             x16, [fp, #0x10]
    // 0xa6cce0: ldr             lr, [fp, #0x20]
    // 0xa6cce4: stp             lr, x16, [SP, #-0x10]!
    // 0xa6cce8: r0 = paint()
    //     0xa6cce8: bl              #0xa6cd08  ; [package:extended_image/src/editor/editor_utils.dart] EditorCropLayerPainter::paint
    // 0xa6ccec: add             SP, SP, #0x20
    // 0xa6ccf0: r0 = Null
    //     0xa6ccf0: mov             x0, NULL
    // 0xa6ccf4: LeaveFrame
    //     0xa6ccf4: mov             SP, fp
    //     0xa6ccf8: ldp             fp, lr, [SP], #0x10
    // 0xa6ccfc: ret
    //     0xa6ccfc: ret             
    // 0xa6cd00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6cd00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6cd04: b               #0xa6cccc
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xa78fb0, size: 0x4ac
    // 0xa78fb0: EnterFrame
    //     0xa78fb0: stp             fp, lr, [SP, #-0x10]!
    //     0xa78fb4: mov             fp, SP
    // 0xa78fb8: AllocStack(0x18)
    //     0xa78fb8: sub             SP, SP, #0x18
    // 0xa78fbc: CheckStackOverflow
    //     0xa78fbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa78fc0: cmp             SP, x16
    //     0xa78fc4: b.ls            #0xa79454
    // 0xa78fc8: ldr             x16, [fp, #0x10]
    // 0xa78fcc: SaveReg r16
    //     0xa78fcc: str             x16, [SP, #-8]!
    // 0xa78fd0: r0 = runtimeType()
    //     0xa78fd0: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xa78fd4: add             SP, SP, #8
    // 0xa78fd8: r1 = LoadClassIdInstr(r0)
    //     0xa78fd8: ldur            x1, [x0, #-1]
    //     0xa78fdc: ubfx            x1, x1, #0xc, #0x14
    // 0xa78fe0: r16 = ExtendedImageCropLayerPainter
    //     0xa78fe0: add             x16, PP, #0x55, lsl #12  ; [pp+0x55c80] Type: ExtendedImageCropLayerPainter
    //     0xa78fe4: ldr             x16, [x16, #0xc80]
    // 0xa78fe8: stp             x16, x0, [SP, #-0x10]!
    // 0xa78fec: mov             x0, x1
    // 0xa78ff0: mov             lr, x0
    // 0xa78ff4: ldr             lr, [x21, lr, lsl #3]
    // 0xa78ff8: blr             lr
    // 0xa78ffc: add             SP, SP, #0x10
    // 0xa79000: tbz             w0, #4, #0xa79014
    // 0xa79004: r0 = true
    //     0xa79004: add             x0, NULL, #0x20  ; true
    // 0xa79008: LeaveFrame
    //     0xa79008: mov             SP, fp
    //     0xa7900c: ldp             fp, lr, [SP], #0x10
    // 0xa79010: ret
    //     0xa79010: ret             
    // 0xa79014: ldr             x4, [fp, #0x18]
    // 0xa79018: ldr             x3, [fp, #0x10]
    // 0xa7901c: mov             x0, x3
    // 0xa79020: r2 = Null
    //     0xa79020: mov             x2, NULL
    // 0xa79024: r1 = Null
    //     0xa79024: mov             x1, NULL
    // 0xa79028: r4 = LoadClassIdInstr(r0)
    //     0xa79028: ldur            x4, [x0, #-1]
    //     0xa7902c: ubfx            x4, x4, #0xc, #0x14
    // 0xa79030: r17 = 4381
    //     0xa79030: mov             x17, #0x111d
    // 0xa79034: cmp             x4, x17
    // 0xa79038: b.eq            #0xa79050
    // 0xa7903c: r8 = ExtendedImageCropLayerPainter
    //     0xa7903c: add             x8, PP, #0x55, lsl #12  ; [pp+0x55c80] Type: ExtendedImageCropLayerPainter
    //     0xa79040: ldr             x8, [x8, #0xc80]
    // 0xa79044: r3 = Null
    //     0xa79044: add             x3, PP, #0x55, lsl #12  ; [pp+0x55c88] Null
    //     0xa79048: ldr             x3, [x3, #0xc88]
    // 0xa7904c: r0 = DefaultTypeTest()
    //     0xa7904c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa79050: ldr             x0, [fp, #0x18]
    // 0xa79054: LoadField: r1 = r0->field_b
    //     0xa79054: ldur            w1, [x0, #0xb]
    // 0xa79058: DecompressPointer r1
    //     0xa79058: add             x1, x1, HEAP, lsl #32
    // 0xa7905c: ldr             x2, [fp, #0x10]
    // 0xa79060: stur            x1, [fp, #-0x10]
    // 0xa79064: LoadField: r3 = r2->field_b
    //     0xa79064: ldur            w3, [x2, #0xb]
    // 0xa79068: DecompressPointer r3
    //     0xa79068: add             x3, x3, HEAP, lsl #32
    // 0xa7906c: stur            x3, [fp, #-8]
    // 0xa79070: cmp             w1, w3
    // 0xa79074: b.eq            #0xa790e4
    // 0xa79078: r16 = Rect
    //     0xa79078: ldr             x16, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0xa7907c: r30 = Rect
    //     0xa7907c: ldr             lr, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0xa79080: stp             lr, x16, [SP, #-0x10]!
    // 0xa79084: r0 = ==()
    //     0xa79084: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xa79088: add             SP, SP, #0x10
    // 0xa7908c: tbnz            w0, #4, #0xa79444
    // 0xa79090: ldur            x0, [fp, #-0x10]
    // 0xa79094: ldur            x1, [fp, #-8]
    // 0xa79098: LoadField: d0 = r1->field_7
    //     0xa79098: ldur            d0, [x1, #7]
    // 0xa7909c: LoadField: d1 = r0->field_7
    //     0xa7909c: ldur            d1, [x0, #7]
    // 0xa790a0: fcmp            d0, d1
    // 0xa790a4: b.vs            #0xa79444
    // 0xa790a8: b.ne            #0xa79444
    // 0xa790ac: LoadField: d0 = r1->field_f
    //     0xa790ac: ldur            d0, [x1, #0xf]
    // 0xa790b0: LoadField: d1 = r0->field_f
    //     0xa790b0: ldur            d1, [x0, #0xf]
    // 0xa790b4: fcmp            d0, d1
    // 0xa790b8: b.vs            #0xa79444
    // 0xa790bc: b.ne            #0xa79444
    // 0xa790c0: LoadField: d0 = r1->field_17
    //     0xa790c0: ldur            d0, [x1, #0x17]
    // 0xa790c4: LoadField: d1 = r0->field_17
    //     0xa790c4: ldur            d1, [x0, #0x17]
    // 0xa790c8: fcmp            d0, d1
    // 0xa790cc: b.vs            #0xa79444
    // 0xa790d0: b.ne            #0xa79444
    // 0xa790d4: LoadField: d0 = r1->field_1f
    //     0xa790d4: ldur            d0, [x1, #0x1f]
    // 0xa790d8: LoadField: d1 = r0->field_1f
    //     0xa790d8: ldur            d1, [x0, #0x1f]
    // 0xa790dc: fcmp            d0, d1
    // 0xa790e0: b.ne            #0xa79444
    // 0xa790e4: r0 = Instance_Size
    //     0xa790e4: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c788] Obj!Size@b5ec91
    //     0xa790e8: ldr             x0, [x0, #0x788]
    // 0xa790ec: LoadField: d0 = r0->field_7
    //     0xa790ec: ldur            d0, [x0, #7]
    // 0xa790f0: fcmp            d0, d0
    // 0xa790f4: b.vs            #0xa79444
    // 0xa790f8: b.ne            #0xa79444
    // 0xa790fc: LoadField: d0 = r0->field_f
    //     0xa790fc: ldur            d0, [x0, #0xf]
    // 0xa79100: fcmp            d0, d0
    // 0xa79104: b.ne            #0xa79444
    // 0xa79108: ldr             x0, [fp, #0x18]
    // 0xa7910c: ldr             x1, [fp, #0x10]
    // 0xa79110: LoadField: r2 = r0->field_17
    //     0xa79110: ldur            w2, [x0, #0x17]
    // 0xa79114: DecompressPointer r2
    //     0xa79114: add             x2, x2, HEAP, lsl #32
    // 0xa79118: stur            x2, [fp, #-0x10]
    // 0xa7911c: LoadField: r3 = r1->field_17
    //     0xa7911c: ldur            w3, [x1, #0x17]
    // 0xa79120: DecompressPointer r3
    //     0xa79120: add             x3, x3, HEAP, lsl #32
    // 0xa79124: stur            x3, [fp, #-8]
    // 0xa79128: cmp             w2, w3
    // 0xa7912c: b.eq            #0xa79168
    // 0xa79130: r16 = Color
    //     0xa79130: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xa79134: ldr             x16, [x16, #0xf18]
    // 0xa79138: r30 = Color
    //     0xa79138: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xa7913c: ldr             lr, [lr, #0xf18]
    // 0xa79140: stp             lr, x16, [SP, #-0x10]!
    // 0xa79144: r0 = ==()
    //     0xa79144: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xa79148: add             SP, SP, #0x10
    // 0xa7914c: tbnz            w0, #4, #0xa79444
    // 0xa79150: ldur            x0, [fp, #-0x10]
    // 0xa79154: ldur            x1, [fp, #-8]
    // 0xa79158: LoadField: r2 = r1->field_7
    //     0xa79158: ldur            x2, [x1, #7]
    // 0xa7915c: LoadField: r1 = r0->field_7
    //     0xa7915c: ldur            x1, [x0, #7]
    // 0xa79160: cmp             x2, x1
    // 0xa79164: b.ne            #0xa79444
    // 0xa79168: d0 = 0.600000
    //     0xa79168: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf90] IMM: double(0.6) from 0x3fe3333333333333
    //     0xa7916c: ldr             d0, [x17, #0xf90]
    // 0xa79170: fcmp            d0, d0
    // 0xa79174: b.ne            #0xa79444
    // 0xa79178: ldr             x0, [fp, #0x18]
    // 0xa7917c: ldr             x1, [fp, #0x10]
    // 0xa79180: LoadField: r2 = r0->field_23
    //     0xa79180: ldur            w2, [x0, #0x23]
    // 0xa79184: DecompressPointer r2
    //     0xa79184: add             x2, x2, HEAP, lsl #32
    // 0xa79188: stur            x2, [fp, #-0x18]
    // 0xa7918c: LoadField: r3 = r1->field_23
    //     0xa7918c: ldur            w3, [x1, #0x23]
    // 0xa79190: DecompressPointer r3
    //     0xa79190: add             x3, x3, HEAP, lsl #32
    // 0xa79194: stur            x3, [fp, #-0x10]
    // 0xa79198: r4 = LoadClassIdInstr(r2)
    //     0xa79198: ldur            x4, [x2, #-1]
    //     0xa7919c: ubfx            x4, x4, #0xc, #0x14
    // 0xa791a0: lsl             x4, x4, #1
    // 0xa791a4: stur            x4, [fp, #-8]
    // 0xa791a8: r17 = 10114
    //     0xa791a8: mov             x17, #0x2782
    // 0xa791ac: cmp             w4, w17
    // 0xa791b0: b.eq            #0xa791c0
    // 0xa791b4: r17 = 10118
    //     0xa791b4: mov             x17, #0x2786
    // 0xa791b8: cmp             w4, w17
    // 0xa791bc: b.ne            #0xa79298
    // 0xa791c0: cmp             w2, w3
    // 0xa791c4: b.eq            #0xa792c8
    // 0xa791c8: stp             x2, x3, [SP, #-0x10]!
    // 0xa791cc: r0 = _haveSameRuntimeType()
    //     0xa791cc: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xa791d0: add             SP, SP, #0x10
    // 0xa791d4: tbnz            w0, #4, #0xa79444
    // 0xa791d8: ldur            x0, [fp, #-0x10]
    // 0xa791dc: r1 = LoadClassIdInstr(r0)
    //     0xa791dc: ldur            x1, [x0, #-1]
    //     0xa791e0: ubfx            x1, x1, #0xc, #0x14
    // 0xa791e4: lsl             x1, x1, #1
    // 0xa791e8: r17 = 10124
    //     0xa791e8: mov             x17, #0x278c
    // 0xa791ec: cmp             w1, w17
    // 0xa791f0: b.gt            #0xa79200
    // 0xa791f4: r17 = 10122
    //     0xa791f4: mov             x17, #0x278a
    // 0xa791f8: cmp             w1, w17
    // 0xa791fc: b.ge            #0xa79218
    // 0xa79200: r17 = 10114
    //     0xa79200: mov             x17, #0x2782
    // 0xa79204: cmp             w1, w17
    // 0xa79208: b.eq            #0xa79218
    // 0xa7920c: r17 = 10118
    //     0xa7920c: mov             x17, #0x2786
    // 0xa79210: cmp             w1, w17
    // 0xa79214: b.ne            #0xa79220
    // 0xa79218: LoadField: r1 = r0->field_7
    //     0xa79218: ldur            x1, [x0, #7]
    // 0xa7921c: b               #0xa79230
    // 0xa79220: LoadField: r1 = r0->field_f
    //     0xa79220: ldur            w1, [x0, #0xf]
    // 0xa79224: DecompressPointer r1
    //     0xa79224: add             x1, x1, HEAP, lsl #32
    // 0xa79228: LoadField: r0 = r1->field_7
    //     0xa79228: ldur            x0, [x1, #7]
    // 0xa7922c: mov             x1, x0
    // 0xa79230: ldur            x0, [fp, #-8]
    // 0xa79234: r17 = 10124
    //     0xa79234: mov             x17, #0x278c
    // 0xa79238: cmp             w0, w17
    // 0xa7923c: b.gt            #0xa7924c
    // 0xa79240: r17 = 10122
    //     0xa79240: mov             x17, #0x278a
    // 0xa79244: cmp             w0, w17
    // 0xa79248: b.ge            #0xa79264
    // 0xa7924c: r17 = 10114
    //     0xa7924c: mov             x17, #0x2782
    // 0xa79250: cmp             w0, w17
    // 0xa79254: b.eq            #0xa79264
    // 0xa79258: r17 = 10118
    //     0xa79258: mov             x17, #0x2786
    // 0xa7925c: cmp             w0, w17
    // 0xa79260: b.ne            #0xa79270
    // 0xa79264: ldur            x2, [fp, #-0x18]
    // 0xa79268: LoadField: r0 = r2->field_7
    //     0xa79268: ldur            x0, [x2, #7]
    // 0xa7926c: b               #0xa79284
    // 0xa79270: ldur            x2, [fp, #-0x18]
    // 0xa79274: LoadField: r0 = r2->field_f
    //     0xa79274: ldur            w0, [x2, #0xf]
    // 0xa79278: DecompressPointer r0
    //     0xa79278: add             x0, x0, HEAP, lsl #32
    // 0xa7927c: LoadField: r2 = r0->field_7
    //     0xa7927c: ldur            x2, [x0, #7]
    // 0xa79280: mov             x0, x2
    // 0xa79284: cmp             x1, x0
    // 0xa79288: b.ne            #0xa79444
    // 0xa7928c: ldr             x0, [fp, #0x18]
    // 0xa79290: ldr             x1, [fp, #0x10]
    // 0xa79294: b               #0xa792c8
    // 0xa79298: mov             x0, x3
    // 0xa7929c: r1 = LoadClassIdInstr(r2)
    //     0xa7929c: ldur            x1, [x2, #-1]
    //     0xa792a0: ubfx            x1, x1, #0xc, #0x14
    // 0xa792a4: stp             x0, x2, [SP, #-0x10]!
    // 0xa792a8: mov             x0, x1
    // 0xa792ac: mov             lr, x0
    // 0xa792b0: ldr             lr, [x21, lr, lsl #3]
    // 0xa792b4: blr             lr
    // 0xa792b8: add             SP, SP, #0x10
    // 0xa792bc: tbnz            w0, #4, #0xa79444
    // 0xa792c0: ldr             x0, [fp, #0x18]
    // 0xa792c4: ldr             x1, [fp, #0x10]
    // 0xa792c8: LoadField: r2 = r0->field_13
    //     0xa792c8: ldur            w2, [x0, #0x13]
    // 0xa792cc: DecompressPointer r2
    //     0xa792cc: add             x2, x2, HEAP, lsl #32
    // 0xa792d0: stur            x2, [fp, #-0x18]
    // 0xa792d4: LoadField: r3 = r1->field_13
    //     0xa792d4: ldur            w3, [x1, #0x13]
    // 0xa792d8: DecompressPointer r3
    //     0xa792d8: add             x3, x3, HEAP, lsl #32
    // 0xa792dc: stur            x3, [fp, #-0x10]
    // 0xa792e0: r4 = LoadClassIdInstr(r2)
    //     0xa792e0: ldur            x4, [x2, #-1]
    //     0xa792e4: ubfx            x4, x4, #0xc, #0x14
    // 0xa792e8: lsl             x4, x4, #1
    // 0xa792ec: stur            x4, [fp, #-8]
    // 0xa792f0: r17 = 10114
    //     0xa792f0: mov             x17, #0x2782
    // 0xa792f4: cmp             w4, w17
    // 0xa792f8: b.eq            #0xa79308
    // 0xa792fc: r17 = 10118
    //     0xa792fc: mov             x17, #0x2786
    // 0xa79300: cmp             w4, w17
    // 0xa79304: b.ne            #0xa793ec
    // 0xa79308: cmp             w2, w3
    // 0xa7930c: b.ne            #0xa7931c
    // 0xa79310: mov             x2, x1
    // 0xa79314: mov             x1, x0
    // 0xa79318: b               #0xa7941c
    // 0xa7931c: stp             x2, x3, [SP, #-0x10]!
    // 0xa79320: r0 = _haveSameRuntimeType()
    //     0xa79320: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xa79324: add             SP, SP, #0x10
    // 0xa79328: tbnz            w0, #4, #0xa79444
    // 0xa7932c: ldur            x0, [fp, #-0x10]
    // 0xa79330: r1 = LoadClassIdInstr(r0)
    //     0xa79330: ldur            x1, [x0, #-1]
    //     0xa79334: ubfx            x1, x1, #0xc, #0x14
    // 0xa79338: lsl             x1, x1, #1
    // 0xa7933c: r17 = 10124
    //     0xa7933c: mov             x17, #0x278c
    // 0xa79340: cmp             w1, w17
    // 0xa79344: b.gt            #0xa79354
    // 0xa79348: r17 = 10122
    //     0xa79348: mov             x17, #0x278a
    // 0xa7934c: cmp             w1, w17
    // 0xa79350: b.ge            #0xa7936c
    // 0xa79354: r17 = 10114
    //     0xa79354: mov             x17, #0x2782
    // 0xa79358: cmp             w1, w17
    // 0xa7935c: b.eq            #0xa7936c
    // 0xa79360: r17 = 10118
    //     0xa79360: mov             x17, #0x2786
    // 0xa79364: cmp             w1, w17
    // 0xa79368: b.ne            #0xa79374
    // 0xa7936c: LoadField: r1 = r0->field_7
    //     0xa7936c: ldur            x1, [x0, #7]
    // 0xa79370: b               #0xa79384
    // 0xa79374: LoadField: r1 = r0->field_f
    //     0xa79374: ldur            w1, [x0, #0xf]
    // 0xa79378: DecompressPointer r1
    //     0xa79378: add             x1, x1, HEAP, lsl #32
    // 0xa7937c: LoadField: r0 = r1->field_7
    //     0xa7937c: ldur            x0, [x1, #7]
    // 0xa79380: mov             x1, x0
    // 0xa79384: ldur            x0, [fp, #-8]
    // 0xa79388: r17 = 10124
    //     0xa79388: mov             x17, #0x278c
    // 0xa7938c: cmp             w0, w17
    // 0xa79390: b.gt            #0xa793a0
    // 0xa79394: r17 = 10122
    //     0xa79394: mov             x17, #0x278a
    // 0xa79398: cmp             w0, w17
    // 0xa7939c: b.ge            #0xa793b8
    // 0xa793a0: r17 = 10114
    //     0xa793a0: mov             x17, #0x2782
    // 0xa793a4: cmp             w0, w17
    // 0xa793a8: b.eq            #0xa793b8
    // 0xa793ac: r17 = 10118
    //     0xa793ac: mov             x17, #0x2786
    // 0xa793b0: cmp             w0, w17
    // 0xa793b4: b.ne            #0xa793c4
    // 0xa793b8: ldur            x2, [fp, #-0x18]
    // 0xa793bc: LoadField: r0 = r2->field_7
    //     0xa793bc: ldur            x0, [x2, #7]
    // 0xa793c0: b               #0xa793d8
    // 0xa793c4: ldur            x2, [fp, #-0x18]
    // 0xa793c8: LoadField: r0 = r2->field_f
    //     0xa793c8: ldur            w0, [x2, #0xf]
    // 0xa793cc: DecompressPointer r0
    //     0xa793cc: add             x0, x0, HEAP, lsl #32
    // 0xa793d0: LoadField: r2 = r0->field_7
    //     0xa793d0: ldur            x2, [x0, #7]
    // 0xa793d4: mov             x0, x2
    // 0xa793d8: cmp             x1, x0
    // 0xa793dc: b.ne            #0xa79444
    // 0xa793e0: ldr             x1, [fp, #0x18]
    // 0xa793e4: ldr             x2, [fp, #0x10]
    // 0xa793e8: b               #0xa7941c
    // 0xa793ec: mov             x0, x3
    // 0xa793f0: r1 = LoadClassIdInstr(r2)
    //     0xa793f0: ldur            x1, [x2, #-1]
    //     0xa793f4: ubfx            x1, x1, #0xc, #0x14
    // 0xa793f8: stp             x0, x2, [SP, #-0x10]!
    // 0xa793fc: mov             x0, x1
    // 0xa79400: mov             lr, x0
    // 0xa79404: ldr             lr, [x21, lr, lsl #3]
    // 0xa79408: blr             lr
    // 0xa7940c: add             SP, SP, #0x10
    // 0xa79410: tbnz            w0, #4, #0xa79444
    // 0xa79414: ldr             x1, [fp, #0x18]
    // 0xa79418: ldr             x2, [fp, #0x10]
    // 0xa7941c: LoadField: r3 = r1->field_27
    //     0xa7941c: ldur            w3, [x1, #0x27]
    // 0xa79420: DecompressPointer r3
    //     0xa79420: add             x3, x3, HEAP, lsl #32
    // 0xa79424: LoadField: r1 = r2->field_27
    //     0xa79424: ldur            w1, [x2, #0x27]
    // 0xa79428: DecompressPointer r1
    //     0xa79428: add             x1, x1, HEAP, lsl #32
    // 0xa7942c: cmp             w3, w1
    // 0xa79430: r16 = true
    //     0xa79430: add             x16, NULL, #0x20  ; true
    // 0xa79434: r17 = false
    //     0xa79434: add             x17, NULL, #0x30  ; false
    // 0xa79438: csel            x2, x16, x17, ne
    // 0xa7943c: mov             x0, x2
    // 0xa79440: b               #0xa79448
    // 0xa79444: r0 = true
    //     0xa79444: add             x0, NULL, #0x20  ; true
    // 0xa79448: LeaveFrame
    //     0xa79448: mov             SP, fp
    //     0xa7944c: ldp             fp, lr, [SP], #0x10
    // 0xa79450: ret
    //     0xa79450: ret             
    // 0xa79454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa79454: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa79458: b               #0xa78fc8
  }
}

// class id: 4497, size: 0x8, field offset: 0x8
//   const constructor, 
class EditorCropLayerPainter extends Object {

  _ paint(/* No info */) {
    // ** addr: 0xa6cd08, size: 0x84
    // 0xa6cd08: EnterFrame
    //     0xa6cd08: stp             fp, lr, [SP, #-0x10]!
    //     0xa6cd0c: mov             fp, SP
    // 0xa6cd10: CheckStackOverflow
    //     0xa6cd10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6cd14: cmp             SP, x16
    //     0xa6cd18: b.ls            #0xa6cd84
    // 0xa6cd1c: ldr             x16, [fp, #0x28]
    // 0xa6cd20: ldr             lr, [fp, #0x20]
    // 0xa6cd24: stp             lr, x16, [SP, #-0x10]!
    // 0xa6cd28: ldr             x16, [fp, #0x18]
    // 0xa6cd2c: ldr             lr, [fp, #0x10]
    // 0xa6cd30: stp             lr, x16, [SP, #-0x10]!
    // 0xa6cd34: r0 = paintMask()
    //     0xa6cd34: bl              #0xa6d670  ; [package:extended_image/src/editor/editor_utils.dart] EditorCropLayerPainter::paintMask
    // 0xa6cd38: add             SP, SP, #0x20
    // 0xa6cd3c: ldr             x16, [fp, #0x28]
    // 0xa6cd40: ldr             lr, [fp, #0x20]
    // 0xa6cd44: stp             lr, x16, [SP, #-0x10]!
    // 0xa6cd48: ldr             x16, [fp, #0x10]
    // 0xa6cd4c: SaveReg r16
    //     0xa6cd4c: str             x16, [SP, #-8]!
    // 0xa6cd50: r0 = paintLines()
    //     0xa6cd50: bl              #0xa6d3e0  ; [package:extended_image/src/editor/editor_utils.dart] EditorCropLayerPainter::paintLines
    // 0xa6cd54: add             SP, SP, #0x18
    // 0xa6cd58: ldr             x16, [fp, #0x28]
    // 0xa6cd5c: ldr             lr, [fp, #0x20]
    // 0xa6cd60: stp             lr, x16, [SP, #-0x10]!
    // 0xa6cd64: ldr             x16, [fp, #0x10]
    // 0xa6cd68: SaveReg r16
    //     0xa6cd68: str             x16, [SP, #-8]!
    // 0xa6cd6c: r0 = paintCorners()
    //     0xa6cd6c: bl              #0xa6cd8c  ; [package:extended_image/src/editor/editor_utils.dart] EditorCropLayerPainter::paintCorners
    // 0xa6cd70: add             SP, SP, #0x18
    // 0xa6cd74: r0 = Null
    //     0xa6cd74: mov             x0, NULL
    // 0xa6cd78: LeaveFrame
    //     0xa6cd78: mov             SP, fp
    //     0xa6cd7c: ldp             fp, lr, [SP], #0x10
    // 0xa6cd80: ret
    //     0xa6cd80: ret             
    // 0xa6cd84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6cd84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6cd88: b               #0xa6cd1c
  }
  _ paintCorners(/* No info */) {
    // ** addr: 0xa6cd8c, size: 0x654
    // 0xa6cd8c: EnterFrame
    //     0xa6cd8c: stp             fp, lr, [SP, #-0x10]!
    //     0xa6cd90: mov             fp, SP
    // 0xa6cd94: AllocStack(0x78)
    //     0xa6cd94: sub             SP, SP, #0x78
    // 0xa6cd98: r0 = Instance_Size
    //     0xa6cd98: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c788] Obj!Size@b5ec91
    //     0xa6cd9c: ldr             x0, [x0, #0x788]
    // 0xa6cda0: CheckStackOverflow
    //     0xa6cda0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6cda4: cmp             SP, x16
    //     0xa6cda8: b.ls            #0xa6d364
    // 0xa6cdac: ldr             x1, [fp, #0x10]
    // 0xa6cdb0: LoadField: r2 = r1->field_b
    //     0xa6cdb0: ldur            w2, [x1, #0xb]
    // 0xa6cdb4: DecompressPointer r2
    //     0xa6cdb4: add             x2, x2, HEAP, lsl #32
    // 0xa6cdb8: stur            x2, [fp, #-8]
    // 0xa6cdbc: LoadField: d0 = r0->field_7
    //     0xa6cdbc: ldur            d0, [x0, #7]
    // 0xa6cdc0: stur            d0, [fp, #-0x40]
    // 0xa6cdc4: LoadField: d1 = r0->field_f
    //     0xa6cdc4: ldur            d1, [x0, #0xf]
    // 0xa6cdc8: stur            d1, [fp, #-0x38]
    // 0xa6cdcc: r16 = 112
    //     0xa6cdcc: mov             x16, #0x70
    // 0xa6cdd0: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6cdd4: r0 = ByteData()
    //     0xa6cdd4: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6cdd8: add             SP, SP, #0x10
    // 0xa6cddc: stur            x0, [fp, #-0x10]
    // 0xa6cde0: r0 = Paint()
    //     0xa6cde0: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6cde4: mov             x1, x0
    // 0xa6cde8: ldur            x0, [fp, #-0x10]
    // 0xa6cdec: stur            x1, [fp, #-0x18]
    // 0xa6cdf0: StoreField: r1->field_7 = r0
    //     0xa6cdf0: stur            w0, [x1, #7]
    // 0xa6cdf4: ldr             x2, [fp, #0x10]
    // 0xa6cdf8: LoadField: r3 = r2->field_13
    //     0xa6cdf8: ldur            w3, [x2, #0x13]
    // 0xa6cdfc: DecompressPointer r3
    //     0xa6cdfc: add             x3, x3, HEAP, lsl #32
    // 0xa6ce00: r2 = LoadClassIdInstr(r3)
    //     0xa6ce00: ldur            x2, [x3, #-1]
    //     0xa6ce04: ubfx            x2, x2, #0xc, #0x14
    // 0xa6ce08: lsl             x2, x2, #1
    // 0xa6ce0c: r17 = 10124
    //     0xa6ce0c: mov             x17, #0x278c
    // 0xa6ce10: cmp             w2, w17
    // 0xa6ce14: b.gt            #0xa6ce24
    // 0xa6ce18: r17 = 10122
    //     0xa6ce18: mov             x17, #0x278a
    // 0xa6ce1c: cmp             w2, w17
    // 0xa6ce20: b.ge            #0xa6ce3c
    // 0xa6ce24: r17 = 10114
    //     0xa6ce24: mov             x17, #0x2782
    // 0xa6ce28: cmp             w2, w17
    // 0xa6ce2c: b.eq            #0xa6ce3c
    // 0xa6ce30: r17 = 10118
    //     0xa6ce30: mov             x17, #0x2786
    // 0xa6ce34: cmp             w2, w17
    // 0xa6ce38: b.ne            #0xa6ce48
    // 0xa6ce3c: LoadField: r2 = r3->field_7
    //     0xa6ce3c: ldur            x2, [x3, #7]
    // 0xa6ce40: mov             x3, x2
    // 0xa6ce44: b               #0xa6ce54
    // 0xa6ce48: LoadField: r2 = r3->field_f
    //     0xa6ce48: ldur            w2, [x3, #0xf]
    // 0xa6ce4c: DecompressPointer r2
    //     0xa6ce4c: add             x2, x2, HEAP, lsl #32
    // 0xa6ce50: LoadField: r3 = r2->field_7
    //     0xa6ce50: ldur            x3, [x2, #7]
    // 0xa6ce54: ldur            x2, [fp, #-8]
    // 0xa6ce58: ldur            d0, [fp, #-0x40]
    // 0xa6ce5c: ldur            d1, [fp, #-0x38]
    // 0xa6ce60: eor             x4, x3, #0xff000000
    // 0xa6ce64: LoadField: r3 = r0->field_17
    //     0xa6ce64: ldur            w3, [x0, #0x17]
    // 0xa6ce68: DecompressPointer r3
    //     0xa6ce68: add             x3, x3, HEAP, lsl #32
    // 0xa6ce6c: sxtw            x4, w4
    // 0xa6ce70: LoadField: r0 = r3->field_7
    //     0xa6ce70: ldur            x0, [x3, #7]
    // 0xa6ce74: str             w4, [x0, #4]
    // 0xa6ce78: LoadField: r0 = r3->field_7
    //     0xa6ce78: ldur            x0, [x3, #7]
    // 0xa6ce7c: str             wzr, [x0, #0xc]
    // 0xa6ce80: r0 = Path()
    //     0xa6ce80: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xa6ce84: stur            x0, [fp, #-0x10]
    // 0xa6ce88: SaveReg r0
    //     0xa6ce88: str             x0, [SP, #-8]!
    // 0xa6ce8c: r0 = _constructor()
    //     0xa6ce8c: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xa6ce90: add             SP, SP, #8
    // 0xa6ce94: ldur            x0, [fp, #-8]
    // 0xa6ce98: LoadField: d0 = r0->field_7
    //     0xa6ce98: ldur            d0, [x0, #7]
    // 0xa6ce9c: stur            d0, [fp, #-0x50]
    // 0xa6cea0: LoadField: d1 = r0->field_f
    //     0xa6cea0: ldur            d1, [x0, #0xf]
    // 0xa6cea4: stur            d1, [fp, #-0x48]
    // 0xa6cea8: r1 = inline_Allocate_Double()
    //     0xa6cea8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa6ceac: add             x1, x1, #0x10
    //     0xa6ceb0: cmp             x2, x1
    //     0xa6ceb4: b.ls            #0xa6d36c
    //     0xa6ceb8: str             x1, [THR, #0x60]  ; THR::top
    //     0xa6cebc: sub             x1, x1, #0xf
    //     0xa6cec0: mov             x2, #0xd108
    //     0xa6cec4: movk            x2, #3, lsl #16
    //     0xa6cec8: stur            x2, [x1, #-1]
    // 0xa6cecc: StoreField: r1->field_7 = d0
    //     0xa6cecc: stur            d0, [x1, #7]
    // 0xa6ced0: stur            x1, [fp, #-0x20]
    // 0xa6ced4: ldur            x16, [fp, #-0x10]
    // 0xa6ced8: stp             x1, x16, [SP, #-0x10]!
    // 0xa6cedc: SaveReg d1
    //     0xa6cedc: str             d1, [SP, #-8]!
    // 0xa6cee0: r0 = moveTo()
    //     0xa6cee0: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0xa6cee4: add             SP, SP, #0x18
    // 0xa6cee8: ldur            d0, [fp, #-0x50]
    // 0xa6ceec: ldur            d1, [fp, #-0x40]
    // 0xa6cef0: fadd            d2, d0, d1
    // 0xa6cef4: r0 = inline_Allocate_Double()
    //     0xa6cef4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6cef8: add             x0, x0, #0x10
    //     0xa6cefc: cmp             x1, x0
    //     0xa6cf00: b.ls            #0xa6d388
    //     0xa6cf04: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6cf08: sub             x0, x0, #0xf
    //     0xa6cf0c: mov             x1, #0xd108
    //     0xa6cf10: movk            x1, #3, lsl #16
    //     0xa6cf14: stur            x1, [x0, #-1]
    // 0xa6cf18: StoreField: r0->field_7 = d2
    //     0xa6cf18: stur            d2, [x0, #7]
    // 0xa6cf1c: stur            x0, [fp, #-0x28]
    // 0xa6cf20: ldur            x16, [fp, #-0x10]
    // 0xa6cf24: stp             x0, x16, [SP, #-0x10]!
    // 0xa6cf28: ldur            d2, [fp, #-0x48]
    // 0xa6cf2c: SaveReg d2
    //     0xa6cf2c: str             d2, [SP, #-8]!
    // 0xa6cf30: r0 = lineTo()
    //     0xa6cf30: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6cf34: add             SP, SP, #0x18
    // 0xa6cf38: ldur            d0, [fp, #-0x48]
    // 0xa6cf3c: ldur            d1, [fp, #-0x38]
    // 0xa6cf40: fadd            d2, d0, d1
    // 0xa6cf44: stur            d2, [fp, #-0x58]
    // 0xa6cf48: ldur            x16, [fp, #-0x10]
    // 0xa6cf4c: ldur            lr, [fp, #-0x28]
    // 0xa6cf50: stp             lr, x16, [SP, #-0x10]!
    // 0xa6cf54: SaveReg d2
    //     0xa6cf54: str             d2, [SP, #-8]!
    // 0xa6cf58: r0 = lineTo()
    //     0xa6cf58: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6cf5c: add             SP, SP, #0x18
    // 0xa6cf60: ldur            d1, [fp, #-0x50]
    // 0xa6cf64: ldur            d0, [fp, #-0x38]
    // 0xa6cf68: fadd            d2, d1, d0
    // 0xa6cf6c: r0 = inline_Allocate_Double()
    //     0xa6cf6c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6cf70: add             x0, x0, #0x10
    //     0xa6cf74: cmp             x1, x0
    //     0xa6cf78: b.ls            #0xa6d3a0
    //     0xa6cf7c: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6cf80: sub             x0, x0, #0xf
    //     0xa6cf84: mov             x1, #0xd108
    //     0xa6cf88: movk            x1, #3, lsl #16
    //     0xa6cf8c: stur            x1, [x0, #-1]
    // 0xa6cf90: StoreField: r0->field_7 = d2
    //     0xa6cf90: stur            d2, [x0, #7]
    // 0xa6cf94: stur            x0, [fp, #-0x30]
    // 0xa6cf98: ldur            x16, [fp, #-0x10]
    // 0xa6cf9c: stp             x0, x16, [SP, #-0x10]!
    // 0xa6cfa0: ldur            d1, [fp, #-0x58]
    // 0xa6cfa4: SaveReg d1
    //     0xa6cfa4: str             d1, [SP, #-8]!
    // 0xa6cfa8: r0 = lineTo()
    //     0xa6cfa8: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6cfac: add             SP, SP, #0x18
    // 0xa6cfb0: ldur            d0, [fp, #-0x48]
    // 0xa6cfb4: ldur            d1, [fp, #-0x40]
    // 0xa6cfb8: fadd            d2, d0, d1
    // 0xa6cfbc: stur            d2, [fp, #-0x50]
    // 0xa6cfc0: ldur            x16, [fp, #-0x10]
    // 0xa6cfc4: ldur            lr, [fp, #-0x30]
    // 0xa6cfc8: stp             lr, x16, [SP, #-0x10]!
    // 0xa6cfcc: SaveReg d2
    //     0xa6cfcc: str             d2, [SP, #-8]!
    // 0xa6cfd0: r0 = lineTo()
    //     0xa6cfd0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6cfd4: add             SP, SP, #0x18
    // 0xa6cfd8: ldur            x16, [fp, #-0x10]
    // 0xa6cfdc: ldur            lr, [fp, #-0x20]
    // 0xa6cfe0: stp             lr, x16, [SP, #-0x10]!
    // 0xa6cfe4: ldur            d0, [fp, #-0x50]
    // 0xa6cfe8: SaveReg d0
    //     0xa6cfe8: str             d0, [SP, #-8]!
    // 0xa6cfec: r0 = lineTo()
    //     0xa6cfec: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6cff0: add             SP, SP, #0x18
    // 0xa6cff4: ldr             x16, [fp, #0x18]
    // 0xa6cff8: ldur            lr, [fp, #-0x10]
    // 0xa6cffc: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d000: ldur            x16, [fp, #-0x18]
    // 0xa6d004: SaveReg r16
    //     0xa6d004: str             x16, [SP, #-8]!
    // 0xa6d008: r0 = drawPath()
    //     0xa6d008: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa6d00c: add             SP, SP, #0x18
    // 0xa6d010: r0 = Path()
    //     0xa6d010: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xa6d014: stur            x0, [fp, #-0x10]
    // 0xa6d018: SaveReg r0
    //     0xa6d018: str             x0, [SP, #-8]!
    // 0xa6d01c: r0 = _constructor()
    //     0xa6d01c: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xa6d020: add             SP, SP, #8
    // 0xa6d024: ldur            x0, [fp, #-8]
    // 0xa6d028: LoadField: d0 = r0->field_1f
    //     0xa6d028: ldur            d0, [x0, #0x1f]
    // 0xa6d02c: stur            d0, [fp, #-0x60]
    // 0xa6d030: ldur            x16, [fp, #-0x10]
    // 0xa6d034: ldur            lr, [fp, #-0x20]
    // 0xa6d038: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d03c: SaveReg d0
    //     0xa6d03c: str             d0, [SP, #-8]!
    // 0xa6d040: r0 = moveTo()
    //     0xa6d040: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0xa6d044: add             SP, SP, #0x18
    // 0xa6d048: ldur            x16, [fp, #-0x10]
    // 0xa6d04c: ldur            lr, [fp, #-0x28]
    // 0xa6d050: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d054: ldur            d0, [fp, #-0x60]
    // 0xa6d058: SaveReg d0
    //     0xa6d058: str             d0, [SP, #-8]!
    // 0xa6d05c: r0 = lineTo()
    //     0xa6d05c: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d060: add             SP, SP, #0x18
    // 0xa6d064: ldur            d0, [fp, #-0x60]
    // 0xa6d068: ldur            d1, [fp, #-0x38]
    // 0xa6d06c: fsub            d2, d0, d1
    // 0xa6d070: stur            d2, [fp, #-0x68]
    // 0xa6d074: ldur            x16, [fp, #-0x10]
    // 0xa6d078: ldur            lr, [fp, #-0x28]
    // 0xa6d07c: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d080: SaveReg d2
    //     0xa6d080: str             d2, [SP, #-8]!
    // 0xa6d084: r0 = lineTo()
    //     0xa6d084: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d088: add             SP, SP, #0x18
    // 0xa6d08c: ldur            x16, [fp, #-0x10]
    // 0xa6d090: ldur            lr, [fp, #-0x30]
    // 0xa6d094: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d098: ldur            d0, [fp, #-0x68]
    // 0xa6d09c: SaveReg d0
    //     0xa6d09c: str             d0, [SP, #-8]!
    // 0xa6d0a0: r0 = lineTo()
    //     0xa6d0a0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d0a4: add             SP, SP, #0x18
    // 0xa6d0a8: ldur            d0, [fp, #-0x60]
    // 0xa6d0ac: ldur            d1, [fp, #-0x40]
    // 0xa6d0b0: fsub            d2, d0, d1
    // 0xa6d0b4: stur            d2, [fp, #-0x70]
    // 0xa6d0b8: ldur            x16, [fp, #-0x10]
    // 0xa6d0bc: ldur            lr, [fp, #-0x30]
    // 0xa6d0c0: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d0c4: SaveReg d2
    //     0xa6d0c4: str             d2, [SP, #-8]!
    // 0xa6d0c8: r0 = lineTo()
    //     0xa6d0c8: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d0cc: add             SP, SP, #0x18
    // 0xa6d0d0: ldur            x16, [fp, #-0x10]
    // 0xa6d0d4: ldur            lr, [fp, #-0x20]
    // 0xa6d0d8: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d0dc: ldur            d0, [fp, #-0x70]
    // 0xa6d0e0: SaveReg d0
    //     0xa6d0e0: str             d0, [SP, #-8]!
    // 0xa6d0e4: r0 = lineTo()
    //     0xa6d0e4: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d0e8: add             SP, SP, #0x18
    // 0xa6d0ec: ldr             x16, [fp, #0x18]
    // 0xa6d0f0: ldur            lr, [fp, #-0x10]
    // 0xa6d0f4: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d0f8: ldur            x16, [fp, #-0x18]
    // 0xa6d0fc: SaveReg r16
    //     0xa6d0fc: str             x16, [SP, #-8]!
    // 0xa6d100: r0 = drawPath()
    //     0xa6d100: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa6d104: add             SP, SP, #0x18
    // 0xa6d108: r0 = Path()
    //     0xa6d108: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xa6d10c: stur            x0, [fp, #-0x10]
    // 0xa6d110: SaveReg r0
    //     0xa6d110: str             x0, [SP, #-8]!
    // 0xa6d114: r0 = _constructor()
    //     0xa6d114: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xa6d118: add             SP, SP, #8
    // 0xa6d11c: ldur            x0, [fp, #-8]
    // 0xa6d120: LoadField: d0 = r0->field_17
    //     0xa6d120: ldur            d0, [x0, #0x17]
    // 0xa6d124: stur            d0, [fp, #-0x78]
    // 0xa6d128: r0 = inline_Allocate_Double()
    //     0xa6d128: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6d12c: add             x0, x0, #0x10
    //     0xa6d130: cmp             x1, x0
    //     0xa6d134: b.ls            #0xa6d3b0
    //     0xa6d138: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6d13c: sub             x0, x0, #0xf
    //     0xa6d140: mov             x1, #0xd108
    //     0xa6d144: movk            x1, #3, lsl #16
    //     0xa6d148: stur            x1, [x0, #-1]
    // 0xa6d14c: StoreField: r0->field_7 = d0
    //     0xa6d14c: stur            d0, [x0, #7]
    // 0xa6d150: stur            x0, [fp, #-8]
    // 0xa6d154: ldur            x16, [fp, #-0x10]
    // 0xa6d158: stp             x0, x16, [SP, #-0x10]!
    // 0xa6d15c: ldur            d1, [fp, #-0x48]
    // 0xa6d160: SaveReg d1
    //     0xa6d160: str             d1, [SP, #-8]!
    // 0xa6d164: r0 = moveTo()
    //     0xa6d164: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0xa6d168: add             SP, SP, #0x18
    // 0xa6d16c: ldur            d0, [fp, #-0x78]
    // 0xa6d170: ldur            d1, [fp, #-0x40]
    // 0xa6d174: fsub            d2, d0, d1
    // 0xa6d178: r0 = inline_Allocate_Double()
    //     0xa6d178: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6d17c: add             x0, x0, #0x10
    //     0xa6d180: cmp             x1, x0
    //     0xa6d184: b.ls            #0xa6d3c0
    //     0xa6d188: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6d18c: sub             x0, x0, #0xf
    //     0xa6d190: mov             x1, #0xd108
    //     0xa6d194: movk            x1, #3, lsl #16
    //     0xa6d198: stur            x1, [x0, #-1]
    // 0xa6d19c: StoreField: r0->field_7 = d2
    //     0xa6d19c: stur            d2, [x0, #7]
    // 0xa6d1a0: stur            x0, [fp, #-0x20]
    // 0xa6d1a4: ldur            x16, [fp, #-0x10]
    // 0xa6d1a8: stp             x0, x16, [SP, #-0x10]!
    // 0xa6d1ac: ldur            d1, [fp, #-0x48]
    // 0xa6d1b0: SaveReg d1
    //     0xa6d1b0: str             d1, [SP, #-8]!
    // 0xa6d1b4: r0 = lineTo()
    //     0xa6d1b4: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d1b8: add             SP, SP, #0x18
    // 0xa6d1bc: ldur            x16, [fp, #-0x10]
    // 0xa6d1c0: ldur            lr, [fp, #-0x20]
    // 0xa6d1c4: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d1c8: ldur            d0, [fp, #-0x58]
    // 0xa6d1cc: SaveReg d0
    //     0xa6d1cc: str             d0, [SP, #-8]!
    // 0xa6d1d0: r0 = lineTo()
    //     0xa6d1d0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d1d4: add             SP, SP, #0x18
    // 0xa6d1d8: ldur            d0, [fp, #-0x78]
    // 0xa6d1dc: ldur            d1, [fp, #-0x38]
    // 0xa6d1e0: fsub            d2, d0, d1
    // 0xa6d1e4: r0 = inline_Allocate_Double()
    //     0xa6d1e4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6d1e8: add             x0, x0, #0x10
    //     0xa6d1ec: cmp             x1, x0
    //     0xa6d1f0: b.ls            #0xa6d3d0
    //     0xa6d1f4: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6d1f8: sub             x0, x0, #0xf
    //     0xa6d1fc: mov             x1, #0xd108
    //     0xa6d200: movk            x1, #3, lsl #16
    //     0xa6d204: stur            x1, [x0, #-1]
    // 0xa6d208: StoreField: r0->field_7 = d2
    //     0xa6d208: stur            d2, [x0, #7]
    // 0xa6d20c: stur            x0, [fp, #-0x28]
    // 0xa6d210: ldur            x16, [fp, #-0x10]
    // 0xa6d214: stp             x0, x16, [SP, #-0x10]!
    // 0xa6d218: ldur            d0, [fp, #-0x58]
    // 0xa6d21c: SaveReg d0
    //     0xa6d21c: str             d0, [SP, #-8]!
    // 0xa6d220: r0 = lineTo()
    //     0xa6d220: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d224: add             SP, SP, #0x18
    // 0xa6d228: ldur            x16, [fp, #-0x10]
    // 0xa6d22c: ldur            lr, [fp, #-0x28]
    // 0xa6d230: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d234: ldur            d0, [fp, #-0x50]
    // 0xa6d238: SaveReg d0
    //     0xa6d238: str             d0, [SP, #-8]!
    // 0xa6d23c: r0 = lineTo()
    //     0xa6d23c: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d240: add             SP, SP, #0x18
    // 0xa6d244: ldur            x16, [fp, #-0x10]
    // 0xa6d248: ldur            lr, [fp, #-8]
    // 0xa6d24c: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d250: ldur            d0, [fp, #-0x50]
    // 0xa6d254: SaveReg d0
    //     0xa6d254: str             d0, [SP, #-8]!
    // 0xa6d258: r0 = lineTo()
    //     0xa6d258: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d25c: add             SP, SP, #0x18
    // 0xa6d260: ldr             x16, [fp, #0x18]
    // 0xa6d264: ldur            lr, [fp, #-0x10]
    // 0xa6d268: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d26c: ldur            x16, [fp, #-0x18]
    // 0xa6d270: SaveReg r16
    //     0xa6d270: str             x16, [SP, #-8]!
    // 0xa6d274: r0 = drawPath()
    //     0xa6d274: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa6d278: add             SP, SP, #0x18
    // 0xa6d27c: r0 = Path()
    //     0xa6d27c: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xa6d280: stur            x0, [fp, #-0x10]
    // 0xa6d284: SaveReg r0
    //     0xa6d284: str             x0, [SP, #-8]!
    // 0xa6d288: r0 = _constructor()
    //     0xa6d288: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xa6d28c: add             SP, SP, #8
    // 0xa6d290: ldur            x16, [fp, #-0x10]
    // 0xa6d294: ldur            lr, [fp, #-8]
    // 0xa6d298: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d29c: ldur            d0, [fp, #-0x60]
    // 0xa6d2a0: SaveReg d0
    //     0xa6d2a0: str             d0, [SP, #-8]!
    // 0xa6d2a4: r0 = moveTo()
    //     0xa6d2a4: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0xa6d2a8: add             SP, SP, #0x18
    // 0xa6d2ac: ldur            x16, [fp, #-0x10]
    // 0xa6d2b0: ldur            lr, [fp, #-0x20]
    // 0xa6d2b4: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d2b8: ldur            d0, [fp, #-0x60]
    // 0xa6d2bc: SaveReg d0
    //     0xa6d2bc: str             d0, [SP, #-8]!
    // 0xa6d2c0: r0 = lineTo()
    //     0xa6d2c0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d2c4: add             SP, SP, #0x18
    // 0xa6d2c8: ldur            x16, [fp, #-0x10]
    // 0xa6d2cc: ldur            lr, [fp, #-0x20]
    // 0xa6d2d0: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d2d4: ldur            d0, [fp, #-0x68]
    // 0xa6d2d8: SaveReg d0
    //     0xa6d2d8: str             d0, [SP, #-8]!
    // 0xa6d2dc: r0 = lineTo()
    //     0xa6d2dc: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d2e0: add             SP, SP, #0x18
    // 0xa6d2e4: ldur            x16, [fp, #-0x10]
    // 0xa6d2e8: ldur            lr, [fp, #-0x28]
    // 0xa6d2ec: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d2f0: ldur            d0, [fp, #-0x68]
    // 0xa6d2f4: SaveReg d0
    //     0xa6d2f4: str             d0, [SP, #-8]!
    // 0xa6d2f8: r0 = lineTo()
    //     0xa6d2f8: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d2fc: add             SP, SP, #0x18
    // 0xa6d300: ldur            x16, [fp, #-0x10]
    // 0xa6d304: ldur            lr, [fp, #-0x28]
    // 0xa6d308: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d30c: ldur            d0, [fp, #-0x70]
    // 0xa6d310: SaveReg d0
    //     0xa6d310: str             d0, [SP, #-8]!
    // 0xa6d314: r0 = lineTo()
    //     0xa6d314: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d318: add             SP, SP, #0x18
    // 0xa6d31c: ldur            x16, [fp, #-0x10]
    // 0xa6d320: ldur            lr, [fp, #-8]
    // 0xa6d324: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d328: ldur            d0, [fp, #-0x70]
    // 0xa6d32c: SaveReg d0
    //     0xa6d32c: str             d0, [SP, #-8]!
    // 0xa6d330: r0 = lineTo()
    //     0xa6d330: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6d334: add             SP, SP, #0x18
    // 0xa6d338: ldr             x16, [fp, #0x18]
    // 0xa6d33c: ldur            lr, [fp, #-0x10]
    // 0xa6d340: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d344: ldur            x16, [fp, #-0x18]
    // 0xa6d348: SaveReg r16
    //     0xa6d348: str             x16, [SP, #-8]!
    // 0xa6d34c: r0 = drawPath()
    //     0xa6d34c: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa6d350: add             SP, SP, #0x18
    // 0xa6d354: r0 = Null
    //     0xa6d354: mov             x0, NULL
    // 0xa6d358: LeaveFrame
    //     0xa6d358: mov             SP, fp
    //     0xa6d35c: ldp             fp, lr, [SP], #0x10
    // 0xa6d360: ret
    //     0xa6d360: ret             
    // 0xa6d364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6d364: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6d368: b               #0xa6cdac
    // 0xa6d36c: stp             q0, q1, [SP, #-0x20]!
    // 0xa6d370: SaveReg r0
    //     0xa6d370: str             x0, [SP, #-8]!
    // 0xa6d374: r0 = AllocateDouble()
    //     0xa6d374: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6d378: mov             x1, x0
    // 0xa6d37c: RestoreReg r0
    //     0xa6d37c: ldr             x0, [SP], #8
    // 0xa6d380: ldp             q0, q1, [SP], #0x20
    // 0xa6d384: b               #0xa6cecc
    // 0xa6d388: stp             q1, q2, [SP, #-0x20]!
    // 0xa6d38c: SaveReg d0
    //     0xa6d38c: str             q0, [SP, #-0x10]!
    // 0xa6d390: r0 = AllocateDouble()
    //     0xa6d390: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6d394: RestoreReg d0
    //     0xa6d394: ldr             q0, [SP], #0x10
    // 0xa6d398: ldp             q1, q2, [SP], #0x20
    // 0xa6d39c: b               #0xa6cf18
    // 0xa6d3a0: stp             q0, q2, [SP, #-0x20]!
    // 0xa6d3a4: r0 = AllocateDouble()
    //     0xa6d3a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6d3a8: ldp             q0, q2, [SP], #0x20
    // 0xa6d3ac: b               #0xa6cf90
    // 0xa6d3b0: SaveReg d0
    //     0xa6d3b0: str             q0, [SP, #-0x10]!
    // 0xa6d3b4: r0 = AllocateDouble()
    //     0xa6d3b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6d3b8: RestoreReg d0
    //     0xa6d3b8: ldr             q0, [SP], #0x10
    // 0xa6d3bc: b               #0xa6d14c
    // 0xa6d3c0: stp             q0, q2, [SP, #-0x20]!
    // 0xa6d3c4: r0 = AllocateDouble()
    //     0xa6d3c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6d3c8: ldp             q0, q2, [SP], #0x20
    // 0xa6d3cc: b               #0xa6d19c
    // 0xa6d3d0: SaveReg d2
    //     0xa6d3d0: str             q2, [SP, #-0x10]!
    // 0xa6d3d4: r0 = AllocateDouble()
    //     0xa6d3d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6d3d8: RestoreReg d2
    //     0xa6d3d8: ldr             q2, [SP], #0x10
    // 0xa6d3dc: b               #0xa6d208
  }
  _ paintLines(/* No info */) {
    // ** addr: 0xa6d3e0, size: 0x290
    // 0xa6d3e0: EnterFrame
    //     0xa6d3e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa6d3e4: mov             fp, SP
    // 0xa6d3e8: AllocStack(0x58)
    //     0xa6d3e8: sub             SP, SP, #0x58
    // 0xa6d3ec: CheckStackOverflow
    //     0xa6d3ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6d3f0: cmp             SP, x16
    //     0xa6d3f4: b.ls            #0xa6d668
    // 0xa6d3f8: ldr             x0, [fp, #0x10]
    // 0xa6d3fc: LoadField: r1 = r0->field_17
    //     0xa6d3fc: ldur            w1, [x0, #0x17]
    // 0xa6d400: DecompressPointer r1
    //     0xa6d400: add             x1, x1, HEAP, lsl #32
    // 0xa6d404: stur            x1, [fp, #-0x18]
    // 0xa6d408: LoadField: r2 = r0->field_b
    //     0xa6d408: ldur            w2, [x0, #0xb]
    // 0xa6d40c: DecompressPointer r2
    //     0xa6d40c: add             x2, x2, HEAP, lsl #32
    // 0xa6d410: stur            x2, [fp, #-0x10]
    // 0xa6d414: LoadField: r3 = r0->field_27
    //     0xa6d414: ldur            w3, [x0, #0x27]
    // 0xa6d418: DecompressPointer r3
    //     0xa6d418: add             x3, x3, HEAP, lsl #32
    // 0xa6d41c: stur            x3, [fp, #-8]
    // 0xa6d420: r16 = 112
    //     0xa6d420: mov             x16, #0x70
    // 0xa6d424: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6d428: r0 = ByteData()
    //     0xa6d428: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6d42c: add             SP, SP, #0x10
    // 0xa6d430: stur            x0, [fp, #-0x20]
    // 0xa6d434: r0 = Paint()
    //     0xa6d434: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6d438: mov             x1, x0
    // 0xa6d43c: ldur            x0, [fp, #-0x20]
    // 0xa6d440: stur            x1, [fp, #-0x28]
    // 0xa6d444: StoreField: r1->field_7 = r0
    //     0xa6d444: stur            w0, [x1, #7]
    // 0xa6d448: ldur            x2, [fp, #-0x18]
    // 0xa6d44c: LoadField: r3 = r2->field_7
    //     0xa6d44c: ldur            x3, [x2, #7]
    // 0xa6d450: eor             x2, x3, #0xff000000
    // 0xa6d454: LoadField: r3 = r0->field_17
    //     0xa6d454: ldur            w3, [x0, #0x17]
    // 0xa6d458: DecompressPointer r3
    //     0xa6d458: add             x3, x3, HEAP, lsl #32
    // 0xa6d45c: sxtw            x2, w2
    // 0xa6d460: LoadField: r0 = r3->field_7
    //     0xa6d460: ldur            x0, [x3, #7]
    // 0xa6d464: str             w2, [x0, #4]
    // 0xa6d468: d0 = 0.600000
    //     0xa6d468: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf90] IMM: double(0.6) from 0x3fe3333333333333
    //     0xa6d46c: ldr             d0, [x17, #0xf90]
    // 0xa6d470: fcvt            s1, d0
    // 0xa6d474: LoadField: r0 = r3->field_7
    //     0xa6d474: ldur            x0, [x3, #7]
    // 0xa6d478: str             s1, [x0, #0x10]
    // 0xa6d47c: LoadField: r0 = r3->field_7
    //     0xa6d47c: ldur            x0, [x3, #7]
    // 0xa6d480: r2 = 1
    //     0xa6d480: mov             x2, #1
    // 0xa6d484: str             w2, [x0, #0xc]
    // 0xa6d488: ldr             x16, [fp, #0x18]
    // 0xa6d48c: ldur            lr, [fp, #-0x10]
    // 0xa6d490: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d494: SaveReg r1
    //     0xa6d494: str             x1, [SP, #-8]!
    // 0xa6d498: r0 = drawRect()
    //     0xa6d498: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xa6d49c: add             SP, SP, #0x18
    // 0xa6d4a0: ldur            x0, [fp, #-8]
    // 0xa6d4a4: tbnz            w0, #4, #0xa6d658
    // 0xa6d4a8: ldur            x0, [fp, #-0x10]
    // 0xa6d4ac: d0 = 3.000000
    //     0xa6d4ac: fmov            d0, #3.00000000
    // 0xa6d4b0: LoadField: d1 = r0->field_17
    //     0xa6d4b0: ldur            d1, [x0, #0x17]
    // 0xa6d4b4: stur            d1, [fp, #-0x50]
    // 0xa6d4b8: LoadField: d2 = r0->field_7
    //     0xa6d4b8: ldur            d2, [x0, #7]
    // 0xa6d4bc: stur            d2, [fp, #-0x48]
    // 0xa6d4c0: fsub            d3, d1, d2
    // 0xa6d4c4: fdiv            d4, d3, d0
    // 0xa6d4c8: stur            d4, [fp, #-0x40]
    // 0xa6d4cc: fadd            d3, d4, d2
    // 0xa6d4d0: stur            d3, [fp, #-0x38]
    // 0xa6d4d4: LoadField: d5 = r0->field_f
    //     0xa6d4d4: ldur            d5, [x0, #0xf]
    // 0xa6d4d8: stur            d5, [fp, #-0x30]
    // 0xa6d4dc: r0 = Offset()
    //     0xa6d4dc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6d4e0: ldur            d0, [fp, #-0x38]
    // 0xa6d4e4: stur            x0, [fp, #-8]
    // 0xa6d4e8: StoreField: r0->field_7 = d0
    //     0xa6d4e8: stur            d0, [x0, #7]
    // 0xa6d4ec: ldur            d1, [fp, #-0x30]
    // 0xa6d4f0: StoreField: r0->field_f = d1
    //     0xa6d4f0: stur            d1, [x0, #0xf]
    // 0xa6d4f4: ldur            x1, [fp, #-0x10]
    // 0xa6d4f8: LoadField: d2 = r1->field_1f
    //     0xa6d4f8: ldur            d2, [x1, #0x1f]
    // 0xa6d4fc: stur            d2, [fp, #-0x58]
    // 0xa6d500: r0 = Offset()
    //     0xa6d500: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6d504: ldur            d0, [fp, #-0x38]
    // 0xa6d508: StoreField: r0->field_7 = d0
    //     0xa6d508: stur            d0, [x0, #7]
    // 0xa6d50c: ldur            d0, [fp, #-0x58]
    // 0xa6d510: StoreField: r0->field_f = d0
    //     0xa6d510: stur            d0, [x0, #0xf]
    // 0xa6d514: ldr             x16, [fp, #0x18]
    // 0xa6d518: ldur            lr, [fp, #-8]
    // 0xa6d51c: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d520: ldur            x16, [fp, #-0x28]
    // 0xa6d524: stp             x16, x0, [SP, #-0x10]!
    // 0xa6d528: r0 = drawLine()
    //     0xa6d528: bl              #0xa66350  ; [dart:ui] Canvas::drawLine
    // 0xa6d52c: add             SP, SP, #0x20
    // 0xa6d530: ldur            d1, [fp, #-0x40]
    // 0xa6d534: d0 = 2.000000
    //     0xa6d534: fmov            d0, #2.00000000
    // 0xa6d538: fmul            d2, d1, d0
    // 0xa6d53c: ldur            d1, [fp, #-0x48]
    // 0xa6d540: fadd            d3, d2, d1
    // 0xa6d544: stur            d3, [fp, #-0x38]
    // 0xa6d548: r0 = Offset()
    //     0xa6d548: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6d54c: ldur            d0, [fp, #-0x38]
    // 0xa6d550: stur            x0, [fp, #-8]
    // 0xa6d554: StoreField: r0->field_7 = d0
    //     0xa6d554: stur            d0, [x0, #7]
    // 0xa6d558: ldur            d1, [fp, #-0x30]
    // 0xa6d55c: StoreField: r0->field_f = d1
    //     0xa6d55c: stur            d1, [x0, #0xf]
    // 0xa6d560: r0 = Offset()
    //     0xa6d560: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6d564: ldur            d0, [fp, #-0x38]
    // 0xa6d568: StoreField: r0->field_7 = d0
    //     0xa6d568: stur            d0, [x0, #7]
    // 0xa6d56c: ldur            d0, [fp, #-0x58]
    // 0xa6d570: StoreField: r0->field_f = d0
    //     0xa6d570: stur            d0, [x0, #0xf]
    // 0xa6d574: ldr             x16, [fp, #0x18]
    // 0xa6d578: ldur            lr, [fp, #-8]
    // 0xa6d57c: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d580: ldur            x16, [fp, #-0x28]
    // 0xa6d584: stp             x16, x0, [SP, #-0x10]!
    // 0xa6d588: r0 = drawLine()
    //     0xa6d588: bl              #0xa66350  ; [dart:ui] Canvas::drawLine
    // 0xa6d58c: add             SP, SP, #0x20
    // 0xa6d590: ldur            d1, [fp, #-0x30]
    // 0xa6d594: ldur            d0, [fp, #-0x58]
    // 0xa6d598: fsub            d2, d0, d1
    // 0xa6d59c: d0 = 3.000000
    //     0xa6d59c: fmov            d0, #3.00000000
    // 0xa6d5a0: fdiv            d3, d2, d0
    // 0xa6d5a4: stur            d3, [fp, #-0x40]
    // 0xa6d5a8: fadd            d0, d3, d1
    // 0xa6d5ac: stur            d0, [fp, #-0x38]
    // 0xa6d5b0: r0 = Offset()
    //     0xa6d5b0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6d5b4: ldur            d0, [fp, #-0x48]
    // 0xa6d5b8: stur            x0, [fp, #-8]
    // 0xa6d5bc: StoreField: r0->field_7 = d0
    //     0xa6d5bc: stur            d0, [x0, #7]
    // 0xa6d5c0: ldur            d1, [fp, #-0x38]
    // 0xa6d5c4: StoreField: r0->field_f = d1
    //     0xa6d5c4: stur            d1, [x0, #0xf]
    // 0xa6d5c8: r0 = Offset()
    //     0xa6d5c8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6d5cc: ldur            d0, [fp, #-0x50]
    // 0xa6d5d0: StoreField: r0->field_7 = d0
    //     0xa6d5d0: stur            d0, [x0, #7]
    // 0xa6d5d4: ldur            d1, [fp, #-0x38]
    // 0xa6d5d8: StoreField: r0->field_f = d1
    //     0xa6d5d8: stur            d1, [x0, #0xf]
    // 0xa6d5dc: ldr             x16, [fp, #0x18]
    // 0xa6d5e0: ldur            lr, [fp, #-8]
    // 0xa6d5e4: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d5e8: ldur            x16, [fp, #-0x28]
    // 0xa6d5ec: stp             x16, x0, [SP, #-0x10]!
    // 0xa6d5f0: r0 = drawLine()
    //     0xa6d5f0: bl              #0xa66350  ; [dart:ui] Canvas::drawLine
    // 0xa6d5f4: add             SP, SP, #0x20
    // 0xa6d5f8: ldur            d0, [fp, #-0x40]
    // 0xa6d5fc: d1 = 2.000000
    //     0xa6d5fc: fmov            d1, #2.00000000
    // 0xa6d600: fmul            d2, d0, d1
    // 0xa6d604: ldur            d0, [fp, #-0x30]
    // 0xa6d608: fadd            d1, d2, d0
    // 0xa6d60c: stur            d1, [fp, #-0x38]
    // 0xa6d610: r0 = Offset()
    //     0xa6d610: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6d614: ldur            d0, [fp, #-0x48]
    // 0xa6d618: stur            x0, [fp, #-8]
    // 0xa6d61c: StoreField: r0->field_7 = d0
    //     0xa6d61c: stur            d0, [x0, #7]
    // 0xa6d620: ldur            d0, [fp, #-0x38]
    // 0xa6d624: StoreField: r0->field_f = d0
    //     0xa6d624: stur            d0, [x0, #0xf]
    // 0xa6d628: r0 = Offset()
    //     0xa6d628: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6d62c: ldur            d0, [fp, #-0x50]
    // 0xa6d630: StoreField: r0->field_7 = d0
    //     0xa6d630: stur            d0, [x0, #7]
    // 0xa6d634: ldur            d0, [fp, #-0x38]
    // 0xa6d638: StoreField: r0->field_f = d0
    //     0xa6d638: stur            d0, [x0, #0xf]
    // 0xa6d63c: ldr             x16, [fp, #0x18]
    // 0xa6d640: ldur            lr, [fp, #-8]
    // 0xa6d644: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d648: ldur            x16, [fp, #-0x28]
    // 0xa6d64c: stp             x16, x0, [SP, #-0x10]!
    // 0xa6d650: r0 = drawLine()
    //     0xa6d650: bl              #0xa66350  ; [dart:ui] Canvas::drawLine
    // 0xa6d654: add             SP, SP, #0x20
    // 0xa6d658: r0 = Null
    //     0xa6d658: mov             x0, NULL
    // 0xa6d65c: LeaveFrame
    //     0xa6d65c: mov             SP, fp
    //     0xa6d660: ldp             fp, lr, [SP], #0x10
    // 0xa6d664: ret
    //     0xa6d664: ret             
    // 0xa6d668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6d668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6d66c: b               #0xa6d3f8
  }
  _ paintMask(/* No info */) {
    // ** addr: 0xa6d670, size: 0x1c0
    // 0xa6d670: EnterFrame
    //     0xa6d670: stp             fp, lr, [SP, #-0x10]!
    //     0xa6d674: mov             fp, SP
    // 0xa6d678: AllocStack(0x20)
    //     0xa6d678: sub             SP, SP, #0x20
    // 0xa6d67c: CheckStackOverflow
    //     0xa6d67c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6d680: cmp             SP, x16
    //     0xa6d684: b.ls            #0xa6d828
    // 0xa6d688: r16 = Instance_Offset
    //     0xa6d688: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa6d68c: ldr             lr, [fp, #0x18]
    // 0xa6d690: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d694: r0 = &()
    //     0xa6d694: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xa6d698: add             SP, SP, #0x10
    // 0xa6d69c: mov             x1, x0
    // 0xa6d6a0: ldr             x0, [fp, #0x10]
    // 0xa6d6a4: stur            x1, [fp, #-0x18]
    // 0xa6d6a8: LoadField: r2 = r0->field_b
    //     0xa6d6a8: ldur            w2, [x0, #0xb]
    // 0xa6d6ac: DecompressPointer r2
    //     0xa6d6ac: add             x2, x2, HEAP, lsl #32
    // 0xa6d6b0: stur            x2, [fp, #-0x10]
    // 0xa6d6b4: LoadField: r3 = r0->field_23
    //     0xa6d6b4: ldur            w3, [x0, #0x23]
    // 0xa6d6b8: DecompressPointer r3
    //     0xa6d6b8: add             x3, x3, HEAP, lsl #32
    // 0xa6d6bc: stur            x3, [fp, #-8]
    // 0xa6d6c0: r16 = 112
    //     0xa6d6c0: mov             x16, #0x70
    // 0xa6d6c4: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6d6c8: r0 = ByteData()
    //     0xa6d6c8: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6d6cc: add             SP, SP, #0x10
    // 0xa6d6d0: stur            x0, [fp, #-0x20]
    // 0xa6d6d4: r0 = Paint()
    //     0xa6d6d4: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6d6d8: mov             x1, x0
    // 0xa6d6dc: ldur            x0, [fp, #-0x20]
    // 0xa6d6e0: StoreField: r1->field_7 = r0
    //     0xa6d6e0: stur            w0, [x1, #7]
    // 0xa6d6e4: ldr             x16, [fp, #0x20]
    // 0xa6d6e8: ldur            lr, [fp, #-0x18]
    // 0xa6d6ec: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d6f0: SaveReg r1
    //     0xa6d6f0: str             x1, [SP, #-8]!
    // 0xa6d6f4: r0 = saveLayer()
    //     0xa6d6f4: bl              #0x65b5f0  ; [dart:ui] Canvas::saveLayer
    // 0xa6d6f8: add             SP, SP, #0x18
    // 0xa6d6fc: r16 = 112
    //     0xa6d6fc: mov             x16, #0x70
    // 0xa6d700: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6d704: r0 = ByteData()
    //     0xa6d704: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6d708: add             SP, SP, #0x10
    // 0xa6d70c: stur            x0, [fp, #-0x20]
    // 0xa6d710: r0 = Paint()
    //     0xa6d710: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6d714: mov             x1, x0
    // 0xa6d718: ldur            x0, [fp, #-0x20]
    // 0xa6d71c: StoreField: r1->field_7 = r0
    //     0xa6d71c: stur            w0, [x1, #7]
    // 0xa6d720: LoadField: r2 = r0->field_17
    //     0xa6d720: ldur            w2, [x0, #0x17]
    // 0xa6d724: DecompressPointer r2
    //     0xa6d724: add             x2, x2, HEAP, lsl #32
    // 0xa6d728: LoadField: r0 = r2->field_7
    //     0xa6d728: ldur            x0, [x2, #7]
    // 0xa6d72c: str             wzr, [x0, #0xc]
    // 0xa6d730: ldur            x0, [fp, #-8]
    // 0xa6d734: r3 = LoadClassIdInstr(r0)
    //     0xa6d734: ldur            x3, [x0, #-1]
    //     0xa6d738: ubfx            x3, x3, #0xc, #0x14
    // 0xa6d73c: lsl             x3, x3, #1
    // 0xa6d740: r17 = 10124
    //     0xa6d740: mov             x17, #0x278c
    // 0xa6d744: cmp             w3, w17
    // 0xa6d748: b.gt            #0xa6d758
    // 0xa6d74c: r17 = 10122
    //     0xa6d74c: mov             x17, #0x278a
    // 0xa6d750: cmp             w3, w17
    // 0xa6d754: b.ge            #0xa6d770
    // 0xa6d758: r17 = 10114
    //     0xa6d758: mov             x17, #0x2782
    // 0xa6d75c: cmp             w3, w17
    // 0xa6d760: b.eq            #0xa6d770
    // 0xa6d764: r17 = 10118
    //     0xa6d764: mov             x17, #0x2786
    // 0xa6d768: cmp             w3, w17
    // 0xa6d76c: b.ne            #0xa6d77c
    // 0xa6d770: LoadField: r3 = r0->field_7
    //     0xa6d770: ldur            x3, [x0, #7]
    // 0xa6d774: mov             x0, x3
    // 0xa6d778: b               #0xa6d788
    // 0xa6d77c: LoadField: r3 = r0->field_f
    //     0xa6d77c: ldur            w3, [x0, #0xf]
    // 0xa6d780: DecompressPointer r3
    //     0xa6d780: add             x3, x3, HEAP, lsl #32
    // 0xa6d784: LoadField: r0 = r3->field_7
    //     0xa6d784: ldur            x0, [x3, #7]
    // 0xa6d788: eor             x3, x0, #0xff000000
    // 0xa6d78c: sxtw            x3, w3
    // 0xa6d790: LoadField: r0 = r2->field_7
    //     0xa6d790: ldur            x0, [x2, #7]
    // 0xa6d794: str             w3, [x0, #4]
    // 0xa6d798: ldr             x16, [fp, #0x20]
    // 0xa6d79c: ldur            lr, [fp, #-0x18]
    // 0xa6d7a0: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d7a4: SaveReg r1
    //     0xa6d7a4: str             x1, [SP, #-8]!
    // 0xa6d7a8: r0 = drawRect()
    //     0xa6d7a8: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xa6d7ac: add             SP, SP, #0x18
    // 0xa6d7b0: r16 = 112
    //     0xa6d7b0: mov             x16, #0x70
    // 0xa6d7b4: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6d7b8: r0 = ByteData()
    //     0xa6d7b8: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6d7bc: add             SP, SP, #0x10
    // 0xa6d7c0: stur            x0, [fp, #-8]
    // 0xa6d7c4: r0 = Paint()
    //     0xa6d7c4: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6d7c8: mov             x1, x0
    // 0xa6d7cc: ldur            x0, [fp, #-8]
    // 0xa6d7d0: stur            x1, [fp, #-0x18]
    // 0xa6d7d4: StoreField: r1->field_7 = r0
    //     0xa6d7d4: stur            w0, [x1, #7]
    // 0xa6d7d8: r16 = Instance_BlendMode
    //     0xa6d7d8: add             x16, PP, #0x51, lsl #12  ; [pp+0x51fd0] Obj!BlendMode@b678b1
    //     0xa6d7dc: ldr             x16, [x16, #0xfd0]
    // 0xa6d7e0: stp             x16, x1, [SP, #-0x10]!
    // 0xa6d7e4: r0 = blendMode=()
    //     0xa6d7e4: bl              #0x65ec3c  ; [dart:ui] Paint::blendMode=
    // 0xa6d7e8: add             SP, SP, #0x10
    // 0xa6d7ec: ldr             x16, [fp, #0x20]
    // 0xa6d7f0: ldur            lr, [fp, #-0x10]
    // 0xa6d7f4: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d7f8: ldur            x16, [fp, #-0x18]
    // 0xa6d7fc: SaveReg r16
    //     0xa6d7fc: str             x16, [SP, #-8]!
    // 0xa6d800: r0 = drawRect()
    //     0xa6d800: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xa6d804: add             SP, SP, #0x18
    // 0xa6d808: ldr             x16, [fp, #0x20]
    // 0xa6d80c: SaveReg r16
    //     0xa6d80c: str             x16, [SP, #-8]!
    // 0xa6d810: r0 = restore()
    //     0xa6d810: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0xa6d814: add             SP, SP, #8
    // 0xa6d818: r0 = Null
    //     0xa6d818: mov             x0, NULL
    // 0xa6d81c: LeaveFrame
    //     0xa6d81c: mov             SP, fp
    //     0xa6d820: ldp             fp, lr, [SP], #0x10
    // 0xa6d824: ret
    //     0xa6d824: ret             
    // 0xa6d828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6d828: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6d82c: b               #0xa6d688
  }
}

// class id: 4498, size: 0x60, field offset: 0x8
class EditorConfig extends Object {
}

// class id: 4499, size: 0x58, field offset: 0x8
class EditActionDetails extends Object {

  late Offset delta; // offset: 0x40

  _ paintRect(/* No info */) {
    // ** addr: 0x6568a4, size: 0x124
    // 0x6568a4: EnterFrame
    //     0x6568a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6568a8: mov             fp, SP
    // 0x6568ac: AllocStack(0x8)
    //     0x6568ac: sub             SP, SP, #8
    // 0x6568b0: d2 = 0.000000
    //     0x6568b0: eor             v2.16b, v2.16b, v2.16b
    // 0x6568b4: CheckStackOverflow
    //     0x6568b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6568b8: cmp             SP, x16
    //     0x6568bc: b.ls            #0x6569bc
    // 0x6568c0: mov             v0.16b, v2.16b
    // 0x6568c4: d1 = 6.283185
    //     0x6568c4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37848] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0x6568c8: ldr             d1, [x17, #0x848]
    // 0x6568cc: stp             fp, lr, [SP, #-0x10]!
    // 0x6568d0: mov             fp, SP
    // 0x6568d4: CallRuntime_DartModulo(double, double) -> double
    //     0x6568d4: and             SP, SP, #0xfffffffffffffff0
    //     0x6568d8: mov             sp, SP
    //     0x6568dc: ldr             x16, [THR, #0x558]  ; THR::DartModulo
    //     0x6568e0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x6568e4: blr             x16
    //     0x6568e8: mov             x16, #8
    //     0x6568ec: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x6568f0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x6568f4: sub             sp, x16, #1, lsl #12
    //     0x6568f8: mov             SP, fp
    //     0x6568fc: ldp             fp, lr, [SP], #0x10
    // 0x656900: mov             v1.16b, v0.16b
    // 0x656904: d0 = 0.000000
    //     0x656904: eor             v0.16b, v0.16b, v0.16b
    // 0x656908: fcmp            d1, d0
    // 0x65690c: b.eq            #0x6569a8
    // 0x656910: ldr             x16, [fp, #0x18]
    // 0x656914: SaveReg r16
    //     0x656914: str             x16, [SP, #-8]!
    // 0x656918: r0 = screenCropRect()
    //     0x656918: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x65691c: add             SP, SP, #8
    // 0x656920: cmp             w0, NULL
    // 0x656924: b.ne            #0x656930
    // 0x656928: ldr             x1, [fp, #0x10]
    // 0x65692c: b               #0x6569ac
    // 0x656930: ldr             x16, [fp, #0x18]
    // 0x656934: SaveReg r16
    //     0x656934: str             x16, [SP, #-8]!
    // 0x656938: r0 = screenCropRect()
    //     0x656938: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x65693c: add             SP, SP, #8
    // 0x656940: cmp             w0, NULL
    // 0x656944: b.eq            #0x6569c4
    // 0x656948: SaveReg r0
    //     0x656948: str             x0, [SP, #-8]!
    // 0x65694c: r0 = center()
    //     0x65694c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x656950: add             SP, SP, #8
    // 0x656954: stur            x0, [fp, #-8]
    // 0x656958: ldr             x16, [fp, #0x18]
    // 0x65695c: SaveReg r16
    //     0x65695c: str             x16, [SP, #-8]!
    // 0x656960: r0 = isTwoPi()
    //     0x656960: bl              #0x656ed0  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::isTwoPi
    // 0x656964: add             SP, SP, #8
    // 0x656968: eor             x1, x0, #0x10
    // 0x65696c: tbnz            w1, #4, #0x656994
    // 0x656970: d0 = 0.000000
    //     0x656970: eor             v0.16b, v0.16b, v0.16b
    // 0x656974: fneg            d1, d0
    // 0x656978: ldr             x16, [fp, #0x10]
    // 0x65697c: ldur            lr, [fp, #-8]
    // 0x656980: stp             lr, x16, [SP, #-0x10]!
    // 0x656984: SaveReg d1
    //     0x656984: str             d1, [SP, #-8]!
    // 0x656988: r0 = rotateRect()
    //     0x656988: bl              #0x6569c8  ; [package:extended_image/src/editor/editor_utils.dart] ::rotateRect
    // 0x65698c: add             SP, SP, #0x18
    // 0x656990: b               #0x65699c
    // 0x656994: ldr             x1, [fp, #0x10]
    // 0x656998: mov             x0, x1
    // 0x65699c: LeaveFrame
    //     0x65699c: mov             SP, fp
    //     0x6569a0: ldp             fp, lr, [SP], #0x10
    // 0x6569a4: ret
    //     0x6569a4: ret             
    // 0x6569a8: ldr             x1, [fp, #0x10]
    // 0x6569ac: mov             x0, x1
    // 0x6569b0: LeaveFrame
    //     0x6569b0: mov             SP, fp
    //     0x6569b4: ldp             fp, lr, [SP], #0x10
    // 0x6569b8: ret
    //     0x6569b8: ret             
    // 0x6569bc: r0 = StackOverflowSharedWithFPURegs()
    //     0x6569bc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6569c0: b               #0x6568c0
    // 0x6569c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6569c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ isTwoPi(/* No info */) {
    // ** addr: 0x656ed0, size: 0x78
    // 0x656ed0: EnterFrame
    //     0x656ed0: stp             fp, lr, [SP, #-0x10]!
    //     0x656ed4: mov             fp, SP
    // 0x656ed8: d2 = 0.000000
    //     0x656ed8: eor             v2.16b, v2.16b, v2.16b
    // 0x656edc: mov             v0.16b, v2.16b
    // 0x656ee0: d1 = 6.283185
    //     0x656ee0: add             x17, PP, #0x37, lsl #12  ; [pp+0x37848] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0x656ee4: ldr             d1, [x17, #0x848]
    // 0x656ee8: stp             fp, lr, [SP, #-0x10]!
    // 0x656eec: mov             fp, SP
    // 0x656ef0: CallRuntime_DartModulo(double, double) -> double
    //     0x656ef0: and             SP, SP, #0xfffffffffffffff0
    //     0x656ef4: mov             sp, SP
    //     0x656ef8: ldr             x16, [THR, #0x558]  ; THR::DartModulo
    //     0x656efc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x656f00: blr             x16
    //     0x656f04: mov             x16, #8
    //     0x656f08: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x656f0c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x656f10: sub             sp, x16, #1, lsl #12
    //     0x656f14: mov             SP, fp
    //     0x656f18: ldp             fp, lr, [SP], #0x10
    // 0x656f1c: mov             v1.16b, v0.16b
    // 0x656f20: d0 = 0.000000
    //     0x656f20: eor             v0.16b, v0.16b, v0.16b
    // 0x656f24: fcmp            d1, d0
    // 0x656f28: b.vs            #0x656f30
    // 0x656f2c: b.eq            #0x656f38
    // 0x656f30: r0 = false
    //     0x656f30: add             x0, NULL, #0x30  ; false
    // 0x656f34: b               #0x656f3c
    // 0x656f38: r0 = true
    //     0x656f38: add             x0, NULL, #0x20  ; true
    // 0x656f3c: LeaveFrame
    //     0x656f3c: mov             SP, fp
    //     0x656f40: ldp             fp, lr, [SP], #0x10
    // 0x656f44: ret
    //     0x656f44: ret             
  }
  get _ hasRotateAngle(/* No info */) {
    // ** addr: 0x6574f8, size: 0x70
    // 0x6574f8: EnterFrame
    //     0x6574f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6574fc: mov             fp, SP
    // 0x657500: d2 = 0.000000
    //     0x657500: eor             v2.16b, v2.16b, v2.16b
    // 0x657504: mov             v0.16b, v2.16b
    // 0x657508: d1 = 6.283185
    //     0x657508: add             x17, PP, #0x37, lsl #12  ; [pp+0x37848] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0x65750c: ldr             d1, [x17, #0x848]
    // 0x657510: stp             fp, lr, [SP, #-0x10]!
    // 0x657514: mov             fp, SP
    // 0x657518: CallRuntime_DartModulo(double, double) -> double
    //     0x657518: and             SP, SP, #0xfffffffffffffff0
    //     0x65751c: mov             sp, SP
    //     0x657520: ldr             x16, [THR, #0x558]  ; THR::DartModulo
    //     0x657524: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x657528: blr             x16
    //     0x65752c: mov             x16, #8
    //     0x657530: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x657534: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x657538: sub             sp, x16, #1, lsl #12
    //     0x65753c: mov             SP, fp
    //     0x657540: ldp             fp, lr, [SP], #0x10
    // 0x657544: mov             v1.16b, v0.16b
    // 0x657548: d0 = 0.000000
    //     0x657548: eor             v0.16b, v0.16b, v0.16b
    // 0x65754c: fcmp            d1, d0
    // 0x657550: r16 = true
    //     0x657550: add             x16, NULL, #0x20  ; true
    // 0x657554: r17 = false
    //     0x657554: add             x17, NULL, #0x30  ; false
    // 0x657558: csel            x0, x16, x17, ne
    // 0x65755c: LeaveFrame
    //     0x65755c: mov             SP, fp
    //     0x657560: ldp             fp, lr, [SP], #0x10
    // 0x657564: ret
    //     0x657564: ret             
  }
  get _ screenCropRect(/* No info */) {
    // ** addr: 0x657568, size: 0x74
    // 0x657568: EnterFrame
    //     0x657568: stp             fp, lr, [SP, #-0x10]!
    //     0x65756c: mov             fp, SP
    // 0x657570: AllocStack(0x8)
    //     0x657570: sub             SP, SP, #8
    // 0x657574: CheckStackOverflow
    //     0x657574: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x657578: cmp             SP, x16
    //     0x65757c: b.ls            #0x6575d0
    // 0x657580: ldr             x0, [fp, #0x10]
    // 0x657584: LoadField: r1 = r0->field_4b
    //     0x657584: ldur            w1, [x0, #0x4b]
    // 0x657588: DecompressPointer r1
    //     0x657588: add             x1, x1, HEAP, lsl #32
    // 0x65758c: stur            x1, [fp, #-8]
    // 0x657590: cmp             w1, NULL
    // 0x657594: b.ne            #0x6575a0
    // 0x657598: r0 = Null
    //     0x657598: mov             x0, NULL
    // 0x65759c: b               #0x6575c4
    // 0x6575a0: SaveReg r0
    //     0x6575a0: str             x0, [SP, #-8]!
    // 0x6575a4: r0 = layoutTopLeft()
    //     0x6575a4: bl              #0x6575dc  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::layoutTopLeft
    // 0x6575a8: add             SP, SP, #8
    // 0x6575ac: cmp             w0, NULL
    // 0x6575b0: b.eq            #0x6575d8
    // 0x6575b4: ldur            x16, [fp, #-8]
    // 0x6575b8: stp             x0, x16, [SP, #-0x10]!
    // 0x6575bc: r0 = shift()
    //     0x6575bc: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x6575c0: add             SP, SP, #0x10
    // 0x6575c4: LeaveFrame
    //     0x6575c4: mov             SP, fp
    //     0x6575c8: ldp             fp, lr, [SP], #0x10
    // 0x6575cc: ret
    //     0x6575cc: ret             
    // 0x6575d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6575d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6575d4: b               #0x657580
    // 0x6575d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6575d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ layoutTopLeft(/* No info */) {
    // ** addr: 0x6575dc, size: 0x58
    // 0x6575dc: EnterFrame
    //     0x6575dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6575e0: mov             fp, SP
    // 0x6575e4: AllocStack(0x10)
    //     0x6575e4: sub             SP, SP, #0x10
    // 0x6575e8: ldr             x0, [fp, #0x10]
    // 0x6575ec: LoadField: r1 = r0->field_1f
    //     0x6575ec: ldur            w1, [x0, #0x1f]
    // 0x6575f0: DecompressPointer r1
    //     0x6575f0: add             x1, x1, HEAP, lsl #32
    // 0x6575f4: cmp             w1, NULL
    // 0x6575f8: b.ne            #0x657604
    // 0x6575fc: r0 = Null
    //     0x6575fc: mov             x0, NULL
    // 0x657600: b               #0x657628
    // 0x657604: LoadField: d0 = r1->field_7
    //     0x657604: ldur            d0, [x1, #7]
    // 0x657608: stur            d0, [fp, #-0x10]
    // 0x65760c: LoadField: d1 = r1->field_f
    //     0x65760c: ldur            d1, [x1, #0xf]
    // 0x657610: stur            d1, [fp, #-8]
    // 0x657614: r0 = Offset()
    //     0x657614: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x657618: ldur            d0, [fp, #-0x10]
    // 0x65761c: StoreField: r0->field_7 = d0
    //     0x65761c: stur            d0, [x0, #7]
    // 0x657620: ldur            d0, [fp, #-8]
    // 0x657624: StoreField: r0->field_f = d0
    //     0x657624: stur            d0, [x0, #0xf]
    // 0x657628: LeaveFrame
    //     0x657628: mov             SP, fp
    //     0x65762c: ldp             fp, lr, [SP], #0x10
    // 0x657630: ret
    //     0x657630: ret             
  }
  get _ hasEditAction(/* No info */) {
    // ** addr: 0x657634, size: 0x74
    // 0x657634: EnterFrame
    //     0x657634: stp             fp, lr, [SP, #-0x10]!
    //     0x657638: mov             fp, SP
    // 0x65763c: d2 = 0.000000
    //     0x65763c: eor             v2.16b, v2.16b, v2.16b
    // 0x657640: mov             v0.16b, v2.16b
    // 0x657644: d1 = 6.283185
    //     0x657644: add             x17, PP, #0x37, lsl #12  ; [pp+0x37848] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0x657648: ldr             d1, [x17, #0x848]
    // 0x65764c: stp             fp, lr, [SP, #-0x10]!
    // 0x657650: mov             fp, SP
    // 0x657654: CallRuntime_DartModulo(double, double) -> double
    //     0x657654: and             SP, SP, #0xfffffffffffffff0
    //     0x657658: mov             sp, SP
    //     0x65765c: ldr             x16, [THR, #0x558]  ; THR::DartModulo
    //     0x657660: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x657664: blr             x16
    //     0x657668: mov             x16, #8
    //     0x65766c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x657670: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x657674: sub             sp, x16, #1, lsl #12
    //     0x657678: mov             SP, fp
    //     0x65767c: ldp             fp, lr, [SP], #0x10
    // 0x657680: mov             v1.16b, v0.16b
    // 0x657684: d0 = 0.000000
    //     0x657684: eor             v0.16b, v0.16b, v0.16b
    // 0x657688: fcmp            d1, d0
    // 0x65768c: b.eq            #0x657698
    // 0x657690: r0 = true
    //     0x657690: add             x0, NULL, #0x20  ; true
    // 0x657694: b               #0x65769c
    // 0x657698: r0 = false
    //     0x657698: add             x0, NULL, #0x30  ; false
    // 0x65769c: LeaveFrame
    //     0x65769c: mov             SP, fp
    //     0x6576a0: ldp             fp, lr, [SP], #0x10
    // 0x6576a4: ret
    //     0x6576a4: ret             
  }
  _ getFinalDestinationRect(/* No info */) {
    // ** addr: 0x6576a8, size: 0xc24
    // 0x6576a8: EnterFrame
    //     0x6576a8: stp             fp, lr, [SP, #-0x10]!
    //     0x6576ac: mov             fp, SP
    // 0x6576b0: AllocStack(0x48)
    //     0x6576b0: sub             SP, SP, #0x48
    // 0x6576b4: r0 = false
    //     0x6576b4: add             x0, NULL, #0x30  ; false
    // 0x6576b8: CheckStackOverflow
    //     0x6576b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6576bc: cmp             SP, x16
    //     0x6576c0: b.ls            #0x65811c
    // 0x6576c4: ldr             x1, [fp, #0x10]
    // 0x6576c8: StoreField: r1->field_2b = r0
    //     0x6576c8: stur            w0, [x1, #0x2b]
    // 0x6576cc: LoadField: r0 = r1->field_23
    //     0x6576cc: ldur            w0, [x1, #0x23]
    // 0x6576d0: DecompressPointer r0
    //     0x6576d0: add             x0, x0, HEAP, lsl #32
    // 0x6576d4: stur            x0, [fp, #-0x18]
    // 0x6576d8: cmp             w0, NULL
    // 0x6576dc: b.eq            #0x658070
    // 0x6576e0: d0 = 1.000000
    //     0x6576e0: fmov            d0, #1.00000000
    // 0x6576e4: LoadField: d1 = r1->field_2f
    //     0x6576e4: ldur            d1, [x1, #0x2f]
    // 0x6576e8: LoadField: d2 = r1->field_37
    //     0x6576e8: ldur            d2, [x1, #0x37]
    // 0x6576ec: fdiv            d3, d1, d2
    // 0x6576f0: stur            d3, [fp, #-0x30]
    // 0x6576f4: fcmp            d3, d0
    // 0x6576f8: b.eq            #0x657958
    // 0x6576fc: LoadField: r2 = r1->field_43
    //     0x6576fc: ldur            w2, [x1, #0x43]
    // 0x657700: DecompressPointer r2
    //     0x657700: add             x2, x2, HEAP, lsl #32
    // 0x657704: cmp             w2, NULL
    // 0x657708: b.ne            #0x657720
    // 0x65770c: SaveReg r0
    //     0x65770c: str             x0, [SP, #-8]!
    // 0x657710: r0 = center()
    //     0x657710: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x657714: add             SP, SP, #8
    // 0x657718: mov             x1, x0
    // 0x65771c: b               #0x657724
    // 0x657720: mov             x1, x2
    // 0x657724: ldr             x0, [fp, #0x10]
    // 0x657728: ldur            d0, [fp, #-0x30]
    // 0x65772c: stur            x1, [fp, #-8]
    // 0x657730: LoadField: d1 = r1->field_7
    //     0x657730: ldur            d1, [x1, #7]
    // 0x657734: LoadField: r2 = r0->field_23
    //     0x657734: ldur            w2, [x0, #0x23]
    // 0x657738: DecompressPointer r2
    //     0x657738: add             x2, x2, HEAP, lsl #32
    // 0x65773c: cmp             w2, NULL
    // 0x657740: b.eq            #0x658124
    // 0x657744: LoadField: d2 = r2->field_7
    //     0x657744: ldur            d2, [x2, #7]
    // 0x657748: LoadField: d3 = r2->field_17
    //     0x657748: ldur            d3, [x2, #0x17]
    // 0x65774c: r2 = inline_Allocate_Double()
    //     0x65774c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x657750: add             x2, x2, #0x10
    //     0x657754: cmp             x3, x2
    //     0x657758: b.ls            #0x658128
    //     0x65775c: str             x2, [THR, #0x60]  ; THR::top
    //     0x657760: sub             x2, x2, #0xf
    //     0x657764: mov             x3, #0xd108
    //     0x657768: movk            x3, #3, lsl #16
    //     0x65776c: stur            x3, [x2, #-1]
    // 0x657770: StoreField: r2->field_7 = d1
    //     0x657770: stur            d1, [x2, #7]
    // 0x657774: r3 = inline_Allocate_Double()
    //     0x657774: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x657778: add             x3, x3, #0x10
    //     0x65777c: cmp             x4, x3
    //     0x657780: b.ls            #0x65814c
    //     0x657784: str             x3, [THR, #0x60]  ; THR::top
    //     0x657788: sub             x3, x3, #0xf
    //     0x65778c: mov             x4, #0xd108
    //     0x657790: movk            x4, #3, lsl #16
    //     0x657794: stur            x4, [x3, #-1]
    // 0x657798: StoreField: r3->field_7 = d2
    //     0x657798: stur            d2, [x3, #7]
    // 0x65779c: r4 = inline_Allocate_Double()
    //     0x65779c: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x6577a0: add             x4, x4, #0x10
    //     0x6577a4: cmp             x5, x4
    //     0x6577a8: b.ls            #0x658178
    //     0x6577ac: str             x4, [THR, #0x60]  ; THR::top
    //     0x6577b0: sub             x4, x4, #0xf
    //     0x6577b4: mov             x5, #0xd108
    //     0x6577b8: movk            x5, #3, lsl #16
    //     0x6577bc: stur            x5, [x4, #-1]
    // 0x6577c0: StoreField: r4->field_7 = d3
    //     0x6577c0: stur            d3, [x4, #7]
    // 0x6577c4: stp             x3, x2, [SP, #-0x10]!
    // 0x6577c8: SaveReg r4
    //     0x6577c8: str             x4, [SP, #-8]!
    // 0x6577cc: r0 = clamp()
    //     0x6577cc: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x6577d0: add             SP, SP, #0x18
    // 0x6577d4: mov             x1, x0
    // 0x6577d8: ldur            x0, [fp, #-8]
    // 0x6577dc: stur            x1, [fp, #-0x10]
    // 0x6577e0: LoadField: d0 = r0->field_f
    //     0x6577e0: ldur            d0, [x0, #0xf]
    // 0x6577e4: ldr             x0, [fp, #0x10]
    // 0x6577e8: LoadField: r2 = r0->field_23
    //     0x6577e8: ldur            w2, [x0, #0x23]
    // 0x6577ec: DecompressPointer r2
    //     0x6577ec: add             x2, x2, HEAP, lsl #32
    // 0x6577f0: cmp             w2, NULL
    // 0x6577f4: b.eq            #0x65819c
    // 0x6577f8: LoadField: d1 = r2->field_f
    //     0x6577f8: ldur            d1, [x2, #0xf]
    // 0x6577fc: LoadField: d2 = r2->field_1f
    //     0x6577fc: ldur            d2, [x2, #0x1f]
    // 0x657800: r2 = inline_Allocate_Double()
    //     0x657800: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x657804: add             x2, x2, #0x10
    //     0x657808: cmp             x3, x2
    //     0x65780c: b.ls            #0x6581a0
    //     0x657810: str             x2, [THR, #0x60]  ; THR::top
    //     0x657814: sub             x2, x2, #0xf
    //     0x657818: mov             x3, #0xd108
    //     0x65781c: movk            x3, #3, lsl #16
    //     0x657820: stur            x3, [x2, #-1]
    // 0x657824: StoreField: r2->field_7 = d0
    //     0x657824: stur            d0, [x2, #7]
    // 0x657828: r3 = inline_Allocate_Double()
    //     0x657828: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x65782c: add             x3, x3, #0x10
    //     0x657830: cmp             x4, x3
    //     0x657834: b.ls            #0x6581c4
    //     0x657838: str             x3, [THR, #0x60]  ; THR::top
    //     0x65783c: sub             x3, x3, #0xf
    //     0x657840: mov             x4, #0xd108
    //     0x657844: movk            x4, #3, lsl #16
    //     0x657848: stur            x4, [x3, #-1]
    // 0x65784c: StoreField: r3->field_7 = d1
    //     0x65784c: stur            d1, [x3, #7]
    // 0x657850: r4 = inline_Allocate_Double()
    //     0x657850: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x657854: add             x4, x4, #0x10
    //     0x657858: cmp             x5, x4
    //     0x65785c: b.ls            #0x6581e8
    //     0x657860: str             x4, [THR, #0x60]  ; THR::top
    //     0x657864: sub             x4, x4, #0xf
    //     0x657868: mov             x5, #0xd108
    //     0x65786c: movk            x5, #3, lsl #16
    //     0x657870: stur            x5, [x4, #-1]
    // 0x657874: StoreField: r4->field_7 = d2
    //     0x657874: stur            d2, [x4, #7]
    // 0x657878: stp             x3, x2, [SP, #-0x10]!
    // 0x65787c: SaveReg r4
    //     0x65787c: str             x4, [SP, #-8]!
    // 0x657880: r0 = clamp()
    //     0x657880: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x657884: add             SP, SP, #0x18
    // 0x657888: mov             x1, x0
    // 0x65788c: ldur            x0, [fp, #-0x10]
    // 0x657890: LoadField: d0 = r0->field_7
    //     0x657890: ldur            d0, [x0, #7]
    // 0x657894: LoadField: d1 = r1->field_7
    //     0x657894: ldur            d1, [x1, #7]
    // 0x657898: ldr             x0, [fp, #0x10]
    // 0x65789c: LoadField: r1 = r0->field_23
    //     0x65789c: ldur            w1, [x0, #0x23]
    // 0x6578a0: DecompressPointer r1
    //     0x6578a0: add             x1, x1, HEAP, lsl #32
    // 0x6578a4: cmp             w1, NULL
    // 0x6578a8: b.eq            #0x65820c
    // 0x6578ac: LoadField: d2 = r1->field_7
    //     0x6578ac: ldur            d2, [x1, #7]
    // 0x6578b0: fsub            d3, d0, d2
    // 0x6578b4: ldur            d4, [fp, #-0x30]
    // 0x6578b8: fmul            d5, d3, d4
    // 0x6578bc: fsub            d3, d0, d5
    // 0x6578c0: stur            d3, [fp, #-0x48]
    // 0x6578c4: LoadField: d0 = r1->field_f
    //     0x6578c4: ldur            d0, [x1, #0xf]
    // 0x6578c8: fsub            d5, d1, d0
    // 0x6578cc: fmul            d6, d5, d4
    // 0x6578d0: fsub            d5, d1, d6
    // 0x6578d4: stur            d5, [fp, #-0x40]
    // 0x6578d8: LoadField: d1 = r1->field_17
    //     0x6578d8: ldur            d1, [x1, #0x17]
    // 0x6578dc: fsub            d6, d1, d2
    // 0x6578e0: fmul            d1, d6, d4
    // 0x6578e4: LoadField: d2 = r1->field_1f
    //     0x6578e4: ldur            d2, [x1, #0x1f]
    // 0x6578e8: fsub            d6, d2, d0
    // 0x6578ec: fmul            d0, d6, d4
    // 0x6578f0: fadd            d2, d3, d1
    // 0x6578f4: stur            d2, [fp, #-0x38]
    // 0x6578f8: fadd            d1, d5, d0
    // 0x6578fc: stur            d1, [fp, #-0x30]
    // 0x657900: r0 = Rect()
    //     0x657900: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x657904: ldur            d0, [fp, #-0x48]
    // 0x657908: StoreField: r0->field_7 = d0
    //     0x657908: stur            d0, [x0, #7]
    // 0x65790c: ldur            d0, [fp, #-0x40]
    // 0x657910: StoreField: r0->field_f = d0
    //     0x657910: stur            d0, [x0, #0xf]
    // 0x657914: ldur            d0, [fp, #-0x38]
    // 0x657918: StoreField: r0->field_17 = d0
    //     0x657918: stur            d0, [x0, #0x17]
    // 0x65791c: ldur            d0, [fp, #-0x30]
    // 0x657920: StoreField: r0->field_1f = d0
    //     0x657920: stur            d0, [x0, #0x1f]
    // 0x657924: ldr             x1, [fp, #0x10]
    // 0x657928: StoreField: r1->field_23 = r0
    //     0x657928: stur            w0, [x1, #0x23]
    //     0x65792c: ldurb           w16, [x1, #-1]
    //     0x657930: ldurb           w17, [x0, #-1]
    //     0x657934: and             x16, x17, x16, lsr #2
    //     0x657938: tst             x16, HEAP, lsr #32
    //     0x65793c: b.eq            #0x657944
    //     0x657940: bl              #0xd6826c
    // 0x657944: LoadField: d0 = r1->field_2f
    //     0x657944: ldur            d0, [x1, #0x2f]
    // 0x657948: StoreField: r1->field_37 = d0
    //     0x657948: stur            d0, [x1, #0x37]
    // 0x65794c: r2 = Instance_Offset
    //     0x65794c: ldr             x2, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x657950: StoreField: r1->field_3f = r2
    //     0x657950: stur            w2, [x1, #0x3f]
    // 0x657954: b               #0x657bec
    // 0x657958: r2 = Instance_Offset
    //     0x657958: ldr             x2, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65795c: SaveReg r1
    //     0x65795c: str             x1, [SP, #-8]!
    // 0x657960: r0 = screenCropRect()
    //     0x657960: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x657964: add             SP, SP, #8
    // 0x657968: mov             x1, x0
    // 0x65796c: ldur            x0, [fp, #-0x18]
    // 0x657970: r2 = LoadClassIdInstr(r0)
    //     0x657970: ldur            x2, [x0, #-1]
    //     0x657974: ubfx            x2, x2, #0xc, #0x14
    // 0x657978: stp             x1, x0, [SP, #-0x10]!
    // 0x65797c: mov             x0, x2
    // 0x657980: mov             lr, x0
    // 0x657984: ldr             lr, [x21, lr, lsl #3]
    // 0x657988: blr             lr
    // 0x65798c: add             SP, SP, #0x10
    // 0x657990: tbz             w0, #4, #0x657be0
    // 0x657994: ldr             x0, [fp, #0x10]
    // 0x657998: LoadField: r1 = r0->field_23
    //     0x657998: ldur            w1, [x0, #0x23]
    // 0x65799c: DecompressPointer r1
    //     0x65799c: add             x1, x1, HEAP, lsl #32
    // 0x6579a0: stur            x1, [fp, #-8]
    // 0x6579a4: cmp             w1, NULL
    // 0x6579a8: b.eq            #0x658210
    // 0x6579ac: SaveReg r0
    //     0x6579ac: str             x0, [SP, #-8]!
    // 0x6579b0: r0 = screenCropRect()
    //     0x6579b0: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x6579b4: add             SP, SP, #8
    // 0x6579b8: cmp             w0, NULL
    // 0x6579bc: b.eq            #0x658214
    // 0x6579c0: ldur            x16, [fp, #-8]
    // 0x6579c4: stp             x0, x16, [SP, #-0x10]!
    // 0x6579c8: r0 = RectExtension.topIsSame()
    //     0x6579c8: bl              #0x658d2c  ; [package:extended_image/src/utils.dart] ::RectExtension.topIsSame
    // 0x6579cc: add             SP, SP, #0x10
    // 0x6579d0: mov             x1, x0
    // 0x6579d4: ldr             x0, [fp, #0x10]
    // 0x6579d8: stur            x1, [fp, #-0x10]
    // 0x6579dc: LoadField: r2 = r0->field_23
    //     0x6579dc: ldur            w2, [x0, #0x23]
    // 0x6579e0: DecompressPointer r2
    //     0x6579e0: add             x2, x2, HEAP, lsl #32
    // 0x6579e4: stur            x2, [fp, #-8]
    // 0x6579e8: cmp             w2, NULL
    // 0x6579ec: b.eq            #0x658218
    // 0x6579f0: SaveReg r0
    //     0x6579f0: str             x0, [SP, #-8]!
    // 0x6579f4: r0 = screenCropRect()
    //     0x6579f4: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x6579f8: add             SP, SP, #8
    // 0x6579fc: cmp             w0, NULL
    // 0x657a00: b.eq            #0x65821c
    // 0x657a04: ldur            x16, [fp, #-8]
    // 0x657a08: stp             x0, x16, [SP, #-0x10]!
    // 0x657a0c: r0 = RectExtension.leftIsSame()
    //     0x657a0c: bl              #0x658cac  ; [package:extended_image/src/utils.dart] ::RectExtension.leftIsSame
    // 0x657a10: add             SP, SP, #0x10
    // 0x657a14: mov             x1, x0
    // 0x657a18: ldr             x0, [fp, #0x10]
    // 0x657a1c: stur            x1, [fp, #-0x18]
    // 0x657a20: LoadField: r2 = r0->field_23
    //     0x657a20: ldur            w2, [x0, #0x23]
    // 0x657a24: DecompressPointer r2
    //     0x657a24: add             x2, x2, HEAP, lsl #32
    // 0x657a28: stur            x2, [fp, #-8]
    // 0x657a2c: cmp             w2, NULL
    // 0x657a30: b.eq            #0x658220
    // 0x657a34: SaveReg r0
    //     0x657a34: str             x0, [SP, #-8]!
    // 0x657a38: r0 = screenCropRect()
    //     0x657a38: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x657a3c: add             SP, SP, #8
    // 0x657a40: cmp             w0, NULL
    // 0x657a44: b.eq            #0x658224
    // 0x657a48: ldur            x16, [fp, #-8]
    // 0x657a4c: stp             x0, x16, [SP, #-0x10]!
    // 0x657a50: r0 = RectExtension.bottomIsSame()
    //     0x657a50: bl              #0x658c2c  ; [package:extended_image/src/utils.dart] ::RectExtension.bottomIsSame
    // 0x657a54: add             SP, SP, #0x10
    // 0x657a58: mov             x1, x0
    // 0x657a5c: ldr             x0, [fp, #0x10]
    // 0x657a60: stur            x1, [fp, #-0x20]
    // 0x657a64: LoadField: r2 = r0->field_23
    //     0x657a64: ldur            w2, [x0, #0x23]
    // 0x657a68: DecompressPointer r2
    //     0x657a68: add             x2, x2, HEAP, lsl #32
    // 0x657a6c: stur            x2, [fp, #-8]
    // 0x657a70: cmp             w2, NULL
    // 0x657a74: b.eq            #0x658228
    // 0x657a78: SaveReg r0
    //     0x657a78: str             x0, [SP, #-8]!
    // 0x657a7c: r0 = screenCropRect()
    //     0x657a7c: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x657a80: add             SP, SP, #8
    // 0x657a84: cmp             w0, NULL
    // 0x657a88: b.eq            #0x65822c
    // 0x657a8c: ldur            x16, [fp, #-8]
    // 0x657a90: stp             x0, x16, [SP, #-0x10]!
    // 0x657a94: r0 = RectExtension.rightIsSame()
    //     0x657a94: bl              #0x658b58  ; [package:extended_image/src/utils.dart] ::RectExtension.rightIsSame
    // 0x657a98: add             SP, SP, #0x10
    // 0x657a9c: mov             x1, x0
    // 0x657aa0: ldur            x0, [fp, #-0x10]
    // 0x657aa4: tbnz            w0, #4, #0x657b18
    // 0x657aa8: ldur            x0, [fp, #-0x20]
    // 0x657aac: tbnz            w0, #4, #0x657b0c
    // 0x657ab0: ldr             x0, [fp, #0x10]
    // 0x657ab4: LoadField: r1 = r0->field_3f
    //     0x657ab4: ldur            w1, [x0, #0x3f]
    // 0x657ab8: DecompressPointer r1
    //     0x657ab8: add             x1, x1, HEAP, lsl #32
    // 0x657abc: r16 = Sentinel
    //     0x657abc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x657ac0: cmp             w1, w16
    // 0x657ac4: b.eq            #0x658230
    // 0x657ac8: LoadField: d0 = r1->field_7
    //     0x657ac8: ldur            d0, [x1, #7]
    // 0x657acc: stur            d0, [fp, #-0x30]
    // 0x657ad0: r0 = Offset()
    //     0x657ad0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x657ad4: ldur            d0, [fp, #-0x30]
    // 0x657ad8: StoreField: r0->field_7 = d0
    //     0x657ad8: stur            d0, [x0, #7]
    // 0x657adc: d0 = 0.000000
    //     0x657adc: eor             v0.16b, v0.16b, v0.16b
    // 0x657ae0: StoreField: r0->field_f = d0
    //     0x657ae0: stur            d0, [x0, #0xf]
    // 0x657ae4: ldr             x2, [fp, #0x10]
    // 0x657ae8: StoreField: r2->field_3f = r0
    //     0x657ae8: stur            w0, [x2, #0x3f]
    //     0x657aec: ldurb           w16, [x2, #-1]
    //     0x657af0: ldurb           w17, [x0, #-1]
    //     0x657af4: and             x16, x17, x16, lsr #2
    //     0x657af8: tst             x16, HEAP, lsr #32
    //     0x657afc: b.eq            #0x657b04
    //     0x657b00: bl              #0xd6828c
    // 0x657b04: mov             x1, x2
    // 0x657b08: b               #0x657b8c
    // 0x657b0c: ldr             x2, [fp, #0x10]
    // 0x657b10: d0 = 0.000000
    //     0x657b10: eor             v0.16b, v0.16b, v0.16b
    // 0x657b14: b               #0x657b20
    // 0x657b18: ldr             x2, [fp, #0x10]
    // 0x657b1c: d0 = 0.000000
    //     0x657b1c: eor             v0.16b, v0.16b, v0.16b
    // 0x657b20: ldur            x0, [fp, #-0x18]
    // 0x657b24: tbnz            w0, #4, #0x657b88
    // 0x657b28: tbnz            w1, #4, #0x657b80
    // 0x657b2c: LoadField: r0 = r2->field_3f
    //     0x657b2c: ldur            w0, [x2, #0x3f]
    // 0x657b30: DecompressPointer r0
    //     0x657b30: add             x0, x0, HEAP, lsl #32
    // 0x657b34: r16 = Sentinel
    //     0x657b34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x657b38: cmp             w0, w16
    // 0x657b3c: b.eq            #0x65823c
    // 0x657b40: LoadField: d1 = r0->field_f
    //     0x657b40: ldur            d1, [x0, #0xf]
    // 0x657b44: stur            d1, [fp, #-0x30]
    // 0x657b48: r0 = Offset()
    //     0x657b48: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x657b4c: d0 = 0.000000
    //     0x657b4c: eor             v0.16b, v0.16b, v0.16b
    // 0x657b50: StoreField: r0->field_7 = d0
    //     0x657b50: stur            d0, [x0, #7]
    // 0x657b54: ldur            d0, [fp, #-0x30]
    // 0x657b58: StoreField: r0->field_f = d0
    //     0x657b58: stur            d0, [x0, #0xf]
    // 0x657b5c: ldr             x1, [fp, #0x10]
    // 0x657b60: StoreField: r1->field_3f = r0
    //     0x657b60: stur            w0, [x1, #0x3f]
    //     0x657b64: ldurb           w16, [x1, #-1]
    //     0x657b68: ldurb           w17, [x0, #-1]
    //     0x657b6c: and             x16, x17, x16, lsr #2
    //     0x657b70: tst             x16, HEAP, lsr #32
    //     0x657b74: b.eq            #0x657b7c
    //     0x657b78: bl              #0xd6826c
    // 0x657b7c: b               #0x657b8c
    // 0x657b80: mov             x1, x2
    // 0x657b84: b               #0x657b8c
    // 0x657b88: mov             x1, x2
    // 0x657b8c: LoadField: r0 = r1->field_23
    //     0x657b8c: ldur            w0, [x1, #0x23]
    // 0x657b90: DecompressPointer r0
    //     0x657b90: add             x0, x0, HEAP, lsl #32
    // 0x657b94: cmp             w0, NULL
    // 0x657b98: b.eq            #0x658248
    // 0x657b9c: LoadField: r2 = r1->field_3f
    //     0x657b9c: ldur            w2, [x1, #0x3f]
    // 0x657ba0: DecompressPointer r2
    //     0x657ba0: add             x2, x2, HEAP, lsl #32
    // 0x657ba4: r16 = Sentinel
    //     0x657ba4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x657ba8: cmp             w2, w16
    // 0x657bac: b.eq            #0x65824c
    // 0x657bb0: stp             x2, x0, [SP, #-0x10]!
    // 0x657bb4: r0 = shift()
    //     0x657bb4: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x657bb8: add             SP, SP, #0x10
    // 0x657bbc: ldr             x1, [fp, #0x10]
    // 0x657bc0: StoreField: r1->field_23 = r0
    //     0x657bc0: stur            w0, [x1, #0x23]
    //     0x657bc4: ldurb           w16, [x1, #-1]
    //     0x657bc8: ldurb           w17, [x0, #-1]
    //     0x657bcc: and             x16, x17, x16, lsr #2
    //     0x657bd0: tst             x16, HEAP, lsr #32
    //     0x657bd4: b.eq            #0x657bdc
    //     0x657bd8: bl              #0xd6826c
    // 0x657bdc: b               #0x657be4
    // 0x657be0: ldr             x1, [fp, #0x10]
    // 0x657be4: r0 = Instance_Offset
    //     0x657be4: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x657be8: StoreField: r1->field_3f = r0
    //     0x657be8: stur            w0, [x1, #0x3f]
    // 0x657bec: LoadField: r0 = r1->field_23
    //     0x657bec: ldur            w0, [x1, #0x23]
    // 0x657bf0: DecompressPointer r0
    //     0x657bf0: add             x0, x0, HEAP, lsl #32
    // 0x657bf4: stur            x0, [fp, #-8]
    // 0x657bf8: cmp             w0, NULL
    // 0x657bfc: b.eq            #0x658258
    // 0x657c00: SaveReg r1
    //     0x657c00: str             x1, [SP, #-8]!
    // 0x657c04: r0 = screenCropRect()
    //     0x657c04: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x657c08: add             SP, SP, #8
    // 0x657c0c: cmp             w0, NULL
    // 0x657c10: b.eq            #0x65825c
    // 0x657c14: ldr             x16, [fp, #0x10]
    // 0x657c18: ldur            lr, [fp, #-8]
    // 0x657c1c: stp             lr, x16, [SP, #-0x10]!
    // 0x657c20: SaveReg r0
    //     0x657c20: str             x0, [SP, #-8]!
    // 0x657c24: r0 = computeBoundary()
    //     0x657c24: bl              #0x658424  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::computeBoundary
    // 0x657c28: add             SP, SP, #0x18
    // 0x657c2c: ldr             x1, [fp, #0x10]
    // 0x657c30: StoreField: r1->field_23 = r0
    //     0x657c30: stur            w0, [x1, #0x23]
    //     0x657c34: ldurb           w16, [x1, #-1]
    //     0x657c38: ldurb           w17, [x0, #-1]
    //     0x657c3c: and             x16, x17, x16, lsr #2
    //     0x657c40: tst             x16, HEAP, lsr #32
    //     0x657c44: b.eq            #0x657c4c
    //     0x657c48: bl              #0xd6826c
    // 0x657c4c: SaveReg r1
    //     0x657c4c: str             x1, [SP, #-8]!
    // 0x657c50: r0 = screenCropRect()
    //     0x657c50: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x657c54: add             SP, SP, #8
    // 0x657c58: cmp             w0, NULL
    // 0x657c5c: b.eq            #0x658068
    // 0x657c60: ldr             x0, [fp, #0x10]
    // 0x657c64: SaveReg r0
    //     0x657c64: str             x0, [SP, #-8]!
    // 0x657c68: r0 = screenCropRect()
    //     0x657c68: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x657c6c: add             SP, SP, #8
    // 0x657c70: cmp             w0, NULL
    // 0x657c74: b.eq            #0x658260
    // 0x657c78: ldr             x1, [fp, #0x10]
    // 0x657c7c: LoadField: r2 = r1->field_23
    //     0x657c7c: ldur            w2, [x1, #0x23]
    // 0x657c80: DecompressPointer r2
    //     0x657c80: add             x2, x2, HEAP, lsl #32
    // 0x657c84: cmp             w2, NULL
    // 0x657c88: b.eq            #0x658264
    // 0x657c8c: stp             x2, x0, [SP, #-0x10]!
    // 0x657c90: r0 = expandToInclude()
    //     0x657c90: bl              #0x5251a0  ; [dart:ui] Rect::expandToInclude
    // 0x657c94: add             SP, SP, #0x10
    // 0x657c98: mov             x1, x0
    // 0x657c9c: ldr             x0, [fp, #0x10]
    // 0x657ca0: stur            x1, [fp, #-0x10]
    // 0x657ca4: LoadField: r2 = r0->field_23
    //     0x657ca4: ldur            w2, [x0, #0x23]
    // 0x657ca8: DecompressPointer r2
    //     0x657ca8: add             x2, x2, HEAP, lsl #32
    // 0x657cac: stur            x2, [fp, #-8]
    // 0x657cb0: cmp             w2, NULL
    // 0x657cb4: b.ne            #0x657cc0
    // 0x657cb8: mov             x0, x1
    // 0x657cbc: b               #0x657d44
    // 0x657cc0: cmp             w1, w2
    // 0x657cc4: b.eq            #0x657d3c
    // 0x657cc8: r16 = Rect
    //     0x657cc8: ldr             x16, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0x657ccc: r30 = Rect
    //     0x657ccc: ldr             lr, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0x657cd0: stp             lr, x16, [SP, #-0x10]!
    // 0x657cd4: r0 = ==()
    //     0x657cd4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x657cd8: add             SP, SP, #0x10
    // 0x657cdc: tbz             w0, #4, #0x657ce8
    // 0x657ce0: ldur            x0, [fp, #-0x10]
    // 0x657ce4: b               #0x657d44
    // 0x657ce8: ldur            x0, [fp, #-0x10]
    // 0x657cec: ldur            x1, [fp, #-8]
    // 0x657cf0: LoadField: d0 = r1->field_7
    //     0x657cf0: ldur            d0, [x1, #7]
    // 0x657cf4: LoadField: d1 = r0->field_7
    //     0x657cf4: ldur            d1, [x0, #7]
    // 0x657cf8: fcmp            d0, d1
    // 0x657cfc: b.vs            #0x657d44
    // 0x657d00: b.ne            #0x657d44
    // 0x657d04: LoadField: d0 = r1->field_f
    //     0x657d04: ldur            d0, [x1, #0xf]
    // 0x657d08: LoadField: d1 = r0->field_f
    //     0x657d08: ldur            d1, [x0, #0xf]
    // 0x657d0c: fcmp            d0, d1
    // 0x657d10: b.vs            #0x657d44
    // 0x657d14: b.ne            #0x657d44
    // 0x657d18: LoadField: d0 = r1->field_17
    //     0x657d18: ldur            d0, [x1, #0x17]
    // 0x657d1c: LoadField: d1 = r0->field_17
    //     0x657d1c: ldur            d1, [x0, #0x17]
    // 0x657d20: fcmp            d0, d1
    // 0x657d24: b.vs            #0x657d44
    // 0x657d28: b.ne            #0x657d44
    // 0x657d2c: LoadField: d0 = r1->field_1f
    //     0x657d2c: ldur            d0, [x1, #0x1f]
    // 0x657d30: LoadField: d1 = r0->field_1f
    //     0x657d30: ldur            d1, [x0, #0x1f]
    // 0x657d34: fcmp            d0, d1
    // 0x657d38: b.ne            #0x657d44
    // 0x657d3c: ldr             x1, [fp, #0x10]
    // 0x657d40: b               #0x658100
    // 0x657d44: ldr             x16, [fp, #0x10]
    // 0x657d48: SaveReg r16
    //     0x657d48: str             x16, [SP, #-8]!
    // 0x657d4c: r0 = screenCropRect()
    //     0x657d4c: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x657d50: add             SP, SP, #8
    // 0x657d54: cmp             w0, NULL
    // 0x657d58: b.eq            #0x658268
    // 0x657d5c: ldur            x16, [fp, #-0x10]
    // 0x657d60: stp             x0, x16, [SP, #-0x10]!
    // 0x657d64: r0 = RectExtension.topIsSame()
    //     0x657d64: bl              #0x658d2c  ; [package:extended_image/src/utils.dart] ::RectExtension.topIsSame
    // 0x657d68: add             SP, SP, #0x10
    // 0x657d6c: stur            x0, [fp, #-8]
    // 0x657d70: ldr             x16, [fp, #0x10]
    // 0x657d74: SaveReg r16
    //     0x657d74: str             x16, [SP, #-8]!
    // 0x657d78: r0 = screenCropRect()
    //     0x657d78: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x657d7c: add             SP, SP, #8
    // 0x657d80: cmp             w0, NULL
    // 0x657d84: b.eq            #0x65826c
    // 0x657d88: ldur            x16, [fp, #-0x10]
    // 0x657d8c: stp             x0, x16, [SP, #-0x10]!
    // 0x657d90: r0 = RectExtension.leftIsSame()
    //     0x657d90: bl              #0x658cac  ; [package:extended_image/src/utils.dart] ::RectExtension.leftIsSame
    // 0x657d94: add             SP, SP, #0x10
    // 0x657d98: stur            x0, [fp, #-0x18]
    // 0x657d9c: ldr             x16, [fp, #0x10]
    // 0x657da0: SaveReg r16
    //     0x657da0: str             x16, [SP, #-8]!
    // 0x657da4: r0 = screenCropRect()
    //     0x657da4: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x657da8: add             SP, SP, #8
    // 0x657dac: cmp             w0, NULL
    // 0x657db0: b.eq            #0x658270
    // 0x657db4: ldur            x16, [fp, #-0x10]
    // 0x657db8: stp             x0, x16, [SP, #-0x10]!
    // 0x657dbc: r0 = RectExtension.bottomIsSame()
    //     0x657dbc: bl              #0x658c2c  ; [package:extended_image/src/utils.dart] ::RectExtension.bottomIsSame
    // 0x657dc0: add             SP, SP, #0x10
    // 0x657dc4: stur            x0, [fp, #-0x20]
    // 0x657dc8: ldr             x16, [fp, #0x10]
    // 0x657dcc: SaveReg r16
    //     0x657dcc: str             x16, [SP, #-8]!
    // 0x657dd0: r0 = screenCropRect()
    //     0x657dd0: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x657dd4: add             SP, SP, #8
    // 0x657dd8: cmp             w0, NULL
    // 0x657ddc: b.eq            #0x658274
    // 0x657de0: ldur            x16, [fp, #-0x10]
    // 0x657de4: stp             x0, x16, [SP, #-0x10]!
    // 0x657de8: r0 = RectExtension.rightIsSame()
    //     0x657de8: bl              #0x658b58  ; [package:extended_image/src/utils.dart] ::RectExtension.rightIsSame
    // 0x657dec: add             SP, SP, #0x10
    // 0x657df0: mov             x1, x0
    // 0x657df4: ldur            x0, [fp, #-8]
    // 0x657df8: tbnz            w0, #4, #0x657ee4
    // 0x657dfc: ldur            x0, [fp, #-0x20]
    // 0x657e00: tbnz            w0, #4, #0x657ed4
    // 0x657e04: ldr             x1, [fp, #0x10]
    // 0x657e08: ldur            x0, [fp, #-0x10]
    // 0x657e0c: SaveReg r0
    //     0x657e0c: str             x0, [SP, #-8]!
    // 0x657e10: r0 = center()
    //     0x657e10: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x657e14: add             SP, SP, #8
    // 0x657e18: mov             x1, x0
    // 0x657e1c: ldur            x0, [fp, #-0x10]
    // 0x657e20: stur            x1, [fp, #-0x20]
    // 0x657e24: LoadField: d0 = r0->field_1f
    //     0x657e24: ldur            d0, [x0, #0x1f]
    // 0x657e28: LoadField: d1 = r0->field_f
    //     0x657e28: ldur            d1, [x0, #0xf]
    // 0x657e2c: fsub            d2, d0, d1
    // 0x657e30: ldr             x0, [fp, #0x10]
    // 0x657e34: LoadField: r2 = r0->field_23
    //     0x657e34: ldur            w2, [x0, #0x23]
    // 0x657e38: DecompressPointer r2
    //     0x657e38: add             x2, x2, HEAP, lsl #32
    // 0x657e3c: cmp             w2, NULL
    // 0x657e40: b.eq            #0x658278
    // 0x657e44: LoadField: d0 = r2->field_1f
    //     0x657e44: ldur            d0, [x2, #0x1f]
    // 0x657e48: LoadField: d1 = r2->field_f
    //     0x657e48: ldur            d1, [x2, #0xf]
    // 0x657e4c: fsub            d3, d0, d1
    // 0x657e50: fdiv            d0, d2, d3
    // 0x657e54: LoadField: d1 = r2->field_17
    //     0x657e54: ldur            d1, [x2, #0x17]
    // 0x657e58: LoadField: d3 = r2->field_7
    //     0x657e58: ldur            d3, [x2, #7]
    // 0x657e5c: fsub            d4, d1, d3
    // 0x657e60: fmul            d1, d0, d4
    // 0x657e64: stur            d1, [fp, #-0x30]
    // 0x657e68: r2 = inline_Allocate_Double()
    //     0x657e68: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x657e6c: add             x2, x2, #0x10
    //     0x657e70: cmp             x3, x2
    //     0x657e74: b.ls            #0x65827c
    //     0x657e78: str             x2, [THR, #0x60]  ; THR::top
    //     0x657e7c: sub             x2, x2, #0xf
    //     0x657e80: mov             x3, #0xd108
    //     0x657e84: movk            x3, #3, lsl #16
    //     0x657e88: stur            x3, [x2, #-1]
    // 0x657e8c: StoreField: r2->field_7 = d2
    //     0x657e8c: stur            d2, [x2, #7]
    // 0x657e90: stur            x2, [fp, #-8]
    // 0x657e94: r0 = Rect()
    //     0x657e94: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x657e98: stur            x0, [fp, #-0x28]
    // 0x657e9c: ldur            x16, [fp, #-0x20]
    // 0x657ea0: stp             x16, x0, [SP, #-0x10]!
    // 0x657ea4: ldur            x16, [fp, #-8]
    // 0x657ea8: SaveReg r16
    //     0x657ea8: str             x16, [SP, #-8]!
    // 0x657eac: ldur            d0, [fp, #-0x30]
    // 0x657eb0: SaveReg d0
    //     0x657eb0: str             d0, [SP, #-8]!
    // 0x657eb4: r0 = Rect.fromCenter()
    //     0x657eb4: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0x657eb8: add             SP, SP, #0x20
    // 0x657ebc: ldr             x2, [fp, #0x10]
    // 0x657ec0: r3 = true
    //     0x657ec0: add             x3, NULL, #0x20  ; true
    // 0x657ec4: StoreField: r2->field_2b = r3
    //     0x657ec4: stur            w3, [x2, #0x2b]
    // 0x657ec8: ldur            x0, [fp, #-0x28]
    // 0x657ecc: mov             x1, x2
    // 0x657ed0: b               #0x657fcc
    // 0x657ed4: ldr             x2, [fp, #0x10]
    // 0x657ed8: ldur            x0, [fp, #-0x10]
    // 0x657edc: r3 = true
    //     0x657edc: add             x3, NULL, #0x20  ; true
    // 0x657ee0: b               #0x657ef0
    // 0x657ee4: ldr             x2, [fp, #0x10]
    // 0x657ee8: ldur            x0, [fp, #-0x10]
    // 0x657eec: r3 = true
    //     0x657eec: add             x3, NULL, #0x20  ; true
    // 0x657ef0: ldur            x4, [fp, #-0x18]
    // 0x657ef4: tbnz            w4, #4, #0x657fc8
    // 0x657ef8: tbnz            w1, #4, #0x657fc0
    // 0x657efc: SaveReg r0
    //     0x657efc: str             x0, [SP, #-8]!
    // 0x657f00: r0 = center()
    //     0x657f00: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x657f04: add             SP, SP, #8
    // 0x657f08: mov             x1, x0
    // 0x657f0c: ldur            x0, [fp, #-0x10]
    // 0x657f10: stur            x1, [fp, #-0x18]
    // 0x657f14: LoadField: d0 = r0->field_17
    //     0x657f14: ldur            d0, [x0, #0x17]
    // 0x657f18: LoadField: d1 = r0->field_7
    //     0x657f18: ldur            d1, [x0, #7]
    // 0x657f1c: fsub            d2, d0, d1
    // 0x657f20: ldr             x0, [fp, #0x10]
    // 0x657f24: stur            d2, [fp, #-0x30]
    // 0x657f28: LoadField: r2 = r0->field_23
    //     0x657f28: ldur            w2, [x0, #0x23]
    // 0x657f2c: DecompressPointer r2
    //     0x657f2c: add             x2, x2, HEAP, lsl #32
    // 0x657f30: cmp             w2, NULL
    // 0x657f34: b.eq            #0x658298
    // 0x657f38: LoadField: d0 = r2->field_17
    //     0x657f38: ldur            d0, [x2, #0x17]
    // 0x657f3c: LoadField: d1 = r2->field_7
    //     0x657f3c: ldur            d1, [x2, #7]
    // 0x657f40: fsub            d3, d0, d1
    // 0x657f44: fdiv            d0, d2, d3
    // 0x657f48: LoadField: d1 = r2->field_1f
    //     0x657f48: ldur            d1, [x2, #0x1f]
    // 0x657f4c: LoadField: d3 = r2->field_f
    //     0x657f4c: ldur            d3, [x2, #0xf]
    // 0x657f50: fsub            d4, d1, d3
    // 0x657f54: fmul            d1, d0, d4
    // 0x657f58: r2 = inline_Allocate_Double()
    //     0x657f58: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x657f5c: add             x2, x2, #0x10
    //     0x657f60: cmp             x3, x2
    //     0x657f64: b.ls            #0x65829c
    //     0x657f68: str             x2, [THR, #0x60]  ; THR::top
    //     0x657f6c: sub             x2, x2, #0xf
    //     0x657f70: mov             x3, #0xd108
    //     0x657f74: movk            x3, #3, lsl #16
    //     0x657f78: stur            x3, [x2, #-1]
    // 0x657f7c: StoreField: r2->field_7 = d1
    //     0x657f7c: stur            d1, [x2, #7]
    // 0x657f80: stur            x2, [fp, #-8]
    // 0x657f84: r0 = Rect()
    //     0x657f84: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x657f88: stur            x0, [fp, #-0x20]
    // 0x657f8c: ldur            x16, [fp, #-0x18]
    // 0x657f90: stp             x16, x0, [SP, #-0x10]!
    // 0x657f94: ldur            x16, [fp, #-8]
    // 0x657f98: SaveReg r16
    //     0x657f98: str             x16, [SP, #-8]!
    // 0x657f9c: ldur            d0, [fp, #-0x30]
    // 0x657fa0: SaveReg d0
    //     0x657fa0: str             d0, [SP, #-8]!
    // 0x657fa4: r0 = Rect.fromCenter()
    //     0x657fa4: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0x657fa8: add             SP, SP, #0x20
    // 0x657fac: ldr             x1, [fp, #0x10]
    // 0x657fb0: r0 = true
    //     0x657fb0: add             x0, NULL, #0x20  ; true
    // 0x657fb4: StoreField: r1->field_2b = r0
    //     0x657fb4: stur            w0, [x1, #0x2b]
    // 0x657fb8: ldur            x0, [fp, #-0x20]
    // 0x657fbc: b               #0x657fcc
    // 0x657fc0: mov             x1, x2
    // 0x657fc4: b               #0x657fcc
    // 0x657fc8: mov             x1, x2
    // 0x657fcc: stur            x0, [fp, #-8]
    // 0x657fd0: LoadField: d0 = r1->field_2f
    //     0x657fd0: ldur            d0, [x1, #0x2f]
    // 0x657fd4: LoadField: d1 = r0->field_17
    //     0x657fd4: ldur            d1, [x0, #0x17]
    // 0x657fd8: LoadField: d2 = r0->field_7
    //     0x657fd8: ldur            d2, [x0, #7]
    // 0x657fdc: fsub            d3, d1, d2
    // 0x657fe0: LoadField: r2 = r1->field_23
    //     0x657fe0: ldur            w2, [x1, #0x23]
    // 0x657fe4: DecompressPointer r2
    //     0x657fe4: add             x2, x2, HEAP, lsl #32
    // 0x657fe8: cmp             w2, NULL
    // 0x657fec: b.eq            #0x6582b8
    // 0x657ff0: LoadField: d1 = r2->field_17
    //     0x657ff0: ldur            d1, [x2, #0x17]
    // 0x657ff4: LoadField: d2 = r2->field_7
    //     0x657ff4: ldur            d2, [x2, #7]
    // 0x657ff8: fsub            d4, d1, d2
    // 0x657ffc: fdiv            d1, d3, d4
    // 0x658000: fdiv            d2, d0, d1
    // 0x658004: StoreField: r1->field_2f = d2
    //     0x658004: stur            d2, [x1, #0x2f]
    // 0x658008: LoadField: r2 = r1->field_27
    //     0x658008: ldur            w2, [x1, #0x27]
    // 0x65800c: DecompressPointer r2
    //     0x65800c: add             x2, x2, HEAP, lsl #32
    // 0x658010: cmp             w2, NULL
    // 0x658014: b.eq            #0x6582bc
    // 0x658018: stp             x2, x2, [SP, #-0x10]!
    // 0x65801c: r0 = RectExtension.isSame()
    //     0x65801c: bl              #0x658398  ; [package:extended_image/src/utils.dart] ::RectExtension.isSame
    // 0x658020: add             SP, SP, #0x10
    // 0x658024: tbnz            w0, #4, #0x658038
    // 0x658028: ldr             x1, [fp, #0x10]
    // 0x65802c: d0 = 1.000000
    //     0x65802c: fmov            d0, #1.00000000
    // 0x658030: StoreField: r1->field_2f = d0
    //     0x658030: stur            d0, [x1, #0x2f]
    // 0x658034: b               #0x65803c
    // 0x658038: ldr             x1, [fp, #0x10]
    // 0x65803c: LoadField: d0 = r1->field_2f
    //     0x65803c: ldur            d0, [x1, #0x2f]
    // 0x658040: StoreField: r1->field_37 = d0
    //     0x658040: stur            d0, [x1, #0x37]
    // 0x658044: ldur            x0, [fp, #-8]
    // 0x658048: StoreField: r1->field_23 = r0
    //     0x658048: stur            w0, [x1, #0x23]
    //     0x65804c: ldurb           w16, [x1, #-1]
    //     0x658050: ldurb           w17, [x0, #-1]
    //     0x658054: and             x16, x17, x16, lsr #2
    //     0x658058: tst             x16, HEAP, lsr #32
    //     0x65805c: b.eq            #0x658064
    //     0x658060: bl              #0xd6826c
    // 0x658064: b               #0x658100
    // 0x658068: ldr             x1, [fp, #0x10]
    // 0x65806c: b               #0x658100
    // 0x658070: LoadField: r0 = r1->field_27
    //     0x658070: ldur            w0, [x1, #0x27]
    // 0x658074: DecompressPointer r0
    //     0x658074: add             x0, x0, HEAP, lsl #32
    // 0x658078: cmp             w0, NULL
    // 0x65807c: b.eq            #0x6582c0
    // 0x658080: stp             x0, x1, [SP, #-0x10]!
    // 0x658084: r0 = getRectWithScale()
    //     0x658084: bl              #0x6582cc  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::getRectWithScale
    // 0x658088: add             SP, SP, #0x10
    // 0x65808c: mov             x2, x0
    // 0x658090: ldr             x1, [fp, #0x10]
    // 0x658094: stur            x2, [fp, #-8]
    // 0x658098: StoreField: r1->field_23 = r0
    //     0x658098: stur            w0, [x1, #0x23]
    //     0x65809c: ldurb           w16, [x1, #-1]
    //     0x6580a0: ldurb           w17, [x0, #-1]
    //     0x6580a4: and             x16, x17, x16, lsr #2
    //     0x6580a8: tst             x16, HEAP, lsr #32
    //     0x6580ac: b.eq            #0x6580b4
    //     0x6580b0: bl              #0xd6826c
    // 0x6580b4: SaveReg r1
    //     0x6580b4: str             x1, [SP, #-8]!
    // 0x6580b8: r0 = screenCropRect()
    //     0x6580b8: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x6580bc: add             SP, SP, #8
    // 0x6580c0: cmp             w0, NULL
    // 0x6580c4: b.eq            #0x6582c4
    // 0x6580c8: ldr             x16, [fp, #0x10]
    // 0x6580cc: ldur            lr, [fp, #-8]
    // 0x6580d0: stp             lr, x16, [SP, #-0x10]!
    // 0x6580d4: SaveReg r0
    //     0x6580d4: str             x0, [SP, #-8]!
    // 0x6580d8: r0 = computeBoundary()
    //     0x6580d8: bl              #0x658424  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::computeBoundary
    // 0x6580dc: add             SP, SP, #0x18
    // 0x6580e0: ldr             x1, [fp, #0x10]
    // 0x6580e4: StoreField: r1->field_23 = r0
    //     0x6580e4: stur            w0, [x1, #0x23]
    //     0x6580e8: ldurb           w16, [x1, #-1]
    //     0x6580ec: ldurb           w17, [x0, #-1]
    //     0x6580f0: and             x16, x17, x16, lsr #2
    //     0x6580f4: tst             x16, HEAP, lsr #32
    //     0x6580f8: b.eq            #0x658100
    //     0x6580fc: bl              #0xd6826c
    // 0x658100: LoadField: r0 = r1->field_23
    //     0x658100: ldur            w0, [x1, #0x23]
    // 0x658104: DecompressPointer r0
    //     0x658104: add             x0, x0, HEAP, lsl #32
    // 0x658108: cmp             w0, NULL
    // 0x65810c: b.eq            #0x6582c8
    // 0x658110: LeaveFrame
    //     0x658110: mov             SP, fp
    //     0x658114: ldp             fp, lr, [SP], #0x10
    // 0x658118: ret
    //     0x658118: ret             
    // 0x65811c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65811c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658120: b               #0x6576c4
    // 0x658124: r0 = NullCastErrorSharedWithFPURegs()
    //     0x658124: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x658128: stp             q2, q3, [SP, #-0x20]!
    // 0x65812c: stp             q0, q1, [SP, #-0x20]!
    // 0x658130: stp             x0, x1, [SP, #-0x10]!
    // 0x658134: r0 = AllocateDouble()
    //     0x658134: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658138: mov             x2, x0
    // 0x65813c: ldp             x0, x1, [SP], #0x10
    // 0x658140: ldp             q0, q1, [SP], #0x20
    // 0x658144: ldp             q2, q3, [SP], #0x20
    // 0x658148: b               #0x657770
    // 0x65814c: stp             q2, q3, [SP, #-0x20]!
    // 0x658150: SaveReg d0
    //     0x658150: str             q0, [SP, #-0x10]!
    // 0x658154: stp             x1, x2, [SP, #-0x10]!
    // 0x658158: SaveReg r0
    //     0x658158: str             x0, [SP, #-8]!
    // 0x65815c: r0 = AllocateDouble()
    //     0x65815c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658160: mov             x3, x0
    // 0x658164: RestoreReg r0
    //     0x658164: ldr             x0, [SP], #8
    // 0x658168: ldp             x1, x2, [SP], #0x10
    // 0x65816c: RestoreReg d0
    //     0x65816c: ldr             q0, [SP], #0x10
    // 0x658170: ldp             q2, q3, [SP], #0x20
    // 0x658174: b               #0x657798
    // 0x658178: stp             q0, q3, [SP, #-0x20]!
    // 0x65817c: stp             x2, x3, [SP, #-0x10]!
    // 0x658180: stp             x0, x1, [SP, #-0x10]!
    // 0x658184: r0 = AllocateDouble()
    //     0x658184: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658188: mov             x4, x0
    // 0x65818c: ldp             x0, x1, [SP], #0x10
    // 0x658190: ldp             x2, x3, [SP], #0x10
    // 0x658194: ldp             q0, q3, [SP], #0x20
    // 0x658198: b               #0x6577c0
    // 0x65819c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65819c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6581a0: stp             q1, q2, [SP, #-0x20]!
    // 0x6581a4: SaveReg d0
    //     0x6581a4: str             q0, [SP, #-0x10]!
    // 0x6581a8: stp             x0, x1, [SP, #-0x10]!
    // 0x6581ac: r0 = AllocateDouble()
    //     0x6581ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6581b0: mov             x2, x0
    // 0x6581b4: ldp             x0, x1, [SP], #0x10
    // 0x6581b8: RestoreReg d0
    //     0x6581b8: ldr             q0, [SP], #0x10
    // 0x6581bc: ldp             q1, q2, [SP], #0x20
    // 0x6581c0: b               #0x657824
    // 0x6581c4: stp             q1, q2, [SP, #-0x20]!
    // 0x6581c8: stp             x1, x2, [SP, #-0x10]!
    // 0x6581cc: SaveReg r0
    //     0x6581cc: str             x0, [SP, #-8]!
    // 0x6581d0: r0 = AllocateDouble()
    //     0x6581d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6581d4: mov             x3, x0
    // 0x6581d8: RestoreReg r0
    //     0x6581d8: ldr             x0, [SP], #8
    // 0x6581dc: ldp             x1, x2, [SP], #0x10
    // 0x6581e0: ldp             q1, q2, [SP], #0x20
    // 0x6581e4: b               #0x65784c
    // 0x6581e8: SaveReg d2
    //     0x6581e8: str             q2, [SP, #-0x10]!
    // 0x6581ec: stp             x2, x3, [SP, #-0x10]!
    // 0x6581f0: stp             x0, x1, [SP, #-0x10]!
    // 0x6581f4: r0 = AllocateDouble()
    //     0x6581f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6581f8: mov             x4, x0
    // 0x6581fc: ldp             x0, x1, [SP], #0x10
    // 0x658200: ldp             x2, x3, [SP], #0x10
    // 0x658204: RestoreReg d2
    //     0x658204: ldr             q2, [SP], #0x10
    // 0x658208: b               #0x657874
    // 0x65820c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65820c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x658210: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658210: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658214: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658214: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658218: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658218: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65821c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65821c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658220: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658220: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658224: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658224: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658228: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658228: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65822c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65822c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658230: r9 = delta
    //     0x658230: add             x9, PP, #0x38, lsl #12  ; [pp+0x38480] Field <EditActionDetails.delta>: late (offset: 0x40)
    //     0x658234: ldr             x9, [x9, #0x480]
    // 0x658238: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x658238: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x65823c: r9 = delta
    //     0x65823c: add             x9, PP, #0x38, lsl #12  ; [pp+0x38480] Field <EditActionDetails.delta>: late (offset: 0x40)
    //     0x658240: ldr             x9, [x9, #0x480]
    // 0x658244: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x658244: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x658248: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658248: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65824c: r9 = delta
    //     0x65824c: add             x9, PP, #0x38, lsl #12  ; [pp+0x38480] Field <EditActionDetails.delta>: late (offset: 0x40)
    //     0x658250: ldr             x9, [x9, #0x480]
    // 0x658254: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x658254: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x658258: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658258: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65825c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65825c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658260: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658260: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658264: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658264: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658268: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65826c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65826c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658270: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658270: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658274: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x658274: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x658278: r0 = NullCastErrorSharedWithFPURegs()
    //     0x658278: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x65827c: stp             q1, q2, [SP, #-0x20]!
    // 0x658280: stp             x0, x1, [SP, #-0x10]!
    // 0x658284: r0 = AllocateDouble()
    //     0x658284: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658288: mov             x2, x0
    // 0x65828c: ldp             x0, x1, [SP], #0x10
    // 0x658290: ldp             q1, q2, [SP], #0x20
    // 0x658294: b               #0x657e8c
    // 0x658298: r0 = NullCastErrorSharedWithFPURegs()
    //     0x658298: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x65829c: stp             q1, q2, [SP, #-0x20]!
    // 0x6582a0: stp             x0, x1, [SP, #-0x10]!
    // 0x6582a4: r0 = AllocateDouble()
    //     0x6582a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6582a8: mov             x2, x0
    // 0x6582ac: ldp             x0, x1, [SP], #0x10
    // 0x6582b0: ldp             q1, q2, [SP], #0x20
    // 0x6582b4: b               #0x657f7c
    // 0x6582b8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6582b8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6582bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6582bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6582c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6582c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6582c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6582c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6582c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6582c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getRectWithScale(/* No info */) {
    // ** addr: 0x6582cc, size: 0xcc
    // 0x6582cc: EnterFrame
    //     0x6582cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6582d0: mov             fp, SP
    // 0x6582d4: AllocStack(0x28)
    //     0x6582d4: sub             SP, SP, #0x28
    // 0x6582d8: CheckStackOverflow
    //     0x6582d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6582dc: cmp             SP, x16
    //     0x6582e0: b.ls            #0x658390
    // 0x6582e4: ldr             x0, [fp, #0x10]
    // 0x6582e8: LoadField: d0 = r0->field_17
    //     0x6582e8: ldur            d0, [x0, #0x17]
    // 0x6582ec: LoadField: d1 = r0->field_7
    //     0x6582ec: ldur            d1, [x0, #7]
    // 0x6582f0: fsub            d2, d0, d1
    // 0x6582f4: ldr             x1, [fp, #0x18]
    // 0x6582f8: LoadField: d0 = r1->field_2f
    //     0x6582f8: ldur            d0, [x1, #0x2f]
    // 0x6582fc: fmul            d1, d2, d0
    // 0x658300: stur            d1, [fp, #-0x10]
    // 0x658304: LoadField: d2 = r0->field_1f
    //     0x658304: ldur            d2, [x0, #0x1f]
    // 0x658308: LoadField: d3 = r0->field_f
    //     0x658308: ldur            d3, [x0, #0xf]
    // 0x65830c: fsub            d4, d2, d3
    // 0x658310: fmul            d2, d4, d0
    // 0x658314: stur            d2, [fp, #-8]
    // 0x658318: SaveReg r0
    //     0x658318: str             x0, [SP, #-8]!
    // 0x65831c: r0 = center()
    //     0x65831c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x658320: add             SP, SP, #8
    // 0x658324: LoadField: d0 = r0->field_7
    //     0x658324: ldur            d0, [x0, #7]
    // 0x658328: ldur            d2, [fp, #-0x10]
    // 0x65832c: d1 = 2.000000
    //     0x65832c: fmov            d1, #2.00000000
    // 0x658330: fdiv            d3, d2, d1
    // 0x658334: fsub            d4, d0, d3
    // 0x658338: stur            d4, [fp, #-0x28]
    // 0x65833c: LoadField: d0 = r0->field_f
    //     0x65833c: ldur            d0, [x0, #0xf]
    // 0x658340: ldur            d3, [fp, #-8]
    // 0x658344: fdiv            d5, d3, d1
    // 0x658348: fsub            d1, d0, d5
    // 0x65834c: stur            d1, [fp, #-0x20]
    // 0x658350: fadd            d0, d4, d2
    // 0x658354: stur            d0, [fp, #-0x18]
    // 0x658358: fadd            d2, d1, d3
    // 0x65835c: stur            d2, [fp, #-0x10]
    // 0x658360: r0 = Rect()
    //     0x658360: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x658364: ldur            d0, [fp, #-0x28]
    // 0x658368: StoreField: r0->field_7 = d0
    //     0x658368: stur            d0, [x0, #7]
    // 0x65836c: ldur            d0, [fp, #-0x20]
    // 0x658370: StoreField: r0->field_f = d0
    //     0x658370: stur            d0, [x0, #0xf]
    // 0x658374: ldur            d0, [fp, #-0x18]
    // 0x658378: StoreField: r0->field_17 = d0
    //     0x658378: stur            d0, [x0, #0x17]
    // 0x65837c: ldur            d0, [fp, #-0x10]
    // 0x658380: StoreField: r0->field_1f = d0
    //     0x658380: stur            d0, [x0, #0x1f]
    // 0x658384: LeaveFrame
    //     0x658384: mov             SP, fp
    //     0x658388: ldp             fp, lr, [SP], #0x10
    // 0x65838c: ret
    //     0x65838c: ret             
    // 0x658390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x658390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658394: b               #0x6582e4
  }
  _ computeBoundary(/* No info */) {
    // ** addr: 0x658424, size: 0x5c4
    // 0x658424: EnterFrame
    //     0x658424: stp             fp, lr, [SP, #-0x10]!
    //     0x658428: mov             fp, SP
    // 0x65842c: AllocStack(0x38)
    //     0x65842c: sub             SP, SP, #0x38
    // 0x658430: CheckStackOverflow
    //     0x658430: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x658434: cmp             SP, x16
    //     0x658438: b.ls            #0x6588dc
    // 0x65843c: ldr             x0, [fp, #0x20]
    // 0x658440: LoadField: r1 = r0->field_17
    //     0x658440: ldur            w1, [x0, #0x17]
    // 0x658444: DecompressPointer r1
    //     0x658444: add             x1, x1, HEAP, lsl #32
    // 0x658448: tbnz            w1, #4, #0x6585d4
    // 0x65844c: ldr             x2, [fp, #0x18]
    // 0x658450: ldr             x1, [fp, #0x10]
    // 0x658454: LoadField: d0 = r2->field_7
    //     0x658454: ldur            d0, [x2, #7]
    // 0x658458: stur            d0, [fp, #-0x20]
    // 0x65845c: LoadField: d1 = r1->field_7
    //     0x65845c: ldur            d1, [x1, #7]
    // 0x658460: stur            d1, [fp, #-0x18]
    // 0x658464: r3 = inline_Allocate_Double()
    //     0x658464: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x658468: add             x3, x3, #0x10
    //     0x65846c: cmp             x4, x3
    //     0x658470: b.ls            #0x6588e4
    //     0x658474: str             x3, [THR, #0x60]  ; THR::top
    //     0x658478: sub             x3, x3, #0xf
    //     0x65847c: mov             x4, #0xd108
    //     0x658480: movk            x4, #3, lsl #16
    //     0x658484: stur            x4, [x3, #-1]
    // 0x658488: StoreField: r3->field_7 = d0
    //     0x658488: stur            d0, [x3, #7]
    // 0x65848c: SaveReg r3
    //     0x65848c: str             x3, [SP, #-8]!
    // 0x658490: SaveReg d1
    //     0x658490: str             d1, [SP, #-8]!
    // 0x658494: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x658494: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x658498: add             SP, SP, #0x10
    // 0x65849c: tbnz            w0, #4, #0x658500
    // 0x6584a0: ldr             x0, [fp, #0x18]
    // 0x6584a4: ldur            d0, [fp, #-0x20]
    // 0x6584a8: ldur            d1, [fp, #-0x18]
    // 0x6584ac: LoadField: d2 = r0->field_f
    //     0x6584ac: ldur            d2, [x0, #0xf]
    // 0x6584b0: stur            d2, [fp, #-0x38]
    // 0x6584b4: LoadField: d3 = r0->field_17
    //     0x6584b4: ldur            d3, [x0, #0x17]
    // 0x6584b8: fsub            d4, d3, d0
    // 0x6584bc: LoadField: d0 = r0->field_1f
    //     0x6584bc: ldur            d0, [x0, #0x1f]
    // 0x6584c0: fsub            d3, d0, d2
    // 0x6584c4: fadd            d0, d1, d4
    // 0x6584c8: stur            d0, [fp, #-0x30]
    // 0x6584cc: fadd            d4, d2, d3
    // 0x6584d0: stur            d4, [fp, #-0x28]
    // 0x6584d4: r0 = Rect()
    //     0x6584d4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x6584d8: ldur            d0, [fp, #-0x18]
    // 0x6584dc: StoreField: r0->field_7 = d0
    //     0x6584dc: stur            d0, [x0, #7]
    // 0x6584e0: ldur            d1, [fp, #-0x38]
    // 0x6584e4: StoreField: r0->field_f = d1
    //     0x6584e4: stur            d1, [x0, #0xf]
    // 0x6584e8: ldur            d1, [fp, #-0x30]
    // 0x6584ec: StoreField: r0->field_17 = d1
    //     0x6584ec: stur            d1, [x0, #0x17]
    // 0x6584f0: ldur            d1, [fp, #-0x28]
    // 0x6584f4: StoreField: r0->field_1f = d1
    //     0x6584f4: stur            d1, [x0, #0x1f]
    // 0x6584f8: mov             x1, x0
    // 0x6584fc: b               #0x65850c
    // 0x658500: ldr             x0, [fp, #0x18]
    // 0x658504: ldur            d0, [fp, #-0x20]
    // 0x658508: mov             x1, x0
    // 0x65850c: ldr             x0, [fp, #0x10]
    // 0x658510: stur            x1, [fp, #-8]
    // 0x658514: stur            d0, [fp, #-0x28]
    // 0x658518: LoadField: d1 = r1->field_17
    //     0x658518: ldur            d1, [x1, #0x17]
    // 0x65851c: stur            d1, [fp, #-0x20]
    // 0x658520: LoadField: d2 = r0->field_17
    //     0x658520: ldur            d2, [x0, #0x17]
    // 0x658524: stur            d2, [fp, #-0x18]
    // 0x658528: r2 = inline_Allocate_Double()
    //     0x658528: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x65852c: add             x2, x2, #0x10
    //     0x658530: cmp             x3, x2
    //     0x658534: b.ls            #0x658908
    //     0x658538: str             x2, [THR, #0x60]  ; THR::top
    //     0x65853c: sub             x2, x2, #0xf
    //     0x658540: mov             x3, #0xd108
    //     0x658544: movk            x3, #3, lsl #16
    //     0x658548: stur            x3, [x2, #-1]
    // 0x65854c: StoreField: r2->field_7 = d1
    //     0x65854c: stur            d1, [x2, #7]
    // 0x658550: SaveReg r2
    //     0x658550: str             x2, [SP, #-8]!
    // 0x658554: SaveReg d2
    //     0x658554: str             d2, [SP, #-8]!
    // 0x658558: r0 = DoubleExtension.lessThanOrEqualTo()
    //     0x658558: bl              #0x6589e8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThanOrEqualTo
    // 0x65855c: add             SP, SP, #0x10
    // 0x658560: tbnz            w0, #4, #0x6585c8
    // 0x658564: ldur            x0, [fp, #-8]
    // 0x658568: ldur            d1, [fp, #-0x20]
    // 0x65856c: ldur            d2, [fp, #-0x18]
    // 0x658570: ldur            d0, [fp, #-0x28]
    // 0x658574: fsub            d3, d1, d0
    // 0x658578: fsub            d0, d2, d3
    // 0x65857c: stur            d0, [fp, #-0x30]
    // 0x658580: LoadField: d1 = r0->field_f
    //     0x658580: ldur            d1, [x0, #0xf]
    // 0x658584: stur            d1, [fp, #-0x28]
    // 0x658588: LoadField: d2 = r0->field_1f
    //     0x658588: ldur            d2, [x0, #0x1f]
    // 0x65858c: fsub            d4, d2, d1
    // 0x658590: fadd            d2, d0, d3
    // 0x658594: stur            d2, [fp, #-0x20]
    // 0x658598: fadd            d3, d1, d4
    // 0x65859c: stur            d3, [fp, #-0x18]
    // 0x6585a0: r0 = Rect()
    //     0x6585a0: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x6585a4: ldur            d0, [fp, #-0x30]
    // 0x6585a8: StoreField: r0->field_7 = d0
    //     0x6585a8: stur            d0, [x0, #7]
    // 0x6585ac: ldur            d0, [fp, #-0x28]
    // 0x6585b0: StoreField: r0->field_f = d0
    //     0x6585b0: stur            d0, [x0, #0xf]
    // 0x6585b4: ldur            d0, [fp, #-0x20]
    // 0x6585b8: StoreField: r0->field_17 = d0
    //     0x6585b8: stur            d0, [x0, #0x17]
    // 0x6585bc: ldur            d0, [fp, #-0x18]
    // 0x6585c0: StoreField: r0->field_1f = d0
    //     0x6585c0: stur            d0, [x0, #0x1f]
    // 0x6585c4: b               #0x6585cc
    // 0x6585c8: ldur            x0, [fp, #-8]
    // 0x6585cc: mov             x1, x0
    // 0x6585d0: b               #0x6585dc
    // 0x6585d4: ldr             x0, [fp, #0x18]
    // 0x6585d8: mov             x1, x0
    // 0x6585dc: ldr             x0, [fp, #0x20]
    // 0x6585e0: stur            x1, [fp, #-8]
    // 0x6585e4: LoadField: r2 = r0->field_1b
    //     0x6585e4: ldur            w2, [x0, #0x1b]
    // 0x6585e8: DecompressPointer r2
    //     0x6585e8: add             x2, x2, HEAP, lsl #32
    // 0x6585ec: tbnz            w2, #4, #0x658774
    // 0x6585f0: ldr             x2, [fp, #0x10]
    // 0x6585f4: LoadField: d0 = r1->field_1f
    //     0x6585f4: ldur            d0, [x1, #0x1f]
    // 0x6585f8: stur            d0, [fp, #-0x20]
    // 0x6585fc: LoadField: d1 = r2->field_1f
    //     0x6585fc: ldur            d1, [x2, #0x1f]
    // 0x658600: stur            d1, [fp, #-0x18]
    // 0x658604: r3 = inline_Allocate_Double()
    //     0x658604: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x658608: add             x3, x3, #0x10
    //     0x65860c: cmp             x4, x3
    //     0x658610: b.ls            #0x65892c
    //     0x658614: str             x3, [THR, #0x60]  ; THR::top
    //     0x658618: sub             x3, x3, #0xf
    //     0x65861c: mov             x4, #0xd108
    //     0x658620: movk            x4, #3, lsl #16
    //     0x658624: stur            x4, [x3, #-1]
    // 0x658628: StoreField: r3->field_7 = d0
    //     0x658628: stur            d0, [x3, #7]
    // 0x65862c: SaveReg r3
    //     0x65862c: str             x3, [SP, #-8]!
    // 0x658630: SaveReg d1
    //     0x658630: str             d1, [SP, #-8]!
    // 0x658634: r0 = DoubleExtension.lessThanOrEqualTo()
    //     0x658634: bl              #0x6589e8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThanOrEqualTo
    // 0x658638: add             SP, SP, #0x10
    // 0x65863c: tbnz            w0, #4, #0x6586a8
    // 0x658640: ldur            x0, [fp, #-8]
    // 0x658644: ldur            d0, [fp, #-0x20]
    // 0x658648: ldur            d1, [fp, #-0x18]
    // 0x65864c: LoadField: d2 = r0->field_7
    //     0x65864c: ldur            d2, [x0, #7]
    // 0x658650: stur            d2, [fp, #-0x38]
    // 0x658654: LoadField: d3 = r0->field_f
    //     0x658654: ldur            d3, [x0, #0xf]
    // 0x658658: fsub            d4, d0, d3
    // 0x65865c: fsub            d0, d1, d4
    // 0x658660: stur            d0, [fp, #-0x30]
    // 0x658664: LoadField: d1 = r0->field_17
    //     0x658664: ldur            d1, [x0, #0x17]
    // 0x658668: fsub            d3, d1, d2
    // 0x65866c: fadd            d1, d2, d3
    // 0x658670: stur            d1, [fp, #-0x28]
    // 0x658674: fadd            d3, d0, d4
    // 0x658678: stur            d3, [fp, #-0x18]
    // 0x65867c: r0 = Rect()
    //     0x65867c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x658680: ldur            d0, [fp, #-0x38]
    // 0x658684: StoreField: r0->field_7 = d0
    //     0x658684: stur            d0, [x0, #7]
    // 0x658688: ldur            d0, [fp, #-0x30]
    // 0x65868c: StoreField: r0->field_f = d0
    //     0x65868c: stur            d0, [x0, #0xf]
    // 0x658690: ldur            d0, [fp, #-0x28]
    // 0x658694: StoreField: r0->field_17 = d0
    //     0x658694: stur            d0, [x0, #0x17]
    // 0x658698: ldur            d0, [fp, #-0x18]
    // 0x65869c: StoreField: r0->field_1f = d0
    //     0x65869c: stur            d0, [x0, #0x1f]
    // 0x6586a0: mov             x1, x0
    // 0x6586a4: b               #0x6586b4
    // 0x6586a8: ldur            x0, [fp, #-8]
    // 0x6586ac: ldur            d0, [fp, #-0x20]
    // 0x6586b0: mov             x1, x0
    // 0x6586b4: ldr             x0, [fp, #0x10]
    // 0x6586b8: stur            x1, [fp, #-0x10]
    // 0x6586bc: stur            d0, [fp, #-0x28]
    // 0x6586c0: LoadField: d1 = r1->field_f
    //     0x6586c0: ldur            d1, [x1, #0xf]
    // 0x6586c4: stur            d1, [fp, #-0x20]
    // 0x6586c8: LoadField: d2 = r0->field_f
    //     0x6586c8: ldur            d2, [x0, #0xf]
    // 0x6586cc: stur            d2, [fp, #-0x18]
    // 0x6586d0: r2 = inline_Allocate_Double()
    //     0x6586d0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x6586d4: add             x2, x2, #0x10
    //     0x6586d8: cmp             x3, x2
    //     0x6586dc: b.ls            #0x658950
    //     0x6586e0: str             x2, [THR, #0x60]  ; THR::top
    //     0x6586e4: sub             x2, x2, #0xf
    //     0x6586e8: mov             x3, #0xd108
    //     0x6586ec: movk            x3, #3, lsl #16
    //     0x6586f0: stur            x3, [x2, #-1]
    // 0x6586f4: StoreField: r2->field_7 = d1
    //     0x6586f4: stur            d1, [x2, #7]
    // 0x6586f8: SaveReg r2
    //     0x6586f8: str             x2, [SP, #-8]!
    // 0x6586fc: SaveReg d2
    //     0x6586fc: str             d2, [SP, #-8]!
    // 0x658700: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x658700: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x658704: add             SP, SP, #0x10
    // 0x658708: tbnz            w0, #4, #0x658768
    // 0x65870c: ldur            x0, [fp, #-0x10]
    // 0x658710: ldur            d1, [fp, #-0x20]
    // 0x658714: ldur            d2, [fp, #-0x18]
    // 0x658718: ldur            d0, [fp, #-0x28]
    // 0x65871c: LoadField: d3 = r0->field_7
    //     0x65871c: ldur            d3, [x0, #7]
    // 0x658720: stur            d3, [fp, #-0x30]
    // 0x658724: LoadField: d4 = r0->field_17
    //     0x658724: ldur            d4, [x0, #0x17]
    // 0x658728: fsub            d5, d4, d3
    // 0x65872c: fsub            d4, d0, d1
    // 0x658730: fadd            d0, d3, d5
    // 0x658734: stur            d0, [fp, #-0x28]
    // 0x658738: fadd            d1, d2, d4
    // 0x65873c: stur            d1, [fp, #-0x20]
    // 0x658740: r0 = Rect()
    //     0x658740: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x658744: ldur            d0, [fp, #-0x30]
    // 0x658748: StoreField: r0->field_7 = d0
    //     0x658748: stur            d0, [x0, #7]
    // 0x65874c: ldur            d0, [fp, #-0x18]
    // 0x658750: StoreField: r0->field_f = d0
    //     0x658750: stur            d0, [x0, #0xf]
    // 0x658754: ldur            d0, [fp, #-0x28]
    // 0x658758: StoreField: r0->field_17 = d0
    //     0x658758: stur            d0, [x0, #0x17]
    // 0x65875c: ldur            d0, [fp, #-0x20]
    // 0x658760: StoreField: r0->field_1f = d0
    //     0x658760: stur            d0, [x0, #0x1f]
    // 0x658764: b               #0x65876c
    // 0x658768: ldur            x0, [fp, #-0x10]
    // 0x65876c: mov             x1, x0
    // 0x658770: b               #0x65877c
    // 0x658774: mov             x0, x1
    // 0x658778: mov             x1, x0
    // 0x65877c: ldr             x0, [fp, #0x10]
    // 0x658780: stur            x1, [fp, #-8]
    // 0x658784: LoadField: d0 = r1->field_7
    //     0x658784: ldur            d0, [x1, #7]
    // 0x658788: LoadField: d1 = r0->field_7
    //     0x658788: ldur            d1, [x0, #7]
    // 0x65878c: r2 = inline_Allocate_Double()
    //     0x65878c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x658790: add             x2, x2, #0x10
    //     0x658794: cmp             x3, x2
    //     0x658798: b.ls            #0x658974
    //     0x65879c: str             x2, [THR, #0x60]  ; THR::top
    //     0x6587a0: sub             x2, x2, #0xf
    //     0x6587a4: mov             x3, #0xd108
    //     0x6587a8: movk            x3, #3, lsl #16
    //     0x6587ac: stur            x3, [x2, #-1]
    // 0x6587b0: StoreField: r2->field_7 = d0
    //     0x6587b0: stur            d0, [x2, #7]
    // 0x6587b4: SaveReg r2
    //     0x6587b4: str             x2, [SP, #-8]!
    // 0x6587b8: SaveReg d1
    //     0x6587b8: str             d1, [SP, #-8]!
    // 0x6587bc: r0 = DoubleExtension.lessThanOrEqualTo()
    //     0x6587bc: bl              #0x6589e8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThanOrEqualTo
    // 0x6587c0: add             SP, SP, #0x10
    // 0x6587c4: tbnz            w0, #4, #0x658818
    // 0x6587c8: ldr             x0, [fp, #0x10]
    // 0x6587cc: ldur            x1, [fp, #-8]
    // 0x6587d0: LoadField: d0 = r1->field_17
    //     0x6587d0: ldur            d0, [x1, #0x17]
    // 0x6587d4: LoadField: d1 = r0->field_17
    //     0x6587d4: ldur            d1, [x0, #0x17]
    // 0x6587d8: r2 = inline_Allocate_Double()
    //     0x6587d8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x6587dc: add             x2, x2, #0x10
    //     0x6587e0: cmp             x3, x2
    //     0x6587e4: b.ls            #0x658990
    //     0x6587e8: str             x2, [THR, #0x60]  ; THR::top
    //     0x6587ec: sub             x2, x2, #0xf
    //     0x6587f0: mov             x3, #0xd108
    //     0x6587f4: movk            x3, #3, lsl #16
    //     0x6587f8: stur            x3, [x2, #-1]
    // 0x6587fc: StoreField: r2->field_7 = d0
    //     0x6587fc: stur            d0, [x2, #7]
    // 0x658800: SaveReg r2
    //     0x658800: str             x2, [SP, #-8]!
    // 0x658804: SaveReg d1
    //     0x658804: str             d1, [SP, #-8]!
    // 0x658808: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x658808: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x65880c: add             SP, SP, #0x10
    // 0x658810: mov             x3, x0
    // 0x658814: b               #0x65881c
    // 0x658818: r3 = false
    //     0x658818: add             x3, NULL, #0x30  ; false
    // 0x65881c: ldr             x2, [fp, #0x20]
    // 0x658820: ldr             x0, [fp, #0x10]
    // 0x658824: ldur            x1, [fp, #-8]
    // 0x658828: StoreField: r2->field_17 = r3
    //     0x658828: stur            w3, [x2, #0x17]
    // 0x65882c: LoadField: d0 = r1->field_f
    //     0x65882c: ldur            d0, [x1, #0xf]
    // 0x658830: LoadField: d1 = r0->field_f
    //     0x658830: ldur            d1, [x0, #0xf]
    // 0x658834: r3 = inline_Allocate_Double()
    //     0x658834: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x658838: add             x3, x3, #0x10
    //     0x65883c: cmp             x4, x3
    //     0x658840: b.ls            #0x6589ac
    //     0x658844: str             x3, [THR, #0x60]  ; THR::top
    //     0x658848: sub             x3, x3, #0xf
    //     0x65884c: mov             x4, #0xd108
    //     0x658850: movk            x4, #3, lsl #16
    //     0x658854: stur            x4, [x3, #-1]
    // 0x658858: StoreField: r3->field_7 = d0
    //     0x658858: stur            d0, [x3, #7]
    // 0x65885c: SaveReg r3
    //     0x65885c: str             x3, [SP, #-8]!
    // 0x658860: SaveReg d1
    //     0x658860: str             d1, [SP, #-8]!
    // 0x658864: r0 = DoubleExtension.lessThanOrEqualTo()
    //     0x658864: bl              #0x6589e8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThanOrEqualTo
    // 0x658868: add             SP, SP, #0x10
    // 0x65886c: tbnz            w0, #4, #0x6588c0
    // 0x658870: ldr             x0, [fp, #0x10]
    // 0x658874: ldur            x1, [fp, #-8]
    // 0x658878: LoadField: d0 = r1->field_1f
    //     0x658878: ldur            d0, [x1, #0x1f]
    // 0x65887c: LoadField: d1 = r0->field_1f
    //     0x65887c: ldur            d1, [x0, #0x1f]
    // 0x658880: r0 = inline_Allocate_Double()
    //     0x658880: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x658884: add             x0, x0, #0x10
    //     0x658888: cmp             x2, x0
    //     0x65888c: b.ls            #0x6589d0
    //     0x658890: str             x0, [THR, #0x60]  ; THR::top
    //     0x658894: sub             x0, x0, #0xf
    //     0x658898: mov             x2, #0xd108
    //     0x65889c: movk            x2, #3, lsl #16
    //     0x6588a0: stur            x2, [x0, #-1]
    // 0x6588a4: StoreField: r0->field_7 = d0
    //     0x6588a4: stur            d0, [x0, #7]
    // 0x6588a8: SaveReg r0
    //     0x6588a8: str             x0, [SP, #-8]!
    // 0x6588ac: SaveReg d1
    //     0x6588ac: str             d1, [SP, #-8]!
    // 0x6588b0: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x6588b0: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x6588b4: add             SP, SP, #0x10
    // 0x6588b8: mov             x2, x0
    // 0x6588bc: b               #0x6588c4
    // 0x6588c0: r2 = false
    //     0x6588c0: add             x2, NULL, #0x30  ; false
    // 0x6588c4: ldr             x1, [fp, #0x20]
    // 0x6588c8: StoreField: r1->field_1b = r2
    //     0x6588c8: stur            w2, [x1, #0x1b]
    // 0x6588cc: ldur            x0, [fp, #-8]
    // 0x6588d0: LeaveFrame
    //     0x6588d0: mov             SP, fp
    //     0x6588d4: ldp             fp, lr, [SP], #0x10
    // 0x6588d8: ret
    //     0x6588d8: ret             
    // 0x6588dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6588dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6588e0: b               #0x65843c
    // 0x6588e4: stp             q0, q1, [SP, #-0x20]!
    // 0x6588e8: stp             x1, x2, [SP, #-0x10]!
    // 0x6588ec: SaveReg r0
    //     0x6588ec: str             x0, [SP, #-8]!
    // 0x6588f0: r0 = AllocateDouble()
    //     0x6588f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6588f4: mov             x3, x0
    // 0x6588f8: RestoreReg r0
    //     0x6588f8: ldr             x0, [SP], #8
    // 0x6588fc: ldp             x1, x2, [SP], #0x10
    // 0x658900: ldp             q0, q1, [SP], #0x20
    // 0x658904: b               #0x658488
    // 0x658908: stp             q1, q2, [SP, #-0x20]!
    // 0x65890c: SaveReg d0
    //     0x65890c: str             q0, [SP, #-0x10]!
    // 0x658910: stp             x0, x1, [SP, #-0x10]!
    // 0x658914: r0 = AllocateDouble()
    //     0x658914: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658918: mov             x2, x0
    // 0x65891c: ldp             x0, x1, [SP], #0x10
    // 0x658920: RestoreReg d0
    //     0x658920: ldr             q0, [SP], #0x10
    // 0x658924: ldp             q1, q2, [SP], #0x20
    // 0x658928: b               #0x65854c
    // 0x65892c: stp             q0, q1, [SP, #-0x20]!
    // 0x658930: stp             x1, x2, [SP, #-0x10]!
    // 0x658934: SaveReg r0
    //     0x658934: str             x0, [SP, #-8]!
    // 0x658938: r0 = AllocateDouble()
    //     0x658938: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65893c: mov             x3, x0
    // 0x658940: RestoreReg r0
    //     0x658940: ldr             x0, [SP], #8
    // 0x658944: ldp             x1, x2, [SP], #0x10
    // 0x658948: ldp             q0, q1, [SP], #0x20
    // 0x65894c: b               #0x658628
    // 0x658950: stp             q1, q2, [SP, #-0x20]!
    // 0x658954: SaveReg d0
    //     0x658954: str             q0, [SP, #-0x10]!
    // 0x658958: stp             x0, x1, [SP, #-0x10]!
    // 0x65895c: r0 = AllocateDouble()
    //     0x65895c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658960: mov             x2, x0
    // 0x658964: ldp             x0, x1, [SP], #0x10
    // 0x658968: RestoreReg d0
    //     0x658968: ldr             q0, [SP], #0x10
    // 0x65896c: ldp             q1, q2, [SP], #0x20
    // 0x658970: b               #0x6586f4
    // 0x658974: stp             q0, q1, [SP, #-0x20]!
    // 0x658978: stp             x0, x1, [SP, #-0x10]!
    // 0x65897c: r0 = AllocateDouble()
    //     0x65897c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658980: mov             x2, x0
    // 0x658984: ldp             x0, x1, [SP], #0x10
    // 0x658988: ldp             q0, q1, [SP], #0x20
    // 0x65898c: b               #0x6587b0
    // 0x658990: stp             q0, q1, [SP, #-0x20]!
    // 0x658994: stp             x0, x1, [SP, #-0x10]!
    // 0x658998: r0 = AllocateDouble()
    //     0x658998: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65899c: mov             x2, x0
    // 0x6589a0: ldp             x0, x1, [SP], #0x10
    // 0x6589a4: ldp             q0, q1, [SP], #0x20
    // 0x6589a8: b               #0x6587fc
    // 0x6589ac: stp             q0, q1, [SP, #-0x20]!
    // 0x6589b0: stp             x1, x2, [SP, #-0x10]!
    // 0x6589b4: SaveReg r0
    //     0x6589b4: str             x0, [SP, #-8]!
    // 0x6589b8: r0 = AllocateDouble()
    //     0x6589b8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6589bc: mov             x3, x0
    // 0x6589c0: RestoreReg r0
    //     0x6589c0: ldr             x0, [SP], #8
    // 0x6589c4: ldp             x1, x2, [SP], #0x10
    // 0x6589c8: ldp             q0, q1, [SP], #0x20
    // 0x6589cc: b               #0x658858
    // 0x6589d0: stp             q0, q1, [SP, #-0x20]!
    // 0x6589d4: SaveReg r1
    //     0x6589d4: str             x1, [SP, #-8]!
    // 0x6589d8: r0 = AllocateDouble()
    //     0x6589d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6589dc: RestoreReg r1
    //     0x6589dc: ldr             x1, [SP], #8
    // 0x6589e0: ldp             q0, q1, [SP], #0x20
    // 0x6589e4: b               #0x6588a4
  }
  _ initRect(/* No info */) {
    // ** addr: 0x658dac, size: 0xe8
    // 0x658dac: EnterFrame
    //     0x658dac: stp             fp, lr, [SP, #-0x10]!
    //     0x658db0: mov             fp, SP
    // 0x658db4: CheckStackOverflow
    //     0x658db4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x658db8: cmp             SP, x16
    //     0x658dbc: b.ls            #0x658e8c
    // 0x658dc0: ldr             x1, [fp, #0x20]
    // 0x658dc4: LoadField: r0 = r1->field_1f
    //     0x658dc4: ldur            w0, [x1, #0x1f]
    // 0x658dc8: DecompressPointer r0
    //     0x658dc8: add             x0, x0, HEAP, lsl #32
    // 0x658dcc: r2 = LoadClassIdInstr(r0)
    //     0x658dcc: ldur            x2, [x0, #-1]
    //     0x658dd0: ubfx            x2, x2, #0xc, #0x14
    // 0x658dd4: ldr             x16, [fp, #0x18]
    // 0x658dd8: stp             x16, x0, [SP, #-0x10]!
    // 0x658ddc: mov             x0, x2
    // 0x658de0: mov             lr, x0
    // 0x658de4: ldr             lr, [x21, lr, lsl #3]
    // 0x658de8: blr             lr
    // 0x658dec: add             SP, SP, #0x10
    // 0x658df0: tbz             w0, #4, #0x658e20
    // 0x658df4: ldr             x1, [fp, #0x20]
    // 0x658df8: ldr             x0, [fp, #0x18]
    // 0x658dfc: StoreField: r1->field_1f = r0
    //     0x658dfc: stur            w0, [x1, #0x1f]
    //     0x658e00: ldurb           w16, [x1, #-1]
    //     0x658e04: ldurb           w17, [x0, #-1]
    //     0x658e08: and             x16, x17, x16, lsr #2
    //     0x658e0c: tst             x16, HEAP, lsr #32
    //     0x658e10: b.eq            #0x658e18
    //     0x658e14: bl              #0xd6826c
    // 0x658e18: StoreField: r1->field_23 = rNULL
    //     0x658e18: stur            NULL, [x1, #0x23]
    // 0x658e1c: b               #0x658e24
    // 0x658e20: ldr             x1, [fp, #0x20]
    // 0x658e24: LoadField: r0 = r1->field_27
    //     0x658e24: ldur            w0, [x1, #0x27]
    // 0x658e28: DecompressPointer r0
    //     0x658e28: add             x0, x0, HEAP, lsl #32
    // 0x658e2c: r2 = LoadClassIdInstr(r0)
    //     0x658e2c: ldur            x2, [x0, #-1]
    //     0x658e30: ubfx            x2, x2, #0xc, #0x14
    // 0x658e34: ldr             x16, [fp, #0x10]
    // 0x658e38: stp             x16, x0, [SP, #-0x10]!
    // 0x658e3c: mov             x0, x2
    // 0x658e40: mov             lr, x0
    // 0x658e44: ldr             lr, [x21, lr, lsl #3]
    // 0x658e48: blr             lr
    // 0x658e4c: add             SP, SP, #0x10
    // 0x658e50: tbz             w0, #4, #0x658e7c
    // 0x658e54: ldr             x1, [fp, #0x20]
    // 0x658e58: ldr             x0, [fp, #0x10]
    // 0x658e5c: StoreField: r1->field_27 = r0
    //     0x658e5c: stur            w0, [x1, #0x27]
    //     0x658e60: ldurb           w16, [x1, #-1]
    //     0x658e64: ldurb           w17, [x0, #-1]
    //     0x658e68: and             x16, x17, x16, lsr #2
    //     0x658e6c: tst             x16, HEAP, lsr #32
    //     0x658e70: b.eq            #0x658e78
    //     0x658e74: bl              #0xd6826c
    // 0x658e78: StoreField: r1->field_23 = rNULL
    //     0x658e78: stur            NULL, [x1, #0x23]
    // 0x658e7c: r0 = Null
    //     0x658e7c: mov             x0, NULL
    // 0x658e80: LeaveFrame
    //     0x658e80: mov             SP, fp
    //     0x658e84: ldp             fp, lr, [SP], #0x10
    // 0x658e88: ret
    //     0x658e88: ret             
    // 0x658e8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x658e8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658e90: b               #0x658dc0
  }
  get _ cropAspectRatio(/* No info */) {
    // ** addr: 0x82a41c, size: 0xd4
    // 0x82a41c: EnterFrame
    //     0x82a41c: stp             fp, lr, [SP, #-0x10]!
    //     0x82a420: mov             fp, SP
    // 0x82a424: CheckStackOverflow
    //     0x82a424: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a428: cmp             SP, x16
    //     0x82a42c: b.ls            #0x82a4d0
    // 0x82a430: ldr             x0, [fp, #0x10]
    // 0x82a434: LoadField: r1 = r0->field_53
    //     0x82a434: ldur            w1, [x0, #0x53]
    // 0x82a438: DecompressPointer r1
    //     0x82a438: add             x1, x1, HEAP, lsl #32
    // 0x82a43c: cmp             w1, NULL
    // 0x82a440: b.eq            #0x82a4c0
    // 0x82a444: SaveReg r0
    //     0x82a444: str             x0, [SP, #-8]!
    // 0x82a448: r0 = isHalfPi()
    //     0x82a448: bl              #0x82a4f0  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::isHalfPi
    // 0x82a44c: add             SP, SP, #8
    // 0x82a450: tbnz            w0, #4, #0x82a4a4
    // 0x82a454: ldr             x1, [fp, #0x10]
    // 0x82a458: d0 = 1.000000
    //     0x82a458: fmov            d0, #1.00000000
    // 0x82a45c: LoadField: r2 = r1->field_53
    //     0x82a45c: ldur            w2, [x1, #0x53]
    // 0x82a460: DecompressPointer r2
    //     0x82a460: add             x2, x2, HEAP, lsl #32
    // 0x82a464: cmp             w2, NULL
    // 0x82a468: b.eq            #0x82a4d8
    // 0x82a46c: LoadField: d1 = r2->field_7
    //     0x82a46c: ldur            d1, [x2, #7]
    // 0x82a470: fdiv            d2, d0, d1
    // 0x82a474: r2 = inline_Allocate_Double()
    //     0x82a474: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x82a478: add             x2, x2, #0x10
    //     0x82a47c: cmp             x3, x2
    //     0x82a480: b.ls            #0x82a4dc
    //     0x82a484: str             x2, [THR, #0x60]  ; THR::top
    //     0x82a488: sub             x2, x2, #0xf
    //     0x82a48c: mov             x3, #0xd108
    //     0x82a490: movk            x3, #3, lsl #16
    //     0x82a494: stur            x3, [x2, #-1]
    // 0x82a498: StoreField: r2->field_7 = d2
    //     0x82a498: stur            d2, [x2, #7]
    // 0x82a49c: mov             x0, x2
    // 0x82a4a0: b               #0x82a4b4
    // 0x82a4a4: ldr             x1, [fp, #0x10]
    // 0x82a4a8: LoadField: r2 = r1->field_53
    //     0x82a4a8: ldur            w2, [x1, #0x53]
    // 0x82a4ac: DecompressPointer r2
    //     0x82a4ac: add             x2, x2, HEAP, lsl #32
    // 0x82a4b0: mov             x0, x2
    // 0x82a4b4: LeaveFrame
    //     0x82a4b4: mov             SP, fp
    //     0x82a4b8: ldp             fp, lr, [SP], #0x10
    // 0x82a4bc: ret
    //     0x82a4bc: ret             
    // 0x82a4c0: r0 = Null
    //     0x82a4c0: mov             x0, NULL
    // 0x82a4c4: LeaveFrame
    //     0x82a4c4: mov             SP, fp
    //     0x82a4c8: ldp             fp, lr, [SP], #0x10
    // 0x82a4cc: ret
    //     0x82a4cc: ret             
    // 0x82a4d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a4d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a4d4: b               #0x82a430
    // 0x82a4d8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82a4d8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82a4dc: SaveReg d2
    //     0x82a4dc: str             q2, [SP, #-0x10]!
    // 0x82a4e0: r0 = AllocateDouble()
    //     0x82a4e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82a4e4: mov             x2, x0
    // 0x82a4e8: RestoreReg d2
    //     0x82a4e8: ldr             q2, [SP], #0x10
    // 0x82a4ec: b               #0x82a498
  }
  get _ isHalfPi(/* No info */) {
    // ** addr: 0x82a4f0, size: 0x6c
    // 0x82a4f0: EnterFrame
    //     0x82a4f0: stp             fp, lr, [SP, #-0x10]!
    //     0x82a4f4: mov             fp, SP
    // 0x82a4f8: d2 = 0.000000
    //     0x82a4f8: eor             v2.16b, v2.16b, v2.16b
    // 0x82a4fc: mov             v0.16b, v2.16b
    // 0x82a500: d1 = 3.141593
    //     0x82a500: ldr             d1, [PP, #0x47c0]  ; [pp+0x47c0] IMM: double(3.141592653589793) from 0x400921fb54442d18
    // 0x82a504: stp             fp, lr, [SP, #-0x10]!
    // 0x82a508: mov             fp, SP
    // 0x82a50c: CallRuntime_DartModulo(double, double) -> double
    //     0x82a50c: and             SP, SP, #0xfffffffffffffff0
    //     0x82a510: mov             sp, SP
    //     0x82a514: ldr             x16, [THR, #0x558]  ; THR::DartModulo
    //     0x82a518: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x82a51c: blr             x16
    //     0x82a520: mov             x16, #8
    //     0x82a524: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x82a528: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x82a52c: sub             sp, x16, #1, lsl #12
    //     0x82a530: mov             SP, fp
    //     0x82a534: ldp             fp, lr, [SP], #0x10
    // 0x82a538: mov             v1.16b, v0.16b
    // 0x82a53c: d0 = 0.000000
    //     0x82a53c: eor             v0.16b, v0.16b, v0.16b
    // 0x82a540: fcmp            d1, d0
    // 0x82a544: r16 = true
    //     0x82a544: add             x16, NULL, #0x20  ; true
    // 0x82a548: r17 = false
    //     0x82a548: add             x17, NULL, #0x30  ; false
    // 0x82a54c: csel            x0, x16, x17, ne
    // 0x82a550: LeaveFrame
    //     0x82a550: mov             SP, fp
    //     0x82a554: ldp             fp, lr, [SP], #0x10
    // 0x82a558: ret
    //     0x82a558: ret             
  }
  get _ layerDestinationRect(/* No info */) {
    // ** addr: 0x82a55c, size: 0x80
    // 0x82a55c: EnterFrame
    //     0x82a55c: stp             fp, lr, [SP, #-0x10]!
    //     0x82a560: mov             fp, SP
    // 0x82a564: AllocStack(0x8)
    //     0x82a564: sub             SP, SP, #8
    // 0x82a568: CheckStackOverflow
    //     0x82a568: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a56c: cmp             SP, x16
    //     0x82a570: b.ls            #0x82a5d0
    // 0x82a574: ldr             x0, [fp, #0x10]
    // 0x82a578: LoadField: r1 = r0->field_23
    //     0x82a578: ldur            w1, [x0, #0x23]
    // 0x82a57c: DecompressPointer r1
    //     0x82a57c: add             x1, x1, HEAP, lsl #32
    // 0x82a580: stur            x1, [fp, #-8]
    // 0x82a584: cmp             w1, NULL
    // 0x82a588: b.ne            #0x82a594
    // 0x82a58c: r0 = Null
    //     0x82a58c: mov             x0, NULL
    // 0x82a590: b               #0x82a5c4
    // 0x82a594: SaveReg r0
    //     0x82a594: str             x0, [SP, #-8]!
    // 0x82a598: r0 = layoutTopLeft()
    //     0x82a598: bl              #0x6575dc  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::layoutTopLeft
    // 0x82a59c: add             SP, SP, #8
    // 0x82a5a0: cmp             w0, NULL
    // 0x82a5a4: b.eq            #0x82a5d8
    // 0x82a5a8: SaveReg r0
    //     0x82a5a8: str             x0, [SP, #-8]!
    // 0x82a5ac: r0 = unary-()
    //     0x82a5ac: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x82a5b0: add             SP, SP, #8
    // 0x82a5b4: ldur            x16, [fp, #-8]
    // 0x82a5b8: stp             x0, x16, [SP, #-0x10]!
    // 0x82a5bc: r0 = shift()
    //     0x82a5bc: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x82a5c0: add             SP, SP, #0x10
    // 0x82a5c4: LeaveFrame
    //     0x82a5c4: mov             SP, fp
    //     0x82a5c8: ldp             fp, lr, [SP], #0x10
    // 0x82a5cc: ret
    //     0x82a5cc: ret             
    // 0x82a5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a5d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a5d4: b               #0x82a574
    // 0x82a5d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82a5d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6000, size: 0x14, field offset: 0x14
enum InitCropRectType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb157e0, size: 0x5c
    // 0xb157e0: EnterFrame
    //     0xb157e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb157e4: mov             fp, SP
    // 0xb157e8: CheckStackOverflow
    //     0xb157e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb157ec: cmp             SP, x16
    //     0xb157f0: b.ls            #0xb15834
    // 0xb157f4: r1 = Null
    //     0xb157f4: mov             x1, NULL
    // 0xb157f8: r2 = 4
    //     0xb157f8: mov             x2, #4
    // 0xb157fc: r0 = AllocateArray()
    //     0xb157fc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15800: r17 = "InitCropRectType."
    //     0xb15800: add             x17, PP, #0x51, lsl #12  ; [pp+0x51460] "InitCropRectType."
    //     0xb15804: ldr             x17, [x17, #0x460]
    // 0xb15808: StoreField: r0->field_f = r17
    //     0xb15808: stur            w17, [x0, #0xf]
    // 0xb1580c: ldr             x1, [fp, #0x10]
    // 0xb15810: LoadField: r2 = r1->field_f
    //     0xb15810: ldur            w2, [x1, #0xf]
    // 0xb15814: DecompressPointer r2
    //     0xb15814: add             x2, x2, HEAP, lsl #32
    // 0xb15818: StoreField: r0->field_13 = r2
    //     0xb15818: stur            w2, [x0, #0x13]
    // 0xb1581c: SaveReg r0
    //     0xb1581c: str             x0, [SP, #-8]!
    // 0xb15820: r0 = _interpolate()
    //     0xb15820: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15824: add             SP, SP, #8
    // 0xb15828: LeaveFrame
    //     0xb15828: mov             SP, fp
    //     0xb1582c: ldp             fp, lr, [SP], #0x10
    // 0xb15830: ret
    //     0xb15830: ret             
    // 0xb15834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15834: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15838: b               #0xb157f4
  }
}

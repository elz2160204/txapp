// lib: , url: package:extended_image/src/editor/crop_layer.dart

// class id: 1048928, size: 0x8
class :: {
}

// class id: 3402, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class _ExtendedImageCropLayerState&State&SingleTickerProviderStateMixin extends State<ExtendedImageCropLayer>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x6135e8, size: 0x98
    // 0x6135e8: EnterFrame
    //     0x6135e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6135ec: mov             fp, SP
    // 0x6135f0: CheckStackOverflow
    //     0x6135f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6135f4: cmp             SP, x16
    //     0x6135f8: b.ls            #0x613674
    // 0x6135fc: r0 = Ticker()
    //     0x6135fc: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x613600: mov             x1, x0
    // 0x613604: r0 = false
    //     0x613604: add             x0, NULL, #0x30  ; false
    // 0x613608: StoreField: r1->field_b = r0
    //     0x613608: stur            w0, [x1, #0xb]
    // 0x61360c: ldr             x0, [fp, #0x10]
    // 0x613610: StoreField: r1->field_13 = r0
    //     0x613610: stur            w0, [x1, #0x13]
    // 0x613614: mov             x0, x1
    // 0x613618: ldr             x1, [fp, #0x18]
    // 0x61361c: StoreField: r1->field_13 = r0
    //     0x61361c: stur            w0, [x1, #0x13]
    //     0x613620: ldurb           w16, [x1, #-1]
    //     0x613624: ldurb           w17, [x0, #-1]
    //     0x613628: and             x16, x17, x16, lsr #2
    //     0x61362c: tst             x16, HEAP, lsr #32
    //     0x613630: b.eq            #0x613638
    //     0x613634: bl              #0xd6826c
    // 0x613638: SaveReg r1
    //     0x613638: str             x1, [SP, #-8]!
    // 0x61363c: r0 = _updateTickerModeNotifier()
    //     0x61363c: bl              #0x6136a4  ; [package:extended_image/src/editor/crop_layer.dart] _ExtendedImageCropLayerState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x613640: add             SP, SP, #8
    // 0x613644: ldr             x16, [fp, #0x18]
    // 0x613648: SaveReg r16
    //     0x613648: str             x16, [SP, #-8]!
    // 0x61364c: r0 = _updateTicker()
    //     0x61364c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x613650: add             SP, SP, #8
    // 0x613654: ldr             x1, [fp, #0x18]
    // 0x613658: LoadField: r0 = r1->field_13
    //     0x613658: ldur            w0, [x1, #0x13]
    // 0x61365c: DecompressPointer r0
    //     0x61365c: add             x0, x0, HEAP, lsl #32
    // 0x613660: cmp             w0, NULL
    // 0x613664: b.eq            #0x61367c
    // 0x613668: LeaveFrame
    //     0x613668: mov             SP, fp
    //     0x61366c: ldp             fp, lr, [SP], #0x10
    // 0x613670: ret
    //     0x613670: ret             
    // 0x613674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613678: b               #0x6135fc
    // 0x61367c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61367c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x6136a4, size: 0x11c
    // 0x6136a4: EnterFrame
    //     0x6136a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6136a8: mov             fp, SP
    // 0x6136ac: AllocStack(0x10)
    //     0x6136ac: sub             SP, SP, #0x10
    // 0x6136b0: CheckStackOverflow
    //     0x6136b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6136b4: cmp             SP, x16
    //     0x6136b8: b.ls            #0x6137b4
    // 0x6136bc: ldr             x0, [fp, #0x10]
    // 0x6136c0: LoadField: r1 = r0->field_f
    //     0x6136c0: ldur            w1, [x0, #0xf]
    // 0x6136c4: DecompressPointer r1
    //     0x6136c4: add             x1, x1, HEAP, lsl #32
    // 0x6136c8: cmp             w1, NULL
    // 0x6136cc: b.eq            #0x6137bc
    // 0x6136d0: SaveReg r1
    //     0x6136d0: str             x1, [SP, #-8]!
    // 0x6136d4: r0 = getNotifier()
    //     0x6136d4: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x6136d8: add             SP, SP, #8
    // 0x6136dc: mov             x1, x0
    // 0x6136e0: ldr             x0, [fp, #0x10]
    // 0x6136e4: stur            x1, [fp, #-0x10]
    // 0x6136e8: LoadField: r2 = r0->field_17
    //     0x6136e8: ldur            w2, [x0, #0x17]
    // 0x6136ec: DecompressPointer r2
    //     0x6136ec: add             x2, x2, HEAP, lsl #32
    // 0x6136f0: stur            x2, [fp, #-8]
    // 0x6136f4: cmp             w1, w2
    // 0x6136f8: b.ne            #0x61370c
    // 0x6136fc: r0 = Null
    //     0x6136fc: mov             x0, NULL
    // 0x613700: LeaveFrame
    //     0x613700: mov             SP, fp
    //     0x613704: ldp             fp, lr, [SP], #0x10
    // 0x613708: ret
    //     0x613708: ret             
    // 0x61370c: cmp             w2, NULL
    // 0x613710: b.eq            #0x61374c
    // 0x613714: r1 = 1
    //     0x613714: mov             x1, #1
    // 0x613718: r0 = AllocateContext()
    //     0x613718: bl              #0xd68aa4  ; AllocateContextStub
    // 0x61371c: mov             x1, x0
    // 0x613720: ldr             x0, [fp, #0x10]
    // 0x613724: StoreField: r1->field_f = r0
    //     0x613724: stur            w0, [x1, #0xf]
    // 0x613728: mov             x2, x1
    // 0x61372c: r1 = Function '_updateTicker@156311458':.
    //     0x61372c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53970] AnonymousClosure: (0x6137c0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x613730: ldr             x1, [x1, #0x970]
    // 0x613734: r0 = AllocateClosure()
    //     0x613734: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x613738: ldur            x16, [fp, #-8]
    // 0x61373c: stp             x0, x16, [SP, #-0x10]!
    // 0x613740: r0 = removeListener()
    //     0x613740: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x613744: add             SP, SP, #0x10
    // 0x613748: ldr             x0, [fp, #0x10]
    // 0x61374c: r1 = 1
    //     0x61374c: mov             x1, #1
    // 0x613750: r0 = AllocateContext()
    //     0x613750: bl              #0xd68aa4  ; AllocateContextStub
    // 0x613754: mov             x1, x0
    // 0x613758: ldr             x0, [fp, #0x10]
    // 0x61375c: StoreField: r1->field_f = r0
    //     0x61375c: stur            w0, [x1, #0xf]
    // 0x613760: mov             x2, x1
    // 0x613764: r1 = Function '_updateTicker@156311458':.
    //     0x613764: add             x1, PP, #0x53, lsl #12  ; [pp+0x53970] AnonymousClosure: (0x6137c0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x613768: ldr             x1, [x1, #0x970]
    // 0x61376c: r0 = AllocateClosure()
    //     0x61376c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x613770: ldur            x16, [fp, #-0x10]
    // 0x613774: stp             x0, x16, [SP, #-0x10]!
    // 0x613778: r0 = addListener()
    //     0x613778: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x61377c: add             SP, SP, #0x10
    // 0x613780: ldur            x0, [fp, #-0x10]
    // 0x613784: ldr             x1, [fp, #0x10]
    // 0x613788: StoreField: r1->field_17 = r0
    //     0x613788: stur            w0, [x1, #0x17]
    //     0x61378c: ldurb           w16, [x1, #-1]
    //     0x613790: ldurb           w17, [x0, #-1]
    //     0x613794: and             x16, x17, x16, lsr #2
    //     0x613798: tst             x16, HEAP, lsr #32
    //     0x61379c: b.eq            #0x6137a4
    //     0x6137a0: bl              #0xd6826c
    // 0x6137a4: r0 = Null
    //     0x6137a4: mov             x0, NULL
    // 0x6137a8: LeaveFrame
    //     0x6137a8: mov             SP, fp
    //     0x6137ac: ldp             fp, lr, [SP], #0x10
    // 0x6137b0: ret
    //     0x6137b0: ret             
    // 0x6137b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6137b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6137b8: b               #0x6136bc
    // 0x6137bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6137bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x6137c0, size: 0x48
    // 0x6137c0: EnterFrame
    //     0x6137c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6137c4: mov             fp, SP
    // 0x6137c8: ldr             x0, [fp, #0x10]
    // 0x6137cc: LoadField: r1 = r0->field_17
    //     0x6137cc: ldur            w1, [x0, #0x17]
    // 0x6137d0: DecompressPointer r1
    //     0x6137d0: add             x1, x1, HEAP, lsl #32
    // 0x6137d4: CheckStackOverflow
    //     0x6137d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6137d8: cmp             SP, x16
    //     0x6137dc: b.ls            #0x613800
    // 0x6137e0: LoadField: r0 = r1->field_f
    //     0x6137e0: ldur            w0, [x1, #0xf]
    // 0x6137e4: DecompressPointer r0
    //     0x6137e4: add             x0, x0, HEAP, lsl #32
    // 0x6137e8: SaveReg r0
    //     0x6137e8: str             x0, [SP, #-8]!
    // 0x6137ec: r0 = _updateTicker()
    //     0x6137ec: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x6137f0: add             SP, SP, #8
    // 0x6137f4: LeaveFrame
    //     0x6137f4: mov             SP, fp
    //     0x6137f8: ldp             fp, lr, [SP], #0x10
    // 0x6137fc: ret
    //     0x6137fc: ret             
    // 0x613800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613800: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613804: b               #0x6137e0
  }
  _ activate(/* No info */) {
    // ** addr: 0x81eeb8, size: 0x4c
    // 0x81eeb8: EnterFrame
    //     0x81eeb8: stp             fp, lr, [SP, #-0x10]!
    //     0x81eebc: mov             fp, SP
    // 0x81eec0: CheckStackOverflow
    //     0x81eec0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81eec4: cmp             SP, x16
    //     0x81eec8: b.ls            #0x81eefc
    // 0x81eecc: ldr             x16, [fp, #0x10]
    // 0x81eed0: SaveReg r16
    //     0x81eed0: str             x16, [SP, #-8]!
    // 0x81eed4: r0 = _updateTickerModeNotifier()
    //     0x81eed4: bl              #0x6136a4  ; [package:extended_image/src/editor/crop_layer.dart] _ExtendedImageCropLayerState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81eed8: add             SP, SP, #8
    // 0x81eedc: ldr             x16, [fp, #0x10]
    // 0x81eee0: SaveReg r16
    //     0x81eee0: str             x16, [SP, #-8]!
    // 0x81eee4: r0 = _updateTicker()
    //     0x81eee4: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81eee8: add             SP, SP, #8
    // 0x81eeec: r0 = Null
    //     0x81eeec: mov             x0, NULL
    // 0x81eef0: LeaveFrame
    //     0x81eef0: mov             SP, fp
    //     0x81eef4: ldp             fp, lr, [SP], #0x10
    // 0x81eef8: ret
    //     0x81eef8: ret             
    // 0x81eefc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81eefc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81ef00: b               #0x81eecc
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4eacc, size: 0x8c
    // 0xa4eacc: EnterFrame
    //     0xa4eacc: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ead0: mov             fp, SP
    // 0xa4ead4: AllocStack(0x8)
    //     0xa4ead4: sub             SP, SP, #8
    // 0xa4ead8: CheckStackOverflow
    //     0xa4ead8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4eadc: cmp             SP, x16
    //     0xa4eae0: b.ls            #0xa4eb50
    // 0xa4eae4: ldr             x0, [fp, #0x10]
    // 0xa4eae8: LoadField: r1 = r0->field_17
    //     0xa4eae8: ldur            w1, [x0, #0x17]
    // 0xa4eaec: DecompressPointer r1
    //     0xa4eaec: add             x1, x1, HEAP, lsl #32
    // 0xa4eaf0: stur            x1, [fp, #-8]
    // 0xa4eaf4: cmp             w1, NULL
    // 0xa4eaf8: b.ne            #0xa4eb04
    // 0xa4eafc: mov             x1, x0
    // 0xa4eb00: b               #0xa4eb3c
    // 0xa4eb04: r1 = 1
    //     0xa4eb04: mov             x1, #1
    // 0xa4eb08: r0 = AllocateContext()
    //     0xa4eb08: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4eb0c: mov             x1, x0
    // 0xa4eb10: ldr             x0, [fp, #0x10]
    // 0xa4eb14: StoreField: r1->field_f = r0
    //     0xa4eb14: stur            w0, [x1, #0xf]
    // 0xa4eb18: mov             x2, x1
    // 0xa4eb1c: r1 = Function '_updateTicker@156311458':.
    //     0xa4eb1c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53970] AnonymousClosure: (0x6137c0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa4eb20: ldr             x1, [x1, #0x970]
    // 0xa4eb24: r0 = AllocateClosure()
    //     0xa4eb24: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4eb28: ldur            x16, [fp, #-8]
    // 0xa4eb2c: stp             x0, x16, [SP, #-0x10]!
    // 0xa4eb30: r0 = removeListener()
    //     0xa4eb30: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4eb34: add             SP, SP, #0x10
    // 0xa4eb38: ldr             x1, [fp, #0x10]
    // 0xa4eb3c: StoreField: r1->field_17 = rNULL
    //     0xa4eb3c: stur            NULL, [x1, #0x17]
    // 0xa4eb40: r0 = Null
    //     0xa4eb40: mov             x0, NULL
    // 0xa4eb44: LeaveFrame
    //     0xa4eb44: mov             SP, fp
    //     0xa4eb48: ldp             fp, lr, [SP], #0x10
    // 0xa4eb4c: ret
    //     0xa4eb4c: ret             
    // 0xa4eb50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4eb50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4eb54: b               #0xa4eae4
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4eb58, size: 0x48
    // 0xa4eb58: EnterFrame
    //     0xa4eb58: stp             fp, lr, [SP, #-0x10]!
    //     0xa4eb5c: mov             fp, SP
    // 0xa4eb60: ldr             x0, [fp, #0x10]
    // 0xa4eb64: LoadField: r1 = r0->field_17
    //     0xa4eb64: ldur            w1, [x0, #0x17]
    // 0xa4eb68: DecompressPointer r1
    //     0xa4eb68: add             x1, x1, HEAP, lsl #32
    // 0xa4eb6c: CheckStackOverflow
    //     0xa4eb6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4eb70: cmp             SP, x16
    //     0xa4eb74: b.ls            #0xa4eb98
    // 0xa4eb78: LoadField: r0 = r1->field_f
    //     0xa4eb78: ldur            w0, [x1, #0xf]
    // 0xa4eb7c: DecompressPointer r0
    //     0xa4eb7c: add             x0, x0, HEAP, lsl #32
    // 0xa4eb80: SaveReg r0
    //     0xa4eb80: str             x0, [SP, #-8]!
    // 0xa4eb84: r0 = dispose()
    //     0xa4eb84: bl              #0xa4eacc  ; [package:extended_image/src/editor/crop_layer.dart] _ExtendedImageCropLayerState&State&SingleTickerProviderStateMixin::dispose
    // 0xa4eb88: add             SP, SP, #8
    // 0xa4eb8c: LeaveFrame
    //     0xa4eb8c: mov             SP, fp
    //     0xa4eb90: ldp             fp, lr, [SP], #0x10
    // 0xa4eb94: ret
    //     0xa4eb94: ret             
    // 0xa4eb98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4eb98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4eb9c: b               #0xa4eb78
  }
}

// class id: 3403, size: 0x30, field offset: 0x1c
class ExtendedImageCropLayerState extends _ExtendedImageCropLayerState&State&SingleTickerProviderStateMixin {

  late AnimationController _rectTweenController; // offset: 0x28

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x79afe4, size: 0xa8
    // 0x79afe4: EnterFrame
    //     0x79afe4: stp             fp, lr, [SP, #-0x10]!
    //     0x79afe8: mov             fp, SP
    // 0x79afec: ldr             x0, [fp, #0x10]
    // 0x79aff0: r2 = Null
    //     0x79aff0: mov             x2, NULL
    // 0x79aff4: r1 = Null
    //     0x79aff4: mov             x1, NULL
    // 0x79aff8: r4 = 59
    //     0x79aff8: mov             x4, #0x3b
    // 0x79affc: branchIfSmi(r0, 0x79b008)
    //     0x79affc: tbz             w0, #0, #0x79b008
    // 0x79b000: r4 = LoadClassIdInstr(r0)
    //     0x79b000: ldur            x4, [x0, #-1]
    //     0x79b004: ubfx            x4, x4, #0xc, #0x14
    // 0x79b008: r17 = 4216
    //     0x79b008: mov             x17, #0x1078
    // 0x79b00c: cmp             x4, x17
    // 0x79b010: b.eq            #0x79b028
    // 0x79b014: r8 = ExtendedImageCropLayer
    //     0x79b014: add             x8, PP, #0x53, lsl #12  ; [pp+0x53938] Type: ExtendedImageCropLayer
    //     0x79b018: ldr             x8, [x8, #0x938]
    // 0x79b01c: r3 = Null
    //     0x79b01c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53940] Null
    //     0x79b020: ldr             x3, [x3, #0x940]
    // 0x79b024: r0 = ExtendedImageCropLayer()
    //     0x79b024: bl              #0x613680  ; IsType_ExtendedImageCropLayer_Stub
    // 0x79b028: ldr             x3, [fp, #0x18]
    // 0x79b02c: LoadField: r2 = r3->field_7
    //     0x79b02c: ldur            w2, [x3, #7]
    // 0x79b030: DecompressPointer r2
    //     0x79b030: add             x2, x2, HEAP, lsl #32
    // 0x79b034: ldr             x0, [fp, #0x10]
    // 0x79b038: r1 = Null
    //     0x79b038: mov             x1, NULL
    // 0x79b03c: cmp             w2, NULL
    // 0x79b040: b.eq            #0x79b064
    // 0x79b044: LoadField: r4 = r2->field_17
    //     0x79b044: ldur            w4, [x2, #0x17]
    // 0x79b048: DecompressPointer r4
    //     0x79b048: add             x4, x4, HEAP, lsl #32
    // 0x79b04c: r8 = X0 bound StatefulWidget
    //     0x79b04c: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x79b050: ldr             x8, [x8, #0x858]
    // 0x79b054: LoadField: r9 = r4->field_7
    //     0x79b054: ldur            x9, [x4, #7]
    // 0x79b058: r3 = Null
    //     0x79b058: add             x3, PP, #0x53, lsl #12  ; [pp+0x53950] Null
    //     0x79b05c: ldr             x3, [x3, #0x950]
    // 0x79b060: blr             x9
    // 0x79b064: ldr             x1, [fp, #0x18]
    // 0x79b068: LoadField: r2 = r1->field_b
    //     0x79b068: ldur            w2, [x1, #0xb]
    // 0x79b06c: DecompressPointer r2
    //     0x79b06c: add             x2, x2, HEAP, lsl #32
    // 0x79b070: cmp             w2, NULL
    // 0x79b074: b.eq            #0x79b088
    // 0x79b078: r0 = Null
    //     0x79b078: mov             x0, NULL
    // 0x79b07c: LeaveFrame
    //     0x79b07c: mov             SP, fp
    //     0x79b080: ldp             fp, lr, [SP], #0x10
    // 0x79b084: ret
    //     0x79b084: ret             
    // 0x79b088: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b088: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ layoutRect(/* No info */) {
    // ** addr: 0x7a09bc, size: 0x34
    // 0x7a09bc: EnterFrame
    //     0x7a09bc: stp             fp, lr, [SP, #-0x10]!
    //     0x7a09c0: mov             fp, SP
    // 0x7a09c4: ldr             x1, [fp, #0x10]
    // 0x7a09c8: LoadField: r2 = r1->field_b
    //     0x7a09c8: ldur            w2, [x1, #0xb]
    // 0x7a09cc: DecompressPointer r2
    //     0x7a09cc: add             x2, x2, HEAP, lsl #32
    // 0x7a09d0: cmp             w2, NULL
    // 0x7a09d4: b.eq            #0x7a09ec
    // 0x7a09d8: LoadField: r0 = r2->field_13
    //     0x7a09d8: ldur            w0, [x2, #0x13]
    // 0x7a09dc: DecompressPointer r0
    //     0x7a09dc: add             x0, x0, HEAP, lsl #32
    // 0x7a09e0: LeaveFrame
    //     0x7a09e0: mov             SP, fp
    //     0x7a09e4: ldp             fp, lr, [SP], #0x10
    // 0x7a09e8: ret
    //     0x7a09e8: ret             
    // 0x7a09ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a09ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x826728, size: 0x1178
    // 0x826728: EnterFrame
    //     0x826728: stp             fp, lr, [SP, #-0x10]!
    //     0x82672c: mov             fp, SP
    // 0x826730: AllocStack(0x70)
    //     0x826730: sub             SP, SP, #0x70
    // 0x826734: CheckStackOverflow
    //     0x826734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x826738: cmp             SP, x16
    //     0x82673c: b.ls            #0x827694
    // 0x826740: r1 = 1
    //     0x826740: mov             x1, #1
    // 0x826744: r0 = AllocateContext()
    //     0x826744: bl              #0xd68aa4  ; AllocateContextStub
    // 0x826748: mov             x1, x0
    // 0x82674c: ldr             x0, [fp, #0x18]
    // 0x826750: stur            x1, [fp, #-0x10]
    // 0x826754: StoreField: r1->field_f = r0
    //     0x826754: stur            w0, [x1, #0xf]
    // 0x826758: LoadField: r2 = r0->field_b
    //     0x826758: ldur            w2, [x0, #0xb]
    // 0x82675c: DecompressPointer r2
    //     0x82675c: add             x2, x2, HEAP, lsl #32
    // 0x826760: cmp             w2, NULL
    // 0x826764: b.eq            #0x82769c
    // 0x826768: LoadField: r3 = r2->field_b
    //     0x826768: ldur            w3, [x2, #0xb]
    // 0x82676c: DecompressPointer r3
    //     0x82676c: add             x3, x3, HEAP, lsl #32
    // 0x826770: LoadField: r2 = r3->field_4b
    //     0x826770: ldur            w2, [x3, #0x4b]
    // 0x826774: DecompressPointer r2
    //     0x826774: add             x2, x2, HEAP, lsl #32
    // 0x826778: cmp             w2, NULL
    // 0x82677c: b.ne            #0x8267a8
    // 0x826780: r0 = Container()
    //     0x826780: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x826784: stur            x0, [fp, #-8]
    // 0x826788: SaveReg r0
    //     0x826788: str             x0, [SP, #-8]!
    // 0x82678c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x82678c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x826790: r0 = Container()
    //     0x826790: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x826794: add             SP, SP, #8
    // 0x826798: ldur            x0, [fp, #-8]
    // 0x82679c: LeaveFrame
    //     0x82679c: mov             SP, fp
    //     0x8267a0: ldp             fp, lr, [SP], #0x10
    // 0x8267a4: ret
    //     0x8267a4: ret             
    // 0x8267a8: ldr             x16, [fp, #0x10]
    // 0x8267ac: SaveReg r16
    //     0x8267ac: str             x16, [SP, #-8]!
    // 0x8267b0: r0 = of()
    //     0x8267b0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8267b4: add             SP, SP, #8
    // 0x8267b8: LoadField: r1 = r0->field_63
    //     0x8267b8: ldur            w1, [x0, #0x63]
    // 0x8267bc: DecompressPointer r1
    //     0x8267bc: add             x1, x1, HEAP, lsl #32
    // 0x8267c0: ldr             x0, [fp, #0x18]
    // 0x8267c4: stur            x1, [fp, #-8]
    // 0x8267c8: LoadField: r2 = r0->field_b
    //     0x8267c8: ldur            w2, [x0, #0xb]
    // 0x8267cc: DecompressPointer r2
    //     0x8267cc: add             x2, x2, HEAP, lsl #32
    // 0x8267d0: cmp             w2, NULL
    // 0x8267d4: b.eq            #0x8276a0
    // 0x8267d8: LoadField: r2 = r0->field_1f
    //     0x8267d8: ldur            w2, [x0, #0x1f]
    // 0x8267dc: DecompressPointer r2
    //     0x8267dc: add             x2, x2, HEAP, lsl #32
    // 0x8267e0: ldr             x16, [fp, #0x10]
    // 0x8267e4: stp             x2, x16, [SP, #-0x10]!
    // 0x8267e8: r0 = defaultEditorMaskColorHandler()
    //     0x8267e8: bl              #0x8278f4  ; [package:extended_image/src/editor/editor_utils.dart] ::defaultEditorMaskColorHandler
    // 0x8267ec: add             SP, SP, #0x10
    // 0x8267f0: mov             x1, x0
    // 0x8267f4: ldr             x0, [fp, #0x18]
    // 0x8267f8: stur            x1, [fp, #-0x20]
    // 0x8267fc: LoadField: r2 = r0->field_b
    //     0x8267fc: ldur            w2, [x0, #0xb]
    // 0x826800: DecompressPointer r2
    //     0x826800: add             x2, x2, HEAP, lsl #32
    // 0x826804: cmp             w2, NULL
    // 0x826808: b.eq            #0x8276a4
    // 0x82680c: LoadField: r3 = r2->field_b
    //     0x82680c: ldur            w3, [x2, #0xb]
    // 0x826810: DecompressPointer r3
    //     0x826810: add             x3, x3, HEAP, lsl #32
    // 0x826814: LoadField: r2 = r3->field_4b
    //     0x826814: ldur            w2, [x3, #0x4b]
    // 0x826818: DecompressPointer r2
    //     0x826818: add             x2, x2, HEAP, lsl #32
    // 0x82681c: stur            x2, [fp, #-0x18]
    // 0x826820: cmp             w2, NULL
    // 0x826824: b.eq            #0x8276a8
    // 0x826828: ldr             x16, [fp, #0x10]
    // 0x82682c: SaveReg r16
    //     0x82682c: str             x16, [SP, #-8]!
    // 0x826830: r0 = of()
    //     0x826830: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x826834: add             SP, SP, #8
    // 0x826838: LoadField: r1 = r0->field_6f
    //     0x826838: ldur            w1, [x0, #0x6f]
    // 0x82683c: DecompressPointer r1
    //     0x82683c: add             x1, x1, HEAP, lsl #32
    // 0x826840: SaveReg r1
    //     0x826840: str             x1, [SP, #-8]!
    // 0x826844: d0 = 0.700000
    //     0x826844: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1c2f0] IMM: double(0.7) from 0x3fe6666666666666
    //     0x826848: ldr             d0, [x17, #0x2f0]
    // 0x82684c: SaveReg d0
    //     0x82684c: str             d0, [SP, #-8]!
    // 0x826850: r0 = withOpacity()
    //     0x826850: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x826854: add             SP, SP, #0x10
    // 0x826858: mov             x1, x0
    // 0x82685c: ldr             x0, [fp, #0x18]
    // 0x826860: stur            x1, [fp, #-0x30]
    // 0x826864: LoadField: r2 = r0->field_1f
    //     0x826864: ldur            w2, [x0, #0x1f]
    // 0x826868: DecompressPointer r2
    //     0x826868: add             x2, x2, HEAP, lsl #32
    // 0x82686c: stur            x2, [fp, #-0x28]
    // 0x826870: r0 = ExtendedImageCropLayerPainter()
    //     0x826870: bl              #0x8278e8  ; AllocateExtendedImageCropLayerPainterStub -> ExtendedImageCropLayerPainter (size=0x30)
    // 0x826874: mov             x1, x0
    // 0x826878: ldur            x0, [fp, #-0x18]
    // 0x82687c: stur            x1, [fp, #-0x38]
    // 0x826880: StoreField: r1->field_b = r0
    //     0x826880: stur            w0, [x1, #0xb]
    // 0x826884: r0 = Instance_EditorCropLayerPainter
    //     0x826884: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c798] Obj!EditorCropLayerPainter@b4fdd1
    //     0x826888: ldr             x0, [x0, #0x798]
    // 0x82688c: StoreField: r1->field_2b = r0
    //     0x82688c: stur            w0, [x1, #0x2b]
    // 0x826890: ldur            x0, [fp, #-0x30]
    // 0x826894: StoreField: r1->field_17 = r0
    //     0x826894: stur            w0, [x1, #0x17]
    // 0x826898: ldur            x0, [fp, #-8]
    // 0x82689c: StoreField: r1->field_13 = r0
    //     0x82689c: stur            w0, [x1, #0x13]
    // 0x8268a0: r0 = Instance_Size
    //     0x8268a0: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c788] Obj!Size@b5ec91
    //     0x8268a4: ldr             x0, [x0, #0x788]
    // 0x8268a8: StoreField: r1->field_f = r0
    //     0x8268a8: stur            w0, [x1, #0xf]
    // 0x8268ac: d0 = 0.600000
    //     0x8268ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf90] IMM: double(0.6) from 0x3fe3333333333333
    //     0x8268b0: ldr             d0, [x17, #0xf90]
    // 0x8268b4: StoreField: r1->field_1b = d0
    //     0x8268b4: stur            d0, [x1, #0x1b]
    // 0x8268b8: ldur            x0, [fp, #-0x20]
    // 0x8268bc: StoreField: r1->field_23 = r0
    //     0x8268bc: stur            w0, [x1, #0x23]
    // 0x8268c0: ldur            x0, [fp, #-0x28]
    // 0x8268c4: StoreField: r1->field_27 = r0
    //     0x8268c4: stur            w0, [x1, #0x27]
    // 0x8268c8: ldr             x16, [fp, #0x18]
    // 0x8268cc: SaveReg r16
    //     0x8268cc: str             x16, [SP, #-8]!
    // 0x8268d0: r0 = cropRect()
    //     0x8268d0: bl              #0x8278ac  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::cropRect
    // 0x8268d4: add             SP, SP, #8
    // 0x8268d8: cmp             w0, NULL
    // 0x8268dc: b.eq            #0x8276ac
    // 0x8268e0: LoadField: d0 = r0->field_f
    //     0x8268e0: ldur            d0, [x0, #0xf]
    // 0x8268e4: d1 = 20.000000
    //     0x8268e4: fmov            d1, #20.00000000
    // 0x8268e8: fsub            d2, d0, d1
    // 0x8268ec: ldr             x0, [fp, #0x18]
    // 0x8268f0: stur            d2, [fp, #-0x68]
    // 0x8268f4: LoadField: r1 = r0->field_b
    //     0x8268f4: ldur            w1, [x0, #0xb]
    // 0x8268f8: DecompressPointer r1
    //     0x8268f8: add             x1, x1, HEAP, lsl #32
    // 0x8268fc: cmp             w1, NULL
    // 0x826900: b.eq            #0x8276b0
    // 0x826904: LoadField: r2 = r1->field_b
    //     0x826904: ldur            w2, [x1, #0xb]
    // 0x826908: DecompressPointer r2
    //     0x826908: add             x2, x2, HEAP, lsl #32
    // 0x82690c: LoadField: r1 = r2->field_4b
    //     0x82690c: ldur            w1, [x2, #0x4b]
    // 0x826910: DecompressPointer r1
    //     0x826910: add             x1, x1, HEAP, lsl #32
    // 0x826914: cmp             w1, NULL
    // 0x826918: b.eq            #0x8276b4
    // 0x82691c: LoadField: d0 = r1->field_7
    //     0x82691c: ldur            d0, [x1, #7]
    // 0x826920: fsub            d3, d0, d1
    // 0x826924: stur            d3, [fp, #-0x60]
    // 0x826928: r0 = GestureDetector()
    //     0x826928: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x82692c: ldur            x2, [fp, #-0x10]
    // 0x826930: r1 = Function '<anonymous closure>':.
    //     0x826930: add             x1, PP, #0x53, lsl #12  ; [pp+0x53800] AnonymousClosure: (0x82aaec), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x826934: ldr             x1, [x1, #0x800]
    // 0x826938: stur            x0, [fp, #-8]
    // 0x82693c: r0 = AllocateClosure()
    //     0x82693c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x826940: ldur            x2, [fp, #-0x10]
    // 0x826944: r1 = Function '<anonymous closure>':.
    //     0x826944: add             x1, PP, #0x53, lsl #12  ; [pp+0x53808] AnonymousClosure: (0x82aa98), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x826948: ldr             x1, [x1, #0x808]
    // 0x82694c: stur            x0, [fp, #-0x18]
    // 0x826950: r0 = AllocateClosure()
    //     0x826950: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x826954: ldur            x16, [fp, #-8]
    // 0x826958: r30 = Instance_HitTestBehavior
    //     0x826958: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x82695c: ldr             lr, [lr, #0xed0]
    // 0x826960: stp             lr, x16, [SP, #-0x10]!
    // 0x826964: ldur            x16, [fp, #-0x18]
    // 0x826968: stp             x0, x16, [SP, #-0x10]!
    // 0x82696c: r4 = const [0, 0x4, 0x4, 0x1, behavior, 0x1, onPanEnd, 0x3, onPanUpdate, 0x2, null]
    //     0x82696c: add             x4, PP, #0x53, lsl #12  ; [pp+0x53810] List(11) [0, 0x4, 0x4, 0x1, "behavior", 0x1, "onPanEnd", 0x3, "onPanUpdate", 0x2, Null]
    //     0x826970: ldr             x4, [x4, #0x810]
    // 0x826974: r0 = GestureDetector()
    //     0x826974: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x826978: add             SP, SP, #0x20
    // 0x82697c: r0 = Container()
    //     0x82697c: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x826980: stur            x0, [fp, #-0x18]
    // 0x826984: r16 = 40.000000
    //     0x826984: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x826988: ldr             x16, [x16, #0x5b0]
    // 0x82698c: stp             x16, x0, [SP, #-0x10]!
    // 0x826990: r16 = 40.000000
    //     0x826990: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x826994: ldr             x16, [x16, #0x5b0]
    // 0x826998: ldur            lr, [fp, #-8]
    // 0x82699c: stp             lr, x16, [SP, #-0x10]!
    // 0x8269a0: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, height, 0x1, width, 0x2, null]
    //     0x8269a0: add             x4, PP, #0x53, lsl #12  ; [pp+0x53818] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x8269a4: ldr             x4, [x4, #0x818]
    // 0x8269a8: r0 = Container()
    //     0x8269a8: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8269ac: add             SP, SP, #0x20
    // 0x8269b0: ldur            d0, [fp, #-0x60]
    // 0x8269b4: r0 = inline_Allocate_Double()
    //     0x8269b4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8269b8: add             x0, x0, #0x10
    //     0x8269bc: cmp             x1, x0
    //     0x8269c0: b.ls            #0x8276b8
    //     0x8269c4: str             x0, [THR, #0x60]  ; THR::top
    //     0x8269c8: sub             x0, x0, #0xf
    //     0x8269cc: mov             x1, #0xd108
    //     0x8269d0: movk            x1, #3, lsl #16
    //     0x8269d4: stur            x1, [x0, #-1]
    // 0x8269d8: StoreField: r0->field_7 = d0
    //     0x8269d8: stur            d0, [x0, #7]
    // 0x8269dc: stur            x0, [fp, #-8]
    // 0x8269e0: r1 = <StackParentData<RenderBox>>
    //     0x8269e0: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x8269e4: ldr             x1, [x1, #0x5a8]
    // 0x8269e8: r0 = Positioned()
    //     0x8269e8: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8269ec: mov             x1, x0
    // 0x8269f0: ldur            x0, [fp, #-8]
    // 0x8269f4: stur            x1, [fp, #-0x20]
    // 0x8269f8: StoreField: r1->field_13 = r0
    //     0x8269f8: stur            w0, [x1, #0x13]
    // 0x8269fc: ldur            d0, [fp, #-0x68]
    // 0x826a00: r0 = inline_Allocate_Double()
    //     0x826a00: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x826a04: add             x0, x0, #0x10
    //     0x826a08: cmp             x2, x0
    //     0x826a0c: b.ls            #0x8276c8
    //     0x826a10: str             x0, [THR, #0x60]  ; THR::top
    //     0x826a14: sub             x0, x0, #0xf
    //     0x826a18: mov             x2, #0xd108
    //     0x826a1c: movk            x2, #3, lsl #16
    //     0x826a20: stur            x2, [x0, #-1]
    // 0x826a24: StoreField: r0->field_7 = d0
    //     0x826a24: stur            d0, [x0, #7]
    // 0x826a28: StoreField: r1->field_17 = r0
    //     0x826a28: stur            w0, [x1, #0x17]
    // 0x826a2c: ldur            x0, [fp, #-0x18]
    // 0x826a30: StoreField: r1->field_b = r0
    //     0x826a30: stur            w0, [x1, #0xb]
    // 0x826a34: ldr             x0, [fp, #0x18]
    // 0x826a38: LoadField: r2 = r0->field_b
    //     0x826a38: ldur            w2, [x0, #0xb]
    // 0x826a3c: DecompressPointer r2
    //     0x826a3c: add             x2, x2, HEAP, lsl #32
    // 0x826a40: cmp             w2, NULL
    // 0x826a44: b.eq            #0x8276e0
    // 0x826a48: LoadField: r3 = r2->field_b
    //     0x826a48: ldur            w3, [x2, #0xb]
    // 0x826a4c: DecompressPointer r3
    //     0x826a4c: add             x3, x3, HEAP, lsl #32
    // 0x826a50: LoadField: r2 = r3->field_4b
    //     0x826a50: ldur            w2, [x3, #0x4b]
    // 0x826a54: DecompressPointer r2
    //     0x826a54: add             x2, x2, HEAP, lsl #32
    // 0x826a58: cmp             w2, NULL
    // 0x826a5c: b.eq            #0x8276e4
    // 0x826a60: LoadField: d0 = r2->field_f
    //     0x826a60: ldur            d0, [x2, #0xf]
    // 0x826a64: d1 = 20.000000
    //     0x826a64: fmov            d1, #20.00000000
    // 0x826a68: fsub            d2, d0, d1
    // 0x826a6c: stur            d2, [fp, #-0x68]
    // 0x826a70: LoadField: d0 = r2->field_17
    //     0x826a70: ldur            d0, [x2, #0x17]
    // 0x826a74: fsub            d3, d0, d1
    // 0x826a78: stur            d3, [fp, #-0x60]
    // 0x826a7c: r0 = GestureDetector()
    //     0x826a7c: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x826a80: ldur            x2, [fp, #-0x10]
    // 0x826a84: r1 = Function '<anonymous closure>':.
    //     0x826a84: add             x1, PP, #0x53, lsl #12  ; [pp+0x53820] AnonymousClosure: (0x82aa34), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x826a88: ldr             x1, [x1, #0x820]
    // 0x826a8c: stur            x0, [fp, #-8]
    // 0x826a90: r0 = AllocateClosure()
    //     0x826a90: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x826a94: ldur            x2, [fp, #-0x10]
    // 0x826a98: r1 = Function '<anonymous closure>':.
    //     0x826a98: add             x1, PP, #0x53, lsl #12  ; [pp+0x53828] AnonymousClosure: (0x82a9e0), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x826a9c: ldr             x1, [x1, #0x828]
    // 0x826aa0: stur            x0, [fp, #-0x18]
    // 0x826aa4: r0 = AllocateClosure()
    //     0x826aa4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x826aa8: ldur            x16, [fp, #-8]
    // 0x826aac: r30 = Instance_HitTestBehavior
    //     0x826aac: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x826ab0: ldr             lr, [lr, #0xed0]
    // 0x826ab4: stp             lr, x16, [SP, #-0x10]!
    // 0x826ab8: ldur            x16, [fp, #-0x18]
    // 0x826abc: stp             x0, x16, [SP, #-0x10]!
    // 0x826ac0: r4 = const [0, 0x4, 0x4, 0x1, behavior, 0x1, onPanEnd, 0x3, onPanUpdate, 0x2, null]
    //     0x826ac0: add             x4, PP, #0x53, lsl #12  ; [pp+0x53810] List(11) [0, 0x4, 0x4, 0x1, "behavior", 0x1, "onPanEnd", 0x3, "onPanUpdate", 0x2, Null]
    //     0x826ac4: ldr             x4, [x4, #0x810]
    // 0x826ac8: r0 = GestureDetector()
    //     0x826ac8: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x826acc: add             SP, SP, #0x20
    // 0x826ad0: r0 = Container()
    //     0x826ad0: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x826ad4: stur            x0, [fp, #-0x18]
    // 0x826ad8: r16 = 40.000000
    //     0x826ad8: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x826adc: ldr             x16, [x16, #0x5b0]
    // 0x826ae0: stp             x16, x0, [SP, #-0x10]!
    // 0x826ae4: r16 = 40.000000
    //     0x826ae4: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x826ae8: ldr             x16, [x16, #0x5b0]
    // 0x826aec: ldur            lr, [fp, #-8]
    // 0x826af0: stp             lr, x16, [SP, #-0x10]!
    // 0x826af4: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, height, 0x1, width, 0x2, null]
    //     0x826af4: add             x4, PP, #0x53, lsl #12  ; [pp+0x53818] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x826af8: ldr             x4, [x4, #0x818]
    // 0x826afc: r0 = Container()
    //     0x826afc: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x826b00: add             SP, SP, #0x20
    // 0x826b04: ldur            d0, [fp, #-0x60]
    // 0x826b08: r0 = inline_Allocate_Double()
    //     0x826b08: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x826b0c: add             x0, x0, #0x10
    //     0x826b10: cmp             x1, x0
    //     0x826b14: b.ls            #0x8276e8
    //     0x826b18: str             x0, [THR, #0x60]  ; THR::top
    //     0x826b1c: sub             x0, x0, #0xf
    //     0x826b20: mov             x1, #0xd108
    //     0x826b24: movk            x1, #3, lsl #16
    //     0x826b28: stur            x1, [x0, #-1]
    // 0x826b2c: StoreField: r0->field_7 = d0
    //     0x826b2c: stur            d0, [x0, #7]
    // 0x826b30: stur            x0, [fp, #-8]
    // 0x826b34: r1 = <StackParentData<RenderBox>>
    //     0x826b34: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x826b38: ldr             x1, [x1, #0x5a8]
    // 0x826b3c: r0 = Positioned()
    //     0x826b3c: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x826b40: mov             x1, x0
    // 0x826b44: ldur            x0, [fp, #-8]
    // 0x826b48: stur            x1, [fp, #-0x28]
    // 0x826b4c: StoreField: r1->field_13 = r0
    //     0x826b4c: stur            w0, [x1, #0x13]
    // 0x826b50: ldur            d0, [fp, #-0x68]
    // 0x826b54: r0 = inline_Allocate_Double()
    //     0x826b54: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x826b58: add             x0, x0, #0x10
    //     0x826b5c: cmp             x2, x0
    //     0x826b60: b.ls            #0x8276f8
    //     0x826b64: str             x0, [THR, #0x60]  ; THR::top
    //     0x826b68: sub             x0, x0, #0xf
    //     0x826b6c: mov             x2, #0xd108
    //     0x826b70: movk            x2, #3, lsl #16
    //     0x826b74: stur            x2, [x0, #-1]
    // 0x826b78: StoreField: r0->field_7 = d0
    //     0x826b78: stur            d0, [x0, #7]
    // 0x826b7c: StoreField: r1->field_17 = r0
    //     0x826b7c: stur            w0, [x1, #0x17]
    // 0x826b80: ldur            x0, [fp, #-0x18]
    // 0x826b84: StoreField: r1->field_b = r0
    //     0x826b84: stur            w0, [x1, #0xb]
    // 0x826b88: ldr             x0, [fp, #0x18]
    // 0x826b8c: LoadField: r2 = r0->field_b
    //     0x826b8c: ldur            w2, [x0, #0xb]
    // 0x826b90: DecompressPointer r2
    //     0x826b90: add             x2, x2, HEAP, lsl #32
    // 0x826b94: cmp             w2, NULL
    // 0x826b98: b.eq            #0x827710
    // 0x826b9c: LoadField: r3 = r2->field_b
    //     0x826b9c: ldur            w3, [x2, #0xb]
    // 0x826ba0: DecompressPointer r3
    //     0x826ba0: add             x3, x3, HEAP, lsl #32
    // 0x826ba4: LoadField: r2 = r3->field_4b
    //     0x826ba4: ldur            w2, [x3, #0x4b]
    // 0x826ba8: DecompressPointer r2
    //     0x826ba8: add             x2, x2, HEAP, lsl #32
    // 0x826bac: cmp             w2, NULL
    // 0x826bb0: b.eq            #0x827714
    // 0x826bb4: LoadField: d0 = r2->field_1f
    //     0x826bb4: ldur            d0, [x2, #0x1f]
    // 0x826bb8: d1 = 20.000000
    //     0x826bb8: fmov            d1, #20.00000000
    // 0x826bbc: fsub            d2, d0, d1
    // 0x826bc0: stur            d2, [fp, #-0x68]
    // 0x826bc4: LoadField: d0 = r2->field_7
    //     0x826bc4: ldur            d0, [x2, #7]
    // 0x826bc8: fsub            d3, d0, d1
    // 0x826bcc: stur            d3, [fp, #-0x60]
    // 0x826bd0: r0 = GestureDetector()
    //     0x826bd0: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x826bd4: ldur            x2, [fp, #-0x10]
    // 0x826bd8: r1 = Function '<anonymous closure>':.
    //     0x826bd8: add             x1, PP, #0x53, lsl #12  ; [pp+0x53830] AnonymousClosure: (0x82a97c), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x826bdc: ldr             x1, [x1, #0x830]
    // 0x826be0: stur            x0, [fp, #-8]
    // 0x826be4: r0 = AllocateClosure()
    //     0x826be4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x826be8: ldur            x2, [fp, #-0x10]
    // 0x826bec: r1 = Function '<anonymous closure>':.
    //     0x826bec: add             x1, PP, #0x53, lsl #12  ; [pp+0x53838] AnonymousClosure: (0x82a928), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x826bf0: ldr             x1, [x1, #0x838]
    // 0x826bf4: stur            x0, [fp, #-0x18]
    // 0x826bf8: r0 = AllocateClosure()
    //     0x826bf8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x826bfc: ldur            x16, [fp, #-8]
    // 0x826c00: r30 = Instance_HitTestBehavior
    //     0x826c00: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x826c04: ldr             lr, [lr, #0xed0]
    // 0x826c08: stp             lr, x16, [SP, #-0x10]!
    // 0x826c0c: ldur            x16, [fp, #-0x18]
    // 0x826c10: stp             x0, x16, [SP, #-0x10]!
    // 0x826c14: r4 = const [0, 0x4, 0x4, 0x1, behavior, 0x1, onPanEnd, 0x3, onPanUpdate, 0x2, null]
    //     0x826c14: add             x4, PP, #0x53, lsl #12  ; [pp+0x53810] List(11) [0, 0x4, 0x4, 0x1, "behavior", 0x1, "onPanEnd", 0x3, "onPanUpdate", 0x2, Null]
    //     0x826c18: ldr             x4, [x4, #0x810]
    // 0x826c1c: r0 = GestureDetector()
    //     0x826c1c: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x826c20: add             SP, SP, #0x20
    // 0x826c24: r0 = Container()
    //     0x826c24: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x826c28: stur            x0, [fp, #-0x18]
    // 0x826c2c: r16 = 40.000000
    //     0x826c2c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x826c30: ldr             x16, [x16, #0x5b0]
    // 0x826c34: stp             x16, x0, [SP, #-0x10]!
    // 0x826c38: r16 = 40.000000
    //     0x826c38: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x826c3c: ldr             x16, [x16, #0x5b0]
    // 0x826c40: ldur            lr, [fp, #-8]
    // 0x826c44: stp             lr, x16, [SP, #-0x10]!
    // 0x826c48: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, height, 0x1, width, 0x2, null]
    //     0x826c48: add             x4, PP, #0x53, lsl #12  ; [pp+0x53818] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x826c4c: ldr             x4, [x4, #0x818]
    // 0x826c50: r0 = Container()
    //     0x826c50: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x826c54: add             SP, SP, #0x20
    // 0x826c58: ldur            d0, [fp, #-0x60]
    // 0x826c5c: r0 = inline_Allocate_Double()
    //     0x826c5c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x826c60: add             x0, x0, #0x10
    //     0x826c64: cmp             x1, x0
    //     0x826c68: b.ls            #0x827718
    //     0x826c6c: str             x0, [THR, #0x60]  ; THR::top
    //     0x826c70: sub             x0, x0, #0xf
    //     0x826c74: mov             x1, #0xd108
    //     0x826c78: movk            x1, #3, lsl #16
    //     0x826c7c: stur            x1, [x0, #-1]
    // 0x826c80: StoreField: r0->field_7 = d0
    //     0x826c80: stur            d0, [x0, #7]
    // 0x826c84: stur            x0, [fp, #-8]
    // 0x826c88: r1 = <StackParentData<RenderBox>>
    //     0x826c88: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x826c8c: ldr             x1, [x1, #0x5a8]
    // 0x826c90: r0 = Positioned()
    //     0x826c90: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x826c94: mov             x1, x0
    // 0x826c98: ldur            x0, [fp, #-8]
    // 0x826c9c: stur            x1, [fp, #-0x30]
    // 0x826ca0: StoreField: r1->field_13 = r0
    //     0x826ca0: stur            w0, [x1, #0x13]
    // 0x826ca4: ldur            d0, [fp, #-0x68]
    // 0x826ca8: r0 = inline_Allocate_Double()
    //     0x826ca8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x826cac: add             x0, x0, #0x10
    //     0x826cb0: cmp             x2, x0
    //     0x826cb4: b.ls            #0x827728
    //     0x826cb8: str             x0, [THR, #0x60]  ; THR::top
    //     0x826cbc: sub             x0, x0, #0xf
    //     0x826cc0: mov             x2, #0xd108
    //     0x826cc4: movk            x2, #3, lsl #16
    //     0x826cc8: stur            x2, [x0, #-1]
    // 0x826ccc: StoreField: r0->field_7 = d0
    //     0x826ccc: stur            d0, [x0, #7]
    // 0x826cd0: StoreField: r1->field_17 = r0
    //     0x826cd0: stur            w0, [x1, #0x17]
    // 0x826cd4: ldur            x0, [fp, #-0x18]
    // 0x826cd8: StoreField: r1->field_b = r0
    //     0x826cd8: stur            w0, [x1, #0xb]
    // 0x826cdc: ldr             x0, [fp, #0x18]
    // 0x826ce0: LoadField: r2 = r0->field_b
    //     0x826ce0: ldur            w2, [x0, #0xb]
    // 0x826ce4: DecompressPointer r2
    //     0x826ce4: add             x2, x2, HEAP, lsl #32
    // 0x826ce8: cmp             w2, NULL
    // 0x826cec: b.eq            #0x827740
    // 0x826cf0: LoadField: r3 = r2->field_b
    //     0x826cf0: ldur            w3, [x2, #0xb]
    // 0x826cf4: DecompressPointer r3
    //     0x826cf4: add             x3, x3, HEAP, lsl #32
    // 0x826cf8: LoadField: r2 = r3->field_4b
    //     0x826cf8: ldur            w2, [x3, #0x4b]
    // 0x826cfc: DecompressPointer r2
    //     0x826cfc: add             x2, x2, HEAP, lsl #32
    // 0x826d00: cmp             w2, NULL
    // 0x826d04: b.eq            #0x827744
    // 0x826d08: LoadField: d0 = r2->field_1f
    //     0x826d08: ldur            d0, [x2, #0x1f]
    // 0x826d0c: d1 = 20.000000
    //     0x826d0c: fmov            d1, #20.00000000
    // 0x826d10: fsub            d2, d0, d1
    // 0x826d14: stur            d2, [fp, #-0x68]
    // 0x826d18: LoadField: d0 = r2->field_17
    //     0x826d18: ldur            d0, [x2, #0x17]
    // 0x826d1c: fsub            d3, d0, d1
    // 0x826d20: stur            d3, [fp, #-0x60]
    // 0x826d24: r0 = GestureDetector()
    //     0x826d24: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x826d28: ldur            x2, [fp, #-0x10]
    // 0x826d2c: r1 = Function '<anonymous closure>':.
    //     0x826d2c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53840] AnonymousClosure: (0x82a8c4), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x826d30: ldr             x1, [x1, #0x840]
    // 0x826d34: stur            x0, [fp, #-8]
    // 0x826d38: r0 = AllocateClosure()
    //     0x826d38: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x826d3c: ldur            x2, [fp, #-0x10]
    // 0x826d40: r1 = Function '<anonymous closure>':.
    //     0x826d40: add             x1, PP, #0x53, lsl #12  ; [pp+0x53848] AnonymousClosure: (0x82a870), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x826d44: ldr             x1, [x1, #0x848]
    // 0x826d48: stur            x0, [fp, #-0x18]
    // 0x826d4c: r0 = AllocateClosure()
    //     0x826d4c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x826d50: ldur            x16, [fp, #-8]
    // 0x826d54: r30 = Instance_HitTestBehavior
    //     0x826d54: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x826d58: ldr             lr, [lr, #0xed0]
    // 0x826d5c: stp             lr, x16, [SP, #-0x10]!
    // 0x826d60: ldur            x16, [fp, #-0x18]
    // 0x826d64: stp             x0, x16, [SP, #-0x10]!
    // 0x826d68: r4 = const [0, 0x4, 0x4, 0x1, behavior, 0x1, onPanEnd, 0x3, onPanUpdate, 0x2, null]
    //     0x826d68: add             x4, PP, #0x53, lsl #12  ; [pp+0x53810] List(11) [0, 0x4, 0x4, 0x1, "behavior", 0x1, "onPanEnd", 0x3, "onPanUpdate", 0x2, Null]
    //     0x826d6c: ldr             x4, [x4, #0x810]
    // 0x826d70: r0 = GestureDetector()
    //     0x826d70: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x826d74: add             SP, SP, #0x20
    // 0x826d78: r0 = Container()
    //     0x826d78: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x826d7c: stur            x0, [fp, #-0x18]
    // 0x826d80: r16 = 40.000000
    //     0x826d80: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x826d84: ldr             x16, [x16, #0x5b0]
    // 0x826d88: stp             x16, x0, [SP, #-0x10]!
    // 0x826d8c: r16 = 40.000000
    //     0x826d8c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x826d90: ldr             x16, [x16, #0x5b0]
    // 0x826d94: ldur            lr, [fp, #-8]
    // 0x826d98: stp             lr, x16, [SP, #-0x10]!
    // 0x826d9c: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, height, 0x1, width, 0x2, null]
    //     0x826d9c: add             x4, PP, #0x53, lsl #12  ; [pp+0x53818] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x826da0: ldr             x4, [x4, #0x818]
    // 0x826da4: r0 = Container()
    //     0x826da4: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x826da8: add             SP, SP, #0x20
    // 0x826dac: ldur            d0, [fp, #-0x60]
    // 0x826db0: r0 = inline_Allocate_Double()
    //     0x826db0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x826db4: add             x0, x0, #0x10
    //     0x826db8: cmp             x1, x0
    //     0x826dbc: b.ls            #0x827748
    //     0x826dc0: str             x0, [THR, #0x60]  ; THR::top
    //     0x826dc4: sub             x0, x0, #0xf
    //     0x826dc8: mov             x1, #0xd108
    //     0x826dcc: movk            x1, #3, lsl #16
    //     0x826dd0: stur            x1, [x0, #-1]
    // 0x826dd4: StoreField: r0->field_7 = d0
    //     0x826dd4: stur            d0, [x0, #7]
    // 0x826dd8: stur            x0, [fp, #-8]
    // 0x826ddc: r1 = <StackParentData<RenderBox>>
    //     0x826ddc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x826de0: ldr             x1, [x1, #0x5a8]
    // 0x826de4: r0 = Positioned()
    //     0x826de4: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x826de8: mov             x1, x0
    // 0x826dec: ldur            x0, [fp, #-8]
    // 0x826df0: stur            x1, [fp, #-0x40]
    // 0x826df4: StoreField: r1->field_13 = r0
    //     0x826df4: stur            w0, [x1, #0x13]
    // 0x826df8: ldur            d0, [fp, #-0x68]
    // 0x826dfc: r0 = inline_Allocate_Double()
    //     0x826dfc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x826e00: add             x0, x0, #0x10
    //     0x826e04: cmp             x2, x0
    //     0x826e08: b.ls            #0x827758
    //     0x826e0c: str             x0, [THR, #0x60]  ; THR::top
    //     0x826e10: sub             x0, x0, #0xf
    //     0x826e14: mov             x2, #0xd108
    //     0x826e18: movk            x2, #3, lsl #16
    //     0x826e1c: stur            x2, [x0, #-1]
    // 0x826e20: StoreField: r0->field_7 = d0
    //     0x826e20: stur            d0, [x0, #7]
    // 0x826e24: StoreField: r1->field_17 = r0
    //     0x826e24: stur            w0, [x1, #0x17]
    // 0x826e28: ldur            x0, [fp, #-0x18]
    // 0x826e2c: StoreField: r1->field_b = r0
    //     0x826e2c: stur            w0, [x1, #0xb]
    // 0x826e30: ldr             x0, [fp, #0x18]
    // 0x826e34: LoadField: r2 = r0->field_b
    //     0x826e34: ldur            w2, [x0, #0xb]
    // 0x826e38: DecompressPointer r2
    //     0x826e38: add             x2, x2, HEAP, lsl #32
    // 0x826e3c: cmp             w2, NULL
    // 0x826e40: b.eq            #0x827770
    // 0x826e44: LoadField: r3 = r2->field_b
    //     0x826e44: ldur            w3, [x2, #0xb]
    // 0x826e48: DecompressPointer r3
    //     0x826e48: add             x3, x3, HEAP, lsl #32
    // 0x826e4c: LoadField: r2 = r3->field_4b
    //     0x826e4c: ldur            w2, [x3, #0x4b]
    // 0x826e50: DecompressPointer r2
    //     0x826e50: add             x2, x2, HEAP, lsl #32
    // 0x826e54: cmp             w2, NULL
    // 0x826e58: b.eq            #0x827774
    // 0x826e5c: LoadField: d0 = r2->field_f
    //     0x826e5c: ldur            d0, [x2, #0xf]
    // 0x826e60: d1 = 20.000000
    //     0x826e60: fmov            d1, #20.00000000
    // 0x826e64: fsub            d2, d0, d1
    // 0x826e68: stur            d2, [fp, #-0x70]
    // 0x826e6c: LoadField: d0 = r2->field_7
    //     0x826e6c: ldur            d0, [x2, #7]
    // 0x826e70: fadd            d3, d0, d1
    // 0x826e74: stur            d3, [fp, #-0x68]
    // 0x826e78: LoadField: d4 = r2->field_17
    //     0x826e78: ldur            d4, [x2, #0x17]
    // 0x826e7c: fsub            d5, d4, d0
    // 0x826e80: d0 = 40.000000
    //     0x826e80: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0x826e84: ldr             d0, [x17, #0xdc0]
    // 0x826e88: fsub            d4, d5, d0
    // 0x826e8c: fcmp            d4, d0
    // 0x826e90: b.vs            #0x826ea0
    // 0x826e94: b.le            #0x826ea0
    // 0x826e98: d5 = 0.000000
    //     0x826e98: eor             v5.16b, v5.16b, v5.16b
    // 0x826e9c: b               #0x826ed4
    // 0x826ea0: fcmp            d4, d0
    // 0x826ea4: b.vs            #0x826ebc
    // 0x826ea8: b.ge            #0x826ebc
    // 0x826eac: d4 = 40.000000
    //     0x826eac: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0x826eb0: ldr             d4, [x17, #0xdc0]
    // 0x826eb4: d5 = 0.000000
    //     0x826eb4: eor             v5.16b, v5.16b, v5.16b
    // 0x826eb8: b               #0x826ed4
    // 0x826ebc: d5 = 0.000000
    //     0x826ebc: eor             v5.16b, v5.16b, v5.16b
    // 0x826ec0: fcmp            d4, d5
    // 0x826ec4: b.vs            #0x826ed4
    // 0x826ec8: b.ne            #0x826ed4
    // 0x826ecc: fadd            d6, d4, d0
    // 0x826ed0: mov             v4.16b, v6.16b
    // 0x826ed4: stur            d4, [fp, #-0x60]
    // 0x826ed8: r0 = GestureDetector()
    //     0x826ed8: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x826edc: ldur            x2, [fp, #-0x10]
    // 0x826ee0: r1 = Function '<anonymous closure>':.
    //     0x826ee0: add             x1, PP, #0x53, lsl #12  ; [pp+0x53850] AnonymousClosure: (0x82a80c), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x826ee4: ldr             x1, [x1, #0x850]
    // 0x826ee8: stur            x0, [fp, #-8]
    // 0x826eec: r0 = AllocateClosure()
    //     0x826eec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x826ef0: ldur            x2, [fp, #-0x10]
    // 0x826ef4: r1 = Function '<anonymous closure>':.
    //     0x826ef4: add             x1, PP, #0x53, lsl #12  ; [pp+0x53858] AnonymousClosure: (0x82a7b8), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x826ef8: ldr             x1, [x1, #0x858]
    // 0x826efc: stur            x0, [fp, #-0x18]
    // 0x826f00: r0 = AllocateClosure()
    //     0x826f00: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x826f04: ldur            x16, [fp, #-8]
    // 0x826f08: r30 = Instance_HitTestBehavior
    //     0x826f08: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x826f0c: ldr             lr, [lr, #0xed0]
    // 0x826f10: stp             lr, x16, [SP, #-0x10]!
    // 0x826f14: ldur            x16, [fp, #-0x18]
    // 0x826f18: stp             x0, x16, [SP, #-0x10]!
    // 0x826f1c: r4 = const [0, 0x4, 0x4, 0x1, behavior, 0x1, onVerticalDragEnd, 0x3, onVerticalDragUpdate, 0x2, null]
    //     0x826f1c: add             x4, PP, #0x53, lsl #12  ; [pp+0x53860] List(11) [0, 0x4, 0x4, 0x1, "behavior", 0x1, "onVerticalDragEnd", 0x3, "onVerticalDragUpdate", 0x2, Null]
    //     0x826f20: ldr             x4, [x4, #0x860]
    // 0x826f24: r0 = GestureDetector()
    //     0x826f24: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x826f28: add             SP, SP, #0x20
    // 0x826f2c: r0 = Container()
    //     0x826f2c: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x826f30: ldur            d0, [fp, #-0x60]
    // 0x826f34: stur            x0, [fp, #-0x18]
    // 0x826f38: r1 = inline_Allocate_Double()
    //     0x826f38: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x826f3c: add             x1, x1, #0x10
    //     0x826f40: cmp             x2, x1
    //     0x826f44: b.ls            #0x827778
    //     0x826f48: str             x1, [THR, #0x60]  ; THR::top
    //     0x826f4c: sub             x1, x1, #0xf
    //     0x826f50: mov             x2, #0xd108
    //     0x826f54: movk            x2, #3, lsl #16
    //     0x826f58: stur            x2, [x1, #-1]
    // 0x826f5c: StoreField: r1->field_7 = d0
    //     0x826f5c: stur            d0, [x1, #7]
    // 0x826f60: r16 = 40.000000
    //     0x826f60: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x826f64: ldr             x16, [x16, #0x5b0]
    // 0x826f68: stp             x16, x0, [SP, #-0x10]!
    // 0x826f6c: ldur            x16, [fp, #-8]
    // 0x826f70: stp             x16, x1, [SP, #-0x10]!
    // 0x826f74: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, height, 0x1, width, 0x2, null]
    //     0x826f74: add             x4, PP, #0x53, lsl #12  ; [pp+0x53818] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x826f78: ldr             x4, [x4, #0x818]
    // 0x826f7c: r0 = Container()
    //     0x826f7c: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x826f80: add             SP, SP, #0x20
    // 0x826f84: ldur            d0, [fp, #-0x68]
    // 0x826f88: r0 = inline_Allocate_Double()
    //     0x826f88: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x826f8c: add             x0, x0, #0x10
    //     0x826f90: cmp             x1, x0
    //     0x826f94: b.ls            #0x827794
    //     0x826f98: str             x0, [THR, #0x60]  ; THR::top
    //     0x826f9c: sub             x0, x0, #0xf
    //     0x826fa0: mov             x1, #0xd108
    //     0x826fa4: movk            x1, #3, lsl #16
    //     0x826fa8: stur            x1, [x0, #-1]
    // 0x826fac: StoreField: r0->field_7 = d0
    //     0x826fac: stur            d0, [x0, #7]
    // 0x826fb0: stur            x0, [fp, #-8]
    // 0x826fb4: r1 = <StackParentData<RenderBox>>
    //     0x826fb4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x826fb8: ldr             x1, [x1, #0x5a8]
    // 0x826fbc: r0 = Positioned()
    //     0x826fbc: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x826fc0: mov             x1, x0
    // 0x826fc4: ldur            x0, [fp, #-8]
    // 0x826fc8: stur            x1, [fp, #-0x48]
    // 0x826fcc: StoreField: r1->field_13 = r0
    //     0x826fcc: stur            w0, [x1, #0x13]
    // 0x826fd0: ldur            d0, [fp, #-0x70]
    // 0x826fd4: r0 = inline_Allocate_Double()
    //     0x826fd4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x826fd8: add             x0, x0, #0x10
    //     0x826fdc: cmp             x2, x0
    //     0x826fe0: b.ls            #0x8277a4
    //     0x826fe4: str             x0, [THR, #0x60]  ; THR::top
    //     0x826fe8: sub             x0, x0, #0xf
    //     0x826fec: mov             x2, #0xd108
    //     0x826ff0: movk            x2, #3, lsl #16
    //     0x826ff4: stur            x2, [x0, #-1]
    // 0x826ff8: StoreField: r0->field_7 = d0
    //     0x826ff8: stur            d0, [x0, #7]
    // 0x826ffc: StoreField: r1->field_17 = r0
    //     0x826ffc: stur            w0, [x1, #0x17]
    // 0x827000: ldur            x0, [fp, #-0x18]
    // 0x827004: StoreField: r1->field_b = r0
    //     0x827004: stur            w0, [x1, #0xb]
    // 0x827008: ldr             x0, [fp, #0x18]
    // 0x82700c: LoadField: r2 = r0->field_b
    //     0x82700c: ldur            w2, [x0, #0xb]
    // 0x827010: DecompressPointer r2
    //     0x827010: add             x2, x2, HEAP, lsl #32
    // 0x827014: cmp             w2, NULL
    // 0x827018: b.eq            #0x8277bc
    // 0x82701c: LoadField: r3 = r2->field_b
    //     0x82701c: ldur            w3, [x2, #0xb]
    // 0x827020: DecompressPointer r3
    //     0x827020: add             x3, x3, HEAP, lsl #32
    // 0x827024: LoadField: r2 = r3->field_4b
    //     0x827024: ldur            w2, [x3, #0x4b]
    // 0x827028: DecompressPointer r2
    //     0x827028: add             x2, x2, HEAP, lsl #32
    // 0x82702c: cmp             w2, NULL
    // 0x827030: b.eq            #0x8277c0
    // 0x827034: LoadField: d0 = r2->field_f
    //     0x827034: ldur            d0, [x2, #0xf]
    // 0x827038: d1 = 20.000000
    //     0x827038: fmov            d1, #20.00000000
    // 0x82703c: fadd            d2, d0, d1
    // 0x827040: stur            d2, [fp, #-0x70]
    // 0x827044: LoadField: d3 = r2->field_7
    //     0x827044: ldur            d3, [x2, #7]
    // 0x827048: fsub            d4, d3, d1
    // 0x82704c: stur            d4, [fp, #-0x68]
    // 0x827050: LoadField: d3 = r2->field_1f
    //     0x827050: ldur            d3, [x2, #0x1f]
    // 0x827054: fsub            d5, d3, d0
    // 0x827058: d0 = 40.000000
    //     0x827058: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0x82705c: ldr             d0, [x17, #0xdc0]
    // 0x827060: fsub            d3, d5, d0
    // 0x827064: fcmp            d3, d0
    // 0x827068: b.vs            #0x827078
    // 0x82706c: b.le            #0x827078
    // 0x827070: d5 = 0.000000
    //     0x827070: eor             v5.16b, v5.16b, v5.16b
    // 0x827074: b               #0x8270ac
    // 0x827078: fcmp            d3, d0
    // 0x82707c: b.vs            #0x827094
    // 0x827080: b.ge            #0x827094
    // 0x827084: d3 = 40.000000
    //     0x827084: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0x827088: ldr             d3, [x17, #0xdc0]
    // 0x82708c: d5 = 0.000000
    //     0x82708c: eor             v5.16b, v5.16b, v5.16b
    // 0x827090: b               #0x8270ac
    // 0x827094: d5 = 0.000000
    //     0x827094: eor             v5.16b, v5.16b, v5.16b
    // 0x827098: fcmp            d3, d5
    // 0x82709c: b.vs            #0x8270ac
    // 0x8270a0: b.ne            #0x8270ac
    // 0x8270a4: fadd            d6, d3, d0
    // 0x8270a8: mov             v3.16b, v6.16b
    // 0x8270ac: stur            d3, [fp, #-0x60]
    // 0x8270b0: r0 = GestureDetector()
    //     0x8270b0: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x8270b4: ldur            x2, [fp, #-0x10]
    // 0x8270b8: r1 = Function '<anonymous closure>':.
    //     0x8270b8: add             x1, PP, #0x53, lsl #12  ; [pp+0x53868] AnonymousClosure: (0x82a754), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x8270bc: ldr             x1, [x1, #0x868]
    // 0x8270c0: stur            x0, [fp, #-8]
    // 0x8270c4: r0 = AllocateClosure()
    //     0x8270c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8270c8: ldur            x2, [fp, #-0x10]
    // 0x8270cc: r1 = Function '<anonymous closure>':.
    //     0x8270cc: add             x1, PP, #0x53, lsl #12  ; [pp+0x53870] AnonymousClosure: (0x82a700), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x8270d0: ldr             x1, [x1, #0x870]
    // 0x8270d4: stur            x0, [fp, #-0x18]
    // 0x8270d8: r0 = AllocateClosure()
    //     0x8270d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8270dc: ldur            x16, [fp, #-8]
    // 0x8270e0: r30 = Instance_HitTestBehavior
    //     0x8270e0: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x8270e4: ldr             lr, [lr, #0xed0]
    // 0x8270e8: stp             lr, x16, [SP, #-0x10]!
    // 0x8270ec: ldur            x16, [fp, #-0x18]
    // 0x8270f0: stp             x0, x16, [SP, #-0x10]!
    // 0x8270f4: r4 = const [0, 0x4, 0x4, 0x1, behavior, 0x1, onHorizontalDragEnd, 0x3, onHorizontalDragUpdate, 0x2, null]
    //     0x8270f4: add             x4, PP, #0x53, lsl #12  ; [pp+0x53878] List(11) [0, 0x4, 0x4, 0x1, "behavior", 0x1, "onHorizontalDragEnd", 0x3, "onHorizontalDragUpdate", 0x2, Null]
    //     0x8270f8: ldr             x4, [x4, #0x878]
    // 0x8270fc: r0 = GestureDetector()
    //     0x8270fc: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x827100: add             SP, SP, #0x20
    // 0x827104: r0 = Container()
    //     0x827104: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x827108: ldur            d0, [fp, #-0x60]
    // 0x82710c: stur            x0, [fp, #-0x18]
    // 0x827110: r1 = inline_Allocate_Double()
    //     0x827110: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x827114: add             x1, x1, #0x10
    //     0x827118: cmp             x2, x1
    //     0x82711c: b.ls            #0x8277c4
    //     0x827120: str             x1, [THR, #0x60]  ; THR::top
    //     0x827124: sub             x1, x1, #0xf
    //     0x827128: mov             x2, #0xd108
    //     0x82712c: movk            x2, #3, lsl #16
    //     0x827130: stur            x2, [x1, #-1]
    // 0x827134: StoreField: r1->field_7 = d0
    //     0x827134: stur            d0, [x1, #7]
    // 0x827138: stp             x1, x0, [SP, #-0x10]!
    // 0x82713c: r16 = 40.000000
    //     0x82713c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x827140: ldr             x16, [x16, #0x5b0]
    // 0x827144: ldur            lr, [fp, #-8]
    // 0x827148: stp             lr, x16, [SP, #-0x10]!
    // 0x82714c: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, height, 0x1, width, 0x2, null]
    //     0x82714c: add             x4, PP, #0x53, lsl #12  ; [pp+0x53818] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x827150: ldr             x4, [x4, #0x818]
    // 0x827154: r0 = Container()
    //     0x827154: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x827158: add             SP, SP, #0x20
    // 0x82715c: ldur            d0, [fp, #-0x68]
    // 0x827160: r0 = inline_Allocate_Double()
    //     0x827160: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x827164: add             x0, x0, #0x10
    //     0x827168: cmp             x1, x0
    //     0x82716c: b.ls            #0x8277e0
    //     0x827170: str             x0, [THR, #0x60]  ; THR::top
    //     0x827174: sub             x0, x0, #0xf
    //     0x827178: mov             x1, #0xd108
    //     0x82717c: movk            x1, #3, lsl #16
    //     0x827180: stur            x1, [x0, #-1]
    // 0x827184: StoreField: r0->field_7 = d0
    //     0x827184: stur            d0, [x0, #7]
    // 0x827188: stur            x0, [fp, #-8]
    // 0x82718c: r1 = <StackParentData<RenderBox>>
    //     0x82718c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x827190: ldr             x1, [x1, #0x5a8]
    // 0x827194: r0 = Positioned()
    //     0x827194: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x827198: mov             x1, x0
    // 0x82719c: ldur            x0, [fp, #-8]
    // 0x8271a0: stur            x1, [fp, #-0x50]
    // 0x8271a4: StoreField: r1->field_13 = r0
    //     0x8271a4: stur            w0, [x1, #0x13]
    // 0x8271a8: ldur            d0, [fp, #-0x70]
    // 0x8271ac: r0 = inline_Allocate_Double()
    //     0x8271ac: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x8271b0: add             x0, x0, #0x10
    //     0x8271b4: cmp             x2, x0
    //     0x8271b8: b.ls            #0x8277f0
    //     0x8271bc: str             x0, [THR, #0x60]  ; THR::top
    //     0x8271c0: sub             x0, x0, #0xf
    //     0x8271c4: mov             x2, #0xd108
    //     0x8271c8: movk            x2, #3, lsl #16
    //     0x8271cc: stur            x2, [x0, #-1]
    // 0x8271d0: StoreField: r0->field_7 = d0
    //     0x8271d0: stur            d0, [x0, #7]
    // 0x8271d4: StoreField: r1->field_17 = r0
    //     0x8271d4: stur            w0, [x1, #0x17]
    // 0x8271d8: ldur            x0, [fp, #-0x18]
    // 0x8271dc: StoreField: r1->field_b = r0
    //     0x8271dc: stur            w0, [x1, #0xb]
    // 0x8271e0: ldr             x0, [fp, #0x18]
    // 0x8271e4: LoadField: r2 = r0->field_b
    //     0x8271e4: ldur            w2, [x0, #0xb]
    // 0x8271e8: DecompressPointer r2
    //     0x8271e8: add             x2, x2, HEAP, lsl #32
    // 0x8271ec: cmp             w2, NULL
    // 0x8271f0: b.eq            #0x827808
    // 0x8271f4: LoadField: r3 = r2->field_b
    //     0x8271f4: ldur            w3, [x2, #0xb]
    // 0x8271f8: DecompressPointer r3
    //     0x8271f8: add             x3, x3, HEAP, lsl #32
    // 0x8271fc: LoadField: r2 = r3->field_4b
    //     0x8271fc: ldur            w2, [x3, #0x4b]
    // 0x827200: DecompressPointer r2
    //     0x827200: add             x2, x2, HEAP, lsl #32
    // 0x827204: cmp             w2, NULL
    // 0x827208: b.eq            #0x82780c
    // 0x82720c: LoadField: d0 = r2->field_1f
    //     0x82720c: ldur            d0, [x2, #0x1f]
    // 0x827210: d1 = 20.000000
    //     0x827210: fmov            d1, #20.00000000
    // 0x827214: fsub            d2, d0, d1
    // 0x827218: stur            d2, [fp, #-0x70]
    // 0x82721c: LoadField: d0 = r2->field_7
    //     0x82721c: ldur            d0, [x2, #7]
    // 0x827220: fadd            d3, d0, d1
    // 0x827224: stur            d3, [fp, #-0x68]
    // 0x827228: LoadField: d4 = r2->field_17
    //     0x827228: ldur            d4, [x2, #0x17]
    // 0x82722c: fsub            d5, d4, d0
    // 0x827230: d0 = 40.000000
    //     0x827230: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0x827234: ldr             d0, [x17, #0xdc0]
    // 0x827238: fsub            d4, d5, d0
    // 0x82723c: fcmp            d4, d0
    // 0x827240: b.vs            #0x827250
    // 0x827244: b.le            #0x827250
    // 0x827248: d5 = 0.000000
    //     0x827248: eor             v5.16b, v5.16b, v5.16b
    // 0x82724c: b               #0x827284
    // 0x827250: fcmp            d4, d0
    // 0x827254: b.vs            #0x82726c
    // 0x827258: b.ge            #0x82726c
    // 0x82725c: d4 = 40.000000
    //     0x82725c: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0x827260: ldr             d4, [x17, #0xdc0]
    // 0x827264: d5 = 0.000000
    //     0x827264: eor             v5.16b, v5.16b, v5.16b
    // 0x827268: b               #0x827284
    // 0x82726c: d5 = 0.000000
    //     0x82726c: eor             v5.16b, v5.16b, v5.16b
    // 0x827270: fcmp            d4, d5
    // 0x827274: b.vs            #0x827284
    // 0x827278: b.ne            #0x827284
    // 0x82727c: fadd            d6, d4, d0
    // 0x827280: mov             v4.16b, v6.16b
    // 0x827284: stur            d4, [fp, #-0x60]
    // 0x827288: r0 = GestureDetector()
    //     0x827288: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x82728c: ldur            x2, [fp, #-0x10]
    // 0x827290: r1 = Function '<anonymous closure>':.
    //     0x827290: add             x1, PP, #0x53, lsl #12  ; [pp+0x53880] AnonymousClosure: (0x82a69c), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x827294: ldr             x1, [x1, #0x880]
    // 0x827298: stur            x0, [fp, #-8]
    // 0x82729c: r0 = AllocateClosure()
    //     0x82729c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8272a0: ldur            x2, [fp, #-0x10]
    // 0x8272a4: r1 = Function '<anonymous closure>':.
    //     0x8272a4: add             x1, PP, #0x53, lsl #12  ; [pp+0x53888] AnonymousClosure: (0x82a648), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x8272a8: ldr             x1, [x1, #0x888]
    // 0x8272ac: stur            x0, [fp, #-0x18]
    // 0x8272b0: r0 = AllocateClosure()
    //     0x8272b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8272b4: ldur            x16, [fp, #-8]
    // 0x8272b8: r30 = Instance_HitTestBehavior
    //     0x8272b8: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x8272bc: ldr             lr, [lr, #0xed0]
    // 0x8272c0: stp             lr, x16, [SP, #-0x10]!
    // 0x8272c4: ldur            x16, [fp, #-0x18]
    // 0x8272c8: stp             x0, x16, [SP, #-0x10]!
    // 0x8272cc: r4 = const [0, 0x4, 0x4, 0x1, behavior, 0x1, onVerticalDragEnd, 0x3, onVerticalDragUpdate, 0x2, null]
    //     0x8272cc: add             x4, PP, #0x53, lsl #12  ; [pp+0x53860] List(11) [0, 0x4, 0x4, 0x1, "behavior", 0x1, "onVerticalDragEnd", 0x3, "onVerticalDragUpdate", 0x2, Null]
    //     0x8272d0: ldr             x4, [x4, #0x860]
    // 0x8272d4: r0 = GestureDetector()
    //     0x8272d4: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8272d8: add             SP, SP, #0x20
    // 0x8272dc: r0 = Container()
    //     0x8272dc: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8272e0: ldur            d0, [fp, #-0x60]
    // 0x8272e4: stur            x0, [fp, #-0x18]
    // 0x8272e8: r1 = inline_Allocate_Double()
    //     0x8272e8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x8272ec: add             x1, x1, #0x10
    //     0x8272f0: cmp             x2, x1
    //     0x8272f4: b.ls            #0x827810
    //     0x8272f8: str             x1, [THR, #0x60]  ; THR::top
    //     0x8272fc: sub             x1, x1, #0xf
    //     0x827300: mov             x2, #0xd108
    //     0x827304: movk            x2, #3, lsl #16
    //     0x827308: stur            x2, [x1, #-1]
    // 0x82730c: StoreField: r1->field_7 = d0
    //     0x82730c: stur            d0, [x1, #7]
    // 0x827310: r16 = 40.000000
    //     0x827310: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x827314: ldr             x16, [x16, #0x5b0]
    // 0x827318: stp             x16, x0, [SP, #-0x10]!
    // 0x82731c: ldur            x16, [fp, #-8]
    // 0x827320: stp             x16, x1, [SP, #-0x10]!
    // 0x827324: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, height, 0x1, width, 0x2, null]
    //     0x827324: add             x4, PP, #0x53, lsl #12  ; [pp+0x53818] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x827328: ldr             x4, [x4, #0x818]
    // 0x82732c: r0 = Container()
    //     0x82732c: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x827330: add             SP, SP, #0x20
    // 0x827334: ldur            d0, [fp, #-0x68]
    // 0x827338: r0 = inline_Allocate_Double()
    //     0x827338: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x82733c: add             x0, x0, #0x10
    //     0x827340: cmp             x1, x0
    //     0x827344: b.ls            #0x82782c
    //     0x827348: str             x0, [THR, #0x60]  ; THR::top
    //     0x82734c: sub             x0, x0, #0xf
    //     0x827350: mov             x1, #0xd108
    //     0x827354: movk            x1, #3, lsl #16
    //     0x827358: stur            x1, [x0, #-1]
    // 0x82735c: StoreField: r0->field_7 = d0
    //     0x82735c: stur            d0, [x0, #7]
    // 0x827360: stur            x0, [fp, #-8]
    // 0x827364: r1 = <StackParentData<RenderBox>>
    //     0x827364: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x827368: ldr             x1, [x1, #0x5a8]
    // 0x82736c: r0 = Positioned()
    //     0x82736c: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x827370: mov             x1, x0
    // 0x827374: ldur            x0, [fp, #-8]
    // 0x827378: stur            x1, [fp, #-0x58]
    // 0x82737c: StoreField: r1->field_13 = r0
    //     0x82737c: stur            w0, [x1, #0x13]
    // 0x827380: ldur            d0, [fp, #-0x70]
    // 0x827384: r0 = inline_Allocate_Double()
    //     0x827384: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x827388: add             x0, x0, #0x10
    //     0x82738c: cmp             x2, x0
    //     0x827390: b.ls            #0x82783c
    //     0x827394: str             x0, [THR, #0x60]  ; THR::top
    //     0x827398: sub             x0, x0, #0xf
    //     0x82739c: mov             x2, #0xd108
    //     0x8273a0: movk            x2, #3, lsl #16
    //     0x8273a4: stur            x2, [x0, #-1]
    // 0x8273a8: StoreField: r0->field_7 = d0
    //     0x8273a8: stur            d0, [x0, #7]
    // 0x8273ac: StoreField: r1->field_17 = r0
    //     0x8273ac: stur            w0, [x1, #0x17]
    // 0x8273b0: ldur            x0, [fp, #-0x18]
    // 0x8273b4: StoreField: r1->field_b = r0
    //     0x8273b4: stur            w0, [x1, #0xb]
    // 0x8273b8: ldr             x0, [fp, #0x18]
    // 0x8273bc: LoadField: r2 = r0->field_b
    //     0x8273bc: ldur            w2, [x0, #0xb]
    // 0x8273c0: DecompressPointer r2
    //     0x8273c0: add             x2, x2, HEAP, lsl #32
    // 0x8273c4: cmp             w2, NULL
    // 0x8273c8: b.eq            #0x827854
    // 0x8273cc: LoadField: r0 = r2->field_b
    //     0x8273cc: ldur            w0, [x2, #0xb]
    // 0x8273d0: DecompressPointer r0
    //     0x8273d0: add             x0, x0, HEAP, lsl #32
    // 0x8273d4: LoadField: r2 = r0->field_4b
    //     0x8273d4: ldur            w2, [x0, #0x4b]
    // 0x8273d8: DecompressPointer r2
    //     0x8273d8: add             x2, x2, HEAP, lsl #32
    // 0x8273dc: cmp             w2, NULL
    // 0x8273e0: b.eq            #0x827858
    // 0x8273e4: LoadField: d0 = r2->field_f
    //     0x8273e4: ldur            d0, [x2, #0xf]
    // 0x8273e8: d1 = 20.000000
    //     0x8273e8: fmov            d1, #20.00000000
    // 0x8273ec: fadd            d2, d0, d1
    // 0x8273f0: stur            d2, [fp, #-0x70]
    // 0x8273f4: LoadField: d3 = r2->field_17
    //     0x8273f4: ldur            d3, [x2, #0x17]
    // 0x8273f8: fsub            d4, d3, d1
    // 0x8273fc: stur            d4, [fp, #-0x68]
    // 0x827400: LoadField: d1 = r2->field_1f
    //     0x827400: ldur            d1, [x2, #0x1f]
    // 0x827404: fsub            d3, d1, d0
    // 0x827408: d0 = 40.000000
    //     0x827408: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0x82740c: ldr             d0, [x17, #0xdc0]
    // 0x827410: fsub            d1, d3, d0
    // 0x827414: fcmp            d1, d0
    // 0x827418: b.vs            #0x827428
    // 0x82741c: b.le            #0x827428
    // 0x827420: mov             v0.16b, v1.16b
    // 0x827424: b               #0x827460
    // 0x827428: fcmp            d1, d0
    // 0x82742c: b.vs            #0x827440
    // 0x827430: b.ge            #0x827440
    // 0x827434: d0 = 40.000000
    //     0x827434: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0x827438: ldr             d0, [x17, #0xdc0]
    // 0x82743c: b               #0x827460
    // 0x827440: d3 = 0.000000
    //     0x827440: eor             v3.16b, v3.16b, v3.16b
    // 0x827444: fcmp            d1, d3
    // 0x827448: b.vs            #0x82745c
    // 0x82744c: b.ne            #0x82745c
    // 0x827450: fadd            d3, d1, d0
    // 0x827454: mov             v0.16b, v3.16b
    // 0x827458: b               #0x827460
    // 0x82745c: mov             v0.16b, v1.16b
    // 0x827460: ldur            x7, [fp, #-0x38]
    // 0x827464: ldur            x6, [fp, #-0x20]
    // 0x827468: ldur            x5, [fp, #-0x28]
    // 0x82746c: ldur            x4, [fp, #-0x30]
    // 0x827470: ldur            x3, [fp, #-0x40]
    // 0x827474: ldur            x2, [fp, #-0x48]
    // 0x827478: ldur            x0, [fp, #-0x50]
    // 0x82747c: stur            d0, [fp, #-0x60]
    // 0x827480: r0 = GestureDetector()
    //     0x827480: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x827484: ldur            x2, [fp, #-0x10]
    // 0x827488: r1 = Function '<anonymous closure>':.
    //     0x827488: add             x1, PP, #0x53, lsl #12  ; [pp+0x53890] AnonymousClosure: (0x827ddc), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x82748c: ldr             x1, [x1, #0x890]
    // 0x827490: stur            x0, [fp, #-8]
    // 0x827494: r0 = AllocateClosure()
    //     0x827494: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x827498: ldur            x2, [fp, #-0x10]
    // 0x82749c: r1 = Function '<anonymous closure>':.
    //     0x82749c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53898] AnonymousClosure: (0x827960), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::build (0x826728)
    //     0x8274a0: ldr             x1, [x1, #0x898]
    // 0x8274a4: stur            x0, [fp, #-0x10]
    // 0x8274a8: r0 = AllocateClosure()
    //     0x8274a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8274ac: ldur            x16, [fp, #-8]
    // 0x8274b0: r30 = Instance_HitTestBehavior
    //     0x8274b0: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x8274b4: ldr             lr, [lr, #0xed0]
    // 0x8274b8: stp             lr, x16, [SP, #-0x10]!
    // 0x8274bc: ldur            x16, [fp, #-0x10]
    // 0x8274c0: stp             x0, x16, [SP, #-0x10]!
    // 0x8274c4: r4 = const [0, 0x4, 0x4, 0x1, behavior, 0x1, onHorizontalDragEnd, 0x3, onHorizontalDragUpdate, 0x2, null]
    //     0x8274c4: add             x4, PP, #0x53, lsl #12  ; [pp+0x53878] List(11) [0, 0x4, 0x4, 0x1, "behavior", 0x1, "onHorizontalDragEnd", 0x3, "onHorizontalDragUpdate", 0x2, Null]
    //     0x8274c8: ldr             x4, [x4, #0x878]
    // 0x8274cc: r0 = GestureDetector()
    //     0x8274cc: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8274d0: add             SP, SP, #0x20
    // 0x8274d4: r0 = Container()
    //     0x8274d4: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8274d8: ldur            d0, [fp, #-0x60]
    // 0x8274dc: stur            x0, [fp, #-0x10]
    // 0x8274e0: r1 = inline_Allocate_Double()
    //     0x8274e0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x8274e4: add             x1, x1, #0x10
    //     0x8274e8: cmp             x2, x1
    //     0x8274ec: b.ls            #0x82785c
    //     0x8274f0: str             x1, [THR, #0x60]  ; THR::top
    //     0x8274f4: sub             x1, x1, #0xf
    //     0x8274f8: mov             x2, #0xd108
    //     0x8274fc: movk            x2, #3, lsl #16
    //     0x827500: stur            x2, [x1, #-1]
    // 0x827504: StoreField: r1->field_7 = d0
    //     0x827504: stur            d0, [x1, #7]
    // 0x827508: stp             x1, x0, [SP, #-0x10]!
    // 0x82750c: r16 = 40.000000
    //     0x82750c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c5b0] 40
    //     0x827510: ldr             x16, [x16, #0x5b0]
    // 0x827514: ldur            lr, [fp, #-8]
    // 0x827518: stp             lr, x16, [SP, #-0x10]!
    // 0x82751c: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, height, 0x1, width, 0x2, null]
    //     0x82751c: add             x4, PP, #0x53, lsl #12  ; [pp+0x53818] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x827520: ldr             x4, [x4, #0x818]
    // 0x827524: r0 = Container()
    //     0x827524: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x827528: add             SP, SP, #0x20
    // 0x82752c: ldur            d0, [fp, #-0x68]
    // 0x827530: r0 = inline_Allocate_Double()
    //     0x827530: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x827534: add             x0, x0, #0x10
    //     0x827538: cmp             x1, x0
    //     0x82753c: b.ls            #0x827878
    //     0x827540: str             x0, [THR, #0x60]  ; THR::top
    //     0x827544: sub             x0, x0, #0xf
    //     0x827548: mov             x1, #0xd108
    //     0x82754c: movk            x1, #3, lsl #16
    //     0x827550: stur            x1, [x0, #-1]
    // 0x827554: StoreField: r0->field_7 = d0
    //     0x827554: stur            d0, [x0, #7]
    // 0x827558: stur            x0, [fp, #-8]
    // 0x82755c: r1 = <StackParentData<RenderBox>>
    //     0x82755c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x827560: ldr             x1, [x1, #0x5a8]
    // 0x827564: r0 = Positioned()
    //     0x827564: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x827568: mov             x3, x0
    // 0x82756c: ldur            x0, [fp, #-8]
    // 0x827570: stur            x3, [fp, #-0x18]
    // 0x827574: StoreField: r3->field_13 = r0
    //     0x827574: stur            w0, [x3, #0x13]
    // 0x827578: ldur            d0, [fp, #-0x70]
    // 0x82757c: r0 = inline_Allocate_Double()
    //     0x82757c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x827580: add             x0, x0, #0x10
    //     0x827584: cmp             x1, x0
    //     0x827588: b.ls            #0x827888
    //     0x82758c: str             x0, [THR, #0x60]  ; THR::top
    //     0x827590: sub             x0, x0, #0xf
    //     0x827594: mov             x1, #0xd108
    //     0x827598: movk            x1, #3, lsl #16
    //     0x82759c: stur            x1, [x0, #-1]
    // 0x8275a0: StoreField: r0->field_7 = d0
    //     0x8275a0: stur            d0, [x0, #7]
    // 0x8275a4: StoreField: r3->field_17 = r0
    //     0x8275a4: stur            w0, [x3, #0x17]
    // 0x8275a8: ldur            x0, [fp, #-0x10]
    // 0x8275ac: StoreField: r3->field_b = r0
    //     0x8275ac: stur            w0, [x3, #0xb]
    // 0x8275b0: r1 = Null
    //     0x8275b0: mov             x1, NULL
    // 0x8275b4: r2 = 16
    //     0x8275b4: mov             x2, #0x10
    // 0x8275b8: r0 = AllocateArray()
    //     0x8275b8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x8275bc: mov             x2, x0
    // 0x8275c0: ldur            x0, [fp, #-0x20]
    // 0x8275c4: stur            x2, [fp, #-8]
    // 0x8275c8: StoreField: r2->field_f = r0
    //     0x8275c8: stur            w0, [x2, #0xf]
    // 0x8275cc: ldur            x0, [fp, #-0x28]
    // 0x8275d0: StoreField: r2->field_13 = r0
    //     0x8275d0: stur            w0, [x2, #0x13]
    // 0x8275d4: ldur            x0, [fp, #-0x30]
    // 0x8275d8: StoreField: r2->field_17 = r0
    //     0x8275d8: stur            w0, [x2, #0x17]
    // 0x8275dc: ldur            x0, [fp, #-0x40]
    // 0x8275e0: StoreField: r2->field_1b = r0
    //     0x8275e0: stur            w0, [x2, #0x1b]
    // 0x8275e4: ldur            x0, [fp, #-0x48]
    // 0x8275e8: StoreField: r2->field_1f = r0
    //     0x8275e8: stur            w0, [x2, #0x1f]
    // 0x8275ec: ldur            x0, [fp, #-0x50]
    // 0x8275f0: StoreField: r2->field_23 = r0
    //     0x8275f0: stur            w0, [x2, #0x23]
    // 0x8275f4: ldur            x0, [fp, #-0x58]
    // 0x8275f8: StoreField: r2->field_27 = r0
    //     0x8275f8: stur            w0, [x2, #0x27]
    // 0x8275fc: ldur            x0, [fp, #-0x18]
    // 0x827600: StoreField: r2->field_2b = r0
    //     0x827600: stur            w0, [x2, #0x2b]
    // 0x827604: r1 = <Widget>
    //     0x827604: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x827608: ldr             x1, [x1, #0xea8]
    // 0x82760c: r0 = AllocateGrowableArray()
    //     0x82760c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x827610: mov             x1, x0
    // 0x827614: ldur            x0, [fp, #-8]
    // 0x827618: stur            x1, [fp, #-0x10]
    // 0x82761c: StoreField: r1->field_f = r0
    //     0x82761c: stur            w0, [x1, #0xf]
    // 0x827620: r0 = 16
    //     0x827620: mov             x0, #0x10
    // 0x827624: StoreField: r1->field_b = r0
    //     0x827624: stur            w0, [x1, #0xb]
    // 0x827628: r0 = Stack()
    //     0x827628: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x82762c: mov             x1, x0
    // 0x827630: r0 = Instance_AlignmentDirectional
    //     0x827630: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0x827634: ldr             x0, [x0, #0xf70]
    // 0x827638: stur            x1, [fp, #-8]
    // 0x82763c: StoreField: r1->field_f = r0
    //     0x82763c: stur            w0, [x1, #0xf]
    // 0x827640: r0 = Instance_StackFit
    //     0x827640: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f78] Obj!StackFit@b64771
    //     0x827644: ldr             x0, [x0, #0xf78]
    // 0x827648: StoreField: r1->field_17 = r0
    //     0x827648: stur            w0, [x1, #0x17]
    // 0x82764c: r0 = Instance_Clip
    //     0x82764c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x827650: ldr             x0, [x0, #0x678]
    // 0x827654: StoreField: r1->field_1b = r0
    //     0x827654: stur            w0, [x1, #0x1b]
    // 0x827658: ldur            x0, [fp, #-0x10]
    // 0x82765c: StoreField: r1->field_b = r0
    //     0x82765c: stur            w0, [x1, #0xb]
    // 0x827660: r0 = CustomPaint()
    //     0x827660: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x827664: ldur            x1, [fp, #-0x38]
    // 0x827668: StoreField: r0->field_f = r1
    //     0x827668: stur            w1, [x0, #0xf]
    // 0x82766c: r1 = Instance_Size
    //     0x82766c: ldr             x1, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x827670: StoreField: r0->field_17 = r1
    //     0x827670: stur            w1, [x0, #0x17]
    // 0x827674: r1 = false
    //     0x827674: add             x1, NULL, #0x30  ; false
    // 0x827678: StoreField: r0->field_1b = r1
    //     0x827678: stur            w1, [x0, #0x1b]
    // 0x82767c: StoreField: r0->field_1f = r1
    //     0x82767c: stur            w1, [x0, #0x1f]
    // 0x827680: ldur            x1, [fp, #-8]
    // 0x827684: StoreField: r0->field_b = r1
    //     0x827684: stur            w1, [x0, #0xb]
    // 0x827688: LeaveFrame
    //     0x827688: mov             SP, fp
    //     0x82768c: ldp             fp, lr, [SP], #0x10
    // 0x827690: ret
    //     0x827690: ret             
    // 0x827694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827694: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827698: b               #0x826740
    // 0x82769c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82769c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8276a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8276a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8276a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8276a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8276a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8276a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8276ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8276ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8276b0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8276b0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x8276b4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8276b4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x8276b8: SaveReg d0
    //     0x8276b8: str             q0, [SP, #-0x10]!
    // 0x8276bc: r0 = AllocateDouble()
    //     0x8276bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8276c0: RestoreReg d0
    //     0x8276c0: ldr             q0, [SP], #0x10
    // 0x8276c4: b               #0x8269d8
    // 0x8276c8: SaveReg d0
    //     0x8276c8: str             q0, [SP, #-0x10]!
    // 0x8276cc: SaveReg r1
    //     0x8276cc: str             x1, [SP, #-8]!
    // 0x8276d0: r0 = AllocateDouble()
    //     0x8276d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8276d4: RestoreReg r1
    //     0x8276d4: ldr             x1, [SP], #8
    // 0x8276d8: RestoreReg d0
    //     0x8276d8: ldr             q0, [SP], #0x10
    // 0x8276dc: b               #0x826a24
    // 0x8276e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8276e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8276e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8276e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8276e8: SaveReg d0
    //     0x8276e8: str             q0, [SP, #-0x10]!
    // 0x8276ec: r0 = AllocateDouble()
    //     0x8276ec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8276f0: RestoreReg d0
    //     0x8276f0: ldr             q0, [SP], #0x10
    // 0x8276f4: b               #0x826b2c
    // 0x8276f8: SaveReg d0
    //     0x8276f8: str             q0, [SP, #-0x10]!
    // 0x8276fc: SaveReg r1
    //     0x8276fc: str             x1, [SP, #-8]!
    // 0x827700: r0 = AllocateDouble()
    //     0x827700: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827704: RestoreReg r1
    //     0x827704: ldr             x1, [SP], #8
    // 0x827708: RestoreReg d0
    //     0x827708: ldr             q0, [SP], #0x10
    // 0x82770c: b               #0x826b78
    // 0x827710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827710: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827714: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827714: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827718: SaveReg d0
    //     0x827718: str             q0, [SP, #-0x10]!
    // 0x82771c: r0 = AllocateDouble()
    //     0x82771c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827720: RestoreReg d0
    //     0x827720: ldr             q0, [SP], #0x10
    // 0x827724: b               #0x826c80
    // 0x827728: SaveReg d0
    //     0x827728: str             q0, [SP, #-0x10]!
    // 0x82772c: SaveReg r1
    //     0x82772c: str             x1, [SP, #-8]!
    // 0x827730: r0 = AllocateDouble()
    //     0x827730: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827734: RestoreReg r1
    //     0x827734: ldr             x1, [SP], #8
    // 0x827738: RestoreReg d0
    //     0x827738: ldr             q0, [SP], #0x10
    // 0x82773c: b               #0x826ccc
    // 0x827740: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827740: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827744: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827744: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827748: SaveReg d0
    //     0x827748: str             q0, [SP, #-0x10]!
    // 0x82774c: r0 = AllocateDouble()
    //     0x82774c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827750: RestoreReg d0
    //     0x827750: ldr             q0, [SP], #0x10
    // 0x827754: b               #0x826dd4
    // 0x827758: SaveReg d0
    //     0x827758: str             q0, [SP, #-0x10]!
    // 0x82775c: SaveReg r1
    //     0x82775c: str             x1, [SP, #-8]!
    // 0x827760: r0 = AllocateDouble()
    //     0x827760: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827764: RestoreReg r1
    //     0x827764: ldr             x1, [SP], #8
    // 0x827768: RestoreReg d0
    //     0x827768: ldr             q0, [SP], #0x10
    // 0x82776c: b               #0x826e20
    // 0x827770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827770: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827774: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827774: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827778: SaveReg d0
    //     0x827778: str             q0, [SP, #-0x10]!
    // 0x82777c: SaveReg r0
    //     0x82777c: str             x0, [SP, #-8]!
    // 0x827780: r0 = AllocateDouble()
    //     0x827780: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827784: mov             x1, x0
    // 0x827788: RestoreReg r0
    //     0x827788: ldr             x0, [SP], #8
    // 0x82778c: RestoreReg d0
    //     0x82778c: ldr             q0, [SP], #0x10
    // 0x827790: b               #0x826f5c
    // 0x827794: SaveReg d0
    //     0x827794: str             q0, [SP, #-0x10]!
    // 0x827798: r0 = AllocateDouble()
    //     0x827798: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82779c: RestoreReg d0
    //     0x82779c: ldr             q0, [SP], #0x10
    // 0x8277a0: b               #0x826fac
    // 0x8277a4: SaveReg d0
    //     0x8277a4: str             q0, [SP, #-0x10]!
    // 0x8277a8: SaveReg r1
    //     0x8277a8: str             x1, [SP, #-8]!
    // 0x8277ac: r0 = AllocateDouble()
    //     0x8277ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8277b0: RestoreReg r1
    //     0x8277b0: ldr             x1, [SP], #8
    // 0x8277b4: RestoreReg d0
    //     0x8277b4: ldr             q0, [SP], #0x10
    // 0x8277b8: b               #0x826ff8
    // 0x8277bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8277bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8277c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8277c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8277c4: SaveReg d0
    //     0x8277c4: str             q0, [SP, #-0x10]!
    // 0x8277c8: SaveReg r0
    //     0x8277c8: str             x0, [SP, #-8]!
    // 0x8277cc: r0 = AllocateDouble()
    //     0x8277cc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8277d0: mov             x1, x0
    // 0x8277d4: RestoreReg r0
    //     0x8277d4: ldr             x0, [SP], #8
    // 0x8277d8: RestoreReg d0
    //     0x8277d8: ldr             q0, [SP], #0x10
    // 0x8277dc: b               #0x827134
    // 0x8277e0: SaveReg d0
    //     0x8277e0: str             q0, [SP, #-0x10]!
    // 0x8277e4: r0 = AllocateDouble()
    //     0x8277e4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8277e8: RestoreReg d0
    //     0x8277e8: ldr             q0, [SP], #0x10
    // 0x8277ec: b               #0x827184
    // 0x8277f0: SaveReg d0
    //     0x8277f0: str             q0, [SP, #-0x10]!
    // 0x8277f4: SaveReg r1
    //     0x8277f4: str             x1, [SP, #-8]!
    // 0x8277f8: r0 = AllocateDouble()
    //     0x8277f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8277fc: RestoreReg r1
    //     0x8277fc: ldr             x1, [SP], #8
    // 0x827800: RestoreReg d0
    //     0x827800: ldr             q0, [SP], #0x10
    // 0x827804: b               #0x8271d0
    // 0x827808: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827808: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82780c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82780c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827810: SaveReg d0
    //     0x827810: str             q0, [SP, #-0x10]!
    // 0x827814: SaveReg r0
    //     0x827814: str             x0, [SP, #-8]!
    // 0x827818: r0 = AllocateDouble()
    //     0x827818: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82781c: mov             x1, x0
    // 0x827820: RestoreReg r0
    //     0x827820: ldr             x0, [SP], #8
    // 0x827824: RestoreReg d0
    //     0x827824: ldr             q0, [SP], #0x10
    // 0x827828: b               #0x82730c
    // 0x82782c: SaveReg d0
    //     0x82782c: str             q0, [SP, #-0x10]!
    // 0x827830: r0 = AllocateDouble()
    //     0x827830: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827834: RestoreReg d0
    //     0x827834: ldr             q0, [SP], #0x10
    // 0x827838: b               #0x82735c
    // 0x82783c: SaveReg d0
    //     0x82783c: str             q0, [SP, #-0x10]!
    // 0x827840: SaveReg r1
    //     0x827840: str             x1, [SP, #-8]!
    // 0x827844: r0 = AllocateDouble()
    //     0x827844: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827848: RestoreReg r1
    //     0x827848: ldr             x1, [SP], #8
    // 0x82784c: RestoreReg d0
    //     0x82784c: ldr             q0, [SP], #0x10
    // 0x827850: b               #0x8273a8
    // 0x827854: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827854: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827858: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827858: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82785c: SaveReg d0
    //     0x82785c: str             q0, [SP, #-0x10]!
    // 0x827860: SaveReg r0
    //     0x827860: str             x0, [SP, #-8]!
    // 0x827864: r0 = AllocateDouble()
    //     0x827864: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827868: mov             x1, x0
    // 0x82786c: RestoreReg r0
    //     0x82786c: ldr             x0, [SP], #8
    // 0x827870: RestoreReg d0
    //     0x827870: ldr             q0, [SP], #0x10
    // 0x827874: b               #0x827504
    // 0x827878: SaveReg d0
    //     0x827878: str             q0, [SP, #-0x10]!
    // 0x82787c: r0 = AllocateDouble()
    //     0x82787c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827880: RestoreReg d0
    //     0x827880: ldr             q0, [SP], #0x10
    // 0x827884: b               #0x827554
    // 0x827888: SaveReg d0
    //     0x827888: str             q0, [SP, #-0x10]!
    // 0x82788c: SaveReg r3
    //     0x82788c: str             x3, [SP, #-8]!
    // 0x827890: r0 = AllocateDouble()
    //     0x827890: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x827894: RestoreReg r3
    //     0x827894: ldr             x3, [SP], #8
    // 0x827898: RestoreReg d0
    //     0x827898: ldr             q0, [SP], #0x10
    // 0x82789c: b               #0x8275a0
  }
  get _ cropRect(/* No info */) {
    // ** addr: 0x8278ac, size: 0x3c
    // 0x8278ac: EnterFrame
    //     0x8278ac: stp             fp, lr, [SP, #-0x10]!
    //     0x8278b0: mov             fp, SP
    // 0x8278b4: ldr             x1, [fp, #0x10]
    // 0x8278b8: LoadField: r2 = r1->field_b
    //     0x8278b8: ldur            w2, [x1, #0xb]
    // 0x8278bc: DecompressPointer r2
    //     0x8278bc: add             x2, x2, HEAP, lsl #32
    // 0x8278c0: cmp             w2, NULL
    // 0x8278c4: b.eq            #0x8278e4
    // 0x8278c8: LoadField: r1 = r2->field_b
    //     0x8278c8: ldur            w1, [x2, #0xb]
    // 0x8278cc: DecompressPointer r1
    //     0x8278cc: add             x1, x1, HEAP, lsl #32
    // 0x8278d0: LoadField: r0 = r1->field_4b
    //     0x8278d0: ldur            w0, [x1, #0x4b]
    // 0x8278d4: DecompressPointer r0
    //     0x8278d4: add             x0, x0, HEAP, lsl #32
    // 0x8278d8: LeaveFrame
    //     0x8278d8: mov             SP, fp
    //     0x8278dc: ldp             fp, lr, [SP], #0x10
    // 0x8278e0: ret
    //     0x8278e0: ret             
    // 0x8278e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8278e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0x827960, size: 0x54
    // 0x827960: EnterFrame
    //     0x827960: stp             fp, lr, [SP, #-0x10]!
    //     0x827964: mov             fp, SP
    // 0x827968: ldr             x0, [fp, #0x18]
    // 0x82796c: LoadField: r1 = r0->field_17
    //     0x82796c: ldur            w1, [x0, #0x17]
    // 0x827970: DecompressPointer r1
    //     0x827970: add             x1, x1, HEAP, lsl #32
    // 0x827974: CheckStackOverflow
    //     0x827974: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x827978: cmp             SP, x16
    //     0x82797c: b.ls            #0x8279ac
    // 0x827980: LoadField: r0 = r1->field_f
    //     0x827980: ldur            w0, [x1, #0xf]
    // 0x827984: DecompressPointer r0
    //     0x827984: add             x0, x0, HEAP, lsl #32
    // 0x827988: r16 = Instance__MoveType
    //     0x827988: add             x16, PP, #0x53, lsl #12  ; [pp+0x538a0] Obj!_MoveType@b661b1
    //     0x82798c: ldr             x16, [x16, #0x8a0]
    // 0x827990: stp             x16, x0, [SP, #-0x10]!
    // 0x827994: r0 = _moveEnd()
    //     0x827994: bl              #0x8279b4  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_moveEnd
    // 0x827998: add             SP, SP, #0x10
    // 0x82799c: r0 = Null
    //     0x82799c: mov             x0, NULL
    // 0x8279a0: LeaveFrame
    //     0x8279a0: mov             SP, fp
    //     0x8279a4: ldp             fp, lr, [SP], #0x10
    // 0x8279a8: ret
    //     0x8279a8: ret             
    // 0x8279ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8279ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8279b0: b               #0x827980
  }
  _ _moveEnd(/* No info */) {
    // ** addr: 0x8279b4, size: 0x5c
    // 0x8279b4: EnterFrame
    //     0x8279b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8279b8: mov             fp, SP
    // 0x8279bc: CheckStackOverflow
    //     0x8279bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8279c0: cmp             SP, x16
    //     0x8279c4: b.ls            #0x827a08
    // 0x8279c8: ldr             x0, [fp, #0x18]
    // 0x8279cc: LoadField: r1 = r0->field_2b
    //     0x8279cc: ldur            w1, [x0, #0x2b]
    // 0x8279d0: DecompressPointer r1
    //     0x8279d0: add             x1, x1, HEAP, lsl #32
    // 0x8279d4: cmp             w1, NULL
    // 0x8279d8: b.eq            #0x8279f8
    // 0x8279dc: ldr             x2, [fp, #0x10]
    // 0x8279e0: cmp             w2, w1
    // 0x8279e4: b.ne            #0x8279f8
    // 0x8279e8: StoreField: r0->field_2b = rNULL
    //     0x8279e8: stur            NULL, [x0, #0x2b]
    // 0x8279ec: SaveReg r0
    //     0x8279ec: str             x0, [SP, #-8]!
    // 0x8279f0: r0 = _startTimer()
    //     0x8279f0: bl              #0x827a10  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_startTimer
    // 0x8279f4: add             SP, SP, #8
    // 0x8279f8: r0 = Null
    //     0x8279f8: mov             x0, NULL
    // 0x8279fc: LeaveFrame
    //     0x8279fc: mov             SP, fp
    //     0x827a00: ldp             fp, lr, [SP], #0x10
    // 0x827a04: ret
    //     0x827a04: ret             
    // 0x827a08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827a08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827a0c: b               #0x8279c8
  }
  _ _startTimer(/* No info */) {
    // ** addr: 0x827a10, size: 0x114
    // 0x827a10: EnterFrame
    //     0x827a10: stp             fp, lr, [SP, #-0x10]!
    //     0x827a14: mov             fp, SP
    // 0x827a18: AllocStack(0x8)
    //     0x827a18: sub             SP, SP, #8
    // 0x827a1c: CheckStackOverflow
    //     0x827a1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x827a20: cmp             SP, x16
    //     0x827a24: b.ls            #0x827b0c
    // 0x827a28: r1 = 1
    //     0x827a28: mov             x1, #1
    // 0x827a2c: r0 = AllocateContext()
    //     0x827a2c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x827a30: mov             x1, x0
    // 0x827a34: ldr             x0, [fp, #0x10]
    // 0x827a38: stur            x1, [fp, #-8]
    // 0x827a3c: StoreField: r1->field_f = r0
    //     0x827a3c: stur            w0, [x1, #0xf]
    // 0x827a40: LoadField: r2 = r0->field_1b
    //     0x827a40: ldur            w2, [x0, #0x1b]
    // 0x827a44: DecompressPointer r2
    //     0x827a44: add             x2, x2, HEAP, lsl #32
    // 0x827a48: cmp             w2, NULL
    // 0x827a4c: b.eq            #0x827a60
    // 0x827a50: SaveReg r2
    //     0x827a50: str             x2, [SP, #-8]!
    // 0x827a54: r0 = cancel()
    //     0x827a54: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x827a58: add             SP, SP, #8
    // 0x827a5c: ldr             x0, [fp, #0x10]
    // 0x827a60: LoadField: r1 = r0->field_27
    //     0x827a60: ldur            w1, [x0, #0x27]
    // 0x827a64: DecompressPointer r1
    //     0x827a64: add             x1, x1, HEAP, lsl #32
    // 0x827a68: r16 = Sentinel
    //     0x827a68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x827a6c: cmp             w1, w16
    // 0x827a70: b.eq            #0x827b14
    // 0x827a74: LoadField: r2 = r1->field_2f
    //     0x827a74: ldur            w2, [x1, #0x2f]
    // 0x827a78: DecompressPointer r2
    //     0x827a78: add             x2, x2, HEAP, lsl #32
    // 0x827a7c: cmp             w2, NULL
    // 0x827a80: b.eq            #0x827aa4
    // 0x827a84: LoadField: r1 = r2->field_7
    //     0x827a84: ldur            w1, [x2, #7]
    // 0x827a88: DecompressPointer r1
    //     0x827a88: add             x1, x1, HEAP, lsl #32
    // 0x827a8c: cmp             w1, NULL
    // 0x827a90: b.eq            #0x827aa4
    // 0x827a94: r0 = Null
    //     0x827a94: mov             x0, NULL
    // 0x827a98: LeaveFrame
    //     0x827a98: mov             SP, fp
    //     0x827a9c: ldp             fp, lr, [SP], #0x10
    // 0x827aa0: ret
    //     0x827aa0: ret             
    // 0x827aa4: LoadField: r1 = r0->field_b
    //     0x827aa4: ldur            w1, [x0, #0xb]
    // 0x827aa8: DecompressPointer r1
    //     0x827aa8: add             x1, x1, HEAP, lsl #32
    // 0x827aac: cmp             w1, NULL
    // 0x827ab0: b.eq            #0x827b20
    // 0x827ab4: ldur            x2, [fp, #-8]
    // 0x827ab8: r1 = Function '<anonymous closure>':.
    //     0x827ab8: add             x1, PP, #0x53, lsl #12  ; [pp+0x538a8] AnonymousClosure: (0x827b24), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_startTimer (0x827a10)
    //     0x827abc: ldr             x1, [x1, #0x8a8]
    // 0x827ac0: r0 = AllocateClosure()
    //     0x827ac0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x827ac4: r16 = Instance_Duration
    //     0x827ac4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20808] Obj!Duration@b67ae1
    //     0x827ac8: ldr             x16, [x16, #0x808]
    // 0x827acc: stp             x16, NULL, [SP, #-0x10]!
    // 0x827ad0: SaveReg r0
    //     0x827ad0: str             x0, [SP, #-8]!
    // 0x827ad4: r0 = Timer.periodic()
    //     0x827ad4: bl              #0x5e7588  ; [dart:async] Timer::Timer.periodic
    // 0x827ad8: add             SP, SP, #0x18
    // 0x827adc: ldr             x1, [fp, #0x10]
    // 0x827ae0: StoreField: r1->field_1b = r0
    //     0x827ae0: stur            w0, [x1, #0x1b]
    //     0x827ae4: ldurb           w16, [x1, #-1]
    //     0x827ae8: ldurb           w17, [x0, #-1]
    //     0x827aec: and             x16, x17, x16, lsr #2
    //     0x827af0: tst             x16, HEAP, lsr #32
    //     0x827af4: b.eq            #0x827afc
    //     0x827af8: bl              #0xd6826c
    // 0x827afc: r0 = Null
    //     0x827afc: mov             x0, NULL
    // 0x827b00: LeaveFrame
    //     0x827b00: mov             SP, fp
    //     0x827b04: ldp             fp, lr, [SP], #0x10
    // 0x827b08: ret
    //     0x827b08: ret             
    // 0x827b0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827b0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827b10: b               #0x827a28
    // 0x827b14: r9 = _rectTweenController
    //     0x827b14: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c750] Field <ExtendedImageCropLayerState._rectTweenController@420005332>: late (offset: 0x28)
    //     0x827b18: ldr             x9, [x9, #0x750]
    // 0x827b1c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x827b1c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x827b20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827b20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x827b24, size: 0x2ac
    // 0x827b24: EnterFrame
    //     0x827b24: stp             fp, lr, [SP, #-0x10]!
    //     0x827b28: mov             fp, SP
    // 0x827b2c: AllocStack(0x28)
    //     0x827b2c: sub             SP, SP, #0x28
    // 0x827b30: SetupParameters()
    //     0x827b30: ldr             x0, [fp, #0x18]
    //     0x827b34: ldur            w1, [x0, #0x17]
    //     0x827b38: add             x1, x1, HEAP, lsl #32
    //     0x827b3c: stur            x1, [fp, #-8]
    // 0x827b40: CheckStackOverflow
    //     0x827b40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x827b44: cmp             SP, x16
    //     0x827b48: b.ls            #0x827d8c
    // 0x827b4c: LoadField: r0 = r1->field_f
    //     0x827b4c: ldur            w0, [x1, #0xf]
    // 0x827b50: DecompressPointer r0
    //     0x827b50: add             x0, x0, HEAP, lsl #32
    // 0x827b54: LoadField: r2 = r0->field_1b
    //     0x827b54: ldur            w2, [x0, #0x1b]
    // 0x827b58: DecompressPointer r2
    //     0x827b58: add             x2, x2, HEAP, lsl #32
    // 0x827b5c: cmp             w2, NULL
    // 0x827b60: b.ne            #0x827b6c
    // 0x827b64: mov             x0, x1
    // 0x827b68: b               #0x827b7c
    // 0x827b6c: SaveReg r2
    //     0x827b6c: str             x2, [SP, #-8]!
    // 0x827b70: r0 = cancel()
    //     0x827b70: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x827b74: add             SP, SP, #8
    // 0x827b78: ldur            x0, [fp, #-8]
    // 0x827b7c: LoadField: r1 = r0->field_f
    //     0x827b7c: ldur            w1, [x0, #0xf]
    // 0x827b80: DecompressPointer r1
    //     0x827b80: add             x1, x1, HEAP, lsl #32
    // 0x827b84: LoadField: r2 = r1->field_b
    //     0x827b84: ldur            w2, [x1, #0xb]
    // 0x827b88: DecompressPointer r2
    //     0x827b88: add             x2, x2, HEAP, lsl #32
    // 0x827b8c: cmp             w2, NULL
    // 0x827b90: b.eq            #0x827d94
    // 0x827b94: LoadField: r1 = r2->field_b
    //     0x827b94: ldur            w1, [x2, #0xb]
    // 0x827b98: DecompressPointer r1
    //     0x827b98: add             x1, x1, HEAP, lsl #32
    // 0x827b9c: SaveReg r1
    //     0x827b9c: str             x1, [SP, #-8]!
    // 0x827ba0: r0 = screenCropRect()
    //     0x827ba0: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x827ba4: add             SP, SP, #8
    // 0x827ba8: mov             x1, x0
    // 0x827bac: ldur            x0, [fp, #-8]
    // 0x827bb0: stur            x1, [fp, #-0x10]
    // 0x827bb4: LoadField: r2 = r0->field_f
    //     0x827bb4: ldur            w2, [x0, #0xf]
    // 0x827bb8: DecompressPointer r2
    //     0x827bb8: add             x2, x2, HEAP, lsl #32
    // 0x827bbc: SaveReg r2
    //     0x827bbc: str             x2, [SP, #-8]!
    // 0x827bc0: r0 = layoutRect()
    //     0x827bc0: bl              #0x7a09bc  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::layoutRect
    // 0x827bc4: add             SP, SP, #8
    // 0x827bc8: mov             x1, x0
    // 0x827bcc: ldur            x0, [fp, #-8]
    // 0x827bd0: stur            x1, [fp, #-0x18]
    // 0x827bd4: LoadField: r2 = r0->field_f
    //     0x827bd4: ldur            w2, [x0, #0xf]
    // 0x827bd8: DecompressPointer r2
    //     0x827bd8: add             x2, x2, HEAP, lsl #32
    // 0x827bdc: LoadField: r3 = r2->field_b
    //     0x827bdc: ldur            w3, [x2, #0xb]
    // 0x827be0: DecompressPointer r3
    //     0x827be0: add             x3, x3, HEAP, lsl #32
    // 0x827be4: cmp             w3, NULL
    // 0x827be8: b.eq            #0x827d98
    // 0x827bec: LoadField: r2 = r3->field_b
    //     0x827bec: ldur            w2, [x3, #0xb]
    // 0x827bf0: DecompressPointer r2
    //     0x827bf0: add             x2, x2, HEAP, lsl #32
    // 0x827bf4: LoadField: r3 = r2->field_4b
    //     0x827bf4: ldur            w3, [x2, #0x4b]
    // 0x827bf8: DecompressPointer r3
    //     0x827bf8: add             x3, x3, HEAP, lsl #32
    // 0x827bfc: cmp             w3, NULL
    // 0x827c00: b.eq            #0x827d9c
    // 0x827c04: SaveReg r3
    //     0x827c04: str             x3, [SP, #-8]!
    // 0x827c08: r0 = size()
    //     0x827c08: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0x827c0c: add             SP, SP, #8
    // 0x827c10: mov             x1, x0
    // 0x827c14: ldur            x0, [fp, #-8]
    // 0x827c18: LoadField: r2 = r0->field_f
    //     0x827c18: ldur            w2, [x0, #0xf]
    // 0x827c1c: DecompressPointer r2
    //     0x827c1c: add             x2, x2, HEAP, lsl #32
    // 0x827c20: LoadField: r3 = r2->field_b
    //     0x827c20: ldur            w3, [x2, #0xb]
    // 0x827c24: DecompressPointer r3
    //     0x827c24: add             x3, x3, HEAP, lsl #32
    // 0x827c28: cmp             w3, NULL
    // 0x827c2c: b.eq            #0x827da0
    // 0x827c30: r16 = Instance_BoxFit
    //     0x827c30: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c2e0] Obj!BoxFit@b64e11
    //     0x827c34: ldr             x16, [x16, #0x2e0]
    // 0x827c38: stp             x1, x16, [SP, #-0x10]!
    // 0x827c3c: ldur            x16, [fp, #-0x18]
    // 0x827c40: SaveReg r16
    //     0x827c40: str             x16, [SP, #-8]!
    // 0x827c44: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x827c44: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x827c48: r0 = getDestinationRect()
    //     0x827c48: bl              #0x658e94  ; [package:extended_image/src/editor/editor_utils.dart] ::getDestinationRect
    // 0x827c4c: add             SP, SP, #0x18
    // 0x827c50: mov             x1, x0
    // 0x827c54: ldur            x0, [fp, #-8]
    // 0x827c58: stur            x1, [fp, #-0x18]
    // 0x827c5c: LoadField: r2 = r0->field_f
    //     0x827c5c: ldur            w2, [x0, #0xf]
    // 0x827c60: DecompressPointer r2
    //     0x827c60: add             x2, x2, HEAP, lsl #32
    // 0x827c64: LoadField: r3 = r2->field_b
    //     0x827c64: ldur            w3, [x2, #0xb]
    // 0x827c68: DecompressPointer r3
    //     0x827c68: add             x3, x3, HEAP, lsl #32
    // 0x827c6c: cmp             w3, NULL
    // 0x827c70: b.eq            #0x827da4
    // 0x827c74: LoadField: r2 = r3->field_b
    //     0x827c74: ldur            w2, [x3, #0xb]
    // 0x827c78: DecompressPointer r2
    //     0x827c78: add             x2, x2, HEAP, lsl #32
    // 0x827c7c: SaveReg r2
    //     0x827c7c: str             x2, [SP, #-8]!
    // 0x827c80: r0 = layoutTopLeft()
    //     0x827c80: bl              #0x6575dc  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::layoutTopLeft
    // 0x827c84: add             SP, SP, #8
    // 0x827c88: cmp             w0, NULL
    // 0x827c8c: b.eq            #0x827da8
    // 0x827c90: ldur            x16, [fp, #-0x18]
    // 0x827c94: stp             x0, x16, [SP, #-0x10]!
    // 0x827c98: r0 = shift()
    //     0x827c98: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x827c9c: add             SP, SP, #0x10
    // 0x827ca0: mov             x2, x0
    // 0x827ca4: ldur            x0, [fp, #-8]
    // 0x827ca8: stur            x2, [fp, #-0x28]
    // 0x827cac: LoadField: r3 = r0->field_f
    //     0x827cac: ldur            w3, [x0, #0xf]
    // 0x827cb0: DecompressPointer r3
    //     0x827cb0: add             x3, x3, HEAP, lsl #32
    // 0x827cb4: stur            x3, [fp, #-0x20]
    // 0x827cb8: LoadField: r4 = r3->field_27
    //     0x827cb8: ldur            w4, [x3, #0x27]
    // 0x827cbc: DecompressPointer r4
    //     0x827cbc: add             x4, x4, HEAP, lsl #32
    // 0x827cc0: r16 = Sentinel
    //     0x827cc0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x827cc4: cmp             w4, w16
    // 0x827cc8: b.eq            #0x827dac
    // 0x827ccc: stur            x4, [fp, #-0x18]
    // 0x827cd0: r1 = <Rect?>
    //     0x827cd0: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1ca20] TypeArguments: <Rect?>
    //     0x827cd4: ldr             x1, [x1, #0xa20]
    // 0x827cd8: r0 = RectTween()
    //     0x827cd8: bl              #0x827dd0  ; AllocateRectTweenStub -> RectTween (size=0x14)
    // 0x827cdc: mov             x1, x0
    // 0x827ce0: ldur            x0, [fp, #-0x10]
    // 0x827ce4: StoreField: r1->field_b = r0
    //     0x827ce4: stur            w0, [x1, #0xb]
    // 0x827ce8: ldur            x0, [fp, #-0x28]
    // 0x827cec: StoreField: r1->field_f = r0
    //     0x827cec: stur            w0, [x1, #0xf]
    // 0x827cf0: ldur            x16, [fp, #-0x18]
    // 0x827cf4: stp             x16, x1, [SP, #-0x10]!
    // 0x827cf8: r0 = animate()
    //     0x827cf8: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x827cfc: add             SP, SP, #0x10
    // 0x827d00: ldur            x1, [fp, #-0x20]
    // 0x827d04: StoreField: r1->field_23 = r0
    //     0x827d04: stur            w0, [x1, #0x23]
    //     0x827d08: ldurb           w16, [x1, #-1]
    //     0x827d0c: ldurb           w17, [x0, #-1]
    //     0x827d10: and             x16, x17, x16, lsr #2
    //     0x827d14: tst             x16, HEAP, lsr #32
    //     0x827d18: b.eq            #0x827d20
    //     0x827d1c: bl              #0xd6826c
    // 0x827d20: ldur            x0, [fp, #-8]
    // 0x827d24: LoadField: r1 = r0->field_f
    //     0x827d24: ldur            w1, [x0, #0xf]
    // 0x827d28: DecompressPointer r1
    //     0x827d28: add             x1, x1, HEAP, lsl #32
    // 0x827d2c: LoadField: r2 = r1->field_27
    //     0x827d2c: ldur            w2, [x1, #0x27]
    // 0x827d30: DecompressPointer r2
    //     0x827d30: add             x2, x2, HEAP, lsl #32
    // 0x827d34: r16 = Sentinel
    //     0x827d34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x827d38: cmp             w2, w16
    // 0x827d3c: b.eq            #0x827db8
    // 0x827d40: SaveReg r2
    //     0x827d40: str             x2, [SP, #-8]!
    // 0x827d44: r0 = reset()
    //     0x827d44: bl              #0x7974f0  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reset
    // 0x827d48: add             SP, SP, #8
    // 0x827d4c: ldur            x0, [fp, #-8]
    // 0x827d50: LoadField: r1 = r0->field_f
    //     0x827d50: ldur            w1, [x0, #0xf]
    // 0x827d54: DecompressPointer r1
    //     0x827d54: add             x1, x1, HEAP, lsl #32
    // 0x827d58: LoadField: r0 = r1->field_27
    //     0x827d58: ldur            w0, [x1, #0x27]
    // 0x827d5c: DecompressPointer r0
    //     0x827d5c: add             x0, x0, HEAP, lsl #32
    // 0x827d60: r16 = Sentinel
    //     0x827d60: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x827d64: cmp             w0, w16
    // 0x827d68: b.eq            #0x827dc4
    // 0x827d6c: SaveReg r0
    //     0x827d6c: str             x0, [SP, #-8]!
    // 0x827d70: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x827d70: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x827d74: r0 = forward()
    //     0x827d74: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x827d78: add             SP, SP, #8
    // 0x827d7c: r0 = Null
    //     0x827d7c: mov             x0, NULL
    // 0x827d80: LeaveFrame
    //     0x827d80: mov             SP, fp
    //     0x827d84: ldp             fp, lr, [SP], #0x10
    // 0x827d88: ret
    //     0x827d88: ret             
    // 0x827d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827d8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827d90: b               #0x827b4c
    // 0x827d94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827d94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827d98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827d98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827d9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827d9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827da0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827da0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827da4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827da4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x827da8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x827dac: r9 = _rectTweenController
    //     0x827dac: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c750] Field <ExtendedImageCropLayerState._rectTweenController@420005332>: late (offset: 0x28)
    //     0x827db0: ldr             x9, [x9, #0x750]
    // 0x827db4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x827db4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x827db8: r9 = _rectTweenController
    //     0x827db8: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c750] Field <ExtendedImageCropLayerState._rectTweenController@420005332>: late (offset: 0x28)
    //     0x827dbc: ldr             x9, [x9, #0x750]
    // 0x827dc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x827dc0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x827dc4: r9 = _rectTweenController
    //     0x827dc4: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c750] Field <ExtendedImageCropLayerState._rectTweenController@420005332>: late (offset: 0x28)
    //     0x827dc8: ldr             x9, [x9, #0x750]
    // 0x827dcc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x827dcc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x827ddc, size: 0x64
    // 0x827ddc: EnterFrame
    //     0x827ddc: stp             fp, lr, [SP, #-0x10]!
    //     0x827de0: mov             fp, SP
    // 0x827de4: ldr             x0, [fp, #0x18]
    // 0x827de8: LoadField: r1 = r0->field_17
    //     0x827de8: ldur            w1, [x0, #0x17]
    // 0x827dec: DecompressPointer r1
    //     0x827dec: add             x1, x1, HEAP, lsl #32
    // 0x827df0: CheckStackOverflow
    //     0x827df0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x827df4: cmp             SP, x16
    //     0x827df8: b.ls            #0x827e38
    // 0x827dfc: LoadField: r0 = r1->field_f
    //     0x827dfc: ldur            w0, [x1, #0xf]
    // 0x827e00: DecompressPointer r0
    //     0x827e00: add             x0, x0, HEAP, lsl #32
    // 0x827e04: ldr             x1, [fp, #0x10]
    // 0x827e08: LoadField: r2 = r1->field_b
    //     0x827e08: ldur            w2, [x1, #0xb]
    // 0x827e0c: DecompressPointer r2
    //     0x827e0c: add             x2, x2, HEAP, lsl #32
    // 0x827e10: r16 = Instance__MoveType
    //     0x827e10: add             x16, PP, #0x53, lsl #12  ; [pp+0x538a0] Obj!_MoveType@b661b1
    //     0x827e14: ldr             x16, [x16, #0x8a0]
    // 0x827e18: stp             x16, x0, [SP, #-0x10]!
    // 0x827e1c: SaveReg r2
    //     0x827e1c: str             x2, [SP, #-8]!
    // 0x827e20: r0 = moveUpdate()
    //     0x827e20: bl              #0x827e40  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::moveUpdate
    // 0x827e24: add             SP, SP, #0x18
    // 0x827e28: r0 = Null
    //     0x827e28: mov             x0, NULL
    // 0x827e2c: LeaveFrame
    //     0x827e2c: mov             SP, fp
    //     0x827e30: ldp             fp, lr, [SP], #0x10
    // 0x827e34: ret
    //     0x827e34: ret             
    // 0x827e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827e38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827e3c: b               #0x827dfc
  }
  _ moveUpdate(/* No info */) {
    // ** addr: 0x827e40, size: 0x11f4
    // 0x827e40: EnterFrame
    //     0x827e40: stp             fp, lr, [SP, #-0x10]!
    //     0x827e44: mov             fp, SP
    // 0x827e48: AllocStack(0x50)
    //     0x827e48: sub             SP, SP, #0x50
    // 0x827e4c: CheckStackOverflow
    //     0x827e4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x827e50: cmp             SP, x16
    //     0x827e54: b.ls            #0x828ef0
    // 0x827e58: r1 = 2
    //     0x827e58: mov             x1, #2
    // 0x827e5c: r0 = AllocateContext()
    //     0x827e5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x827e60: mov             x2, x0
    // 0x827e64: ldr             x1, [fp, #0x20]
    // 0x827e68: stur            x2, [fp, #-8]
    // 0x827e6c: StoreField: r2->field_f = r1
    //     0x827e6c: stur            w1, [x2, #0xf]
    // 0x827e70: LoadField: r0 = r1->field_27
    //     0x827e70: ldur            w0, [x1, #0x27]
    // 0x827e74: DecompressPointer r0
    //     0x827e74: add             x0, x0, HEAP, lsl #32
    // 0x827e78: r16 = Sentinel
    //     0x827e78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x827e7c: cmp             w0, w16
    // 0x827e80: b.eq            #0x828ef8
    // 0x827e84: LoadField: r3 = r0->field_2f
    //     0x827e84: ldur            w3, [x0, #0x2f]
    // 0x827e88: DecompressPointer r3
    //     0x827e88: add             x3, x3, HEAP, lsl #32
    // 0x827e8c: cmp             w3, NULL
    // 0x827e90: b.eq            #0x827eb4
    // 0x827e94: LoadField: r0 = r3->field_7
    //     0x827e94: ldur            w0, [x3, #7]
    // 0x827e98: DecompressPointer r0
    //     0x827e98: add             x0, x0, HEAP, lsl #32
    // 0x827e9c: cmp             w0, NULL
    // 0x827ea0: b.eq            #0x827eb4
    // 0x827ea4: r0 = Null
    //     0x827ea4: mov             x0, NULL
    // 0x827ea8: LeaveFrame
    //     0x827ea8: mov             SP, fp
    //     0x827eac: ldp             fp, lr, [SP], #0x10
    // 0x827eb0: ret
    //     0x827eb0: ret             
    // 0x827eb4: LoadField: r0 = r1->field_2b
    //     0x827eb4: ldur            w0, [x1, #0x2b]
    // 0x827eb8: DecompressPointer r0
    //     0x827eb8: add             x0, x0, HEAP, lsl #32
    // 0x827ebc: cmp             w0, NULL
    // 0x827ec0: b.eq            #0x827ee0
    // 0x827ec4: ldr             x3, [fp, #0x18]
    // 0x827ec8: cmp             w3, w0
    // 0x827ecc: b.eq            #0x827ee4
    // 0x827ed0: r0 = Null
    //     0x827ed0: mov             x0, NULL
    // 0x827ed4: LeaveFrame
    //     0x827ed4: mov             SP, fp
    //     0x827ed8: ldp             fp, lr, [SP], #0x10
    // 0x827edc: ret
    //     0x827edc: ret             
    // 0x827ee0: ldr             x3, [fp, #0x18]
    // 0x827ee4: mov             x0, x3
    // 0x827ee8: StoreField: r1->field_2b = r0
    //     0x827ee8: stur            w0, [x1, #0x2b]
    //     0x827eec: ldurb           w16, [x1, #-1]
    //     0x827ef0: ldurb           w17, [x0, #-1]
    //     0x827ef4: and             x16, x17, x16, lsr #2
    //     0x827ef8: tst             x16, HEAP, lsr #32
    //     0x827efc: b.eq            #0x827f04
    //     0x827f00: bl              #0xd6826c
    // 0x827f04: LoadField: r0 = r1->field_b
    //     0x827f04: ldur            w0, [x1, #0xb]
    // 0x827f08: DecompressPointer r0
    //     0x827f08: add             x0, x0, HEAP, lsl #32
    // 0x827f0c: cmp             w0, NULL
    // 0x827f10: b.eq            #0x828f04
    // 0x827f14: LoadField: r4 = r0->field_b
    //     0x827f14: ldur            w4, [x0, #0xb]
    // 0x827f18: DecompressPointer r4
    //     0x827f18: add             x4, x4, HEAP, lsl #32
    // 0x827f1c: SaveReg r4
    //     0x827f1c: str             x4, [SP, #-8]!
    // 0x827f20: r0 = layerDestinationRect()
    //     0x827f20: bl              #0x82a55c  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::layerDestinationRect
    // 0x827f24: add             SP, SP, #8
    // 0x827f28: mov             x2, x0
    // 0x827f2c: ldr             x1, [fp, #0x20]
    // 0x827f30: stur            x2, [fp, #-0x10]
    // 0x827f34: LoadField: r0 = r1->field_b
    //     0x827f34: ldur            w0, [x1, #0xb]
    // 0x827f38: DecompressPointer r0
    //     0x827f38: add             x0, x0, HEAP, lsl #32
    // 0x827f3c: cmp             w0, NULL
    // 0x827f40: b.eq            #0x828f08
    // 0x827f44: LoadField: r3 = r0->field_b
    //     0x827f44: ldur            w3, [x0, #0xb]
    // 0x827f48: DecompressPointer r3
    //     0x827f48: add             x3, x3, HEAP, lsl #32
    // 0x827f4c: LoadField: r4 = r3->field_4b
    //     0x827f4c: ldur            w4, [x3, #0x4b]
    // 0x827f50: DecompressPointer r4
    //     0x827f50: add             x4, x4, HEAP, lsl #32
    // 0x827f54: mov             x0, x4
    // 0x827f58: ldur            x3, [fp, #-8]
    // 0x827f5c: StoreField: r3->field_13 = r0
    //     0x827f5c: stur            w0, [x3, #0x13]
    //     0x827f60: ldurb           w16, [x3, #-1]
    //     0x827f64: ldurb           w17, [x0, #-1]
    //     0x827f68: and             x16, x17, x16, lsr #2
    //     0x827f6c: tst             x16, HEAP, lsr #32
    //     0x827f70: b.eq            #0x827f78
    //     0x827f74: bl              #0xd682ac
    // 0x827f78: r0 = Instance_Size
    //     0x827f78: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c788] Obj!Size@b5ec91
    //     0x827f7c: ldr             x0, [x0, #0x788]
    // 0x827f80: LoadField: d0 = r0->field_7
    //     0x827f80: ldur            d0, [x0, #7]
    // 0x827f84: ldr             x0, [fp, #0x18]
    // 0x827f88: stur            d0, [fp, #-0x40]
    // 0x827f8c: LoadField: r5 = r0->field_7
    //     0x827f8c: ldur            x5, [x0, #7]
    // 0x827f90: cmp             x5, #3
    // 0x827f94: b.gt            #0x828468
    // 0x827f98: cmp             x5, #1
    // 0x827f9c: b.gt            #0x8281f0
    // 0x827fa0: cmp             x5, #0
    // 0x827fa4: b.gt            #0x827fb8
    // 0x827fa8: mov             x2, x3
    // 0x827fac: d2 = 60.000000
    //     0x827fac: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x827fb0: ldr             d2, [x17, #0x8c8]
    // 0x827fb4: b               #0x828644
    // 0x827fb8: cmp             w4, NULL
    // 0x827fbc: b.eq            #0x828f0c
    // 0x827fc0: LoadField: d1 = r4->field_17
    //     0x827fc0: ldur            d1, [x4, #0x17]
    // 0x827fc4: stur            d1, [fp, #-0x38]
    // 0x827fc8: LoadField: d2 = r4->field_f
    //     0x827fc8: ldur            d2, [x4, #0xf]
    // 0x827fcc: stur            d2, [fp, #-0x30]
    // 0x827fd0: r0 = Offset()
    //     0x827fd0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x827fd4: ldur            d0, [fp, #-0x38]
    // 0x827fd8: StoreField: r0->field_7 = d0
    //     0x827fd8: stur            d0, [x0, #7]
    // 0x827fdc: ldur            d0, [fp, #-0x30]
    // 0x827fe0: StoreField: r0->field_f = d0
    //     0x827fe0: stur            d0, [x0, #0xf]
    // 0x827fe4: ldr             x16, [fp, #0x10]
    // 0x827fe8: stp             x16, x0, [SP, #-0x10]!
    // 0x827fec: r0 = +()
    //     0x827fec: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x827ff0: add             SP, SP, #0x10
    // 0x827ff4: LoadField: d0 = r0->field_7
    //     0x827ff4: ldur            d0, [x0, #7]
    // 0x827ff8: ldur            x2, [fp, #-8]
    // 0x827ffc: LoadField: r1 = r2->field_13
    //     0x827ffc: ldur            w1, [x2, #0x13]
    // 0x828000: DecompressPointer r1
    //     0x828000: add             x1, x1, HEAP, lsl #32
    // 0x828004: cmp             w1, NULL
    // 0x828008: b.eq            #0x828f10
    // 0x82800c: LoadField: d1 = r1->field_7
    //     0x82800c: ldur            d1, [x1, #7]
    // 0x828010: d2 = 60.000000
    //     0x828010: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x828014: ldr             d2, [x17, #0x8c8]
    // 0x828018: fadd            d3, d1, d2
    // 0x82801c: fcmp            d0, d3
    // 0x828020: b.vs            #0x828030
    // 0x828024: b.le            #0x828030
    // 0x828028: d1 = 0.000000
    //     0x828028: eor             v1.16b, v1.16b, v1.16b
    // 0x82802c: b               #0x828070
    // 0x828030: fcmp            d0, d3
    // 0x828034: b.vs            #0x828048
    // 0x828038: b.ge            #0x828048
    // 0x82803c: mov             v0.16b, v3.16b
    // 0x828040: d1 = 0.000000
    //     0x828040: eor             v1.16b, v1.16b, v1.16b
    // 0x828044: b               #0x828070
    // 0x828048: d1 = 0.000000
    //     0x828048: eor             v1.16b, v1.16b, v1.16b
    // 0x82804c: fcmp            d0, d1
    // 0x828050: b.vs            #0x828064
    // 0x828054: b.ne            #0x828064
    // 0x828058: fadd            d4, d0, d3
    // 0x82805c: mov             v0.16b, v4.16b
    // 0x828060: b               #0x828070
    // 0x828064: fcmp            d3, d3
    // 0x828068: b.vc            #0x828070
    // 0x82806c: mov             v0.16b, v3.16b
    // 0x828070: stur            d0, [fp, #-0x48]
    // 0x828074: LoadField: d3 = r0->field_f
    //     0x828074: ldur            d3, [x0, #0xf]
    // 0x828078: stur            d3, [fp, #-0x38]
    // 0x82807c: LoadField: d4 = r1->field_1f
    //     0x82807c: ldur            d4, [x1, #0x1f]
    // 0x828080: fsub            d5, d4, d2
    // 0x828084: stur            d5, [fp, #-0x30]
    // 0x828088: fcmp            d3, d5
    // 0x82808c: b.vs            #0x82809c
    // 0x828090: b.le            #0x82809c
    // 0x828094: mov             v1.16b, v5.16b
    // 0x828098: b               #0x82814c
    // 0x82809c: fcmp            d3, d5
    // 0x8280a0: b.vs            #0x8280b0
    // 0x8280a4: b.ge            #0x8280b0
    // 0x8280a8: mov             v1.16b, v3.16b
    // 0x8280ac: b               #0x82814c
    // 0x8280b0: fcmp            d3, d1
    // 0x8280b4: b.vs            #0x8280bc
    // 0x8280b8: b.eq            #0x8280c4
    // 0x8280bc: r0 = false
    //     0x8280bc: add             x0, NULL, #0x30  ; false
    // 0x8280c0: b               #0x8280c8
    // 0x8280c4: r0 = true
    //     0x8280c4: add             x0, NULL, #0x20  ; true
    // 0x8280c8: tbnz            w0, #4, #0x8280e0
    // 0x8280cc: fadd            d2, d3, d5
    // 0x8280d0: fmul            d4, d2, d3
    // 0x8280d4: fmul            d2, d4, d5
    // 0x8280d8: mov             v1.16b, v2.16b
    // 0x8280dc: b               #0x82814c
    // 0x8280e0: tbnz            w0, #4, #0x828124
    // 0x8280e4: r0 = inline_Allocate_Double()
    //     0x8280e4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8280e8: add             x0, x0, #0x10
    //     0x8280ec: cmp             x1, x0
    //     0x8280f0: b.ls            #0x828f14
    //     0x8280f4: str             x0, [THR, #0x60]  ; THR::top
    //     0x8280f8: sub             x0, x0, #0xf
    //     0x8280fc: mov             x1, #0xd108
    //     0x828100: movk            x1, #3, lsl #16
    //     0x828104: stur            x1, [x0, #-1]
    // 0x828108: StoreField: r0->field_7 = d5
    //     0x828108: stur            d5, [x0, #7]
    // 0x82810c: SaveReg r0
    //     0x82810c: str             x0, [SP, #-8]!
    // 0x828110: r0 = isNegative()
    //     0x828110: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x828114: add             SP, SP, #8
    // 0x828118: tbnz            w0, #4, #0x828124
    // 0x82811c: ldur            d0, [fp, #-0x30]
    // 0x828120: b               #0x828130
    // 0x828124: ldur            d0, [fp, #-0x30]
    // 0x828128: fcmp            d0, d0
    // 0x82812c: b.vc            #0x828140
    // 0x828130: mov             v1.16b, v0.16b
    // 0x828134: ldur            x2, [fp, #-8]
    // 0x828138: ldur            d0, [fp, #-0x48]
    // 0x82813c: b               #0x82814c
    // 0x828140: ldur            d1, [fp, #-0x38]
    // 0x828144: ldur            x2, [fp, #-8]
    // 0x828148: ldur            d0, [fp, #-0x48]
    // 0x82814c: stur            d1, [fp, #-0x30]
    // 0x828150: r0 = Offset()
    //     0x828150: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x828154: ldur            d0, [fp, #-0x48]
    // 0x828158: stur            x0, [fp, #-0x18]
    // 0x82815c: StoreField: r0->field_7 = d0
    //     0x82815c: stur            d0, [x0, #7]
    // 0x828160: ldur            d0, [fp, #-0x30]
    // 0x828164: StoreField: r0->field_f = d0
    //     0x828164: stur            d0, [x0, #0xf]
    // 0x828168: ldur            x2, [fp, #-8]
    // 0x82816c: LoadField: r1 = r2->field_13
    //     0x82816c: ldur            w1, [x2, #0x13]
    // 0x828170: DecompressPointer r1
    //     0x828170: add             x1, x1, HEAP, lsl #32
    // 0x828174: cmp             w1, NULL
    // 0x828178: b.eq            #0x828f34
    // 0x82817c: LoadField: d0 = r1->field_7
    //     0x82817c: ldur            d0, [x1, #7]
    // 0x828180: stur            d0, [fp, #-0x38]
    // 0x828184: LoadField: d1 = r1->field_1f
    //     0x828184: ldur            d1, [x1, #0x1f]
    // 0x828188: stur            d1, [fp, #-0x30]
    // 0x82818c: r0 = Offset()
    //     0x82818c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x828190: ldur            d0, [fp, #-0x38]
    // 0x828194: stur            x0, [fp, #-0x20]
    // 0x828198: StoreField: r0->field_7 = d0
    //     0x828198: stur            d0, [x0, #7]
    // 0x82819c: ldur            d0, [fp, #-0x30]
    // 0x8281a0: StoreField: r0->field_f = d0
    //     0x8281a0: stur            d0, [x0, #0xf]
    // 0x8281a4: r0 = Rect()
    //     0x8281a4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x8281a8: stur            x0, [fp, #-0x28]
    // 0x8281ac: ldur            x16, [fp, #-0x18]
    // 0x8281b0: stp             x16, x0, [SP, #-0x10]!
    // 0x8281b4: ldur            x16, [fp, #-0x20]
    // 0x8281b8: SaveReg r16
    //     0x8281b8: str             x16, [SP, #-8]!
    // 0x8281bc: r0 = Rect.fromPoints()
    //     0x8281bc: bl              #0x656aa4  ; [dart:ui] Rect::Rect.fromPoints
    // 0x8281c0: add             SP, SP, #0x18
    // 0x8281c4: ldur            x0, [fp, #-0x28]
    // 0x8281c8: ldur            x2, [fp, #-8]
    // 0x8281cc: StoreField: r2->field_13 = r0
    //     0x8281cc: stur            w0, [x2, #0x13]
    //     0x8281d0: ldurb           w16, [x2, #-1]
    //     0x8281d4: ldurb           w17, [x0, #-1]
    //     0x8281d8: and             x16, x17, x16, lsr #2
    //     0x8281dc: tst             x16, HEAP, lsr #32
    //     0x8281e0: b.eq            #0x8281e8
    //     0x8281e4: bl              #0xd6828c
    // 0x8281e8: ldur            x1, [fp, #-0x28]
    // 0x8281ec: b               #0x82893c
    // 0x8281f0: mov             x2, x3
    // 0x8281f4: d2 = 60.000000
    //     0x8281f4: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x8281f8: ldr             d2, [x17, #0x8c8]
    // 0x8281fc: cmp             x5, #2
    // 0x828200: b.gt            #0x82820c
    // 0x828204: mov             v0.16b, v2.16b
    // 0x828208: b               #0x828494
    // 0x82820c: cmp             w4, NULL
    // 0x828210: b.eq            #0x828f38
    // 0x828214: LoadField: d0 = r4->field_7
    //     0x828214: ldur            d0, [x4, #7]
    // 0x828218: stur            d0, [fp, #-0x38]
    // 0x82821c: LoadField: d1 = r4->field_1f
    //     0x82821c: ldur            d1, [x4, #0x1f]
    // 0x828220: stur            d1, [fp, #-0x30]
    // 0x828224: r0 = Offset()
    //     0x828224: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x828228: ldur            d0, [fp, #-0x38]
    // 0x82822c: StoreField: r0->field_7 = d0
    //     0x82822c: stur            d0, [x0, #7]
    // 0x828230: ldur            d0, [fp, #-0x30]
    // 0x828234: StoreField: r0->field_f = d0
    //     0x828234: stur            d0, [x0, #0xf]
    // 0x828238: ldr             x16, [fp, #0x10]
    // 0x82823c: stp             x16, x0, [SP, #-0x10]!
    // 0x828240: r0 = +()
    //     0x828240: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x828244: add             SP, SP, #0x10
    // 0x828248: stur            x0, [fp, #-0x18]
    // 0x82824c: LoadField: d0 = r0->field_7
    //     0x82824c: ldur            d0, [x0, #7]
    // 0x828250: ldur            x2, [fp, #-8]
    // 0x828254: stur            d0, [fp, #-0x38]
    // 0x828258: LoadField: r1 = r2->field_13
    //     0x828258: ldur            w1, [x2, #0x13]
    // 0x82825c: DecompressPointer r1
    //     0x82825c: add             x1, x1, HEAP, lsl #32
    // 0x828260: cmp             w1, NULL
    // 0x828264: b.eq            #0x828f3c
    // 0x828268: LoadField: d1 = r1->field_17
    //     0x828268: ldur            d1, [x1, #0x17]
    // 0x82826c: d2 = 60.000000
    //     0x82826c: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x828270: ldr             d2, [x17, #0x8c8]
    // 0x828274: fsub            d3, d1, d2
    // 0x828278: stur            d3, [fp, #-0x30]
    // 0x82827c: fcmp            d0, d3
    // 0x828280: b.vs            #0x828294
    // 0x828284: b.le            #0x828294
    // 0x828288: mov             v1.16b, v3.16b
    // 0x82828c: mov             v0.16b, v2.16b
    // 0x828290: b               #0x828360
    // 0x828294: fcmp            d0, d3
    // 0x828298: b.vs            #0x8282ac
    // 0x82829c: b.ge            #0x8282ac
    // 0x8282a0: mov             v1.16b, v0.16b
    // 0x8282a4: mov             v0.16b, v2.16b
    // 0x8282a8: b               #0x828360
    // 0x8282ac: d1 = 0.000000
    //     0x8282ac: eor             v1.16b, v1.16b, v1.16b
    // 0x8282b0: fcmp            d0, d1
    // 0x8282b4: b.vs            #0x8282bc
    // 0x8282b8: b.eq            #0x8282c4
    // 0x8282bc: r1 = false
    //     0x8282bc: add             x1, NULL, #0x30  ; false
    // 0x8282c0: b               #0x8282c8
    // 0x8282c4: r1 = true
    //     0x8282c4: add             x1, NULL, #0x20  ; true
    // 0x8282c8: tbnz            w1, #4, #0x8282e4
    // 0x8282cc: fadd            d4, d0, d3
    // 0x8282d0: fmul            d5, d4, d0
    // 0x8282d4: fmul            d0, d5, d3
    // 0x8282d8: mov             v1.16b, v0.16b
    // 0x8282dc: mov             v0.16b, v2.16b
    // 0x8282e0: b               #0x828360
    // 0x8282e4: tbnz            w1, #4, #0x828328
    // 0x8282e8: r1 = inline_Allocate_Double()
    //     0x8282e8: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x8282ec: add             x1, x1, #0x10
    //     0x8282f0: cmp             x3, x1
    //     0x8282f4: b.ls            #0x828f40
    //     0x8282f8: str             x1, [THR, #0x60]  ; THR::top
    //     0x8282fc: sub             x1, x1, #0xf
    //     0x828300: mov             x3, #0xd108
    //     0x828304: movk            x3, #3, lsl #16
    //     0x828308: stur            x3, [x1, #-1]
    // 0x82830c: StoreField: r1->field_7 = d3
    //     0x82830c: stur            d3, [x1, #7]
    // 0x828310: SaveReg r1
    //     0x828310: str             x1, [SP, #-8]!
    // 0x828314: r0 = isNegative()
    //     0x828314: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x828318: add             SP, SP, #8
    // 0x82831c: tbnz            w0, #4, #0x828328
    // 0x828320: ldur            d0, [fp, #-0x30]
    // 0x828324: b               #0x828334
    // 0x828328: ldur            d0, [fp, #-0x30]
    // 0x82832c: fcmp            d0, d0
    // 0x828330: b.vc            #0x82834c
    // 0x828334: mov             v1.16b, v0.16b
    // 0x828338: ldur            x2, [fp, #-8]
    // 0x82833c: ldur            x0, [fp, #-0x18]
    // 0x828340: d0 = 60.000000
    //     0x828340: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x828344: ldr             d0, [x17, #0x8c8]
    // 0x828348: b               #0x828360
    // 0x82834c: ldur            d1, [fp, #-0x38]
    // 0x828350: ldur            x2, [fp, #-8]
    // 0x828354: ldur            x0, [fp, #-0x18]
    // 0x828358: d0 = 60.000000
    //     0x828358: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x82835c: ldr             d0, [x17, #0x8c8]
    // 0x828360: stur            d1, [fp, #-0x48]
    // 0x828364: LoadField: d2 = r0->field_f
    //     0x828364: ldur            d2, [x0, #0xf]
    // 0x828368: LoadField: r0 = r2->field_13
    //     0x828368: ldur            w0, [x2, #0x13]
    // 0x82836c: DecompressPointer r0
    //     0x82836c: add             x0, x0, HEAP, lsl #32
    // 0x828370: stur            x0, [fp, #-0x18]
    // 0x828374: cmp             w0, NULL
    // 0x828378: b.eq            #0x828f64
    // 0x82837c: LoadField: d3 = r0->field_f
    //     0x82837c: ldur            d3, [x0, #0xf]
    // 0x828380: stur            d3, [fp, #-0x38]
    // 0x828384: fadd            d4, d3, d0
    // 0x828388: fcmp            d2, d4
    // 0x82838c: b.vs            #0x82839c
    // 0x828390: b.le            #0x82839c
    // 0x828394: d0 = 0.000000
    //     0x828394: eor             v0.16b, v0.16b, v0.16b
    // 0x828398: b               #0x8283dc
    // 0x82839c: fcmp            d2, d4
    // 0x8283a0: b.vs            #0x8283b4
    // 0x8283a4: b.ge            #0x8283b4
    // 0x8283a8: mov             v2.16b, v4.16b
    // 0x8283ac: d0 = 0.000000
    //     0x8283ac: eor             v0.16b, v0.16b, v0.16b
    // 0x8283b0: b               #0x8283dc
    // 0x8283b4: d0 = 0.000000
    //     0x8283b4: eor             v0.16b, v0.16b, v0.16b
    // 0x8283b8: fcmp            d2, d0
    // 0x8283bc: b.vs            #0x8283d0
    // 0x8283c0: b.ne            #0x8283d0
    // 0x8283c4: fadd            d5, d2, d4
    // 0x8283c8: mov             v2.16b, v5.16b
    // 0x8283cc: b               #0x8283dc
    // 0x8283d0: fcmp            d4, d4
    // 0x8283d4: b.vc            #0x8283dc
    // 0x8283d8: mov             v2.16b, v4.16b
    // 0x8283dc: stur            d2, [fp, #-0x30]
    // 0x8283e0: r0 = Offset()
    //     0x8283e0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8283e4: ldur            d0, [fp, #-0x48]
    // 0x8283e8: stur            x0, [fp, #-0x20]
    // 0x8283ec: StoreField: r0->field_7 = d0
    //     0x8283ec: stur            d0, [x0, #7]
    // 0x8283f0: ldur            d0, [fp, #-0x30]
    // 0x8283f4: StoreField: r0->field_f = d0
    //     0x8283f4: stur            d0, [x0, #0xf]
    // 0x8283f8: ldur            x1, [fp, #-0x18]
    // 0x8283fc: LoadField: d0 = r1->field_17
    //     0x8283fc: ldur            d0, [x1, #0x17]
    // 0x828400: stur            d0, [fp, #-0x30]
    // 0x828404: r0 = Offset()
    //     0x828404: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x828408: ldur            d0, [fp, #-0x30]
    // 0x82840c: stur            x0, [fp, #-0x18]
    // 0x828410: StoreField: r0->field_7 = d0
    //     0x828410: stur            d0, [x0, #7]
    // 0x828414: ldur            d0, [fp, #-0x38]
    // 0x828418: StoreField: r0->field_f = d0
    //     0x828418: stur            d0, [x0, #0xf]
    // 0x82841c: r0 = Rect()
    //     0x82841c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x828420: stur            x0, [fp, #-0x28]
    // 0x828424: ldur            x16, [fp, #-0x20]
    // 0x828428: stp             x16, x0, [SP, #-0x10]!
    // 0x82842c: ldur            x16, [fp, #-0x18]
    // 0x828430: SaveReg r16
    //     0x828430: str             x16, [SP, #-8]!
    // 0x828434: r0 = Rect.fromPoints()
    //     0x828434: bl              #0x656aa4  ; [dart:ui] Rect::Rect.fromPoints
    // 0x828438: add             SP, SP, #0x18
    // 0x82843c: ldur            x0, [fp, #-0x28]
    // 0x828440: ldur            x2, [fp, #-8]
    // 0x828444: StoreField: r2->field_13 = r0
    //     0x828444: stur            w0, [x2, #0x13]
    //     0x828448: ldurb           w16, [x2, #-1]
    //     0x82844c: ldurb           w17, [x0, #-1]
    //     0x828450: and             x16, x17, x16, lsr #2
    //     0x828454: tst             x16, HEAP, lsr #32
    //     0x828458: b.eq            #0x828460
    //     0x82845c: bl              #0xd6828c
    // 0x828460: ldur            x1, [fp, #-0x28]
    // 0x828464: b               #0x82893c
    // 0x828468: mov             x2, x3
    // 0x82846c: d0 = 60.000000
    //     0x82846c: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x828470: ldr             d0, [x17, #0x8c8]
    // 0x828474: cmp             x5, #5
    // 0x828478: b.gt            #0x82848c
    // 0x82847c: cmp             x5, #4
    // 0x828480: b.gt            #0x828494
    // 0x828484: mov             v2.16b, v0.16b
    // 0x828488: b               #0x828644
    // 0x82848c: cmp             x5, #6
    // 0x828490: b.gt            #0x828634
    // 0x828494: cmp             w4, NULL
    // 0x828498: b.eq            #0x828f68
    // 0x82849c: LoadField: d1 = r4->field_17
    //     0x82849c: ldur            d1, [x4, #0x17]
    // 0x8284a0: stur            d1, [fp, #-0x38]
    // 0x8284a4: LoadField: d2 = r4->field_1f
    //     0x8284a4: ldur            d2, [x4, #0x1f]
    // 0x8284a8: stur            d2, [fp, #-0x30]
    // 0x8284ac: r0 = Offset()
    //     0x8284ac: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8284b0: ldur            d0, [fp, #-0x38]
    // 0x8284b4: StoreField: r0->field_7 = d0
    //     0x8284b4: stur            d0, [x0, #7]
    // 0x8284b8: ldur            d0, [fp, #-0x30]
    // 0x8284bc: StoreField: r0->field_f = d0
    //     0x8284bc: stur            d0, [x0, #0xf]
    // 0x8284c0: ldr             x16, [fp, #0x10]
    // 0x8284c4: stp             x16, x0, [SP, #-0x10]!
    // 0x8284c8: r0 = +()
    //     0x8284c8: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x8284cc: add             SP, SP, #0x10
    // 0x8284d0: LoadField: d0 = r0->field_7
    //     0x8284d0: ldur            d0, [x0, #7]
    // 0x8284d4: ldur            x2, [fp, #-8]
    // 0x8284d8: LoadField: r1 = r2->field_13
    //     0x8284d8: ldur            w1, [x2, #0x13]
    // 0x8284dc: DecompressPointer r1
    //     0x8284dc: add             x1, x1, HEAP, lsl #32
    // 0x8284e0: cmp             w1, NULL
    // 0x8284e4: b.eq            #0x828f6c
    // 0x8284e8: LoadField: d1 = r1->field_7
    //     0x8284e8: ldur            d1, [x1, #7]
    // 0x8284ec: stur            d1, [fp, #-0x50]
    // 0x8284f0: d2 = 60.000000
    //     0x8284f0: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x8284f4: ldr             d2, [x17, #0x8c8]
    // 0x8284f8: fadd            d3, d1, d2
    // 0x8284fc: fcmp            d0, d3
    // 0x828500: b.vs            #0x828510
    // 0x828504: b.le            #0x828510
    // 0x828508: d4 = 0.000000
    //     0x828508: eor             v4.16b, v4.16b, v4.16b
    // 0x82850c: b               #0x828550
    // 0x828510: fcmp            d0, d3
    // 0x828514: b.vs            #0x828528
    // 0x828518: b.ge            #0x828528
    // 0x82851c: mov             v0.16b, v3.16b
    // 0x828520: d4 = 0.000000
    //     0x828520: eor             v4.16b, v4.16b, v4.16b
    // 0x828524: b               #0x828550
    // 0x828528: d4 = 0.000000
    //     0x828528: eor             v4.16b, v4.16b, v4.16b
    // 0x82852c: fcmp            d0, d4
    // 0x828530: b.vs            #0x828544
    // 0x828534: b.ne            #0x828544
    // 0x828538: fadd            d5, d0, d3
    // 0x82853c: mov             v0.16b, v5.16b
    // 0x828540: b               #0x828550
    // 0x828544: fcmp            d3, d3
    // 0x828548: b.vc            #0x828550
    // 0x82854c: mov             v0.16b, v3.16b
    // 0x828550: stur            d0, [fp, #-0x48]
    // 0x828554: LoadField: d3 = r0->field_f
    //     0x828554: ldur            d3, [x0, #0xf]
    // 0x828558: LoadField: d5 = r1->field_f
    //     0x828558: ldur            d5, [x1, #0xf]
    // 0x82855c: stur            d5, [fp, #-0x38]
    // 0x828560: fadd            d6, d5, d2
    // 0x828564: fcmp            d3, d6
    // 0x828568: b.vs            #0x828578
    // 0x82856c: b.le            #0x828578
    // 0x828570: mov             v2.16b, v3.16b
    // 0x828574: b               #0x8285b4
    // 0x828578: fcmp            d3, d6
    // 0x82857c: b.vs            #0x82858c
    // 0x828580: b.ge            #0x82858c
    // 0x828584: mov             v2.16b, v6.16b
    // 0x828588: b               #0x8285b4
    // 0x82858c: fcmp            d3, d4
    // 0x828590: b.vs            #0x8285a0
    // 0x828594: b.ne            #0x8285a0
    // 0x828598: fadd            d2, d3, d6
    // 0x82859c: b               #0x8285b4
    // 0x8285a0: fcmp            d6, d6
    // 0x8285a4: b.vc            #0x8285b0
    // 0x8285a8: mov             v2.16b, v6.16b
    // 0x8285ac: b               #0x8285b4
    // 0x8285b0: mov             v2.16b, v3.16b
    // 0x8285b4: stur            d2, [fp, #-0x30]
    // 0x8285b8: r0 = Offset()
    //     0x8285b8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8285bc: ldur            d0, [fp, #-0x48]
    // 0x8285c0: stur            x0, [fp, #-0x18]
    // 0x8285c4: StoreField: r0->field_7 = d0
    //     0x8285c4: stur            d0, [x0, #7]
    // 0x8285c8: ldur            d0, [fp, #-0x30]
    // 0x8285cc: StoreField: r0->field_f = d0
    //     0x8285cc: stur            d0, [x0, #0xf]
    // 0x8285d0: r0 = Offset()
    //     0x8285d0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8285d4: ldur            d0, [fp, #-0x50]
    // 0x8285d8: stur            x0, [fp, #-0x20]
    // 0x8285dc: StoreField: r0->field_7 = d0
    //     0x8285dc: stur            d0, [x0, #7]
    // 0x8285e0: ldur            d0, [fp, #-0x38]
    // 0x8285e4: StoreField: r0->field_f = d0
    //     0x8285e4: stur            d0, [x0, #0xf]
    // 0x8285e8: r0 = Rect()
    //     0x8285e8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x8285ec: stur            x0, [fp, #-0x28]
    // 0x8285f0: ldur            x16, [fp, #-0x20]
    // 0x8285f4: stp             x16, x0, [SP, #-0x10]!
    // 0x8285f8: ldur            x16, [fp, #-0x18]
    // 0x8285fc: SaveReg r16
    //     0x8285fc: str             x16, [SP, #-8]!
    // 0x828600: r0 = Rect.fromPoints()
    //     0x828600: bl              #0x656aa4  ; [dart:ui] Rect::Rect.fromPoints
    // 0x828604: add             SP, SP, #0x18
    // 0x828608: ldur            x0, [fp, #-0x28]
    // 0x82860c: ldur            x2, [fp, #-8]
    // 0x828610: StoreField: r2->field_13 = r0
    //     0x828610: stur            w0, [x2, #0x13]
    //     0x828614: ldurb           w16, [x2, #-1]
    //     0x828618: ldurb           w17, [x0, #-1]
    //     0x82861c: and             x16, x17, x16, lsr #2
    //     0x828620: tst             x16, HEAP, lsr #32
    //     0x828624: b.eq            #0x82862c
    //     0x828628: bl              #0xd6828c
    // 0x82862c: ldur            x1, [fp, #-0x28]
    // 0x828630: b               #0x82893c
    // 0x828634: mov             v2.16b, v0.16b
    // 0x828638: lsl             x0, x5, #1
    // 0x82863c: cmp             w0, #0xe
    // 0x828640: b.ne            #0x828938
    // 0x828644: cmp             w4, NULL
    // 0x828648: b.eq            #0x828f70
    // 0x82864c: LoadField: d0 = r4->field_7
    //     0x82864c: ldur            d0, [x4, #7]
    // 0x828650: stur            d0, [fp, #-0x38]
    // 0x828654: LoadField: d1 = r4->field_f
    //     0x828654: ldur            d1, [x4, #0xf]
    // 0x828658: stur            d1, [fp, #-0x30]
    // 0x82865c: r0 = Offset()
    //     0x82865c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x828660: ldur            d0, [fp, #-0x38]
    // 0x828664: StoreField: r0->field_7 = d0
    //     0x828664: stur            d0, [x0, #7]
    // 0x828668: ldur            d0, [fp, #-0x30]
    // 0x82866c: StoreField: r0->field_f = d0
    //     0x82866c: stur            d0, [x0, #0xf]
    // 0x828670: ldr             x16, [fp, #0x10]
    // 0x828674: stp             x16, x0, [SP, #-0x10]!
    // 0x828678: r0 = +()
    //     0x828678: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x82867c: add             SP, SP, #0x10
    // 0x828680: stur            x0, [fp, #-0x18]
    // 0x828684: LoadField: d0 = r0->field_7
    //     0x828684: ldur            d0, [x0, #7]
    // 0x828688: ldur            x2, [fp, #-8]
    // 0x82868c: stur            d0, [fp, #-0x38]
    // 0x828690: LoadField: r1 = r2->field_13
    //     0x828690: ldur            w1, [x2, #0x13]
    // 0x828694: DecompressPointer r1
    //     0x828694: add             x1, x1, HEAP, lsl #32
    // 0x828698: cmp             w1, NULL
    // 0x82869c: b.eq            #0x828f74
    // 0x8286a0: LoadField: d1 = r1->field_17
    //     0x8286a0: ldur            d1, [x1, #0x17]
    // 0x8286a4: d2 = 60.000000
    //     0x8286a4: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x8286a8: ldr             d2, [x17, #0x8c8]
    // 0x8286ac: fsub            d3, d1, d2
    // 0x8286b0: stur            d3, [fp, #-0x30]
    // 0x8286b4: fcmp            d0, d3
    // 0x8286b8: b.vs            #0x8286cc
    // 0x8286bc: b.le            #0x8286cc
    // 0x8286c0: mov             v1.16b, v3.16b
    // 0x8286c4: mov             v0.16b, v2.16b
    // 0x8286c8: b               #0x828798
    // 0x8286cc: fcmp            d0, d3
    // 0x8286d0: b.vs            #0x8286e4
    // 0x8286d4: b.ge            #0x8286e4
    // 0x8286d8: mov             v1.16b, v0.16b
    // 0x8286dc: mov             v0.16b, v2.16b
    // 0x8286e0: b               #0x828798
    // 0x8286e4: d1 = 0.000000
    //     0x8286e4: eor             v1.16b, v1.16b, v1.16b
    // 0x8286e8: fcmp            d0, d1
    // 0x8286ec: b.vs            #0x8286f4
    // 0x8286f0: b.eq            #0x8286fc
    // 0x8286f4: r1 = false
    //     0x8286f4: add             x1, NULL, #0x30  ; false
    // 0x8286f8: b               #0x828700
    // 0x8286fc: r1 = true
    //     0x8286fc: add             x1, NULL, #0x20  ; true
    // 0x828700: tbnz            w1, #4, #0x82871c
    // 0x828704: fadd            d4, d0, d3
    // 0x828708: fmul            d5, d4, d0
    // 0x82870c: fmul            d0, d5, d3
    // 0x828710: mov             v1.16b, v0.16b
    // 0x828714: mov             v0.16b, v2.16b
    // 0x828718: b               #0x828798
    // 0x82871c: tbnz            w1, #4, #0x828760
    // 0x828720: r1 = inline_Allocate_Double()
    //     0x828720: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x828724: add             x1, x1, #0x10
    //     0x828728: cmp             x3, x1
    //     0x82872c: b.ls            #0x828f78
    //     0x828730: str             x1, [THR, #0x60]  ; THR::top
    //     0x828734: sub             x1, x1, #0xf
    //     0x828738: mov             x3, #0xd108
    //     0x82873c: movk            x3, #3, lsl #16
    //     0x828740: stur            x3, [x1, #-1]
    // 0x828744: StoreField: r1->field_7 = d3
    //     0x828744: stur            d3, [x1, #7]
    // 0x828748: SaveReg r1
    //     0x828748: str             x1, [SP, #-8]!
    // 0x82874c: r0 = isNegative()
    //     0x82874c: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x828750: add             SP, SP, #8
    // 0x828754: tbnz            w0, #4, #0x828760
    // 0x828758: ldur            d0, [fp, #-0x30]
    // 0x82875c: b               #0x82876c
    // 0x828760: ldur            d0, [fp, #-0x30]
    // 0x828764: fcmp            d0, d0
    // 0x828768: b.vc            #0x828784
    // 0x82876c: mov             v1.16b, v0.16b
    // 0x828770: ldur            x2, [fp, #-8]
    // 0x828774: ldur            x0, [fp, #-0x18]
    // 0x828778: d0 = 60.000000
    //     0x828778: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x82877c: ldr             d0, [x17, #0x8c8]
    // 0x828780: b               #0x828798
    // 0x828784: ldur            d1, [fp, #-0x38]
    // 0x828788: ldur            x2, [fp, #-8]
    // 0x82878c: ldur            x0, [fp, #-0x18]
    // 0x828790: d0 = 60.000000
    //     0x828790: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x828794: ldr             d0, [x17, #0x8c8]
    // 0x828798: stur            d1, [fp, #-0x48]
    // 0x82879c: LoadField: d2 = r0->field_f
    //     0x82879c: ldur            d2, [x0, #0xf]
    // 0x8287a0: stur            d2, [fp, #-0x38]
    // 0x8287a4: LoadField: r0 = r2->field_13
    //     0x8287a4: ldur            w0, [x2, #0x13]
    // 0x8287a8: DecompressPointer r0
    //     0x8287a8: add             x0, x0, HEAP, lsl #32
    // 0x8287ac: cmp             w0, NULL
    // 0x8287b0: b.eq            #0x828f9c
    // 0x8287b4: LoadField: d3 = r0->field_1f
    //     0x8287b4: ldur            d3, [x0, #0x1f]
    // 0x8287b8: fsub            d4, d3, d0
    // 0x8287bc: stur            d4, [fp, #-0x30]
    // 0x8287c0: fcmp            d2, d4
    // 0x8287c4: b.vs            #0x8287d8
    // 0x8287c8: b.le            #0x8287d8
    // 0x8287cc: mov             v0.16b, v1.16b
    // 0x8287d0: mov             v1.16b, v4.16b
    // 0x8287d4: b               #0x828894
    // 0x8287d8: fcmp            d2, d4
    // 0x8287dc: b.vs            #0x8287f0
    // 0x8287e0: b.ge            #0x8287f0
    // 0x8287e4: mov             v0.16b, v1.16b
    // 0x8287e8: mov             v1.16b, v2.16b
    // 0x8287ec: b               #0x828894
    // 0x8287f0: d0 = 0.000000
    //     0x8287f0: eor             v0.16b, v0.16b, v0.16b
    // 0x8287f4: fcmp            d2, d0
    // 0x8287f8: b.vs            #0x828800
    // 0x8287fc: b.eq            #0x828808
    // 0x828800: r0 = false
    //     0x828800: add             x0, NULL, #0x30  ; false
    // 0x828804: b               #0x82880c
    // 0x828808: r0 = true
    //     0x828808: add             x0, NULL, #0x20  ; true
    // 0x82880c: tbnz            w0, #4, #0x828828
    // 0x828810: fadd            d3, d2, d4
    // 0x828814: fmul            d5, d3, d2
    // 0x828818: fmul            d2, d5, d4
    // 0x82881c: mov             v0.16b, v1.16b
    // 0x828820: mov             v1.16b, v2.16b
    // 0x828824: b               #0x828894
    // 0x828828: tbnz            w0, #4, #0x82886c
    // 0x82882c: r0 = inline_Allocate_Double()
    //     0x82882c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x828830: add             x0, x0, #0x10
    //     0x828834: cmp             x1, x0
    //     0x828838: b.ls            #0x828fa0
    //     0x82883c: str             x0, [THR, #0x60]  ; THR::top
    //     0x828840: sub             x0, x0, #0xf
    //     0x828844: mov             x1, #0xd108
    //     0x828848: movk            x1, #3, lsl #16
    //     0x82884c: stur            x1, [x0, #-1]
    // 0x828850: StoreField: r0->field_7 = d4
    //     0x828850: stur            d4, [x0, #7]
    // 0x828854: SaveReg r0
    //     0x828854: str             x0, [SP, #-8]!
    // 0x828858: r0 = isNegative()
    //     0x828858: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x82885c: add             SP, SP, #8
    // 0x828860: tbnz            w0, #4, #0x82886c
    // 0x828864: ldur            d0, [fp, #-0x30]
    // 0x828868: b               #0x828878
    // 0x82886c: ldur            d0, [fp, #-0x30]
    // 0x828870: fcmp            d0, d0
    // 0x828874: b.vc            #0x828888
    // 0x828878: mov             v1.16b, v0.16b
    // 0x82887c: ldur            x2, [fp, #-8]
    // 0x828880: ldur            d0, [fp, #-0x48]
    // 0x828884: b               #0x828894
    // 0x828888: ldur            d1, [fp, #-0x38]
    // 0x82888c: ldur            x2, [fp, #-8]
    // 0x828890: ldur            d0, [fp, #-0x48]
    // 0x828894: stur            d1, [fp, #-0x30]
    // 0x828898: r0 = Offset()
    //     0x828898: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x82889c: ldur            d0, [fp, #-0x48]
    // 0x8288a0: stur            x0, [fp, #-0x18]
    // 0x8288a4: StoreField: r0->field_7 = d0
    //     0x8288a4: stur            d0, [x0, #7]
    // 0x8288a8: ldur            d0, [fp, #-0x30]
    // 0x8288ac: StoreField: r0->field_f = d0
    //     0x8288ac: stur            d0, [x0, #0xf]
    // 0x8288b0: ldur            x2, [fp, #-8]
    // 0x8288b4: LoadField: r1 = r2->field_13
    //     0x8288b4: ldur            w1, [x2, #0x13]
    // 0x8288b8: DecompressPointer r1
    //     0x8288b8: add             x1, x1, HEAP, lsl #32
    // 0x8288bc: cmp             w1, NULL
    // 0x8288c0: b.eq            #0x828fc0
    // 0x8288c4: LoadField: d0 = r1->field_17
    //     0x8288c4: ldur            d0, [x1, #0x17]
    // 0x8288c8: stur            d0, [fp, #-0x38]
    // 0x8288cc: LoadField: d1 = r1->field_1f
    //     0x8288cc: ldur            d1, [x1, #0x1f]
    // 0x8288d0: stur            d1, [fp, #-0x30]
    // 0x8288d4: r0 = Offset()
    //     0x8288d4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8288d8: ldur            d0, [fp, #-0x38]
    // 0x8288dc: stur            x0, [fp, #-0x20]
    // 0x8288e0: StoreField: r0->field_7 = d0
    //     0x8288e0: stur            d0, [x0, #7]
    // 0x8288e4: ldur            d0, [fp, #-0x30]
    // 0x8288e8: StoreField: r0->field_f = d0
    //     0x8288e8: stur            d0, [x0, #0xf]
    // 0x8288ec: r0 = Rect()
    //     0x8288ec: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x8288f0: stur            x0, [fp, #-0x28]
    // 0x8288f4: ldur            x16, [fp, #-0x18]
    // 0x8288f8: stp             x16, x0, [SP, #-0x10]!
    // 0x8288fc: ldur            x16, [fp, #-0x20]
    // 0x828900: SaveReg r16
    //     0x828900: str             x16, [SP, #-8]!
    // 0x828904: r0 = Rect.fromPoints()
    //     0x828904: bl              #0x656aa4  ; [dart:ui] Rect::Rect.fromPoints
    // 0x828908: add             SP, SP, #0x18
    // 0x82890c: ldur            x0, [fp, #-0x28]
    // 0x828910: ldur            x2, [fp, #-8]
    // 0x828914: StoreField: r2->field_13 = r0
    //     0x828914: stur            w0, [x2, #0x13]
    //     0x828918: ldurb           w16, [x2, #-1]
    //     0x82891c: ldurb           w17, [x0, #-1]
    //     0x828920: and             x16, x17, x16, lsr #2
    //     0x828924: tst             x16, HEAP, lsr #32
    //     0x828928: b.eq            #0x828930
    //     0x82892c: bl              #0xd6828c
    // 0x828930: ldur            x1, [fp, #-0x28]
    // 0x828934: b               #0x82893c
    // 0x828938: mov             x1, x4
    // 0x82893c: ldur            x0, [fp, #-0x10]
    // 0x828940: stur            x1, [fp, #-0x18]
    // 0x828944: cmp             w1, NULL
    // 0x828948: b.eq            #0x828fc4
    // 0x82894c: LoadField: d0 = r1->field_7
    //     0x82894c: ldur            d0, [x1, #7]
    // 0x828950: cmp             w0, NULL
    // 0x828954: b.eq            #0x828fc8
    // 0x828958: LoadField: d1 = r0->field_7
    //     0x828958: ldur            d1, [x0, #7]
    // 0x82895c: fcmp            d0, d1
    // 0x828960: b.vs            #0x828970
    // 0x828964: b.le            #0x828970
    // 0x828968: d2 = 0.000000
    //     0x828968: eor             v2.16b, v2.16b, v2.16b
    // 0x82896c: b               #0x8289b0
    // 0x828970: fcmp            d0, d1
    // 0x828974: b.vs            #0x828988
    // 0x828978: b.ge            #0x828988
    // 0x82897c: mov             v0.16b, v1.16b
    // 0x828980: d2 = 0.000000
    //     0x828980: eor             v2.16b, v2.16b, v2.16b
    // 0x828984: b               #0x8289b0
    // 0x828988: d2 = 0.000000
    //     0x828988: eor             v2.16b, v2.16b, v2.16b
    // 0x82898c: fcmp            d0, d2
    // 0x828990: b.vs            #0x8289a4
    // 0x828994: b.ne            #0x8289a4
    // 0x828998: fadd            d3, d0, d1
    // 0x82899c: mov             v0.16b, v3.16b
    // 0x8289a0: b               #0x8289b0
    // 0x8289a4: fcmp            d1, d1
    // 0x8289a8: b.vc            #0x8289b0
    // 0x8289ac: mov             v0.16b, v1.16b
    // 0x8289b0: stur            d0, [fp, #-0x38]
    // 0x8289b4: LoadField: d1 = r1->field_f
    //     0x8289b4: ldur            d1, [x1, #0xf]
    // 0x8289b8: LoadField: d3 = r0->field_f
    //     0x8289b8: ldur            d3, [x0, #0xf]
    // 0x8289bc: fcmp            d1, d3
    // 0x8289c0: b.vs            #0x8289c8
    // 0x8289c4: b.gt            #0x828a00
    // 0x8289c8: fcmp            d1, d3
    // 0x8289cc: b.vs            #0x8289dc
    // 0x8289d0: b.ge            #0x8289dc
    // 0x8289d4: mov             v1.16b, v3.16b
    // 0x8289d8: b               #0x828a00
    // 0x8289dc: fcmp            d1, d2
    // 0x8289e0: b.vs            #0x8289f4
    // 0x8289e4: b.ne            #0x8289f4
    // 0x8289e8: fadd            d4, d1, d3
    // 0x8289ec: mov             v1.16b, v4.16b
    // 0x8289f0: b               #0x828a00
    // 0x8289f4: fcmp            d3, d3
    // 0x8289f8: b.vc            #0x828a00
    // 0x8289fc: mov             v1.16b, v3.16b
    // 0x828a00: stur            d1, [fp, #-0x30]
    // 0x828a04: r0 = Offset()
    //     0x828a04: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x828a08: ldur            d0, [fp, #-0x38]
    // 0x828a0c: stur            x0, [fp, #-0x20]
    // 0x828a10: StoreField: r0->field_7 = d0
    //     0x828a10: stur            d0, [x0, #7]
    // 0x828a14: ldur            d0, [fp, #-0x30]
    // 0x828a18: StoreField: r0->field_f = d0
    //     0x828a18: stur            d0, [x0, #0xf]
    // 0x828a1c: ldur            x1, [fp, #-0x18]
    // 0x828a20: LoadField: d0 = r1->field_17
    //     0x828a20: ldur            d0, [x1, #0x17]
    // 0x828a24: ldur            x1, [fp, #-0x10]
    // 0x828a28: stur            d0, [fp, #-0x38]
    // 0x828a2c: LoadField: d1 = r1->field_17
    //     0x828a2c: ldur            d1, [x1, #0x17]
    // 0x828a30: stur            d1, [fp, #-0x30]
    // 0x828a34: fcmp            d0, d1
    // 0x828a38: b.vs            #0x828a4c
    // 0x828a3c: b.le            #0x828a4c
    // 0x828a40: mov             v0.16b, v1.16b
    // 0x828a44: mov             x0, x1
    // 0x828a48: b               #0x828af4
    // 0x828a4c: fcmp            d0, d1
    // 0x828a50: b.vs            #0x828a60
    // 0x828a54: b.ge            #0x828a60
    // 0x828a58: mov             x0, x1
    // 0x828a5c: b               #0x828af4
    // 0x828a60: d2 = 0.000000
    //     0x828a60: eor             v2.16b, v2.16b, v2.16b
    // 0x828a64: fcmp            d0, d2
    // 0x828a68: b.vs            #0x828a70
    // 0x828a6c: b.eq            #0x828a78
    // 0x828a70: r2 = false
    //     0x828a70: add             x2, NULL, #0x30  ; false
    // 0x828a74: b               #0x828a7c
    // 0x828a78: r2 = true
    //     0x828a78: add             x2, NULL, #0x20  ; true
    // 0x828a7c: tbnz            w2, #4, #0x828a94
    // 0x828a80: fadd            d3, d0, d1
    // 0x828a84: fmul            d4, d3, d0
    // 0x828a88: fmul            d0, d4, d1
    // 0x828a8c: mov             x0, x1
    // 0x828a90: b               #0x828af4
    // 0x828a94: tbnz            w2, #4, #0x828ad8
    // 0x828a98: r2 = inline_Allocate_Double()
    //     0x828a98: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x828a9c: add             x2, x2, #0x10
    //     0x828aa0: cmp             x3, x2
    //     0x828aa4: b.ls            #0x828fcc
    //     0x828aa8: str             x2, [THR, #0x60]  ; THR::top
    //     0x828aac: sub             x2, x2, #0xf
    //     0x828ab0: mov             x3, #0xd108
    //     0x828ab4: movk            x3, #3, lsl #16
    //     0x828ab8: stur            x3, [x2, #-1]
    // 0x828abc: StoreField: r2->field_7 = d1
    //     0x828abc: stur            d1, [x2, #7]
    // 0x828ac0: SaveReg r2
    //     0x828ac0: str             x2, [SP, #-8]!
    // 0x828ac4: r0 = isNegative()
    //     0x828ac4: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x828ac8: add             SP, SP, #8
    // 0x828acc: tbnz            w0, #4, #0x828ad8
    // 0x828ad0: ldur            d0, [fp, #-0x30]
    // 0x828ad4: b               #0x828ae4
    // 0x828ad8: ldur            d0, [fp, #-0x30]
    // 0x828adc: fcmp            d0, d0
    // 0x828ae0: b.vc            #0x828aec
    // 0x828ae4: ldur            x0, [fp, #-0x10]
    // 0x828ae8: b               #0x828af4
    // 0x828aec: ldur            d0, [fp, #-0x38]
    // 0x828af0: ldur            x0, [fp, #-0x10]
    // 0x828af4: ldur            x2, [fp, #-8]
    // 0x828af8: stur            d0, [fp, #-0x48]
    // 0x828afc: LoadField: r1 = r2->field_13
    //     0x828afc: ldur            w1, [x2, #0x13]
    // 0x828b00: DecompressPointer r1
    //     0x828b00: add             x1, x1, HEAP, lsl #32
    // 0x828b04: cmp             w1, NULL
    // 0x828b08: b.eq            #0x828ff0
    // 0x828b0c: LoadField: d1 = r1->field_1f
    //     0x828b0c: ldur            d1, [x1, #0x1f]
    // 0x828b10: stur            d1, [fp, #-0x38]
    // 0x828b14: LoadField: d2 = r0->field_1f
    //     0x828b14: ldur            d2, [x0, #0x1f]
    // 0x828b18: stur            d2, [fp, #-0x30]
    // 0x828b1c: fcmp            d1, d2
    // 0x828b20: b.vs            #0x828b28
    // 0x828b24: b.gt            #0x828bdc
    // 0x828b28: fcmp            d1, d2
    // 0x828b2c: b.vs            #0x828b3c
    // 0x828b30: b.ge            #0x828b3c
    // 0x828b34: mov             v2.16b, v1.16b
    // 0x828b38: b               #0x828bdc
    // 0x828b3c: d3 = 0.000000
    //     0x828b3c: eor             v3.16b, v3.16b, v3.16b
    // 0x828b40: fcmp            d1, d3
    // 0x828b44: b.vs            #0x828b4c
    // 0x828b48: b.eq            #0x828b54
    // 0x828b4c: r1 = false
    //     0x828b4c: add             x1, NULL, #0x30  ; false
    // 0x828b50: b               #0x828b58
    // 0x828b54: r1 = true
    //     0x828b54: add             x1, NULL, #0x20  ; true
    // 0x828b58: tbnz            w1, #4, #0x828b70
    // 0x828b5c: fadd            d3, d1, d2
    // 0x828b60: fmul            d4, d3, d1
    // 0x828b64: fmul            d1, d4, d2
    // 0x828b68: mov             v2.16b, v1.16b
    // 0x828b6c: b               #0x828bdc
    // 0x828b70: tbnz            w1, #4, #0x828bb4
    // 0x828b74: r1 = inline_Allocate_Double()
    //     0x828b74: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x828b78: add             x1, x1, #0x10
    //     0x828b7c: cmp             x3, x1
    //     0x828b80: b.ls            #0x828ff4
    //     0x828b84: str             x1, [THR, #0x60]  ; THR::top
    //     0x828b88: sub             x1, x1, #0xf
    //     0x828b8c: mov             x3, #0xd108
    //     0x828b90: movk            x3, #3, lsl #16
    //     0x828b94: stur            x3, [x1, #-1]
    // 0x828b98: StoreField: r1->field_7 = d2
    //     0x828b98: stur            d2, [x1, #7]
    // 0x828b9c: SaveReg r1
    //     0x828b9c: str             x1, [SP, #-8]!
    // 0x828ba0: r0 = isNegative()
    //     0x828ba0: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x828ba4: add             SP, SP, #8
    // 0x828ba8: tbnz            w0, #4, #0x828bb4
    // 0x828bac: ldur            d0, [fp, #-0x30]
    // 0x828bb0: b               #0x828bc0
    // 0x828bb4: ldur            d0, [fp, #-0x30]
    // 0x828bb8: fcmp            d0, d0
    // 0x828bbc: b.vc            #0x828bd0
    // 0x828bc0: mov             v2.16b, v0.16b
    // 0x828bc4: ldur            x2, [fp, #-8]
    // 0x828bc8: ldur            d0, [fp, #-0x48]
    // 0x828bcc: b               #0x828bdc
    // 0x828bd0: ldur            d2, [fp, #-0x38]
    // 0x828bd4: ldur            x2, [fp, #-8]
    // 0x828bd8: ldur            d0, [fp, #-0x48]
    // 0x828bdc: ldr             x0, [fp, #0x20]
    // 0x828be0: ldur            d1, [fp, #-0x40]
    // 0x828be4: stur            d2, [fp, #-0x30]
    // 0x828be8: r0 = Offset()
    //     0x828be8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x828bec: ldur            d0, [fp, #-0x48]
    // 0x828bf0: stur            x0, [fp, #-0x18]
    // 0x828bf4: StoreField: r0->field_7 = d0
    //     0x828bf4: stur            d0, [x0, #7]
    // 0x828bf8: ldur            d0, [fp, #-0x30]
    // 0x828bfc: StoreField: r0->field_f = d0
    //     0x828bfc: stur            d0, [x0, #0xf]
    // 0x828c00: r0 = Rect()
    //     0x828c00: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x828c04: stur            x0, [fp, #-0x28]
    // 0x828c08: ldur            x16, [fp, #-0x20]
    // 0x828c0c: stp             x16, x0, [SP, #-0x10]!
    // 0x828c10: ldur            x16, [fp, #-0x18]
    // 0x828c14: SaveReg r16
    //     0x828c14: str             x16, [SP, #-8]!
    // 0x828c18: r0 = Rect.fromPoints()
    //     0x828c18: bl              #0x656aa4  ; [dart:ui] Rect::Rect.fromPoints
    // 0x828c1c: add             SP, SP, #0x18
    // 0x828c20: ldur            x0, [fp, #-0x28]
    // 0x828c24: ldur            x2, [fp, #-8]
    // 0x828c28: StoreField: r2->field_13 = r0
    //     0x828c28: stur            w0, [x2, #0x13]
    //     0x828c2c: ldurb           w16, [x2, #-1]
    //     0x828c30: ldurb           w17, [x0, #-1]
    //     0x828c34: and             x16, x17, x16, lsr #2
    //     0x828c38: tst             x16, HEAP, lsr #32
    //     0x828c3c: b.eq            #0x828c44
    //     0x828c40: bl              #0xd6828c
    // 0x828c44: ldr             x16, [fp, #0x20]
    // 0x828c48: SaveReg r16
    //     0x828c48: str             x16, [SP, #-8]!
    // 0x828c4c: ldur            d0, [fp, #-0x40]
    // 0x828c50: SaveReg d0
    //     0x828c50: str             d0, [SP, #-8]!
    // 0x828c54: ldr             x16, [fp, #0x18]
    // 0x828c58: ldur            lr, [fp, #-0x28]
    // 0x828c5c: stp             lr, x16, [SP, #-0x10]!
    // 0x828c60: ldur            x16, [fp, #-0x10]
    // 0x828c64: ldr             lr, [fp, #0x10]
    // 0x828c68: stp             lr, x16, [SP, #-0x10]!
    // 0x828c6c: r0 = _handleAspectRatio()
    //     0x828c6c: bl              #0x829950  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_handleAspectRatio
    // 0x828c70: add             SP, SP, #0x30
    // 0x828c74: mov             x1, x0
    // 0x828c78: ldur            x2, [fp, #-8]
    // 0x828c7c: StoreField: r2->field_13 = r0
    //     0x828c7c: stur            w0, [x2, #0x13]
    //     0x828c80: ldurb           w16, [x2, #-1]
    //     0x828c84: ldurb           w17, [x0, #-1]
    //     0x828c88: and             x16, x17, x16, lsr #2
    //     0x828c8c: tst             x16, HEAP, lsr #32
    //     0x828c90: b.eq            #0x828c98
    //     0x828c94: bl              #0xd6828c
    // 0x828c98: ldr             x0, [fp, #0x20]
    // 0x828c9c: LoadField: r3 = r0->field_b
    //     0x828c9c: ldur            w3, [x0, #0xb]
    // 0x828ca0: DecompressPointer r3
    //     0x828ca0: add             x3, x3, HEAP, lsl #32
    // 0x828ca4: cmp             w3, NULL
    // 0x828ca8: b.eq            #0x829018
    // 0x828cac: LoadField: r4 = r3->field_13
    //     0x828cac: ldur            w4, [x3, #0x13]
    // 0x828cb0: DecompressPointer r4
    //     0x828cb0: add             x4, x4, HEAP, lsl #32
    // 0x828cb4: stp             x4, x1, [SP, #-0x10]!
    // 0x828cb8: r0 = RectExtension.beyond()
    //     0x828cb8: bl              #0x659734  ; [package:extended_image/src/utils.dart] ::RectExtension.beyond
    // 0x828cbc: add             SP, SP, #0x10
    // 0x828cc0: tbnz            w0, #4, #0x828dbc
    // 0x828cc4: ldr             x0, [fp, #0x20]
    // 0x828cc8: ldur            x2, [fp, #-8]
    // 0x828ccc: LoadField: r1 = r2->field_13
    //     0x828ccc: ldur            w1, [x2, #0x13]
    // 0x828cd0: DecompressPointer r1
    //     0x828cd0: add             x1, x1, HEAP, lsl #32
    // 0x828cd4: stp             x1, x0, [SP, #-0x10]!
    // 0x828cd8: r0 = cropRect=()
    //     0x828cd8: bl              #0x8298f8  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::cropRect=
    // 0x828cdc: add             SP, SP, #0x10
    // 0x828ce0: ldr             x0, [fp, #0x20]
    // 0x828ce4: LoadField: r1 = r0->field_b
    //     0x828ce4: ldur            w1, [x0, #0xb]
    // 0x828ce8: DecompressPointer r1
    //     0x828ce8: add             x1, x1, HEAP, lsl #32
    // 0x828cec: cmp             w1, NULL
    // 0x828cf0: b.eq            #0x82901c
    // 0x828cf4: LoadField: r2 = r1->field_13
    //     0x828cf4: ldur            w2, [x1, #0x13]
    // 0x828cf8: DecompressPointer r2
    //     0x828cf8: add             x2, x2, HEAP, lsl #32
    // 0x828cfc: ldur            x1, [fp, #-8]
    // 0x828d00: stur            x2, [fp, #-0x10]
    // 0x828d04: LoadField: r3 = r1->field_13
    //     0x828d04: ldur            w3, [x1, #0x13]
    // 0x828d08: DecompressPointer r3
    //     0x828d08: add             x3, x3, HEAP, lsl #32
    // 0x828d0c: cmp             w3, NULL
    // 0x828d10: b.eq            #0x829020
    // 0x828d14: SaveReg r3
    //     0x828d14: str             x3, [SP, #-8]!
    // 0x828d18: r0 = size()
    //     0x828d18: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0x828d1c: add             SP, SP, #8
    // 0x828d20: mov             x1, x0
    // 0x828d24: ldr             x0, [fp, #0x20]
    // 0x828d28: LoadField: r2 = r0->field_b
    //     0x828d28: ldur            w2, [x0, #0xb]
    // 0x828d2c: DecompressPointer r2
    //     0x828d2c: add             x2, x2, HEAP, lsl #32
    // 0x828d30: cmp             w2, NULL
    // 0x828d34: b.eq            #0x829024
    // 0x828d38: r16 = Instance_BoxFit
    //     0x828d38: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c2e0] Obj!BoxFit@b64e11
    //     0x828d3c: ldr             x16, [x16, #0x2e0]
    // 0x828d40: stp             x1, x16, [SP, #-0x10]!
    // 0x828d44: ldur            x16, [fp, #-0x10]
    // 0x828d48: SaveReg r16
    //     0x828d48: str             x16, [SP, #-8]!
    // 0x828d4c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x828d4c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x828d50: r0 = getDestinationRect()
    //     0x828d50: bl              #0x658e94  ; [package:extended_image/src/editor/editor_utils.dart] ::getDestinationRect
    // 0x828d54: add             SP, SP, #0x18
    // 0x828d58: mov             x1, x0
    // 0x828d5c: ldr             x0, [fp, #0x20]
    // 0x828d60: stur            x1, [fp, #-0x10]
    // 0x828d64: LoadField: r2 = r0->field_b
    //     0x828d64: ldur            w2, [x0, #0xb]
    // 0x828d68: DecompressPointer r2
    //     0x828d68: add             x2, x2, HEAP, lsl #32
    // 0x828d6c: cmp             w2, NULL
    // 0x828d70: b.eq            #0x829028
    // 0x828d74: LoadField: r3 = r2->field_b
    //     0x828d74: ldur            w3, [x2, #0xb]
    // 0x828d78: DecompressPointer r3
    //     0x828d78: add             x3, x3, HEAP, lsl #32
    // 0x828d7c: SaveReg r3
    //     0x828d7c: str             x3, [SP, #-8]!
    // 0x828d80: r0 = layoutTopLeft()
    //     0x828d80: bl              #0x6575dc  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::layoutTopLeft
    // 0x828d84: add             SP, SP, #8
    // 0x828d88: cmp             w0, NULL
    // 0x828d8c: b.eq            #0x82902c
    // 0x828d90: ldur            x16, [fp, #-0x10]
    // 0x828d94: stp             x0, x16, [SP, #-0x10]!
    // 0x828d98: r0 = shift()
    //     0x828d98: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x828d9c: add             SP, SP, #0x10
    // 0x828da0: ldr             x16, [fp, #0x20]
    // 0x828da4: stp             x0, x16, [SP, #-0x10]!
    // 0x828da8: r4 = const [0, 0x2, 0x2, 0x1, newScreenCropRect, 0x1, null]
    //     0x828da8: add             x4, PP, #0x53, lsl #12  ; [pp+0x538b0] List(7) [0, 0x2, 0x2, 0x1, "newScreenCropRect", 0x1, Null]
    //     0x828dac: ldr             x4, [x4, #0x8b0]
    // 0x828db0: r0 = _doCropAutoCenterAnimation()
    //     0x828db0: bl              #0x829374  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_doCropAutoCenterAnimation
    // 0x828db4: add             SP, SP, #0x10
    // 0x828db8: b               #0x828ee0
    // 0x828dbc: ldur            x1, [fp, #-8]
    // 0x828dc0: LoadField: r0 = r1->field_13
    //     0x828dc0: ldur            w0, [x1, #0x13]
    // 0x828dc4: DecompressPointer r0
    //     0x828dc4: add             x0, x0, HEAP, lsl #32
    // 0x828dc8: ldr             x16, [fp, #0x20]
    // 0x828dcc: stp             x0, x16, [SP, #-0x10]!
    // 0x828dd0: r0 = _doWithMaxScale()
    //     0x828dd0: bl              #0x829034  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_doWithMaxScale
    // 0x828dd4: add             SP, SP, #0x10
    // 0x828dd8: mov             x1, x0
    // 0x828ddc: ldur            x2, [fp, #-8]
    // 0x828de0: stur            x1, [fp, #-0x18]
    // 0x828de4: StoreField: r2->field_13 = r0
    //     0x828de4: stur            w0, [x2, #0x13]
    //     0x828de8: ldurb           w16, [x2, #-1]
    //     0x828dec: ldurb           w17, [x0, #-1]
    //     0x828df0: and             x16, x17, x16, lsr #2
    //     0x828df4: tst             x16, HEAP, lsr #32
    //     0x828df8: b.eq            #0x828e00
    //     0x828dfc: bl              #0xd6828c
    // 0x828e00: cmp             w1, NULL
    // 0x828e04: b.eq            #0x828ee0
    // 0x828e08: ldr             x0, [fp, #0x20]
    // 0x828e0c: LoadField: r3 = r0->field_b
    //     0x828e0c: ldur            w3, [x0, #0xb]
    // 0x828e10: DecompressPointer r3
    //     0x828e10: add             x3, x3, HEAP, lsl #32
    // 0x828e14: cmp             w3, NULL
    // 0x828e18: b.eq            #0x829030
    // 0x828e1c: LoadField: r4 = r3->field_b
    //     0x828e1c: ldur            w4, [x3, #0xb]
    // 0x828e20: DecompressPointer r4
    //     0x828e20: add             x4, x4, HEAP, lsl #32
    // 0x828e24: LoadField: r3 = r4->field_4b
    //     0x828e24: ldur            w3, [x4, #0x4b]
    // 0x828e28: DecompressPointer r3
    //     0x828e28: add             x3, x3, HEAP, lsl #32
    // 0x828e2c: stur            x3, [fp, #-0x10]
    // 0x828e30: cmp             w3, NULL
    // 0x828e34: b.eq            #0x828eb0
    // 0x828e38: cmp             w1, w3
    // 0x828e3c: b.eq            #0x828ee0
    // 0x828e40: stp             x3, x1, [SP, #-0x10]!
    // 0x828e44: r0 = _haveSameRuntimeType()
    //     0x828e44: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x828e48: add             SP, SP, #0x10
    // 0x828e4c: tbz             w0, #4, #0x828e58
    // 0x828e50: ldr             x0, [fp, #0x20]
    // 0x828e54: b               #0x828eb0
    // 0x828e58: ldur            x0, [fp, #-0x18]
    // 0x828e5c: ldur            x1, [fp, #-0x10]
    // 0x828e60: LoadField: d0 = r1->field_7
    //     0x828e60: ldur            d0, [x1, #7]
    // 0x828e64: LoadField: d1 = r0->field_7
    //     0x828e64: ldur            d1, [x0, #7]
    // 0x828e68: fcmp            d0, d1
    // 0x828e6c: b.vs            #0x828eac
    // 0x828e70: b.ne            #0x828eac
    // 0x828e74: LoadField: d0 = r1->field_f
    //     0x828e74: ldur            d0, [x1, #0xf]
    // 0x828e78: LoadField: d1 = r0->field_f
    //     0x828e78: ldur            d1, [x0, #0xf]
    // 0x828e7c: fcmp            d0, d1
    // 0x828e80: b.vs            #0x828eac
    // 0x828e84: b.ne            #0x828eac
    // 0x828e88: LoadField: d0 = r1->field_17
    //     0x828e88: ldur            d0, [x1, #0x17]
    // 0x828e8c: LoadField: d1 = r0->field_17
    //     0x828e8c: ldur            d1, [x0, #0x17]
    // 0x828e90: fcmp            d0, d1
    // 0x828e94: b.vs            #0x828eac
    // 0x828e98: b.ne            #0x828eac
    // 0x828e9c: LoadField: d0 = r1->field_1f
    //     0x828e9c: ldur            d0, [x1, #0x1f]
    // 0x828ea0: LoadField: d1 = r0->field_1f
    //     0x828ea0: ldur            d1, [x0, #0x1f]
    // 0x828ea4: fcmp            d0, d1
    // 0x828ea8: b.eq            #0x828ee0
    // 0x828eac: ldr             x0, [fp, #0x20]
    // 0x828eb0: LoadField: r1 = r0->field_f
    //     0x828eb0: ldur            w1, [x0, #0xf]
    // 0x828eb4: DecompressPointer r1
    //     0x828eb4: add             x1, x1, HEAP, lsl #32
    // 0x828eb8: cmp             w1, NULL
    // 0x828ebc: b.eq            #0x828ee0
    // 0x828ec0: ldur            x2, [fp, #-8]
    // 0x828ec4: r1 = Function '<anonymous closure>':.
    //     0x828ec4: add             x1, PP, #0x53, lsl #12  ; [pp+0x538b8] AnonymousClosure: (0x82a5dc), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::moveUpdate (0x827e40)
    //     0x828ec8: ldr             x1, [x1, #0x8b8]
    // 0x828ecc: r0 = AllocateClosure()
    //     0x828ecc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x828ed0: ldr             x16, [fp, #0x20]
    // 0x828ed4: stp             x0, x16, [SP, #-0x10]!
    // 0x828ed8: r0 = setState()
    //     0x828ed8: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x828edc: add             SP, SP, #0x10
    // 0x828ee0: r0 = Null
    //     0x828ee0: mov             x0, NULL
    // 0x828ee4: LeaveFrame
    //     0x828ee4: mov             SP, fp
    //     0x828ee8: ldp             fp, lr, [SP], #0x10
    // 0x828eec: ret
    //     0x828eec: ret             
    // 0x828ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x828ef0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x828ef4: b               #0x827e58
    // 0x828ef8: r9 = _rectTweenController
    //     0x828ef8: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c750] Field <ExtendedImageCropLayerState._rectTweenController@420005332>: late (offset: 0x28)
    //     0x828efc: ldr             x9, [x9, #0x750]
    // 0x828f00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x828f00: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x828f04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x828f04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x828f08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x828f08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x828f0c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x828f0c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x828f10: r0 = NullErrorSharedWithFPURegs()
    //     0x828f10: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x828f14: stp             q3, q5, [SP, #-0x20]!
    // 0x828f18: stp             q0, q1, [SP, #-0x20]!
    // 0x828f1c: SaveReg r2
    //     0x828f1c: str             x2, [SP, #-8]!
    // 0x828f20: r0 = AllocateDouble()
    //     0x828f20: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x828f24: RestoreReg r2
    //     0x828f24: ldr             x2, [SP], #8
    // 0x828f28: ldp             q0, q1, [SP], #0x20
    // 0x828f2c: ldp             q3, q5, [SP], #0x20
    // 0x828f30: b               #0x828108
    // 0x828f34: r0 = NullErrorSharedWithoutFPURegs()
    //     0x828f34: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x828f38: r0 = NullCastErrorSharedWithFPURegs()
    //     0x828f38: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x828f3c: r0 = NullErrorSharedWithFPURegs()
    //     0x828f3c: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x828f40: stp             q2, q3, [SP, #-0x20]!
    // 0x828f44: stp             q0, q1, [SP, #-0x20]!
    // 0x828f48: stp             x0, x2, [SP, #-0x10]!
    // 0x828f4c: r0 = AllocateDouble()
    //     0x828f4c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x828f50: mov             x1, x0
    // 0x828f54: ldp             x0, x2, [SP], #0x10
    // 0x828f58: ldp             q0, q1, [SP], #0x20
    // 0x828f5c: ldp             q2, q3, [SP], #0x20
    // 0x828f60: b               #0x82830c
    // 0x828f64: r0 = NullErrorSharedWithFPURegs()
    //     0x828f64: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x828f68: r0 = NullCastErrorSharedWithFPURegs()
    //     0x828f68: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x828f6c: r0 = NullErrorSharedWithFPURegs()
    //     0x828f6c: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x828f70: r0 = NullCastErrorSharedWithFPURegs()
    //     0x828f70: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x828f74: r0 = NullErrorSharedWithFPURegs()
    //     0x828f74: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x828f78: stp             q2, q3, [SP, #-0x20]!
    // 0x828f7c: stp             q0, q1, [SP, #-0x20]!
    // 0x828f80: stp             x0, x2, [SP, #-0x10]!
    // 0x828f84: r0 = AllocateDouble()
    //     0x828f84: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x828f88: mov             x1, x0
    // 0x828f8c: ldp             x0, x2, [SP], #0x10
    // 0x828f90: ldp             q0, q1, [SP], #0x20
    // 0x828f94: ldp             q2, q3, [SP], #0x20
    // 0x828f98: b               #0x828744
    // 0x828f9c: r0 = NullErrorSharedWithFPURegs()
    //     0x828f9c: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x828fa0: stp             q2, q4, [SP, #-0x20]!
    // 0x828fa4: stp             q0, q1, [SP, #-0x20]!
    // 0x828fa8: SaveReg r2
    //     0x828fa8: str             x2, [SP, #-8]!
    // 0x828fac: r0 = AllocateDouble()
    //     0x828fac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x828fb0: RestoreReg r2
    //     0x828fb0: ldr             x2, [SP], #8
    // 0x828fb4: ldp             q0, q1, [SP], #0x20
    // 0x828fb8: ldp             q2, q4, [SP], #0x20
    // 0x828fbc: b               #0x828850
    // 0x828fc0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x828fc0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x828fc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x828fc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x828fc8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x828fc8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x828fcc: stp             q1, q2, [SP, #-0x20]!
    // 0x828fd0: SaveReg d0
    //     0x828fd0: str             q0, [SP, #-0x10]!
    // 0x828fd4: stp             x0, x1, [SP, #-0x10]!
    // 0x828fd8: r0 = AllocateDouble()
    //     0x828fd8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x828fdc: mov             x2, x0
    // 0x828fe0: ldp             x0, x1, [SP], #0x10
    // 0x828fe4: RestoreReg d0
    //     0x828fe4: ldr             q0, [SP], #0x10
    // 0x828fe8: ldp             q1, q2, [SP], #0x20
    // 0x828fec: b               #0x828abc
    // 0x828ff0: r0 = NullErrorSharedWithFPURegs()
    //     0x828ff0: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x828ff4: stp             q1, q2, [SP, #-0x20]!
    // 0x828ff8: SaveReg d0
    //     0x828ff8: str             q0, [SP, #-0x10]!
    // 0x828ffc: stp             x0, x2, [SP, #-0x10]!
    // 0x829000: r0 = AllocateDouble()
    //     0x829000: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x829004: mov             x1, x0
    // 0x829008: ldp             x0, x2, [SP], #0x10
    // 0x82900c: RestoreReg d0
    //     0x82900c: ldr             q0, [SP], #0x10
    // 0x829010: ldp             q1, q2, [SP], #0x20
    // 0x829014: b               #0x828b98
    // 0x829018: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829018: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82901c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82901c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x829020: r0 = NullErrorSharedWithoutFPURegs()
    //     0x829020: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x829024: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829024: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x829028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82902c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82902c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x829030: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829030: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _doWithMaxScale(/* No info */) {
    // ** addr: 0x829034, size: 0x340
    // 0x829034: EnterFrame
    //     0x829034: stp             fp, lr, [SP, #-0x10]!
    //     0x829038: mov             fp, SP
    // 0x82903c: AllocStack(0x8)
    //     0x82903c: sub             SP, SP, #8
    // 0x829040: CheckStackOverflow
    //     0x829040: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x829044: cmp             SP, x16
    //     0x829048: b.ls            #0x8292f0
    // 0x82904c: ldr             x0, [fp, #0x18]
    // 0x829050: LoadField: r1 = r0->field_b
    //     0x829050: ldur            w1, [x0, #0xb]
    // 0x829054: DecompressPointer r1
    //     0x829054: add             x1, x1, HEAP, lsl #32
    // 0x829058: cmp             w1, NULL
    // 0x82905c: b.eq            #0x8292f8
    // 0x829060: LoadField: r2 = r1->field_13
    //     0x829060: ldur            w2, [x1, #0x13]
    // 0x829064: DecompressPointer r2
    //     0x829064: add             x2, x2, HEAP, lsl #32
    // 0x829068: stur            x2, [fp, #-8]
    // 0x82906c: ldr             x16, [fp, #0x10]
    // 0x829070: SaveReg r16
    //     0x829070: str             x16, [SP, #-8]!
    // 0x829074: r0 = size()
    //     0x829074: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0x829078: add             SP, SP, #8
    // 0x82907c: mov             x1, x0
    // 0x829080: ldr             x0, [fp, #0x18]
    // 0x829084: LoadField: r2 = r0->field_b
    //     0x829084: ldur            w2, [x0, #0xb]
    // 0x829088: DecompressPointer r2
    //     0x829088: add             x2, x2, HEAP, lsl #32
    // 0x82908c: cmp             w2, NULL
    // 0x829090: b.eq            #0x8292fc
    // 0x829094: r16 = Instance_BoxFit
    //     0x829094: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c2e0] Obj!BoxFit@b64e11
    //     0x829098: ldr             x16, [x16, #0x2e0]
    // 0x82909c: stp             x1, x16, [SP, #-0x10]!
    // 0x8290a0: ldur            x16, [fp, #-8]
    // 0x8290a4: SaveReg r16
    //     0x8290a4: str             x16, [SP, #-8]!
    // 0x8290a8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x8290a8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x8290ac: r0 = getDestinationRect()
    //     0x8290ac: bl              #0x658e94  ; [package:extended_image/src/editor/editor_utils.dart] ::getDestinationRect
    // 0x8290b0: add             SP, SP, #0x18
    // 0x8290b4: mov             x1, x0
    // 0x8290b8: ldr             x0, [fp, #0x18]
    // 0x8290bc: stur            x1, [fp, #-8]
    // 0x8290c0: LoadField: r2 = r0->field_b
    //     0x8290c0: ldur            w2, [x0, #0xb]
    // 0x8290c4: DecompressPointer r2
    //     0x8290c4: add             x2, x2, HEAP, lsl #32
    // 0x8290c8: cmp             w2, NULL
    // 0x8290cc: b.eq            #0x829300
    // 0x8290d0: LoadField: r3 = r2->field_b
    //     0x8290d0: ldur            w3, [x2, #0xb]
    // 0x8290d4: DecompressPointer r3
    //     0x8290d4: add             x3, x3, HEAP, lsl #32
    // 0x8290d8: SaveReg r3
    //     0x8290d8: str             x3, [SP, #-8]!
    // 0x8290dc: r0 = layoutTopLeft()
    //     0x8290dc: bl              #0x6575dc  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::layoutTopLeft
    // 0x8290e0: add             SP, SP, #8
    // 0x8290e4: cmp             w0, NULL
    // 0x8290e8: b.eq            #0x829304
    // 0x8290ec: ldur            x16, [fp, #-8]
    // 0x8290f0: stp             x0, x16, [SP, #-0x10]!
    // 0x8290f4: r0 = shift()
    //     0x8290f4: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x8290f8: add             SP, SP, #0x10
    // 0x8290fc: mov             x1, x0
    // 0x829100: ldr             x0, [fp, #0x18]
    // 0x829104: stur            x1, [fp, #-8]
    // 0x829108: LoadField: r2 = r0->field_b
    //     0x829108: ldur            w2, [x0, #0xb]
    // 0x82910c: DecompressPointer r2
    //     0x82910c: add             x2, x2, HEAP, lsl #32
    // 0x829110: cmp             w2, NULL
    // 0x829114: b.eq            #0x829308
    // 0x829118: LoadField: r3 = r2->field_b
    //     0x829118: ldur            w3, [x2, #0xb]
    // 0x82911c: DecompressPointer r3
    //     0x82911c: add             x3, x3, HEAP, lsl #32
    // 0x829120: SaveReg r3
    //     0x829120: str             x3, [SP, #-8]!
    // 0x829124: r0 = screenCropRect()
    //     0x829124: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x829128: add             SP, SP, #8
    // 0x82912c: cmp             w0, NULL
    // 0x829130: b.eq            #0x82930c
    // 0x829134: ldur            x1, [fp, #-8]
    // 0x829138: LoadField: d0 = r1->field_17
    //     0x829138: ldur            d0, [x1, #0x17]
    // 0x82913c: LoadField: d1 = r1->field_7
    //     0x82913c: ldur            d1, [x1, #7]
    // 0x829140: fsub            d2, d0, d1
    // 0x829144: LoadField: d0 = r0->field_17
    //     0x829144: ldur            d0, [x0, #0x17]
    // 0x829148: LoadField: d1 = r0->field_7
    //     0x829148: ldur            d1, [x0, #7]
    // 0x82914c: fsub            d3, d0, d1
    // 0x829150: fdiv            d0, d2, d3
    // 0x829154: ldr             x0, [fp, #0x18]
    // 0x829158: LoadField: r1 = r0->field_b
    //     0x829158: ldur            w1, [x0, #0xb]
    // 0x82915c: DecompressPointer r1
    //     0x82915c: add             x1, x1, HEAP, lsl #32
    // 0x829160: cmp             w1, NULL
    // 0x829164: b.eq            #0x829310
    // 0x829168: LoadField: r2 = r1->field_b
    //     0x829168: ldur            w2, [x1, #0xb]
    // 0x82916c: DecompressPointer r2
    //     0x82916c: add             x2, x2, HEAP, lsl #32
    // 0x829170: LoadField: d1 = r2->field_2f
    //     0x829170: ldur            d1, [x2, #0x2f]
    // 0x829174: fmul            d2, d1, d0
    // 0x829178: r1 = inline_Allocate_Double()
    //     0x829178: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82917c: add             x1, x1, #0x10
    //     0x829180: cmp             x2, x1
    //     0x829184: b.ls            #0x829314
    //     0x829188: str             x1, [THR, #0x60]  ; THR::top
    //     0x82918c: sub             x1, x1, #0xf
    //     0x829190: mov             x2, #0xd108
    //     0x829194: movk            x2, #3, lsl #16
    //     0x829198: stur            x2, [x1, #-1]
    // 0x82919c: StoreField: r1->field_7 = d2
    //     0x82919c: stur            d2, [x1, #7]
    // 0x8291a0: SaveReg r1
    //     0x8291a0: str             x1, [SP, #-8]!
    // 0x8291a4: d0 = 5.000000
    //     0x8291a4: fmov            d0, #5.00000000
    // 0x8291a8: SaveReg d0
    //     0x8291a8: str             d0, [SP, #-8]!
    // 0x8291ac: r0 = DoubleExtension.greaterThan()
    //     0x8291ac: bl              #0x6598f4  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThan
    // 0x8291b0: add             SP, SP, #0x10
    // 0x8291b4: tbnz            w0, #4, #0x8292e0
    // 0x8291b8: ldr             x0, [fp, #0x18]
    // 0x8291bc: ldr             x1, [fp, #0x10]
    // 0x8291c0: LoadField: d0 = r1->field_17
    //     0x8291c0: ldur            d0, [x1, #0x17]
    // 0x8291c4: LoadField: d1 = r1->field_7
    //     0x8291c4: ldur            d1, [x1, #7]
    // 0x8291c8: fsub            d2, d0, d1
    // 0x8291cc: LoadField: r2 = r0->field_b
    //     0x8291cc: ldur            w2, [x0, #0xb]
    // 0x8291d0: DecompressPointer r2
    //     0x8291d0: add             x2, x2, HEAP, lsl #32
    // 0x8291d4: cmp             w2, NULL
    // 0x8291d8: b.eq            #0x829330
    // 0x8291dc: LoadField: r3 = r2->field_b
    //     0x8291dc: ldur            w3, [x2, #0xb]
    // 0x8291e0: DecompressPointer r3
    //     0x8291e0: add             x3, x3, HEAP, lsl #32
    // 0x8291e4: LoadField: r2 = r3->field_4b
    //     0x8291e4: ldur            w2, [x3, #0x4b]
    // 0x8291e8: DecompressPointer r2
    //     0x8291e8: add             x2, x2, HEAP, lsl #32
    // 0x8291ec: cmp             w2, NULL
    // 0x8291f0: b.eq            #0x829334
    // 0x8291f4: LoadField: d0 = r2->field_17
    //     0x8291f4: ldur            d0, [x2, #0x17]
    // 0x8291f8: LoadField: d1 = r2->field_7
    //     0x8291f8: ldur            d1, [x2, #7]
    // 0x8291fc: fsub            d3, d0, d1
    // 0x829200: r2 = inline_Allocate_Double()
    //     0x829200: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x829204: add             x2, x2, #0x10
    //     0x829208: cmp             x3, x2
    //     0x82920c: b.ls            #0x829338
    //     0x829210: str             x2, [THR, #0x60]  ; THR::top
    //     0x829214: sub             x2, x2, #0xf
    //     0x829218: mov             x3, #0xd108
    //     0x82921c: movk            x3, #3, lsl #16
    //     0x829220: stur            x3, [x2, #-1]
    // 0x829224: StoreField: r2->field_7 = d2
    //     0x829224: stur            d2, [x2, #7]
    // 0x829228: SaveReg r2
    //     0x829228: str             x2, [SP, #-8]!
    // 0x82922c: SaveReg d3
    //     0x82922c: str             d3, [SP, #-8]!
    // 0x829230: r0 = DoubleExtension.greaterThan()
    //     0x829230: bl              #0x6598f4  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThan
    // 0x829234: add             SP, SP, #0x10
    // 0x829238: tbz             w0, #4, #0x8292c0
    // 0x82923c: ldr             x0, [fp, #0x18]
    // 0x829240: ldr             x1, [fp, #0x10]
    // 0x829244: LoadField: d0 = r1->field_1f
    //     0x829244: ldur            d0, [x1, #0x1f]
    // 0x829248: LoadField: d1 = r1->field_f
    //     0x829248: ldur            d1, [x1, #0xf]
    // 0x82924c: fsub            d2, d0, d1
    // 0x829250: LoadField: r2 = r0->field_b
    //     0x829250: ldur            w2, [x0, #0xb]
    // 0x829254: DecompressPointer r2
    //     0x829254: add             x2, x2, HEAP, lsl #32
    // 0x829258: cmp             w2, NULL
    // 0x82925c: b.eq            #0x829354
    // 0x829260: LoadField: r0 = r2->field_b
    //     0x829260: ldur            w0, [x2, #0xb]
    // 0x829264: DecompressPointer r0
    //     0x829264: add             x0, x0, HEAP, lsl #32
    // 0x829268: LoadField: r2 = r0->field_4b
    //     0x829268: ldur            w2, [x0, #0x4b]
    // 0x82926c: DecompressPointer r2
    //     0x82926c: add             x2, x2, HEAP, lsl #32
    // 0x829270: cmp             w2, NULL
    // 0x829274: b.eq            #0x829358
    // 0x829278: LoadField: d0 = r2->field_1f
    //     0x829278: ldur            d0, [x2, #0x1f]
    // 0x82927c: LoadField: d1 = r2->field_f
    //     0x82927c: ldur            d1, [x2, #0xf]
    // 0x829280: fsub            d3, d0, d1
    // 0x829284: r0 = inline_Allocate_Double()
    //     0x829284: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x829288: add             x0, x0, #0x10
    //     0x82928c: cmp             x2, x0
    //     0x829290: b.ls            #0x82935c
    //     0x829294: str             x0, [THR, #0x60]  ; THR::top
    //     0x829298: sub             x0, x0, #0xf
    //     0x82929c: mov             x2, #0xd108
    //     0x8292a0: movk            x2, #3, lsl #16
    //     0x8292a4: stur            x2, [x0, #-1]
    // 0x8292a8: StoreField: r0->field_7 = d2
    //     0x8292a8: stur            d2, [x0, #7]
    // 0x8292ac: SaveReg r0
    //     0x8292ac: str             x0, [SP, #-8]!
    // 0x8292b0: SaveReg d3
    //     0x8292b0: str             d3, [SP, #-8]!
    // 0x8292b4: r0 = DoubleExtension.greaterThan()
    //     0x8292b4: bl              #0x6598f4  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThan
    // 0x8292b8: add             SP, SP, #0x10
    // 0x8292bc: tbnz            w0, #4, #0x8292d0
    // 0x8292c0: ldr             x0, [fp, #0x10]
    // 0x8292c4: LeaveFrame
    //     0x8292c4: mov             SP, fp
    //     0x8292c8: ldp             fp, lr, [SP], #0x10
    // 0x8292cc: ret
    //     0x8292cc: ret             
    // 0x8292d0: r0 = Null
    //     0x8292d0: mov             x0, NULL
    // 0x8292d4: LeaveFrame
    //     0x8292d4: mov             SP, fp
    //     0x8292d8: ldp             fp, lr, [SP], #0x10
    // 0x8292dc: ret
    //     0x8292dc: ret             
    // 0x8292e0: ldr             x0, [fp, #0x10]
    // 0x8292e4: LeaveFrame
    //     0x8292e4: mov             SP, fp
    //     0x8292e8: ldp             fp, lr, [SP], #0x10
    // 0x8292ec: ret
    //     0x8292ec: ret             
    // 0x8292f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8292f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8292f4: b               #0x82904c
    // 0x8292f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8292f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8292fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8292fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x829300: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829300: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x829304: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829304: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x829308: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829308: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82930c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82930c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x829310: r0 = NullCastErrorSharedWithFPURegs()
    //     0x829310: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x829314: SaveReg d2
    //     0x829314: str             q2, [SP, #-0x10]!
    // 0x829318: SaveReg r0
    //     0x829318: str             x0, [SP, #-8]!
    // 0x82931c: r0 = AllocateDouble()
    //     0x82931c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x829320: mov             x1, x0
    // 0x829324: RestoreReg r0
    //     0x829324: ldr             x0, [SP], #8
    // 0x829328: RestoreReg d2
    //     0x829328: ldr             q2, [SP], #0x10
    // 0x82932c: b               #0x82919c
    // 0x829330: r0 = NullCastErrorSharedWithFPURegs()
    //     0x829330: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x829334: r0 = NullCastErrorSharedWithFPURegs()
    //     0x829334: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x829338: stp             q2, q3, [SP, #-0x20]!
    // 0x82933c: stp             x0, x1, [SP, #-0x10]!
    // 0x829340: r0 = AllocateDouble()
    //     0x829340: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x829344: mov             x2, x0
    // 0x829348: ldp             x0, x1, [SP], #0x10
    // 0x82934c: ldp             q2, q3, [SP], #0x20
    // 0x829350: b               #0x829224
    // 0x829354: r0 = NullCastErrorSharedWithFPURegs()
    //     0x829354: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x829358: r0 = NullCastErrorSharedWithFPURegs()
    //     0x829358: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82935c: stp             q2, q3, [SP, #-0x20]!
    // 0x829360: SaveReg r1
    //     0x829360: str             x1, [SP, #-8]!
    // 0x829364: r0 = AllocateDouble()
    //     0x829364: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x829368: RestoreReg r1
    //     0x829368: ldr             x1, [SP], #8
    // 0x82936c: ldp             q2, q3, [SP], #0x20
    // 0x829370: b               #0x8292a8
  }
  _ _doCropAutoCenterAnimation(/* No info */) {
    // ** addr: 0x829374, size: 0xd4
    // 0x829374: EnterFrame
    //     0x829374: stp             fp, lr, [SP, #-0x10]!
    //     0x829378: mov             fp, SP
    // 0x82937c: AllocStack(0x10)
    //     0x82937c: sub             SP, SP, #0x10
    // 0x829380: SetupParameters(ExtendedImageCropLayerState<ExtendedImageCropLayer> this /* r3, fp-0x10 */, {dynamic newScreenCropRect = Null /* r0, fp-0x8 */})
    //     0x829380: mov             x0, x4
    //     0x829384: ldur            w1, [x0, #0x13]
    //     0x829388: add             x1, x1, HEAP, lsl #32
    //     0x82938c: sub             x2, x1, #2
    //     0x829390: add             x3, fp, w2, sxtw #2
    //     0x829394: ldr             x3, [x3, #0x10]
    //     0x829398: stur            x3, [fp, #-0x10]
    //     0x82939c: ldur            w2, [x0, #0x1f]
    //     0x8293a0: add             x2, x2, HEAP, lsl #32
    //     0x8293a4: add             x16, PP, #0x53, lsl #12  ; [pp+0x538f0] "newScreenCropRect"
    //     0x8293a8: ldr             x16, [x16, #0x8f0]
    //     0x8293ac: cmp             w2, w16
    //     0x8293b0: b.ne            #0x8293d0
    //     0x8293b4: ldur            w2, [x0, #0x23]
    //     0x8293b8: add             x2, x2, HEAP, lsl #32
    //     0x8293bc: sub             w0, w1, w2
    //     0x8293c0: add             x1, fp, w0, sxtw #2
    //     0x8293c4: ldr             x1, [x1, #8]
    //     0x8293c8: mov             x0, x1
    //     0x8293cc: b               #0x8293d4
    //     0x8293d0: mov             x0, NULL
    //     0x8293d4: stur            x0, [fp, #-8]
    // 0x8293d8: CheckStackOverflow
    //     0x8293d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8293dc: cmp             SP, x16
    //     0x8293e0: b.ls            #0x829440
    // 0x8293e4: r1 = 2
    //     0x8293e4: mov             x1, #2
    // 0x8293e8: r0 = AllocateContext()
    //     0x8293e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8293ec: mov             x1, x0
    // 0x8293f0: ldur            x0, [fp, #-0x10]
    // 0x8293f4: StoreField: r1->field_f = r0
    //     0x8293f4: stur            w0, [x1, #0xf]
    // 0x8293f8: ldur            x2, [fp, #-8]
    // 0x8293fc: StoreField: r1->field_13 = r2
    //     0x8293fc: stur            w2, [x1, #0x13]
    // 0x829400: LoadField: r2 = r0->field_f
    //     0x829400: ldur            w2, [x0, #0xf]
    // 0x829404: DecompressPointer r2
    //     0x829404: add             x2, x2, HEAP, lsl #32
    // 0x829408: cmp             w2, NULL
    // 0x82940c: b.eq            #0x829430
    // 0x829410: mov             x2, x1
    // 0x829414: r1 = Function '<anonymous closure>':.
    //     0x829414: add             x1, PP, #0x53, lsl #12  ; [pp+0x538f8] AnonymousClosure: (0x8294e4), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_doCropAutoCenterAnimation (0x829374)
    //     0x829418: ldr             x1, [x1, #0x8f8]
    // 0x82941c: r0 = AllocateClosure()
    //     0x82941c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x829420: ldur            x16, [fp, #-0x10]
    // 0x829424: stp             x0, x16, [SP, #-0x10]!
    // 0x829428: r0 = setState()
    //     0x829428: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82942c: add             SP, SP, #0x10
    // 0x829430: r0 = Null
    //     0x829430: mov             x0, NULL
    // 0x829434: LeaveFrame
    //     0x829434: mov             SP, fp
    //     0x829438: ldp             fp, lr, [SP], #0x10
    // 0x82943c: ret
    //     0x82943c: ret             
    // 0x829440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829440: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829444: b               #0x8293e4
  }
  [closure] void _doCropAutoCenterAnimation(dynamic, {Rect? newScreenCropRect}) {
    // ** addr: 0x829448, size: 0x9c
    // 0x829448: EnterFrame
    //     0x829448: stp             fp, lr, [SP, #-0x10]!
    //     0x82944c: mov             fp, SP
    // 0x829450: mov             x0, x4
    // 0x829454: LoadField: r1 = r0->field_13
    //     0x829454: ldur            w1, [x0, #0x13]
    // 0x829458: DecompressPointer r1
    //     0x829458: add             x1, x1, HEAP, lsl #32
    // 0x82945c: sub             x2, x1, #2
    // 0x829460: add             x3, fp, w2, sxtw #2
    // 0x829464: ldr             x3, [x3, #0x10]
    // 0x829468: LoadField: r2 = r0->field_1f
    //     0x829468: ldur            w2, [x0, #0x1f]
    // 0x82946c: DecompressPointer r2
    //     0x82946c: add             x2, x2, HEAP, lsl #32
    // 0x829470: r16 = "newScreenCropRect"
    //     0x829470: add             x16, PP, #0x53, lsl #12  ; [pp+0x538f0] "newScreenCropRect"
    //     0x829474: ldr             x16, [x16, #0x8f0]
    // 0x829478: cmp             w2, w16
    // 0x82947c: b.ne            #0x82949c
    // 0x829480: LoadField: r2 = r0->field_23
    //     0x829480: ldur            w2, [x0, #0x23]
    // 0x829484: DecompressPointer r2
    //     0x829484: add             x2, x2, HEAP, lsl #32
    // 0x829488: sub             w0, w1, w2
    // 0x82948c: add             x1, fp, w0, sxtw #2
    // 0x829490: ldr             x1, [x1, #8]
    // 0x829494: mov             x0, x1
    // 0x829498: b               #0x8294a0
    // 0x82949c: r0 = Null
    //     0x82949c: mov             x0, NULL
    // 0x8294a0: LoadField: r1 = r3->field_17
    //     0x8294a0: ldur            w1, [x3, #0x17]
    // 0x8294a4: DecompressPointer r1
    //     0x8294a4: add             x1, x1, HEAP, lsl #32
    // 0x8294a8: CheckStackOverflow
    //     0x8294a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8294ac: cmp             SP, x16
    //     0x8294b0: b.ls            #0x8294dc
    // 0x8294b4: LoadField: r2 = r1->field_f
    //     0x8294b4: ldur            w2, [x1, #0xf]
    // 0x8294b8: DecompressPointer r2
    //     0x8294b8: add             x2, x2, HEAP, lsl #32
    // 0x8294bc: stp             x0, x2, [SP, #-0x10]!
    // 0x8294c0: r4 = const [0, 0x2, 0x2, 0x1, newScreenCropRect, 0x1, null]
    //     0x8294c0: add             x4, PP, #0x53, lsl #12  ; [pp+0x538b0] List(7) [0, 0x2, 0x2, 0x1, "newScreenCropRect", 0x1, Null]
    //     0x8294c4: ldr             x4, [x4, #0x8b0]
    // 0x8294c8: r0 = _doCropAutoCenterAnimation()
    //     0x8294c8: bl              #0x829374  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_doCropAutoCenterAnimation
    // 0x8294cc: add             SP, SP, #0x10
    // 0x8294d0: LeaveFrame
    //     0x8294d0: mov             SP, fp
    //     0x8294d4: ldp             fp, lr, [SP], #0x10
    // 0x8294d8: ret
    //     0x8294d8: ret             
    // 0x8294dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8294dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8294e0: b               #0x8294b4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8294e4, size: 0x414
    // 0x8294e4: EnterFrame
    //     0x8294e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8294e8: mov             fp, SP
    // 0x8294ec: AllocStack(0x40)
    //     0x8294ec: sub             SP, SP, #0x40
    // 0x8294f0: SetupParameters()
    //     0x8294f0: ldr             x0, [fp, #0x10]
    //     0x8294f4: ldur            w1, [x0, #0x17]
    //     0x8294f8: add             x1, x1, HEAP, lsl #32
    //     0x8294fc: stur            x1, [fp, #-8]
    // 0x829500: CheckStackOverflow
    //     0x829500: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x829504: cmp             SP, x16
    //     0x829508: b.ls            #0x829888
    // 0x82950c: LoadField: r0 = r1->field_f
    //     0x82950c: ldur            w0, [x1, #0xf]
    // 0x829510: DecompressPointer r0
    //     0x829510: add             x0, x0, HEAP, lsl #32
    // 0x829514: LoadField: r2 = r0->field_b
    //     0x829514: ldur            w2, [x0, #0xb]
    // 0x829518: DecompressPointer r2
    //     0x829518: add             x2, x2, HEAP, lsl #32
    // 0x82951c: cmp             w2, NULL
    // 0x829520: b.eq            #0x829890
    // 0x829524: LoadField: r0 = r2->field_b
    //     0x829524: ldur            w0, [x2, #0xb]
    // 0x829528: DecompressPointer r0
    //     0x829528: add             x0, x0, HEAP, lsl #32
    // 0x82952c: SaveReg r0
    //     0x82952c: str             x0, [SP, #-8]!
    // 0x829530: r0 = screenCropRect()
    //     0x829530: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x829534: add             SP, SP, #8
    // 0x829538: stur            x0, [fp, #-0x18]
    // 0x82953c: cmp             w0, NULL
    // 0x829540: b.eq            #0x829894
    // 0x829544: ldur            x1, [fp, #-8]
    // 0x829548: LoadField: r2 = r1->field_f
    //     0x829548: ldur            w2, [x1, #0xf]
    // 0x82954c: DecompressPointer r2
    //     0x82954c: add             x2, x2, HEAP, lsl #32
    // 0x829550: LoadField: r3 = r2->field_b
    //     0x829550: ldur            w3, [x2, #0xb]
    // 0x829554: DecompressPointer r3
    //     0x829554: add             x3, x3, HEAP, lsl #32
    // 0x829558: cmp             w3, NULL
    // 0x82955c: b.eq            #0x829898
    // 0x829560: LoadField: r4 = r3->field_b
    //     0x829560: ldur            w4, [x3, #0xb]
    // 0x829564: DecompressPointer r4
    //     0x829564: add             x4, x4, HEAP, lsl #32
    // 0x829568: LoadField: r3 = r4->field_23
    //     0x829568: ldur            w3, [x4, #0x23]
    // 0x82956c: DecompressPointer r3
    //     0x82956c: add             x3, x3, HEAP, lsl #32
    // 0x829570: stur            x3, [fp, #-0x10]
    // 0x829574: cmp             w3, NULL
    // 0x829578: b.eq            #0x82989c
    // 0x82957c: LoadField: r4 = r1->field_13
    //     0x82957c: ldur            w4, [x1, #0x13]
    // 0x829580: DecompressPointer r4
    //     0x829580: add             x4, x4, HEAP, lsl #32
    // 0x829584: cmp             w4, NULL
    // 0x829588: b.ne            #0x8295e4
    // 0x82958c: LoadField: r4 = r2->field_23
    //     0x82958c: ldur            w4, [x2, #0x23]
    // 0x829590: DecompressPointer r4
    //     0x829590: add             x4, x4, HEAP, lsl #32
    // 0x829594: cmp             w4, NULL
    // 0x829598: b.eq            #0x8298a0
    // 0x82959c: LoadField: r2 = r4->field_f
    //     0x82959c: ldur            w2, [x4, #0xf]
    // 0x8295a0: DecompressPointer r2
    //     0x8295a0: add             x2, x2, HEAP, lsl #32
    // 0x8295a4: LoadField: r5 = r4->field_b
    //     0x8295a4: ldur            w5, [x4, #0xb]
    // 0x8295a8: DecompressPointer r5
    //     0x8295a8: add             x5, x5, HEAP, lsl #32
    // 0x8295ac: stp             x5, x2, [SP, #-0x10]!
    // 0x8295b0: r0 = evaluate()
    //     0x8295b0: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x8295b4: add             SP, SP, #0x10
    // 0x8295b8: mov             x2, x0
    // 0x8295bc: ldur            x1, [fp, #-8]
    // 0x8295c0: StoreField: r1->field_13 = r0
    //     0x8295c0: stur            w0, [x1, #0x13]
    //     0x8295c4: ldurb           w16, [x1, #-1]
    //     0x8295c8: ldurb           w17, [x0, #-1]
    //     0x8295cc: and             x16, x17, x16, lsr #2
    //     0x8295d0: tst             x16, HEAP, lsr #32
    //     0x8295d4: b.eq            #0x8295dc
    //     0x8295d8: bl              #0xd6826c
    // 0x8295dc: mov             x3, x2
    // 0x8295e0: b               #0x8295e8
    // 0x8295e4: mov             x3, x4
    // 0x8295e8: ldur            x0, [fp, #-0x18]
    // 0x8295ec: ldur            x2, [fp, #-0x10]
    // 0x8295f0: cmp             w3, NULL
    // 0x8295f4: b.eq            #0x8298a4
    // 0x8295f8: LoadField: d0 = r3->field_17
    //     0x8295f8: ldur            d0, [x3, #0x17]
    // 0x8295fc: LoadField: d1 = r3->field_7
    //     0x8295fc: ldur            d1, [x3, #7]
    // 0x829600: fsub            d2, d0, d1
    // 0x829604: LoadField: d0 = r0->field_17
    //     0x829604: ldur            d0, [x0, #0x17]
    // 0x829608: LoadField: d1 = r0->field_7
    //     0x829608: ldur            d1, [x0, #7]
    // 0x82960c: fsub            d3, d0, d1
    // 0x829610: fdiv            d0, d2, d3
    // 0x829614: stur            d0, [fp, #-0x38]
    // 0x829618: SaveReg r3
    //     0x829618: str             x3, [SP, #-8]!
    // 0x82961c: r0 = center()
    //     0x82961c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x829620: add             SP, SP, #8
    // 0x829624: stur            x0, [fp, #-0x20]
    // 0x829628: ldur            x16, [fp, #-0x18]
    // 0x82962c: SaveReg r16
    //     0x82962c: str             x16, [SP, #-8]!
    // 0x829630: r0 = center()
    //     0x829630: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x829634: add             SP, SP, #8
    // 0x829638: ldur            x16, [fp, #-0x20]
    // 0x82963c: stp             x0, x16, [SP, #-0x10]!
    // 0x829640: r0 = -()
    //     0x829640: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x829644: add             SP, SP, #0x10
    // 0x829648: stur            x0, [fp, #-0x20]
    // 0x82964c: ldur            x16, [fp, #-0x18]
    // 0x829650: SaveReg r16
    //     0x829650: str             x16, [SP, #-8]!
    // 0x829654: r0 = center()
    //     0x829654: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x829658: add             SP, SP, #8
    // 0x82965c: stur            x0, [fp, #-0x28]
    // 0x829660: ldur            x16, [fp, #-0x10]
    // 0x829664: SaveReg r16
    //     0x829664: str             x16, [SP, #-8]!
    // 0x829668: r0 = center()
    //     0x829668: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x82966c: add             SP, SP, #8
    // 0x829670: stur            x0, [fp, #-0x30]
    // 0x829674: ldur            x16, [fp, #-0x18]
    // 0x829678: SaveReg r16
    //     0x829678: str             x16, [SP, #-8]!
    // 0x82967c: r0 = center()
    //     0x82967c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x829680: add             SP, SP, #8
    // 0x829684: ldur            x16, [fp, #-0x30]
    // 0x829688: stp             x0, x16, [SP, #-0x10]!
    // 0x82968c: r0 = -()
    //     0x82968c: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x829690: add             SP, SP, #0x10
    // 0x829694: ldur            d0, [fp, #-0x38]
    // 0x829698: r1 = inline_Allocate_Double()
    //     0x829698: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82969c: add             x1, x1, #0x10
    //     0x8296a0: cmp             x2, x1
    //     0x8296a4: b.ls            #0x8298a8
    //     0x8296a8: str             x1, [THR, #0x60]  ; THR::top
    //     0x8296ac: sub             x1, x1, #0xf
    //     0x8296b0: mov             x2, #0xd108
    //     0x8296b4: movk            x2, #3, lsl #16
    //     0x8296b8: stur            x2, [x1, #-1]
    // 0x8296bc: StoreField: r1->field_7 = d0
    //     0x8296bc: stur            d0, [x1, #7]
    // 0x8296c0: stp             x1, x0, [SP, #-0x10]!
    // 0x8296c4: r0 = *()
    //     0x8296c4: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x8296c8: add             SP, SP, #0x10
    // 0x8296cc: ldur            x16, [fp, #-0x28]
    // 0x8296d0: stp             x0, x16, [SP, #-0x10]!
    // 0x8296d4: r0 = +()
    //     0x8296d4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x8296d8: add             SP, SP, #0x10
    // 0x8296dc: ldur            x16, [fp, #-0x20]
    // 0x8296e0: stp             x16, x0, [SP, #-0x10]!
    // 0x8296e4: r0 = +()
    //     0x8296e4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x8296e8: add             SP, SP, #0x10
    // 0x8296ec: mov             x1, x0
    // 0x8296f0: ldur            x0, [fp, #-0x10]
    // 0x8296f4: stur            x1, [fp, #-0x18]
    // 0x8296f8: LoadField: d0 = r0->field_17
    //     0x8296f8: ldur            d0, [x0, #0x17]
    // 0x8296fc: LoadField: d1 = r0->field_7
    //     0x8296fc: ldur            d1, [x0, #7]
    // 0x829700: fsub            d2, d0, d1
    // 0x829704: ldur            d0, [fp, #-0x38]
    // 0x829708: fmul            d1, d2, d0
    // 0x82970c: stur            d1, [fp, #-0x40]
    // 0x829710: LoadField: d2 = r0->field_1f
    //     0x829710: ldur            d2, [x0, #0x1f]
    // 0x829714: LoadField: d3 = r0->field_f
    //     0x829714: ldur            d3, [x0, #0xf]
    // 0x829718: fsub            d4, d2, d3
    // 0x82971c: fmul            d2, d4, d0
    // 0x829720: r0 = inline_Allocate_Double()
    //     0x829720: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x829724: add             x0, x0, #0x10
    //     0x829728: cmp             x2, x0
    //     0x82972c: b.ls            #0x8298c4
    //     0x829730: str             x0, [THR, #0x60]  ; THR::top
    //     0x829734: sub             x0, x0, #0xf
    //     0x829738: mov             x2, #0xd108
    //     0x82973c: movk            x2, #3, lsl #16
    //     0x829740: stur            x2, [x0, #-1]
    // 0x829744: StoreField: r0->field_7 = d2
    //     0x829744: stur            d2, [x0, #7]
    // 0x829748: stur            x0, [fp, #-0x10]
    // 0x82974c: r0 = Rect()
    //     0x82974c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x829750: stur            x0, [fp, #-0x20]
    // 0x829754: ldur            x16, [fp, #-0x18]
    // 0x829758: stp             x16, x0, [SP, #-0x10]!
    // 0x82975c: ldur            x16, [fp, #-0x10]
    // 0x829760: SaveReg r16
    //     0x829760: str             x16, [SP, #-8]!
    // 0x829764: ldur            d0, [fp, #-0x40]
    // 0x829768: SaveReg d0
    //     0x829768: str             d0, [SP, #-8]!
    // 0x82976c: r0 = Rect.fromCenter()
    //     0x82976c: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0x829770: add             SP, SP, #0x20
    // 0x829774: ldur            x0, [fp, #-8]
    // 0x829778: LoadField: r1 = r0->field_f
    //     0x829778: ldur            w1, [x0, #0xf]
    // 0x82977c: DecompressPointer r1
    //     0x82977c: add             x1, x1, HEAP, lsl #32
    // 0x829780: stur            x1, [fp, #-0x18]
    // 0x829784: LoadField: r2 = r1->field_b
    //     0x829784: ldur            w2, [x1, #0xb]
    // 0x829788: DecompressPointer r2
    //     0x829788: add             x2, x2, HEAP, lsl #32
    // 0x82978c: cmp             w2, NULL
    // 0x829790: b.eq            #0x8298e4
    // 0x829794: LoadField: r3 = r2->field_b
    //     0x829794: ldur            w3, [x2, #0xb]
    // 0x829798: DecompressPointer r3
    //     0x829798: add             x3, x3, HEAP, lsl #32
    // 0x82979c: LoadField: d0 = r3->field_2f
    //     0x82979c: ldur            d0, [x3, #0x2f]
    // 0x8297a0: ldur            d1, [fp, #-0x38]
    // 0x8297a4: fmul            d2, d0, d1
    // 0x8297a8: stur            d2, [fp, #-0x40]
    // 0x8297ac: LoadField: r2 = r0->field_13
    //     0x8297ac: ldur            w2, [x0, #0x13]
    // 0x8297b0: DecompressPointer r2
    //     0x8297b0: add             x2, x2, HEAP, lsl #32
    // 0x8297b4: stur            x2, [fp, #-0x10]
    // 0x8297b8: cmp             w2, NULL
    // 0x8297bc: b.eq            #0x8298e8
    // 0x8297c0: SaveReg r3
    //     0x8297c0: str             x3, [SP, #-8]!
    // 0x8297c4: r0 = layoutTopLeft()
    //     0x8297c4: bl              #0x6575dc  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::layoutTopLeft
    // 0x8297c8: add             SP, SP, #8
    // 0x8297cc: cmp             w0, NULL
    // 0x8297d0: b.eq            #0x8298ec
    // 0x8297d4: SaveReg r0
    //     0x8297d4: str             x0, [SP, #-8]!
    // 0x8297d8: r0 = unary-()
    //     0x8297d8: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x8297dc: add             SP, SP, #8
    // 0x8297e0: ldur            x16, [fp, #-0x10]
    // 0x8297e4: stp             x0, x16, [SP, #-0x10]!
    // 0x8297e8: r0 = shift()
    //     0x8297e8: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x8297ec: add             SP, SP, #0x10
    // 0x8297f0: ldur            x1, [fp, #-0x18]
    // 0x8297f4: LoadField: r2 = r1->field_b
    //     0x8297f4: ldur            w2, [x1, #0xb]
    // 0x8297f8: DecompressPointer r2
    //     0x8297f8: add             x2, x2, HEAP, lsl #32
    // 0x8297fc: cmp             w2, NULL
    // 0x829800: b.eq            #0x8298f0
    // 0x829804: LoadField: r1 = r2->field_b
    //     0x829804: ldur            w1, [x2, #0xb]
    // 0x829808: DecompressPointer r1
    //     0x829808: add             x1, x1, HEAP, lsl #32
    // 0x82980c: StoreField: r1->field_4b = r0
    //     0x82980c: stur            w0, [x1, #0x4b]
    //     0x829810: ldurb           w16, [x1, #-1]
    //     0x829814: ldurb           w17, [x0, #-1]
    //     0x829818: and             x16, x17, x16, lsr #2
    //     0x82981c: tst             x16, HEAP, lsr #32
    //     0x829820: b.eq            #0x829828
    //     0x829824: bl              #0xd6826c
    // 0x829828: ldur            x1, [fp, #-8]
    // 0x82982c: LoadField: r2 = r1->field_f
    //     0x82982c: ldur            w2, [x1, #0xf]
    // 0x829830: DecompressPointer r2
    //     0x829830: add             x2, x2, HEAP, lsl #32
    // 0x829834: LoadField: r1 = r2->field_b
    //     0x829834: ldur            w1, [x2, #0xb]
    // 0x829838: DecompressPointer r1
    //     0x829838: add             x1, x1, HEAP, lsl #32
    // 0x82983c: cmp             w1, NULL
    // 0x829840: b.eq            #0x8298f4
    // 0x829844: LoadField: r2 = r1->field_b
    //     0x829844: ldur            w2, [x1, #0xb]
    // 0x829848: DecompressPointer r2
    //     0x829848: add             x2, x2, HEAP, lsl #32
    // 0x82984c: ldur            x0, [fp, #-0x20]
    // 0x829850: StoreField: r2->field_23 = r0
    //     0x829850: stur            w0, [x2, #0x23]
    //     0x829854: ldurb           w16, [x2, #-1]
    //     0x829858: ldurb           w17, [x0, #-1]
    //     0x82985c: and             x16, x17, x16, lsr #2
    //     0x829860: tst             x16, HEAP, lsr #32
    //     0x829864: b.eq            #0x82986c
    //     0x829868: bl              #0xd6828c
    // 0x82986c: ldur            d0, [fp, #-0x40]
    // 0x829870: StoreField: r2->field_2f = d0
    //     0x829870: stur            d0, [x2, #0x2f]
    // 0x829874: StoreField: r2->field_37 = d0
    //     0x829874: stur            d0, [x2, #0x37]
    // 0x829878: r0 = Null
    //     0x829878: mov             x0, NULL
    // 0x82987c: LeaveFrame
    //     0x82987c: mov             SP, fp
    //     0x829880: ldp             fp, lr, [SP], #0x10
    // 0x829884: ret
    //     0x829884: ret             
    // 0x829888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829888: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82988c: b               #0x82950c
    // 0x829890: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829890: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x829894: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829894: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x829898: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829898: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82989c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82989c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8298a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8298a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8298a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8298a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8298a8: SaveReg d0
    //     0x8298a8: str             q0, [SP, #-0x10]!
    // 0x8298ac: SaveReg r0
    //     0x8298ac: str             x0, [SP, #-8]!
    // 0x8298b0: r0 = AllocateDouble()
    //     0x8298b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8298b4: mov             x1, x0
    // 0x8298b8: RestoreReg r0
    //     0x8298b8: ldr             x0, [SP], #8
    // 0x8298bc: RestoreReg d0
    //     0x8298bc: ldr             q0, [SP], #0x10
    // 0x8298c0: b               #0x8296bc
    // 0x8298c4: stp             q1, q2, [SP, #-0x20]!
    // 0x8298c8: SaveReg d0
    //     0x8298c8: str             q0, [SP, #-0x10]!
    // 0x8298cc: SaveReg r1
    //     0x8298cc: str             x1, [SP, #-8]!
    // 0x8298d0: r0 = AllocateDouble()
    //     0x8298d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8298d4: RestoreReg r1
    //     0x8298d4: ldr             x1, [SP], #8
    // 0x8298d8: RestoreReg d0
    //     0x8298d8: ldr             q0, [SP], #0x10
    // 0x8298dc: ldp             q1, q2, [SP], #0x20
    // 0x8298e0: b               #0x829744
    // 0x8298e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8298e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8298e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8298e8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x8298ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8298ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8298f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8298f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8298f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8298f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ cropRect=(/* No info */) {
    // ** addr: 0x8298f8, size: 0x58
    // 0x8298f8: EnterFrame
    //     0x8298f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8298fc: mov             fp, SP
    // 0x829900: ldr             x1, [fp, #0x18]
    // 0x829904: LoadField: r2 = r1->field_b
    //     0x829904: ldur            w2, [x1, #0xb]
    // 0x829908: DecompressPointer r2
    //     0x829908: add             x2, x2, HEAP, lsl #32
    // 0x82990c: cmp             w2, NULL
    // 0x829910: b.eq            #0x82994c
    // 0x829914: LoadField: r1 = r2->field_b
    //     0x829914: ldur            w1, [x2, #0xb]
    // 0x829918: DecompressPointer r1
    //     0x829918: add             x1, x1, HEAP, lsl #32
    // 0x82991c: ldr             x0, [fp, #0x10]
    // 0x829920: StoreField: r1->field_4b = r0
    //     0x829920: stur            w0, [x1, #0x4b]
    //     0x829924: ldurb           w16, [x1, #-1]
    //     0x829928: ldurb           w17, [x0, #-1]
    //     0x82992c: and             x16, x17, x16, lsr #2
    //     0x829930: tst             x16, HEAP, lsr #32
    //     0x829934: b.eq            #0x82993c
    //     0x829938: bl              #0xd6826c
    // 0x82993c: r0 = Null
    //     0x82993c: mov             x0, NULL
    // 0x829940: LeaveFrame
    //     0x829940: mov             SP, fp
    //     0x829944: ldp             fp, lr, [SP], #0x10
    // 0x829948: ret
    //     0x829948: ret             
    // 0x82994c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82994c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleAspectRatio(/* No info */) {
    // ** addr: 0x829950, size: 0x654
    // 0x829950: EnterFrame
    //     0x829950: stp             fp, lr, [SP, #-0x10]!
    //     0x829954: mov             fp, SP
    // 0x829958: AllocStack(0x38)
    //     0x829958: sub             SP, SP, #0x38
    // 0x82995c: CheckStackOverflow
    //     0x82995c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x829960: cmp             SP, x16
    //     0x829964: b.ls            #0x829eec
    // 0x829968: ldr             x0, [fp, #0x38]
    // 0x82996c: LoadField: r1 = r0->field_b
    //     0x82996c: ldur            w1, [x0, #0xb]
    // 0x829970: DecompressPointer r1
    //     0x829970: add             x1, x1, HEAP, lsl #32
    // 0x829974: cmp             w1, NULL
    // 0x829978: b.eq            #0x829ef4
    // 0x82997c: LoadField: r2 = r1->field_b
    //     0x82997c: ldur            w2, [x1, #0xb]
    // 0x829980: DecompressPointer r2
    //     0x829980: add             x2, x2, HEAP, lsl #32
    // 0x829984: SaveReg r2
    //     0x829984: str             x2, [SP, #-8]!
    // 0x829988: r0 = cropAspectRatio()
    //     0x829988: bl              #0x82a41c  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::cropAspectRatio
    // 0x82998c: add             SP, SP, #8
    // 0x829990: stur            x0, [fp, #-0x10]
    // 0x829994: cmp             w0, NULL
    // 0x829998: b.eq            #0x829ed8
    // 0x82999c: ldr             d1, [fp, #0x30]
    // 0x8299a0: ldr             x1, [fp, #0x28]
    // 0x8299a4: d0 = 2.000000
    //     0x8299a4: fmov            d0, #2.00000000
    // 0x8299a8: fmul            d2, d1, d0
    // 0x8299ac: stur            d2, [fp, #-0x18]
    // 0x8299b0: LoadField: r2 = r1->field_7
    //     0x8299b0: ldur            x2, [x1, #7]
    // 0x8299b4: stur            x2, [fp, #-8]
    // 0x8299b8: cmp             x2, #3
    // 0x8299bc: b.gt            #0x829dc4
    // 0x8299c0: ldr             x1, [fp, #0x10]
    // 0x8299c4: d0 = 0.000000
    //     0x8299c4: eor             v0.16b, v0.16b, v0.16b
    // 0x8299c8: LoadField: d1 = r1->field_7
    //     0x8299c8: ldur            d1, [x1, #7]
    // 0x8299cc: fcmp            d1, d0
    // 0x8299d0: b.vs            #0x8299e0
    // 0x8299d4: b.ne            #0x8299e0
    // 0x8299d8: d1 = 0.000000
    //     0x8299d8: eor             v1.16b, v1.16b, v1.16b
    // 0x8299dc: b               #0x8299f4
    // 0x8299e0: fcmp            d1, d0
    // 0x8299e4: b.vs            #0x8299f4
    // 0x8299e8: b.ge            #0x8299f4
    // 0x8299ec: fneg            d3, d1
    // 0x8299f0: mov             v1.16b, v3.16b
    // 0x8299f4: LoadField: d3 = r1->field_f
    //     0x8299f4: ldur            d3, [x1, #0xf]
    // 0x8299f8: fcmp            d3, d0
    // 0x8299fc: b.vs            #0x829a0c
    // 0x829a00: b.ne            #0x829a0c
    // 0x829a04: d3 = 0.000000
    //     0x829a04: eor             v3.16b, v3.16b, v3.16b
    // 0x829a08: b               #0x829a20
    // 0x829a0c: fcmp            d3, d0
    // 0x829a10: b.vs            #0x829a20
    // 0x829a14: b.ge            #0x829a20
    // 0x829a18: fneg            d4, d3
    // 0x829a1c: mov             v3.16b, v4.16b
    // 0x829a20: r1 = inline_Allocate_Double()
    //     0x829a20: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x829a24: add             x1, x1, #0x10
    //     0x829a28: cmp             x3, x1
    //     0x829a2c: b.ls            #0x829ef8
    //     0x829a30: str             x1, [THR, #0x60]  ; THR::top
    //     0x829a34: sub             x1, x1, #0xf
    //     0x829a38: mov             x3, #0xd108
    //     0x829a3c: movk            x3, #3, lsl #16
    //     0x829a40: stur            x3, [x1, #-1]
    // 0x829a44: StoreField: r1->field_7 = d1
    //     0x829a44: stur            d1, [x1, #7]
    // 0x829a48: SaveReg r1
    //     0x829a48: str             x1, [SP, #-8]!
    // 0x829a4c: SaveReg d3
    //     0x829a4c: str             d3, [SP, #-8]!
    // 0x829a50: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x829a50: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x829a54: add             SP, SP, #0x10
    // 0x829a58: tbnz            w0, #4, #0x829ba0
    // 0x829a5c: ldr             x1, [fp, #0x20]
    // 0x829a60: ldr             x2, [fp, #0x18]
    // 0x829a64: ldur            x0, [fp, #-0x10]
    // 0x829a68: LoadField: d0 = r1->field_17
    //     0x829a68: ldur            d0, [x1, #0x17]
    // 0x829a6c: LoadField: d1 = r1->field_7
    //     0x829a6c: ldur            d1, [x1, #7]
    // 0x829a70: fsub            d2, d0, d1
    // 0x829a74: LoadField: d0 = r0->field_7
    //     0x829a74: ldur            d0, [x0, #7]
    // 0x829a78: stur            d0, [fp, #-0x30]
    // 0x829a7c: fdiv            d1, d2, d0
    // 0x829a80: stur            d1, [fp, #-0x28]
    // 0x829a84: LoadField: d2 = r2->field_1f
    //     0x829a84: ldur            d2, [x2, #0x1f]
    // 0x829a88: LoadField: d3 = r2->field_f
    //     0x829a88: ldur            d3, [x2, #0xf]
    // 0x829a8c: fsub            d4, d2, d3
    // 0x829a90: stur            d4, [fp, #-0x20]
    // 0x829a94: fcmp            d1, d4
    // 0x829a98: b.vs            #0x829aa8
    // 0x829a9c: b.le            #0x829aa8
    // 0x829aa0: mov             v1.16b, v4.16b
    // 0x829aa4: b               #0x829b40
    // 0x829aa8: fcmp            d1, d4
    // 0x829aac: b.vs            #0x829ab4
    // 0x829ab0: b.lt            #0x829b40
    // 0x829ab4: d2 = 0.000000
    //     0x829ab4: eor             v2.16b, v2.16b, v2.16b
    // 0x829ab8: fcmp            d1, d2
    // 0x829abc: b.vs            #0x829ac4
    // 0x829ac0: b.eq            #0x829acc
    // 0x829ac4: r0 = false
    //     0x829ac4: add             x0, NULL, #0x30  ; false
    // 0x829ac8: b               #0x829ad0
    // 0x829acc: r0 = true
    //     0x829acc: add             x0, NULL, #0x20  ; true
    // 0x829ad0: tbnz            w0, #4, #0x829ae4
    // 0x829ad4: fadd            d3, d1, d4
    // 0x829ad8: fmul            d5, d3, d1
    // 0x829adc: fmul            d1, d5, d4
    // 0x829ae0: b               #0x829b40
    // 0x829ae4: tbnz            w0, #4, #0x829b28
    // 0x829ae8: r0 = inline_Allocate_Double()
    //     0x829ae8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x829aec: add             x0, x0, #0x10
    //     0x829af0: cmp             x2, x0
    //     0x829af4: b.ls            #0x829f1c
    //     0x829af8: str             x0, [THR, #0x60]  ; THR::top
    //     0x829afc: sub             x0, x0, #0xf
    //     0x829b00: mov             x2, #0xd108
    //     0x829b04: movk            x2, #3, lsl #16
    //     0x829b08: stur            x2, [x0, #-1]
    // 0x829b0c: StoreField: r0->field_7 = d4
    //     0x829b0c: stur            d4, [x0, #7]
    // 0x829b10: SaveReg r0
    //     0x829b10: str             x0, [SP, #-8]!
    // 0x829b14: r0 = isNegative()
    //     0x829b14: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x829b18: add             SP, SP, #8
    // 0x829b1c: tbnz            w0, #4, #0x829b28
    // 0x829b20: ldur            d0, [fp, #-0x20]
    // 0x829b24: b               #0x829b34
    // 0x829b28: ldur            d0, [fp, #-0x20]
    // 0x829b2c: fcmp            d0, d0
    // 0x829b30: b.vc            #0x829b3c
    // 0x829b34: mov             v1.16b, v0.16b
    // 0x829b38: b               #0x829b40
    // 0x829b3c: ldur            d1, [fp, #-0x28]
    // 0x829b40: ldur            d0, [fp, #-0x18]
    // 0x829b44: fcmp            d0, d1
    // 0x829b48: b.vs            #0x829b58
    // 0x829b4c: b.le            #0x829b58
    // 0x829b50: mov             v1.16b, v0.16b
    // 0x829b54: b               #0x829b8c
    // 0x829b58: fcmp            d0, d1
    // 0x829b5c: b.vs            #0x829b64
    // 0x829b60: b.lt            #0x829b8c
    // 0x829b64: d2 = 0.000000
    //     0x829b64: eor             v2.16b, v2.16b, v2.16b
    // 0x829b68: fcmp            d0, d2
    // 0x829b6c: b.vs            #0x829b80
    // 0x829b70: b.ne            #0x829b80
    // 0x829b74: fadd            d2, d0, d1
    // 0x829b78: mov             v1.16b, v2.16b
    // 0x829b7c: b               #0x829b8c
    // 0x829b80: fcmp            d1, d1
    // 0x829b84: b.vs            #0x829b8c
    // 0x829b88: mov             v1.16b, v0.16b
    // 0x829b8c: ldur            d0, [fp, #-0x30]
    // 0x829b90: fmul            d2, d1, d0
    // 0x829b94: mov             v0.16b, v1.16b
    // 0x829b98: mov             v1.16b, v2.16b
    // 0x829b9c: b               #0x829cf0
    // 0x829ba0: ldr             x1, [fp, #0x20]
    // 0x829ba4: ldr             x2, [fp, #0x18]
    // 0x829ba8: ldur            x0, [fp, #-0x10]
    // 0x829bac: ldur            d0, [fp, #-0x18]
    // 0x829bb0: d2 = 0.000000
    //     0x829bb0: eor             v2.16b, v2.16b, v2.16b
    // 0x829bb4: LoadField: d1 = r1->field_1f
    //     0x829bb4: ldur            d1, [x1, #0x1f]
    // 0x829bb8: LoadField: d3 = r1->field_f
    //     0x829bb8: ldur            d3, [x1, #0xf]
    // 0x829bbc: fsub            d4, d1, d3
    // 0x829bc0: LoadField: d1 = r0->field_7
    //     0x829bc0: ldur            d1, [x0, #7]
    // 0x829bc4: stur            d1, [fp, #-0x30]
    // 0x829bc8: fmul            d3, d4, d1
    // 0x829bcc: stur            d3, [fp, #-0x28]
    // 0x829bd0: LoadField: d4 = r2->field_17
    //     0x829bd0: ldur            d4, [x2, #0x17]
    // 0x829bd4: LoadField: d5 = r2->field_7
    //     0x829bd4: ldur            d5, [x2, #7]
    // 0x829bd8: fsub            d6, d4, d5
    // 0x829bdc: stur            d6, [fp, #-0x20]
    // 0x829be0: fcmp            d3, d6
    // 0x829be4: b.vs            #0x829bf4
    // 0x829be8: b.le            #0x829bf4
    // 0x829bec: mov             v1.16b, v6.16b
    // 0x829bf0: b               #0x829c9c
    // 0x829bf4: fcmp            d3, d6
    // 0x829bf8: b.vs            #0x829c08
    // 0x829bfc: b.ge            #0x829c08
    // 0x829c00: mov             v1.16b, v3.16b
    // 0x829c04: b               #0x829c9c
    // 0x829c08: fcmp            d3, d2
    // 0x829c0c: b.vs            #0x829c14
    // 0x829c10: b.eq            #0x829c1c
    // 0x829c14: r0 = false
    //     0x829c14: add             x0, NULL, #0x30  ; false
    // 0x829c18: b               #0x829c20
    // 0x829c1c: r0 = true
    //     0x829c1c: add             x0, NULL, #0x20  ; true
    // 0x829c20: tbnz            w0, #4, #0x829c38
    // 0x829c24: fadd            d4, d3, d6
    // 0x829c28: fmul            d5, d4, d3
    // 0x829c2c: fmul            d3, d5, d6
    // 0x829c30: mov             v1.16b, v3.16b
    // 0x829c34: b               #0x829c9c
    // 0x829c38: tbnz            w0, #4, #0x829c7c
    // 0x829c3c: r0 = inline_Allocate_Double()
    //     0x829c3c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x829c40: add             x0, x0, #0x10
    //     0x829c44: cmp             x2, x0
    //     0x829c48: b.ls            #0x829f3c
    //     0x829c4c: str             x0, [THR, #0x60]  ; THR::top
    //     0x829c50: sub             x0, x0, #0xf
    //     0x829c54: mov             x2, #0xd108
    //     0x829c58: movk            x2, #3, lsl #16
    //     0x829c5c: stur            x2, [x0, #-1]
    // 0x829c60: StoreField: r0->field_7 = d6
    //     0x829c60: stur            d6, [x0, #7]
    // 0x829c64: SaveReg r0
    //     0x829c64: str             x0, [SP, #-8]!
    // 0x829c68: r0 = isNegative()
    //     0x829c68: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x829c6c: add             SP, SP, #8
    // 0x829c70: tbnz            w0, #4, #0x829c7c
    // 0x829c74: ldur            d0, [fp, #-0x20]
    // 0x829c78: b               #0x829c88
    // 0x829c7c: ldur            d0, [fp, #-0x20]
    // 0x829c80: fcmp            d0, d0
    // 0x829c84: b.vc            #0x829c94
    // 0x829c88: mov             v1.16b, v0.16b
    // 0x829c8c: ldur            d0, [fp, #-0x18]
    // 0x829c90: b               #0x829c9c
    // 0x829c94: ldur            d1, [fp, #-0x28]
    // 0x829c98: ldur            d0, [fp, #-0x18]
    // 0x829c9c: fcmp            d0, d1
    // 0x829ca0: b.vs            #0x829cb0
    // 0x829ca4: b.le            #0x829cb0
    // 0x829ca8: mov             v1.16b, v0.16b
    // 0x829cac: b               #0x829ce4
    // 0x829cb0: fcmp            d0, d1
    // 0x829cb4: b.vs            #0x829cbc
    // 0x829cb8: b.lt            #0x829ce4
    // 0x829cbc: d2 = 0.000000
    //     0x829cbc: eor             v2.16b, v2.16b, v2.16b
    // 0x829cc0: fcmp            d0, d2
    // 0x829cc4: b.vs            #0x829cd8
    // 0x829cc8: b.ne            #0x829cd8
    // 0x829ccc: fadd            d2, d0, d1
    // 0x829cd0: mov             v1.16b, v2.16b
    // 0x829cd4: b               #0x829ce4
    // 0x829cd8: fcmp            d1, d1
    // 0x829cdc: b.vs            #0x829ce4
    // 0x829ce0: mov             v1.16b, v0.16b
    // 0x829ce4: ldur            d0, [fp, #-0x30]
    // 0x829ce8: fdiv            d2, d1, d0
    // 0x829cec: mov             v0.16b, v2.16b
    // 0x829cf0: ldr             x3, [fp, #0x20]
    // 0x829cf4: ldur            x4, [fp, #-8]
    // 0x829cf8: LoadField: d2 = r3->field_f
    //     0x829cf8: ldur            d2, [x3, #0xf]
    // 0x829cfc: LoadField: d3 = r3->field_7
    //     0x829cfc: ldur            d3, [x3, #7]
    // 0x829d00: cmp             x4, #1
    // 0x829d04: b.gt            #0x829d3c
    // 0x829d08: cmp             x4, #0
    // 0x829d0c: b.gt            #0x829d28
    // 0x829d10: LoadField: d2 = r3->field_1f
    //     0x829d10: ldur            d2, [x3, #0x1f]
    // 0x829d14: fsub            d3, d2, d0
    // 0x829d18: LoadField: d2 = r3->field_17
    //     0x829d18: ldur            d2, [x3, #0x17]
    // 0x829d1c: fsub            d4, d2, d1
    // 0x829d20: mov             v2.16b, v4.16b
    // 0x829d24: b               #0x829d80
    // 0x829d28: LoadField: d2 = r3->field_1f
    //     0x829d28: ldur            d2, [x3, #0x1f]
    // 0x829d2c: fsub            d4, d2, d0
    // 0x829d30: mov             v2.16b, v3.16b
    // 0x829d34: mov             v3.16b, v4.16b
    // 0x829d38: b               #0x829d80
    // 0x829d3c: cmp             x4, #2
    // 0x829d40: b.gt            #0x829d54
    // 0x829d44: mov             v31.16b, v3.16b
    // 0x829d48: mov             v3.16b, v2.16b
    // 0x829d4c: mov             v2.16b, v31.16b
    // 0x829d50: b               #0x829d80
    // 0x829d54: lsl             x0, x4, #1
    // 0x829d58: cmp             w0, #6
    // 0x829d5c: b.ne            #0x829d74
    // 0x829d60: LoadField: d3 = r3->field_17
    //     0x829d60: ldur            d3, [x3, #0x17]
    // 0x829d64: fsub            d4, d3, d1
    // 0x829d68: mov             v3.16b, v2.16b
    // 0x829d6c: mov             v2.16b, v4.16b
    // 0x829d70: b               #0x829d80
    // 0x829d74: mov             v31.16b, v3.16b
    // 0x829d78: mov             v3.16b, v2.16b
    // 0x829d7c: mov             v2.16b, v31.16b
    // 0x829d80: stur            d3, [fp, #-0x30]
    // 0x829d84: stur            d2, [fp, #-0x38]
    // 0x829d88: fadd            d4, d2, d1
    // 0x829d8c: stur            d4, [fp, #-0x28]
    // 0x829d90: fadd            d1, d3, d0
    // 0x829d94: stur            d1, [fp, #-0x20]
    // 0x829d98: r0 = Rect()
    //     0x829d98: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x829d9c: ldur            d0, [fp, #-0x38]
    // 0x829da0: StoreField: r0->field_7 = d0
    //     0x829da0: stur            d0, [x0, #7]
    // 0x829da4: ldur            d0, [fp, #-0x30]
    // 0x829da8: StoreField: r0->field_f = d0
    //     0x829da8: stur            d0, [x0, #0xf]
    // 0x829dac: ldur            d0, [fp, #-0x28]
    // 0x829db0: StoreField: r0->field_17 = d0
    //     0x829db0: stur            d0, [x0, #0x17]
    // 0x829db4: ldur            d0, [fp, #-0x20]
    // 0x829db8: StoreField: r0->field_1f = d0
    //     0x829db8: stur            d0, [x0, #0x1f]
    // 0x829dbc: mov             x1, x0
    // 0x829dc0: b               #0x829ed0
    // 0x829dc4: ldr             x3, [fp, #0x20]
    // 0x829dc8: mov             x4, x2
    // 0x829dcc: ldr             x2, [fp, #0x18]
    // 0x829dd0: mov             v0.16b, v2.16b
    // 0x829dd4: cmp             x4, #5
    // 0x829dd8: b.gt            #0x829de8
    // 0x829ddc: cmp             x4, #4
    // 0x829de0: b.gt            #0x829e64
    // 0x829de4: b               #0x829df0
    // 0x829de8: cmp             x4, #6
    // 0x829dec: b.gt            #0x829e58
    // 0x829df0: r16 = Instance__MoveType
    //     0x829df0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53900] Obj!_MoveType@b661f1
    //     0x829df4: ldr             x16, [x16, #0x900]
    // 0x829df8: cmp             w1, w16
    // 0x829dfc: r16 = true
    //     0x829dfc: add             x16, NULL, #0x20  ; true
    // 0x829e00: r17 = false
    //     0x829e00: add             x17, NULL, #0x30  ; false
    // 0x829e04: csel            x4, x16, x17, eq
    // 0x829e08: LoadField: d1 = r0->field_7
    //     0x829e08: ldur            d1, [x0, #7]
    // 0x829e0c: r0 = inline_Allocate_Double()
    //     0x829e0c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x829e10: add             x0, x0, #0x10
    //     0x829e14: cmp             x1, x0
    //     0x829e18: b.ls            #0x829f64
    //     0x829e1c: str             x0, [THR, #0x60]  ; THR::top
    //     0x829e20: sub             x0, x0, #0xf
    //     0x829e24: mov             x1, #0xd108
    //     0x829e28: movk            x1, #3, lsl #16
    //     0x829e2c: stur            x1, [x0, #-1]
    // 0x829e30: StoreField: r0->field_7 = d0
    //     0x829e30: stur            d0, [x0, #7]
    // 0x829e34: ldr             x16, [fp, #0x38]
    // 0x829e38: stp             x0, x16, [SP, #-0x10]!
    // 0x829e3c: SaveReg r3
    //     0x829e3c: str             x3, [SP, #-8]!
    // 0x829e40: SaveReg d1
    //     0x829e40: str             d1, [SP, #-8]!
    // 0x829e44: stp             x4, x2, [SP, #-0x10]!
    // 0x829e48: r0 = _doAspectRatioV()
    //     0x829e48: bl              #0x82a1e0  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_doAspectRatioV
    // 0x829e4c: add             SP, SP, #0x30
    // 0x829e50: mov             x1, x0
    // 0x829e54: b               #0x829ed0
    // 0x829e58: lsl             x5, x4, #1
    // 0x829e5c: cmp             w5, #0xe
    // 0x829e60: b.ne            #0x829ecc
    // 0x829e64: r16 = Instance__MoveType
    //     0x829e64: add             x16, PP, #0x53, lsl #12  ; [pp+0x53908] Obj!_MoveType@b661d1
    //     0x829e68: ldr             x16, [x16, #0x908]
    // 0x829e6c: cmp             w1, w16
    // 0x829e70: r16 = true
    //     0x829e70: add             x16, NULL, #0x20  ; true
    // 0x829e74: r17 = false
    //     0x829e74: add             x17, NULL, #0x30  ; false
    // 0x829e78: csel            x4, x16, x17, eq
    // 0x829e7c: LoadField: d1 = r0->field_7
    //     0x829e7c: ldur            d1, [x0, #7]
    // 0x829e80: r0 = inline_Allocate_Double()
    //     0x829e80: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x829e84: add             x0, x0, #0x10
    //     0x829e88: cmp             x1, x0
    //     0x829e8c: b.ls            #0x829f84
    //     0x829e90: str             x0, [THR, #0x60]  ; THR::top
    //     0x829e94: sub             x0, x0, #0xf
    //     0x829e98: mov             x1, #0xd108
    //     0x829e9c: movk            x1, #3, lsl #16
    //     0x829ea0: stur            x1, [x0, #-1]
    // 0x829ea4: StoreField: r0->field_7 = d0
    //     0x829ea4: stur            d0, [x0, #7]
    // 0x829ea8: ldr             x16, [fp, #0x38]
    // 0x829eac: stp             x0, x16, [SP, #-0x10]!
    // 0x829eb0: SaveReg r3
    //     0x829eb0: str             x3, [SP, #-8]!
    // 0x829eb4: SaveReg d1
    //     0x829eb4: str             d1, [SP, #-8]!
    // 0x829eb8: stp             x4, x2, [SP, #-0x10]!
    // 0x829ebc: r0 = _doAspectRatioH()
    //     0x829ebc: bl              #0x829fa4  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_doAspectRatioH
    // 0x829ec0: add             SP, SP, #0x30
    // 0x829ec4: mov             x1, x0
    // 0x829ec8: b               #0x829ed0
    // 0x829ecc: mov             x1, x3
    // 0x829ed0: mov             x0, x1
    // 0x829ed4: b               #0x829ee0
    // 0x829ed8: ldr             x3, [fp, #0x20]
    // 0x829edc: mov             x0, x3
    // 0x829ee0: LeaveFrame
    //     0x829ee0: mov             SP, fp
    //     0x829ee4: ldp             fp, lr, [SP], #0x10
    // 0x829ee8: ret
    //     0x829ee8: ret             
    // 0x829eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829eec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829ef0: b               #0x829968
    // 0x829ef4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829ef4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x829ef8: stp             q2, q3, [SP, #-0x20]!
    // 0x829efc: stp             q0, q1, [SP, #-0x20]!
    // 0x829f00: stp             x0, x2, [SP, #-0x10]!
    // 0x829f04: r0 = AllocateDouble()
    //     0x829f04: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x829f08: mov             x1, x0
    // 0x829f0c: ldp             x0, x2, [SP], #0x10
    // 0x829f10: ldp             q0, q1, [SP], #0x20
    // 0x829f14: ldp             q2, q3, [SP], #0x20
    // 0x829f18: b               #0x829a44
    // 0x829f1c: stp             q2, q4, [SP, #-0x20]!
    // 0x829f20: stp             q0, q1, [SP, #-0x20]!
    // 0x829f24: SaveReg r1
    //     0x829f24: str             x1, [SP, #-8]!
    // 0x829f28: r0 = AllocateDouble()
    //     0x829f28: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x829f2c: RestoreReg r1
    //     0x829f2c: ldr             x1, [SP], #8
    // 0x829f30: ldp             q0, q1, [SP], #0x20
    // 0x829f34: ldp             q2, q4, [SP], #0x20
    // 0x829f38: b               #0x829b0c
    // 0x829f3c: stp             q3, q6, [SP, #-0x20]!
    // 0x829f40: stp             q1, q2, [SP, #-0x20]!
    // 0x829f44: SaveReg d0
    //     0x829f44: str             q0, [SP, #-0x10]!
    // 0x829f48: SaveReg r1
    //     0x829f48: str             x1, [SP, #-8]!
    // 0x829f4c: r0 = AllocateDouble()
    //     0x829f4c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x829f50: RestoreReg r1
    //     0x829f50: ldr             x1, [SP], #8
    // 0x829f54: RestoreReg d0
    //     0x829f54: ldr             q0, [SP], #0x10
    // 0x829f58: ldp             q1, q2, [SP], #0x20
    // 0x829f5c: ldp             q3, q6, [SP], #0x20
    // 0x829f60: b               #0x829c60
    // 0x829f64: stp             q0, q1, [SP, #-0x20]!
    // 0x829f68: stp             x3, x4, [SP, #-0x10]!
    // 0x829f6c: SaveReg r2
    //     0x829f6c: str             x2, [SP, #-8]!
    // 0x829f70: r0 = AllocateDouble()
    //     0x829f70: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x829f74: RestoreReg r2
    //     0x829f74: ldr             x2, [SP], #8
    // 0x829f78: ldp             x3, x4, [SP], #0x10
    // 0x829f7c: ldp             q0, q1, [SP], #0x20
    // 0x829f80: b               #0x829e30
    // 0x829f84: stp             q0, q1, [SP, #-0x20]!
    // 0x829f88: stp             x3, x4, [SP, #-0x10]!
    // 0x829f8c: SaveReg r2
    //     0x829f8c: str             x2, [SP, #-8]!
    // 0x829f90: r0 = AllocateDouble()
    //     0x829f90: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x829f94: RestoreReg r2
    //     0x829f94: ldr             x2, [SP], #8
    // 0x829f98: ldp             x3, x4, [SP], #0x10
    // 0x829f9c: ldp             q0, q1, [SP], #0x20
    // 0x829fa0: b               #0x829ea4
  }
  _ _doAspectRatioH(/* No info */) {
    // ** addr: 0x829fa4, size: 0x23c
    // 0x829fa4: EnterFrame
    //     0x829fa4: stp             fp, lr, [SP, #-0x10]!
    //     0x829fa8: mov             fp, SP
    // 0x829fac: AllocStack(0x28)
    //     0x829fac: sub             SP, SP, #0x28
    // 0x829fb0: CheckStackOverflow
    //     0x829fb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x829fb4: cmp             SP, x16
    //     0x829fb8: b.ls            #0x82a1ac
    // 0x829fbc: ldr             x0, [fp, #0x28]
    // 0x829fc0: LoadField: d0 = r0->field_17
    //     0x829fc0: ldur            d0, [x0, #0x17]
    // 0x829fc4: stur            d0, [fp, #-0x20]
    // 0x829fc8: LoadField: d1 = r0->field_7
    //     0x829fc8: ldur            d1, [x0, #7]
    // 0x829fcc: stur            d1, [fp, #-0x18]
    // 0x829fd0: fsub            d2, d0, d1
    // 0x829fd4: ldr             d3, [fp, #0x20]
    // 0x829fd8: fdiv            d4, d2, d3
    // 0x829fdc: ldr             x1, [fp, #0x18]
    // 0x829fe0: stur            d4, [fp, #-0x10]
    // 0x829fe4: LoadField: d2 = r1->field_1f
    //     0x829fe4: ldur            d2, [x1, #0x1f]
    // 0x829fe8: LoadField: d5 = r1->field_f
    //     0x829fe8: ldur            d5, [x1, #0xf]
    // 0x829fec: fsub            d6, d2, d5
    // 0x829ff0: stur            d6, [fp, #-8]
    // 0x829ff4: fcmp            d4, d6
    // 0x829ff8: b.vs            #0x82a008
    // 0x829ffc: b.le            #0x82a008
    // 0x82a000: mov             v0.16b, v6.16b
    // 0x82a004: b               #0x82a0a4
    // 0x82a008: fcmp            d4, d6
    // 0x82a00c: b.vs            #0x82a01c
    // 0x82a010: b.ge            #0x82a01c
    // 0x82a014: mov             v0.16b, v4.16b
    // 0x82a018: b               #0x82a0a4
    // 0x82a01c: d2 = 0.000000
    //     0x82a01c: eor             v2.16b, v2.16b, v2.16b
    // 0x82a020: fcmp            d4, d2
    // 0x82a024: b.vs            #0x82a02c
    // 0x82a028: b.eq            #0x82a034
    // 0x82a02c: r1 = false
    //     0x82a02c: add             x1, NULL, #0x30  ; false
    // 0x82a030: b               #0x82a038
    // 0x82a034: r1 = true
    //     0x82a034: add             x1, NULL, #0x20  ; true
    // 0x82a038: tbnz            w1, #4, #0x82a050
    // 0x82a03c: fadd            d5, d4, d6
    // 0x82a040: fmul            d7, d5, d4
    // 0x82a044: fmul            d4, d7, d6
    // 0x82a048: mov             v0.16b, v4.16b
    // 0x82a04c: b               #0x82a0a4
    // 0x82a050: tbnz            w1, #4, #0x82a094
    // 0x82a054: r1 = inline_Allocate_Double()
    //     0x82a054: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82a058: add             x1, x1, #0x10
    //     0x82a05c: cmp             x2, x1
    //     0x82a060: b.ls            #0x82a1b4
    //     0x82a064: str             x1, [THR, #0x60]  ; THR::top
    //     0x82a068: sub             x1, x1, #0xf
    //     0x82a06c: mov             x2, #0xd108
    //     0x82a070: movk            x2, #3, lsl #16
    //     0x82a074: stur            x2, [x1, #-1]
    // 0x82a078: StoreField: r1->field_7 = d6
    //     0x82a078: stur            d6, [x1, #7]
    // 0x82a07c: SaveReg r1
    //     0x82a07c: str             x1, [SP, #-8]!
    // 0x82a080: r0 = isNegative()
    //     0x82a080: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x82a084: add             SP, SP, #8
    // 0x82a088: tbnz            w0, #4, #0x82a094
    // 0x82a08c: ldur            d0, [fp, #-8]
    // 0x82a090: b               #0x82a0a4
    // 0x82a094: ldur            d0, [fp, #-8]
    // 0x82a098: fcmp            d0, d0
    // 0x82a09c: b.vs            #0x82a0a4
    // 0x82a0a0: ldur            d0, [fp, #-0x10]
    // 0x82a0a4: ldr             x0, [fp, #0x30]
    // 0x82a0a8: LoadField: d1 = r0->field_7
    //     0x82a0a8: ldur            d1, [x0, #7]
    // 0x82a0ac: fcmp            d1, d0
    // 0x82a0b0: b.vs            #0x82a0c4
    // 0x82a0b4: b.le            #0x82a0c4
    // 0x82a0b8: LoadField: d0 = r0->field_7
    //     0x82a0b8: ldur            d0, [x0, #7]
    // 0x82a0bc: mov             v1.16b, v0.16b
    // 0x82a0c0: b               #0x82a10c
    // 0x82a0c4: fcmp            d1, d0
    // 0x82a0c8: b.vs            #0x82a0d8
    // 0x82a0cc: b.ge            #0x82a0d8
    // 0x82a0d0: mov             v1.16b, v0.16b
    // 0x82a0d4: b               #0x82a10c
    // 0x82a0d8: d2 = 0.000000
    //     0x82a0d8: eor             v2.16b, v2.16b, v2.16b
    // 0x82a0dc: fcmp            d1, d2
    // 0x82a0e0: b.vs            #0x82a0f4
    // 0x82a0e4: b.ne            #0x82a0f4
    // 0x82a0e8: fadd            d2, d1, d0
    // 0x82a0ec: mov             v1.16b, v2.16b
    // 0x82a0f0: b               #0x82a10c
    // 0x82a0f4: fcmp            d0, d0
    // 0x82a0f8: b.vc            #0x82a104
    // 0x82a0fc: mov             v1.16b, v0.16b
    // 0x82a100: b               #0x82a10c
    // 0x82a104: LoadField: d0 = r0->field_7
    //     0x82a104: ldur            d0, [x0, #7]
    // 0x82a108: mov             v1.16b, v0.16b
    // 0x82a10c: ldr             d0, [fp, #0x20]
    // 0x82a110: ldr             x0, [fp, #0x10]
    // 0x82a114: stur            d1, [fp, #-0x28]
    // 0x82a118: fmul            d2, d1, d0
    // 0x82a11c: stur            d2, [fp, #-0x10]
    // 0x82a120: tbnz            w0, #4, #0x82a134
    // 0x82a124: ldur            d0, [fp, #-0x20]
    // 0x82a128: fsub            d3, d0, d2
    // 0x82a12c: mov             v0.16b, v3.16b
    // 0x82a130: b               #0x82a138
    // 0x82a134: ldur            d0, [fp, #-0x18]
    // 0x82a138: stur            d0, [fp, #-8]
    // 0x82a13c: ldr             x16, [fp, #0x28]
    // 0x82a140: SaveReg r16
    //     0x82a140: str             x16, [SP, #-8]!
    // 0x82a144: r0 = centerRight()
    //     0x82a144: bl              #0x65a1f0  ; [dart:ui] Rect::centerRight
    // 0x82a148: add             SP, SP, #8
    // 0x82a14c: LoadField: d0 = r0->field_f
    //     0x82a14c: ldur            d0, [x0, #0xf]
    // 0x82a150: ldur            d1, [fp, #-0x28]
    // 0x82a154: d2 = 2.000000
    //     0x82a154: fmov            d2, #2.00000000
    // 0x82a158: fdiv            d3, d1, d2
    // 0x82a15c: fsub            d2, d0, d3
    // 0x82a160: ldur            d0, [fp, #-0x10]
    // 0x82a164: ldur            d3, [fp, #-8]
    // 0x82a168: stur            d2, [fp, #-0x20]
    // 0x82a16c: fadd            d4, d3, d0
    // 0x82a170: stur            d4, [fp, #-0x18]
    // 0x82a174: fadd            d0, d2, d1
    // 0x82a178: stur            d0, [fp, #-0x10]
    // 0x82a17c: r0 = Rect()
    //     0x82a17c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x82a180: ldur            d0, [fp, #-8]
    // 0x82a184: StoreField: r0->field_7 = d0
    //     0x82a184: stur            d0, [x0, #7]
    // 0x82a188: ldur            d0, [fp, #-0x20]
    // 0x82a18c: StoreField: r0->field_f = d0
    //     0x82a18c: stur            d0, [x0, #0xf]
    // 0x82a190: ldur            d0, [fp, #-0x18]
    // 0x82a194: StoreField: r0->field_17 = d0
    //     0x82a194: stur            d0, [x0, #0x17]
    // 0x82a198: ldur            d0, [fp, #-0x10]
    // 0x82a19c: StoreField: r0->field_1f = d0
    //     0x82a19c: stur            d0, [x0, #0x1f]
    // 0x82a1a0: LeaveFrame
    //     0x82a1a0: mov             SP, fp
    //     0x82a1a4: ldp             fp, lr, [SP], #0x10
    // 0x82a1a8: ret
    //     0x82a1a8: ret             
    // 0x82a1ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a1ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a1b0: b               #0x829fbc
    // 0x82a1b4: stp             q4, q6, [SP, #-0x20]!
    // 0x82a1b8: stp             q2, q3, [SP, #-0x20]!
    // 0x82a1bc: stp             q0, q1, [SP, #-0x20]!
    // 0x82a1c0: SaveReg r0
    //     0x82a1c0: str             x0, [SP, #-8]!
    // 0x82a1c4: r0 = AllocateDouble()
    //     0x82a1c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82a1c8: mov             x1, x0
    // 0x82a1cc: RestoreReg r0
    //     0x82a1cc: ldr             x0, [SP], #8
    // 0x82a1d0: ldp             q0, q1, [SP], #0x20
    // 0x82a1d4: ldp             q2, q3, [SP], #0x20
    // 0x82a1d8: ldp             q4, q6, [SP], #0x20
    // 0x82a1dc: b               #0x82a078
  }
  _ _doAspectRatioV(/* No info */) {
    // ** addr: 0x82a1e0, size: 0x23c
    // 0x82a1e0: EnterFrame
    //     0x82a1e0: stp             fp, lr, [SP, #-0x10]!
    //     0x82a1e4: mov             fp, SP
    // 0x82a1e8: AllocStack(0x30)
    //     0x82a1e8: sub             SP, SP, #0x30
    // 0x82a1ec: CheckStackOverflow
    //     0x82a1ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a1f0: cmp             SP, x16
    //     0x82a1f4: b.ls            #0x82a3e8
    // 0x82a1f8: ldr             x0, [fp, #0x28]
    // 0x82a1fc: LoadField: d0 = r0->field_1f
    //     0x82a1fc: ldur            d0, [x0, #0x1f]
    // 0x82a200: stur            d0, [fp, #-0x20]
    // 0x82a204: LoadField: d1 = r0->field_f
    //     0x82a204: ldur            d1, [x0, #0xf]
    // 0x82a208: stur            d1, [fp, #-0x18]
    // 0x82a20c: fsub            d2, d0, d1
    // 0x82a210: ldr             d3, [fp, #0x20]
    // 0x82a214: fmul            d4, d2, d3
    // 0x82a218: ldr             x1, [fp, #0x18]
    // 0x82a21c: stur            d4, [fp, #-0x10]
    // 0x82a220: LoadField: d2 = r1->field_17
    //     0x82a220: ldur            d2, [x1, #0x17]
    // 0x82a224: LoadField: d5 = r1->field_7
    //     0x82a224: ldur            d5, [x1, #7]
    // 0x82a228: fsub            d6, d2, d5
    // 0x82a22c: stur            d6, [fp, #-8]
    // 0x82a230: fcmp            d4, d6
    // 0x82a234: b.vs            #0x82a244
    // 0x82a238: b.le            #0x82a244
    // 0x82a23c: mov             v0.16b, v6.16b
    // 0x82a240: b               #0x82a2e0
    // 0x82a244: fcmp            d4, d6
    // 0x82a248: b.vs            #0x82a258
    // 0x82a24c: b.ge            #0x82a258
    // 0x82a250: mov             v0.16b, v4.16b
    // 0x82a254: b               #0x82a2e0
    // 0x82a258: d2 = 0.000000
    //     0x82a258: eor             v2.16b, v2.16b, v2.16b
    // 0x82a25c: fcmp            d4, d2
    // 0x82a260: b.vs            #0x82a268
    // 0x82a264: b.eq            #0x82a270
    // 0x82a268: r1 = false
    //     0x82a268: add             x1, NULL, #0x30  ; false
    // 0x82a26c: b               #0x82a274
    // 0x82a270: r1 = true
    //     0x82a270: add             x1, NULL, #0x20  ; true
    // 0x82a274: tbnz            w1, #4, #0x82a28c
    // 0x82a278: fadd            d5, d4, d6
    // 0x82a27c: fmul            d7, d5, d4
    // 0x82a280: fmul            d4, d7, d6
    // 0x82a284: mov             v0.16b, v4.16b
    // 0x82a288: b               #0x82a2e0
    // 0x82a28c: tbnz            w1, #4, #0x82a2d0
    // 0x82a290: r1 = inline_Allocate_Double()
    //     0x82a290: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82a294: add             x1, x1, #0x10
    //     0x82a298: cmp             x2, x1
    //     0x82a29c: b.ls            #0x82a3f0
    //     0x82a2a0: str             x1, [THR, #0x60]  ; THR::top
    //     0x82a2a4: sub             x1, x1, #0xf
    //     0x82a2a8: mov             x2, #0xd108
    //     0x82a2ac: movk            x2, #3, lsl #16
    //     0x82a2b0: stur            x2, [x1, #-1]
    // 0x82a2b4: StoreField: r1->field_7 = d6
    //     0x82a2b4: stur            d6, [x1, #7]
    // 0x82a2b8: SaveReg r1
    //     0x82a2b8: str             x1, [SP, #-8]!
    // 0x82a2bc: r0 = isNegative()
    //     0x82a2bc: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x82a2c0: add             SP, SP, #8
    // 0x82a2c4: tbnz            w0, #4, #0x82a2d0
    // 0x82a2c8: ldur            d0, [fp, #-8]
    // 0x82a2cc: b               #0x82a2e0
    // 0x82a2d0: ldur            d0, [fp, #-8]
    // 0x82a2d4: fcmp            d0, d0
    // 0x82a2d8: b.vs            #0x82a2e0
    // 0x82a2dc: ldur            d0, [fp, #-0x10]
    // 0x82a2e0: ldr             x0, [fp, #0x30]
    // 0x82a2e4: LoadField: d1 = r0->field_7
    //     0x82a2e4: ldur            d1, [x0, #7]
    // 0x82a2e8: fcmp            d1, d0
    // 0x82a2ec: b.vs            #0x82a300
    // 0x82a2f0: b.le            #0x82a300
    // 0x82a2f4: LoadField: d0 = r0->field_7
    //     0x82a2f4: ldur            d0, [x0, #7]
    // 0x82a2f8: mov             v1.16b, v0.16b
    // 0x82a2fc: b               #0x82a348
    // 0x82a300: fcmp            d1, d0
    // 0x82a304: b.vs            #0x82a314
    // 0x82a308: b.ge            #0x82a314
    // 0x82a30c: mov             v1.16b, v0.16b
    // 0x82a310: b               #0x82a348
    // 0x82a314: d2 = 0.000000
    //     0x82a314: eor             v2.16b, v2.16b, v2.16b
    // 0x82a318: fcmp            d1, d2
    // 0x82a31c: b.vs            #0x82a330
    // 0x82a320: b.ne            #0x82a330
    // 0x82a324: fadd            d2, d1, d0
    // 0x82a328: mov             v1.16b, v2.16b
    // 0x82a32c: b               #0x82a348
    // 0x82a330: fcmp            d0, d0
    // 0x82a334: b.vc            #0x82a340
    // 0x82a338: mov             v1.16b, v0.16b
    // 0x82a33c: b               #0x82a348
    // 0x82a340: LoadField: d0 = r0->field_7
    //     0x82a340: ldur            d0, [x0, #7]
    // 0x82a344: mov             v1.16b, v0.16b
    // 0x82a348: ldr             d0, [fp, #0x20]
    // 0x82a34c: ldr             x0, [fp, #0x10]
    // 0x82a350: stur            d1, [fp, #-0x28]
    // 0x82a354: fdiv            d2, d1, d0
    // 0x82a358: stur            d2, [fp, #-0x10]
    // 0x82a35c: tbnz            w0, #4, #0x82a370
    // 0x82a360: ldur            d0, [fp, #-0x20]
    // 0x82a364: fsub            d3, d0, d2
    // 0x82a368: mov             v0.16b, v3.16b
    // 0x82a36c: b               #0x82a374
    // 0x82a370: ldur            d0, [fp, #-0x18]
    // 0x82a374: stur            d0, [fp, #-8]
    // 0x82a378: ldr             x16, [fp, #0x28]
    // 0x82a37c: SaveReg r16
    //     0x82a37c: str             x16, [SP, #-8]!
    // 0x82a380: r0 = topCenter()
    //     0x82a380: bl              #0x65a298  ; [dart:ui] Rect::topCenter
    // 0x82a384: add             SP, SP, #8
    // 0x82a388: LoadField: d0 = r0->field_7
    //     0x82a388: ldur            d0, [x0, #7]
    // 0x82a38c: ldur            d1, [fp, #-0x28]
    // 0x82a390: d2 = 2.000000
    //     0x82a390: fmov            d2, #2.00000000
    // 0x82a394: fdiv            d3, d1, d2
    // 0x82a398: fsub            d2, d0, d3
    // 0x82a39c: stur            d2, [fp, #-0x30]
    // 0x82a3a0: fadd            d0, d2, d1
    // 0x82a3a4: ldur            d1, [fp, #-0x10]
    // 0x82a3a8: ldur            d3, [fp, #-8]
    // 0x82a3ac: stur            d0, [fp, #-0x20]
    // 0x82a3b0: fadd            d4, d3, d1
    // 0x82a3b4: stur            d4, [fp, #-0x18]
    // 0x82a3b8: r0 = Rect()
    //     0x82a3b8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x82a3bc: ldur            d0, [fp, #-0x30]
    // 0x82a3c0: StoreField: r0->field_7 = d0
    //     0x82a3c0: stur            d0, [x0, #7]
    // 0x82a3c4: ldur            d0, [fp, #-8]
    // 0x82a3c8: StoreField: r0->field_f = d0
    //     0x82a3c8: stur            d0, [x0, #0xf]
    // 0x82a3cc: ldur            d0, [fp, #-0x20]
    // 0x82a3d0: StoreField: r0->field_17 = d0
    //     0x82a3d0: stur            d0, [x0, #0x17]
    // 0x82a3d4: ldur            d0, [fp, #-0x18]
    // 0x82a3d8: StoreField: r0->field_1f = d0
    //     0x82a3d8: stur            d0, [x0, #0x1f]
    // 0x82a3dc: LeaveFrame
    //     0x82a3dc: mov             SP, fp
    //     0x82a3e0: ldp             fp, lr, [SP], #0x10
    // 0x82a3e4: ret
    //     0x82a3e4: ret             
    // 0x82a3e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a3e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a3ec: b               #0x82a1f8
    // 0x82a3f0: stp             q4, q6, [SP, #-0x20]!
    // 0x82a3f4: stp             q2, q3, [SP, #-0x20]!
    // 0x82a3f8: stp             q0, q1, [SP, #-0x20]!
    // 0x82a3fc: SaveReg r0
    //     0x82a3fc: str             x0, [SP, #-8]!
    // 0x82a400: r0 = AllocateDouble()
    //     0x82a400: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82a404: mov             x1, x0
    // 0x82a408: RestoreReg r0
    //     0x82a408: ldr             x0, [SP], #8
    // 0x82a40c: ldp             q0, q1, [SP], #0x20
    // 0x82a410: ldp             q2, q3, [SP], #0x20
    // 0x82a414: ldp             q4, q6, [SP], #0x20
    // 0x82a418: b               #0x82a2b4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82a5dc, size: 0x6c
    // 0x82a5dc: EnterFrame
    //     0x82a5dc: stp             fp, lr, [SP, #-0x10]!
    //     0x82a5e0: mov             fp, SP
    // 0x82a5e4: ldr             x1, [fp, #0x10]
    // 0x82a5e8: LoadField: r2 = r1->field_17
    //     0x82a5e8: ldur            w2, [x1, #0x17]
    // 0x82a5ec: DecompressPointer r2
    //     0x82a5ec: add             x2, x2, HEAP, lsl #32
    // 0x82a5f0: LoadField: r1 = r2->field_f
    //     0x82a5f0: ldur            w1, [x2, #0xf]
    // 0x82a5f4: DecompressPointer r1
    //     0x82a5f4: add             x1, x1, HEAP, lsl #32
    // 0x82a5f8: LoadField: r0 = r2->field_13
    //     0x82a5f8: ldur            w0, [x2, #0x13]
    // 0x82a5fc: DecompressPointer r0
    //     0x82a5fc: add             x0, x0, HEAP, lsl #32
    // 0x82a600: LoadField: r2 = r1->field_b
    //     0x82a600: ldur            w2, [x1, #0xb]
    // 0x82a604: DecompressPointer r2
    //     0x82a604: add             x2, x2, HEAP, lsl #32
    // 0x82a608: cmp             w2, NULL
    // 0x82a60c: b.eq            #0x82a644
    // 0x82a610: LoadField: r1 = r2->field_b
    //     0x82a610: ldur            w1, [x2, #0xb]
    // 0x82a614: DecompressPointer r1
    //     0x82a614: add             x1, x1, HEAP, lsl #32
    // 0x82a618: StoreField: r1->field_4b = r0
    //     0x82a618: stur            w0, [x1, #0x4b]
    //     0x82a61c: ldurb           w16, [x1, #-1]
    //     0x82a620: ldurb           w17, [x0, #-1]
    //     0x82a624: and             x16, x17, x16, lsr #2
    //     0x82a628: tst             x16, HEAP, lsr #32
    //     0x82a62c: b.eq            #0x82a634
    //     0x82a630: bl              #0xd6826c
    // 0x82a634: r0 = Null
    //     0x82a634: mov             x0, NULL
    // 0x82a638: LeaveFrame
    //     0x82a638: mov             SP, fp
    //     0x82a63c: ldp             fp, lr, [SP], #0x10
    // 0x82a640: ret
    //     0x82a640: ret             
    // 0x82a644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82a644: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0x82a648, size: 0x54
    // 0x82a648: EnterFrame
    //     0x82a648: stp             fp, lr, [SP, #-0x10]!
    //     0x82a64c: mov             fp, SP
    // 0x82a650: ldr             x0, [fp, #0x18]
    // 0x82a654: LoadField: r1 = r0->field_17
    //     0x82a654: ldur            w1, [x0, #0x17]
    // 0x82a658: DecompressPointer r1
    //     0x82a658: add             x1, x1, HEAP, lsl #32
    // 0x82a65c: CheckStackOverflow
    //     0x82a65c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a660: cmp             SP, x16
    //     0x82a664: b.ls            #0x82a694
    // 0x82a668: LoadField: r0 = r1->field_f
    //     0x82a668: ldur            w0, [x1, #0xf]
    // 0x82a66c: DecompressPointer r0
    //     0x82a66c: add             x0, x0, HEAP, lsl #32
    // 0x82a670: r16 = Instance__MoveType
    //     0x82a670: add             x16, PP, #0x53, lsl #12  ; [pp+0x53910] Obj!_MoveType@b66211
    //     0x82a674: ldr             x16, [x16, #0x910]
    // 0x82a678: stp             x16, x0, [SP, #-0x10]!
    // 0x82a67c: r0 = _moveEnd()
    //     0x82a67c: bl              #0x8279b4  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_moveEnd
    // 0x82a680: add             SP, SP, #0x10
    // 0x82a684: r0 = Null
    //     0x82a684: mov             x0, NULL
    // 0x82a688: LeaveFrame
    //     0x82a688: mov             SP, fp
    //     0x82a68c: ldp             fp, lr, [SP], #0x10
    // 0x82a690: ret
    //     0x82a690: ret             
    // 0x82a694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a694: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a698: b               #0x82a668
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x82a69c, size: 0x64
    // 0x82a69c: EnterFrame
    //     0x82a69c: stp             fp, lr, [SP, #-0x10]!
    //     0x82a6a0: mov             fp, SP
    // 0x82a6a4: ldr             x0, [fp, #0x18]
    // 0x82a6a8: LoadField: r1 = r0->field_17
    //     0x82a6a8: ldur            w1, [x0, #0x17]
    // 0x82a6ac: DecompressPointer r1
    //     0x82a6ac: add             x1, x1, HEAP, lsl #32
    // 0x82a6b0: CheckStackOverflow
    //     0x82a6b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a6b4: cmp             SP, x16
    //     0x82a6b8: b.ls            #0x82a6f8
    // 0x82a6bc: LoadField: r0 = r1->field_f
    //     0x82a6bc: ldur            w0, [x1, #0xf]
    // 0x82a6c0: DecompressPointer r0
    //     0x82a6c0: add             x0, x0, HEAP, lsl #32
    // 0x82a6c4: ldr             x1, [fp, #0x10]
    // 0x82a6c8: LoadField: r2 = r1->field_b
    //     0x82a6c8: ldur            w2, [x1, #0xb]
    // 0x82a6cc: DecompressPointer r2
    //     0x82a6cc: add             x2, x2, HEAP, lsl #32
    // 0x82a6d0: r16 = Instance__MoveType
    //     0x82a6d0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53910] Obj!_MoveType@b66211
    //     0x82a6d4: ldr             x16, [x16, #0x910]
    // 0x82a6d8: stp             x16, x0, [SP, #-0x10]!
    // 0x82a6dc: SaveReg r2
    //     0x82a6dc: str             x2, [SP, #-8]!
    // 0x82a6e0: r0 = moveUpdate()
    //     0x82a6e0: bl              #0x827e40  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::moveUpdate
    // 0x82a6e4: add             SP, SP, #0x18
    // 0x82a6e8: r0 = Null
    //     0x82a6e8: mov             x0, NULL
    // 0x82a6ec: LeaveFrame
    //     0x82a6ec: mov             SP, fp
    //     0x82a6f0: ldp             fp, lr, [SP], #0x10
    // 0x82a6f4: ret
    //     0x82a6f4: ret             
    // 0x82a6f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a6f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a6fc: b               #0x82a6bc
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0x82a700, size: 0x54
    // 0x82a700: EnterFrame
    //     0x82a700: stp             fp, lr, [SP, #-0x10]!
    //     0x82a704: mov             fp, SP
    // 0x82a708: ldr             x0, [fp, #0x18]
    // 0x82a70c: LoadField: r1 = r0->field_17
    //     0x82a70c: ldur            w1, [x0, #0x17]
    // 0x82a710: DecompressPointer r1
    //     0x82a710: add             x1, x1, HEAP, lsl #32
    // 0x82a714: CheckStackOverflow
    //     0x82a714: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a718: cmp             SP, x16
    //     0x82a71c: b.ls            #0x82a74c
    // 0x82a720: LoadField: r0 = r1->field_f
    //     0x82a720: ldur            w0, [x1, #0xf]
    // 0x82a724: DecompressPointer r0
    //     0x82a724: add             x0, x0, HEAP, lsl #32
    // 0x82a728: r16 = Instance__MoveType
    //     0x82a728: add             x16, PP, #0x53, lsl #12  ; [pp+0x53908] Obj!_MoveType@b661d1
    //     0x82a72c: ldr             x16, [x16, #0x908]
    // 0x82a730: stp             x16, x0, [SP, #-0x10]!
    // 0x82a734: r0 = _moveEnd()
    //     0x82a734: bl              #0x8279b4  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_moveEnd
    // 0x82a738: add             SP, SP, #0x10
    // 0x82a73c: r0 = Null
    //     0x82a73c: mov             x0, NULL
    // 0x82a740: LeaveFrame
    //     0x82a740: mov             SP, fp
    //     0x82a744: ldp             fp, lr, [SP], #0x10
    // 0x82a748: ret
    //     0x82a748: ret             
    // 0x82a74c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a74c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a750: b               #0x82a720
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x82a754, size: 0x64
    // 0x82a754: EnterFrame
    //     0x82a754: stp             fp, lr, [SP, #-0x10]!
    //     0x82a758: mov             fp, SP
    // 0x82a75c: ldr             x0, [fp, #0x18]
    // 0x82a760: LoadField: r1 = r0->field_17
    //     0x82a760: ldur            w1, [x0, #0x17]
    // 0x82a764: DecompressPointer r1
    //     0x82a764: add             x1, x1, HEAP, lsl #32
    // 0x82a768: CheckStackOverflow
    //     0x82a768: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a76c: cmp             SP, x16
    //     0x82a770: b.ls            #0x82a7b0
    // 0x82a774: LoadField: r0 = r1->field_f
    //     0x82a774: ldur            w0, [x1, #0xf]
    // 0x82a778: DecompressPointer r0
    //     0x82a778: add             x0, x0, HEAP, lsl #32
    // 0x82a77c: ldr             x1, [fp, #0x10]
    // 0x82a780: LoadField: r2 = r1->field_b
    //     0x82a780: ldur            w2, [x1, #0xb]
    // 0x82a784: DecompressPointer r2
    //     0x82a784: add             x2, x2, HEAP, lsl #32
    // 0x82a788: r16 = Instance__MoveType
    //     0x82a788: add             x16, PP, #0x53, lsl #12  ; [pp+0x53908] Obj!_MoveType@b661d1
    //     0x82a78c: ldr             x16, [x16, #0x908]
    // 0x82a790: stp             x16, x0, [SP, #-0x10]!
    // 0x82a794: SaveReg r2
    //     0x82a794: str             x2, [SP, #-8]!
    // 0x82a798: r0 = moveUpdate()
    //     0x82a798: bl              #0x827e40  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::moveUpdate
    // 0x82a79c: add             SP, SP, #0x18
    // 0x82a7a0: r0 = Null
    //     0x82a7a0: mov             x0, NULL
    // 0x82a7a4: LeaveFrame
    //     0x82a7a4: mov             SP, fp
    //     0x82a7a8: ldp             fp, lr, [SP], #0x10
    // 0x82a7ac: ret
    //     0x82a7ac: ret             
    // 0x82a7b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a7b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a7b4: b               #0x82a774
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0x82a7b8, size: 0x54
    // 0x82a7b8: EnterFrame
    //     0x82a7b8: stp             fp, lr, [SP, #-0x10]!
    //     0x82a7bc: mov             fp, SP
    // 0x82a7c0: ldr             x0, [fp, #0x18]
    // 0x82a7c4: LoadField: r1 = r0->field_17
    //     0x82a7c4: ldur            w1, [x0, #0x17]
    // 0x82a7c8: DecompressPointer r1
    //     0x82a7c8: add             x1, x1, HEAP, lsl #32
    // 0x82a7cc: CheckStackOverflow
    //     0x82a7cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a7d0: cmp             SP, x16
    //     0x82a7d4: b.ls            #0x82a804
    // 0x82a7d8: LoadField: r0 = r1->field_f
    //     0x82a7d8: ldur            w0, [x1, #0xf]
    // 0x82a7dc: DecompressPointer r0
    //     0x82a7dc: add             x0, x0, HEAP, lsl #32
    // 0x82a7e0: r16 = Instance__MoveType
    //     0x82a7e0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53900] Obj!_MoveType@b661f1
    //     0x82a7e4: ldr             x16, [x16, #0x900]
    // 0x82a7e8: stp             x16, x0, [SP, #-0x10]!
    // 0x82a7ec: r0 = _moveEnd()
    //     0x82a7ec: bl              #0x8279b4  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_moveEnd
    // 0x82a7f0: add             SP, SP, #0x10
    // 0x82a7f4: r0 = Null
    //     0x82a7f4: mov             x0, NULL
    // 0x82a7f8: LeaveFrame
    //     0x82a7f8: mov             SP, fp
    //     0x82a7fc: ldp             fp, lr, [SP], #0x10
    // 0x82a800: ret
    //     0x82a800: ret             
    // 0x82a804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a804: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a808: b               #0x82a7d8
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x82a80c, size: 0x64
    // 0x82a80c: EnterFrame
    //     0x82a80c: stp             fp, lr, [SP, #-0x10]!
    //     0x82a810: mov             fp, SP
    // 0x82a814: ldr             x0, [fp, #0x18]
    // 0x82a818: LoadField: r1 = r0->field_17
    //     0x82a818: ldur            w1, [x0, #0x17]
    // 0x82a81c: DecompressPointer r1
    //     0x82a81c: add             x1, x1, HEAP, lsl #32
    // 0x82a820: CheckStackOverflow
    //     0x82a820: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a824: cmp             SP, x16
    //     0x82a828: b.ls            #0x82a868
    // 0x82a82c: LoadField: r0 = r1->field_f
    //     0x82a82c: ldur            w0, [x1, #0xf]
    // 0x82a830: DecompressPointer r0
    //     0x82a830: add             x0, x0, HEAP, lsl #32
    // 0x82a834: ldr             x1, [fp, #0x10]
    // 0x82a838: LoadField: r2 = r1->field_b
    //     0x82a838: ldur            w2, [x1, #0xb]
    // 0x82a83c: DecompressPointer r2
    //     0x82a83c: add             x2, x2, HEAP, lsl #32
    // 0x82a840: r16 = Instance__MoveType
    //     0x82a840: add             x16, PP, #0x53, lsl #12  ; [pp+0x53900] Obj!_MoveType@b661f1
    //     0x82a844: ldr             x16, [x16, #0x900]
    // 0x82a848: stp             x16, x0, [SP, #-0x10]!
    // 0x82a84c: SaveReg r2
    //     0x82a84c: str             x2, [SP, #-8]!
    // 0x82a850: r0 = moveUpdate()
    //     0x82a850: bl              #0x827e40  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::moveUpdate
    // 0x82a854: add             SP, SP, #0x18
    // 0x82a858: r0 = Null
    //     0x82a858: mov             x0, NULL
    // 0x82a85c: LeaveFrame
    //     0x82a85c: mov             SP, fp
    //     0x82a860: ldp             fp, lr, [SP], #0x10
    // 0x82a864: ret
    //     0x82a864: ret             
    // 0x82a868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a868: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a86c: b               #0x82a82c
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0x82a870, size: 0x54
    // 0x82a870: EnterFrame
    //     0x82a870: stp             fp, lr, [SP, #-0x10]!
    //     0x82a874: mov             fp, SP
    // 0x82a878: ldr             x0, [fp, #0x18]
    // 0x82a87c: LoadField: r1 = r0->field_17
    //     0x82a87c: ldur            w1, [x0, #0x17]
    // 0x82a880: DecompressPointer r1
    //     0x82a880: add             x1, x1, HEAP, lsl #32
    // 0x82a884: CheckStackOverflow
    //     0x82a884: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a888: cmp             SP, x16
    //     0x82a88c: b.ls            #0x82a8bc
    // 0x82a890: LoadField: r0 = r1->field_f
    //     0x82a890: ldur            w0, [x1, #0xf]
    // 0x82a894: DecompressPointer r0
    //     0x82a894: add             x0, x0, HEAP, lsl #32
    // 0x82a898: r16 = Instance__MoveType
    //     0x82a898: add             x16, PP, #0x53, lsl #12  ; [pp+0x53918] Obj!_MoveType@b66231
    //     0x82a89c: ldr             x16, [x16, #0x918]
    // 0x82a8a0: stp             x16, x0, [SP, #-0x10]!
    // 0x82a8a4: r0 = _moveEnd()
    //     0x82a8a4: bl              #0x8279b4  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_moveEnd
    // 0x82a8a8: add             SP, SP, #0x10
    // 0x82a8ac: r0 = Null
    //     0x82a8ac: mov             x0, NULL
    // 0x82a8b0: LeaveFrame
    //     0x82a8b0: mov             SP, fp
    //     0x82a8b4: ldp             fp, lr, [SP], #0x10
    // 0x82a8b8: ret
    //     0x82a8b8: ret             
    // 0x82a8bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a8bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a8c0: b               #0x82a890
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x82a8c4, size: 0x64
    // 0x82a8c4: EnterFrame
    //     0x82a8c4: stp             fp, lr, [SP, #-0x10]!
    //     0x82a8c8: mov             fp, SP
    // 0x82a8cc: ldr             x0, [fp, #0x18]
    // 0x82a8d0: LoadField: r1 = r0->field_17
    //     0x82a8d0: ldur            w1, [x0, #0x17]
    // 0x82a8d4: DecompressPointer r1
    //     0x82a8d4: add             x1, x1, HEAP, lsl #32
    // 0x82a8d8: CheckStackOverflow
    //     0x82a8d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a8dc: cmp             SP, x16
    //     0x82a8e0: b.ls            #0x82a920
    // 0x82a8e4: LoadField: r0 = r1->field_f
    //     0x82a8e4: ldur            w0, [x1, #0xf]
    // 0x82a8e8: DecompressPointer r0
    //     0x82a8e8: add             x0, x0, HEAP, lsl #32
    // 0x82a8ec: ldr             x1, [fp, #0x10]
    // 0x82a8f0: LoadField: r2 = r1->field_b
    //     0x82a8f0: ldur            w2, [x1, #0xb]
    // 0x82a8f4: DecompressPointer r2
    //     0x82a8f4: add             x2, x2, HEAP, lsl #32
    // 0x82a8f8: r16 = Instance__MoveType
    //     0x82a8f8: add             x16, PP, #0x53, lsl #12  ; [pp+0x53918] Obj!_MoveType@b66231
    //     0x82a8fc: ldr             x16, [x16, #0x918]
    // 0x82a900: stp             x16, x0, [SP, #-0x10]!
    // 0x82a904: SaveReg r2
    //     0x82a904: str             x2, [SP, #-8]!
    // 0x82a908: r0 = moveUpdate()
    //     0x82a908: bl              #0x827e40  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::moveUpdate
    // 0x82a90c: add             SP, SP, #0x18
    // 0x82a910: r0 = Null
    //     0x82a910: mov             x0, NULL
    // 0x82a914: LeaveFrame
    //     0x82a914: mov             SP, fp
    //     0x82a918: ldp             fp, lr, [SP], #0x10
    // 0x82a91c: ret
    //     0x82a91c: ret             
    // 0x82a920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a920: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a924: b               #0x82a8e4
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0x82a928, size: 0x54
    // 0x82a928: EnterFrame
    //     0x82a928: stp             fp, lr, [SP, #-0x10]!
    //     0x82a92c: mov             fp, SP
    // 0x82a930: ldr             x0, [fp, #0x18]
    // 0x82a934: LoadField: r1 = r0->field_17
    //     0x82a934: ldur            w1, [x0, #0x17]
    // 0x82a938: DecompressPointer r1
    //     0x82a938: add             x1, x1, HEAP, lsl #32
    // 0x82a93c: CheckStackOverflow
    //     0x82a93c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a940: cmp             SP, x16
    //     0x82a944: b.ls            #0x82a974
    // 0x82a948: LoadField: r0 = r1->field_f
    //     0x82a948: ldur            w0, [x1, #0xf]
    // 0x82a94c: DecompressPointer r0
    //     0x82a94c: add             x0, x0, HEAP, lsl #32
    // 0x82a950: r16 = Instance__MoveType
    //     0x82a950: add             x16, PP, #0x53, lsl #12  ; [pp+0x53920] Obj!_MoveType@b66251
    //     0x82a954: ldr             x16, [x16, #0x920]
    // 0x82a958: stp             x16, x0, [SP, #-0x10]!
    // 0x82a95c: r0 = _moveEnd()
    //     0x82a95c: bl              #0x8279b4  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_moveEnd
    // 0x82a960: add             SP, SP, #0x10
    // 0x82a964: r0 = Null
    //     0x82a964: mov             x0, NULL
    // 0x82a968: LeaveFrame
    //     0x82a968: mov             SP, fp
    //     0x82a96c: ldp             fp, lr, [SP], #0x10
    // 0x82a970: ret
    //     0x82a970: ret             
    // 0x82a974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a974: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a978: b               #0x82a948
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x82a97c, size: 0x64
    // 0x82a97c: EnterFrame
    //     0x82a97c: stp             fp, lr, [SP, #-0x10]!
    //     0x82a980: mov             fp, SP
    // 0x82a984: ldr             x0, [fp, #0x18]
    // 0x82a988: LoadField: r1 = r0->field_17
    //     0x82a988: ldur            w1, [x0, #0x17]
    // 0x82a98c: DecompressPointer r1
    //     0x82a98c: add             x1, x1, HEAP, lsl #32
    // 0x82a990: CheckStackOverflow
    //     0x82a990: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a994: cmp             SP, x16
    //     0x82a998: b.ls            #0x82a9d8
    // 0x82a99c: LoadField: r0 = r1->field_f
    //     0x82a99c: ldur            w0, [x1, #0xf]
    // 0x82a9a0: DecompressPointer r0
    //     0x82a9a0: add             x0, x0, HEAP, lsl #32
    // 0x82a9a4: ldr             x1, [fp, #0x10]
    // 0x82a9a8: LoadField: r2 = r1->field_b
    //     0x82a9a8: ldur            w2, [x1, #0xb]
    // 0x82a9ac: DecompressPointer r2
    //     0x82a9ac: add             x2, x2, HEAP, lsl #32
    // 0x82a9b0: r16 = Instance__MoveType
    //     0x82a9b0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53920] Obj!_MoveType@b66251
    //     0x82a9b4: ldr             x16, [x16, #0x920]
    // 0x82a9b8: stp             x16, x0, [SP, #-0x10]!
    // 0x82a9bc: SaveReg r2
    //     0x82a9bc: str             x2, [SP, #-8]!
    // 0x82a9c0: r0 = moveUpdate()
    //     0x82a9c0: bl              #0x827e40  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::moveUpdate
    // 0x82a9c4: add             SP, SP, #0x18
    // 0x82a9c8: r0 = Null
    //     0x82a9c8: mov             x0, NULL
    // 0x82a9cc: LeaveFrame
    //     0x82a9cc: mov             SP, fp
    //     0x82a9d0: ldp             fp, lr, [SP], #0x10
    // 0x82a9d4: ret
    //     0x82a9d4: ret             
    // 0x82a9d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a9d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a9dc: b               #0x82a99c
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0x82a9e0, size: 0x54
    // 0x82a9e0: EnterFrame
    //     0x82a9e0: stp             fp, lr, [SP, #-0x10]!
    //     0x82a9e4: mov             fp, SP
    // 0x82a9e8: ldr             x0, [fp, #0x18]
    // 0x82a9ec: LoadField: r1 = r0->field_17
    //     0x82a9ec: ldur            w1, [x0, #0x17]
    // 0x82a9f0: DecompressPointer r1
    //     0x82a9f0: add             x1, x1, HEAP, lsl #32
    // 0x82a9f4: CheckStackOverflow
    //     0x82a9f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82a9f8: cmp             SP, x16
    //     0x82a9fc: b.ls            #0x82aa2c
    // 0x82aa00: LoadField: r0 = r1->field_f
    //     0x82aa00: ldur            w0, [x1, #0xf]
    // 0x82aa04: DecompressPointer r0
    //     0x82aa04: add             x0, x0, HEAP, lsl #32
    // 0x82aa08: r16 = Instance__MoveType
    //     0x82aa08: add             x16, PP, #0x53, lsl #12  ; [pp+0x53928] Obj!_MoveType@b66271
    //     0x82aa0c: ldr             x16, [x16, #0x928]
    // 0x82aa10: stp             x16, x0, [SP, #-0x10]!
    // 0x82aa14: r0 = _moveEnd()
    //     0x82aa14: bl              #0x8279b4  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_moveEnd
    // 0x82aa18: add             SP, SP, #0x10
    // 0x82aa1c: r0 = Null
    //     0x82aa1c: mov             x0, NULL
    // 0x82aa20: LeaveFrame
    //     0x82aa20: mov             SP, fp
    //     0x82aa24: ldp             fp, lr, [SP], #0x10
    // 0x82aa28: ret
    //     0x82aa28: ret             
    // 0x82aa2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82aa2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82aa30: b               #0x82aa00
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x82aa34, size: 0x64
    // 0x82aa34: EnterFrame
    //     0x82aa34: stp             fp, lr, [SP, #-0x10]!
    //     0x82aa38: mov             fp, SP
    // 0x82aa3c: ldr             x0, [fp, #0x18]
    // 0x82aa40: LoadField: r1 = r0->field_17
    //     0x82aa40: ldur            w1, [x0, #0x17]
    // 0x82aa44: DecompressPointer r1
    //     0x82aa44: add             x1, x1, HEAP, lsl #32
    // 0x82aa48: CheckStackOverflow
    //     0x82aa48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82aa4c: cmp             SP, x16
    //     0x82aa50: b.ls            #0x82aa90
    // 0x82aa54: LoadField: r0 = r1->field_f
    //     0x82aa54: ldur            w0, [x1, #0xf]
    // 0x82aa58: DecompressPointer r0
    //     0x82aa58: add             x0, x0, HEAP, lsl #32
    // 0x82aa5c: ldr             x1, [fp, #0x10]
    // 0x82aa60: LoadField: r2 = r1->field_b
    //     0x82aa60: ldur            w2, [x1, #0xb]
    // 0x82aa64: DecompressPointer r2
    //     0x82aa64: add             x2, x2, HEAP, lsl #32
    // 0x82aa68: r16 = Instance__MoveType
    //     0x82aa68: add             x16, PP, #0x53, lsl #12  ; [pp+0x53928] Obj!_MoveType@b66271
    //     0x82aa6c: ldr             x16, [x16, #0x928]
    // 0x82aa70: stp             x16, x0, [SP, #-0x10]!
    // 0x82aa74: SaveReg r2
    //     0x82aa74: str             x2, [SP, #-8]!
    // 0x82aa78: r0 = moveUpdate()
    //     0x82aa78: bl              #0x827e40  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::moveUpdate
    // 0x82aa7c: add             SP, SP, #0x18
    // 0x82aa80: r0 = Null
    //     0x82aa80: mov             x0, NULL
    // 0x82aa84: LeaveFrame
    //     0x82aa84: mov             SP, fp
    //     0x82aa88: ldp             fp, lr, [SP], #0x10
    // 0x82aa8c: ret
    //     0x82aa8c: ret             
    // 0x82aa90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82aa90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82aa94: b               #0x82aa54
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0x82aa98, size: 0x54
    // 0x82aa98: EnterFrame
    //     0x82aa98: stp             fp, lr, [SP, #-0x10]!
    //     0x82aa9c: mov             fp, SP
    // 0x82aaa0: ldr             x0, [fp, #0x18]
    // 0x82aaa4: LoadField: r1 = r0->field_17
    //     0x82aaa4: ldur            w1, [x0, #0x17]
    // 0x82aaa8: DecompressPointer r1
    //     0x82aaa8: add             x1, x1, HEAP, lsl #32
    // 0x82aaac: CheckStackOverflow
    //     0x82aaac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82aab0: cmp             SP, x16
    //     0x82aab4: b.ls            #0x82aae4
    // 0x82aab8: LoadField: r0 = r1->field_f
    //     0x82aab8: ldur            w0, [x1, #0xf]
    // 0x82aabc: DecompressPointer r0
    //     0x82aabc: add             x0, x0, HEAP, lsl #32
    // 0x82aac0: r16 = Instance__MoveType
    //     0x82aac0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53930] Obj!_MoveType@b66291
    //     0x82aac4: ldr             x16, [x16, #0x930]
    // 0x82aac8: stp             x16, x0, [SP, #-0x10]!
    // 0x82aacc: r0 = _moveEnd()
    //     0x82aacc: bl              #0x8279b4  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_moveEnd
    // 0x82aad0: add             SP, SP, #0x10
    // 0x82aad4: r0 = Null
    //     0x82aad4: mov             x0, NULL
    // 0x82aad8: LeaveFrame
    //     0x82aad8: mov             SP, fp
    //     0x82aadc: ldp             fp, lr, [SP], #0x10
    // 0x82aae0: ret
    //     0x82aae0: ret             
    // 0x82aae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82aae4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82aae8: b               #0x82aab8
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x82aaec, size: 0x64
    // 0x82aaec: EnterFrame
    //     0x82aaec: stp             fp, lr, [SP, #-0x10]!
    //     0x82aaf0: mov             fp, SP
    // 0x82aaf4: ldr             x0, [fp, #0x18]
    // 0x82aaf8: LoadField: r1 = r0->field_17
    //     0x82aaf8: ldur            w1, [x0, #0x17]
    // 0x82aafc: DecompressPointer r1
    //     0x82aafc: add             x1, x1, HEAP, lsl #32
    // 0x82ab00: CheckStackOverflow
    //     0x82ab00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82ab04: cmp             SP, x16
    //     0x82ab08: b.ls            #0x82ab48
    // 0x82ab0c: LoadField: r0 = r1->field_f
    //     0x82ab0c: ldur            w0, [x1, #0xf]
    // 0x82ab10: DecompressPointer r0
    //     0x82ab10: add             x0, x0, HEAP, lsl #32
    // 0x82ab14: ldr             x1, [fp, #0x10]
    // 0x82ab18: LoadField: r2 = r1->field_b
    //     0x82ab18: ldur            w2, [x1, #0xb]
    // 0x82ab1c: DecompressPointer r2
    //     0x82ab1c: add             x2, x2, HEAP, lsl #32
    // 0x82ab20: r16 = Instance__MoveType
    //     0x82ab20: add             x16, PP, #0x53, lsl #12  ; [pp+0x53930] Obj!_MoveType@b66291
    //     0x82ab24: ldr             x16, [x16, #0x930]
    // 0x82ab28: stp             x16, x0, [SP, #-0x10]!
    // 0x82ab2c: SaveReg r2
    //     0x82ab2c: str             x2, [SP, #-8]!
    // 0x82ab30: r0 = moveUpdate()
    //     0x82ab30: bl              #0x827e40  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::moveUpdate
    // 0x82ab34: add             SP, SP, #0x18
    // 0x82ab38: r0 = Null
    //     0x82ab38: mov             x0, NULL
    // 0x82ab3c: LeaveFrame
    //     0x82ab3c: mov             SP, fp
    //     0x82ab40: ldp             fp, lr, [SP], #0x10
    // 0x82ab44: ret
    //     0x82ab44: ret             
    // 0x82ab48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ab48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ab4c: b               #0x82ab0c
  }
  get _ isAnimating(/* No info */) {
    // ** addr: 0x82b774, size: 0x6c
    // 0x82b774: EnterFrame
    //     0x82b774: stp             fp, lr, [SP, #-0x10]!
    //     0x82b778: mov             fp, SP
    // 0x82b77c: ldr             x1, [fp, #0x10]
    // 0x82b780: LoadField: r2 = r1->field_27
    //     0x82b780: ldur            w2, [x1, #0x27]
    // 0x82b784: DecompressPointer r2
    //     0x82b784: add             x2, x2, HEAP, lsl #32
    // 0x82b788: r16 = Sentinel
    //     0x82b788: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82b78c: cmp             w2, w16
    // 0x82b790: b.eq            #0x82b7d4
    // 0x82b794: LoadField: r1 = r2->field_2f
    //     0x82b794: ldur            w1, [x2, #0x2f]
    // 0x82b798: DecompressPointer r1
    //     0x82b798: add             x1, x1, HEAP, lsl #32
    // 0x82b79c: cmp             w1, NULL
    // 0x82b7a0: b.eq            #0x82b7c4
    // 0x82b7a4: LoadField: r2 = r1->field_7
    //     0x82b7a4: ldur            w2, [x1, #7]
    // 0x82b7a8: DecompressPointer r2
    //     0x82b7a8: add             x2, x2, HEAP, lsl #32
    // 0x82b7ac: cmp             w2, NULL
    // 0x82b7b0: r16 = true
    //     0x82b7b0: add             x16, NULL, #0x20  ; true
    // 0x82b7b4: r17 = false
    //     0x82b7b4: add             x17, NULL, #0x30  ; false
    // 0x82b7b8: csel            x1, x16, x17, ne
    // 0x82b7bc: mov             x0, x1
    // 0x82b7c0: b               #0x82b7c8
    // 0x82b7c4: r0 = false
    //     0x82b7c4: add             x0, NULL, #0x30  ; false
    // 0x82b7c8: LeaveFrame
    //     0x82b7c8: mov             SP, fp
    //     0x82b7cc: ldp             fp, lr, [SP], #0x10
    // 0x82b7d0: ret
    //     0x82b7d0: ret             
    // 0x82b7d4: r9 = _rectTweenController
    //     0x82b7d4: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c750] Field <ExtendedImageCropLayerState._rectTweenController@420005332>: late (offset: 0x28)
    //     0x82b7d8: ldr             x9, [x9, #0x750]
    // 0x82b7dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82b7dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ pointerDown(/* No info */) {
    // ** addr: 0x82b7e0, size: 0x88
    // 0x82b7e0: EnterFrame
    //     0x82b7e0: stp             fp, lr, [SP, #-0x10]!
    //     0x82b7e4: mov             fp, SP
    // 0x82b7e8: CheckStackOverflow
    //     0x82b7e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82b7ec: cmp             SP, x16
    //     0x82b7f0: b.ls            #0x82b860
    // 0x82b7f4: r1 = 2
    //     0x82b7f4: mov             x1, #2
    // 0x82b7f8: r0 = AllocateContext()
    //     0x82b7f8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82b7fc: mov             x1, x0
    // 0x82b800: ldr             x0, [fp, #0x18]
    // 0x82b804: StoreField: r1->field_f = r0
    //     0x82b804: stur            w0, [x1, #0xf]
    // 0x82b808: ldr             x2, [fp, #0x10]
    // 0x82b80c: StoreField: r1->field_13 = r2
    //     0x82b80c: stur            w2, [x1, #0x13]
    // 0x82b810: LoadField: r3 = r0->field_f
    //     0x82b810: ldur            w3, [x0, #0xf]
    // 0x82b814: DecompressPointer r3
    //     0x82b814: add             x3, x3, HEAP, lsl #32
    // 0x82b818: cmp             w3, NULL
    // 0x82b81c: b.eq            #0x82b850
    // 0x82b820: LoadField: r3 = r0->field_1f
    //     0x82b820: ldur            w3, [x0, #0x1f]
    // 0x82b824: DecompressPointer r3
    //     0x82b824: add             x3, x3, HEAP, lsl #32
    // 0x82b828: cmp             w3, w2
    // 0x82b82c: b.eq            #0x82b850
    // 0x82b830: mov             x2, x1
    // 0x82b834: r1 = Function '<anonymous closure>':.
    //     0x82b834: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c758] AnonymousClosure: (0x508af8), in [package:flutter/src/widgets/app.dart] _WidgetsAppState::didChangeLocales (0x50794c)
    //     0x82b838: ldr             x1, [x1, #0x758]
    // 0x82b83c: r0 = AllocateClosure()
    //     0x82b83c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82b840: ldr             x16, [fp, #0x18]
    // 0x82b844: stp             x0, x16, [SP, #-0x10]!
    // 0x82b848: r0 = setState()
    //     0x82b848: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82b84c: add             SP, SP, #0x10
    // 0x82b850: r0 = Null
    //     0x82b850: mov             x0, NULL
    // 0x82b854: LeaveFrame
    //     0x82b854: mov             SP, fp
    //     0x82b858: ldp             fp, lr, [SP], #0x10
    // 0x82b85c: ret
    //     0x82b85c: ret             
    // 0x82b860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b860: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b864: b               #0x82b7f4
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d5e7c, size: 0xd8
    // 0x9d5e7c: EnterFrame
    //     0x9d5e7c: stp             fp, lr, [SP, #-0x10]!
    //     0x9d5e80: mov             fp, SP
    // 0x9d5e84: AllocStack(0x8)
    //     0x9d5e84: sub             SP, SP, #8
    // 0x9d5e88: r0 = false
    //     0x9d5e88: add             x0, NULL, #0x30  ; false
    // 0x9d5e8c: CheckStackOverflow
    //     0x9d5e8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d5e90: cmp             SP, x16
    //     0x9d5e94: b.ls            #0x9d5f48
    // 0x9d5e98: ldr             x2, [fp, #0x10]
    // 0x9d5e9c: StoreField: r2->field_1f = r0
    //     0x9d5e9c: stur            w0, [x2, #0x1f]
    // 0x9d5ea0: LoadField: r0 = r2->field_b
    //     0x9d5ea0: ldur            w0, [x2, #0xb]
    // 0x9d5ea4: DecompressPointer r0
    //     0x9d5ea4: add             x0, x0, HEAP, lsl #32
    // 0x9d5ea8: cmp             w0, NULL
    // 0x9d5eac: b.eq            #0x9d5f50
    // 0x9d5eb0: r1 = <double>
    //     0x9d5eb0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d5eb4: r0 = AnimationController()
    //     0x9d5eb4: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d5eb8: stur            x0, [fp, #-8]
    // 0x9d5ebc: ldr             x16, [fp, #0x10]
    // 0x9d5ec0: stp             x16, x0, [SP, #-0x10]!
    // 0x9d5ec4: r16 = Instance_Duration
    //     0x9d5ec4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x9d5ec8: ldr             x16, [x16, #0x9e0]
    // 0x9d5ecc: SaveReg r16
    //     0x9d5ecc: str             x16, [SP, #-8]!
    // 0x9d5ed0: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9d5ed0: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9d5ed4: ldr             x4, [x4, #0xa0]
    // 0x9d5ed8: r0 = AnimationController()
    //     0x9d5ed8: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d5edc: add             SP, SP, #0x18
    // 0x9d5ee0: r1 = 1
    //     0x9d5ee0: mov             x1, #1
    // 0x9d5ee4: r0 = AllocateContext()
    //     0x9d5ee4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d5ee8: mov             x1, x0
    // 0x9d5eec: ldr             x0, [fp, #0x10]
    // 0x9d5ef0: StoreField: r1->field_f = r0
    //     0x9d5ef0: stur            w0, [x1, #0xf]
    // 0x9d5ef4: mov             x2, x1
    // 0x9d5ef8: r1 = Function '_doCropAutoCenterAnimation@420005332':.
    //     0x9d5ef8: add             x1, PP, #0x53, lsl #12  ; [pp+0x53960] AnonymousClosure: (0x829448), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::_doCropAutoCenterAnimation (0x829374)
    //     0x9d5efc: ldr             x1, [x1, #0x960]
    // 0x9d5f00: r0 = AllocateClosure()
    //     0x9d5f00: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d5f04: ldur            x16, [fp, #-8]
    // 0x9d5f08: stp             x0, x16, [SP, #-0x10]!
    // 0x9d5f0c: r0 = addActionListener()
    //     0x9d5f0c: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x9d5f10: add             SP, SP, #0x10
    // 0x9d5f14: ldur            x0, [fp, #-8]
    // 0x9d5f18: ldr             x1, [fp, #0x10]
    // 0x9d5f1c: StoreField: r1->field_27 = r0
    //     0x9d5f1c: stur            w0, [x1, #0x27]
    //     0x9d5f20: ldurb           w16, [x1, #-1]
    //     0x9d5f24: ldurb           w17, [x0, #-1]
    //     0x9d5f28: and             x16, x17, x16, lsr #2
    //     0x9d5f2c: tst             x16, HEAP, lsr #32
    //     0x9d5f30: b.eq            #0x9d5f38
    //     0x9d5f34: bl              #0xd6826c
    // 0x9d5f38: r0 = Null
    //     0x9d5f38: mov             x0, NULL
    // 0x9d5f3c: LeaveFrame
    //     0x9d5f3c: mov             SP, fp
    //     0x9d5f40: ldp             fp, lr, [SP], #0x10
    // 0x9d5f44: ret
    //     0x9d5f44: ret             
    // 0x9d5f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d5f48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d5f4c: b               #0x9d5e98
    // 0x9d5f50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d5f50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a0a8, size: 0x18
    // 0xa4a0a8: r4 = 7
    //     0xa4a0a8: mov             x4, #7
    // 0xa4a0ac: r1 = Function 'dispose':.
    //     0xa4a0ac: add             x17, PP, #0x53, lsl #12  ; [pp+0x537f8] AnonymousClosure: (0xa4a0c0), in [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::dispose (0xa4ea40)
    //     0xa4a0b0: ldr             x1, [x17, #0x7f8]
    // 0xa4a0b4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a0b4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a0b8: LoadField: r0 = r24->field_17
    //     0xa4a0b8: ldur            x0, [x24, #0x17]
    // 0xa4a0bc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a0c0, size: 0x48
    // 0xa4a0c0: EnterFrame
    //     0xa4a0c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a0c4: mov             fp, SP
    // 0xa4a0c8: ldr             x0, [fp, #0x10]
    // 0xa4a0cc: LoadField: r1 = r0->field_17
    //     0xa4a0cc: ldur            w1, [x0, #0x17]
    // 0xa4a0d0: DecompressPointer r1
    //     0xa4a0d0: add             x1, x1, HEAP, lsl #32
    // 0xa4a0d4: CheckStackOverflow
    //     0xa4a0d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a0d8: cmp             SP, x16
    //     0xa4a0dc: b.ls            #0xa4a100
    // 0xa4a0e0: LoadField: r0 = r1->field_f
    //     0xa4a0e0: ldur            w0, [x1, #0xf]
    // 0xa4a0e4: DecompressPointer r0
    //     0xa4a0e4: add             x0, x0, HEAP, lsl #32
    // 0xa4a0e8: SaveReg r0
    //     0xa4a0e8: str             x0, [SP, #-8]!
    // 0xa4a0ec: r0 = dispose()
    //     0xa4a0ec: bl              #0xa4ea40  ; [package:extended_image/src/editor/crop_layer.dart] ExtendedImageCropLayerState::dispose
    // 0xa4a0f0: add             SP, SP, #8
    // 0xa4a0f4: LeaveFrame
    //     0xa4a0f4: mov             SP, fp
    //     0xa4a0f8: ldp             fp, lr, [SP], #0x10
    // 0xa4a0fc: ret
    //     0xa4a0fc: ret             
    // 0xa4a100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a100: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a104: b               #0xa4a0e0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4ea40, size: 0x8c
    // 0xa4ea40: EnterFrame
    //     0xa4ea40: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ea44: mov             fp, SP
    // 0xa4ea48: CheckStackOverflow
    //     0xa4ea48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4ea4c: cmp             SP, x16
    //     0xa4ea50: b.ls            #0xa4eab8
    // 0xa4ea54: ldr             x0, [fp, #0x10]
    // 0xa4ea58: LoadField: r1 = r0->field_1b
    //     0xa4ea58: ldur            w1, [x0, #0x1b]
    // 0xa4ea5c: DecompressPointer r1
    //     0xa4ea5c: add             x1, x1, HEAP, lsl #32
    // 0xa4ea60: cmp             w1, NULL
    // 0xa4ea64: b.eq            #0xa4ea78
    // 0xa4ea68: SaveReg r1
    //     0xa4ea68: str             x1, [SP, #-8]!
    // 0xa4ea6c: r0 = cancel()
    //     0xa4ea6c: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0xa4ea70: add             SP, SP, #8
    // 0xa4ea74: ldr             x0, [fp, #0x10]
    // 0xa4ea78: LoadField: r1 = r0->field_27
    //     0xa4ea78: ldur            w1, [x0, #0x27]
    // 0xa4ea7c: DecompressPointer r1
    //     0xa4ea7c: add             x1, x1, HEAP, lsl #32
    // 0xa4ea80: r16 = Sentinel
    //     0xa4ea80: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4ea84: cmp             w1, w16
    // 0xa4ea88: b.eq            #0xa4eac0
    // 0xa4ea8c: SaveReg r1
    //     0xa4ea8c: str             x1, [SP, #-8]!
    // 0xa4ea90: r0 = dispose()
    //     0xa4ea90: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa4ea94: add             SP, SP, #8
    // 0xa4ea98: ldr             x16, [fp, #0x10]
    // 0xa4ea9c: SaveReg r16
    //     0xa4ea9c: str             x16, [SP, #-8]!
    // 0xa4eaa0: r0 = dispose()
    //     0xa4eaa0: bl              #0xa4eacc  ; [package:extended_image/src/editor/crop_layer.dart] _ExtendedImageCropLayerState&State&SingleTickerProviderStateMixin::dispose
    // 0xa4eaa4: add             SP, SP, #8
    // 0xa4eaa8: r0 = Null
    //     0xa4eaa8: mov             x0, NULL
    // 0xa4eaac: LeaveFrame
    //     0xa4eaac: mov             SP, fp
    //     0xa4eab0: ldp             fp, lr, [SP], #0x10
    // 0xa4eab4: ret
    //     0xa4eab4: ret             
    // 0xa4eab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4eab8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4eabc: b               #0xa4ea54
    // 0xa4eac0: r9 = _rectTweenController
    //     0xa4eac0: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c750] Field <ExtendedImageCropLayerState._rectTweenController@420005332>: late (offset: 0x28)
    //     0xa4eac4: ldr             x9, [x9, #0x750]
    // 0xa4eac8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4eac8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4216, size: 0x1c, field offset: 0xc
//   const constructor, 
class ExtendedImageCropLayer extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3f1a8, size: 0x30
    // 0xa3f1a8: EnterFrame
    //     0xa3f1a8: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f1ac: mov             fp, SP
    // 0xa3f1b0: r1 = <ExtendedImageCropLayer>
    //     0xa3f1b0: add             x1, PP, #0x51, lsl #12  ; [pp+0x51398] TypeArguments: <ExtendedImageCropLayer>
    //     0xa3f1b4: ldr             x1, [x1, #0x398]
    // 0xa3f1b8: r0 = ExtendedImageCropLayerState()
    //     0xa3f1b8: bl              #0xa3f1d8  ; AllocateExtendedImageCropLayerStateStub -> ExtendedImageCropLayerState (size=0x30)
    // 0xa3f1bc: r1 = false
    //     0xa3f1bc: add             x1, NULL, #0x30  ; false
    // 0xa3f1c0: StoreField: r0->field_1f = r1
    //     0xa3f1c0: stur            w1, [x0, #0x1f]
    // 0xa3f1c4: r1 = Sentinel
    //     0xa3f1c4: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3f1c8: StoreField: r0->field_27 = r1
    //     0xa3f1c8: stur            w1, [x0, #0x27]
    // 0xa3f1cc: LeaveFrame
    //     0xa3f1cc: mov             SP, fp
    //     0xa3f1d0: ldp             fp, lr, [SP], #0x10
    // 0xa3f1d4: ret
    //     0xa3f1d4: ret             
  }
}

// class id: 6001, size: 0x14, field offset: 0x14
enum _MoveType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15784, size: 0x5c
    // 0xb15784: EnterFrame
    //     0xb15784: stp             fp, lr, [SP, #-0x10]!
    //     0xb15788: mov             fp, SP
    // 0xb1578c: CheckStackOverflow
    //     0xb1578c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15790: cmp             SP, x16
    //     0xb15794: b.ls            #0xb157d8
    // 0xb15798: r1 = Null
    //     0xb15798: mov             x1, NULL
    // 0xb1579c: r2 = 4
    //     0xb1579c: mov             x2, #4
    // 0xb157a0: r0 = AllocateArray()
    //     0xb157a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb157a4: r17 = "_MoveType."
    //     0xb157a4: add             x17, PP, #0x55, lsl #12  ; [pp+0x55c58] "_MoveType."
    //     0xb157a8: ldr             x17, [x17, #0xc58]
    // 0xb157ac: StoreField: r0->field_f = r17
    //     0xb157ac: stur            w17, [x0, #0xf]
    // 0xb157b0: ldr             x1, [fp, #0x10]
    // 0xb157b4: LoadField: r2 = r1->field_f
    //     0xb157b4: ldur            w2, [x1, #0xf]
    // 0xb157b8: DecompressPointer r2
    //     0xb157b8: add             x2, x2, HEAP, lsl #32
    // 0xb157bc: StoreField: r0->field_13 = r2
    //     0xb157bc: stur            w2, [x0, #0x13]
    // 0xb157c0: SaveReg r0
    //     0xb157c0: str             x0, [SP, #-8]!
    // 0xb157c4: r0 = _interpolate()
    //     0xb157c4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb157c8: add             SP, SP, #8
    // 0xb157cc: LeaveFrame
    //     0xb157cc: mov             SP, fp
    //     0xb157d0: ldp             fp, lr, [SP], #0x10
    // 0xb157d4: ret
    //     0xb157d4: ret             
    // 0xb157d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb157d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb157dc: b               #0xb15798
  }
}

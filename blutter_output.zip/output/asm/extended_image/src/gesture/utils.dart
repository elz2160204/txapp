// lib: , url: package:extended_image/src/gesture/utils.dart

// class id: 1048939, size: 0x8
class :: {
}

// class id: 4478, size: 0x18, field offset: 0x8
class GestureAnimation extends Object {

  late Animation<double> _scaleAnimation; // offset: 0x14
  late Animation<Offset> _offsetAnimation; // offset: 0xc

  _ GestureAnimation(/* No info */) {
    // ** addr: 0x79b9d0, size: 0x1b4
    // 0x79b9d0: EnterFrame
    //     0x79b9d0: stp             fp, lr, [SP, #-0x10]!
    //     0x79b9d4: mov             fp, SP
    // 0x79b9d8: AllocStack(0x28)
    //     0x79b9d8: sub             SP, SP, #0x28
    // 0x79b9dc: SetupParameters(GestureAnimation this /* r3, fp-0x20 */, dynamic _ /* r4, fp-0x18 */, dynamic _ /* r5, fp-0x10 */, {dynamic scaleCallBack = Null /* r0, fp-0x8 */})
    //     0x79b9dc: mov             x0, x4
    //     0x79b9e0: ldur            w1, [x0, #0x13]
    //     0x79b9e4: add             x1, x1, HEAP, lsl #32
    //     0x79b9e8: sub             x2, x1, #6
    //     0x79b9ec: add             x3, fp, w2, sxtw #2
    //     0x79b9f0: ldr             x3, [x3, #0x20]
    //     0x79b9f4: stur            x3, [fp, #-0x20]
    //     0x79b9f8: add             x4, fp, w2, sxtw #2
    //     0x79b9fc: ldr             x4, [x4, #0x18]
    //     0x79ba00: stur            x4, [fp, #-0x18]
    //     0x79ba04: add             x5, fp, w2, sxtw #2
    //     0x79ba08: ldr             x5, [x5, #0x10]
    //     0x79ba0c: stur            x5, [fp, #-0x10]
    //     0x79ba10: ldur            w2, [x0, #0x1f]
    //     0x79ba14: add             x2, x2, HEAP, lsl #32
    //     0x79ba18: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c5c0] "scaleCallBack"
    //     0x79ba1c: ldr             x16, [x16, #0x5c0]
    //     0x79ba20: cmp             w2, w16
    //     0x79ba24: b.ne            #0x79ba44
    //     0x79ba28: ldur            w2, [x0, #0x23]
    //     0x79ba2c: add             x2, x2, HEAP, lsl #32
    //     0x79ba30: sub             w0, w1, w2
    //     0x79ba34: add             x1, fp, w0, sxtw #2
    //     0x79ba38: ldr             x1, [x1, #8]
    //     0x79ba3c: mov             x0, x1
    //     0x79ba40: b               #0x79ba48
    //     0x79ba44: mov             x0, NULL
    //     0x79ba48: stur            x0, [fp, #-8]
    // 0x79ba4c: CheckStackOverflow
    //     0x79ba4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79ba50: cmp             SP, x16
    //     0x79ba54: b.ls            #0x79bb7c
    // 0x79ba58: r1 = 3
    //     0x79ba58: mov             x1, #3
    // 0x79ba5c: r0 = AllocateContext()
    //     0x79ba5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79ba60: mov             x2, x0
    // 0x79ba64: ldur            x0, [fp, #-0x20]
    // 0x79ba68: stur            x2, [fp, #-0x28]
    // 0x79ba6c: StoreField: r2->field_f = r0
    //     0x79ba6c: stur            w0, [x2, #0xf]
    // 0x79ba70: ldur            x1, [fp, #-0x10]
    // 0x79ba74: StoreField: r2->field_13 = r1
    //     0x79ba74: stur            w1, [x2, #0x13]
    // 0x79ba78: ldur            x1, [fp, #-8]
    // 0x79ba7c: StoreField: r2->field_17 = r1
    //     0x79ba7c: stur            w1, [x2, #0x17]
    // 0x79ba80: r1 = Sentinel
    //     0x79ba80: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79ba84: StoreField: r0->field_b = r1
    //     0x79ba84: stur            w1, [x0, #0xb]
    // 0x79ba88: StoreField: r0->field_13 = r1
    //     0x79ba88: stur            w1, [x0, #0x13]
    // 0x79ba8c: r1 = <double>
    //     0x79ba8c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x79ba90: r0 = AnimationController()
    //     0x79ba90: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x79ba94: stur            x0, [fp, #-8]
    // 0x79ba98: ldur            x16, [fp, #-0x18]
    // 0x79ba9c: stp             x16, x0, [SP, #-0x10]!
    // 0x79baa0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x79baa0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x79baa4: r0 = AnimationController()
    //     0x79baa4: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x79baa8: add             SP, SP, #0x10
    // 0x79baac: ldur            x0, [fp, #-8]
    // 0x79bab0: ldur            x3, [fp, #-0x20]
    // 0x79bab4: StoreField: r3->field_7 = r0
    //     0x79bab4: stur            w0, [x3, #7]
    //     0x79bab8: ldurb           w16, [x3, #-1]
    //     0x79babc: ldurb           w17, [x0, #-1]
    //     0x79bac0: and             x16, x17, x16, lsr #2
    //     0x79bac4: tst             x16, HEAP, lsr #32
    //     0x79bac8: b.eq            #0x79bad0
    //     0x79bacc: bl              #0xd682ac
    // 0x79bad0: ldur            x2, [fp, #-0x28]
    // 0x79bad4: r1 = Function '<anonymous closure>':.
    //     0x79bad4: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c5c8] AnonymousClosure: (0x79bc38), in [package:extended_image/src/gesture/utils.dart] GestureAnimation::GestureAnimation (0x79b9d0)
    //     0x79bad8: ldr             x1, [x1, #0x5c8]
    // 0x79badc: r0 = AllocateClosure()
    //     0x79badc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79bae0: ldur            x16, [fp, #-8]
    // 0x79bae4: stp             x0, x16, [SP, #-0x10]!
    // 0x79bae8: r0 = addActionListener()
    //     0x79bae8: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x79baec: add             SP, SP, #0x10
    // 0x79baf0: ldur            x2, [fp, #-0x28]
    // 0x79baf4: LoadField: r0 = r2->field_17
    //     0x79baf4: ldur            w0, [x2, #0x17]
    // 0x79baf8: DecompressPointer r0
    //     0x79baf8: add             x0, x0, HEAP, lsl #32
    // 0x79bafc: cmp             w0, NULL
    // 0x79bb00: b.eq            #0x79bb6c
    // 0x79bb04: ldur            x0, [fp, #-0x20]
    // 0x79bb08: r1 = <double>
    //     0x79bb08: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x79bb0c: r0 = AnimationController()
    //     0x79bb0c: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x79bb10: stur            x0, [fp, #-8]
    // 0x79bb14: ldur            x16, [fp, #-0x18]
    // 0x79bb18: stp             x16, x0, [SP, #-0x10]!
    // 0x79bb1c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x79bb1c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x79bb20: r0 = AnimationController()
    //     0x79bb20: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x79bb24: add             SP, SP, #0x10
    // 0x79bb28: ldur            x0, [fp, #-8]
    // 0x79bb2c: ldur            x1, [fp, #-0x20]
    // 0x79bb30: StoreField: r1->field_f = r0
    //     0x79bb30: stur            w0, [x1, #0xf]
    //     0x79bb34: ldurb           w16, [x1, #-1]
    //     0x79bb38: ldurb           w17, [x0, #-1]
    //     0x79bb3c: and             x16, x17, x16, lsr #2
    //     0x79bb40: tst             x16, HEAP, lsr #32
    //     0x79bb44: b.eq            #0x79bb4c
    //     0x79bb48: bl              #0xd6826c
    // 0x79bb4c: ldur            x2, [fp, #-0x28]
    // 0x79bb50: r1 = Function '<anonymous closure>':.
    //     0x79bb50: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c5d0] AnonymousClosure: (0x79bb84), in [package:extended_image/src/gesture/utils.dart] GestureAnimation::GestureAnimation (0x79b9d0)
    //     0x79bb54: ldr             x1, [x1, #0x5d0]
    // 0x79bb58: r0 = AllocateClosure()
    //     0x79bb58: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79bb5c: ldur            x16, [fp, #-8]
    // 0x79bb60: stp             x0, x16, [SP, #-0x10]!
    // 0x79bb64: r0 = addActionListener()
    //     0x79bb64: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x79bb68: add             SP, SP, #0x10
    // 0x79bb6c: r0 = Null
    //     0x79bb6c: mov             x0, NULL
    // 0x79bb70: LeaveFrame
    //     0x79bb70: mov             SP, fp
    //     0x79bb74: ldp             fp, lr, [SP], #0x10
    // 0x79bb78: ret
    //     0x79bb78: ret             
    // 0x79bb7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79bb7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79bb80: b               #0x79ba58
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x79bb84, size: 0xb4
    // 0x79bb84: EnterFrame
    //     0x79bb84: stp             fp, lr, [SP, #-0x10]!
    //     0x79bb88: mov             fp, SP
    // 0x79bb8c: AllocStack(0x8)
    //     0x79bb8c: sub             SP, SP, #8
    // 0x79bb90: SetupParameters()
    //     0x79bb90: ldr             x0, [fp, #0x10]
    //     0x79bb94: ldur            w1, [x0, #0x17]
    //     0x79bb98: add             x1, x1, HEAP, lsl #32
    // 0x79bb9c: CheckStackOverflow
    //     0x79bb9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79bba0: cmp             SP, x16
    //     0x79bba4: b.ls            #0x79bc20
    // 0x79bba8: LoadField: r0 = r1->field_17
    //     0x79bba8: ldur            w0, [x1, #0x17]
    // 0x79bbac: DecompressPointer r0
    //     0x79bbac: add             x0, x0, HEAP, lsl #32
    // 0x79bbb0: stur            x0, [fp, #-8]
    // 0x79bbb4: LoadField: r2 = r1->field_f
    //     0x79bbb4: ldur            w2, [x1, #0xf]
    // 0x79bbb8: DecompressPointer r2
    //     0x79bbb8: add             x2, x2, HEAP, lsl #32
    // 0x79bbbc: LoadField: r1 = r2->field_13
    //     0x79bbbc: ldur            w1, [x2, #0x13]
    // 0x79bbc0: DecompressPointer r1
    //     0x79bbc0: add             x1, x1, HEAP, lsl #32
    // 0x79bbc4: r16 = Sentinel
    //     0x79bbc4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79bbc8: cmp             w1, w16
    // 0x79bbcc: b.eq            #0x79bc28
    // 0x79bbd0: LoadField: r2 = r1->field_f
    //     0x79bbd0: ldur            w2, [x1, #0xf]
    // 0x79bbd4: DecompressPointer r2
    //     0x79bbd4: add             x2, x2, HEAP, lsl #32
    // 0x79bbd8: LoadField: r3 = r1->field_b
    //     0x79bbd8: ldur            w3, [x1, #0xb]
    // 0x79bbdc: DecompressPointer r3
    //     0x79bbdc: add             x3, x3, HEAP, lsl #32
    // 0x79bbe0: stp             x3, x2, [SP, #-0x10]!
    // 0x79bbe4: r0 = evaluate()
    //     0x79bbe4: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x79bbe8: add             SP, SP, #0x10
    // 0x79bbec: mov             x1, x0
    // 0x79bbf0: ldur            x0, [fp, #-8]
    // 0x79bbf4: cmp             w0, NULL
    // 0x79bbf8: b.eq            #0x79bc34
    // 0x79bbfc: stp             x1, x0, [SP, #-0x10]!
    // 0x79bc00: ClosureCall
    //     0x79bc00: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x79bc04: ldur            x2, [x0, #0x1f]
    //     0x79bc08: blr             x2
    // 0x79bc0c: add             SP, SP, #0x10
    // 0x79bc10: r0 = Null
    //     0x79bc10: mov             x0, NULL
    // 0x79bc14: LeaveFrame
    //     0x79bc14: mov             SP, fp
    //     0x79bc18: ldp             fp, lr, [SP], #0x10
    // 0x79bc1c: ret
    //     0x79bc1c: ret             
    // 0x79bc20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79bc20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79bc24: b               #0x79bba8
    // 0x79bc28: r9 = _scaleAnimation
    //     0x79bc28: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c5d8] Field <GestureAnimation._scaleAnimation@413201704>: late (offset: 0x14)
    //     0x79bc2c: ldr             x9, [x9, #0x5d8]
    // 0x79bc30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x79bc30: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x79bc34: r0 = NullErrorSharedWithoutFPURegs()
    //     0x79bc34: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x79bc38, size: 0xb4
    // 0x79bc38: EnterFrame
    //     0x79bc38: stp             fp, lr, [SP, #-0x10]!
    //     0x79bc3c: mov             fp, SP
    // 0x79bc40: AllocStack(0x8)
    //     0x79bc40: sub             SP, SP, #8
    // 0x79bc44: SetupParameters()
    //     0x79bc44: ldr             x0, [fp, #0x10]
    //     0x79bc48: ldur            w1, [x0, #0x17]
    //     0x79bc4c: add             x1, x1, HEAP, lsl #32
    // 0x79bc50: CheckStackOverflow
    //     0x79bc50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79bc54: cmp             SP, x16
    //     0x79bc58: b.ls            #0x79bcd4
    // 0x79bc5c: LoadField: r0 = r1->field_13
    //     0x79bc5c: ldur            w0, [x1, #0x13]
    // 0x79bc60: DecompressPointer r0
    //     0x79bc60: add             x0, x0, HEAP, lsl #32
    // 0x79bc64: stur            x0, [fp, #-8]
    // 0x79bc68: LoadField: r2 = r1->field_f
    //     0x79bc68: ldur            w2, [x1, #0xf]
    // 0x79bc6c: DecompressPointer r2
    //     0x79bc6c: add             x2, x2, HEAP, lsl #32
    // 0x79bc70: LoadField: r1 = r2->field_b
    //     0x79bc70: ldur            w1, [x2, #0xb]
    // 0x79bc74: DecompressPointer r1
    //     0x79bc74: add             x1, x1, HEAP, lsl #32
    // 0x79bc78: r16 = Sentinel
    //     0x79bc78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79bc7c: cmp             w1, w16
    // 0x79bc80: b.eq            #0x79bcdc
    // 0x79bc84: LoadField: r2 = r1->field_f
    //     0x79bc84: ldur            w2, [x1, #0xf]
    // 0x79bc88: DecompressPointer r2
    //     0x79bc88: add             x2, x2, HEAP, lsl #32
    // 0x79bc8c: LoadField: r3 = r1->field_b
    //     0x79bc8c: ldur            w3, [x1, #0xb]
    // 0x79bc90: DecompressPointer r3
    //     0x79bc90: add             x3, x3, HEAP, lsl #32
    // 0x79bc94: stp             x3, x2, [SP, #-0x10]!
    // 0x79bc98: r0 = evaluate()
    //     0x79bc98: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x79bc9c: add             SP, SP, #0x10
    // 0x79bca0: mov             x1, x0
    // 0x79bca4: ldur            x0, [fp, #-8]
    // 0x79bca8: cmp             w0, NULL
    // 0x79bcac: b.eq            #0x79bce8
    // 0x79bcb0: stp             x1, x0, [SP, #-0x10]!
    // 0x79bcb4: ClosureCall
    //     0x79bcb4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x79bcb8: ldur            x2, [x0, #0x1f]
    //     0x79bcbc: blr             x2
    // 0x79bcc0: add             SP, SP, #0x10
    // 0x79bcc4: r0 = Null
    //     0x79bcc4: mov             x0, NULL
    // 0x79bcc8: LeaveFrame
    //     0x79bcc8: mov             SP, fp
    //     0x79bccc: ldp             fp, lr, [SP], #0x10
    // 0x79bcd0: ret
    //     0x79bcd0: ret             
    // 0x79bcd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79bcd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79bcd8: b               #0x79bc5c
    // 0x79bcdc: r9 = _offsetAnimation
    //     0x79bcdc: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c5e0] Field <GestureAnimation._offsetAnimation@413201704>: late (offset: 0xc)
    //     0x79bce0: ldr             x9, [x9, #0x5e0]
    // 0x79bce4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x79bce4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x79bce8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x79bce8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ animationOffset(/* No info */) {
    // ** addr: 0x82d224, size: 0xf4
    // 0x82d224: EnterFrame
    //     0x82d224: stp             fp, lr, [SP, #-0x10]!
    //     0x82d228: mov             fp, SP
    // 0x82d22c: AllocStack(0x8)
    //     0x82d22c: sub             SP, SP, #8
    // 0x82d230: CheckStackOverflow
    //     0x82d230: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82d234: cmp             SP, x16
    //     0x82d238: b.ls            #0x82d30c
    // 0x82d23c: ldr             x0, [fp, #0x20]
    // 0x82d240: LoadField: r2 = r0->field_7
    //     0x82d240: ldur            w2, [x0, #7]
    // 0x82d244: DecompressPointer r2
    //     0x82d244: add             x2, x2, HEAP, lsl #32
    // 0x82d248: stur            x2, [fp, #-8]
    // 0x82d24c: cmp             w2, NULL
    // 0x82d250: b.ne            #0x82d264
    // 0x82d254: r0 = Null
    //     0x82d254: mov             x0, NULL
    // 0x82d258: LeaveFrame
    //     0x82d258: mov             SP, fp
    //     0x82d25c: ldp             fp, lr, [SP], #0x10
    // 0x82d260: ret
    //     0x82d260: ret             
    // 0x82d264: ldr             x4, [fp, #0x18]
    // 0x82d268: ldr             x3, [fp, #0x10]
    // 0x82d26c: r1 = <Offset>
    //     0x82d26c: add             x1, PP, #0x20, lsl #12  ; [pp+0x207f8] TypeArguments: <Offset>
    //     0x82d270: ldr             x1, [x1, #0x7f8]
    // 0x82d274: r0 = Tween()
    //     0x82d274: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x82d278: mov             x1, x0
    // 0x82d27c: ldr             x0, [fp, #0x18]
    // 0x82d280: StoreField: r1->field_b = r0
    //     0x82d280: stur            w0, [x1, #0xb]
    // 0x82d284: ldr             x0, [fp, #0x10]
    // 0x82d288: StoreField: r1->field_f = r0
    //     0x82d288: stur            w0, [x1, #0xf]
    // 0x82d28c: ldur            x16, [fp, #-8]
    // 0x82d290: stp             x16, x1, [SP, #-0x10]!
    // 0x82d294: r0 = animate()
    //     0x82d294: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x82d298: add             SP, SP, #0x10
    // 0x82d29c: ldr             x1, [fp, #0x20]
    // 0x82d2a0: StoreField: r1->field_b = r0
    //     0x82d2a0: stur            w0, [x1, #0xb]
    //     0x82d2a4: ldurb           w16, [x1, #-1]
    //     0x82d2a8: ldurb           w17, [x0, #-1]
    //     0x82d2ac: and             x16, x17, x16, lsr #2
    //     0x82d2b0: tst             x16, HEAP, lsr #32
    //     0x82d2b4: b.eq            #0x82d2bc
    //     0x82d2b8: bl              #0xd6826c
    // 0x82d2bc: LoadField: r0 = r1->field_7
    //     0x82d2bc: ldur            w0, [x1, #7]
    // 0x82d2c0: DecompressPointer r0
    //     0x82d2c0: add             x0, x0, HEAP, lsl #32
    // 0x82d2c4: stur            x0, [fp, #-8]
    // 0x82d2c8: cmp             w0, NULL
    // 0x82d2cc: b.eq            #0x82d314
    // 0x82d2d0: stp             xzr, x0, [SP, #-0x10]!
    // 0x82d2d4: r0 = value=()
    //     0x82d2d4: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x82d2d8: add             SP, SP, #0x10
    // 0x82d2dc: ldur            x16, [fp, #-8]
    // 0x82d2e0: r30 = 0.400000
    //     0x82d2e0: add             lr, PP, #0x42, lsl #12  ; [pp+0x42020] 0.4
    //     0x82d2e4: ldr             lr, [lr, #0x20]
    // 0x82d2e8: stp             lr, x16, [SP, #-0x10]!
    // 0x82d2ec: r4 = const [0, 0x2, 0x2, 0x1, velocity, 0x1, null]
    //     0x82d2ec: add             x4, PP, #0x37, lsl #12  ; [pp+0x37a40] List(7) [0, 0x2, 0x2, 0x1, "velocity", 0x1, Null]
    //     0x82d2f0: ldr             x4, [x4, #0xa40]
    // 0x82d2f4: r0 = fling()
    //     0x82d2f4: bl              #0x82d318  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0x82d2f8: add             SP, SP, #0x10
    // 0x82d2fc: r0 = Null
    //     0x82d2fc: mov             x0, NULL
    // 0x82d300: LeaveFrame
    //     0x82d300: mov             SP, fp
    //     0x82d304: ldp             fp, lr, [SP], #0x10
    // 0x82d308: ret
    //     0x82d308: ret             
    // 0x82d30c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d30c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d310: b               #0x82d23c
    // 0x82d314: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82d314: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ animationScale(/* No info */) {
    // ** addr: 0x82da54, size: 0x128
    // 0x82da54: EnterFrame
    //     0x82da54: stp             fp, lr, [SP, #-0x10]!
    //     0x82da58: mov             fp, SP
    // 0x82da5c: AllocStack(0x8)
    //     0x82da5c: sub             SP, SP, #8
    // 0x82da60: CheckStackOverflow
    //     0x82da60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82da64: cmp             SP, x16
    //     0x82da68: b.ls            #0x82db60
    // 0x82da6c: ldr             x0, [fp, #0x28]
    // 0x82da70: LoadField: r2 = r0->field_f
    //     0x82da70: ldur            w2, [x0, #0xf]
    // 0x82da74: DecompressPointer r2
    //     0x82da74: add             x2, x2, HEAP, lsl #32
    // 0x82da78: stur            x2, [fp, #-8]
    // 0x82da7c: cmp             w2, NULL
    // 0x82da80: b.ne            #0x82da94
    // 0x82da84: r0 = Null
    //     0x82da84: mov             x0, NULL
    // 0x82da88: LeaveFrame
    //     0x82da88: mov             SP, fp
    //     0x82da8c: ldp             fp, lr, [SP], #0x10
    // 0x82da90: ret
    //     0x82da90: ret             
    // 0x82da94: ldr             x4, [fp, #0x20]
    // 0x82da98: ldr             x3, [fp, #0x18]
    // 0x82da9c: ldr             d0, [fp, #0x10]
    // 0x82daa0: r1 = <double>
    //     0x82daa0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x82daa4: r0 = Tween()
    //     0x82daa4: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x82daa8: mov             x1, x0
    // 0x82daac: ldr             x0, [fp, #0x20]
    // 0x82dab0: StoreField: r1->field_b = r0
    //     0x82dab0: stur            w0, [x1, #0xb]
    // 0x82dab4: ldr             x0, [fp, #0x18]
    // 0x82dab8: StoreField: r1->field_f = r0
    //     0x82dab8: stur            w0, [x1, #0xf]
    // 0x82dabc: ldur            x16, [fp, #-8]
    // 0x82dac0: stp             x16, x1, [SP, #-0x10]!
    // 0x82dac4: r0 = animate()
    //     0x82dac4: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x82dac8: add             SP, SP, #0x10
    // 0x82dacc: ldr             x1, [fp, #0x28]
    // 0x82dad0: StoreField: r1->field_13 = r0
    //     0x82dad0: stur            w0, [x1, #0x13]
    //     0x82dad4: ldurb           w16, [x1, #-1]
    //     0x82dad8: ldurb           w17, [x0, #-1]
    //     0x82dadc: and             x16, x17, x16, lsr #2
    //     0x82dae0: tst             x16, HEAP, lsr #32
    //     0x82dae4: b.eq            #0x82daec
    //     0x82dae8: bl              #0xd6826c
    // 0x82daec: LoadField: r0 = r1->field_f
    //     0x82daec: ldur            w0, [x1, #0xf]
    // 0x82daf0: DecompressPointer r0
    //     0x82daf0: add             x0, x0, HEAP, lsl #32
    // 0x82daf4: stur            x0, [fp, #-8]
    // 0x82daf8: cmp             w0, NULL
    // 0x82dafc: b.eq            #0x82db68
    // 0x82db00: stp             xzr, x0, [SP, #-0x10]!
    // 0x82db04: r0 = value=()
    //     0x82db04: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x82db08: add             SP, SP, #0x10
    // 0x82db0c: ldr             d0, [fp, #0x10]
    // 0x82db10: r0 = inline_Allocate_Double()
    //     0x82db10: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x82db14: add             x0, x0, #0x10
    //     0x82db18: cmp             x1, x0
    //     0x82db1c: b.ls            #0x82db6c
    //     0x82db20: str             x0, [THR, #0x60]  ; THR::top
    //     0x82db24: sub             x0, x0, #0xf
    //     0x82db28: mov             x1, #0xd108
    //     0x82db2c: movk            x1, #3, lsl #16
    //     0x82db30: stur            x1, [x0, #-1]
    // 0x82db34: StoreField: r0->field_7 = d0
    //     0x82db34: stur            d0, [x0, #7]
    // 0x82db38: ldur            x16, [fp, #-8]
    // 0x82db3c: stp             x0, x16, [SP, #-0x10]!
    // 0x82db40: r4 = const [0, 0x2, 0x2, 0x1, velocity, 0x1, null]
    //     0x82db40: add             x4, PP, #0x37, lsl #12  ; [pp+0x37a40] List(7) [0, 0x2, 0x2, 0x1, "velocity", 0x1, Null]
    //     0x82db44: ldr             x4, [x4, #0xa40]
    // 0x82db48: r0 = fling()
    //     0x82db48: bl              #0x82d318  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0x82db4c: add             SP, SP, #0x10
    // 0x82db50: r0 = Null
    //     0x82db50: mov             x0, NULL
    // 0x82db54: LeaveFrame
    //     0x82db54: mov             SP, fp
    //     0x82db58: ldp             fp, lr, [SP], #0x10
    // 0x82db5c: ret
    //     0x82db5c: ret             
    // 0x82db60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82db60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82db64: b               #0x82da6c
    // 0x82db68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82db68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82db6c: SaveReg d0
    //     0x82db6c: str             q0, [SP, #-0x10]!
    // 0x82db70: r0 = AllocateDouble()
    //     0x82db70: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82db74: RestoreReg d0
    //     0x82db74: ldr             q0, [SP], #0x10
    // 0x82db78: b               #0x82db34
  }
  _ stop(/* No info */) {
    // ** addr: 0x82ece0, size: 0x74
    // 0x82ece0: EnterFrame
    //     0x82ece0: stp             fp, lr, [SP, #-0x10]!
    //     0x82ece4: mov             fp, SP
    // 0x82ece8: CheckStackOverflow
    //     0x82ece8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82ecec: cmp             SP, x16
    //     0x82ecf0: b.ls            #0x82ed4c
    // 0x82ecf4: ldr             x0, [fp, #0x10]
    // 0x82ecf8: LoadField: r1 = r0->field_7
    //     0x82ecf8: ldur            w1, [x0, #7]
    // 0x82ecfc: DecompressPointer r1
    //     0x82ecfc: add             x1, x1, HEAP, lsl #32
    // 0x82ed00: cmp             w1, NULL
    // 0x82ed04: b.eq            #0x82ed1c
    // 0x82ed08: SaveReg r1
    //     0x82ed08: str             x1, [SP, #-8]!
    // 0x82ed0c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x82ed0c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x82ed10: r0 = stop()
    //     0x82ed10: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x82ed14: add             SP, SP, #8
    // 0x82ed18: ldr             x0, [fp, #0x10]
    // 0x82ed1c: LoadField: r1 = r0->field_f
    //     0x82ed1c: ldur            w1, [x0, #0xf]
    // 0x82ed20: DecompressPointer r1
    //     0x82ed20: add             x1, x1, HEAP, lsl #32
    // 0x82ed24: cmp             w1, NULL
    // 0x82ed28: b.eq            #0x82ed3c
    // 0x82ed2c: SaveReg r1
    //     0x82ed2c: str             x1, [SP, #-8]!
    // 0x82ed30: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x82ed30: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x82ed34: r0 = stop()
    //     0x82ed34: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x82ed38: add             SP, SP, #8
    // 0x82ed3c: r0 = Null
    //     0x82ed3c: mov             x0, NULL
    // 0x82ed40: LeaveFrame
    //     0x82ed40: mov             SP, fp
    //     0x82ed44: ldp             fp, lr, [SP], #0x10
    // 0x82ed48: ret
    //     0x82ed48: ret             
    // 0x82ed4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ed4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ed50: b               #0x82ecf4
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4f000, size: 0x80
    // 0xa4f000: EnterFrame
    //     0xa4f000: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f004: mov             fp, SP
    // 0xa4f008: CheckStackOverflow
    //     0xa4f008: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f00c: cmp             SP, x16
    //     0xa4f010: b.ls            #0xa4f078
    // 0xa4f014: ldr             x0, [fp, #0x10]
    // 0xa4f018: LoadField: r1 = r0->field_7
    //     0xa4f018: ldur            w1, [x0, #7]
    // 0xa4f01c: DecompressPointer r1
    //     0xa4f01c: add             x1, x1, HEAP, lsl #32
    // 0xa4f020: cmp             w1, NULL
    // 0xa4f024: b.eq            #0xa4f038
    // 0xa4f028: SaveReg r1
    //     0xa4f028: str             x1, [SP, #-8]!
    // 0xa4f02c: r0 = dispose()
    //     0xa4f02c: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa4f030: add             SP, SP, #8
    // 0xa4f034: ldr             x0, [fp, #0x10]
    // 0xa4f038: StoreField: r0->field_7 = rNULL
    //     0xa4f038: stur            NULL, [x0, #7]
    // 0xa4f03c: LoadField: r1 = r0->field_f
    //     0xa4f03c: ldur            w1, [x0, #0xf]
    // 0xa4f040: DecompressPointer r1
    //     0xa4f040: add             x1, x1, HEAP, lsl #32
    // 0xa4f044: cmp             w1, NULL
    // 0xa4f048: b.ne            #0xa4f054
    // 0xa4f04c: mov             x1, x0
    // 0xa4f050: b               #0xa4f064
    // 0xa4f054: SaveReg r1
    //     0xa4f054: str             x1, [SP, #-8]!
    // 0xa4f058: r0 = dispose()
    //     0xa4f058: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa4f05c: add             SP, SP, #8
    // 0xa4f060: ldr             x1, [fp, #0x10]
    // 0xa4f064: StoreField: r1->field_f = rNULL
    //     0xa4f064: stur            NULL, [x1, #0xf]
    // 0xa4f068: r0 = Null
    //     0xa4f068: mov             x0, NULL
    // 0xa4f06c: LeaveFrame
    //     0xa4f06c: mov             SP, fp
    //     0xa4f070: ldp             fp, lr, [SP], #0x10
    // 0xa4f074: ret
    //     0xa4f074: ret             
    // 0xa4f078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f07c: b               #0xa4f014
  }
}

// class id: 4479, size: 0x58, field offset: 0x8
class GestureConfig extends Object {
}

// class id: 4480, size: 0x40, field offset: 0x8
class GestureDetails extends Object {

  _ calculateFinalDestinationRect(/* No info */) {
    // ** addr: 0x65999c, size: 0x20c
    // 0x65999c: EnterFrame
    //     0x65999c: stp             fp, lr, [SP, #-0x10]!
    //     0x6599a0: mov             fp, SP
    // 0x6599a4: AllocStack(0x10)
    //     0x6599a4: sub             SP, SP, #0x10
    // 0x6599a8: CheckStackOverflow
    //     0x6599a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6599ac: cmp             SP, x16
    //     0x6599b0: b.ls            #0x659ba0
    // 0x6599b4: ldr             x1, [fp, #0x20]
    // 0x6599b8: LoadField: r0 = r1->field_33
    //     0x6599b8: ldur            w0, [x1, #0x33]
    // 0x6599bc: DecompressPointer r0
    //     0x6599bc: add             x0, x0, HEAP, lsl #32
    // 0x6599c0: r2 = LoadClassIdInstr(r0)
    //     0x6599c0: ldur            x2, [x0, #-1]
    //     0x6599c4: ubfx            x2, x2, #0xc, #0x14
    // 0x6599c8: ldr             x16, [fp, #0x10]
    // 0x6599cc: stp             x16, x0, [SP, #-0x10]!
    // 0x6599d0: mov             x0, x2
    // 0x6599d4: mov             lr, x0
    // 0x6599d8: ldr             lr, [x21, lr, lsl #3]
    // 0x6599dc: blr             lr
    // 0x6599e0: add             SP, SP, #0x10
    // 0x6599e4: eor             x1, x0, #0x10
    // 0x6599e8: ldr             x0, [fp, #0x10]
    // 0x6599ec: ldr             x2, [fp, #0x20]
    // 0x6599f0: stur            x1, [fp, #-0x10]
    // 0x6599f4: StoreField: r2->field_33 = r0
    //     0x6599f4: stur            w0, [x2, #0x33]
    //     0x6599f8: ldurb           w16, [x2, #-1]
    //     0x6599fc: ldurb           w17, [x0, #-1]
    //     0x659a00: and             x16, x17, x16, lsr #2
    //     0x659a04: tst             x16, HEAP, lsr #32
    //     0x659a08: b.eq            #0x659a10
    //     0x659a0c: bl              #0xd6828c
    // 0x659a10: LoadField: r0 = r2->field_7
    //     0x659a10: ldur            w0, [x2, #7]
    // 0x659a14: DecompressPointer r0
    //     0x659a14: add             x0, x0, HEAP, lsl #32
    // 0x659a18: stur            x0, [fp, #-8]
    // 0x659a1c: ldr             x16, [fp, #0x18]
    // 0x659a20: stp             x16, x2, [SP, #-0x10]!
    // 0x659a24: ldr             x16, [fp, #0x10]
    // 0x659a28: SaveReg r16
    //     0x659a28: str             x16, [SP, #-8]!
    // 0x659a2c: r0 = _innerCalculateFinalDestinationRect()
    //     0x659a2c: bl              #0x65a2ec  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::_innerCalculateFinalDestinationRect
    // 0x659a30: add             SP, SP, #0x18
    // 0x659a34: ldur            x0, [fp, #-8]
    // 0x659a38: ldr             x1, [fp, #0x20]
    // 0x659a3c: StoreField: r1->field_7 = r0
    //     0x659a3c: stur            w0, [x1, #7]
    //     0x659a40: ldurb           w16, [x1, #-1]
    //     0x659a44: ldurb           w17, [x0, #-1]
    //     0x659a48: and             x16, x17, x16, lsr #2
    //     0x659a4c: tst             x16, HEAP, lsr #32
    //     0x659a50: b.eq            #0x659a58
    //     0x659a54: bl              #0xd6826c
    // 0x659a58: ldr             x16, [fp, #0x18]
    // 0x659a5c: stp             x16, x1, [SP, #-0x10]!
    // 0x659a60: ldr             x16, [fp, #0x10]
    // 0x659a64: SaveReg r16
    //     0x659a64: str             x16, [SP, #-8]!
    // 0x659a68: r0 = _innerCalculateFinalDestinationRect()
    //     0x659a68: bl              #0x65a2ec  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::_innerCalculateFinalDestinationRect
    // 0x659a6c: add             SP, SP, #0x18
    // 0x659a70: mov             x1, x0
    // 0x659a74: ldr             x0, [fp, #0x20]
    // 0x659a78: stur            x1, [fp, #-8]
    // 0x659a7c: LoadField: d0 = r0->field_b
    //     0x659a7c: ldur            d0, [x0, #0xb]
    // 0x659a80: d1 = 1.000000
    //     0x659a80: fmov            d1, #1.00000000
    // 0x659a84: fcmp            d0, d1
    // 0x659a88: b.vs            #0x659b48
    // 0x659a8c: b.le            #0x659b48
    // 0x659a90: ldur            x2, [fp, #-0x10]
    // 0x659a94: tbnz            w2, #4, #0x659b48
    // 0x659a98: LoadField: r2 = r0->field_37
    //     0x659a98: ldur            w2, [x0, #0x37]
    // 0x659a9c: DecompressPointer r2
    //     0x659a9c: add             x2, x2, HEAP, lsl #32
    // 0x659aa0: cmp             w2, NULL
    // 0x659aa4: b.eq            #0x659b48
    // 0x659aa8: SaveReg r1
    //     0x659aa8: str             x1, [SP, #-8]!
    // 0x659aac: r0 = center()
    //     0x659aac: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x659ab0: add             SP, SP, #8
    // 0x659ab4: mov             x1, x0
    // 0x659ab8: ldr             x0, [fp, #0x20]
    // 0x659abc: stur            x1, [fp, #-0x10]
    // 0x659ac0: LoadField: r2 = r0->field_37
    //     0x659ac0: ldur            w2, [x0, #0x37]
    // 0x659ac4: DecompressPointer r2
    //     0x659ac4: add             x2, x2, HEAP, lsl #32
    // 0x659ac8: ldur            x16, [fp, #-8]
    // 0x659acc: stp             x16, x0, [SP, #-0x10]!
    // 0x659ad0: ldr             x16, [fp, #0x18]
    // 0x659ad4: stp             x2, x16, [SP, #-0x10]!
    // 0x659ad8: r0 = _getCenterDif()
    //     0x659ad8: bl              #0x659dc4  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::_getCenterDif
    // 0x659adc: add             SP, SP, #0x20
    // 0x659ae0: ldur            x16, [fp, #-0x10]
    // 0x659ae4: stp             x0, x16, [SP, #-0x10]!
    // 0x659ae8: r0 = +()
    //     0x659ae8: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x659aec: add             SP, SP, #0x10
    // 0x659af0: ldr             x16, [fp, #0x20]
    // 0x659af4: ldr             lr, [fp, #0x10]
    // 0x659af8: stp             lr, x16, [SP, #-0x10]!
    // 0x659afc: SaveReg r0
    //     0x659afc: str             x0, [SP, #-8]!
    // 0x659b00: r0 = _getFixedOffset()
    //     0x659b00: bl              #0x659ba8  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::_getFixedOffset
    // 0x659b04: add             SP, SP, #0x18
    // 0x659b08: ldr             x1, [fp, #0x20]
    // 0x659b0c: StoreField: r1->field_7 = r0
    //     0x659b0c: stur            w0, [x1, #7]
    //     0x659b10: ldurb           w16, [x1, #-1]
    //     0x659b14: ldurb           w17, [x0, #-1]
    //     0x659b18: and             x16, x17, x16, lsr #2
    //     0x659b1c: tst             x16, HEAP, lsr #32
    //     0x659b20: b.eq            #0x659b28
    //     0x659b24: bl              #0xd6826c
    // 0x659b28: ldr             x16, [fp, #0x18]
    // 0x659b2c: stp             x16, x1, [SP, #-0x10]!
    // 0x659b30: ldr             x16, [fp, #0x10]
    // 0x659b34: SaveReg r16
    //     0x659b34: str             x16, [SP, #-8]!
    // 0x659b38: r0 = _innerCalculateFinalDestinationRect()
    //     0x659b38: bl              #0x65a2ec  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::_innerCalculateFinalDestinationRect
    // 0x659b3c: add             SP, SP, #0x18
    // 0x659b40: mov             x2, x0
    // 0x659b44: b               #0x659b4c
    // 0x659b48: ldur            x2, [fp, #-8]
    // 0x659b4c: ldr             x1, [fp, #0x20]
    // 0x659b50: mov             x0, x2
    // 0x659b54: StoreField: r1->field_2f = r0
    //     0x659b54: stur            w0, [x1, #0x2f]
    //     0x659b58: ldurb           w16, [x1, #-1]
    //     0x659b5c: ldurb           w17, [x0, #-1]
    //     0x659b60: and             x16, x17, x16, lsr #2
    //     0x659b64: tst             x16, HEAP, lsr #32
    //     0x659b68: b.eq            #0x659b70
    //     0x659b6c: bl              #0xd6826c
    // 0x659b70: ldr             x0, [fp, #0x18]
    // 0x659b74: StoreField: r1->field_2b = r0
    //     0x659b74: stur            w0, [x1, #0x2b]
    //     0x659b78: ldurb           w16, [x1, #-1]
    //     0x659b7c: ldurb           w17, [x0, #-1]
    //     0x659b80: and             x16, x17, x16, lsr #2
    //     0x659b84: tst             x16, HEAP, lsr #32
    //     0x659b88: b.eq            #0x659b90
    //     0x659b8c: bl              #0xd6826c
    // 0x659b90: mov             x0, x2
    // 0x659b94: LeaveFrame
    //     0x659b94: mov             SP, fp
    //     0x659b98: ldp             fp, lr, [SP], #0x10
    // 0x659b9c: ret
    //     0x659b9c: ret             
    // 0x659ba0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x659ba0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x659ba4: b               #0x6599b4
  }
  _ _getFixedOffset(/* No info */) {
    // ** addr: 0x659ba8, size: 0x21c
    // 0x659ba8: EnterFrame
    //     0x659ba8: stp             fp, lr, [SP, #-0x10]!
    //     0x659bac: mov             fp, SP
    // 0x659bb0: AllocStack(0x18)
    //     0x659bb0: sub             SP, SP, #0x18
    // 0x659bb4: d0 = 1.000000
    //     0x659bb4: fmov            d0, #1.00000000
    // 0x659bb8: CheckStackOverflow
    //     0x659bb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x659bbc: cmp             SP, x16
    //     0x659bc0: b.ls            #0x659da0
    // 0x659bc4: ldr             x0, [fp, #0x20]
    // 0x659bc8: LoadField: d1 = r0->field_b
    //     0x659bc8: ldur            d1, [x0, #0xb]
    // 0x659bcc: stur            d1, [fp, #-8]
    // 0x659bd0: fcmp            d1, d0
    // 0x659bd4: b.vs            #0x659d74
    // 0x659bd8: b.le            #0x659d74
    // 0x659bdc: LoadField: r1 = r0->field_1b
    //     0x659bdc: ldur            w1, [x0, #0x1b]
    // 0x659be0: DecompressPointer r1
    //     0x659be0: add             x1, x1, HEAP, lsl #32
    // 0x659be4: tbnz            w1, #4, #0x659c60
    // 0x659be8: LoadField: r2 = r0->field_17
    //     0x659be8: ldur            w2, [x0, #0x17]
    // 0x659bec: DecompressPointer r2
    //     0x659bec: add             x2, x2, HEAP, lsl #32
    // 0x659bf0: tbnz            w2, #4, #0x659c58
    // 0x659bf4: ldr             x16, [fp, #0x18]
    // 0x659bf8: SaveReg r16
    //     0x659bf8: str             x16, [SP, #-8]!
    // 0x659bfc: r0 = center()
    //     0x659bfc: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x659c00: add             SP, SP, #8
    // 0x659c04: ldur            d0, [fp, #-8]
    // 0x659c08: r1 = inline_Allocate_Double()
    //     0x659c08: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x659c0c: add             x1, x1, #0x10
    //     0x659c10: cmp             x2, x1
    //     0x659c14: b.ls            #0x659da8
    //     0x659c18: str             x1, [THR, #0x60]  ; THR::top
    //     0x659c1c: sub             x1, x1, #0xf
    //     0x659c20: mov             x2, #0xd108
    //     0x659c24: movk            x2, #3, lsl #16
    //     0x659c28: stur            x2, [x1, #-1]
    // 0x659c2c: StoreField: r1->field_7 = d0
    //     0x659c2c: stur            d0, [x1, #7]
    // 0x659c30: stp             x1, x0, [SP, #-0x10]!
    // 0x659c34: r0 = *()
    //     0x659c34: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x659c38: add             SP, SP, #0x10
    // 0x659c3c: ldr             x16, [fp, #0x10]
    // 0x659c40: stp             x0, x16, [SP, #-0x10]!
    // 0x659c44: r0 = -()
    //     0x659c44: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x659c48: add             SP, SP, #0x10
    // 0x659c4c: LeaveFrame
    //     0x659c4c: mov             SP, fp
    //     0x659c50: ldp             fp, lr, [SP], #0x10
    // 0x659c54: ret
    //     0x659c54: ret             
    // 0x659c58: mov             v0.16b, v1.16b
    // 0x659c5c: b               #0x659c64
    // 0x659c60: mov             v0.16b, v1.16b
    // 0x659c64: tbnz            w1, #4, #0x659cd0
    // 0x659c68: ldr             x16, [fp, #0x18]
    // 0x659c6c: SaveReg r16
    //     0x659c6c: str             x16, [SP, #-8]!
    // 0x659c70: r0 = center()
    //     0x659c70: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x659c74: add             SP, SP, #8
    // 0x659c78: LoadField: d0 = r0->field_7
    //     0x659c78: ldur            d0, [x0, #7]
    // 0x659c7c: ldur            d1, [fp, #-8]
    // 0x659c80: fmul            d2, d0, d1
    // 0x659c84: stur            d2, [fp, #-0x10]
    // 0x659c88: ldr             x16, [fp, #0x18]
    // 0x659c8c: SaveReg r16
    //     0x659c8c: str             x16, [SP, #-8]!
    // 0x659c90: r0 = center()
    //     0x659c90: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x659c94: add             SP, SP, #8
    // 0x659c98: LoadField: d0 = r0->field_f
    //     0x659c98: ldur            d0, [x0, #0xf]
    // 0x659c9c: stur            d0, [fp, #-0x18]
    // 0x659ca0: r0 = Offset()
    //     0x659ca0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x659ca4: ldur            d0, [fp, #-0x10]
    // 0x659ca8: StoreField: r0->field_7 = d0
    //     0x659ca8: stur            d0, [x0, #7]
    // 0x659cac: ldur            d0, [fp, #-0x18]
    // 0x659cb0: StoreField: r0->field_f = d0
    //     0x659cb0: stur            d0, [x0, #0xf]
    // 0x659cb4: ldr             x16, [fp, #0x10]
    // 0x659cb8: stp             x0, x16, [SP, #-0x10]!
    // 0x659cbc: r0 = -()
    //     0x659cbc: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x659cc0: add             SP, SP, #0x10
    // 0x659cc4: LeaveFrame
    //     0x659cc4: mov             SP, fp
    //     0x659cc8: ldp             fp, lr, [SP], #0x10
    // 0x659ccc: ret
    //     0x659ccc: ret             
    // 0x659cd0: mov             v1.16b, v0.16b
    // 0x659cd4: LoadField: r1 = r0->field_17
    //     0x659cd4: ldur            w1, [x0, #0x17]
    // 0x659cd8: DecompressPointer r1
    //     0x659cd8: add             x1, x1, HEAP, lsl #32
    // 0x659cdc: tbnz            w1, #4, #0x659d48
    // 0x659ce0: ldr             x16, [fp, #0x18]
    // 0x659ce4: SaveReg r16
    //     0x659ce4: str             x16, [SP, #-8]!
    // 0x659ce8: r0 = center()
    //     0x659ce8: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x659cec: add             SP, SP, #8
    // 0x659cf0: LoadField: d0 = r0->field_7
    //     0x659cf0: ldur            d0, [x0, #7]
    // 0x659cf4: stur            d0, [fp, #-0x10]
    // 0x659cf8: ldr             x16, [fp, #0x18]
    // 0x659cfc: SaveReg r16
    //     0x659cfc: str             x16, [SP, #-8]!
    // 0x659d00: r0 = center()
    //     0x659d00: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x659d04: add             SP, SP, #8
    // 0x659d08: LoadField: d0 = r0->field_f
    //     0x659d08: ldur            d0, [x0, #0xf]
    // 0x659d0c: ldur            d1, [fp, #-8]
    // 0x659d10: fmul            d2, d0, d1
    // 0x659d14: stur            d2, [fp, #-0x18]
    // 0x659d18: r0 = Offset()
    //     0x659d18: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x659d1c: ldur            d0, [fp, #-0x10]
    // 0x659d20: StoreField: r0->field_7 = d0
    //     0x659d20: stur            d0, [x0, #7]
    // 0x659d24: ldur            d0, [fp, #-0x18]
    // 0x659d28: StoreField: r0->field_f = d0
    //     0x659d28: stur            d0, [x0, #0xf]
    // 0x659d2c: ldr             x16, [fp, #0x10]
    // 0x659d30: stp             x0, x16, [SP, #-0x10]!
    // 0x659d34: r0 = -()
    //     0x659d34: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x659d38: add             SP, SP, #0x10
    // 0x659d3c: LeaveFrame
    //     0x659d3c: mov             SP, fp
    //     0x659d40: ldp             fp, lr, [SP], #0x10
    // 0x659d44: ret
    //     0x659d44: ret             
    // 0x659d48: ldr             x16, [fp, #0x18]
    // 0x659d4c: SaveReg r16
    //     0x659d4c: str             x16, [SP, #-8]!
    // 0x659d50: r0 = center()
    //     0x659d50: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x659d54: add             SP, SP, #8
    // 0x659d58: ldr             x16, [fp, #0x10]
    // 0x659d5c: stp             x0, x16, [SP, #-0x10]!
    // 0x659d60: r0 = -()
    //     0x659d60: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x659d64: add             SP, SP, #0x10
    // 0x659d68: LeaveFrame
    //     0x659d68: mov             SP, fp
    //     0x659d6c: ldp             fp, lr, [SP], #0x10
    // 0x659d70: ret
    //     0x659d70: ret             
    // 0x659d74: ldr             x16, [fp, #0x18]
    // 0x659d78: SaveReg r16
    //     0x659d78: str             x16, [SP, #-8]!
    // 0x659d7c: r0 = center()
    //     0x659d7c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x659d80: add             SP, SP, #8
    // 0x659d84: ldr             x16, [fp, #0x10]
    // 0x659d88: stp             x0, x16, [SP, #-0x10]!
    // 0x659d8c: r0 = -()
    //     0x659d8c: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x659d90: add             SP, SP, #0x10
    // 0x659d94: LeaveFrame
    //     0x659d94: mov             SP, fp
    //     0x659d98: ldp             fp, lr, [SP], #0x10
    // 0x659d9c: ret
    //     0x659d9c: ret             
    // 0x659da0: r0 = StackOverflowSharedWithFPURegs()
    //     0x659da0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x659da4: b               #0x659bc4
    // 0x659da8: SaveReg d0
    //     0x659da8: str             q0, [SP, #-0x10]!
    // 0x659dac: SaveReg r0
    //     0x659dac: str             x0, [SP, #-8]!
    // 0x659db0: r0 = AllocateDouble()
    //     0x659db0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x659db4: mov             x1, x0
    // 0x659db8: RestoreReg r0
    //     0x659db8: ldr             x0, [SP], #8
    // 0x659dbc: RestoreReg d0
    //     0x659dbc: ldr             q0, [SP], #0x10
    // 0x659dc0: b               #0x659c2c
  }
  _ _getCenterDif(/* No info */) {
    // ** addr: 0x659dc4, size: 0x398
    // 0x659dc4: EnterFrame
    //     0x659dc4: stp             fp, lr, [SP, #-0x10]!
    //     0x659dc8: mov             fp, SP
    // 0x659dcc: AllocStack(0x18)
    //     0x659dcc: sub             SP, SP, #0x18
    // 0x659dd0: CheckStackOverflow
    //     0x659dd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x659dd4: cmp             SP, x16
    //     0x659dd8: b.ls            #0x65a154
    // 0x659ddc: ldr             x0, [fp, #0x10]
    // 0x659de0: cmp             w0, NULL
    // 0x659de4: b.eq            #0x65a144
    // 0x659de8: LoadField: r1 = r0->field_7
    //     0x659de8: ldur            x1, [x0, #7]
    // 0x659dec: cmp             x1, #4
    // 0x659df0: b.gt            #0x659fc0
    // 0x659df4: cmp             x1, #2
    // 0x659df8: b.gt            #0x659f38
    // 0x659dfc: cmp             x1, #1
    // 0x659e00: b.gt            #0x659ec4
    // 0x659e04: cmp             x1, #0
    // 0x659e08: b.gt            #0x659e80
    // 0x659e0c: ldr             x1, [fp, #0x20]
    // 0x659e10: ldr             x0, [fp, #0x18]
    // 0x659e14: LoadField: d0 = r0->field_7
    //     0x659e14: ldur            d0, [x0, #7]
    // 0x659e18: stur            d0, [fp, #-0x18]
    // 0x659e1c: LoadField: d1 = r0->field_f
    //     0x659e1c: ldur            d1, [x0, #0xf]
    // 0x659e20: stur            d1, [fp, #-0x10]
    // 0x659e24: r0 = Offset()
    //     0x659e24: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x659e28: ldur            d0, [fp, #-0x18]
    // 0x659e2c: stur            x0, [fp, #-8]
    // 0x659e30: StoreField: r0->field_7 = d0
    //     0x659e30: stur            d0, [x0, #7]
    // 0x659e34: ldur            d0, [fp, #-0x10]
    // 0x659e38: StoreField: r0->field_f = d0
    //     0x659e38: stur            d0, [x0, #0xf]
    // 0x659e3c: ldr             x1, [fp, #0x20]
    // 0x659e40: LoadField: d0 = r1->field_7
    //     0x659e40: ldur            d0, [x1, #7]
    // 0x659e44: stur            d0, [fp, #-0x18]
    // 0x659e48: LoadField: d1 = r1->field_f
    //     0x659e48: ldur            d1, [x1, #0xf]
    // 0x659e4c: stur            d1, [fp, #-0x10]
    // 0x659e50: r0 = Offset()
    //     0x659e50: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x659e54: ldur            d0, [fp, #-0x18]
    // 0x659e58: StoreField: r0->field_7 = d0
    //     0x659e58: stur            d0, [x0, #7]
    // 0x659e5c: ldur            d0, [fp, #-0x10]
    // 0x659e60: StoreField: r0->field_f = d0
    //     0x659e60: stur            d0, [x0, #0xf]
    // 0x659e64: ldur            x16, [fp, #-8]
    // 0x659e68: stp             x0, x16, [SP, #-0x10]!
    // 0x659e6c: r0 = -()
    //     0x659e6c: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x659e70: add             SP, SP, #0x10
    // 0x659e74: LeaveFrame
    //     0x659e74: mov             SP, fp
    //     0x659e78: ldp             fp, lr, [SP], #0x10
    // 0x659e7c: ret
    //     0x659e7c: ret             
    // 0x659e80: ldr             x1, [fp, #0x20]
    // 0x659e84: ldr             x0, [fp, #0x18]
    // 0x659e88: SaveReg r0
    //     0x659e88: str             x0, [SP, #-8]!
    // 0x659e8c: r0 = topCenter()
    //     0x659e8c: bl              #0x65a298  ; [dart:ui] Rect::topCenter
    // 0x659e90: add             SP, SP, #8
    // 0x659e94: stur            x0, [fp, #-8]
    // 0x659e98: ldr             x16, [fp, #0x20]
    // 0x659e9c: SaveReg r16
    //     0x659e9c: str             x16, [SP, #-8]!
    // 0x659ea0: r0 = topCenter()
    //     0x659ea0: bl              #0x65a298  ; [dart:ui] Rect::topCenter
    // 0x659ea4: add             SP, SP, #8
    // 0x659ea8: ldur            x16, [fp, #-8]
    // 0x659eac: stp             x0, x16, [SP, #-0x10]!
    // 0x659eb0: r0 = -()
    //     0x659eb0: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x659eb4: add             SP, SP, #0x10
    // 0x659eb8: LeaveFrame
    //     0x659eb8: mov             SP, fp
    //     0x659ebc: ldp             fp, lr, [SP], #0x10
    // 0x659ec0: ret
    //     0x659ec0: ret             
    // 0x659ec4: ldr             x1, [fp, #0x20]
    // 0x659ec8: ldr             x0, [fp, #0x18]
    // 0x659ecc: LoadField: d0 = r0->field_17
    //     0x659ecc: ldur            d0, [x0, #0x17]
    // 0x659ed0: stur            d0, [fp, #-0x18]
    // 0x659ed4: LoadField: d1 = r0->field_f
    //     0x659ed4: ldur            d1, [x0, #0xf]
    // 0x659ed8: stur            d1, [fp, #-0x10]
    // 0x659edc: r0 = Offset()
    //     0x659edc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x659ee0: ldur            d0, [fp, #-0x18]
    // 0x659ee4: stur            x0, [fp, #-8]
    // 0x659ee8: StoreField: r0->field_7 = d0
    //     0x659ee8: stur            d0, [x0, #7]
    // 0x659eec: ldur            d0, [fp, #-0x10]
    // 0x659ef0: StoreField: r0->field_f = d0
    //     0x659ef0: stur            d0, [x0, #0xf]
    // 0x659ef4: ldr             x2, [fp, #0x20]
    // 0x659ef8: LoadField: d0 = r2->field_17
    //     0x659ef8: ldur            d0, [x2, #0x17]
    // 0x659efc: stur            d0, [fp, #-0x18]
    // 0x659f00: LoadField: d1 = r2->field_f
    //     0x659f00: ldur            d1, [x2, #0xf]
    // 0x659f04: stur            d1, [fp, #-0x10]
    // 0x659f08: r0 = Offset()
    //     0x659f08: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x659f0c: ldur            d0, [fp, #-0x18]
    // 0x659f10: StoreField: r0->field_7 = d0
    //     0x659f10: stur            d0, [x0, #7]
    // 0x659f14: ldur            d0, [fp, #-0x10]
    // 0x659f18: StoreField: r0->field_f = d0
    //     0x659f18: stur            d0, [x0, #0xf]
    // 0x659f1c: ldur            x16, [fp, #-8]
    // 0x659f20: stp             x0, x16, [SP, #-0x10]!
    // 0x659f24: r0 = -()
    //     0x659f24: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x659f28: add             SP, SP, #0x10
    // 0x659f2c: LeaveFrame
    //     0x659f2c: mov             SP, fp
    //     0x659f30: ldp             fp, lr, [SP], #0x10
    // 0x659f34: ret
    //     0x659f34: ret             
    // 0x659f38: ldr             x2, [fp, #0x20]
    // 0x659f3c: ldr             x0, [fp, #0x18]
    // 0x659f40: cmp             x1, #3
    // 0x659f44: b.gt            #0x659f84
    // 0x659f48: SaveReg r0
    //     0x659f48: str             x0, [SP, #-8]!
    // 0x659f4c: r0 = centerLeft()
    //     0x659f4c: bl              #0x65a244  ; [dart:ui] Rect::centerLeft
    // 0x659f50: add             SP, SP, #8
    // 0x659f54: stur            x0, [fp, #-8]
    // 0x659f58: ldr             x16, [fp, #0x20]
    // 0x659f5c: SaveReg r16
    //     0x659f5c: str             x16, [SP, #-8]!
    // 0x659f60: r0 = centerLeft()
    //     0x659f60: bl              #0x65a244  ; [dart:ui] Rect::centerLeft
    // 0x659f64: add             SP, SP, #8
    // 0x659f68: ldur            x16, [fp, #-8]
    // 0x659f6c: stp             x0, x16, [SP, #-0x10]!
    // 0x659f70: r0 = -()
    //     0x659f70: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x659f74: add             SP, SP, #0x10
    // 0x659f78: LeaveFrame
    //     0x659f78: mov             SP, fp
    //     0x659f7c: ldp             fp, lr, [SP], #0x10
    // 0x659f80: ret
    //     0x659f80: ret             
    // 0x659f84: SaveReg r0
    //     0x659f84: str             x0, [SP, #-8]!
    // 0x659f88: r0 = center()
    //     0x659f88: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x659f8c: add             SP, SP, #8
    // 0x659f90: stur            x0, [fp, #-8]
    // 0x659f94: ldr             x16, [fp, #0x20]
    // 0x659f98: SaveReg r16
    //     0x659f98: str             x16, [SP, #-8]!
    // 0x659f9c: r0 = center()
    //     0x659f9c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x659fa0: add             SP, SP, #8
    // 0x659fa4: ldur            x16, [fp, #-8]
    // 0x659fa8: stp             x0, x16, [SP, #-0x10]!
    // 0x659fac: r0 = -()
    //     0x659fac: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x659fb0: add             SP, SP, #0x10
    // 0x659fb4: LeaveFrame
    //     0x659fb4: mov             SP, fp
    //     0x659fb8: ldp             fp, lr, [SP], #0x10
    // 0x659fbc: ret
    //     0x659fbc: ret             
    // 0x659fc0: ldr             x0, [fp, #0x18]
    // 0x659fc4: cmp             x1, #6
    // 0x659fc8: b.gt            #0x65a080
    // 0x659fcc: cmp             x1, #5
    // 0x659fd0: b.gt            #0x65a010
    // 0x659fd4: SaveReg r0
    //     0x659fd4: str             x0, [SP, #-8]!
    // 0x659fd8: r0 = centerRight()
    //     0x659fd8: bl              #0x65a1f0  ; [dart:ui] Rect::centerRight
    // 0x659fdc: add             SP, SP, #8
    // 0x659fe0: stur            x0, [fp, #-8]
    // 0x659fe4: ldr             x16, [fp, #0x20]
    // 0x659fe8: SaveReg r16
    //     0x659fe8: str             x16, [SP, #-8]!
    // 0x659fec: r0 = centerRight()
    //     0x659fec: bl              #0x65a1f0  ; [dart:ui] Rect::centerRight
    // 0x659ff0: add             SP, SP, #8
    // 0x659ff4: ldur            x16, [fp, #-8]
    // 0x659ff8: stp             x0, x16, [SP, #-0x10]!
    // 0x659ffc: r0 = -()
    //     0x659ffc: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x65a000: add             SP, SP, #0x10
    // 0x65a004: LeaveFrame
    //     0x65a004: mov             SP, fp
    //     0x65a008: ldp             fp, lr, [SP], #0x10
    // 0x65a00c: ret
    //     0x65a00c: ret             
    // 0x65a010: ldr             x1, [fp, #0x20]
    // 0x65a014: LoadField: d0 = r0->field_7
    //     0x65a014: ldur            d0, [x0, #7]
    // 0x65a018: stur            d0, [fp, #-0x18]
    // 0x65a01c: LoadField: d1 = r0->field_1f
    //     0x65a01c: ldur            d1, [x0, #0x1f]
    // 0x65a020: stur            d1, [fp, #-0x10]
    // 0x65a024: r0 = Offset()
    //     0x65a024: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65a028: ldur            d0, [fp, #-0x18]
    // 0x65a02c: stur            x0, [fp, #-8]
    // 0x65a030: StoreField: r0->field_7 = d0
    //     0x65a030: stur            d0, [x0, #7]
    // 0x65a034: ldur            d0, [fp, #-0x10]
    // 0x65a038: StoreField: r0->field_f = d0
    //     0x65a038: stur            d0, [x0, #0xf]
    // 0x65a03c: ldr             x2, [fp, #0x20]
    // 0x65a040: LoadField: d0 = r2->field_7
    //     0x65a040: ldur            d0, [x2, #7]
    // 0x65a044: stur            d0, [fp, #-0x18]
    // 0x65a048: LoadField: d1 = r2->field_1f
    //     0x65a048: ldur            d1, [x2, #0x1f]
    // 0x65a04c: stur            d1, [fp, #-0x10]
    // 0x65a050: r0 = Offset()
    //     0x65a050: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65a054: ldur            d0, [fp, #-0x18]
    // 0x65a058: StoreField: r0->field_7 = d0
    //     0x65a058: stur            d0, [x0, #7]
    // 0x65a05c: ldur            d0, [fp, #-0x10]
    // 0x65a060: StoreField: r0->field_f = d0
    //     0x65a060: stur            d0, [x0, #0xf]
    // 0x65a064: ldur            x16, [fp, #-8]
    // 0x65a068: stp             x0, x16, [SP, #-0x10]!
    // 0x65a06c: r0 = -()
    //     0x65a06c: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x65a070: add             SP, SP, #0x10
    // 0x65a074: LeaveFrame
    //     0x65a074: mov             SP, fp
    //     0x65a078: ldp             fp, lr, [SP], #0x10
    // 0x65a07c: ret
    //     0x65a07c: ret             
    // 0x65a080: ldr             x2, [fp, #0x20]
    // 0x65a084: cmp             x1, #7
    // 0x65a088: b.gt            #0x65a0c8
    // 0x65a08c: SaveReg r0
    //     0x65a08c: str             x0, [SP, #-8]!
    // 0x65a090: r0 = bottomCenter()
    //     0x65a090: bl              #0x65a19c  ; [dart:ui] Rect::bottomCenter
    // 0x65a094: add             SP, SP, #8
    // 0x65a098: stur            x0, [fp, #-8]
    // 0x65a09c: ldr             x16, [fp, #0x20]
    // 0x65a0a0: SaveReg r16
    //     0x65a0a0: str             x16, [SP, #-8]!
    // 0x65a0a4: r0 = bottomCenter()
    //     0x65a0a4: bl              #0x65a19c  ; [dart:ui] Rect::bottomCenter
    // 0x65a0a8: add             SP, SP, #8
    // 0x65a0ac: ldur            x16, [fp, #-8]
    // 0x65a0b0: stp             x0, x16, [SP, #-0x10]!
    // 0x65a0b4: r0 = -()
    //     0x65a0b4: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x65a0b8: add             SP, SP, #0x10
    // 0x65a0bc: LeaveFrame
    //     0x65a0bc: mov             SP, fp
    //     0x65a0c0: ldp             fp, lr, [SP], #0x10
    // 0x65a0c4: ret
    //     0x65a0c4: ret             
    // 0x65a0c8: lsl             x2, x1, #1
    // 0x65a0cc: cmp             w2, #0x10
    // 0x65a0d0: b.ne            #0x65a144
    // 0x65a0d4: ldr             x1, [fp, #0x20]
    // 0x65a0d8: LoadField: d0 = r0->field_17
    //     0x65a0d8: ldur            d0, [x0, #0x17]
    // 0x65a0dc: stur            d0, [fp, #-0x18]
    // 0x65a0e0: LoadField: d1 = r0->field_1f
    //     0x65a0e0: ldur            d1, [x0, #0x1f]
    // 0x65a0e4: stur            d1, [fp, #-0x10]
    // 0x65a0e8: r0 = Offset()
    //     0x65a0e8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65a0ec: ldur            d0, [fp, #-0x18]
    // 0x65a0f0: stur            x0, [fp, #-8]
    // 0x65a0f4: StoreField: r0->field_7 = d0
    //     0x65a0f4: stur            d0, [x0, #7]
    // 0x65a0f8: ldur            d0, [fp, #-0x10]
    // 0x65a0fc: StoreField: r0->field_f = d0
    //     0x65a0fc: stur            d0, [x0, #0xf]
    // 0x65a100: ldr             x1, [fp, #0x20]
    // 0x65a104: LoadField: d0 = r1->field_17
    //     0x65a104: ldur            d0, [x1, #0x17]
    // 0x65a108: stur            d0, [fp, #-0x18]
    // 0x65a10c: LoadField: d1 = r1->field_1f
    //     0x65a10c: ldur            d1, [x1, #0x1f]
    // 0x65a110: stur            d1, [fp, #-0x10]
    // 0x65a114: r0 = Offset()
    //     0x65a114: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65a118: ldur            d0, [fp, #-0x18]
    // 0x65a11c: StoreField: r0->field_7 = d0
    //     0x65a11c: stur            d0, [x0, #7]
    // 0x65a120: ldur            d0, [fp, #-0x10]
    // 0x65a124: StoreField: r0->field_f = d0
    //     0x65a124: stur            d0, [x0, #0xf]
    // 0x65a128: ldur            x16, [fp, #-8]
    // 0x65a12c: stp             x0, x16, [SP, #-0x10]!
    // 0x65a130: r0 = -()
    //     0x65a130: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x65a134: add             SP, SP, #0x10
    // 0x65a138: LeaveFrame
    //     0x65a138: mov             SP, fp
    //     0x65a13c: ldp             fp, lr, [SP], #0x10
    // 0x65a140: ret
    //     0x65a140: ret             
    // 0x65a144: r0 = Instance_Offset
    //     0x65a144: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65a148: LeaveFrame
    //     0x65a148: mov             SP, fp
    //     0x65a14c: ldp             fp, lr, [SP], #0x10
    // 0x65a150: ret
    //     0x65a150: ret             
    // 0x65a154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65a154: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65a158: b               #0x659ddc
  }
  _ _innerCalculateFinalDestinationRect(/* No info */) {
    // ** addr: 0x65a2ec, size: 0x740
    // 0x65a2ec: EnterFrame
    //     0x65a2ec: stp             fp, lr, [SP, #-0x10]!
    //     0x65a2f0: mov             fp, SP
    // 0x65a2f4: AllocStack(0x38)
    //     0x65a2f4: sub             SP, SP, #0x38
    // 0x65a2f8: CheckStackOverflow
    //     0x65a2f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65a2fc: cmp             SP, x16
    //     0x65a300: b.ls            #0x65a904
    // 0x65a304: r0 = Boundary()
    //     0x65a304: bl              #0x65ad60  ; AllocateBoundaryStub -> Boundary (size=0x18)
    // 0x65a308: mov             x1, x0
    // 0x65a30c: r0 = false
    //     0x65a30c: add             x0, NULL, #0x30  ; false
    // 0x65a310: StoreField: r1->field_7 = r0
    //     0x65a310: stur            w0, [x1, #7]
    // 0x65a314: StoreField: r1->field_b = r0
    //     0x65a314: stur            w0, [x1, #0xb]
    // 0x65a318: StoreField: r1->field_13 = r0
    //     0x65a318: stur            w0, [x1, #0x13]
    // 0x65a31c: StoreField: r1->field_f = r0
    //     0x65a31c: stur            w0, [x1, #0xf]
    // 0x65a320: mov             x0, x1
    // 0x65a324: ldr             x1, [fp, #0x20]
    // 0x65a328: StoreField: r1->field_1f = r0
    //     0x65a328: stur            w0, [x1, #0x1f]
    //     0x65a32c: ldurb           w16, [x1, #-1]
    //     0x65a330: ldurb           w17, [x0, #-1]
    //     0x65a334: and             x16, x17, x16, lsr #2
    //     0x65a338: tst             x16, HEAP, lsr #32
    //     0x65a33c: b.eq            #0x65a344
    //     0x65a340: bl              #0xd6826c
    // 0x65a344: ldr             x16, [fp, #0x10]
    // 0x65a348: stp             x16, x1, [SP, #-0x10]!
    // 0x65a34c: r0 = _getCenter()
    //     0x65a34c: bl              #0x65aacc  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::_getCenter
    // 0x65a350: add             SP, SP, #0x10
    // 0x65a354: cmp             w0, NULL
    // 0x65a358: b.eq            #0x65a90c
    // 0x65a35c: ldr             x16, [fp, #0x20]
    // 0x65a360: ldr             lr, [fp, #0x10]
    // 0x65a364: stp             lr, x16, [SP, #-0x10]!
    // 0x65a368: SaveReg r0
    //     0x65a368: str             x0, [SP, #-8]!
    // 0x65a36c: r0 = _getDestinationRect()
    //     0x65a36c: bl              #0x65aa2c  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::_getDestinationRect
    // 0x65a370: add             SP, SP, #0x18
    // 0x65a374: mov             x1, x0
    // 0x65a378: ldr             x0, [fp, #0x20]
    // 0x65a37c: stur            x1, [fp, #-8]
    // 0x65a380: LoadField: r2 = r0->field_1b
    //     0x65a380: ldur            w2, [x0, #0x1b]
    // 0x65a384: DecompressPointer r2
    //     0x65a384: add             x2, x2, HEAP, lsl #32
    // 0x65a388: tbnz            w2, #4, #0x65a54c
    // 0x65a38c: ldr             x2, [fp, #0x18]
    // 0x65a390: LoadField: d0 = r1->field_7
    //     0x65a390: ldur            d0, [x1, #7]
    // 0x65a394: stur            d0, [fp, #-0x20]
    // 0x65a398: LoadField: d1 = r2->field_7
    //     0x65a398: ldur            d1, [x2, #7]
    // 0x65a39c: stur            d1, [fp, #-0x18]
    // 0x65a3a0: r3 = inline_Allocate_Double()
    //     0x65a3a0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x65a3a4: add             x3, x3, #0x10
    //     0x65a3a8: cmp             x4, x3
    //     0x65a3ac: b.ls            #0x65a910
    //     0x65a3b0: str             x3, [THR, #0x60]  ; THR::top
    //     0x65a3b4: sub             x3, x3, #0xf
    //     0x65a3b8: mov             x4, #0xd108
    //     0x65a3bc: movk            x4, #3, lsl #16
    //     0x65a3c0: stur            x4, [x3, #-1]
    // 0x65a3c4: StoreField: r3->field_7 = d0
    //     0x65a3c4: stur            d0, [x3, #7]
    // 0x65a3c8: SaveReg r3
    //     0x65a3c8: str             x3, [SP, #-8]!
    // 0x65a3cc: SaveReg d1
    //     0x65a3cc: str             d1, [SP, #-8]!
    // 0x65a3d0: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x65a3d0: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x65a3d4: add             SP, SP, #0x10
    // 0x65a3d8: tbnz            w0, #4, #0x65a454
    // 0x65a3dc: ldr             x0, [fp, #0x20]
    // 0x65a3e0: ldur            x1, [fp, #-8]
    // 0x65a3e4: ldur            d0, [fp, #-0x20]
    // 0x65a3e8: ldur            d1, [fp, #-0x18]
    // 0x65a3ec: LoadField: d2 = r1->field_f
    //     0x65a3ec: ldur            d2, [x1, #0xf]
    // 0x65a3f0: stur            d2, [fp, #-0x38]
    // 0x65a3f4: LoadField: d3 = r1->field_17
    //     0x65a3f4: ldur            d3, [x1, #0x17]
    // 0x65a3f8: fsub            d4, d3, d0
    // 0x65a3fc: LoadField: d0 = r1->field_1f
    //     0x65a3fc: ldur            d0, [x1, #0x1f]
    // 0x65a400: fsub            d3, d0, d2
    // 0x65a404: fadd            d0, d1, d4
    // 0x65a408: stur            d0, [fp, #-0x30]
    // 0x65a40c: fadd            d4, d2, d3
    // 0x65a410: stur            d4, [fp, #-0x28]
    // 0x65a414: r0 = Rect()
    //     0x65a414: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x65a418: ldur            d0, [fp, #-0x18]
    // 0x65a41c: StoreField: r0->field_7 = d0
    //     0x65a41c: stur            d0, [x0, #7]
    // 0x65a420: ldur            d1, [fp, #-0x38]
    // 0x65a424: StoreField: r0->field_f = d1
    //     0x65a424: stur            d1, [x0, #0xf]
    // 0x65a428: ldur            d1, [fp, #-0x30]
    // 0x65a42c: StoreField: r0->field_17 = d1
    //     0x65a42c: stur            d1, [x0, #0x17]
    // 0x65a430: ldur            d1, [fp, #-0x28]
    // 0x65a434: StoreField: r0->field_1f = d1
    //     0x65a434: stur            d1, [x0, #0x1f]
    // 0x65a438: ldr             x2, [fp, #0x20]
    // 0x65a43c: LoadField: r1 = r2->field_1f
    //     0x65a43c: ldur            w1, [x2, #0x1f]
    // 0x65a440: DecompressPointer r1
    //     0x65a440: add             x1, x1, HEAP, lsl #32
    // 0x65a444: r3 = true
    //     0x65a444: add             x3, NULL, #0x20  ; true
    // 0x65a448: StoreField: r1->field_7 = r3
    //     0x65a448: stur            w3, [x1, #7]
    // 0x65a44c: mov             x1, x0
    // 0x65a450: b               #0x65a464
    // 0x65a454: ldr             x2, [fp, #0x20]
    // 0x65a458: ldur            x1, [fp, #-8]
    // 0x65a45c: ldur            d0, [fp, #-0x20]
    // 0x65a460: r3 = true
    //     0x65a460: add             x3, NULL, #0x20  ; true
    // 0x65a464: ldr             x0, [fp, #0x18]
    // 0x65a468: stur            x1, [fp, #-0x10]
    // 0x65a46c: stur            d0, [fp, #-0x28]
    // 0x65a470: LoadField: d1 = r1->field_17
    //     0x65a470: ldur            d1, [x1, #0x17]
    // 0x65a474: stur            d1, [fp, #-0x20]
    // 0x65a478: LoadField: d2 = r0->field_17
    //     0x65a478: ldur            d2, [x0, #0x17]
    // 0x65a47c: stur            d2, [fp, #-0x18]
    // 0x65a480: r4 = inline_Allocate_Double()
    //     0x65a480: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x65a484: add             x4, x4, #0x10
    //     0x65a488: cmp             x5, x4
    //     0x65a48c: b.ls            #0x65a934
    //     0x65a490: str             x4, [THR, #0x60]  ; THR::top
    //     0x65a494: sub             x4, x4, #0xf
    //     0x65a498: mov             x5, #0xd108
    //     0x65a49c: movk            x5, #3, lsl #16
    //     0x65a4a0: stur            x5, [x4, #-1]
    // 0x65a4a4: StoreField: r4->field_7 = d1
    //     0x65a4a4: stur            d1, [x4, #7]
    // 0x65a4a8: SaveReg r4
    //     0x65a4a8: str             x4, [SP, #-8]!
    // 0x65a4ac: SaveReg d2
    //     0x65a4ac: str             d2, [SP, #-8]!
    // 0x65a4b0: r0 = DoubleExtension.lessThanOrEqualTo()
    //     0x65a4b0: bl              #0x6589e8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThanOrEqualTo
    // 0x65a4b4: add             SP, SP, #0x10
    // 0x65a4b8: tbnz            w0, #4, #0x65a538
    // 0x65a4bc: ldr             x0, [fp, #0x20]
    // 0x65a4c0: ldur            x1, [fp, #-0x10]
    // 0x65a4c4: ldur            d1, [fp, #-0x20]
    // 0x65a4c8: ldur            d2, [fp, #-0x18]
    // 0x65a4cc: ldur            d0, [fp, #-0x28]
    // 0x65a4d0: fsub            d3, d1, d0
    // 0x65a4d4: fsub            d0, d2, d3
    // 0x65a4d8: stur            d0, [fp, #-0x30]
    // 0x65a4dc: LoadField: d1 = r1->field_f
    //     0x65a4dc: ldur            d1, [x1, #0xf]
    // 0x65a4e0: stur            d1, [fp, #-0x28]
    // 0x65a4e4: LoadField: d2 = r1->field_1f
    //     0x65a4e4: ldur            d2, [x1, #0x1f]
    // 0x65a4e8: fsub            d4, d2, d1
    // 0x65a4ec: fadd            d2, d0, d3
    // 0x65a4f0: stur            d2, [fp, #-0x20]
    // 0x65a4f4: fadd            d3, d1, d4
    // 0x65a4f8: stur            d3, [fp, #-0x18]
    // 0x65a4fc: r0 = Rect()
    //     0x65a4fc: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x65a500: ldur            d0, [fp, #-0x30]
    // 0x65a504: StoreField: r0->field_7 = d0
    //     0x65a504: stur            d0, [x0, #7]
    // 0x65a508: ldur            d0, [fp, #-0x28]
    // 0x65a50c: StoreField: r0->field_f = d0
    //     0x65a50c: stur            d0, [x0, #0xf]
    // 0x65a510: ldur            d0, [fp, #-0x20]
    // 0x65a514: StoreField: r0->field_17 = d0
    //     0x65a514: stur            d0, [x0, #0x17]
    // 0x65a518: ldur            d0, [fp, #-0x18]
    // 0x65a51c: StoreField: r0->field_1f = d0
    //     0x65a51c: stur            d0, [x0, #0x1f]
    // 0x65a520: ldr             x2, [fp, #0x20]
    // 0x65a524: LoadField: r1 = r2->field_1f
    //     0x65a524: ldur            w1, [x2, #0x1f]
    // 0x65a528: DecompressPointer r1
    //     0x65a528: add             x1, x1, HEAP, lsl #32
    // 0x65a52c: r3 = true
    //     0x65a52c: add             x3, NULL, #0x20  ; true
    // 0x65a530: StoreField: r1->field_b = r3
    //     0x65a530: stur            w3, [x1, #0xb]
    // 0x65a534: b               #0x65a558
    // 0x65a538: ldr             x2, [fp, #0x20]
    // 0x65a53c: ldur            x1, [fp, #-0x10]
    // 0x65a540: r3 = true
    //     0x65a540: add             x3, NULL, #0x20  ; true
    // 0x65a544: mov             x0, x1
    // 0x65a548: b               #0x65a558
    // 0x65a54c: mov             x2, x0
    // 0x65a550: r3 = true
    //     0x65a550: add             x3, NULL, #0x20  ; true
    // 0x65a554: mov             x0, x1
    // 0x65a558: stur            x0, [fp, #-8]
    // 0x65a55c: LoadField: r1 = r2->field_17
    //     0x65a55c: ldur            w1, [x2, #0x17]
    // 0x65a560: DecompressPointer r1
    //     0x65a560: add             x1, x1, HEAP, lsl #32
    // 0x65a564: tbnz            w1, #4, #0x65a728
    // 0x65a568: ldr             x1, [fp, #0x18]
    // 0x65a56c: LoadField: d0 = r0->field_1f
    //     0x65a56c: ldur            d0, [x0, #0x1f]
    // 0x65a570: stur            d0, [fp, #-0x20]
    // 0x65a574: LoadField: d1 = r1->field_1f
    //     0x65a574: ldur            d1, [x1, #0x1f]
    // 0x65a578: stur            d1, [fp, #-0x18]
    // 0x65a57c: r4 = inline_Allocate_Double()
    //     0x65a57c: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x65a580: add             x4, x4, #0x10
    //     0x65a584: cmp             x5, x4
    //     0x65a588: b.ls            #0x65a960
    //     0x65a58c: str             x4, [THR, #0x60]  ; THR::top
    //     0x65a590: sub             x4, x4, #0xf
    //     0x65a594: mov             x5, #0xd108
    //     0x65a598: movk            x5, #3, lsl #16
    //     0x65a59c: stur            x5, [x4, #-1]
    // 0x65a5a0: StoreField: r4->field_7 = d0
    //     0x65a5a0: stur            d0, [x4, #7]
    // 0x65a5a4: SaveReg r4
    //     0x65a5a4: str             x4, [SP, #-8]!
    // 0x65a5a8: SaveReg d1
    //     0x65a5a8: str             d1, [SP, #-8]!
    // 0x65a5ac: r0 = DoubleExtension.lessThanOrEqualTo()
    //     0x65a5ac: bl              #0x6589e8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThanOrEqualTo
    // 0x65a5b0: add             SP, SP, #0x10
    // 0x65a5b4: tbnz            w0, #4, #0x65a638
    // 0x65a5b8: ldr             x0, [fp, #0x20]
    // 0x65a5bc: ldur            x1, [fp, #-8]
    // 0x65a5c0: ldur            d0, [fp, #-0x20]
    // 0x65a5c4: ldur            d1, [fp, #-0x18]
    // 0x65a5c8: LoadField: d2 = r1->field_7
    //     0x65a5c8: ldur            d2, [x1, #7]
    // 0x65a5cc: stur            d2, [fp, #-0x38]
    // 0x65a5d0: LoadField: d3 = r1->field_f
    //     0x65a5d0: ldur            d3, [x1, #0xf]
    // 0x65a5d4: fsub            d4, d0, d3
    // 0x65a5d8: fsub            d0, d1, d4
    // 0x65a5dc: stur            d0, [fp, #-0x30]
    // 0x65a5e0: LoadField: d1 = r1->field_17
    //     0x65a5e0: ldur            d1, [x1, #0x17]
    // 0x65a5e4: fsub            d3, d1, d2
    // 0x65a5e8: fadd            d1, d2, d3
    // 0x65a5ec: stur            d1, [fp, #-0x28]
    // 0x65a5f0: fadd            d3, d0, d4
    // 0x65a5f4: stur            d3, [fp, #-0x18]
    // 0x65a5f8: r0 = Rect()
    //     0x65a5f8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x65a5fc: ldur            d0, [fp, #-0x38]
    // 0x65a600: StoreField: r0->field_7 = d0
    //     0x65a600: stur            d0, [x0, #7]
    // 0x65a604: ldur            d0, [fp, #-0x30]
    // 0x65a608: StoreField: r0->field_f = d0
    //     0x65a608: stur            d0, [x0, #0xf]
    // 0x65a60c: ldur            d0, [fp, #-0x28]
    // 0x65a610: StoreField: r0->field_17 = d0
    //     0x65a610: stur            d0, [x0, #0x17]
    // 0x65a614: ldur            d0, [fp, #-0x18]
    // 0x65a618: StoreField: r0->field_1f = d0
    //     0x65a618: stur            d0, [x0, #0x1f]
    // 0x65a61c: ldr             x2, [fp, #0x20]
    // 0x65a620: LoadField: r1 = r2->field_1f
    //     0x65a620: ldur            w1, [x2, #0x1f]
    // 0x65a624: DecompressPointer r1
    //     0x65a624: add             x1, x1, HEAP, lsl #32
    // 0x65a628: r3 = true
    //     0x65a628: add             x3, NULL, #0x20  ; true
    // 0x65a62c: StoreField: r1->field_f = r3
    //     0x65a62c: stur            w3, [x1, #0xf]
    // 0x65a630: mov             x1, x0
    // 0x65a634: b               #0x65a648
    // 0x65a638: ldr             x2, [fp, #0x20]
    // 0x65a63c: ldur            x1, [fp, #-8]
    // 0x65a640: ldur            d0, [fp, #-0x20]
    // 0x65a644: r3 = true
    //     0x65a644: add             x3, NULL, #0x20  ; true
    // 0x65a648: ldr             x0, [fp, #0x18]
    // 0x65a64c: stur            x1, [fp, #-0x10]
    // 0x65a650: stur            d0, [fp, #-0x28]
    // 0x65a654: LoadField: d1 = r1->field_f
    //     0x65a654: ldur            d1, [x1, #0xf]
    // 0x65a658: stur            d1, [fp, #-0x20]
    // 0x65a65c: LoadField: d2 = r0->field_f
    //     0x65a65c: ldur            d2, [x0, #0xf]
    // 0x65a660: stur            d2, [fp, #-0x18]
    // 0x65a664: r4 = inline_Allocate_Double()
    //     0x65a664: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x65a668: add             x4, x4, #0x10
    //     0x65a66c: cmp             x5, x4
    //     0x65a670: b.ls            #0x65a984
    //     0x65a674: str             x4, [THR, #0x60]  ; THR::top
    //     0x65a678: sub             x4, x4, #0xf
    //     0x65a67c: mov             x5, #0xd108
    //     0x65a680: movk            x5, #3, lsl #16
    //     0x65a684: stur            x5, [x4, #-1]
    // 0x65a688: StoreField: r4->field_7 = d1
    //     0x65a688: stur            d1, [x4, #7]
    // 0x65a68c: SaveReg r4
    //     0x65a68c: str             x4, [SP, #-8]!
    // 0x65a690: SaveReg d2
    //     0x65a690: str             d2, [SP, #-8]!
    // 0x65a694: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x65a694: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x65a698: add             SP, SP, #0x10
    // 0x65a69c: tbnz            w0, #4, #0x65a714
    // 0x65a6a0: ldr             x0, [fp, #0x20]
    // 0x65a6a4: ldur            x1, [fp, #-0x10]
    // 0x65a6a8: ldur            d1, [fp, #-0x20]
    // 0x65a6ac: ldur            d2, [fp, #-0x18]
    // 0x65a6b0: ldur            d0, [fp, #-0x28]
    // 0x65a6b4: LoadField: d3 = r1->field_7
    //     0x65a6b4: ldur            d3, [x1, #7]
    // 0x65a6b8: stur            d3, [fp, #-0x30]
    // 0x65a6bc: LoadField: d4 = r1->field_17
    //     0x65a6bc: ldur            d4, [x1, #0x17]
    // 0x65a6c0: fsub            d5, d4, d3
    // 0x65a6c4: fsub            d4, d0, d1
    // 0x65a6c8: fadd            d0, d3, d5
    // 0x65a6cc: stur            d0, [fp, #-0x28]
    // 0x65a6d0: fadd            d1, d2, d4
    // 0x65a6d4: stur            d1, [fp, #-0x20]
    // 0x65a6d8: r0 = Rect()
    //     0x65a6d8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x65a6dc: ldur            d0, [fp, #-0x30]
    // 0x65a6e0: StoreField: r0->field_7 = d0
    //     0x65a6e0: stur            d0, [x0, #7]
    // 0x65a6e4: ldur            d0, [fp, #-0x18]
    // 0x65a6e8: StoreField: r0->field_f = d0
    //     0x65a6e8: stur            d0, [x0, #0xf]
    // 0x65a6ec: ldur            d0, [fp, #-0x28]
    // 0x65a6f0: StoreField: r0->field_17 = d0
    //     0x65a6f0: stur            d0, [x0, #0x17]
    // 0x65a6f4: ldur            d0, [fp, #-0x20]
    // 0x65a6f8: StoreField: r0->field_1f = d0
    //     0x65a6f8: stur            d0, [x0, #0x1f]
    // 0x65a6fc: ldr             x2, [fp, #0x20]
    // 0x65a700: LoadField: r1 = r2->field_1f
    //     0x65a700: ldur            w1, [x2, #0x1f]
    // 0x65a704: DecompressPointer r1
    //     0x65a704: add             x1, x1, HEAP, lsl #32
    // 0x65a708: r3 = true
    //     0x65a708: add             x3, NULL, #0x20  ; true
    // 0x65a70c: StoreField: r1->field_13 = r3
    //     0x65a70c: stur            w3, [x1, #0x13]
    // 0x65a710: b               #0x65a720
    // 0x65a714: ldr             x2, [fp, #0x20]
    // 0x65a718: ldur            x1, [fp, #-0x10]
    // 0x65a71c: mov             x0, x1
    // 0x65a720: mov             x1, x0
    // 0x65a724: b               #0x65a72c
    // 0x65a728: mov             x1, x0
    // 0x65a72c: ldr             x0, [fp, #0x18]
    // 0x65a730: stur            x1, [fp, #-8]
    // 0x65a734: LoadField: d0 = r1->field_7
    //     0x65a734: ldur            d0, [x1, #7]
    // 0x65a738: LoadField: d1 = r0->field_7
    //     0x65a738: ldur            d1, [x0, #7]
    // 0x65a73c: r3 = inline_Allocate_Double()
    //     0x65a73c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x65a740: add             x3, x3, #0x10
    //     0x65a744: cmp             x4, x3
    //     0x65a748: b.ls            #0x65a9b0
    //     0x65a74c: str             x3, [THR, #0x60]  ; THR::top
    //     0x65a750: sub             x3, x3, #0xf
    //     0x65a754: mov             x4, #0xd108
    //     0x65a758: movk            x4, #3, lsl #16
    //     0x65a75c: stur            x4, [x3, #-1]
    // 0x65a760: StoreField: r3->field_7 = d0
    //     0x65a760: stur            d0, [x3, #7]
    // 0x65a764: SaveReg r3
    //     0x65a764: str             x3, [SP, #-8]!
    // 0x65a768: SaveReg d1
    //     0x65a768: str             d1, [SP, #-8]!
    // 0x65a76c: r0 = DoubleExtension.lessThanOrEqualTo()
    //     0x65a76c: bl              #0x6589e8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThanOrEqualTo
    // 0x65a770: add             SP, SP, #0x10
    // 0x65a774: tbnz            w0, #4, #0x65a7c8
    // 0x65a778: ldr             x0, [fp, #0x18]
    // 0x65a77c: ldur            x1, [fp, #-8]
    // 0x65a780: LoadField: d0 = r1->field_17
    //     0x65a780: ldur            d0, [x1, #0x17]
    // 0x65a784: LoadField: d1 = r0->field_17
    //     0x65a784: ldur            d1, [x0, #0x17]
    // 0x65a788: r2 = inline_Allocate_Double()
    //     0x65a788: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x65a78c: add             x2, x2, #0x10
    //     0x65a790: cmp             x3, x2
    //     0x65a794: b.ls            #0x65a9d4
    //     0x65a798: str             x2, [THR, #0x60]  ; THR::top
    //     0x65a79c: sub             x2, x2, #0xf
    //     0x65a7a0: mov             x3, #0xd108
    //     0x65a7a4: movk            x3, #3, lsl #16
    //     0x65a7a8: stur            x3, [x2, #-1]
    // 0x65a7ac: StoreField: r2->field_7 = d0
    //     0x65a7ac: stur            d0, [x2, #7]
    // 0x65a7b0: SaveReg r2
    //     0x65a7b0: str             x2, [SP, #-8]!
    // 0x65a7b4: SaveReg d1
    //     0x65a7b4: str             d1, [SP, #-8]!
    // 0x65a7b8: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x65a7b8: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x65a7bc: add             SP, SP, #0x10
    // 0x65a7c0: mov             x3, x0
    // 0x65a7c4: b               #0x65a7cc
    // 0x65a7c8: r3 = false
    //     0x65a7c8: add             x3, NULL, #0x30  ; false
    // 0x65a7cc: ldr             x2, [fp, #0x20]
    // 0x65a7d0: ldr             x0, [fp, #0x18]
    // 0x65a7d4: ldur            x1, [fp, #-8]
    // 0x65a7d8: StoreField: r2->field_1b = r3
    //     0x65a7d8: stur            w3, [x2, #0x1b]
    // 0x65a7dc: LoadField: d0 = r1->field_f
    //     0x65a7dc: ldur            d0, [x1, #0xf]
    // 0x65a7e0: LoadField: d1 = r0->field_f
    //     0x65a7e0: ldur            d1, [x0, #0xf]
    // 0x65a7e4: r3 = inline_Allocate_Double()
    //     0x65a7e4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x65a7e8: add             x3, x3, #0x10
    //     0x65a7ec: cmp             x4, x3
    //     0x65a7f0: b.ls            #0x65a9f0
    //     0x65a7f4: str             x3, [THR, #0x60]  ; THR::top
    //     0x65a7f8: sub             x3, x3, #0xf
    //     0x65a7fc: mov             x4, #0xd108
    //     0x65a800: movk            x4, #3, lsl #16
    //     0x65a804: stur            x4, [x3, #-1]
    // 0x65a808: StoreField: r3->field_7 = d0
    //     0x65a808: stur            d0, [x3, #7]
    // 0x65a80c: SaveReg r3
    //     0x65a80c: str             x3, [SP, #-8]!
    // 0x65a810: SaveReg d1
    //     0x65a810: str             d1, [SP, #-8]!
    // 0x65a814: r0 = DoubleExtension.lessThanOrEqualTo()
    //     0x65a814: bl              #0x6589e8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThanOrEqualTo
    // 0x65a818: add             SP, SP, #0x10
    // 0x65a81c: tbnz            w0, #4, #0x65a870
    // 0x65a820: ldr             x0, [fp, #0x18]
    // 0x65a824: ldur            x1, [fp, #-8]
    // 0x65a828: LoadField: d0 = r1->field_1f
    //     0x65a828: ldur            d0, [x1, #0x1f]
    // 0x65a82c: LoadField: d1 = r0->field_1f
    //     0x65a82c: ldur            d1, [x0, #0x1f]
    // 0x65a830: r0 = inline_Allocate_Double()
    //     0x65a830: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x65a834: add             x0, x0, #0x10
    //     0x65a838: cmp             x2, x0
    //     0x65a83c: b.ls            #0x65aa14
    //     0x65a840: str             x0, [THR, #0x60]  ; THR::top
    //     0x65a844: sub             x0, x0, #0xf
    //     0x65a848: mov             x2, #0xd108
    //     0x65a84c: movk            x2, #3, lsl #16
    //     0x65a850: stur            x2, [x0, #-1]
    // 0x65a854: StoreField: r0->field_7 = d0
    //     0x65a854: stur            d0, [x0, #7]
    // 0x65a858: SaveReg r0
    //     0x65a858: str             x0, [SP, #-8]!
    // 0x65a85c: SaveReg d1
    //     0x65a85c: str             d1, [SP, #-8]!
    // 0x65a860: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x65a860: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x65a864: add             SP, SP, #0x10
    // 0x65a868: mov             x1, x0
    // 0x65a86c: b               #0x65a874
    // 0x65a870: r1 = false
    //     0x65a870: add             x1, NULL, #0x30  ; false
    // 0x65a874: ldr             x0, [fp, #0x20]
    // 0x65a878: StoreField: r0->field_17 = r1
    //     0x65a878: stur            w1, [x0, #0x17]
    // 0x65a87c: ldur            x16, [fp, #-8]
    // 0x65a880: SaveReg r16
    //     0x65a880: str             x16, [SP, #-8]!
    // 0x65a884: r0 = center()
    //     0x65a884: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x65a888: add             SP, SP, #8
    // 0x65a88c: ldr             x16, [fp, #0x20]
    // 0x65a890: ldr             lr, [fp, #0x10]
    // 0x65a894: stp             lr, x16, [SP, #-0x10]!
    // 0x65a898: SaveReg r0
    //     0x65a898: str             x0, [SP, #-8]!
    // 0x65a89c: r0 = _getFixedOffset()
    //     0x65a89c: bl              #0x659ba8  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::_getFixedOffset
    // 0x65a8a0: add             SP, SP, #0x18
    // 0x65a8a4: ldr             x1, [fp, #0x20]
    // 0x65a8a8: StoreField: r1->field_7 = r0
    //     0x65a8a8: stur            w0, [x1, #7]
    //     0x65a8ac: ldurb           w16, [x1, #-1]
    //     0x65a8b0: ldurb           w17, [x0, #-1]
    //     0x65a8b4: and             x16, x17, x16, lsr #2
    //     0x65a8b8: tst             x16, HEAP, lsr #32
    //     0x65a8bc: b.eq            #0x65a8c4
    //     0x65a8c0: bl              #0xd6826c
    // 0x65a8c4: ldur            x16, [fp, #-8]
    // 0x65a8c8: SaveReg r16
    //     0x65a8c8: str             x16, [SP, #-8]!
    // 0x65a8cc: r0 = center()
    //     0x65a8cc: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x65a8d0: add             SP, SP, #8
    // 0x65a8d4: ldr             x1, [fp, #0x20]
    // 0x65a8d8: StoreField: r1->field_27 = r0
    //     0x65a8d8: stur            w0, [x1, #0x27]
    //     0x65a8dc: ldurb           w16, [x1, #-1]
    //     0x65a8e0: ldurb           w17, [x0, #-1]
    //     0x65a8e4: and             x16, x17, x16, lsr #2
    //     0x65a8e8: tst             x16, HEAP, lsr #32
    //     0x65a8ec: b.eq            #0x65a8f4
    //     0x65a8f0: bl              #0xd6826c
    // 0x65a8f4: ldur            x0, [fp, #-8]
    // 0x65a8f8: LeaveFrame
    //     0x65a8f8: mov             SP, fp
    //     0x65a8fc: ldp             fp, lr, [SP], #0x10
    // 0x65a900: ret
    //     0x65a900: ret             
    // 0x65a904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65a904: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65a908: b               #0x65a304
    // 0x65a90c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65a90c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65a910: stp             q0, q1, [SP, #-0x20]!
    // 0x65a914: stp             x1, x2, [SP, #-0x10]!
    // 0x65a918: SaveReg r0
    //     0x65a918: str             x0, [SP, #-8]!
    // 0x65a91c: r0 = AllocateDouble()
    //     0x65a91c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65a920: mov             x3, x0
    // 0x65a924: RestoreReg r0
    //     0x65a924: ldr             x0, [SP], #8
    // 0x65a928: ldp             x1, x2, [SP], #0x10
    // 0x65a92c: ldp             q0, q1, [SP], #0x20
    // 0x65a930: b               #0x65a3c4
    // 0x65a934: stp             q1, q2, [SP, #-0x20]!
    // 0x65a938: SaveReg d0
    //     0x65a938: str             q0, [SP, #-0x10]!
    // 0x65a93c: stp             x2, x3, [SP, #-0x10]!
    // 0x65a940: stp             x0, x1, [SP, #-0x10]!
    // 0x65a944: r0 = AllocateDouble()
    //     0x65a944: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65a948: mov             x4, x0
    // 0x65a94c: ldp             x0, x1, [SP], #0x10
    // 0x65a950: ldp             x2, x3, [SP], #0x10
    // 0x65a954: RestoreReg d0
    //     0x65a954: ldr             q0, [SP], #0x10
    // 0x65a958: ldp             q1, q2, [SP], #0x20
    // 0x65a95c: b               #0x65a4a4
    // 0x65a960: stp             q0, q1, [SP, #-0x20]!
    // 0x65a964: stp             x2, x3, [SP, #-0x10]!
    // 0x65a968: stp             x0, x1, [SP, #-0x10]!
    // 0x65a96c: r0 = AllocateDouble()
    //     0x65a96c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65a970: mov             x4, x0
    // 0x65a974: ldp             x0, x1, [SP], #0x10
    // 0x65a978: ldp             x2, x3, [SP], #0x10
    // 0x65a97c: ldp             q0, q1, [SP], #0x20
    // 0x65a980: b               #0x65a5a0
    // 0x65a984: stp             q1, q2, [SP, #-0x20]!
    // 0x65a988: SaveReg d0
    //     0x65a988: str             q0, [SP, #-0x10]!
    // 0x65a98c: stp             x2, x3, [SP, #-0x10]!
    // 0x65a990: stp             x0, x1, [SP, #-0x10]!
    // 0x65a994: r0 = AllocateDouble()
    //     0x65a994: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65a998: mov             x4, x0
    // 0x65a99c: ldp             x0, x1, [SP], #0x10
    // 0x65a9a0: ldp             x2, x3, [SP], #0x10
    // 0x65a9a4: RestoreReg d0
    //     0x65a9a4: ldr             q0, [SP], #0x10
    // 0x65a9a8: ldp             q1, q2, [SP], #0x20
    // 0x65a9ac: b               #0x65a688
    // 0x65a9b0: stp             q0, q1, [SP, #-0x20]!
    // 0x65a9b4: stp             x1, x2, [SP, #-0x10]!
    // 0x65a9b8: SaveReg r0
    //     0x65a9b8: str             x0, [SP, #-8]!
    // 0x65a9bc: r0 = AllocateDouble()
    //     0x65a9bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65a9c0: mov             x3, x0
    // 0x65a9c4: RestoreReg r0
    //     0x65a9c4: ldr             x0, [SP], #8
    // 0x65a9c8: ldp             x1, x2, [SP], #0x10
    // 0x65a9cc: ldp             q0, q1, [SP], #0x20
    // 0x65a9d0: b               #0x65a760
    // 0x65a9d4: stp             q0, q1, [SP, #-0x20]!
    // 0x65a9d8: stp             x0, x1, [SP, #-0x10]!
    // 0x65a9dc: r0 = AllocateDouble()
    //     0x65a9dc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65a9e0: mov             x2, x0
    // 0x65a9e4: ldp             x0, x1, [SP], #0x10
    // 0x65a9e8: ldp             q0, q1, [SP], #0x20
    // 0x65a9ec: b               #0x65a7ac
    // 0x65a9f0: stp             q0, q1, [SP, #-0x20]!
    // 0x65a9f4: stp             x1, x2, [SP, #-0x10]!
    // 0x65a9f8: SaveReg r0
    //     0x65a9f8: str             x0, [SP, #-8]!
    // 0x65a9fc: r0 = AllocateDouble()
    //     0x65a9fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65aa00: mov             x3, x0
    // 0x65aa04: RestoreReg r0
    //     0x65aa04: ldr             x0, [SP], #8
    // 0x65aa08: ldp             x1, x2, [SP], #0x10
    // 0x65aa0c: ldp             q0, q1, [SP], #0x20
    // 0x65aa10: b               #0x65a808
    // 0x65aa14: stp             q0, q1, [SP, #-0x20]!
    // 0x65aa18: SaveReg r1
    //     0x65aa18: str             x1, [SP, #-8]!
    // 0x65aa1c: r0 = AllocateDouble()
    //     0x65aa1c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65aa20: RestoreReg r1
    //     0x65aa20: ldr             x1, [SP], #8
    // 0x65aa24: ldp             q0, q1, [SP], #0x20
    // 0x65aa28: b               #0x65a854
  }
  _ _getDestinationRect(/* No info */) {
    // ** addr: 0x65aa2c, size: 0xa0
    // 0x65aa2c: EnterFrame
    //     0x65aa2c: stp             fp, lr, [SP, #-0x10]!
    //     0x65aa30: mov             fp, SP
    // 0x65aa34: AllocStack(0x20)
    //     0x65aa34: sub             SP, SP, #0x20
    // 0x65aa38: d0 = 2.000000
    //     0x65aa38: fmov            d0, #2.00000000
    // 0x65aa3c: ldr             x0, [fp, #0x18]
    // 0x65aa40: LoadField: d1 = r0->field_17
    //     0x65aa40: ldur            d1, [x0, #0x17]
    // 0x65aa44: LoadField: d2 = r0->field_7
    //     0x65aa44: ldur            d2, [x0, #7]
    // 0x65aa48: fsub            d3, d1, d2
    // 0x65aa4c: ldr             x1, [fp, #0x20]
    // 0x65aa50: LoadField: d1 = r1->field_b
    //     0x65aa50: ldur            d1, [x1, #0xb]
    // 0x65aa54: fmul            d2, d3, d1
    // 0x65aa58: LoadField: d3 = r0->field_1f
    //     0x65aa58: ldur            d3, [x0, #0x1f]
    // 0x65aa5c: LoadField: d4 = r0->field_f
    //     0x65aa5c: ldur            d4, [x0, #0xf]
    // 0x65aa60: fsub            d5, d3, d4
    // 0x65aa64: fmul            d3, d5, d1
    // 0x65aa68: ldr             x0, [fp, #0x10]
    // 0x65aa6c: LoadField: d1 = r0->field_7
    //     0x65aa6c: ldur            d1, [x0, #7]
    // 0x65aa70: fdiv            d4, d2, d0
    // 0x65aa74: fsub            d5, d1, d4
    // 0x65aa78: stur            d5, [fp, #-0x20]
    // 0x65aa7c: LoadField: d1 = r0->field_f
    //     0x65aa7c: ldur            d1, [x0, #0xf]
    // 0x65aa80: fdiv            d4, d3, d0
    // 0x65aa84: fsub            d0, d1, d4
    // 0x65aa88: stur            d0, [fp, #-0x18]
    // 0x65aa8c: fadd            d1, d5, d2
    // 0x65aa90: stur            d1, [fp, #-0x10]
    // 0x65aa94: fadd            d2, d0, d3
    // 0x65aa98: stur            d2, [fp, #-8]
    // 0x65aa9c: r0 = Rect()
    //     0x65aa9c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x65aaa0: ldur            d0, [fp, #-0x20]
    // 0x65aaa4: StoreField: r0->field_7 = d0
    //     0x65aaa4: stur            d0, [x0, #7]
    // 0x65aaa8: ldur            d0, [fp, #-0x18]
    // 0x65aaac: StoreField: r0->field_f = d0
    //     0x65aaac: stur            d0, [x0, #0xf]
    // 0x65aab0: ldur            d0, [fp, #-0x10]
    // 0x65aab4: StoreField: r0->field_17 = d0
    //     0x65aab4: stur            d0, [x0, #0x17]
    // 0x65aab8: ldur            d0, [fp, #-8]
    // 0x65aabc: StoreField: r0->field_1f = d0
    //     0x65aabc: stur            d0, [x0, #0x1f]
    // 0x65aac0: LeaveFrame
    //     0x65aac0: mov             SP, fp
    //     0x65aac4: ldp             fp, lr, [SP], #0x10
    // 0x65aac8: ret
    //     0x65aac8: ret             
  }
  _ _getCenter(/* No info */) {
    // ** addr: 0x65aacc, size: 0x294
    // 0x65aacc: EnterFrame
    //     0x65aacc: stp             fp, lr, [SP, #-0x10]!
    //     0x65aad0: mov             fp, SP
    // 0x65aad4: AllocStack(0x20)
    //     0x65aad4: sub             SP, SP, #0x20
    // 0x65aad8: CheckStackOverflow
    //     0x65aad8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65aadc: cmp             SP, x16
    //     0x65aae0: b.ls            #0x65ad3c
    // 0x65aae4: ldr             x0, [fp, #0x18]
    // 0x65aae8: LoadField: r1 = r0->field_23
    //     0x65aae8: ldur            w1, [x0, #0x23]
    // 0x65aaec: DecompressPointer r1
    //     0x65aaec: add             x1, x1, HEAP, lsl #32
    // 0x65aaf0: tbz             w1, #4, #0x65ab14
    // 0x65aaf4: LoadField: r1 = r0->field_27
    //     0x65aaf4: ldur            w1, [x0, #0x27]
    // 0x65aaf8: DecompressPointer r1
    //     0x65aaf8: add             x1, x1, HEAP, lsl #32
    // 0x65aafc: cmp             w1, NULL
    // 0x65ab00: b.eq            #0x65ab14
    // 0x65ab04: mov             x0, x1
    // 0x65ab08: LeaveFrame
    //     0x65ab08: mov             SP, fp
    //     0x65ab0c: ldp             fp, lr, [SP], #0x10
    // 0x65ab10: ret
    //     0x65ab10: ret             
    // 0x65ab14: d0 = 1.000000
    //     0x65ab14: fmov            d0, #1.00000000
    // 0x65ab18: LoadField: d1 = r0->field_b
    //     0x65ab18: ldur            d1, [x0, #0xb]
    // 0x65ab1c: stur            d1, [fp, #-0x10]
    // 0x65ab20: fcmp            d1, d0
    // 0x65ab24: b.vs            #0x65ad20
    // 0x65ab28: b.le            #0x65ad20
    // 0x65ab2c: LoadField: r1 = r0->field_1b
    //     0x65ab2c: ldur            w1, [x0, #0x1b]
    // 0x65ab30: DecompressPointer r1
    //     0x65ab30: add             x1, x1, HEAP, lsl #32
    // 0x65ab34: tbnz            w1, #4, #0x65abbc
    // 0x65ab38: LoadField: r2 = r0->field_17
    //     0x65ab38: ldur            w2, [x0, #0x17]
    // 0x65ab3c: DecompressPointer r2
    //     0x65ab3c: add             x2, x2, HEAP, lsl #32
    // 0x65ab40: tbnz            w2, #4, #0x65abb4
    // 0x65ab44: ldr             x16, [fp, #0x10]
    // 0x65ab48: SaveReg r16
    //     0x65ab48: str             x16, [SP, #-8]!
    // 0x65ab4c: r0 = center()
    //     0x65ab4c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x65ab50: add             SP, SP, #8
    // 0x65ab54: ldur            d0, [fp, #-0x10]
    // 0x65ab58: r1 = inline_Allocate_Double()
    //     0x65ab58: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x65ab5c: add             x1, x1, #0x10
    //     0x65ab60: cmp             x2, x1
    //     0x65ab64: b.ls            #0x65ad44
    //     0x65ab68: str             x1, [THR, #0x60]  ; THR::top
    //     0x65ab6c: sub             x1, x1, #0xf
    //     0x65ab70: mov             x2, #0xd108
    //     0x65ab74: movk            x2, #3, lsl #16
    //     0x65ab78: stur            x2, [x1, #-1]
    // 0x65ab7c: StoreField: r1->field_7 = d0
    //     0x65ab7c: stur            d0, [x1, #7]
    // 0x65ab80: stp             x1, x0, [SP, #-0x10]!
    // 0x65ab84: r0 = *()
    //     0x65ab84: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x65ab88: add             SP, SP, #0x10
    // 0x65ab8c: mov             x1, x0
    // 0x65ab90: ldr             x0, [fp, #0x18]
    // 0x65ab94: LoadField: r2 = r0->field_7
    //     0x65ab94: ldur            w2, [x0, #7]
    // 0x65ab98: DecompressPointer r2
    //     0x65ab98: add             x2, x2, HEAP, lsl #32
    // 0x65ab9c: stp             x2, x1, [SP, #-0x10]!
    // 0x65aba0: r0 = +()
    //     0x65aba0: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x65aba4: add             SP, SP, #0x10
    // 0x65aba8: LeaveFrame
    //     0x65aba8: mov             SP, fp
    //     0x65abac: ldp             fp, lr, [SP], #0x10
    // 0x65abb0: ret
    //     0x65abb0: ret             
    // 0x65abb4: mov             v0.16b, v1.16b
    // 0x65abb8: b               #0x65abc0
    // 0x65abbc: mov             v0.16b, v1.16b
    // 0x65abc0: tbnz            w1, #4, #0x65ac58
    // 0x65abc4: ldr             x16, [fp, #0x10]
    // 0x65abc8: SaveReg r16
    //     0x65abc8: str             x16, [SP, #-8]!
    // 0x65abcc: r0 = center()
    //     0x65abcc: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x65abd0: add             SP, SP, #8
    // 0x65abd4: LoadField: d0 = r0->field_7
    //     0x65abd4: ldur            d0, [x0, #7]
    // 0x65abd8: ldur            d1, [fp, #-0x10]
    // 0x65abdc: fmul            d2, d0, d1
    // 0x65abe0: stur            d2, [fp, #-0x18]
    // 0x65abe4: ldr             x16, [fp, #0x10]
    // 0x65abe8: SaveReg r16
    //     0x65abe8: str             x16, [SP, #-8]!
    // 0x65abec: r0 = center()
    //     0x65abec: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x65abf0: add             SP, SP, #8
    // 0x65abf4: LoadField: d0 = r0->field_f
    //     0x65abf4: ldur            d0, [x0, #0xf]
    // 0x65abf8: stur            d0, [fp, #-0x20]
    // 0x65abfc: r0 = Offset()
    //     0x65abfc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65ac00: ldur            d0, [fp, #-0x18]
    // 0x65ac04: stur            x0, [fp, #-8]
    // 0x65ac08: StoreField: r0->field_7 = d0
    //     0x65ac08: stur            d0, [x0, #7]
    // 0x65ac0c: ldur            d0, [fp, #-0x20]
    // 0x65ac10: StoreField: r0->field_f = d0
    //     0x65ac10: stur            d0, [x0, #0xf]
    // 0x65ac14: ldr             x1, [fp, #0x18]
    // 0x65ac18: LoadField: r2 = r1->field_7
    //     0x65ac18: ldur            w2, [x1, #7]
    // 0x65ac1c: DecompressPointer r2
    //     0x65ac1c: add             x2, x2, HEAP, lsl #32
    // 0x65ac20: LoadField: d0 = r2->field_7
    //     0x65ac20: ldur            d0, [x2, #7]
    // 0x65ac24: stur            d0, [fp, #-0x18]
    // 0x65ac28: r0 = Offset()
    //     0x65ac28: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65ac2c: ldur            d0, [fp, #-0x18]
    // 0x65ac30: StoreField: r0->field_7 = d0
    //     0x65ac30: stur            d0, [x0, #7]
    // 0x65ac34: d0 = 0.000000
    //     0x65ac34: eor             v0.16b, v0.16b, v0.16b
    // 0x65ac38: StoreField: r0->field_f = d0
    //     0x65ac38: stur            d0, [x0, #0xf]
    // 0x65ac3c: ldur            x16, [fp, #-8]
    // 0x65ac40: stp             x0, x16, [SP, #-0x10]!
    // 0x65ac44: r0 = +()
    //     0x65ac44: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x65ac48: add             SP, SP, #0x10
    // 0x65ac4c: LeaveFrame
    //     0x65ac4c: mov             SP, fp
    //     0x65ac50: ldp             fp, lr, [SP], #0x10
    // 0x65ac54: ret
    //     0x65ac54: ret             
    // 0x65ac58: mov             x1, x0
    // 0x65ac5c: mov             v1.16b, v0.16b
    // 0x65ac60: d0 = 0.000000
    //     0x65ac60: eor             v0.16b, v0.16b, v0.16b
    // 0x65ac64: LoadField: r0 = r1->field_17
    //     0x65ac64: ldur            w0, [x1, #0x17]
    // 0x65ac68: DecompressPointer r0
    //     0x65ac68: add             x0, x0, HEAP, lsl #32
    // 0x65ac6c: tbnz            w0, #4, #0x65ad04
    // 0x65ac70: ldr             x16, [fp, #0x10]
    // 0x65ac74: SaveReg r16
    //     0x65ac74: str             x16, [SP, #-8]!
    // 0x65ac78: r0 = center()
    //     0x65ac78: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x65ac7c: add             SP, SP, #8
    // 0x65ac80: LoadField: d0 = r0->field_7
    //     0x65ac80: ldur            d0, [x0, #7]
    // 0x65ac84: stur            d0, [fp, #-0x18]
    // 0x65ac88: ldr             x16, [fp, #0x10]
    // 0x65ac8c: SaveReg r16
    //     0x65ac8c: str             x16, [SP, #-8]!
    // 0x65ac90: r0 = center()
    //     0x65ac90: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x65ac94: add             SP, SP, #8
    // 0x65ac98: LoadField: d0 = r0->field_f
    //     0x65ac98: ldur            d0, [x0, #0xf]
    // 0x65ac9c: ldur            d1, [fp, #-0x10]
    // 0x65aca0: fmul            d2, d0, d1
    // 0x65aca4: stur            d2, [fp, #-0x20]
    // 0x65aca8: r0 = Offset()
    //     0x65aca8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65acac: ldur            d0, [fp, #-0x18]
    // 0x65acb0: stur            x0, [fp, #-8]
    // 0x65acb4: StoreField: r0->field_7 = d0
    //     0x65acb4: stur            d0, [x0, #7]
    // 0x65acb8: ldur            d0, [fp, #-0x20]
    // 0x65acbc: StoreField: r0->field_f = d0
    //     0x65acbc: stur            d0, [x0, #0xf]
    // 0x65acc0: ldr             x1, [fp, #0x18]
    // 0x65acc4: LoadField: r2 = r1->field_7
    //     0x65acc4: ldur            w2, [x1, #7]
    // 0x65acc8: DecompressPointer r2
    //     0x65acc8: add             x2, x2, HEAP, lsl #32
    // 0x65accc: LoadField: d0 = r2->field_f
    //     0x65accc: ldur            d0, [x2, #0xf]
    // 0x65acd0: stur            d0, [fp, #-0x10]
    // 0x65acd4: r0 = Offset()
    //     0x65acd4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65acd8: d0 = 0.000000
    //     0x65acd8: eor             v0.16b, v0.16b, v0.16b
    // 0x65acdc: StoreField: r0->field_7 = d0
    //     0x65acdc: stur            d0, [x0, #7]
    // 0x65ace0: ldur            d0, [fp, #-0x10]
    // 0x65ace4: StoreField: r0->field_f = d0
    //     0x65ace4: stur            d0, [x0, #0xf]
    // 0x65ace8: ldur            x16, [fp, #-8]
    // 0x65acec: stp             x0, x16, [SP, #-0x10]!
    // 0x65acf0: r0 = +()
    //     0x65acf0: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x65acf4: add             SP, SP, #0x10
    // 0x65acf8: LeaveFrame
    //     0x65acf8: mov             SP, fp
    //     0x65acfc: ldp             fp, lr, [SP], #0x10
    // 0x65ad00: ret
    //     0x65ad00: ret             
    // 0x65ad04: ldr             x16, [fp, #0x10]
    // 0x65ad08: SaveReg r16
    //     0x65ad08: str             x16, [SP, #-8]!
    // 0x65ad0c: r0 = center()
    //     0x65ad0c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x65ad10: add             SP, SP, #8
    // 0x65ad14: LeaveFrame
    //     0x65ad14: mov             SP, fp
    //     0x65ad18: ldp             fp, lr, [SP], #0x10
    // 0x65ad1c: ret
    //     0x65ad1c: ret             
    // 0x65ad20: ldr             x16, [fp, #0x10]
    // 0x65ad24: SaveReg r16
    //     0x65ad24: str             x16, [SP, #-8]!
    // 0x65ad28: r0 = center()
    //     0x65ad28: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x65ad2c: add             SP, SP, #8
    // 0x65ad30: LeaveFrame
    //     0x65ad30: mov             SP, fp
    //     0x65ad34: ldp             fp, lr, [SP], #0x10
    // 0x65ad38: ret
    //     0x65ad38: ret             
    // 0x65ad3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65ad3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65ad40: b               #0x65aae4
    // 0x65ad44: SaveReg d0
    //     0x65ad44: str             q0, [SP, #-0x10]!
    // 0x65ad48: SaveReg r0
    //     0x65ad48: str             x0, [SP, #-8]!
    // 0x65ad4c: r0 = AllocateDouble()
    //     0x65ad4c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65ad50: mov             x1, x0
    // 0x65ad54: RestoreReg r0
    //     0x65ad54: ldr             x0, [SP], #8
    // 0x65ad58: RestoreReg d0
    //     0x65ad58: ldr             q0, [SP], #0x10
    // 0x65ad5c: b               #0x65ab7c
  }
  _ GestureDetails(/* No info */) {
    // ** addr: 0x79bd90, size: 0x26c
    // 0x79bd90: EnterFrame
    //     0x79bd90: stp             fp, lr, [SP, #-0x10]!
    //     0x79bd94: mov             fp, SP
    // 0x79bd98: AllocStack(0x30)
    //     0x79bd98: sub             SP, SP, #0x30
    // 0x79bd9c: SetupParameters(GestureDetails this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, dynamic _ /* d0, fp-0x30 */, {dynamic actionType = Instance_ActionType /* r5, fp-0x18 */, dynamic gestureDetails = Null /* r6, fp-0x10 */, dynamic userOffset = true /* r1 */})
    //     0x79bd9c: mov             x0, x4
    //     0x79bda0: ldur            w1, [x0, #0x13]
    //     0x79bda4: add             x1, x1, HEAP, lsl #32
    //     0x79bda8: sub             x2, x1, #6
    //     0x79bdac: add             x3, fp, w2, sxtw #2
    //     0x79bdb0: ldr             x3, [x3, #0x20]
    //     0x79bdb4: stur            x3, [fp, #-0x28]
    //     0x79bdb8: add             x4, fp, w2, sxtw #2
    //     0x79bdbc: ldr             x4, [x4, #0x18]
    //     0x79bdc0: stur            x4, [fp, #-0x20]
    //     0x79bdc4: add             x5, fp, w2, sxtw #2
    //     0x79bdc8: ldr             d0, [x5, #0x10]
    //     0x79bdcc: stur            d0, [fp, #-0x30]
    //     0x79bdd0: ldur            w2, [x0, #0x1f]
    //     0x79bdd4: add             x2, x2, HEAP, lsl #32
    //     0x79bdd8: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c5e8] "actionType"
    //     0x79bddc: ldr             x16, [x16, #0x5e8]
    //     0x79bde0: cmp             w2, w16
    //     0x79bde4: b.ne            #0x79be08
    //     0x79bde8: ldur            w2, [x0, #0x23]
    //     0x79bdec: add             x2, x2, HEAP, lsl #32
    //     0x79bdf0: sub             w5, w1, w2
    //     0x79bdf4: add             x2, fp, w5, sxtw #2
    //     0x79bdf8: ldr             x2, [x2, #8]
    //     0x79bdfc: mov             x5, x2
    //     0x79be00: mov             x2, #1
    //     0x79be04: b               #0x79be14
    //     0x79be08: add             x5, PP, #0x4c, lsl #12  ; [pp+0x4c5f0] Obj!ActionType@b66131
    //     0x79be0c: ldr             x5, [x5, #0x5f0]
    //     0x79be10: mov             x2, #0
    //     0x79be14: stur            x5, [fp, #-0x18]
    //     0x79be18: lsl             x6, x2, #1
    //     0x79be1c: lsl             w7, w6, #1
    //     0x79be20: add             w8, w7, #8
    //     0x79be24: add             x16, x0, w8, sxtw #1
    //     0x79be28: ldur            w9, [x16, #0xf]
    //     0x79be2c: add             x9, x9, HEAP, lsl #32
    //     0x79be30: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c5f8] "gestureDetails"
    //     0x79be34: ldr             x16, [x16, #0x5f8]
    //     0x79be38: cmp             w9, w16
    //     0x79be3c: b.ne            #0x79be70
    //     0x79be40: add             w2, w7, #0xa
    //     0x79be44: add             x16, x0, w2, sxtw #1
    //     0x79be48: ldur            w7, [x16, #0xf]
    //     0x79be4c: add             x7, x7, HEAP, lsl #32
    //     0x79be50: sub             w2, w1, w7
    //     0x79be54: add             x7, fp, w2, sxtw #2
    //     0x79be58: ldr             x7, [x7, #8]
    //     0x79be5c: add             w2, w6, #2
    //     0x79be60: sbfx            x6, x2, #1, #0x1f
    //     0x79be64: mov             x2, x6
    //     0x79be68: mov             x6, x7
    //     0x79be6c: b               #0x79be74
    //     0x79be70: mov             x6, NULL
    //     0x79be74: stur            x6, [fp, #-0x10]
    //     0x79be78: lsl             x7, x2, #1
    //     0x79be7c: lsl             w2, w7, #1
    //     0x79be80: add             w7, w2, #8
    //     0x79be84: add             x16, x0, w7, sxtw #1
    //     0x79be88: ldur            w8, [x16, #0xf]
    //     0x79be8c: add             x8, x8, HEAP, lsl #32
    //     0x79be90: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c600] "userOffset"
    //     0x79be94: ldr             x16, [x16, #0x600]
    //     0x79be98: cmp             w8, w16
    //     0x79be9c: b.ne            #0x79bec0
    //     0x79bea0: add             w7, w2, #0xa
    //     0x79bea4: add             x16, x0, w7, sxtw #1
    //     0x79bea8: ldur            w2, [x16, #0xf]
    //     0x79beac: add             x2, x2, HEAP, lsl #32
    //     0x79beb0: sub             w0, w1, w2
    //     0x79beb4: add             x1, fp, w0, sxtw #2
    //     0x79beb8: ldr             x1, [x1, #8]
    //     0x79bebc: b               #0x79bec4
    //     0x79bec0: add             x1, NULL, #0x20  ; true
    // 0x79bec4: r0 = false
    //     0x79bec4: add             x0, NULL, #0x30  ; false
    // 0x79bec8: stur            x1, [fp, #-8]
    // 0x79becc: StoreField: r3->field_17 = r0
    //     0x79becc: stur            w0, [x3, #0x17]
    // 0x79bed0: StoreField: r3->field_1b = r0
    //     0x79bed0: stur            w0, [x3, #0x1b]
    // 0x79bed4: r0 = Boundary()
    //     0x79bed4: bl              #0x65ad60  ; AllocateBoundaryStub -> Boundary (size=0x18)
    // 0x79bed8: r1 = false
    //     0x79bed8: add             x1, NULL, #0x30  ; false
    // 0x79bedc: StoreField: r0->field_7 = r1
    //     0x79bedc: stur            w1, [x0, #7]
    // 0x79bee0: StoreField: r0->field_b = r1
    //     0x79bee0: stur            w1, [x0, #0xb]
    // 0x79bee4: StoreField: r0->field_13 = r1
    //     0x79bee4: stur            w1, [x0, #0x13]
    // 0x79bee8: StoreField: r0->field_f = r1
    //     0x79bee8: stur            w1, [x0, #0xf]
    // 0x79beec: ldur            x1, [fp, #-0x28]
    // 0x79bef0: StoreField: r1->field_1f = r0
    //     0x79bef0: stur            w0, [x1, #0x1f]
    //     0x79bef4: ldurb           w16, [x1, #-1]
    //     0x79bef8: ldurb           w17, [x0, #-1]
    //     0x79befc: and             x16, x17, x16, lsr #2
    //     0x79bf00: tst             x16, HEAP, lsr #32
    //     0x79bf04: b.eq            #0x79bf0c
    //     0x79bf08: bl              #0xd6826c
    // 0x79bf0c: ldur            x0, [fp, #-0x20]
    // 0x79bf10: StoreField: r1->field_7 = r0
    //     0x79bf10: stur            w0, [x1, #7]
    //     0x79bf14: ldurb           w16, [x1, #-1]
    //     0x79bf18: ldurb           w17, [x0, #-1]
    //     0x79bf1c: and             x16, x17, x16, lsr #2
    //     0x79bf20: tst             x16, HEAP, lsr #32
    //     0x79bf24: b.eq            #0x79bf2c
    //     0x79bf28: bl              #0xd6826c
    // 0x79bf2c: ldur            d0, [fp, #-0x30]
    // 0x79bf30: StoreField: r1->field_b = d0
    //     0x79bf30: stur            d0, [x1, #0xb]
    // 0x79bf34: ldur            x0, [fp, #-0x18]
    // 0x79bf38: StoreField: r1->field_13 = r0
    //     0x79bf38: stur            w0, [x1, #0x13]
    //     0x79bf3c: ldurb           w16, [x1, #-1]
    //     0x79bf40: ldurb           w17, [x0, #-1]
    //     0x79bf44: and             x16, x17, x16, lsr #2
    //     0x79bf48: tst             x16, HEAP, lsr #32
    //     0x79bf4c: b.eq            #0x79bf54
    //     0x79bf50: bl              #0xd6826c
    // 0x79bf54: ldur            x2, [fp, #-8]
    // 0x79bf58: StoreField: r1->field_23 = r2
    //     0x79bf58: stur            w2, [x1, #0x23]
    // 0x79bf5c: ldur            x2, [fp, #-0x10]
    // 0x79bf60: cmp             w2, NULL
    // 0x79bf64: b.eq            #0x79bfec
    // 0x79bf68: LoadField: r3 = r2->field_17
    //     0x79bf68: ldur            w3, [x2, #0x17]
    // 0x79bf6c: DecompressPointer r3
    //     0x79bf6c: add             x3, x3, HEAP, lsl #32
    // 0x79bf70: StoreField: r1->field_17 = r3
    //     0x79bf70: stur            w3, [x1, #0x17]
    // 0x79bf74: LoadField: r3 = r2->field_1b
    //     0x79bf74: ldur            w3, [x2, #0x1b]
    // 0x79bf78: DecompressPointer r3
    //     0x79bf78: add             x3, x3, HEAP, lsl #32
    // 0x79bf7c: StoreField: r1->field_1b = r3
    //     0x79bf7c: stur            w3, [x1, #0x1b]
    // 0x79bf80: LoadField: r0 = r2->field_27
    //     0x79bf80: ldur            w0, [x2, #0x27]
    // 0x79bf84: DecompressPointer r0
    //     0x79bf84: add             x0, x0, HEAP, lsl #32
    // 0x79bf88: StoreField: r1->field_27 = r0
    //     0x79bf88: stur            w0, [x1, #0x27]
    //     0x79bf8c: ldurb           w16, [x1, #-1]
    //     0x79bf90: ldurb           w17, [x0, #-1]
    //     0x79bf94: and             x16, x17, x16, lsr #2
    //     0x79bf98: tst             x16, HEAP, lsr #32
    //     0x79bf9c: b.eq            #0x79bfa4
    //     0x79bfa0: bl              #0xd6826c
    // 0x79bfa4: LoadField: r0 = r2->field_2b
    //     0x79bfa4: ldur            w0, [x2, #0x2b]
    // 0x79bfa8: DecompressPointer r0
    //     0x79bfa8: add             x0, x0, HEAP, lsl #32
    // 0x79bfac: StoreField: r1->field_2b = r0
    //     0x79bfac: stur            w0, [x1, #0x2b]
    //     0x79bfb0: ldurb           w16, [x1, #-1]
    //     0x79bfb4: ldurb           w17, [x0, #-1]
    //     0x79bfb8: and             x16, x17, x16, lsr #2
    //     0x79bfbc: tst             x16, HEAP, lsr #32
    //     0x79bfc0: b.eq            #0x79bfc8
    //     0x79bfc4: bl              #0xd6826c
    // 0x79bfc8: LoadField: r0 = r2->field_2f
    //     0x79bfc8: ldur            w0, [x2, #0x2f]
    // 0x79bfcc: DecompressPointer r0
    //     0x79bfcc: add             x0, x0, HEAP, lsl #32
    // 0x79bfd0: StoreField: r1->field_2f = r0
    //     0x79bfd0: stur            w0, [x1, #0x2f]
    //     0x79bfd4: ldurb           w16, [x1, #-1]
    //     0x79bfd8: ldurb           w17, [x0, #-1]
    //     0x79bfdc: and             x16, x17, x16, lsr #2
    //     0x79bfe0: tst             x16, HEAP, lsr #32
    //     0x79bfe4: b.eq            #0x79bfec
    //     0x79bfe8: bl              #0xd6826c
    // 0x79bfec: r0 = Null
    //     0x79bfec: mov             x0, NULL
    // 0x79bff0: LeaveFrame
    //     0x79bff0: mov             SP, fp
    //     0x79bff4: ldp             fp, lr, [SP], #0x10
    // 0x79bff8: ret
    //     0x79bff8: ret             
  }
  _ movePage(/* No info */) {
    // ** addr: 0x82edac, size: 0xfc
    // 0x82edac: d0 = 1.000000
    //     0x82edac: fmov            d0, #1.00000000
    // 0x82edb0: ldr             x1, [SP, #8]
    // 0x82edb4: LoadField: d1 = r1->field_b
    //     0x82edb4: ldur            d1, [x1, #0xb]
    // 0x82edb8: fcmp            d1, d0
    // 0x82edbc: b.vs            #0x82edcc
    // 0x82edc0: b.gt            #0x82edcc
    // 0x82edc4: r0 = false
    //     0x82edc4: add             x0, NULL, #0x30  ; false
    // 0x82edc8: ret
    //     0x82edc8: ret             
    // 0x82edcc: ldr             x2, [SP]
    // 0x82edd0: d0 = 0.000000
    //     0x82edd0: eor             v0.16b, v0.16b, v0.16b
    // 0x82edd4: LoadField: d1 = r2->field_7
    //     0x82edd4: ldur            d1, [x2, #7]
    // 0x82edd8: fcmp            d1, d0
    // 0x82eddc: b.eq            #0x82eea0
    // 0x82ede0: fcmp            d1, d0
    // 0x82ede4: b.vs            #0x82edf4
    // 0x82ede8: b.ne            #0x82edf4
    // 0x82edec: d2 = 0.000000
    //     0x82edec: eor             v2.16b, v2.16b, v2.16b
    // 0x82edf0: b               #0x82ee0c
    // 0x82edf4: fcmp            d1, d0
    // 0x82edf8: b.vs            #0x82ee08
    // 0x82edfc: b.ge            #0x82ee08
    // 0x82ee00: fneg            d2, d1
    // 0x82ee04: b               #0x82ee0c
    // 0x82ee08: mov             v2.16b, v1.16b
    // 0x82ee0c: LoadField: d3 = r2->field_f
    //     0x82ee0c: ldur            d3, [x2, #0xf]
    // 0x82ee10: fcmp            d3, d0
    // 0x82ee14: b.vs            #0x82ee24
    // 0x82ee18: b.ne            #0x82ee24
    // 0x82ee1c: d3 = 0.000000
    //     0x82ee1c: eor             v3.16b, v3.16b, v3.16b
    // 0x82ee20: b               #0x82ee38
    // 0x82ee24: fcmp            d3, d0
    // 0x82ee28: b.vs            #0x82ee38
    // 0x82ee2c: b.ge            #0x82ee38
    // 0x82ee30: fneg            d4, d3
    // 0x82ee34: mov             v3.16b, v4.16b
    // 0x82ee38: fcmp            d2, d3
    // 0x82ee3c: b.vs            #0x82eea0
    // 0x82ee40: b.le            #0x82eea0
    // 0x82ee44: fcmp            d1, d0
    // 0x82ee48: b.vs            #0x82ee64
    // 0x82ee4c: b.ge            #0x82ee64
    // 0x82ee50: LoadField: r2 = r1->field_1f
    //     0x82ee50: ldur            w2, [x1, #0x1f]
    // 0x82ee54: DecompressPointer r2
    //     0x82ee54: add             x2, x2, HEAP, lsl #32
    // 0x82ee58: LoadField: r3 = r2->field_b
    //     0x82ee58: ldur            w3, [x2, #0xb]
    // 0x82ee5c: DecompressPointer r3
    //     0x82ee5c: add             x3, x3, HEAP, lsl #32
    // 0x82ee60: tbz             w3, #4, #0x82ee84
    // 0x82ee64: fcmp            d1, d0
    // 0x82ee68: b.vs            #0x82ee8c
    // 0x82ee6c: b.le            #0x82ee8c
    // 0x82ee70: LoadField: r2 = r1->field_1f
    //     0x82ee70: ldur            w2, [x1, #0x1f]
    // 0x82ee74: DecompressPointer r2
    //     0x82ee74: add             x2, x2, HEAP, lsl #32
    // 0x82ee78: LoadField: r3 = r2->field_7
    //     0x82ee78: ldur            w3, [x2, #7]
    // 0x82ee7c: DecompressPointer r3
    //     0x82ee7c: add             x3, x3, HEAP, lsl #32
    // 0x82ee80: tbnz            w3, #4, #0x82ee8c
    // 0x82ee84: r0 = true
    //     0x82ee84: add             x0, NULL, #0x20  ; true
    // 0x82ee88: b               #0x82eea4
    // 0x82ee8c: LoadField: r2 = r1->field_1b
    //     0x82ee8c: ldur            w2, [x1, #0x1b]
    // 0x82ee90: DecompressPointer r2
    //     0x82ee90: add             x2, x2, HEAP, lsl #32
    // 0x82ee94: eor             x1, x2, #0x10
    // 0x82ee98: mov             x0, x1
    // 0x82ee9c: b               #0x82eea4
    // 0x82eea0: r0 = false
    //     0x82eea0: add             x0, NULL, #0x30  ; false
    // 0x82eea4: ret
    //     0x82eea4: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafadd8, size: 0x118
    // 0xafadd8: EnterFrame
    //     0xafadd8: stp             fp, lr, [SP, #-0x10]!
    //     0xafaddc: mov             fp, SP
    // 0xafade0: CheckStackOverflow
    //     0xafade0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafade4: cmp             SP, x16
    //     0xafade8: b.ls            #0xafaeb0
    // 0xafadec: ldr             x0, [fp, #0x10]
    // 0xafadf0: LoadField: r1 = r0->field_7
    //     0xafadf0: ldur            w1, [x0, #7]
    // 0xafadf4: DecompressPointer r1
    //     0xafadf4: add             x1, x1, HEAP, lsl #32
    // 0xafadf8: LoadField: d0 = r0->field_b
    //     0xafadf8: ldur            d0, [x0, #0xb]
    // 0xafadfc: LoadField: r2 = r0->field_17
    //     0xafadfc: ldur            w2, [x0, #0x17]
    // 0xafae00: DecompressPointer r2
    //     0xafae00: add             x2, x2, HEAP, lsl #32
    // 0xafae04: LoadField: r3 = r0->field_1b
    //     0xafae04: ldur            w3, [x0, #0x1b]
    // 0xafae08: DecompressPointer r3
    //     0xafae08: add             x3, x3, HEAP, lsl #32
    // 0xafae0c: LoadField: r4 = r0->field_1f
    //     0xafae0c: ldur            w4, [x0, #0x1f]
    // 0xafae10: DecompressPointer r4
    //     0xafae10: add             x4, x4, HEAP, lsl #32
    // 0xafae14: LoadField: r5 = r0->field_13
    //     0xafae14: ldur            w5, [x0, #0x13]
    // 0xafae18: DecompressPointer r5
    //     0xafae18: add             x5, x5, HEAP, lsl #32
    // 0xafae1c: LoadField: r6 = r0->field_23
    //     0xafae1c: ldur            w6, [x0, #0x23]
    // 0xafae20: DecompressPointer r6
    //     0xafae20: add             x6, x6, HEAP, lsl #32
    // 0xafae24: LoadField: r7 = r0->field_2b
    //     0xafae24: ldur            w7, [x0, #0x2b]
    // 0xafae28: DecompressPointer r7
    //     0xafae28: add             x7, x7, HEAP, lsl #32
    // 0xafae2c: LoadField: r8 = r0->field_2f
    //     0xafae2c: ldur            w8, [x0, #0x2f]
    // 0xafae30: DecompressPointer r8
    //     0xafae30: add             x8, x8, HEAP, lsl #32
    // 0xafae34: LoadField: r9 = r0->field_27
    //     0xafae34: ldur            w9, [x0, #0x27]
    // 0xafae38: DecompressPointer r9
    //     0xafae38: add             x9, x9, HEAP, lsl #32
    // 0xafae3c: r0 = inline_Allocate_Double()
    //     0xafae3c: ldp             x0, x10, [THR, #0x60]  ; THR::top
    //     0xafae40: add             x0, x0, #0x10
    //     0xafae44: cmp             x10, x0
    //     0xafae48: b.ls            #0xafaeb8
    //     0xafae4c: str             x0, [THR, #0x60]  ; THR::top
    //     0xafae50: sub             x0, x0, #0xf
    //     0xafae54: mov             x10, #0xd108
    //     0xafae58: movk            x10, #3, lsl #16
    //     0xafae5c: stur            x10, [x0, #-1]
    // 0xafae60: StoreField: r0->field_7 = d0
    //     0xafae60: stur            d0, [x0, #7]
    // 0xafae64: stp             x0, x1, [SP, #-0x10]!
    // 0xafae68: stp             x3, x2, [SP, #-0x10]!
    // 0xafae6c: stp             x5, x4, [SP, #-0x10]!
    // 0xafae70: stp             x7, x6, [SP, #-0x10]!
    // 0xafae74: stp             x9, x8, [SP, #-0x10]!
    // 0xafae78: SaveReg rNULL
    //     0xafae78: str             NULL, [SP, #-8]!
    // 0xafae7c: r4 = const [0, 0xb, 0xb, 0xb, null]
    //     0xafae7c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe128] List(5) [0, 0xb, 0xb, 0xb, Null]
    //     0xafae80: ldr             x4, [x4, #0x128]
    // 0xafae84: r0 = hash()
    //     0xafae84: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafae88: add             SP, SP, #0x58
    // 0xafae8c: mov             x2, x0
    // 0xafae90: r0 = BoxInt64Instr(r2)
    //     0xafae90: sbfiz           x0, x2, #1, #0x1f
    //     0xafae94: cmp             x2, x0, asr #1
    //     0xafae98: b.eq            #0xafaea4
    //     0xafae9c: bl              #0xd69bb8
    //     0xafaea0: stur            x2, [x0, #7]
    // 0xafaea4: LeaveFrame
    //     0xafaea4: mov             SP, fp
    //     0xafaea8: ldp             fp, lr, [SP], #0x10
    // 0xafaeac: ret
    //     0xafaeac: ret             
    // 0xafaeb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafaeb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafaeb4: b               #0xafadec
    // 0xafaeb8: SaveReg d0
    //     0xafaeb8: str             q0, [SP, #-0x10]!
    // 0xafaebc: stp             x8, x9, [SP, #-0x10]!
    // 0xafaec0: stp             x6, x7, [SP, #-0x10]!
    // 0xafaec4: stp             x4, x5, [SP, #-0x10]!
    // 0xafaec8: stp             x2, x3, [SP, #-0x10]!
    // 0xafaecc: SaveReg r1
    //     0xafaecc: str             x1, [SP, #-8]!
    // 0xafaed0: r0 = AllocateDouble()
    //     0xafaed0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xafaed4: RestoreReg r1
    //     0xafaed4: ldr             x1, [SP], #8
    // 0xafaed8: ldp             x2, x3, [SP], #0x10
    // 0xafaedc: ldp             x4, x5, [SP], #0x10
    // 0xafaee0: ldp             x6, x7, [SP], #0x10
    // 0xafaee4: ldp             x8, x9, [SP], #0x10
    // 0xafaee8: RestoreReg d0
    //     0xafaee8: ldr             q0, [SP], #0x10
    // 0xafaeec: b               #0xafae60
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6f734, size: 0x2cc
    // 0xc6f734: EnterFrame
    //     0xc6f734: stp             fp, lr, [SP, #-0x10]!
    //     0xc6f738: mov             fp, SP
    // 0xc6f73c: AllocStack(0x10)
    //     0xc6f73c: sub             SP, SP, #0x10
    // 0xc6f740: CheckStackOverflow
    //     0xc6f740: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6f744: cmp             SP, x16
    //     0xc6f748: b.ls            #0xc6f9f8
    // 0xc6f74c: ldr             x1, [fp, #0x10]
    // 0xc6f750: cmp             w1, NULL
    // 0xc6f754: b.ne            #0xc6f768
    // 0xc6f758: r0 = false
    //     0xc6f758: add             x0, NULL, #0x30  ; false
    // 0xc6f75c: LeaveFrame
    //     0xc6f75c: mov             SP, fp
    //     0xc6f760: ldp             fp, lr, [SP], #0x10
    // 0xc6f764: ret
    //     0xc6f764: ret             
    // 0xc6f768: r0 = 59
    //     0xc6f768: mov             x0, #0x3b
    // 0xc6f76c: branchIfSmi(r1, 0xc6f778)
    //     0xc6f76c: tbz             w1, #0, #0xc6f778
    // 0xc6f770: r0 = LoadClassIdInstr(r1)
    //     0xc6f770: ldur            x0, [x1, #-1]
    //     0xc6f774: ubfx            x0, x0, #0xc, #0x14
    // 0xc6f778: SaveReg r1
    //     0xc6f778: str             x1, [SP, #-8]!
    // 0xc6f77c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc6f77c: mov             x17, #0x57c5
    //     0xc6f780: add             lr, x0, x17
    //     0xc6f784: ldr             lr, [x21, lr, lsl #3]
    //     0xc6f788: blr             lr
    // 0xc6f78c: add             SP, SP, #8
    // 0xc6f790: r1 = LoadClassIdInstr(r0)
    //     0xc6f790: ldur            x1, [x0, #-1]
    //     0xc6f794: ubfx            x1, x1, #0xc, #0x14
    // 0xc6f798: r16 = GestureDetails
    //     0xc6f798: add             x16, PP, #0x51, lsl #12  ; [pp+0x513a8] Type: GestureDetails
    //     0xc6f79c: ldr             x16, [x16, #0x3a8]
    // 0xc6f7a0: stp             x16, x0, [SP, #-0x10]!
    // 0xc6f7a4: mov             x0, x1
    // 0xc6f7a8: mov             lr, x0
    // 0xc6f7ac: ldr             lr, [x21, lr, lsl #3]
    // 0xc6f7b0: blr             lr
    // 0xc6f7b4: add             SP, SP, #0x10
    // 0xc6f7b8: tbz             w0, #4, #0xc6f7cc
    // 0xc6f7bc: r0 = false
    //     0xc6f7bc: add             x0, NULL, #0x30  ; false
    // 0xc6f7c0: LeaveFrame
    //     0xc6f7c0: mov             SP, fp
    //     0xc6f7c4: ldp             fp, lr, [SP], #0x10
    // 0xc6f7c8: ret
    //     0xc6f7c8: ret             
    // 0xc6f7cc: ldr             x0, [fp, #0x10]
    // 0xc6f7d0: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6f7d0: mov             x1, #0x76
    //     0xc6f7d4: tbz             w0, #0, #0xc6f7e4
    //     0xc6f7d8: ldur            x1, [x0, #-1]
    //     0xc6f7dc: ubfx            x1, x1, #0xc, #0x14
    //     0xc6f7e0: lsl             x1, x1, #1
    // 0xc6f7e4: r17 = 8960
    //     0xc6f7e4: mov             x17, #0x2300
    // 0xc6f7e8: cmp             w1, w17
    // 0xc6f7ec: b.ne            #0xc6f9e8
    // 0xc6f7f0: ldr             x1, [fp, #0x18]
    // 0xc6f7f4: LoadField: r2 = r1->field_7
    //     0xc6f7f4: ldur            w2, [x1, #7]
    // 0xc6f7f8: DecompressPointer r2
    //     0xc6f7f8: add             x2, x2, HEAP, lsl #32
    // 0xc6f7fc: LoadField: r3 = r0->field_7
    //     0xc6f7fc: ldur            w3, [x0, #7]
    // 0xc6f800: DecompressPointer r3
    //     0xc6f800: add             x3, x3, HEAP, lsl #32
    // 0xc6f804: stp             x3, x2, [SP, #-0x10]!
    // 0xc6f808: r0 = ==()
    //     0xc6f808: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xc6f80c: add             SP, SP, #0x10
    // 0xc6f810: tbnz            w0, #4, #0xc6f9e8
    // 0xc6f814: ldr             x1, [fp, #0x18]
    // 0xc6f818: ldr             x0, [fp, #0x10]
    // 0xc6f81c: LoadField: d0 = r1->field_b
    //     0xc6f81c: ldur            d0, [x1, #0xb]
    // 0xc6f820: LoadField: d1 = r0->field_b
    //     0xc6f820: ldur            d1, [x0, #0xb]
    // 0xc6f824: fcmp            d0, d1
    // 0xc6f828: b.vs            #0xc6f9e8
    // 0xc6f82c: b.ne            #0xc6f9e8
    // 0xc6f830: LoadField: r2 = r1->field_17
    //     0xc6f830: ldur            w2, [x1, #0x17]
    // 0xc6f834: DecompressPointer r2
    //     0xc6f834: add             x2, x2, HEAP, lsl #32
    // 0xc6f838: LoadField: r3 = r0->field_17
    //     0xc6f838: ldur            w3, [x0, #0x17]
    // 0xc6f83c: DecompressPointer r3
    //     0xc6f83c: add             x3, x3, HEAP, lsl #32
    // 0xc6f840: cmp             w2, w3
    // 0xc6f844: b.ne            #0xc6f9e8
    // 0xc6f848: LoadField: r2 = r1->field_1b
    //     0xc6f848: ldur            w2, [x1, #0x1b]
    // 0xc6f84c: DecompressPointer r2
    //     0xc6f84c: add             x2, x2, HEAP, lsl #32
    // 0xc6f850: LoadField: r3 = r0->field_1b
    //     0xc6f850: ldur            w3, [x0, #0x1b]
    // 0xc6f854: DecompressPointer r3
    //     0xc6f854: add             x3, x3, HEAP, lsl #32
    // 0xc6f858: cmp             w2, w3
    // 0xc6f85c: b.ne            #0xc6f9e8
    // 0xc6f860: LoadField: r2 = r1->field_1f
    //     0xc6f860: ldur            w2, [x1, #0x1f]
    // 0xc6f864: DecompressPointer r2
    //     0xc6f864: add             x2, x2, HEAP, lsl #32
    // 0xc6f868: stur            x2, [fp, #-0x10]
    // 0xc6f86c: LoadField: r3 = r0->field_1f
    //     0xc6f86c: ldur            w3, [x0, #0x1f]
    // 0xc6f870: DecompressPointer r3
    //     0xc6f870: add             x3, x3, HEAP, lsl #32
    // 0xc6f874: stur            x3, [fp, #-8]
    // 0xc6f878: r16 = Boundary
    //     0xc6f878: add             x16, PP, #0x41, lsl #12  ; [pp+0x41000] Type: Boundary
    //     0xc6f87c: ldr             x16, [x16]
    // 0xc6f880: r30 = Boundary
    //     0xc6f880: add             lr, PP, #0x41, lsl #12  ; [pp+0x41000] Type: Boundary
    //     0xc6f884: ldr             lr, [lr]
    // 0xc6f888: stp             lr, x16, [SP, #-0x10]!
    // 0xc6f88c: r0 = ==()
    //     0xc6f88c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc6f890: add             SP, SP, #0x10
    // 0xc6f894: tbnz            w0, #4, #0xc6f9e8
    // 0xc6f898: ldur            x0, [fp, #-0x10]
    // 0xc6f89c: ldur            x1, [fp, #-8]
    // 0xc6f8a0: LoadField: r2 = r0->field_7
    //     0xc6f8a0: ldur            w2, [x0, #7]
    // 0xc6f8a4: DecompressPointer r2
    //     0xc6f8a4: add             x2, x2, HEAP, lsl #32
    // 0xc6f8a8: LoadField: r3 = r1->field_7
    //     0xc6f8a8: ldur            w3, [x1, #7]
    // 0xc6f8ac: DecompressPointer r3
    //     0xc6f8ac: add             x3, x3, HEAP, lsl #32
    // 0xc6f8b0: cmp             w2, w3
    // 0xc6f8b4: b.ne            #0xc6f9e8
    // 0xc6f8b8: LoadField: r2 = r0->field_b
    //     0xc6f8b8: ldur            w2, [x0, #0xb]
    // 0xc6f8bc: DecompressPointer r2
    //     0xc6f8bc: add             x2, x2, HEAP, lsl #32
    // 0xc6f8c0: LoadField: r3 = r1->field_b
    //     0xc6f8c0: ldur            w3, [x1, #0xb]
    // 0xc6f8c4: DecompressPointer r3
    //     0xc6f8c4: add             x3, x3, HEAP, lsl #32
    // 0xc6f8c8: cmp             w2, w3
    // 0xc6f8cc: b.ne            #0xc6f9e8
    // 0xc6f8d0: LoadField: r2 = r0->field_13
    //     0xc6f8d0: ldur            w2, [x0, #0x13]
    // 0xc6f8d4: DecompressPointer r2
    //     0xc6f8d4: add             x2, x2, HEAP, lsl #32
    // 0xc6f8d8: LoadField: r3 = r1->field_13
    //     0xc6f8d8: ldur            w3, [x1, #0x13]
    // 0xc6f8dc: DecompressPointer r3
    //     0xc6f8dc: add             x3, x3, HEAP, lsl #32
    // 0xc6f8e0: cmp             w2, w3
    // 0xc6f8e4: b.ne            #0xc6f9e8
    // 0xc6f8e8: LoadField: r2 = r0->field_f
    //     0xc6f8e8: ldur            w2, [x0, #0xf]
    // 0xc6f8ec: DecompressPointer r2
    //     0xc6f8ec: add             x2, x2, HEAP, lsl #32
    // 0xc6f8f0: LoadField: r0 = r1->field_f
    //     0xc6f8f0: ldur            w0, [x1, #0xf]
    // 0xc6f8f4: DecompressPointer r0
    //     0xc6f8f4: add             x0, x0, HEAP, lsl #32
    // 0xc6f8f8: cmp             w2, w0
    // 0xc6f8fc: b.ne            #0xc6f9e8
    // 0xc6f900: ldr             x2, [fp, #0x18]
    // 0xc6f904: ldr             x1, [fp, #0x10]
    // 0xc6f908: LoadField: r0 = r2->field_13
    //     0xc6f908: ldur            w0, [x2, #0x13]
    // 0xc6f90c: DecompressPointer r0
    //     0xc6f90c: add             x0, x0, HEAP, lsl #32
    // 0xc6f910: LoadField: r3 = r1->field_13
    //     0xc6f910: ldur            w3, [x1, #0x13]
    // 0xc6f914: DecompressPointer r3
    //     0xc6f914: add             x3, x3, HEAP, lsl #32
    // 0xc6f918: cmp             w0, w3
    // 0xc6f91c: b.ne            #0xc6f9e8
    // 0xc6f920: LoadField: r0 = r2->field_23
    //     0xc6f920: ldur            w0, [x2, #0x23]
    // 0xc6f924: DecompressPointer r0
    //     0xc6f924: add             x0, x0, HEAP, lsl #32
    // 0xc6f928: LoadField: r3 = r1->field_23
    //     0xc6f928: ldur            w3, [x1, #0x23]
    // 0xc6f92c: DecompressPointer r3
    //     0xc6f92c: add             x3, x3, HEAP, lsl #32
    // 0xc6f930: cmp             w0, w3
    // 0xc6f934: b.ne            #0xc6f9e8
    // 0xc6f938: LoadField: r0 = r2->field_2b
    //     0xc6f938: ldur            w0, [x2, #0x2b]
    // 0xc6f93c: DecompressPointer r0
    //     0xc6f93c: add             x0, x0, HEAP, lsl #32
    // 0xc6f940: LoadField: r3 = r1->field_2b
    //     0xc6f940: ldur            w3, [x1, #0x2b]
    // 0xc6f944: DecompressPointer r3
    //     0xc6f944: add             x3, x3, HEAP, lsl #32
    // 0xc6f948: r4 = LoadClassIdInstr(r0)
    //     0xc6f948: ldur            x4, [x0, #-1]
    //     0xc6f94c: ubfx            x4, x4, #0xc, #0x14
    // 0xc6f950: stp             x3, x0, [SP, #-0x10]!
    // 0xc6f954: mov             x0, x4
    // 0xc6f958: mov             lr, x0
    // 0xc6f95c: ldr             lr, [x21, lr, lsl #3]
    // 0xc6f960: blr             lr
    // 0xc6f964: add             SP, SP, #0x10
    // 0xc6f968: tbnz            w0, #4, #0xc6f9e8
    // 0xc6f96c: ldr             x2, [fp, #0x18]
    // 0xc6f970: ldr             x1, [fp, #0x10]
    // 0xc6f974: LoadField: r0 = r2->field_2f
    //     0xc6f974: ldur            w0, [x2, #0x2f]
    // 0xc6f978: DecompressPointer r0
    //     0xc6f978: add             x0, x0, HEAP, lsl #32
    // 0xc6f97c: LoadField: r3 = r1->field_2f
    //     0xc6f97c: ldur            w3, [x1, #0x2f]
    // 0xc6f980: DecompressPointer r3
    //     0xc6f980: add             x3, x3, HEAP, lsl #32
    // 0xc6f984: r4 = LoadClassIdInstr(r0)
    //     0xc6f984: ldur            x4, [x0, #-1]
    //     0xc6f988: ubfx            x4, x4, #0xc, #0x14
    // 0xc6f98c: stp             x3, x0, [SP, #-0x10]!
    // 0xc6f990: mov             x0, x4
    // 0xc6f994: mov             lr, x0
    // 0xc6f998: ldr             lr, [x21, lr, lsl #3]
    // 0xc6f99c: blr             lr
    // 0xc6f9a0: add             SP, SP, #0x10
    // 0xc6f9a4: tbnz            w0, #4, #0xc6f9e8
    // 0xc6f9a8: ldr             x1, [fp, #0x18]
    // 0xc6f9ac: ldr             x0, [fp, #0x10]
    // 0xc6f9b0: LoadField: r2 = r1->field_27
    //     0xc6f9b0: ldur            w2, [x1, #0x27]
    // 0xc6f9b4: DecompressPointer r2
    //     0xc6f9b4: add             x2, x2, HEAP, lsl #32
    // 0xc6f9b8: LoadField: r1 = r0->field_27
    //     0xc6f9b8: ldur            w1, [x0, #0x27]
    // 0xc6f9bc: DecompressPointer r1
    //     0xc6f9bc: add             x1, x1, HEAP, lsl #32
    // 0xc6f9c0: r0 = LoadClassIdInstr(r2)
    //     0xc6f9c0: ldur            x0, [x2, #-1]
    //     0xc6f9c4: ubfx            x0, x0, #0xc, #0x14
    // 0xc6f9c8: stp             x1, x2, [SP, #-0x10]!
    // 0xc6f9cc: mov             lr, x0
    // 0xc6f9d0: ldr             lr, [x21, lr, lsl #3]
    // 0xc6f9d4: blr             lr
    // 0xc6f9d8: add             SP, SP, #0x10
    // 0xc6f9dc: tbnz            w0, #4, #0xc6f9e8
    // 0xc6f9e0: r0 = true
    //     0xc6f9e0: add             x0, NULL, #0x20  ; true
    // 0xc6f9e4: b               #0xc6f9ec
    // 0xc6f9e8: r0 = false
    //     0xc6f9e8: add             x0, NULL, #0x30  ; false
    // 0xc6f9ec: LeaveFrame
    //     0xc6f9ec: mov             SP, fp
    //     0xc6f9f0: ldp             fp, lr, [SP], #0x10
    // 0xc6f9f4: ret
    //     0xc6f9f4: ret             
    // 0xc6f9f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6f9f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6f9fc: b               #0xc6f74c
  }
}

// class id: 4481, size: 0x18, field offset: 0x8
class Boundary extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad3b30, size: 0xa4
    // 0xad3b30: EnterFrame
    //     0xad3b30: stp             fp, lr, [SP, #-0x10]!
    //     0xad3b34: mov             fp, SP
    // 0xad3b38: CheckStackOverflow
    //     0xad3b38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3b3c: cmp             SP, x16
    //     0xad3b40: b.ls            #0xad3bcc
    // 0xad3b44: r1 = Null
    //     0xad3b44: mov             x1, NULL
    // 0xad3b48: r2 = 16
    //     0xad3b48: mov             x2, #0x10
    // 0xad3b4c: r0 = AllocateArray()
    //     0xad3b4c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad3b50: r17 = "left:"
    //     0xad3b50: add             x17, PP, #0x41, lsl #12  ; [pp+0x41008] "left:"
    //     0xad3b54: ldr             x17, [x17, #8]
    // 0xad3b58: StoreField: r0->field_f = r17
    //     0xad3b58: stur            w17, [x0, #0xf]
    // 0xad3b5c: ldr             x1, [fp, #0x10]
    // 0xad3b60: LoadField: r2 = r1->field_7
    //     0xad3b60: ldur            w2, [x1, #7]
    // 0xad3b64: DecompressPointer r2
    //     0xad3b64: add             x2, x2, HEAP, lsl #32
    // 0xad3b68: StoreField: r0->field_13 = r2
    //     0xad3b68: stur            w2, [x0, #0x13]
    // 0xad3b6c: r17 = ",right:"
    //     0xad3b6c: add             x17, PP, #0x41, lsl #12  ; [pp+0x41010] ",right:"
    //     0xad3b70: ldr             x17, [x17, #0x10]
    // 0xad3b74: StoreField: r0->field_17 = r17
    //     0xad3b74: stur            w17, [x0, #0x17]
    // 0xad3b78: LoadField: r2 = r1->field_b
    //     0xad3b78: ldur            w2, [x1, #0xb]
    // 0xad3b7c: DecompressPointer r2
    //     0xad3b7c: add             x2, x2, HEAP, lsl #32
    // 0xad3b80: StoreField: r0->field_1b = r2
    //     0xad3b80: stur            w2, [x0, #0x1b]
    // 0xad3b84: r17 = ",top:"
    //     0xad3b84: add             x17, PP, #0x41, lsl #12  ; [pp+0x41018] ",top:"
    //     0xad3b88: ldr             x17, [x17, #0x18]
    // 0xad3b8c: StoreField: r0->field_1f = r17
    //     0xad3b8c: stur            w17, [x0, #0x1f]
    // 0xad3b90: LoadField: r2 = r1->field_13
    //     0xad3b90: ldur            w2, [x1, #0x13]
    // 0xad3b94: DecompressPointer r2
    //     0xad3b94: add             x2, x2, HEAP, lsl #32
    // 0xad3b98: StoreField: r0->field_23 = r2
    //     0xad3b98: stur            w2, [x0, #0x23]
    // 0xad3b9c: r17 = ",bottom:"
    //     0xad3b9c: add             x17, PP, #0x41, lsl #12  ; [pp+0x41020] ",bottom:"
    //     0xad3ba0: ldr             x17, [x17, #0x20]
    // 0xad3ba4: StoreField: r0->field_27 = r17
    //     0xad3ba4: stur            w17, [x0, #0x27]
    // 0xad3ba8: LoadField: r2 = r1->field_f
    //     0xad3ba8: ldur            w2, [x1, #0xf]
    // 0xad3bac: DecompressPointer r2
    //     0xad3bac: add             x2, x2, HEAP, lsl #32
    // 0xad3bb0: StoreField: r0->field_2b = r2
    //     0xad3bb0: stur            w2, [x0, #0x2b]
    // 0xad3bb4: SaveReg r0
    //     0xad3bb4: str             x0, [SP, #-8]!
    // 0xad3bb8: r0 = _interpolate()
    //     0xad3bb8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3bbc: add             SP, SP, #8
    // 0xad3bc0: LeaveFrame
    //     0xad3bc0: mov             SP, fp
    //     0xad3bc4: ldp             fp, lr, [SP], #0x10
    // 0xad3bc8: ret
    //     0xad3bc8: ret             
    // 0xad3bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3bcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3bd0: b               #0xad3b44
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6f5f0, size: 0x144
    // 0xc6f5f0: EnterFrame
    //     0xc6f5f0: stp             fp, lr, [SP, #-0x10]!
    //     0xc6f5f4: mov             fp, SP
    // 0xc6f5f8: CheckStackOverflow
    //     0xc6f5f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6f5fc: cmp             SP, x16
    //     0xc6f600: b.ls            #0xc6f72c
    // 0xc6f604: ldr             x1, [fp, #0x10]
    // 0xc6f608: cmp             w1, NULL
    // 0xc6f60c: b.ne            #0xc6f620
    // 0xc6f610: r0 = false
    //     0xc6f610: add             x0, NULL, #0x30  ; false
    // 0xc6f614: LeaveFrame
    //     0xc6f614: mov             SP, fp
    //     0xc6f618: ldp             fp, lr, [SP], #0x10
    // 0xc6f61c: ret
    //     0xc6f61c: ret             
    // 0xc6f620: r0 = 59
    //     0xc6f620: mov             x0, #0x3b
    // 0xc6f624: branchIfSmi(r1, 0xc6f630)
    //     0xc6f624: tbz             w1, #0, #0xc6f630
    // 0xc6f628: r0 = LoadClassIdInstr(r1)
    //     0xc6f628: ldur            x0, [x1, #-1]
    //     0xc6f62c: ubfx            x0, x0, #0xc, #0x14
    // 0xc6f630: SaveReg r1
    //     0xc6f630: str             x1, [SP, #-8]!
    // 0xc6f634: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc6f634: mov             x17, #0x57c5
    //     0xc6f638: add             lr, x0, x17
    //     0xc6f63c: ldr             lr, [x21, lr, lsl #3]
    //     0xc6f640: blr             lr
    // 0xc6f644: add             SP, SP, #8
    // 0xc6f648: r1 = LoadClassIdInstr(r0)
    //     0xc6f648: ldur            x1, [x0, #-1]
    //     0xc6f64c: ubfx            x1, x1, #0xc, #0x14
    // 0xc6f650: r16 = Boundary
    //     0xc6f650: add             x16, PP, #0x41, lsl #12  ; [pp+0x41000] Type: Boundary
    //     0xc6f654: ldr             x16, [x16]
    // 0xc6f658: stp             x16, x0, [SP, #-0x10]!
    // 0xc6f65c: mov             x0, x1
    // 0xc6f660: mov             lr, x0
    // 0xc6f664: ldr             lr, [x21, lr, lsl #3]
    // 0xc6f668: blr             lr
    // 0xc6f66c: add             SP, SP, #0x10
    // 0xc6f670: tbz             w0, #4, #0xc6f684
    // 0xc6f674: r0 = false
    //     0xc6f674: add             x0, NULL, #0x30  ; false
    // 0xc6f678: LeaveFrame
    //     0xc6f678: mov             SP, fp
    //     0xc6f67c: ldp             fp, lr, [SP], #0x10
    // 0xc6f680: ret
    //     0xc6f680: ret             
    // 0xc6f684: ldr             x1, [fp, #0x10]
    // 0xc6f688: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6f688: mov             x2, #0x76
    //     0xc6f68c: tbz             w1, #0, #0xc6f69c
    //     0xc6f690: ldur            x2, [x1, #-1]
    //     0xc6f694: ubfx            x2, x2, #0xc, #0x14
    //     0xc6f698: lsl             x2, x2, #1
    // 0xc6f69c: r17 = 8962
    //     0xc6f69c: mov             x17, #0x2302
    // 0xc6f6a0: cmp             w2, w17
    // 0xc6f6a4: b.ne            #0xc6f71c
    // 0xc6f6a8: ldr             x2, [fp, #0x18]
    // 0xc6f6ac: LoadField: r3 = r2->field_7
    //     0xc6f6ac: ldur            w3, [x2, #7]
    // 0xc6f6b0: DecompressPointer r3
    //     0xc6f6b0: add             x3, x3, HEAP, lsl #32
    // 0xc6f6b4: LoadField: r4 = r1->field_7
    //     0xc6f6b4: ldur            w4, [x1, #7]
    // 0xc6f6b8: DecompressPointer r4
    //     0xc6f6b8: add             x4, x4, HEAP, lsl #32
    // 0xc6f6bc: cmp             w3, w4
    // 0xc6f6c0: b.ne            #0xc6f71c
    // 0xc6f6c4: LoadField: r3 = r2->field_b
    //     0xc6f6c4: ldur            w3, [x2, #0xb]
    // 0xc6f6c8: DecompressPointer r3
    //     0xc6f6c8: add             x3, x3, HEAP, lsl #32
    // 0xc6f6cc: LoadField: r4 = r1->field_b
    //     0xc6f6cc: ldur            w4, [x1, #0xb]
    // 0xc6f6d0: DecompressPointer r4
    //     0xc6f6d0: add             x4, x4, HEAP, lsl #32
    // 0xc6f6d4: cmp             w3, w4
    // 0xc6f6d8: b.ne            #0xc6f71c
    // 0xc6f6dc: LoadField: r3 = r2->field_13
    //     0xc6f6dc: ldur            w3, [x2, #0x13]
    // 0xc6f6e0: DecompressPointer r3
    //     0xc6f6e0: add             x3, x3, HEAP, lsl #32
    // 0xc6f6e4: LoadField: r4 = r1->field_13
    //     0xc6f6e4: ldur            w4, [x1, #0x13]
    // 0xc6f6e8: DecompressPointer r4
    //     0xc6f6e8: add             x4, x4, HEAP, lsl #32
    // 0xc6f6ec: cmp             w3, w4
    // 0xc6f6f0: b.ne            #0xc6f71c
    // 0xc6f6f4: LoadField: r3 = r2->field_f
    //     0xc6f6f4: ldur            w3, [x2, #0xf]
    // 0xc6f6f8: DecompressPointer r3
    //     0xc6f6f8: add             x3, x3, HEAP, lsl #32
    // 0xc6f6fc: LoadField: r2 = r1->field_f
    //     0xc6f6fc: ldur            w2, [x1, #0xf]
    // 0xc6f700: DecompressPointer r2
    //     0xc6f700: add             x2, x2, HEAP, lsl #32
    // 0xc6f704: cmp             w3, w2
    // 0xc6f708: r16 = true
    //     0xc6f708: add             x16, NULL, #0x20  ; true
    // 0xc6f70c: r17 = false
    //     0xc6f70c: add             x17, NULL, #0x30  ; false
    // 0xc6f710: csel            x1, x16, x17, eq
    // 0xc6f714: mov             x0, x1
    // 0xc6f718: b               #0xc6f720
    // 0xc6f71c: r0 = false
    //     0xc6f71c: add             x0, NULL, #0x30  ; false
    // 0xc6f720: LeaveFrame
    //     0xc6f720: mov             SP, fp
    //     0xc6f724: ldp             fp, lr, [SP], #0x10
    // 0xc6f728: ret
    //     0xc6f728: ret             
    // 0xc6f72c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6f72c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6f730: b               #0xc6f604
  }
}

// class id: 5997, size: 0x14, field offset: 0x14
enum ActionType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15898, size: 0x5c
    // 0xb15898: EnterFrame
    //     0xb15898: stp             fp, lr, [SP, #-0x10]!
    //     0xb1589c: mov             fp, SP
    // 0xb158a0: CheckStackOverflow
    //     0xb158a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb158a4: cmp             SP, x16
    //     0xb158a8: b.ls            #0xb158ec
    // 0xb158ac: r1 = Null
    //     0xb158ac: mov             x1, NULL
    // 0xb158b0: r2 = 4
    //     0xb158b0: mov             x2, #4
    // 0xb158b4: r0 = AllocateArray()
    //     0xb158b4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb158b8: r17 = "ActionType."
    //     0xb158b8: add             x17, PP, #0x51, lsl #12  ; [pp+0x513b0] "ActionType."
    //     0xb158bc: ldr             x17, [x17, #0x3b0]
    // 0xb158c0: StoreField: r0->field_f = r17
    //     0xb158c0: stur            w17, [x0, #0xf]
    // 0xb158c4: ldr             x1, [fp, #0x10]
    // 0xb158c8: LoadField: r2 = r1->field_f
    //     0xb158c8: ldur            w2, [x1, #0xf]
    // 0xb158cc: DecompressPointer r2
    //     0xb158cc: add             x2, x2, HEAP, lsl #32
    // 0xb158d0: StoreField: r0->field_13 = r2
    //     0xb158d0: stur            w2, [x0, #0x13]
    // 0xb158d4: SaveReg r0
    //     0xb158d4: str             x0, [SP, #-8]!
    // 0xb158d8: r0 = _interpolate()
    //     0xb158d8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb158dc: add             SP, SP, #8
    // 0xb158e0: LeaveFrame
    //     0xb158e0: mov             SP, fp
    //     0xb158e4: ldp             fp, lr, [SP], #0x10
    // 0xb158e8: ret
    //     0xb158e8: ret             
    // 0xb158ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb158ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb158f0: b               #0xb158ac
  }
}

// class id: 5998, size: 0x14, field offset: 0x14
enum InitialAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb1583c, size: 0x5c
    // 0xb1583c: EnterFrame
    //     0xb1583c: stp             fp, lr, [SP, #-0x10]!
    //     0xb15840: mov             fp, SP
    // 0xb15844: CheckStackOverflow
    //     0xb15844: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15848: cmp             SP, x16
    //     0xb1584c: b.ls            #0xb15890
    // 0xb15850: r1 = Null
    //     0xb15850: mov             x1, NULL
    // 0xb15854: r2 = 4
    //     0xb15854: mov             x2, #4
    // 0xb15858: r0 = AllocateArray()
    //     0xb15858: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1585c: r17 = "InitialAlignment."
    //     0xb1585c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c560] "InitialAlignment."
    //     0xb15860: ldr             x17, [x17, #0x560]
    // 0xb15864: StoreField: r0->field_f = r17
    //     0xb15864: stur            w17, [x0, #0xf]
    // 0xb15868: ldr             x1, [fp, #0x10]
    // 0xb1586c: LoadField: r2 = r1->field_f
    //     0xb1586c: ldur            w2, [x1, #0xf]
    // 0xb15870: DecompressPointer r2
    //     0xb15870: add             x2, x2, HEAP, lsl #32
    // 0xb15874: StoreField: r0->field_13 = r2
    //     0xb15874: stur            w2, [x0, #0x13]
    // 0xb15878: SaveReg r0
    //     0xb15878: str             x0, [SP, #-8]!
    // 0xb1587c: r0 = _interpolate()
    //     0xb1587c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15880: add             SP, SP, #8
    // 0xb15884: LeaveFrame
    //     0xb15884: mov             SP, fp
    //     0xb15888: ldp             fp, lr, [SP], #0x10
    // 0xb1588c: ret
    //     0xb1588c: ret             
    // 0xb15890: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15890: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15894: b               #0xb15850
  }
}

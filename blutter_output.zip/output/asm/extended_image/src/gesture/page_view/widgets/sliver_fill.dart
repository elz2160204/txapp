// lib: , url: package:extended_image/src/gesture/page_view/widgets/sliver_fill.dart

// class id: 1048936, size: 0x8
class :: {
}

// class id: 2579, size: 0x68, field offset: 0x58
class _RenderSliverFractionalPadding extends RenderSliverEdgeInsetsPadding {

  _ performLayout(/* No info */) {
    // ** addr: 0x682c28, size: 0x4c
    // 0x682c28: EnterFrame
    //     0x682c28: stp             fp, lr, [SP, #-0x10]!
    //     0x682c2c: mov             fp, SP
    // 0x682c30: CheckStackOverflow
    //     0x682c30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x682c34: cmp             SP, x16
    //     0x682c38: b.ls            #0x682c6c
    // 0x682c3c: ldr             x16, [fp, #0x10]
    // 0x682c40: SaveReg r16
    //     0x682c40: str             x16, [SP, #-8]!
    // 0x682c44: r0 = _resolve()
    //     0x682c44: bl              #0x685110  ; [package:extended_image/src/gesture/page_view/widgets/sliver_fill.dart] _RenderSliverFractionalPadding::_resolve
    // 0x682c48: add             SP, SP, #8
    // 0x682c4c: ldr             x16, [fp, #0x10]
    // 0x682c50: SaveReg r16
    //     0x682c50: str             x16, [SP, #-8]!
    // 0x682c54: r0 = performLayout()
    //     0x682c54: bl              #0x682c74  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::performLayout
    // 0x682c58: add             SP, SP, #8
    // 0x682c5c: r0 = Null
    //     0x682c5c: mov             x0, NULL
    // 0x682c60: LeaveFrame
    //     0x682c60: mov             SP, fp
    //     0x682c64: ldp             fp, lr, [SP], #0x10
    // 0x682c68: ret
    //     0x682c68: ret             
    // 0x682c6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x682c6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x682c70: b               #0x682c3c
  }
  _ _resolve(/* No info */) {
    // ** addr: 0x685110, size: 0x238
    // 0x685110: EnterFrame
    //     0x685110: stp             fp, lr, [SP, #-0x10]!
    //     0x685114: mov             fp, SP
    // 0x685118: AllocStack(0x18)
    //     0x685118: sub             SP, SP, #0x18
    // 0x68511c: CheckStackOverflow
    //     0x68511c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x685120: cmp             SP, x16
    //     0x685124: b.ls            #0x685340
    // 0x685128: ldr             x3, [fp, #0x10]
    // 0x68512c: LoadField: r0 = r3->field_63
    //     0x68512c: ldur            w0, [x3, #0x63]
    // 0x685130: DecompressPointer r0
    //     0x685130: add             x0, x0, HEAP, lsl #32
    // 0x685134: cmp             w0, NULL
    // 0x685138: b.eq            #0x6851d0
    // 0x68513c: LoadField: r4 = r3->field_57
    //     0x68513c: ldur            w4, [x3, #0x57]
    // 0x685140: DecompressPointer r4
    //     0x685140: add             x4, x4, HEAP, lsl #32
    // 0x685144: stur            x4, [fp, #-0x10]
    // 0x685148: LoadField: r5 = r3->field_27
    //     0x685148: ldur            w5, [x3, #0x27]
    // 0x68514c: DecompressPointer r5
    //     0x68514c: add             x5, x5, HEAP, lsl #32
    // 0x685150: stur            x5, [fp, #-8]
    // 0x685154: cmp             w5, NULL
    // 0x685158: b.eq            #0x685308
    // 0x68515c: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68515c: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x685160: ldr             x6, [x6, #0x1e8]
    // 0x685164: mov             x0, x5
    // 0x685168: r2 = Null
    //     0x685168: mov             x2, NULL
    // 0x68516c: r1 = Null
    //     0x68516c: mov             x1, NULL
    // 0x685170: r4 = LoadClassIdInstr(r0)
    //     0x685170: ldur            x4, [x0, #-1]
    //     0x685174: ubfx            x4, x4, #0xc, #0x14
    // 0x685178: cmp             x4, #0x80c
    // 0x68517c: b.eq            #0x685194
    // 0x685180: r8 = SliverConstraints
    //     0x685180: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x685184: ldr             x8, [x8, #0x5a8]
    // 0x685188: r3 = Null
    //     0x685188: add             x3, PP, #0x57, lsl #12  ; [pp+0x57390] Null
    //     0x68518c: ldr             x3, [x3, #0x390]
    // 0x685190: r0 = DefaultTypeTest()
    //     0x685190: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x685194: ldur            x0, [fp, #-0x10]
    // 0x685198: r1 = LoadClassIdInstr(r0)
    //     0x685198: ldur            x1, [x0, #-1]
    //     0x68519c: ubfx            x1, x1, #0xc, #0x14
    // 0x6851a0: ldur            x16, [fp, #-8]
    // 0x6851a4: stp             x16, x0, [SP, #-0x10]!
    // 0x6851a8: mov             x0, x1
    // 0x6851ac: mov             lr, x0
    // 0x6851b0: ldr             lr, [x21, lr, lsl #3]
    // 0x6851b4: blr             lr
    // 0x6851b8: add             SP, SP, #0x10
    // 0x6851bc: tbnz            w0, #4, #0x6851d0
    // 0x6851c0: r0 = Null
    //     0x6851c0: mov             x0, NULL
    // 0x6851c4: LeaveFrame
    //     0x6851c4: mov             SP, fp
    //     0x6851c8: ldp             fp, lr, [SP], #0x10
    // 0x6851cc: ret
    //     0x6851cc: ret             
    // 0x6851d0: ldr             x3, [fp, #0x10]
    // 0x6851d4: LoadField: r4 = r3->field_27
    //     0x6851d4: ldur            w4, [x3, #0x27]
    // 0x6851d8: DecompressPointer r4
    //     0x6851d8: add             x4, x4, HEAP, lsl #32
    // 0x6851dc: stur            x4, [fp, #-8]
    // 0x6851e0: cmp             w4, NULL
    // 0x6851e4: b.eq            #0x685320
    // 0x6851e8: mov             x0, x4
    // 0x6851ec: r2 = Null
    //     0x6851ec: mov             x2, NULL
    // 0x6851f0: r1 = Null
    //     0x6851f0: mov             x1, NULL
    // 0x6851f4: r4 = LoadClassIdInstr(r0)
    //     0x6851f4: ldur            x4, [x0, #-1]
    //     0x6851f8: ubfx            x4, x4, #0xc, #0x14
    // 0x6851fc: cmp             x4, #0x80c
    // 0x685200: b.eq            #0x685218
    // 0x685204: r8 = SliverConstraints
    //     0x685204: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x685208: ldr             x8, [x8, #0x5a8]
    // 0x68520c: r3 = Null
    //     0x68520c: add             x3, PP, #0x57, lsl #12  ; [pp+0x573a0] Null
    //     0x685210: ldr             x3, [x3, #0x3a0]
    // 0x685214: r0 = DefaultTypeTest()
    //     0x685214: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x685218: ldur            x1, [fp, #-8]
    // 0x68521c: LoadField: d0 = r1->field_3f
    //     0x68521c: ldur            d0, [x1, #0x3f]
    // 0x685220: ldr             x2, [fp, #0x10]
    // 0x685224: LoadField: d1 = r2->field_5b
    //     0x685224: ldur            d1, [x2, #0x5b]
    // 0x685228: fmul            d2, d0, d1
    // 0x68522c: mov             x0, x1
    // 0x685230: stur            d2, [fp, #-0x18]
    // 0x685234: StoreField: r2->field_57 = r0
    //     0x685234: stur            w0, [x2, #0x57]
    //     0x685238: ldurb           w16, [x2, #-1]
    //     0x68523c: ldurb           w17, [x0, #-1]
    //     0x685240: and             x16, x17, x16, lsr #2
    //     0x685244: tst             x16, HEAP, lsr #32
    //     0x685248: b.eq            #0x685250
    //     0x68524c: bl              #0xd6828c
    // 0x685250: SaveReg r1
    //     0x685250: str             x1, [SP, #-8]!
    // 0x685254: r0 = axis()
    //     0x685254: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x685258: add             SP, SP, #8
    // 0x68525c: LoadField: r1 = r0->field_7
    //     0x68525c: ldur            x1, [x0, #7]
    // 0x685260: cmp             x1, #0
    // 0x685264: b.gt            #0x6852b0
    // 0x685268: ldr             x0, [fp, #0x10]
    // 0x68526c: ldur            d0, [fp, #-0x18]
    // 0x685270: r0 = EdgeInsets()
    //     0x685270: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x685274: ldur            d0, [fp, #-0x18]
    // 0x685278: StoreField: r0->field_7 = d0
    //     0x685278: stur            d0, [x0, #7]
    // 0x68527c: d1 = 0.000000
    //     0x68527c: eor             v1.16b, v1.16b, v1.16b
    // 0x685280: StoreField: r0->field_f = d1
    //     0x685280: stur            d1, [x0, #0xf]
    // 0x685284: StoreField: r0->field_17 = d0
    //     0x685284: stur            d0, [x0, #0x17]
    // 0x685288: StoreField: r0->field_1f = d1
    //     0x685288: stur            d1, [x0, #0x1f]
    // 0x68528c: ldr             x1, [fp, #0x10]
    // 0x685290: StoreField: r1->field_63 = r0
    //     0x685290: stur            w0, [x1, #0x63]
    //     0x685294: ldurb           w16, [x1, #-1]
    //     0x685298: ldurb           w17, [x0, #-1]
    //     0x68529c: and             x16, x17, x16, lsr #2
    //     0x6852a0: tst             x16, HEAP, lsr #32
    //     0x6852a4: b.eq            #0x6852ac
    //     0x6852a8: bl              #0xd6826c
    // 0x6852ac: b               #0x6852f8
    // 0x6852b0: ldr             x1, [fp, #0x10]
    // 0x6852b4: ldur            d0, [fp, #-0x18]
    // 0x6852b8: d1 = 0.000000
    //     0x6852b8: eor             v1.16b, v1.16b, v1.16b
    // 0x6852bc: r0 = EdgeInsets()
    //     0x6852bc: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x6852c0: d0 = 0.000000
    //     0x6852c0: eor             v0.16b, v0.16b, v0.16b
    // 0x6852c4: StoreField: r0->field_7 = d0
    //     0x6852c4: stur            d0, [x0, #7]
    // 0x6852c8: ldur            d1, [fp, #-0x18]
    // 0x6852cc: StoreField: r0->field_f = d1
    //     0x6852cc: stur            d1, [x0, #0xf]
    // 0x6852d0: StoreField: r0->field_17 = d0
    //     0x6852d0: stur            d0, [x0, #0x17]
    // 0x6852d4: StoreField: r0->field_1f = d1
    //     0x6852d4: stur            d1, [x0, #0x1f]
    // 0x6852d8: ldr             x1, [fp, #0x10]
    // 0x6852dc: StoreField: r1->field_63 = r0
    //     0x6852dc: stur            w0, [x1, #0x63]
    //     0x6852e0: ldurb           w16, [x1, #-1]
    //     0x6852e4: ldurb           w17, [x0, #-1]
    //     0x6852e8: and             x16, x17, x16, lsr #2
    //     0x6852ec: tst             x16, HEAP, lsr #32
    //     0x6852f0: b.eq            #0x6852f8
    //     0x6852f4: bl              #0xd6826c
    // 0x6852f8: r0 = Null
    //     0x6852f8: mov             x0, NULL
    // 0x6852fc: LeaveFrame
    //     0x6852fc: mov             SP, fp
    //     0x685300: ldp             fp, lr, [SP], #0x10
    // 0x685304: ret
    //     0x685304: ret             
    // 0x685308: r0 = StateError()
    //     0x685308: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68530c: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68530c: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x685310: ldr             x6, [x6, #0x1e8]
    // 0x685314: StoreField: r0->field_b = r6
    //     0x685314: stur            w6, [x0, #0xb]
    // 0x685318: r0 = Throw()
    //     0x685318: bl              #0xd67e38  ; ThrowStub
    // 0x68531c: brk             #0
    // 0x685320: r0 = StateError()
    //     0x685320: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x685324: mov             x1, x0
    // 0x685328: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x685328: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68532c: ldr             x0, [x0, #0x1e8]
    // 0x685330: StoreField: r1->field_b = r0
    //     0x685330: stur            w0, [x1, #0xb]
    // 0x685334: mov             x0, x1
    // 0x685338: r0 = Throw()
    //     0x685338: bl              #0xd67e38  ; ThrowStub
    // 0x68533c: brk             #0
    // 0x685340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x685340: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x685344: b               #0x685128
  }
  set _ viewportFraction=(/* No info */) {
    // ** addr: 0x6c229c, size: 0x64
    // 0x6c229c: EnterFrame
    //     0x6c229c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c22a0: mov             fp, SP
    // 0x6c22a4: CheckStackOverflow
    //     0x6c22a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c22a8: cmp             SP, x16
    //     0x6c22ac: b.ls            #0x6c22f8
    // 0x6c22b0: ldr             x0, [fp, #0x18]
    // 0x6c22b4: LoadField: d0 = r0->field_5b
    //     0x6c22b4: ldur            d0, [x0, #0x5b]
    // 0x6c22b8: ldr             d1, [fp, #0x10]
    // 0x6c22bc: fcmp            d0, d1
    // 0x6c22c0: b.vs            #0x6c22d8
    // 0x6c22c4: b.ne            #0x6c22d8
    // 0x6c22c8: r0 = Null
    //     0x6c22c8: mov             x0, NULL
    // 0x6c22cc: LeaveFrame
    //     0x6c22cc: mov             SP, fp
    //     0x6c22d0: ldp             fp, lr, [SP], #0x10
    // 0x6c22d4: ret
    //     0x6c22d4: ret             
    // 0x6c22d8: StoreField: r0->field_5b = d1
    //     0x6c22d8: stur            d1, [x0, #0x5b]
    // 0x6c22dc: SaveReg r0
    //     0x6c22dc: str             x0, [SP, #-8]!
    // 0x6c22e0: r0 = _markNeedsResolution()
    //     0x6c22e0: bl              #0x6c2300  ; [package:extended_image/src/gesture/page_view/widgets/sliver_fill.dart] _RenderSliverFractionalPadding::_markNeedsResolution
    // 0x6c22e4: add             SP, SP, #8
    // 0x6c22e8: r0 = Null
    //     0x6c22e8: mov             x0, NULL
    // 0x6c22ec: LeaveFrame
    //     0x6c22ec: mov             SP, fp
    //     0x6c22f0: ldp             fp, lr, [SP], #0x10
    // 0x6c22f4: ret
    //     0x6c22f4: ret             
    // 0x6c22f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c22f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c22fc: b               #0x6c22b0
  }
  _ _markNeedsResolution(/* No info */) {
    // ** addr: 0x6c2300, size: 0x40
    // 0x6c2300: EnterFrame
    //     0x6c2300: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2304: mov             fp, SP
    // 0x6c2308: CheckStackOverflow
    //     0x6c2308: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c230c: cmp             SP, x16
    //     0x6c2310: b.ls            #0x6c2338
    // 0x6c2314: ldr             x0, [fp, #0x10]
    // 0x6c2318: StoreField: r0->field_63 = rNULL
    //     0x6c2318: stur            NULL, [x0, #0x63]
    // 0x6c231c: SaveReg r0
    //     0x6c231c: str             x0, [SP, #-8]!
    // 0x6c2320: r0 = markNeedsLayout()
    //     0x6c2320: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x6c2324: add             SP, SP, #8
    // 0x6c2328: r0 = Null
    //     0x6c2328: mov             x0, NULL
    // 0x6c232c: LeaveFrame
    //     0x6c232c: mov             SP, fp
    //     0x6c2330: ldp             fp, lr, [SP], #0x10
    // 0x6c2334: ret
    //     0x6c2334: ret             
    // 0x6c2338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2338: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c233c: b               #0x6c2314
  }
}

// class id: 3679, size: 0x18, field offset: 0x10
//   const constructor, 
class _SliverFractionalPadding extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6c221c, size: 0x80
    // 0x6c221c: EnterFrame
    //     0x6c221c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2220: mov             fp, SP
    // 0x6c2224: CheckStackOverflow
    //     0x6c2224: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2228: cmp             SP, x16
    //     0x6c222c: b.ls            #0x6c2294
    // 0x6c2230: ldr             x0, [fp, #0x10]
    // 0x6c2234: r2 = Null
    //     0x6c2234: mov             x2, NULL
    // 0x6c2238: r1 = Null
    //     0x6c2238: mov             x1, NULL
    // 0x6c223c: r4 = 59
    //     0x6c223c: mov             x4, #0x3b
    // 0x6c2240: branchIfSmi(r0, 0x6c224c)
    //     0x6c2240: tbz             w0, #0, #0x6c224c
    // 0x6c2244: r4 = LoadClassIdInstr(r0)
    //     0x6c2244: ldur            x4, [x0, #-1]
    //     0x6c2248: ubfx            x4, x4, #0xc, #0x14
    // 0x6c224c: cmp             x4, #0xa13
    // 0x6c2250: b.eq            #0x6c2268
    // 0x6c2254: r8 = _RenderSliverFractionalPadding
    //     0x6c2254: add             x8, PP, #0x56, lsl #12  ; [pp+0x56f30] Type: _RenderSliverFractionalPadding
    //     0x6c2258: ldr             x8, [x8, #0xf30]
    // 0x6c225c: r3 = Null
    //     0x6c225c: add             x3, PP, #0x56, lsl #12  ; [pp+0x56f38] Null
    //     0x6c2260: ldr             x3, [x3, #0xf38]
    // 0x6c2264: r0 = DefaultTypeTest()
    //     0x6c2264: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c2268: ldr             x0, [fp, #0x20]
    // 0x6c226c: LoadField: d0 = r0->field_f
    //     0x6c226c: ldur            d0, [x0, #0xf]
    // 0x6c2270: ldr             x16, [fp, #0x10]
    // 0x6c2274: SaveReg r16
    //     0x6c2274: str             x16, [SP, #-8]!
    // 0x6c2278: SaveReg d0
    //     0x6c2278: str             d0, [SP, #-8]!
    // 0x6c227c: r0 = viewportFraction=()
    //     0x6c227c: bl              #0x6c229c  ; [package:extended_image/src/gesture/page_view/widgets/sliver_fill.dart] _RenderSliverFractionalPadding::viewportFraction=
    // 0x6c2280: add             SP, SP, #0x10
    // 0x6c2284: r0 = Null
    //     0x6c2284: mov             x0, NULL
    // 0x6c2288: LeaveFrame
    //     0x6c2288: mov             SP, fp
    //     0x6c228c: ldp             fp, lr, [SP], #0x10
    // 0x6c2290: ret
    //     0x6c2290: ret             
    // 0x6c2294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2294: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2298: b               #0x6c2230
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6e9efc, size: 0x58
    // 0x6e9efc: EnterFrame
    //     0x6e9efc: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9f00: mov             fp, SP
    // 0x6e9f04: AllocStack(0x10)
    //     0x6e9f04: sub             SP, SP, #0x10
    // 0x6e9f08: CheckStackOverflow
    //     0x6e9f08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9f0c: cmp             SP, x16
    //     0x6e9f10: b.ls            #0x6e9f4c
    // 0x6e9f14: ldr             x0, [fp, #0x18]
    // 0x6e9f18: LoadField: d0 = r0->field_f
    //     0x6e9f18: ldur            d0, [x0, #0xf]
    // 0x6e9f1c: stur            d0, [fp, #-0x10]
    // 0x6e9f20: r0 = _RenderSliverFractionalPadding()
    //     0x6e9f20: bl              #0x6e9f54  ; Allocate_RenderSliverFractionalPaddingStub -> _RenderSliverFractionalPadding (size=0x68)
    // 0x6e9f24: ldur            d0, [fp, #-0x10]
    // 0x6e9f28: stur            x0, [fp, #-8]
    // 0x6e9f2c: StoreField: r0->field_5b = d0
    //     0x6e9f2c: stur            d0, [x0, #0x5b]
    // 0x6e9f30: SaveReg r0
    //     0x6e9f30: str             x0, [SP, #-8]!
    // 0x6e9f34: r0 = RenderObject()
    //     0x6e9f34: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6e9f38: add             SP, SP, #8
    // 0x6e9f3c: ldur            x0, [fp, #-8]
    // 0x6e9f40: LeaveFrame
    //     0x6e9f40: mov             SP, fp
    //     0x6e9f44: ldp             fp, lr, [SP], #0x10
    // 0x6e9f48: ret
    //     0x6e9f48: ret             
    // 0x6e9f4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9f4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9f50: b               #0x6e9f14
  }
}

// class id: 3688, size: 0x20, field offset: 0x10
//   const constructor, 
class _SliverFillViewportRenderObjectWidget extends SliverMultiBoxAdaptorWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6c1c3c, size: 0x8c
    // 0x6c1c3c: EnterFrame
    //     0x6c1c3c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c1c40: mov             fp, SP
    // 0x6c1c44: CheckStackOverflow
    //     0x6c1c44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c1c48: cmp             SP, x16
    //     0x6c1c4c: b.ls            #0x6c1cc0
    // 0x6c1c50: ldr             x0, [fp, #0x10]
    // 0x6c1c54: r2 = Null
    //     0x6c1c54: mov             x2, NULL
    // 0x6c1c58: r1 = Null
    //     0x6c1c58: mov             x1, NULL
    // 0x6c1c5c: r4 = 59
    //     0x6c1c5c: mov             x4, #0x3b
    // 0x6c1c60: branchIfSmi(r0, 0x6c1c6c)
    //     0x6c1c60: tbz             w0, #0, #0x6c1c6c
    // 0x6c1c64: r4 = LoadClassIdInstr(r0)
    //     0x6c1c64: ldur            x4, [x0, #-1]
    //     0x6c1c68: ubfx            x4, x4, #0xc, #0x14
    // 0x6c1c6c: cmp             x4, #0xa1f
    // 0x6c1c70: b.eq            #0x6c1c88
    // 0x6c1c74: r8 = ExtendedRenderSliverFillViewport
    //     0x6c1c74: add             x8, PP, #0x56, lsl #12  ; [pp+0x56f48] Type: ExtendedRenderSliverFillViewport
    //     0x6c1c78: ldr             x8, [x8, #0xf48]
    // 0x6c1c7c: r3 = Null
    //     0x6c1c7c: add             x3, PP, #0x56, lsl #12  ; [pp+0x56f50] Null
    //     0x6c1c80: ldr             x3, [x3, #0xf50]
    // 0x6c1c84: r0 = DefaultTypeTest()
    //     0x6c1c84: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c1c88: ldr             x16, [fp, #0x10]
    // 0x6c1c8c: SaveReg r16
    //     0x6c1c8c: str             x16, [SP, #-8]!
    // 0x6c1c90: d0 = 1.000000
    //     0x6c1c90: fmov            d0, #1.00000000
    // 0x6c1c94: SaveReg d0
    //     0x6c1c94: str             d0, [SP, #-8]!
    // 0x6c1c98: r0 = viewportFraction=()
    //     0x6c1c98: bl              #0x6c1d28  ; [package:extended_image/src/gesture/page_view/rendering/sliver_fill.dart] ExtendedRenderSliverFillViewport::viewportFraction=
    // 0x6c1c9c: add             SP, SP, #0x10
    // 0x6c1ca0: ldr             x16, [fp, #0x10]
    // 0x6c1ca4: stp             xzr, x16, [SP, #-0x10]!
    // 0x6c1ca8: r0 = pageSpacing=()
    //     0x6c1ca8: bl              #0x6c1cc8  ; [package:extended_image/src/gesture/page_view/rendering/sliver_fill.dart] ExtendedRenderSliverFillViewport::pageSpacing=
    // 0x6c1cac: add             SP, SP, #0x10
    // 0x6c1cb0: r0 = Null
    //     0x6c1cb0: mov             x0, NULL
    // 0x6c1cb4: LeaveFrame
    //     0x6c1cb4: mov             SP, fp
    //     0x6c1cb8: ldp             fp, lr, [SP], #0x10
    // 0x6c1cbc: ret
    //     0x6c1cbc: ret             
    // 0x6c1cc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c1cc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c1cc4: b               #0x6c1c50
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6e990c, size: 0x8c
    // 0x6e990c: EnterFrame
    //     0x6e990c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9910: mov             fp, SP
    // 0x6e9914: AllocStack(0x8)
    //     0x6e9914: sub             SP, SP, #8
    // 0x6e9918: CheckStackOverflow
    //     0x6e9918: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e991c: cmp             SP, x16
    //     0x6e9920: b.ls            #0x6e9990
    // 0x6e9924: ldr             x0, [fp, #0x10]
    // 0x6e9928: r2 = Null
    //     0x6e9928: mov             x2, NULL
    // 0x6e992c: r1 = Null
    //     0x6e992c: mov             x1, NULL
    // 0x6e9930: r4 = LoadClassIdInstr(r0)
    //     0x6e9930: ldur            x4, [x0, #-1]
    //     0x6e9934: ubfx            x4, x4, #0xc, #0x14
    // 0x6e9938: sub             x4, x4, #0xd7e
    // 0x6e993c: cmp             x4, #1
    // 0x6e9940: b.ls            #0x6e9958
    // 0x6e9944: r8 = SliverMultiBoxAdaptorElement
    //     0x6e9944: add             x8, PP, #0x3b, lsl #12  ; [pp+0x3bc98] Type: SliverMultiBoxAdaptorElement
    //     0x6e9948: ldr             x8, [x8, #0xc98]
    // 0x6e994c: r3 = Null
    //     0x6e994c: add             x3, PP, #0x56, lsl #12  ; [pp+0x56f60] Null
    //     0x6e9950: ldr             x3, [x3, #0xf60]
    // 0x6e9954: r0 = DefaultTypeTest()
    //     0x6e9954: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6e9958: r0 = ExtendedRenderSliverFillViewport()
    //     0x6e9958: bl              #0x6e9a34  ; AllocateExtendedRenderSliverFillViewportStub -> ExtendedRenderSliverFillViewport (size=0x7c)
    // 0x6e995c: d0 = 1.000000
    //     0x6e995c: fmov            d0, #1.00000000
    // 0x6e9960: stur            x0, [fp, #-8]
    // 0x6e9964: StoreField: r0->field_6b = d0
    //     0x6e9964: stur            d0, [x0, #0x6b]
    // 0x6e9968: d0 = 0.000000
    //     0x6e9968: eor             v0.16b, v0.16b, v0.16b
    // 0x6e996c: StoreField: r0->field_73 = d0
    //     0x6e996c: stur            d0, [x0, #0x73]
    // 0x6e9970: ldr             x16, [fp, #0x10]
    // 0x6e9974: stp             x16, x0, [SP, #-0x10]!
    // 0x6e9978: r0 = RenderSliverMultiBoxAdaptor()
    //     0x6e9978: bl              #0x6e9998  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::RenderSliverMultiBoxAdaptor
    // 0x6e997c: add             SP, SP, #0x10
    // 0x6e9980: ldur            x0, [fp, #-8]
    // 0x6e9984: LeaveFrame
    //     0x6e9984: mov             SP, fp
    //     0x6e9988: ldp             fp, lr, [SP], #0x10
    // 0x6e998c: ret
    //     0x6e998c: ret             
    // 0x6e9990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9990: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9994: b               #0x6e9924
  }
}

// class id: 3882, size: 0x24, field offset: 0xc
//   const constructor, 
class ExtendedSliverFillViewport extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1c518, size: 0xc8
    // 0xb1c518: EnterFrame
    //     0xb1c518: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c51c: mov             fp, SP
    // 0xb1c520: AllocStack(0x20)
    //     0xb1c520: sub             SP, SP, #0x20
    // 0xb1c524: CheckStackOverflow
    //     0xb1c524: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1c528: cmp             SP, x16
    //     0xb1c52c: b.ls            #0xb1c5d8
    // 0xb1c530: r16 = 0.000000
    //     0xb1c530: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xb1c534: stp             xzr, x16, [SP, #-0x10]!
    // 0xb1c538: r16 = 2
    //     0xb1c538: mov             x16, #2
    // 0xb1c53c: SaveReg r16
    //     0xb1c53c: str             x16, [SP, #-8]!
    // 0xb1c540: r0 = clamp()
    //     0xb1c540: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0xb1c544: add             SP, SP, #0x18
    // 0xb1c548: r1 = 59
    //     0xb1c548: mov             x1, #0x3b
    // 0xb1c54c: branchIfSmi(r0, 0xb1c558)
    //     0xb1c54c: tbz             w0, #0, #0xb1c558
    // 0xb1c550: r1 = LoadClassIdInstr(r0)
    //     0xb1c550: ldur            x1, [x0, #-1]
    //     0xb1c554: ubfx            x1, x1, #0xc, #0x14
    // 0xb1c558: r16 = 4
    //     0xb1c558: mov             x16, #4
    // 0xb1c55c: stp             x16, x0, [SP, #-0x10]!
    // 0xb1c560: mov             x0, x1
    // 0xb1c564: r0 = GDT[cid_x0 + -0xfe7]()
    //     0xb1c564: sub             lr, x0, #0xfe7
    //     0xb1c568: ldr             lr, [x21, lr, lsl #3]
    //     0xb1c56c: blr             lr
    // 0xb1c570: add             SP, SP, #0x10
    // 0xb1c574: mov             x1, x0
    // 0xb1c578: ldr             x0, [fp, #0x18]
    // 0xb1c57c: stur            x1, [fp, #-0x10]
    // 0xb1c580: LoadField: r2 = r0->field_17
    //     0xb1c580: ldur            w2, [x0, #0x17]
    // 0xb1c584: DecompressPointer r2
    //     0xb1c584: add             x2, x2, HEAP, lsl #32
    // 0xb1c588: stur            x2, [fp, #-8]
    // 0xb1c58c: r0 = _SliverFillViewportRenderObjectWidget()
    //     0xb1c58c: bl              #0xb1c5ec  ; Allocate_SliverFillViewportRenderObjectWidgetStub -> _SliverFillViewportRenderObjectWidget (size=0x20)
    // 0xb1c590: d0 = 1.000000
    //     0xb1c590: fmov            d0, #1.00000000
    // 0xb1c594: stur            x0, [fp, #-0x18]
    // 0xb1c598: StoreField: r0->field_f = d0
    //     0xb1c598: stur            d0, [x0, #0xf]
    // 0xb1c59c: d0 = 0.000000
    //     0xb1c59c: eor             v0.16b, v0.16b, v0.16b
    // 0xb1c5a0: StoreField: r0->field_17 = d0
    //     0xb1c5a0: stur            d0, [x0, #0x17]
    // 0xb1c5a4: ldur            x1, [fp, #-8]
    // 0xb1c5a8: StoreField: r0->field_b = r1
    //     0xb1c5a8: stur            w1, [x0, #0xb]
    // 0xb1c5ac: ldur            x1, [fp, #-0x10]
    // 0xb1c5b0: LoadField: d0 = r1->field_7
    //     0xb1c5b0: ldur            d0, [x1, #7]
    // 0xb1c5b4: stur            d0, [fp, #-0x20]
    // 0xb1c5b8: r0 = _SliverFractionalPadding()
    //     0xb1c5b8: bl              #0xb1c5e0  ; Allocate_SliverFractionalPaddingStub -> _SliverFractionalPadding (size=0x18)
    // 0xb1c5bc: ldur            d0, [fp, #-0x20]
    // 0xb1c5c0: StoreField: r0->field_f = d0
    //     0xb1c5c0: stur            d0, [x0, #0xf]
    // 0xb1c5c4: ldur            x1, [fp, #-0x18]
    // 0xb1c5c8: StoreField: r0->field_b = r1
    //     0xb1c5c8: stur            w1, [x0, #0xb]
    // 0xb1c5cc: LeaveFrame
    //     0xb1c5cc: mov             SP, fp
    //     0xb1c5d0: ldp             fp, lr, [SP], #0x10
    // 0xb1c5d4: ret
    //     0xb1c5d4: ret             
    // 0xb1c5d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c5d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c5dc: b               #0xb1c530
  }
}

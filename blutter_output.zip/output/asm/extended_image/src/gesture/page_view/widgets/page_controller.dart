// lib: , url: package:extended_image/src/gesture/page_view/widgets/page_controller.dart

// class id: 1048935, size: 0x8
class :: {
}

// class id: 4850, size: 0x9c, field offset: 0x80
class ExtendedPagePosition extends ScrollPositionWithSingleContext
    implements PageMetrics {

  _ ExtendedPagePosition(/* No info */) {
    // ** addr: 0xbebc08, size: 0x94
    // 0xbebc08: EnterFrame
    //     0xbebc08: stp             fp, lr, [SP, #-0x10]!
    //     0xbebc0c: mov             fp, SP
    // 0xbebc10: d1 = 1.000000
    //     0xbebc10: fmov            d1, #1.00000000
    // 0xbebc14: d0 = 0.000000
    //     0xbebc14: eor             v0.16b, v0.16b, v0.16b
    // 0xbebc18: CheckStackOverflow
    //     0xbebc18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbebc1c: cmp             SP, x16
    //     0xbebc20: b.ls            #0xbebc94
    // 0xbebc24: ldr             x2, [fp, #0x30]
    // 0xbebc28: StoreField: r2->field_8b = d1
    //     0xbebc28: stur            d1, [x2, #0x8b]
    // 0xbebc2c: StoreField: r2->field_93 = d0
    //     0xbebc2c: stur            d0, [x2, #0x93]
    // 0xbebc30: ldr             x3, [fp, #0x20]
    // 0xbebc34: r0 = BoxInt64Instr(r3)
    //     0xbebc34: sbfiz           x0, x3, #1, #0x1f
    //     0xbebc38: cmp             x3, x0, asr #1
    //     0xbebc3c: b.eq            #0xbebc48
    //     0xbebc40: bl              #0xd69bb8
    //     0xbebc44: stur            x3, [x0, #7]
    // 0xbebc48: stp             x0, NULL, [SP, #-0x10]!
    // 0xbebc4c: r0 = _Double.fromInteger()
    //     0xbebc4c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xbebc50: add             SP, SP, #0x10
    // 0xbebc54: LoadField: d0 = r0->field_7
    //     0xbebc54: ldur            d0, [x0, #7]
    // 0xbebc58: ldr             x0, [fp, #0x30]
    // 0xbebc5c: StoreField: r0->field_7f = d0
    //     0xbebc5c: stur            d0, [x0, #0x7f]
    // 0xbebc60: ldr             x16, [fp, #0x28]
    // 0xbebc64: stp             x16, x0, [SP, #-0x10]!
    // 0xbebc68: ldr             x16, [fp, #0x18]
    // 0xbebc6c: stp             x16, NULL, [SP, #-0x10]!
    // 0xbebc70: ldr             x16, [fp, #0x10]
    // 0xbebc74: SaveReg r16
    //     0xbebc74: str             x16, [SP, #-8]!
    // 0xbebc78: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xbebc78: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xbebc7c: r0 = ScrollPositionWithSingleContext()
    //     0xbebc7c: bl              #0xbeb8c8  ; [package:flutter/src/widgets/scroll_position_with_single_context.dart] ScrollPositionWithSingleContext::ScrollPositionWithSingleContext
    // 0xbebc80: add             SP, SP, #0x28
    // 0xbebc84: r0 = Null
    //     0xbebc84: mov             x0, NULL
    // 0xbebc88: LeaveFrame
    //     0xbebc88: mov             SP, fp
    //     0xbebc8c: ldp             fp, lr, [SP], #0x10
    // 0xbebc90: ret
    //     0xbebc90: ret             
    // 0xbebc94: r0 = StackOverflowSharedWithFPURegs()
    //     0xbebc94: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbebc98: b               #0xbebc24
  }
  _ restoreOffset(/* No info */) {
    // ** addr: 0xbff65c, size: 0xa4
    // 0xbff65c: EnterFrame
    //     0xbff65c: stp             fp, lr, [SP, #-0x10]!
    //     0xbff660: mov             fp, SP
    // 0xbff664: CheckStackOverflow
    //     0xbff664: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbff668: cmp             SP, x16
    //     0xbff66c: b.ls            #0xbff6e8
    // 0xbff670: ldr             x0, [fp, #0x10]
    // 0xbff674: tbnz            w0, #4, #0xbff688
    // 0xbff678: ldr             x0, [fp, #0x20]
    // 0xbff67c: ldr             d0, [fp, #0x18]
    // 0xbff680: StoreField: r0->field_7f = d0
    //     0xbff680: stur            d0, [x0, #0x7f]
    // 0xbff684: b               #0xbff6d8
    // 0xbff688: ldr             x0, [fp, #0x20]
    // 0xbff68c: ldr             d0, [fp, #0x18]
    // 0xbff690: SaveReg r0
    //     0xbff690: str             x0, [SP, #-8]!
    // 0xbff694: SaveReg d0
    //     0xbff694: str             d0, [SP, #-8]!
    // 0xbff698: r0 = getPixelsFromPage()
    //     0xbff698: bl              #0xbff700  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::getPixelsFromPage
    // 0xbff69c: add             SP, SP, #0x10
    // 0xbff6a0: r0 = inline_Allocate_Double()
    //     0xbff6a0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbff6a4: add             x0, x0, #0x10
    //     0xbff6a8: cmp             x1, x0
    //     0xbff6ac: b.ls            #0xbff6f0
    //     0xbff6b0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbff6b4: sub             x0, x0, #0xf
    //     0xbff6b8: mov             x1, #0xd108
    //     0xbff6bc: movk            x1, #3, lsl #16
    //     0xbff6c0: stur            x1, [x0, #-1]
    // 0xbff6c4: StoreField: r0->field_7 = d0
    //     0xbff6c4: stur            d0, [x0, #7]
    // 0xbff6c8: ldr             x16, [fp, #0x20]
    // 0xbff6cc: stp             x0, x16, [SP, #-0x10]!
    // 0xbff6d0: r0 = jumpTo()
    //     0xbff6d0: bl              #0xc51528  ; [package:flutter/src/widgets/scroll_position_with_single_context.dart] ScrollPositionWithSingleContext::jumpTo
    // 0xbff6d4: add             SP, SP, #0x10
    // 0xbff6d8: r0 = Null
    //     0xbff6d8: mov             x0, NULL
    // 0xbff6dc: LeaveFrame
    //     0xbff6dc: mov             SP, fp
    //     0xbff6e0: ldp             fp, lr, [SP], #0x10
    // 0xbff6e4: ret
    //     0xbff6e4: ret             
    // 0xbff6e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbff6e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbff6ec: b               #0xbff670
    // 0xbff6f0: SaveReg d0
    //     0xbff6f0: str             q0, [SP, #-0x10]!
    // 0xbff6f4: r0 = AllocateDouble()
    //     0xbff6f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbff6f8: RestoreReg d0
    //     0xbff6f8: ldr             q0, [SP], #0x10
    // 0xbff6fc: b               #0xbff6c4
  }
  _ getPixelsFromPage(/* No info */) {
    // ** addr: 0xbff700, size: 0x68
    // 0xbff700: EnterFrame
    //     0xbff700: stp             fp, lr, [SP, #-0x10]!
    //     0xbff704: mov             fp, SP
    // 0xbff708: AllocStack(0x8)
    //     0xbff708: sub             SP, SP, #8
    // 0xbff70c: CheckStackOverflow
    //     0xbff70c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbff710: cmp             SP, x16
    //     0xbff714: b.ls            #0xbff760
    // 0xbff718: ldr             x16, [fp, #0x18]
    // 0xbff71c: SaveReg r16
    //     0xbff71c: str             x16, [SP, #-8]!
    // 0xbff720: r0 = viewportDimension()
    //     0xbff720: bl              #0xcaf454  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::viewportDimension
    // 0xbff724: add             SP, SP, #8
    // 0xbff728: mov             v1.16b, v0.16b
    // 0xbff72c: ldr             d0, [fp, #0x10]
    // 0xbff730: fmul            d2, d0, d1
    // 0xbff734: stur            d2, [fp, #-8]
    // 0xbff738: ldr             x16, [fp, #0x18]
    // 0xbff73c: SaveReg r16
    //     0xbff73c: str             x16, [SP, #-8]!
    // 0xbff740: r0 = _initialPageOffset()
    //     0xbff740: bl              #0xbff768  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::_initialPageOffset
    // 0xbff744: add             SP, SP, #8
    // 0xbff748: ldur            d1, [fp, #-8]
    // 0xbff74c: fadd            d2, d1, d0
    // 0xbff750: mov             v0.16b, v2.16b
    // 0xbff754: LeaveFrame
    //     0xbff754: mov             SP, fp
    //     0xbff758: ldp             fp, lr, [SP], #0x10
    // 0xbff75c: ret
    //     0xbff75c: ret             
    // 0xbff760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbff760: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbff764: b               #0xbff718
  }
  get _ _initialPageOffset(/* No info */) {
    // ** addr: 0xbff768, size: 0x98
    // 0xbff768: EnterFrame
    //     0xbff768: stp             fp, lr, [SP, #-0x10]!
    //     0xbff76c: mov             fp, SP
    // 0xbff770: d2 = 0.000000
    //     0xbff770: eor             v2.16b, v2.16b, v2.16b
    // 0xbff774: d1 = 2.000000
    //     0xbff774: fmov            d1, #2.00000000
    // 0xbff778: ldr             x0, [fp, #0x10]
    // 0xbff77c: LoadField: r1 = r0->field_47
    //     0xbff77c: ldur            w1, [x0, #0x47]
    // 0xbff780: DecompressPointer r1
    //     0xbff780: add             x1, x1, HEAP, lsl #32
    // 0xbff784: cmp             w1, NULL
    // 0xbff788: b.eq            #0xbff7fc
    // 0xbff78c: LoadField: d3 = r1->field_7
    //     0xbff78c: ldur            d3, [x1, #7]
    // 0xbff790: fadd            d4, d3, d2
    // 0xbff794: fmul            d3, d4, d2
    // 0xbff798: fdiv            d4, d3, d1
    // 0xbff79c: fcmp            d2, d4
    // 0xbff7a0: b.vs            #0xbff7b0
    // 0xbff7a4: b.le            #0xbff7b0
    // 0xbff7a8: d0 = 0.000000
    //     0xbff7a8: eor             v0.16b, v0.16b, v0.16b
    // 0xbff7ac: b               #0xbff7f0
    // 0xbff7b0: fcmp            d2, d4
    // 0xbff7b4: b.vs            #0xbff7c4
    // 0xbff7b8: b.ge            #0xbff7c4
    // 0xbff7bc: mov             v0.16b, v4.16b
    // 0xbff7c0: b               #0xbff7f0
    // 0xbff7c4: fcmp            d2, d2
    // 0xbff7c8: b.vs            #0xbff7dc
    // 0xbff7cc: b.ne            #0xbff7dc
    // 0xbff7d0: fadd            d1, d2, d4
    // 0xbff7d4: mov             v0.16b, v1.16b
    // 0xbff7d8: b               #0xbff7f0
    // 0xbff7dc: fcmp            d4, d4
    // 0xbff7e0: b.vc            #0xbff7ec
    // 0xbff7e4: mov             v0.16b, v4.16b
    // 0xbff7e8: b               #0xbff7f0
    // 0xbff7ec: d0 = 0.000000
    //     0xbff7ec: eor             v0.16b, v0.16b, v0.16b
    // 0xbff7f0: LeaveFrame
    //     0xbff7f0: mov             SP, fp
    //     0xbff7f4: ldp             fp, lr, [SP], #0x10
    // 0xbff7f8: ret
    //     0xbff7f8: ret             
    // 0xbff7fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbff7fc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ saveOffset(/* No info */) {
    // ** addr: 0xbff9a8, size: 0xb0
    // 0xbff9a8: EnterFrame
    //     0xbff9a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbff9ac: mov             fp, SP
    // 0xbff9b0: AllocStack(0x8)
    //     0xbff9b0: sub             SP, SP, #8
    // 0xbff9b4: CheckStackOverflow
    //     0xbff9b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbff9b8: cmp             SP, x16
    //     0xbff9bc: b.ls            #0xbffa48
    // 0xbff9c0: ldr             x0, [fp, #0x10]
    // 0xbff9c4: LoadField: r1 = r0->field_27
    //     0xbff9c4: ldur            w1, [x0, #0x27]
    // 0xbff9c8: DecompressPointer r1
    //     0xbff9c8: add             x1, x1, HEAP, lsl #32
    // 0xbff9cc: stur            x1, [fp, #-8]
    // 0xbff9d0: LoadField: r2 = r0->field_87
    //     0xbff9d0: ldur            w2, [x0, #0x87]
    // 0xbff9d4: DecompressPointer r2
    //     0xbff9d4: add             x2, x2, HEAP, lsl #32
    // 0xbff9d8: cmp             w2, NULL
    // 0xbff9dc: b.ne            #0xbffa20
    // 0xbff9e0: d0 = 0.000000
    //     0xbff9e0: eor             v0.16b, v0.16b, v0.16b
    // 0xbff9e4: LoadField: r2 = r0->field_43
    //     0xbff9e4: ldur            w2, [x0, #0x43]
    // 0xbff9e8: DecompressPointer r2
    //     0xbff9e8: add             x2, x2, HEAP, lsl #32
    // 0xbff9ec: cmp             w2, NULL
    // 0xbff9f0: b.eq            #0xbffa50
    // 0xbff9f4: LoadField: r3 = r0->field_47
    //     0xbff9f4: ldur            w3, [x0, #0x47]
    // 0xbff9f8: DecompressPointer r3
    //     0xbff9f8: add             x3, x3, HEAP, lsl #32
    // 0xbff9fc: cmp             w3, NULL
    // 0xbffa00: b.eq            #0xbffa54
    // 0xbffa04: LoadField: d1 = r3->field_7
    //     0xbffa04: ldur            d1, [x3, #7]
    // 0xbffa08: fadd            d2, d1, d0
    // 0xbffa0c: stp             x2, x0, [SP, #-0x10]!
    // 0xbffa10: SaveReg d2
    //     0xbffa10: str             d2, [SP, #-8]!
    // 0xbffa14: r0 = getPageFromPixels()
    //     0xbffa14: bl              #0xbffb8c  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::getPageFromPixels
    // 0xbffa18: add             SP, SP, #0x18
    // 0xbffa1c: b               #0xbffa24
    // 0xbffa20: LoadField: d0 = r2->field_7
    //     0xbffa20: ldur            d0, [x2, #7]
    // 0xbffa24: ldur            x16, [fp, #-8]
    // 0xbffa28: SaveReg r16
    //     0xbffa28: str             x16, [SP, #-8]!
    // 0xbffa2c: SaveReg d0
    //     0xbffa2c: str             d0, [SP, #-8]!
    // 0xbffa30: r0 = saveOffset()
    //     0xbffa30: bl              #0xbffa58  ; [package:flutter/src/widgets/scrollable.dart] ScrollableState::saveOffset
    // 0xbffa34: add             SP, SP, #0x10
    // 0xbffa38: r0 = Null
    //     0xbffa38: mov             x0, NULL
    // 0xbffa3c: LeaveFrame
    //     0xbffa3c: mov             SP, fp
    //     0xbffa40: ldp             fp, lr, [SP], #0x10
    // 0xbffa44: ret
    //     0xbffa44: ret             
    // 0xbffa48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbffa48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbffa4c: b               #0xbff9c0
    // 0xbffa50: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbffa50: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbffa54: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbffa54: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ getPageFromPixels(/* No info */) {
    // ** addr: 0xbffb8c, size: 0x19c
    // 0xbffb8c: EnterFrame
    //     0xbffb8c: stp             fp, lr, [SP, #-0x10]!
    //     0xbffb90: mov             fp, SP
    // 0xbffb94: AllocStack(0x8)
    //     0xbffb94: sub             SP, SP, #8
    // 0xbffb98: CheckStackOverflow
    //     0xbffb98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbffb9c: cmp             SP, x16
    //     0xbffba0: b.ls            #0xbffd20
    // 0xbffba4: ldr             x16, [fp, #0x20]
    // 0xbffba8: SaveReg r16
    //     0xbffba8: str             x16, [SP, #-8]!
    // 0xbffbac: r0 = _initialPageOffset()
    //     0xbffbac: bl              #0xbff768  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::_initialPageOffset
    // 0xbffbb0: add             SP, SP, #8
    // 0xbffbb4: ldr             x0, [fp, #0x18]
    // 0xbffbb8: LoadField: d1 = r0->field_7
    //     0xbffbb8: ldur            d1, [x0, #7]
    // 0xbffbbc: fsub            d2, d1, d0
    // 0xbffbc0: d1 = 0.000000
    //     0xbffbc0: eor             v1.16b, v1.16b, v1.16b
    // 0xbffbc4: fcmp            d1, d2
    // 0xbffbc8: b.vs            #0xbffbd8
    // 0xbffbcc: b.le            #0xbffbd8
    // 0xbffbd0: d3 = 0.000000
    //     0xbffbd0: eor             v3.16b, v3.16b, v3.16b
    // 0xbffbd4: b               #0xbffc18
    // 0xbffbd8: fcmp            d1, d2
    // 0xbffbdc: b.vs            #0xbffbec
    // 0xbffbe0: b.ge            #0xbffbec
    // 0xbffbe4: mov             v3.16b, v2.16b
    // 0xbffbe8: b               #0xbffc18
    // 0xbffbec: fcmp            d1, d1
    // 0xbffbf0: b.vs            #0xbffc04
    // 0xbffbf4: b.ne            #0xbffc04
    // 0xbffbf8: fadd            d0, d1, d2
    // 0xbffbfc: mov             v3.16b, v0.16b
    // 0xbffc00: b               #0xbffc18
    // 0xbffc04: fcmp            d2, d2
    // 0xbffc08: b.vc            #0xbffc14
    // 0xbffc0c: mov             v3.16b, v2.16b
    // 0xbffc10: b               #0xbffc18
    // 0xbffc14: d3 = 0.000000
    //     0xbffc14: eor             v3.16b, v3.16b, v3.16b
    // 0xbffc18: ldr             d2, [fp, #0x10]
    // 0xbffc1c: d0 = 1.000000
    //     0xbffc1c: fmov            d0, #1.00000000
    // 0xbffc20: fcmp            d0, d2
    // 0xbffc24: b.vs            #0xbffc34
    // 0xbffc28: b.le            #0xbffc34
    // 0xbffc2c: d0 = 1.000000
    //     0xbffc2c: fmov            d0, #1.00000000
    // 0xbffc30: b               #0xbffc74
    // 0xbffc34: fcmp            d0, d2
    // 0xbffc38: b.vs            #0xbffc48
    // 0xbffc3c: b.ge            #0xbffc48
    // 0xbffc40: mov             v0.16b, v2.16b
    // 0xbffc44: b               #0xbffc74
    // 0xbffc48: fcmp            d0, d1
    // 0xbffc4c: b.vs            #0xbffc60
    // 0xbffc50: b.ne            #0xbffc60
    // 0xbffc54: fadd            d4, d0, d2
    // 0xbffc58: mov             v0.16b, v4.16b
    // 0xbffc5c: b               #0xbffc74
    // 0xbffc60: fcmp            d2, d2
    // 0xbffc64: b.vc            #0xbffc70
    // 0xbffc68: mov             v0.16b, v2.16b
    // 0xbffc6c: b               #0xbffc74
    // 0xbffc70: d0 = 1.000000
    //     0xbffc70: fmov            d0, #1.00000000
    // 0xbffc74: fdiv            d2, d3, d0
    // 0xbffc78: mov             v0.16b, v2.16b
    // 0xbffc7c: stur            d2, [fp, #-8]
    // 0xbffc80: stp             fp, lr, [SP, #-0x10]!
    // 0xbffc84: mov             fp, SP
    // 0xbffc88: CallRuntime_LibcRound(double) -> double
    //     0xbffc88: and             SP, SP, #0xfffffffffffffff0
    //     0xbffc8c: mov             sp, SP
    //     0xbffc90: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0xbffc94: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbffc98: blr             x16
    //     0xbffc9c: mov             x16, #8
    //     0xbffca0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbffca4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbffca8: sub             sp, x16, #1, lsl #12
    //     0xbffcac: mov             SP, fp
    //     0xbffcb0: ldp             fp, lr, [SP], #0x10
    // 0xbffcb4: mov             v1.16b, v0.16b
    // 0xbffcb8: ldur            d0, [fp, #-8]
    // 0xbffcbc: fsub            d2, d0, d1
    // 0xbffcc0: d3 = 0.000000
    //     0xbffcc0: eor             v3.16b, v3.16b, v3.16b
    // 0xbffcc4: fcmp            d2, d3
    // 0xbffcc8: b.vs            #0xbffcd8
    // 0xbffccc: b.ne            #0xbffcd8
    // 0xbffcd0: d3 = 0.000000
    //     0xbffcd0: eor             v3.16b, v3.16b, v3.16b
    // 0xbffcd4: b               #0xbffcf0
    // 0xbffcd8: fcmp            d2, d3
    // 0xbffcdc: b.vs            #0xbffcec
    // 0xbffce0: b.ge            #0xbffcec
    // 0xbffce4: fneg            d3, d2
    // 0xbffce8: mov             v2.16b, v3.16b
    // 0xbffcec: mov             v3.16b, v2.16b
    // 0xbffcf0: d2 = 0.000000
    //     0xbffcf0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0xbffcf4: ldr             d2, [x17, #0x1e0]
    // 0xbffcf8: fcmp            d3, d2
    // 0xbffcfc: b.vs            #0xbffd14
    // 0xbffd00: b.ge            #0xbffd14
    // 0xbffd04: mov             v0.16b, v1.16b
    // 0xbffd08: LeaveFrame
    //     0xbffd08: mov             SP, fp
    //     0xbffd0c: ldp             fp, lr, [SP], #0x10
    // 0xbffd10: ret
    //     0xbffd10: ret             
    // 0xbffd14: LeaveFrame
    //     0xbffd14: mov             SP, fp
    //     0xbffd18: ldp             fp, lr, [SP], #0x10
    // 0xbffd1c: ret
    //     0xbffd1c: ret             
    // 0xbffd20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbffd20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbffd24: b               #0xbffba4
  }
  _ saveScrollOffset(/* No info */) {
    // ** addr: 0xbffe30, size: 0x138
    // 0xbffe30: EnterFrame
    //     0xbffe30: stp             fp, lr, [SP, #-0x10]!
    //     0xbffe34: mov             fp, SP
    // 0xbffe38: AllocStack(0x18)
    //     0xbffe38: sub             SP, SP, #0x18
    // 0xbffe3c: CheckStackOverflow
    //     0xbffe3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbffe40: cmp             SP, x16
    //     0xbffe44: b.ls            #0xbfff40
    // 0xbffe48: ldr             x0, [fp, #0x10]
    // 0xbffe4c: LoadField: r1 = r0->field_27
    //     0xbffe4c: ldur            w1, [x0, #0x27]
    // 0xbffe50: DecompressPointer r1
    //     0xbffe50: add             x1, x1, HEAP, lsl #32
    // 0xbffe54: stur            x1, [fp, #-8]
    // 0xbffe58: LoadField: r2 = r1->field_f
    //     0xbffe58: ldur            w2, [x1, #0xf]
    // 0xbffe5c: DecompressPointer r2
    //     0xbffe5c: add             x2, x2, HEAP, lsl #32
    // 0xbffe60: cmp             w2, NULL
    // 0xbffe64: b.eq            #0xbfff48
    // 0xbffe68: SaveReg r2
    //     0xbffe68: str             x2, [SP, #-8]!
    // 0xbffe6c: r0 = maybeOf()
    //     0xbffe6c: bl              #0x8536fc  ; [package:flutter/src/widgets/page_storage.dart] PageStorage::maybeOf
    // 0xbffe70: add             SP, SP, #8
    // 0xbffe74: stur            x0, [fp, #-0x18]
    // 0xbffe78: cmp             w0, NULL
    // 0xbffe7c: b.eq            #0xbfff30
    // 0xbffe80: ldr             x1, [fp, #0x10]
    // 0xbffe84: ldur            x2, [fp, #-8]
    // 0xbffe88: LoadField: r3 = r2->field_f
    //     0xbffe88: ldur            w3, [x2, #0xf]
    // 0xbffe8c: DecompressPointer r3
    //     0xbffe8c: add             x3, x3, HEAP, lsl #32
    // 0xbffe90: stur            x3, [fp, #-0x10]
    // 0xbffe94: cmp             w3, NULL
    // 0xbffe98: b.eq            #0xbfff4c
    // 0xbffe9c: LoadField: r2 = r1->field_87
    //     0xbffe9c: ldur            w2, [x1, #0x87]
    // 0xbffea0: DecompressPointer r2
    //     0xbffea0: add             x2, x2, HEAP, lsl #32
    // 0xbffea4: cmp             w2, NULL
    // 0xbffea8: b.ne            #0xbffeec
    // 0xbffeac: d0 = 0.000000
    //     0xbffeac: eor             v0.16b, v0.16b, v0.16b
    // 0xbffeb0: LoadField: r2 = r1->field_43
    //     0xbffeb0: ldur            w2, [x1, #0x43]
    // 0xbffeb4: DecompressPointer r2
    //     0xbffeb4: add             x2, x2, HEAP, lsl #32
    // 0xbffeb8: cmp             w2, NULL
    // 0xbffebc: b.eq            #0xbfff50
    // 0xbffec0: LoadField: r4 = r1->field_47
    //     0xbffec0: ldur            w4, [x1, #0x47]
    // 0xbffec4: DecompressPointer r4
    //     0xbffec4: add             x4, x4, HEAP, lsl #32
    // 0xbffec8: cmp             w4, NULL
    // 0xbffecc: b.eq            #0xbfff54
    // 0xbffed0: LoadField: d1 = r4->field_7
    //     0xbffed0: ldur            d1, [x4, #7]
    // 0xbffed4: fadd            d2, d1, d0
    // 0xbffed8: stp             x2, x1, [SP, #-0x10]!
    // 0xbffedc: SaveReg d2
    //     0xbffedc: str             d2, [SP, #-8]!
    // 0xbffee0: r0 = getPageFromPixels()
    //     0xbffee0: bl              #0xbffb8c  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::getPageFromPixels
    // 0xbffee4: add             SP, SP, #0x18
    // 0xbffee8: b               #0xbffef0
    // 0xbffeec: LoadField: d0 = r2->field_7
    //     0xbffeec: ldur            d0, [x2, #7]
    // 0xbffef0: r0 = inline_Allocate_Double()
    //     0xbffef0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbffef4: add             x0, x0, #0x10
    //     0xbffef8: cmp             x1, x0
    //     0xbffefc: b.ls            #0xbfff58
    //     0xbfff00: str             x0, [THR, #0x60]  ; THR::top
    //     0xbfff04: sub             x0, x0, #0xf
    //     0xbfff08: mov             x1, #0xd108
    //     0xbfff0c: movk            x1, #3, lsl #16
    //     0xbfff10: stur            x1, [x0, #-1]
    // 0xbfff14: StoreField: r0->field_7 = d0
    //     0xbfff14: stur            d0, [x0, #7]
    // 0xbfff18: ldur            x16, [fp, #-0x18]
    // 0xbfff1c: ldur            lr, [fp, #-0x10]
    // 0xbfff20: stp             lr, x16, [SP, #-0x10]!
    // 0xbfff24: SaveReg r0
    //     0xbfff24: str             x0, [SP, #-8]!
    // 0xbfff28: r0 = writeState()
    //     0xbfff28: bl              #0x853448  ; [package:flutter/src/widgets/page_storage.dart] PageStorageBucket::writeState
    // 0xbfff2c: add             SP, SP, #0x18
    // 0xbfff30: r0 = Null
    //     0xbfff30: mov             x0, NULL
    // 0xbfff34: LeaveFrame
    //     0xbfff34: mov             SP, fp
    //     0xbfff38: ldp             fp, lr, [SP], #0x10
    // 0xbfff3c: ret
    //     0xbfff3c: ret             
    // 0xbfff40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfff40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfff44: b               #0xbffe48
    // 0xbfff48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfff48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbfff4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfff4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbfff50: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbfff50: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbfff54: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbfff54: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbfff58: SaveReg d0
    //     0xbfff58: str             q0, [SP, #-0x10]!
    // 0xbfff5c: r0 = AllocateDouble()
    //     0xbfff5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbfff60: RestoreReg d0
    //     0xbfff60: ldr             q0, [SP], #0x10
    // 0xbfff64: b               #0xbfff14
  }
  _ ensureVisible(/* No info */) {
    // ** addr: 0xc00140, size: 0x74
    // 0xc00140: EnterFrame
    //     0xc00140: stp             fp, lr, [SP, #-0x10]!
    //     0xc00144: mov             fp, SP
    // 0xc00148: mov             x0, x4
    // 0xc0014c: LoadField: r1 = r0->field_13
    //     0xc0014c: ldur            w1, [x0, #0x13]
    // 0xc00150: DecompressPointer r1
    //     0xc00150: add             x1, x1, HEAP, lsl #32
    // 0xc00154: sub             x0, x1, #8
    // 0xc00158: add             x1, fp, w0, sxtw #2
    // 0xc0015c: ldr             x1, [x1, #0x28]
    // 0xc00160: add             x2, fp, w0, sxtw #2
    // 0xc00164: ldr             x2, [x2, #0x20]
    // 0xc00168: add             x3, fp, w0, sxtw #2
    // 0xc0016c: ldr             d0, [x3, #0x18]
    // 0xc00170: add             x3, fp, w0, sxtw #2
    // 0xc00174: ldr             x3, [x3, #0x10]
    // 0xc00178: CheckStackOverflow
    //     0xc00178: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0017c: cmp             SP, x16
    //     0xc00180: b.ls            #0xc001ac
    // 0xc00184: stp             x2, x1, [SP, #-0x10]!
    // 0xc00188: SaveReg d0
    //     0xc00188: str             d0, [SP, #-8]!
    // 0xc0018c: stp             NULL, x3, [SP, #-0x10]!
    // 0xc00190: r4 = const [0, 0x5, 0x5, 0x4, targetRenderObject, 0x4, null]
    //     0xc00190: add             x4, PP, #0x31, lsl #12  ; [pp+0x315c8] List(7) [0, 0x5, 0x5, 0x4, "targetRenderObject", 0x4, Null]
    //     0xc00194: ldr             x4, [x4, #0x5c8]
    // 0xc00198: r0 = ensureVisible()
    //     0xc00198: bl              #0xc00224  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::ensureVisible
    // 0xc0019c: add             SP, SP, #0x28
    // 0xc001a0: LeaveFrame
    //     0xc001a0: mov             SP, fp
    //     0xc001a4: ldp             fp, lr, [SP], #0x10
    // 0xc001a8: ret
    //     0xc001a8: ret             
    // 0xc001ac: r0 = StackOverflowSharedWithFPURegs()
    //     0xc001ac: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc001b0: b               #0xc00184
  }
  _ restoreScrollOffset(/* No info */) {
    // ** addr: 0xc02f0c, size: 0xf8
    // 0xc02f0c: EnterFrame
    //     0xc02f0c: stp             fp, lr, [SP, #-0x10]!
    //     0xc02f10: mov             fp, SP
    // 0xc02f14: AllocStack(0x8)
    //     0xc02f14: sub             SP, SP, #8
    // 0xc02f18: CheckStackOverflow
    //     0xc02f18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc02f1c: cmp             SP, x16
    //     0xc02f20: b.ls            #0xc02ff4
    // 0xc02f24: ldr             x0, [fp, #0x10]
    // 0xc02f28: LoadField: r1 = r0->field_43
    //     0xc02f28: ldur            w1, [x0, #0x43]
    // 0xc02f2c: DecompressPointer r1
    //     0xc02f2c: add             x1, x1, HEAP, lsl #32
    // 0xc02f30: cmp             w1, NULL
    // 0xc02f34: b.ne            #0xc02fe4
    // 0xc02f38: LoadField: r1 = r0->field_27
    //     0xc02f38: ldur            w1, [x0, #0x27]
    // 0xc02f3c: DecompressPointer r1
    //     0xc02f3c: add             x1, x1, HEAP, lsl #32
    // 0xc02f40: stur            x1, [fp, #-8]
    // 0xc02f44: LoadField: r2 = r1->field_f
    //     0xc02f44: ldur            w2, [x1, #0xf]
    // 0xc02f48: DecompressPointer r2
    //     0xc02f48: add             x2, x2, HEAP, lsl #32
    // 0xc02f4c: cmp             w2, NULL
    // 0xc02f50: b.eq            #0xc02ffc
    // 0xc02f54: SaveReg r2
    //     0xc02f54: str             x2, [SP, #-8]!
    // 0xc02f58: r0 = maybeOf()
    //     0xc02f58: bl              #0x8536fc  ; [package:flutter/src/widgets/page_storage.dart] PageStorage::maybeOf
    // 0xc02f5c: add             SP, SP, #8
    // 0xc02f60: cmp             w0, NULL
    // 0xc02f64: b.ne            #0xc02f70
    // 0xc02f68: r3 = Null
    //     0xc02f68: mov             x3, NULL
    // 0xc02f6c: b               #0xc02f94
    // 0xc02f70: ldur            x1, [fp, #-8]
    // 0xc02f74: LoadField: r2 = r1->field_f
    //     0xc02f74: ldur            w2, [x1, #0xf]
    // 0xc02f78: DecompressPointer r2
    //     0xc02f78: add             x2, x2, HEAP, lsl #32
    // 0xc02f7c: cmp             w2, NULL
    // 0xc02f80: b.eq            #0xc03000
    // 0xc02f84: stp             x2, x0, [SP, #-0x10]!
    // 0xc02f88: r0 = readState()
    //     0xc02f88: bl              #0x9d9da0  ; [package:flutter/src/widgets/page_storage.dart] PageStorageBucket::readState
    // 0xc02f8c: add             SP, SP, #0x10
    // 0xc02f90: mov             x3, x0
    // 0xc02f94: mov             x0, x3
    // 0xc02f98: stur            x3, [fp, #-8]
    // 0xc02f9c: r2 = Null
    //     0xc02f9c: mov             x2, NULL
    // 0xc02fa0: r1 = Null
    //     0xc02fa0: mov             x1, NULL
    // 0xc02fa4: r4 = 59
    //     0xc02fa4: mov             x4, #0x3b
    // 0xc02fa8: branchIfSmi(r0, 0xc02fb4)
    //     0xc02fa8: tbz             w0, #0, #0xc02fb4
    // 0xc02fac: r4 = LoadClassIdInstr(r0)
    //     0xc02fac: ldur            x4, [x0, #-1]
    //     0xc02fb0: ubfx            x4, x4, #0xc, #0x14
    // 0xc02fb4: cmp             x4, #0x3d
    // 0xc02fb8: b.eq            #0xc02fcc
    // 0xc02fbc: r8 = double?
    //     0xc02fbc: ldr             x8, [PP, #0x21e0]  ; [pp+0x21e0] Type: double?
    // 0xc02fc0: r3 = Null
    //     0xc02fc0: add             x3, PP, #0x51, lsl #12  ; [pp+0x51388] Null
    //     0xc02fc4: ldr             x3, [x3, #0x388]
    // 0xc02fc8: r0 = double?()
    //     0xc02fc8: bl              #0xd72b80  ; IsType_double?_Stub
    // 0xc02fcc: ldur            x1, [fp, #-8]
    // 0xc02fd0: cmp             w1, NULL
    // 0xc02fd4: b.eq            #0xc02fe4
    // 0xc02fd8: ldr             x2, [fp, #0x10]
    // 0xc02fdc: LoadField: d0 = r1->field_7
    //     0xc02fdc: ldur            d0, [x1, #7]
    // 0xc02fe0: StoreField: r2->field_7f = d0
    //     0xc02fe0: stur            d0, [x2, #0x7f]
    // 0xc02fe4: r0 = Null
    //     0xc02fe4: mov             x0, NULL
    // 0xc02fe8: LeaveFrame
    //     0xc02fe8: mov             SP, fp
    //     0xc02fec: ldp             fp, lr, [SP], #0x10
    // 0xc02ff0: ret
    //     0xc02ff0: ret             
    // 0xc02ff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02ff4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02ff8: b               #0xc02f24
    // 0xc02ffc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc02ffc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc03000: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc03000: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ absorb(/* No info */) {
    // ** addr: 0xc037b4, size: 0x9c
    // 0xc037b4: EnterFrame
    //     0xc037b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc037b8: mov             fp, SP
    // 0xc037bc: CheckStackOverflow
    //     0xc037bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc037c0: cmp             SP, x16
    //     0xc037c4: b.ls            #0xc03848
    // 0xc037c8: ldr             x16, [fp, #0x18]
    // 0xc037cc: ldr             lr, [fp, #0x10]
    // 0xc037d0: stp             lr, x16, [SP, #-0x10]!
    // 0xc037d4: r0 = absorb()
    //     0xc037d4: bl              #0xc038ec  ; [package:flutter/src/widgets/scroll_position_with_single_context.dart] ScrollPositionWithSingleContext::absorb
    // 0xc037d8: add             SP, SP, #0x10
    // 0xc037dc: ldr             x1, [fp, #0x10]
    // 0xc037e0: r2 = LoadClassIdInstr(r1)
    //     0xc037e0: ldur            x2, [x1, #-1]
    //     0xc037e4: ubfx            x2, x2, #0xc, #0x14
    // 0xc037e8: lsl             x2, x2, #1
    // 0xc037ec: r17 = 9700
    //     0xc037ec: mov             x17, #0x25e4
    // 0xc037f0: cmp             w2, w17
    // 0xc037f4: b.eq            #0xc03808
    // 0xc037f8: r0 = Null
    //     0xc037f8: mov             x0, NULL
    // 0xc037fc: LeaveFrame
    //     0xc037fc: mov             SP, fp
    //     0xc03800: ldp             fp, lr, [SP], #0x10
    // 0xc03804: ret
    //     0xc03804: ret             
    // 0xc03808: LoadField: r0 = r1->field_87
    //     0xc03808: ldur            w0, [x1, #0x87]
    // 0xc0380c: DecompressPointer r0
    //     0xc0380c: add             x0, x0, HEAP, lsl #32
    // 0xc03810: cmp             w0, NULL
    // 0xc03814: b.eq            #0xc03838
    // 0xc03818: ldr             x1, [fp, #0x18]
    // 0xc0381c: StoreField: r1->field_87 = r0
    //     0xc0381c: stur            w0, [x1, #0x87]
    //     0xc03820: ldurb           w16, [x1, #-1]
    //     0xc03824: ldurb           w17, [x0, #-1]
    //     0xc03828: and             x16, x17, x16, lsr #2
    //     0xc0382c: tst             x16, HEAP, lsr #32
    //     0xc03830: b.eq            #0xc03838
    //     0xc03834: bl              #0xd6826c
    // 0xc03838: r0 = Null
    //     0xc03838: mov             x0, NULL
    // 0xc0383c: LeaveFrame
    //     0xc0383c: mov             SP, fp
    //     0xc03840: ldp             fp, lr, [SP], #0x10
    // 0xc03844: ret
    //     0xc03844: ret             
    // 0xc03848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc03848: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0384c: b               #0xc037c8
  }
  set _ pageSpacing=(/* No info */) {
    // ** addr: 0xc48a58, size: 0x88
    // 0xc48a58: EnterFrame
    //     0xc48a58: stp             fp, lr, [SP, #-0x10]!
    //     0xc48a5c: mov             fp, SP
    // 0xc48a60: d0 = 0.000000
    //     0xc48a60: eor             v0.16b, v0.16b, v0.16b
    // 0xc48a64: CheckStackOverflow
    //     0xc48a64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc48a68: cmp             SP, x16
    //     0xc48a6c: b.ls            #0xc48ad8
    // 0xc48a70: fcmp            d0, d0
    // 0xc48a74: b.eq            #0xc48ac8
    // 0xc48a78: ldr             x0, [fp, #0x18]
    // 0xc48a7c: SaveReg r0
    //     0xc48a7c: str             x0, [SP, #-8]!
    // 0xc48a80: r0 = page()
    //     0xc48a80: bl              #0xc48ae0  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::page
    // 0xc48a84: add             SP, SP, #8
    // 0xc48a88: mov             x1, x0
    // 0xc48a8c: ldr             x0, [fp, #0x18]
    // 0xc48a90: d0 = 0.000000
    //     0xc48a90: eor             v0.16b, v0.16b, v0.16b
    // 0xc48a94: StoreField: r0->field_93 = d0
    //     0xc48a94: stur            d0, [x0, #0x93]
    // 0xc48a98: cmp             w1, NULL
    // 0xc48a9c: b.eq            #0xc48ac8
    // 0xc48aa0: LoadField: d0 = r1->field_7
    //     0xc48aa0: ldur            d0, [x1, #7]
    // 0xc48aa4: SaveReg r0
    //     0xc48aa4: str             x0, [SP, #-8]!
    // 0xc48aa8: SaveReg d0
    //     0xc48aa8: str             d0, [SP, #-8]!
    // 0xc48aac: r0 = getPixelsFromPage()
    //     0xc48aac: bl              #0xbff700  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::getPixelsFromPage
    // 0xc48ab0: add             SP, SP, #0x10
    // 0xc48ab4: ldr             x16, [fp, #0x18]
    // 0xc48ab8: SaveReg r16
    //     0xc48ab8: str             x16, [SP, #-8]!
    // 0xc48abc: SaveReg d0
    //     0xc48abc: str             d0, [SP, #-8]!
    // 0xc48ac0: r0 = forcePixels()
    //     0xc48ac0: bl              #0xc144d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::forcePixels
    // 0xc48ac4: add             SP, SP, #0x10
    // 0xc48ac8: r0 = Null
    //     0xc48ac8: mov             x0, NULL
    // 0xc48acc: LeaveFrame
    //     0xc48acc: mov             SP, fp
    //     0xc48ad0: ldp             fp, lr, [SP], #0x10
    // 0xc48ad4: ret
    //     0xc48ad4: ret             
    // 0xc48ad8: r0 = StackOverflowSharedWithFPURegs()
    //     0xc48ad8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc48adc: b               #0xc48a70
  }
  get _ page(/* No info */) {
    // ** addr: 0xc48ae0, size: 0x164
    // 0xc48ae0: EnterFrame
    //     0xc48ae0: stp             fp, lr, [SP, #-0x10]!
    //     0xc48ae4: mov             fp, SP
    // 0xc48ae8: CheckStackOverflow
    //     0xc48ae8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc48aec: cmp             SP, x16
    //     0xc48af0: b.ls            #0xc48c08
    // 0xc48af4: ldr             x0, [fp, #0x10]
    // 0xc48af8: LoadField: r1 = r0->field_43
    //     0xc48af8: ldur            w1, [x0, #0x43]
    // 0xc48afc: DecompressPointer r1
    //     0xc48afc: add             x1, x1, HEAP, lsl #32
    // 0xc48b00: cmp             w1, NULL
    // 0xc48b04: b.eq            #0xc48bf8
    // 0xc48b08: LoadField: r2 = r0->field_33
    //     0xc48b08: ldur            w2, [x0, #0x33]
    // 0xc48b0c: DecompressPointer r2
    //     0xc48b0c: add             x2, x2, HEAP, lsl #32
    // 0xc48b10: cmp             w2, NULL
    // 0xc48b14: b.eq            #0xc48bf8
    // 0xc48b18: LoadField: r3 = r0->field_37
    //     0xc48b18: ldur            w3, [x0, #0x37]
    // 0xc48b1c: DecompressPointer r3
    //     0xc48b1c: add             x3, x3, HEAP, lsl #32
    // 0xc48b20: cmp             w3, NULL
    // 0xc48b24: b.eq            #0xc48bf8
    // 0xc48b28: LoadField: r4 = r0->field_87
    //     0xc48b28: ldur            w4, [x0, #0x87]
    // 0xc48b2c: DecompressPointer r4
    //     0xc48b2c: add             x4, x4, HEAP, lsl #32
    // 0xc48b30: cmp             w4, NULL
    // 0xc48b34: b.ne            #0xc48bc4
    // 0xc48b38: LoadField: d0 = r1->field_7
    //     0xc48b38: ldur            d0, [x1, #7]
    // 0xc48b3c: LoadField: d1 = r2->field_7
    //     0xc48b3c: ldur            d1, [x2, #7]
    // 0xc48b40: fcmp            d0, d1
    // 0xc48b44: b.vs            #0xc48b4c
    // 0xc48b48: b.lt            #0xc48b6c
    // 0xc48b4c: LoadField: d1 = r3->field_7
    //     0xc48b4c: ldur            d1, [x3, #7]
    // 0xc48b50: fcmp            d0, d1
    // 0xc48b54: b.vs            #0xc48b5c
    // 0xc48b58: b.gt            #0xc48b6c
    // 0xc48b5c: LoadField: d2 = r1->field_7
    //     0xc48b5c: ldur            d2, [x1, #7]
    // 0xc48b60: fcmp            d2, d2
    // 0xc48b64: b.vs            #0xc48b6c
    // 0xc48b68: mov             v1.16b, v0.16b
    // 0xc48b6c: d0 = 0.000000
    //     0xc48b6c: eor             v0.16b, v0.16b, v0.16b
    // 0xc48b70: LoadField: r1 = r0->field_47
    //     0xc48b70: ldur            w1, [x0, #0x47]
    // 0xc48b74: DecompressPointer r1
    //     0xc48b74: add             x1, x1, HEAP, lsl #32
    // 0xc48b78: cmp             w1, NULL
    // 0xc48b7c: b.eq            #0xc48c10
    // 0xc48b80: LoadField: d2 = r1->field_7
    //     0xc48b80: ldur            d2, [x1, #7]
    // 0xc48b84: fadd            d3, d2, d0
    // 0xc48b88: r1 = inline_Allocate_Double()
    //     0xc48b88: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc48b8c: add             x1, x1, #0x10
    //     0xc48b90: cmp             x2, x1
    //     0xc48b94: b.ls            #0xc48c14
    //     0xc48b98: str             x1, [THR, #0x60]  ; THR::top
    //     0xc48b9c: sub             x1, x1, #0xf
    //     0xc48ba0: mov             x2, #0xd108
    //     0xc48ba4: movk            x2, #3, lsl #16
    //     0xc48ba8: stur            x2, [x1, #-1]
    // 0xc48bac: StoreField: r1->field_7 = d1
    //     0xc48bac: stur            d1, [x1, #7]
    // 0xc48bb0: stp             x1, x0, [SP, #-0x10]!
    // 0xc48bb4: SaveReg d3
    //     0xc48bb4: str             d3, [SP, #-8]!
    // 0xc48bb8: r0 = getPageFromPixels()
    //     0xc48bb8: bl              #0xbffb8c  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::getPageFromPixels
    // 0xc48bbc: add             SP, SP, #0x18
    // 0xc48bc0: b               #0xc48bc8
    // 0xc48bc4: LoadField: d0 = r4->field_7
    //     0xc48bc4: ldur            d0, [x4, #7]
    // 0xc48bc8: r1 = inline_Allocate_Double()
    //     0xc48bc8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc48bcc: add             x1, x1, #0x10
    //     0xc48bd0: cmp             x2, x1
    //     0xc48bd4: b.ls            #0xc48c30
    //     0xc48bd8: str             x1, [THR, #0x60]  ; THR::top
    //     0xc48bdc: sub             x1, x1, #0xf
    //     0xc48be0: mov             x2, #0xd108
    //     0xc48be4: movk            x2, #3, lsl #16
    //     0xc48be8: stur            x2, [x1, #-1]
    // 0xc48bec: StoreField: r1->field_7 = d0
    //     0xc48bec: stur            d0, [x1, #7]
    // 0xc48bf0: mov             x0, x1
    // 0xc48bf4: b               #0xc48bfc
    // 0xc48bf8: r0 = Null
    //     0xc48bf8: mov             x0, NULL
    // 0xc48bfc: LeaveFrame
    //     0xc48bfc: mov             SP, fp
    //     0xc48c00: ldp             fp, lr, [SP], #0x10
    // 0xc48c04: ret
    //     0xc48c04: ret             
    // 0xc48c08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc48c08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc48c0c: b               #0xc48af4
    // 0xc48c10: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc48c10: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc48c14: stp             q1, q3, [SP, #-0x20]!
    // 0xc48c18: SaveReg r0
    //     0xc48c18: str             x0, [SP, #-8]!
    // 0xc48c1c: r0 = AllocateDouble()
    //     0xc48c1c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc48c20: mov             x1, x0
    // 0xc48c24: RestoreReg r0
    //     0xc48c24: ldr             x0, [SP], #8
    // 0xc48c28: ldp             q1, q3, [SP], #0x20
    // 0xc48c2c: b               #0xc48bac
    // 0xc48c30: SaveReg d0
    //     0xc48c30: str             q0, [SP, #-0x10]!
    // 0xc48c34: r0 = AllocateDouble()
    //     0xc48c34: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc48c38: mov             x1, x0
    // 0xc48c3c: RestoreReg d0
    //     0xc48c3c: ldr             q0, [SP], #0x10
    // 0xc48c40: b               #0xc48bec
  }
  set _ viewportFraction=(/* No info */) {
    // ** addr: 0xc48c44, size: 0x9c
    // 0xc48c44: EnterFrame
    //     0xc48c44: stp             fp, lr, [SP, #-0x10]!
    //     0xc48c48: mov             fp, SP
    // 0xc48c4c: d0 = 1.000000
    //     0xc48c4c: fmov            d0, #1.00000000
    // 0xc48c50: CheckStackOverflow
    //     0xc48c50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc48c54: cmp             SP, x16
    //     0xc48c58: b.ls            #0xc48cd8
    // 0xc48c5c: fcmp            d0, d0
    // 0xc48c60: b.vs            #0xc48c78
    // 0xc48c64: b.ne            #0xc48c78
    // 0xc48c68: r0 = Null
    //     0xc48c68: mov             x0, NULL
    // 0xc48c6c: LeaveFrame
    //     0xc48c6c: mov             SP, fp
    //     0xc48c70: ldp             fp, lr, [SP], #0x10
    // 0xc48c74: ret
    //     0xc48c74: ret             
    // 0xc48c78: ldr             x0, [fp, #0x18]
    // 0xc48c7c: SaveReg r0
    //     0xc48c7c: str             x0, [SP, #-8]!
    // 0xc48c80: r0 = page()
    //     0xc48c80: bl              #0xc48ae0  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::page
    // 0xc48c84: add             SP, SP, #8
    // 0xc48c88: mov             x1, x0
    // 0xc48c8c: ldr             x0, [fp, #0x18]
    // 0xc48c90: d0 = 1.000000
    //     0xc48c90: fmov            d0, #1.00000000
    // 0xc48c94: StoreField: r0->field_8b = d0
    //     0xc48c94: stur            d0, [x0, #0x8b]
    // 0xc48c98: cmp             w1, NULL
    // 0xc48c9c: b.eq            #0xc48cc8
    // 0xc48ca0: LoadField: d0 = r1->field_7
    //     0xc48ca0: ldur            d0, [x1, #7]
    // 0xc48ca4: SaveReg r0
    //     0xc48ca4: str             x0, [SP, #-8]!
    // 0xc48ca8: SaveReg d0
    //     0xc48ca8: str             d0, [SP, #-8]!
    // 0xc48cac: r0 = getPixelsFromPage()
    //     0xc48cac: bl              #0xbff700  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::getPixelsFromPage
    // 0xc48cb0: add             SP, SP, #0x10
    // 0xc48cb4: ldr             x16, [fp, #0x18]
    // 0xc48cb8: SaveReg r16
    //     0xc48cb8: str             x16, [SP, #-8]!
    // 0xc48cbc: SaveReg d0
    //     0xc48cbc: str             d0, [SP, #-8]!
    // 0xc48cc0: r0 = forcePixels()
    //     0xc48cc0: bl              #0xc144d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::forcePixels
    // 0xc48cc4: add             SP, SP, #0x10
    // 0xc48cc8: r0 = Null
    //     0xc48cc8: mov             x0, NULL
    // 0xc48ccc: LeaveFrame
    //     0xc48ccc: mov             SP, fp
    //     0xc48cd0: ldp             fp, lr, [SP], #0x10
    // 0xc48cd4: ret
    //     0xc48cd4: ret             
    // 0xc48cd8: r0 = StackOverflowSharedWithFPURegs()
    //     0xc48cd8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc48cdc: b               #0xc48c5c
  }
  _ applyViewportDimension(/* No info */) {
    // ** addr: 0xc659fc, size: 0x2ac
    // 0xc659fc: EnterFrame
    //     0xc659fc: stp             fp, lr, [SP, #-0x10]!
    //     0xc65a00: mov             fp, SP
    // 0xc65a04: AllocStack(0x20)
    //     0xc65a04: sub             SP, SP, #0x20
    // 0xc65a08: CheckStackOverflow
    //     0xc65a08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc65a0c: cmp             SP, x16
    //     0xc65a10: b.ls            #0xc65c54
    // 0xc65a14: ldr             x0, [fp, #0x18]
    // 0xc65a18: LoadField: r1 = r0->field_47
    //     0xc65a18: ldur            w1, [x0, #0x47]
    // 0xc65a1c: DecompressPointer r1
    //     0xc65a1c: add             x1, x1, HEAP, lsl #32
    // 0xc65a20: cmp             w1, NULL
    // 0xc65a24: b.eq            #0xc65a64
    // 0xc65a28: d0 = 0.000000
    //     0xc65a28: eor             v0.16b, v0.16b, v0.16b
    // 0xc65a2c: LoadField: d1 = r1->field_7
    //     0xc65a2c: ldur            d1, [x1, #7]
    // 0xc65a30: fadd            d2, d1, d0
    // 0xc65a34: fsub            d1, d2, d0
    // 0xc65a38: r1 = inline_Allocate_Double()
    //     0xc65a38: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc65a3c: add             x1, x1, #0x10
    //     0xc65a40: cmp             x2, x1
    //     0xc65a44: b.ls            #0xc65c5c
    //     0xc65a48: str             x1, [THR, #0x60]  ; THR::top
    //     0xc65a4c: sub             x1, x1, #0xf
    //     0xc65a50: mov             x2, #0xd108
    //     0xc65a54: movk            x2, #3, lsl #16
    //     0xc65a58: stur            x2, [x1, #-1]
    // 0xc65a5c: StoreField: r1->field_7 = d1
    //     0xc65a5c: stur            d1, [x1, #7]
    // 0xc65a60: b               #0xc65a68
    // 0xc65a64: r1 = Null
    //     0xc65a64: mov             x1, NULL
    // 0xc65a68: stur            x1, [fp, #-8]
    // 0xc65a6c: ldr             x16, [fp, #0x10]
    // 0xc65a70: stp             x1, x16, [SP, #-0x10]!
    // 0xc65a74: r0 = ==()
    //     0xc65a74: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0xc65a78: add             SP, SP, #0x10
    // 0xc65a7c: tbnz            w0, #4, #0xc65a90
    // 0xc65a80: r0 = true
    //     0xc65a80: add             x0, NULL, #0x20  ; true
    // 0xc65a84: LeaveFrame
    //     0xc65a84: mov             SP, fp
    //     0xc65a88: ldp             fp, lr, [SP], #0x10
    // 0xc65a8c: ret
    //     0xc65a8c: ret             
    // 0xc65a90: ldr             x0, [fp, #0x18]
    // 0xc65a94: ldr             x16, [fp, #0x10]
    // 0xc65a98: stp             x16, x0, [SP, #-0x10]!
    // 0xc65a9c: r0 = applyViewportDimension()
    //     0xc65a9c: bl              #0xc65efc  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyViewportDimension
    // 0xc65aa0: add             SP, SP, #0x10
    // 0xc65aa4: ldr             x1, [fp, #0x18]
    // 0xc65aa8: LoadField: r0 = r1->field_43
    //     0xc65aa8: ldur            w0, [x1, #0x43]
    // 0xc65aac: DecompressPointer r0
    //     0xc65aac: add             x0, x0, HEAP, lsl #32
    // 0xc65ab0: cmp             w0, NULL
    // 0xc65ab4: b.eq            #0xc65ac0
    // 0xc65ab8: mov             x2, x0
    // 0xc65abc: b               #0xc65ac4
    // 0xc65ac0: r2 = Null
    //     0xc65ac0: mov             x2, NULL
    // 0xc65ac4: stur            x2, [fp, #-0x10]
    // 0xc65ac8: cmp             w2, NULL
    // 0xc65acc: b.ne            #0xc65ad8
    // 0xc65ad0: LoadField: d0 = r1->field_7f
    //     0xc65ad0: ldur            d0, [x1, #0x7f]
    // 0xc65ad4: b               #0xc65b44
    // 0xc65ad8: ldur            x3, [fp, #-8]
    // 0xc65adc: r0 = LoadClassIdInstr(r3)
    //     0xc65adc: ldur            x0, [x3, #-1]
    //     0xc65ae0: ubfx            x0, x0, #0xc, #0x14
    // 0xc65ae4: r16 = 0.000000
    //     0xc65ae4: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xc65ae8: stp             x16, x3, [SP, #-0x10]!
    // 0xc65aec: mov             lr, x0
    // 0xc65af0: ldr             lr, [x21, lr, lsl #3]
    // 0xc65af4: blr             lr
    // 0xc65af8: add             SP, SP, #0x10
    // 0xc65afc: tbnz            w0, #4, #0xc65b1c
    // 0xc65b00: ldr             x0, [fp, #0x18]
    // 0xc65b04: LoadField: r1 = r0->field_87
    //     0xc65b04: ldur            w1, [x0, #0x87]
    // 0xc65b08: DecompressPointer r1
    //     0xc65b08: add             x1, x1, HEAP, lsl #32
    // 0xc65b0c: cmp             w1, NULL
    // 0xc65b10: b.eq            #0xc65c78
    // 0xc65b14: LoadField: d0 = r1->field_7
    //     0xc65b14: ldur            d0, [x1, #7]
    // 0xc65b18: b               #0xc65b44
    // 0xc65b1c: ldr             x0, [fp, #0x18]
    // 0xc65b20: ldur            x1, [fp, #-8]
    // 0xc65b24: cmp             w1, NULL
    // 0xc65b28: b.eq            #0xc65c7c
    // 0xc65b2c: LoadField: d0 = r1->field_7
    //     0xc65b2c: ldur            d0, [x1, #7]
    // 0xc65b30: ldur            x16, [fp, #-0x10]
    // 0xc65b34: stp             x16, x0, [SP, #-0x10]!
    // 0xc65b38: SaveReg d0
    //     0xc65b38: str             d0, [SP, #-8]!
    // 0xc65b3c: r0 = getPageFromPixels()
    //     0xc65b3c: bl              #0xbffb8c  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::getPageFromPixels
    // 0xc65b40: add             SP, SP, #0x18
    // 0xc65b44: stur            d0, [fp, #-0x18]
    // 0xc65b48: ldr             x16, [fp, #0x18]
    // 0xc65b4c: SaveReg r16
    //     0xc65b4c: str             x16, [SP, #-8]!
    // 0xc65b50: SaveReg d0
    //     0xc65b50: str             d0, [SP, #-8]!
    // 0xc65b54: r0 = getPixelsFromPage()
    //     0xc65b54: bl              #0xbff700  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::getPixelsFromPage
    // 0xc65b58: add             SP, SP, #0x10
    // 0xc65b5c: stur            d0, [fp, #-0x20]
    // 0xc65b60: ldr             x16, [fp, #0x10]
    // 0xc65b64: r30 = 0.000000
    //     0xc65b64: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xc65b68: stp             lr, x16, [SP, #-0x10]!
    // 0xc65b6c: r0 = ==()
    //     0xc65b6c: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0xc65b70: add             SP, SP, #0x10
    // 0xc65b74: tbnz            w0, #4, #0xc65ba8
    // 0xc65b78: ldur            d0, [fp, #-0x18]
    // 0xc65b7c: r0 = inline_Allocate_Double()
    //     0xc65b7c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc65b80: add             x0, x0, #0x10
    //     0xc65b84: cmp             x1, x0
    //     0xc65b88: b.ls            #0xc65c80
    //     0xc65b8c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc65b90: sub             x0, x0, #0xf
    //     0xc65b94: mov             x1, #0xd108
    //     0xc65b98: movk            x1, #3, lsl #16
    //     0xc65b9c: stur            x1, [x0, #-1]
    // 0xc65ba0: StoreField: r0->field_7 = d0
    //     0xc65ba0: stur            d0, [x0, #7]
    // 0xc65ba4: b               #0xc65bac
    // 0xc65ba8: r0 = Null
    //     0xc65ba8: mov             x0, NULL
    // 0xc65bac: ldr             x1, [fp, #0x18]
    // 0xc65bb0: ldur            d0, [fp, #-0x20]
    // 0xc65bb4: StoreField: r1->field_87 = r0
    //     0xc65bb4: stur            w0, [x1, #0x87]
    //     0xc65bb8: ldurb           w16, [x1, #-1]
    //     0xc65bbc: ldurb           w17, [x0, #-1]
    //     0xc65bc0: and             x16, x17, x16, lsr #2
    //     0xc65bc4: tst             x16, HEAP, lsr #32
    //     0xc65bc8: b.eq            #0xc65bd0
    //     0xc65bcc: bl              #0xd6826c
    // 0xc65bd0: r0 = inline_Allocate_Double()
    //     0xc65bd0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xc65bd4: add             x0, x0, #0x10
    //     0xc65bd8: cmp             x2, x0
    //     0xc65bdc: b.ls            #0xc65c90
    //     0xc65be0: str             x0, [THR, #0x60]  ; THR::top
    //     0xc65be4: sub             x0, x0, #0xf
    //     0xc65be8: mov             x2, #0xd108
    //     0xc65bec: movk            x2, #3, lsl #16
    //     0xc65bf0: stur            x2, [x0, #-1]
    // 0xc65bf4: StoreField: r0->field_7 = d0
    //     0xc65bf4: stur            d0, [x0, #7]
    // 0xc65bf8: stur            x0, [fp, #-8]
    // 0xc65bfc: ldur            x16, [fp, #-0x10]
    // 0xc65c00: stp             x16, x0, [SP, #-0x10]!
    // 0xc65c04: r0 = ==()
    //     0xc65c04: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0xc65c08: add             SP, SP, #0x10
    // 0xc65c0c: tbz             w0, #4, #0xc65c44
    // 0xc65c10: ldr             x1, [fp, #0x18]
    // 0xc65c14: ldur            x0, [fp, #-8]
    // 0xc65c18: StoreField: r1->field_43 = r0
    //     0xc65c18: stur            w0, [x1, #0x43]
    //     0xc65c1c: ldurb           w16, [x1, #-1]
    //     0xc65c20: ldurb           w17, [x0, #-1]
    //     0xc65c24: and             x16, x17, x16, lsr #2
    //     0xc65c28: tst             x16, HEAP, lsr #32
    //     0xc65c2c: b.eq            #0xc65c34
    //     0xc65c30: bl              #0xd6826c
    // 0xc65c34: r0 = false
    //     0xc65c34: add             x0, NULL, #0x30  ; false
    // 0xc65c38: LeaveFrame
    //     0xc65c38: mov             SP, fp
    //     0xc65c3c: ldp             fp, lr, [SP], #0x10
    // 0xc65c40: ret
    //     0xc65c40: ret             
    // 0xc65c44: r0 = true
    //     0xc65c44: add             x0, NULL, #0x20  ; true
    // 0xc65c48: LeaveFrame
    //     0xc65c48: mov             SP, fp
    //     0xc65c4c: ldp             fp, lr, [SP], #0x10
    // 0xc65c50: ret
    //     0xc65c50: ret             
    // 0xc65c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc65c54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc65c58: b               #0xc65a14
    // 0xc65c5c: SaveReg d1
    //     0xc65c5c: str             q1, [SP, #-0x10]!
    // 0xc65c60: SaveReg r0
    //     0xc65c60: str             x0, [SP, #-8]!
    // 0xc65c64: r0 = AllocateDouble()
    //     0xc65c64: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc65c68: mov             x1, x0
    // 0xc65c6c: RestoreReg r0
    //     0xc65c6c: ldr             x0, [SP], #8
    // 0xc65c70: RestoreReg d1
    //     0xc65c70: ldr             q1, [SP], #0x10
    // 0xc65c74: b               #0xc65a5c
    // 0xc65c78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc65c78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc65c7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc65c7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc65c80: SaveReg d0
    //     0xc65c80: str             q0, [SP, #-0x10]!
    // 0xc65c84: r0 = AllocateDouble()
    //     0xc65c84: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc65c88: RestoreReg d0
    //     0xc65c88: ldr             q0, [SP], #0x10
    // 0xc65c8c: b               #0xc65ba0
    // 0xc65c90: SaveReg d0
    //     0xc65c90: str             q0, [SP, #-0x10]!
    // 0xc65c94: SaveReg r1
    //     0xc65c94: str             x1, [SP, #-8]!
    // 0xc65c98: r0 = AllocateDouble()
    //     0xc65c98: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc65c9c: RestoreReg r1
    //     0xc65c9c: ldr             x1, [SP], #8
    // 0xc65ca0: RestoreReg d0
    //     0xc65ca0: ldr             q0, [SP], #0x10
    // 0xc65ca4: b               #0xc65bf4
  }
  _ applyContentDimensions(/* No info */) {
    // ** addr: 0xc73c48, size: 0x11c
    // 0xc73c48: EnterFrame
    //     0xc73c48: stp             fp, lr, [SP, #-0x10]!
    //     0xc73c4c: mov             fp, SP
    // 0xc73c50: AllocStack(0x8)
    //     0xc73c50: sub             SP, SP, #8
    // 0xc73c54: CheckStackOverflow
    //     0xc73c54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc73c58: cmp             SP, x16
    //     0xc73c5c: b.ls            #0xc73d48
    // 0xc73c60: ldr             x16, [fp, #0x20]
    // 0xc73c64: SaveReg r16
    //     0xc73c64: str             x16, [SP, #-8]!
    // 0xc73c68: r0 = _initialPageOffset()
    //     0xc73c68: bl              #0xbff768  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::_initialPageOffset
    // 0xc73c6c: add             SP, SP, #8
    // 0xc73c70: mov             v1.16b, v0.16b
    // 0xc73c74: ldr             d0, [fp, #0x18]
    // 0xc73c78: fadd            d2, d0, d1
    // 0xc73c7c: stur            d2, [fp, #-8]
    // 0xc73c80: ldr             x16, [fp, #0x20]
    // 0xc73c84: SaveReg r16
    //     0xc73c84: str             x16, [SP, #-8]!
    // 0xc73c88: r0 = _initialPageOffset()
    //     0xc73c88: bl              #0xbff768  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::_initialPageOffset
    // 0xc73c8c: add             SP, SP, #8
    // 0xc73c90: ldr             x0, [fp, #0x10]
    // 0xc73c94: cmp             w0, NULL
    // 0xc73c98: b.eq            #0xc73d50
    // 0xc73c9c: LoadField: d1 = r0->field_7
    //     0xc73c9c: ldur            d1, [x0, #7]
    // 0xc73ca0: fsub            d2, d1, d0
    // 0xc73ca4: ldur            d0, [fp, #-8]
    // 0xc73ca8: fcmp            d0, d2
    // 0xc73cac: b.vs            #0xc73cbc
    // 0xc73cb0: b.le            #0xc73cbc
    // 0xc73cb4: mov             v1.16b, v0.16b
    // 0xc73cb8: b               #0xc73cfc
    // 0xc73cbc: fcmp            d0, d2
    // 0xc73cc0: b.vs            #0xc73cd0
    // 0xc73cc4: b.ge            #0xc73cd0
    // 0xc73cc8: mov             v1.16b, v2.16b
    // 0xc73ccc: b               #0xc73cfc
    // 0xc73cd0: d1 = 0.000000
    //     0xc73cd0: eor             v1.16b, v1.16b, v1.16b
    // 0xc73cd4: fcmp            d0, d1
    // 0xc73cd8: b.vs            #0xc73ce8
    // 0xc73cdc: b.ne            #0xc73ce8
    // 0xc73ce0: fadd            d1, d0, d2
    // 0xc73ce4: b               #0xc73cfc
    // 0xc73ce8: fcmp            d2, d2
    // 0xc73cec: b.vc            #0xc73cf8
    // 0xc73cf0: mov             v1.16b, v2.16b
    // 0xc73cf4: b               #0xc73cfc
    // 0xc73cf8: mov             v1.16b, v0.16b
    // 0xc73cfc: r0 = inline_Allocate_Double()
    //     0xc73cfc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc73d00: add             x0, x0, #0x10
    //     0xc73d04: cmp             x1, x0
    //     0xc73d08: b.ls            #0xc73d54
    //     0xc73d0c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc73d10: sub             x0, x0, #0xf
    //     0xc73d14: mov             x1, #0xd108
    //     0xc73d18: movk            x1, #3, lsl #16
    //     0xc73d1c: stur            x1, [x0, #-1]
    // 0xc73d20: StoreField: r0->field_7 = d1
    //     0xc73d20: stur            d1, [x0, #7]
    // 0xc73d24: ldr             x16, [fp, #0x20]
    // 0xc73d28: SaveReg r16
    //     0xc73d28: str             x16, [SP, #-8]!
    // 0xc73d2c: SaveReg d0
    //     0xc73d2c: str             d0, [SP, #-8]!
    // 0xc73d30: SaveReg r0
    //     0xc73d30: str             x0, [SP, #-8]!
    // 0xc73d34: r0 = applyContentDimensions()
    //     0xc73d34: bl              #0xc742d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyContentDimensions
    // 0xc73d38: add             SP, SP, #0x18
    // 0xc73d3c: LeaveFrame
    //     0xc73d3c: mov             SP, fp
    //     0xc73d40: ldp             fp, lr, [SP], #0x10
    // 0xc73d44: ret
    //     0xc73d44: ret             
    // 0xc73d48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc73d48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc73d4c: b               #0xc73c60
    // 0xc73d50: r0 = NullErrorSharedWithFPURegs()
    //     0xc73d50: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0xc73d54: stp             q0, q1, [SP, #-0x20]!
    // 0xc73d58: r0 = AllocateDouble()
    //     0xc73d58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc73d5c: ldp             q0, q1, [SP], #0x20
    // 0xc73d60: b               #0xc73d20
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xc95d0c, size: 0x154
    // 0xc95d0c: EnterFrame
    //     0xc95d0c: stp             fp, lr, [SP, #-0x10]!
    //     0xc95d10: mov             fp, SP
    // 0xc95d14: AllocStack(0x28)
    //     0xc95d14: sub             SP, SP, #0x28
    // 0xc95d18: ldr             x0, [fp, #0x10]
    // 0xc95d1c: LoadField: r1 = r0->field_33
    //     0xc95d1c: ldur            w1, [x0, #0x33]
    // 0xc95d20: DecompressPointer r1
    //     0xc95d20: add             x1, x1, HEAP, lsl #32
    // 0xc95d24: cmp             w1, NULL
    // 0xc95d28: b.eq            #0xc95d44
    // 0xc95d2c: LoadField: r2 = r0->field_37
    //     0xc95d2c: ldur            w2, [x0, #0x37]
    // 0xc95d30: DecompressPointer r2
    //     0xc95d30: add             x2, x2, HEAP, lsl #32
    // 0xc95d34: cmp             w2, NULL
    // 0xc95d38: b.eq            #0xc95d44
    // 0xc95d3c: mov             x2, x1
    // 0xc95d40: b               #0xc95d48
    // 0xc95d44: r2 = Null
    //     0xc95d44: mov             x2, NULL
    // 0xc95d48: stur            x2, [fp, #-0x28]
    // 0xc95d4c: cmp             w1, NULL
    // 0xc95d50: b.eq            #0xc95d64
    // 0xc95d54: LoadField: r1 = r0->field_37
    //     0xc95d54: ldur            w1, [x0, #0x37]
    // 0xc95d58: DecompressPointer r1
    //     0xc95d58: add             x1, x1, HEAP, lsl #32
    // 0xc95d5c: cmp             w1, NULL
    // 0xc95d60: b.ne            #0xc95d68
    // 0xc95d64: r1 = Null
    //     0xc95d64: mov             x1, NULL
    // 0xc95d68: stur            x1, [fp, #-0x20]
    // 0xc95d6c: LoadField: r3 = r0->field_43
    //     0xc95d6c: ldur            w3, [x0, #0x43]
    // 0xc95d70: DecompressPointer r3
    //     0xc95d70: add             x3, x3, HEAP, lsl #32
    // 0xc95d74: cmp             w3, NULL
    // 0xc95d78: b.ne            #0xc95d80
    // 0xc95d7c: r3 = Null
    //     0xc95d7c: mov             x3, NULL
    // 0xc95d80: stur            x3, [fp, #-0x18]
    // 0xc95d84: LoadField: r4 = r0->field_47
    //     0xc95d84: ldur            w4, [x0, #0x47]
    // 0xc95d88: DecompressPointer r4
    //     0xc95d88: add             x4, x4, HEAP, lsl #32
    // 0xc95d8c: cmp             w4, NULL
    // 0xc95d90: b.eq            #0xc95dcc
    // 0xc95d94: d0 = 0.000000
    //     0xc95d94: eor             v0.16b, v0.16b, v0.16b
    // 0xc95d98: LoadField: d1 = r4->field_7
    //     0xc95d98: ldur            d1, [x4, #7]
    // 0xc95d9c: fadd            d2, d1, d0
    // 0xc95da0: r4 = inline_Allocate_Double()
    //     0xc95da0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xc95da4: add             x4, x4, #0x10
    //     0xc95da8: cmp             x5, x4
    //     0xc95dac: b.ls            #0xc95e38
    //     0xc95db0: str             x4, [THR, #0x60]  ; THR::top
    //     0xc95db4: sub             x4, x4, #0xf
    //     0xc95db8: mov             x5, #0xd108
    //     0xc95dbc: movk            x5, #3, lsl #16
    //     0xc95dc0: stur            x5, [x4, #-1]
    // 0xc95dc4: StoreField: r4->field_7 = d2
    //     0xc95dc4: stur            d2, [x4, #7]
    // 0xc95dc8: b               #0xc95dd0
    // 0xc95dcc: r4 = Null
    //     0xc95dcc: mov             x4, NULL
    // 0xc95dd0: stur            x4, [fp, #-0x10]
    // 0xc95dd4: LoadField: r5 = r0->field_27
    //     0xc95dd4: ldur            w5, [x0, #0x27]
    // 0xc95dd8: DecompressPointer r5
    //     0xc95dd8: add             x5, x5, HEAP, lsl #32
    // 0xc95ddc: LoadField: r0 = r5->field_b
    //     0xc95ddc: ldur            w0, [x5, #0xb]
    // 0xc95de0: DecompressPointer r0
    //     0xc95de0: add             x0, x0, HEAP, lsl #32
    // 0xc95de4: cmp             w0, NULL
    // 0xc95de8: b.eq            #0xc95e5c
    // 0xc95dec: LoadField: r5 = r0->field_b
    //     0xc95dec: ldur            w5, [x0, #0xb]
    // 0xc95df0: DecompressPointer r5
    //     0xc95df0: add             x5, x5, HEAP, lsl #32
    // 0xc95df4: stur            x5, [fp, #-8]
    // 0xc95df8: r0 = PageMetrics()
    //     0xc95df8: bl              #0x79cf00  ; AllocatePageMetricsStub -> PageMetrics (size=0x24)
    // 0xc95dfc: d0 = 1.000000
    //     0xc95dfc: fmov            d0, #1.00000000
    // 0xc95e00: StoreField: r0->field_1b = d0
    //     0xc95e00: stur            d0, [x0, #0x1b]
    // 0xc95e04: ldur            x1, [fp, #-8]
    // 0xc95e08: StoreField: r0->field_17 = r1
    //     0xc95e08: stur            w1, [x0, #0x17]
    // 0xc95e0c: ldur            x1, [fp, #-0x28]
    // 0xc95e10: StoreField: r0->field_7 = r1
    //     0xc95e10: stur            w1, [x0, #7]
    // 0xc95e14: ldur            x1, [fp, #-0x20]
    // 0xc95e18: StoreField: r0->field_b = r1
    //     0xc95e18: stur            w1, [x0, #0xb]
    // 0xc95e1c: ldur            x1, [fp, #-0x18]
    // 0xc95e20: StoreField: r0->field_f = r1
    //     0xc95e20: stur            w1, [x0, #0xf]
    // 0xc95e24: ldur            x1, [fp, #-0x10]
    // 0xc95e28: StoreField: r0->field_13 = r1
    //     0xc95e28: stur            w1, [x0, #0x13]
    // 0xc95e2c: LeaveFrame
    //     0xc95e2c: mov             SP, fp
    //     0xc95e30: ldp             fp, lr, [SP], #0x10
    // 0xc95e34: ret
    //     0xc95e34: ret             
    // 0xc95e38: SaveReg d2
    //     0xc95e38: str             q2, [SP, #-0x10]!
    // 0xc95e3c: stp             x2, x3, [SP, #-0x10]!
    // 0xc95e40: stp             x0, x1, [SP, #-0x10]!
    // 0xc95e44: r0 = AllocateDouble()
    //     0xc95e44: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc95e48: mov             x4, x0
    // 0xc95e4c: ldp             x0, x1, [SP], #0x10
    // 0xc95e50: ldp             x2, x3, [SP], #0x10
    // 0xc95e54: RestoreReg d2
    //     0xc95e54: ldr             q2, [SP], #0x10
    // 0xc95e58: b               #0xc95dc4
    // 0xc95e5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc95e5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ viewportDimension(/* No info */) {
    // ** addr: 0xcaf454, size: 0x38
    // 0xcaf454: EnterFrame
    //     0xcaf454: stp             fp, lr, [SP, #-0x10]!
    //     0xcaf458: mov             fp, SP
    // 0xcaf45c: d1 = 0.000000
    //     0xcaf45c: eor             v1.16b, v1.16b, v1.16b
    // 0xcaf460: ldr             x0, [fp, #0x10]
    // 0xcaf464: LoadField: r1 = r0->field_47
    //     0xcaf464: ldur            w1, [x0, #0x47]
    // 0xcaf468: DecompressPointer r1
    //     0xcaf468: add             x1, x1, HEAP, lsl #32
    // 0xcaf46c: cmp             w1, NULL
    // 0xcaf470: b.eq            #0xcaf488
    // 0xcaf474: LoadField: d2 = r1->field_7
    //     0xcaf474: ldur            d2, [x1, #7]
    // 0xcaf478: fadd            d0, d2, d1
    // 0xcaf47c: LeaveFrame
    //     0xcaf47c: mov             SP, fp
    //     0xcaf480: ldp             fp, lr, [SP], #0x10
    // 0xcaf484: ret
    //     0xcaf484: ret             
    // 0xcaf488: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcaf488: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 4859, size: 0x58, field offset: 0x38
class ExtendedPageController extends ScrollController {

  _ createScrollPosition(/* No info */) {
    // ** addr: 0xbebba0, size: 0x68
    // 0xbebba0: EnterFrame
    //     0xbebba0: stp             fp, lr, [SP, #-0x10]!
    //     0xbebba4: mov             fp, SP
    // 0xbebba8: AllocStack(0x10)
    //     0xbebba8: sub             SP, SP, #0x10
    // 0xbebbac: CheckStackOverflow
    //     0xbebbac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbebbb0: cmp             SP, x16
    //     0xbebbb4: b.ls            #0xbebc00
    // 0xbebbb8: ldr             x0, [fp, #0x28]
    // 0xbebbbc: LoadField: r1 = r0->field_3b
    //     0xbebbbc: ldur            x1, [x0, #0x3b]
    // 0xbebbc0: stur            x1, [fp, #-8]
    // 0xbebbc4: r0 = ExtendedPagePosition()
    //     0xbebbc4: bl              #0xbebc9c  ; AllocateExtendedPagePositionStub -> ExtendedPagePosition (size=0x9c)
    // 0xbebbc8: stur            x0, [fp, #-0x10]
    // 0xbebbcc: ldr             x16, [fp, #0x18]
    // 0xbebbd0: stp             x16, x0, [SP, #-0x10]!
    // 0xbebbd4: ldur            x1, [fp, #-8]
    // 0xbebbd8: ldr             x16, [fp, #0x10]
    // 0xbebbdc: stp             x16, x1, [SP, #-0x10]!
    // 0xbebbe0: ldr             x16, [fp, #0x20]
    // 0xbebbe4: SaveReg r16
    //     0xbebbe4: str             x16, [SP, #-8]!
    // 0xbebbe8: r0 = ExtendedPagePosition()
    //     0xbebbe8: bl              #0xbebc08  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::ExtendedPagePosition
    // 0xbebbec: add             SP, SP, #0x28
    // 0xbebbf0: ldur            x0, [fp, #-0x10]
    // 0xbebbf4: LeaveFrame
    //     0xbebbf4: mov             SP, fp
    //     0xbebbf8: ldp             fp, lr, [SP], #0x10
    // 0xbebbfc: ret
    //     0xbebbfc: ret             
    // 0xbebc00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbebc00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbebc04: b               #0xbebbb8
  }
  _ attach(/* No info */) {
    // ** addr: 0xc489bc, size: 0x9c
    // 0xc489bc: EnterFrame
    //     0xc489bc: stp             fp, lr, [SP, #-0x10]!
    //     0xc489c0: mov             fp, SP
    // 0xc489c4: CheckStackOverflow
    //     0xc489c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc489c8: cmp             SP, x16
    //     0xc489cc: b.ls            #0xc48a50
    // 0xc489d0: ldr             x16, [fp, #0x18]
    // 0xc489d4: ldr             lr, [fp, #0x10]
    // 0xc489d8: stp             lr, x16, [SP, #-0x10]!
    // 0xc489dc: r0 = attach()
    //     0xc489dc: bl              #0xc49460  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::attach
    // 0xc489e0: add             SP, SP, #0x10
    // 0xc489e4: ldr             x0, [fp, #0x10]
    // 0xc489e8: r2 = Null
    //     0xc489e8: mov             x2, NULL
    // 0xc489ec: r1 = Null
    //     0xc489ec: mov             x1, NULL
    // 0xc489f0: r4 = LoadClassIdInstr(r0)
    //     0xc489f0: ldur            x4, [x0, #-1]
    //     0xc489f4: ubfx            x4, x4, #0xc, #0x14
    // 0xc489f8: r17 = 4850
    //     0xc489f8: mov             x17, #0x12f2
    // 0xc489fc: cmp             x4, x17
    // 0xc48a00: b.eq            #0xc48a18
    // 0xc48a04: r8 = ExtendedPagePosition
    //     0xc48a04: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4c540] Type: ExtendedPagePosition
    //     0xc48a08: ldr             x8, [x8, #0x540]
    // 0xc48a0c: r3 = Null
    //     0xc48a0c: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c548] Null
    //     0xc48a10: ldr             x3, [x3, #0x548]
    // 0xc48a14: r0 = DefaultTypeTest()
    //     0xc48a14: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xc48a18: ldr             x16, [fp, #0x10]
    // 0xc48a1c: SaveReg r16
    //     0xc48a1c: str             x16, [SP, #-8]!
    // 0xc48a20: d0 = 1.000000
    //     0xc48a20: fmov            d0, #1.00000000
    // 0xc48a24: SaveReg d0
    //     0xc48a24: str             d0, [SP, #-8]!
    // 0xc48a28: r0 = viewportFraction=()
    //     0xc48a28: bl              #0xc48c44  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::viewportFraction=
    // 0xc48a2c: add             SP, SP, #0x10
    // 0xc48a30: ldr             x16, [fp, #0x10]
    // 0xc48a34: stp             xzr, x16, [SP, #-0x10]!
    // 0xc48a38: r0 = pageSpacing=()
    //     0xc48a38: bl              #0xc48a58  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::pageSpacing=
    // 0xc48a3c: add             SP, SP, #0x10
    // 0xc48a40: r0 = Null
    //     0xc48a40: mov             x0, NULL
    // 0xc48a44: LeaveFrame
    //     0xc48a44: mov             SP, fp
    //     0xc48a48: ldp             fp, lr, [SP], #0x10
    // 0xc48a4c: ret
    //     0xc48a4c: ret             
    // 0xc48a50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc48a50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc48a54: b               #0xc489d0
  }
  _ jumpToPage(/* No info */) {
    // ** addr: 0xd63258, size: 0x16c
    // 0xd63258: EnterFrame
    //     0xd63258: stp             fp, lr, [SP, #-0x10]!
    //     0xd6325c: mov             fp, SP
    // 0xd63260: AllocStack(0x8)
    //     0xd63260: sub             SP, SP, #8
    // 0xd63264: CheckStackOverflow
    //     0xd63264: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd63268: cmp             SP, x16
    //     0xd6326c: b.ls            #0xd633ac
    // 0xd63270: ldr             x0, [fp, #0x18]
    // 0xd63274: LoadField: r1 = r0->field_33
    //     0xd63274: ldur            w1, [x0, #0x33]
    // 0xd63278: DecompressPointer r1
    //     0xd63278: add             x1, x1, HEAP, lsl #32
    // 0xd6327c: SaveReg r1
    //     0xd6327c: str             x1, [SP, #-8]!
    // 0xd63280: r0 = single()
    //     0xd63280: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0xd63284: add             SP, SP, #8
    // 0xd63288: mov             x3, x0
    // 0xd6328c: r2 = Null
    //     0xd6328c: mov             x2, NULL
    // 0xd63290: r1 = Null
    //     0xd63290: mov             x1, NULL
    // 0xd63294: stur            x3, [fp, #-8]
    // 0xd63298: r4 = LoadClassIdInstr(r0)
    //     0xd63298: ldur            x4, [x0, #-1]
    //     0xd6329c: ubfx            x4, x4, #0xc, #0x14
    // 0xd632a0: r17 = 4850
    //     0xd632a0: mov             x17, #0x12f2
    // 0xd632a4: cmp             x4, x17
    // 0xd632a8: b.eq            #0xd632c0
    // 0xd632ac: r8 = ExtendedPagePosition
    //     0xd632ac: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4c540] Type: ExtendedPagePosition
    //     0xd632b0: ldr             x8, [x8, #0x540]
    // 0xd632b4: r3 = Null
    //     0xd632b4: add             x3, PP, #0x54, lsl #12  ; [pp+0x546c0] Null
    //     0xd632b8: ldr             x3, [x3, #0x6c0]
    // 0xd632bc: r0 = DefaultTypeTest()
    //     0xd632bc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xd632c0: ldur            x2, [fp, #-8]
    // 0xd632c4: LoadField: r0 = r2->field_87
    //     0xd632c4: ldur            w0, [x2, #0x87]
    // 0xd632c8: DecompressPointer r0
    //     0xd632c8: add             x0, x0, HEAP, lsl #32
    // 0xd632cc: cmp             w0, NULL
    // 0xd632d0: b.eq            #0xd63328
    // 0xd632d4: ldr             x3, [fp, #0x10]
    // 0xd632d8: r0 = BoxInt64Instr(r3)
    //     0xd632d8: sbfiz           x0, x3, #1, #0x1f
    //     0xd632dc: cmp             x3, x0, asr #1
    //     0xd632e0: b.eq            #0xd632ec
    //     0xd632e4: bl              #0xd69bb8
    //     0xd632e8: stur            x3, [x0, #7]
    // 0xd632ec: stp             x0, NULL, [SP, #-0x10]!
    // 0xd632f0: r0 = _Double.fromInteger()
    //     0xd632f0: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xd632f4: add             SP, SP, #0x10
    // 0xd632f8: ldur            x2, [fp, #-8]
    // 0xd632fc: StoreField: r2->field_87 = r0
    //     0xd632fc: stur            w0, [x2, #0x87]
    //     0xd63300: ldurb           w16, [x2, #-1]
    //     0xd63304: ldurb           w17, [x0, #-1]
    //     0xd63308: and             x16, x17, x16, lsr #2
    //     0xd6330c: tst             x16, HEAP, lsr #32
    //     0xd63310: b.eq            #0xd63318
    //     0xd63314: bl              #0xd6828c
    // 0xd63318: r0 = Null
    //     0xd63318: mov             x0, NULL
    // 0xd6331c: LeaveFrame
    //     0xd6331c: mov             SP, fp
    //     0xd63320: ldp             fp, lr, [SP], #0x10
    // 0xd63324: ret
    //     0xd63324: ret             
    // 0xd63328: ldr             x3, [fp, #0x10]
    // 0xd6332c: r0 = BoxInt64Instr(r3)
    //     0xd6332c: sbfiz           x0, x3, #1, #0x1f
    //     0xd63330: cmp             x3, x0, asr #1
    //     0xd63334: b.eq            #0xd63340
    //     0xd63338: bl              #0xd69bb8
    //     0xd6333c: stur            x3, [x0, #7]
    // 0xd63340: stp             x0, NULL, [SP, #-0x10]!
    // 0xd63344: r0 = _Double.fromInteger()
    //     0xd63344: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xd63348: add             SP, SP, #0x10
    // 0xd6334c: LoadField: d0 = r0->field_7
    //     0xd6334c: ldur            d0, [x0, #7]
    // 0xd63350: ldur            x16, [fp, #-8]
    // 0xd63354: SaveReg r16
    //     0xd63354: str             x16, [SP, #-8]!
    // 0xd63358: SaveReg d0
    //     0xd63358: str             d0, [SP, #-8]!
    // 0xd6335c: r0 = getPixelsFromPage()
    //     0xd6335c: bl              #0xbff700  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::getPixelsFromPage
    // 0xd63360: add             SP, SP, #0x10
    // 0xd63364: r0 = inline_Allocate_Double()
    //     0xd63364: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd63368: add             x0, x0, #0x10
    //     0xd6336c: cmp             x1, x0
    //     0xd63370: b.ls            #0xd633b4
    //     0xd63374: str             x0, [THR, #0x60]  ; THR::top
    //     0xd63378: sub             x0, x0, #0xf
    //     0xd6337c: mov             x1, #0xd108
    //     0xd63380: movk            x1, #3, lsl #16
    //     0xd63384: stur            x1, [x0, #-1]
    // 0xd63388: StoreField: r0->field_7 = d0
    //     0xd63388: stur            d0, [x0, #7]
    // 0xd6338c: ldur            x16, [fp, #-8]
    // 0xd63390: stp             x0, x16, [SP, #-0x10]!
    // 0xd63394: r0 = jumpTo()
    //     0xd63394: bl              #0xc51528  ; [package:flutter/src/widgets/scroll_position_with_single_context.dart] ScrollPositionWithSingleContext::jumpTo
    // 0xd63398: add             SP, SP, #0x10
    // 0xd6339c: r0 = Null
    //     0xd6339c: mov             x0, NULL
    // 0xd633a0: LeaveFrame
    //     0xd633a0: mov             SP, fp
    //     0xd633a4: ldp             fp, lr, [SP], #0x10
    // 0xd633a8: ret
    //     0xd633a8: ret             
    // 0xd633ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd633ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd633b0: b               #0xd63270
    // 0xd633b4: SaveReg d0
    //     0xd633b4: str             q0, [SP, #-0x10]!
    // 0xd633b8: r0 = AllocateDouble()
    //     0xd633b8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xd633bc: RestoreReg d0
    //     0xd633bc: ldr             q0, [SP], #0x10
    // 0xd633c0: b               #0xd63388
  }
  get _ page(/* No info */) {
    // ** addr: 0xd633c4, size: 0x8c
    // 0xd633c4: EnterFrame
    //     0xd633c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd633c8: mov             fp, SP
    // 0xd633cc: AllocStack(0x8)
    //     0xd633cc: sub             SP, SP, #8
    // 0xd633d0: CheckStackOverflow
    //     0xd633d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd633d4: cmp             SP, x16
    //     0xd633d8: b.ls            #0xd63448
    // 0xd633dc: ldr             x0, [fp, #0x10]
    // 0xd633e0: LoadField: r1 = r0->field_33
    //     0xd633e0: ldur            w1, [x0, #0x33]
    // 0xd633e4: DecompressPointer r1
    //     0xd633e4: add             x1, x1, HEAP, lsl #32
    // 0xd633e8: SaveReg r1
    //     0xd633e8: str             x1, [SP, #-8]!
    // 0xd633ec: r0 = single()
    //     0xd633ec: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0xd633f0: add             SP, SP, #8
    // 0xd633f4: mov             x3, x0
    // 0xd633f8: r2 = Null
    //     0xd633f8: mov             x2, NULL
    // 0xd633fc: r1 = Null
    //     0xd633fc: mov             x1, NULL
    // 0xd63400: stur            x3, [fp, #-8]
    // 0xd63404: r4 = LoadClassIdInstr(r0)
    //     0xd63404: ldur            x4, [x0, #-1]
    //     0xd63408: ubfx            x4, x4, #0xc, #0x14
    // 0xd6340c: r17 = 4850
    //     0xd6340c: mov             x17, #0x12f2
    // 0xd63410: cmp             x4, x17
    // 0xd63414: b.eq            #0xd6342c
    // 0xd63418: r8 = ExtendedPagePosition
    //     0xd63418: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4c540] Type: ExtendedPagePosition
    //     0xd6341c: ldr             x8, [x8, #0x540]
    // 0xd63420: r3 = Null
    //     0xd63420: add             x3, PP, #0x54, lsl #12  ; [pp+0x546d0] Null
    //     0xd63424: ldr             x3, [x3, #0x6d0]
    // 0xd63428: r0 = DefaultTypeTest()
    //     0xd63428: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xd6342c: ldur            x16, [fp, #-8]
    // 0xd63430: SaveReg r16
    //     0xd63430: str             x16, [SP, #-8]!
    // 0xd63434: r0 = page()
    //     0xd63434: bl              #0xc48ae0  ; [package:extended_image/src/gesture/page_view/widgets/page_controller.dart] ExtendedPagePosition::page
    // 0xd63438: add             SP, SP, #8
    // 0xd6343c: LeaveFrame
    //     0xd6343c: mov             SP, fp
    //     0xd63440: ldp             fp, lr, [SP], #0x10
    // 0xd63444: ret
    //     0xd63444: ret             
    // 0xd63448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd63448: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6344c: b               #0xd633dc
  }
}

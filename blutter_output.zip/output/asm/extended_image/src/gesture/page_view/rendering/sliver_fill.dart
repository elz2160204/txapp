// lib: , url: package:extended_image/src/gesture/page_view/rendering/sliver_fill.dart

// class id: 1048934, size: 0x8
class :: {
}

// class id: 2591, size: 0x7c, field offset: 0x6c
class ExtendedRenderSliverFillViewport extends RenderSliverFixedExtentBoxAdaptor {

  _ performLayout(/* No info */) {
    // ** addr: 0x676a80, size: 0x1024
    // 0x676a80: EnterFrame
    //     0x676a80: stp             fp, lr, [SP, #-0x10]!
    //     0x676a84: mov             fp, SP
    // 0x676a88: AllocStack(0x78)
    //     0x676a88: sub             SP, SP, #0x78
    // 0x676a8c: CheckStackOverflow
    //     0x676a8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x676a90: cmp             SP, x16
    //     0x676a94: b.ls            #0x6778d0
    // 0x676a98: ldr             x3, [fp, #0x10]
    // 0x676a9c: LoadField: r4 = r3->field_27
    //     0x676a9c: ldur            w4, [x3, #0x27]
    // 0x676aa0: DecompressPointer r4
    //     0x676aa0: add             x4, x4, HEAP, lsl #32
    // 0x676aa4: stur            x4, [fp, #-8]
    // 0x676aa8: cmp             w4, NULL
    // 0x676aac: b.eq            #0x6778b0
    // 0x676ab0: mov             x0, x4
    // 0x676ab4: r2 = Null
    //     0x676ab4: mov             x2, NULL
    // 0x676ab8: r1 = Null
    //     0x676ab8: mov             x1, NULL
    // 0x676abc: r4 = LoadClassIdInstr(r0)
    //     0x676abc: ldur            x4, [x0, #-1]
    //     0x676ac0: ubfx            x4, x4, #0xc, #0x14
    // 0x676ac4: cmp             x4, #0x80c
    // 0x676ac8: b.eq            #0x676ae0
    // 0x676acc: r8 = SliverConstraints
    //     0x676acc: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x676ad0: ldr             x8, [x8, #0x5a8]
    // 0x676ad4: r3 = Null
    //     0x676ad4: add             x3, PP, #0x57, lsl #12  ; [pp+0x573b0] Null
    //     0x676ad8: ldr             x3, [x3, #0x3b0]
    // 0x676adc: r0 = DefaultTypeTest()
    //     0x676adc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x676ae0: ldr             x0, [fp, #0x10]
    // 0x676ae4: LoadField: r1 = r0->field_63
    //     0x676ae4: ldur            w1, [x0, #0x63]
    // 0x676ae8: DecompressPointer r1
    //     0x676ae8: add             x1, x1, HEAP, lsl #32
    // 0x676aec: stur            x1, [fp, #-0x10]
    // 0x676af0: r2 = false
    //     0x676af0: add             x2, NULL, #0x30  ; false
    // 0x676af4: StoreField: r1->field_53 = r2
    //     0x676af4: stur            w2, [x1, #0x53]
    // 0x676af8: ldur            x3, [fp, #-8]
    // 0x676afc: LoadField: d0 = r3->field_3f
    //     0x676afc: ldur            d0, [x3, #0x3f]
    // 0x676b00: d1 = 0.000000
    //     0x676b00: eor             v1.16b, v1.16b, v1.16b
    // 0x676b04: fadd            d2, d0, d1
    // 0x676b08: stur            d2, [fp, #-0x68]
    // 0x676b0c: LoadField: d3 = r3->field_13
    //     0x676b0c: ldur            d3, [x3, #0x13]
    // 0x676b10: stur            d3, [fp, #-0x60]
    // 0x676b14: LoadField: d4 = r3->field_47
    //     0x676b14: ldur            d4, [x3, #0x47]
    // 0x676b18: fadd            d5, d3, d4
    // 0x676b1c: stur            d5, [fp, #-0x58]
    // 0x676b20: LoadField: d4 = r3->field_4f
    //     0x676b20: ldur            d4, [x3, #0x4f]
    // 0x676b24: fadd            d6, d5, d4
    // 0x676b28: stur            d6, [fp, #-0x50]
    // 0x676b2c: r4 = inline_Allocate_Double()
    //     0x676b2c: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x676b30: add             x4, x4, #0x10
    //     0x676b34: cmp             x5, x4
    //     0x676b38: b.ls            #0x6778d8
    //     0x676b3c: str             x4, [THR, #0x60]  ; THR::top
    //     0x676b40: sub             x4, x4, #0xf
    //     0x676b44: mov             x5, #0xd108
    //     0x676b48: movk            x5, #3, lsl #16
    //     0x676b4c: stur            x5, [x4, #-1]
    // 0x676b50: StoreField: r4->field_7 = d0
    //     0x676b50: stur            d0, [x4, #7]
    // 0x676b54: stp             x4, x3, [SP, #-0x10]!
    // 0x676b58: SaveReg r4
    //     0x676b58: str             x4, [SP, #-8]!
    // 0x676b5c: r4 = const [0, 0x3, 0x3, 0x1, maxExtent, 0x2, minExtent, 0x1, null]
    //     0x676b5c: add             x4, PP, #0x40, lsl #12  ; [pp+0x40d60] List(9) [0, 0x3, 0x3, 0x1, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0x676b60: ldr             x4, [x4, #0xd60]
    // 0x676b64: r0 = asBoxConstraints()
    //     0x676b64: bl              #0x67a528  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0x676b68: add             SP, SP, #0x18
    // 0x676b6c: ldur            d0, [fp, #-0x58]
    // 0x676b70: stur            x0, [fp, #-0x18]
    // 0x676b74: r1 = inline_Allocate_Double()
    //     0x676b74: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x676b78: add             x1, x1, #0x10
    //     0x676b7c: cmp             x2, x1
    //     0x676b80: b.ls            #0x67790c
    //     0x676b84: str             x1, [THR, #0x60]  ; THR::top
    //     0x676b88: sub             x1, x1, #0xf
    //     0x676b8c: mov             x2, #0xd108
    //     0x676b90: movk            x2, #3, lsl #16
    //     0x676b94: stur            x2, [x1, #-1]
    // 0x676b98: StoreField: r1->field_7 = d0
    //     0x676b98: stur            d0, [x1, #7]
    // 0x676b9c: ldr             x16, [fp, #0x10]
    // 0x676ba0: stp             x1, x16, [SP, #-0x10]!
    // 0x676ba4: ldur            d0, [fp, #-0x68]
    // 0x676ba8: SaveReg d0
    //     0x676ba8: str             d0, [SP, #-8]!
    // 0x676bac: r0 = getMinChildIndexForScrollOffset()
    //     0x676bac: bl              #0x67a3a8  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::getMinChildIndexForScrollOffset
    // 0x676bb0: add             SP, SP, #0x18
    // 0x676bb4: ldur            d0, [fp, #-0x50]
    // 0x676bb8: stur            x0, [fp, #-0x20]
    // 0x676bbc: mov             x1, v0.d[0]
    // 0x676bc0: and             x1, x1, #0x7fffffffffffffff
    // 0x676bc4: r17 = 9218868437227405312
    //     0x676bc4: mov             x17, #0x7ff0000000000000
    // 0x676bc8: cmp             x1, x17
    // 0x676bcc: b.eq            #0x676c38
    // 0x676bd0: fcmp            d0, d0
    // 0x676bd4: b.vs            #0x676c38
    // 0x676bd8: ldur            d1, [fp, #-0x68]
    // 0x676bdc: r1 = inline_Allocate_Double()
    //     0x676bdc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x676be0: add             x1, x1, #0x10
    //     0x676be4: cmp             x2, x1
    //     0x676be8: b.ls            #0x677928
    //     0x676bec: str             x1, [THR, #0x60]  ; THR::top
    //     0x676bf0: sub             x1, x1, #0xf
    //     0x676bf4: mov             x2, #0xd108
    //     0x676bf8: movk            x2, #3, lsl #16
    //     0x676bfc: stur            x2, [x1, #-1]
    // 0x676c00: StoreField: r1->field_7 = d0
    //     0x676c00: stur            d0, [x1, #7]
    // 0x676c04: ldr             x16, [fp, #0x10]
    // 0x676c08: stp             x1, x16, [SP, #-0x10]!
    // 0x676c0c: SaveReg d1
    //     0x676c0c: str             d1, [SP, #-8]!
    // 0x676c10: r0 = getMaxChildIndexForScrollOffset()
    //     0x676c10: bl              #0x67a178  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::getMaxChildIndexForScrollOffset
    // 0x676c14: add             SP, SP, #0x18
    // 0x676c18: mov             x2, x0
    // 0x676c1c: r0 = BoxInt64Instr(r2)
    //     0x676c1c: sbfiz           x0, x2, #1, #0x1f
    //     0x676c20: cmp             x2, x0, asr #1
    //     0x676c24: b.eq            #0x676c30
    //     0x676c28: bl              #0xd69bb8
    //     0x676c2c: stur            x2, [x0, #7]
    // 0x676c30: mov             x1, x0
    // 0x676c34: b               #0x676c3c
    // 0x676c38: r1 = Null
    //     0x676c38: mov             x1, NULL
    // 0x676c3c: ldr             x0, [fp, #0x10]
    // 0x676c40: stur            x1, [fp, #-0x28]
    // 0x676c44: LoadField: r2 = r0->field_5b
    //     0x676c44: ldur            w2, [x0, #0x5b]
    // 0x676c48: DecompressPointer r2
    //     0x676c48: add             x2, x2, HEAP, lsl #32
    // 0x676c4c: cmp             w2, NULL
    // 0x676c50: b.eq            #0x676cd0
    // 0x676c54: ldur            x2, [fp, #-0x20]
    // 0x676c58: stp             x2, x0, [SP, #-0x10]!
    // 0x676c5c: r0 = _calculateLeadingGarbage()
    //     0x676c5c: bl              #0x67a088  ; [package:extended_image/src/gesture/page_view/rendering/sliver_fill.dart] ExtendedRenderSliverFillViewport::_calculateLeadingGarbage
    // 0x676c60: add             SP, SP, #0x10
    // 0x676c64: mov             x1, x0
    // 0x676c68: ldur            x0, [fp, #-0x28]
    // 0x676c6c: stur            x1, [fp, #-0x30]
    // 0x676c70: cmp             w0, NULL
    // 0x676c74: b.eq            #0x676c9c
    // 0x676c78: r2 = LoadInt32Instr(r0)
    //     0x676c78: sbfx            x2, x0, #1, #0x1f
    //     0x676c7c: tbz             w0, #0, #0x676c84
    //     0x676c80: ldur            x2, [x0, #7]
    // 0x676c84: ldr             x16, [fp, #0x10]
    // 0x676c88: stp             x2, x16, [SP, #-0x10]!
    // 0x676c8c: r0 = _calculateTrailingGarbage()
    //     0x676c8c: bl              #0x679f98  ; [package:extended_image/src/gesture/page_view/rendering/sliver_fill.dart] ExtendedRenderSliverFillViewport::_calculateTrailingGarbage
    // 0x676c90: add             SP, SP, #0x10
    // 0x676c94: mov             x3, x0
    // 0x676c98: b               #0x676ca0
    // 0x676c9c: r3 = 0
    //     0x676c9c: mov             x3, #0
    // 0x676ca0: ldur            x2, [fp, #-0x30]
    // 0x676ca4: r0 = BoxInt64Instr(r2)
    //     0x676ca4: sbfiz           x0, x2, #1, #0x1f
    //     0x676ca8: cmp             x2, x0, asr #1
    //     0x676cac: b.eq            #0x676cb8
    //     0x676cb0: bl              #0xd69bb8
    //     0x676cb4: stur            x2, [x0, #7]
    // 0x676cb8: ldr             x16, [fp, #0x10]
    // 0x676cbc: stp             x0, x16, [SP, #-0x10]!
    // 0x676cc0: SaveReg r3
    //     0x676cc0: str             x3, [SP, #-8]!
    // 0x676cc4: r0 = collectGarbage()
    //     0x676cc4: bl              #0x6797bc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0x676cc8: add             SP, SP, #0x18
    // 0x676ccc: b               #0x676ce4
    // 0x676cd0: ldr             x16, [fp, #0x10]
    // 0x676cd4: stp             xzr, x16, [SP, #-0x10]!
    // 0x676cd8: SaveReg rZR
    //     0x676cd8: str             xzr, [SP, #-8]!
    // 0x676cdc: r0 = collectGarbage()
    //     0x676cdc: bl              #0x6797bc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0x676ce0: add             SP, SP, #0x18
    // 0x676ce4: ldr             x2, [fp, #0x10]
    // 0x676ce8: LoadField: r0 = r2->field_5b
    //     0x676ce8: ldur            w0, [x2, #0x5b]
    // 0x676cec: DecompressPointer r0
    //     0x676cec: add             x0, x0, HEAP, lsl #32
    // 0x676cf0: cmp             w0, NULL
    // 0x676cf4: b.ne            #0x676e3c
    // 0x676cf8: ldur            d0, [fp, #-0x68]
    // 0x676cfc: ldur            x3, [fp, #-0x20]
    // 0x676d00: scvtf           d1, x3
    // 0x676d04: fmul            d2, d0, d1
    // 0x676d08: r0 = BoxInt64Instr(r3)
    //     0x676d08: sbfiz           x0, x3, #1, #0x1f
    //     0x676d0c: cmp             x3, x0, asr #1
    //     0x676d10: b.eq            #0x676d1c
    //     0x676d14: bl              #0xd69c6c
    //     0x676d18: stur            x3, [x0, #7]
    // 0x676d1c: r1 = inline_Allocate_Double()
    //     0x676d1c: ldp             x1, x4, [THR, #0x60]  ; THR::top
    //     0x676d20: add             x1, x1, #0x10
    //     0x676d24: cmp             x4, x1
    //     0x676d28: b.ls            #0x677944
    //     0x676d2c: str             x1, [THR, #0x60]  ; THR::top
    //     0x676d30: sub             x1, x1, #0xf
    //     0x676d34: mov             x4, #0xd108
    //     0x676d38: movk            x4, #3, lsl #16
    //     0x676d3c: stur            x4, [x1, #-1]
    // 0x676d40: StoreField: r1->field_7 = d2
    //     0x676d40: stur            d2, [x1, #7]
    // 0x676d44: stp             x0, x2, [SP, #-0x10]!
    // 0x676d48: SaveReg r1
    //     0x676d48: str             x1, [SP, #-8]!
    // 0x676d4c: r4 = const [0, 0x3, 0x3, 0x1, index, 0x1, layoutOffset, 0x2, null]
    //     0x676d4c: add             x4, PP, #0x43, lsl #12  ; [pp+0x43530] List(9) [0, 0x3, 0x3, 0x1, "index", 0x1, "layoutOffset", 0x2, Null]
    //     0x676d50: ldr             x4, [x4, #0x530]
    // 0x676d54: r0 = addInitialChild()
    //     0x676d54: bl              #0x6795e8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::addInitialChild
    // 0x676d58: add             SP, SP, #0x18
    // 0x676d5c: tbz             w0, #4, #0x676e24
    // 0x676d60: ldur            x3, [fp, #-0x20]
    // 0x676d64: cmp             x3, #0
    // 0x676d68: b.gt            #0x676d74
    // 0x676d6c: d0 = 0.000000
    //     0x676d6c: eor             v0.16b, v0.16b, v0.16b
    // 0x676d70: b               #0x676d8c
    // 0x676d74: ldur            d0, [fp, #-0x68]
    // 0x676d78: ldr             x16, [fp, #0x10]
    // 0x676d7c: SaveReg r16
    //     0x676d7c: str             x16, [SP, #-8]!
    // 0x676d80: SaveReg d0
    //     0x676d80: str             d0, [SP, #-8]!
    // 0x676d84: r0 = computeMaxScrollOffset()
    //     0x676d84: bl              #0x679340  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::computeMaxScrollOffset
    // 0x676d88: add             SP, SP, #0x10
    // 0x676d8c: ldr             x0, [fp, #0x10]
    // 0x676d90: stur            d0, [fp, #-0x50]
    // 0x676d94: r0 = SliverGeometry()
    //     0x676d94: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x676d98: ldur            d0, [fp, #-0x50]
    // 0x676d9c: StoreField: r0->field_7 = d0
    //     0x676d9c: stur            d0, [x0, #7]
    // 0x676da0: d1 = 0.000000
    //     0x676da0: eor             v1.16b, v1.16b, v1.16b
    // 0x676da4: StoreField: r0->field_17 = d1
    //     0x676da4: stur            d1, [x0, #0x17]
    // 0x676da8: StoreField: r0->field_f = d1
    //     0x676da8: stur            d1, [x0, #0xf]
    // 0x676dac: StoreField: r0->field_27 = d0
    //     0x676dac: stur            d0, [x0, #0x27]
    // 0x676db0: StoreField: r0->field_2f = d1
    //     0x676db0: stur            d1, [x0, #0x2f]
    // 0x676db4: r4 = false
    //     0x676db4: add             x4, NULL, #0x30  ; false
    // 0x676db8: StoreField: r0->field_43 = r4
    //     0x676db8: stur            w4, [x0, #0x43]
    // 0x676dbc: StoreField: r0->field_1f = d1
    //     0x676dbc: stur            d1, [x0, #0x1f]
    // 0x676dc0: StoreField: r0->field_37 = d1
    //     0x676dc0: stur            d1, [x0, #0x37]
    // 0x676dc4: StoreField: r0->field_4b = d1
    //     0x676dc4: stur            d1, [x0, #0x4b]
    // 0x676dc8: fcmp            d1, d1
    // 0x676dcc: b.vs            #0x676dd4
    // 0x676dd0: b.gt            #0x676ddc
    // 0x676dd4: r1 = false
    //     0x676dd4: add             x1, NULL, #0x30  ; false
    // 0x676dd8: b               #0x676de0
    // 0x676ddc: r1 = true
    //     0x676ddc: add             x1, NULL, #0x20  ; true
    // 0x676de0: StoreField: r0->field_3f = r1
    //     0x676de0: stur            w1, [x0, #0x3f]
    // 0x676de4: ldr             x5, [fp, #0x10]
    // 0x676de8: StoreField: r5->field_4f = r0
    //     0x676de8: stur            w0, [x5, #0x4f]
    //     0x676dec: ldurb           w16, [x5, #-1]
    //     0x676df0: ldurb           w17, [x0, #-1]
    //     0x676df4: and             x16, x17, x16, lsr #2
    //     0x676df8: tst             x16, HEAP, lsr #32
    //     0x676dfc: b.eq            #0x676e04
    //     0x676e00: bl              #0xd682ec
    // 0x676e04: ldur            x16, [fp, #-0x10]
    // 0x676e08: SaveReg r16
    //     0x676e08: str             x16, [SP, #-8]!
    // 0x676e0c: r0 = didFinishLayout()
    //     0x676e0c: bl              #0x678c84  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0x676e10: add             SP, SP, #8
    // 0x676e14: r0 = Null
    //     0x676e14: mov             x0, NULL
    // 0x676e18: LeaveFrame
    //     0x676e18: mov             SP, fp
    //     0x676e1c: ldp             fp, lr, [SP], #0x10
    // 0x676e20: ret
    //     0x676e20: ret             
    // 0x676e24: ldr             x5, [fp, #0x10]
    // 0x676e28: ldur            d0, [fp, #-0x68]
    // 0x676e2c: ldur            x3, [fp, #-0x20]
    // 0x676e30: r4 = false
    //     0x676e30: add             x4, NULL, #0x30  ; false
    // 0x676e34: d1 = 0.000000
    //     0x676e34: eor             v1.16b, v1.16b, v1.16b
    // 0x676e38: b               #0x676e50
    // 0x676e3c: mov             x5, x2
    // 0x676e40: ldur            d0, [fp, #-0x68]
    // 0x676e44: ldur            x3, [fp, #-0x20]
    // 0x676e48: r4 = false
    //     0x676e48: add             x4, NULL, #0x30  ; false
    // 0x676e4c: d1 = 0.000000
    //     0x676e4c: eor             v1.16b, v1.16b, v1.16b
    // 0x676e50: LoadField: r0 = r5->field_5b
    //     0x676e50: ldur            w0, [x5, #0x5b]
    // 0x676e54: DecompressPointer r0
    //     0x676e54: add             x0, x0, HEAP, lsl #32
    // 0x676e58: cmp             w0, NULL
    // 0x676e5c: b.eq            #0x677968
    // 0x676e60: LoadField: r6 = r0->field_17
    //     0x676e60: ldur            w6, [x0, #0x17]
    // 0x676e64: DecompressPointer r6
    //     0x676e64: add             x6, x6, HEAP, lsl #32
    // 0x676e68: stur            x6, [fp, #-0x38]
    // 0x676e6c: cmp             w6, NULL
    // 0x676e70: b.eq            #0x67796c
    // 0x676e74: mov             x0, x6
    // 0x676e78: r2 = Null
    //     0x676e78: mov             x2, NULL
    // 0x676e7c: r1 = Null
    //     0x676e7c: mov             x1, NULL
    // 0x676e80: r4 = LoadClassIdInstr(r0)
    //     0x676e80: ldur            x4, [x0, #-1]
    //     0x676e84: ubfx            x4, x4, #0xc, #0x14
    // 0x676e88: sub             x4, x4, #0x7f9
    // 0x676e8c: cmp             x4, #2
    // 0x676e90: b.ls            #0x676ea8
    // 0x676e94: r8 = SliverMultiBoxAdaptorParentData
    //     0x676e94: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x676e98: ldr             x8, [x8, #0x120]
    // 0x676e9c: r3 = Null
    //     0x676e9c: add             x3, PP, #0x57, lsl #12  ; [pp+0x573c0] Null
    //     0x676ea0: ldr             x3, [x3, #0x3c0]
    // 0x676ea4: r0 = DefaultTypeTest()
    //     0x676ea4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x676ea8: ldur            x0, [fp, #-0x38]
    // 0x676eac: LoadField: r1 = r0->field_17
    //     0x676eac: ldur            w1, [x0, #0x17]
    // 0x676eb0: DecompressPointer r1
    //     0x676eb0: add             x1, x1, HEAP, lsl #32
    // 0x676eb4: cmp             w1, NULL
    // 0x676eb8: b.eq            #0x677970
    // 0x676ebc: r0 = LoadInt32Instr(r1)
    //     0x676ebc: sbfx            x0, x1, #1, #0x1f
    //     0x676ec0: tbz             w1, #0, #0x676ec8
    //     0x676ec4: ldur            x0, [x1, #7]
    // 0x676ec8: sub             x1, x0, #1
    // 0x676ecc: mov             x2, x1
    // 0x676ed0: ldur            d0, [fp, #-0x68]
    // 0x676ed4: r3 = Null
    //     0x676ed4: mov             x3, NULL
    // 0x676ed8: ldr             x1, [fp, #0x10]
    // 0x676edc: ldur            x0, [fp, #-0x20]
    // 0x676ee0: stur            x3, [fp, #-0x38]
    // 0x676ee4: stur            x2, [fp, #-0x30]
    // 0x676ee8: CheckStackOverflow
    //     0x676ee8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x676eec: cmp             SP, x16
    //     0x676ef0: b.ls            #0x677974
    // 0x676ef4: cmp             x2, x0
    // 0x676ef8: b.lt            #0x6770c0
    // 0x676efc: ldur            x16, [fp, #-0x18]
    // 0x676f00: stp             x16, x1, [SP, #-0x10]!
    // 0x676f04: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x676f04: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x676f08: r0 = insertAndLayoutLeadingChild()
    //     0x676f08: bl              #0x678a4c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutLeadingChild
    // 0x676f0c: add             SP, SP, #0x10
    // 0x676f10: mov             x3, x0
    // 0x676f14: stur            x3, [fp, #-0x48]
    // 0x676f18: cmp             w3, NULL
    // 0x676f1c: b.ne            #0x676fe4
    // 0x676f20: ldr             x0, [fp, #0x10]
    // 0x676f24: ldur            d0, [fp, #-0x68]
    // 0x676f28: ldur            x4, [fp, #-0x30]
    // 0x676f2c: scvtf           d1, x4
    // 0x676f30: fmul            d2, d1, d0
    // 0x676f34: stur            d2, [fp, #-0x50]
    // 0x676f38: r0 = SliverGeometry()
    //     0x676f38: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x676f3c: d1 = 0.000000
    //     0x676f3c: eor             v1.16b, v1.16b, v1.16b
    // 0x676f40: StoreField: r0->field_7 = d1
    //     0x676f40: stur            d1, [x0, #7]
    // 0x676f44: StoreField: r0->field_17 = d1
    //     0x676f44: stur            d1, [x0, #0x17]
    // 0x676f48: StoreField: r0->field_f = d1
    //     0x676f48: stur            d1, [x0, #0xf]
    // 0x676f4c: StoreField: r0->field_27 = d1
    //     0x676f4c: stur            d1, [x0, #0x27]
    // 0x676f50: StoreField: r0->field_2f = d1
    //     0x676f50: stur            d1, [x0, #0x2f]
    // 0x676f54: r5 = false
    //     0x676f54: add             x5, NULL, #0x30  ; false
    // 0x676f58: StoreField: r0->field_43 = r5
    //     0x676f58: stur            w5, [x0, #0x43]
    // 0x676f5c: ldur            d0, [fp, #-0x50]
    // 0x676f60: r1 = inline_Allocate_Double()
    //     0x676f60: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x676f64: add             x1, x1, #0x10
    //     0x676f68: cmp             x2, x1
    //     0x676f6c: b.ls            #0x67797c
    //     0x676f70: str             x1, [THR, #0x60]  ; THR::top
    //     0x676f74: sub             x1, x1, #0xf
    //     0x676f78: mov             x2, #0xd108
    //     0x676f7c: movk            x2, #3, lsl #16
    //     0x676f80: stur            x2, [x1, #-1]
    // 0x676f84: StoreField: r1->field_7 = d0
    //     0x676f84: stur            d0, [x1, #7]
    // 0x676f88: StoreField: r0->field_47 = r1
    //     0x676f88: stur            w1, [x0, #0x47]
    // 0x676f8c: StoreField: r0->field_1f = d1
    //     0x676f8c: stur            d1, [x0, #0x1f]
    // 0x676f90: StoreField: r0->field_37 = d1
    //     0x676f90: stur            d1, [x0, #0x37]
    // 0x676f94: StoreField: r0->field_4b = d1
    //     0x676f94: stur            d1, [x0, #0x4b]
    // 0x676f98: fcmp            d1, d1
    // 0x676f9c: b.vs            #0x676fa4
    // 0x676fa0: b.gt            #0x676fac
    // 0x676fa4: r1 = false
    //     0x676fa4: add             x1, NULL, #0x30  ; false
    // 0x676fa8: b               #0x676fb0
    // 0x676fac: r1 = true
    //     0x676fac: add             x1, NULL, #0x20  ; true
    // 0x676fb0: StoreField: r0->field_3f = r1
    //     0x676fb0: stur            w1, [x0, #0x3f]
    // 0x676fb4: ldr             x6, [fp, #0x10]
    // 0x676fb8: StoreField: r6->field_4f = r0
    //     0x676fb8: stur            w0, [x6, #0x4f]
    //     0x676fbc: ldurb           w16, [x6, #-1]
    //     0x676fc0: ldurb           w17, [x0, #-1]
    //     0x676fc4: and             x16, x17, x16, lsr #2
    //     0x676fc8: tst             x16, HEAP, lsr #32
    //     0x676fcc: b.eq            #0x676fd4
    //     0x676fd0: bl              #0xd6830c
    // 0x676fd4: r0 = Null
    //     0x676fd4: mov             x0, NULL
    // 0x676fd8: LeaveFrame
    //     0x676fd8: mov             SP, fp
    //     0x676fdc: ldp             fp, lr, [SP], #0x10
    // 0x676fe0: ret
    //     0x676fe0: ret             
    // 0x676fe4: ldr             x6, [fp, #0x10]
    // 0x676fe8: ldur            d0, [fp, #-0x68]
    // 0x676fec: ldur            x7, [fp, #-0x38]
    // 0x676ff0: ldur            x4, [fp, #-0x30]
    // 0x676ff4: r5 = false
    //     0x676ff4: add             x5, NULL, #0x30  ; false
    // 0x676ff8: d1 = 0.000000
    //     0x676ff8: eor             v1.16b, v1.16b, v1.16b
    // 0x676ffc: LoadField: r8 = r3->field_17
    //     0x676ffc: ldur            w8, [x3, #0x17]
    // 0x677000: DecompressPointer r8
    //     0x677000: add             x8, x8, HEAP, lsl #32
    // 0x677004: stur            x8, [fp, #-0x40]
    // 0x677008: cmp             w8, NULL
    // 0x67700c: b.eq            #0x677998
    // 0x677010: mov             x0, x8
    // 0x677014: r2 = Null
    //     0x677014: mov             x2, NULL
    // 0x677018: r1 = Null
    //     0x677018: mov             x1, NULL
    // 0x67701c: r4 = LoadClassIdInstr(r0)
    //     0x67701c: ldur            x4, [x0, #-1]
    //     0x677020: ubfx            x4, x4, #0xc, #0x14
    // 0x677024: sub             x4, x4, #0x7f9
    // 0x677028: cmp             x4, #2
    // 0x67702c: b.ls            #0x677044
    // 0x677030: r8 = SliverMultiBoxAdaptorParentData
    //     0x677030: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x677034: ldr             x8, [x8, #0x120]
    // 0x677038: r3 = Null
    //     0x677038: add             x3, PP, #0x57, lsl #12  ; [pp+0x573d0] Null
    //     0x67703c: ldr             x3, [x3, #0x3d0]
    // 0x677040: r0 = DefaultTypeTest()
    //     0x677040: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x677044: ldur            x1, [fp, #-0x30]
    // 0x677048: scvtf           d0, x1
    // 0x67704c: ldur            d1, [fp, #-0x68]
    // 0x677050: fmul            d2, d1, d0
    // 0x677054: r0 = inline_Allocate_Double()
    //     0x677054: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x677058: add             x0, x0, #0x10
    //     0x67705c: cmp             x2, x0
    //     0x677060: b.ls            #0x67799c
    //     0x677064: str             x0, [THR, #0x60]  ; THR::top
    //     0x677068: sub             x0, x0, #0xf
    //     0x67706c: mov             x2, #0xd108
    //     0x677070: movk            x2, #3, lsl #16
    //     0x677074: stur            x2, [x0, #-1]
    // 0x677078: StoreField: r0->field_7 = d2
    //     0x677078: stur            d2, [x0, #7]
    // 0x67707c: ldur            x2, [fp, #-0x40]
    // 0x677080: StoreField: r2->field_7 = r0
    //     0x677080: stur            w0, [x2, #7]
    //     0x677084: ldurb           w16, [x2, #-1]
    //     0x677088: ldurb           w17, [x0, #-1]
    //     0x67708c: and             x16, x17, x16, lsr #2
    //     0x677090: tst             x16, HEAP, lsr #32
    //     0x677094: b.eq            #0x67709c
    //     0x677098: bl              #0xd6828c
    // 0x67709c: ldur            x0, [fp, #-0x38]
    // 0x6770a0: cmp             w0, NULL
    // 0x6770a4: b.ne            #0x6770b0
    // 0x6770a8: ldur            x3, [fp, #-0x48]
    // 0x6770ac: b               #0x6770b4
    // 0x6770b0: mov             x3, x0
    // 0x6770b4: sub             x2, x1, #1
    // 0x6770b8: mov             v0.16b, v1.16b
    // 0x6770bc: b               #0x676ed8
    // 0x6770c0: mov             v1.16b, v0.16b
    // 0x6770c4: mov             x0, x3
    // 0x6770c8: cmp             w0, NULL
    // 0x6770cc: b.ne            #0x6771d4
    // 0x6770d0: ldr             x1, [fp, #0x10]
    // 0x6770d4: ldur            x2, [fp, #-0x20]
    // 0x6770d8: LoadField: r0 = r1->field_5b
    //     0x6770d8: ldur            w0, [x1, #0x5b]
    // 0x6770dc: DecompressPointer r0
    //     0x6770dc: add             x0, x0, HEAP, lsl #32
    // 0x6770e0: cmp             w0, NULL
    // 0x6770e4: b.eq            #0x6779b4
    // 0x6770e8: r3 = LoadClassIdInstr(r0)
    //     0x6770e8: ldur            x3, [x0, #-1]
    //     0x6770ec: ubfx            x3, x3, #0xc, #0x14
    // 0x6770f0: ldur            x16, [fp, #-0x18]
    // 0x6770f4: stp             x16, x0, [SP, #-0x10]!
    // 0x6770f8: mov             x0, x3
    // 0x6770fc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6770fc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x677100: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x677100: mov             x17, #0xcdfb
    //     0x677104: add             lr, x0, x17
    //     0x677108: ldr             lr, [x21, lr, lsl #3]
    //     0x67710c: blr             lr
    // 0x677110: add             SP, SP, #0x10
    // 0x677114: ldr             x3, [fp, #0x10]
    // 0x677118: LoadField: r4 = r3->field_5b
    //     0x677118: ldur            w4, [x3, #0x5b]
    // 0x67711c: DecompressPointer r4
    //     0x67711c: add             x4, x4, HEAP, lsl #32
    // 0x677120: stur            x4, [fp, #-0x48]
    // 0x677124: cmp             w4, NULL
    // 0x677128: b.eq            #0x6779b8
    // 0x67712c: LoadField: r5 = r4->field_17
    //     0x67712c: ldur            w5, [x4, #0x17]
    // 0x677130: DecompressPointer r5
    //     0x677130: add             x5, x5, HEAP, lsl #32
    // 0x677134: stur            x5, [fp, #-0x40]
    // 0x677138: cmp             w5, NULL
    // 0x67713c: b.eq            #0x6779bc
    // 0x677140: mov             x0, x5
    // 0x677144: r2 = Null
    //     0x677144: mov             x2, NULL
    // 0x677148: r1 = Null
    //     0x677148: mov             x1, NULL
    // 0x67714c: r4 = LoadClassIdInstr(r0)
    //     0x67714c: ldur            x4, [x0, #-1]
    //     0x677150: ubfx            x4, x4, #0xc, #0x14
    // 0x677154: sub             x4, x4, #0x7f9
    // 0x677158: cmp             x4, #2
    // 0x67715c: b.ls            #0x677174
    // 0x677160: r8 = SliverMultiBoxAdaptorParentData
    //     0x677160: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x677164: ldr             x8, [x8, #0x120]
    // 0x677168: r3 = Null
    //     0x677168: add             x3, PP, #0x57, lsl #12  ; [pp+0x573e0] Null
    //     0x67716c: ldr             x3, [x3, #0x3e0]
    // 0x677170: r0 = DefaultTypeTest()
    //     0x677170: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x677174: ldur            x3, [fp, #-0x20]
    // 0x677178: scvtf           d0, x3
    // 0x67717c: ldur            d1, [fp, #-0x68]
    // 0x677180: fmul            d2, d1, d0
    // 0x677184: r0 = inline_Allocate_Double()
    //     0x677184: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x677188: add             x0, x0, #0x10
    //     0x67718c: cmp             x1, x0
    //     0x677190: b.ls            #0x6779c0
    //     0x677194: str             x0, [THR, #0x60]  ; THR::top
    //     0x677198: sub             x0, x0, #0xf
    //     0x67719c: mov             x1, #0xd108
    //     0x6771a0: movk            x1, #3, lsl #16
    //     0x6771a4: stur            x1, [x0, #-1]
    // 0x6771a8: StoreField: r0->field_7 = d2
    //     0x6771a8: stur            d2, [x0, #7]
    // 0x6771ac: ldur            x1, [fp, #-0x40]
    // 0x6771b0: StoreField: r1->field_7 = r0
    //     0x6771b0: stur            w0, [x1, #7]
    //     0x6771b4: ldurb           w16, [x1, #-1]
    //     0x6771b8: ldurb           w17, [x0, #-1]
    //     0x6771bc: and             x16, x17, x16, lsr #2
    //     0x6771c0: tst             x16, HEAP, lsr #32
    //     0x6771c4: b.eq            #0x6771cc
    //     0x6771c8: bl              #0xd6826c
    // 0x6771cc: ldur            x4, [fp, #-0x48]
    // 0x6771d0: b               #0x6771dc
    // 0x6771d4: ldur            x3, [fp, #-0x20]
    // 0x6771d8: mov             x4, x0
    // 0x6771dc: stur            x4, [fp, #-0x40]
    // 0x6771e0: LoadField: r5 = r4->field_17
    //     0x6771e0: ldur            w5, [x4, #0x17]
    // 0x6771e4: DecompressPointer r5
    //     0x6771e4: add             x5, x5, HEAP, lsl #32
    // 0x6771e8: stur            x5, [fp, #-0x38]
    // 0x6771ec: cmp             w5, NULL
    // 0x6771f0: b.eq            #0x6779d8
    // 0x6771f4: mov             x0, x5
    // 0x6771f8: r2 = Null
    //     0x6771f8: mov             x2, NULL
    // 0x6771fc: r1 = Null
    //     0x6771fc: mov             x1, NULL
    // 0x677200: r4 = LoadClassIdInstr(r0)
    //     0x677200: ldur            x4, [x0, #-1]
    //     0x677204: ubfx            x4, x4, #0xc, #0x14
    // 0x677208: sub             x4, x4, #0x7f9
    // 0x67720c: cmp             x4, #2
    // 0x677210: b.ls            #0x677228
    // 0x677214: r8 = SliverMultiBoxAdaptorParentData
    //     0x677214: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x677218: ldr             x8, [x8, #0x120]
    // 0x67721c: r3 = Null
    //     0x67721c: add             x3, PP, #0x57, lsl #12  ; [pp+0x573f0] Null
    //     0x677220: ldr             x3, [x3, #0x3f0]
    // 0x677224: r0 = DefaultTypeTest()
    //     0x677224: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x677228: ldur            x0, [fp, #-0x38]
    // 0x67722c: LoadField: r1 = r0->field_17
    //     0x67722c: ldur            w1, [x0, #0x17]
    // 0x677230: DecompressPointer r1
    //     0x677230: add             x1, x1, HEAP, lsl #32
    // 0x677234: cmp             w1, NULL
    // 0x677238: b.eq            #0x6779dc
    // 0x67723c: r2 = LoadInt32Instr(r1)
    //     0x67723c: sbfx            x2, x1, #1, #0x1f
    //     0x677240: tbz             w1, #0, #0x677248
    //     0x677244: ldur            x2, [x1, #7]
    // 0x677248: add             x1, x2, #1
    // 0x67724c: ldur            x5, [fp, #-0x40]
    // 0x677250: mov             x4, x1
    // 0x677254: ldur            d0, [fp, #-0x68]
    // 0x677258: ldur            x3, [fp, #-0x28]
    // 0x67725c: stur            x5, [fp, #-0x48]
    // 0x677260: stur            x4, [fp, #-0x30]
    // 0x677264: CheckStackOverflow
    //     0x677264: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x677268: cmp             SP, x16
    //     0x67726c: b.ls            #0x6779e0
    // 0x677270: cmp             w3, NULL
    // 0x677274: b.eq            #0x67728c
    // 0x677278: r1 = LoadInt32Instr(r3)
    //     0x677278: sbfx            x1, x3, #1, #0x1f
    //     0x67727c: tbz             w3, #0, #0x677284
    //     0x677280: ldur            x1, [x3, #7]
    // 0x677284: cmp             x4, x1
    // 0x677288: b.gt            #0x67748c
    // 0x67728c: LoadField: r6 = r0->field_f
    //     0x67728c: ldur            w6, [x0, #0xf]
    // 0x677290: DecompressPointer r6
    //     0x677290: add             x6, x6, HEAP, lsl #32
    // 0x677294: stur            x6, [fp, #-0x40]
    // 0x677298: cmp             w6, NULL
    // 0x67729c: b.ne            #0x6772a8
    // 0x6772a0: mov             x1, x4
    // 0x6772a4: b               #0x67731c
    // 0x6772a8: LoadField: r7 = r6->field_17
    //     0x6772a8: ldur            w7, [x6, #0x17]
    // 0x6772ac: DecompressPointer r7
    //     0x6772ac: add             x7, x7, HEAP, lsl #32
    // 0x6772b0: stur            x7, [fp, #-0x38]
    // 0x6772b4: cmp             w7, NULL
    // 0x6772b8: b.eq            #0x6779e8
    // 0x6772bc: mov             x0, x7
    // 0x6772c0: r2 = Null
    //     0x6772c0: mov             x2, NULL
    // 0x6772c4: r1 = Null
    //     0x6772c4: mov             x1, NULL
    // 0x6772c8: r4 = LoadClassIdInstr(r0)
    //     0x6772c8: ldur            x4, [x0, #-1]
    //     0x6772cc: ubfx            x4, x4, #0xc, #0x14
    // 0x6772d0: sub             x4, x4, #0x7f9
    // 0x6772d4: cmp             x4, #2
    // 0x6772d8: b.ls            #0x6772f0
    // 0x6772dc: r8 = SliverMultiBoxAdaptorParentData
    //     0x6772dc: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x6772e0: ldr             x8, [x8, #0x120]
    // 0x6772e4: r3 = Null
    //     0x6772e4: add             x3, PP, #0x57, lsl #12  ; [pp+0x57400] Null
    //     0x6772e8: ldr             x3, [x3, #0x400]
    // 0x6772ec: r0 = DefaultTypeTest()
    //     0x6772ec: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6772f0: ldur            x0, [fp, #-0x38]
    // 0x6772f4: LoadField: r1 = r0->field_17
    //     0x6772f4: ldur            w1, [x0, #0x17]
    // 0x6772f8: DecompressPointer r1
    //     0x6772f8: add             x1, x1, HEAP, lsl #32
    // 0x6772fc: cmp             w1, NULL
    // 0x677300: b.eq            #0x6779ec
    // 0x677304: r0 = LoadInt32Instr(r1)
    //     0x677304: sbfx            x0, x1, #1, #0x1f
    //     0x677308: tbz             w1, #0, #0x677310
    //     0x67730c: ldur            x0, [x1, #7]
    // 0x677310: ldur            x1, [fp, #-0x30]
    // 0x677314: cmp             x0, x1
    // 0x677318: b.eq            #0x677378
    // 0x67731c: ldr             x16, [fp, #0x10]
    // 0x677320: ldur            lr, [fp, #-0x18]
    // 0x677324: stp             lr, x16, [SP, #-0x10]!
    // 0x677328: ldur            x16, [fp, #-0x48]
    // 0x67732c: SaveReg r16
    //     0x67732c: str             x16, [SP, #-8]!
    // 0x677330: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x677330: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x677334: r0 = insertAndLayoutChild()
    //     0x677334: bl              #0x677f44  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutChild
    // 0x677338: add             SP, SP, #0x18
    // 0x67733c: mov             x1, x0
    // 0x677340: cmp             w1, NULL
    // 0x677344: b.ne            #0x677364
    // 0x677348: ldur            d0, [fp, #-0x68]
    // 0x67734c: ldur            x2, [fp, #-0x30]
    // 0x677350: scvtf           d1, x2
    // 0x677354: fmul            d2, d1, d0
    // 0x677358: mov             v1.16b, v0.16b
    // 0x67735c: mov             v0.16b, v2.16b
    // 0x677360: b               #0x677494
    // 0x677364: ldur            d0, [fp, #-0x68]
    // 0x677368: ldur            x2, [fp, #-0x30]
    // 0x67736c: mov             x5, x1
    // 0x677370: mov             x3, x2
    // 0x677374: b               #0x6773b8
    // 0x677378: ldur            d0, [fp, #-0x68]
    // 0x67737c: mov             x2, x1
    // 0x677380: ldur            x1, [fp, #-0x40]
    // 0x677384: r0 = LoadClassIdInstr(r1)
    //     0x677384: ldur            x0, [x1, #-1]
    //     0x677388: ubfx            x0, x0, #0xc, #0x14
    // 0x67738c: ldur            x16, [fp, #-0x18]
    // 0x677390: stp             x16, x1, [SP, #-0x10]!
    // 0x677394: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x677394: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x677398: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x677398: mov             x17, #0xcdfb
    //     0x67739c: add             lr, x0, x17
    //     0x6773a0: ldr             lr, [x21, lr, lsl #3]
    //     0x6773a4: blr             lr
    // 0x6773a8: add             SP, SP, #0x10
    // 0x6773ac: ldur            x5, [fp, #-0x40]
    // 0x6773b0: ldur            d0, [fp, #-0x68]
    // 0x6773b4: ldur            x3, [fp, #-0x30]
    // 0x6773b8: stur            x5, [fp, #-0x40]
    // 0x6773bc: LoadField: r4 = r5->field_17
    //     0x6773bc: ldur            w4, [x5, #0x17]
    // 0x6773c0: DecompressPointer r4
    //     0x6773c0: add             x4, x4, HEAP, lsl #32
    // 0x6773c4: stur            x4, [fp, #-0x38]
    // 0x6773c8: cmp             w4, NULL
    // 0x6773cc: b.eq            #0x6779f0
    // 0x6773d0: mov             x0, x4
    // 0x6773d4: r2 = Null
    //     0x6773d4: mov             x2, NULL
    // 0x6773d8: r1 = Null
    //     0x6773d8: mov             x1, NULL
    // 0x6773dc: r4 = LoadClassIdInstr(r0)
    //     0x6773dc: ldur            x4, [x0, #-1]
    //     0x6773e0: ubfx            x4, x4, #0xc, #0x14
    // 0x6773e4: sub             x4, x4, #0x7f9
    // 0x6773e8: cmp             x4, #2
    // 0x6773ec: b.ls            #0x677404
    // 0x6773f0: r8 = SliverMultiBoxAdaptorParentData
    //     0x6773f0: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x6773f4: ldr             x8, [x8, #0x120]
    // 0x6773f8: r3 = Null
    //     0x6773f8: add             x3, PP, #0x57, lsl #12  ; [pp+0x57410] Null
    //     0x6773fc: ldr             x3, [x3, #0x410]
    // 0x677400: r0 = DefaultTypeTest()
    //     0x677400: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x677404: ldur            x1, [fp, #-0x38]
    // 0x677408: LoadField: r0 = r1->field_17
    //     0x677408: ldur            w0, [x1, #0x17]
    // 0x67740c: DecompressPointer r0
    //     0x67740c: add             x0, x0, HEAP, lsl #32
    // 0x677410: cmp             w0, NULL
    // 0x677414: b.eq            #0x6779f4
    // 0x677418: r2 = LoadInt32Instr(r0)
    //     0x677418: sbfx            x2, x0, #1, #0x1f
    //     0x67741c: tbz             w0, #0, #0x677424
    //     0x677420: ldur            x2, [x0, #7]
    // 0x677424: scvtf           d0, x2
    // 0x677428: ldur            d1, [fp, #-0x68]
    // 0x67742c: fmul            d2, d1, d0
    // 0x677430: r0 = inline_Allocate_Double()
    //     0x677430: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x677434: add             x0, x0, #0x10
    //     0x677438: cmp             x2, x0
    //     0x67743c: b.ls            #0x6779f8
    //     0x677440: str             x0, [THR, #0x60]  ; THR::top
    //     0x677444: sub             x0, x0, #0xf
    //     0x677448: mov             x2, #0xd108
    //     0x67744c: movk            x2, #3, lsl #16
    //     0x677450: stur            x2, [x0, #-1]
    // 0x677454: StoreField: r0->field_7 = d2
    //     0x677454: stur            d2, [x0, #7]
    // 0x677458: StoreField: r1->field_7 = r0
    //     0x677458: stur            w0, [x1, #7]
    //     0x67745c: ldurb           w16, [x1, #-1]
    //     0x677460: ldurb           w17, [x0, #-1]
    //     0x677464: and             x16, x17, x16, lsr #2
    //     0x677468: tst             x16, HEAP, lsr #32
    //     0x67746c: b.eq            #0x677474
    //     0x677470: bl              #0xd6826c
    // 0x677474: ldur            x0, [fp, #-0x30]
    // 0x677478: add             x4, x0, #1
    // 0x67747c: ldur            x5, [fp, #-0x40]
    // 0x677480: mov             x0, x1
    // 0x677484: mov             v0.16b, v1.16b
    // 0x677488: b               #0x677258
    // 0x67748c: mov             v1.16b, v0.16b
    // 0x677490: d0 = inf
    //     0x677490: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x677494: ldr             x4, [fp, #0x10]
    // 0x677498: ldur            x3, [fp, #-0x20]
    // 0x67749c: stur            d0, [fp, #-0x50]
    // 0x6774a0: LoadField: r0 = r4->field_5f
    //     0x6774a0: ldur            w0, [x4, #0x5f]
    // 0x6774a4: DecompressPointer r0
    //     0x6774a4: add             x0, x0, HEAP, lsl #32
    // 0x6774a8: cmp             w0, NULL
    // 0x6774ac: b.eq            #0x677a10
    // 0x6774b0: LoadField: r5 = r0->field_17
    //     0x6774b0: ldur            w5, [x0, #0x17]
    // 0x6774b4: DecompressPointer r5
    //     0x6774b4: add             x5, x5, HEAP, lsl #32
    // 0x6774b8: stur            x5, [fp, #-0x18]
    // 0x6774bc: cmp             w5, NULL
    // 0x6774c0: b.eq            #0x677a14
    // 0x6774c4: mov             x0, x5
    // 0x6774c8: r2 = Null
    //     0x6774c8: mov             x2, NULL
    // 0x6774cc: r1 = Null
    //     0x6774cc: mov             x1, NULL
    // 0x6774d0: r4 = LoadClassIdInstr(r0)
    //     0x6774d0: ldur            x4, [x0, #-1]
    //     0x6774d4: ubfx            x4, x4, #0xc, #0x14
    // 0x6774d8: sub             x4, x4, #0x7f9
    // 0x6774dc: cmp             x4, #2
    // 0x6774e0: b.ls            #0x6774f8
    // 0x6774e4: r8 = SliverMultiBoxAdaptorParentData
    //     0x6774e4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x6774e8: ldr             x8, [x8, #0x120]
    // 0x6774ec: r3 = Null
    //     0x6774ec: add             x3, PP, #0x57, lsl #12  ; [pp+0x57420] Null
    //     0x6774f0: ldr             x3, [x3, #0x420]
    // 0x6774f4: r0 = DefaultTypeTest()
    //     0x6774f4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6774f8: ldur            x0, [fp, #-0x18]
    // 0x6774fc: LoadField: r2 = r0->field_17
    //     0x6774fc: ldur            w2, [x0, #0x17]
    // 0x677500: DecompressPointer r2
    //     0x677500: add             x2, x2, HEAP, lsl #32
    // 0x677504: cmp             w2, NULL
    // 0x677508: b.eq            #0x677a18
    // 0x67750c: ldur            x3, [fp, #-0x20]
    // 0x677510: scvtf           d0, x3
    // 0x677514: ldur            d1, [fp, #-0x68]
    // 0x677518: fmul            d2, d1, d0
    // 0x67751c: stur            d2, [fp, #-0x70]
    // 0x677520: r4 = LoadInt32Instr(r2)
    //     0x677520: sbfx            x4, x2, #1, #0x1f
    //     0x677524: tbz             w2, #0, #0x67752c
    //     0x677528: ldur            x4, [x2, #7]
    // 0x67752c: stur            x4, [fp, #-0x30]
    // 0x677530: add             x0, x4, #1
    // 0x677534: scvtf           d0, x0
    // 0x677538: fmul            d3, d1, d0
    // 0x67753c: cmp             x4, #0
    // 0x677540: b.le            #0x677550
    // 0x677544: d0 = 0.000000
    //     0x677544: eor             v0.16b, v0.16b, v0.16b
    // 0x677548: fsub            d4, d3, d0
    // 0x67754c: b               #0x677558
    // 0x677550: d0 = 0.000000
    //     0x677550: eor             v0.16b, v0.16b, v0.16b
    // 0x677554: mov             v4.16b, v3.16b
    // 0x677558: ldur            d3, [fp, #-0x50]
    // 0x67755c: stur            d4, [fp, #-0x58]
    // 0x677560: r0 = BoxInt64Instr(r3)
    //     0x677560: sbfiz           x0, x3, #1, #0x1f
    //     0x677564: cmp             x3, x0, asr #1
    //     0x677568: b.eq            #0x677574
    //     0x67756c: bl              #0xd69c6c
    //     0x677570: stur            x3, [x0, #7]
    // 0x677574: r1 = inline_Allocate_Double()
    //     0x677574: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x677578: add             x1, x1, #0x10
    //     0x67757c: cmp             x3, x1
    //     0x677580: b.ls            #0x677a1c
    //     0x677584: str             x1, [THR, #0x60]  ; THR::top
    //     0x677588: sub             x1, x1, #0xf
    //     0x67758c: mov             x3, #0xd108
    //     0x677590: movk            x3, #3, lsl #16
    //     0x677594: stur            x3, [x1, #-1]
    // 0x677598: StoreField: r1->field_7 = d2
    //     0x677598: stur            d2, [x1, #7]
    // 0x67759c: ldr             x16, [fp, #0x10]
    // 0x6775a0: ldur            lr, [fp, #-8]
    // 0x6775a4: stp             lr, x16, [SP, #-0x10]!
    // 0x6775a8: stp             x2, x0, [SP, #-0x10]!
    // 0x6775ac: SaveReg r1
    //     0x6775ac: str             x1, [SP, #-8]!
    // 0x6775b0: SaveReg d4
    //     0x6775b0: str             d4, [SP, #-8]!
    // 0x6775b4: r0 = estimateMaxScrollOffset()
    //     0x6775b4: bl              #0x677c8c  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::estimateMaxScrollOffset
    // 0x6775b8: add             SP, SP, #0x30
    // 0x6775bc: mov             v1.16b, v0.16b
    // 0x6775c0: ldur            d0, [fp, #-0x50]
    // 0x6775c4: stur            d1, [fp, #-0x78]
    // 0x6775c8: fcmp            d0, d1
    // 0x6775cc: b.vs            #0x6775dc
    // 0x6775d0: b.le            #0x6775dc
    // 0x6775d4: mov             v3.16b, v1.16b
    // 0x6775d8: b               #0x677680
    // 0x6775dc: fcmp            d0, d1
    // 0x6775e0: b.vs            #0x6775f0
    // 0x6775e4: b.ge            #0x6775f0
    // 0x6775e8: mov             v3.16b, v0.16b
    // 0x6775ec: b               #0x677680
    // 0x6775f0: d2 = 0.000000
    //     0x6775f0: eor             v2.16b, v2.16b, v2.16b
    // 0x6775f4: fcmp            d0, d2
    // 0x6775f8: b.vs            #0x677600
    // 0x6775fc: b.eq            #0x677608
    // 0x677600: r0 = false
    //     0x677600: add             x0, NULL, #0x30  ; false
    // 0x677604: b               #0x67760c
    // 0x677608: r0 = true
    //     0x677608: add             x0, NULL, #0x20  ; true
    // 0x67760c: tbnz            w0, #4, #0x677624
    // 0x677610: fadd            d3, d0, d1
    // 0x677614: fmul            d4, d3, d0
    // 0x677618: fmul            d0, d4, d1
    // 0x67761c: mov             v3.16b, v0.16b
    // 0x677620: b               #0x677680
    // 0x677624: tbnz            w0, #4, #0x677668
    // 0x677628: r0 = inline_Allocate_Double()
    //     0x677628: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67762c: add             x0, x0, #0x10
    //     0x677630: cmp             x1, x0
    //     0x677634: b.ls            #0x677a50
    //     0x677638: str             x0, [THR, #0x60]  ; THR::top
    //     0x67763c: sub             x0, x0, #0xf
    //     0x677640: mov             x1, #0xd108
    //     0x677644: movk            x1, #3, lsl #16
    //     0x677648: stur            x1, [x0, #-1]
    // 0x67764c: StoreField: r0->field_7 = d1
    //     0x67764c: stur            d1, [x0, #7]
    // 0x677650: SaveReg r0
    //     0x677650: str             x0, [SP, #-8]!
    // 0x677654: r0 = isNegative()
    //     0x677654: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x677658: add             SP, SP, #8
    // 0x67765c: tbnz            w0, #4, #0x677668
    // 0x677660: ldur            d0, [fp, #-0x78]
    // 0x677664: b               #0x677674
    // 0x677668: ldur            d0, [fp, #-0x78]
    // 0x67766c: fcmp            d0, d0
    // 0x677670: b.vc            #0x67767c
    // 0x677674: mov             v3.16b, v0.16b
    // 0x677678: b               #0x677680
    // 0x67767c: ldur            d3, [fp, #-0x50]
    // 0x677680: ldur            d2, [fp, #-0x60]
    // 0x677684: ldur            d1, [fp, #-0x58]
    // 0x677688: ldur            d0, [fp, #-0x70]
    // 0x67768c: ldur            x0, [fp, #-8]
    // 0x677690: stur            d3, [fp, #-0x50]
    // 0x677694: r1 = inline_Allocate_Double()
    //     0x677694: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x677698: add             x1, x1, #0x10
    //     0x67769c: cmp             x2, x1
    //     0x6776a0: b.ls            #0x677a68
    //     0x6776a4: str             x1, [THR, #0x60]  ; THR::top
    //     0x6776a8: sub             x1, x1, #0xf
    //     0x6776ac: mov             x2, #0xd108
    //     0x6776b0: movk            x2, #3, lsl #16
    //     0x6776b4: stur            x2, [x1, #-1]
    // 0x6776b8: StoreField: r1->field_7 = d1
    //     0x6776b8: stur            d1, [x1, #7]
    // 0x6776bc: stur            x1, [fp, #-0x18]
    // 0x6776c0: ldr             x16, [fp, #0x10]
    // 0x6776c4: stp             x0, x16, [SP, #-0x10]!
    // 0x6776c8: SaveReg d0
    //     0x6776c8: str             d0, [SP, #-8]!
    // 0x6776cc: SaveReg r1
    //     0x6776cc: str             x1, [SP, #-8]!
    // 0x6776d0: r0 = calculatePaintOffset()
    //     0x6776d0: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x6776d4: add             SP, SP, #0x20
    // 0x6776d8: stur            d0, [fp, #-0x78]
    // 0x6776dc: ldr             x16, [fp, #0x10]
    // 0x6776e0: ldur            lr, [fp, #-8]
    // 0x6776e4: stp             lr, x16, [SP, #-0x10]!
    // 0x6776e8: ldur            d1, [fp, #-0x70]
    // 0x6776ec: SaveReg d1
    //     0x6776ec: str             d1, [SP, #-8]!
    // 0x6776f0: ldur            x16, [fp, #-0x18]
    // 0x6776f4: SaveReg r16
    //     0x6776f4: str             x16, [SP, #-8]!
    // 0x6776f8: r0 = calculateCacheOffset()
    //     0x6776f8: bl              #0x677aa4  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0x6776fc: add             SP, SP, #0x20
    // 0x677700: ldur            x0, [fp, #-8]
    // 0x677704: stur            d0, [fp, #-0x70]
    // 0x677708: LoadField: d1 = r0->field_2b
    //     0x677708: ldur            d1, [x0, #0x2b]
    // 0x67770c: ldur            d2, [fp, #-0x60]
    // 0x677710: fadd            d3, d2, d1
    // 0x677714: mov             x0, v3.d[0]
    // 0x677718: and             x0, x0, #0x7fffffffffffffff
    // 0x67771c: r17 = 9218868437227405312
    //     0x67771c: mov             x17, #0x7ff0000000000000
    // 0x677720: cmp             x0, x17
    // 0x677724: b.eq            #0x67778c
    // 0x677728: fcmp            d3, d3
    // 0x67772c: b.vs            #0x67778c
    // 0x677730: ldur            d1, [fp, #-0x68]
    // 0x677734: r0 = inline_Allocate_Double()
    //     0x677734: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x677738: add             x0, x0, #0x10
    //     0x67773c: cmp             x1, x0
    //     0x677740: b.ls            #0x677a8c
    //     0x677744: str             x0, [THR, #0x60]  ; THR::top
    //     0x677748: sub             x0, x0, #0xf
    //     0x67774c: mov             x1, #0xd108
    //     0x677750: movk            x1, #3, lsl #16
    //     0x677754: stur            x1, [x0, #-1]
    // 0x677758: StoreField: r0->field_7 = d3
    //     0x677758: stur            d3, [x0, #7]
    // 0x67775c: ldr             x16, [fp, #0x10]
    // 0x677760: stp             x0, x16, [SP, #-0x10]!
    // 0x677764: SaveReg d1
    //     0x677764: str             d1, [SP, #-8]!
    // 0x677768: r0 = getMaxChildIndexForScrollOffset()
    //     0x677768: bl              #0x67a178  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::getMaxChildIndexForScrollOffset
    // 0x67776c: add             SP, SP, #0x18
    // 0x677770: mov             x2, x0
    // 0x677774: r0 = BoxInt64Instr(r2)
    //     0x677774: sbfiz           x0, x2, #1, #0x1f
    //     0x677778: cmp             x2, x0, asr #1
    //     0x67777c: b.eq            #0x677788
    //     0x677780: bl              #0xd69bb8
    //     0x677784: stur            x2, [x0, #7]
    // 0x677788: b               #0x677790
    // 0x67778c: r0 = Null
    //     0x67778c: mov             x0, NULL
    // 0x677790: cmp             w0, NULL
    // 0x677794: b.eq            #0x6777bc
    // 0x677798: ldur            x1, [fp, #-0x30]
    // 0x67779c: r2 = LoadInt32Instr(r0)
    //     0x67779c: sbfx            x2, x0, #1, #0x1f
    //     0x6777a0: tbz             w0, #0, #0x6777a8
    //     0x6777a4: ldur            x2, [x0, #7]
    // 0x6777a8: cmp             x1, x2
    // 0x6777ac: b.lt            #0x6777bc
    // 0x6777b0: r1 = true
    //     0x6777b0: add             x1, NULL, #0x20  ; true
    // 0x6777b4: d1 = 0.000000
    //     0x6777b4: eor             v1.16b, v1.16b, v1.16b
    // 0x6777b8: b               #0x6777e0
    // 0x6777bc: ldur            d0, [fp, #-0x60]
    // 0x6777c0: d1 = 0.000000
    //     0x6777c0: eor             v1.16b, v1.16b, v1.16b
    // 0x6777c4: fcmp            d0, d1
    // 0x6777c8: b.vs            #0x6777d0
    // 0x6777cc: b.gt            #0x6777d8
    // 0x6777d0: r0 = false
    //     0x6777d0: add             x0, NULL, #0x30  ; false
    // 0x6777d4: b               #0x6777dc
    // 0x6777d8: r0 = true
    //     0x6777d8: add             x0, NULL, #0x20  ; true
    // 0x6777dc: mov             x1, x0
    // 0x6777e0: ldr             x0, [fp, #0x10]
    // 0x6777e4: ldur            d3, [fp, #-0x58]
    // 0x6777e8: ldur            d2, [fp, #-0x78]
    // 0x6777ec: ldur            d0, [fp, #-0x70]
    // 0x6777f0: ldur            d4, [fp, #-0x50]
    // 0x6777f4: stur            x1, [fp, #-8]
    // 0x6777f8: r0 = SliverGeometry()
    //     0x6777f8: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x6777fc: ldur            d0, [fp, #-0x50]
    // 0x677800: StoreField: r0->field_7 = d0
    //     0x677800: stur            d0, [x0, #7]
    // 0x677804: ldur            d1, [fp, #-0x78]
    // 0x677808: StoreField: r0->field_17 = d1
    //     0x677808: stur            d1, [x0, #0x17]
    // 0x67780c: d2 = 0.000000
    //     0x67780c: eor             v2.16b, v2.16b, v2.16b
    // 0x677810: StoreField: r0->field_f = d2
    //     0x677810: stur            d2, [x0, #0xf]
    // 0x677814: StoreField: r0->field_27 = d0
    //     0x677814: stur            d0, [x0, #0x27]
    // 0x677818: StoreField: r0->field_2f = d2
    //     0x677818: stur            d2, [x0, #0x2f]
    // 0x67781c: ldur            x1, [fp, #-8]
    // 0x677820: StoreField: r0->field_43 = r1
    //     0x677820: stur            w1, [x0, #0x43]
    // 0x677824: StoreField: r0->field_1f = d1
    //     0x677824: stur            d1, [x0, #0x1f]
    // 0x677828: StoreField: r0->field_37 = d1
    //     0x677828: stur            d1, [x0, #0x37]
    // 0x67782c: ldur            d3, [fp, #-0x70]
    // 0x677830: StoreField: r0->field_4b = d3
    //     0x677830: stur            d3, [x0, #0x4b]
    // 0x677834: fcmp            d1, d2
    // 0x677838: b.vs            #0x677840
    // 0x67783c: b.gt            #0x677848
    // 0x677840: r1 = false
    //     0x677840: add             x1, NULL, #0x30  ; false
    // 0x677844: b               #0x67784c
    // 0x677848: r1 = true
    //     0x677848: add             x1, NULL, #0x20  ; true
    // 0x67784c: StoreField: r0->field_3f = r1
    //     0x67784c: stur            w1, [x0, #0x3f]
    // 0x677850: ldr             x1, [fp, #0x10]
    // 0x677854: StoreField: r1->field_4f = r0
    //     0x677854: stur            w0, [x1, #0x4f]
    //     0x677858: ldurb           w16, [x1, #-1]
    //     0x67785c: ldurb           w17, [x0, #-1]
    //     0x677860: and             x16, x17, x16, lsr #2
    //     0x677864: tst             x16, HEAP, lsr #32
    //     0x677868: b.eq            #0x677870
    //     0x67786c: bl              #0xd6826c
    // 0x677870: ldur            d1, [fp, #-0x58]
    // 0x677874: fcmp            d0, d1
    // 0x677878: b.vs            #0x677890
    // 0x67787c: b.ne            #0x677890
    // 0x677880: ldur            x0, [fp, #-0x10]
    // 0x677884: r1 = true
    //     0x677884: add             x1, NULL, #0x20  ; true
    // 0x677888: StoreField: r0->field_53 = r1
    //     0x677888: stur            w1, [x0, #0x53]
    // 0x67788c: b               #0x677894
    // 0x677890: ldur            x0, [fp, #-0x10]
    // 0x677894: SaveReg r0
    //     0x677894: str             x0, [SP, #-8]!
    // 0x677898: r0 = didFinishLayout()
    //     0x677898: bl              #0x678c84  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0x67789c: add             SP, SP, #8
    // 0x6778a0: r0 = Null
    //     0x6778a0: mov             x0, NULL
    // 0x6778a4: LeaveFrame
    //     0x6778a4: mov             SP, fp
    //     0x6778a8: ldp             fp, lr, [SP], #0x10
    // 0x6778ac: ret
    //     0x6778ac: ret             
    // 0x6778b0: r0 = StateError()
    //     0x6778b0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6778b4: mov             x1, x0
    // 0x6778b8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6778b8: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6778bc: ldr             x0, [x0, #0x1e8]
    // 0x6778c0: StoreField: r1->field_b = r0
    //     0x6778c0: stur            w0, [x1, #0xb]
    // 0x6778c4: mov             x0, x1
    // 0x6778c8: r0 = Throw()
    //     0x6778c8: bl              #0xd67e38  ; ThrowStub
    // 0x6778cc: brk             #0
    // 0x6778d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6778d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6778d4: b               #0x676a98
    // 0x6778d8: stp             q5, q6, [SP, #-0x20]!
    // 0x6778dc: stp             q2, q3, [SP, #-0x20]!
    // 0x6778e0: stp             q0, q1, [SP, #-0x20]!
    // 0x6778e4: stp             x2, x3, [SP, #-0x10]!
    // 0x6778e8: stp             x0, x1, [SP, #-0x10]!
    // 0x6778ec: r0 = AllocateDouble()
    //     0x6778ec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6778f0: mov             x4, x0
    // 0x6778f4: ldp             x0, x1, [SP], #0x10
    // 0x6778f8: ldp             x2, x3, [SP], #0x10
    // 0x6778fc: ldp             q0, q1, [SP], #0x20
    // 0x677900: ldp             q2, q3, [SP], #0x20
    // 0x677904: ldp             q5, q6, [SP], #0x20
    // 0x677908: b               #0x676b50
    // 0x67790c: SaveReg d0
    //     0x67790c: str             q0, [SP, #-0x10]!
    // 0x677910: SaveReg r0
    //     0x677910: str             x0, [SP, #-8]!
    // 0x677914: r0 = AllocateDouble()
    //     0x677914: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x677918: mov             x1, x0
    // 0x67791c: RestoreReg r0
    //     0x67791c: ldr             x0, [SP], #8
    // 0x677920: RestoreReg d0
    //     0x677920: ldr             q0, [SP], #0x10
    // 0x677924: b               #0x676b98
    // 0x677928: stp             q0, q1, [SP, #-0x20]!
    // 0x67792c: SaveReg r0
    //     0x67792c: str             x0, [SP, #-8]!
    // 0x677930: r0 = AllocateDouble()
    //     0x677930: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x677934: mov             x1, x0
    // 0x677938: RestoreReg r0
    //     0x677938: ldr             x0, [SP], #8
    // 0x67793c: ldp             q0, q1, [SP], #0x20
    // 0x677940: b               #0x676c00
    // 0x677944: stp             q0, q2, [SP, #-0x20]!
    // 0x677948: stp             x2, x3, [SP, #-0x10]!
    // 0x67794c: SaveReg r0
    //     0x67794c: str             x0, [SP, #-8]!
    // 0x677950: r0 = AllocateDouble()
    //     0x677950: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x677954: mov             x1, x0
    // 0x677958: RestoreReg r0
    //     0x677958: ldr             x0, [SP], #8
    // 0x67795c: ldp             x2, x3, [SP], #0x10
    // 0x677960: ldp             q0, q2, [SP], #0x20
    // 0x677964: b               #0x676d40
    // 0x677968: r0 = NullCastErrorSharedWithFPURegs()
    //     0x677968: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67796c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67796c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x677970: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x677970: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x677974: r0 = StackOverflowSharedWithFPURegs()
    //     0x677974: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x677978: b               #0x676ef4
    // 0x67797c: stp             q0, q1, [SP, #-0x20]!
    // 0x677980: SaveReg r0
    //     0x677980: str             x0, [SP, #-8]!
    // 0x677984: r0 = AllocateDouble()
    //     0x677984: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x677988: mov             x1, x0
    // 0x67798c: RestoreReg r0
    //     0x67798c: ldr             x0, [SP], #8
    // 0x677990: ldp             q0, q1, [SP], #0x20
    // 0x677994: b               #0x676f84
    // 0x677998: r0 = NullCastErrorSharedWithFPURegs()
    //     0x677998: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67799c: stp             q1, q2, [SP, #-0x20]!
    // 0x6779a0: SaveReg r1
    //     0x6779a0: str             x1, [SP, #-8]!
    // 0x6779a4: r0 = AllocateDouble()
    //     0x6779a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6779a8: RestoreReg r1
    //     0x6779a8: ldr             x1, [SP], #8
    // 0x6779ac: ldp             q1, q2, [SP], #0x20
    // 0x6779b0: b               #0x677078
    // 0x6779b4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6779b4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6779b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6779b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6779bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6779bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6779c0: stp             q1, q2, [SP, #-0x20]!
    // 0x6779c4: SaveReg r3
    //     0x6779c4: str             x3, [SP, #-8]!
    // 0x6779c8: r0 = AllocateDouble()
    //     0x6779c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6779cc: RestoreReg r3
    //     0x6779cc: ldr             x3, [SP], #8
    // 0x6779d0: ldp             q1, q2, [SP], #0x20
    // 0x6779d4: b               #0x6771a8
    // 0x6779d8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6779d8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6779dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6779dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6779e0: r0 = StackOverflowSharedWithFPURegs()
    //     0x6779e0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6779e4: b               #0x677270
    // 0x6779e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6779e8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6779ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6779ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6779f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6779f0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6779f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6779f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6779f8: stp             q1, q2, [SP, #-0x20]!
    // 0x6779fc: SaveReg r1
    //     0x6779fc: str             x1, [SP, #-8]!
    // 0x677a00: r0 = AllocateDouble()
    //     0x677a00: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x677a04: RestoreReg r1
    //     0x677a04: ldr             x1, [SP], #8
    // 0x677a08: ldp             q1, q2, [SP], #0x20
    // 0x677a0c: b               #0x677454
    // 0x677a10: r0 = NullCastErrorSharedWithFPURegs()
    //     0x677a10: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x677a14: r0 = NullCastErrorSharedWithFPURegs()
    //     0x677a14: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x677a18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x677a18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x677a1c: stp             q3, q4, [SP, #-0x20]!
    // 0x677a20: stp             q1, q2, [SP, #-0x20]!
    // 0x677a24: SaveReg d0
    //     0x677a24: str             q0, [SP, #-0x10]!
    // 0x677a28: stp             x2, x4, [SP, #-0x10]!
    // 0x677a2c: SaveReg r0
    //     0x677a2c: str             x0, [SP, #-8]!
    // 0x677a30: r0 = AllocateDouble()
    //     0x677a30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x677a34: mov             x1, x0
    // 0x677a38: RestoreReg r0
    //     0x677a38: ldr             x0, [SP], #8
    // 0x677a3c: ldp             x2, x4, [SP], #0x10
    // 0x677a40: RestoreReg d0
    //     0x677a40: ldr             q0, [SP], #0x10
    // 0x677a44: ldp             q1, q2, [SP], #0x20
    // 0x677a48: ldp             q3, q4, [SP], #0x20
    // 0x677a4c: b               #0x677598
    // 0x677a50: stp             q1, q2, [SP, #-0x20]!
    // 0x677a54: SaveReg d0
    //     0x677a54: str             q0, [SP, #-0x10]!
    // 0x677a58: r0 = AllocateDouble()
    //     0x677a58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x677a5c: RestoreReg d0
    //     0x677a5c: ldr             q0, [SP], #0x10
    // 0x677a60: ldp             q1, q2, [SP], #0x20
    // 0x677a64: b               #0x67764c
    // 0x677a68: stp             q2, q3, [SP, #-0x20]!
    // 0x677a6c: stp             q0, q1, [SP, #-0x20]!
    // 0x677a70: SaveReg r0
    //     0x677a70: str             x0, [SP, #-8]!
    // 0x677a74: r0 = AllocateDouble()
    //     0x677a74: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x677a78: mov             x1, x0
    // 0x677a7c: RestoreReg r0
    //     0x677a7c: ldr             x0, [SP], #8
    // 0x677a80: ldp             q0, q1, [SP], #0x20
    // 0x677a84: ldp             q2, q3, [SP], #0x20
    // 0x677a88: b               #0x6776b8
    // 0x677a8c: stp             q2, q3, [SP, #-0x20]!
    // 0x677a90: stp             q0, q1, [SP, #-0x20]!
    // 0x677a94: r0 = AllocateDouble()
    //     0x677a94: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x677a98: ldp             q0, q1, [SP], #0x20
    // 0x677a9c: ldp             q2, q3, [SP], #0x20
    // 0x677aa0: b               #0x677758
  }
  _ _calculateTrailingGarbage(/* No info */) {
    // ** addr: 0x679f98, size: 0xf0
    // 0x679f98: EnterFrame
    //     0x679f98: stp             fp, lr, [SP, #-0x10]!
    //     0x679f9c: mov             fp, SP
    // 0x679fa0: AllocStack(0x10)
    //     0x679fa0: sub             SP, SP, #0x10
    // 0x679fa4: ldr             x0, [fp, #0x18]
    // 0x679fa8: LoadField: r1 = r0->field_5f
    //     0x679fa8: ldur            w1, [x0, #0x5f]
    // 0x679fac: DecompressPointer r1
    //     0x679fac: add             x1, x1, HEAP, lsl #32
    // 0x679fb0: mov             x0, x1
    // 0x679fb4: ldr             x3, [fp, #0x10]
    // 0x679fb8: r4 = 0
    //     0x679fb8: mov             x4, #0
    // 0x679fbc: stur            x4, [fp, #-0x10]
    // 0x679fc0: CheckStackOverflow
    //     0x679fc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x679fc4: cmp             SP, x16
    //     0x679fc8: b.ls            #0x67a078
    // 0x679fcc: cmp             w0, NULL
    // 0x679fd0: b.eq            #0x67a068
    // 0x679fd4: LoadField: r5 = r0->field_17
    //     0x679fd4: ldur            w5, [x0, #0x17]
    // 0x679fd8: DecompressPointer r5
    //     0x679fd8: add             x5, x5, HEAP, lsl #32
    // 0x679fdc: stur            x5, [fp, #-8]
    // 0x679fe0: cmp             w5, NULL
    // 0x679fe4: b.eq            #0x67a080
    // 0x679fe8: mov             x0, x5
    // 0x679fec: r2 = Null
    //     0x679fec: mov             x2, NULL
    // 0x679ff0: r1 = Null
    //     0x679ff0: mov             x1, NULL
    // 0x679ff4: r4 = LoadClassIdInstr(r0)
    //     0x679ff4: ldur            x4, [x0, #-1]
    //     0x679ff8: ubfx            x4, x4, #0xc, #0x14
    // 0x679ffc: sub             x4, x4, #0x7f9
    // 0x67a000: cmp             x4, #2
    // 0x67a004: b.ls            #0x67a01c
    // 0x67a008: r8 = SliverMultiBoxAdaptorParentData
    //     0x67a008: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67a00c: ldr             x8, [x8, #0x120]
    // 0x67a010: r3 = Null
    //     0x67a010: add             x3, PP, #0x57, lsl #12  ; [pp+0x57430] Null
    //     0x67a014: ldr             x3, [x3, #0x430]
    // 0x67a018: r0 = DefaultTypeTest()
    //     0x67a018: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67a01c: ldur            x1, [fp, #-8]
    // 0x67a020: LoadField: r2 = r1->field_17
    //     0x67a020: ldur            w2, [x1, #0x17]
    // 0x67a024: DecompressPointer r2
    //     0x67a024: add             x2, x2, HEAP, lsl #32
    // 0x67a028: cmp             w2, NULL
    // 0x67a02c: b.eq            #0x67a084
    // 0x67a030: r3 = LoadInt32Instr(r2)
    //     0x67a030: sbfx            x3, x2, #1, #0x1f
    //     0x67a034: tbz             w2, #0, #0x67a03c
    //     0x67a038: ldur            x3, [x2, #7]
    // 0x67a03c: ldr             x2, [fp, #0x10]
    // 0x67a040: cmp             x3, x2
    // 0x67a044: b.le            #0x67a060
    // 0x67a048: ldur            x0, [fp, #-0x10]
    // 0x67a04c: add             x4, x0, #1
    // 0x67a050: LoadField: r0 = r1->field_b
    //     0x67a050: ldur            w0, [x1, #0xb]
    // 0x67a054: DecompressPointer r0
    //     0x67a054: add             x0, x0, HEAP, lsl #32
    // 0x67a058: mov             x3, x2
    // 0x67a05c: b               #0x679fbc
    // 0x67a060: ldur            x0, [fp, #-0x10]
    // 0x67a064: b               #0x67a06c
    // 0x67a068: mov             x0, x4
    // 0x67a06c: LeaveFrame
    //     0x67a06c: mov             SP, fp
    //     0x67a070: ldp             fp, lr, [SP], #0x10
    // 0x67a074: ret
    //     0x67a074: ret             
    // 0x67a078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67a078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67a07c: b               #0x679fcc
    // 0x67a080: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67a080: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67a084: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67a084: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _calculateLeadingGarbage(/* No info */) {
    // ** addr: 0x67a088, size: 0xf0
    // 0x67a088: EnterFrame
    //     0x67a088: stp             fp, lr, [SP, #-0x10]!
    //     0x67a08c: mov             fp, SP
    // 0x67a090: AllocStack(0x10)
    //     0x67a090: sub             SP, SP, #0x10
    // 0x67a094: ldr             x0, [fp, #0x18]
    // 0x67a098: LoadField: r1 = r0->field_5b
    //     0x67a098: ldur            w1, [x0, #0x5b]
    // 0x67a09c: DecompressPointer r1
    //     0x67a09c: add             x1, x1, HEAP, lsl #32
    // 0x67a0a0: mov             x0, x1
    // 0x67a0a4: ldr             x3, [fp, #0x10]
    // 0x67a0a8: r4 = 0
    //     0x67a0a8: mov             x4, #0
    // 0x67a0ac: stur            x4, [fp, #-0x10]
    // 0x67a0b0: CheckStackOverflow
    //     0x67a0b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67a0b4: cmp             SP, x16
    //     0x67a0b8: b.ls            #0x67a168
    // 0x67a0bc: cmp             w0, NULL
    // 0x67a0c0: b.eq            #0x67a158
    // 0x67a0c4: LoadField: r5 = r0->field_17
    //     0x67a0c4: ldur            w5, [x0, #0x17]
    // 0x67a0c8: DecompressPointer r5
    //     0x67a0c8: add             x5, x5, HEAP, lsl #32
    // 0x67a0cc: stur            x5, [fp, #-8]
    // 0x67a0d0: cmp             w5, NULL
    // 0x67a0d4: b.eq            #0x67a170
    // 0x67a0d8: mov             x0, x5
    // 0x67a0dc: r2 = Null
    //     0x67a0dc: mov             x2, NULL
    // 0x67a0e0: r1 = Null
    //     0x67a0e0: mov             x1, NULL
    // 0x67a0e4: r4 = LoadClassIdInstr(r0)
    //     0x67a0e4: ldur            x4, [x0, #-1]
    //     0x67a0e8: ubfx            x4, x4, #0xc, #0x14
    // 0x67a0ec: sub             x4, x4, #0x7f9
    // 0x67a0f0: cmp             x4, #2
    // 0x67a0f4: b.ls            #0x67a10c
    // 0x67a0f8: r8 = SliverMultiBoxAdaptorParentData
    //     0x67a0f8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67a0fc: ldr             x8, [x8, #0x120]
    // 0x67a100: r3 = Null
    //     0x67a100: add             x3, PP, #0x57, lsl #12  ; [pp+0x57440] Null
    //     0x67a104: ldr             x3, [x3, #0x440]
    // 0x67a108: r0 = DefaultTypeTest()
    //     0x67a108: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67a10c: ldur            x1, [fp, #-8]
    // 0x67a110: LoadField: r2 = r1->field_17
    //     0x67a110: ldur            w2, [x1, #0x17]
    // 0x67a114: DecompressPointer r2
    //     0x67a114: add             x2, x2, HEAP, lsl #32
    // 0x67a118: cmp             w2, NULL
    // 0x67a11c: b.eq            #0x67a174
    // 0x67a120: r3 = LoadInt32Instr(r2)
    //     0x67a120: sbfx            x3, x2, #1, #0x1f
    //     0x67a124: tbz             w2, #0, #0x67a12c
    //     0x67a128: ldur            x3, [x2, #7]
    // 0x67a12c: ldr             x2, [fp, #0x10]
    // 0x67a130: cmp             x3, x2
    // 0x67a134: b.ge            #0x67a150
    // 0x67a138: ldur            x0, [fp, #-0x10]
    // 0x67a13c: add             x4, x0, #1
    // 0x67a140: LoadField: r0 = r1->field_f
    //     0x67a140: ldur            w0, [x1, #0xf]
    // 0x67a144: DecompressPointer r0
    //     0x67a144: add             x0, x0, HEAP, lsl #32
    // 0x67a148: mov             x3, x2
    // 0x67a14c: b               #0x67a0ac
    // 0x67a150: ldur            x0, [fp, #-0x10]
    // 0x67a154: b               #0x67a15c
    // 0x67a158: mov             x0, x4
    // 0x67a15c: LeaveFrame
    //     0x67a15c: mov             SP, fp
    //     0x67a160: ldp             fp, lr, [SP], #0x10
    // 0x67a164: ret
    //     0x67a164: ret             
    // 0x67a168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67a168: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67a16c: b               #0x67a0bc
    // 0x67a170: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67a170: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67a174: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67a174: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ pageSpacing=(/* No info */) {
    // ** addr: 0x6c1cc8, size: 0x60
    // 0x6c1cc8: EnterFrame
    //     0x6c1cc8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c1ccc: mov             fp, SP
    // 0x6c1cd0: d0 = 0.000000
    //     0x6c1cd0: eor             v0.16b, v0.16b, v0.16b
    // 0x6c1cd4: CheckStackOverflow
    //     0x6c1cd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c1cd8: cmp             SP, x16
    //     0x6c1cdc: b.ls            #0x6c1d20
    // 0x6c1ce0: fcmp            d0, d0
    // 0x6c1ce4: b.vs            #0x6c1cfc
    // 0x6c1ce8: b.ne            #0x6c1cfc
    // 0x6c1cec: r0 = Null
    //     0x6c1cec: mov             x0, NULL
    // 0x6c1cf0: LeaveFrame
    //     0x6c1cf0: mov             SP, fp
    //     0x6c1cf4: ldp             fp, lr, [SP], #0x10
    // 0x6c1cf8: ret
    //     0x6c1cf8: ret             
    // 0x6c1cfc: ldr             x0, [fp, #0x18]
    // 0x6c1d00: StoreField: r0->field_73 = d0
    //     0x6c1d00: stur            d0, [x0, #0x73]
    // 0x6c1d04: SaveReg r0
    //     0x6c1d04: str             x0, [SP, #-8]!
    // 0x6c1d08: r0 = markNeedsLayout()
    //     0x6c1d08: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x6c1d0c: add             SP, SP, #8
    // 0x6c1d10: r0 = Null
    //     0x6c1d10: mov             x0, NULL
    // 0x6c1d14: LeaveFrame
    //     0x6c1d14: mov             SP, fp
    //     0x6c1d18: ldp             fp, lr, [SP], #0x10
    // 0x6c1d1c: ret
    //     0x6c1d1c: ret             
    // 0x6c1d20: r0 = StackOverflowSharedWithFPURegs()
    //     0x6c1d20: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6c1d24: b               #0x6c1ce0
  }
  set _ viewportFraction=(/* No info */) {
    // ** addr: 0x6c1d28, size: 0x60
    // 0x6c1d28: EnterFrame
    //     0x6c1d28: stp             fp, lr, [SP, #-0x10]!
    //     0x6c1d2c: mov             fp, SP
    // 0x6c1d30: d0 = 1.000000
    //     0x6c1d30: fmov            d0, #1.00000000
    // 0x6c1d34: CheckStackOverflow
    //     0x6c1d34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c1d38: cmp             SP, x16
    //     0x6c1d3c: b.ls            #0x6c1d80
    // 0x6c1d40: fcmp            d0, d0
    // 0x6c1d44: b.vs            #0x6c1d5c
    // 0x6c1d48: b.ne            #0x6c1d5c
    // 0x6c1d4c: r0 = Null
    //     0x6c1d4c: mov             x0, NULL
    // 0x6c1d50: LeaveFrame
    //     0x6c1d50: mov             SP, fp
    //     0x6c1d54: ldp             fp, lr, [SP], #0x10
    // 0x6c1d58: ret
    //     0x6c1d58: ret             
    // 0x6c1d5c: ldr             x0, [fp, #0x18]
    // 0x6c1d60: StoreField: r0->field_6b = d0
    //     0x6c1d60: stur            d0, [x0, #0x6b]
    // 0x6c1d64: SaveReg r0
    //     0x6c1d64: str             x0, [SP, #-8]!
    // 0x6c1d68: r0 = markNeedsLayout()
    //     0x6c1d68: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x6c1d6c: add             SP, SP, #8
    // 0x6c1d70: r0 = Null
    //     0x6c1d70: mov             x0, NULL
    // 0x6c1d74: LeaveFrame
    //     0x6c1d74: mov             SP, fp
    //     0x6c1d78: ldp             fp, lr, [SP], #0x10
    // 0x6c1d7c: ret
    //     0x6c1d7c: ret             
    // 0x6c1d80: r0 = StackOverflowSharedWithFPURegs()
    //     0x6c1d80: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6c1d84: b               #0x6c1d40
  }
}

// lib: , url: package:extended_image/src/gesture/page_view/gesture_page_view.dart

// class id: 1048933, size: 0x8
class :: {

  static late final PageMetrics _testPageMetrics; // offset: 0xb98

  static PageMetrics _testPageMetrics() {
    // ** addr: 0x79ceb0, size: 0x50
    // 0x79ceb0: EnterFrame
    //     0x79ceb0: stp             fp, lr, [SP, #-0x10]!
    //     0x79ceb4: mov             fp, SP
    // 0x79ceb8: r0 = PageMetrics()
    //     0x79ceb8: bl              #0x79cf00  ; AllocatePageMetricsStub -> PageMetrics (size=0x24)
    // 0x79cebc: d0 = 1.000000
    //     0x79cebc: fmov            d0, #1.00000000
    // 0x79cec0: StoreField: r0->field_1b = d0
    //     0x79cec0: stur            d0, [x0, #0x1b]
    // 0x79cec4: r1 = Instance_AxisDirection
    //     0x79cec4: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cce0] Obj!AxisDirection@b64f71
    //     0x79cec8: ldr             x1, [x1, #0xce0]
    // 0x79cecc: StoreField: r0->field_17 = r1
    //     0x79cecc: stur            w1, [x0, #0x17]
    // 0x79ced0: r1 = 0.000000
    //     0x79ced0: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x79ced4: StoreField: r0->field_7 = r1
    //     0x79ced4: stur            w1, [x0, #7]
    // 0x79ced8: r1 = 10.000000
    //     0x79ced8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5b8] 10
    //     0x79cedc: ldr             x1, [x1, #0x5b8]
    // 0x79cee0: StoreField: r0->field_b = r1
    //     0x79cee0: stur            w1, [x0, #0xb]
    // 0x79cee4: r2 = 5.000000
    //     0x79cee4: add             x2, PP, #0x27, lsl #12  ; [pp+0x27190] 5
    //     0x79cee8: ldr             x2, [x2, #0x190]
    // 0x79ceec: StoreField: r0->field_f = r2
    //     0x79ceec: stur            w2, [x0, #0xf]
    // 0x79cef0: StoreField: r0->field_13 = r1
    //     0x79cef0: stur            w1, [x0, #0x13]
    // 0x79cef4: LeaveFrame
    //     0x79cef4: mov             SP, fp
    //     0x79cef8: ldp             fp, lr, [SP], #0x10
    // 0x79cefc: ret
    //     0x79cefc: ret             
  }
}

// class id: 3392, size: 0x68, field offset: 0x68
class _ExtendedScrollableState extends ScrollableState {

  _ setIgnorePointer(/* No info */) {
    // ** addr: 0xce1ce8, size: 0x64
    // 0xce1ce8: EnterFrame
    //     0xce1ce8: stp             fp, lr, [SP, #-0x10]!
    //     0xce1cec: mov             fp, SP
    // 0xce1cf0: ldr             x0, [fp, #0x18]
    // 0xce1cf4: LoadField: r1 = r0->field_b
    //     0xce1cf4: ldur            w1, [x0, #0xb]
    // 0xce1cf8: DecompressPointer r1
    //     0xce1cf8: add             x1, x1, HEAP, lsl #32
    // 0xce1cfc: cmp             w1, NULL
    // 0xce1d00: b.eq            #0xce1d48
    // 0xce1d04: mov             x0, x1
    // 0xce1d08: r2 = Null
    //     0xce1d08: mov             x2, NULL
    // 0xce1d0c: r1 = Null
    //     0xce1d0c: mov             x1, NULL
    // 0xce1d10: r4 = LoadClassIdInstr(r0)
    //     0xce1d10: ldur            x4, [x0, #-1]
    //     0xce1d14: ubfx            x4, x4, #0xc, #0x14
    // 0xce1d18: r17 = 4210
    //     0xce1d18: mov             x17, #0x1072
    // 0xce1d1c: cmp             x4, x17
    // 0xce1d20: b.eq            #0xce1d38
    // 0xce1d24: r8 = _Scrollable
    //     0xce1d24: add             x8, PP, #0x56, lsl #12  ; [pp+0x56f70] Type: _Scrollable
    //     0xce1d28: ldr             x8, [x8, #0xf70]
    // 0xce1d2c: r3 = Null
    //     0xce1d2c: add             x3, PP, #0x56, lsl #12  ; [pp+0x56f78] Null
    //     0xce1d30: ldr             x3, [x3, #0xf78]
    // 0xce1d34: r0 = DefaultTypeTest()
    //     0xce1d34: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xce1d38: r0 = Null
    //     0xce1d38: mov             x0, NULL
    // 0xce1d3c: LeaveFrame
    //     0xce1d3c: mov             SP, fp
    //     0xce1d40: ldp             fp, lr, [SP], #0x10
    // 0xce1d44: ret
    //     0xce1d44: ret             
    // 0xce1d48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce1d48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3393, size: 0x1c, field offset: 0x14
class _GesturePageViewState extends State<GesturePageView> {

  _ build(/* No info */) {
    // ** addr: 0x82f688, size: 0x1d0
    // 0x82f688: EnterFrame
    //     0x82f688: stp             fp, lr, [SP, #-0x10]!
    //     0x82f68c: mov             fp, SP
    // 0x82f690: AllocStack(0x30)
    //     0x82f690: sub             SP, SP, #0x30
    // 0x82f694: CheckStackOverflow
    //     0x82f694: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82f698: cmp             SP, x16
    //     0x82f69c: b.ls            #0x82f848
    // 0x82f6a0: r1 = 2
    //     0x82f6a0: mov             x1, #2
    // 0x82f6a4: r0 = AllocateContext()
    //     0x82f6a4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82f6a8: mov             x1, x0
    // 0x82f6ac: ldr             x0, [fp, #0x18]
    // 0x82f6b0: stur            x1, [fp, #-8]
    // 0x82f6b4: StoreField: r1->field_f = r0
    //     0x82f6b4: stur            w0, [x1, #0xf]
    // 0x82f6b8: ldr             x16, [fp, #0x10]
    // 0x82f6bc: stp             x16, x0, [SP, #-0x10]!
    // 0x82f6c0: r0 = _getDirection()
    //     0x82f6c0: bl              #0x82f920  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] _GesturePageViewState::_getDirection
    // 0x82f6c4: add             SP, SP, #0x10
    // 0x82f6c8: mov             x1, x0
    // 0x82f6cc: ldur            x2, [fp, #-8]
    // 0x82f6d0: stur            x1, [fp, #-0x18]
    // 0x82f6d4: StoreField: r2->field_13 = r0
    //     0x82f6d4: stur            w0, [x2, #0x13]
    //     0x82f6d8: ldurb           w16, [x2, #-1]
    //     0x82f6dc: ldurb           w17, [x0, #-1]
    //     0x82f6e0: and             x16, x17, x16, lsr #2
    //     0x82f6e4: tst             x16, HEAP, lsr #32
    //     0x82f6e8: b.eq            #0x82f6f0
    //     0x82f6ec: bl              #0xd6828c
    // 0x82f6f0: ldr             x0, [fp, #0x18]
    // 0x82f6f4: LoadField: r3 = r0->field_b
    //     0x82f6f4: ldur            w3, [x0, #0xb]
    // 0x82f6f8: DecompressPointer r3
    //     0x82f6f8: add             x3, x3, HEAP, lsl #32
    // 0x82f6fc: stur            x3, [fp, #-0x10]
    // 0x82f700: cmp             w3, NULL
    // 0x82f704: b.eq            #0x82f850
    // 0x82f708: r0 = _ForceImplicitScrollPhysics()
    //     0x82f708: bl              #0x82f914  ; Allocate_ForceImplicitScrollPhysicsStub -> _ForceImplicitScrollPhysics (size=0x10)
    // 0x82f70c: mov             x1, x0
    // 0x82f710: r0 = false
    //     0x82f710: add             x0, NULL, #0x30  ; false
    // 0x82f714: stur            x1, [fp, #-0x20]
    // 0x82f718: StoreField: r1->field_b = r0
    //     0x82f718: stur            w0, [x1, #0xb]
    // 0x82f71c: ldur            x2, [fp, #-0x10]
    // 0x82f720: LoadField: r3 = r2->field_1f
    //     0x82f720: ldur            w3, [x2, #0x1f]
    // 0x82f724: DecompressPointer r3
    //     0x82f724: add             x3, x3, HEAP, lsl #32
    // 0x82f728: r16 = Instance_PageScrollPhysics
    //     0x82f728: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f408] Obj!PageScrollPhysics@b4fdc1
    //     0x82f72c: ldr             x16, [x16, #0x408]
    // 0x82f730: stp             x3, x16, [SP, #-0x10]!
    // 0x82f734: r0 = applyTo()
    //     0x82f734: bl              #0xc3b304  ; [package:flutter/src/widgets/page_view.dart] PageScrollPhysics::applyTo
    // 0x82f738: add             SP, SP, #0x10
    // 0x82f73c: ldur            x16, [fp, #-0x20]
    // 0x82f740: stp             x0, x16, [SP, #-0x10]!
    // 0x82f744: r0 = applyTo()
    //     0x82f744: bl              #0xc3b17c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] _ForceImplicitScrollPhysics::applyTo
    // 0x82f748: add             SP, SP, #0x10
    // 0x82f74c: mov             x1, x0
    // 0x82f750: ldr             x0, [fp, #0x18]
    // 0x82f754: stur            x1, [fp, #-0x20]
    // 0x82f758: LoadField: r2 = r0->field_b
    //     0x82f758: ldur            w2, [x0, #0xb]
    // 0x82f75c: DecompressPointer r2
    //     0x82f75c: add             x2, x2, HEAP, lsl #32
    // 0x82f760: cmp             w2, NULL
    // 0x82f764: b.eq            #0x82f854
    // 0x82f768: LoadField: r0 = r2->field_1b
    //     0x82f768: ldur            w0, [x2, #0x1b]
    // 0x82f76c: DecompressPointer r0
    //     0x82f76c: add             x0, x0, HEAP, lsl #32
    // 0x82f770: stur            x0, [fp, #-0x10]
    // 0x82f774: ldr             x16, [fp, #0x10]
    // 0x82f778: SaveReg r16
    //     0x82f778: str             x16, [SP, #-8]!
    // 0x82f77c: r0 = of()
    //     0x82f77c: bl              #0x79d574  ; [package:flutter/src/widgets/scroll_configuration.dart] ScrollConfiguration::of
    // 0x82f780: add             SP, SP, #8
    // 0x82f784: r16 = false
    //     0x82f784: add             x16, NULL, #0x30  ; false
    // 0x82f788: stp             x16, x0, [SP, #-0x10]!
    // 0x82f78c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x82f78c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x82f790: r0 = copyWith()
    //     0x82f790: bl              #0x82f864  ; [package:flutter/src/widgets/scroll_configuration.dart] ScrollBehavior::copyWith
    // 0x82f794: add             SP, SP, #0x10
    // 0x82f798: stur            x0, [fp, #-0x28]
    // 0x82f79c: r0 = _Scrollable()
    //     0x82f79c: bl              #0x82f858  ; Allocate_ScrollableStub -> _Scrollable (size=0x3c)
    // 0x82f7a0: mov             x3, x0
    // 0x82f7a4: r0 = false
    //     0x82f7a4: add             x0, NULL, #0x30  ; false
    // 0x82f7a8: stur            x3, [fp, #-0x30]
    // 0x82f7ac: StoreField: r3->field_37 = r0
    //     0x82f7ac: stur            w0, [x3, #0x37]
    // 0x82f7b0: ldur            x1, [fp, #-0x18]
    // 0x82f7b4: StoreField: r3->field_b = r1
    //     0x82f7b4: stur            w1, [x3, #0xb]
    // 0x82f7b8: ldur            x1, [fp, #-0x10]
    // 0x82f7bc: StoreField: r3->field_f = r1
    //     0x82f7bc: stur            w1, [x3, #0xf]
    // 0x82f7c0: ldur            x1, [fp, #-0x20]
    // 0x82f7c4: StoreField: r3->field_13 = r1
    //     0x82f7c4: stur            w1, [x3, #0x13]
    // 0x82f7c8: ldur            x2, [fp, #-8]
    // 0x82f7cc: r1 = Function '<anonymous closure>':.
    //     0x82f7cc: add             x1, PP, #0x55, lsl #12  ; [pp+0x55c60] AnonymousClosure: (0x82fd98), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] _GesturePageViewState::build (0x82f688)
    //     0x82f7d0: ldr             x1, [x1, #0xc60]
    // 0x82f7d4: r0 = AllocateClosure()
    //     0x82f7d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82f7d8: mov             x1, x0
    // 0x82f7dc: ldur            x0, [fp, #-0x30]
    // 0x82f7e0: StoreField: r0->field_17 = r1
    //     0x82f7e0: stur            w1, [x0, #0x17]
    // 0x82f7e4: r1 = false
    //     0x82f7e4: add             x1, NULL, #0x30  ; false
    // 0x82f7e8: StoreField: r0->field_1f = r1
    //     0x82f7e8: stur            w1, [x0, #0x1f]
    // 0x82f7ec: r1 = Instance_DragStartBehavior
    //     0x82f7ec: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x82f7f0: ldr             x1, [x1, #0xf88]
    // 0x82f7f4: StoreField: r0->field_27 = r1
    //     0x82f7f4: stur            w1, [x0, #0x27]
    // 0x82f7f8: ldur            x1, [fp, #-0x28]
    // 0x82f7fc: StoreField: r0->field_2f = r1
    //     0x82f7fc: stur            w1, [x0, #0x2f]
    // 0x82f800: r1 = Instance_Clip
    //     0x82f800: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x82f804: ldr             x1, [x1, #0x678]
    // 0x82f808: StoreField: r0->field_33 = r1
    //     0x82f808: stur            w1, [x0, #0x33]
    // 0x82f80c: ldur            x2, [fp, #-8]
    // 0x82f810: r1 = Function '<anonymous closure>':.
    //     0x82f810: add             x1, PP, #0x55, lsl #12  ; [pp+0x55c68] AnonymousClosure: (0x82fa48), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] _GesturePageViewState::build (0x82f688)
    //     0x82f814: ldr             x1, [x1, #0xc68]
    // 0x82f818: r0 = AllocateClosure()
    //     0x82f818: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82f81c: r1 = <ScrollNotification>
    //     0x82f81c: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2ccf8] TypeArguments: <ScrollNotification>
    //     0x82f820: ldr             x1, [x1, #0xcf8]
    // 0x82f824: stur            x0, [fp, #-8]
    // 0x82f828: r0 = NotificationListener()
    //     0x82f828: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x82f82c: ldur            x1, [fp, #-8]
    // 0x82f830: StoreField: r0->field_13 = r1
    //     0x82f830: stur            w1, [x0, #0x13]
    // 0x82f834: ldur            x1, [fp, #-0x30]
    // 0x82f838: StoreField: r0->field_b = r1
    //     0x82f838: stur            w1, [x0, #0xb]
    // 0x82f83c: LeaveFrame
    //     0x82f83c: mov             SP, fp
    //     0x82f840: ldp             fp, lr, [SP], #0x10
    // 0x82f844: ret
    //     0x82f844: ret             
    // 0x82f848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f848: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f84c: b               #0x82f6a0
    // 0x82f850: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f850: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82f854: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f854: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getDirection(/* No info */) {
    // ** addr: 0x82f920, size: 0x128
    // 0x82f920: EnterFrame
    //     0x82f920: stp             fp, lr, [SP, #-0x10]!
    //     0x82f924: mov             fp, SP
    // 0x82f928: CheckStackOverflow
    //     0x82f928: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82f92c: cmp             SP, x16
    //     0x82f930: b.ls            #0x82fa38
    // 0x82f934: ldr             x0, [fp, #0x18]
    // 0x82f938: LoadField: r1 = r0->field_b
    //     0x82f938: ldur            w1, [x0, #0xb]
    // 0x82f93c: DecompressPointer r1
    //     0x82f93c: add             x1, x1, HEAP, lsl #32
    // 0x82f940: cmp             w1, NULL
    // 0x82f944: b.eq            #0x82fa40
    // 0x82f948: LoadField: r2 = r1->field_13
    //     0x82f948: ldur            w2, [x1, #0x13]
    // 0x82f94c: DecompressPointer r2
    //     0x82f94c: add             x2, x2, HEAP, lsl #32
    // 0x82f950: LoadField: r3 = r2->field_7
    //     0x82f950: ldur            x3, [x2, #7]
    // 0x82f954: cmp             x3, #0
    // 0x82f958: b.gt            #0x82fa0c
    // 0x82f95c: ldr             x16, [fp, #0x10]
    // 0x82f960: SaveReg r16
    //     0x82f960: str             x16, [SP, #-8]!
    // 0x82f964: r0 = of()
    //     0x82f964: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x82f968: add             SP, SP, #8
    // 0x82f96c: LoadField: r2 = r0->field_7
    //     0x82f96c: ldur            x2, [x0, #7]
    // 0x82f970: cmp             x2, #0
    // 0x82f974: b.gt            #0x82f984
    // 0x82f978: r3 = Instance_AxisDirection
    //     0x82f978: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1c578] Obj!AxisDirection@b64f51
    //     0x82f97c: ldr             x3, [x3, #0x578]
    // 0x82f980: b               #0x82f98c
    // 0x82f984: r3 = Instance_AxisDirection
    //     0x82f984: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2ccd8] Obj!AxisDirection@b64f11
    //     0x82f988: ldr             x3, [x3, #0xcd8]
    // 0x82f98c: ldr             x2, [fp, #0x18]
    // 0x82f990: LoadField: r4 = r2->field_b
    //     0x82f990: ldur            w4, [x2, #0xb]
    // 0x82f994: DecompressPointer r4
    //     0x82f994: add             x4, x4, HEAP, lsl #32
    // 0x82f998: cmp             w4, NULL
    // 0x82f99c: b.eq            #0x82fa44
    // 0x82f9a0: LoadField: r2 = r4->field_17
    //     0x82f9a0: ldur            w2, [x4, #0x17]
    // 0x82f9a4: DecompressPointer r2
    //     0x82f9a4: add             x2, x2, HEAP, lsl #32
    // 0x82f9a8: tbnz            w2, #4, #0x82f9fc
    // 0x82f9ac: LoadField: r2 = r3->field_7
    //     0x82f9ac: ldur            x2, [x3, #7]
    // 0x82f9b0: cmp             x2, #1
    // 0x82f9b4: b.gt            #0x82f9d8
    // 0x82f9b8: cmp             x2, #0
    // 0x82f9bc: b.gt            #0x82f9cc
    // 0x82f9c0: r2 = Instance_AxisDirection
    //     0x82f9c0: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2cce0] Obj!AxisDirection@b64f71
    //     0x82f9c4: ldr             x2, [x2, #0xce0]
    // 0x82f9c8: b               #0x82f9f4
    // 0x82f9cc: r2 = Instance_AxisDirection
    //     0x82f9cc: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c578] Obj!AxisDirection@b64f51
    //     0x82f9d0: ldr             x2, [x2, #0x578]
    // 0x82f9d4: b               #0x82f9f4
    // 0x82f9d8: cmp             x2, #2
    // 0x82f9dc: b.gt            #0x82f9ec
    // 0x82f9e0: r2 = Instance_AxisDirection
    //     0x82f9e0: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2cce8] Obj!AxisDirection@b64f31
    //     0x82f9e4: ldr             x2, [x2, #0xce8]
    // 0x82f9e8: b               #0x82f9f4
    // 0x82f9ec: r2 = Instance_AxisDirection
    //     0x82f9ec: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2ccd8] Obj!AxisDirection@b64f11
    //     0x82f9f0: ldr             x2, [x2, #0xcd8]
    // 0x82f9f4: mov             x0, x2
    // 0x82f9f8: b               #0x82fa00
    // 0x82f9fc: mov             x0, x3
    // 0x82fa00: LeaveFrame
    //     0x82fa00: mov             SP, fp
    //     0x82fa04: ldp             fp, lr, [SP], #0x10
    // 0x82fa08: ret
    //     0x82fa08: ret             
    // 0x82fa0c: LoadField: r2 = r1->field_17
    //     0x82fa0c: ldur            w2, [x1, #0x17]
    // 0x82fa10: DecompressPointer r2
    //     0x82fa10: add             x2, x2, HEAP, lsl #32
    // 0x82fa14: tbnz            w2, #4, #0x82fa24
    // 0x82fa18: r0 = Instance_AxisDirection
    //     0x82fa18: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cce8] Obj!AxisDirection@b64f31
    //     0x82fa1c: ldr             x0, [x0, #0xce8]
    // 0x82fa20: b               #0x82fa2c
    // 0x82fa24: r0 = Instance_AxisDirection
    //     0x82fa24: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cce0] Obj!AxisDirection@b64f71
    //     0x82fa28: ldr             x0, [x0, #0xce0]
    // 0x82fa2c: LeaveFrame
    //     0x82fa2c: mov             SP, fp
    //     0x82fa30: ldp             fp, lr, [SP], #0x10
    // 0x82fa34: ret
    //     0x82fa34: ret             
    // 0x82fa38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82fa38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82fa3c: b               #0x82f934
    // 0x82fa40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82fa40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82fa44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82fa44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, ScrollNotification) {
    // ** addr: 0x82fa48, size: 0x1c4
    // 0x82fa48: EnterFrame
    //     0x82fa48: stp             fp, lr, [SP, #-0x10]!
    //     0x82fa4c: mov             fp, SP
    // 0x82fa50: AllocStack(0x10)
    //     0x82fa50: sub             SP, SP, #0x10
    // 0x82fa54: SetupParameters()
    //     0x82fa54: ldr             x0, [fp, #0x18]
    //     0x82fa58: ldur            w3, [x0, #0x17]
    //     0x82fa5c: add             x3, x3, HEAP, lsl #32
    //     0x82fa60: stur            x3, [fp, #-0x10]
    // 0x82fa64: CheckStackOverflow
    //     0x82fa64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82fa68: cmp             SP, x16
    //     0x82fa6c: b.ls            #0x82fbdc
    // 0x82fa70: ldr             x0, [fp, #0x10]
    // 0x82fa74: LoadField: r1 = r0->field_7
    //     0x82fa74: ldur            x1, [x0, #7]
    // 0x82fa78: cbnz            x1, #0x82fbcc
    // 0x82fa7c: LoadField: r1 = r3->field_f
    //     0x82fa7c: ldur            w1, [x3, #0xf]
    // 0x82fa80: DecompressPointer r1
    //     0x82fa80: add             x1, x1, HEAP, lsl #32
    // 0x82fa84: LoadField: r2 = r1->field_b
    //     0x82fa84: ldur            w2, [x1, #0xb]
    // 0x82fa88: DecompressPointer r2
    //     0x82fa88: add             x2, x2, HEAP, lsl #32
    // 0x82fa8c: cmp             w2, NULL
    // 0x82fa90: b.eq            #0x82fbe4
    // 0x82fa94: r1 = LoadClassIdInstr(r0)
    //     0x82fa94: ldur            x1, [x0, #-1]
    //     0x82fa98: ubfx            x1, x1, #0xc, #0x14
    // 0x82fa9c: lsl             x1, x1, #1
    // 0x82faa0: r2 = LoadInt32Instr(r1)
    //     0x82faa0: sbfx            x2, x1, #1, #0x1f
    // 0x82faa4: cmp             x2, #0x731
    // 0x82faa8: b.lt            #0x82fbcc
    // 0x82faac: cmp             x2, #0x732
    // 0x82fab0: b.gt            #0x82fbcc
    // 0x82fab4: LoadField: r4 = r0->field_f
    //     0x82fab4: ldur            w4, [x0, #0xf]
    // 0x82fab8: DecompressPointer r4
    //     0x82fab8: add             x4, x4, HEAP, lsl #32
    // 0x82fabc: mov             x0, x4
    // 0x82fac0: stur            x4, [fp, #-8]
    // 0x82fac4: r2 = Null
    //     0x82fac4: mov             x2, NULL
    // 0x82fac8: r1 = Null
    //     0x82fac8: mov             x1, NULL
    // 0x82facc: r4 = LoadClassIdInstr(r0)
    //     0x82facc: ldur            x4, [x0, #-1]
    //     0x82fad0: ubfx            x4, x4, #0xc, #0x14
    // 0x82fad4: cmp             x4, #0x6ac
    // 0x82fad8: b.eq            #0x82fb08
    // 0x82fadc: r17 = 4847
    //     0x82fadc: mov             x17, #0x12ef
    // 0x82fae0: cmp             x4, x17
    // 0x82fae4: b.eq            #0x82fb08
    // 0x82fae8: r17 = 4850
    //     0x82fae8: mov             x17, #0x12f2
    // 0x82faec: cmp             x4, x17
    // 0x82faf0: b.eq            #0x82fb08
    // 0x82faf4: r8 = PageMetrics
    //     0x82faf4: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4ca40] Type: PageMetrics
    //     0x82faf8: ldr             x8, [x8, #0xa40]
    // 0x82fafc: r3 = Null
    //     0x82fafc: add             x3, PP, #0x55, lsl #12  ; [pp+0x55c70] Null
    //     0x82fb00: ldr             x3, [x3, #0xc70]
    // 0x82fb04: r0 = DefaultTypeTest()
    //     0x82fb04: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x82fb08: ldur            x16, [fp, #-8]
    // 0x82fb0c: SaveReg r16
    //     0x82fb0c: str             x16, [SP, #-8]!
    // 0x82fb10: r0 = page()
    //     0x82fb10: bl              #0x82fc0c  ; [package:flutter/src/widgets/page_view.dart] PageMetrics::page
    // 0x82fb14: add             SP, SP, #8
    // 0x82fb18: LoadField: d0 = r0->field_7
    //     0x82fb18: ldur            d0, [x0, #7]
    // 0x82fb1c: stp             fp, lr, [SP, #-0x10]!
    // 0x82fb20: mov             fp, SP
    // 0x82fb24: CallRuntime_LibcRound(double) -> double
    //     0x82fb24: and             SP, SP, #0xfffffffffffffff0
    //     0x82fb28: mov             sp, SP
    //     0x82fb2c: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x82fb30: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x82fb34: blr             x16
    //     0x82fb38: mov             x16, #8
    //     0x82fb3c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x82fb40: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x82fb44: sub             sp, x16, #1, lsl #12
    //     0x82fb48: mov             SP, fp
    //     0x82fb4c: ldp             fp, lr, [SP], #0x10
    // 0x82fb50: fcmp            d0, d0
    // 0x82fb54: b.vs            #0x82fbe8
    // 0x82fb58: fcvtzs          x0, d0
    // 0x82fb5c: asr             x16, x0, #0x1e
    // 0x82fb60: cmp             x16, x0, asr #63
    // 0x82fb64: b.ne            #0x82fbe8
    // 0x82fb68: lsl             x0, x0, #1
    // 0x82fb6c: ldur            x1, [fp, #-0x10]
    // 0x82fb70: LoadField: r2 = r1->field_f
    //     0x82fb70: ldur            w2, [x1, #0xf]
    // 0x82fb74: DecompressPointer r2
    //     0x82fb74: add             x2, x2, HEAP, lsl #32
    // 0x82fb78: LoadField: r1 = r2->field_13
    //     0x82fb78: ldur            x1, [x2, #0x13]
    // 0x82fb7c: r3 = LoadInt32Instr(r0)
    //     0x82fb7c: sbfx            x3, x0, #1, #0x1f
    //     0x82fb80: tbz             w0, #0, #0x82fb88
    //     0x82fb84: ldur            x3, [x0, #7]
    // 0x82fb88: cmp             x3, x1
    // 0x82fb8c: b.eq            #0x82fbcc
    // 0x82fb90: StoreField: r2->field_13 = r3
    //     0x82fb90: stur            x3, [x2, #0x13]
    // 0x82fb94: LoadField: r1 = r2->field_b
    //     0x82fb94: ldur            w1, [x2, #0xb]
    // 0x82fb98: DecompressPointer r1
    //     0x82fb98: add             x1, x1, HEAP, lsl #32
    // 0x82fb9c: cmp             w1, NULL
    // 0x82fba0: b.eq            #0x82fc04
    // 0x82fba4: LoadField: r2 = r1->field_27
    //     0x82fba4: ldur            w2, [x1, #0x27]
    // 0x82fba8: DecompressPointer r2
    //     0x82fba8: add             x2, x2, HEAP, lsl #32
    // 0x82fbac: cmp             w2, NULL
    // 0x82fbb0: b.eq            #0x82fc08
    // 0x82fbb4: stp             x0, x2, [SP, #-0x10]!
    // 0x82fbb8: mov             x0, x2
    // 0x82fbbc: ClosureCall
    //     0x82fbbc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x82fbc0: ldur            x2, [x0, #0x1f]
    //     0x82fbc4: blr             x2
    // 0x82fbc8: add             SP, SP, #0x10
    // 0x82fbcc: r0 = false
    //     0x82fbcc: add             x0, NULL, #0x30  ; false
    // 0x82fbd0: LeaveFrame
    //     0x82fbd0: mov             SP, fp
    //     0x82fbd4: ldp             fp, lr, [SP], #0x10
    // 0x82fbd8: ret
    //     0x82fbd8: ret             
    // 0x82fbdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82fbdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82fbe0: b               #0x82fa70
    // 0x82fbe4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82fbe4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82fbe8: SaveReg d0
    //     0x82fbe8: str             q0, [SP, #-0x10]!
    // 0x82fbec: r0 = 218
    //     0x82fbec: mov             x0, #0xda
    // 0x82fbf0: r24 = DoubleToIntegerStub
    //     0x82fbf0: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x82fbf4: LoadField: r30 = r24->field_7
    //     0x82fbf4: ldur            lr, [x24, #7]
    // 0x82fbf8: blr             lr
    // 0x82fbfc: RestoreReg d0
    //     0x82fbfc: ldr             q0, [SP], #0x10
    // 0x82fc00: b               #0x82fb6c
    // 0x82fc04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82fc04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82fc08: r0 = NullErrorSharedWithoutFPURegs()
    //     0x82fc08: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] Viewport <anonymous closure>(dynamic, BuildContext, ViewportOffset) {
    // ** addr: 0x82fd98, size: 0x110
    // 0x82fd98: EnterFrame
    //     0x82fd98: stp             fp, lr, [SP, #-0x10]!
    //     0x82fd9c: mov             fp, SP
    // 0x82fda0: AllocStack(0x18)
    //     0x82fda0: sub             SP, SP, #0x18
    // 0x82fda4: SetupParameters()
    //     0x82fda4: ldr             x0, [fp, #0x20]
    //     0x82fda8: ldur            w1, [x0, #0x17]
    //     0x82fdac: add             x1, x1, HEAP, lsl #32
    //     0x82fdb0: stur            x1, [fp, #-0x10]
    // 0x82fdb4: LoadField: r0 = r1->field_f
    //     0x82fdb4: ldur            w0, [x1, #0xf]
    // 0x82fdb8: DecompressPointer r0
    //     0x82fdb8: add             x0, x0, HEAP, lsl #32
    // 0x82fdbc: LoadField: r2 = r0->field_b
    //     0x82fdbc: ldur            w2, [x0, #0xb]
    // 0x82fdc0: DecompressPointer r2
    //     0x82fdc0: add             x2, x2, HEAP, lsl #32
    // 0x82fdc4: cmp             w2, NULL
    // 0x82fdc8: b.eq            #0x82fea4
    // 0x82fdcc: LoadField: r0 = r2->field_2b
    //     0x82fdcc: ldur            w0, [x2, #0x2b]
    // 0x82fdd0: DecompressPointer r0
    //     0x82fdd0: add             x0, x0, HEAP, lsl #32
    // 0x82fdd4: stur            x0, [fp, #-8]
    // 0x82fdd8: r0 = ExtendedSliverFillViewport()
    //     0x82fdd8: bl              #0x82feb4  ; AllocateExtendedSliverFillViewportStub -> ExtendedSliverFillViewport (size=0x24)
    // 0x82fddc: mov             x3, x0
    // 0x82fde0: ldur            x0, [fp, #-8]
    // 0x82fde4: stur            x3, [fp, #-0x18]
    // 0x82fde8: StoreField: r3->field_17 = r0
    //     0x82fde8: stur            w0, [x3, #0x17]
    // 0x82fdec: d0 = 1.000000
    //     0x82fdec: fmov            d0, #1.00000000
    // 0x82fdf0: StoreField: r3->field_b = d0
    //     0x82fdf0: stur            d0, [x3, #0xb]
    // 0x82fdf4: r0 = true
    //     0x82fdf4: add             x0, NULL, #0x20  ; true
    // 0x82fdf8: StoreField: r3->field_13 = r0
    //     0x82fdf8: stur            w0, [x3, #0x13]
    // 0x82fdfc: d0 = 0.000000
    //     0x82fdfc: eor             v0.16b, v0.16b, v0.16b
    // 0x82fe00: StoreField: r3->field_1b = d0
    //     0x82fe00: stur            d0, [x3, #0x1b]
    // 0x82fe04: r1 = Null
    //     0x82fe04: mov             x1, NULL
    // 0x82fe08: r2 = 2
    //     0x82fe08: mov             x2, #2
    // 0x82fe0c: r0 = AllocateArray()
    //     0x82fe0c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x82fe10: mov             x2, x0
    // 0x82fe14: ldur            x0, [fp, #-0x18]
    // 0x82fe18: stur            x2, [fp, #-8]
    // 0x82fe1c: StoreField: r2->field_f = r0
    //     0x82fe1c: stur            w0, [x2, #0xf]
    // 0x82fe20: r1 = <Widget>
    //     0x82fe20: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x82fe24: ldr             x1, [x1, #0xea8]
    // 0x82fe28: r0 = AllocateGrowableArray()
    //     0x82fe28: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x82fe2c: mov             x1, x0
    // 0x82fe30: ldur            x0, [fp, #-8]
    // 0x82fe34: stur            x1, [fp, #-0x18]
    // 0x82fe38: StoreField: r1->field_f = r0
    //     0x82fe38: stur            w0, [x1, #0xf]
    // 0x82fe3c: r0 = 2
    //     0x82fe3c: mov             x0, #2
    // 0x82fe40: StoreField: r1->field_b = r0
    //     0x82fe40: stur            w0, [x1, #0xb]
    // 0x82fe44: ldur            x0, [fp, #-0x10]
    // 0x82fe48: LoadField: r2 = r0->field_13
    //     0x82fe48: ldur            w2, [x0, #0x13]
    // 0x82fe4c: DecompressPointer r2
    //     0x82fe4c: add             x2, x2, HEAP, lsl #32
    // 0x82fe50: stur            x2, [fp, #-8]
    // 0x82fe54: r0 = Viewport()
    //     0x82fe54: bl              #0x82fea8  ; AllocateViewportStub -> Viewport (size=0x34)
    // 0x82fe58: ldur            x1, [fp, #-8]
    // 0x82fe5c: StoreField: r0->field_f = r1
    //     0x82fe5c: stur            w1, [x0, #0xf]
    // 0x82fe60: d0 = 0.000000
    //     0x82fe60: eor             v0.16b, v0.16b, v0.16b
    // 0x82fe64: StoreField: r0->field_17 = d0
    //     0x82fe64: stur            d0, [x0, #0x17]
    // 0x82fe68: ldr             x1, [fp, #0x10]
    // 0x82fe6c: StoreField: r0->field_1f = r1
    //     0x82fe6c: stur            w1, [x0, #0x1f]
    // 0x82fe70: r1 = 0.000000
    //     0x82fe70: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x82fe74: StoreField: r0->field_27 = r1
    //     0x82fe74: stur            w1, [x0, #0x27]
    // 0x82fe78: r1 = Instance_CacheExtentStyle
    //     0x82fe78: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c018] Obj!CacheExtentStyle@b64731
    //     0x82fe7c: ldr             x1, [x1, #0x18]
    // 0x82fe80: StoreField: r0->field_2b = r1
    //     0x82fe80: stur            w1, [x0, #0x2b]
    // 0x82fe84: r1 = Instance_Clip
    //     0x82fe84: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x82fe88: ldr             x1, [x1, #0x678]
    // 0x82fe8c: StoreField: r0->field_2f = r1
    //     0x82fe8c: stur            w1, [x0, #0x2f]
    // 0x82fe90: ldur            x1, [fp, #-0x18]
    // 0x82fe94: StoreField: r0->field_b = r1
    //     0x82fe94: stur            w1, [x0, #0xb]
    // 0x82fe98: LeaveFrame
    //     0x82fe98: mov             SP, fp
    //     0x82fe9c: ldp             fp, lr, [SP], #0x10
    // 0x82fea0: ret
    //     0x82fea0: ret             
    // 0x82fea4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82fea4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d6310, size: 0x40
    // 0x9d6310: EnterFrame
    //     0x9d6310: stp             fp, lr, [SP, #-0x10]!
    //     0x9d6314: mov             fp, SP
    // 0x9d6318: ldr             x1, [fp, #0x10]
    // 0x9d631c: LoadField: r2 = r1->field_b
    //     0x9d631c: ldur            w2, [x1, #0xb]
    // 0x9d6320: DecompressPointer r2
    //     0x9d6320: add             x2, x2, HEAP, lsl #32
    // 0x9d6324: cmp             w2, NULL
    // 0x9d6328: b.eq            #0x9d634c
    // 0x9d632c: LoadField: r3 = r2->field_1b
    //     0x9d632c: ldur            w3, [x2, #0x1b]
    // 0x9d6330: DecompressPointer r3
    //     0x9d6330: add             x3, x3, HEAP, lsl #32
    // 0x9d6334: LoadField: r2 = r3->field_3b
    //     0x9d6334: ldur            x2, [x3, #0x3b]
    // 0x9d6338: StoreField: r1->field_13 = r2
    //     0x9d6338: stur            x2, [x1, #0x13]
    // 0x9d633c: r0 = Null
    //     0x9d633c: mov             x0, NULL
    // 0x9d6340: LeaveFrame
    //     0x9d6340: mov             SP, fp
    //     0x9d6344: ldp             fp, lr, [SP], #0x10
    // 0x9d6348: ret
    //     0x9d6348: ret             
    // 0x9d634c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d634c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3394, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class _ExtendedImageGesturePageViewState&State&SingleTickerProviderStateMixin extends State<ExtendedImageGesturePageView>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x613c58, size: 0x98
    // 0x613c58: EnterFrame
    //     0x613c58: stp             fp, lr, [SP, #-0x10]!
    //     0x613c5c: mov             fp, SP
    // 0x613c60: CheckStackOverflow
    //     0x613c60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613c64: cmp             SP, x16
    //     0x613c68: b.ls            #0x613ce4
    // 0x613c6c: r0 = Ticker()
    //     0x613c6c: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x613c70: mov             x1, x0
    // 0x613c74: r0 = false
    //     0x613c74: add             x0, NULL, #0x30  ; false
    // 0x613c78: StoreField: r1->field_b = r0
    //     0x613c78: stur            w0, [x1, #0xb]
    // 0x613c7c: ldr             x0, [fp, #0x10]
    // 0x613c80: StoreField: r1->field_13 = r0
    //     0x613c80: stur            w0, [x1, #0x13]
    // 0x613c84: mov             x0, x1
    // 0x613c88: ldr             x1, [fp, #0x18]
    // 0x613c8c: StoreField: r1->field_13 = r0
    //     0x613c8c: stur            w0, [x1, #0x13]
    //     0x613c90: ldurb           w16, [x1, #-1]
    //     0x613c94: ldurb           w17, [x0, #-1]
    //     0x613c98: and             x16, x17, x16, lsr #2
    //     0x613c9c: tst             x16, HEAP, lsr #32
    //     0x613ca0: b.eq            #0x613ca8
    //     0x613ca4: bl              #0xd6826c
    // 0x613ca8: SaveReg r1
    //     0x613ca8: str             x1, [SP, #-8]!
    // 0x613cac: r0 = _updateTickerModeNotifier()
    //     0x613cac: bl              #0x613d14  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] _ExtendedImageGesturePageViewState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x613cb0: add             SP, SP, #8
    // 0x613cb4: ldr             x16, [fp, #0x18]
    // 0x613cb8: SaveReg r16
    //     0x613cb8: str             x16, [SP, #-8]!
    // 0x613cbc: r0 = _updateTicker()
    //     0x613cbc: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x613cc0: add             SP, SP, #8
    // 0x613cc4: ldr             x1, [fp, #0x18]
    // 0x613cc8: LoadField: r0 = r1->field_13
    //     0x613cc8: ldur            w0, [x1, #0x13]
    // 0x613ccc: DecompressPointer r0
    //     0x613ccc: add             x0, x0, HEAP, lsl #32
    // 0x613cd0: cmp             w0, NULL
    // 0x613cd4: b.eq            #0x613cec
    // 0x613cd8: LeaveFrame
    //     0x613cd8: mov             SP, fp
    //     0x613cdc: ldp             fp, lr, [SP], #0x10
    // 0x613ce0: ret
    //     0x613ce0: ret             
    // 0x613ce4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613ce4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613ce8: b               #0x613c6c
    // 0x613cec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x613cec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x613d14, size: 0x11c
    // 0x613d14: EnterFrame
    //     0x613d14: stp             fp, lr, [SP, #-0x10]!
    //     0x613d18: mov             fp, SP
    // 0x613d1c: AllocStack(0x10)
    //     0x613d1c: sub             SP, SP, #0x10
    // 0x613d20: CheckStackOverflow
    //     0x613d20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613d24: cmp             SP, x16
    //     0x613d28: b.ls            #0x613e24
    // 0x613d2c: ldr             x0, [fp, #0x10]
    // 0x613d30: LoadField: r1 = r0->field_f
    //     0x613d30: ldur            w1, [x0, #0xf]
    // 0x613d34: DecompressPointer r1
    //     0x613d34: add             x1, x1, HEAP, lsl #32
    // 0x613d38: cmp             w1, NULL
    // 0x613d3c: b.eq            #0x613e2c
    // 0x613d40: SaveReg r1
    //     0x613d40: str             x1, [SP, #-8]!
    // 0x613d44: r0 = getNotifier()
    //     0x613d44: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x613d48: add             SP, SP, #8
    // 0x613d4c: mov             x1, x0
    // 0x613d50: ldr             x0, [fp, #0x10]
    // 0x613d54: stur            x1, [fp, #-0x10]
    // 0x613d58: LoadField: r2 = r0->field_17
    //     0x613d58: ldur            w2, [x0, #0x17]
    // 0x613d5c: DecompressPointer r2
    //     0x613d5c: add             x2, x2, HEAP, lsl #32
    // 0x613d60: stur            x2, [fp, #-8]
    // 0x613d64: cmp             w1, w2
    // 0x613d68: b.ne            #0x613d7c
    // 0x613d6c: r0 = Null
    //     0x613d6c: mov             x0, NULL
    // 0x613d70: LeaveFrame
    //     0x613d70: mov             SP, fp
    //     0x613d74: ldp             fp, lr, [SP], #0x10
    // 0x613d78: ret
    //     0x613d78: ret             
    // 0x613d7c: cmp             w2, NULL
    // 0x613d80: b.eq            #0x613dbc
    // 0x613d84: r1 = 1
    //     0x613d84: mov             x1, #1
    // 0x613d88: r0 = AllocateContext()
    //     0x613d88: bl              #0xd68aa4  ; AllocateContextStub
    // 0x613d8c: mov             x1, x0
    // 0x613d90: ldr             x0, [fp, #0x10]
    // 0x613d94: StoreField: r1->field_f = r0
    //     0x613d94: stur            w0, [x1, #0xf]
    // 0x613d98: mov             x2, x1
    // 0x613d9c: r1 = Function '_updateTicker@156311458':.
    //     0x613d9c: add             x1, PP, #0x51, lsl #12  ; [pp+0x513c0] AnonymousClosure: (0x613e30), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x613da0: ldr             x1, [x1, #0x3c0]
    // 0x613da4: r0 = AllocateClosure()
    //     0x613da4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x613da8: ldur            x16, [fp, #-8]
    // 0x613dac: stp             x0, x16, [SP, #-0x10]!
    // 0x613db0: r0 = removeListener()
    //     0x613db0: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x613db4: add             SP, SP, #0x10
    // 0x613db8: ldr             x0, [fp, #0x10]
    // 0x613dbc: r1 = 1
    //     0x613dbc: mov             x1, #1
    // 0x613dc0: r0 = AllocateContext()
    //     0x613dc0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x613dc4: mov             x1, x0
    // 0x613dc8: ldr             x0, [fp, #0x10]
    // 0x613dcc: StoreField: r1->field_f = r0
    //     0x613dcc: stur            w0, [x1, #0xf]
    // 0x613dd0: mov             x2, x1
    // 0x613dd4: r1 = Function '_updateTicker@156311458':.
    //     0x613dd4: add             x1, PP, #0x51, lsl #12  ; [pp+0x513c0] AnonymousClosure: (0x613e30), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x613dd8: ldr             x1, [x1, #0x3c0]
    // 0x613ddc: r0 = AllocateClosure()
    //     0x613ddc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x613de0: ldur            x16, [fp, #-0x10]
    // 0x613de4: stp             x0, x16, [SP, #-0x10]!
    // 0x613de8: r0 = addListener()
    //     0x613de8: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x613dec: add             SP, SP, #0x10
    // 0x613df0: ldur            x0, [fp, #-0x10]
    // 0x613df4: ldr             x1, [fp, #0x10]
    // 0x613df8: StoreField: r1->field_17 = r0
    //     0x613df8: stur            w0, [x1, #0x17]
    //     0x613dfc: ldurb           w16, [x1, #-1]
    //     0x613e00: ldurb           w17, [x0, #-1]
    //     0x613e04: and             x16, x17, x16, lsr #2
    //     0x613e08: tst             x16, HEAP, lsr #32
    //     0x613e0c: b.eq            #0x613e14
    //     0x613e10: bl              #0xd6826c
    // 0x613e14: r0 = Null
    //     0x613e14: mov             x0, NULL
    // 0x613e18: LeaveFrame
    //     0x613e18: mov             SP, fp
    //     0x613e1c: ldp             fp, lr, [SP], #0x10
    // 0x613e20: ret
    //     0x613e20: ret             
    // 0x613e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613e24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613e28: b               #0x613d2c
    // 0x613e2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x613e2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x613e30, size: 0x48
    // 0x613e30: EnterFrame
    //     0x613e30: stp             fp, lr, [SP, #-0x10]!
    //     0x613e34: mov             fp, SP
    // 0x613e38: ldr             x0, [fp, #0x10]
    // 0x613e3c: LoadField: r1 = r0->field_17
    //     0x613e3c: ldur            w1, [x0, #0x17]
    // 0x613e40: DecompressPointer r1
    //     0x613e40: add             x1, x1, HEAP, lsl #32
    // 0x613e44: CheckStackOverflow
    //     0x613e44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613e48: cmp             SP, x16
    //     0x613e4c: b.ls            #0x613e70
    // 0x613e50: LoadField: r0 = r1->field_f
    //     0x613e50: ldur            w0, [x1, #0xf]
    // 0x613e54: DecompressPointer r0
    //     0x613e54: add             x0, x0, HEAP, lsl #32
    // 0x613e58: SaveReg r0
    //     0x613e58: str             x0, [SP, #-8]!
    // 0x613e5c: r0 = _updateTicker()
    //     0x613e5c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x613e60: add             SP, SP, #8
    // 0x613e64: LeaveFrame
    //     0x613e64: mov             SP, fp
    //     0x613e68: ldp             fp, lr, [SP], #0x10
    // 0x613e6c: ret
    //     0x613e6c: ret             
    // 0x613e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613e70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613e74: b               #0x613e50
  }
  _ activate(/* No info */) {
    // ** addr: 0x81ef50, size: 0x4c
    // 0x81ef50: EnterFrame
    //     0x81ef50: stp             fp, lr, [SP, #-0x10]!
    //     0x81ef54: mov             fp, SP
    // 0x81ef58: CheckStackOverflow
    //     0x81ef58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81ef5c: cmp             SP, x16
    //     0x81ef60: b.ls            #0x81ef94
    // 0x81ef64: ldr             x16, [fp, #0x10]
    // 0x81ef68: SaveReg r16
    //     0x81ef68: str             x16, [SP, #-8]!
    // 0x81ef6c: r0 = _updateTickerModeNotifier()
    //     0x81ef6c: bl              #0x613d14  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] _ExtendedImageGesturePageViewState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81ef70: add             SP, SP, #8
    // 0x81ef74: ldr             x16, [fp, #0x10]
    // 0x81ef78: SaveReg r16
    //     0x81ef78: str             x16, [SP, #-8]!
    // 0x81ef7c: r0 = _updateTicker()
    //     0x81ef7c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81ef80: add             SP, SP, #8
    // 0x81ef84: r0 = Null
    //     0x81ef84: mov             x0, NULL
    // 0x81ef88: LeaveFrame
    //     0x81ef88: mov             SP, fp
    //     0x81ef8c: ldp             fp, lr, [SP], #0x10
    // 0x81ef90: ret
    //     0x81ef90: ret             
    // 0x81ef94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81ef94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81ef98: b               #0x81ef64
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4f0ec, size: 0x8c
    // 0xa4f0ec: EnterFrame
    //     0xa4f0ec: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f0f0: mov             fp, SP
    // 0xa4f0f4: AllocStack(0x8)
    //     0xa4f0f4: sub             SP, SP, #8
    // 0xa4f0f8: CheckStackOverflow
    //     0xa4f0f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f0fc: cmp             SP, x16
    //     0xa4f100: b.ls            #0xa4f170
    // 0xa4f104: ldr             x0, [fp, #0x10]
    // 0xa4f108: LoadField: r1 = r0->field_17
    //     0xa4f108: ldur            w1, [x0, #0x17]
    // 0xa4f10c: DecompressPointer r1
    //     0xa4f10c: add             x1, x1, HEAP, lsl #32
    // 0xa4f110: stur            x1, [fp, #-8]
    // 0xa4f114: cmp             w1, NULL
    // 0xa4f118: b.ne            #0xa4f124
    // 0xa4f11c: mov             x1, x0
    // 0xa4f120: b               #0xa4f15c
    // 0xa4f124: r1 = 1
    //     0xa4f124: mov             x1, #1
    // 0xa4f128: r0 = AllocateContext()
    //     0xa4f128: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4f12c: mov             x1, x0
    // 0xa4f130: ldr             x0, [fp, #0x10]
    // 0xa4f134: StoreField: r1->field_f = r0
    //     0xa4f134: stur            w0, [x1, #0xf]
    // 0xa4f138: mov             x2, x1
    // 0xa4f13c: r1 = Function '_updateTicker@156311458':.
    //     0xa4f13c: add             x1, PP, #0x51, lsl #12  ; [pp+0x513c0] AnonymousClosure: (0x613e30), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa4f140: ldr             x1, [x1, #0x3c0]
    // 0xa4f144: r0 = AllocateClosure()
    //     0xa4f144: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4f148: ldur            x16, [fp, #-8]
    // 0xa4f14c: stp             x0, x16, [SP, #-0x10]!
    // 0xa4f150: r0 = removeListener()
    //     0xa4f150: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4f154: add             SP, SP, #0x10
    // 0xa4f158: ldr             x1, [fp, #0x10]
    // 0xa4f15c: StoreField: r1->field_17 = rNULL
    //     0xa4f15c: stur            NULL, [x1, #0x17]
    // 0xa4f160: r0 = Null
    //     0xa4f160: mov             x0, NULL
    // 0xa4f164: LeaveFrame
    //     0xa4f164: mov             SP, fp
    //     0xa4f168: ldp             fp, lr, [SP], #0x10
    // 0xa4f16c: ret
    //     0xa4f16c: ret             
    // 0xa4f170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f170: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f174: b               #0xa4f104
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4f178, size: 0x48
    // 0xa4f178: EnterFrame
    //     0xa4f178: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f17c: mov             fp, SP
    // 0xa4f180: ldr             x0, [fp, #0x10]
    // 0xa4f184: LoadField: r1 = r0->field_17
    //     0xa4f184: ldur            w1, [x0, #0x17]
    // 0xa4f188: DecompressPointer r1
    //     0xa4f188: add             x1, x1, HEAP, lsl #32
    // 0xa4f18c: CheckStackOverflow
    //     0xa4f18c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f190: cmp             SP, x16
    //     0xa4f194: b.ls            #0xa4f1b8
    // 0xa4f198: LoadField: r0 = r1->field_f
    //     0xa4f198: ldur            w0, [x1, #0xf]
    // 0xa4f19c: DecompressPointer r0
    //     0xa4f19c: add             x0, x0, HEAP, lsl #32
    // 0xa4f1a0: SaveReg r0
    //     0xa4f1a0: str             x0, [SP, #-8]!
    // 0xa4f1a4: r0 = dispose()
    //     0xa4f1a4: bl              #0xa4f0ec  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] _ExtendedImageGesturePageViewState&State&SingleTickerProviderStateMixin::dispose
    // 0xa4f1a8: add             SP, SP, #8
    // 0xa4f1ac: LeaveFrame
    //     0xa4f1ac: mov             SP, fp
    //     0xa4f1b0: ldp             fp, lr, [SP], #0x10
    // 0xa4f1b4: ret
    //     0xa4f1b4: ret             
    // 0xa4f1b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f1b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f1bc: b               #0xa4f198
  }
}

// class id: 3395, size: 0x34, field offset: 0x1c
class ExtendedImageGesturePageViewState extends _ExtendedImageGesturePageViewState&State&SingleTickerProviderStateMixin {

  late GestureAnimation _gestureAnimation; // offset: 0x24

  set _ extendedImageGestureState=(/* No info */) {
    // ** addr: 0x79b608, size: 0x68
    // 0x79b608: EnterFrame
    //     0x79b608: stp             fp, lr, [SP, #-0x10]!
    //     0x79b60c: mov             fp, SP
    // 0x79b610: CheckStackOverflow
    //     0x79b610: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79b614: cmp             SP, x16
    //     0x79b618: b.ls            #0x79b668
    // 0x79b61c: ldr             x0, [fp, #0x10]
    // 0x79b620: LoadField: r1 = r0->field_f
    //     0x79b620: ldur            w1, [x0, #0xf]
    // 0x79b624: DecompressPointer r1
    //     0x79b624: add             x1, x1, HEAP, lsl #32
    // 0x79b628: cmp             w1, NULL
    // 0x79b62c: b.ne            #0x79b640
    // 0x79b630: r0 = Null
    //     0x79b630: mov             x0, NULL
    // 0x79b634: LeaveFrame
    //     0x79b634: mov             SP, fp
    //     0x79b638: ldp             fp, lr, [SP], #0x10
    // 0x79b63c: ret
    //     0x79b63c: ret             
    // 0x79b640: ldr             x1, [fp, #0x18]
    // 0x79b644: LoadField: r2 = r1->field_27
    //     0x79b644: ldur            w2, [x1, #0x27]
    // 0x79b648: DecompressPointer r2
    //     0x79b648: add             x2, x2, HEAP, lsl #32
    // 0x79b64c: stp             x0, x2, [SP, #-0x10]!
    // 0x79b650: r0 = add()
    //     0x79b650: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x79b654: add             SP, SP, #0x10
    // 0x79b658: r0 = Null
    //     0x79b658: mov             x0, NULL
    // 0x79b65c: LeaveFrame
    //     0x79b65c: mov             SP, fp
    //     0x79b660: ldp             fp, lr, [SP], #0x10
    // 0x79b664: ret
    //     0x79b664: ret             
    // 0x79b668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79b668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79b66c: b               #0x79b61c
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x79c24c, size: 0xc0
    // 0x79c24c: EnterFrame
    //     0x79c24c: stp             fp, lr, [SP, #-0x10]!
    //     0x79c250: mov             fp, SP
    // 0x79c254: CheckStackOverflow
    //     0x79c254: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79c258: cmp             SP, x16
    //     0x79c25c: b.ls            #0x79c304
    // 0x79c260: ldr             x0, [fp, #0x10]
    // 0x79c264: r2 = Null
    //     0x79c264: mov             x2, NULL
    // 0x79c268: r1 = Null
    //     0x79c268: mov             x1, NULL
    // 0x79c26c: r4 = 59
    //     0x79c26c: mov             x4, #0x3b
    // 0x79c270: branchIfSmi(r0, 0x79c27c)
    //     0x79c270: tbz             w0, #0, #0x79c27c
    // 0x79c274: r4 = LoadClassIdInstr(r0)
    //     0x79c274: ldur            x4, [x0, #-1]
    //     0x79c278: ubfx            x4, x4, #0xc, #0x14
    // 0x79c27c: r17 = 4212
    //     0x79c27c: mov             x17, #0x1074
    // 0x79c280: cmp             x4, x17
    // 0x79c284: b.eq            #0x79c29c
    // 0x79c288: r8 = ExtendedImageGesturePageView
    //     0x79c288: add             x8, PP, #0x51, lsl #12  ; [pp+0x513d8] Type: ExtendedImageGesturePageView
    //     0x79c28c: ldr             x8, [x8, #0x3d8]
    // 0x79c290: r3 = Null
    //     0x79c290: add             x3, PP, #0x51, lsl #12  ; [pp+0x513e0] Null
    //     0x79c294: ldr             x3, [x3, #0x3e0]
    // 0x79c298: r0 = ExtendedImageGesturePageView()
    //     0x79c298: bl              #0x613cf0  ; IsType_ExtendedImageGesturePageView_Stub
    // 0x79c29c: ldr             x16, [fp, #0x18]
    // 0x79c2a0: ldr             lr, [fp, #0x10]
    // 0x79c2a4: stp             lr, x16, [SP, #-0x10]!
    // 0x79c2a8: r4 = const [0, 0x2, 0x2, 0x1, oldWidget, 0x1, null]
    //     0x79c2a8: add             x4, PP, #0x28, lsl #12  ; [pp+0x28228] List(7) [0, 0x2, 0x2, 0x1, "oldWidget", 0x1, Null]
    //     0x79c2ac: ldr             x4, [x4, #0x228]
    // 0x79c2b0: r0 = _initGestureRecognizers()
    //     0x79c2b0: bl              #0x79c30c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::_initGestureRecognizers
    // 0x79c2b4: add             SP, SP, #0x10
    // 0x79c2b8: ldr             x0, [fp, #0x18]
    // 0x79c2bc: LoadField: r2 = r0->field_7
    //     0x79c2bc: ldur            w2, [x0, #7]
    // 0x79c2c0: DecompressPointer r2
    //     0x79c2c0: add             x2, x2, HEAP, lsl #32
    // 0x79c2c4: ldr             x0, [fp, #0x10]
    // 0x79c2c8: r1 = Null
    //     0x79c2c8: mov             x1, NULL
    // 0x79c2cc: cmp             w2, NULL
    // 0x79c2d0: b.eq            #0x79c2f4
    // 0x79c2d4: LoadField: r4 = r2->field_17
    //     0x79c2d4: ldur            w4, [x2, #0x17]
    // 0x79c2d8: DecompressPointer r4
    //     0x79c2d8: add             x4, x4, HEAP, lsl #32
    // 0x79c2dc: r8 = X0 bound StatefulWidget
    //     0x79c2dc: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x79c2e0: ldr             x8, [x8, #0x858]
    // 0x79c2e4: LoadField: r9 = r4->field_7
    //     0x79c2e4: ldur            x9, [x4, #7]
    // 0x79c2e8: r3 = Null
    //     0x79c2e8: add             x3, PP, #0x51, lsl #12  ; [pp+0x513f0] Null
    //     0x79c2ec: ldr             x3, [x3, #0x3f0]
    // 0x79c2f0: blr             x9
    // 0x79c2f4: r0 = Null
    //     0x79c2f4: mov             x0, NULL
    // 0x79c2f8: LeaveFrame
    //     0x79c2f8: mov             SP, fp
    //     0x79c2fc: ldp             fp, lr, [SP], #0x10
    // 0x79c300: ret
    //     0x79c300: ret             
    // 0x79c304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79c304: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79c308: b               #0x79c260
  }
  _ _initGestureRecognizers(/* No info */) {
    // ** addr: 0x79c30c, size: 0x33c
    // 0x79c30c: EnterFrame
    //     0x79c30c: stp             fp, lr, [SP, #-0x10]!
    //     0x79c310: mov             fp, SP
    // 0x79c314: AllocStack(0x20)
    //     0x79c314: sub             SP, SP, #0x20
    // 0x79c318: SetupParameters(ExtendedImageGesturePageViewState<ExtendedImageGesturePageView> this /* r3, fp-0x10 */, {dynamic oldWidget = Null /* r0, fp-0x8 */})
    //     0x79c318: mov             x0, x4
    //     0x79c31c: ldur            w1, [x0, #0x13]
    //     0x79c320: add             x1, x1, HEAP, lsl #32
    //     0x79c324: sub             x2, x1, #2
    //     0x79c328: add             x3, fp, w2, sxtw #2
    //     0x79c32c: ldr             x3, [x3, #0x10]
    //     0x79c330: stur            x3, [fp, #-0x10]
    //     0x79c334: ldur            w2, [x0, #0x1f]
    //     0x79c338: add             x2, x2, HEAP, lsl #32
    //     0x79c33c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28230] "oldWidget"
    //     0x79c340: ldr             x16, [x16, #0x230]
    //     0x79c344: cmp             w2, w16
    //     0x79c348: b.ne            #0x79c368
    //     0x79c34c: ldur            w2, [x0, #0x23]
    //     0x79c350: add             x2, x2, HEAP, lsl #32
    //     0x79c354: sub             w0, w1, w2
    //     0x79c358: add             x1, fp, w0, sxtw #2
    //     0x79c35c: ldr             x1, [x1, #8]
    //     0x79c360: mov             x0, x1
    //     0x79c364: b               #0x79c36c
    //     0x79c368: mov             x0, NULL
    //     0x79c36c: stur            x0, [fp, #-8]
    // 0x79c370: CheckStackOverflow
    //     0x79c370: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79c374: cmp             SP, x16
    //     0x79c378: b.ls            #0x79c62c
    // 0x79c37c: r1 = 1
    //     0x79c37c: mov             x1, #1
    // 0x79c380: r0 = AllocateContext()
    //     0x79c380: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79c384: mov             x2, x0
    // 0x79c388: ldur            x1, [fp, #-0x10]
    // 0x79c38c: stur            x2, [fp, #-0x18]
    // 0x79c390: StoreField: r2->field_f = r1
    //     0x79c390: stur            w1, [x2, #0xf]
    // 0x79c394: ldur            x0, [fp, #-8]
    // 0x79c398: cmp             w0, NULL
    // 0x79c39c: b.ne            #0x79c3a8
    // 0x79c3a0: mov             x0, x1
    // 0x79c3a4: b               #0x79c400
    // 0x79c3a8: LoadField: r3 = r1->field_b
    //     0x79c3a8: ldur            w3, [x1, #0xb]
    // 0x79c3ac: DecompressPointer r3
    //     0x79c3ac: add             x3, x3, HEAP, lsl #32
    // 0x79c3b0: cmp             w3, NULL
    // 0x79c3b4: b.eq            #0x79c634
    // 0x79c3b8: LoadField: r4 = r0->field_1b
    //     0x79c3b8: ldur            w4, [x0, #0x1b]
    // 0x79c3bc: DecompressPointer r4
    //     0x79c3bc: add             x4, x4, HEAP, lsl #32
    // 0x79c3c0: LoadField: r0 = r4->field_7
    //     0x79c3c0: ldur            w0, [x4, #7]
    // 0x79c3c4: DecompressPointer r0
    //     0x79c3c4: add             x0, x0, HEAP, lsl #32
    // 0x79c3c8: LoadField: r4 = r3->field_1b
    //     0x79c3c8: ldur            w4, [x3, #0x1b]
    // 0x79c3cc: DecompressPointer r4
    //     0x79c3cc: add             x4, x4, HEAP, lsl #32
    // 0x79c3d0: LoadField: r3 = r4->field_7
    //     0x79c3d0: ldur            w3, [x4, #7]
    // 0x79c3d4: DecompressPointer r3
    //     0x79c3d4: add             x3, x3, HEAP, lsl #32
    // 0x79c3d8: r4 = LoadClassIdInstr(r0)
    //     0x79c3d8: ldur            x4, [x0, #-1]
    //     0x79c3dc: ubfx            x4, x4, #0xc, #0x14
    // 0x79c3e0: stp             x3, x0, [SP, #-0x10]!
    // 0x79c3e4: mov             x0, x4
    // 0x79c3e8: mov             lr, x0
    // 0x79c3ec: ldr             lr, [x21, lr, lsl #3]
    // 0x79c3f0: blr             lr
    // 0x79c3f4: add             SP, SP, #0x10
    // 0x79c3f8: tbz             w0, #4, #0x79c608
    // 0x79c3fc: ldur            x0, [fp, #-0x10]
    // 0x79c400: LoadField: r1 = r0->field_b
    //     0x79c400: ldur            w1, [x0, #0xb]
    // 0x79c404: DecompressPointer r1
    //     0x79c404: add             x1, x1, HEAP, lsl #32
    // 0x79c408: cmp             w1, NULL
    // 0x79c40c: b.eq            #0x79c638
    // 0x79c410: LoadField: r2 = r1->field_1b
    //     0x79c410: ldur            w2, [x1, #0x1b]
    // 0x79c414: DecompressPointer r2
    //     0x79c414: add             x2, x2, HEAP, lsl #32
    // 0x79c418: LoadField: r1 = r2->field_7
    //     0x79c418: ldur            w1, [x2, #7]
    // 0x79c41c: DecompressPointer r1
    //     0x79c41c: add             x1, x1, HEAP, lsl #32
    // 0x79c420: stur            x1, [fp, #-8]
    // 0x79c424: cmp             w1, NULL
    // 0x79c428: b.eq            #0x79c478
    // 0x79c42c: r0 = InitLateStaticField(0xb98) // [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ::_testPageMetrics
    //     0x79c42c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x79c430: ldr             x0, [x0, #0x1730]
    //     0x79c434: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x79c438: cmp             w0, w16
    //     0x79c43c: b.ne            #0x79c44c
    //     0x79c440: add             x2, PP, #0x51, lsl #12  ; [pp+0x513d0] Field <::._testPageMetrics@410206143>: static late final (offset: 0xb98)
    //     0x79c444: ldr             x2, [x2, #0x3d0]
    //     0x79c448: bl              #0xd67cdc
    // 0x79c44c: mov             x1, x0
    // 0x79c450: ldur            x0, [fp, #-8]
    // 0x79c454: r2 = LoadClassIdInstr(r0)
    //     0x79c454: ldur            x2, [x0, #-1]
    //     0x79c458: ubfx            x2, x2, #0xc, #0x14
    // 0x79c45c: stp             x1, x0, [SP, #-0x10]!
    // 0x79c460: mov             x0, x2
    // 0x79c464: r0 = GDT[cid_x0 + 0x72d]()
    //     0x79c464: add             lr, x0, #0x72d
    //     0x79c468: ldr             lr, [x21, lr, lsl #3]
    //     0x79c46c: blr             lr
    // 0x79c470: add             SP, SP, #0x10
    // 0x79c474: tbnz            w0, #4, #0x79c61c
    // 0x79c478: ldur            x0, [fp, #-0x10]
    // 0x79c47c: LoadField: r1 = r0->field_b
    //     0x79c47c: ldur            w1, [x0, #0xb]
    // 0x79c480: DecompressPointer r1
    //     0x79c480: add             x1, x1, HEAP, lsl #32
    // 0x79c484: cmp             w1, NULL
    // 0x79c488: b.eq            #0x79c63c
    // 0x79c48c: LoadField: r2 = r1->field_f
    //     0x79c48c: ldur            w2, [x1, #0xf]
    // 0x79c490: DecompressPointer r2
    //     0x79c490: add             x2, x2, HEAP, lsl #32
    // 0x79c494: LoadField: r1 = r2->field_7
    //     0x79c494: ldur            x1, [x2, #7]
    // 0x79c498: cmp             x1, #0
    // 0x79c49c: b.gt            #0x79c54c
    // 0x79c4a0: r1 = Null
    //     0x79c4a0: mov             x1, NULL
    // 0x79c4a4: r2 = 4
    //     0x79c4a4: mov             x2, #4
    // 0x79c4a8: r0 = AllocateArray()
    //     0x79c4a8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x79c4ac: stur            x0, [fp, #-8]
    // 0x79c4b0: r17 = ExtendedHorizontalDragGestureRecognizer
    //     0x79c4b0: add             x17, PP, #0x51, lsl #12  ; [pp+0x51400] Type: ExtendedHorizontalDragGestureRecognizer
    //     0x79c4b4: ldr             x17, [x17, #0x400]
    // 0x79c4b8: StoreField: r0->field_f = r17
    //     0x79c4b8: stur            w17, [x0, #0xf]
    // 0x79c4bc: r1 = <ExtendedHorizontalDragGestureRecognizer>
    //     0x79c4bc: add             x1, PP, #0x51, lsl #12  ; [pp+0x51408] TypeArguments: <ExtendedHorizontalDragGestureRecognizer>
    //     0x79c4c0: ldr             x1, [x1, #0x408]
    // 0x79c4c4: r0 = GestureRecognizerFactoryWithHandlers()
    //     0x79c4c4: bl              #0x79c648  ; AllocateGestureRecognizerFactoryWithHandlersStub -> GestureRecognizerFactoryWithHandlers<X0 bound GestureRecognizer> (size=0x14)
    // 0x79c4c8: ldur            x2, [fp, #-0x18]
    // 0x79c4cc: r1 = Function '<anonymous closure>':.
    //     0x79c4cc: add             x1, PP, #0x51, lsl #12  ; [pp+0x51410] AnonymousClosure: (0x79cd90), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::_initGestureRecognizers (0x79c30c)
    //     0x79c4d0: ldr             x1, [x1, #0x410]
    // 0x79c4d4: stur            x0, [fp, #-0x20]
    // 0x79c4d8: r0 = AllocateClosure()
    //     0x79c4d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79c4dc: mov             x1, x0
    // 0x79c4e0: ldur            x0, [fp, #-0x20]
    // 0x79c4e4: StoreField: r0->field_b = r1
    //     0x79c4e4: stur            w1, [x0, #0xb]
    // 0x79c4e8: ldur            x2, [fp, #-0x18]
    // 0x79c4ec: r1 = Function '<anonymous closure>':.
    //     0x79c4ec: add             x1, PP, #0x51, lsl #12  ; [pp+0x51418] AnonymousClosure: (0x79c654), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::_initGestureRecognizers (0x79c30c)
    //     0x79c4f0: ldr             x1, [x1, #0x418]
    // 0x79c4f4: r0 = AllocateClosure()
    //     0x79c4f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79c4f8: mov             x1, x0
    // 0x79c4fc: ldur            x0, [fp, #-0x20]
    // 0x79c500: StoreField: r0->field_f = r1
    //     0x79c500: stur            w1, [x0, #0xf]
    // 0x79c504: ldur            x1, [fp, #-8]
    // 0x79c508: StoreField: r1->field_13 = r0
    //     0x79c508: stur            w0, [x1, #0x13]
    // 0x79c50c: r16 = <Type, GestureRecognizerFactory<GestureRecognizer>>
    //     0x79c50c: add             x16, PP, #0x21, lsl #12  ; [pp+0x213a0] TypeArguments: <Type, GestureRecognizerFactory<GestureRecognizer>>
    //     0x79c510: ldr             x16, [x16, #0x3a0]
    // 0x79c514: stp             x1, x16, [SP, #-0x10]!
    // 0x79c518: r0 = Map._fromLiteral()
    //     0x79c518: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x79c51c: add             SP, SP, #0x10
    // 0x79c520: ldur            x3, [fp, #-0x10]
    // 0x79c524: StoreField: r3->field_1f = r0
    //     0x79c524: stur            w0, [x3, #0x1f]
    //     0x79c528: tbz             w0, #0, #0x79c544
    //     0x79c52c: ldurb           w16, [x3, #-1]
    //     0x79c530: ldurb           w17, [x0, #-1]
    //     0x79c534: and             x16, x17, x16, lsr #2
    //     0x79c538: tst             x16, HEAP, lsr #32
    //     0x79c53c: b.eq            #0x79c544
    //     0x79c540: bl              #0xd682ac
    // 0x79c544: mov             x1, x3
    // 0x79c548: b               #0x79c5f4
    // 0x79c54c: mov             x3, x0
    // 0x79c550: r1 = Null
    //     0x79c550: mov             x1, NULL
    // 0x79c554: r2 = 4
    //     0x79c554: mov             x2, #4
    // 0x79c558: r0 = AllocateArray()
    //     0x79c558: bl              #0xd6987c  ; AllocateArrayStub
    // 0x79c55c: stur            x0, [fp, #-8]
    // 0x79c560: r17 = ExtendedVerticalDragGestureRecognizer
    //     0x79c560: add             x17, PP, #0x51, lsl #12  ; [pp+0x51420] Type: ExtendedVerticalDragGestureRecognizer
    //     0x79c564: ldr             x17, [x17, #0x420]
    // 0x79c568: StoreField: r0->field_f = r17
    //     0x79c568: stur            w17, [x0, #0xf]
    // 0x79c56c: r1 = <ExtendedVerticalDragGestureRecognizer>
    //     0x79c56c: add             x1, PP, #0x51, lsl #12  ; [pp+0x51428] TypeArguments: <ExtendedVerticalDragGestureRecognizer>
    //     0x79c570: ldr             x1, [x1, #0x428]
    // 0x79c574: r0 = GestureRecognizerFactoryWithHandlers()
    //     0x79c574: bl              #0x79c648  ; AllocateGestureRecognizerFactoryWithHandlersStub -> GestureRecognizerFactoryWithHandlers<X0 bound GestureRecognizer> (size=0x14)
    // 0x79c578: ldur            x2, [fp, #-0x18]
    // 0x79c57c: r1 = Function '<anonymous closure>':.
    //     0x79c57c: add             x1, PP, #0x51, lsl #12  ; [pp+0x51430] AnonymousClosure: (0x79ca78), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::_initGestureRecognizers (0x79c30c)
    //     0x79c580: ldr             x1, [x1, #0x430]
    // 0x79c584: stur            x0, [fp, #-0x20]
    // 0x79c588: r0 = AllocateClosure()
    //     0x79c588: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79c58c: mov             x1, x0
    // 0x79c590: ldur            x0, [fp, #-0x20]
    // 0x79c594: StoreField: r0->field_b = r1
    //     0x79c594: stur            w1, [x0, #0xb]
    // 0x79c598: ldur            x2, [fp, #-0x18]
    // 0x79c59c: r1 = Function '<anonymous closure>':.
    //     0x79c59c: add             x1, PP, #0x51, lsl #12  ; [pp+0x51438] AnonymousClosure: (0x79c654), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::_initGestureRecognizers (0x79c30c)
    //     0x79c5a0: ldr             x1, [x1, #0x438]
    // 0x79c5a4: r0 = AllocateClosure()
    //     0x79c5a4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79c5a8: mov             x1, x0
    // 0x79c5ac: ldur            x0, [fp, #-0x20]
    // 0x79c5b0: StoreField: r0->field_f = r1
    //     0x79c5b0: stur            w1, [x0, #0xf]
    // 0x79c5b4: ldur            x1, [fp, #-8]
    // 0x79c5b8: StoreField: r1->field_13 = r0
    //     0x79c5b8: stur            w0, [x1, #0x13]
    // 0x79c5bc: r16 = <Type, GestureRecognizerFactory<GestureRecognizer>>
    //     0x79c5bc: add             x16, PP, #0x21, lsl #12  ; [pp+0x213a0] TypeArguments: <Type, GestureRecognizerFactory<GestureRecognizer>>
    //     0x79c5c0: ldr             x16, [x16, #0x3a0]
    // 0x79c5c4: stp             x1, x16, [SP, #-0x10]!
    // 0x79c5c8: r0 = Map._fromLiteral()
    //     0x79c5c8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x79c5cc: add             SP, SP, #0x10
    // 0x79c5d0: ldur            x1, [fp, #-0x10]
    // 0x79c5d4: StoreField: r1->field_1f = r0
    //     0x79c5d4: stur            w0, [x1, #0x1f]
    //     0x79c5d8: tbz             w0, #0, #0x79c5f4
    //     0x79c5dc: ldurb           w16, [x1, #-1]
    //     0x79c5e0: ldurb           w17, [x0, #-1]
    //     0x79c5e4: and             x16, x17, x16, lsr #2
    //     0x79c5e8: tst             x16, HEAP, lsr #32
    //     0x79c5ec: b.eq            #0x79c5f4
    //     0x79c5f0: bl              #0xd6826c
    // 0x79c5f4: LoadField: r2 = r1->field_b
    //     0x79c5f4: ldur            w2, [x1, #0xb]
    // 0x79c5f8: DecompressPointer r2
    //     0x79c5f8: add             x2, x2, HEAP, lsl #32
    // 0x79c5fc: cmp             w2, NULL
    // 0x79c600: b.eq            #0x79c640
    // 0x79c604: b               #0x79c61c
    // 0x79c608: ldur            x1, [fp, #-0x10]
    // 0x79c60c: LoadField: r2 = r1->field_b
    //     0x79c60c: ldur            w2, [x1, #0xb]
    // 0x79c610: DecompressPointer r2
    //     0x79c610: add             x2, x2, HEAP, lsl #32
    // 0x79c614: cmp             w2, NULL
    // 0x79c618: b.eq            #0x79c644
    // 0x79c61c: r0 = Null
    //     0x79c61c: mov             x0, NULL
    // 0x79c620: LeaveFrame
    //     0x79c620: mov             SP, fp
    //     0x79c624: ldp             fp, lr, [SP], #0x10
    // 0x79c628: ret
    //     0x79c628: ret             
    // 0x79c62c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79c62c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79c630: b               #0x79c37c
    // 0x79c634: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79c634: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79c638: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79c638: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79c63c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79c63c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79c640: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79c640: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79c644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79c644: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, ExtendedHorizontalDragGestureRecognizer) {
    // ** addr: 0x79c654, size: 0x384
    // 0x79c654: EnterFrame
    //     0x79c654: stp             fp, lr, [SP, #-0x10]!
    //     0x79c658: mov             fp, SP
    // 0x79c65c: AllocStack(0x8)
    //     0x79c65c: sub             SP, SP, #8
    // 0x79c660: SetupParameters()
    //     0x79c660: ldr             x0, [fp, #0x18]
    //     0x79c664: ldur            w1, [x0, #0x17]
    //     0x79c668: add             x1, x1, HEAP, lsl #32
    //     0x79c66c: stur            x1, [fp, #-8]
    // 0x79c670: CheckStackOverflow
    //     0x79c670: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79c674: cmp             SP, x16
    //     0x79c678: b.ls            #0x79c9a4
    // 0x79c67c: LoadField: r0 = r1->field_f
    //     0x79c67c: ldur            w0, [x1, #0xf]
    // 0x79c680: DecompressPointer r0
    //     0x79c680: add             x0, x0, HEAP, lsl #32
    // 0x79c684: r2 = LoadClassIdInstr(r0)
    //     0x79c684: ldur            x2, [x0, #-1]
    //     0x79c688: ubfx            x2, x2, #0xc, #0x14
    // 0x79c68c: SaveReg r0
    //     0x79c68c: str             x0, [SP, #-8]!
    // 0x79c690: mov             x0, x2
    // 0x79c694: r0 = GDT[cid_x0 + -0xfff]()
    //     0x79c694: sub             lr, x0, #0xfff
    //     0x79c698: ldr             lr, [x21, lr, lsl #3]
    //     0x79c69c: blr             lr
    // 0x79c6a0: add             SP, SP, #8
    // 0x79c6a4: ldr             x1, [fp, #0x10]
    // 0x79c6a8: StoreField: r1->field_27 = r0
    //     0x79c6a8: stur            w0, [x1, #0x27]
    //     0x79c6ac: tbz             w0, #0, #0x79c6c8
    //     0x79c6b0: ldurb           w16, [x1, #-1]
    //     0x79c6b4: ldurb           w17, [x0, #-1]
    //     0x79c6b8: and             x16, x17, x16, lsr #2
    //     0x79c6bc: tst             x16, HEAP, lsr #32
    //     0x79c6c0: b.eq            #0x79c6c8
    //     0x79c6c4: bl              #0xd6826c
    // 0x79c6c8: ldur            x2, [fp, #-8]
    // 0x79c6cc: LoadField: r0 = r2->field_f
    //     0x79c6cc: ldur            w0, [x2, #0xf]
    // 0x79c6d0: DecompressPointer r0
    //     0x79c6d0: add             x0, x0, HEAP, lsl #32
    // 0x79c6d4: r3 = LoadClassIdInstr(r0)
    //     0x79c6d4: ldur            x3, [x0, #-1]
    //     0x79c6d8: ubfx            x3, x3, #0xc, #0x14
    // 0x79c6dc: SaveReg r0
    //     0x79c6dc: str             x0, [SP, #-8]!
    // 0x79c6e0: mov             x0, x3
    // 0x79c6e4: r0 = GDT[cid_x0 + -0xffe]()
    //     0x79c6e4: sub             lr, x0, #0xffe
    //     0x79c6e8: ldr             lr, [x21, lr, lsl #3]
    //     0x79c6ec: blr             lr
    // 0x79c6f0: add             SP, SP, #8
    // 0x79c6f4: ldr             x1, [fp, #0x10]
    // 0x79c6f8: StoreField: r1->field_2b = r0
    //     0x79c6f8: stur            w0, [x1, #0x2b]
    //     0x79c6fc: tbz             w0, #0, #0x79c718
    //     0x79c700: ldurb           w16, [x1, #-1]
    //     0x79c704: ldurb           w17, [x0, #-1]
    //     0x79c708: and             x16, x17, x16, lsr #2
    //     0x79c70c: tst             x16, HEAP, lsr #32
    //     0x79c710: b.eq            #0x79c718
    //     0x79c714: bl              #0xd6826c
    // 0x79c718: ldur            x2, [fp, #-8]
    // 0x79c71c: LoadField: r0 = r2->field_f
    //     0x79c71c: ldur            w0, [x2, #0xf]
    // 0x79c720: DecompressPointer r0
    //     0x79c720: add             x0, x0, HEAP, lsl #32
    // 0x79c724: r3 = LoadClassIdInstr(r0)
    //     0x79c724: ldur            x3, [x0, #-1]
    //     0x79c728: ubfx            x3, x3, #0xc, #0x14
    // 0x79c72c: SaveReg r0
    //     0x79c72c: str             x0, [SP, #-8]!
    // 0x79c730: mov             x0, x3
    // 0x79c734: r0 = GDT[cid_x0 + -0xffd]()
    //     0x79c734: sub             lr, x0, #0xffd
    //     0x79c738: ldr             lr, [x21, lr, lsl #3]
    //     0x79c73c: blr             lr
    // 0x79c740: add             SP, SP, #8
    // 0x79c744: ldr             x1, [fp, #0x10]
    // 0x79c748: StoreField: r1->field_2f = r0
    //     0x79c748: stur            w0, [x1, #0x2f]
    //     0x79c74c: tbz             w0, #0, #0x79c768
    //     0x79c750: ldurb           w16, [x1, #-1]
    //     0x79c754: ldurb           w17, [x0, #-1]
    //     0x79c758: and             x16, x17, x16, lsr #2
    //     0x79c75c: tst             x16, HEAP, lsr #32
    //     0x79c760: b.eq            #0x79c768
    //     0x79c764: bl              #0xd6826c
    // 0x79c768: ldur            x2, [fp, #-8]
    // 0x79c76c: LoadField: r0 = r2->field_f
    //     0x79c76c: ldur            w0, [x2, #0xf]
    // 0x79c770: DecompressPointer r0
    //     0x79c770: add             x0, x0, HEAP, lsl #32
    // 0x79c774: r3 = LoadClassIdInstr(r0)
    //     0x79c774: ldur            x3, [x0, #-1]
    //     0x79c778: ubfx            x3, x3, #0xc, #0x14
    // 0x79c77c: SaveReg r0
    //     0x79c77c: str             x0, [SP, #-8]!
    // 0x79c780: mov             x0, x3
    // 0x79c784: r0 = GDT[cid_x0 + -0xffc]()
    //     0x79c784: sub             lr, x0, #0xffc
    //     0x79c788: ldr             lr, [x21, lr, lsl #3]
    //     0x79c78c: blr             lr
    // 0x79c790: add             SP, SP, #8
    // 0x79c794: ldr             x1, [fp, #0x10]
    // 0x79c798: StoreField: r1->field_33 = r0
    //     0x79c798: stur            w0, [x1, #0x33]
    //     0x79c79c: tbz             w0, #0, #0x79c7b8
    //     0x79c7a0: ldurb           w16, [x1, #-1]
    //     0x79c7a4: ldurb           w17, [x0, #-1]
    //     0x79c7a8: and             x16, x17, x16, lsr #2
    //     0x79c7ac: tst             x16, HEAP, lsr #32
    //     0x79c7b0: b.eq            #0x79c7b8
    //     0x79c7b4: bl              #0xd6826c
    // 0x79c7b8: ldur            x2, [fp, #-8]
    // 0x79c7bc: LoadField: r0 = r2->field_f
    //     0x79c7bc: ldur            w0, [x2, #0xf]
    // 0x79c7c0: DecompressPointer r0
    //     0x79c7c0: add             x0, x0, HEAP, lsl #32
    // 0x79c7c4: r3 = LoadClassIdInstr(r0)
    //     0x79c7c4: ldur            x3, [x0, #-1]
    //     0x79c7c8: ubfx            x3, x3, #0xc, #0x14
    // 0x79c7cc: SaveReg r0
    //     0x79c7cc: str             x0, [SP, #-8]!
    // 0x79c7d0: mov             x0, x3
    // 0x79c7d4: r0 = GDT[cid_x0 + -0xffb]()
    //     0x79c7d4: sub             lr, x0, #0xffb
    //     0x79c7d8: ldr             lr, [x21, lr, lsl #3]
    //     0x79c7dc: blr             lr
    // 0x79c7e0: add             SP, SP, #8
    // 0x79c7e4: ldr             x1, [fp, #0x10]
    // 0x79c7e8: StoreField: r1->field_37 = r0
    //     0x79c7e8: stur            w0, [x1, #0x37]
    //     0x79c7ec: tbz             w0, #0, #0x79c808
    //     0x79c7f0: ldurb           w16, [x1, #-1]
    //     0x79c7f4: ldurb           w17, [x0, #-1]
    //     0x79c7f8: and             x16, x17, x16, lsr #2
    //     0x79c7fc: tst             x16, HEAP, lsr #32
    //     0x79c800: b.eq            #0x79c808
    //     0x79c804: bl              #0xd6826c
    // 0x79c808: ldur            x0, [fp, #-8]
    // 0x79c80c: LoadField: r2 = r0->field_f
    //     0x79c80c: ldur            w2, [x0, #0xf]
    // 0x79c810: DecompressPointer r2
    //     0x79c810: add             x2, x2, HEAP, lsl #32
    // 0x79c814: LoadField: r3 = r2->field_b
    //     0x79c814: ldur            w3, [x2, #0xb]
    // 0x79c818: DecompressPointer r3
    //     0x79c818: add             x3, x3, HEAP, lsl #32
    // 0x79c81c: cmp             w3, NULL
    // 0x79c820: b.eq            #0x79c9ac
    // 0x79c824: LoadField: r2 = r3->field_1b
    //     0x79c824: ldur            w2, [x3, #0x1b]
    // 0x79c828: DecompressPointer r2
    //     0x79c828: add             x2, x2, HEAP, lsl #32
    // 0x79c82c: SaveReg r2
    //     0x79c82c: str             x2, [SP, #-8]!
    // 0x79c830: r0 = minFlingDistance()
    //     0x79c830: bl              #0x79c9d8  ; [package:flutter/src/widgets/scroll_physics.dart] ScrollPhysics::minFlingDistance
    // 0x79c834: add             SP, SP, #8
    // 0x79c838: r0 = inline_Allocate_Double()
    //     0x79c838: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x79c83c: add             x0, x0, #0x10
    //     0x79c840: cmp             x1, x0
    //     0x79c844: b.ls            #0x79c9b0
    //     0x79c848: str             x0, [THR, #0x60]  ; THR::top
    //     0x79c84c: sub             x0, x0, #0xf
    //     0x79c850: mov             x1, #0xd108
    //     0x79c854: movk            x1, #3, lsl #16
    //     0x79c858: stur            x1, [x0, #-1]
    // 0x79c85c: StoreField: r0->field_7 = d0
    //     0x79c85c: stur            d0, [x0, #7]
    // 0x79c860: ldr             x1, [fp, #0x10]
    // 0x79c864: StoreField: r1->field_3b = r0
    //     0x79c864: stur            w0, [x1, #0x3b]
    //     0x79c868: ldurb           w16, [x1, #-1]
    //     0x79c86c: ldurb           w17, [x0, #-1]
    //     0x79c870: and             x16, x17, x16, lsr #2
    //     0x79c874: tst             x16, HEAP, lsr #32
    //     0x79c878: b.eq            #0x79c880
    //     0x79c87c: bl              #0xd6826c
    // 0x79c880: ldur            x0, [fp, #-8]
    // 0x79c884: LoadField: r2 = r0->field_f
    //     0x79c884: ldur            w2, [x0, #0xf]
    // 0x79c888: DecompressPointer r2
    //     0x79c888: add             x2, x2, HEAP, lsl #32
    // 0x79c88c: LoadField: r3 = r2->field_b
    //     0x79c88c: ldur            w3, [x2, #0xb]
    // 0x79c890: DecompressPointer r3
    //     0x79c890: add             x3, x3, HEAP, lsl #32
    // 0x79c894: cmp             w3, NULL
    // 0x79c898: b.eq            #0x79c9c0
    // 0x79c89c: LoadField: r2 = r3->field_1b
    //     0x79c89c: ldur            w2, [x3, #0x1b]
    // 0x79c8a0: DecompressPointer r2
    //     0x79c8a0: add             x2, x2, HEAP, lsl #32
    // 0x79c8a4: SaveReg r2
    //     0x79c8a4: str             x2, [SP, #-8]!
    // 0x79c8a8: r0 = minFlingVelocity()
    //     0x79c8a8: bl              #0xc39c64  ; [package:flutter/src/widgets/scroll_physics.dart] ScrollPhysics::minFlingVelocity
    // 0x79c8ac: add             SP, SP, #8
    // 0x79c8b0: r0 = inline_Allocate_Double()
    //     0x79c8b0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x79c8b4: add             x0, x0, #0x10
    //     0x79c8b8: cmp             x1, x0
    //     0x79c8bc: b.ls            #0x79c9c4
    //     0x79c8c0: str             x0, [THR, #0x60]  ; THR::top
    //     0x79c8c4: sub             x0, x0, #0xf
    //     0x79c8c8: mov             x1, #0xd108
    //     0x79c8cc: movk            x1, #3, lsl #16
    //     0x79c8d0: stur            x1, [x0, #-1]
    // 0x79c8d4: StoreField: r0->field_7 = d0
    //     0x79c8d4: stur            d0, [x0, #7]
    // 0x79c8d8: ldr             x1, [fp, #0x10]
    // 0x79c8dc: StoreField: r1->field_3f = r0
    //     0x79c8dc: stur            w0, [x1, #0x3f]
    //     0x79c8e0: ldurb           w16, [x1, #-1]
    //     0x79c8e4: ldurb           w17, [x0, #-1]
    //     0x79c8e8: and             x16, x17, x16, lsr #2
    //     0x79c8ec: tst             x16, HEAP, lsr #32
    //     0x79c8f0: b.eq            #0x79c8f8
    //     0x79c8f4: bl              #0xd6826c
    // 0x79c8f8: ldur            x0, [fp, #-8]
    // 0x79c8fc: LoadField: r2 = r0->field_f
    //     0x79c8fc: ldur            w2, [x0, #0xf]
    // 0x79c900: DecompressPointer r2
    //     0x79c900: add             x2, x2, HEAP, lsl #32
    // 0x79c904: LoadField: r3 = r2->field_b
    //     0x79c904: ldur            w3, [x2, #0xb]
    // 0x79c908: DecompressPointer r3
    //     0x79c908: add             x3, x3, HEAP, lsl #32
    // 0x79c90c: cmp             w3, NULL
    // 0x79c910: b.eq            #0x79c9d4
    // 0x79c914: LoadField: r2 = r3->field_1b
    //     0x79c914: ldur            w2, [x3, #0x1b]
    // 0x79c918: DecompressPointer r2
    //     0x79c918: add             x2, x2, HEAP, lsl #32
    // 0x79c91c: SaveReg r2
    //     0x79c91c: str             x2, [SP, #-8]!
    // 0x79c920: r0 = maxFlingVelocity()
    //     0x79c920: bl              #0xc37ab8  ; [package:flutter/src/widgets/scroll_physics.dart] ScrollPhysics::maxFlingVelocity
    // 0x79c924: add             SP, SP, #8
    // 0x79c928: ldr             x1, [fp, #0x10]
    // 0x79c92c: StoreField: r1->field_43 = r0
    //     0x79c92c: stur            w0, [x1, #0x43]
    //     0x79c930: ldurb           w16, [x1, #-1]
    //     0x79c934: ldurb           w17, [x0, #-1]
    //     0x79c938: and             x16, x17, x16, lsr #2
    //     0x79c93c: tst             x16, HEAP, lsr #32
    //     0x79c940: b.eq            #0x79c948
    //     0x79c944: bl              #0xd6826c
    // 0x79c948: ldur            x2, [fp, #-8]
    // 0x79c94c: LoadField: r3 = r2->field_f
    //     0x79c94c: ldur            w3, [x2, #0xf]
    // 0x79c950: DecompressPointer r3
    //     0x79c950: add             x3, x3, HEAP, lsl #32
    // 0x79c954: LoadField: r2 = r3->field_1b
    //     0x79c954: ldur            w2, [x3, #0x1b]
    // 0x79c958: DecompressPointer r2
    //     0x79c958: add             x2, x2, HEAP, lsl #32
    // 0x79c95c: cmp             w2, NULL
    // 0x79c960: b.ne            #0x79c96c
    // 0x79c964: r0 = Null
    //     0x79c964: mov             x0, NULL
    // 0x79c968: b               #0x79c978
    // 0x79c96c: LoadField: r3 = r2->field_4b
    //     0x79c96c: ldur            w3, [x2, #0x4b]
    // 0x79c970: DecompressPointer r3
    //     0x79c970: add             x3, x3, HEAP, lsl #32
    // 0x79c974: mov             x0, x3
    // 0x79c978: StoreField: r1->field_7 = r0
    //     0x79c978: stur            w0, [x1, #7]
    //     0x79c97c: ldurb           w16, [x1, #-1]
    //     0x79c980: ldurb           w17, [x0, #-1]
    //     0x79c984: and             x16, x17, x16, lsr #2
    //     0x79c988: tst             x16, HEAP, lsr #32
    //     0x79c98c: b.eq            #0x79c994
    //     0x79c990: bl              #0xd6826c
    // 0x79c994: r0 = Null
    //     0x79c994: mov             x0, NULL
    // 0x79c998: LeaveFrame
    //     0x79c998: mov             SP, fp
    //     0x79c99c: ldp             fp, lr, [SP], #0x10
    // 0x79c9a0: ret
    //     0x79c9a0: ret             
    // 0x79c9a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79c9a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79c9a8: b               #0x79c67c
    // 0x79c9ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79c9ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79c9b0: SaveReg d0
    //     0x79c9b0: str             q0, [SP, #-0x10]!
    // 0x79c9b4: r0 = AllocateDouble()
    //     0x79c9b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x79c9b8: RestoreReg d0
    //     0x79c9b8: ldr             q0, [SP], #0x10
    // 0x79c9bc: b               #0x79c85c
    // 0x79c9c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79c9c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79c9c4: SaveReg d0
    //     0x79c9c4: str             q0, [SP, #-0x10]!
    // 0x79c9c8: r0 = AllocateDouble()
    //     0x79c9c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x79c9cc: RestoreReg d0
    //     0x79c9cc: ldr             q0, [SP], #0x10
    // 0x79c9d0: b               #0x79c8d4
    // 0x79c9d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79c9d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] ExtendedVerticalDragGestureRecognizer <anonymous closure>(dynamic) {
    // ** addr: 0x79ca78, size: 0x80
    // 0x79ca78: EnterFrame
    //     0x79ca78: stp             fp, lr, [SP, #-0x10]!
    //     0x79ca7c: mov             fp, SP
    // 0x79ca80: AllocStack(0x10)
    //     0x79ca80: sub             SP, SP, #0x10
    // 0x79ca84: SetupParameters()
    //     0x79ca84: ldr             x0, [fp, #0x10]
    //     0x79ca88: ldur            w1, [x0, #0x17]
    //     0x79ca8c: add             x1, x1, HEAP, lsl #32
    // 0x79ca90: CheckStackOverflow
    //     0x79ca90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79ca94: cmp             SP, x16
    //     0x79ca98: b.ls            #0x79caf0
    // 0x79ca9c: LoadField: r0 = r1->field_f
    //     0x79ca9c: ldur            w0, [x1, #0xf]
    // 0x79caa0: DecompressPointer r0
    //     0x79caa0: add             x0, x0, HEAP, lsl #32
    // 0x79caa4: r1 = LoadClassIdInstr(r0)
    //     0x79caa4: ldur            x1, [x0, #-1]
    //     0x79caa8: ubfx            x1, x1, #0xc, #0x14
    // 0x79caac: SaveReg r0
    //     0x79caac: str             x0, [SP, #-8]!
    // 0x79cab0: mov             x0, x1
    // 0x79cab4: r0 = GDT[cid_x0 + -0xffa]()
    //     0x79cab4: sub             lr, x0, #0xffa
    //     0x79cab8: ldr             lr, [x21, lr, lsl #3]
    //     0x79cabc: blr             lr
    // 0x79cac0: add             SP, SP, #8
    // 0x79cac4: stur            x0, [fp, #-8]
    // 0x79cac8: r0 = ExtendedVerticalDragGestureRecognizer()
    //     0x79cac8: bl              #0x79cd84  ; AllocateExtendedVerticalDragGestureRecognizerStub -> ExtendedVerticalDragGestureRecognizer (size=0x70)
    // 0x79cacc: stur            x0, [fp, #-0x10]
    // 0x79cad0: ldur            x16, [fp, #-8]
    // 0x79cad4: stp             x16, x0, [SP, #-0x10]!
    // 0x79cad8: r0 = ExtendedDragGestureRecognizer()
    //     0x79cad8: bl              #0x79caf8  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::ExtendedDragGestureRecognizer
    // 0x79cadc: add             SP, SP, #0x10
    // 0x79cae0: ldur            x0, [fp, #-0x10]
    // 0x79cae4: LeaveFrame
    //     0x79cae4: mov             SP, fp
    //     0x79cae8: ldp             fp, lr, [SP], #0x10
    // 0x79caec: ret
    //     0x79caec: ret             
    // 0x79caf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79caf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79caf4: b               #0x79ca9c
  }
  [closure] ExtendedHorizontalDragGestureRecognizer <anonymous closure>(dynamic) {
    // ** addr: 0x79cd90, size: 0x80
    // 0x79cd90: EnterFrame
    //     0x79cd90: stp             fp, lr, [SP, #-0x10]!
    //     0x79cd94: mov             fp, SP
    // 0x79cd98: AllocStack(0x10)
    //     0x79cd98: sub             SP, SP, #0x10
    // 0x79cd9c: SetupParameters()
    //     0x79cd9c: ldr             x0, [fp, #0x10]
    //     0x79cda0: ldur            w1, [x0, #0x17]
    //     0x79cda4: add             x1, x1, HEAP, lsl #32
    // 0x79cda8: CheckStackOverflow
    //     0x79cda8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79cdac: cmp             SP, x16
    //     0x79cdb0: b.ls            #0x79ce08
    // 0x79cdb4: LoadField: r0 = r1->field_f
    //     0x79cdb4: ldur            w0, [x1, #0xf]
    // 0x79cdb8: DecompressPointer r0
    //     0x79cdb8: add             x0, x0, HEAP, lsl #32
    // 0x79cdbc: r1 = LoadClassIdInstr(r0)
    //     0x79cdbc: ldur            x1, [x0, #-1]
    //     0x79cdc0: ubfx            x1, x1, #0xc, #0x14
    // 0x79cdc4: SaveReg r0
    //     0x79cdc4: str             x0, [SP, #-8]!
    // 0x79cdc8: mov             x0, x1
    // 0x79cdcc: r0 = GDT[cid_x0 + -0xffa]()
    //     0x79cdcc: sub             lr, x0, #0xffa
    //     0x79cdd0: ldr             lr, [x21, lr, lsl #3]
    //     0x79cdd4: blr             lr
    // 0x79cdd8: add             SP, SP, #8
    // 0x79cddc: stur            x0, [fp, #-8]
    // 0x79cde0: r0 = ExtendedHorizontalDragGestureRecognizer()
    //     0x79cde0: bl              #0x79ce10  ; AllocateExtendedHorizontalDragGestureRecognizerStub -> ExtendedHorizontalDragGestureRecognizer (size=0x70)
    // 0x79cde4: stur            x0, [fp, #-0x10]
    // 0x79cde8: ldur            x16, [fp, #-8]
    // 0x79cdec: stp             x16, x0, [SP, #-0x10]!
    // 0x79cdf0: r0 = ExtendedDragGestureRecognizer()
    //     0x79cdf0: bl              #0x79caf8  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::ExtendedDragGestureRecognizer
    // 0x79cdf4: add             SP, SP, #0x10
    // 0x79cdf8: ldur            x0, [fp, #-0x10]
    // 0x79cdfc: LeaveFrame
    //     0x79cdfc: mov             SP, fp
    //     0x79ce00: ldp             fp, lr, [SP], #0x10
    // 0x79ce04: ret
    //     0x79ce04: ret             
    // 0x79ce08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79ce08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79ce0c: b               #0x79cdb4
  }
  get _ pageController(/* No info */) {
    // ** addr: 0x7bf758, size: 0x34
    // 0x7bf758: EnterFrame
    //     0x7bf758: stp             fp, lr, [SP, #-0x10]!
    //     0x7bf75c: mov             fp, SP
    // 0x7bf760: ldr             x1, [fp, #0x10]
    // 0x7bf764: LoadField: r2 = r1->field_b
    //     0x7bf764: ldur            w2, [x1, #0xb]
    // 0x7bf768: DecompressPointer r2
    //     0x7bf768: add             x2, x2, HEAP, lsl #32
    // 0x7bf76c: cmp             w2, NULL
    // 0x7bf770: b.eq            #0x7bf788
    // 0x7bf774: LoadField: r0 = r2->field_17
    //     0x7bf774: ldur            w0, [x2, #0x17]
    // 0x7bf778: DecompressPointer r0
    //     0x7bf778: add             x0, x0, HEAP, lsl #32
    // 0x7bf77c: LeaveFrame
    //     0x7bf77c: mov             SP, fp
    //     0x7bf780: ldp             fp, lr, [SP], #0x10
    // 0x7bf784: ret
    //     0x7bf784: ret             
    // 0x7bf788: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bf788: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ onDragEnd(/* No info */) {
    // ** addr: 0x82db7c, size: 0x12c
    // 0x82db7c: EnterFrame
    //     0x82db7c: stp             fp, lr, [SP, #-0x10]!
    //     0x82db80: mov             fp, SP
    // 0x82db84: AllocStack(0x8)
    //     0x82db84: sub             SP, SP, #8
    // 0x82db88: CheckStackOverflow
    //     0x82db88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82db8c: cmp             SP, x16
    //     0x82db90: b.ls            #0x82dc94
    // 0x82db94: ldr             x0, [fp, #0x18]
    // 0x82db98: LoadField: r1 = r0->field_b
    //     0x82db98: ldur            w1, [x0, #0xb]
    // 0x82db9c: DecompressPointer r1
    //     0x82db9c: add             x1, x1, HEAP, lsl #32
    // 0x82dba0: stur            x1, [fp, #-8]
    // 0x82dba4: cmp             w1, NULL
    // 0x82dba8: b.eq            #0x82dc9c
    // 0x82dbac: SaveReg r0
    //     0x82dbac: str             x0, [SP, #-8]!
    // 0x82dbb0: r0 = extendedImageGestureState()
    //     0x82dbb0: bl              #0x82dcf4  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::extendedImageGestureState
    // 0x82dbb4: add             SP, SP, #8
    // 0x82dbb8: cmp             w0, NULL
    // 0x82dbbc: b.ne            #0x82dbc8
    // 0x82dbc0: r1 = Null
    //     0x82dbc0: mov             x1, NULL
    // 0x82dbc4: b               #0x82dbd0
    // 0x82dbc8: LoadField: r1 = r0->field_1b
    //     0x82dbc8: ldur            w1, [x0, #0x1b]
    // 0x82dbcc: DecompressPointer r1
    //     0x82dbcc: add             x1, x1, HEAP, lsl #32
    // 0x82dbd0: ldur            x0, [fp, #-8]
    // 0x82dbd4: LoadField: r2 = r0->field_b
    //     0x82dbd4: ldur            w2, [x0, #0xb]
    // 0x82dbd8: DecompressPointer r2
    //     0x82dbd8: add             x2, x2, HEAP, lsl #32
    // 0x82dbdc: stp             x1, x2, [SP, #-0x10]!
    // 0x82dbe0: mov             x0, x2
    // 0x82dbe4: ClosureCall
    //     0x82dbe4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x82dbe8: ldur            x2, [x0, #0x1f]
    //     0x82dbec: blr             x2
    // 0x82dbf0: add             SP, SP, #0x10
    // 0x82dbf4: mov             x1, x0
    // 0x82dbf8: stur            x1, [fp, #-8]
    // 0x82dbfc: tbnz            w0, #5, #0x82dc04
    // 0x82dc00: r0 = AssertBoolean()
    //     0x82dc00: bl              #0xd67df0  ; AssertBooleanStub
    // 0x82dc04: ldur            x0, [fp, #-8]
    // 0x82dc08: tbz             w0, #4, #0x82dc60
    // 0x82dc0c: ldr             x0, [fp, #0x18]
    // 0x82dc10: LoadField: r1 = r0->field_2b
    //     0x82dc10: ldur            w1, [x0, #0x2b]
    // 0x82dc14: DecompressPointer r1
    //     0x82dc14: add             x1, x1, HEAP, lsl #32
    // 0x82dc18: stur            x1, [fp, #-8]
    // 0x82dc1c: cmp             w1, NULL
    // 0x82dc20: b.eq            #0x82dca0
    // 0x82dc24: r0 = DragEndDetails()
    //     0x82dc24: bl              #0x713c0c  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x10)
    // 0x82dc28: mov             x1, x0
    // 0x82dc2c: r0 = Instance_Velocity
    //     0x82dc2c: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e850] Obj!Velocity@b38701
    //     0x82dc30: ldr             x0, [x0, #0x850]
    // 0x82dc34: StoreField: r1->field_7 = r0
    //     0x82dc34: stur            w0, [x1, #7]
    // 0x82dc38: r0 = 0.000000
    //     0x82dc38: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x82dc3c: StoreField: r1->field_b = r0
    //     0x82dc3c: stur            w0, [x1, #0xb]
    // 0x82dc40: ldur            x16, [fp, #-8]
    // 0x82dc44: stp             x1, x16, [SP, #-0x10]!
    // 0x82dc48: r0 = end()
    //     0x82dc48: bl              #0xd0e59c  ; [package:flutter/src/widgets/scroll_activity.dart] ScrollDragController::end
    // 0x82dc4c: add             SP, SP, #0x10
    // 0x82dc50: r0 = Null
    //     0x82dc50: mov             x0, NULL
    // 0x82dc54: LeaveFrame
    //     0x82dc54: mov             SP, fp
    //     0x82dc58: ldp             fp, lr, [SP], #0x10
    // 0x82dc5c: ret
    //     0x82dc5c: ret             
    // 0x82dc60: ldr             x0, [fp, #0x18]
    // 0x82dc64: LoadField: r1 = r0->field_2b
    //     0x82dc64: ldur            w1, [x0, #0x2b]
    // 0x82dc68: DecompressPointer r1
    //     0x82dc68: add             x1, x1, HEAP, lsl #32
    // 0x82dc6c: cmp             w1, NULL
    // 0x82dc70: b.eq            #0x82dca4
    // 0x82dc74: ldr             x16, [fp, #0x10]
    // 0x82dc78: stp             x16, x1, [SP, #-0x10]!
    // 0x82dc7c: r0 = end()
    //     0x82dc7c: bl              #0xd0e59c  ; [package:flutter/src/widgets/scroll_activity.dart] ScrollDragController::end
    // 0x82dc80: add             SP, SP, #0x10
    // 0x82dc84: r0 = Null
    //     0x82dc84: mov             x0, NULL
    // 0x82dc88: LeaveFrame
    //     0x82dc88: mov             SP, fp
    //     0x82dc8c: ldp             fp, lr, [SP], #0x10
    // 0x82dc90: ret
    //     0x82dc90: ret             
    // 0x82dc94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82dc94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82dc98: b               #0x82db94
    // 0x82dc9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82dc9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82dca0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82dca0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82dca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82dca4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0x82dca8, size: 0x4c
    // 0x82dca8: EnterFrame
    //     0x82dca8: stp             fp, lr, [SP, #-0x10]!
    //     0x82dcac: mov             fp, SP
    // 0x82dcb0: ldr             x0, [fp, #0x18]
    // 0x82dcb4: LoadField: r1 = r0->field_17
    //     0x82dcb4: ldur            w1, [x0, #0x17]
    // 0x82dcb8: DecompressPointer r1
    //     0x82dcb8: add             x1, x1, HEAP, lsl #32
    // 0x82dcbc: CheckStackOverflow
    //     0x82dcbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82dcc0: cmp             SP, x16
    //     0x82dcc4: b.ls            #0x82dcec
    // 0x82dcc8: LoadField: r0 = r1->field_f
    //     0x82dcc8: ldur            w0, [x1, #0xf]
    // 0x82dccc: DecompressPointer r0
    //     0x82dccc: add             x0, x0, HEAP, lsl #32
    // 0x82dcd0: ldr             x16, [fp, #0x10]
    // 0x82dcd4: stp             x16, x0, [SP, #-0x10]!
    // 0x82dcd8: r0 = onDragEnd()
    //     0x82dcd8: bl              #0x82db7c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragEnd
    // 0x82dcdc: add             SP, SP, #0x10
    // 0x82dce0: LeaveFrame
    //     0x82dce0: mov             SP, fp
    //     0x82dce4: ldp             fp, lr, [SP], #0x10
    // 0x82dce8: ret
    //     0x82dce8: ret             
    // 0x82dcec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82dcec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82dcf0: b               #0x82dcc8
  }
  get _ extendedImageGestureState(/* No info */) {
    // ** addr: 0x82dcf4, size: 0x7c
    // 0x82dcf4: EnterFrame
    //     0x82dcf4: stp             fp, lr, [SP, #-0x10]!
    //     0x82dcf8: mov             fp, SP
    // 0x82dcfc: AllocStack(0x10)
    //     0x82dcfc: sub             SP, SP, #0x10
    // 0x82dd00: CheckStackOverflow
    //     0x82dd00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82dd04: cmp             SP, x16
    //     0x82dd08: b.ls            #0x82dd68
    // 0x82dd0c: ldr             x0, [fp, #0x10]
    // 0x82dd10: LoadField: r3 = r0->field_27
    //     0x82dd10: ldur            w3, [x0, #0x27]
    // 0x82dd14: DecompressPointer r3
    //     0x82dd14: add             x3, x3, HEAP, lsl #32
    // 0x82dd18: stur            x3, [fp, #-8]
    // 0x82dd1c: r1 = Function '<anonymous closure>':.
    //     0x82dd1c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c678] AnonymousClosure: (0x82df78), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::extendedImageGestureState (0x82dcf4)
    //     0x82dd20: ldr             x1, [x1, #0x678]
    // 0x82dd24: r2 = Null
    //     0x82dd24: mov             x2, NULL
    // 0x82dd28: r0 = AllocateClosure()
    //     0x82dd28: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82dd2c: r1 = Function '<anonymous closure>':.
    //     0x82dd2c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c680] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x82dd30: ldr             x1, [x1, #0x680]
    // 0x82dd34: r2 = Null
    //     0x82dd34: mov             x2, NULL
    // 0x82dd38: stur            x0, [fp, #-0x10]
    // 0x82dd3c: r0 = AllocateClosure()
    //     0x82dd3c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82dd40: ldur            x16, [fp, #-8]
    // 0x82dd44: ldur            lr, [fp, #-0x10]
    // 0x82dd48: stp             lr, x16, [SP, #-0x10]!
    // 0x82dd4c: SaveReg r0
    //     0x82dd4c: str             x0, [SP, #-8]!
    // 0x82dd50: r4 = const [0, 0x3, 0x3, 0x2, orElse, 0x2, null]
    //     0x82dd50: ldr             x4, [PP, #0x6bc8]  ; [pp+0x6bc8] List(7) [0, 0x3, 0x3, 0x2, "orElse", 0x2, Null]
    // 0x82dd54: r0 = lastWhere()
    //     0x82dd54: bl              #0x82dd70  ; [dart:collection] __Set&_HashVMBase&SetMixin::lastWhere
    // 0x82dd58: add             SP, SP, #0x18
    // 0x82dd5c: LeaveFrame
    //     0x82dd5c: mov             SP, fp
    //     0x82dd60: ldp             fp, lr, [SP], #0x10
    // 0x82dd64: ret
    //     0x82dd64: ret             
    // 0x82dd68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82dd68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82dd6c: b               #0x82dd0c
  }
  [closure] bool <anonymous closure>(dynamic, ExtendedImageGestureState?) {
    // ** addr: 0x82df78, size: 0x44
    // 0x82df78: ldr             x1, [SP]
    // 0x82df7c: cmp             w1, NULL
    // 0x82df80: b.ne            #0x82df8c
    // 0x82df84: r1 = Null
    //     0x82df84: mov             x1, NULL
    // 0x82df88: b               #0x82dfa4
    // 0x82df8c: LoadField: r2 = r1->field_f
    //     0x82df8c: ldur            w2, [x1, #0xf]
    // 0x82df90: DecompressPointer r2
    //     0x82df90: add             x2, x2, HEAP, lsl #32
    // 0x82df94: cmp             w2, NULL
    // 0x82df98: r16 = true
    //     0x82df98: add             x16, NULL, #0x20  ; true
    // 0x82df9c: r17 = false
    //     0x82df9c: add             x17, NULL, #0x30  ; false
    // 0x82dfa0: csel            x1, x16, x17, ne
    // 0x82dfa4: cmp             w1, NULL
    // 0x82dfa8: b.ne            #0x82dfb4
    // 0x82dfac: r0 = false
    //     0x82dfac: add             x0, NULL, #0x30  ; false
    // 0x82dfb0: b               #0x82dfb8
    // 0x82dfb4: mov             x0, x1
    // 0x82dfb8: ret
    //     0x82dfb8: ret             
  }
  _ onDragUpdate(/* No info */) {
    // ** addr: 0x82e818, size: 0x120
    // 0x82e818: EnterFrame
    //     0x82e818: stp             fp, lr, [SP, #-0x10]!
    //     0x82e81c: mov             fp, SP
    // 0x82e820: AllocStack(0x18)
    //     0x82e820: sub             SP, SP, #0x18
    // 0x82e824: CheckStackOverflow
    //     0x82e824: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82e828: cmp             SP, x16
    //     0x82e82c: b.ls            #0x82e92c
    // 0x82e830: ldr             x0, [fp, #0x18]
    // 0x82e834: LoadField: r3 = r0->field_b
    //     0x82e834: ldur            w3, [x0, #0xb]
    // 0x82e838: DecompressPointer r3
    //     0x82e838: add             x3, x3, HEAP, lsl #32
    // 0x82e83c: stur            x3, [fp, #-0x10]
    // 0x82e840: cmp             w3, NULL
    // 0x82e844: b.eq            #0x82e934
    // 0x82e848: LoadField: r4 = r0->field_27
    //     0x82e848: ldur            w4, [x0, #0x27]
    // 0x82e84c: DecompressPointer r4
    //     0x82e84c: add             x4, x4, HEAP, lsl #32
    // 0x82e850: stur            x4, [fp, #-8]
    // 0x82e854: r1 = Function '<anonymous closure>':.
    //     0x82e854: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c678] AnonymousClosure: (0x82df78), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::extendedImageGestureState (0x82dcf4)
    //     0x82e858: ldr             x1, [x1, #0x678]
    // 0x82e85c: r2 = Null
    //     0x82e85c: mov             x2, NULL
    // 0x82e860: r0 = AllocateClosure()
    //     0x82e860: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82e864: r1 = Function '<anonymous closure>':.
    //     0x82e864: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c680] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x82e868: ldr             x1, [x1, #0x680]
    // 0x82e86c: r2 = Null
    //     0x82e86c: mov             x2, NULL
    // 0x82e870: stur            x0, [fp, #-0x18]
    // 0x82e874: r0 = AllocateClosure()
    //     0x82e874: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82e878: ldur            x16, [fp, #-8]
    // 0x82e87c: ldur            lr, [fp, #-0x18]
    // 0x82e880: stp             lr, x16, [SP, #-0x10]!
    // 0x82e884: SaveReg r0
    //     0x82e884: str             x0, [SP, #-8]!
    // 0x82e888: r4 = const [0, 0x3, 0x3, 0x2, orElse, 0x2, null]
    //     0x82e888: ldr             x4, [PP, #0x6bc8]  ; [pp+0x6bc8] List(7) [0, 0x3, 0x3, 0x2, "orElse", 0x2, Null]
    // 0x82e88c: r0 = lastWhere()
    //     0x82e88c: bl              #0x82dd70  ; [dart:collection] __Set&_HashVMBase&SetMixin::lastWhere
    // 0x82e890: add             SP, SP, #0x18
    // 0x82e894: cmp             w0, NULL
    // 0x82e898: b.ne            #0x82e8a4
    // 0x82e89c: r1 = Null
    //     0x82e89c: mov             x1, NULL
    // 0x82e8a0: b               #0x82e8ac
    // 0x82e8a4: LoadField: r1 = r0->field_1b
    //     0x82e8a4: ldur            w1, [x0, #0x1b]
    // 0x82e8a8: DecompressPointer r1
    //     0x82e8a8: add             x1, x1, HEAP, lsl #32
    // 0x82e8ac: ldur            x0, [fp, #-0x10]
    // 0x82e8b0: LoadField: r2 = r0->field_b
    //     0x82e8b0: ldur            w2, [x0, #0xb]
    // 0x82e8b4: DecompressPointer r2
    //     0x82e8b4: add             x2, x2, HEAP, lsl #32
    // 0x82e8b8: stp             x1, x2, [SP, #-0x10]!
    // 0x82e8bc: mov             x0, x2
    // 0x82e8c0: ClosureCall
    //     0x82e8c0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x82e8c4: ldur            x2, [x0, #0x1f]
    //     0x82e8c8: blr             x2
    // 0x82e8cc: add             SP, SP, #0x10
    // 0x82e8d0: mov             x1, x0
    // 0x82e8d4: stur            x1, [fp, #-8]
    // 0x82e8d8: tbnz            w0, #5, #0x82e8e0
    // 0x82e8dc: r0 = AssertBoolean()
    //     0x82e8dc: bl              #0xd67df0  ; AssertBooleanStub
    // 0x82e8e0: ldur            x0, [fp, #-8]
    // 0x82e8e4: tbz             w0, #4, #0x82e8f8
    // 0x82e8e8: r0 = Null
    //     0x82e8e8: mov             x0, NULL
    // 0x82e8ec: LeaveFrame
    //     0x82e8ec: mov             SP, fp
    //     0x82e8f0: ldp             fp, lr, [SP], #0x10
    // 0x82e8f4: ret
    //     0x82e8f4: ret             
    // 0x82e8f8: ldr             x0, [fp, #0x18]
    // 0x82e8fc: LoadField: r1 = r0->field_2b
    //     0x82e8fc: ldur            w1, [x0, #0x2b]
    // 0x82e900: DecompressPointer r1
    //     0x82e900: add             x1, x1, HEAP, lsl #32
    // 0x82e904: cmp             w1, NULL
    // 0x82e908: b.eq            #0x82e91c
    // 0x82e90c: ldr             x16, [fp, #0x10]
    // 0x82e910: stp             x16, x1, [SP, #-0x10]!
    // 0x82e914: r0 = update()
    //     0x82e914: bl              #0xd0e89c  ; [package:flutter/src/widgets/scroll_activity.dart] ScrollDragController::update
    // 0x82e918: add             SP, SP, #0x10
    // 0x82e91c: r0 = Null
    //     0x82e91c: mov             x0, NULL
    // 0x82e920: LeaveFrame
    //     0x82e920: mov             SP, fp
    //     0x82e924: ldp             fp, lr, [SP], #0x10
    // 0x82e928: ret
    //     0x82e928: ret             
    // 0x82e92c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82e92c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82e930: b               #0x82e830
    // 0x82e934: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82e934: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0x82e938, size: 0x4c
    // 0x82e938: EnterFrame
    //     0x82e938: stp             fp, lr, [SP, #-0x10]!
    //     0x82e93c: mov             fp, SP
    // 0x82e940: ldr             x0, [fp, #0x18]
    // 0x82e944: LoadField: r1 = r0->field_17
    //     0x82e944: ldur            w1, [x0, #0x17]
    // 0x82e948: DecompressPointer r1
    //     0x82e948: add             x1, x1, HEAP, lsl #32
    // 0x82e94c: CheckStackOverflow
    //     0x82e94c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82e950: cmp             SP, x16
    //     0x82e954: b.ls            #0x82e97c
    // 0x82e958: LoadField: r0 = r1->field_f
    //     0x82e958: ldur            w0, [x1, #0xf]
    // 0x82e95c: DecompressPointer r0
    //     0x82e95c: add             x0, x0, HEAP, lsl #32
    // 0x82e960: ldr             x16, [fp, #0x10]
    // 0x82e964: stp             x16, x0, [SP, #-0x10]!
    // 0x82e968: r0 = onDragUpdate()
    //     0x82e968: bl              #0x82e818  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragUpdate
    // 0x82e96c: add             SP, SP, #0x10
    // 0x82e970: LeaveFrame
    //     0x82e970: mov             SP, fp
    //     0x82e974: ldp             fp, lr, [SP], #0x10
    // 0x82e978: ret
    //     0x82e978: ret             
    // 0x82e97c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82e97c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82e980: b               #0x82e958
  }
  _ onDragStart(/* No info */) {
    // ** addr: 0x82e984, size: 0xb8
    // 0x82e984: EnterFrame
    //     0x82e984: stp             fp, lr, [SP, #-0x10]!
    //     0x82e988: mov             fp, SP
    // 0x82e98c: AllocStack(0x8)
    //     0x82e98c: sub             SP, SP, #8
    // 0x82e990: CheckStackOverflow
    //     0x82e990: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82e994: cmp             SP, x16
    //     0x82e998: b.ls            #0x82ea34
    // 0x82e99c: ldr             x16, [fp, #0x18]
    // 0x82e9a0: SaveReg r16
    //     0x82e9a0: str             x16, [SP, #-8]!
    // 0x82e9a4: r0 = position()
    //     0x82e9a4: bl              #0x82ea88  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::position
    // 0x82e9a8: add             SP, SP, #8
    // 0x82e9ac: stur            x0, [fp, #-8]
    // 0x82e9b0: r1 = 1
    //     0x82e9b0: mov             x1, #1
    // 0x82e9b4: r0 = AllocateContext()
    //     0x82e9b4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82e9b8: mov             x1, x0
    // 0x82e9bc: ldr             x0, [fp, #0x18]
    // 0x82e9c0: StoreField: r1->field_f = r0
    //     0x82e9c0: stur            w0, [x1, #0xf]
    // 0x82e9c4: mov             x2, x1
    // 0x82e9c8: r1 = Function '_disposeDrag@410206143':.
    //     0x82e9c8: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c6c0] AnonymousClosure: (0x82ead4), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::_disposeDrag (0x82eb1c)
    //     0x82e9cc: ldr             x1, [x1, #0x6c0]
    // 0x82e9d0: r0 = AllocateClosure()
    //     0x82e9d0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82e9d4: mov             x1, x0
    // 0x82e9d8: ldur            x0, [fp, #-8]
    // 0x82e9dc: r2 = LoadClassIdInstr(r0)
    //     0x82e9dc: ldur            x2, [x0, #-1]
    //     0x82e9e0: ubfx            x2, x2, #0xc, #0x14
    // 0x82e9e4: ldr             x16, [fp, #0x10]
    // 0x82e9e8: stp             x16, x0, [SP, #-0x10]!
    // 0x82e9ec: SaveReg r1
    //     0x82e9ec: str             x1, [SP, #-8]!
    // 0x82e9f0: mov             x0, x2
    // 0x82e9f4: r0 = GDT[cid_x0 + 0x754]()
    //     0x82e9f4: add             lr, x0, #0x754
    //     0x82e9f8: ldr             lr, [x21, lr, lsl #3]
    //     0x82e9fc: blr             lr
    // 0x82ea00: add             SP, SP, #0x18
    // 0x82ea04: ldr             x1, [fp, #0x18]
    // 0x82ea08: StoreField: r1->field_2b = r0
    //     0x82ea08: stur            w0, [x1, #0x2b]
    //     0x82ea0c: ldurb           w16, [x1, #-1]
    //     0x82ea10: ldurb           w17, [x0, #-1]
    //     0x82ea14: and             x16, x17, x16, lsr #2
    //     0x82ea18: tst             x16, HEAP, lsr #32
    //     0x82ea1c: b.eq            #0x82ea24
    //     0x82ea20: bl              #0xd6826c
    // 0x82ea24: r0 = Null
    //     0x82ea24: mov             x0, NULL
    // 0x82ea28: LeaveFrame
    //     0x82ea28: mov             SP, fp
    //     0x82ea2c: ldp             fp, lr, [SP], #0x10
    // 0x82ea30: ret
    //     0x82ea30: ret             
    // 0x82ea34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ea34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ea38: b               #0x82e99c
  }
  [closure] void onDragStart(dynamic, DragStartDetails) {
    // ** addr: 0x82ea3c, size: 0x4c
    // 0x82ea3c: EnterFrame
    //     0x82ea3c: stp             fp, lr, [SP, #-0x10]!
    //     0x82ea40: mov             fp, SP
    // 0x82ea44: ldr             x0, [fp, #0x18]
    // 0x82ea48: LoadField: r1 = r0->field_17
    //     0x82ea48: ldur            w1, [x0, #0x17]
    // 0x82ea4c: DecompressPointer r1
    //     0x82ea4c: add             x1, x1, HEAP, lsl #32
    // 0x82ea50: CheckStackOverflow
    //     0x82ea50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82ea54: cmp             SP, x16
    //     0x82ea58: b.ls            #0x82ea80
    // 0x82ea5c: LoadField: r0 = r1->field_f
    //     0x82ea5c: ldur            w0, [x1, #0xf]
    // 0x82ea60: DecompressPointer r0
    //     0x82ea60: add             x0, x0, HEAP, lsl #32
    // 0x82ea64: ldr             x16, [fp, #0x10]
    // 0x82ea68: stp             x16, x0, [SP, #-0x10]!
    // 0x82ea6c: r0 = onDragStart()
    //     0x82ea6c: bl              #0x82e984  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragStart
    // 0x82ea70: add             SP, SP, #0x10
    // 0x82ea74: LeaveFrame
    //     0x82ea74: mov             SP, fp
    //     0x82ea78: ldp             fp, lr, [SP], #0x10
    // 0x82ea7c: ret
    //     0x82ea7c: ret             
    // 0x82ea80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ea80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ea84: b               #0x82ea5c
  }
  get _ position(/* No info */) {
    // ** addr: 0x82ea88, size: 0x4c
    // 0x82ea88: EnterFrame
    //     0x82ea88: stp             fp, lr, [SP, #-0x10]!
    //     0x82ea8c: mov             fp, SP
    // 0x82ea90: CheckStackOverflow
    //     0x82ea90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82ea94: cmp             SP, x16
    //     0x82ea98: b.ls            #0x82eacc
    // 0x82ea9c: ldr             x16, [fp, #0x10]
    // 0x82eaa0: SaveReg r16
    //     0x82eaa0: str             x16, [SP, #-8]!
    // 0x82eaa4: r0 = pageController()
    //     0x82eaa4: bl              #0x7bf758  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::pageController
    // 0x82eaa8: add             SP, SP, #8
    // 0x82eaac: LoadField: r1 = r0->field_33
    //     0x82eaac: ldur            w1, [x0, #0x33]
    // 0x82eab0: DecompressPointer r1
    //     0x82eab0: add             x1, x1, HEAP, lsl #32
    // 0x82eab4: SaveReg r1
    //     0x82eab4: str             x1, [SP, #-8]!
    // 0x82eab8: r0 = single()
    //     0x82eab8: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x82eabc: add             SP, SP, #8
    // 0x82eac0: LeaveFrame
    //     0x82eac0: mov             SP, fp
    //     0x82eac4: ldp             fp, lr, [SP], #0x10
    // 0x82eac8: ret
    //     0x82eac8: ret             
    // 0x82eacc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82eacc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ead0: b               #0x82ea9c
  }
  [closure] void _disposeDrag(dynamic) {
    // ** addr: 0x82ead4, size: 0x48
    // 0x82ead4: EnterFrame
    //     0x82ead4: stp             fp, lr, [SP, #-0x10]!
    //     0x82ead8: mov             fp, SP
    // 0x82eadc: ldr             x0, [fp, #0x10]
    // 0x82eae0: LoadField: r1 = r0->field_17
    //     0x82eae0: ldur            w1, [x0, #0x17]
    // 0x82eae4: DecompressPointer r1
    //     0x82eae4: add             x1, x1, HEAP, lsl #32
    // 0x82eae8: CheckStackOverflow
    //     0x82eae8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82eaec: cmp             SP, x16
    //     0x82eaf0: b.ls            #0x82eb14
    // 0x82eaf4: LoadField: r0 = r1->field_f
    //     0x82eaf4: ldur            w0, [x1, #0xf]
    // 0x82eaf8: DecompressPointer r0
    //     0x82eaf8: add             x0, x0, HEAP, lsl #32
    // 0x82eafc: SaveReg r0
    //     0x82eafc: str             x0, [SP, #-8]!
    // 0x82eb00: r0 = _disposeDrag()
    //     0x82eb00: bl              #0x82eb1c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::_disposeDrag
    // 0x82eb04: add             SP, SP, #8
    // 0x82eb08: LeaveFrame
    //     0x82eb08: mov             SP, fp
    //     0x82eb0c: ldp             fp, lr, [SP], #0x10
    // 0x82eb10: ret
    //     0x82eb10: ret             
    // 0x82eb14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82eb14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82eb18: b               #0x82eaf4
  }
  _ _disposeDrag(/* No info */) {
    // ** addr: 0x82eb1c, size: 0x10
    // 0x82eb1c: ldr             x1, [SP]
    // 0x82eb20: StoreField: r1->field_2b = rNULL
    //     0x82eb20: stur            NULL, [x1, #0x2b]
    // 0x82eb24: r0 = Null
    //     0x82eb24: mov             x0, NULL
    // 0x82eb28: ret
    //     0x82eb28: ret             
  }
  _ onDragDown(/* No info */) {
    // ** addr: 0x82eb2c, size: 0x168
    // 0x82eb2c: EnterFrame
    //     0x82eb2c: stp             fp, lr, [SP, #-0x10]!
    //     0x82eb30: mov             fp, SP
    // 0x82eb34: AllocStack(0x8)
    //     0x82eb34: sub             SP, SP, #8
    // 0x82eb38: CheckStackOverflow
    //     0x82eb38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82eb3c: cmp             SP, x16
    //     0x82eb40: b.ls            #0x82ec7c
    // 0x82eb44: ldr             x0, [fp, #0x18]
    // 0x82eb48: LoadField: r1 = r0->field_23
    //     0x82eb48: ldur            w1, [x0, #0x23]
    // 0x82eb4c: DecompressPointer r1
    //     0x82eb4c: add             x1, x1, HEAP, lsl #32
    // 0x82eb50: r16 = Sentinel
    //     0x82eb50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82eb54: cmp             w1, w16
    // 0x82eb58: b.eq            #0x82ec84
    // 0x82eb5c: SaveReg r1
    //     0x82eb5c: str             x1, [SP, #-8]!
    // 0x82eb60: r0 = stop()
    //     0x82eb60: bl              #0x82ece0  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::stop
    // 0x82eb64: add             SP, SP, #8
    // 0x82eb68: ldr             x1, [fp, #0x18]
    // 0x82eb6c: LoadField: r0 = r1->field_2f
    //     0x82eb6c: ldur            w0, [x1, #0x2f]
    // 0x82eb70: DecompressPointer r0
    //     0x82eb70: add             x0, x0, HEAP, lsl #32
    // 0x82eb74: cmp             w0, NULL
    // 0x82eb78: b.ne            #0x82eb84
    // 0x82eb7c: mov             x0, x1
    // 0x82eb80: b               #0x82eba8
    // 0x82eb84: r2 = LoadClassIdInstr(r0)
    //     0x82eb84: ldur            x2, [x0, #-1]
    //     0x82eb88: ubfx            x2, x2, #0xc, #0x14
    // 0x82eb8c: SaveReg r0
    //     0x82eb8c: str             x0, [SP, #-8]!
    // 0x82eb90: mov             x0, x2
    // 0x82eb94: r0 = GDT[cid_x0 + -0xff7]()
    //     0x82eb94: sub             lr, x0, #0xff7
    //     0x82eb98: ldr             lr, [x21, lr, lsl #3]
    //     0x82eb9c: blr             lr
    // 0x82eba0: add             SP, SP, #8
    // 0x82eba4: ldr             x0, [fp, #0x18]
    // 0x82eba8: StoreField: r0->field_2f = rNULL
    //     0x82eba8: stur            NULL, [x0, #0x2f]
    // 0x82ebac: LoadField: r1 = r0->field_2b
    //     0x82ebac: ldur            w1, [x0, #0x2b]
    // 0x82ebb0: DecompressPointer r1
    //     0x82ebb0: add             x1, x1, HEAP, lsl #32
    // 0x82ebb4: cmp             w1, NULL
    // 0x82ebb8: b.eq            #0x82ebcc
    // 0x82ebbc: SaveReg r1
    //     0x82ebbc: str             x1, [SP, #-8]!
    // 0x82ebc0: r0 = cancel()
    //     0x82ebc0: bl              #0xd0e848  ; [package:flutter/src/widgets/scroll_activity.dart] HoldScrollActivity::cancel
    // 0x82ebc4: add             SP, SP, #8
    // 0x82ebc8: ldr             x0, [fp, #0x18]
    // 0x82ebcc: StoreField: r0->field_2b = rNULL
    //     0x82ebcc: stur            NULL, [x0, #0x2b]
    // 0x82ebd0: LoadField: r1 = r0->field_b
    //     0x82ebd0: ldur            w1, [x0, #0xb]
    // 0x82ebd4: DecompressPointer r1
    //     0x82ebd4: add             x1, x1, HEAP, lsl #32
    // 0x82ebd8: cmp             w1, NULL
    // 0x82ebdc: b.eq            #0x82ec90
    // 0x82ebe0: LoadField: r2 = r1->field_17
    //     0x82ebe0: ldur            w2, [x1, #0x17]
    // 0x82ebe4: DecompressPointer r2
    //     0x82ebe4: add             x2, x2, HEAP, lsl #32
    // 0x82ebe8: LoadField: r1 = r2->field_33
    //     0x82ebe8: ldur            w1, [x2, #0x33]
    // 0x82ebec: DecompressPointer r1
    //     0x82ebec: add             x1, x1, HEAP, lsl #32
    // 0x82ebf0: SaveReg r1
    //     0x82ebf0: str             x1, [SP, #-8]!
    // 0x82ebf4: r0 = single()
    //     0x82ebf4: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x82ebf8: add             SP, SP, #8
    // 0x82ebfc: stur            x0, [fp, #-8]
    // 0x82ec00: r1 = 1
    //     0x82ec00: mov             x1, #1
    // 0x82ec04: r0 = AllocateContext()
    //     0x82ec04: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82ec08: mov             x1, x0
    // 0x82ec0c: ldr             x0, [fp, #0x18]
    // 0x82ec10: StoreField: r1->field_f = r0
    //     0x82ec10: stur            w0, [x1, #0xf]
    // 0x82ec14: mov             x2, x1
    // 0x82ec18: r1 = Function '_disposeHold@410206143':.
    //     0x82ec18: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c6c8] AnonymousClosure: (0x82ed54), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::_disposeHold (0x82ed9c)
    //     0x82ec1c: ldr             x1, [x1, #0x6c8]
    // 0x82ec20: r0 = AllocateClosure()
    //     0x82ec20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82ec24: mov             x1, x0
    // 0x82ec28: ldur            x0, [fp, #-8]
    // 0x82ec2c: r2 = LoadClassIdInstr(r0)
    //     0x82ec2c: ldur            x2, [x0, #-1]
    //     0x82ec30: ubfx            x2, x2, #0xc, #0x14
    // 0x82ec34: stp             x1, x0, [SP, #-0x10]!
    // 0x82ec38: mov             x0, x2
    // 0x82ec3c: r0 = GDT[cid_x0 + 0x740]()
    //     0x82ec3c: add             lr, x0, #0x740
    //     0x82ec40: ldr             lr, [x21, lr, lsl #3]
    //     0x82ec44: blr             lr
    // 0x82ec48: add             SP, SP, #0x10
    // 0x82ec4c: ldr             x1, [fp, #0x18]
    // 0x82ec50: StoreField: r1->field_2f = r0
    //     0x82ec50: stur            w0, [x1, #0x2f]
    //     0x82ec54: ldurb           w16, [x1, #-1]
    //     0x82ec58: ldurb           w17, [x0, #-1]
    //     0x82ec5c: and             x16, x17, x16, lsr #2
    //     0x82ec60: tst             x16, HEAP, lsr #32
    //     0x82ec64: b.eq            #0x82ec6c
    //     0x82ec68: bl              #0xd6826c
    // 0x82ec6c: r0 = Null
    //     0x82ec6c: mov             x0, NULL
    // 0x82ec70: LeaveFrame
    //     0x82ec70: mov             SP, fp
    //     0x82ec74: ldp             fp, lr, [SP], #0x10
    // 0x82ec78: ret
    //     0x82ec78: ret             
    // 0x82ec7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ec7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ec80: b               #0x82eb44
    // 0x82ec84: r9 = _gestureAnimation
    //     0x82ec84: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c6d0] Field <ExtendedImageGesturePageViewState._gestureAnimation@410206143>: late (offset: 0x24)
    //     0x82ec88: ldr             x9, [x9, #0x6d0]
    // 0x82ec8c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82ec8c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x82ec90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82ec90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onDragDown(dynamic, DragDownDetails) {
    // ** addr: 0x82ec94, size: 0x4c
    // 0x82ec94: EnterFrame
    //     0x82ec94: stp             fp, lr, [SP, #-0x10]!
    //     0x82ec98: mov             fp, SP
    // 0x82ec9c: ldr             x0, [fp, #0x18]
    // 0x82eca0: LoadField: r1 = r0->field_17
    //     0x82eca0: ldur            w1, [x0, #0x17]
    // 0x82eca4: DecompressPointer r1
    //     0x82eca4: add             x1, x1, HEAP, lsl #32
    // 0x82eca8: CheckStackOverflow
    //     0x82eca8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82ecac: cmp             SP, x16
    //     0x82ecb0: b.ls            #0x82ecd8
    // 0x82ecb4: LoadField: r0 = r1->field_f
    //     0x82ecb4: ldur            w0, [x1, #0xf]
    // 0x82ecb8: DecompressPointer r0
    //     0x82ecb8: add             x0, x0, HEAP, lsl #32
    // 0x82ecbc: ldr             x16, [fp, #0x10]
    // 0x82ecc0: stp             x16, x0, [SP, #-0x10]!
    // 0x82ecc4: r0 = onDragDown()
    //     0x82ecc4: bl              #0x82eb2c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragDown
    // 0x82ecc8: add             SP, SP, #0x10
    // 0x82eccc: LeaveFrame
    //     0x82eccc: mov             SP, fp
    //     0x82ecd0: ldp             fp, lr, [SP], #0x10
    // 0x82ecd4: ret
    //     0x82ecd4: ret             
    // 0x82ecd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ecd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ecdc: b               #0x82ecb4
  }
  [closure] void _disposeHold(dynamic) {
    // ** addr: 0x82ed54, size: 0x48
    // 0x82ed54: EnterFrame
    //     0x82ed54: stp             fp, lr, [SP, #-0x10]!
    //     0x82ed58: mov             fp, SP
    // 0x82ed5c: ldr             x0, [fp, #0x10]
    // 0x82ed60: LoadField: r1 = r0->field_17
    //     0x82ed60: ldur            w1, [x0, #0x17]
    // 0x82ed64: DecompressPointer r1
    //     0x82ed64: add             x1, x1, HEAP, lsl #32
    // 0x82ed68: CheckStackOverflow
    //     0x82ed68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82ed6c: cmp             SP, x16
    //     0x82ed70: b.ls            #0x82ed94
    // 0x82ed74: LoadField: r0 = r1->field_f
    //     0x82ed74: ldur            w0, [x1, #0xf]
    // 0x82ed78: DecompressPointer r0
    //     0x82ed78: add             x0, x0, HEAP, lsl #32
    // 0x82ed7c: SaveReg r0
    //     0x82ed7c: str             x0, [SP, #-8]!
    // 0x82ed80: r0 = _disposeHold()
    //     0x82ed80: bl              #0x82ed9c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::_disposeHold
    // 0x82ed84: add             SP, SP, #8
    // 0x82ed88: LeaveFrame
    //     0x82ed88: mov             SP, fp
    //     0x82ed8c: ldp             fp, lr, [SP], #0x10
    // 0x82ed90: ret
    //     0x82ed90: ret             
    // 0x82ed94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ed94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ed98: b               #0x82ed74
  }
  _ _disposeHold(/* No info */) {
    // ** addr: 0x82ed9c, size: 0x10
    // 0x82ed9c: ldr             x1, [SP]
    // 0x82eda0: StoreField: r1->field_2f = rNULL
    //     0x82eda0: stur            NULL, [x1, #0x2f]
    // 0x82eda4: r0 = Null
    //     0x82eda4: mov             x0, NULL
    // 0x82eda8: ret
    //     0x82eda8: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0x82f3bc, size: 0x18c
    // 0x82f3bc: EnterFrame
    //     0x82f3bc: stp             fp, lr, [SP, #-0x10]!
    //     0x82f3c0: mov             fp, SP
    // 0x82f3c4: AllocStack(0x38)
    //     0x82f3c4: sub             SP, SP, #0x38
    // 0x82f3c8: CheckStackOverflow
    //     0x82f3c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82f3cc: cmp             SP, x16
    //     0x82f3d0: b.ls            #0x82f538
    // 0x82f3d4: ldr             x0, [fp, #0x18]
    // 0x82f3d8: LoadField: r1 = r0->field_b
    //     0x82f3d8: ldur            w1, [x0, #0xb]
    // 0x82f3dc: DecompressPointer r1
    //     0x82f3dc: add             x1, x1, HEAP, lsl #32
    // 0x82f3e0: cmp             w1, NULL
    // 0x82f3e4: b.eq            #0x82f540
    // 0x82f3e8: LoadField: r2 = r1->field_7
    //     0x82f3e8: ldur            w2, [x1, #7]
    // 0x82f3ec: DecompressPointer r2
    //     0x82f3ec: add             x2, x2, HEAP, lsl #32
    // 0x82f3f0: stur            x2, [fp, #-0x30]
    // 0x82f3f4: LoadField: r3 = r1->field_13
    //     0x82f3f4: ldur            w3, [x1, #0x13]
    // 0x82f3f8: DecompressPointer r3
    //     0x82f3f8: add             x3, x3, HEAP, lsl #32
    // 0x82f3fc: stur            x3, [fp, #-0x28]
    // 0x82f400: LoadField: r4 = r1->field_17
    //     0x82f400: ldur            w4, [x1, #0x17]
    // 0x82f404: DecompressPointer r4
    //     0x82f404: add             x4, x4, HEAP, lsl #32
    // 0x82f408: stur            x4, [fp, #-0x20]
    // 0x82f40c: LoadField: r5 = r1->field_27
    //     0x82f40c: ldur            w5, [x1, #0x27]
    // 0x82f410: DecompressPointer r5
    //     0x82f410: add             x5, x5, HEAP, lsl #32
    // 0x82f414: stur            x5, [fp, #-0x18]
    // 0x82f418: LoadField: r6 = r1->field_1b
    //     0x82f418: ldur            w6, [x1, #0x1b]
    // 0x82f41c: DecompressPointer r6
    //     0x82f41c: add             x6, x6, HEAP, lsl #32
    // 0x82f420: stur            x6, [fp, #-0x10]
    // 0x82f424: LoadField: r7 = r1->field_23
    //     0x82f424: ldur            w7, [x1, #0x23]
    // 0x82f428: DecompressPointer r7
    //     0x82f428: add             x7, x7, HEAP, lsl #32
    // 0x82f42c: stur            x7, [fp, #-8]
    // 0x82f430: r0 = GesturePageView()
    //     0x82f430: bl              #0x82f67c  ; AllocateGesturePageViewStub -> GesturePageView (size=0x48)
    // 0x82f434: stur            x0, [fp, #-0x38]
    // 0x82f438: ldur            x16, [fp, #-0x18]
    // 0x82f43c: stp             x16, x0, [SP, #-0x10]!
    // 0x82f440: ldur            x16, [fp, #-0x20]
    // 0x82f444: ldur            lr, [fp, #-0x30]
    // 0x82f448: stp             lr, x16, [SP, #-0x10]!
    // 0x82f44c: ldur            x16, [fp, #-8]
    // 0x82f450: ldur            lr, [fp, #-0x10]
    // 0x82f454: stp             lr, x16, [SP, #-0x10]!
    // 0x82f458: ldur            x16, [fp, #-0x28]
    // 0x82f45c: SaveReg r16
    //     0x82f45c: str             x16, [SP, #-8]!
    // 0x82f460: r0 = GesturePageView.custom()
    //     0x82f460: bl              #0x82f554  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] GesturePageView::GesturePageView.custom
    // 0x82f464: add             SP, SP, #0x38
    // 0x82f468: ldr             x0, [fp, #0x18]
    // 0x82f46c: LoadField: r1 = r0->field_b
    //     0x82f46c: ldur            w1, [x0, #0xb]
    // 0x82f470: DecompressPointer r1
    //     0x82f470: add             x1, x1, HEAP, lsl #32
    // 0x82f474: cmp             w1, NULL
    // 0x82f478: b.eq            #0x82f544
    // 0x82f47c: LoadField: r2 = r1->field_1b
    //     0x82f47c: ldur            w2, [x1, #0x1b]
    // 0x82f480: DecompressPointer r2
    //     0x82f480: add             x2, x2, HEAP, lsl #32
    // 0x82f484: LoadField: r1 = r2->field_7
    //     0x82f484: ldur            w1, [x2, #7]
    // 0x82f488: DecompressPointer r1
    //     0x82f488: add             x1, x1, HEAP, lsl #32
    // 0x82f48c: stur            x1, [fp, #-8]
    // 0x82f490: cmp             w1, NULL
    // 0x82f494: b.eq            #0x82f4e8
    // 0x82f498: r0 = InitLateStaticField(0xb98) // [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ::_testPageMetrics
    //     0x82f498: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x82f49c: ldr             x0, [x0, #0x1730]
    //     0x82f4a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x82f4a4: cmp             w0, w16
    //     0x82f4a8: b.ne            #0x82f4b8
    //     0x82f4ac: add             x2, PP, #0x51, lsl #12  ; [pp+0x513d0] Field <::._testPageMetrics@410206143>: static late final (offset: 0xb98)
    //     0x82f4b0: ldr             x2, [x2, #0x3d0]
    //     0x82f4b4: bl              #0xd67cdc
    // 0x82f4b8: mov             x1, x0
    // 0x82f4bc: ldur            x0, [fp, #-8]
    // 0x82f4c0: r2 = LoadClassIdInstr(r0)
    //     0x82f4c0: ldur            x2, [x0, #-1]
    //     0x82f4c4: ubfx            x2, x2, #0xc, #0x14
    // 0x82f4c8: stp             x1, x0, [SP, #-0x10]!
    // 0x82f4cc: mov             x0, x2
    // 0x82f4d0: r0 = GDT[cid_x0 + 0x72d]()
    //     0x82f4d0: add             lr, x0, #0x72d
    //     0x82f4d4: ldr             lr, [x21, lr, lsl #3]
    //     0x82f4d8: blr             lr
    // 0x82f4dc: add             SP, SP, #0x10
    // 0x82f4e0: tbnz            w0, #4, #0x82f524
    // 0x82f4e4: ldr             x0, [fp, #0x18]
    // 0x82f4e8: ldur            x1, [fp, #-0x38]
    // 0x82f4ec: LoadField: r2 = r0->field_1f
    //     0x82f4ec: ldur            w2, [x0, #0x1f]
    // 0x82f4f0: DecompressPointer r2
    //     0x82f4f0: add             x2, x2, HEAP, lsl #32
    // 0x82f4f4: stur            x2, [fp, #-8]
    // 0x82f4f8: r0 = RawGestureDetector()
    //     0x82f4f8: bl              #0x82f548  ; AllocateRawGestureDetectorStub -> RawGestureDetector (size=0x20)
    // 0x82f4fc: ldur            x1, [fp, #-0x38]
    // 0x82f500: StoreField: r0->field_b = r1
    //     0x82f500: stur            w1, [x0, #0xb]
    // 0x82f504: ldur            x2, [fp, #-8]
    // 0x82f508: StoreField: r0->field_f = r2
    //     0x82f508: stur            w2, [x0, #0xf]
    // 0x82f50c: r2 = Instance_HitTestBehavior
    //     0x82f50c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15408] Obj!HitTestBehavior@b648f1
    //     0x82f510: ldr             x2, [x2, #0x408]
    // 0x82f514: StoreField: r0->field_13 = r2
    //     0x82f514: stur            w2, [x0, #0x13]
    // 0x82f518: r2 = false
    //     0x82f518: add             x2, NULL, #0x30  ; false
    // 0x82f51c: StoreField: r0->field_17 = r2
    //     0x82f51c: stur            w2, [x0, #0x17]
    // 0x82f520: b               #0x82f52c
    // 0x82f524: ldur            x1, [fp, #-0x38]
    // 0x82f528: mov             x0, x1
    // 0x82f52c: LeaveFrame
    //     0x82f52c: mov             SP, fp
    //     0x82f530: ldp             fp, lr, [SP], #0x10
    // 0x82f534: ret
    //     0x82f534: ret             
    // 0x82f538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f538: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f53c: b               #0x82f3d4
    // 0x82f540: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f540: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82f544: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f544: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d6100, size: 0xa0
    // 0x9d6100: EnterFrame
    //     0x9d6100: stp             fp, lr, [SP, #-0x10]!
    //     0x9d6104: mov             fp, SP
    // 0x9d6108: AllocStack(0x10)
    //     0x9d6108: sub             SP, SP, #0x10
    // 0x9d610c: CheckStackOverflow
    //     0x9d610c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d6110: cmp             SP, x16
    //     0x9d6114: b.ls            #0x9d6198
    // 0x9d6118: r1 = 1
    //     0x9d6118: mov             x1, #1
    // 0x9d611c: r0 = AllocateContext()
    //     0x9d611c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d6120: mov             x1, x0
    // 0x9d6124: ldr             x0, [fp, #0x10]
    // 0x9d6128: StoreField: r1->field_f = r0
    //     0x9d6128: stur            w0, [x1, #0xf]
    // 0x9d612c: mov             x2, x1
    // 0x9d6130: r1 = Function '<anonymous closure>':.
    //     0x9d6130: add             x1, PP, #0x51, lsl #12  ; [pp+0x51458] AnonymousClosure: (0x9d61a0), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::initState (0x9d6100)
    //     0x9d6134: ldr             x1, [x1, #0x458]
    // 0x9d6138: r0 = AllocateClosure()
    //     0x9d6138: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d613c: stur            x0, [fp, #-8]
    // 0x9d6140: r0 = GestureAnimation()
    //     0x9d6140: bl              #0x79bd84  ; AllocateGestureAnimationStub -> GestureAnimation (size=0x18)
    // 0x9d6144: stur            x0, [fp, #-0x10]
    // 0x9d6148: ldr             x16, [fp, #0x10]
    // 0x9d614c: stp             x16, x0, [SP, #-0x10]!
    // 0x9d6150: ldur            x16, [fp, #-8]
    // 0x9d6154: SaveReg r16
    //     0x9d6154: str             x16, [SP, #-8]!
    // 0x9d6158: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9d6158: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9d615c: r0 = GestureAnimation()
    //     0x9d615c: bl              #0x79b9d0  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::GestureAnimation
    // 0x9d6160: add             SP, SP, #0x18
    // 0x9d6164: ldur            x0, [fp, #-0x10]
    // 0x9d6168: ldr             x1, [fp, #0x10]
    // 0x9d616c: StoreField: r1->field_23 = r0
    //     0x9d616c: stur            w0, [x1, #0x23]
    //     0x9d6170: ldurb           w16, [x1, #-1]
    //     0x9d6174: ldurb           w17, [x0, #-1]
    //     0x9d6178: and             x16, x17, x16, lsr #2
    //     0x9d617c: tst             x16, HEAP, lsr #32
    //     0x9d6180: b.eq            #0x9d6188
    //     0x9d6184: bl              #0xd6826c
    // 0x9d6188: r0 = Null
    //     0x9d6188: mov             x0, NULL
    // 0x9d618c: LeaveFrame
    //     0x9d618c: mov             SP, fp
    //     0x9d6190: ldp             fp, lr, [SP], #0x10
    // 0x9d6194: ret
    //     0x9d6194: ret             
    // 0x9d6198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d6198: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d619c: b               #0x9d6118
  }
  [closure] void <anonymous closure>(dynamic, Offset) {
    // ** addr: 0x9d61a0, size: 0x170
    // 0x9d61a0: EnterFrame
    //     0x9d61a0: stp             fp, lr, [SP, #-0x10]!
    //     0x9d61a4: mov             fp, SP
    // 0x9d61a8: AllocStack(0x20)
    //     0x9d61a8: sub             SP, SP, #0x20
    // 0x9d61ac: SetupParameters()
    //     0x9d61ac: ldr             x0, [fp, #0x18]
    //     0x9d61b0: ldur            w3, [x0, #0x17]
    //     0x9d61b4: add             x3, x3, HEAP, lsl #32
    //     0x9d61b8: stur            x3, [fp, #-0x10]
    // 0x9d61bc: CheckStackOverflow
    //     0x9d61bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d61c0: cmp             SP, x16
    //     0x9d61c4: b.ls            #0x9d6308
    // 0x9d61c8: LoadField: r0 = r3->field_f
    //     0x9d61c8: ldur            w0, [x3, #0xf]
    // 0x9d61cc: DecompressPointer r0
    //     0x9d61cc: add             x0, x0, HEAP, lsl #32
    // 0x9d61d0: LoadField: r4 = r0->field_27
    //     0x9d61d0: ldur            w4, [x0, #0x27]
    // 0x9d61d4: DecompressPointer r4
    //     0x9d61d4: add             x4, x4, HEAP, lsl #32
    // 0x9d61d8: stur            x4, [fp, #-8]
    // 0x9d61dc: r1 = Function '<anonymous closure>':.
    //     0x9d61dc: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c678] AnonymousClosure: (0x82df78), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::extendedImageGestureState (0x82dcf4)
    //     0x9d61e0: ldr             x1, [x1, #0x678]
    // 0x9d61e4: r2 = Null
    //     0x9d61e4: mov             x2, NULL
    // 0x9d61e8: r0 = AllocateClosure()
    //     0x9d61e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d61ec: r1 = Function '<anonymous closure>':.
    //     0x9d61ec: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c680] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x9d61f0: ldr             x1, [x1, #0x680]
    // 0x9d61f4: r2 = Null
    //     0x9d61f4: mov             x2, NULL
    // 0x9d61f8: stur            x0, [fp, #-0x18]
    // 0x9d61fc: r0 = AllocateClosure()
    //     0x9d61fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d6200: ldur            x16, [fp, #-8]
    // 0x9d6204: ldur            lr, [fp, #-0x18]
    // 0x9d6208: stp             lr, x16, [SP, #-0x10]!
    // 0x9d620c: SaveReg r0
    //     0x9d620c: str             x0, [SP, #-8]!
    // 0x9d6210: r4 = const [0, 0x3, 0x3, 0x2, orElse, 0x2, null]
    //     0x9d6210: ldr             x4, [PP, #0x6bc8]  ; [pp+0x6bc8] List(7) [0, 0x3, 0x3, 0x2, "orElse", 0x2, Null]
    // 0x9d6214: r0 = lastWhere()
    //     0x9d6214: bl              #0x82dd70  ; [dart:collection] __Set&_HashVMBase&SetMixin::lastWhere
    // 0x9d6218: add             SP, SP, #0x18
    // 0x9d621c: cmp             w0, NULL
    // 0x9d6220: b.ne            #0x9d622c
    // 0x9d6224: r0 = Null
    //     0x9d6224: mov             x0, NULL
    // 0x9d6228: b               #0x9d6238
    // 0x9d622c: LoadField: r1 = r0->field_1b
    //     0x9d622c: ldur            w1, [x0, #0x1b]
    // 0x9d6230: DecompressPointer r1
    //     0x9d6230: add             x1, x1, HEAP, lsl #32
    // 0x9d6234: mov             x0, x1
    // 0x9d6238: stur            x0, [fp, #-0x18]
    // 0x9d623c: cmp             w0, NULL
    // 0x9d6240: b.eq            #0x9d62f8
    // 0x9d6244: ldur            x1, [fp, #-0x10]
    // 0x9d6248: LoadField: r2 = r1->field_f
    //     0x9d6248: ldur            w2, [x1, #0xf]
    // 0x9d624c: DecompressPointer r2
    //     0x9d624c: add             x2, x2, HEAP, lsl #32
    // 0x9d6250: LoadField: r3 = r2->field_27
    //     0x9d6250: ldur            w3, [x2, #0x27]
    // 0x9d6254: DecompressPointer r3
    //     0x9d6254: add             x3, x3, HEAP, lsl #32
    // 0x9d6258: stur            x3, [fp, #-8]
    // 0x9d625c: r1 = Function '<anonymous closure>':.
    //     0x9d625c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c678] AnonymousClosure: (0x82df78), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::extendedImageGestureState (0x82dcf4)
    //     0x9d6260: ldr             x1, [x1, #0x678]
    // 0x9d6264: r2 = Null
    //     0x9d6264: mov             x2, NULL
    // 0x9d6268: r0 = AllocateClosure()
    //     0x9d6268: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d626c: r1 = Function '<anonymous closure>':.
    //     0x9d626c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c680] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x9d6270: ldr             x1, [x1, #0x680]
    // 0x9d6274: r2 = Null
    //     0x9d6274: mov             x2, NULL
    // 0x9d6278: stur            x0, [fp, #-0x10]
    // 0x9d627c: r0 = AllocateClosure()
    //     0x9d627c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d6280: ldur            x16, [fp, #-8]
    // 0x9d6284: ldur            lr, [fp, #-0x10]
    // 0x9d6288: stp             lr, x16, [SP, #-0x10]!
    // 0x9d628c: SaveReg r0
    //     0x9d628c: str             x0, [SP, #-8]!
    // 0x9d6290: r4 = const [0, 0x3, 0x3, 0x2, orElse, 0x2, null]
    //     0x9d6290: ldr             x4, [PP, #0x6bc8]  ; [pp+0x6bc8] List(7) [0, 0x3, 0x3, 0x2, "orElse", 0x2, Null]
    // 0x9d6294: r0 = lastWhere()
    //     0x9d6294: bl              #0x82dd70  ; [dart:collection] __Set&_HashVMBase&SetMixin::lastWhere
    // 0x9d6298: add             SP, SP, #0x18
    // 0x9d629c: stur            x0, [fp, #-8]
    // 0x9d62a0: cmp             w0, NULL
    // 0x9d62a4: b.eq            #0x9d62f8
    // 0x9d62a8: ldur            x1, [fp, #-0x18]
    // 0x9d62ac: LoadField: d0 = r1->field_b
    //     0x9d62ac: ldur            d0, [x1, #0xb]
    // 0x9d62b0: stur            d0, [fp, #-0x20]
    // 0x9d62b4: r0 = GestureDetails()
    //     0x9d62b4: bl              #0x79bffc  ; AllocateGestureDetailsStub -> GestureDetails (size=0x40)
    // 0x9d62b8: stur            x0, [fp, #-0x10]
    // 0x9d62bc: ldr             x16, [fp, #0x10]
    // 0x9d62c0: stp             x16, x0, [SP, #-0x10]!
    // 0x9d62c4: ldur            d0, [fp, #-0x20]
    // 0x9d62c8: SaveReg d0
    //     0x9d62c8: str             d0, [SP, #-8]!
    // 0x9d62cc: ldur            x16, [fp, #-0x18]
    // 0x9d62d0: SaveReg r16
    //     0x9d62d0: str             x16, [SP, #-8]!
    // 0x9d62d4: r4 = const [0, 0x4, 0x4, 0x3, gestureDetails, 0x3, null]
    //     0x9d62d4: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4c5b8] List(7) [0, 0x4, 0x4, 0x3, "gestureDetails", 0x3, Null]
    //     0x9d62d8: ldr             x4, [x4, #0x5b8]
    // 0x9d62dc: r0 = GestureDetails()
    //     0x9d62dc: bl              #0x79bd90  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::GestureDetails
    // 0x9d62e0: add             SP, SP, #0x20
    // 0x9d62e4: ldur            x16, [fp, #-8]
    // 0x9d62e8: ldur            lr, [fp, #-0x10]
    // 0x9d62ec: stp             lr, x16, [SP, #-0x10]!
    // 0x9d62f0: r0 = gestureDetails=()
    //     0x9d62f0: bl              #0x79c0e0  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::gestureDetails=
    // 0x9d62f4: add             SP, SP, #0x10
    // 0x9d62f8: r0 = Null
    //     0x9d62f8: mov             x0, NULL
    // 0x9d62fc: LeaveFrame
    //     0x9d62fc: mov             SP, fp
    //     0x9d6300: ldp             fp, lr, [SP], #0x10
    // 0x9d6304: ret
    //     0x9d6304: ret             
    // 0x9d6308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d6308: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d630c: b               #0x9d61c8
  }
  _ ExtendedImageGesturePageViewState(/* No info */) {
    // ** addr: 0xa3f31c, size: 0xd8
    // 0xa3f31c: EnterFrame
    //     0xa3f31c: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f320: mov             fp, SP
    // 0xa3f324: AllocStack(0x10)
    //     0xa3f324: sub             SP, SP, #0x10
    // 0xa3f328: r1 = _ConstMap len:0
    //     0xa3f328: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f3d0] Map<Type, GestureRecognizerFactory<GestureRecognizer>>(0)
    //     0xa3f32c: ldr             x1, [x1, #0x3d0]
    // 0xa3f330: r0 = Sentinel
    //     0xa3f330: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3f334: CheckStackOverflow
    //     0xa3f334: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3f338: cmp             SP, x16
    //     0xa3f33c: b.ls            #0xa3f3ec
    // 0xa3f340: ldr             x2, [fp, #0x10]
    // 0xa3f344: StoreField: r2->field_1f = r1
    //     0xa3f344: stur            w1, [x2, #0x1f]
    // 0xa3f348: StoreField: r2->field_23 = r0
    //     0xa3f348: stur            w0, [x2, #0x23]
    // 0xa3f34c: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xa3f34c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa3f350: ldr             x0, [x0, #0x598]
    //     0xa3f354: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa3f358: cmp             w0, w16
    //     0xa3f35c: b.ne            #0xa3f368
    //     0xa3f360: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xa3f364: bl              #0xd67cdc
    // 0xa3f368: r1 = <ExtendedImageGestureState<ExtendedImageGesture>?>
    //     0xa3f368: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c570] TypeArguments: <ExtendedImageGestureState<ExtendedImageGesture>?>
    //     0xa3f36c: ldr             x1, [x1, #0x570]
    // 0xa3f370: stur            x0, [fp, #-8]
    // 0xa3f374: r0 = _Set()
    //     0xa3f374: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xa3f378: mov             x1, x0
    // 0xa3f37c: ldur            x0, [fp, #-8]
    // 0xa3f380: stur            x1, [fp, #-0x10]
    // 0xa3f384: StoreField: r1->field_1b = r0
    //     0xa3f384: stur            w0, [x1, #0x1b]
    // 0xa3f388: StoreField: r1->field_b = rZR
    //     0xa3f388: stur            wzr, [x1, #0xb]
    // 0xa3f38c: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xa3f38c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa3f390: ldr             x0, [x0, #0x5a0]
    //     0xa3f394: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa3f398: cmp             w0, w16
    //     0xa3f39c: b.ne            #0xa3f3a8
    //     0xa3f3a0: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xa3f3a4: bl              #0xd67cdc
    // 0xa3f3a8: mov             x1, x0
    // 0xa3f3ac: ldur            x0, [fp, #-0x10]
    // 0xa3f3b0: StoreField: r0->field_f = r1
    //     0xa3f3b0: stur            w1, [x0, #0xf]
    // 0xa3f3b4: StoreField: r0->field_13 = rZR
    //     0xa3f3b4: stur            wzr, [x0, #0x13]
    // 0xa3f3b8: StoreField: r0->field_17 = rZR
    //     0xa3f3b8: stur            wzr, [x0, #0x17]
    // 0xa3f3bc: ldr             x1, [fp, #0x10]
    // 0xa3f3c0: StoreField: r1->field_27 = r0
    //     0xa3f3c0: stur            w0, [x1, #0x27]
    //     0xa3f3c4: ldurb           w16, [x1, #-1]
    //     0xa3f3c8: ldurb           w17, [x0, #-1]
    //     0xa3f3cc: and             x16, x17, x16, lsr #2
    //     0xa3f3d0: tst             x16, HEAP, lsr #32
    //     0xa3f3d4: b.eq            #0xa3f3dc
    //     0xa3f3d8: bl              #0xd6826c
    // 0xa3f3dc: r0 = Null
    //     0xa3f3dc: mov             x0, NULL
    // 0xa3f3e0: LeaveFrame
    //     0xa3f3e0: mov             SP, fp
    //     0xa3f3e4: ldp             fp, lr, [SP], #0x10
    // 0xa3f3e8: ret
    //     0xa3f3e8: ret             
    // 0xa3f3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3f3ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3f3f0: b               #0xa3f340
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a1c8, size: 0x18
    // 0xa4a1c8: r4 = 7
    //     0xa4a1c8: mov             x4, #7
    // 0xa4a1cc: r1 = Function 'dispose':.
    //     0xa4a1cc: add             x17, PP, #0x51, lsl #12  ; [pp+0x513c8] AnonymousClosure: (0xa4a1e0), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::dispose (0xa4f080)
    //     0xa4a1d0: ldr             x1, [x17, #0x3c8]
    // 0xa4a1d4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a1d4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a1d8: LoadField: r0 = r24->field_17
    //     0xa4a1d8: ldur            x0, [x24, #0x17]
    // 0xa4a1dc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a1e0, size: 0x48
    // 0xa4a1e0: EnterFrame
    //     0xa4a1e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a1e4: mov             fp, SP
    // 0xa4a1e8: ldr             x0, [fp, #0x10]
    // 0xa4a1ec: LoadField: r1 = r0->field_17
    //     0xa4a1ec: ldur            w1, [x0, #0x17]
    // 0xa4a1f0: DecompressPointer r1
    //     0xa4a1f0: add             x1, x1, HEAP, lsl #32
    // 0xa4a1f4: CheckStackOverflow
    //     0xa4a1f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a1f8: cmp             SP, x16
    //     0xa4a1fc: b.ls            #0xa4a220
    // 0xa4a200: LoadField: r0 = r1->field_f
    //     0xa4a200: ldur            w0, [x1, #0xf]
    // 0xa4a204: DecompressPointer r0
    //     0xa4a204: add             x0, x0, HEAP, lsl #32
    // 0xa4a208: SaveReg r0
    //     0xa4a208: str             x0, [SP, #-8]!
    // 0xa4a20c: r0 = dispose()
    //     0xa4a20c: bl              #0xa4f080  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::dispose
    // 0xa4a210: add             SP, SP, #8
    // 0xa4a214: LeaveFrame
    //     0xa4a214: mov             SP, fp
    //     0xa4a218: ldp             fp, lr, [SP], #0x10
    // 0xa4a21c: ret
    //     0xa4a21c: ret             
    // 0xa4a220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a220: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a224: b               #0xa4a200
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4f080, size: 0x6c
    // 0xa4f080: EnterFrame
    //     0xa4f080: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f084: mov             fp, SP
    // 0xa4f088: CheckStackOverflow
    //     0xa4f088: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f08c: cmp             SP, x16
    //     0xa4f090: b.ls            #0xa4f0d8
    // 0xa4f094: ldr             x0, [fp, #0x10]
    // 0xa4f098: LoadField: r1 = r0->field_23
    //     0xa4f098: ldur            w1, [x0, #0x23]
    // 0xa4f09c: DecompressPointer r1
    //     0xa4f09c: add             x1, x1, HEAP, lsl #32
    // 0xa4f0a0: r16 = Sentinel
    //     0xa4f0a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4f0a4: cmp             w1, w16
    // 0xa4f0a8: b.eq            #0xa4f0e0
    // 0xa4f0ac: SaveReg r1
    //     0xa4f0ac: str             x1, [SP, #-8]!
    // 0xa4f0b0: r0 = dispose()
    //     0xa4f0b0: bl              #0xa4f000  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::dispose
    // 0xa4f0b4: add             SP, SP, #8
    // 0xa4f0b8: ldr             x16, [fp, #0x10]
    // 0xa4f0bc: SaveReg r16
    //     0xa4f0bc: str             x16, [SP, #-8]!
    // 0xa4f0c0: r0 = dispose()
    //     0xa4f0c0: bl              #0xa4f0ec  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] _ExtendedImageGesturePageViewState&State&SingleTickerProviderStateMixin::dispose
    // 0xa4f0c4: add             SP, SP, #8
    // 0xa4f0c8: r0 = Null
    //     0xa4f0c8: mov             x0, NULL
    // 0xa4f0cc: LeaveFrame
    //     0xa4f0cc: mov             SP, fp
    //     0xa4f0d0: ldp             fp, lr, [SP], #0x10
    // 0xa4f0d4: ret
    //     0xa4f0d4: ret             
    // 0xa4f0d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f0d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f0dc: b               #0xa4f094
    // 0xa4f0e0: r9 = _gestureAnimation
    //     0xa4f0e0: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c6d0] Field <ExtendedImageGesturePageViewState._gestureAnimation@410206143>: late (offset: 0x24)
    //     0xa4f0e4: ldr             x9, [x9, #0x6d0]
    // 0xa4f0e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4f0e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa5fb60, size: 0x80
    // 0xa5fb60: EnterFrame
    //     0xa5fb60: stp             fp, lr, [SP, #-0x10]!
    //     0xa5fb64: mov             fp, SP
    // 0xa5fb68: CheckStackOverflow
    //     0xa5fb68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5fb6c: cmp             SP, x16
    //     0xa5fb70: b.ls            #0xa5fbd4
    // 0xa5fb74: ldr             x0, [fp, #0x10]
    // 0xa5fb78: LoadField: r1 = r0->field_f
    //     0xa5fb78: ldur            w1, [x0, #0xf]
    // 0xa5fb7c: DecompressPointer r1
    //     0xa5fb7c: add             x1, x1, HEAP, lsl #32
    // 0xa5fb80: cmp             w1, NULL
    // 0xa5fb84: b.eq            #0xa5fbdc
    // 0xa5fb88: SaveReg r1
    //     0xa5fb88: str             x1, [SP, #-8]!
    // 0xa5fb8c: r0 = maybeOf()
    //     0xa5fb8c: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0xa5fb90: add             SP, SP, #8
    // 0xa5fb94: ldr             x1, [fp, #0x10]
    // 0xa5fb98: StoreField: r1->field_1b = r0
    //     0xa5fb98: stur            w0, [x1, #0x1b]
    //     0xa5fb9c: ldurb           w16, [x1, #-1]
    //     0xa5fba0: ldurb           w17, [x0, #-1]
    //     0xa5fba4: and             x16, x17, x16, lsr #2
    //     0xa5fba8: tst             x16, HEAP, lsr #32
    //     0xa5fbac: b.eq            #0xa5fbb4
    //     0xa5fbb0: bl              #0xd6826c
    // 0xa5fbb4: SaveReg r1
    //     0xa5fbb4: str             x1, [SP, #-8]!
    // 0xa5fbb8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa5fbb8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa5fbbc: r0 = _initGestureRecognizers()
    //     0xa5fbbc: bl              #0x79c30c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::_initGestureRecognizers
    // 0xa5fbc0: add             SP, SP, #8
    // 0xa5fbc4: r0 = Null
    //     0xa5fbc4: mov             x0, NULL
    // 0xa5fbc8: LeaveFrame
    //     0xa5fbc8: mov             SP, fp
    //     0xa5fbcc: ldp             fp, lr, [SP], #0x10
    // 0xa5fbd0: ret
    //     0xa5fbd0: ret             
    // 0xa5fbd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5fbd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5fbd8: b               #0xa5fb74
    // 0xa5fbdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5fbdc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic canHorizontalOrVerticalDrag(dynamic) {
    // ** addr: 0xce1edc, size: 0x18
    // 0xce1edc: r4 = 7
    //     0xce1edc: mov             x4, #7
    // 0xce1ee0: r1 = Function 'canHorizontalOrVerticalDrag':.
    //     0xce1ee0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53980] AnonymousClosure: (0xce1ef4), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::canHorizontalOrVerticalDrag (0xce1f3c)
    //     0xce1ee4: ldr             x1, [x17, #0x980]
    // 0xce1ee8: r24 = BuildNonGenericMethodExtractorStub
    //     0xce1ee8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xce1eec: LoadField: r0 = r24->field_17
    //     0xce1eec: ldur            x0, [x24, #0x17]
    // 0xce1ef0: br              x0
  }
  [closure] bool canHorizontalOrVerticalDrag(dynamic) {
    // ** addr: 0xce1ef4, size: 0x48
    // 0xce1ef4: EnterFrame
    //     0xce1ef4: stp             fp, lr, [SP, #-0x10]!
    //     0xce1ef8: mov             fp, SP
    // 0xce1efc: ldr             x0, [fp, #0x10]
    // 0xce1f00: LoadField: r1 = r0->field_17
    //     0xce1f00: ldur            w1, [x0, #0x17]
    // 0xce1f04: DecompressPointer r1
    //     0xce1f04: add             x1, x1, HEAP, lsl #32
    // 0xce1f08: CheckStackOverflow
    //     0xce1f08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce1f0c: cmp             SP, x16
    //     0xce1f10: b.ls            #0xce1f34
    // 0xce1f14: LoadField: r0 = r1->field_f
    //     0xce1f14: ldur            w0, [x1, #0xf]
    // 0xce1f18: DecompressPointer r0
    //     0xce1f18: add             x0, x0, HEAP, lsl #32
    // 0xce1f1c: SaveReg r0
    //     0xce1f1c: str             x0, [SP, #-8]!
    // 0xce1f20: r0 = canHorizontalOrVerticalDrag()
    //     0xce1f20: bl              #0xce1f3c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::canHorizontalOrVerticalDrag
    // 0xce1f24: add             SP, SP, #8
    // 0xce1f28: LeaveFrame
    //     0xce1f28: mov             SP, fp
    //     0xce1f2c: ldp             fp, lr, [SP], #0x10
    // 0xce1f30: ret
    //     0xce1f30: ret             
    // 0xce1f34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce1f34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce1f38: b               #0xce1f14
  }
  _ canHorizontalOrVerticalDrag(/* No info */) {
    // ** addr: 0xce1f3c, size: 0x19c
    // 0xce1f3c: EnterFrame
    //     0xce1f3c: stp             fp, lr, [SP, #-0x10]!
    //     0xce1f40: mov             fp, SP
    // 0xce1f44: AllocStack(0x10)
    //     0xce1f44: sub             SP, SP, #0x10
    // 0xce1f48: CheckStackOverflow
    //     0xce1f48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce1f4c: cmp             SP, x16
    //     0xce1f50: b.ls            #0xce20b0
    // 0xce1f54: ldr             x0, [fp, #0x10]
    // 0xce1f58: LoadField: r3 = r0->field_27
    //     0xce1f58: ldur            w3, [x0, #0x27]
    // 0xce1f5c: DecompressPointer r3
    //     0xce1f5c: add             x3, x3, HEAP, lsl #32
    // 0xce1f60: stur            x3, [fp, #-8]
    // 0xce1f64: r1 = Function '<anonymous closure>':.
    //     0xce1f64: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c678] AnonymousClosure: (0x82df78), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::extendedImageGestureState (0x82dcf4)
    //     0xce1f68: ldr             x1, [x1, #0x678]
    // 0xce1f6c: r2 = Null
    //     0xce1f6c: mov             x2, NULL
    // 0xce1f70: r0 = AllocateClosure()
    //     0xce1f70: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce1f74: r1 = Function '<anonymous closure>':.
    //     0xce1f74: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c680] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xce1f78: ldr             x1, [x1, #0x680]
    // 0xce1f7c: r2 = Null
    //     0xce1f7c: mov             x2, NULL
    // 0xce1f80: stur            x0, [fp, #-0x10]
    // 0xce1f84: r0 = AllocateClosure()
    //     0xce1f84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce1f88: ldur            x16, [fp, #-8]
    // 0xce1f8c: ldur            lr, [fp, #-0x10]
    // 0xce1f90: stp             lr, x16, [SP, #-0x10]!
    // 0xce1f94: SaveReg r0
    //     0xce1f94: str             x0, [SP, #-8]!
    // 0xce1f98: r4 = const [0, 0x3, 0x3, 0x2, orElse, 0x2, null]
    //     0xce1f98: ldr             x4, [PP, #0x6bc8]  ; [pp+0x6bc8] List(7) [0, 0x3, 0x3, 0x2, "orElse", 0x2, Null]
    // 0xce1f9c: r0 = lastWhere()
    //     0xce1f9c: bl              #0x82dd70  ; [dart:collection] __Set&_HashVMBase&SetMixin::lastWhere
    // 0xce1fa0: add             SP, SP, #0x18
    // 0xce1fa4: cmp             w0, NULL
    // 0xce1fa8: b.eq            #0xce20a0
    // 0xce1fac: r1 = Function '<anonymous closure>':.
    //     0xce1fac: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c678] AnonymousClosure: (0x82df78), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::extendedImageGestureState (0x82dcf4)
    //     0xce1fb0: ldr             x1, [x1, #0x678]
    // 0xce1fb4: r2 = Null
    //     0xce1fb4: mov             x2, NULL
    // 0xce1fb8: r0 = AllocateClosure()
    //     0xce1fb8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce1fbc: r1 = Function '<anonymous closure>':.
    //     0xce1fbc: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c680] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xce1fc0: ldr             x1, [x1, #0x680]
    // 0xce1fc4: r2 = Null
    //     0xce1fc4: mov             x2, NULL
    // 0xce1fc8: stur            x0, [fp, #-0x10]
    // 0xce1fcc: r0 = AllocateClosure()
    //     0xce1fcc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce1fd0: ldur            x16, [fp, #-8]
    // 0xce1fd4: ldur            lr, [fp, #-0x10]
    // 0xce1fd8: stp             lr, x16, [SP, #-0x10]!
    // 0xce1fdc: SaveReg r0
    //     0xce1fdc: str             x0, [SP, #-8]!
    // 0xce1fe0: r4 = const [0, 0x3, 0x3, 0x2, orElse, 0x2, null]
    //     0xce1fe0: ldr             x4, [PP, #0x6bc8]  ; [pp+0x6bc8] List(7) [0, 0x3, 0x3, 0x2, "orElse", 0x2, Null]
    // 0xce1fe4: r0 = lastWhere()
    //     0xce1fe4: bl              #0x82dd70  ; [dart:collection] __Set&_HashVMBase&SetMixin::lastWhere
    // 0xce1fe8: add             SP, SP, #0x18
    // 0xce1fec: cmp             w0, NULL
    // 0xce1ff0: b.ne            #0xce1ffc
    // 0xce1ff4: r0 = Null
    //     0xce1ff4: mov             x0, NULL
    // 0xce1ff8: b               #0xce2040
    // 0xce1ffc: LoadField: r1 = r0->field_1b
    //     0xce1ffc: ldur            w1, [x0, #0x1b]
    // 0xce2000: DecompressPointer r1
    //     0xce2000: add             x1, x1, HEAP, lsl #32
    // 0xce2004: cmp             w1, NULL
    // 0xce2008: b.ne            #0xce2014
    // 0xce200c: r0 = Null
    //     0xce200c: mov             x0, NULL
    // 0xce2010: b               #0xce2040
    // 0xce2014: LoadField: d0 = r1->field_b
    //     0xce2014: ldur            d0, [x1, #0xb]
    // 0xce2018: r0 = inline_Allocate_Double()
    //     0xce2018: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xce201c: add             x0, x0, #0x10
    //     0xce2020: cmp             x1, x0
    //     0xce2024: b.ls            #0xce20b8
    //     0xce2028: str             x0, [THR, #0x60]  ; THR::top
    //     0xce202c: sub             x0, x0, #0xf
    //     0xce2030: mov             x1, #0xd108
    //     0xce2034: movk            x1, #3, lsl #16
    //     0xce2038: stur            x1, [x0, #-1]
    // 0xce203c: StoreField: r0->field_7 = d0
    //     0xce203c: stur            d0, [x0, #7]
    // 0xce2040: cmp             w0, NULL
    // 0xce2044: b.ne            #0xce2050
    // 0xce2048: d1 = 1.000000
    //     0xce2048: fmov            d1, #1.00000000
    // 0xce204c: b               #0xce2058
    // 0xce2050: LoadField: d0 = r0->field_7
    //     0xce2050: ldur            d0, [x0, #7]
    // 0xce2054: mov             v1.16b, v0.16b
    // 0xce2058: d0 = 1.000000
    //     0xce2058: fmov            d0, #1.00000000
    // 0xce205c: r0 = inline_Allocate_Double()
    //     0xce205c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xce2060: add             x0, x0, #0x10
    //     0xce2064: cmp             x1, x0
    //     0xce2068: b.ls            #0xce20c8
    //     0xce206c: str             x0, [THR, #0x60]  ; THR::top
    //     0xce2070: sub             x0, x0, #0xf
    //     0xce2074: mov             x1, #0xd108
    //     0xce2078: movk            x1, #3, lsl #16
    //     0xce207c: stur            x1, [x0, #-1]
    // 0xce2080: StoreField: r0->field_7 = d1
    //     0xce2080: stur            d1, [x0, #7]
    // 0xce2084: SaveReg r0
    //     0xce2084: str             x0, [SP, #-8]!
    // 0xce2088: SaveReg d0
    //     0xce2088: str             d0, [SP, #-8]!
    // 0xce208c: r0 = DoubleExtension.lessThanOrEqualTo()
    //     0xce208c: bl              #0x6589e8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThanOrEqualTo
    // 0xce2090: add             SP, SP, #0x10
    // 0xce2094: LeaveFrame
    //     0xce2094: mov             SP, fp
    //     0xce2098: ldp             fp, lr, [SP], #0x10
    // 0xce209c: ret
    //     0xce209c: ret             
    // 0xce20a0: r0 = true
    //     0xce20a0: add             x0, NULL, #0x20  ; true
    // 0xce20a4: LeaveFrame
    //     0xce20a4: mov             SP, fp
    //     0xce20a8: ldp             fp, lr, [SP], #0x10
    // 0xce20ac: ret
    //     0xce20ac: ret             
    // 0xce20b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce20b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce20b4: b               #0xce1f54
    // 0xce20b8: SaveReg d0
    //     0xce20b8: str             q0, [SP, #-0x10]!
    // 0xce20bc: r0 = AllocateDouble()
    //     0xce20bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xce20c0: RestoreReg d0
    //     0xce20c0: ldr             q0, [SP], #0x10
    // 0xce20c4: b               #0xce203c
    // 0xce20c8: stp             q0, q1, [SP, #-0x20]!
    // 0xce20cc: r0 = AllocateDouble()
    //     0xce20cc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xce20d0: ldp             q0, q1, [SP], #0x20
    // 0xce20d4: b               #0xce2080
  }
  dynamic onDragCancel(dynamic) {
    // ** addr: 0xce20d8, size: 0x18
    // 0xce20d8: r4 = 7
    //     0xce20d8: mov             x4, #7
    // 0xce20dc: r1 = Function 'onDragCancel':.
    //     0xce20dc: add             x17, PP, #0x53, lsl #12  ; [pp+0x53988] AnonymousClosure: (0xce20f0), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragCancel (0xce2138)
    //     0xce20e0: ldr             x1, [x17, #0x988]
    // 0xce20e4: r24 = BuildNonGenericMethodExtractorStub
    //     0xce20e4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xce20e8: LoadField: r0 = r24->field_17
    //     0xce20e8: ldur            x0, [x24, #0x17]
    // 0xce20ec: br              x0
  }
  [closure] void onDragCancel(dynamic) {
    // ** addr: 0xce20f0, size: 0x48
    // 0xce20f0: EnterFrame
    //     0xce20f0: stp             fp, lr, [SP, #-0x10]!
    //     0xce20f4: mov             fp, SP
    // 0xce20f8: ldr             x0, [fp, #0x10]
    // 0xce20fc: LoadField: r1 = r0->field_17
    //     0xce20fc: ldur            w1, [x0, #0x17]
    // 0xce2100: DecompressPointer r1
    //     0xce2100: add             x1, x1, HEAP, lsl #32
    // 0xce2104: CheckStackOverflow
    //     0xce2104: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce2108: cmp             SP, x16
    //     0xce210c: b.ls            #0xce2130
    // 0xce2110: LoadField: r0 = r1->field_f
    //     0xce2110: ldur            w0, [x1, #0xf]
    // 0xce2114: DecompressPointer r0
    //     0xce2114: add             x0, x0, HEAP, lsl #32
    // 0xce2118: SaveReg r0
    //     0xce2118: str             x0, [SP, #-8]!
    // 0xce211c: r0 = onDragCancel()
    //     0xce211c: bl              #0xce2138  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragCancel
    // 0xce2120: add             SP, SP, #8
    // 0xce2124: LeaveFrame
    //     0xce2124: mov             SP, fp
    //     0xce2128: ldp             fp, lr, [SP], #0x10
    // 0xce212c: ret
    //     0xce212c: ret             
    // 0xce2130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2130: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2134: b               #0xce2110
  }
  _ onDragCancel(/* No info */) {
    // ** addr: 0xce2138, size: 0x88
    // 0xce2138: EnterFrame
    //     0xce2138: stp             fp, lr, [SP, #-0x10]!
    //     0xce213c: mov             fp, SP
    // 0xce2140: CheckStackOverflow
    //     0xce2140: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce2144: cmp             SP, x16
    //     0xce2148: b.ls            #0xce21b8
    // 0xce214c: ldr             x1, [fp, #0x10]
    // 0xce2150: LoadField: r0 = r1->field_2f
    //     0xce2150: ldur            w0, [x1, #0x2f]
    // 0xce2154: DecompressPointer r0
    //     0xce2154: add             x0, x0, HEAP, lsl #32
    // 0xce2158: cmp             w0, NULL
    // 0xce215c: b.ne            #0xce2168
    // 0xce2160: mov             x0, x1
    // 0xce2164: b               #0xce218c
    // 0xce2168: r2 = LoadClassIdInstr(r0)
    //     0xce2168: ldur            x2, [x0, #-1]
    //     0xce216c: ubfx            x2, x2, #0xc, #0x14
    // 0xce2170: SaveReg r0
    //     0xce2170: str             x0, [SP, #-8]!
    // 0xce2174: mov             x0, x2
    // 0xce2178: r0 = GDT[cid_x0 + -0xff7]()
    //     0xce2178: sub             lr, x0, #0xff7
    //     0xce217c: ldr             lr, [x21, lr, lsl #3]
    //     0xce2180: blr             lr
    // 0xce2184: add             SP, SP, #8
    // 0xce2188: ldr             x0, [fp, #0x10]
    // 0xce218c: LoadField: r1 = r0->field_2b
    //     0xce218c: ldur            w1, [x0, #0x2b]
    // 0xce2190: DecompressPointer r1
    //     0xce2190: add             x1, x1, HEAP, lsl #32
    // 0xce2194: cmp             w1, NULL
    // 0xce2198: b.eq            #0xce21a8
    // 0xce219c: SaveReg r1
    //     0xce219c: str             x1, [SP, #-8]!
    // 0xce21a0: r0 = cancel()
    //     0xce21a0: bl              #0xd0e848  ; [package:flutter/src/widgets/scroll_activity.dart] HoldScrollActivity::cancel
    // 0xce21a4: add             SP, SP, #8
    // 0xce21a8: r0 = Null
    //     0xce21a8: mov             x0, NULL
    // 0xce21ac: LeaveFrame
    //     0xce21ac: mov             SP, fp
    //     0xce21b0: ldp             fp, lr, [SP], #0x10
    // 0xce21b4: ret
    //     0xce21b4: ret             
    // 0xce21b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce21b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce21bc: b               #0xce214c
  }
  dynamic onDragEnd(dynamic) {
    // ** addr: 0xce21c0, size: 0x18
    // 0xce21c0: r4 = 7
    //     0xce21c0: mov             x4, #7
    // 0xce21c4: r1 = Function 'onDragEnd':.
    //     0xce21c4: add             x17, PP, #0x53, lsl #12  ; [pp+0x53990] AnonymousClosure: (0x82dca8), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragEnd (0x82db7c)
    //     0xce21c8: ldr             x1, [x17, #0x990]
    // 0xce21cc: r24 = BuildNonGenericMethodExtractorStub
    //     0xce21cc: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xce21d0: LoadField: r0 = r24->field_17
    //     0xce21d0: ldur            x0, [x24, #0x17]
    // 0xce21d4: br              x0
  }
  dynamic onDragUpdate(dynamic) {
    // ** addr: 0xce21d8, size: 0x18
    // 0xce21d8: r4 = 7
    //     0xce21d8: mov             x4, #7
    // 0xce21dc: r1 = Function 'onDragUpdate':.
    //     0xce21dc: add             x17, PP, #0x53, lsl #12  ; [pp+0x53998] AnonymousClosure: (0x82e938), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragUpdate (0x82e818)
    //     0xce21e0: ldr             x1, [x17, #0x998]
    // 0xce21e4: r24 = BuildNonGenericMethodExtractorStub
    //     0xce21e4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xce21e8: LoadField: r0 = r24->field_17
    //     0xce21e8: ldur            x0, [x24, #0x17]
    // 0xce21ec: br              x0
  }
  dynamic onDragStart(dynamic) {
    // ** addr: 0xce21f0, size: 0x18
    // 0xce21f0: r4 = 7
    //     0xce21f0: mov             x4, #7
    // 0xce21f4: r1 = Function 'onDragStart':.
    //     0xce21f4: add             x17, PP, #0x53, lsl #12  ; [pp+0x539a0] AnonymousClosure: (0x82ea3c), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragStart (0x82e984)
    //     0xce21f8: ldr             x1, [x17, #0x9a0]
    // 0xce21fc: r24 = BuildNonGenericMethodExtractorStub
    //     0xce21fc: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xce2200: LoadField: r0 = r24->field_17
    //     0xce2200: ldur            x0, [x24, #0x17]
    // 0xce2204: br              x0
  }
  dynamic onDragDown(dynamic) {
    // ** addr: 0xce2208, size: 0x18
    // 0xce2208: r4 = 7
    //     0xce2208: mov             x4, #7
    // 0xce220c: r1 = Function 'onDragDown':.
    //     0xce220c: add             x17, PP, #0x53, lsl #12  ; [pp+0x539a8] AnonymousClosure: (0x82ec94), in [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragDown (0x82eb2c)
    //     0xce2210: ldr             x1, [x17, #0x9a8]
    // 0xce2214: r24 = BuildNonGenericMethodExtractorStub
    //     0xce2214: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xce2218: LoadField: r0 = r24->field_17
    //     0xce2218: ldur            x0, [x24, #0x17]
    // 0xce221c: br              x0
  }
}

// class id: 4210, size: 0x3c, field offset: 0x38
//   const constructor, 
class _Scrollable extends Scrollable {

  _ createState(/* No info */) {
    // ** addr: 0xa3f434, size: 0x4c
    // 0xa3f434: EnterFrame
    //     0xa3f434: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f438: mov             fp, SP
    // 0xa3f43c: AllocStack(0x8)
    //     0xa3f43c: sub             SP, SP, #8
    // 0xa3f440: CheckStackOverflow
    //     0xa3f440: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3f444: cmp             SP, x16
    //     0xa3f448: b.ls            #0xa3f478
    // 0xa3f44c: r1 = <Scrollable>
    //     0xa3f44c: add             x1, PP, #0x38, lsl #12  ; [pp+0x38468] TypeArguments: <Scrollable>
    //     0xa3f450: ldr             x1, [x1, #0x468]
    // 0xa3f454: r0 = _ExtendedScrollableState()
    //     0xa3f454: bl              #0xa3f610  ; Allocate_ExtendedScrollableStateStub -> _ExtendedScrollableState (size=0x68)
    // 0xa3f458: stur            x0, [fp, #-8]
    // 0xa3f45c: SaveReg r0
    //     0xa3f45c: str             x0, [SP, #-8]!
    // 0xa3f460: r0 = ScrollableState()
    //     0xa3f460: bl              #0xa3f480  ; [package:flutter/src/widgets/scrollable.dart] ScrollableState::ScrollableState
    // 0xa3f464: add             SP, SP, #8
    // 0xa3f468: ldur            x0, [fp, #-8]
    // 0xa3f46c: LeaveFrame
    //     0xa3f46c: mov             SP, fp
    //     0xa3f470: ldp             fp, lr, [SP], #0x10
    // 0xa3f474: ret
    //     0xa3f474: ret             
    // 0xa3f478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3f478: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3f47c: b               #0xa3f44c
  }
}

// class id: 4211, size: 0x48, field offset: 0xc
class GesturePageView extends StatefulWidget {

  _ GesturePageView.custom(/* No info */) {
    // ** addr: 0x82f554, size: 0x104
    // 0x82f554: EnterFrame
    //     0x82f554: stp             fp, lr, [SP, #-0x10]!
    //     0x82f558: mov             fp, SP
    // 0x82f55c: r6 = Instance_Axis
    //     0x82f55c: add             x6, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x82f560: ldr             x6, [x6, #0x440]
    // 0x82f564: r5 = true
    //     0x82f564: add             x5, NULL, #0x20  ; true
    // 0x82f568: r4 = Instance_DragStartBehavior
    //     0x82f568: add             x4, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x82f56c: ldr             x4, [x4, #0xf88]
    // 0x82f570: r3 = false
    //     0x82f570: add             x3, NULL, #0x30  ; false
    // 0x82f574: r2 = Instance_Clip
    //     0x82f574: add             x2, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x82f578: ldr             x2, [x2, #0x678]
    // 0x82f57c: r1 = 0
    //     0x82f57c: mov             x1, #0
    // 0x82f580: ldr             x7, [fp, #0x40]
    // 0x82f584: StoreField: r7->field_13 = r6
    //     0x82f584: stur            w6, [x7, #0x13]
    // 0x82f588: ldr             x6, [fp, #0x10]
    // 0x82f58c: StoreField: r7->field_17 = r6
    //     0x82f58c: stur            w6, [x7, #0x17]
    // 0x82f590: ldr             x0, [fp, #0x18]
    // 0x82f594: StoreField: r7->field_1f = r0
    //     0x82f594: stur            w0, [x7, #0x1f]
    //     0x82f598: ldurb           w16, [x7, #-1]
    //     0x82f59c: ldurb           w17, [x0, #-1]
    //     0x82f5a0: and             x16, x17, x16, lsr #2
    //     0x82f5a4: tst             x16, HEAP, lsr #32
    //     0x82f5a8: b.eq            #0x82f5b0
    //     0x82f5ac: bl              #0xd6832c
    // 0x82f5b0: StoreField: r7->field_23 = r5
    //     0x82f5b0: stur            w5, [x7, #0x23]
    // 0x82f5b4: ldr             x0, [fp, #0x20]
    // 0x82f5b8: StoreField: r7->field_27 = r0
    //     0x82f5b8: stur            w0, [x7, #0x27]
    //     0x82f5bc: ldurb           w16, [x7, #-1]
    //     0x82f5c0: ldurb           w17, [x0, #-1]
    //     0x82f5c4: and             x16, x17, x16, lsr #2
    //     0x82f5c8: tst             x16, HEAP, lsr #32
    //     0x82f5cc: b.eq            #0x82f5d4
    //     0x82f5d0: bl              #0xd6832c
    // 0x82f5d4: ldr             x0, [fp, #0x38]
    // 0x82f5d8: StoreField: r7->field_2b = r0
    //     0x82f5d8: stur            w0, [x7, #0x2b]
    //     0x82f5dc: ldurb           w16, [x7, #-1]
    //     0x82f5e0: ldurb           w17, [x0, #-1]
    //     0x82f5e4: and             x16, x17, x16, lsr #2
    //     0x82f5e8: tst             x16, HEAP, lsr #32
    //     0x82f5ec: b.eq            #0x82f5f4
    //     0x82f5f0: bl              #0xd6832c
    // 0x82f5f4: StoreField: r7->field_2f = r4
    //     0x82f5f4: stur            w4, [x7, #0x2f]
    // 0x82f5f8: StoreField: r7->field_b = r3
    //     0x82f5f8: stur            w3, [x7, #0xb]
    // 0x82f5fc: StoreField: r7->field_33 = r2
    //     0x82f5fc: stur            w2, [x7, #0x33]
    // 0x82f600: StoreField: r7->field_3b = r5
    //     0x82f600: stur            w5, [x7, #0x3b]
    // 0x82f604: StoreField: r7->field_3f = r1
    //     0x82f604: stur            x1, [x7, #0x3f]
    // 0x82f608: ldr             x0, [fp, #0x30]
    // 0x82f60c: StoreField: r7->field_1b = r0
    //     0x82f60c: stur            w0, [x7, #0x1b]
    //     0x82f610: ldurb           w16, [x7, #-1]
    //     0x82f614: ldurb           w17, [x0, #-1]
    //     0x82f618: and             x16, x17, x16, lsr #2
    //     0x82f61c: tst             x16, HEAP, lsr #32
    //     0x82f620: b.eq            #0x82f628
    //     0x82f624: bl              #0xd6832c
    // 0x82f628: ldr             x0, [fp, #0x28]
    // 0x82f62c: StoreField: r7->field_7 = r0
    //     0x82f62c: stur            w0, [x7, #7]
    //     0x82f630: ldurb           w16, [x7, #-1]
    //     0x82f634: ldurb           w17, [x0, #-1]
    //     0x82f638: and             x16, x17, x16, lsr #2
    //     0x82f63c: tst             x16, HEAP, lsr #32
    //     0x82f640: b.eq            #0x82f648
    //     0x82f644: bl              #0xd6832c
    // 0x82f648: r0 = Null
    //     0x82f648: mov             x0, NULL
    // 0x82f64c: LeaveFrame
    //     0x82f64c: mov             SP, fp
    //     0x82f650: ldp             fp, lr, [SP], #0x10
    // 0x82f654: ret
    //     0x82f654: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xa3f400, size: 0x28
    // 0xa3f400: EnterFrame
    //     0xa3f400: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f404: mov             fp, SP
    // 0xa3f408: r1 = <GesturePageView>
    //     0xa3f408: add             x1, PP, #0x53, lsl #12  ; [pp+0x539b0] TypeArguments: <GesturePageView>
    //     0xa3f40c: ldr             x1, [x1, #0x9b0]
    // 0xa3f410: r0 = _GesturePageViewState()
    //     0xa3f410: bl              #0xa3f428  ; Allocate_GesturePageViewStateStub -> _GesturePageViewState (size=0x1c)
    // 0xa3f414: r1 = 0
    //     0xa3f414: mov             x1, #0
    // 0xa3f418: StoreField: r0->field_13 = r1
    //     0xa3f418: stur            x1, [x0, #0x13]
    // 0xa3f41c: LeaveFrame
    //     0xa3f41c: mov             SP, fp
    //     0xa3f420: ldp             fp, lr, [SP], #0x10
    // 0xa3f424: ret
    //     0xa3f424: ret             
  }
}

// class id: 4212, size: 0x34, field offset: 0xc
class ExtendedImageGesturePageView extends StatefulWidget {

  _ ExtendedImageGesturePageView.builder(/* No info */) {
    // ** addr: 0x942478, size: 0x234
    // 0x942478: EnterFrame
    //     0x942478: stp             fp, lr, [SP, #-0x10]!
    //     0x94247c: mov             fp, SP
    // 0x942480: AllocStack(0x20)
    //     0x942480: sub             SP, SP, #0x20
    // 0x942484: SetupParameters(ExtendedImageGesturePageView this /* r3, fp-0x20 */, dynamic _ /* r4 */, dynamic _ /* r5, fp-0x18 */, dynamic _ /* r6, fp-0x10 */, dynamic _ /* r7 */, {dynamic physics = Null /* r8, fp-0x8 */, dynamic reverse = false /* r9 */})
    //     0x942484: mov             x0, x4
    //     0x942488: ldur            w1, [x0, #0x13]
    //     0x94248c: add             x1, x1, HEAP, lsl #32
    //     0x942490: sub             x2, x1, #0xa
    //     0x942494: add             x3, fp, w2, sxtw #2
    //     0x942498: ldr             x3, [x3, #0x30]
    //     0x94249c: stur            x3, [fp, #-0x20]
    //     0x9424a0: add             x4, fp, w2, sxtw #2
    //     0x9424a4: ldr             x4, [x4, #0x28]
    //     0x9424a8: add             x5, fp, w2, sxtw #2
    //     0x9424ac: ldr             x5, [x5, #0x20]
    //     0x9424b0: stur            x5, [fp, #-0x18]
    //     0x9424b4: add             x6, fp, w2, sxtw #2
    //     0x9424b8: ldr             x6, [x6, #0x18]
    //     0x9424bc: stur            x6, [fp, #-0x10]
    //     0x9424c0: add             x7, fp, w2, sxtw #2
    //     0x9424c4: ldr             x7, [x7, #0x10]
    //     0x9424c8: ldur            w2, [x0, #0x1f]
    //     0x9424cc: add             x2, x2, HEAP, lsl #32
    //     0x9424d0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26750] "physics"
    //     0x9424d4: ldr             x16, [x16, #0x750]
    //     0x9424d8: cmp             w2, w16
    //     0x9424dc: b.ne            #0x942500
    //     0x9424e0: ldur            w2, [x0, #0x23]
    //     0x9424e4: add             x2, x2, HEAP, lsl #32
    //     0x9424e8: sub             w8, w1, w2
    //     0x9424ec: add             x2, fp, w8, sxtw #2
    //     0x9424f0: ldr             x2, [x2, #8]
    //     0x9424f4: mov             x8, x2
    //     0x9424f8: mov             x2, #1
    //     0x9424fc: b               #0x942508
    //     0x942500: mov             x8, NULL
    //     0x942504: mov             x2, #0
    //     0x942508: stur            x8, [fp, #-8]
    //     0x94250c: lsl             x9, x2, #1
    //     0x942510: lsl             w2, w9, #1
    //     0x942514: add             w9, w2, #8
    //     0x942518: add             x16, x0, w9, sxtw #1
    //     0x94251c: ldur            w10, [x16, #0xf]
    //     0x942520: add             x10, x10, HEAP, lsl #32
    //     0x942524: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d090] "reverse"
    //     0x942528: ldr             x16, [x16, #0x90]
    //     0x94252c: cmp             w10, w16
    //     0x942530: b.ne            #0x942558
    //     0x942534: add             w9, w2, #0xa
    //     0x942538: add             x16, x0, w9, sxtw #1
    //     0x94253c: ldur            w2, [x16, #0xf]
    //     0x942540: add             x2, x2, HEAP, lsl #32
    //     0x942544: sub             w0, w1, w2
    //     0x942548: add             x1, fp, w0, sxtw #2
    //     0x94254c: ldr             x1, [x1, #8]
    //     0x942550: mov             x9, x1
    //     0x942554: b               #0x94255c
    //     0x942558: add             x9, NULL, #0x30  ; false
    //     0x94255c: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x942560: ldr             x0, [x0, #0x440]
    //     0x942564: add             x2, NULL, #0x20  ; true
    //     0x942568: mov             x1, #0
    // 0x94255c: r0 = Instance_Axis
    // 0x942564: r2 = true
    // 0x942568: r1 = 0
    // 0x94256c: CheckStackOverflow
    //     0x94256c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x942570: cmp             SP, x16
    //     0x942574: b.ls            #0x9426a4
    // 0x942578: StoreField: r3->field_f = r0
    //     0x942578: stur            w0, [x3, #0xf]
    // 0x94257c: StoreField: r3->field_13 = r9
    //     0x94257c: stur            w9, [x3, #0x13]
    // 0x942580: StoreField: r3->field_1f = r2
    //     0x942580: stur            w2, [x3, #0x1f]
    // 0x942584: mov             x0, x7
    // 0x942588: StoreField: r3->field_23 = r0
    //     0x942588: stur            w0, [x3, #0x23]
    //     0x94258c: ldurb           w16, [x3, #-1]
    //     0x942590: ldurb           w17, [x0, #-1]
    //     0x942594: and             x16, x17, x16, lsr #2
    //     0x942598: tst             x16, HEAP, lsr #32
    //     0x94259c: b.eq            #0x9425a4
    //     0x9425a0: bl              #0xd682ac
    // 0x9425a4: StoreField: r3->field_2b = r1
    //     0x9425a4: stur            x1, [x3, #0x2b]
    // 0x9425a8: mov             x0, x4
    // 0x9425ac: StoreField: r3->field_17 = r0
    //     0x9425ac: stur            w0, [x3, #0x17]
    //     0x9425b0: ldurb           w16, [x3, #-1]
    //     0x9425b4: ldurb           w17, [x0, #-1]
    //     0x9425b8: and             x16, x17, x16, lsr #2
    //     0x9425bc: tst             x16, HEAP, lsr #32
    //     0x9425c0: b.eq            #0x9425c8
    //     0x9425c4: bl              #0xd682ac
    // 0x9425c8: r0 = SliverChildBuilderDelegate()
    //     0x9425c8: bl              #0x82433c  ; AllocateSliverChildBuilderDelegateStub -> SliverChildBuilderDelegate (size=0x2c)
    // 0x9425cc: mov             x2, x0
    // 0x9425d0: ldur            x0, [fp, #-0x18]
    // 0x9425d4: StoreField: r2->field_7 = r0
    //     0x9425d4: stur            w0, [x2, #7]
    // 0x9425d8: ldur            x3, [fp, #-0x10]
    // 0x9425dc: r0 = BoxInt64Instr(r3)
    //     0x9425dc: sbfiz           x0, x3, #1, #0x1f
    //     0x9425e0: cmp             x3, x0, asr #1
    //     0x9425e4: b.eq            #0x9425f0
    //     0x9425e8: bl              #0xd69bb8
    //     0x9425ec: stur            x3, [x0, #7]
    // 0x9425f0: StoreField: r2->field_b = r0
    //     0x9425f0: stur            w0, [x2, #0xb]
    // 0x9425f4: r0 = true
    //     0x9425f4: add             x0, NULL, #0x20  ; true
    // 0x9425f8: StoreField: r2->field_f = r0
    //     0x9425f8: stur            w0, [x2, #0xf]
    // 0x9425fc: StoreField: r2->field_13 = r0
    //     0x9425fc: stur            w0, [x2, #0x13]
    // 0x942600: StoreField: r2->field_17 = r0
    //     0x942600: stur            w0, [x2, #0x17]
    // 0x942604: r0 = Closure: (Widget, int) => int from Function '_kDefaultSemanticIndexCallback@433358031': static.
    //     0x942604: add             x0, PP, #0x26, lsl #12  ; [pp+0x26768] Closure: (Widget, int) => int from Function '_kDefaultSemanticIndexCallback@433358031': static. (0x7fe6e25677cc)
    //     0x942608: ldr             x0, [x0, #0x768]
    // 0x94260c: StoreField: r2->field_23 = r0
    //     0x94260c: stur            w0, [x2, #0x23]
    // 0x942610: r0 = 0
    //     0x942610: mov             x0, #0
    // 0x942614: StoreField: r2->field_1b = r0
    //     0x942614: stur            x0, [x2, #0x1b]
    // 0x942618: mov             x0, x2
    // 0x94261c: ldur            x1, [fp, #-0x20]
    // 0x942620: StoreField: r1->field_27 = r0
    //     0x942620: stur            w0, [x1, #0x27]
    //     0x942624: ldurb           w16, [x1, #-1]
    //     0x942628: ldurb           w17, [x0, #-1]
    //     0x94262c: and             x16, x17, x16, lsr #2
    //     0x942630: tst             x16, HEAP, lsr #32
    //     0x942634: b.eq            #0x94263c
    //     0x942638: bl              #0xd6826c
    // 0x94263c: ldur            x0, [fp, #-8]
    // 0x942640: cmp             w0, NULL
    // 0x942644: b.eq            #0x942660
    // 0x942648: r16 = Instance_NeverScrollableScrollPhysics
    //     0x942648: add             x16, PP, #0x26, lsl #12  ; [pp+0x26998] Obj!NeverScrollableScrollPhysics@b4fd11
    //     0x94264c: ldr             x16, [x16, #0x998]
    // 0x942650: stp             x0, x16, [SP, #-0x10]!
    // 0x942654: r0 = applyTo()
    //     0x942654: bl              #0xc3b598  ; [package:flutter/src/widgets/scroll_physics.dart] NeverScrollableScrollPhysics::applyTo
    // 0x942658: add             SP, SP, #0x10
    // 0x94265c: b               #0x942668
    // 0x942660: r0 = Instance_NeverScrollableScrollPhysics
    //     0x942660: add             x0, PP, #0x26, lsl #12  ; [pp+0x26998] Obj!NeverScrollableScrollPhysics@b4fd11
    //     0x942664: ldr             x0, [x0, #0x998]
    // 0x942668: ldur            x1, [fp, #-0x20]
    // 0x94266c: r2 = Closure: (GestureDetails?) => bool from Function '_defaultCanScrollPage@410206143': static.
    //     0x94266c: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e3e0] Closure: (GestureDetails?) => bool from Function '_defaultCanScrollPage@410206143': static. (0x7fe6e255cca4)
    //     0x942670: ldr             x2, [x2, #0x3e0]
    // 0x942674: StoreField: r1->field_1b = r0
    //     0x942674: stur            w0, [x1, #0x1b]
    //     0x942678: ldurb           w16, [x1, #-1]
    //     0x94267c: ldurb           w17, [x0, #-1]
    //     0x942680: and             x16, x17, x16, lsr #2
    //     0x942684: tst             x16, HEAP, lsr #32
    //     0x942688: b.eq            #0x942690
    //     0x94268c: bl              #0xd6826c
    // 0x942690: StoreField: r1->field_b = r2
    //     0x942690: stur            w2, [x1, #0xb]
    // 0x942694: r0 = Null
    //     0x942694: mov             x0, NULL
    // 0x942698: LeaveFrame
    //     0x942698: mov             SP, fp
    //     0x94269c: ldp             fp, lr, [SP], #0x10
    // 0x9426a0: ret
    //     0x9426a0: ret             
    // 0x9426a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9426a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9426a8: b               #0x942578
  }
  _ createState(/* No info */) {
    // ** addr: 0xa3f2d0, size: 0x4c
    // 0xa3f2d0: EnterFrame
    //     0xa3f2d0: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f2d4: mov             fp, SP
    // 0xa3f2d8: AllocStack(0x8)
    //     0xa3f2d8: sub             SP, SP, #8
    // 0xa3f2dc: CheckStackOverflow
    //     0xa3f2dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3f2e0: cmp             SP, x16
    //     0xa3f2e4: b.ls            #0xa3f314
    // 0xa3f2e8: r1 = <ExtendedImageGesturePageView>
    //     0xa3f2e8: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c568] TypeArguments: <ExtendedImageGesturePageView>
    //     0xa3f2ec: ldr             x1, [x1, #0x568]
    // 0xa3f2f0: r0 = ExtendedImageGesturePageViewState()
    //     0xa3f2f0: bl              #0xa3f3f4  ; AllocateExtendedImageGesturePageViewStateStub -> ExtendedImageGesturePageViewState (size=0x34)
    // 0xa3f2f4: stur            x0, [fp, #-8]
    // 0xa3f2f8: SaveReg r0
    //     0xa3f2f8: str             x0, [SP, #-8]!
    // 0xa3f2fc: r0 = ExtendedImageGesturePageViewState()
    //     0xa3f2fc: bl              #0xa3f31c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::ExtendedImageGesturePageViewState
    // 0xa3f300: add             SP, SP, #8
    // 0xa3f304: ldur            x0, [fp, #-8]
    // 0xa3f308: LeaveFrame
    //     0xa3f308: mov             SP, fp
    //     0xa3f30c: ldp             fp, lr, [SP], #0x10
    // 0xa3f310: ret
    //     0xa3f310: ret             
    // 0xa3f314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3f314: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3f318: b               #0xa3f2e8
  }
}

// class id: 4494, size: 0x10, field offset: 0xc
//   const constructor, 
class _ForceImplicitScrollPhysics extends ScrollPhysics {

  _ applyTo(/* No info */) {
    // ** addr: 0xc3b17c, size: 0x58
    // 0xc3b17c: EnterFrame
    //     0xc3b17c: stp             fp, lr, [SP, #-0x10]!
    //     0xc3b180: mov             fp, SP
    // 0xc3b184: AllocStack(0x8)
    //     0xc3b184: sub             SP, SP, #8
    // 0xc3b188: CheckStackOverflow
    //     0xc3b188: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3b18c: cmp             SP, x16
    //     0xc3b190: b.ls            #0xc3b1cc
    // 0xc3b194: ldr             x16, [fp, #0x18]
    // 0xc3b198: ldr             lr, [fp, #0x10]
    // 0xc3b19c: stp             lr, x16, [SP, #-0x10]!
    // 0xc3b1a0: r0 = buildParent()
    //     0xc3b1a0: bl              #0xc3b1d4  ; [package:flutter/src/widgets/scroll_physics.dart] ScrollPhysics::buildParent
    // 0xc3b1a4: add             SP, SP, #0x10
    // 0xc3b1a8: stur            x0, [fp, #-8]
    // 0xc3b1ac: r0 = _ForceImplicitScrollPhysics()
    //     0xc3b1ac: bl              #0x82f914  ; Allocate_ForceImplicitScrollPhysicsStub -> _ForceImplicitScrollPhysics (size=0x10)
    // 0xc3b1b0: r1 = false
    //     0xc3b1b0: add             x1, NULL, #0x30  ; false
    // 0xc3b1b4: StoreField: r0->field_b = r1
    //     0xc3b1b4: stur            w1, [x0, #0xb]
    // 0xc3b1b8: ldur            x1, [fp, #-8]
    // 0xc3b1bc: StoreField: r0->field_7 = r1
    //     0xc3b1bc: stur            w1, [x0, #7]
    // 0xc3b1c0: LeaveFrame
    //     0xc3b1c0: mov             SP, fp
    //     0xc3b1c4: ldp             fp, lr, [SP], #0x10
    // 0xc3b1c8: ret
    //     0xc3b1c8: ret             
    // 0xc3b1cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3b1cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3b1d0: b               #0xc3b194
  }
}

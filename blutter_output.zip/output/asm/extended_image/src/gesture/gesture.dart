// lib: , url: package:extended_image/src/gesture/gesture.dart

// class id: 1048932, size: 0x8
class :: {
}

// class id: 3396, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class _ExtendedImageGestureState&State&TickerProviderStateMixin extends State<ExtendedImageGesture>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x613808, size: 0x178
    // 0x613808: EnterFrame
    //     0x613808: stp             fp, lr, [SP, #-0x10]!
    //     0x61380c: mov             fp, SP
    // 0x613810: AllocStack(0x10)
    //     0x613810: sub             SP, SP, #0x10
    // 0x613814: CheckStackOverflow
    //     0x613814: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613818: cmp             SP, x16
    //     0x61381c: b.ls            #0x613970
    // 0x613820: ldr             x0, [fp, #0x18]
    // 0x613824: LoadField: r1 = r0->field_17
    //     0x613824: ldur            w1, [x0, #0x17]
    // 0x613828: DecompressPointer r1
    //     0x613828: add             x1, x1, HEAP, lsl #32
    // 0x61382c: cmp             w1, NULL
    // 0x613830: b.ne            #0x613840
    // 0x613834: SaveReg r0
    //     0x613834: str             x0, [SP, #-8]!
    // 0x613838: r0 = _updateTickerModeNotifier()
    //     0x613838: bl              #0x6139a4  ; [package:extended_image/src/gesture/gesture.dart] _ExtendedImageGestureState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x61383c: add             SP, SP, #8
    // 0x613840: ldr             x0, [fp, #0x18]
    // 0x613844: LoadField: r1 = r0->field_13
    //     0x613844: ldur            w1, [x0, #0x13]
    // 0x613848: DecompressPointer r1
    //     0x613848: add             x1, x1, HEAP, lsl #32
    // 0x61384c: cmp             w1, NULL
    // 0x613850: b.ne            #0x6138e8
    // 0x613854: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x613854: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x613858: ldr             x0, [x0, #0x598]
    //     0x61385c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x613860: cmp             w0, w16
    //     0x613864: b.ne            #0x613870
    //     0x613868: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x61386c: bl              #0xd67cdc
    // 0x613870: r1 = <_WidgetTicker>
    //     0x613870: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x613874: ldr             x1, [x1, #0x210]
    // 0x613878: stur            x0, [fp, #-8]
    // 0x61387c: r0 = _Set()
    //     0x61387c: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x613880: mov             x1, x0
    // 0x613884: ldur            x0, [fp, #-8]
    // 0x613888: stur            x1, [fp, #-0x10]
    // 0x61388c: StoreField: r1->field_1b = r0
    //     0x61388c: stur            w0, [x1, #0x1b]
    // 0x613890: StoreField: r1->field_b = rZR
    //     0x613890: stur            wzr, [x1, #0xb]
    // 0x613894: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x613894: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x613898: ldr             x0, [x0, #0x5a0]
    //     0x61389c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6138a0: cmp             w0, w16
    //     0x6138a4: b.ne            #0x6138b0
    //     0x6138a8: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x6138ac: bl              #0xd67cdc
    // 0x6138b0: mov             x1, x0
    // 0x6138b4: ldur            x0, [fp, #-0x10]
    // 0x6138b8: StoreField: r0->field_f = r1
    //     0x6138b8: stur            w1, [x0, #0xf]
    // 0x6138bc: StoreField: r0->field_13 = rZR
    //     0x6138bc: stur            wzr, [x0, #0x13]
    // 0x6138c0: StoreField: r0->field_17 = rZR
    //     0x6138c0: stur            wzr, [x0, #0x17]
    // 0x6138c4: ldr             x1, [fp, #0x18]
    // 0x6138c8: StoreField: r1->field_13 = r0
    //     0x6138c8: stur            w0, [x1, #0x13]
    //     0x6138cc: ldurb           w16, [x1, #-1]
    //     0x6138d0: ldurb           w17, [x0, #-1]
    //     0x6138d4: and             x16, x17, x16, lsr #2
    //     0x6138d8: tst             x16, HEAP, lsr #32
    //     0x6138dc: b.eq            #0x6138e4
    //     0x6138e0: bl              #0xd6826c
    // 0x6138e4: b               #0x6138ec
    // 0x6138e8: mov             x1, x0
    // 0x6138ec: ldr             x0, [fp, #0x10]
    // 0x6138f0: r0 = _WidgetTicker()
    //     0x6138f0: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x6138f4: mov             x1, x0
    // 0x6138f8: ldr             x0, [fp, #0x18]
    // 0x6138fc: stur            x1, [fp, #-8]
    // 0x613900: StoreField: r1->field_1b = r0
    //     0x613900: stur            w0, [x1, #0x1b]
    // 0x613904: r2 = false
    //     0x613904: add             x2, NULL, #0x30  ; false
    // 0x613908: StoreField: r1->field_b = r2
    //     0x613908: stur            w2, [x1, #0xb]
    // 0x61390c: ldr             x2, [fp, #0x10]
    // 0x613910: StoreField: r1->field_13 = r2
    //     0x613910: stur            w2, [x1, #0x13]
    // 0x613914: LoadField: r2 = r0->field_17
    //     0x613914: ldur            w2, [x0, #0x17]
    // 0x613918: DecompressPointer r2
    //     0x613918: add             x2, x2, HEAP, lsl #32
    // 0x61391c: cmp             w2, NULL
    // 0x613920: b.eq            #0x613978
    // 0x613924: LoadField: r3 = r2->field_27
    //     0x613924: ldur            w3, [x2, #0x27]
    // 0x613928: DecompressPointer r3
    //     0x613928: add             x3, x3, HEAP, lsl #32
    // 0x61392c: eor             x2, x3, #0x10
    // 0x613930: stp             x2, x1, [SP, #-0x10]!
    // 0x613934: r0 = muted=()
    //     0x613934: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x613938: add             SP, SP, #0x10
    // 0x61393c: ldr             x0, [fp, #0x18]
    // 0x613940: LoadField: r1 = r0->field_13
    //     0x613940: ldur            w1, [x0, #0x13]
    // 0x613944: DecompressPointer r1
    //     0x613944: add             x1, x1, HEAP, lsl #32
    // 0x613948: cmp             w1, NULL
    // 0x61394c: b.eq            #0x61397c
    // 0x613950: ldur            x16, [fp, #-8]
    // 0x613954: stp             x16, x1, [SP, #-0x10]!
    // 0x613958: r0 = add()
    //     0x613958: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x61395c: add             SP, SP, #0x10
    // 0x613960: ldur            x0, [fp, #-8]
    // 0x613964: LeaveFrame
    //     0x613964: mov             SP, fp
    //     0x613968: ldp             fp, lr, [SP], #0x10
    // 0x61396c: ret
    //     0x61396c: ret             
    // 0x613970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613970: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613974: b               #0x613820
    // 0x613978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x613978: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61397c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61397c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x6139a4, size: 0x11c
    // 0x6139a4: EnterFrame
    //     0x6139a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6139a8: mov             fp, SP
    // 0x6139ac: AllocStack(0x10)
    //     0x6139ac: sub             SP, SP, #0x10
    // 0x6139b0: CheckStackOverflow
    //     0x6139b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6139b4: cmp             SP, x16
    //     0x6139b8: b.ls            #0x613ab4
    // 0x6139bc: ldr             x0, [fp, #0x10]
    // 0x6139c0: LoadField: r1 = r0->field_f
    //     0x6139c0: ldur            w1, [x0, #0xf]
    // 0x6139c4: DecompressPointer r1
    //     0x6139c4: add             x1, x1, HEAP, lsl #32
    // 0x6139c8: cmp             w1, NULL
    // 0x6139cc: b.eq            #0x613abc
    // 0x6139d0: SaveReg r1
    //     0x6139d0: str             x1, [SP, #-8]!
    // 0x6139d4: r0 = getNotifier()
    //     0x6139d4: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x6139d8: add             SP, SP, #8
    // 0x6139dc: mov             x1, x0
    // 0x6139e0: ldr             x0, [fp, #0x10]
    // 0x6139e4: stur            x1, [fp, #-0x10]
    // 0x6139e8: LoadField: r2 = r0->field_17
    //     0x6139e8: ldur            w2, [x0, #0x17]
    // 0x6139ec: DecompressPointer r2
    //     0x6139ec: add             x2, x2, HEAP, lsl #32
    // 0x6139f0: stur            x2, [fp, #-8]
    // 0x6139f4: cmp             w1, w2
    // 0x6139f8: b.ne            #0x613a0c
    // 0x6139fc: r0 = Null
    //     0x6139fc: mov             x0, NULL
    // 0x613a00: LeaveFrame
    //     0x613a00: mov             SP, fp
    //     0x613a04: ldp             fp, lr, [SP], #0x10
    // 0x613a08: ret
    //     0x613a08: ret             
    // 0x613a0c: cmp             w2, NULL
    // 0x613a10: b.eq            #0x613a4c
    // 0x613a14: r1 = 1
    //     0x613a14: mov             x1, #1
    // 0x613a18: r0 = AllocateContext()
    //     0x613a18: bl              #0xd68aa4  ; AllocateContextStub
    // 0x613a1c: mov             x1, x0
    // 0x613a20: ldr             x0, [fp, #0x10]
    // 0x613a24: StoreField: r1->field_f = r0
    //     0x613a24: stur            w0, [x1, #0xf]
    // 0x613a28: mov             x2, x1
    // 0x613a2c: r1 = Function '_updateTickers@156311458':.
    //     0x613a2c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c6f0] AnonymousClosure: (0x613ac0), in [package:extended_image/src/gesture/gesture.dart] _ExtendedImageGestureState&State&TickerProviderStateMixin::_updateTickers (0x613b08)
    //     0x613a30: ldr             x1, [x1, #0x6f0]
    // 0x613a34: r0 = AllocateClosure()
    //     0x613a34: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x613a38: ldur            x16, [fp, #-8]
    // 0x613a3c: stp             x0, x16, [SP, #-0x10]!
    // 0x613a40: r0 = removeListener()
    //     0x613a40: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x613a44: add             SP, SP, #0x10
    // 0x613a48: ldr             x0, [fp, #0x10]
    // 0x613a4c: r1 = 1
    //     0x613a4c: mov             x1, #1
    // 0x613a50: r0 = AllocateContext()
    //     0x613a50: bl              #0xd68aa4  ; AllocateContextStub
    // 0x613a54: mov             x1, x0
    // 0x613a58: ldr             x0, [fp, #0x10]
    // 0x613a5c: StoreField: r1->field_f = r0
    //     0x613a5c: stur            w0, [x1, #0xf]
    // 0x613a60: mov             x2, x1
    // 0x613a64: r1 = Function '_updateTickers@156311458':.
    //     0x613a64: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c6f0] AnonymousClosure: (0x613ac0), in [package:extended_image/src/gesture/gesture.dart] _ExtendedImageGestureState&State&TickerProviderStateMixin::_updateTickers (0x613b08)
    //     0x613a68: ldr             x1, [x1, #0x6f0]
    // 0x613a6c: r0 = AllocateClosure()
    //     0x613a6c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x613a70: ldur            x16, [fp, #-0x10]
    // 0x613a74: stp             x0, x16, [SP, #-0x10]!
    // 0x613a78: r0 = addListener()
    //     0x613a78: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x613a7c: add             SP, SP, #0x10
    // 0x613a80: ldur            x0, [fp, #-0x10]
    // 0x613a84: ldr             x1, [fp, #0x10]
    // 0x613a88: StoreField: r1->field_17 = r0
    //     0x613a88: stur            w0, [x1, #0x17]
    //     0x613a8c: ldurb           w16, [x1, #-1]
    //     0x613a90: ldurb           w17, [x0, #-1]
    //     0x613a94: and             x16, x17, x16, lsr #2
    //     0x613a98: tst             x16, HEAP, lsr #32
    //     0x613a9c: b.eq            #0x613aa4
    //     0x613aa0: bl              #0xd6826c
    // 0x613aa4: r0 = Null
    //     0x613aa4: mov             x0, NULL
    // 0x613aa8: LeaveFrame
    //     0x613aa8: mov             SP, fp
    //     0x613aac: ldp             fp, lr, [SP], #0x10
    // 0x613ab0: ret
    //     0x613ab0: ret             
    // 0x613ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613ab4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613ab8: b               #0x6139bc
    // 0x613abc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x613abc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x613ac0, size: 0x48
    // 0x613ac0: EnterFrame
    //     0x613ac0: stp             fp, lr, [SP, #-0x10]!
    //     0x613ac4: mov             fp, SP
    // 0x613ac8: ldr             x0, [fp, #0x10]
    // 0x613acc: LoadField: r1 = r0->field_17
    //     0x613acc: ldur            w1, [x0, #0x17]
    // 0x613ad0: DecompressPointer r1
    //     0x613ad0: add             x1, x1, HEAP, lsl #32
    // 0x613ad4: CheckStackOverflow
    //     0x613ad4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613ad8: cmp             SP, x16
    //     0x613adc: b.ls            #0x613b00
    // 0x613ae0: LoadField: r0 = r1->field_f
    //     0x613ae0: ldur            w0, [x1, #0xf]
    // 0x613ae4: DecompressPointer r0
    //     0x613ae4: add             x0, x0, HEAP, lsl #32
    // 0x613ae8: SaveReg r0
    //     0x613ae8: str             x0, [SP, #-8]!
    // 0x613aec: r0 = _updateTickers()
    //     0x613aec: bl              #0x613b08  ; [package:extended_image/src/gesture/gesture.dart] _ExtendedImageGestureState&State&TickerProviderStateMixin::_updateTickers
    // 0x613af0: add             SP, SP, #8
    // 0x613af4: LeaveFrame
    //     0x613af4: mov             SP, fp
    //     0x613af8: ldp             fp, lr, [SP], #0x10
    // 0x613afc: ret
    //     0x613afc: ret             
    // 0x613b00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613b00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613b04: b               #0x613ae0
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x613b08, size: 0x150
    // 0x613b08: EnterFrame
    //     0x613b08: stp             fp, lr, [SP, #-0x10]!
    //     0x613b0c: mov             fp, SP
    // 0x613b10: AllocStack(0x20)
    //     0x613b10: sub             SP, SP, #0x20
    // 0x613b14: CheckStackOverflow
    //     0x613b14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613b18: cmp             SP, x16
    //     0x613b1c: b.ls            #0x613c44
    // 0x613b20: ldr             x0, [fp, #0x10]
    // 0x613b24: LoadField: r1 = r0->field_13
    //     0x613b24: ldur            w1, [x0, #0x13]
    // 0x613b28: DecompressPointer r1
    //     0x613b28: add             x1, x1, HEAP, lsl #32
    // 0x613b2c: cmp             w1, NULL
    // 0x613b30: b.eq            #0x613c34
    // 0x613b34: LoadField: r2 = r0->field_17
    //     0x613b34: ldur            w2, [x0, #0x17]
    // 0x613b38: DecompressPointer r2
    //     0x613b38: add             x2, x2, HEAP, lsl #32
    // 0x613b3c: cmp             w2, NULL
    // 0x613b40: b.eq            #0x613c4c
    // 0x613b44: LoadField: r0 = r2->field_27
    //     0x613b44: ldur            w0, [x2, #0x27]
    // 0x613b48: DecompressPointer r0
    //     0x613b48: add             x0, x0, HEAP, lsl #32
    // 0x613b4c: eor             x2, x0, #0x10
    // 0x613b50: stur            x2, [fp, #-8]
    // 0x613b54: SaveReg r1
    //     0x613b54: str             x1, [SP, #-8]!
    // 0x613b58: r0 = iterator()
    //     0x613b58: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x613b5c: add             SP, SP, #8
    // 0x613b60: stur            x0, [fp, #-0x18]
    // 0x613b64: LoadField: r2 = r0->field_7
    //     0x613b64: ldur            w2, [x0, #7]
    // 0x613b68: DecompressPointer r2
    //     0x613b68: add             x2, x2, HEAP, lsl #32
    // 0x613b6c: stur            x2, [fp, #-0x10]
    // 0x613b70: ldur            x1, [fp, #-8]
    // 0x613b74: CheckStackOverflow
    //     0x613b74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613b78: cmp             SP, x16
    //     0x613b7c: b.ls            #0x613c50
    // 0x613b80: SaveReg r0
    //     0x613b80: str             x0, [SP, #-8]!
    // 0x613b84: r0 = moveNext()
    //     0x613b84: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x613b88: add             SP, SP, #8
    // 0x613b8c: tbnz            w0, #4, #0x613c34
    // 0x613b90: ldur            x3, [fp, #-0x18]
    // 0x613b94: LoadField: r4 = r3->field_33
    //     0x613b94: ldur            w4, [x3, #0x33]
    // 0x613b98: DecompressPointer r4
    //     0x613b98: add             x4, x4, HEAP, lsl #32
    // 0x613b9c: stur            x4, [fp, #-0x20]
    // 0x613ba0: cmp             w4, NULL
    // 0x613ba4: b.ne            #0x613bd8
    // 0x613ba8: mov             x0, x4
    // 0x613bac: ldur            x2, [fp, #-0x10]
    // 0x613bb0: r1 = Null
    //     0x613bb0: mov             x1, NULL
    // 0x613bb4: cmp             w2, NULL
    // 0x613bb8: b.eq            #0x613bd8
    // 0x613bbc: LoadField: r4 = r2->field_17
    //     0x613bbc: ldur            w4, [x2, #0x17]
    // 0x613bc0: DecompressPointer r4
    //     0x613bc0: add             x4, x4, HEAP, lsl #32
    // 0x613bc4: r8 = X0
    //     0x613bc4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x613bc8: LoadField: r9 = r4->field_7
    //     0x613bc8: ldur            x9, [x4, #7]
    // 0x613bcc: r3 = Null
    //     0x613bcc: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c6e0] Null
    //     0x613bd0: ldr             x3, [x3, #0x6e0]
    // 0x613bd4: blr             x9
    // 0x613bd8: ldur            x1, [fp, #-8]
    // 0x613bdc: ldur            x0, [fp, #-0x20]
    // 0x613be0: LoadField: r2 = r0->field_b
    //     0x613be0: ldur            w2, [x0, #0xb]
    // 0x613be4: DecompressPointer r2
    //     0x613be4: add             x2, x2, HEAP, lsl #32
    // 0x613be8: cmp             w1, w2
    // 0x613bec: b.eq            #0x613c28
    // 0x613bf0: StoreField: r0->field_b = r1
    //     0x613bf0: stur            w1, [x0, #0xb]
    // 0x613bf4: tbnz            w1, #4, #0x613c08
    // 0x613bf8: SaveReg r0
    //     0x613bf8: str             x0, [SP, #-8]!
    // 0x613bfc: r0 = unscheduleTick()
    //     0x613bfc: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x613c00: add             SP, SP, #8
    // 0x613c04: b               #0x613c28
    // 0x613c08: SaveReg r0
    //     0x613c08: str             x0, [SP, #-8]!
    // 0x613c0c: r0 = shouldScheduleTick()
    //     0x613c0c: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x613c10: add             SP, SP, #8
    // 0x613c14: tbnz            w0, #4, #0x613c28
    // 0x613c18: ldur            x16, [fp, #-0x20]
    // 0x613c1c: SaveReg r16
    //     0x613c1c: str             x16, [SP, #-8]!
    // 0x613c20: r0 = scheduleTick()
    //     0x613c20: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x613c24: add             SP, SP, #8
    // 0x613c28: ldur            x0, [fp, #-0x18]
    // 0x613c2c: ldur            x2, [fp, #-0x10]
    // 0x613c30: b               #0x613b70
    // 0x613c34: r0 = Null
    //     0x613c34: mov             x0, NULL
    // 0x613c38: LeaveFrame
    //     0x613c38: mov             SP, fp
    //     0x613c3c: ldp             fp, lr, [SP], #0x10
    // 0x613c40: ret
    //     0x613c40: ret             
    // 0x613c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613c44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613c48: b               #0x613b20
    // 0x613c4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x613c4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x613c50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613c50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613c54: b               #0x613b80
  }
  _ activate(/* No info */) {
    // ** addr: 0x81ef04, size: 0x4c
    // 0x81ef04: EnterFrame
    //     0x81ef04: stp             fp, lr, [SP, #-0x10]!
    //     0x81ef08: mov             fp, SP
    // 0x81ef0c: CheckStackOverflow
    //     0x81ef0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81ef10: cmp             SP, x16
    //     0x81ef14: b.ls            #0x81ef48
    // 0x81ef18: ldr             x16, [fp, #0x10]
    // 0x81ef1c: SaveReg r16
    //     0x81ef1c: str             x16, [SP, #-8]!
    // 0x81ef20: r0 = _updateTickerModeNotifier()
    //     0x81ef20: bl              #0x6139a4  ; [package:extended_image/src/gesture/gesture.dart] _ExtendedImageGestureState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81ef24: add             SP, SP, #8
    // 0x81ef28: ldr             x16, [fp, #0x10]
    // 0x81ef2c: SaveReg r16
    //     0x81ef2c: str             x16, [SP, #-8]!
    // 0x81ef30: r0 = _updateTickers()
    //     0x81ef30: bl              #0x613b08  ; [package:extended_image/src/gesture/gesture.dart] _ExtendedImageGestureState&State&TickerProviderStateMixin::_updateTickers
    // 0x81ef34: add             SP, SP, #8
    // 0x81ef38: r0 = Null
    //     0x81ef38: mov             x0, NULL
    // 0x81ef3c: LeaveFrame
    //     0x81ef3c: mov             SP, fp
    //     0x81ef40: ldp             fp, lr, [SP], #0x10
    // 0x81ef44: ret
    //     0x81ef44: ret             
    // 0x81ef48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81ef48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81ef4c: b               #0x81ef18
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4ef2c, size: 0x8c
    // 0xa4ef2c: EnterFrame
    //     0xa4ef2c: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ef30: mov             fp, SP
    // 0xa4ef34: AllocStack(0x8)
    //     0xa4ef34: sub             SP, SP, #8
    // 0xa4ef38: CheckStackOverflow
    //     0xa4ef38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4ef3c: cmp             SP, x16
    //     0xa4ef40: b.ls            #0xa4efb0
    // 0xa4ef44: ldr             x0, [fp, #0x10]
    // 0xa4ef48: LoadField: r1 = r0->field_17
    //     0xa4ef48: ldur            w1, [x0, #0x17]
    // 0xa4ef4c: DecompressPointer r1
    //     0xa4ef4c: add             x1, x1, HEAP, lsl #32
    // 0xa4ef50: stur            x1, [fp, #-8]
    // 0xa4ef54: cmp             w1, NULL
    // 0xa4ef58: b.ne            #0xa4ef64
    // 0xa4ef5c: mov             x1, x0
    // 0xa4ef60: b               #0xa4ef9c
    // 0xa4ef64: r1 = 1
    //     0xa4ef64: mov             x1, #1
    // 0xa4ef68: r0 = AllocateContext()
    //     0xa4ef68: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4ef6c: mov             x1, x0
    // 0xa4ef70: ldr             x0, [fp, #0x10]
    // 0xa4ef74: StoreField: r1->field_f = r0
    //     0xa4ef74: stur            w0, [x1, #0xf]
    // 0xa4ef78: mov             x2, x1
    // 0xa4ef7c: r1 = Function '_updateTickers@156311458':.
    //     0xa4ef7c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c6f0] AnonymousClosure: (0x613ac0), in [package:extended_image/src/gesture/gesture.dart] _ExtendedImageGestureState&State&TickerProviderStateMixin::_updateTickers (0x613b08)
    //     0xa4ef80: ldr             x1, [x1, #0x6f0]
    // 0xa4ef84: r0 = AllocateClosure()
    //     0xa4ef84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4ef88: ldur            x16, [fp, #-8]
    // 0xa4ef8c: stp             x0, x16, [SP, #-0x10]!
    // 0xa4ef90: r0 = removeListener()
    //     0xa4ef90: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4ef94: add             SP, SP, #0x10
    // 0xa4ef98: ldr             x1, [fp, #0x10]
    // 0xa4ef9c: StoreField: r1->field_17 = rNULL
    //     0xa4ef9c: stur            NULL, [x1, #0x17]
    // 0xa4efa0: r0 = Null
    //     0xa4efa0: mov             x0, NULL
    // 0xa4efa4: LeaveFrame
    //     0xa4efa4: mov             SP, fp
    //     0xa4efa8: ldp             fp, lr, [SP], #0x10
    // 0xa4efac: ret
    //     0xa4efac: ret             
    // 0xa4efb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4efb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4efb4: b               #0xa4ef44
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4efb8, size: 0x48
    // 0xa4efb8: EnterFrame
    //     0xa4efb8: stp             fp, lr, [SP, #-0x10]!
    //     0xa4efbc: mov             fp, SP
    // 0xa4efc0: ldr             x0, [fp, #0x10]
    // 0xa4efc4: LoadField: r1 = r0->field_17
    //     0xa4efc4: ldur            w1, [x0, #0x17]
    // 0xa4efc8: DecompressPointer r1
    //     0xa4efc8: add             x1, x1, HEAP, lsl #32
    // 0xa4efcc: CheckStackOverflow
    //     0xa4efcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4efd0: cmp             SP, x16
    //     0xa4efd4: b.ls            #0xa4eff8
    // 0xa4efd8: LoadField: r0 = r1->field_f
    //     0xa4efd8: ldur            w0, [x1, #0xf]
    // 0xa4efdc: DecompressPointer r0
    //     0xa4efdc: add             x0, x0, HEAP, lsl #32
    // 0xa4efe0: SaveReg r0
    //     0xa4efe0: str             x0, [SP, #-8]!
    // 0xa4efe4: r0 = dispose()
    //     0xa4efe4: bl              #0xa4ef2c  ; [package:extended_image/src/gesture/gesture.dart] _ExtendedImageGestureState&State&TickerProviderStateMixin::dispose
    // 0xa4efe8: add             SP, SP, #8
    // 0xa4efec: LeaveFrame
    //     0xa4efec: mov             SP, fp
    //     0xa4eff0: ldp             fp, lr, [SP], #0x10
    // 0xa4eff4: ret
    //     0xa4eff4: ret             
    // 0xa4eff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4eff8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4effc: b               #0xa4efd8
  }
}

// class id: 3397, size: 0x3c, field offset: 0x1c
class ExtendedImageGestureState extends _ExtendedImageGestureState&State&TickerProviderStateMixin {

  late GestureAnimation _gestureAnimation; // offset: 0x30
  late Offset _startingOffset; // offset: 0x28
  late Offset _normalizedOffset; // offset: 0x20

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x79b4c8, size: 0x140
    // 0x79b4c8: EnterFrame
    //     0x79b4c8: stp             fp, lr, [SP, #-0x10]!
    //     0x79b4cc: mov             fp, SP
    // 0x79b4d0: CheckStackOverflow
    //     0x79b4d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79b4d4: cmp             SP, x16
    //     0x79b4d8: b.ls            #0x79b5f8
    // 0x79b4dc: ldr             x0, [fp, #0x10]
    // 0x79b4e0: r2 = Null
    //     0x79b4e0: mov             x2, NULL
    // 0x79b4e4: r1 = Null
    //     0x79b4e4: mov             x1, NULL
    // 0x79b4e8: r4 = 59
    //     0x79b4e8: mov             x4, #0x3b
    // 0x79b4ec: branchIfSmi(r0, 0x79b4f8)
    //     0x79b4ec: tbz             w0, #0, #0x79b4f8
    // 0x79b4f0: r4 = LoadClassIdInstr(r0)
    //     0x79b4f0: ldur            x4, [x0, #-1]
    //     0x79b4f4: ubfx            x4, x4, #0xc, #0x14
    // 0x79b4f8: r17 = 4213
    //     0x79b4f8: mov             x17, #0x1075
    // 0x79b4fc: cmp             x4, x17
    // 0x79b500: b.eq            #0x79b518
    // 0x79b504: r8 = ExtendedImageGesture
    //     0x79b504: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4c610] Type: ExtendedImageGesture
    //     0x79b508: ldr             x8, [x8, #0x610]
    // 0x79b50c: r3 = Null
    //     0x79b50c: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c618] Null
    //     0x79b510: ldr             x3, [x3, #0x618]
    // 0x79b514: r0 = ExtendedImageGesture()
    //     0x79b514: bl              #0x613980  ; IsType_ExtendedImageGesture_Stub
    // 0x79b518: ldr             x3, [fp, #0x18]
    // 0x79b51c: LoadField: r2 = r3->field_7
    //     0x79b51c: ldur            w2, [x3, #7]
    // 0x79b520: DecompressPointer r2
    //     0x79b520: add             x2, x2, HEAP, lsl #32
    // 0x79b524: ldr             x0, [fp, #0x10]
    // 0x79b528: r1 = Null
    //     0x79b528: mov             x1, NULL
    // 0x79b52c: cmp             w2, NULL
    // 0x79b530: b.eq            #0x79b554
    // 0x79b534: LoadField: r4 = r2->field_17
    //     0x79b534: ldur            w4, [x2, #0x17]
    // 0x79b538: DecompressPointer r4
    //     0x79b538: add             x4, x4, HEAP, lsl #32
    // 0x79b53c: r8 = X0 bound StatefulWidget
    //     0x79b53c: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x79b540: ldr             x8, [x8, #0x858]
    // 0x79b544: LoadField: r9 = r4->field_7
    //     0x79b544: ldur            x9, [x4, #7]
    // 0x79b548: r3 = Null
    //     0x79b548: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c628] Null
    //     0x79b54c: ldr             x3, [x3, #0x628]
    // 0x79b550: blr             x9
    // 0x79b554: ldr             x16, [fp, #0x18]
    // 0x79b558: SaveReg r16
    //     0x79b558: str             x16, [SP, #-8]!
    // 0x79b55c: r0 = _initGestureConfig()
    //     0x79b55c: bl              #0x79b670  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::_initGestureConfig
    // 0x79b560: add             SP, SP, #8
    // 0x79b564: ldr             x0, [fp, #0x18]
    // 0x79b568: StoreField: r0->field_37 = rNULL
    //     0x79b568: stur            NULL, [x0, #0x37]
    // 0x79b56c: LoadField: r1 = r0->field_33
    //     0x79b56c: ldur            w1, [x0, #0x33]
    // 0x79b570: DecompressPointer r1
    //     0x79b570: add             x1, x1, HEAP, lsl #32
    // 0x79b574: cmp             w1, NULL
    // 0x79b578: b.eq            #0x79b600
    // 0x79b57c: LoadField: r2 = r1->field_3b
    //     0x79b57c: ldur            w2, [x1, #0x3b]
    // 0x79b580: DecompressPointer r2
    //     0x79b580: add             x2, x2, HEAP, lsl #32
    // 0x79b584: tbnz            w2, #4, #0x79b5e8
    // 0x79b588: LoadField: r1 = r0->field_f
    //     0x79b588: ldur            w1, [x0, #0xf]
    // 0x79b58c: DecompressPointer r1
    //     0x79b58c: add             x1, x1, HEAP, lsl #32
    // 0x79b590: cmp             w1, NULL
    // 0x79b594: b.eq            #0x79b604
    // 0x79b598: r16 = <ExtendedImageGesturePageViewState<ExtendedImageGesturePageView>>
    //     0x79b598: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c638] TypeArguments: <ExtendedImageGesturePageViewState<ExtendedImageGesturePageView>>
    //     0x79b59c: ldr             x16, [x16, #0x638]
    // 0x79b5a0: stp             x1, x16, [SP, #-0x10]!
    // 0x79b5a4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x79b5a4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x79b5a8: r0 = findAncestorStateOfType()
    //     0x79b5a8: bl              #0x594348  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorStateOfType
    // 0x79b5ac: add             SP, SP, #0x10
    // 0x79b5b0: mov             x2, x0
    // 0x79b5b4: ldr             x1, [fp, #0x18]
    // 0x79b5b8: StoreField: r1->field_37 = r0
    //     0x79b5b8: stur            w0, [x1, #0x37]
    //     0x79b5bc: ldurb           w16, [x1, #-1]
    //     0x79b5c0: ldurb           w17, [x0, #-1]
    //     0x79b5c4: and             x16, x17, x16, lsr #2
    //     0x79b5c8: tst             x16, HEAP, lsr #32
    //     0x79b5cc: b.eq            #0x79b5d4
    //     0x79b5d0: bl              #0xd6826c
    // 0x79b5d4: cmp             w2, NULL
    // 0x79b5d8: b.eq            #0x79b5e8
    // 0x79b5dc: stp             x1, x2, [SP, #-0x10]!
    // 0x79b5e0: r0 = extendedImageGestureState=()
    //     0x79b5e0: bl              #0x79b608  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::extendedImageGestureState=
    // 0x79b5e4: add             SP, SP, #0x10
    // 0x79b5e8: r0 = Null
    //     0x79b5e8: mov             x0, NULL
    // 0x79b5ec: LeaveFrame
    //     0x79b5ec: mov             SP, fp
    //     0x79b5f0: ldp             fp, lr, [SP], #0x10
    // 0x79b5f4: ret
    //     0x79b5f4: ret             
    // 0x79b5f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79b5f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79b5fc: b               #0x79b4dc
    // 0x79b600: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b600: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79b604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b604: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initGestureConfig(/* No info */) {
    // ** addr: 0x79b670, size: 0x360
    // 0x79b670: EnterFrame
    //     0x79b670: stp             fp, lr, [SP, #-0x10]!
    //     0x79b674: mov             fp, SP
    // 0x79b678: AllocStack(0x18)
    //     0x79b678: sub             SP, SP, #0x18
    // 0x79b67c: CheckStackOverflow
    //     0x79b67c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79b680: cmp             SP, x16
    //     0x79b684: b.ls            #0x79b9b4
    // 0x79b688: r1 = 1
    //     0x79b688: mov             x1, #1
    // 0x79b68c: r0 = AllocateContext()
    //     0x79b68c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79b690: mov             x2, x0
    // 0x79b694: ldr             x1, [fp, #0x10]
    // 0x79b698: stur            x2, [fp, #-0x18]
    // 0x79b69c: StoreField: r2->field_f = r1
    //     0x79b69c: stur            w1, [x2, #0xf]
    // 0x79b6a0: LoadField: r0 = r1->field_33
    //     0x79b6a0: ldur            w0, [x1, #0x33]
    // 0x79b6a4: DecompressPointer r0
    //     0x79b6a4: add             x0, x0, HEAP, lsl #32
    // 0x79b6a8: cmp             w0, NULL
    // 0x79b6ac: b.ne            #0x79b6b8
    // 0x79b6b0: r3 = Null
    //     0x79b6b0: mov             x3, NULL
    // 0x79b6b4: b               #0x79b6bc
    // 0x79b6b8: r3 = 1.000000
    //     0x79b6b8: ldr             x3, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x79b6bc: stur            x3, [fp, #-0x10]
    // 0x79b6c0: cmp             w0, NULL
    // 0x79b6c4: b.ne            #0x79b6d0
    // 0x79b6c8: r4 = Null
    //     0x79b6c8: mov             x4, NULL
    // 0x79b6cc: b               #0x79b6d8
    // 0x79b6d0: r4 = Instance_InitialAlignment
    //     0x79b6d0: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3e3c8] Obj!InitialAlignment@b66171
    //     0x79b6d4: ldr             x4, [x4, #0x3c8]
    // 0x79b6d8: stur            x4, [fp, #-8]
    // 0x79b6dc: LoadField: r0 = r1->field_b
    //     0x79b6dc: ldur            w0, [x1, #0xb]
    // 0x79b6e0: DecompressPointer r0
    //     0x79b6e0: add             x0, x0, HEAP, lsl #32
    // 0x79b6e4: cmp             w0, NULL
    // 0x79b6e8: b.eq            #0x79b9bc
    // 0x79b6ec: LoadField: r5 = r0->field_b
    //     0x79b6ec: ldur            w5, [x0, #0xb]
    // 0x79b6f0: DecompressPointer r5
    //     0x79b6f0: add             x5, x5, HEAP, lsl #32
    // 0x79b6f4: LoadField: r0 = r5->field_b
    //     0x79b6f4: ldur            w0, [x5, #0xb]
    // 0x79b6f8: DecompressPointer r0
    //     0x79b6f8: add             x0, x0, HEAP, lsl #32
    // 0x79b6fc: cmp             w0, NULL
    // 0x79b700: b.eq            #0x79b9c0
    // 0x79b704: LoadField: r6 = r0->field_27
    //     0x79b704: ldur            w6, [x0, #0x27]
    // 0x79b708: DecompressPointer r6
    //     0x79b708: add             x6, x6, HEAP, lsl #32
    // 0x79b70c: cmp             w6, NULL
    // 0x79b710: b.ne            #0x79b71c
    // 0x79b714: r0 = Null
    //     0x79b714: mov             x0, NULL
    // 0x79b718: b               #0x79b734
    // 0x79b71c: stp             x5, x6, [SP, #-0x10]!
    // 0x79b720: mov             x0, x6
    // 0x79b724: ClosureCall
    //     0x79b724: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x79b728: ldur            x2, [x0, #0x1f]
    //     0x79b72c: blr             x2
    // 0x79b730: add             SP, SP, #0x10
    // 0x79b734: cmp             w0, NULL
    // 0x79b738: b.ne            #0x79b7ac
    // 0x79b73c: r0 = GestureConfig()
    //     0x79b73c: bl              #0x79c008  ; AllocateGestureConfigStub -> GestureConfig (size=0x58)
    // 0x79b740: d0 = 0.800000
    //     0x79b740: add             x17, PP, #0x2b, lsl #12  ; [pp+0x2bf68] IMM: double(0.8) from 0x3fe999999999999a
    //     0x79b744: ldr             d0, [x17, #0xf68]
    // 0x79b748: StoreField: r0->field_17 = d0
    //     0x79b748: stur            d0, [x0, #0x17]
    // 0x79b74c: d0 = 5.000000
    //     0x79b74c: fmov            d0, #5.00000000
    // 0x79b750: StoreField: r0->field_27 = d0
    //     0x79b750: stur            d0, [x0, #0x27]
    // 0x79b754: d0 = 1.000000
    //     0x79b754: fmov            d0, #1.00000000
    // 0x79b758: StoreField: r0->field_2f = d0
    //     0x79b758: stur            d0, [x0, #0x2f]
    // 0x79b75c: r1 = false
    //     0x79b75c: add             x1, NULL, #0x30  ; false
    // 0x79b760: StoreField: r0->field_37 = r1
    //     0x79b760: stur            w1, [x0, #0x37]
    // 0x79b764: d1 = 100.000000
    //     0x79b764: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0x79b768: ldr             d1, [x17, #0x308]
    // 0x79b76c: StoreField: r0->field_3f = d1
    //     0x79b76c: stur            d1, [x0, #0x3f]
    // 0x79b770: StoreField: r0->field_47 = d0
    //     0x79b770: stur            d0, [x0, #0x47]
    // 0x79b774: StoreField: r0->field_3b = r1
    //     0x79b774: stur            w1, [x0, #0x3b]
    // 0x79b778: r2 = Instance_InitialAlignment
    //     0x79b778: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e3c8] Obj!InitialAlignment@b66171
    //     0x79b77c: ldr             x2, [x2, #0x3c8]
    // 0x79b780: StoreField: r0->field_4f = r2
    //     0x79b780: stur            w2, [x0, #0x4f]
    // 0x79b784: r3 = Instance_HitTestBehavior
    //     0x79b784: add             x3, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!HitTestBehavior@b64931
    //     0x79b788: ldr             x3, [x3, #0x780]
    // 0x79b78c: StoreField: r0->field_7 = r3
    //     0x79b78c: stur            w3, [x0, #7]
    // 0x79b790: StoreField: r0->field_53 = r1
    //     0x79b790: stur            w1, [x0, #0x53]
    // 0x79b794: d1 = 0.640000
    //     0x79b794: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c580] IMM: double(0.6400000000000001) from 0x3fe47ae147ae147c
    //     0x79b798: ldr             d1, [x17, #0x580]
    // 0x79b79c: StoreField: r0->field_f = d1
    //     0x79b79c: stur            d1, [x0, #0xf]
    // 0x79b7a0: d1 = 6.000000
    //     0x79b7a0: fmov            d1, #6.00000000
    // 0x79b7a4: StoreField: r0->field_1f = d1
    //     0x79b7a4: stur            d1, [x0, #0x1f]
    // 0x79b7a8: b               #0x79b7b8
    // 0x79b7ac: r2 = Instance_InitialAlignment
    //     0x79b7ac: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e3c8] Obj!InitialAlignment@b66171
    //     0x79b7b0: ldr             x2, [x2, #0x3c8]
    // 0x79b7b4: d0 = 1.000000
    //     0x79b7b4: fmov            d0, #1.00000000
    // 0x79b7b8: ldr             x1, [fp, #0x10]
    // 0x79b7bc: StoreField: r1->field_33 = r0
    //     0x79b7bc: stur            w0, [x1, #0x33]
    //     0x79b7c0: tbz             w0, #0, #0x79b7dc
    //     0x79b7c4: ldurb           w16, [x1, #-1]
    //     0x79b7c8: ldurb           w17, [x0, #-1]
    //     0x79b7cc: and             x16, x17, x16, lsr #2
    //     0x79b7d0: tst             x16, HEAP, lsr #32
    //     0x79b7d4: b.eq            #0x79b7dc
    //     0x79b7d8: bl              #0xd6826c
    // 0x79b7dc: LoadField: r0 = r1->field_1b
    //     0x79b7dc: ldur            w0, [x1, #0x1b]
    // 0x79b7e0: DecompressPointer r0
    //     0x79b7e0: add             x0, x0, HEAP, lsl #32
    // 0x79b7e4: cmp             w0, NULL
    // 0x79b7e8: b.ne            #0x79b7f4
    // 0x79b7ec: mov             x0, x1
    // 0x79b7f0: b               #0x79b850
    // 0x79b7f4: ldur            x0, [fp, #-0x10]
    // 0x79b7f8: r3 = LoadClassIdInstr(r0)
    //     0x79b7f8: ldur            x3, [x0, #-1]
    //     0x79b7fc: ubfx            x3, x3, #0xc, #0x14
    // 0x79b800: r16 = 1.000000
    //     0x79b800: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x79b804: stp             x16, x0, [SP, #-0x10]!
    // 0x79b808: mov             x0, x3
    // 0x79b80c: mov             lr, x0
    // 0x79b810: ldr             lr, [x21, lr, lsl #3]
    // 0x79b814: blr             lr
    // 0x79b818: add             SP, SP, #0x10
    // 0x79b81c: tbz             w0, #4, #0x79b828
    // 0x79b820: ldr             x0, [fp, #0x10]
    // 0x79b824: b               #0x79b850
    // 0x79b828: ldr             x0, [fp, #0x10]
    // 0x79b82c: ldur            x1, [fp, #-8]
    // 0x79b830: LoadField: r2 = r0->field_33
    //     0x79b830: ldur            w2, [x0, #0x33]
    // 0x79b834: DecompressPointer r2
    //     0x79b834: add             x2, x2, HEAP, lsl #32
    // 0x79b838: cmp             w2, NULL
    // 0x79b83c: b.eq            #0x79b9c4
    // 0x79b840: r16 = Instance_InitialAlignment
    //     0x79b840: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e3c8] Obj!InitialAlignment@b66171
    //     0x79b844: ldr             x16, [x16, #0x3c8]
    // 0x79b848: cmp             w1, w16
    // 0x79b84c: b.eq            #0x79b8c8
    // 0x79b850: LoadField: r1 = r0->field_33
    //     0x79b850: ldur            w1, [x0, #0x33]
    // 0x79b854: DecompressPointer r1
    //     0x79b854: add             x1, x1, HEAP, lsl #32
    // 0x79b858: cmp             w1, NULL
    // 0x79b85c: b.eq            #0x79b9c8
    // 0x79b860: r0 = GestureDetails()
    //     0x79b860: bl              #0x79bffc  ; AllocateGestureDetailsStub -> GestureDetails (size=0x40)
    // 0x79b864: stur            x0, [fp, #-8]
    // 0x79b868: r16 = Instance_Offset
    //     0x79b868: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x79b86c: stp             x16, x0, [SP, #-0x10]!
    // 0x79b870: d0 = 1.000000
    //     0x79b870: fmov            d0, #1.00000000
    // 0x79b874: SaveReg d0
    //     0x79b874: str             d0, [SP, #-8]!
    // 0x79b878: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x79b878: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x79b87c: r0 = GestureDetails()
    //     0x79b87c: bl              #0x79bd90  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::GestureDetails
    // 0x79b880: add             SP, SP, #0x18
    // 0x79b884: ldr             x1, [fp, #0x10]
    // 0x79b888: LoadField: r0 = r1->field_33
    //     0x79b888: ldur            w0, [x1, #0x33]
    // 0x79b88c: DecompressPointer r0
    //     0x79b88c: add             x0, x0, HEAP, lsl #32
    // 0x79b890: cmp             w0, NULL
    // 0x79b894: b.eq            #0x79b9cc
    // 0x79b898: ldur            x0, [fp, #-8]
    // 0x79b89c: r2 = Instance_InitialAlignment
    //     0x79b89c: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e3c8] Obj!InitialAlignment@b66171
    //     0x79b8a0: ldr             x2, [x2, #0x3c8]
    // 0x79b8a4: StoreField: r0->field_37 = r2
    //     0x79b8a4: stur            w2, [x0, #0x37]
    // 0x79b8a8: StoreField: r1->field_1b = r0
    //     0x79b8a8: stur            w0, [x1, #0x1b]
    //     0x79b8ac: ldurb           w16, [x1, #-1]
    //     0x79b8b0: ldurb           w17, [x0, #-1]
    //     0x79b8b4: and             x16, x17, x16, lsr #2
    //     0x79b8b8: tst             x16, HEAP, lsr #32
    //     0x79b8bc: b.eq            #0x79b8c4
    //     0x79b8c0: bl              #0xd6826c
    // 0x79b8c4: b               #0x79b8cc
    // 0x79b8c8: mov             x1, x0
    // 0x79b8cc: LoadField: r0 = r1->field_1b
    //     0x79b8cc: ldur            w0, [x1, #0x1b]
    // 0x79b8d0: DecompressPointer r0
    //     0x79b8d0: add             x0, x0, HEAP, lsl #32
    // 0x79b8d4: cmp             w0, NULL
    // 0x79b8d8: b.ne            #0x79b928
    // 0x79b8dc: r0 = GestureDetails()
    //     0x79b8dc: bl              #0x79bffc  ; AllocateGestureDetailsStub -> GestureDetails (size=0x40)
    // 0x79b8e0: stur            x0, [fp, #-8]
    // 0x79b8e4: r16 = Instance_Offset
    //     0x79b8e4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x79b8e8: stp             x16, x0, [SP, #-0x10]!
    // 0x79b8ec: d0 = 1.000000
    //     0x79b8ec: fmov            d0, #1.00000000
    // 0x79b8f0: SaveReg d0
    //     0x79b8f0: str             d0, [SP, #-8]!
    // 0x79b8f4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x79b8f4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x79b8f8: r0 = GestureDetails()
    //     0x79b8f8: bl              #0x79bd90  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::GestureDetails
    // 0x79b8fc: add             SP, SP, #0x18
    // 0x79b900: ldur            x0, [fp, #-8]
    // 0x79b904: ldr             x3, [fp, #0x10]
    // 0x79b908: StoreField: r3->field_1b = r0
    //     0x79b908: stur            w0, [x3, #0x1b]
    //     0x79b90c: ldurb           w16, [x3, #-1]
    //     0x79b910: ldurb           w17, [x0, #-1]
    //     0x79b914: and             x16, x17, x16, lsr #2
    //     0x79b918: tst             x16, HEAP, lsr #32
    //     0x79b91c: b.eq            #0x79b924
    //     0x79b920: bl              #0xd682ac
    // 0x79b924: b               #0x79b92c
    // 0x79b928: mov             x3, x1
    // 0x79b92c: ldur            x2, [fp, #-0x18]
    // 0x79b930: r1 = Function '<anonymous closure>':.
    //     0x79b930: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c588] AnonymousClosure: (0x79c1a0), in [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::_initGestureConfig (0x79b670)
    //     0x79b934: ldr             x1, [x1, #0x588]
    // 0x79b938: r0 = AllocateClosure()
    //     0x79b938: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79b93c: ldur            x2, [fp, #-0x18]
    // 0x79b940: r1 = Function '<anonymous closure>':.
    //     0x79b940: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c590] AnonymousClosure: (0x79c014), in [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::_initGestureConfig (0x79b670)
    //     0x79b944: ldr             x1, [x1, #0x590]
    // 0x79b948: stur            x0, [fp, #-8]
    // 0x79b94c: r0 = AllocateClosure()
    //     0x79b94c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79b950: stur            x0, [fp, #-0x10]
    // 0x79b954: r0 = GestureAnimation()
    //     0x79b954: bl              #0x79bd84  ; AllocateGestureAnimationStub -> GestureAnimation (size=0x18)
    // 0x79b958: stur            x0, [fp, #-0x18]
    // 0x79b95c: ldr             x16, [fp, #0x10]
    // 0x79b960: stp             x16, x0, [SP, #-0x10]!
    // 0x79b964: ldur            x16, [fp, #-8]
    // 0x79b968: ldur            lr, [fp, #-0x10]
    // 0x79b96c: stp             lr, x16, [SP, #-0x10]!
    // 0x79b970: r4 = const [0, 0x4, 0x4, 0x3, scaleCallBack, 0x3, null]
    //     0x79b970: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4c598] List(7) [0, 0x4, 0x4, 0x3, "scaleCallBack", 0x3, Null]
    //     0x79b974: ldr             x4, [x4, #0x598]
    // 0x79b978: r0 = GestureAnimation()
    //     0x79b978: bl              #0x79b9d0  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::GestureAnimation
    // 0x79b97c: add             SP, SP, #0x20
    // 0x79b980: ldur            x0, [fp, #-0x18]
    // 0x79b984: ldr             x1, [fp, #0x10]
    // 0x79b988: StoreField: r1->field_2f = r0
    //     0x79b988: stur            w0, [x1, #0x2f]
    //     0x79b98c: ldurb           w16, [x1, #-1]
    //     0x79b990: ldurb           w17, [x0, #-1]
    //     0x79b994: and             x16, x17, x16, lsr #2
    //     0x79b998: tst             x16, HEAP, lsr #32
    //     0x79b99c: b.eq            #0x79b9a4
    //     0x79b9a0: bl              #0xd6826c
    // 0x79b9a4: r0 = Null
    //     0x79b9a4: mov             x0, NULL
    // 0x79b9a8: LeaveFrame
    //     0x79b9a8: mov             SP, fp
    //     0x79b9ac: ldp             fp, lr, [SP], #0x10
    // 0x79b9b0: ret
    //     0x79b9b0: ret             
    // 0x79b9b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79b9b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79b9b8: b               #0x79b688
    // 0x79b9bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b9bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79b9c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b9c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79b9c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b9c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79b9c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b9c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79b9cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b9cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, double) {
    // ** addr: 0x79c014, size: 0xcc
    // 0x79c014: EnterFrame
    //     0x79c014: stp             fp, lr, [SP, #-0x10]!
    //     0x79c018: mov             fp, SP
    // 0x79c01c: AllocStack(0x28)
    //     0x79c01c: sub             SP, SP, #0x28
    // 0x79c020: SetupParameters()
    //     0x79c020: ldr             x0, [fp, #0x18]
    //     0x79c024: ldur            w1, [x0, #0x17]
    //     0x79c028: add             x1, x1, HEAP, lsl #32
    // 0x79c02c: CheckStackOverflow
    //     0x79c02c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79c030: cmp             SP, x16
    //     0x79c034: b.ls            #0x79c0d4
    // 0x79c038: LoadField: r0 = r1->field_f
    //     0x79c038: ldur            w0, [x1, #0xf]
    // 0x79c03c: DecompressPointer r0
    //     0x79c03c: add             x0, x0, HEAP, lsl #32
    // 0x79c040: stur            x0, [fp, #-0x18]
    // 0x79c044: LoadField: r1 = r0->field_1b
    //     0x79c044: ldur            w1, [x0, #0x1b]
    // 0x79c048: DecompressPointer r1
    //     0x79c048: add             x1, x1, HEAP, lsl #32
    // 0x79c04c: stur            x1, [fp, #-0x10]
    // 0x79c050: cmp             w1, NULL
    // 0x79c054: b.eq            #0x79c0dc
    // 0x79c058: LoadField: r2 = r1->field_7
    //     0x79c058: ldur            w2, [x1, #7]
    // 0x79c05c: DecompressPointer r2
    //     0x79c05c: add             x2, x2, HEAP, lsl #32
    // 0x79c060: ldr             x3, [fp, #0x10]
    // 0x79c064: stur            x2, [fp, #-8]
    // 0x79c068: LoadField: d0 = r3->field_7
    //     0x79c068: ldur            d0, [x3, #7]
    // 0x79c06c: stur            d0, [fp, #-0x28]
    // 0x79c070: r0 = GestureDetails()
    //     0x79c070: bl              #0x79bffc  ; AllocateGestureDetailsStub -> GestureDetails (size=0x40)
    // 0x79c074: stur            x0, [fp, #-0x20]
    // 0x79c078: ldur            x16, [fp, #-8]
    // 0x79c07c: stp             x16, x0, [SP, #-0x10]!
    // 0x79c080: ldur            d0, [fp, #-0x28]
    // 0x79c084: SaveReg d0
    //     0x79c084: str             d0, [SP, #-8]!
    // 0x79c088: ldur            x16, [fp, #-0x10]
    // 0x79c08c: r30 = Instance_ActionType
    //     0x79c08c: add             lr, PP, #0x4c, lsl #12  ; [pp+0x4c5a0] Obj!ActionType@b66151
    //     0x79c090: ldr             lr, [lr, #0x5a0]
    // 0x79c094: stp             lr, x16, [SP, #-0x10]!
    // 0x79c098: r16 = false
    //     0x79c098: add             x16, NULL, #0x30  ; false
    // 0x79c09c: SaveReg r16
    //     0x79c09c: str             x16, [SP, #-8]!
    // 0x79c0a0: r4 = const [0, 0x6, 0x6, 0x3, actionType, 0x4, gestureDetails, 0x3, userOffset, 0x5, null]
    //     0x79c0a0: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4c5a8] List(11) [0, 0x6, 0x6, 0x3, "actionType", 0x4, "gestureDetails", 0x3, "userOffset", 0x5, Null]
    //     0x79c0a4: ldr             x4, [x4, #0x5a8]
    // 0x79c0a8: r0 = GestureDetails()
    //     0x79c0a8: bl              #0x79bd90  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::GestureDetails
    // 0x79c0ac: add             SP, SP, #0x30
    // 0x79c0b0: ldur            x16, [fp, #-0x18]
    // 0x79c0b4: ldur            lr, [fp, #-0x20]
    // 0x79c0b8: stp             lr, x16, [SP, #-0x10]!
    // 0x79c0bc: r0 = gestureDetails=()
    //     0x79c0bc: bl              #0x79c0e0  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::gestureDetails=
    // 0x79c0c0: add             SP, SP, #0x10
    // 0x79c0c4: r0 = Null
    //     0x79c0c4: mov             x0, NULL
    // 0x79c0c8: LeaveFrame
    //     0x79c0c8: mov             SP, fp
    //     0x79c0cc: ldp             fp, lr, [SP], #0x10
    // 0x79c0d0: ret
    //     0x79c0d0: ret             
    // 0x79c0d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79c0d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79c0d8: b               #0x79c038
    // 0x79c0dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79c0dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ gestureDetails=(/* No info */) {
    // ** addr: 0x79c0e0, size: 0x78
    // 0x79c0e0: EnterFrame
    //     0x79c0e0: stp             fp, lr, [SP, #-0x10]!
    //     0x79c0e4: mov             fp, SP
    // 0x79c0e8: CheckStackOverflow
    //     0x79c0e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79c0ec: cmp             SP, x16
    //     0x79c0f0: b.ls            #0x79c150
    // 0x79c0f4: r1 = 2
    //     0x79c0f4: mov             x1, #2
    // 0x79c0f8: r0 = AllocateContext()
    //     0x79c0f8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79c0fc: mov             x1, x0
    // 0x79c100: ldr             x0, [fp, #0x18]
    // 0x79c104: StoreField: r1->field_f = r0
    //     0x79c104: stur            w0, [x1, #0xf]
    // 0x79c108: ldr             x2, [fp, #0x10]
    // 0x79c10c: StoreField: r1->field_13 = r2
    //     0x79c10c: stur            w2, [x1, #0x13]
    // 0x79c110: LoadField: r2 = r0->field_f
    //     0x79c110: ldur            w2, [x0, #0xf]
    // 0x79c114: DecompressPointer r2
    //     0x79c114: add             x2, x2, HEAP, lsl #32
    // 0x79c118: cmp             w2, NULL
    // 0x79c11c: b.eq            #0x79c140
    // 0x79c120: mov             x2, x1
    // 0x79c124: r1 = Function '<anonymous closure>':.
    //     0x79c124: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c5b0] AnonymousClosure: (0x79c158), in [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::gestureDetails= (0x79c0e0)
    //     0x79c128: ldr             x1, [x1, #0x5b0]
    // 0x79c12c: r0 = AllocateClosure()
    //     0x79c12c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79c130: ldr             x16, [fp, #0x18]
    // 0x79c134: stp             x0, x16, [SP, #-0x10]!
    // 0x79c138: r0 = setState()
    //     0x79c138: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x79c13c: add             SP, SP, #0x10
    // 0x79c140: r0 = Null
    //     0x79c140: mov             x0, NULL
    // 0x79c144: LeaveFrame
    //     0x79c144: mov             SP, fp
    //     0x79c148: ldp             fp, lr, [SP], #0x10
    // 0x79c14c: ret
    //     0x79c14c: ret             
    // 0x79c150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79c150: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79c154: b               #0x79c0f4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x79c158, size: 0x48
    // 0x79c158: ldr             x1, [SP]
    // 0x79c15c: LoadField: r2 = r1->field_17
    //     0x79c15c: ldur            w2, [x1, #0x17]
    // 0x79c160: DecompressPointer r2
    //     0x79c160: add             x2, x2, HEAP, lsl #32
    // 0x79c164: LoadField: r1 = r2->field_f
    //     0x79c164: ldur            w1, [x2, #0xf]
    // 0x79c168: DecompressPointer r1
    //     0x79c168: add             x1, x1, HEAP, lsl #32
    // 0x79c16c: LoadField: r0 = r2->field_13
    //     0x79c16c: ldur            w0, [x2, #0x13]
    // 0x79c170: DecompressPointer r0
    //     0x79c170: add             x0, x0, HEAP, lsl #32
    // 0x79c174: StoreField: r1->field_1b = r0
    //     0x79c174: stur            w0, [x1, #0x1b]
    //     0x79c178: ldurb           w16, [x1, #-1]
    //     0x79c17c: ldurb           w17, [x0, #-1]
    //     0x79c180: and             x16, x17, x16, lsr #2
    //     0x79c184: tst             x16, HEAP, lsr #32
    //     0x79c188: b.eq            #0x79c198
    //     0x79c18c: str             lr, [SP, #-8]!
    //     0x79c190: bl              #0xd6826c
    //     0x79c194: ldr             lr, [SP], #8
    // 0x79c198: r0 = Null
    //     0x79c198: mov             x0, NULL
    // 0x79c19c: ret
    //     0x79c19c: ret             
  }
  [closure] void <anonymous closure>(dynamic, Offset) {
    // ** addr: 0x79c1a0, size: 0xac
    // 0x79c1a0: EnterFrame
    //     0x79c1a0: stp             fp, lr, [SP, #-0x10]!
    //     0x79c1a4: mov             fp, SP
    // 0x79c1a8: AllocStack(0x20)
    //     0x79c1a8: sub             SP, SP, #0x20
    // 0x79c1ac: SetupParameters()
    //     0x79c1ac: ldr             x0, [fp, #0x18]
    //     0x79c1b0: ldur            w1, [x0, #0x17]
    //     0x79c1b4: add             x1, x1, HEAP, lsl #32
    // 0x79c1b8: CheckStackOverflow
    //     0x79c1b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79c1bc: cmp             SP, x16
    //     0x79c1c0: b.ls            #0x79c240
    // 0x79c1c4: LoadField: r0 = r1->field_f
    //     0x79c1c4: ldur            w0, [x1, #0xf]
    // 0x79c1c8: DecompressPointer r0
    //     0x79c1c8: add             x0, x0, HEAP, lsl #32
    // 0x79c1cc: stur            x0, [fp, #-0x10]
    // 0x79c1d0: LoadField: r1 = r0->field_1b
    //     0x79c1d0: ldur            w1, [x0, #0x1b]
    // 0x79c1d4: DecompressPointer r1
    //     0x79c1d4: add             x1, x1, HEAP, lsl #32
    // 0x79c1d8: stur            x1, [fp, #-8]
    // 0x79c1dc: cmp             w1, NULL
    // 0x79c1e0: b.eq            #0x79c248
    // 0x79c1e4: LoadField: d0 = r1->field_b
    //     0x79c1e4: ldur            d0, [x1, #0xb]
    // 0x79c1e8: stur            d0, [fp, #-0x20]
    // 0x79c1ec: r0 = GestureDetails()
    //     0x79c1ec: bl              #0x79bffc  ; AllocateGestureDetailsStub -> GestureDetails (size=0x40)
    // 0x79c1f0: stur            x0, [fp, #-0x18]
    // 0x79c1f4: ldr             x16, [fp, #0x10]
    // 0x79c1f8: stp             x16, x0, [SP, #-0x10]!
    // 0x79c1fc: ldur            d0, [fp, #-0x20]
    // 0x79c200: SaveReg d0
    //     0x79c200: str             d0, [SP, #-8]!
    // 0x79c204: ldur            x16, [fp, #-8]
    // 0x79c208: SaveReg r16
    //     0x79c208: str             x16, [SP, #-8]!
    // 0x79c20c: r4 = const [0, 0x4, 0x4, 0x3, gestureDetails, 0x3, null]
    //     0x79c20c: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4c5b8] List(7) [0, 0x4, 0x4, 0x3, "gestureDetails", 0x3, Null]
    //     0x79c210: ldr             x4, [x4, #0x5b8]
    // 0x79c214: r0 = GestureDetails()
    //     0x79c214: bl              #0x79bd90  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::GestureDetails
    // 0x79c218: add             SP, SP, #0x20
    // 0x79c21c: ldur            x16, [fp, #-0x10]
    // 0x79c220: ldur            lr, [fp, #-0x18]
    // 0x79c224: stp             lr, x16, [SP, #-0x10]!
    // 0x79c228: r0 = gestureDetails=()
    //     0x79c228: bl              #0x79c0e0  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::gestureDetails=
    // 0x79c22c: add             SP, SP, #0x10
    // 0x79c230: r0 = Null
    //     0x79c230: mov             x0, NULL
    // 0x79c234: LeaveFrame
    //     0x79c234: mov             SP, fp
    //     0x79c238: ldp             fp, lr, [SP], #0x10
    // 0x79c23c: ret
    //     0x79c23c: ret             
    // 0x79c240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79c240: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79c244: b               #0x79c1c4
    // 0x79c248: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79c248: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x82c638, size: 0x344
    // 0x82c638: EnterFrame
    //     0x82c638: stp             fp, lr, [SP, #-0x10]!
    //     0x82c63c: mov             fp, SP
    // 0x82c640: AllocStack(0x30)
    //     0x82c640: sub             SP, SP, #0x30
    // 0x82c644: CheckStackOverflow
    //     0x82c644: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82c648: cmp             SP, x16
    //     0x82c64c: b.ls            #0x82c934
    // 0x82c650: ldr             x0, [fp, #0x18]
    // 0x82c654: LoadField: r1 = r0->field_33
    //     0x82c654: ldur            w1, [x0, #0x33]
    // 0x82c658: DecompressPointer r1
    //     0x82c658: add             x1, x1, HEAP, lsl #32
    // 0x82c65c: cmp             w1, NULL
    // 0x82c660: b.eq            #0x82c93c
    // 0x82c664: LoadField: r1 = r0->field_b
    //     0x82c664: ldur            w1, [x0, #0xb]
    // 0x82c668: DecompressPointer r1
    //     0x82c668: add             x1, x1, HEAP, lsl #32
    // 0x82c66c: cmp             w1, NULL
    // 0x82c670: b.eq            #0x82c940
    // 0x82c674: LoadField: r2 = r1->field_b
    //     0x82c674: ldur            w2, [x1, #0xb]
    // 0x82c678: DecompressPointer r2
    //     0x82c678: add             x2, x2, HEAP, lsl #32
    // 0x82c67c: LoadField: r1 = r2->field_1f
    //     0x82c67c: ldur            w1, [x2, #0x1f]
    // 0x82c680: DecompressPointer r1
    //     0x82c680: add             x1, x1, HEAP, lsl #32
    // 0x82c684: cmp             w1, NULL
    // 0x82c688: b.ne            #0x82c694
    // 0x82c68c: r3 = Null
    //     0x82c68c: mov             x3, NULL
    // 0x82c690: b               #0x82c69c
    // 0x82c694: LoadField: r3 = r1->field_7
    //     0x82c694: ldur            w3, [x1, #7]
    // 0x82c698: DecompressPointer r3
    //     0x82c698: add             x3, x3, HEAP, lsl #32
    // 0x82c69c: stur            x3, [fp, #-0x20]
    // 0x82c6a0: LoadField: r4 = r2->field_b
    //     0x82c6a0: ldur            w4, [x2, #0xb]
    // 0x82c6a4: DecompressPointer r4
    //     0x82c6a4: add             x4, x4, HEAP, lsl #32
    // 0x82c6a8: cmp             w4, NULL
    // 0x82c6ac: b.eq            #0x82c944
    // 0x82c6b0: cmp             w1, NULL
    // 0x82c6b4: b.ne            #0x82c6c0
    // 0x82c6b8: r1 = Null
    //     0x82c6b8: mov             x1, NULL
    // 0x82c6bc: b               #0x82c6ec
    // 0x82c6c0: LoadField: d0 = r1->field_b
    //     0x82c6c0: ldur            d0, [x1, #0xb]
    // 0x82c6c4: r1 = inline_Allocate_Double()
    //     0x82c6c4: ldp             x1, x5, [THR, #0x60]  ; THR::top
    //     0x82c6c8: add             x1, x1, #0x10
    //     0x82c6cc: cmp             x5, x1
    //     0x82c6d0: b.ls            #0x82c948
    //     0x82c6d4: str             x1, [THR, #0x60]  ; THR::top
    //     0x82c6d8: sub             x1, x1, #0xf
    //     0x82c6dc: mov             x5, #0xd108
    //     0x82c6e0: movk            x5, #3, lsl #16
    //     0x82c6e4: stur            x5, [x1, #-1]
    // 0x82c6e8: StoreField: r1->field_7 = d0
    //     0x82c6e8: stur            d0, [x1, #7]
    // 0x82c6ec: cmp             w1, NULL
    // 0x82c6f0: b.ne            #0x82c6fc
    // 0x82c6f4: d0 = 1.000000
    //     0x82c6f4: fmov            d0, #1.00000000
    // 0x82c6f8: b               #0x82c700
    // 0x82c6fc: LoadField: d0 = r1->field_7
    //     0x82c6fc: ldur            d0, [x1, #7]
    // 0x82c700: stur            d0, [fp, #-0x30]
    // 0x82c704: LoadField: r1 = r4->field_77
    //     0x82c704: ldur            w1, [x4, #0x77]
    // 0x82c708: DecompressPointer r1
    //     0x82c708: add             x1, x1, HEAP, lsl #32
    // 0x82c70c: stur            x1, [fp, #-0x18]
    // 0x82c710: LoadField: r4 = r2->field_27
    //     0x82c710: ldur            w4, [x2, #0x27]
    // 0x82c714: DecompressPointer r4
    //     0x82c714: add             x4, x4, HEAP, lsl #32
    // 0x82c718: r16 = Sentinel
    //     0x82c718: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82c71c: cmp             w4, w16
    // 0x82c720: b.eq            #0x82c96c
    // 0x82c724: stur            x4, [fp, #-0x10]
    // 0x82c728: LoadField: r2 = r0->field_1b
    //     0x82c728: ldur            w2, [x0, #0x1b]
    // 0x82c72c: DecompressPointer r2
    //     0x82c72c: add             x2, x2, HEAP, lsl #32
    // 0x82c730: stur            x2, [fp, #-8]
    // 0x82c734: r0 = ExtendedRawImage()
    //     0x82c734: bl              #0x82af6c  ; AllocateExtendedRawImageStub -> ExtendedRawImage (size=0x68)
    // 0x82c738: mov             x1, x0
    // 0x82c73c: ldur            x0, [fp, #-0x20]
    // 0x82c740: stur            x1, [fp, #-0x28]
    // 0x82c744: StoreField: r1->field_1f = r0
    //     0x82c744: stur            w0, [x1, #0x1f]
    // 0x82c748: ldur            d0, [fp, #-0x30]
    // 0x82c74c: StoreField: r1->field_2b = d0
    //     0x82c74c: stur            d0, [x1, #0x2b]
    // 0x82c750: ldur            x0, [fp, #-0x18]
    // 0x82c754: StoreField: r1->field_43 = r0
    //     0x82c754: stur            w0, [x1, #0x43]
    // 0x82c758: r0 = Instance_Alignment
    //     0x82c758: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x82c75c: ldr             x0, [x0, #0xc70]
    // 0x82c760: StoreField: r1->field_47 = r0
    //     0x82c760: stur            w0, [x1, #0x47]
    // 0x82c764: r0 = Instance_ImageRepeat
    //     0x82c764: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0x82c768: ldr             x0, [x0, #0x540]
    // 0x82c76c: StoreField: r1->field_4b = r0
    //     0x82c76c: stur            w0, [x1, #0x4b]
    // 0x82c770: r0 = false
    //     0x82c770: add             x0, NULL, #0x30  ; false
    // 0x82c774: StoreField: r1->field_53 = r0
    //     0x82c774: stur            w0, [x1, #0x53]
    // 0x82c778: ldur            x2, [fp, #-0x10]
    // 0x82c77c: StoreField: r1->field_57 = r2
    //     0x82c77c: stur            w2, [x1, #0x57]
    // 0x82c780: r2 = Instance_FilterQuality
    //     0x82c780: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0x82c784: ldr             x2, [x2, #0x548]
    // 0x82c788: StoreField: r1->field_3b = r2
    //     0x82c788: stur            w2, [x1, #0x3b]
    // 0x82c78c: ldur            x2, [fp, #-8]
    // 0x82c790: StoreField: r1->field_13 = r2
    //     0x82c790: stur            w2, [x1, #0x13]
    // 0x82c794: StoreField: r1->field_b = r0
    //     0x82c794: stur            w0, [x1, #0xb]
    // 0x82c798: r0 = Instance_EdgeInsets
    //     0x82c798: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x82c79c: ldr             x0, [x0, #0xbd8]
    // 0x82c7a0: StoreField: r1->field_63 = r0
    //     0x82c7a0: stur            w0, [x1, #0x63]
    // 0x82c7a4: r1 = 1
    //     0x82c7a4: mov             x1, #1
    // 0x82c7a8: r0 = AllocateContext()
    //     0x82c7a8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82c7ac: mov             x1, x0
    // 0x82c7b0: ldr             x0, [fp, #0x18]
    // 0x82c7b4: stur            x1, [fp, #-8]
    // 0x82c7b8: StoreField: r1->field_f = r0
    //     0x82c7b8: stur            w0, [x1, #0xf]
    // 0x82c7bc: r1 = 1
    //     0x82c7bc: mov             x1, #1
    // 0x82c7c0: r0 = AllocateContext()
    //     0x82c7c0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82c7c4: mov             x1, x0
    // 0x82c7c8: ldr             x0, [fp, #0x18]
    // 0x82c7cc: stur            x1, [fp, #-0x10]
    // 0x82c7d0: StoreField: r1->field_f = r0
    //     0x82c7d0: stur            w0, [x1, #0xf]
    // 0x82c7d4: r1 = 1
    //     0x82c7d4: mov             x1, #1
    // 0x82c7d8: r0 = AllocateContext()
    //     0x82c7d8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82c7dc: mov             x1, x0
    // 0x82c7e0: ldr             x0, [fp, #0x18]
    // 0x82c7e4: stur            x1, [fp, #-0x18]
    // 0x82c7e8: StoreField: r1->field_f = r0
    //     0x82c7e8: stur            w0, [x1, #0xf]
    // 0x82c7ec: r1 = 1
    //     0x82c7ec: mov             x1, #1
    // 0x82c7f0: r0 = AllocateContext()
    //     0x82c7f0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82c7f4: mov             x1, x0
    // 0x82c7f8: ldr             x0, [fp, #0x18]
    // 0x82c7fc: stur            x1, [fp, #-0x20]
    // 0x82c800: StoreField: r1->field_f = r0
    //     0x82c800: stur            w0, [x1, #0xf]
    // 0x82c804: r0 = GestureDetector()
    //     0x82c804: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x82c808: ldur            x2, [fp, #-8]
    // 0x82c80c: r1 = Function 'handleScaleStart':.
    //     0x82c80c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c640] AnonymousClosure: (0x82f370), in [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleStart (0x82eea8)
    //     0x82c810: ldr             x1, [x1, #0x640]
    // 0x82c814: stur            x0, [fp, #-8]
    // 0x82c818: r0 = AllocateClosure()
    //     0x82c818: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82c81c: ldur            x2, [fp, #-0x10]
    // 0x82c820: r1 = Function 'handleScaleUpdate':.
    //     0x82c820: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c648] AnonymousClosure: (0x82f324), in [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleUpdate (0x82dfe8)
    //     0x82c824: ldr             x1, [x1, #0x648]
    // 0x82c828: stur            x0, [fp, #-0x10]
    // 0x82c82c: r0 = AllocateClosure()
    //     0x82c82c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82c830: ldur            x2, [fp, #-0x18]
    // 0x82c834: r1 = Function 'handleScaleEnd':.
    //     0x82c834: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c650] AnonymousClosure: (0x82f2d8), in [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleEnd (0x82cc58)
    //     0x82c838: ldr             x1, [x1, #0x650]
    // 0x82c83c: stur            x0, [fp, #-0x18]
    // 0x82c840: r0 = AllocateClosure()
    //     0x82c840: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82c844: ldur            x2, [fp, #-0x20]
    // 0x82c848: r1 = Function '_handleDoubleTap@409445628':.
    //     0x82c848: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c658] AnonymousClosure: (0x82f188), in [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::_handleDoubleTap (0x82f1d0)
    //     0x82c84c: ldr             x1, [x1, #0x658]
    // 0x82c850: stur            x0, [fp, #-0x20]
    // 0x82c854: r0 = AllocateClosure()
    //     0x82c854: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82c858: ldur            x16, [fp, #-8]
    // 0x82c85c: ldur            lr, [fp, #-0x10]
    // 0x82c860: stp             lr, x16, [SP, #-0x10]!
    // 0x82c864: ldur            x16, [fp, #-0x18]
    // 0x82c868: ldur            lr, [fp, #-0x20]
    // 0x82c86c: stp             lr, x16, [SP, #-0x10]!
    // 0x82c870: ldur            x16, [fp, #-0x28]
    // 0x82c874: stp             x16, x0, [SP, #-0x10]!
    // 0x82c878: r16 = Instance_HitTestBehavior
    //     0x82c878: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!HitTestBehavior@b64931
    //     0x82c87c: ldr             x16, [x16, #0x780]
    // 0x82c880: SaveReg r16
    //     0x82c880: str             x16, [SP, #-8]!
    // 0x82c884: r4 = const [0, 0x7, 0x7, 0x1, behavior, 0x6, child, 0x5, onDoubleTap, 0x4, onScaleEnd, 0x3, onScaleStart, 0x1, onScaleUpdate, 0x2, null]
    //     0x82c884: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4c660] List(17) [0, 0x7, 0x7, 0x1, "behavior", 0x6, "child", 0x5, "onDoubleTap", 0x4, "onScaleEnd", 0x3, "onScaleStart", 0x1, "onScaleUpdate", 0x2, Null]
    //     0x82c888: ldr             x4, [x4, #0x660]
    // 0x82c88c: r0 = GestureDetector()
    //     0x82c88c: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x82c890: add             SP, SP, #0x38
    // 0x82c894: r1 = 1
    //     0x82c894: mov             x1, #1
    // 0x82c898: r0 = AllocateContext()
    //     0x82c898: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82c89c: mov             x1, x0
    // 0x82c8a0: ldr             x0, [fp, #0x18]
    // 0x82c8a4: stur            x1, [fp, #-0x10]
    // 0x82c8a8: StoreField: r1->field_f = r0
    //     0x82c8a8: stur            w0, [x1, #0xf]
    // 0x82c8ac: r1 = 1
    //     0x82c8ac: mov             x1, #1
    // 0x82c8b0: r0 = AllocateContext()
    //     0x82c8b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82c8b4: mov             x1, x0
    // 0x82c8b8: ldr             x0, [fp, #0x18]
    // 0x82c8bc: stur            x1, [fp, #-0x18]
    // 0x82c8c0: StoreField: r1->field_f = r0
    //     0x82c8c0: stur            w0, [x1, #0xf]
    // 0x82c8c4: LoadField: r2 = r0->field_33
    //     0x82c8c4: ldur            w2, [x0, #0x33]
    // 0x82c8c8: DecompressPointer r2
    //     0x82c8c8: add             x2, x2, HEAP, lsl #32
    // 0x82c8cc: cmp             w2, NULL
    // 0x82c8d0: b.eq            #0x82c978
    // 0x82c8d4: r0 = Listener()
    //     0x82c8d4: bl              #0x82af60  ; AllocateListenerStub -> Listener (size=0x38)
    // 0x82c8d8: ldur            x2, [fp, #-0x10]
    // 0x82c8dc: r1 = Function '_handlePointerDown@409445628':.
    //     0x82c8dc: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c668] AnonymousClosure: (0x82f068), in [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::_handlePointerDown (0x82f0b4)
    //     0x82c8e0: ldr             x1, [x1, #0x668]
    // 0x82c8e4: stur            x0, [fp, #-0x10]
    // 0x82c8e8: r0 = AllocateClosure()
    //     0x82c8e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82c8ec: mov             x1, x0
    // 0x82c8f0: ldur            x0, [fp, #-0x10]
    // 0x82c8f4: StoreField: r0->field_f = r1
    //     0x82c8f4: stur            w1, [x0, #0xf]
    // 0x82c8f8: ldur            x2, [fp, #-0x18]
    // 0x82c8fc: r1 = Function '_handlePointerSignal@409445628':.
    //     0x82c8fc: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c670] AnonymousClosure: (0x82c97c), in [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::_handlePointerSignal (0x82c9c8)
    //     0x82c900: ldr             x1, [x1, #0x670]
    // 0x82c904: r0 = AllocateClosure()
    //     0x82c904: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82c908: mov             x1, x0
    // 0x82c90c: ldur            x0, [fp, #-0x10]
    // 0x82c910: StoreField: r0->field_2f = r1
    //     0x82c910: stur            w1, [x0, #0x2f]
    // 0x82c914: r1 = Instance_HitTestBehavior
    //     0x82c914: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!HitTestBehavior@b64931
    //     0x82c918: ldr             x1, [x1, #0x780]
    // 0x82c91c: StoreField: r0->field_33 = r1
    //     0x82c91c: stur            w1, [x0, #0x33]
    // 0x82c920: ldur            x1, [fp, #-8]
    // 0x82c924: StoreField: r0->field_b = r1
    //     0x82c924: stur            w1, [x0, #0xb]
    // 0x82c928: LeaveFrame
    //     0x82c928: mov             SP, fp
    //     0x82c92c: ldp             fp, lr, [SP], #0x10
    // 0x82c930: ret
    //     0x82c930: ret             
    // 0x82c934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c934: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c938: b               #0x82c650
    // 0x82c93c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c93c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c940: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c940: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c944: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c944: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c948: SaveReg d0
    //     0x82c948: str             q0, [SP, #-0x10]!
    // 0x82c94c: stp             x3, x4, [SP, #-0x10]!
    // 0x82c950: stp             x0, x2, [SP, #-0x10]!
    // 0x82c954: r0 = AllocateDouble()
    //     0x82c954: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82c958: mov             x1, x0
    // 0x82c95c: ldp             x0, x2, [SP], #0x10
    // 0x82c960: ldp             x3, x4, [SP], #0x10
    // 0x82c964: RestoreReg d0
    //     0x82c964: ldr             q0, [SP], #0x10
    // 0x82c968: b               #0x82c6e8
    // 0x82c96c: r9 = _invertColors
    //     0x82c96c: add             x9, PP, #0x38, lsl #12  ; [pp+0x38510] Field <_ExtendedImageState@408436062._invertColors@408436062>: late (offset: 0x28)
    //     0x82c970: ldr             x9, [x9, #0x510]
    // 0x82c974: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x82c974: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x82c978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c978: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handlePointerSignal(dynamic, PointerSignalEvent) {
    // ** addr: 0x82c97c, size: 0x4c
    // 0x82c97c: EnterFrame
    //     0x82c97c: stp             fp, lr, [SP, #-0x10]!
    //     0x82c980: mov             fp, SP
    // 0x82c984: ldr             x0, [fp, #0x18]
    // 0x82c988: LoadField: r1 = r0->field_17
    //     0x82c988: ldur            w1, [x0, #0x17]
    // 0x82c98c: DecompressPointer r1
    //     0x82c98c: add             x1, x1, HEAP, lsl #32
    // 0x82c990: CheckStackOverflow
    //     0x82c990: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82c994: cmp             SP, x16
    //     0x82c998: b.ls            #0x82c9c0
    // 0x82c99c: LoadField: r0 = r1->field_f
    //     0x82c99c: ldur            w0, [x1, #0xf]
    // 0x82c9a0: DecompressPointer r0
    //     0x82c9a0: add             x0, x0, HEAP, lsl #32
    // 0x82c9a4: ldr             x16, [fp, #0x10]
    // 0x82c9a8: stp             x16, x0, [SP, #-0x10]!
    // 0x82c9ac: r0 = _handlePointerSignal()
    //     0x82c9ac: bl              #0x82c9c8  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::_handlePointerSignal
    // 0x82c9b0: add             SP, SP, #0x10
    // 0x82c9b4: LeaveFrame
    //     0x82c9b4: mov             SP, fp
    //     0x82c9b8: ldp             fp, lr, [SP], #0x10
    // 0x82c9bc: ret
    //     0x82c9bc: ret             
    // 0x82c9c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c9c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c9c4: b               #0x82c99c
  }
  _ _handlePointerSignal(/* No info */) {
    // ** addr: 0x82c9c8, size: 0x290
    // 0x82c9c8: EnterFrame
    //     0x82c9c8: stp             fp, lr, [SP, #-0x10]!
    //     0x82c9cc: mov             fp, SP
    // 0x82c9d0: AllocStack(0x18)
    //     0x82c9d0: sub             SP, SP, #0x18
    // 0x82c9d4: CheckStackOverflow
    //     0x82c9d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82c9d8: cmp             SP, x16
    //     0x82c9dc: b.ls            #0x82cc4c
    // 0x82c9e0: ldr             x0, [fp, #0x10]
    // 0x82c9e4: r2 = Null
    //     0x82c9e4: mov             x2, NULL
    // 0x82c9e8: r1 = Null
    //     0x82c9e8: mov             x1, NULL
    // 0x82c9ec: cmp             w0, NULL
    // 0x82c9f0: b.eq            #0x82ca10
    // 0x82c9f4: branchIfSmi(r0, 0x82ca10)
    //     0x82c9f4: tbz             w0, #0, #0x82ca10
    // 0x82c9f8: r3 = LoadClassIdInstr(r0)
    //     0x82c9f8: ldur            x3, [x0, #-1]
    //     0x82c9fc: ubfx            x3, x3, #0xc, #0x14
    // 0x82ca00: cmp             x3, #0x904
    // 0x82ca04: b.eq            #0x82ca18
    // 0x82ca08: cmp             x3, #0xb2b
    // 0x82ca0c: b.eq            #0x82ca18
    // 0x82ca10: r0 = false
    //     0x82ca10: add             x0, NULL, #0x30  ; false
    // 0x82ca14: b               #0x82ca1c
    // 0x82ca18: r0 = true
    //     0x82ca18: add             x0, NULL, #0x20  ; true
    // 0x82ca1c: tbnz            w0, #4, #0x82cc3c
    // 0x82ca20: ldr             x1, [fp, #0x10]
    // 0x82ca24: r0 = LoadClassIdInstr(r1)
    //     0x82ca24: ldur            x0, [x1, #-1]
    //     0x82ca28: ubfx            x0, x0, #0xc, #0x14
    // 0x82ca2c: SaveReg r1
    //     0x82ca2c: str             x1, [SP, #-8]!
    // 0x82ca30: r0 = GDT[cid_x0 + -0xf60]()
    //     0x82ca30: sub             lr, x0, #0xf60
    //     0x82ca34: ldr             lr, [x21, lr, lsl #3]
    //     0x82ca38: blr             lr
    // 0x82ca3c: add             SP, SP, #8
    // 0x82ca40: r16 = Instance_PointerDeviceKind
    //     0x82ca40: ldr             x16, [PP, #0x3958]  ; [pp+0x3958] Obj!PointerDeviceKind@b67191
    // 0x82ca44: cmp             w0, w16
    // 0x82ca48: b.ne            #0x82cc3c
    // 0x82ca4c: ldr             x1, [fp, #0x10]
    // 0x82ca50: r0 = LoadClassIdInstr(r1)
    //     0x82ca50: ldur            x0, [x1, #-1]
    //     0x82ca54: ubfx            x0, x0, #0xc, #0x14
    // 0x82ca58: SaveReg r1
    //     0x82ca58: str             x1, [SP, #-8]!
    // 0x82ca5c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x82ca5c: sub             lr, x0, #0xfd9
    //     0x82ca60: ldr             lr, [x21, lr, lsl #3]
    //     0x82ca64: blr             lr
    // 0x82ca68: add             SP, SP, #8
    // 0x82ca6c: stur            x0, [fp, #-8]
    // 0x82ca70: r0 = ScaleStartDetails()
    //     0x82ca70: bl              #0x78bd4c  ; AllocateScaleStartDetailsStub -> ScaleStartDetails (size=0x18)
    // 0x82ca74: mov             x1, x0
    // 0x82ca78: ldur            x0, [fp, #-8]
    // 0x82ca7c: StoreField: r1->field_7 = r0
    //     0x82ca7c: stur            w0, [x1, #7]
    // 0x82ca80: r2 = 0
    //     0x82ca80: mov             x2, #0
    // 0x82ca84: StoreField: r1->field_f = r2
    //     0x82ca84: stur            x2, [x1, #0xf]
    // 0x82ca88: StoreField: r1->field_b = r0
    //     0x82ca88: stur            w0, [x1, #0xb]
    // 0x82ca8c: ldr             x16, [fp, #0x18]
    // 0x82ca90: stp             x1, x16, [SP, #-0x10]!
    // 0x82ca94: r0 = handleScaleStart()
    //     0x82ca94: bl              #0x82eea8  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleStart
    // 0x82ca98: add             SP, SP, #0x10
    // 0x82ca9c: ldr             x1, [fp, #0x10]
    // 0x82caa0: r0 = LoadClassIdInstr(r1)
    //     0x82caa0: ldur            x0, [x1, #-1]
    //     0x82caa4: ubfx            x0, x0, #0xc, #0x14
    // 0x82caa8: SaveReg r1
    //     0x82caa8: str             x1, [SP, #-8]!
    // 0x82caac: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82caac: sub             lr, x0, #1, lsl #12
    //     0x82cab0: ldr             lr, [x21, lr, lsl #3]
    //     0x82cab4: blr             lr
    // 0x82cab8: add             SP, SP, #8
    // 0x82cabc: LoadField: d0 = r0->field_f
    //     0x82cabc: ldur            d0, [x0, #0xf]
    // 0x82cac0: ldr             x1, [fp, #0x10]
    // 0x82cac4: stur            d0, [fp, #-0x10]
    // 0x82cac8: r0 = LoadClassIdInstr(r1)
    //     0x82cac8: ldur            x0, [x1, #-1]
    //     0x82cacc: ubfx            x0, x0, #0xc, #0x14
    // 0x82cad0: SaveReg r1
    //     0x82cad0: str             x1, [SP, #-8]!
    // 0x82cad4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82cad4: sub             lr, x0, #1, lsl #12
    //     0x82cad8: ldr             lr, [x21, lr, lsl #3]
    //     0x82cadc: blr             lr
    // 0x82cae0: add             SP, SP, #8
    // 0x82cae4: LoadField: d0 = r0->field_7
    //     0x82cae4: ldur            d0, [x0, #7]
    // 0x82cae8: ldr             x0, [fp, #0x10]
    // 0x82caec: stur            d0, [fp, #-0x18]
    // 0x82caf0: r1 = LoadClassIdInstr(r0)
    //     0x82caf0: ldur            x1, [x0, #-1]
    //     0x82caf4: ubfx            x1, x1, #0xc, #0x14
    // 0x82caf8: SaveReg r0
    //     0x82caf8: str             x0, [SP, #-8]!
    // 0x82cafc: mov             x0, x1
    // 0x82cb00: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x82cb00: sub             lr, x0, #0xfd9
    //     0x82cb04: ldr             lr, [x21, lr, lsl #3]
    //     0x82cb08: blr             lr
    // 0x82cb0c: add             SP, SP, #8
    // 0x82cb10: ldur            d0, [fp, #-0x10]
    // 0x82cb14: d1 = 0.000000
    //     0x82cb14: eor             v1.16b, v1.16b, v1.16b
    // 0x82cb18: stur            x0, [fp, #-8]
    // 0x82cb1c: fcmp            d0, d1
    // 0x82cb20: b.vs            #0x82cb30
    // 0x82cb24: b.ne            #0x82cb30
    // 0x82cb28: d3 = 0.000000
    //     0x82cb28: eor             v3.16b, v3.16b, v3.16b
    // 0x82cb2c: b               #0x82cb4c
    // 0x82cb30: fcmp            d0, d1
    // 0x82cb34: b.vs            #0x82cb44
    // 0x82cb38: b.ge            #0x82cb44
    // 0x82cb3c: fneg            d2, d0
    // 0x82cb40: b               #0x82cb48
    // 0x82cb44: mov             v2.16b, v0.16b
    // 0x82cb48: mov             v3.16b, v2.16b
    // 0x82cb4c: ldur            d2, [fp, #-0x18]
    // 0x82cb50: fcmp            d2, d1
    // 0x82cb54: b.vs            #0x82cb64
    // 0x82cb58: b.ne            #0x82cb64
    // 0x82cb5c: d4 = 0.000000
    //     0x82cb5c: eor             v4.16b, v4.16b, v4.16b
    // 0x82cb60: b               #0x82cb7c
    // 0x82cb64: fcmp            d2, d1
    // 0x82cb68: b.vs            #0x82cb78
    // 0x82cb6c: b.ge            #0x82cb78
    // 0x82cb70: fneg            d4, d2
    // 0x82cb74: b               #0x82cb7c
    // 0x82cb78: mov             v4.16b, v2.16b
    // 0x82cb7c: fcmp            d3, d4
    // 0x82cb80: b.vs            #0x82cb90
    // 0x82cb84: b.le            #0x82cb90
    // 0x82cb88: mov             v3.16b, v0.16b
    // 0x82cb8c: b               #0x82cb94
    // 0x82cb90: mov             v3.16b, v2.16b
    // 0x82cb94: ldr             x1, [fp, #0x18]
    // 0x82cb98: d2 = 1.000000
    //     0x82cb98: fmov            d2, #1.00000000
    // 0x82cb9c: d0 = 1000.000000
    //     0x82cb9c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0x82cba0: ldr             d0, [x17, #0x3b0]
    // 0x82cba4: LoadField: r2 = r1->field_33
    //     0x82cba4: ldur            w2, [x1, #0x33]
    // 0x82cba8: DecompressPointer r2
    //     0x82cba8: add             x2, x2, HEAP, lsl #32
    // 0x82cbac: cmp             w2, NULL
    // 0x82cbb0: b.eq            #0x82cc54
    // 0x82cbb4: fdiv            d4, d3, d0
    // 0x82cbb8: fadd            d0, d2, d4
    // 0x82cbbc: stur            d0, [fp, #-0x10]
    // 0x82cbc0: r0 = ScaleUpdateDetails()
    //     0x82cbc0: bl              #0x78c0d8  ; AllocateScaleUpdateDetailsStub -> ScaleUpdateDetails (size=0x3c)
    // 0x82cbc4: mov             x1, x0
    // 0x82cbc8: ldur            x0, [fp, #-8]
    // 0x82cbcc: StoreField: r1->field_b = r0
    //     0x82cbcc: stur            w0, [x1, #0xb]
    // 0x82cbd0: ldur            d0, [fp, #-0x10]
    // 0x82cbd4: StoreField: r1->field_13 = d0
    //     0x82cbd4: stur            d0, [x1, #0x13]
    // 0x82cbd8: d0 = 1.000000
    //     0x82cbd8: fmov            d0, #1.00000000
    // 0x82cbdc: StoreField: r1->field_1b = d0
    //     0x82cbdc: stur            d0, [x1, #0x1b]
    // 0x82cbe0: StoreField: r1->field_23 = d0
    //     0x82cbe0: stur            d0, [x1, #0x23]
    // 0x82cbe4: d0 = 0.000000
    //     0x82cbe4: eor             v0.16b, v0.16b, v0.16b
    // 0x82cbe8: StoreField: r1->field_2b = d0
    //     0x82cbe8: stur            d0, [x1, #0x2b]
    // 0x82cbec: r2 = 0
    //     0x82cbec: mov             x2, #0
    // 0x82cbf0: StoreField: r1->field_33 = r2
    //     0x82cbf0: stur            x2, [x1, #0x33]
    // 0x82cbf4: r3 = Instance_Offset
    //     0x82cbf4: ldr             x3, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x82cbf8: StoreField: r1->field_7 = r3
    //     0x82cbf8: stur            w3, [x1, #7]
    // 0x82cbfc: StoreField: r1->field_f = r0
    //     0x82cbfc: stur            w0, [x1, #0xf]
    // 0x82cc00: ldr             x16, [fp, #0x18]
    // 0x82cc04: stp             x1, x16, [SP, #-0x10]!
    // 0x82cc08: r0 = handleScaleUpdate()
    //     0x82cc08: bl              #0x82dfe8  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleUpdate
    // 0x82cc0c: add             SP, SP, #0x10
    // 0x82cc10: r0 = ScaleEndDetails()
    //     0x82cc10: bl              #0x78ce24  ; AllocateScaleEndDetailsStub -> ScaleEndDetails (size=0x14)
    // 0x82cc14: mov             x1, x0
    // 0x82cc18: r0 = Instance_Velocity
    //     0x82cc18: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e850] Obj!Velocity@b38701
    //     0x82cc1c: ldr             x0, [x0, #0x850]
    // 0x82cc20: StoreField: r1->field_7 = r0
    //     0x82cc20: stur            w0, [x1, #7]
    // 0x82cc24: r0 = 0
    //     0x82cc24: mov             x0, #0
    // 0x82cc28: StoreField: r1->field_b = r0
    //     0x82cc28: stur            x0, [x1, #0xb]
    // 0x82cc2c: ldr             x16, [fp, #0x18]
    // 0x82cc30: stp             x1, x16, [SP, #-0x10]!
    // 0x82cc34: r0 = handleScaleEnd()
    //     0x82cc34: bl              #0x82cc58  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleEnd
    // 0x82cc38: add             SP, SP, #0x10
    // 0x82cc3c: r0 = Null
    //     0x82cc3c: mov             x0, NULL
    // 0x82cc40: LeaveFrame
    //     0x82cc40: mov             SP, fp
    //     0x82cc44: ldp             fp, lr, [SP], #0x10
    // 0x82cc48: ret
    //     0x82cc48: ret             
    // 0x82cc4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82cc4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82cc50: b               #0x82c9e0
    // 0x82cc54: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82cc54: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ handleScaleEnd(/* No info */) {
    // ** addr: 0x82cc58, size: 0x5cc
    // 0x82cc58: EnterFrame
    //     0x82cc58: stp             fp, lr, [SP, #-0x10]!
    //     0x82cc5c: mov             fp, SP
    // 0x82cc60: AllocStack(0x18)
    //     0x82cc60: sub             SP, SP, #0x18
    // 0x82cc64: CheckStackOverflow
    //     0x82cc64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82cc68: cmp             SP, x16
    //     0x82cc6c: b.ls            #0x82d0e0
    // 0x82cc70: ldr             x0, [fp, #0x18]
    // 0x82cc74: LoadField: r1 = r0->field_b
    //     0x82cc74: ldur            w1, [x0, #0xb]
    // 0x82cc78: DecompressPointer r1
    //     0x82cc78: add             x1, x1, HEAP, lsl #32
    // 0x82cc7c: cmp             w1, NULL
    // 0x82cc80: b.eq            #0x82d0e8
    // 0x82cc84: LoadField: r1 = r0->field_37
    //     0x82cc84: ldur            w1, [x0, #0x37]
    // 0x82cc88: DecompressPointer r1
    //     0x82cc88: add             x1, x1, HEAP, lsl #32
    // 0x82cc8c: stur            x1, [fp, #-0x10]
    // 0x82cc90: cmp             w1, NULL
    // 0x82cc94: b.eq            #0x82cd40
    // 0x82cc98: LoadField: r2 = r1->field_2b
    //     0x82cc98: ldur            w2, [x1, #0x2b]
    // 0x82cc9c: DecompressPointer r2
    //     0x82cc9c: add             x2, x2, HEAP, lsl #32
    // 0x82cca0: cmp             w2, NULL
    // 0x82cca4: b.eq            #0x82cd38
    // 0x82cca8: ldr             x2, [fp, #0x10]
    // 0x82ccac: LoadField: r0 = r2->field_7
    //     0x82ccac: ldur            w0, [x2, #7]
    // 0x82ccb0: DecompressPointer r0
    //     0x82ccb0: add             x0, x0, HEAP, lsl #32
    // 0x82ccb4: stur            x0, [fp, #-8]
    // 0x82ccb8: LoadField: r2 = r1->field_b
    //     0x82ccb8: ldur            w2, [x1, #0xb]
    // 0x82ccbc: DecompressPointer r2
    //     0x82ccbc: add             x2, x2, HEAP, lsl #32
    // 0x82ccc0: cmp             w2, NULL
    // 0x82ccc4: b.eq            #0x82d0ec
    // 0x82ccc8: LoadField: r2 = r0->field_7
    //     0x82ccc8: ldur            w2, [x0, #7]
    // 0x82cccc: DecompressPointer r2
    //     0x82cccc: add             x2, x2, HEAP, lsl #32
    // 0x82ccd0: LoadField: d0 = r2->field_7
    //     0x82ccd0: ldur            d0, [x2, #7]
    // 0x82ccd4: stur            d0, [fp, #-0x18]
    // 0x82ccd8: r0 = DragEndDetails()
    //     0x82ccd8: bl              #0x713c0c  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x10)
    // 0x82ccdc: mov             x1, x0
    // 0x82cce0: ldur            x0, [fp, #-8]
    // 0x82cce4: StoreField: r1->field_7 = r0
    //     0x82cce4: stur            w0, [x1, #7]
    // 0x82cce8: ldur            d0, [fp, #-0x18]
    // 0x82ccec: r0 = inline_Allocate_Double()
    //     0x82ccec: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x82ccf0: add             x0, x0, #0x10
    //     0x82ccf4: cmp             x2, x0
    //     0x82ccf8: b.ls            #0x82d0f0
    //     0x82ccfc: str             x0, [THR, #0x60]  ; THR::top
    //     0x82cd00: sub             x0, x0, #0xf
    //     0x82cd04: mov             x2, #0xd108
    //     0x82cd08: movk            x2, #3, lsl #16
    //     0x82cd0c: stur            x2, [x0, #-1]
    // 0x82cd10: StoreField: r0->field_7 = d0
    //     0x82cd10: stur            d0, [x0, #7]
    // 0x82cd14: StoreField: r1->field_b = r0
    //     0x82cd14: stur            w0, [x1, #0xb]
    // 0x82cd18: ldur            x16, [fp, #-0x10]
    // 0x82cd1c: stp             x1, x16, [SP, #-0x10]!
    // 0x82cd20: r0 = onDragEnd()
    //     0x82cd20: bl              #0x82db7c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragEnd
    // 0x82cd24: add             SP, SP, #0x10
    // 0x82cd28: r0 = Null
    //     0x82cd28: mov             x0, NULL
    // 0x82cd2c: LeaveFrame
    //     0x82cd2c: mov             SP, fp
    //     0x82cd30: ldp             fp, lr, [SP], #0x10
    // 0x82cd34: ret
    //     0x82cd34: ret             
    // 0x82cd38: ldr             x2, [fp, #0x10]
    // 0x82cd3c: b               #0x82cd44
    // 0x82cd40: ldr             x2, [fp, #0x10]
    // 0x82cd44: LoadField: r1 = r0->field_1b
    //     0x82cd44: ldur            w1, [x0, #0x1b]
    // 0x82cd48: DecompressPointer r1
    //     0x82cd48: add             x1, x1, HEAP, lsl #32
    // 0x82cd4c: cmp             w1, NULL
    // 0x82cd50: b.eq            #0x82d108
    // 0x82cd54: LoadField: d0 = r1->field_b
    //     0x82cd54: ldur            d0, [x1, #0xb]
    // 0x82cd58: LoadField: r1 = r0->field_33
    //     0x82cd58: ldur            w1, [x0, #0x33]
    // 0x82cd5c: DecompressPointer r1
    //     0x82cd5c: add             x1, x1, HEAP, lsl #32
    // 0x82cd60: cmp             w1, NULL
    // 0x82cd64: b.eq            #0x82d10c
    // 0x82cd68: LoadField: d1 = r1->field_27
    //     0x82cd68: ldur            d1, [x1, #0x27]
    // 0x82cd6c: r1 = inline_Allocate_Double()
    //     0x82cd6c: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x82cd70: add             x1, x1, #0x10
    //     0x82cd74: cmp             x3, x1
    //     0x82cd78: b.ls            #0x82d110
    //     0x82cd7c: str             x1, [THR, #0x60]  ; THR::top
    //     0x82cd80: sub             x1, x1, #0xf
    //     0x82cd84: mov             x3, #0xd108
    //     0x82cd88: movk            x3, #3, lsl #16
    //     0x82cd8c: stur            x3, [x1, #-1]
    // 0x82cd90: StoreField: r1->field_7 = d0
    //     0x82cd90: stur            d0, [x1, #7]
    // 0x82cd94: SaveReg r1
    //     0x82cd94: str             x1, [SP, #-8]!
    // 0x82cd98: SaveReg d1
    //     0x82cd98: str             d1, [SP, #-8]!
    // 0x82cd9c: r0 = DoubleExtension.greaterThan()
    //     0x82cd9c: bl              #0x6598f4  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThan
    // 0x82cda0: add             SP, SP, #0x10
    // 0x82cda4: tbnz            w0, #4, #0x82ce64
    // 0x82cda8: ldr             x0, [fp, #0x18]
    // 0x82cdac: LoadField: r1 = r0->field_1b
    //     0x82cdac: ldur            w1, [x0, #0x1b]
    // 0x82cdb0: DecompressPointer r1
    //     0x82cdb0: add             x1, x1, HEAP, lsl #32
    // 0x82cdb4: cmp             w1, NULL
    // 0x82cdb8: b.eq            #0x82d12c
    // 0x82cdbc: LoadField: d0 = r1->field_b
    //     0x82cdbc: ldur            d0, [x1, #0xb]
    // 0x82cdc0: LoadField: r1 = r0->field_33
    //     0x82cdc0: ldur            w1, [x0, #0x33]
    // 0x82cdc4: DecompressPointer r1
    //     0x82cdc4: add             x1, x1, HEAP, lsl #32
    // 0x82cdc8: cmp             w1, NULL
    // 0x82cdcc: b.eq            #0x82d130
    // 0x82cdd0: LoadField: d1 = r1->field_27
    //     0x82cdd0: ldur            d1, [x1, #0x27]
    // 0x82cdd4: fsub            d2, d0, d1
    // 0x82cdd8: fdiv            d3, d2, d1
    // 0x82cddc: LoadField: r1 = r0->field_2f
    //     0x82cddc: ldur            w1, [x0, #0x2f]
    // 0x82cde0: DecompressPointer r1
    //     0x82cde0: add             x1, x1, HEAP, lsl #32
    // 0x82cde4: r16 = Sentinel
    //     0x82cde4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82cde8: cmp             w1, w16
    // 0x82cdec: b.eq            #0x82d134
    // 0x82cdf0: r0 = inline_Allocate_Double()
    //     0x82cdf0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x82cdf4: add             x0, x0, #0x10
    //     0x82cdf8: cmp             x2, x0
    //     0x82cdfc: b.ls            #0x82d140
    //     0x82ce00: str             x0, [THR, #0x60]  ; THR::top
    //     0x82ce04: sub             x0, x0, #0xf
    //     0x82ce08: mov             x2, #0xd108
    //     0x82ce0c: movk            x2, #3, lsl #16
    //     0x82ce10: stur            x2, [x0, #-1]
    // 0x82ce14: StoreField: r0->field_7 = d0
    //     0x82ce14: stur            d0, [x0, #7]
    // 0x82ce18: r2 = inline_Allocate_Double()
    //     0x82ce18: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x82ce1c: add             x2, x2, #0x10
    //     0x82ce20: cmp             x3, x2
    //     0x82ce24: b.ls            #0x82d160
    //     0x82ce28: str             x2, [THR, #0x60]  ; THR::top
    //     0x82ce2c: sub             x2, x2, #0xf
    //     0x82ce30: mov             x3, #0xd108
    //     0x82ce34: movk            x3, #3, lsl #16
    //     0x82ce38: stur            x3, [x2, #-1]
    // 0x82ce3c: StoreField: r2->field_7 = d1
    //     0x82ce3c: stur            d1, [x2, #7]
    // 0x82ce40: stp             x0, x1, [SP, #-0x10]!
    // 0x82ce44: SaveReg r2
    //     0x82ce44: str             x2, [SP, #-8]!
    // 0x82ce48: SaveReg d3
    //     0x82ce48: str             d3, [SP, #-8]!
    // 0x82ce4c: r0 = animationScale()
    //     0x82ce4c: bl              #0x82da54  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::animationScale
    // 0x82ce50: add             SP, SP, #0x20
    // 0x82ce54: r0 = Null
    //     0x82ce54: mov             x0, NULL
    // 0x82ce58: LeaveFrame
    //     0x82ce58: mov             SP, fp
    //     0x82ce5c: ldp             fp, lr, [SP], #0x10
    // 0x82ce60: ret
    //     0x82ce60: ret             
    // 0x82ce64: ldr             x0, [fp, #0x18]
    // 0x82ce68: LoadField: r1 = r0->field_1b
    //     0x82ce68: ldur            w1, [x0, #0x1b]
    // 0x82ce6c: DecompressPointer r1
    //     0x82ce6c: add             x1, x1, HEAP, lsl #32
    // 0x82ce70: cmp             w1, NULL
    // 0x82ce74: b.eq            #0x82d17c
    // 0x82ce78: LoadField: d0 = r1->field_b
    //     0x82ce78: ldur            d0, [x1, #0xb]
    // 0x82ce7c: LoadField: r1 = r0->field_33
    //     0x82ce7c: ldur            w1, [x0, #0x33]
    // 0x82ce80: DecompressPointer r1
    //     0x82ce80: add             x1, x1, HEAP, lsl #32
    // 0x82ce84: cmp             w1, NULL
    // 0x82ce88: b.eq            #0x82d180
    // 0x82ce8c: LoadField: d1 = r1->field_17
    //     0x82ce8c: ldur            d1, [x1, #0x17]
    // 0x82ce90: r1 = inline_Allocate_Double()
    //     0x82ce90: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82ce94: add             x1, x1, #0x10
    //     0x82ce98: cmp             x2, x1
    //     0x82ce9c: b.ls            #0x82d184
    //     0x82cea0: str             x1, [THR, #0x60]  ; THR::top
    //     0x82cea4: sub             x1, x1, #0xf
    //     0x82cea8: mov             x2, #0xd108
    //     0x82ceac: movk            x2, #3, lsl #16
    //     0x82ceb0: stur            x2, [x1, #-1]
    // 0x82ceb4: StoreField: r1->field_7 = d0
    //     0x82ceb4: stur            d0, [x1, #7]
    // 0x82ceb8: SaveReg r1
    //     0x82ceb8: str             x1, [SP, #-8]!
    // 0x82cebc: SaveReg d1
    //     0x82cebc: str             d1, [SP, #-8]!
    // 0x82cec0: r0 = DoubleExtension.lessThan()
    //     0x82cec0: bl              #0x659948  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThan
    // 0x82cec4: add             SP, SP, #0x10
    // 0x82cec8: tbnz            w0, #4, #0x82cf88
    // 0x82cecc: ldr             x0, [fp, #0x18]
    // 0x82ced0: LoadField: r1 = r0->field_33
    //     0x82ced0: ldur            w1, [x0, #0x33]
    // 0x82ced4: DecompressPointer r1
    //     0x82ced4: add             x1, x1, HEAP, lsl #32
    // 0x82ced8: cmp             w1, NULL
    // 0x82cedc: b.eq            #0x82d1a0
    // 0x82cee0: LoadField: d0 = r1->field_17
    //     0x82cee0: ldur            d0, [x1, #0x17]
    // 0x82cee4: LoadField: r1 = r0->field_1b
    //     0x82cee4: ldur            w1, [x0, #0x1b]
    // 0x82cee8: DecompressPointer r1
    //     0x82cee8: add             x1, x1, HEAP, lsl #32
    // 0x82ceec: cmp             w1, NULL
    // 0x82cef0: b.eq            #0x82d1a4
    // 0x82cef4: LoadField: d1 = r1->field_b
    //     0x82cef4: ldur            d1, [x1, #0xb]
    // 0x82cef8: fsub            d2, d0, d1
    // 0x82cefc: fdiv            d3, d2, d0
    // 0x82cf00: LoadField: r1 = r0->field_2f
    //     0x82cf00: ldur            w1, [x0, #0x2f]
    // 0x82cf04: DecompressPointer r1
    //     0x82cf04: add             x1, x1, HEAP, lsl #32
    // 0x82cf08: r16 = Sentinel
    //     0x82cf08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82cf0c: cmp             w1, w16
    // 0x82cf10: b.eq            #0x82d1a8
    // 0x82cf14: r0 = inline_Allocate_Double()
    //     0x82cf14: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x82cf18: add             x0, x0, #0x10
    //     0x82cf1c: cmp             x2, x0
    //     0x82cf20: b.ls            #0x82d1b4
    //     0x82cf24: str             x0, [THR, #0x60]  ; THR::top
    //     0x82cf28: sub             x0, x0, #0xf
    //     0x82cf2c: mov             x2, #0xd108
    //     0x82cf30: movk            x2, #3, lsl #16
    //     0x82cf34: stur            x2, [x0, #-1]
    // 0x82cf38: StoreField: r0->field_7 = d1
    //     0x82cf38: stur            d1, [x0, #7]
    // 0x82cf3c: r2 = inline_Allocate_Double()
    //     0x82cf3c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x82cf40: add             x2, x2, #0x10
    //     0x82cf44: cmp             x3, x2
    //     0x82cf48: b.ls            #0x82d1d4
    //     0x82cf4c: str             x2, [THR, #0x60]  ; THR::top
    //     0x82cf50: sub             x2, x2, #0xf
    //     0x82cf54: mov             x3, #0xd108
    //     0x82cf58: movk            x3, #3, lsl #16
    //     0x82cf5c: stur            x3, [x2, #-1]
    // 0x82cf60: StoreField: r2->field_7 = d0
    //     0x82cf60: stur            d0, [x2, #7]
    // 0x82cf64: stp             x0, x1, [SP, #-0x10]!
    // 0x82cf68: SaveReg r2
    //     0x82cf68: str             x2, [SP, #-8]!
    // 0x82cf6c: SaveReg d3
    //     0x82cf6c: str             d3, [SP, #-8]!
    // 0x82cf70: r0 = animationScale()
    //     0x82cf70: bl              #0x82da54  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::animationScale
    // 0x82cf74: add             SP, SP, #0x20
    // 0x82cf78: r0 = Null
    //     0x82cf78: mov             x0, NULL
    // 0x82cf7c: LeaveFrame
    //     0x82cf7c: mov             SP, fp
    //     0x82cf80: ldp             fp, lr, [SP], #0x10
    // 0x82cf84: ret
    //     0x82cf84: ret             
    // 0x82cf88: ldr             x0, [fp, #0x18]
    // 0x82cf8c: LoadField: r1 = r0->field_1b
    //     0x82cf8c: ldur            w1, [x0, #0x1b]
    // 0x82cf90: DecompressPointer r1
    //     0x82cf90: add             x1, x1, HEAP, lsl #32
    // 0x82cf94: cmp             w1, NULL
    // 0x82cf98: b.eq            #0x82d1f0
    // 0x82cf9c: LoadField: r2 = r1->field_13
    //     0x82cf9c: ldur            w2, [x1, #0x13]
    // 0x82cfa0: DecompressPointer r2
    //     0x82cfa0: add             x2, x2, HEAP, lsl #32
    // 0x82cfa4: r16 = Instance_ActionType
    //     0x82cfa4: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c5f0] Obj!ActionType@b66131
    //     0x82cfa8: ldr             x16, [x16, #0x5f0]
    // 0x82cfac: cmp             w2, w16
    // 0x82cfb0: b.ne            #0x82d0d0
    // 0x82cfb4: ldr             x1, [fp, #0x10]
    // 0x82cfb8: d0 = 400.000000
    //     0x82cfb8: add             x17, PP, #0x27, lsl #12  ; [pp+0x27d80] IMM: double(400) from 0x4079000000000000
    //     0x82cfbc: ldr             d0, [x17, #0xd80]
    // 0x82cfc0: LoadField: r2 = r1->field_7
    //     0x82cfc0: ldur            w2, [x1, #7]
    // 0x82cfc4: DecompressPointer r2
    //     0x82cfc4: add             x2, x2, HEAP, lsl #32
    // 0x82cfc8: LoadField: r1 = r2->field_7
    //     0x82cfc8: ldur            w1, [x2, #7]
    // 0x82cfcc: DecompressPointer r1
    //     0x82cfcc: add             x1, x1, HEAP, lsl #32
    // 0x82cfd0: stur            x1, [fp, #-0x10]
    // 0x82cfd4: LoadField: d1 = r1->field_7
    //     0x82cfd4: ldur            d1, [x1, #7]
    // 0x82cfd8: fmul            d2, d1, d1
    // 0x82cfdc: LoadField: d1 = r1->field_f
    //     0x82cfdc: ldur            d1, [x1, #0xf]
    // 0x82cfe0: fmul            d3, d1, d1
    // 0x82cfe4: fadd            d1, d2, d3
    // 0x82cfe8: fsqrt           d2, d1
    // 0x82cfec: r2 = inline_Allocate_Double()
    //     0x82cfec: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x82cff0: add             x2, x2, #0x10
    //     0x82cff4: cmp             x3, x2
    //     0x82cff8: b.ls            #0x82d1f4
    //     0x82cffc: str             x2, [THR, #0x60]  ; THR::top
    //     0x82d000: sub             x2, x2, #0xf
    //     0x82d004: mov             x3, #0xd108
    //     0x82d008: movk            x3, #3, lsl #16
    //     0x82d00c: stur            x3, [x2, #-1]
    // 0x82d010: StoreField: r2->field_7 = d2
    //     0x82d010: stur            d2, [x2, #7]
    // 0x82d014: stur            x2, [fp, #-8]
    // 0x82d018: SaveReg r2
    //     0x82d018: str             x2, [SP, #-8]!
    // 0x82d01c: SaveReg d0
    //     0x82d01c: str             d0, [SP, #-8]!
    // 0x82d020: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x82d020: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x82d024: add             SP, SP, #0x10
    // 0x82d028: tbnz            w0, #4, #0x82d0d0
    // 0x82d02c: ldr             x0, [fp, #0x18]
    // 0x82d030: ldur            x16, [fp, #-0x10]
    // 0x82d034: ldur            lr, [fp, #-8]
    // 0x82d038: stp             lr, x16, [SP, #-0x10]!
    // 0x82d03c: r0 = /()
    //     0x82d03c: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x82d040: add             SP, SP, #0x10
    // 0x82d044: mov             x1, x0
    // 0x82d048: ldr             x0, [fp, #0x18]
    // 0x82d04c: LoadField: r2 = r0->field_33
    //     0x82d04c: ldur            w2, [x0, #0x33]
    // 0x82d050: DecompressPointer r2
    //     0x82d050: add             x2, x2, HEAP, lsl #32
    // 0x82d054: cmp             w2, NULL
    // 0x82d058: b.eq            #0x82d210
    // 0x82d05c: r16 = 100.000000
    //     0x82d05c: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2adb0] 100
    //     0x82d060: ldr             x16, [x16, #0xdb0]
    // 0x82d064: stp             x16, x1, [SP, #-0x10]!
    // 0x82d068: r0 = *()
    //     0x82d068: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x82d06c: add             SP, SP, #0x10
    // 0x82d070: mov             x1, x0
    // 0x82d074: ldr             x0, [fp, #0x18]
    // 0x82d078: LoadField: r2 = r0->field_2f
    //     0x82d078: ldur            w2, [x0, #0x2f]
    // 0x82d07c: DecompressPointer r2
    //     0x82d07c: add             x2, x2, HEAP, lsl #32
    // 0x82d080: r16 = Sentinel
    //     0x82d080: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82d084: cmp             w2, w16
    // 0x82d088: b.eq            #0x82d214
    // 0x82d08c: stur            x2, [fp, #-0x10]
    // 0x82d090: LoadField: r3 = r0->field_1b
    //     0x82d090: ldur            w3, [x0, #0x1b]
    // 0x82d094: DecompressPointer r3
    //     0x82d094: add             x3, x3, HEAP, lsl #32
    // 0x82d098: cmp             w3, NULL
    // 0x82d09c: b.eq            #0x82d220
    // 0x82d0a0: LoadField: r0 = r3->field_7
    //     0x82d0a0: ldur            w0, [x3, #7]
    // 0x82d0a4: DecompressPointer r0
    //     0x82d0a4: add             x0, x0, HEAP, lsl #32
    // 0x82d0a8: stur            x0, [fp, #-8]
    // 0x82d0ac: stp             x1, x0, [SP, #-0x10]!
    // 0x82d0b0: r0 = +()
    //     0x82d0b0: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x82d0b4: add             SP, SP, #0x10
    // 0x82d0b8: ldur            x16, [fp, #-0x10]
    // 0x82d0bc: ldur            lr, [fp, #-8]
    // 0x82d0c0: stp             lr, x16, [SP, #-0x10]!
    // 0x82d0c4: SaveReg r0
    //     0x82d0c4: str             x0, [SP, #-8]!
    // 0x82d0c8: r0 = animationOffset()
    //     0x82d0c8: bl              #0x82d224  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::animationOffset
    // 0x82d0cc: add             SP, SP, #0x18
    // 0x82d0d0: r0 = Null
    //     0x82d0d0: mov             x0, NULL
    // 0x82d0d4: LeaveFrame
    //     0x82d0d4: mov             SP, fp
    //     0x82d0d8: ldp             fp, lr, [SP], #0x10
    // 0x82d0dc: ret
    //     0x82d0dc: ret             
    // 0x82d0e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d0e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d0e4: b               #0x82cc70
    // 0x82d0e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82d0e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82d0ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82d0ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82d0f0: SaveReg d0
    //     0x82d0f0: str             q0, [SP, #-0x10]!
    // 0x82d0f4: SaveReg r1
    //     0x82d0f4: str             x1, [SP, #-8]!
    // 0x82d0f8: r0 = AllocateDouble()
    //     0x82d0f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82d0fc: RestoreReg r1
    //     0x82d0fc: ldr             x1, [SP], #8
    // 0x82d100: RestoreReg d0
    //     0x82d100: ldr             q0, [SP], #0x10
    // 0x82d104: b               #0x82cd10
    // 0x82d108: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82d108: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82d10c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82d10c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82d110: stp             q0, q1, [SP, #-0x20]!
    // 0x82d114: stp             x0, x2, [SP, #-0x10]!
    // 0x82d118: r0 = AllocateDouble()
    //     0x82d118: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82d11c: mov             x1, x0
    // 0x82d120: ldp             x0, x2, [SP], #0x10
    // 0x82d124: ldp             q0, q1, [SP], #0x20
    // 0x82d128: b               #0x82cd90
    // 0x82d12c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82d12c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82d130: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82d130: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82d134: r9 = _gestureAnimation
    //     0x82d134: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c608] Field <ExtendedImageGestureState._gestureAnimation@409445628>: late (offset: 0x30)
    //     0x82d138: ldr             x9, [x9, #0x608]
    // 0x82d13c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x82d13c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x82d140: stp             q1, q3, [SP, #-0x20]!
    // 0x82d144: SaveReg d0
    //     0x82d144: str             q0, [SP, #-0x10]!
    // 0x82d148: SaveReg r1
    //     0x82d148: str             x1, [SP, #-8]!
    // 0x82d14c: r0 = AllocateDouble()
    //     0x82d14c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82d150: RestoreReg r1
    //     0x82d150: ldr             x1, [SP], #8
    // 0x82d154: RestoreReg d0
    //     0x82d154: ldr             q0, [SP], #0x10
    // 0x82d158: ldp             q1, q3, [SP], #0x20
    // 0x82d15c: b               #0x82ce14
    // 0x82d160: stp             q1, q3, [SP, #-0x20]!
    // 0x82d164: stp             x0, x1, [SP, #-0x10]!
    // 0x82d168: r0 = AllocateDouble()
    //     0x82d168: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82d16c: mov             x2, x0
    // 0x82d170: ldp             x0, x1, [SP], #0x10
    // 0x82d174: ldp             q1, q3, [SP], #0x20
    // 0x82d178: b               #0x82ce3c
    // 0x82d17c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82d17c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82d180: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82d180: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82d184: stp             q0, q1, [SP, #-0x20]!
    // 0x82d188: SaveReg r0
    //     0x82d188: str             x0, [SP, #-8]!
    // 0x82d18c: r0 = AllocateDouble()
    //     0x82d18c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82d190: mov             x1, x0
    // 0x82d194: RestoreReg r0
    //     0x82d194: ldr             x0, [SP], #8
    // 0x82d198: ldp             q0, q1, [SP], #0x20
    // 0x82d19c: b               #0x82ceb4
    // 0x82d1a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82d1a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82d1a4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82d1a4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82d1a8: r9 = _gestureAnimation
    //     0x82d1a8: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c608] Field <ExtendedImageGestureState._gestureAnimation@409445628>: late (offset: 0x30)
    //     0x82d1ac: ldr             x9, [x9, #0x608]
    // 0x82d1b0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x82d1b0: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x82d1b4: stp             q1, q3, [SP, #-0x20]!
    // 0x82d1b8: SaveReg d0
    //     0x82d1b8: str             q0, [SP, #-0x10]!
    // 0x82d1bc: SaveReg r1
    //     0x82d1bc: str             x1, [SP, #-8]!
    // 0x82d1c0: r0 = AllocateDouble()
    //     0x82d1c0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82d1c4: RestoreReg r1
    //     0x82d1c4: ldr             x1, [SP], #8
    // 0x82d1c8: RestoreReg d0
    //     0x82d1c8: ldr             q0, [SP], #0x10
    // 0x82d1cc: ldp             q1, q3, [SP], #0x20
    // 0x82d1d0: b               #0x82cf38
    // 0x82d1d4: stp             q0, q3, [SP, #-0x20]!
    // 0x82d1d8: stp             x0, x1, [SP, #-0x10]!
    // 0x82d1dc: r0 = AllocateDouble()
    //     0x82d1dc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82d1e0: mov             x2, x0
    // 0x82d1e4: ldp             x0, x1, [SP], #0x10
    // 0x82d1e8: ldp             q0, q3, [SP], #0x20
    // 0x82d1ec: b               #0x82cf60
    // 0x82d1f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82d1f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82d1f4: stp             q0, q2, [SP, #-0x20]!
    // 0x82d1f8: stp             x0, x1, [SP, #-0x10]!
    // 0x82d1fc: r0 = AllocateDouble()
    //     0x82d1fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82d200: mov             x2, x0
    // 0x82d204: ldp             x0, x1, [SP], #0x10
    // 0x82d208: ldp             q0, q2, [SP], #0x20
    // 0x82d20c: b               #0x82d010
    // 0x82d210: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82d210: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82d214: r9 = _gestureAnimation
    //     0x82d214: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c608] Field <ExtendedImageGestureState._gestureAnimation@409445628>: late (offset: 0x30)
    //     0x82d218: ldr             x9, [x9, #0x608]
    // 0x82d21c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82d21c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x82d220: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82d220: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleScaleUpdate(/* No info */) {
    // ** addr: 0x82dfe8, size: 0x830
    // 0x82dfe8: EnterFrame
    //     0x82dfe8: stp             fp, lr, [SP, #-0x10]!
    //     0x82dfec: mov             fp, SP
    // 0x82dff0: AllocStack(0x28)
    //     0x82dff0: sub             SP, SP, #0x28
    // 0x82dff4: CheckStackOverflow
    //     0x82dff4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82dff8: cmp             SP, x16
    //     0x82dffc: b.ls            #0x82e690
    // 0x82e000: ldr             x0, [fp, #0x18]
    // 0x82e004: LoadField: r1 = r0->field_b
    //     0x82e004: ldur            w1, [x0, #0xb]
    // 0x82e008: DecompressPointer r1
    //     0x82e008: add             x1, x1, HEAP, lsl #32
    // 0x82e00c: cmp             w1, NULL
    // 0x82e010: b.eq            #0x82e698
    // 0x82e014: LoadField: r1 = r0->field_37
    //     0x82e014: ldur            w1, [x0, #0x37]
    // 0x82e018: DecompressPointer r1
    //     0x82e018: add             x1, x1, HEAP, lsl #32
    // 0x82e01c: stur            x1, [fp, #-8]
    // 0x82e020: cmp             w1, NULL
    // 0x82e024: b.eq            #0x82e1d8
    // 0x82e028: LoadField: r2 = r1->field_b
    //     0x82e028: ldur            w2, [x1, #0xb]
    // 0x82e02c: DecompressPointer r2
    //     0x82e02c: add             x2, x2, HEAP, lsl #32
    // 0x82e030: cmp             w2, NULL
    // 0x82e034: b.eq            #0x82e69c
    // 0x82e038: LoadField: r2 = r1->field_2b
    //     0x82e038: ldur            w2, [x1, #0x2b]
    // 0x82e03c: DecompressPointer r2
    //     0x82e03c: add             x2, x2, HEAP, lsl #32
    // 0x82e040: cmp             w2, NULL
    // 0x82e044: b.eq            #0x82e050
    // 0x82e048: mov             x0, x1
    // 0x82e04c: b               #0x82e0b4
    // 0x82e050: ldr             x2, [fp, #0x10]
    // 0x82e054: LoadField: r3 = r2->field_33
    //     0x82e054: ldur            x3, [x2, #0x33]
    // 0x82e058: cmp             x3, #1
    // 0x82e05c: b.ne            #0x82e1d0
    // 0x82e060: d0 = 1.000000
    //     0x82e060: fmov            d0, #1.00000000
    // 0x82e064: LoadField: d1 = r2->field_13
    //     0x82e064: ldur            d1, [x2, #0x13]
    // 0x82e068: fcmp            d1, d0
    // 0x82e06c: b.vs            #0x82e1c8
    // 0x82e070: b.ne            #0x82e1c8
    // 0x82e074: LoadField: r3 = r0->field_1b
    //     0x82e074: ldur            w3, [x0, #0x1b]
    // 0x82e078: DecompressPointer r3
    //     0x82e078: add             x3, x3, HEAP, lsl #32
    // 0x82e07c: cmp             w3, NULL
    // 0x82e080: b.eq            #0x82e6a0
    // 0x82e084: LoadField: r4 = r2->field_7
    //     0x82e084: ldur            w4, [x2, #7]
    // 0x82e088: DecompressPointer r4
    //     0x82e088: add             x4, x4, HEAP, lsl #32
    // 0x82e08c: stp             x4, x3, [SP, #-0x10]!
    // 0x82e090: r0 = movePage()
    //     0x82e090: bl              #0x82edac  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::movePage
    // 0x82e094: add             SP, SP, #0x10
    // 0x82e098: mov             x1, x0
    // 0x82e09c: stur            x1, [fp, #-0x10]
    // 0x82e0a0: tbnz            w0, #5, #0x82e0a8
    // 0x82e0a4: r0 = AssertBoolean()
    //     0x82e0a4: bl              #0xd67df0  ; AssertBooleanStub
    // 0x82e0a8: ldur            x0, [fp, #-0x10]
    // 0x82e0ac: tbnz            w0, #4, #0x82e1c0
    // 0x82e0b0: ldur            x0, [fp, #-8]
    // 0x82e0b4: LoadField: r1 = r0->field_2b
    //     0x82e0b4: ldur            w1, [x0, #0x2b]
    // 0x82e0b8: DecompressPointer r1
    //     0x82e0b8: add             x1, x1, HEAP, lsl #32
    // 0x82e0bc: cmp             w1, NULL
    // 0x82e0c0: b.ne            #0x82e118
    // 0x82e0c4: ldr             x1, [fp, #0x10]
    // 0x82e0c8: LoadField: r2 = r1->field_b
    //     0x82e0c8: ldur            w2, [x1, #0xb]
    // 0x82e0cc: DecompressPointer r2
    //     0x82e0cc: add             x2, x2, HEAP, lsl #32
    // 0x82e0d0: stur            x2, [fp, #-0x10]
    // 0x82e0d4: r0 = DragDownDetails()
    //     0x82e0d4: bl              #0x719970  ; AllocateDragDownDetailsStub -> DragDownDetails (size=0xc)
    // 0x82e0d8: mov             x1, x0
    // 0x82e0dc: ldur            x0, [fp, #-0x10]
    // 0x82e0e0: StoreField: r1->field_7 = r0
    //     0x82e0e0: stur            w0, [x1, #7]
    // 0x82e0e4: ldur            x16, [fp, #-8]
    // 0x82e0e8: stp             x1, x16, [SP, #-0x10]!
    // 0x82e0ec: r0 = onDragDown()
    //     0x82e0ec: bl              #0x82eb2c  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragDown
    // 0x82e0f0: add             SP, SP, #0x10
    // 0x82e0f4: r0 = DragStartDetails()
    //     0x82e0f4: bl              #0x719b08  ; AllocateDragStartDetailsStub -> DragStartDetails (size=0x18)
    // 0x82e0f8: mov             x1, x0
    // 0x82e0fc: ldur            x0, [fp, #-0x10]
    // 0x82e100: StoreField: r1->field_b = r0
    //     0x82e100: stur            w0, [x1, #0xb]
    // 0x82e104: StoreField: r1->field_f = r0
    //     0x82e104: stur            w0, [x1, #0xf]
    // 0x82e108: ldur            x16, [fp, #-8]
    // 0x82e10c: stp             x1, x16, [SP, #-0x10]!
    // 0x82e110: r0 = onDragStart()
    //     0x82e110: bl              #0x82e984  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragStart
    // 0x82e114: add             SP, SP, #0x10
    // 0x82e118: ldr             x0, [fp, #0x10]
    // 0x82e11c: LoadField: r1 = r0->field_7
    //     0x82e11c: ldur            w1, [x0, #7]
    // 0x82e120: DecompressPointer r1
    //     0x82e120: add             x1, x1, HEAP, lsl #32
    // 0x82e124: LoadField: d0 = r1->field_7
    //     0x82e124: ldur            d0, [x1, #7]
    // 0x82e128: stur            d0, [fp, #-0x28]
    // 0x82e12c: r0 = Offset()
    //     0x82e12c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x82e130: ldur            d0, [fp, #-0x28]
    // 0x82e134: stur            x0, [fp, #-0x18]
    // 0x82e138: StoreField: r0->field_7 = d0
    //     0x82e138: stur            d0, [x0, #7]
    // 0x82e13c: d1 = 0.000000
    //     0x82e13c: eor             v1.16b, v1.16b, v1.16b
    // 0x82e140: StoreField: r0->field_f = d1
    //     0x82e140: stur            d1, [x0, #0xf]
    // 0x82e144: ldr             x1, [fp, #0x10]
    // 0x82e148: LoadField: r2 = r1->field_b
    //     0x82e148: ldur            w2, [x1, #0xb]
    // 0x82e14c: DecompressPointer r2
    //     0x82e14c: add             x2, x2, HEAP, lsl #32
    // 0x82e150: stur            x2, [fp, #-0x10]
    // 0x82e154: r0 = DragUpdateDetails()
    //     0x82e154: bl              #0x64e814  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x1c)
    // 0x82e158: mov             x1, x0
    // 0x82e15c: ldur            x0, [fp, #-0x18]
    // 0x82e160: StoreField: r1->field_b = r0
    //     0x82e160: stur            w0, [x1, #0xb]
    // 0x82e164: ldur            d0, [fp, #-0x28]
    // 0x82e168: r0 = inline_Allocate_Double()
    //     0x82e168: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x82e16c: add             x0, x0, #0x10
    //     0x82e170: cmp             x2, x0
    //     0x82e174: b.ls            #0x82e6a4
    //     0x82e178: str             x0, [THR, #0x60]  ; THR::top
    //     0x82e17c: sub             x0, x0, #0xf
    //     0x82e180: mov             x2, #0xd108
    //     0x82e184: movk            x2, #3, lsl #16
    //     0x82e188: stur            x2, [x0, #-1]
    // 0x82e18c: StoreField: r0->field_7 = d0
    //     0x82e18c: stur            d0, [x0, #7]
    // 0x82e190: StoreField: r1->field_f = r0
    //     0x82e190: stur            w0, [x1, #0xf]
    // 0x82e194: ldur            x0, [fp, #-0x10]
    // 0x82e198: StoreField: r1->field_13 = r0
    //     0x82e198: stur            w0, [x1, #0x13]
    // 0x82e19c: StoreField: r1->field_17 = r0
    //     0x82e19c: stur            w0, [x1, #0x17]
    // 0x82e1a0: ldur            x16, [fp, #-8]
    // 0x82e1a4: stp             x1, x16, [SP, #-0x10]!
    // 0x82e1a8: r0 = onDragUpdate()
    //     0x82e1a8: bl              #0x82e818  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::onDragUpdate
    // 0x82e1ac: add             SP, SP, #0x10
    // 0x82e1b0: r0 = Null
    //     0x82e1b0: mov             x0, NULL
    // 0x82e1b4: LeaveFrame
    //     0x82e1b4: mov             SP, fp
    //     0x82e1b8: ldp             fp, lr, [SP], #0x10
    // 0x82e1bc: ret
    //     0x82e1bc: ret             
    // 0x82e1c0: ldr             x1, [fp, #0x10]
    // 0x82e1c4: b               #0x82e1dc
    // 0x82e1c8: mov             x1, x2
    // 0x82e1cc: b               #0x82e1dc
    // 0x82e1d0: mov             x1, x2
    // 0x82e1d4: b               #0x82e1dc
    // 0x82e1d8: ldr             x1, [fp, #0x10]
    // 0x82e1dc: ldr             x2, [fp, #0x18]
    // 0x82e1e0: LoadField: r0 = r2->field_b
    //     0x82e1e0: ldur            w0, [x2, #0xb]
    // 0x82e1e4: DecompressPointer r0
    //     0x82e1e4: add             x0, x0, HEAP, lsl #32
    // 0x82e1e8: cmp             w0, NULL
    // 0x82e1ec: b.eq            #0x82e6bc
    // 0x82e1f0: LoadField: r3 = r2->field_1b
    //     0x82e1f0: ldur            w3, [x2, #0x1b]
    // 0x82e1f4: DecompressPointer r3
    //     0x82e1f4: add             x3, x3, HEAP, lsl #32
    // 0x82e1f8: LoadField: r4 = r0->field_13
    //     0x82e1f8: ldur            w4, [x0, #0x13]
    // 0x82e1fc: DecompressPointer r4
    //     0x82e1fc: add             x4, x4, HEAP, lsl #32
    // 0x82e200: stp             x3, x4, [SP, #-0x10]!
    // 0x82e204: mov             x0, x4
    // 0x82e208: ClosureCall
    //     0x82e208: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x82e20c: ldur            x2, [x0, #0x1f]
    //     0x82e210: blr             x2
    // 0x82e214: add             SP, SP, #0x10
    // 0x82e218: mov             x1, x0
    // 0x82e21c: stur            x1, [fp, #-8]
    // 0x82e220: tbnz            w0, #5, #0x82e228
    // 0x82e224: r0 = AssertBoolean()
    //     0x82e224: bl              #0xd67df0  ; AssertBooleanStub
    // 0x82e228: ldur            x0, [fp, #-8]
    // 0x82e22c: tbnz            w0, #4, #0x82e304
    // 0x82e230: ldr             x1, [fp, #0x18]
    // 0x82e234: ldr             x0, [fp, #0x10]
    // 0x82e238: LoadField: r2 = r1->field_23
    //     0x82e238: ldur            w2, [x1, #0x23]
    // 0x82e23c: DecompressPointer r2
    //     0x82e23c: add             x2, x2, HEAP, lsl #32
    // 0x82e240: cmp             w2, NULL
    // 0x82e244: b.eq            #0x82e6c0
    // 0x82e248: LoadField: d0 = r0->field_13
    //     0x82e248: ldur            d0, [x0, #0x13]
    // 0x82e24c: LoadField: d1 = r2->field_7
    //     0x82e24c: ldur            d1, [x2, #7]
    // 0x82e250: fmul            d2, d1, d0
    // 0x82e254: LoadField: r2 = r1->field_33
    //     0x82e254: ldur            w2, [x1, #0x33]
    // 0x82e258: DecompressPointer r2
    //     0x82e258: add             x2, x2, HEAP, lsl #32
    // 0x82e25c: cmp             w2, NULL
    // 0x82e260: b.eq            #0x82e6c4
    // 0x82e264: LoadField: d0 = r2->field_f
    //     0x82e264: ldur            d0, [x2, #0xf]
    // 0x82e268: LoadField: d1 = r2->field_1f
    //     0x82e268: ldur            d1, [x2, #0x1f]
    // 0x82e26c: r2 = inline_Allocate_Double()
    //     0x82e26c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x82e270: add             x2, x2, #0x10
    //     0x82e274: cmp             x3, x2
    //     0x82e278: b.ls            #0x82e6c8
    //     0x82e27c: str             x2, [THR, #0x60]  ; THR::top
    //     0x82e280: sub             x2, x2, #0xf
    //     0x82e284: mov             x3, #0xd108
    //     0x82e288: movk            x3, #3, lsl #16
    //     0x82e28c: stur            x3, [x2, #-1]
    // 0x82e290: StoreField: r2->field_7 = d2
    //     0x82e290: stur            d2, [x2, #7]
    // 0x82e294: r3 = inline_Allocate_Double()
    //     0x82e294: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x82e298: add             x3, x3, #0x10
    //     0x82e29c: cmp             x4, x3
    //     0x82e2a0: b.ls            #0x82e6ec
    //     0x82e2a4: str             x3, [THR, #0x60]  ; THR::top
    //     0x82e2a8: sub             x3, x3, #0xf
    //     0x82e2ac: mov             x4, #0xd108
    //     0x82e2b0: movk            x4, #3, lsl #16
    //     0x82e2b4: stur            x4, [x3, #-1]
    // 0x82e2b8: StoreField: r3->field_7 = d0
    //     0x82e2b8: stur            d0, [x3, #7]
    // 0x82e2bc: r4 = inline_Allocate_Double()
    //     0x82e2bc: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x82e2c0: add             x4, x4, #0x10
    //     0x82e2c4: cmp             x5, x4
    //     0x82e2c8: b.ls            #0x82e710
    //     0x82e2cc: str             x4, [THR, #0x60]  ; THR::top
    //     0x82e2d0: sub             x4, x4, #0xf
    //     0x82e2d4: mov             x5, #0xd108
    //     0x82e2d8: movk            x5, #3, lsl #16
    //     0x82e2dc: stur            x5, [x4, #-1]
    // 0x82e2e0: StoreField: r4->field_7 = d1
    //     0x82e2e0: stur            d1, [x4, #7]
    // 0x82e2e4: stp             x3, x2, [SP, #-0x10]!
    // 0x82e2e8: SaveReg r4
    //     0x82e2e8: str             x4, [SP, #-8]!
    // 0x82e2ec: r0 = clamp()
    //     0x82e2ec: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x82e2f0: add             SP, SP, #0x18
    // 0x82e2f4: LoadField: d0 = r0->field_7
    //     0x82e2f4: ldur            d0, [x0, #7]
    // 0x82e2f8: mov             v1.16b, v0.16b
    // 0x82e2fc: ldr             x0, [fp, #0x18]
    // 0x82e300: b               #0x82e320
    // 0x82e304: ldr             x0, [fp, #0x18]
    // 0x82e308: LoadField: r1 = r0->field_1b
    //     0x82e308: ldur            w1, [x0, #0x1b]
    // 0x82e30c: DecompressPointer r1
    //     0x82e30c: add             x1, x1, HEAP, lsl #32
    // 0x82e310: cmp             w1, NULL
    // 0x82e314: b.eq            #0x82e734
    // 0x82e318: LoadField: d0 = r1->field_b
    //     0x82e318: ldur            d0, [x1, #0xb]
    // 0x82e31c: mov             v1.16b, v0.16b
    // 0x82e320: ldr             x1, [fp, #0x10]
    // 0x82e324: d0 = 1.000000
    //     0x82e324: fmov            d0, #1.00000000
    // 0x82e328: stur            d1, [fp, #-0x28]
    // 0x82e32c: LoadField: d2 = r1->field_13
    //     0x82e32c: ldur            d2, [x1, #0x13]
    // 0x82e330: fcmp            d2, d0
    // 0x82e334: b.vs            #0x82e33c
    // 0x82e338: b.eq            #0x82e344
    // 0x82e33c: r2 = false
    //     0x82e33c: add             x2, NULL, #0x30  ; false
    // 0x82e340: b               #0x82e348
    // 0x82e344: r2 = true
    //     0x82e344: add             x2, NULL, #0x20  ; true
    // 0x82e348: stur            x2, [fp, #-8]
    // 0x82e34c: tbz             w2, #4, #0x82e4dc
    // 0x82e350: LoadField: r3 = r0->field_1b
    //     0x82e350: ldur            w3, [x0, #0x1b]
    // 0x82e354: DecompressPointer r3
    //     0x82e354: add             x3, x3, HEAP, lsl #32
    // 0x82e358: cmp             w3, NULL
    // 0x82e35c: b.eq            #0x82e738
    // 0x82e360: LoadField: d0 = r3->field_b
    //     0x82e360: ldur            d0, [x3, #0xb]
    // 0x82e364: LoadField: r3 = r0->field_33
    //     0x82e364: ldur            w3, [x0, #0x33]
    // 0x82e368: DecompressPointer r3
    //     0x82e368: add             x3, x3, HEAP, lsl #32
    // 0x82e36c: cmp             w3, NULL
    // 0x82e370: b.eq            #0x82e73c
    // 0x82e374: LoadField: d2 = r3->field_f
    //     0x82e374: ldur            d2, [x3, #0xf]
    // 0x82e378: r3 = inline_Allocate_Double()
    //     0x82e378: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x82e37c: add             x3, x3, #0x10
    //     0x82e380: cmp             x4, x3
    //     0x82e384: b.ls            #0x82e740
    //     0x82e388: str             x3, [THR, #0x60]  ; THR::top
    //     0x82e38c: sub             x3, x3, #0xf
    //     0x82e390: mov             x4, #0xd108
    //     0x82e394: movk            x4, #3, lsl #16
    //     0x82e398: stur            x4, [x3, #-1]
    // 0x82e39c: StoreField: r3->field_7 = d0
    //     0x82e39c: stur            d0, [x3, #7]
    // 0x82e3a0: SaveReg r3
    //     0x82e3a0: str             x3, [SP, #-8]!
    // 0x82e3a4: SaveReg d2
    //     0x82e3a4: str             d2, [SP, #-8]!
    // 0x82e3a8: r0 = DoubleExtension.equalTo()
    //     0x82e3a8: bl              #0x658bd8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.equalTo
    // 0x82e3ac: add             SP, SP, #0x10
    // 0x82e3b0: tbnz            w0, #4, #0x82e40c
    // 0x82e3b4: ldr             x0, [fp, #0x18]
    // 0x82e3b8: ldur            d0, [fp, #-0x28]
    // 0x82e3bc: LoadField: r1 = r0->field_1b
    //     0x82e3bc: ldur            w1, [x0, #0x1b]
    // 0x82e3c0: DecompressPointer r1
    //     0x82e3c0: add             x1, x1, HEAP, lsl #32
    // 0x82e3c4: cmp             w1, NULL
    // 0x82e3c8: b.eq            #0x82e76c
    // 0x82e3cc: LoadField: d1 = r1->field_b
    //     0x82e3cc: ldur            d1, [x1, #0xb]
    // 0x82e3d0: r1 = inline_Allocate_Double()
    //     0x82e3d0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82e3d4: add             x1, x1, #0x10
    //     0x82e3d8: cmp             x2, x1
    //     0x82e3dc: b.ls            #0x82e770
    //     0x82e3e0: str             x1, [THR, #0x60]  ; THR::top
    //     0x82e3e4: sub             x1, x1, #0xf
    //     0x82e3e8: mov             x2, #0xd108
    //     0x82e3ec: movk            x2, #3, lsl #16
    //     0x82e3f0: stur            x2, [x1, #-1]
    // 0x82e3f4: StoreField: r1->field_7 = d0
    //     0x82e3f4: stur            d0, [x1, #7]
    // 0x82e3f8: SaveReg r1
    //     0x82e3f8: str             x1, [SP, #-8]!
    // 0x82e3fc: SaveReg d1
    //     0x82e3fc: str             d1, [SP, #-8]!
    // 0x82e400: r0 = DoubleExtension.lessThanOrEqualTo()
    //     0x82e400: bl              #0x6589e8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThanOrEqualTo
    // 0x82e404: add             SP, SP, #0x10
    // 0x82e408: tbz             w0, #4, #0x82e4cc
    // 0x82e40c: ldr             x0, [fp, #0x18]
    // 0x82e410: LoadField: r1 = r0->field_1b
    //     0x82e410: ldur            w1, [x0, #0x1b]
    // 0x82e414: DecompressPointer r1
    //     0x82e414: add             x1, x1, HEAP, lsl #32
    // 0x82e418: cmp             w1, NULL
    // 0x82e41c: b.eq            #0x82e78c
    // 0x82e420: LoadField: d0 = r1->field_b
    //     0x82e420: ldur            d0, [x1, #0xb]
    // 0x82e424: LoadField: r1 = r0->field_33
    //     0x82e424: ldur            w1, [x0, #0x33]
    // 0x82e428: DecompressPointer r1
    //     0x82e428: add             x1, x1, HEAP, lsl #32
    // 0x82e42c: cmp             w1, NULL
    // 0x82e430: b.eq            #0x82e790
    // 0x82e434: LoadField: d1 = r1->field_1f
    //     0x82e434: ldur            d1, [x1, #0x1f]
    // 0x82e438: r1 = inline_Allocate_Double()
    //     0x82e438: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82e43c: add             x1, x1, #0x10
    //     0x82e440: cmp             x2, x1
    //     0x82e444: b.ls            #0x82e794
    //     0x82e448: str             x1, [THR, #0x60]  ; THR::top
    //     0x82e44c: sub             x1, x1, #0xf
    //     0x82e450: mov             x2, #0xd108
    //     0x82e454: movk            x2, #3, lsl #16
    //     0x82e458: stur            x2, [x1, #-1]
    // 0x82e45c: StoreField: r1->field_7 = d0
    //     0x82e45c: stur            d0, [x1, #7]
    // 0x82e460: SaveReg r1
    //     0x82e460: str             x1, [SP, #-8]!
    // 0x82e464: SaveReg d1
    //     0x82e464: str             d1, [SP, #-8]!
    // 0x82e468: r0 = DoubleExtension.equalTo()
    //     0x82e468: bl              #0x658bd8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.equalTo
    // 0x82e46c: add             SP, SP, #0x10
    // 0x82e470: tbnz            w0, #4, #0x82e4dc
    // 0x82e474: ldr             x0, [fp, #0x18]
    // 0x82e478: ldur            d0, [fp, #-0x28]
    // 0x82e47c: LoadField: r1 = r0->field_1b
    //     0x82e47c: ldur            w1, [x0, #0x1b]
    // 0x82e480: DecompressPointer r1
    //     0x82e480: add             x1, x1, HEAP, lsl #32
    // 0x82e484: cmp             w1, NULL
    // 0x82e488: b.eq            #0x82e7b0
    // 0x82e48c: LoadField: d1 = r1->field_b
    //     0x82e48c: ldur            d1, [x1, #0xb]
    // 0x82e490: r1 = inline_Allocate_Double()
    //     0x82e490: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82e494: add             x1, x1, #0x10
    //     0x82e498: cmp             x2, x1
    //     0x82e49c: b.ls            #0x82e7b4
    //     0x82e4a0: str             x1, [THR, #0x60]  ; THR::top
    //     0x82e4a4: sub             x1, x1, #0xf
    //     0x82e4a8: mov             x2, #0xd108
    //     0x82e4ac: movk            x2, #3, lsl #16
    //     0x82e4b0: stur            x2, [x1, #-1]
    // 0x82e4b4: StoreField: r1->field_7 = d0
    //     0x82e4b4: stur            d0, [x1, #7]
    // 0x82e4b8: SaveReg r1
    //     0x82e4b8: str             x1, [SP, #-8]!
    // 0x82e4bc: SaveReg d1
    //     0x82e4bc: str             d1, [SP, #-8]!
    // 0x82e4c0: r0 = DoubleExtension.greaterThanOrEqualTo()
    //     0x82e4c0: bl              #0x658b04  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThanOrEqualTo
    // 0x82e4c4: add             SP, SP, #0x10
    // 0x82e4c8: tbnz            w0, #4, #0x82e4dc
    // 0x82e4cc: r0 = Null
    //     0x82e4cc: mov             x0, NULL
    // 0x82e4d0: LeaveFrame
    //     0x82e4d0: mov             SP, fp
    //     0x82e4d4: ldp             fp, lr, [SP], #0x10
    // 0x82e4d8: ret
    //     0x82e4d8: ret             
    // 0x82e4dc: ldur            x0, [fp, #-8]
    // 0x82e4e0: tbnz            w0, #4, #0x82e520
    // 0x82e4e4: ldr             x1, [fp, #0x18]
    // 0x82e4e8: ldr             x2, [fp, #0x10]
    // 0x82e4ec: LoadField: r3 = r2->field_b
    //     0x82e4ec: ldur            w3, [x2, #0xb]
    // 0x82e4f0: DecompressPointer r3
    //     0x82e4f0: add             x3, x3, HEAP, lsl #32
    // 0x82e4f4: LoadField: r2 = r1->field_33
    //     0x82e4f4: ldur            w2, [x1, #0x33]
    // 0x82e4f8: DecompressPointer r2
    //     0x82e4f8: add             x2, x2, HEAP, lsl #32
    // 0x82e4fc: cmp             w2, NULL
    // 0x82e500: b.eq            #0x82e7d0
    // 0x82e504: r16 = 1.000000
    //     0x82e504: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x82e508: stp             x16, x3, [SP, #-0x10]!
    // 0x82e50c: r0 = *()
    //     0x82e50c: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x82e510: add             SP, SP, #0x10
    // 0x82e514: mov             x1, x0
    // 0x82e518: ldr             x0, [fp, #0x18]
    // 0x82e51c: b               #0x82e538
    // 0x82e520: ldr             x0, [fp, #0x18]
    // 0x82e524: LoadField: r1 = r0->field_27
    //     0x82e524: ldur            w1, [x0, #0x27]
    // 0x82e528: DecompressPointer r1
    //     0x82e528: add             x1, x1, HEAP, lsl #32
    // 0x82e52c: r16 = Sentinel
    //     0x82e52c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82e530: cmp             w1, w16
    // 0x82e534: b.eq            #0x82e7d4
    // 0x82e538: ldur            d0, [fp, #-0x28]
    // 0x82e53c: stur            x1, [fp, #-0x10]
    // 0x82e540: LoadField: r2 = r0->field_1f
    //     0x82e540: ldur            w2, [x0, #0x1f]
    // 0x82e544: DecompressPointer r2
    //     0x82e544: add             x2, x2, HEAP, lsl #32
    // 0x82e548: r16 = Sentinel
    //     0x82e548: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82e54c: cmp             w2, w16
    // 0x82e550: b.eq            #0x82e7e0
    // 0x82e554: r3 = inline_Allocate_Double()
    //     0x82e554: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x82e558: add             x3, x3, #0x10
    //     0x82e55c: cmp             x4, x3
    //     0x82e560: b.ls            #0x82e7ec
    //     0x82e564: str             x3, [THR, #0x60]  ; THR::top
    //     0x82e568: sub             x3, x3, #0xf
    //     0x82e56c: mov             x4, #0xd108
    //     0x82e570: movk            x4, #3, lsl #16
    //     0x82e574: stur            x4, [x3, #-1]
    // 0x82e578: StoreField: r3->field_7 = d0
    //     0x82e578: stur            d0, [x3, #7]
    // 0x82e57c: stp             x3, x2, [SP, #-0x10]!
    // 0x82e580: r0 = *()
    //     0x82e580: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x82e584: add             SP, SP, #0x10
    // 0x82e588: ldur            x16, [fp, #-0x10]
    // 0x82e58c: stp             x0, x16, [SP, #-0x10]!
    // 0x82e590: r0 = -()
    //     0x82e590: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x82e594: add             SP, SP, #0x10
    // 0x82e598: mov             x1, x0
    // 0x82e59c: ldr             x0, [fp, #0x18]
    // 0x82e5a0: stur            x1, [fp, #-0x10]
    // 0x82e5a4: LoadField: r2 = r0->field_f
    //     0x82e5a4: ldur            w2, [x0, #0xf]
    // 0x82e5a8: DecompressPointer r2
    //     0x82e5a8: add             x2, x2, HEAP, lsl #32
    // 0x82e5ac: cmp             w2, NULL
    // 0x82e5b0: b.eq            #0x82e680
    // 0x82e5b4: LoadField: r2 = r0->field_1b
    //     0x82e5b4: ldur            w2, [x0, #0x1b]
    // 0x82e5b8: DecompressPointer r2
    //     0x82e5b8: add             x2, x2, HEAP, lsl #32
    // 0x82e5bc: cmp             w2, NULL
    // 0x82e5c0: b.eq            #0x82e810
    // 0x82e5c4: LoadField: r3 = r2->field_7
    //     0x82e5c4: ldur            w3, [x2, #7]
    // 0x82e5c8: DecompressPointer r3
    //     0x82e5c8: add             x3, x3, HEAP, lsl #32
    // 0x82e5cc: stp             x3, x1, [SP, #-0x10]!
    // 0x82e5d0: r0 = ==()
    //     0x82e5d0: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x82e5d4: add             SP, SP, #0x10
    // 0x82e5d8: tbz             w0, #4, #0x82e5e8
    // 0x82e5dc: ldr             x0, [fp, #0x18]
    // 0x82e5e0: ldur            d0, [fp, #-0x28]
    // 0x82e5e4: b               #0x82e60c
    // 0x82e5e8: ldr             x0, [fp, #0x18]
    // 0x82e5ec: ldur            d0, [fp, #-0x28]
    // 0x82e5f0: LoadField: r1 = r0->field_1b
    //     0x82e5f0: ldur            w1, [x0, #0x1b]
    // 0x82e5f4: DecompressPointer r1
    //     0x82e5f4: add             x1, x1, HEAP, lsl #32
    // 0x82e5f8: cmp             w1, NULL
    // 0x82e5fc: b.eq            #0x82e814
    // 0x82e600: LoadField: d1 = r1->field_b
    //     0x82e600: ldur            d1, [x1, #0xb]
    // 0x82e604: fcmp            d0, d1
    // 0x82e608: b.eq            #0x82e680
    // 0x82e60c: ldur            x1, [fp, #-8]
    // 0x82e610: LoadField: r2 = r0->field_1b
    //     0x82e610: ldur            w2, [x0, #0x1b]
    // 0x82e614: DecompressPointer r2
    //     0x82e614: add             x2, x2, HEAP, lsl #32
    // 0x82e618: stur            x2, [fp, #-0x18]
    // 0x82e61c: tbz             w1, #4, #0x82e62c
    // 0x82e620: r1 = Instance_ActionType
    //     0x82e620: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c5a0] Obj!ActionType@b66151
    //     0x82e624: ldr             x1, [x1, #0x5a0]
    // 0x82e628: b               #0x82e634
    // 0x82e62c: r1 = Instance_ActionType
    //     0x82e62c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c5f0] Obj!ActionType@b66131
    //     0x82e630: ldr             x1, [x1, #0x5f0]
    // 0x82e634: stur            x1, [fp, #-8]
    // 0x82e638: r0 = GestureDetails()
    //     0x82e638: bl              #0x79bffc  ; AllocateGestureDetailsStub -> GestureDetails (size=0x40)
    // 0x82e63c: stur            x0, [fp, #-0x20]
    // 0x82e640: ldur            x16, [fp, #-0x10]
    // 0x82e644: stp             x16, x0, [SP, #-0x10]!
    // 0x82e648: ldur            d0, [fp, #-0x28]
    // 0x82e64c: SaveReg d0
    //     0x82e64c: str             d0, [SP, #-8]!
    // 0x82e650: ldur            x16, [fp, #-0x18]
    // 0x82e654: ldur            lr, [fp, #-8]
    // 0x82e658: stp             lr, x16, [SP, #-0x10]!
    // 0x82e65c: r4 = const [0, 0x5, 0x5, 0x3, actionType, 0x4, gestureDetails, 0x3, null]
    //     0x82e65c: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4c6a8] List(9) [0, 0x5, 0x5, 0x3, "actionType", 0x4, "gestureDetails", 0x3, Null]
    //     0x82e660: ldr             x4, [x4, #0x6a8]
    // 0x82e664: r0 = GestureDetails()
    //     0x82e664: bl              #0x79bd90  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::GestureDetails
    // 0x82e668: add             SP, SP, #0x28
    // 0x82e66c: ldr             x16, [fp, #0x18]
    // 0x82e670: ldur            lr, [fp, #-0x20]
    // 0x82e674: stp             lr, x16, [SP, #-0x10]!
    // 0x82e678: r0 = gestureDetails=()
    //     0x82e678: bl              #0x79c0e0  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::gestureDetails=
    // 0x82e67c: add             SP, SP, #0x10
    // 0x82e680: r0 = Null
    //     0x82e680: mov             x0, NULL
    // 0x82e684: LeaveFrame
    //     0x82e684: mov             SP, fp
    //     0x82e688: ldp             fp, lr, [SP], #0x10
    // 0x82e68c: ret
    //     0x82e68c: ret             
    // 0x82e690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82e690: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82e694: b               #0x82e000
    // 0x82e698: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82e698: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82e69c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82e69c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82e6a0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82e6a0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82e6a4: SaveReg d0
    //     0x82e6a4: str             q0, [SP, #-0x10]!
    // 0x82e6a8: SaveReg r1
    //     0x82e6a8: str             x1, [SP, #-8]!
    // 0x82e6ac: r0 = AllocateDouble()
    //     0x82e6ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82e6b0: RestoreReg r1
    //     0x82e6b0: ldr             x1, [SP], #8
    // 0x82e6b4: RestoreReg d0
    //     0x82e6b4: ldr             q0, [SP], #0x10
    // 0x82e6b8: b               #0x82e18c
    // 0x82e6bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82e6bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82e6c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82e6c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82e6c4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82e6c4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82e6c8: stp             q1, q2, [SP, #-0x20]!
    // 0x82e6cc: SaveReg d0
    //     0x82e6cc: str             q0, [SP, #-0x10]!
    // 0x82e6d0: stp             x0, x1, [SP, #-0x10]!
    // 0x82e6d4: r0 = AllocateDouble()
    //     0x82e6d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82e6d8: mov             x2, x0
    // 0x82e6dc: ldp             x0, x1, [SP], #0x10
    // 0x82e6e0: RestoreReg d0
    //     0x82e6e0: ldr             q0, [SP], #0x10
    // 0x82e6e4: ldp             q1, q2, [SP], #0x20
    // 0x82e6e8: b               #0x82e290
    // 0x82e6ec: stp             q0, q1, [SP, #-0x20]!
    // 0x82e6f0: stp             x1, x2, [SP, #-0x10]!
    // 0x82e6f4: SaveReg r0
    //     0x82e6f4: str             x0, [SP, #-8]!
    // 0x82e6f8: r0 = AllocateDouble()
    //     0x82e6f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82e6fc: mov             x3, x0
    // 0x82e700: RestoreReg r0
    //     0x82e700: ldr             x0, [SP], #8
    // 0x82e704: ldp             x1, x2, [SP], #0x10
    // 0x82e708: ldp             q0, q1, [SP], #0x20
    // 0x82e70c: b               #0x82e2b8
    // 0x82e710: SaveReg d1
    //     0x82e710: str             q1, [SP, #-0x10]!
    // 0x82e714: stp             x2, x3, [SP, #-0x10]!
    // 0x82e718: stp             x0, x1, [SP, #-0x10]!
    // 0x82e71c: r0 = AllocateDouble()
    //     0x82e71c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82e720: mov             x4, x0
    // 0x82e724: ldp             x0, x1, [SP], #0x10
    // 0x82e728: ldp             x2, x3, [SP], #0x10
    // 0x82e72c: RestoreReg d1
    //     0x82e72c: ldr             q1, [SP], #0x10
    // 0x82e730: b               #0x82e2e0
    // 0x82e734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82e734: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82e738: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82e738: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82e73c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82e73c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82e740: stp             q1, q2, [SP, #-0x20]!
    // 0x82e744: SaveReg d0
    //     0x82e744: str             q0, [SP, #-0x10]!
    // 0x82e748: stp             x1, x2, [SP, #-0x10]!
    // 0x82e74c: SaveReg r0
    //     0x82e74c: str             x0, [SP, #-8]!
    // 0x82e750: r0 = AllocateDouble()
    //     0x82e750: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82e754: mov             x3, x0
    // 0x82e758: RestoreReg r0
    //     0x82e758: ldr             x0, [SP], #8
    // 0x82e75c: ldp             x1, x2, [SP], #0x10
    // 0x82e760: RestoreReg d0
    //     0x82e760: ldr             q0, [SP], #0x10
    // 0x82e764: ldp             q1, q2, [SP], #0x20
    // 0x82e768: b               #0x82e39c
    // 0x82e76c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82e76c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82e770: stp             q0, q1, [SP, #-0x20]!
    // 0x82e774: SaveReg r0
    //     0x82e774: str             x0, [SP, #-8]!
    // 0x82e778: r0 = AllocateDouble()
    //     0x82e778: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82e77c: mov             x1, x0
    // 0x82e780: RestoreReg r0
    //     0x82e780: ldr             x0, [SP], #8
    // 0x82e784: ldp             q0, q1, [SP], #0x20
    // 0x82e788: b               #0x82e3f4
    // 0x82e78c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82e78c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82e790: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82e790: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82e794: stp             q0, q1, [SP, #-0x20]!
    // 0x82e798: SaveReg r0
    //     0x82e798: str             x0, [SP, #-8]!
    // 0x82e79c: r0 = AllocateDouble()
    //     0x82e79c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82e7a0: mov             x1, x0
    // 0x82e7a4: RestoreReg r0
    //     0x82e7a4: ldr             x0, [SP], #8
    // 0x82e7a8: ldp             q0, q1, [SP], #0x20
    // 0x82e7ac: b               #0x82e45c
    // 0x82e7b0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82e7b0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82e7b4: stp             q0, q1, [SP, #-0x20]!
    // 0x82e7b8: SaveReg r0
    //     0x82e7b8: str             x0, [SP, #-8]!
    // 0x82e7bc: r0 = AllocateDouble()
    //     0x82e7bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82e7c0: mov             x1, x0
    // 0x82e7c4: RestoreReg r0
    //     0x82e7c4: ldr             x0, [SP], #8
    // 0x82e7c8: ldp             q0, q1, [SP], #0x20
    // 0x82e7cc: b               #0x82e4b4
    // 0x82e7d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82e7d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82e7d4: r9 = _startingOffset
    //     0x82e7d4: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c6b0] Field <ExtendedImageGestureState._startingOffset@409445628>: late (offset: 0x28)
    //     0x82e7d8: ldr             x9, [x9, #0x6b0]
    // 0x82e7dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82e7dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x82e7e0: r9 = _normalizedOffset
    //     0x82e7e0: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c6b8] Field <ExtendedImageGestureState._normalizedOffset@409445628>: late (offset: 0x20)
    //     0x82e7e4: ldr             x9, [x9, #0x6b8]
    // 0x82e7e8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x82e7e8: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x82e7ec: SaveReg d0
    //     0x82e7ec: str             q0, [SP, #-0x10]!
    // 0x82e7f0: stp             x1, x2, [SP, #-0x10]!
    // 0x82e7f4: SaveReg r0
    //     0x82e7f4: str             x0, [SP, #-8]!
    // 0x82e7f8: r0 = AllocateDouble()
    //     0x82e7f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82e7fc: mov             x3, x0
    // 0x82e800: RestoreReg r0
    //     0x82e800: ldr             x0, [SP], #8
    // 0x82e804: ldp             x1, x2, [SP], #0x10
    // 0x82e808: RestoreReg d0
    //     0x82e808: ldr             q0, [SP], #0x10
    // 0x82e80c: b               #0x82e578
    // 0x82e810: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82e810: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82e814: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82e814: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ handleScaleStart(/* No info */) {
    // ** addr: 0x82eea8, size: 0x1c0
    // 0x82eea8: EnterFrame
    //     0x82eea8: stp             fp, lr, [SP, #-0x10]!
    //     0x82eeac: mov             fp, SP
    // 0x82eeb0: AllocStack(0x8)
    //     0x82eeb0: sub             SP, SP, #8
    // 0x82eeb4: CheckStackOverflow
    //     0x82eeb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82eeb8: cmp             SP, x16
    //     0x82eebc: b.ls            #0x82f014
    // 0x82eec0: ldr             x0, [fp, #0x18]
    // 0x82eec4: LoadField: r1 = r0->field_2f
    //     0x82eec4: ldur            w1, [x0, #0x2f]
    // 0x82eec8: DecompressPointer r1
    //     0x82eec8: add             x1, x1, HEAP, lsl #32
    // 0x82eecc: r16 = Sentinel
    //     0x82eecc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82eed0: cmp             w1, w16
    // 0x82eed4: b.eq            #0x82f01c
    // 0x82eed8: SaveReg r1
    //     0x82eed8: str             x1, [SP, #-8]!
    // 0x82eedc: r0 = stop()
    //     0x82eedc: bl              #0x82ece0  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::stop
    // 0x82eee0: add             SP, SP, #8
    // 0x82eee4: ldr             x0, [fp, #0x10]
    // 0x82eee8: LoadField: r1 = r0->field_7
    //     0x82eee8: ldur            w1, [x0, #7]
    // 0x82eeec: DecompressPointer r1
    //     0x82eeec: add             x1, x1, HEAP, lsl #32
    // 0x82eef0: ldr             x0, [fp, #0x18]
    // 0x82eef4: stur            x1, [fp, #-8]
    // 0x82eef8: LoadField: r2 = r0->field_1b
    //     0x82eef8: ldur            w2, [x0, #0x1b]
    // 0x82eefc: DecompressPointer r2
    //     0x82eefc: add             x2, x2, HEAP, lsl #32
    // 0x82ef00: cmp             w2, NULL
    // 0x82ef04: b.eq            #0x82f028
    // 0x82ef08: LoadField: r3 = r2->field_7
    //     0x82ef08: ldur            w3, [x2, #7]
    // 0x82ef0c: DecompressPointer r3
    //     0x82ef0c: add             x3, x3, HEAP, lsl #32
    // 0x82ef10: stp             x3, x1, [SP, #-0x10]!
    // 0x82ef14: r0 = -()
    //     0x82ef14: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x82ef18: add             SP, SP, #0x10
    // 0x82ef1c: mov             x1, x0
    // 0x82ef20: ldr             x0, [fp, #0x18]
    // 0x82ef24: LoadField: r2 = r0->field_1b
    //     0x82ef24: ldur            w2, [x0, #0x1b]
    // 0x82ef28: DecompressPointer r2
    //     0x82ef28: add             x2, x2, HEAP, lsl #32
    // 0x82ef2c: cmp             w2, NULL
    // 0x82ef30: b.eq            #0x82f02c
    // 0x82ef34: LoadField: d0 = r2->field_b
    //     0x82ef34: ldur            d0, [x2, #0xb]
    // 0x82ef38: r2 = inline_Allocate_Double()
    //     0x82ef38: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x82ef3c: add             x2, x2, #0x10
    //     0x82ef40: cmp             x3, x2
    //     0x82ef44: b.ls            #0x82f030
    //     0x82ef48: str             x2, [THR, #0x60]  ; THR::top
    //     0x82ef4c: sub             x2, x2, #0xf
    //     0x82ef50: mov             x3, #0xd108
    //     0x82ef54: movk            x3, #3, lsl #16
    //     0x82ef58: stur            x3, [x2, #-1]
    // 0x82ef5c: StoreField: r2->field_7 = d0
    //     0x82ef5c: stur            d0, [x2, #7]
    // 0x82ef60: stp             x2, x1, [SP, #-0x10]!
    // 0x82ef64: r0 = /()
    //     0x82ef64: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x82ef68: add             SP, SP, #0x10
    // 0x82ef6c: ldr             x1, [fp, #0x18]
    // 0x82ef70: StoreField: r1->field_1f = r0
    //     0x82ef70: stur            w0, [x1, #0x1f]
    //     0x82ef74: ldurb           w16, [x1, #-1]
    //     0x82ef78: ldurb           w17, [x0, #-1]
    //     0x82ef7c: and             x16, x17, x16, lsr #2
    //     0x82ef80: tst             x16, HEAP, lsr #32
    //     0x82ef84: b.eq            #0x82ef8c
    //     0x82ef88: bl              #0xd6826c
    // 0x82ef8c: LoadField: r2 = r1->field_1b
    //     0x82ef8c: ldur            w2, [x1, #0x1b]
    // 0x82ef90: DecompressPointer r2
    //     0x82ef90: add             x2, x2, HEAP, lsl #32
    // 0x82ef94: cmp             w2, NULL
    // 0x82ef98: b.eq            #0x82f04c
    // 0x82ef9c: LoadField: d0 = r2->field_b
    //     0x82ef9c: ldur            d0, [x2, #0xb]
    // 0x82efa0: r0 = inline_Allocate_Double()
    //     0x82efa0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x82efa4: add             x0, x0, #0x10
    //     0x82efa8: cmp             x2, x0
    //     0x82efac: b.ls            #0x82f050
    //     0x82efb0: str             x0, [THR, #0x60]  ; THR::top
    //     0x82efb4: sub             x0, x0, #0xf
    //     0x82efb8: mov             x2, #0xd108
    //     0x82efbc: movk            x2, #3, lsl #16
    //     0x82efc0: stur            x2, [x0, #-1]
    // 0x82efc4: StoreField: r0->field_7 = d0
    //     0x82efc4: stur            d0, [x0, #7]
    // 0x82efc8: StoreField: r1->field_23 = r0
    //     0x82efc8: stur            w0, [x1, #0x23]
    //     0x82efcc: ldurb           w16, [x1, #-1]
    //     0x82efd0: ldurb           w17, [x0, #-1]
    //     0x82efd4: and             x16, x17, x16, lsr #2
    //     0x82efd8: tst             x16, HEAP, lsr #32
    //     0x82efdc: b.eq            #0x82efe4
    //     0x82efe0: bl              #0xd6826c
    // 0x82efe4: ldur            x0, [fp, #-8]
    // 0x82efe8: StoreField: r1->field_27 = r0
    //     0x82efe8: stur            w0, [x1, #0x27]
    //     0x82efec: ldurb           w16, [x1, #-1]
    //     0x82eff0: ldurb           w17, [x0, #-1]
    //     0x82eff4: and             x16, x17, x16, lsr #2
    //     0x82eff8: tst             x16, HEAP, lsr #32
    //     0x82effc: b.eq            #0x82f004
    //     0x82f000: bl              #0xd6826c
    // 0x82f004: r0 = Null
    //     0x82f004: mov             x0, NULL
    // 0x82f008: LeaveFrame
    //     0x82f008: mov             SP, fp
    //     0x82f00c: ldp             fp, lr, [SP], #0x10
    // 0x82f010: ret
    //     0x82f010: ret             
    // 0x82f014: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f014: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f018: b               #0x82eec0
    // 0x82f01c: r9 = _gestureAnimation
    //     0x82f01c: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c608] Field <ExtendedImageGestureState._gestureAnimation@409445628>: late (offset: 0x30)
    //     0x82f020: ldr             x9, [x9, #0x608]
    // 0x82f024: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82f024: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x82f028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82f02c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f02c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82f030: SaveReg d0
    //     0x82f030: str             q0, [SP, #-0x10]!
    // 0x82f034: stp             x0, x1, [SP, #-0x10]!
    // 0x82f038: r0 = AllocateDouble()
    //     0x82f038: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82f03c: mov             x2, x0
    // 0x82f040: ldp             x0, x1, [SP], #0x10
    // 0x82f044: RestoreReg d0
    //     0x82f044: ldr             q0, [SP], #0x10
    // 0x82f048: b               #0x82ef5c
    // 0x82f04c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f04c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82f050: SaveReg d0
    //     0x82f050: str             q0, [SP, #-0x10]!
    // 0x82f054: SaveReg r1
    //     0x82f054: str             x1, [SP, #-8]!
    // 0x82f058: r0 = AllocateDouble()
    //     0x82f058: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82f05c: RestoreReg r1
    //     0x82f05c: ldr             x1, [SP], #8
    // 0x82f060: RestoreReg d0
    //     0x82f060: ldr             q0, [SP], #0x10
    // 0x82f064: b               #0x82efc4
  }
  [closure] void _handlePointerDown(dynamic, PointerDownEvent) {
    // ** addr: 0x82f068, size: 0x4c
    // 0x82f068: EnterFrame
    //     0x82f068: stp             fp, lr, [SP, #-0x10]!
    //     0x82f06c: mov             fp, SP
    // 0x82f070: ldr             x0, [fp, #0x18]
    // 0x82f074: LoadField: r1 = r0->field_17
    //     0x82f074: ldur            w1, [x0, #0x17]
    // 0x82f078: DecompressPointer r1
    //     0x82f078: add             x1, x1, HEAP, lsl #32
    // 0x82f07c: CheckStackOverflow
    //     0x82f07c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82f080: cmp             SP, x16
    //     0x82f084: b.ls            #0x82f0ac
    // 0x82f088: LoadField: r0 = r1->field_f
    //     0x82f088: ldur            w0, [x1, #0xf]
    // 0x82f08c: DecompressPointer r0
    //     0x82f08c: add             x0, x0, HEAP, lsl #32
    // 0x82f090: ldr             x16, [fp, #0x10]
    // 0x82f094: stp             x16, x0, [SP, #-0x10]!
    // 0x82f098: r0 = _handlePointerDown()
    //     0x82f098: bl              #0x82f0b4  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::_handlePointerDown
    // 0x82f09c: add             SP, SP, #0x10
    // 0x82f0a0: LeaveFrame
    //     0x82f0a0: mov             SP, fp
    //     0x82f0a4: ldp             fp, lr, [SP], #0x10
    // 0x82f0a8: ret
    //     0x82f0a8: ret             
    // 0x82f0ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f0ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f0b0: b               #0x82f088
  }
  _ _handlePointerDown(/* No info */) {
    // ** addr: 0x82f0b4, size: 0xd4
    // 0x82f0b4: EnterFrame
    //     0x82f0b4: stp             fp, lr, [SP, #-0x10]!
    //     0x82f0b8: mov             fp, SP
    // 0x82f0bc: CheckStackOverflow
    //     0x82f0bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82f0c0: cmp             SP, x16
    //     0x82f0c4: b.ls            #0x82f174
    // 0x82f0c8: ldr             x0, [fp, #0x10]
    // 0x82f0cc: r1 = LoadClassIdInstr(r0)
    //     0x82f0cc: ldur            x1, [x0, #-1]
    //     0x82f0d0: ubfx            x1, x1, #0xc, #0x14
    // 0x82f0d4: SaveReg r0
    //     0x82f0d4: str             x0, [SP, #-8]!
    // 0x82f0d8: mov             x0, x1
    // 0x82f0dc: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x82f0dc: sub             lr, x0, #0xfd9
    //     0x82f0e0: ldr             lr, [x21, lr, lsl #3]
    //     0x82f0e4: blr             lr
    // 0x82f0e8: add             SP, SP, #8
    // 0x82f0ec: ldr             x1, [fp, #0x18]
    // 0x82f0f0: StoreField: r1->field_2b = r0
    //     0x82f0f0: stur            w0, [x1, #0x2b]
    //     0x82f0f4: ldurb           w16, [x1, #-1]
    //     0x82f0f8: ldurb           w17, [x0, #-1]
    //     0x82f0fc: and             x16, x17, x16, lsr #2
    //     0x82f100: tst             x16, HEAP, lsr #32
    //     0x82f104: b.eq            #0x82f10c
    //     0x82f108: bl              #0xd6826c
    // 0x82f10c: LoadField: r0 = r1->field_2f
    //     0x82f10c: ldur            w0, [x1, #0x2f]
    // 0x82f110: DecompressPointer r0
    //     0x82f110: add             x0, x0, HEAP, lsl #32
    // 0x82f114: r16 = Sentinel
    //     0x82f114: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82f118: cmp             w0, w16
    // 0x82f11c: b.eq            #0x82f17c
    // 0x82f120: SaveReg r0
    //     0x82f120: str             x0, [SP, #-8]!
    // 0x82f124: r0 = stop()
    //     0x82f124: bl              #0x82ece0  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::stop
    // 0x82f128: add             SP, SP, #8
    // 0x82f12c: ldr             x0, [fp, #0x18]
    // 0x82f130: LoadField: r1 = r0->field_37
    //     0x82f130: ldur            w1, [x0, #0x37]
    // 0x82f134: DecompressPointer r1
    //     0x82f134: add             x1, x1, HEAP, lsl #32
    // 0x82f138: cmp             w1, NULL
    // 0x82f13c: b.eq            #0x82f164
    // 0x82f140: LoadField: r2 = r0->field_f
    //     0x82f140: ldur            w2, [x0, #0xf]
    // 0x82f144: DecompressPointer r2
    //     0x82f144: add             x2, x2, HEAP, lsl #32
    // 0x82f148: cmp             w2, NULL
    // 0x82f14c: b.eq            #0x82f164
    // 0x82f150: LoadField: r2 = r1->field_27
    //     0x82f150: ldur            w2, [x1, #0x27]
    // 0x82f154: DecompressPointer r2
    //     0x82f154: add             x2, x2, HEAP, lsl #32
    // 0x82f158: stp             x0, x2, [SP, #-0x10]!
    // 0x82f15c: r0 = add()
    //     0x82f15c: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x82f160: add             SP, SP, #0x10
    // 0x82f164: r0 = Null
    //     0x82f164: mov             x0, NULL
    // 0x82f168: LeaveFrame
    //     0x82f168: mov             SP, fp
    //     0x82f16c: ldp             fp, lr, [SP], #0x10
    // 0x82f170: ret
    //     0x82f170: ret             
    // 0x82f174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f174: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f178: b               #0x82f0c8
    // 0x82f17c: r9 = _gestureAnimation
    //     0x82f17c: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c608] Field <ExtendedImageGestureState._gestureAnimation@409445628>: late (offset: 0x30)
    //     0x82f180: ldr             x9, [x9, #0x608]
    // 0x82f184: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82f184: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDoubleTap(dynamic) {
    // ** addr: 0x82f188, size: 0x48
    // 0x82f188: EnterFrame
    //     0x82f188: stp             fp, lr, [SP, #-0x10]!
    //     0x82f18c: mov             fp, SP
    // 0x82f190: ldr             x0, [fp, #0x10]
    // 0x82f194: LoadField: r1 = r0->field_17
    //     0x82f194: ldur            w1, [x0, #0x17]
    // 0x82f198: DecompressPointer r1
    //     0x82f198: add             x1, x1, HEAP, lsl #32
    // 0x82f19c: CheckStackOverflow
    //     0x82f19c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82f1a0: cmp             SP, x16
    //     0x82f1a4: b.ls            #0x82f1c8
    // 0x82f1a8: LoadField: r0 = r1->field_f
    //     0x82f1a8: ldur            w0, [x1, #0xf]
    // 0x82f1ac: DecompressPointer r0
    //     0x82f1ac: add             x0, x0, HEAP, lsl #32
    // 0x82f1b0: SaveReg r0
    //     0x82f1b0: str             x0, [SP, #-8]!
    // 0x82f1b4: r0 = _handleDoubleTap()
    //     0x82f1b4: bl              #0x82f1d0  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::_handleDoubleTap
    // 0x82f1b8: add             SP, SP, #8
    // 0x82f1bc: LeaveFrame
    //     0x82f1bc: mov             SP, fp
    //     0x82f1c0: ldp             fp, lr, [SP], #0x10
    // 0x82f1c4: ret
    //     0x82f1c4: ret             
    // 0x82f1c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f1c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f1cc: b               #0x82f1a8
  }
  _ _handleDoubleTap(/* No info */) {
    // ** addr: 0x82f1d0, size: 0x108
    // 0x82f1d0: EnterFrame
    //     0x82f1d0: stp             fp, lr, [SP, #-0x10]!
    //     0x82f1d4: mov             fp, SP
    // 0x82f1d8: AllocStack(0x8)
    //     0x82f1d8: sub             SP, SP, #8
    // 0x82f1dc: CheckStackOverflow
    //     0x82f1dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82f1e0: cmp             SP, x16
    //     0x82f1e4: b.ls            #0x82f2c4
    // 0x82f1e8: ldr             x0, [fp, #0x10]
    // 0x82f1ec: LoadField: r1 = r0->field_b
    //     0x82f1ec: ldur            w1, [x0, #0xb]
    // 0x82f1f0: DecompressPointer r1
    //     0x82f1f0: add             x1, x1, HEAP, lsl #32
    // 0x82f1f4: cmp             w1, NULL
    // 0x82f1f8: b.eq            #0x82f2cc
    // 0x82f1fc: LoadField: r2 = r1->field_b
    //     0x82f1fc: ldur            w2, [x1, #0xb]
    // 0x82f200: DecompressPointer r2
    //     0x82f200: add             x2, x2, HEAP, lsl #32
    // 0x82f204: LoadField: r1 = r2->field_b
    //     0x82f204: ldur            w1, [x2, #0xb]
    // 0x82f208: DecompressPointer r1
    //     0x82f208: add             x1, x1, HEAP, lsl #32
    // 0x82f20c: cmp             w1, NULL
    // 0x82f210: b.eq            #0x82f2d0
    // 0x82f214: LoadField: r2 = r1->field_2b
    //     0x82f214: ldur            w2, [x1, #0x2b]
    // 0x82f218: DecompressPointer r2
    //     0x82f218: add             x2, x2, HEAP, lsl #32
    // 0x82f21c: cmp             w2, NULL
    // 0x82f220: b.eq            #0x82f24c
    // 0x82f224: stp             x0, x2, [SP, #-0x10]!
    // 0x82f228: mov             x0, x2
    // 0x82f22c: ClosureCall
    //     0x82f22c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x82f230: ldur            x2, [x0, #0x1f]
    //     0x82f234: blr             x2
    // 0x82f238: add             SP, SP, #0x10
    // 0x82f23c: r0 = Null
    //     0x82f23c: mov             x0, NULL
    // 0x82f240: LeaveFrame
    //     0x82f240: mov             SP, fp
    //     0x82f244: ldp             fp, lr, [SP], #0x10
    // 0x82f248: ret
    //     0x82f248: ret             
    // 0x82f24c: LoadField: r1 = r0->field_f
    //     0x82f24c: ldur            w1, [x0, #0xf]
    // 0x82f250: DecompressPointer r1
    //     0x82f250: add             x1, x1, HEAP, lsl #32
    // 0x82f254: cmp             w1, NULL
    // 0x82f258: b.ne            #0x82f26c
    // 0x82f25c: r0 = Null
    //     0x82f25c: mov             x0, NULL
    // 0x82f260: LeaveFrame
    //     0x82f260: mov             SP, fp
    //     0x82f264: ldp             fp, lr, [SP], #0x10
    // 0x82f268: ret
    //     0x82f268: ret             
    // 0x82f26c: LoadField: r1 = r0->field_33
    //     0x82f26c: ldur            w1, [x0, #0x33]
    // 0x82f270: DecompressPointer r1
    //     0x82f270: add             x1, x1, HEAP, lsl #32
    // 0x82f274: cmp             w1, NULL
    // 0x82f278: b.eq            #0x82f2d4
    // 0x82f27c: r0 = GestureDetails()
    //     0x82f27c: bl              #0x79bffc  ; AllocateGestureDetailsStub -> GestureDetails (size=0x40)
    // 0x82f280: stur            x0, [fp, #-8]
    // 0x82f284: r16 = Instance_Offset
    //     0x82f284: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x82f288: stp             x16, x0, [SP, #-0x10]!
    // 0x82f28c: d0 = 1.000000
    //     0x82f28c: fmov            d0, #1.00000000
    // 0x82f290: SaveReg d0
    //     0x82f290: str             d0, [SP, #-8]!
    // 0x82f294: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x82f294: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x82f298: r0 = GestureDetails()
    //     0x82f298: bl              #0x79bd90  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::GestureDetails
    // 0x82f29c: add             SP, SP, #0x18
    // 0x82f2a0: ldr             x16, [fp, #0x10]
    // 0x82f2a4: ldur            lr, [fp, #-8]
    // 0x82f2a8: stp             lr, x16, [SP, #-0x10]!
    // 0x82f2ac: r0 = gestureDetails=()
    //     0x82f2ac: bl              #0x79c0e0  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::gestureDetails=
    // 0x82f2b0: add             SP, SP, #0x10
    // 0x82f2b4: r0 = Null
    //     0x82f2b4: mov             x0, NULL
    // 0x82f2b8: LeaveFrame
    //     0x82f2b8: mov             SP, fp
    //     0x82f2bc: ldp             fp, lr, [SP], #0x10
    // 0x82f2c0: ret
    //     0x82f2c0: ret             
    // 0x82f2c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f2c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f2c8: b               #0x82f1e8
    // 0x82f2cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f2cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82f2d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f2d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82f2d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f2d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleScaleEnd(dynamic, ScaleEndDetails) {
    // ** addr: 0x82f2d8, size: 0x4c
    // 0x82f2d8: EnterFrame
    //     0x82f2d8: stp             fp, lr, [SP, #-0x10]!
    //     0x82f2dc: mov             fp, SP
    // 0x82f2e0: ldr             x0, [fp, #0x18]
    // 0x82f2e4: LoadField: r1 = r0->field_17
    //     0x82f2e4: ldur            w1, [x0, #0x17]
    // 0x82f2e8: DecompressPointer r1
    //     0x82f2e8: add             x1, x1, HEAP, lsl #32
    // 0x82f2ec: CheckStackOverflow
    //     0x82f2ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82f2f0: cmp             SP, x16
    //     0x82f2f4: b.ls            #0x82f31c
    // 0x82f2f8: LoadField: r0 = r1->field_f
    //     0x82f2f8: ldur            w0, [x1, #0xf]
    // 0x82f2fc: DecompressPointer r0
    //     0x82f2fc: add             x0, x0, HEAP, lsl #32
    // 0x82f300: ldr             x16, [fp, #0x10]
    // 0x82f304: stp             x16, x0, [SP, #-0x10]!
    // 0x82f308: r0 = handleScaleEnd()
    //     0x82f308: bl              #0x82cc58  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleEnd
    // 0x82f30c: add             SP, SP, #0x10
    // 0x82f310: LeaveFrame
    //     0x82f310: mov             SP, fp
    //     0x82f314: ldp             fp, lr, [SP], #0x10
    // 0x82f318: ret
    //     0x82f318: ret             
    // 0x82f31c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f31c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f320: b               #0x82f2f8
  }
  [closure] void handleScaleUpdate(dynamic, ScaleUpdateDetails) {
    // ** addr: 0x82f324, size: 0x4c
    // 0x82f324: EnterFrame
    //     0x82f324: stp             fp, lr, [SP, #-0x10]!
    //     0x82f328: mov             fp, SP
    // 0x82f32c: ldr             x0, [fp, #0x18]
    // 0x82f330: LoadField: r1 = r0->field_17
    //     0x82f330: ldur            w1, [x0, #0x17]
    // 0x82f334: DecompressPointer r1
    //     0x82f334: add             x1, x1, HEAP, lsl #32
    // 0x82f338: CheckStackOverflow
    //     0x82f338: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82f33c: cmp             SP, x16
    //     0x82f340: b.ls            #0x82f368
    // 0x82f344: LoadField: r0 = r1->field_f
    //     0x82f344: ldur            w0, [x1, #0xf]
    // 0x82f348: DecompressPointer r0
    //     0x82f348: add             x0, x0, HEAP, lsl #32
    // 0x82f34c: ldr             x16, [fp, #0x10]
    // 0x82f350: stp             x16, x0, [SP, #-0x10]!
    // 0x82f354: r0 = handleScaleUpdate()
    //     0x82f354: bl              #0x82dfe8  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleUpdate
    // 0x82f358: add             SP, SP, #0x10
    // 0x82f35c: LeaveFrame
    //     0x82f35c: mov             SP, fp
    //     0x82f360: ldp             fp, lr, [SP], #0x10
    // 0x82f364: ret
    //     0x82f364: ret             
    // 0x82f368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f368: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f36c: b               #0x82f344
  }
  [closure] void handleScaleStart(dynamic, ScaleStartDetails) {
    // ** addr: 0x82f370, size: 0x4c
    // 0x82f370: EnterFrame
    //     0x82f370: stp             fp, lr, [SP, #-0x10]!
    //     0x82f374: mov             fp, SP
    // 0x82f378: ldr             x0, [fp, #0x18]
    // 0x82f37c: LoadField: r1 = r0->field_17
    //     0x82f37c: ldur            w1, [x0, #0x17]
    // 0x82f380: DecompressPointer r1
    //     0x82f380: add             x1, x1, HEAP, lsl #32
    // 0x82f384: CheckStackOverflow
    //     0x82f384: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82f388: cmp             SP, x16
    //     0x82f38c: b.ls            #0x82f3b4
    // 0x82f390: LoadField: r0 = r1->field_f
    //     0x82f390: ldur            w0, [x1, #0xf]
    // 0x82f394: DecompressPointer r0
    //     0x82f394: add             x0, x0, HEAP, lsl #32
    // 0x82f398: ldr             x16, [fp, #0x10]
    // 0x82f39c: stp             x16, x0, [SP, #-0x10]!
    // 0x82f3a0: r0 = handleScaleStart()
    //     0x82f3a0: bl              #0x82eea8  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleStart
    // 0x82f3a4: add             SP, SP, #0x10
    // 0x82f3a8: LeaveFrame
    //     0x82f3a8: mov             SP, fp
    //     0x82f3ac: ldp             fp, lr, [SP], #0x10
    // 0x82f3b0: ret
    //     0x82f3b0: ret             
    // 0x82f3b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f3b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f3b8: b               #0x82f390
  }
  _ handleDoubleTap(/* No info */) {
    // ** addr: 0x9ae170, size: 0x13c
    // 0x9ae170: EnterFrame
    //     0x9ae170: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae174: mov             fp, SP
    // 0x9ae178: AllocStack(0x8)
    //     0x9ae178: sub             SP, SP, #8
    // 0x9ae17c: CheckStackOverflow
    //     0x9ae17c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ae180: cmp             SP, x16
    //     0x9ae184: b.ls            #0x9ae29c
    // 0x9ae188: r0 = ScaleStartDetails()
    //     0x9ae188: bl              #0x78bd4c  ; AllocateScaleStartDetailsStub -> ScaleStartDetails (size=0x18)
    // 0x9ae18c: mov             x1, x0
    // 0x9ae190: ldr             x0, [fp, #0x18]
    // 0x9ae194: StoreField: r1->field_7 = r0
    //     0x9ae194: stur            w0, [x1, #7]
    // 0x9ae198: r2 = 0
    //     0x9ae198: mov             x2, #0
    // 0x9ae19c: StoreField: r1->field_f = r2
    //     0x9ae19c: stur            x2, [x1, #0xf]
    // 0x9ae1a0: StoreField: r1->field_b = r0
    //     0x9ae1a0: stur            w0, [x1, #0xb]
    // 0x9ae1a4: ldr             x16, [fp, #0x20]
    // 0x9ae1a8: stp             x1, x16, [SP, #-0x10]!
    // 0x9ae1ac: r0 = handleScaleStart()
    //     0x9ae1ac: bl              #0x82eea8  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleStart
    // 0x9ae1b0: add             SP, SP, #0x10
    // 0x9ae1b4: ldr             x0, [fp, #0x20]
    // 0x9ae1b8: LoadField: r1 = r0->field_23
    //     0x9ae1b8: ldur            w1, [x0, #0x23]
    // 0x9ae1bc: DecompressPointer r1
    //     0x9ae1bc: add             x1, x1, HEAP, lsl #32
    // 0x9ae1c0: cmp             w1, NULL
    // 0x9ae1c4: b.eq            #0x9ae2a4
    // 0x9ae1c8: LoadField: d0 = r1->field_7
    //     0x9ae1c8: ldur            d0, [x1, #7]
    // 0x9ae1cc: ldr             d1, [fp, #0x10]
    // 0x9ae1d0: fdiv            d2, d1, d0
    // 0x9ae1d4: stur            d2, [fp, #-8]
    // 0x9ae1d8: r0 = ScaleUpdateDetails()
    //     0x9ae1d8: bl              #0x78c0d8  ; AllocateScaleUpdateDetailsStub -> ScaleUpdateDetails (size=0x3c)
    // 0x9ae1dc: mov             x1, x0
    // 0x9ae1e0: ldr             x0, [fp, #0x18]
    // 0x9ae1e4: StoreField: r1->field_b = r0
    //     0x9ae1e4: stur            w0, [x1, #0xb]
    // 0x9ae1e8: ldur            d0, [fp, #-8]
    // 0x9ae1ec: StoreField: r1->field_13 = d0
    //     0x9ae1ec: stur            d0, [x1, #0x13]
    // 0x9ae1f0: d0 = 1.000000
    //     0x9ae1f0: fmov            d0, #1.00000000
    // 0x9ae1f4: StoreField: r1->field_1b = d0
    //     0x9ae1f4: stur            d0, [x1, #0x1b]
    // 0x9ae1f8: StoreField: r1->field_23 = d0
    //     0x9ae1f8: stur            d0, [x1, #0x23]
    // 0x9ae1fc: d0 = 0.000000
    //     0x9ae1fc: eor             v0.16b, v0.16b, v0.16b
    // 0x9ae200: StoreField: r1->field_2b = d0
    //     0x9ae200: stur            d0, [x1, #0x2b]
    // 0x9ae204: r2 = 0
    //     0x9ae204: mov             x2, #0
    // 0x9ae208: StoreField: r1->field_33 = r2
    //     0x9ae208: stur            x2, [x1, #0x33]
    // 0x9ae20c: r3 = Instance_Offset
    //     0x9ae20c: ldr             x3, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x9ae210: StoreField: r1->field_7 = r3
    //     0x9ae210: stur            w3, [x1, #7]
    // 0x9ae214: StoreField: r1->field_f = r0
    //     0x9ae214: stur            w0, [x1, #0xf]
    // 0x9ae218: ldr             x16, [fp, #0x20]
    // 0x9ae21c: stp             x1, x16, [SP, #-0x10]!
    // 0x9ae220: r0 = handleScaleUpdate()
    //     0x9ae220: bl              #0x82dfe8  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleUpdate
    // 0x9ae224: add             SP, SP, #0x10
    // 0x9ae228: ldr             x0, [fp, #0x20]
    // 0x9ae22c: LoadField: r1 = r0->field_33
    //     0x9ae22c: ldur            w1, [x0, #0x33]
    // 0x9ae230: DecompressPointer r1
    //     0x9ae230: add             x1, x1, HEAP, lsl #32
    // 0x9ae234: cmp             w1, NULL
    // 0x9ae238: b.eq            #0x9ae2a8
    // 0x9ae23c: LoadField: d0 = r1->field_17
    //     0x9ae23c: ldur            d0, [x1, #0x17]
    // 0x9ae240: ldr             d1, [fp, #0x10]
    // 0x9ae244: fcmp            d1, d0
    // 0x9ae248: b.vs            #0x9ae250
    // 0x9ae24c: b.lt            #0x9ae260
    // 0x9ae250: LoadField: d0 = r1->field_27
    //     0x9ae250: ldur            d0, [x1, #0x27]
    // 0x9ae254: fcmp            d1, d0
    // 0x9ae258: b.vs            #0x9ae28c
    // 0x9ae25c: b.le            #0x9ae28c
    // 0x9ae260: r0 = ScaleEndDetails()
    //     0x9ae260: bl              #0x78ce24  ; AllocateScaleEndDetailsStub -> ScaleEndDetails (size=0x14)
    // 0x9ae264: mov             x1, x0
    // 0x9ae268: r0 = Instance_Velocity
    //     0x9ae268: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e850] Obj!Velocity@b38701
    //     0x9ae26c: ldr             x0, [x0, #0x850]
    // 0x9ae270: StoreField: r1->field_7 = r0
    //     0x9ae270: stur            w0, [x1, #7]
    // 0x9ae274: r0 = 0
    //     0x9ae274: mov             x0, #0
    // 0x9ae278: StoreField: r1->field_b = r0
    //     0x9ae278: stur            x0, [x1, #0xb]
    // 0x9ae27c: ldr             x16, [fp, #0x20]
    // 0x9ae280: stp             x1, x16, [SP, #-0x10]!
    // 0x9ae284: r0 = handleScaleEnd()
    //     0x9ae284: bl              #0x82cc58  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::handleScaleEnd
    // 0x9ae288: add             SP, SP, #0x10
    // 0x9ae28c: r0 = Null
    //     0x9ae28c: mov             x0, NULL
    // 0x9ae290: LeaveFrame
    //     0x9ae290: mov             SP, fp
    //     0x9ae294: ldp             fp, lr, [SP], #0x10
    // 0x9ae298: ret
    //     0x9ae298: ret             
    // 0x9ae29c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae29c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae2a0: b               #0x9ae188
    // 0x9ae2a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9ae2a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9ae2a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9ae2a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d60c4, size: 0x3c
    // 0x9d60c4: EnterFrame
    //     0x9d60c4: stp             fp, lr, [SP, #-0x10]!
    //     0x9d60c8: mov             fp, SP
    // 0x9d60cc: CheckStackOverflow
    //     0x9d60cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d60d0: cmp             SP, x16
    //     0x9d60d4: b.ls            #0x9d60f8
    // 0x9d60d8: ldr             x16, [fp, #0x10]
    // 0x9d60dc: SaveReg r16
    //     0x9d60dc: str             x16, [SP, #-8]!
    // 0x9d60e0: r0 = _initGestureConfig()
    //     0x9d60e0: bl              #0x79b670  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::_initGestureConfig
    // 0x9d60e4: add             SP, SP, #8
    // 0x9d60e8: r0 = Null
    //     0x9d60e8: mov             x0, NULL
    // 0x9d60ec: LeaveFrame
    //     0x9d60ec: mov             SP, fp
    //     0x9d60f0: ldp             fp, lr, [SP], #0x10
    // 0x9d60f4: ret
    //     0x9d60f4: ret             
    // 0x9d60f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d60f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d60fc: b               #0x9d60d8
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a168, size: 0x18
    // 0xa4a168: r4 = 7
    //     0xa4a168: mov             x4, #7
    // 0xa4a16c: r1 = Function 'dispose':.
    //     0xa4a16c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c578] AnonymousClosure: (0xa4a180), in [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::dispose (0xa4ee80)
    //     0xa4a170: ldr             x1, [x17, #0x578]
    // 0xa4a174: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a174: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a178: LoadField: r0 = r24->field_17
    //     0xa4a178: ldur            x0, [x24, #0x17]
    // 0xa4a17c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a180, size: 0x48
    // 0xa4a180: EnterFrame
    //     0xa4a180: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a184: mov             fp, SP
    // 0xa4a188: ldr             x0, [fp, #0x10]
    // 0xa4a18c: LoadField: r1 = r0->field_17
    //     0xa4a18c: ldur            w1, [x0, #0x17]
    // 0xa4a190: DecompressPointer r1
    //     0xa4a190: add             x1, x1, HEAP, lsl #32
    // 0xa4a194: CheckStackOverflow
    //     0xa4a194: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a198: cmp             SP, x16
    //     0xa4a19c: b.ls            #0xa4a1c0
    // 0xa4a1a0: LoadField: r0 = r1->field_f
    //     0xa4a1a0: ldur            w0, [x1, #0xf]
    // 0xa4a1a4: DecompressPointer r0
    //     0xa4a1a4: add             x0, x0, HEAP, lsl #32
    // 0xa4a1a8: SaveReg r0
    //     0xa4a1a8: str             x0, [SP, #-8]!
    // 0xa4a1ac: r0 = dispose()
    //     0xa4a1ac: bl              #0xa4ee80  ; [package:extended_image/src/gesture/gesture.dart] ExtendedImageGestureState::dispose
    // 0xa4a1b0: add             SP, SP, #8
    // 0xa4a1b4: LeaveFrame
    //     0xa4a1b4: mov             SP, fp
    //     0xa4a1b8: ldp             fp, lr, [SP], #0x10
    // 0xa4a1bc: ret
    //     0xa4a1bc: ret             
    // 0xa4a1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a1c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a1c4: b               #0xa4a1a0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4ee80, size: 0xac
    // 0xa4ee80: EnterFrame
    //     0xa4ee80: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ee84: mov             fp, SP
    // 0xa4ee88: CheckStackOverflow
    //     0xa4ee88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4ee8c: cmp             SP, x16
    //     0xa4ee90: b.ls            #0xa4ef18
    // 0xa4ee94: ldr             x0, [fp, #0x10]
    // 0xa4ee98: LoadField: r1 = r0->field_2f
    //     0xa4ee98: ldur            w1, [x0, #0x2f]
    // 0xa4ee9c: DecompressPointer r1
    //     0xa4ee9c: add             x1, x1, HEAP, lsl #32
    // 0xa4eea0: r16 = Sentinel
    //     0xa4eea0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4eea4: cmp             w1, w16
    // 0xa4eea8: b.eq            #0xa4ef20
    // 0xa4eeac: SaveReg r1
    //     0xa4eeac: str             x1, [SP, #-8]!
    // 0xa4eeb0: r0 = stop()
    //     0xa4eeb0: bl              #0x82ece0  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::stop
    // 0xa4eeb4: add             SP, SP, #8
    // 0xa4eeb8: ldr             x0, [fp, #0x10]
    // 0xa4eebc: LoadField: r1 = r0->field_2f
    //     0xa4eebc: ldur            w1, [x0, #0x2f]
    // 0xa4eec0: DecompressPointer r1
    //     0xa4eec0: add             x1, x1, HEAP, lsl #32
    // 0xa4eec4: SaveReg r1
    //     0xa4eec4: str             x1, [SP, #-8]!
    // 0xa4eec8: r0 = dispose()
    //     0xa4eec8: bl              #0xa4f000  ; [package:extended_image/src/gesture/utils.dart] GestureAnimation::dispose
    // 0xa4eecc: add             SP, SP, #8
    // 0xa4eed0: ldr             x0, [fp, #0x10]
    // 0xa4eed4: LoadField: r1 = r0->field_37
    //     0xa4eed4: ldur            w1, [x0, #0x37]
    // 0xa4eed8: DecompressPointer r1
    //     0xa4eed8: add             x1, x1, HEAP, lsl #32
    // 0xa4eedc: cmp             w1, NULL
    // 0xa4eee0: b.eq            #0xa4eef8
    // 0xa4eee4: LoadField: r2 = r1->field_27
    //     0xa4eee4: ldur            w2, [x1, #0x27]
    // 0xa4eee8: DecompressPointer r2
    //     0xa4eee8: add             x2, x2, HEAP, lsl #32
    // 0xa4eeec: stp             x0, x2, [SP, #-0x10]!
    // 0xa4eef0: r0 = remove()
    //     0xa4eef0: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xa4eef4: add             SP, SP, #0x10
    // 0xa4eef8: ldr             x16, [fp, #0x10]
    // 0xa4eefc: SaveReg r16
    //     0xa4eefc: str             x16, [SP, #-8]!
    // 0xa4ef00: r0 = dispose()
    //     0xa4ef00: bl              #0xa4ef2c  ; [package:extended_image/src/gesture/gesture.dart] _ExtendedImageGestureState&State&TickerProviderStateMixin::dispose
    // 0xa4ef04: add             SP, SP, #8
    // 0xa4ef08: r0 = Null
    //     0xa4ef08: mov             x0, NULL
    // 0xa4ef0c: LeaveFrame
    //     0xa4ef0c: mov             SP, fp
    //     0xa4ef10: ldp             fp, lr, [SP], #0x10
    // 0xa4ef14: ret
    //     0xa4ef14: ret             
    // 0xa4ef18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4ef18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4ef1c: b               #0xa4ee94
    // 0xa4ef20: r9 = _gestureAnimation
    //     0xa4ef20: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4c608] Field <ExtendedImageGestureState._gestureAnimation@409445628>: late (offset: 0x30)
    //     0xa4ef24: ldr             x9, [x9, #0x608]
    // 0xa4ef28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4ef28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa5fa90, size: 0xd0
    // 0xa5fa90: EnterFrame
    //     0xa5fa90: stp             fp, lr, [SP, #-0x10]!
    //     0xa5fa94: mov             fp, SP
    // 0xa5fa98: CheckStackOverflow
    //     0xa5fa98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5fa9c: cmp             SP, x16
    //     0xa5faa0: b.ls            #0xa5fb50
    // 0xa5faa4: ldr             x0, [fp, #0x10]
    // 0xa5faa8: StoreField: r0->field_37 = rNULL
    //     0xa5faa8: stur            NULL, [x0, #0x37]
    // 0xa5faac: LoadField: r1 = r0->field_33
    //     0xa5faac: ldur            w1, [x0, #0x33]
    // 0xa5fab0: DecompressPointer r1
    //     0xa5fab0: add             x1, x1, HEAP, lsl #32
    // 0xa5fab4: cmp             w1, NULL
    // 0xa5fab8: b.eq            #0xa5fb58
    // 0xa5fabc: LoadField: r2 = r1->field_3b
    //     0xa5fabc: ldur            w2, [x1, #0x3b]
    // 0xa5fac0: DecompressPointer r2
    //     0xa5fac0: add             x2, x2, HEAP, lsl #32
    // 0xa5fac4: tbnz            w2, #4, #0xa5fb40
    // 0xa5fac8: LoadField: r1 = r0->field_f
    //     0xa5fac8: ldur            w1, [x0, #0xf]
    // 0xa5facc: DecompressPointer r1
    //     0xa5facc: add             x1, x1, HEAP, lsl #32
    // 0xa5fad0: cmp             w1, NULL
    // 0xa5fad4: b.eq            #0xa5fb5c
    // 0xa5fad8: r16 = <ExtendedImageGesturePageViewState<ExtendedImageGesturePageView>>
    //     0xa5fad8: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c638] TypeArguments: <ExtendedImageGesturePageViewState<ExtendedImageGesturePageView>>
    //     0xa5fadc: ldr             x16, [x16, #0x638]
    // 0xa5fae0: stp             x1, x16, [SP, #-0x10]!
    // 0xa5fae4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xa5fae4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xa5fae8: r0 = findAncestorStateOfType()
    //     0xa5fae8: bl              #0x594348  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorStateOfType
    // 0xa5faec: add             SP, SP, #0x10
    // 0xa5faf0: mov             x2, x0
    // 0xa5faf4: ldr             x1, [fp, #0x10]
    // 0xa5faf8: StoreField: r1->field_37 = r0
    //     0xa5faf8: stur            w0, [x1, #0x37]
    //     0xa5fafc: ldurb           w16, [x1, #-1]
    //     0xa5fb00: ldurb           w17, [x0, #-1]
    //     0xa5fb04: and             x16, x17, x16, lsr #2
    //     0xa5fb08: tst             x16, HEAP, lsr #32
    //     0xa5fb0c: b.eq            #0xa5fb14
    //     0xa5fb10: bl              #0xd6826c
    // 0xa5fb14: cmp             w2, NULL
    // 0xa5fb18: b.eq            #0xa5fb40
    // 0xa5fb1c: LoadField: r0 = r1->field_f
    //     0xa5fb1c: ldur            w0, [x1, #0xf]
    // 0xa5fb20: DecompressPointer r0
    //     0xa5fb20: add             x0, x0, HEAP, lsl #32
    // 0xa5fb24: cmp             w0, NULL
    // 0xa5fb28: b.eq            #0xa5fb40
    // 0xa5fb2c: LoadField: r0 = r2->field_27
    //     0xa5fb2c: ldur            w0, [x2, #0x27]
    // 0xa5fb30: DecompressPointer r0
    //     0xa5fb30: add             x0, x0, HEAP, lsl #32
    // 0xa5fb34: stp             x1, x0, [SP, #-0x10]!
    // 0xa5fb38: r0 = add()
    //     0xa5fb38: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xa5fb3c: add             SP, SP, #0x10
    // 0xa5fb40: r0 = Null
    //     0xa5fb40: mov             x0, NULL
    // 0xa5fb44: LeaveFrame
    //     0xa5fb44: mov             SP, fp
    //     0xa5fb48: ldp             fp, lr, [SP], #0x10
    // 0xa5fb4c: ret
    //     0xa5fb4c: ret             
    // 0xa5fb50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5fb50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5fb54: b               #0xa5faa4
    // 0xa5fb58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5fb58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5fb5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5fb5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4213, size: 0x18, field offset: 0xc
//   const constructor, 
class ExtendedImageGesture extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3f294, size: 0x30
    // 0xa3f294: EnterFrame
    //     0xa3f294: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f298: mov             fp, SP
    // 0xa3f29c: r1 = <ExtendedImageGesture>
    //     0xa3f29c: add             x1, PP, #0x41, lsl #12  ; [pp+0x41028] TypeArguments: <ExtendedImageGesture>
    //     0xa3f2a0: ldr             x1, [x1, #0x28]
    // 0xa3f2a4: r0 = ExtendedImageGestureState()
    //     0xa3f2a4: bl              #0xa3f2c4  ; AllocateExtendedImageGestureStateStub -> ExtendedImageGestureState (size=0x3c)
    // 0xa3f2a8: r1 = Sentinel
    //     0xa3f2a8: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3f2ac: StoreField: r0->field_1f = r1
    //     0xa3f2ac: stur            w1, [x0, #0x1f]
    // 0xa3f2b0: StoreField: r0->field_27 = r1
    //     0xa3f2b0: stur            w1, [x0, #0x27]
    // 0xa3f2b4: StoreField: r0->field_2f = r1
    //     0xa3f2b4: stur            w1, [x0, #0x2f]
    // 0xa3f2b8: LeaveFrame
    //     0xa3f2b8: mov             SP, fp
    //     0xa3f2bc: ldp             fp, lr, [SP], #0x10
    // 0xa3f2c0: ret
    //     0xa3f2c0: ret             
  }
}

// lib: , url: package:extended_image/src/extended_image.dart

// class id: 1048931, size: 0x8
class :: {
}

// class id: 3398, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class __ExtendedImageState&State&ExtendedImageState extends State<ExtendedImage>
     with ExtendedImageState {
}

// class id: 3399, size: 0x18, field offset: 0x18
//   transformed mixin,
abstract class __ExtendedImageState&State&ExtendedImageState&WidgetsBindingObserver extends __ExtendedImageState&State&ExtendedImageState
     with WidgetsBindingObserver {
}

// class id: 3400, size: 0x44, field offset: 0x18
class _ExtendedImageState extends __ExtendedImageState&State&ExtendedImageState&WidgetsBindingObserver {

  late LoadState _loadState; // offset: 0x18
  late DisposableBuildContext<State<ExtendedImage>> _scrollAwareContext; // offset: 0x38
  late bool _invertColors; // offset: 0x28

  _ didChangeAccessibilityFeatures(/* No info */) {
    // ** addr: 0x5176ec, size: 0x60
    // 0x5176ec: EnterFrame
    //     0x5176ec: stp             fp, lr, [SP, #-0x10]!
    //     0x5176f0: mov             fp, SP
    // 0x5176f4: CheckStackOverflow
    //     0x5176f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5176f8: cmp             SP, x16
    //     0x5176fc: b.ls            #0x517744
    // 0x517700: r1 = 1
    //     0x517700: mov             x1, #1
    // 0x517704: r0 = AllocateContext()
    //     0x517704: bl              #0xd68aa4  ; AllocateContextStub
    // 0x517708: mov             x1, x0
    // 0x51770c: ldr             x0, [fp, #0x10]
    // 0x517710: StoreField: r1->field_f = r0
    //     0x517710: stur            w0, [x1, #0xf]
    // 0x517714: mov             x2, x1
    // 0x517718: r1 = Function '<anonymous closure>':.
    //     0x517718: add             x1, PP, #0x38, lsl #12  ; [pp+0x38508] AnonymousClosure: (0x517770), in [package:extended_image/src/extended_image.dart] _ExtendedImageState::didChangeAccessibilityFeatures (0x5176ec)
    //     0x51771c: ldr             x1, [x1, #0x508]
    // 0x517720: r0 = AllocateClosure()
    //     0x517720: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x517724: ldr             x16, [fp, #0x10]
    // 0x517728: stp             x0, x16, [SP, #-0x10]!
    // 0x51772c: r0 = setState()
    //     0x51772c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x517730: add             SP, SP, #0x10
    // 0x517734: r0 = Null
    //     0x517734: mov             x0, NULL
    // 0x517738: LeaveFrame
    //     0x517738: mov             SP, fp
    //     0x51773c: ldp             fp, lr, [SP], #0x10
    // 0x517740: ret
    //     0x517740: ret             
    // 0x517744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x517744: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x517748: b               #0x517700
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x517770, size: 0x4c
    // 0x517770: EnterFrame
    //     0x517770: stp             fp, lr, [SP, #-0x10]!
    //     0x517774: mov             fp, SP
    // 0x517778: ldr             x0, [fp, #0x10]
    // 0x51777c: LoadField: r1 = r0->field_17
    //     0x51777c: ldur            w1, [x0, #0x17]
    // 0x517780: DecompressPointer r1
    //     0x517780: add             x1, x1, HEAP, lsl #32
    // 0x517784: CheckStackOverflow
    //     0x517784: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x517788: cmp             SP, x16
    //     0x51778c: b.ls            #0x5177b4
    // 0x517790: LoadField: r0 = r1->field_f
    //     0x517790: ldur            w0, [x1, #0xf]
    // 0x517794: DecompressPointer r0
    //     0x517794: add             x0, x0, HEAP, lsl #32
    // 0x517798: SaveReg r0
    //     0x517798: str             x0, [SP, #-8]!
    // 0x51779c: r0 = _updateInvertColors()
    //     0x51779c: bl              #0x5177bc  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_updateInvertColors
    // 0x5177a0: add             SP, SP, #8
    // 0x5177a4: r0 = Null
    //     0x5177a4: mov             x0, NULL
    // 0x5177a8: LeaveFrame
    //     0x5177a8: mov             SP, fp
    //     0x5177ac: ldp             fp, lr, [SP], #0x10
    // 0x5177b0: ret
    //     0x5177b0: ret             
    // 0x5177b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5177b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5177b8: b               #0x517790
  }
  _ _updateInvertColors(/* No info */) {
    // ** addr: 0x5177bc, size: 0xd8
    // 0x5177bc: EnterFrame
    //     0x5177bc: stp             fp, lr, [SP, #-0x10]!
    //     0x5177c0: mov             fp, SP
    // 0x5177c4: CheckStackOverflow
    //     0x5177c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5177c8: cmp             SP, x16
    //     0x5177cc: b.ls            #0x517878
    // 0x5177d0: ldr             x0, [fp, #0x10]
    // 0x5177d4: LoadField: r1 = r0->field_f
    //     0x5177d4: ldur            w1, [x0, #0xf]
    // 0x5177d8: DecompressPointer r1
    //     0x5177d8: add             x1, x1, HEAP, lsl #32
    // 0x5177dc: cmp             w1, NULL
    // 0x5177e0: b.eq            #0x517880
    // 0x5177e4: SaveReg r1
    //     0x5177e4: str             x1, [SP, #-8]!
    // 0x5177e8: r0 = maybeOf()
    //     0x5177e8: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0x5177ec: add             SP, SP, #8
    // 0x5177f0: cmp             w0, NULL
    // 0x5177f4: b.ne            #0x517800
    // 0x5177f8: r1 = Null
    //     0x5177f8: mov             x1, NULL
    // 0x5177fc: b               #0x517808
    // 0x517800: LoadField: r1 = r0->field_37
    //     0x517800: ldur            w1, [x0, #0x37]
    // 0x517804: DecompressPointer r1
    //     0x517804: add             x1, x1, HEAP, lsl #32
    // 0x517808: cmp             w1, NULL
    // 0x51780c: b.ne            #0x51785c
    // 0x517810: r2 = 2
    //     0x517810: mov             x2, #2
    // 0x517814: r3 = LoadStaticField(0xf1c)
    //     0x517814: ldr             x3, [THR, #0x88]  ; THR::field_table_values
    //     0x517818: ldr             x3, [x3, #0x1e38]
    // 0x51781c: cmp             w3, NULL
    // 0x517820: b.eq            #0x517884
    // 0x517824: LoadField: r4 = r3->field_af
    //     0x517824: ldur            w4, [x3, #0xaf]
    // 0x517828: DecompressPointer r4
    //     0x517828: add             x4, x4, HEAP, lsl #32
    // 0x51782c: r16 = Sentinel
    //     0x51782c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x517830: cmp             w4, w16
    // 0x517834: b.eq            #0x517888
    // 0x517838: LoadField: r3 = r4->field_7
    //     0x517838: ldur            x3, [x4, #7]
    // 0x51783c: ubfx            x3, x3, #0, #0x20
    // 0x517840: and             x4, x3, x2
    // 0x517844: ubfx            x4, x4, #0, #0x20
    // 0x517848: cbnz            x4, #0x517854
    // 0x51784c: r2 = false
    //     0x51784c: add             x2, NULL, #0x30  ; false
    // 0x517850: b               #0x517858
    // 0x517854: r2 = true
    //     0x517854: add             x2, NULL, #0x20  ; true
    // 0x517858: b               #0x517860
    // 0x51785c: mov             x2, x1
    // 0x517860: ldr             x1, [fp, #0x10]
    // 0x517864: StoreField: r1->field_27 = r2
    //     0x517864: stur            w2, [x1, #0x27]
    // 0x517868: r0 = Null
    //     0x517868: mov             x0, NULL
    // 0x51786c: LeaveFrame
    //     0x51786c: mov             SP, fp
    //     0x517870: ldp             fp, lr, [SP], #0x10
    // 0x517874: ret
    //     0x517874: ret             
    // 0x517878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x517878: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51787c: b               #0x5177d0
    // 0x517880: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x517880: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x517884: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x517884: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x517888: r9 = _accessibilityFeatures
    //     0x517888: add             x9, PP, #0xd, lsl #12  ; [pp+0xdc28] Field <_WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding@423399801._accessibilityFeatures@932275577>: late (offset: 0xb0)
    //     0x51788c: ldr             x9, [x9, #0xc28]
    // 0x517890: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x517890: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ reassemble(/* No info */) {
    // ** addr: 0x7937d8, size: 0x40
    // 0x7937d8: EnterFrame
    //     0x7937d8: stp             fp, lr, [SP, #-0x10]!
    //     0x7937dc: mov             fp, SP
    // 0x7937e0: CheckStackOverflow
    //     0x7937e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7937e4: cmp             SP, x16
    //     0x7937e8: b.ls            #0x793810
    // 0x7937ec: ldr             x16, [fp, #0x10]
    // 0x7937f0: SaveReg r16
    //     0x7937f0: str             x16, [SP, #-8]!
    // 0x7937f4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7937f4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7937f8: r0 = _resolveImage()
    //     0x7937f8: bl              #0x793818  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_resolveImage
    // 0x7937fc: add             SP, SP, #8
    // 0x793800: r0 = Null
    //     0x793800: mov             x0, NULL
    // 0x793804: LeaveFrame
    //     0x793804: mov             SP, fp
    //     0x793808: ldp             fp, lr, [SP], #0x10
    // 0x79380c: ret
    //     0x79380c: ret             
    // 0x793810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x793810: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x793814: b               #0x7937ec
  }
  _ _resolveImage(/* No info */) {
    // ** addr: 0x793818, size: 0x238
    // 0x793818: EnterFrame
    //     0x793818: stp             fp, lr, [SP, #-0x10]!
    //     0x79381c: mov             fp, SP
    // 0x793820: AllocStack(0x30)
    //     0x793820: sub             SP, SP, #0x30
    // 0x793824: SetupParameters(_ExtendedImageState<ExtendedImage> this /* r1, fp-0x10 */, [dynamic _ = false /* r0, fp-0x8 */])
    //     0x793824: mov             x0, x4
    //     0x793828: ldur            w1, [x0, #0x13]
    //     0x79382c: add             x1, x1, HEAP, lsl #32
    //     0x793830: sub             x0, x1, #2
    //     0x793834: add             x1, fp, w0, sxtw #2
    //     0x793838: ldr             x1, [x1, #0x10]
    //     0x79383c: stur            x1, [fp, #-0x10]
    //     0x793840: cmp             w0, #2
    //     0x793844: b.lt            #0x793858
    //     0x793848: add             x2, fp, w0, sxtw #2
    //     0x79384c: ldr             x2, [x2, #8]
    //     0x793850: mov             x0, x2
    //     0x793854: b               #0x79385c
    //     0x793858: add             x0, NULL, #0x30  ; false
    //     0x79385c: stur            x0, [fp, #-8]
    // 0x793860: CheckStackOverflow
    //     0x793860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x793864: cmp             SP, x16
    //     0x793868: b.ls            #0x793a30
    // 0x79386c: r1 = 1
    //     0x79386c: mov             x1, #1
    // 0x793870: r0 = AllocateContext()
    //     0x793870: bl              #0xd68aa4  ; AllocateContextStub
    // 0x793874: mov             x2, x0
    // 0x793878: ldur            x1, [fp, #-0x10]
    // 0x79387c: stur            x2, [fp, #-0x18]
    // 0x793880: StoreField: r2->field_f = r1
    //     0x793880: stur            w1, [x2, #0xf]
    // 0x793884: ldur            x3, [fp, #-8]
    // 0x793888: tbnz            w3, #4, #0x7938c4
    // 0x79388c: LoadField: r0 = r1->field_b
    //     0x79388c: ldur            w0, [x1, #0xb]
    // 0x793890: DecompressPointer r0
    //     0x793890: add             x0, x0, HEAP, lsl #32
    // 0x793894: cmp             w0, NULL
    // 0x793898: b.eq            #0x793a38
    // 0x79389c: LoadField: r4 = r0->field_57
    //     0x79389c: ldur            w4, [x0, #0x57]
    // 0x7938a0: DecompressPointer r4
    //     0x7938a0: add             x4, x4, HEAP, lsl #32
    // 0x7938a4: r0 = LoadClassIdInstr(r4)
    //     0x7938a4: ldur            x0, [x4, #-1]
    //     0x7938a8: ubfx            x0, x0, #0xc, #0x14
    // 0x7938ac: SaveReg r4
    //     0x7938ac: str             x4, [SP, #-8]!
    // 0x7938b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7938b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7938b4: r0 = GDT[cid_x0 + 0x949]()
    //     0x7938b4: add             lr, x0, #0x949
    //     0x7938b8: ldr             lr, [x21, lr, lsl #3]
    //     0x7938bc: blr             lr
    // 0x7938c0: add             SP, SP, #8
    // 0x7938c4: ldur            x0, [fp, #-0x10]
    // 0x7938c8: LoadField: r2 = r0->field_37
    //     0x7938c8: ldur            w2, [x0, #0x37]
    // 0x7938cc: DecompressPointer r2
    //     0x7938cc: add             x2, x2, HEAP, lsl #32
    // 0x7938d0: r16 = Sentinel
    //     0x7938d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7938d4: cmp             w2, w16
    // 0x7938d8: b.eq            #0x793a3c
    // 0x7938dc: stur            x2, [fp, #-0x28]
    // 0x7938e0: LoadField: r1 = r0->field_b
    //     0x7938e0: ldur            w1, [x0, #0xb]
    // 0x7938e4: DecompressPointer r1
    //     0x7938e4: add             x1, x1, HEAP, lsl #32
    // 0x7938e8: cmp             w1, NULL
    // 0x7938ec: b.eq            #0x793a48
    // 0x7938f0: LoadField: r3 = r1->field_57
    //     0x7938f0: ldur            w3, [x1, #0x57]
    // 0x7938f4: DecompressPointer r3
    //     0x7938f4: add             x3, x3, HEAP, lsl #32
    // 0x7938f8: stur            x3, [fp, #-0x20]
    // 0x7938fc: r1 = <Object>
    //     0x7938fc: ldr             x1, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0x793900: r0 = ScrollAwareImageProvider()
    //     0x793900: bl              #0x794e8c  ; AllocateScrollAwareImageProviderStub -> ScrollAwareImageProvider<X0> (size=0x14)
    // 0x793904: mov             x1, x0
    // 0x793908: ldur            x0, [fp, #-0x28]
    // 0x79390c: stur            x1, [fp, #-0x30]
    // 0x793910: StoreField: r1->field_b = r0
    //     0x793910: stur            w0, [x1, #0xb]
    // 0x793914: ldur            x0, [fp, #-0x20]
    // 0x793918: StoreField: r1->field_f = r0
    //     0x793918: stur            w0, [x1, #0xf]
    // 0x79391c: ldur            x0, [fp, #-0x10]
    // 0x793920: LoadField: r2 = r0->field_f
    //     0x793920: ldur            w2, [x0, #0xf]
    // 0x793924: DecompressPointer r2
    //     0x793924: add             x2, x2, HEAP, lsl #32
    // 0x793928: cmp             w2, NULL
    // 0x79392c: b.eq            #0x793a4c
    // 0x793930: stp             NULL, x2, [SP, #-0x10]!
    // 0x793934: r4 = const [0, 0x2, 0x2, 0x1, size, 0x1, null]
    //     0x793934: add             x4, PP, #0x27, lsl #12  ; [pp+0x27e20] List(7) [0, 0x2, 0x2, 0x1, "size", 0x1, Null]
    //     0x793938: ldr             x4, [x4, #0xe20]
    // 0x79393c: r0 = createLocalImageConfiguration()
    //     0x79393c: bl              #0x6c7908  ; [package:flutter/src/widgets/image.dart] ::createLocalImageConfiguration
    // 0x793940: add             SP, SP, #0x10
    // 0x793944: ldur            x16, [fp, #-0x30]
    // 0x793948: stp             x0, x16, [SP, #-0x10]!
    // 0x79394c: r0 = resolve()
    //     0x79394c: bl              #0x7941c4  ; [package:flutter/src/painting/image_provider.dart] ImageProvider::resolve
    // 0x793950: add             SP, SP, #0x10
    // 0x793954: mov             x2, x0
    // 0x793958: ldur            x1, [fp, #-0x10]
    // 0x79395c: stur            x2, [fp, #-0x20]
    // 0x793960: LoadField: r0 = r1->field_1f
    //     0x793960: ldur            w0, [x1, #0x1f]
    // 0x793964: DecompressPointer r0
    //     0x793964: add             x0, x0, HEAP, lsl #32
    // 0x793968: cmp             w0, NULL
    // 0x79396c: b.eq            #0x793a04
    // 0x793970: ldur            x3, [fp, #-8]
    // 0x793974: tbz             w3, #4, #0x793a04
    // 0x793978: LoadField: r0 = r1->field_1b
    //     0x793978: ldur            w0, [x1, #0x1b]
    // 0x79397c: DecompressPointer r0
    //     0x79397c: add             x0, x0, HEAP, lsl #32
    // 0x793980: cmp             w0, NULL
    // 0x793984: b.ne            #0x793990
    // 0x793988: r0 = Null
    //     0x793988: mov             x0, NULL
    // 0x79398c: b               #0x7939a4
    // 0x793990: LoadField: r4 = r0->field_7
    //     0x793990: ldur            w4, [x0, #7]
    // 0x793994: DecompressPointer r4
    //     0x793994: add             x4, x4, HEAP, lsl #32
    // 0x793998: cmp             w4, NULL
    // 0x79399c: b.eq            #0x7939a4
    // 0x7939a0: mov             x0, x4
    // 0x7939a4: LoadField: r4 = r2->field_7
    //     0x7939a4: ldur            w4, [x2, #7]
    // 0x7939a8: DecompressPointer r4
    //     0x7939a8: add             x4, x4, HEAP, lsl #32
    // 0x7939ac: cmp             w4, NULL
    // 0x7939b0: b.ne            #0x7939b8
    // 0x7939b4: mov             x4, x2
    // 0x7939b8: r5 = 59
    //     0x7939b8: mov             x5, #0x3b
    // 0x7939bc: branchIfSmi(r0, 0x7939c8)
    //     0x7939bc: tbz             w0, #0, #0x7939c8
    // 0x7939c0: r5 = LoadClassIdInstr(r0)
    //     0x7939c0: ldur            x5, [x0, #-1]
    //     0x7939c4: ubfx            x5, x5, #0xc, #0x14
    // 0x7939c8: stp             x4, x0, [SP, #-0x10]!
    // 0x7939cc: mov             x0, x5
    // 0x7939d0: mov             lr, x0
    // 0x7939d4: ldr             lr, [x21, lr, lsl #3]
    // 0x7939d8: blr             lr
    // 0x7939dc: add             SP, SP, #0x10
    // 0x7939e0: tbnz            w0, #4, #0x793a04
    // 0x7939e4: ldur            x2, [fp, #-0x18]
    // 0x7939e8: r1 = Function '<anonymous closure>':.
    //     0x7939e8: add             x1, PP, #0x38, lsl #12  ; [pp+0x384b8] AnonymousClosure: (0x794e98), in [package:extended_image/src/extended_image.dart] _ExtendedImageState::_resolveImage (0x793818)
    //     0x7939ec: ldr             x1, [x1, #0x4b8]
    // 0x7939f0: r0 = AllocateClosure()
    //     0x7939f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7939f4: ldur            x16, [fp, #-0x10]
    // 0x7939f8: stp             x0, x16, [SP, #-0x10]!
    // 0x7939fc: r0 = setState()
    //     0x7939fc: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x793a00: add             SP, SP, #0x10
    // 0x793a04: ldur            x16, [fp, #-0x10]
    // 0x793a08: ldur            lr, [fp, #-0x20]
    // 0x793a0c: stp             lr, x16, [SP, #-0x10]!
    // 0x793a10: ldur            x16, [fp, #-8]
    // 0x793a14: SaveReg r16
    //     0x793a14: str             x16, [SP, #-8]!
    // 0x793a18: r0 = _updateSourceStream()
    //     0x793a18: bl              #0x793a50  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_updateSourceStream
    // 0x793a1c: add             SP, SP, #0x18
    // 0x793a20: r0 = Null
    //     0x793a20: mov             x0, NULL
    // 0x793a24: LeaveFrame
    //     0x793a24: mov             SP, fp
    //     0x793a28: ldp             fp, lr, [SP], #0x10
    // 0x793a2c: ret
    //     0x793a2c: ret             
    // 0x793a30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x793a30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x793a34: b               #0x79386c
    // 0x793a38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x793a38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x793a3c: r9 = _scrollAwareContext
    //     0x793a3c: add             x9, PP, #0x38, lsl #12  ; [pp+0x384c0] Field <_ExtendedImageState@408436062._scrollAwareContext@408436062>: late (offset: 0x38)
    //     0x793a40: ldr             x9, [x9, #0x4c0]
    // 0x793a44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x793a44: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x793a48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x793a48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x793a4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x793a4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateSourceStream(/* No info */) {
    // ** addr: 0x793a50, size: 0x1b4
    // 0x793a50: EnterFrame
    //     0x793a50: stp             fp, lr, [SP, #-0x10]!
    //     0x793a54: mov             fp, SP
    // 0x793a58: AllocStack(0x10)
    //     0x793a58: sub             SP, SP, #0x10
    // 0x793a5c: CheckStackOverflow
    //     0x793a5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x793a60: cmp             SP, x16
    //     0x793a64: b.ls            #0x793bf8
    // 0x793a68: r1 = 1
    //     0x793a68: mov             x1, #1
    // 0x793a6c: r0 = AllocateContext()
    //     0x793a6c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x793a70: mov             x2, x0
    // 0x793a74: ldr             x1, [fp, #0x20]
    // 0x793a78: stur            x2, [fp, #-8]
    // 0x793a7c: StoreField: r2->field_f = r1
    //     0x793a7c: stur            w1, [x2, #0xf]
    // 0x793a80: LoadField: r0 = r1->field_1b
    //     0x793a80: ldur            w0, [x1, #0x1b]
    // 0x793a84: DecompressPointer r0
    //     0x793a84: add             x0, x0, HEAP, lsl #32
    // 0x793a88: cmp             w0, NULL
    // 0x793a8c: b.ne            #0x793a98
    // 0x793a90: r0 = Null
    //     0x793a90: mov             x0, NULL
    // 0x793a94: b               #0x793aac
    // 0x793a98: LoadField: r3 = r0->field_7
    //     0x793a98: ldur            w3, [x0, #7]
    // 0x793a9c: DecompressPointer r3
    //     0x793a9c: add             x3, x3, HEAP, lsl #32
    // 0x793aa0: cmp             w3, NULL
    // 0x793aa4: b.eq            #0x793aac
    // 0x793aa8: mov             x0, x3
    // 0x793aac: ldr             x3, [fp, #0x18]
    // 0x793ab0: LoadField: r4 = r3->field_7
    //     0x793ab0: ldur            w4, [x3, #7]
    // 0x793ab4: DecompressPointer r4
    //     0x793ab4: add             x4, x4, HEAP, lsl #32
    // 0x793ab8: cmp             w4, NULL
    // 0x793abc: b.ne            #0x793ac4
    // 0x793ac0: mov             x4, x3
    // 0x793ac4: r5 = 59
    //     0x793ac4: mov             x5, #0x3b
    // 0x793ac8: branchIfSmi(r0, 0x793ad4)
    //     0x793ac8: tbz             w0, #0, #0x793ad4
    // 0x793acc: r5 = LoadClassIdInstr(r0)
    //     0x793acc: ldur            x5, [x0, #-1]
    //     0x793ad0: ubfx            x5, x5, #0xc, #0x14
    // 0x793ad4: stp             x4, x0, [SP, #-0x10]!
    // 0x793ad8: mov             x0, x5
    // 0x793adc: mov             lr, x0
    // 0x793ae0: ldr             lr, [x21, lr, lsl #3]
    // 0x793ae4: blr             lr
    // 0x793ae8: add             SP, SP, #0x10
    // 0x793aec: tbnz            w0, #4, #0x793b00
    // 0x793af0: r0 = Null
    //     0x793af0: mov             x0, NULL
    // 0x793af4: LeaveFrame
    //     0x793af4: mov             SP, fp
    //     0x793af8: ldp             fp, lr, [SP], #0x10
    // 0x793afc: ret
    //     0x793afc: ret             
    // 0x793b00: ldr             x0, [fp, #0x20]
    // 0x793b04: LoadField: r1 = r0->field_23
    //     0x793b04: ldur            w1, [x0, #0x23]
    // 0x793b08: DecompressPointer r1
    //     0x793b08: add             x1, x1, HEAP, lsl #32
    // 0x793b0c: tbnz            w1, #4, #0x793b44
    // 0x793b10: LoadField: r1 = r0->field_1b
    //     0x793b10: ldur            w1, [x0, #0x1b]
    // 0x793b14: DecompressPointer r1
    //     0x793b14: add             x1, x1, HEAP, lsl #32
    // 0x793b18: stur            x1, [fp, #-0x10]
    // 0x793b1c: cmp             w1, NULL
    // 0x793b20: b.eq            #0x793b44
    // 0x793b24: SaveReg r0
    //     0x793b24: str             x0, [SP, #-8]!
    // 0x793b28: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x793b28: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x793b2c: r0 = _getListener()
    //     0x793b2c: bl              #0x793f20  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_getListener
    // 0x793b30: add             SP, SP, #8
    // 0x793b34: ldur            x16, [fp, #-0x10]
    // 0x793b38: stp             x0, x16, [SP, #-0x10]!
    // 0x793b3c: r0 = removeListener()
    //     0x793b3c: bl              #0x793d7c  ; [package:flutter/src/painting/image_stream.dart] ImageStream::removeListener
    // 0x793b40: add             SP, SP, #0x10
    // 0x793b44: ldr             x0, [fp, #0x20]
    // 0x793b48: LoadField: r1 = r0->field_b
    //     0x793b48: ldur            w1, [x0, #0xb]
    // 0x793b4c: DecompressPointer r1
    //     0x793b4c: add             x1, x1, HEAP, lsl #32
    // 0x793b50: cmp             w1, NULL
    // 0x793b54: b.eq            #0x793c00
    // 0x793b58: ldur            x2, [fp, #-8]
    // 0x793b5c: r1 = Function '<anonymous closure>':.
    //     0x793b5c: add             x1, PP, #0x38, lsl #12  ; [pp+0x384c8] AnonymousClosure: (0x79409c), in [package:extended_image/src/extended_image.dart] _ExtendedImageState::_updateSourceStream (0x793a50)
    //     0x793b60: ldr             x1, [x1, #0x4c8]
    // 0x793b64: r0 = AllocateClosure()
    //     0x793b64: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x793b68: ldr             x16, [fp, #0x20]
    // 0x793b6c: stp             x0, x16, [SP, #-0x10]!
    // 0x793b70: r0 = setState()
    //     0x793b70: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x793b74: add             SP, SP, #0x10
    // 0x793b78: ldur            x2, [fp, #-8]
    // 0x793b7c: r1 = Function '<anonymous closure>':.
    //     0x793b7c: add             x1, PP, #0x38, lsl #12  ; [pp+0x384d0] AnonymousClosure: (0x794074), in [package:extended_image/src/extended_image.dart] _ExtendedImageState::_updateSourceStream (0x793a50)
    //     0x793b80: ldr             x1, [x1, #0x4d0]
    // 0x793b84: r0 = AllocateClosure()
    //     0x793b84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x793b88: ldr             x16, [fp, #0x20]
    // 0x793b8c: stp             x0, x16, [SP, #-0x10]!
    // 0x793b90: r0 = setState()
    //     0x793b90: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x793b94: add             SP, SP, #0x10
    // 0x793b98: ldr             x0, [fp, #0x18]
    // 0x793b9c: ldr             x1, [fp, #0x20]
    // 0x793ba0: StoreField: r1->field_1b = r0
    //     0x793ba0: stur            w0, [x1, #0x1b]
    //     0x793ba4: ldurb           w16, [x1, #-1]
    //     0x793ba8: ldurb           w17, [x0, #-1]
    //     0x793bac: and             x16, x17, x16, lsr #2
    //     0x793bb0: tst             x16, HEAP, lsr #32
    //     0x793bb4: b.eq            #0x793bbc
    //     0x793bb8: bl              #0xd6826c
    // 0x793bbc: LoadField: r0 = r1->field_23
    //     0x793bbc: ldur            w0, [x1, #0x23]
    // 0x793bc0: DecompressPointer r0
    //     0x793bc0: add             x0, x0, HEAP, lsl #32
    // 0x793bc4: tbnz            w0, #4, #0x793be8
    // 0x793bc8: SaveReg r1
    //     0x793bc8: str             x1, [SP, #-8]!
    // 0x793bcc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x793bcc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x793bd0: r0 = _getListener()
    //     0x793bd0: bl              #0x793f20  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_getListener
    // 0x793bd4: add             SP, SP, #8
    // 0x793bd8: ldr             x16, [fp, #0x18]
    // 0x793bdc: stp             x0, x16, [SP, #-0x10]!
    // 0x793be0: r0 = addListener()
    //     0x793be0: bl              #0x793c04  ; [package:flutter/src/painting/image_stream.dart] ImageStream::addListener
    // 0x793be4: add             SP, SP, #0x10
    // 0x793be8: r0 = Null
    //     0x793be8: mov             x0, NULL
    // 0x793bec: LeaveFrame
    //     0x793bec: mov             SP, fp
    //     0x793bf0: ldp             fp, lr, [SP], #0x10
    // 0x793bf4: ret
    //     0x793bf4: ret             
    // 0x793bf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x793bf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x793bfc: b               #0x793a68
    // 0x793c00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x793c00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getListener(/* No info */) {
    // ** addr: 0x793f20, size: 0x148
    // 0x793f20: EnterFrame
    //     0x793f20: stp             fp, lr, [SP, #-0x10]!
    //     0x793f24: mov             fp, SP
    // 0x793f28: AllocStack(0x18)
    //     0x793f28: sub             SP, SP, #0x18
    // 0x793f2c: SetupParameters(_ExtendedImageState<ExtendedImage> this /* r3, fp-0x8 */, {dynamic recreateListener = false /* r0 */})
    //     0x793f2c: mov             x0, x4
    //     0x793f30: ldur            w1, [x0, #0x13]
    //     0x793f34: add             x1, x1, HEAP, lsl #32
    //     0x793f38: sub             x2, x1, #2
    //     0x793f3c: add             x3, fp, w2, sxtw #2
    //     0x793f40: ldr             x3, [x3, #0x10]
    //     0x793f44: stur            x3, [fp, #-8]
    //     0x793f48: ldur            w2, [x0, #0x1f]
    //     0x793f4c: add             x2, x2, HEAP, lsl #32
    //     0x793f50: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e60] "recreateListener"
    //     0x793f54: ldr             x16, [x16, #0xe60]
    //     0x793f58: cmp             w2, w16
    //     0x793f5c: b.ne            #0x793f7c
    //     0x793f60: ldur            w2, [x0, #0x23]
    //     0x793f64: add             x2, x2, HEAP, lsl #32
    //     0x793f68: sub             w0, w1, w2
    //     0x793f6c: add             x1, fp, w0, sxtw #2
    //     0x793f70: ldr             x1, [x1, #8]
    //     0x793f74: mov             x0, x1
    //     0x793f78: b               #0x793f80
    //     0x793f7c: add             x0, NULL, #0x30  ; false
    // 0x793f80: CheckStackOverflow
    //     0x793f80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x793f84: cmp             SP, x16
    //     0x793f88: b.ls            #0x79405c
    // 0x793f8c: LoadField: r1 = r3->field_3f
    //     0x793f8c: ldur            w1, [x3, #0x3f]
    // 0x793f90: DecompressPointer r1
    //     0x793f90: add             x1, x1, HEAP, lsl #32
    // 0x793f94: cmp             w1, NULL
    // 0x793f98: b.eq            #0x793fa0
    // 0x793f9c: tbnz            w0, #4, #0x79404c
    // 0x793fa0: r0 = 59
    //     0x793fa0: mov             x0, #0x3b
    // 0x793fa4: branchIfSmi(r3, 0x793fb0)
    //     0x793fa4: tbz             w3, #0, #0x793fb0
    // 0x793fa8: r0 = LoadClassIdInstr(r3)
    //     0x793fa8: ldur            x0, [x3, #-1]
    //     0x793fac: ubfx            x0, x0, #0xc, #0x14
    // 0x793fb0: SaveReg r3
    //     0x793fb0: str             x3, [SP, #-8]!
    // 0x793fb4: r0 = GDT[cid_x0 + -0xf84]()
    //     0x793fb4: sub             lr, x0, #0xf84
    //     0x793fb8: ldr             lr, [x21, lr, lsl #3]
    //     0x793fbc: blr             lr
    // 0x793fc0: add             SP, SP, #8
    // 0x793fc4: mov             x2, x0
    // 0x793fc8: ldur            x1, [fp, #-8]
    // 0x793fcc: stur            x2, [fp, #-0x10]
    // 0x793fd0: LoadField: r0 = r1->field_b
    //     0x793fd0: ldur            w0, [x1, #0xb]
    // 0x793fd4: DecompressPointer r0
    //     0x793fd4: add             x0, x0, HEAP, lsl #32
    // 0x793fd8: cmp             w0, NULL
    // 0x793fdc: b.eq            #0x794064
    // 0x793fe0: r0 = 59
    //     0x793fe0: mov             x0, #0x3b
    // 0x793fe4: branchIfSmi(r1, 0x793ff0)
    //     0x793fe4: tbz             w1, #0, #0x793ff0
    // 0x793fe8: r0 = LoadClassIdInstr(r1)
    //     0x793fe8: ldur            x0, [x1, #-1]
    //     0x793fec: ubfx            x0, x0, #0xc, #0x14
    // 0x793ff0: SaveReg r1
    //     0x793ff0: str             x1, [SP, #-8]!
    // 0x793ff4: r0 = GDT[cid_x0 + -0xf83]()
    //     0x793ff4: sub             lr, x0, #0xf83
    //     0x793ff8: ldr             lr, [x21, lr, lsl #3]
    //     0x793ffc: blr             lr
    // 0x794000: add             SP, SP, #8
    // 0x794004: stur            x0, [fp, #-0x18]
    // 0x794008: r0 = ImageStreamListener()
    //     0x794008: bl              #0x794068  ; AllocateImageStreamListenerStub -> ImageStreamListener (size=0x14)
    // 0x79400c: mov             x1, x0
    // 0x794010: ldur            x2, [fp, #-0x10]
    // 0x794014: StoreField: r1->field_7 = r2
    //     0x794014: stur            w2, [x1, #7]
    // 0x794018: ldur            x2, [fp, #-0x18]
    // 0x79401c: StoreField: r1->field_f = r2
    //     0x79401c: stur            w2, [x1, #0xf]
    // 0x794020: mov             x0, x1
    // 0x794024: ldur            x2, [fp, #-8]
    // 0x794028: StoreField: r2->field_3f = r0
    //     0x794028: stur            w0, [x2, #0x3f]
    //     0x79402c: ldurb           w16, [x2, #-1]
    //     0x794030: ldurb           w17, [x0, #-1]
    //     0x794034: and             x16, x17, x16, lsr #2
    //     0x794038: tst             x16, HEAP, lsr #32
    //     0x79403c: b.eq            #0x794044
    //     0x794040: bl              #0xd6828c
    // 0x794044: mov             x0, x1
    // 0x794048: b               #0x794050
    // 0x79404c: mov             x0, x1
    // 0x794050: LeaveFrame
    //     0x794050: mov             SP, fp
    //     0x794054: ldp             fp, lr, [SP], #0x10
    // 0x794058: ret
    //     0x794058: ret             
    // 0x79405c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79405c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794060: b               #0x793f8c
    // 0x794064: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x794064: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x794074, size: 0x28
    // 0x794074: r1 = false
    //     0x794074: add             x1, NULL, #0x30  ; false
    // 0x794078: ldr             x2, [SP]
    // 0x79407c: LoadField: r3 = r2->field_17
    //     0x79407c: ldur            w3, [x2, #0x17]
    // 0x794080: DecompressPointer r3
    //     0x794080: add             x3, x3, HEAP, lsl #32
    // 0x794084: LoadField: r2 = r3->field_f
    //     0x794084: ldur            w2, [x3, #0xf]
    // 0x794088: DecompressPointer r2
    //     0x794088: add             x2, x2, HEAP, lsl #32
    // 0x79408c: StoreField: r2->field_2f = rNULL
    //     0x79408c: stur            NULL, [x2, #0x2f]
    // 0x794090: StoreField: r2->field_33 = r1
    //     0x794090: stur            w1, [x2, #0x33]
    // 0x794094: r0 = Null
    //     0x794094: mov             x0, NULL
    // 0x794098: ret
    //     0x794098: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x79409c, size: 0x6c
    // 0x79409c: EnterFrame
    //     0x79409c: stp             fp, lr, [SP, #-0x10]!
    //     0x7940a0: mov             fp, SP
    // 0x7940a4: AllocStack(0x8)
    //     0x7940a4: sub             SP, SP, #8
    // 0x7940a8: SetupParameters()
    //     0x7940a8: ldr             x0, [fp, #0x10]
    //     0x7940ac: ldur            w1, [x0, #0x17]
    //     0x7940b0: add             x1, x1, HEAP, lsl #32
    //     0x7940b4: stur            x1, [fp, #-8]
    // 0x7940b8: CheckStackOverflow
    //     0x7940b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7940bc: cmp             SP, x16
    //     0x7940c0: b.ls            #0x794100
    // 0x7940c4: LoadField: r0 = r1->field_f
    //     0x7940c4: ldur            w0, [x1, #0xf]
    // 0x7940c8: DecompressPointer r0
    //     0x7940c8: add             x0, x0, HEAP, lsl #32
    // 0x7940cc: stp             NULL, x0, [SP, #-0x10]!
    // 0x7940d0: r0 = _replaceImage()
    //     0x7940d0: bl              #0x794108  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_replaceImage
    // 0x7940d4: add             SP, SP, #0x10
    // 0x7940d8: ldur            x1, [fp, #-8]
    // 0x7940dc: LoadField: r2 = r1->field_f
    //     0x7940dc: ldur            w2, [x1, #0xf]
    // 0x7940e0: DecompressPointer r2
    //     0x7940e0: add             x2, x2, HEAP, lsl #32
    // 0x7940e4: r1 = Instance_LoadState
    //     0x7940e4: add             x1, PP, #0x27, lsl #12  ; [pp+0x27c58] Obj!LoadState@b66071
    //     0x7940e8: ldr             x1, [x1, #0xc58]
    // 0x7940ec: StoreField: r2->field_17 = r1
    //     0x7940ec: stur            w1, [x2, #0x17]
    // 0x7940f0: r0 = Null
    //     0x7940f0: mov             x0, NULL
    // 0x7940f4: LeaveFrame
    //     0x7940f4: mov             SP, fp
    //     0x7940f8: ldp             fp, lr, [SP], #0x10
    // 0x7940fc: ret
    //     0x7940fc: ret             
    // 0x794100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794100: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794104: b               #0x7940c4
  }
  _ _replaceImage(/* No info */) {
    // ** addr: 0x794108, size: 0x78
    // 0x794108: EnterFrame
    //     0x794108: stp             fp, lr, [SP, #-0x10]!
    //     0x79410c: mov             fp, SP
    // 0x794110: CheckStackOverflow
    //     0x794110: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x794114: cmp             SP, x16
    //     0x794118: b.ls            #0x794178
    // 0x79411c: ldr             x0, [fp, #0x18]
    // 0x794120: LoadField: r1 = r0->field_1f
    //     0x794120: ldur            w1, [x0, #0x1f]
    // 0x794124: DecompressPointer r1
    //     0x794124: add             x1, x1, HEAP, lsl #32
    // 0x794128: cmp             w1, NULL
    // 0x79412c: b.ne            #0x794138
    // 0x794130: mov             x1, x0
    // 0x794134: b               #0x794148
    // 0x794138: SaveReg r1
    //     0x794138: str             x1, [SP, #-8]!
    // 0x79413c: r0 = dispose()
    //     0x79413c: bl              #0x794180  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0x794140: add             SP, SP, #8
    // 0x794144: ldr             x1, [fp, #0x18]
    // 0x794148: ldr             x0, [fp, #0x10]
    // 0x79414c: StoreField: r1->field_1f = r0
    //     0x79414c: stur            w0, [x1, #0x1f]
    //     0x794150: ldurb           w16, [x1, #-1]
    //     0x794154: ldurb           w17, [x0, #-1]
    //     0x794158: and             x16, x17, x16, lsr #2
    //     0x79415c: tst             x16, HEAP, lsr #32
    //     0x794160: b.eq            #0x794168
    //     0x794164: bl              #0xd6826c
    // 0x794168: r0 = Null
    //     0x794168: mov             x0, NULL
    // 0x79416c: LeaveFrame
    //     0x79416c: mov             SP, fp
    //     0x794170: ldp             fp, lr, [SP], #0x10
    // 0x794174: ret
    //     0x794174: ret             
    // 0x794178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794178: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79417c: b               #0x79411c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x794e98, size: 0x28
    // 0x794e98: r1 = Instance_LoadState
    //     0x794e98: add             x1, PP, #0x27, lsl #12  ; [pp+0x27c78] Obj!LoadState@b66091
    //     0x794e9c: ldr             x1, [x1, #0xc78]
    // 0x794ea0: ldr             x2, [SP]
    // 0x794ea4: LoadField: r3 = r2->field_17
    //     0x794ea4: ldur            w3, [x2, #0x17]
    // 0x794ea8: DecompressPointer r3
    //     0x794ea8: add             x3, x3, HEAP, lsl #32
    // 0x794eac: LoadField: r2 = r3->field_f
    //     0x794eac: ldur            w2, [x3, #0xf]
    // 0x794eb0: DecompressPointer r2
    //     0x794eb0: add             x2, x2, HEAP, lsl #32
    // 0x794eb4: StoreField: r2->field_17 = r1
    //     0x794eb4: stur            w1, [x2, #0x17]
    // 0x794eb8: r0 = Null
    //     0x794eb8: mov             x0, NULL
    // 0x794ebc: ret
    //     0x794ebc: ret             
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x79b38c, size: 0x13c
    // 0x79b38c: EnterFrame
    //     0x79b38c: stp             fp, lr, [SP, #-0x10]!
    //     0x79b390: mov             fp, SP
    // 0x79b394: CheckStackOverflow
    //     0x79b394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79b398: cmp             SP, x16
    //     0x79b39c: b.ls            #0x79b4b4
    // 0x79b3a0: ldr             x0, [fp, #0x10]
    // 0x79b3a4: r2 = Null
    //     0x79b3a4: mov             x2, NULL
    // 0x79b3a8: r1 = Null
    //     0x79b3a8: mov             x1, NULL
    // 0x79b3ac: r4 = 59
    //     0x79b3ac: mov             x4, #0x3b
    // 0x79b3b0: branchIfSmi(r0, 0x79b3bc)
    //     0x79b3b0: tbz             w0, #0, #0x79b3bc
    // 0x79b3b4: r4 = LoadClassIdInstr(r0)
    //     0x79b3b4: ldur            x4, [x0, #-1]
    //     0x79b3b8: ubfx            x4, x4, #0xc, #0x14
    // 0x79b3bc: r17 = 4214
    //     0x79b3bc: mov             x17, #0x1076
    // 0x79b3c0: cmp             x4, x17
    // 0x79b3c4: b.eq            #0x79b3dc
    // 0x79b3c8: r8 = ExtendedImage
    //     0x79b3c8: add             x8, PP, #0x38, lsl #12  ; [pp+0x384e0] Type: ExtendedImage
    //     0x79b3cc: ldr             x8, [x8, #0x4e0]
    // 0x79b3d0: r3 = Null
    //     0x79b3d0: add             x3, PP, #0x38, lsl #12  ; [pp+0x384e8] Null
    //     0x79b3d4: ldr             x3, [x3, #0x4e8]
    // 0x79b3d8: r0 = ExtendedImage()
    //     0x79b3d8: bl              #0x51774c  ; IsType_ExtendedImage_Stub
    // 0x79b3dc: ldr             x3, [fp, #0x18]
    // 0x79b3e0: LoadField: r2 = r3->field_7
    //     0x79b3e0: ldur            w2, [x3, #7]
    // 0x79b3e4: DecompressPointer r2
    //     0x79b3e4: add             x2, x2, HEAP, lsl #32
    // 0x79b3e8: ldr             x0, [fp, #0x10]
    // 0x79b3ec: r1 = Null
    //     0x79b3ec: mov             x1, NULL
    // 0x79b3f0: cmp             w2, NULL
    // 0x79b3f4: b.eq            #0x79b418
    // 0x79b3f8: LoadField: r4 = r2->field_17
    //     0x79b3f8: ldur            w4, [x2, #0x17]
    // 0x79b3fc: DecompressPointer r4
    //     0x79b3fc: add             x4, x4, HEAP, lsl #32
    // 0x79b400: r8 = X0 bound StatefulWidget
    //     0x79b400: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x79b404: ldr             x8, [x8, #0x858]
    // 0x79b408: LoadField: r9 = r4->field_7
    //     0x79b408: ldur            x9, [x4, #7]
    // 0x79b40c: r3 = Null
    //     0x79b40c: add             x3, PP, #0x38, lsl #12  ; [pp+0x384f8] Null
    //     0x79b410: ldr             x3, [x3, #0x4f8]
    // 0x79b414: blr             x9
    // 0x79b418: ldr             x1, [fp, #0x18]
    // 0x79b41c: LoadField: r0 = r1->field_23
    //     0x79b41c: ldur            w0, [x1, #0x23]
    // 0x79b420: DecompressPointer r0
    //     0x79b420: add             x0, x0, HEAP, lsl #32
    // 0x79b424: tbnz            w0, #4, #0x79b438
    // 0x79b428: LoadField: r0 = r1->field_b
    //     0x79b428: ldur            w0, [x1, #0xb]
    // 0x79b42c: DecompressPointer r0
    //     0x79b42c: add             x0, x0, HEAP, lsl #32
    // 0x79b430: cmp             w0, NULL
    // 0x79b434: b.eq            #0x79b4bc
    // 0x79b438: ldr             x0, [fp, #0x10]
    // 0x79b43c: LoadField: r2 = r1->field_b
    //     0x79b43c: ldur            w2, [x1, #0xb]
    // 0x79b440: DecompressPointer r2
    //     0x79b440: add             x2, x2, HEAP, lsl #32
    // 0x79b444: cmp             w2, NULL
    // 0x79b448: b.eq            #0x79b4c0
    // 0x79b44c: LoadField: r3 = r2->field_57
    //     0x79b44c: ldur            w3, [x2, #0x57]
    // 0x79b450: DecompressPointer r3
    //     0x79b450: add             x3, x3, HEAP, lsl #32
    // 0x79b454: LoadField: r2 = r0->field_57
    //     0x79b454: ldur            w2, [x0, #0x57]
    // 0x79b458: DecompressPointer r2
    //     0x79b458: add             x2, x2, HEAP, lsl #32
    // 0x79b45c: r0 = LoadClassIdInstr(r3)
    //     0x79b45c: ldur            x0, [x3, #-1]
    //     0x79b460: ubfx            x0, x0, #0xc, #0x14
    // 0x79b464: stp             x2, x3, [SP, #-0x10]!
    // 0x79b468: mov             lr, x0
    // 0x79b46c: ldr             lr, [x21, lr, lsl #3]
    // 0x79b470: blr             lr
    // 0x79b474: add             SP, SP, #0x10
    // 0x79b478: tbz             w0, #4, #0x79b490
    // 0x79b47c: ldr             x16, [fp, #0x18]
    // 0x79b480: SaveReg r16
    //     0x79b480: str             x16, [SP, #-8]!
    // 0x79b484: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x79b484: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x79b488: r0 = _resolveImage()
    //     0x79b488: bl              #0x793818  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_resolveImage
    // 0x79b48c: add             SP, SP, #8
    // 0x79b490: ldr             x1, [fp, #0x18]
    // 0x79b494: LoadField: r2 = r1->field_b
    //     0x79b494: ldur            w2, [x1, #0xb]
    // 0x79b498: DecompressPointer r2
    //     0x79b498: add             x2, x2, HEAP, lsl #32
    // 0x79b49c: cmp             w2, NULL
    // 0x79b4a0: b.eq            #0x79b4c4
    // 0x79b4a4: r0 = Null
    //     0x79b4a4: mov             x0, NULL
    // 0x79b4a8: LeaveFrame
    //     0x79b4a8: mov             SP, fp
    //     0x79b4ac: ldp             fp, lr, [SP], #0x10
    // 0x79b4b0: ret
    //     0x79b4b0: ret             
    // 0x79b4b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79b4b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79b4b8: b               #0x79b3a0
    // 0x79b4bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b4bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79b4c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b4c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79b4c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79b4c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x82c258, size: 0x188
    // 0x82c258: EnterFrame
    //     0x82c258: stp             fp, lr, [SP, #-0x10]!
    //     0x82c25c: mov             fp, SP
    // 0x82c260: AllocStack(0x10)
    //     0x82c260: sub             SP, SP, #0x10
    // 0x82c264: r0 = false
    //     0x82c264: add             x0, NULL, #0x30  ; false
    // 0x82c268: CheckStackOverflow
    //     0x82c268: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82c26c: cmp             SP, x16
    //     0x82c270: b.ls            #0x82c3c0
    // 0x82c274: ldr             x1, [fp, #0x18]
    // 0x82c278: StoreField: r1->field_13 = r0
    //     0x82c278: stur            w0, [x1, #0x13]
    // 0x82c27c: LoadField: r0 = r1->field_b
    //     0x82c27c: ldur            w0, [x1, #0xb]
    // 0x82c280: DecompressPointer r0
    //     0x82c280: add             x0, x0, HEAP, lsl #32
    // 0x82c284: cmp             w0, NULL
    // 0x82c288: b.eq            #0x82c3c8
    // 0x82c28c: LoadField: r2 = r0->field_53
    //     0x82c28c: ldur            w2, [x0, #0x53]
    // 0x82c290: DecompressPointer r2
    //     0x82c290: add             x2, x2, HEAP, lsl #32
    // 0x82c294: cmp             w2, NULL
    // 0x82c298: b.eq            #0x82c2b8
    // 0x82c29c: stp             x1, x2, [SP, #-0x10]!
    // 0x82c2a0: mov             x0, x2
    // 0x82c2a4: ClosureCall
    //     0x82c2a4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x82c2a8: ldur            x2, [x0, #0x1f]
    //     0x82c2ac: blr             x2
    // 0x82c2b0: add             SP, SP, #0x10
    // 0x82c2b4: b               #0x82c2bc
    // 0x82c2b8: r0 = Null
    //     0x82c2b8: mov             x0, NULL
    // 0x82c2bc: cmp             w0, NULL
    // 0x82c2c0: b.ne            #0x82c324
    // 0x82c2c4: ldr             x0, [fp, #0x18]
    // 0x82c2c8: LoadField: r1 = r0->field_b
    //     0x82c2c8: ldur            w1, [x0, #0xb]
    // 0x82c2cc: DecompressPointer r1
    //     0x82c2cc: add             x1, x1, HEAP, lsl #32
    // 0x82c2d0: cmp             w1, NULL
    // 0x82c2d4: b.eq            #0x82c3cc
    // 0x82c2d8: LoadField: r1 = r0->field_17
    //     0x82c2d8: ldur            w1, [x0, #0x17]
    // 0x82c2dc: DecompressPointer r1
    //     0x82c2dc: add             x1, x1, HEAP, lsl #32
    // 0x82c2e0: r16 = Sentinel
    //     0x82c2e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82c2e4: cmp             w1, w16
    // 0x82c2e8: b.eq            #0x82c3d0
    // 0x82c2ec: r16 = Instance_LoadState
    //     0x82c2ec: add             x16, PP, #0x27, lsl #12  ; [pp+0x27c78] Obj!LoadState@b66091
    //     0x82c2f0: ldr             x16, [x16, #0xc78]
    // 0x82c2f4: cmp             w1, w16
    // 0x82c2f8: b.ne            #0x82c30c
    // 0x82c2fc: SaveReg r0
    //     0x82c2fc: str             x0, [SP, #-8]!
    // 0x82c300: r0 = _getCompletedWidget()
    //     0x82c300: bl              #0x82c56c  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_getCompletedWidget
    // 0x82c304: add             SP, SP, #8
    // 0x82c308: b               #0x82c31c
    // 0x82c30c: ldr             x16, [fp, #0x18]
    // 0x82c310: SaveReg r16
    //     0x82c310: str             x16, [SP, #-8]!
    // 0x82c314: r0 = _buildExtendedRawImage()
    //     0x82c314: bl              #0x82c3ec  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_buildExtendedRawImage
    // 0x82c318: add             SP, SP, #8
    // 0x82c31c: mov             x1, x0
    // 0x82c320: b               #0x82c328
    // 0x82c324: mov             x1, x0
    // 0x82c328: ldr             x0, [fp, #0x18]
    // 0x82c32c: stur            x1, [fp, #-0x10]
    // 0x82c330: LoadField: r2 = r0->field_b
    //     0x82c330: ldur            w2, [x0, #0xb]
    // 0x82c334: DecompressPointer r2
    //     0x82c334: add             x2, x2, HEAP, lsl #32
    // 0x82c338: cmp             w2, NULL
    // 0x82c33c: b.eq            #0x82c3dc
    // 0x82c340: LoadField: r0 = r2->field_63
    //     0x82c340: ldur            w0, [x2, #0x63]
    // 0x82c344: DecompressPointer r0
    //     0x82c344: add             x0, x0, HEAP, lsl #32
    // 0x82c348: stur            x0, [fp, #-8]
    // 0x82c34c: cmp             w0, NULL
    // 0x82c350: b.eq            #0x82c374
    // 0x82c354: r0 = ConstrainedBox()
    //     0x82c354: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x82c358: mov             x1, x0
    // 0x82c35c: ldur            x0, [fp, #-8]
    // 0x82c360: StoreField: r1->field_f = r0
    //     0x82c360: stur            w0, [x1, #0xf]
    // 0x82c364: ldur            x0, [fp, #-0x10]
    // 0x82c368: StoreField: r1->field_b = r0
    //     0x82c368: stur            w0, [x1, #0xb]
    // 0x82c36c: mov             x0, x1
    // 0x82c370: b               #0x82c378
    // 0x82c374: mov             x0, x1
    // 0x82c378: stur            x0, [fp, #-8]
    // 0x82c37c: r0 = Semantics()
    //     0x82c37c: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x82c380: stur            x0, [fp, #-0x10]
    // 0x82c384: r16 = false
    //     0x82c384: add             x16, NULL, #0x30  ; false
    // 0x82c388: stp             x16, x0, [SP, #-0x10]!
    // 0x82c38c: r16 = true
    //     0x82c38c: add             x16, NULL, #0x20  ; true
    // 0x82c390: r30 = ""
    //     0x82c390: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x82c394: stp             lr, x16, [SP, #-0x10]!
    // 0x82c398: ldur            x16, [fp, #-8]
    // 0x82c39c: SaveReg r16
    //     0x82c39c: str             x16, [SP, #-8]!
    // 0x82c3a0: r4 = const [0, 0x5, 0x5, 0x1, child, 0x4, container, 0x1, image, 0x2, label, 0x3, null]
    //     0x82c3a0: add             x4, PP, #0x27, lsl #12  ; [pp+0x27e10] List(13) [0, 0x5, 0x5, 0x1, "child", 0x4, "container", 0x1, "image", 0x2, "label", 0x3, Null]
    //     0x82c3a4: ldr             x4, [x4, #0xe10]
    // 0x82c3a8: r0 = Semantics()
    //     0x82c3a8: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x82c3ac: add             SP, SP, #0x28
    // 0x82c3b0: ldur            x0, [fp, #-0x10]
    // 0x82c3b4: LeaveFrame
    //     0x82c3b4: mov             SP, fp
    //     0x82c3b8: ldp             fp, lr, [SP], #0x10
    // 0x82c3bc: ret
    //     0x82c3bc: ret             
    // 0x82c3c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c3c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c3c4: b               #0x82c274
    // 0x82c3c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c3c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c3cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c3cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c3d0: r9 = _loadState
    //     0x82c3d0: add             x9, PP, #0x27, lsl #12  ; [pp+0x27c60] Field <_ExtendedImageState@408436062._loadState@408436062>: late (offset: 0x18)
    //     0x82c3d4: ldr             x9, [x9, #0xc60]
    // 0x82c3d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82c3d8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x82c3dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c3dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildExtendedRawImage(/* No info */) {
    // ** addr: 0x82c3ec, size: 0x180
    // 0x82c3ec: EnterFrame
    //     0x82c3ec: stp             fp, lr, [SP, #-0x10]!
    //     0x82c3f0: mov             fp, SP
    // 0x82c3f4: AllocStack(0x28)
    //     0x82c3f4: sub             SP, SP, #0x28
    // 0x82c3f8: ldr             x0, [fp, #0x10]
    // 0x82c3fc: LoadField: r1 = r0->field_1f
    //     0x82c3fc: ldur            w1, [x0, #0x1f]
    // 0x82c400: DecompressPointer r1
    //     0x82c400: add             x1, x1, HEAP, lsl #32
    // 0x82c404: cmp             w1, NULL
    // 0x82c408: b.ne            #0x82c414
    // 0x82c40c: r2 = Null
    //     0x82c40c: mov             x2, NULL
    // 0x82c410: b               #0x82c41c
    // 0x82c414: LoadField: r2 = r1->field_7
    //     0x82c414: ldur            w2, [x1, #7]
    // 0x82c418: DecompressPointer r2
    //     0x82c418: add             x2, x2, HEAP, lsl #32
    // 0x82c41c: stur            x2, [fp, #-0x20]
    // 0x82c420: cmp             w1, NULL
    // 0x82c424: b.ne            #0x82c430
    // 0x82c428: r3 = Null
    //     0x82c428: mov             x3, NULL
    // 0x82c42c: b               #0x82c438
    // 0x82c430: LoadField: r3 = r1->field_13
    //     0x82c430: ldur            w3, [x1, #0x13]
    // 0x82c434: DecompressPointer r3
    //     0x82c434: add             x3, x3, HEAP, lsl #32
    // 0x82c438: stur            x3, [fp, #-0x18]
    // 0x82c43c: LoadField: r4 = r0->field_b
    //     0x82c43c: ldur            w4, [x0, #0xb]
    // 0x82c440: DecompressPointer r4
    //     0x82c440: add             x4, x4, HEAP, lsl #32
    // 0x82c444: cmp             w4, NULL
    // 0x82c448: b.eq            #0x82c538
    // 0x82c44c: cmp             w1, NULL
    // 0x82c450: b.ne            #0x82c45c
    // 0x82c454: r1 = Null
    //     0x82c454: mov             x1, NULL
    // 0x82c458: b               #0x82c488
    // 0x82c45c: LoadField: d0 = r1->field_b
    //     0x82c45c: ldur            d0, [x1, #0xb]
    // 0x82c460: r1 = inline_Allocate_Double()
    //     0x82c460: ldp             x1, x5, [THR, #0x60]  ; THR::top
    //     0x82c464: add             x1, x1, #0x10
    //     0x82c468: cmp             x5, x1
    //     0x82c46c: b.ls            #0x82c53c
    //     0x82c470: str             x1, [THR, #0x60]  ; THR::top
    //     0x82c474: sub             x1, x1, #0xf
    //     0x82c478: mov             x5, #0xd108
    //     0x82c47c: movk            x5, #3, lsl #16
    //     0x82c480: stur            x5, [x1, #-1]
    // 0x82c484: StoreField: r1->field_7 = d0
    //     0x82c484: stur            d0, [x1, #7]
    // 0x82c488: cmp             w1, NULL
    // 0x82c48c: b.ne            #0x82c498
    // 0x82c490: d0 = 1.000000
    //     0x82c490: fmov            d0, #1.00000000
    // 0x82c494: b               #0x82c49c
    // 0x82c498: LoadField: d0 = r1->field_7
    //     0x82c498: ldur            d0, [x1, #7]
    // 0x82c49c: stur            d0, [fp, #-0x28]
    // 0x82c4a0: LoadField: r1 = r4->field_77
    //     0x82c4a0: ldur            w1, [x4, #0x77]
    // 0x82c4a4: DecompressPointer r1
    //     0x82c4a4: add             x1, x1, HEAP, lsl #32
    // 0x82c4a8: stur            x1, [fp, #-0x10]
    // 0x82c4ac: LoadField: r4 = r0->field_27
    //     0x82c4ac: ldur            w4, [x0, #0x27]
    // 0x82c4b0: DecompressPointer r4
    //     0x82c4b0: add             x4, x4, HEAP, lsl #32
    // 0x82c4b4: r16 = Sentinel
    //     0x82c4b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82c4b8: cmp             w4, w16
    // 0x82c4bc: b.eq            #0x82c560
    // 0x82c4c0: stur            x4, [fp, #-8]
    // 0x82c4c4: r0 = ExtendedRawImage()
    //     0x82c4c4: bl              #0x82af6c  ; AllocateExtendedRawImageStub -> ExtendedRawImage (size=0x68)
    // 0x82c4c8: ldur            x1, [fp, #-0x20]
    // 0x82c4cc: StoreField: r0->field_1f = r1
    //     0x82c4cc: stur            w1, [x0, #0x1f]
    // 0x82c4d0: ldur            d0, [fp, #-0x28]
    // 0x82c4d4: StoreField: r0->field_2b = d0
    //     0x82c4d4: stur            d0, [x0, #0x2b]
    // 0x82c4d8: ldur            x1, [fp, #-0x10]
    // 0x82c4dc: StoreField: r0->field_43 = r1
    //     0x82c4dc: stur            w1, [x0, #0x43]
    // 0x82c4e0: r1 = Instance_Alignment
    //     0x82c4e0: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x82c4e4: ldr             x1, [x1, #0xc70]
    // 0x82c4e8: StoreField: r0->field_47 = r1
    //     0x82c4e8: stur            w1, [x0, #0x47]
    // 0x82c4ec: r1 = Instance_ImageRepeat
    //     0x82c4ec: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0x82c4f0: ldr             x1, [x1, #0x540]
    // 0x82c4f4: StoreField: r0->field_4b = r1
    //     0x82c4f4: stur            w1, [x0, #0x4b]
    // 0x82c4f8: r1 = false
    //     0x82c4f8: add             x1, NULL, #0x30  ; false
    // 0x82c4fc: StoreField: r0->field_53 = r1
    //     0x82c4fc: stur            w1, [x0, #0x53]
    // 0x82c500: ldur            x2, [fp, #-8]
    // 0x82c504: StoreField: r0->field_57 = r2
    //     0x82c504: stur            w2, [x0, #0x57]
    // 0x82c508: r2 = Instance_FilterQuality
    //     0x82c508: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0x82c50c: ldr             x2, [x2, #0x548]
    // 0x82c510: StoreField: r0->field_3b = r2
    //     0x82c510: stur            w2, [x0, #0x3b]
    // 0x82c514: StoreField: r0->field_b = r1
    //     0x82c514: stur            w1, [x0, #0xb]
    // 0x82c518: ldur            x1, [fp, #-0x18]
    // 0x82c51c: StoreField: r0->field_5f = r1
    //     0x82c51c: stur            w1, [x0, #0x5f]
    // 0x82c520: r1 = Instance_EdgeInsets
    //     0x82c520: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x82c524: ldr             x1, [x1, #0xbd8]
    // 0x82c528: StoreField: r0->field_63 = r1
    //     0x82c528: stur            w1, [x0, #0x63]
    // 0x82c52c: LeaveFrame
    //     0x82c52c: mov             SP, fp
    //     0x82c530: ldp             fp, lr, [SP], #0x10
    // 0x82c534: ret
    //     0x82c534: ret             
    // 0x82c538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c538: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c53c: SaveReg d0
    //     0x82c53c: str             q0, [SP, #-0x10]!
    // 0x82c540: stp             x3, x4, [SP, #-0x10]!
    // 0x82c544: stp             x0, x2, [SP, #-0x10]!
    // 0x82c548: r0 = AllocateDouble()
    //     0x82c548: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82c54c: mov             x1, x0
    // 0x82c550: ldp             x0, x2, [SP], #0x10
    // 0x82c554: ldp             x3, x4, [SP], #0x10
    // 0x82c558: RestoreReg d0
    //     0x82c558: ldr             q0, [SP], #0x10
    // 0x82c55c: b               #0x82c484
    // 0x82c560: r9 = _invertColors
    //     0x82c560: add             x9, PP, #0x38, lsl #12  ; [pp+0x38510] Field <_ExtendedImageState@408436062._invertColors@408436062>: late (offset: 0x28)
    //     0x82c564: ldr             x9, [x9, #0x510]
    // 0x82c568: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x82c568: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _getCompletedWidget(/* No info */) {
    // ** addr: 0x82c56c, size: 0xb4
    // 0x82c56c: EnterFrame
    //     0x82c56c: stp             fp, lr, [SP, #-0x10]!
    //     0x82c570: mov             fp, SP
    // 0x82c574: CheckStackOverflow
    //     0x82c574: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82c578: cmp             SP, x16
    //     0x82c57c: b.ls            #0x82c614
    // 0x82c580: ldr             x0, [fp, #0x10]
    // 0x82c584: LoadField: r1 = r0->field_b
    //     0x82c584: ldur            w1, [x0, #0xb]
    // 0x82c588: DecompressPointer r1
    //     0x82c588: add             x1, x1, HEAP, lsl #32
    // 0x82c58c: cmp             w1, NULL
    // 0x82c590: b.eq            #0x82c61c
    // 0x82c594: LoadField: r2 = r1->field_33
    //     0x82c594: ldur            w2, [x1, #0x33]
    // 0x82c598: DecompressPointer r2
    //     0x82c598: add             x2, x2, HEAP, lsl #32
    // 0x82c59c: r16 = Instance_ExtendedImageMode
    //     0x82c59c: add             x16, PP, #0x38, lsl #12  ; [pp+0x38518] Obj!ExtendedImageMode@b66031
    //     0x82c5a0: ldr             x16, [x16, #0x518]
    // 0x82c5a4: cmp             w2, w16
    // 0x82c5a8: b.ne            #0x82c5d0
    // 0x82c5ac: r0 = ExtendedImageGesture()
    //     0x82c5ac: bl              #0x82c62c  ; AllocateExtendedImageGestureStub -> ExtendedImageGesture (size=0x18)
    // 0x82c5b0: mov             x1, x0
    // 0x82c5b4: ldr             x0, [fp, #0x10]
    // 0x82c5b8: StoreField: r1->field_b = r0
    //     0x82c5b8: stur            w0, [x1, #0xb]
    // 0x82c5bc: r0 = Closure: (GestureDetails?) => bool from Function '_defaultCanScaleImage@409445628': static.
    //     0x82c5bc: add             x0, PP, #0x38, lsl #12  ; [pp+0x38520] Closure: (GestureDetails?) => bool from Function '_defaultCanScaleImage@409445628': static. (0x7fe6e255cca4)
    //     0x82c5c0: ldr             x0, [x0, #0x520]
    // 0x82c5c4: StoreField: r1->field_13 = r0
    //     0x82c5c4: stur            w0, [x1, #0x13]
    // 0x82c5c8: mov             x0, x1
    // 0x82c5cc: b               #0x82c608
    // 0x82c5d0: r16 = Instance_ExtendedImageMode
    //     0x82c5d0: add             x16, PP, #0x38, lsl #12  ; [pp+0x38528] Obj!ExtendedImageMode@b66011
    //     0x82c5d4: ldr             x16, [x16, #0x528]
    // 0x82c5d8: cmp             w2, w16
    // 0x82c5dc: b.ne            #0x82c5f4
    // 0x82c5e0: r0 = ExtendedImageEditor()
    //     0x82c5e0: bl              #0x82c620  ; AllocateExtendedImageEditorStub -> ExtendedImageEditor (size=0x10)
    // 0x82c5e4: mov             x1, x0
    // 0x82c5e8: ldr             x0, [fp, #0x10]
    // 0x82c5ec: StoreField: r1->field_b = r0
    //     0x82c5ec: stur            w0, [x1, #0xb]
    // 0x82c5f0: b               #0x82c604
    // 0x82c5f4: SaveReg r0
    //     0x82c5f4: str             x0, [SP, #-8]!
    // 0x82c5f8: r0 = _buildExtendedRawImage()
    //     0x82c5f8: bl              #0x82c3ec  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_buildExtendedRawImage
    // 0x82c5fc: add             SP, SP, #8
    // 0x82c600: mov             x1, x0
    // 0x82c604: mov             x0, x1
    // 0x82c608: LeaveFrame
    //     0x82c608: mov             SP, fp
    //     0x82c60c: ldp             fp, lr, [SP], #0x10
    // 0x82c610: ret
    //     0x82c610: ret             
    // 0x82c614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c614: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c618: b               #0x82c580
    // 0x82c61c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c61c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d5f90, size: 0x128
    // 0x9d5f90: EnterFrame
    //     0x9d5f90: stp             fp, lr, [SP, #-0x10]!
    //     0x9d5f94: mov             fp, SP
    // 0x9d5f98: AllocStack(0x10)
    //     0x9d5f98: sub             SP, SP, #0x10
    // 0x9d5f9c: r1 = false
    //     0x9d5f9c: add             x1, NULL, #0x30  ; false
    // 0x9d5fa0: r0 = Instance_LoadState
    //     0x9d5fa0: add             x0, PP, #0x27, lsl #12  ; [pp+0x27c58] Obj!LoadState@b66071
    //     0x9d5fa4: ldr             x0, [x0, #0xc58]
    // 0x9d5fa8: CheckStackOverflow
    //     0x9d5fa8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d5fac: cmp             SP, x16
    //     0x9d5fb0: b.ls            #0x9d60a8
    // 0x9d5fb4: ldr             x2, [fp, #0x10]
    // 0x9d5fb8: StoreField: r2->field_13 = r1
    //     0x9d5fb8: stur            w1, [x2, #0x13]
    // 0x9d5fbc: StoreField: r2->field_17 = r0
    //     0x9d5fbc: stur            w0, [x2, #0x17]
    // 0x9d5fc0: r0 = LoadStaticField(0xbb8)
    //     0x9d5fc0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9d5fc4: ldr             x0, [x0, #0x1770]
    // 0x9d5fc8: cmp             w0, NULL
    // 0x9d5fcc: b.eq            #0x9d60b0
    // 0x9d5fd0: LoadField: r1 = r0->field_cf
    //     0x9d5fd0: ldur            w1, [x0, #0xcf]
    // 0x9d5fd4: DecompressPointer r1
    //     0x9d5fd4: add             x1, x1, HEAP, lsl #32
    // 0x9d5fd8: stur            x1, [fp, #-0x10]
    // 0x9d5fdc: LoadField: r0 = r1->field_b
    //     0x9d5fdc: ldur            w0, [x1, #0xb]
    // 0x9d5fe0: DecompressPointer r0
    //     0x9d5fe0: add             x0, x0, HEAP, lsl #32
    // 0x9d5fe4: stur            x0, [fp, #-8]
    // 0x9d5fe8: LoadField: r3 = r1->field_f
    //     0x9d5fe8: ldur            w3, [x1, #0xf]
    // 0x9d5fec: DecompressPointer r3
    //     0x9d5fec: add             x3, x3, HEAP, lsl #32
    // 0x9d5ff0: LoadField: r4 = r3->field_b
    //     0x9d5ff0: ldur            w4, [x3, #0xb]
    // 0x9d5ff4: DecompressPointer r4
    //     0x9d5ff4: add             x4, x4, HEAP, lsl #32
    // 0x9d5ff8: cmp             w0, w4
    // 0x9d5ffc: b.ne            #0x9d600c
    // 0x9d6000: SaveReg r1
    //     0x9d6000: str             x1, [SP, #-8]!
    // 0x9d6004: r0 = _growToNextCapacity()
    //     0x9d6004: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9d6008: add             SP, SP, #8
    // 0x9d600c: ldr             x2, [fp, #0x10]
    // 0x9d6010: ldur            x3, [fp, #-0x10]
    // 0x9d6014: ldur            x0, [fp, #-8]
    // 0x9d6018: r4 = LoadInt32Instr(r0)
    //     0x9d6018: sbfx            x4, x0, #1, #0x1f
    // 0x9d601c: add             x0, x4, #1
    // 0x9d6020: lsl             x1, x0, #1
    // 0x9d6024: StoreField: r3->field_b = r1
    //     0x9d6024: stur            w1, [x3, #0xb]
    // 0x9d6028: mov             x1, x4
    // 0x9d602c: cmp             x1, x0
    // 0x9d6030: b.hs            #0x9d60b4
    // 0x9d6034: LoadField: r1 = r3->field_f
    //     0x9d6034: ldur            w1, [x3, #0xf]
    // 0x9d6038: DecompressPointer r1
    //     0x9d6038: add             x1, x1, HEAP, lsl #32
    // 0x9d603c: mov             x0, x2
    // 0x9d6040: ArrayStore: r1[r4] = r0  ; List_4
    //     0x9d6040: add             x25, x1, x4, lsl #2
    //     0x9d6044: add             x25, x25, #0xf
    //     0x9d6048: str             w0, [x25]
    //     0x9d604c: tbz             w0, #0, #0x9d6068
    //     0x9d6050: ldurb           w16, [x1, #-1]
    //     0x9d6054: ldurb           w17, [x0, #-1]
    //     0x9d6058: and             x16, x17, x16, lsr #2
    //     0x9d605c: tst             x16, HEAP, lsr #32
    //     0x9d6060: b.eq            #0x9d6068
    //     0x9d6064: bl              #0xd67e5c
    // 0x9d6068: r1 = <State<ExtendedImage>>
    //     0x9d6068: add             x1, PP, #0x38, lsl #12  ; [pp+0x384d8] TypeArguments: <State<ExtendedImage>>
    //     0x9d606c: ldr             x1, [x1, #0x4d8]
    // 0x9d6070: r0 = DisposableBuildContext()
    //     0x9d6070: bl              #0x9d60b8  ; AllocateDisposableBuildContextStub -> DisposableBuildContext<X0 bound State<StatefulWidget>> (size=0x10)
    // 0x9d6074: ldr             x1, [fp, #0x10]
    // 0x9d6078: StoreField: r0->field_b = r1
    //     0x9d6078: stur            w1, [x0, #0xb]
    // 0x9d607c: StoreField: r1->field_37 = r0
    //     0x9d607c: stur            w0, [x1, #0x37]
    //     0x9d6080: ldurb           w16, [x1, #-1]
    //     0x9d6084: ldurb           w17, [x0, #-1]
    //     0x9d6088: and             x16, x17, x16, lsr #2
    //     0x9d608c: tst             x16, HEAP, lsr #32
    //     0x9d6090: b.eq            #0x9d6098
    //     0x9d6094: bl              #0xd6826c
    // 0x9d6098: r0 = Null
    //     0x9d6098: mov             x0, NULL
    // 0x9d609c: LeaveFrame
    //     0x9d609c: mov             SP, fp
    //     0x9d60a0: ldp             fp, lr, [SP], #0x10
    // 0x9d60a4: ret
    //     0x9d60a4: ret             
    // 0x9d60a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d60a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d60ac: b               #0x9d5fb4
    // 0x9d60b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d60b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d60b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9d60b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a108, size: 0x18
    // 0xa4a108: r4 = 7
    //     0xa4a108: mov             x4, #7
    // 0xa4a10c: r1 = Function 'dispose':.
    //     0xa4a10c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c6f8] AnonymousClosure: (0xa4a120), in [package:extended_image/src/extended_image.dart] _ExtendedImageState::dispose (0xa4eba0)
    //     0xa4a110: ldr             x1, [x17, #0x6f8]
    // 0xa4a114: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a114: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a118: LoadField: r0 = r24->field_17
    //     0xa4a118: ldur            x0, [x24, #0x17]
    // 0xa4a11c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a120, size: 0x48
    // 0xa4a120: EnterFrame
    //     0xa4a120: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a124: mov             fp, SP
    // 0xa4a128: ldr             x0, [fp, #0x10]
    // 0xa4a12c: LoadField: r1 = r0->field_17
    //     0xa4a12c: ldur            w1, [x0, #0x17]
    // 0xa4a130: DecompressPointer r1
    //     0xa4a130: add             x1, x1, HEAP, lsl #32
    // 0xa4a134: CheckStackOverflow
    //     0xa4a134: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a138: cmp             SP, x16
    //     0xa4a13c: b.ls            #0xa4a160
    // 0xa4a140: LoadField: r0 = r1->field_f
    //     0xa4a140: ldur            w0, [x1, #0xf]
    // 0xa4a144: DecompressPointer r0
    //     0xa4a144: add             x0, x0, HEAP, lsl #32
    // 0xa4a148: SaveReg r0
    //     0xa4a148: str             x0, [SP, #-8]!
    // 0xa4a14c: r0 = dispose()
    //     0xa4a14c: bl              #0xa4eba0  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::dispose
    // 0xa4a150: add             SP, SP, #8
    // 0xa4a154: LeaveFrame
    //     0xa4a154: mov             SP, fp
    //     0xa4a158: ldp             fp, lr, [SP], #0x10
    // 0xa4a15c: ret
    //     0xa4a15c: ret             
    // 0xa4a160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a160: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a164: b               #0xa4a140
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4eba0, size: 0xdc
    // 0xa4eba0: EnterFrame
    //     0xa4eba0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4eba4: mov             fp, SP
    // 0xa4eba8: CheckStackOverflow
    //     0xa4eba8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4ebac: cmp             SP, x16
    //     0xa4ebb0: b.ls            #0xa4ec60
    // 0xa4ebb4: r0 = LoadStaticField(0xbb8)
    //     0xa4ebb4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa4ebb8: ldr             x0, [x0, #0x1770]
    // 0xa4ebbc: cmp             w0, NULL
    // 0xa4ebc0: b.eq            #0xa4ec68
    // 0xa4ebc4: ldr             x16, [fp, #0x10]
    // 0xa4ebc8: stp             x16, x0, [SP, #-0x10]!
    // 0xa4ebcc: r0 = removeObserver()
    //     0xa4ebcc: bl              #0x6e7f28  ; [package:flutter/src/widgets/binding.dart] _WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::removeObserver
    // 0xa4ebd0: add             SP, SP, #0x10
    // 0xa4ebd4: ldr             x16, [fp, #0x10]
    // 0xa4ebd8: SaveReg r16
    //     0xa4ebd8: str             x16, [SP, #-8]!
    // 0xa4ebdc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa4ebdc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa4ebe0: r0 = _stopListeningToStream()
    //     0xa4ebe0: bl              #0xa4ec7c  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_stopListeningToStream
    // 0xa4ebe4: add             SP, SP, #8
    // 0xa4ebe8: ldr             x0, [fp, #0x10]
    // 0xa4ebec: LoadField: r1 = r0->field_3b
    //     0xa4ebec: ldur            w1, [x0, #0x3b]
    // 0xa4ebf0: DecompressPointer r1
    //     0xa4ebf0: add             x1, x1, HEAP, lsl #32
    // 0xa4ebf4: cmp             w1, NULL
    // 0xa4ebf8: b.eq            #0xa4ec0c
    // 0xa4ebfc: SaveReg r1
    //     0xa4ebfc: str             x1, [SP, #-8]!
    // 0xa4ec00: r0 = dispose()
    //     0xa4ec00: bl              #0x5cd4f4  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleterHandle::dispose
    // 0xa4ec04: add             SP, SP, #8
    // 0xa4ec08: ldr             x0, [fp, #0x10]
    // 0xa4ec0c: LoadField: r1 = r0->field_37
    //     0xa4ec0c: ldur            w1, [x0, #0x37]
    // 0xa4ec10: DecompressPointer r1
    //     0xa4ec10: add             x1, x1, HEAP, lsl #32
    // 0xa4ec14: r16 = Sentinel
    //     0xa4ec14: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4ec18: cmp             w1, w16
    // 0xa4ec1c: b.eq            #0xa4ec6c
    // 0xa4ec20: SaveReg r1
    //     0xa4ec20: str             x1, [SP, #-8]!
    // 0xa4ec24: r0 = dispose()
    //     0xa4ec24: bl              #0xb1082c  ; [package:flutter/src/widgets/scroll_activity.dart] DragScrollActivity::dispose
    // 0xa4ec28: add             SP, SP, #8
    // 0xa4ec2c: ldr             x16, [fp, #0x10]
    // 0xa4ec30: stp             NULL, x16, [SP, #-0x10]!
    // 0xa4ec34: r0 = _replaceImage()
    //     0xa4ec34: bl              #0x794108  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_replaceImage
    // 0xa4ec38: add             SP, SP, #0x10
    // 0xa4ec3c: ldr             x1, [fp, #0x10]
    // 0xa4ec40: LoadField: r2 = r1->field_b
    //     0xa4ec40: ldur            w2, [x1, #0xb]
    // 0xa4ec44: DecompressPointer r2
    //     0xa4ec44: add             x2, x2, HEAP, lsl #32
    // 0xa4ec48: cmp             w2, NULL
    // 0xa4ec4c: b.eq            #0xa4ec78
    // 0xa4ec50: r0 = Null
    //     0xa4ec50: mov             x0, NULL
    // 0xa4ec54: LeaveFrame
    //     0xa4ec54: mov             SP, fp
    //     0xa4ec58: ldp             fp, lr, [SP], #0x10
    // 0xa4ec5c: ret
    //     0xa4ec5c: ret             
    // 0xa4ec60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4ec60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4ec64: b               #0xa4ebb4
    // 0xa4ec68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4ec68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa4ec6c: r9 = _scrollAwareContext
    //     0xa4ec6c: add             x9, PP, #0x38, lsl #12  ; [pp+0x384c0] Field <_ExtendedImageState@408436062._scrollAwareContext@408436062>: late (offset: 0x38)
    //     0xa4ec70: ldr             x9, [x9, #0x4c0]
    // 0xa4ec74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4ec74: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa4ec78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4ec78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _stopListeningToStream(/* No info */) {
    // ** addr: 0xa4ec7c, size: 0x164
    // 0xa4ec7c: EnterFrame
    //     0xa4ec7c: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ec80: mov             fp, SP
    // 0xa4ec84: AllocStack(0x10)
    //     0xa4ec84: sub             SP, SP, #0x10
    // 0xa4ec88: SetupParameters(_ExtendedImageState<ExtendedImage> this /* r3, fp-0x8 */, {dynamic keepStreamAlive = false /* r0 */})
    //     0xa4ec88: mov             x0, x4
    //     0xa4ec8c: ldur            w1, [x0, #0x13]
    //     0xa4ec90: add             x1, x1, HEAP, lsl #32
    //     0xa4ec94: sub             x2, x1, #2
    //     0xa4ec98: add             x3, fp, w2, sxtw #2
    //     0xa4ec9c: ldr             x3, [x3, #0x10]
    //     0xa4eca0: stur            x3, [fp, #-8]
    //     0xa4eca4: ldur            w2, [x0, #0x1f]
    //     0xa4eca8: add             x2, x2, HEAP, lsl #32
    //     0xa4ecac: add             x16, PP, #0x27, lsl #12  ; [pp+0x27fb8] "keepStreamAlive"
    //     0xa4ecb0: ldr             x16, [x16, #0xfb8]
    //     0xa4ecb4: cmp             w2, w16
    //     0xa4ecb8: b.ne            #0xa4ecd8
    //     0xa4ecbc: ldur            w2, [x0, #0x23]
    //     0xa4ecc0: add             x2, x2, HEAP, lsl #32
    //     0xa4ecc4: sub             w0, w1, w2
    //     0xa4ecc8: add             x1, fp, w0, sxtw #2
    //     0xa4eccc: ldr             x1, [x1, #8]
    //     0xa4ecd0: mov             x0, x1
    //     0xa4ecd4: b               #0xa4ecdc
    //     0xa4ecd8: add             x0, NULL, #0x30  ; false
    // 0xa4ecdc: CheckStackOverflow
    //     0xa4ecdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4ece0: cmp             SP, x16
    //     0xa4ece4: b.ls            #0xa4edd4
    // 0xa4ece8: LoadField: r1 = r3->field_23
    //     0xa4ece8: ldur            w1, [x3, #0x23]
    // 0xa4ecec: DecompressPointer r1
    //     0xa4ecec: add             x1, x1, HEAP, lsl #32
    // 0xa4ecf0: tbz             w1, #4, #0xa4ed04
    // 0xa4ecf4: r0 = Null
    //     0xa4ecf4: mov             x0, NULL
    // 0xa4ecf8: LeaveFrame
    //     0xa4ecf8: mov             SP, fp
    //     0xa4ecfc: ldp             fp, lr, [SP], #0x10
    // 0xa4ed00: ret
    //     0xa4ed00: ret             
    // 0xa4ed04: tbnz            w0, #4, #0xa4ed80
    // 0xa4ed08: LoadField: r0 = r3->field_3b
    //     0xa4ed08: ldur            w0, [x3, #0x3b]
    // 0xa4ed0c: DecompressPointer r0
    //     0xa4ed0c: add             x0, x0, HEAP, lsl #32
    // 0xa4ed10: cmp             w0, NULL
    // 0xa4ed14: b.ne            #0xa4ed78
    // 0xa4ed18: LoadField: r0 = r3->field_1b
    //     0xa4ed18: ldur            w0, [x3, #0x1b]
    // 0xa4ed1c: DecompressPointer r0
    //     0xa4ed1c: add             x0, x0, HEAP, lsl #32
    // 0xa4ed20: cmp             w0, NULL
    // 0xa4ed24: b.ne            #0xa4ed30
    // 0xa4ed28: mov             x1, x3
    // 0xa4ed2c: b               #0xa4ed84
    // 0xa4ed30: LoadField: r1 = r0->field_7
    //     0xa4ed30: ldur            w1, [x0, #7]
    // 0xa4ed34: DecompressPointer r1
    //     0xa4ed34: add             x1, x1, HEAP, lsl #32
    // 0xa4ed38: cmp             w1, NULL
    // 0xa4ed3c: b.eq            #0xa4ed70
    // 0xa4ed40: SaveReg r1
    //     0xa4ed40: str             x1, [SP, #-8]!
    // 0xa4ed44: r0 = keepAlive()
    //     0xa4ed44: bl              #0xa4ede0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::keepAlive
    // 0xa4ed48: add             SP, SP, #8
    // 0xa4ed4c: ldur            x1, [fp, #-8]
    // 0xa4ed50: StoreField: r1->field_3b = r0
    //     0xa4ed50: stur            w0, [x1, #0x3b]
    //     0xa4ed54: ldurb           w16, [x1, #-1]
    //     0xa4ed58: ldurb           w17, [x0, #-1]
    //     0xa4ed5c: and             x16, x17, x16, lsr #2
    //     0xa4ed60: tst             x16, HEAP, lsr #32
    //     0xa4ed64: b.eq            #0xa4ed6c
    //     0xa4ed68: bl              #0xd6826c
    // 0xa4ed6c: b               #0xa4ed84
    // 0xa4ed70: mov             x1, x3
    // 0xa4ed74: b               #0xa4ed84
    // 0xa4ed78: mov             x1, x3
    // 0xa4ed7c: b               #0xa4ed84
    // 0xa4ed80: mov             x1, x3
    // 0xa4ed84: LoadField: r0 = r1->field_1b
    //     0xa4ed84: ldur            w0, [x1, #0x1b]
    // 0xa4ed88: DecompressPointer r0
    //     0xa4ed88: add             x0, x0, HEAP, lsl #32
    // 0xa4ed8c: stur            x0, [fp, #-0x10]
    // 0xa4ed90: cmp             w0, NULL
    // 0xa4ed94: b.eq            #0xa4eddc
    // 0xa4ed98: SaveReg r1
    //     0xa4ed98: str             x1, [SP, #-8]!
    // 0xa4ed9c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa4ed9c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa4eda0: r0 = _getListener()
    //     0xa4eda0: bl              #0x793f20  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_getListener
    // 0xa4eda4: add             SP, SP, #8
    // 0xa4eda8: ldur            x16, [fp, #-0x10]
    // 0xa4edac: stp             x0, x16, [SP, #-0x10]!
    // 0xa4edb0: r0 = removeListener()
    //     0xa4edb0: bl              #0x793d7c  ; [package:flutter/src/painting/image_stream.dart] ImageStream::removeListener
    // 0xa4edb4: add             SP, SP, #0x10
    // 0xa4edb8: ldur            x1, [fp, #-8]
    // 0xa4edbc: r2 = false
    //     0xa4edbc: add             x2, NULL, #0x30  ; false
    // 0xa4edc0: StoreField: r1->field_23 = r2
    //     0xa4edc0: stur            w2, [x1, #0x23]
    // 0xa4edc4: r0 = Null
    //     0xa4edc4: mov             x0, NULL
    // 0xa4edc8: LeaveFrame
    //     0xa4edc8: mov             SP, fp
    //     0xa4edcc: ldp             fp, lr, [SP], #0x10
    // 0xa4edd0: ret
    //     0xa4edd0: ret             
    // 0xa4edd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4edd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4edd8: b               #0xa4ece8
    // 0xa4eddc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4eddc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa5f910, size: 0xc0
    // 0xa5f910: EnterFrame
    //     0xa5f910: stp             fp, lr, [SP, #-0x10]!
    //     0xa5f914: mov             fp, SP
    // 0xa5f918: CheckStackOverflow
    //     0xa5f918: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5f91c: cmp             SP, x16
    //     0xa5f920: b.ls            #0xa5f9c0
    // 0xa5f924: ldr             x16, [fp, #0x10]
    // 0xa5f928: SaveReg r16
    //     0xa5f928: str             x16, [SP, #-8]!
    // 0xa5f92c: r0 = _updateInvertColors()
    //     0xa5f92c: bl              #0x5177bc  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_updateInvertColors
    // 0xa5f930: add             SP, SP, #8
    // 0xa5f934: ldr             x16, [fp, #0x10]
    // 0xa5f938: SaveReg r16
    //     0xa5f938: str             x16, [SP, #-8]!
    // 0xa5f93c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa5f93c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa5f940: r0 = _resolveImage()
    //     0xa5f940: bl              #0x793818  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_resolveImage
    // 0xa5f944: add             SP, SP, #8
    // 0xa5f948: ldr             x0, [fp, #0x10]
    // 0xa5f94c: StoreField: r0->field_2b = rNULL
    //     0xa5f94c: stur            NULL, [x0, #0x2b]
    // 0xa5f950: LoadField: r1 = r0->field_b
    //     0xa5f950: ldur            w1, [x0, #0xb]
    // 0xa5f954: DecompressPointer r1
    //     0xa5f954: add             x1, x1, HEAP, lsl #32
    // 0xa5f958: cmp             w1, NULL
    // 0xa5f95c: b.eq            #0xa5f9c8
    // 0xa5f960: LoadField: r1 = r0->field_f
    //     0xa5f960: ldur            w1, [x0, #0xf]
    // 0xa5f964: DecompressPointer r1
    //     0xa5f964: add             x1, x1, HEAP, lsl #32
    // 0xa5f968: cmp             w1, NULL
    // 0xa5f96c: b.eq            #0xa5f9cc
    // 0xa5f970: SaveReg r1
    //     0xa5f970: str             x1, [SP, #-8]!
    // 0xa5f974: r0 = of()
    //     0xa5f974: bl              #0x86897c  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::of
    // 0xa5f978: add             SP, SP, #8
    // 0xa5f97c: tbnz            w0, #4, #0xa5f994
    // 0xa5f980: ldr             x16, [fp, #0x10]
    // 0xa5f984: SaveReg r16
    //     0xa5f984: str             x16, [SP, #-8]!
    // 0xa5f988: r0 = _listenToStream()
    //     0xa5f988: bl              #0xa5f9d0  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_listenToStream
    // 0xa5f98c: add             SP, SP, #8
    // 0xa5f990: b               #0xa5f9b0
    // 0xa5f994: ldr             x16, [fp, #0x10]
    // 0xa5f998: r30 = true
    //     0xa5f998: add             lr, NULL, #0x20  ; true
    // 0xa5f99c: stp             lr, x16, [SP, #-0x10]!
    // 0xa5f9a0: r4 = const [0, 0x2, 0x2, 0x1, keepStreamAlive, 0x1, null]
    //     0xa5f9a0: add             x4, PP, #0x27, lsl #12  ; [pp+0x27fb0] List(7) [0, 0x2, 0x2, 0x1, "keepStreamAlive", 0x1, Null]
    //     0xa5f9a4: ldr             x4, [x4, #0xfb0]
    // 0xa5f9a8: r0 = _stopListeningToStream()
    //     0xa5f9a8: bl              #0xa4ec7c  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_stopListeningToStream
    // 0xa5f9ac: add             SP, SP, #0x10
    // 0xa5f9b0: r0 = Null
    //     0xa5f9b0: mov             x0, NULL
    // 0xa5f9b4: LeaveFrame
    //     0xa5f9b4: mov             SP, fp
    //     0xa5f9b8: ldp             fp, lr, [SP], #0x10
    // 0xa5f9bc: ret
    //     0xa5f9bc: ret             
    // 0xa5f9c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5f9c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5f9c4: b               #0xa5f924
    // 0xa5f9c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5f9c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5f9cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5f9cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _listenToStream(/* No info */) {
    // ** addr: 0xa5f9d0, size: 0xc0
    // 0xa5f9d0: EnterFrame
    //     0xa5f9d0: stp             fp, lr, [SP, #-0x10]!
    //     0xa5f9d4: mov             fp, SP
    // 0xa5f9d8: AllocStack(0x8)
    //     0xa5f9d8: sub             SP, SP, #8
    // 0xa5f9dc: CheckStackOverflow
    //     0xa5f9dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5f9e0: cmp             SP, x16
    //     0xa5f9e4: b.ls            #0xa5fa84
    // 0xa5f9e8: ldr             x0, [fp, #0x10]
    // 0xa5f9ec: LoadField: r1 = r0->field_23
    //     0xa5f9ec: ldur            w1, [x0, #0x23]
    // 0xa5f9f0: DecompressPointer r1
    //     0xa5f9f0: add             x1, x1, HEAP, lsl #32
    // 0xa5f9f4: tbnz            w1, #4, #0xa5fa08
    // 0xa5f9f8: r0 = Null
    //     0xa5f9f8: mov             x0, NULL
    // 0xa5f9fc: LeaveFrame
    //     0xa5f9fc: mov             SP, fp
    //     0xa5fa00: ldp             fp, lr, [SP], #0x10
    // 0xa5fa04: ret
    //     0xa5fa04: ret             
    // 0xa5fa08: LoadField: r1 = r0->field_1b
    //     0xa5fa08: ldur            w1, [x0, #0x1b]
    // 0xa5fa0c: DecompressPointer r1
    //     0xa5fa0c: add             x1, x1, HEAP, lsl #32
    // 0xa5fa10: stur            x1, [fp, #-8]
    // 0xa5fa14: cmp             w1, NULL
    // 0xa5fa18: b.eq            #0xa5fa8c
    // 0xa5fa1c: SaveReg r0
    //     0xa5fa1c: str             x0, [SP, #-8]!
    // 0xa5fa20: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa5fa20: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa5fa24: r0 = _getListener()
    //     0xa5fa24: bl              #0x793f20  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_getListener
    // 0xa5fa28: add             SP, SP, #8
    // 0xa5fa2c: ldur            x16, [fp, #-8]
    // 0xa5fa30: stp             x0, x16, [SP, #-0x10]!
    // 0xa5fa34: r0 = addListener()
    //     0xa5fa34: bl              #0x793c04  ; [package:flutter/src/painting/image_stream.dart] ImageStream::addListener
    // 0xa5fa38: add             SP, SP, #0x10
    // 0xa5fa3c: ldr             x0, [fp, #0x10]
    // 0xa5fa40: LoadField: r1 = r0->field_3b
    //     0xa5fa40: ldur            w1, [x0, #0x3b]
    // 0xa5fa44: DecompressPointer r1
    //     0xa5fa44: add             x1, x1, HEAP, lsl #32
    // 0xa5fa48: cmp             w1, NULL
    // 0xa5fa4c: b.ne            #0xa5fa58
    // 0xa5fa50: mov             x1, x0
    // 0xa5fa54: b               #0xa5fa68
    // 0xa5fa58: SaveReg r1
    //     0xa5fa58: str             x1, [SP, #-8]!
    // 0xa5fa5c: r0 = dispose()
    //     0xa5fa5c: bl              #0x5cd4f4  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleterHandle::dispose
    // 0xa5fa60: add             SP, SP, #8
    // 0xa5fa64: ldr             x1, [fp, #0x10]
    // 0xa5fa68: r2 = true
    //     0xa5fa68: add             x2, NULL, #0x20  ; true
    // 0xa5fa6c: StoreField: r1->field_3b = rNULL
    //     0xa5fa6c: stur            NULL, [x1, #0x3b]
    // 0xa5fa70: StoreField: r1->field_23 = r2
    //     0xa5fa70: stur            w2, [x1, #0x23]
    // 0xa5fa74: r0 = Null
    //     0xa5fa74: mov             x0, NULL
    // 0xa5fa78: LeaveFrame
    //     0xa5fa78: mov             SP, fp
    //     0xa5fa7c: ldp             fp, lr, [SP], #0x10
    // 0xa5fa80: ret
    //     0xa5fa80: ret             
    // 0xa5fa84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5fa84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5fa88: b               #0xa5f9e8
    // 0xa5fa8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5fa8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic _loadFailed(dynamic) {
    // ** addr: 0xcdea3c, size: 0x18
    // 0xcdea3c: r4 = 7
    //     0xcdea3c: mov             x4, #7
    // 0xcdea40: r1 = Function '_loadFailed@408436062':.
    //     0xcdea40: add             x17, PP, #0x41, lsl #12  ; [pp+0x41030] AnonymousClosure: (0xcdea54), in [package:extended_image/src/extended_image.dart] _ExtendedImageState::_loadFailed (0xcdeaa8)
    //     0xcdea44: ldr             x1, [x17, #0x30]
    // 0xcdea48: r24 = BuildNonGenericMethodExtractorStub
    //     0xcdea48: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcdea4c: LoadField: r0 = r24->field_17
    //     0xcdea4c: ldur            x0, [x24, #0x17]
    // 0xcdea50: br              x0
  }
  [closure] void _loadFailed(dynamic, dynamic, StackTrace?) {
    // ** addr: 0xcdea54, size: 0x54
    // 0xcdea54: EnterFrame
    //     0xcdea54: stp             fp, lr, [SP, #-0x10]!
    //     0xcdea58: mov             fp, SP
    // 0xcdea5c: ldr             x0, [fp, #0x20]
    // 0xcdea60: LoadField: r1 = r0->field_17
    //     0xcdea60: ldur            w1, [x0, #0x17]
    // 0xcdea64: DecompressPointer r1
    //     0xcdea64: add             x1, x1, HEAP, lsl #32
    // 0xcdea68: CheckStackOverflow
    //     0xcdea68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdea6c: cmp             SP, x16
    //     0xcdea70: b.ls            #0xcdeaa0
    // 0xcdea74: LoadField: r0 = r1->field_f
    //     0xcdea74: ldur            w0, [x1, #0xf]
    // 0xcdea78: DecompressPointer r0
    //     0xcdea78: add             x0, x0, HEAP, lsl #32
    // 0xcdea7c: ldr             x16, [fp, #0x18]
    // 0xcdea80: stp             x16, x0, [SP, #-0x10]!
    // 0xcdea84: ldr             x16, [fp, #0x10]
    // 0xcdea88: SaveReg r16
    //     0xcdea88: str             x16, [SP, #-8]!
    // 0xcdea8c: r0 = _loadFailed()
    //     0xcdea8c: bl              #0xcdeaa8  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_loadFailed
    // 0xcdea90: add             SP, SP, #0x18
    // 0xcdea94: LeaveFrame
    //     0xcdea94: mov             SP, fp
    //     0xcdea98: ldp             fp, lr, [SP], #0x10
    // 0xcdea9c: ret
    //     0xcdea9c: ret             
    // 0xcdeaa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdeaa0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdeaa4: b               #0xcdea74
  }
  _ _loadFailed(/* No info */) {
    // ** addr: 0xcdeaa8, size: 0xb4
    // 0xcdeaa8: EnterFrame
    //     0xcdeaa8: stp             fp, lr, [SP, #-0x10]!
    //     0xcdeaac: mov             fp, SP
    // 0xcdeab0: CheckStackOverflow
    //     0xcdeab0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdeab4: cmp             SP, x16
    //     0xcdeab8: b.ls            #0xcdeb50
    // 0xcdeabc: r1 = 3
    //     0xcdeabc: mov             x1, #3
    // 0xcdeac0: r0 = AllocateContext()
    //     0xcdeac0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcdeac4: mov             x1, x0
    // 0xcdeac8: ldr             x0, [fp, #0x20]
    // 0xcdeacc: StoreField: r1->field_f = r0
    //     0xcdeacc: stur            w0, [x1, #0xf]
    // 0xcdead0: ldr             x2, [fp, #0x18]
    // 0xcdead4: StoreField: r1->field_13 = r2
    //     0xcdead4: stur            w2, [x1, #0x13]
    // 0xcdead8: ldr             x2, [fp, #0x10]
    // 0xcdeadc: StoreField: r1->field_17 = r2
    //     0xcdeadc: stur            w2, [x1, #0x17]
    // 0xcdeae0: mov             x2, x1
    // 0xcdeae4: r1 = Function '<anonymous closure>':.
    //     0xcdeae4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41038] AnonymousClosure: (0xcdeb5c), in [package:extended_image/src/extended_image.dart] _ExtendedImageState::_loadFailed (0xcdeaa8)
    //     0xcdeae8: ldr             x1, [x1, #0x38]
    // 0xcdeaec: r0 = AllocateClosure()
    //     0xcdeaec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcdeaf0: ldr             x16, [fp, #0x20]
    // 0xcdeaf4: stp             x0, x16, [SP, #-0x10]!
    // 0xcdeaf8: r0 = setState()
    //     0xcdeaf8: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xcdeafc: add             SP, SP, #0x10
    // 0xcdeb00: ldr             x0, [fp, #0x20]
    // 0xcdeb04: LoadField: r1 = r0->field_b
    //     0xcdeb04: ldur            w1, [x0, #0xb]
    // 0xcdeb08: DecompressPointer r1
    //     0xcdeb08: add             x1, x1, HEAP, lsl #32
    // 0xcdeb0c: cmp             w1, NULL
    // 0xcdeb10: b.eq            #0xcdeb58
    // 0xcdeb14: LoadField: r0 = r1->field_57
    //     0xcdeb14: ldur            w0, [x1, #0x57]
    // 0xcdeb18: DecompressPointer r0
    //     0xcdeb18: add             x0, x0, HEAP, lsl #32
    // 0xcdeb1c: r1 = LoadClassIdInstr(r0)
    //     0xcdeb1c: ldur            x1, [x0, #-1]
    //     0xcdeb20: ubfx            x1, x1, #0xc, #0x14
    // 0xcdeb24: SaveReg r0
    //     0xcdeb24: str             x0, [SP, #-8]!
    // 0xcdeb28: mov             x0, x1
    // 0xcdeb2c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcdeb2c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcdeb30: r0 = GDT[cid_x0 + 0x949]()
    //     0xcdeb30: add             lr, x0, #0x949
    //     0xcdeb34: ldr             lr, [x21, lr, lsl #3]
    //     0xcdeb38: blr             lr
    // 0xcdeb3c: add             SP, SP, #8
    // 0xcdeb40: r0 = Null
    //     0xcdeb40: mov             x0, NULL
    // 0xcdeb44: LeaveFrame
    //     0xcdeb44: mov             SP, fp
    //     0xcdeb48: ldp             fp, lr, [SP], #0x10
    // 0xcdeb4c: ret
    //     0xcdeb4c: ret             
    // 0xcdeb50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdeb50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdeb54: b               #0xcdeabc
    // 0xcdeb58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcdeb58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xcdeb5c, size: 0x28
    // 0xcdeb5c: r1 = Instance_LoadState
    //     0xcdeb5c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27c80] Obj!LoadState@b660b1
    //     0xcdeb60: ldr             x1, [x1, #0xc80]
    // 0xcdeb64: ldr             x2, [SP]
    // 0xcdeb68: LoadField: r3 = r2->field_17
    //     0xcdeb68: ldur            w3, [x2, #0x17]
    // 0xcdeb6c: DecompressPointer r3
    //     0xcdeb6c: add             x3, x3, HEAP, lsl #32
    // 0xcdeb70: LoadField: r2 = r3->field_f
    //     0xcdeb70: ldur            w2, [x3, #0xf]
    // 0xcdeb74: DecompressPointer r2
    //     0xcdeb74: add             x2, x2, HEAP, lsl #32
    // 0xcdeb78: StoreField: r2->field_17 = r1
    //     0xcdeb78: stur            w1, [x2, #0x17]
    // 0xcdeb7c: r0 = Null
    //     0xcdeb7c: mov             x0, NULL
    // 0xcdeb80: ret
    //     0xcdeb80: ret             
  }
  dynamic _handleImageFrame(dynamic) {
    // ** addr: 0xcdeb84, size: 0x18
    // 0xcdeb84: r4 = 7
    //     0xcdeb84: mov             x4, #7
    // 0xcdeb88: r1 = Function '_handleImageFrame@408436062':.
    //     0xcdeb88: add             x17, PP, #0x41, lsl #12  ; [pp+0x41040] AnonymousClosure: (0xcdeb9c), in [package:extended_image/src/extended_image.dart] _ExtendedImageState::_handleImageFrame (0xcdebf0)
    //     0xcdeb8c: ldr             x1, [x17, #0x40]
    // 0xcdeb90: r24 = BuildNonGenericMethodExtractorStub
    //     0xcdeb90: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcdeb94: LoadField: r0 = r24->field_17
    //     0xcdeb94: ldur            x0, [x24, #0x17]
    // 0xcdeb98: br              x0
  }
  [closure] void _handleImageFrame(dynamic, ImageInfo, bool) {
    // ** addr: 0xcdeb9c, size: 0x54
    // 0xcdeb9c: EnterFrame
    //     0xcdeb9c: stp             fp, lr, [SP, #-0x10]!
    //     0xcdeba0: mov             fp, SP
    // 0xcdeba4: ldr             x0, [fp, #0x20]
    // 0xcdeba8: LoadField: r1 = r0->field_17
    //     0xcdeba8: ldur            w1, [x0, #0x17]
    // 0xcdebac: DecompressPointer r1
    //     0xcdebac: add             x1, x1, HEAP, lsl #32
    // 0xcdebb0: CheckStackOverflow
    //     0xcdebb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdebb4: cmp             SP, x16
    //     0xcdebb8: b.ls            #0xcdebe8
    // 0xcdebbc: LoadField: r0 = r1->field_f
    //     0xcdebbc: ldur            w0, [x1, #0xf]
    // 0xcdebc0: DecompressPointer r0
    //     0xcdebc0: add             x0, x0, HEAP, lsl #32
    // 0xcdebc4: ldr             x16, [fp, #0x18]
    // 0xcdebc8: stp             x16, x0, [SP, #-0x10]!
    // 0xcdebcc: ldr             x16, [fp, #0x10]
    // 0xcdebd0: SaveReg r16
    //     0xcdebd0: str             x16, [SP, #-8]!
    // 0xcdebd4: r0 = _handleImageFrame()
    //     0xcdebd4: bl              #0xcdebf0  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_handleImageFrame
    // 0xcdebd8: add             SP, SP, #0x18
    // 0xcdebdc: LeaveFrame
    //     0xcdebdc: mov             SP, fp
    //     0xcdebe0: ldp             fp, lr, [SP], #0x10
    // 0xcdebe4: ret
    //     0xcdebe4: ret             
    // 0xcdebe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdebe8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdebec: b               #0xcdebbc
  }
  _ _handleImageFrame(/* No info */) {
    // ** addr: 0xcdebf0, size: 0x70
    // 0xcdebf0: EnterFrame
    //     0xcdebf0: stp             fp, lr, [SP, #-0x10]!
    //     0xcdebf4: mov             fp, SP
    // 0xcdebf8: CheckStackOverflow
    //     0xcdebf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdebfc: cmp             SP, x16
    //     0xcdec00: b.ls            #0xcdec58
    // 0xcdec04: r1 = 3
    //     0xcdec04: mov             x1, #3
    // 0xcdec08: r0 = AllocateContext()
    //     0xcdec08: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcdec0c: mov             x1, x0
    // 0xcdec10: ldr             x0, [fp, #0x20]
    // 0xcdec14: StoreField: r1->field_f = r0
    //     0xcdec14: stur            w0, [x1, #0xf]
    // 0xcdec18: ldr             x2, [fp, #0x18]
    // 0xcdec1c: StoreField: r1->field_13 = r2
    //     0xcdec1c: stur            w2, [x1, #0x13]
    // 0xcdec20: ldr             x2, [fp, #0x10]
    // 0xcdec24: StoreField: r1->field_17 = r2
    //     0xcdec24: stur            w2, [x1, #0x17]
    // 0xcdec28: mov             x2, x1
    // 0xcdec2c: r1 = Function '<anonymous closure>':.
    //     0xcdec2c: add             x1, PP, #0x41, lsl #12  ; [pp+0x41048] AnonymousClosure: (0xcdec60), in [package:extended_image/src/extended_image.dart] _ExtendedImageState::_handleImageFrame (0xcdebf0)
    //     0xcdec30: ldr             x1, [x1, #0x48]
    // 0xcdec34: r0 = AllocateClosure()
    //     0xcdec34: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcdec38: ldr             x16, [fp, #0x20]
    // 0xcdec3c: stp             x0, x16, [SP, #-0x10]!
    // 0xcdec40: r0 = setState()
    //     0xcdec40: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xcdec44: add             SP, SP, #0x10
    // 0xcdec48: r0 = Null
    //     0xcdec48: mov             x0, NULL
    // 0xcdec4c: LeaveFrame
    //     0xcdec4c: mov             SP, fp
    //     0xcdec50: ldp             fp, lr, [SP], #0x10
    // 0xcdec54: ret
    //     0xcdec54: ret             
    // 0xcdec58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdec58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdec5c: b               #0xcdec04
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xcdec60, size: 0x118
    // 0xcdec60: EnterFrame
    //     0xcdec60: stp             fp, lr, [SP, #-0x10]!
    //     0xcdec64: mov             fp, SP
    // 0xcdec68: AllocStack(0x20)
    //     0xcdec68: sub             SP, SP, #0x20
    // 0xcdec6c: SetupParameters()
    //     0xcdec6c: ldr             x0, [fp, #0x10]
    //     0xcdec70: ldur            w1, [x0, #0x17]
    //     0xcdec74: add             x1, x1, HEAP, lsl #32
    //     0xcdec78: stur            x1, [fp, #-8]
    // 0xcdec7c: CheckStackOverflow
    //     0xcdec7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdec80: cmp             SP, x16
    //     0xcdec84: b.ls            #0xcded70
    // 0xcdec88: LoadField: r0 = r1->field_f
    //     0xcdec88: ldur            w0, [x1, #0xf]
    // 0xcdec8c: DecompressPointer r0
    //     0xcdec8c: add             x0, x0, HEAP, lsl #32
    // 0xcdec90: LoadField: r2 = r1->field_13
    //     0xcdec90: ldur            w2, [x1, #0x13]
    // 0xcdec94: DecompressPointer r2
    //     0xcdec94: add             x2, x2, HEAP, lsl #32
    // 0xcdec98: stp             x2, x0, [SP, #-0x10]!
    // 0xcdec9c: r0 = _replaceImage()
    //     0xcdec9c: bl              #0x794108  ; [package:extended_image/src/extended_image.dart] _ExtendedImageState::_replaceImage
    // 0xcdeca0: add             SP, SP, #0x10
    // 0xcdeca4: ldur            x2, [fp, #-8]
    // 0xcdeca8: LoadField: r3 = r2->field_f
    //     0xcdeca8: ldur            w3, [x2, #0xf]
    // 0xcdecac: DecompressPointer r3
    //     0xcdecac: add             x3, x3, HEAP, lsl #32
    // 0xcdecb0: stur            x3, [fp, #-0x20]
    // 0xcdecb4: r0 = Instance_LoadState
    //     0xcdecb4: add             x0, PP, #0x27, lsl #12  ; [pp+0x27c78] Obj!LoadState@b66091
    //     0xcdecb8: ldr             x0, [x0, #0xc78]
    // 0xcdecbc: StoreField: r3->field_17 = r0
    //     0xcdecbc: stur            w0, [x3, #0x17]
    // 0xcdecc0: LoadField: r0 = r3->field_2f
    //     0xcdecc0: ldur            w0, [x3, #0x2f]
    // 0xcdecc4: DecompressPointer r0
    //     0xcdecc4: add             x0, x0, HEAP, lsl #32
    // 0xcdecc8: cmp             w0, NULL
    // 0xcdeccc: b.ne            #0xcdecd8
    // 0xcdecd0: r4 = 0
    //     0xcdecd0: mov             x4, #0
    // 0xcdecd4: b               #0xcdecec
    // 0xcdecd8: r1 = LoadInt32Instr(r0)
    //     0xcdecd8: sbfx            x1, x0, #1, #0x1f
    //     0xcdecdc: tbz             w0, #0, #0xcdece4
    //     0xcdece0: ldur            x1, [x0, #7]
    // 0xcdece4: add             x0, x1, #1
    // 0xcdece8: mov             x4, x0
    // 0xcdecec: r0 = BoxInt64Instr(r4)
    //     0xcdecec: sbfiz           x0, x4, #1, #0x1f
    //     0xcdecf0: cmp             x4, x0, asr #1
    //     0xcdecf4: b.eq            #0xcded00
    //     0xcdecf8: bl              #0xd69bb8
    //     0xcdecfc: stur            x4, [x0, #7]
    // 0xcded00: StoreField: r3->field_2f = r0
    //     0xcded00: stur            w0, [x3, #0x2f]
    //     0xcded04: tbz             w0, #0, #0xcded20
    //     0xcded08: ldurb           w16, [x3, #-1]
    //     0xcded0c: ldurb           w17, [x0, #-1]
    //     0xcded10: and             x16, x17, x16, lsr #2
    //     0xcded14: tst             x16, HEAP, lsr #32
    //     0xcded18: b.eq            #0xcded20
    //     0xcded1c: bl              #0xd682ac
    // 0xcded20: LoadField: r1 = r3->field_33
    //     0xcded20: ldur            w1, [x3, #0x33]
    // 0xcded24: DecompressPointer r1
    //     0xcded24: add             x1, x1, HEAP, lsl #32
    // 0xcded28: stur            x1, [fp, #-0x18]
    // 0xcded2c: LoadField: r4 = r2->field_17
    //     0xcded2c: ldur            w4, [x2, #0x17]
    // 0xcded30: DecompressPointer r4
    //     0xcded30: add             x4, x4, HEAP, lsl #32
    // 0xcded34: mov             x0, x4
    // 0xcded38: stur            x4, [fp, #-0x10]
    // 0xcded3c: tbnz            w0, #5, #0xcded44
    // 0xcded40: r0 = AssertBoolean()
    //     0xcded40: bl              #0xd67df0  ; AssertBooleanStub
    // 0xcded44: ldur            x1, [fp, #-0x10]
    // 0xcded48: tbnz            w1, #4, #0xcded54
    // 0xcded4c: r2 = true
    //     0xcded4c: add             x2, NULL, #0x20  ; true
    // 0xcded50: b               #0xcded58
    // 0xcded54: ldur            x2, [fp, #-0x18]
    // 0xcded58: ldur            x1, [fp, #-0x20]
    // 0xcded5c: StoreField: r1->field_33 = r2
    //     0xcded5c: stur            w2, [x1, #0x33]
    // 0xcded60: r0 = Null
    //     0xcded60: mov             x0, NULL
    // 0xcded64: LeaveFrame
    //     0xcded64: mov             SP, fp
    //     0xcded68: ldp             fp, lr, [SP], #0x10
    // 0xcded6c: ret
    //     0xcded6c: ret             
    // 0xcded70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcded70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcded74: b               #0xcdec88
  }
}

// class id: 4214, size: 0xa0, field offset: 0xc
class ExtendedImage extends StatefulWidget {

  _ ExtendedImage(/* No info */) {
    // ** addr: 0x89e200, size: 0x304
    // 0x89e200: EnterFrame
    //     0x89e200: stp             fp, lr, [SP, #-0x10]!
    //     0x89e204: mov             fp, SP
    // 0x89e208: mov             x1, x4
    // 0x89e20c: LoadField: r2 = r1->field_13
    //     0x89e20c: ldur            w2, [x1, #0x13]
    // 0x89e210: DecompressPointer r2
    //     0x89e210: add             x2, x2, HEAP, lsl #32
    // 0x89e214: sub             x3, x2, #4
    // 0x89e218: add             x4, fp, w3, sxtw #2
    // 0x89e21c: ldr             x4, [x4, #0x18]
    // 0x89e220: add             x0, fp, w3, sxtw #2
    // 0x89e224: ldr             x0, [x0, #0x10]
    // 0x89e228: LoadField: r3 = r1->field_1f
    //     0x89e228: ldur            w3, [x1, #0x1f]
    // 0x89e22c: DecompressPointer r3
    //     0x89e22c: add             x3, x3, HEAP, lsl #32
    // 0x89e230: r16 = "fit"
    //     0x89e230: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c7b8] "fit"
    //     0x89e234: ldr             x16, [x16, #0x7b8]
    // 0x89e238: cmp             w3, w16
    // 0x89e23c: b.ne            #0x89e260
    // 0x89e240: LoadField: r3 = r1->field_23
    //     0x89e240: ldur            w3, [x1, #0x23]
    // 0x89e244: DecompressPointer r3
    //     0x89e244: add             x3, x3, HEAP, lsl #32
    // 0x89e248: sub             w5, w2, w3
    // 0x89e24c: add             x3, fp, w5, sxtw #2
    // 0x89e250: ldr             x3, [x3, #8]
    // 0x89e254: mov             x5, x3
    // 0x89e258: r3 = 1
    //     0x89e258: mov             x3, #1
    // 0x89e25c: b               #0x89e268
    // 0x89e260: r5 = Null
    //     0x89e260: mov             x5, NULL
    // 0x89e264: r3 = 0
    //     0x89e264: mov             x3, #0
    // 0x89e268: lsl             x6, x3, #1
    // 0x89e26c: lsl             w7, w6, #1
    // 0x89e270: add             w8, w7, #8
    // 0x89e274: ArrayLoad: r9 = r1[r8]  ; Unknown_4
    //     0x89e274: add             x16, x1, w8, sxtw #1
    //     0x89e278: ldur            w9, [x16, #0xf]
    // 0x89e27c: DecompressPointer r9
    //     0x89e27c: add             x9, x9, HEAP, lsl #32
    // 0x89e280: r16 = "initGestureConfigHandler"
    //     0x89e280: add             x16, PP, #0x27, lsl #12  ; [pp+0x27c88] "initGestureConfigHandler"
    //     0x89e284: ldr             x16, [x16, #0xc88]
    // 0x89e288: cmp             w9, w16
    // 0x89e28c: b.ne            #0x89e2c0
    // 0x89e290: add             w8, w7, #0xa
    // 0x89e294: ArrayLoad: r7 = r1[r8]  ; Unknown_4
    //     0x89e294: add             x16, x1, w8, sxtw #1
    //     0x89e298: ldur            w7, [x16, #0xf]
    // 0x89e29c: DecompressPointer r7
    //     0x89e29c: add             x7, x7, HEAP, lsl #32
    // 0x89e2a0: sub             w8, w2, w7
    // 0x89e2a4: add             x7, fp, w8, sxtw #2
    // 0x89e2a8: ldr             x7, [x7, #8]
    // 0x89e2ac: add             w8, w6, #2
    // 0x89e2b0: r6 = LoadInt32Instr(r8)
    //     0x89e2b0: sbfx            x6, x8, #1, #0x1f
    // 0x89e2b4: mov             x3, x6
    // 0x89e2b8: mov             x6, x7
    // 0x89e2bc: b               #0x89e2c4
    // 0x89e2c0: r6 = Null
    //     0x89e2c0: mov             x6, NULL
    // 0x89e2c4: lsl             x7, x3, #1
    // 0x89e2c8: lsl             w8, w7, #1
    // 0x89e2cc: add             w9, w8, #8
    // 0x89e2d0: ArrayLoad: r10 = r1[r9]  ; Unknown_4
    //     0x89e2d0: add             x16, x1, w9, sxtw #1
    //     0x89e2d4: ldur            w10, [x16, #0xf]
    // 0x89e2d8: DecompressPointer r10
    //     0x89e2d8: add             x10, x10, HEAP, lsl #32
    // 0x89e2dc: r16 = "loadStateChanged"
    //     0x89e2dc: add             x16, PP, #0x27, lsl #12  ; [pp+0x27c90] "loadStateChanged"
    //     0x89e2e0: ldr             x16, [x16, #0xc90]
    // 0x89e2e4: cmp             w10, w16
    // 0x89e2e8: b.ne            #0x89e31c
    // 0x89e2ec: add             w9, w8, #0xa
    // 0x89e2f0: ArrayLoad: r8 = r1[r9]  ; Unknown_4
    //     0x89e2f0: add             x16, x1, w9, sxtw #1
    //     0x89e2f4: ldur            w8, [x16, #0xf]
    // 0x89e2f8: DecompressPointer r8
    //     0x89e2f8: add             x8, x8, HEAP, lsl #32
    // 0x89e2fc: sub             w9, w2, w8
    // 0x89e300: add             x8, fp, w9, sxtw #2
    // 0x89e304: ldr             x8, [x8, #8]
    // 0x89e308: add             w9, w7, #2
    // 0x89e30c: r7 = LoadInt32Instr(r9)
    //     0x89e30c: sbfx            x7, x9, #1, #0x1f
    // 0x89e310: mov             x3, x7
    // 0x89e314: mov             x7, x8
    // 0x89e318: b               #0x89e320
    // 0x89e31c: r7 = Null
    //     0x89e31c: mov             x7, NULL
    // 0x89e320: lsl             x8, x3, #1
    // 0x89e324: lsl             w9, w8, #1
    // 0x89e328: add             w10, w9, #8
    // 0x89e32c: ArrayLoad: r11 = r1[r10]  ; Unknown_4
    //     0x89e32c: add             x16, x1, w10, sxtw #1
    //     0x89e330: ldur            w11, [x16, #0xf]
    // 0x89e334: DecompressPointer r11
    //     0x89e334: add             x11, x11, HEAP, lsl #32
    // 0x89e338: r16 = "mode"
    //     0x89e338: add             x16, PP, #8, lsl #12  ; [pp+0x8f18] "mode"
    //     0x89e33c: ldr             x16, [x16, #0xf18]
    // 0x89e340: cmp             w11, w16
    // 0x89e344: b.ne            #0x89e378
    // 0x89e348: add             w10, w9, #0xa
    // 0x89e34c: ArrayLoad: r9 = r1[r10]  ; Unknown_4
    //     0x89e34c: add             x16, x1, w10, sxtw #1
    //     0x89e350: ldur            w9, [x16, #0xf]
    // 0x89e354: DecompressPointer r9
    //     0x89e354: add             x9, x9, HEAP, lsl #32
    // 0x89e358: sub             w10, w2, w9
    // 0x89e35c: add             x9, fp, w10, sxtw #2
    // 0x89e360: ldr             x9, [x9, #8]
    // 0x89e364: add             w10, w8, #2
    // 0x89e368: r8 = LoadInt32Instr(r10)
    //     0x89e368: sbfx            x8, x10, #1, #0x1f
    // 0x89e36c: mov             x3, x8
    // 0x89e370: mov             x8, x9
    // 0x89e374: b               #0x89e380
    // 0x89e378: r8 = Instance_ExtendedImageMode
    //     0x89e378: add             x8, PP, #0x27, lsl #12  ; [pp+0x27c98] Obj!ExtendedImageMode@b66051
    //     0x89e37c: ldr             x8, [x8, #0xc98]
    // 0x89e380: lsl             x9, x3, #1
    // 0x89e384: lsl             w3, w9, #1
    // 0x89e388: add             w9, w3, #8
    // 0x89e38c: ArrayLoad: r10 = r1[r9]  ; Unknown_4
    //     0x89e38c: add             x16, x1, w9, sxtw #1
    //     0x89e390: ldur            w10, [x16, #0xf]
    // 0x89e394: DecompressPointer r10
    //     0x89e394: add             x10, x10, HEAP, lsl #32
    // 0x89e398: r16 = "onDoubleTap"
    //     0x89e398: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c458] "onDoubleTap"
    //     0x89e39c: ldr             x16, [x16, #0x458]
    // 0x89e3a0: cmp             w10, w16
    // 0x89e3a4: b.ne            #0x89e3cc
    // 0x89e3a8: add             w9, w3, #0xa
    // 0x89e3ac: ArrayLoad: r3 = r1[r9]  ; Unknown_4
    //     0x89e3ac: add             x16, x1, w9, sxtw #1
    //     0x89e3b0: ldur            w3, [x16, #0xf]
    // 0x89e3b4: DecompressPointer r3
    //     0x89e3b4: add             x3, x3, HEAP, lsl #32
    // 0x89e3b8: sub             w1, w2, w3
    // 0x89e3bc: add             x2, fp, w1, sxtw #2
    // 0x89e3c0: ldr             x2, [x2, #8]
    // 0x89e3c4: mov             x13, x2
    // 0x89e3c8: b               #0x89e3d0
    // 0x89e3cc: r13 = Null
    //     0x89e3cc: mov             x13, NULL
    // 0x89e3d0: r12 = false
    //     0x89e3d0: add             x12, NULL, #0x30  ; false
    // 0x89e3d4: r11 = Instance_Alignment
    //     0x89e3d4: add             x11, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x89e3d8: ldr             x11, [x11, #0xc70]
    // 0x89e3dc: r10 = Instance_ImageRepeat
    //     0x89e3dc: add             x10, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0x89e3e0: ldr             x10, [x10, #0x540]
    // 0x89e3e4: r9 = Instance_FilterQuality
    //     0x89e3e4: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0x89e3e8: ldr             x9, [x9, #0x548]
    // 0x89e3ec: r3 = Instance_Clip
    //     0x89e3ec: add             x3, PP, #0x21, lsl #12  ; [pp+0x21ad0] Obj!Clip@b676b1
    //     0x89e3f0: ldr             x3, [x3, #0xad0]
    // 0x89e3f4: r2 = true
    //     0x89e3f4: add             x2, NULL, #0x20  ; true
    // 0x89e3f8: r1 = Instance_EdgeInsets
    //     0x89e3f8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x89e3fc: ldr             x1, [x1, #0xbd8]
    // 0x89e400: StoreField: r4->field_57 = r0
    //     0x89e400: stur            w0, [x4, #0x57]
    //     0x89e404: ldurb           w16, [x4, #-1]
    //     0x89e408: ldurb           w17, [x0, #-1]
    //     0x89e40c: and             x16, x17, x16, lsr #2
    //     0x89e410: tst             x16, HEAP, lsr #32
    //     0x89e414: b.eq            #0x89e41c
    //     0x89e418: bl              #0xd682cc
    // 0x89e41c: StoreField: r4->field_93 = r12
    //     0x89e41c: stur            w12, [x4, #0x93]
    // 0x89e420: mov             x0, x5
    // 0x89e424: StoreField: r4->field_77 = r0
    //     0x89e424: stur            w0, [x4, #0x77]
    //     0x89e428: ldurb           w16, [x4, #-1]
    //     0x89e42c: ldurb           w17, [x0, #-1]
    //     0x89e430: and             x16, x17, x16, lsr #2
    //     0x89e434: tst             x16, HEAP, lsr #32
    //     0x89e438: b.eq            #0x89e440
    //     0x89e43c: bl              #0xd682cc
    // 0x89e440: StoreField: r4->field_7b = r11
    //     0x89e440: stur            w11, [x4, #0x7b]
    // 0x89e444: StoreField: r4->field_7f = r10
    //     0x89e444: stur            w10, [x4, #0x7f]
    // 0x89e448: StoreField: r4->field_87 = r12
    //     0x89e448: stur            w12, [x4, #0x87]
    // 0x89e44c: StoreField: r4->field_8b = r12
    //     0x89e44c: stur            w12, [x4, #0x8b]
    // 0x89e450: StoreField: r4->field_6f = r9
    //     0x89e450: stur            w9, [x4, #0x6f]
    // 0x89e454: mov             x0, x7
    // 0x89e458: StoreField: r4->field_53 = r0
    //     0x89e458: stur            w0, [x4, #0x53]
    //     0x89e45c: ldurb           w16, [x4, #-1]
    //     0x89e460: ldurb           w17, [x0, #-1]
    //     0x89e464: and             x16, x17, x16, lsr #2
    //     0x89e468: tst             x16, HEAP, lsr #32
    //     0x89e46c: b.eq            #0x89e474
    //     0x89e470: bl              #0xd682cc
    // 0x89e474: StoreField: r4->field_43 = r3
    //     0x89e474: stur            w3, [x4, #0x43]
    // 0x89e478: StoreField: r4->field_3f = r12
    //     0x89e478: stur            w12, [x4, #0x3f]
    // 0x89e47c: mov             x0, x8
    // 0x89e480: StoreField: r4->field_33 = r0
    //     0x89e480: stur            w0, [x4, #0x33]
    //     0x89e484: ldurb           w16, [x4, #-1]
    //     0x89e488: ldurb           w17, [x0, #-1]
    //     0x89e48c: and             x16, x17, x16, lsr #2
    //     0x89e490: tst             x16, HEAP, lsr #32
    //     0x89e494: b.eq            #0x89e49c
    //     0x89e498: bl              #0xd682cc
    // 0x89e49c: StoreField: r4->field_2f = r2
    //     0x89e49c: stur            w2, [x4, #0x2f]
    // 0x89e4a0: mov             x0, x13
    // 0x89e4a4: StoreField: r4->field_2b = r0
    //     0x89e4a4: stur            w0, [x4, #0x2b]
    //     0x89e4a8: ldurb           w16, [x4, #-1]
    //     0x89e4ac: ldurb           w17, [x0, #-1]
    //     0x89e4b0: and             x16, x17, x16, lsr #2
    //     0x89e4b4: tst             x16, HEAP, lsr #32
    //     0x89e4b8: b.eq            #0x89e4c0
    //     0x89e4bc: bl              #0xd682cc
    // 0x89e4c0: mov             x0, x6
    // 0x89e4c4: StoreField: r4->field_27 = r0
    //     0x89e4c4: stur            w0, [x4, #0x27]
    //     0x89e4c8: ldurb           w16, [x4, #-1]
    //     0x89e4cc: ldurb           w17, [x0, #-1]
    //     0x89e4d0: and             x16, x17, x16, lsr #2
    //     0x89e4d4: tst             x16, HEAP, lsr #32
    //     0x89e4d8: b.eq            #0x89e4e0
    //     0x89e4dc: bl              #0xd682cc
    // 0x89e4e0: StoreField: r4->field_23 = r12
    //     0x89e4e0: stur            w12, [x4, #0x23]
    // 0x89e4e4: StoreField: r4->field_13 = r12
    //     0x89e4e4: stur            w12, [x4, #0x13]
    // 0x89e4e8: StoreField: r4->field_97 = r12
    //     0x89e4e8: stur            w12, [x4, #0x97]
    // 0x89e4ec: StoreField: r4->field_f = r12
    //     0x89e4ec: stur            w12, [x4, #0xf]
    // 0x89e4f0: StoreField: r4->field_9b = r1
    //     0x89e4f0: stur            w1, [x4, #0x9b]
    // 0x89e4f4: r0 = Null
    //     0x89e4f4: mov             x0, NULL
    // 0x89e4f8: LeaveFrame
    //     0x89e4f8: mov             SP, fp
    //     0x89e4fc: ldp             fp, lr, [SP], #0x10
    // 0x89e500: ret
    //     0x89e500: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xa3f248, size: 0x40
    // 0xa3f248: EnterFrame
    //     0xa3f248: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f24c: mov             fp, SP
    // 0xa3f250: r1 = <ExtendedImage>
    //     0xa3f250: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f0e0] TypeArguments: <ExtendedImage>
    //     0xa3f254: ldr             x1, [x1, #0xe0]
    // 0xa3f258: r0 = _ExtendedImageState()
    //     0xa3f258: bl              #0xa3f288  ; Allocate_ExtendedImageStateStub -> _ExtendedImageState (size=0x44)
    // 0xa3f25c: r1 = Sentinel
    //     0xa3f25c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3f260: StoreField: r0->field_17 = r1
    //     0xa3f260: stur            w1, [x0, #0x17]
    // 0xa3f264: r2 = false
    //     0xa3f264: add             x2, NULL, #0x30  ; false
    // 0xa3f268: StoreField: r0->field_23 = r2
    //     0xa3f268: stur            w2, [x0, #0x23]
    // 0xa3f26c: StoreField: r0->field_27 = r1
    //     0xa3f26c: stur            w1, [x0, #0x27]
    // 0xa3f270: StoreField: r0->field_33 = r2
    //     0xa3f270: stur            w2, [x0, #0x33]
    // 0xa3f274: StoreField: r0->field_37 = r1
    //     0xa3f274: stur            w1, [x0, #0x37]
    // 0xa3f278: StoreField: r0->field_13 = r1
    //     0xa3f278: stur            w1, [x0, #0x13]
    // 0xa3f27c: LeaveFrame
    //     0xa3f27c: mov             SP, fp
    //     0xa3f280: ldp             fp, lr, [SP], #0x10
    // 0xa3f284: ret
    //     0xa3f284: ret             
  }
}

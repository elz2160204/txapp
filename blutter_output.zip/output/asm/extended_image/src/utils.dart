// lib: , url: package:extended_image/src/utils.dart

// class id: 1048946, size: 0x8
class :: {

  static _ RectExtension.isSame(/* No info */) {
    // ** addr: 0x658398, size: 0x8c
    // 0x658398: EnterFrame
    //     0x658398: stp             fp, lr, [SP, #-0x10]!
    //     0x65839c: mov             fp, SP
    // 0x6583a0: CheckStackOverflow
    //     0x6583a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6583a4: cmp             SP, x16
    //     0x6583a8: b.ls            #0x65841c
    // 0x6583ac: ldr             x16, [fp, #0x18]
    // 0x6583b0: ldr             lr, [fp, #0x10]
    // 0x6583b4: stp             lr, x16, [SP, #-0x10]!
    // 0x6583b8: r0 = RectExtension.topIsSame()
    //     0x6583b8: bl              #0x658d2c  ; [package:extended_image/src/utils.dart] ::RectExtension.topIsSame
    // 0x6583bc: add             SP, SP, #0x10
    // 0x6583c0: tbnz            w0, #4, #0x65840c
    // 0x6583c4: ldr             x16, [fp, #0x18]
    // 0x6583c8: ldr             lr, [fp, #0x10]
    // 0x6583cc: stp             lr, x16, [SP, #-0x10]!
    // 0x6583d0: r0 = RectExtension.leftIsSame()
    //     0x6583d0: bl              #0x658cac  ; [package:extended_image/src/utils.dart] ::RectExtension.leftIsSame
    // 0x6583d4: add             SP, SP, #0x10
    // 0x6583d8: tbnz            w0, #4, #0x65840c
    // 0x6583dc: ldr             x16, [fp, #0x18]
    // 0x6583e0: ldr             lr, [fp, #0x10]
    // 0x6583e4: stp             lr, x16, [SP, #-0x10]!
    // 0x6583e8: r0 = RectExtension.rightIsSame()
    //     0x6583e8: bl              #0x658b58  ; [package:extended_image/src/utils.dart] ::RectExtension.rightIsSame
    // 0x6583ec: add             SP, SP, #0x10
    // 0x6583f0: tbnz            w0, #4, #0x65840c
    // 0x6583f4: ldr             x16, [fp, #0x18]
    // 0x6583f8: ldr             lr, [fp, #0x10]
    // 0x6583fc: stp             lr, x16, [SP, #-0x10]!
    // 0x658400: r0 = RectExtension.bottomIsSame()
    //     0x658400: bl              #0x658c2c  ; [package:extended_image/src/utils.dart] ::RectExtension.bottomIsSame
    // 0x658404: add             SP, SP, #0x10
    // 0x658408: b               #0x658410
    // 0x65840c: r0 = false
    //     0x65840c: add             x0, NULL, #0x30  ; false
    // 0x658410: LeaveFrame
    //     0x658410: mov             SP, fp
    //     0x658414: ldp             fp, lr, [SP], #0x10
    // 0x658418: ret
    //     0x658418: ret             
    // 0x65841c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65841c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658420: b               #0x6583ac
  }
  static _ DoubleExtension.lessThanOrEqualTo(/* No info */) {
    // ** addr: 0x6589e8, size: 0x54
    // 0x6589e8: EnterFrame
    //     0x6589e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6589ec: mov             fp, SP
    // 0x6589f0: CheckStackOverflow
    //     0x6589f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6589f4: cmp             SP, x16
    //     0x6589f8: b.ls            #0x658a34
    // 0x6589fc: ldr             x16, [fp, #0x18]
    // 0x658a00: SaveReg r16
    //     0x658a00: str             x16, [SP, #-8]!
    // 0x658a04: ldr             d0, [fp, #0x10]
    // 0x658a08: SaveReg d0
    //     0x658a08: str             d0, [SP, #-8]!
    // 0x658a0c: r0 = DoubleExtension.compare()
    //     0x658a0c: bl              #0x658a3c  ; [package:extended_image/src/utils.dart] ::DoubleExtension.compare
    // 0x658a10: add             SP, SP, #0x10
    // 0x658a14: cmp             x0, #0
    // 0x658a18: r16 = true
    //     0x658a18: add             x16, NULL, #0x20  ; true
    // 0x658a1c: r17 = false
    //     0x658a1c: add             x17, NULL, #0x30  ; false
    // 0x658a20: csel            x1, x16, x17, le
    // 0x658a24: mov             x0, x1
    // 0x658a28: LeaveFrame
    //     0x658a28: mov             SP, fp
    //     0x658a2c: ldp             fp, lr, [SP], #0x10
    // 0x658a30: ret
    //     0x658a30: ret             
    // 0x658a34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x658a34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658a38: b               #0x6589fc
  }
  static _ DoubleExtension.compare(/* No info */) {
    // ** addr: 0x658a3c, size: 0xc8
    // 0x658a3c: EnterFrame
    //     0x658a3c: stp             fp, lr, [SP, #-0x10]!
    //     0x658a40: mov             fp, SP
    // 0x658a44: ldr             x0, [fp, #0x18]
    // 0x658a48: LoadField: d0 = r0->field_7
    //     0x658a48: ldur            d0, [x0, #7]
    // 0x658a4c: fcmp            d0, d0
    // 0x658a50: b.vs            #0x658ae4
    // 0x658a54: ldr             d0, [fp, #0x10]
    // 0x658a58: fcmp            d0, d0
    // 0x658a5c: b.vs            #0x658ae4
    // 0x658a60: d1 = 0.000000
    //     0x658a60: eor             v1.16b, v1.16b, v1.16b
    // 0x658a64: LoadField: d2 = r0->field_7
    //     0x658a64: ldur            d2, [x0, #7]
    // 0x658a68: fsub            d3, d2, d0
    // 0x658a6c: fcmp            d3, d1
    // 0x658a70: b.vs            #0x658a80
    // 0x658a74: b.ne            #0x658a80
    // 0x658a78: d2 = 0.000000
    //     0x658a78: eor             v2.16b, v2.16b, v2.16b
    // 0x658a7c: b               #0x658a9c
    // 0x658a80: fcmp            d3, d1
    // 0x658a84: b.vs            #0x658a94
    // 0x658a88: b.ge            #0x658a94
    // 0x658a8c: fneg            d0, d3
    // 0x658a90: b               #0x658a98
    // 0x658a94: mov             v0.16b, v3.16b
    // 0x658a98: mov             v2.16b, v0.16b
    // 0x658a9c: d0 = 0.000000
    //     0x658a9c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0x658aa0: ldr             d0, [x17, #0x1e0]
    // 0x658aa4: fcmp            d2, d0
    // 0x658aa8: b.vs            #0x658ac0
    // 0x658aac: b.ge            #0x658ac0
    // 0x658ab0: r0 = 0
    //     0x658ab0: mov             x0, #0
    // 0x658ab4: LeaveFrame
    //     0x658ab4: mov             SP, fp
    //     0x658ab8: ldp             fp, lr, [SP], #0x10
    // 0x658abc: ret
    //     0x658abc: ret             
    // 0x658ac0: fcmp            d3, d1
    // 0x658ac4: b.vs            #0x658ad4
    // 0x658ac8: b.ge            #0x658ad4
    // 0x658acc: r0 = -1
    //     0x658acc: mov             x0, #-1
    // 0x658ad0: b               #0x658ad8
    // 0x658ad4: r0 = 1
    //     0x658ad4: mov             x0, #1
    // 0x658ad8: LeaveFrame
    //     0x658ad8: mov             SP, fp
    //     0x658adc: ldp             fp, lr, [SP], #0x10
    // 0x658ae0: ret
    //     0x658ae0: ret             
    // 0x658ae4: r0 = UnsupportedError()
    //     0x658ae4: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x658ae8: mov             x1, x0
    // 0x658aec: r0 = "Compared with Infinity or NaN"
    //     0x658aec: add             x0, PP, #0x38, lsl #12  ; [pp+0x38488] "Compared with Infinity or NaN"
    //     0x658af0: ldr             x0, [x0, #0x488]
    // 0x658af4: StoreField: r1->field_b = r0
    //     0x658af4: stur            w0, [x1, #0xb]
    // 0x658af8: mov             x0, x1
    // 0x658afc: r0 = Throw()
    //     0x658afc: bl              #0xd67e38  ; ThrowStub
    // 0x658b00: brk             #0
  }
  static _ DoubleExtension.greaterThanOrEqualTo(/* No info */) {
    // ** addr: 0x658b04, size: 0x54
    // 0x658b04: EnterFrame
    //     0x658b04: stp             fp, lr, [SP, #-0x10]!
    //     0x658b08: mov             fp, SP
    // 0x658b0c: CheckStackOverflow
    //     0x658b0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x658b10: cmp             SP, x16
    //     0x658b14: b.ls            #0x658b50
    // 0x658b18: ldr             x16, [fp, #0x18]
    // 0x658b1c: SaveReg r16
    //     0x658b1c: str             x16, [SP, #-8]!
    // 0x658b20: ldr             d0, [fp, #0x10]
    // 0x658b24: SaveReg d0
    //     0x658b24: str             d0, [SP, #-8]!
    // 0x658b28: r0 = DoubleExtension.compare()
    //     0x658b28: bl              #0x658a3c  ; [package:extended_image/src/utils.dart] ::DoubleExtension.compare
    // 0x658b2c: add             SP, SP, #0x10
    // 0x658b30: tbz             x0, #0x3f, #0x658b3c
    // 0x658b34: r1 = false
    //     0x658b34: add             x1, NULL, #0x30  ; false
    // 0x658b38: b               #0x658b40
    // 0x658b3c: r1 = true
    //     0x658b3c: add             x1, NULL, #0x20  ; true
    // 0x658b40: mov             x0, x1
    // 0x658b44: LeaveFrame
    //     0x658b44: mov             SP, fp
    //     0x658b48: ldp             fp, lr, [SP], #0x10
    // 0x658b4c: ret
    //     0x658b4c: ret             
    // 0x658b50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x658b50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658b54: b               #0x658b18
  }
  static _ RectExtension.rightIsSame(/* No info */) {
    // ** addr: 0x658b58, size: 0x80
    // 0x658b58: EnterFrame
    //     0x658b58: stp             fp, lr, [SP, #-0x10]!
    //     0x658b5c: mov             fp, SP
    // 0x658b60: CheckStackOverflow
    //     0x658b60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x658b64: cmp             SP, x16
    //     0x658b68: b.ls            #0x658bc0
    // 0x658b6c: ldr             x0, [fp, #0x18]
    // 0x658b70: LoadField: d0 = r0->field_17
    //     0x658b70: ldur            d0, [x0, #0x17]
    // 0x658b74: ldr             x0, [fp, #0x10]
    // 0x658b78: LoadField: d1 = r0->field_17
    //     0x658b78: ldur            d1, [x0, #0x17]
    // 0x658b7c: r0 = inline_Allocate_Double()
    //     0x658b7c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x658b80: add             x0, x0, #0x10
    //     0x658b84: cmp             x1, x0
    //     0x658b88: b.ls            #0x658bc8
    //     0x658b8c: str             x0, [THR, #0x60]  ; THR::top
    //     0x658b90: sub             x0, x0, #0xf
    //     0x658b94: mov             x1, #0xd108
    //     0x658b98: movk            x1, #3, lsl #16
    //     0x658b9c: stur            x1, [x0, #-1]
    // 0x658ba0: StoreField: r0->field_7 = d0
    //     0x658ba0: stur            d0, [x0, #7]
    // 0x658ba4: SaveReg r0
    //     0x658ba4: str             x0, [SP, #-8]!
    // 0x658ba8: SaveReg d1
    //     0x658ba8: str             d1, [SP, #-8]!
    // 0x658bac: r0 = DoubleExtension.equalTo()
    //     0x658bac: bl              #0x658bd8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.equalTo
    // 0x658bb0: add             SP, SP, #0x10
    // 0x658bb4: LeaveFrame
    //     0x658bb4: mov             SP, fp
    //     0x658bb8: ldp             fp, lr, [SP], #0x10
    // 0x658bbc: ret
    //     0x658bbc: ret             
    // 0x658bc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x658bc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658bc4: b               #0x658b6c
    // 0x658bc8: stp             q0, q1, [SP, #-0x20]!
    // 0x658bcc: r0 = AllocateDouble()
    //     0x658bcc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658bd0: ldp             q0, q1, [SP], #0x20
    // 0x658bd4: b               #0x658ba0
  }
  static _ DoubleExtension.equalTo(/* No info */) {
    // ** addr: 0x658bd8, size: 0x54
    // 0x658bd8: EnterFrame
    //     0x658bd8: stp             fp, lr, [SP, #-0x10]!
    //     0x658bdc: mov             fp, SP
    // 0x658be0: CheckStackOverflow
    //     0x658be0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x658be4: cmp             SP, x16
    //     0x658be8: b.ls            #0x658c24
    // 0x658bec: ldr             x16, [fp, #0x18]
    // 0x658bf0: SaveReg r16
    //     0x658bf0: str             x16, [SP, #-8]!
    // 0x658bf4: ldr             d0, [fp, #0x10]
    // 0x658bf8: SaveReg d0
    //     0x658bf8: str             d0, [SP, #-8]!
    // 0x658bfc: r0 = DoubleExtension.compare()
    //     0x658bfc: bl              #0x658a3c  ; [package:extended_image/src/utils.dart] ::DoubleExtension.compare
    // 0x658c00: add             SP, SP, #0x10
    // 0x658c04: cbz             x0, #0x658c10
    // 0x658c08: r1 = false
    //     0x658c08: add             x1, NULL, #0x30  ; false
    // 0x658c0c: b               #0x658c14
    // 0x658c10: r1 = true
    //     0x658c10: add             x1, NULL, #0x20  ; true
    // 0x658c14: mov             x0, x1
    // 0x658c18: LeaveFrame
    //     0x658c18: mov             SP, fp
    //     0x658c1c: ldp             fp, lr, [SP], #0x10
    // 0x658c20: ret
    //     0x658c20: ret             
    // 0x658c24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x658c24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658c28: b               #0x658bec
  }
  static _ RectExtension.bottomIsSame(/* No info */) {
    // ** addr: 0x658c2c, size: 0x80
    // 0x658c2c: EnterFrame
    //     0x658c2c: stp             fp, lr, [SP, #-0x10]!
    //     0x658c30: mov             fp, SP
    // 0x658c34: CheckStackOverflow
    //     0x658c34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x658c38: cmp             SP, x16
    //     0x658c3c: b.ls            #0x658c94
    // 0x658c40: ldr             x0, [fp, #0x18]
    // 0x658c44: LoadField: d0 = r0->field_1f
    //     0x658c44: ldur            d0, [x0, #0x1f]
    // 0x658c48: ldr             x0, [fp, #0x10]
    // 0x658c4c: LoadField: d1 = r0->field_1f
    //     0x658c4c: ldur            d1, [x0, #0x1f]
    // 0x658c50: r0 = inline_Allocate_Double()
    //     0x658c50: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x658c54: add             x0, x0, #0x10
    //     0x658c58: cmp             x1, x0
    //     0x658c5c: b.ls            #0x658c9c
    //     0x658c60: str             x0, [THR, #0x60]  ; THR::top
    //     0x658c64: sub             x0, x0, #0xf
    //     0x658c68: mov             x1, #0xd108
    //     0x658c6c: movk            x1, #3, lsl #16
    //     0x658c70: stur            x1, [x0, #-1]
    // 0x658c74: StoreField: r0->field_7 = d0
    //     0x658c74: stur            d0, [x0, #7]
    // 0x658c78: SaveReg r0
    //     0x658c78: str             x0, [SP, #-8]!
    // 0x658c7c: SaveReg d1
    //     0x658c7c: str             d1, [SP, #-8]!
    // 0x658c80: r0 = DoubleExtension.equalTo()
    //     0x658c80: bl              #0x658bd8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.equalTo
    // 0x658c84: add             SP, SP, #0x10
    // 0x658c88: LeaveFrame
    //     0x658c88: mov             SP, fp
    //     0x658c8c: ldp             fp, lr, [SP], #0x10
    // 0x658c90: ret
    //     0x658c90: ret             
    // 0x658c94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x658c94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658c98: b               #0x658c40
    // 0x658c9c: stp             q0, q1, [SP, #-0x20]!
    // 0x658ca0: r0 = AllocateDouble()
    //     0x658ca0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658ca4: ldp             q0, q1, [SP], #0x20
    // 0x658ca8: b               #0x658c74
  }
  static _ RectExtension.leftIsSame(/* No info */) {
    // ** addr: 0x658cac, size: 0x80
    // 0x658cac: EnterFrame
    //     0x658cac: stp             fp, lr, [SP, #-0x10]!
    //     0x658cb0: mov             fp, SP
    // 0x658cb4: CheckStackOverflow
    //     0x658cb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x658cb8: cmp             SP, x16
    //     0x658cbc: b.ls            #0x658d14
    // 0x658cc0: ldr             x0, [fp, #0x18]
    // 0x658cc4: LoadField: d0 = r0->field_7
    //     0x658cc4: ldur            d0, [x0, #7]
    // 0x658cc8: ldr             x0, [fp, #0x10]
    // 0x658ccc: LoadField: d1 = r0->field_7
    //     0x658ccc: ldur            d1, [x0, #7]
    // 0x658cd0: r0 = inline_Allocate_Double()
    //     0x658cd0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x658cd4: add             x0, x0, #0x10
    //     0x658cd8: cmp             x1, x0
    //     0x658cdc: b.ls            #0x658d1c
    //     0x658ce0: str             x0, [THR, #0x60]  ; THR::top
    //     0x658ce4: sub             x0, x0, #0xf
    //     0x658ce8: mov             x1, #0xd108
    //     0x658cec: movk            x1, #3, lsl #16
    //     0x658cf0: stur            x1, [x0, #-1]
    // 0x658cf4: StoreField: r0->field_7 = d0
    //     0x658cf4: stur            d0, [x0, #7]
    // 0x658cf8: SaveReg r0
    //     0x658cf8: str             x0, [SP, #-8]!
    // 0x658cfc: SaveReg d1
    //     0x658cfc: str             d1, [SP, #-8]!
    // 0x658d00: r0 = DoubleExtension.equalTo()
    //     0x658d00: bl              #0x658bd8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.equalTo
    // 0x658d04: add             SP, SP, #0x10
    // 0x658d08: LeaveFrame
    //     0x658d08: mov             SP, fp
    //     0x658d0c: ldp             fp, lr, [SP], #0x10
    // 0x658d10: ret
    //     0x658d10: ret             
    // 0x658d14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x658d14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658d18: b               #0x658cc0
    // 0x658d1c: stp             q0, q1, [SP, #-0x20]!
    // 0x658d20: r0 = AllocateDouble()
    //     0x658d20: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658d24: ldp             q0, q1, [SP], #0x20
    // 0x658d28: b               #0x658cf4
  }
  static _ RectExtension.topIsSame(/* No info */) {
    // ** addr: 0x658d2c, size: 0x80
    // 0x658d2c: EnterFrame
    //     0x658d2c: stp             fp, lr, [SP, #-0x10]!
    //     0x658d30: mov             fp, SP
    // 0x658d34: CheckStackOverflow
    //     0x658d34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x658d38: cmp             SP, x16
    //     0x658d3c: b.ls            #0x658d94
    // 0x658d40: ldr             x0, [fp, #0x18]
    // 0x658d44: LoadField: d0 = r0->field_f
    //     0x658d44: ldur            d0, [x0, #0xf]
    // 0x658d48: ldr             x0, [fp, #0x10]
    // 0x658d4c: LoadField: d1 = r0->field_f
    //     0x658d4c: ldur            d1, [x0, #0xf]
    // 0x658d50: r0 = inline_Allocate_Double()
    //     0x658d50: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x658d54: add             x0, x0, #0x10
    //     0x658d58: cmp             x1, x0
    //     0x658d5c: b.ls            #0x658d9c
    //     0x658d60: str             x0, [THR, #0x60]  ; THR::top
    //     0x658d64: sub             x0, x0, #0xf
    //     0x658d68: mov             x1, #0xd108
    //     0x658d6c: movk            x1, #3, lsl #16
    //     0x658d70: stur            x1, [x0, #-1]
    // 0x658d74: StoreField: r0->field_7 = d0
    //     0x658d74: stur            d0, [x0, #7]
    // 0x658d78: SaveReg r0
    //     0x658d78: str             x0, [SP, #-8]!
    // 0x658d7c: SaveReg d1
    //     0x658d7c: str             d1, [SP, #-8]!
    // 0x658d80: r0 = DoubleExtension.equalTo()
    //     0x658d80: bl              #0x658bd8  ; [package:extended_image/src/utils.dart] ::DoubleExtension.equalTo
    // 0x658d84: add             SP, SP, #0x10
    // 0x658d88: LeaveFrame
    //     0x658d88: mov             SP, fp
    //     0x658d8c: ldp             fp, lr, [SP], #0x10
    // 0x658d90: ret
    //     0x658d90: ret             
    // 0x658d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x658d94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x658d98: b               #0x658d40
    // 0x658d9c: stp             q0, q1, [SP, #-0x20]!
    // 0x658da0: r0 = AllocateDouble()
    //     0x658da0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x658da4: ldp             q0, q1, [SP], #0x20
    // 0x658da8: b               #0x658d74
  }
  static _ RectExtension.beyond(/* No info */) {
    // ** addr: 0x659734, size: 0x1c0
    // 0x659734: EnterFrame
    //     0x659734: stp             fp, lr, [SP, #-0x10]!
    //     0x659738: mov             fp, SP
    // 0x65973c: CheckStackOverflow
    //     0x65973c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x659740: cmp             SP, x16
    //     0x659744: b.ls            #0x659888
    // 0x659748: ldr             x0, [fp, #0x18]
    // 0x65974c: LoadField: d0 = r0->field_7
    //     0x65974c: ldur            d0, [x0, #7]
    // 0x659750: ldr             x1, [fp, #0x10]
    // 0x659754: LoadField: d1 = r1->field_7
    //     0x659754: ldur            d1, [x1, #7]
    // 0x659758: r2 = inline_Allocate_Double()
    //     0x659758: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x65975c: add             x2, x2, #0x10
    //     0x659760: cmp             x3, x2
    //     0x659764: b.ls            #0x659890
    //     0x659768: str             x2, [THR, #0x60]  ; THR::top
    //     0x65976c: sub             x2, x2, #0xf
    //     0x659770: mov             x3, #0xd108
    //     0x659774: movk            x3, #3, lsl #16
    //     0x659778: stur            x3, [x2, #-1]
    // 0x65977c: StoreField: r2->field_7 = d0
    //     0x65977c: stur            d0, [x2, #7]
    // 0x659780: SaveReg r2
    //     0x659780: str             x2, [SP, #-8]!
    // 0x659784: SaveReg d1
    //     0x659784: str             d1, [SP, #-8]!
    // 0x659788: r0 = DoubleExtension.lessThan()
    //     0x659788: bl              #0x659948  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThan
    // 0x65978c: add             SP, SP, #0x10
    // 0x659790: tbz             w0, #4, #0x65982c
    // 0x659794: ldr             x0, [fp, #0x18]
    // 0x659798: ldr             x1, [fp, #0x10]
    // 0x65979c: LoadField: d0 = r0->field_17
    //     0x65979c: ldur            d0, [x0, #0x17]
    // 0x6597a0: LoadField: d1 = r1->field_17
    //     0x6597a0: ldur            d1, [x1, #0x17]
    // 0x6597a4: r2 = inline_Allocate_Double()
    //     0x6597a4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x6597a8: add             x2, x2, #0x10
    //     0x6597ac: cmp             x3, x2
    //     0x6597b0: b.ls            #0x6598ac
    //     0x6597b4: str             x2, [THR, #0x60]  ; THR::top
    //     0x6597b8: sub             x2, x2, #0xf
    //     0x6597bc: mov             x3, #0xd108
    //     0x6597c0: movk            x3, #3, lsl #16
    //     0x6597c4: stur            x3, [x2, #-1]
    // 0x6597c8: StoreField: r2->field_7 = d0
    //     0x6597c8: stur            d0, [x2, #7]
    // 0x6597cc: SaveReg r2
    //     0x6597cc: str             x2, [SP, #-8]!
    // 0x6597d0: SaveReg d1
    //     0x6597d0: str             d1, [SP, #-8]!
    // 0x6597d4: r0 = DoubleExtension.greaterThan()
    //     0x6597d4: bl              #0x6598f4  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThan
    // 0x6597d8: add             SP, SP, #0x10
    // 0x6597dc: tbz             w0, #4, #0x65982c
    // 0x6597e0: ldr             x0, [fp, #0x18]
    // 0x6597e4: ldr             x1, [fp, #0x10]
    // 0x6597e8: LoadField: d0 = r0->field_f
    //     0x6597e8: ldur            d0, [x0, #0xf]
    // 0x6597ec: LoadField: d1 = r1->field_f
    //     0x6597ec: ldur            d1, [x1, #0xf]
    // 0x6597f0: r2 = inline_Allocate_Double()
    //     0x6597f0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x6597f4: add             x2, x2, #0x10
    //     0x6597f8: cmp             x3, x2
    //     0x6597fc: b.ls            #0x6598c8
    //     0x659800: str             x2, [THR, #0x60]  ; THR::top
    //     0x659804: sub             x2, x2, #0xf
    //     0x659808: mov             x3, #0xd108
    //     0x65980c: movk            x3, #3, lsl #16
    //     0x659810: stur            x3, [x2, #-1]
    // 0x659814: StoreField: r2->field_7 = d0
    //     0x659814: stur            d0, [x2, #7]
    // 0x659818: SaveReg r2
    //     0x659818: str             x2, [SP, #-8]!
    // 0x65981c: SaveReg d1
    //     0x65981c: str             d1, [SP, #-8]!
    // 0x659820: r0 = DoubleExtension.lessThan()
    //     0x659820: bl              #0x659948  ; [package:extended_image/src/utils.dart] ::DoubleExtension.lessThan
    // 0x659824: add             SP, SP, #0x10
    // 0x659828: tbnz            w0, #4, #0x659834
    // 0x65982c: r0 = true
    //     0x65982c: add             x0, NULL, #0x20  ; true
    // 0x659830: b               #0x65987c
    // 0x659834: ldr             x0, [fp, #0x18]
    // 0x659838: ldr             x1, [fp, #0x10]
    // 0x65983c: LoadField: d0 = r0->field_1f
    //     0x65983c: ldur            d0, [x0, #0x1f]
    // 0x659840: LoadField: d1 = r1->field_1f
    //     0x659840: ldur            d1, [x1, #0x1f]
    // 0x659844: r0 = inline_Allocate_Double()
    //     0x659844: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x659848: add             x0, x0, #0x10
    //     0x65984c: cmp             x1, x0
    //     0x659850: b.ls            #0x6598e4
    //     0x659854: str             x0, [THR, #0x60]  ; THR::top
    //     0x659858: sub             x0, x0, #0xf
    //     0x65985c: mov             x1, #0xd108
    //     0x659860: movk            x1, #3, lsl #16
    //     0x659864: stur            x1, [x0, #-1]
    // 0x659868: StoreField: r0->field_7 = d0
    //     0x659868: stur            d0, [x0, #7]
    // 0x65986c: SaveReg r0
    //     0x65986c: str             x0, [SP, #-8]!
    // 0x659870: SaveReg d1
    //     0x659870: str             d1, [SP, #-8]!
    // 0x659874: r0 = DoubleExtension.greaterThan()
    //     0x659874: bl              #0x6598f4  ; [package:extended_image/src/utils.dart] ::DoubleExtension.greaterThan
    // 0x659878: add             SP, SP, #0x10
    // 0x65987c: LeaveFrame
    //     0x65987c: mov             SP, fp
    //     0x659880: ldp             fp, lr, [SP], #0x10
    // 0x659884: ret
    //     0x659884: ret             
    // 0x659888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x659888: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65988c: b               #0x659748
    // 0x659890: stp             q0, q1, [SP, #-0x20]!
    // 0x659894: stp             x0, x1, [SP, #-0x10]!
    // 0x659898: r0 = AllocateDouble()
    //     0x659898: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65989c: mov             x2, x0
    // 0x6598a0: ldp             x0, x1, [SP], #0x10
    // 0x6598a4: ldp             q0, q1, [SP], #0x20
    // 0x6598a8: b               #0x65977c
    // 0x6598ac: stp             q0, q1, [SP, #-0x20]!
    // 0x6598b0: stp             x0, x1, [SP, #-0x10]!
    // 0x6598b4: r0 = AllocateDouble()
    //     0x6598b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6598b8: mov             x2, x0
    // 0x6598bc: ldp             x0, x1, [SP], #0x10
    // 0x6598c0: ldp             q0, q1, [SP], #0x20
    // 0x6598c4: b               #0x6597c8
    // 0x6598c8: stp             q0, q1, [SP, #-0x20]!
    // 0x6598cc: stp             x0, x1, [SP, #-0x10]!
    // 0x6598d0: r0 = AllocateDouble()
    //     0x6598d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6598d4: mov             x2, x0
    // 0x6598d8: ldp             x0, x1, [SP], #0x10
    // 0x6598dc: ldp             q0, q1, [SP], #0x20
    // 0x6598e0: b               #0x659814
    // 0x6598e4: stp             q0, q1, [SP, #-0x20]!
    // 0x6598e8: r0 = AllocateDouble()
    //     0x6598e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6598ec: ldp             q0, q1, [SP], #0x20
    // 0x6598f0: b               #0x659868
  }
  static _ DoubleExtension.greaterThan(/* No info */) {
    // ** addr: 0x6598f4, size: 0x54
    // 0x6598f4: EnterFrame
    //     0x6598f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6598f8: mov             fp, SP
    // 0x6598fc: CheckStackOverflow
    //     0x6598fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x659900: cmp             SP, x16
    //     0x659904: b.ls            #0x659940
    // 0x659908: ldr             x16, [fp, #0x18]
    // 0x65990c: SaveReg r16
    //     0x65990c: str             x16, [SP, #-8]!
    // 0x659910: ldr             d0, [fp, #0x10]
    // 0x659914: SaveReg d0
    //     0x659914: str             d0, [SP, #-8]!
    // 0x659918: r0 = DoubleExtension.compare()
    //     0x659918: bl              #0x658a3c  ; [package:extended_image/src/utils.dart] ::DoubleExtension.compare
    // 0x65991c: add             SP, SP, #0x10
    // 0x659920: cmp             x0, #0
    // 0x659924: r16 = true
    //     0x659924: add             x16, NULL, #0x20  ; true
    // 0x659928: r17 = false
    //     0x659928: add             x17, NULL, #0x30  ; false
    // 0x65992c: csel            x1, x16, x17, gt
    // 0x659930: mov             x0, x1
    // 0x659934: LeaveFrame
    //     0x659934: mov             SP, fp
    //     0x659938: ldp             fp, lr, [SP], #0x10
    // 0x65993c: ret
    //     0x65993c: ret             
    // 0x659940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x659940: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x659944: b               #0x659908
  }
  static _ DoubleExtension.lessThan(/* No info */) {
    // ** addr: 0x659948, size: 0x54
    // 0x659948: EnterFrame
    //     0x659948: stp             fp, lr, [SP, #-0x10]!
    //     0x65994c: mov             fp, SP
    // 0x659950: CheckStackOverflow
    //     0x659950: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x659954: cmp             SP, x16
    //     0x659958: b.ls            #0x659994
    // 0x65995c: ldr             x16, [fp, #0x18]
    // 0x659960: SaveReg r16
    //     0x659960: str             x16, [SP, #-8]!
    // 0x659964: ldr             d0, [fp, #0x10]
    // 0x659968: SaveReg d0
    //     0x659968: str             d0, [SP, #-8]!
    // 0x65996c: r0 = DoubleExtension.compare()
    //     0x65996c: bl              #0x658a3c  ; [package:extended_image/src/utils.dart] ::DoubleExtension.compare
    // 0x659970: add             SP, SP, #0x10
    // 0x659974: tbnz            x0, #0x3f, #0x659980
    // 0x659978: r1 = false
    //     0x659978: add             x1, NULL, #0x30  ; false
    // 0x65997c: b               #0x659984
    // 0x659980: r1 = true
    //     0x659980: add             x1, NULL, #0x20  ; true
    // 0x659984: mov             x0, x1
    // 0x659988: LeaveFrame
    //     0x659988: mov             SP, fp
    //     0x65998c: ldp             fp, lr, [SP], #0x10
    // 0x659990: ret
    //     0x659990: ret             
    // 0x659994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x659994: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x659998: b               #0x65995c
  }
}

// class id: 4496, size: 0x8, field offset: 0x8
abstract class ExtendedImageState extends Object {
}

// class id: 5994, size: 0x14, field offset: 0x14
enum ExtendedImageMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15950, size: 0x5c
    // 0xb15950: EnterFrame
    //     0xb15950: stp             fp, lr, [SP, #-0x10]!
    //     0xb15954: mov             fp, SP
    // 0xb15958: CheckStackOverflow
    //     0xb15958: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1595c: cmp             SP, x16
    //     0xb15960: b.ls            #0xb159a4
    // 0xb15964: r1 = Null
    //     0xb15964: mov             x1, NULL
    // 0xb15968: r2 = 4
    //     0xb15968: mov             x2, #4
    // 0xb1596c: r0 = AllocateArray()
    //     0xb1596c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15970: r17 = "ExtendedImageMode."
    //     0xb15970: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2f0a8] "ExtendedImageMode."
    //     0xb15974: ldr             x17, [x17, #0xa8]
    // 0xb15978: StoreField: r0->field_f = r17
    //     0xb15978: stur            w17, [x0, #0xf]
    // 0xb1597c: ldr             x1, [fp, #0x10]
    // 0xb15980: LoadField: r2 = r1->field_f
    //     0xb15980: ldur            w2, [x1, #0xf]
    // 0xb15984: DecompressPointer r2
    //     0xb15984: add             x2, x2, HEAP, lsl #32
    // 0xb15988: StoreField: r0->field_13 = r2
    //     0xb15988: stur            w2, [x0, #0x13]
    // 0xb1598c: SaveReg r0
    //     0xb1598c: str             x0, [SP, #-8]!
    // 0xb15990: r0 = _interpolate()
    //     0xb15990: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15994: add             SP, SP, #8
    // 0xb15998: LeaveFrame
    //     0xb15998: mov             SP, fp
    //     0xb1599c: ldp             fp, lr, [SP], #0x10
    // 0xb159a0: ret
    //     0xb159a0: ret             
    // 0xb159a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb159a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb159a8: b               #0xb15964
  }
}

// class id: 5995, size: 0x14, field offset: 0x14
enum LoadState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb158f4, size: 0x5c
    // 0xb158f4: EnterFrame
    //     0xb158f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb158f8: mov             fp, SP
    // 0xb158fc: CheckStackOverflow
    //     0xb158fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15900: cmp             SP, x16
    //     0xb15904: b.ls            #0xb15948
    // 0xb15908: r1 = Null
    //     0xb15908: mov             x1, NULL
    // 0xb1590c: r2 = 4
    //     0xb1590c: mov             x2, #4
    // 0xb15910: r0 = AllocateArray()
    //     0xb15910: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15914: r17 = "LoadState."
    //     0xb15914: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2f0b0] "LoadState."
    //     0xb15918: ldr             x17, [x17, #0xb0]
    // 0xb1591c: StoreField: r0->field_f = r17
    //     0xb1591c: stur            w17, [x0, #0xf]
    // 0xb15920: ldr             x1, [fp, #0x10]
    // 0xb15924: LoadField: r2 = r1->field_f
    //     0xb15924: ldur            w2, [x1, #0xf]
    // 0xb15928: DecompressPointer r2
    //     0xb15928: add             x2, x2, HEAP, lsl #32
    // 0xb1592c: StoreField: r0->field_13 = r2
    //     0xb1592c: stur            w2, [x0, #0x13]
    // 0xb15930: SaveReg r0
    //     0xb15930: str             x0, [SP, #-8]!
    // 0xb15934: r0 = _interpolate()
    //     0xb15934: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15938: add             SP, SP, #8
    // 0xb1593c: LeaveFrame
    //     0xb1593c: mov             SP, fp
    //     0xb15940: ldp             fp, lr, [SP], #0x10
    // 0xb15944: ret
    //     0xb15944: ret             
    // 0xb15948: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15948: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1594c: b               #0xb15908
  }
}

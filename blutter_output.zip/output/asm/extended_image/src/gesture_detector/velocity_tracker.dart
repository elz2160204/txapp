// lib: , url: package:extended_image/src/gesture_detector/velocity_tracker.dart

// class id: 1048941, size: 0x8
class :: {
}

// class id: 4473, size: 0x18, field offset: 0x18
//   transformed mixin,
abstract class _ExtendedVelocityTracker&VelocityTracker&VelocityTrackerMixin extends VelocityTracker
     with VelocityTrackerMixin {

  _ getSamplesDelta(/* No info */) {
    // ** addr: 0x7888d8, size: 0x104
    // 0x7888d8: EnterFrame
    //     0x7888d8: stp             fp, lr, [SP, #-0x10]!
    //     0x7888dc: mov             fp, SP
    // 0x7888e0: CheckStackOverflow
    //     0x7888e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7888e4: cmp             SP, x16
    //     0x7888e8: b.ls            #0x7889c4
    // 0x7888ec: ldr             x0, [fp, #0x10]
    // 0x7888f0: LoadField: r1 = r0->field_17
    //     0x7888f0: ldur            w1, [x0, #0x17]
    // 0x7888f4: DecompressPointer r1
    //     0x7888f4: add             x1, x1, HEAP, lsl #32
    // 0x7888f8: LoadField: r0 = r1->field_b
    //     0x7888f8: ldur            w0, [x1, #0xb]
    // 0x7888fc: DecompressPointer r0
    //     0x7888fc: add             x0, x0, HEAP, lsl #32
    // 0x788900: r2 = LoadInt32Instr(r0)
    //     0x788900: sbfx            x2, x0, #1, #0x1f
    // 0x788904: r0 = 0
    //     0x788904: mov             x0, #0
    // 0x788908: CheckStackOverflow
    //     0x788908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78890c: cmp             SP, x16
    //     0x788910: b.ls            #0x7889cc
    // 0x788914: cmp             x0, x2
    // 0x788918: b.ge            #0x788948
    // 0x78891c: ArrayLoad: r3 = r1[r0]  ; Unknown_4
    //     0x78891c: add             x16, x1, x0, lsl #2
    //     0x788920: ldur            w3, [x16, #0xf]
    // 0x788924: DecompressPointer r3
    //     0x788924: add             x3, x3, HEAP, lsl #32
    // 0x788928: cmp             w3, NULL
    // 0x78892c: b.eq            #0x78893c
    // 0x788930: LoadField: r0 = r3->field_b
    //     0x788930: ldur            w0, [x3, #0xb]
    // 0x788934: DecompressPointer r0
    //     0x788934: add             x0, x0, HEAP, lsl #32
    // 0x788938: b               #0x78894c
    // 0x78893c: add             x3, x0, #1
    // 0x788940: mov             x0, x3
    // 0x788944: b               #0x788908
    // 0x788948: r0 = Null
    //     0x788948: mov             x0, NULL
    // 0x78894c: sub             x3, x2, #1
    // 0x788950: mov             x2, x3
    // 0x788954: CheckStackOverflow
    //     0x788954: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x788958: cmp             SP, x16
    //     0x78895c: b.ls            #0x7889d4
    // 0x788960: tbnz            x2, #0x3f, #0x788990
    // 0x788964: ArrayLoad: r3 = r1[r2]  ; Unknown_4
    //     0x788964: add             x16, x1, x2, lsl #2
    //     0x788968: ldur            w3, [x16, #0xf]
    // 0x78896c: DecompressPointer r3
    //     0x78896c: add             x3, x3, HEAP, lsl #32
    // 0x788970: cmp             w3, NULL
    // 0x788974: b.eq            #0x788984
    // 0x788978: LoadField: r1 = r3->field_b
    //     0x788978: ldur            w1, [x3, #0xb]
    // 0x78897c: DecompressPointer r1
    //     0x78897c: add             x1, x1, HEAP, lsl #32
    // 0x788980: b               #0x788994
    // 0x788984: sub             x3, x2, #1
    // 0x788988: mov             x2, x3
    // 0x78898c: b               #0x788954
    // 0x788990: r1 = Null
    //     0x788990: mov             x1, NULL
    // 0x788994: cmp             w1, NULL
    // 0x788998: b.ne            #0x7889a0
    // 0x78899c: r1 = Instance_Offset
    //     0x78899c: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x7889a0: cmp             w0, NULL
    // 0x7889a4: b.ne            #0x7889ac
    // 0x7889a8: r0 = Instance_Offset
    //     0x7889a8: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x7889ac: stp             x0, x1, [SP, #-0x10]!
    // 0x7889b0: r0 = -()
    //     0x7889b0: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x7889b4: add             SP, SP, #0x10
    // 0x7889b8: LeaveFrame
    //     0x7889b8: mov             SP, fp
    //     0x7889bc: ldp             fp, lr, [SP], #0x10
    // 0x7889c0: ret
    //     0x7889c0: ret             
    // 0x7889c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7889c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7889c8: b               #0x7888ec
    // 0x7889cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7889cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7889d0: b               #0x788914
    // 0x7889d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7889d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7889d8: b               #0x788960
  }
}

// class id: 4474, size: 0x24, field offset: 0x18
class ExtendedVelocityTracker extends _ExtendedVelocityTracker&VelocityTracker&VelocityTrackerMixin {

  _ getVelocity(/* No info */) {
    // ** addr: 0xc3eab4, size: 0x88
    // 0xc3eab4: EnterFrame
    //     0xc3eab4: stp             fp, lr, [SP, #-0x10]!
    //     0xc3eab8: mov             fp, SP
    // 0xc3eabc: AllocStack(0x8)
    //     0xc3eabc: sub             SP, SP, #8
    // 0xc3eac0: CheckStackOverflow
    //     0xc3eac0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3eac4: cmp             SP, x16
    //     0xc3eac8: b.ls            #0xc3eb34
    // 0xc3eacc: ldr             x16, [fp, #0x10]
    // 0xc3ead0: SaveReg r16
    //     0xc3ead0: str             x16, [SP, #-8]!
    // 0xc3ead4: r0 = getVelocityEstimate()
    //     0xc3ead4: bl              #0xcb32c8  ; [package:extended_image/src/gesture_detector/velocity_tracker.dart] ExtendedVelocityTracker::getVelocityEstimate
    // 0xc3ead8: add             SP, SP, #8
    // 0xc3eadc: cmp             w0, NULL
    // 0xc3eae0: b.eq            #0xc3eb04
    // 0xc3eae4: LoadField: r1 = r0->field_7
    //     0xc3eae4: ldur            w1, [x0, #7]
    // 0xc3eae8: DecompressPointer r1
    //     0xc3eae8: add             x1, x1, HEAP, lsl #32
    // 0xc3eaec: stur            x1, [fp, #-8]
    // 0xc3eaf0: r16 = Instance_Offset
    //     0xc3eaf0: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xc3eaf4: stp             x16, x1, [SP, #-0x10]!
    // 0xc3eaf8: r0 = ==()
    //     0xc3eaf8: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xc3eafc: add             SP, SP, #0x10
    // 0xc3eb00: tbnz            w0, #4, #0xc3eb18
    // 0xc3eb04: r0 = Instance_Velocity
    //     0xc3eb04: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e850] Obj!Velocity@b38701
    //     0xc3eb08: ldr             x0, [x0, #0x850]
    // 0xc3eb0c: LeaveFrame
    //     0xc3eb0c: mov             SP, fp
    //     0xc3eb10: ldp             fp, lr, [SP], #0x10
    // 0xc3eb14: ret
    //     0xc3eb14: ret             
    // 0xc3eb18: ldur            x0, [fp, #-8]
    // 0xc3eb1c: r0 = Velocity()
    //     0xc3eb1c: bl              #0x713f24  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0xc3eb20: ldur            x1, [fp, #-8]
    // 0xc3eb24: StoreField: r0->field_7 = r1
    //     0xc3eb24: stur            w1, [x0, #7]
    // 0xc3eb28: LeaveFrame
    //     0xc3eb28: mov             SP, fp
    //     0xc3eb2c: ldp             fp, lr, [SP], #0x10
    // 0xc3eb30: ret
    //     0xc3eb30: ret             
    // 0xc3eb34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3eb34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3eb38: b               #0xc3eacc
  }
  _ getVelocityEstimate(/* No info */) {
    // ** addr: 0xcb32c8, size: 0x88c
    // 0xcb32c8: EnterFrame
    //     0xcb32c8: stp             fp, lr, [SP, #-0x10]!
    //     0xcb32cc: mov             fp, SP
    // 0xcb32d0: AllocStack(0x90)
    //     0xcb32d0: sub             SP, SP, #0x90
    // 0xcb32d4: CheckStackOverflow
    //     0xcb32d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb32d8: cmp             SP, x16
    //     0xcb32dc: b.ls            #0xcb3aa4
    // 0xcb32e0: r16 = <double>
    //     0xcb32e0: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcb32e4: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb32e8: r0 = _GrowableList()
    //     0xcb32e8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcb32ec: add             SP, SP, #0x10
    // 0xcb32f0: stur            x0, [fp, #-8]
    // 0xcb32f4: r16 = <double>
    //     0xcb32f4: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcb32f8: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb32fc: r0 = _GrowableList()
    //     0xcb32fc: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcb3300: add             SP, SP, #0x10
    // 0xcb3304: stur            x0, [fp, #-0x10]
    // 0xcb3308: r16 = <double>
    //     0xcb3308: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcb330c: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb3310: r0 = _GrowableList()
    //     0xcb3310: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcb3314: add             SP, SP, #0x10
    // 0xcb3318: stur            x0, [fp, #-0x18]
    // 0xcb331c: r16 = <double>
    //     0xcb331c: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcb3320: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb3324: r0 = _GrowableList()
    //     0xcb3324: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcb3328: add             SP, SP, #0x10
    // 0xcb332c: mov             x2, x0
    // 0xcb3330: ldr             x0, [fp, #0x10]
    // 0xcb3334: stur            x2, [fp, #-0x80]
    // 0xcb3338: LoadField: r3 = r0->field_1b
    //     0xcb3338: ldur            x3, [x0, #0x1b]
    // 0xcb333c: LoadField: r4 = r0->field_17
    //     0xcb333c: ldur            w4, [x0, #0x17]
    // 0xcb3340: DecompressPointer r4
    //     0xcb3340: add             x4, x4, HEAP, lsl #32
    // 0xcb3344: stur            x4, [fp, #-0x78]
    // 0xcb3348: LoadField: r0 = r4->field_b
    //     0xcb3348: ldur            w0, [x4, #0xb]
    // 0xcb334c: DecompressPointer r0
    //     0xcb334c: add             x0, x0, HEAP, lsl #32
    // 0xcb3350: r5 = LoadInt32Instr(r0)
    //     0xcb3350: sbfx            x5, x0, #1, #0x1f
    // 0xcb3354: mov             x0, x5
    // 0xcb3358: mov             x1, x3
    // 0xcb335c: stur            x5, [fp, #-0x70]
    // 0xcb3360: cmp             x1, x0
    // 0xcb3364: b.hs            #0xcb3aac
    // 0xcb3368: ArrayLoad: r6 = r4[r3]  ; Unknown_4
    //     0xcb3368: add             x16, x4, x3, lsl #2
    //     0xcb336c: ldur            w6, [x16, #0xf]
    // 0xcb3370: DecompressPointer r6
    //     0xcb3370: add             x6, x6, HEAP, lsl #32
    // 0xcb3374: stur            x6, [fp, #-0x68]
    // 0xcb3378: cmp             w6, NULL
    // 0xcb337c: b.ne            #0xcb3390
    // 0xcb3380: r0 = Null
    //     0xcb3380: mov             x0, NULL
    // 0xcb3384: LeaveFrame
    //     0xcb3384: mov             SP, fp
    //     0xcb3388: ldp             fp, lr, [SP], #0x10
    // 0xcb338c: ret
    //     0xcb338c: ret             
    // 0xcb3390: LoadField: r7 = r6->field_7
    //     0xcb3390: ldur            w7, [x6, #7]
    // 0xcb3394: DecompressPointer r7
    //     0xcb3394: add             x7, x7, HEAP, lsl #32
    // 0xcb3398: stur            x7, [fp, #-0x60]
    // 0xcb339c: LoadField: r8 = r7->field_7
    //     0xcb339c: ldur            x8, [x7, #7]
    // 0xcb33a0: stur            x8, [fp, #-0x58]
    // 0xcb33a4: mov             x13, x3
    // 0xcb33a8: mov             x12, x6
    // 0xcb33ac: mov             x11, x7
    // 0xcb33b0: r14 = 0
    //     0xcb33b0: mov             x14, #0
    // 0xcb33b4: ldur            x10, [fp, #-8]
    // 0xcb33b8: ldur            x9, [fp, #-0x10]
    // 0xcb33bc: ldur            x3, [fp, #-0x18]
    // 0xcb33c0: stur            x14, [fp, #-0x38]
    // 0xcb33c4: stur            x13, [fp, #-0x40]
    // 0xcb33c8: stur            x12, [fp, #-0x48]
    // 0xcb33cc: stur            x11, [fp, #-0x50]
    // 0xcb33d0: CheckStackOverflow
    //     0xcb33d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb33d4: cmp             SP, x16
    //     0xcb33d8: b.ls            #0xcb3ab0
    // 0xcb33dc: mov             x0, x5
    // 0xcb33e0: mov             x1, x13
    // 0xcb33e4: cmp             x1, x0
    // 0xcb33e8: b.hs            #0xcb3ab8
    // 0xcb33ec: ArrayLoad: r19 = r4[r13]  ; Unknown_4
    //     0xcb33ec: add             x16, x4, x13, lsl #2
    //     0xcb33f0: ldur            w19, [x16, #0xf]
    // 0xcb33f4: DecompressPointer r19
    //     0xcb33f4: add             x19, x19, HEAP, lsl #32
    // 0xcb33f8: stur            x19, [fp, #-0x30]
    // 0xcb33fc: cmp             w19, NULL
    // 0xcb3400: b.ne            #0xcb3414
    // 0xcb3404: mov             x3, x14
    // 0xcb3408: mov             x1, x12
    // 0xcb340c: mov             x0, x11
    // 0xcb3410: b               #0xcb37f8
    // 0xcb3414: LoadField: r20 = r19->field_7
    //     0xcb3414: ldur            w20, [x19, #7]
    // 0xcb3418: DecompressPointer r20
    //     0xcb3418: add             x20, x20, HEAP, lsl #32
    // 0xcb341c: stur            x20, [fp, #-0x28]
    // 0xcb3420: LoadField: r23 = r20->field_7
    //     0xcb3420: ldur            x23, [x20, #7]
    // 0xcb3424: stur            x23, [fp, #-0x20]
    // 0xcb3428: sub             x24, x8, x23
    // 0xcb342c: r0 = BoxInt64Instr(r24)
    //     0xcb342c: sbfiz           x0, x24, #1, #0x1f
    //     0xcb3430: cmp             x24, x0, asr #1
    //     0xcb3434: b.eq            #0xcb3440
    //     0xcb3438: bl              #0xd69bb8
    //     0xcb343c: stur            x24, [x0, #7]
    // 0xcb3440: stp             x0, NULL, [SP, #-0x10]!
    // 0xcb3444: r0 = _Double.fromInteger()
    //     0xcb3444: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xcb3448: add             SP, SP, #0x10
    // 0xcb344c: LoadField: d0 = r0->field_7
    //     0xcb344c: ldur            d0, [x0, #7]
    // 0xcb3450: d1 = 1000.000000
    //     0xcb3450: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0xcb3454: ldr             d1, [x17, #0x3b0]
    // 0xcb3458: fdiv            d2, d0, d1
    // 0xcb345c: ldur            x2, [fp, #-0x50]
    // 0xcb3460: stur            d2, [fp, #-0x88]
    // 0xcb3464: LoadField: r0 = r2->field_7
    //     0xcb3464: ldur            x0, [x2, #7]
    // 0xcb3468: ldur            x1, [fp, #-0x20]
    // 0xcb346c: sub             x3, x1, x0
    // 0xcb3470: tbz             x3, #0x3f, #0xcb347c
    // 0xcb3474: neg             x0, x3
    // 0xcb3478: mov             x3, x0
    // 0xcb347c: r0 = BoxInt64Instr(r3)
    //     0xcb347c: sbfiz           x0, x3, #1, #0x1f
    //     0xcb3480: cmp             x3, x0, asr #1
    //     0xcb3484: b.eq            #0xcb3490
    //     0xcb3488: bl              #0xd69c6c
    //     0xcb348c: stur            x3, [x0, #7]
    // 0xcb3490: stp             x0, NULL, [SP, #-0x10]!
    // 0xcb3494: r0 = _Double.fromInteger()
    //     0xcb3494: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xcb3498: add             SP, SP, #0x10
    // 0xcb349c: LoadField: d0 = r0->field_7
    //     0xcb349c: ldur            d0, [x0, #7]
    // 0xcb34a0: d1 = 1000.000000
    //     0xcb34a0: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0xcb34a4: ldr             d1, [x17, #0x3b0]
    // 0xcb34a8: fdiv            d2, d0, d1
    // 0xcb34ac: ldur            d0, [fp, #-0x88]
    // 0xcb34b0: d3 = 100.000000
    //     0xcb34b0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xcb34b4: ldr             d3, [x17, #0x308]
    // 0xcb34b8: fcmp            d0, d3
    // 0xcb34bc: b.vs            #0xcb34c4
    // 0xcb34c0: b.gt            #0xcb34d8
    // 0xcb34c4: d4 = 40.000000
    //     0xcb34c4: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0xcb34c8: ldr             d4, [x17, #0xdc0]
    // 0xcb34cc: fcmp            d2, d4
    // 0xcb34d0: b.vs            #0xcb34ec
    // 0xcb34d4: b.le            #0xcb34ec
    // 0xcb34d8: ldur            x3, [fp, #-0x38]
    // 0xcb34dc: ldur            x1, [fp, #-0x48]
    // 0xcb34e0: ldur            x0, [fp, #-0x50]
    // 0xcb34e4: ldur            x2, [fp, #-0x80]
    // 0xcb34e8: b               #0xcb37f8
    // 0xcb34ec: ldur            x0, [fp, #-8]
    // 0xcb34f0: ldur            x12, [fp, #-0x30]
    // 0xcb34f4: LoadField: r1 = r12->field_b
    //     0xcb34f4: ldur            w1, [x12, #0xb]
    // 0xcb34f8: DecompressPointer r1
    //     0xcb34f8: add             x1, x1, HEAP, lsl #32
    // 0xcb34fc: stur            x1, [fp, #-0x50]
    // 0xcb3500: LoadField: d2 = r1->field_7
    //     0xcb3500: ldur            d2, [x1, #7]
    // 0xcb3504: stur            d2, [fp, #-0x90]
    // 0xcb3508: LoadField: r2 = r0->field_b
    //     0xcb3508: ldur            w2, [x0, #0xb]
    // 0xcb350c: DecompressPointer r2
    //     0xcb350c: add             x2, x2, HEAP, lsl #32
    // 0xcb3510: stur            x2, [fp, #-0x48]
    // 0xcb3514: LoadField: r3 = r0->field_f
    //     0xcb3514: ldur            w3, [x0, #0xf]
    // 0xcb3518: DecompressPointer r3
    //     0xcb3518: add             x3, x3, HEAP, lsl #32
    // 0xcb351c: LoadField: r4 = r3->field_b
    //     0xcb351c: ldur            w4, [x3, #0xb]
    // 0xcb3520: DecompressPointer r4
    //     0xcb3520: add             x4, x4, HEAP, lsl #32
    // 0xcb3524: cmp             w2, w4
    // 0xcb3528: b.ne            #0xcb3538
    // 0xcb352c: SaveReg r0
    //     0xcb352c: str             x0, [SP, #-8]!
    // 0xcb3530: r0 = _growToNextCapacity()
    //     0xcb3530: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcb3534: add             SP, SP, #8
    // 0xcb3538: ldur            x2, [fp, #-8]
    // 0xcb353c: ldur            x4, [fp, #-0x10]
    // 0xcb3540: ldur            x3, [fp, #-0x50]
    // 0xcb3544: ldur            d0, [fp, #-0x90]
    // 0xcb3548: ldur            x0, [fp, #-0x48]
    // 0xcb354c: r5 = LoadInt32Instr(r0)
    //     0xcb354c: sbfx            x5, x0, #1, #0x1f
    // 0xcb3550: add             x0, x5, #1
    // 0xcb3554: lsl             x1, x0, #1
    // 0xcb3558: StoreField: r2->field_b = r1
    //     0xcb3558: stur            w1, [x2, #0xb]
    // 0xcb355c: mov             x1, x5
    // 0xcb3560: cmp             x1, x0
    // 0xcb3564: b.hs            #0xcb3abc
    // 0xcb3568: LoadField: r1 = r2->field_f
    //     0xcb3568: ldur            w1, [x2, #0xf]
    // 0xcb356c: DecompressPointer r1
    //     0xcb356c: add             x1, x1, HEAP, lsl #32
    // 0xcb3570: r0 = inline_Allocate_Double()
    //     0xcb3570: ldp             x0, x6, [THR, #0x60]  ; THR::top
    //     0xcb3574: add             x0, x0, #0x10
    //     0xcb3578: cmp             x6, x0
    //     0xcb357c: b.ls            #0xcb3ac0
    //     0xcb3580: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb3584: sub             x0, x0, #0xf
    //     0xcb3588: mov             x6, #0xd108
    //     0xcb358c: movk            x6, #3, lsl #16
    //     0xcb3590: stur            x6, [x0, #-1]
    // 0xcb3594: StoreField: r0->field_7 = d0
    //     0xcb3594: stur            d0, [x0, #7]
    // 0xcb3598: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcb3598: add             x25, x1, x5, lsl #2
    //     0xcb359c: add             x25, x25, #0xf
    //     0xcb35a0: str             w0, [x25]
    //     0xcb35a4: tbz             w0, #0, #0xcb35c0
    //     0xcb35a8: ldurb           w16, [x1, #-1]
    //     0xcb35ac: ldurb           w17, [x0, #-1]
    //     0xcb35b0: and             x16, x17, x16, lsr #2
    //     0xcb35b4: tst             x16, HEAP, lsr #32
    //     0xcb35b8: b.eq            #0xcb35c0
    //     0xcb35bc: bl              #0xd67e5c
    // 0xcb35c0: LoadField: d0 = r3->field_f
    //     0xcb35c0: ldur            d0, [x3, #0xf]
    // 0xcb35c4: stur            d0, [fp, #-0x90]
    // 0xcb35c8: LoadField: r0 = r4->field_b
    //     0xcb35c8: ldur            w0, [x4, #0xb]
    // 0xcb35cc: DecompressPointer r0
    //     0xcb35cc: add             x0, x0, HEAP, lsl #32
    // 0xcb35d0: stur            x0, [fp, #-0x48]
    // 0xcb35d4: LoadField: r1 = r4->field_f
    //     0xcb35d4: ldur            w1, [x4, #0xf]
    // 0xcb35d8: DecompressPointer r1
    //     0xcb35d8: add             x1, x1, HEAP, lsl #32
    // 0xcb35dc: LoadField: r3 = r1->field_b
    //     0xcb35dc: ldur            w3, [x1, #0xb]
    // 0xcb35e0: DecompressPointer r3
    //     0xcb35e0: add             x3, x3, HEAP, lsl #32
    // 0xcb35e4: cmp             w0, w3
    // 0xcb35e8: b.ne            #0xcb35f8
    // 0xcb35ec: SaveReg r4
    //     0xcb35ec: str             x4, [SP, #-8]!
    // 0xcb35f0: r0 = _growToNextCapacity()
    //     0xcb35f0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcb35f4: add             SP, SP, #8
    // 0xcb35f8: ldur            x2, [fp, #-0x10]
    // 0xcb35fc: ldur            x3, [fp, #-0x18]
    // 0xcb3600: ldur            d0, [fp, #-0x90]
    // 0xcb3604: ldur            x0, [fp, #-0x48]
    // 0xcb3608: r4 = LoadInt32Instr(r0)
    //     0xcb3608: sbfx            x4, x0, #1, #0x1f
    // 0xcb360c: add             x0, x4, #1
    // 0xcb3610: lsl             x1, x0, #1
    // 0xcb3614: StoreField: r2->field_b = r1
    //     0xcb3614: stur            w1, [x2, #0xb]
    // 0xcb3618: mov             x1, x4
    // 0xcb361c: cmp             x1, x0
    // 0xcb3620: b.hs            #0xcb3ae8
    // 0xcb3624: LoadField: r1 = r2->field_f
    //     0xcb3624: ldur            w1, [x2, #0xf]
    // 0xcb3628: DecompressPointer r1
    //     0xcb3628: add             x1, x1, HEAP, lsl #32
    // 0xcb362c: r0 = inline_Allocate_Double()
    //     0xcb362c: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0xcb3630: add             x0, x0, #0x10
    //     0xcb3634: cmp             x5, x0
    //     0xcb3638: b.ls            #0xcb3aec
    //     0xcb363c: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb3640: sub             x0, x0, #0xf
    //     0xcb3644: mov             x5, #0xd108
    //     0xcb3648: movk            x5, #3, lsl #16
    //     0xcb364c: stur            x5, [x0, #-1]
    // 0xcb3650: StoreField: r0->field_7 = d0
    //     0xcb3650: stur            d0, [x0, #7]
    // 0xcb3654: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcb3654: add             x25, x1, x4, lsl #2
    //     0xcb3658: add             x25, x25, #0xf
    //     0xcb365c: str             w0, [x25]
    //     0xcb3660: tbz             w0, #0, #0xcb367c
    //     0xcb3664: ldurb           w16, [x1, #-1]
    //     0xcb3668: ldurb           w17, [x0, #-1]
    //     0xcb366c: and             x16, x17, x16, lsr #2
    //     0xcb3670: tst             x16, HEAP, lsr #32
    //     0xcb3674: b.eq            #0xcb367c
    //     0xcb3678: bl              #0xd67e5c
    // 0xcb367c: LoadField: r0 = r3->field_b
    //     0xcb367c: ldur            w0, [x3, #0xb]
    // 0xcb3680: DecompressPointer r0
    //     0xcb3680: add             x0, x0, HEAP, lsl #32
    // 0xcb3684: stur            x0, [fp, #-0x48]
    // 0xcb3688: LoadField: r1 = r3->field_f
    //     0xcb3688: ldur            w1, [x3, #0xf]
    // 0xcb368c: DecompressPointer r1
    //     0xcb368c: add             x1, x1, HEAP, lsl #32
    // 0xcb3690: LoadField: r4 = r1->field_b
    //     0xcb3690: ldur            w4, [x1, #0xb]
    // 0xcb3694: DecompressPointer r4
    //     0xcb3694: add             x4, x4, HEAP, lsl #32
    // 0xcb3698: cmp             w0, w4
    // 0xcb369c: b.ne            #0xcb36ac
    // 0xcb36a0: SaveReg r3
    //     0xcb36a0: str             x3, [SP, #-8]!
    // 0xcb36a4: r0 = _growToNextCapacity()
    //     0xcb36a4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcb36a8: add             SP, SP, #8
    // 0xcb36ac: ldur            x2, [fp, #-0x18]
    // 0xcb36b0: ldur            x3, [fp, #-0x80]
    // 0xcb36b4: ldur            d0, [fp, #-0x88]
    // 0xcb36b8: ldur            x0, [fp, #-0x48]
    // 0xcb36bc: r4 = LoadInt32Instr(r0)
    //     0xcb36bc: sbfx            x4, x0, #1, #0x1f
    // 0xcb36c0: add             x0, x4, #1
    // 0xcb36c4: lsl             x1, x0, #1
    // 0xcb36c8: StoreField: r2->field_b = r1
    //     0xcb36c8: stur            w1, [x2, #0xb]
    // 0xcb36cc: mov             x1, x4
    // 0xcb36d0: cmp             x1, x0
    // 0xcb36d4: b.hs            #0xcb3b0c
    // 0xcb36d8: LoadField: r0 = r2->field_f
    //     0xcb36d8: ldur            w0, [x2, #0xf]
    // 0xcb36dc: DecompressPointer r0
    //     0xcb36dc: add             x0, x0, HEAP, lsl #32
    // 0xcb36e0: add             x1, x0, x4, lsl #2
    // 0xcb36e4: r17 = 1.000000
    //     0xcb36e4: ldr             x17, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xcb36e8: StoreField: r1->field_f = r17
    //     0xcb36e8: stur            w17, [x1, #0xf]
    // 0xcb36ec: fneg            d1, d0
    // 0xcb36f0: stur            d1, [fp, #-0x90]
    // 0xcb36f4: LoadField: r0 = r3->field_b
    //     0xcb36f4: ldur            w0, [x3, #0xb]
    // 0xcb36f8: DecompressPointer r0
    //     0xcb36f8: add             x0, x0, HEAP, lsl #32
    // 0xcb36fc: stur            x0, [fp, #-0x48]
    // 0xcb3700: LoadField: r1 = r3->field_f
    //     0xcb3700: ldur            w1, [x3, #0xf]
    // 0xcb3704: DecompressPointer r1
    //     0xcb3704: add             x1, x1, HEAP, lsl #32
    // 0xcb3708: LoadField: r4 = r1->field_b
    //     0xcb3708: ldur            w4, [x1, #0xb]
    // 0xcb370c: DecompressPointer r4
    //     0xcb370c: add             x4, x4, HEAP, lsl #32
    // 0xcb3710: cmp             w0, w4
    // 0xcb3714: b.ne            #0xcb3724
    // 0xcb3718: SaveReg r3
    //     0xcb3718: str             x3, [SP, #-8]!
    // 0xcb371c: r0 = _growToNextCapacity()
    //     0xcb371c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcb3720: add             SP, SP, #8
    // 0xcb3724: ldur            x2, [fp, #-0x80]
    // 0xcb3728: ldur            x3, [fp, #-0x40]
    // 0xcb372c: ldur            d0, [fp, #-0x90]
    // 0xcb3730: ldur            x0, [fp, #-0x48]
    // 0xcb3734: r4 = LoadInt32Instr(r0)
    //     0xcb3734: sbfx            x4, x0, #1, #0x1f
    // 0xcb3738: add             x0, x4, #1
    // 0xcb373c: lsl             x1, x0, #1
    // 0xcb3740: StoreField: r2->field_b = r1
    //     0xcb3740: stur            w1, [x2, #0xb]
    // 0xcb3744: mov             x1, x4
    // 0xcb3748: cmp             x1, x0
    // 0xcb374c: b.hs            #0xcb3b10
    // 0xcb3750: LoadField: r1 = r2->field_f
    //     0xcb3750: ldur            w1, [x2, #0xf]
    // 0xcb3754: DecompressPointer r1
    //     0xcb3754: add             x1, x1, HEAP, lsl #32
    // 0xcb3758: r0 = inline_Allocate_Double()
    //     0xcb3758: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0xcb375c: add             x0, x0, #0x10
    //     0xcb3760: cmp             x5, x0
    //     0xcb3764: b.ls            #0xcb3b14
    //     0xcb3768: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb376c: sub             x0, x0, #0xf
    //     0xcb3770: mov             x5, #0xd108
    //     0xcb3774: movk            x5, #3, lsl #16
    //     0xcb3778: stur            x5, [x0, #-1]
    // 0xcb377c: StoreField: r0->field_7 = d0
    //     0xcb377c: stur            d0, [x0, #7]
    // 0xcb3780: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcb3780: add             x25, x1, x4, lsl #2
    //     0xcb3784: add             x25, x25, #0xf
    //     0xcb3788: str             w0, [x25]
    //     0xcb378c: tbz             w0, #0, #0xcb37a8
    //     0xcb3790: ldurb           w16, [x1, #-1]
    //     0xcb3794: ldurb           w17, [x0, #-1]
    //     0xcb3798: and             x16, x17, x16, lsr #2
    //     0xcb379c: tst             x16, HEAP, lsr #32
    //     0xcb37a0: b.eq            #0xcb37a8
    //     0xcb37a4: bl              #0xd67e5c
    // 0xcb37a8: cbnz            x3, #0xcb37b4
    // 0xcb37ac: r1 = 20
    //     0xcb37ac: mov             x1, #0x14
    // 0xcb37b0: b               #0xcb37b8
    // 0xcb37b4: mov             x1, x3
    // 0xcb37b8: ldur            x0, [fp, #-0x38]
    // 0xcb37bc: sub             x13, x1, #1
    // 0xcb37c0: add             x14, x0, #1
    // 0xcb37c4: cmp             x14, #0x14
    // 0xcb37c8: b.ge            #0xcb37ec
    // 0xcb37cc: ldur            x12, [fp, #-0x30]
    // 0xcb37d0: ldur            x11, [fp, #-0x28]
    // 0xcb37d4: ldur            x4, [fp, #-0x78]
    // 0xcb37d8: ldur            x7, [fp, #-0x60]
    // 0xcb37dc: ldur            x8, [fp, #-0x58]
    // 0xcb37e0: ldur            x5, [fp, #-0x70]
    // 0xcb37e4: ldur            x6, [fp, #-0x68]
    // 0xcb37e8: b               #0xcb33b4
    // 0xcb37ec: mov             x3, x14
    // 0xcb37f0: ldur            x1, [fp, #-0x30]
    // 0xcb37f4: ldur            x0, [fp, #-0x28]
    // 0xcb37f8: stur            x1, [fp, #-0x28]
    // 0xcb37fc: stur            x0, [fp, #-0x30]
    // 0xcb3800: cmp             x3, #3
    // 0xcb3804: b.lt            #0xcb3a18
    // 0xcb3808: ldur            x4, [fp, #-8]
    // 0xcb380c: ldur            x3, [fp, #-0x18]
    // 0xcb3810: r0 = LeastSquaresSolver()
    //     0xcb3810: bl              #0xcb4b54  ; AllocateLeastSquaresSolverStub -> LeastSquaresSolver (size=0x14)
    // 0xcb3814: mov             x1, x0
    // 0xcb3818: ldur            x0, [fp, #-0x80]
    // 0xcb381c: StoreField: r1->field_7 = r0
    //     0xcb381c: stur            w0, [x1, #7]
    // 0xcb3820: ldur            x2, [fp, #-8]
    // 0xcb3824: StoreField: r1->field_b = r2
    //     0xcb3824: stur            w2, [x1, #0xb]
    // 0xcb3828: ldur            x2, [fp, #-0x18]
    // 0xcb382c: StoreField: r1->field_f = r2
    //     0xcb382c: stur            w2, [x1, #0xf]
    // 0xcb3830: SaveReg r1
    //     0xcb3830: str             x1, [SP, #-8]!
    // 0xcb3834: r0 = solve()
    //     0xcb3834: bl              #0xcb3b60  ; [package:flutter/src/gestures/lsq_solver.dart] LeastSquaresSolver::solve
    // 0xcb3838: add             SP, SP, #8
    // 0xcb383c: stur            x0, [fp, #-8]
    // 0xcb3840: cmp             w0, NULL
    // 0xcb3844: b.eq            #0xcb3a04
    // 0xcb3848: ldur            x3, [fp, #-0x10]
    // 0xcb384c: ldur            x2, [fp, #-0x18]
    // 0xcb3850: ldur            x1, [fp, #-0x80]
    // 0xcb3854: r0 = LeastSquaresSolver()
    //     0xcb3854: bl              #0xcb4b54  ; AllocateLeastSquaresSolverStub -> LeastSquaresSolver (size=0x14)
    // 0xcb3858: mov             x1, x0
    // 0xcb385c: ldur            x0, [fp, #-0x80]
    // 0xcb3860: StoreField: r1->field_7 = r0
    //     0xcb3860: stur            w0, [x1, #7]
    // 0xcb3864: ldur            x0, [fp, #-0x10]
    // 0xcb3868: StoreField: r1->field_b = r0
    //     0xcb3868: stur            w0, [x1, #0xb]
    // 0xcb386c: ldur            x0, [fp, #-0x18]
    // 0xcb3870: StoreField: r1->field_f = r0
    //     0xcb3870: stur            w0, [x1, #0xf]
    // 0xcb3874: SaveReg r1
    //     0xcb3874: str             x1, [SP, #-8]!
    // 0xcb3878: r0 = solve()
    //     0xcb3878: bl              #0xcb3b60  ; [package:flutter/src/gestures/lsq_solver.dart] LeastSquaresSolver::solve
    // 0xcb387c: add             SP, SP, #8
    // 0xcb3880: mov             x2, x0
    // 0xcb3884: stur            x2, [fp, #-0x10]
    // 0xcb3888: cmp             w2, NULL
    // 0xcb388c: b.eq            #0xcb39f0
    // 0xcb3890: ldur            x7, [fp, #-0x60]
    // 0xcb3894: ldur            x5, [fp, #-0x28]
    // 0xcb3898: ldur            x3, [fp, #-8]
    // 0xcb389c: ldur            x6, [fp, #-0x68]
    // 0xcb38a0: ldur            x4, [fp, #-0x30]
    // 0xcb38a4: d0 = 1000.000000
    //     0xcb38a4: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0xcb38a8: ldr             d0, [x17, #0x3b0]
    // 0xcb38ac: LoadField: r8 = r3->field_7
    //     0xcb38ac: ldur            w8, [x3, #7]
    // 0xcb38b0: DecompressPointer r8
    //     0xcb38b0: add             x8, x8, HEAP, lsl #32
    // 0xcb38b4: LoadField: r0 = r8->field_13
    //     0xcb38b4: ldur            w0, [x8, #0x13]
    // 0xcb38b8: DecompressPointer r0
    //     0xcb38b8: add             x0, x0, HEAP, lsl #32
    // 0xcb38bc: r1 = LoadInt32Instr(r0)
    //     0xcb38bc: sbfx            x1, x0, #1, #0x1f
    // 0xcb38c0: mov             x0, x1
    // 0xcb38c4: r1 = 1
    //     0xcb38c4: mov             x1, #1
    // 0xcb38c8: cmp             x1, x0
    // 0xcb38cc: b.hs            #0xcb3b34
    // 0xcb38d0: LoadField: d1 = r8->field_1f
    //     0xcb38d0: ldur            d1, [x8, #0x1f]
    // 0xcb38d4: fmul            d2, d1, d0
    // 0xcb38d8: stur            d2, [fp, #-0x90]
    // 0xcb38dc: LoadField: r8 = r2->field_7
    //     0xcb38dc: ldur            w8, [x2, #7]
    // 0xcb38e0: DecompressPointer r8
    //     0xcb38e0: add             x8, x8, HEAP, lsl #32
    // 0xcb38e4: LoadField: r0 = r8->field_13
    //     0xcb38e4: ldur            w0, [x8, #0x13]
    // 0xcb38e8: DecompressPointer r0
    //     0xcb38e8: add             x0, x0, HEAP, lsl #32
    // 0xcb38ec: r1 = LoadInt32Instr(r0)
    //     0xcb38ec: sbfx            x1, x0, #1, #0x1f
    // 0xcb38f0: mov             x0, x1
    // 0xcb38f4: r1 = 1
    //     0xcb38f4: mov             x1, #1
    // 0xcb38f8: cmp             x1, x0
    // 0xcb38fc: b.hs            #0xcb3b38
    // 0xcb3900: LoadField: d1 = r8->field_1f
    //     0xcb3900: ldur            d1, [x8, #0x1f]
    // 0xcb3904: fmul            d3, d1, d0
    // 0xcb3908: stur            d3, [fp, #-0x88]
    // 0xcb390c: r0 = Offset()
    //     0xcb390c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcb3910: ldur            d0, [fp, #-0x90]
    // 0xcb3914: stur            x0, [fp, #-0x18]
    // 0xcb3918: StoreField: r0->field_7 = d0
    //     0xcb3918: stur            d0, [x0, #7]
    // 0xcb391c: ldur            d0, [fp, #-0x88]
    // 0xcb3920: StoreField: r0->field_f = d0
    //     0xcb3920: stur            d0, [x0, #0xf]
    // 0xcb3924: ldur            x1, [fp, #-8]
    // 0xcb3928: LoadField: r2 = r1->field_b
    //     0xcb3928: ldur            w2, [x1, #0xb]
    // 0xcb392c: DecompressPointer r2
    //     0xcb392c: add             x2, x2, HEAP, lsl #32
    // 0xcb3930: r16 = Sentinel
    //     0xcb3930: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcb3934: cmp             w2, w16
    // 0xcb3938: b.eq            #0xcb3b3c
    // 0xcb393c: ldur            x1, [fp, #-0x10]
    // 0xcb3940: LoadField: r3 = r1->field_b
    //     0xcb3940: ldur            w3, [x1, #0xb]
    // 0xcb3944: DecompressPointer r3
    //     0xcb3944: add             x3, x3, HEAP, lsl #32
    // 0xcb3948: r16 = Sentinel
    //     0xcb3948: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcb394c: cmp             w3, w16
    // 0xcb3950: b.eq            #0xcb3b48
    // 0xcb3954: LoadField: d0 = r2->field_7
    //     0xcb3954: ldur            d0, [x2, #7]
    // 0xcb3958: LoadField: d1 = r3->field_7
    //     0xcb3958: ldur            d1, [x3, #7]
    // 0xcb395c: fmul            d2, d0, d1
    // 0xcb3960: ldur            x1, [fp, #-0x60]
    // 0xcb3964: stur            d2, [fp, #-0x88]
    // 0xcb3968: LoadField: r2 = r1->field_7
    //     0xcb3968: ldur            x2, [x1, #7]
    // 0xcb396c: ldur            x3, [fp, #-0x30]
    // 0xcb3970: LoadField: r1 = r3->field_7
    //     0xcb3970: ldur            x1, [x3, #7]
    // 0xcb3974: sub             x3, x2, x1
    // 0xcb3978: stur            x3, [fp, #-0x20]
    // 0xcb397c: r0 = Duration()
    //     0xcb397c: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xcb3980: mov             x1, x0
    // 0xcb3984: ldur            x0, [fp, #-0x20]
    // 0xcb3988: stur            x1, [fp, #-8]
    // 0xcb398c: StoreField: r1->field_7 = r0
    //     0xcb398c: stur            x0, [x1, #7]
    // 0xcb3990: ldur            x0, [fp, #-0x68]
    // 0xcb3994: LoadField: r2 = r0->field_b
    //     0xcb3994: ldur            w2, [x0, #0xb]
    // 0xcb3998: DecompressPointer r2
    //     0xcb3998: add             x2, x2, HEAP, lsl #32
    // 0xcb399c: ldur            x4, [fp, #-0x28]
    // 0xcb39a0: LoadField: r0 = r4->field_b
    //     0xcb39a0: ldur            w0, [x4, #0xb]
    // 0xcb39a4: DecompressPointer r0
    //     0xcb39a4: add             x0, x0, HEAP, lsl #32
    // 0xcb39a8: stp             x0, x2, [SP, #-0x10]!
    // 0xcb39ac: r0 = -()
    //     0xcb39ac: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xcb39b0: add             SP, SP, #0x10
    // 0xcb39b4: stur            x0, [fp, #-0x10]
    // 0xcb39b8: r0 = VelocityEstimate()
    //     0xcb39b8: bl              #0xcb3b54  ; AllocateVelocityEstimateStub -> VelocityEstimate (size=0x1c)
    // 0xcb39bc: mov             x1, x0
    // 0xcb39c0: ldur            x0, [fp, #-0x18]
    // 0xcb39c4: StoreField: r1->field_7 = r0
    //     0xcb39c4: stur            w0, [x1, #7]
    // 0xcb39c8: ldur            d0, [fp, #-0x88]
    // 0xcb39cc: StoreField: r1->field_b = d0
    //     0xcb39cc: stur            d0, [x1, #0xb]
    // 0xcb39d0: ldur            x0, [fp, #-8]
    // 0xcb39d4: StoreField: r1->field_13 = r0
    //     0xcb39d4: stur            w0, [x1, #0x13]
    // 0xcb39d8: ldur            x0, [fp, #-0x10]
    // 0xcb39dc: StoreField: r1->field_17 = r0
    //     0xcb39dc: stur            w0, [x1, #0x17]
    // 0xcb39e0: mov             x0, x1
    // 0xcb39e4: LeaveFrame
    //     0xcb39e4: mov             SP, fp
    //     0xcb39e8: ldp             fp, lr, [SP], #0x10
    // 0xcb39ec: ret
    //     0xcb39ec: ret             
    // 0xcb39f0: ldur            x1, [fp, #-0x60]
    // 0xcb39f4: ldur            x4, [fp, #-0x28]
    // 0xcb39f8: ldur            x0, [fp, #-0x68]
    // 0xcb39fc: ldur            x3, [fp, #-0x30]
    // 0xcb3a00: b               #0xcb3a28
    // 0xcb3a04: ldur            x1, [fp, #-0x60]
    // 0xcb3a08: ldur            x4, [fp, #-0x28]
    // 0xcb3a0c: ldur            x0, [fp, #-0x68]
    // 0xcb3a10: ldur            x3, [fp, #-0x30]
    // 0xcb3a14: b               #0xcb3a28
    // 0xcb3a18: mov             x4, x1
    // 0xcb3a1c: ldur            x1, [fp, #-0x60]
    // 0xcb3a20: mov             x3, x0
    // 0xcb3a24: ldur            x0, [fp, #-0x68]
    // 0xcb3a28: LoadField: r2 = r1->field_7
    //     0xcb3a28: ldur            x2, [x1, #7]
    // 0xcb3a2c: LoadField: r1 = r3->field_7
    //     0xcb3a2c: ldur            x1, [x3, #7]
    // 0xcb3a30: sub             x3, x2, x1
    // 0xcb3a34: stur            x3, [fp, #-0x20]
    // 0xcb3a38: r0 = Duration()
    //     0xcb3a38: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xcb3a3c: mov             x1, x0
    // 0xcb3a40: ldur            x0, [fp, #-0x20]
    // 0xcb3a44: stur            x1, [fp, #-8]
    // 0xcb3a48: StoreField: r1->field_7 = r0
    //     0xcb3a48: stur            x0, [x1, #7]
    // 0xcb3a4c: ldur            x0, [fp, #-0x68]
    // 0xcb3a50: LoadField: r2 = r0->field_b
    //     0xcb3a50: ldur            w2, [x0, #0xb]
    // 0xcb3a54: DecompressPointer r2
    //     0xcb3a54: add             x2, x2, HEAP, lsl #32
    // 0xcb3a58: ldur            x0, [fp, #-0x28]
    // 0xcb3a5c: LoadField: r3 = r0->field_b
    //     0xcb3a5c: ldur            w3, [x0, #0xb]
    // 0xcb3a60: DecompressPointer r3
    //     0xcb3a60: add             x3, x3, HEAP, lsl #32
    // 0xcb3a64: stp             x3, x2, [SP, #-0x10]!
    // 0xcb3a68: r0 = -()
    //     0xcb3a68: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xcb3a6c: add             SP, SP, #0x10
    // 0xcb3a70: stur            x0, [fp, #-0x10]
    // 0xcb3a74: r0 = VelocityEstimate()
    //     0xcb3a74: bl              #0xcb3b54  ; AllocateVelocityEstimateStub -> VelocityEstimate (size=0x1c)
    // 0xcb3a78: r1 = Instance_Offset
    //     0xcb3a78: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcb3a7c: StoreField: r0->field_7 = r1
    //     0xcb3a7c: stur            w1, [x0, #7]
    // 0xcb3a80: d0 = 1.000000
    //     0xcb3a80: fmov            d0, #1.00000000
    // 0xcb3a84: StoreField: r0->field_b = d0
    //     0xcb3a84: stur            d0, [x0, #0xb]
    // 0xcb3a88: ldur            x1, [fp, #-8]
    // 0xcb3a8c: StoreField: r0->field_13 = r1
    //     0xcb3a8c: stur            w1, [x0, #0x13]
    // 0xcb3a90: ldur            x1, [fp, #-0x10]
    // 0xcb3a94: StoreField: r0->field_17 = r1
    //     0xcb3a94: stur            w1, [x0, #0x17]
    // 0xcb3a98: LeaveFrame
    //     0xcb3a98: mov             SP, fp
    //     0xcb3a9c: ldp             fp, lr, [SP], #0x10
    // 0xcb3aa0: ret
    //     0xcb3aa0: ret             
    // 0xcb3aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb3aa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb3aa8: b               #0xcb32e0
    // 0xcb3aac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb3aac: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb3ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb3ab0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb3ab4: b               #0xcb33dc
    // 0xcb3ab8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb3ab8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb3abc: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb3abc: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb3ac0: SaveReg d0
    //     0xcb3ac0: str             q0, [SP, #-0x10]!
    // 0xcb3ac4: stp             x4, x5, [SP, #-0x10]!
    // 0xcb3ac8: stp             x2, x3, [SP, #-0x10]!
    // 0xcb3acc: SaveReg r1
    //     0xcb3acc: str             x1, [SP, #-8]!
    // 0xcb3ad0: r0 = AllocateDouble()
    //     0xcb3ad0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb3ad4: RestoreReg r1
    //     0xcb3ad4: ldr             x1, [SP], #8
    // 0xcb3ad8: ldp             x2, x3, [SP], #0x10
    // 0xcb3adc: ldp             x4, x5, [SP], #0x10
    // 0xcb3ae0: RestoreReg d0
    //     0xcb3ae0: ldr             q0, [SP], #0x10
    // 0xcb3ae4: b               #0xcb3594
    // 0xcb3ae8: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb3ae8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb3aec: SaveReg d0
    //     0xcb3aec: str             q0, [SP, #-0x10]!
    // 0xcb3af0: stp             x3, x4, [SP, #-0x10]!
    // 0xcb3af4: stp             x1, x2, [SP, #-0x10]!
    // 0xcb3af8: r0 = AllocateDouble()
    //     0xcb3af8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb3afc: ldp             x1, x2, [SP], #0x10
    // 0xcb3b00: ldp             x3, x4, [SP], #0x10
    // 0xcb3b04: RestoreReg d0
    //     0xcb3b04: ldr             q0, [SP], #0x10
    // 0xcb3b08: b               #0xcb3650
    // 0xcb3b0c: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb3b0c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb3b10: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb3b10: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb3b14: SaveReg d0
    //     0xcb3b14: str             q0, [SP, #-0x10]!
    // 0xcb3b18: stp             x3, x4, [SP, #-0x10]!
    // 0xcb3b1c: stp             x1, x2, [SP, #-0x10]!
    // 0xcb3b20: r0 = AllocateDouble()
    //     0xcb3b20: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb3b24: ldp             x1, x2, [SP], #0x10
    // 0xcb3b28: ldp             x3, x4, [SP], #0x10
    // 0xcb3b2c: RestoreReg d0
    //     0xcb3b2c: ldr             q0, [SP], #0x10
    // 0xcb3b30: b               #0xcb377c
    // 0xcb3b34: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb3b34: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb3b38: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb3b38: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb3b3c: r9 = confidence
    //     0xcb3b3c: add             x9, PP, #0x38, lsl #12  ; [pp+0x38450] Field <PolynomialFit.confidence>: late (offset: 0xc)
    //     0xcb3b40: ldr             x9, [x9, #0x450]
    // 0xcb3b44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcb3b44: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcb3b48: r9 = confidence
    //     0xcb3b48: add             x9, PP, #0x38, lsl #12  ; [pp+0x38450] Field <PolynomialFit.confidence>: late (offset: 0xc)
    //     0xcb3b4c: ldr             x9, [x9, #0x450]
    // 0xcb3b50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcb3b50: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ addPosition(/* No info */) {
    // ** addr: 0xcb5a20, size: 0xcc
    // 0xcb5a20: EnterFrame
    //     0xcb5a20: stp             fp, lr, [SP, #-0x10]!
    //     0xcb5a24: mov             fp, SP
    // 0xcb5a28: AllocStack(0x10)
    //     0xcb5a28: sub             SP, SP, #0x10
    // 0xcb5a2c: ldr             x0, [fp, #0x20]
    // 0xcb5a30: LoadField: r1 = r0->field_1b
    //     0xcb5a30: ldur            x1, [x0, #0x1b]
    // 0xcb5a34: add             x2, x1, #1
    // 0xcb5a38: StoreField: r0->field_1b = r2
    //     0xcb5a38: stur            x2, [x0, #0x1b]
    // 0xcb5a3c: cmp             x2, #0x14
    // 0xcb5a40: b.ne            #0xcb5a54
    // 0xcb5a44: r1 = 0
    //     0xcb5a44: mov             x1, #0
    // 0xcb5a48: StoreField: r0->field_1b = r1
    //     0xcb5a48: stur            x1, [x0, #0x1b]
    // 0xcb5a4c: r3 = 0
    //     0xcb5a4c: mov             x3, #0
    // 0xcb5a50: b               #0xcb5a58
    // 0xcb5a54: mov             x3, x2
    // 0xcb5a58: ldr             x2, [fp, #0x18]
    // 0xcb5a5c: ldr             x1, [fp, #0x10]
    // 0xcb5a60: stur            x3, [fp, #-0x10]
    // 0xcb5a64: LoadField: r4 = r0->field_17
    //     0xcb5a64: ldur            w4, [x0, #0x17]
    // 0xcb5a68: DecompressPointer r4
    //     0xcb5a68: add             x4, x4, HEAP, lsl #32
    // 0xcb5a6c: stur            x4, [fp, #-8]
    // 0xcb5a70: r0 = _PointAtTime()
    //     0xcb5a70: bl              #0xcb5aec  ; Allocate_PointAtTimeStub -> _PointAtTime (size=0x10)
    // 0xcb5a74: mov             x3, x0
    // 0xcb5a78: ldr             x2, [fp, #0x10]
    // 0xcb5a7c: StoreField: r3->field_b = r2
    //     0xcb5a7c: stur            w2, [x3, #0xb]
    // 0xcb5a80: ldr             x2, [fp, #0x18]
    // 0xcb5a84: StoreField: r3->field_7 = r2
    //     0xcb5a84: stur            w2, [x3, #7]
    // 0xcb5a88: ldur            x2, [fp, #-8]
    // 0xcb5a8c: LoadField: r4 = r2->field_b
    //     0xcb5a8c: ldur            w4, [x2, #0xb]
    // 0xcb5a90: DecompressPointer r4
    //     0xcb5a90: add             x4, x4, HEAP, lsl #32
    // 0xcb5a94: r0 = LoadInt32Instr(r4)
    //     0xcb5a94: sbfx            x0, x4, #1, #0x1f
    // 0xcb5a98: ldur            x1, [fp, #-0x10]
    // 0xcb5a9c: cmp             x1, x0
    // 0xcb5aa0: b.hs            #0xcb5ae8
    // 0xcb5aa4: mov             x1, x2
    // 0xcb5aa8: mov             x0, x3
    // 0xcb5aac: ldur            x2, [fp, #-0x10]
    // 0xcb5ab0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xcb5ab0: add             x25, x1, x2, lsl #2
    //     0xcb5ab4: add             x25, x25, #0xf
    //     0xcb5ab8: str             w0, [x25]
    //     0xcb5abc: tbz             w0, #0, #0xcb5ad8
    //     0xcb5ac0: ldurb           w16, [x1, #-1]
    //     0xcb5ac4: ldurb           w17, [x0, #-1]
    //     0xcb5ac8: and             x16, x17, x16, lsr #2
    //     0xcb5acc: tst             x16, HEAP, lsr #32
    //     0xcb5ad0: b.eq            #0xcb5ad8
    //     0xcb5ad4: bl              #0xd67e5c
    // 0xcb5ad8: r0 = Null
    //     0xcb5ad8: mov             x0, NULL
    // 0xcb5adc: LeaveFrame
    //     0xcb5adc: mov             SP, fp
    //     0xcb5ae0: ldp             fp, lr, [SP], #0x10
    // 0xcb5ae4: ret
    //     0xcb5ae4: ret             
    // 0xcb5ae8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb5ae8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 4475, size: 0x18, field offset: 0x18
abstract class VelocityTrackerMixin extends VelocityTracker {
}

// class id: 4476, size: 0x10, field offset: 0x8
//   const constructor, 
class _PointAtTime extends Object {
}

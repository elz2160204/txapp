// lib: , url: package:extended_image/src/gesture_detector/drag.dart

// class id: 1048940, size: 0x8
class :: {
}

// class id: 2364, size: 0x20, field offset: 0x20
//   transformed mixin,
abstract class _ExtendedDragGestureRecognizer&OneSequenceGestureRecognizer&DragGestureRecognizerMixin extends OneSequenceGestureRecognizer
     with DragGestureRecognizerMixin {

  _ _shouldAccpet(/* No info */) {
    // ** addr: 0x788528, size: 0x3b0
    // 0x788528: EnterFrame
    //     0x788528: stp             fp, lr, [SP, #-0x10]!
    //     0x78852c: mov             fp, SP
    // 0x788530: AllocStack(0x30)
    //     0x788530: sub             SP, SP, #0x30
    // 0x788534: CheckStackOverflow
    //     0x788534: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x788538: cmp             SP, x16
    //     0x78853c: b.ls            #0x788844
    // 0x788540: ldr             x16, [fp, #0x10]
    // 0x788544: SaveReg r16
    //     0x788544: str             x16, [SP, #-8]!
    // 0x788548: r0 = canDrag()
    //     0x788548: bl              #0x7889dc  ; [package:extended_image/src/gesture_detector/drag.dart] _ExtendedDragGestureRecognizer&OneSequenceGestureRecognizer&DragGestureRecognizerMixin::canDrag
    // 0x78854c: add             SP, SP, #8
    // 0x788550: tbz             w0, #4, #0x788564
    // 0x788554: r0 = false
    //     0x788554: add             x0, NULL, #0x30  ; false
    // 0x788558: LeaveFrame
    //     0x788558: mov             SP, fp
    //     0x78855c: ldp             fp, lr, [SP], #0x10
    // 0x788560: ret
    //     0x788560: ret             
    // 0x788564: ldr             x0, [fp, #0x10]
    // 0x788568: LoadField: r1 = r0->field_67
    //     0x788568: ldur            w1, [x0, #0x67]
    // 0x78856c: DecompressPointer r1
    //     0x78856c: add             x1, x1, HEAP, lsl #32
    // 0x788570: stur            x1, [fp, #-8]
    // 0x788574: SaveReg r1
    //     0x788574: str             x1, [SP, #-8]!
    // 0x788578: r0 = keys()
    //     0x788578: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x78857c: add             SP, SP, #8
    // 0x788580: LoadField: r1 = r0->field_b
    //     0x788580: ldur            w1, [x0, #0xb]
    // 0x788584: DecompressPointer r1
    //     0x788584: add             x1, x1, HEAP, lsl #32
    // 0x788588: r0 = LoadClassIdInstr(r1)
    //     0x788588: ldur            x0, [x1, #-1]
    //     0x78858c: ubfx            x0, x0, #0xc, #0x14
    // 0x788590: SaveReg r1
    //     0x788590: str             x1, [SP, #-8]!
    // 0x788594: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x788594: mov             x17, #0xb8ea
    //     0x788598: add             lr, x0, x17
    //     0x78859c: ldr             lr, [x21, lr, lsl #3]
    //     0x7885a0: blr             lr
    // 0x7885a4: add             SP, SP, #8
    // 0x7885a8: r1 = LoadInt32Instr(r0)
    //     0x7885a8: sbfx            x1, x0, #1, #0x1f
    //     0x7885ac: tbz             w0, #0, #0x7885b4
    //     0x7885b0: ldur            x1, [x0, #7]
    // 0x7885b4: cmp             x1, #1
    // 0x7885b8: b.ne            #0x7885cc
    // 0x7885bc: r0 = true
    //     0x7885bc: add             x0, NULL, #0x20  ; true
    // 0x7885c0: LeaveFrame
    //     0x7885c0: mov             SP, fp
    //     0x7885c4: ldp             fp, lr, [SP], #0x10
    // 0x7885c8: ret
    //     0x7885c8: ret             
    // 0x7885cc: ldur            x16, [fp, #-8]
    // 0x7885d0: SaveReg r16
    //     0x7885d0: str             x16, [SP, #-8]!
    // 0x7885d4: r0 = values()
    //     0x7885d4: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x7885d8: add             SP, SP, #8
    // 0x7885dc: SaveReg r0
    //     0x7885dc: str             x0, [SP, #-8]!
    // 0x7885e0: r0 = iterator()
    //     0x7885e0: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x7885e4: add             SP, SP, #8
    // 0x7885e8: stur            x0, [fp, #-0x18]
    // 0x7885ec: LoadField: r2 = r0->field_7
    //     0x7885ec: ldur            w2, [x0, #7]
    // 0x7885f0: DecompressPointer r2
    //     0x7885f0: add             x2, x2, HEAP, lsl #32
    // 0x7885f4: stur            x2, [fp, #-0x10]
    // 0x7885f8: r1 = Instance_Offset
    //     0x7885f8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a2f0] Obj!Offset@b5eff1
    //     0x7885fc: ldr             x1, [x1, #0x2f0]
    // 0x788600: stur            x1, [fp, #-8]
    // 0x788604: CheckStackOverflow
    //     0x788604: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x788608: cmp             SP, x16
    //     0x78860c: b.ls            #0x78884c
    // 0x788610: SaveReg r0
    //     0x788610: str             x0, [SP, #-8]!
    // 0x788614: r0 = moveNext()
    //     0x788614: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x788618: add             SP, SP, #8
    // 0x78861c: tbnz            w0, #4, #0x7887f8
    // 0x788620: ldur            x3, [fp, #-0x18]
    // 0x788624: LoadField: r4 = r3->field_33
    //     0x788624: ldur            w4, [x3, #0x33]
    // 0x788628: DecompressPointer r4
    //     0x788628: add             x4, x4, HEAP, lsl #32
    // 0x78862c: stur            x4, [fp, #-0x20]
    // 0x788630: cmp             w4, NULL
    // 0x788634: b.ne            #0x788668
    // 0x788638: mov             x0, x4
    // 0x78863c: ldur            x2, [fp, #-0x10]
    // 0x788640: r1 = Null
    //     0x788640: mov             x1, NULL
    // 0x788644: cmp             w2, NULL
    // 0x788648: b.eq            #0x788668
    // 0x78864c: LoadField: r4 = r2->field_17
    //     0x78864c: ldur            w4, [x2, #0x17]
    // 0x788650: DecompressPointer r4
    //     0x788650: add             x4, x4, HEAP, lsl #32
    // 0x788654: r8 = X0
    //     0x788654: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x788658: LoadField: r9 = r4->field_7
    //     0x788658: ldur            x9, [x4, #7]
    // 0x78865c: r3 = Null
    //     0x78865c: add             x3, PP, #0x53, lsl #12  ; [pp+0x537b8] Null
    //     0x788660: ldr             x3, [x3, #0x7b8]
    // 0x788664: blr             x9
    // 0x788668: ldur            x0, [fp, #-0x20]
    // 0x78866c: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x78866c: mov             x1, #0x76
    //     0x788670: tbz             w0, #0, #0x788680
    //     0x788674: ldur            x1, [x0, #-1]
    //     0x788678: ubfx            x1, x1, #0xc, #0x14
    //     0x78867c: lsl             x1, x1, #1
    // 0x788680: r17 = 8948
    //     0x788680: mov             x17, #0x22f4
    // 0x788684: cmp             w1, w17
    // 0x788688: b.ne            #0x7887e4
    // 0x78868c: ldur            x1, [fp, #-8]
    // 0x788690: SaveReg r0
    //     0x788690: str             x0, [SP, #-8]!
    // 0x788694: r0 = getSamplesDelta()
    //     0x788694: bl              #0x7888d8  ; [package:extended_image/src/gesture_detector/velocity_tracker.dart] _ExtendedVelocityTracker&VelocityTracker&VelocityTrackerMixin::getSamplesDelta
    // 0x788698: add             SP, SP, #8
    // 0x78869c: mov             x1, x0
    // 0x7886a0: ldur            x0, [fp, #-8]
    // 0x7886a4: stur            x1, [fp, #-0x20]
    // 0x7886a8: LoadField: d0 = r0->field_7
    //     0x7886a8: ldur            d0, [x0, #7]
    // 0x7886ac: LoadField: d1 = r1->field_7
    //     0x7886ac: ldur            d1, [x1, #7]
    // 0x7886b0: d2 = 0.000000
    //     0x7886b0: eor             v2.16b, v2.16b, v2.16b
    // 0x7886b4: fcmp            d1, d2
    // 0x7886b8: b.vs            #0x7886c8
    // 0x7886bc: b.ne            #0x7886c8
    // 0x7886c0: r2 = 2
    //     0x7886c0: mov             x2, #2
    // 0x7886c4: b               #0x7886f0
    // 0x7886c8: r2 = inline_Allocate_Double()
    //     0x7886c8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x7886cc: add             x2, x2, #0x10
    //     0x7886d0: cmp             x3, x2
    //     0x7886d4: b.ls            #0x788854
    //     0x7886d8: str             x2, [THR, #0x60]  ; THR::top
    //     0x7886dc: sub             x2, x2, #0xf
    //     0x7886e0: mov             x3, #0xd108
    //     0x7886e4: movk            x3, #3, lsl #16
    //     0x7886e8: stur            x3, [x2, #-1]
    // 0x7886ec: StoreField: r2->field_7 = d1
    //     0x7886ec: stur            d1, [x2, #7]
    // 0x7886f0: r3 = inline_Allocate_Double()
    //     0x7886f0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x7886f4: add             x3, x3, #0x10
    //     0x7886f8: cmp             x4, x3
    //     0x7886fc: b.ls            #0x788878
    //     0x788700: str             x3, [THR, #0x60]  ; THR::top
    //     0x788704: sub             x3, x3, #0xf
    //     0x788708: mov             x4, #0xd108
    //     0x78870c: movk            x4, #3, lsl #16
    //     0x788710: stur            x4, [x3, #-1]
    // 0x788714: StoreField: r3->field_7 = d0
    //     0x788714: stur            d0, [x3, #7]
    // 0x788718: stp             x2, x3, [SP, #-0x10]!
    // 0x78871c: r0 = *()
    //     0x78871c: bl              #0xd6758c  ; [dart:core] _Double::*
    // 0x788720: add             SP, SP, #0x10
    // 0x788724: mov             x1, x0
    // 0x788728: ldur            x0, [fp, #-8]
    // 0x78872c: stur            x1, [fp, #-0x28]
    // 0x788730: LoadField: d0 = r0->field_f
    //     0x788730: ldur            d0, [x0, #0xf]
    // 0x788734: ldur            x0, [fp, #-0x20]
    // 0x788738: LoadField: d1 = r0->field_f
    //     0x788738: ldur            d1, [x0, #0xf]
    // 0x78873c: d2 = 0.000000
    //     0x78873c: eor             v2.16b, v2.16b, v2.16b
    // 0x788740: fcmp            d1, d2
    // 0x788744: b.vs            #0x788754
    // 0x788748: b.ne            #0x788754
    // 0x78874c: r0 = 2
    //     0x78874c: mov             x0, #2
    // 0x788750: b               #0x78877c
    // 0x788754: r0 = inline_Allocate_Double()
    //     0x788754: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x788758: add             x0, x0, #0x10
    //     0x78875c: cmp             x2, x0
    //     0x788760: b.ls            #0x78889c
    //     0x788764: str             x0, [THR, #0x60]  ; THR::top
    //     0x788768: sub             x0, x0, #0xf
    //     0x78876c: mov             x2, #0xd108
    //     0x788770: movk            x2, #3, lsl #16
    //     0x788774: stur            x2, [x0, #-1]
    // 0x788778: StoreField: r0->field_7 = d1
    //     0x788778: stur            d1, [x0, #7]
    // 0x78877c: r2 = inline_Allocate_Double()
    //     0x78877c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x788780: add             x2, x2, #0x10
    //     0x788784: cmp             x3, x2
    //     0x788788: b.ls            #0x7888bc
    //     0x78878c: str             x2, [THR, #0x60]  ; THR::top
    //     0x788790: sub             x2, x2, #0xf
    //     0x788794: mov             x3, #0xd108
    //     0x788798: movk            x3, #3, lsl #16
    //     0x78879c: stur            x3, [x2, #-1]
    // 0x7887a0: StoreField: r2->field_7 = d0
    //     0x7887a0: stur            d0, [x2, #7]
    // 0x7887a4: stp             x0, x2, [SP, #-0x10]!
    // 0x7887a8: r0 = *()
    //     0x7887a8: bl              #0xd6758c  ; [dart:core] _Double::*
    // 0x7887ac: add             SP, SP, #0x10
    // 0x7887b0: mov             x1, x0
    // 0x7887b4: ldur            x0, [fp, #-0x28]
    // 0x7887b8: stur            x1, [fp, #-0x20]
    // 0x7887bc: LoadField: d0 = r0->field_7
    //     0x7887bc: ldur            d0, [x0, #7]
    // 0x7887c0: stur            d0, [fp, #-0x30]
    // 0x7887c4: r0 = Offset()
    //     0x7887c4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7887c8: ldur            d0, [fp, #-0x30]
    // 0x7887cc: StoreField: r0->field_7 = d0
    //     0x7887cc: stur            d0, [x0, #7]
    // 0x7887d0: ldur            x1, [fp, #-0x20]
    // 0x7887d4: LoadField: d0 = r1->field_7
    //     0x7887d4: ldur            d0, [x1, #7]
    // 0x7887d8: StoreField: r0->field_f = d0
    //     0x7887d8: stur            d0, [x0, #0xf]
    // 0x7887dc: mov             x1, x0
    // 0x7887e0: b               #0x7887ec
    // 0x7887e4: ldur            x0, [fp, #-8]
    // 0x7887e8: mov             x1, x0
    // 0x7887ec: ldur            x0, [fp, #-0x18]
    // 0x7887f0: ldur            x2, [fp, #-0x10]
    // 0x7887f4: b               #0x788600
    // 0x7887f8: ldur            x0, [fp, #-8]
    // 0x7887fc: d0 = 0.000000
    //     0x7887fc: eor             v0.16b, v0.16b, v0.16b
    // 0x788800: LoadField: d1 = r0->field_7
    //     0x788800: ldur            d1, [x0, #7]
    // 0x788804: fcmp            d1, d0
    // 0x788808: b.vs            #0x788818
    // 0x78880c: b.ge            #0x788818
    // 0x788810: r1 = true
    //     0x788810: add             x1, NULL, #0x20  ; true
    // 0x788814: b               #0x788834
    // 0x788818: LoadField: d1 = r0->field_f
    //     0x788818: ldur            d1, [x0, #0xf]
    // 0x78881c: fcmp            d1, d0
    // 0x788820: b.vs            #0x788828
    // 0x788824: b.lt            #0x788830
    // 0x788828: r1 = false
    //     0x788828: add             x1, NULL, #0x30  ; false
    // 0x78882c: b               #0x788834
    // 0x788830: r1 = true
    //     0x788830: add             x1, NULL, #0x20  ; true
    // 0x788834: eor             x0, x1, #0x10
    // 0x788838: LeaveFrame
    //     0x788838: mov             SP, fp
    //     0x78883c: ldp             fp, lr, [SP], #0x10
    // 0x788840: ret
    //     0x788840: ret             
    // 0x788844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x788844: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x788848: b               #0x788540
    // 0x78884c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78884c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x788850: b               #0x788610
    // 0x788854: stp             q1, q2, [SP, #-0x20]!
    // 0x788858: SaveReg d0
    //     0x788858: str             q0, [SP, #-0x10]!
    // 0x78885c: stp             x0, x1, [SP, #-0x10]!
    // 0x788860: r0 = AllocateDouble()
    //     0x788860: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x788864: mov             x2, x0
    // 0x788868: ldp             x0, x1, [SP], #0x10
    // 0x78886c: RestoreReg d0
    //     0x78886c: ldr             q0, [SP], #0x10
    // 0x788870: ldp             q1, q2, [SP], #0x20
    // 0x788874: b               #0x7886ec
    // 0x788878: stp             q0, q2, [SP, #-0x20]!
    // 0x78887c: stp             x1, x2, [SP, #-0x10]!
    // 0x788880: SaveReg r0
    //     0x788880: str             x0, [SP, #-8]!
    // 0x788884: r0 = AllocateDouble()
    //     0x788884: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x788888: mov             x3, x0
    // 0x78888c: RestoreReg r0
    //     0x78888c: ldr             x0, [SP], #8
    // 0x788890: ldp             x1, x2, [SP], #0x10
    // 0x788894: ldp             q0, q2, [SP], #0x20
    // 0x788898: b               #0x788714
    // 0x78889c: stp             q1, q2, [SP, #-0x20]!
    // 0x7888a0: SaveReg d0
    //     0x7888a0: str             q0, [SP, #-0x10]!
    // 0x7888a4: SaveReg r1
    //     0x7888a4: str             x1, [SP, #-8]!
    // 0x7888a8: r0 = AllocateDouble()
    //     0x7888a8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7888ac: RestoreReg r1
    //     0x7888ac: ldr             x1, [SP], #8
    // 0x7888b0: RestoreReg d0
    //     0x7888b0: ldr             q0, [SP], #0x10
    // 0x7888b4: ldp             q1, q2, [SP], #0x20
    // 0x7888b8: b               #0x788778
    // 0x7888bc: stp             q0, q2, [SP, #-0x20]!
    // 0x7888c0: stp             x0, x1, [SP, #-0x10]!
    // 0x7888c4: r0 = AllocateDouble()
    //     0x7888c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7888c8: mov             x2, x0
    // 0x7888cc: ldp             x0, x1, [SP], #0x10
    // 0x7888d0: ldp             q0, q2, [SP], #0x20
    // 0x7888d4: b               #0x7887a0
  }
  get _ canDrag(/* No info */) {
    // ** addr: 0x7889dc, size: 0x74
    // 0x7889dc: EnterFrame
    //     0x7889dc: stp             fp, lr, [SP, #-0x10]!
    //     0x7889e0: mov             fp, SP
    // 0x7889e4: AllocStack(0x8)
    //     0x7889e4: sub             SP, SP, #8
    // 0x7889e8: CheckStackOverflow
    //     0x7889e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7889ec: cmp             SP, x16
    //     0x7889f0: b.ls            #0x788a48
    // 0x7889f4: ldr             x0, [fp, #0x10]
    // 0x7889f8: LoadField: r1 = r0->field_1f
    //     0x7889f8: ldur            w1, [x0, #0x1f]
    // 0x7889fc: DecompressPointer r1
    //     0x7889fc: add             x1, x1, HEAP, lsl #32
    // 0x788a00: cmp             w1, NULL
    // 0x788a04: b.ne            #0x788a10
    // 0x788a08: r0 = true
    //     0x788a08: add             x0, NULL, #0x20  ; true
    // 0x788a0c: b               #0x788a3c
    // 0x788a10: SaveReg r1
    //     0x788a10: str             x1, [SP, #-8]!
    // 0x788a14: mov             x0, x1
    // 0x788a18: ClosureCall
    //     0x788a18: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x788a1c: ldur            x2, [x0, #0x1f]
    //     0x788a20: blr             x2
    // 0x788a24: add             SP, SP, #8
    // 0x788a28: mov             x1, x0
    // 0x788a2c: stur            x1, [fp, #-8]
    // 0x788a30: tbnz            w0, #5, #0x788a38
    // 0x788a34: r0 = AssertBoolean()
    //     0x788a34: bl              #0xd67df0  ; AssertBooleanStub
    // 0x788a38: ldur            x0, [fp, #-8]
    // 0x788a3c: LeaveFrame
    //     0x788a3c: mov             SP, fp
    //     0x788a40: ldp             fp, lr, [SP], #0x10
    // 0x788a44: ret
    //     0x788a44: ret             
    // 0x788a48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x788a48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x788a4c: b               #0x7889f4
  }
}

// class id: 2365, size: 0x70, field offset: 0x20
abstract class ExtendedDragGestureRecognizer extends _ExtendedDragGestureRecognizer&OneSequenceGestureRecognizer&DragGestureRecognizerMixin {

  late OffsetPair _pendingDragOffset; // offset: 0x54
  late double _globalDistanceMoved; // offset: 0x64
  late OffsetPair _initialPosition; // offset: 0x50

  _ didStopTrackingLastPointer(/* No info */) {
    // ** addr: 0x71372c, size: 0xb8
    // 0x71372c: EnterFrame
    //     0x71372c: stp             fp, lr, [SP, #-0x10]!
    //     0x713730: mov             fp, SP
    // 0x713734: CheckStackOverflow
    //     0x713734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x713738: cmp             SP, x16
    //     0x71373c: b.ls            #0x7137dc
    // 0x713740: ldr             x0, [fp, #0x18]
    // 0x713744: LoadField: r1 = r0->field_4b
    //     0x713744: ldur            w1, [x0, #0x4b]
    // 0x713748: DecompressPointer r1
    //     0x713748: add             x1, x1, HEAP, lsl #32
    // 0x71374c: LoadField: r2 = r1->field_7
    //     0x71374c: ldur            x2, [x1, #7]
    // 0x713750: cmp             x2, #1
    // 0x713754: b.gt            #0x71378c
    // 0x713758: cmp             x2, #0
    // 0x71375c: b.le            #0x7137a4
    // 0x713760: r16 = Instance_GestureDisposition
    //     0x713760: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x713764: ldr             x16, [x16, #0xeb8]
    // 0x713768: stp             x16, x0, [SP, #-0x10]!
    // 0x71376c: r0 = resolve()
    //     0x71376c: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x713770: add             SP, SP, #0x10
    // 0x713774: ldr             x16, [fp, #0x18]
    // 0x713778: SaveReg r16
    //     0x713778: str             x16, [SP, #-8]!
    // 0x71377c: r0 = _checkCancel()
    //     0x71377c: bl              #0x713fa0  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_checkCancel
    // 0x713780: add             SP, SP, #8
    // 0x713784: ldr             x0, [fp, #0x18]
    // 0x713788: b               #0x7137a4
    // 0x71378c: ldr             x0, [fp, #0x10]
    // 0x713790: ldr             x16, [fp, #0x18]
    // 0x713794: stp             x0, x16, [SP, #-0x10]!
    // 0x713798: r0 = _checkEnd()
    //     0x713798: bl              #0x7137e4  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_checkEnd
    // 0x71379c: add             SP, SP, #0x10
    // 0x7137a0: ldr             x0, [fp, #0x18]
    // 0x7137a4: LoadField: r1 = r0->field_67
    //     0x7137a4: ldur            w1, [x0, #0x67]
    // 0x7137a8: DecompressPointer r1
    //     0x7137a8: add             x1, x1, HEAP, lsl #32
    // 0x7137ac: SaveReg r1
    //     0x7137ac: str             x1, [SP, #-8]!
    // 0x7137b0: r0 = clear()
    //     0x7137b0: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x7137b4: add             SP, SP, #8
    // 0x7137b8: ldr             x1, [fp, #0x18]
    // 0x7137bc: StoreField: r1->field_5b = rNULL
    //     0x7137bc: stur            NULL, [x1, #0x5b]
    // 0x7137c0: r2 = Instance__DragState
    //     0x7137c0: add             x2, PP, #0x51, lsl #12  ; [pp+0x51440] Obj!_DragState@b660d1
    //     0x7137c4: ldr             x2, [x2, #0x440]
    // 0x7137c8: StoreField: r1->field_4b = r2
    //     0x7137c8: stur            w2, [x1, #0x4b]
    // 0x7137cc: r0 = Null
    //     0x7137cc: mov             x0, NULL
    // 0x7137d0: LeaveFrame
    //     0x7137d0: mov             SP, fp
    //     0x7137d4: ldp             fp, lr, [SP], #0x10
    // 0x7137d8: ret
    //     0x7137d8: ret             
    // 0x7137dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7137dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7137e0: b               #0x713740
  }
  _ _checkEnd(/* No info */) {
    // ** addr: 0x7137e4, size: 0x35c
    // 0x7137e4: EnterFrame
    //     0x7137e4: stp             fp, lr, [SP, #-0x10]!
    //     0x7137e8: mov             fp, SP
    // 0x7137ec: AllocStack(0x20)
    //     0x7137ec: sub             SP, SP, #0x20
    // 0x7137f0: CheckStackOverflow
    //     0x7137f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7137f4: cmp             SP, x16
    //     0x7137f8: b.ls            #0x713af8
    // 0x7137fc: r1 = 4
    //     0x7137fc: mov             x1, #4
    // 0x713800: r0 = AllocateContext()
    //     0x713800: bl              #0xd68aa4  ; AllocateContextStub
    // 0x713804: mov             x3, x0
    // 0x713808: ldr             x2, [fp, #0x18]
    // 0x71380c: stur            x3, [fp, #-0x10]
    // 0x713810: StoreField: r3->field_f = r2
    //     0x713810: stur            w2, [x3, #0xf]
    // 0x713814: LoadField: r0 = r2->field_33
    //     0x713814: ldur            w0, [x2, #0x33]
    // 0x713818: DecompressPointer r0
    //     0x713818: add             x0, x0, HEAP, lsl #32
    // 0x71381c: cmp             w0, NULL
    // 0x713820: b.ne            #0x713834
    // 0x713824: r0 = Null
    //     0x713824: mov             x0, NULL
    // 0x713828: LeaveFrame
    //     0x713828: mov             SP, fp
    //     0x71382c: ldp             fp, lr, [SP], #0x10
    // 0x713830: ret
    //     0x713830: ret             
    // 0x713834: ldr             x4, [fp, #0x10]
    // 0x713838: LoadField: r5 = r2->field_67
    //     0x713838: ldur            w5, [x2, #0x67]
    // 0x71383c: DecompressPointer r5
    //     0x71383c: add             x5, x5, HEAP, lsl #32
    // 0x713840: stur            x5, [fp, #-8]
    // 0x713844: r0 = BoxInt64Instr(r4)
    //     0x713844: sbfiz           x0, x4, #1, #0x1f
    //     0x713848: cmp             x4, x0, asr #1
    //     0x71384c: b.eq            #0x713858
    //     0x713850: bl              #0xd69bb8
    //     0x713854: stur            x4, [x0, #7]
    // 0x713858: stp             x0, x5, [SP, #-0x10]!
    // 0x71385c: r0 = _getValueOrData()
    //     0x71385c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x713860: add             SP, SP, #0x10
    // 0x713864: mov             x1, x0
    // 0x713868: ldur            x0, [fp, #-8]
    // 0x71386c: LoadField: r2 = r0->field_f
    //     0x71386c: ldur            w2, [x0, #0xf]
    // 0x713870: DecompressPointer r2
    //     0x713870: add             x2, x2, HEAP, lsl #32
    // 0x713874: cmp             w2, w1
    // 0x713878: b.ne            #0x713880
    // 0x71387c: r1 = Null
    //     0x71387c: mov             x1, NULL
    // 0x713880: ldur            x2, [fp, #-0x10]
    // 0x713884: stur            x1, [fp, #-8]
    // 0x713888: cmp             w1, NULL
    // 0x71388c: b.eq            #0x713b00
    // 0x713890: StoreField: r2->field_13 = rNULL
    //     0x713890: stur            NULL, [x2, #0x13]
    // 0x713894: r0 = LoadClassIdInstr(r1)
    //     0x713894: ldur            x0, [x1, #-1]
    //     0x713898: ubfx            x0, x0, #0xc, #0x14
    // 0x71389c: SaveReg r1
    //     0x71389c: str             x1, [SP, #-8]!
    // 0x7138a0: r0 = GDT[cid_x0 + -0xf7d]()
    //     0x7138a0: sub             lr, x0, #0xf7d
    //     0x7138a4: ldr             lr, [x21, lr, lsl #3]
    //     0x7138a8: blr             lr
    // 0x7138ac: add             SP, SP, #8
    // 0x7138b0: mov             x1, x0
    // 0x7138b4: ldur            x2, [fp, #-0x10]
    // 0x7138b8: stur            x1, [fp, #-0x18]
    // 0x7138bc: StoreField: r2->field_17 = r0
    //     0x7138bc: stur            w0, [x2, #0x17]
    //     0x7138c0: ldurb           w16, [x2, #-1]
    //     0x7138c4: ldurb           w17, [x0, #-1]
    //     0x7138c8: and             x16, x17, x16, lsr #2
    //     0x7138cc: tst             x16, HEAP, lsr #32
    //     0x7138d0: b.eq            #0x7138d8
    //     0x7138d4: bl              #0xd6828c
    // 0x7138d8: cmp             w1, NULL
    // 0x7138dc: b.eq            #0x713a80
    // 0x7138e0: ldr             x3, [fp, #0x18]
    // 0x7138e4: ldur            x0, [fp, #-8]
    // 0x7138e8: LoadField: r4 = r0->field_7
    //     0x7138e8: ldur            w4, [x0, #7]
    // 0x7138ec: DecompressPointer r4
    //     0x7138ec: add             x4, x4, HEAP, lsl #32
    // 0x7138f0: r0 = LoadClassIdInstr(r3)
    //     0x7138f0: ldur            x0, [x3, #-1]
    //     0x7138f4: ubfx            x0, x0, #0xc, #0x14
    // 0x7138f8: stp             x1, x3, [SP, #-0x10]!
    // 0x7138fc: SaveReg r4
    //     0x7138fc: str             x4, [SP, #-8]!
    // 0x713900: r0 = GDT[cid_x0 + -0xfe2]()
    //     0x713900: sub             lr, x0, #0xfe2
    //     0x713904: ldr             lr, [x21, lr, lsl #3]
    //     0x713908: blr             lr
    // 0x71390c: add             SP, SP, #0x18
    // 0x713910: tbnz            w0, #4, #0x713a7c
    // 0x713914: ldr             x1, [fp, #0x18]
    // 0x713918: ldur            x0, [fp, #-0x18]
    // 0x71391c: LoadField: r2 = r0->field_7
    //     0x71391c: ldur            w2, [x0, #7]
    // 0x713920: DecompressPointer r2
    //     0x713920: add             x2, x2, HEAP, lsl #32
    // 0x713924: stur            x2, [fp, #-8]
    // 0x713928: r0 = Velocity()
    //     0x713928: bl              #0x713f24  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x71392c: mov             x1, x0
    // 0x713930: ldur            x0, [fp, #-8]
    // 0x713934: StoreField: r1->field_7 = r0
    //     0x713934: stur            w0, [x1, #7]
    // 0x713938: ldr             x0, [fp, #0x18]
    // 0x71393c: LoadField: r2 = r0->field_3f
    //     0x71393c: ldur            w2, [x0, #0x3f]
    // 0x713940: DecompressPointer r2
    //     0x713940: add             x2, x2, HEAP, lsl #32
    // 0x713944: cmp             w2, NULL
    // 0x713948: b.ne            #0x713958
    // 0x71394c: d0 = 50.000000
    //     0x71394c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0x713950: ldr             d0, [x17, #0x980]
    // 0x713954: b               #0x71395c
    // 0x713958: LoadField: d0 = r2->field_7
    //     0x713958: ldur            d0, [x2, #7]
    // 0x71395c: LoadField: r2 = r0->field_43
    //     0x71395c: ldur            w2, [x0, #0x43]
    // 0x713960: DecompressPointer r2
    //     0x713960: add             x2, x2, HEAP, lsl #32
    // 0x713964: cmp             w2, NULL
    // 0x713968: b.ne            #0x713978
    // 0x71396c: d1 = 8000.000000
    //     0x71396c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e910] IMM: double(8000) from 0x40bf400000000000
    //     0x713970: ldr             d1, [x17, #0x910]
    // 0x713974: b               #0x71397c
    // 0x713978: LoadField: d1 = r2->field_7
    //     0x713978: ldur            d1, [x2, #7]
    // 0x71397c: ldur            x2, [fp, #-0x10]
    // 0x713980: r3 = inline_Allocate_Double()
    //     0x713980: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x713984: add             x3, x3, #0x10
    //     0x713988: cmp             x4, x3
    //     0x71398c: b.ls            #0x713b04
    //     0x713990: str             x3, [THR, #0x60]  ; THR::top
    //     0x713994: sub             x3, x3, #0xf
    //     0x713998: mov             x4, #0xd108
    //     0x71399c: movk            x4, #3, lsl #16
    //     0x7139a0: stur            x4, [x3, #-1]
    // 0x7139a4: StoreField: r3->field_7 = d0
    //     0x7139a4: stur            d0, [x3, #7]
    // 0x7139a8: stp             x3, x1, [SP, #-0x10]!
    // 0x7139ac: SaveReg d1
    //     0x7139ac: str             d1, [SP, #-8]!
    // 0x7139b0: r0 = clampMagnitude()
    //     0x7139b0: bl              #0x713c18  ; [package:flutter/src/gestures/velocity_tracker.dart] Velocity::clampMagnitude
    // 0x7139b4: add             SP, SP, #0x18
    // 0x7139b8: mov             x1, x0
    // 0x7139bc: ldur            x2, [fp, #-0x10]
    // 0x7139c0: stur            x1, [fp, #-8]
    // 0x7139c4: StoreField: r2->field_1b = r0
    //     0x7139c4: stur            w0, [x2, #0x1b]
    //     0x7139c8: ldurb           w16, [x2, #-1]
    //     0x7139cc: ldurb           w17, [x0, #-1]
    //     0x7139d0: and             x16, x17, x16, lsr #2
    //     0x7139d4: tst             x16, HEAP, lsr #32
    //     0x7139d8: b.eq            #0x7139e0
    //     0x7139dc: bl              #0xd6828c
    // 0x7139e0: LoadField: r0 = r1->field_7
    //     0x7139e0: ldur            w0, [x1, #7]
    // 0x7139e4: DecompressPointer r0
    //     0x7139e4: add             x0, x0, HEAP, lsl #32
    // 0x7139e8: ldr             x3, [fp, #0x18]
    // 0x7139ec: r4 = LoadClassIdInstr(r3)
    //     0x7139ec: ldur            x4, [x3, #-1]
    //     0x7139f0: ubfx            x4, x4, #0xc, #0x14
    // 0x7139f4: lsl             x4, x4, #1
    // 0x7139f8: r17 = 4732
    //     0x7139f8: mov             x17, #0x127c
    // 0x7139fc: cmp             w4, w17
    // 0x713a00: b.ne            #0x713a0c
    // 0x713a04: LoadField: d0 = r0->field_7
    //     0x713a04: ldur            d0, [x0, #7]
    // 0x713a08: b               #0x713a10
    // 0x713a0c: LoadField: d0 = r0->field_f
    //     0x713a0c: ldur            d0, [x0, #0xf]
    // 0x713a10: stur            d0, [fp, #-0x20]
    // 0x713a14: r0 = DragEndDetails()
    //     0x713a14: bl              #0x713c0c  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x10)
    // 0x713a18: mov             x1, x0
    // 0x713a1c: ldur            x0, [fp, #-8]
    // 0x713a20: StoreField: r1->field_7 = r0
    //     0x713a20: stur            w0, [x1, #7]
    // 0x713a24: ldur            d0, [fp, #-0x20]
    // 0x713a28: r0 = inline_Allocate_Double()
    //     0x713a28: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x713a2c: add             x0, x0, #0x10
    //     0x713a30: cmp             x2, x0
    //     0x713a34: b.ls            #0x713b28
    //     0x713a38: str             x0, [THR, #0x60]  ; THR::top
    //     0x713a3c: sub             x0, x0, #0xf
    //     0x713a40: mov             x2, #0xd108
    //     0x713a44: movk            x2, #3, lsl #16
    //     0x713a48: stur            x2, [x0, #-1]
    // 0x713a4c: StoreField: r0->field_7 = d0
    //     0x713a4c: stur            d0, [x0, #7]
    // 0x713a50: StoreField: r1->field_b = r0
    //     0x713a50: stur            w0, [x1, #0xb]
    // 0x713a54: mov             x0, x1
    // 0x713a58: ldur            x2, [fp, #-0x10]
    // 0x713a5c: StoreField: r2->field_13 = r0
    //     0x713a5c: stur            w0, [x2, #0x13]
    //     0x713a60: ldurb           w16, [x2, #-1]
    //     0x713a64: ldurb           w17, [x0, #-1]
    //     0x713a68: and             x16, x17, x16, lsr #2
    //     0x713a6c: tst             x16, HEAP, lsr #32
    //     0x713a70: b.eq            #0x713a78
    //     0x713a74: bl              #0xd6828c
    // 0x713a78: b               #0x713ac0
    // 0x713a7c: ldur            x2, [fp, #-0x10]
    // 0x713a80: r0 = DragEndDetails()
    //     0x713a80: bl              #0x713c0c  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x10)
    // 0x713a84: mov             x1, x0
    // 0x713a88: r0 = Instance_Velocity
    //     0x713a88: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e850] Obj!Velocity@b38701
    //     0x713a8c: ldr             x0, [x0, #0x850]
    // 0x713a90: StoreField: r1->field_7 = r0
    //     0x713a90: stur            w0, [x1, #7]
    // 0x713a94: r0 = 0.000000
    //     0x713a94: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x713a98: StoreField: r1->field_b = r0
    //     0x713a98: stur            w0, [x1, #0xb]
    // 0x713a9c: mov             x0, x1
    // 0x713aa0: ldur            x2, [fp, #-0x10]
    // 0x713aa4: StoreField: r2->field_13 = r0
    //     0x713aa4: stur            w0, [x2, #0x13]
    //     0x713aa8: ldurb           w16, [x2, #-1]
    //     0x713aac: ldurb           w17, [x0, #-1]
    //     0x713ab0: and             x16, x17, x16, lsr #2
    //     0x713ab4: tst             x16, HEAP, lsr #32
    //     0x713ab8: b.eq            #0x713ac0
    //     0x713abc: bl              #0xd6828c
    // 0x713ac0: r1 = Function '<anonymous closure>':.
    //     0x713ac0: add             x1, PP, #0x53, lsl #12  ; [pp+0x537d0] AnonymousClosure: (0x713f30), in [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_checkEnd (0x7137e4)
    //     0x713ac4: ldr             x1, [x1, #0x7d0]
    // 0x713ac8: r0 = AllocateClosure()
    //     0x713ac8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x713acc: r16 = <void?>
    //     0x713acc: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x713ad0: ldr             lr, [fp, #0x18]
    // 0x713ad4: stp             lr, x16, [SP, #-0x10]!
    // 0x713ad8: SaveReg r0
    //     0x713ad8: str             x0, [SP, #-8]!
    // 0x713adc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x713adc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x713ae0: r0 = invokeCallback()
    //     0x713ae0: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x713ae4: add             SP, SP, #0x18
    // 0x713ae8: r0 = Null
    //     0x713ae8: mov             x0, NULL
    // 0x713aec: LeaveFrame
    //     0x713aec: mov             SP, fp
    //     0x713af0: ldp             fp, lr, [SP], #0x10
    // 0x713af4: ret
    //     0x713af4: ret             
    // 0x713af8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x713af8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x713afc: b               #0x7137fc
    // 0x713b00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x713b00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x713b04: stp             q0, q1, [SP, #-0x20]!
    // 0x713b08: stp             x1, x2, [SP, #-0x10]!
    // 0x713b0c: SaveReg r0
    //     0x713b0c: str             x0, [SP, #-8]!
    // 0x713b10: r0 = AllocateDouble()
    //     0x713b10: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x713b14: mov             x3, x0
    // 0x713b18: RestoreReg r0
    //     0x713b18: ldr             x0, [SP], #8
    // 0x713b1c: ldp             x1, x2, [SP], #0x10
    // 0x713b20: ldp             q0, q1, [SP], #0x20
    // 0x713b24: b               #0x7139a4
    // 0x713b28: SaveReg d0
    //     0x713b28: str             q0, [SP, #-0x10]!
    // 0x713b2c: SaveReg r1
    //     0x713b2c: str             x1, [SP, #-8]!
    // 0x713b30: r0 = AllocateDouble()
    //     0x713b30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x713b34: RestoreReg r1
    //     0x713b34: ldr             x1, [SP], #8
    // 0x713b38: RestoreReg d0
    //     0x713b38: ldr             q0, [SP], #0x10
    // 0x713b3c: b               #0x713a4c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x713f30, size: 0x70
    // 0x713f30: EnterFrame
    //     0x713f30: stp             fp, lr, [SP, #-0x10]!
    //     0x713f34: mov             fp, SP
    // 0x713f38: ldr             x0, [fp, #0x10]
    // 0x713f3c: LoadField: r1 = r0->field_17
    //     0x713f3c: ldur            w1, [x0, #0x17]
    // 0x713f40: DecompressPointer r1
    //     0x713f40: add             x1, x1, HEAP, lsl #32
    // 0x713f44: CheckStackOverflow
    //     0x713f44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x713f48: cmp             SP, x16
    //     0x713f4c: b.ls            #0x713f94
    // 0x713f50: LoadField: r0 = r1->field_f
    //     0x713f50: ldur            w0, [x1, #0xf]
    // 0x713f54: DecompressPointer r0
    //     0x713f54: add             x0, x0, HEAP, lsl #32
    // 0x713f58: LoadField: r2 = r0->field_33
    //     0x713f58: ldur            w2, [x0, #0x33]
    // 0x713f5c: DecompressPointer r2
    //     0x713f5c: add             x2, x2, HEAP, lsl #32
    // 0x713f60: cmp             w2, NULL
    // 0x713f64: b.eq            #0x713f9c
    // 0x713f68: LoadField: r0 = r1->field_13
    //     0x713f68: ldur            w0, [x1, #0x13]
    // 0x713f6c: DecompressPointer r0
    //     0x713f6c: add             x0, x0, HEAP, lsl #32
    // 0x713f70: stp             x0, x2, [SP, #-0x10]!
    // 0x713f74: mov             x0, x2
    // 0x713f78: ClosureCall
    //     0x713f78: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x713f7c: ldur            x2, [x0, #0x1f]
    //     0x713f80: blr             x2
    // 0x713f84: add             SP, SP, #0x10
    // 0x713f88: LeaveFrame
    //     0x713f88: mov             SP, fp
    //     0x713f8c: ldp             fp, lr, [SP], #0x10
    // 0x713f90: ret
    //     0x713f90: ret             
    // 0x713f94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x713f94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x713f98: b               #0x713f50
    // 0x713f9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x713f9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkCancel(/* No info */) {
    // ** addr: 0x713fa0, size: 0x58
    // 0x713fa0: EnterFrame
    //     0x713fa0: stp             fp, lr, [SP, #-0x10]!
    //     0x713fa4: mov             fp, SP
    // 0x713fa8: CheckStackOverflow
    //     0x713fa8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x713fac: cmp             SP, x16
    //     0x713fb0: b.ls            #0x713ff0
    // 0x713fb4: ldr             x0, [fp, #0x10]
    // 0x713fb8: LoadField: r1 = r0->field_37
    //     0x713fb8: ldur            w1, [x0, #0x37]
    // 0x713fbc: DecompressPointer r1
    //     0x713fbc: add             x1, x1, HEAP, lsl #32
    // 0x713fc0: cmp             w1, NULL
    // 0x713fc4: b.eq            #0x713fe0
    // 0x713fc8: r16 = <void?>
    //     0x713fc8: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x713fcc: stp             x0, x16, [SP, #-0x10]!
    // 0x713fd0: SaveReg r1
    //     0x713fd0: str             x1, [SP, #-8]!
    // 0x713fd4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x713fd4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x713fd8: r0 = invokeCallback()
    //     0x713fd8: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x713fdc: add             SP, SP, #0x18
    // 0x713fe0: r0 = Null
    //     0x713fe0: mov             x0, NULL
    // 0x713fe4: LeaveFrame
    //     0x713fe4: mov             SP, fp
    //     0x713fe8: ldp             fp, lr, [SP], #0x10
    // 0x713fec: ret
    //     0x713fec: ret             
    // 0x713ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x713ff0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x713ff4: b               #0x713fb4
  }
  _ addAllowedPointerPanZoom(/* No info */) {
    // ** addr: 0x7195a4, size: 0xc8
    // 0x7195a4: EnterFrame
    //     0x7195a4: stp             fp, lr, [SP, #-0x10]!
    //     0x7195a8: mov             fp, SP
    // 0x7195ac: AllocStack(0x8)
    //     0x7195ac: sub             SP, SP, #8
    // 0x7195b0: CheckStackOverflow
    //     0x7195b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7195b4: cmp             SP, x16
    //     0x7195b8: b.ls            #0x719664
    // 0x7195bc: ldr             x1, [fp, #0x10]
    // 0x7195c0: r0 = LoadClassIdInstr(r1)
    //     0x7195c0: ldur            x0, [x1, #-1]
    //     0x7195c4: ubfx            x0, x0, #0xc, #0x14
    // 0x7195c8: SaveReg r1
    //     0x7195c8: str             x1, [SP, #-8]!
    // 0x7195cc: r0 = GDT[cid_x0 + -0xfff]()
    //     0x7195cc: sub             lr, x0, #0xfff
    //     0x7195d0: ldr             lr, [x21, lr, lsl #3]
    //     0x7195d4: blr             lr
    // 0x7195d8: add             SP, SP, #8
    // 0x7195dc: mov             x2, x0
    // 0x7195e0: ldr             x1, [fp, #0x10]
    // 0x7195e4: stur            x2, [fp, #-8]
    // 0x7195e8: r0 = LoadClassIdInstr(r1)
    //     0x7195e8: ldur            x0, [x1, #-1]
    //     0x7195ec: ubfx            x0, x0, #0xc, #0x14
    // 0x7195f0: SaveReg r1
    //     0x7195f0: str             x1, [SP, #-8]!
    // 0x7195f4: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x7195f4: mov             x17, #0x3f6e
    //     0x7195f8: add             lr, x0, x17
    //     0x7195fc: ldr             lr, [x21, lr, lsl #3]
    //     0x719600: blr             lr
    // 0x719604: add             SP, SP, #8
    // 0x719608: ldr             x16, [fp, #0x18]
    // 0x71960c: SaveReg r16
    //     0x71960c: str             x16, [SP, #-8]!
    // 0x719610: ldur            x1, [fp, #-8]
    // 0x719614: stp             x0, x1, [SP, #-0x10]!
    // 0x719618: r0 = startTrackingPointer()
    //     0x719618: bl              #0x71111c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::startTrackingPointer
    // 0x71961c: add             SP, SP, #0x18
    // 0x719620: ldr             x0, [fp, #0x18]
    // 0x719624: LoadField: r1 = r0->field_4b
    //     0x719624: ldur            w1, [x0, #0x4b]
    // 0x719628: DecompressPointer r1
    //     0x719628: add             x1, x1, HEAP, lsl #32
    // 0x71962c: r16 = Instance__DragState
    //     0x71962c: add             x16, PP, #0x51, lsl #12  ; [pp+0x51440] Obj!_DragState@b660d1
    //     0x719630: ldr             x16, [x16, #0x440]
    // 0x719634: cmp             w1, w16
    // 0x719638: b.ne            #0x719644
    // 0x71963c: r1 = 2
    //     0x71963c: mov             x1, #2
    // 0x719640: StoreField: r0->field_5b = r1
    //     0x719640: stur            w1, [x0, #0x5b]
    // 0x719644: ldr             x16, [fp, #0x10]
    // 0x719648: stp             x16, x0, [SP, #-0x10]!
    // 0x71964c: r0 = _addPointer()
    //     0x71964c: bl              #0x71966c  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_addPointer
    // 0x719650: add             SP, SP, #0x10
    // 0x719654: r0 = Null
    //     0x719654: mov             x0, NULL
    // 0x719658: LeaveFrame
    //     0x719658: mov             SP, fp
    //     0x71965c: ldp             fp, lr, [SP], #0x10
    // 0x719660: ret
    //     0x719660: ret             
    // 0x719664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x719664: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x719668: b               #0x7195bc
  }
  _ _addPointer(/* No info */) {
    // ** addr: 0x71966c, size: 0x240
    // 0x71966c: EnterFrame
    //     0x71966c: stp             fp, lr, [SP, #-0x10]!
    //     0x719670: mov             fp, SP
    // 0x719674: AllocStack(0x18)
    //     0x719674: sub             SP, SP, #0x18
    // 0x719678: CheckStackOverflow
    //     0x719678: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71967c: cmp             SP, x16
    //     0x719680: b.ls            #0x7198a4
    // 0x719684: ldr             x1, [fp, #0x18]
    // 0x719688: LoadField: r2 = r1->field_67
    //     0x719688: ldur            w2, [x1, #0x67]
    // 0x71968c: DecompressPointer r2
    //     0x71968c: add             x2, x2, HEAP, lsl #32
    // 0x719690: ldr             x3, [fp, #0x10]
    // 0x719694: stur            x2, [fp, #-8]
    // 0x719698: r0 = LoadClassIdInstr(r3)
    //     0x719698: ldur            x0, [x3, #-1]
    //     0x71969c: ubfx            x0, x0, #0xc, #0x14
    // 0x7196a0: SaveReg r3
    //     0x7196a0: str             x3, [SP, #-8]!
    // 0x7196a4: r0 = GDT[cid_x0 + -0xfff]()
    //     0x7196a4: sub             lr, x0, #0xfff
    //     0x7196a8: ldr             lr, [x21, lr, lsl #3]
    //     0x7196ac: blr             lr
    // 0x7196b0: add             SP, SP, #8
    // 0x7196b4: mov             x2, x0
    // 0x7196b8: ldr             x1, [fp, #0x18]
    // 0x7196bc: stur            x2, [fp, #-0x10]
    // 0x7196c0: LoadField: r0 = r1->field_47
    //     0x7196c0: ldur            w0, [x1, #0x47]
    // 0x7196c4: DecompressPointer r0
    //     0x7196c4: add             x0, x0, HEAP, lsl #32
    // 0x7196c8: ldr             x16, [fp, #0x10]
    // 0x7196cc: stp             x16, x0, [SP, #-0x10]!
    // 0x7196d0: ClosureCall
    //     0x7196d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x7196d4: ldur            x2, [x0, #0x1f]
    //     0x7196d8: blr             x2
    // 0x7196dc: add             SP, SP, #0x10
    // 0x7196e0: mov             x3, x0
    // 0x7196e4: ldur            x2, [fp, #-0x10]
    // 0x7196e8: r0 = BoxInt64Instr(r2)
    //     0x7196e8: sbfiz           x0, x2, #1, #0x1f
    //     0x7196ec: cmp             x2, x0, asr #1
    //     0x7196f0: b.eq            #0x7196fc
    //     0x7196f4: bl              #0xd69bb8
    //     0x7196f8: stur            x2, [x0, #7]
    // 0x7196fc: ldur            x16, [fp, #-8]
    // 0x719700: stp             x0, x16, [SP, #-0x10]!
    // 0x719704: SaveReg r3
    //     0x719704: str             x3, [SP, #-8]!
    // 0x719708: r0 = []=()
    //     0x719708: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x71970c: add             SP, SP, #0x18
    // 0x719710: ldr             x1, [fp, #0x18]
    // 0x719714: LoadField: r0 = r1->field_4b
    //     0x719714: ldur            w0, [x1, #0x4b]
    // 0x719718: DecompressPointer r0
    //     0x719718: add             x0, x0, HEAP, lsl #32
    // 0x71971c: r16 = Instance__DragState
    //     0x71971c: add             x16, PP, #0x51, lsl #12  ; [pp+0x51440] Obj!_DragState@b660d1
    //     0x719720: ldr             x16, [x16, #0x440]
    // 0x719724: cmp             w0, w16
    // 0x719728: b.ne            #0x719870
    // 0x71972c: ldr             x2, [fp, #0x10]
    // 0x719730: r0 = Instance__DragState
    //     0x719730: add             x0, PP, #0x53, lsl #12  ; [pp+0x537e8] Obj!_DragState@b660f1
    //     0x719734: ldr             x0, [x0, #0x7e8]
    // 0x719738: StoreField: r1->field_4b = r0
    //     0x719738: stur            w0, [x1, #0x4b]
    // 0x71973c: r0 = LoadClassIdInstr(r2)
    //     0x71973c: ldur            x0, [x2, #-1]
    //     0x719740: ubfx            x0, x0, #0xc, #0x14
    // 0x719744: SaveReg r2
    //     0x719744: str             x2, [SP, #-8]!
    // 0x719748: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x719748: sub             lr, x0, #0xfd9
    //     0x71974c: ldr             lr, [x21, lr, lsl #3]
    //     0x719750: blr             lr
    // 0x719754: add             SP, SP, #8
    // 0x719758: mov             x2, x0
    // 0x71975c: ldr             x1, [fp, #0x10]
    // 0x719760: stur            x2, [fp, #-8]
    // 0x719764: r0 = LoadClassIdInstr(r1)
    //     0x719764: ldur            x0, [x1, #-1]
    //     0x719768: ubfx            x0, x0, #0xc, #0x14
    // 0x71976c: SaveReg r1
    //     0x71976c: str             x1, [SP, #-8]!
    // 0x719770: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x719770: mov             x17, #0x57c0
    //     0x719774: add             lr, x0, x17
    //     0x719778: ldr             lr, [x21, lr, lsl #3]
    //     0x71977c: blr             lr
    // 0x719780: add             SP, SP, #8
    // 0x719784: stur            x0, [fp, #-0x18]
    // 0x719788: r0 = OffsetPair()
    //     0x719788: bl              #0x7142f0  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0x71978c: mov             x1, x0
    // 0x719790: ldur            x0, [fp, #-0x18]
    // 0x719794: StoreField: r1->field_7 = r0
    //     0x719794: stur            w0, [x1, #7]
    // 0x719798: ldur            x0, [fp, #-8]
    // 0x71979c: StoreField: r1->field_b = r0
    //     0x71979c: stur            w0, [x1, #0xb]
    // 0x7197a0: mov             x0, x1
    // 0x7197a4: ldr             x1, [fp, #0x18]
    // 0x7197a8: StoreField: r1->field_4f = r0
    //     0x7197a8: stur            w0, [x1, #0x4f]
    //     0x7197ac: ldurb           w16, [x1, #-1]
    //     0x7197b0: ldurb           w17, [x0, #-1]
    //     0x7197b4: and             x16, x17, x16, lsr #2
    //     0x7197b8: tst             x16, HEAP, lsr #32
    //     0x7197bc: b.eq            #0x7197c4
    //     0x7197c0: bl              #0xd6826c
    // 0x7197c4: r0 = Instance_OffsetPair
    //     0x7197c4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28f10] Obj!OffsetPair@b38711
    //     0x7197c8: ldr             x0, [x0, #0xf10]
    // 0x7197cc: StoreField: r1->field_53 = r0
    //     0x7197cc: stur            w0, [x1, #0x53]
    // 0x7197d0: r0 = 0.000000
    //     0x7197d0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x7197d4: StoreField: r1->field_63 = r0
    //     0x7197d4: stur            w0, [x1, #0x63]
    // 0x7197d8: ldr             x2, [fp, #0x10]
    // 0x7197dc: r0 = LoadClassIdInstr(r2)
    //     0x7197dc: ldur            x0, [x2, #-1]
    //     0x7197e0: ubfx            x0, x0, #0xc, #0x14
    // 0x7197e4: SaveReg r2
    //     0x7197e4: str             x2, [SP, #-8]!
    // 0x7197e8: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x7197e8: sub             lr, x0, #0xf3a
    //     0x7197ec: ldr             lr, [x21, lr, lsl #3]
    //     0x7197f0: blr             lr
    // 0x7197f4: add             SP, SP, #8
    // 0x7197f8: ldr             x1, [fp, #0x18]
    // 0x7197fc: StoreField: r1->field_57 = r0
    //     0x7197fc: stur            w0, [x1, #0x57]
    //     0x719800: ldurb           w16, [x1, #-1]
    //     0x719804: ldurb           w17, [x0, #-1]
    //     0x719808: and             x16, x17, x16, lsr #2
    //     0x71980c: tst             x16, HEAP, lsr #32
    //     0x719810: b.eq            #0x719818
    //     0x719814: bl              #0xd6826c
    // 0x719818: ldr             x0, [fp, #0x10]
    // 0x71981c: r2 = LoadClassIdInstr(r0)
    //     0x71981c: ldur            x2, [x0, #-1]
    //     0x719820: ubfx            x2, x2, #0xc, #0x14
    // 0x719824: SaveReg r0
    //     0x719824: str             x0, [SP, #-8]!
    // 0x719828: mov             x0, x2
    // 0x71982c: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x71982c: mov             x17, #0x3f6e
    //     0x719830: add             lr, x0, x17
    //     0x719834: ldr             lr, [x21, lr, lsl #3]
    //     0x719838: blr             lr
    // 0x71983c: add             SP, SP, #8
    // 0x719840: ldr             x1, [fp, #0x18]
    // 0x719844: StoreField: r1->field_5f = r0
    //     0x719844: stur            w0, [x1, #0x5f]
    //     0x719848: ldurb           w16, [x1, #-1]
    //     0x71984c: ldurb           w17, [x0, #-1]
    //     0x719850: and             x16, x17, x16, lsr #2
    //     0x719854: tst             x16, HEAP, lsr #32
    //     0x719858: b.eq            #0x719860
    //     0x71985c: bl              #0xd6826c
    // 0x719860: SaveReg r1
    //     0x719860: str             x1, [SP, #-8]!
    // 0x719864: r0 = _checkDown()
    //     0x719864: bl              #0x7198ac  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_checkDown
    // 0x719868: add             SP, SP, #8
    // 0x71986c: b               #0x719894
    // 0x719870: r16 = Instance__DragState
    //     0x719870: add             x16, PP, #0x53, lsl #12  ; [pp+0x537a0] Obj!_DragState@b66111
    //     0x719874: ldr             x16, [x16, #0x7a0]
    // 0x719878: cmp             w0, w16
    // 0x71987c: b.ne            #0x719894
    // 0x719880: r16 = Instance_GestureDisposition
    //     0x719880: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x719884: ldr             x16, [x16, #0xed0]
    // 0x719888: stp             x16, x1, [SP, #-0x10]!
    // 0x71988c: r0 = resolve()
    //     0x71988c: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x719890: add             SP, SP, #0x10
    // 0x719894: r0 = Null
    //     0x719894: mov             x0, NULL
    // 0x719898: LeaveFrame
    //     0x719898: mov             SP, fp
    //     0x71989c: ldp             fp, lr, [SP], #0x10
    // 0x7198a0: ret
    //     0x7198a0: ret             
    // 0x7198a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7198a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7198a8: b               #0x719684
  }
  _ _checkDown(/* No info */) {
    // ** addr: 0x7198ac, size: 0xc4
    // 0x7198ac: EnterFrame
    //     0x7198ac: stp             fp, lr, [SP, #-0x10]!
    //     0x7198b0: mov             fp, SP
    // 0x7198b4: AllocStack(0x10)
    //     0x7198b4: sub             SP, SP, #0x10
    // 0x7198b8: CheckStackOverflow
    //     0x7198b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7198bc: cmp             SP, x16
    //     0x7198c0: b.ls            #0x71995c
    // 0x7198c4: r1 = 2
    //     0x7198c4: mov             x1, #2
    // 0x7198c8: r0 = AllocateContext()
    //     0x7198c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7198cc: mov             x1, x0
    // 0x7198d0: ldr             x0, [fp, #0x10]
    // 0x7198d4: stur            x1, [fp, #-0x10]
    // 0x7198d8: StoreField: r1->field_f = r0
    //     0x7198d8: stur            w0, [x1, #0xf]
    // 0x7198dc: LoadField: r2 = r0->field_27
    //     0x7198dc: ldur            w2, [x0, #0x27]
    // 0x7198e0: DecompressPointer r2
    //     0x7198e0: add             x2, x2, HEAP, lsl #32
    // 0x7198e4: cmp             w2, NULL
    // 0x7198e8: b.eq            #0x71994c
    // 0x7198ec: LoadField: r2 = r0->field_4f
    //     0x7198ec: ldur            w2, [x0, #0x4f]
    // 0x7198f0: DecompressPointer r2
    //     0x7198f0: add             x2, x2, HEAP, lsl #32
    // 0x7198f4: r16 = Sentinel
    //     0x7198f4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7198f8: cmp             w2, w16
    // 0x7198fc: b.eq            #0x719964
    // 0x719900: LoadField: r3 = r2->field_b
    //     0x719900: ldur            w3, [x2, #0xb]
    // 0x719904: DecompressPointer r3
    //     0x719904: add             x3, x3, HEAP, lsl #32
    // 0x719908: stur            x3, [fp, #-8]
    // 0x71990c: r0 = DragDownDetails()
    //     0x71990c: bl              #0x719970  ; AllocateDragDownDetailsStub -> DragDownDetails (size=0xc)
    // 0x719910: mov             x1, x0
    // 0x719914: ldur            x0, [fp, #-8]
    // 0x719918: StoreField: r1->field_7 = r0
    //     0x719918: stur            w0, [x1, #7]
    // 0x71991c: ldur            x2, [fp, #-0x10]
    // 0x719920: StoreField: r2->field_13 = r1
    //     0x719920: stur            w1, [x2, #0x13]
    // 0x719924: r1 = Function '<anonymous closure>':.
    //     0x719924: add             x1, PP, #0x53, lsl #12  ; [pp+0x537f0] AnonymousClosure: (0x71997c), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkStart (0x7199ec)
    //     0x719928: ldr             x1, [x1, #0x7f0]
    // 0x71992c: r0 = AllocateClosure()
    //     0x71992c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x719930: r16 = <void?>
    //     0x719930: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x719934: ldr             lr, [fp, #0x10]
    // 0x719938: stp             lr, x16, [SP, #-0x10]!
    // 0x71993c: SaveReg r0
    //     0x71993c: str             x0, [SP, #-8]!
    // 0x719940: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x719940: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x719944: r0 = invokeCallback()
    //     0x719944: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x719948: add             SP, SP, #0x18
    // 0x71994c: r0 = Null
    //     0x71994c: mov             x0, NULL
    // 0x719950: LeaveFrame
    //     0x719950: mov             SP, fp
    //     0x719954: ldp             fp, lr, [SP], #0x10
    // 0x719958: ret
    //     0x719958: ret             
    // 0x71995c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71995c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x719960: b               #0x7198c4
    // 0x719964: r9 = _initialPosition
    //     0x719964: add             x9, PP, #0x53, lsl #12  ; [pp+0x537d8] Field <ExtendedDragGestureRecognizer._initialPosition@424469339>: late (offset: 0x50)
    //     0x719968: ldr             x9, [x9, #0x7d8]
    // 0x71996c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71996c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x782048, size: 0xcc
    // 0x782048: EnterFrame
    //     0x782048: stp             fp, lr, [SP, #-0x10]!
    //     0x78204c: mov             fp, SP
    // 0x782050: CheckStackOverflow
    //     0x782050: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x782054: cmp             SP, x16
    //     0x782058: b.ls            #0x78210c
    // 0x78205c: ldr             x16, [fp, #0x18]
    // 0x782060: ldr             lr, [fp, #0x10]
    // 0x782064: stp             lr, x16, [SP, #-0x10]!
    // 0x782068: r0 = addAllowedPointer()
    //     0x782068: bl              #0x782114  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0x78206c: add             SP, SP, #0x10
    // 0x782070: ldr             x1, [fp, #0x18]
    // 0x782074: LoadField: r0 = r1->field_4b
    //     0x782074: ldur            w0, [x1, #0x4b]
    // 0x782078: DecompressPointer r0
    //     0x782078: add             x0, x0, HEAP, lsl #32
    // 0x78207c: r16 = Instance__DragState
    //     0x78207c: add             x16, PP, #0x51, lsl #12  ; [pp+0x51440] Obj!_DragState@b660d1
    //     0x782080: ldr             x16, [x16, #0x440]
    // 0x782084: cmp             w0, w16
    // 0x782088: b.ne            #0x7820ec
    // 0x78208c: ldr             x2, [fp, #0x10]
    // 0x782090: r0 = LoadClassIdInstr(r2)
    //     0x782090: ldur            x0, [x2, #-1]
    //     0x782094: ubfx            x0, x0, #0xc, #0x14
    // 0x782098: SaveReg r2
    //     0x782098: str             x2, [SP, #-8]!
    // 0x78209c: r0 = GDT[cid_x0 + 0x271c]()
    //     0x78209c: mov             x17, #0x271c
    //     0x7820a0: add             lr, x0, x17
    //     0x7820a4: ldr             lr, [x21, lr, lsl #3]
    //     0x7820a8: blr             lr
    // 0x7820ac: add             SP, SP, #8
    // 0x7820b0: mov             x2, x0
    // 0x7820b4: r0 = BoxInt64Instr(r2)
    //     0x7820b4: sbfiz           x0, x2, #1, #0x1f
    //     0x7820b8: cmp             x2, x0, asr #1
    //     0x7820bc: b.eq            #0x7820c8
    //     0x7820c0: bl              #0xd69bb8
    //     0x7820c4: stur            x2, [x0, #7]
    // 0x7820c8: ldr             x1, [fp, #0x18]
    // 0x7820cc: StoreField: r1->field_5b = r0
    //     0x7820cc: stur            w0, [x1, #0x5b]
    //     0x7820d0: tbz             w0, #0, #0x7820ec
    //     0x7820d4: ldurb           w16, [x1, #-1]
    //     0x7820d8: ldurb           w17, [x0, #-1]
    //     0x7820dc: and             x16, x17, x16, lsr #2
    //     0x7820e0: tst             x16, HEAP, lsr #32
    //     0x7820e4: b.eq            #0x7820ec
    //     0x7820e8: bl              #0xd6826c
    // 0x7820ec: ldr             x16, [fp, #0x10]
    // 0x7820f0: stp             x16, x1, [SP, #-0x10]!
    // 0x7820f4: r0 = _addPointer()
    //     0x7820f4: bl              #0x71966c  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_addPointer
    // 0x7820f8: add             SP, SP, #0x10
    // 0x7820fc: r0 = Null
    //     0x7820fc: mov             x0, NULL
    // 0x782100: LeaveFrame
    //     0x782100: mov             SP, fp
    //     0x782104: ldp             fp, lr, [SP], #0x10
    // 0x782108: ret
    //     0x782108: ret             
    // 0x78210c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78210c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x782110: b               #0x78205c
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0x7874d4, size: 0x18
    // 0x7874d4: r4 = 0
    //     0x7874d4: mov             x4, #0
    // 0x7874d8: r1 = Function 'handleEvent':.
    //     0x7874d8: add             x17, PP, #0x53, lsl #12  ; [pp+0x53758] AnonymousClosure: (0x7874ec), in [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::handleEvent (0x787538)
    //     0x7874dc: ldr             x1, [x17, #0x758]
    // 0x7874e0: r24 = BuildNonGenericMethodExtractorStub
    //     0x7874e0: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x7874e4: LoadField: r0 = r24->field_17
    //     0x7874e4: ldur            x0, [x24, #0x17]
    // 0x7874e8: br              x0
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0x7874ec, size: 0x4c
    // 0x7874ec: EnterFrame
    //     0x7874ec: stp             fp, lr, [SP, #-0x10]!
    //     0x7874f0: mov             fp, SP
    // 0x7874f4: ldr             x0, [fp, #0x18]
    // 0x7874f8: LoadField: r1 = r0->field_17
    //     0x7874f8: ldur            w1, [x0, #0x17]
    // 0x7874fc: DecompressPointer r1
    //     0x7874fc: add             x1, x1, HEAP, lsl #32
    // 0x787500: CheckStackOverflow
    //     0x787500: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x787504: cmp             SP, x16
    //     0x787508: b.ls            #0x787530
    // 0x78750c: LoadField: r0 = r1->field_f
    //     0x78750c: ldur            w0, [x1, #0xf]
    // 0x787510: DecompressPointer r0
    //     0x787510: add             x0, x0, HEAP, lsl #32
    // 0x787514: ldr             x16, [fp, #0x10]
    // 0x787518: stp             x16, x0, [SP, #-0x10]!
    // 0x78751c: r0 = handleEvent()
    //     0x78751c: bl              #0x787538  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::handleEvent
    // 0x787520: add             SP, SP, #0x10
    // 0x787524: LeaveFrame
    //     0x787524: mov             SP, fp
    //     0x787528: ldp             fp, lr, [SP], #0x10
    // 0x78752c: ret
    //     0x78752c: ret             
    // 0x787530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x787530: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x787534: b               #0x78750c
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x787538, size: 0xfb0
    // 0x787538: EnterFrame
    //     0x787538: stp             fp, lr, [SP, #-0x10]!
    //     0x78753c: mov             fp, SP
    // 0x787540: AllocStack(0x40)
    //     0x787540: sub             SP, SP, #0x40
    // 0x787544: CheckStackOverflow
    //     0x787544: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x787548: cmp             SP, x16
    //     0x78754c: b.ls            #0x7884a0
    // 0x787550: ldr             x1, [fp, #0x10]
    // 0x787554: r0 = LoadClassIdInstr(r1)
    //     0x787554: ldur            x0, [x1, #-1]
    //     0x787558: ubfx            x0, x0, #0xc, #0x14
    // 0x78755c: SaveReg r1
    //     0x78755c: str             x1, [SP, #-8]!
    // 0x787560: r0 = GDT[cid_x0 + 0x7012]()
    //     0x787560: mov             x17, #0x7012
    //     0x787564: add             lr, x0, x17
    //     0x787568: ldr             lr, [x21, lr, lsl #3]
    //     0x78756c: blr             lr
    // 0x787570: add             SP, SP, #8
    // 0x787574: tbz             w0, #4, #0x7878d4
    // 0x787578: ldr             x0, [fp, #0x10]
    // 0x78757c: r2 = Null
    //     0x78757c: mov             x2, NULL
    // 0x787580: r1 = Null
    //     0x787580: mov             x1, NULL
    // 0x787584: cmp             w0, NULL
    // 0x787588: b.eq            #0x7875a8
    // 0x78758c: branchIfSmi(r0, 0x7875a8)
    //     0x78758c: tbz             w0, #0, #0x7875a8
    // 0x787590: r3 = LoadClassIdInstr(r0)
    //     0x787590: ldur            x3, [x0, #-1]
    //     0x787594: ubfx            x3, x3, #0xc, #0x14
    // 0x787598: cmp             x3, #0x90a
    // 0x78759c: b.eq            #0x7875b0
    // 0x7875a0: cmp             x3, #0xb41
    // 0x7875a4: b.eq            #0x7875b0
    // 0x7875a8: r0 = false
    //     0x7875a8: add             x0, NULL, #0x30  ; false
    // 0x7875ac: b               #0x7875b4
    // 0x7875b0: r0 = true
    //     0x7875b0: add             x0, NULL, #0x20  ; true
    // 0x7875b4: tbz             w0, #4, #0x787678
    // 0x7875b8: ldr             x0, [fp, #0x10]
    // 0x7875bc: r2 = Null
    //     0x7875bc: mov             x2, NULL
    // 0x7875c0: r1 = Null
    //     0x7875c0: mov             x1, NULL
    // 0x7875c4: cmp             w0, NULL
    // 0x7875c8: b.eq            #0x7875e8
    // 0x7875cc: branchIfSmi(r0, 0x7875e8)
    //     0x7875cc: tbz             w0, #0, #0x7875e8
    // 0x7875d0: r3 = LoadClassIdInstr(r0)
    //     0x7875d0: ldur            x3, [x0, #-1]
    //     0x7875d4: ubfx            x3, x3, #0xc, #0x14
    // 0x7875d8: cmp             x3, #0x908
    // 0x7875dc: b.eq            #0x7875f0
    // 0x7875e0: cmp             x3, #0xb3f
    // 0x7875e4: b.eq            #0x7875f0
    // 0x7875e8: r0 = false
    //     0x7875e8: add             x0, NULL, #0x30  ; false
    // 0x7875ec: b               #0x7875f4
    // 0x7875f0: r0 = true
    //     0x7875f0: add             x0, NULL, #0x20  ; true
    // 0x7875f4: tbz             w0, #4, #0x787678
    // 0x7875f8: ldr             x0, [fp, #0x10]
    // 0x7875fc: r2 = Null
    //     0x7875fc: mov             x2, NULL
    // 0x787600: r1 = Null
    //     0x787600: mov             x1, NULL
    // 0x787604: cmp             w0, NULL
    // 0x787608: b.eq            #0x787628
    // 0x78760c: branchIfSmi(r0, 0x787628)
    //     0x78760c: tbz             w0, #0, #0x787628
    // 0x787610: r3 = LoadClassIdInstr(r0)
    //     0x787610: ldur            x3, [x0, #-1]
    //     0x787614: ubfx            x3, x3, #0xc, #0x14
    // 0x787618: cmp             x3, #0x8fe
    // 0x78761c: b.eq            #0x787630
    // 0x787620: cmp             x3, #0xb3b
    // 0x787624: b.eq            #0x787630
    // 0x787628: r0 = false
    //     0x787628: add             x0, NULL, #0x30  ; false
    // 0x78762c: b               #0x787634
    // 0x787630: r0 = true
    //     0x787630: add             x0, NULL, #0x20  ; true
    // 0x787634: tbz             w0, #4, #0x787678
    // 0x787638: ldr             x0, [fp, #0x10]
    // 0x78763c: r2 = Null
    //     0x78763c: mov             x2, NULL
    // 0x787640: r1 = Null
    //     0x787640: mov             x1, NULL
    // 0x787644: cmp             w0, NULL
    // 0x787648: b.eq            #0x787668
    // 0x78764c: branchIfSmi(r0, 0x787668)
    //     0x78764c: tbz             w0, #0, #0x787668
    // 0x787650: r3 = LoadClassIdInstr(r0)
    //     0x787650: ldur            x3, [x0, #-1]
    //     0x787654: ubfx            x3, x3, #0xc, #0x14
    // 0x787658: cmp             x3, #0x8fc
    // 0x78765c: b.eq            #0x787670
    // 0x787660: cmp             x3, #0xb39
    // 0x787664: b.eq            #0x787670
    // 0x787668: r0 = false
    //     0x787668: add             x0, NULL, #0x30  ; false
    // 0x78766c: b               #0x787674
    // 0x787670: r0 = true
    //     0x787670: add             x0, NULL, #0x20  ; true
    // 0x787674: tbnz            w0, #4, #0x7878d4
    // 0x787678: ldr             x2, [fp, #0x18]
    // 0x78767c: ldr             x1, [fp, #0x10]
    // 0x787680: LoadField: r3 = r2->field_67
    //     0x787680: ldur            w3, [x2, #0x67]
    // 0x787684: DecompressPointer r3
    //     0x787684: add             x3, x3, HEAP, lsl #32
    // 0x787688: stur            x3, [fp, #-8]
    // 0x78768c: r0 = LoadClassIdInstr(r1)
    //     0x78768c: ldur            x0, [x1, #-1]
    //     0x787690: ubfx            x0, x0, #0xc, #0x14
    // 0x787694: SaveReg r1
    //     0x787694: str             x1, [SP, #-8]!
    // 0x787698: r0 = GDT[cid_x0 + -0xfff]()
    //     0x787698: sub             lr, x0, #0xfff
    //     0x78769c: ldr             lr, [x21, lr, lsl #3]
    //     0x7876a0: blr             lr
    // 0x7876a4: add             SP, SP, #8
    // 0x7876a8: mov             x2, x0
    // 0x7876ac: r0 = BoxInt64Instr(r2)
    //     0x7876ac: sbfiz           x0, x2, #1, #0x1f
    //     0x7876b0: cmp             x2, x0, asr #1
    //     0x7876b4: b.eq            #0x7876c0
    //     0x7876b8: bl              #0xd69bb8
    //     0x7876bc: stur            x2, [x0, #7]
    // 0x7876c0: ldur            x16, [fp, #-8]
    // 0x7876c4: stp             x0, x16, [SP, #-0x10]!
    // 0x7876c8: r0 = _getValueOrData()
    //     0x7876c8: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x7876cc: add             SP, SP, #0x10
    // 0x7876d0: mov             x1, x0
    // 0x7876d4: ldur            x0, [fp, #-8]
    // 0x7876d8: LoadField: r2 = r0->field_f
    //     0x7876d8: ldur            w2, [x0, #0xf]
    // 0x7876dc: DecompressPointer r2
    //     0x7876dc: add             x2, x2, HEAP, lsl #32
    // 0x7876e0: cmp             w2, w1
    // 0x7876e4: b.ne            #0x7876f0
    // 0x7876e8: r3 = Null
    //     0x7876e8: mov             x3, NULL
    // 0x7876ec: b               #0x7876f4
    // 0x7876f0: mov             x3, x1
    // 0x7876f4: stur            x3, [fp, #-8]
    // 0x7876f8: cmp             w3, NULL
    // 0x7876fc: b.eq            #0x7884a8
    // 0x787700: ldr             x0, [fp, #0x10]
    // 0x787704: r2 = Null
    //     0x787704: mov             x2, NULL
    // 0x787708: r1 = Null
    //     0x787708: mov             x1, NULL
    // 0x78770c: cmp             w0, NULL
    // 0x787710: b.eq            #0x787730
    // 0x787714: branchIfSmi(r0, 0x787730)
    //     0x787714: tbz             w0, #0, #0x787730
    // 0x787718: r3 = LoadClassIdInstr(r0)
    //     0x787718: ldur            x3, [x0, #-1]
    //     0x78771c: ubfx            x3, x3, #0xc, #0x14
    // 0x787720: cmp             x3, #0x8fe
    // 0x787724: b.eq            #0x787738
    // 0x787728: cmp             x3, #0xb3b
    // 0x78772c: b.eq            #0x787738
    // 0x787730: r0 = false
    //     0x787730: add             x0, NULL, #0x30  ; false
    // 0x787734: b               #0x78773c
    // 0x787738: r0 = true
    //     0x787738: add             x0, NULL, #0x20  ; true
    // 0x78773c: tbnz            w0, #4, #0x787794
    // 0x787740: ldr             x2, [fp, #0x10]
    // 0x787744: ldur            x1, [fp, #-8]
    // 0x787748: r0 = LoadClassIdInstr(r2)
    //     0x787748: ldur            x0, [x2, #-1]
    //     0x78774c: ubfx            x0, x0, #0xc, #0x14
    // 0x787750: SaveReg r2
    //     0x787750: str             x2, [SP, #-8]!
    // 0x787754: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x787754: sub             lr, x0, #0xf3a
    //     0x787758: ldr             lr, [x21, lr, lsl #3]
    //     0x78775c: blr             lr
    // 0x787760: add             SP, SP, #8
    // 0x787764: ldur            x3, [fp, #-8]
    // 0x787768: r1 = LoadClassIdInstr(r3)
    //     0x787768: ldur            x1, [x3, #-1]
    //     0x78776c: ubfx            x1, x1, #0xc, #0x14
    // 0x787770: stp             x0, x3, [SP, #-0x10]!
    // 0x787774: r16 = Instance_Offset
    //     0x787774: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x787778: SaveReg r16
    //     0x787778: str             x16, [SP, #-8]!
    // 0x78777c: mov             x0, x1
    // 0x787780: r0 = GDT[cid_x0 + -0xf82]()
    //     0x787780: sub             lr, x0, #0xf82
    //     0x787784: ldr             lr, [x21, lr, lsl #3]
    //     0x787788: blr             lr
    // 0x78778c: add             SP, SP, #0x18
    // 0x787790: b               #0x7878d4
    // 0x787794: ldur            x3, [fp, #-8]
    // 0x787798: ldr             x0, [fp, #0x10]
    // 0x78779c: r2 = Null
    //     0x78779c: mov             x2, NULL
    // 0x7877a0: r1 = Null
    //     0x7877a0: mov             x1, NULL
    // 0x7877a4: cmp             w0, NULL
    // 0x7877a8: b.eq            #0x7877c8
    // 0x7877ac: branchIfSmi(r0, 0x7877c8)
    //     0x7877ac: tbz             w0, #0, #0x7877c8
    // 0x7877b0: r3 = LoadClassIdInstr(r0)
    //     0x7877b0: ldur            x3, [x0, #-1]
    //     0x7877b4: ubfx            x3, x3, #0xc, #0x14
    // 0x7877b8: cmp             x3, #0x8fc
    // 0x7877bc: b.eq            #0x7877d0
    // 0x7877c0: cmp             x3, #0xb39
    // 0x7877c4: b.eq            #0x7877d0
    // 0x7877c8: r0 = false
    //     0x7877c8: add             x0, NULL, #0x30  ; false
    // 0x7877cc: b               #0x7877d4
    // 0x7877d0: r0 = true
    //     0x7877d0: add             x0, NULL, #0x20  ; true
    // 0x7877d4: tbnz            w0, #4, #0x787854
    // 0x7877d8: ldr             x2, [fp, #0x10]
    // 0x7877dc: ldur            x1, [fp, #-8]
    // 0x7877e0: r0 = LoadClassIdInstr(r2)
    //     0x7877e0: ldur            x0, [x2, #-1]
    //     0x7877e4: ubfx            x0, x0, #0xc, #0x14
    // 0x7877e8: SaveReg r2
    //     0x7877e8: str             x2, [SP, #-8]!
    // 0x7877ec: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x7877ec: sub             lr, x0, #0xf3a
    //     0x7877f0: ldr             lr, [x21, lr, lsl #3]
    //     0x7877f4: blr             lr
    // 0x7877f8: add             SP, SP, #8
    // 0x7877fc: mov             x2, x0
    // 0x787800: ldr             x1, [fp, #0x10]
    // 0x787804: stur            x2, [fp, #-0x10]
    // 0x787808: r0 = LoadClassIdInstr(r1)
    //     0x787808: ldur            x0, [x1, #-1]
    //     0x78780c: ubfx            x0, x0, #0xc, #0x14
    // 0x787810: SaveReg r1
    //     0x787810: str             x1, [SP, #-8]!
    // 0x787814: r0 = GDT[cid_x0 + -0x1000]()
    //     0x787814: sub             lr, x0, #1, lsl #12
    //     0x787818: ldr             lr, [x21, lr, lsl #3]
    //     0x78781c: blr             lr
    // 0x787820: add             SP, SP, #8
    // 0x787824: ldur            x1, [fp, #-8]
    // 0x787828: r2 = LoadClassIdInstr(r1)
    //     0x787828: ldur            x2, [x1, #-1]
    //     0x78782c: ubfx            x2, x2, #0xc, #0x14
    // 0x787830: ldur            x16, [fp, #-0x10]
    // 0x787834: stp             x16, x1, [SP, #-0x10]!
    // 0x787838: SaveReg r0
    //     0x787838: str             x0, [SP, #-8]!
    // 0x78783c: mov             x0, x2
    // 0x787840: r0 = GDT[cid_x0 + -0xf82]()
    //     0x787840: sub             lr, x0, #0xf82
    //     0x787844: ldr             lr, [x21, lr, lsl #3]
    //     0x787848: blr             lr
    // 0x78784c: add             SP, SP, #0x18
    // 0x787850: b               #0x7878d4
    // 0x787854: ldr             x2, [fp, #0x10]
    // 0x787858: ldur            x1, [fp, #-8]
    // 0x78785c: r0 = LoadClassIdInstr(r2)
    //     0x78785c: ldur            x0, [x2, #-1]
    //     0x787860: ubfx            x0, x0, #0xc, #0x14
    // 0x787864: SaveReg r2
    //     0x787864: str             x2, [SP, #-8]!
    // 0x787868: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x787868: sub             lr, x0, #0xf3a
    //     0x78786c: ldr             lr, [x21, lr, lsl #3]
    //     0x787870: blr             lr
    // 0x787874: add             SP, SP, #8
    // 0x787878: mov             x2, x0
    // 0x78787c: ldr             x1, [fp, #0x10]
    // 0x787880: stur            x2, [fp, #-0x10]
    // 0x787884: r0 = LoadClassIdInstr(r1)
    //     0x787884: ldur            x0, [x1, #-1]
    //     0x787888: ubfx            x0, x0, #0xc, #0x14
    // 0x78788c: SaveReg r1
    //     0x78788c: str             x1, [SP, #-8]!
    // 0x787890: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x787890: mov             x17, #0x57c0
    //     0x787894: add             lr, x0, x17
    //     0x787898: ldr             lr, [x21, lr, lsl #3]
    //     0x78789c: blr             lr
    // 0x7878a0: add             SP, SP, #8
    // 0x7878a4: mov             x1, x0
    // 0x7878a8: ldur            x0, [fp, #-8]
    // 0x7878ac: r2 = LoadClassIdInstr(r0)
    //     0x7878ac: ldur            x2, [x0, #-1]
    //     0x7878b0: ubfx            x2, x2, #0xc, #0x14
    // 0x7878b4: ldur            x16, [fp, #-0x10]
    // 0x7878b8: stp             x16, x0, [SP, #-0x10]!
    // 0x7878bc: SaveReg r1
    //     0x7878bc: str             x1, [SP, #-8]!
    // 0x7878c0: mov             x0, x2
    // 0x7878c4: r0 = GDT[cid_x0 + -0xf82]()
    //     0x7878c4: sub             lr, x0, #0xf82
    //     0x7878c8: ldr             lr, [x21, lr, lsl #3]
    //     0x7878cc: blr             lr
    // 0x7878d0: add             SP, SP, #0x18
    // 0x7878d4: ldr             x0, [fp, #0x10]
    // 0x7878d8: r2 = Null
    //     0x7878d8: mov             x2, NULL
    // 0x7878dc: r1 = Null
    //     0x7878dc: mov             x1, NULL
    // 0x7878e0: cmp             w0, NULL
    // 0x7878e4: b.eq            #0x787904
    // 0x7878e8: branchIfSmi(r0, 0x787904)
    //     0x7878e8: tbz             w0, #0, #0x787904
    // 0x7878ec: r3 = LoadClassIdInstr(r0)
    //     0x7878ec: ldur            x3, [x0, #-1]
    //     0x7878f0: ubfx            x3, x3, #0xc, #0x14
    // 0x7878f4: cmp             x3, #0x908
    // 0x7878f8: b.eq            #0x78790c
    // 0x7878fc: cmp             x3, #0xb3f
    // 0x787900: b.eq            #0x78790c
    // 0x787904: r0 = false
    //     0x787904: add             x0, NULL, #0x30  ; false
    // 0x787908: b               #0x787910
    // 0x78790c: r0 = true
    //     0x78790c: add             x0, NULL, #0x20  ; true
    // 0x787910: tbnz            w0, #4, #0x7879e8
    // 0x787914: ldr             x2, [fp, #0x18]
    // 0x787918: ldr             x1, [fp, #0x10]
    // 0x78791c: r0 = LoadClassIdInstr(r1)
    //     0x78791c: ldur            x0, [x1, #-1]
    //     0x787920: ubfx            x0, x0, #0xc, #0x14
    // 0x787924: SaveReg r1
    //     0x787924: str             x1, [SP, #-8]!
    // 0x787928: r0 = GDT[cid_x0 + 0x271c]()
    //     0x787928: mov             x17, #0x271c
    //     0x78792c: add             lr, x0, x17
    //     0x787930: ldr             lr, [x21, lr, lsl #3]
    //     0x787934: blr             lr
    // 0x787938: add             SP, SP, #8
    // 0x78793c: mov             x3, x0
    // 0x787940: ldr             x2, [fp, #0x18]
    // 0x787944: LoadField: r4 = r2->field_5b
    //     0x787944: ldur            w4, [x2, #0x5b]
    // 0x787948: DecompressPointer r4
    //     0x787948: add             x4, x4, HEAP, lsl #32
    // 0x78794c: r0 = BoxInt64Instr(r3)
    //     0x78794c: sbfiz           x0, x3, #1, #0x1f
    //     0x787950: cmp             x3, x0, asr #1
    //     0x787954: b.eq            #0x787960
    //     0x787958: bl              #0xd69bb8
    //     0x78795c: stur            x3, [x0, #7]
    // 0x787960: cmp             w0, w4
    // 0x787964: b.eq            #0x7879e0
    // 0x787968: and             w16, w0, w4
    // 0x78796c: branchIfSmi(r16, 0x7879a0)
    //     0x78796c: tbz             w16, #0, #0x7879a0
    // 0x787970: r16 = LoadClassIdInstr(r0)
    //     0x787970: ldur            x16, [x0, #-1]
    //     0x787974: ubfx            x16, x16, #0xc, #0x14
    // 0x787978: cmp             x16, #0x3c
    // 0x78797c: b.ne            #0x7879a0
    // 0x787980: r16 = LoadClassIdInstr(r4)
    //     0x787980: ldur            x16, [x4, #-1]
    //     0x787984: ubfx            x16, x16, #0xc, #0x14
    // 0x787988: cmp             x16, #0x3c
    // 0x78798c: b.ne            #0x7879a0
    // 0x787990: LoadField: r16 = r0->field_7
    //     0x787990: ldur            x16, [x0, #7]
    // 0x787994: LoadField: r17 = r4->field_7
    //     0x787994: ldur            x17, [x4, #7]
    // 0x787998: cmp             x16, x17
    // 0x78799c: b.eq            #0x7879e0
    // 0x7879a0: ldr             x3, [fp, #0x10]
    // 0x7879a4: r0 = LoadClassIdInstr(r3)
    //     0x7879a4: ldur            x0, [x3, #-1]
    //     0x7879a8: ubfx            x0, x0, #0xc, #0x14
    // 0x7879ac: SaveReg r3
    //     0x7879ac: str             x3, [SP, #-8]!
    // 0x7879b0: r0 = GDT[cid_x0 + -0xfff]()
    //     0x7879b0: sub             lr, x0, #0xfff
    //     0x7879b4: ldr             lr, [x21, lr, lsl #3]
    //     0x7879b8: blr             lr
    // 0x7879bc: add             SP, SP, #8
    // 0x7879c0: ldr             x16, [fp, #0x18]
    // 0x7879c4: stp             x0, x16, [SP, #-0x10]!
    // 0x7879c8: r0 = _giveUpPointer()
    //     0x7879c8: bl              #0x788b5c  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_giveUpPointer
    // 0x7879cc: add             SP, SP, #0x10
    // 0x7879d0: r0 = Null
    //     0x7879d0: mov             x0, NULL
    // 0x7879d4: LeaveFrame
    //     0x7879d4: mov             SP, fp
    //     0x7879d8: ldp             fp, lr, [SP], #0x10
    // 0x7879dc: ret
    //     0x7879dc: ret             
    // 0x7879e0: ldr             x3, [fp, #0x10]
    // 0x7879e4: b               #0x7879ec
    // 0x7879e8: ldr             x3, [fp, #0x10]
    // 0x7879ec: mov             x0, x3
    // 0x7879f0: r2 = Null
    //     0x7879f0: mov             x2, NULL
    // 0x7879f4: r1 = Null
    //     0x7879f4: mov             x1, NULL
    // 0x7879f8: cmp             w0, NULL
    // 0x7879fc: b.eq            #0x787a1c
    // 0x787a00: branchIfSmi(r0, 0x787a1c)
    //     0x787a00: tbz             w0, #0, #0x787a1c
    // 0x787a04: r3 = LoadClassIdInstr(r0)
    //     0x787a04: ldur            x3, [x0, #-1]
    //     0x787a08: ubfx            x3, x3, #0xc, #0x14
    // 0x787a0c: cmp             x3, #0x908
    // 0x787a10: b.eq            #0x787a24
    // 0x787a14: cmp             x3, #0xb3f
    // 0x787a18: b.eq            #0x787a24
    // 0x787a1c: r0 = false
    //     0x787a1c: add             x0, NULL, #0x30  ; false
    // 0x787a20: b               #0x787a28
    // 0x787a24: r0 = true
    //     0x787a24: add             x0, NULL, #0x20  ; true
    // 0x787a28: tbz             w0, #4, #0x787a6c
    // 0x787a2c: ldr             x0, [fp, #0x10]
    // 0x787a30: r2 = Null
    //     0x787a30: mov             x2, NULL
    // 0x787a34: r1 = Null
    //     0x787a34: mov             x1, NULL
    // 0x787a38: cmp             w0, NULL
    // 0x787a3c: b.eq            #0x787a5c
    // 0x787a40: branchIfSmi(r0, 0x787a5c)
    //     0x787a40: tbz             w0, #0, #0x787a5c
    // 0x787a44: r3 = LoadClassIdInstr(r0)
    //     0x787a44: ldur            x3, [x0, #-1]
    //     0x787a48: ubfx            x3, x3, #0xc, #0x14
    // 0x787a4c: cmp             x3, #0x8fc
    // 0x787a50: b.eq            #0x787a64
    // 0x787a54: cmp             x3, #0xb39
    // 0x787a58: b.eq            #0x787a64
    // 0x787a5c: r0 = false
    //     0x787a5c: add             x0, NULL, #0x30  ; false
    // 0x787a60: b               #0x787a68
    // 0x787a64: r0 = true
    //     0x787a64: add             x0, NULL, #0x20  ; true
    // 0x787a68: tbnz            w0, #4, #0x78839c
    // 0x787a6c: ldr             x0, [fp, #0x10]
    // 0x787a70: r2 = Null
    //     0x787a70: mov             x2, NULL
    // 0x787a74: r1 = Null
    //     0x787a74: mov             x1, NULL
    // 0x787a78: cmp             w0, NULL
    // 0x787a7c: b.eq            #0x787a9c
    // 0x787a80: branchIfSmi(r0, 0x787a9c)
    //     0x787a80: tbz             w0, #0, #0x787a9c
    // 0x787a84: r3 = LoadClassIdInstr(r0)
    //     0x787a84: ldur            x3, [x0, #-1]
    //     0x787a88: ubfx            x3, x3, #0xc, #0x14
    // 0x787a8c: cmp             x3, #0x908
    // 0x787a90: b.eq            #0x787aa4
    // 0x787a94: cmp             x3, #0xb3f
    // 0x787a98: b.eq            #0x787aa4
    // 0x787a9c: r0 = false
    //     0x787a9c: add             x0, NULL, #0x30  ; false
    // 0x787aa0: b               #0x787aa8
    // 0x787aa4: r0 = true
    //     0x787aa4: add             x0, NULL, #0x20  ; true
    // 0x787aa8: tbnz            w0, #4, #0x787ad8
    // 0x787aac: ldr             x1, [fp, #0x10]
    // 0x787ab0: r0 = LoadClassIdInstr(r1)
    //     0x787ab0: ldur            x0, [x1, #-1]
    //     0x787ab4: ubfx            x0, x0, #0xc, #0x14
    // 0x787ab8: SaveReg r1
    //     0x787ab8: str             x1, [SP, #-8]!
    // 0x787abc: r0 = GDT[cid_x0 + 0x9887]()
    //     0x787abc: mov             x17, #0x9887
    //     0x787ac0: add             lr, x0, x17
    //     0x787ac4: ldr             lr, [x21, lr, lsl #3]
    //     0x787ac8: blr             lr
    // 0x787acc: add             SP, SP, #8
    // 0x787ad0: mov             x3, x0
    // 0x787ad4: b               #0x787b38
    // 0x787ad8: ldr             x3, [fp, #0x10]
    // 0x787adc: mov             x0, x3
    // 0x787ae0: r2 = Null
    //     0x787ae0: mov             x2, NULL
    // 0x787ae4: r1 = Null
    //     0x787ae4: mov             x1, NULL
    // 0x787ae8: r4 = LoadClassIdInstr(r0)
    //     0x787ae8: ldur            x4, [x0, #-1]
    //     0x787aec: ubfx            x4, x4, #0xc, #0x14
    // 0x787af0: cmp             x4, #0x8fc
    // 0x787af4: b.eq            #0x787b14
    // 0x787af8: cmp             x4, #0xb39
    // 0x787afc: b.eq            #0x787b14
    // 0x787b00: r8 = PointerPanZoomUpdateEvent
    //     0x787b00: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e8c0] Type: PointerPanZoomUpdateEvent
    //     0x787b04: ldr             x8, [x8, #0x8c0]
    // 0x787b08: r3 = Null
    //     0x787b08: add             x3, PP, #0x53, lsl #12  ; [pp+0x53760] Null
    //     0x787b0c: ldr             x3, [x3, #0x760]
    // 0x787b10: r0 = DefaultTypeTest()
    //     0x787b10: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x787b14: ldr             x1, [fp, #0x10]
    // 0x787b18: r0 = LoadClassIdInstr(r1)
    //     0x787b18: ldur            x0, [x1, #-1]
    //     0x787b1c: ubfx            x0, x0, #0xc, #0x14
    // 0x787b20: SaveReg r1
    //     0x787b20: str             x1, [SP, #-8]!
    // 0x787b24: r0 = GDT[cid_x0 + -0xffe]()
    //     0x787b24: sub             lr, x0, #0xffe
    //     0x787b28: ldr             lr, [x21, lr, lsl #3]
    //     0x787b2c: blr             lr
    // 0x787b30: add             SP, SP, #8
    // 0x787b34: mov             x3, x0
    // 0x787b38: ldr             x0, [fp, #0x10]
    // 0x787b3c: stur            x3, [fp, #-8]
    // 0x787b40: r2 = Null
    //     0x787b40: mov             x2, NULL
    // 0x787b44: r1 = Null
    //     0x787b44: mov             x1, NULL
    // 0x787b48: cmp             w0, NULL
    // 0x787b4c: b.eq            #0x787b6c
    // 0x787b50: branchIfSmi(r0, 0x787b6c)
    //     0x787b50: tbz             w0, #0, #0x787b6c
    // 0x787b54: r3 = LoadClassIdInstr(r0)
    //     0x787b54: ldur            x3, [x0, #-1]
    //     0x787b58: ubfx            x3, x3, #0xc, #0x14
    // 0x787b5c: cmp             x3, #0x908
    // 0x787b60: b.eq            #0x787b74
    // 0x787b64: cmp             x3, #0xb3f
    // 0x787b68: b.eq            #0x787b74
    // 0x787b6c: r0 = false
    //     0x787b6c: add             x0, NULL, #0x30  ; false
    // 0x787b70: b               #0x787b78
    // 0x787b74: r0 = true
    //     0x787b74: add             x0, NULL, #0x20  ; true
    // 0x787b78: tbnz            w0, #4, #0x787bac
    // 0x787b7c: ldr             x1, [fp, #0x10]
    // 0x787b80: r0 = LoadClassIdInstr(r1)
    //     0x787b80: ldur            x0, [x1, #-1]
    //     0x787b84: ubfx            x0, x0, #0xc, #0x14
    // 0x787b88: SaveReg r1
    //     0x787b88: str             x1, [SP, #-8]!
    // 0x787b8c: r0 = GDT[cid_x0 + 0x104eb]()
    //     0x787b8c: mov             x17, #0x4eb
    //     0x787b90: movk            x17, #1, lsl #16
    //     0x787b94: add             lr, x0, x17
    //     0x787b98: ldr             lr, [x21, lr, lsl #3]
    //     0x787b9c: blr             lr
    // 0x787ba0: add             SP, SP, #8
    // 0x787ba4: mov             x3, x0
    // 0x787ba8: b               #0x787c0c
    // 0x787bac: ldr             x3, [fp, #0x10]
    // 0x787bb0: mov             x0, x3
    // 0x787bb4: r2 = Null
    //     0x787bb4: mov             x2, NULL
    // 0x787bb8: r1 = Null
    //     0x787bb8: mov             x1, NULL
    // 0x787bbc: r4 = LoadClassIdInstr(r0)
    //     0x787bbc: ldur            x4, [x0, #-1]
    //     0x787bc0: ubfx            x4, x4, #0xc, #0x14
    // 0x787bc4: cmp             x4, #0x8fc
    // 0x787bc8: b.eq            #0x787be8
    // 0x787bcc: cmp             x4, #0xb39
    // 0x787bd0: b.eq            #0x787be8
    // 0x787bd4: r8 = PointerPanZoomUpdateEvent
    //     0x787bd4: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e8c0] Type: PointerPanZoomUpdateEvent
    //     0x787bd8: ldr             x8, [x8, #0x8c0]
    // 0x787bdc: r3 = Null
    //     0x787bdc: add             x3, PP, #0x53, lsl #12  ; [pp+0x53770] Null
    //     0x787be0: ldr             x3, [x3, #0x770]
    // 0x787be4: r0 = DefaultTypeTest()
    //     0x787be4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x787be8: ldr             x1, [fp, #0x10]
    // 0x787bec: r0 = LoadClassIdInstr(r1)
    //     0x787bec: ldur            x0, [x1, #-1]
    //     0x787bf0: ubfx            x0, x0, #0xc, #0x14
    // 0x787bf4: SaveReg r1
    //     0x787bf4: str             x1, [SP, #-8]!
    // 0x787bf8: r0 = GDT[cid_x0 + -0xffa]()
    //     0x787bf8: sub             lr, x0, #0xffa
    //     0x787bfc: ldr             lr, [x21, lr, lsl #3]
    //     0x787c00: blr             lr
    // 0x787c04: add             SP, SP, #8
    // 0x787c08: mov             x3, x0
    // 0x787c0c: ldr             x0, [fp, #0x10]
    // 0x787c10: stur            x3, [fp, #-0x10]
    // 0x787c14: r2 = Null
    //     0x787c14: mov             x2, NULL
    // 0x787c18: r1 = Null
    //     0x787c18: mov             x1, NULL
    // 0x787c1c: cmp             w0, NULL
    // 0x787c20: b.eq            #0x787c40
    // 0x787c24: branchIfSmi(r0, 0x787c40)
    //     0x787c24: tbz             w0, #0, #0x787c40
    // 0x787c28: r3 = LoadClassIdInstr(r0)
    //     0x787c28: ldur            x3, [x0, #-1]
    //     0x787c2c: ubfx            x3, x3, #0xc, #0x14
    // 0x787c30: cmp             x3, #0x908
    // 0x787c34: b.eq            #0x787c48
    // 0x787c38: cmp             x3, #0xb3f
    // 0x787c3c: b.eq            #0x787c48
    // 0x787c40: r0 = false
    //     0x787c40: add             x0, NULL, #0x30  ; false
    // 0x787c44: b               #0x787c4c
    // 0x787c48: r0 = true
    //     0x787c48: add             x0, NULL, #0x20  ; true
    // 0x787c4c: tbnz            w0, #4, #0x787c78
    // 0x787c50: ldr             x1, [fp, #0x10]
    // 0x787c54: r0 = LoadClassIdInstr(r1)
    //     0x787c54: ldur            x0, [x1, #-1]
    //     0x787c58: ubfx            x0, x0, #0xc, #0x14
    // 0x787c5c: SaveReg r1
    //     0x787c5c: str             x1, [SP, #-8]!
    // 0x787c60: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x787c60: sub             lr, x0, #0xfd9
    //     0x787c64: ldr             lr, [x21, lr, lsl #3]
    //     0x787c68: blr             lr
    // 0x787c6c: add             SP, SP, #8
    // 0x787c70: mov             x3, x0
    // 0x787c74: b               #0x787d0c
    // 0x787c78: ldr             x1, [fp, #0x10]
    // 0x787c7c: r0 = LoadClassIdInstr(r1)
    //     0x787c7c: ldur            x0, [x1, #-1]
    //     0x787c80: ubfx            x0, x0, #0xc, #0x14
    // 0x787c84: SaveReg r1
    //     0x787c84: str             x1, [SP, #-8]!
    // 0x787c88: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x787c88: sub             lr, x0, #0xfd9
    //     0x787c8c: ldr             lr, [x21, lr, lsl #3]
    //     0x787c90: blr             lr
    // 0x787c94: add             SP, SP, #8
    // 0x787c98: mov             x3, x0
    // 0x787c9c: ldr             x0, [fp, #0x10]
    // 0x787ca0: r2 = Null
    //     0x787ca0: mov             x2, NULL
    // 0x787ca4: r1 = Null
    //     0x787ca4: mov             x1, NULL
    // 0x787ca8: stur            x3, [fp, #-0x18]
    // 0x787cac: r4 = LoadClassIdInstr(r0)
    //     0x787cac: ldur            x4, [x0, #-1]
    //     0x787cb0: ubfx            x4, x4, #0xc, #0x14
    // 0x787cb4: cmp             x4, #0x8fc
    // 0x787cb8: b.eq            #0x787cd8
    // 0x787cbc: cmp             x4, #0xb39
    // 0x787cc0: b.eq            #0x787cd8
    // 0x787cc4: r8 = PointerPanZoomUpdateEvent
    //     0x787cc4: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e8c0] Type: PointerPanZoomUpdateEvent
    //     0x787cc8: ldr             x8, [x8, #0x8c0]
    // 0x787ccc: r3 = Null
    //     0x787ccc: add             x3, PP, #0x53, lsl #12  ; [pp+0x53780] Null
    //     0x787cd0: ldr             x3, [x3, #0x780]
    // 0x787cd4: r0 = DefaultTypeTest()
    //     0x787cd4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x787cd8: ldr             x1, [fp, #0x10]
    // 0x787cdc: r0 = LoadClassIdInstr(r1)
    //     0x787cdc: ldur            x0, [x1, #-1]
    //     0x787ce0: ubfx            x0, x0, #0xc, #0x14
    // 0x787ce4: SaveReg r1
    //     0x787ce4: str             x1, [SP, #-8]!
    // 0x787ce8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x787ce8: sub             lr, x0, #1, lsl #12
    //     0x787cec: ldr             lr, [x21, lr, lsl #3]
    //     0x787cf0: blr             lr
    // 0x787cf4: add             SP, SP, #8
    // 0x787cf8: ldur            x16, [fp, #-0x18]
    // 0x787cfc: stp             x0, x16, [SP, #-0x10]!
    // 0x787d00: r0 = +()
    //     0x787d00: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x787d04: add             SP, SP, #0x10
    // 0x787d08: mov             x3, x0
    // 0x787d0c: ldr             x0, [fp, #0x10]
    // 0x787d10: stur            x3, [fp, #-0x18]
    // 0x787d14: r2 = Null
    //     0x787d14: mov             x2, NULL
    // 0x787d18: r1 = Null
    //     0x787d18: mov             x1, NULL
    // 0x787d1c: cmp             w0, NULL
    // 0x787d20: b.eq            #0x787d40
    // 0x787d24: branchIfSmi(r0, 0x787d40)
    //     0x787d24: tbz             w0, #0, #0x787d40
    // 0x787d28: r3 = LoadClassIdInstr(r0)
    //     0x787d28: ldur            x3, [x0, #-1]
    //     0x787d2c: ubfx            x3, x3, #0xc, #0x14
    // 0x787d30: cmp             x3, #0x908
    // 0x787d34: b.eq            #0x787d48
    // 0x787d38: cmp             x3, #0xb3f
    // 0x787d3c: b.eq            #0x787d48
    // 0x787d40: r0 = false
    //     0x787d40: add             x0, NULL, #0x30  ; false
    // 0x787d44: b               #0x787d4c
    // 0x787d48: r0 = true
    //     0x787d48: add             x0, NULL, #0x20  ; true
    // 0x787d4c: tbnz            w0, #4, #0x787d7c
    // 0x787d50: ldr             x1, [fp, #0x10]
    // 0x787d54: r0 = LoadClassIdInstr(r1)
    //     0x787d54: ldur            x0, [x1, #-1]
    //     0x787d58: ubfx            x0, x0, #0xc, #0x14
    // 0x787d5c: SaveReg r1
    //     0x787d5c: str             x1, [SP, #-8]!
    // 0x787d60: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x787d60: mov             x17, #0x57c0
    //     0x787d64: add             lr, x0, x17
    //     0x787d68: ldr             lr, [x21, lr, lsl #3]
    //     0x787d6c: blr             lr
    // 0x787d70: add             SP, SP, #8
    // 0x787d74: mov             x2, x0
    // 0x787d78: b               #0x787e14
    // 0x787d7c: ldr             x1, [fp, #0x10]
    // 0x787d80: r0 = LoadClassIdInstr(r1)
    //     0x787d80: ldur            x0, [x1, #-1]
    //     0x787d84: ubfx            x0, x0, #0xc, #0x14
    // 0x787d88: SaveReg r1
    //     0x787d88: str             x1, [SP, #-8]!
    // 0x787d8c: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x787d8c: mov             x17, #0x57c0
    //     0x787d90: add             lr, x0, x17
    //     0x787d94: ldr             lr, [x21, lr, lsl #3]
    //     0x787d98: blr             lr
    // 0x787d9c: add             SP, SP, #8
    // 0x787da0: mov             x3, x0
    // 0x787da4: ldr             x0, [fp, #0x10]
    // 0x787da8: r2 = Null
    //     0x787da8: mov             x2, NULL
    // 0x787dac: r1 = Null
    //     0x787dac: mov             x1, NULL
    // 0x787db0: stur            x3, [fp, #-0x20]
    // 0x787db4: r4 = LoadClassIdInstr(r0)
    //     0x787db4: ldur            x4, [x0, #-1]
    //     0x787db8: ubfx            x4, x4, #0xc, #0x14
    // 0x787dbc: cmp             x4, #0x8fc
    // 0x787dc0: b.eq            #0x787de0
    // 0x787dc4: cmp             x4, #0xb39
    // 0x787dc8: b.eq            #0x787de0
    // 0x787dcc: r8 = PointerPanZoomUpdateEvent
    //     0x787dcc: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e8c0] Type: PointerPanZoomUpdateEvent
    //     0x787dd0: ldr             x8, [x8, #0x8c0]
    // 0x787dd4: r3 = Null
    //     0x787dd4: add             x3, PP, #0x53, lsl #12  ; [pp+0x53790] Null
    //     0x787dd8: ldr             x3, [x3, #0x790]
    // 0x787ddc: r0 = DefaultTypeTest()
    //     0x787ddc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x787de0: ldr             x1, [fp, #0x10]
    // 0x787de4: r0 = LoadClassIdInstr(r1)
    //     0x787de4: ldur            x0, [x1, #-1]
    //     0x787de8: ubfx            x0, x0, #0xc, #0x14
    // 0x787dec: SaveReg r1
    //     0x787dec: str             x1, [SP, #-8]!
    // 0x787df0: r0 = GDT[cid_x0 + -0xffc]()
    //     0x787df0: sub             lr, x0, #0xffc
    //     0x787df4: ldr             lr, [x21, lr, lsl #3]
    //     0x787df8: blr             lr
    // 0x787dfc: add             SP, SP, #8
    // 0x787e00: ldur            x16, [fp, #-0x20]
    // 0x787e04: stp             x0, x16, [SP, #-0x10]!
    // 0x787e08: r0 = +()
    //     0x787e08: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x787e0c: add             SP, SP, #0x10
    // 0x787e10: mov             x2, x0
    // 0x787e14: ldr             x1, [fp, #0x18]
    // 0x787e18: stur            x2, [fp, #-0x20]
    // 0x787e1c: LoadField: r0 = r1->field_4b
    //     0x787e1c: ldur            w0, [x1, #0x4b]
    // 0x787e20: DecompressPointer r0
    //     0x787e20: add             x0, x0, HEAP, lsl #32
    // 0x787e24: r16 = Instance__DragState
    //     0x787e24: add             x16, PP, #0x53, lsl #12  ; [pp+0x537a0] Obj!_DragState@b66111
    //     0x787e28: ldr             x16, [x16, #0x7a0]
    // 0x787e2c: cmp             w0, w16
    // 0x787e30: b.ne            #0x787f1c
    // 0x787e34: ldr             x3, [fp, #0x10]
    // 0x787e38: r0 = LoadClassIdInstr(r3)
    //     0x787e38: ldur            x0, [x3, #-1]
    //     0x787e3c: ubfx            x0, x0, #0xc, #0x14
    // 0x787e40: SaveReg r3
    //     0x787e40: str             x3, [SP, #-8]!
    // 0x787e44: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x787e44: sub             lr, x0, #0xf3a
    //     0x787e48: ldr             lr, [x21, lr, lsl #3]
    //     0x787e4c: blr             lr
    // 0x787e50: add             SP, SP, #8
    // 0x787e54: mov             x1, x0
    // 0x787e58: ldr             x0, [fp, #0x18]
    // 0x787e5c: stur            x1, [fp, #-0x30]
    // 0x787e60: r2 = LoadClassIdInstr(r0)
    //     0x787e60: ldur            x2, [x0, #-1]
    //     0x787e64: ubfx            x2, x2, #0xc, #0x14
    // 0x787e68: lsl             x2, x2, #1
    // 0x787e6c: stur            x2, [fp, #-0x28]
    // 0x787e70: r17 = 4732
    //     0x787e70: mov             x17, #0x127c
    // 0x787e74: cmp             w2, w17
    // 0x787e78: b.ne            #0x787ea4
    // 0x787e7c: ldur            x3, [fp, #-0x10]
    // 0x787e80: LoadField: d0 = r3->field_7
    //     0x787e80: ldur            d0, [x3, #7]
    // 0x787e84: stur            d0, [fp, #-0x38]
    // 0x787e88: r0 = Offset()
    //     0x787e88: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x787e8c: ldur            d0, [fp, #-0x38]
    // 0x787e90: StoreField: r0->field_7 = d0
    //     0x787e90: stur            d0, [x0, #7]
    // 0x787e94: d0 = 0.000000
    //     0x787e94: eor             v0.16b, v0.16b, v0.16b
    // 0x787e98: StoreField: r0->field_f = d0
    //     0x787e98: stur            d0, [x0, #0xf]
    // 0x787e9c: mov             x1, x0
    // 0x787ea0: b               #0x787ecc
    // 0x787ea4: ldur            x0, [fp, #-0x10]
    // 0x787ea8: d0 = 0.000000
    //     0x787ea8: eor             v0.16b, v0.16b, v0.16b
    // 0x787eac: LoadField: d1 = r0->field_f
    //     0x787eac: ldur            d1, [x0, #0xf]
    // 0x787eb0: stur            d1, [fp, #-0x38]
    // 0x787eb4: r0 = Offset()
    //     0x787eb4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x787eb8: d0 = 0.000000
    //     0x787eb8: eor             v0.16b, v0.16b, v0.16b
    // 0x787ebc: StoreField: r0->field_7 = d0
    //     0x787ebc: stur            d0, [x0, #7]
    // 0x787ec0: ldur            d0, [fp, #-0x38]
    // 0x787ec4: StoreField: r0->field_f = d0
    //     0x787ec4: stur            d0, [x0, #0xf]
    // 0x787ec8: mov             x1, x0
    // 0x787ecc: ldur            x0, [fp, #-0x28]
    // 0x787ed0: r17 = 4732
    //     0x787ed0: mov             x17, #0x127c
    // 0x787ed4: cmp             w0, w17
    // 0x787ed8: b.ne            #0x787ee8
    // 0x787edc: ldur            x0, [fp, #-0x10]
    // 0x787ee0: LoadField: d0 = r0->field_7
    //     0x787ee0: ldur            d0, [x0, #7]
    // 0x787ee4: b               #0x787ef0
    // 0x787ee8: ldur            x0, [fp, #-0x10]
    // 0x787eec: LoadField: d0 = r0->field_f
    //     0x787eec: ldur            d0, [x0, #0xf]
    // 0x787ef0: ldr             x16, [fp, #0x18]
    // 0x787ef4: stp             x1, x16, [SP, #-0x10]!
    // 0x787ef8: ldur            x16, [fp, #-0x18]
    // 0x787efc: ldur            lr, [fp, #-0x20]
    // 0x787f00: stp             lr, x16, [SP, #-0x10]!
    // 0x787f04: SaveReg d0
    //     0x787f04: str             d0, [SP, #-8]!
    // 0x787f08: ldur            x16, [fp, #-0x30]
    // 0x787f0c: SaveReg r16
    //     0x787f0c: str             x16, [SP, #-8]!
    // 0x787f10: r0 = _checkUpdate()
    //     0x787f10: bl              #0x788a50  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_checkUpdate
    // 0x787f14: add             SP, SP, #0x30
    // 0x787f18: b               #0x78839c
    // 0x787f1c: ldr             x2, [fp, #0x10]
    // 0x787f20: ldur            x3, [fp, #-8]
    // 0x787f24: ldur            x0, [fp, #-0x10]
    // 0x787f28: d0 = 0.000000
    //     0x787f28: eor             v0.16b, v0.16b, v0.16b
    // 0x787f2c: LoadField: r4 = r1->field_53
    //     0x787f2c: ldur            w4, [x1, #0x53]
    // 0x787f30: DecompressPointer r4
    //     0x787f30: add             x4, x4, HEAP, lsl #32
    // 0x787f34: r16 = Sentinel
    //     0x787f34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x787f38: cmp             w4, w16
    // 0x787f3c: b.eq            #0x7884ac
    // 0x787f40: stur            x4, [fp, #-0x18]
    // 0x787f44: r0 = OffsetPair()
    //     0x787f44: bl              #0x7142f0  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0x787f48: mov             x1, x0
    // 0x787f4c: ldur            x0, [fp, #-0x10]
    // 0x787f50: StoreField: r1->field_7 = r0
    //     0x787f50: stur            w0, [x1, #7]
    // 0x787f54: ldur            x2, [fp, #-8]
    // 0x787f58: StoreField: r1->field_b = r2
    //     0x787f58: stur            w2, [x1, #0xb]
    // 0x787f5c: ldur            x16, [fp, #-0x18]
    // 0x787f60: stp             x1, x16, [SP, #-0x10]!
    // 0x787f64: r0 = +()
    //     0x787f64: bl              #0x714388  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0x787f68: add             SP, SP, #0x10
    // 0x787f6c: ldr             x1, [fp, #0x18]
    // 0x787f70: StoreField: r1->field_53 = r0
    //     0x787f70: stur            w0, [x1, #0x53]
    //     0x787f74: ldurb           w16, [x1, #-1]
    //     0x787f78: ldurb           w17, [x0, #-1]
    //     0x787f7c: and             x16, x17, x16, lsr #2
    //     0x787f80: tst             x16, HEAP, lsr #32
    //     0x787f84: b.eq            #0x787f8c
    //     0x787f88: bl              #0xd6826c
    // 0x787f8c: ldr             x2, [fp, #0x10]
    // 0x787f90: r0 = LoadClassIdInstr(r2)
    //     0x787f90: ldur            x0, [x2, #-1]
    //     0x787f94: ubfx            x0, x0, #0xc, #0x14
    // 0x787f98: SaveReg r2
    //     0x787f98: str             x2, [SP, #-8]!
    // 0x787f9c: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x787f9c: sub             lr, x0, #0xf3a
    //     0x787fa0: ldr             lr, [x21, lr, lsl #3]
    //     0x787fa4: blr             lr
    // 0x787fa8: add             SP, SP, #8
    // 0x787fac: ldr             x1, [fp, #0x18]
    // 0x787fb0: StoreField: r1->field_57 = r0
    //     0x787fb0: stur            w0, [x1, #0x57]
    //     0x787fb4: ldurb           w16, [x1, #-1]
    //     0x787fb8: ldurb           w17, [x0, #-1]
    //     0x787fbc: and             x16, x17, x16, lsr #2
    //     0x787fc0: tst             x16, HEAP, lsr #32
    //     0x787fc4: b.eq            #0x787fcc
    //     0x787fc8: bl              #0xd6826c
    // 0x787fcc: ldr             x2, [fp, #0x10]
    // 0x787fd0: r0 = LoadClassIdInstr(r2)
    //     0x787fd0: ldur            x0, [x2, #-1]
    //     0x787fd4: ubfx            x0, x0, #0xc, #0x14
    // 0x787fd8: SaveReg r2
    //     0x787fd8: str             x2, [SP, #-8]!
    // 0x787fdc: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x787fdc: mov             x17, #0x3f6e
    //     0x787fe0: add             lr, x0, x17
    //     0x787fe4: ldr             lr, [x21, lr, lsl #3]
    //     0x787fe8: blr             lr
    // 0x787fec: add             SP, SP, #8
    // 0x787ff0: ldr             x1, [fp, #0x18]
    // 0x787ff4: StoreField: r1->field_5f = r0
    //     0x787ff4: stur            w0, [x1, #0x5f]
    //     0x787ff8: ldurb           w16, [x1, #-1]
    //     0x787ffc: ldurb           w17, [x0, #-1]
    //     0x788000: and             x16, x17, x16, lsr #2
    //     0x788004: tst             x16, HEAP, lsr #32
    //     0x788008: b.eq            #0x788010
    //     0x78800c: bl              #0xd6826c
    // 0x788010: r0 = LoadClassIdInstr(r1)
    //     0x788010: ldur            x0, [x1, #-1]
    //     0x788014: ubfx            x0, x0, #0xc, #0x14
    // 0x788018: lsl             x0, x0, #1
    // 0x78801c: stur            x0, [fp, #-8]
    // 0x788020: r17 = 4732
    //     0x788020: mov             x17, #0x127c
    // 0x788024: cmp             w0, w17
    // 0x788028: b.ne            #0x788060
    // 0x78802c: ldur            x2, [fp, #-0x10]
    // 0x788030: LoadField: d0 = r2->field_7
    //     0x788030: ldur            d0, [x2, #7]
    // 0x788034: stur            d0, [fp, #-0x38]
    // 0x788038: r0 = Offset()
    //     0x788038: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x78803c: ldur            d0, [fp, #-0x38]
    // 0x788040: StoreField: r0->field_7 = d0
    //     0x788040: stur            d0, [x0, #7]
    // 0x788044: d1 = 0.000000
    //     0x788044: eor             v1.16b, v1.16b, v1.16b
    // 0x788048: StoreField: r0->field_f = d1
    //     0x788048: stur            d1, [x0, #0xf]
    // 0x78804c: mov             x2, x0
    // 0x788050: mov             v2.16b, v0.16b
    // 0x788054: mov             v0.16b, v1.16b
    // 0x788058: d1 = 0.000000
    //     0x788058: eor             v1.16b, v1.16b, v1.16b
    // 0x78805c: b               #0x78808c
    // 0x788060: ldur            x2, [fp, #-0x10]
    // 0x788064: d1 = 0.000000
    //     0x788064: eor             v1.16b, v1.16b, v1.16b
    // 0x788068: LoadField: d0 = r2->field_f
    //     0x788068: ldur            d0, [x2, #0xf]
    // 0x78806c: stur            d0, [fp, #-0x38]
    // 0x788070: r0 = Offset()
    //     0x788070: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x788074: d0 = 0.000000
    //     0x788074: eor             v0.16b, v0.16b, v0.16b
    // 0x788078: StoreField: r0->field_7 = d0
    //     0x788078: stur            d0, [x0, #7]
    // 0x78807c: ldur            d1, [fp, #-0x38]
    // 0x788080: StoreField: r0->field_f = d1
    //     0x788080: stur            d1, [x0, #0xf]
    // 0x788084: mov             x2, x0
    // 0x788088: d2 = 0.000000
    //     0x788088: eor             v2.16b, v2.16b, v2.16b
    // 0x78808c: ldr             x1, [fp, #0x10]
    // 0x788090: stur            x2, [fp, #-0x10]
    // 0x788094: stur            d2, [fp, #-0x38]
    // 0x788098: stur            d1, [fp, #-0x40]
    // 0x78809c: r0 = LoadClassIdInstr(r1)
    //     0x78809c: ldur            x0, [x1, #-1]
    //     0x7880a0: ubfx            x0, x0, #0xc, #0x14
    // 0x7880a4: SaveReg r1
    //     0x7880a4: str             x1, [SP, #-8]!
    // 0x7880a8: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x7880a8: mov             x17, #0x3f6e
    //     0x7880ac: add             lr, x0, x17
    //     0x7880b0: ldr             lr, [x21, lr, lsl #3]
    //     0x7880b4: blr             lr
    // 0x7880b8: add             SP, SP, #8
    // 0x7880bc: cmp             w0, NULL
    // 0x7880c0: b.ne            #0x7880cc
    // 0x7880c4: r2 = Null
    //     0x7880c4: mov             x2, NULL
    // 0x7880c8: b               #0x788108
    // 0x7880cc: ldr             x1, [fp, #0x10]
    // 0x7880d0: r0 = LoadClassIdInstr(r1)
    //     0x7880d0: ldur            x0, [x1, #-1]
    //     0x7880d4: ubfx            x0, x0, #0xc, #0x14
    // 0x7880d8: SaveReg r1
    //     0x7880d8: str             x1, [SP, #-8]!
    // 0x7880dc: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x7880dc: mov             x17, #0x3f6e
    //     0x7880e0: add             lr, x0, x17
    //     0x7880e4: ldr             lr, [x21, lr, lsl #3]
    //     0x7880e8: blr             lr
    // 0x7880ec: add             SP, SP, #8
    // 0x7880f0: cmp             w0, NULL
    // 0x7880f4: b.eq            #0x7884b8
    // 0x7880f8: SaveReg r0
    //     0x7880f8: str             x0, [SP, #-8]!
    // 0x7880fc: r0 = tryInvert()
    //     0x7880fc: bl              #0x623294  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0x788100: add             SP, SP, #8
    // 0x788104: mov             x2, x0
    // 0x788108: ldr             x0, [fp, #0x18]
    // 0x78810c: ldur            x1, [fp, #-8]
    // 0x788110: LoadField: r3 = r0->field_63
    //     0x788110: ldur            w3, [x0, #0x63]
    // 0x788114: DecompressPointer r3
    //     0x788114: add             x3, x3, HEAP, lsl #32
    // 0x788118: r16 = Sentinel
    //     0x788118: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78811c: cmp             w3, w16
    // 0x788120: b.eq            #0x7884bc
    // 0x788124: stur            x3, [fp, #-0x18]
    // 0x788128: ldur            x16, [fp, #-0x10]
    // 0x78812c: stp             x16, x2, [SP, #-0x10]!
    // 0x788130: ldur            x16, [fp, #-0x20]
    // 0x788134: SaveReg r16
    //     0x788134: str             x16, [SP, #-8]!
    // 0x788138: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x788138: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x78813c: r0 = transformDeltaViaPositions()
    //     0x78813c: bl              #0x5b64a0  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0x788140: add             SP, SP, #0x18
    // 0x788144: LoadField: d0 = r0->field_7
    //     0x788144: ldur            d0, [x0, #7]
    // 0x788148: fmul            d1, d0, d0
    // 0x78814c: LoadField: d0 = r0->field_f
    //     0x78814c: ldur            d0, [x0, #0xf]
    // 0x788150: fmul            d2, d0, d0
    // 0x788154: fadd            d0, d1, d2
    // 0x788158: fsqrt           d1, d0
    // 0x78815c: ldur            x1, [fp, #-8]
    // 0x788160: r17 = 4732
    //     0x788160: mov             x17, #0x127c
    // 0x788164: cmp             w1, w17
    // 0x788168: b.ne            #0x788174
    // 0x78816c: ldur            d2, [fp, #-0x38]
    // 0x788170: b               #0x788178
    // 0x788174: ldur            d2, [fp, #-0x40]
    // 0x788178: d0 = 0.000000
    //     0x788178: eor             v0.16b, v0.16b, v0.16b
    // 0x78817c: fcmp            d2, d0
    // 0x788180: b.vs            #0x788190
    // 0x788184: b.le            #0x788190
    // 0x788188: d2 = 1.000000
    //     0x788188: fmov            d2, #1.00000000
    // 0x78818c: b               #0x7881a8
    // 0x788190: fcmp            d2, d0
    // 0x788194: b.vs            #0x7881a8
    // 0x788198: b.ge            #0x7881a8
    // 0x78819c: d2 = 1.000000
    //     0x78819c: fmov            d2, #1.00000000
    // 0x7881a0: fneg            d3, d2
    // 0x7881a4: mov             v2.16b, v3.16b
    // 0x7881a8: ldr             x2, [fp, #0x18]
    // 0x7881ac: ldr             x3, [fp, #0x10]
    // 0x7881b0: ldur            x0, [fp, #-0x18]
    // 0x7881b4: fmul            d3, d1, d2
    // 0x7881b8: LoadField: d1 = r0->field_7
    //     0x7881b8: ldur            d1, [x0, #7]
    // 0x7881bc: fadd            d2, d1, d3
    // 0x7881c0: r0 = inline_Allocate_Double()
    //     0x7881c0: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x7881c4: add             x0, x0, #0x10
    //     0x7881c8: cmp             x4, x0
    //     0x7881cc: b.ls            #0x7884c8
    //     0x7881d0: str             x0, [THR, #0x60]  ; THR::top
    //     0x7881d4: sub             x0, x0, #0xf
    //     0x7881d8: mov             x4, #0xd108
    //     0x7881dc: movk            x4, #3, lsl #16
    //     0x7881e0: stur            x4, [x0, #-1]
    // 0x7881e4: StoreField: r0->field_7 = d2
    //     0x7881e4: stur            d2, [x0, #7]
    // 0x7881e8: StoreField: r2->field_63 = r0
    //     0x7881e8: stur            w0, [x2, #0x63]
    //     0x7881ec: ldurb           w16, [x2, #-1]
    //     0x7881f0: ldurb           w17, [x0, #-1]
    //     0x7881f4: and             x16, x17, x16, lsr #2
    //     0x7881f8: tst             x16, HEAP, lsr #32
    //     0x7881fc: b.eq            #0x788204
    //     0x788200: bl              #0xd6828c
    // 0x788204: r0 = LoadClassIdInstr(r3)
    //     0x788204: ldur            x0, [x3, #-1]
    //     0x788208: ubfx            x0, x0, #0xc, #0x14
    // 0x78820c: SaveReg r3
    //     0x78820c: str             x3, [SP, #-8]!
    // 0x788210: r0 = GDT[cid_x0 + -0xf60]()
    //     0x788210: sub             lr, x0, #0xf60
    //     0x788214: ldr             lr, [x21, lr, lsl #3]
    //     0x788218: blr             lr
    // 0x78821c: add             SP, SP, #8
    // 0x788220: mov             x1, x0
    // 0x788224: ldr             x0, [fp, #0x18]
    // 0x788228: LoadField: r2 = r0->field_7
    //     0x788228: ldur            w2, [x0, #7]
    // 0x78822c: DecompressPointer r2
    //     0x78822c: add             x2, x2, HEAP, lsl #32
    // 0x788230: ldur            x3, [fp, #-8]
    // 0x788234: r17 = 4732
    //     0x788234: mov             x17, #0x127c
    // 0x788238: cmp             w3, w17
    // 0x78823c: b.ne            #0x7882dc
    // 0x788240: d0 = 0.000000
    //     0x788240: eor             v0.16b, v0.16b, v0.16b
    // 0x788244: LoadField: r3 = r0->field_63
    //     0x788244: ldur            w3, [x0, #0x63]
    // 0x788248: DecompressPointer r3
    //     0x788248: add             x3, x3, HEAP, lsl #32
    // 0x78824c: LoadField: d1 = r3->field_7
    //     0x78824c: ldur            d1, [x3, #7]
    // 0x788250: fcmp            d1, d0
    // 0x788254: b.vs            #0x788264
    // 0x788258: b.ne            #0x788264
    // 0x78825c: d0 = 0.000000
    //     0x78825c: eor             v0.16b, v0.16b, v0.16b
    // 0x788260: b               #0x78827c
    // 0x788264: fcmp            d1, d0
    // 0x788268: b.vs            #0x788278
    // 0x78826c: b.ge            #0x788278
    // 0x788270: fneg            d0, d1
    // 0x788274: b               #0x78827c
    // 0x788278: mov             v0.16b, v1.16b
    // 0x78827c: LoadField: r3 = r1->field_7
    //     0x78827c: ldur            x3, [x1, #7]
    // 0x788280: cmp             x3, #2
    // 0x788284: b.gt            #0x7882a0
    // 0x788288: cmp             x3, #1
    // 0x78828c: b.gt            #0x7882a0
    // 0x788290: cmp             x3, #0
    // 0x788294: b.le            #0x7882a0
    // 0x788298: d1 = 1.000000
    //     0x788298: fmov            d1, #1.00000000
    // 0x78829c: b               #0x7882cc
    // 0x7882a0: cmp             w2, NULL
    // 0x7882a4: b.ne            #0x7882b0
    // 0x7882a8: r1 = Null
    //     0x7882a8: mov             x1, NULL
    // 0x7882ac: b               #0x7882b8
    // 0x7882b0: LoadField: r1 = r2->field_7
    //     0x7882b0: ldur            w1, [x2, #7]
    // 0x7882b4: DecompressPointer r1
    //     0x7882b4: add             x1, x1, HEAP, lsl #32
    // 0x7882b8: cmp             w1, NULL
    // 0x7882bc: b.ne            #0x7882c8
    // 0x7882c0: d1 = 18.000000
    //     0x7882c0: fmov            d1, #18.00000000
    // 0x7882c4: b               #0x7882cc
    // 0x7882c8: LoadField: d1 = r1->field_7
    //     0x7882c8: ldur            d1, [x1, #7]
    // 0x7882cc: fcmp            d0, d1
    // 0x7882d0: b.vs            #0x78839c
    // 0x7882d4: b.le            #0x78839c
    // 0x7882d8: b               #0x788374
    // 0x7882dc: d0 = 0.000000
    //     0x7882dc: eor             v0.16b, v0.16b, v0.16b
    // 0x7882e0: LoadField: r3 = r0->field_63
    //     0x7882e0: ldur            w3, [x0, #0x63]
    // 0x7882e4: DecompressPointer r3
    //     0x7882e4: add             x3, x3, HEAP, lsl #32
    // 0x7882e8: LoadField: d1 = r3->field_7
    //     0x7882e8: ldur            d1, [x3, #7]
    // 0x7882ec: fcmp            d1, d0
    // 0x7882f0: b.vs            #0x788300
    // 0x7882f4: b.ne            #0x788300
    // 0x7882f8: d0 = 0.000000
    //     0x7882f8: eor             v0.16b, v0.16b, v0.16b
    // 0x7882fc: b               #0x788318
    // 0x788300: fcmp            d1, d0
    // 0x788304: b.vs            #0x788314
    // 0x788308: b.ge            #0x788314
    // 0x78830c: fneg            d0, d1
    // 0x788310: b               #0x788318
    // 0x788314: mov             v0.16b, v1.16b
    // 0x788318: LoadField: r3 = r1->field_7
    //     0x788318: ldur            x3, [x1, #7]
    // 0x78831c: cmp             x3, #2
    // 0x788320: b.gt            #0x78833c
    // 0x788324: cmp             x3, #1
    // 0x788328: b.gt            #0x78833c
    // 0x78832c: cmp             x3, #0
    // 0x788330: b.le            #0x78833c
    // 0x788334: d1 = 1.000000
    //     0x788334: fmov            d1, #1.00000000
    // 0x788338: b               #0x788368
    // 0x78833c: cmp             w2, NULL
    // 0x788340: b.ne            #0x78834c
    // 0x788344: r1 = Null
    //     0x788344: mov             x1, NULL
    // 0x788348: b               #0x788354
    // 0x78834c: LoadField: r1 = r2->field_7
    //     0x78834c: ldur            w1, [x2, #7]
    // 0x788350: DecompressPointer r1
    //     0x788350: add             x1, x1, HEAP, lsl #32
    // 0x788354: cmp             w1, NULL
    // 0x788358: b.ne            #0x788364
    // 0x78835c: d1 = 18.000000
    //     0x78835c: fmov            d1, #18.00000000
    // 0x788360: b               #0x788368
    // 0x788364: LoadField: d1 = r1->field_7
    //     0x788364: ldur            d1, [x1, #7]
    // 0x788368: fcmp            d0, d1
    // 0x78836c: b.vs            #0x78839c
    // 0x788370: b.le            #0x78839c
    // 0x788374: SaveReg r0
    //     0x788374: str             x0, [SP, #-8]!
    // 0x788378: r0 = _shouldAccpet()
    //     0x788378: bl              #0x788528  ; [package:extended_image/src/gesture_detector/drag.dart] _ExtendedDragGestureRecognizer&OneSequenceGestureRecognizer&DragGestureRecognizerMixin::_shouldAccpet
    // 0x78837c: add             SP, SP, #8
    // 0x788380: tbnz            w0, #4, #0x78839c
    // 0x788384: ldr             x16, [fp, #0x18]
    // 0x788388: r30 = Instance_GestureDisposition
    //     0x788388: add             lr, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x78838c: ldr             lr, [lr, #0xed0]
    // 0x788390: stp             lr, x16, [SP, #-0x10]!
    // 0x788394: r0 = resolve()
    //     0x788394: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x788398: add             SP, SP, #0x10
    // 0x78839c: ldr             x0, [fp, #0x10]
    // 0x7883a0: r2 = Null
    //     0x7883a0: mov             x2, NULL
    // 0x7883a4: r1 = Null
    //     0x7883a4: mov             x1, NULL
    // 0x7883a8: cmp             w0, NULL
    // 0x7883ac: b.eq            #0x7883cc
    // 0x7883b0: branchIfSmi(r0, 0x7883cc)
    //     0x7883b0: tbz             w0, #0, #0x7883cc
    // 0x7883b4: r3 = LoadClassIdInstr(r0)
    //     0x7883b4: ldur            x3, [x0, #-1]
    //     0x7883b8: ubfx            x3, x3, #0xc, #0x14
    // 0x7883bc: cmp             x3, #0x906
    // 0x7883c0: b.eq            #0x7883d4
    // 0x7883c4: cmp             x3, #0xb3d
    // 0x7883c8: b.eq            #0x7883d4
    // 0x7883cc: r0 = false
    //     0x7883cc: add             x0, NULL, #0x30  ; false
    // 0x7883d0: b               #0x7883d8
    // 0x7883d4: r0 = true
    //     0x7883d4: add             x0, NULL, #0x20  ; true
    // 0x7883d8: tbz             w0, #4, #0x78845c
    // 0x7883dc: ldr             x0, [fp, #0x10]
    // 0x7883e0: r2 = Null
    //     0x7883e0: mov             x2, NULL
    // 0x7883e4: r1 = Null
    //     0x7883e4: mov             x1, NULL
    // 0x7883e8: cmp             w0, NULL
    // 0x7883ec: b.eq            #0x78840c
    // 0x7883f0: branchIfSmi(r0, 0x78840c)
    //     0x7883f0: tbz             w0, #0, #0x78840c
    // 0x7883f4: r3 = LoadClassIdInstr(r0)
    //     0x7883f4: ldur            x3, [x0, #-1]
    //     0x7883f8: ubfx            x3, x3, #0xc, #0x14
    // 0x7883fc: cmp             x3, #0x8f8
    // 0x788400: b.eq            #0x788414
    // 0x788404: cmp             x3, #0xb35
    // 0x788408: b.eq            #0x788414
    // 0x78840c: r0 = false
    //     0x78840c: add             x0, NULL, #0x30  ; false
    // 0x788410: b               #0x788418
    // 0x788414: r0 = true
    //     0x788414: add             x0, NULL, #0x20  ; true
    // 0x788418: tbz             w0, #4, #0x78845c
    // 0x78841c: ldr             x0, [fp, #0x10]
    // 0x788420: r2 = Null
    //     0x788420: mov             x2, NULL
    // 0x788424: r1 = Null
    //     0x788424: mov             x1, NULL
    // 0x788428: cmp             w0, NULL
    // 0x78842c: b.eq            #0x78844c
    // 0x788430: branchIfSmi(r0, 0x78844c)
    //     0x788430: tbz             w0, #0, #0x78844c
    // 0x788434: r3 = LoadClassIdInstr(r0)
    //     0x788434: ldur            x3, [x0, #-1]
    //     0x788438: ubfx            x3, x3, #0xc, #0x14
    // 0x78843c: cmp             x3, #0x8fa
    // 0x788440: b.eq            #0x788454
    // 0x788444: cmp             x3, #0xb37
    // 0x788448: b.eq            #0x788454
    // 0x78844c: r0 = false
    //     0x78844c: add             x0, NULL, #0x30  ; false
    // 0x788450: b               #0x788458
    // 0x788454: r0 = true
    //     0x788454: add             x0, NULL, #0x20  ; true
    // 0x788458: tbnz            w0, #4, #0x788490
    // 0x78845c: ldr             x0, [fp, #0x10]
    // 0x788460: r1 = LoadClassIdInstr(r0)
    //     0x788460: ldur            x1, [x0, #-1]
    //     0x788464: ubfx            x1, x1, #0xc, #0x14
    // 0x788468: SaveReg r0
    //     0x788468: str             x0, [SP, #-8]!
    // 0x78846c: mov             x0, x1
    // 0x788470: r0 = GDT[cid_x0 + -0xfff]()
    //     0x788470: sub             lr, x0, #0xfff
    //     0x788474: ldr             lr, [x21, lr, lsl #3]
    //     0x788478: blr             lr
    // 0x78847c: add             SP, SP, #8
    // 0x788480: ldr             x16, [fp, #0x18]
    // 0x788484: stp             x0, x16, [SP, #-0x10]!
    // 0x788488: r0 = _giveUpPointer()
    //     0x788488: bl              #0x788b5c  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_giveUpPointer
    // 0x78848c: add             SP, SP, #0x10
    // 0x788490: r0 = Null
    //     0x788490: mov             x0, NULL
    // 0x788494: LeaveFrame
    //     0x788494: mov             SP, fp
    //     0x788498: ldp             fp, lr, [SP], #0x10
    // 0x78849c: ret
    //     0x78849c: ret             
    // 0x7884a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7884a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7884a4: b               #0x787550
    // 0x7884a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7884a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7884ac: r9 = _pendingDragOffset
    //     0x7884ac: add             x9, PP, #0x53, lsl #12  ; [pp+0x537a8] Field <ExtendedDragGestureRecognizer._pendingDragOffset@424469339>: late (offset: 0x54)
    //     0x7884b0: ldr             x9, [x9, #0x7a8]
    // 0x7884b4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x7884b4: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x7884b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7884b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7884bc: r9 = _globalDistanceMoved
    //     0x7884bc: add             x9, PP, #0x53, lsl #12  ; [pp+0x537b0] Field <ExtendedDragGestureRecognizer._globalDistanceMoved@424469339>: late (offset: 0x64)
    //     0x7884c0: ldr             x9, [x9, #0x7b0]
    // 0x7884c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7884c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7884c8: stp             q0, q2, [SP, #-0x20]!
    // 0x7884cc: stp             x2, x3, [SP, #-0x10]!
    // 0x7884d0: SaveReg r1
    //     0x7884d0: str             x1, [SP, #-8]!
    // 0x7884d4: r0 = AllocateDouble()
    //     0x7884d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7884d8: RestoreReg r1
    //     0x7884d8: ldr             x1, [SP], #8
    // 0x7884dc: ldp             x2, x3, [SP], #0x10
    // 0x7884e0: ldp             q0, q2, [SP], #0x20
    // 0x7884e4: b               #0x7881e4
  }
  _ _checkUpdate(/* No info */) {
    // ** addr: 0x788a50, size: 0x10c
    // 0x788a50: EnterFrame
    //     0x788a50: stp             fp, lr, [SP, #-0x10]!
    //     0x788a54: mov             fp, SP
    // 0x788a58: AllocStack(0x8)
    //     0x788a58: sub             SP, SP, #8
    // 0x788a5c: CheckStackOverflow
    //     0x788a5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x788a60: cmp             SP, x16
    //     0x788a64: b.ls            #0x788b3c
    // 0x788a68: r1 = 2
    //     0x788a68: mov             x1, #2
    // 0x788a6c: r0 = AllocateContext()
    //     0x788a6c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x788a70: mov             x1, x0
    // 0x788a74: ldr             x0, [fp, #0x38]
    // 0x788a78: stur            x1, [fp, #-8]
    // 0x788a7c: StoreField: r1->field_f = r0
    //     0x788a7c: stur            w0, [x1, #0xf]
    // 0x788a80: LoadField: r2 = r0->field_2f
    //     0x788a80: ldur            w2, [x0, #0x2f]
    // 0x788a84: DecompressPointer r2
    //     0x788a84: add             x2, x2, HEAP, lsl #32
    // 0x788a88: cmp             w2, NULL
    // 0x788a8c: b.eq            #0x788b2c
    // 0x788a90: ldr             x5, [fp, #0x30]
    // 0x788a94: ldr             x4, [fp, #0x28]
    // 0x788a98: ldr             x3, [fp, #0x20]
    // 0x788a9c: ldr             d0, [fp, #0x18]
    // 0x788aa0: ldr             x2, [fp, #0x10]
    // 0x788aa4: r0 = DragUpdateDetails()
    //     0x788aa4: bl              #0x64e814  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x1c)
    // 0x788aa8: mov             x1, x0
    // 0x788aac: ldr             x0, [fp, #0x10]
    // 0x788ab0: StoreField: r1->field_7 = r0
    //     0x788ab0: stur            w0, [x1, #7]
    // 0x788ab4: ldr             x0, [fp, #0x30]
    // 0x788ab8: StoreField: r1->field_b = r0
    //     0x788ab8: stur            w0, [x1, #0xb]
    // 0x788abc: ldr             d0, [fp, #0x18]
    // 0x788ac0: r0 = inline_Allocate_Double()
    //     0x788ac0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x788ac4: add             x0, x0, #0x10
    //     0x788ac8: cmp             x2, x0
    //     0x788acc: b.ls            #0x788b44
    //     0x788ad0: str             x0, [THR, #0x60]  ; THR::top
    //     0x788ad4: sub             x0, x0, #0xf
    //     0x788ad8: mov             x2, #0xd108
    //     0x788adc: movk            x2, #3, lsl #16
    //     0x788ae0: stur            x2, [x0, #-1]
    // 0x788ae4: StoreField: r0->field_7 = d0
    //     0x788ae4: stur            d0, [x0, #7]
    // 0x788ae8: StoreField: r1->field_f = r0
    //     0x788ae8: stur            w0, [x1, #0xf]
    // 0x788aec: ldr             x0, [fp, #0x28]
    // 0x788af0: StoreField: r1->field_13 = r0
    //     0x788af0: stur            w0, [x1, #0x13]
    // 0x788af4: ldr             x0, [fp, #0x20]
    // 0x788af8: StoreField: r1->field_17 = r0
    //     0x788af8: stur            w0, [x1, #0x17]
    // 0x788afc: ldur            x2, [fp, #-8]
    // 0x788b00: StoreField: r2->field_13 = r1
    //     0x788b00: stur            w1, [x2, #0x13]
    // 0x788b04: r1 = Function '<anonymous closure>':.
    //     0x788b04: add             x1, PP, #0x53, lsl #12  ; [pp+0x537c8] AnonymousClosure: (0x714940), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkEnd (0x714580)
    //     0x788b08: ldr             x1, [x1, #0x7c8]
    // 0x788b0c: r0 = AllocateClosure()
    //     0x788b0c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x788b10: r16 = <void?>
    //     0x788b10: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x788b14: ldr             lr, [fp, #0x38]
    // 0x788b18: stp             lr, x16, [SP, #-0x10]!
    // 0x788b1c: SaveReg r0
    //     0x788b1c: str             x0, [SP, #-8]!
    // 0x788b20: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x788b20: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x788b24: r0 = invokeCallback()
    //     0x788b24: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x788b28: add             SP, SP, #0x18
    // 0x788b2c: r0 = Null
    //     0x788b2c: mov             x0, NULL
    // 0x788b30: LeaveFrame
    //     0x788b30: mov             SP, fp
    //     0x788b34: ldp             fp, lr, [SP], #0x10
    // 0x788b38: ret
    //     0x788b38: ret             
    // 0x788b3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x788b3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x788b40: b               #0x788a68
    // 0x788b44: SaveReg d0
    //     0x788b44: str             q0, [SP, #-0x10]!
    // 0x788b48: SaveReg r1
    //     0x788b48: str             x1, [SP, #-8]!
    // 0x788b4c: r0 = AllocateDouble()
    //     0x788b4c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x788b50: RestoreReg r1
    //     0x788b50: ldr             x1, [SP], #8
    // 0x788b54: RestoreReg d0
    //     0x788b54: ldr             q0, [SP], #0x10
    // 0x788b58: b               #0x788ae4
  }
  _ _giveUpPointer(/* No info */) {
    // ** addr: 0x788b5c, size: 0x90
    // 0x788b5c: EnterFrame
    //     0x788b5c: stp             fp, lr, [SP, #-0x10]!
    //     0x788b60: mov             fp, SP
    // 0x788b64: AllocStack(0x8)
    //     0x788b64: sub             SP, SP, #8
    // 0x788b68: CheckStackOverflow
    //     0x788b68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x788b6c: cmp             SP, x16
    //     0x788b70: b.ls            #0x788be4
    // 0x788b74: ldr             x2, [fp, #0x10]
    // 0x788b78: r0 = BoxInt64Instr(r2)
    //     0x788b78: sbfiz           x0, x2, #1, #0x1f
    //     0x788b7c: cmp             x2, x0, asr #1
    //     0x788b80: b.eq            #0x788b8c
    //     0x788b84: bl              #0xd69bb8
    //     0x788b88: stur            x2, [x0, #7]
    // 0x788b8c: stur            x0, [fp, #-8]
    // 0x788b90: ldr             x16, [fp, #0x18]
    // 0x788b94: stp             x0, x16, [SP, #-0x10]!
    // 0x788b98: r0 = stopTrackingPointer()
    //     0x788b98: bl              #0x71334c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0x788b9c: add             SP, SP, #0x10
    // 0x788ba0: ldr             x0, [fp, #0x18]
    // 0x788ba4: LoadField: r1 = r0->field_6b
    //     0x788ba4: ldur            w1, [x0, #0x6b]
    // 0x788ba8: DecompressPointer r1
    //     0x788ba8: add             x1, x1, HEAP, lsl #32
    // 0x788bac: ldur            x16, [fp, #-8]
    // 0x788bb0: stp             x16, x1, [SP, #-0x10]!
    // 0x788bb4: r0 = remove()
    //     0x788bb4: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x788bb8: add             SP, SP, #0x10
    // 0x788bbc: tbz             w0, #4, #0x788bd4
    // 0x788bc0: ldr             x0, [fp, #0x10]
    // 0x788bc4: ldr             x16, [fp, #0x18]
    // 0x788bc8: stp             x0, x16, [SP, #-0x10]!
    // 0x788bcc: r0 = resolvePointer()
    //     0x788bcc: bl              #0x788bec  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolvePointer
    // 0x788bd0: add             SP, SP, #0x10
    // 0x788bd4: r0 = Null
    //     0x788bd4: mov             x0, NULL
    // 0x788bd8: LeaveFrame
    //     0x788bd8: mov             SP, fp
    //     0x788bdc: ldp             fp, lr, [SP], #0x10
    // 0x788be0: ret
    //     0x788be0: ret             
    // 0x788be4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x788be4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x788be8: b               #0x788b74
  }
  _ ExtendedDragGestureRecognizer(/* No info */) {
    // ** addr: 0x79caf8, size: 0x168
    // 0x79caf8: EnterFrame
    //     0x79caf8: stp             fp, lr, [SP, #-0x10]!
    //     0x79cafc: mov             fp, SP
    // 0x79cb00: AllocStack(0x10)
    //     0x79cb00: sub             SP, SP, #0x10
    // 0x79cb04: r1 = Instance__DragState
    //     0x79cb04: add             x1, PP, #0x51, lsl #12  ; [pp+0x51440] Obj!_DragState@b660d1
    //     0x79cb08: ldr             x1, [x1, #0x440]
    // 0x79cb0c: r0 = Sentinel
    //     0x79cb0c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79cb10: CheckStackOverflow
    //     0x79cb10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79cb14: cmp             SP, x16
    //     0x79cb18: b.ls            #0x79cc58
    // 0x79cb1c: ldr             x2, [fp, #0x18]
    // 0x79cb20: StoreField: r2->field_4b = r1
    //     0x79cb20: stur            w1, [x2, #0x4b]
    // 0x79cb24: StoreField: r2->field_4f = r0
    //     0x79cb24: stur            w0, [x2, #0x4f]
    // 0x79cb28: StoreField: r2->field_53 = r0
    //     0x79cb28: stur            w0, [x2, #0x53]
    // 0x79cb2c: StoreField: r2->field_63 = r0
    //     0x79cb2c: stur            w0, [x2, #0x63]
    // 0x79cb30: r16 = <int, VelocityTracker>
    //     0x79cb30: add             x16, PP, #0x21, lsl #12  ; [pp+0x21498] TypeArguments: <int, VelocityTracker>
    //     0x79cb34: ldr             x16, [x16, #0x498]
    // 0x79cb38: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x79cb3c: stp             lr, x16, [SP, #-0x10]!
    // 0x79cb40: r0 = Map._fromLiteral()
    //     0x79cb40: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x79cb44: add             SP, SP, #0x10
    // 0x79cb48: ldr             x1, [fp, #0x18]
    // 0x79cb4c: StoreField: r1->field_67 = r0
    //     0x79cb4c: stur            w0, [x1, #0x67]
    //     0x79cb50: tbz             w0, #0, #0x79cb6c
    //     0x79cb54: ldurb           w16, [x1, #-1]
    //     0x79cb58: ldurb           w17, [x0, #-1]
    //     0x79cb5c: and             x16, x17, x16, lsr #2
    //     0x79cb60: tst             x16, HEAP, lsr #32
    //     0x79cb64: b.eq            #0x79cb6c
    //     0x79cb68: bl              #0xd6826c
    // 0x79cb6c: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x79cb6c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x79cb70: ldr             x0, [x0, #0x598]
    //     0x79cb74: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x79cb78: cmp             w0, w16
    //     0x79cb7c: b.ne            #0x79cb88
    //     0x79cb80: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x79cb84: bl              #0xd67cdc
    // 0x79cb88: r1 = <int>
    //     0x79cb88: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x79cb8c: stur            x0, [fp, #-8]
    // 0x79cb90: r0 = _Set()
    //     0x79cb90: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x79cb94: mov             x1, x0
    // 0x79cb98: ldur            x0, [fp, #-8]
    // 0x79cb9c: stur            x1, [fp, #-0x10]
    // 0x79cba0: StoreField: r1->field_1b = r0
    //     0x79cba0: stur            w0, [x1, #0x1b]
    // 0x79cba4: StoreField: r1->field_b = rZR
    //     0x79cba4: stur            wzr, [x1, #0xb]
    // 0x79cba8: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x79cba8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x79cbac: ldr             x0, [x0, #0x5a0]
    //     0x79cbb0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x79cbb4: cmp             w0, w16
    //     0x79cbb8: b.ne            #0x79cbc4
    //     0x79cbbc: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x79cbc0: bl              #0xd67cdc
    // 0x79cbc4: mov             x1, x0
    // 0x79cbc8: ldur            x0, [fp, #-0x10]
    // 0x79cbcc: StoreField: r0->field_f = r1
    //     0x79cbcc: stur            w1, [x0, #0xf]
    // 0x79cbd0: StoreField: r0->field_13 = rZR
    //     0x79cbd0: stur            wzr, [x0, #0x13]
    // 0x79cbd4: StoreField: r0->field_17 = rZR
    //     0x79cbd4: stur            wzr, [x0, #0x17]
    // 0x79cbd8: ldr             x1, [fp, #0x18]
    // 0x79cbdc: StoreField: r1->field_6b = r0
    //     0x79cbdc: stur            w0, [x1, #0x6b]
    //     0x79cbe0: ldurb           w16, [x1, #-1]
    //     0x79cbe4: ldurb           w17, [x0, #-1]
    //     0x79cbe8: and             x16, x17, x16, lsr #2
    //     0x79cbec: tst             x16, HEAP, lsr #32
    //     0x79cbf0: b.eq            #0x79cbf8
    //     0x79cbf4: bl              #0xd6826c
    // 0x79cbf8: r0 = Instance_DragStartBehavior
    //     0x79cbf8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x79cbfc: ldr             x0, [x0, #0xf88]
    // 0x79cc00: StoreField: r1->field_23 = r0
    //     0x79cc00: stur            w0, [x1, #0x23]
    // 0x79cc04: r0 = Closure: (PointerEvent) => ExtendedVelocityTracker from Function '_defaultBuilder@424469339': static.
    //     0x79cc04: add             x0, PP, #0x51, lsl #12  ; [pp+0x51448] Closure: (PointerEvent) => ExtendedVelocityTracker from Function '_defaultBuilder@424469339': static. (0x7fe6e1f9cc60)
    //     0x79cc08: ldr             x0, [x0, #0x448]
    // 0x79cc0c: StoreField: r1->field_47 = r0
    //     0x79cc0c: stur            w0, [x1, #0x47]
    // 0x79cc10: ldr             x0, [fp, #0x10]
    // 0x79cc14: StoreField: r1->field_1f = r0
    //     0x79cc14: stur            w0, [x1, #0x1f]
    //     0x79cc18: ldurb           w16, [x1, #-1]
    //     0x79cc1c: ldurb           w17, [x0, #-1]
    //     0x79cc20: and             x16, x17, x16, lsr #2
    //     0x79cc24: tst             x16, HEAP, lsr #32
    //     0x79cc28: b.eq            #0x79cc30
    //     0x79cc2c: bl              #0xd6826c
    // 0x79cc30: stp             NULL, x1, [SP, #-0x10]!
    // 0x79cc34: SaveReg rNULL
    //     0x79cc34: str             NULL, [SP, #-8]!
    // 0x79cc38: r4 = const [0, 0x3, 0x3, 0x1, kind, 0x1, supportedDevices, 0x2, null]
    //     0x79cc38: add             x4, PP, #0x21, lsl #12  ; [pp+0x214b0] List(9) [0, 0x3, 0x3, 0x1, "kind", 0x1, "supportedDevices", 0x2, Null]
    //     0x79cc3c: ldr             x4, [x4, #0x4b0]
    // 0x79cc40: r0 = OneSequenceGestureRecognizer()
    //     0x79cc40: bl              #0x6d3ef4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0x79cc44: add             SP, SP, #0x18
    // 0x79cc48: r0 = Null
    //     0x79cc48: mov             x0, NULL
    // 0x79cc4c: LeaveFrame
    //     0x79cc4c: mov             SP, fp
    //     0x79cc50: ldp             fp, lr, [SP], #0x10
    // 0x79cc54: ret
    //     0x79cc54: ret             
    // 0x79cc58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79cc58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79cc5c: b               #0x79cb1c
  }
  [closure] static ExtendedVelocityTracker _defaultBuilder(dynamic, PointerEvent) {
    // ** addr: 0x79cc60, size: 0x38
    // 0x79cc60: EnterFrame
    //     0x79cc60: stp             fp, lr, [SP, #-0x10]!
    //     0x79cc64: mov             fp, SP
    // 0x79cc68: CheckStackOverflow
    //     0x79cc68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79cc6c: cmp             SP, x16
    //     0x79cc70: b.ls            #0x79cc90
    // 0x79cc74: ldr             x16, [fp, #0x10]
    // 0x79cc78: SaveReg r16
    //     0x79cc78: str             x16, [SP, #-8]!
    // 0x79cc7c: r0 = _defaultBuilder()
    //     0x79cc7c: bl              #0x79cc98  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_defaultBuilder
    // 0x79cc80: add             SP, SP, #8
    // 0x79cc84: LeaveFrame
    //     0x79cc84: mov             SP, fp
    //     0x79cc88: ldp             fp, lr, [SP], #0x10
    // 0x79cc8c: ret
    //     0x79cc8c: ret             
    // 0x79cc90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79cc90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79cc94: b               #0x79cc74
  }
  static _ _defaultBuilder(/* No info */) {
    // ** addr: 0x79cc98, size: 0xb0
    // 0x79cc98: EnterFrame
    //     0x79cc98: stp             fp, lr, [SP, #-0x10]!
    //     0x79cc9c: mov             fp, SP
    // 0x79cca0: AllocStack(0x10)
    //     0x79cca0: sub             SP, SP, #0x10
    // 0x79cca4: CheckStackOverflow
    //     0x79cca4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79cca8: cmp             SP, x16
    //     0x79ccac: b.ls            #0x79cd40
    // 0x79ccb0: ldr             x0, [fp, #0x10]
    // 0x79ccb4: r1 = LoadClassIdInstr(r0)
    //     0x79ccb4: ldur            x1, [x0, #-1]
    //     0x79ccb8: ubfx            x1, x1, #0xc, #0x14
    // 0x79ccbc: SaveReg r0
    //     0x79ccbc: str             x0, [SP, #-8]!
    // 0x79ccc0: mov             x0, x1
    // 0x79ccc4: r0 = GDT[cid_x0 + -0xf60]()
    //     0x79ccc4: sub             lr, x0, #0xf60
    //     0x79ccc8: ldr             lr, [x21, lr, lsl #3]
    //     0x79cccc: blr             lr
    // 0x79ccd0: add             SP, SP, #8
    // 0x79ccd4: stur            x0, [fp, #-8]
    // 0x79ccd8: r0 = ExtendedVelocityTracker()
    //     0x79ccd8: bl              #0x79cd48  ; AllocateExtendedVelocityTrackerStub -> ExtendedVelocityTracker (size=0x24)
    // 0x79ccdc: mov             x3, x0
    // 0x79cce0: r0 = 0
    //     0x79cce0: mov             x0, #0
    // 0x79cce4: stur            x3, [fp, #-0x10]
    // 0x79cce8: StoreField: r3->field_1b = r0
    //     0x79cce8: stur            x0, [x3, #0x1b]
    // 0x79ccec: r1 = <_PointAtTime?>
    //     0x79ccec: add             x1, PP, #0x51, lsl #12  ; [pp+0x51450] TypeArguments: <_PointAtTime?>
    //     0x79ccf0: ldr             x1, [x1, #0x450]
    // 0x79ccf4: r2 = 40
    //     0x79ccf4: mov             x2, #0x28
    // 0x79ccf8: r0 = AllocateArray()
    //     0x79ccf8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x79ccfc: mov             x1, x0
    // 0x79cd00: ldur            x0, [fp, #-0x10]
    // 0x79cd04: StoreField: r0->field_17 = r1
    //     0x79cd04: stur            w1, [x0, #0x17]
    // 0x79cd08: r1 = 0
    //     0x79cd08: mov             x1, #0
    // 0x79cd0c: StoreField: r0->field_f = r1
    //     0x79cd0c: stur            x1, [x0, #0xf]
    // 0x79cd10: r1 = <_PointAtTime?>
    //     0x79cd10: add             x1, PP, #0x21, lsl #12  ; [pp+0x214e8] TypeArguments: <_PointAtTime?>
    //     0x79cd14: ldr             x1, [x1, #0x4e8]
    // 0x79cd18: r2 = 40
    //     0x79cd18: mov             x2, #0x28
    // 0x79cd1c: r0 = AllocateArray()
    //     0x79cd1c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x79cd20: mov             x1, x0
    // 0x79cd24: ldur            x0, [fp, #-0x10]
    // 0x79cd28: StoreField: r0->field_b = r1
    //     0x79cd28: stur            w1, [x0, #0xb]
    // 0x79cd2c: ldur            x1, [fp, #-8]
    // 0x79cd30: StoreField: r0->field_7 = r1
    //     0x79cd30: stur            w1, [x0, #7]
    // 0x79cd34: LeaveFrame
    //     0x79cd34: mov             SP, fp
    //     0x79cd38: ldp             fp, lr, [SP], #0x10
    // 0x79cd3c: ret
    //     0x79cd3c: ret             
    // 0x79cd40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79cd40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79cd44: b               #0x79ccb0
  }
  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xa819f0, size: 0x1c0
    // 0xa819f0: EnterFrame
    //     0xa819f0: stp             fp, lr, [SP, #-0x10]!
    //     0xa819f4: mov             fp, SP
    // 0xa819f8: CheckStackOverflow
    //     0xa819f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa819fc: cmp             SP, x16
    //     0xa81a00: b.ls            #0xa81ba8
    // 0xa81a04: ldr             x1, [fp, #0x18]
    // 0xa81a08: LoadField: r0 = r1->field_5b
    //     0xa81a08: ldur            w0, [x1, #0x5b]
    // 0xa81a0c: DecompressPointer r0
    //     0xa81a0c: add             x0, x0, HEAP, lsl #32
    // 0xa81a10: cmp             w0, NULL
    // 0xa81a14: b.ne            #0xa81af4
    // 0xa81a18: ldr             x2, [fp, #0x10]
    // 0xa81a1c: r0 = LoadClassIdInstr(r2)
    //     0xa81a1c: ldur            x0, [x2, #-1]
    //     0xa81a20: ubfx            x0, x0, #0xc, #0x14
    // 0xa81a24: SaveReg r2
    //     0xa81a24: str             x2, [SP, #-8]!
    // 0xa81a28: r0 = GDT[cid_x0 + 0x271c]()
    //     0xa81a28: mov             x17, #0x271c
    //     0xa81a2c: add             lr, x0, x17
    //     0xa81a30: ldr             lr, [x21, lr, lsl #3]
    //     0xa81a34: blr             lr
    // 0xa81a38: add             SP, SP, #8
    // 0xa81a3c: mov             x2, x0
    // 0xa81a40: r0 = BoxInt64Instr(r2)
    //     0xa81a40: sbfiz           x0, x2, #1, #0x1f
    //     0xa81a44: cmp             x2, x0, asr #1
    //     0xa81a48: b.eq            #0xa81a54
    //     0xa81a4c: bl              #0xd69bb8
    //     0xa81a50: stur            x2, [x0, #7]
    // 0xa81a54: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xa81a54: mov             x1, #0x76
    //     0xa81a58: tbz             w0, #0, #0xa81a68
    //     0xa81a5c: ldur            x1, [x0, #-1]
    //     0xa81a60: ubfx            x1, x1, #0xc, #0x14
    //     0xa81a64: lsl             x1, x1, #1
    // 0xa81a68: cmp             w1, #0x76
    // 0xa81a6c: b.ne            #0xa81ae4
    // 0xa81a70: cmp             w0, #2
    // 0xa81a74: b.ne            #0xa81ae4
    // 0xa81a78: ldr             x1, [fp, #0x18]
    // 0xa81a7c: LoadField: r0 = r1->field_27
    //     0xa81a7c: ldur            w0, [x1, #0x27]
    // 0xa81a80: DecompressPointer r0
    //     0xa81a80: add             x0, x0, HEAP, lsl #32
    // 0xa81a84: cmp             w0, NULL
    // 0xa81a88: b.ne            #0xa81adc
    // 0xa81a8c: LoadField: r0 = r1->field_2b
    //     0xa81a8c: ldur            w0, [x1, #0x2b]
    // 0xa81a90: DecompressPointer r0
    //     0xa81a90: add             x0, x0, HEAP, lsl #32
    // 0xa81a94: cmp             w0, NULL
    // 0xa81a98: b.ne            #0xa81adc
    // 0xa81a9c: LoadField: r0 = r1->field_2f
    //     0xa81a9c: ldur            w0, [x1, #0x2f]
    // 0xa81aa0: DecompressPointer r0
    //     0xa81aa0: add             x0, x0, HEAP, lsl #32
    // 0xa81aa4: cmp             w0, NULL
    // 0xa81aa8: b.ne            #0xa81adc
    // 0xa81aac: LoadField: r0 = r1->field_33
    //     0xa81aac: ldur            w0, [x1, #0x33]
    // 0xa81ab0: DecompressPointer r0
    //     0xa81ab0: add             x0, x0, HEAP, lsl #32
    // 0xa81ab4: cmp             w0, NULL
    // 0xa81ab8: b.ne            #0xa81adc
    // 0xa81abc: LoadField: r0 = r1->field_37
    //     0xa81abc: ldur            w0, [x1, #0x37]
    // 0xa81ac0: DecompressPointer r0
    //     0xa81ac0: add             x0, x0, HEAP, lsl #32
    // 0xa81ac4: cmp             w0, NULL
    // 0xa81ac8: b.ne            #0xa81adc
    // 0xa81acc: r0 = false
    //     0xa81acc: add             x0, NULL, #0x30  ; false
    // 0xa81ad0: LeaveFrame
    //     0xa81ad0: mov             SP, fp
    //     0xa81ad4: ldp             fp, lr, [SP], #0x10
    // 0xa81ad8: ret
    //     0xa81ad8: ret             
    // 0xa81adc: mov             x2, x1
    // 0xa81ae0: b               #0xa81b8c
    // 0xa81ae4: r0 = false
    //     0xa81ae4: add             x0, NULL, #0x30  ; false
    // 0xa81ae8: LeaveFrame
    //     0xa81ae8: mov             SP, fp
    //     0xa81aec: ldp             fp, lr, [SP], #0x10
    // 0xa81af0: ret
    //     0xa81af0: ret             
    // 0xa81af4: ldr             x2, [fp, #0x10]
    // 0xa81af8: r0 = LoadClassIdInstr(r2)
    //     0xa81af8: ldur            x0, [x2, #-1]
    //     0xa81afc: ubfx            x0, x0, #0xc, #0x14
    // 0xa81b00: SaveReg r2
    //     0xa81b00: str             x2, [SP, #-8]!
    // 0xa81b04: r0 = GDT[cid_x0 + 0x271c]()
    //     0xa81b04: mov             x17, #0x271c
    //     0xa81b08: add             lr, x0, x17
    //     0xa81b0c: ldr             lr, [x21, lr, lsl #3]
    //     0xa81b10: blr             lr
    // 0xa81b14: add             SP, SP, #8
    // 0xa81b18: mov             x3, x0
    // 0xa81b1c: ldr             x2, [fp, #0x18]
    // 0xa81b20: LoadField: r4 = r2->field_5b
    //     0xa81b20: ldur            w4, [x2, #0x5b]
    // 0xa81b24: DecompressPointer r4
    //     0xa81b24: add             x4, x4, HEAP, lsl #32
    // 0xa81b28: r0 = BoxInt64Instr(r3)
    //     0xa81b28: sbfiz           x0, x3, #1, #0x1f
    //     0xa81b2c: cmp             x3, x0, asr #1
    //     0xa81b30: b.eq            #0xa81b3c
    //     0xa81b34: bl              #0xd69bb8
    //     0xa81b38: stur            x3, [x0, #7]
    // 0xa81b3c: cmp             w0, w4
    // 0xa81b40: b.eq            #0xa81b8c
    // 0xa81b44: and             w16, w0, w4
    // 0xa81b48: branchIfSmi(r16, 0xa81b7c)
    //     0xa81b48: tbz             w16, #0, #0xa81b7c
    // 0xa81b4c: r16 = LoadClassIdInstr(r0)
    //     0xa81b4c: ldur            x16, [x0, #-1]
    //     0xa81b50: ubfx            x16, x16, #0xc, #0x14
    // 0xa81b54: cmp             x16, #0x3c
    // 0xa81b58: b.ne            #0xa81b7c
    // 0xa81b5c: r16 = LoadClassIdInstr(r4)
    //     0xa81b5c: ldur            x16, [x4, #-1]
    //     0xa81b60: ubfx            x16, x16, #0xc, #0x14
    // 0xa81b64: cmp             x16, #0x3c
    // 0xa81b68: b.ne            #0xa81b7c
    // 0xa81b6c: LoadField: r16 = r0->field_7
    //     0xa81b6c: ldur            x16, [x0, #7]
    // 0xa81b70: LoadField: r17 = r4->field_7
    //     0xa81b70: ldur            x17, [x4, #7]
    // 0xa81b74: cmp             x16, x17
    // 0xa81b78: b.eq            #0xa81b8c
    // 0xa81b7c: r0 = false
    //     0xa81b7c: add             x0, NULL, #0x30  ; false
    // 0xa81b80: LeaveFrame
    //     0xa81b80: mov             SP, fp
    //     0xa81b84: ldp             fp, lr, [SP], #0x10
    // 0xa81b88: ret
    //     0xa81b88: ret             
    // 0xa81b8c: ldr             x16, [fp, #0x10]
    // 0xa81b90: stp             x16, x2, [SP, #-0x10]!
    // 0xa81b94: r0 = isPointerAllowed()
    //     0xa81b94: bl              #0xa829e0  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::isPointerAllowed
    // 0xa81b98: add             SP, SP, #0x10
    // 0xa81b9c: LeaveFrame
    //     0xa81b9c: mov             SP, fp
    //     0xa81ba0: ldp             fp, lr, [SP], #0x10
    // 0xa81ba4: ret
    //     0xa81ba4: ret             
    // 0xa81ba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa81ba8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa81bac: b               #0xa81a04
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbd91f8, size: 0x54
    // 0xbd91f8: EnterFrame
    //     0xbd91f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbd91fc: mov             fp, SP
    // 0xbd9200: CheckStackOverflow
    //     0xbd9200: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd9204: cmp             SP, x16
    //     0xbd9208: b.ls            #0xbd9244
    // 0xbd920c: ldr             x0, [fp, #0x10]
    // 0xbd9210: LoadField: r1 = r0->field_67
    //     0xbd9210: ldur            w1, [x0, #0x67]
    // 0xbd9214: DecompressPointer r1
    //     0xbd9214: add             x1, x1, HEAP, lsl #32
    // 0xbd9218: SaveReg r1
    //     0xbd9218: str             x1, [SP, #-8]!
    // 0xbd921c: r0 = clear()
    //     0xbd921c: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xbd9220: add             SP, SP, #8
    // 0xbd9224: ldr             x16, [fp, #0x10]
    // 0xbd9228: SaveReg r16
    //     0xbd9228: str             x16, [SP, #-8]!
    // 0xbd922c: r0 = dispose()
    //     0xbd922c: bl              #0xbd93a4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::dispose
    // 0xbd9230: add             SP, SP, #8
    // 0xbd9234: r0 = Null
    //     0xbd9234: mov             x0, NULL
    // 0xbd9238: LeaveFrame
    //     0xbd9238: mov             SP, fp
    //     0xbd923c: ldp             fp, lr, [SP], #0x10
    // 0xbd9240: ret
    //     0xbd9240: ret             
    // 0xbd9244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd9244: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd9248: b               #0xbd920c
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0xbdaa2c, size: 0x324
    // 0xbdaa2c: EnterFrame
    //     0xbdaa2c: stp             fp, lr, [SP, #-0x10]!
    //     0xbdaa30: mov             fp, SP
    // 0xbdaa34: AllocStack(0x20)
    //     0xbdaa34: sub             SP, SP, #0x20
    // 0xbdaa38: CheckStackOverflow
    //     0xbdaa38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdaa3c: cmp             SP, x16
    //     0xbdaa40: b.ls            #0xbdad20
    // 0xbdaa44: ldr             x2, [fp, #0x18]
    // 0xbdaa48: LoadField: r3 = r2->field_6b
    //     0xbdaa48: ldur            w3, [x2, #0x6b]
    // 0xbdaa4c: DecompressPointer r3
    //     0xbdaa4c: add             x3, x3, HEAP, lsl #32
    // 0xbdaa50: ldr             x4, [fp, #0x10]
    // 0xbdaa54: r0 = BoxInt64Instr(r4)
    //     0xbdaa54: sbfiz           x0, x4, #1, #0x1f
    //     0xbdaa58: cmp             x4, x0, asr #1
    //     0xbdaa5c: b.eq            #0xbdaa68
    //     0xbdaa60: bl              #0xd69bb8
    //     0xbdaa64: stur            x4, [x0, #7]
    // 0xbdaa68: stp             x0, x3, [SP, #-0x10]!
    // 0xbdaa6c: r0 = add()
    //     0xbdaa6c: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xbdaa70: add             SP, SP, #0x10
    // 0xbdaa74: ldr             x0, [fp, #0x18]
    // 0xbdaa78: LoadField: r1 = r0->field_4b
    //     0xbdaa78: ldur            w1, [x0, #0x4b]
    // 0xbdaa7c: DecompressPointer r1
    //     0xbdaa7c: add             x1, x1, HEAP, lsl #32
    // 0xbdaa80: r16 = Instance__DragState
    //     0xbdaa80: add             x16, PP, #0x53, lsl #12  ; [pp+0x537a0] Obj!_DragState@b66111
    //     0xbdaa84: ldr             x16, [x16, #0x7a0]
    // 0xbdaa88: cmp             w1, w16
    // 0xbdaa8c: b.eq            #0xbdad10
    // 0xbdaa90: r1 = Instance__DragState
    //     0xbdaa90: add             x1, PP, #0x53, lsl #12  ; [pp+0x537a0] Obj!_DragState@b66111
    //     0xbdaa94: ldr             x1, [x1, #0x7a0]
    // 0xbdaa98: StoreField: r0->field_4b = r1
    //     0xbdaa98: stur            w1, [x0, #0x4b]
    // 0xbdaa9c: LoadField: r1 = r0->field_53
    //     0xbdaa9c: ldur            w1, [x0, #0x53]
    // 0xbdaaa0: DecompressPointer r1
    //     0xbdaaa0: add             x1, x1, HEAP, lsl #32
    // 0xbdaaa4: r16 = Sentinel
    //     0xbdaaa4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdaaa8: cmp             w1, w16
    // 0xbdaaac: b.eq            #0xbdad28
    // 0xbdaab0: LoadField: r2 = r0->field_57
    //     0xbdaab0: ldur            w2, [x0, #0x57]
    // 0xbdaab4: DecompressPointer r2
    //     0xbdaab4: add             x2, x2, HEAP, lsl #32
    // 0xbdaab8: stur            x2, [fp, #-0x10]
    // 0xbdaabc: cmp             w2, NULL
    // 0xbdaac0: b.eq            #0xbdad34
    // 0xbdaac4: LoadField: r3 = r0->field_5f
    //     0xbdaac4: ldur            w3, [x0, #0x5f]
    // 0xbdaac8: DecompressPointer r3
    //     0xbdaac8: add             x3, x3, HEAP, lsl #32
    // 0xbdaacc: stur            x3, [fp, #-8]
    // 0xbdaad0: LoadField: r4 = r0->field_23
    //     0xbdaad0: ldur            w4, [x0, #0x23]
    // 0xbdaad4: DecompressPointer r4
    //     0xbdaad4: add             x4, x4, HEAP, lsl #32
    // 0xbdaad8: LoadField: r5 = r4->field_7
    //     0xbdaad8: ldur            x5, [x4, #7]
    // 0xbdaadc: cmp             x5, #0
    // 0xbdaae0: b.gt            #0xbdab50
    // 0xbdaae4: LoadField: r4 = r1->field_7
    //     0xbdaae4: ldur            w4, [x1, #7]
    // 0xbdaae8: DecompressPointer r4
    //     0xbdaae8: add             x4, x4, HEAP, lsl #32
    // 0xbdaaec: r1 = LoadClassIdInstr(r0)
    //     0xbdaaec: ldur            x1, [x0, #-1]
    //     0xbdaaf0: ubfx            x1, x1, #0xc, #0x14
    // 0xbdaaf4: lsl             x1, x1, #1
    // 0xbdaaf8: r17 = 4732
    //     0xbdaaf8: mov             x17, #0x127c
    // 0xbdaafc: cmp             w1, w17
    // 0xbdab00: b.ne            #0xbdab24
    // 0xbdab04: LoadField: d0 = r4->field_7
    //     0xbdab04: ldur            d0, [x4, #7]
    // 0xbdab08: stur            d0, [fp, #-0x20]
    // 0xbdab0c: r0 = Offset()
    //     0xbdab0c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbdab10: ldur            d0, [fp, #-0x20]
    // 0xbdab14: StoreField: r0->field_7 = d0
    //     0xbdab14: stur            d0, [x0, #7]
    // 0xbdab18: d0 = 0.000000
    //     0xbdab18: eor             v0.16b, v0.16b, v0.16b
    // 0xbdab1c: StoreField: r0->field_f = d0
    //     0xbdab1c: stur            d0, [x0, #0xf]
    // 0xbdab20: b               #0xbdab44
    // 0xbdab24: d0 = 0.000000
    //     0xbdab24: eor             v0.16b, v0.16b, v0.16b
    // 0xbdab28: LoadField: d1 = r4->field_f
    //     0xbdab28: ldur            d1, [x4, #0xf]
    // 0xbdab2c: stur            d1, [fp, #-0x20]
    // 0xbdab30: r0 = Offset()
    //     0xbdab30: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbdab34: d0 = 0.000000
    //     0xbdab34: eor             v0.16b, v0.16b, v0.16b
    // 0xbdab38: StoreField: r0->field_7 = d0
    //     0xbdab38: stur            d0, [x0, #7]
    // 0xbdab3c: ldur            d0, [fp, #-0x20]
    // 0xbdab40: StoreField: r0->field_f = d0
    //     0xbdab40: stur            d0, [x0, #0xf]
    // 0xbdab44: mov             x3, x0
    // 0xbdab48: ldr             x1, [fp, #0x18]
    // 0xbdab4c: b               #0xbdab94
    // 0xbdab50: LoadField: r2 = r0->field_4f
    //     0xbdab50: ldur            w2, [x0, #0x4f]
    // 0xbdab54: DecompressPointer r2
    //     0xbdab54: add             x2, x2, HEAP, lsl #32
    // 0xbdab58: r16 = Sentinel
    //     0xbdab58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdab5c: cmp             w2, w16
    // 0xbdab60: b.eq            #0xbdad38
    // 0xbdab64: stp             x1, x2, [SP, #-0x10]!
    // 0xbdab68: r0 = +()
    //     0xbdab68: bl              #0x714388  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0xbdab6c: add             SP, SP, #0x10
    // 0xbdab70: ldr             x1, [fp, #0x18]
    // 0xbdab74: StoreField: r1->field_4f = r0
    //     0xbdab74: stur            w0, [x1, #0x4f]
    //     0xbdab78: ldurb           w16, [x1, #-1]
    //     0xbdab7c: ldurb           w17, [x0, #-1]
    //     0xbdab80: and             x16, x17, x16, lsr #2
    //     0xbdab84: tst             x16, HEAP, lsr #32
    //     0xbdab88: b.eq            #0xbdab90
    //     0xbdab8c: bl              #0xd6826c
    // 0xbdab90: r3 = Instance_Offset
    //     0xbdab90: ldr             x3, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xbdab94: ldr             x0, [fp, #0x10]
    // 0xbdab98: r2 = Instance_OffsetPair
    //     0xbdab98: add             x2, PP, #0x28, lsl #12  ; [pp+0x28f10] Obj!OffsetPair@b38711
    //     0xbdab9c: ldr             x2, [x2, #0xf10]
    // 0xbdaba0: stur            x3, [fp, #-0x18]
    // 0xbdaba4: StoreField: r1->field_53 = r2
    //     0xbdaba4: stur            w2, [x1, #0x53]
    // 0xbdaba8: StoreField: r1->field_57 = rNULL
    //     0xbdaba8: stur            NULL, [x1, #0x57]
    // 0xbdabac: StoreField: r1->field_5f = rNULL
    //     0xbdabac: stur            NULL, [x1, #0x5f]
    // 0xbdabb0: ldur            x16, [fp, #-0x10]
    // 0xbdabb4: stp             x16, x1, [SP, #-0x10]!
    // 0xbdabb8: SaveReg r0
    //     0xbdabb8: str             x0, [SP, #-8]!
    // 0xbdabbc: r0 = _checkStart()
    //     0xbdabbc: bl              #0xbdad50  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_checkStart
    // 0xbdabc0: add             SP, SP, #0x18
    // 0xbdabc4: ldur            x16, [fp, #-0x18]
    // 0xbdabc8: r30 = Instance_Offset
    //     0xbdabc8: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xbdabcc: stp             lr, x16, [SP, #-0x10]!
    // 0xbdabd0: r0 = ==()
    //     0xbdabd0: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xbdabd4: add             SP, SP, #0x10
    // 0xbdabd8: tbz             w0, #4, #0xbdacf8
    // 0xbdabdc: ldr             x0, [fp, #0x18]
    // 0xbdabe0: LoadField: r1 = r0->field_2f
    //     0xbdabe0: ldur            w1, [x0, #0x2f]
    // 0xbdabe4: DecompressPointer r1
    //     0xbdabe4: add             x1, x1, HEAP, lsl #32
    // 0xbdabe8: cmp             w1, NULL
    // 0xbdabec: b.eq            #0xbdacf8
    // 0xbdabf0: ldur            x1, [fp, #-8]
    // 0xbdabf4: cmp             w1, NULL
    // 0xbdabf8: b.eq            #0xbdac10
    // 0xbdabfc: SaveReg r1
    //     0xbdabfc: str             x1, [SP, #-8]!
    // 0xbdac00: r0 = tryInvert()
    //     0xbdac00: bl              #0x623294  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0xbdac04: add             SP, SP, #8
    // 0xbdac08: mov             x2, x0
    // 0xbdac0c: b               #0xbdac14
    // 0xbdac10: r2 = Null
    //     0xbdac10: mov             x2, NULL
    // 0xbdac14: ldr             x0, [fp, #0x18]
    // 0xbdac18: ldur            x1, [fp, #-0x18]
    // 0xbdac1c: stur            x2, [fp, #-8]
    // 0xbdac20: LoadField: r3 = r0->field_4f
    //     0xbdac20: ldur            w3, [x0, #0x4f]
    // 0xbdac24: DecompressPointer r3
    //     0xbdac24: add             x3, x3, HEAP, lsl #32
    // 0xbdac28: r16 = Sentinel
    //     0xbdac28: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdac2c: cmp             w3, w16
    // 0xbdac30: b.eq            #0xbdad44
    // 0xbdac34: LoadField: r4 = r3->field_7
    //     0xbdac34: ldur            w4, [x3, #7]
    // 0xbdac38: DecompressPointer r4
    //     0xbdac38: add             x4, x4, HEAP, lsl #32
    // 0xbdac3c: stp             x1, x4, [SP, #-0x10]!
    // 0xbdac40: r0 = +()
    //     0xbdac40: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xbdac44: add             SP, SP, #0x10
    // 0xbdac48: ldur            x16, [fp, #-8]
    // 0xbdac4c: ldur            lr, [fp, #-0x18]
    // 0xbdac50: stp             lr, x16, [SP, #-0x10]!
    // 0xbdac54: SaveReg r0
    //     0xbdac54: str             x0, [SP, #-8]!
    // 0xbdac58: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbdac58: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbdac5c: r0 = transformDeltaViaPositions()
    //     0xbdac5c: bl              #0x5b64a0  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0xbdac60: add             SP, SP, #0x18
    // 0xbdac64: stur            x0, [fp, #-8]
    // 0xbdac68: r0 = OffsetPair()
    //     0xbdac68: bl              #0x7142f0  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xbdac6c: mov             x1, x0
    // 0xbdac70: ldur            x0, [fp, #-0x18]
    // 0xbdac74: StoreField: r1->field_7 = r0
    //     0xbdac74: stur            w0, [x1, #7]
    // 0xbdac78: ldur            x2, [fp, #-8]
    // 0xbdac7c: StoreField: r1->field_b = r2
    //     0xbdac7c: stur            w2, [x1, #0xb]
    // 0xbdac80: ldr             x2, [fp, #0x18]
    // 0xbdac84: LoadField: r3 = r2->field_4f
    //     0xbdac84: ldur            w3, [x2, #0x4f]
    // 0xbdac88: DecompressPointer r3
    //     0xbdac88: add             x3, x3, HEAP, lsl #32
    // 0xbdac8c: stp             x1, x3, [SP, #-0x10]!
    // 0xbdac90: r0 = +()
    //     0xbdac90: bl              #0x714388  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0xbdac94: add             SP, SP, #0x10
    // 0xbdac98: mov             x1, x0
    // 0xbdac9c: ldr             x0, [fp, #0x18]
    // 0xbdaca0: r2 = LoadClassIdInstr(r0)
    //     0xbdaca0: ldur            x2, [x0, #-1]
    //     0xbdaca4: ubfx            x2, x2, #0xc, #0x14
    // 0xbdaca8: lsl             x2, x2, #1
    // 0xbdacac: r17 = 4732
    //     0xbdacac: mov             x17, #0x127c
    // 0xbdacb0: cmp             w2, w17
    // 0xbdacb4: b.ne            #0xbdacc4
    // 0xbdacb8: ldur            x2, [fp, #-0x18]
    // 0xbdacbc: LoadField: d0 = r2->field_7
    //     0xbdacbc: ldur            d0, [x2, #7]
    // 0xbdacc0: b               #0xbdaccc
    // 0xbdacc4: ldur            x2, [fp, #-0x18]
    // 0xbdacc8: LoadField: d0 = r2->field_f
    //     0xbdacc8: ldur            d0, [x2, #0xf]
    // 0xbdaccc: LoadField: r3 = r1->field_b
    //     0xbdaccc: ldur            w3, [x1, #0xb]
    // 0xbdacd0: DecompressPointer r3
    //     0xbdacd0: add             x3, x3, HEAP, lsl #32
    // 0xbdacd4: LoadField: r4 = r1->field_7
    //     0xbdacd4: ldur            w4, [x1, #7]
    // 0xbdacd8: DecompressPointer r4
    //     0xbdacd8: add             x4, x4, HEAP, lsl #32
    // 0xbdacdc: stp             x2, x0, [SP, #-0x10]!
    // 0xbdace0: stp             x4, x3, [SP, #-0x10]!
    // 0xbdace4: SaveReg d0
    //     0xbdace4: str             d0, [SP, #-8]!
    // 0xbdace8: ldur            x16, [fp, #-0x10]
    // 0xbdacec: SaveReg r16
    //     0xbdacec: str             x16, [SP, #-8]!
    // 0xbdacf0: r0 = _checkUpdate()
    //     0xbdacf0: bl              #0x788a50  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_checkUpdate
    // 0xbdacf4: add             SP, SP, #0x30
    // 0xbdacf8: ldr             x16, [fp, #0x18]
    // 0xbdacfc: r30 = Instance_GestureDisposition
    //     0xbdacfc: add             lr, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0xbdad00: ldr             lr, [lr, #0xed0]
    // 0xbdad04: stp             lr, x16, [SP, #-0x10]!
    // 0xbdad08: r0 = resolve()
    //     0xbdad08: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xbdad0c: add             SP, SP, #0x10
    // 0xbdad10: r0 = Null
    //     0xbdad10: mov             x0, NULL
    // 0xbdad14: LeaveFrame
    //     0xbdad14: mov             SP, fp
    //     0xbdad18: ldp             fp, lr, [SP], #0x10
    // 0xbdad1c: ret
    //     0xbdad1c: ret             
    // 0xbdad20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdad20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdad24: b               #0xbdaa44
    // 0xbdad28: r9 = _pendingDragOffset
    //     0xbdad28: add             x9, PP, #0x53, lsl #12  ; [pp+0x537a8] Field <ExtendedDragGestureRecognizer._pendingDragOffset@424469339>: late (offset: 0x54)
    //     0xbdad2c: ldr             x9, [x9, #0x7a8]
    // 0xbdad30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdad30: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbdad34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdad34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbdad38: r9 = _initialPosition
    //     0xbdad38: add             x9, PP, #0x53, lsl #12  ; [pp+0x537d8] Field <ExtendedDragGestureRecognizer._initialPosition@424469339>: late (offset: 0x50)
    //     0xbdad3c: ldr             x9, [x9, #0x7d8]
    // 0xbdad40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdad40: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbdad44: r9 = _initialPosition
    //     0xbdad44: add             x9, PP, #0x53, lsl #12  ; [pp+0x537d8] Field <ExtendedDragGestureRecognizer._initialPosition@424469339>: late (offset: 0x50)
    //     0xbdad48: ldr             x9, [x9, #0x7d8]
    // 0xbdad4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdad4c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _checkStart(/* No info */) {
    // ** addr: 0xbdad50, size: 0x11c
    // 0xbdad50: EnterFrame
    //     0xbdad50: stp             fp, lr, [SP, #-0x10]!
    //     0xbdad54: mov             fp, SP
    // 0xbdad58: AllocStack(0x20)
    //     0xbdad58: sub             SP, SP, #0x20
    // 0xbdad5c: CheckStackOverflow
    //     0xbdad5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdad60: cmp             SP, x16
    //     0xbdad64: b.ls            #0xbdae58
    // 0xbdad68: r1 = 2
    //     0xbdad68: mov             x1, #2
    // 0xbdad6c: r0 = AllocateContext()
    //     0xbdad6c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xbdad70: mov             x1, x0
    // 0xbdad74: ldr             x0, [fp, #0x20]
    // 0xbdad78: stur            x1, [fp, #-0x18]
    // 0xbdad7c: StoreField: r1->field_f = r0
    //     0xbdad7c: stur            w0, [x1, #0xf]
    // 0xbdad80: LoadField: r2 = r0->field_2b
    //     0xbdad80: ldur            w2, [x0, #0x2b]
    // 0xbdad84: DecompressPointer r2
    //     0xbdad84: add             x2, x2, HEAP, lsl #32
    // 0xbdad88: cmp             w2, NULL
    // 0xbdad8c: b.eq            #0xbdae48
    // 0xbdad90: ldr             x3, [fp, #0x18]
    // 0xbdad94: ldr             x2, [fp, #0x10]
    // 0xbdad98: LoadField: r4 = r0->field_4f
    //     0xbdad98: ldur            w4, [x0, #0x4f]
    // 0xbdad9c: DecompressPointer r4
    //     0xbdad9c: add             x4, x4, HEAP, lsl #32
    // 0xbdada0: r16 = Sentinel
    //     0xbdada0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdada4: cmp             w4, w16
    // 0xbdada8: b.eq            #0xbdae60
    // 0xbdadac: LoadField: r5 = r4->field_b
    //     0xbdadac: ldur            w5, [x4, #0xb]
    // 0xbdadb0: DecompressPointer r5
    //     0xbdadb0: add             x5, x5, HEAP, lsl #32
    // 0xbdadb4: stur            x5, [fp, #-0x10]
    // 0xbdadb8: LoadField: r6 = r4->field_7
    //     0xbdadb8: ldur            w6, [x4, #7]
    // 0xbdadbc: DecompressPointer r6
    //     0xbdadbc: add             x6, x6, HEAP, lsl #32
    // 0xbdadc0: stur            x6, [fp, #-8]
    // 0xbdadc4: stp             x2, x0, [SP, #-0x10]!
    // 0xbdadc8: r0 = getKindForPointer()
    //     0xbdadc8: bl              #0x719b14  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xbdadcc: add             SP, SP, #0x10
    // 0xbdadd0: stur            x0, [fp, #-0x20]
    // 0xbdadd4: r0 = DragStartDetails()
    //     0xbdadd4: bl              #0x719b08  ; AllocateDragStartDetailsStub -> DragStartDetails (size=0x18)
    // 0xbdadd8: mov             x1, x0
    // 0xbdaddc: ldr             x0, [fp, #0x18]
    // 0xbdade0: StoreField: r1->field_7 = r0
    //     0xbdade0: stur            w0, [x1, #7]
    // 0xbdade4: ldur            x0, [fp, #-0x10]
    // 0xbdade8: StoreField: r1->field_b = r0
    //     0xbdade8: stur            w0, [x1, #0xb]
    // 0xbdadec: ldur            x0, [fp, #-0x20]
    // 0xbdadf0: StoreField: r1->field_13 = r0
    //     0xbdadf0: stur            w0, [x1, #0x13]
    // 0xbdadf4: ldur            x0, [fp, #-8]
    // 0xbdadf8: StoreField: r1->field_f = r0
    //     0xbdadf8: stur            w0, [x1, #0xf]
    // 0xbdadfc: mov             x0, x1
    // 0xbdae00: ldur            x2, [fp, #-0x18]
    // 0xbdae04: StoreField: r2->field_13 = r0
    //     0xbdae04: stur            w0, [x2, #0x13]
    //     0xbdae08: ldurb           w16, [x2, #-1]
    //     0xbdae0c: ldurb           w17, [x0, #-1]
    //     0xbdae10: and             x16, x17, x16, lsr #2
    //     0xbdae14: tst             x16, HEAP, lsr #32
    //     0xbdae18: b.eq            #0xbdae20
    //     0xbdae1c: bl              #0xd6828c
    // 0xbdae20: r1 = Function '<anonymous closure>':.
    //     0xbdae20: add             x1, PP, #0x53, lsl #12  ; [pp+0x537e0] AnonymousClosure: (0x78ab94), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkUpdate (0x78aac8)
    //     0xbdae24: ldr             x1, [x1, #0x7e0]
    // 0xbdae28: r0 = AllocateClosure()
    //     0xbdae28: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbdae2c: r16 = <void?>
    //     0xbdae2c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xbdae30: ldr             lr, [fp, #0x20]
    // 0xbdae34: stp             lr, x16, [SP, #-0x10]!
    // 0xbdae38: SaveReg r0
    //     0xbdae38: str             x0, [SP, #-8]!
    // 0xbdae3c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbdae3c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbdae40: r0 = invokeCallback()
    //     0xbdae40: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xbdae44: add             SP, SP, #0x18
    // 0xbdae48: r0 = Null
    //     0xbdae48: mov             x0, NULL
    // 0xbdae4c: LeaveFrame
    //     0xbdae4c: mov             SP, fp
    //     0xbdae50: ldp             fp, lr, [SP], #0x10
    // 0xbdae54: ret
    //     0xbdae54: ret             
    // 0xbdae58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdae58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdae5c: b               #0xbdad68
    // 0xbdae60: r9 = _initialPosition
    //     0xbdae60: add             x9, PP, #0x53, lsl #12  ; [pp+0x537d8] Field <ExtendedDragGestureRecognizer._initialPosition@424469339>: late (offset: 0x50)
    //     0xbdae64: ldr             x9, [x9, #0x7d8]
    // 0xbdae68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdae68: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee238, size: 0x44
    // 0xcee238: EnterFrame
    //     0xcee238: stp             fp, lr, [SP, #-0x10]!
    //     0xcee23c: mov             fp, SP
    // 0xcee240: CheckStackOverflow
    //     0xcee240: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee244: cmp             SP, x16
    //     0xcee248: b.ls            #0xcee274
    // 0xcee24c: ldr             x16, [fp, #0x18]
    // 0xcee250: SaveReg r16
    //     0xcee250: str             x16, [SP, #-8]!
    // 0xcee254: ldr             x0, [fp, #0x10]
    // 0xcee258: SaveReg r0
    //     0xcee258: str             x0, [SP, #-8]!
    // 0xcee25c: r0 = _giveUpPointer()
    //     0xcee25c: bl              #0x788b5c  ; [package:extended_image/src/gesture_detector/drag.dart] ExtendedDragGestureRecognizer::_giveUpPointer
    // 0xcee260: add             SP, SP, #0x10
    // 0xcee264: r0 = Null
    //     0xcee264: mov             x0, NULL
    // 0xcee268: LeaveFrame
    //     0xcee268: mov             SP, fp
    //     0xcee26c: ldp             fp, lr, [SP], #0x10
    // 0xcee270: ret
    //     0xcee270: ret             
    // 0xcee274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee274: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee278: b               #0xcee24c
  }
}

// class id: 2366, size: 0x70, field offset: 0x70
class ExtendedHorizontalDragGestureRecognizer extends ExtendedDragGestureRecognizer {

  _ isFlingGesture(/* No info */) {
    // ** addr: 0xcf537c, size: 0x144
    // 0xcf537c: ldr             x1, [SP, #0x10]
    // 0xcf5380: LoadField: r2 = r1->field_3f
    //     0xcf5380: ldur            w2, [x1, #0x3f]
    // 0xcf5384: DecompressPointer r2
    //     0xcf5384: add             x2, x2, HEAP, lsl #32
    // 0xcf5388: cmp             w2, NULL
    // 0xcf538c: b.ne            #0xcf539c
    // 0xcf5390: d0 = 50.000000
    //     0xcf5390: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0xcf5394: ldr             d0, [x17, #0x980]
    // 0xcf5398: b               #0xcf53a0
    // 0xcf539c: LoadField: d0 = r2->field_7
    //     0xcf539c: ldur            d0, [x2, #7]
    // 0xcf53a0: LoadField: r2 = r1->field_3b
    //     0xcf53a0: ldur            w2, [x1, #0x3b]
    // 0xcf53a4: DecompressPointer r2
    //     0xcf53a4: add             x2, x2, HEAP, lsl #32
    // 0xcf53a8: cmp             w2, NULL
    // 0xcf53ac: b.ne            #0xcf5414
    // 0xcf53b0: ldr             x3, [SP]
    // 0xcf53b4: LoadField: r4 = r1->field_7
    //     0xcf53b4: ldur            w4, [x1, #7]
    // 0xcf53b8: DecompressPointer r4
    //     0xcf53b8: add             x4, x4, HEAP, lsl #32
    // 0xcf53bc: LoadField: r1 = r3->field_7
    //     0xcf53bc: ldur            x1, [x3, #7]
    // 0xcf53c0: cmp             x1, #2
    // 0xcf53c4: b.gt            #0xcf53e0
    // 0xcf53c8: cmp             x1, #1
    // 0xcf53cc: b.gt            #0xcf53e0
    // 0xcf53d0: cmp             x1, #0
    // 0xcf53d4: b.le            #0xcf53e0
    // 0xcf53d8: d1 = 1.000000
    //     0xcf53d8: fmov            d1, #1.00000000
    // 0xcf53dc: b               #0xcf540c
    // 0xcf53e0: cmp             w4, NULL
    // 0xcf53e4: b.ne            #0xcf53f0
    // 0xcf53e8: r1 = Null
    //     0xcf53e8: mov             x1, NULL
    // 0xcf53ec: b               #0xcf53f8
    // 0xcf53f0: LoadField: r1 = r4->field_7
    //     0xcf53f0: ldur            w1, [x4, #7]
    // 0xcf53f4: DecompressPointer r1
    //     0xcf53f4: add             x1, x1, HEAP, lsl #32
    // 0xcf53f8: cmp             w1, NULL
    // 0xcf53fc: b.ne            #0xcf5408
    // 0xcf5400: d1 = 18.000000
    //     0xcf5400: fmov            d1, #18.00000000
    // 0xcf5404: b               #0xcf540c
    // 0xcf5408: LoadField: d1 = r1->field_7
    //     0xcf5408: ldur            d1, [x1, #7]
    // 0xcf540c: mov             v2.16b, v1.16b
    // 0xcf5410: b               #0xcf541c
    // 0xcf5414: LoadField: d1 = r2->field_7
    //     0xcf5414: ldur            d1, [x2, #7]
    // 0xcf5418: mov             v2.16b, v1.16b
    // 0xcf541c: ldr             x1, [SP, #8]
    // 0xcf5420: d1 = 0.000000
    //     0xcf5420: eor             v1.16b, v1.16b, v1.16b
    // 0xcf5424: LoadField: r2 = r1->field_7
    //     0xcf5424: ldur            w2, [x1, #7]
    // 0xcf5428: DecompressPointer r2
    //     0xcf5428: add             x2, x2, HEAP, lsl #32
    // 0xcf542c: LoadField: d3 = r2->field_7
    //     0xcf542c: ldur            d3, [x2, #7]
    // 0xcf5430: fcmp            d3, d1
    // 0xcf5434: b.vs            #0xcf5444
    // 0xcf5438: b.ne            #0xcf5444
    // 0xcf543c: d3 = 0.000000
    //     0xcf543c: eor             v3.16b, v3.16b, v3.16b
    // 0xcf5440: b               #0xcf5458
    // 0xcf5444: fcmp            d3, d1
    // 0xcf5448: b.vs            #0xcf5458
    // 0xcf544c: b.ge            #0xcf5458
    // 0xcf5450: fneg            d4, d3
    // 0xcf5454: mov             v3.16b, v4.16b
    // 0xcf5458: fcmp            d3, d0
    // 0xcf545c: b.vs            #0xcf54b8
    // 0xcf5460: b.le            #0xcf54b8
    // 0xcf5464: LoadField: r2 = r1->field_17
    //     0xcf5464: ldur            w2, [x1, #0x17]
    // 0xcf5468: DecompressPointer r2
    //     0xcf5468: add             x2, x2, HEAP, lsl #32
    // 0xcf546c: LoadField: d0 = r2->field_7
    //     0xcf546c: ldur            d0, [x2, #7]
    // 0xcf5470: fcmp            d0, d1
    // 0xcf5474: b.vs            #0xcf5484
    // 0xcf5478: b.ne            #0xcf5484
    // 0xcf547c: d0 = 0.000000
    //     0xcf547c: eor             v0.16b, v0.16b, v0.16b
    // 0xcf5480: b               #0xcf5498
    // 0xcf5484: fcmp            d0, d1
    // 0xcf5488: b.vs            #0xcf5498
    // 0xcf548c: b.ge            #0xcf5498
    // 0xcf5490: fneg            d1, d0
    // 0xcf5494: mov             v0.16b, v1.16b
    // 0xcf5498: fcmp            d0, d2
    // 0xcf549c: b.vs            #0xcf54a4
    // 0xcf54a0: b.gt            #0xcf54ac
    // 0xcf54a4: r1 = false
    //     0xcf54a4: add             x1, NULL, #0x30  ; false
    // 0xcf54a8: b               #0xcf54b0
    // 0xcf54ac: r1 = true
    //     0xcf54ac: add             x1, NULL, #0x20  ; true
    // 0xcf54b0: mov             x0, x1
    // 0xcf54b4: b               #0xcf54bc
    // 0xcf54b8: r0 = false
    //     0xcf54b8: add             x0, NULL, #0x30  ; false
    // 0xcf54bc: ret
    //     0xcf54bc: ret             
  }
}

// class id: 2367, size: 0x70, field offset: 0x70
class ExtendedVerticalDragGestureRecognizer extends ExtendedDragGestureRecognizer {

  _ isFlingGesture(/* No info */) {
    // ** addr: 0xcf5238, size: 0x144
    // 0xcf5238: ldr             x1, [SP, #0x10]
    // 0xcf523c: LoadField: r2 = r1->field_3f
    //     0xcf523c: ldur            w2, [x1, #0x3f]
    // 0xcf5240: DecompressPointer r2
    //     0xcf5240: add             x2, x2, HEAP, lsl #32
    // 0xcf5244: cmp             w2, NULL
    // 0xcf5248: b.ne            #0xcf5258
    // 0xcf524c: d0 = 50.000000
    //     0xcf524c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0xcf5250: ldr             d0, [x17, #0x980]
    // 0xcf5254: b               #0xcf525c
    // 0xcf5258: LoadField: d0 = r2->field_7
    //     0xcf5258: ldur            d0, [x2, #7]
    // 0xcf525c: LoadField: r2 = r1->field_3b
    //     0xcf525c: ldur            w2, [x1, #0x3b]
    // 0xcf5260: DecompressPointer r2
    //     0xcf5260: add             x2, x2, HEAP, lsl #32
    // 0xcf5264: cmp             w2, NULL
    // 0xcf5268: b.ne            #0xcf52d0
    // 0xcf526c: ldr             x3, [SP]
    // 0xcf5270: LoadField: r4 = r1->field_7
    //     0xcf5270: ldur            w4, [x1, #7]
    // 0xcf5274: DecompressPointer r4
    //     0xcf5274: add             x4, x4, HEAP, lsl #32
    // 0xcf5278: LoadField: r1 = r3->field_7
    //     0xcf5278: ldur            x1, [x3, #7]
    // 0xcf527c: cmp             x1, #2
    // 0xcf5280: b.gt            #0xcf529c
    // 0xcf5284: cmp             x1, #1
    // 0xcf5288: b.gt            #0xcf529c
    // 0xcf528c: cmp             x1, #0
    // 0xcf5290: b.le            #0xcf529c
    // 0xcf5294: d1 = 1.000000
    //     0xcf5294: fmov            d1, #1.00000000
    // 0xcf5298: b               #0xcf52c8
    // 0xcf529c: cmp             w4, NULL
    // 0xcf52a0: b.ne            #0xcf52ac
    // 0xcf52a4: r1 = Null
    //     0xcf52a4: mov             x1, NULL
    // 0xcf52a8: b               #0xcf52b4
    // 0xcf52ac: LoadField: r1 = r4->field_7
    //     0xcf52ac: ldur            w1, [x4, #7]
    // 0xcf52b0: DecompressPointer r1
    //     0xcf52b0: add             x1, x1, HEAP, lsl #32
    // 0xcf52b4: cmp             w1, NULL
    // 0xcf52b8: b.ne            #0xcf52c4
    // 0xcf52bc: d1 = 18.000000
    //     0xcf52bc: fmov            d1, #18.00000000
    // 0xcf52c0: b               #0xcf52c8
    // 0xcf52c4: LoadField: d1 = r1->field_7
    //     0xcf52c4: ldur            d1, [x1, #7]
    // 0xcf52c8: mov             v2.16b, v1.16b
    // 0xcf52cc: b               #0xcf52d8
    // 0xcf52d0: LoadField: d1 = r2->field_7
    //     0xcf52d0: ldur            d1, [x2, #7]
    // 0xcf52d4: mov             v2.16b, v1.16b
    // 0xcf52d8: ldr             x1, [SP, #8]
    // 0xcf52dc: d1 = 0.000000
    //     0xcf52dc: eor             v1.16b, v1.16b, v1.16b
    // 0xcf52e0: LoadField: r2 = r1->field_7
    //     0xcf52e0: ldur            w2, [x1, #7]
    // 0xcf52e4: DecompressPointer r2
    //     0xcf52e4: add             x2, x2, HEAP, lsl #32
    // 0xcf52e8: LoadField: d3 = r2->field_f
    //     0xcf52e8: ldur            d3, [x2, #0xf]
    // 0xcf52ec: fcmp            d3, d1
    // 0xcf52f0: b.vs            #0xcf5300
    // 0xcf52f4: b.ne            #0xcf5300
    // 0xcf52f8: d3 = 0.000000
    //     0xcf52f8: eor             v3.16b, v3.16b, v3.16b
    // 0xcf52fc: b               #0xcf5314
    // 0xcf5300: fcmp            d3, d1
    // 0xcf5304: b.vs            #0xcf5314
    // 0xcf5308: b.ge            #0xcf5314
    // 0xcf530c: fneg            d4, d3
    // 0xcf5310: mov             v3.16b, v4.16b
    // 0xcf5314: fcmp            d3, d0
    // 0xcf5318: b.vs            #0xcf5374
    // 0xcf531c: b.le            #0xcf5374
    // 0xcf5320: LoadField: r2 = r1->field_17
    //     0xcf5320: ldur            w2, [x1, #0x17]
    // 0xcf5324: DecompressPointer r2
    //     0xcf5324: add             x2, x2, HEAP, lsl #32
    // 0xcf5328: LoadField: d0 = r2->field_f
    //     0xcf5328: ldur            d0, [x2, #0xf]
    // 0xcf532c: fcmp            d0, d1
    // 0xcf5330: b.vs            #0xcf5340
    // 0xcf5334: b.ne            #0xcf5340
    // 0xcf5338: d0 = 0.000000
    //     0xcf5338: eor             v0.16b, v0.16b, v0.16b
    // 0xcf533c: b               #0xcf5354
    // 0xcf5340: fcmp            d0, d1
    // 0xcf5344: b.vs            #0xcf5354
    // 0xcf5348: b.ge            #0xcf5354
    // 0xcf534c: fneg            d1, d0
    // 0xcf5350: mov             v0.16b, v1.16b
    // 0xcf5354: fcmp            d0, d2
    // 0xcf5358: b.vs            #0xcf5360
    // 0xcf535c: b.gt            #0xcf5368
    // 0xcf5360: r1 = false
    //     0xcf5360: add             x1, NULL, #0x30  ; false
    // 0xcf5364: b               #0xcf536c
    // 0xcf5368: r1 = true
    //     0xcf5368: add             x1, NULL, #0x20  ; true
    // 0xcf536c: mov             x0, x1
    // 0xcf5370: b               #0xcf5378
    // 0xcf5374: r0 = false
    //     0xcf5374: add             x0, NULL, #0x30  ; false
    // 0xcf5378: ret
    //     0xcf5378: ret             
  }
}

// class id: 4477, size: 0x8, field offset: 0x8
abstract class DragGestureRecognizerMixin extends Object {
}

// class id: 5996, size: 0x14, field offset: 0x14
enum _DragState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// lib: , url: package:extended_image/src/image/painting.dart

// class id: 1048942, size: 0x8
class :: {

  static _ paintExtendedImage(/* No info */) {
    // ** addr: 0x654eb4, size: 0x924
    // 0x654eb4: EnterFrame
    //     0x654eb4: stp             fp, lr, [SP, #-0x10]!
    //     0x654eb8: mov             fp, SP
    // 0x654ebc: AllocStack(0x70)
    //     0x654ebc: sub             SP, SP, #0x70
    // 0x654ec0: CheckStackOverflow
    //     0x654ec0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x654ec4: cmp             SP, x16
    //     0x654ec8: b.ls            #0x6556fc
    // 0x654ecc: ldr             x0, [fp, #0x20]
    // 0x654ed0: LoadField: d0 = r0->field_7
    //     0x654ed0: ldur            d0, [x0, #7]
    // 0x654ed4: LoadField: d1 = r0->field_17
    //     0x654ed4: ldur            d1, [x0, #0x17]
    // 0x654ed8: fcmp            d0, d1
    // 0x654edc: b.vs            #0x654ee4
    // 0x654ee0: b.ge            #0x654ef8
    // 0x654ee4: LoadField: d0 = r0->field_f
    //     0x654ee4: ldur            d0, [x0, #0xf]
    // 0x654ee8: LoadField: d1 = r0->field_1f
    //     0x654ee8: ldur            d1, [x0, #0x1f]
    // 0x654eec: fcmp            d0, d1
    // 0x654ef0: b.vs            #0x654f08
    // 0x654ef4: b.lt            #0x654f08
    // 0x654ef8: r0 = Null
    //     0x654ef8: mov             x0, NULL
    // 0x654efc: LeaveFrame
    //     0x654efc: mov             SP, fp
    //     0x654f00: ldp             fp, lr, [SP], #0x10
    // 0x654f04: ret
    //     0x654f04: ret             
    // 0x654f08: ldr             x2, [fp, #0x50]
    // 0x654f0c: ldr             x1, [fp, #0x38]
    // 0x654f10: r16 = Instance_EdgeInsets
    //     0x654f10: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x654f14: ldr             x16, [x16, #0xbd8]
    // 0x654f18: stp             x0, x16, [SP, #-0x10]!
    // 0x654f1c: r0 = deflateRect()
    //     0x654f1c: bl              #0x65ae60  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRect
    // 0x654f20: add             SP, SP, #0x10
    // 0x654f24: stur            x0, [fp, #-8]
    // 0x654f28: SaveReg r0
    //     0x654f28: str             x0, [SP, #-8]!
    // 0x654f2c: r0 = size()
    //     0x654f2c: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0x654f30: add             SP, SP, #8
    // 0x654f34: mov             x3, x0
    // 0x654f38: ldr             x2, [fp, #0x38]
    // 0x654f3c: stur            x3, [fp, #-0x10]
    // 0x654f40: LoadField: r4 = r2->field_f
    //     0x654f40: ldur            x4, [x2, #0xf]
    // 0x654f44: r0 = BoxInt64Instr(r4)
    //     0x654f44: sbfiz           x0, x4, #1, #0x1f
    //     0x654f48: cmp             x4, x0, asr #1
    //     0x654f4c: b.eq            #0x654f58
    //     0x654f50: bl              #0xd69bb8
    //     0x654f54: stur            x4, [x0, #7]
    // 0x654f58: stp             x0, NULL, [SP, #-0x10]!
    // 0x654f5c: r0 = _Double.fromInteger()
    //     0x654f5c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x654f60: add             SP, SP, #0x10
    // 0x654f64: mov             x3, x0
    // 0x654f68: ldr             x2, [fp, #0x38]
    // 0x654f6c: stur            x3, [fp, #-0x18]
    // 0x654f70: LoadField: r4 = r2->field_17
    //     0x654f70: ldur            x4, [x2, #0x17]
    // 0x654f74: r0 = BoxInt64Instr(r4)
    //     0x654f74: sbfiz           x0, x4, #1, #0x1f
    //     0x654f78: cmp             x4, x0, asr #1
    //     0x654f7c: b.eq            #0x654f88
    //     0x654f80: bl              #0xd69bb8
    //     0x654f84: stur            x4, [x0, #7]
    // 0x654f88: stp             x0, NULL, [SP, #-0x10]!
    // 0x654f8c: r0 = _Double.fromInteger()
    //     0x654f8c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x654f90: add             SP, SP, #0x10
    // 0x654f94: mov             x1, x0
    // 0x654f98: ldur            x0, [fp, #-0x18]
    // 0x654f9c: stur            x1, [fp, #-0x20]
    // 0x654fa0: LoadField: d0 = r0->field_7
    //     0x654fa0: ldur            d0, [x0, #7]
    // 0x654fa4: stur            d0, [fp, #-0x60]
    // 0x654fa8: r0 = Size()
    //     0x654fa8: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x654fac: ldur            d0, [fp, #-0x60]
    // 0x654fb0: stur            x0, [fp, #-0x18]
    // 0x654fb4: StoreField: r0->field_7 = d0
    //     0x654fb4: stur            d0, [x0, #7]
    // 0x654fb8: ldur            x1, [fp, #-0x20]
    // 0x654fbc: LoadField: d0 = r1->field_7
    //     0x654fbc: ldur            d0, [x1, #7]
    // 0x654fc0: StoreField: r0->field_f = d0
    //     0x654fc0: stur            d0, [x0, #0xf]
    // 0x654fc4: ldur            x1, [fp, #-8]
    // 0x654fc8: LoadField: d0 = r1->field_7
    //     0x654fc8: ldur            d0, [x1, #7]
    // 0x654fcc: stur            d0, [fp, #-0x68]
    // 0x654fd0: LoadField: d1 = r1->field_f
    //     0x654fd0: ldur            d1, [x1, #0xf]
    // 0x654fd4: stur            d1, [fp, #-0x60]
    // 0x654fd8: r0 = Offset()
    //     0x654fd8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x654fdc: ldur            d0, [fp, #-0x68]
    // 0x654fe0: stur            x0, [fp, #-0x30]
    // 0x654fe4: StoreField: r0->field_7 = d0
    //     0x654fe4: stur            d0, [x0, #7]
    // 0x654fe8: ldur            d1, [fp, #-0x60]
    // 0x654fec: StoreField: r0->field_f = d1
    //     0x654fec: stur            d1, [x0, #0xf]
    // 0x654ff0: ldr             x1, [fp, #0x50]
    // 0x654ff4: cmp             w1, NULL
    // 0x654ff8: b.ne            #0x655008
    // 0x654ffc: r5 = Instance_BoxFit
    //     0x654ffc: add             x5, PP, #0x21, lsl #12  ; [pp+0x21cc8] Obj!BoxFit@b64df1
    //     0x655000: ldr             x5, [x5, #0xcc8]
    // 0x655004: b               #0x65500c
    // 0x655008: mov             x5, x1
    // 0x65500c: ldr             x4, [fp, #0x48]
    // 0x655010: ldr             x3, [fp, #0x30]
    // 0x655014: ldr             x2, [fp, #0x28]
    // 0x655018: ldr             d1, [fp, #0x10]
    // 0x65501c: ldur            x1, [fp, #-0x10]
    // 0x655020: stur            x5, [fp, #-0x28]
    // 0x655024: r6 = inline_Allocate_Double()
    //     0x655024: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0x655028: add             x6, x6, #0x10
    //     0x65502c: cmp             x7, x6
    //     0x655030: b.ls            #0x655704
    //     0x655034: str             x6, [THR, #0x60]  ; THR::top
    //     0x655038: sub             x6, x6, #0xf
    //     0x65503c: mov             x7, #0xd108
    //     0x655040: movk            x7, #3, lsl #16
    //     0x655044: stur            x7, [x6, #-1]
    // 0x655048: StoreField: r6->field_7 = d1
    //     0x655048: stur            d1, [x6, #7]
    // 0x65504c: stur            x6, [fp, #-0x20]
    // 0x655050: ldur            x16, [fp, #-0x18]
    // 0x655054: stp             x6, x16, [SP, #-0x10]!
    // 0x655058: r0 = /()
    //     0x655058: bl              #0x50e098  ; [dart:ui] Size::/
    // 0x65505c: add             SP, SP, #0x10
    // 0x655060: ldur            x16, [fp, #-0x28]
    // 0x655064: stp             x0, x16, [SP, #-0x10]!
    // 0x655068: ldur            x16, [fp, #-0x10]
    // 0x65506c: SaveReg r16
    //     0x65506c: str             x16, [SP, #-8]!
    // 0x655070: r0 = applyBoxFit()
    //     0x655070: bl              #0x626a14  ; [package:flutter/src/painting/box_fit.dart] ::applyBoxFit
    // 0x655074: add             SP, SP, #0x18
    // 0x655078: stur            x0, [fp, #-0x38]
    // 0x65507c: LoadField: r1 = r0->field_7
    //     0x65507c: ldur            w1, [x0, #7]
    // 0x655080: DecompressPointer r1
    //     0x655080: add             x1, x1, HEAP, lsl #32
    // 0x655084: ldur            x16, [fp, #-0x20]
    // 0x655088: stp             x16, x1, [SP, #-0x10]!
    // 0x65508c: r0 = *()
    //     0x65508c: bl              #0x50e17c  ; [dart:ui] Size::*
    // 0x655090: add             SP, SP, #0x10
    // 0x655094: mov             x1, x0
    // 0x655098: ldur            x0, [fp, #-0x38]
    // 0x65509c: stur            x1, [fp, #-0x48]
    // 0x6550a0: LoadField: r2 = r0->field_b
    //     0x6550a0: ldur            w2, [x0, #0xb]
    // 0x6550a4: DecompressPointer r2
    //     0x6550a4: add             x2, x2, HEAP, lsl #32
    // 0x6550a8: stur            x2, [fp, #-0x40]
    // 0x6550ac: r16 = 112
    //     0x6550ac: mov             x16, #0x70
    // 0x6550b0: stp             x16, NULL, [SP, #-0x10]!
    // 0x6550b4: r0 = ByteData()
    //     0x6550b4: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x6550b8: add             SP, SP, #0x10
    // 0x6550bc: stur            x0, [fp, #-0x38]
    // 0x6550c0: r0 = Paint()
    //     0x6550c0: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6550c4: mov             x1, x0
    // 0x6550c8: ldur            x0, [fp, #-0x38]
    // 0x6550cc: stur            x1, [fp, #-0x58]
    // 0x6550d0: StoreField: r1->field_7 = r0
    //     0x6550d0: stur            w0, [x1, #7]
    // 0x6550d4: LoadField: r2 = r0->field_17
    //     0x6550d4: ldur            w2, [x0, #0x17]
    // 0x6550d8: DecompressPointer r2
    //     0x6550d8: add             x2, x2, HEAP, lsl #32
    // 0x6550dc: stur            x2, [fp, #-0x50]
    // 0x6550e0: LoadField: r0 = r2->field_7
    //     0x6550e0: ldur            x0, [x2, #7]
    // 0x6550e4: r3 = 1
    //     0x6550e4: mov             x3, #1
    // 0x6550e8: str             w3, [x0]
    // 0x6550ec: ldr             x0, [fp, #0x28]
    // 0x6550f0: LoadField: d0 = r0->field_7
    //     0x6550f0: ldur            d0, [x0, #7]
    // 0x6550f4: d1 = 255.000000
    //     0x6550f4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0x6550f8: ldr             d1, [x17, #0x200]
    // 0x6550fc: fmul            d2, d0, d1
    // 0x655100: r0 = inline_Allocate_Double()
    //     0x655100: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x655104: add             x0, x0, #0x10
    //     0x655108: cmp             x4, x0
    //     0x65510c: b.ls            #0x655730
    //     0x655110: str             x0, [THR, #0x60]  ; THR::top
    //     0x655114: sub             x0, x0, #0xf
    //     0x655118: mov             x4, #0xd108
    //     0x65511c: movk            x4, #3, lsl #16
    //     0x655120: stur            x4, [x0, #-1]
    // 0x655124: StoreField: r0->field_7 = d2
    //     0x655124: stur            d2, [x0, #7]
    // 0x655128: r16 = 2
    //     0x655128: mov             x16, #2
    // 0x65512c: stp             x16, x0, [SP, #-0x10]!
    // 0x655130: r0 = ~/()
    //     0x655130: bl              #0x65adc0  ; [dart:core] _Double::~/
    // 0x655134: add             SP, SP, #0x10
    // 0x655138: r1 = LoadInt32Instr(r0)
    //     0x655138: sbfx            x1, x0, #1, #0x1f
    //     0x65513c: tbz             w0, #0, #0x655144
    //     0x655140: ldur            x1, [x0, #7]
    // 0x655144: r0 = 255
    //     0x655144: mov             x0, #0xff
    // 0x655148: and             x2, x1, x0
    // 0x65514c: lsl             w0, w2, #0x18
    // 0x655150: ubfx            x0, x0, #0, #0x20
    // 0x655154: eor             x1, x0, #0xff000000
    // 0x655158: sxtw            x1, w1
    // 0x65515c: ldur            x0, [fp, #-0x50]
    // 0x655160: LoadField: r2 = r0->field_7
    //     0x655160: ldur            x2, [x0, #7]
    // 0x655164: str             w1, [x2, #4]
    // 0x655168: LoadField: r1 = r0->field_7
    //     0x655168: ldur            x1, [x0, #7]
    // 0x65516c: r2 = 1
    //     0x65516c: mov             x2, #1
    // 0x655170: str             w2, [x1, #0x20]
    // 0x655174: ldr             x1, [fp, #0x30]
    // 0x655178: tst             x1, #0x10
    // 0x65517c: cset            x2, eq
    // 0x655180: lsl             x2, x2, #1
    // 0x655184: r1 = LoadInt32Instr(r2)
    //     0x655184: sbfx            x1, x2, #1, #0x1f
    // 0x655188: LoadField: r2 = r0->field_7
    //     0x655188: ldur            x2, [x0, #7]
    // 0x65518c: str             w1, [x2, #0x30]
    // 0x655190: ldur            x0, [fp, #-0x10]
    // 0x655194: LoadField: d0 = r0->field_7
    //     0x655194: ldur            d0, [x0, #7]
    // 0x655198: ldur            x1, [fp, #-0x40]
    // 0x65519c: LoadField: d1 = r1->field_7
    //     0x65519c: ldur            d1, [x1, #7]
    // 0x6551a0: fsub            d2, d0, d1
    // 0x6551a4: d0 = 2.000000
    //     0x6551a4: fmov            d0, #2.00000000
    // 0x6551a8: fdiv            d1, d2, d0
    // 0x6551ac: LoadField: d2 = r0->field_f
    //     0x6551ac: ldur            d2, [x0, #0xf]
    // 0x6551b0: LoadField: d3 = r1->field_f
    //     0x6551b0: ldur            d3, [x1, #0xf]
    // 0x6551b4: fsub            d4, d2, d3
    // 0x6551b8: fdiv            d2, d4, d0
    // 0x6551bc: ldr             x0, [fp, #0x48]
    // 0x6551c0: tbnz            w0, #4, #0x6551dc
    // 0x6551c4: r2 = Instance_Alignment
    //     0x6551c4: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6551c8: ldr             x2, [x2, #0xc70]
    // 0x6551cc: LoadField: d3 = r2->field_7
    //     0x6551cc: ldur            d3, [x2, #7]
    // 0x6551d0: fneg            d4, d3
    // 0x6551d4: mov             v3.16b, v4.16b
    // 0x6551d8: b               #0x6551e8
    // 0x6551dc: r2 = Instance_Alignment
    //     0x6551dc: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6551e0: ldr             x2, [x2, #0xc70]
    // 0x6551e4: LoadField: d3 = r2->field_7
    //     0x6551e4: ldur            d3, [x2, #7]
    // 0x6551e8: ldr             x3, [fp, #0x40]
    // 0x6551ec: fmul            d4, d3, d1
    // 0x6551f0: fadd            d3, d1, d4
    // 0x6551f4: LoadField: d1 = r2->field_f
    //     0x6551f4: ldur            d1, [x2, #0xf]
    // 0x6551f8: fmul            d4, d1, d2
    // 0x6551fc: fadd            d1, d2, d4
    // 0x655200: r2 = inline_Allocate_Double()
    //     0x655200: ldp             x2, x4, [THR, #0x60]  ; THR::top
    //     0x655204: add             x2, x2, #0x10
    //     0x655208: cmp             x4, x2
    //     0x65520c: b.ls            #0x655750
    //     0x655210: str             x2, [THR, #0x60]  ; THR::top
    //     0x655214: sub             x2, x2, #0xf
    //     0x655218: mov             x4, #0xd108
    //     0x65521c: movk            x4, #3, lsl #16
    //     0x655220: stur            x4, [x2, #-1]
    // 0x655224: StoreField: r2->field_7 = d3
    //     0x655224: stur            d3, [x2, #7]
    // 0x655228: ldur            x16, [fp, #-0x30]
    // 0x65522c: stp             x2, x16, [SP, #-0x10]!
    // 0x655230: SaveReg d1
    //     0x655230: str             d1, [SP, #-8]!
    // 0x655234: r0 = translate()
    //     0x655234: bl              #0x65ad6c  ; [dart:ui] Offset::translate
    // 0x655238: add             SP, SP, #0x18
    // 0x65523c: ldur            x16, [fp, #-0x40]
    // 0x655240: stp             x16, x0, [SP, #-0x10]!
    // 0x655244: r0 = &()
    //     0x655244: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x655248: add             SP, SP, #0x10
    // 0x65524c: mov             x1, x0
    // 0x655250: ldr             x0, [fp, #0x40]
    // 0x655254: cmp             w0, NULL
    // 0x655258: b.eq            #0x6552c0
    // 0x65525c: ldur            x16, [fp, #-8]
    // 0x655260: stp             x16, x0, [SP, #-0x10]!
    // 0x655264: SaveReg r1
    //     0x655264: str             x1, [SP, #-8]!
    // 0x655268: r0 = calculateFinalDestinationRect()
    //     0x655268: bl              #0x65999c  ; [package:extended_image/src/gesture/utils.dart] GestureDetails::calculateFinalDestinationRect
    // 0x65526c: add             SP, SP, #0x18
    // 0x655270: stur            x0, [fp, #-0x10]
    // 0x655274: ldur            x16, [fp, #-8]
    // 0x655278: stp             x0, x16, [SP, #-0x10]!
    // 0x65527c: r0 = RectExtension.beyond()
    //     0x65527c: bl              #0x659734  ; [package:extended_image/src/utils.dart] ::RectExtension.beyond
    // 0x655280: add             SP, SP, #0x10
    // 0x655284: stur            x0, [fp, #-0x30]
    // 0x655288: tbnz            w0, #4, #0x6552b4
    // 0x65528c: ldr             x16, [fp, #0x60]
    // 0x655290: SaveReg r16
    //     0x655290: str             x16, [SP, #-8]!
    // 0x655294: r0 = save()
    //     0x655294: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0x655298: add             SP, SP, #8
    // 0x65529c: ldr             x16, [fp, #0x60]
    // 0x6552a0: ldr             lr, [fp, #0x20]
    // 0x6552a4: stp             lr, x16, [SP, #-0x10]!
    // 0x6552a8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6552a8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6552ac: r0 = clipRect()
    //     0x6552ac: bl              #0x6590f4  ; [dart:ui] Canvas::clipRect
    // 0x6552b0: add             SP, SP, #0x10
    // 0x6552b4: ldur            x2, [fp, #-0x10]
    // 0x6552b8: ldur            x1, [fp, #-0x30]
    // 0x6552bc: b               #0x6552c8
    // 0x6552c0: mov             x2, x1
    // 0x6552c4: r1 = false
    //     0x6552c4: add             x1, NULL, #0x30  ; false
    // 0x6552c8: ldr             x0, [fp, #0x58]
    // 0x6552cc: cmp             w0, NULL
    // 0x6552d0: b.eq            #0x65553c
    // 0x6552d4: LoadField: r1 = r0->field_47
    //     0x6552d4: ldur            w1, [x0, #0x47]
    // 0x6552d8: DecompressPointer r1
    //     0x6552d8: add             x1, x1, HEAP, lsl #32
    // 0x6552dc: cmp             w1, NULL
    // 0x6552e0: b.eq            #0x65531c
    // 0x6552e4: ldur            x16, [fp, #-8]
    // 0x6552e8: stp             x16, x1, [SP, #-0x10]!
    // 0x6552ec: r0 = deflateRect()
    //     0x6552ec: bl              #0x65ae60  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRect
    // 0x6552f0: add             SP, SP, #0x10
    // 0x6552f4: ldur            x16, [fp, #-0x28]
    // 0x6552f8: ldur            lr, [fp, #-0x18]
    // 0x6552fc: stp             lr, x16, [SP, #-0x10]!
    // 0x655300: ldur            x16, [fp, #-0x20]
    // 0x655304: stp             x16, x0, [SP, #-0x10]!
    // 0x655308: r4 = const [0, 0x4, 0x4, 0x3, scale, 0x3, null]
    //     0x655308: add             x4, PP, #0x38, lsl #12  ; [pp+0x38478] List(7) [0, 0x4, 0x4, 0x3, "scale", 0x3, Null]
    //     0x65530c: ldr             x4, [x4, #0x478]
    // 0x655310: r0 = getDestinationRect()
    //     0x655310: bl              #0x658e94  ; [package:extended_image/src/editor/editor_utils.dart] ::getDestinationRect
    // 0x655314: add             SP, SP, #0x20
    // 0x655318: b               #0x655320
    // 0x65531c: mov             x0, x2
    // 0x655320: ldr             x16, [fp, #0x58]
    // 0x655324: ldur            lr, [fp, #-8]
    // 0x655328: stp             lr, x16, [SP, #-0x10]!
    // 0x65532c: SaveReg r0
    //     0x65532c: str             x0, [SP, #-8]!
    // 0x655330: r0 = initRect()
    //     0x655330: bl              #0x658dac  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::initRect
    // 0x655334: add             SP, SP, #0x18
    // 0x655338: ldr             x16, [fp, #0x58]
    // 0x65533c: SaveReg r16
    //     0x65533c: str             x16, [SP, #-8]!
    // 0x655340: r0 = getFinalDestinationRect()
    //     0x655340: bl              #0x6576a8  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::getFinalDestinationRect
    // 0x655344: add             SP, SP, #8
    // 0x655348: stur            x0, [fp, #-0x10]
    // 0x65534c: ldur            x16, [fp, #-8]
    // 0x655350: stp             x0, x16, [SP, #-0x10]!
    // 0x655354: r0 = RectExtension.beyond()
    //     0x655354: bl              #0x659734  ; [package:extended_image/src/utils.dart] ::RectExtension.beyond
    // 0x655358: add             SP, SP, #0x10
    // 0x65535c: stur            x0, [fp, #-0x20]
    // 0x655360: ldr             x16, [fp, #0x58]
    // 0x655364: SaveReg r16
    //     0x655364: str             x16, [SP, #-8]!
    // 0x655368: r0 = hasEditAction()
    //     0x655368: bl              #0x657634  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::hasEditAction
    // 0x65536c: add             SP, SP, #8
    // 0x655370: mov             x1, x0
    // 0x655374: ldur            x0, [fp, #-0x20]
    // 0x655378: stur            x1, [fp, #-0x28]
    // 0x65537c: tbz             w0, #4, #0x655384
    // 0x655380: tbnz            w1, #4, #0x6553b4
    // 0x655384: ldr             x16, [fp, #0x60]
    // 0x655388: SaveReg r16
    //     0x655388: str             x16, [SP, #-8]!
    // 0x65538c: r0 = save()
    //     0x65538c: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0x655390: add             SP, SP, #8
    // 0x655394: ldur            x0, [fp, #-0x20]
    // 0x655398: tbnz            w0, #4, #0x6553b4
    // 0x65539c: ldr             x16, [fp, #0x60]
    // 0x6553a0: ldr             lr, [fp, #0x20]
    // 0x6553a4: stp             lr, x16, [SP, #-0x10]!
    // 0x6553a8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6553a8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6553ac: r0 = clipRect()
    //     0x6553ac: bl              #0x6590f4  ; [dart:ui] Canvas::clipRect
    // 0x6553b0: add             SP, SP, #0x10
    // 0x6553b4: ldur            x0, [fp, #-0x28]
    // 0x6553b8: tbnz            w0, #4, #0x655528
    // 0x6553bc: ldr             x16, [fp, #0x58]
    // 0x6553c0: SaveReg r16
    //     0x6553c0: str             x16, [SP, #-8]!
    // 0x6553c4: r0 = screenCropRect()
    //     0x6553c4: bl              #0x657568  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::screenCropRect
    // 0x6553c8: add             SP, SP, #8
    // 0x6553cc: cmp             w0, NULL
    // 0x6553d0: b.ne            #0x6553dc
    // 0x6553d4: r0 = Null
    //     0x6553d4: mov             x0, NULL
    // 0x6553d8: b               #0x6553e8
    // 0x6553dc: SaveReg r0
    //     0x6553dc: str             x0, [SP, #-8]!
    // 0x6553e0: r0 = center()
    //     0x6553e0: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x6553e4: add             SP, SP, #8
    // 0x6553e8: cmp             w0, NULL
    // 0x6553ec: b.ne            #0x655400
    // 0x6553f0: ldur            x16, [fp, #-0x10]
    // 0x6553f4: SaveReg r16
    //     0x6553f4: str             x16, [SP, #-8]!
    // 0x6553f8: r0 = center()
    //     0x6553f8: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x6553fc: add             SP, SP, #8
    // 0x655400: stur            x0, [fp, #-0x30]
    // 0x655404: r0 = Matrix4()
    //     0x655404: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x655408: r4 = 32
    //     0x655408: mov             x4, #0x20
    // 0x65540c: stur            x0, [fp, #-0x38]
    // 0x655410: r0 = AllocateFloat64Array()
    //     0x655410: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x655414: mov             x1, x0
    // 0x655418: ldur            x0, [fp, #-0x38]
    // 0x65541c: stur            x1, [fp, #-0x40]
    // 0x655420: StoreField: r0->field_7 = r1
    //     0x655420: stur            w1, [x0, #7]
    // 0x655424: SaveReg r0
    //     0x655424: str             x0, [SP, #-8]!
    // 0x655428: r0 = setIdentity()
    //     0x655428: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x65542c: add             SP, SP, #8
    // 0x655430: ldur            x0, [fp, #-0x30]
    // 0x655434: LoadField: d0 = r0->field_7
    //     0x655434: ldur            d0, [x0, #7]
    // 0x655438: stur            d0, [fp, #-0x70]
    // 0x65543c: LoadField: d1 = r0->field_f
    //     0x65543c: ldur            d1, [x0, #0xf]
    // 0x655440: stur            d1, [fp, #-0x60]
    // 0x655444: r0 = inline_Allocate_Double()
    //     0x655444: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x655448: add             x0, x0, #0x10
    //     0x65544c: cmp             x1, x0
    //     0x655450: b.ls            #0x65577c
    //     0x655454: str             x0, [THR, #0x60]  ; THR::top
    //     0x655458: sub             x0, x0, #0xf
    //     0x65545c: mov             x1, #0xd108
    //     0x655460: movk            x1, #3, lsl #16
    //     0x655464: stur            x1, [x0, #-1]
    // 0x655468: StoreField: r0->field_7 = d0
    //     0x655468: stur            d0, [x0, #7]
    // 0x65546c: ldur            x16, [fp, #-0x38]
    // 0x655470: stp             x0, x16, [SP, #-0x10]!
    // 0x655474: SaveReg d1
    //     0x655474: str             d1, [SP, #-8]!
    // 0x655478: r0 = translate()
    //     0x655478: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x65547c: add             SP, SP, #0x18
    // 0x655480: ldr             x16, [fp, #0x58]
    // 0x655484: SaveReg r16
    //     0x655484: str             x16, [SP, #-8]!
    // 0x655488: r0 = hasRotateAngle()
    //     0x655488: bl              #0x6574f8  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::hasRotateAngle
    // 0x65548c: add             SP, SP, #8
    // 0x655490: tbnz            w0, #4, #0x6554b0
    // 0x655494: SaveReg rNULL
    //     0x655494: str             NULL, [SP, #-8]!
    // 0x655498: r0 = Matrix4.rotationZ()
    //     0x655498: bl              #0x6572e8  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.rotationZ
    // 0x65549c: add             SP, SP, #8
    // 0x6554a0: ldur            x16, [fp, #-0x38]
    // 0x6554a4: stp             x0, x16, [SP, #-0x10]!
    // 0x6554a8: r0 = multiply()
    //     0x6554a8: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x6554ac: add             SP, SP, #0x10
    // 0x6554b0: ldur            d0, [fp, #-0x70]
    // 0x6554b4: ldur            d1, [fp, #-0x60]
    // 0x6554b8: fneg            d2, d0
    // 0x6554bc: fneg            d0, d1
    // 0x6554c0: r0 = inline_Allocate_Double()
    //     0x6554c0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6554c4: add             x0, x0, #0x10
    //     0x6554c8: cmp             x1, x0
    //     0x6554cc: b.ls            #0x65578c
    //     0x6554d0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6554d4: sub             x0, x0, #0xf
    //     0x6554d8: mov             x1, #0xd108
    //     0x6554dc: movk            x1, #3, lsl #16
    //     0x6554e0: stur            x1, [x0, #-1]
    // 0x6554e4: StoreField: r0->field_7 = d2
    //     0x6554e4: stur            d2, [x0, #7]
    // 0x6554e8: ldur            x16, [fp, #-0x38]
    // 0x6554ec: stp             x0, x16, [SP, #-0x10]!
    // 0x6554f0: SaveReg d0
    //     0x6554f0: str             d0, [SP, #-8]!
    // 0x6554f4: r0 = translate()
    //     0x6554f4: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x6554f8: add             SP, SP, #0x18
    // 0x6554fc: ldr             x16, [fp, #0x60]
    // 0x655500: ldur            lr, [fp, #-0x40]
    // 0x655504: stp             lr, x16, [SP, #-0x10]!
    // 0x655508: r0 = transform()
    //     0x655508: bl              #0x656f48  ; [dart:ui] Canvas::transform
    // 0x65550c: add             SP, SP, #0x10
    // 0x655510: ldr             x16, [fp, #0x58]
    // 0x655514: ldur            lr, [fp, #-0x10]
    // 0x655518: stp             lr, x16, [SP, #-0x10]!
    // 0x65551c: r0 = paintRect()
    //     0x65551c: bl              #0x6568a4  ; [package:extended_image/src/editor/editor_utils.dart] EditActionDetails::paintRect
    // 0x655520: add             SP, SP, #0x10
    // 0x655524: b               #0x65552c
    // 0x655528: ldur            x0, [fp, #-0x10]
    // 0x65552c: mov             x3, x0
    // 0x655530: ldur            x2, [fp, #-0x20]
    // 0x655534: ldur            x1, [fp, #-0x28]
    // 0x655538: b               #0x655548
    // 0x65553c: mov             x3, x2
    // 0x655540: mov             x2, x1
    // 0x655544: r1 = false
    //     0x655544: add             x1, NULL, #0x30  ; false
    // 0x655548: ldr             x0, [fp, #0x48]
    // 0x65554c: stur            x3, [fp, #-0x10]
    // 0x655550: stur            x2, [fp, #-0x20]
    // 0x655554: stur            x1, [fp, #-0x28]
    // 0x655558: tbnz            w0, #4, #0x65556c
    // 0x65555c: ldr             x16, [fp, #0x60]
    // 0x655560: SaveReg r16
    //     0x655560: str             x16, [SP, #-8]!
    // 0x655564: r0 = save()
    //     0x655564: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0x655568: add             SP, SP, #8
    // 0x65556c: ldr             x0, [fp, #0x48]
    // 0x655570: tbnz            w0, #4, #0x65565c
    // 0x655574: ldur            x1, [fp, #-8]
    // 0x655578: ldur            d1, [fp, #-0x68]
    // 0x65557c: d0 = 2.000000
    //     0x65557c: fmov            d0, #2.00000000
    // 0x655580: LoadField: d2 = r1->field_17
    //     0x655580: ldur            d2, [x1, #0x17]
    // 0x655584: fsub            d3, d2, d1
    // 0x655588: fdiv            d2, d3, d0
    // 0x65558c: fadd            d0, d1, d2
    // 0x655590: fneg            d1, d0
    // 0x655594: stur            d1, [fp, #-0x60]
    // 0x655598: fneg            d0, d1
    // 0x65559c: r1 = inline_Allocate_Double()
    //     0x65559c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6555a0: add             x1, x1, #0x10
    //     0x6555a4: cmp             x2, x1
    //     0x6555a8: b.ls            #0x65579c
    //     0x6555ac: str             x1, [THR, #0x60]  ; THR::top
    //     0x6555b0: sub             x1, x1, #0xf
    //     0x6555b4: mov             x2, #0xd108
    //     0x6555b8: movk            x2, #3, lsl #16
    //     0x6555bc: stur            x2, [x1, #-1]
    // 0x6555c0: StoreField: r1->field_7 = d0
    //     0x6555c0: stur            d0, [x1, #7]
    // 0x6555c4: ldr             x16, [fp, #0x60]
    // 0x6555c8: stp             x1, x16, [SP, #-0x10]!
    // 0x6555cc: SaveReg rZR
    //     0x6555cc: str             xzr, [SP, #-8]!
    // 0x6555d0: r0 = translate()
    //     0x6555d0: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0x6555d4: add             SP, SP, #0x18
    // 0x6555d8: d0 = 1.000000
    //     0x6555d8: fmov            d0, #1.00000000
    // 0x6555dc: fneg            d1, d0
    // 0x6555e0: r0 = inline_Allocate_Double()
    //     0x6555e0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6555e4: add             x0, x0, #0x10
    //     0x6555e8: cmp             x1, x0
    //     0x6555ec: b.ls            #0x6557b8
    //     0x6555f0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6555f4: sub             x0, x0, #0xf
    //     0x6555f8: mov             x1, #0xd108
    //     0x6555fc: movk            x1, #3, lsl #16
    //     0x655600: stur            x1, [x0, #-1]
    // 0x655604: StoreField: r0->field_7 = d1
    //     0x655604: stur            d1, [x0, #7]
    // 0x655608: ldr             x16, [fp, #0x60]
    // 0x65560c: stp             x0, x16, [SP, #-0x10]!
    // 0x655610: SaveReg d0
    //     0x655610: str             d0, [SP, #-8]!
    // 0x655614: r0 = _scale()
    //     0x655614: bl              #0x656458  ; [dart:ui] Canvas::_scale
    // 0x655618: add             SP, SP, #0x18
    // 0x65561c: ldur            d0, [fp, #-0x60]
    // 0x655620: r0 = inline_Allocate_Double()
    //     0x655620: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x655624: add             x0, x0, #0x10
    //     0x655628: cmp             x1, x0
    //     0x65562c: b.ls            #0x6557c8
    //     0x655630: str             x0, [THR, #0x60]  ; THR::top
    //     0x655634: sub             x0, x0, #0xf
    //     0x655638: mov             x1, #0xd108
    //     0x65563c: movk            x1, #3, lsl #16
    //     0x655640: stur            x1, [x0, #-1]
    // 0x655644: StoreField: r0->field_7 = d0
    //     0x655644: stur            d0, [x0, #7]
    // 0x655648: ldr             x16, [fp, #0x60]
    // 0x65564c: stp             x0, x16, [SP, #-0x10]!
    // 0x655650: SaveReg rZR
    //     0x655650: str             xzr, [SP, #-8]!
    // 0x655654: r0 = translate()
    //     0x655654: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0x655658: add             SP, SP, #0x18
    // 0x65565c: ldr             x0, [fp, #0x48]
    // 0x655660: r16 = Instance_Offset
    //     0x655660: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x655664: ldur            lr, [fp, #-0x18]
    // 0x655668: stp             lr, x16, [SP, #-0x10]!
    // 0x65566c: r0 = &()
    //     0x65566c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x655670: add             SP, SP, #0x10
    // 0x655674: r16 = Instance_Alignment
    //     0x655674: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x655678: ldr             x16, [x16, #0xc70]
    // 0x65567c: ldur            lr, [fp, #-0x48]
    // 0x655680: stp             lr, x16, [SP, #-0x10]!
    // 0x655684: SaveReg r0
    //     0x655684: str             x0, [SP, #-8]!
    // 0x655688: r0 = inscribe()
    //     0x655688: bl              #0x626960  ; [package:flutter/src/painting/alignment.dart] Alignment::inscribe
    // 0x65568c: add             SP, SP, #0x18
    // 0x655690: ldr             x16, [fp, #0x60]
    // 0x655694: ldr             lr, [fp, #0x38]
    // 0x655698: stp             lr, x16, [SP, #-0x10]!
    // 0x65569c: ldur            x16, [fp, #-0x10]
    // 0x6556a0: stp             x16, x0, [SP, #-0x10]!
    // 0x6556a4: ldur            x16, [fp, #-0x58]
    // 0x6556a8: SaveReg r16
    //     0x6556a8: str             x16, [SP, #-8]!
    // 0x6556ac: r0 = drawImageRect()
    //     0x6556ac: bl              #0x655a70  ; [dart:ui] Canvas::drawImageRect
    // 0x6556b0: add             SP, SP, #0x28
    // 0x6556b4: ldr             x0, [fp, #0x48]
    // 0x6556b8: tbnz            w0, #4, #0x6556cc
    // 0x6556bc: ldr             x16, [fp, #0x60]
    // 0x6556c0: SaveReg r16
    //     0x6556c0: str             x16, [SP, #-8]!
    // 0x6556c4: r0 = restore()
    //     0x6556c4: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0x6556c8: add             SP, SP, #8
    // 0x6556cc: ldur            x0, [fp, #-0x20]
    // 0x6556d0: tbz             w0, #4, #0x6556dc
    // 0x6556d4: ldur            x0, [fp, #-0x28]
    // 0x6556d8: tbnz            w0, #4, #0x6556ec
    // 0x6556dc: ldr             x16, [fp, #0x60]
    // 0x6556e0: SaveReg r16
    //     0x6556e0: str             x16, [SP, #-8]!
    // 0x6556e4: r0 = restore()
    //     0x6556e4: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0x6556e8: add             SP, SP, #8
    // 0x6556ec: r0 = Null
    //     0x6556ec: mov             x0, NULL
    // 0x6556f0: LeaveFrame
    //     0x6556f0: mov             SP, fp
    //     0x6556f4: ldp             fp, lr, [SP], #0x10
    // 0x6556f8: ret
    //     0x6556f8: ret             
    // 0x6556fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6556fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x655700: b               #0x654ecc
    // 0x655704: stp             q0, q1, [SP, #-0x20]!
    // 0x655708: stp             x4, x5, [SP, #-0x10]!
    // 0x65570c: stp             x2, x3, [SP, #-0x10]!
    // 0x655710: stp             x0, x1, [SP, #-0x10]!
    // 0x655714: r0 = AllocateDouble()
    //     0x655714: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x655718: mov             x6, x0
    // 0x65571c: ldp             x0, x1, [SP], #0x10
    // 0x655720: ldp             x2, x3, [SP], #0x10
    // 0x655724: ldp             x4, x5, [SP], #0x10
    // 0x655728: ldp             q0, q1, [SP], #0x20
    // 0x65572c: b               #0x655048
    // 0x655730: SaveReg d2
    //     0x655730: str             q2, [SP, #-0x10]!
    // 0x655734: stp             x2, x3, [SP, #-0x10]!
    // 0x655738: SaveReg r1
    //     0x655738: str             x1, [SP, #-8]!
    // 0x65573c: r0 = AllocateDouble()
    //     0x65573c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x655740: RestoreReg r1
    //     0x655740: ldr             x1, [SP], #8
    // 0x655744: ldp             x2, x3, [SP], #0x10
    // 0x655748: RestoreReg d2
    //     0x655748: ldr             q2, [SP], #0x10
    // 0x65574c: b               #0x655124
    // 0x655750: stp             q1, q3, [SP, #-0x20]!
    // 0x655754: SaveReg d0
    //     0x655754: str             q0, [SP, #-0x10]!
    // 0x655758: stp             x1, x3, [SP, #-0x10]!
    // 0x65575c: SaveReg r0
    //     0x65575c: str             x0, [SP, #-8]!
    // 0x655760: r0 = AllocateDouble()
    //     0x655760: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x655764: mov             x2, x0
    // 0x655768: RestoreReg r0
    //     0x655768: ldr             x0, [SP], #8
    // 0x65576c: ldp             x1, x3, [SP], #0x10
    // 0x655770: RestoreReg d0
    //     0x655770: ldr             q0, [SP], #0x10
    // 0x655774: ldp             q1, q3, [SP], #0x20
    // 0x655778: b               #0x655224
    // 0x65577c: stp             q0, q1, [SP, #-0x20]!
    // 0x655780: r0 = AllocateDouble()
    //     0x655780: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x655784: ldp             q0, q1, [SP], #0x20
    // 0x655788: b               #0x655468
    // 0x65578c: stp             q0, q2, [SP, #-0x20]!
    // 0x655790: r0 = AllocateDouble()
    //     0x655790: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x655794: ldp             q0, q2, [SP], #0x20
    // 0x655798: b               #0x6554e4
    // 0x65579c: stp             q0, q1, [SP, #-0x20]!
    // 0x6557a0: SaveReg r0
    //     0x6557a0: str             x0, [SP, #-8]!
    // 0x6557a4: r0 = AllocateDouble()
    //     0x6557a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6557a8: mov             x1, x0
    // 0x6557ac: RestoreReg r0
    //     0x6557ac: ldr             x0, [SP], #8
    // 0x6557b0: ldp             q0, q1, [SP], #0x20
    // 0x6557b4: b               #0x6555c0
    // 0x6557b8: stp             q0, q1, [SP, #-0x20]!
    // 0x6557bc: r0 = AllocateDouble()
    //     0x6557bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6557c0: ldp             q0, q1, [SP], #0x20
    // 0x6557c4: b               #0x655604
    // 0x6557c8: SaveReg d0
    //     0x6557c8: str             q0, [SP, #-0x10]!
    // 0x6557cc: r0 = AllocateDouble()
    //     0x6557cc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6557d0: RestoreReg d0
    //     0x6557d0: ldr             q0, [SP], #0x10
    // 0x6557d4: b               #0x655644
  }
}

// lib: , url: package:extended_image/src/image/render_image.dart

// class id: 1048944, size: 0x8
class :: {
}

// class id: 2544, size: 0xcc, field offset: 0x60
class ExtendedRenderImage extends RenderBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62b724, size: 0x18
    // 0x62b724: r4 = 0
    //     0x62b724: mov             x4, #0
    // 0x62b728: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62b728: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c558] AnonymousClosure: (0x62b73c), in [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::computeMaxIntrinsicHeight (0x62b788)
    //     0x62b72c: ldr             x1, [x17, #0x558]
    // 0x62b730: r24 = BuildNonGenericMethodExtractorStub
    //     0x62b730: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62b734: LoadField: r0 = r24->field_17
    //     0x62b734: ldur            x0, [x24, #0x17]
    // 0x62b738: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62b73c, size: 0x4c
    // 0x62b73c: EnterFrame
    //     0x62b73c: stp             fp, lr, [SP, #-0x10]!
    //     0x62b740: mov             fp, SP
    // 0x62b744: ldr             x0, [fp, #0x18]
    // 0x62b748: LoadField: r1 = r0->field_17
    //     0x62b748: ldur            w1, [x0, #0x17]
    // 0x62b74c: DecompressPointer r1
    //     0x62b74c: add             x1, x1, HEAP, lsl #32
    // 0x62b750: CheckStackOverflow
    //     0x62b750: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62b754: cmp             SP, x16
    //     0x62b758: b.ls            #0x62b780
    // 0x62b75c: LoadField: r0 = r1->field_f
    //     0x62b75c: ldur            w0, [x1, #0xf]
    // 0x62b760: DecompressPointer r0
    //     0x62b760: add             x0, x0, HEAP, lsl #32
    // 0x62b764: ldr             x16, [fp, #0x10]
    // 0x62b768: stp             x16, x0, [SP, #-0x10]!
    // 0x62b76c: r0 = computeMaxIntrinsicHeight()
    //     0x62b76c: bl              #0x62b788  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::computeMaxIntrinsicHeight
    // 0x62b770: add             SP, SP, #0x10
    // 0x62b774: LeaveFrame
    //     0x62b774: mov             SP, fp
    //     0x62b778: ldp             fp, lr, [SP], #0x10
    // 0x62b77c: ret
    //     0x62b77c: ret             
    // 0x62b780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62b780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62b784: b               #0x62b75c
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62b788, size: 0xfc
    // 0x62b788: EnterFrame
    //     0x62b788: stp             fp, lr, [SP, #-0x10]!
    //     0x62b78c: mov             fp, SP
    // 0x62b790: AllocStack(0x18)
    //     0x62b790: sub             SP, SP, #0x18
    // 0x62b794: d0 = inf
    //     0x62b794: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62b798: CheckStackOverflow
    //     0x62b798: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62b79c: cmp             SP, x16
    //     0x62b7a0: b.ls            #0x62b86c
    // 0x62b7a4: ldr             x0, [fp, #0x10]
    // 0x62b7a8: LoadField: d1 = r0->field_7
    //     0x62b7a8: ldur            d1, [x0, #7]
    // 0x62b7ac: stur            d1, [fp, #-0x18]
    // 0x62b7b0: fcmp            d1, d0
    // 0x62b7b4: b.vs            #0x62b7bc
    // 0x62b7b8: b.eq            #0x62b7c4
    // 0x62b7bc: r0 = false
    //     0x62b7bc: add             x0, NULL, #0x30  ; false
    // 0x62b7c0: b               #0x62b7c8
    // 0x62b7c4: r0 = true
    //     0x62b7c4: add             x0, NULL, #0x20  ; true
    // 0x62b7c8: stur            x0, [fp, #-8]
    // 0x62b7cc: tbz             w0, #4, #0x62b7d8
    // 0x62b7d0: mov             v2.16b, v1.16b
    // 0x62b7d4: b               #0x62b7dc
    // 0x62b7d8: d2 = 0.000000
    //     0x62b7d8: eor             v2.16b, v2.16b, v2.16b
    // 0x62b7dc: stur            d2, [fp, #-0x10]
    // 0x62b7e0: r0 = BoxConstraints()
    //     0x62b7e0: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x62b7e4: ldur            d0, [fp, #-0x10]
    // 0x62b7e8: StoreField: r0->field_7 = d0
    //     0x62b7e8: stur            d0, [x0, #7]
    // 0x62b7ec: ldur            x1, [fp, #-8]
    // 0x62b7f0: tbz             w1, #4, #0x62b7fc
    // 0x62b7f4: ldur            d1, [fp, #-0x18]
    // 0x62b7f8: b               #0x62b800
    // 0x62b7fc: d1 = inf
    //     0x62b7fc: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62b800: d0 = inf
    //     0x62b800: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62b804: StoreField: r0->field_f = d1
    //     0x62b804: stur            d1, [x0, #0xf]
    // 0x62b808: fcmp            d0, d0
    // 0x62b80c: b.eq            #0x62b818
    // 0x62b810: d1 = inf
    //     0x62b810: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62b814: b               #0x62b81c
    // 0x62b818: d1 = 0.000000
    //     0x62b818: eor             v1.16b, v1.16b, v1.16b
    // 0x62b81c: StoreField: r0->field_17 = d1
    //     0x62b81c: stur            d1, [x0, #0x17]
    // 0x62b820: StoreField: r0->field_1f = d0
    //     0x62b820: stur            d0, [x0, #0x1f]
    // 0x62b824: ldr             x16, [fp, #0x18]
    // 0x62b828: stp             x0, x16, [SP, #-0x10]!
    // 0x62b82c: r0 = _sizeForConstraints()
    //     0x62b82c: bl              #0x62b884  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::_sizeForConstraints
    // 0x62b830: add             SP, SP, #0x10
    // 0x62b834: LoadField: d0 = r0->field_f
    //     0x62b834: ldur            d0, [x0, #0xf]
    // 0x62b838: r0 = inline_Allocate_Double()
    //     0x62b838: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62b83c: add             x0, x0, #0x10
    //     0x62b840: cmp             x1, x0
    //     0x62b844: b.ls            #0x62b874
    //     0x62b848: str             x0, [THR, #0x60]  ; THR::top
    //     0x62b84c: sub             x0, x0, #0xf
    //     0x62b850: mov             x1, #0xd108
    //     0x62b854: movk            x1, #3, lsl #16
    //     0x62b858: stur            x1, [x0, #-1]
    // 0x62b85c: StoreField: r0->field_7 = d0
    //     0x62b85c: stur            d0, [x0, #7]
    // 0x62b860: LeaveFrame
    //     0x62b860: mov             SP, fp
    //     0x62b864: ldp             fp, lr, [SP], #0x10
    // 0x62b868: ret
    //     0x62b868: ret             
    // 0x62b86c: r0 = StackOverflowSharedWithFPURegs()
    //     0x62b86c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62b870: b               #0x62b7a4
    // 0x62b874: SaveReg d0
    //     0x62b874: str             q0, [SP, #-0x10]!
    // 0x62b878: r0 = AllocateDouble()
    //     0x62b878: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62b87c: RestoreReg d0
    //     0x62b87c: ldr             q0, [SP], #0x10
    // 0x62b880: b               #0x62b85c
  }
  _ _sizeForConstraints(/* No info */) {
    // ** addr: 0x62b884, size: 0x1b0
    // 0x62b884: EnterFrame
    //     0x62b884: stp             fp, lr, [SP, #-0x10]!
    //     0x62b888: mov             fp, SP
    // 0x62b88c: AllocStack(0x20)
    //     0x62b88c: sub             SP, SP, #0x20
    // 0x62b890: CheckStackOverflow
    //     0x62b890: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62b894: cmp             SP, x16
    //     0x62b898: b.ls            #0x62ba28
    // 0x62b89c: ldr             x0, [fp, #0x18]
    // 0x62b8a0: LoadField: r1 = r0->field_87
    //     0x62b8a0: ldur            w1, [x0, #0x87]
    // 0x62b8a4: DecompressPointer r1
    //     0x62b8a4: add             x1, x1, HEAP, lsl #32
    // 0x62b8a8: stur            x1, [fp, #-0x10]
    // 0x62b8ac: LoadField: r2 = r0->field_8b
    //     0x62b8ac: ldur            w2, [x0, #0x8b]
    // 0x62b8b0: DecompressPointer r2
    //     0x62b8b0: add             x2, x2, HEAP, lsl #32
    // 0x62b8b4: stur            x2, [fp, #-8]
    // 0x62b8b8: cmp             w1, NULL
    // 0x62b8bc: b.ne            #0x62b8c8
    // 0x62b8c0: d0 = 0.000000
    //     0x62b8c0: eor             v0.16b, v0.16b, v0.16b
    // 0x62b8c4: b               #0x62b8cc
    // 0x62b8c8: LoadField: d0 = r1->field_7
    //     0x62b8c8: ldur            d0, [x1, #7]
    // 0x62b8cc: stur            d0, [fp, #-0x18]
    // 0x62b8d0: r0 = BoxConstraints()
    //     0x62b8d0: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x62b8d4: ldur            d0, [fp, #-0x18]
    // 0x62b8d8: StoreField: r0->field_7 = d0
    //     0x62b8d8: stur            d0, [x0, #7]
    // 0x62b8dc: ldur            x1, [fp, #-0x10]
    // 0x62b8e0: cmp             w1, NULL
    // 0x62b8e4: b.ne            #0x62b8f0
    // 0x62b8e8: d0 = inf
    //     0x62b8e8: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62b8ec: b               #0x62b8f4
    // 0x62b8f0: LoadField: d0 = r1->field_7
    //     0x62b8f0: ldur            d0, [x1, #7]
    // 0x62b8f4: ldur            x1, [fp, #-8]
    // 0x62b8f8: StoreField: r0->field_f = d0
    //     0x62b8f8: stur            d0, [x0, #0xf]
    // 0x62b8fc: cmp             w1, NULL
    // 0x62b900: b.ne            #0x62b90c
    // 0x62b904: d0 = 0.000000
    //     0x62b904: eor             v0.16b, v0.16b, v0.16b
    // 0x62b908: b               #0x62b910
    // 0x62b90c: LoadField: d0 = r1->field_7
    //     0x62b90c: ldur            d0, [x1, #7]
    // 0x62b910: StoreField: r0->field_17 = d0
    //     0x62b910: stur            d0, [x0, #0x17]
    // 0x62b914: cmp             w1, NULL
    // 0x62b918: b.ne            #0x62b924
    // 0x62b91c: d0 = inf
    //     0x62b91c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62b920: b               #0x62b928
    // 0x62b924: LoadField: d0 = r1->field_7
    //     0x62b924: ldur            d0, [x1, #7]
    // 0x62b928: ldr             x1, [fp, #0x18]
    // 0x62b92c: StoreField: r0->field_1f = d0
    //     0x62b92c: stur            d0, [x0, #0x1f]
    // 0x62b930: ldr             x16, [fp, #0x10]
    // 0x62b934: stp             x16, x0, [SP, #-0x10]!
    // 0x62b938: r0 = enforce()
    //     0x62b938: bl              #0x62bd90  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0x62b93c: add             SP, SP, #0x10
    // 0x62b940: mov             x3, x0
    // 0x62b944: ldr             x2, [fp, #0x18]
    // 0x62b948: stur            x3, [fp, #-8]
    // 0x62b94c: LoadField: r0 = r2->field_7f
    //     0x62b94c: ldur            w0, [x2, #0x7f]
    // 0x62b950: DecompressPointer r0
    //     0x62b950: add             x0, x0, HEAP, lsl #32
    // 0x62b954: cmp             w0, NULL
    // 0x62b958: b.ne            #0x62b974
    // 0x62b95c: SaveReg r3
    //     0x62b95c: str             x3, [SP, #-8]!
    // 0x62b960: r0 = smallest()
    //     0x62b960: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x62b964: add             SP, SP, #8
    // 0x62b968: LeaveFrame
    //     0x62b968: mov             SP, fp
    //     0x62b96c: ldp             fp, lr, [SP], #0x10
    // 0x62b970: ret
    //     0x62b970: ret             
    // 0x62b974: LoadField: r4 = r0->field_f
    //     0x62b974: ldur            x4, [x0, #0xf]
    // 0x62b978: r0 = BoxInt64Instr(r4)
    //     0x62b978: sbfiz           x0, x4, #1, #0x1f
    //     0x62b97c: cmp             x4, x0, asr #1
    //     0x62b980: b.eq            #0x62b98c
    //     0x62b984: bl              #0xd69bb8
    //     0x62b988: stur            x4, [x0, #7]
    // 0x62b98c: stp             x0, NULL, [SP, #-0x10]!
    // 0x62b990: r0 = _Double.fromInteger()
    //     0x62b990: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x62b994: add             SP, SP, #0x10
    // 0x62b998: ldr             x2, [fp, #0x18]
    // 0x62b99c: LoadField: d0 = r2->field_8f
    //     0x62b99c: ldur            d0, [x2, #0x8f]
    // 0x62b9a0: LoadField: d1 = r0->field_7
    //     0x62b9a0: ldur            d1, [x0, #7]
    // 0x62b9a4: fdiv            d2, d1, d0
    // 0x62b9a8: stur            d2, [fp, #-0x18]
    // 0x62b9ac: LoadField: r0 = r2->field_7f
    //     0x62b9ac: ldur            w0, [x2, #0x7f]
    // 0x62b9b0: DecompressPointer r0
    //     0x62b9b0: add             x0, x0, HEAP, lsl #32
    // 0x62b9b4: cmp             w0, NULL
    // 0x62b9b8: b.eq            #0x62ba30
    // 0x62b9bc: LoadField: r3 = r0->field_17
    //     0x62b9bc: ldur            x3, [x0, #0x17]
    // 0x62b9c0: r0 = BoxInt64Instr(r3)
    //     0x62b9c0: sbfiz           x0, x3, #1, #0x1f
    //     0x62b9c4: cmp             x3, x0, asr #1
    //     0x62b9c8: b.eq            #0x62b9d4
    //     0x62b9cc: bl              #0xd69c6c
    //     0x62b9d0: stur            x3, [x0, #7]
    // 0x62b9d4: stp             x0, NULL, [SP, #-0x10]!
    // 0x62b9d8: r0 = _Double.fromInteger()
    //     0x62b9d8: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x62b9dc: add             SP, SP, #0x10
    // 0x62b9e0: mov             x1, x0
    // 0x62b9e4: ldr             x0, [fp, #0x18]
    // 0x62b9e8: LoadField: d0 = r0->field_8f
    //     0x62b9e8: ldur            d0, [x0, #0x8f]
    // 0x62b9ec: LoadField: d1 = r1->field_7
    //     0x62b9ec: ldur            d1, [x1, #7]
    // 0x62b9f0: fdiv            d2, d1, d0
    // 0x62b9f4: stur            d2, [fp, #-0x20]
    // 0x62b9f8: r0 = Size()
    //     0x62b9f8: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x62b9fc: ldur            d0, [fp, #-0x18]
    // 0x62ba00: StoreField: r0->field_7 = d0
    //     0x62ba00: stur            d0, [x0, #7]
    // 0x62ba04: ldur            d0, [fp, #-0x20]
    // 0x62ba08: StoreField: r0->field_f = d0
    //     0x62ba08: stur            d0, [x0, #0xf]
    // 0x62ba0c: ldur            x16, [fp, #-8]
    // 0x62ba10: stp             x0, x16, [SP, #-0x10]!
    // 0x62ba14: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0x62ba14: bl              #0x62ba34  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0x62ba18: add             SP, SP, #0x10
    // 0x62ba1c: LeaveFrame
    //     0x62ba1c: mov             SP, fp
    //     0x62ba20: ldp             fp, lr, [SP], #0x10
    // 0x62ba24: ret
    //     0x62ba24: ret             
    // 0x62ba28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ba28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ba2c: b               #0x62b89c
    // 0x62ba30: r0 = NullCastErrorSharedWithFPURegs()
    //     0x62ba30: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x6346c0, size: 0x18
    // 0x6346c0: r4 = 0
    //     0x6346c0: mov             x4, #0
    // 0x6346c4: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x6346c4: add             x17, PP, #0x40, lsl #12  ; [pp+0x40ff8] AnonymousClosure: (0x6346d8), in [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::computeMaxIntrinsicWidth (0x634724)
    //     0x6346c8: ldr             x1, [x17, #0xff8]
    // 0x6346cc: r24 = BuildNonGenericMethodExtractorStub
    //     0x6346cc: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6346d0: LoadField: r0 = r24->field_17
    //     0x6346d0: ldur            x0, [x24, #0x17]
    // 0x6346d4: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x6346d8, size: 0x4c
    // 0x6346d8: EnterFrame
    //     0x6346d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6346dc: mov             fp, SP
    // 0x6346e0: ldr             x0, [fp, #0x18]
    // 0x6346e4: LoadField: r1 = r0->field_17
    //     0x6346e4: ldur            w1, [x0, #0x17]
    // 0x6346e8: DecompressPointer r1
    //     0x6346e8: add             x1, x1, HEAP, lsl #32
    // 0x6346ec: CheckStackOverflow
    //     0x6346ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6346f0: cmp             SP, x16
    //     0x6346f4: b.ls            #0x63471c
    // 0x6346f8: LoadField: r0 = r1->field_f
    //     0x6346f8: ldur            w0, [x1, #0xf]
    // 0x6346fc: DecompressPointer r0
    //     0x6346fc: add             x0, x0, HEAP, lsl #32
    // 0x634700: ldr             x16, [fp, #0x10]
    // 0x634704: stp             x16, x0, [SP, #-0x10]!
    // 0x634708: r0 = computeMaxIntrinsicWidth()
    //     0x634708: bl              #0x634724  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::computeMaxIntrinsicWidth
    // 0x63470c: add             SP, SP, #0x10
    // 0x634710: LeaveFrame
    //     0x634710: mov             SP, fp
    //     0x634714: ldp             fp, lr, [SP], #0x10
    // 0x634718: ret
    //     0x634718: ret             
    // 0x63471c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63471c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x634720: b               #0x6346f8
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x634724, size: 0xf4
    // 0x634724: EnterFrame
    //     0x634724: stp             fp, lr, [SP, #-0x10]!
    //     0x634728: mov             fp, SP
    // 0x63472c: AllocStack(0x8)
    //     0x63472c: sub             SP, SP, #8
    // 0x634730: d0 = inf
    //     0x634730: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x634734: CheckStackOverflow
    //     0x634734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634738: cmp             SP, x16
    //     0x63473c: b.ls            #0x634800
    // 0x634740: fcmp            d0, d0
    // 0x634744: b.eq            #0x634750
    // 0x634748: d1 = inf
    //     0x634748: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63474c: b               #0x634754
    // 0x634750: d1 = 0.000000
    //     0x634750: eor             v1.16b, v1.16b, v1.16b
    // 0x634754: ldr             x0, [fp, #0x10]
    // 0x634758: stur            d1, [fp, #-8]
    // 0x63475c: r0 = BoxConstraints()
    //     0x63475c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x634760: ldur            d0, [fp, #-8]
    // 0x634764: StoreField: r0->field_7 = d0
    //     0x634764: stur            d0, [x0, #7]
    // 0x634768: d0 = inf
    //     0x634768: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63476c: StoreField: r0->field_f = d0
    //     0x63476c: stur            d0, [x0, #0xf]
    // 0x634770: ldr             x1, [fp, #0x10]
    // 0x634774: LoadField: d1 = r1->field_7
    //     0x634774: ldur            d1, [x1, #7]
    // 0x634778: fcmp            d1, d0
    // 0x63477c: b.vs            #0x634784
    // 0x634780: b.eq            #0x63478c
    // 0x634784: r1 = false
    //     0x634784: add             x1, NULL, #0x30  ; false
    // 0x634788: b               #0x634790
    // 0x63478c: r1 = true
    //     0x63478c: add             x1, NULL, #0x20  ; true
    // 0x634790: tbz             w1, #4, #0x63479c
    // 0x634794: mov             v0.16b, v1.16b
    // 0x634798: b               #0x6347a0
    // 0x63479c: d0 = 0.000000
    //     0x63479c: eor             v0.16b, v0.16b, v0.16b
    // 0x6347a0: StoreField: r0->field_17 = d0
    //     0x6347a0: stur            d0, [x0, #0x17]
    // 0x6347a4: tbz             w1, #4, #0x6347b0
    // 0x6347a8: mov             v0.16b, v1.16b
    // 0x6347ac: b               #0x6347b4
    // 0x6347b0: d0 = inf
    //     0x6347b0: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6347b4: StoreField: r0->field_1f = d0
    //     0x6347b4: stur            d0, [x0, #0x1f]
    // 0x6347b8: ldr             x16, [fp, #0x18]
    // 0x6347bc: stp             x0, x16, [SP, #-0x10]!
    // 0x6347c0: r0 = _sizeForConstraints()
    //     0x6347c0: bl              #0x62b884  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::_sizeForConstraints
    // 0x6347c4: add             SP, SP, #0x10
    // 0x6347c8: LoadField: d0 = r0->field_7
    //     0x6347c8: ldur            d0, [x0, #7]
    // 0x6347cc: r0 = inline_Allocate_Double()
    //     0x6347cc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6347d0: add             x0, x0, #0x10
    //     0x6347d4: cmp             x1, x0
    //     0x6347d8: b.ls            #0x634808
    //     0x6347dc: str             x0, [THR, #0x60]  ; THR::top
    //     0x6347e0: sub             x0, x0, #0xf
    //     0x6347e4: mov             x1, #0xd108
    //     0x6347e8: movk            x1, #3, lsl #16
    //     0x6347ec: stur            x1, [x0, #-1]
    // 0x6347f0: StoreField: r0->field_7 = d0
    //     0x6347f0: stur            d0, [x0, #7]
    // 0x6347f4: LeaveFrame
    //     0x6347f4: mov             SP, fp
    //     0x6347f8: ldp             fp, lr, [SP], #0x10
    // 0x6347fc: ret
    //     0x6347fc: ret             
    // 0x634800: r0 = StackOverflowSharedWithFPURegs()
    //     0x634800: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x634804: b               #0x634740
    // 0x634808: SaveReg d0
    //     0x634808: str             q0, [SP, #-0x10]!
    // 0x63480c: r0 = AllocateDouble()
    //     0x63480c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x634810: RestoreReg d0
    //     0x634810: ldr             q0, [SP], #0x10
    // 0x634814: b               #0x6347f0
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638140, size: 0x18
    // 0x638140: r4 = 0
    //     0x638140: mov             x4, #0
    // 0x638144: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638144: add             x17, PP, #0x53, lsl #12  ; [pp+0x53978] AnonymousClosure: (0x638158), in [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::computeMinIntrinsicHeight (0x6381a4)
    //     0x638148: ldr             x1, [x17, #0x978]
    // 0x63814c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63814c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638150: LoadField: r0 = r24->field_17
    //     0x638150: ldur            x0, [x24, #0x17]
    // 0x638154: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x638158, size: 0x4c
    // 0x638158: EnterFrame
    //     0x638158: stp             fp, lr, [SP, #-0x10]!
    //     0x63815c: mov             fp, SP
    // 0x638160: ldr             x0, [fp, #0x18]
    // 0x638164: LoadField: r1 = r0->field_17
    //     0x638164: ldur            w1, [x0, #0x17]
    // 0x638168: DecompressPointer r1
    //     0x638168: add             x1, x1, HEAP, lsl #32
    // 0x63816c: CheckStackOverflow
    //     0x63816c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638170: cmp             SP, x16
    //     0x638174: b.ls            #0x63819c
    // 0x638178: LoadField: r0 = r1->field_f
    //     0x638178: ldur            w0, [x1, #0xf]
    // 0x63817c: DecompressPointer r0
    //     0x63817c: add             x0, x0, HEAP, lsl #32
    // 0x638180: ldr             x16, [fp, #0x10]
    // 0x638184: stp             x16, x0, [SP, #-0x10]!
    // 0x638188: r0 = computeMinIntrinsicHeight()
    //     0x638188: bl              #0x6381a4  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::computeMinIntrinsicHeight
    // 0x63818c: add             SP, SP, #0x10
    // 0x638190: LeaveFrame
    //     0x638190: mov             SP, fp
    //     0x638194: ldp             fp, lr, [SP], #0x10
    // 0x638198: ret
    //     0x638198: ret             
    // 0x63819c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63819c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6381a0: b               #0x638178
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x6381a4, size: 0x130
    // 0x6381a4: EnterFrame
    //     0x6381a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6381a8: mov             fp, SP
    // 0x6381ac: AllocStack(0x18)
    //     0x6381ac: sub             SP, SP, #0x18
    // 0x6381b0: CheckStackOverflow
    //     0x6381b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6381b4: cmp             SP, x16
    //     0x6381b8: b.ls            #0x6382bc
    // 0x6381bc: ldr             x0, [fp, #0x18]
    // 0x6381c0: LoadField: r1 = r0->field_87
    //     0x6381c0: ldur            w1, [x0, #0x87]
    // 0x6381c4: DecompressPointer r1
    //     0x6381c4: add             x1, x1, HEAP, lsl #32
    // 0x6381c8: cmp             w1, NULL
    // 0x6381cc: b.ne            #0x6381f0
    // 0x6381d0: LoadField: r1 = r0->field_8b
    //     0x6381d0: ldur            w1, [x0, #0x8b]
    // 0x6381d4: DecompressPointer r1
    //     0x6381d4: add             x1, x1, HEAP, lsl #32
    // 0x6381d8: cmp             w1, NULL
    // 0x6381dc: b.ne            #0x6381f0
    // 0x6381e0: r0 = 0.000000
    //     0x6381e0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6381e4: LeaveFrame
    //     0x6381e4: mov             SP, fp
    //     0x6381e8: ldp             fp, lr, [SP], #0x10
    // 0x6381ec: ret
    //     0x6381ec: ret             
    // 0x6381f0: ldr             x1, [fp, #0x10]
    // 0x6381f4: d0 = inf
    //     0x6381f4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6381f8: LoadField: d1 = r1->field_7
    //     0x6381f8: ldur            d1, [x1, #7]
    // 0x6381fc: stur            d1, [fp, #-0x18]
    // 0x638200: fcmp            d1, d0
    // 0x638204: b.vs            #0x63820c
    // 0x638208: b.eq            #0x638214
    // 0x63820c: r1 = false
    //     0x63820c: add             x1, NULL, #0x30  ; false
    // 0x638210: b               #0x638218
    // 0x638214: r1 = true
    //     0x638214: add             x1, NULL, #0x20  ; true
    // 0x638218: stur            x1, [fp, #-8]
    // 0x63821c: tbz             w1, #4, #0x638228
    // 0x638220: mov             v2.16b, v1.16b
    // 0x638224: b               #0x63822c
    // 0x638228: d2 = 0.000000
    //     0x638228: eor             v2.16b, v2.16b, v2.16b
    // 0x63822c: stur            d2, [fp, #-0x10]
    // 0x638230: r0 = BoxConstraints()
    //     0x638230: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x638234: ldur            d0, [fp, #-0x10]
    // 0x638238: StoreField: r0->field_7 = d0
    //     0x638238: stur            d0, [x0, #7]
    // 0x63823c: ldur            x1, [fp, #-8]
    // 0x638240: tbz             w1, #4, #0x63824c
    // 0x638244: ldur            d1, [fp, #-0x18]
    // 0x638248: b               #0x638250
    // 0x63824c: d1 = inf
    //     0x63824c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x638250: d0 = inf
    //     0x638250: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x638254: StoreField: r0->field_f = d1
    //     0x638254: stur            d1, [x0, #0xf]
    // 0x638258: fcmp            d0, d0
    // 0x63825c: b.eq            #0x638268
    // 0x638260: d1 = inf
    //     0x638260: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x638264: b               #0x63826c
    // 0x638268: d1 = 0.000000
    //     0x638268: eor             v1.16b, v1.16b, v1.16b
    // 0x63826c: StoreField: r0->field_17 = d1
    //     0x63826c: stur            d1, [x0, #0x17]
    // 0x638270: StoreField: r0->field_1f = d0
    //     0x638270: stur            d0, [x0, #0x1f]
    // 0x638274: ldr             x16, [fp, #0x18]
    // 0x638278: stp             x0, x16, [SP, #-0x10]!
    // 0x63827c: r0 = _sizeForConstraints()
    //     0x63827c: bl              #0x62b884  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::_sizeForConstraints
    // 0x638280: add             SP, SP, #0x10
    // 0x638284: LoadField: d0 = r0->field_f
    //     0x638284: ldur            d0, [x0, #0xf]
    // 0x638288: r0 = inline_Allocate_Double()
    //     0x638288: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63828c: add             x0, x0, #0x10
    //     0x638290: cmp             x1, x0
    //     0x638294: b.ls            #0x6382c4
    //     0x638298: str             x0, [THR, #0x60]  ; THR::top
    //     0x63829c: sub             x0, x0, #0xf
    //     0x6382a0: mov             x1, #0xd108
    //     0x6382a4: movk            x1, #3, lsl #16
    //     0x6382a8: stur            x1, [x0, #-1]
    // 0x6382ac: StoreField: r0->field_7 = d0
    //     0x6382ac: stur            d0, [x0, #7]
    // 0x6382b0: LeaveFrame
    //     0x6382b0: mov             SP, fp
    //     0x6382b4: ldp             fp, lr, [SP], #0x10
    // 0x6382b8: ret
    //     0x6382b8: ret             
    // 0x6382bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6382bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6382c0: b               #0x6381bc
    // 0x6382c4: SaveReg d0
    //     0x6382c4: str             q0, [SP, #-0x10]!
    // 0x6382c8: r0 = AllocateDouble()
    //     0x6382c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6382cc: RestoreReg d0
    //     0x6382cc: ldr             q0, [SP], #0x10
    // 0x6382d0: b               #0x6382ac
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63a460, size: 0x18
    // 0x63a460: r4 = 0
    //     0x63a460: mov             x4, #0
    // 0x63a464: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63a464: add             x17, PP, #0x51, lsl #12  ; [pp+0x513a0] AnonymousClosure: (0x63a478), in [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::computeMinIntrinsicWidth (0x63a4c4)
    //     0x63a468: ldr             x1, [x17, #0x3a0]
    // 0x63a46c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63a46c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63a470: LoadField: r0 = r24->field_17
    //     0x63a470: ldur            x0, [x24, #0x17]
    // 0x63a474: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63a478, size: 0x4c
    // 0x63a478: EnterFrame
    //     0x63a478: stp             fp, lr, [SP, #-0x10]!
    //     0x63a47c: mov             fp, SP
    // 0x63a480: ldr             x0, [fp, #0x18]
    // 0x63a484: LoadField: r1 = r0->field_17
    //     0x63a484: ldur            w1, [x0, #0x17]
    // 0x63a488: DecompressPointer r1
    //     0x63a488: add             x1, x1, HEAP, lsl #32
    // 0x63a48c: CheckStackOverflow
    //     0x63a48c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63a490: cmp             SP, x16
    //     0x63a494: b.ls            #0x63a4bc
    // 0x63a498: LoadField: r0 = r1->field_f
    //     0x63a498: ldur            w0, [x1, #0xf]
    // 0x63a49c: DecompressPointer r0
    //     0x63a49c: add             x0, x0, HEAP, lsl #32
    // 0x63a4a0: ldr             x16, [fp, #0x10]
    // 0x63a4a4: stp             x16, x0, [SP, #-0x10]!
    // 0x63a4a8: r0 = computeMinIntrinsicWidth()
    //     0x63a4a8: bl              #0x63a4c4  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::computeMinIntrinsicWidth
    // 0x63a4ac: add             SP, SP, #0x10
    // 0x63a4b0: LeaveFrame
    //     0x63a4b0: mov             SP, fp
    //     0x63a4b4: ldp             fp, lr, [SP], #0x10
    // 0x63a4b8: ret
    //     0x63a4b8: ret             
    // 0x63a4bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63a4bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63a4c0: b               #0x63a498
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63a4c4, size: 0x128
    // 0x63a4c4: EnterFrame
    //     0x63a4c4: stp             fp, lr, [SP, #-0x10]!
    //     0x63a4c8: mov             fp, SP
    // 0x63a4cc: AllocStack(0x8)
    //     0x63a4cc: sub             SP, SP, #8
    // 0x63a4d0: CheckStackOverflow
    //     0x63a4d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63a4d4: cmp             SP, x16
    //     0x63a4d8: b.ls            #0x63a5d4
    // 0x63a4dc: ldr             x0, [fp, #0x18]
    // 0x63a4e0: LoadField: r1 = r0->field_87
    //     0x63a4e0: ldur            w1, [x0, #0x87]
    // 0x63a4e4: DecompressPointer r1
    //     0x63a4e4: add             x1, x1, HEAP, lsl #32
    // 0x63a4e8: cmp             w1, NULL
    // 0x63a4ec: b.ne            #0x63a510
    // 0x63a4f0: LoadField: r1 = r0->field_8b
    //     0x63a4f0: ldur            w1, [x0, #0x8b]
    // 0x63a4f4: DecompressPointer r1
    //     0x63a4f4: add             x1, x1, HEAP, lsl #32
    // 0x63a4f8: cmp             w1, NULL
    // 0x63a4fc: b.ne            #0x63a510
    // 0x63a500: r0 = 0.000000
    //     0x63a500: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63a504: LeaveFrame
    //     0x63a504: mov             SP, fp
    //     0x63a508: ldp             fp, lr, [SP], #0x10
    // 0x63a50c: ret
    //     0x63a50c: ret             
    // 0x63a510: d0 = inf
    //     0x63a510: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63a514: fcmp            d0, d0
    // 0x63a518: b.eq            #0x63a524
    // 0x63a51c: d1 = inf
    //     0x63a51c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63a520: b               #0x63a528
    // 0x63a524: d1 = 0.000000
    //     0x63a524: eor             v1.16b, v1.16b, v1.16b
    // 0x63a528: ldr             x1, [fp, #0x10]
    // 0x63a52c: stur            d1, [fp, #-8]
    // 0x63a530: r0 = BoxConstraints()
    //     0x63a530: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x63a534: ldur            d0, [fp, #-8]
    // 0x63a538: StoreField: r0->field_7 = d0
    //     0x63a538: stur            d0, [x0, #7]
    // 0x63a53c: d0 = inf
    //     0x63a53c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63a540: StoreField: r0->field_f = d0
    //     0x63a540: stur            d0, [x0, #0xf]
    // 0x63a544: ldr             x1, [fp, #0x10]
    // 0x63a548: LoadField: d1 = r1->field_7
    //     0x63a548: ldur            d1, [x1, #7]
    // 0x63a54c: fcmp            d1, d0
    // 0x63a550: b.vs            #0x63a558
    // 0x63a554: b.eq            #0x63a560
    // 0x63a558: r1 = false
    //     0x63a558: add             x1, NULL, #0x30  ; false
    // 0x63a55c: b               #0x63a564
    // 0x63a560: r1 = true
    //     0x63a560: add             x1, NULL, #0x20  ; true
    // 0x63a564: tbz             w1, #4, #0x63a570
    // 0x63a568: mov             v0.16b, v1.16b
    // 0x63a56c: b               #0x63a574
    // 0x63a570: d0 = 0.000000
    //     0x63a570: eor             v0.16b, v0.16b, v0.16b
    // 0x63a574: StoreField: r0->field_17 = d0
    //     0x63a574: stur            d0, [x0, #0x17]
    // 0x63a578: tbz             w1, #4, #0x63a584
    // 0x63a57c: mov             v0.16b, v1.16b
    // 0x63a580: b               #0x63a588
    // 0x63a584: d0 = inf
    //     0x63a584: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63a588: StoreField: r0->field_1f = d0
    //     0x63a588: stur            d0, [x0, #0x1f]
    // 0x63a58c: ldr             x16, [fp, #0x18]
    // 0x63a590: stp             x0, x16, [SP, #-0x10]!
    // 0x63a594: r0 = _sizeForConstraints()
    //     0x63a594: bl              #0x62b884  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::_sizeForConstraints
    // 0x63a598: add             SP, SP, #0x10
    // 0x63a59c: LoadField: d0 = r0->field_7
    //     0x63a59c: ldur            d0, [x0, #7]
    // 0x63a5a0: r0 = inline_Allocate_Double()
    //     0x63a5a0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63a5a4: add             x0, x0, #0x10
    //     0x63a5a8: cmp             x1, x0
    //     0x63a5ac: b.ls            #0x63a5dc
    //     0x63a5b0: str             x0, [THR, #0x60]  ; THR::top
    //     0x63a5b4: sub             x0, x0, #0xf
    //     0x63a5b8: mov             x1, #0xd108
    //     0x63a5bc: movk            x1, #3, lsl #16
    //     0x63a5c0: stur            x1, [x0, #-1]
    // 0x63a5c4: StoreField: r0->field_7 = d0
    //     0x63a5c4: stur            d0, [x0, #7]
    // 0x63a5c8: LeaveFrame
    //     0x63a5c8: mov             SP, fp
    //     0x63a5cc: ldp             fp, lr, [SP], #0x10
    // 0x63a5d0: ret
    //     0x63a5d0: ret             
    // 0x63a5d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63a5d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63a5d8: b               #0x63a4dc
    // 0x63a5dc: SaveReg d0
    //     0x63a5dc: str             q0, [SP, #-0x10]!
    // 0x63a5e0: r0 = AllocateDouble()
    //     0x63a5e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63a5e4: RestoreReg d0
    //     0x63a5e4: ldr             q0, [SP], #0x10
    // 0x63a5e8: b               #0x63a5c4
  }
  _ dispose(/* No info */) {
    // ** addr: 0x652244, size: 0x60
    // 0x652244: EnterFrame
    //     0x652244: stp             fp, lr, [SP, #-0x10]!
    //     0x652248: mov             fp, SP
    // 0x65224c: CheckStackOverflow
    //     0x65224c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x652250: cmp             SP, x16
    //     0x652254: b.ls            #0x65229c
    // 0x652258: ldr             x0, [fp, #0x10]
    // 0x65225c: LoadField: r1 = r0->field_7f
    //     0x65225c: ldur            w1, [x0, #0x7f]
    // 0x652260: DecompressPointer r1
    //     0x652260: add             x1, x1, HEAP, lsl #32
    // 0x652264: cmp             w1, NULL
    // 0x652268: b.eq            #0x65227c
    // 0x65226c: SaveReg r1
    //     0x65226c: str             x1, [SP, #-8]!
    // 0x652270: r0 = dispose()
    //     0x652270: bl              #0x6522a4  ; [dart:ui] Image::dispose
    // 0x652274: add             SP, SP, #8
    // 0x652278: ldr             x0, [fp, #0x10]
    // 0x65227c: StoreField: r0->field_7f = rNULL
    //     0x65227c: stur            NULL, [x0, #0x7f]
    // 0x652280: SaveReg r0
    //     0x652280: str             x0, [SP, #-8]!
    // 0x652284: r0 = dispose()
    //     0x652284: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x652288: add             SP, SP, #8
    // 0x65228c: r0 = Null
    //     0x65228c: mov             x0, NULL
    // 0x652290: LeaveFrame
    //     0x652290: mov             SP, fp
    //     0x652294: ldp             fp, lr, [SP], #0x10
    // 0x652298: ret
    //     0x652298: ret             
    // 0x65229c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65229c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6522a0: b               #0x652258
  }
  _ paint(/* No info */) {
    // ** addr: 0x654cdc, size: 0x1d8
    // 0x654cdc: EnterFrame
    //     0x654cdc: stp             fp, lr, [SP, #-0x10]!
    //     0x654ce0: mov             fp, SP
    // 0x654ce4: AllocStack(0x8)
    //     0x654ce4: sub             SP, SP, #8
    // 0x654ce8: CheckStackOverflow
    //     0x654ce8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x654cec: cmp             SP, x16
    //     0x654cf0: b.ls            #0x654e60
    // 0x654cf4: ldr             x0, [fp, #0x20]
    // 0x654cf8: LoadField: r1 = r0->field_7f
    //     0x654cf8: ldur            w1, [x0, #0x7f]
    // 0x654cfc: DecompressPointer r1
    //     0x654cfc: add             x1, x1, HEAP, lsl #32
    // 0x654d00: cmp             w1, NULL
    // 0x654d04: b.ne            #0x654d18
    // 0x654d08: r0 = Null
    //     0x654d08: mov             x0, NULL
    // 0x654d0c: LeaveFrame
    //     0x654d0c: mov             SP, fp
    //     0x654d10: ldp             fp, lr, [SP], #0x10
    // 0x654d14: ret
    //     0x654d14: ret             
    // 0x654d18: SaveReg r0
    //     0x654d18: str             x0, [SP, #-8]!
    // 0x654d1c: r0 = _resolve()
    //     0x654d1c: bl              #0x65b080  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::_resolve
    // 0x654d20: add             SP, SP, #8
    // 0x654d24: ldr             x0, [fp, #0x20]
    // 0x654d28: LoadField: r1 = r0->field_57
    //     0x654d28: ldur            w1, [x0, #0x57]
    // 0x654d2c: DecompressPointer r1
    //     0x654d2c: add             x1, x1, HEAP, lsl #32
    // 0x654d30: cmp             w1, NULL
    // 0x654d34: b.eq            #0x654e68
    // 0x654d38: ldr             x16, [fp, #0x10]
    // 0x654d3c: stp             x1, x16, [SP, #-0x10]!
    // 0x654d40: r0 = &()
    //     0x654d40: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x654d44: add             SP, SP, #0x10
    // 0x654d48: stur            x0, [fp, #-8]
    // 0x654d4c: ldr             x16, [fp, #0x18]
    // 0x654d50: SaveReg r16
    //     0x654d50: str             x16, [SP, #-8]!
    // 0x654d54: r0 = canvas()
    //     0x654d54: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x654d58: add             SP, SP, #8
    // 0x654d5c: mov             x1, x0
    // 0x654d60: ldr             x0, [fp, #0x20]
    // 0x654d64: LoadField: r2 = r0->field_7f
    //     0x654d64: ldur            w2, [x0, #0x7f]
    // 0x654d68: DecompressPointer r2
    //     0x654d68: add             x2, x2, HEAP, lsl #32
    // 0x654d6c: cmp             w2, NULL
    // 0x654d70: b.eq            #0x654e6c
    // 0x654d74: LoadField: d0 = r0->field_8f
    //     0x654d74: ldur            d0, [x0, #0x8f]
    // 0x654d78: LoadField: r3 = r0->field_9f
    //     0x654d78: ldur            w3, [x0, #0x9f]
    // 0x654d7c: DecompressPointer r3
    //     0x654d7c: add             x3, x3, HEAP, lsl #32
    // 0x654d80: cmp             w3, NULL
    // 0x654d84: b.ne            #0x654d90
    // 0x654d88: r3 = Null
    //     0x654d88: mov             x3, NULL
    // 0x654d8c: b               #0x654da8
    // 0x654d90: LoadField: r4 = r3->field_37
    //     0x654d90: ldur            w4, [x3, #0x37]
    // 0x654d94: DecompressPointer r4
    //     0x654d94: add             x4, x4, HEAP, lsl #32
    // 0x654d98: r16 = Sentinel
    //     0x654d98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x654d9c: cmp             w4, w16
    // 0x654da0: b.eq            #0x654e70
    // 0x654da4: mov             x3, x4
    // 0x654da8: cmp             w3, NULL
    // 0x654dac: b.ne            #0x654db8
    // 0x654db0: d1 = 1.000000
    //     0x654db0: fmov            d1, #1.00000000
    // 0x654db4: b               #0x654dbc
    // 0x654db8: LoadField: d1 = r3->field_7
    //     0x654db8: ldur            d1, [x3, #7]
    // 0x654dbc: LoadField: r3 = r0->field_ab
    //     0x654dbc: ldur            w3, [x0, #0xab]
    // 0x654dc0: DecompressPointer r3
    //     0x654dc0: add             x3, x3, HEAP, lsl #32
    // 0x654dc4: LoadField: r4 = r0->field_77
    //     0x654dc4: ldur            w4, [x0, #0x77]
    // 0x654dc8: DecompressPointer r4
    //     0x654dc8: add             x4, x4, HEAP, lsl #32
    // 0x654dcc: cmp             w4, NULL
    // 0x654dd0: b.eq            #0x654e7c
    // 0x654dd4: LoadField: r4 = r0->field_7b
    //     0x654dd4: ldur            w4, [x0, #0x7b]
    // 0x654dd8: DecompressPointer r4
    //     0x654dd8: add             x4, x4, HEAP, lsl #32
    // 0x654ddc: cmp             w4, NULL
    // 0x654de0: b.eq            #0x654e80
    // 0x654de4: LoadField: r5 = r0->field_bb
    //     0x654de4: ldur            w5, [x0, #0xbb]
    // 0x654de8: DecompressPointer r5
    //     0x654de8: add             x5, x5, HEAP, lsl #32
    // 0x654dec: LoadField: r6 = r0->field_67
    //     0x654dec: ldur            w6, [x0, #0x67]
    // 0x654df0: DecompressPointer r6
    //     0x654df0: add             x6, x6, HEAP, lsl #32
    // 0x654df4: LoadField: r7 = r0->field_63
    //     0x654df4: ldur            w7, [x0, #0x63]
    // 0x654df8: DecompressPointer r7
    //     0x654df8: add             x7, x7, HEAP, lsl #32
    // 0x654dfc: r0 = inline_Allocate_Double()
    //     0x654dfc: ldp             x0, x8, [THR, #0x60]  ; THR::top
    //     0x654e00: add             x0, x0, #0x10
    //     0x654e04: cmp             x8, x0
    //     0x654e08: b.ls            #0x654e84
    //     0x654e0c: str             x0, [THR, #0x60]  ; THR::top
    //     0x654e10: sub             x0, x0, #0xf
    //     0x654e14: mov             x8, #0xd108
    //     0x654e18: movk            x8, #3, lsl #16
    //     0x654e1c: stur            x8, [x0, #-1]
    // 0x654e20: StoreField: r0->field_7 = d1
    //     0x654e20: stur            d1, [x0, #7]
    // 0x654e24: stp             x7, x1, [SP, #-0x10]!
    // 0x654e28: stp             x4, x3, [SP, #-0x10]!
    // 0x654e2c: stp             x2, x6, [SP, #-0x10]!
    // 0x654e30: stp             x0, x5, [SP, #-0x10]!
    // 0x654e34: ldur            x16, [fp, #-8]
    // 0x654e38: r30 = Instance_ImageRepeat
    //     0x654e38: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0x654e3c: ldr             lr, [lr, #0x540]
    // 0x654e40: stp             lr, x16, [SP, #-0x10]!
    // 0x654e44: SaveReg d0
    //     0x654e44: str             d0, [SP, #-8]!
    // 0x654e48: r0 = paintExtendedImage()
    //     0x654e48: bl              #0x654eb4  ; [package:extended_image/src/image/painting.dart] ::paintExtendedImage
    // 0x654e4c: add             SP, SP, #0x58
    // 0x654e50: r0 = Null
    //     0x654e50: mov             x0, NULL
    // 0x654e54: LeaveFrame
    //     0x654e54: mov             SP, fp
    //     0x654e58: ldp             fp, lr, [SP], #0x10
    // 0x654e5c: ret
    //     0x654e5c: ret             
    // 0x654e60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x654e60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x654e64: b               #0x654cf4
    // 0x654e68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x654e68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x654e6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x654e6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x654e70: r9 = _value
    //     0x654e70: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x654e74: ldr             x9, [x9, #0xbb0]
    // 0x654e78: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x654e78: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x654e7c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654e7c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654e80: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654e80: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654e84: stp             q0, q1, [SP, #-0x20]!
    // 0x654e88: stp             x6, x7, [SP, #-0x10]!
    // 0x654e8c: stp             x4, x5, [SP, #-0x10]!
    // 0x654e90: stp             x2, x3, [SP, #-0x10]!
    // 0x654e94: SaveReg r1
    //     0x654e94: str             x1, [SP, #-8]!
    // 0x654e98: r0 = AllocateDouble()
    //     0x654e98: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x654e9c: RestoreReg r1
    //     0x654e9c: ldr             x1, [SP], #8
    // 0x654ea0: ldp             x2, x3, [SP], #0x10
    // 0x654ea4: ldp             x4, x5, [SP], #0x10
    // 0x654ea8: ldp             x6, x7, [SP], #0x10
    // 0x654eac: ldp             q0, q1, [SP], #0x20
    // 0x654eb0: b               #0x654e20
  }
  _ _resolve(/* No info */) {
    // ** addr: 0x65b080, size: 0x38
    // 0x65b080: ldr             x1, [SP]
    // 0x65b084: LoadField: r2 = r1->field_77
    //     0x65b084: ldur            w2, [x1, #0x77]
    // 0x65b088: DecompressPointer r2
    //     0x65b088: add             x2, x2, HEAP, lsl #32
    // 0x65b08c: cmp             w2, NULL
    // 0x65b090: b.eq            #0x65b09c
    // 0x65b094: r0 = Null
    //     0x65b094: mov             x0, NULL
    // 0x65b098: ret
    //     0x65b098: ret             
    // 0x65b09c: r3 = Instance_Alignment
    //     0x65b09c: add             x3, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x65b0a0: ldr             x3, [x3, #0xc70]
    // 0x65b0a4: r2 = false
    //     0x65b0a4: add             x2, NULL, #0x30  ; false
    // 0x65b0a8: StoreField: r1->field_77 = r3
    //     0x65b0a8: stur            w3, [x1, #0x77]
    // 0x65b0ac: StoreField: r1->field_7b = r2
    //     0x65b0ac: stur            w2, [x1, #0x7b]
    // 0x65b0b0: r0 = Null
    //     0x65b0b0: mov             x0, NULL
    // 0x65b0b4: ret
    //     0x65b0b4: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x688f00, size: 0xd0
    // 0x688f00: EnterFrame
    //     0x688f00: stp             fp, lr, [SP, #-0x10]!
    //     0x688f04: mov             fp, SP
    // 0x688f08: AllocStack(0x8)
    //     0x688f08: sub             SP, SP, #8
    // 0x688f0c: CheckStackOverflow
    //     0x688f0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x688f10: cmp             SP, x16
    //     0x688f14: b.ls            #0x688fc8
    // 0x688f18: ldr             x3, [fp, #0x10]
    // 0x688f1c: LoadField: r4 = r3->field_27
    //     0x688f1c: ldur            w4, [x3, #0x27]
    // 0x688f20: DecompressPointer r4
    //     0x688f20: add             x4, x4, HEAP, lsl #32
    // 0x688f24: stur            x4, [fp, #-8]
    // 0x688f28: cmp             w4, NULL
    // 0x688f2c: b.eq            #0x688fa8
    // 0x688f30: mov             x0, x4
    // 0x688f34: r2 = Null
    //     0x688f34: mov             x2, NULL
    // 0x688f38: r1 = Null
    //     0x688f38: mov             x1, NULL
    // 0x688f3c: r4 = LoadClassIdInstr(r0)
    //     0x688f3c: ldur            x4, [x0, #-1]
    //     0x688f40: ubfx            x4, x4, #0xc, #0x14
    // 0x688f44: sub             x4, x4, #0x80d
    // 0x688f48: cmp             x4, #1
    // 0x688f4c: b.ls            #0x688f64
    // 0x688f50: r8 = BoxConstraints
    //     0x688f50: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x688f54: ldr             x8, [x8, #0x1d0]
    // 0x688f58: r3 = Null
    //     0x688f58: add             x3, PP, #0x38, lsl #12  ; [pp+0x384a8] Null
    //     0x688f5c: ldr             x3, [x3, #0x4a8]
    // 0x688f60: r0 = BoxConstraints()
    //     0x688f60: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x688f64: ldr             x16, [fp, #0x10]
    // 0x688f68: ldur            lr, [fp, #-8]
    // 0x688f6c: stp             lr, x16, [SP, #-0x10]!
    // 0x688f70: r0 = _sizeForConstraints()
    //     0x688f70: bl              #0x62b884  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::_sizeForConstraints
    // 0x688f74: add             SP, SP, #0x10
    // 0x688f78: ldr             x1, [fp, #0x10]
    // 0x688f7c: StoreField: r1->field_57 = r0
    //     0x688f7c: stur            w0, [x1, #0x57]
    //     0x688f80: ldurb           w16, [x1, #-1]
    //     0x688f84: ldurb           w17, [x0, #-1]
    //     0x688f88: and             x16, x17, x16, lsr #2
    //     0x688f8c: tst             x16, HEAP, lsr #32
    //     0x688f90: b.eq            #0x688f98
    //     0x688f94: bl              #0xd6826c
    // 0x688f98: r0 = Null
    //     0x688f98: mov             x0, NULL
    // 0x688f9c: LeaveFrame
    //     0x688f9c: mov             SP, fp
    //     0x688fa0: ldp             fp, lr, [SP], #0x10
    // 0x688fa4: ret
    //     0x688fa4: ret             
    // 0x688fa8: r0 = StateError()
    //     0x688fa8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x688fac: mov             x1, x0
    // 0x688fb0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x688fb0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x688fb4: ldr             x0, [x0, #0x1e8]
    // 0x688fb8: StoreField: r1->field_b = r0
    //     0x688fb8: stur            w0, [x1, #0xb]
    // 0x688fbc: mov             x0, x1
    // 0x688fc0: r0 = Throw()
    //     0x688fc0: bl              #0xd67e38  ; ThrowStub
    // 0x688fc4: brk             #0
    // 0x688fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x688fc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x688fcc: b               #0x688f18
  }
  set _ image=(/* No info */) {
    // ** addr: 0x6c19a0, size: 0x114
    // 0x6c19a0: EnterFrame
    //     0x6c19a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c19a4: mov             fp, SP
    // 0x6c19a8: CheckStackOverflow
    //     0x6c19a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c19ac: cmp             SP, x16
    //     0x6c19b0: b.ls            #0x6c1aac
    // 0x6c19b4: ldr             x0, [fp, #0x18]
    // 0x6c19b8: LoadField: r1 = r0->field_7f
    //     0x6c19b8: ldur            w1, [x0, #0x7f]
    // 0x6c19bc: DecompressPointer r1
    //     0x6c19bc: add             x1, x1, HEAP, lsl #32
    // 0x6c19c0: ldr             x2, [fp, #0x10]
    // 0x6c19c4: cmp             w2, w1
    // 0x6c19c8: b.ne            #0x6c19dc
    // 0x6c19cc: r0 = Null
    //     0x6c19cc: mov             x0, NULL
    // 0x6c19d0: LeaveFrame
    //     0x6c19d0: mov             SP, fp
    //     0x6c19d4: ldp             fp, lr, [SP], #0x10
    // 0x6c19d8: ret
    //     0x6c19d8: ret             
    // 0x6c19dc: cmp             w2, NULL
    // 0x6c19e0: b.eq            #0x6c1a20
    // 0x6c19e4: cmp             w1, NULL
    // 0x6c19e8: b.eq            #0x6c1a20
    // 0x6c19ec: LoadField: r3 = r1->field_7
    //     0x6c19ec: ldur            w3, [x1, #7]
    // 0x6c19f0: DecompressPointer r3
    //     0x6c19f0: add             x3, x3, HEAP, lsl #32
    // 0x6c19f4: LoadField: r4 = r2->field_7
    //     0x6c19f4: ldur            w4, [x2, #7]
    // 0x6c19f8: DecompressPointer r4
    //     0x6c19f8: add             x4, x4, HEAP, lsl #32
    // 0x6c19fc: cmp             w3, w4
    // 0x6c1a00: b.ne            #0x6c1a20
    // 0x6c1a04: SaveReg r2
    //     0x6c1a04: str             x2, [SP, #-8]!
    // 0x6c1a08: r0 = dispose()
    //     0x6c1a08: bl              #0x6522a4  ; [dart:ui] Image::dispose
    // 0x6c1a0c: add             SP, SP, #8
    // 0x6c1a10: r0 = Null
    //     0x6c1a10: mov             x0, NULL
    // 0x6c1a14: LeaveFrame
    //     0x6c1a14: mov             SP, fp
    //     0x6c1a18: ldp             fp, lr, [SP], #0x10
    // 0x6c1a1c: ret
    //     0x6c1a1c: ret             
    // 0x6c1a20: cmp             w1, NULL
    // 0x6c1a24: b.ne            #0x6c1a30
    // 0x6c1a28: mov             x1, x0
    // 0x6c1a2c: b               #0x6c1a40
    // 0x6c1a30: SaveReg r1
    //     0x6c1a30: str             x1, [SP, #-8]!
    // 0x6c1a34: r0 = dispose()
    //     0x6c1a34: bl              #0x6522a4  ; [dart:ui] Image::dispose
    // 0x6c1a38: add             SP, SP, #8
    // 0x6c1a3c: ldr             x1, [fp, #0x18]
    // 0x6c1a40: ldr             x0, [fp, #0x10]
    // 0x6c1a44: StoreField: r1->field_7f = r0
    //     0x6c1a44: stur            w0, [x1, #0x7f]
    //     0x6c1a48: ldurb           w16, [x1, #-1]
    //     0x6c1a4c: ldurb           w17, [x0, #-1]
    //     0x6c1a50: and             x16, x17, x16, lsr #2
    //     0x6c1a54: tst             x16, HEAP, lsr #32
    //     0x6c1a58: b.eq            #0x6c1a60
    //     0x6c1a5c: bl              #0xd6826c
    // 0x6c1a60: SaveReg r1
    //     0x6c1a60: str             x1, [SP, #-8]!
    // 0x6c1a64: r0 = markNeedsPaint()
    //     0x6c1a64: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c1a68: add             SP, SP, #8
    // 0x6c1a6c: ldr             x0, [fp, #0x18]
    // 0x6c1a70: LoadField: r1 = r0->field_87
    //     0x6c1a70: ldur            w1, [x0, #0x87]
    // 0x6c1a74: DecompressPointer r1
    //     0x6c1a74: add             x1, x1, HEAP, lsl #32
    // 0x6c1a78: cmp             w1, NULL
    // 0x6c1a7c: b.eq            #0x6c1a90
    // 0x6c1a80: LoadField: r1 = r0->field_8b
    //     0x6c1a80: ldur            w1, [x0, #0x8b]
    // 0x6c1a84: DecompressPointer r1
    //     0x6c1a84: add             x1, x1, HEAP, lsl #32
    // 0x6c1a88: cmp             w1, NULL
    // 0x6c1a8c: b.ne            #0x6c1a9c
    // 0x6c1a90: SaveReg r0
    //     0x6c1a90: str             x0, [SP, #-8]!
    // 0x6c1a94: r0 = markNeedsLayout()
    //     0x6c1a94: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c1a98: add             SP, SP, #8
    // 0x6c1a9c: r0 = Null
    //     0x6c1a9c: mov             x0, NULL
    // 0x6c1aa0: LeaveFrame
    //     0x6c1aa0: mov             SP, fp
    //     0x6c1aa4: ldp             fp, lr, [SP], #0x10
    // 0x6c1aa8: ret
    //     0x6c1aa8: ret             
    // 0x6c1aac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c1aac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c1ab0: b               #0x6c19b4
  }
  set _ layoutInsets=(/* No info */) {
    // ** addr: 0x6c9e78, size: 0x78
    // 0x6c9e78: EnterFrame
    //     0x6c9e78: stp             fp, lr, [SP, #-0x10]!
    //     0x6c9e7c: mov             fp, SP
    // 0x6c9e80: CheckStackOverflow
    //     0x6c9e80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c9e84: cmp             SP, x16
    //     0x6c9e88: b.ls            #0x6c9ee8
    // 0x6c9e8c: r16 = Instance_EdgeInsets
    //     0x6c9e8c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x6c9e90: ldr             x16, [x16, #0xbd8]
    // 0x6c9e94: r30 = Instance_EdgeInsets
    //     0x6c9e94: add             lr, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x6c9e98: ldr             lr, [lr, #0xbd8]
    // 0x6c9e9c: stp             lr, x16, [SP, #-0x10]!
    // 0x6c9ea0: r0 = ==()
    //     0x6c9ea0: bl              #0xc9d2f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0x6c9ea4: add             SP, SP, #0x10
    // 0x6c9ea8: tbnz            w0, #4, #0x6c9ebc
    // 0x6c9eac: r0 = Null
    //     0x6c9eac: mov             x0, NULL
    // 0x6c9eb0: LeaveFrame
    //     0x6c9eb0: mov             SP, fp
    //     0x6c9eb4: ldp             fp, lr, [SP], #0x10
    // 0x6c9eb8: ret
    //     0x6c9eb8: ret             
    // 0x6c9ebc: ldr             x1, [fp, #0x18]
    // 0x6c9ec0: r0 = Instance_EdgeInsets
    //     0x6c9ec0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x6c9ec4: ldr             x0, [x0, #0xbd8]
    // 0x6c9ec8: StoreField: r1->field_5f = r0
    //     0x6c9ec8: stur            w0, [x1, #0x5f]
    // 0x6c9ecc: SaveReg r1
    //     0x6c9ecc: str             x1, [SP, #-8]!
    // 0x6c9ed0: r0 = markNeedsPaint()
    //     0x6c9ed0: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c9ed4: add             SP, SP, #8
    // 0x6c9ed8: r0 = Null
    //     0x6c9ed8: mov             x0, NULL
    // 0x6c9edc: LeaveFrame
    //     0x6c9edc: mov             SP, fp
    //     0x6c9ee0: ldp             fp, lr, [SP], #0x10
    // 0x6c9ee4: ret
    //     0x6c9ee4: ret             
    // 0x6c9ee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c9ee8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c9eec: b               #0x6c9e8c
  }
  set _ editActionDetails=(/* No info */) {
    // ** addr: 0x6c9ef0, size: 0x80
    // 0x6c9ef0: EnterFrame
    //     0x6c9ef0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c9ef4: mov             fp, SP
    // 0x6c9ef8: CheckStackOverflow
    //     0x6c9ef8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c9efc: cmp             SP, x16
    //     0x6c9f00: b.ls            #0x6c9f68
    // 0x6c9f04: ldr             x1, [fp, #0x18]
    // 0x6c9f08: LoadField: r0 = r1->field_63
    //     0x6c9f08: ldur            w0, [x1, #0x63]
    // 0x6c9f0c: DecompressPointer r0
    //     0x6c9f0c: add             x0, x0, HEAP, lsl #32
    // 0x6c9f10: ldr             x2, [fp, #0x10]
    // 0x6c9f14: cmp             w2, w0
    // 0x6c9f18: b.ne            #0x6c9f2c
    // 0x6c9f1c: r0 = Null
    //     0x6c9f1c: mov             x0, NULL
    // 0x6c9f20: LeaveFrame
    //     0x6c9f20: mov             SP, fp
    //     0x6c9f24: ldp             fp, lr, [SP], #0x10
    // 0x6c9f28: ret
    //     0x6c9f28: ret             
    // 0x6c9f2c: mov             x0, x2
    // 0x6c9f30: StoreField: r1->field_63 = r0
    //     0x6c9f30: stur            w0, [x1, #0x63]
    //     0x6c9f34: ldurb           w16, [x1, #-1]
    //     0x6c9f38: ldurb           w17, [x0, #-1]
    //     0x6c9f3c: and             x16, x17, x16, lsr #2
    //     0x6c9f40: tst             x16, HEAP, lsr #32
    //     0x6c9f44: b.eq            #0x6c9f4c
    //     0x6c9f48: bl              #0xd6826c
    // 0x6c9f4c: SaveReg r1
    //     0x6c9f4c: str             x1, [SP, #-8]!
    // 0x6c9f50: r0 = markNeedsPaint()
    //     0x6c9f50: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c9f54: add             SP, SP, #8
    // 0x6c9f58: r0 = Null
    //     0x6c9f58: mov             x0, NULL
    // 0x6c9f5c: LeaveFrame
    //     0x6c9f5c: mov             SP, fp
    //     0x6c9f60: ldp             fp, lr, [SP], #0x10
    // 0x6c9f64: ret
    //     0x6c9f64: ret             
    // 0x6c9f68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c9f68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c9f6c: b               #0x6c9f04
  }
  set _ gestureDetails=(/* No info */) {
    // ** addr: 0x6c9f70, size: 0xa0
    // 0x6c9f70: EnterFrame
    //     0x6c9f70: stp             fp, lr, [SP, #-0x10]!
    //     0x6c9f74: mov             fp, SP
    // 0x6c9f78: CheckStackOverflow
    //     0x6c9f78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c9f7c: cmp             SP, x16
    //     0x6c9f80: b.ls            #0x6ca008
    // 0x6c9f84: ldr             x1, [fp, #0x18]
    // 0x6c9f88: LoadField: r0 = r1->field_67
    //     0x6c9f88: ldur            w0, [x1, #0x67]
    // 0x6c9f8c: DecompressPointer r0
    //     0x6c9f8c: add             x0, x0, HEAP, lsl #32
    // 0x6c9f90: ldr             x2, [fp, #0x10]
    // 0x6c9f94: r3 = LoadClassIdInstr(r2)
    //     0x6c9f94: ldur            x3, [x2, #-1]
    //     0x6c9f98: ubfx            x3, x3, #0xc, #0x14
    // 0x6c9f9c: stp             x0, x2, [SP, #-0x10]!
    // 0x6c9fa0: mov             x0, x3
    // 0x6c9fa4: mov             lr, x0
    // 0x6c9fa8: ldr             lr, [x21, lr, lsl #3]
    // 0x6c9fac: blr             lr
    // 0x6c9fb0: add             SP, SP, #0x10
    // 0x6c9fb4: tbnz            w0, #4, #0x6c9fc8
    // 0x6c9fb8: r0 = Null
    //     0x6c9fb8: mov             x0, NULL
    // 0x6c9fbc: LeaveFrame
    //     0x6c9fbc: mov             SP, fp
    //     0x6c9fc0: ldp             fp, lr, [SP], #0x10
    // 0x6c9fc4: ret
    //     0x6c9fc4: ret             
    // 0x6c9fc8: ldr             x1, [fp, #0x18]
    // 0x6c9fcc: ldr             x0, [fp, #0x10]
    // 0x6c9fd0: StoreField: r1->field_67 = r0
    //     0x6c9fd0: stur            w0, [x1, #0x67]
    //     0x6c9fd4: ldurb           w16, [x1, #-1]
    //     0x6c9fd8: ldurb           w17, [x0, #-1]
    //     0x6c9fdc: and             x16, x17, x16, lsr #2
    //     0x6c9fe0: tst             x16, HEAP, lsr #32
    //     0x6c9fe4: b.eq            #0x6c9fec
    //     0x6c9fe8: bl              #0xd6826c
    // 0x6c9fec: SaveReg r1
    //     0x6c9fec: str             x1, [SP, #-8]!
    // 0x6c9ff0: r0 = markNeedsPaint()
    //     0x6c9ff0: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c9ff4: add             SP, SP, #8
    // 0x6c9ff8: r0 = Null
    //     0x6c9ff8: mov             x0, NULL
    // 0x6c9ffc: LeaveFrame
    //     0x6c9ffc: mov             SP, fp
    //     0x6ca000: ldp             fp, lr, [SP], #0x10
    // 0x6ca004: ret
    //     0x6ca004: ret             
    // 0x6ca008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca008: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca00c: b               #0x6c9f84
  }
  set _ invertColors=(/* No info */) {
    // ** addr: 0x6ca010, size: 0x64
    // 0x6ca010: EnterFrame
    //     0x6ca010: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca014: mov             fp, SP
    // 0x6ca018: CheckStackOverflow
    //     0x6ca018: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca01c: cmp             SP, x16
    //     0x6ca020: b.ls            #0x6ca06c
    // 0x6ca024: ldr             x0, [fp, #0x18]
    // 0x6ca028: LoadField: r1 = r0->field_bb
    //     0x6ca028: ldur            w1, [x0, #0xbb]
    // 0x6ca02c: DecompressPointer r1
    //     0x6ca02c: add             x1, x1, HEAP, lsl #32
    // 0x6ca030: ldr             x2, [fp, #0x10]
    // 0x6ca034: cmp             w2, w1
    // 0x6ca038: b.ne            #0x6ca04c
    // 0x6ca03c: r0 = Null
    //     0x6ca03c: mov             x0, NULL
    // 0x6ca040: LeaveFrame
    //     0x6ca040: mov             SP, fp
    //     0x6ca044: ldp             fp, lr, [SP], #0x10
    // 0x6ca048: ret
    //     0x6ca048: ret             
    // 0x6ca04c: StoreField: r0->field_bb = r2
    //     0x6ca04c: stur            w2, [x0, #0xbb]
    // 0x6ca050: SaveReg r0
    //     0x6ca050: str             x0, [SP, #-8]!
    // 0x6ca054: r0 = markNeedsPaint()
    //     0x6ca054: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6ca058: add             SP, SP, #8
    // 0x6ca05c: r0 = Null
    //     0x6ca05c: mov             x0, NULL
    // 0x6ca060: LeaveFrame
    //     0x6ca060: mov             SP, fp
    //     0x6ca064: ldp             fp, lr, [SP], #0x10
    // 0x6ca068: ret
    //     0x6ca068: ret             
    // 0x6ca06c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca06c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca070: b               #0x6ca024
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6ca074, size: 0x80
    // 0x6ca074: EnterFrame
    //     0x6ca074: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca078: mov             fp, SP
    // 0x6ca07c: CheckStackOverflow
    //     0x6ca07c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca080: cmp             SP, x16
    //     0x6ca084: b.ls            #0x6ca0ec
    // 0x6ca088: ldr             x1, [fp, #0x18]
    // 0x6ca08c: LoadField: r0 = r1->field_c3
    //     0x6ca08c: ldur            w0, [x1, #0xc3]
    // 0x6ca090: DecompressPointer r0
    //     0x6ca090: add             x0, x0, HEAP, lsl #32
    // 0x6ca094: ldr             x2, [fp, #0x10]
    // 0x6ca098: cmp             w0, w2
    // 0x6ca09c: b.ne            #0x6ca0b0
    // 0x6ca0a0: r0 = Null
    //     0x6ca0a0: mov             x0, NULL
    // 0x6ca0a4: LeaveFrame
    //     0x6ca0a4: mov             SP, fp
    //     0x6ca0a8: ldp             fp, lr, [SP], #0x10
    // 0x6ca0ac: ret
    //     0x6ca0ac: ret             
    // 0x6ca0b0: mov             x0, x2
    // 0x6ca0b4: StoreField: r1->field_c3 = r0
    //     0x6ca0b4: stur            w0, [x1, #0xc3]
    //     0x6ca0b8: ldurb           w16, [x1, #-1]
    //     0x6ca0bc: ldurb           w17, [x0, #-1]
    //     0x6ca0c0: and             x16, x17, x16, lsr #2
    //     0x6ca0c4: tst             x16, HEAP, lsr #32
    //     0x6ca0c8: b.eq            #0x6ca0d0
    //     0x6ca0cc: bl              #0xd6826c
    // 0x6ca0d0: SaveReg r1
    //     0x6ca0d0: str             x1, [SP, #-8]!
    // 0x6ca0d4: r0 = _markNeedResolution()
    //     0x6ca0d4: bl              #0x6ca0f4  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::_markNeedResolution
    // 0x6ca0d8: add             SP, SP, #8
    // 0x6ca0dc: r0 = Null
    //     0x6ca0dc: mov             x0, NULL
    // 0x6ca0e0: LeaveFrame
    //     0x6ca0e0: mov             SP, fp
    //     0x6ca0e4: ldp             fp, lr, [SP], #0x10
    // 0x6ca0e8: ret
    //     0x6ca0e8: ret             
    // 0x6ca0ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca0ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca0f0: b               #0x6ca088
  }
  _ _markNeedResolution(/* No info */) {
    // ** addr: 0x6ca0f4, size: 0x44
    // 0x6ca0f4: EnterFrame
    //     0x6ca0f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca0f8: mov             fp, SP
    // 0x6ca0fc: CheckStackOverflow
    //     0x6ca0fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca100: cmp             SP, x16
    //     0x6ca104: b.ls            #0x6ca130
    // 0x6ca108: ldr             x0, [fp, #0x10]
    // 0x6ca10c: StoreField: r0->field_77 = rNULL
    //     0x6ca10c: stur            NULL, [x0, #0x77]
    // 0x6ca110: StoreField: r0->field_7b = rNULL
    //     0x6ca110: stur            NULL, [x0, #0x7b]
    // 0x6ca114: SaveReg r0
    //     0x6ca114: str             x0, [SP, #-8]!
    // 0x6ca118: r0 = markNeedsPaint()
    //     0x6ca118: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6ca11c: add             SP, SP, #8
    // 0x6ca120: r0 = Null
    //     0x6ca120: mov             x0, NULL
    // 0x6ca124: LeaveFrame
    //     0x6ca124: mov             SP, fp
    //     0x6ca128: ldp             fp, lr, [SP], #0x10
    // 0x6ca12c: ret
    //     0x6ca12c: ret             
    // 0x6ca130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca130: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca134: b               #0x6ca108
  }
  set _ fit=(/* No info */) {
    // ** addr: 0x6ca138, size: 0x80
    // 0x6ca138: EnterFrame
    //     0x6ca138: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca13c: mov             fp, SP
    // 0x6ca140: CheckStackOverflow
    //     0x6ca140: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca144: cmp             SP, x16
    //     0x6ca148: b.ls            #0x6ca1b0
    // 0x6ca14c: ldr             x1, [fp, #0x18]
    // 0x6ca150: LoadField: r0 = r1->field_ab
    //     0x6ca150: ldur            w0, [x1, #0xab]
    // 0x6ca154: DecompressPointer r0
    //     0x6ca154: add             x0, x0, HEAP, lsl #32
    // 0x6ca158: ldr             x2, [fp, #0x10]
    // 0x6ca15c: cmp             w2, w0
    // 0x6ca160: b.ne            #0x6ca174
    // 0x6ca164: r0 = Null
    //     0x6ca164: mov             x0, NULL
    // 0x6ca168: LeaveFrame
    //     0x6ca168: mov             SP, fp
    //     0x6ca16c: ldp             fp, lr, [SP], #0x10
    // 0x6ca170: ret
    //     0x6ca170: ret             
    // 0x6ca174: mov             x0, x2
    // 0x6ca178: StoreField: r1->field_ab = r0
    //     0x6ca178: stur            w0, [x1, #0xab]
    //     0x6ca17c: ldurb           w16, [x1, #-1]
    //     0x6ca180: ldurb           w17, [x0, #-1]
    //     0x6ca184: and             x16, x17, x16, lsr #2
    //     0x6ca188: tst             x16, HEAP, lsr #32
    //     0x6ca18c: b.eq            #0x6ca194
    //     0x6ca190: bl              #0xd6826c
    // 0x6ca194: SaveReg r1
    //     0x6ca194: str             x1, [SP, #-8]!
    // 0x6ca198: r0 = markNeedsPaint()
    //     0x6ca198: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6ca19c: add             SP, SP, #8
    // 0x6ca1a0: r0 = Null
    //     0x6ca1a0: mov             x0, NULL
    // 0x6ca1a4: LeaveFrame
    //     0x6ca1a4: mov             SP, fp
    //     0x6ca1a8: ldp             fp, lr, [SP], #0x10
    // 0x6ca1ac: ret
    //     0x6ca1ac: ret             
    // 0x6ca1b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca1b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca1b4: b               #0x6ca14c
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0x6ca1b8, size: 0x78
    // 0x6ca1b8: EnterFrame
    //     0x6ca1b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca1bc: mov             fp, SP
    // 0x6ca1c0: CheckStackOverflow
    //     0x6ca1c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca1c4: cmp             SP, x16
    //     0x6ca1c8: b.ls            #0x6ca228
    // 0x6ca1cc: r16 = Instance_Alignment
    //     0x6ca1cc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6ca1d0: ldr             x16, [x16, #0xc70]
    // 0x6ca1d4: r30 = Instance_Alignment
    //     0x6ca1d4: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6ca1d8: ldr             lr, [lr, #0xc70]
    // 0x6ca1dc: stp             lr, x16, [SP, #-0x10]!
    // 0x6ca1e0: r0 = ==()
    //     0x6ca1e0: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x6ca1e4: add             SP, SP, #0x10
    // 0x6ca1e8: tbnz            w0, #4, #0x6ca1fc
    // 0x6ca1ec: r0 = Null
    //     0x6ca1ec: mov             x0, NULL
    // 0x6ca1f0: LeaveFrame
    //     0x6ca1f0: mov             SP, fp
    //     0x6ca1f4: ldp             fp, lr, [SP], #0x10
    // 0x6ca1f8: ret
    //     0x6ca1f8: ret             
    // 0x6ca1fc: ldr             x1, [fp, #0x18]
    // 0x6ca200: r0 = Instance_Alignment
    //     0x6ca200: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6ca204: ldr             x0, [x0, #0xc70]
    // 0x6ca208: StoreField: r1->field_af = r0
    //     0x6ca208: stur            w0, [x1, #0xaf]
    // 0x6ca20c: SaveReg r1
    //     0x6ca20c: str             x1, [SP, #-8]!
    // 0x6ca210: r0 = _markNeedResolution()
    //     0x6ca210: bl              #0x6ca0f4  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::_markNeedResolution
    // 0x6ca214: add             SP, SP, #8
    // 0x6ca218: r0 = Null
    //     0x6ca218: mov             x0, NULL
    // 0x6ca21c: LeaveFrame
    //     0x6ca21c: mov             SP, fp
    //     0x6ca220: ldp             fp, lr, [SP], #0x10
    // 0x6ca224: ret
    //     0x6ca224: ret             
    // 0x6ca228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca228: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca22c: b               #0x6ca1cc
  }
  set _ opacity=(/* No info */) {
    // ** addr: 0x6ca230, size: 0x11c
    // 0x6ca230: EnterFrame
    //     0x6ca230: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca234: mov             fp, SP
    // 0x6ca238: AllocStack(0x8)
    //     0x6ca238: sub             SP, SP, #8
    // 0x6ca23c: CheckStackOverflow
    //     0x6ca23c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca240: cmp             SP, x16
    //     0x6ca244: b.ls            #0x6ca344
    // 0x6ca248: ldr             x0, [fp, #0x18]
    // 0x6ca24c: LoadField: r1 = r0->field_9f
    //     0x6ca24c: ldur            w1, [x0, #0x9f]
    // 0x6ca250: DecompressPointer r1
    //     0x6ca250: add             x1, x1, HEAP, lsl #32
    // 0x6ca254: ldr             x2, [fp, #0x10]
    // 0x6ca258: stur            x1, [fp, #-8]
    // 0x6ca25c: cmp             w2, w1
    // 0x6ca260: b.ne            #0x6ca274
    // 0x6ca264: r0 = Null
    //     0x6ca264: mov             x0, NULL
    // 0x6ca268: LeaveFrame
    //     0x6ca268: mov             SP, fp
    //     0x6ca26c: ldp             fp, lr, [SP], #0x10
    // 0x6ca270: ret
    //     0x6ca270: ret             
    // 0x6ca274: LoadField: r3 = r0->field_f
    //     0x6ca274: ldur            w3, [x0, #0xf]
    // 0x6ca278: DecompressPointer r3
    //     0x6ca278: add             x3, x3, HEAP, lsl #32
    // 0x6ca27c: cmp             w3, NULL
    // 0x6ca280: b.eq            #0x6ca2c0
    // 0x6ca284: cmp             w1, NULL
    // 0x6ca288: b.eq            #0x6ca2c0
    // 0x6ca28c: r1 = 1
    //     0x6ca28c: mov             x1, #1
    // 0x6ca290: r0 = AllocateContext()
    //     0x6ca290: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6ca294: mov             x1, x0
    // 0x6ca298: ldr             x0, [fp, #0x18]
    // 0x6ca29c: StoreField: r1->field_f = r0
    //     0x6ca29c: stur            w0, [x1, #0xf]
    // 0x6ca2a0: mov             x2, x1
    // 0x6ca2a4: r1 = Function 'markNeedsPaint':.
    //     0x6ca2a4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x6ca2a8: ldr             x1, [x1, #0xf60]
    // 0x6ca2ac: r0 = AllocateClosure()
    //     0x6ca2ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ca2b0: ldur            x16, [fp, #-8]
    // 0x6ca2b4: stp             x0, x16, [SP, #-0x10]!
    // 0x6ca2b8: r0 = removeListener()
    //     0x6ca2b8: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0x6ca2bc: add             SP, SP, #0x10
    // 0x6ca2c0: ldr             x1, [fp, #0x18]
    // 0x6ca2c4: ldr             x0, [fp, #0x10]
    // 0x6ca2c8: StoreField: r1->field_9f = r0
    //     0x6ca2c8: stur            w0, [x1, #0x9f]
    //     0x6ca2cc: ldurb           w16, [x1, #-1]
    //     0x6ca2d0: ldurb           w17, [x0, #-1]
    //     0x6ca2d4: and             x16, x17, x16, lsr #2
    //     0x6ca2d8: tst             x16, HEAP, lsr #32
    //     0x6ca2dc: b.eq            #0x6ca2e4
    //     0x6ca2e0: bl              #0xd6826c
    // 0x6ca2e4: LoadField: r0 = r1->field_f
    //     0x6ca2e4: ldur            w0, [x1, #0xf]
    // 0x6ca2e8: DecompressPointer r0
    //     0x6ca2e8: add             x0, x0, HEAP, lsl #32
    // 0x6ca2ec: cmp             w0, NULL
    // 0x6ca2f0: b.eq            #0x6ca334
    // 0x6ca2f4: ldr             x0, [fp, #0x10]
    // 0x6ca2f8: cmp             w0, NULL
    // 0x6ca2fc: b.eq            #0x6ca334
    // 0x6ca300: r1 = 1
    //     0x6ca300: mov             x1, #1
    // 0x6ca304: r0 = AllocateContext()
    //     0x6ca304: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6ca308: mov             x1, x0
    // 0x6ca30c: ldr             x0, [fp, #0x18]
    // 0x6ca310: StoreField: r1->field_f = r0
    //     0x6ca310: stur            w0, [x1, #0xf]
    // 0x6ca314: mov             x2, x1
    // 0x6ca318: r1 = Function 'markNeedsPaint':.
    //     0x6ca318: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x6ca31c: ldr             x1, [x1, #0xf60]
    // 0x6ca320: r0 = AllocateClosure()
    //     0x6ca320: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ca324: ldr             x16, [fp, #0x10]
    // 0x6ca328: stp             x0, x16, [SP, #-0x10]!
    // 0x6ca32c: r0 = addActionListener()
    //     0x6ca32c: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x6ca330: add             SP, SP, #0x10
    // 0x6ca334: r0 = Null
    //     0x6ca334: mov             x0, NULL
    // 0x6ca338: LeaveFrame
    //     0x6ca338: mov             SP, fp
    //     0x6ca33c: ldp             fp, lr, [SP], #0x10
    // 0x6ca340: ret
    //     0x6ca340: ret             
    // 0x6ca344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca344: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca348: b               #0x6ca248
  }
  set _ scale=(/* No info */) {
    // ** addr: 0x6ca34c, size: 0x64
    // 0x6ca34c: EnterFrame
    //     0x6ca34c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca350: mov             fp, SP
    // 0x6ca354: CheckStackOverflow
    //     0x6ca354: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca358: cmp             SP, x16
    //     0x6ca35c: b.ls            #0x6ca3a8
    // 0x6ca360: ldr             x0, [fp, #0x18]
    // 0x6ca364: LoadField: d0 = r0->field_8f
    //     0x6ca364: ldur            d0, [x0, #0x8f]
    // 0x6ca368: ldr             d1, [fp, #0x10]
    // 0x6ca36c: fcmp            d1, d0
    // 0x6ca370: b.vs            #0x6ca388
    // 0x6ca374: b.ne            #0x6ca388
    // 0x6ca378: r0 = Null
    //     0x6ca378: mov             x0, NULL
    // 0x6ca37c: LeaveFrame
    //     0x6ca37c: mov             SP, fp
    //     0x6ca380: ldp             fp, lr, [SP], #0x10
    // 0x6ca384: ret
    //     0x6ca384: ret             
    // 0x6ca388: StoreField: r0->field_8f = d1
    //     0x6ca388: stur            d1, [x0, #0x8f]
    // 0x6ca38c: SaveReg r0
    //     0x6ca38c: str             x0, [SP, #-8]!
    // 0x6ca390: r0 = markNeedsLayout()
    //     0x6ca390: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6ca394: add             SP, SP, #8
    // 0x6ca398: r0 = Null
    //     0x6ca398: mov             x0, NULL
    // 0x6ca39c: LeaveFrame
    //     0x6ca39c: mov             SP, fp
    //     0x6ca3a0: ldp             fp, lr, [SP], #0x10
    // 0x6ca3a4: ret
    //     0x6ca3a4: ret             
    // 0x6ca3a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca3a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca3ac: b               #0x6ca360
  }
  set _ height=(/* No info */) {
    // ** addr: 0x6ca3b0, size: 0xa0
    // 0x6ca3b0: EnterFrame
    //     0x6ca3b0: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca3b4: mov             fp, SP
    // 0x6ca3b8: CheckStackOverflow
    //     0x6ca3b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca3bc: cmp             SP, x16
    //     0x6ca3c0: b.ls            #0x6ca448
    // 0x6ca3c4: ldr             x1, [fp, #0x18]
    // 0x6ca3c8: LoadField: r0 = r1->field_8b
    //     0x6ca3c8: ldur            w0, [x1, #0x8b]
    // 0x6ca3cc: DecompressPointer r0
    //     0x6ca3cc: add             x0, x0, HEAP, lsl #32
    // 0x6ca3d0: ldr             x2, [fp, #0x10]
    // 0x6ca3d4: r3 = LoadClassIdInstr(r2)
    //     0x6ca3d4: ldur            x3, [x2, #-1]
    //     0x6ca3d8: ubfx            x3, x3, #0xc, #0x14
    // 0x6ca3dc: stp             x0, x2, [SP, #-0x10]!
    // 0x6ca3e0: mov             x0, x3
    // 0x6ca3e4: mov             lr, x0
    // 0x6ca3e8: ldr             lr, [x21, lr, lsl #3]
    // 0x6ca3ec: blr             lr
    // 0x6ca3f0: add             SP, SP, #0x10
    // 0x6ca3f4: tbnz            w0, #4, #0x6ca408
    // 0x6ca3f8: r0 = Null
    //     0x6ca3f8: mov             x0, NULL
    // 0x6ca3fc: LeaveFrame
    //     0x6ca3fc: mov             SP, fp
    //     0x6ca400: ldp             fp, lr, [SP], #0x10
    // 0x6ca404: ret
    //     0x6ca404: ret             
    // 0x6ca408: ldr             x1, [fp, #0x18]
    // 0x6ca40c: ldr             x0, [fp, #0x10]
    // 0x6ca410: StoreField: r1->field_8b = r0
    //     0x6ca410: stur            w0, [x1, #0x8b]
    //     0x6ca414: ldurb           w16, [x1, #-1]
    //     0x6ca418: ldurb           w17, [x0, #-1]
    //     0x6ca41c: and             x16, x17, x16, lsr #2
    //     0x6ca420: tst             x16, HEAP, lsr #32
    //     0x6ca424: b.eq            #0x6ca42c
    //     0x6ca428: bl              #0xd6826c
    // 0x6ca42c: SaveReg r1
    //     0x6ca42c: str             x1, [SP, #-8]!
    // 0x6ca430: r0 = markNeedsLayout()
    //     0x6ca430: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6ca434: add             SP, SP, #8
    // 0x6ca438: r0 = Null
    //     0x6ca438: mov             x0, NULL
    // 0x6ca43c: LeaveFrame
    //     0x6ca43c: mov             SP, fp
    //     0x6ca440: ldp             fp, lr, [SP], #0x10
    // 0x6ca444: ret
    //     0x6ca444: ret             
    // 0x6ca448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca448: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca44c: b               #0x6ca3c4
  }
  set _ width=(/* No info */) {
    // ** addr: 0x6ca450, size: 0xa0
    // 0x6ca450: EnterFrame
    //     0x6ca450: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca454: mov             fp, SP
    // 0x6ca458: CheckStackOverflow
    //     0x6ca458: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca45c: cmp             SP, x16
    //     0x6ca460: b.ls            #0x6ca4e8
    // 0x6ca464: ldr             x1, [fp, #0x18]
    // 0x6ca468: LoadField: r0 = r1->field_87
    //     0x6ca468: ldur            w0, [x1, #0x87]
    // 0x6ca46c: DecompressPointer r0
    //     0x6ca46c: add             x0, x0, HEAP, lsl #32
    // 0x6ca470: ldr             x2, [fp, #0x10]
    // 0x6ca474: r3 = LoadClassIdInstr(r2)
    //     0x6ca474: ldur            x3, [x2, #-1]
    //     0x6ca478: ubfx            x3, x3, #0xc, #0x14
    // 0x6ca47c: stp             x0, x2, [SP, #-0x10]!
    // 0x6ca480: mov             x0, x3
    // 0x6ca484: mov             lr, x0
    // 0x6ca488: ldr             lr, [x21, lr, lsl #3]
    // 0x6ca48c: blr             lr
    // 0x6ca490: add             SP, SP, #0x10
    // 0x6ca494: tbnz            w0, #4, #0x6ca4a8
    // 0x6ca498: r0 = Null
    //     0x6ca498: mov             x0, NULL
    // 0x6ca49c: LeaveFrame
    //     0x6ca49c: mov             SP, fp
    //     0x6ca4a0: ldp             fp, lr, [SP], #0x10
    // 0x6ca4a4: ret
    //     0x6ca4a4: ret             
    // 0x6ca4a8: ldr             x1, [fp, #0x18]
    // 0x6ca4ac: ldr             x0, [fp, #0x10]
    // 0x6ca4b0: StoreField: r1->field_87 = r0
    //     0x6ca4b0: stur            w0, [x1, #0x87]
    //     0x6ca4b4: ldurb           w16, [x1, #-1]
    //     0x6ca4b8: ldurb           w17, [x0, #-1]
    //     0x6ca4bc: and             x16, x17, x16, lsr #2
    //     0x6ca4c0: tst             x16, HEAP, lsr #32
    //     0x6ca4c4: b.eq            #0x6ca4cc
    //     0x6ca4c8: bl              #0xd6826c
    // 0x6ca4cc: SaveReg r1
    //     0x6ca4cc: str             x1, [SP, #-8]!
    // 0x6ca4d0: r0 = markNeedsLayout()
    //     0x6ca4d0: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6ca4d4: add             SP, SP, #8
    // 0x6ca4d8: r0 = Null
    //     0x6ca4d8: mov             x0, NULL
    // 0x6ca4dc: LeaveFrame
    //     0x6ca4dc: mov             SP, fp
    //     0x6ca4e0: ldp             fp, lr, [SP], #0x10
    // 0x6ca4e4: ret
    //     0x6ca4e4: ret             
    // 0x6ca4e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca4e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca4ec: b               #0x6ca464
  }
  _ ExtendedRenderImage(/* No info */) {
    // ** addr: 0x6edc88, size: 0x1b8
    // 0x6edc88: EnterFrame
    //     0x6edc88: stp             fp, lr, [SP, #-0x10]!
    //     0x6edc8c: mov             fp, SP
    // 0x6edc90: r5 = Instance_Alignment
    //     0x6edc90: add             x5, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6edc94: ldr             x5, [x5, #0xc70]
    // 0x6edc98: r4 = Instance_ImageRepeat
    //     0x6edc98: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0x6edc9c: ldr             x4, [x4, #0x540]
    // 0x6edca0: r3 = false
    //     0x6edca0: add             x3, NULL, #0x30  ; false
    // 0x6edca4: r2 = Instance_FilterQuality
    //     0x6edca4: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0x6edca8: ldr             x2, [x2, #0x548]
    // 0x6edcac: r1 = Instance_EdgeInsets
    //     0x6edcac: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x6edcb0: ldr             x1, [x1, #0xbd8]
    // 0x6edcb4: CheckStackOverflow
    //     0x6edcb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6edcb8: cmp             SP, x16
    //     0x6edcbc: b.ls            #0x6ede38
    // 0x6edcc0: ldr             x0, [fp, #0x60]
    // 0x6edcc4: ldr             x6, [fp, #0x68]
    // 0x6edcc8: StoreField: r6->field_83 = r0
    //     0x6edcc8: stur            w0, [x6, #0x83]
    //     0x6edccc: ldurb           w16, [x6, #-1]
    //     0x6edcd0: ldurb           w17, [x0, #-1]
    //     0x6edcd4: and             x16, x17, x16, lsr #2
    //     0x6edcd8: tst             x16, HEAP, lsr #32
    //     0x6edcdc: b.eq            #0x6edce4
    //     0x6edce0: bl              #0xd6830c
    // 0x6edce4: ldr             x0, [fp, #0x38]
    // 0x6edce8: StoreField: r6->field_7f = r0
    //     0x6edce8: stur            w0, [x6, #0x7f]
    //     0x6edcec: ldurb           w16, [x6, #-1]
    //     0x6edcf0: ldurb           w17, [x0, #-1]
    //     0x6edcf4: and             x16, x17, x16, lsr #2
    //     0x6edcf8: tst             x16, HEAP, lsr #32
    //     0x6edcfc: b.eq            #0x6edd04
    //     0x6edd00: bl              #0xd6830c
    // 0x6edd04: ldr             x0, [fp, #0x10]
    // 0x6edd08: StoreField: r6->field_87 = r0
    //     0x6edd08: stur            w0, [x6, #0x87]
    //     0x6edd0c: ldurb           w16, [x6, #-1]
    //     0x6edd10: ldurb           w17, [x0, #-1]
    //     0x6edd14: and             x16, x17, x16, lsr #2
    //     0x6edd18: tst             x16, HEAP, lsr #32
    //     0x6edd1c: b.eq            #0x6edd24
    //     0x6edd20: bl              #0xd6830c
    // 0x6edd24: ldr             x0, [fp, #0x40]
    // 0x6edd28: StoreField: r6->field_8b = r0
    //     0x6edd28: stur            w0, [x6, #0x8b]
    //     0x6edd2c: ldurb           w16, [x6, #-1]
    //     0x6edd30: ldurb           w17, [x0, #-1]
    //     0x6edd34: and             x16, x17, x16, lsr #2
    //     0x6edd38: tst             x16, HEAP, lsr #32
    //     0x6edd3c: b.eq            #0x6edd44
    //     0x6edd40: bl              #0xd6830c
    // 0x6edd44: ldr             d0, [fp, #0x20]
    // 0x6edd48: StoreField: r6->field_8f = d0
    //     0x6edd48: stur            d0, [x6, #0x8f]
    // 0x6edd4c: ldr             x0, [fp, #0x28]
    // 0x6edd50: StoreField: r6->field_9f = r0
    //     0x6edd50: stur            w0, [x6, #0x9f]
    //     0x6edd54: ldurb           w16, [x6, #-1]
    //     0x6edd58: ldurb           w17, [x0, #-1]
    //     0x6edd5c: and             x16, x17, x16, lsr #2
    //     0x6edd60: tst             x16, HEAP, lsr #32
    //     0x6edd64: b.eq            #0x6edd6c
    //     0x6edd68: bl              #0xd6830c
    // 0x6edd6c: ldr             x0, [fp, #0x50]
    // 0x6edd70: StoreField: r6->field_ab = r0
    //     0x6edd70: stur            w0, [x6, #0xab]
    //     0x6edd74: ldurb           w16, [x6, #-1]
    //     0x6edd78: ldurb           w17, [x0, #-1]
    //     0x6edd7c: and             x16, x17, x16, lsr #2
    //     0x6edd80: tst             x16, HEAP, lsr #32
    //     0x6edd84: b.eq            #0x6edd8c
    //     0x6edd88: bl              #0xd6830c
    // 0x6edd8c: StoreField: r6->field_af = r5
    //     0x6edd8c: stur            w5, [x6, #0xaf]
    // 0x6edd90: StoreField: r6->field_b3 = r4
    //     0x6edd90: stur            w4, [x6, #0xb3]
    // 0x6edd94: StoreField: r6->field_bf = r3
    //     0x6edd94: stur            w3, [x6, #0xbf]
    // 0x6edd98: ldr             x0, [fp, #0x30]
    // 0x6edd9c: StoreField: r6->field_bb = r0
    //     0x6edd9c: stur            w0, [x6, #0xbb]
    // 0x6edda0: ldr             x0, [fp, #0x18]
    // 0x6edda4: StoreField: r6->field_c3 = r0
    //     0x6edda4: stur            w0, [x6, #0xc3]
    //     0x6edda8: ldurb           w16, [x6, #-1]
    //     0x6eddac: ldurb           w17, [x0, #-1]
    //     0x6eddb0: and             x16, x17, x16, lsr #2
    //     0x6eddb4: tst             x16, HEAP, lsr #32
    //     0x6eddb8: b.eq            #0x6eddc0
    //     0x6eddbc: bl              #0xd6830c
    // 0x6eddc0: StoreField: r6->field_c7 = r3
    //     0x6eddc0: stur            w3, [x6, #0xc7]
    // 0x6eddc4: StoreField: r6->field_a3 = r2
    //     0x6eddc4: stur            w2, [x6, #0xa3]
    // 0x6eddc8: ldr             x0, [fp, #0x48]
    // 0x6eddcc: StoreField: r6->field_67 = r0
    //     0x6eddcc: stur            w0, [x6, #0x67]
    //     0x6eddd0: ldurb           w16, [x6, #-1]
    //     0x6eddd4: ldurb           w17, [x0, #-1]
    //     0x6eddd8: and             x16, x17, x16, lsr #2
    //     0x6edddc: tst             x16, HEAP, lsr #32
    //     0x6edde0: b.eq            #0x6edde8
    //     0x6edde4: bl              #0xd6830c
    // 0x6edde8: ldr             x0, [fp, #0x58]
    // 0x6eddec: StoreField: r6->field_63 = r0
    //     0x6eddec: stur            w0, [x6, #0x63]
    //     0x6eddf0: ldurb           w16, [x6, #-1]
    //     0x6eddf4: ldurb           w17, [x0, #-1]
    //     0x6eddf8: and             x16, x17, x16, lsr #2
    //     0x6eddfc: tst             x16, HEAP, lsr #32
    //     0x6ede00: b.eq            #0x6ede08
    //     0x6ede04: bl              #0xd6830c
    // 0x6ede08: StoreField: r6->field_5f = r1
    //     0x6ede08: stur            w1, [x6, #0x5f]
    // 0x6ede0c: SaveReg r6
    //     0x6ede0c: str             x6, [SP, #-8]!
    // 0x6ede10: r0 = RenderObject()
    //     0x6ede10: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ede14: add             SP, SP, #8
    // 0x6ede18: ldr             x16, [fp, #0x68]
    // 0x6ede1c: SaveReg r16
    //     0x6ede1c: str             x16, [SP, #-8]!
    // 0x6ede20: r0 = _updateColorFilter()
    //     0x6ede20: bl              #0x6ede40  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::_updateColorFilter
    // 0x6ede24: add             SP, SP, #8
    // 0x6ede28: r0 = Null
    //     0x6ede28: mov             x0, NULL
    // 0x6ede2c: LeaveFrame
    //     0x6ede2c: mov             SP, fp
    //     0x6ede30: ldp             fp, lr, [SP], #0x10
    // 0x6ede34: ret
    //     0x6ede34: ret             
    // 0x6ede38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ede38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ede3c: b               #0x6edcc0
  }
  _ _updateColorFilter(/* No info */) {
    // ** addr: 0x6ede40, size: 0x10
    // 0x6ede40: ldr             x1, [SP]
    // 0x6ede44: StoreField: r1->field_97 = rNULL
    //     0x6ede44: stur            NULL, [x1, #0x97]
    // 0x6ede48: r0 = Null
    //     0x6ede48: mov             x0, NULL
    // 0x6ede4c: ret
    //     0x6ede4c: ret             
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bc378, size: 0xc4
    // 0x9bc378: EnterFrame
    //     0x9bc378: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc37c: mov             fp, SP
    // 0x9bc380: AllocStack(0x8)
    //     0x9bc380: sub             SP, SP, #8
    // 0x9bc384: CheckStackOverflow
    //     0x9bc384: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc388: cmp             SP, x16
    //     0x9bc38c: b.ls            #0x9bc434
    // 0x9bc390: ldr             x0, [fp, #0x10]
    // 0x9bc394: r2 = Null
    //     0x9bc394: mov             x2, NULL
    // 0x9bc398: r1 = Null
    //     0x9bc398: mov             x1, NULL
    // 0x9bc39c: r4 = 59
    //     0x9bc39c: mov             x4, #0x3b
    // 0x9bc3a0: branchIfSmi(r0, 0x9bc3ac)
    //     0x9bc3a0: tbz             w0, #0, #0x9bc3ac
    // 0x9bc3a4: r4 = LoadClassIdInstr(r0)
    //     0x9bc3a4: ldur            x4, [x0, #-1]
    //     0x9bc3a8: ubfx            x4, x4, #0xc, #0x14
    // 0x9bc3ac: cmp             x4, #0x7e6
    // 0x9bc3b0: b.eq            #0x9bc3c4
    // 0x9bc3b4: r8 = PipelineOwner
    //     0x9bc3b4: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bc3b8: r3 = Null
    //     0x9bc3b8: add             x3, PP, #0x38, lsl #12  ; [pp+0x38498] Null
    //     0x9bc3bc: ldr             x3, [x3, #0x498]
    // 0x9bc3c0: r0 = DefaultTypeTest()
    //     0x9bc3c0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bc3c4: ldr             x16, [fp, #0x18]
    // 0x9bc3c8: ldr             lr, [fp, #0x10]
    // 0x9bc3cc: stp             lr, x16, [SP, #-0x10]!
    // 0x9bc3d0: r0 = attach()
    //     0x9bc3d0: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9bc3d4: add             SP, SP, #0x10
    // 0x9bc3d8: ldr             x0, [fp, #0x18]
    // 0x9bc3dc: LoadField: r1 = r0->field_9f
    //     0x9bc3dc: ldur            w1, [x0, #0x9f]
    // 0x9bc3e0: DecompressPointer r1
    //     0x9bc3e0: add             x1, x1, HEAP, lsl #32
    // 0x9bc3e4: stur            x1, [fp, #-8]
    // 0x9bc3e8: cmp             w1, NULL
    // 0x9bc3ec: b.eq            #0x9bc424
    // 0x9bc3f0: r1 = 1
    //     0x9bc3f0: mov             x1, #1
    // 0x9bc3f4: r0 = AllocateContext()
    //     0x9bc3f4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bc3f8: mov             x1, x0
    // 0x9bc3fc: ldr             x0, [fp, #0x18]
    // 0x9bc400: StoreField: r1->field_f = r0
    //     0x9bc400: stur            w0, [x1, #0xf]
    // 0x9bc404: mov             x2, x1
    // 0x9bc408: r1 = Function 'markNeedsPaint':.
    //     0x9bc408: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9bc40c: ldr             x1, [x1, #0xf60]
    // 0x9bc410: r0 = AllocateClosure()
    //     0x9bc410: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bc414: ldur            x16, [fp, #-8]
    // 0x9bc418: stp             x0, x16, [SP, #-0x10]!
    // 0x9bc41c: r0 = addActionListener()
    //     0x9bc41c: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x9bc420: add             SP, SP, #0x10
    // 0x9bc424: r0 = Null
    //     0x9bc424: mov             x0, NULL
    // 0x9bc428: LeaveFrame
    //     0x9bc428: mov             SP, fp
    //     0x9bc42c: ldp             fp, lr, [SP], #0x10
    // 0x9bc430: ret
    //     0x9bc430: ret             
    // 0x9bc434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc434: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc438: b               #0x9bc390
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5ccf8, size: 0x3c
    // 0xa5ccf8: EnterFrame
    //     0xa5ccf8: stp             fp, lr, [SP, #-0x10]!
    //     0xa5ccfc: mov             fp, SP
    // 0xa5cd00: CheckStackOverflow
    //     0xa5cd00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5cd04: cmp             SP, x16
    //     0xa5cd08: b.ls            #0xa5cd2c
    // 0xa5cd0c: ldr             x16, [fp, #0x18]
    // 0xa5cd10: ldr             lr, [fp, #0x10]
    // 0xa5cd14: stp             lr, x16, [SP, #-0x10]!
    // 0xa5cd18: r0 = _sizeForConstraints()
    //     0xa5cd18: bl              #0x62b884  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::_sizeForConstraints
    // 0xa5cd1c: add             SP, SP, #0x10
    // 0xa5cd20: LeaveFrame
    //     0xa5cd20: mov             SP, fp
    //     0xa5cd24: ldp             fp, lr, [SP], #0x10
    // 0xa5cd28: ret
    //     0xa5cd28: ret             
    // 0xa5cd2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5cd2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5cd30: b               #0xa5cd0c
  }
  _ detach(/* No info */) {
    // ** addr: 0xa68890, size: 0x8c
    // 0xa68890: EnterFrame
    //     0xa68890: stp             fp, lr, [SP, #-0x10]!
    //     0xa68894: mov             fp, SP
    // 0xa68898: AllocStack(0x8)
    //     0xa68898: sub             SP, SP, #8
    // 0xa6889c: CheckStackOverflow
    //     0xa6889c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa688a0: cmp             SP, x16
    //     0xa688a4: b.ls            #0xa68914
    // 0xa688a8: ldr             x0, [fp, #0x10]
    // 0xa688ac: LoadField: r1 = r0->field_9f
    //     0xa688ac: ldur            w1, [x0, #0x9f]
    // 0xa688b0: DecompressPointer r1
    //     0xa688b0: add             x1, x1, HEAP, lsl #32
    // 0xa688b4: stur            x1, [fp, #-8]
    // 0xa688b8: cmp             w1, NULL
    // 0xa688bc: b.eq            #0xa688f4
    // 0xa688c0: r1 = 1
    //     0xa688c0: mov             x1, #1
    // 0xa688c4: r0 = AllocateContext()
    //     0xa688c4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa688c8: mov             x1, x0
    // 0xa688cc: ldr             x0, [fp, #0x10]
    // 0xa688d0: StoreField: r1->field_f = r0
    //     0xa688d0: stur            w0, [x1, #0xf]
    // 0xa688d4: mov             x2, x1
    // 0xa688d8: r1 = Function 'markNeedsPaint':.
    //     0xa688d8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa688dc: ldr             x1, [x1, #0xf60]
    // 0xa688e0: r0 = AllocateClosure()
    //     0xa688e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa688e4: ldur            x16, [fp, #-8]
    // 0xa688e8: stp             x0, x16, [SP, #-0x10]!
    // 0xa688ec: r0 = removeListener()
    //     0xa688ec: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xa688f0: add             SP, SP, #0x10
    // 0xa688f4: ldr             x16, [fp, #0x10]
    // 0xa688f8: SaveReg r16
    //     0xa688f8: str             x16, [SP, #-8]!
    // 0xa688fc: r0 = detach()
    //     0xa688fc: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa68900: add             SP, SP, #8
    // 0xa68904: r0 = Null
    //     0xa68904: mov             x0, NULL
    // 0xa68908: LeaveFrame
    //     0xa68908: mov             SP, fp
    //     0xa6890c: ldp             fp, lr, [SP], #0x10
    // 0xa68910: ret
    //     0xa68910: ret             
    // 0xa68914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa68914: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68918: b               #0xa688a8
  }
}

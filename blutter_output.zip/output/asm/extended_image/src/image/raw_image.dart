// lib: , url: package:extended_image/src/image/raw_image.dart

// class id: 1048943, size: 0x8
class :: {
}

// class id: 3605, size: 0x68, field offset: 0xc
//   const constructor, 
class ExtendedRawImage extends LeafRenderObjectWidget {

  _ didUnmountRenderObject(/* No info */) {
    // ** addr: 0x6c192c, size: 0x74
    // 0x6c192c: EnterFrame
    //     0x6c192c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c1930: mov             fp, SP
    // 0x6c1934: CheckStackOverflow
    //     0x6c1934: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c1938: cmp             SP, x16
    //     0x6c193c: b.ls            #0x6c1998
    // 0x6c1940: ldr             x0, [fp, #0x10]
    // 0x6c1944: r2 = Null
    //     0x6c1944: mov             x2, NULL
    // 0x6c1948: r1 = Null
    //     0x6c1948: mov             x1, NULL
    // 0x6c194c: r4 = 59
    //     0x6c194c: mov             x4, #0x3b
    // 0x6c1950: branchIfSmi(r0, 0x6c195c)
    //     0x6c1950: tbz             w0, #0, #0x6c195c
    // 0x6c1954: r4 = LoadClassIdInstr(r0)
    //     0x6c1954: ldur            x4, [x0, #-1]
    //     0x6c1958: ubfx            x4, x4, #0xc, #0x14
    // 0x6c195c: cmp             x4, #0x9f0
    // 0x6c1960: b.eq            #0x6c1978
    // 0x6c1964: r8 = ExtendedRenderImage
    //     0x6c1964: add             x8, PP, #0x2f, lsl #12  ; [pp+0x2f0b8] Type: ExtendedRenderImage
    //     0x6c1968: ldr             x8, [x8, #0xb8]
    // 0x6c196c: r3 = Null
    //     0x6c196c: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f0c0] Null
    //     0x6c1970: ldr             x3, [x3, #0xc0]
    // 0x6c1974: r0 = DefaultTypeTest()
    //     0x6c1974: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c1978: ldr             x16, [fp, #0x10]
    // 0x6c197c: stp             NULL, x16, [SP, #-0x10]!
    // 0x6c1980: r0 = image=()
    //     0x6c1980: bl              #0x6c19a0  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::image=
    // 0x6c1984: add             SP, SP, #0x10
    // 0x6c1988: r0 = Null
    //     0x6c1988: mov             x0, NULL
    // 0x6c198c: LeaveFrame
    //     0x6c198c: mov             SP, fp
    //     0x6c1990: ldp             fp, lr, [SP], #0x10
    // 0x6c1994: ret
    //     0x6c1994: ret             
    // 0x6c1998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c1998: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c199c: b               #0x6c1940
  }
  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6c9bd8, size: 0x2a0
    // 0x6c9bd8: EnterFrame
    //     0x6c9bd8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c9bdc: mov             fp, SP
    // 0x6c9be0: CheckStackOverflow
    //     0x6c9be0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c9be4: cmp             SP, x16
    //     0x6c9be8: b.ls            #0x6c9e70
    // 0x6c9bec: ldr             x0, [fp, #0x10]
    // 0x6c9bf0: r2 = Null
    //     0x6c9bf0: mov             x2, NULL
    // 0x6c9bf4: r1 = Null
    //     0x6c9bf4: mov             x1, NULL
    // 0x6c9bf8: r4 = 59
    //     0x6c9bf8: mov             x4, #0x3b
    // 0x6c9bfc: branchIfSmi(r0, 0x6c9c08)
    //     0x6c9bfc: tbz             w0, #0, #0x6c9c08
    // 0x6c9c00: r4 = LoadClassIdInstr(r0)
    //     0x6c9c00: ldur            x4, [x0, #-1]
    //     0x6c9c04: ubfx            x4, x4, #0xc, #0x14
    // 0x6c9c08: cmp             x4, #0x9f0
    // 0x6c9c0c: b.eq            #0x6c9c24
    // 0x6c9c10: r8 = ExtendedRenderImage
    //     0x6c9c10: add             x8, PP, #0x2f, lsl #12  ; [pp+0x2f0b8] Type: ExtendedRenderImage
    //     0x6c9c14: ldr             x8, [x8, #0xb8]
    // 0x6c9c18: r3 = Null
    //     0x6c9c18: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f0d0] Null
    //     0x6c9c1c: ldr             x3, [x3, #0xd0]
    // 0x6c9c20: r0 = DefaultTypeTest()
    //     0x6c9c20: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c9c24: ldr             x0, [fp, #0x20]
    // 0x6c9c28: LoadField: r1 = r0->field_1f
    //     0x6c9c28: ldur            w1, [x0, #0x1f]
    // 0x6c9c2c: DecompressPointer r1
    //     0x6c9c2c: add             x1, x1, HEAP, lsl #32
    // 0x6c9c30: cmp             w1, NULL
    // 0x6c9c34: b.ne            #0x6c9c40
    // 0x6c9c38: r2 = Null
    //     0x6c9c38: mov             x2, NULL
    // 0x6c9c3c: b               #0x6c9c54
    // 0x6c9c40: SaveReg r1
    //     0x6c9c40: str             x1, [SP, #-8]!
    // 0x6c9c44: r0 = clone()
    //     0x6c9c44: bl              #0x6ca4f0  ; [dart:ui] Image::clone
    // 0x6c9c48: add             SP, SP, #8
    // 0x6c9c4c: mov             x2, x0
    // 0x6c9c50: ldr             x0, [fp, #0x20]
    // 0x6c9c54: ldr             x1, [fp, #0x10]
    // 0x6c9c58: stp             x2, x1, [SP, #-0x10]!
    // 0x6c9c5c: r0 = image=()
    //     0x6c9c5c: bl              #0x6c19a0  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::image=
    // 0x6c9c60: add             SP, SP, #0x10
    // 0x6c9c64: ldr             x1, [fp, #0x20]
    // 0x6c9c68: LoadField: r0 = r1->field_5f
    //     0x6c9c68: ldur            w0, [x1, #0x5f]
    // 0x6c9c6c: DecompressPointer r0
    //     0x6c9c6c: add             x0, x0, HEAP, lsl #32
    // 0x6c9c70: ldr             x2, [fp, #0x10]
    // 0x6c9c74: StoreField: r2->field_83 = r0
    //     0x6c9c74: stur            w0, [x2, #0x83]
    //     0x6c9c78: ldurb           w16, [x2, #-1]
    //     0x6c9c7c: ldurb           w17, [x0, #-1]
    //     0x6c9c80: and             x16, x17, x16, lsr #2
    //     0x6c9c84: tst             x16, HEAP, lsr #32
    //     0x6c9c88: b.eq            #0x6c9c90
    //     0x6c9c8c: bl              #0xd6828c
    // 0x6c9c90: LoadField: r0 = r1->field_23
    //     0x6c9c90: ldur            w0, [x1, #0x23]
    // 0x6c9c94: DecompressPointer r0
    //     0x6c9c94: add             x0, x0, HEAP, lsl #32
    // 0x6c9c98: stp             x0, x2, [SP, #-0x10]!
    // 0x6c9c9c: r0 = width=()
    //     0x6c9c9c: bl              #0x6ca450  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::width=
    // 0x6c9ca0: add             SP, SP, #0x10
    // 0x6c9ca4: ldr             x0, [fp, #0x20]
    // 0x6c9ca8: LoadField: r1 = r0->field_27
    //     0x6c9ca8: ldur            w1, [x0, #0x27]
    // 0x6c9cac: DecompressPointer r1
    //     0x6c9cac: add             x1, x1, HEAP, lsl #32
    // 0x6c9cb0: ldr             x16, [fp, #0x10]
    // 0x6c9cb4: stp             x1, x16, [SP, #-0x10]!
    // 0x6c9cb8: r0 = height=()
    //     0x6c9cb8: bl              #0x6ca3b0  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::height=
    // 0x6c9cbc: add             SP, SP, #0x10
    // 0x6c9cc0: ldr             x0, [fp, #0x20]
    // 0x6c9cc4: LoadField: d0 = r0->field_2b
    //     0x6c9cc4: ldur            d0, [x0, #0x2b]
    // 0x6c9cc8: ldr             x16, [fp, #0x10]
    // 0x6c9ccc: SaveReg r16
    //     0x6c9ccc: str             x16, [SP, #-8]!
    // 0x6c9cd0: SaveReg d0
    //     0x6c9cd0: str             d0, [SP, #-8]!
    // 0x6c9cd4: r0 = scale=()
    //     0x6c9cd4: bl              #0x6ca34c  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::scale=
    // 0x6c9cd8: add             SP, SP, #0x10
    // 0x6c9cdc: ldr             x16, [fp, #0x10]
    // 0x6c9ce0: stp             NULL, x16, [SP, #-0x10]!
    // 0x6c9ce4: r0 = Shader._()
    //     0x6c9ce4: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6c9ce8: add             SP, SP, #0x10
    // 0x6c9cec: ldr             x0, [fp, #0x20]
    // 0x6c9cf0: LoadField: r1 = r0->field_37
    //     0x6c9cf0: ldur            w1, [x0, #0x37]
    // 0x6c9cf4: DecompressPointer r1
    //     0x6c9cf4: add             x1, x1, HEAP, lsl #32
    // 0x6c9cf8: ldr             x16, [fp, #0x10]
    // 0x6c9cfc: stp             x1, x16, [SP, #-0x10]!
    // 0x6c9d00: r0 = opacity=()
    //     0x6c9d00: bl              #0x6ca230  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::opacity=
    // 0x6c9d04: add             SP, SP, #0x10
    // 0x6c9d08: ldr             x16, [fp, #0x10]
    // 0x6c9d0c: stp             NULL, x16, [SP, #-0x10]!
    // 0x6c9d10: r0 = Shader._()
    //     0x6c9d10: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6c9d14: add             SP, SP, #0x10
    // 0x6c9d18: ldr             x16, [fp, #0x10]
    // 0x6c9d1c: r30 = Instance_Alignment
    //     0x6c9d1c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6c9d20: ldr             lr, [lr, #0xc70]
    // 0x6c9d24: stp             lr, x16, [SP, #-0x10]!
    // 0x6c9d28: r0 = alignment=()
    //     0x6c9d28: bl              #0x6ca1b8  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::alignment=
    // 0x6c9d2c: add             SP, SP, #0x10
    // 0x6c9d30: ldr             x0, [fp, #0x20]
    // 0x6c9d34: LoadField: r1 = r0->field_43
    //     0x6c9d34: ldur            w1, [x0, #0x43]
    // 0x6c9d38: DecompressPointer r1
    //     0x6c9d38: add             x1, x1, HEAP, lsl #32
    // 0x6c9d3c: ldr             x16, [fp, #0x10]
    // 0x6c9d40: stp             x1, x16, [SP, #-0x10]!
    // 0x6c9d44: r0 = fit=()
    //     0x6c9d44: bl              #0x6ca138  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::fit=
    // 0x6c9d48: add             SP, SP, #0x10
    // 0x6c9d4c: ldr             x16, [fp, #0x10]
    // 0x6c9d50: r30 = Instance_ImageRepeat
    //     0x6c9d50: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0x6c9d54: ldr             lr, [lr, #0x540]
    // 0x6c9d58: stp             lr, x16, [SP, #-0x10]!
    // 0x6c9d5c: r0 = Shader._()
    //     0x6c9d5c: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6c9d60: add             SP, SP, #0x10
    // 0x6c9d64: ldr             x16, [fp, #0x10]
    // 0x6c9d68: stp             NULL, x16, [SP, #-0x10]!
    // 0x6c9d6c: r0 = Shader._()
    //     0x6c9d6c: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6c9d70: add             SP, SP, #0x10
    // 0x6c9d74: ldr             x16, [fp, #0x10]
    // 0x6c9d78: r30 = false
    //     0x6c9d78: add             lr, NULL, #0x30  ; false
    // 0x6c9d7c: stp             lr, x16, [SP, #-0x10]!
    // 0x6c9d80: r0 = Shader._()
    //     0x6c9d80: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6c9d84: add             SP, SP, #0x10
    // 0x6c9d88: ldr             x16, [fp, #0x10]
    // 0x6c9d8c: stp             NULL, x16, [SP, #-0x10]!
    // 0x6c9d90: r0 = textDirection=()
    //     0x6c9d90: bl              #0x6ca074  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::textDirection=
    // 0x6c9d94: add             SP, SP, #0x10
    // 0x6c9d98: ldr             x0, [fp, #0x20]
    // 0x6c9d9c: LoadField: r1 = r0->field_57
    //     0x6c9d9c: ldur            w1, [x0, #0x57]
    // 0x6c9da0: DecompressPointer r1
    //     0x6c9da0: add             x1, x1, HEAP, lsl #32
    // 0x6c9da4: ldr             x16, [fp, #0x10]
    // 0x6c9da8: stp             x1, x16, [SP, #-0x10]!
    // 0x6c9dac: r0 = invertColors=()
    //     0x6c9dac: bl              #0x6ca010  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::invertColors=
    // 0x6c9db0: add             SP, SP, #0x10
    // 0x6c9db4: ldr             x16, [fp, #0x10]
    // 0x6c9db8: r30 = Instance_FilterQuality
    //     0x6c9db8: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0x6c9dbc: ldr             lr, [lr, #0x548]
    // 0x6c9dc0: stp             lr, x16, [SP, #-0x10]!
    // 0x6c9dc4: r0 = Shader._()
    //     0x6c9dc4: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6c9dc8: add             SP, SP, #0x10
    // 0x6c9dcc: ldr             x16, [fp, #0x10]
    // 0x6c9dd0: stp             NULL, x16, [SP, #-0x10]!
    // 0x6c9dd4: r0 = Shader._()
    //     0x6c9dd4: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6c9dd8: add             SP, SP, #0x10
    // 0x6c9ddc: ldr             x16, [fp, #0x10]
    // 0x6c9de0: stp             NULL, x16, [SP, #-0x10]!
    // 0x6c9de4: r0 = Shader._()
    //     0x6c9de4: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6c9de8: add             SP, SP, #0x10
    // 0x6c9dec: ldr             x16, [fp, #0x10]
    // 0x6c9df0: stp             NULL, x16, [SP, #-0x10]!
    // 0x6c9df4: r0 = Shader._()
    //     0x6c9df4: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6c9df8: add             SP, SP, #0x10
    // 0x6c9dfc: ldr             x0, [fp, #0x20]
    // 0x6c9e00: LoadField: r1 = r0->field_13
    //     0x6c9e00: ldur            w1, [x0, #0x13]
    // 0x6c9e04: DecompressPointer r1
    //     0x6c9e04: add             x1, x1, HEAP, lsl #32
    // 0x6c9e08: ldr             x16, [fp, #0x10]
    // 0x6c9e0c: stp             x1, x16, [SP, #-0x10]!
    // 0x6c9e10: r0 = gestureDetails=()
    //     0x6c9e10: bl              #0x6c9f70  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::gestureDetails=
    // 0x6c9e14: add             SP, SP, #0x10
    // 0x6c9e18: ldr             x0, [fp, #0x20]
    // 0x6c9e1c: LoadField: r1 = r0->field_f
    //     0x6c9e1c: ldur            w1, [x0, #0xf]
    // 0x6c9e20: DecompressPointer r1
    //     0x6c9e20: add             x1, x1, HEAP, lsl #32
    // 0x6c9e24: ldr             x16, [fp, #0x10]
    // 0x6c9e28: stp             x1, x16, [SP, #-0x10]!
    // 0x6c9e2c: r0 = editActionDetails=()
    //     0x6c9e2c: bl              #0x6c9ef0  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::editActionDetails=
    // 0x6c9e30: add             SP, SP, #0x10
    // 0x6c9e34: ldr             x16, [fp, #0x10]
    // 0x6c9e38: r30 = false
    //     0x6c9e38: add             lr, NULL, #0x30  ; false
    // 0x6c9e3c: stp             lr, x16, [SP, #-0x10]!
    // 0x6c9e40: r0 = Shader._()
    //     0x6c9e40: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6c9e44: add             SP, SP, #0x10
    // 0x6c9e48: ldr             x16, [fp, #0x10]
    // 0x6c9e4c: r30 = Instance_EdgeInsets
    //     0x6c9e4c: add             lr, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x6c9e50: ldr             lr, [lr, #0xbd8]
    // 0x6c9e54: stp             lr, x16, [SP, #-0x10]!
    // 0x6c9e58: r0 = layoutInsets=()
    //     0x6c9e58: bl              #0x6c9e78  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::layoutInsets=
    // 0x6c9e5c: add             SP, SP, #0x10
    // 0x6c9e60: r0 = Null
    //     0x6c9e60: mov             x0, NULL
    // 0x6c9e64: LeaveFrame
    //     0x6c9e64: mov             SP, fp
    //     0x6c9e68: ldp             fp, lr, [SP], #0x10
    // 0x6c9e6c: ret
    //     0x6c9e6c: ret             
    // 0x6c9e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c9e70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c9e74: b               #0x6c9bec
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6edb68, size: 0x120
    // 0x6edb68: EnterFrame
    //     0x6edb68: stp             fp, lr, [SP, #-0x10]!
    //     0x6edb6c: mov             fp, SP
    // 0x6edb70: AllocStack(0x58)
    //     0x6edb70: sub             SP, SP, #0x58
    // 0x6edb74: CheckStackOverflow
    //     0x6edb74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6edb78: cmp             SP, x16
    //     0x6edb7c: b.ls            #0x6edc80
    // 0x6edb80: ldr             x0, [fp, #0x18]
    // 0x6edb84: LoadField: r1 = r0->field_1f
    //     0x6edb84: ldur            w1, [x0, #0x1f]
    // 0x6edb88: DecompressPointer r1
    //     0x6edb88: add             x1, x1, HEAP, lsl #32
    // 0x6edb8c: cmp             w1, NULL
    // 0x6edb90: b.ne            #0x6edb9c
    // 0x6edb94: r1 = Null
    //     0x6edb94: mov             x1, NULL
    // 0x6edb98: b               #0x6edbb0
    // 0x6edb9c: SaveReg r1
    //     0x6edb9c: str             x1, [SP, #-8]!
    // 0x6edba0: r0 = clone()
    //     0x6edba0: bl              #0x6ca4f0  ; [dart:ui] Image::clone
    // 0x6edba4: add             SP, SP, #8
    // 0x6edba8: mov             x1, x0
    // 0x6edbac: ldr             x0, [fp, #0x18]
    // 0x6edbb0: stur            x1, [fp, #-0x48]
    // 0x6edbb4: LoadField: r2 = r0->field_5f
    //     0x6edbb4: ldur            w2, [x0, #0x5f]
    // 0x6edbb8: DecompressPointer r2
    //     0x6edbb8: add             x2, x2, HEAP, lsl #32
    // 0x6edbbc: stur            x2, [fp, #-0x40]
    // 0x6edbc0: LoadField: r3 = r0->field_23
    //     0x6edbc0: ldur            w3, [x0, #0x23]
    // 0x6edbc4: DecompressPointer r3
    //     0x6edbc4: add             x3, x3, HEAP, lsl #32
    // 0x6edbc8: stur            x3, [fp, #-0x38]
    // 0x6edbcc: LoadField: r4 = r0->field_27
    //     0x6edbcc: ldur            w4, [x0, #0x27]
    // 0x6edbd0: DecompressPointer r4
    //     0x6edbd0: add             x4, x4, HEAP, lsl #32
    // 0x6edbd4: stur            x4, [fp, #-0x30]
    // 0x6edbd8: LoadField: d0 = r0->field_2b
    //     0x6edbd8: ldur            d0, [x0, #0x2b]
    // 0x6edbdc: stur            d0, [fp, #-0x58]
    // 0x6edbe0: LoadField: r5 = r0->field_37
    //     0x6edbe0: ldur            w5, [x0, #0x37]
    // 0x6edbe4: DecompressPointer r5
    //     0x6edbe4: add             x5, x5, HEAP, lsl #32
    // 0x6edbe8: stur            x5, [fp, #-0x28]
    // 0x6edbec: LoadField: r6 = r0->field_43
    //     0x6edbec: ldur            w6, [x0, #0x43]
    // 0x6edbf0: DecompressPointer r6
    //     0x6edbf0: add             x6, x6, HEAP, lsl #32
    // 0x6edbf4: stur            x6, [fp, #-0x20]
    // 0x6edbf8: LoadField: r7 = r0->field_57
    //     0x6edbf8: ldur            w7, [x0, #0x57]
    // 0x6edbfc: DecompressPointer r7
    //     0x6edbfc: add             x7, x7, HEAP, lsl #32
    // 0x6edc00: stur            x7, [fp, #-0x18]
    // 0x6edc04: LoadField: r8 = r0->field_13
    //     0x6edc04: ldur            w8, [x0, #0x13]
    // 0x6edc08: DecompressPointer r8
    //     0x6edc08: add             x8, x8, HEAP, lsl #32
    // 0x6edc0c: stur            x8, [fp, #-0x10]
    // 0x6edc10: LoadField: r9 = r0->field_f
    //     0x6edc10: ldur            w9, [x0, #0xf]
    // 0x6edc14: DecompressPointer r9
    //     0x6edc14: add             x9, x9, HEAP, lsl #32
    // 0x6edc18: stur            x9, [fp, #-8]
    // 0x6edc1c: r0 = ExtendedRenderImage()
    //     0x6edc1c: bl              #0x6ede50  ; AllocateExtendedRenderImageStub -> ExtendedRenderImage (size=0xcc)
    // 0x6edc20: stur            x0, [fp, #-0x50]
    // 0x6edc24: ldur            x16, [fp, #-0x40]
    // 0x6edc28: stp             x16, x0, [SP, #-0x10]!
    // 0x6edc2c: ldur            x16, [fp, #-8]
    // 0x6edc30: ldur            lr, [fp, #-0x20]
    // 0x6edc34: stp             lr, x16, [SP, #-0x10]!
    // 0x6edc38: ldur            x16, [fp, #-0x10]
    // 0x6edc3c: ldur            lr, [fp, #-0x30]
    // 0x6edc40: stp             lr, x16, [SP, #-0x10]!
    // 0x6edc44: ldur            x16, [fp, #-0x48]
    // 0x6edc48: ldur            lr, [fp, #-0x18]
    // 0x6edc4c: stp             lr, x16, [SP, #-0x10]!
    // 0x6edc50: ldur            x16, [fp, #-0x28]
    // 0x6edc54: SaveReg r16
    //     0x6edc54: str             x16, [SP, #-8]!
    // 0x6edc58: ldur            d0, [fp, #-0x58]
    // 0x6edc5c: SaveReg d0
    //     0x6edc5c: str             d0, [SP, #-8]!
    // 0x6edc60: ldur            x16, [fp, #-0x38]
    // 0x6edc64: stp             x16, NULL, [SP, #-0x10]!
    // 0x6edc68: r0 = ExtendedRenderImage()
    //     0x6edc68: bl              #0x6edc88  ; [package:extended_image/src/image/render_image.dart] ExtendedRenderImage::ExtendedRenderImage
    // 0x6edc6c: add             SP, SP, #0x60
    // 0x6edc70: ldur            x0, [fp, #-0x50]
    // 0x6edc74: LeaveFrame
    //     0x6edc74: mov             SP, fp
    //     0x6edc78: ldp             fp, lr, [SP], #0x10
    // 0x6edc7c: ret
    //     0x6edc7c: ret             
    // 0x6edc80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6edc80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6edc84: b               #0x6edb80
  }
}

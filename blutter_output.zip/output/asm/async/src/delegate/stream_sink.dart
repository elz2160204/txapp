// lib: , url: package:async/src/delegate/stream_sink.dart

// class id: 1048649, size: 0x8
class :: {
}

// class id: 4981, size: 0x10, field offset: 0x8
abstract class DelegatingStreamSink<X0> extends Object
    implements StreamSink<X0> {

  dynamic add(dynamic) {
    // ** addr: 0xbdf218, size: 0x18
    // 0xbdf218: r4 = 7
    //     0xbdf218: mov             x4, #7
    // 0xbdf21c: r1 = Function 'add':.
    //     0xbdf21c: add             x17, PP, #0x29, lsl #12  ; [pp+0x294a8] AnonymousClosure: (0xbdf230), in [package:async/src/delegate/stream_sink.dart] DelegatingStreamSink::add (0xc430a8)
    //     0xbdf220: ldr             x1, [x17, #0x4a8]
    // 0xbdf224: r24 = BuildNonGenericMethodExtractorStub
    //     0xbdf224: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xbdf228: LoadField: r0 = r24->field_17
    //     0xbdf228: ldur            x0, [x24, #0x17]
    // 0xbdf22c: br              x0
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0xbdf230, size: 0x4c
    // 0xbdf230: EnterFrame
    //     0xbdf230: stp             fp, lr, [SP, #-0x10]!
    //     0xbdf234: mov             fp, SP
    // 0xbdf238: ldr             x0, [fp, #0x18]
    // 0xbdf23c: LoadField: r1 = r0->field_17
    //     0xbdf23c: ldur            w1, [x0, #0x17]
    // 0xbdf240: DecompressPointer r1
    //     0xbdf240: add             x1, x1, HEAP, lsl #32
    // 0xbdf244: CheckStackOverflow
    //     0xbdf244: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdf248: cmp             SP, x16
    //     0xbdf24c: b.ls            #0xbdf274
    // 0xbdf250: LoadField: r0 = r1->field_f
    //     0xbdf250: ldur            w0, [x1, #0xf]
    // 0xbdf254: DecompressPointer r0
    //     0xbdf254: add             x0, x0, HEAP, lsl #32
    // 0xbdf258: ldr             x16, [fp, #0x10]
    // 0xbdf25c: stp             x16, x0, [SP, #-0x10]!
    // 0xbdf260: r0 = add()
    //     0xbdf260: bl              #0xc430a8  ; [package:async/src/delegate/stream_sink.dart] DelegatingStreamSink::add
    // 0xbdf264: add             SP, SP, #0x10
    // 0xbdf268: LeaveFrame
    //     0xbdf268: mov             SP, fp
    //     0xbdf26c: ldp             fp, lr, [SP], #0x10
    // 0xbdf270: ret
    //     0xbdf270: ret             
    // 0xbdf274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdf274: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdf278: b               #0xbdf250
  }
  dynamic addError(dynamic) {
    // ** addr: 0xc10998, size: 0x18
    // 0xc10998: r4 = 7
    //     0xc10998: mov             x4, #7
    // 0xc1099c: r1 = Function 'addError':.
    //     0xc1099c: add             x17, PP, #0x29, lsl #12  ; [pp+0x294a0] AnonymousClosure: (0xc109b0), in [package:async/src/delegate/stream_sink.dart] DelegatingStreamSink::addError (0xc3ab28)
    //     0xc109a0: ldr             x1, [x17, #0x4a0]
    // 0xc109a4: r24 = BuildNonGenericMethodExtractorStub
    //     0xc109a4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xc109a8: LoadField: r0 = r24->field_17
    //     0xc109a8: ldur            x0, [x24, #0x17]
    // 0xc109ac: br              x0
  }
  [closure] void addError(dynamic, Object, [StackTrace?]) {
    // ** addr: 0xc109b0, size: 0x88
    // 0xc109b0: EnterFrame
    //     0xc109b0: stp             fp, lr, [SP, #-0x10]!
    //     0xc109b4: mov             fp, SP
    // 0xc109b8: mov             x0, x4
    // 0xc109bc: LoadField: r1 = r0->field_13
    //     0xc109bc: ldur            w1, [x0, #0x13]
    // 0xc109c0: DecompressPointer r1
    //     0xc109c0: add             x1, x1, HEAP, lsl #32
    // 0xc109c4: sub             x0, x1, #4
    // 0xc109c8: add             x1, fp, w0, sxtw #2
    // 0xc109cc: ldr             x1, [x1, #0x18]
    // 0xc109d0: add             x2, fp, w0, sxtw #2
    // 0xc109d4: ldr             x2, [x2, #0x10]
    // 0xc109d8: cmp             w0, #2
    // 0xc109dc: b.lt            #0xc109f0
    // 0xc109e0: add             x3, fp, w0, sxtw #2
    // 0xc109e4: ldr             x3, [x3, #8]
    // 0xc109e8: mov             x0, x3
    // 0xc109ec: b               #0xc109f4
    // 0xc109f0: r0 = Null
    //     0xc109f0: mov             x0, NULL
    // 0xc109f4: LoadField: r3 = r1->field_17
    //     0xc109f4: ldur            w3, [x1, #0x17]
    // 0xc109f8: DecompressPointer r3
    //     0xc109f8: add             x3, x3, HEAP, lsl #32
    // 0xc109fc: CheckStackOverflow
    //     0xc109fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc10a00: cmp             SP, x16
    //     0xc10a04: b.ls            #0xc10a30
    // 0xc10a08: LoadField: r1 = r3->field_f
    //     0xc10a08: ldur            w1, [x3, #0xf]
    // 0xc10a0c: DecompressPointer r1
    //     0xc10a0c: add             x1, x1, HEAP, lsl #32
    // 0xc10a10: stp             x2, x1, [SP, #-0x10]!
    // 0xc10a14: SaveReg r0
    //     0xc10a14: str             x0, [SP, #-8]!
    // 0xc10a18: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xc10a18: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xc10a1c: r0 = addError()
    //     0xc10a1c: bl              #0xc3ab28  ; [package:async/src/delegate/stream_sink.dart] DelegatingStreamSink::addError
    // 0xc10a20: add             SP, SP, #0x18
    // 0xc10a24: LeaveFrame
    //     0xc10a24: mov             SP, fp
    //     0xc10a28: ldp             fp, lr, [SP], #0x10
    // 0xc10a2c: ret
    //     0xc10a2c: ret             
    // 0xc10a30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc10a30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc10a34: b               #0xc10a08
  }
  get _ done(/* No info */) {
    // ** addr: 0xc2ed90, size: 0x40
    // 0xc2ed90: EnterFrame
    //     0xc2ed90: stp             fp, lr, [SP, #-0x10]!
    //     0xc2ed94: mov             fp, SP
    // 0xc2ed98: CheckStackOverflow
    //     0xc2ed98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2ed9c: cmp             SP, x16
    //     0xc2eda0: b.ls            #0xc2edc8
    // 0xc2eda4: ldr             x0, [fp, #0x10]
    // 0xc2eda8: LoadField: r1 = r0->field_b
    //     0xc2eda8: ldur            w1, [x0, #0xb]
    // 0xc2edac: DecompressPointer r1
    //     0xc2edac: add             x1, x1, HEAP, lsl #32
    // 0xc2edb0: SaveReg r1
    //     0xc2edb0: str             x1, [SP, #-8]!
    // 0xc2edb4: r0 = done()
    //     0xc2edb4: bl              #0xc047f4  ; [dart:_http] _WebSocketImpl::done
    // 0xc2edb8: add             SP, SP, #8
    // 0xc2edbc: LeaveFrame
    //     0xc2edbc: mov             SP, fp
    //     0xc2edc0: ldp             fp, lr, [SP], #0x10
    // 0xc2edc4: ret
    //     0xc2edc4: ret             
    // 0xc2edc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2edc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2edcc: b               #0xc2eda4
  }
  _ addError(/* No info */) {
    // ** addr: 0xc3ab28, size: 0x84
    // 0xc3ab28: EnterFrame
    //     0xc3ab28: stp             fp, lr, [SP, #-0x10]!
    //     0xc3ab2c: mov             fp, SP
    // 0xc3ab30: mov             x0, x4
    // 0xc3ab34: LoadField: r1 = r0->field_13
    //     0xc3ab34: ldur            w1, [x0, #0x13]
    // 0xc3ab38: DecompressPointer r1
    //     0xc3ab38: add             x1, x1, HEAP, lsl #32
    // 0xc3ab3c: sub             x0, x1, #4
    // 0xc3ab40: add             x1, fp, w0, sxtw #2
    // 0xc3ab44: ldr             x1, [x1, #0x18]
    // 0xc3ab48: add             x2, fp, w0, sxtw #2
    // 0xc3ab4c: ldr             x2, [x2, #0x10]
    // 0xc3ab50: cmp             w0, #2
    // 0xc3ab54: b.lt            #0xc3ab68
    // 0xc3ab58: add             x3, fp, w0, sxtw #2
    // 0xc3ab5c: ldr             x3, [x3, #8]
    // 0xc3ab60: mov             x0, x3
    // 0xc3ab64: b               #0xc3ab6c
    // 0xc3ab68: r0 = Null
    //     0xc3ab68: mov             x0, NULL
    // 0xc3ab6c: CheckStackOverflow
    //     0xc3ab6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3ab70: cmp             SP, x16
    //     0xc3ab74: b.ls            #0xc3aba4
    // 0xc3ab78: LoadField: r3 = r1->field_b
    //     0xc3ab78: ldur            w3, [x1, #0xb]
    // 0xc3ab7c: DecompressPointer r3
    //     0xc3ab7c: add             x3, x3, HEAP, lsl #32
    // 0xc3ab80: stp             x2, x3, [SP, #-0x10]!
    // 0xc3ab84: SaveReg r0
    //     0xc3ab84: str             x0, [SP, #-8]!
    // 0xc3ab88: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xc3ab88: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xc3ab8c: r0 = addError()
    //     0xc3ab8c: bl              #0xc0a2d0  ; [dart:_http] _WebSocketImpl::addError
    // 0xc3ab90: add             SP, SP, #0x18
    // 0xc3ab94: r0 = Null
    //     0xc3ab94: mov             x0, NULL
    // 0xc3ab98: LeaveFrame
    //     0xc3ab98: mov             SP, fp
    //     0xc3ab9c: ldp             fp, lr, [SP], #0x10
    // 0xc3aba0: ret
    //     0xc3aba0: ret             
    // 0xc3aba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3aba4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3aba8: b               #0xc3ab78
  }
  _ add(/* No info */) {
    // ** addr: 0xc430a8, size: 0x80
    // 0xc430a8: EnterFrame
    //     0xc430a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc430ac: mov             fp, SP
    // 0xc430b0: CheckStackOverflow
    //     0xc430b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc430b4: cmp             SP, x16
    //     0xc430b8: b.ls            #0xc43120
    // 0xc430bc: ldr             x3, [fp, #0x18]
    // 0xc430c0: LoadField: r2 = r3->field_7
    //     0xc430c0: ldur            w2, [x3, #7]
    // 0xc430c4: DecompressPointer r2
    //     0xc430c4: add             x2, x2, HEAP, lsl #32
    // 0xc430c8: ldr             x0, [fp, #0x10]
    // 0xc430cc: r1 = Null
    //     0xc430cc: mov             x1, NULL
    // 0xc430d0: cmp             w2, NULL
    // 0xc430d4: b.eq            #0xc430f4
    // 0xc430d8: LoadField: r4 = r2->field_17
    //     0xc430d8: ldur            w4, [x2, #0x17]
    // 0xc430dc: DecompressPointer r4
    //     0xc430dc: add             x4, x4, HEAP, lsl #32
    // 0xc430e0: r8 = X0
    //     0xc430e0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc430e4: LoadField: r9 = r4->field_7
    //     0xc430e4: ldur            x9, [x4, #7]
    // 0xc430e8: r3 = Null
    //     0xc430e8: add             x3, PP, #0x29, lsl #12  ; [pp+0x294b0] Null
    //     0xc430ec: ldr             x3, [x3, #0x4b0]
    // 0xc430f0: blr             x9
    // 0xc430f4: ldr             x0, [fp, #0x18]
    // 0xc430f8: LoadField: r1 = r0->field_b
    //     0xc430f8: ldur            w1, [x0, #0xb]
    // 0xc430fc: DecompressPointer r1
    //     0xc430fc: add             x1, x1, HEAP, lsl #32
    // 0xc43100: ldr             x16, [fp, #0x10]
    // 0xc43104: stp             x16, x1, [SP, #-0x10]!
    // 0xc43108: r0 = add()
    //     0xc43108: bl              #0xc17c3c  ; [dart:_http] _WebSocketImpl::add
    // 0xc4310c: add             SP, SP, #0x10
    // 0xc43110: r0 = Null
    //     0xc43110: mov             x0, NULL
    // 0xc43114: LeaveFrame
    //     0xc43114: mov             SP, fp
    //     0xc43118: ldp             fp, lr, [SP], #0x10
    // 0xc4311c: ret
    //     0xc4311c: ret             
    // 0xc43120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43120: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc43124: b               #0xc430bc
  }
  _ addStream(/* No info */) {
    // ** addr: 0xc529b4, size: 0x6c
    // 0xc529b4: EnterFrame
    //     0xc529b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc529b8: mov             fp, SP
    // 0xc529bc: CheckStackOverflow
    //     0xc529bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc529c0: cmp             SP, x16
    //     0xc529c4: b.ls            #0xc52a18
    // 0xc529c8: ldr             x3, [fp, #0x18]
    // 0xc529cc: LoadField: r2 = r3->field_7
    //     0xc529cc: ldur            w2, [x3, #7]
    // 0xc529d0: DecompressPointer r2
    //     0xc529d0: add             x2, x2, HEAP, lsl #32
    // 0xc529d4: ldr             x0, [fp, #0x10]
    // 0xc529d8: r1 = Null
    //     0xc529d8: mov             x1, NULL
    // 0xc529dc: r8 = Stream<X0>
    //     0xc529dc: ldr             x8, [PP, #0x30c8]  ; [pp+0x30c8] Type: Stream<X0>
    // 0xc529e0: LoadField: r9 = r8->field_7
    //     0xc529e0: ldur            x9, [x8, #7]
    // 0xc529e4: r3 = Null
    //     0xc529e4: add             x3, PP, #0x20, lsl #12  ; [pp+0x20c00] Null
    //     0xc529e8: ldr             x3, [x3, #0xc00]
    // 0xc529ec: blr             x9
    // 0xc529f0: ldr             x0, [fp, #0x18]
    // 0xc529f4: LoadField: r1 = r0->field_b
    //     0xc529f4: ldur            w1, [x0, #0xb]
    // 0xc529f8: DecompressPointer r1
    //     0xc529f8: add             x1, x1, HEAP, lsl #32
    // 0xc529fc: ldr             x16, [fp, #0x10]
    // 0xc52a00: stp             x16, x1, [SP, #-0x10]!
    // 0xc52a04: r0 = addStream()
    //     0xc52a04: bl              #0xc37960  ; [dart:_http] _WebSocketImpl::addStream
    // 0xc52a08: add             SP, SP, #0x10
    // 0xc52a0c: LeaveFrame
    //     0xc52a0c: mov             SP, fp
    //     0xc52a10: ldp             fp, lr, [SP], #0x10
    // 0xc52a14: ret
    //     0xc52a14: ret             
    // 0xc52a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc52a18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc52a1c: b               #0xc529c8
  }
}

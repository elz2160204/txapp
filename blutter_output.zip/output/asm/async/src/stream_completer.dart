// lib: , url: package:async/src/stream_completer.dart

// class id: 1048666, size: 0x8
class :: {
}

// class id: 4980, size: 0x10, field offset: 0x8
class StreamCompleter<X0> extends Object {

  static _ fromFuture(/* No info */) {
    // ** addr: 0x9f66c4, size: 0x110
    // 0x9f66c4: EnterFrame
    //     0x9f66c4: stp             fp, lr, [SP, #-0x10]!
    //     0x9f66c8: mov             fp, SP
    // 0x9f66cc: AllocStack(0x18)
    //     0x9f66cc: sub             SP, SP, #0x18
    // 0x9f66d0: SetupParameters()
    //     0x9f66d0: mov             x0, x4
    //     0x9f66d4: ldur            w1, [x0, #0xf]
    //     0x9f66d8: add             x1, x1, HEAP, lsl #32
    //     0x9f66dc: cbnz            w1, #0x9f66e8
    //     0x9f66e0: mov             x0, NULL
    //     0x9f66e4: b               #0x9f66f8
    //     0x9f66e8: ldur            w1, [x0, #0x17]
    //     0x9f66ec: add             x1, x1, HEAP, lsl #32
    //     0x9f66f0: add             x0, fp, w1, sxtw #2
    //     0x9f66f4: ldr             x0, [x0, #0x10]
    //     0x9f66f8: stur            x0, [fp, #-8]
    // 0x9f66fc: CheckStackOverflow
    //     0x9f66fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9f6700: cmp             SP, x16
    //     0x9f6704: b.ls            #0x9f67cc
    // 0x9f6708: mov             x1, x0
    // 0x9f670c: r0 = StreamCompleter()
    //     0x9f670c: bl              #0x9f67e0  ; AllocateStreamCompleterStub -> StreamCompleter<X0> (size=0x10)
    // 0x9f6710: ldur            x1, [fp, #-8]
    // 0x9f6714: stur            x0, [fp, #-0x10]
    // 0x9f6718: r0 = _CompleterStream()
    //     0x9f6718: bl              #0x9f67d4  ; Allocate_CompleterStreamStub -> _CompleterStream<X0> (size=0x14)
    // 0x9f671c: mov             x1, x0
    // 0x9f6720: ldur            x0, [fp, #-0x10]
    // 0x9f6724: stur            x1, [fp, #-0x18]
    // 0x9f6728: StoreField: r0->field_b = r1
    //     0x9f6728: stur            w1, [x0, #0xb]
    // 0x9f672c: r1 = 1
    //     0x9f672c: mov             x1, #1
    // 0x9f6730: r0 = AllocateContext()
    //     0x9f6730: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9f6734: mov             x1, x0
    // 0x9f6738: ldur            x0, [fp, #-0x10]
    // 0x9f673c: StoreField: r1->field_f = r0
    //     0x9f673c: stur            w0, [x1, #0xf]
    // 0x9f6740: mov             x2, x1
    // 0x9f6744: r1 = Function 'setSourceStream':.
    //     0x9f6744: add             x1, PP, #0x20, lsl #12  ; [pp+0x20c98] AnonymousClosure: (0x9f6d44), in [package:async/src/stream_completer.dart] StreamCompleter::setSourceStream (0x9f6924)
    //     0x9f6748: ldr             x1, [x1, #0xc98]
    // 0x9f674c: r0 = AllocateClosure()
    //     0x9f674c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9f6750: ldur            x1, [fp, #-8]
    // 0x9f6754: mov             x3, x0
    // 0x9f6758: r2 = Null
    //     0x9f6758: mov             x2, NULL
    // 0x9f675c: stur            x3, [fp, #-8]
    // 0x9f6760: r8 = (dynamic this, Stream<Y0>) => void?
    //     0x9f6760: add             x8, PP, #0x20, lsl #12  ; [pp+0x20ca0] FunctionType: (dynamic this, Stream<Y0>) => void?
    //     0x9f6764: ldr             x8, [x8, #0xca0]
    // 0x9f6768: LoadField: r9 = r8->field_7
    //     0x9f6768: ldur            x9, [x8, #7]
    // 0x9f676c: r3 = Null
    //     0x9f676c: add             x3, PP, #0x20, lsl #12  ; [pp+0x20ca8] Null
    //     0x9f6770: ldr             x3, [x3, #0xca8]
    // 0x9f6774: blr             x9
    // 0x9f6778: r1 = 1
    //     0x9f6778: mov             x1, #1
    // 0x9f677c: r0 = AllocateContext()
    //     0x9f677c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9f6780: mov             x1, x0
    // 0x9f6784: ldur            x0, [fp, #-0x10]
    // 0x9f6788: StoreField: r1->field_f = r0
    //     0x9f6788: stur            w0, [x1, #0xf]
    // 0x9f678c: mov             x2, x1
    // 0x9f6790: r1 = Function 'setError':.
    //     0x9f6790: add             x1, PP, #0x20, lsl #12  ; [pp+0x20cb8] AnonymousClosure: (0x9f67ec), in [package:async/src/stream_completer.dart] StreamCompleter::setError (0x9f6874)
    //     0x9f6794: ldr             x1, [x1, #0xcb8]
    // 0x9f6798: r0 = AllocateClosure()
    //     0x9f6798: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9f679c: r16 = <void?>
    //     0x9f679c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x9f67a0: ldr             lr, [fp, #0x10]
    // 0x9f67a4: stp             lr, x16, [SP, #-0x10]!
    // 0x9f67a8: ldur            x16, [fp, #-8]
    // 0x9f67ac: stp             x0, x16, [SP, #-0x10]!
    // 0x9f67b0: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x9f67b0: ldr             x4, [PP, #0x1a30]  ; [pp+0x1a30] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x9f67b4: r0 = then()
    //     0x9f67b4: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x9f67b8: add             SP, SP, #0x20
    // 0x9f67bc: ldur            x0, [fp, #-0x18]
    // 0x9f67c0: LeaveFrame
    //     0x9f67c0: mov             SP, fp
    //     0x9f67c4: ldp             fp, lr, [SP], #0x10
    // 0x9f67c8: ret
    //     0x9f67c8: ret             
    // 0x9f67cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9f67cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9f67d0: b               #0x9f6708
  }
  [closure] void setError(dynamic, Object, [StackTrace?]) {
    // ** addr: 0x9f67ec, size: 0x88
    // 0x9f67ec: EnterFrame
    //     0x9f67ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9f67f0: mov             fp, SP
    // 0x9f67f4: mov             x0, x4
    // 0x9f67f8: LoadField: r1 = r0->field_13
    //     0x9f67f8: ldur            w1, [x0, #0x13]
    // 0x9f67fc: DecompressPointer r1
    //     0x9f67fc: add             x1, x1, HEAP, lsl #32
    // 0x9f6800: sub             x0, x1, #4
    // 0x9f6804: add             x1, fp, w0, sxtw #2
    // 0x9f6808: ldr             x1, [x1, #0x18]
    // 0x9f680c: add             x2, fp, w0, sxtw #2
    // 0x9f6810: ldr             x2, [x2, #0x10]
    // 0x9f6814: cmp             w0, #2
    // 0x9f6818: b.lt            #0x9f682c
    // 0x9f681c: add             x3, fp, w0, sxtw #2
    // 0x9f6820: ldr             x3, [x3, #8]
    // 0x9f6824: mov             x0, x3
    // 0x9f6828: b               #0x9f6830
    // 0x9f682c: r0 = Null
    //     0x9f682c: mov             x0, NULL
    // 0x9f6830: LoadField: r3 = r1->field_17
    //     0x9f6830: ldur            w3, [x1, #0x17]
    // 0x9f6834: DecompressPointer r3
    //     0x9f6834: add             x3, x3, HEAP, lsl #32
    // 0x9f6838: CheckStackOverflow
    //     0x9f6838: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9f683c: cmp             SP, x16
    //     0x9f6840: b.ls            #0x9f686c
    // 0x9f6844: LoadField: r1 = r3->field_f
    //     0x9f6844: ldur            w1, [x3, #0xf]
    // 0x9f6848: DecompressPointer r1
    //     0x9f6848: add             x1, x1, HEAP, lsl #32
    // 0x9f684c: stp             x2, x1, [SP, #-0x10]!
    // 0x9f6850: SaveReg r0
    //     0x9f6850: str             x0, [SP, #-8]!
    // 0x9f6854: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9f6854: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9f6858: r0 = setError()
    //     0x9f6858: bl              #0x9f6874  ; [package:async/src/stream_completer.dart] StreamCompleter::setError
    // 0x9f685c: add             SP, SP, #0x18
    // 0x9f6860: LeaveFrame
    //     0x9f6860: mov             SP, fp
    //     0x9f6864: ldp             fp, lr, [SP], #0x10
    // 0x9f6868: ret
    //     0x9f6868: ret             
    // 0x9f686c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9f686c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9f6870: b               #0x9f6844
  }
  _ setError(/* No info */) {
    // ** addr: 0x9f6874, size: 0xb0
    // 0x9f6874: EnterFrame
    //     0x9f6874: stp             fp, lr, [SP, #-0x10]!
    //     0x9f6878: mov             fp, SP
    // 0x9f687c: AllocStack(0x10)
    //     0x9f687c: sub             SP, SP, #0x10
    // 0x9f6880: SetupParameters(StreamCompleter<X0> this /* r1, fp-0x10 */, dynamic _ /* r2 */, [dynamic _ = Null /* r0 */])
    //     0x9f6880: mov             x0, x4
    //     0x9f6884: ldur            w1, [x0, #0x13]
    //     0x9f6888: add             x1, x1, HEAP, lsl #32
    //     0x9f688c: sub             x0, x1, #4
    //     0x9f6890: add             x1, fp, w0, sxtw #2
    //     0x9f6894: ldr             x1, [x1, #0x18]
    //     0x9f6898: stur            x1, [fp, #-0x10]
    //     0x9f689c: add             x2, fp, w0, sxtw #2
    //     0x9f68a0: ldr             x2, [x2, #0x10]
    //     0x9f68a4: cmp             w0, #2
    //     0x9f68a8: b.lt            #0x9f68bc
    //     0x9f68ac: add             x3, fp, w0, sxtw #2
    //     0x9f68b0: ldr             x3, [x3, #8]
    //     0x9f68b4: mov             x0, x3
    //     0x9f68b8: b               #0x9f68c0
    //     0x9f68bc: mov             x0, NULL
    // 0x9f68c0: CheckStackOverflow
    //     0x9f68c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9f68c4: cmp             SP, x16
    //     0x9f68c8: b.ls            #0x9f691c
    // 0x9f68cc: LoadField: r3 = r1->field_7
    //     0x9f68cc: ldur            w3, [x1, #7]
    // 0x9f68d0: DecompressPointer r3
    //     0x9f68d0: add             x3, x3, HEAP, lsl #32
    // 0x9f68d4: stur            x3, [fp, #-8]
    // 0x9f68d8: stp             x2, x3, [SP, #-0x10]!
    // 0x9f68dc: SaveReg r0
    //     0x9f68dc: str             x0, [SP, #-8]!
    // 0x9f68e0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9f68e0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9f68e4: r0 = Future.error()
    //     0x9f68e4: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0x9f68e8: add             SP, SP, #0x18
    // 0x9f68ec: ldur            x16, [fp, #-8]
    // 0x9f68f0: stp             x0, x16, [SP, #-0x10]!
    // 0x9f68f4: r0 = Stream.fromFuture()
    //     0x9f68f4: bl              #0x9f6b0c  ; [dart:async] Stream::Stream.fromFuture
    // 0x9f68f8: add             SP, SP, #0x10
    // 0x9f68fc: ldur            x16, [fp, #-0x10]
    // 0x9f6900: stp             x0, x16, [SP, #-0x10]!
    // 0x9f6904: r0 = setSourceStream()
    //     0x9f6904: bl              #0x9f6924  ; [package:async/src/stream_completer.dart] StreamCompleter::setSourceStream
    // 0x9f6908: add             SP, SP, #0x10
    // 0x9f690c: r0 = Null
    //     0x9f690c: mov             x0, NULL
    // 0x9f6910: LeaveFrame
    //     0x9f6910: mov             SP, fp
    //     0x9f6914: ldp             fp, lr, [SP], #0x10
    // 0x9f6918: ret
    //     0x9f6918: ret             
    // 0x9f691c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9f691c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9f6920: b               #0x9f68cc
  }
  _ setSourceStream(/* No info */) {
    // ** addr: 0x9f6924, size: 0xa0
    // 0x9f6924: EnterFrame
    //     0x9f6924: stp             fp, lr, [SP, #-0x10]!
    //     0x9f6928: mov             fp, SP
    // 0x9f692c: CheckStackOverflow
    //     0x9f692c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9f6930: cmp             SP, x16
    //     0x9f6934: b.ls            #0x9f69bc
    // 0x9f6938: ldr             x3, [fp, #0x18]
    // 0x9f693c: LoadField: r2 = r3->field_7
    //     0x9f693c: ldur            w2, [x3, #7]
    // 0x9f6940: DecompressPointer r2
    //     0x9f6940: add             x2, x2, HEAP, lsl #32
    // 0x9f6944: ldr             x0, [fp, #0x10]
    // 0x9f6948: r1 = Null
    //     0x9f6948: mov             x1, NULL
    // 0x9f694c: r8 = Stream<X0>
    //     0x9f694c: ldr             x8, [PP, #0x30c8]  ; [pp+0x30c8] Type: Stream<X0>
    // 0x9f6950: LoadField: r9 = r8->field_7
    //     0x9f6950: ldur            x9, [x8, #7]
    // 0x9f6954: r3 = Null
    //     0x9f6954: add             x3, PP, #0x20, lsl #12  ; [pp+0x20cc0] Null
    //     0x9f6958: ldr             x3, [x3, #0xcc0]
    // 0x9f695c: blr             x9
    // 0x9f6960: ldr             x0, [fp, #0x18]
    // 0x9f6964: LoadField: r1 = r0->field_b
    //     0x9f6964: ldur            w1, [x0, #0xb]
    // 0x9f6968: DecompressPointer r1
    //     0x9f6968: add             x1, x1, HEAP, lsl #32
    // 0x9f696c: LoadField: r0 = r1->field_f
    //     0x9f696c: ldur            w0, [x1, #0xf]
    // 0x9f6970: DecompressPointer r0
    //     0x9f6970: add             x0, x0, HEAP, lsl #32
    // 0x9f6974: cmp             w0, NULL
    // 0x9f6978: b.ne            #0x9f699c
    // 0x9f697c: ldr             x16, [fp, #0x10]
    // 0x9f6980: stp             x16, x1, [SP, #-0x10]!
    // 0x9f6984: r0 = _setSourceStream()
    //     0x9f6984: bl              #0x9f69c4  ; [package:async/src/stream_completer.dart] _CompleterStream::_setSourceStream
    // 0x9f6988: add             SP, SP, #0x10
    // 0x9f698c: r0 = Null
    //     0x9f698c: mov             x0, NULL
    // 0x9f6990: LeaveFrame
    //     0x9f6990: mov             SP, fp
    //     0x9f6994: ldp             fp, lr, [SP], #0x10
    // 0x9f6998: ret
    //     0x9f6998: ret             
    // 0x9f699c: r0 = StateError()
    //     0x9f699c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x9f69a0: mov             x1, x0
    // 0x9f69a4: r0 = "Source stream already set"
    //     0x9f69a4: add             x0, PP, #0x20, lsl #12  ; [pp+0x20cd0] "Source stream already set"
    //     0x9f69a8: ldr             x0, [x0, #0xcd0]
    // 0x9f69ac: StoreField: r1->field_b = r0
    //     0x9f69ac: stur            w0, [x1, #0xb]
    // 0x9f69b0: mov             x0, x1
    // 0x9f69b4: r0 = Throw()
    //     0x9f69b4: bl              #0xd67e38  ; ThrowStub
    // 0x9f69b8: brk             #0
    // 0x9f69bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9f69bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9f69c0: b               #0x9f6938
  }
  [closure] void setSourceStream(dynamic, Object?) {
    // ** addr: 0x9f6d44, size: 0x4c
    // 0x9f6d44: EnterFrame
    //     0x9f6d44: stp             fp, lr, [SP, #-0x10]!
    //     0x9f6d48: mov             fp, SP
    // 0x9f6d4c: ldr             x0, [fp, #0x18]
    // 0x9f6d50: LoadField: r1 = r0->field_17
    //     0x9f6d50: ldur            w1, [x0, #0x17]
    // 0x9f6d54: DecompressPointer r1
    //     0x9f6d54: add             x1, x1, HEAP, lsl #32
    // 0x9f6d58: CheckStackOverflow
    //     0x9f6d58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9f6d5c: cmp             SP, x16
    //     0x9f6d60: b.ls            #0x9f6d88
    // 0x9f6d64: LoadField: r0 = r1->field_f
    //     0x9f6d64: ldur            w0, [x1, #0xf]
    // 0x9f6d68: DecompressPointer r0
    //     0x9f6d68: add             x0, x0, HEAP, lsl #32
    // 0x9f6d6c: ldr             x16, [fp, #0x10]
    // 0x9f6d70: stp             x16, x0, [SP, #-0x10]!
    // 0x9f6d74: r0 = setSourceStream()
    //     0x9f6d74: bl              #0x9f6924  ; [package:async/src/stream_completer.dart] StreamCompleter::setSourceStream
    // 0x9f6d78: add             SP, SP, #0x10
    // 0x9f6d7c: LeaveFrame
    //     0x9f6d7c: mov             SP, fp
    //     0x9f6d80: ldp             fp, lr, [SP], #0x10
    // 0x9f6d84: ret
    //     0x9f6d84: ret             
    // 0x9f6d88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9f6d88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9f6d8c: b               #0x9f6d64
  }
}

// class id: 5629, size: 0x14, field offset: 0xc
class _CompleterStream<X0> extends Stream<X0> {

  _ _setSourceStream(/* No info */) {
    // ** addr: 0x9f69c4, size: 0x94
    // 0x9f69c4: EnterFrame
    //     0x9f69c4: stp             fp, lr, [SP, #-0x10]!
    //     0x9f69c8: mov             fp, SP
    // 0x9f69cc: CheckStackOverflow
    //     0x9f69cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9f69d0: cmp             SP, x16
    //     0x9f69d4: b.ls            #0x9f6a50
    // 0x9f69d8: ldr             x3, [fp, #0x18]
    // 0x9f69dc: LoadField: r2 = r3->field_7
    //     0x9f69dc: ldur            w2, [x3, #7]
    // 0x9f69e0: DecompressPointer r2
    //     0x9f69e0: add             x2, x2, HEAP, lsl #32
    // 0x9f69e4: ldr             x0, [fp, #0x10]
    // 0x9f69e8: r1 = Null
    //     0x9f69e8: mov             x1, NULL
    // 0x9f69ec: r8 = Stream<X0>
    //     0x9f69ec: ldr             x8, [PP, #0x30c8]  ; [pp+0x30c8] Type: Stream<X0>
    // 0x9f69f0: LoadField: r9 = r8->field_7
    //     0x9f69f0: ldur            x9, [x8, #7]
    // 0x9f69f4: r3 = Null
    //     0x9f69f4: add             x3, PP, #0x20, lsl #12  ; [pp+0x20cd8] Null
    //     0x9f69f8: ldr             x3, [x3, #0xcd8]
    // 0x9f69fc: blr             x9
    // 0x9f6a00: ldr             x0, [fp, #0x10]
    // 0x9f6a04: ldr             x1, [fp, #0x18]
    // 0x9f6a08: StoreField: r1->field_f = r0
    //     0x9f6a08: stur            w0, [x1, #0xf]
    //     0x9f6a0c: ldurb           w16, [x1, #-1]
    //     0x9f6a10: ldurb           w17, [x0, #-1]
    //     0x9f6a14: and             x16, x17, x16, lsr #2
    //     0x9f6a18: tst             x16, HEAP, lsr #32
    //     0x9f6a1c: b.eq            #0x9f6a24
    //     0x9f6a20: bl              #0xd6826c
    // 0x9f6a24: LoadField: r0 = r1->field_b
    //     0x9f6a24: ldur            w0, [x1, #0xb]
    // 0x9f6a28: DecompressPointer r0
    //     0x9f6a28: add             x0, x0, HEAP, lsl #32
    // 0x9f6a2c: cmp             w0, NULL
    // 0x9f6a30: b.eq            #0x9f6a40
    // 0x9f6a34: SaveReg r1
    //     0x9f6a34: str             x1, [SP, #-8]!
    // 0x9f6a38: r0 = _linkStreamToController()
    //     0x9f6a38: bl              #0x9f6a58  ; [package:async/src/stream_completer.dart] _CompleterStream::_linkStreamToController
    // 0x9f6a3c: add             SP, SP, #8
    // 0x9f6a40: r0 = Null
    //     0x9f6a40: mov             x0, NULL
    // 0x9f6a44: LeaveFrame
    //     0x9f6a44: mov             SP, fp
    //     0x9f6a48: ldp             fp, lr, [SP], #0x10
    // 0x9f6a4c: ret
    //     0x9f6a4c: ret             
    // 0x9f6a50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9f6a50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9f6a54: b               #0x9f69d8
  }
  _ _linkStreamToController(/* No info */) {
    // ** addr: 0x9f6a58, size: 0xb4
    // 0x9f6a58: EnterFrame
    //     0x9f6a58: stp             fp, lr, [SP, #-0x10]!
    //     0x9f6a5c: mov             fp, SP
    // 0x9f6a60: AllocStack(0x10)
    //     0x9f6a60: sub             SP, SP, #0x10
    // 0x9f6a64: CheckStackOverflow
    //     0x9f6a64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9f6a68: cmp             SP, x16
    //     0x9f6a6c: b.ls            #0x9f6afc
    // 0x9f6a70: ldr             x0, [fp, #0x10]
    // 0x9f6a74: LoadField: r1 = r0->field_b
    //     0x9f6a74: ldur            w1, [x0, #0xb]
    // 0x9f6a78: DecompressPointer r1
    //     0x9f6a78: add             x1, x1, HEAP, lsl #32
    // 0x9f6a7c: stur            x1, [fp, #-8]
    // 0x9f6a80: cmp             w1, NULL
    // 0x9f6a84: b.eq            #0x9f6b04
    // 0x9f6a88: LoadField: r2 = r0->field_f
    //     0x9f6a88: ldur            w2, [x0, #0xf]
    // 0x9f6a8c: DecompressPointer r2
    //     0x9f6a8c: add             x2, x2, HEAP, lsl #32
    // 0x9f6a90: cmp             w2, NULL
    // 0x9f6a94: b.eq            #0x9f6b08
    // 0x9f6a98: stp             x2, x1, [SP, #-0x10]!
    // 0x9f6a9c: r16 = false
    //     0x9f6a9c: add             x16, NULL, #0x30  ; false
    // 0x9f6aa0: SaveReg r16
    //     0x9f6aa0: str             x16, [SP, #-8]!
    // 0x9f6aa4: r4 = const [0, 0x3, 0x3, 0x2, cancelOnError, 0x2, null]
    //     0x9f6aa4: ldr             x4, [PP, #0x30e8]  ; [pp+0x30e8] List(7) [0, 0x3, 0x3, 0x2, "cancelOnError", 0x2, Null]
    // 0x9f6aa8: r0 = addStream()
    //     0x9f6aa8: bl              #0xc399a8  ; [dart:async] _StreamController::addStream
    // 0x9f6aac: add             SP, SP, #0x18
    // 0x9f6ab0: mov             x1, x0
    // 0x9f6ab4: ldur            x0, [fp, #-8]
    // 0x9f6ab8: stur            x1, [fp, #-0x10]
    // 0x9f6abc: r2 = LoadClassIdInstr(r0)
    //     0x9f6abc: ldur            x2, [x0, #-1]
    //     0x9f6ac0: ubfx            x2, x2, #0xc, #0x14
    // 0x9f6ac4: SaveReg r0
    //     0x9f6ac4: str             x0, [SP, #-8]!
    // 0x9f6ac8: mov             x0, x2
    // 0x9f6acc: r0 = GDT[cid_x0 + 0xeb8]()
    //     0x9f6acc: add             lr, x0, #0xeb8
    //     0x9f6ad0: ldr             lr, [x21, lr, lsl #3]
    //     0x9f6ad4: blr             lr
    // 0x9f6ad8: add             SP, SP, #8
    // 0x9f6adc: ldur            x16, [fp, #-0x10]
    // 0x9f6ae0: stp             x0, x16, [SP, #-0x10]!
    // 0x9f6ae4: r0 = whenComplete()
    //     0x9f6ae4: bl              #0xca6034  ; [dart:async] _Future::whenComplete
    // 0x9f6ae8: add             SP, SP, #0x10
    // 0x9f6aec: r0 = Null
    //     0x9f6aec: mov             x0, NULL
    // 0x9f6af0: LeaveFrame
    //     0x9f6af0: mov             SP, fp
    //     0x9f6af4: ldp             fp, lr, [SP], #0x10
    // 0x9f6af8: ret
    //     0x9f6af8: ret             
    // 0x9f6afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9f6afc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9f6b00: b               #0x9f6a70
    // 0x9f6b04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9f6b04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9f6b08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9f6b08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ listen(/* No info */) {
    // ** addr: 0xc59ccc, size: 0x258
    // 0xc59ccc: EnterFrame
    //     0xc59ccc: stp             fp, lr, [SP, #-0x10]!
    //     0xc59cd0: mov             fp, SP
    // 0xc59cd4: AllocStack(0x30)
    //     0xc59cd4: sub             SP, SP, #0x30
    // 0xc59cd8: SetupParameters(_CompleterStream<X0> this /* r3, fp-0x30 */, dynamic _ /* r4, fp-0x28 */, {dynamic cancelOnError = Null /* r5, fp-0x20 */, dynamic onDone = Null /* r6, fp-0x18 */, dynamic onError = Null /* r1, fp-0x10 */})
    //     0xc59cd8: mov             x0, x4
    //     0xc59cdc: ldur            w1, [x0, #0x13]
    //     0xc59ce0: add             x1, x1, HEAP, lsl #32
    //     0xc59ce4: sub             x2, x1, #4
    //     0xc59ce8: add             x3, fp, w2, sxtw #2
    //     0xc59cec: ldr             x3, [x3, #0x18]
    //     0xc59cf0: stur            x3, [fp, #-0x30]
    //     0xc59cf4: add             x4, fp, w2, sxtw #2
    //     0xc59cf8: ldr             x4, [x4, #0x10]
    //     0xc59cfc: stur            x4, [fp, #-0x28]
    //     0xc59d00: ldur            w2, [x0, #0x1f]
    //     0xc59d04: add             x2, x2, HEAP, lsl #32
    //     0xc59d08: ldr             x16, [PP, #0x79e0]  ; [pp+0x79e0] "cancelOnError"
    //     0xc59d0c: cmp             w2, w16
    //     0xc59d10: b.ne            #0xc59d34
    //     0xc59d14: ldur            w2, [x0, #0x23]
    //     0xc59d18: add             x2, x2, HEAP, lsl #32
    //     0xc59d1c: sub             w5, w1, w2
    //     0xc59d20: add             x2, fp, w5, sxtw #2
    //     0xc59d24: ldr             x2, [x2, #8]
    //     0xc59d28: mov             x5, x2
    //     0xc59d2c: mov             x2, #1
    //     0xc59d30: b               #0xc59d3c
    //     0xc59d34: mov             x5, NULL
    //     0xc59d38: mov             x2, #0
    //     0xc59d3c: stur            x5, [fp, #-0x20]
    //     0xc59d40: lsl             x6, x2, #1
    //     0xc59d44: lsl             w7, w6, #1
    //     0xc59d48: add             w8, w7, #8
    //     0xc59d4c: add             x16, x0, w8, sxtw #1
    //     0xc59d50: ldur            w9, [x16, #0xf]
    //     0xc59d54: add             x9, x9, HEAP, lsl #32
    //     0xc59d58: ldr             x16, [PP, #0x79e8]  ; [pp+0x79e8] "onDone"
    //     0xc59d5c: cmp             w9, w16
    //     0xc59d60: b.ne            #0xc59d94
    //     0xc59d64: add             w2, w7, #0xa
    //     0xc59d68: add             x16, x0, w2, sxtw #1
    //     0xc59d6c: ldur            w7, [x16, #0xf]
    //     0xc59d70: add             x7, x7, HEAP, lsl #32
    //     0xc59d74: sub             w2, w1, w7
    //     0xc59d78: add             x7, fp, w2, sxtw #2
    //     0xc59d7c: ldr             x7, [x7, #8]
    //     0xc59d80: add             w2, w6, #2
    //     0xc59d84: sbfx            x6, x2, #1, #0x1f
    //     0xc59d88: mov             x2, x6
    //     0xc59d8c: mov             x6, x7
    //     0xc59d90: b               #0xc59d98
    //     0xc59d94: mov             x6, NULL
    //     0xc59d98: stur            x6, [fp, #-0x18]
    //     0xc59d9c: lsl             x7, x2, #1
    //     0xc59da0: lsl             w2, w7, #1
    //     0xc59da4: add             w7, w2, #8
    //     0xc59da8: add             x16, x0, w7, sxtw #1
    //     0xc59dac: ldur            w8, [x16, #0xf]
    //     0xc59db0: add             x8, x8, HEAP, lsl #32
    //     0xc59db4: ldr             x16, [PP, #0x19a0]  ; [pp+0x19a0] "onError"
    //     0xc59db8: cmp             w8, w16
    //     0xc59dbc: b.ne            #0xc59de0
    //     0xc59dc0: add             w7, w2, #0xa
    //     0xc59dc4: add             x16, x0, w7, sxtw #1
    //     0xc59dc8: ldur            w2, [x16, #0xf]
    //     0xc59dcc: add             x2, x2, HEAP, lsl #32
    //     0xc59dd0: sub             w0, w1, w2
    //     0xc59dd4: add             x1, fp, w0, sxtw #2
    //     0xc59dd8: ldr             x1, [x1, #8]
    //     0xc59ddc: b               #0xc59de4
    //     0xc59de0: mov             x1, NULL
    //     0xc59de4: stur            x1, [fp, #-0x10]
    // 0xc59de8: CheckStackOverflow
    //     0xc59de8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc59dec: cmp             SP, x16
    //     0xc59df0: b.ls            #0xc59f18
    // 0xc59df4: LoadField: r0 = r3->field_b
    //     0xc59df4: ldur            w0, [x3, #0xb]
    // 0xc59df8: DecompressPointer r0
    //     0xc59df8: add             x0, x0, HEAP, lsl #32
    // 0xc59dfc: cmp             w0, NULL
    // 0xc59e00: b.ne            #0xc59eb4
    // 0xc59e04: LoadField: r2 = r3->field_f
    //     0xc59e04: ldur            w2, [x3, #0xf]
    // 0xc59e08: DecompressPointer r2
    //     0xc59e08: add             x2, x2, HEAP, lsl #32
    // 0xc59e0c: stur            x2, [fp, #-8]
    // 0xc59e10: cmp             w2, NULL
    // 0xc59e14: b.eq            #0xc59e84
    // 0xc59e18: r0 = LoadClassIdInstr(r2)
    //     0xc59e18: ldur            x0, [x2, #-1]
    //     0xc59e1c: ubfx            x0, x0, #0xc, #0x14
    // 0xc59e20: SaveReg r2
    //     0xc59e20: str             x2, [SP, #-8]!
    // 0xc59e24: r0 = GDT[cid_x0 + 0x811]()
    //     0xc59e24: add             lr, x0, #0x811
    //     0xc59e28: ldr             lr, [x21, lr, lsl #3]
    //     0xc59e2c: blr             lr
    // 0xc59e30: add             SP, SP, #8
    // 0xc59e34: tbz             w0, #4, #0xc59e84
    // 0xc59e38: ldur            x0, [fp, #-8]
    // 0xc59e3c: r1 = LoadClassIdInstr(r0)
    //     0xc59e3c: ldur            x1, [x0, #-1]
    //     0xc59e40: ubfx            x1, x1, #0xc, #0x14
    // 0xc59e44: ldur            x16, [fp, #-0x28]
    // 0xc59e48: stp             x16, x0, [SP, #-0x10]!
    // 0xc59e4c: ldur            x16, [fp, #-0x10]
    // 0xc59e50: ldur            lr, [fp, #-0x18]
    // 0xc59e54: stp             lr, x16, [SP, #-0x10]!
    // 0xc59e58: ldur            x16, [fp, #-0x20]
    // 0xc59e5c: SaveReg r16
    //     0xc59e5c: str             x16, [SP, #-8]!
    // 0xc59e60: mov             x0, x1
    // 0xc59e64: r4 = const [0, 0x5, 0x5, 0x2, cancelOnError, 0x4, onDone, 0x3, onError, 0x2, null]
    //     0xc59e64: ldr             x4, [PP, #0x6868]  ; [pp+0x6868] List(11) [0, 0x5, 0x5, 0x2, "cancelOnError", 0x4, "onDone", 0x3, "onError", 0x2, Null]
    // 0xc59e68: r0 = GDT[cid_x0 + 0x28a]()
    //     0xc59e68: add             lr, x0, #0x28a
    //     0xc59e6c: ldr             lr, [x21, lr, lsl #3]
    //     0xc59e70: blr             lr
    // 0xc59e74: add             SP, SP, #0x28
    // 0xc59e78: LeaveFrame
    //     0xc59e78: mov             SP, fp
    //     0xc59e7c: ldp             fp, lr, [SP], #0x10
    // 0xc59e80: ret
    //     0xc59e80: ret             
    // 0xc59e84: ldur            x0, [fp, #-0x30]
    // 0xc59e88: SaveReg r0
    //     0xc59e88: str             x0, [SP, #-8]!
    // 0xc59e8c: r0 = _ensureController()
    //     0xc59e8c: bl              #0xc59f24  ; [package:async/src/stream_completer.dart] _CompleterStream::_ensureController
    // 0xc59e90: add             SP, SP, #8
    // 0xc59e94: ldur            x0, [fp, #-0x30]
    // 0xc59e98: LoadField: r1 = r0->field_f
    //     0xc59e98: ldur            w1, [x0, #0xf]
    // 0xc59e9c: DecompressPointer r1
    //     0xc59e9c: add             x1, x1, HEAP, lsl #32
    // 0xc59ea0: cmp             w1, NULL
    // 0xc59ea4: b.eq            #0xc59eb4
    // 0xc59ea8: SaveReg r0
    //     0xc59ea8: str             x0, [SP, #-8]!
    // 0xc59eac: r0 = _linkStreamToController()
    //     0xc59eac: bl              #0x9f6a58  ; [package:async/src/stream_completer.dart] _CompleterStream::_linkStreamToController
    // 0xc59eb0: add             SP, SP, #8
    // 0xc59eb4: ldur            x0, [fp, #-0x30]
    // 0xc59eb8: LoadField: r2 = r0->field_b
    //     0xc59eb8: ldur            w2, [x0, #0xb]
    // 0xc59ebc: DecompressPointer r2
    //     0xc59ebc: add             x2, x2, HEAP, lsl #32
    // 0xc59ec0: stur            x2, [fp, #-8]
    // 0xc59ec4: cmp             w2, NULL
    // 0xc59ec8: b.eq            #0xc59f20
    // 0xc59ecc: LoadField: r1 = r2->field_7
    //     0xc59ecc: ldur            w1, [x2, #7]
    // 0xc59ed0: DecompressPointer r1
    //     0xc59ed0: add             x1, x1, HEAP, lsl #32
    // 0xc59ed4: r0 = _ControllerStream()
    //     0xc59ed4: bl              #0x534e34  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x14)
    // 0xc59ed8: mov             x1, x0
    // 0xc59edc: ldur            x0, [fp, #-8]
    // 0xc59ee0: StoreField: r1->field_f = r0
    //     0xc59ee0: stur            w0, [x1, #0xf]
    // 0xc59ee4: ldur            x16, [fp, #-0x28]
    // 0xc59ee8: stp             x16, x1, [SP, #-0x10]!
    // 0xc59eec: ldur            x16, [fp, #-0x10]
    // 0xc59ef0: ldur            lr, [fp, #-0x18]
    // 0xc59ef4: stp             lr, x16, [SP, #-0x10]!
    // 0xc59ef8: ldur            x16, [fp, #-0x20]
    // 0xc59efc: SaveReg r16
    //     0xc59efc: str             x16, [SP, #-8]!
    // 0xc59f00: r4 = const [0, 0x5, 0x5, 0x2, cancelOnError, 0x4, onDone, 0x3, onError, 0x2, null]
    //     0xc59f00: ldr             x4, [PP, #0x6868]  ; [pp+0x6868] List(11) [0, 0x5, 0x5, 0x2, "cancelOnError", 0x4, "onDone", 0x3, "onError", 0x2, Null]
    // 0xc59f04: r0 = listen()
    //     0xc59f04: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xc59f08: add             SP, SP, #0x28
    // 0xc59f0c: LeaveFrame
    //     0xc59f0c: mov             SP, fp
    //     0xc59f10: ldp             fp, lr, [SP], #0x10
    // 0xc59f14: ret
    //     0xc59f14: ret             
    // 0xc59f18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc59f18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc59f1c: b               #0xc59df4
    // 0xc59f20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc59f20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _ensureController(/* No info */) {
    // ** addr: 0xc59f24, size: 0x8c
    // 0xc59f24: EnterFrame
    //     0xc59f24: stp             fp, lr, [SP, #-0x10]!
    //     0xc59f28: mov             fp, SP
    // 0xc59f2c: CheckStackOverflow
    //     0xc59f2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc59f30: cmp             SP, x16
    //     0xc59f34: b.ls            #0xc59fa8
    // 0xc59f38: ldr             x0, [fp, #0x10]
    // 0xc59f3c: LoadField: r1 = r0->field_b
    //     0xc59f3c: ldur            w1, [x0, #0xb]
    // 0xc59f40: DecompressPointer r1
    //     0xc59f40: add             x1, x1, HEAP, lsl #32
    // 0xc59f44: cmp             w1, NULL
    // 0xc59f48: b.ne            #0xc59f98
    // 0xc59f4c: LoadField: r1 = r0->field_7
    //     0xc59f4c: ldur            w1, [x0, #7]
    // 0xc59f50: DecompressPointer r1
    //     0xc59f50: add             x1, x1, HEAP, lsl #32
    // 0xc59f54: r16 = true
    //     0xc59f54: add             x16, NULL, #0x20  ; true
    // 0xc59f58: stp             x16, x1, [SP, #-0x10]!
    // 0xc59f5c: r4 = const [0, 0x2, 0x2, 0x1, sync, 0x1, null]
    //     0xc59f5c: ldr             x4, [PP, #0x31b0]  ; [pp+0x31b0] List(7) [0, 0x2, 0x2, 0x1, "sync", 0x1, Null]
    // 0xc59f60: r0 = StreamController()
    //     0xc59f60: bl              #0x534f54  ; [dart:async] StreamController::StreamController
    // 0xc59f64: add             SP, SP, #0x10
    // 0xc59f68: mov             x1, x0
    // 0xc59f6c: ldr             x2, [fp, #0x10]
    // 0xc59f70: StoreField: r2->field_b = r0
    //     0xc59f70: stur            w0, [x2, #0xb]
    //     0xc59f74: tbz             w0, #0, #0xc59f90
    //     0xc59f78: ldurb           w16, [x2, #-1]
    //     0xc59f7c: ldurb           w17, [x0, #-1]
    //     0xc59f80: and             x16, x17, x16, lsr #2
    //     0xc59f84: tst             x16, HEAP, lsr #32
    //     0xc59f88: b.eq            #0xc59f90
    //     0xc59f8c: bl              #0xd6828c
    // 0xc59f90: mov             x0, x1
    // 0xc59f94: b               #0xc59f9c
    // 0xc59f98: mov             x0, x1
    // 0xc59f9c: LeaveFrame
    //     0xc59f9c: mov             SP, fp
    //     0xc59fa0: ldp             fp, lr, [SP], #0x10
    // 0xc59fa4: ret
    //     0xc59fa4: ret             
    // 0xc59fa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc59fa8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc59fac: b               #0xc59f38
  }
}

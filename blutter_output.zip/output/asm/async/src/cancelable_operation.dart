// lib: , url: package:async/src/cancelable_operation.dart

// class id: 1048642, size: 0x8
class :: {
}

// class id: 4984, size: 0x20, field offset: 0x8
class CancelableCompleter<X0> extends Object {

  late final CancelableOperation<X0> operation; // offset: 0x1c

  _ complete(/* No info */) {
    // ** addr: 0x52ea54, size: 0x1ec
    // 0x52ea54: EnterFrame
    //     0x52ea54: stp             fp, lr, [SP, #-0x10]!
    //     0x52ea58: mov             fp, SP
    // 0x52ea5c: AllocStack(0x18)
    //     0x52ea5c: sub             SP, SP, #0x18
    // 0x52ea60: CheckStackOverflow
    //     0x52ea60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52ea64: cmp             SP, x16
    //     0x52ea68: b.ls            #0x52ec38
    // 0x52ea6c: r1 = 1
    //     0x52ea6c: mov             x1, #1
    // 0x52ea70: r0 = AllocateContext()
    //     0x52ea70: bl              #0xd68aa4  ; AllocateContextStub
    // 0x52ea74: mov             x4, x0
    // 0x52ea78: ldr             x3, [fp, #0x18]
    // 0x52ea7c: stur            x4, [fp, #-0x10]
    // 0x52ea80: StoreField: r4->field_f = r3
    //     0x52ea80: stur            w3, [x4, #0xf]
    // 0x52ea84: LoadField: r5 = r3->field_7
    //     0x52ea84: ldur            w5, [x3, #7]
    // 0x52ea88: DecompressPointer r5
    //     0x52ea88: add             x5, x5, HEAP, lsl #32
    // 0x52ea8c: ldr             x0, [fp, #0x10]
    // 0x52ea90: mov             x2, x5
    // 0x52ea94: stur            x5, [fp, #-8]
    // 0x52ea98: r1 = Null
    //     0x52ea98: mov             x1, NULL
    // 0x52ea9c: r8 = FutureOr<X0>?
    //     0x52ea9c: ldr             x8, [PP, #0x1798]  ; [pp+0x1798] Type: FutureOr<X0>?
    // 0x52eaa0: LoadField: r9 = r8->field_7
    //     0x52eaa0: ldur            x9, [x8, #7]
    // 0x52eaa4: r3 = Null
    //     0x52eaa4: add             x3, PP, #0x13, lsl #12  ; [pp+0x13388] Null
    //     0x52eaa8: ldr             x3, [x3, #0x388]
    // 0x52eaac: blr             x9
    // 0x52eab0: ldr             x3, [fp, #0x18]
    // 0x52eab4: LoadField: r0 = r3->field_17
    //     0x52eab4: ldur            w0, [x3, #0x17]
    // 0x52eab8: DecompressPointer r0
    //     0x52eab8: add             x0, x0, HEAP, lsl #32
    // 0x52eabc: tbnz            w0, #4, #0x52ec18
    // 0x52eac0: r0 = false
    //     0x52eac0: add             x0, NULL, #0x30  ; false
    // 0x52eac4: StoreField: r3->field_17 = r0
    //     0x52eac4: stur            w0, [x3, #0x17]
    // 0x52eac8: ldr             x0, [fp, #0x10]
    // 0x52eacc: ldur            x2, [fp, #-8]
    // 0x52ead0: r1 = Null
    //     0x52ead0: mov             x1, NULL
    // 0x52ead4: cmp             w0, NULL
    // 0x52ead8: b.eq            #0x52eb2c
    // 0x52eadc: branchIfSmi(r0, 0x52eb2c)
    //     0x52eadc: tbz             w0, #0, #0x52eb2c
    // 0x52eae0: r8 = Future<X0>
    //     0x52eae0: add             x8, PP, #0x13, lsl #12  ; [pp+0x13398] Type: Future<X0>
    //     0x52eae4: ldr             x8, [x8, #0x398]
    // 0x52eae8: r3 = SubtypeTestCache
    //     0x52eae8: add             x3, PP, #0x13, lsl #12  ; [pp+0x133a0] SubtypeTestCache
    //     0x52eaec: ldr             x3, [x3, #0x3a0]
    // 0x52eaf0: r24 = Subtype5TestCacheStub
    //     0x52eaf0: ldr             x24, [PP, #0xc78]  ; [pp+0xc78] Stub: Subtype5TestCache (0x4ae1bc)
    // 0x52eaf4: LoadField: r30 = r24->field_7
    //     0x52eaf4: ldur            lr, [x24, #7]
    // 0x52eaf8: blr             lr
    // 0x52eafc: cmp             w7, NULL
    // 0x52eb00: b.eq            #0x52eb0c
    // 0x52eb04: tbnz            w7, #4, #0x52eb2c
    // 0x52eb08: b               #0x52eb34
    // 0x52eb0c: r8 = Future<X0>
    //     0x52eb0c: add             x8, PP, #0x13, lsl #12  ; [pp+0x133a8] Type: Future<X0>
    //     0x52eb10: ldr             x8, [x8, #0x3a8]
    // 0x52eb14: r3 = SubtypeTestCache
    //     0x52eb14: add             x3, PP, #0x13, lsl #12  ; [pp+0x133b0] SubtypeTestCache
    //     0x52eb18: ldr             x3, [x3, #0x3b0]
    // 0x52eb1c: r24 = InstanceOfStub
    //     0x52eb1c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x52eb20: LoadField: r30 = r24->field_7
    //     0x52eb20: ldur            lr, [x24, #7]
    // 0x52eb24: blr             lr
    // 0x52eb28: b               #0x52eb38
    // 0x52eb2c: r0 = false
    //     0x52eb2c: add             x0, NULL, #0x30  ; false
    // 0x52eb30: b               #0x52eb38
    // 0x52eb34: r0 = true
    //     0x52eb34: add             x0, NULL, #0x20  ; true
    // 0x52eb38: tbz             w0, #4, #0x52eb78
    // 0x52eb3c: ldr             x16, [fp, #0x18]
    // 0x52eb40: SaveReg r16
    //     0x52eb40: str             x16, [SP, #-8]!
    // 0x52eb44: r0 = _completeNow()
    //     0x52eb44: bl              #0x52ed78  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::_completeNow
    // 0x52eb48: add             SP, SP, #8
    // 0x52eb4c: cmp             w0, NULL
    // 0x52eb50: b.eq            #0x52eb68
    // 0x52eb54: ldr             x16, [fp, #0x10]
    // 0x52eb58: stp             x16, x0, [SP, #-0x10]!
    // 0x52eb5c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x52eb5c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x52eb60: r0 = complete()
    //     0x52eb60: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x52eb64: add             SP, SP, #0x10
    // 0x52eb68: r0 = Null
    //     0x52eb68: mov             x0, NULL
    // 0x52eb6c: LeaveFrame
    //     0x52eb6c: mov             SP, fp
    //     0x52eb70: ldp             fp, lr, [SP], #0x10
    // 0x52eb74: ret
    //     0x52eb74: ret             
    // 0x52eb78: ldr             x0, [fp, #0x18]
    // 0x52eb7c: LoadField: r1 = r0->field_b
    //     0x52eb7c: ldur            w1, [x0, #0xb]
    // 0x52eb80: DecompressPointer r1
    //     0x52eb80: add             x1, x1, HEAP, lsl #32
    // 0x52eb84: cmp             w1, NULL
    // 0x52eb88: b.ne            #0x52ebb4
    // 0x52eb8c: ldur            x16, [fp, #-8]
    // 0x52eb90: ldr             lr, [fp, #0x10]
    // 0x52eb94: stp             lr, x16, [SP, #-0x10]!
    // 0x52eb98: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x52eb98: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x52eb9c: r0 = FutureExtensions.ignore()
    //     0x52eb9c: bl              #0x52ec40  ; [dart:async] ::FutureExtensions.ignore
    // 0x52eba0: add             SP, SP, #0x10
    // 0x52eba4: r0 = Null
    //     0x52eba4: mov             x0, NULL
    // 0x52eba8: LeaveFrame
    //     0x52eba8: mov             SP, fp
    //     0x52ebac: ldp             fp, lr, [SP], #0x10
    // 0x52ebb0: ret
    //     0x52ebb0: ret             
    // 0x52ebb4: ldur            x0, [fp, #-8]
    // 0x52ebb8: ldur            x2, [fp, #-0x10]
    // 0x52ebbc: r1 = Function '<anonymous closure>':.
    //     0x52ebbc: add             x1, PP, #0x13, lsl #12  ; [pp+0x133b8] AnonymousClosure: (0x52ee0c), in [package:async/src/cancelable_operation.dart] CancelableCompleter::complete (0x52ea54)
    //     0x52ebc0: ldr             x1, [x1, #0x3b8]
    // 0x52ebc4: r0 = AllocateClosure()
    //     0x52ebc4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52ebc8: mov             x3, x0
    // 0x52ebcc: ldur            x0, [fp, #-8]
    // 0x52ebd0: stur            x3, [fp, #-0x18]
    // 0x52ebd4: StoreField: r3->field_7 = r0
    //     0x52ebd4: stur            w0, [x3, #7]
    // 0x52ebd8: ldur            x2, [fp, #-0x10]
    // 0x52ebdc: r1 = Function '<anonymous closure>':.
    //     0x52ebdc: add             x1, PP, #0x13, lsl #12  ; [pp+0x133c0] AnonymousClosure: (0x52ed9c), in [package:async/src/cancelable_operation.dart] CancelableCompleter::complete (0x52ea54)
    //     0x52ebe0: ldr             x1, [x1, #0x3c0]
    // 0x52ebe4: r0 = AllocateClosure()
    //     0x52ebe4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52ebe8: r16 = <Null?>
    //     0x52ebe8: ldr             x16, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    // 0x52ebec: ldr             lr, [fp, #0x10]
    // 0x52ebf0: stp             lr, x16, [SP, #-0x10]!
    // 0x52ebf4: ldur            x16, [fp, #-0x18]
    // 0x52ebf8: stp             x0, x16, [SP, #-0x10]!
    // 0x52ebfc: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x52ebfc: ldr             x4, [PP, #0x1a30]  ; [pp+0x1a30] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x52ec00: r0 = then()
    //     0x52ec00: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x52ec04: add             SP, SP, #0x20
    // 0x52ec08: r0 = Null
    //     0x52ec08: mov             x0, NULL
    // 0x52ec0c: LeaveFrame
    //     0x52ec0c: mov             SP, fp
    //     0x52ec10: ldp             fp, lr, [SP], #0x10
    // 0x52ec14: ret
    //     0x52ec14: ret             
    // 0x52ec18: r0 = StateError()
    //     0x52ec18: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x52ec1c: mov             x1, x0
    // 0x52ec20: r0 = "Operation already completed"
    //     0x52ec20: add             x0, PP, #0x13, lsl #12  ; [pp+0x133c8] "Operation already completed"
    //     0x52ec24: ldr             x0, [x0, #0x3c8]
    // 0x52ec28: StoreField: r1->field_b = r0
    //     0x52ec28: stur            w0, [x1, #0xb]
    // 0x52ec2c: mov             x0, x1
    // 0x52ec30: r0 = Throw()
    //     0x52ec30: bl              #0xd67e38  ; ThrowStub
    // 0x52ec34: brk             #0
    // 0x52ec38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52ec38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52ec3c: b               #0x52ea6c
  }
  _ _completeNow(/* No info */) {
    // ** addr: 0x52ed78, size: 0x24
    // 0x52ed78: ldr             x1, [SP]
    // 0x52ed7c: LoadField: r0 = r1->field_b
    //     0x52ed7c: ldur            w0, [x1, #0xb]
    // 0x52ed80: DecompressPointer r0
    //     0x52ed80: add             x0, x0, HEAP, lsl #32
    // 0x52ed84: cmp             w0, NULL
    // 0x52ed88: b.ne            #0x52ed94
    // 0x52ed8c: r0 = Null
    //     0x52ed8c: mov             x0, NULL
    // 0x52ed90: ret
    //     0x52ed90: ret             
    // 0x52ed94: StoreField: r1->field_f = rNULL
    //     0x52ed94: stur            NULL, [x1, #0xf]
    // 0x52ed98: ret
    //     0x52ed98: ret             
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x52ed9c, size: 0x70
    // 0x52ed9c: EnterFrame
    //     0x52ed9c: stp             fp, lr, [SP, #-0x10]!
    //     0x52eda0: mov             fp, SP
    // 0x52eda4: ldr             x0, [fp, #0x20]
    // 0x52eda8: LoadField: r1 = r0->field_17
    //     0x52eda8: ldur            w1, [x0, #0x17]
    // 0x52edac: DecompressPointer r1
    //     0x52edac: add             x1, x1, HEAP, lsl #32
    // 0x52edb0: CheckStackOverflow
    //     0x52edb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52edb4: cmp             SP, x16
    //     0x52edb8: b.ls            #0x52ee04
    // 0x52edbc: LoadField: r0 = r1->field_f
    //     0x52edbc: ldur            w0, [x1, #0xf]
    // 0x52edc0: DecompressPointer r0
    //     0x52edc0: add             x0, x0, HEAP, lsl #32
    // 0x52edc4: SaveReg r0
    //     0x52edc4: str             x0, [SP, #-8]!
    // 0x52edc8: r0 = _completeNow()
    //     0x52edc8: bl              #0x52ed78  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::_completeNow
    // 0x52edcc: add             SP, SP, #8
    // 0x52edd0: cmp             w0, NULL
    // 0x52edd4: b.eq            #0x52edf4
    // 0x52edd8: ldr             x16, [fp, #0x18]
    // 0x52eddc: stp             x16, x0, [SP, #-0x10]!
    // 0x52ede0: ldr             x16, [fp, #0x10]
    // 0x52ede4: SaveReg r16
    //     0x52ede4: str             x16, [SP, #-8]!
    // 0x52ede8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x52ede8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x52edec: r0 = completeError()
    //     0x52edec: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0x52edf0: add             SP, SP, #0x18
    // 0x52edf4: r0 = Null
    //     0x52edf4: mov             x0, NULL
    // 0x52edf8: LeaveFrame
    //     0x52edf8: mov             SP, fp
    //     0x52edfc: ldp             fp, lr, [SP], #0x10
    // 0x52ee00: ret
    //     0x52ee00: ret             
    // 0x52ee04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52ee04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52ee08: b               #0x52edbc
  }
  [closure] Null <anonymous closure>(dynamic, X0) {
    // ** addr: 0x52ee0c, size: 0x68
    // 0x52ee0c: EnterFrame
    //     0x52ee0c: stp             fp, lr, [SP, #-0x10]!
    //     0x52ee10: mov             fp, SP
    // 0x52ee14: ldr             x0, [fp, #0x18]
    // 0x52ee18: LoadField: r1 = r0->field_17
    //     0x52ee18: ldur            w1, [x0, #0x17]
    // 0x52ee1c: DecompressPointer r1
    //     0x52ee1c: add             x1, x1, HEAP, lsl #32
    // 0x52ee20: CheckStackOverflow
    //     0x52ee20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52ee24: cmp             SP, x16
    //     0x52ee28: b.ls            #0x52ee6c
    // 0x52ee2c: LoadField: r0 = r1->field_f
    //     0x52ee2c: ldur            w0, [x1, #0xf]
    // 0x52ee30: DecompressPointer r0
    //     0x52ee30: add             x0, x0, HEAP, lsl #32
    // 0x52ee34: SaveReg r0
    //     0x52ee34: str             x0, [SP, #-8]!
    // 0x52ee38: r0 = _completeNow()
    //     0x52ee38: bl              #0x52ed78  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::_completeNow
    // 0x52ee3c: add             SP, SP, #8
    // 0x52ee40: cmp             w0, NULL
    // 0x52ee44: b.eq            #0x52ee5c
    // 0x52ee48: ldr             x16, [fp, #0x10]
    // 0x52ee4c: stp             x16, x0, [SP, #-0x10]!
    // 0x52ee50: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x52ee50: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x52ee54: r0 = complete()
    //     0x52ee54: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x52ee58: add             SP, SP, #0x10
    // 0x52ee5c: r0 = Null
    //     0x52ee5c: mov             x0, NULL
    // 0x52ee60: LeaveFrame
    //     0x52ee60: mov             SP, fp
    //     0x52ee64: ldp             fp, lr, [SP], #0x10
    // 0x52ee68: ret
    //     0x52ee68: ret             
    // 0x52ee6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52ee6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52ee70: b               #0x52ee2c
  }
  _ CancelableCompleter(/* No info */) {
    // ** addr: 0x52ee74, size: 0x11c
    // 0x52ee74: EnterFrame
    //     0x52ee74: stp             fp, lr, [SP, #-0x10]!
    //     0x52ee78: mov             fp, SP
    // 0x52ee7c: AllocStack(0x18)
    //     0x52ee7c: sub             SP, SP, #0x18
    // 0x52ee80: r1 = true
    //     0x52ee80: add             x1, NULL, #0x20  ; true
    // 0x52ee84: r0 = Sentinel
    //     0x52ee84: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52ee88: CheckStackOverflow
    //     0x52ee88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52ee8c: cmp             SP, x16
    //     0x52ee90: b.ls            #0x52ef88
    // 0x52ee94: ldr             x2, [fp, #0x10]
    // 0x52ee98: StoreField: r2->field_17 = r1
    //     0x52ee98: stur            w1, [x2, #0x17]
    // 0x52ee9c: StoreField: r2->field_1b = r0
    //     0x52ee9c: stur            w0, [x2, #0x1b]
    // 0x52eea0: LoadField: r0 = r2->field_7
    //     0x52eea0: ldur            w0, [x2, #7]
    // 0x52eea4: DecompressPointer r0
    //     0x52eea4: add             x0, x0, HEAP, lsl #32
    // 0x52eea8: mov             x1, x0
    // 0x52eeac: stur            x0, [fp, #-8]
    // 0x52eeb0: r0 = _Future()
    //     0x52eeb0: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x52eeb4: mov             x1, x0
    // 0x52eeb8: r0 = 0
    //     0x52eeb8: mov             x0, #0
    // 0x52eebc: stur            x1, [fp, #-0x10]
    // 0x52eec0: StoreField: r1->field_b = r0
    //     0x52eec0: stur            x0, [x1, #0xb]
    // 0x52eec4: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x52eec4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x52eec8: ldr             x0, [x0, #0xb58]
    //     0x52eecc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x52eed0: cmp             w0, w16
    //     0x52eed4: b.ne            #0x52eee0
    //     0x52eed8: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x52eedc: bl              #0xd67d44
    // 0x52eee0: mov             x2, x0
    // 0x52eee4: ldur            x0, [fp, #-0x10]
    // 0x52eee8: stur            x2, [fp, #-0x18]
    // 0x52eeec: StoreField: r0->field_13 = r2
    //     0x52eeec: stur            w2, [x0, #0x13]
    // 0x52eef0: ldur            x1, [fp, #-8]
    // 0x52eef4: r0 = _AsyncCompleter()
    //     0x52eef4: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x52eef8: mov             x1, x0
    // 0x52eefc: ldur            x0, [fp, #-0x10]
    // 0x52ef00: StoreField: r1->field_b = r0
    //     0x52ef00: stur            w0, [x1, #0xb]
    // 0x52ef04: mov             x0, x1
    // 0x52ef08: ldr             x2, [fp, #0x10]
    // 0x52ef0c: StoreField: r2->field_b = r0
    //     0x52ef0c: stur            w0, [x2, #0xb]
    //     0x52ef10: ldurb           w16, [x2, #-1]
    //     0x52ef14: ldurb           w17, [x0, #-1]
    //     0x52ef18: and             x16, x17, x16, lsr #2
    //     0x52ef1c: tst             x16, HEAP, lsr #32
    //     0x52ef20: b.eq            #0x52ef28
    //     0x52ef24: bl              #0xd6828c
    // 0x52ef28: r1 = <void?>
    //     0x52ef28: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x52ef2c: r0 = _Future()
    //     0x52ef2c: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x52ef30: mov             x2, x0
    // 0x52ef34: r0 = 0
    //     0x52ef34: mov             x0, #0
    // 0x52ef38: stur            x2, [fp, #-8]
    // 0x52ef3c: StoreField: r2->field_b = r0
    //     0x52ef3c: stur            x0, [x2, #0xb]
    // 0x52ef40: ldur            x0, [fp, #-0x18]
    // 0x52ef44: StoreField: r2->field_13 = r0
    //     0x52ef44: stur            w0, [x2, #0x13]
    // 0x52ef48: r1 = <void?>
    //     0x52ef48: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x52ef4c: r0 = _AsyncCompleter()
    //     0x52ef4c: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x52ef50: ldur            x1, [fp, #-8]
    // 0x52ef54: StoreField: r0->field_b = r1
    //     0x52ef54: stur            w1, [x0, #0xb]
    // 0x52ef58: ldr             x1, [fp, #0x10]
    // 0x52ef5c: StoreField: r1->field_f = r0
    //     0x52ef5c: stur            w0, [x1, #0xf]
    //     0x52ef60: ldurb           w16, [x1, #-1]
    //     0x52ef64: ldurb           w17, [x0, #-1]
    //     0x52ef68: and             x16, x17, x16, lsr #2
    //     0x52ef6c: tst             x16, HEAP, lsr #32
    //     0x52ef70: b.eq            #0x52ef78
    //     0x52ef74: bl              #0xd6826c
    // 0x52ef78: r0 = Null
    //     0x52ef78: mov             x0, NULL
    // 0x52ef7c: LeaveFrame
    //     0x52ef7c: mov             SP, fp
    //     0x52ef80: ldp             fp, lr, [SP], #0x10
    // 0x52ef84: ret
    //     0x52ef84: ret             
    // 0x52ef88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52ef88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52ef8c: b               #0x52ee94
  }
  CancelableOperation<X0> operation(CancelableCompleter<X0>) {
    // ** addr: 0x52ef9c, size: 0x2c
    // 0x52ef9c: EnterFrame
    //     0x52ef9c: stp             fp, lr, [SP, #-0x10]!
    //     0x52efa0: mov             fp, SP
    // 0x52efa4: ldr             x0, [fp, #0x10]
    // 0x52efa8: LoadField: r1 = r0->field_7
    //     0x52efa8: ldur            w1, [x0, #7]
    // 0x52efac: DecompressPointer r1
    //     0x52efac: add             x1, x1, HEAP, lsl #32
    // 0x52efb0: r0 = CancelableOperation()
    //     0x52efb0: bl              #0x52efc8  ; AllocateCancelableOperationStub -> CancelableOperation<X0> (size=0x10)
    // 0x52efb4: ldr             x1, [fp, #0x10]
    // 0x52efb8: StoreField: r0->field_b = r1
    //     0x52efb8: stur            w1, [x0, #0xb]
    // 0x52efbc: LeaveFrame
    //     0x52efbc: mov             SP, fp
    //     0x52efc0: ldp             fp, lr, [SP], #0x10
    // 0x52efc4: ret
    //     0x52efc4: ret             
  }
  _ _cancel(/* No info */) {
    // ** addr: 0x557220, size: 0xd0
    // 0x557220: EnterFrame
    //     0x557220: stp             fp, lr, [SP, #-0x10]!
    //     0x557224: mov             fp, SP
    // 0x557228: AllocStack(0x10)
    //     0x557228: sub             SP, SP, #0x10
    // 0x55722c: CheckStackOverflow
    //     0x55722c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x557230: cmp             SP, x16
    //     0x557234: b.ls            #0x5572e8
    // 0x557238: ldr             x0, [fp, #0x10]
    // 0x55723c: LoadField: r1 = r0->field_f
    //     0x55723c: ldur            w1, [x0, #0xf]
    // 0x557240: DecompressPointer r1
    //     0x557240: add             x1, x1, HEAP, lsl #32
    // 0x557244: stur            x1, [fp, #-0x10]
    // 0x557248: cmp             w1, NULL
    // 0x55724c: b.ne            #0x5572ac
    // 0x557250: r1 = <void?>
    //     0x557250: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x557254: r0 = _Future()
    //     0x557254: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x557258: mov             x1, x0
    // 0x55725c: r0 = 0
    //     0x55725c: mov             x0, #0
    // 0x557260: stur            x1, [fp, #-8]
    // 0x557264: StoreField: r1->field_b = r0
    //     0x557264: stur            x0, [x1, #0xb]
    // 0x557268: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x557268: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x55726c: ldr             x0, [x0, #0xb58]
    //     0x557270: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x557274: cmp             w0, w16
    //     0x557278: b.ne            #0x557284
    //     0x55727c: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x557280: bl              #0xd67d44
    // 0x557284: mov             x1, x0
    // 0x557288: ldur            x0, [fp, #-8]
    // 0x55728c: StoreField: r0->field_13 = r1
    //     0x55728c: stur            w1, [x0, #0x13]
    // 0x557290: stp             NULL, x0, [SP, #-0x10]!
    // 0x557294: r0 = _asyncComplete()
    //     0x557294: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x557298: add             SP, SP, #0x10
    // 0x55729c: ldur            x0, [fp, #-8]
    // 0x5572a0: LeaveFrame
    //     0x5572a0: mov             SP, fp
    //     0x5572a4: ldp             fp, lr, [SP], #0x10
    // 0x5572a8: ret
    //     0x5572a8: ret             
    // 0x5572ac: LoadField: r2 = r0->field_b
    //     0x5572ac: ldur            w2, [x0, #0xb]
    // 0x5572b0: DecompressPointer r2
    //     0x5572b0: add             x2, x2, HEAP, lsl #32
    // 0x5572b4: cmp             w2, NULL
    // 0x5572b8: b.eq            #0x5572d0
    // 0x5572bc: StoreField: r0->field_b = rNULL
    //     0x5572bc: stur            NULL, [x0, #0xb]
    // 0x5572c0: stp             NULL, x1, [SP, #-0x10]!
    // 0x5572c4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x5572c4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x5572c8: r0 = complete()
    //     0x5572c8: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x5572cc: add             SP, SP, #0x10
    // 0x5572d0: ldur            x1, [fp, #-0x10]
    // 0x5572d4: LoadField: r0 = r1->field_b
    //     0x5572d4: ldur            w0, [x1, #0xb]
    // 0x5572d8: DecompressPointer r0
    //     0x5572d8: add             x0, x0, HEAP, lsl #32
    // 0x5572dc: LeaveFrame
    //     0x5572dc: mov             SP, fp
    //     0x5572e0: ldp             fp, lr, [SP], #0x10
    // 0x5572e4: ret
    //     0x5572e4: ret             
    // 0x5572e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5572e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5572ec: b               #0x557238
  }
}

// class id: 4985, size: 0x10, field offset: 0x8
class CancelableOperation<X0> extends Object {

  get _ value(/* No info */) {
    // ** addr: 0x52e92c, size: 0xac
    // 0x52e92c: EnterFrame
    //     0x52e92c: stp             fp, lr, [SP, #-0x10]!
    //     0x52e930: mov             fp, SP
    // 0x52e934: AllocStack(0x8)
    //     0x52e934: sub             SP, SP, #8
    // 0x52e938: CheckStackOverflow
    //     0x52e938: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52e93c: cmp             SP, x16
    //     0x52e940: b.ls            #0x52e9d0
    // 0x52e944: ldr             x0, [fp, #0x10]
    // 0x52e948: LoadField: r1 = r0->field_b
    //     0x52e948: ldur            w1, [x0, #0xb]
    // 0x52e94c: DecompressPointer r1
    //     0x52e94c: add             x1, x1, HEAP, lsl #32
    // 0x52e950: LoadField: r2 = r1->field_b
    //     0x52e950: ldur            w2, [x1, #0xb]
    // 0x52e954: DecompressPointer r2
    //     0x52e954: add             x2, x2, HEAP, lsl #32
    // 0x52e958: cmp             w2, NULL
    // 0x52e95c: b.ne            #0x52e968
    // 0x52e960: r1 = Null
    //     0x52e960: mov             x1, NULL
    // 0x52e964: b               #0x52e970
    // 0x52e968: LoadField: r1 = r2->field_b
    //     0x52e968: ldur            w1, [x2, #0xb]
    // 0x52e96c: DecompressPointer r1
    //     0x52e96c: add             x1, x1, HEAP, lsl #32
    // 0x52e970: cmp             w1, NULL
    // 0x52e974: b.ne            #0x52e9c0
    // 0x52e978: LoadField: r1 = r0->field_7
    //     0x52e978: ldur            w1, [x0, #7]
    // 0x52e97c: DecompressPointer r1
    //     0x52e97c: add             x1, x1, HEAP, lsl #32
    // 0x52e980: r0 = _Future()
    //     0x52e980: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x52e984: mov             x1, x0
    // 0x52e988: r0 = 0
    //     0x52e988: mov             x0, #0
    // 0x52e98c: stur            x1, [fp, #-8]
    // 0x52e990: StoreField: r1->field_b = r0
    //     0x52e990: stur            x0, [x1, #0xb]
    // 0x52e994: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x52e994: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x52e998: ldr             x0, [x0, #0xb58]
    //     0x52e99c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x52e9a0: cmp             w0, w16
    //     0x52e9a4: b.ne            #0x52e9b0
    //     0x52e9a8: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x52e9ac: bl              #0xd67d44
    // 0x52e9b0: ldur            x2, [fp, #-8]
    // 0x52e9b4: StoreField: r2->field_13 = r0
    //     0x52e9b4: stur            w0, [x2, #0x13]
    // 0x52e9b8: mov             x0, x2
    // 0x52e9bc: b               #0x52e9c4
    // 0x52e9c0: mov             x0, x1
    // 0x52e9c4: LeaveFrame
    //     0x52e9c4: mov             SP, fp
    //     0x52e9c8: ldp             fp, lr, [SP], #0x10
    // 0x52e9cc: ret
    //     0x52e9cc: ret             
    // 0x52e9d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52e9d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52e9d4: b               #0x52e944
  }
  factory _ CancelableOperation.fromFuture(/* No info */) {
    // ** addr: 0x52e9d8, size: 0x7c
    // 0x52e9d8: EnterFrame
    //     0x52e9d8: stp             fp, lr, [SP, #-0x10]!
    //     0x52e9dc: mov             fp, SP
    // 0x52e9e0: AllocStack(0x8)
    //     0x52e9e0: sub             SP, SP, #8
    // 0x52e9e4: CheckStackOverflow
    //     0x52e9e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52e9e8: cmp             SP, x16
    //     0x52e9ec: b.ls            #0x52ea4c
    // 0x52e9f0: ldr             x1, [fp, #0x18]
    // 0x52e9f4: r0 = CancelableCompleter()
    //     0x52e9f4: bl              #0x52ef90  ; AllocateCancelableCompleterStub -> CancelableCompleter<X0> (size=0x20)
    // 0x52e9f8: stur            x0, [fp, #-8]
    // 0x52e9fc: SaveReg r0
    //     0x52e9fc: str             x0, [SP, #-8]!
    // 0x52ea00: r0 = CancelableCompleter()
    //     0x52ea00: bl              #0x52ee74  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::CancelableCompleter
    // 0x52ea04: add             SP, SP, #8
    // 0x52ea08: ldur            x16, [fp, #-8]
    // 0x52ea0c: ldr             lr, [fp, #0x10]
    // 0x52ea10: stp             lr, x16, [SP, #-0x10]!
    // 0x52ea14: r0 = complete()
    //     0x52ea14: bl              #0x52ea54  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::complete
    // 0x52ea18: add             SP, SP, #0x10
    // 0x52ea1c: ldur            x1, [fp, #-8]
    // 0x52ea20: LoadField: r0 = r1->field_1b
    //     0x52ea20: ldur            w0, [x1, #0x1b]
    // 0x52ea24: DecompressPointer r0
    //     0x52ea24: add             x0, x0, HEAP, lsl #32
    // 0x52ea28: r16 = Sentinel
    //     0x52ea28: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52ea2c: cmp             w0, w16
    // 0x52ea30: b.ne            #0x52ea40
    // 0x52ea34: r2 = operation
    //     0x52ea34: add             x2, PP, #0x13, lsl #12  ; [pp+0x13380] Field <CancelableCompleter.operation>: late final (offset: 0x1c)
    //     0x52ea38: ldr             x2, [x2, #0x380]
    // 0x52ea3c: r0 = InitLateFinalInstanceField()
    //     0x52ea3c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x52ea40: LeaveFrame
    //     0x52ea40: mov             SP, fp
    //     0x52ea44: ldp             fp, lr, [SP], #0x10
    // 0x52ea48: ret
    //     0x52ea48: ret             
    // 0x52ea4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52ea4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52ea50: b               #0x52e9f0
  }
  _ cancel(/* No info */) {
    // ** addr: 0x5571e0, size: 0x40
    // 0x5571e0: EnterFrame
    //     0x5571e0: stp             fp, lr, [SP, #-0x10]!
    //     0x5571e4: mov             fp, SP
    // 0x5571e8: CheckStackOverflow
    //     0x5571e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5571ec: cmp             SP, x16
    //     0x5571f0: b.ls            #0x557218
    // 0x5571f4: ldr             x0, [fp, #0x10]
    // 0x5571f8: LoadField: r1 = r0->field_b
    //     0x5571f8: ldur            w1, [x0, #0xb]
    // 0x5571fc: DecompressPointer r1
    //     0x5571fc: add             x1, x1, HEAP, lsl #32
    // 0x557200: SaveReg r1
    //     0x557200: str             x1, [SP, #-8]!
    // 0x557204: r0 = _cancel()
    //     0x557204: bl              #0x557220  ; [package:async/src/cancelable_operation.dart] CancelableCompleter::_cancel
    // 0x557208: add             SP, SP, #8
    // 0x55720c: LeaveFrame
    //     0x55720c: mov             SP, fp
    //     0x557210: ldp             fp, lr, [SP], #0x10
    // 0x557214: ret
    //     0x557214: ret             
    // 0x557218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x557218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55721c: b               #0x5571f4
  }
}

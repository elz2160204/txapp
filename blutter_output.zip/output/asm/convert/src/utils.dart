// lib: convert.utils, url: package:convert/src/utils.dart

// class id: 1048806, size: 0x8
class :: {

  static _ digitForCodeUnit(/* No info */) {
    // ** addr: 0xc207ec, size: 0x180
    // 0xc207ec: EnterFrame
    //     0xc207ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc207f0: mov             fp, SP
    // 0xc207f4: AllocStack(0x18)
    //     0xc207f4: sub             SP, SP, #0x18
    // 0xc207f8: CheckStackOverflow
    //     0xc207f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc207fc: cmp             SP, x16
    //     0xc20800: b.ls            #0xc20964
    // 0xc20804: ldr             x2, [fp, #0x18]
    // 0xc20808: LoadField: r3 = r2->field_b
    //     0xc20808: ldur            w3, [x2, #0xb]
    // 0xc2080c: DecompressPointer r3
    //     0xc2080c: add             x3, x3, HEAP, lsl #32
    // 0xc20810: ldr             x4, [fp, #0x10]
    // 0xc20814: r0 = BoxInt64Instr(r4)
    //     0xc20814: sbfiz           x0, x4, #1, #0x1f
    //     0xc20818: cmp             x4, x0, asr #1
    //     0xc2081c: b.eq            #0xc20828
    //     0xc20820: bl              #0xd69bb8
    //     0xc20824: stur            x4, [x0, #7]
    // 0xc20828: mov             x1, x0
    // 0xc2082c: stur            x1, [fp, #-8]
    // 0xc20830: r0 = LoadClassIdInstr(r3)
    //     0xc20830: ldur            x0, [x3, #-1]
    //     0xc20834: ubfx            x0, x0, #0xc, #0x14
    // 0xc20838: stp             x1, x3, [SP, #-0x10]!
    // 0xc2083c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xc2083c: sub             lr, x0, #1, lsl #12
    //     0xc20840: ldr             lr, [x21, lr, lsl #3]
    //     0xc20844: blr             lr
    // 0xc20848: add             SP, SP, #0x10
    // 0xc2084c: stur            x0, [fp, #-0x10]
    // 0xc20850: r1 = LoadInt32Instr(r0)
    //     0xc20850: sbfx            x1, x0, #1, #0x1f
    // 0xc20854: eor             x2, x1, #0x30
    // 0xc20858: cmp             x2, #9
    // 0xc2085c: b.gt            #0xc20874
    // 0xc20860: tbnz            x2, #0x3f, #0xc208a0
    // 0xc20864: mov             x0, x2
    // 0xc20868: LeaveFrame
    //     0xc20868: mov             SP, fp
    //     0xc2086c: ldp             fp, lr, [SP], #0x10
    // 0xc20870: ret
    //     0xc20870: ret             
    // 0xc20874: orr             x2, x1, #0x20
    // 0xc20878: cmp             x2, #0x61
    // 0xc2087c: b.lt            #0xc208a0
    // 0xc20880: cmp             x2, #0x66
    // 0xc20884: b.gt            #0xc208a0
    // 0xc20888: sub             x0, x2, #0x61
    // 0xc2088c: add             x1, x0, #0xa
    // 0xc20890: mov             x0, x1
    // 0xc20894: LeaveFrame
    //     0xc20894: mov             SP, fp
    //     0xc20898: ldp             fp, lr, [SP], #0x10
    // 0xc2089c: ret
    //     0xc2089c: ret             
    // 0xc208a0: ldr             x3, [fp, #0x18]
    // 0xc208a4: ldur            x4, [fp, #-8]
    // 0xc208a8: r1 = Null
    //     0xc208a8: mov             x1, NULL
    // 0xc208ac: r2 = 6
    //     0xc208ac: mov             x2, #6
    // 0xc208b0: r0 = AllocateArray()
    //     0xc208b0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc208b4: stur            x0, [fp, #-0x18]
    // 0xc208b8: r17 = "Invalid hexadecimal code unit U+"
    //     0xc208b8: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d6e0] "Invalid hexadecimal code unit U+"
    //     0xc208bc: ldr             x17, [x17, #0x6e0]
    // 0xc208c0: StoreField: r0->field_f = r17
    //     0xc208c0: stur            w17, [x0, #0xf]
    // 0xc208c4: ldur            x16, [fp, #-0x10]
    // 0xc208c8: SaveReg r16
    //     0xc208c8: str             x16, [SP, #-8]!
    // 0xc208cc: r1 = 16
    //     0xc208cc: mov             x1, #0x10
    // 0xc208d0: SaveReg r1
    //     0xc208d0: str             x1, [SP, #-8]!
    // 0xc208d4: r0 = _toPow2String()
    //     0xc208d4: bl              #0x506b60  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0xc208d8: add             SP, SP, #0x10
    // 0xc208dc: SaveReg r0
    //     0xc208dc: str             x0, [SP, #-8]!
    // 0xc208e0: r0 = 4
    //     0xc208e0: mov             x0, #4
    // 0xc208e4: r16 = "0"
    //     0xc208e4: ldr             x16, [PP, #0x3af8]  ; [pp+0x3af8] "0"
    // 0xc208e8: stp             x16, x0, [SP, #-0x10]!
    // 0xc208ec: r0 = padLeft()
    //     0xc208ec: bl              #0xd65600  ; [dart:core] _OneByteString::padLeft
    // 0xc208f0: add             SP, SP, #0x18
    // 0xc208f4: ldur            x1, [fp, #-0x18]
    // 0xc208f8: ArrayStore: r1[1] = r0  ; List_4
    //     0xc208f8: add             x25, x1, #0x13
    //     0xc208fc: str             w0, [x25]
    //     0xc20900: tbz             w0, #0, #0xc2091c
    //     0xc20904: ldurb           w16, [x1, #-1]
    //     0xc20908: ldurb           w17, [x0, #-1]
    //     0xc2090c: and             x16, x17, x16, lsr #2
    //     0xc20910: tst             x16, HEAP, lsr #32
    //     0xc20914: b.eq            #0xc2091c
    //     0xc20918: bl              #0xd67e5c
    // 0xc2091c: ldur            x0, [fp, #-0x18]
    // 0xc20920: r17 = "."
    //     0xc20920: ldr             x17, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xc20924: StoreField: r0->field_17 = r17
    //     0xc20924: stur            w17, [x0, #0x17]
    // 0xc20928: SaveReg r0
    //     0xc20928: str             x0, [SP, #-8]!
    // 0xc2092c: r0 = _interpolate()
    //     0xc2092c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc20930: add             SP, SP, #8
    // 0xc20934: stur            x0, [fp, #-0x10]
    // 0xc20938: r0 = FormatException()
    //     0xc20938: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xc2093c: mov             x1, x0
    // 0xc20940: ldur            x0, [fp, #-0x10]
    // 0xc20944: StoreField: r1->field_7 = r0
    //     0xc20944: stur            w0, [x1, #7]
    // 0xc20948: ldr             x0, [fp, #0x18]
    // 0xc2094c: StoreField: r1->field_b = r0
    //     0xc2094c: stur            w0, [x1, #0xb]
    // 0xc20950: ldur            x0, [fp, #-8]
    // 0xc20954: StoreField: r1->field_f = r0
    //     0xc20954: stur            w0, [x1, #0xf]
    // 0xc20958: mov             x0, x1
    // 0xc2095c: r0 = Throw()
    //     0xc2095c: bl              #0xd67e38  ; ThrowStub
    // 0xc20960: brk             #0
    // 0xc20964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20964: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20968: b               #0xc20804
  }
}

// lib: convert.hex, url: package:convert/src/hex.dart

// class id: 1048798, size: 0x8
class :: {
}

// class id: 5410, size: 0xc, field offset: 0xc
//   const constructor, 
class HexCodec extends Codec<List<int>, String> {

  get _ decoder(/* No info */) {
    // ** addr: 0xbfdcb4, size: 0xc
    // 0xbfdcb4: r0 = Instance_HexDecoder
    //     0xbfdcb4: add             x0, PP, #0x15, lsl #12  ; [pp+0x154a0] Obj!HexDecoder<String, List<int>>@b5f751
    //     0xbfdcb8: ldr             x0, [x0, #0x4a0]
    // 0xbfdcbc: ret
    //     0xbfdcbc: ret             
  }
  get _ encoder(/* No info */) {
    // ** addr: 0xbfe0c8, size: 0xc
    // 0xbfe0c8: r0 = Instance_HexEncoder
    //     0xbfe0c8: add             x0, PP, #0x15, lsl #12  ; [pp+0x154a8] Obj!HexEncoder<List<int>, String>@b5f741
    //     0xbfe0cc: ldr             x0, [x0, #0x4a8]
    // 0xbfe0d0: ret
    //     0xbfe0d0: ret             
  }
}

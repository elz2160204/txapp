// lib: convert.hex.encoder, url: package:convert/src/hex/encoder.dart

// class id: 1048800, size: 0x8
class :: {

  static _ _convert(/* No info */) {
    // ** addr: 0xc209b0, size: 0x370
    // 0xc209b0: EnterFrame
    //     0xc209b0: stp             fp, lr, [SP, #-0x10]!
    //     0xc209b4: mov             fp, SP
    // 0xc209b8: AllocStack(0x30)
    //     0xc209b8: sub             SP, SP, #0x30
    // 0xc209bc: CheckStackOverflow
    //     0xc209bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc209c0: cmp             SP, x16
    //     0xc209c4: b.ls            #0xc20d00
    // 0xc209c8: ldr             x2, [fp, #0x10]
    // 0xc209cc: lsl             x3, x2, #1
    // 0xc209d0: stur            x3, [fp, #-8]
    // 0xc209d4: r0 = BoxInt64Instr(r3)
    //     0xc209d4: sbfiz           x0, x3, #1, #0x1f
    //     0xc209d8: cmp             x3, x0, asr #1
    //     0xc209dc: b.eq            #0xc209e8
    //     0xc209e0: bl              #0xd69bb8
    //     0xc209e4: stur            x3, [x0, #7]
    // 0xc209e8: mov             x4, x0
    // 0xc209ec: r0 = AllocateUint8Array()
    //     0xc209ec: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xc209f0: mov             x2, x0
    // 0xc209f4: stur            x2, [fp, #-0x28]
    // 0xc209f8: r7 = 0
    //     0xc209f8: mov             x7, #0
    // 0xc209fc: r6 = 0
    //     0xc209fc: mov             x6, #0
    // 0xc20a00: r5 = 0
    //     0xc20a00: mov             x5, #0
    // 0xc20a04: ldr             x4, [fp, #0x18]
    // 0xc20a08: ldr             x3, [fp, #0x10]
    // 0xc20a0c: stur            x7, [fp, #-0x10]
    // 0xc20a10: stur            x6, [fp, #-0x18]
    // 0xc20a14: stur            x5, [fp, #-0x20]
    // 0xc20a18: CheckStackOverflow
    //     0xc20a18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc20a1c: cmp             SP, x16
    //     0xc20a20: b.ls            #0xc20d08
    // 0xc20a24: cmp             x5, x3
    // 0xc20a28: b.ge            #0xc20b30
    // 0xc20a2c: r0 = BoxInt64Instr(r5)
    //     0xc20a2c: sbfiz           x0, x5, #1, #0x1f
    //     0xc20a30: cmp             x5, x0, asr #1
    //     0xc20a34: b.eq            #0xc20a40
    //     0xc20a38: bl              #0xd69bb8
    //     0xc20a3c: stur            x5, [x0, #7]
    // 0xc20a40: r1 = LoadClassIdInstr(r4)
    //     0xc20a40: ldur            x1, [x4, #-1]
    //     0xc20a44: ubfx            x1, x1, #0xc, #0x14
    // 0xc20a48: stp             x0, x4, [SP, #-0x10]!
    // 0xc20a4c: mov             x0, x1
    // 0xc20a50: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc20a50: sub             lr, x0, #0xd83
    //     0xc20a54: ldr             lr, [x21, lr, lsl #3]
    //     0xc20a58: blr             lr
    // 0xc20a5c: add             SP, SP, #0x10
    // 0xc20a60: r2 = LoadInt32Instr(r0)
    //     0xc20a60: sbfx            x2, x0, #1, #0x1f
    // 0xc20a64: ldur            x0, [fp, #-0x18]
    // 0xc20a68: orr             x6, x0, x2
    // 0xc20a6c: ldur            x3, [fp, #-0x10]
    // 0xc20a70: add             x4, x3, #1
    // 0xc20a74: mov             x0, x2
    // 0xc20a78: ubfx            x0, x0, #0, #0x20
    // 0xc20a7c: r8 = 240
    //     0xc20a7c: mov             x8, #0xf0
    // 0xc20a80: and             x1, x0, x8
    // 0xc20a84: ubfx            x1, x1, #0, #0x20
    // 0xc20a88: asr             x0, x1, #4
    // 0xc20a8c: cmp             x0, #0xa
    // 0xc20a90: b.ge            #0xc20aa0
    // 0xc20a94: add             x1, x0, #0x30
    // 0xc20a98: mov             x5, x1
    // 0xc20a9c: b               #0xc20aac
    // 0xc20aa0: add             x1, x0, #0x61
    // 0xc20aa4: sub             x0, x1, #0xa
    // 0xc20aa8: mov             x5, x0
    // 0xc20aac: ldur            x9, [fp, #-0x28]
    // 0xc20ab0: r10 = 15
    //     0xc20ab0: mov             x10, #0xf
    // 0xc20ab4: ldur            x0, [fp, #-8]
    // 0xc20ab8: mov             x1, x3
    // 0xc20abc: cmp             x1, x0
    // 0xc20ac0: b.hs            #0xc20d10
    // 0xc20ac4: ArrayStore: r9[r3] = r5  ; TypeUnknown_1
    //     0xc20ac4: add             x0, x9, x3
    //     0xc20ac8: strb            w5, [x0, #0x17]
    // 0xc20acc: add             x7, x4, #1
    // 0xc20ad0: ubfx            x2, x2, #0, #0x20
    // 0xc20ad4: and             x0, x2, x10
    // 0xc20ad8: mov             x1, x0
    // 0xc20adc: ubfx            x1, x1, #0, #0x20
    // 0xc20ae0: cmp             x1, #0xa
    // 0xc20ae4: b.ge            #0xc20af8
    // 0xc20ae8: ubfx            x0, x0, #0, #0x20
    // 0xc20aec: add             x1, x0, #0x30
    // 0xc20af0: mov             x3, x1
    // 0xc20af4: b               #0xc20b08
    // 0xc20af8: ubfx            x0, x0, #0, #0x20
    // 0xc20afc: add             x1, x0, #0x61
    // 0xc20b00: sub             x0, x1, #0xa
    // 0xc20b04: mov             x3, x0
    // 0xc20b08: ldur            x2, [fp, #-0x20]
    // 0xc20b0c: ldur            x0, [fp, #-8]
    // 0xc20b10: mov             x1, x4
    // 0xc20b14: cmp             x1, x0
    // 0xc20b18: b.hs            #0xc20d14
    // 0xc20b1c: ArrayStore: r9[r4] = r3  ; TypeUnknown_1
    //     0xc20b1c: add             x0, x9, x4
    //     0xc20b20: strb            w3, [x0, #0x17]
    // 0xc20b24: add             x5, x2, #1
    // 0xc20b28: mov             x2, x9
    // 0xc20b2c: b               #0xc20a04
    // 0xc20b30: mov             x0, x6
    // 0xc20b34: mov             x9, x2
    // 0xc20b38: tbnz            x0, #0x3f, #0xc20b60
    // 0xc20b3c: cmp             x0, #0xff
    // 0xc20b40: b.gt            #0xc20b60
    // 0xc20b44: stp             xzr, x9, [SP, #-0x10]!
    // 0xc20b48: stp             NULL, NULL, [SP, #-0x10]!
    // 0xc20b4c: r0 = createFromCharCodes()
    //     0xc20b4c: bl              #0x4d2124  ; [dart:core] _StringBase::createFromCharCodes
    // 0xc20b50: add             SP, SP, #0x20
    // 0xc20b54: LeaveFrame
    //     0xc20b54: mov             SP, fp
    //     0xc20b58: ldp             fp, lr, [SP], #0x10
    // 0xc20b5c: ret
    //     0xc20b5c: ret             
    // 0xc20b60: r4 = 0
    //     0xc20b60: mov             x4, #0
    // 0xc20b64: ldr             x3, [fp, #0x18]
    // 0xc20b68: ldr             x2, [fp, #0x10]
    // 0xc20b6c: stur            x4, [fp, #-8]
    // 0xc20b70: CheckStackOverflow
    //     0xc20b70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc20b74: cmp             SP, x16
    //     0xc20b78: b.ls            #0xc20d18
    // 0xc20b7c: cmp             x4, x2
    // 0xc20b80: b.ge            #0xc20ce0
    // 0xc20b84: r0 = BoxInt64Instr(r4)
    //     0xc20b84: sbfiz           x0, x4, #1, #0x1f
    //     0xc20b88: cmp             x4, x0, asr #1
    //     0xc20b8c: b.eq            #0xc20b98
    //     0xc20b90: bl              #0xd69bb8
    //     0xc20b94: stur            x4, [x0, #7]
    // 0xc20b98: mov             x1, x0
    // 0xc20b9c: stur            x1, [fp, #-0x28]
    // 0xc20ba0: r0 = LoadClassIdInstr(r3)
    //     0xc20ba0: ldur            x0, [x3, #-1]
    //     0xc20ba4: ubfx            x0, x0, #0xc, #0x14
    // 0xc20ba8: stp             x1, x3, [SP, #-0x10]!
    // 0xc20bac: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc20bac: sub             lr, x0, #0xd83
    //     0xc20bb0: ldr             lr, [x21, lr, lsl #3]
    //     0xc20bb4: blr             lr
    // 0xc20bb8: add             SP, SP, #0x10
    // 0xc20bbc: r3 = LoadInt32Instr(r0)
    //     0xc20bbc: sbfx            x3, x0, #1, #0x1f
    // 0xc20bc0: stur            x3, [fp, #-0x10]
    // 0xc20bc4: tbnz            x3, #0x3f, #0xc20bdc
    // 0xc20bc8: cmp             x3, #0xff
    // 0xc20bcc: b.gt            #0xc20bdc
    // 0xc20bd0: ldur            x0, [fp, #-8]
    // 0xc20bd4: add             x4, x0, #1
    // 0xc20bd8: b               #0xc20b64
    // 0xc20bdc: r1 = Null
    //     0xc20bdc: mov             x1, NULL
    // 0xc20be0: r2 = 10
    //     0xc20be0: mov             x2, #0xa
    // 0xc20be4: r0 = AllocateArray()
    //     0xc20be4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc20be8: mov             x2, x0
    // 0xc20bec: stur            x2, [fp, #-0x30]
    // 0xc20bf0: r17 = "Invalid byte "
    //     0xc20bf0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d6b8] "Invalid byte "
    //     0xc20bf4: ldr             x17, [x17, #0x6b8]
    // 0xc20bf8: StoreField: r2->field_f = r17
    //     0xc20bf8: stur            w17, [x2, #0xf]
    // 0xc20bfc: ldur            x0, [fp, #-0x10]
    // 0xc20c00: tbnz            x0, #0x3f, #0xc20c0c
    // 0xc20c04: r1 = false
    //     0xc20c04: add             x1, NULL, #0x30  ; false
    // 0xc20c08: b               #0xc20c10
    // 0xc20c0c: r1 = true
    //     0xc20c0c: add             x1, NULL, #0x20  ; true
    // 0xc20c10: tbnz            w1, #4, #0xc20c1c
    // 0xc20c14: r3 = "-"
    //     0xc20c14: ldr             x3, [PP, #0x2e68]  ; [pp+0x2e68] "-"
    // 0xc20c18: b               #0xc20c20
    // 0xc20c1c: r3 = ""
    //     0xc20c1c: ldr             x3, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xc20c20: StoreField: r2->field_13 = r3
    //     0xc20c20: stur            w3, [x2, #0x13]
    // 0xc20c24: r17 = "0x"
    //     0xc20c24: add             x17, PP, #8, lsl #12  ; [pp+0x8aa0] "0x"
    //     0xc20c28: ldr             x17, [x17, #0xaa0]
    // 0xc20c2c: StoreField: r2->field_17 = r17
    //     0xc20c2c: stur            w17, [x2, #0x17]
    // 0xc20c30: tbnz            w1, #4, #0xc20c40
    // 0xc20c34: neg             x1, x0
    // 0xc20c38: mov             x6, x1
    // 0xc20c3c: b               #0xc20c44
    // 0xc20c40: mov             x6, x0
    // 0xc20c44: ldr             x3, [fp, #0x18]
    // 0xc20c48: ldur            x4, [fp, #-0x28]
    // 0xc20c4c: r5 = 16
    //     0xc20c4c: mov             x5, #0x10
    // 0xc20c50: r0 = BoxInt64Instr(r6)
    //     0xc20c50: sbfiz           x0, x6, #1, #0x1f
    //     0xc20c54: cmp             x6, x0, asr #1
    //     0xc20c58: b.eq            #0xc20c64
    //     0xc20c5c: bl              #0xd69bb8
    //     0xc20c60: stur            x6, [x0, #7]
    // 0xc20c64: stp             x5, x0, [SP, #-0x10]!
    // 0xc20c68: r0 = _toPow2String()
    //     0xc20c68: bl              #0x506b60  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0xc20c6c: add             SP, SP, #0x10
    // 0xc20c70: ldur            x1, [fp, #-0x30]
    // 0xc20c74: ArrayStore: r1[3] = r0  ; List_4
    //     0xc20c74: add             x25, x1, #0x1b
    //     0xc20c78: str             w0, [x25]
    //     0xc20c7c: tbz             w0, #0, #0xc20c98
    //     0xc20c80: ldurb           w16, [x1, #-1]
    //     0xc20c84: ldurb           w17, [x0, #-1]
    //     0xc20c88: and             x16, x17, x16, lsr #2
    //     0xc20c8c: tst             x16, HEAP, lsr #32
    //     0xc20c90: b.eq            #0xc20c98
    //     0xc20c94: bl              #0xd67e5c
    // 0xc20c98: ldur            x0, [fp, #-0x30]
    // 0xc20c9c: r17 = "."
    //     0xc20c9c: ldr             x17, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xc20ca0: StoreField: r0->field_1f = r17
    //     0xc20ca0: stur            w17, [x0, #0x1f]
    // 0xc20ca4: SaveReg r0
    //     0xc20ca4: str             x0, [SP, #-8]!
    // 0xc20ca8: r0 = _interpolate()
    //     0xc20ca8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc20cac: add             SP, SP, #8
    // 0xc20cb0: stur            x0, [fp, #-0x30]
    // 0xc20cb4: r0 = FormatException()
    //     0xc20cb4: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xc20cb8: mov             x1, x0
    // 0xc20cbc: ldur            x0, [fp, #-0x30]
    // 0xc20cc0: StoreField: r1->field_7 = r0
    //     0xc20cc0: stur            w0, [x1, #7]
    // 0xc20cc4: ldr             x0, [fp, #0x18]
    // 0xc20cc8: StoreField: r1->field_b = r0
    //     0xc20cc8: stur            w0, [x1, #0xb]
    // 0xc20ccc: ldur            x0, [fp, #-0x28]
    // 0xc20cd0: StoreField: r1->field_f = r0
    //     0xc20cd0: stur            w0, [x1, #0xf]
    // 0xc20cd4: mov             x0, x1
    // 0xc20cd8: r0 = Throw()
    //     0xc20cd8: bl              #0xd67e38  ; ThrowStub
    // 0xc20cdc: brk             #0
    // 0xc20ce0: r0 = StateError()
    //     0xc20ce0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc20ce4: mov             x1, x0
    // 0xc20ce8: r0 = "unreachable"
    //     0xc20ce8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d6c0] "unreachable"
    //     0xc20cec: ldr             x0, [x0, #0x6c0]
    // 0xc20cf0: StoreField: r1->field_b = r0
    //     0xc20cf0: stur            w0, [x1, #0xb]
    // 0xc20cf4: mov             x0, x1
    // 0xc20cf8: r0 = Throw()
    //     0xc20cf8: bl              #0xd67e38  ; ThrowStub
    // 0xc20cfc: brk             #0
    // 0xc20d00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20d00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20d04: b               #0xc209c8
    // 0xc20d08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20d08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20d0c: b               #0xc20a24
    // 0xc20d10: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc20d10: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc20d14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc20d14: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc20d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20d18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20d1c: b               #0xc20b7c
  }
}

// class id: 5596, size: 0xc, field offset: 0xc
//   const constructor, 
class HexEncoder extends Converter<List<int>, String> {

  _ convert(/* No info */) {
    // ** addr: 0xc2096c, size: 0x44
    // 0xc2096c: EnterFrame
    //     0xc2096c: stp             fp, lr, [SP, #-0x10]!
    //     0xc20970: mov             fp, SP
    // 0xc20974: CheckStackOverflow
    //     0xc20974: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc20978: cmp             SP, x16
    //     0xc2097c: b.ls            #0xc209a8
    // 0xc20980: ldr             x0, [fp, #0x10]
    // 0xc20984: LoadField: r1 = r0->field_13
    //     0xc20984: ldur            w1, [x0, #0x13]
    // 0xc20988: DecompressPointer r1
    //     0xc20988: add             x1, x1, HEAP, lsl #32
    // 0xc2098c: r2 = LoadInt32Instr(r1)
    //     0xc2098c: sbfx            x2, x1, #1, #0x1f
    // 0xc20990: stp             x2, x0, [SP, #-0x10]!
    // 0xc20994: r0 = _convert()
    //     0xc20994: bl              #0xc209b0  ; [package:convert/src/hex/encoder.dart] ::_convert
    // 0xc20998: add             SP, SP, #0x10
    // 0xc2099c: LeaveFrame
    //     0xc2099c: mov             SP, fp
    //     0xc209a0: ldp             fp, lr, [SP], #0x10
    // 0xc209a4: ret
    //     0xc209a4: ret             
    // 0xc209a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc209a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc209ac: b               #0xc20980
  }
}

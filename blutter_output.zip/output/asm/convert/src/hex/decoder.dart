// lib: convert.hex.decoder, url: package:convert/src/hex/decoder.dart

// class id: 1048799, size: 0x8
class :: {

  static _ _decode(/* No info */) {
    // ** addr: 0xc206a0, size: 0x14c
    // 0xc206a0: EnterFrame
    //     0xc206a0: stp             fp, lr, [SP, #-0x10]!
    //     0xc206a4: mov             fp, SP
    // 0xc206a8: AllocStack(0x28)
    //     0xc206a8: sub             SP, SP, #0x28
    // 0xc206ac: CheckStackOverflow
    //     0xc206ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc206b0: cmp             SP, x16
    //     0xc206b4: b.ls            #0xc207d8
    // 0xc206b8: ldr             x0, [fp, #0x18]
    // 0xc206bc: sub             x1, x0, #1
    // 0xc206c0: ldr             x2, [fp, #0x10]
    // 0xc206c4: stur            x1, [fp, #-0x20]
    // 0xc206c8: LoadField: r3 = r2->field_13
    //     0xc206c8: ldur            w3, [x2, #0x13]
    // 0xc206cc: DecompressPointer r3
    //     0xc206cc: add             x3, x3, HEAP, lsl #32
    // 0xc206d0: r4 = LoadInt32Instr(r3)
    //     0xc206d0: sbfx            x4, x3, #1, #0x1f
    // 0xc206d4: stur            x4, [fp, #-0x18]
    // 0xc206d8: r5 = 0
    //     0xc206d8: mov             x5, #0
    // 0xc206dc: r3 = 0
    //     0xc206dc: mov             x3, #0
    // 0xc206e0: stur            x5, [fp, #-8]
    // 0xc206e4: stur            x3, [fp, #-0x10]
    // 0xc206e8: CheckStackOverflow
    //     0xc206e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc206ec: cmp             SP, x16
    //     0xc206f0: b.ls            #0xc207e0
    // 0xc206f4: cmp             x3, x1
    // 0xc206f8: b.ge            #0xc20778
    // 0xc206fc: ldr             x16, [fp, #0x20]
    // 0xc20700: stp             x3, x16, [SP, #-0x10]!
    // 0xc20704: r0 = digitForCodeUnit()
    //     0xc20704: bl              #0xc207ec  ; [package:convert/src/utils.dart] ::digitForCodeUnit
    // 0xc20708: add             SP, SP, #0x10
    // 0xc2070c: mov             x1, x0
    // 0xc20710: ldur            x0, [fp, #-0x10]
    // 0xc20714: stur            x1, [fp, #-0x28]
    // 0xc20718: add             x2, x0, #1
    // 0xc2071c: ldr             x16, [fp, #0x20]
    // 0xc20720: stp             x2, x16, [SP, #-0x10]!
    // 0xc20724: r0 = digitForCodeUnit()
    //     0xc20724: bl              #0xc207ec  ; [package:convert/src/utils.dart] ::digitForCodeUnit
    // 0xc20728: add             SP, SP, #0x10
    // 0xc2072c: ldur            x2, [fp, #-8]
    // 0xc20730: add             x5, x2, #1
    // 0xc20734: ldur            x1, [fp, #-0x28]
    // 0xc20738: lsl             x3, x1, #4
    // 0xc2073c: add             x4, x3, x0
    // 0xc20740: ldur            x0, [fp, #-0x18]
    // 0xc20744: mov             x1, x2
    // 0xc20748: cmp             x1, x0
    // 0xc2074c: b.hs            #0xc207e8
    // 0xc20750: ldr             x0, [fp, #0x10]
    // 0xc20754: LoadField: r1 = r0->field_7
    //     0xc20754: ldur            x1, [x0, #7]
    // 0xc20758: strb            w4, [x1, x2]
    // 0xc2075c: ldur            x1, [fp, #-0x10]
    // 0xc20760: add             x3, x1, #2
    // 0xc20764: mov             x2, x0
    // 0xc20768: ldr             x0, [fp, #0x18]
    // 0xc2076c: ldur            x1, [fp, #-0x20]
    // 0xc20770: ldur            x4, [fp, #-0x18]
    // 0xc20774: b               #0xc206e0
    // 0xc20778: r0 = 1
    //     0xc20778: mov             x0, #1
    // 0xc2077c: ldr             x1, [fp, #0x18]
    // 0xc20780: ubfx            x1, x1, #0, #0x20
    // 0xc20784: and             x2, x1, x0
    // 0xc20788: ubfx            x2, x2, #0, #0x20
    // 0xc2078c: cbnz            x2, #0xc207a0
    // 0xc20790: r0 = Null
    //     0xc20790: mov             x0, NULL
    // 0xc20794: LeaveFrame
    //     0xc20794: mov             SP, fp
    //     0xc20798: ldp             fp, lr, [SP], #0x10
    // 0xc2079c: ret
    //     0xc2079c: ret             
    // 0xc207a0: ldur            x0, [fp, #-0x20]
    // 0xc207a4: ldr             x16, [fp, #0x20]
    // 0xc207a8: stp             x0, x16, [SP, #-0x10]!
    // 0xc207ac: r0 = digitForCodeUnit()
    //     0xc207ac: bl              #0xc207ec  ; [package:convert/src/utils.dart] ::digitForCodeUnit
    // 0xc207b0: add             SP, SP, #0x10
    // 0xc207b4: lsl             x2, x0, #4
    // 0xc207b8: r0 = BoxInt64Instr(r2)
    //     0xc207b8: sbfiz           x0, x2, #1, #0x1f
    //     0xc207bc: cmp             x2, x0, asr #1
    //     0xc207c0: b.eq            #0xc207cc
    //     0xc207c4: bl              #0xd69bb8
    //     0xc207c8: stur            x2, [x0, #7]
    // 0xc207cc: LeaveFrame
    //     0xc207cc: mov             SP, fp
    //     0xc207d0: ldp             fp, lr, [SP], #0x10
    // 0xc207d4: ret
    //     0xc207d4: ret             
    // 0xc207d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc207d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc207dc: b               #0xc206b8
    // 0xc207e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc207e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc207e4: b               #0xc206f4
    // 0xc207e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc207e8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 5597, size: 0xc, field offset: 0xc
//   const constructor, 
class HexDecoder extends Converter<String, List<int>> {

  _ convert(/* No info */) {
    // ** addr: 0xc2058c, size: 0x114
    // 0xc2058c: EnterFrame
    //     0xc2058c: stp             fp, lr, [SP, #-0x10]!
    //     0xc20590: mov             fp, SP
    // 0xc20594: AllocStack(0x18)
    //     0xc20594: sub             SP, SP, #0x18
    // 0xc20598: CheckStackOverflow
    //     0xc20598: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2059c: cmp             SP, x16
    //     0xc205a0: b.ls            #0xc20698
    // 0xc205a4: ldr             x0, [fp, #0x10]
    // 0xc205a8: r2 = Null
    //     0xc205a8: mov             x2, NULL
    // 0xc205ac: r1 = Null
    //     0xc205ac: mov             x1, NULL
    // 0xc205b0: r4 = 59
    //     0xc205b0: mov             x4, #0x3b
    // 0xc205b4: branchIfSmi(r0, 0xc205c0)
    //     0xc205b4: tbz             w0, #0, #0xc205c0
    // 0xc205b8: r4 = LoadClassIdInstr(r0)
    //     0xc205b8: ldur            x4, [x0, #-1]
    //     0xc205bc: ubfx            x4, x4, #0xc, #0x14
    // 0xc205c0: sub             x4, x4, #0x5d
    // 0xc205c4: cmp             x4, #3
    // 0xc205c8: b.ls            #0xc205dc
    // 0xc205cc: r8 = String
    //     0xc205cc: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc205d0: r3 = Null
    //     0xc205d0: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Null
    //     0xc205d4: ldr             x3, [x3, #0x6c8]
    // 0xc205d8: r0 = String()
    //     0xc205d8: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc205dc: ldr             x0, [fp, #0x10]
    // 0xc205e0: LoadField: r1 = r0->field_7
    //     0xc205e0: ldur            w1, [x0, #7]
    // 0xc205e4: DecompressPointer r1
    //     0xc205e4: add             x1, x1, HEAP, lsl #32
    // 0xc205e8: stur            x1, [fp, #-8]
    // 0xc205ec: r2 = LoadInt32Instr(r1)
    //     0xc205ec: sbfx            x2, x1, #1, #0x1f
    // 0xc205f0: stur            x2, [fp, #-0x10]
    // 0xc205f4: mov             x3, x2
    // 0xc205f8: ubfx            x3, x3, #0, #0x20
    // 0xc205fc: r4 = 1
    //     0xc205fc: mov             x4, #1
    // 0xc20600: and             x5, x3, x4
    // 0xc20604: ubfx            x5, x5, #0, #0x20
    // 0xc20608: cbnz            x5, #0xc20668
    // 0xc2060c: r1 = 2
    //     0xc2060c: mov             x1, #2
    // 0xc20610: sdiv            x3, x2, x1
    // 0xc20614: lsl             x4, x3, #1
    // 0xc20618: stur            x4, [fp, #-8]
    // 0xc2061c: r1 = <int>
    //     0xc2061c: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xc20620: r0 = CodeUnits()
    //     0xc20620: bl              #0x52dacc  ; AllocateCodeUnitsStub -> CodeUnits (size=0x10)
    // 0xc20624: mov             x1, x0
    // 0xc20628: ldr             x0, [fp, #0x10]
    // 0xc2062c: stur            x1, [fp, #-0x18]
    // 0xc20630: StoreField: r1->field_b = r0
    //     0xc20630: stur            w0, [x1, #0xb]
    // 0xc20634: ldur            x4, [fp, #-8]
    // 0xc20638: r0 = AllocateUint8Array()
    //     0xc20638: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xc2063c: stur            x0, [fp, #-8]
    // 0xc20640: ldur            x16, [fp, #-0x18]
    // 0xc20644: SaveReg r16
    //     0xc20644: str             x16, [SP, #-8]!
    // 0xc20648: ldur            x1, [fp, #-0x10]
    // 0xc2064c: stp             x0, x1, [SP, #-0x10]!
    // 0xc20650: r0 = _decode()
    //     0xc20650: bl              #0xc206a0  ; [package:convert/src/hex/decoder.dart] ::_decode
    // 0xc20654: add             SP, SP, #0x18
    // 0xc20658: ldur            x0, [fp, #-8]
    // 0xc2065c: LeaveFrame
    //     0xc2065c: mov             SP, fp
    //     0xc20660: ldp             fp, lr, [SP], #0x10
    // 0xc20664: ret
    //     0xc20664: ret             
    // 0xc20668: r0 = FormatException()
    //     0xc20668: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xc2066c: mov             x1, x0
    // 0xc20670: r0 = "Invalid input length, must be even."
    //     0xc20670: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d6d8] "Invalid input length, must be even."
    //     0xc20674: ldr             x0, [x0, #0x6d8]
    // 0xc20678: StoreField: r1->field_7 = r0
    //     0xc20678: stur            w0, [x1, #7]
    // 0xc2067c: ldr             x0, [fp, #0x10]
    // 0xc20680: StoreField: r1->field_b = r0
    //     0xc20680: stur            w0, [x1, #0xb]
    // 0xc20684: ldur            x0, [fp, #-8]
    // 0xc20688: StoreField: r1->field_f = r0
    //     0xc20688: stur            w0, [x1, #0xf]
    // 0xc2068c: mov             x0, x1
    // 0xc20690: r0 = Throw()
    //     0xc20690: bl              #0xd67e38  ; ThrowStub
    // 0xc20694: brk             #0
    // 0xc20698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20698: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2069c: b               #0xc205a4
  }
}

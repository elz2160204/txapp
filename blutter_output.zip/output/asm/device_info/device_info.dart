// lib: , url: package:device_info/device_info.dart

// class id: 1048861, size: 0x8
class :: {
}

// class id: 4565, size: 0x10, field offset: 0x8
class DeviceInfoPlugin extends Object {

  get _ iosInfo(/* No info */) async {
    // ** addr: 0xd151bc, size: 0xc4
    // 0xd151bc: EnterFrame
    //     0xd151bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd151c0: mov             fp, SP
    // 0xd151c4: AllocStack(0x18)
    //     0xd151c4: sub             SP, SP, #0x18
    // 0xd151c8: SetupParameters(DeviceInfoPlugin this /* r1, fp-0x10 */)
    //     0xd151c8: stur            NULL, [fp, #-8]
    //     0xd151cc: mov             x0, #0
    //     0xd151d0: add             x1, fp, w0, sxtw #2
    //     0xd151d4: ldr             x1, [x1, #0x10]
    //     0xd151d8: stur            x1, [fp, #-0x10]
    // 0xd151dc: CheckStackOverflow
    //     0xd151dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd151e0: cmp             SP, x16
    //     0xd151e4: b.ls            #0xd15278
    // 0xd151e8: InitAsync() -> Future<IosDeviceInfo>
    //     0xd151e8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b68] TypeArguments: <IosDeviceInfo>
    //     0xd151ec: ldr             x0, [x0, #0xb68]
    //     0xd151f0: bl              #0x4b92e4
    // 0xd151f4: ldur            x0, [fp, #-0x10]
    // 0xd151f8: LoadField: r1 = r0->field_b
    //     0xd151f8: ldur            w1, [x0, #0xb]
    // 0xd151fc: DecompressPointer r1
    //     0xd151fc: add             x1, x1, HEAP, lsl #32
    // 0xd15200: cmp             w1, NULL
    // 0xd15204: b.ne            #0xd15270
    // 0xd15208: r0 = InitLateStaticField(0xb34) // [package:device_info_platform_interface/device_info_platform_interface.dart] DeviceInfoPlatform::_instance
    //     0xd15208: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd1520c: ldr             x0, [x0, #0x1668]
    //     0xd15210: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd15214: cmp             w0, w16
    //     0xd15218: b.ne            #0xd15228
    //     0xd1521c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b70] Field <DeviceInfoPlatform._instance@333212227>: static late (offset: 0xb34)
    //     0xd15220: ldr             x2, [x2, #0xb70]
    //     0xd15224: bl              #0xd67d44
    // 0xd15228: SaveReg r0
    //     0xd15228: str             x0, [SP, #-8]!
    // 0xd1522c: r0 = iosInfo()
    //     0xd1522c: bl              #0xd15280  ; [package:device_info_platform_interface/method_channel/method_channel_device_info.dart] MethodChannelDeviceInfo::iosInfo
    // 0xd15230: add             SP, SP, #8
    // 0xd15234: mov             x1, x0
    // 0xd15238: stur            x1, [fp, #-0x18]
    // 0xd1523c: r0 = Await()
    //     0xd1523c: bl              #0x4b8e6c  ; AwaitStub
    // 0xd15240: mov             x1, x0
    // 0xd15244: ldur            x2, [fp, #-0x10]
    // 0xd15248: StoreField: r2->field_b = r0
    //     0xd15248: stur            w0, [x2, #0xb]
    //     0xd1524c: tbz             w0, #0, #0xd15268
    //     0xd15250: ldurb           w16, [x2, #-1]
    //     0xd15254: ldurb           w17, [x0, #-1]
    //     0xd15258: and             x16, x17, x16, lsr #2
    //     0xd1525c: tst             x16, HEAP, lsr #32
    //     0xd15260: b.eq            #0xd15268
    //     0xd15264: bl              #0xd6828c
    // 0xd15268: mov             x0, x1
    // 0xd1526c: b               #0xd15274
    // 0xd15270: mov             x0, x1
    // 0xd15274: r0 = ReturnAsync()
    //     0xd15274: b               #0x501858  ; ReturnAsyncStub
    // 0xd15278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd15278: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1527c: b               #0xd151e8
  }
  get _ androidInfo(/* No info */) async {
    // ** addr: 0xd15ac8, size: 0xc4
    // 0xd15ac8: EnterFrame
    //     0xd15ac8: stp             fp, lr, [SP, #-0x10]!
    //     0xd15acc: mov             fp, SP
    // 0xd15ad0: AllocStack(0x18)
    //     0xd15ad0: sub             SP, SP, #0x18
    // 0xd15ad4: SetupParameters(DeviceInfoPlugin this /* r1, fp-0x10 */)
    //     0xd15ad4: stur            NULL, [fp, #-8]
    //     0xd15ad8: mov             x0, #0
    //     0xd15adc: add             x1, fp, w0, sxtw #2
    //     0xd15ae0: ldr             x1, [x1, #0x10]
    //     0xd15ae4: stur            x1, [fp, #-0x10]
    // 0xd15ae8: CheckStackOverflow
    //     0xd15ae8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd15aec: cmp             SP, x16
    //     0xd15af0: b.ls            #0xd15b84
    // 0xd15af4: InitAsync() -> Future<AndroidDeviceInfo>
    //     0xd15af4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14cd0] TypeArguments: <AndroidDeviceInfo>
    //     0xd15af8: ldr             x0, [x0, #0xcd0]
    //     0xd15afc: bl              #0x4b92e4
    // 0xd15b00: ldur            x0, [fp, #-0x10]
    // 0xd15b04: LoadField: r1 = r0->field_7
    //     0xd15b04: ldur            w1, [x0, #7]
    // 0xd15b08: DecompressPointer r1
    //     0xd15b08: add             x1, x1, HEAP, lsl #32
    // 0xd15b0c: cmp             w1, NULL
    // 0xd15b10: b.ne            #0xd15b7c
    // 0xd15b14: r0 = InitLateStaticField(0xb34) // [package:device_info_platform_interface/device_info_platform_interface.dart] DeviceInfoPlatform::_instance
    //     0xd15b14: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd15b18: ldr             x0, [x0, #0x1668]
    //     0xd15b1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd15b20: cmp             w0, w16
    //     0xd15b24: b.ne            #0xd15b34
    //     0xd15b28: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b70] Field <DeviceInfoPlatform._instance@333212227>: static late (offset: 0xb34)
    //     0xd15b2c: ldr             x2, [x2, #0xb70]
    //     0xd15b30: bl              #0xd67d44
    // 0xd15b34: SaveReg r0
    //     0xd15b34: str             x0, [SP, #-8]!
    // 0xd15b38: r0 = androidInfo()
    //     0xd15b38: bl              #0xd15b8c  ; [package:device_info_platform_interface/method_channel/method_channel_device_info.dart] MethodChannelDeviceInfo::androidInfo
    // 0xd15b3c: add             SP, SP, #8
    // 0xd15b40: mov             x1, x0
    // 0xd15b44: stur            x1, [fp, #-0x18]
    // 0xd15b48: r0 = Await()
    //     0xd15b48: bl              #0x4b8e6c  ; AwaitStub
    // 0xd15b4c: mov             x1, x0
    // 0xd15b50: ldur            x2, [fp, #-0x10]
    // 0xd15b54: StoreField: r2->field_7 = r0
    //     0xd15b54: stur            w0, [x2, #7]
    //     0xd15b58: tbz             w0, #0, #0xd15b74
    //     0xd15b5c: ldurb           w16, [x2, #-1]
    //     0xd15b60: ldurb           w17, [x0, #-1]
    //     0xd15b64: and             x16, x17, x16, lsr #2
    //     0xd15b68: tst             x16, HEAP, lsr #32
    //     0xd15b6c: b.eq            #0xd15b74
    //     0xd15b70: bl              #0xd6828c
    // 0xd15b74: mov             x0, x1
    // 0xd15b78: b               #0xd15b80
    // 0xd15b7c: mov             x0, x1
    // 0xd15b80: r0 = ReturnAsync()
    //     0xd15b80: b               #0x501858  ; ReturnAsyncStub
    // 0xd15b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd15b84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd15b88: b               #0xd15af4
  }
}

// lib: , url: package:dbus/src/dbus_match_rule.dart

// class id: 1048838, size: 0x8
class :: {
}

// class id: 4613, size: 0x20, field offset: 0x8
//   const constructor, 
class DBusMatchRule extends Object {

  _ match(/* No info */) {
    // ** addr: 0xa04fa0, size: 0x19c
    // 0xa04fa0: EnterFrame
    //     0xa04fa0: stp             fp, lr, [SP, #-0x10]!
    //     0xa04fa4: mov             fp, SP
    // 0xa04fa8: CheckStackOverflow
    //     0xa04fa8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa04fac: cmp             SP, x16
    //     0xa04fb0: b.ls            #0xa05134
    // 0xa04fb4: ldr             x1, [fp, #0x30]
    // 0xa04fb8: LoadField: r0 = r1->field_b
    //     0xa04fb8: ldur            w0, [x1, #0xb]
    // 0xa04fbc: DecompressPointer r0
    //     0xa04fbc: add             x0, x0, HEAP, lsl #32
    // 0xa04fc0: cmp             w0, NULL
    // 0xa04fc4: b.eq            #0xa05000
    // 0xa04fc8: r2 = LoadClassIdInstr(r0)
    //     0xa04fc8: ldur            x2, [x0, #-1]
    //     0xa04fcc: ubfx            x2, x2, #0xc, #0x14
    // 0xa04fd0: ldr             x16, [fp, #0x10]
    // 0xa04fd4: stp             x16, x0, [SP, #-0x10]!
    // 0xa04fd8: mov             x0, x2
    // 0xa04fdc: mov             lr, x0
    // 0xa04fe0: ldr             lr, [x21, lr, lsl #3]
    // 0xa04fe4: blr             lr
    // 0xa04fe8: add             SP, SP, #0x10
    // 0xa04fec: tbz             w0, #4, #0xa05000
    // 0xa04ff0: r0 = false
    //     0xa04ff0: add             x0, NULL, #0x30  ; false
    // 0xa04ff4: LeaveFrame
    //     0xa04ff4: mov             SP, fp
    //     0xa04ff8: ldp             fp, lr, [SP], #0x10
    // 0xa04ffc: ret
    //     0xa04ffc: ret             
    // 0xa05000: ldr             x1, [fp, #0x30]
    // 0xa05004: LoadField: r0 = r1->field_f
    //     0xa05004: ldur            w0, [x1, #0xf]
    // 0xa05008: DecompressPointer r0
    //     0xa05008: add             x0, x0, HEAP, lsl #32
    // 0xa0500c: cmp             w0, NULL
    // 0xa05010: b.eq            #0xa0504c
    // 0xa05014: r2 = LoadClassIdInstr(r0)
    //     0xa05014: ldur            x2, [x0, #-1]
    //     0xa05018: ubfx            x2, x2, #0xc, #0x14
    // 0xa0501c: ldr             x16, [fp, #0x28]
    // 0xa05020: stp             x16, x0, [SP, #-0x10]!
    // 0xa05024: mov             x0, x2
    // 0xa05028: mov             lr, x0
    // 0xa0502c: ldr             lr, [x21, lr, lsl #3]
    // 0xa05030: blr             lr
    // 0xa05034: add             SP, SP, #0x10
    // 0xa05038: tbz             w0, #4, #0xa0504c
    // 0xa0503c: r0 = false
    //     0xa0503c: add             x0, NULL, #0x30  ; false
    // 0xa05040: LeaveFrame
    //     0xa05040: mov             SP, fp
    //     0xa05044: ldp             fp, lr, [SP], #0x10
    // 0xa05048: ret
    //     0xa05048: ret             
    // 0xa0504c: ldr             x1, [fp, #0x30]
    // 0xa05050: LoadField: r0 = r1->field_13
    //     0xa05050: ldur            w0, [x1, #0x13]
    // 0xa05054: DecompressPointer r0
    //     0xa05054: add             x0, x0, HEAP, lsl #32
    // 0xa05058: cmp             w0, NULL
    // 0xa0505c: b.eq            #0xa05098
    // 0xa05060: r2 = LoadClassIdInstr(r0)
    //     0xa05060: ldur            x2, [x0, #-1]
    //     0xa05064: ubfx            x2, x2, #0xc, #0x14
    // 0xa05068: ldr             x16, [fp, #0x20]
    // 0xa0506c: stp             x16, x0, [SP, #-0x10]!
    // 0xa05070: mov             x0, x2
    // 0xa05074: mov             lr, x0
    // 0xa05078: ldr             lr, [x21, lr, lsl #3]
    // 0xa0507c: blr             lr
    // 0xa05080: add             SP, SP, #0x10
    // 0xa05084: tbz             w0, #4, #0xa05098
    // 0xa05088: r0 = false
    //     0xa05088: add             x0, NULL, #0x30  ; false
    // 0xa0508c: LeaveFrame
    //     0xa0508c: mov             SP, fp
    //     0xa05090: ldp             fp, lr, [SP], #0x10
    // 0xa05094: ret
    //     0xa05094: ret             
    // 0xa05098: ldr             x1, [fp, #0x30]
    // 0xa0509c: LoadField: r0 = r1->field_17
    //     0xa0509c: ldur            w0, [x1, #0x17]
    // 0xa050a0: DecompressPointer r0
    //     0xa050a0: add             x0, x0, HEAP, lsl #32
    // 0xa050a4: cmp             w0, NULL
    // 0xa050a8: b.eq            #0xa050e4
    // 0xa050ac: r2 = LoadClassIdInstr(r0)
    //     0xa050ac: ldur            x2, [x0, #-1]
    //     0xa050b0: ubfx            x2, x2, #0xc, #0x14
    // 0xa050b4: ldr             x16, [fp, #0x18]
    // 0xa050b8: stp             x16, x0, [SP, #-0x10]!
    // 0xa050bc: mov             x0, x2
    // 0xa050c0: mov             lr, x0
    // 0xa050c4: ldr             lr, [x21, lr, lsl #3]
    // 0xa050c8: blr             lr
    // 0xa050cc: add             SP, SP, #0x10
    // 0xa050d0: tbz             w0, #4, #0xa050e4
    // 0xa050d4: r0 = false
    //     0xa050d4: add             x0, NULL, #0x30  ; false
    // 0xa050d8: LeaveFrame
    //     0xa050d8: mov             SP, fp
    //     0xa050dc: ldp             fp, lr, [SP], #0x10
    // 0xa050e0: ret
    //     0xa050e0: ret             
    // 0xa050e4: ldr             x0, [fp, #0x30]
    // 0xa050e8: LoadField: r1 = r0->field_1b
    //     0xa050e8: ldur            w1, [x0, #0x1b]
    // 0xa050ec: DecompressPointer r1
    //     0xa050ec: add             x1, x1, HEAP, lsl #32
    // 0xa050f0: cmp             w1, NULL
    // 0xa050f4: b.eq            #0xa05124
    // 0xa050f8: ldr             x0, [fp, #0x18]
    // 0xa050fc: cmp             w0, NULL
    // 0xa05100: b.eq            #0xa05124
    // 0xa05104: stp             x1, x0, [SP, #-0x10]!
    // 0xa05108: r0 = isInNamespace()
    //     0xa05108: bl              #0xa0513c  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::isInNamespace
    // 0xa0510c: add             SP, SP, #0x10
    // 0xa05110: tbz             w0, #4, #0xa05124
    // 0xa05114: r0 = false
    //     0xa05114: add             x0, NULL, #0x30  ; false
    // 0xa05118: LeaveFrame
    //     0xa05118: mov             SP, fp
    //     0xa0511c: ldp             fp, lr, [SP], #0x10
    // 0xa05120: ret
    //     0xa05120: ret             
    // 0xa05124: r0 = true
    //     0xa05124: add             x0, NULL, #0x20  ; true
    // 0xa05128: LeaveFrame
    //     0xa05128: mov             SP, fp
    //     0xa0512c: ldp             fp, lr, [SP], #0x10
    // 0xa05130: ret
    //     0xa05130: ret             
    // 0xa05134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa05134: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa05138: b               #0xa04fb4
  }
  [closure] bool <anonymous closure>(dynamic, String) {
    // ** addr: 0xacff6c, size: 0x84
    // 0xacff6c: EnterFrame
    //     0xacff6c: stp             fp, lr, [SP, #-0x10]!
    //     0xacff70: mov             fp, SP
    // 0xacff74: AllocStack(0x8)
    //     0xacff74: sub             SP, SP, #8
    // 0xacff78: SetupParameters()
    //     0xacff78: ldr             x0, [fp, #0x18]
    //     0xacff7c: ldur            w1, [x0, #0x17]
    //     0xacff80: add             x1, x1, HEAP, lsl #32
    // 0xacff84: CheckStackOverflow
    //     0xacff84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacff88: cmp             SP, x16
    //     0xacff8c: b.ls            #0xacffe8
    // 0xacff90: LoadField: r0 = r1->field_f
    //     0xacff90: ldur            w0, [x1, #0xf]
    // 0xacff94: DecompressPointer r0
    //     0xacff94: add             x0, x0, HEAP, lsl #32
    // 0xacff98: stur            x0, [fp, #-8]
    // 0xacff9c: ldr             x16, [fp, #0x10]
    // 0xacffa0: stp             x16, x0, [SP, #-0x10]!
    // 0xacffa4: r0 = _getValueOrData()
    //     0xacffa4: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xacffa8: add             SP, SP, #0x10
    // 0xacffac: ldur            x1, [fp, #-8]
    // 0xacffb0: LoadField: r2 = r1->field_f
    //     0xacffb0: ldur            w2, [x1, #0xf]
    // 0xacffb4: DecompressPointer r2
    //     0xacffb4: add             x2, x2, HEAP, lsl #32
    // 0xacffb8: cmp             w2, w0
    // 0xacffbc: b.ne            #0xacffc8
    // 0xacffc0: r1 = Null
    //     0xacffc0: mov             x1, NULL
    // 0xacffc4: b               #0xacffcc
    // 0xacffc8: mov             x1, x0
    // 0xacffcc: cmp             w1, NULL
    // 0xacffd0: r16 = true
    //     0xacffd0: add             x16, NULL, #0x20  ; true
    // 0xacffd4: r17 = false
    //     0xacffd4: add             x17, NULL, #0x30  ; false
    // 0xacffd8: csel            x0, x16, x17, ne
    // 0xacffdc: LeaveFrame
    //     0xacffdc: mov             SP, fp
    //     0xacffe0: ldp             fp, lr, [SP], #0x10
    // 0xacffe4: ret
    //     0xacffe4: ret             
    // 0xacffe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacffe8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacffec: b               #0xacff90
  }
  _ toString(/* No info */) {
    // ** addr: 0xacfff0, size: 0x2f4
    // 0xacfff0: EnterFrame
    //     0xacfff0: stp             fp, lr, [SP, #-0x10]!
    //     0xacfff4: mov             fp, SP
    // 0xacfff8: AllocStack(0x10)
    //     0xacfff8: sub             SP, SP, #0x10
    // 0xacfffc: CheckStackOverflow
    //     0xacfffc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad0000: cmp             SP, x16
    //     0xad0004: b.ls            #0xad02dc
    // 0xad0008: r1 = Null
    //     0xad0008: mov             x1, NULL
    // 0xad000c: r2 = 24
    //     0xad000c: mov             x2, #0x18
    // 0xad0010: r0 = AllocateArray()
    //     0xad0010: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0014: stur            x0, [fp, #-8]
    // 0xad0018: r17 = "type"
    //     0xad0018: ldr             x17, [PP, #0x1db8]  ; [pp+0x1db8] "type"
    // 0xad001c: StoreField: r0->field_f = r17
    //     0xad001c: stur            w17, [x0, #0xf]
    // 0xad0020: r17 = "DBusMessageType.signal"
    //     0xad0020: ldr             x17, [PP, #0x7638]  ; [pp+0x7638] "DBusMessageType.signal"
    // 0xad0024: StoreField: r0->field_13 = r17
    //     0xad0024: stur            w17, [x0, #0x13]
    // 0xad0028: r17 = "sender"
    //     0xad0028: ldr             x17, [PP, #0x7640]  ; [pp+0x7640] "sender"
    // 0xad002c: StoreField: r0->field_17 = r17
    //     0xad002c: stur            w17, [x0, #0x17]
    // 0xad0030: ldr             x1, [fp, #0x10]
    // 0xad0034: LoadField: r2 = r1->field_b
    //     0xad0034: ldur            w2, [x1, #0xb]
    // 0xad0038: DecompressPointer r2
    //     0xad0038: add             x2, x2, HEAP, lsl #32
    // 0xad003c: cmp             w2, NULL
    // 0xad0040: b.ne            #0xad0054
    // 0xad0044: mov             x3, x1
    // 0xad0048: mov             x2, x0
    // 0xad004c: r0 = Null
    //     0xad004c: mov             x0, NULL
    // 0xad0050: b               #0xad0068
    // 0xad0054: SaveReg r2
    //     0xad0054: str             x2, [SP, #-8]!
    // 0xad0058: r0 = toString()
    //     0xad0058: bl              #0xacf7c0  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::toString
    // 0xad005c: add             SP, SP, #8
    // 0xad0060: ldr             x3, [fp, #0x10]
    // 0xad0064: ldur            x2, [fp, #-8]
    // 0xad0068: mov             x1, x2
    // 0xad006c: ArrayStore: r1[3] = r0  ; List_4
    //     0xad006c: add             x25, x1, #0x1b
    //     0xad0070: str             w0, [x25]
    //     0xad0074: tbz             w0, #0, #0xad0090
    //     0xad0078: ldurb           w16, [x1, #-1]
    //     0xad007c: ldurb           w17, [x0, #-1]
    //     0xad0080: and             x16, x17, x16, lsr #2
    //     0xad0084: tst             x16, HEAP, lsr #32
    //     0xad0088: b.eq            #0xad0090
    //     0xad008c: bl              #0xd67e5c
    // 0xad0090: r17 = "interface"
    //     0xad0090: ldr             x17, [PP, #0x508]  ; [pp+0x508] "interface"
    // 0xad0094: StoreField: r2->field_1f = r17
    //     0xad0094: stur            w17, [x2, #0x1f]
    // 0xad0098: LoadField: r0 = r3->field_f
    //     0xad0098: ldur            w0, [x3, #0xf]
    // 0xad009c: DecompressPointer r0
    //     0xad009c: add             x0, x0, HEAP, lsl #32
    // 0xad00a0: cmp             w0, NULL
    // 0xad00a4: b.ne            #0xad00b0
    // 0xad00a8: r0 = Null
    //     0xad00a8: mov             x0, NULL
    // 0xad00ac: b               #0xad00c4
    // 0xad00b0: SaveReg r0
    //     0xad00b0: str             x0, [SP, #-8]!
    // 0xad00b4: r0 = toString()
    //     0xad00b4: bl              #0xacfb78  ; [package:dbus/src/dbus_interface_name.dart] DBusInterfaceName::toString
    // 0xad00b8: add             SP, SP, #8
    // 0xad00bc: ldr             x3, [fp, #0x10]
    // 0xad00c0: ldur            x2, [fp, #-8]
    // 0xad00c4: mov             x1, x2
    // 0xad00c8: ArrayStore: r1[5] = r0  ; List_4
    //     0xad00c8: add             x25, x1, #0x23
    //     0xad00cc: str             w0, [x25]
    //     0xad00d0: tbz             w0, #0, #0xad00ec
    //     0xad00d4: ldurb           w16, [x1, #-1]
    //     0xad00d8: ldurb           w17, [x0, #-1]
    //     0xad00dc: and             x16, x17, x16, lsr #2
    //     0xad00e0: tst             x16, HEAP, lsr #32
    //     0xad00e4: b.eq            #0xad00ec
    //     0xad00e8: bl              #0xd67e5c
    // 0xad00ec: r17 = "member"
    //     0xad00ec: ldr             x17, [PP, #0x7648]  ; [pp+0x7648] "member"
    // 0xad00f0: StoreField: r2->field_27 = r17
    //     0xad00f0: stur            w17, [x2, #0x27]
    // 0xad00f4: LoadField: r0 = r3->field_13
    //     0xad00f4: ldur            w0, [x3, #0x13]
    // 0xad00f8: DecompressPointer r0
    //     0xad00f8: add             x0, x0, HEAP, lsl #32
    // 0xad00fc: cmp             w0, NULL
    // 0xad0100: b.ne            #0xad010c
    // 0xad0104: r0 = Null
    //     0xad0104: mov             x0, NULL
    // 0xad0108: b               #0xad0120
    // 0xad010c: SaveReg r0
    //     0xad010c: str             x0, [SP, #-8]!
    // 0xad0110: r0 = toString()
    //     0xad0110: bl              #0xad03bc  ; [package:dbus/src/dbus_member_name.dart] DBusMemberName::toString
    // 0xad0114: add             SP, SP, #8
    // 0xad0118: ldr             x3, [fp, #0x10]
    // 0xad011c: ldur            x2, [fp, #-8]
    // 0xad0120: mov             x1, x2
    // 0xad0124: ArrayStore: r1[7] = r0  ; List_4
    //     0xad0124: add             x25, x1, #0x2b
    //     0xad0128: str             w0, [x25]
    //     0xad012c: tbz             w0, #0, #0xad0148
    //     0xad0130: ldurb           w16, [x1, #-1]
    //     0xad0134: ldurb           w17, [x0, #-1]
    //     0xad0138: and             x16, x17, x16, lsr #2
    //     0xad013c: tst             x16, HEAP, lsr #32
    //     0xad0140: b.eq            #0xad0148
    //     0xad0144: bl              #0xd67e5c
    // 0xad0148: r17 = "path"
    //     0xad0148: ldr             x17, [PP, #0x518]  ; [pp+0x518] "path"
    // 0xad014c: StoreField: r2->field_2f = r17
    //     0xad014c: stur            w17, [x2, #0x2f]
    // 0xad0150: LoadField: r0 = r3->field_17
    //     0xad0150: ldur            w0, [x3, #0x17]
    // 0xad0154: DecompressPointer r0
    //     0xad0154: add             x0, x0, HEAP, lsl #32
    // 0xad0158: cmp             w0, NULL
    // 0xad015c: b.ne            #0xad0168
    // 0xad0160: r0 = Null
    //     0xad0160: mov             x0, NULL
    // 0xad0164: b               #0xad017c
    // 0xad0168: SaveReg r0
    //     0xad0168: str             x0, [SP, #-8]!
    // 0xad016c: r0 = toString()
    //     0xad016c: bl              #0xad1718  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::toString
    // 0xad0170: add             SP, SP, #8
    // 0xad0174: ldr             x3, [fp, #0x10]
    // 0xad0178: ldur            x2, [fp, #-8]
    // 0xad017c: mov             x1, x2
    // 0xad0180: ArrayStore: r1[9] = r0  ; List_4
    //     0xad0180: add             x25, x1, #0x33
    //     0xad0184: str             w0, [x25]
    //     0xad0188: tbz             w0, #0, #0xad01a4
    //     0xad018c: ldurb           w16, [x1, #-1]
    //     0xad0190: ldurb           w17, [x0, #-1]
    //     0xad0194: and             x16, x17, x16, lsr #2
    //     0xad0198: tst             x16, HEAP, lsr #32
    //     0xad019c: b.eq            #0xad01a4
    //     0xad01a0: bl              #0xd67e5c
    // 0xad01a4: r17 = "pathNamespace"
    //     0xad01a4: ldr             x17, [PP, #0x520]  ; [pp+0x520] "pathNamespace"
    // 0xad01a8: StoreField: r2->field_37 = r17
    //     0xad01a8: stur            w17, [x2, #0x37]
    // 0xad01ac: LoadField: r0 = r3->field_1b
    //     0xad01ac: ldur            w0, [x3, #0x1b]
    // 0xad01b0: DecompressPointer r0
    //     0xad01b0: add             x0, x0, HEAP, lsl #32
    // 0xad01b4: cmp             w0, NULL
    // 0xad01b8: b.ne            #0xad01c4
    // 0xad01bc: r0 = Null
    //     0xad01bc: mov             x0, NULL
    // 0xad01c0: b               #0xad01d0
    // 0xad01c4: SaveReg r0
    //     0xad01c4: str             x0, [SP, #-8]!
    // 0xad01c8: r0 = toString()
    //     0xad01c8: bl              #0xad1718  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::toString
    // 0xad01cc: add             SP, SP, #8
    // 0xad01d0: ldur            x1, [fp, #-8]
    // 0xad01d4: ArrayStore: r1[11] = r0  ; List_4
    //     0xad01d4: add             x25, x1, #0x3b
    //     0xad01d8: str             w0, [x25]
    //     0xad01dc: tbz             w0, #0, #0xad01f8
    //     0xad01e0: ldurb           w16, [x1, #-1]
    //     0xad01e4: ldurb           w17, [x0, #-1]
    //     0xad01e8: and             x16, x17, x16, lsr #2
    //     0xad01ec: tst             x16, HEAP, lsr #32
    //     0xad01f0: b.eq            #0xad01f8
    //     0xad01f4: bl              #0xd67e5c
    // 0xad01f8: r16 = <String, String?>
    //     0xad01f8: ldr             x16, [PP, #0x7650]  ; [pp+0x7650] TypeArguments: <String, String?>
    // 0xad01fc: ldur            lr, [fp, #-8]
    // 0xad0200: stp             lr, x16, [SP, #-0x10]!
    // 0xad0204: r0 = Map._fromLiteral()
    //     0xad0204: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xad0208: add             SP, SP, #0x10
    // 0xad020c: stur            x0, [fp, #-8]
    // 0xad0210: r1 = 1
    //     0xad0210: mov             x1, #1
    // 0xad0214: r0 = AllocateContext()
    //     0xad0214: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad0218: mov             x1, x0
    // 0xad021c: ldur            x0, [fp, #-8]
    // 0xad0220: stur            x1, [fp, #-0x10]
    // 0xad0224: StoreField: r1->field_f = r0
    //     0xad0224: stur            w0, [x1, #0xf]
    // 0xad0228: SaveReg r0
    //     0xad0228: str             x0, [SP, #-8]!
    // 0xad022c: r0 = keys()
    //     0xad022c: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0xad0230: add             SP, SP, #8
    // 0xad0234: ldur            x2, [fp, #-0x10]
    // 0xad0238: r1 = Function '<anonymous closure>':.
    //     0xad0238: ldr             x1, [PP, #0x7658]  ; [pp+0x7658] AnonymousClosure: (0xacff6c), in [package:dbus/src/dbus_match_rule.dart] DBusMatchRule::toString (0xacfff0)
    // 0xad023c: stur            x0, [fp, #-8]
    // 0xad0240: r0 = AllocateClosure()
    //     0xad0240: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad0244: ldur            x16, [fp, #-8]
    // 0xad0248: stp             x0, x16, [SP, #-0x10]!
    // 0xad024c: r0 = where()
    //     0xad024c: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0xad0250: add             SP, SP, #0x10
    // 0xad0254: ldur            x2, [fp, #-0x10]
    // 0xad0258: r1 = Function '<anonymous closure>':.
    //     0xad0258: ldr             x1, [PP, #0x7660]  ; [pp+0x7660] AnonymousClosure: (0xad02e4), in [package:dbus/src/dbus_match_rule.dart] DBusMatchRule::toString (0xacfff0)
    // 0xad025c: stur            x0, [fp, #-8]
    // 0xad0260: r0 = AllocateClosure()
    //     0xad0260: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad0264: r16 = <String>
    //     0xad0264: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad0268: ldur            lr, [fp, #-8]
    // 0xad026c: stp             lr, x16, [SP, #-0x10]!
    // 0xad0270: SaveReg r0
    //     0xad0270: str             x0, [SP, #-8]!
    // 0xad0274: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad0274: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad0278: r0 = map()
    //     0xad0278: bl              #0x6ba568  ; [dart:_internal] WhereIterable::map
    // 0xad027c: add             SP, SP, #0x18
    // 0xad0280: r16 = ", "
    //     0xad0280: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad0284: stp             x16, x0, [SP, #-0x10]!
    // 0xad0288: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad0288: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad028c: r0 = join()
    //     0xad028c: bl              #0x6a9d88  ; [dart:core] Iterable::join
    // 0xad0290: add             SP, SP, #0x10
    // 0xad0294: r1 = Null
    //     0xad0294: mov             x1, NULL
    // 0xad0298: r2 = 8
    //     0xad0298: mov             x2, #8
    // 0xad029c: stur            x0, [fp, #-8]
    // 0xad02a0: r0 = AllocateArray()
    //     0xad02a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad02a4: r17 = DBusMatchRule
    //     0xad02a4: ldr             x17, [PP, #0x7668]  ; [pp+0x7668] Type: DBusMatchRule
    // 0xad02a8: StoreField: r0->field_f = r17
    //     0xad02a8: stur            w17, [x0, #0xf]
    // 0xad02ac: r17 = "("
    //     0xad02ac: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad02b0: StoreField: r0->field_13 = r17
    //     0xad02b0: stur            w17, [x0, #0x13]
    // 0xad02b4: ldur            x1, [fp, #-8]
    // 0xad02b8: StoreField: r0->field_17 = r1
    //     0xad02b8: stur            w1, [x0, #0x17]
    // 0xad02bc: r17 = ")"
    //     0xad02bc: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad02c0: StoreField: r0->field_1b = r17
    //     0xad02c0: stur            w17, [x0, #0x1b]
    // 0xad02c4: SaveReg r0
    //     0xad02c4: str             x0, [SP, #-8]!
    // 0xad02c8: r0 = _interpolate()
    //     0xad02c8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad02cc: add             SP, SP, #8
    // 0xad02d0: LeaveFrame
    //     0xad02d0: mov             SP, fp
    //     0xad02d4: ldp             fp, lr, [SP], #0x10
    // 0xad02d8: ret
    //     0xad02d8: ret             
    // 0xad02dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad02dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad02e0: b               #0xad0008
  }
  [closure] String <anonymous closure>(dynamic, String) {
    // ** addr: 0xad02e4, size: 0xd8
    // 0xad02e4: EnterFrame
    //     0xad02e4: stp             fp, lr, [SP, #-0x10]!
    //     0xad02e8: mov             fp, SP
    // 0xad02ec: AllocStack(0x18)
    //     0xad02ec: sub             SP, SP, #0x18
    // 0xad02f0: SetupParameters()
    //     0xad02f0: ldr             x0, [fp, #0x18]
    //     0xad02f4: ldur            w3, [x0, #0x17]
    //     0xad02f8: add             x3, x3, HEAP, lsl #32
    //     0xad02fc: stur            x3, [fp, #-8]
    // 0xad0300: CheckStackOverflow
    //     0xad0300: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad0304: cmp             SP, x16
    //     0xad0308: b.ls            #0xad03b4
    // 0xad030c: r1 = Null
    //     0xad030c: mov             x1, NULL
    // 0xad0310: r2 = 6
    //     0xad0310: mov             x2, #6
    // 0xad0314: r0 = AllocateArray()
    //     0xad0314: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0318: mov             x1, x0
    // 0xad031c: ldr             x0, [fp, #0x10]
    // 0xad0320: stur            x1, [fp, #-0x18]
    // 0xad0324: StoreField: r1->field_f = r0
    //     0xad0324: stur            w0, [x1, #0xf]
    // 0xad0328: r17 = "="
    //     0xad0328: ldr             x17, [PP, #0x2a8]  ; [pp+0x2a8] "="
    // 0xad032c: StoreField: r1->field_13 = r17
    //     0xad032c: stur            w17, [x1, #0x13]
    // 0xad0330: ldur            x2, [fp, #-8]
    // 0xad0334: LoadField: r3 = r2->field_f
    //     0xad0334: ldur            w3, [x2, #0xf]
    // 0xad0338: DecompressPointer r3
    //     0xad0338: add             x3, x3, HEAP, lsl #32
    // 0xad033c: stur            x3, [fp, #-0x10]
    // 0xad0340: stp             x0, x3, [SP, #-0x10]!
    // 0xad0344: r0 = _getValueOrData()
    //     0xad0344: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xad0348: add             SP, SP, #0x10
    // 0xad034c: mov             x1, x0
    // 0xad0350: ldur            x0, [fp, #-0x10]
    // 0xad0354: LoadField: r2 = r0->field_f
    //     0xad0354: ldur            w2, [x0, #0xf]
    // 0xad0358: DecompressPointer r2
    //     0xad0358: add             x2, x2, HEAP, lsl #32
    // 0xad035c: cmp             w2, w1
    // 0xad0360: b.ne            #0xad036c
    // 0xad0364: r0 = Null
    //     0xad0364: mov             x0, NULL
    // 0xad0368: b               #0xad0370
    // 0xad036c: mov             x0, x1
    // 0xad0370: ldur            x1, [fp, #-0x18]
    // 0xad0374: ArrayStore: r1[2] = r0  ; List_4
    //     0xad0374: add             x25, x1, #0x17
    //     0xad0378: str             w0, [x25]
    //     0xad037c: tbz             w0, #0, #0xad0398
    //     0xad0380: ldurb           w16, [x1, #-1]
    //     0xad0384: ldurb           w17, [x0, #-1]
    //     0xad0388: and             x16, x17, x16, lsr #2
    //     0xad038c: tst             x16, HEAP, lsr #32
    //     0xad0390: b.eq            #0xad0398
    //     0xad0394: bl              #0xd67e5c
    // 0xad0398: ldur            x16, [fp, #-0x18]
    // 0xad039c: SaveReg r16
    //     0xad039c: str             x16, [SP, #-8]!
    // 0xad03a0: r0 = _interpolate()
    //     0xad03a0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad03a4: add             SP, SP, #8
    // 0xad03a8: LeaveFrame
    //     0xad03a8: mov             SP, fp
    //     0xad03ac: ldp             fp, lr, [SP], #0x10
    // 0xad03b0: ret
    //     0xad03b0: ret             
    // 0xad03b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad03b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad03b8: b               #0xad030c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafa74c, size: 0x88
    // 0xafa74c: EnterFrame
    //     0xafa74c: stp             fp, lr, [SP, #-0x10]!
    //     0xafa750: mov             fp, SP
    // 0xafa754: CheckStackOverflow
    //     0xafa754: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafa758: cmp             SP, x16
    //     0xafa75c: b.ls            #0xafa7cc
    // 0xafa760: ldr             x0, [fp, #0x10]
    // 0xafa764: LoadField: r1 = r0->field_b
    //     0xafa764: ldur            w1, [x0, #0xb]
    // 0xafa768: DecompressPointer r1
    //     0xafa768: add             x1, x1, HEAP, lsl #32
    // 0xafa76c: LoadField: r2 = r0->field_f
    //     0xafa76c: ldur            w2, [x0, #0xf]
    // 0xafa770: DecompressPointer r2
    //     0xafa770: add             x2, x2, HEAP, lsl #32
    // 0xafa774: LoadField: r3 = r0->field_13
    //     0xafa774: ldur            w3, [x0, #0x13]
    // 0xafa778: DecompressPointer r3
    //     0xafa778: add             x3, x3, HEAP, lsl #32
    // 0xafa77c: LoadField: r4 = r0->field_17
    //     0xafa77c: ldur            w4, [x0, #0x17]
    // 0xafa780: DecompressPointer r4
    //     0xafa780: add             x4, x4, HEAP, lsl #32
    // 0xafa784: LoadField: r5 = r0->field_1b
    //     0xafa784: ldur            w5, [x0, #0x1b]
    // 0xafa788: DecompressPointer r5
    //     0xafa788: add             x5, x5, HEAP, lsl #32
    // 0xafa78c: r16 = Instance_DBusMessageType
    //     0xafa78c: ldr             x16, [PP, #0x530]  ; [pp+0x530] Obj!DBusMessageType@b667b1
    // 0xafa790: stp             x1, x16, [SP, #-0x10]!
    // 0xafa794: stp             x3, x2, [SP, #-0x10]!
    // 0xafa798: stp             x5, x4, [SP, #-0x10]!
    // 0xafa79c: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0xafa79c: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0xafa7a0: r0 = hash()
    //     0xafa7a0: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafa7a4: add             SP, SP, #0x30
    // 0xafa7a8: mov             x2, x0
    // 0xafa7ac: r0 = BoxInt64Instr(r2)
    //     0xafa7ac: sbfiz           x0, x2, #1, #0x1f
    //     0xafa7b0: cmp             x2, x0, asr #1
    //     0xafa7b4: b.eq            #0xafa7c0
    //     0xafa7b8: bl              #0xd69bb8
    //     0xafa7bc: stur            x2, [x0, #7]
    // 0xafa7c0: LeaveFrame
    //     0xafa7c0: mov             SP, fp
    //     0xafa7c4: ldp             fp, lr, [SP], #0x10
    // 0xafa7c8: ret
    //     0xafa7c8: ret             
    // 0xafa7cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa7cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa7d0: b               #0xafa760
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e450, size: 0x190
    // 0xc6e450: EnterFrame
    //     0xc6e450: stp             fp, lr, [SP, #-0x10]!
    //     0xc6e454: mov             fp, SP
    // 0xc6e458: CheckStackOverflow
    //     0xc6e458: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6e45c: cmp             SP, x16
    //     0xc6e460: b.ls            #0xc6e5d8
    // 0xc6e464: ldr             x1, [fp, #0x10]
    // 0xc6e468: cmp             w1, NULL
    // 0xc6e46c: b.ne            #0xc6e480
    // 0xc6e470: r0 = false
    //     0xc6e470: add             x0, NULL, #0x30  ; false
    // 0xc6e474: LeaveFrame
    //     0xc6e474: mov             SP, fp
    //     0xc6e478: ldp             fp, lr, [SP], #0x10
    // 0xc6e47c: ret
    //     0xc6e47c: ret             
    // 0xc6e480: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e480: mov             x0, #0x76
    //     0xc6e484: tbz             w1, #0, #0xc6e494
    //     0xc6e488: ldur            x0, [x1, #-1]
    //     0xc6e48c: ubfx            x0, x0, #0xc, #0x14
    //     0xc6e490: lsl             x0, x0, #1
    // 0xc6e494: r17 = 9226
    //     0xc6e494: mov             x17, #0x240a
    // 0xc6e498: cmp             w0, w17
    // 0xc6e49c: b.ne            #0xc6e5c8
    // 0xc6e4a0: ldr             x2, [fp, #0x18]
    // 0xc6e4a4: LoadField: r0 = r1->field_b
    //     0xc6e4a4: ldur            w0, [x1, #0xb]
    // 0xc6e4a8: DecompressPointer r0
    //     0xc6e4a8: add             x0, x0, HEAP, lsl #32
    // 0xc6e4ac: LoadField: r3 = r2->field_b
    //     0xc6e4ac: ldur            w3, [x2, #0xb]
    // 0xc6e4b0: DecompressPointer r3
    //     0xc6e4b0: add             x3, x3, HEAP, lsl #32
    // 0xc6e4b4: r4 = LoadClassIdInstr(r0)
    //     0xc6e4b4: ldur            x4, [x0, #-1]
    //     0xc6e4b8: ubfx            x4, x4, #0xc, #0x14
    // 0xc6e4bc: stp             x3, x0, [SP, #-0x10]!
    // 0xc6e4c0: mov             x0, x4
    // 0xc6e4c4: mov             lr, x0
    // 0xc6e4c8: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e4cc: blr             lr
    // 0xc6e4d0: add             SP, SP, #0x10
    // 0xc6e4d4: tbnz            w0, #4, #0xc6e5c8
    // 0xc6e4d8: ldr             x2, [fp, #0x18]
    // 0xc6e4dc: ldr             x1, [fp, #0x10]
    // 0xc6e4e0: LoadField: r0 = r1->field_f
    //     0xc6e4e0: ldur            w0, [x1, #0xf]
    // 0xc6e4e4: DecompressPointer r0
    //     0xc6e4e4: add             x0, x0, HEAP, lsl #32
    // 0xc6e4e8: LoadField: r3 = r2->field_f
    //     0xc6e4e8: ldur            w3, [x2, #0xf]
    // 0xc6e4ec: DecompressPointer r3
    //     0xc6e4ec: add             x3, x3, HEAP, lsl #32
    // 0xc6e4f0: r4 = LoadClassIdInstr(r0)
    //     0xc6e4f0: ldur            x4, [x0, #-1]
    //     0xc6e4f4: ubfx            x4, x4, #0xc, #0x14
    // 0xc6e4f8: stp             x3, x0, [SP, #-0x10]!
    // 0xc6e4fc: mov             x0, x4
    // 0xc6e500: mov             lr, x0
    // 0xc6e504: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e508: blr             lr
    // 0xc6e50c: add             SP, SP, #0x10
    // 0xc6e510: tbnz            w0, #4, #0xc6e5c8
    // 0xc6e514: ldr             x2, [fp, #0x18]
    // 0xc6e518: ldr             x1, [fp, #0x10]
    // 0xc6e51c: LoadField: r0 = r1->field_13
    //     0xc6e51c: ldur            w0, [x1, #0x13]
    // 0xc6e520: DecompressPointer r0
    //     0xc6e520: add             x0, x0, HEAP, lsl #32
    // 0xc6e524: LoadField: r3 = r2->field_13
    //     0xc6e524: ldur            w3, [x2, #0x13]
    // 0xc6e528: DecompressPointer r3
    //     0xc6e528: add             x3, x3, HEAP, lsl #32
    // 0xc6e52c: r4 = LoadClassIdInstr(r0)
    //     0xc6e52c: ldur            x4, [x0, #-1]
    //     0xc6e530: ubfx            x4, x4, #0xc, #0x14
    // 0xc6e534: stp             x3, x0, [SP, #-0x10]!
    // 0xc6e538: mov             x0, x4
    // 0xc6e53c: mov             lr, x0
    // 0xc6e540: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e544: blr             lr
    // 0xc6e548: add             SP, SP, #0x10
    // 0xc6e54c: tbnz            w0, #4, #0xc6e5c8
    // 0xc6e550: ldr             x2, [fp, #0x18]
    // 0xc6e554: ldr             x1, [fp, #0x10]
    // 0xc6e558: LoadField: r0 = r1->field_17
    //     0xc6e558: ldur            w0, [x1, #0x17]
    // 0xc6e55c: DecompressPointer r0
    //     0xc6e55c: add             x0, x0, HEAP, lsl #32
    // 0xc6e560: LoadField: r3 = r2->field_17
    //     0xc6e560: ldur            w3, [x2, #0x17]
    // 0xc6e564: DecompressPointer r3
    //     0xc6e564: add             x3, x3, HEAP, lsl #32
    // 0xc6e568: r4 = LoadClassIdInstr(r0)
    //     0xc6e568: ldur            x4, [x0, #-1]
    //     0xc6e56c: ubfx            x4, x4, #0xc, #0x14
    // 0xc6e570: stp             x3, x0, [SP, #-0x10]!
    // 0xc6e574: mov             x0, x4
    // 0xc6e578: mov             lr, x0
    // 0xc6e57c: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e580: blr             lr
    // 0xc6e584: add             SP, SP, #0x10
    // 0xc6e588: tbnz            w0, #4, #0xc6e5c8
    // 0xc6e58c: ldr             x1, [fp, #0x18]
    // 0xc6e590: ldr             x0, [fp, #0x10]
    // 0xc6e594: LoadField: r2 = r0->field_1b
    //     0xc6e594: ldur            w2, [x0, #0x1b]
    // 0xc6e598: DecompressPointer r2
    //     0xc6e598: add             x2, x2, HEAP, lsl #32
    // 0xc6e59c: LoadField: r0 = r1->field_1b
    //     0xc6e59c: ldur            w0, [x1, #0x1b]
    // 0xc6e5a0: DecompressPointer r0
    //     0xc6e5a0: add             x0, x0, HEAP, lsl #32
    // 0xc6e5a4: r1 = LoadClassIdInstr(r2)
    //     0xc6e5a4: ldur            x1, [x2, #-1]
    //     0xc6e5a8: ubfx            x1, x1, #0xc, #0x14
    // 0xc6e5ac: stp             x0, x2, [SP, #-0x10]!
    // 0xc6e5b0: mov             x0, x1
    // 0xc6e5b4: mov             lr, x0
    // 0xc6e5b8: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e5bc: blr             lr
    // 0xc6e5c0: add             SP, SP, #0x10
    // 0xc6e5c4: b               #0xc6e5cc
    // 0xc6e5c8: r0 = false
    //     0xc6e5c8: add             x0, NULL, #0x30  ; false
    // 0xc6e5cc: LeaveFrame
    //     0xc6e5cc: mov             SP, fp
    //     0xc6e5d0: ldp             fp, lr, [SP], #0x10
    // 0xc6e5d4: ret
    //     0xc6e5d4: ret             
    // 0xc6e5d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6e5d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6e5dc: b               #0xc6e464
  }
  _ toDBusString(/* No info */) {
    // ** addr: 0xc97504, size: 0x3e4
    // 0xc97504: EnterFrame
    //     0xc97504: stp             fp, lr, [SP, #-0x10]!
    //     0xc97508: mov             fp, SP
    // 0xc9750c: AllocStack(0x18)
    //     0xc9750c: sub             SP, SP, #0x18
    // 0xc97510: CheckStackOverflow
    //     0xc97510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc97514: cmp             SP, x16
    //     0xc97518: b.ls            #0xc978e0
    // 0xc9751c: r1 = 2
    //     0xc9751c: mov             x1, #2
    // 0xc97520: r0 = AllocateContext()
    //     0xc97520: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc97524: mov             x1, x0
    // 0xc97528: ldr             x0, [fp, #0x10]
    // 0xc9752c: stur            x1, [fp, #-8]
    // 0xc97530: StoreField: r1->field_f = r0
    //     0xc97530: stur            w0, [x1, #0xf]
    // 0xc97534: r16 = <String, String>
    //     0xc97534: ldr             x16, [PP, #0x278]  ; [pp+0x278] TypeArguments: <String, String>
    // 0xc97538: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xc9753c: stp             lr, x16, [SP, #-0x10]!
    // 0xc97540: r0 = Map._fromLiteral()
    //     0xc97540: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc97544: add             SP, SP, #0x10
    // 0xc97548: mov             x4, x0
    // 0xc9754c: ldur            x3, [fp, #-8]
    // 0xc97550: stur            x4, [fp, #-0x10]
    // 0xc97554: StoreField: r3->field_13 = r0
    //     0xc97554: stur            w0, [x3, #0x13]
    //     0xc97558: tbz             w0, #0, #0xc97574
    //     0xc9755c: ldurb           w16, [x3, #-1]
    //     0xc97560: ldurb           w17, [x0, #-1]
    //     0xc97564: and             x16, x17, x16, lsr #2
    //     0xc97568: tst             x16, HEAP, lsr #32
    //     0xc9756c: b.eq            #0xc97574
    //     0xc97570: bl              #0xd682ac
    // 0xc97574: r1 = Null
    //     0xc97574: mov             x1, NULL
    // 0xc97578: r2 = 16
    //     0xc97578: mov             x2, #0x10
    // 0xc9757c: r0 = AllocateArray()
    //     0xc9757c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc97580: r17 = Instance_DBusMessageType
    //     0xc97580: ldr             x17, [PP, #0x7750]  ; [pp+0x7750] Obj!DBusMessageType@b667d1
    // 0xc97584: StoreField: r0->field_f = r17
    //     0xc97584: stur            w17, [x0, #0xf]
    // 0xc97588: r17 = "method_call"
    //     0xc97588: add             x17, PP, #8, lsl #12  ; [pp+0x87a8] "method_call"
    //     0xc9758c: ldr             x17, [x17, #0x7a8]
    // 0xc97590: StoreField: r0->field_13 = r17
    //     0xc97590: stur            w17, [x0, #0x13]
    // 0xc97594: r17 = Instance_DBusMessageType
    //     0xc97594: ldr             x17, [PP, #0x7818]  ; [pp+0x7818] Obj!DBusMessageType@b66791
    // 0xc97598: StoreField: r0->field_17 = r17
    //     0xc97598: stur            w17, [x0, #0x17]
    // 0xc9759c: r17 = "method_return"
    //     0xc9759c: add             x17, PP, #8, lsl #12  ; [pp+0x87b0] "method_return"
    //     0xc975a0: ldr             x17, [x17, #0x7b0]
    // 0xc975a4: StoreField: r0->field_1b = r17
    //     0xc975a4: stur            w17, [x0, #0x1b]
    // 0xc975a8: r17 = Instance_DBusMessageType
    //     0xc975a8: ldr             x17, [PP, #0x7820]  ; [pp+0x7820] Obj!DBusMessageType@b66771
    // 0xc975ac: StoreField: r0->field_1f = r17
    //     0xc975ac: stur            w17, [x0, #0x1f]
    // 0xc975b0: r17 = "error"
    //     0xc975b0: ldr             x17, [PP, #0xeb8]  ; [pp+0xeb8] "error"
    // 0xc975b4: StoreField: r0->field_23 = r17
    //     0xc975b4: stur            w17, [x0, #0x23]
    // 0xc975b8: r17 = Instance_DBusMessageType
    //     0xc975b8: ldr             x17, [PP, #0x530]  ; [pp+0x530] Obj!DBusMessageType@b667b1
    // 0xc975bc: StoreField: r0->field_27 = r17
    //     0xc975bc: stur            w17, [x0, #0x27]
    // 0xc975c0: r17 = "signal"
    //     0xc975c0: ldr             x17, [PP, #0x7da0]  ; [pp+0x7da0] "signal"
    // 0xc975c4: StoreField: r0->field_2b = r17
    //     0xc975c4: stur            w17, [x0, #0x2b]
    // 0xc975c8: r16 = <DBusMessageType, String>
    //     0xc975c8: add             x16, PP, #8, lsl #12  ; [pp+0x87b8] TypeArguments: <DBusMessageType, String>
    //     0xc975cc: ldr             x16, [x16, #0x7b8]
    // 0xc975d0: stp             x0, x16, [SP, #-0x10]!
    // 0xc975d4: r0 = Map._fromLiteral()
    //     0xc975d4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc975d8: add             SP, SP, #0x10
    // 0xc975dc: stur            x0, [fp, #-0x18]
    // 0xc975e0: r16 = Instance_DBusMessageType
    //     0xc975e0: ldr             x16, [PP, #0x530]  ; [pp+0x530] Obj!DBusMessageType@b667b1
    // 0xc975e4: stp             x16, x0, [SP, #-0x10]!
    // 0xc975e8: r0 = _getValueOrData()
    //     0xc975e8: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc975ec: add             SP, SP, #0x10
    // 0xc975f0: mov             x1, x0
    // 0xc975f4: ldur            x0, [fp, #-0x18]
    // 0xc975f8: LoadField: r2 = r0->field_f
    //     0xc975f8: ldur            w2, [x0, #0xf]
    // 0xc975fc: DecompressPointer r2
    //     0xc975fc: add             x2, x2, HEAP, lsl #32
    // 0xc97600: cmp             w2, w1
    // 0xc97604: b.ne            #0xc97610
    // 0xc97608: r0 = Null
    //     0xc97608: mov             x0, NULL
    // 0xc9760c: b               #0xc97614
    // 0xc97610: mov             x0, x1
    // 0xc97614: cmp             w0, NULL
    // 0xc97618: b.ne            #0xc97624
    // 0xc9761c: r1 = ""
    //     0xc9761c: ldr             x1, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xc97620: b               #0xc97628
    // 0xc97624: mov             x1, x0
    // 0xc97628: ldr             x0, [fp, #0x10]
    // 0xc9762c: stur            x1, [fp, #-0x18]
    // 0xc97630: r16 = "type"
    //     0xc97630: ldr             x16, [PP, #0x1db8]  ; [pp+0x1db8] "type"
    // 0xc97634: SaveReg r16
    //     0xc97634: str             x16, [SP, #-8]!
    // 0xc97638: r0 = hashCode()
    //     0xc97638: bl              #0xb13a00  ; [dart:core] _OneByteString::hashCode
    // 0xc9763c: add             SP, SP, #8
    // 0xc97640: r1 = LoadInt32Instr(r0)
    //     0xc97640: sbfx            x1, x0, #1, #0x1f
    //     0xc97644: tbz             w0, #0, #0xc9764c
    //     0xc97648: ldur            x1, [x0, #7]
    // 0xc9764c: ldur            x16, [fp, #-0x10]
    // 0xc97650: r30 = "type"
    //     0xc97650: ldr             lr, [PP, #0x1db8]  ; [pp+0x1db8] "type"
    // 0xc97654: stp             lr, x16, [SP, #-0x10]!
    // 0xc97658: ldur            x16, [fp, #-0x18]
    // 0xc9765c: stp             x1, x16, [SP, #-0x10]!
    // 0xc97660: r0 = _set()
    //     0xc97660: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc97664: add             SP, SP, #0x20
    // 0xc97668: ldr             x0, [fp, #0x10]
    // 0xc9766c: LoadField: r1 = r0->field_b
    //     0xc9766c: ldur            w1, [x0, #0xb]
    // 0xc97670: DecompressPointer r1
    //     0xc97670: add             x1, x1, HEAP, lsl #32
    // 0xc97674: cmp             w1, NULL
    // 0xc97678: b.eq            #0xc976d0
    // 0xc9767c: ldur            x2, [fp, #-8]
    // 0xc97680: LoadField: r3 = r2->field_13
    //     0xc97680: ldur            w3, [x2, #0x13]
    // 0xc97684: DecompressPointer r3
    //     0xc97684: add             x3, x3, HEAP, lsl #32
    // 0xc97688: stur            x3, [fp, #-0x18]
    // 0xc9768c: LoadField: r4 = r1->field_7
    //     0xc9768c: ldur            w4, [x1, #7]
    // 0xc97690: DecompressPointer r4
    //     0xc97690: add             x4, x4, HEAP, lsl #32
    // 0xc97694: stur            x4, [fp, #-0x10]
    // 0xc97698: r16 = "sender"
    //     0xc97698: ldr             x16, [PP, #0x7640]  ; [pp+0x7640] "sender"
    // 0xc9769c: SaveReg r16
    //     0xc9769c: str             x16, [SP, #-8]!
    // 0xc976a0: r0 = hashCode()
    //     0xc976a0: bl              #0xb13a00  ; [dart:core] _OneByteString::hashCode
    // 0xc976a4: add             SP, SP, #8
    // 0xc976a8: r1 = LoadInt32Instr(r0)
    //     0xc976a8: sbfx            x1, x0, #1, #0x1f
    //     0xc976ac: tbz             w0, #0, #0xc976b4
    //     0xc976b0: ldur            x1, [x0, #7]
    // 0xc976b4: ldur            x16, [fp, #-0x18]
    // 0xc976b8: r30 = "sender"
    //     0xc976b8: ldr             lr, [PP, #0x7640]  ; [pp+0x7640] "sender"
    // 0xc976bc: stp             lr, x16, [SP, #-0x10]!
    // 0xc976c0: ldur            x16, [fp, #-0x10]
    // 0xc976c4: stp             x1, x16, [SP, #-0x10]!
    // 0xc976c8: r0 = _set()
    //     0xc976c8: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc976cc: add             SP, SP, #0x20
    // 0xc976d0: ldr             x0, [fp, #0x10]
    // 0xc976d4: LoadField: r1 = r0->field_f
    //     0xc976d4: ldur            w1, [x0, #0xf]
    // 0xc976d8: DecompressPointer r1
    //     0xc976d8: add             x1, x1, HEAP, lsl #32
    // 0xc976dc: cmp             w1, NULL
    // 0xc976e0: b.eq            #0xc97738
    // 0xc976e4: ldur            x2, [fp, #-8]
    // 0xc976e8: LoadField: r3 = r2->field_13
    //     0xc976e8: ldur            w3, [x2, #0x13]
    // 0xc976ec: DecompressPointer r3
    //     0xc976ec: add             x3, x3, HEAP, lsl #32
    // 0xc976f0: stur            x3, [fp, #-0x18]
    // 0xc976f4: LoadField: r4 = r1->field_7
    //     0xc976f4: ldur            w4, [x1, #7]
    // 0xc976f8: DecompressPointer r4
    //     0xc976f8: add             x4, x4, HEAP, lsl #32
    // 0xc976fc: stur            x4, [fp, #-0x10]
    // 0xc97700: r16 = "interface"
    //     0xc97700: ldr             x16, [PP, #0x508]  ; [pp+0x508] "interface"
    // 0xc97704: SaveReg r16
    //     0xc97704: str             x16, [SP, #-8]!
    // 0xc97708: r0 = hashCode()
    //     0xc97708: bl              #0xb13a00  ; [dart:core] _OneByteString::hashCode
    // 0xc9770c: add             SP, SP, #8
    // 0xc97710: r1 = LoadInt32Instr(r0)
    //     0xc97710: sbfx            x1, x0, #1, #0x1f
    //     0xc97714: tbz             w0, #0, #0xc9771c
    //     0xc97718: ldur            x1, [x0, #7]
    // 0xc9771c: ldur            x16, [fp, #-0x18]
    // 0xc97720: r30 = "interface"
    //     0xc97720: ldr             lr, [PP, #0x508]  ; [pp+0x508] "interface"
    // 0xc97724: stp             lr, x16, [SP, #-0x10]!
    // 0xc97728: ldur            x16, [fp, #-0x10]
    // 0xc9772c: stp             x1, x16, [SP, #-0x10]!
    // 0xc97730: r0 = _set()
    //     0xc97730: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc97734: add             SP, SP, #0x20
    // 0xc97738: ldr             x0, [fp, #0x10]
    // 0xc9773c: LoadField: r1 = r0->field_13
    //     0xc9773c: ldur            w1, [x0, #0x13]
    // 0xc97740: DecompressPointer r1
    //     0xc97740: add             x1, x1, HEAP, lsl #32
    // 0xc97744: cmp             w1, NULL
    // 0xc97748: b.eq            #0xc977a0
    // 0xc9774c: ldur            x2, [fp, #-8]
    // 0xc97750: LoadField: r3 = r2->field_13
    //     0xc97750: ldur            w3, [x2, #0x13]
    // 0xc97754: DecompressPointer r3
    //     0xc97754: add             x3, x3, HEAP, lsl #32
    // 0xc97758: stur            x3, [fp, #-0x18]
    // 0xc9775c: LoadField: r4 = r1->field_7
    //     0xc9775c: ldur            w4, [x1, #7]
    // 0xc97760: DecompressPointer r4
    //     0xc97760: add             x4, x4, HEAP, lsl #32
    // 0xc97764: stur            x4, [fp, #-0x10]
    // 0xc97768: r16 = "member"
    //     0xc97768: ldr             x16, [PP, #0x7648]  ; [pp+0x7648] "member"
    // 0xc9776c: SaveReg r16
    //     0xc9776c: str             x16, [SP, #-8]!
    // 0xc97770: r0 = hashCode()
    //     0xc97770: bl              #0xb13a00  ; [dart:core] _OneByteString::hashCode
    // 0xc97774: add             SP, SP, #8
    // 0xc97778: r1 = LoadInt32Instr(r0)
    //     0xc97778: sbfx            x1, x0, #1, #0x1f
    //     0xc9777c: tbz             w0, #0, #0xc97784
    //     0xc97780: ldur            x1, [x0, #7]
    // 0xc97784: ldur            x16, [fp, #-0x18]
    // 0xc97788: r30 = "member"
    //     0xc97788: ldr             lr, [PP, #0x7648]  ; [pp+0x7648] "member"
    // 0xc9778c: stp             lr, x16, [SP, #-0x10]!
    // 0xc97790: ldur            x16, [fp, #-0x10]
    // 0xc97794: stp             x1, x16, [SP, #-0x10]!
    // 0xc97798: r0 = _set()
    //     0xc97798: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc9779c: add             SP, SP, #0x20
    // 0xc977a0: ldr             x0, [fp, #0x10]
    // 0xc977a4: LoadField: r1 = r0->field_17
    //     0xc977a4: ldur            w1, [x0, #0x17]
    // 0xc977a8: DecompressPointer r1
    //     0xc977a8: add             x1, x1, HEAP, lsl #32
    // 0xc977ac: cmp             w1, NULL
    // 0xc977b0: b.eq            #0xc97808
    // 0xc977b4: ldur            x2, [fp, #-8]
    // 0xc977b8: LoadField: r3 = r2->field_13
    //     0xc977b8: ldur            w3, [x2, #0x13]
    // 0xc977bc: DecompressPointer r3
    //     0xc977bc: add             x3, x3, HEAP, lsl #32
    // 0xc977c0: stur            x3, [fp, #-0x18]
    // 0xc977c4: LoadField: r4 = r1->field_7
    //     0xc977c4: ldur            w4, [x1, #7]
    // 0xc977c8: DecompressPointer r4
    //     0xc977c8: add             x4, x4, HEAP, lsl #32
    // 0xc977cc: stur            x4, [fp, #-0x10]
    // 0xc977d0: r16 = "path"
    //     0xc977d0: ldr             x16, [PP, #0x518]  ; [pp+0x518] "path"
    // 0xc977d4: SaveReg r16
    //     0xc977d4: str             x16, [SP, #-8]!
    // 0xc977d8: r0 = hashCode()
    //     0xc977d8: bl              #0xb13a00  ; [dart:core] _OneByteString::hashCode
    // 0xc977dc: add             SP, SP, #8
    // 0xc977e0: r1 = LoadInt32Instr(r0)
    //     0xc977e0: sbfx            x1, x0, #1, #0x1f
    //     0xc977e4: tbz             w0, #0, #0xc977ec
    //     0xc977e8: ldur            x1, [x0, #7]
    // 0xc977ec: ldur            x16, [fp, #-0x18]
    // 0xc977f0: r30 = "path"
    //     0xc977f0: ldr             lr, [PP, #0x518]  ; [pp+0x518] "path"
    // 0xc977f4: stp             lr, x16, [SP, #-0x10]!
    // 0xc977f8: ldur            x16, [fp, #-0x10]
    // 0xc977fc: stp             x1, x16, [SP, #-0x10]!
    // 0xc97800: r0 = _set()
    //     0xc97800: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc97804: add             SP, SP, #0x20
    // 0xc97808: ldr             x0, [fp, #0x10]
    // 0xc9780c: LoadField: r1 = r0->field_1b
    //     0xc9780c: ldur            w1, [x0, #0x1b]
    // 0xc97810: DecompressPointer r1
    //     0xc97810: add             x1, x1, HEAP, lsl #32
    // 0xc97814: cmp             w1, NULL
    // 0xc97818: b.eq            #0xc97878
    // 0xc9781c: ldur            x2, [fp, #-8]
    // 0xc97820: LoadField: r0 = r2->field_13
    //     0xc97820: ldur            w0, [x2, #0x13]
    // 0xc97824: DecompressPointer r0
    //     0xc97824: add             x0, x0, HEAP, lsl #32
    // 0xc97828: stur            x0, [fp, #-0x18]
    // 0xc9782c: LoadField: r3 = r1->field_7
    //     0xc9782c: ldur            w3, [x1, #7]
    // 0xc97830: DecompressPointer r3
    //     0xc97830: add             x3, x3, HEAP, lsl #32
    // 0xc97834: stur            x3, [fp, #-0x10]
    // 0xc97838: r16 = "path_namespace"
    //     0xc97838: add             x16, PP, #8, lsl #12  ; [pp+0x87c0] "path_namespace"
    //     0xc9783c: ldr             x16, [x16, #0x7c0]
    // 0xc97840: SaveReg r16
    //     0xc97840: str             x16, [SP, #-8]!
    // 0xc97844: r0 = hashCode()
    //     0xc97844: bl              #0xb13a00  ; [dart:core] _OneByteString::hashCode
    // 0xc97848: add             SP, SP, #8
    // 0xc9784c: r1 = LoadInt32Instr(r0)
    //     0xc9784c: sbfx            x1, x0, #1, #0x1f
    //     0xc97850: tbz             w0, #0, #0xc97858
    //     0xc97854: ldur            x1, [x0, #7]
    // 0xc97858: ldur            x16, [fp, #-0x18]
    // 0xc9785c: r30 = "path_namespace"
    //     0xc9785c: add             lr, PP, #8, lsl #12  ; [pp+0x87c0] "path_namespace"
    //     0xc97860: ldr             lr, [lr, #0x7c0]
    // 0xc97864: stp             lr, x16, [SP, #-0x10]!
    // 0xc97868: ldur            x16, [fp, #-0x10]
    // 0xc9786c: stp             x1, x16, [SP, #-0x10]!
    // 0xc97870: r0 = _set()
    //     0xc97870: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc97874: add             SP, SP, #0x20
    // 0xc97878: ldur            x2, [fp, #-8]
    // 0xc9787c: LoadField: r0 = r2->field_13
    //     0xc9787c: ldur            w0, [x2, #0x13]
    // 0xc97880: DecompressPointer r0
    //     0xc97880: add             x0, x0, HEAP, lsl #32
    // 0xc97884: SaveReg r0
    //     0xc97884: str             x0, [SP, #-8]!
    // 0xc97888: r0 = keys()
    //     0xc97888: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0xc9788c: add             SP, SP, #8
    // 0xc97890: ldur            x2, [fp, #-8]
    // 0xc97894: r1 = Function '<anonymous closure>':.
    //     0xc97894: add             x1, PP, #8, lsl #12  ; [pp+0x87c8] AnonymousClosure: (0xc978e8), in [package:dbus/src/dbus_match_rule.dart] DBusMatchRule::toDBusString (0xc97504)
    //     0xc97898: ldr             x1, [x1, #0x7c8]
    // 0xc9789c: stur            x0, [fp, #-8]
    // 0xc978a0: r0 = AllocateClosure()
    //     0xc978a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc978a4: r16 = <String>
    //     0xc978a4: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xc978a8: ldur            lr, [fp, #-8]
    // 0xc978ac: stp             lr, x16, [SP, #-0x10]!
    // 0xc978b0: SaveReg r0
    //     0xc978b0: str             x0, [SP, #-8]!
    // 0xc978b4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc978b4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc978b8: r0 = map()
    //     0xc978b8: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0xc978bc: add             SP, SP, #0x18
    // 0xc978c0: r16 = ","
    //     0xc978c0: ldr             x16, [PP, #0x978]  ; [pp+0x978] ","
    // 0xc978c4: stp             x16, x0, [SP, #-0x10]!
    // 0xc978c8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc978c8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc978cc: r0 = join()
    //     0xc978cc: bl              #0x6a9d88  ; [dart:core] Iterable::join
    // 0xc978d0: add             SP, SP, #0x10
    // 0xc978d4: LeaveFrame
    //     0xc978d4: mov             SP, fp
    //     0xc978d8: ldp             fp, lr, [SP], #0x10
    // 0xc978dc: ret
    //     0xc978dc: ret             
    // 0xc978e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc978e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc978e4: b               #0xc9751c
  }
  [closure] String <anonymous closure>(dynamic, String) {
    // ** addr: 0xc978e8, size: 0x100
    // 0xc978e8: EnterFrame
    //     0xc978e8: stp             fp, lr, [SP, #-0x10]!
    //     0xc978ec: mov             fp, SP
    // 0xc978f0: AllocStack(0x20)
    //     0xc978f0: sub             SP, SP, #0x20
    // 0xc978f4: SetupParameters()
    //     0xc978f4: ldr             x0, [fp, #0x18]
    //     0xc978f8: ldur            w3, [x0, #0x17]
    //     0xc978fc: add             x3, x3, HEAP, lsl #32
    //     0xc97900: stur            x3, [fp, #-8]
    // 0xc97904: CheckStackOverflow
    //     0xc97904: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc97908: cmp             SP, x16
    //     0xc9790c: b.ls            #0xc979dc
    // 0xc97910: r1 = Null
    //     0xc97910: mov             x1, NULL
    // 0xc97914: r2 = 6
    //     0xc97914: mov             x2, #6
    // 0xc97918: r0 = AllocateArray()
    //     0xc97918: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc9791c: mov             x1, x0
    // 0xc97920: ldr             x0, [fp, #0x10]
    // 0xc97924: stur            x1, [fp, #-0x20]
    // 0xc97928: StoreField: r1->field_f = r0
    //     0xc97928: stur            w0, [x1, #0xf]
    // 0xc9792c: r17 = "="
    //     0xc9792c: ldr             x17, [PP, #0x2a8]  ; [pp+0x2a8] "="
    // 0xc97930: StoreField: r1->field_13 = r17
    //     0xc97930: stur            w17, [x1, #0x13]
    // 0xc97934: ldur            x2, [fp, #-8]
    // 0xc97938: LoadField: r3 = r2->field_f
    //     0xc97938: ldur            w3, [x2, #0xf]
    // 0xc9793c: DecompressPointer r3
    //     0xc9793c: add             x3, x3, HEAP, lsl #32
    // 0xc97940: stur            x3, [fp, #-0x18]
    // 0xc97944: LoadField: r4 = r2->field_13
    //     0xc97944: ldur            w4, [x2, #0x13]
    // 0xc97948: DecompressPointer r4
    //     0xc97948: add             x4, x4, HEAP, lsl #32
    // 0xc9794c: stur            x4, [fp, #-0x10]
    // 0xc97950: stp             x0, x4, [SP, #-0x10]!
    // 0xc97954: r0 = _getValueOrData()
    //     0xc97954: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc97958: add             SP, SP, #0x10
    // 0xc9795c: mov             x1, x0
    // 0xc97960: ldur            x0, [fp, #-0x10]
    // 0xc97964: LoadField: r2 = r0->field_f
    //     0xc97964: ldur            w2, [x0, #0xf]
    // 0xc97968: DecompressPointer r2
    //     0xc97968: add             x2, x2, HEAP, lsl #32
    // 0xc9796c: cmp             w2, w1
    // 0xc97970: b.ne            #0xc9797c
    // 0xc97974: r0 = Null
    //     0xc97974: mov             x0, NULL
    // 0xc97978: b               #0xc97980
    // 0xc9797c: mov             x0, x1
    // 0xc97980: cmp             w0, NULL
    // 0xc97984: b.eq            #0xc979e4
    // 0xc97988: ldur            x16, [fp, #-0x18]
    // 0xc9798c: stp             x0, x16, [SP, #-0x10]!
    // 0xc97990: r0 = _escapeString()
    //     0xc97990: bl              #0xc979e8  ; [package:dbus/src/dbus_match_rule.dart] DBusMatchRule::_escapeString
    // 0xc97994: add             SP, SP, #0x10
    // 0xc97998: ldur            x1, [fp, #-0x20]
    // 0xc9799c: ArrayStore: r1[2] = r0  ; List_4
    //     0xc9799c: add             x25, x1, #0x17
    //     0xc979a0: str             w0, [x25]
    //     0xc979a4: tbz             w0, #0, #0xc979c0
    //     0xc979a8: ldurb           w16, [x1, #-1]
    //     0xc979ac: ldurb           w17, [x0, #-1]
    //     0xc979b0: and             x16, x17, x16, lsr #2
    //     0xc979b4: tst             x16, HEAP, lsr #32
    //     0xc979b8: b.eq            #0xc979c0
    //     0xc979bc: bl              #0xd67e5c
    // 0xc979c0: ldur            x16, [fp, #-0x20]
    // 0xc979c4: SaveReg r16
    //     0xc979c4: str             x16, [SP, #-8]!
    // 0xc979c8: r0 = _interpolate()
    //     0xc979c8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc979cc: add             SP, SP, #8
    // 0xc979d0: LeaveFrame
    //     0xc979d0: mov             SP, fp
    //     0xc979d4: ldp             fp, lr, [SP], #0x10
    // 0xc979d8: ret
    //     0xc979d8: ret             
    // 0xc979dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc979dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc979e0: b               #0xc97910
    // 0xc979e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc979e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _escapeString(/* No info */) {
    // ** addr: 0xc979e8, size: 0x80
    // 0xc979e8: EnterFrame
    //     0xc979e8: stp             fp, lr, [SP, #-0x10]!
    //     0xc979ec: mov             fp, SP
    // 0xc979f0: AllocStack(0x8)
    //     0xc979f0: sub             SP, SP, #8
    // 0xc979f4: CheckStackOverflow
    //     0xc979f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc979f8: cmp             SP, x16
    //     0xc979fc: b.ls            #0xc97a60
    // 0xc97a00: ldr             x16, [fp, #0x10]
    // 0xc97a04: r30 = "\'"
    //     0xc97a04: ldr             lr, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xc97a08: stp             lr, x16, [SP, #-0x10]!
    // 0xc97a0c: r16 = "\'\\\'\'"
    //     0xc97a0c: add             x16, PP, #8, lsl #12  ; [pp+0x87d0] "\'\\\'\'"
    //     0xc97a10: ldr             x16, [x16, #0x7d0]
    // 0xc97a14: SaveReg r16
    //     0xc97a14: str             x16, [SP, #-8]!
    // 0xc97a18: r0 = replaceAll()
    //     0xc97a18: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0xc97a1c: add             SP, SP, #0x18
    // 0xc97a20: r1 = Null
    //     0xc97a20: mov             x1, NULL
    // 0xc97a24: r2 = 6
    //     0xc97a24: mov             x2, #6
    // 0xc97a28: stur            x0, [fp, #-8]
    // 0xc97a2c: r0 = AllocateArray()
    //     0xc97a2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc97a30: r17 = "\'"
    //     0xc97a30: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xc97a34: StoreField: r0->field_f = r17
    //     0xc97a34: stur            w17, [x0, #0xf]
    // 0xc97a38: ldur            x1, [fp, #-8]
    // 0xc97a3c: StoreField: r0->field_13 = r1
    //     0xc97a3c: stur            w1, [x0, #0x13]
    // 0xc97a40: r17 = "\'"
    //     0xc97a40: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xc97a44: StoreField: r0->field_17 = r17
    //     0xc97a44: stur            w17, [x0, #0x17]
    // 0xc97a48: SaveReg r0
    //     0xc97a48: str             x0, [SP, #-8]!
    // 0xc97a4c: r0 = _interpolate()
    //     0xc97a4c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc97a50: add             SP, SP, #8
    // 0xc97a54: LeaveFrame
    //     0xc97a54: mov             SP, fp
    //     0xc97a58: ldp             fp, lr, [SP], #0x10
    // 0xc97a5c: ret
    //     0xc97a5c: ret             
    // 0xc97a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc97a60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc97a64: b               #0xc97a00
  }
}

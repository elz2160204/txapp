// lib: , url: package:dbus/src/dbus_signal.dart

// class id: 1048852, size: 0x8
class :: {
}

// class id: 4628, size: 0x1c, field offset: 0x8
//   const constructor, 
class DBusSignal extends Object {

  [closure] DBusSignature <anonymous closure>(dynamic, DBusSignature, DBusSignature) {
    // ** addr: 0x9fef14, size: 0x3c
    // 0x9fef14: EnterFrame
    //     0x9fef14: stp             fp, lr, [SP, #-0x10]!
    //     0x9fef18: mov             fp, SP
    // 0x9fef1c: CheckStackOverflow
    //     0x9fef1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fef20: cmp             SP, x16
    //     0x9fef24: b.ls            #0x9fef48
    // 0x9fef28: ldr             x16, [fp, #0x18]
    // 0x9fef2c: ldr             lr, [fp, #0x10]
    // 0x9fef30: stp             lr, x16, [SP, #-0x10]!
    // 0x9fef34: r0 = +()
    //     0x9fef34: bl              #0x9fd3a8  ; [package:dbus/src/dbus_value.dart] DBusSignature::+
    // 0x9fef38: add             SP, SP, #0x10
    // 0x9fef3c: LeaveFrame
    //     0x9fef3c: mov             SP, fp
    //     0x9fef40: ldp             fp, lr, [SP], #0x10
    // 0x9fef44: ret
    //     0x9fef44: ret             
    // 0x9fef48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fef48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fef4c: b               #0x9fef28
  }
  get _ signature(/* No info */) {
    // ** addr: 0x9fef50, size: 0xac
    // 0x9fef50: EnterFrame
    //     0x9fef50: stp             fp, lr, [SP, #-0x10]!
    //     0x9fef54: mov             fp, SP
    // 0x9fef58: AllocStack(0x10)
    //     0x9fef58: sub             SP, SP, #0x10
    // 0x9fef5c: CheckStackOverflow
    //     0x9fef5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fef60: cmp             SP, x16
    //     0x9fef64: b.ls            #0x9feff4
    // 0x9fef68: ldr             x0, [fp, #0x10]
    // 0x9fef6c: LoadField: r3 = r0->field_17
    //     0x9fef6c: ldur            w3, [x0, #0x17]
    // 0x9fef70: DecompressPointer r3
    //     0x9fef70: add             x3, x3, HEAP, lsl #32
    // 0x9fef74: stur            x3, [fp, #-8]
    // 0x9fef78: r1 = Function '<anonymous closure>':.
    //     0x9fef78: ldr             x1, [PP, #0x4b8]  ; [pp+0x4b8] AnonymousClosure: (0x9feffc), in [package:dbus/src/dbus_signal.dart] DBusSignal::signature (0x9fef50)
    // 0x9fef7c: r2 = Null
    //     0x9fef7c: mov             x2, NULL
    // 0x9fef80: r0 = AllocateClosure()
    //     0x9fef80: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9fef84: r16 = <DBusSignature>
    //     0x9fef84: ldr             x16, [PP, #0x4c0]  ; [pp+0x4c0] TypeArguments: <DBusSignature>
    // 0x9fef88: ldur            lr, [fp, #-8]
    // 0x9fef8c: stp             lr, x16, [SP, #-0x10]!
    // 0x9fef90: SaveReg r0
    //     0x9fef90: str             x0, [SP, #-8]!
    // 0x9fef94: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9fef94: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9fef98: r0 = map()
    //     0x9fef98: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x9fef9c: add             SP, SP, #0x18
    // 0x9fefa0: stur            x0, [fp, #-8]
    // 0x9fefa4: r0 = DBusSignature()
    //     0x9fefa4: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0x9fefa8: stur            x0, [fp, #-0x10]
    // 0x9fefac: r16 = ""
    //     0x9fefac: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x9fefb0: stp             x16, x0, [SP, #-0x10]!
    // 0x9fefb4: r0 = DBusSignature()
    //     0x9fefb4: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0x9fefb8: add             SP, SP, #0x10
    // 0x9fefbc: r1 = Function '<anonymous closure>':.
    //     0x9fefbc: ldr             x1, [PP, #0x4c8]  ; [pp+0x4c8] AnonymousClosure: (0x9fef14), in [package:dbus/src/dbus_signal.dart] DBusSignal::signature (0x9fef50)
    // 0x9fefc0: r2 = Null
    //     0x9fefc0: mov             x2, NULL
    // 0x9fefc4: r0 = AllocateClosure()
    //     0x9fefc4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9fefc8: r16 = <DBusSignature>
    //     0x9fefc8: ldr             x16, [PP, #0x4c0]  ; [pp+0x4c0] TypeArguments: <DBusSignature>
    // 0x9fefcc: ldur            lr, [fp, #-8]
    // 0x9fefd0: stp             lr, x16, [SP, #-0x10]!
    // 0x9fefd4: ldur            x16, [fp, #-0x10]
    // 0x9fefd8: stp             x0, x16, [SP, #-0x10]!
    // 0x9fefdc: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x9fefdc: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x9fefe0: r0 = fold()
    //     0x9fefe0: bl              #0x9fed6c  ; [dart:_internal] ListIterable::fold
    // 0x9fefe4: add             SP, SP, #0x20
    // 0x9fefe8: LeaveFrame
    //     0x9fefe8: mov             SP, fp
    //     0x9fefec: ldp             fp, lr, [SP], #0x10
    // 0x9feff0: ret
    //     0x9feff0: ret             
    // 0x9feff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9feff4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9feff8: b               #0x9fef68
  }
  [closure] DBusSignature <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0x9feffc, size: 0x4c
    // 0x9feffc: EnterFrame
    //     0x9feffc: stp             fp, lr, [SP, #-0x10]!
    //     0x9ff000: mov             fp, SP
    // 0x9ff004: CheckStackOverflow
    //     0x9ff004: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ff008: cmp             SP, x16
    //     0x9ff00c: b.ls            #0x9ff040
    // 0x9ff010: ldr             x0, [fp, #0x10]
    // 0x9ff014: r1 = LoadClassIdInstr(r0)
    //     0x9ff014: ldur            x1, [x0, #-1]
    //     0x9ff018: ubfx            x1, x1, #0xc, #0x14
    // 0x9ff01c: SaveReg r0
    //     0x9ff01c: str             x0, [SP, #-8]!
    // 0x9ff020: mov             x0, x1
    // 0x9ff024: r0 = GDT[cid_x0 + 0x2b8]()
    //     0x9ff024: add             lr, x0, #0x2b8
    //     0x9ff028: ldr             lr, [x21, lr, lsl #3]
    //     0x9ff02c: blr             lr
    // 0x9ff030: add             SP, SP, #8
    // 0x9ff034: LeaveFrame
    //     0x9ff034: mov             SP, fp
    //     0x9ff038: ldp             fp, lr, [SP], #0x10
    // 0x9ff03c: ret
    //     0x9ff03c: ret             
    // 0x9ff040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ff040: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ff044: b               #0x9ff010
  }
  _ toString(/* No info */) {
    // ** addr: 0xacf828, size: 0xd4
    // 0xacf828: EnterFrame
    //     0xacf828: stp             fp, lr, [SP, #-0x10]!
    //     0xacf82c: mov             fp, SP
    // 0xacf830: AllocStack(0x8)
    //     0xacf830: sub             SP, SP, #8
    // 0xacf834: CheckStackOverflow
    //     0xacf834: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf838: cmp             SP, x16
    //     0xacf83c: b.ls            #0xacf8f4
    // 0xacf840: ldr             x16, [fp, #0x10]
    // 0xacf844: SaveReg r16
    //     0xacf844: str             x16, [SP, #-8]!
    // 0xacf848: r0 = runtimeType()
    //     0xacf848: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xacf84c: add             SP, SP, #8
    // 0xacf850: r1 = Null
    //     0xacf850: mov             x1, NULL
    // 0xacf854: r2 = 24
    //     0xacf854: mov             x2, #0x18
    // 0xacf858: stur            x0, [fp, #-8]
    // 0xacf85c: r0 = AllocateArray()
    //     0xacf85c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf860: mov             x1, x0
    // 0xacf864: ldur            x0, [fp, #-8]
    // 0xacf868: StoreField: r1->field_f = r0
    //     0xacf868: stur            w0, [x1, #0xf]
    // 0xacf86c: r17 = "(sender: \'"
    //     0xacf86c: ldr             x17, [PP, #0x76a8]  ; [pp+0x76a8] "(sender: \'"
    // 0xacf870: StoreField: r1->field_13 = r17
    //     0xacf870: stur            w17, [x1, #0x13]
    // 0xacf874: ldr             x0, [fp, #0x10]
    // 0xacf878: LoadField: r2 = r0->field_7
    //     0xacf878: ldur            w2, [x0, #7]
    // 0xacf87c: DecompressPointer r2
    //     0xacf87c: add             x2, x2, HEAP, lsl #32
    // 0xacf880: StoreField: r1->field_17 = r2
    //     0xacf880: stur            w2, [x1, #0x17]
    // 0xacf884: r17 = "\', path: "
    //     0xacf884: ldr             x17, [PP, #0x76b0]  ; [pp+0x76b0] "\', path: "
    // 0xacf888: StoreField: r1->field_1b = r17
    //     0xacf888: stur            w17, [x1, #0x1b]
    // 0xacf88c: LoadField: r2 = r0->field_b
    //     0xacf88c: ldur            w2, [x0, #0xb]
    // 0xacf890: DecompressPointer r2
    //     0xacf890: add             x2, x2, HEAP, lsl #32
    // 0xacf894: StoreField: r1->field_1f = r2
    //     0xacf894: stur            w2, [x1, #0x1f]
    // 0xacf898: r17 = ", interface: \'"
    //     0xacf898: ldr             x17, [PP, #0x76b8]  ; [pp+0x76b8] ", interface: \'"
    // 0xacf89c: StoreField: r1->field_23 = r17
    //     0xacf89c: stur            w17, [x1, #0x23]
    // 0xacf8a0: LoadField: r2 = r0->field_f
    //     0xacf8a0: ldur            w2, [x0, #0xf]
    // 0xacf8a4: DecompressPointer r2
    //     0xacf8a4: add             x2, x2, HEAP, lsl #32
    // 0xacf8a8: StoreField: r1->field_27 = r2
    //     0xacf8a8: stur            w2, [x1, #0x27]
    // 0xacf8ac: r17 = "\', name: \'"
    //     0xacf8ac: ldr             x17, [PP, #0x76c0]  ; [pp+0x76c0] "\', name: \'"
    // 0xacf8b0: StoreField: r1->field_2b = r17
    //     0xacf8b0: stur            w17, [x1, #0x2b]
    // 0xacf8b4: LoadField: r2 = r0->field_13
    //     0xacf8b4: ldur            w2, [x0, #0x13]
    // 0xacf8b8: DecompressPointer r2
    //     0xacf8b8: add             x2, x2, HEAP, lsl #32
    // 0xacf8bc: StoreField: r1->field_2f = r2
    //     0xacf8bc: stur            w2, [x1, #0x2f]
    // 0xacf8c0: r17 = "\', values: "
    //     0xacf8c0: ldr             x17, [PP, #0x76c8]  ; [pp+0x76c8] "\', values: "
    // 0xacf8c4: StoreField: r1->field_33 = r17
    //     0xacf8c4: stur            w17, [x1, #0x33]
    // 0xacf8c8: LoadField: r2 = r0->field_17
    //     0xacf8c8: ldur            w2, [x0, #0x17]
    // 0xacf8cc: DecompressPointer r2
    //     0xacf8cc: add             x2, x2, HEAP, lsl #32
    // 0xacf8d0: StoreField: r1->field_37 = r2
    //     0xacf8d0: stur            w2, [x1, #0x37]
    // 0xacf8d4: r17 = ")"
    //     0xacf8d4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xacf8d8: StoreField: r1->field_3b = r17
    //     0xacf8d8: stur            w17, [x1, #0x3b]
    // 0xacf8dc: SaveReg r1
    //     0xacf8dc: str             x1, [SP, #-8]!
    // 0xacf8e0: r0 = _interpolate()
    //     0xacf8e0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf8e4: add             SP, SP, #8
    // 0xacf8e8: LeaveFrame
    //     0xacf8e8: mov             SP, fp
    //     0xacf8ec: ldp             fp, lr, [SP], #0x10
    // 0xacf8f0: ret
    //     0xacf8f0: ret             
    // 0xacf8f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf8f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf8f8: b               #0xacf840
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6ddbc, size: 0x184
    // 0xc6ddbc: EnterFrame
    //     0xc6ddbc: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ddc0: mov             fp, SP
    // 0xc6ddc4: CheckStackOverflow
    //     0xc6ddc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ddc8: cmp             SP, x16
    //     0xc6ddcc: b.ls            #0xc6df38
    // 0xc6ddd0: ldr             x1, [fp, #0x10]
    // 0xc6ddd4: cmp             w1, NULL
    // 0xc6ddd8: b.ne            #0xc6ddec
    // 0xc6dddc: r0 = false
    //     0xc6dddc: add             x0, NULL, #0x30  ; false
    // 0xc6dde0: LeaveFrame
    //     0xc6dde0: mov             SP, fp
    //     0xc6dde4: ldp             fp, lr, [SP], #0x10
    // 0xc6dde8: ret
    //     0xc6dde8: ret             
    // 0xc6ddec: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6ddec: mov             x0, #0x76
    //     0xc6ddf0: tbz             w1, #0, #0xc6de00
    //     0xc6ddf4: ldur            x0, [x1, #-1]
    //     0xc6ddf8: ubfx            x0, x0, #0xc, #0x14
    //     0xc6ddfc: lsl             x0, x0, #1
    // 0xc6de00: r2 = LoadInt32Instr(r0)
    //     0xc6de00: sbfx            x2, x0, #1, #0x1f
    // 0xc6de04: r17 = 4628
    //     0xc6de04: mov             x17, #0x1214
    // 0xc6de08: cmp             x2, x17
    // 0xc6de0c: b.lt            #0xc6df28
    // 0xc6de10: r17 = 4631
    //     0xc6de10: mov             x17, #0x1217
    // 0xc6de14: cmp             x2, x17
    // 0xc6de18: b.gt            #0xc6df28
    // 0xc6de1c: ldr             x2, [fp, #0x18]
    // 0xc6de20: LoadField: r0 = r1->field_7
    //     0xc6de20: ldur            w0, [x1, #7]
    // 0xc6de24: DecompressPointer r0
    //     0xc6de24: add             x0, x0, HEAP, lsl #32
    // 0xc6de28: LoadField: r3 = r2->field_7
    //     0xc6de28: ldur            w3, [x2, #7]
    // 0xc6de2c: DecompressPointer r3
    //     0xc6de2c: add             x3, x3, HEAP, lsl #32
    // 0xc6de30: r4 = LoadClassIdInstr(r0)
    //     0xc6de30: ldur            x4, [x0, #-1]
    //     0xc6de34: ubfx            x4, x4, #0xc, #0x14
    // 0xc6de38: stp             x3, x0, [SP, #-0x10]!
    // 0xc6de3c: mov             x0, x4
    // 0xc6de40: mov             lr, x0
    // 0xc6de44: ldr             lr, [x21, lr, lsl #3]
    // 0xc6de48: blr             lr
    // 0xc6de4c: add             SP, SP, #0x10
    // 0xc6de50: tbnz            w0, #4, #0xc6df28
    // 0xc6de54: ldr             x1, [fp, #0x18]
    // 0xc6de58: ldr             x0, [fp, #0x10]
    // 0xc6de5c: LoadField: r2 = r0->field_b
    //     0xc6de5c: ldur            w2, [x0, #0xb]
    // 0xc6de60: DecompressPointer r2
    //     0xc6de60: add             x2, x2, HEAP, lsl #32
    // 0xc6de64: LoadField: r3 = r1->field_b
    //     0xc6de64: ldur            w3, [x1, #0xb]
    // 0xc6de68: DecompressPointer r3
    //     0xc6de68: add             x3, x3, HEAP, lsl #32
    // 0xc6de6c: stp             x3, x2, [SP, #-0x10]!
    // 0xc6de70: r0 = ==()
    //     0xc6de70: bl              #0xc6e9f0  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::==
    // 0xc6de74: add             SP, SP, #0x10
    // 0xc6de78: tbnz            w0, #4, #0xc6df28
    // 0xc6de7c: ldr             x2, [fp, #0x18]
    // 0xc6de80: ldr             x1, [fp, #0x10]
    // 0xc6de84: LoadField: r0 = r1->field_f
    //     0xc6de84: ldur            w0, [x1, #0xf]
    // 0xc6de88: DecompressPointer r0
    //     0xc6de88: add             x0, x0, HEAP, lsl #32
    // 0xc6de8c: LoadField: r3 = r2->field_f
    //     0xc6de8c: ldur            w3, [x2, #0xf]
    // 0xc6de90: DecompressPointer r3
    //     0xc6de90: add             x3, x3, HEAP, lsl #32
    // 0xc6de94: r4 = LoadClassIdInstr(r0)
    //     0xc6de94: ldur            x4, [x0, #-1]
    //     0xc6de98: ubfx            x4, x4, #0xc, #0x14
    // 0xc6de9c: stp             x3, x0, [SP, #-0x10]!
    // 0xc6dea0: mov             x0, x4
    // 0xc6dea4: mov             lr, x0
    // 0xc6dea8: ldr             lr, [x21, lr, lsl #3]
    // 0xc6deac: blr             lr
    // 0xc6deb0: add             SP, SP, #0x10
    // 0xc6deb4: tbnz            w0, #4, #0xc6df28
    // 0xc6deb8: ldr             x2, [fp, #0x18]
    // 0xc6debc: ldr             x1, [fp, #0x10]
    // 0xc6dec0: LoadField: r0 = r1->field_13
    //     0xc6dec0: ldur            w0, [x1, #0x13]
    // 0xc6dec4: DecompressPointer r0
    //     0xc6dec4: add             x0, x0, HEAP, lsl #32
    // 0xc6dec8: LoadField: r3 = r2->field_13
    //     0xc6dec8: ldur            w3, [x2, #0x13]
    // 0xc6decc: DecompressPointer r3
    //     0xc6decc: add             x3, x3, HEAP, lsl #32
    // 0xc6ded0: r4 = LoadClassIdInstr(r0)
    //     0xc6ded0: ldur            x4, [x0, #-1]
    //     0xc6ded4: ubfx            x4, x4, #0xc, #0x14
    // 0xc6ded8: stp             x3, x0, [SP, #-0x10]!
    // 0xc6dedc: mov             x0, x4
    // 0xc6dee0: mov             lr, x0
    // 0xc6dee4: ldr             lr, [x21, lr, lsl #3]
    // 0xc6dee8: blr             lr
    // 0xc6deec: add             SP, SP, #0x10
    // 0xc6def0: tbnz            w0, #4, #0xc6df28
    // 0xc6def4: ldr             x1, [fp, #0x18]
    // 0xc6def8: ldr             x0, [fp, #0x10]
    // 0xc6defc: LoadField: r2 = r0->field_17
    //     0xc6defc: ldur            w2, [x0, #0x17]
    // 0xc6df00: DecompressPointer r2
    //     0xc6df00: add             x2, x2, HEAP, lsl #32
    // 0xc6df04: LoadField: r0 = r1->field_17
    //     0xc6df04: ldur            w0, [x1, #0x17]
    // 0xc6df08: DecompressPointer r0
    //     0xc6df08: add             x0, x0, HEAP, lsl #32
    // 0xc6df0c: r16 = <DBusValue>
    //     0xc6df0c: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xc6df10: stp             x2, x16, [SP, #-0x10]!
    // 0xc6df14: SaveReg r0
    //     0xc6df14: str             x0, [SP, #-8]!
    // 0xc6df18: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6df18: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6df1c: r0 = _listsEqual()
    //     0xc6df1c: bl              #0xc6df40  ; [package:dbus/src/dbus_introspect.dart] ::_listsEqual
    // 0xc6df20: add             SP, SP, #0x18
    // 0xc6df24: b               #0xc6df2c
    // 0xc6df28: r0 = false
    //     0xc6df28: add             x0, NULL, #0x30  ; false
    // 0xc6df2c: LeaveFrame
    //     0xc6df2c: mov             SP, fp
    //     0xc6df30: ldp             fp, lr, [SP], #0x10
    // 0xc6df34: ret
    //     0xc6df34: ret             
    // 0xc6df38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6df38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6df3c: b               #0xc6ddd0
  }
}

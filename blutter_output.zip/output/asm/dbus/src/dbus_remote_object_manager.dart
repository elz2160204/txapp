// lib: , url: package:dbus/src/dbus_remote_object_manager.dart

// class id: 1048850, size: 0x8
class :: {

  static _ _decodeInterfacesAndProperties(/* No info */) {
    // ** addr: 0xa0e340, size: 0xa4
    // 0xa0e340: EnterFrame
    //     0xa0e340: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e344: mov             fp, SP
    // 0xa0e348: AllocStack(0x8)
    //     0xa0e348: sub             SP, SP, #8
    // 0xa0e34c: CheckStackOverflow
    //     0xa0e34c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0e350: cmp             SP, x16
    //     0xa0e354: b.ls            #0xa0e3dc
    // 0xa0e358: ldr             x0, [fp, #0x10]
    // 0xa0e35c: r2 = Null
    //     0xa0e35c: mov             x2, NULL
    // 0xa0e360: r1 = Null
    //     0xa0e360: mov             x1, NULL
    // 0xa0e364: r4 = LoadClassIdInstr(r0)
    //     0xa0e364: ldur            x4, [x0, #-1]
    //     0xa0e368: ubfx            x4, x4, #0xc, #0x14
    // 0xa0e36c: r17 = 4567
    //     0xa0e36c: mov             x17, #0x11d7
    // 0xa0e370: cmp             x4, x17
    // 0xa0e374: b.eq            #0xa0e38c
    // 0xa0e378: r8 = DBusDict
    //     0xa0e378: add             x8, PP, #0xb, lsl #12  ; [pp+0xb490] Type: DBusDict
    //     0xa0e37c: ldr             x8, [x8, #0x490]
    // 0xa0e380: r3 = Null
    //     0xa0e380: add             x3, PP, #0x21, lsl #12  ; [pp+0x21218] Null
    //     0xa0e384: ldr             x3, [x3, #0x218]
    // 0xa0e388: r0 = DefaultTypeTest()
    //     0xa0e388: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa0e38c: ldr             x0, [fp, #0x10]
    // 0xa0e390: LoadField: r3 = r0->field_f
    //     0xa0e390: ldur            w3, [x0, #0xf]
    // 0xa0e394: DecompressPointer r3
    //     0xa0e394: add             x3, x3, HEAP, lsl #32
    // 0xa0e398: stur            x3, [fp, #-8]
    // 0xa0e39c: r1 = Function '<anonymous closure>': static.
    //     0xa0e39c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21228] AnonymousClosure: static (0xa0e3e4), in [package:dbus/src/dbus_remote_object_manager.dart] ::_decodeInterfacesAndProperties (0xa0e340)
    //     0xa0e3a0: ldr             x1, [x1, #0x228]
    // 0xa0e3a4: r2 = Null
    //     0xa0e3a4: mov             x2, NULL
    // 0xa0e3a8: r0 = AllocateClosure()
    //     0xa0e3a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0e3ac: r16 = <String, Map<String, DBusValue>>
    //     0xa0e3ac: add             x16, PP, #0x21, lsl #12  ; [pp+0x21230] TypeArguments: <String, Map<String, DBusValue>>
    //     0xa0e3b0: ldr             x16, [x16, #0x230]
    // 0xa0e3b4: ldur            lr, [fp, #-8]
    // 0xa0e3b8: stp             lr, x16, [SP, #-0x10]!
    // 0xa0e3bc: SaveReg r0
    //     0xa0e3bc: str             x0, [SP, #-8]!
    // 0xa0e3c0: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xa0e3c0: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0xa0e3c4: ldr             x4, [x4, #0x4d8]
    // 0xa0e3c8: r0 = map()
    //     0xa0e3c8: bl              #0xc7ae6c  ; [dart:collection] __Map&_HashVMBase&MapMixin::map
    // 0xa0e3cc: add             SP, SP, #0x18
    // 0xa0e3d0: LeaveFrame
    //     0xa0e3d0: mov             SP, fp
    //     0xa0e3d4: ldp             fp, lr, [SP], #0x10
    // 0xa0e3d8: ret
    //     0xa0e3d8: ret             
    // 0xa0e3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0e3dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0e3e0: b               #0xa0e358
  }
  [closure] static MapEntry<String, Map<String, DBusValue>> <anonymous closure>(dynamic, DBusValue, DBusValue) {
    // ** addr: 0xa0e3e4, size: 0xa0
    // 0xa0e3e4: EnterFrame
    //     0xa0e3e4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e3e8: mov             fp, SP
    // 0xa0e3ec: AllocStack(0x10)
    //     0xa0e3ec: sub             SP, SP, #0x10
    // 0xa0e3f0: CheckStackOverflow
    //     0xa0e3f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0e3f4: cmp             SP, x16
    //     0xa0e3f8: b.ls            #0xa0e47c
    // 0xa0e3fc: ldr             x0, [fp, #0x18]
    // 0xa0e400: r2 = Null
    //     0xa0e400: mov             x2, NULL
    // 0xa0e404: r1 = Null
    //     0xa0e404: mov             x1, NULL
    // 0xa0e408: r4 = LoadClassIdInstr(r0)
    //     0xa0e408: ldur            x4, [x0, #-1]
    //     0xa0e40c: ubfx            x4, x4, #0xc, #0x14
    // 0xa0e410: r17 = -4573
    //     0xa0e410: mov             x17, #-0x11dd
    // 0xa0e414: add             x4, x4, x17
    // 0xa0e418: cmp             x4, #1
    // 0xa0e41c: b.ls            #0xa0e430
    // 0xa0e420: r8 = DBusString
    //     0xa0e420: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa0e424: r3 = Null
    //     0xa0e424: add             x3, PP, #0x21, lsl #12  ; [pp+0x21238] Null
    //     0xa0e428: ldr             x3, [x3, #0x238]
    // 0xa0e42c: r0 = DefaultTypeTest()
    //     0xa0e42c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa0e430: ldr             x0, [fp, #0x18]
    // 0xa0e434: LoadField: r1 = r0->field_7
    //     0xa0e434: ldur            w1, [x0, #7]
    // 0xa0e438: DecompressPointer r1
    //     0xa0e438: add             x1, x1, HEAP, lsl #32
    // 0xa0e43c: stur            x1, [fp, #-8]
    // 0xa0e440: ldr             x16, [fp, #0x10]
    // 0xa0e444: SaveReg r16
    //     0xa0e444: str             x16, [SP, #-8]!
    // 0xa0e448: r0 = asStringVariantDict()
    //     0xa0e448: bl              #0xa0e484  ; [package:dbus/src/dbus_value.dart] DBusValue::asStringVariantDict
    // 0xa0e44c: add             SP, SP, #8
    // 0xa0e450: r1 = <String, Map<String, DBusValue>>
    //     0xa0e450: add             x1, PP, #0x21, lsl #12  ; [pp+0x21230] TypeArguments: <String, Map<String, DBusValue>>
    //     0xa0e454: ldr             x1, [x1, #0x230]
    // 0xa0e458: stur            x0, [fp, #-0x10]
    // 0xa0e45c: r0 = MapEntry()
    //     0xa0e45c: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xa0e460: ldur            x1, [fp, #-8]
    // 0xa0e464: StoreField: r0->field_b = r1
    //     0xa0e464: stur            w1, [x0, #0xb]
    // 0xa0e468: ldur            x1, [fp, #-0x10]
    // 0xa0e46c: StoreField: r0->field_f = r1
    //     0xa0e46c: stur            w1, [x0, #0xf]
    // 0xa0e470: LeaveFrame
    //     0xa0e470: mov             SP, fp
    //     0xa0e474: ldp             fp, lr, [SP], #0x10
    // 0xa0e478: ret
    //     0xa0e478: ret             
    // 0xa0e47c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0e47c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0e480: b               #0xa0e3fc
  }
}

// class id: 4587, size: 0x1c, field offset: 0x18
class DBusRemoteObjectManager extends DBusRemoteObject {

  late final Stream<DBusSignal> signals; // offset: 0x18

  _ getManagedObjects(/* No info */) async {
    // ** addr: 0x9fe1d4, size: 0x164
    // 0x9fe1d4: EnterFrame
    //     0x9fe1d4: stp             fp, lr, [SP, #-0x10]!
    //     0x9fe1d8: mov             fp, SP
    // 0x9fe1dc: AllocStack(0x20)
    //     0x9fe1dc: sub             SP, SP, #0x20
    // 0x9fe1e0: SetupParameters(DBusRemoteObjectManager this /* r1, fp-0x10 */)
    //     0x9fe1e0: stur            NULL, [fp, #-8]
    //     0x9fe1e4: mov             x0, #0
    //     0x9fe1e8: add             x1, fp, w0, sxtw #2
    //     0x9fe1ec: ldr             x1, [x1, #0x10]
    //     0x9fe1f0: stur            x1, [fp, #-0x10]
    // 0x9fe1f4: CheckStackOverflow
    //     0x9fe1f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fe1f8: cmp             SP, x16
    //     0x9fe1fc: b.ls            #0x9fe330
    // 0x9fe200: InitAsync() -> Future<Map<DBusObjectPath, Map<String, Map<String, DBusValue>>>>
    //     0x9fe200: add             x0, PP, #0x21, lsl #12  ; [pp+0x21248] TypeArguments: <Map<DBusObjectPath, Map<String, Map<String, DBusValue>>>>
    //     0x9fe204: ldr             x0, [x0, #0x248]
    //     0x9fe208: bl              #0x4b92e4
    // 0x9fe20c: ldur            x0, [fp, #-0x10]
    // 0x9fe210: LoadField: r1 = r0->field_7
    //     0x9fe210: ldur            w1, [x0, #7]
    // 0x9fe214: DecompressPointer r1
    //     0x9fe214: add             x1, x1, HEAP, lsl #32
    // 0x9fe218: stur            x1, [fp, #-0x20]
    // 0x9fe21c: LoadField: r2 = r0->field_f
    //     0x9fe21c: ldur            w2, [x0, #0xf]
    // 0x9fe220: DecompressPointer r2
    //     0x9fe220: add             x2, x2, HEAP, lsl #32
    // 0x9fe224: stur            x2, [fp, #-0x18]
    // 0x9fe228: r0 = DBusSignature()
    //     0x9fe228: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0x9fe22c: stur            x0, [fp, #-0x10]
    // 0x9fe230: r16 = "a{oa{sa{sv}}}"
    //     0x9fe230: add             x16, PP, #0x21, lsl #12  ; [pp+0x21250] "a{oa{sa{sv}}}"
    //     0x9fe234: ldr             x16, [x16, #0x250]
    // 0x9fe238: stp             x16, x0, [SP, #-0x10]!
    // 0x9fe23c: r0 = DBusSignature()
    //     0x9fe23c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0x9fe240: add             SP, SP, #0x10
    // 0x9fe244: ldur            x16, [fp, #-0x20]
    // 0x9fe248: r30 = "org.freedesktop.NetworkManager"
    //     0x9fe248: ldr             lr, [PP, #0x3a0]  ; [pp+0x3a0] "org.freedesktop.NetworkManager"
    // 0x9fe24c: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe250: r16 = "org.freedesktop.DBus.ObjectManager"
    //     0x9fe250: ldr             x16, [PP, #0x3c8]  ; [pp+0x3c8] "org.freedesktop.DBus.ObjectManager"
    // 0x9fe254: r30 = "GetManagedObjects"
    //     0x9fe254: add             lr, PP, #0x21, lsl #12  ; [pp+0x21258] "GetManagedObjects"
    //     0x9fe258: ldr             lr, [lr, #0x258]
    // 0x9fe25c: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe260: ldur            x16, [fp, #-0x18]
    // 0x9fe264: ldur            lr, [fp, #-0x10]
    // 0x9fe268: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe26c: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0x9fe26c: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0x9fe270: r0 = callMethod()
    //     0x9fe270: bl              #0x9fe338  ; [package:dbus/src/dbus_client.dart] DBusClient::callMethod
    // 0x9fe274: add             SP, SP, #0x30
    // 0x9fe278: mov             x1, x0
    // 0x9fe27c: stur            x1, [fp, #-0x10]
    // 0x9fe280: r0 = Await()
    //     0x9fe280: bl              #0x4b8e6c  ; AwaitStub
    // 0x9fe284: LoadField: r1 = r0->field_7
    //     0x9fe284: ldur            w1, [x0, #7]
    // 0x9fe288: DecompressPointer r1
    //     0x9fe288: add             x1, x1, HEAP, lsl #32
    // 0x9fe28c: r0 = LoadClassIdInstr(r1)
    //     0x9fe28c: ldur            x0, [x1, #-1]
    //     0x9fe290: ubfx            x0, x0, #0xc, #0x14
    // 0x9fe294: stp             xzr, x1, [SP, #-0x10]!
    // 0x9fe298: r0 = GDT[cid_x0 + -0xd83]()
    //     0x9fe298: sub             lr, x0, #0xd83
    //     0x9fe29c: ldr             lr, [x21, lr, lsl #3]
    //     0x9fe2a0: blr             lr
    // 0x9fe2a4: add             SP, SP, #0x10
    // 0x9fe2a8: mov             x3, x0
    // 0x9fe2ac: r2 = Null
    //     0x9fe2ac: mov             x2, NULL
    // 0x9fe2b0: r1 = Null
    //     0x9fe2b0: mov             x1, NULL
    // 0x9fe2b4: stur            x3, [fp, #-0x10]
    // 0x9fe2b8: r4 = 59
    //     0x9fe2b8: mov             x4, #0x3b
    // 0x9fe2bc: branchIfSmi(r0, 0x9fe2c8)
    //     0x9fe2bc: tbz             w0, #0, #0x9fe2c8
    // 0x9fe2c0: r4 = LoadClassIdInstr(r0)
    //     0x9fe2c0: ldur            x4, [x0, #-1]
    //     0x9fe2c4: ubfx            x4, x4, #0xc, #0x14
    // 0x9fe2c8: r17 = 4567
    //     0x9fe2c8: mov             x17, #0x11d7
    // 0x9fe2cc: cmp             x4, x17
    // 0x9fe2d0: b.eq            #0x9fe2e8
    // 0x9fe2d4: r8 = DBusDict
    //     0x9fe2d4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb490] Type: DBusDict
    //     0x9fe2d8: ldr             x8, [x8, #0x490]
    // 0x9fe2dc: r3 = Null
    //     0x9fe2dc: add             x3, PP, #0x21, lsl #12  ; [pp+0x21260] Null
    //     0x9fe2e0: ldr             x3, [x3, #0x260]
    // 0x9fe2e4: r0 = DefaultTypeTest()
    //     0x9fe2e4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9fe2e8: ldur            x0, [fp, #-0x10]
    // 0x9fe2ec: LoadField: r3 = r0->field_f
    //     0x9fe2ec: ldur            w3, [x0, #0xf]
    // 0x9fe2f0: DecompressPointer r3
    //     0x9fe2f0: add             x3, x3, HEAP, lsl #32
    // 0x9fe2f4: stur            x3, [fp, #-0x18]
    // 0x9fe2f8: r1 = Function '<anonymous closure>':.
    //     0x9fe2f8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21270] AnonymousClosure: (0xa0e2b4), of [package:dbus/src/dbus_remote_object_manager.dart] DBusRemoteObjectManager
    //     0x9fe2fc: ldr             x1, [x1, #0x270]
    // 0x9fe300: r2 = Null
    //     0x9fe300: mov             x2, NULL
    // 0x9fe304: r0 = AllocateClosure()
    //     0x9fe304: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9fe308: r16 = <DBusObjectPath, Map<String, Map<String, DBusValue>>>
    //     0x9fe308: add             x16, PP, #0x21, lsl #12  ; [pp+0x21278] TypeArguments: <DBusObjectPath, Map<String, Map<String, DBusValue>>>
    //     0x9fe30c: ldr             x16, [x16, #0x278]
    // 0x9fe310: ldur            lr, [fp, #-0x18]
    // 0x9fe314: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe318: SaveReg r0
    //     0x9fe318: str             x0, [SP, #-8]!
    // 0x9fe31c: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x9fe31c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0x9fe320: ldr             x4, [x4, #0x4d8]
    // 0x9fe324: r0 = map()
    //     0x9fe324: bl              #0xc7ae6c  ; [dart:collection] __Map&_HashVMBase&MapMixin::map
    // 0x9fe328: add             SP, SP, #0x18
    // 0x9fe32c: r0 = ReturnAsync()
    //     0x9fe32c: b               #0x501858  ; ReturnAsyncStub
    // 0x9fe330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fe330: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fe334: b               #0x9fe200
  }
  [closure] MapEntry<DBusObjectPath, Map<String, Map<String, DBusValue>>> <anonymous closure>(dynamic, DBusValue, DBusValue) {
    // ** addr: 0xa0e2b4, size: 0x8c
    // 0xa0e2b4: EnterFrame
    //     0xa0e2b4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e2b8: mov             fp, SP
    // 0xa0e2bc: AllocStack(0x8)
    //     0xa0e2bc: sub             SP, SP, #8
    // 0xa0e2c0: CheckStackOverflow
    //     0xa0e2c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0e2c4: cmp             SP, x16
    //     0xa0e2c8: b.ls            #0xa0e338
    // 0xa0e2cc: ldr             x0, [fp, #0x18]
    // 0xa0e2d0: r2 = Null
    //     0xa0e2d0: mov             x2, NULL
    // 0xa0e2d4: r1 = Null
    //     0xa0e2d4: mov             x1, NULL
    // 0xa0e2d8: r4 = LoadClassIdInstr(r0)
    //     0xa0e2d8: ldur            x4, [x0, #-1]
    //     0xa0e2dc: ubfx            x4, x4, #0xc, #0x14
    // 0xa0e2e0: r17 = 4574
    //     0xa0e2e0: mov             x17, #0x11de
    // 0xa0e2e4: cmp             x4, x17
    // 0xa0e2e8: b.eq            #0xa0e2fc
    // 0xa0e2ec: r8 = DBusObjectPath
    //     0xa0e2ec: ldr             x8, [PP, #0x7688]  ; [pp+0x7688] Type: DBusObjectPath
    // 0xa0e2f0: r3 = Null
    //     0xa0e2f0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21280] Null
    //     0xa0e2f4: ldr             x3, [x3, #0x280]
    // 0xa0e2f8: r0 = DBusObjectPath()
    //     0xa0e2f8: bl              #0x9fcd54  ; IsType_DBusObjectPath_Stub
    // 0xa0e2fc: ldr             x16, [fp, #0x10]
    // 0xa0e300: SaveReg r16
    //     0xa0e300: str             x16, [SP, #-8]!
    // 0xa0e304: r0 = _decodeInterfacesAndProperties()
    //     0xa0e304: bl              #0xa0e340  ; [package:dbus/src/dbus_remote_object_manager.dart] ::_decodeInterfacesAndProperties
    // 0xa0e308: add             SP, SP, #8
    // 0xa0e30c: r1 = <DBusObjectPath, Map<String, Map<String, DBusValue>>>
    //     0xa0e30c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21278] TypeArguments: <DBusObjectPath, Map<String, Map<String, DBusValue>>>
    //     0xa0e310: ldr             x1, [x1, #0x278]
    // 0xa0e314: stur            x0, [fp, #-8]
    // 0xa0e318: r0 = MapEntry()
    //     0xa0e318: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xa0e31c: ldr             x1, [fp, #0x18]
    // 0xa0e320: StoreField: r0->field_b = r1
    //     0xa0e320: stur            w1, [x0, #0xb]
    // 0xa0e324: ldur            x1, [fp, #-8]
    // 0xa0e328: StoreField: r0->field_f = r1
    //     0xa0e328: stur            w1, [x0, #0xf]
    // 0xa0e32c: LeaveFrame
    //     0xa0e32c: mov             SP, fp
    //     0xa0e330: ldp             fp, lr, [SP], #0x10
    // 0xa0e334: ret
    //     0xa0e334: ret             
    // 0xa0e338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0e338: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0e33c: b               #0xa0e2cc
  }
  _ toString(/* No info */) {
    // ** addr: 0xad1160, size: 0x84
    // 0xad1160: EnterFrame
    //     0xad1160: stp             fp, lr, [SP, #-0x10]!
    //     0xad1164: mov             fp, SP
    // 0xad1168: CheckStackOverflow
    //     0xad1168: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad116c: cmp             SP, x16
    //     0xad1170: b.ls            #0xad11dc
    // 0xad1174: r1 = Null
    //     0xad1174: mov             x1, NULL
    // 0xad1178: r2 = 12
    //     0xad1178: mov             x2, #0xc
    // 0xad117c: r0 = AllocateArray()
    //     0xad117c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1180: r17 = DBusRemoteObjectManager
    //     0xad1180: ldr             x17, [PP, #0x76d8]  ; [pp+0x76d8] Type: DBusRemoteObjectManager
    // 0xad1184: StoreField: r0->field_f = r17
    //     0xad1184: stur            w17, [x0, #0xf]
    // 0xad1188: r17 = "(name: \'"
    //     0xad1188: ldr             x17, [PP, #0x76e0]  ; [pp+0x76e0] "(name: \'"
    // 0xad118c: StoreField: r0->field_13 = r17
    //     0xad118c: stur            w17, [x0, #0x13]
    // 0xad1190: ldr             x1, [fp, #0x10]
    // 0xad1194: LoadField: r2 = r1->field_b
    //     0xad1194: ldur            w2, [x1, #0xb]
    // 0xad1198: DecompressPointer r2
    //     0xad1198: add             x2, x2, HEAP, lsl #32
    // 0xad119c: StoreField: r0->field_17 = r2
    //     0xad119c: stur            w2, [x0, #0x17]
    // 0xad11a0: r17 = "\', path: \'"
    //     0xad11a0: ldr             x17, [PP, #0x76e8]  ; [pp+0x76e8] "\', path: \'"
    // 0xad11a4: StoreField: r0->field_1b = r17
    //     0xad11a4: stur            w17, [x0, #0x1b]
    // 0xad11a8: LoadField: r2 = r1->field_f
    //     0xad11a8: ldur            w2, [x1, #0xf]
    // 0xad11ac: DecompressPointer r2
    //     0xad11ac: add             x2, x2, HEAP, lsl #32
    // 0xad11b0: LoadField: r1 = r2->field_7
    //     0xad11b0: ldur            w1, [x2, #7]
    // 0xad11b4: DecompressPointer r1
    //     0xad11b4: add             x1, x1, HEAP, lsl #32
    // 0xad11b8: StoreField: r0->field_1f = r1
    //     0xad11b8: stur            w1, [x0, #0x1f]
    // 0xad11bc: r17 = "\')"
    //     0xad11bc: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xad11c0: StoreField: r0->field_23 = r17
    //     0xad11c0: stur            w17, [x0, #0x23]
    // 0xad11c4: SaveReg r0
    //     0xad11c4: str             x0, [SP, #-8]!
    // 0xad11c8: r0 = _interpolate()
    //     0xad11c8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad11cc: add             SP, SP, #8
    // 0xad11d0: LeaveFrame
    //     0xad11d0: mov             SP, fp
    //     0xad11d4: ldp             fp, lr, [SP], #0x10
    // 0xad11d8: ret
    //     0xad11d8: ret             
    // 0xad11dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad11dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad11e0: b               #0xad1174
  }
  _ DBusRemoteObjectManager(/* No info */) {
    // ** addr: 0xd6e5e0, size: 0x104
    // 0xd6e5e0: EnterFrame
    //     0xd6e5e0: stp             fp, lr, [SP, #-0x10]!
    //     0xd6e5e4: mov             fp, SP
    // 0xd6e5e8: AllocStack(0x8)
    //     0xd6e5e8: sub             SP, SP, #8
    // 0xd6e5ec: r0 = Sentinel
    //     0xd6e5ec: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd6e5f0: CheckStackOverflow
    //     0xd6e5f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6e5f4: cmp             SP, x16
    //     0xd6e5f8: b.ls            #0xd6e6dc
    // 0xd6e5fc: ldr             x1, [fp, #0x20]
    // 0xd6e600: StoreField: r1->field_17 = r0
    //     0xd6e600: stur            w0, [x1, #0x17]
    // 0xd6e604: ldr             x16, [fp, #0x18]
    // 0xd6e608: stp             x16, x1, [SP, #-0x10]!
    // 0xd6e60c: ldr             x16, [fp, #0x10]
    // 0xd6e610: SaveReg r16
    //     0xd6e610: str             x16, [SP, #-8]!
    // 0xd6e614: r0 = DBusRemoteObject()
    //     0xd6e614: bl              #0xa0e884  ; [package:dbus/src/dbus_remote_object.dart] DBusRemoteObject::DBusRemoteObject
    // 0xd6e618: add             SP, SP, #0x18
    // 0xd6e61c: r1 = <DBusSignal>
    //     0xd6e61c: ldr             x1, [PP, #0x398]  ; [pp+0x398] TypeArguments: <DBusSignal>
    // 0xd6e620: r0 = DBusSignalStream()
    //     0xd6e620: bl              #0xa03060  ; AllocateDBusSignalStreamStub -> DBusSignalStream (size=0x1c)
    // 0xd6e624: stur            x0, [fp, #-8]
    // 0xd6e628: ldr             x16, [fp, #0x18]
    // 0xd6e62c: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e630: r16 = "org.freedesktop.NetworkManager"
    //     0xd6e630: ldr             x16, [PP, #0x3a0]  ; [pp+0x3a0] "org.freedesktop.NetworkManager"
    // 0xd6e634: ldr             lr, [fp, #0x10]
    // 0xd6e638: stp             lr, x16, [SP, #-0x10]!
    // 0xd6e63c: r4 = const [0, 0x4, 0x4, 0x3, pathNamespace, 0x3, null]
    //     0xd6e63c: ldr             x4, [PP, #0x3a8]  ; [pp+0x3a8] List(7) [0, 0x4, 0x4, 0x3, "pathNamespace", 0x3, Null]
    // 0xd6e640: r0 = DBusSignalStream()
    //     0xd6e640: bl              #0xa02c18  ; [package:dbus/src/dbus_client.dart] DBusSignalStream::DBusSignalStream
    // 0xd6e644: add             SP, SP, #0x20
    // 0xd6e648: r1 = Function '<anonymous closure>':.
    //     0xd6e648: ldr             x1, [PP, #0x3b0]  ; [pp+0x3b0] AnonymousClosure: (0xd6e6e4), in [package:dbus/src/dbus_remote_object_manager.dart] DBusRemoteObjectManager::DBusRemoteObjectManager (0xd6e5e0)
    // 0xd6e64c: r2 = Null
    //     0xd6e64c: mov             x2, NULL
    // 0xd6e650: r0 = AllocateClosure()
    //     0xd6e650: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xd6e654: r16 = <DBusSignal>
    //     0xd6e654: ldr             x16, [PP, #0x398]  ; [pp+0x398] TypeArguments: <DBusSignal>
    // 0xd6e658: ldur            lr, [fp, #-8]
    // 0xd6e65c: stp             lr, x16, [SP, #-0x10]!
    // 0xd6e660: SaveReg r0
    //     0xd6e660: str             x0, [SP, #-8]!
    // 0xd6e664: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd6e664: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd6e668: r0 = map()
    //     0xd6e668: bl              #0x5b31c8  ; [dart:async] Stream::map
    // 0xd6e66c: add             SP, SP, #0x18
    // 0xd6e670: mov             x1, x0
    // 0xd6e674: ldr             x0, [fp, #0x20]
    // 0xd6e678: stur            x1, [fp, #-8]
    // 0xd6e67c: LoadField: r2 = r0->field_17
    //     0xd6e67c: ldur            w2, [x0, #0x17]
    // 0xd6e680: DecompressPointer r2
    //     0xd6e680: add             x2, x2, HEAP, lsl #32
    // 0xd6e684: r16 = Sentinel
    //     0xd6e684: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd6e688: cmp             w2, w16
    // 0xd6e68c: b.ne            #0xd6e698
    // 0xd6e690: mov             x1, x0
    // 0xd6e694: b               #0xd6e6ac
    // 0xd6e698: r16 = "signals"
    //     0xd6e698: ldr             x16, [PP, #0x3c0]  ; [pp+0x3c0] "signals"
    // 0xd6e69c: SaveReg r16
    //     0xd6e69c: str             x16, [SP, #-8]!
    // 0xd6e6a0: r0 = _throwFieldAlreadyInitialized()
    //     0xd6e6a0: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xd6e6a4: add             SP, SP, #8
    // 0xd6e6a8: ldr             x1, [fp, #0x20]
    // 0xd6e6ac: ldur            x0, [fp, #-8]
    // 0xd6e6b0: StoreField: r1->field_17 = r0
    //     0xd6e6b0: stur            w0, [x1, #0x17]
    //     0xd6e6b4: ldurb           w16, [x1, #-1]
    //     0xd6e6b8: ldurb           w17, [x0, #-1]
    //     0xd6e6bc: and             x16, x17, x16, lsr #2
    //     0xd6e6c0: tst             x16, HEAP, lsr #32
    //     0xd6e6c4: b.eq            #0xd6e6cc
    //     0xd6e6c8: bl              #0xd6826c
    // 0xd6e6cc: r0 = Null
    //     0xd6e6cc: mov             x0, NULL
    // 0xd6e6d0: LeaveFrame
    //     0xd6e6d0: mov             SP, fp
    //     0xd6e6d4: ldp             fp, lr, [SP], #0x10
    // 0xd6e6d8: ret
    //     0xd6e6d8: ret             
    // 0xd6e6dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6e6dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6e6e0: b               #0xd6e5fc
  }
  [closure] DBusSignal <anonymous closure>(dynamic, DBusSignal) {
    // ** addr: 0xd6e6e4, size: 0x298
    // 0xd6e6e4: EnterFrame
    //     0xd6e6e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd6e6e8: mov             fp, SP
    // 0xd6e6ec: AllocStack(0x18)
    //     0xd6e6ec: sub             SP, SP, #0x18
    // 0xd6e6f0: CheckStackOverflow
    //     0xd6e6f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6e6f4: cmp             SP, x16
    //     0xd6e6f8: b.ls            #0xd6e974
    // 0xd6e6fc: ldr             x1, [fp, #0x10]
    // 0xd6e700: LoadField: r2 = r1->field_f
    //     0xd6e700: ldur            w2, [x1, #0xf]
    // 0xd6e704: DecompressPointer r2
    //     0xd6e704: add             x2, x2, HEAP, lsl #32
    // 0xd6e708: stur            x2, [fp, #-8]
    // 0xd6e70c: r0 = LoadClassIdInstr(r2)
    //     0xd6e70c: ldur            x0, [x2, #-1]
    //     0xd6e710: ubfx            x0, x0, #0xc, #0x14
    // 0xd6e714: r16 = "org.freedesktop.DBus.ObjectManager"
    //     0xd6e714: ldr             x16, [PP, #0x3c8]  ; [pp+0x3c8] "org.freedesktop.DBus.ObjectManager"
    // 0xd6e718: stp             x16, x2, [SP, #-0x10]!
    // 0xd6e71c: mov             lr, x0
    // 0xd6e720: ldr             lr, [x21, lr, lsl #3]
    // 0xd6e724: blr             lr
    // 0xd6e728: add             SP, SP, #0x10
    // 0xd6e72c: tbnz            w0, #4, #0xd6e7d0
    // 0xd6e730: ldr             x1, [fp, #0x10]
    // 0xd6e734: LoadField: r0 = r1->field_13
    //     0xd6e734: ldur            w0, [x1, #0x13]
    // 0xd6e738: DecompressPointer r0
    //     0xd6e738: add             x0, x0, HEAP, lsl #32
    // 0xd6e73c: r2 = LoadClassIdInstr(r0)
    //     0xd6e73c: ldur            x2, [x0, #-1]
    //     0xd6e740: ubfx            x2, x2, #0xc, #0x14
    // 0xd6e744: r16 = "InterfacesAdded"
    //     0xd6e744: ldr             x16, [PP, #0x3d0]  ; [pp+0x3d0] "InterfacesAdded"
    // 0xd6e748: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e74c: mov             x0, x2
    // 0xd6e750: mov             lr, x0
    // 0xd6e754: ldr             lr, [x21, lr, lsl #3]
    // 0xd6e758: blr             lr
    // 0xd6e75c: add             SP, SP, #0x10
    // 0xd6e760: tbnz            w0, #4, #0xd6e7d0
    // 0xd6e764: ldr             x16, [fp, #0x10]
    // 0xd6e768: SaveReg r16
    //     0xd6e768: str             x16, [SP, #-8]!
    // 0xd6e76c: r0 = signature()
    //     0xd6e76c: bl              #0x9fef50  ; [package:dbus/src/dbus_signal.dart] DBusSignal::signature
    // 0xd6e770: add             SP, SP, #8
    // 0xd6e774: stur            x0, [fp, #-0x10]
    // 0xd6e778: r0 = DBusSignature()
    //     0xd6e778: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xd6e77c: stur            x0, [fp, #-0x18]
    // 0xd6e780: r16 = "oa{sa{sv}}"
    //     0xd6e780: ldr             x16, [PP, #0x3d8]  ; [pp+0x3d8] "oa{sa{sv}}"
    // 0xd6e784: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e788: r0 = DBusSignature()
    //     0xd6e788: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xd6e78c: add             SP, SP, #0x10
    // 0xd6e790: ldur            x16, [fp, #-0x10]
    // 0xd6e794: ldur            lr, [fp, #-0x18]
    // 0xd6e798: stp             lr, x16, [SP, #-0x10]!
    // 0xd6e79c: r0 = ==()
    //     0xd6e79c: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0xd6e7a0: add             SP, SP, #0x10
    // 0xd6e7a4: tbnz            w0, #4, #0xd6e7d0
    // 0xd6e7a8: r0 = DBusObjectManagerInterfacesAddedSignal()
    //     0xd6e7a8: bl              #0xd6e988  ; AllocateDBusObjectManagerInterfacesAddedSignalStub -> DBusObjectManagerInterfacesAddedSignal (size=0x1c)
    // 0xd6e7ac: stur            x0, [fp, #-0x10]
    // 0xd6e7b0: ldr             x16, [fp, #0x10]
    // 0xd6e7b4: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e7b8: r0 = DBusPropertiesChangedSignal()
    //     0xd6e7b8: bl              #0xa0eae8  ; [package:dbus/src/dbus_remote_object.dart] DBusPropertiesChangedSignal::DBusPropertiesChangedSignal
    // 0xd6e7bc: add             SP, SP, #0x10
    // 0xd6e7c0: ldur            x0, [fp, #-0x10]
    // 0xd6e7c4: LeaveFrame
    //     0xd6e7c4: mov             SP, fp
    //     0xd6e7c8: ldp             fp, lr, [SP], #0x10
    // 0xd6e7cc: ret
    //     0xd6e7cc: ret             
    // 0xd6e7d0: ldur            x1, [fp, #-8]
    // 0xd6e7d4: r0 = LoadClassIdInstr(r1)
    //     0xd6e7d4: ldur            x0, [x1, #-1]
    //     0xd6e7d8: ubfx            x0, x0, #0xc, #0x14
    // 0xd6e7dc: r16 = "org.freedesktop.DBus.ObjectManager"
    //     0xd6e7dc: ldr             x16, [PP, #0x3c8]  ; [pp+0x3c8] "org.freedesktop.DBus.ObjectManager"
    // 0xd6e7e0: stp             x16, x1, [SP, #-0x10]!
    // 0xd6e7e4: mov             lr, x0
    // 0xd6e7e8: ldr             lr, [x21, lr, lsl #3]
    // 0xd6e7ec: blr             lr
    // 0xd6e7f0: add             SP, SP, #0x10
    // 0xd6e7f4: tbnz            w0, #4, #0xd6e898
    // 0xd6e7f8: ldr             x1, [fp, #0x10]
    // 0xd6e7fc: LoadField: r0 = r1->field_13
    //     0xd6e7fc: ldur            w0, [x1, #0x13]
    // 0xd6e800: DecompressPointer r0
    //     0xd6e800: add             x0, x0, HEAP, lsl #32
    // 0xd6e804: r2 = LoadClassIdInstr(r0)
    //     0xd6e804: ldur            x2, [x0, #-1]
    //     0xd6e808: ubfx            x2, x2, #0xc, #0x14
    // 0xd6e80c: r16 = "InterfacesRemoved"
    //     0xd6e80c: ldr             x16, [PP, #0x3e0]  ; [pp+0x3e0] "InterfacesRemoved"
    // 0xd6e810: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e814: mov             x0, x2
    // 0xd6e818: mov             lr, x0
    // 0xd6e81c: ldr             lr, [x21, lr, lsl #3]
    // 0xd6e820: blr             lr
    // 0xd6e824: add             SP, SP, #0x10
    // 0xd6e828: tbnz            w0, #4, #0xd6e898
    // 0xd6e82c: ldr             x16, [fp, #0x10]
    // 0xd6e830: SaveReg r16
    //     0xd6e830: str             x16, [SP, #-8]!
    // 0xd6e834: r0 = signature()
    //     0xd6e834: bl              #0x9fef50  ; [package:dbus/src/dbus_signal.dart] DBusSignal::signature
    // 0xd6e838: add             SP, SP, #8
    // 0xd6e83c: stur            x0, [fp, #-0x10]
    // 0xd6e840: r0 = DBusSignature()
    //     0xd6e840: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xd6e844: stur            x0, [fp, #-0x18]
    // 0xd6e848: r16 = "oas"
    //     0xd6e848: ldr             x16, [PP, #0x3e8]  ; [pp+0x3e8] "oas"
    // 0xd6e84c: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e850: r0 = DBusSignature()
    //     0xd6e850: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xd6e854: add             SP, SP, #0x10
    // 0xd6e858: ldur            x16, [fp, #-0x10]
    // 0xd6e85c: ldur            lr, [fp, #-0x18]
    // 0xd6e860: stp             lr, x16, [SP, #-0x10]!
    // 0xd6e864: r0 = ==()
    //     0xd6e864: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0xd6e868: add             SP, SP, #0x10
    // 0xd6e86c: tbnz            w0, #4, #0xd6e898
    // 0xd6e870: r0 = DBusObjectManagerInterfacesRemovedSignal()
    //     0xd6e870: bl              #0xd6e97c  ; AllocateDBusObjectManagerInterfacesRemovedSignalStub -> DBusObjectManagerInterfacesRemovedSignal (size=0x1c)
    // 0xd6e874: stur            x0, [fp, #-0x10]
    // 0xd6e878: ldr             x16, [fp, #0x10]
    // 0xd6e87c: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e880: r0 = DBusPropertiesChangedSignal()
    //     0xd6e880: bl              #0xa0eae8  ; [package:dbus/src/dbus_remote_object.dart] DBusPropertiesChangedSignal::DBusPropertiesChangedSignal
    // 0xd6e884: add             SP, SP, #0x10
    // 0xd6e888: ldur            x0, [fp, #-0x10]
    // 0xd6e88c: LeaveFrame
    //     0xd6e88c: mov             SP, fp
    //     0xd6e890: ldp             fp, lr, [SP], #0x10
    // 0xd6e894: ret
    //     0xd6e894: ret             
    // 0xd6e898: ldur            x0, [fp, #-8]
    // 0xd6e89c: r1 = LoadClassIdInstr(r0)
    //     0xd6e89c: ldur            x1, [x0, #-1]
    //     0xd6e8a0: ubfx            x1, x1, #0xc, #0x14
    // 0xd6e8a4: r16 = "org.freedesktop.DBus.Properties"
    //     0xd6e8a4: ldr             x16, [PP, #0x3f0]  ; [pp+0x3f0] "org.freedesktop.DBus.Properties"
    // 0xd6e8a8: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e8ac: mov             x0, x1
    // 0xd6e8b0: mov             lr, x0
    // 0xd6e8b4: ldr             lr, [x21, lr, lsl #3]
    // 0xd6e8b8: blr             lr
    // 0xd6e8bc: add             SP, SP, #0x10
    // 0xd6e8c0: tbnz            w0, #4, #0xd6e964
    // 0xd6e8c4: ldr             x1, [fp, #0x10]
    // 0xd6e8c8: LoadField: r0 = r1->field_13
    //     0xd6e8c8: ldur            w0, [x1, #0x13]
    // 0xd6e8cc: DecompressPointer r0
    //     0xd6e8cc: add             x0, x0, HEAP, lsl #32
    // 0xd6e8d0: r2 = LoadClassIdInstr(r0)
    //     0xd6e8d0: ldur            x2, [x0, #-1]
    //     0xd6e8d4: ubfx            x2, x2, #0xc, #0x14
    // 0xd6e8d8: r16 = "PropertiesChanged"
    //     0xd6e8d8: ldr             x16, [PP, #0x3f8]  ; [pp+0x3f8] "PropertiesChanged"
    // 0xd6e8dc: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e8e0: mov             x0, x2
    // 0xd6e8e4: mov             lr, x0
    // 0xd6e8e8: ldr             lr, [x21, lr, lsl #3]
    // 0xd6e8ec: blr             lr
    // 0xd6e8f0: add             SP, SP, #0x10
    // 0xd6e8f4: tbnz            w0, #4, #0xd6e964
    // 0xd6e8f8: ldr             x16, [fp, #0x10]
    // 0xd6e8fc: SaveReg r16
    //     0xd6e8fc: str             x16, [SP, #-8]!
    // 0xd6e900: r0 = signature()
    //     0xd6e900: bl              #0x9fef50  ; [package:dbus/src/dbus_signal.dart] DBusSignal::signature
    // 0xd6e904: add             SP, SP, #8
    // 0xd6e908: stur            x0, [fp, #-8]
    // 0xd6e90c: r0 = DBusSignature()
    //     0xd6e90c: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xd6e910: stur            x0, [fp, #-0x10]
    // 0xd6e914: r16 = "sa{sv}as"
    //     0xd6e914: ldr             x16, [PP, #0x400]  ; [pp+0x400] "sa{sv}as"
    // 0xd6e918: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e91c: r0 = DBusSignature()
    //     0xd6e91c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xd6e920: add             SP, SP, #0x10
    // 0xd6e924: ldur            x16, [fp, #-8]
    // 0xd6e928: ldur            lr, [fp, #-0x10]
    // 0xd6e92c: stp             lr, x16, [SP, #-0x10]!
    // 0xd6e930: r0 = ==()
    //     0xd6e930: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0xd6e934: add             SP, SP, #0x10
    // 0xd6e938: tbnz            w0, #4, #0xd6e964
    // 0xd6e93c: r0 = DBusPropertiesChangedSignal()
    //     0xd6e93c: bl              #0xa0ebcc  ; AllocateDBusPropertiesChangedSignalStub -> DBusPropertiesChangedSignal (size=0x1c)
    // 0xd6e940: stur            x0, [fp, #-8]
    // 0xd6e944: ldr             x16, [fp, #0x10]
    // 0xd6e948: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e94c: r0 = DBusPropertiesChangedSignal()
    //     0xd6e94c: bl              #0xa0eae8  ; [package:dbus/src/dbus_remote_object.dart] DBusPropertiesChangedSignal::DBusPropertiesChangedSignal
    // 0xd6e950: add             SP, SP, #0x10
    // 0xd6e954: ldur            x0, [fp, #-8]
    // 0xd6e958: LeaveFrame
    //     0xd6e958: mov             SP, fp
    //     0xd6e95c: ldp             fp, lr, [SP], #0x10
    // 0xd6e960: ret
    //     0xd6e960: ret             
    // 0xd6e964: ldr             x0, [fp, #0x10]
    // 0xd6e968: LeaveFrame
    //     0xd6e968: mov             SP, fp
    //     0xd6e96c: ldp             fp, lr, [SP], #0x10
    // 0xd6e970: ret
    //     0xd6e970: ret             
    // 0xd6e974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6e974: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6e978: b               #0xd6e6fc
  }
}

// class id: 4629, size: 0x1c, field offset: 0x1c
class DBusObjectManagerInterfacesRemovedSignal extends DBusSignal {

  get _ interfaces(/* No info */) {
    // ** addr: 0xa0f478, size: 0x70
    // 0xa0f478: EnterFrame
    //     0xa0f478: stp             fp, lr, [SP, #-0x10]!
    //     0xa0f47c: mov             fp, SP
    // 0xa0f480: CheckStackOverflow
    //     0xa0f480: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0f484: cmp             SP, x16
    //     0xa0f488: b.ls            #0xa0f4e0
    // 0xa0f48c: ldr             x0, [fp, #0x10]
    // 0xa0f490: LoadField: r1 = r0->field_17
    //     0xa0f490: ldur            w1, [x0, #0x17]
    // 0xa0f494: DecompressPointer r1
    //     0xa0f494: add             x1, x1, HEAP, lsl #32
    // 0xa0f498: r0 = LoadClassIdInstr(r1)
    //     0xa0f498: ldur            x0, [x1, #-1]
    //     0xa0f49c: ubfx            x0, x0, #0xc, #0x14
    // 0xa0f4a0: r16 = 2
    //     0xa0f4a0: mov             x16, #2
    // 0xa0f4a4: stp             x16, x1, [SP, #-0x10]!
    // 0xa0f4a8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa0f4a8: sub             lr, x0, #0xd83
    //     0xa0f4ac: ldr             lr, [x21, lr, lsl #3]
    //     0xa0f4b0: blr             lr
    // 0xa0f4b4: add             SP, SP, #0x10
    // 0xa0f4b8: SaveReg r0
    //     0xa0f4b8: str             x0, [SP, #-8]!
    // 0xa0f4bc: r0 = asStringArray()
    //     0xa0f4bc: bl              #0xa0f760  ; [package:dbus/src/dbus_value.dart] DBusValue::asStringArray
    // 0xa0f4c0: add             SP, SP, #8
    // 0xa0f4c4: SaveReg r0
    //     0xa0f4c4: str             x0, [SP, #-8]!
    // 0xa0f4c8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0f4c8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0f4cc: r0 = toList()
    //     0xa0f4cc: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0xa0f4d0: add             SP, SP, #8
    // 0xa0f4d4: LeaveFrame
    //     0xa0f4d4: mov             SP, fp
    //     0xa0f4d8: ldp             fp, lr, [SP], #0x10
    // 0xa0f4dc: ret
    //     0xa0f4dc: ret             
    // 0xa0f4e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0f4e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0f4e4: b               #0xa0f48c
  }
  get _ changedPath(/* No info */) {
    // ** addr: 0xa0f5c8, size: 0x94
    // 0xa0f5c8: EnterFrame
    //     0xa0f5c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa0f5cc: mov             fp, SP
    // 0xa0f5d0: AllocStack(0x8)
    //     0xa0f5d0: sub             SP, SP, #8
    // 0xa0f5d4: CheckStackOverflow
    //     0xa0f5d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0f5d8: cmp             SP, x16
    //     0xa0f5dc: b.ls            #0xa0f654
    // 0xa0f5e0: ldr             x0, [fp, #0x10]
    // 0xa0f5e4: LoadField: r1 = r0->field_17
    //     0xa0f5e4: ldur            w1, [x0, #0x17]
    // 0xa0f5e8: DecompressPointer r1
    //     0xa0f5e8: add             x1, x1, HEAP, lsl #32
    // 0xa0f5ec: r0 = LoadClassIdInstr(r1)
    //     0xa0f5ec: ldur            x0, [x1, #-1]
    //     0xa0f5f0: ubfx            x0, x0, #0xc, #0x14
    // 0xa0f5f4: stp             xzr, x1, [SP, #-0x10]!
    // 0xa0f5f8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa0f5f8: sub             lr, x0, #0xd83
    //     0xa0f5fc: ldr             lr, [x21, lr, lsl #3]
    //     0xa0f600: blr             lr
    // 0xa0f604: add             SP, SP, #0x10
    // 0xa0f608: mov             x3, x0
    // 0xa0f60c: r2 = Null
    //     0xa0f60c: mov             x2, NULL
    // 0xa0f610: r1 = Null
    //     0xa0f610: mov             x1, NULL
    // 0xa0f614: stur            x3, [fp, #-8]
    // 0xa0f618: r4 = 59
    //     0xa0f618: mov             x4, #0x3b
    // 0xa0f61c: branchIfSmi(r0, 0xa0f628)
    //     0xa0f61c: tbz             w0, #0, #0xa0f628
    // 0xa0f620: r4 = LoadClassIdInstr(r0)
    //     0xa0f620: ldur            x4, [x0, #-1]
    //     0xa0f624: ubfx            x4, x4, #0xc, #0x14
    // 0xa0f628: r17 = 4574
    //     0xa0f628: mov             x17, #0x11de
    // 0xa0f62c: cmp             x4, x17
    // 0xa0f630: b.eq            #0xa0f644
    // 0xa0f634: r8 = DBusObjectPath
    //     0xa0f634: ldr             x8, [PP, #0x7688]  ; [pp+0x7688] Type: DBusObjectPath
    // 0xa0f638: r3 = Null
    //     0xa0f638: add             x3, PP, #0x21, lsl #12  ; [pp+0x211c0] Null
    //     0xa0f63c: ldr             x3, [x3, #0x1c0]
    // 0xa0f640: r0 = DBusObjectPath()
    //     0xa0f640: bl              #0x9fcd54  ; IsType_DBusObjectPath_Stub
    // 0xa0f644: ldur            x0, [fp, #-8]
    // 0xa0f648: LeaveFrame
    //     0xa0f648: mov             SP, fp
    //     0xa0f64c: ldp             fp, lr, [SP], #0x10
    // 0xa0f650: ret
    //     0xa0f650: ret             
    // 0xa0f654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0f654: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0f658: b               #0xa0f5e0
  }
}

// class id: 4630, size: 0x1c, field offset: 0x1c
class DBusObjectManagerInterfacesAddedSignal extends DBusSignal {

  get _ interfacesAndProperties(/* No info */) {
    // ** addr: 0xa0f8e0, size: 0x60
    // 0xa0f8e0: EnterFrame
    //     0xa0f8e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa0f8e4: mov             fp, SP
    // 0xa0f8e8: CheckStackOverflow
    //     0xa0f8e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0f8ec: cmp             SP, x16
    //     0xa0f8f0: b.ls            #0xa0f938
    // 0xa0f8f4: ldr             x0, [fp, #0x10]
    // 0xa0f8f8: LoadField: r1 = r0->field_17
    //     0xa0f8f8: ldur            w1, [x0, #0x17]
    // 0xa0f8fc: DecompressPointer r1
    //     0xa0f8fc: add             x1, x1, HEAP, lsl #32
    // 0xa0f900: r0 = LoadClassIdInstr(r1)
    //     0xa0f900: ldur            x0, [x1, #-1]
    //     0xa0f904: ubfx            x0, x0, #0xc, #0x14
    // 0xa0f908: r16 = 2
    //     0xa0f908: mov             x16, #2
    // 0xa0f90c: stp             x16, x1, [SP, #-0x10]!
    // 0xa0f910: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa0f910: sub             lr, x0, #0xd83
    //     0xa0f914: ldr             lr, [x21, lr, lsl #3]
    //     0xa0f918: blr             lr
    // 0xa0f91c: add             SP, SP, #0x10
    // 0xa0f920: SaveReg r0
    //     0xa0f920: str             x0, [SP, #-8]!
    // 0xa0f924: r0 = _decodeInterfacesAndProperties()
    //     0xa0f924: bl              #0xa0e340  ; [package:dbus/src/dbus_remote_object_manager.dart] ::_decodeInterfacesAndProperties
    // 0xa0f928: add             SP, SP, #8
    // 0xa0f92c: LeaveFrame
    //     0xa0f92c: mov             SP, fp
    //     0xa0f930: ldp             fp, lr, [SP], #0x10
    // 0xa0f934: ret
    //     0xa0f934: ret             
    // 0xa0f938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0f938: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0f93c: b               #0xa0f8f4
  }
  get _ changedPath(/* No info */) {
    // ** addr: 0xa0f940, size: 0x94
    // 0xa0f940: EnterFrame
    //     0xa0f940: stp             fp, lr, [SP, #-0x10]!
    //     0xa0f944: mov             fp, SP
    // 0xa0f948: AllocStack(0x8)
    //     0xa0f948: sub             SP, SP, #8
    // 0xa0f94c: CheckStackOverflow
    //     0xa0f94c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0f950: cmp             SP, x16
    //     0xa0f954: b.ls            #0xa0f9cc
    // 0xa0f958: ldr             x0, [fp, #0x10]
    // 0xa0f95c: LoadField: r1 = r0->field_17
    //     0xa0f95c: ldur            w1, [x0, #0x17]
    // 0xa0f960: DecompressPointer r1
    //     0xa0f960: add             x1, x1, HEAP, lsl #32
    // 0xa0f964: r0 = LoadClassIdInstr(r1)
    //     0xa0f964: ldur            x0, [x1, #-1]
    //     0xa0f968: ubfx            x0, x0, #0xc, #0x14
    // 0xa0f96c: stp             xzr, x1, [SP, #-0x10]!
    // 0xa0f970: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa0f970: sub             lr, x0, #0xd83
    //     0xa0f974: ldr             lr, [x21, lr, lsl #3]
    //     0xa0f978: blr             lr
    // 0xa0f97c: add             SP, SP, #0x10
    // 0xa0f980: mov             x3, x0
    // 0xa0f984: r2 = Null
    //     0xa0f984: mov             x2, NULL
    // 0xa0f988: r1 = Null
    //     0xa0f988: mov             x1, NULL
    // 0xa0f98c: stur            x3, [fp, #-8]
    // 0xa0f990: r4 = 59
    //     0xa0f990: mov             x4, #0x3b
    // 0xa0f994: branchIfSmi(r0, 0xa0f9a0)
    //     0xa0f994: tbz             w0, #0, #0xa0f9a0
    // 0xa0f998: r4 = LoadClassIdInstr(r0)
    //     0xa0f998: ldur            x4, [x0, #-1]
    //     0xa0f99c: ubfx            x4, x4, #0xc, #0x14
    // 0xa0f9a0: r17 = 4574
    //     0xa0f9a0: mov             x17, #0x11de
    // 0xa0f9a4: cmp             x4, x17
    // 0xa0f9a8: b.eq            #0xa0f9bc
    // 0xa0f9ac: r8 = DBusObjectPath
    //     0xa0f9ac: ldr             x8, [PP, #0x7688]  ; [pp+0x7688] Type: DBusObjectPath
    // 0xa0f9b0: r3 = Null
    //     0xa0f9b0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21208] Null
    //     0xa0f9b4: ldr             x3, [x3, #0x208]
    // 0xa0f9b8: r0 = DBusObjectPath()
    //     0xa0f9b8: bl              #0x9fcd54  ; IsType_DBusObjectPath_Stub
    // 0xa0f9bc: ldur            x0, [fp, #-8]
    // 0xa0f9c0: LeaveFrame
    //     0xa0f9c0: mov             SP, fp
    //     0xa0f9c4: ldp             fp, lr, [SP], #0x10
    // 0xa0f9c8: ret
    //     0xa0f9c8: ret             
    // 0xa0f9cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0f9cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0f9d0: b               #0xa0f958
  }
}

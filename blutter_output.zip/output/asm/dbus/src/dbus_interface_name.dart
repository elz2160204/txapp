// lib: , url: package:dbus/src/dbus_interface_name.dart

// class id: 1048835, size: 0x8
class :: {
}

// class id: 4621, size: 0xc, field offset: 0x8
class DBusInterfaceName extends Object {

  _ DBusInterfaceName(/* No info */) {
    // ** addr: 0xa0212c, size: 0x290
    // 0xa0212c: EnterFrame
    //     0xa0212c: stp             fp, lr, [SP, #-0x10]!
    //     0xa02130: mov             fp, SP
    // 0xa02134: AllocStack(0x30)
    //     0xa02134: sub             SP, SP, #0x30
    // 0xa02138: CheckStackOverflow
    //     0xa02138: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0213c: cmp             SP, x16
    //     0xa02140: b.ls            #0xa023ac
    // 0xa02144: ldr             x0, [fp, #0x10]
    // 0xa02148: ldr             x1, [fp, #0x18]
    // 0xa0214c: StoreField: r1->field_7 = r0
    //     0xa0214c: stur            w0, [x1, #7]
    //     0xa02150: ldurb           w16, [x1, #-1]
    //     0xa02154: ldurb           w17, [x0, #-1]
    //     0xa02158: and             x16, x17, x16, lsr #2
    //     0xa0215c: tst             x16, HEAP, lsr #32
    //     0xa02160: b.eq            #0xa02168
    //     0xa02164: bl              #0xd6826c
    // 0xa02168: ldr             x1, [fp, #0x10]
    // 0xa0216c: LoadField: r0 = r1->field_7
    //     0xa0216c: ldur            w0, [x1, #7]
    // 0xa02170: DecompressPointer r0
    //     0xa02170: add             x0, x0, HEAP, lsl #32
    // 0xa02174: r2 = LoadInt32Instr(r0)
    //     0xa02174: sbfx            x2, x0, #1, #0x1f
    // 0xa02178: cmp             x2, #0xff
    // 0xa0217c: b.gt            #0xa02340
    // 0xa02180: r0 = LoadClassIdInstr(r1)
    //     0xa02180: ldur            x0, [x1, #-1]
    //     0xa02184: ubfx            x0, x0, #0xc, #0x14
    // 0xa02188: r16 = "."
    //     0xa02188: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xa0218c: stp             x16, x1, [SP, #-0x10]!
    // 0xa02190: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa02190: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa02194: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa02194: sub             lr, x0, #0xffc
    //     0xa02198: ldr             lr, [x21, lr, lsl #3]
    //     0xa0219c: blr             lr
    // 0xa021a0: add             SP, SP, #0x10
    // 0xa021a4: tbnz            w0, #4, #0xa0235c
    // 0xa021a8: ldr             x0, [fp, #0x10]
    // 0xa021ac: r1 = LoadClassIdInstr(r0)
    //     0xa021ac: ldur            x1, [x0, #-1]
    //     0xa021b0: ubfx            x1, x1, #0xc, #0x14
    // 0xa021b4: r16 = "."
    //     0xa021b4: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xa021b8: stp             x16, x0, [SP, #-0x10]!
    // 0xa021bc: mov             x0, x1
    // 0xa021c0: r0 = GDT[cid_x0 + -0xff8]()
    //     0xa021c0: sub             lr, x0, #0xff8
    //     0xa021c4: ldr             lr, [x21, lr, lsl #3]
    //     0xa021c8: blr             lr
    // 0xa021cc: add             SP, SP, #0x10
    // 0xa021d0: mov             x1, x0
    // 0xa021d4: stur            x1, [fp, #-0x20]
    // 0xa021d8: LoadField: r2 = r1->field_7
    //     0xa021d8: ldur            w2, [x1, #7]
    // 0xa021dc: DecompressPointer r2
    //     0xa021dc: add             x2, x2, HEAP, lsl #32
    // 0xa021e0: stur            x2, [fp, #-0x18]
    // 0xa021e4: LoadField: r0 = r1->field_b
    //     0xa021e4: ldur            w0, [x1, #0xb]
    // 0xa021e8: DecompressPointer r0
    //     0xa021e8: add             x0, x0, HEAP, lsl #32
    // 0xa021ec: r3 = LoadInt32Instr(r0)
    //     0xa021ec: sbfx            x3, x0, #1, #0x1f
    // 0xa021f0: stur            x3, [fp, #-0x10]
    // 0xa021f4: r4 = 0
    //     0xa021f4: mov             x4, #0
    // 0xa021f8: stur            x4, [fp, #-8]
    // 0xa021fc: CheckStackOverflow
    //     0xa021fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa02200: cmp             SP, x16
    //     0xa02204: b.ls            #0xa023b4
    // 0xa02208: r0 = LoadClassIdInstr(r1)
    //     0xa02208: ldur            x0, [x1, #-1]
    //     0xa0220c: ubfx            x0, x0, #0xc, #0x14
    // 0xa02210: SaveReg r1
    //     0xa02210: str             x1, [SP, #-8]!
    // 0xa02214: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa02214: mov             x17, #0xb8ea
    //     0xa02218: add             lr, x0, x17
    //     0xa0221c: ldr             lr, [x21, lr, lsl #3]
    //     0xa02220: blr             lr
    // 0xa02224: add             SP, SP, #8
    // 0xa02228: r1 = LoadInt32Instr(r0)
    //     0xa02228: sbfx            x1, x0, #1, #0x1f
    //     0xa0222c: tbz             w0, #0, #0xa02234
    //     0xa02230: ldur            x1, [x0, #7]
    // 0xa02234: ldur            x2, [fp, #-0x10]
    // 0xa02238: cmp             x2, x1
    // 0xa0223c: b.ne            #0xa02378
    // 0xa02240: ldur            x3, [fp, #-0x20]
    // 0xa02244: ldur            x4, [fp, #-8]
    // 0xa02248: cmp             x4, x1
    // 0xa0224c: b.lt            #0xa02260
    // 0xa02250: r0 = Null
    //     0xa02250: mov             x0, NULL
    // 0xa02254: LeaveFrame
    //     0xa02254: mov             SP, fp
    //     0xa02258: ldp             fp, lr, [SP], #0x10
    // 0xa0225c: ret
    //     0xa0225c: ret             
    // 0xa02260: r0 = BoxInt64Instr(r4)
    //     0xa02260: sbfiz           x0, x4, #1, #0x1f
    //     0xa02264: cmp             x4, x0, asr #1
    //     0xa02268: b.eq            #0xa02274
    //     0xa0226c: bl              #0xd69bb8
    //     0xa02270: stur            x4, [x0, #7]
    // 0xa02274: r1 = LoadClassIdInstr(r3)
    //     0xa02274: ldur            x1, [x3, #-1]
    //     0xa02278: ubfx            x1, x1, #0xc, #0x14
    // 0xa0227c: stp             x0, x3, [SP, #-0x10]!
    // 0xa02280: mov             x0, x1
    // 0xa02284: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa02284: mov             x17, #0xd175
    //     0xa02288: add             lr, x0, x17
    //     0xa0228c: ldr             lr, [x21, lr, lsl #3]
    //     0xa02290: blr             lr
    // 0xa02294: add             SP, SP, #0x10
    // 0xa02298: mov             x3, x0
    // 0xa0229c: ldur            x0, [fp, #-8]
    // 0xa022a0: stur            x3, [fp, #-0x30]
    // 0xa022a4: add             x4, x0, #1
    // 0xa022a8: stur            x4, [fp, #-0x28]
    // 0xa022ac: cmp             w3, NULL
    // 0xa022b0: b.ne            #0xa022e0
    // 0xa022b4: mov             x0, x3
    // 0xa022b8: ldur            x2, [fp, #-0x18]
    // 0xa022bc: r1 = Null
    //     0xa022bc: mov             x1, NULL
    // 0xa022c0: cmp             w2, NULL
    // 0xa022c4: b.eq            #0xa022e0
    // 0xa022c8: LoadField: r4 = r2->field_17
    //     0xa022c8: ldur            w4, [x2, #0x17]
    // 0xa022cc: DecompressPointer r4
    //     0xa022cc: add             x4, x4, HEAP, lsl #32
    // 0xa022d0: r8 = X0
    //     0xa022d0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa022d4: LoadField: r9 = r4->field_7
    //     0xa022d4: ldur            x9, [x4, #7]
    // 0xa022d8: r3 = Null
    //     0xa022d8: ldr             x3, [PP, #0x6c8]  ; [pp+0x6c8] Null
    // 0xa022dc: blr             x9
    // 0xa022e0: ldur            x0, [fp, #-0x30]
    // 0xa022e4: r16 = "^[a-zA-Z_][0-9a-zA-Z_]+$"
    //     0xa022e4: ldr             x16, [PP, #0x6d8]  ; [pp+0x6d8] "^[a-zA-Z_][0-9a-zA-Z_]+$"
    // 0xa022e8: stp             x16, NULL, [SP, #-0x10]!
    // 0xa022ec: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa022ec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa022f0: r0 = RegExp()
    //     0xa022f0: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0xa022f4: add             SP, SP, #0x10
    // 0xa022f8: mov             x1, x0
    // 0xa022fc: ldur            x0, [fp, #-0x30]
    // 0xa02300: r2 = LoadClassIdInstr(r0)
    //     0xa02300: ldur            x2, [x0, #-1]
    //     0xa02304: ubfx            x2, x2, #0xc, #0x14
    // 0xa02308: stp             x1, x0, [SP, #-0x10]!
    // 0xa0230c: mov             x0, x2
    // 0xa02310: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa02310: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa02314: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa02314: sub             lr, x0, #0xffc
    //     0xa02318: ldr             lr, [x21, lr, lsl #3]
    //     0xa0231c: blr             lr
    // 0xa02320: add             SP, SP, #0x10
    // 0xa02324: tbnz            w0, #4, #0xa02390
    // 0xa02328: r0 = "Invalid element in interface name"
    //     0xa02328: ldr             x0, [PP, #0x6e0]  ; [pp+0x6e0] "Invalid element in interface name"
    // 0xa0232c: ldur            x4, [fp, #-0x28]
    // 0xa02330: ldur            x1, [fp, #-0x20]
    // 0xa02334: ldur            x2, [fp, #-0x18]
    // 0xa02338: ldur            x3, [fp, #-0x10]
    // 0xa0233c: b               #0xa021f8
    // 0xa02340: r0 = FormatException()
    //     0xa02340: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa02344: mov             x1, x0
    // 0xa02348: r0 = "Interface name too long"
    //     0xa02348: ldr             x0, [PP, #0x6e8]  ; [pp+0x6e8] "Interface name too long"
    // 0xa0234c: StoreField: r1->field_7 = r0
    //     0xa0234c: stur            w0, [x1, #7]
    // 0xa02350: mov             x0, x1
    // 0xa02354: r0 = Throw()
    //     0xa02354: bl              #0xd67e38  ; ThrowStub
    // 0xa02358: brk             #0
    // 0xa0235c: r0 = FormatException()
    //     0xa0235c: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa02360: mov             x1, x0
    // 0xa02364: r0 = "Interface name needs at least two elements"
    //     0xa02364: ldr             x0, [PP, #0x6f0]  ; [pp+0x6f0] "Interface name needs at least two elements"
    // 0xa02368: StoreField: r1->field_7 = r0
    //     0xa02368: stur            w0, [x1, #7]
    // 0xa0236c: mov             x0, x1
    // 0xa02370: r0 = Throw()
    //     0xa02370: bl              #0xd67e38  ; ThrowStub
    // 0xa02374: brk             #0
    // 0xa02378: ldur            x0, [fp, #-0x20]
    // 0xa0237c: r0 = ConcurrentModificationError()
    //     0xa0237c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa02380: ldur            x3, [fp, #-0x20]
    // 0xa02384: StoreField: r0->field_b = r3
    //     0xa02384: stur            w3, [x0, #0xb]
    // 0xa02388: r0 = Throw()
    //     0xa02388: bl              #0xd67e38  ; ThrowStub
    // 0xa0238c: brk             #0
    // 0xa02390: r0 = FormatException()
    //     0xa02390: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa02394: mov             x1, x0
    // 0xa02398: r0 = "Invalid element in interface name"
    //     0xa02398: ldr             x0, [PP, #0x6e0]  ; [pp+0x6e0] "Invalid element in interface name"
    // 0xa0239c: StoreField: r1->field_7 = r0
    //     0xa0239c: stur            w0, [x1, #7]
    // 0xa023a0: mov             x0, x1
    // 0xa023a4: r0 = Throw()
    //     0xa023a4: bl              #0xd67e38  ; ThrowStub
    // 0xa023a8: brk             #0
    // 0xa023ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa023ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa023b0: b               #0xa02144
    // 0xa023b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa023b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa023b8: b               #0xa02208
  }
  _ toString(/* No info */) {
    // ** addr: 0xacfb78, size: 0x68
    // 0xacfb78: EnterFrame
    //     0xacfb78: stp             fp, lr, [SP, #-0x10]!
    //     0xacfb7c: mov             fp, SP
    // 0xacfb80: CheckStackOverflow
    //     0xacfb80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacfb84: cmp             SP, x16
    //     0xacfb88: b.ls            #0xacfbd8
    // 0xacfb8c: r1 = Null
    //     0xacfb8c: mov             x1, NULL
    // 0xacfb90: r2 = 8
    //     0xacfb90: mov             x2, #8
    // 0xacfb94: r0 = AllocateArray()
    //     0xacfb94: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacfb98: r17 = DBusInterfaceName
    //     0xacfb98: ldr             x17, [PP, #0x7670]  ; [pp+0x7670] Type: DBusInterfaceName
    // 0xacfb9c: StoreField: r0->field_f = r17
    //     0xacfb9c: stur            w17, [x0, #0xf]
    // 0xacfba0: r17 = "(\'"
    //     0xacfba0: ldr             x17, [PP, #0x7168]  ; [pp+0x7168] "(\'"
    // 0xacfba4: StoreField: r0->field_13 = r17
    //     0xacfba4: stur            w17, [x0, #0x13]
    // 0xacfba8: ldr             x1, [fp, #0x10]
    // 0xacfbac: LoadField: r2 = r1->field_7
    //     0xacfbac: ldur            w2, [x1, #7]
    // 0xacfbb0: DecompressPointer r2
    //     0xacfbb0: add             x2, x2, HEAP, lsl #32
    // 0xacfbb4: StoreField: r0->field_17 = r2
    //     0xacfbb4: stur            w2, [x0, #0x17]
    // 0xacfbb8: r17 = "\')"
    //     0xacfbb8: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xacfbbc: StoreField: r0->field_1b = r17
    //     0xacfbbc: stur            w17, [x0, #0x1b]
    // 0xacfbc0: SaveReg r0
    //     0xacfbc0: str             x0, [SP, #-8]!
    // 0xacfbc4: r0 = _interpolate()
    //     0xacfbc4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacfbc8: add             SP, SP, #8
    // 0xacfbcc: LeaveFrame
    //     0xacfbcc: mov             SP, fp
    //     0xacfbd0: ldp             fp, lr, [SP], #0x10
    // 0xacfbd4: ret
    //     0xacfbd4: ret             
    // 0xacfbd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacfbd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacfbdc: b               #0xacfb8c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e2a8, size: 0xa0
    // 0xc6e2a8: EnterFrame
    //     0xc6e2a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc6e2ac: mov             fp, SP
    // 0xc6e2b0: CheckStackOverflow
    //     0xc6e2b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6e2b4: cmp             SP, x16
    //     0xc6e2b8: b.ls            #0xc6e340
    // 0xc6e2bc: ldr             x0, [fp, #0x10]
    // 0xc6e2c0: cmp             w0, NULL
    // 0xc6e2c4: b.ne            #0xc6e2d8
    // 0xc6e2c8: r0 = false
    //     0xc6e2c8: add             x0, NULL, #0x30  ; false
    // 0xc6e2cc: LeaveFrame
    //     0xc6e2cc: mov             SP, fp
    //     0xc6e2d0: ldp             fp, lr, [SP], #0x10
    // 0xc6e2d4: ret
    //     0xc6e2d4: ret             
    // 0xc6e2d8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6e2d8: mov             x1, #0x76
    //     0xc6e2dc: tbz             w0, #0, #0xc6e2ec
    //     0xc6e2e0: ldur            x1, [x0, #-1]
    //     0xc6e2e4: ubfx            x1, x1, #0xc, #0x14
    //     0xc6e2e8: lsl             x1, x1, #1
    // 0xc6e2ec: r17 = 9242
    //     0xc6e2ec: mov             x17, #0x241a
    // 0xc6e2f0: cmp             w1, w17
    // 0xc6e2f4: b.ne            #0xc6e330
    // 0xc6e2f8: ldr             x1, [fp, #0x18]
    // 0xc6e2fc: LoadField: r2 = r0->field_7
    //     0xc6e2fc: ldur            w2, [x0, #7]
    // 0xc6e300: DecompressPointer r2
    //     0xc6e300: add             x2, x2, HEAP, lsl #32
    // 0xc6e304: LoadField: r0 = r1->field_7
    //     0xc6e304: ldur            w0, [x1, #7]
    // 0xc6e308: DecompressPointer r0
    //     0xc6e308: add             x0, x0, HEAP, lsl #32
    // 0xc6e30c: r1 = LoadClassIdInstr(r2)
    //     0xc6e30c: ldur            x1, [x2, #-1]
    //     0xc6e310: ubfx            x1, x1, #0xc, #0x14
    // 0xc6e314: stp             x0, x2, [SP, #-0x10]!
    // 0xc6e318: mov             x0, x1
    // 0xc6e31c: mov             lr, x0
    // 0xc6e320: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e324: blr             lr
    // 0xc6e328: add             SP, SP, #0x10
    // 0xc6e32c: b               #0xc6e334
    // 0xc6e330: r0 = false
    //     0xc6e330: add             x0, NULL, #0x30  ; false
    // 0xc6e334: LeaveFrame
    //     0xc6e334: mov             SP, fp
    //     0xc6e338: ldp             fp, lr, [SP], #0x10
    // 0xc6e33c: ret
    //     0xc6e33c: ret             
    // 0xc6e340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6e340: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6e344: b               #0xc6e2bc
  }
}

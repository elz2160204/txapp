// lib: , url: package:dbus/src/dbus_bus_name.dart

// class id: 1048832, size: 0x8
class :: {
}

// class id: 4632, size: 0xc, field offset: 0x8
class DBusBusName extends Object {

  _ DBusBusName(/* No info */) {
    // ** addr: 0xa023c8, size: 0x32c
    // 0xa023c8: EnterFrame
    //     0xa023c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa023cc: mov             fp, SP
    // 0xa023d0: AllocStack(0x38)
    //     0xa023d0: sub             SP, SP, #0x38
    // 0xa023d4: CheckStackOverflow
    //     0xa023d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa023d8: cmp             SP, x16
    //     0xa023dc: b.ls            #0xa026e4
    // 0xa023e0: ldr             x0, [fp, #0x10]
    // 0xa023e4: ldr             x1, [fp, #0x18]
    // 0xa023e8: StoreField: r1->field_7 = r0
    //     0xa023e8: stur            w0, [x1, #7]
    //     0xa023ec: ldurb           w16, [x1, #-1]
    //     0xa023f0: ldurb           w17, [x0, #-1]
    //     0xa023f4: and             x16, x17, x16, lsr #2
    //     0xa023f8: tst             x16, HEAP, lsr #32
    //     0xa023fc: b.eq            #0xa02404
    //     0xa02400: bl              #0xd6826c
    // 0xa02404: ldr             x0, [fp, #0x10]
    // 0xa02408: LoadField: r1 = r0->field_7
    //     0xa02408: ldur            w1, [x0, #7]
    // 0xa0240c: DecompressPointer r1
    //     0xa0240c: add             x1, x1, HEAP, lsl #32
    // 0xa02410: cbz             w1, #0xa0265c
    // 0xa02414: r2 = LoadInt32Instr(r1)
    //     0xa02414: sbfx            x2, x1, #1, #0x1f
    // 0xa02418: cmp             x2, #0xff
    // 0xa0241c: b.gt            #0xa02678
    // 0xa02420: r16 = ":"
    //     0xa02420: ldr             x16, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0xa02424: stp             x16, x0, [SP, #-0x10]!
    // 0xa02428: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa02428: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0242c: r0 = startsWith()
    //     0xa0242c: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0xa02430: add             SP, SP, #0x10
    // 0xa02434: tst             x0, #0x10
    // 0xa02438: cset            x1, eq
    // 0xa0243c: lsl             x1, x1, #1
    // 0xa02440: r0 = LoadInt32Instr(r1)
    //     0xa02440: sbfx            x0, x1, #1, #0x1f
    // 0xa02444: ldr             x16, [fp, #0x10]
    // 0xa02448: stp             x0, x16, [SP, #-0x10]!
    // 0xa0244c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0244c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa02450: r0 = substring()
    //     0xa02450: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xa02454: add             SP, SP, #0x10
    // 0xa02458: stur            x0, [fp, #-8]
    // 0xa0245c: ldr             x16, [fp, #0x10]
    // 0xa02460: r30 = ":"
    //     0xa02460: ldr             lr, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0xa02464: stp             lr, x16, [SP, #-0x10]!
    // 0xa02468: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa02468: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0246c: r0 = startsWith()
    //     0xa0246c: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0xa02470: add             SP, SP, #0x10
    // 0xa02474: tbnz            w0, #4, #0xa02494
    // 0xa02478: r16 = "^[0-9a-zA-Z_-]+$"
    //     0xa02478: ldr             x16, [PP, #0x700]  ; [pp+0x700] "^[0-9a-zA-Z_-]+$"
    // 0xa0247c: stp             x16, NULL, [SP, #-0x10]!
    // 0xa02480: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa02480: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa02484: r0 = RegExp()
    //     0xa02484: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0xa02488: add             SP, SP, #0x10
    // 0xa0248c: mov             x2, x0
    // 0xa02490: b               #0xa024ac
    // 0xa02494: r16 = "^[a-zA-Z_-][0-9a-zA-Z_-]*$"
    //     0xa02494: ldr             x16, [PP, #0x708]  ; [pp+0x708] "^[a-zA-Z_-][0-9a-zA-Z_-]*$"
    // 0xa02498: stp             x16, NULL, [SP, #-0x10]!
    // 0xa0249c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0249c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa024a0: r0 = RegExp()
    //     0xa024a0: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0xa024a4: add             SP, SP, #0x10
    // 0xa024a8: mov             x2, x0
    // 0xa024ac: ldur            x1, [fp, #-8]
    // 0xa024b0: stur            x2, [fp, #-0x10]
    // 0xa024b4: r0 = LoadClassIdInstr(r1)
    //     0xa024b4: ldur            x0, [x1, #-1]
    //     0xa024b8: ubfx            x0, x0, #0xc, #0x14
    // 0xa024bc: r16 = "."
    //     0xa024bc: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xa024c0: stp             x16, x1, [SP, #-0x10]!
    // 0xa024c4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa024c4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa024c8: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa024c8: sub             lr, x0, #0xffc
    //     0xa024cc: ldr             lr, [x21, lr, lsl #3]
    //     0xa024d0: blr             lr
    // 0xa024d4: add             SP, SP, #0x10
    // 0xa024d8: tbnz            w0, #4, #0xa02694
    // 0xa024dc: ldur            x0, [fp, #-8]
    // 0xa024e0: r1 = LoadClassIdInstr(r0)
    //     0xa024e0: ldur            x1, [x0, #-1]
    //     0xa024e4: ubfx            x1, x1, #0xc, #0x14
    // 0xa024e8: r16 = "."
    //     0xa024e8: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xa024ec: stp             x16, x0, [SP, #-0x10]!
    // 0xa024f0: mov             x0, x1
    // 0xa024f4: r0 = GDT[cid_x0 + -0xff8]()
    //     0xa024f4: sub             lr, x0, #0xff8
    //     0xa024f8: ldr             lr, [x21, lr, lsl #3]
    //     0xa024fc: blr             lr
    // 0xa02500: add             SP, SP, #0x10
    // 0xa02504: mov             x1, x0
    // 0xa02508: stur            x1, [fp, #-0x28]
    // 0xa0250c: LoadField: r2 = r1->field_7
    //     0xa0250c: ldur            w2, [x1, #7]
    // 0xa02510: DecompressPointer r2
    //     0xa02510: add             x2, x2, HEAP, lsl #32
    // 0xa02514: stur            x2, [fp, #-8]
    // 0xa02518: LoadField: r0 = r1->field_b
    //     0xa02518: ldur            w0, [x1, #0xb]
    // 0xa0251c: DecompressPointer r0
    //     0xa0251c: add             x0, x0, HEAP, lsl #32
    // 0xa02520: r3 = LoadInt32Instr(r0)
    //     0xa02520: sbfx            x3, x0, #1, #0x1f
    // 0xa02524: stur            x3, [fp, #-0x20]
    // 0xa02528: r4 = 0
    //     0xa02528: mov             x4, #0
    // 0xa0252c: stur            x4, [fp, #-0x18]
    // 0xa02530: CheckStackOverflow
    //     0xa02530: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa02534: cmp             SP, x16
    //     0xa02538: b.ls            #0xa026ec
    // 0xa0253c: r0 = LoadClassIdInstr(r1)
    //     0xa0253c: ldur            x0, [x1, #-1]
    //     0xa02540: ubfx            x0, x0, #0xc, #0x14
    // 0xa02544: SaveReg r1
    //     0xa02544: str             x1, [SP, #-8]!
    // 0xa02548: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa02548: mov             x17, #0xb8ea
    //     0xa0254c: add             lr, x0, x17
    //     0xa02550: ldr             lr, [x21, lr, lsl #3]
    //     0xa02554: blr             lr
    // 0xa02558: add             SP, SP, #8
    // 0xa0255c: r1 = LoadInt32Instr(r0)
    //     0xa0255c: sbfx            x1, x0, #1, #0x1f
    //     0xa02560: tbz             w0, #0, #0xa02568
    //     0xa02564: ldur            x1, [x0, #7]
    // 0xa02568: ldur            x2, [fp, #-0x20]
    // 0xa0256c: cmp             x2, x1
    // 0xa02570: b.ne            #0xa026b0
    // 0xa02574: ldur            x3, [fp, #-0x28]
    // 0xa02578: ldur            x4, [fp, #-0x18]
    // 0xa0257c: cmp             x4, x1
    // 0xa02580: b.lt            #0xa02594
    // 0xa02584: r0 = Null
    //     0xa02584: mov             x0, NULL
    // 0xa02588: LeaveFrame
    //     0xa02588: mov             SP, fp
    //     0xa0258c: ldp             fp, lr, [SP], #0x10
    // 0xa02590: ret
    //     0xa02590: ret             
    // 0xa02594: r0 = BoxInt64Instr(r4)
    //     0xa02594: sbfiz           x0, x4, #1, #0x1f
    //     0xa02598: cmp             x4, x0, asr #1
    //     0xa0259c: b.eq            #0xa025a8
    //     0xa025a0: bl              #0xd69bb8
    //     0xa025a4: stur            x4, [x0, #7]
    // 0xa025a8: r1 = LoadClassIdInstr(r3)
    //     0xa025a8: ldur            x1, [x3, #-1]
    //     0xa025ac: ubfx            x1, x1, #0xc, #0x14
    // 0xa025b0: stp             x0, x3, [SP, #-0x10]!
    // 0xa025b4: mov             x0, x1
    // 0xa025b8: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa025b8: mov             x17, #0xd175
    //     0xa025bc: add             lr, x0, x17
    //     0xa025c0: ldr             lr, [x21, lr, lsl #3]
    //     0xa025c4: blr             lr
    // 0xa025c8: add             SP, SP, #0x10
    // 0xa025cc: mov             x3, x0
    // 0xa025d0: ldur            x0, [fp, #-0x18]
    // 0xa025d4: stur            x3, [fp, #-0x38]
    // 0xa025d8: add             x4, x0, #1
    // 0xa025dc: stur            x4, [fp, #-0x30]
    // 0xa025e0: cmp             w3, NULL
    // 0xa025e4: b.ne            #0xa02614
    // 0xa025e8: mov             x0, x3
    // 0xa025ec: ldur            x2, [fp, #-8]
    // 0xa025f0: r1 = Null
    //     0xa025f0: mov             x1, NULL
    // 0xa025f4: cmp             w2, NULL
    // 0xa025f8: b.eq            #0xa02614
    // 0xa025fc: LoadField: r4 = r2->field_17
    //     0xa025fc: ldur            w4, [x2, #0x17]
    // 0xa02600: DecompressPointer r4
    //     0xa02600: add             x4, x4, HEAP, lsl #32
    // 0xa02604: r8 = X0
    //     0xa02604: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa02608: LoadField: r9 = r4->field_7
    //     0xa02608: ldur            x9, [x4, #7]
    // 0xa0260c: r3 = Null
    //     0xa0260c: ldr             x3, [PP, #0x710]  ; [pp+0x710] Null
    // 0xa02610: blr             x9
    // 0xa02614: ldur            x0, [fp, #-0x38]
    // 0xa02618: r1 = LoadClassIdInstr(r0)
    //     0xa02618: ldur            x1, [x0, #-1]
    //     0xa0261c: ubfx            x1, x1, #0xc, #0x14
    // 0xa02620: ldur            x16, [fp, #-0x10]
    // 0xa02624: stp             x16, x0, [SP, #-0x10]!
    // 0xa02628: mov             x0, x1
    // 0xa0262c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0262c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa02630: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa02630: sub             lr, x0, #0xffc
    //     0xa02634: ldr             lr, [x21, lr, lsl #3]
    //     0xa02638: blr             lr
    // 0xa0263c: add             SP, SP, #0x10
    // 0xa02640: tbnz            w0, #4, #0xa026c8
    // 0xa02644: r0 = "Invalid element in bus name"
    //     0xa02644: ldr             x0, [PP, #0x720]  ; [pp+0x720] "Invalid element in bus name"
    // 0xa02648: ldur            x4, [fp, #-0x30]
    // 0xa0264c: ldur            x1, [fp, #-0x28]
    // 0xa02650: ldur            x2, [fp, #-8]
    // 0xa02654: ldur            x3, [fp, #-0x20]
    // 0xa02658: b               #0xa0252c
    // 0xa0265c: r0 = FormatException()
    //     0xa0265c: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa02660: mov             x1, x0
    // 0xa02664: r0 = "Empty bus name"
    //     0xa02664: ldr             x0, [PP, #0x728]  ; [pp+0x728] "Empty bus name"
    // 0xa02668: StoreField: r1->field_7 = r0
    //     0xa02668: stur            w0, [x1, #7]
    // 0xa0266c: mov             x0, x1
    // 0xa02670: r0 = Throw()
    //     0xa02670: bl              #0xd67e38  ; ThrowStub
    // 0xa02674: brk             #0
    // 0xa02678: r0 = FormatException()
    //     0xa02678: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa0267c: mov             x1, x0
    // 0xa02680: r0 = "Bus name too long"
    //     0xa02680: ldr             x0, [PP, #0x730]  ; [pp+0x730] "Bus name too long"
    // 0xa02684: StoreField: r1->field_7 = r0
    //     0xa02684: stur            w0, [x1, #7]
    // 0xa02688: mov             x0, x1
    // 0xa0268c: r0 = Throw()
    //     0xa0268c: bl              #0xd67e38  ; ThrowStub
    // 0xa02690: brk             #0
    // 0xa02694: r0 = FormatException()
    //     0xa02694: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa02698: mov             x1, x0
    // 0xa0269c: r0 = "Bus name needs at least two elements"
    //     0xa0269c: ldr             x0, [PP, #0x738]  ; [pp+0x738] "Bus name needs at least two elements"
    // 0xa026a0: StoreField: r1->field_7 = r0
    //     0xa026a0: stur            w0, [x1, #7]
    // 0xa026a4: mov             x0, x1
    // 0xa026a8: r0 = Throw()
    //     0xa026a8: bl              #0xd67e38  ; ThrowStub
    // 0xa026ac: brk             #0
    // 0xa026b0: ldur            x0, [fp, #-0x28]
    // 0xa026b4: r0 = ConcurrentModificationError()
    //     0xa026b4: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa026b8: ldur            x3, [fp, #-0x28]
    // 0xa026bc: StoreField: r0->field_b = r3
    //     0xa026bc: stur            w3, [x0, #0xb]
    // 0xa026c0: r0 = Throw()
    //     0xa026c0: bl              #0xd67e38  ; ThrowStub
    // 0xa026c4: brk             #0
    // 0xa026c8: r0 = FormatException()
    //     0xa026c8: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa026cc: mov             x1, x0
    // 0xa026d0: r0 = "Invalid element in bus name"
    //     0xa026d0: ldr             x0, [PP, #0x720]  ; [pp+0x720] "Invalid element in bus name"
    // 0xa026d4: StoreField: r1->field_7 = r0
    //     0xa026d4: stur            w0, [x1, #7]
    // 0xa026d8: mov             x0, x1
    // 0xa026dc: r0 = Throw()
    //     0xa026dc: bl              #0xd67e38  ; ThrowStub
    // 0xa026e0: brk             #0
    // 0xa026e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa026e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa026e8: b               #0xa023e0
    // 0xa026ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa026ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa026f0: b               #0xa0253c
  }
  _ toString(/* No info */) {
    // ** addr: 0xacf7c0, size: 0x68
    // 0xacf7c0: EnterFrame
    //     0xacf7c0: stp             fp, lr, [SP, #-0x10]!
    //     0xacf7c4: mov             fp, SP
    // 0xacf7c8: CheckStackOverflow
    //     0xacf7c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf7cc: cmp             SP, x16
    //     0xacf7d0: b.ls            #0xacf820
    // 0xacf7d4: r1 = Null
    //     0xacf7d4: mov             x1, NULL
    // 0xacf7d8: r2 = 8
    //     0xacf7d8: mov             x2, #8
    // 0xacf7dc: r0 = AllocateArray()
    //     0xacf7dc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf7e0: r17 = DBusBusName
    //     0xacf7e0: ldr             x17, [PP, #0x7678]  ; [pp+0x7678] Type: DBusBusName
    // 0xacf7e4: StoreField: r0->field_f = r17
    //     0xacf7e4: stur            w17, [x0, #0xf]
    // 0xacf7e8: r17 = "(\'"
    //     0xacf7e8: ldr             x17, [PP, #0x7168]  ; [pp+0x7168] "(\'"
    // 0xacf7ec: StoreField: r0->field_13 = r17
    //     0xacf7ec: stur            w17, [x0, #0x13]
    // 0xacf7f0: ldr             x1, [fp, #0x10]
    // 0xacf7f4: LoadField: r2 = r1->field_7
    //     0xacf7f4: ldur            w2, [x1, #7]
    // 0xacf7f8: DecompressPointer r2
    //     0xacf7f8: add             x2, x2, HEAP, lsl #32
    // 0xacf7fc: StoreField: r0->field_17 = r2
    //     0xacf7fc: stur            w2, [x0, #0x17]
    // 0xacf800: r17 = "\')"
    //     0xacf800: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xacf804: StoreField: r0->field_1b = r17
    //     0xacf804: stur            w17, [x0, #0x1b]
    // 0xacf808: SaveReg r0
    //     0xacf808: str             x0, [SP, #-8]!
    // 0xacf80c: r0 = _interpolate()
    //     0xacf80c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf810: add             SP, SP, #8
    // 0xacf814: LeaveFrame
    //     0xacf814: mov             SP, fp
    //     0xacf818: ldp             fp, lr, [SP], #0x10
    // 0xacf81c: ret
    //     0xacf81c: ret             
    // 0xacf820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf820: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf824: b               #0xacf7d4
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6dd1c, size: 0xa0
    // 0xc6dd1c: EnterFrame
    //     0xc6dd1c: stp             fp, lr, [SP, #-0x10]!
    //     0xc6dd20: mov             fp, SP
    // 0xc6dd24: CheckStackOverflow
    //     0xc6dd24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6dd28: cmp             SP, x16
    //     0xc6dd2c: b.ls            #0xc6ddb4
    // 0xc6dd30: ldr             x0, [fp, #0x10]
    // 0xc6dd34: cmp             w0, NULL
    // 0xc6dd38: b.ne            #0xc6dd4c
    // 0xc6dd3c: r0 = false
    //     0xc6dd3c: add             x0, NULL, #0x30  ; false
    // 0xc6dd40: LeaveFrame
    //     0xc6dd40: mov             SP, fp
    //     0xc6dd44: ldp             fp, lr, [SP], #0x10
    // 0xc6dd48: ret
    //     0xc6dd48: ret             
    // 0xc6dd4c: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6dd4c: mov             x1, #0x76
    //     0xc6dd50: tbz             w0, #0, #0xc6dd60
    //     0xc6dd54: ldur            x1, [x0, #-1]
    //     0xc6dd58: ubfx            x1, x1, #0xc, #0x14
    //     0xc6dd5c: lsl             x1, x1, #1
    // 0xc6dd60: r17 = 9264
    //     0xc6dd60: mov             x17, #0x2430
    // 0xc6dd64: cmp             w1, w17
    // 0xc6dd68: b.ne            #0xc6dda4
    // 0xc6dd6c: ldr             x1, [fp, #0x18]
    // 0xc6dd70: LoadField: r2 = r0->field_7
    //     0xc6dd70: ldur            w2, [x0, #7]
    // 0xc6dd74: DecompressPointer r2
    //     0xc6dd74: add             x2, x2, HEAP, lsl #32
    // 0xc6dd78: LoadField: r0 = r1->field_7
    //     0xc6dd78: ldur            w0, [x1, #7]
    // 0xc6dd7c: DecompressPointer r0
    //     0xc6dd7c: add             x0, x0, HEAP, lsl #32
    // 0xc6dd80: r1 = LoadClassIdInstr(r2)
    //     0xc6dd80: ldur            x1, [x2, #-1]
    //     0xc6dd84: ubfx            x1, x1, #0xc, #0x14
    // 0xc6dd88: stp             x0, x2, [SP, #-0x10]!
    // 0xc6dd8c: mov             x0, x1
    // 0xc6dd90: mov             lr, x0
    // 0xc6dd94: ldr             lr, [x21, lr, lsl #3]
    // 0xc6dd98: blr             lr
    // 0xc6dd9c: add             SP, SP, #0x10
    // 0xc6dda0: b               #0xc6dda8
    // 0xc6dda4: r0 = false
    //     0xc6dda4: add             x0, NULL, #0x30  ; false
    // 0xc6dda8: LeaveFrame
    //     0xc6dda8: mov             SP, fp
    //     0xc6ddac: ldp             fp, lr, [SP], #0x10
    // 0xc6ddb0: ret
    //     0xc6ddb0: ret             
    // 0xc6ddb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ddb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ddb8: b               #0xc6dd30
  }
}

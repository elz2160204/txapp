// lib: , url: package:dbus/src/dbus_value.dart

// class id: 1048854, size: 0x8
class :: {

  static _ _mapsEqual(/* No info */) {
    // ** addr: 0xc6ef30, size: 0x1e8
    // 0xc6ef30: EnterFrame
    //     0xc6ef30: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ef34: mov             fp, SP
    // 0xc6ef38: AllocStack(0x20)
    //     0xc6ef38: sub             SP, SP, #0x20
    // 0xc6ef3c: CheckStackOverflow
    //     0xc6ef3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ef40: cmp             SP, x16
    //     0xc6ef44: b.ls            #0xc6f108
    // 0xc6ef48: ldr             x0, [fp, #0x18]
    // 0xc6ef4c: LoadField: r1 = r0->field_13
    //     0xc6ef4c: ldur            w1, [x0, #0x13]
    // 0xc6ef50: DecompressPointer r1
    //     0xc6ef50: add             x1, x1, HEAP, lsl #32
    // 0xc6ef54: r2 = LoadInt32Instr(r1)
    //     0xc6ef54: sbfx            x2, x1, #1, #0x1f
    // 0xc6ef58: asr             x1, x2, #1
    // 0xc6ef5c: LoadField: r2 = r0->field_17
    //     0xc6ef5c: ldur            w2, [x0, #0x17]
    // 0xc6ef60: DecompressPointer r2
    //     0xc6ef60: add             x2, x2, HEAP, lsl #32
    // 0xc6ef64: r3 = LoadInt32Instr(r2)
    //     0xc6ef64: sbfx            x3, x2, #1, #0x1f
    // 0xc6ef68: sub             x2, x1, x3
    // 0xc6ef6c: ldr             x1, [fp, #0x10]
    // 0xc6ef70: LoadField: r3 = r1->field_13
    //     0xc6ef70: ldur            w3, [x1, #0x13]
    // 0xc6ef74: DecompressPointer r3
    //     0xc6ef74: add             x3, x3, HEAP, lsl #32
    // 0xc6ef78: r4 = LoadInt32Instr(r3)
    //     0xc6ef78: sbfx            x4, x3, #1, #0x1f
    // 0xc6ef7c: asr             x3, x4, #1
    // 0xc6ef80: LoadField: r4 = r1->field_17
    //     0xc6ef80: ldur            w4, [x1, #0x17]
    // 0xc6ef84: DecompressPointer r4
    //     0xc6ef84: add             x4, x4, HEAP, lsl #32
    // 0xc6ef88: r5 = LoadInt32Instr(r4)
    //     0xc6ef88: sbfx            x5, x4, #1, #0x1f
    // 0xc6ef8c: sub             x4, x3, x5
    // 0xc6ef90: cmp             x2, x4
    // 0xc6ef94: b.eq            #0xc6efa8
    // 0xc6ef98: r0 = false
    //     0xc6ef98: add             x0, NULL, #0x30  ; false
    // 0xc6ef9c: LeaveFrame
    //     0xc6ef9c: mov             SP, fp
    //     0xc6efa0: ldp             fp, lr, [SP], #0x10
    // 0xc6efa4: ret
    //     0xc6efa4: ret             
    // 0xc6efa8: SaveReg r0
    //     0xc6efa8: str             x0, [SP, #-8]!
    // 0xc6efac: r0 = keys()
    //     0xc6efac: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0xc6efb0: add             SP, SP, #8
    // 0xc6efb4: SaveReg r0
    //     0xc6efb4: str             x0, [SP, #-8]!
    // 0xc6efb8: r0 = iterator()
    //     0xc6efb8: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0xc6efbc: add             SP, SP, #8
    // 0xc6efc0: stur            x0, [fp, #-0x10]
    // 0xc6efc4: LoadField: r2 = r0->field_7
    //     0xc6efc4: ldur            w2, [x0, #7]
    // 0xc6efc8: DecompressPointer r2
    //     0xc6efc8: add             x2, x2, HEAP, lsl #32
    // 0xc6efcc: stur            x2, [fp, #-8]
    // 0xc6efd0: ldr             x1, [fp, #0x18]
    // 0xc6efd4: ldr             x3, [fp, #0x10]
    // 0xc6efd8: CheckStackOverflow
    //     0xc6efd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6efdc: cmp             SP, x16
    //     0xc6efe0: b.ls            #0xc6f110
    // 0xc6efe4: SaveReg r0
    //     0xc6efe4: str             x0, [SP, #-8]!
    // 0xc6efe8: r0 = moveNext()
    //     0xc6efe8: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0xc6efec: add             SP, SP, #8
    // 0xc6eff0: tbnz            w0, #4, #0xc6f0f8
    // 0xc6eff4: ldur            x3, [fp, #-0x10]
    // 0xc6eff8: LoadField: r4 = r3->field_33
    //     0xc6eff8: ldur            w4, [x3, #0x33]
    // 0xc6effc: DecompressPointer r4
    //     0xc6effc: add             x4, x4, HEAP, lsl #32
    // 0xc6f000: stur            x4, [fp, #-0x18]
    // 0xc6f004: cmp             w4, NULL
    // 0xc6f008: b.ne            #0xc6f03c
    // 0xc6f00c: mov             x0, x4
    // 0xc6f010: ldur            x2, [fp, #-8]
    // 0xc6f014: r1 = Null
    //     0xc6f014: mov             x1, NULL
    // 0xc6f018: cmp             w2, NULL
    // 0xc6f01c: b.eq            #0xc6f03c
    // 0xc6f020: LoadField: r4 = r2->field_17
    //     0xc6f020: ldur            w4, [x2, #0x17]
    // 0xc6f024: DecompressPointer r4
    //     0xc6f024: add             x4, x4, HEAP, lsl #32
    // 0xc6f028: r8 = X0
    //     0xc6f028: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc6f02c: LoadField: r9 = r4->field_7
    //     0xc6f02c: ldur            x9, [x4, #7]
    // 0xc6f030: r3 = Null
    //     0xc6f030: add             x3, PP, #0xb, lsl #12  ; [pp+0xb4e0] Null
    //     0xc6f034: ldr             x3, [x3, #0x4e0]
    // 0xc6f038: blr             x9
    // 0xc6f03c: ldr             x0, [fp, #0x18]
    // 0xc6f040: ldur            x16, [fp, #-0x18]
    // 0xc6f044: stp             x16, x0, [SP, #-0x10]!
    // 0xc6f048: r0 = _getValueOrData()
    //     0xc6f048: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc6f04c: add             SP, SP, #0x10
    // 0xc6f050: mov             x1, x0
    // 0xc6f054: ldr             x0, [fp, #0x18]
    // 0xc6f058: LoadField: r2 = r0->field_f
    //     0xc6f058: ldur            w2, [x0, #0xf]
    // 0xc6f05c: DecompressPointer r2
    //     0xc6f05c: add             x2, x2, HEAP, lsl #32
    // 0xc6f060: cmp             w2, w1
    // 0xc6f064: b.ne            #0xc6f070
    // 0xc6f068: r2 = Null
    //     0xc6f068: mov             x2, NULL
    // 0xc6f06c: b               #0xc6f074
    // 0xc6f070: mov             x2, x1
    // 0xc6f074: ldr             x1, [fp, #0x10]
    // 0xc6f078: stur            x2, [fp, #-0x20]
    // 0xc6f07c: ldur            x16, [fp, #-0x18]
    // 0xc6f080: stp             x16, x1, [SP, #-0x10]!
    // 0xc6f084: r0 = _getValueOrData()
    //     0xc6f084: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc6f088: add             SP, SP, #0x10
    // 0xc6f08c: ldr             x1, [fp, #0x10]
    // 0xc6f090: LoadField: r2 = r1->field_f
    //     0xc6f090: ldur            w2, [x1, #0xf]
    // 0xc6f094: DecompressPointer r2
    //     0xc6f094: add             x2, x2, HEAP, lsl #32
    // 0xc6f098: cmp             w2, w0
    // 0xc6f09c: b.ne            #0xc6f0a8
    // 0xc6f0a0: r2 = Null
    //     0xc6f0a0: mov             x2, NULL
    // 0xc6f0a4: b               #0xc6f0ac
    // 0xc6f0a8: mov             x2, x0
    // 0xc6f0ac: ldur            x0, [fp, #-0x20]
    // 0xc6f0b0: r3 = 59
    //     0xc6f0b0: mov             x3, #0x3b
    // 0xc6f0b4: branchIfSmi(r0, 0xc6f0c0)
    //     0xc6f0b4: tbz             w0, #0, #0xc6f0c0
    // 0xc6f0b8: r3 = LoadClassIdInstr(r0)
    //     0xc6f0b8: ldur            x3, [x0, #-1]
    //     0xc6f0bc: ubfx            x3, x3, #0xc, #0x14
    // 0xc6f0c0: stp             x2, x0, [SP, #-0x10]!
    // 0xc6f0c4: mov             x0, x3
    // 0xc6f0c8: mov             lr, x0
    // 0xc6f0cc: ldr             lr, [x21, lr, lsl #3]
    // 0xc6f0d0: blr             lr
    // 0xc6f0d4: add             SP, SP, #0x10
    // 0xc6f0d8: tbz             w0, #4, #0xc6f0ec
    // 0xc6f0dc: r0 = false
    //     0xc6f0dc: add             x0, NULL, #0x30  ; false
    // 0xc6f0e0: LeaveFrame
    //     0xc6f0e0: mov             SP, fp
    //     0xc6f0e4: ldp             fp, lr, [SP], #0x10
    // 0xc6f0e8: ret
    //     0xc6f0e8: ret             
    // 0xc6f0ec: ldur            x0, [fp, #-0x10]
    // 0xc6f0f0: ldur            x2, [fp, #-8]
    // 0xc6f0f4: b               #0xc6efd0
    // 0xc6f0f8: r0 = true
    //     0xc6f0f8: add             x0, NULL, #0x20  ; true
    // 0xc6f0fc: LeaveFrame
    //     0xc6f0fc: mov             SP, fp
    //     0xc6f100: ldp             fp, lr, [SP], #0x10
    // 0xc6f104: ret
    //     0xc6f104: ret             
    // 0xc6f108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6f108: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6f10c: b               #0xc6ef48
    // 0xc6f110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6f110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6f114: b               #0xc6efe4
  }
}

// class id: 4566, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class DBusValue extends Object {

  _ asStringVariantDict(/* No info */) {
    // ** addr: 0xa0e484, size: 0x6c
    // 0xa0e484: EnterFrame
    //     0xa0e484: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e488: mov             fp, SP
    // 0xa0e48c: CheckStackOverflow
    //     0xa0e48c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0e490: cmp             SP, x16
    //     0xa0e494: b.ls            #0xa0e4e8
    // 0xa0e498: ldr             x0, [fp, #0x10]
    // 0xa0e49c: r2 = Null
    //     0xa0e49c: mov             x2, NULL
    // 0xa0e4a0: r1 = Null
    //     0xa0e4a0: mov             x1, NULL
    // 0xa0e4a4: r4 = LoadClassIdInstr(r0)
    //     0xa0e4a4: ldur            x4, [x0, #-1]
    //     0xa0e4a8: ubfx            x4, x4, #0xc, #0x14
    // 0xa0e4ac: r17 = 4567
    //     0xa0e4ac: mov             x17, #0x11d7
    // 0xa0e4b0: cmp             x4, x17
    // 0xa0e4b4: b.eq            #0xa0e4cc
    // 0xa0e4b8: r8 = DBusDict
    //     0xa0e4b8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb490] Type: DBusDict
    //     0xa0e4bc: ldr             x8, [x8, #0x490]
    // 0xa0e4c0: r3 = Null
    //     0xa0e4c0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21170] Null
    //     0xa0e4c4: ldr             x3, [x3, #0x170]
    // 0xa0e4c8: r0 = DefaultTypeTest()
    //     0xa0e4c8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa0e4cc: ldr             x16, [fp, #0x10]
    // 0xa0e4d0: SaveReg r16
    //     0xa0e4d0: str             x16, [SP, #-8]!
    // 0xa0e4d4: r0 = mapStringVariant()
    //     0xa0e4d4: bl              #0xa0e4f0  ; [package:dbus/src/dbus_value.dart] DBusDict::mapStringVariant
    // 0xa0e4d8: add             SP, SP, #8
    // 0xa0e4dc: LeaveFrame
    //     0xa0e4dc: mov             SP, fp
    //     0xa0e4e0: ldp             fp, lr, [SP], #0x10
    // 0xa0e4e4: ret
    //     0xa0e4e4: ret             
    // 0xa0e4e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0e4e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0e4ec: b               #0xa0e498
  }
  _ asStringArray(/* No info */) {
    // ** addr: 0xa0f760, size: 0x6c
    // 0xa0f760: EnterFrame
    //     0xa0f760: stp             fp, lr, [SP, #-0x10]!
    //     0xa0f764: mov             fp, SP
    // 0xa0f768: CheckStackOverflow
    //     0xa0f768: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0f76c: cmp             SP, x16
    //     0xa0f770: b.ls            #0xa0f7c4
    // 0xa0f774: ldr             x0, [fp, #0x10]
    // 0xa0f778: r2 = Null
    //     0xa0f778: mov             x2, NULL
    // 0xa0f77c: r1 = Null
    //     0xa0f77c: mov             x1, NULL
    // 0xa0f780: r4 = LoadClassIdInstr(r0)
    //     0xa0f780: ldur            x4, [x0, #-1]
    //     0xa0f784: ubfx            x4, x4, #0xc, #0x14
    // 0xa0f788: r17 = 4568
    //     0xa0f788: mov             x17, #0x11d8
    // 0xa0f78c: cmp             x4, x17
    // 0xa0f790: b.eq            #0xa0f7a8
    // 0xa0f794: r8 = DBusArray
    //     0xa0f794: add             x8, PP, #0xb, lsl #12  ; [pp+0xb370] Type: DBusArray
    //     0xa0f798: ldr             x8, [x8, #0x370]
    // 0xa0f79c: r3 = Null
    //     0xa0f79c: add             x3, PP, #0x21, lsl #12  ; [pp+0x211e0] Null
    //     0xa0f7a0: ldr             x3, [x3, #0x1e0]
    // 0xa0f7a4: r0 = DefaultTypeTest()
    //     0xa0f7a4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa0f7a8: ldr             x16, [fp, #0x10]
    // 0xa0f7ac: SaveReg r16
    //     0xa0f7ac: str             x16, [SP, #-8]!
    // 0xa0f7b0: r0 = mapString()
    //     0xa0f7b0: bl              #0xa0f7cc  ; [package:dbus/src/dbus_value.dart] DBusArray::mapString
    // 0xa0f7b4: add             SP, SP, #8
    // 0xa0f7b8: LeaveFrame
    //     0xa0f7b8: mov             SP, fp
    //     0xa0f7bc: ldp             fp, lr, [SP], #0x10
    // 0xa0f7c0: ret
    //     0xa0f7c0: ret             
    // 0xa0f7c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0f7c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0f7c8: b               #0xa0f774
  }
}

// class id: 4567, size: 0x14, field offset: 0x8
//   const constructor, 
class DBusDict extends DBusValue {

  _ DBusDict(/* No info */) {
    // ** addr: 0xa09e5c, size: 0x174
    // 0xa09e5c: EnterFrame
    //     0xa09e5c: stp             fp, lr, [SP, #-0x10]!
    //     0xa09e60: mov             fp, SP
    // 0xa09e64: AllocStack(0x8)
    //     0xa09e64: sub             SP, SP, #8
    // 0xa09e68: CheckStackOverflow
    //     0xa09e68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa09e6c: cmp             SP, x16
    //     0xa09e70: b.ls            #0xa09fc8
    // 0xa09e74: r1 = 1
    //     0xa09e74: mov             x1, #1
    // 0xa09e78: r0 = AllocateContext()
    //     0xa09e78: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa09e7c: mov             x2, x0
    // 0xa09e80: ldr             x1, [fp, #0x28]
    // 0xa09e84: stur            x2, [fp, #-8]
    // 0xa09e88: StoreField: r2->field_f = r1
    //     0xa09e88: stur            w1, [x2, #0xf]
    // 0xa09e8c: ldr             x0, [fp, #0x20]
    // 0xa09e90: StoreField: r1->field_7 = r0
    //     0xa09e90: stur            w0, [x1, #7]
    //     0xa09e94: ldurb           w16, [x1, #-1]
    //     0xa09e98: ldurb           w17, [x0, #-1]
    //     0xa09e9c: and             x16, x17, x16, lsr #2
    //     0xa09ea0: tst             x16, HEAP, lsr #32
    //     0xa09ea4: b.eq            #0xa09eac
    //     0xa09ea8: bl              #0xd6826c
    // 0xa09eac: ldr             x0, [fp, #0x18]
    // 0xa09eb0: StoreField: r1->field_b = r0
    //     0xa09eb0: stur            w0, [x1, #0xb]
    //     0xa09eb4: ldurb           w16, [x1, #-1]
    //     0xa09eb8: ldurb           w17, [x0, #-1]
    //     0xa09ebc: and             x16, x17, x16, lsr #2
    //     0xa09ec0: tst             x16, HEAP, lsr #32
    //     0xa09ec4: b.eq            #0xa09ecc
    //     0xa09ec8: bl              #0xd6826c
    // 0xa09ecc: ldr             x0, [fp, #0x10]
    // 0xa09ed0: StoreField: r1->field_f = r0
    //     0xa09ed0: stur            w0, [x1, #0xf]
    //     0xa09ed4: ldurb           w16, [x1, #-1]
    //     0xa09ed8: ldurb           w17, [x0, #-1]
    //     0xa09edc: and             x16, x17, x16, lsr #2
    //     0xa09ee0: tst             x16, HEAP, lsr #32
    //     0xa09ee4: b.eq            #0xa09eec
    //     0xa09ee8: bl              #0xd6826c
    // 0xa09eec: ldr             x16, [fp, #0x20]
    // 0xa09ef0: SaveReg r16
    //     0xa09ef0: str             x16, [SP, #-8]!
    // 0xa09ef4: r0 = isSingleCompleteType()
    //     0xa09ef4: bl              #0xa004ec  ; [package:dbus/src/dbus_value.dart] DBusSignature::isSingleCompleteType
    // 0xa09ef8: add             SP, SP, #8
    // 0xa09efc: tbnz            w0, #4, #0xa09f48
    // 0xa09f00: r0 = true
    //     0xa09f00: add             x0, NULL, #0x20  ; true
    // 0xa09f04: ldr             x16, [fp, #0x18]
    // 0xa09f08: SaveReg r16
    //     0xa09f08: str             x16, [SP, #-8]!
    // 0xa09f0c: r0 = isSingleCompleteType()
    //     0xa09f0c: bl              #0xa004ec  ; [package:dbus/src/dbus_value.dart] DBusSignature::isSingleCompleteType
    // 0xa09f10: add             SP, SP, #8
    // 0xa09f14: tbnz            w0, #4, #0xa09f88
    // 0xa09f18: ldur            x2, [fp, #-8]
    // 0xa09f1c: r1 = Function '<anonymous closure>':.
    //     0xa09f1c: add             x1, PP, #8, lsl #12  ; [pp+0x8170] AnonymousClosure: (0xa09fd0), in [package:dbus/src/dbus_value.dart] DBusDict::DBusDict (0xa09e5c)
    //     0xa09f20: ldr             x1, [x1, #0x170]
    // 0xa09f24: r0 = AllocateClosure()
    //     0xa09f24: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa09f28: ldr             x16, [fp, #0x10]
    // 0xa09f2c: stp             x0, x16, [SP, #-0x10]!
    // 0xa09f30: r0 = forEach()
    //     0xa09f30: bl              #0xca3d28  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0xa09f34: add             SP, SP, #0x10
    // 0xa09f38: r0 = Null
    //     0xa09f38: mov             x0, NULL
    // 0xa09f3c: LeaveFrame
    //     0xa09f3c: mov             SP, fp
    //     0xa09f40: ldp             fp, lr, [SP], #0x10
    // 0xa09f44: ret
    //     0xa09f44: ret             
    // 0xa09f48: ldr             x0, [fp, #0x20]
    // 0xa09f4c: r0 = ArgumentError()
    //     0xa09f4c: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xa09f50: mov             x1, x0
    // 0xa09f54: r0 = "keySignature"
    //     0xa09f54: add             x0, PP, #8, lsl #12  ; [pp+0x8178] "keySignature"
    //     0xa09f58: ldr             x0, [x0, #0x178]
    // 0xa09f5c: StoreField: r1->field_13 = r0
    //     0xa09f5c: stur            w0, [x1, #0x13]
    // 0xa09f60: r0 = "Dict key type must be a single complete type"
    //     0xa09f60: add             x0, PP, #8, lsl #12  ; [pp+0x8180] "Dict key type must be a single complete type"
    //     0xa09f64: ldr             x0, [x0, #0x180]
    // 0xa09f68: StoreField: r1->field_17 = r0
    //     0xa09f68: stur            w0, [x1, #0x17]
    // 0xa09f6c: ldr             x0, [fp, #0x20]
    // 0xa09f70: StoreField: r1->field_f = r0
    //     0xa09f70: stur            w0, [x1, #0xf]
    // 0xa09f74: r0 = true
    //     0xa09f74: add             x0, NULL, #0x20  ; true
    // 0xa09f78: StoreField: r1->field_b = r0
    //     0xa09f78: stur            w0, [x1, #0xb]
    // 0xa09f7c: mov             x0, x1
    // 0xa09f80: r0 = Throw()
    //     0xa09f80: bl              #0xd67e38  ; ThrowStub
    // 0xa09f84: brk             #0
    // 0xa09f88: ldr             x0, [fp, #0x18]
    // 0xa09f8c: r0 = ArgumentError()
    //     0xa09f8c: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xa09f90: mov             x1, x0
    // 0xa09f94: r0 = "valueSignature"
    //     0xa09f94: add             x0, PP, #8, lsl #12  ; [pp+0x8188] "valueSignature"
    //     0xa09f98: ldr             x0, [x0, #0x188]
    // 0xa09f9c: StoreField: r1->field_13 = r0
    //     0xa09f9c: stur            w0, [x1, #0x13]
    // 0xa09fa0: r0 = "Dict value type must be a single complete type"
    //     0xa09fa0: add             x0, PP, #8, lsl #12  ; [pp+0x8190] "Dict value type must be a single complete type"
    //     0xa09fa4: ldr             x0, [x0, #0x190]
    // 0xa09fa8: StoreField: r1->field_17 = r0
    //     0xa09fa8: stur            w0, [x1, #0x17]
    // 0xa09fac: ldr             x0, [fp, #0x18]
    // 0xa09fb0: StoreField: r1->field_f = r0
    //     0xa09fb0: stur            w0, [x1, #0xf]
    // 0xa09fb4: r0 = true
    //     0xa09fb4: add             x0, NULL, #0x20  ; true
    // 0xa09fb8: StoreField: r1->field_b = r0
    //     0xa09fb8: stur            w0, [x1, #0xb]
    // 0xa09fbc: mov             x0, x1
    // 0xa09fc0: r0 = Throw()
    //     0xa09fc0: bl              #0xd67e38  ; ThrowStub
    // 0xa09fc4: brk             #0
    // 0xa09fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa09fc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa09fcc: b               #0xa09e74
  }
  [closure] void <anonymous closure>(dynamic, DBusValue, DBusValue) {
    // ** addr: 0xa09fd0, size: 0x21c
    // 0xa09fd0: EnterFrame
    //     0xa09fd0: stp             fp, lr, [SP, #-0x10]!
    //     0xa09fd4: mov             fp, SP
    // 0xa09fd8: AllocStack(0x10)
    //     0xa09fd8: sub             SP, SP, #0x10
    // 0xa09fdc: SetupParameters()
    //     0xa09fdc: ldr             x0, [fp, #0x20]
    //     0xa09fe0: ldur            w1, [x0, #0x17]
    //     0xa09fe4: add             x1, x1, HEAP, lsl #32
    //     0xa09fe8: stur            x1, [fp, #-8]
    // 0xa09fec: CheckStackOverflow
    //     0xa09fec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa09ff0: cmp             SP, x16
    //     0xa09ff4: b.ls            #0xa0a1e4
    // 0xa09ff8: ldr             x2, [fp, #0x18]
    // 0xa09ffc: r0 = LoadClassIdInstr(r2)
    //     0xa09ffc: ldur            x0, [x2, #-1]
    //     0xa0a000: ubfx            x0, x0, #0xc, #0x14
    // 0xa0a004: SaveReg r2
    //     0xa0a004: str             x2, [SP, #-8]!
    // 0xa0a008: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa0a008: add             lr, x0, #0x2b8
    //     0xa0a00c: ldr             lr, [x21, lr, lsl #3]
    //     0xa0a010: blr             lr
    // 0xa0a014: add             SP, SP, #8
    // 0xa0a018: LoadField: r1 = r0->field_7
    //     0xa0a018: ldur            w1, [x0, #7]
    // 0xa0a01c: DecompressPointer r1
    //     0xa0a01c: add             x1, x1, HEAP, lsl #32
    // 0xa0a020: ldur            x2, [fp, #-8]
    // 0xa0a024: LoadField: r0 = r2->field_f
    //     0xa0a024: ldur            w0, [x2, #0xf]
    // 0xa0a028: DecompressPointer r0
    //     0xa0a028: add             x0, x0, HEAP, lsl #32
    // 0xa0a02c: LoadField: r3 = r0->field_7
    //     0xa0a02c: ldur            w3, [x0, #7]
    // 0xa0a030: DecompressPointer r3
    //     0xa0a030: add             x3, x3, HEAP, lsl #32
    // 0xa0a034: LoadField: r0 = r3->field_7
    //     0xa0a034: ldur            w0, [x3, #7]
    // 0xa0a038: DecompressPointer r0
    //     0xa0a038: add             x0, x0, HEAP, lsl #32
    // 0xa0a03c: r3 = LoadClassIdInstr(r1)
    //     0xa0a03c: ldur            x3, [x1, #-1]
    //     0xa0a040: ubfx            x3, x3, #0xc, #0x14
    // 0xa0a044: stp             x0, x1, [SP, #-0x10]!
    // 0xa0a048: mov             x0, x3
    // 0xa0a04c: mov             lr, x0
    // 0xa0a050: ldr             lr, [x21, lr, lsl #3]
    // 0xa0a054: blr             lr
    // 0xa0a058: add             SP, SP, #0x10
    // 0xa0a05c: tbnz            w0, #4, #0xa0a0e4
    // 0xa0a060: ldr             x4, [fp, #0x10]
    // 0xa0a064: ldur            x1, [fp, #-8]
    // 0xa0a068: r3 = true
    //     0xa0a068: add             x3, NULL, #0x20  ; true
    // 0xa0a06c: r2 = "children"
    //     0xa0a06c: ldr             x2, [PP, #0x7868]  ; [pp+0x7868] "children"
    // 0xa0a070: r0 = LoadClassIdInstr(r4)
    //     0xa0a070: ldur            x0, [x4, #-1]
    //     0xa0a074: ubfx            x0, x0, #0xc, #0x14
    // 0xa0a078: SaveReg r4
    //     0xa0a078: str             x4, [SP, #-8]!
    // 0xa0a07c: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa0a07c: add             lr, x0, #0x2b8
    //     0xa0a080: ldr             lr, [x21, lr, lsl #3]
    //     0xa0a084: blr             lr
    // 0xa0a088: add             SP, SP, #8
    // 0xa0a08c: LoadField: r1 = r0->field_7
    //     0xa0a08c: ldur            w1, [x0, #7]
    // 0xa0a090: DecompressPointer r1
    //     0xa0a090: add             x1, x1, HEAP, lsl #32
    // 0xa0a094: ldur            x2, [fp, #-8]
    // 0xa0a098: LoadField: r0 = r2->field_f
    //     0xa0a098: ldur            w0, [x2, #0xf]
    // 0xa0a09c: DecompressPointer r0
    //     0xa0a09c: add             x0, x0, HEAP, lsl #32
    // 0xa0a0a0: LoadField: r3 = r0->field_b
    //     0xa0a0a0: ldur            w3, [x0, #0xb]
    // 0xa0a0a4: DecompressPointer r3
    //     0xa0a0a4: add             x3, x3, HEAP, lsl #32
    // 0xa0a0a8: LoadField: r0 = r3->field_7
    //     0xa0a0a8: ldur            w0, [x3, #7]
    // 0xa0a0ac: DecompressPointer r0
    //     0xa0a0ac: add             x0, x0, HEAP, lsl #32
    // 0xa0a0b0: r3 = LoadClassIdInstr(r1)
    //     0xa0a0b0: ldur            x3, [x1, #-1]
    //     0xa0a0b4: ubfx            x3, x3, #0xc, #0x14
    // 0xa0a0b8: stp             x0, x1, [SP, #-0x10]!
    // 0xa0a0bc: mov             x0, x3
    // 0xa0a0c0: mov             lr, x0
    // 0xa0a0c4: ldr             lr, [x21, lr, lsl #3]
    // 0xa0a0c8: blr             lr
    // 0xa0a0cc: add             SP, SP, #0x10
    // 0xa0a0d0: tbnz            w0, #4, #0xa0a160
    // 0xa0a0d4: r0 = Null
    //     0xa0a0d4: mov             x0, NULL
    // 0xa0a0d8: LeaveFrame
    //     0xa0a0d8: mov             SP, fp
    //     0xa0a0dc: ldp             fp, lr, [SP], #0x10
    // 0xa0a0e0: ret
    //     0xa0a0e0: ret             
    // 0xa0a0e4: ldr             x3, [fp, #0x18]
    // 0xa0a0e8: ldur            x0, [fp, #-8]
    // 0xa0a0ec: r1 = Null
    //     0xa0a0ec: mov             x1, NULL
    // 0xa0a0f0: r2 = 4
    //     0xa0a0f0: mov             x2, #4
    // 0xa0a0f4: r0 = AllocateArray()
    //     0xa0a0f4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0a0f8: r17 = "Provided key doesn\'t match signature "
    //     0xa0a0f8: add             x17, PP, #8, lsl #12  ; [pp+0x8198] "Provided key doesn\'t match signature "
    //     0xa0a0fc: ldr             x17, [x17, #0x198]
    // 0xa0a100: StoreField: r0->field_f = r17
    //     0xa0a100: stur            w17, [x0, #0xf]
    // 0xa0a104: ldur            x1, [fp, #-8]
    // 0xa0a108: LoadField: r2 = r1->field_f
    //     0xa0a108: ldur            w2, [x1, #0xf]
    // 0xa0a10c: DecompressPointer r2
    //     0xa0a10c: add             x2, x2, HEAP, lsl #32
    // 0xa0a110: LoadField: r1 = r2->field_7
    //     0xa0a110: ldur            w1, [x2, #7]
    // 0xa0a114: DecompressPointer r1
    //     0xa0a114: add             x1, x1, HEAP, lsl #32
    // 0xa0a118: LoadField: r2 = r1->field_7
    //     0xa0a118: ldur            w2, [x1, #7]
    // 0xa0a11c: DecompressPointer r2
    //     0xa0a11c: add             x2, x2, HEAP, lsl #32
    // 0xa0a120: StoreField: r0->field_13 = r2
    //     0xa0a120: stur            w2, [x0, #0x13]
    // 0xa0a124: SaveReg r0
    //     0xa0a124: str             x0, [SP, #-8]!
    // 0xa0a128: r0 = _interpolate()
    //     0xa0a128: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0a12c: add             SP, SP, #8
    // 0xa0a130: stur            x0, [fp, #-0x10]
    // 0xa0a134: r0 = ArgumentError()
    //     0xa0a134: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xa0a138: r2 = "children"
    //     0xa0a138: ldr             x2, [PP, #0x7868]  ; [pp+0x7868] "children"
    // 0xa0a13c: StoreField: r0->field_13 = r2
    //     0xa0a13c: stur            w2, [x0, #0x13]
    // 0xa0a140: ldur            x1, [fp, #-0x10]
    // 0xa0a144: StoreField: r0->field_17 = r1
    //     0xa0a144: stur            w1, [x0, #0x17]
    // 0xa0a148: ldr             x1, [fp, #0x18]
    // 0xa0a14c: StoreField: r0->field_f = r1
    //     0xa0a14c: stur            w1, [x0, #0xf]
    // 0xa0a150: r3 = true
    //     0xa0a150: add             x3, NULL, #0x20  ; true
    // 0xa0a154: StoreField: r0->field_b = r3
    //     0xa0a154: stur            w3, [x0, #0xb]
    // 0xa0a158: r0 = Throw()
    //     0xa0a158: bl              #0xd67e38  ; ThrowStub
    // 0xa0a15c: brk             #0
    // 0xa0a160: ldr             x3, [fp, #0x10]
    // 0xa0a164: ldur            x0, [fp, #-8]
    // 0xa0a168: r1 = Null
    //     0xa0a168: mov             x1, NULL
    // 0xa0a16c: r2 = 4
    //     0xa0a16c: mov             x2, #4
    // 0xa0a170: r0 = AllocateArray()
    //     0xa0a170: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0a174: r17 = "Provided value doesn\'t match signature "
    //     0xa0a174: add             x17, PP, #8, lsl #12  ; [pp+0x81a0] "Provided value doesn\'t match signature "
    //     0xa0a178: ldr             x17, [x17, #0x1a0]
    // 0xa0a17c: StoreField: r0->field_f = r17
    //     0xa0a17c: stur            w17, [x0, #0xf]
    // 0xa0a180: ldur            x1, [fp, #-8]
    // 0xa0a184: LoadField: r2 = r1->field_f
    //     0xa0a184: ldur            w2, [x1, #0xf]
    // 0xa0a188: DecompressPointer r2
    //     0xa0a188: add             x2, x2, HEAP, lsl #32
    // 0xa0a18c: LoadField: r1 = r2->field_b
    //     0xa0a18c: ldur            w1, [x2, #0xb]
    // 0xa0a190: DecompressPointer r1
    //     0xa0a190: add             x1, x1, HEAP, lsl #32
    // 0xa0a194: LoadField: r2 = r1->field_7
    //     0xa0a194: ldur            w2, [x1, #7]
    // 0xa0a198: DecompressPointer r2
    //     0xa0a198: add             x2, x2, HEAP, lsl #32
    // 0xa0a19c: StoreField: r0->field_13 = r2
    //     0xa0a19c: stur            w2, [x0, #0x13]
    // 0xa0a1a0: SaveReg r0
    //     0xa0a1a0: str             x0, [SP, #-8]!
    // 0xa0a1a4: r0 = _interpolate()
    //     0xa0a1a4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0a1a8: add             SP, SP, #8
    // 0xa0a1ac: stur            x0, [fp, #-8]
    // 0xa0a1b0: r0 = ArgumentError()
    //     0xa0a1b0: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xa0a1b4: mov             x1, x0
    // 0xa0a1b8: r0 = "children"
    //     0xa0a1b8: ldr             x0, [PP, #0x7868]  ; [pp+0x7868] "children"
    // 0xa0a1bc: StoreField: r1->field_13 = r0
    //     0xa0a1bc: stur            w0, [x1, #0x13]
    // 0xa0a1c0: ldur            x0, [fp, #-8]
    // 0xa0a1c4: StoreField: r1->field_17 = r0
    //     0xa0a1c4: stur            w0, [x1, #0x17]
    // 0xa0a1c8: ldr             x0, [fp, #0x10]
    // 0xa0a1cc: StoreField: r1->field_f = r0
    //     0xa0a1cc: stur            w0, [x1, #0xf]
    // 0xa0a1d0: r0 = true
    //     0xa0a1d0: add             x0, NULL, #0x20  ; true
    // 0xa0a1d4: StoreField: r1->field_b = r0
    //     0xa0a1d4: stur            w0, [x1, #0xb]
    // 0xa0a1d8: mov             x0, x1
    // 0xa0a1dc: r0 = Throw()
    //     0xa0a1dc: bl              #0xd67e38  ; ThrowStub
    // 0xa0a1e0: brk             #0
    // 0xa0a1e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0a1e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0a1e8: b               #0xa09ff8
  }
  _ mapStringVariant(/* No info */) {
    // ** addr: 0xa0e4f0, size: 0x70
    // 0xa0e4f0: EnterFrame
    //     0xa0e4f0: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e4f4: mov             fp, SP
    // 0xa0e4f8: AllocStack(0x8)
    //     0xa0e4f8: sub             SP, SP, #8
    // 0xa0e4fc: CheckStackOverflow
    //     0xa0e4fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0e500: cmp             SP, x16
    //     0xa0e504: b.ls            #0xa0e558
    // 0xa0e508: ldr             x0, [fp, #0x10]
    // 0xa0e50c: LoadField: r3 = r0->field_f
    //     0xa0e50c: ldur            w3, [x0, #0xf]
    // 0xa0e510: DecompressPointer r3
    //     0xa0e510: add             x3, x3, HEAP, lsl #32
    // 0xa0e514: stur            x3, [fp, #-8]
    // 0xa0e518: r1 = Function '<anonymous closure>':.
    //     0xa0e518: add             x1, PP, #0x21, lsl #12  ; [pp+0x21180] AnonymousClosure: (0xa0e560), in [package:dbus/src/dbus_value.dart] DBusDict::mapStringVariant (0xa0e4f0)
    //     0xa0e51c: ldr             x1, [x1, #0x180]
    // 0xa0e520: r2 = Null
    //     0xa0e520: mov             x2, NULL
    // 0xa0e524: r0 = AllocateClosure()
    //     0xa0e524: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0e528: r16 = <String, DBusValue>
    //     0xa0e528: add             x16, PP, #0x21, lsl #12  ; [pp+0x21188] TypeArguments: <String, DBusValue>
    //     0xa0e52c: ldr             x16, [x16, #0x188]
    // 0xa0e530: ldur            lr, [fp, #-8]
    // 0xa0e534: stp             lr, x16, [SP, #-0x10]!
    // 0xa0e538: SaveReg r0
    //     0xa0e538: str             x0, [SP, #-8]!
    // 0xa0e53c: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xa0e53c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0xa0e540: ldr             x4, [x4, #0x4d8]
    // 0xa0e544: r0 = map()
    //     0xa0e544: bl              #0xc7ae6c  ; [dart:collection] __Map&_HashVMBase&MapMixin::map
    // 0xa0e548: add             SP, SP, #0x18
    // 0xa0e54c: LeaveFrame
    //     0xa0e54c: mov             SP, fp
    //     0xa0e550: ldp             fp, lr, [SP], #0x10
    // 0xa0e554: ret
    //     0xa0e554: ret             
    // 0xa0e558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0e558: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0e55c: b               #0xa0e508
  }
  [closure] MapEntry<String, DBusValue> <anonymous closure>(dynamic, DBusValue, DBusValue) {
    // ** addr: 0xa0e560, size: 0xb8
    // 0xa0e560: EnterFrame
    //     0xa0e560: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e564: mov             fp, SP
    // 0xa0e568: AllocStack(0x10)
    //     0xa0e568: sub             SP, SP, #0x10
    // 0xa0e56c: ldr             x0, [fp, #0x18]
    // 0xa0e570: r2 = Null
    //     0xa0e570: mov             x2, NULL
    // 0xa0e574: r1 = Null
    //     0xa0e574: mov             x1, NULL
    // 0xa0e578: r4 = LoadClassIdInstr(r0)
    //     0xa0e578: ldur            x4, [x0, #-1]
    //     0xa0e57c: ubfx            x4, x4, #0xc, #0x14
    // 0xa0e580: r17 = -4573
    //     0xa0e580: mov             x17, #-0x11dd
    // 0xa0e584: add             x4, x4, x17
    // 0xa0e588: cmp             x4, #1
    // 0xa0e58c: b.ls            #0xa0e5a0
    // 0xa0e590: r8 = DBusString
    //     0xa0e590: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa0e594: r3 = Null
    //     0xa0e594: add             x3, PP, #0x21, lsl #12  ; [pp+0x21190] Null
    //     0xa0e598: ldr             x3, [x3, #0x190]
    // 0xa0e59c: r0 = DefaultTypeTest()
    //     0xa0e59c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa0e5a0: ldr             x0, [fp, #0x18]
    // 0xa0e5a4: LoadField: r3 = r0->field_7
    //     0xa0e5a4: ldur            w3, [x0, #7]
    // 0xa0e5a8: DecompressPointer r3
    //     0xa0e5a8: add             x3, x3, HEAP, lsl #32
    // 0xa0e5ac: ldr             x0, [fp, #0x10]
    // 0xa0e5b0: stur            x3, [fp, #-8]
    // 0xa0e5b4: r2 = Null
    //     0xa0e5b4: mov             x2, NULL
    // 0xa0e5b8: r1 = Null
    //     0xa0e5b8: mov             x1, NULL
    // 0xa0e5bc: r4 = LoadClassIdInstr(r0)
    //     0xa0e5bc: ldur            x4, [x0, #-1]
    //     0xa0e5c0: ubfx            x4, x4, #0xc, #0x14
    // 0xa0e5c4: r17 = 4571
    //     0xa0e5c4: mov             x17, #0x11db
    // 0xa0e5c8: cmp             x4, x17
    // 0xa0e5cc: b.eq            #0xa0e5e0
    // 0xa0e5d0: r8 = DBusVariant
    //     0xa0e5d0: ldr             x8, [PP, #0x7fc0]  ; [pp+0x7fc0] Type: DBusVariant
    // 0xa0e5d4: r3 = Null
    //     0xa0e5d4: add             x3, PP, #0x21, lsl #12  ; [pp+0x211a0] Null
    //     0xa0e5d8: ldr             x3, [x3, #0x1a0]
    // 0xa0e5dc: r0 = DefaultTypeTest()
    //     0xa0e5dc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa0e5e0: ldr             x0, [fp, #0x10]
    // 0xa0e5e4: LoadField: r2 = r0->field_7
    //     0xa0e5e4: ldur            w2, [x0, #7]
    // 0xa0e5e8: DecompressPointer r2
    //     0xa0e5e8: add             x2, x2, HEAP, lsl #32
    // 0xa0e5ec: stur            x2, [fp, #-0x10]
    // 0xa0e5f0: r1 = <String, DBusValue>
    //     0xa0e5f0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21188] TypeArguments: <String, DBusValue>
    //     0xa0e5f4: ldr             x1, [x1, #0x188]
    // 0xa0e5f8: r0 = MapEntry()
    //     0xa0e5f8: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xa0e5fc: ldur            x1, [fp, #-8]
    // 0xa0e600: StoreField: r0->field_b = r1
    //     0xa0e600: stur            w1, [x0, #0xb]
    // 0xa0e604: ldur            x1, [fp, #-0x10]
    // 0xa0e608: StoreField: r0->field_f = r1
    //     0xa0e608: stur            w1, [x0, #0xf]
    // 0xa0e60c: LeaveFrame
    //     0xa0e60c: mov             SP, fp
    //     0xa0e610: ldp             fp, lr, [SP], #0x10
    // 0xa0e614: ret
    //     0xa0e614: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xad2d8c, size: 0x274
    // 0xad2d8c: EnterFrame
    //     0xad2d8c: stp             fp, lr, [SP, #-0x10]!
    //     0xad2d90: mov             fp, SP
    // 0xad2d94: AllocStack(0x10)
    //     0xad2d94: sub             SP, SP, #0x10
    // 0xad2d98: CheckStackOverflow
    //     0xad2d98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad2d9c: cmp             SP, x16
    //     0xad2da0: b.ls            #0xad2ff8
    // 0xad2da4: ldr             x1, [fp, #0x10]
    // 0xad2da8: LoadField: r2 = r1->field_7
    //     0xad2da8: ldur            w2, [x1, #7]
    // 0xad2dac: DecompressPointer r2
    //     0xad2dac: add             x2, x2, HEAP, lsl #32
    // 0xad2db0: stur            x2, [fp, #-8]
    // 0xad2db4: LoadField: r0 = r2->field_7
    //     0xad2db4: ldur            w0, [x2, #7]
    // 0xad2db8: DecompressPointer r0
    //     0xad2db8: add             x0, x0, HEAP, lsl #32
    // 0xad2dbc: r3 = LoadClassIdInstr(r0)
    //     0xad2dbc: ldur            x3, [x0, #-1]
    //     0xad2dc0: ubfx            x3, x3, #0xc, #0x14
    // 0xad2dc4: r16 = "s"
    //     0xad2dc4: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xad2dc8: stp             x16, x0, [SP, #-0x10]!
    // 0xad2dcc: mov             x0, x3
    // 0xad2dd0: mov             lr, x0
    // 0xad2dd4: ldr             lr, [x21, lr, lsl #3]
    // 0xad2dd8: blr             lr
    // 0xad2ddc: add             SP, SP, #0x10
    // 0xad2de0: tbnz            w0, #4, #0xad2ec8
    // 0xad2de4: ldr             x1, [fp, #0x10]
    // 0xad2de8: LoadField: r0 = r1->field_b
    //     0xad2de8: ldur            w0, [x1, #0xb]
    // 0xad2dec: DecompressPointer r0
    //     0xad2dec: add             x0, x0, HEAP, lsl #32
    // 0xad2df0: LoadField: r2 = r0->field_7
    //     0xad2df0: ldur            w2, [x0, #7]
    // 0xad2df4: DecompressPointer r2
    //     0xad2df4: add             x2, x2, HEAP, lsl #32
    // 0xad2df8: r0 = LoadClassIdInstr(r2)
    //     0xad2df8: ldur            x0, [x2, #-1]
    //     0xad2dfc: ubfx            x0, x0, #0xc, #0x14
    // 0xad2e00: r16 = "v"
    //     0xad2e00: ldr             x16, [PP, #0x7910]  ; [pp+0x7910] "v"
    // 0xad2e04: stp             x16, x2, [SP, #-0x10]!
    // 0xad2e08: mov             lr, x0
    // 0xad2e0c: ldr             lr, [x21, lr, lsl #3]
    // 0xad2e10: blr             lr
    // 0xad2e14: add             SP, SP, #0x10
    // 0xad2e18: tbnz            w0, #4, #0xad2ec0
    // 0xad2e1c: ldr             x0, [fp, #0x10]
    // 0xad2e20: LoadField: r1 = r0->field_f
    //     0xad2e20: ldur            w1, [x0, #0xf]
    // 0xad2e24: DecompressPointer r1
    //     0xad2e24: add             x1, x1, HEAP, lsl #32
    // 0xad2e28: SaveReg r1
    //     0xad2e28: str             x1, [SP, #-8]!
    // 0xad2e2c: r0 = entries()
    //     0xad2e2c: bl              #0xc761a0  ; [dart:collection] __Map&_HashVMBase&MapMixin::entries
    // 0xad2e30: add             SP, SP, #8
    // 0xad2e34: r1 = Function '<anonymous closure>':.
    //     0xad2e34: add             x1, PP, #0xb, lsl #12  ; [pp+0xb468] AnonymousClosure: (0xad32c8), in [package:dbus/src/dbus_value.dart] DBusDict::toString (0xad2d8c)
    //     0xad2e38: ldr             x1, [x1, #0x468]
    // 0xad2e3c: r2 = Null
    //     0xad2e3c: mov             x2, NULL
    // 0xad2e40: stur            x0, [fp, #-0x10]
    // 0xad2e44: r0 = AllocateClosure()
    //     0xad2e44: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad2e48: r16 = <String>
    //     0xad2e48: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad2e4c: ldur            lr, [fp, #-0x10]
    // 0xad2e50: stp             lr, x16, [SP, #-0x10]!
    // 0xad2e54: SaveReg r0
    //     0xad2e54: str             x0, [SP, #-8]!
    // 0xad2e58: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad2e58: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad2e5c: r0 = map()
    //     0xad2e5c: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0xad2e60: add             SP, SP, #0x18
    // 0xad2e64: r16 = ", "
    //     0xad2e64: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad2e68: stp             x16, x0, [SP, #-0x10]!
    // 0xad2e6c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad2e6c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad2e70: r0 = join()
    //     0xad2e70: bl              #0x6a9d88  ; [dart:core] Iterable::join
    // 0xad2e74: add             SP, SP, #0x10
    // 0xad2e78: r1 = Null
    //     0xad2e78: mov             x1, NULL
    // 0xad2e7c: r2 = 6
    //     0xad2e7c: mov             x2, #6
    // 0xad2e80: stur            x0, [fp, #-0x10]
    // 0xad2e84: r0 = AllocateArray()
    //     0xad2e84: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad2e88: r17 = "DBusDict.stringVariant({"
    //     0xad2e88: add             x17, PP, #0xb, lsl #12  ; [pp+0xb470] "DBusDict.stringVariant({"
    //     0xad2e8c: ldr             x17, [x17, #0x470]
    // 0xad2e90: StoreField: r0->field_f = r17
    //     0xad2e90: stur            w17, [x0, #0xf]
    // 0xad2e94: ldur            x1, [fp, #-0x10]
    // 0xad2e98: StoreField: r0->field_13 = r1
    //     0xad2e98: stur            w1, [x0, #0x13]
    // 0xad2e9c: r17 = "})"
    //     0xad2e9c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb478] "})"
    //     0xad2ea0: ldr             x17, [x17, #0x478]
    // 0xad2ea4: StoreField: r0->field_17 = r17
    //     0xad2ea4: stur            w17, [x0, #0x17]
    // 0xad2ea8: SaveReg r0
    //     0xad2ea8: str             x0, [SP, #-8]!
    // 0xad2eac: r0 = _interpolate()
    //     0xad2eac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad2eb0: add             SP, SP, #8
    // 0xad2eb4: LeaveFrame
    //     0xad2eb4: mov             SP, fp
    //     0xad2eb8: ldp             fp, lr, [SP], #0x10
    // 0xad2ebc: ret
    //     0xad2ebc: ret             
    // 0xad2ec0: ldr             x0, [fp, #0x10]
    // 0xad2ec4: b               #0xad2ecc
    // 0xad2ec8: ldr             x0, [fp, #0x10]
    // 0xad2ecc: ldur            x1, [fp, #-8]
    // 0xad2ed0: r16 = <String>
    //     0xad2ed0: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad2ed4: stp             xzr, x16, [SP, #-0x10]!
    // 0xad2ed8: r0 = _GrowableList()
    //     0xad2ed8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xad2edc: add             SP, SP, #0x10
    // 0xad2ee0: stur            x0, [fp, #-0x10]
    // 0xad2ee4: r1 = 1
    //     0xad2ee4: mov             x1, #1
    // 0xad2ee8: r0 = AllocateContext()
    //     0xad2ee8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad2eec: mov             x1, x0
    // 0xad2ef0: ldur            x0, [fp, #-0x10]
    // 0xad2ef4: StoreField: r1->field_f = r0
    //     0xad2ef4: stur            w0, [x1, #0xf]
    // 0xad2ef8: ldr             x0, [fp, #0x10]
    // 0xad2efc: LoadField: r3 = r0->field_f
    //     0xad2efc: ldur            w3, [x0, #0xf]
    // 0xad2f00: DecompressPointer r3
    //     0xad2f00: add             x3, x3, HEAP, lsl #32
    // 0xad2f04: mov             x2, x1
    // 0xad2f08: stur            x3, [fp, #-0x10]
    // 0xad2f0c: r1 = Function '<anonymous closure>':.
    //     0xad2f0c: add             x1, PP, #0xb, lsl #12  ; [pp+0xb480] AnonymousClosure: (0xad3130), in [package:dbus/src/dbus_value.dart] DBusDict::toString (0xad2d8c)
    //     0xad2f10: ldr             x1, [x1, #0x480]
    // 0xad2f14: r0 = AllocateClosure()
    //     0xad2f14: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad2f18: ldur            x16, [fp, #-0x10]
    // 0xad2f1c: stp             x0, x16, [SP, #-0x10]!
    // 0xad2f20: r0 = forEach()
    //     0xad2f20: bl              #0xca3d28  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0xad2f24: add             SP, SP, #0x10
    // 0xad2f28: ldur            x16, [fp, #-0x10]
    // 0xad2f2c: SaveReg r16
    //     0xad2f2c: str             x16, [SP, #-8]!
    // 0xad2f30: r0 = entries()
    //     0xad2f30: bl              #0xc761a0  ; [dart:collection] __Map&_HashVMBase&MapMixin::entries
    // 0xad2f34: add             SP, SP, #8
    // 0xad2f38: r1 = Function '<anonymous closure>':.
    //     0xad2f38: add             x1, PP, #0xb, lsl #12  ; [pp+0xb488] AnonymousClosure: (0xad3000), in [package:dbus/src/dbus_value.dart] DBusDict::toString (0xad2d8c)
    //     0xad2f3c: ldr             x1, [x1, #0x488]
    // 0xad2f40: r2 = Null
    //     0xad2f40: mov             x2, NULL
    // 0xad2f44: stur            x0, [fp, #-0x10]
    // 0xad2f48: r0 = AllocateClosure()
    //     0xad2f48: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad2f4c: r16 = <String>
    //     0xad2f4c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad2f50: ldur            lr, [fp, #-0x10]
    // 0xad2f54: stp             lr, x16, [SP, #-0x10]!
    // 0xad2f58: SaveReg r0
    //     0xad2f58: str             x0, [SP, #-8]!
    // 0xad2f5c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad2f5c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad2f60: r0 = map()
    //     0xad2f60: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0xad2f64: add             SP, SP, #0x18
    // 0xad2f68: r16 = ", "
    //     0xad2f68: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad2f6c: stp             x16, x0, [SP, #-0x10]!
    // 0xad2f70: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad2f70: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad2f74: r0 = join()
    //     0xad2f74: bl              #0x6a9d88  ; [dart:core] Iterable::join
    // 0xad2f78: add             SP, SP, #0x10
    // 0xad2f7c: r1 = Null
    //     0xad2f7c: mov             x1, NULL
    // 0xad2f80: r2 = 16
    //     0xad2f80: mov             x2, #0x10
    // 0xad2f84: stur            x0, [fp, #-0x10]
    // 0xad2f88: r0 = AllocateArray()
    //     0xad2f88: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad2f8c: r17 = DBusDict
    //     0xad2f8c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb490] Type: DBusDict
    //     0xad2f90: ldr             x17, [x17, #0x490]
    // 0xad2f94: StoreField: r0->field_f = r17
    //     0xad2f94: stur            w17, [x0, #0xf]
    // 0xad2f98: r17 = "("
    //     0xad2f98: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad2f9c: StoreField: r0->field_13 = r17
    //     0xad2f9c: stur            w17, [x0, #0x13]
    // 0xad2fa0: ldur            x1, [fp, #-8]
    // 0xad2fa4: StoreField: r0->field_17 = r1
    //     0xad2fa4: stur            w1, [x0, #0x17]
    // 0xad2fa8: r17 = ", "
    //     0xad2fa8: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad2fac: StoreField: r0->field_1b = r17
    //     0xad2fac: stur            w17, [x0, #0x1b]
    // 0xad2fb0: ldr             x1, [fp, #0x10]
    // 0xad2fb4: LoadField: r2 = r1->field_b
    //     0xad2fb4: ldur            w2, [x1, #0xb]
    // 0xad2fb8: DecompressPointer r2
    //     0xad2fb8: add             x2, x2, HEAP, lsl #32
    // 0xad2fbc: StoreField: r0->field_1f = r2
    //     0xad2fbc: stur            w2, [x0, #0x1f]
    // 0xad2fc0: r17 = ", {"
    //     0xad2fc0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb498] ", {"
    //     0xad2fc4: ldr             x17, [x17, #0x498]
    // 0xad2fc8: StoreField: r0->field_23 = r17
    //     0xad2fc8: stur            w17, [x0, #0x23]
    // 0xad2fcc: ldur            x1, [fp, #-0x10]
    // 0xad2fd0: StoreField: r0->field_27 = r1
    //     0xad2fd0: stur            w1, [x0, #0x27]
    // 0xad2fd4: r17 = "})"
    //     0xad2fd4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb478] "})"
    //     0xad2fd8: ldr             x17, [x17, #0x478]
    // 0xad2fdc: StoreField: r0->field_2b = r17
    //     0xad2fdc: stur            w17, [x0, #0x2b]
    // 0xad2fe0: SaveReg r0
    //     0xad2fe0: str             x0, [SP, #-8]!
    // 0xad2fe4: r0 = _interpolate()
    //     0xad2fe4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad2fe8: add             SP, SP, #8
    // 0xad2fec: LeaveFrame
    //     0xad2fec: mov             SP, fp
    //     0xad2ff0: ldp             fp, lr, [SP], #0x10
    // 0xad2ff4: ret
    //     0xad2ff4: ret             
    // 0xad2ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad2ff8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad2ffc: b               #0xad2da4
  }
  [closure] String <anonymous closure>(dynamic, MapEntry<DBusValue, DBusValue>) {
    // ** addr: 0xad3000, size: 0x130
    // 0xad3000: EnterFrame
    //     0xad3000: stp             fp, lr, [SP, #-0x10]!
    //     0xad3004: mov             fp, SP
    // 0xad3008: AllocStack(0x10)
    //     0xad3008: sub             SP, SP, #0x10
    // 0xad300c: CheckStackOverflow
    //     0xad300c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3010: cmp             SP, x16
    //     0xad3014: b.ls            #0xad3128
    // 0xad3018: ldr             x1, [fp, #0x10]
    // 0xad301c: r0 = LoadClassIdInstr(r1)
    //     0xad301c: ldur            x0, [x1, #-1]
    //     0xad3020: ubfx            x0, x0, #0xc, #0x14
    // 0xad3024: SaveReg r1
    //     0xad3024: str             x1, [SP, #-8]!
    // 0xad3028: r0 = GDT[cid_x0 + -0xfba]()
    //     0xad3028: sub             lr, x0, #0xfba
    //     0xad302c: ldr             lr, [x21, lr, lsl #3]
    //     0xad3030: blr             lr
    // 0xad3034: add             SP, SP, #8
    // 0xad3038: r1 = 59
    //     0xad3038: mov             x1, #0x3b
    // 0xad303c: branchIfSmi(r0, 0xad3048)
    //     0xad303c: tbz             w0, #0, #0xad3048
    // 0xad3040: r1 = LoadClassIdInstr(r0)
    //     0xad3040: ldur            x1, [x0, #-1]
    //     0xad3044: ubfx            x1, x1, #0xc, #0x14
    // 0xad3048: SaveReg r0
    //     0xad3048: str             x0, [SP, #-8]!
    // 0xad304c: mov             x0, x1
    // 0xad3050: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad3050: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad3054: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad3054: mov             x17, #0x3f73
    //     0xad3058: add             lr, x0, x17
    //     0xad305c: ldr             lr, [x21, lr, lsl #3]
    //     0xad3060: blr             lr
    // 0xad3064: add             SP, SP, #8
    // 0xad3068: r1 = Null
    //     0xad3068: mov             x1, NULL
    // 0xad306c: r2 = 6
    //     0xad306c: mov             x2, #6
    // 0xad3070: stur            x0, [fp, #-8]
    // 0xad3074: r0 = AllocateArray()
    //     0xad3074: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad3078: mov             x1, x0
    // 0xad307c: ldur            x0, [fp, #-8]
    // 0xad3080: stur            x1, [fp, #-0x10]
    // 0xad3084: StoreField: r1->field_f = r0
    //     0xad3084: stur            w0, [x1, #0xf]
    // 0xad3088: r17 = ": "
    //     0xad3088: ldr             x17, [PP, #0xf48]  ; [pp+0xf48] ": "
    // 0xad308c: StoreField: r1->field_13 = r17
    //     0xad308c: stur            w17, [x1, #0x13]
    // 0xad3090: ldr             x0, [fp, #0x10]
    // 0xad3094: r2 = LoadClassIdInstr(r0)
    //     0xad3094: ldur            x2, [x0, #-1]
    //     0xad3098: ubfx            x2, x2, #0xc, #0x14
    // 0xad309c: SaveReg r0
    //     0xad309c: str             x0, [SP, #-8]!
    // 0xad30a0: mov             x0, x2
    // 0xad30a4: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xad30a4: sub             lr, x0, #0xfc4
    //     0xad30a8: ldr             lr, [x21, lr, lsl #3]
    //     0xad30ac: blr             lr
    // 0xad30b0: add             SP, SP, #8
    // 0xad30b4: r1 = 59
    //     0xad30b4: mov             x1, #0x3b
    // 0xad30b8: branchIfSmi(r0, 0xad30c4)
    //     0xad30b8: tbz             w0, #0, #0xad30c4
    // 0xad30bc: r1 = LoadClassIdInstr(r0)
    //     0xad30bc: ldur            x1, [x0, #-1]
    //     0xad30c0: ubfx            x1, x1, #0xc, #0x14
    // 0xad30c4: SaveReg r0
    //     0xad30c4: str             x0, [SP, #-8]!
    // 0xad30c8: mov             x0, x1
    // 0xad30cc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad30cc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad30d0: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad30d0: mov             x17, #0x3f73
    //     0xad30d4: add             lr, x0, x17
    //     0xad30d8: ldr             lr, [x21, lr, lsl #3]
    //     0xad30dc: blr             lr
    // 0xad30e0: add             SP, SP, #8
    // 0xad30e4: ldur            x1, [fp, #-0x10]
    // 0xad30e8: ArrayStore: r1[2] = r0  ; List_4
    //     0xad30e8: add             x25, x1, #0x17
    //     0xad30ec: str             w0, [x25]
    //     0xad30f0: tbz             w0, #0, #0xad310c
    //     0xad30f4: ldurb           w16, [x1, #-1]
    //     0xad30f8: ldurb           w17, [x0, #-1]
    //     0xad30fc: and             x16, x17, x16, lsr #2
    //     0xad3100: tst             x16, HEAP, lsr #32
    //     0xad3104: b.eq            #0xad310c
    //     0xad3108: bl              #0xd67e5c
    // 0xad310c: ldur            x16, [fp, #-0x10]
    // 0xad3110: SaveReg r16
    //     0xad3110: str             x16, [SP, #-8]!
    // 0xad3114: r0 = _interpolate()
    //     0xad3114: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3118: add             SP, SP, #8
    // 0xad311c: LeaveFrame
    //     0xad311c: mov             SP, fp
    //     0xad3120: ldp             fp, lr, [SP], #0x10
    // 0xad3124: ret
    //     0xad3124: ret             
    // 0xad3128: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3128: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad312c: b               #0xad3018
  }
  [closure] void <anonymous closure>(dynamic, DBusValue, DBusValue) {
    // ** addr: 0xad3130, size: 0x198
    // 0xad3130: EnterFrame
    //     0xad3130: stp             fp, lr, [SP, #-0x10]!
    //     0xad3134: mov             fp, SP
    // 0xad3138: AllocStack(0x18)
    //     0xad3138: sub             SP, SP, #0x18
    // 0xad313c: SetupParameters()
    //     0xad313c: ldr             x0, [fp, #0x20]
    //     0xad3140: ldur            w1, [x0, #0x17]
    //     0xad3144: add             x1, x1, HEAP, lsl #32
    // 0xad3148: CheckStackOverflow
    //     0xad3148: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad314c: cmp             SP, x16
    //     0xad3150: b.ls            #0xad32bc
    // 0xad3154: LoadField: r2 = r1->field_f
    //     0xad3154: ldur            w2, [x1, #0xf]
    // 0xad3158: DecompressPointer r2
    //     0xad3158: add             x2, x2, HEAP, lsl #32
    // 0xad315c: ldr             x0, [fp, #0x18]
    // 0xad3160: stur            x2, [fp, #-8]
    // 0xad3164: r1 = LoadClassIdInstr(r0)
    //     0xad3164: ldur            x1, [x0, #-1]
    //     0xad3168: ubfx            x1, x1, #0xc, #0x14
    // 0xad316c: SaveReg r0
    //     0xad316c: str             x0, [SP, #-8]!
    // 0xad3170: mov             x0, x1
    // 0xad3174: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad3174: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad3178: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad3178: mov             x17, #0x3f73
    //     0xad317c: add             lr, x0, x17
    //     0xad3180: ldr             lr, [x21, lr, lsl #3]
    //     0xad3184: blr             lr
    // 0xad3188: add             SP, SP, #8
    // 0xad318c: r1 = Null
    //     0xad318c: mov             x1, NULL
    // 0xad3190: r2 = 6
    //     0xad3190: mov             x2, #6
    // 0xad3194: stur            x0, [fp, #-0x10]
    // 0xad3198: r0 = AllocateArray()
    //     0xad3198: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad319c: mov             x1, x0
    // 0xad31a0: ldur            x0, [fp, #-0x10]
    // 0xad31a4: stur            x1, [fp, #-0x18]
    // 0xad31a8: StoreField: r1->field_f = r0
    //     0xad31a8: stur            w0, [x1, #0xf]
    // 0xad31ac: r17 = ": "
    //     0xad31ac: ldr             x17, [PP, #0xf48]  ; [pp+0xf48] ": "
    // 0xad31b0: StoreField: r1->field_13 = r17
    //     0xad31b0: stur            w17, [x1, #0x13]
    // 0xad31b4: ldr             x0, [fp, #0x10]
    // 0xad31b8: r2 = LoadClassIdInstr(r0)
    //     0xad31b8: ldur            x2, [x0, #-1]
    //     0xad31bc: ubfx            x2, x2, #0xc, #0x14
    // 0xad31c0: SaveReg r0
    //     0xad31c0: str             x0, [SP, #-8]!
    // 0xad31c4: mov             x0, x2
    // 0xad31c8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad31c8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad31cc: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad31cc: mov             x17, #0x3f73
    //     0xad31d0: add             lr, x0, x17
    //     0xad31d4: ldr             lr, [x21, lr, lsl #3]
    //     0xad31d8: blr             lr
    // 0xad31dc: add             SP, SP, #8
    // 0xad31e0: ldur            x1, [fp, #-0x18]
    // 0xad31e4: ArrayStore: r1[2] = r0  ; List_4
    //     0xad31e4: add             x25, x1, #0x17
    //     0xad31e8: str             w0, [x25]
    //     0xad31ec: tbz             w0, #0, #0xad3208
    //     0xad31f0: ldurb           w16, [x1, #-1]
    //     0xad31f4: ldurb           w17, [x0, #-1]
    //     0xad31f8: and             x16, x17, x16, lsr #2
    //     0xad31fc: tst             x16, HEAP, lsr #32
    //     0xad3200: b.eq            #0xad3208
    //     0xad3204: bl              #0xd67e5c
    // 0xad3208: ldur            x16, [fp, #-0x18]
    // 0xad320c: SaveReg r16
    //     0xad320c: str             x16, [SP, #-8]!
    // 0xad3210: r0 = _interpolate()
    //     0xad3210: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3214: add             SP, SP, #8
    // 0xad3218: mov             x1, x0
    // 0xad321c: ldur            x0, [fp, #-8]
    // 0xad3220: stur            x1, [fp, #-0x18]
    // 0xad3224: LoadField: r2 = r0->field_b
    //     0xad3224: ldur            w2, [x0, #0xb]
    // 0xad3228: DecompressPointer r2
    //     0xad3228: add             x2, x2, HEAP, lsl #32
    // 0xad322c: stur            x2, [fp, #-0x10]
    // 0xad3230: LoadField: r3 = r0->field_f
    //     0xad3230: ldur            w3, [x0, #0xf]
    // 0xad3234: DecompressPointer r3
    //     0xad3234: add             x3, x3, HEAP, lsl #32
    // 0xad3238: LoadField: r4 = r3->field_b
    //     0xad3238: ldur            w4, [x3, #0xb]
    // 0xad323c: DecompressPointer r4
    //     0xad323c: add             x4, x4, HEAP, lsl #32
    // 0xad3240: cmp             w2, w4
    // 0xad3244: b.ne            #0xad3254
    // 0xad3248: SaveReg r0
    //     0xad3248: str             x0, [SP, #-8]!
    // 0xad324c: r0 = _growToNextCapacity()
    //     0xad324c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xad3250: add             SP, SP, #8
    // 0xad3254: ldur            x2, [fp, #-8]
    // 0xad3258: ldur            x3, [fp, #-0x10]
    // 0xad325c: r4 = LoadInt32Instr(r3)
    //     0xad325c: sbfx            x4, x3, #1, #0x1f
    // 0xad3260: add             x0, x4, #1
    // 0xad3264: lsl             x3, x0, #1
    // 0xad3268: StoreField: r2->field_b = r3
    //     0xad3268: stur            w3, [x2, #0xb]
    // 0xad326c: mov             x1, x4
    // 0xad3270: cmp             x1, x0
    // 0xad3274: b.hs            #0xad32c4
    // 0xad3278: LoadField: r1 = r2->field_f
    //     0xad3278: ldur            w1, [x2, #0xf]
    // 0xad327c: DecompressPointer r1
    //     0xad327c: add             x1, x1, HEAP, lsl #32
    // 0xad3280: ldur            x0, [fp, #-0x18]
    // 0xad3284: ArrayStore: r1[r4] = r0  ; List_4
    //     0xad3284: add             x25, x1, x4, lsl #2
    //     0xad3288: add             x25, x25, #0xf
    //     0xad328c: str             w0, [x25]
    //     0xad3290: tbz             w0, #0, #0xad32ac
    //     0xad3294: ldurb           w16, [x1, #-1]
    //     0xad3298: ldurb           w17, [x0, #-1]
    //     0xad329c: and             x16, x17, x16, lsr #2
    //     0xad32a0: tst             x16, HEAP, lsr #32
    //     0xad32a4: b.eq            #0xad32ac
    //     0xad32a8: bl              #0xd67e5c
    // 0xad32ac: r0 = Null
    //     0xad32ac: mov             x0, NULL
    // 0xad32b0: LeaveFrame
    //     0xad32b0: mov             SP, fp
    //     0xad32b4: ldp             fp, lr, [SP], #0x10
    // 0xad32b8: ret
    //     0xad32b8: ret             
    // 0xad32bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad32bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad32c0: b               #0xad3154
    // 0xad32c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xad32c4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] String <anonymous closure>(dynamic, MapEntry<DBusValue, DBusValue>) {
    // ** addr: 0xad32c8, size: 0x1d8
    // 0xad32c8: EnterFrame
    //     0xad32c8: stp             fp, lr, [SP, #-0x10]!
    //     0xad32cc: mov             fp, SP
    // 0xad32d0: AllocStack(0x10)
    //     0xad32d0: sub             SP, SP, #0x10
    // 0xad32d4: CheckStackOverflow
    //     0xad32d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad32d8: cmp             SP, x16
    //     0xad32dc: b.ls            #0xad3490
    // 0xad32e0: r1 = Null
    //     0xad32e0: mov             x1, NULL
    // 0xad32e4: r2 = 8
    //     0xad32e4: mov             x2, #8
    // 0xad32e8: r0 = AllocateArray()
    //     0xad32e8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad32ec: mov             x1, x0
    // 0xad32f0: stur            x1, [fp, #-8]
    // 0xad32f4: r17 = "\'"
    //     0xad32f4: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad32f8: StoreField: r1->field_f = r17
    //     0xad32f8: stur            w17, [x1, #0xf]
    // 0xad32fc: ldr             x2, [fp, #0x10]
    // 0xad3300: r0 = LoadClassIdInstr(r2)
    //     0xad3300: ldur            x0, [x2, #-1]
    //     0xad3304: ubfx            x0, x0, #0xc, #0x14
    // 0xad3308: SaveReg r2
    //     0xad3308: str             x2, [SP, #-8]!
    // 0xad330c: r0 = GDT[cid_x0 + -0xfba]()
    //     0xad330c: sub             lr, x0, #0xfba
    //     0xad3310: ldr             lr, [x21, lr, lsl #3]
    //     0xad3314: blr             lr
    // 0xad3318: add             SP, SP, #8
    // 0xad331c: mov             x3, x0
    // 0xad3320: stur            x3, [fp, #-0x10]
    // 0xad3324: cmp             w3, NULL
    // 0xad3328: b.eq            #0xad3498
    // 0xad332c: mov             x0, x3
    // 0xad3330: r2 = Null
    //     0xad3330: mov             x2, NULL
    // 0xad3334: r1 = Null
    //     0xad3334: mov             x1, NULL
    // 0xad3338: r4 = 59
    //     0xad3338: mov             x4, #0x3b
    // 0xad333c: branchIfSmi(r0, 0xad3348)
    //     0xad333c: tbz             w0, #0, #0xad3348
    // 0xad3340: r4 = LoadClassIdInstr(r0)
    //     0xad3340: ldur            x4, [x0, #-1]
    //     0xad3344: ubfx            x4, x4, #0xc, #0x14
    // 0xad3348: r17 = -4573
    //     0xad3348: mov             x17, #-0x11dd
    // 0xad334c: add             x4, x4, x17
    // 0xad3350: cmp             x4, #1
    // 0xad3354: b.ls            #0xad3368
    // 0xad3358: r8 = DBusString
    //     0xad3358: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xad335c: r3 = Null
    //     0xad335c: add             x3, PP, #0xb, lsl #12  ; [pp+0xb4a0] Null
    //     0xad3360: ldr             x3, [x3, #0x4a0]
    // 0xad3364: r0 = DefaultTypeTest()
    //     0xad3364: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad3368: ldur            x0, [fp, #-0x10]
    // 0xad336c: LoadField: r1 = r0->field_7
    //     0xad336c: ldur            w1, [x0, #7]
    // 0xad3370: DecompressPointer r1
    //     0xad3370: add             x1, x1, HEAP, lsl #32
    // 0xad3374: mov             x0, x1
    // 0xad3378: ldur            x1, [fp, #-8]
    // 0xad337c: ArrayStore: r1[1] = r0  ; List_4
    //     0xad337c: add             x25, x1, #0x13
    //     0xad3380: str             w0, [x25]
    //     0xad3384: tbz             w0, #0, #0xad33a0
    //     0xad3388: ldurb           w16, [x1, #-1]
    //     0xad338c: ldurb           w17, [x0, #-1]
    //     0xad3390: and             x16, x17, x16, lsr #2
    //     0xad3394: tst             x16, HEAP, lsr #32
    //     0xad3398: b.eq            #0xad33a0
    //     0xad339c: bl              #0xd67e5c
    // 0xad33a0: ldur            x1, [fp, #-8]
    // 0xad33a4: r17 = "\': "
    //     0xad33a4: add             x17, PP, #0xa, lsl #12  ; [pp+0xa628] "\': "
    //     0xad33a8: ldr             x17, [x17, #0x628]
    // 0xad33ac: StoreField: r1->field_17 = r17
    //     0xad33ac: stur            w17, [x1, #0x17]
    // 0xad33b0: ldr             x0, [fp, #0x10]
    // 0xad33b4: r2 = LoadClassIdInstr(r0)
    //     0xad33b4: ldur            x2, [x0, #-1]
    //     0xad33b8: ubfx            x2, x2, #0xc, #0x14
    // 0xad33bc: SaveReg r0
    //     0xad33bc: str             x0, [SP, #-8]!
    // 0xad33c0: mov             x0, x2
    // 0xad33c4: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xad33c4: sub             lr, x0, #0xfc4
    //     0xad33c8: ldr             lr, [x21, lr, lsl #3]
    //     0xad33cc: blr             lr
    // 0xad33d0: add             SP, SP, #8
    // 0xad33d4: mov             x3, x0
    // 0xad33d8: stur            x3, [fp, #-0x10]
    // 0xad33dc: cmp             w3, NULL
    // 0xad33e0: b.eq            #0xad349c
    // 0xad33e4: mov             x0, x3
    // 0xad33e8: r2 = Null
    //     0xad33e8: mov             x2, NULL
    // 0xad33ec: r1 = Null
    //     0xad33ec: mov             x1, NULL
    // 0xad33f0: r4 = 59
    //     0xad33f0: mov             x4, #0x3b
    // 0xad33f4: branchIfSmi(r0, 0xad3400)
    //     0xad33f4: tbz             w0, #0, #0xad3400
    // 0xad33f8: r4 = LoadClassIdInstr(r0)
    //     0xad33f8: ldur            x4, [x0, #-1]
    //     0xad33fc: ubfx            x4, x4, #0xc, #0x14
    // 0xad3400: r17 = 4571
    //     0xad3400: mov             x17, #0x11db
    // 0xad3404: cmp             x4, x17
    // 0xad3408: b.eq            #0xad341c
    // 0xad340c: r8 = DBusVariant
    //     0xad340c: ldr             x8, [PP, #0x7fc0]  ; [pp+0x7fc0] Type: DBusVariant
    // 0xad3410: r3 = Null
    //     0xad3410: add             x3, PP, #0xb, lsl #12  ; [pp+0xb4b0] Null
    //     0xad3414: ldr             x3, [x3, #0x4b0]
    // 0xad3418: r0 = DefaultTypeTest()
    //     0xad3418: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad341c: ldur            x0, [fp, #-0x10]
    // 0xad3420: LoadField: r1 = r0->field_7
    //     0xad3420: ldur            w1, [x0, #7]
    // 0xad3424: DecompressPointer r1
    //     0xad3424: add             x1, x1, HEAP, lsl #32
    // 0xad3428: r0 = LoadClassIdInstr(r1)
    //     0xad3428: ldur            x0, [x1, #-1]
    //     0xad342c: ubfx            x0, x0, #0xc, #0x14
    // 0xad3430: SaveReg r1
    //     0xad3430: str             x1, [SP, #-8]!
    // 0xad3434: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad3434: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad3438: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad3438: mov             x17, #0x3f73
    //     0xad343c: add             lr, x0, x17
    //     0xad3440: ldr             lr, [x21, lr, lsl #3]
    //     0xad3444: blr             lr
    // 0xad3448: add             SP, SP, #8
    // 0xad344c: ldur            x1, [fp, #-8]
    // 0xad3450: ArrayStore: r1[3] = r0  ; List_4
    //     0xad3450: add             x25, x1, #0x1b
    //     0xad3454: str             w0, [x25]
    //     0xad3458: tbz             w0, #0, #0xad3474
    //     0xad345c: ldurb           w16, [x1, #-1]
    //     0xad3460: ldurb           w17, [x0, #-1]
    //     0xad3464: and             x16, x17, x16, lsr #2
    //     0xad3468: tst             x16, HEAP, lsr #32
    //     0xad346c: b.eq            #0xad3474
    //     0xad3470: bl              #0xd67e5c
    // 0xad3474: ldur            x16, [fp, #-8]
    // 0xad3478: SaveReg r16
    //     0xad3478: str             x16, [SP, #-8]!
    // 0xad347c: r0 = _interpolate()
    //     0xad347c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3480: add             SP, SP, #8
    // 0xad3484: LeaveFrame
    //     0xad3484: mov             SP, fp
    //     0xad3488: ldp             fp, lr, [SP], #0x10
    // 0xad348c: ret
    //     0xad348c: ret             
    // 0xad3490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3490: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3494: b               #0xad32e0
    // 0xad3498: r0 = NullErrorSharedWithoutFPURegs()
    //     0xad3498: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xad349c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xad349c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafa8b0, size: 0x98
    // 0xafa8b0: EnterFrame
    //     0xafa8b0: stp             fp, lr, [SP, #-0x10]!
    //     0xafa8b4: mov             fp, SP
    // 0xafa8b8: AllocStack(0x8)
    //     0xafa8b8: sub             SP, SP, #8
    // 0xafa8bc: CheckStackOverflow
    //     0xafa8bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafa8c0: cmp             SP, x16
    //     0xafa8c4: b.ls            #0xafa940
    // 0xafa8c8: ldr             x0, [fp, #0x10]
    // 0xafa8cc: LoadField: r1 = r0->field_f
    //     0xafa8cc: ldur            w1, [x0, #0xf]
    // 0xafa8d0: DecompressPointer r1
    //     0xafa8d0: add             x1, x1, HEAP, lsl #32
    // 0xafa8d4: SaveReg r1
    //     0xafa8d4: str             x1, [SP, #-8]!
    // 0xafa8d8: r0 = entries()
    //     0xafa8d8: bl              #0xc761a0  ; [dart:collection] __Map&_HashVMBase&MapMixin::entries
    // 0xafa8dc: add             SP, SP, #8
    // 0xafa8e0: r1 = Function '<anonymous closure>':.
    //     0xafa8e0: add             x1, PP, #0xb, lsl #12  ; [pp+0xb4d0] AnonymousClosure: (0xafa948), in [package:dbus/src/dbus_value.dart] DBusDict::hashCode (0xafa8b0)
    //     0xafa8e4: ldr             x1, [x1, #0x4d0]
    // 0xafa8e8: r2 = Null
    //     0xafa8e8: mov             x2, NULL
    // 0xafa8ec: stur            x0, [fp, #-8]
    // 0xafa8f0: r0 = AllocateClosure()
    //     0xafa8f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xafa8f4: r16 = <Object?>
    //     0xafa8f4: ldr             x16, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xafa8f8: ldur            lr, [fp, #-8]
    // 0xafa8fc: stp             lr, x16, [SP, #-0x10]!
    // 0xafa900: SaveReg r0
    //     0xafa900: str             x0, [SP, #-8]!
    // 0xafa904: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xafa904: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xafa908: r0 = map()
    //     0xafa908: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0xafa90c: add             SP, SP, #0x18
    // 0xafa910: SaveReg r0
    //     0xafa910: str             x0, [SP, #-8]!
    // 0xafa914: r0 = hashAll()
    //     0xafa914: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xafa918: add             SP, SP, #8
    // 0xafa91c: mov             x2, x0
    // 0xafa920: r0 = BoxInt64Instr(r2)
    //     0xafa920: sbfiz           x0, x2, #1, #0x1f
    //     0xafa924: cmp             x2, x0, asr #1
    //     0xafa928: b.eq            #0xafa934
    //     0xafa92c: bl              #0xd69bb8
    //     0xafa930: stur            x2, [x0, #7]
    // 0xafa934: LeaveFrame
    //     0xafa934: mov             SP, fp
    //     0xafa938: ldp             fp, lr, [SP], #0x10
    // 0xafa93c: ret
    //     0xafa93c: ret             
    // 0xafa940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa940: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa944: b               #0xafa8c8
  }
  [closure] int <anonymous closure>(dynamic, MapEntry<DBusValue, DBusValue>) {
    // ** addr: 0xafa948, size: 0xa4
    // 0xafa948: EnterFrame
    //     0xafa948: stp             fp, lr, [SP, #-0x10]!
    //     0xafa94c: mov             fp, SP
    // 0xafa950: AllocStack(0x8)
    //     0xafa950: sub             SP, SP, #8
    // 0xafa954: CheckStackOverflow
    //     0xafa954: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafa958: cmp             SP, x16
    //     0xafa95c: b.ls            #0xafa9e4
    // 0xafa960: ldr             x1, [fp, #0x10]
    // 0xafa964: r0 = LoadClassIdInstr(r1)
    //     0xafa964: ldur            x0, [x1, #-1]
    //     0xafa968: ubfx            x0, x0, #0xc, #0x14
    // 0xafa96c: SaveReg r1
    //     0xafa96c: str             x1, [SP, #-8]!
    // 0xafa970: r0 = GDT[cid_x0 + -0xfba]()
    //     0xafa970: sub             lr, x0, #0xfba
    //     0xafa974: ldr             lr, [x21, lr, lsl #3]
    //     0xafa978: blr             lr
    // 0xafa97c: add             SP, SP, #8
    // 0xafa980: mov             x1, x0
    // 0xafa984: ldr             x0, [fp, #0x10]
    // 0xafa988: stur            x1, [fp, #-8]
    // 0xafa98c: r2 = LoadClassIdInstr(r0)
    //     0xafa98c: ldur            x2, [x0, #-1]
    //     0xafa990: ubfx            x2, x2, #0xc, #0x14
    // 0xafa994: SaveReg r0
    //     0xafa994: str             x0, [SP, #-8]!
    // 0xafa998: mov             x0, x2
    // 0xafa99c: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xafa99c: sub             lr, x0, #0xfc4
    //     0xafa9a0: ldr             lr, [x21, lr, lsl #3]
    //     0xafa9a4: blr             lr
    // 0xafa9a8: add             SP, SP, #8
    // 0xafa9ac: ldur            x16, [fp, #-8]
    // 0xafa9b0: stp             x0, x16, [SP, #-0x10]!
    // 0xafa9b4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xafa9b4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xafa9b8: r0 = hash()
    //     0xafa9b8: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafa9bc: add             SP, SP, #0x10
    // 0xafa9c0: mov             x2, x0
    // 0xafa9c4: r0 = BoxInt64Instr(r2)
    //     0xafa9c4: sbfiz           x0, x2, #1, #0x1f
    //     0xafa9c8: cmp             x2, x0, asr #1
    //     0xafa9cc: b.eq            #0xafa9d8
    //     0xafa9d0: bl              #0xd69bb8
    //     0xafa9d4: stur            x2, [x0, #7]
    // 0xafa9d8: LeaveFrame
    //     0xafa9d8: mov             SP, fp
    //     0xafa9dc: ldp             fp, lr, [SP], #0x10
    // 0xafa9e0: ret
    //     0xafa9e0: ret             
    // 0xafa9e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa9e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa9e8: b               #0xafa960
  }
  _ toNative(/* No info */) {
    // ** addr: 0xc432c4, size: 0x68
    // 0xc432c4: EnterFrame
    //     0xc432c4: stp             fp, lr, [SP, #-0x10]!
    //     0xc432c8: mov             fp, SP
    // 0xc432cc: AllocStack(0x8)
    //     0xc432cc: sub             SP, SP, #8
    // 0xc432d0: CheckStackOverflow
    //     0xc432d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc432d4: cmp             SP, x16
    //     0xc432d8: b.ls            #0xc43324
    // 0xc432dc: ldr             x0, [fp, #0x10]
    // 0xc432e0: LoadField: r3 = r0->field_f
    //     0xc432e0: ldur            w3, [x0, #0xf]
    // 0xc432e4: DecompressPointer r3
    //     0xc432e4: add             x3, x3, HEAP, lsl #32
    // 0xc432e8: stur            x3, [fp, #-8]
    // 0xc432ec: r1 = Function '<anonymous closure>':.
    //     0xc432ec: add             x1, PP, #0xc, lsl #12  ; [pp+0xc7d0] AnonymousClosure: (0xc4332c), in [package:dbus/src/dbus_value.dart] DBusDict::toNative (0xc432c4)
    //     0xc432f0: ldr             x1, [x1, #0x7d0]
    // 0xc432f4: r2 = Null
    //     0xc432f4: mov             x2, NULL
    // 0xc432f8: r0 = AllocateClosure()
    //     0xc432f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc432fc: ldur            x16, [fp, #-8]
    // 0xc43300: stp             x16, NULL, [SP, #-0x10]!
    // 0xc43304: SaveReg r0
    //     0xc43304: str             x0, [SP, #-8]!
    // 0xc43308: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xc43308: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0xc4330c: ldr             x4, [x4, #0x4d8]
    // 0xc43310: r0 = map()
    //     0xc43310: bl              #0xc7ae6c  ; [dart:collection] __Map&_HashVMBase&MapMixin::map
    // 0xc43314: add             SP, SP, #0x18
    // 0xc43318: LeaveFrame
    //     0xc43318: mov             SP, fp
    //     0xc4331c: ldp             fp, lr, [SP], #0x10
    // 0xc43320: ret
    //     0xc43320: ret             
    // 0xc43324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43324: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc43328: b               #0xc432dc
  }
  [closure] MapEntry<dynamic, dynamic> <anonymous closure>(dynamic, DBusValue, DBusValue) {
    // ** addr: 0xc4332c, size: 0x98
    // 0xc4332c: EnterFrame
    //     0xc4332c: stp             fp, lr, [SP, #-0x10]!
    //     0xc43330: mov             fp, SP
    // 0xc43334: AllocStack(0x10)
    //     0xc43334: sub             SP, SP, #0x10
    // 0xc43338: CheckStackOverflow
    //     0xc43338: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4333c: cmp             SP, x16
    //     0xc43340: b.ls            #0xc433bc
    // 0xc43344: ldr             x0, [fp, #0x18]
    // 0xc43348: r1 = LoadClassIdInstr(r0)
    //     0xc43348: ldur            x1, [x0, #-1]
    //     0xc4334c: ubfx            x1, x1, #0xc, #0x14
    // 0xc43350: SaveReg r0
    //     0xc43350: str             x0, [SP, #-8]!
    // 0xc43354: mov             x0, x1
    // 0xc43358: r0 = GDT[cid_x0 + 0x872]()
    //     0xc43358: add             lr, x0, #0x872
    //     0xc4335c: ldr             lr, [x21, lr, lsl #3]
    //     0xc43360: blr             lr
    // 0xc43364: add             SP, SP, #8
    // 0xc43368: mov             x1, x0
    // 0xc4336c: ldr             x0, [fp, #0x10]
    // 0xc43370: stur            x1, [fp, #-8]
    // 0xc43374: r2 = LoadClassIdInstr(r0)
    //     0xc43374: ldur            x2, [x0, #-1]
    //     0xc43378: ubfx            x2, x2, #0xc, #0x14
    // 0xc4337c: SaveReg r0
    //     0xc4337c: str             x0, [SP, #-8]!
    // 0xc43380: mov             x0, x2
    // 0xc43384: r0 = GDT[cid_x0 + 0x872]()
    //     0xc43384: add             lr, x0, #0x872
    //     0xc43388: ldr             lr, [x21, lr, lsl #3]
    //     0xc4338c: blr             lr
    // 0xc43390: add             SP, SP, #8
    // 0xc43394: r1 = Null
    //     0xc43394: mov             x1, NULL
    // 0xc43398: stur            x0, [fp, #-0x10]
    // 0xc4339c: r0 = MapEntry()
    //     0xc4339c: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xc433a0: ldur            x1, [fp, #-8]
    // 0xc433a4: StoreField: r0->field_b = r1
    //     0xc433a4: stur            w1, [x0, #0xb]
    // 0xc433a8: ldur            x1, [fp, #-0x10]
    // 0xc433ac: StoreField: r0->field_f = r1
    //     0xc433ac: stur            w1, [x0, #0xf]
    // 0xc433b0: LeaveFrame
    //     0xc433b0: mov             SP, fp
    //     0xc433b4: ldp             fp, lr, [SP], #0x10
    // 0xc433b8: ret
    //     0xc433b8: ret             
    // 0xc433bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc433bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc433c0: b               #0xc43344
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc639c8, size: 0xa0
    // 0xc639c8: EnterFrame
    //     0xc639c8: stp             fp, lr, [SP, #-0x10]!
    //     0xc639cc: mov             fp, SP
    // 0xc639d0: AllocStack(0x10)
    //     0xc639d0: sub             SP, SP, #0x10
    // 0xc639d4: CheckStackOverflow
    //     0xc639d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc639d8: cmp             SP, x16
    //     0xc639dc: b.ls            #0xc63a60
    // 0xc639e0: r1 = Null
    //     0xc639e0: mov             x1, NULL
    // 0xc639e4: r2 = 8
    //     0xc639e4: mov             x2, #8
    // 0xc639e8: r0 = AllocateArray()
    //     0xc639e8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc639ec: r17 = "a{"
    //     0xc639ec: ldr             x17, [PP, #0x428]  ; [pp+0x428] "a{"
    // 0xc639f0: StoreField: r0->field_f = r17
    //     0xc639f0: stur            w17, [x0, #0xf]
    // 0xc639f4: ldr             x1, [fp, #0x10]
    // 0xc639f8: LoadField: r2 = r1->field_7
    //     0xc639f8: ldur            w2, [x1, #7]
    // 0xc639fc: DecompressPointer r2
    //     0xc639fc: add             x2, x2, HEAP, lsl #32
    // 0xc63a00: LoadField: r3 = r2->field_7
    //     0xc63a00: ldur            w3, [x2, #7]
    // 0xc63a04: DecompressPointer r3
    //     0xc63a04: add             x3, x3, HEAP, lsl #32
    // 0xc63a08: StoreField: r0->field_13 = r3
    //     0xc63a08: stur            w3, [x0, #0x13]
    // 0xc63a0c: LoadField: r2 = r1->field_b
    //     0xc63a0c: ldur            w2, [x1, #0xb]
    // 0xc63a10: DecompressPointer r2
    //     0xc63a10: add             x2, x2, HEAP, lsl #32
    // 0xc63a14: LoadField: r1 = r2->field_7
    //     0xc63a14: ldur            w1, [x2, #7]
    // 0xc63a18: DecompressPointer r1
    //     0xc63a18: add             x1, x1, HEAP, lsl #32
    // 0xc63a1c: StoreField: r0->field_17 = r1
    //     0xc63a1c: stur            w1, [x0, #0x17]
    // 0xc63a20: r17 = "}"
    //     0xc63a20: ldr             x17, [PP, #0x438]  ; [pp+0x438] "}"
    // 0xc63a24: StoreField: r0->field_1b = r17
    //     0xc63a24: stur            w17, [x0, #0x1b]
    // 0xc63a28: SaveReg r0
    //     0xc63a28: str             x0, [SP, #-8]!
    // 0xc63a2c: r0 = _interpolate()
    //     0xc63a2c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc63a30: add             SP, SP, #8
    // 0xc63a34: stur            x0, [fp, #-8]
    // 0xc63a38: r0 = DBusSignature()
    //     0xc63a38: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc63a3c: stur            x0, [fp, #-0x10]
    // 0xc63a40: ldur            x16, [fp, #-8]
    // 0xc63a44: stp             x16, x0, [SP, #-0x10]!
    // 0xc63a48: r0 = DBusSignature()
    //     0xc63a48: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc63a4c: add             SP, SP, #0x10
    // 0xc63a50: ldur            x0, [fp, #-0x10]
    // 0xc63a54: LeaveFrame
    //     0xc63a54: mov             SP, fp
    //     0xc63a58: ldp             fp, lr, [SP], #0x10
    // 0xc63a5c: ret
    //     0xc63a5c: ret             
    // 0xc63a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc63a60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc63a64: b               #0xc639e0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6ee40, size: 0xf0
    // 0xc6ee40: EnterFrame
    //     0xc6ee40: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ee44: mov             fp, SP
    // 0xc6ee48: CheckStackOverflow
    //     0xc6ee48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ee4c: cmp             SP, x16
    //     0xc6ee50: b.ls            #0xc6ef28
    // 0xc6ee54: ldr             x0, [fp, #0x10]
    // 0xc6ee58: cmp             w0, NULL
    // 0xc6ee5c: b.ne            #0xc6ee70
    // 0xc6ee60: r0 = false
    //     0xc6ee60: add             x0, NULL, #0x30  ; false
    // 0xc6ee64: LeaveFrame
    //     0xc6ee64: mov             SP, fp
    //     0xc6ee68: ldp             fp, lr, [SP], #0x10
    // 0xc6ee6c: ret
    //     0xc6ee6c: ret             
    // 0xc6ee70: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6ee70: mov             x1, #0x76
    //     0xc6ee74: tbz             w0, #0, #0xc6ee84
    //     0xc6ee78: ldur            x1, [x0, #-1]
    //     0xc6ee7c: ubfx            x1, x1, #0xc, #0x14
    //     0xc6ee80: lsl             x1, x1, #1
    // 0xc6ee84: r17 = 9134
    //     0xc6ee84: mov             x17, #0x23ae
    // 0xc6ee88: cmp             w1, w17
    // 0xc6ee8c: b.ne            #0xc6ef18
    // 0xc6ee90: ldr             x1, [fp, #0x18]
    // 0xc6ee94: LoadField: r2 = r0->field_7
    //     0xc6ee94: ldur            w2, [x0, #7]
    // 0xc6ee98: DecompressPointer r2
    //     0xc6ee98: add             x2, x2, HEAP, lsl #32
    // 0xc6ee9c: LoadField: r3 = r1->field_7
    //     0xc6ee9c: ldur            w3, [x1, #7]
    // 0xc6eea0: DecompressPointer r3
    //     0xc6eea0: add             x3, x3, HEAP, lsl #32
    // 0xc6eea4: stp             x3, x2, [SP, #-0x10]!
    // 0xc6eea8: r0 = ==()
    //     0xc6eea8: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0xc6eeac: add             SP, SP, #0x10
    // 0xc6eeb0: tbnz            w0, #4, #0xc6ef18
    // 0xc6eeb4: ldr             x1, [fp, #0x18]
    // 0xc6eeb8: ldr             x0, [fp, #0x10]
    // 0xc6eebc: LoadField: r2 = r0->field_b
    //     0xc6eebc: ldur            w2, [x0, #0xb]
    // 0xc6eec0: DecompressPointer r2
    //     0xc6eec0: add             x2, x2, HEAP, lsl #32
    // 0xc6eec4: LoadField: r3 = r1->field_b
    //     0xc6eec4: ldur            w3, [x1, #0xb]
    // 0xc6eec8: DecompressPointer r3
    //     0xc6eec8: add             x3, x3, HEAP, lsl #32
    // 0xc6eecc: stp             x3, x2, [SP, #-0x10]!
    // 0xc6eed0: r0 = ==()
    //     0xc6eed0: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0xc6eed4: add             SP, SP, #0x10
    // 0xc6eed8: tbnz            w0, #4, #0xc6ef18
    // 0xc6eedc: ldr             x1, [fp, #0x18]
    // 0xc6eee0: ldr             x0, [fp, #0x10]
    // 0xc6eee4: LoadField: r2 = r0->field_f
    //     0xc6eee4: ldur            w2, [x0, #0xf]
    // 0xc6eee8: DecompressPointer r2
    //     0xc6eee8: add             x2, x2, HEAP, lsl #32
    // 0xc6eeec: LoadField: r0 = r1->field_f
    //     0xc6eeec: ldur            w0, [x1, #0xf]
    // 0xc6eef0: DecompressPointer r0
    //     0xc6eef0: add             x0, x0, HEAP, lsl #32
    // 0xc6eef4: r16 = <DBusValue, DBusValue>
    //     0xc6eef4: add             x16, PP, #8, lsl #12  ; [pp+0x8168] TypeArguments: <DBusValue, DBusValue>
    //     0xc6eef8: ldr             x16, [x16, #0x168]
    // 0xc6eefc: stp             x2, x16, [SP, #-0x10]!
    // 0xc6ef00: SaveReg r0
    //     0xc6ef00: str             x0, [SP, #-8]!
    // 0xc6ef04: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xc6ef04: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0xc6ef08: ldr             x4, [x4, #0x4d8]
    // 0xc6ef0c: r0 = _mapsEqual()
    //     0xc6ef0c: bl              #0xc6ef30  ; [package:dbus/src/dbus_value.dart] ::_mapsEqual
    // 0xc6ef10: add             SP, SP, #0x18
    // 0xc6ef14: b               #0xc6ef1c
    // 0xc6ef18: r0 = false
    //     0xc6ef18: add             x0, NULL, #0x30  ; false
    // 0xc6ef1c: LeaveFrame
    //     0xc6ef1c: mov             SP, fp
    //     0xc6ef20: ldp             fp, lr, [SP], #0x10
    // 0xc6ef24: ret
    //     0xc6ef24: ret             
    // 0xc6ef28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ef28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ef2c: b               #0xc6ee54
  }
}

// class id: 4568, size: 0x10, field offset: 0x8
class DBusArray extends DBusValue {

  _ DBusArray(/* No info */) {
    // ** addr: 0xa00200, size: 0x2ec
    // 0xa00200: EnterFrame
    //     0xa00200: stp             fp, lr, [SP, #-0x10]!
    //     0xa00204: mov             fp, SP
    // 0xa00208: AllocStack(0x30)
    //     0xa00208: sub             SP, SP, #0x30
    // 0xa0020c: CheckStackOverflow
    //     0xa0020c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa00210: cmp             SP, x16
    //     0xa00214: b.ls            #0xa004dc
    // 0xa00218: ldr             x0, [fp, #0x18]
    // 0xa0021c: ldr             x1, [fp, #0x20]
    // 0xa00220: StoreField: r1->field_7 = r0
    //     0xa00220: stur            w0, [x1, #7]
    //     0xa00224: ldurb           w16, [x1, #-1]
    //     0xa00228: ldurb           w17, [x0, #-1]
    //     0xa0022c: and             x16, x17, x16, lsr #2
    //     0xa00230: tst             x16, HEAP, lsr #32
    //     0xa00234: b.eq            #0xa0023c
    //     0xa00238: bl              #0xd6826c
    // 0xa0023c: ldr             x16, [fp, #0x10]
    // 0xa00240: SaveReg r16
    //     0xa00240: str             x16, [SP, #-8]!
    // 0xa00244: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa00244: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa00248: r0 = toList()
    //     0xa00248: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0xa0024c: add             SP, SP, #8
    // 0xa00250: ldr             x1, [fp, #0x20]
    // 0xa00254: StoreField: r1->field_b = r0
    //     0xa00254: stur            w0, [x1, #0xb]
    //     0xa00258: tbz             w0, #0, #0xa00274
    //     0xa0025c: ldurb           w16, [x1, #-1]
    //     0xa00260: ldurb           w17, [x0, #-1]
    //     0xa00264: and             x16, x17, x16, lsr #2
    //     0xa00268: tst             x16, HEAP, lsr #32
    //     0xa0026c: b.eq            #0xa00274
    //     0xa00270: bl              #0xd6826c
    // 0xa00274: ldr             x16, [fp, #0x18]
    // 0xa00278: SaveReg r16
    //     0xa00278: str             x16, [SP, #-8]!
    // 0xa0027c: r0 = isSingleCompleteType()
    //     0xa0027c: bl              #0xa004ec  ; [package:dbus/src/dbus_value.dart] DBusSignature::isSingleCompleteType
    // 0xa00280: add             SP, SP, #8
    // 0xa00284: tbnz            w0, #4, #0xa00424
    // 0xa00288: ldr             x0, [fp, #0x18]
    // 0xa0028c: ldr             x1, [fp, #0x10]
    // 0xa00290: r2 = true
    //     0xa00290: add             x2, NULL, #0x20  ; true
    // 0xa00294: LoadField: r3 = r1->field_7
    //     0xa00294: ldur            w3, [x1, #7]
    // 0xa00298: DecompressPointer r3
    //     0xa00298: add             x3, x3, HEAP, lsl #32
    // 0xa0029c: stur            x3, [fp, #-0x20]
    // 0xa002a0: LoadField: r4 = r1->field_b
    //     0xa002a0: ldur            w4, [x1, #0xb]
    // 0xa002a4: DecompressPointer r4
    //     0xa002a4: add             x4, x4, HEAP, lsl #32
    // 0xa002a8: r5 = LoadInt32Instr(r4)
    //     0xa002a8: sbfx            x5, x4, #1, #0x1f
    // 0xa002ac: stur            x5, [fp, #-0x18]
    // 0xa002b0: LoadField: r4 = r0->field_7
    //     0xa002b0: ldur            w4, [x0, #7]
    // 0xa002b4: DecompressPointer r4
    //     0xa002b4: add             x4, x4, HEAP, lsl #32
    // 0xa002b8: stur            x4, [fp, #-0x10]
    // 0xa002bc: r6 = 0
    //     0xa002bc: mov             x6, #0
    // 0xa002c0: stur            x6, [fp, #-8]
    // 0xa002c4: CheckStackOverflow
    //     0xa002c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa002c8: cmp             SP, x16
    //     0xa002cc: b.ls            #0xa004e4
    // 0xa002d0: r0 = LoadClassIdInstr(r1)
    //     0xa002d0: ldur            x0, [x1, #-1]
    //     0xa002d4: ubfx            x0, x0, #0xc, #0x14
    // 0xa002d8: SaveReg r1
    //     0xa002d8: str             x1, [SP, #-8]!
    // 0xa002dc: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa002dc: mov             x17, #0xb8ea
    //     0xa002e0: add             lr, x0, x17
    //     0xa002e4: ldr             lr, [x21, lr, lsl #3]
    //     0xa002e8: blr             lr
    // 0xa002ec: add             SP, SP, #8
    // 0xa002f0: r1 = LoadInt32Instr(r0)
    //     0xa002f0: sbfx            x1, x0, #1, #0x1f
    //     0xa002f4: tbz             w0, #0, #0xa002fc
    //     0xa002f8: ldur            x1, [x0, #7]
    // 0xa002fc: ldur            x2, [fp, #-0x18]
    // 0xa00300: cmp             x2, x1
    // 0xa00304: b.ne            #0xa0045c
    // 0xa00308: ldr             x3, [fp, #0x10]
    // 0xa0030c: ldur            x4, [fp, #-8]
    // 0xa00310: cmp             x4, x1
    // 0xa00314: b.lt            #0xa00328
    // 0xa00318: r0 = Null
    //     0xa00318: mov             x0, NULL
    // 0xa0031c: LeaveFrame
    //     0xa0031c: mov             SP, fp
    //     0xa00320: ldp             fp, lr, [SP], #0x10
    // 0xa00324: ret
    //     0xa00324: ret             
    // 0xa00328: r0 = BoxInt64Instr(r4)
    //     0xa00328: sbfiz           x0, x4, #1, #0x1f
    //     0xa0032c: cmp             x4, x0, asr #1
    //     0xa00330: b.eq            #0xa0033c
    //     0xa00334: bl              #0xd69bb8
    //     0xa00338: stur            x4, [x0, #7]
    // 0xa0033c: r1 = LoadClassIdInstr(r3)
    //     0xa0033c: ldur            x1, [x3, #-1]
    //     0xa00340: ubfx            x1, x1, #0xc, #0x14
    // 0xa00344: stp             x0, x3, [SP, #-0x10]!
    // 0xa00348: mov             x0, x1
    // 0xa0034c: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa0034c: mov             x17, #0xd175
    //     0xa00350: add             lr, x0, x17
    //     0xa00354: ldr             lr, [x21, lr, lsl #3]
    //     0xa00358: blr             lr
    // 0xa0035c: add             SP, SP, #0x10
    // 0xa00360: mov             x3, x0
    // 0xa00364: ldur            x0, [fp, #-8]
    // 0xa00368: stur            x3, [fp, #-0x30]
    // 0xa0036c: add             x6, x0, #1
    // 0xa00370: stur            x6, [fp, #-0x28]
    // 0xa00374: cmp             w3, NULL
    // 0xa00378: b.ne            #0xa003a8
    // 0xa0037c: mov             x0, x3
    // 0xa00380: ldur            x2, [fp, #-0x20]
    // 0xa00384: r1 = Null
    //     0xa00384: mov             x1, NULL
    // 0xa00388: cmp             w2, NULL
    // 0xa0038c: b.eq            #0xa003a8
    // 0xa00390: LoadField: r4 = r2->field_17
    //     0xa00390: ldur            w4, [x2, #0x17]
    // 0xa00394: DecompressPointer r4
    //     0xa00394: add             x4, x4, HEAP, lsl #32
    // 0xa00398: r8 = X0
    //     0xa00398: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa0039c: LoadField: r9 = r4->field_7
    //     0xa0039c: ldur            x9, [x4, #7]
    // 0xa003a0: r3 = Null
    //     0xa003a0: ldr             x3, [PP, #0x7858]  ; [pp+0x7858] Null
    // 0xa003a4: blr             x9
    // 0xa003a8: ldur            x0, [fp, #-0x30]
    // 0xa003ac: r1 = LoadClassIdInstr(r0)
    //     0xa003ac: ldur            x1, [x0, #-1]
    //     0xa003b0: ubfx            x1, x1, #0xc, #0x14
    // 0xa003b4: SaveReg r0
    //     0xa003b4: str             x0, [SP, #-8]!
    // 0xa003b8: mov             x0, x1
    // 0xa003bc: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa003bc: add             lr, x0, #0x2b8
    //     0xa003c0: ldr             lr, [x21, lr, lsl #3]
    //     0xa003c4: blr             lr
    // 0xa003c8: add             SP, SP, #8
    // 0xa003cc: LoadField: r1 = r0->field_7
    //     0xa003cc: ldur            w1, [x0, #7]
    // 0xa003d0: DecompressPointer r1
    //     0xa003d0: add             x1, x1, HEAP, lsl #32
    // 0xa003d4: r0 = LoadClassIdInstr(r1)
    //     0xa003d4: ldur            x0, [x1, #-1]
    //     0xa003d8: ubfx            x0, x0, #0xc, #0x14
    // 0xa003dc: ldur            x16, [fp, #-0x10]
    // 0xa003e0: stp             x16, x1, [SP, #-0x10]!
    // 0xa003e4: mov             lr, x0
    // 0xa003e8: ldr             lr, [x21, lr, lsl #3]
    // 0xa003ec: blr             lr
    // 0xa003f0: add             SP, SP, #0x10
    // 0xa003f4: tbnz            w0, #4, #0xa00474
    // 0xa003f8: ldr             x2, [fp, #0x10]
    // 0xa003fc: ldur            x1, [fp, #-0x10]
    // 0xa00400: r3 = true
    //     0xa00400: add             x3, NULL, #0x20  ; true
    // 0xa00404: r0 = "children"
    //     0xa00404: ldr             x0, [PP, #0x7868]  ; [pp+0x7868] "children"
    // 0xa00408: ldur            x6, [fp, #-0x28]
    // 0xa0040c: mov             x4, x1
    // 0xa00410: mov             x1, x2
    // 0xa00414: mov             x2, x3
    // 0xa00418: ldur            x3, [fp, #-0x20]
    // 0xa0041c: ldur            x5, [fp, #-0x18]
    // 0xa00420: b               #0xa002c0
    // 0xa00424: ldr             x0, [fp, #0x18]
    // 0xa00428: r0 = ArgumentError()
    //     0xa00428: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xa0042c: mov             x1, x0
    // 0xa00430: r0 = "childSignature"
    //     0xa00430: ldr             x0, [PP, #0x7870]  ; [pp+0x7870] "childSignature"
    // 0xa00434: StoreField: r1->field_13 = r0
    //     0xa00434: stur            w0, [x1, #0x13]
    // 0xa00438: r0 = "Array value type must be a single complete type"
    //     0xa00438: ldr             x0, [PP, #0x7878]  ; [pp+0x7878] "Array value type must be a single complete type"
    // 0xa0043c: StoreField: r1->field_17 = r0
    //     0xa0043c: stur            w0, [x1, #0x17]
    // 0xa00440: ldr             x0, [fp, #0x18]
    // 0xa00444: StoreField: r1->field_f = r0
    //     0xa00444: stur            w0, [x1, #0xf]
    // 0xa00448: r2 = true
    //     0xa00448: add             x2, NULL, #0x20  ; true
    // 0xa0044c: StoreField: r1->field_b = r2
    //     0xa0044c: stur            w2, [x1, #0xb]
    // 0xa00450: mov             x0, x1
    // 0xa00454: r0 = Throw()
    //     0xa00454: bl              #0xd67e38  ; ThrowStub
    // 0xa00458: brk             #0
    // 0xa0045c: ldr             x0, [fp, #0x10]
    // 0xa00460: r0 = ConcurrentModificationError()
    //     0xa00460: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa00464: ldr             x3, [fp, #0x10]
    // 0xa00468: StoreField: r0->field_b = r3
    //     0xa00468: stur            w3, [x0, #0xb]
    // 0xa0046c: r0 = Throw()
    //     0xa0046c: bl              #0xd67e38  ; ThrowStub
    // 0xa00470: brk             #0
    // 0xa00474: ldr             x0, [fp, #0x10]
    // 0xa00478: ldur            x3, [fp, #-0x10]
    // 0xa0047c: r1 = Null
    //     0xa0047c: mov             x1, NULL
    // 0xa00480: r2 = 4
    //     0xa00480: mov             x2, #4
    // 0xa00484: r0 = AllocateArray()
    //     0xa00484: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa00488: r17 = "Provided children don\'t match array signature "
    //     0xa00488: ldr             x17, [PP, #0x7880]  ; [pp+0x7880] "Provided children don\'t match array signature "
    // 0xa0048c: StoreField: r0->field_f = r17
    //     0xa0048c: stur            w17, [x0, #0xf]
    // 0xa00490: ldur            x1, [fp, #-0x10]
    // 0xa00494: StoreField: r0->field_13 = r1
    //     0xa00494: stur            w1, [x0, #0x13]
    // 0xa00498: SaveReg r0
    //     0xa00498: str             x0, [SP, #-8]!
    // 0xa0049c: r0 = _interpolate()
    //     0xa0049c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa004a0: add             SP, SP, #8
    // 0xa004a4: stur            x0, [fp, #-0x30]
    // 0xa004a8: r0 = ArgumentError()
    //     0xa004a8: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xa004ac: mov             x1, x0
    // 0xa004b0: r0 = "children"
    //     0xa004b0: ldr             x0, [PP, #0x7868]  ; [pp+0x7868] "children"
    // 0xa004b4: StoreField: r1->field_13 = r0
    //     0xa004b4: stur            w0, [x1, #0x13]
    // 0xa004b8: ldur            x0, [fp, #-0x30]
    // 0xa004bc: StoreField: r1->field_17 = r0
    //     0xa004bc: stur            w0, [x1, #0x17]
    // 0xa004c0: ldr             x2, [fp, #0x10]
    // 0xa004c4: StoreField: r1->field_f = r2
    //     0xa004c4: stur            w2, [x1, #0xf]
    // 0xa004c8: r3 = true
    //     0xa004c8: add             x3, NULL, #0x20  ; true
    // 0xa004cc: StoreField: r1->field_b = r3
    //     0xa004cc: stur            w3, [x1, #0xb]
    // 0xa004d0: mov             x0, x1
    // 0xa004d4: r0 = Throw()
    //     0xa004d4: bl              #0xd67e38  ; ThrowStub
    // 0xa004d8: brk             #0
    // 0xa004dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa004dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa004e0: b               #0xa00218
    // 0xa004e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa004e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa004e8: b               #0xa002d0
  }
  _ mapString(/* No info */) {
    // ** addr: 0xa0f7cc, size: 0x68
    // 0xa0f7cc: EnterFrame
    //     0xa0f7cc: stp             fp, lr, [SP, #-0x10]!
    //     0xa0f7d0: mov             fp, SP
    // 0xa0f7d4: AllocStack(0x8)
    //     0xa0f7d4: sub             SP, SP, #8
    // 0xa0f7d8: CheckStackOverflow
    //     0xa0f7d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0f7dc: cmp             SP, x16
    //     0xa0f7e0: b.ls            #0xa0f82c
    // 0xa0f7e4: ldr             x0, [fp, #0x10]
    // 0xa0f7e8: LoadField: r3 = r0->field_b
    //     0xa0f7e8: ldur            w3, [x0, #0xb]
    // 0xa0f7ec: DecompressPointer r3
    //     0xa0f7ec: add             x3, x3, HEAP, lsl #32
    // 0xa0f7f0: stur            x3, [fp, #-8]
    // 0xa0f7f4: r1 = Function '<anonymous closure>':.
    //     0xa0f7f4: add             x1, PP, #0x21, lsl #12  ; [pp+0x211f0] AnonymousClosure: (0xa0f834), in [package:dbus/src/dbus_value.dart] DBusArray::mapString (0xa0f7cc)
    //     0xa0f7f8: ldr             x1, [x1, #0x1f0]
    // 0xa0f7fc: r2 = Null
    //     0xa0f7fc: mov             x2, NULL
    // 0xa0f800: r0 = AllocateClosure()
    //     0xa0f800: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0f804: r16 = <String>
    //     0xa0f804: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xa0f808: ldur            lr, [fp, #-8]
    // 0xa0f80c: stp             lr, x16, [SP, #-0x10]!
    // 0xa0f810: SaveReg r0
    //     0xa0f810: str             x0, [SP, #-8]!
    // 0xa0f814: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0f814: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0f818: r0 = map()
    //     0xa0f818: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa0f81c: add             SP, SP, #0x18
    // 0xa0f820: LeaveFrame
    //     0xa0f820: mov             SP, fp
    //     0xa0f824: ldp             fp, lr, [SP], #0x10
    // 0xa0f828: ret
    //     0xa0f828: ret             
    // 0xa0f82c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0f82c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0f830: b               #0xa0f7e4
  }
  [closure] String <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xa0f834, size: 0x54
    // 0xa0f834: EnterFrame
    //     0xa0f834: stp             fp, lr, [SP, #-0x10]!
    //     0xa0f838: mov             fp, SP
    // 0xa0f83c: ldr             x0, [fp, #0x10]
    // 0xa0f840: r2 = Null
    //     0xa0f840: mov             x2, NULL
    // 0xa0f844: r1 = Null
    //     0xa0f844: mov             x1, NULL
    // 0xa0f848: r4 = LoadClassIdInstr(r0)
    //     0xa0f848: ldur            x4, [x0, #-1]
    //     0xa0f84c: ubfx            x4, x4, #0xc, #0x14
    // 0xa0f850: r17 = -4573
    //     0xa0f850: mov             x17, #-0x11dd
    // 0xa0f854: add             x4, x4, x17
    // 0xa0f858: cmp             x4, #1
    // 0xa0f85c: b.ls            #0xa0f870
    // 0xa0f860: r8 = DBusString
    //     0xa0f860: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa0f864: r3 = Null
    //     0xa0f864: add             x3, PP, #0x21, lsl #12  ; [pp+0x211f8] Null
    //     0xa0f868: ldr             x3, [x3, #0x1f8]
    // 0xa0f86c: r0 = DefaultTypeTest()
    //     0xa0f86c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa0f870: ldr             x1, [fp, #0x10]
    // 0xa0f874: LoadField: r0 = r1->field_7
    //     0xa0f874: ldur            w0, [x1, #7]
    // 0xa0f878: DecompressPointer r0
    //     0xa0f878: add             x0, x0, HEAP, lsl #32
    // 0xa0f87c: LeaveFrame
    //     0xa0f87c: mov             SP, fp
    //     0xa0f880: ldp             fp, lr, [SP], #0x10
    // 0xa0f884: ret
    //     0xa0f884: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xad1bac, size: 0xc34
    // 0xad1bac: EnterFrame
    //     0xad1bac: stp             fp, lr, [SP, #-0x10]!
    //     0xad1bb0: mov             fp, SP
    // 0xad1bb4: AllocStack(0x28)
    //     0xad1bb4: sub             SP, SP, #0x28
    // 0xad1bb8: CheckStackOverflow
    //     0xad1bb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1bbc: cmp             SP, x16
    //     0xad1bc0: b.ls            #0xad27cc
    // 0xad1bc4: ldr             x0, [fp, #0x10]
    // 0xad1bc8: LoadField: r1 = r0->field_7
    //     0xad1bc8: ldur            w1, [x0, #7]
    // 0xad1bcc: DecompressPointer r1
    //     0xad1bcc: add             x1, x1, HEAP, lsl #32
    // 0xad1bd0: stur            x1, [fp, #-0x10]
    // 0xad1bd4: LoadField: r2 = r1->field_7
    //     0xad1bd4: ldur            w2, [x1, #7]
    // 0xad1bd8: DecompressPointer r2
    //     0xad1bd8: add             x2, x2, HEAP, lsl #32
    // 0xad1bdc: stur            x2, [fp, #-8]
    // 0xad1be0: r16 = "y"
    //     0xad1be0: ldr             x16, [PP, #0x78d0]  ; [pp+0x78d0] "y"
    // 0xad1be4: stp             x2, x16, [SP, #-0x10]!
    // 0xad1be8: r0 = ==()
    //     0xad1be8: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad1bec: add             SP, SP, #0x10
    // 0xad1bf0: tbnz            w0, #4, #0xad1c8c
    // 0xad1bf4: ldr             x0, [fp, #0x10]
    // 0xad1bf8: LoadField: r3 = r0->field_b
    //     0xad1bf8: ldur            w3, [x0, #0xb]
    // 0xad1bfc: DecompressPointer r3
    //     0xad1bfc: add             x3, x3, HEAP, lsl #32
    // 0xad1c00: stur            x3, [fp, #-0x18]
    // 0xad1c04: r1 = Function '<anonymous closure>':.
    //     0xad1c04: add             x1, PP, #0xb, lsl #12  ; [pp+0xb288] AnonymousClosure: (0xad2d2c), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad1c08: ldr             x1, [x1, #0x288]
    // 0xad1c0c: r2 = Null
    //     0xad1c0c: mov             x2, NULL
    // 0xad1c10: r0 = AllocateClosure()
    //     0xad1c10: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad1c14: r16 = <int>
    //     0xad1c14: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xad1c18: ldur            lr, [fp, #-0x18]
    // 0xad1c1c: stp             lr, x16, [SP, #-0x10]!
    // 0xad1c20: SaveReg r0
    //     0xad1c20: str             x0, [SP, #-8]!
    // 0xad1c24: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad1c24: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad1c28: r0 = map()
    //     0xad1c28: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad1c2c: add             SP, SP, #0x18
    // 0xad1c30: r16 = ", "
    //     0xad1c30: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad1c34: stp             x16, x0, [SP, #-0x10]!
    // 0xad1c38: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad1c38: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad1c3c: r0 = join()
    //     0xad1c3c: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad1c40: add             SP, SP, #0x10
    // 0xad1c44: r1 = Null
    //     0xad1c44: mov             x1, NULL
    // 0xad1c48: r2 = 6
    //     0xad1c48: mov             x2, #6
    // 0xad1c4c: stur            x0, [fp, #-0x18]
    // 0xad1c50: r0 = AllocateArray()
    //     0xad1c50: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1c54: r17 = "DBusArray.byte(["
    //     0xad1c54: add             x17, PP, #0xb, lsl #12  ; [pp+0xb290] "DBusArray.byte(["
    //     0xad1c58: ldr             x17, [x17, #0x290]
    // 0xad1c5c: StoreField: r0->field_f = r17
    //     0xad1c5c: stur            w17, [x0, #0xf]
    // 0xad1c60: ldur            x1, [fp, #-0x18]
    // 0xad1c64: StoreField: r0->field_13 = r1
    //     0xad1c64: stur            w1, [x0, #0x13]
    // 0xad1c68: r17 = "])"
    //     0xad1c68: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad1c6c: ldr             x17, [x17, #0x298]
    // 0xad1c70: StoreField: r0->field_17 = r17
    //     0xad1c70: stur            w17, [x0, #0x17]
    // 0xad1c74: SaveReg r0
    //     0xad1c74: str             x0, [SP, #-8]!
    // 0xad1c78: r0 = _interpolate()
    //     0xad1c78: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1c7c: add             SP, SP, #8
    // 0xad1c80: LeaveFrame
    //     0xad1c80: mov             SP, fp
    //     0xad1c84: ldp             fp, lr, [SP], #0x10
    // 0xad1c88: ret
    //     0xad1c88: ret             
    // 0xad1c8c: ldr             x0, [fp, #0x10]
    // 0xad1c90: r16 = "b"
    //     0xad1c90: ldr             x16, [PP, #0x78d8]  ; [pp+0x78d8] "b"
    // 0xad1c94: ldur            lr, [fp, #-8]
    // 0xad1c98: stp             lr, x16, [SP, #-0x10]!
    // 0xad1c9c: r0 = ==()
    //     0xad1c9c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad1ca0: add             SP, SP, #0x10
    // 0xad1ca4: tbnz            w0, #4, #0xad1d40
    // 0xad1ca8: ldr             x0, [fp, #0x10]
    // 0xad1cac: LoadField: r3 = r0->field_b
    //     0xad1cac: ldur            w3, [x0, #0xb]
    // 0xad1cb0: DecompressPointer r3
    //     0xad1cb0: add             x3, x3, HEAP, lsl #32
    // 0xad1cb4: stur            x3, [fp, #-0x18]
    // 0xad1cb8: r1 = Function '<anonymous closure>':.
    //     0xad1cb8: add             x1, PP, #0xb, lsl #12  ; [pp+0xb2a0] AnonymousClosure: (0xad2cd8), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad1cbc: ldr             x1, [x1, #0x2a0]
    // 0xad1cc0: r2 = Null
    //     0xad1cc0: mov             x2, NULL
    // 0xad1cc4: r0 = AllocateClosure()
    //     0xad1cc4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad1cc8: r16 = <bool>
    //     0xad1cc8: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0xad1ccc: ldur            lr, [fp, #-0x18]
    // 0xad1cd0: stp             lr, x16, [SP, #-0x10]!
    // 0xad1cd4: SaveReg r0
    //     0xad1cd4: str             x0, [SP, #-8]!
    // 0xad1cd8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad1cd8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad1cdc: r0 = map()
    //     0xad1cdc: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad1ce0: add             SP, SP, #0x18
    // 0xad1ce4: r16 = ", "
    //     0xad1ce4: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad1ce8: stp             x16, x0, [SP, #-0x10]!
    // 0xad1cec: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad1cec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad1cf0: r0 = join()
    //     0xad1cf0: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad1cf4: add             SP, SP, #0x10
    // 0xad1cf8: r1 = Null
    //     0xad1cf8: mov             x1, NULL
    // 0xad1cfc: r2 = 6
    //     0xad1cfc: mov             x2, #6
    // 0xad1d00: stur            x0, [fp, #-0x18]
    // 0xad1d04: r0 = AllocateArray()
    //     0xad1d04: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1d08: r17 = "DBusArray.boolean(["
    //     0xad1d08: add             x17, PP, #0xb, lsl #12  ; [pp+0xb2a8] "DBusArray.boolean(["
    //     0xad1d0c: ldr             x17, [x17, #0x2a8]
    // 0xad1d10: StoreField: r0->field_f = r17
    //     0xad1d10: stur            w17, [x0, #0xf]
    // 0xad1d14: ldur            x1, [fp, #-0x18]
    // 0xad1d18: StoreField: r0->field_13 = r1
    //     0xad1d18: stur            w1, [x0, #0x13]
    // 0xad1d1c: r17 = "])"
    //     0xad1d1c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad1d20: ldr             x17, [x17, #0x298]
    // 0xad1d24: StoreField: r0->field_17 = r17
    //     0xad1d24: stur            w17, [x0, #0x17]
    // 0xad1d28: SaveReg r0
    //     0xad1d28: str             x0, [SP, #-8]!
    // 0xad1d2c: r0 = _interpolate()
    //     0xad1d2c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1d30: add             SP, SP, #8
    // 0xad1d34: LeaveFrame
    //     0xad1d34: mov             SP, fp
    //     0xad1d38: ldp             fp, lr, [SP], #0x10
    // 0xad1d3c: ret
    //     0xad1d3c: ret             
    // 0xad1d40: ldr             x0, [fp, #0x10]
    // 0xad1d44: r16 = "n"
    //     0xad1d44: ldr             x16, [PP, #0x78e0]  ; [pp+0x78e0] "n"
    // 0xad1d48: ldur            lr, [fp, #-8]
    // 0xad1d4c: stp             lr, x16, [SP, #-0x10]!
    // 0xad1d50: r0 = ==()
    //     0xad1d50: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad1d54: add             SP, SP, #0x10
    // 0xad1d58: tbnz            w0, #4, #0xad1df4
    // 0xad1d5c: ldr             x0, [fp, #0x10]
    // 0xad1d60: LoadField: r3 = r0->field_b
    //     0xad1d60: ldur            w3, [x0, #0xb]
    // 0xad1d64: DecompressPointer r3
    //     0xad1d64: add             x3, x3, HEAP, lsl #32
    // 0xad1d68: stur            x3, [fp, #-0x18]
    // 0xad1d6c: r1 = Function '<anonymous closure>':.
    //     0xad1d6c: add             x1, PP, #0xb, lsl #12  ; [pp+0xb2b0] AnonymousClosure: (0xad2c74), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad1d70: ldr             x1, [x1, #0x2b0]
    // 0xad1d74: r2 = Null
    //     0xad1d74: mov             x2, NULL
    // 0xad1d78: r0 = AllocateClosure()
    //     0xad1d78: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad1d7c: r16 = <int>
    //     0xad1d7c: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xad1d80: ldur            lr, [fp, #-0x18]
    // 0xad1d84: stp             lr, x16, [SP, #-0x10]!
    // 0xad1d88: SaveReg r0
    //     0xad1d88: str             x0, [SP, #-8]!
    // 0xad1d8c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad1d8c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad1d90: r0 = map()
    //     0xad1d90: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad1d94: add             SP, SP, #0x18
    // 0xad1d98: r16 = ", "
    //     0xad1d98: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad1d9c: stp             x16, x0, [SP, #-0x10]!
    // 0xad1da0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad1da0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad1da4: r0 = join()
    //     0xad1da4: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad1da8: add             SP, SP, #0x10
    // 0xad1dac: r1 = Null
    //     0xad1dac: mov             x1, NULL
    // 0xad1db0: r2 = 6
    //     0xad1db0: mov             x2, #6
    // 0xad1db4: stur            x0, [fp, #-0x18]
    // 0xad1db8: r0 = AllocateArray()
    //     0xad1db8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1dbc: r17 = "DBusArray.int16(["
    //     0xad1dbc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb2b8] "DBusArray.int16(["
    //     0xad1dc0: ldr             x17, [x17, #0x2b8]
    // 0xad1dc4: StoreField: r0->field_f = r17
    //     0xad1dc4: stur            w17, [x0, #0xf]
    // 0xad1dc8: ldur            x1, [fp, #-0x18]
    // 0xad1dcc: StoreField: r0->field_13 = r1
    //     0xad1dcc: stur            w1, [x0, #0x13]
    // 0xad1dd0: r17 = "])"
    //     0xad1dd0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad1dd4: ldr             x17, [x17, #0x298]
    // 0xad1dd8: StoreField: r0->field_17 = r17
    //     0xad1dd8: stur            w17, [x0, #0x17]
    // 0xad1ddc: SaveReg r0
    //     0xad1ddc: str             x0, [SP, #-8]!
    // 0xad1de0: r0 = _interpolate()
    //     0xad1de0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1de4: add             SP, SP, #8
    // 0xad1de8: LeaveFrame
    //     0xad1de8: mov             SP, fp
    //     0xad1dec: ldp             fp, lr, [SP], #0x10
    // 0xad1df0: ret
    //     0xad1df0: ret             
    // 0xad1df4: ldr             x0, [fp, #0x10]
    // 0xad1df8: r16 = "q"
    //     0xad1df8: ldr             x16, [PP, #0x78e8]  ; [pp+0x78e8] "q"
    // 0xad1dfc: ldur            lr, [fp, #-8]
    // 0xad1e00: stp             lr, x16, [SP, #-0x10]!
    // 0xad1e04: r0 = ==()
    //     0xad1e04: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad1e08: add             SP, SP, #0x10
    // 0xad1e0c: tbnz            w0, #4, #0xad1ea8
    // 0xad1e10: ldr             x0, [fp, #0x10]
    // 0xad1e14: LoadField: r3 = r0->field_b
    //     0xad1e14: ldur            w3, [x0, #0xb]
    // 0xad1e18: DecompressPointer r3
    //     0xad1e18: add             x3, x3, HEAP, lsl #32
    // 0xad1e1c: stur            x3, [fp, #-0x18]
    // 0xad1e20: r1 = Function '<anonymous closure>':.
    //     0xad1e20: add             x1, PP, #0xb, lsl #12  ; [pp+0xb2c0] AnonymousClosure: (0xad2c10), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad1e24: ldr             x1, [x1, #0x2c0]
    // 0xad1e28: r2 = Null
    //     0xad1e28: mov             x2, NULL
    // 0xad1e2c: r0 = AllocateClosure()
    //     0xad1e2c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad1e30: r16 = <int>
    //     0xad1e30: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xad1e34: ldur            lr, [fp, #-0x18]
    // 0xad1e38: stp             lr, x16, [SP, #-0x10]!
    // 0xad1e3c: SaveReg r0
    //     0xad1e3c: str             x0, [SP, #-8]!
    // 0xad1e40: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad1e40: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad1e44: r0 = map()
    //     0xad1e44: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad1e48: add             SP, SP, #0x18
    // 0xad1e4c: r16 = ", "
    //     0xad1e4c: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad1e50: stp             x16, x0, [SP, #-0x10]!
    // 0xad1e54: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad1e54: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad1e58: r0 = join()
    //     0xad1e58: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad1e5c: add             SP, SP, #0x10
    // 0xad1e60: r1 = Null
    //     0xad1e60: mov             x1, NULL
    // 0xad1e64: r2 = 6
    //     0xad1e64: mov             x2, #6
    // 0xad1e68: stur            x0, [fp, #-0x18]
    // 0xad1e6c: r0 = AllocateArray()
    //     0xad1e6c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1e70: r17 = "DBusArray.uint16(["
    //     0xad1e70: add             x17, PP, #0xb, lsl #12  ; [pp+0xb2c8] "DBusArray.uint16(["
    //     0xad1e74: ldr             x17, [x17, #0x2c8]
    // 0xad1e78: StoreField: r0->field_f = r17
    //     0xad1e78: stur            w17, [x0, #0xf]
    // 0xad1e7c: ldur            x1, [fp, #-0x18]
    // 0xad1e80: StoreField: r0->field_13 = r1
    //     0xad1e80: stur            w1, [x0, #0x13]
    // 0xad1e84: r17 = "])"
    //     0xad1e84: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad1e88: ldr             x17, [x17, #0x298]
    // 0xad1e8c: StoreField: r0->field_17 = r17
    //     0xad1e8c: stur            w17, [x0, #0x17]
    // 0xad1e90: SaveReg r0
    //     0xad1e90: str             x0, [SP, #-8]!
    // 0xad1e94: r0 = _interpolate()
    //     0xad1e94: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1e98: add             SP, SP, #8
    // 0xad1e9c: LeaveFrame
    //     0xad1e9c: mov             SP, fp
    //     0xad1ea0: ldp             fp, lr, [SP], #0x10
    // 0xad1ea4: ret
    //     0xad1ea4: ret             
    // 0xad1ea8: ldr             x0, [fp, #0x10]
    // 0xad1eac: r16 = "i"
    //     0xad1eac: ldr             x16, [PP, #0x78f0]  ; [pp+0x78f0] "i"
    // 0xad1eb0: ldur            lr, [fp, #-8]
    // 0xad1eb4: stp             lr, x16, [SP, #-0x10]!
    // 0xad1eb8: r0 = ==()
    //     0xad1eb8: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad1ebc: add             SP, SP, #0x10
    // 0xad1ec0: tbnz            w0, #4, #0xad1f5c
    // 0xad1ec4: ldr             x0, [fp, #0x10]
    // 0xad1ec8: LoadField: r3 = r0->field_b
    //     0xad1ec8: ldur            w3, [x0, #0xb]
    // 0xad1ecc: DecompressPointer r3
    //     0xad1ecc: add             x3, x3, HEAP, lsl #32
    // 0xad1ed0: stur            x3, [fp, #-0x18]
    // 0xad1ed4: r1 = Function '<anonymous closure>':.
    //     0xad1ed4: add             x1, PP, #0xb, lsl #12  ; [pp+0xb2d0] AnonymousClosure: (0xad2bac), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad1ed8: ldr             x1, [x1, #0x2d0]
    // 0xad1edc: r2 = Null
    //     0xad1edc: mov             x2, NULL
    // 0xad1ee0: r0 = AllocateClosure()
    //     0xad1ee0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad1ee4: r16 = <int>
    //     0xad1ee4: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xad1ee8: ldur            lr, [fp, #-0x18]
    // 0xad1eec: stp             lr, x16, [SP, #-0x10]!
    // 0xad1ef0: SaveReg r0
    //     0xad1ef0: str             x0, [SP, #-8]!
    // 0xad1ef4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad1ef4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad1ef8: r0 = map()
    //     0xad1ef8: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad1efc: add             SP, SP, #0x18
    // 0xad1f00: r16 = ", "
    //     0xad1f00: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad1f04: stp             x16, x0, [SP, #-0x10]!
    // 0xad1f08: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad1f08: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad1f0c: r0 = join()
    //     0xad1f0c: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad1f10: add             SP, SP, #0x10
    // 0xad1f14: r1 = Null
    //     0xad1f14: mov             x1, NULL
    // 0xad1f18: r2 = 6
    //     0xad1f18: mov             x2, #6
    // 0xad1f1c: stur            x0, [fp, #-0x18]
    // 0xad1f20: r0 = AllocateArray()
    //     0xad1f20: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1f24: r17 = "DBusArray.int32(["
    //     0xad1f24: add             x17, PP, #0xb, lsl #12  ; [pp+0xb2d8] "DBusArray.int32(["
    //     0xad1f28: ldr             x17, [x17, #0x2d8]
    // 0xad1f2c: StoreField: r0->field_f = r17
    //     0xad1f2c: stur            w17, [x0, #0xf]
    // 0xad1f30: ldur            x1, [fp, #-0x18]
    // 0xad1f34: StoreField: r0->field_13 = r1
    //     0xad1f34: stur            w1, [x0, #0x13]
    // 0xad1f38: r17 = "])"
    //     0xad1f38: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad1f3c: ldr             x17, [x17, #0x298]
    // 0xad1f40: StoreField: r0->field_17 = r17
    //     0xad1f40: stur            w17, [x0, #0x17]
    // 0xad1f44: SaveReg r0
    //     0xad1f44: str             x0, [SP, #-8]!
    // 0xad1f48: r0 = _interpolate()
    //     0xad1f48: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1f4c: add             SP, SP, #8
    // 0xad1f50: LeaveFrame
    //     0xad1f50: mov             SP, fp
    //     0xad1f54: ldp             fp, lr, [SP], #0x10
    // 0xad1f58: ret
    //     0xad1f58: ret             
    // 0xad1f5c: ldr             x0, [fp, #0x10]
    // 0xad1f60: r16 = "u"
    //     0xad1f60: ldr             x16, [PP, #0x78f8]  ; [pp+0x78f8] "u"
    // 0xad1f64: ldur            lr, [fp, #-8]
    // 0xad1f68: stp             lr, x16, [SP, #-0x10]!
    // 0xad1f6c: r0 = ==()
    //     0xad1f6c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad1f70: add             SP, SP, #0x10
    // 0xad1f74: tbnz            w0, #4, #0xad2010
    // 0xad1f78: ldr             x0, [fp, #0x10]
    // 0xad1f7c: LoadField: r3 = r0->field_b
    //     0xad1f7c: ldur            w3, [x0, #0xb]
    // 0xad1f80: DecompressPointer r3
    //     0xad1f80: add             x3, x3, HEAP, lsl #32
    // 0xad1f84: stur            x3, [fp, #-0x18]
    // 0xad1f88: r1 = Function '<anonymous closure>':.
    //     0xad1f88: add             x1, PP, #0xb, lsl #12  ; [pp+0xb2e0] AnonymousClosure: (0xad2b48), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad1f8c: ldr             x1, [x1, #0x2e0]
    // 0xad1f90: r2 = Null
    //     0xad1f90: mov             x2, NULL
    // 0xad1f94: r0 = AllocateClosure()
    //     0xad1f94: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad1f98: r16 = <int>
    //     0xad1f98: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xad1f9c: ldur            lr, [fp, #-0x18]
    // 0xad1fa0: stp             lr, x16, [SP, #-0x10]!
    // 0xad1fa4: SaveReg r0
    //     0xad1fa4: str             x0, [SP, #-8]!
    // 0xad1fa8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad1fa8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad1fac: r0 = map()
    //     0xad1fac: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad1fb0: add             SP, SP, #0x18
    // 0xad1fb4: r16 = ", "
    //     0xad1fb4: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad1fb8: stp             x16, x0, [SP, #-0x10]!
    // 0xad1fbc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad1fbc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad1fc0: r0 = join()
    //     0xad1fc0: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad1fc4: add             SP, SP, #0x10
    // 0xad1fc8: r1 = Null
    //     0xad1fc8: mov             x1, NULL
    // 0xad1fcc: r2 = 6
    //     0xad1fcc: mov             x2, #6
    // 0xad1fd0: stur            x0, [fp, #-0x18]
    // 0xad1fd4: r0 = AllocateArray()
    //     0xad1fd4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1fd8: r17 = "DBusArray.uint32(["
    //     0xad1fd8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb2e8] "DBusArray.uint32(["
    //     0xad1fdc: ldr             x17, [x17, #0x2e8]
    // 0xad1fe0: StoreField: r0->field_f = r17
    //     0xad1fe0: stur            w17, [x0, #0xf]
    // 0xad1fe4: ldur            x1, [fp, #-0x18]
    // 0xad1fe8: StoreField: r0->field_13 = r1
    //     0xad1fe8: stur            w1, [x0, #0x13]
    // 0xad1fec: r17 = "])"
    //     0xad1fec: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad1ff0: ldr             x17, [x17, #0x298]
    // 0xad1ff4: StoreField: r0->field_17 = r17
    //     0xad1ff4: stur            w17, [x0, #0x17]
    // 0xad1ff8: SaveReg r0
    //     0xad1ff8: str             x0, [SP, #-8]!
    // 0xad1ffc: r0 = _interpolate()
    //     0xad1ffc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad2000: add             SP, SP, #8
    // 0xad2004: LeaveFrame
    //     0xad2004: mov             SP, fp
    //     0xad2008: ldp             fp, lr, [SP], #0x10
    // 0xad200c: ret
    //     0xad200c: ret             
    // 0xad2010: ldr             x0, [fp, #0x10]
    // 0xad2014: r16 = "x"
    //     0xad2014: ldr             x16, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xad2018: ldur            lr, [fp, #-8]
    // 0xad201c: stp             lr, x16, [SP, #-0x10]!
    // 0xad2020: r0 = ==()
    //     0xad2020: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad2024: add             SP, SP, #0x10
    // 0xad2028: tbnz            w0, #4, #0xad20c4
    // 0xad202c: ldr             x0, [fp, #0x10]
    // 0xad2030: LoadField: r3 = r0->field_b
    //     0xad2030: ldur            w3, [x0, #0xb]
    // 0xad2034: DecompressPointer r3
    //     0xad2034: add             x3, x3, HEAP, lsl #32
    // 0xad2038: stur            x3, [fp, #-0x18]
    // 0xad203c: r1 = Function '<anonymous closure>':.
    //     0xad203c: add             x1, PP, #0xb, lsl #12  ; [pp+0xb2f0] AnonymousClosure: (0xad2ae4), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad2040: ldr             x1, [x1, #0x2f0]
    // 0xad2044: r2 = Null
    //     0xad2044: mov             x2, NULL
    // 0xad2048: r0 = AllocateClosure()
    //     0xad2048: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad204c: r16 = <int>
    //     0xad204c: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xad2050: ldur            lr, [fp, #-0x18]
    // 0xad2054: stp             lr, x16, [SP, #-0x10]!
    // 0xad2058: SaveReg r0
    //     0xad2058: str             x0, [SP, #-8]!
    // 0xad205c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad205c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad2060: r0 = map()
    //     0xad2060: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad2064: add             SP, SP, #0x18
    // 0xad2068: r16 = ", "
    //     0xad2068: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad206c: stp             x16, x0, [SP, #-0x10]!
    // 0xad2070: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad2070: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad2074: r0 = join()
    //     0xad2074: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad2078: add             SP, SP, #0x10
    // 0xad207c: r1 = Null
    //     0xad207c: mov             x1, NULL
    // 0xad2080: r2 = 6
    //     0xad2080: mov             x2, #6
    // 0xad2084: stur            x0, [fp, #-0x18]
    // 0xad2088: r0 = AllocateArray()
    //     0xad2088: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad208c: r17 = "DBusArray.int64(["
    //     0xad208c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb2f8] "DBusArray.int64(["
    //     0xad2090: ldr             x17, [x17, #0x2f8]
    // 0xad2094: StoreField: r0->field_f = r17
    //     0xad2094: stur            w17, [x0, #0xf]
    // 0xad2098: ldur            x1, [fp, #-0x18]
    // 0xad209c: StoreField: r0->field_13 = r1
    //     0xad209c: stur            w1, [x0, #0x13]
    // 0xad20a0: r17 = "])"
    //     0xad20a0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad20a4: ldr             x17, [x17, #0x298]
    // 0xad20a8: StoreField: r0->field_17 = r17
    //     0xad20a8: stur            w17, [x0, #0x17]
    // 0xad20ac: SaveReg r0
    //     0xad20ac: str             x0, [SP, #-8]!
    // 0xad20b0: r0 = _interpolate()
    //     0xad20b0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad20b4: add             SP, SP, #8
    // 0xad20b8: LeaveFrame
    //     0xad20b8: mov             SP, fp
    //     0xad20bc: ldp             fp, lr, [SP], #0x10
    // 0xad20c0: ret
    //     0xad20c0: ret             
    // 0xad20c4: ldr             x0, [fp, #0x10]
    // 0xad20c8: r16 = "t"
    //     0xad20c8: ldr             x16, [PP, #0x7900]  ; [pp+0x7900] "t"
    // 0xad20cc: ldur            lr, [fp, #-8]
    // 0xad20d0: stp             lr, x16, [SP, #-0x10]!
    // 0xad20d4: r0 = ==()
    //     0xad20d4: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad20d8: add             SP, SP, #0x10
    // 0xad20dc: tbnz            w0, #4, #0xad2178
    // 0xad20e0: ldr             x0, [fp, #0x10]
    // 0xad20e4: LoadField: r3 = r0->field_b
    //     0xad20e4: ldur            w3, [x0, #0xb]
    // 0xad20e8: DecompressPointer r3
    //     0xad20e8: add             x3, x3, HEAP, lsl #32
    // 0xad20ec: stur            x3, [fp, #-0x18]
    // 0xad20f0: r1 = Function '<anonymous closure>':.
    //     0xad20f0: add             x1, PP, #0xb, lsl #12  ; [pp+0xb300] AnonymousClosure: (0xad2a80), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad20f4: ldr             x1, [x1, #0x300]
    // 0xad20f8: r2 = Null
    //     0xad20f8: mov             x2, NULL
    // 0xad20fc: r0 = AllocateClosure()
    //     0xad20fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad2100: r16 = <int>
    //     0xad2100: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xad2104: ldur            lr, [fp, #-0x18]
    // 0xad2108: stp             lr, x16, [SP, #-0x10]!
    // 0xad210c: SaveReg r0
    //     0xad210c: str             x0, [SP, #-8]!
    // 0xad2110: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad2110: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad2114: r0 = map()
    //     0xad2114: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad2118: add             SP, SP, #0x18
    // 0xad211c: r16 = ", "
    //     0xad211c: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad2120: stp             x16, x0, [SP, #-0x10]!
    // 0xad2124: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad2124: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad2128: r0 = join()
    //     0xad2128: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad212c: add             SP, SP, #0x10
    // 0xad2130: r1 = Null
    //     0xad2130: mov             x1, NULL
    // 0xad2134: r2 = 6
    //     0xad2134: mov             x2, #6
    // 0xad2138: stur            x0, [fp, #-0x18]
    // 0xad213c: r0 = AllocateArray()
    //     0xad213c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad2140: r17 = "DBusArray.uint64(["
    //     0xad2140: add             x17, PP, #0xb, lsl #12  ; [pp+0xb308] "DBusArray.uint64(["
    //     0xad2144: ldr             x17, [x17, #0x308]
    // 0xad2148: StoreField: r0->field_f = r17
    //     0xad2148: stur            w17, [x0, #0xf]
    // 0xad214c: ldur            x1, [fp, #-0x18]
    // 0xad2150: StoreField: r0->field_13 = r1
    //     0xad2150: stur            w1, [x0, #0x13]
    // 0xad2154: r17 = "])"
    //     0xad2154: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad2158: ldr             x17, [x17, #0x298]
    // 0xad215c: StoreField: r0->field_17 = r17
    //     0xad215c: stur            w17, [x0, #0x17]
    // 0xad2160: SaveReg r0
    //     0xad2160: str             x0, [SP, #-8]!
    // 0xad2164: r0 = _interpolate()
    //     0xad2164: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad2168: add             SP, SP, #8
    // 0xad216c: LeaveFrame
    //     0xad216c: mov             SP, fp
    //     0xad2170: ldp             fp, lr, [SP], #0x10
    // 0xad2174: ret
    //     0xad2174: ret             
    // 0xad2178: ldr             x0, [fp, #0x10]
    // 0xad217c: r16 = "d"
    //     0xad217c: ldr             x16, [PP, #0x7908]  ; [pp+0x7908] "d"
    // 0xad2180: ldur            lr, [fp, #-8]
    // 0xad2184: stp             lr, x16, [SP, #-0x10]!
    // 0xad2188: r0 = ==()
    //     0xad2188: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad218c: add             SP, SP, #0x10
    // 0xad2190: tbnz            w0, #4, #0xad222c
    // 0xad2194: ldr             x0, [fp, #0x10]
    // 0xad2198: LoadField: r3 = r0->field_b
    //     0xad2198: ldur            w3, [x0, #0xb]
    // 0xad219c: DecompressPointer r3
    //     0xad219c: add             x3, x3, HEAP, lsl #32
    // 0xad21a0: stur            x3, [fp, #-0x18]
    // 0xad21a4: r1 = Function '<anonymous closure>':.
    //     0xad21a4: add             x1, PP, #0xb, lsl #12  ; [pp+0xb310] AnonymousClosure: (0xad29f8), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad21a8: ldr             x1, [x1, #0x310]
    // 0xad21ac: r2 = Null
    //     0xad21ac: mov             x2, NULL
    // 0xad21b0: r0 = AllocateClosure()
    //     0xad21b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad21b4: r16 = <double>
    //     0xad21b4: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xad21b8: ldur            lr, [fp, #-0x18]
    // 0xad21bc: stp             lr, x16, [SP, #-0x10]!
    // 0xad21c0: SaveReg r0
    //     0xad21c0: str             x0, [SP, #-8]!
    // 0xad21c4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad21c4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad21c8: r0 = map()
    //     0xad21c8: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad21cc: add             SP, SP, #0x18
    // 0xad21d0: r16 = ", "
    //     0xad21d0: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad21d4: stp             x16, x0, [SP, #-0x10]!
    // 0xad21d8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad21d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad21dc: r0 = join()
    //     0xad21dc: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad21e0: add             SP, SP, #0x10
    // 0xad21e4: r1 = Null
    //     0xad21e4: mov             x1, NULL
    // 0xad21e8: r2 = 6
    //     0xad21e8: mov             x2, #6
    // 0xad21ec: stur            x0, [fp, #-0x18]
    // 0xad21f0: r0 = AllocateArray()
    //     0xad21f0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad21f4: r17 = "DBusArray.double(["
    //     0xad21f4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb318] "DBusArray.double(["
    //     0xad21f8: ldr             x17, [x17, #0x318]
    // 0xad21fc: StoreField: r0->field_f = r17
    //     0xad21fc: stur            w17, [x0, #0xf]
    // 0xad2200: ldur            x1, [fp, #-0x18]
    // 0xad2204: StoreField: r0->field_13 = r1
    //     0xad2204: stur            w1, [x0, #0x13]
    // 0xad2208: r17 = "])"
    //     0xad2208: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad220c: ldr             x17, [x17, #0x298]
    // 0xad2210: StoreField: r0->field_17 = r17
    //     0xad2210: stur            w17, [x0, #0x17]
    // 0xad2214: SaveReg r0
    //     0xad2214: str             x0, [SP, #-8]!
    // 0xad2218: r0 = _interpolate()
    //     0xad2218: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad221c: add             SP, SP, #8
    // 0xad2220: LeaveFrame
    //     0xad2220: mov             SP, fp
    //     0xad2224: ldp             fp, lr, [SP], #0x10
    // 0xad2228: ret
    //     0xad2228: ret             
    // 0xad222c: ldr             x0, [fp, #0x10]
    // 0xad2230: r16 = "s"
    //     0xad2230: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xad2234: ldur            lr, [fp, #-8]
    // 0xad2238: stp             lr, x16, [SP, #-0x10]!
    // 0xad223c: r0 = ==()
    //     0xad223c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad2240: add             SP, SP, #0x10
    // 0xad2244: tbnz            w0, #4, #0xad22e0
    // 0xad2248: ldr             x0, [fp, #0x10]
    // 0xad224c: LoadField: r3 = r0->field_b
    //     0xad224c: ldur            w3, [x0, #0xb]
    // 0xad2250: DecompressPointer r3
    //     0xad2250: add             x3, x3, HEAP, lsl #32
    // 0xad2254: stur            x3, [fp, #-0x18]
    // 0xad2258: r1 = Function '<anonymous closure>':.
    //     0xad2258: add             x1, PP, #0xb, lsl #12  ; [pp+0xb320] AnonymousClosure: (0xad2954), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad225c: ldr             x1, [x1, #0x320]
    // 0xad2260: r2 = Null
    //     0xad2260: mov             x2, NULL
    // 0xad2264: r0 = AllocateClosure()
    //     0xad2264: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad2268: r16 = <String>
    //     0xad2268: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad226c: ldur            lr, [fp, #-0x18]
    // 0xad2270: stp             lr, x16, [SP, #-0x10]!
    // 0xad2274: SaveReg r0
    //     0xad2274: str             x0, [SP, #-8]!
    // 0xad2278: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad2278: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad227c: r0 = map()
    //     0xad227c: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad2280: add             SP, SP, #0x18
    // 0xad2284: r16 = ", "
    //     0xad2284: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad2288: stp             x16, x0, [SP, #-0x10]!
    // 0xad228c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad228c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad2290: r0 = join()
    //     0xad2290: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad2294: add             SP, SP, #0x10
    // 0xad2298: r1 = Null
    //     0xad2298: mov             x1, NULL
    // 0xad229c: r2 = 6
    //     0xad229c: mov             x2, #6
    // 0xad22a0: stur            x0, [fp, #-0x18]
    // 0xad22a4: r0 = AllocateArray()
    //     0xad22a4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad22a8: r17 = "DBusArray.string(["
    //     0xad22a8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb328] "DBusArray.string(["
    //     0xad22ac: ldr             x17, [x17, #0x328]
    // 0xad22b0: StoreField: r0->field_f = r17
    //     0xad22b0: stur            w17, [x0, #0xf]
    // 0xad22b4: ldur            x1, [fp, #-0x18]
    // 0xad22b8: StoreField: r0->field_13 = r1
    //     0xad22b8: stur            w1, [x0, #0x13]
    // 0xad22bc: r17 = "])"
    //     0xad22bc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad22c0: ldr             x17, [x17, #0x298]
    // 0xad22c4: StoreField: r0->field_17 = r17
    //     0xad22c4: stur            w17, [x0, #0x17]
    // 0xad22c8: SaveReg r0
    //     0xad22c8: str             x0, [SP, #-8]!
    // 0xad22cc: r0 = _interpolate()
    //     0xad22cc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad22d0: add             SP, SP, #8
    // 0xad22d4: LeaveFrame
    //     0xad22d4: mov             SP, fp
    //     0xad22d8: ldp             fp, lr, [SP], #0x10
    // 0xad22dc: ret
    //     0xad22dc: ret             
    // 0xad22e0: ldr             x0, [fp, #0x10]
    // 0xad22e4: r16 = "o"
    //     0xad22e4: ldr             x16, [PP, #0x7690]  ; [pp+0x7690] "o"
    // 0xad22e8: ldur            lr, [fp, #-8]
    // 0xad22ec: stp             lr, x16, [SP, #-0x10]!
    // 0xad22f0: r0 = ==()
    //     0xad22f0: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad22f4: add             SP, SP, #0x10
    // 0xad22f8: tbnz            w0, #4, #0xad2394
    // 0xad22fc: ldr             x0, [fp, #0x10]
    // 0xad2300: LoadField: r3 = r0->field_b
    //     0xad2300: ldur            w3, [x0, #0xb]
    // 0xad2304: DecompressPointer r3
    //     0xad2304: add             x3, x3, HEAP, lsl #32
    // 0xad2308: stur            x3, [fp, #-0x18]
    // 0xad230c: r1 = Function '<anonymous closure>':.
    //     0xad230c: add             x1, PP, #0xb, lsl #12  ; [pp+0xb330] AnonymousClosure: (0xad28ec), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad2310: ldr             x1, [x1, #0x330]
    // 0xad2314: r2 = Null
    //     0xad2314: mov             x2, NULL
    // 0xad2318: r0 = AllocateClosure()
    //     0xad2318: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad231c: r16 = <String>
    //     0xad231c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad2320: ldur            lr, [fp, #-0x18]
    // 0xad2324: stp             lr, x16, [SP, #-0x10]!
    // 0xad2328: SaveReg r0
    //     0xad2328: str             x0, [SP, #-8]!
    // 0xad232c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad232c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad2330: r0 = map()
    //     0xad2330: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad2334: add             SP, SP, #0x18
    // 0xad2338: r16 = ", "
    //     0xad2338: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad233c: stp             x16, x0, [SP, #-0x10]!
    // 0xad2340: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad2340: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad2344: r0 = join()
    //     0xad2344: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad2348: add             SP, SP, #0x10
    // 0xad234c: r1 = Null
    //     0xad234c: mov             x1, NULL
    // 0xad2350: r2 = 6
    //     0xad2350: mov             x2, #6
    // 0xad2354: stur            x0, [fp, #-0x18]
    // 0xad2358: r0 = AllocateArray()
    //     0xad2358: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad235c: r17 = "DBusArray.objectPath(["
    //     0xad235c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb338] "DBusArray.objectPath(["
    //     0xad2360: ldr             x17, [x17, #0x338]
    // 0xad2364: StoreField: r0->field_f = r17
    //     0xad2364: stur            w17, [x0, #0xf]
    // 0xad2368: ldur            x1, [fp, #-0x18]
    // 0xad236c: StoreField: r0->field_13 = r1
    //     0xad236c: stur            w1, [x0, #0x13]
    // 0xad2370: r17 = "])"
    //     0xad2370: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad2374: ldr             x17, [x17, #0x298]
    // 0xad2378: StoreField: r0->field_17 = r17
    //     0xad2378: stur            w17, [x0, #0x17]
    // 0xad237c: SaveReg r0
    //     0xad237c: str             x0, [SP, #-8]!
    // 0xad2380: r0 = _interpolate()
    //     0xad2380: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad2384: add             SP, SP, #8
    // 0xad2388: LeaveFrame
    //     0xad2388: mov             SP, fp
    //     0xad238c: ldp             fp, lr, [SP], #0x10
    // 0xad2390: ret
    //     0xad2390: ret             
    // 0xad2394: ldr             x0, [fp, #0x10]
    // 0xad2398: r16 = "g"
    //     0xad2398: ldr             x16, [PP, #0x76a0]  ; [pp+0x76a0] "g"
    // 0xad239c: ldur            lr, [fp, #-8]
    // 0xad23a0: stp             lr, x16, [SP, #-0x10]!
    // 0xad23a4: r0 = ==()
    //     0xad23a4: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad23a8: add             SP, SP, #0x10
    // 0xad23ac: tbnz            w0, #4, #0xad2448
    // 0xad23b0: ldr             x0, [fp, #0x10]
    // 0xad23b4: LoadField: r3 = r0->field_b
    //     0xad23b4: ldur            w3, [x0, #0xb]
    // 0xad23b8: DecompressPointer r3
    //     0xad23b8: add             x3, x3, HEAP, lsl #32
    // 0xad23bc: stur            x3, [fp, #-0x18]
    // 0xad23c0: r1 = Function '<anonymous closure>':.
    //     0xad23c0: add             x1, PP, #0xb, lsl #12  ; [pp+0xb340] AnonymousClosure: (0xad2884), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad23c4: ldr             x1, [x1, #0x340]
    // 0xad23c8: r2 = Null
    //     0xad23c8: mov             x2, NULL
    // 0xad23cc: r0 = AllocateClosure()
    //     0xad23cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad23d0: r16 = <String>
    //     0xad23d0: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad23d4: ldur            lr, [fp, #-0x18]
    // 0xad23d8: stp             lr, x16, [SP, #-0x10]!
    // 0xad23dc: SaveReg r0
    //     0xad23dc: str             x0, [SP, #-8]!
    // 0xad23e0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad23e0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad23e4: r0 = map()
    //     0xad23e4: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad23e8: add             SP, SP, #0x18
    // 0xad23ec: r16 = ", "
    //     0xad23ec: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad23f0: stp             x16, x0, [SP, #-0x10]!
    // 0xad23f4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad23f4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad23f8: r0 = join()
    //     0xad23f8: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad23fc: add             SP, SP, #0x10
    // 0xad2400: r1 = Null
    //     0xad2400: mov             x1, NULL
    // 0xad2404: r2 = 6
    //     0xad2404: mov             x2, #6
    // 0xad2408: stur            x0, [fp, #-0x18]
    // 0xad240c: r0 = AllocateArray()
    //     0xad240c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad2410: r17 = "DBusArray.signature(["
    //     0xad2410: add             x17, PP, #0xb, lsl #12  ; [pp+0xb348] "DBusArray.signature(["
    //     0xad2414: ldr             x17, [x17, #0x348]
    // 0xad2418: StoreField: r0->field_f = r17
    //     0xad2418: stur            w17, [x0, #0xf]
    // 0xad241c: ldur            x1, [fp, #-0x18]
    // 0xad2420: StoreField: r0->field_13 = r1
    //     0xad2420: stur            w1, [x0, #0x13]
    // 0xad2424: r17 = "])"
    //     0xad2424: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad2428: ldr             x17, [x17, #0x298]
    // 0xad242c: StoreField: r0->field_17 = r17
    //     0xad242c: stur            w17, [x0, #0x17]
    // 0xad2430: SaveReg r0
    //     0xad2430: str             x0, [SP, #-8]!
    // 0xad2434: r0 = _interpolate()
    //     0xad2434: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad2438: add             SP, SP, #8
    // 0xad243c: LeaveFrame
    //     0xad243c: mov             SP, fp
    //     0xad2440: ldp             fp, lr, [SP], #0x10
    // 0xad2444: ret
    //     0xad2444: ret             
    // 0xad2448: ldr             x0, [fp, #0x10]
    // 0xad244c: r16 = "v"
    //     0xad244c: ldr             x16, [PP, #0x7910]  ; [pp+0x7910] "v"
    // 0xad2450: ldur            lr, [fp, #-8]
    // 0xad2454: stp             lr, x16, [SP, #-0x10]!
    // 0xad2458: r0 = ==()
    //     0xad2458: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad245c: add             SP, SP, #0x10
    // 0xad2460: tbnz            w0, #4, #0xad24fc
    // 0xad2464: ldr             x0, [fp, #0x10]
    // 0xad2468: LoadField: r3 = r0->field_b
    //     0xad2468: ldur            w3, [x0, #0xb]
    // 0xad246c: DecompressPointer r3
    //     0xad246c: add             x3, x3, HEAP, lsl #32
    // 0xad2470: stur            x3, [fp, #-0x18]
    // 0xad2474: r1 = Function '<anonymous closure>':.
    //     0xad2474: add             x1, PP, #0xb, lsl #12  ; [pp+0xb350] AnonymousClosure: (0xad2834), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad2478: ldr             x1, [x1, #0x350]
    // 0xad247c: r2 = Null
    //     0xad247c: mov             x2, NULL
    // 0xad2480: r0 = AllocateClosure()
    //     0xad2480: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad2484: r16 = <DBusValue>
    //     0xad2484: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xad2488: ldur            lr, [fp, #-0x18]
    // 0xad248c: stp             lr, x16, [SP, #-0x10]!
    // 0xad2490: SaveReg r0
    //     0xad2490: str             x0, [SP, #-8]!
    // 0xad2494: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad2494: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad2498: r0 = map()
    //     0xad2498: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad249c: add             SP, SP, #0x18
    // 0xad24a0: r16 = ", "
    //     0xad24a0: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad24a4: stp             x16, x0, [SP, #-0x10]!
    // 0xad24a8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad24a8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad24ac: r0 = join()
    //     0xad24ac: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad24b0: add             SP, SP, #0x10
    // 0xad24b4: r1 = Null
    //     0xad24b4: mov             x1, NULL
    // 0xad24b8: r2 = 6
    //     0xad24b8: mov             x2, #6
    // 0xad24bc: stur            x0, [fp, #-0x18]
    // 0xad24c0: r0 = AllocateArray()
    //     0xad24c0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad24c4: r17 = "DBusArray.variant(["
    //     0xad24c4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb358] "DBusArray.variant(["
    //     0xad24c8: ldr             x17, [x17, #0x358]
    // 0xad24cc: StoreField: r0->field_f = r17
    //     0xad24cc: stur            w17, [x0, #0xf]
    // 0xad24d0: ldur            x1, [fp, #-0x18]
    // 0xad24d4: StoreField: r0->field_13 = r1
    //     0xad24d4: stur            w1, [x0, #0x13]
    // 0xad24d8: r17 = "])"
    //     0xad24d8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad24dc: ldr             x17, [x17, #0x298]
    // 0xad24e0: StoreField: r0->field_17 = r17
    //     0xad24e0: stur            w17, [x0, #0x17]
    // 0xad24e4: SaveReg r0
    //     0xad24e4: str             x0, [SP, #-8]!
    // 0xad24e8: r0 = _interpolate()
    //     0xad24e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad24ec: add             SP, SP, #8
    // 0xad24f0: LeaveFrame
    //     0xad24f0: mov             SP, fp
    //     0xad24f4: ldp             fp, lr, [SP], #0x10
    // 0xad24f8: ret
    //     0xad24f8: ret             
    // 0xad24fc: ldr             x0, [fp, #0x10]
    // 0xad2500: r16 = "h"
    //     0xad2500: ldr             x16, [PP, #0x7918]  ; [pp+0x7918] "h"
    // 0xad2504: ldur            lr, [fp, #-8]
    // 0xad2508: stp             lr, x16, [SP, #-0x10]!
    // 0xad250c: r0 = ==()
    //     0xad250c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xad2510: add             SP, SP, #0x10
    // 0xad2514: tbnz            w0, #4, #0xad25b0
    // 0xad2518: ldr             x0, [fp, #0x10]
    // 0xad251c: LoadField: r3 = r0->field_b
    //     0xad251c: ldur            w3, [x0, #0xb]
    // 0xad2520: DecompressPointer r3
    //     0xad2520: add             x3, x3, HEAP, lsl #32
    // 0xad2524: stur            x3, [fp, #-8]
    // 0xad2528: r1 = Function '<anonymous closure>':.
    //     0xad2528: add             x1, PP, #0xb, lsl #12  ; [pp+0xb360] AnonymousClosure: (0xad27e0), in [package:dbus/src/dbus_value.dart] DBusArray::toString (0xad1bac)
    //     0xad252c: ldr             x1, [x1, #0x360]
    // 0xad2530: r2 = Null
    //     0xad2530: mov             x2, NULL
    // 0xad2534: r0 = AllocateClosure()
    //     0xad2534: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad2538: r16 = <ResourceHandle>
    //     0xad2538: ldr             x16, [PP, #0x968]  ; [pp+0x968] TypeArguments: <ResourceHandle>
    // 0xad253c: ldur            lr, [fp, #-8]
    // 0xad2540: stp             lr, x16, [SP, #-0x10]!
    // 0xad2544: SaveReg r0
    //     0xad2544: str             x0, [SP, #-8]!
    // 0xad2548: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad2548: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad254c: r0 = map()
    //     0xad254c: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad2550: add             SP, SP, #0x18
    // 0xad2554: r16 = ", "
    //     0xad2554: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad2558: stp             x16, x0, [SP, #-0x10]!
    // 0xad255c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad255c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad2560: r0 = join()
    //     0xad2560: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad2564: add             SP, SP, #0x10
    // 0xad2568: r1 = Null
    //     0xad2568: mov             x1, NULL
    // 0xad256c: r2 = 6
    //     0xad256c: mov             x2, #6
    // 0xad2570: stur            x0, [fp, #-8]
    // 0xad2574: r0 = AllocateArray()
    //     0xad2574: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad2578: r17 = "DBusArray.unixFd(["
    //     0xad2578: add             x17, PP, #0xb, lsl #12  ; [pp+0xb368] "DBusArray.unixFd(["
    //     0xad257c: ldr             x17, [x17, #0x368]
    // 0xad2580: StoreField: r0->field_f = r17
    //     0xad2580: stur            w17, [x0, #0xf]
    // 0xad2584: ldur            x1, [fp, #-8]
    // 0xad2588: StoreField: r0->field_13 = r1
    //     0xad2588: stur            w1, [x0, #0x13]
    // 0xad258c: r17 = "])"
    //     0xad258c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad2590: ldr             x17, [x17, #0x298]
    // 0xad2594: StoreField: r0->field_17 = r17
    //     0xad2594: stur            w17, [x0, #0x17]
    // 0xad2598: SaveReg r0
    //     0xad2598: str             x0, [SP, #-8]!
    // 0xad259c: r0 = _interpolate()
    //     0xad259c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad25a0: add             SP, SP, #8
    // 0xad25a4: LeaveFrame
    //     0xad25a4: mov             SP, fp
    //     0xad25a8: ldp             fp, lr, [SP], #0x10
    // 0xad25ac: ret
    //     0xad25ac: ret             
    // 0xad25b0: ldr             x0, [fp, #0x10]
    // 0xad25b4: r16 = <String>
    //     0xad25b4: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad25b8: stp             xzr, x16, [SP, #-0x10]!
    // 0xad25bc: r0 = _GrowableList()
    //     0xad25bc: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xad25c0: add             SP, SP, #0x10
    // 0xad25c4: mov             x1, x0
    // 0xad25c8: ldr             x0, [fp, #0x10]
    // 0xad25cc: stur            x1, [fp, #-8]
    // 0xad25d0: LoadField: r2 = r0->field_b
    //     0xad25d0: ldur            w2, [x0, #0xb]
    // 0xad25d4: DecompressPointer r2
    //     0xad25d4: add             x2, x2, HEAP, lsl #32
    // 0xad25d8: r0 = LoadClassIdInstr(r2)
    //     0xad25d8: ldur            x0, [x2, #-1]
    //     0xad25dc: ubfx            x0, x0, #0xc, #0x14
    // 0xad25e0: SaveReg r2
    //     0xad25e0: str             x2, [SP, #-8]!
    // 0xad25e4: r0 = GDT[cid_x0 + 0xb940]()
    //     0xad25e4: mov             x17, #0xb940
    //     0xad25e8: add             lr, x0, x17
    //     0xad25ec: ldr             lr, [x21, lr, lsl #3]
    //     0xad25f0: blr             lr
    // 0xad25f4: add             SP, SP, #8
    // 0xad25f8: mov             x1, x0
    // 0xad25fc: stur            x1, [fp, #-0x18]
    // 0xad2600: ldur            x2, [fp, #-8]
    // 0xad2604: CheckStackOverflow
    //     0xad2604: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad2608: cmp             SP, x16
    //     0xad260c: b.ls            #0xad27d4
    // 0xad2610: r0 = LoadClassIdInstr(r1)
    //     0xad2610: ldur            x0, [x1, #-1]
    //     0xad2614: ubfx            x0, x0, #0xc, #0x14
    // 0xad2618: SaveReg r1
    //     0xad2618: str             x1, [SP, #-8]!
    // 0xad261c: r0 = GDT[cid_x0 + 0x541]()
    //     0xad261c: add             lr, x0, #0x541
    //     0xad2620: ldr             lr, [x21, lr, lsl #3]
    //     0xad2624: blr             lr
    // 0xad2628: add             SP, SP, #8
    // 0xad262c: tbnz            w0, #4, #0xad2724
    // 0xad2630: ldur            x2, [fp, #-8]
    // 0xad2634: ldur            x1, [fp, #-0x18]
    // 0xad2638: r0 = LoadClassIdInstr(r1)
    //     0xad2638: ldur            x0, [x1, #-1]
    //     0xad263c: ubfx            x0, x0, #0xc, #0x14
    // 0xad2640: SaveReg r1
    //     0xad2640: str             x1, [SP, #-8]!
    // 0xad2644: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xad2644: add             lr, x0, #0x5ca
    //     0xad2648: ldr             lr, [x21, lr, lsl #3]
    //     0xad264c: blr             lr
    // 0xad2650: add             SP, SP, #8
    // 0xad2654: r1 = 59
    //     0xad2654: mov             x1, #0x3b
    // 0xad2658: branchIfSmi(r0, 0xad2664)
    //     0xad2658: tbz             w0, #0, #0xad2664
    // 0xad265c: r1 = LoadClassIdInstr(r0)
    //     0xad265c: ldur            x1, [x0, #-1]
    //     0xad2660: ubfx            x1, x1, #0xc, #0x14
    // 0xad2664: SaveReg r0
    //     0xad2664: str             x0, [SP, #-8]!
    // 0xad2668: mov             x0, x1
    // 0xad266c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad266c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad2670: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad2670: mov             x17, #0x3f73
    //     0xad2674: add             lr, x0, x17
    //     0xad2678: ldr             lr, [x21, lr, lsl #3]
    //     0xad267c: blr             lr
    // 0xad2680: add             SP, SP, #8
    // 0xad2684: mov             x1, x0
    // 0xad2688: ldur            x0, [fp, #-8]
    // 0xad268c: stur            x1, [fp, #-0x28]
    // 0xad2690: LoadField: r2 = r0->field_b
    //     0xad2690: ldur            w2, [x0, #0xb]
    // 0xad2694: DecompressPointer r2
    //     0xad2694: add             x2, x2, HEAP, lsl #32
    // 0xad2698: stur            x2, [fp, #-0x20]
    // 0xad269c: LoadField: r3 = r0->field_f
    //     0xad269c: ldur            w3, [x0, #0xf]
    // 0xad26a0: DecompressPointer r3
    //     0xad26a0: add             x3, x3, HEAP, lsl #32
    // 0xad26a4: LoadField: r4 = r3->field_b
    //     0xad26a4: ldur            w4, [x3, #0xb]
    // 0xad26a8: DecompressPointer r4
    //     0xad26a8: add             x4, x4, HEAP, lsl #32
    // 0xad26ac: cmp             w2, w4
    // 0xad26b0: b.ne            #0xad26c0
    // 0xad26b4: SaveReg r0
    //     0xad26b4: str             x0, [SP, #-8]!
    // 0xad26b8: r0 = _growToNextCapacity()
    //     0xad26b8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xad26bc: add             SP, SP, #8
    // 0xad26c0: ldur            x3, [fp, #-8]
    // 0xad26c4: ldur            x0, [fp, #-0x20]
    // 0xad26c8: r2 = LoadInt32Instr(r0)
    //     0xad26c8: sbfx            x2, x0, #1, #0x1f
    // 0xad26cc: add             x0, x2, #1
    // 0xad26d0: lsl             x1, x0, #1
    // 0xad26d4: StoreField: r3->field_b = r1
    //     0xad26d4: stur            w1, [x3, #0xb]
    // 0xad26d8: mov             x1, x2
    // 0xad26dc: cmp             x1, x0
    // 0xad26e0: b.hs            #0xad27dc
    // 0xad26e4: LoadField: r1 = r3->field_f
    //     0xad26e4: ldur            w1, [x3, #0xf]
    // 0xad26e8: DecompressPointer r1
    //     0xad26e8: add             x1, x1, HEAP, lsl #32
    // 0xad26ec: ldur            x0, [fp, #-0x28]
    // 0xad26f0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xad26f0: add             x25, x1, x2, lsl #2
    //     0xad26f4: add             x25, x25, #0xf
    //     0xad26f8: str             w0, [x25]
    //     0xad26fc: tbz             w0, #0, #0xad2718
    //     0xad2700: ldurb           w16, [x1, #-1]
    //     0xad2704: ldurb           w17, [x0, #-1]
    //     0xad2708: and             x16, x17, x16, lsr #2
    //     0xad270c: tst             x16, HEAP, lsr #32
    //     0xad2710: b.eq            #0xad2718
    //     0xad2714: bl              #0xd67e5c
    // 0xad2718: mov             x2, x3
    // 0xad271c: ldur            x1, [fp, #-0x18]
    // 0xad2720: b               #0xad2604
    // 0xad2724: ldur            x0, [fp, #-0x10]
    // 0xad2728: ldur            x3, [fp, #-8]
    // 0xad272c: r1 = Null
    //     0xad272c: mov             x1, NULL
    // 0xad2730: r2 = 12
    //     0xad2730: mov             x2, #0xc
    // 0xad2734: r0 = AllocateArray()
    //     0xad2734: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad2738: stur            x0, [fp, #-0x18]
    // 0xad273c: r17 = DBusArray
    //     0xad273c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb370] Type: DBusArray
    //     0xad2740: ldr             x17, [x17, #0x370]
    // 0xad2744: StoreField: r0->field_f = r17
    //     0xad2744: stur            w17, [x0, #0xf]
    // 0xad2748: r17 = "("
    //     0xad2748: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad274c: StoreField: r0->field_13 = r17
    //     0xad274c: stur            w17, [x0, #0x13]
    // 0xad2750: ldur            x1, [fp, #-0x10]
    // 0xad2754: StoreField: r0->field_17 = r1
    //     0xad2754: stur            w1, [x0, #0x17]
    // 0xad2758: r17 = ", ["
    //     0xad2758: add             x17, PP, #0xb, lsl #12  ; [pp+0xb378] ", ["
    //     0xad275c: ldr             x17, [x17, #0x378]
    // 0xad2760: StoreField: r0->field_1b = r17
    //     0xad2760: stur            w17, [x0, #0x1b]
    // 0xad2764: ldur            x16, [fp, #-8]
    // 0xad2768: r30 = ", "
    //     0xad2768: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad276c: stp             lr, x16, [SP, #-0x10]!
    // 0xad2770: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad2770: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad2774: r0 = join()
    //     0xad2774: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xad2778: add             SP, SP, #0x10
    // 0xad277c: ldur            x1, [fp, #-0x18]
    // 0xad2780: ArrayStore: r1[4] = r0  ; List_4
    //     0xad2780: add             x25, x1, #0x1f
    //     0xad2784: str             w0, [x25]
    //     0xad2788: tbz             w0, #0, #0xad27a4
    //     0xad278c: ldurb           w16, [x1, #-1]
    //     0xad2790: ldurb           w17, [x0, #-1]
    //     0xad2794: and             x16, x17, x16, lsr #2
    //     0xad2798: tst             x16, HEAP, lsr #32
    //     0xad279c: b.eq            #0xad27a4
    //     0xad27a0: bl              #0xd67e5c
    // 0xad27a4: ldur            x0, [fp, #-0x18]
    // 0xad27a8: r17 = "])"
    //     0xad27a8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad27ac: ldr             x17, [x17, #0x298]
    // 0xad27b0: StoreField: r0->field_23 = r17
    //     0xad27b0: stur            w17, [x0, #0x23]
    // 0xad27b4: SaveReg r0
    //     0xad27b4: str             x0, [SP, #-8]!
    // 0xad27b8: r0 = _interpolate()
    //     0xad27b8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad27bc: add             SP, SP, #8
    // 0xad27c0: LeaveFrame
    //     0xad27c0: mov             SP, fp
    //     0xad27c4: ldp             fp, lr, [SP], #0x10
    // 0xad27c8: ret
    //     0xad27c8: ret             
    // 0xad27cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad27cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad27d0: b               #0xad1bc4
    // 0xad27d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad27d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad27d8: b               #0xad2610
    // 0xad27dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xad27dc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] ResourceHandle <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad27e0, size: 0x54
    // 0xad27e0: EnterFrame
    //     0xad27e0: stp             fp, lr, [SP, #-0x10]!
    //     0xad27e4: mov             fp, SP
    // 0xad27e8: ldr             x0, [fp, #0x10]
    // 0xad27ec: r2 = Null
    //     0xad27ec: mov             x2, NULL
    // 0xad27f0: r1 = Null
    //     0xad27f0: mov             x1, NULL
    // 0xad27f4: r4 = LoadClassIdInstr(r0)
    //     0xad27f4: ldur            x4, [x0, #-1]
    //     0xad27f8: ubfx            x4, x4, #0xc, #0x14
    // 0xad27fc: r17 = 4570
    //     0xad27fc: mov             x17, #0x11da
    // 0xad2800: cmp             x4, x17
    // 0xad2804: b.eq            #0xad281c
    // 0xad2808: r8 = DBusUnixFd
    //     0xad2808: add             x8, PP, #0xb, lsl #12  ; [pp+0xb250] Type: DBusUnixFd
    //     0xad280c: ldr             x8, [x8, #0x250]
    // 0xad2810: r3 = Null
    //     0xad2810: add             x3, PP, #0xb, lsl #12  ; [pp+0xb380] Null
    //     0xad2814: ldr             x3, [x3, #0x380]
    // 0xad2818: r0 = DefaultTypeTest()
    //     0xad2818: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad281c: ldr             x1, [fp, #0x10]
    // 0xad2820: LoadField: r0 = r1->field_7
    //     0xad2820: ldur            w0, [x1, #7]
    // 0xad2824: DecompressPointer r0
    //     0xad2824: add             x0, x0, HEAP, lsl #32
    // 0xad2828: LeaveFrame
    //     0xad2828: mov             SP, fp
    //     0xad282c: ldp             fp, lr, [SP], #0x10
    // 0xad2830: ret
    //     0xad2830: ret             
  }
  [closure] DBusValue <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2834, size: 0x50
    // 0xad2834: EnterFrame
    //     0xad2834: stp             fp, lr, [SP, #-0x10]!
    //     0xad2838: mov             fp, SP
    // 0xad283c: ldr             x0, [fp, #0x10]
    // 0xad2840: r2 = Null
    //     0xad2840: mov             x2, NULL
    // 0xad2844: r1 = Null
    //     0xad2844: mov             x1, NULL
    // 0xad2848: r4 = LoadClassIdInstr(r0)
    //     0xad2848: ldur            x4, [x0, #-1]
    //     0xad284c: ubfx            x4, x4, #0xc, #0x14
    // 0xad2850: r17 = 4571
    //     0xad2850: mov             x17, #0x11db
    // 0xad2854: cmp             x4, x17
    // 0xad2858: b.eq            #0xad286c
    // 0xad285c: r8 = DBusVariant
    //     0xad285c: ldr             x8, [PP, #0x7fc0]  ; [pp+0x7fc0] Type: DBusVariant
    // 0xad2860: r3 = Null
    //     0xad2860: add             x3, PP, #0xb, lsl #12  ; [pp+0xb390] Null
    //     0xad2864: ldr             x3, [x3, #0x390]
    // 0xad2868: r0 = DefaultTypeTest()
    //     0xad2868: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad286c: ldr             x1, [fp, #0x10]
    // 0xad2870: LoadField: r0 = r1->field_7
    //     0xad2870: ldur            w0, [x1, #7]
    // 0xad2874: DecompressPointer r0
    //     0xad2874: add             x0, x0, HEAP, lsl #32
    // 0xad2878: LeaveFrame
    //     0xad2878: mov             SP, fp
    //     0xad287c: ldp             fp, lr, [SP], #0x10
    // 0xad2880: ret
    //     0xad2880: ret             
  }
  [closure] String <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2884, size: 0x68
    // 0xad2884: EnterFrame
    //     0xad2884: stp             fp, lr, [SP, #-0x10]!
    //     0xad2888: mov             fp, SP
    // 0xad288c: CheckStackOverflow
    //     0xad288c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad2890: cmp             SP, x16
    //     0xad2894: b.ls            #0xad28e4
    // 0xad2898: ldr             x0, [fp, #0x10]
    // 0xad289c: r2 = Null
    //     0xad289c: mov             x2, NULL
    // 0xad28a0: r1 = Null
    //     0xad28a0: mov             x1, NULL
    // 0xad28a4: r4 = LoadClassIdInstr(r0)
    //     0xad28a4: ldur            x4, [x0, #-1]
    //     0xad28a8: ubfx            x4, x4, #0xc, #0x14
    // 0xad28ac: r17 = 4572
    //     0xad28ac: mov             x17, #0x11dc
    // 0xad28b0: cmp             x4, x17
    // 0xad28b4: b.eq            #0xad28c8
    // 0xad28b8: r8 = DBusSignature
    //     0xad28b8: ldr             x8, [PP, #0x7698]  ; [pp+0x7698] Type: DBusSignature
    // 0xad28bc: r3 = Null
    //     0xad28bc: add             x3, PP, #0xb, lsl #12  ; [pp+0xb3a0] Null
    //     0xad28c0: ldr             x3, [x3, #0x3a0]
    // 0xad28c4: r0 = DBusSignature()
    //     0xad28c4: bl              #0x9fd418  ; IsType_DBusSignature_Stub
    // 0xad28c8: ldr             x16, [fp, #0x10]
    // 0xad28cc: SaveReg r16
    //     0xad28cc: str             x16, [SP, #-8]!
    // 0xad28d0: r0 = toString()
    //     0xad28d0: bl              #0xad1804  ; [package:dbus/src/dbus_value.dart] DBusSignature::toString
    // 0xad28d4: add             SP, SP, #8
    // 0xad28d8: LeaveFrame
    //     0xad28d8: mov             SP, fp
    //     0xad28dc: ldp             fp, lr, [SP], #0x10
    // 0xad28e0: ret
    //     0xad28e0: ret             
    // 0xad28e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad28e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad28e8: b               #0xad2898
  }
  [closure] String <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad28ec, size: 0x68
    // 0xad28ec: EnterFrame
    //     0xad28ec: stp             fp, lr, [SP, #-0x10]!
    //     0xad28f0: mov             fp, SP
    // 0xad28f4: CheckStackOverflow
    //     0xad28f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad28f8: cmp             SP, x16
    //     0xad28fc: b.ls            #0xad294c
    // 0xad2900: ldr             x0, [fp, #0x10]
    // 0xad2904: r2 = Null
    //     0xad2904: mov             x2, NULL
    // 0xad2908: r1 = Null
    //     0xad2908: mov             x1, NULL
    // 0xad290c: r4 = LoadClassIdInstr(r0)
    //     0xad290c: ldur            x4, [x0, #-1]
    //     0xad2910: ubfx            x4, x4, #0xc, #0x14
    // 0xad2914: r17 = 4574
    //     0xad2914: mov             x17, #0x11de
    // 0xad2918: cmp             x4, x17
    // 0xad291c: b.eq            #0xad2930
    // 0xad2920: r8 = DBusObjectPath
    //     0xad2920: ldr             x8, [PP, #0x7688]  ; [pp+0x7688] Type: DBusObjectPath
    // 0xad2924: r3 = Null
    //     0xad2924: add             x3, PP, #0xb, lsl #12  ; [pp+0xb3b0] Null
    //     0xad2928: ldr             x3, [x3, #0x3b0]
    // 0xad292c: r0 = DBusObjectPath()
    //     0xad292c: bl              #0x9fcd54  ; IsType_DBusObjectPath_Stub
    // 0xad2930: ldr             x16, [fp, #0x10]
    // 0xad2934: SaveReg r16
    //     0xad2934: str             x16, [SP, #-8]!
    // 0xad2938: r0 = toString()
    //     0xad2938: bl              #0xad1718  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::toString
    // 0xad293c: add             SP, SP, #8
    // 0xad2940: LeaveFrame
    //     0xad2940: mov             SP, fp
    //     0xad2944: ldp             fp, lr, [SP], #0x10
    // 0xad2948: ret
    //     0xad2948: ret             
    // 0xad294c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad294c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad2950: b               #0xad2900
  }
  [closure] String <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2954, size: 0xa4
    // 0xad2954: EnterFrame
    //     0xad2954: stp             fp, lr, [SP, #-0x10]!
    //     0xad2958: mov             fp, SP
    // 0xad295c: AllocStack(0x8)
    //     0xad295c: sub             SP, SP, #8
    // 0xad2960: CheckStackOverflow
    //     0xad2960: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad2964: cmp             SP, x16
    //     0xad2968: b.ls            #0xad29f0
    // 0xad296c: r1 = Null
    //     0xad296c: mov             x1, NULL
    // 0xad2970: r2 = 6
    //     0xad2970: mov             x2, #6
    // 0xad2974: r0 = AllocateArray()
    //     0xad2974: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad2978: mov             x3, x0
    // 0xad297c: stur            x3, [fp, #-8]
    // 0xad2980: r17 = "\'"
    //     0xad2980: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad2984: StoreField: r3->field_f = r17
    //     0xad2984: stur            w17, [x3, #0xf]
    // 0xad2988: ldr             x0, [fp, #0x10]
    // 0xad298c: r2 = Null
    //     0xad298c: mov             x2, NULL
    // 0xad2990: r1 = Null
    //     0xad2990: mov             x1, NULL
    // 0xad2994: r4 = LoadClassIdInstr(r0)
    //     0xad2994: ldur            x4, [x0, #-1]
    //     0xad2998: ubfx            x4, x4, #0xc, #0x14
    // 0xad299c: r17 = -4573
    //     0xad299c: mov             x17, #-0x11dd
    // 0xad29a0: add             x4, x4, x17
    // 0xad29a4: cmp             x4, #1
    // 0xad29a8: b.ls            #0xad29bc
    // 0xad29ac: r8 = DBusString
    //     0xad29ac: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xad29b0: r3 = Null
    //     0xad29b0: add             x3, PP, #0xb, lsl #12  ; [pp+0xb3c0] Null
    //     0xad29b4: ldr             x3, [x3, #0x3c0]
    // 0xad29b8: r0 = DefaultTypeTest()
    //     0xad29b8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad29bc: ldr             x0, [fp, #0x10]
    // 0xad29c0: LoadField: r1 = r0->field_7
    //     0xad29c0: ldur            w1, [x0, #7]
    // 0xad29c4: DecompressPointer r1
    //     0xad29c4: add             x1, x1, HEAP, lsl #32
    // 0xad29c8: ldur            x0, [fp, #-8]
    // 0xad29cc: StoreField: r0->field_13 = r1
    //     0xad29cc: stur            w1, [x0, #0x13]
    // 0xad29d0: r17 = "\'"
    //     0xad29d0: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad29d4: StoreField: r0->field_17 = r17
    //     0xad29d4: stur            w17, [x0, #0x17]
    // 0xad29d8: SaveReg r0
    //     0xad29d8: str             x0, [SP, #-8]!
    // 0xad29dc: r0 = _interpolate()
    //     0xad29dc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad29e0: add             SP, SP, #8
    // 0xad29e4: LeaveFrame
    //     0xad29e4: mov             SP, fp
    //     0xad29e8: ldp             fp, lr, [SP], #0x10
    // 0xad29ec: ret
    //     0xad29ec: ret             
    // 0xad29f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad29f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad29f4: b               #0xad296c
  }
  [closure] double <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad29f8, size: 0x88
    // 0xad29f8: EnterFrame
    //     0xad29f8: stp             fp, lr, [SP, #-0x10]!
    //     0xad29fc: mov             fp, SP
    // 0xad2a00: ldr             x0, [fp, #0x10]
    // 0xad2a04: r2 = Null
    //     0xad2a04: mov             x2, NULL
    // 0xad2a08: r1 = Null
    //     0xad2a08: mov             x1, NULL
    // 0xad2a0c: r4 = LoadClassIdInstr(r0)
    //     0xad2a0c: ldur            x4, [x0, #-1]
    //     0xad2a10: ubfx            x4, x4, #0xc, #0x14
    // 0xad2a14: r17 = 4575
    //     0xad2a14: mov             x17, #0x11df
    // 0xad2a18: cmp             x4, x17
    // 0xad2a1c: b.eq            #0xad2a34
    // 0xad2a20: r8 = DBusDouble
    //     0xad2a20: add             x8, PP, #0xb, lsl #12  ; [pp+0xb270] Type: DBusDouble
    //     0xad2a24: ldr             x8, [x8, #0x270]
    // 0xad2a28: r3 = Null
    //     0xad2a28: add             x3, PP, #0xb, lsl #12  ; [pp+0xb3d0] Null
    //     0xad2a2c: ldr             x3, [x3, #0x3d0]
    // 0xad2a30: r0 = DefaultTypeTest()
    //     0xad2a30: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad2a34: ldr             x1, [fp, #0x10]
    // 0xad2a38: LoadField: d0 = r1->field_7
    //     0xad2a38: ldur            d0, [x1, #7]
    // 0xad2a3c: r0 = inline_Allocate_Double()
    //     0xad2a3c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xad2a40: add             x0, x0, #0x10
    //     0xad2a44: cmp             x1, x0
    //     0xad2a48: b.ls            #0xad2a70
    //     0xad2a4c: str             x0, [THR, #0x60]  ; THR::top
    //     0xad2a50: sub             x0, x0, #0xf
    //     0xad2a54: mov             x1, #0xd108
    //     0xad2a58: movk            x1, #3, lsl #16
    //     0xad2a5c: stur            x1, [x0, #-1]
    // 0xad2a60: StoreField: r0->field_7 = d0
    //     0xad2a60: stur            d0, [x0, #7]
    // 0xad2a64: LeaveFrame
    //     0xad2a64: mov             SP, fp
    //     0xad2a68: ldp             fp, lr, [SP], #0x10
    // 0xad2a6c: ret
    //     0xad2a6c: ret             
    // 0xad2a70: SaveReg d0
    //     0xad2a70: str             q0, [SP, #-0x10]!
    // 0xad2a74: r0 = AllocateDouble()
    //     0xad2a74: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad2a78: RestoreReg d0
    //     0xad2a78: ldr             q0, [SP], #0x10
    // 0xad2a7c: b               #0xad2a60
  }
  [closure] int <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2a80, size: 0x64
    // 0xad2a80: EnterFrame
    //     0xad2a80: stp             fp, lr, [SP, #-0x10]!
    //     0xad2a84: mov             fp, SP
    // 0xad2a88: ldr             x0, [fp, #0x10]
    // 0xad2a8c: r2 = Null
    //     0xad2a8c: mov             x2, NULL
    // 0xad2a90: r1 = Null
    //     0xad2a90: mov             x1, NULL
    // 0xad2a94: r4 = LoadClassIdInstr(r0)
    //     0xad2a94: ldur            x4, [x0, #-1]
    //     0xad2a98: ubfx            x4, x4, #0xc, #0x14
    // 0xad2a9c: r17 = 4576
    //     0xad2a9c: mov             x17, #0x11e0
    // 0xad2aa0: cmp             x4, x17
    // 0xad2aa4: b.eq            #0xad2abc
    // 0xad2aa8: r8 = DBusUint64
    //     0xad2aa8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb3e0] Type: DBusUint64
    //     0xad2aac: ldr             x8, [x8, #0x3e0]
    // 0xad2ab0: r3 = Null
    //     0xad2ab0: add             x3, PP, #0xb, lsl #12  ; [pp+0xb3e8] Null
    //     0xad2ab4: ldr             x3, [x3, #0x3e8]
    // 0xad2ab8: r0 = DefaultTypeTest()
    //     0xad2ab8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad2abc: ldr             x2, [fp, #0x10]
    // 0xad2ac0: LoadField: r3 = r2->field_7
    //     0xad2ac0: ldur            x3, [x2, #7]
    // 0xad2ac4: r0 = BoxInt64Instr(r3)
    //     0xad2ac4: sbfiz           x0, x3, #1, #0x1f
    //     0xad2ac8: cmp             x3, x0, asr #1
    //     0xad2acc: b.eq            #0xad2ad8
    //     0xad2ad0: bl              #0xd69bb8
    //     0xad2ad4: stur            x3, [x0, #7]
    // 0xad2ad8: LeaveFrame
    //     0xad2ad8: mov             SP, fp
    //     0xad2adc: ldp             fp, lr, [SP], #0x10
    // 0xad2ae0: ret
    //     0xad2ae0: ret             
  }
  [closure] int <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2ae4, size: 0x64
    // 0xad2ae4: EnterFrame
    //     0xad2ae4: stp             fp, lr, [SP, #-0x10]!
    //     0xad2ae8: mov             fp, SP
    // 0xad2aec: ldr             x0, [fp, #0x10]
    // 0xad2af0: r2 = Null
    //     0xad2af0: mov             x2, NULL
    // 0xad2af4: r1 = Null
    //     0xad2af4: mov             x1, NULL
    // 0xad2af8: r4 = LoadClassIdInstr(r0)
    //     0xad2af8: ldur            x4, [x0, #-1]
    //     0xad2afc: ubfx            x4, x4, #0xc, #0x14
    // 0xad2b00: r17 = 4577
    //     0xad2b00: mov             x17, #0x11e1
    // 0xad2b04: cmp             x4, x17
    // 0xad2b08: b.eq            #0xad2b20
    // 0xad2b0c: r8 = DBusInt64
    //     0xad2b0c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb258] Type: DBusInt64
    //     0xad2b10: ldr             x8, [x8, #0x258]
    // 0xad2b14: r3 = Null
    //     0xad2b14: add             x3, PP, #0xb, lsl #12  ; [pp+0xb3f8] Null
    //     0xad2b18: ldr             x3, [x3, #0x3f8]
    // 0xad2b1c: r0 = DefaultTypeTest()
    //     0xad2b1c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad2b20: ldr             x2, [fp, #0x10]
    // 0xad2b24: LoadField: r3 = r2->field_7
    //     0xad2b24: ldur            x3, [x2, #7]
    // 0xad2b28: r0 = BoxInt64Instr(r3)
    //     0xad2b28: sbfiz           x0, x3, #1, #0x1f
    //     0xad2b2c: cmp             x3, x0, asr #1
    //     0xad2b30: b.eq            #0xad2b3c
    //     0xad2b34: bl              #0xd69bb8
    //     0xad2b38: stur            x3, [x0, #7]
    // 0xad2b3c: LeaveFrame
    //     0xad2b3c: mov             SP, fp
    //     0xad2b40: ldp             fp, lr, [SP], #0x10
    // 0xad2b44: ret
    //     0xad2b44: ret             
  }
  [closure] int <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2b48, size: 0x64
    // 0xad2b48: EnterFrame
    //     0xad2b48: stp             fp, lr, [SP, #-0x10]!
    //     0xad2b4c: mov             fp, SP
    // 0xad2b50: ldr             x0, [fp, #0x10]
    // 0xad2b54: r2 = Null
    //     0xad2b54: mov             x2, NULL
    // 0xad2b58: r1 = Null
    //     0xad2b58: mov             x1, NULL
    // 0xad2b5c: r4 = LoadClassIdInstr(r0)
    //     0xad2b5c: ldur            x4, [x0, #-1]
    //     0xad2b60: ubfx            x4, x4, #0xc, #0x14
    // 0xad2b64: r17 = 4578
    //     0xad2b64: mov             x17, #0x11e2
    // 0xad2b68: cmp             x4, x17
    // 0xad2b6c: b.eq            #0xad2b84
    // 0xad2b70: r8 = DBusUint32
    //     0xad2b70: add             x8, PP, #8, lsl #12  ; [pp+0x8028] Type: DBusUint32
    //     0xad2b74: ldr             x8, [x8, #0x28]
    // 0xad2b78: r3 = Null
    //     0xad2b78: add             x3, PP, #0xb, lsl #12  ; [pp+0xb408] Null
    //     0xad2b7c: ldr             x3, [x3, #0x408]
    // 0xad2b80: r0 = DefaultTypeTest()
    //     0xad2b80: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad2b84: ldr             x2, [fp, #0x10]
    // 0xad2b88: LoadField: r3 = r2->field_7
    //     0xad2b88: ldur            x3, [x2, #7]
    // 0xad2b8c: r0 = BoxInt64Instr(r3)
    //     0xad2b8c: sbfiz           x0, x3, #1, #0x1f
    //     0xad2b90: cmp             x3, x0, asr #1
    //     0xad2b94: b.eq            #0xad2ba0
    //     0xad2b98: bl              #0xd69bb8
    //     0xad2b9c: stur            x3, [x0, #7]
    // 0xad2ba0: LeaveFrame
    //     0xad2ba0: mov             SP, fp
    //     0xad2ba4: ldp             fp, lr, [SP], #0x10
    // 0xad2ba8: ret
    //     0xad2ba8: ret             
  }
  [closure] int <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2bac, size: 0x64
    // 0xad2bac: EnterFrame
    //     0xad2bac: stp             fp, lr, [SP, #-0x10]!
    //     0xad2bb0: mov             fp, SP
    // 0xad2bb4: ldr             x0, [fp, #0x10]
    // 0xad2bb8: r2 = Null
    //     0xad2bb8: mov             x2, NULL
    // 0xad2bbc: r1 = Null
    //     0xad2bbc: mov             x1, NULL
    // 0xad2bc0: r4 = LoadClassIdInstr(r0)
    //     0xad2bc0: ldur            x4, [x0, #-1]
    //     0xad2bc4: ubfx            x4, x4, #0xc, #0x14
    // 0xad2bc8: r17 = 4579
    //     0xad2bc8: mov             x17, #0x11e3
    // 0xad2bcc: cmp             x4, x17
    // 0xad2bd0: b.eq            #0xad2be8
    // 0xad2bd4: r8 = DBusInt32
    //     0xad2bd4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb278] Type: DBusInt32
    //     0xad2bd8: ldr             x8, [x8, #0x278]
    // 0xad2bdc: r3 = Null
    //     0xad2bdc: add             x3, PP, #0xb, lsl #12  ; [pp+0xb418] Null
    //     0xad2be0: ldr             x3, [x3, #0x418]
    // 0xad2be4: r0 = DefaultTypeTest()
    //     0xad2be4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad2be8: ldr             x2, [fp, #0x10]
    // 0xad2bec: LoadField: r3 = r2->field_7
    //     0xad2bec: ldur            x3, [x2, #7]
    // 0xad2bf0: r0 = BoxInt64Instr(r3)
    //     0xad2bf0: sbfiz           x0, x3, #1, #0x1f
    //     0xad2bf4: cmp             x3, x0, asr #1
    //     0xad2bf8: b.eq            #0xad2c04
    //     0xad2bfc: bl              #0xd69bb8
    //     0xad2c00: stur            x3, [x0, #7]
    // 0xad2c04: LeaveFrame
    //     0xad2c04: mov             SP, fp
    //     0xad2c08: ldp             fp, lr, [SP], #0x10
    // 0xad2c0c: ret
    //     0xad2c0c: ret             
  }
  [closure] int <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2c10, size: 0x64
    // 0xad2c10: EnterFrame
    //     0xad2c10: stp             fp, lr, [SP, #-0x10]!
    //     0xad2c14: mov             fp, SP
    // 0xad2c18: ldr             x0, [fp, #0x10]
    // 0xad2c1c: r2 = Null
    //     0xad2c1c: mov             x2, NULL
    // 0xad2c20: r1 = Null
    //     0xad2c20: mov             x1, NULL
    // 0xad2c24: r4 = LoadClassIdInstr(r0)
    //     0xad2c24: ldur            x4, [x0, #-1]
    //     0xad2c28: ubfx            x4, x4, #0xc, #0x14
    // 0xad2c2c: r17 = 4580
    //     0xad2c2c: mov             x17, #0x11e4
    // 0xad2c30: cmp             x4, x17
    // 0xad2c34: b.eq            #0xad2c4c
    // 0xad2c38: r8 = DBusUint16
    //     0xad2c38: add             x8, PP, #0xb, lsl #12  ; [pp+0xb260] Type: DBusUint16
    //     0xad2c3c: ldr             x8, [x8, #0x260]
    // 0xad2c40: r3 = Null
    //     0xad2c40: add             x3, PP, #0xb, lsl #12  ; [pp+0xb428] Null
    //     0xad2c44: ldr             x3, [x3, #0x428]
    // 0xad2c48: r0 = DefaultTypeTest()
    //     0xad2c48: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad2c4c: ldr             x2, [fp, #0x10]
    // 0xad2c50: LoadField: r3 = r2->field_7
    //     0xad2c50: ldur            x3, [x2, #7]
    // 0xad2c54: r0 = BoxInt64Instr(r3)
    //     0xad2c54: sbfiz           x0, x3, #1, #0x1f
    //     0xad2c58: cmp             x3, x0, asr #1
    //     0xad2c5c: b.eq            #0xad2c68
    //     0xad2c60: bl              #0xd69bb8
    //     0xad2c64: stur            x3, [x0, #7]
    // 0xad2c68: LeaveFrame
    //     0xad2c68: mov             SP, fp
    //     0xad2c6c: ldp             fp, lr, [SP], #0x10
    // 0xad2c70: ret
    //     0xad2c70: ret             
  }
  [closure] int <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2c74, size: 0x64
    // 0xad2c74: EnterFrame
    //     0xad2c74: stp             fp, lr, [SP, #-0x10]!
    //     0xad2c78: mov             fp, SP
    // 0xad2c7c: ldr             x0, [fp, #0x10]
    // 0xad2c80: r2 = Null
    //     0xad2c80: mov             x2, NULL
    // 0xad2c84: r1 = Null
    //     0xad2c84: mov             x1, NULL
    // 0xad2c88: r4 = LoadClassIdInstr(r0)
    //     0xad2c88: ldur            x4, [x0, #-1]
    //     0xad2c8c: ubfx            x4, x4, #0xc, #0x14
    // 0xad2c90: r17 = 4581
    //     0xad2c90: mov             x17, #0x11e5
    // 0xad2c94: cmp             x4, x17
    // 0xad2c98: b.eq            #0xad2cb0
    // 0xad2c9c: r8 = DBusInt16
    //     0xad2c9c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb268] Type: DBusInt16
    //     0xad2ca0: ldr             x8, [x8, #0x268]
    // 0xad2ca4: r3 = Null
    //     0xad2ca4: add             x3, PP, #0xb, lsl #12  ; [pp+0xb438] Null
    //     0xad2ca8: ldr             x3, [x3, #0x438]
    // 0xad2cac: r0 = DefaultTypeTest()
    //     0xad2cac: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad2cb0: ldr             x2, [fp, #0x10]
    // 0xad2cb4: LoadField: r3 = r2->field_7
    //     0xad2cb4: ldur            x3, [x2, #7]
    // 0xad2cb8: r0 = BoxInt64Instr(r3)
    //     0xad2cb8: sbfiz           x0, x3, #1, #0x1f
    //     0xad2cbc: cmp             x3, x0, asr #1
    //     0xad2cc0: b.eq            #0xad2ccc
    //     0xad2cc4: bl              #0xd69bb8
    //     0xad2cc8: stur            x3, [x0, #7]
    // 0xad2ccc: LeaveFrame
    //     0xad2ccc: mov             SP, fp
    //     0xad2cd0: ldp             fp, lr, [SP], #0x10
    // 0xad2cd4: ret
    //     0xad2cd4: ret             
  }
  [closure] bool <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2cd8, size: 0x54
    // 0xad2cd8: EnterFrame
    //     0xad2cd8: stp             fp, lr, [SP, #-0x10]!
    //     0xad2cdc: mov             fp, SP
    // 0xad2ce0: ldr             x0, [fp, #0x10]
    // 0xad2ce4: r2 = Null
    //     0xad2ce4: mov             x2, NULL
    // 0xad2ce8: r1 = Null
    //     0xad2ce8: mov             x1, NULL
    // 0xad2cec: r4 = LoadClassIdInstr(r0)
    //     0xad2cec: ldur            x4, [x0, #-1]
    //     0xad2cf0: ubfx            x4, x4, #0xc, #0x14
    // 0xad2cf4: r17 = 4582
    //     0xad2cf4: mov             x17, #0x11e6
    // 0xad2cf8: cmp             x4, x17
    // 0xad2cfc: b.eq            #0xad2d14
    // 0xad2d00: r8 = DBusBoolean
    //     0xad2d00: add             x8, PP, #0xb, lsl #12  ; [pp+0xb280] Type: DBusBoolean
    //     0xad2d04: ldr             x8, [x8, #0x280]
    // 0xad2d08: r3 = Null
    //     0xad2d08: add             x3, PP, #0xb, lsl #12  ; [pp+0xb448] Null
    //     0xad2d0c: ldr             x3, [x3, #0x448]
    // 0xad2d10: r0 = DefaultTypeTest()
    //     0xad2d10: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad2d14: ldr             x1, [fp, #0x10]
    // 0xad2d18: LoadField: r0 = r1->field_7
    //     0xad2d18: ldur            w0, [x1, #7]
    // 0xad2d1c: DecompressPointer r0
    //     0xad2d1c: add             x0, x0, HEAP, lsl #32
    // 0xad2d20: LeaveFrame
    //     0xad2d20: mov             SP, fp
    //     0xad2d24: ldp             fp, lr, [SP], #0x10
    // 0xad2d28: ret
    //     0xad2d28: ret             
  }
  [closure] int <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad2d2c, size: 0x60
    // 0xad2d2c: EnterFrame
    //     0xad2d2c: stp             fp, lr, [SP, #-0x10]!
    //     0xad2d30: mov             fp, SP
    // 0xad2d34: ldr             x0, [fp, #0x10]
    // 0xad2d38: r2 = Null
    //     0xad2d38: mov             x2, NULL
    // 0xad2d3c: r1 = Null
    //     0xad2d3c: mov             x1, NULL
    // 0xad2d40: r4 = LoadClassIdInstr(r0)
    //     0xad2d40: ldur            x4, [x0, #-1]
    //     0xad2d44: ubfx            x4, x4, #0xc, #0x14
    // 0xad2d48: r17 = 4583
    //     0xad2d48: mov             x17, #0x11e7
    // 0xad2d4c: cmp             x4, x17
    // 0xad2d50: b.eq            #0xad2d64
    // 0xad2d54: r8 = DBusByte
    //     0xad2d54: ldr             x8, [PP, #0x7fa8]  ; [pp+0x7fa8] Type: DBusByte
    // 0xad2d58: r3 = Null
    //     0xad2d58: add             x3, PP, #0xb, lsl #12  ; [pp+0xb458] Null
    //     0xad2d5c: ldr             x3, [x3, #0x458]
    // 0xad2d60: r0 = DefaultTypeTest()
    //     0xad2d60: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xad2d64: ldr             x2, [fp, #0x10]
    // 0xad2d68: LoadField: r3 = r2->field_7
    //     0xad2d68: ldur            x3, [x2, #7]
    // 0xad2d6c: r0 = BoxInt64Instr(r3)
    //     0xad2d6c: sbfiz           x0, x3, #1, #0x1f
    //     0xad2d70: cmp             x3, x0, asr #1
    //     0xad2d74: b.eq            #0xad2d80
    //     0xad2d78: bl              #0xd69bb8
    //     0xad2d7c: stur            x3, [x0, #7]
    // 0xad2d80: LeaveFrame
    //     0xad2d80: mov             SP, fp
    //     0xad2d84: ldp             fp, lr, [SP], #0x10
    // 0xad2d88: ret
    //     0xad2d88: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafa858, size: 0x58
    // 0xafa858: EnterFrame
    //     0xafa858: stp             fp, lr, [SP, #-0x10]!
    //     0xafa85c: mov             fp, SP
    // 0xafa860: CheckStackOverflow
    //     0xafa860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafa864: cmp             SP, x16
    //     0xafa868: b.ls            #0xafa8a8
    // 0xafa86c: ldr             x0, [fp, #0x10]
    // 0xafa870: LoadField: r1 = r0->field_b
    //     0xafa870: ldur            w1, [x0, #0xb]
    // 0xafa874: DecompressPointer r1
    //     0xafa874: add             x1, x1, HEAP, lsl #32
    // 0xafa878: SaveReg r1
    //     0xafa878: str             x1, [SP, #-8]!
    // 0xafa87c: r0 = hashAll()
    //     0xafa87c: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xafa880: add             SP, SP, #8
    // 0xafa884: mov             x2, x0
    // 0xafa888: r0 = BoxInt64Instr(r2)
    //     0xafa888: sbfiz           x0, x2, #1, #0x1f
    //     0xafa88c: cmp             x2, x0, asr #1
    //     0xafa890: b.eq            #0xafa89c
    //     0xafa894: bl              #0xd69bb8
    //     0xafa898: stur            x2, [x0, #7]
    // 0xafa89c: LeaveFrame
    //     0xafa89c: mov             SP, fp
    //     0xafa8a0: ldp             fp, lr, [SP], #0x10
    // 0xafa8a4: ret
    //     0xafa8a4: ret             
    // 0xafa8a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa8a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa8ac: b               #0xafa86c
  }
  _ toNative(/* No info */) {
    // ** addr: 0xc43260, size: 0x64
    // 0xc43260: EnterFrame
    //     0xc43260: stp             fp, lr, [SP, #-0x10]!
    //     0xc43264: mov             fp, SP
    // 0xc43268: AllocStack(0x8)
    //     0xc43268: sub             SP, SP, #8
    // 0xc4326c: CheckStackOverflow
    //     0xc4326c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc43270: cmp             SP, x16
    //     0xc43274: b.ls            #0xc432bc
    // 0xc43278: ldr             x0, [fp, #0x10]
    // 0xc4327c: LoadField: r3 = r0->field_b
    //     0xc4327c: ldur            w3, [x0, #0xb]
    // 0xc43280: DecompressPointer r3
    //     0xc43280: add             x3, x3, HEAP, lsl #32
    // 0xc43284: stur            x3, [fp, #-8]
    // 0xc43288: r1 = Function '<anonymous closure>':.
    //     0xc43288: add             x1, PP, #0xc, lsl #12  ; [pp+0xc7c8] AnonymousClosure: (0xad1114), in [package:dbus/src/dbus_method_response.dart] DBusMethodResponseException::toString (0xad0ef0)
    //     0xc4328c: ldr             x1, [x1, #0x7c8]
    // 0xc43290: r2 = Null
    //     0xc43290: mov             x2, NULL
    // 0xc43294: r0 = AllocateClosure()
    //     0xc43294: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc43298: ldur            x16, [fp, #-8]
    // 0xc4329c: stp             x16, NULL, [SP, #-0x10]!
    // 0xc432a0: SaveReg r0
    //     0xc432a0: str             x0, [SP, #-8]!
    // 0xc432a4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc432a4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc432a8: r0 = map()
    //     0xc432a8: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xc432ac: add             SP, SP, #0x18
    // 0xc432b0: LeaveFrame
    //     0xc432b0: mov             SP, fp
    //     0xc432b4: ldp             fp, lr, [SP], #0x10
    // 0xc432b8: ret
    //     0xc432b8: ret             
    // 0xc432bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc432bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc432c0: b               #0xc43278
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc63944, size: 0x84
    // 0xc63944: EnterFrame
    //     0xc63944: stp             fp, lr, [SP, #-0x10]!
    //     0xc63948: mov             fp, SP
    // 0xc6394c: AllocStack(0x10)
    //     0xc6394c: sub             SP, SP, #0x10
    // 0xc63950: CheckStackOverflow
    //     0xc63950: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63954: cmp             SP, x16
    //     0xc63958: b.ls            #0xc639c0
    // 0xc6395c: r1 = Null
    //     0xc6395c: mov             x1, NULL
    // 0xc63960: r2 = 4
    //     0xc63960: mov             x2, #4
    // 0xc63964: r0 = AllocateArray()
    //     0xc63964: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc63968: r17 = "a"
    //     0xc63968: ldr             x17, [PP, #0x440]  ; [pp+0x440] "a"
    // 0xc6396c: StoreField: r0->field_f = r17
    //     0xc6396c: stur            w17, [x0, #0xf]
    // 0xc63970: ldr             x1, [fp, #0x10]
    // 0xc63974: LoadField: r2 = r1->field_7
    //     0xc63974: ldur            w2, [x1, #7]
    // 0xc63978: DecompressPointer r2
    //     0xc63978: add             x2, x2, HEAP, lsl #32
    // 0xc6397c: LoadField: r1 = r2->field_7
    //     0xc6397c: ldur            w1, [x2, #7]
    // 0xc63980: DecompressPointer r1
    //     0xc63980: add             x1, x1, HEAP, lsl #32
    // 0xc63984: StoreField: r0->field_13 = r1
    //     0xc63984: stur            w1, [x0, #0x13]
    // 0xc63988: SaveReg r0
    //     0xc63988: str             x0, [SP, #-8]!
    // 0xc6398c: r0 = _interpolate()
    //     0xc6398c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc63990: add             SP, SP, #8
    // 0xc63994: stur            x0, [fp, #-8]
    // 0xc63998: r0 = DBusSignature()
    //     0xc63998: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc6399c: stur            x0, [fp, #-0x10]
    // 0xc639a0: ldur            x16, [fp, #-8]
    // 0xc639a4: stp             x16, x0, [SP, #-0x10]!
    // 0xc639a8: r0 = DBusSignature()
    //     0xc639a8: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc639ac: add             SP, SP, #0x10
    // 0xc639b0: ldur            x0, [fp, #-0x10]
    // 0xc639b4: LeaveFrame
    //     0xc639b4: mov             SP, fp
    //     0xc639b8: ldp             fp, lr, [SP], #0x10
    // 0xc639bc: ret
    //     0xc639bc: ret             
    // 0xc639c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc639c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc639c4: b               #0xc6395c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6ed80, size: 0xc0
    // 0xc6ed80: EnterFrame
    //     0xc6ed80: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ed84: mov             fp, SP
    // 0xc6ed88: CheckStackOverflow
    //     0xc6ed88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ed8c: cmp             SP, x16
    //     0xc6ed90: b.ls            #0xc6ee38
    // 0xc6ed94: ldr             x0, [fp, #0x10]
    // 0xc6ed98: cmp             w0, NULL
    // 0xc6ed9c: b.ne            #0xc6edb0
    // 0xc6eda0: r0 = false
    //     0xc6eda0: add             x0, NULL, #0x30  ; false
    // 0xc6eda4: LeaveFrame
    //     0xc6eda4: mov             SP, fp
    //     0xc6eda8: ldp             fp, lr, [SP], #0x10
    // 0xc6edac: ret
    //     0xc6edac: ret             
    // 0xc6edb0: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6edb0: mov             x1, #0x76
    //     0xc6edb4: tbz             w0, #0, #0xc6edc4
    //     0xc6edb8: ldur            x1, [x0, #-1]
    //     0xc6edbc: ubfx            x1, x1, #0xc, #0x14
    //     0xc6edc0: lsl             x1, x1, #1
    // 0xc6edc4: r17 = 9136
    //     0xc6edc4: mov             x17, #0x23b0
    // 0xc6edc8: cmp             w1, w17
    // 0xc6edcc: b.ne            #0xc6ee28
    // 0xc6edd0: ldr             x1, [fp, #0x18]
    // 0xc6edd4: LoadField: r2 = r0->field_7
    //     0xc6edd4: ldur            w2, [x0, #7]
    // 0xc6edd8: DecompressPointer r2
    //     0xc6edd8: add             x2, x2, HEAP, lsl #32
    // 0xc6eddc: LoadField: r3 = r1->field_7
    //     0xc6eddc: ldur            w3, [x1, #7]
    // 0xc6ede0: DecompressPointer r3
    //     0xc6ede0: add             x3, x3, HEAP, lsl #32
    // 0xc6ede4: stp             x3, x2, [SP, #-0x10]!
    // 0xc6ede8: r0 = ==()
    //     0xc6ede8: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0xc6edec: add             SP, SP, #0x10
    // 0xc6edf0: tbnz            w0, #4, #0xc6ee28
    // 0xc6edf4: ldr             x1, [fp, #0x18]
    // 0xc6edf8: ldr             x0, [fp, #0x10]
    // 0xc6edfc: LoadField: r2 = r0->field_b
    //     0xc6edfc: ldur            w2, [x0, #0xb]
    // 0xc6ee00: DecompressPointer r2
    //     0xc6ee00: add             x2, x2, HEAP, lsl #32
    // 0xc6ee04: LoadField: r0 = r1->field_b
    //     0xc6ee04: ldur            w0, [x1, #0xb]
    // 0xc6ee08: DecompressPointer r0
    //     0xc6ee08: add             x0, x0, HEAP, lsl #32
    // 0xc6ee0c: r16 = <DBusValue>
    //     0xc6ee0c: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xc6ee10: stp             x2, x16, [SP, #-0x10]!
    // 0xc6ee14: SaveReg r0
    //     0xc6ee14: str             x0, [SP, #-8]!
    // 0xc6ee18: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6ee18: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6ee1c: r0 = _listsEqual()
    //     0xc6ee1c: bl              #0xc6df40  ; [package:dbus/src/dbus_introspect.dart] ::_listsEqual
    // 0xc6ee20: add             SP, SP, #0x18
    // 0xc6ee24: b               #0xc6ee2c
    // 0xc6ee28: r0 = false
    //     0xc6ee28: add             x0, NULL, #0x30  ; false
    // 0xc6ee2c: LeaveFrame
    //     0xc6ee2c: mov             SP, fp
    //     0xc6ee30: ldp             fp, lr, [SP], #0x10
    // 0xc6ee34: ret
    //     0xc6ee34: ret             
    // 0xc6ee38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ee38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ee3c: b               #0xc6ed94
  }
}

// class id: 4569, size: 0xc, field offset: 0x8
class DBusStruct extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad1980, size: 0x22c
    // 0xad1980: EnterFrame
    //     0xad1980: stp             fp, lr, [SP, #-0x10]!
    //     0xad1984: mov             fp, SP
    // 0xad1988: AllocStack(0x20)
    //     0xad1988: sub             SP, SP, #0x20
    // 0xad198c: CheckStackOverflow
    //     0xad198c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1990: cmp             SP, x16
    //     0xad1994: b.ls            #0xad1b98
    // 0xad1998: r16 = <String>
    //     0xad1998: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad199c: stp             xzr, x16, [SP, #-0x10]!
    // 0xad19a0: r0 = _GrowableList()
    //     0xad19a0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xad19a4: add             SP, SP, #0x10
    // 0xad19a8: mov             x1, x0
    // 0xad19ac: ldr             x0, [fp, #0x10]
    // 0xad19b0: stur            x1, [fp, #-8]
    // 0xad19b4: LoadField: r2 = r0->field_7
    //     0xad19b4: ldur            w2, [x0, #7]
    // 0xad19b8: DecompressPointer r2
    //     0xad19b8: add             x2, x2, HEAP, lsl #32
    // 0xad19bc: r0 = LoadClassIdInstr(r2)
    //     0xad19bc: ldur            x0, [x2, #-1]
    //     0xad19c0: ubfx            x0, x0, #0xc, #0x14
    // 0xad19c4: SaveReg r2
    //     0xad19c4: str             x2, [SP, #-8]!
    // 0xad19c8: r0 = GDT[cid_x0 + 0xb940]()
    //     0xad19c8: mov             x17, #0xb940
    //     0xad19cc: add             lr, x0, x17
    //     0xad19d0: ldr             lr, [x21, lr, lsl #3]
    //     0xad19d4: blr             lr
    // 0xad19d8: add             SP, SP, #8
    // 0xad19dc: mov             x1, x0
    // 0xad19e0: stur            x1, [fp, #-0x10]
    // 0xad19e4: ldur            x2, [fp, #-8]
    // 0xad19e8: CheckStackOverflow
    //     0xad19e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad19ec: cmp             SP, x16
    //     0xad19f0: b.ls            #0xad1ba0
    // 0xad19f4: r0 = LoadClassIdInstr(r1)
    //     0xad19f4: ldur            x0, [x1, #-1]
    //     0xad19f8: ubfx            x0, x0, #0xc, #0x14
    // 0xad19fc: SaveReg r1
    //     0xad19fc: str             x1, [SP, #-8]!
    // 0xad1a00: r0 = GDT[cid_x0 + 0x541]()
    //     0xad1a00: add             lr, x0, #0x541
    //     0xad1a04: ldr             lr, [x21, lr, lsl #3]
    //     0xad1a08: blr             lr
    // 0xad1a0c: add             SP, SP, #8
    // 0xad1a10: tbnz            w0, #4, #0xad1b08
    // 0xad1a14: ldur            x2, [fp, #-8]
    // 0xad1a18: ldur            x1, [fp, #-0x10]
    // 0xad1a1c: r0 = LoadClassIdInstr(r1)
    //     0xad1a1c: ldur            x0, [x1, #-1]
    //     0xad1a20: ubfx            x0, x0, #0xc, #0x14
    // 0xad1a24: SaveReg r1
    //     0xad1a24: str             x1, [SP, #-8]!
    // 0xad1a28: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xad1a28: add             lr, x0, #0x5ca
    //     0xad1a2c: ldr             lr, [x21, lr, lsl #3]
    //     0xad1a30: blr             lr
    // 0xad1a34: add             SP, SP, #8
    // 0xad1a38: r1 = 59
    //     0xad1a38: mov             x1, #0x3b
    // 0xad1a3c: branchIfSmi(r0, 0xad1a48)
    //     0xad1a3c: tbz             w0, #0, #0xad1a48
    // 0xad1a40: r1 = LoadClassIdInstr(r0)
    //     0xad1a40: ldur            x1, [x0, #-1]
    //     0xad1a44: ubfx            x1, x1, #0xc, #0x14
    // 0xad1a48: SaveReg r0
    //     0xad1a48: str             x0, [SP, #-8]!
    // 0xad1a4c: mov             x0, x1
    // 0xad1a50: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad1a50: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad1a54: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad1a54: mov             x17, #0x3f73
    //     0xad1a58: add             lr, x0, x17
    //     0xad1a5c: ldr             lr, [x21, lr, lsl #3]
    //     0xad1a60: blr             lr
    // 0xad1a64: add             SP, SP, #8
    // 0xad1a68: mov             x1, x0
    // 0xad1a6c: ldur            x0, [fp, #-8]
    // 0xad1a70: stur            x1, [fp, #-0x20]
    // 0xad1a74: LoadField: r2 = r0->field_b
    //     0xad1a74: ldur            w2, [x0, #0xb]
    // 0xad1a78: DecompressPointer r2
    //     0xad1a78: add             x2, x2, HEAP, lsl #32
    // 0xad1a7c: stur            x2, [fp, #-0x18]
    // 0xad1a80: LoadField: r3 = r0->field_f
    //     0xad1a80: ldur            w3, [x0, #0xf]
    // 0xad1a84: DecompressPointer r3
    //     0xad1a84: add             x3, x3, HEAP, lsl #32
    // 0xad1a88: LoadField: r4 = r3->field_b
    //     0xad1a88: ldur            w4, [x3, #0xb]
    // 0xad1a8c: DecompressPointer r4
    //     0xad1a8c: add             x4, x4, HEAP, lsl #32
    // 0xad1a90: cmp             w2, w4
    // 0xad1a94: b.ne            #0xad1aa4
    // 0xad1a98: SaveReg r0
    //     0xad1a98: str             x0, [SP, #-8]!
    // 0xad1a9c: r0 = _growToNextCapacity()
    //     0xad1a9c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xad1aa0: add             SP, SP, #8
    // 0xad1aa4: ldur            x3, [fp, #-8]
    // 0xad1aa8: ldur            x0, [fp, #-0x18]
    // 0xad1aac: r2 = LoadInt32Instr(r0)
    //     0xad1aac: sbfx            x2, x0, #1, #0x1f
    // 0xad1ab0: add             x0, x2, #1
    // 0xad1ab4: lsl             x1, x0, #1
    // 0xad1ab8: StoreField: r3->field_b = r1
    //     0xad1ab8: stur            w1, [x3, #0xb]
    // 0xad1abc: mov             x1, x2
    // 0xad1ac0: cmp             x1, x0
    // 0xad1ac4: b.hs            #0xad1ba8
    // 0xad1ac8: LoadField: r1 = r3->field_f
    //     0xad1ac8: ldur            w1, [x3, #0xf]
    // 0xad1acc: DecompressPointer r1
    //     0xad1acc: add             x1, x1, HEAP, lsl #32
    // 0xad1ad0: ldur            x0, [fp, #-0x20]
    // 0xad1ad4: ArrayStore: r1[r2] = r0  ; List_4
    //     0xad1ad4: add             x25, x1, x2, lsl #2
    //     0xad1ad8: add             x25, x25, #0xf
    //     0xad1adc: str             w0, [x25]
    //     0xad1ae0: tbz             w0, #0, #0xad1afc
    //     0xad1ae4: ldurb           w16, [x1, #-1]
    //     0xad1ae8: ldurb           w17, [x0, #-1]
    //     0xad1aec: and             x16, x17, x16, lsr #2
    //     0xad1af0: tst             x16, HEAP, lsr #32
    //     0xad1af4: b.eq            #0xad1afc
    //     0xad1af8: bl              #0xd67e5c
    // 0xad1afc: mov             x2, x3
    // 0xad1b00: ldur            x1, [fp, #-0x10]
    // 0xad1b04: b               #0xad19e8
    // 0xad1b08: ldur            x3, [fp, #-8]
    // 0xad1b0c: r1 = Null
    //     0xad1b0c: mov             x1, NULL
    // 0xad1b10: r2 = 8
    //     0xad1b10: mov             x2, #8
    // 0xad1b14: r0 = AllocateArray()
    //     0xad1b14: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1b18: stur            x0, [fp, #-0x10]
    // 0xad1b1c: r17 = DBusStruct
    //     0xad1b1c: ldr             x17, [PP, #0x7f90]  ; [pp+0x7f90] Type: DBusStruct
    // 0xad1b20: StoreField: r0->field_f = r17
    //     0xad1b20: stur            w17, [x0, #0xf]
    // 0xad1b24: r17 = "(["
    //     0xad1b24: add             x17, PP, #0xb, lsl #12  ; [pp+0xb4f0] "(["
    //     0xad1b28: ldr             x17, [x17, #0x4f0]
    // 0xad1b2c: StoreField: r0->field_13 = r17
    //     0xad1b2c: stur            w17, [x0, #0x13]
    // 0xad1b30: ldur            x16, [fp, #-8]
    // 0xad1b34: r30 = ", "
    //     0xad1b34: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad1b38: stp             lr, x16, [SP, #-0x10]!
    // 0xad1b3c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad1b3c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad1b40: r0 = join()
    //     0xad1b40: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xad1b44: add             SP, SP, #0x10
    // 0xad1b48: ldur            x1, [fp, #-0x10]
    // 0xad1b4c: ArrayStore: r1[2] = r0  ; List_4
    //     0xad1b4c: add             x25, x1, #0x17
    //     0xad1b50: str             w0, [x25]
    //     0xad1b54: tbz             w0, #0, #0xad1b70
    //     0xad1b58: ldurb           w16, [x1, #-1]
    //     0xad1b5c: ldurb           w17, [x0, #-1]
    //     0xad1b60: and             x16, x17, x16, lsr #2
    //     0xad1b64: tst             x16, HEAP, lsr #32
    //     0xad1b68: b.eq            #0xad1b70
    //     0xad1b6c: bl              #0xd67e5c
    // 0xad1b70: ldur            x0, [fp, #-0x10]
    // 0xad1b74: r17 = "])"
    //     0xad1b74: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad1b78: ldr             x17, [x17, #0x298]
    // 0xad1b7c: StoreField: r0->field_1b = r17
    //     0xad1b7c: stur            w17, [x0, #0x1b]
    // 0xad1b80: SaveReg r0
    //     0xad1b80: str             x0, [SP, #-8]!
    // 0xad1b84: r0 = _interpolate()
    //     0xad1b84: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1b88: add             SP, SP, #8
    // 0xad1b8c: LeaveFrame
    //     0xad1b8c: mov             SP, fp
    //     0xad1b90: ldp             fp, lr, [SP], #0x10
    // 0xad1b94: ret
    //     0xad1b94: ret             
    // 0xad1b98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1b98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1b9c: b               #0xad1998
    // 0xad1ba0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1ba0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1ba4: b               #0xad19f4
    // 0xad1ba8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xad1ba8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ toNative(/* No info */) {
    // ** addr: 0xc431fc, size: 0x64
    // 0xc431fc: EnterFrame
    //     0xc431fc: stp             fp, lr, [SP, #-0x10]!
    //     0xc43200: mov             fp, SP
    // 0xc43204: AllocStack(0x8)
    //     0xc43204: sub             SP, SP, #8
    // 0xc43208: CheckStackOverflow
    //     0xc43208: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4320c: cmp             SP, x16
    //     0xc43210: b.ls            #0xc43258
    // 0xc43214: ldr             x0, [fp, #0x10]
    // 0xc43218: LoadField: r3 = r0->field_7
    //     0xc43218: ldur            w3, [x0, #7]
    // 0xc4321c: DecompressPointer r3
    //     0xc4321c: add             x3, x3, HEAP, lsl #32
    // 0xc43220: stur            x3, [fp, #-8]
    // 0xc43224: r1 = Function '<anonymous closure>':.
    //     0xc43224: add             x1, PP, #0xc, lsl #12  ; [pp+0xc820] AnonymousClosure: (0xad1114), in [package:dbus/src/dbus_method_response.dart] DBusMethodResponseException::toString (0xad0ef0)
    //     0xc43228: ldr             x1, [x1, #0x820]
    // 0xc4322c: r2 = Null
    //     0xc4322c: mov             x2, NULL
    // 0xc43230: r0 = AllocateClosure()
    //     0xc43230: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc43234: ldur            x16, [fp, #-8]
    // 0xc43238: stp             x16, NULL, [SP, #-0x10]!
    // 0xc4323c: SaveReg r0
    //     0xc4323c: str             x0, [SP, #-8]!
    // 0xc43240: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc43240: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc43244: r0 = map()
    //     0xc43244: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xc43248: add             SP, SP, #0x18
    // 0xc4324c: LeaveFrame
    //     0xc4324c: mov             SP, fp
    //     0xc43250: ldp             fp, lr, [SP], #0x10
    // 0xc43254: ret
    //     0xc43254: ret             
    // 0xc43258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43258: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4325c: b               #0xc43214
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc637f0, size: 0x154
    // 0xc637f0: EnterFrame
    //     0xc637f0: stp             fp, lr, [SP, #-0x10]!
    //     0xc637f4: mov             fp, SP
    // 0xc637f8: AllocStack(0x10)
    //     0xc637f8: sub             SP, SP, #0x10
    // 0xc637fc: CheckStackOverflow
    //     0xc637fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63800: cmp             SP, x16
    //     0xc63804: b.ls            #0xc63934
    // 0xc63808: ldr             x0, [fp, #0x10]
    // 0xc6380c: LoadField: r1 = r0->field_7
    //     0xc6380c: ldur            w1, [x0, #7]
    // 0xc63810: DecompressPointer r1
    //     0xc63810: add             x1, x1, HEAP, lsl #32
    // 0xc63814: r0 = LoadClassIdInstr(r1)
    //     0xc63814: ldur            x0, [x1, #-1]
    //     0xc63818: ubfx            x0, x0, #0xc, #0x14
    // 0xc6381c: SaveReg r1
    //     0xc6381c: str             x1, [SP, #-8]!
    // 0xc63820: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc63820: mov             x17, #0xb940
    //     0xc63824: add             lr, x0, x17
    //     0xc63828: ldr             lr, [x21, lr, lsl #3]
    //     0xc6382c: blr             lr
    // 0xc63830: add             SP, SP, #8
    // 0xc63834: mov             x1, x0
    // 0xc63838: stur            x1, [fp, #-0x10]
    // 0xc6383c: r2 = ""
    //     0xc6383c: ldr             x2, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xc63840: stur            x2, [fp, #-8]
    // 0xc63844: CheckStackOverflow
    //     0xc63844: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63848: cmp             SP, x16
    //     0xc6384c: b.ls            #0xc6393c
    // 0xc63850: r0 = LoadClassIdInstr(r1)
    //     0xc63850: ldur            x0, [x1, #-1]
    //     0xc63854: ubfx            x0, x0, #0xc, #0x14
    // 0xc63858: SaveReg r1
    //     0xc63858: str             x1, [SP, #-8]!
    // 0xc6385c: r0 = GDT[cid_x0 + 0x541]()
    //     0xc6385c: add             lr, x0, #0x541
    //     0xc63860: ldr             lr, [x21, lr, lsl #3]
    //     0xc63864: blr             lr
    // 0xc63868: add             SP, SP, #8
    // 0xc6386c: tbnz            w0, #4, #0xc638d4
    // 0xc63870: ldur            x1, [fp, #-0x10]
    // 0xc63874: r0 = LoadClassIdInstr(r1)
    //     0xc63874: ldur            x0, [x1, #-1]
    //     0xc63878: ubfx            x0, x0, #0xc, #0x14
    // 0xc6387c: SaveReg r1
    //     0xc6387c: str             x1, [SP, #-8]!
    // 0xc63880: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc63880: add             lr, x0, #0x5ca
    //     0xc63884: ldr             lr, [x21, lr, lsl #3]
    //     0xc63888: blr             lr
    // 0xc6388c: add             SP, SP, #8
    // 0xc63890: r1 = LoadClassIdInstr(r0)
    //     0xc63890: ldur            x1, [x0, #-1]
    //     0xc63894: ubfx            x1, x1, #0xc, #0x14
    // 0xc63898: SaveReg r0
    //     0xc63898: str             x0, [SP, #-8]!
    // 0xc6389c: mov             x0, x1
    // 0xc638a0: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xc638a0: add             lr, x0, #0x2b8
    //     0xc638a4: ldr             lr, [x21, lr, lsl #3]
    //     0xc638a8: blr             lr
    // 0xc638ac: add             SP, SP, #8
    // 0xc638b0: LoadField: r1 = r0->field_7
    //     0xc638b0: ldur            w1, [x0, #7]
    // 0xc638b4: DecompressPointer r1
    //     0xc638b4: add             x1, x1, HEAP, lsl #32
    // 0xc638b8: ldur            x16, [fp, #-8]
    // 0xc638bc: stp             x1, x16, [SP, #-0x10]!
    // 0xc638c0: r0 = +()
    //     0xc638c0: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0xc638c4: add             SP, SP, #0x10
    // 0xc638c8: mov             x2, x0
    // 0xc638cc: ldur            x1, [fp, #-0x10]
    // 0xc638d0: b               #0xc63840
    // 0xc638d4: ldur            x0, [fp, #-8]
    // 0xc638d8: r1 = Null
    //     0xc638d8: mov             x1, NULL
    // 0xc638dc: r2 = 6
    //     0xc638dc: mov             x2, #6
    // 0xc638e0: r0 = AllocateArray()
    //     0xc638e0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc638e4: r17 = "("
    //     0xc638e4: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xc638e8: StoreField: r0->field_f = r17
    //     0xc638e8: stur            w17, [x0, #0xf]
    // 0xc638ec: ldur            x1, [fp, #-8]
    // 0xc638f0: StoreField: r0->field_13 = r1
    //     0xc638f0: stur            w1, [x0, #0x13]
    // 0xc638f4: r17 = ")"
    //     0xc638f4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xc638f8: StoreField: r0->field_17 = r17
    //     0xc638f8: stur            w17, [x0, #0x17]
    // 0xc638fc: SaveReg r0
    //     0xc638fc: str             x0, [SP, #-8]!
    // 0xc63900: r0 = _interpolate()
    //     0xc63900: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc63904: add             SP, SP, #8
    // 0xc63908: stur            x0, [fp, #-8]
    // 0xc6390c: r0 = DBusSignature()
    //     0xc6390c: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc63910: stur            x0, [fp, #-0x10]
    // 0xc63914: ldur            x16, [fp, #-8]
    // 0xc63918: stp             x16, x0, [SP, #-0x10]!
    // 0xc6391c: r0 = DBusSignature()
    //     0xc6391c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc63920: add             SP, SP, #0x10
    // 0xc63924: ldur            x0, [fp, #-0x10]
    // 0xc63928: LeaveFrame
    //     0xc63928: mov             SP, fp
    //     0xc6392c: ldp             fp, lr, [SP], #0x10
    // 0xc63930: ret
    //     0xc63930: ret             
    // 0xc63934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc63934: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc63938: b               #0xc63808
    // 0xc6393c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6393c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc63940: b               #0xc63850
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6ece8, size: 0x98
    // 0xc6ece8: EnterFrame
    //     0xc6ece8: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ecec: mov             fp, SP
    // 0xc6ecf0: CheckStackOverflow
    //     0xc6ecf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ecf4: cmp             SP, x16
    //     0xc6ecf8: b.ls            #0xc6ed78
    // 0xc6ecfc: ldr             x0, [fp, #0x10]
    // 0xc6ed00: cmp             w0, NULL
    // 0xc6ed04: b.ne            #0xc6ed18
    // 0xc6ed08: r0 = false
    //     0xc6ed08: add             x0, NULL, #0x30  ; false
    // 0xc6ed0c: LeaveFrame
    //     0xc6ed0c: mov             SP, fp
    //     0xc6ed10: ldp             fp, lr, [SP], #0x10
    // 0xc6ed14: ret
    //     0xc6ed14: ret             
    // 0xc6ed18: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6ed18: mov             x1, #0x76
    //     0xc6ed1c: tbz             w0, #0, #0xc6ed2c
    //     0xc6ed20: ldur            x1, [x0, #-1]
    //     0xc6ed24: ubfx            x1, x1, #0xc, #0x14
    //     0xc6ed28: lsl             x1, x1, #1
    // 0xc6ed2c: r17 = 9138
    //     0xc6ed2c: mov             x17, #0x23b2
    // 0xc6ed30: cmp             w1, w17
    // 0xc6ed34: b.ne            #0xc6ed68
    // 0xc6ed38: ldr             x1, [fp, #0x18]
    // 0xc6ed3c: LoadField: r2 = r0->field_7
    //     0xc6ed3c: ldur            w2, [x0, #7]
    // 0xc6ed40: DecompressPointer r2
    //     0xc6ed40: add             x2, x2, HEAP, lsl #32
    // 0xc6ed44: LoadField: r0 = r1->field_7
    //     0xc6ed44: ldur            w0, [x1, #7]
    // 0xc6ed48: DecompressPointer r0
    //     0xc6ed48: add             x0, x0, HEAP, lsl #32
    // 0xc6ed4c: r16 = <DBusValue>
    //     0xc6ed4c: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xc6ed50: stp             x2, x16, [SP, #-0x10]!
    // 0xc6ed54: SaveReg r0
    //     0xc6ed54: str             x0, [SP, #-8]!
    // 0xc6ed58: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6ed58: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6ed5c: r0 = _listsEqual()
    //     0xc6ed5c: bl              #0xc6df40  ; [package:dbus/src/dbus_introspect.dart] ::_listsEqual
    // 0xc6ed60: add             SP, SP, #0x18
    // 0xc6ed64: b               #0xc6ed6c
    // 0xc6ed68: r0 = false
    //     0xc6ed68: add             x0, NULL, #0x30  ; false
    // 0xc6ed6c: LeaveFrame
    //     0xc6ed6c: mov             SP, fp
    //     0xc6ed70: ldp             fp, lr, [SP], #0x10
    // 0xc6ed74: ret
    //     0xc6ed74: ret             
    // 0xc6ed78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ed78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ed7c: b               #0xc6ecfc
  }
}

// class id: 4570, size: 0xc, field offset: 0x8
//   const constructor, 
class DBusUnixFd extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad192c, size: 0x54
    // 0xad192c: EnterFrame
    //     0xad192c: stp             fp, lr, [SP, #-0x10]!
    //     0xad1930: mov             fp, SP
    // 0xad1934: CheckStackOverflow
    //     0xad1934: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1938: cmp             SP, x16
    //     0xad193c: b.ls            #0xad1978
    // 0xad1940: r1 = Null
    //     0xad1940: mov             x1, NULL
    // 0xad1944: r2 = 4
    //     0xad1944: mov             x2, #4
    // 0xad1948: r0 = AllocateArray()
    //     0xad1948: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad194c: r17 = DBusUnixFd
    //     0xad194c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb250] Type: DBusUnixFd
    //     0xad1950: ldr             x17, [x17, #0x250]
    // 0xad1954: StoreField: r0->field_f = r17
    //     0xad1954: stur            w17, [x0, #0xf]
    // 0xad1958: r17 = "()"
    //     0xad1958: ldr             x17, [PP, #0x4aa0]  ; [pp+0x4aa0] "()"
    // 0xad195c: StoreField: r0->field_13 = r17
    //     0xad195c: stur            w17, [x0, #0x13]
    // 0xad1960: SaveReg r0
    //     0xad1960: str             x0, [SP, #-8]!
    // 0xad1964: r0 = _interpolate()
    //     0xad1964: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1968: add             SP, SP, #8
    // 0xad196c: LeaveFrame
    //     0xad196c: mov             SP, fp
    //     0xad1970: ldp             fp, lr, [SP], #0x10
    // 0xad1974: ret
    //     0xad1974: ret             
    // 0xad1978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1978: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad197c: b               #0xad1940
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc637a8, size: 0x48
    // 0xc637a8: EnterFrame
    //     0xc637a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc637ac: mov             fp, SP
    // 0xc637b0: AllocStack(0x8)
    //     0xc637b0: sub             SP, SP, #8
    // 0xc637b4: CheckStackOverflow
    //     0xc637b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc637b8: cmp             SP, x16
    //     0xc637bc: b.ls            #0xc637e8
    // 0xc637c0: r0 = DBusSignature()
    //     0xc637c0: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc637c4: stur            x0, [fp, #-8]
    // 0xc637c8: r16 = "h"
    //     0xc637c8: ldr             x16, [PP, #0x7918]  ; [pp+0x7918] "h"
    // 0xc637cc: stp             x16, x0, [SP, #-0x10]!
    // 0xc637d0: r0 = DBusSignature()
    //     0xc637d0: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc637d4: add             SP, SP, #0x10
    // 0xc637d8: ldur            x0, [fp, #-8]
    // 0xc637dc: LeaveFrame
    //     0xc637dc: mov             SP, fp
    //     0xc637e0: ldp             fp, lr, [SP], #0x10
    // 0xc637e4: ret
    //     0xc637e4: ret             
    // 0xc637e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc637e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc637ec: b               #0xc637c0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6ec80, size: 0x68
    // 0xc6ec80: ldr             x1, [SP]
    // 0xc6ec84: cmp             w1, NULL
    // 0xc6ec88: b.ne            #0xc6ec94
    // 0xc6ec8c: r0 = false
    //     0xc6ec8c: add             x0, NULL, #0x30  ; false
    // 0xc6ec90: ret
    //     0xc6ec90: ret             
    // 0xc6ec94: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6ec94: mov             x2, #0x76
    //     0xc6ec98: tbz             w1, #0, #0xc6eca8
    //     0xc6ec9c: ldur            x2, [x1, #-1]
    //     0xc6eca0: ubfx            x2, x2, #0xc, #0x14
    //     0xc6eca4: lsl             x2, x2, #1
    // 0xc6eca8: r17 = 9140
    //     0xc6eca8: mov             x17, #0x23b4
    // 0xc6ecac: cmp             w2, w17
    // 0xc6ecb0: b.ne            #0xc6ece0
    // 0xc6ecb4: ldr             x2, [SP, #8]
    // 0xc6ecb8: LoadField: r3 = r1->field_7
    //     0xc6ecb8: ldur            w3, [x1, #7]
    // 0xc6ecbc: DecompressPointer r3
    //     0xc6ecbc: add             x3, x3, HEAP, lsl #32
    // 0xc6ecc0: LoadField: r1 = r2->field_7
    //     0xc6ecc0: ldur            w1, [x2, #7]
    // 0xc6ecc4: DecompressPointer r1
    //     0xc6ecc4: add             x1, x1, HEAP, lsl #32
    // 0xc6ecc8: cmp             w3, w1
    // 0xc6eccc: r16 = true
    //     0xc6eccc: add             x16, NULL, #0x20  ; true
    // 0xc6ecd0: r17 = false
    //     0xc6ecd0: add             x17, NULL, #0x30  ; false
    // 0xc6ecd4: csel            x2, x16, x17, eq
    // 0xc6ecd8: mov             x0, x2
    // 0xc6ecdc: b               #0xc6ece4
    // 0xc6ece0: r0 = false
    //     0xc6ece0: add             x0, NULL, #0x30  ; false
    // 0xc6ece4: ret
    //     0xc6ece4: ret             
  }
}

// class id: 4571, size: 0xc, field offset: 0x8
//   const constructor, 
class DBusVariant extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad186c, size: 0xc0
    // 0xad186c: EnterFrame
    //     0xad186c: stp             fp, lr, [SP, #-0x10]!
    //     0xad1870: mov             fp, SP
    // 0xad1874: AllocStack(0x8)
    //     0xad1874: sub             SP, SP, #8
    // 0xad1878: CheckStackOverflow
    //     0xad1878: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad187c: cmp             SP, x16
    //     0xad1880: b.ls            #0xad1924
    // 0xad1884: r1 = Null
    //     0xad1884: mov             x1, NULL
    // 0xad1888: r2 = 8
    //     0xad1888: mov             x2, #8
    // 0xad188c: r0 = AllocateArray()
    //     0xad188c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1890: mov             x1, x0
    // 0xad1894: stur            x1, [fp, #-8]
    // 0xad1898: r17 = DBusVariant
    //     0xad1898: ldr             x17, [PP, #0x7fc0]  ; [pp+0x7fc0] Type: DBusVariant
    // 0xad189c: StoreField: r1->field_f = r17
    //     0xad189c: stur            w17, [x1, #0xf]
    // 0xad18a0: r17 = "("
    //     0xad18a0: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad18a4: StoreField: r1->field_13 = r17
    //     0xad18a4: stur            w17, [x1, #0x13]
    // 0xad18a8: ldr             x0, [fp, #0x10]
    // 0xad18ac: LoadField: r2 = r0->field_7
    //     0xad18ac: ldur            w2, [x0, #7]
    // 0xad18b0: DecompressPointer r2
    //     0xad18b0: add             x2, x2, HEAP, lsl #32
    // 0xad18b4: r0 = LoadClassIdInstr(r2)
    //     0xad18b4: ldur            x0, [x2, #-1]
    //     0xad18b8: ubfx            x0, x0, #0xc, #0x14
    // 0xad18bc: SaveReg r2
    //     0xad18bc: str             x2, [SP, #-8]!
    // 0xad18c0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad18c0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad18c4: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad18c4: mov             x17, #0x3f73
    //     0xad18c8: add             lr, x0, x17
    //     0xad18cc: ldr             lr, [x21, lr, lsl #3]
    //     0xad18d0: blr             lr
    // 0xad18d4: add             SP, SP, #8
    // 0xad18d8: ldur            x1, [fp, #-8]
    // 0xad18dc: ArrayStore: r1[2] = r0  ; List_4
    //     0xad18dc: add             x25, x1, #0x17
    //     0xad18e0: str             w0, [x25]
    //     0xad18e4: tbz             w0, #0, #0xad1900
    //     0xad18e8: ldurb           w16, [x1, #-1]
    //     0xad18ec: ldurb           w17, [x0, #-1]
    //     0xad18f0: and             x16, x17, x16, lsr #2
    //     0xad18f4: tst             x16, HEAP, lsr #32
    //     0xad18f8: b.eq            #0xad1900
    //     0xad18fc: bl              #0xd67e5c
    // 0xad1900: ldur            x0, [fp, #-8]
    // 0xad1904: r17 = ")"
    //     0xad1904: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad1908: StoreField: r0->field_1b = r17
    //     0xad1908: stur            w17, [x0, #0x1b]
    // 0xad190c: SaveReg r0
    //     0xad190c: str             x0, [SP, #-8]!
    // 0xad1910: r0 = _interpolate()
    //     0xad1910: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1914: add             SP, SP, #8
    // 0xad1918: LeaveFrame
    //     0xad1918: mov             SP, fp
    //     0xad191c: ldp             fp, lr, [SP], #0x10
    // 0xad1920: ret
    //     0xad1920: ret             
    // 0xad1924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1924: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1928: b               #0xad1884
  }
  _ toNative(/* No info */) {
    // ** addr: 0xc431ac, size: 0x50
    // 0xc431ac: EnterFrame
    //     0xc431ac: stp             fp, lr, [SP, #-0x10]!
    //     0xc431b0: mov             fp, SP
    // 0xc431b4: CheckStackOverflow
    //     0xc431b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc431b8: cmp             SP, x16
    //     0xc431bc: b.ls            #0xc431f4
    // 0xc431c0: ldr             x0, [fp, #0x10]
    // 0xc431c4: LoadField: r1 = r0->field_7
    //     0xc431c4: ldur            w1, [x0, #7]
    // 0xc431c8: DecompressPointer r1
    //     0xc431c8: add             x1, x1, HEAP, lsl #32
    // 0xc431cc: r0 = LoadClassIdInstr(r1)
    //     0xc431cc: ldur            x0, [x1, #-1]
    //     0xc431d0: ubfx            x0, x0, #0xc, #0x14
    // 0xc431d4: SaveReg r1
    //     0xc431d4: str             x1, [SP, #-8]!
    // 0xc431d8: r0 = GDT[cid_x0 + 0x872]()
    //     0xc431d8: add             lr, x0, #0x872
    //     0xc431dc: ldr             lr, [x21, lr, lsl #3]
    //     0xc431e0: blr             lr
    // 0xc431e4: add             SP, SP, #8
    // 0xc431e8: LeaveFrame
    //     0xc431e8: mov             SP, fp
    //     0xc431ec: ldp             fp, lr, [SP], #0x10
    // 0xc431f0: ret
    //     0xc431f0: ret             
    // 0xc431f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc431f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc431f8: b               #0xc431c0
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc63760, size: 0x48
    // 0xc63760: EnterFrame
    //     0xc63760: stp             fp, lr, [SP, #-0x10]!
    //     0xc63764: mov             fp, SP
    // 0xc63768: AllocStack(0x8)
    //     0xc63768: sub             SP, SP, #8
    // 0xc6376c: CheckStackOverflow
    //     0xc6376c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63770: cmp             SP, x16
    //     0xc63774: b.ls            #0xc637a0
    // 0xc63778: r0 = DBusSignature()
    //     0xc63778: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc6377c: stur            x0, [fp, #-8]
    // 0xc63780: r16 = "v"
    //     0xc63780: ldr             x16, [PP, #0x7910]  ; [pp+0x7910] "v"
    // 0xc63784: stp             x16, x0, [SP, #-0x10]!
    // 0xc63788: r0 = DBusSignature()
    //     0xc63788: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc6378c: add             SP, SP, #0x10
    // 0xc63790: ldur            x0, [fp, #-8]
    // 0xc63794: LeaveFrame
    //     0xc63794: mov             SP, fp
    //     0xc63798: ldp             fp, lr, [SP], #0x10
    // 0xc6379c: ret
    //     0xc6379c: ret             
    // 0xc637a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc637a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc637a4: b               #0xc63778
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6ebe0, size: 0xa0
    // 0xc6ebe0: EnterFrame
    //     0xc6ebe0: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ebe4: mov             fp, SP
    // 0xc6ebe8: CheckStackOverflow
    //     0xc6ebe8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ebec: cmp             SP, x16
    //     0xc6ebf0: b.ls            #0xc6ec78
    // 0xc6ebf4: ldr             x0, [fp, #0x10]
    // 0xc6ebf8: cmp             w0, NULL
    // 0xc6ebfc: b.ne            #0xc6ec10
    // 0xc6ec00: r0 = false
    //     0xc6ec00: add             x0, NULL, #0x30  ; false
    // 0xc6ec04: LeaveFrame
    //     0xc6ec04: mov             SP, fp
    //     0xc6ec08: ldp             fp, lr, [SP], #0x10
    // 0xc6ec0c: ret
    //     0xc6ec0c: ret             
    // 0xc6ec10: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6ec10: mov             x1, #0x76
    //     0xc6ec14: tbz             w0, #0, #0xc6ec24
    //     0xc6ec18: ldur            x1, [x0, #-1]
    //     0xc6ec1c: ubfx            x1, x1, #0xc, #0x14
    //     0xc6ec20: lsl             x1, x1, #1
    // 0xc6ec24: r17 = 9142
    //     0xc6ec24: mov             x17, #0x23b6
    // 0xc6ec28: cmp             w1, w17
    // 0xc6ec2c: b.ne            #0xc6ec68
    // 0xc6ec30: ldr             x1, [fp, #0x18]
    // 0xc6ec34: LoadField: r2 = r0->field_7
    //     0xc6ec34: ldur            w2, [x0, #7]
    // 0xc6ec38: DecompressPointer r2
    //     0xc6ec38: add             x2, x2, HEAP, lsl #32
    // 0xc6ec3c: LoadField: r0 = r1->field_7
    //     0xc6ec3c: ldur            w0, [x1, #7]
    // 0xc6ec40: DecompressPointer r0
    //     0xc6ec40: add             x0, x0, HEAP, lsl #32
    // 0xc6ec44: r1 = LoadClassIdInstr(r2)
    //     0xc6ec44: ldur            x1, [x2, #-1]
    //     0xc6ec48: ubfx            x1, x1, #0xc, #0x14
    // 0xc6ec4c: stp             x0, x2, [SP, #-0x10]!
    // 0xc6ec50: mov             x0, x1
    // 0xc6ec54: mov             lr, x0
    // 0xc6ec58: ldr             lr, [x21, lr, lsl #3]
    // 0xc6ec5c: blr             lr
    // 0xc6ec60: add             SP, SP, #0x10
    // 0xc6ec64: b               #0xc6ec6c
    // 0xc6ec68: r0 = false
    //     0xc6ec68: add             x0, NULL, #0x30  ; false
    // 0xc6ec6c: LeaveFrame
    //     0xc6ec6c: mov             SP, fp
    //     0xc6ec70: ldp             fp, lr, [SP], #0x10
    // 0xc6ec74: ret
    //     0xc6ec74: ret             
    // 0xc6ec78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ec78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ec7c: b               #0xc6ebf4
  }
}

// class id: 4572, size: 0xc, field offset: 0x8
//   const constructor, 
class DBusSignature extends DBusValue {

  List<DBusSignature> split(DBusSignature) {
    // ** addr: 0x9fd454, size: 0x1e8
    // 0x9fd454: EnterFrame
    //     0x9fd454: stp             fp, lr, [SP, #-0x10]!
    //     0x9fd458: mov             fp, SP
    // 0x9fd45c: AllocStack(0x38)
    //     0x9fd45c: sub             SP, SP, #0x38
    // 0x9fd460: CheckStackOverflow
    //     0x9fd460: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd464: cmp             SP, x16
    //     0x9fd468: b.ls            #0x9fd610
    // 0x9fd46c: r16 = <DBusSignature>
    //     0x9fd46c: ldr             x16, [PP, #0x4c0]  ; [pp+0x4c0] TypeArguments: <DBusSignature>
    // 0x9fd470: stp             xzr, x16, [SP, #-0x10]!
    // 0x9fd474: r0 = _GrowableList()
    //     0x9fd474: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x9fd478: add             SP, SP, #0x10
    // 0x9fd47c: mov             x1, x0
    // 0x9fd480: ldr             x0, [fp, #0x10]
    // 0x9fd484: stur            x1, [fp, #-0x20]
    // 0x9fd488: LoadField: r2 = r0->field_7
    //     0x9fd488: ldur            w2, [x0, #7]
    // 0x9fd48c: DecompressPointer r2
    //     0x9fd48c: add             x2, x2, HEAP, lsl #32
    // 0x9fd490: stur            x2, [fp, #-0x18]
    // 0x9fd494: LoadField: r3 = r2->field_7
    //     0x9fd494: ldur            w3, [x2, #7]
    // 0x9fd498: DecompressPointer r3
    //     0x9fd498: add             x3, x3, HEAP, lsl #32
    // 0x9fd49c: r4 = LoadInt32Instr(r3)
    //     0x9fd49c: sbfx            x4, x3, #1, #0x1f
    // 0x9fd4a0: stur            x4, [fp, #-0x10]
    // 0x9fd4a4: r3 = 0
    //     0x9fd4a4: mov             x3, #0
    // 0x9fd4a8: stur            x3, [fp, #-8]
    // 0x9fd4ac: CheckStackOverflow
    //     0x9fd4ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd4b0: cmp             SP, x16
    //     0x9fd4b4: b.ls            #0x9fd618
    // 0x9fd4b8: cmp             x3, x4
    // 0x9fd4bc: b.ge            #0x9fd5fc
    // 0x9fd4c0: stp             x2, x0, [SP, #-0x10]!
    // 0x9fd4c4: SaveReg r3
    //     0x9fd4c4: str             x3, [SP, #-8]!
    // 0x9fd4c8: r0 = _findChildSignatureEnd()
    //     0x9fd4c8: bl              #0x9fd624  ; [package:dbus/src/dbus_value.dart] DBusSignature::_findChildSignatureEnd
    // 0x9fd4cc: add             SP, SP, #0x18
    // 0x9fd4d0: add             x3, x0, #1
    // 0x9fd4d4: ldur            x2, [fp, #-8]
    // 0x9fd4d8: stur            x3, [fp, #-0x30]
    // 0x9fd4dc: r0 = BoxInt64Instr(r2)
    //     0x9fd4dc: sbfiz           x0, x2, #1, #0x1f
    //     0x9fd4e0: cmp             x2, x0, asr #1
    //     0x9fd4e4: b.eq            #0x9fd4f0
    //     0x9fd4e8: bl              #0xd69bb8
    //     0x9fd4ec: stur            x2, [x0, #7]
    // 0x9fd4f0: mov             x2, x0
    // 0x9fd4f4: stur            x2, [fp, #-0x28]
    // 0x9fd4f8: r0 = BoxInt64Instr(r3)
    //     0x9fd4f8: sbfiz           x0, x3, #1, #0x1f
    //     0x9fd4fc: cmp             x3, x0, asr #1
    //     0x9fd500: b.eq            #0x9fd50c
    //     0x9fd504: bl              #0xd69bb8
    //     0x9fd508: stur            x3, [x0, #7]
    // 0x9fd50c: stp             x0, x2, [SP, #-0x10]!
    // 0x9fd510: ldur            x0, [fp, #-0x10]
    // 0x9fd514: SaveReg r0
    //     0x9fd514: str             x0, [SP, #-8]!
    // 0x9fd518: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9fd518: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9fd51c: r0 = checkValidRange()
    //     0x9fd51c: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0x9fd520: add             SP, SP, #0x18
    // 0x9fd524: ldur            x16, [fp, #-0x18]
    // 0x9fd528: ldur            lr, [fp, #-0x28]
    // 0x9fd52c: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd530: SaveReg r0
    //     0x9fd530: str             x0, [SP, #-8]!
    // 0x9fd534: r0 = _substringUnchecked()
    //     0x9fd534: bl              #0x4d0ab0  ; [dart:core] _StringBase::_substringUnchecked
    // 0x9fd538: add             SP, SP, #0x18
    // 0x9fd53c: stur            x0, [fp, #-0x28]
    // 0x9fd540: r0 = DBusSignature()
    //     0x9fd540: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0x9fd544: stur            x0, [fp, #-0x38]
    // 0x9fd548: ldur            x16, [fp, #-0x28]
    // 0x9fd54c: stp             x16, x0, [SP, #-0x10]!
    // 0x9fd550: r0 = DBusSignature()
    //     0x9fd550: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0x9fd554: add             SP, SP, #0x10
    // 0x9fd558: ldur            x0, [fp, #-0x20]
    // 0x9fd55c: LoadField: r1 = r0->field_b
    //     0x9fd55c: ldur            w1, [x0, #0xb]
    // 0x9fd560: DecompressPointer r1
    //     0x9fd560: add             x1, x1, HEAP, lsl #32
    // 0x9fd564: stur            x1, [fp, #-0x28]
    // 0x9fd568: LoadField: r2 = r0->field_f
    //     0x9fd568: ldur            w2, [x0, #0xf]
    // 0x9fd56c: DecompressPointer r2
    //     0x9fd56c: add             x2, x2, HEAP, lsl #32
    // 0x9fd570: LoadField: r3 = r2->field_b
    //     0x9fd570: ldur            w3, [x2, #0xb]
    // 0x9fd574: DecompressPointer r3
    //     0x9fd574: add             x3, x3, HEAP, lsl #32
    // 0x9fd578: cmp             w1, w3
    // 0x9fd57c: b.ne            #0x9fd58c
    // 0x9fd580: SaveReg r0
    //     0x9fd580: str             x0, [SP, #-8]!
    // 0x9fd584: r0 = _growToNextCapacity()
    //     0x9fd584: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9fd588: add             SP, SP, #8
    // 0x9fd58c: ldur            x2, [fp, #-0x20]
    // 0x9fd590: ldur            x3, [fp, #-0x28]
    // 0x9fd594: r4 = LoadInt32Instr(r3)
    //     0x9fd594: sbfx            x4, x3, #1, #0x1f
    // 0x9fd598: add             x0, x4, #1
    // 0x9fd59c: lsl             x3, x0, #1
    // 0x9fd5a0: StoreField: r2->field_b = r3
    //     0x9fd5a0: stur            w3, [x2, #0xb]
    // 0x9fd5a4: mov             x1, x4
    // 0x9fd5a8: cmp             x1, x0
    // 0x9fd5ac: b.hs            #0x9fd620
    // 0x9fd5b0: LoadField: r1 = r2->field_f
    //     0x9fd5b0: ldur            w1, [x2, #0xf]
    // 0x9fd5b4: DecompressPointer r1
    //     0x9fd5b4: add             x1, x1, HEAP, lsl #32
    // 0x9fd5b8: ldur            x0, [fp, #-0x38]
    // 0x9fd5bc: ArrayStore: r1[r4] = r0  ; List_4
    //     0x9fd5bc: add             x25, x1, x4, lsl #2
    //     0x9fd5c0: add             x25, x25, #0xf
    //     0x9fd5c4: str             w0, [x25]
    //     0x9fd5c8: tbz             w0, #0, #0x9fd5e4
    //     0x9fd5cc: ldurb           w16, [x1, #-1]
    //     0x9fd5d0: ldurb           w17, [x0, #-1]
    //     0x9fd5d4: and             x16, x17, x16, lsr #2
    //     0x9fd5d8: tst             x16, HEAP, lsr #32
    //     0x9fd5dc: b.eq            #0x9fd5e4
    //     0x9fd5e0: bl              #0xd67e5c
    // 0x9fd5e4: ldur            x3, [fp, #-0x30]
    // 0x9fd5e8: ldr             x0, [fp, #0x10]
    // 0x9fd5ec: mov             x1, x2
    // 0x9fd5f0: ldur            x2, [fp, #-0x18]
    // 0x9fd5f4: ldur            x4, [fp, #-0x10]
    // 0x9fd5f8: b               #0x9fd4a8
    // 0x9fd5fc: mov             x2, x1
    // 0x9fd600: mov             x0, x2
    // 0x9fd604: LeaveFrame
    //     0x9fd604: mov             SP, fp
    //     0x9fd608: ldp             fp, lr, [SP], #0x10
    // 0x9fd60c: ret
    //     0x9fd60c: ret             
    // 0x9fd610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fd610: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fd614: b               #0x9fd46c
    // 0x9fd618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fd618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fd61c: b               #0x9fd4b8
    // 0x9fd620: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9fd620: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ DBusSignature(/* No info */) {
    // ** addr: 0x9fd234, size: 0xe8
    // 0x9fd234: EnterFrame
    //     0x9fd234: stp             fp, lr, [SP, #-0x10]!
    //     0x9fd238: mov             fp, SP
    // 0x9fd23c: AllocStack(0x8)
    //     0x9fd23c: sub             SP, SP, #8
    // 0x9fd240: CheckStackOverflow
    //     0x9fd240: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd244: cmp             SP, x16
    //     0x9fd248: b.ls            #0x9fd30c
    // 0x9fd24c: ldr             x0, [fp, #0x10]
    // 0x9fd250: ldr             x1, [fp, #0x18]
    // 0x9fd254: StoreField: r1->field_7 = r0
    //     0x9fd254: stur            w0, [x1, #7]
    //     0x9fd258: ldurb           w16, [x1, #-1]
    //     0x9fd25c: ldurb           w17, [x0, #-1]
    //     0x9fd260: and             x16, x17, x16, lsr #2
    //     0x9fd264: tst             x16, HEAP, lsr #32
    //     0x9fd268: b.eq            #0x9fd270
    //     0x9fd26c: bl              #0xd6826c
    // 0x9fd270: ldr             x0, [fp, #0x10]
    // 0x9fd274: LoadField: r2 = r0->field_7
    //     0x9fd274: ldur            w2, [x0, #7]
    // 0x9fd278: DecompressPointer r2
    //     0x9fd278: add             x2, x2, HEAP, lsl #32
    // 0x9fd27c: r3 = LoadInt32Instr(r2)
    //     0x9fd27c: sbfx            x3, x2, #1, #0x1f
    // 0x9fd280: stur            x3, [fp, #-8]
    // 0x9fd284: cmp             x3, #0xff
    // 0x9fd288: b.gt            #0x9fd2d8
    // 0x9fd28c: r2 = 0
    //     0x9fd28c: mov             x2, #0
    // 0x9fd290: CheckStackOverflow
    //     0x9fd290: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd294: cmp             SP, x16
    //     0x9fd298: b.ls            #0x9fd314
    // 0x9fd29c: cmp             x2, x3
    // 0x9fd2a0: b.ge            #0x9fd2c8
    // 0x9fd2a4: stp             x0, x1, [SP, #-0x10]!
    // 0x9fd2a8: SaveReg r2
    //     0x9fd2a8: str             x2, [SP, #-8]!
    // 0x9fd2ac: r0 = _validate()
    //     0x9fd2ac: bl              #0x9fd93c  ; [package:dbus/src/dbus_value.dart] DBusSignature::_validate
    // 0x9fd2b0: add             SP, SP, #0x18
    // 0x9fd2b4: add             x2, x0, #1
    // 0x9fd2b8: ldr             x1, [fp, #0x18]
    // 0x9fd2bc: ldr             x0, [fp, #0x10]
    // 0x9fd2c0: ldur            x3, [fp, #-8]
    // 0x9fd2c4: b               #0x9fd290
    // 0x9fd2c8: r0 = Null
    //     0x9fd2c8: mov             x0, NULL
    // 0x9fd2cc: LeaveFrame
    //     0x9fd2cc: mov             SP, fp
    //     0x9fd2d0: ldp             fp, lr, [SP], #0x10
    // 0x9fd2d4: ret
    //     0x9fd2d4: ret             
    // 0x9fd2d8: r0 = ArgumentError()
    //     0x9fd2d8: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x9fd2dc: mov             x1, x0
    // 0x9fd2e0: r0 = "value"
    //     0x9fd2e0: ldr             x0, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fd2e4: StoreField: r1->field_13 = r0
    //     0x9fd2e4: stur            w0, [x1, #0x13]
    // 0x9fd2e8: r0 = "Signature maximum length is 255 characters"
    //     0x9fd2e8: ldr             x0, [PP, #0x410]  ; [pp+0x410] "Signature maximum length is 255 characters"
    // 0x9fd2ec: StoreField: r1->field_17 = r0
    //     0x9fd2ec: stur            w0, [x1, #0x17]
    // 0x9fd2f0: ldr             x0, [fp, #0x10]
    // 0x9fd2f4: StoreField: r1->field_f = r0
    //     0x9fd2f4: stur            w0, [x1, #0xf]
    // 0x9fd2f8: r0 = true
    //     0x9fd2f8: add             x0, NULL, #0x20  ; true
    // 0x9fd2fc: StoreField: r1->field_b = r0
    //     0x9fd2fc: stur            w0, [x1, #0xb]
    // 0x9fd300: mov             x0, x1
    // 0x9fd304: r0 = Throw()
    //     0x9fd304: bl              #0xd67e38  ; ThrowStub
    // 0x9fd308: brk             #0
    // 0x9fd30c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fd30c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fd310: b               #0x9fd24c
    // 0x9fd314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fd314: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fd318: b               #0x9fd29c
  }
  DBusSignature +(DBusSignature, DBusSignature) {
    // ** addr: 0x9fd334, size: 0x8c
    // 0x9fd334: EnterFrame
    //     0x9fd334: stp             fp, lr, [SP, #-0x10]!
    //     0x9fd338: mov             fp, SP
    // 0x9fd33c: CheckStackOverflow
    //     0x9fd33c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd340: cmp             SP, x16
    //     0x9fd344: b.ls            #0x9fd3a0
    // 0x9fd348: ldr             x0, [fp, #0x10]
    // 0x9fd34c: r2 = Null
    //     0x9fd34c: mov             x2, NULL
    // 0x9fd350: r1 = Null
    //     0x9fd350: mov             x1, NULL
    // 0x9fd354: r4 = 59
    //     0x9fd354: mov             x4, #0x3b
    // 0x9fd358: branchIfSmi(r0, 0x9fd364)
    //     0x9fd358: tbz             w0, #0, #0x9fd364
    // 0x9fd35c: r4 = LoadClassIdInstr(r0)
    //     0x9fd35c: ldur            x4, [x0, #-1]
    //     0x9fd360: ubfx            x4, x4, #0xc, #0x14
    // 0x9fd364: r17 = 4572
    //     0x9fd364: mov             x17, #0x11dc
    // 0x9fd368: cmp             x4, x17
    // 0x9fd36c: b.eq            #0x9fd380
    // 0x9fd370: r8 = DBusSignature
    //     0x9fd370: ldr             x8, [PP, #0x7698]  ; [pp+0x7698] Type: DBusSignature
    // 0x9fd374: r3 = Null
    //     0x9fd374: add             x3, PP, #0x29, lsl #12  ; [pp+0x292b0] Null
    //     0x9fd378: ldr             x3, [x3, #0x2b0]
    // 0x9fd37c: r0 = DBusSignature()
    //     0x9fd37c: bl              #0x9fd418  ; IsType_DBusSignature_Stub
    // 0x9fd380: ldr             x16, [fp, #0x18]
    // 0x9fd384: ldr             lr, [fp, #0x10]
    // 0x9fd388: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd38c: r0 = +()
    //     0x9fd38c: bl              #0x9fd3a8  ; [package:dbus/src/dbus_value.dart] DBusSignature::+
    // 0x9fd390: add             SP, SP, #0x10
    // 0x9fd394: LeaveFrame
    //     0x9fd394: mov             SP, fp
    //     0x9fd398: ldp             fp, lr, [SP], #0x10
    // 0x9fd39c: ret
    //     0x9fd39c: ret             
    // 0x9fd3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fd3a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fd3a4: b               #0x9fd348
  }
  DBusSignature +(DBusSignature, DBusSignature) {
    // ** addr: 0x9fd3a8, size: 0x70
    // 0x9fd3a8: EnterFrame
    //     0x9fd3a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9fd3ac: mov             fp, SP
    // 0x9fd3b0: AllocStack(0x10)
    //     0x9fd3b0: sub             SP, SP, #0x10
    // 0x9fd3b4: CheckStackOverflow
    //     0x9fd3b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd3b8: cmp             SP, x16
    //     0x9fd3bc: b.ls            #0x9fd410
    // 0x9fd3c0: ldr             x0, [fp, #0x18]
    // 0x9fd3c4: LoadField: r1 = r0->field_7
    //     0x9fd3c4: ldur            w1, [x0, #7]
    // 0x9fd3c8: DecompressPointer r1
    //     0x9fd3c8: add             x1, x1, HEAP, lsl #32
    // 0x9fd3cc: ldr             x0, [fp, #0x10]
    // 0x9fd3d0: LoadField: r2 = r0->field_7
    //     0x9fd3d0: ldur            w2, [x0, #7]
    // 0x9fd3d4: DecompressPointer r2
    //     0x9fd3d4: add             x2, x2, HEAP, lsl #32
    // 0x9fd3d8: stp             x2, x1, [SP, #-0x10]!
    // 0x9fd3dc: r0 = +()
    //     0x9fd3dc: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x9fd3e0: add             SP, SP, #0x10
    // 0x9fd3e4: stur            x0, [fp, #-8]
    // 0x9fd3e8: r0 = DBusSignature()
    //     0x9fd3e8: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0x9fd3ec: stur            x0, [fp, #-0x10]
    // 0x9fd3f0: ldur            x16, [fp, #-8]
    // 0x9fd3f4: stp             x16, x0, [SP, #-0x10]!
    // 0x9fd3f8: r0 = DBusSignature()
    //     0x9fd3f8: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0x9fd3fc: add             SP, SP, #0x10
    // 0x9fd400: ldur            x0, [fp, #-0x10]
    // 0x9fd404: LeaveFrame
    //     0x9fd404: mov             SP, fp
    //     0x9fd408: ldp             fp, lr, [SP], #0x10
    // 0x9fd40c: ret
    //     0x9fd40c: ret             
    // 0x9fd410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fd410: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fd414: b               #0x9fd3c0
  }
  _ _findChildSignatureEnd(/* No info */) {
    // ** addr: 0x9fd624, size: 0x1c8
    // 0x9fd624: EnterFrame
    //     0x9fd624: stp             fp, lr, [SP, #-0x10]!
    //     0x9fd628: mov             fp, SP
    // 0x9fd62c: AllocStack(0x8)
    //     0x9fd62c: sub             SP, SP, #8
    // 0x9fd630: CheckStackOverflow
    //     0x9fd630: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd634: cmp             SP, x16
    //     0x9fd638: b.ls            #0x9fd7e4
    // 0x9fd63c: ldr             x2, [fp, #0x18]
    // 0x9fd640: LoadField: r0 = r2->field_7
    //     0x9fd640: ldur            w0, [x2, #7]
    // 0x9fd644: DecompressPointer r0
    //     0x9fd644: add             x0, x0, HEAP, lsl #32
    // 0x9fd648: r1 = LoadInt32Instr(r0)
    //     0x9fd648: sbfx            x1, x0, #1, #0x1f
    // 0x9fd64c: ldr             x3, [fp, #0x10]
    // 0x9fd650: cmp             x3, x1
    // 0x9fd654: b.lt            #0x9fd668
    // 0x9fd658: r0 = -1
    //     0x9fd658: mov             x0, #-1
    // 0x9fd65c: LeaveFrame
    //     0x9fd65c: mov             SP, fp
    //     0x9fd660: ldp             fp, lr, [SP], #0x10
    // 0x9fd664: ret
    //     0x9fd664: ret             
    // 0x9fd668: r0 = BoxInt64Instr(r3)
    //     0x9fd668: sbfiz           x0, x3, #1, #0x1f
    //     0x9fd66c: cmp             x3, x0, asr #1
    //     0x9fd670: b.eq            #0x9fd67c
    //     0x9fd674: bl              #0xd69bb8
    //     0x9fd678: stur            x3, [x0, #7]
    // 0x9fd67c: stur            x0, [fp, #-8]
    // 0x9fd680: r16 = "("
    //     0x9fd680: ldr             x16, [PP, #0x418]  ; [pp+0x418] "("
    // 0x9fd684: stp             x16, x2, [SP, #-0x10]!
    // 0x9fd688: SaveReg r0
    //     0x9fd688: str             x0, [SP, #-8]!
    // 0x9fd68c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9fd68c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9fd690: r0 = startsWith()
    //     0x9fd690: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x9fd694: add             SP, SP, #0x18
    // 0x9fd698: tbnz            w0, #4, #0x9fd6d0
    // 0x9fd69c: ldr             x0, [fp, #0x10]
    // 0x9fd6a0: ldr             x16, [fp, #0x20]
    // 0x9fd6a4: ldr             lr, [fp, #0x18]
    // 0x9fd6a8: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd6ac: r16 = "("
    //     0x9fd6ac: ldr             x16, [PP, #0x418]  ; [pp+0x418] "("
    // 0x9fd6b0: stp             x16, x0, [SP, #-0x10]!
    // 0x9fd6b4: r16 = ")"
    //     0x9fd6b4: ldr             x16, [PP, #0x420]  ; [pp+0x420] ")"
    // 0x9fd6b8: SaveReg r16
    //     0x9fd6b8: str             x16, [SP, #-8]!
    // 0x9fd6bc: r0 = _findClosing()
    //     0x9fd6bc: bl              #0x9fd7ec  ; [package:dbus/src/dbus_value.dart] DBusSignature::_findClosing
    // 0x9fd6c0: add             SP, SP, #0x28
    // 0x9fd6c4: LeaveFrame
    //     0x9fd6c4: mov             SP, fp
    //     0x9fd6c8: ldp             fp, lr, [SP], #0x10
    // 0x9fd6cc: ret
    //     0x9fd6cc: ret             
    // 0x9fd6d0: ldr             x0, [fp, #0x10]
    // 0x9fd6d4: ldr             x16, [fp, #0x18]
    // 0x9fd6d8: r30 = "a{"
    //     0x9fd6d8: ldr             lr, [PP, #0x428]  ; [pp+0x428] "a{"
    // 0x9fd6dc: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd6e0: ldur            x16, [fp, #-8]
    // 0x9fd6e4: SaveReg r16
    //     0x9fd6e4: str             x16, [SP, #-8]!
    // 0x9fd6e8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9fd6e8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9fd6ec: r0 = startsWith()
    //     0x9fd6ec: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x9fd6f0: add             SP, SP, #0x18
    // 0x9fd6f4: tbnz            w0, #4, #0x9fd72c
    // 0x9fd6f8: ldr             x0, [fp, #0x10]
    // 0x9fd6fc: ldr             x16, [fp, #0x20]
    // 0x9fd700: ldr             lr, [fp, #0x18]
    // 0x9fd704: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd708: r16 = "{"
    //     0x9fd708: ldr             x16, [PP, #0x430]  ; [pp+0x430] "{"
    // 0x9fd70c: stp             x16, x0, [SP, #-0x10]!
    // 0x9fd710: r16 = "}"
    //     0x9fd710: ldr             x16, [PP, #0x438]  ; [pp+0x438] "}"
    // 0x9fd714: SaveReg r16
    //     0x9fd714: str             x16, [SP, #-8]!
    // 0x9fd718: r0 = _findClosing()
    //     0x9fd718: bl              #0x9fd7ec  ; [package:dbus/src/dbus_value.dart] DBusSignature::_findClosing
    // 0x9fd71c: add             SP, SP, #0x28
    // 0x9fd720: LeaveFrame
    //     0x9fd720: mov             SP, fp
    //     0x9fd724: ldp             fp, lr, [SP], #0x10
    // 0x9fd728: ret
    //     0x9fd728: ret             
    // 0x9fd72c: ldr             x0, [fp, #0x10]
    // 0x9fd730: ldr             x16, [fp, #0x18]
    // 0x9fd734: r30 = "a"
    //     0x9fd734: ldr             lr, [PP, #0x440]  ; [pp+0x440] "a"
    // 0x9fd738: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd73c: ldur            x16, [fp, #-8]
    // 0x9fd740: SaveReg r16
    //     0x9fd740: str             x16, [SP, #-8]!
    // 0x9fd744: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9fd744: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9fd748: r0 = startsWith()
    //     0x9fd748: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x9fd74c: add             SP, SP, #0x18
    // 0x9fd750: tbnz            w0, #4, #0x9fd780
    // 0x9fd754: ldr             x0, [fp, #0x10]
    // 0x9fd758: add             x1, x0, #1
    // 0x9fd75c: ldr             x16, [fp, #0x20]
    // 0x9fd760: ldr             lr, [fp, #0x18]
    // 0x9fd764: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd768: SaveReg r1
    //     0x9fd768: str             x1, [SP, #-8]!
    // 0x9fd76c: r0 = _findChildSignatureEnd()
    //     0x9fd76c: bl              #0x9fd624  ; [package:dbus/src/dbus_value.dart] DBusSignature::_findChildSignatureEnd
    // 0x9fd770: add             SP, SP, #0x18
    // 0x9fd774: LeaveFrame
    //     0x9fd774: mov             SP, fp
    //     0x9fd778: ldp             fp, lr, [SP], #0x10
    // 0x9fd77c: ret
    //     0x9fd77c: ret             
    // 0x9fd780: ldr             x0, [fp, #0x10]
    // 0x9fd784: ldr             x16, [fp, #0x18]
    // 0x9fd788: r30 = "m"
    //     0x9fd788: ldr             lr, [PP, #0x448]  ; [pp+0x448] "m"
    // 0x9fd78c: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd790: ldur            x16, [fp, #-8]
    // 0x9fd794: SaveReg r16
    //     0x9fd794: str             x16, [SP, #-8]!
    // 0x9fd798: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9fd798: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9fd79c: r0 = startsWith()
    //     0x9fd79c: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x9fd7a0: add             SP, SP, #0x18
    // 0x9fd7a4: tbnz            w0, #4, #0x9fd7d4
    // 0x9fd7a8: ldr             x0, [fp, #0x10]
    // 0x9fd7ac: add             x1, x0, #1
    // 0x9fd7b0: ldr             x16, [fp, #0x20]
    // 0x9fd7b4: ldr             lr, [fp, #0x18]
    // 0x9fd7b8: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd7bc: SaveReg r1
    //     0x9fd7bc: str             x1, [SP, #-8]!
    // 0x9fd7c0: r0 = _findChildSignatureEnd()
    //     0x9fd7c0: bl              #0x9fd624  ; [package:dbus/src/dbus_value.dart] DBusSignature::_findChildSignatureEnd
    // 0x9fd7c4: add             SP, SP, #0x18
    // 0x9fd7c8: LeaveFrame
    //     0x9fd7c8: mov             SP, fp
    //     0x9fd7cc: ldp             fp, lr, [SP], #0x10
    // 0x9fd7d0: ret
    //     0x9fd7d0: ret             
    // 0x9fd7d4: ldr             x0, [fp, #0x10]
    // 0x9fd7d8: LeaveFrame
    //     0x9fd7d8: mov             SP, fp
    //     0x9fd7dc: ldp             fp, lr, [SP], #0x10
    // 0x9fd7e0: ret
    //     0x9fd7e0: ret             
    // 0x9fd7e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fd7e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fd7e8: b               #0x9fd63c
  }
  _ _findClosing(/* No info */) {
    // ** addr: 0x9fd7ec, size: 0x150
    // 0x9fd7ec: EnterFrame
    //     0x9fd7ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9fd7f0: mov             fp, SP
    // 0x9fd7f4: AllocStack(0x20)
    //     0x9fd7f4: sub             SP, SP, #0x20
    // 0x9fd7f8: CheckStackOverflow
    //     0x9fd7f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd7fc: cmp             SP, x16
    //     0x9fd800: b.ls            #0x9fd92c
    // 0x9fd804: ldr             x2, [fp, #0x28]
    // 0x9fd808: LoadField: r0 = r2->field_7
    //     0x9fd808: ldur            w0, [x2, #7]
    // 0x9fd80c: DecompressPointer r0
    //     0x9fd80c: add             x0, x0, HEAP, lsl #32
    // 0x9fd810: r3 = LoadInt32Instr(r0)
    //     0x9fd810: sbfx            x3, x0, #1, #0x1f
    // 0x9fd814: ldr             x0, [fp, #0x20]
    // 0x9fd818: stur            x3, [fp, #-0x20]
    // 0x9fd81c: mov             x4, x0
    // 0x9fd820: r5 = 0
    //     0x9fd820: mov             x5, #0
    // 0x9fd824: stur            x5, [fp, #-0x10]
    // 0x9fd828: stur            x4, [fp, #-0x18]
    // 0x9fd82c: CheckStackOverflow
    //     0x9fd82c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd830: cmp             SP, x16
    //     0x9fd834: b.ls            #0x9fd934
    // 0x9fd838: cmp             x4, x3
    // 0x9fd83c: b.ge            #0x9fd91c
    // 0x9fd840: r0 = BoxInt64Instr(r4)
    //     0x9fd840: sbfiz           x0, x4, #1, #0x1f
    //     0x9fd844: cmp             x4, x0, asr #1
    //     0x9fd848: b.eq            #0x9fd854
    //     0x9fd84c: bl              #0xd69bb8
    //     0x9fd850: stur            x4, [x0, #7]
    // 0x9fd854: stur            x0, [fp, #-8]
    // 0x9fd858: stp             x0, x2, [SP, #-0x10]!
    // 0x9fd85c: r0 = []()
    //     0x9fd85c: bl              #0x4bdc9c  ; [dart:core] _StringBase::[]
    // 0x9fd860: add             SP, SP, #0x10
    // 0x9fd864: r1 = LoadClassIdInstr(r0)
    //     0x9fd864: ldur            x1, [x0, #-1]
    //     0x9fd868: ubfx            x1, x1, #0xc, #0x14
    // 0x9fd86c: ldr             x16, [fp, #0x18]
    // 0x9fd870: stp             x16, x0, [SP, #-0x10]!
    // 0x9fd874: mov             x0, x1
    // 0x9fd878: mov             lr, x0
    // 0x9fd87c: ldr             lr, [x21, lr, lsl #3]
    // 0x9fd880: blr             lr
    // 0x9fd884: add             SP, SP, #0x10
    // 0x9fd888: tbnz            w0, #4, #0x9fd89c
    // 0x9fd88c: ldur            x0, [fp, #-0x10]
    // 0x9fd890: add             x1, x0, #1
    // 0x9fd894: mov             x5, x1
    // 0x9fd898: b               #0x9fd908
    // 0x9fd89c: ldur            x0, [fp, #-0x10]
    // 0x9fd8a0: ldr             x16, [fp, #0x28]
    // 0x9fd8a4: ldur            lr, [fp, #-8]
    // 0x9fd8a8: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd8ac: r0 = []()
    //     0x9fd8ac: bl              #0x4bdc9c  ; [dart:core] _StringBase::[]
    // 0x9fd8b0: add             SP, SP, #0x10
    // 0x9fd8b4: r1 = LoadClassIdInstr(r0)
    //     0x9fd8b4: ldur            x1, [x0, #-1]
    //     0x9fd8b8: ubfx            x1, x1, #0xc, #0x14
    // 0x9fd8bc: ldr             x16, [fp, #0x10]
    // 0x9fd8c0: stp             x16, x0, [SP, #-0x10]!
    // 0x9fd8c4: mov             x0, x1
    // 0x9fd8c8: mov             lr, x0
    // 0x9fd8cc: ldr             lr, [x21, lr, lsl #3]
    // 0x9fd8d0: blr             lr
    // 0x9fd8d4: add             SP, SP, #0x10
    // 0x9fd8d8: tbnz            w0, #4, #0x9fd900
    // 0x9fd8dc: ldur            x1, [fp, #-0x10]
    // 0x9fd8e0: sub             x2, x1, #1
    // 0x9fd8e4: cbnz            x2, #0x9fd8f8
    // 0x9fd8e8: ldur            x0, [fp, #-0x18]
    // 0x9fd8ec: LeaveFrame
    //     0x9fd8ec: mov             SP, fp
    //     0x9fd8f0: ldp             fp, lr, [SP], #0x10
    // 0x9fd8f4: ret
    //     0x9fd8f4: ret             
    // 0x9fd8f8: mov             x1, x2
    // 0x9fd8fc: b               #0x9fd904
    // 0x9fd900: ldur            x1, [fp, #-0x10]
    // 0x9fd904: mov             x5, x1
    // 0x9fd908: ldur            x1, [fp, #-0x18]
    // 0x9fd90c: add             x4, x1, #1
    // 0x9fd910: ldr             x2, [fp, #0x28]
    // 0x9fd914: ldur            x3, [fp, #-0x20]
    // 0x9fd918: b               #0x9fd824
    // 0x9fd91c: r0 = -1
    //     0x9fd91c: mov             x0, #-1
    // 0x9fd920: LeaveFrame
    //     0x9fd920: mov             SP, fp
    //     0x9fd924: ldp             fp, lr, [SP], #0x10
    // 0x9fd928: ret
    //     0x9fd928: ret             
    // 0x9fd92c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fd92c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fd930: b               #0x9fd804
    // 0x9fd934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fd934: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fd938: b               #0x9fd838
  }
  _ _validate(/* No info */) {
    // ** addr: 0x9fd93c, size: 0x43c
    // 0x9fd93c: EnterFrame
    //     0x9fd93c: stp             fp, lr, [SP, #-0x10]!
    //     0x9fd940: mov             fp, SP
    // 0x9fd944: AllocStack(0x18)
    //     0x9fd944: sub             SP, SP, #0x18
    // 0x9fd948: CheckStackOverflow
    //     0x9fd948: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd94c: cmp             SP, x16
    //     0x9fd950: b.ls            #0x9fdd60
    // 0x9fd954: ldr             x2, [fp, #0x10]
    // 0x9fd958: r0 = BoxInt64Instr(r2)
    //     0x9fd958: sbfiz           x0, x2, #1, #0x1f
    //     0x9fd95c: cmp             x2, x0, asr #1
    //     0x9fd960: b.eq            #0x9fd96c
    //     0x9fd964: bl              #0xd69bb8
    //     0x9fd968: stur            x2, [x0, #7]
    // 0x9fd96c: stur            x0, [fp, #-8]
    // 0x9fd970: ldr             x16, [fp, #0x18]
    // 0x9fd974: r30 = "("
    //     0x9fd974: ldr             lr, [PP, #0x418]  ; [pp+0x418] "("
    // 0x9fd978: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd97c: SaveReg r0
    //     0x9fd97c: str             x0, [SP, #-8]!
    // 0x9fd980: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9fd980: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9fd984: r0 = startsWith()
    //     0x9fd984: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x9fd988: add             SP, SP, #0x18
    // 0x9fd98c: tbnz            w0, #4, #0x9fda18
    // 0x9fd990: ldr             x0, [fp, #0x10]
    // 0x9fd994: ldr             x16, [fp, #0x20]
    // 0x9fd998: ldr             lr, [fp, #0x18]
    // 0x9fd99c: stp             lr, x16, [SP, #-0x10]!
    // 0x9fd9a0: r16 = "("
    //     0x9fd9a0: ldr             x16, [PP, #0x418]  ; [pp+0x418] "("
    // 0x9fd9a4: stp             x16, x0, [SP, #-0x10]!
    // 0x9fd9a8: r16 = ")"
    //     0x9fd9a8: ldr             x16, [PP, #0x420]  ; [pp+0x420] ")"
    // 0x9fd9ac: SaveReg r16
    //     0x9fd9ac: str             x16, [SP, #-8]!
    // 0x9fd9b0: r0 = _findClosing()
    //     0x9fd9b0: bl              #0x9fd7ec  ; [package:dbus/src/dbus_value.dart] DBusSignature::_findClosing
    // 0x9fd9b4: add             SP, SP, #0x28
    // 0x9fd9b8: stur            x0, [fp, #-0x10]
    // 0x9fd9bc: tbnz            x0, #0x3f, #0x9fdc30
    // 0x9fd9c0: ldr             x2, [fp, #0x18]
    // 0x9fd9c4: ldr             x1, [fp, #0x10]
    // 0x9fd9c8: add             x3, x1, #1
    // 0x9fd9cc: mov             x1, x3
    // 0x9fd9d0: CheckStackOverflow
    //     0x9fd9d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fd9d4: cmp             SP, x16
    //     0x9fd9d8: b.ls            #0x9fdd68
    // 0x9fd9dc: cmp             x1, x0
    // 0x9fd9e0: b.ge            #0x9fda08
    // 0x9fd9e4: ldr             x16, [fp, #0x20]
    // 0x9fd9e8: stp             x2, x16, [SP, #-0x10]!
    // 0x9fd9ec: SaveReg r1
    //     0x9fd9ec: str             x1, [SP, #-8]!
    // 0x9fd9f0: r0 = _validate()
    //     0x9fd9f0: bl              #0x9fd93c  ; [package:dbus/src/dbus_value.dart] DBusSignature::_validate
    // 0x9fd9f4: add             SP, SP, #0x18
    // 0x9fd9f8: add             x1, x0, #1
    // 0x9fd9fc: ldr             x2, [fp, #0x18]
    // 0x9fda00: ldur            x0, [fp, #-0x10]
    // 0x9fda04: b               #0x9fd9d0
    // 0x9fda08: ldur            x0, [fp, #-0x10]
    // 0x9fda0c: LeaveFrame
    //     0x9fda0c: mov             SP, fp
    //     0x9fda10: ldp             fp, lr, [SP], #0x10
    // 0x9fda14: ret
    //     0x9fda14: ret             
    // 0x9fda18: ldr             x1, [fp, #0x10]
    // 0x9fda1c: r2 = true
    //     0x9fda1c: add             x2, NULL, #0x20  ; true
    // 0x9fda20: r0 = "value"
    //     0x9fda20: ldr             x0, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fda24: ldr             x16, [fp, #0x18]
    // 0x9fda28: r30 = "a{"
    //     0x9fda28: ldr             lr, [PP, #0x428]  ; [pp+0x428] "a{"
    // 0x9fda2c: stp             lr, x16, [SP, #-0x10]!
    // 0x9fda30: ldur            x16, [fp, #-8]
    // 0x9fda34: SaveReg r16
    //     0x9fda34: str             x16, [SP, #-8]!
    // 0x9fda38: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9fda38: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9fda3c: r0 = startsWith()
    //     0x9fda3c: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x9fda40: add             SP, SP, #0x18
    // 0x9fda44: tbnz            w0, #4, #0x9fdaf8
    // 0x9fda48: ldr             x0, [fp, #0x10]
    // 0x9fda4c: ldr             x16, [fp, #0x20]
    // 0x9fda50: ldr             lr, [fp, #0x18]
    // 0x9fda54: stp             lr, x16, [SP, #-0x10]!
    // 0x9fda58: r16 = "{"
    //     0x9fda58: ldr             x16, [PP, #0x430]  ; [pp+0x430] "{"
    // 0x9fda5c: stp             x16, x0, [SP, #-0x10]!
    // 0x9fda60: r16 = "}"
    //     0x9fda60: ldr             x16, [PP, #0x438]  ; [pp+0x438] "}"
    // 0x9fda64: SaveReg r16
    //     0x9fda64: str             x16, [SP, #-8]!
    // 0x9fda68: r0 = _findClosing()
    //     0x9fda68: bl              #0x9fd7ec  ; [package:dbus/src/dbus_value.dart] DBusSignature::_findClosing
    // 0x9fda6c: add             SP, SP, #0x28
    // 0x9fda70: stur            x0, [fp, #-0x18]
    // 0x9fda74: tbnz            x0, #0x3f, #0x9fdc68
    // 0x9fda78: ldr             x2, [fp, #0x18]
    // 0x9fda7c: ldr             x4, [fp, #0x10]
    // 0x9fda80: r3 = true
    //     0x9fda80: add             x3, NULL, #0x20  ; true
    // 0x9fda84: r1 = "value"
    //     0x9fda84: ldr             x1, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fda88: add             x5, x4, #2
    // 0x9fda8c: r4 = 0
    //     0x9fda8c: mov             x4, #0
    // 0x9fda90: stur            x4, [fp, #-0x10]
    // 0x9fda94: CheckStackOverflow
    //     0x9fda94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fda98: cmp             SP, x16
    //     0x9fda9c: b.ls            #0x9fdd70
    // 0x9fdaa0: cmp             x5, x0
    // 0x9fdaa4: b.ge            #0x9fdadc
    // 0x9fdaa8: ldr             x16, [fp, #0x20]
    // 0x9fdaac: stp             x2, x16, [SP, #-0x10]!
    // 0x9fdab0: SaveReg r5
    //     0x9fdab0: str             x5, [SP, #-8]!
    // 0x9fdab4: r0 = _validate()
    //     0x9fdab4: bl              #0x9fd93c  ; [package:dbus/src/dbus_value.dart] DBusSignature::_validate
    // 0x9fdab8: add             SP, SP, #0x18
    // 0x9fdabc: add             x5, x0, #1
    // 0x9fdac0: ldur            x0, [fp, #-0x10]
    // 0x9fdac4: add             x4, x0, #1
    // 0x9fdac8: ldr             x2, [fp, #0x18]
    // 0x9fdacc: ldur            x0, [fp, #-0x18]
    // 0x9fdad0: r3 = true
    //     0x9fdad0: add             x3, NULL, #0x20  ; true
    // 0x9fdad4: r1 = "value"
    //     0x9fdad4: ldr             x1, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fdad8: b               #0x9fda90
    // 0x9fdadc: mov             x0, x4
    // 0x9fdae0: cmp             x0, #2
    // 0x9fdae4: b.ne            #0x9fdc98
    // 0x9fdae8: ldur            x0, [fp, #-0x18]
    // 0x9fdaec: LeaveFrame
    //     0x9fdaec: mov             SP, fp
    //     0x9fdaf0: ldp             fp, lr, [SP], #0x10
    // 0x9fdaf4: ret
    //     0x9fdaf4: ret             
    // 0x9fdaf8: ldr             x2, [fp, #0x18]
    // 0x9fdafc: ldr             x4, [fp, #0x10]
    // 0x9fdb00: r3 = true
    //     0x9fdb00: add             x3, NULL, #0x20  ; true
    // 0x9fdb04: r0 = "value"
    //     0x9fdb04: ldr             x0, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fdb08: r16 = "a"
    //     0x9fdb08: ldr             x16, [PP, #0x440]  ; [pp+0x440] "a"
    // 0x9fdb0c: stp             x16, x2, [SP, #-0x10]!
    // 0x9fdb10: ldur            x16, [fp, #-8]
    // 0x9fdb14: SaveReg r16
    //     0x9fdb14: str             x16, [SP, #-8]!
    // 0x9fdb18: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9fdb18: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9fdb1c: r0 = startsWith()
    //     0x9fdb1c: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x9fdb20: add             SP, SP, #0x18
    // 0x9fdb24: tbnz            w0, #4, #0x9fdb70
    // 0x9fdb28: ldr             x1, [fp, #0x18]
    // 0x9fdb2c: ldr             x0, [fp, #0x10]
    // 0x9fdb30: LoadField: r2 = r1->field_7
    //     0x9fdb30: ldur            w2, [x1, #7]
    // 0x9fdb34: DecompressPointer r2
    //     0x9fdb34: add             x2, x2, HEAP, lsl #32
    // 0x9fdb38: r3 = LoadInt32Instr(r2)
    //     0x9fdb38: sbfx            x3, x2, #1, #0x1f
    // 0x9fdb3c: sub             x2, x3, #1
    // 0x9fdb40: cmp             x0, x2
    // 0x9fdb44: b.ge            #0x9fdcd0
    // 0x9fdb48: mov             x2, x1
    // 0x9fdb4c: add             x1, x0, #1
    // 0x9fdb50: ldr             x16, [fp, #0x20]
    // 0x9fdb54: stp             x2, x16, [SP, #-0x10]!
    // 0x9fdb58: SaveReg r1
    //     0x9fdb58: str             x1, [SP, #-8]!
    // 0x9fdb5c: r0 = _validate()
    //     0x9fdb5c: bl              #0x9fd93c  ; [package:dbus/src/dbus_value.dart] DBusSignature::_validate
    // 0x9fdb60: add             SP, SP, #0x18
    // 0x9fdb64: LeaveFrame
    //     0x9fdb64: mov             SP, fp
    //     0x9fdb68: ldp             fp, lr, [SP], #0x10
    // 0x9fdb6c: ret
    //     0x9fdb6c: ret             
    // 0x9fdb70: ldr             x2, [fp, #0x18]
    // 0x9fdb74: ldr             x0, [fp, #0x10]
    // 0x9fdb78: r3 = true
    //     0x9fdb78: add             x3, NULL, #0x20  ; true
    // 0x9fdb7c: r1 = "value"
    //     0x9fdb7c: ldr             x1, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fdb80: r16 = "m"
    //     0x9fdb80: ldr             x16, [PP, #0x448]  ; [pp+0x448] "m"
    // 0x9fdb84: stp             x16, x2, [SP, #-0x10]!
    // 0x9fdb88: ldur            x16, [fp, #-8]
    // 0x9fdb8c: SaveReg r16
    //     0x9fdb8c: str             x16, [SP, #-8]!
    // 0x9fdb90: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9fdb90: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9fdb94: r0 = startsWith()
    //     0x9fdb94: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x9fdb98: add             SP, SP, #0x18
    // 0x9fdb9c: tbnz            w0, #4, #0x9fdbe8
    // 0x9fdba0: ldr             x1, [fp, #0x18]
    // 0x9fdba4: ldr             x0, [fp, #0x10]
    // 0x9fdba8: LoadField: r2 = r1->field_7
    //     0x9fdba8: ldur            w2, [x1, #7]
    // 0x9fdbac: DecompressPointer r2
    //     0x9fdbac: add             x2, x2, HEAP, lsl #32
    // 0x9fdbb0: r3 = LoadInt32Instr(r2)
    //     0x9fdbb0: sbfx            x3, x2, #1, #0x1f
    // 0x9fdbb4: sub             x2, x3, #1
    // 0x9fdbb8: cmp             x0, x2
    // 0x9fdbbc: b.ge            #0x9fdcfc
    // 0x9fdbc0: mov             x2, x1
    // 0x9fdbc4: add             x1, x0, #1
    // 0x9fdbc8: ldr             x16, [fp, #0x20]
    // 0x9fdbcc: stp             x2, x16, [SP, #-0x10]!
    // 0x9fdbd0: SaveReg r1
    //     0x9fdbd0: str             x1, [SP, #-8]!
    // 0x9fdbd4: r0 = _validate()
    //     0x9fdbd4: bl              #0x9fd93c  ; [package:dbus/src/dbus_value.dart] DBusSignature::_validate
    // 0x9fdbd8: add             SP, SP, #0x18
    // 0x9fdbdc: LeaveFrame
    //     0x9fdbdc: mov             SP, fp
    //     0x9fdbe0: ldp             fp, lr, [SP], #0x10
    // 0x9fdbe4: ret
    //     0x9fdbe4: ret             
    // 0x9fdbe8: ldr             x2, [fp, #0x18]
    // 0x9fdbec: ldr             x0, [fp, #0x10]
    // 0x9fdbf0: r3 = true
    //     0x9fdbf0: add             x3, NULL, #0x20  ; true
    // 0x9fdbf4: r1 = "value"
    //     0x9fdbf4: ldr             x1, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fdbf8: ldur            x16, [fp, #-8]
    // 0x9fdbfc: stp             x16, x2, [SP, #-0x10]!
    // 0x9fdc00: r0 = []()
    //     0x9fdc00: bl              #0x4bdc9c  ; [dart:core] _StringBase::[]
    // 0x9fdc04: add             SP, SP, #0x10
    // 0x9fdc08: r16 = "ybnqiuxtdsogvha"
    //     0x9fdc08: ldr             x16, [PP, #0x450]  ; [pp+0x450] "ybnqiuxtdsogvha"
    // 0x9fdc0c: stp             x0, x16, [SP, #-0x10]!
    // 0x9fdc10: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fdc10: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fdc14: r0 = contains()
    //     0x9fdc14: bl              #0xd66790  ; [dart:core] _OneByteString::contains
    // 0x9fdc18: add             SP, SP, #0x10
    // 0x9fdc1c: tbnz            w0, #4, #0x9fdd28
    // 0x9fdc20: ldr             x0, [fp, #0x10]
    // 0x9fdc24: LeaveFrame
    //     0x9fdc24: mov             SP, fp
    //     0x9fdc28: ldp             fp, lr, [SP], #0x10
    // 0x9fdc2c: ret
    //     0x9fdc2c: ret             
    // 0x9fdc30: ldr             x0, [fp, #0x18]
    // 0x9fdc34: r0 = ArgumentError()
    //     0x9fdc34: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x9fdc38: mov             x1, x0
    // 0x9fdc3c: r0 = "value"
    //     0x9fdc3c: ldr             x0, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fdc40: StoreField: r1->field_13 = r0
    //     0x9fdc40: stur            w0, [x1, #0x13]
    // 0x9fdc44: r0 = "Struct missing closing parenthesis"
    //     0x9fdc44: ldr             x0, [PP, #0x458]  ; [pp+0x458] "Struct missing closing parenthesis"
    // 0x9fdc48: StoreField: r1->field_17 = r0
    //     0x9fdc48: stur            w0, [x1, #0x17]
    // 0x9fdc4c: ldr             x2, [fp, #0x18]
    // 0x9fdc50: StoreField: r1->field_f = r2
    //     0x9fdc50: stur            w2, [x1, #0xf]
    // 0x9fdc54: r2 = true
    //     0x9fdc54: add             x2, NULL, #0x20  ; true
    // 0x9fdc58: StoreField: r1->field_b = r2
    //     0x9fdc58: stur            w2, [x1, #0xb]
    // 0x9fdc5c: mov             x0, x1
    // 0x9fdc60: r0 = Throw()
    //     0x9fdc60: bl              #0xd67e38  ; ThrowStub
    // 0x9fdc64: brk             #0
    // 0x9fdc68: ldr             x0, [fp, #0x18]
    // 0x9fdc6c: r0 = ArgumentError()
    //     0x9fdc6c: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x9fdc70: r1 = "value"
    //     0x9fdc70: ldr             x1, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fdc74: StoreField: r0->field_13 = r1
    //     0x9fdc74: stur            w1, [x0, #0x13]
    // 0x9fdc78: r1 = "Dict missing closing brace"
    //     0x9fdc78: ldr             x1, [PP, #0x460]  ; [pp+0x460] "Dict missing closing brace"
    // 0x9fdc7c: StoreField: r0->field_17 = r1
    //     0x9fdc7c: stur            w1, [x0, #0x17]
    // 0x9fdc80: ldr             x2, [fp, #0x18]
    // 0x9fdc84: StoreField: r0->field_f = r2
    //     0x9fdc84: stur            w2, [x0, #0xf]
    // 0x9fdc88: r3 = true
    //     0x9fdc88: add             x3, NULL, #0x20  ; true
    // 0x9fdc8c: StoreField: r0->field_b = r3
    //     0x9fdc8c: stur            w3, [x0, #0xb]
    // 0x9fdc90: r0 = Throw()
    //     0x9fdc90: bl              #0xd67e38  ; ThrowStub
    // 0x9fdc94: brk             #0
    // 0x9fdc98: ldr             x0, [fp, #0x18]
    // 0x9fdc9c: r0 = ArgumentError()
    //     0x9fdc9c: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x9fdca0: mov             x1, x0
    // 0x9fdca4: r0 = "value"
    //     0x9fdca4: ldr             x0, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fdca8: StoreField: r1->field_13 = r0
    //     0x9fdca8: stur            w0, [x1, #0x13]
    // 0x9fdcac: r0 = "Dict doesn\'t have correct number of child signatures"
    //     0x9fdcac: ldr             x0, [PP, #0x468]  ; [pp+0x468] "Dict doesn\'t have correct number of child signatures"
    // 0x9fdcb0: StoreField: r1->field_17 = r0
    //     0x9fdcb0: stur            w0, [x1, #0x17]
    // 0x9fdcb4: ldr             x2, [fp, #0x18]
    // 0x9fdcb8: StoreField: r1->field_f = r2
    //     0x9fdcb8: stur            w2, [x1, #0xf]
    // 0x9fdcbc: r3 = true
    //     0x9fdcbc: add             x3, NULL, #0x20  ; true
    // 0x9fdcc0: StoreField: r1->field_b = r3
    //     0x9fdcc0: stur            w3, [x1, #0xb]
    // 0x9fdcc4: mov             x0, x1
    // 0x9fdcc8: r0 = Throw()
    //     0x9fdcc8: bl              #0xd67e38  ; ThrowStub
    // 0x9fdccc: brk             #0
    // 0x9fdcd0: r0 = ArgumentError()
    //     0x9fdcd0: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x9fdcd4: r1 = "value"
    //     0x9fdcd4: ldr             x1, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fdcd8: StoreField: r0->field_13 = r1
    //     0x9fdcd8: stur            w1, [x0, #0x13]
    // 0x9fdcdc: r1 = "Array missing child type"
    //     0x9fdcdc: ldr             x1, [PP, #0x470]  ; [pp+0x470] "Array missing child type"
    // 0x9fdce0: StoreField: r0->field_17 = r1
    //     0x9fdce0: stur            w1, [x0, #0x17]
    // 0x9fdce4: ldr             x2, [fp, #0x18]
    // 0x9fdce8: StoreField: r0->field_f = r2
    //     0x9fdce8: stur            w2, [x0, #0xf]
    // 0x9fdcec: r3 = true
    //     0x9fdcec: add             x3, NULL, #0x20  ; true
    // 0x9fdcf0: StoreField: r0->field_b = r3
    //     0x9fdcf0: stur            w3, [x0, #0xb]
    // 0x9fdcf4: r0 = Throw()
    //     0x9fdcf4: bl              #0xd67e38  ; ThrowStub
    // 0x9fdcf8: brk             #0
    // 0x9fdcfc: r0 = ArgumentError()
    //     0x9fdcfc: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x9fdd00: r1 = "value"
    //     0x9fdd00: ldr             x1, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fdd04: StoreField: r0->field_13 = r1
    //     0x9fdd04: stur            w1, [x0, #0x13]
    // 0x9fdd08: r1 = "Maybe missing child type"
    //     0x9fdd08: ldr             x1, [PP, #0x478]  ; [pp+0x478] "Maybe missing child type"
    // 0x9fdd0c: StoreField: r0->field_17 = r1
    //     0x9fdd0c: stur            w1, [x0, #0x17]
    // 0x9fdd10: ldr             x2, [fp, #0x18]
    // 0x9fdd14: StoreField: r0->field_f = r2
    //     0x9fdd14: stur            w2, [x0, #0xf]
    // 0x9fdd18: r3 = true
    //     0x9fdd18: add             x3, NULL, #0x20  ; true
    // 0x9fdd1c: StoreField: r0->field_b = r3
    //     0x9fdd1c: stur            w3, [x0, #0xb]
    // 0x9fdd20: r0 = Throw()
    //     0x9fdd20: bl              #0xd67e38  ; ThrowStub
    // 0x9fdd24: brk             #0
    // 0x9fdd28: ldr             x0, [fp, #0x18]
    // 0x9fdd2c: r0 = ArgumentError()
    //     0x9fdd2c: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x9fdd30: mov             x1, x0
    // 0x9fdd34: r0 = "value"
    //     0x9fdd34: ldr             x0, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fdd38: StoreField: r1->field_13 = r0
    //     0x9fdd38: stur            w0, [x1, #0x13]
    // 0x9fdd3c: r0 = "Signature contains unknown characters"
    //     0x9fdd3c: ldr             x0, [PP, #0x480]  ; [pp+0x480] "Signature contains unknown characters"
    // 0x9fdd40: StoreField: r1->field_17 = r0
    //     0x9fdd40: stur            w0, [x1, #0x17]
    // 0x9fdd44: ldr             x0, [fp, #0x18]
    // 0x9fdd48: StoreField: r1->field_f = r0
    //     0x9fdd48: stur            w0, [x1, #0xf]
    // 0x9fdd4c: r0 = true
    //     0x9fdd4c: add             x0, NULL, #0x20  ; true
    // 0x9fdd50: StoreField: r1->field_b = r0
    //     0x9fdd50: stur            w0, [x1, #0xb]
    // 0x9fdd54: mov             x0, x1
    // 0x9fdd58: r0 = Throw()
    //     0x9fdd58: bl              #0xd67e38  ; ThrowStub
    // 0x9fdd5c: brk             #0
    // 0x9fdd60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fdd60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fdd64: b               #0x9fd954
    // 0x9fdd68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fdd68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fdd6c: b               #0x9fd9dc
    // 0x9fdd70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fdd70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fdd74: b               #0x9fdaa0
  }
  get _ isSingleCompleteType(/* No info */) {
    // ** addr: 0xa004ec, size: 0x80
    // 0xa004ec: EnterFrame
    //     0xa004ec: stp             fp, lr, [SP, #-0x10]!
    //     0xa004f0: mov             fp, SP
    // 0xa004f4: AllocStack(0x8)
    //     0xa004f4: sub             SP, SP, #8
    // 0xa004f8: CheckStackOverflow
    //     0xa004f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa004fc: cmp             SP, x16
    //     0xa00500: b.ls            #0xa00564
    // 0xa00504: ldr             x0, [fp, #0x10]
    // 0xa00508: LoadField: r1 = r0->field_7
    //     0xa00508: ldur            w1, [x0, #7]
    // 0xa0050c: DecompressPointer r1
    //     0xa0050c: add             x1, x1, HEAP, lsl #32
    // 0xa00510: LoadField: r2 = r1->field_7
    //     0xa00510: ldur            w2, [x1, #7]
    // 0xa00514: DecompressPointer r2
    //     0xa00514: add             x2, x2, HEAP, lsl #32
    // 0xa00518: stur            x2, [fp, #-8]
    // 0xa0051c: cbz             w2, #0xa00554
    // 0xa00520: stp             x1, x0, [SP, #-0x10]!
    // 0xa00524: SaveReg rZR
    //     0xa00524: str             xzr, [SP, #-8]!
    // 0xa00528: r0 = _findChildSignatureEnd()
    //     0xa00528: bl              #0x9fd624  ; [package:dbus/src/dbus_value.dart] DBusSignature::_findChildSignatureEnd
    // 0xa0052c: add             SP, SP, #0x18
    // 0xa00530: ldur            x1, [fp, #-8]
    // 0xa00534: r2 = LoadInt32Instr(r1)
    //     0xa00534: sbfx            x2, x1, #1, #0x1f
    // 0xa00538: sub             x1, x2, #1
    // 0xa0053c: cmp             x0, x1
    // 0xa00540: r16 = true
    //     0xa00540: add             x16, NULL, #0x20  ; true
    // 0xa00544: r17 = false
    //     0xa00544: add             x17, NULL, #0x30  ; false
    // 0xa00548: csel            x2, x16, x17, eq
    // 0xa0054c: mov             x0, x2
    // 0xa00550: b               #0xa00558
    // 0xa00554: r0 = false
    //     0xa00554: add             x0, NULL, #0x30  ; false
    // 0xa00558: LeaveFrame
    //     0xa00558: mov             SP, fp
    //     0xa0055c: ldp             fp, lr, [SP], #0x10
    // 0xa00560: ret
    //     0xa00560: ret             
    // 0xa00564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa00564: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa00568: b               #0xa00504
  }
  get _ isBasic(/* No info */) {
    // ** addr: 0xa01514, size: 0x60
    // 0xa01514: EnterFrame
    //     0xa01514: stp             fp, lr, [SP, #-0x10]!
    //     0xa01518: mov             fp, SP
    // 0xa0151c: CheckStackOverflow
    //     0xa0151c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01520: cmp             SP, x16
    //     0xa01524: b.ls            #0xa0156c
    // 0xa01528: ldr             x0, [fp, #0x10]
    // 0xa0152c: LoadField: r1 = r0->field_7
    //     0xa0152c: ldur            w1, [x0, #7]
    // 0xa01530: DecompressPointer r1
    //     0xa01530: add             x1, x1, HEAP, lsl #32
    // 0xa01534: LoadField: r0 = r1->field_7
    //     0xa01534: ldur            w0, [x1, #7]
    // 0xa01538: DecompressPointer r0
    //     0xa01538: add             x0, x0, HEAP, lsl #32
    // 0xa0153c: cmp             w0, #2
    // 0xa01540: b.ne            #0xa0155c
    // 0xa01544: r16 = "ybnqiuxtdhsog"
    //     0xa01544: ldr             x16, [PP, #0x78c8]  ; [pp+0x78c8] "ybnqiuxtdhsog"
    // 0xa01548: stp             x1, x16, [SP, #-0x10]!
    // 0xa0154c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0154c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa01550: r0 = contains()
    //     0xa01550: bl              #0xd66790  ; [dart:core] _OneByteString::contains
    // 0xa01554: add             SP, SP, #0x10
    // 0xa01558: b               #0xa01560
    // 0xa0155c: r0 = false
    //     0xa0155c: add             x0, NULL, #0x30  ; false
    // 0xa01560: LeaveFrame
    //     0xa01560: mov             SP, fp
    //     0xa01564: ldp             fp, lr, [SP], #0x10
    // 0xa01568: ret
    //     0xa01568: ret             
    // 0xa0156c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0156c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa01570: b               #0xa01528
  }
  _ toString(/* No info */) {
    // ** addr: 0xad1804, size: 0x68
    // 0xad1804: EnterFrame
    //     0xad1804: stp             fp, lr, [SP, #-0x10]!
    //     0xad1808: mov             fp, SP
    // 0xad180c: CheckStackOverflow
    //     0xad180c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1810: cmp             SP, x16
    //     0xad1814: b.ls            #0xad1864
    // 0xad1818: r1 = Null
    //     0xad1818: mov             x1, NULL
    // 0xad181c: r2 = 8
    //     0xad181c: mov             x2, #8
    // 0xad1820: r0 = AllocateArray()
    //     0xad1820: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1824: r17 = DBusSignature
    //     0xad1824: ldr             x17, [PP, #0x7698]  ; [pp+0x7698] Type: DBusSignature
    // 0xad1828: StoreField: r0->field_f = r17
    //     0xad1828: stur            w17, [x0, #0xf]
    // 0xad182c: r17 = "(\'"
    //     0xad182c: ldr             x17, [PP, #0x7168]  ; [pp+0x7168] "(\'"
    // 0xad1830: StoreField: r0->field_13 = r17
    //     0xad1830: stur            w17, [x0, #0x13]
    // 0xad1834: ldr             x1, [fp, #0x10]
    // 0xad1838: LoadField: r2 = r1->field_7
    //     0xad1838: ldur            w2, [x1, #7]
    // 0xad183c: DecompressPointer r2
    //     0xad183c: add             x2, x2, HEAP, lsl #32
    // 0xad1840: StoreField: r0->field_17 = r2
    //     0xad1840: stur            w2, [x0, #0x17]
    // 0xad1844: r17 = "\')"
    //     0xad1844: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xad1848: StoreField: r0->field_1b = r17
    //     0xad1848: stur            w17, [x0, #0x1b]
    // 0xad184c: SaveReg r0
    //     0xad184c: str             x0, [SP, #-8]!
    // 0xad1850: r0 = _interpolate()
    //     0xad1850: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1854: add             SP, SP, #8
    // 0xad1858: LeaveFrame
    //     0xad1858: mov             SP, fp
    //     0xad185c: ldp             fp, lr, [SP], #0x10
    // 0xad1860: ret
    //     0xad1860: ret             
    // 0xad1864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1864: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1868: b               #0xad1818
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc63718, size: 0x48
    // 0xc63718: EnterFrame
    //     0xc63718: stp             fp, lr, [SP, #-0x10]!
    //     0xc6371c: mov             fp, SP
    // 0xc63720: AllocStack(0x8)
    //     0xc63720: sub             SP, SP, #8
    // 0xc63724: CheckStackOverflow
    //     0xc63724: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63728: cmp             SP, x16
    //     0xc6372c: b.ls            #0xc63758
    // 0xc63730: r0 = DBusSignature()
    //     0xc63730: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc63734: stur            x0, [fp, #-8]
    // 0xc63738: r16 = "g"
    //     0xc63738: ldr             x16, [PP, #0x76a0]  ; [pp+0x76a0] "g"
    // 0xc6373c: stp             x16, x0, [SP, #-0x10]!
    // 0xc63740: r0 = DBusSignature()
    //     0xc63740: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc63744: add             SP, SP, #0x10
    // 0xc63748: ldur            x0, [fp, #-8]
    // 0xc6374c: LeaveFrame
    //     0xc6374c: mov             SP, fp
    //     0xc63750: ldp             fp, lr, [SP], #0x10
    // 0xc63754: ret
    //     0xc63754: ret             
    // 0xc63758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc63758: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6375c: b               #0xc63730
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6eb40, size: 0xa0
    // 0xc6eb40: EnterFrame
    //     0xc6eb40: stp             fp, lr, [SP, #-0x10]!
    //     0xc6eb44: mov             fp, SP
    // 0xc6eb48: CheckStackOverflow
    //     0xc6eb48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6eb4c: cmp             SP, x16
    //     0xc6eb50: b.ls            #0xc6ebd8
    // 0xc6eb54: ldr             x0, [fp, #0x10]
    // 0xc6eb58: cmp             w0, NULL
    // 0xc6eb5c: b.ne            #0xc6eb70
    // 0xc6eb60: r0 = false
    //     0xc6eb60: add             x0, NULL, #0x30  ; false
    // 0xc6eb64: LeaveFrame
    //     0xc6eb64: mov             SP, fp
    //     0xc6eb68: ldp             fp, lr, [SP], #0x10
    // 0xc6eb6c: ret
    //     0xc6eb6c: ret             
    // 0xc6eb70: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6eb70: mov             x1, #0x76
    //     0xc6eb74: tbz             w0, #0, #0xc6eb84
    //     0xc6eb78: ldur            x1, [x0, #-1]
    //     0xc6eb7c: ubfx            x1, x1, #0xc, #0x14
    //     0xc6eb80: lsl             x1, x1, #1
    // 0xc6eb84: r17 = 9144
    //     0xc6eb84: mov             x17, #0x23b8
    // 0xc6eb88: cmp             w1, w17
    // 0xc6eb8c: b.ne            #0xc6ebc8
    // 0xc6eb90: ldr             x1, [fp, #0x18]
    // 0xc6eb94: LoadField: r2 = r0->field_7
    //     0xc6eb94: ldur            w2, [x0, #7]
    // 0xc6eb98: DecompressPointer r2
    //     0xc6eb98: add             x2, x2, HEAP, lsl #32
    // 0xc6eb9c: LoadField: r0 = r1->field_7
    //     0xc6eb9c: ldur            w0, [x1, #7]
    // 0xc6eba0: DecompressPointer r0
    //     0xc6eba0: add             x0, x0, HEAP, lsl #32
    // 0xc6eba4: r1 = LoadClassIdInstr(r2)
    //     0xc6eba4: ldur            x1, [x2, #-1]
    //     0xc6eba8: ubfx            x1, x1, #0xc, #0x14
    // 0xc6ebac: stp             x0, x2, [SP, #-0x10]!
    // 0xc6ebb0: mov             x0, x1
    // 0xc6ebb4: mov             lr, x0
    // 0xc6ebb8: ldr             lr, [x21, lr, lsl #3]
    // 0xc6ebbc: blr             lr
    // 0xc6ebc0: add             SP, SP, #0x10
    // 0xc6ebc4: b               #0xc6ebcc
    // 0xc6ebc8: r0 = false
    //     0xc6ebc8: add             x0, NULL, #0x30  ; false
    // 0xc6ebcc: LeaveFrame
    //     0xc6ebcc: mov             SP, fp
    //     0xc6ebd0: ldp             fp, lr, [SP], #0x10
    // 0xc6ebd4: ret
    //     0xc6ebd4: ret             
    // 0xc6ebd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ebd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ebdc: b               #0xc6eb54
  }
}

// class id: 4573, size: 0xc, field offset: 0x8
//   const constructor, 
class DBusString extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad1780, size: 0x84
    // 0xad1780: EnterFrame
    //     0xad1780: stp             fp, lr, [SP, #-0x10]!
    //     0xad1784: mov             fp, SP
    // 0xad1788: AllocStack(0x8)
    //     0xad1788: sub             SP, SP, #8
    // 0xad178c: CheckStackOverflow
    //     0xad178c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1790: cmp             SP, x16
    //     0xad1794: b.ls            #0xad17fc
    // 0xad1798: ldr             x16, [fp, #0x10]
    // 0xad179c: SaveReg r16
    //     0xad179c: str             x16, [SP, #-8]!
    // 0xad17a0: r0 = runtimeType()
    //     0xad17a0: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xad17a4: add             SP, SP, #8
    // 0xad17a8: r1 = Null
    //     0xad17a8: mov             x1, NULL
    // 0xad17ac: r2 = 8
    //     0xad17ac: mov             x2, #8
    // 0xad17b0: stur            x0, [fp, #-8]
    // 0xad17b4: r0 = AllocateArray()
    //     0xad17b4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad17b8: mov             x1, x0
    // 0xad17bc: ldur            x0, [fp, #-8]
    // 0xad17c0: StoreField: r1->field_f = r0
    //     0xad17c0: stur            w0, [x1, #0xf]
    // 0xad17c4: r17 = "(\'"
    //     0xad17c4: ldr             x17, [PP, #0x7168]  ; [pp+0x7168] "(\'"
    // 0xad17c8: StoreField: r1->field_13 = r17
    //     0xad17c8: stur            w17, [x1, #0x13]
    // 0xad17cc: ldr             x0, [fp, #0x10]
    // 0xad17d0: LoadField: r2 = r0->field_7
    //     0xad17d0: ldur            w2, [x0, #7]
    // 0xad17d4: DecompressPointer r2
    //     0xad17d4: add             x2, x2, HEAP, lsl #32
    // 0xad17d8: StoreField: r1->field_17 = r2
    //     0xad17d8: stur            w2, [x1, #0x17]
    // 0xad17dc: r17 = "\')"
    //     0xad17dc: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xad17e0: StoreField: r1->field_1b = r17
    //     0xad17e0: stur            w17, [x1, #0x1b]
    // 0xad17e4: SaveReg r1
    //     0xad17e4: str             x1, [SP, #-8]!
    // 0xad17e8: r0 = _interpolate()
    //     0xad17e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad17ec: add             SP, SP, #8
    // 0xad17f0: LeaveFrame
    //     0xad17f0: mov             SP, fp
    //     0xad17f4: ldp             fp, lr, [SP], #0x10
    // 0xad17f8: ret
    //     0xad17f8: ret             
    // 0xad17fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad17fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1800: b               #0xad1798
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc636d0, size: 0x48
    // 0xc636d0: EnterFrame
    //     0xc636d0: stp             fp, lr, [SP, #-0x10]!
    //     0xc636d4: mov             fp, SP
    // 0xc636d8: AllocStack(0x8)
    //     0xc636d8: sub             SP, SP, #8
    // 0xc636dc: CheckStackOverflow
    //     0xc636dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc636e0: cmp             SP, x16
    //     0xc636e4: b.ls            #0xc63710
    // 0xc636e8: r0 = DBusSignature()
    //     0xc636e8: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc636ec: stur            x0, [fp, #-8]
    // 0xc636f0: r16 = "s"
    //     0xc636f0: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xc636f4: stp             x16, x0, [SP, #-0x10]!
    // 0xc636f8: r0 = DBusSignature()
    //     0xc636f8: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc636fc: add             SP, SP, #0x10
    // 0xc63700: ldur            x0, [fp, #-8]
    // 0xc63704: LeaveFrame
    //     0xc63704: mov             SP, fp
    //     0xc63708: ldp             fp, lr, [SP], #0x10
    // 0xc6370c: ret
    //     0xc6370c: ret             
    // 0xc63710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc63710: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc63714: b               #0xc636e8
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6ea90, size: 0xb0
    // 0xc6ea90: EnterFrame
    //     0xc6ea90: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ea94: mov             fp, SP
    // 0xc6ea98: CheckStackOverflow
    //     0xc6ea98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ea9c: cmp             SP, x16
    //     0xc6eaa0: b.ls            #0xc6eb38
    // 0xc6eaa4: ldr             x0, [fp, #0x10]
    // 0xc6eaa8: cmp             w0, NULL
    // 0xc6eaac: b.ne            #0xc6eac0
    // 0xc6eab0: r0 = false
    //     0xc6eab0: add             x0, NULL, #0x30  ; false
    // 0xc6eab4: LeaveFrame
    //     0xc6eab4: mov             SP, fp
    //     0xc6eab8: ldp             fp, lr, [SP], #0x10
    // 0xc6eabc: ret
    //     0xc6eabc: ret             
    // 0xc6eac0: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6eac0: mov             x1, #0x76
    //     0xc6eac4: tbz             w0, #0, #0xc6ead4
    //     0xc6eac8: ldur            x1, [x0, #-1]
    //     0xc6eacc: ubfx            x1, x1, #0xc, #0x14
    //     0xc6ead0: lsl             x1, x1, #1
    // 0xc6ead4: r2 = LoadInt32Instr(r1)
    //     0xc6ead4: sbfx            x2, x1, #1, #0x1f
    // 0xc6ead8: r17 = 4573
    //     0xc6ead8: mov             x17, #0x11dd
    // 0xc6eadc: cmp             x2, x17
    // 0xc6eae0: b.lt            #0xc6eb28
    // 0xc6eae4: r17 = 4574
    //     0xc6eae4: mov             x17, #0x11de
    // 0xc6eae8: cmp             x2, x17
    // 0xc6eaec: b.gt            #0xc6eb28
    // 0xc6eaf0: ldr             x1, [fp, #0x18]
    // 0xc6eaf4: LoadField: r2 = r0->field_7
    //     0xc6eaf4: ldur            w2, [x0, #7]
    // 0xc6eaf8: DecompressPointer r2
    //     0xc6eaf8: add             x2, x2, HEAP, lsl #32
    // 0xc6eafc: LoadField: r0 = r1->field_7
    //     0xc6eafc: ldur            w0, [x1, #7]
    // 0xc6eb00: DecompressPointer r0
    //     0xc6eb00: add             x0, x0, HEAP, lsl #32
    // 0xc6eb04: r1 = LoadClassIdInstr(r2)
    //     0xc6eb04: ldur            x1, [x2, #-1]
    //     0xc6eb08: ubfx            x1, x1, #0xc, #0x14
    // 0xc6eb0c: stp             x0, x2, [SP, #-0x10]!
    // 0xc6eb10: mov             x0, x1
    // 0xc6eb14: mov             lr, x0
    // 0xc6eb18: ldr             lr, [x21, lr, lsl #3]
    // 0xc6eb1c: blr             lr
    // 0xc6eb20: add             SP, SP, #0x10
    // 0xc6eb24: b               #0xc6eb2c
    // 0xc6eb28: r0 = false
    //     0xc6eb28: add             x0, NULL, #0x30  ; false
    // 0xc6eb2c: LeaveFrame
    //     0xc6eb2c: mov             SP, fp
    //     0xc6eb30: ldp             fp, lr, [SP], #0x10
    // 0xc6eb34: ret
    //     0xc6eb34: ret             
    // 0xc6eb38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6eb38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6eb3c: b               #0xc6eaa4
  }
}

// class id: 4574, size: 0xc, field offset: 0xc
//   const constructor, 
class DBusObjectPath extends DBusString {

  List<String> split(DBusObjectPath) {
    // ** addr: 0x9fcdb8, size: 0xd0
    // 0x9fcdb8: EnterFrame
    //     0x9fcdb8: stp             fp, lr, [SP, #-0x10]!
    //     0x9fcdbc: mov             fp, SP
    // 0x9fcdc0: AllocStack(0x8)
    //     0x9fcdc0: sub             SP, SP, #8
    // 0x9fcdc4: CheckStackOverflow
    //     0x9fcdc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fcdc8: cmp             SP, x16
    //     0x9fcdcc: b.ls            #0x9fce68
    // 0x9fcdd0: ldr             x0, [fp, #0x10]
    // 0x9fcdd4: LoadField: r1 = r0->field_7
    //     0x9fcdd4: ldur            w1, [x0, #7]
    // 0x9fcdd8: DecompressPointer r1
    //     0x9fcdd8: add             x1, x1, HEAP, lsl #32
    // 0x9fcddc: stur            x1, [fp, #-8]
    // 0x9fcde0: r0 = LoadClassIdInstr(r1)
    //     0x9fcde0: ldur            x0, [x1, #-1]
    //     0x9fcde4: ubfx            x0, x0, #0xc, #0x14
    // 0x9fcde8: r16 = "/"
    //     0x9fcde8: ldr             x16, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x9fcdec: stp             x16, x1, [SP, #-0x10]!
    // 0x9fcdf0: mov             lr, x0
    // 0x9fcdf4: ldr             lr, [x21, lr, lsl #3]
    // 0x9fcdf8: blr             lr
    // 0x9fcdfc: add             SP, SP, #0x10
    // 0x9fce00: tbnz            w0, #4, #0x9fce20
    // 0x9fce04: r16 = <String>
    //     0x9fce04: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x9fce08: stp             xzr, x16, [SP, #-0x10]!
    // 0x9fce0c: r0 = _GrowableList()
    //     0x9fce0c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x9fce10: add             SP, SP, #0x10
    // 0x9fce14: LeaveFrame
    //     0x9fce14: mov             SP, fp
    //     0x9fce18: ldp             fp, lr, [SP], #0x10
    // 0x9fce1c: ret
    //     0x9fce1c: ret             
    // 0x9fce20: r0 = 1
    //     0x9fce20: mov             x0, #1
    // 0x9fce24: ldur            x16, [fp, #-8]
    // 0x9fce28: stp             x0, x16, [SP, #-0x10]!
    // 0x9fce2c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fce2c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fce30: r0 = substring()
    //     0x9fce30: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0x9fce34: add             SP, SP, #0x10
    // 0x9fce38: r1 = LoadClassIdInstr(r0)
    //     0x9fce38: ldur            x1, [x0, #-1]
    //     0x9fce3c: ubfx            x1, x1, #0xc, #0x14
    // 0x9fce40: r16 = "/"
    //     0x9fce40: ldr             x16, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x9fce44: stp             x16, x0, [SP, #-0x10]!
    // 0x9fce48: mov             x0, x1
    // 0x9fce4c: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9fce4c: sub             lr, x0, #0xff8
    //     0x9fce50: ldr             lr, [x21, lr, lsl #3]
    //     0x9fce54: blr             lr
    // 0x9fce58: add             SP, SP, #0x10
    // 0x9fce5c: LeaveFrame
    //     0x9fce5c: mov             SP, fp
    //     0x9fce60: ldp             fp, lr, [SP], #0x10
    // 0x9fce64: ret
    //     0x9fce64: ret             
    // 0x9fce68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fce68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fce6c: b               #0x9fcdd0
  }
  _ DBusObjectPath(/* No info */) {
    // ** addr: 0x9fcc00, size: 0x154
    // 0x9fcc00: EnterFrame
    //     0x9fcc00: stp             fp, lr, [SP, #-0x10]!
    //     0x9fcc04: mov             fp, SP
    // 0x9fcc08: CheckStackOverflow
    //     0x9fcc08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fcc0c: cmp             SP, x16
    //     0x9fcc10: b.ls            #0x9fcd4c
    // 0x9fcc14: ldr             x0, [fp, #0x10]
    // 0x9fcc18: ldr             x1, [fp, #0x18]
    // 0x9fcc1c: StoreField: r1->field_7 = r0
    //     0x9fcc1c: stur            w0, [x1, #7]
    //     0x9fcc20: ldurb           w16, [x1, #-1]
    //     0x9fcc24: ldurb           w17, [x0, #-1]
    //     0x9fcc28: and             x16, x17, x16, lsr #2
    //     0x9fcc2c: tst             x16, HEAP, lsr #32
    //     0x9fcc30: b.eq            #0x9fcc38
    //     0x9fcc34: bl              #0xd6826c
    // 0x9fcc38: ldr             x1, [fp, #0x10]
    // 0x9fcc3c: r0 = LoadClassIdInstr(r1)
    //     0x9fcc3c: ldur            x0, [x1, #-1]
    //     0x9fcc40: ubfx            x0, x0, #0xc, #0x14
    // 0x9fcc44: r16 = "/"
    //     0x9fcc44: ldr             x16, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x9fcc48: stp             x16, x1, [SP, #-0x10]!
    // 0x9fcc4c: mov             lr, x0
    // 0x9fcc50: ldr             lr, [x21, lr, lsl #3]
    // 0x9fcc54: blr             lr
    // 0x9fcc58: add             SP, SP, #0x10
    // 0x9fcc5c: tbz             w0, #4, #0x9fcd04
    // 0x9fcc60: ldr             x0, [fp, #0x10]
    // 0x9fcc64: r16 = "[^a-zA-Z0-9_/]"
    //     0x9fcc64: ldr             x16, [PP, #0x770]  ; [pp+0x770] "[^a-zA-Z0-9_/]"
    // 0x9fcc68: stp             x16, NULL, [SP, #-0x10]!
    // 0x9fcc6c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fcc6c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fcc70: r0 = RegExp()
    //     0x9fcc70: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0x9fcc74: add             SP, SP, #0x10
    // 0x9fcc78: ldr             x1, [fp, #0x10]
    // 0x9fcc7c: r2 = LoadClassIdInstr(r1)
    //     0x9fcc7c: ldur            x2, [x1, #-1]
    //     0x9fcc80: ubfx            x2, x2, #0xc, #0x14
    // 0x9fcc84: stp             x0, x1, [SP, #-0x10]!
    // 0x9fcc88: mov             x0, x2
    // 0x9fcc8c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fcc8c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fcc90: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9fcc90: sub             lr, x0, #0xffc
    //     0x9fcc94: ldr             lr, [x21, lr, lsl #3]
    //     0x9fcc98: blr             lr
    // 0x9fcc9c: add             SP, SP, #0x10
    // 0x9fcca0: tbz             w0, #4, #0x9fcd14
    // 0x9fcca4: ldr             x1, [fp, #0x10]
    // 0x9fcca8: r0 = LoadClassIdInstr(r1)
    //     0x9fcca8: ldur            x0, [x1, #-1]
    //     0x9fccac: ubfx            x0, x0, #0xc, #0x14
    // 0x9fccb0: r16 = "//"
    //     0x9fccb0: ldr             x16, [PP, #0x778]  ; [pp+0x778] "//"
    // 0x9fccb4: stp             x16, x1, [SP, #-0x10]!
    // 0x9fccb8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fccb8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fccbc: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9fccbc: sub             lr, x0, #0xffc
    //     0x9fccc0: ldr             lr, [x21, lr, lsl #3]
    //     0x9fccc4: blr             lr
    // 0x9fccc8: add             SP, SP, #0x10
    // 0x9fcccc: tbz             w0, #4, #0x9fcd14
    // 0x9fccd0: ldr             x16, [fp, #0x10]
    // 0x9fccd4: r30 = "/"
    //     0x9fccd4: ldr             lr, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x9fccd8: stp             lr, x16, [SP, #-0x10]!
    // 0x9fccdc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fccdc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fcce0: r0 = startsWith()
    //     0x9fcce0: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x9fcce4: add             SP, SP, #0x10
    // 0x9fcce8: tbnz            w0, #4, #0x9fcd14
    // 0x9fccec: ldr             x16, [fp, #0x10]
    // 0x9fccf0: r30 = "/"
    //     0x9fccf0: ldr             lr, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x9fccf4: stp             lr, x16, [SP, #-0x10]!
    // 0x9fccf8: r0 = endsWith()
    //     0x9fccf8: bl              #0x52b7ec  ; [dart:core] _StringBase::endsWith
    // 0x9fccfc: add             SP, SP, #0x10
    // 0x9fcd00: tbz             w0, #4, #0x9fcd14
    // 0x9fcd04: r0 = Null
    //     0x9fcd04: mov             x0, NULL
    // 0x9fcd08: LeaveFrame
    //     0x9fcd08: mov             SP, fp
    //     0x9fcd0c: ldp             fp, lr, [SP], #0x10
    // 0x9fcd10: ret
    //     0x9fcd10: ret             
    // 0x9fcd14: ldr             x0, [fp, #0x10]
    // 0x9fcd18: r0 = ArgumentError()
    //     0x9fcd18: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x9fcd1c: mov             x1, x0
    // 0x9fcd20: r0 = "value"
    //     0x9fcd20: ldr             x0, [PP, #0x408]  ; [pp+0x408] "value"
    // 0x9fcd24: StoreField: r1->field_13 = r0
    //     0x9fcd24: stur            w0, [x1, #0x13]
    // 0x9fcd28: r0 = "Invalid object path"
    //     0x9fcd28: ldr             x0, [PP, #0x780]  ; [pp+0x780] "Invalid object path"
    // 0x9fcd2c: StoreField: r1->field_17 = r0
    //     0x9fcd2c: stur            w0, [x1, #0x17]
    // 0x9fcd30: ldr             x0, [fp, #0x10]
    // 0x9fcd34: StoreField: r1->field_f = r0
    //     0x9fcd34: stur            w0, [x1, #0xf]
    // 0x9fcd38: r0 = true
    //     0x9fcd38: add             x0, NULL, #0x20  ; true
    // 0x9fcd3c: StoreField: r1->field_b = r0
    //     0x9fcd3c: stur            w0, [x1, #0xb]
    // 0x9fcd40: mov             x0, x1
    // 0x9fcd44: r0 = Throw()
    //     0x9fcd44: bl              #0xd67e38  ; ThrowStub
    // 0x9fcd48: brk             #0
    // 0x9fcd4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fcd4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fcd50: b               #0x9fcc14
  }
  _ isInNamespace(/* No info */) {
    // ** addr: 0xa0513c, size: 0xe0
    // 0xa0513c: EnterFrame
    //     0xa0513c: stp             fp, lr, [SP, #-0x10]!
    //     0xa05140: mov             fp, SP
    // 0xa05144: AllocStack(0x10)
    //     0xa05144: sub             SP, SP, #0x10
    // 0xa05148: CheckStackOverflow
    //     0xa05148: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0514c: cmp             SP, x16
    //     0xa05150: b.ls            #0xa05214
    // 0xa05154: ldr             x0, [fp, #0x10]
    // 0xa05158: LoadField: r1 = r0->field_7
    //     0xa05158: ldur            w1, [x0, #7]
    // 0xa0515c: DecompressPointer r1
    //     0xa0515c: add             x1, x1, HEAP, lsl #32
    // 0xa05160: stur            x1, [fp, #-8]
    // 0xa05164: r0 = LoadClassIdInstr(r1)
    //     0xa05164: ldur            x0, [x1, #-1]
    //     0xa05168: ubfx            x0, x0, #0xc, #0x14
    // 0xa0516c: r16 = "/"
    //     0xa0516c: ldr             x16, [PP, #0x768]  ; [pp+0x768] "/"
    // 0xa05170: stp             x16, x1, [SP, #-0x10]!
    // 0xa05174: mov             lr, x0
    // 0xa05178: ldr             lr, [x21, lr, lsl #3]
    // 0xa0517c: blr             lr
    // 0xa05180: add             SP, SP, #0x10
    // 0xa05184: tbz             w0, #4, #0xa051bc
    // 0xa05188: ldr             x0, [fp, #0x18]
    // 0xa0518c: LoadField: r1 = r0->field_7
    //     0xa0518c: ldur            w1, [x0, #7]
    // 0xa05190: DecompressPointer r1
    //     0xa05190: add             x1, x1, HEAP, lsl #32
    // 0xa05194: stur            x1, [fp, #-0x10]
    // 0xa05198: r0 = LoadClassIdInstr(r1)
    //     0xa05198: ldur            x0, [x1, #-1]
    //     0xa0519c: ubfx            x0, x0, #0xc, #0x14
    // 0xa051a0: ldur            x16, [fp, #-8]
    // 0xa051a4: stp             x16, x1, [SP, #-0x10]!
    // 0xa051a8: mov             lr, x0
    // 0xa051ac: ldr             lr, [x21, lr, lsl #3]
    // 0xa051b0: blr             lr
    // 0xa051b4: add             SP, SP, #0x10
    // 0xa051b8: tbnz            w0, #4, #0xa051c4
    // 0xa051bc: r0 = true
    //     0xa051bc: add             x0, NULL, #0x20  ; true
    // 0xa051c0: b               #0xa05208
    // 0xa051c4: ldur            x0, [fp, #-8]
    // 0xa051c8: r1 = Null
    //     0xa051c8: mov             x1, NULL
    // 0xa051cc: r2 = 4
    //     0xa051cc: mov             x2, #4
    // 0xa051d0: r0 = AllocateArray()
    //     0xa051d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa051d4: mov             x1, x0
    // 0xa051d8: ldur            x0, [fp, #-8]
    // 0xa051dc: StoreField: r1->field_f = r0
    //     0xa051dc: stur            w0, [x1, #0xf]
    // 0xa051e0: r17 = "/"
    //     0xa051e0: ldr             x17, [PP, #0x768]  ; [pp+0x768] "/"
    // 0xa051e4: StoreField: r1->field_13 = r17
    //     0xa051e4: stur            w17, [x1, #0x13]
    // 0xa051e8: SaveReg r1
    //     0xa051e8: str             x1, [SP, #-8]!
    // 0xa051ec: r0 = _interpolate()
    //     0xa051ec: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa051f0: add             SP, SP, #8
    // 0xa051f4: ldur            x16, [fp, #-0x10]
    // 0xa051f8: stp             x0, x16, [SP, #-0x10]!
    // 0xa051fc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa051fc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa05200: r0 = startsWith()
    //     0xa05200: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0xa05204: add             SP, SP, #0x10
    // 0xa05208: LeaveFrame
    //     0xa05208: mov             SP, fp
    //     0xa0520c: ldp             fp, lr, [SP], #0x10
    // 0xa05210: ret
    //     0xa05210: ret             
    // 0xa05214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa05214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa05218: b               #0xa05154
  }
  _ toString(/* No info */) {
    // ** addr: 0xad1718, size: 0x68
    // 0xad1718: EnterFrame
    //     0xad1718: stp             fp, lr, [SP, #-0x10]!
    //     0xad171c: mov             fp, SP
    // 0xad1720: CheckStackOverflow
    //     0xad1720: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1724: cmp             SP, x16
    //     0xad1728: b.ls            #0xad1778
    // 0xad172c: r1 = Null
    //     0xad172c: mov             x1, NULL
    // 0xad1730: r2 = 8
    //     0xad1730: mov             x2, #8
    // 0xad1734: r0 = AllocateArray()
    //     0xad1734: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1738: r17 = DBusObjectPath
    //     0xad1738: ldr             x17, [PP, #0x7688]  ; [pp+0x7688] Type: DBusObjectPath
    // 0xad173c: StoreField: r0->field_f = r17
    //     0xad173c: stur            w17, [x0, #0xf]
    // 0xad1740: r17 = "(\'"
    //     0xad1740: ldr             x17, [PP, #0x7168]  ; [pp+0x7168] "(\'"
    // 0xad1744: StoreField: r0->field_13 = r17
    //     0xad1744: stur            w17, [x0, #0x13]
    // 0xad1748: ldr             x1, [fp, #0x10]
    // 0xad174c: LoadField: r2 = r1->field_7
    //     0xad174c: ldur            w2, [x1, #7]
    // 0xad1750: DecompressPointer r2
    //     0xad1750: add             x2, x2, HEAP, lsl #32
    // 0xad1754: StoreField: r0->field_17 = r2
    //     0xad1754: stur            w2, [x0, #0x17]
    // 0xad1758: r17 = "\')"
    //     0xad1758: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xad175c: StoreField: r0->field_1b = r17
    //     0xad175c: stur            w17, [x0, #0x1b]
    // 0xad1760: SaveReg r0
    //     0xad1760: str             x0, [SP, #-8]!
    // 0xad1764: r0 = _interpolate()
    //     0xad1764: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1768: add             SP, SP, #8
    // 0xad176c: LeaveFrame
    //     0xad176c: mov             SP, fp
    //     0xad1770: ldp             fp, lr, [SP], #0x10
    // 0xad1774: ret
    //     0xad1774: ret             
    // 0xad1778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1778: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad177c: b               #0xad172c
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc63688, size: 0x48
    // 0xc63688: EnterFrame
    //     0xc63688: stp             fp, lr, [SP, #-0x10]!
    //     0xc6368c: mov             fp, SP
    // 0xc63690: AllocStack(0x8)
    //     0xc63690: sub             SP, SP, #8
    // 0xc63694: CheckStackOverflow
    //     0xc63694: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63698: cmp             SP, x16
    //     0xc6369c: b.ls            #0xc636c8
    // 0xc636a0: r0 = DBusSignature()
    //     0xc636a0: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc636a4: stur            x0, [fp, #-8]
    // 0xc636a8: r16 = "o"
    //     0xc636a8: ldr             x16, [PP, #0x7690]  ; [pp+0x7690] "o"
    // 0xc636ac: stp             x16, x0, [SP, #-0x10]!
    // 0xc636b0: r0 = DBusSignature()
    //     0xc636b0: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc636b4: add             SP, SP, #0x10
    // 0xc636b8: ldur            x0, [fp, #-8]
    // 0xc636bc: LeaveFrame
    //     0xc636bc: mov             SP, fp
    //     0xc636c0: ldp             fp, lr, [SP], #0x10
    // 0xc636c4: ret
    //     0xc636c4: ret             
    // 0xc636c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc636c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc636cc: b               #0xc636a0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e9f0, size: 0xa0
    // 0xc6e9f0: EnterFrame
    //     0xc6e9f0: stp             fp, lr, [SP, #-0x10]!
    //     0xc6e9f4: mov             fp, SP
    // 0xc6e9f8: CheckStackOverflow
    //     0xc6e9f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6e9fc: cmp             SP, x16
    //     0xc6ea00: b.ls            #0xc6ea88
    // 0xc6ea04: ldr             x0, [fp, #0x10]
    // 0xc6ea08: cmp             w0, NULL
    // 0xc6ea0c: b.ne            #0xc6ea20
    // 0xc6ea10: r0 = false
    //     0xc6ea10: add             x0, NULL, #0x30  ; false
    // 0xc6ea14: LeaveFrame
    //     0xc6ea14: mov             SP, fp
    //     0xc6ea18: ldp             fp, lr, [SP], #0x10
    // 0xc6ea1c: ret
    //     0xc6ea1c: ret             
    // 0xc6ea20: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6ea20: mov             x1, #0x76
    //     0xc6ea24: tbz             w0, #0, #0xc6ea34
    //     0xc6ea28: ldur            x1, [x0, #-1]
    //     0xc6ea2c: ubfx            x1, x1, #0xc, #0x14
    //     0xc6ea30: lsl             x1, x1, #1
    // 0xc6ea34: r17 = 9148
    //     0xc6ea34: mov             x17, #0x23bc
    // 0xc6ea38: cmp             w1, w17
    // 0xc6ea3c: b.ne            #0xc6ea78
    // 0xc6ea40: ldr             x1, [fp, #0x18]
    // 0xc6ea44: LoadField: r2 = r0->field_7
    //     0xc6ea44: ldur            w2, [x0, #7]
    // 0xc6ea48: DecompressPointer r2
    //     0xc6ea48: add             x2, x2, HEAP, lsl #32
    // 0xc6ea4c: LoadField: r0 = r1->field_7
    //     0xc6ea4c: ldur            w0, [x1, #7]
    // 0xc6ea50: DecompressPointer r0
    //     0xc6ea50: add             x0, x0, HEAP, lsl #32
    // 0xc6ea54: r1 = LoadClassIdInstr(r2)
    //     0xc6ea54: ldur            x1, [x2, #-1]
    //     0xc6ea58: ubfx            x1, x1, #0xc, #0x14
    // 0xc6ea5c: stp             x0, x2, [SP, #-0x10]!
    // 0xc6ea60: mov             x0, x1
    // 0xc6ea64: mov             lr, x0
    // 0xc6ea68: ldr             lr, [x21, lr, lsl #3]
    // 0xc6ea6c: blr             lr
    // 0xc6ea70: add             SP, SP, #0x10
    // 0xc6ea74: b               #0xc6ea7c
    // 0xc6ea78: r0 = false
    //     0xc6ea78: add             x0, NULL, #0x30  ; false
    // 0xc6ea7c: LeaveFrame
    //     0xc6ea7c: mov             SP, fp
    //     0xc6ea80: ldp             fp, lr, [SP], #0x10
    // 0xc6ea84: ret
    //     0xc6ea84: ret             
    // 0xc6ea88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ea88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ea8c: b               #0xc6ea04
  }
}

// class id: 4575, size: 0x10, field offset: 0x8
//   const constructor, 
class DBusDouble extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad166c, size: 0xac
    // 0xad166c: EnterFrame
    //     0xad166c: stp             fp, lr, [SP, #-0x10]!
    //     0xad1670: mov             fp, SP
    // 0xad1674: CheckStackOverflow
    //     0xad1674: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1678: cmp             SP, x16
    //     0xad167c: b.ls            #0xad16f4
    // 0xad1680: r1 = Null
    //     0xad1680: mov             x1, NULL
    // 0xad1684: r2 = 8
    //     0xad1684: mov             x2, #8
    // 0xad1688: r0 = AllocateArray()
    //     0xad1688: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad168c: r17 = DBusDouble
    //     0xad168c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb270] Type: DBusDouble
    //     0xad1690: ldr             x17, [x17, #0x270]
    // 0xad1694: StoreField: r0->field_f = r17
    //     0xad1694: stur            w17, [x0, #0xf]
    // 0xad1698: r17 = "("
    //     0xad1698: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad169c: StoreField: r0->field_13 = r17
    //     0xad169c: stur            w17, [x0, #0x13]
    // 0xad16a0: ldr             x1, [fp, #0x10]
    // 0xad16a4: LoadField: d0 = r1->field_7
    //     0xad16a4: ldur            d0, [x1, #7]
    // 0xad16a8: r1 = inline_Allocate_Double()
    //     0xad16a8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xad16ac: add             x1, x1, #0x10
    //     0xad16b0: cmp             x2, x1
    //     0xad16b4: b.ls            #0xad16fc
    //     0xad16b8: str             x1, [THR, #0x60]  ; THR::top
    //     0xad16bc: sub             x1, x1, #0xf
    //     0xad16c0: mov             x2, #0xd108
    //     0xad16c4: movk            x2, #3, lsl #16
    //     0xad16c8: stur            x2, [x1, #-1]
    // 0xad16cc: StoreField: r1->field_7 = d0
    //     0xad16cc: stur            d0, [x1, #7]
    // 0xad16d0: StoreField: r0->field_17 = r1
    //     0xad16d0: stur            w1, [x0, #0x17]
    // 0xad16d4: r17 = ")"
    //     0xad16d4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad16d8: StoreField: r0->field_1b = r17
    //     0xad16d8: stur            w17, [x0, #0x1b]
    // 0xad16dc: SaveReg r0
    //     0xad16dc: str             x0, [SP, #-8]!
    // 0xad16e0: r0 = _interpolate()
    //     0xad16e0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad16e4: add             SP, SP, #8
    // 0xad16e8: LeaveFrame
    //     0xad16e8: mov             SP, fp
    //     0xad16ec: ldp             fp, lr, [SP], #0x10
    // 0xad16f0: ret
    //     0xad16f0: ret             
    // 0xad16f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad16f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad16f8: b               #0xad1680
    // 0xad16fc: SaveReg d0
    //     0xad16fc: str             q0, [SP, #-0x10]!
    // 0xad1700: SaveReg r0
    //     0xad1700: str             x0, [SP, #-8]!
    // 0xad1704: r0 = AllocateDouble()
    //     0xad1704: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad1708: mov             x1, x0
    // 0xad170c: RestoreReg r0
    //     0xad170c: ldr             x0, [SP], #8
    // 0xad1710: RestoreReg d0
    //     0xad1710: ldr             q0, [SP], #0x10
    // 0xad1714: b               #0xad16cc
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafa7fc, size: 0x5c
    // 0xafa7fc: ldr             x1, [SP]
    // 0xafa800: LoadField: d0 = r1->field_7
    //     0xafa800: ldur            d0, [x1, #7]
    // 0xafa804: mov             x16, v0.d[0]
    // 0xafa808: and             x16, x16, #0x7ff0000000000000
    // 0xafa80c: r17 = 9218868437227405312
    //     0xafa80c: mov             x17, #0x7ff0000000000000
    // 0xafa810: cmp             x16, x17
    // 0xafa814: b.eq            #0xafa844
    // 0xafa818: fcvtzs          x16, d0
    // 0xafa81c: scvtf           d1, x16
    // 0xafa820: fcmp            d1, d0
    // 0xafa824: b.ne            #0xafa844
    // 0xafa828: r17 = 11601
    //     0xafa828: mov             x17, #0x2d51
    // 0xafa82c: mul             x1, x16, x17
    // 0xafa830: umulh           x16, x16, x17
    // 0xafa834: eor             x1, x1, x16
    // 0xafa838: r1 = 0
    //     0xafa838: eor             x1, x1, x1, lsr #32
    // 0xafa83c: and             x1, x1, #0x3fffffff
    // 0xafa840: b               #0xafa850
    // 0xafa844: r1 = 0.000000
    //     0xafa844: fmov            x1, d0
    // 0xafa848: r1 = 0
    //     0xafa848: eor             x1, x1, x1, lsr #32
    // 0xafa84c: and             x1, x1, #0x3fffffff
    // 0xafa850: lsl             x0, x1, #1
    // 0xafa854: ret
    //     0xafa854: ret             
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc63640, size: 0x48
    // 0xc63640: EnterFrame
    //     0xc63640: stp             fp, lr, [SP, #-0x10]!
    //     0xc63644: mov             fp, SP
    // 0xc63648: AllocStack(0x8)
    //     0xc63648: sub             SP, SP, #8
    // 0xc6364c: CheckStackOverflow
    //     0xc6364c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63650: cmp             SP, x16
    //     0xc63654: b.ls            #0xc63680
    // 0xc63658: r0 = DBusSignature()
    //     0xc63658: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc6365c: stur            x0, [fp, #-8]
    // 0xc63660: r16 = "d"
    //     0xc63660: ldr             x16, [PP, #0x7908]  ; [pp+0x7908] "d"
    // 0xc63664: stp             x16, x0, [SP, #-0x10]!
    // 0xc63668: r0 = DBusSignature()
    //     0xc63668: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc6366c: add             SP, SP, #0x10
    // 0xc63670: ldur            x0, [fp, #-8]
    // 0xc63674: LeaveFrame
    //     0xc63674: mov             SP, fp
    //     0xc63678: ldp             fp, lr, [SP], #0x10
    // 0xc6367c: ret
    //     0xc6367c: ret             
    // 0xc63680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc63680: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc63684: b               #0xc63658
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e988, size: 0x68
    // 0xc6e988: ldr             x1, [SP]
    // 0xc6e98c: cmp             w1, NULL
    // 0xc6e990: b.ne            #0xc6e99c
    // 0xc6e994: r0 = false
    //     0xc6e994: add             x0, NULL, #0x30  ; false
    // 0xc6e998: ret
    //     0xc6e998: ret             
    // 0xc6e99c: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e99c: mov             x2, #0x76
    //     0xc6e9a0: tbz             w1, #0, #0xc6e9b0
    //     0xc6e9a4: ldur            x2, [x1, #-1]
    //     0xc6e9a8: ubfx            x2, x2, #0xc, #0x14
    //     0xc6e9ac: lsl             x2, x2, #1
    // 0xc6e9b0: r17 = 9150
    //     0xc6e9b0: mov             x17, #0x23be
    // 0xc6e9b4: cmp             w2, w17
    // 0xc6e9b8: b.ne            #0xc6e9e8
    // 0xc6e9bc: ldr             x2, [SP, #8]
    // 0xc6e9c0: LoadField: d0 = r1->field_7
    //     0xc6e9c0: ldur            d0, [x1, #7]
    // 0xc6e9c4: LoadField: d1 = r2->field_7
    //     0xc6e9c4: ldur            d1, [x2, #7]
    // 0xc6e9c8: fcmp            d0, d1
    // 0xc6e9cc: b.vs            #0xc6e9d4
    // 0xc6e9d0: b.eq            #0xc6e9dc
    // 0xc6e9d4: r1 = false
    //     0xc6e9d4: add             x1, NULL, #0x30  ; false
    // 0xc6e9d8: b               #0xc6e9e0
    // 0xc6e9dc: r1 = true
    //     0xc6e9dc: add             x1, NULL, #0x20  ; true
    // 0xc6e9e0: mov             x0, x1
    // 0xc6e9e4: b               #0xc6e9ec
    // 0xc6e9e8: r0 = false
    //     0xc6e9e8: add             x0, NULL, #0x30  ; false
    // 0xc6e9ec: ret
    //     0xc6e9ec: ret             
  }
}

// class id: 4576, size: 0x10, field offset: 0x8
//   const constructor, 
class DBusUint64 extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad15ec, size: 0x80
    // 0xad15ec: EnterFrame
    //     0xad15ec: stp             fp, lr, [SP, #-0x10]!
    //     0xad15f0: mov             fp, SP
    // 0xad15f4: CheckStackOverflow
    //     0xad15f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad15f8: cmp             SP, x16
    //     0xad15fc: b.ls            #0xad1664
    // 0xad1600: r1 = Null
    //     0xad1600: mov             x1, NULL
    // 0xad1604: r2 = 8
    //     0xad1604: mov             x2, #8
    // 0xad1608: r0 = AllocateArray()
    //     0xad1608: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad160c: mov             x2, x0
    // 0xad1610: r17 = DBusUint64
    //     0xad1610: add             x17, PP, #0xb, lsl #12  ; [pp+0xb3e0] Type: DBusUint64
    //     0xad1614: ldr             x17, [x17, #0x3e0]
    // 0xad1618: StoreField: r2->field_f = r17
    //     0xad1618: stur            w17, [x2, #0xf]
    // 0xad161c: r17 = "("
    //     0xad161c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad1620: StoreField: r2->field_13 = r17
    //     0xad1620: stur            w17, [x2, #0x13]
    // 0xad1624: ldr             x0, [fp, #0x10]
    // 0xad1628: LoadField: r3 = r0->field_7
    //     0xad1628: ldur            x3, [x0, #7]
    // 0xad162c: r0 = BoxInt64Instr(r3)
    //     0xad162c: sbfiz           x0, x3, #1, #0x1f
    //     0xad1630: cmp             x3, x0, asr #1
    //     0xad1634: b.eq            #0xad1640
    //     0xad1638: bl              #0xd69bb8
    //     0xad163c: stur            x3, [x0, #7]
    // 0xad1640: StoreField: r2->field_17 = r0
    //     0xad1640: stur            w0, [x2, #0x17]
    // 0xad1644: r17 = ")"
    //     0xad1644: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad1648: StoreField: r2->field_1b = r17
    //     0xad1648: stur            w17, [x2, #0x1b]
    // 0xad164c: SaveReg r2
    //     0xad164c: str             x2, [SP, #-8]!
    // 0xad1650: r0 = _interpolate()
    //     0xad1650: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1654: add             SP, SP, #8
    // 0xad1658: LeaveFrame
    //     0xad1658: mov             SP, fp
    //     0xad165c: ldp             fp, lr, [SP], #0x10
    // 0xad1660: ret
    //     0xad1660: ret             
    // 0xad1664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1664: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1668: b               #0xad1600
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc635f8, size: 0x48
    // 0xc635f8: EnterFrame
    //     0xc635f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc635fc: mov             fp, SP
    // 0xc63600: AllocStack(0x8)
    //     0xc63600: sub             SP, SP, #8
    // 0xc63604: CheckStackOverflow
    //     0xc63604: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63608: cmp             SP, x16
    //     0xc6360c: b.ls            #0xc63638
    // 0xc63610: r0 = DBusSignature()
    //     0xc63610: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc63614: stur            x0, [fp, #-8]
    // 0xc63618: r16 = "t"
    //     0xc63618: ldr             x16, [PP, #0x7900]  ; [pp+0x7900] "t"
    // 0xc6361c: stp             x16, x0, [SP, #-0x10]!
    // 0xc63620: r0 = DBusSignature()
    //     0xc63620: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc63624: add             SP, SP, #0x10
    // 0xc63628: ldur            x0, [fp, #-8]
    // 0xc6362c: LeaveFrame
    //     0xc6362c: mov             SP, fp
    //     0xc63630: ldp             fp, lr, [SP], #0x10
    // 0xc63634: ret
    //     0xc63634: ret             
    // 0xc63638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc63638: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6363c: b               #0xc63610
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e928, size: 0x60
    // 0xc6e928: ldr             x1, [SP]
    // 0xc6e92c: cmp             w1, NULL
    // 0xc6e930: b.ne            #0xc6e93c
    // 0xc6e934: r0 = false
    //     0xc6e934: add             x0, NULL, #0x30  ; false
    // 0xc6e938: ret
    //     0xc6e938: ret             
    // 0xc6e93c: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e93c: mov             x2, #0x76
    //     0xc6e940: tbz             w1, #0, #0xc6e950
    //     0xc6e944: ldur            x2, [x1, #-1]
    //     0xc6e948: ubfx            x2, x2, #0xc, #0x14
    //     0xc6e94c: lsl             x2, x2, #1
    // 0xc6e950: r17 = 9152
    //     0xc6e950: mov             x17, #0x23c0
    // 0xc6e954: cmp             w2, w17
    // 0xc6e958: b.ne            #0xc6e980
    // 0xc6e95c: ldr             x2, [SP, #8]
    // 0xc6e960: LoadField: r3 = r1->field_7
    //     0xc6e960: ldur            x3, [x1, #7]
    // 0xc6e964: LoadField: r1 = r2->field_7
    //     0xc6e964: ldur            x1, [x2, #7]
    // 0xc6e968: cmp             x3, x1
    // 0xc6e96c: r16 = true
    //     0xc6e96c: add             x16, NULL, #0x20  ; true
    // 0xc6e970: r17 = false
    //     0xc6e970: add             x17, NULL, #0x30  ; false
    // 0xc6e974: csel            x2, x16, x17, eq
    // 0xc6e978: mov             x0, x2
    // 0xc6e97c: b               #0xc6e984
    // 0xc6e980: r0 = false
    //     0xc6e980: add             x0, NULL, #0x30  ; false
    // 0xc6e984: ret
    //     0xc6e984: ret             
  }
}

// class id: 4577, size: 0x10, field offset: 0x8
//   const constructor, 
class DBusInt64 extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad156c, size: 0x80
    // 0xad156c: EnterFrame
    //     0xad156c: stp             fp, lr, [SP, #-0x10]!
    //     0xad1570: mov             fp, SP
    // 0xad1574: CheckStackOverflow
    //     0xad1574: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1578: cmp             SP, x16
    //     0xad157c: b.ls            #0xad15e4
    // 0xad1580: r1 = Null
    //     0xad1580: mov             x1, NULL
    // 0xad1584: r2 = 8
    //     0xad1584: mov             x2, #8
    // 0xad1588: r0 = AllocateArray()
    //     0xad1588: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad158c: mov             x2, x0
    // 0xad1590: r17 = DBusInt64
    //     0xad1590: add             x17, PP, #0xb, lsl #12  ; [pp+0xb258] Type: DBusInt64
    //     0xad1594: ldr             x17, [x17, #0x258]
    // 0xad1598: StoreField: r2->field_f = r17
    //     0xad1598: stur            w17, [x2, #0xf]
    // 0xad159c: r17 = "("
    //     0xad159c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad15a0: StoreField: r2->field_13 = r17
    //     0xad15a0: stur            w17, [x2, #0x13]
    // 0xad15a4: ldr             x0, [fp, #0x10]
    // 0xad15a8: LoadField: r3 = r0->field_7
    //     0xad15a8: ldur            x3, [x0, #7]
    // 0xad15ac: r0 = BoxInt64Instr(r3)
    //     0xad15ac: sbfiz           x0, x3, #1, #0x1f
    //     0xad15b0: cmp             x3, x0, asr #1
    //     0xad15b4: b.eq            #0xad15c0
    //     0xad15b8: bl              #0xd69bb8
    //     0xad15bc: stur            x3, [x0, #7]
    // 0xad15c0: StoreField: r2->field_17 = r0
    //     0xad15c0: stur            w0, [x2, #0x17]
    // 0xad15c4: r17 = ")"
    //     0xad15c4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad15c8: StoreField: r2->field_1b = r17
    //     0xad15c8: stur            w17, [x2, #0x1b]
    // 0xad15cc: SaveReg r2
    //     0xad15cc: str             x2, [SP, #-8]!
    // 0xad15d0: r0 = _interpolate()
    //     0xad15d0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad15d4: add             SP, SP, #8
    // 0xad15d8: LeaveFrame
    //     0xad15d8: mov             SP, fp
    //     0xad15dc: ldp             fp, lr, [SP], #0x10
    // 0xad15e0: ret
    //     0xad15e0: ret             
    // 0xad15e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad15e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad15e8: b               #0xad1580
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc635b0, size: 0x48
    // 0xc635b0: EnterFrame
    //     0xc635b0: stp             fp, lr, [SP, #-0x10]!
    //     0xc635b4: mov             fp, SP
    // 0xc635b8: AllocStack(0x8)
    //     0xc635b8: sub             SP, SP, #8
    // 0xc635bc: CheckStackOverflow
    //     0xc635bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc635c0: cmp             SP, x16
    //     0xc635c4: b.ls            #0xc635f0
    // 0xc635c8: r0 = DBusSignature()
    //     0xc635c8: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc635cc: stur            x0, [fp, #-8]
    // 0xc635d0: r16 = "x"
    //     0xc635d0: ldr             x16, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xc635d4: stp             x16, x0, [SP, #-0x10]!
    // 0xc635d8: r0 = DBusSignature()
    //     0xc635d8: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc635dc: add             SP, SP, #0x10
    // 0xc635e0: ldur            x0, [fp, #-8]
    // 0xc635e4: LeaveFrame
    //     0xc635e4: mov             SP, fp
    //     0xc635e8: ldp             fp, lr, [SP], #0x10
    // 0xc635ec: ret
    //     0xc635ec: ret             
    // 0xc635f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc635f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc635f4: b               #0xc635c8
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e8c8, size: 0x60
    // 0xc6e8c8: ldr             x1, [SP]
    // 0xc6e8cc: cmp             w1, NULL
    // 0xc6e8d0: b.ne            #0xc6e8dc
    // 0xc6e8d4: r0 = false
    //     0xc6e8d4: add             x0, NULL, #0x30  ; false
    // 0xc6e8d8: ret
    //     0xc6e8d8: ret             
    // 0xc6e8dc: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e8dc: mov             x2, #0x76
    //     0xc6e8e0: tbz             w1, #0, #0xc6e8f0
    //     0xc6e8e4: ldur            x2, [x1, #-1]
    //     0xc6e8e8: ubfx            x2, x2, #0xc, #0x14
    //     0xc6e8ec: lsl             x2, x2, #1
    // 0xc6e8f0: r17 = 9154
    //     0xc6e8f0: mov             x17, #0x23c2
    // 0xc6e8f4: cmp             w2, w17
    // 0xc6e8f8: b.ne            #0xc6e920
    // 0xc6e8fc: ldr             x2, [SP, #8]
    // 0xc6e900: LoadField: r3 = r1->field_7
    //     0xc6e900: ldur            x3, [x1, #7]
    // 0xc6e904: LoadField: r1 = r2->field_7
    //     0xc6e904: ldur            x1, [x2, #7]
    // 0xc6e908: cmp             x3, x1
    // 0xc6e90c: r16 = true
    //     0xc6e90c: add             x16, NULL, #0x20  ; true
    // 0xc6e910: r17 = false
    //     0xc6e910: add             x17, NULL, #0x30  ; false
    // 0xc6e914: csel            x2, x16, x17, eq
    // 0xc6e918: mov             x0, x2
    // 0xc6e91c: b               #0xc6e924
    // 0xc6e920: r0 = false
    //     0xc6e920: add             x0, NULL, #0x30  ; false
    // 0xc6e924: ret
    //     0xc6e924: ret             
  }
}

// class id: 4578, size: 0x10, field offset: 0x8
//   const constructor, 
class DBusUint32 extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad14ec, size: 0x80
    // 0xad14ec: EnterFrame
    //     0xad14ec: stp             fp, lr, [SP, #-0x10]!
    //     0xad14f0: mov             fp, SP
    // 0xad14f4: CheckStackOverflow
    //     0xad14f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad14f8: cmp             SP, x16
    //     0xad14fc: b.ls            #0xad1564
    // 0xad1500: r1 = Null
    //     0xad1500: mov             x1, NULL
    // 0xad1504: r2 = 8
    //     0xad1504: mov             x2, #8
    // 0xad1508: r0 = AllocateArray()
    //     0xad1508: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad150c: mov             x2, x0
    // 0xad1510: r17 = DBusUint32
    //     0xad1510: add             x17, PP, #8, lsl #12  ; [pp+0x8028] Type: DBusUint32
    //     0xad1514: ldr             x17, [x17, #0x28]
    // 0xad1518: StoreField: r2->field_f = r17
    //     0xad1518: stur            w17, [x2, #0xf]
    // 0xad151c: r17 = "("
    //     0xad151c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad1520: StoreField: r2->field_13 = r17
    //     0xad1520: stur            w17, [x2, #0x13]
    // 0xad1524: ldr             x0, [fp, #0x10]
    // 0xad1528: LoadField: r3 = r0->field_7
    //     0xad1528: ldur            x3, [x0, #7]
    // 0xad152c: r0 = BoxInt64Instr(r3)
    //     0xad152c: sbfiz           x0, x3, #1, #0x1f
    //     0xad1530: cmp             x3, x0, asr #1
    //     0xad1534: b.eq            #0xad1540
    //     0xad1538: bl              #0xd69bb8
    //     0xad153c: stur            x3, [x0, #7]
    // 0xad1540: StoreField: r2->field_17 = r0
    //     0xad1540: stur            w0, [x2, #0x17]
    // 0xad1544: r17 = ")"
    //     0xad1544: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad1548: StoreField: r2->field_1b = r17
    //     0xad1548: stur            w17, [x2, #0x1b]
    // 0xad154c: SaveReg r2
    //     0xad154c: str             x2, [SP, #-8]!
    // 0xad1550: r0 = _interpolate()
    //     0xad1550: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1554: add             SP, SP, #8
    // 0xad1558: LeaveFrame
    //     0xad1558: mov             SP, fp
    //     0xad155c: ldp             fp, lr, [SP], #0x10
    // 0xad1560: ret
    //     0xad1560: ret             
    // 0xad1564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1564: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1568: b               #0xad1500
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc63568, size: 0x48
    // 0xc63568: EnterFrame
    //     0xc63568: stp             fp, lr, [SP, #-0x10]!
    //     0xc6356c: mov             fp, SP
    // 0xc63570: AllocStack(0x8)
    //     0xc63570: sub             SP, SP, #8
    // 0xc63574: CheckStackOverflow
    //     0xc63574: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63578: cmp             SP, x16
    //     0xc6357c: b.ls            #0xc635a8
    // 0xc63580: r0 = DBusSignature()
    //     0xc63580: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc63584: stur            x0, [fp, #-8]
    // 0xc63588: r16 = "u"
    //     0xc63588: ldr             x16, [PP, #0x78f8]  ; [pp+0x78f8] "u"
    // 0xc6358c: stp             x16, x0, [SP, #-0x10]!
    // 0xc63590: r0 = DBusSignature()
    //     0xc63590: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc63594: add             SP, SP, #0x10
    // 0xc63598: ldur            x0, [fp, #-8]
    // 0xc6359c: LeaveFrame
    //     0xc6359c: mov             SP, fp
    //     0xc635a0: ldp             fp, lr, [SP], #0x10
    // 0xc635a4: ret
    //     0xc635a4: ret             
    // 0xc635a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc635a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc635ac: b               #0xc63580
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e868, size: 0x60
    // 0xc6e868: ldr             x1, [SP]
    // 0xc6e86c: cmp             w1, NULL
    // 0xc6e870: b.ne            #0xc6e87c
    // 0xc6e874: r0 = false
    //     0xc6e874: add             x0, NULL, #0x30  ; false
    // 0xc6e878: ret
    //     0xc6e878: ret             
    // 0xc6e87c: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e87c: mov             x2, #0x76
    //     0xc6e880: tbz             w1, #0, #0xc6e890
    //     0xc6e884: ldur            x2, [x1, #-1]
    //     0xc6e888: ubfx            x2, x2, #0xc, #0x14
    //     0xc6e88c: lsl             x2, x2, #1
    // 0xc6e890: r17 = 9156
    //     0xc6e890: mov             x17, #0x23c4
    // 0xc6e894: cmp             w2, w17
    // 0xc6e898: b.ne            #0xc6e8c0
    // 0xc6e89c: ldr             x2, [SP, #8]
    // 0xc6e8a0: LoadField: r3 = r1->field_7
    //     0xc6e8a0: ldur            x3, [x1, #7]
    // 0xc6e8a4: LoadField: r1 = r2->field_7
    //     0xc6e8a4: ldur            x1, [x2, #7]
    // 0xc6e8a8: cmp             x3, x1
    // 0xc6e8ac: r16 = true
    //     0xc6e8ac: add             x16, NULL, #0x20  ; true
    // 0xc6e8b0: r17 = false
    //     0xc6e8b0: add             x17, NULL, #0x30  ; false
    // 0xc6e8b4: csel            x2, x16, x17, eq
    // 0xc6e8b8: mov             x0, x2
    // 0xc6e8bc: b               #0xc6e8c4
    // 0xc6e8c0: r0 = false
    //     0xc6e8c0: add             x0, NULL, #0x30  ; false
    // 0xc6e8c4: ret
    //     0xc6e8c4: ret             
  }
}

// class id: 4579, size: 0x10, field offset: 0x8
//   const constructor, 
class DBusInt32 extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad146c, size: 0x80
    // 0xad146c: EnterFrame
    //     0xad146c: stp             fp, lr, [SP, #-0x10]!
    //     0xad1470: mov             fp, SP
    // 0xad1474: CheckStackOverflow
    //     0xad1474: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1478: cmp             SP, x16
    //     0xad147c: b.ls            #0xad14e4
    // 0xad1480: r1 = Null
    //     0xad1480: mov             x1, NULL
    // 0xad1484: r2 = 8
    //     0xad1484: mov             x2, #8
    // 0xad1488: r0 = AllocateArray()
    //     0xad1488: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad148c: mov             x2, x0
    // 0xad1490: r17 = DBusInt32
    //     0xad1490: add             x17, PP, #0xb, lsl #12  ; [pp+0xb278] Type: DBusInt32
    //     0xad1494: ldr             x17, [x17, #0x278]
    // 0xad1498: StoreField: r2->field_f = r17
    //     0xad1498: stur            w17, [x2, #0xf]
    // 0xad149c: r17 = "("
    //     0xad149c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad14a0: StoreField: r2->field_13 = r17
    //     0xad14a0: stur            w17, [x2, #0x13]
    // 0xad14a4: ldr             x0, [fp, #0x10]
    // 0xad14a8: LoadField: r3 = r0->field_7
    //     0xad14a8: ldur            x3, [x0, #7]
    // 0xad14ac: r0 = BoxInt64Instr(r3)
    //     0xad14ac: sbfiz           x0, x3, #1, #0x1f
    //     0xad14b0: cmp             x3, x0, asr #1
    //     0xad14b4: b.eq            #0xad14c0
    //     0xad14b8: bl              #0xd69bb8
    //     0xad14bc: stur            x3, [x0, #7]
    // 0xad14c0: StoreField: r2->field_17 = r0
    //     0xad14c0: stur            w0, [x2, #0x17]
    // 0xad14c4: r17 = ")"
    //     0xad14c4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad14c8: StoreField: r2->field_1b = r17
    //     0xad14c8: stur            w17, [x2, #0x1b]
    // 0xad14cc: SaveReg r2
    //     0xad14cc: str             x2, [SP, #-8]!
    // 0xad14d0: r0 = _interpolate()
    //     0xad14d0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad14d4: add             SP, SP, #8
    // 0xad14d8: LeaveFrame
    //     0xad14d8: mov             SP, fp
    //     0xad14dc: ldp             fp, lr, [SP], #0x10
    // 0xad14e0: ret
    //     0xad14e0: ret             
    // 0xad14e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad14e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad14e8: b               #0xad1480
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc63520, size: 0x48
    // 0xc63520: EnterFrame
    //     0xc63520: stp             fp, lr, [SP, #-0x10]!
    //     0xc63524: mov             fp, SP
    // 0xc63528: AllocStack(0x8)
    //     0xc63528: sub             SP, SP, #8
    // 0xc6352c: CheckStackOverflow
    //     0xc6352c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63530: cmp             SP, x16
    //     0xc63534: b.ls            #0xc63560
    // 0xc63538: r0 = DBusSignature()
    //     0xc63538: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc6353c: stur            x0, [fp, #-8]
    // 0xc63540: r16 = "i"
    //     0xc63540: ldr             x16, [PP, #0x78f0]  ; [pp+0x78f0] "i"
    // 0xc63544: stp             x16, x0, [SP, #-0x10]!
    // 0xc63548: r0 = DBusSignature()
    //     0xc63548: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc6354c: add             SP, SP, #0x10
    // 0xc63550: ldur            x0, [fp, #-8]
    // 0xc63554: LeaveFrame
    //     0xc63554: mov             SP, fp
    //     0xc63558: ldp             fp, lr, [SP], #0x10
    // 0xc6355c: ret
    //     0xc6355c: ret             
    // 0xc63560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc63560: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc63564: b               #0xc63538
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e808, size: 0x60
    // 0xc6e808: ldr             x1, [SP]
    // 0xc6e80c: cmp             w1, NULL
    // 0xc6e810: b.ne            #0xc6e81c
    // 0xc6e814: r0 = false
    //     0xc6e814: add             x0, NULL, #0x30  ; false
    // 0xc6e818: ret
    //     0xc6e818: ret             
    // 0xc6e81c: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e81c: mov             x2, #0x76
    //     0xc6e820: tbz             w1, #0, #0xc6e830
    //     0xc6e824: ldur            x2, [x1, #-1]
    //     0xc6e828: ubfx            x2, x2, #0xc, #0x14
    //     0xc6e82c: lsl             x2, x2, #1
    // 0xc6e830: r17 = 9158
    //     0xc6e830: mov             x17, #0x23c6
    // 0xc6e834: cmp             w2, w17
    // 0xc6e838: b.ne            #0xc6e860
    // 0xc6e83c: ldr             x2, [SP, #8]
    // 0xc6e840: LoadField: r3 = r1->field_7
    //     0xc6e840: ldur            x3, [x1, #7]
    // 0xc6e844: LoadField: r1 = r2->field_7
    //     0xc6e844: ldur            x1, [x2, #7]
    // 0xc6e848: cmp             x3, x1
    // 0xc6e84c: r16 = true
    //     0xc6e84c: add             x16, NULL, #0x20  ; true
    // 0xc6e850: r17 = false
    //     0xc6e850: add             x17, NULL, #0x30  ; false
    // 0xc6e854: csel            x2, x16, x17, eq
    // 0xc6e858: mov             x0, x2
    // 0xc6e85c: b               #0xc6e864
    // 0xc6e860: r0 = false
    //     0xc6e860: add             x0, NULL, #0x30  ; false
    // 0xc6e864: ret
    //     0xc6e864: ret             
  }
}

// class id: 4580, size: 0x10, field offset: 0x8
//   const constructor, 
class DBusUint16 extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad13ec, size: 0x80
    // 0xad13ec: EnterFrame
    //     0xad13ec: stp             fp, lr, [SP, #-0x10]!
    //     0xad13f0: mov             fp, SP
    // 0xad13f4: CheckStackOverflow
    //     0xad13f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad13f8: cmp             SP, x16
    //     0xad13fc: b.ls            #0xad1464
    // 0xad1400: r1 = Null
    //     0xad1400: mov             x1, NULL
    // 0xad1404: r2 = 8
    //     0xad1404: mov             x2, #8
    // 0xad1408: r0 = AllocateArray()
    //     0xad1408: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad140c: mov             x2, x0
    // 0xad1410: r17 = DBusUint16
    //     0xad1410: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] Type: DBusUint16
    //     0xad1414: ldr             x17, [x17, #0x260]
    // 0xad1418: StoreField: r2->field_f = r17
    //     0xad1418: stur            w17, [x2, #0xf]
    // 0xad141c: r17 = "("
    //     0xad141c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad1420: StoreField: r2->field_13 = r17
    //     0xad1420: stur            w17, [x2, #0x13]
    // 0xad1424: ldr             x0, [fp, #0x10]
    // 0xad1428: LoadField: r3 = r0->field_7
    //     0xad1428: ldur            x3, [x0, #7]
    // 0xad142c: r0 = BoxInt64Instr(r3)
    //     0xad142c: sbfiz           x0, x3, #1, #0x1f
    //     0xad1430: cmp             x3, x0, asr #1
    //     0xad1434: b.eq            #0xad1440
    //     0xad1438: bl              #0xd69bb8
    //     0xad143c: stur            x3, [x0, #7]
    // 0xad1440: StoreField: r2->field_17 = r0
    //     0xad1440: stur            w0, [x2, #0x17]
    // 0xad1444: r17 = ")"
    //     0xad1444: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad1448: StoreField: r2->field_1b = r17
    //     0xad1448: stur            w17, [x2, #0x1b]
    // 0xad144c: SaveReg r2
    //     0xad144c: str             x2, [SP, #-8]!
    // 0xad1450: r0 = _interpolate()
    //     0xad1450: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1454: add             SP, SP, #8
    // 0xad1458: LeaveFrame
    //     0xad1458: mov             SP, fp
    //     0xad145c: ldp             fp, lr, [SP], #0x10
    // 0xad1460: ret
    //     0xad1460: ret             
    // 0xad1464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1464: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1468: b               #0xad1400
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc634d8, size: 0x48
    // 0xc634d8: EnterFrame
    //     0xc634d8: stp             fp, lr, [SP, #-0x10]!
    //     0xc634dc: mov             fp, SP
    // 0xc634e0: AllocStack(0x8)
    //     0xc634e0: sub             SP, SP, #8
    // 0xc634e4: CheckStackOverflow
    //     0xc634e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc634e8: cmp             SP, x16
    //     0xc634ec: b.ls            #0xc63518
    // 0xc634f0: r0 = DBusSignature()
    //     0xc634f0: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc634f4: stur            x0, [fp, #-8]
    // 0xc634f8: r16 = "q"
    //     0xc634f8: ldr             x16, [PP, #0x78e8]  ; [pp+0x78e8] "q"
    // 0xc634fc: stp             x16, x0, [SP, #-0x10]!
    // 0xc63500: r0 = DBusSignature()
    //     0xc63500: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc63504: add             SP, SP, #0x10
    // 0xc63508: ldur            x0, [fp, #-8]
    // 0xc6350c: LeaveFrame
    //     0xc6350c: mov             SP, fp
    //     0xc63510: ldp             fp, lr, [SP], #0x10
    // 0xc63514: ret
    //     0xc63514: ret             
    // 0xc63518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc63518: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6351c: b               #0xc634f0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e7a8, size: 0x60
    // 0xc6e7a8: ldr             x1, [SP]
    // 0xc6e7ac: cmp             w1, NULL
    // 0xc6e7b0: b.ne            #0xc6e7bc
    // 0xc6e7b4: r0 = false
    //     0xc6e7b4: add             x0, NULL, #0x30  ; false
    // 0xc6e7b8: ret
    //     0xc6e7b8: ret             
    // 0xc6e7bc: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e7bc: mov             x2, #0x76
    //     0xc6e7c0: tbz             w1, #0, #0xc6e7d0
    //     0xc6e7c4: ldur            x2, [x1, #-1]
    //     0xc6e7c8: ubfx            x2, x2, #0xc, #0x14
    //     0xc6e7cc: lsl             x2, x2, #1
    // 0xc6e7d0: r17 = 9160
    //     0xc6e7d0: mov             x17, #0x23c8
    // 0xc6e7d4: cmp             w2, w17
    // 0xc6e7d8: b.ne            #0xc6e800
    // 0xc6e7dc: ldr             x2, [SP, #8]
    // 0xc6e7e0: LoadField: r3 = r1->field_7
    //     0xc6e7e0: ldur            x3, [x1, #7]
    // 0xc6e7e4: LoadField: r1 = r2->field_7
    //     0xc6e7e4: ldur            x1, [x2, #7]
    // 0xc6e7e8: cmp             x3, x1
    // 0xc6e7ec: r16 = true
    //     0xc6e7ec: add             x16, NULL, #0x20  ; true
    // 0xc6e7f0: r17 = false
    //     0xc6e7f0: add             x17, NULL, #0x30  ; false
    // 0xc6e7f4: csel            x2, x16, x17, eq
    // 0xc6e7f8: mov             x0, x2
    // 0xc6e7fc: b               #0xc6e804
    // 0xc6e800: r0 = false
    //     0xc6e800: add             x0, NULL, #0x30  ; false
    // 0xc6e804: ret
    //     0xc6e804: ret             
  }
}

// class id: 4581, size: 0x10, field offset: 0x8
//   const constructor, 
class DBusInt16 extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad136c, size: 0x80
    // 0xad136c: EnterFrame
    //     0xad136c: stp             fp, lr, [SP, #-0x10]!
    //     0xad1370: mov             fp, SP
    // 0xad1374: CheckStackOverflow
    //     0xad1374: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1378: cmp             SP, x16
    //     0xad137c: b.ls            #0xad13e4
    // 0xad1380: r1 = Null
    //     0xad1380: mov             x1, NULL
    // 0xad1384: r2 = 8
    //     0xad1384: mov             x2, #8
    // 0xad1388: r0 = AllocateArray()
    //     0xad1388: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad138c: mov             x2, x0
    // 0xad1390: r17 = DBusInt16
    //     0xad1390: add             x17, PP, #0xb, lsl #12  ; [pp+0xb268] Type: DBusInt16
    //     0xad1394: ldr             x17, [x17, #0x268]
    // 0xad1398: StoreField: r2->field_f = r17
    //     0xad1398: stur            w17, [x2, #0xf]
    // 0xad139c: r17 = "("
    //     0xad139c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad13a0: StoreField: r2->field_13 = r17
    //     0xad13a0: stur            w17, [x2, #0x13]
    // 0xad13a4: ldr             x0, [fp, #0x10]
    // 0xad13a8: LoadField: r3 = r0->field_7
    //     0xad13a8: ldur            x3, [x0, #7]
    // 0xad13ac: r0 = BoxInt64Instr(r3)
    //     0xad13ac: sbfiz           x0, x3, #1, #0x1f
    //     0xad13b0: cmp             x3, x0, asr #1
    //     0xad13b4: b.eq            #0xad13c0
    //     0xad13b8: bl              #0xd69bb8
    //     0xad13bc: stur            x3, [x0, #7]
    // 0xad13c0: StoreField: r2->field_17 = r0
    //     0xad13c0: stur            w0, [x2, #0x17]
    // 0xad13c4: r17 = ")"
    //     0xad13c4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad13c8: StoreField: r2->field_1b = r17
    //     0xad13c8: stur            w17, [x2, #0x1b]
    // 0xad13cc: SaveReg r2
    //     0xad13cc: str             x2, [SP, #-8]!
    // 0xad13d0: r0 = _interpolate()
    //     0xad13d0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad13d4: add             SP, SP, #8
    // 0xad13d8: LeaveFrame
    //     0xad13d8: mov             SP, fp
    //     0xad13dc: ldp             fp, lr, [SP], #0x10
    // 0xad13e0: ret
    //     0xad13e0: ret             
    // 0xad13e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad13e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad13e8: b               #0xad1380
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc63490, size: 0x48
    // 0xc63490: EnterFrame
    //     0xc63490: stp             fp, lr, [SP, #-0x10]!
    //     0xc63494: mov             fp, SP
    // 0xc63498: AllocStack(0x8)
    //     0xc63498: sub             SP, SP, #8
    // 0xc6349c: CheckStackOverflow
    //     0xc6349c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc634a0: cmp             SP, x16
    //     0xc634a4: b.ls            #0xc634d0
    // 0xc634a8: r0 = DBusSignature()
    //     0xc634a8: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc634ac: stur            x0, [fp, #-8]
    // 0xc634b0: r16 = "n"
    //     0xc634b0: ldr             x16, [PP, #0x78e0]  ; [pp+0x78e0] "n"
    // 0xc634b4: stp             x16, x0, [SP, #-0x10]!
    // 0xc634b8: r0 = DBusSignature()
    //     0xc634b8: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc634bc: add             SP, SP, #0x10
    // 0xc634c0: ldur            x0, [fp, #-8]
    // 0xc634c4: LeaveFrame
    //     0xc634c4: mov             SP, fp
    //     0xc634c8: ldp             fp, lr, [SP], #0x10
    // 0xc634cc: ret
    //     0xc634cc: ret             
    // 0xc634d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc634d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc634d4: b               #0xc634a8
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e748, size: 0x60
    // 0xc6e748: ldr             x1, [SP]
    // 0xc6e74c: cmp             w1, NULL
    // 0xc6e750: b.ne            #0xc6e75c
    // 0xc6e754: r0 = false
    //     0xc6e754: add             x0, NULL, #0x30  ; false
    // 0xc6e758: ret
    //     0xc6e758: ret             
    // 0xc6e75c: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e75c: mov             x2, #0x76
    //     0xc6e760: tbz             w1, #0, #0xc6e770
    //     0xc6e764: ldur            x2, [x1, #-1]
    //     0xc6e768: ubfx            x2, x2, #0xc, #0x14
    //     0xc6e76c: lsl             x2, x2, #1
    // 0xc6e770: r17 = 9162
    //     0xc6e770: mov             x17, #0x23ca
    // 0xc6e774: cmp             w2, w17
    // 0xc6e778: b.ne            #0xc6e7a0
    // 0xc6e77c: ldr             x2, [SP, #8]
    // 0xc6e780: LoadField: r3 = r1->field_7
    //     0xc6e780: ldur            x3, [x1, #7]
    // 0xc6e784: LoadField: r1 = r2->field_7
    //     0xc6e784: ldur            x1, [x2, #7]
    // 0xc6e788: cmp             x3, x1
    // 0xc6e78c: r16 = true
    //     0xc6e78c: add             x16, NULL, #0x20  ; true
    // 0xc6e790: r17 = false
    //     0xc6e790: add             x17, NULL, #0x30  ; false
    // 0xc6e794: csel            x2, x16, x17, eq
    // 0xc6e798: mov             x0, x2
    // 0xc6e79c: b               #0xc6e7a4
    // 0xc6e7a0: r0 = false
    //     0xc6e7a0: add             x0, NULL, #0x30  ; false
    // 0xc6e7a4: ret
    //     0xc6e7a4: ret             
  }
}

// class id: 4582, size: 0xc, field offset: 0x8
//   const constructor, 
class DBusBoolean extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad1300, size: 0x6c
    // 0xad1300: EnterFrame
    //     0xad1300: stp             fp, lr, [SP, #-0x10]!
    //     0xad1304: mov             fp, SP
    // 0xad1308: CheckStackOverflow
    //     0xad1308: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad130c: cmp             SP, x16
    //     0xad1310: b.ls            #0xad1364
    // 0xad1314: r1 = Null
    //     0xad1314: mov             x1, NULL
    // 0xad1318: r2 = 8
    //     0xad1318: mov             x2, #8
    // 0xad131c: r0 = AllocateArray()
    //     0xad131c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1320: r17 = DBusBoolean
    //     0xad1320: add             x17, PP, #0xb, lsl #12  ; [pp+0xb280] Type: DBusBoolean
    //     0xad1324: ldr             x17, [x17, #0x280]
    // 0xad1328: StoreField: r0->field_f = r17
    //     0xad1328: stur            w17, [x0, #0xf]
    // 0xad132c: r17 = "("
    //     0xad132c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad1330: StoreField: r0->field_13 = r17
    //     0xad1330: stur            w17, [x0, #0x13]
    // 0xad1334: ldr             x1, [fp, #0x10]
    // 0xad1338: LoadField: r2 = r1->field_7
    //     0xad1338: ldur            w2, [x1, #7]
    // 0xad133c: DecompressPointer r2
    //     0xad133c: add             x2, x2, HEAP, lsl #32
    // 0xad1340: StoreField: r0->field_17 = r2
    //     0xad1340: stur            w2, [x0, #0x17]
    // 0xad1344: r17 = ")"
    //     0xad1344: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad1348: StoreField: r0->field_1b = r17
    //     0xad1348: stur            w17, [x0, #0x1b]
    // 0xad134c: SaveReg r0
    //     0xad134c: str             x0, [SP, #-8]!
    // 0xad1350: r0 = _interpolate()
    //     0xad1350: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad1354: add             SP, SP, #8
    // 0xad1358: LeaveFrame
    //     0xad1358: mov             SP, fp
    //     0xad135c: ldp             fp, lr, [SP], #0x10
    // 0xad1360: ret
    //     0xad1360: ret             
    // 0xad1364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1364: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1368: b               #0xad1314
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafa7d4, size: 0x28
    // 0xafa7d4: ldr             x1, [SP]
    // 0xafa7d8: LoadField: r2 = r1->field_7
    //     0xafa7d8: ldur            w2, [x1, #7]
    // 0xafa7dc: DecompressPointer r2
    //     0xafa7dc: add             x2, x2, HEAP, lsl #32
    // 0xafa7e0: tst             x2, #0x10
    // 0xafa7e4: cset            x0, ne
    // 0xafa7e8: sub             x0, x0, #1
    // 0xafa7ec: r16 = -12
    //     0xafa7ec: mov             x16, #-0xc
    // 0xafa7f0: and             x0, x0, x16
    // 0xafa7f4: add             x0, x0, #0x9aa
    // 0xafa7f8: ret
    //     0xafa7f8: ret             
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc63448, size: 0x48
    // 0xc63448: EnterFrame
    //     0xc63448: stp             fp, lr, [SP, #-0x10]!
    //     0xc6344c: mov             fp, SP
    // 0xc63450: AllocStack(0x8)
    //     0xc63450: sub             SP, SP, #8
    // 0xc63454: CheckStackOverflow
    //     0xc63454: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63458: cmp             SP, x16
    //     0xc6345c: b.ls            #0xc63488
    // 0xc63460: r0 = DBusSignature()
    //     0xc63460: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc63464: stur            x0, [fp, #-8]
    // 0xc63468: r16 = "b"
    //     0xc63468: ldr             x16, [PP, #0x78d8]  ; [pp+0x78d8] "b"
    // 0xc6346c: stp             x16, x0, [SP, #-0x10]!
    // 0xc63470: r0 = DBusSignature()
    //     0xc63470: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc63474: add             SP, SP, #0x10
    // 0xc63478: ldur            x0, [fp, #-8]
    // 0xc6347c: LeaveFrame
    //     0xc6347c: mov             SP, fp
    //     0xc63480: ldp             fp, lr, [SP], #0x10
    // 0xc63484: ret
    //     0xc63484: ret             
    // 0xc63488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc63488: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6348c: b               #0xc63460
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e6e0, size: 0x68
    // 0xc6e6e0: ldr             x1, [SP]
    // 0xc6e6e4: cmp             w1, NULL
    // 0xc6e6e8: b.ne            #0xc6e6f4
    // 0xc6e6ec: r0 = false
    //     0xc6e6ec: add             x0, NULL, #0x30  ; false
    // 0xc6e6f0: ret
    //     0xc6e6f0: ret             
    // 0xc6e6f4: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e6f4: mov             x2, #0x76
    //     0xc6e6f8: tbz             w1, #0, #0xc6e708
    //     0xc6e6fc: ldur            x2, [x1, #-1]
    //     0xc6e700: ubfx            x2, x2, #0xc, #0x14
    //     0xc6e704: lsl             x2, x2, #1
    // 0xc6e708: r17 = 9164
    //     0xc6e708: mov             x17, #0x23cc
    // 0xc6e70c: cmp             w2, w17
    // 0xc6e710: b.ne            #0xc6e740
    // 0xc6e714: ldr             x2, [SP, #8]
    // 0xc6e718: LoadField: r3 = r1->field_7
    //     0xc6e718: ldur            w3, [x1, #7]
    // 0xc6e71c: DecompressPointer r3
    //     0xc6e71c: add             x3, x3, HEAP, lsl #32
    // 0xc6e720: LoadField: r1 = r2->field_7
    //     0xc6e720: ldur            w1, [x2, #7]
    // 0xc6e724: DecompressPointer r1
    //     0xc6e724: add             x1, x1, HEAP, lsl #32
    // 0xc6e728: cmp             w3, w1
    // 0xc6e72c: r16 = true
    //     0xc6e72c: add             x16, NULL, #0x20  ; true
    // 0xc6e730: r17 = false
    //     0xc6e730: add             x17, NULL, #0x30  ; false
    // 0xc6e734: csel            x2, x16, x17, eq
    // 0xc6e738: mov             x0, x2
    // 0xc6e73c: b               #0xc6e744
    // 0xc6e740: r0 = false
    //     0xc6e740: add             x0, NULL, #0x30  ; false
    // 0xc6e744: ret
    //     0xc6e744: ret             
  }
}

// class id: 4583, size: 0x10, field offset: 0x8
//   const constructor, 
class DBusByte extends DBusValue {

  _ toString(/* No info */) {
    // ** addr: 0xad1284, size: 0x7c
    // 0xad1284: EnterFrame
    //     0xad1284: stp             fp, lr, [SP, #-0x10]!
    //     0xad1288: mov             fp, SP
    // 0xad128c: CheckStackOverflow
    //     0xad128c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1290: cmp             SP, x16
    //     0xad1294: b.ls            #0xad12f8
    // 0xad1298: r1 = Null
    //     0xad1298: mov             x1, NULL
    // 0xad129c: r2 = 8
    //     0xad129c: mov             x2, #8
    // 0xad12a0: r0 = AllocateArray()
    //     0xad12a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad12a4: mov             x2, x0
    // 0xad12a8: r17 = DBusByte
    //     0xad12a8: ldr             x17, [PP, #0x7fa8]  ; [pp+0x7fa8] Type: DBusByte
    // 0xad12ac: StoreField: r2->field_f = r17
    //     0xad12ac: stur            w17, [x2, #0xf]
    // 0xad12b0: r17 = "("
    //     0xad12b0: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad12b4: StoreField: r2->field_13 = r17
    //     0xad12b4: stur            w17, [x2, #0x13]
    // 0xad12b8: ldr             x0, [fp, #0x10]
    // 0xad12bc: LoadField: r3 = r0->field_7
    //     0xad12bc: ldur            x3, [x0, #7]
    // 0xad12c0: r0 = BoxInt64Instr(r3)
    //     0xad12c0: sbfiz           x0, x3, #1, #0x1f
    //     0xad12c4: cmp             x3, x0, asr #1
    //     0xad12c8: b.eq            #0xad12d4
    //     0xad12cc: bl              #0xd69bb8
    //     0xad12d0: stur            x3, [x0, #7]
    // 0xad12d4: StoreField: r2->field_17 = r0
    //     0xad12d4: stur            w0, [x2, #0x17]
    // 0xad12d8: r17 = ")"
    //     0xad12d8: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad12dc: StoreField: r2->field_1b = r17
    //     0xad12dc: stur            w17, [x2, #0x1b]
    // 0xad12e0: SaveReg r2
    //     0xad12e0: str             x2, [SP, #-8]!
    // 0xad12e4: r0 = _interpolate()
    //     0xad12e4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad12e8: add             SP, SP, #8
    // 0xad12ec: LeaveFrame
    //     0xad12ec: mov             SP, fp
    //     0xad12f0: ldp             fp, lr, [SP], #0x10
    // 0xad12f4: ret
    //     0xad12f4: ret             
    // 0xad12f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad12f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad12fc: b               #0xad1298
  }
  get _ signature(/* No info */) {
    // ** addr: 0xc63400, size: 0x48
    // 0xc63400: EnterFrame
    //     0xc63400: stp             fp, lr, [SP, #-0x10]!
    //     0xc63404: mov             fp, SP
    // 0xc63408: AllocStack(0x8)
    //     0xc63408: sub             SP, SP, #8
    // 0xc6340c: CheckStackOverflow
    //     0xc6340c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc63410: cmp             SP, x16
    //     0xc63414: b.ls            #0xc63440
    // 0xc63418: r0 = DBusSignature()
    //     0xc63418: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc6341c: stur            x0, [fp, #-8]
    // 0xc63420: r16 = "y"
    //     0xc63420: ldr             x16, [PP, #0x78d0]  ; [pp+0x78d0] "y"
    // 0xc63424: stp             x16, x0, [SP, #-0x10]!
    // 0xc63428: r0 = DBusSignature()
    //     0xc63428: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc6342c: add             SP, SP, #0x10
    // 0xc63430: ldur            x0, [fp, #-8]
    // 0xc63434: LeaveFrame
    //     0xc63434: mov             SP, fp
    //     0xc63438: ldp             fp, lr, [SP], #0x10
    // 0xc6343c: ret
    //     0xc6343c: ret             
    // 0xc63440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc63440: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc63444: b               #0xc63418
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e680, size: 0x60
    // 0xc6e680: ldr             x1, [SP]
    // 0xc6e684: cmp             w1, NULL
    // 0xc6e688: b.ne            #0xc6e694
    // 0xc6e68c: r0 = false
    //     0xc6e68c: add             x0, NULL, #0x30  ; false
    // 0xc6e690: ret
    //     0xc6e690: ret             
    // 0xc6e694: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e694: mov             x2, #0x76
    //     0xc6e698: tbz             w1, #0, #0xc6e6a8
    //     0xc6e69c: ldur            x2, [x1, #-1]
    //     0xc6e6a0: ubfx            x2, x2, #0xc, #0x14
    //     0xc6e6a4: lsl             x2, x2, #1
    // 0xc6e6a8: r17 = 9166
    //     0xc6e6a8: mov             x17, #0x23ce
    // 0xc6e6ac: cmp             w2, w17
    // 0xc6e6b0: b.ne            #0xc6e6d8
    // 0xc6e6b4: ldr             x2, [SP, #8]
    // 0xc6e6b8: LoadField: r3 = r1->field_7
    //     0xc6e6b8: ldur            x3, [x1, #7]
    // 0xc6e6bc: LoadField: r1 = r2->field_7
    //     0xc6e6bc: ldur            x1, [x2, #7]
    // 0xc6e6c0: cmp             x3, x1
    // 0xc6e6c4: r16 = true
    //     0xc6e6c4: add             x16, NULL, #0x20  ; true
    // 0xc6e6c8: r17 = false
    //     0xc6e6c8: add             x17, NULL, #0x30  ; false
    // 0xc6e6cc: csel            x2, x16, x17, eq
    // 0xc6e6d0: mov             x0, x2
    // 0xc6e6d4: b               #0xc6e6dc
    // 0xc6e6d8: r0 = false
    //     0xc6e6d8: add             x0, NULL, #0x30  ; false
    // 0xc6e6dc: ret
    //     0xc6e6dc: ret             
  }
}

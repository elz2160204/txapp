// lib: , url: package:dbus/src/getsid_windows.dart

// class id: 1048857, size: 0x8
class :: {

  static String getsid() {
    // ** addr: 0xa0c9d4, size: 0x854
    // 0xa0c9d4: EnterFrame
    //     0xa0c9d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0c9d8: mov             fp, SP
    // 0xa0c9dc: AllocStack(0x48)
    //     0xa0c9dc: sub             SP, SP, #0x48
    // 0xa0c9e0: CheckStackOverflow
    //     0xa0c9e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0c9e4: cmp             SP, x16
    //     0xa0c9e8: b.ls            #0xa0d208
    // 0xa0c9ec: r0 = InitLateStaticField(0x694) // [dart:io] Platform::isWindows
    //     0xa0c9ec: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0c9f0: ldr             x0, [x0, #0xd28]
    //     0xa0c9f4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0c9f8: cmp             w0, w16
    //     0xa0c9fc: b.ne            #0xa0ca08
    //     0xa0ca00: ldr             x2, [PP, #0x80]  ; [pp+0x80] Field <Platform.isWindows>: static late final (offset: 0x694)
    //     0xa0ca04: bl              #0xd67cdc
    // 0xa0ca08: tbnz            w0, #4, #0xa0d008
    // 0xa0ca0c: r16 = "kernel32.dll"
    //     0xa0ca0c: ldr             x16, [PP, #0x6358]  ; [pp+0x6358] "kernel32.dll"
    // 0xa0ca10: SaveReg r16
    //     0xa0ca10: str             x16, [SP, #-8]!
    // 0xa0ca14: r0 = _open()
    //     0xa0ca14: bl              #0x930078  ; [dart:ffi] ::_open
    // 0xa0ca18: add             SP, SP, #8
    // 0xa0ca1c: stur            x0, [fp, #-8]
    // 0xa0ca20: r16 = <NativeFunction<(dynamic this) => IntPtr>>
    //     0xa0ca20: add             x16, PP, #8, lsl #12  ; [pp+0x8288] TypeArguments: <NativeFunction<(dynamic this) => IntPtr>>
    //     0xa0ca24: ldr             x16, [x16, #0x288]
    // 0xa0ca28: stp             x0, x16, [SP, #-0x10]!
    // 0xa0ca2c: r16 = "GetCurrentProcess"
    //     0xa0ca2c: add             x16, PP, #8, lsl #12  ; [pp+0x8290] "GetCurrentProcess"
    //     0xa0ca30: ldr             x16, [x16, #0x290]
    // 0xa0ca34: SaveReg r16
    //     0xa0ca34: str             x16, [SP, #-8]!
    // 0xa0ca38: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0ca38: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0ca3c: r0 = lookup()
    //     0xa0ca3c: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0xa0ca40: add             SP, SP, #0x18
    // 0xa0ca44: stur            x0, [fp, #-0x10]
    // 0xa0ca48: r1 = 1
    //     0xa0ca48: mov             x1, #1
    // 0xa0ca4c: r0 = AllocateContext()
    //     0xa0ca4c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa0ca50: mov             x1, x0
    // 0xa0ca54: ldur            x0, [fp, #-0x10]
    // 0xa0ca58: StoreField: r1->field_f = r0
    //     0xa0ca58: stur            w0, [x1, #0xf]
    // 0xa0ca5c: mov             x2, x1
    // 0xa0ca60: r1 = Function 'FfiTrampoline_getsid': static ffi-trampoline-function.
    //     0xa0ca60: add             x1, PP, #8, lsl #12  ; [pp+0x8298] Function: [dart:ffi] ::FfiTrampoline____getRootIsolateToken$Method$FfiNative$Ptr (0x5022fc)
    //     0xa0ca64: ldr             x1, [x1, #0x298]
    // 0xa0ca68: r0 = AllocateClosure()
    //     0xa0ca68: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0ca6c: stur            x0, [fp, #-0x10]
    // 0xa0ca70: r16 = <NativeFunction<(dynamic this, IntPtr) => Int32>>
    //     0xa0ca70: add             x16, PP, #8, lsl #12  ; [pp+0x82a0] TypeArguments: <NativeFunction<(dynamic this, IntPtr) => Int32>>
    //     0xa0ca74: ldr             x16, [x16, #0x2a0]
    // 0xa0ca78: ldur            lr, [fp, #-8]
    // 0xa0ca7c: stp             lr, x16, [SP, #-0x10]!
    // 0xa0ca80: r16 = "CloseHandle"
    //     0xa0ca80: add             x16, PP, #8, lsl #12  ; [pp+0x82a8] "CloseHandle"
    //     0xa0ca84: ldr             x16, [x16, #0x2a8]
    // 0xa0ca88: SaveReg r16
    //     0xa0ca88: str             x16, [SP, #-8]!
    // 0xa0ca8c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0ca8c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0ca90: r0 = lookup()
    //     0xa0ca90: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0xa0ca94: add             SP, SP, #0x18
    // 0xa0ca98: stur            x0, [fp, #-0x18]
    // 0xa0ca9c: r1 = 1
    //     0xa0ca9c: mov             x1, #1
    // 0xa0caa0: r0 = AllocateContext()
    //     0xa0caa0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa0caa4: mov             x1, x0
    // 0xa0caa8: ldur            x0, [fp, #-0x18]
    // 0xa0caac: StoreField: r1->field_f = r0
    //     0xa0caac: stur            w0, [x1, #0xf]
    // 0xa0cab0: mov             x2, x1
    // 0xa0cab4: r1 = Function 'FfiTrampoline_getsid': static ffi-trampoline-function.
    //     0xa0cab4: add             x1, PP, #8, lsl #12  ; [pp+0x82b0] Function: [dart:ffi] ::FfiTrampoline_getsid (0x701b14)
    //     0xa0cab8: ldr             x1, [x1, #0x2b0]
    // 0xa0cabc: r0 = AllocateClosure()
    //     0xa0cabc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0cac0: stur            x0, [fp, #-0x18]
    // 0xa0cac4: r16 = <NativeFunction<(dynamic this) => Uint32>>
    //     0xa0cac4: add             x16, PP, #8, lsl #12  ; [pp+0x82b8] TypeArguments: <NativeFunction<(dynamic this) => Uint32>>
    //     0xa0cac8: ldr             x16, [x16, #0x2b8]
    // 0xa0cacc: ldur            lr, [fp, #-8]
    // 0xa0cad0: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cad4: r16 = "GetLastError"
    //     0xa0cad4: add             x16, PP, #8, lsl #12  ; [pp+0x82c0] "GetLastError"
    //     0xa0cad8: ldr             x16, [x16, #0x2c0]
    // 0xa0cadc: SaveReg r16
    //     0xa0cadc: str             x16, [SP, #-8]!
    // 0xa0cae0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0cae0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0cae4: r0 = lookup()
    //     0xa0cae4: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0xa0cae8: add             SP, SP, #0x18
    // 0xa0caec: stur            x0, [fp, #-0x20]
    // 0xa0caf0: r1 = 1
    //     0xa0caf0: mov             x1, #1
    // 0xa0caf4: r0 = AllocateContext()
    //     0xa0caf4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa0caf8: mov             x1, x0
    // 0xa0cafc: ldur            x0, [fp, #-0x20]
    // 0xa0cb00: StoreField: r1->field_f = r0
    //     0xa0cb00: stur            w0, [x1, #0xf]
    // 0xa0cb04: mov             x2, x1
    // 0xa0cb08: r1 = Function 'FfiTrampoline_getsid': static ffi-trampoline-function.
    //     0xa0cb08: add             x1, PP, #8, lsl #12  ; [pp+0x82c8] Function: [dart:ffi] ::FfiTrampoline_getsid (0x92d5c8)
    //     0xa0cb0c: ldr             x1, [x1, #0x2c8]
    // 0xa0cb10: r0 = AllocateClosure()
    //     0xa0cb10: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0cb14: stur            x0, [fp, #-0x20]
    // 0xa0cb18: r16 = <NativeFunction<(dynamic this, IntPtr) => IntPtr>>
    //     0xa0cb18: add             x16, PP, #8, lsl #12  ; [pp+0x82d0] TypeArguments: <NativeFunction<(dynamic this, IntPtr) => IntPtr>>
    //     0xa0cb1c: ldr             x16, [x16, #0x2d0]
    // 0xa0cb20: ldur            lr, [fp, #-8]
    // 0xa0cb24: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cb28: r16 = "LocalFree"
    //     0xa0cb28: add             x16, PP, #8, lsl #12  ; [pp+0x82d8] "LocalFree"
    //     0xa0cb2c: ldr             x16, [x16, #0x2d8]
    // 0xa0cb30: SaveReg r16
    //     0xa0cb30: str             x16, [SP, #-8]!
    // 0xa0cb34: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0cb34: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0cb38: r0 = lookup()
    //     0xa0cb38: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0xa0cb3c: add             SP, SP, #0x18
    // 0xa0cb40: stur            x0, [fp, #-8]
    // 0xa0cb44: r1 = 1
    //     0xa0cb44: mov             x1, #1
    // 0xa0cb48: r0 = AllocateContext()
    //     0xa0cb48: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa0cb4c: mov             x1, x0
    // 0xa0cb50: ldur            x0, [fp, #-8]
    // 0xa0cb54: StoreField: r1->field_f = r0
    //     0xa0cb54: stur            w0, [x1, #0xf]
    // 0xa0cb58: mov             x2, x1
    // 0xa0cb5c: r1 = Function 'FfiTrampoline_getsid': static ffi-trampoline-function.
    //     0xa0cb5c: add             x1, PP, #8, lsl #12  ; [pp+0x82e0] Function: [dart:ffi] ::FfiTrampoline_getsid (0xa0d804)
    //     0xa0cb60: ldr             x1, [x1, #0x2e0]
    // 0xa0cb64: r0 = AllocateClosure()
    //     0xa0cb64: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0cb68: stur            x0, [fp, #-8]
    // 0xa0cb6c: r16 = "advapi32.dll"
    //     0xa0cb6c: add             x16, PP, #8, lsl #12  ; [pp+0x82e8] "advapi32.dll"
    //     0xa0cb70: ldr             x16, [x16, #0x2e8]
    // 0xa0cb74: SaveReg r16
    //     0xa0cb74: str             x16, [SP, #-8]!
    // 0xa0cb78: r0 = _open()
    //     0xa0cb78: bl              #0x930078  ; [dart:ffi] ::_open
    // 0xa0cb7c: add             SP, SP, #8
    // 0xa0cb80: stur            x0, [fp, #-0x28]
    // 0xa0cb84: r16 = <NativeFunction<(dynamic this, IntPtr, Uint32, Pointer<IntPtr>) => Int32>>
    //     0xa0cb84: add             x16, PP, #8, lsl #12  ; [pp+0x82f0] TypeArguments: <NativeFunction<(dynamic this, IntPtr, Uint32, Pointer<IntPtr>) => Int32>>
    //     0xa0cb88: ldr             x16, [x16, #0x2f0]
    // 0xa0cb8c: stp             x0, x16, [SP, #-0x10]!
    // 0xa0cb90: r16 = "OpenProcessToken"
    //     0xa0cb90: add             x16, PP, #8, lsl #12  ; [pp+0x82f8] "OpenProcessToken"
    //     0xa0cb94: ldr             x16, [x16, #0x2f8]
    // 0xa0cb98: SaveReg r16
    //     0xa0cb98: str             x16, [SP, #-8]!
    // 0xa0cb9c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0cb9c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0cba0: r0 = lookup()
    //     0xa0cba0: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0xa0cba4: add             SP, SP, #0x18
    // 0xa0cba8: stur            x0, [fp, #-0x30]
    // 0xa0cbac: r1 = 1
    //     0xa0cbac: mov             x1, #1
    // 0xa0cbb0: r0 = AllocateContext()
    //     0xa0cbb0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa0cbb4: mov             x1, x0
    // 0xa0cbb8: ldur            x0, [fp, #-0x30]
    // 0xa0cbbc: StoreField: r1->field_f = r0
    //     0xa0cbbc: stur            w0, [x1, #0xf]
    // 0xa0cbc0: mov             x2, x1
    // 0xa0cbc4: r1 = Function 'FfiTrampoline_getsid': static ffi-trampoline-function.
    //     0xa0cbc4: add             x1, PP, #8, lsl #12  ; [pp+0x8300] Function: [dart:ffi] ::FfiTrampoline_getsid (0xa0d6c0)
    //     0xa0cbc8: ldr             x1, [x1, #0x300]
    // 0xa0cbcc: r0 = AllocateClosure()
    //     0xa0cbcc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0cbd0: stur            x0, [fp, #-0x30]
    // 0xa0cbd4: r16 = <NativeFunction<(dynamic this, IntPtr, Uint32, Pointer<NativeType>, Uint32, Pointer<Uint32>) => Int32>>
    //     0xa0cbd4: add             x16, PP, #8, lsl #12  ; [pp+0x8308] TypeArguments: <NativeFunction<(dynamic this, IntPtr, Uint32, Pointer<NativeType>, Uint32, Pointer<Uint32>) => Int32>>
    //     0xa0cbd8: ldr             x16, [x16, #0x308]
    // 0xa0cbdc: ldur            lr, [fp, #-0x28]
    // 0xa0cbe0: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cbe4: r16 = "GetTokenInformation"
    //     0xa0cbe4: add             x16, PP, #8, lsl #12  ; [pp+0x8310] "GetTokenInformation"
    //     0xa0cbe8: ldr             x16, [x16, #0x310]
    // 0xa0cbec: SaveReg r16
    //     0xa0cbec: str             x16, [SP, #-8]!
    // 0xa0cbf0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0cbf0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0cbf4: r0 = lookup()
    //     0xa0cbf4: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0xa0cbf8: add             SP, SP, #0x18
    // 0xa0cbfc: stur            x0, [fp, #-0x38]
    // 0xa0cc00: r1 = 1
    //     0xa0cc00: mov             x1, #1
    // 0xa0cc04: r0 = AllocateContext()
    //     0xa0cc04: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa0cc08: mov             x1, x0
    // 0xa0cc0c: ldur            x0, [fp, #-0x38]
    // 0xa0cc10: StoreField: r1->field_f = r0
    //     0xa0cc10: stur            w0, [x1, #0xf]
    // 0xa0cc14: mov             x2, x1
    // 0xa0cc18: r1 = Function 'FfiTrampoline_getsid': static ffi-trampoline-function.
    //     0xa0cc18: add             x1, PP, #8, lsl #12  ; [pp+0x8318] Function: [dart:ffi] ::FfiTrampoline_getsid (0xa0d534)
    //     0xa0cc1c: ldr             x1, [x1, #0x318]
    // 0xa0cc20: r0 = AllocateClosure()
    //     0xa0cc20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0cc24: stur            x0, [fp, #-0x38]
    // 0xa0cc28: r16 = <NativeFunction<(dynamic this, Pointer<Void>, Pointer<Pointer<Utf8>>) => Int32>>
    //     0xa0cc28: add             x16, PP, #8, lsl #12  ; [pp+0x8320] TypeArguments: <NativeFunction<(dynamic this, Pointer<Void>, Pointer<Pointer<Utf8>>) => Int32>>
    //     0xa0cc2c: ldr             x16, [x16, #0x320]
    // 0xa0cc30: ldur            lr, [fp, #-0x28]
    // 0xa0cc34: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cc38: r16 = "ConvertSidToStringSidA"
    //     0xa0cc38: add             x16, PP, #8, lsl #12  ; [pp+0x8328] "ConvertSidToStringSidA"
    //     0xa0cc3c: ldr             x16, [x16, #0x328]
    // 0xa0cc40: SaveReg r16
    //     0xa0cc40: str             x16, [SP, #-8]!
    // 0xa0cc44: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0cc44: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0cc48: r0 = lookup()
    //     0xa0cc48: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0xa0cc4c: add             SP, SP, #0x18
    // 0xa0cc50: stur            x0, [fp, #-0x28]
    // 0xa0cc54: r1 = 1
    //     0xa0cc54: mov             x1, #1
    // 0xa0cc58: r0 = AllocateContext()
    //     0xa0cc58: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa0cc5c: mov             x1, x0
    // 0xa0cc60: ldur            x0, [fp, #-0x28]
    // 0xa0cc64: StoreField: r1->field_f = r0
    //     0xa0cc64: stur            w0, [x1, #0xf]
    // 0xa0cc68: mov             x2, x1
    // 0xa0cc6c: r1 = Function 'FfiTrampoline_getsid': static ffi-trampoline-function.
    //     0xa0cc6c: add             x1, PP, #8, lsl #12  ; [pp+0x8330] Function: [dart:ffi] ::FfiTrampoline_getsid (0x92da6c)
    //     0xa0cc70: ldr             x1, [x1, #0x330]
    // 0xa0cc74: r0 = AllocateClosure()
    //     0xa0cc74: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0cc78: stur            x0, [fp, #-0x28]
    // 0xa0cc7c: r16 = <IntPtr>
    //     0xa0cc7c: add             x16, PP, #8, lsl #12  ; [pp+0x8338] TypeArguments: <IntPtr>
    //     0xa0cc80: ldr             x16, [x16, #0x338]
    // 0xa0cc84: r30 = Instance__CallocAllocator
    //     0xa0cc84: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0xa0cc88: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cc8c: r1 = 8
    //     0xa0cc8c: mov             x1, #8
    // 0xa0cc90: SaveReg r1
    //     0xa0cc90: str             x1, [SP, #-8]!
    // 0xa0cc94: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0cc94: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0cc98: r0 = allocate()
    //     0xa0cc98: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0xa0cc9c: add             SP, SP, #0x18
    // 0xa0cca0: mov             x1, x0
    // 0xa0cca4: stur            x1, [fp, #-0x40]
    // 0xa0cca8: ldur            x16, [fp, #-0x10]
    // 0xa0ccac: SaveReg r16
    //     0xa0ccac: str             x16, [SP, #-8]!
    // 0xa0ccb0: ldur            x0, [fp, #-0x10]
    // 0xa0ccb4: ClosureCall
    //     0xa0ccb4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xa0ccb8: ldur            x2, [x0, #0x1f]
    //     0xa0ccbc: blr             x2
    // 0xa0ccc0: add             SP, SP, #8
    // 0xa0ccc4: ldur            x16, [fp, #-0x30]
    // 0xa0ccc8: stp             x0, x16, [SP, #-0x10]!
    // 0xa0cccc: r16 = 16
    //     0xa0cccc: mov             x16, #0x10
    // 0xa0ccd0: ldur            lr, [fp, #-0x40]
    // 0xa0ccd4: stp             lr, x16, [SP, #-0x10]!
    // 0xa0ccd8: ldur            x0, [fp, #-0x30]
    // 0xa0ccdc: ClosureCall
    //     0xa0ccdc: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xa0cce0: ldur            x2, [x0, #0x1f]
    //     0xa0cce4: blr             x2
    // 0xa0cce8: add             SP, SP, #0x20
    // 0xa0ccec: cbz             w0, #0xa0d018
    // 0xa0ccf0: ldur            x2, [fp, #-0x40]
    // 0xa0ccf4: LoadField: r0 = r2->field_7
    //     0xa0ccf4: ldur            x0, [x2, #7]
    // 0xa0ccf8: ldr             x3, [x0]
    // 0xa0ccfc: r0 = BoxInt64Instr(r3)
    //     0xa0ccfc: sbfiz           x0, x3, #1, #0x1f
    //     0xa0cd00: cmp             x3, x0, asr #1
    //     0xa0cd04: b.eq            #0xa0cd10
    //     0xa0cd08: bl              #0xd69bb8
    //     0xa0cd0c: stur            x3, [x0, #7]
    // 0xa0cd10: stur            x0, [fp, #-0x10]
    // 0xa0cd14: r16 = Instance__CallocAllocator
    //     0xa0cd14: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0xa0cd18: stp             x2, x16, [SP, #-0x10]!
    // 0xa0cd1c: r0 = free()
    //     0xa0cd1c: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0xa0cd20: add             SP, SP, #0x10
    // 0xa0cd24: r16 = <Uint32>
    //     0xa0cd24: add             x16, PP, #8, lsl #12  ; [pp+0x8340] TypeArguments: <Uint32>
    //     0xa0cd28: ldr             x16, [x16, #0x340]
    // 0xa0cd2c: r30 = Instance__CallocAllocator
    //     0xa0cd2c: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0xa0cd30: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cd34: r0 = 4
    //     0xa0cd34: mov             x0, #4
    // 0xa0cd38: SaveReg r0
    //     0xa0cd38: str             x0, [SP, #-8]!
    // 0xa0cd3c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0cd3c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0cd40: r0 = allocate()
    //     0xa0cd40: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0xa0cd44: add             SP, SP, #0x18
    // 0xa0cd48: stur            x0, [fp, #-0x30]
    // 0xa0cd4c: r0 = InitLateStaticField(0x2d8) // [dart:ffi] ::nullptr
    //     0xa0cd4c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0cd50: ldr             x0, [x0, #0x5b0]
    //     0xa0cd54: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0cd58: cmp             w0, w16
    //     0xa0cd5c: b.ne            #0xa0cd68
    //     0xa0cd60: ldr             x2, [PP, #0x63c8]  ; [pp+0x63c8] Field <::.nullptr>: static late final (offset: 0x2d8)
    //     0xa0cd64: bl              #0xd67cdc
    // 0xa0cd68: ldur            x16, [fp, #-0x38]
    // 0xa0cd6c: ldur            lr, [fp, #-0x10]
    // 0xa0cd70: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cd74: r16 = 2
    //     0xa0cd74: mov             x16, #2
    // 0xa0cd78: stp             x0, x16, [SP, #-0x10]!
    // 0xa0cd7c: ldur            x16, [fp, #-0x30]
    // 0xa0cd80: stp             x16, xzr, [SP, #-0x10]!
    // 0xa0cd84: ldur            x0, [fp, #-0x38]
    // 0xa0cd88: ClosureCall
    //     0xa0cd88: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    //     0xa0cd8c: ldur            x2, [x0, #0x1f]
    //     0xa0cd90: blr             x2
    // 0xa0cd94: add             SP, SP, #0x30
    // 0xa0cd98: cbnz            w0, #0xa0cdc0
    // 0xa0cd9c: ldur            x16, [fp, #-0x20]
    // 0xa0cda0: SaveReg r16
    //     0xa0cda0: str             x16, [SP, #-8]!
    // 0xa0cda4: ldur            x0, [fp, #-0x20]
    // 0xa0cda8: ClosureCall
    //     0xa0cda8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xa0cdac: ldur            x2, [x0, #0x1f]
    //     0xa0cdb0: blr             x2
    // 0xa0cdb4: add             SP, SP, #8
    // 0xa0cdb8: cmp             w0, #0xf4
    // 0xa0cdbc: b.ne            #0xa0d094
    // 0xa0cdc0: ldur            x0, [fp, #-0x30]
    // 0xa0cdc4: LoadField: r1 = r0->field_7
    //     0xa0cdc4: ldur            x1, [x0, #7]
    // 0xa0cdc8: ldr             w2, [x1]
    // 0xa0cdcc: ubfx            x2, x2, #0, #0x20
    // 0xa0cdd0: r16 = <_TokenUser>
    //     0xa0cdd0: add             x16, PP, #8, lsl #12  ; [pp+0x8348] TypeArguments: <_TokenUser>
    //     0xa0cdd4: ldr             x16, [x16, #0x348]
    // 0xa0cdd8: r30 = Instance__CallocAllocator
    //     0xa0cdd8: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0xa0cddc: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cde0: SaveReg r2
    //     0xa0cde0: str             x2, [SP, #-8]!
    // 0xa0cde4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0cde4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0cde8: r0 = allocate()
    //     0xa0cde8: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0xa0cdec: add             SP, SP, #0x18
    // 0xa0cdf0: mov             x2, x0
    // 0xa0cdf4: ldur            x1, [fp, #-0x30]
    // 0xa0cdf8: stur            x2, [fp, #-0x40]
    // 0xa0cdfc: LoadField: r0 = r1->field_7
    //     0xa0cdfc: ldur            x0, [x1, #7]
    // 0xa0ce00: ldr             w3, [x0]
    // 0xa0ce04: lsl             w0, w3, #1
    // 0xa0ce08: tst             x3, #0xc0000000
    // 0xa0ce0c: b.eq            #0xa0ce3c
    // 0xa0ce10: r0 = inline_Allocate_Mint()
    //     0xa0ce10: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xa0ce14: add             x0, x0, #0x10
    //     0xa0ce18: cmp             x4, x0
    //     0xa0ce1c: b.ls            #0xa0d210
    //     0xa0ce20: str             x0, [THR, #0x60]  ; THR::top
    //     0xa0ce24: sub             x0, x0, #0xf
    //     0xa0ce28: mov             x4, #0xc108
    //     0xa0ce2c: movk            x4, #3, lsl #16
    //     0xa0ce30: stur            x4, [x0, #-1]
    // 0xa0ce34: ubfx            x4, x3, #0, #0x20
    // 0xa0ce38: StoreField: r0->field_7 = r4
    //     0xa0ce38: stur            x4, [x0, #7]
    // 0xa0ce3c: ldur            x16, [fp, #-0x38]
    // 0xa0ce40: ldur            lr, [fp, #-0x10]
    // 0xa0ce44: stp             lr, x16, [SP, #-0x10]!
    // 0xa0ce48: r16 = 2
    //     0xa0ce48: mov             x16, #2
    // 0xa0ce4c: stp             x2, x16, [SP, #-0x10]!
    // 0xa0ce50: stp             x1, x0, [SP, #-0x10]!
    // 0xa0ce54: ldur            x0, [fp, #-0x38]
    // 0xa0ce58: ClosureCall
    //     0xa0ce58: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    //     0xa0ce5c: ldur            x2, [x0, #0x1f]
    //     0xa0ce60: blr             x2
    // 0xa0ce64: add             SP, SP, #0x30
    // 0xa0ce68: cbz             w0, #0xa0d110
    // 0xa0ce6c: ldur            x0, [fp, #-0x40]
    // 0xa0ce70: r16 = Instance__CallocAllocator
    //     0xa0ce70: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0xa0ce74: ldur            lr, [fp, #-0x30]
    // 0xa0ce78: stp             lr, x16, [SP, #-0x10]!
    // 0xa0ce7c: r0 = free()
    //     0xa0ce7c: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0xa0ce80: add             SP, SP, #0x10
    // 0xa0ce84: r16 = <Pointer<Utf8>>
    //     0xa0ce84: add             x16, PP, #8, lsl #12  ; [pp+0x8350] TypeArguments: <Pointer<Utf8>>
    //     0xa0ce88: ldr             x16, [x16, #0x350]
    // 0xa0ce8c: r30 = Instance__CallocAllocator
    //     0xa0ce8c: ldr             lr, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0xa0ce90: stp             lr, x16, [SP, #-0x10]!
    // 0xa0ce94: r0 = 8
    //     0xa0ce94: mov             x0, #8
    // 0xa0ce98: SaveReg r0
    //     0xa0ce98: str             x0, [SP, #-8]!
    // 0xa0ce9c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0ce9c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0cea0: r0 = allocate()
    //     0xa0cea0: bl              #0x92dc14  ; [package:ffi/src/allocation.dart] _CallocAllocator::allocate
    // 0xa0cea4: add             SP, SP, #0x18
    // 0xa0cea8: stur            x0, [fp, #-0x30]
    // 0xa0ceac: r0 = _TokenUser()
    //     0xa0ceac: bl              #0xa0d528  ; Allocate_TokenUserStub -> _TokenUser (size=0xc)
    // 0xa0ceb0: mov             x1, x0
    // 0xa0ceb4: ldur            x0, [fp, #-0x40]
    // 0xa0ceb8: StoreField: r1->field_7 = r0
    //     0xa0ceb8: stur            w0, [x1, #7]
    // 0xa0cebc: SaveReg r1
    //     0xa0cebc: str             x1, [SP, #-8]!
    // 0xa0cec0: r0 = user()
    //     0xa0cec0: bl              #0xa0d49c  ; [package:dbus/src/getsid_windows.dart] _TokenUser::user
    // 0xa0cec4: add             SP, SP, #8
    // 0xa0cec8: LoadField: r1 = r0->field_7
    //     0xa0cec8: ldur            w1, [x0, #7]
    // 0xa0cecc: DecompressPointer r1
    //     0xa0cecc: add             x1, x1, HEAP, lsl #32
    // 0xa0ced0: LoadField: r0 = r1->field_7
    //     0xa0ced0: ldur            x0, [x1, #7]
    // 0xa0ced4: ldr             x2, [x0]
    // 0xa0ced8: stur            x2, [fp, #-0x48]
    // 0xa0cedc: r1 = <Never>
    //     0xa0cedc: ldr             x1, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    // 0xa0cee0: r0 = Pointer()
    //     0xa0cee0: bl              #0x4ba128  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xa0cee4: mov             x1, x0
    // 0xa0cee8: ldur            x0, [fp, #-0x48]
    // 0xa0ceec: StoreField: r1->field_7 = r0
    //     0xa0ceec: stur            x0, [x1, #7]
    // 0xa0cef0: ldur            x16, [fp, #-0x28]
    // 0xa0cef4: stp             x1, x16, [SP, #-0x10]!
    // 0xa0cef8: ldur            x16, [fp, #-0x30]
    // 0xa0cefc: SaveReg r16
    //     0xa0cefc: str             x16, [SP, #-8]!
    // 0xa0cf00: ldur            x0, [fp, #-0x28]
    // 0xa0cf04: ClosureCall
    //     0xa0cf04: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xa0cf08: ldur            x2, [x0, #0x1f]
    //     0xa0cf0c: blr             x2
    // 0xa0cf10: add             SP, SP, #0x18
    // 0xa0cf14: cbz             w0, #0xa0d18c
    // 0xa0cf18: ldur            x0, [fp, #-0x30]
    // 0xa0cf1c: LoadField: r1 = r0->field_7
    //     0xa0cf1c: ldur            x1, [x0, #7]
    // 0xa0cf20: ldr             x2, [x1]
    // 0xa0cf24: stur            x2, [fp, #-0x48]
    // 0xa0cf28: r1 = <Never>
    //     0xa0cf28: ldr             x1, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    // 0xa0cf2c: r0 = Pointer()
    //     0xa0cf2c: bl              #0x4ba128  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xa0cf30: mov             x1, x0
    // 0xa0cf34: ldur            x0, [fp, #-0x48]
    // 0xa0cf38: StoreField: r1->field_7 = r0
    //     0xa0cf38: stur            x0, [x1, #7]
    // 0xa0cf3c: SaveReg r1
    //     0xa0cf3c: str             x1, [SP, #-8]!
    // 0xa0cf40: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0cf40: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0cf44: r0 = Utf8Pointer.toDartString()
    //     0xa0cf44: bl              #0xa0d228  ; [package:ffi/src/utf8.dart] ::Utf8Pointer.toDartString
    // 0xa0cf48: add             SP, SP, #8
    // 0xa0cf4c: mov             x2, x0
    // 0xa0cf50: ldur            x0, [fp, #-0x30]
    // 0xa0cf54: stur            x2, [fp, #-0x20]
    // 0xa0cf58: LoadField: r1 = r0->field_7
    //     0xa0cf58: ldur            x1, [x0, #7]
    // 0xa0cf5c: ldr             x3, [x1]
    // 0xa0cf60: stur            x3, [fp, #-0x48]
    // 0xa0cf64: r1 = <Never>
    //     0xa0cf64: ldr             x1, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    // 0xa0cf68: r0 = Pointer()
    //     0xa0cf68: bl              #0x4ba128  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xa0cf6c: mov             x1, x0
    // 0xa0cf70: ldur            x0, [fp, #-0x48]
    // 0xa0cf74: StoreField: r1->field_7 = r0
    //     0xa0cf74: stur            x0, [x1, #7]
    // 0xa0cf78: LoadField: r0 = r1->field_7
    //     0xa0cf78: ldur            x0, [x1, #7]
    // 0xa0cf7c: mov             x2, x0
    // 0xa0cf80: r0 = BoxInt64Instr(r2)
    //     0xa0cf80: sbfiz           x0, x2, #1, #0x1f
    //     0xa0cf84: cmp             x2, x0, asr #1
    //     0xa0cf88: b.eq            #0xa0cf94
    //     0xa0cf8c: bl              #0xd69bb8
    //     0xa0cf90: stur            x2, [x0, #7]
    // 0xa0cf94: ldur            x16, [fp, #-8]
    // 0xa0cf98: stp             x0, x16, [SP, #-0x10]!
    // 0xa0cf9c: ldur            x0, [fp, #-8]
    // 0xa0cfa0: ClosureCall
    //     0xa0cfa0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xa0cfa4: ldur            x2, [x0, #0x1f]
    //     0xa0cfa8: blr             x2
    // 0xa0cfac: add             SP, SP, #0x10
    // 0xa0cfb0: r16 = Instance__CallocAllocator
    //     0xa0cfb0: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0xa0cfb4: ldur            lr, [fp, #-0x40]
    // 0xa0cfb8: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cfbc: r0 = free()
    //     0xa0cfbc: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0xa0cfc0: add             SP, SP, #0x10
    // 0xa0cfc4: r16 = Instance__CallocAllocator
    //     0xa0cfc4: ldr             x16, [PP, #0x63a0]  ; [pp+0x63a0] Obj!_CallocAllocator@b4fcf1
    // 0xa0cfc8: ldur            lr, [fp, #-0x30]
    // 0xa0cfcc: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cfd0: r0 = free()
    //     0xa0cfd0: bl              #0x92cd04  ; [package:ffi/src/allocation.dart] _CallocAllocator::free
    // 0xa0cfd4: add             SP, SP, #0x10
    // 0xa0cfd8: ldur            x16, [fp, #-0x18]
    // 0xa0cfdc: ldur            lr, [fp, #-0x10]
    // 0xa0cfe0: stp             lr, x16, [SP, #-0x10]!
    // 0xa0cfe4: ldur            x0, [fp, #-0x18]
    // 0xa0cfe8: ClosureCall
    //     0xa0cfe8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xa0cfec: ldur            x2, [x0, #0x1f]
    //     0xa0cff0: blr             x2
    // 0xa0cff4: add             SP, SP, #0x10
    // 0xa0cff8: ldur            x0, [fp, #-0x20]
    // 0xa0cffc: LeaveFrame
    //     0xa0cffc: mov             SP, fp
    //     0xa0d000: ldp             fp, lr, [SP], #0x10
    // 0xa0d004: ret
    //     0xa0d004: ret             
    // 0xa0d008: r0 = "Unable to determine SID on this system"
    //     0xa0d008: add             x0, PP, #8, lsl #12  ; [pp+0x8358] "Unable to determine SID on this system"
    //     0xa0d00c: ldr             x0, [x0, #0x358]
    // 0xa0d010: r0 = Throw()
    //     0xa0d010: bl              #0xd67e38  ; ThrowStub
    // 0xa0d014: brk             #0
    // 0xa0d018: r1 = Null
    //     0xa0d018: mov             x1, NULL
    // 0xa0d01c: r2 = 4
    //     0xa0d01c: mov             x2, #4
    // 0xa0d020: r0 = AllocateArray()
    //     0xa0d020: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0d024: mov             x1, x0
    // 0xa0d028: stur            x1, [fp, #-0x10]
    // 0xa0d02c: r17 = "Failed to call OpenProcessToken: "
    //     0xa0d02c: add             x17, PP, #8, lsl #12  ; [pp+0x8360] "Failed to call OpenProcessToken: "
    //     0xa0d030: ldr             x17, [x17, #0x360]
    // 0xa0d034: StoreField: r1->field_f = r17
    //     0xa0d034: stur            w17, [x1, #0xf]
    // 0xa0d038: ldur            x16, [fp, #-0x20]
    // 0xa0d03c: SaveReg r16
    //     0xa0d03c: str             x16, [SP, #-8]!
    // 0xa0d040: ldur            x0, [fp, #-0x20]
    // 0xa0d044: ClosureCall
    //     0xa0d044: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xa0d048: ldur            x2, [x0, #0x1f]
    //     0xa0d04c: blr             x2
    // 0xa0d050: add             SP, SP, #8
    // 0xa0d054: ldur            x1, [fp, #-0x10]
    // 0xa0d058: ArrayStore: r1[1] = r0  ; List_4
    //     0xa0d058: add             x25, x1, #0x13
    //     0xa0d05c: str             w0, [x25]
    //     0xa0d060: tbz             w0, #0, #0xa0d07c
    //     0xa0d064: ldurb           w16, [x1, #-1]
    //     0xa0d068: ldurb           w17, [x0, #-1]
    //     0xa0d06c: and             x16, x17, x16, lsr #2
    //     0xa0d070: tst             x16, HEAP, lsr #32
    //     0xa0d074: b.eq            #0xa0d07c
    //     0xa0d078: bl              #0xd67e5c
    // 0xa0d07c: ldur            x16, [fp, #-0x10]
    // 0xa0d080: SaveReg r16
    //     0xa0d080: str             x16, [SP, #-8]!
    // 0xa0d084: r0 = _interpolate()
    //     0xa0d084: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0d088: add             SP, SP, #8
    // 0xa0d08c: r0 = Throw()
    //     0xa0d08c: bl              #0xd67e38  ; ThrowStub
    // 0xa0d090: brk             #0
    // 0xa0d094: r1 = Null
    //     0xa0d094: mov             x1, NULL
    // 0xa0d098: r2 = 4
    //     0xa0d098: mov             x2, #4
    // 0xa0d09c: r0 = AllocateArray()
    //     0xa0d09c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0d0a0: mov             x1, x0
    // 0xa0d0a4: stur            x1, [fp, #-0x40]
    // 0xa0d0a8: r17 = "Failed to call GetTokenInformation: "
    //     0xa0d0a8: add             x17, PP, #8, lsl #12  ; [pp+0x8368] "Failed to call GetTokenInformation: "
    //     0xa0d0ac: ldr             x17, [x17, #0x368]
    // 0xa0d0b0: StoreField: r1->field_f = r17
    //     0xa0d0b0: stur            w17, [x1, #0xf]
    // 0xa0d0b4: ldur            x16, [fp, #-0x20]
    // 0xa0d0b8: SaveReg r16
    //     0xa0d0b8: str             x16, [SP, #-8]!
    // 0xa0d0bc: ldur            x0, [fp, #-0x20]
    // 0xa0d0c0: ClosureCall
    //     0xa0d0c0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xa0d0c4: ldur            x2, [x0, #0x1f]
    //     0xa0d0c8: blr             x2
    // 0xa0d0cc: add             SP, SP, #8
    // 0xa0d0d0: ldur            x1, [fp, #-0x40]
    // 0xa0d0d4: ArrayStore: r1[1] = r0  ; List_4
    //     0xa0d0d4: add             x25, x1, #0x13
    //     0xa0d0d8: str             w0, [x25]
    //     0xa0d0dc: tbz             w0, #0, #0xa0d0f8
    //     0xa0d0e0: ldurb           w16, [x1, #-1]
    //     0xa0d0e4: ldurb           w17, [x0, #-1]
    //     0xa0d0e8: and             x16, x17, x16, lsr #2
    //     0xa0d0ec: tst             x16, HEAP, lsr #32
    //     0xa0d0f0: b.eq            #0xa0d0f8
    //     0xa0d0f4: bl              #0xd67e5c
    // 0xa0d0f8: ldur            x16, [fp, #-0x40]
    // 0xa0d0fc: SaveReg r16
    //     0xa0d0fc: str             x16, [SP, #-8]!
    // 0xa0d100: r0 = _interpolate()
    //     0xa0d100: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0d104: add             SP, SP, #8
    // 0xa0d108: r0 = Throw()
    //     0xa0d108: bl              #0xd67e38  ; ThrowStub
    // 0xa0d10c: brk             #0
    // 0xa0d110: r1 = Null
    //     0xa0d110: mov             x1, NULL
    // 0xa0d114: r2 = 4
    //     0xa0d114: mov             x2, #4
    // 0xa0d118: r0 = AllocateArray()
    //     0xa0d118: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0d11c: mov             x1, x0
    // 0xa0d120: stur            x1, [fp, #-0x38]
    // 0xa0d124: r17 = "Failed to call GetTokenInformation: "
    //     0xa0d124: add             x17, PP, #8, lsl #12  ; [pp+0x8368] "Failed to call GetTokenInformation: "
    //     0xa0d128: ldr             x17, [x17, #0x368]
    // 0xa0d12c: StoreField: r1->field_f = r17
    //     0xa0d12c: stur            w17, [x1, #0xf]
    // 0xa0d130: ldur            x16, [fp, #-0x20]
    // 0xa0d134: SaveReg r16
    //     0xa0d134: str             x16, [SP, #-8]!
    // 0xa0d138: ldur            x0, [fp, #-0x20]
    // 0xa0d13c: ClosureCall
    //     0xa0d13c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xa0d140: ldur            x2, [x0, #0x1f]
    //     0xa0d144: blr             x2
    // 0xa0d148: add             SP, SP, #8
    // 0xa0d14c: ldur            x1, [fp, #-0x38]
    // 0xa0d150: ArrayStore: r1[1] = r0  ; List_4
    //     0xa0d150: add             x25, x1, #0x13
    //     0xa0d154: str             w0, [x25]
    //     0xa0d158: tbz             w0, #0, #0xa0d174
    //     0xa0d15c: ldurb           w16, [x1, #-1]
    //     0xa0d160: ldurb           w17, [x0, #-1]
    //     0xa0d164: and             x16, x17, x16, lsr #2
    //     0xa0d168: tst             x16, HEAP, lsr #32
    //     0xa0d16c: b.eq            #0xa0d174
    //     0xa0d170: bl              #0xd67e5c
    // 0xa0d174: ldur            x16, [fp, #-0x38]
    // 0xa0d178: SaveReg r16
    //     0xa0d178: str             x16, [SP, #-8]!
    // 0xa0d17c: r0 = _interpolate()
    //     0xa0d17c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0d180: add             SP, SP, #8
    // 0xa0d184: r0 = Throw()
    //     0xa0d184: bl              #0xd67e38  ; ThrowStub
    // 0xa0d188: brk             #0
    // 0xa0d18c: r1 = Null
    //     0xa0d18c: mov             x1, NULL
    // 0xa0d190: r2 = 4
    //     0xa0d190: mov             x2, #4
    // 0xa0d194: r0 = AllocateArray()
    //     0xa0d194: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0d198: mov             x1, x0
    // 0xa0d19c: stur            x1, [fp, #-0x28]
    // 0xa0d1a0: r17 = "Failed to call ConvertSidToStringSidA: "
    //     0xa0d1a0: add             x17, PP, #8, lsl #12  ; [pp+0x8370] "Failed to call ConvertSidToStringSidA: "
    //     0xa0d1a4: ldr             x17, [x17, #0x370]
    // 0xa0d1a8: StoreField: r1->field_f = r17
    //     0xa0d1a8: stur            w17, [x1, #0xf]
    // 0xa0d1ac: ldur            x16, [fp, #-0x20]
    // 0xa0d1b0: SaveReg r16
    //     0xa0d1b0: str             x16, [SP, #-8]!
    // 0xa0d1b4: ldur            x0, [fp, #-0x20]
    // 0xa0d1b8: ClosureCall
    //     0xa0d1b8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xa0d1bc: ldur            x2, [x0, #0x1f]
    //     0xa0d1c0: blr             x2
    // 0xa0d1c4: add             SP, SP, #8
    // 0xa0d1c8: ldur            x1, [fp, #-0x28]
    // 0xa0d1cc: ArrayStore: r1[1] = r0  ; List_4
    //     0xa0d1cc: add             x25, x1, #0x13
    //     0xa0d1d0: str             w0, [x25]
    //     0xa0d1d4: tbz             w0, #0, #0xa0d1f0
    //     0xa0d1d8: ldurb           w16, [x1, #-1]
    //     0xa0d1dc: ldurb           w17, [x0, #-1]
    //     0xa0d1e0: and             x16, x17, x16, lsr #2
    //     0xa0d1e4: tst             x16, HEAP, lsr #32
    //     0xa0d1e8: b.eq            #0xa0d1f0
    //     0xa0d1ec: bl              #0xd67e5c
    // 0xa0d1f0: ldur            x16, [fp, #-0x28]
    // 0xa0d1f4: SaveReg r16
    //     0xa0d1f4: str             x16, [SP, #-8]!
    // 0xa0d1f8: r0 = _interpolate()
    //     0xa0d1f8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0d1fc: add             SP, SP, #8
    // 0xa0d200: r0 = Throw()
    //     0xa0d200: bl              #0xd67e38  ; ThrowStub
    // 0xa0d204: brk             #0
    // 0xa0d208: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0d208: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0d20c: b               #0xa0c9ec
    // 0xa0d210: stp             x2, x3, [SP, #-0x10]!
    // 0xa0d214: SaveReg r1
    //     0xa0d214: str             x1, [SP, #-8]!
    // 0xa0d218: r0 = AllocateMint()
    //     0xa0d218: bl              #0xd69828  ; AllocateMintStub
    // 0xa0d21c: RestoreReg r1
    //     0xa0d21c: ldr             x1, [SP], #8
    // 0xa0d220: ldp             x2, x3, [SP], #0x10
    // 0xa0d224: b               #0xa0ce34
  }
}

// class id: 6260, size: 0xc, field offset: 0xc
class _SidAndAttributes extends Struct {
}

// class id: 6261, size: 0xc, field offset: 0xc
class _TokenUser extends Struct {

  get _ user(/* No info */) {
    // ** addr: 0xa0d49c, size: 0x80
    // 0xa0d49c: EnterFrame
    //     0xa0d49c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0d4a0: mov             fp, SP
    // 0xa0d4a4: AllocStack(0x10)
    //     0xa0d4a4: sub             SP, SP, #0x10
    // 0xa0d4a8: ldr             x0, [fp, #0x10]
    // 0xa0d4ac: LoadField: r1 = r0->field_7
    //     0xa0d4ac: ldur            w1, [x0, #7]
    // 0xa0d4b0: DecompressPointer r1
    //     0xa0d4b0: add             x1, x1, HEAP, lsl #32
    // 0xa0d4b4: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xa0d4b4: mov             x0, #0x76
    //     0xa0d4b8: tbz             w1, #0, #0xa0d4c8
    //     0xa0d4bc: ldur            x0, [x1, #-1]
    //     0xa0d4c0: ubfx            x0, x0, #0xc, #0x14
    //     0xa0d4c4: lsl             x0, x0, #1
    // 0xa0d4c8: cmp             w0, #0x8e
    // 0xa0d4cc: b.ne            #0xa0d510
    // 0xa0d4d0: LoadField: r0 = r1->field_7
    //     0xa0d4d0: ldur            x0, [x1, #7]
    // 0xa0d4d4: stur            x0, [fp, #-8]
    // 0xa0d4d8: r1 = <Never>
    //     0xa0d4d8: ldr             x1, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    // 0xa0d4dc: r0 = Pointer()
    //     0xa0d4dc: bl              #0x4ba128  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xa0d4e0: mov             x1, x0
    // 0xa0d4e4: ldur            x0, [fp, #-8]
    // 0xa0d4e8: stur            x1, [fp, #-0x10]
    // 0xa0d4ec: StoreField: r1->field_7 = r0
    //     0xa0d4ec: stur            x0, [x1, #7]
    // 0xa0d4f0: r0 = _SidAndAttributes()
    //     0xa0d4f0: bl              #0xa0d51c  ; Allocate_SidAndAttributesStub -> _SidAndAttributes (size=0xc)
    // 0xa0d4f4: mov             x1, x0
    // 0xa0d4f8: ldur            x0, [fp, #-0x10]
    // 0xa0d4fc: StoreField: r1->field_7 = r0
    //     0xa0d4fc: stur            w0, [x1, #7]
    // 0xa0d500: mov             x0, x1
    // 0xa0d504: LeaveFrame
    //     0xa0d504: mov             SP, fp
    //     0xa0d508: ldp             fp, lr, [SP], #0x10
    // 0xa0d50c: ret
    //     0xa0d50c: ret             
    // 0xa0d510: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xa0d510: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xa0d514: r0 = Throw()
    //     0xa0d514: bl              #0xd67e38  ; ThrowStub
    // 0xa0d518: brk             #0
  }
}

// lib: , url: package:dbus/src/dbus_client.dart

// class id: 1048833, size: 0x8
class :: {
}

// class id: 4623, size: 0x58, field offset: 0x8
class DBusClient extends Object {

  _ close(/* No info */) async {
    // ** addr: 0x9fc7ec, size: 0x104
    // 0x9fc7ec: EnterFrame
    //     0x9fc7ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9fc7f0: mov             fp, SP
    // 0x9fc7f4: AllocStack(0x18)
    //     0x9fc7f4: sub             SP, SP, #0x18
    // 0x9fc7f8: SetupParameters(DBusClient this /* r1, fp-0x10 */)
    //     0x9fc7f8: stur            NULL, [fp, #-8]
    //     0x9fc7fc: mov             x0, #0
    //     0x9fc800: add             x1, fp, w0, sxtw #2
    //     0x9fc804: ldr             x1, [x1, #0x10]
    //     0x9fc808: stur            x1, [fp, #-0x10]
    // 0x9fc80c: CheckStackOverflow
    //     0x9fc80c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fc810: cmp             SP, x16
    //     0x9fc814: b.ls            #0x9fc8e8
    // 0x9fc818: InitAsync() -> Future<void?>
    //     0x9fc818: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9fc81c: bl              #0x4b92e4
    // 0x9fc820: ldur            x0, [fp, #-0x10]
    // 0x9fc824: LoadField: r1 = r0->field_33
    //     0x9fc824: ldur            w1, [x0, #0x33]
    // 0x9fc828: DecompressPointer r1
    //     0x9fc828: add             x1, x1, HEAP, lsl #32
    // 0x9fc82c: cmp             w1, NULL
    // 0x9fc830: b.eq            #0x9fc84c
    // 0x9fc834: SaveReg r1
    //     0x9fc834: str             x1, [SP, #-8]!
    // 0x9fc838: r0 = cancel()
    //     0x9fc838: bl              #0xc54490  ; [dart:async] _BufferingStreamSubscription::cancel
    // 0x9fc83c: add             SP, SP, #8
    // 0x9fc840: mov             x1, x0
    // 0x9fc844: stur            x1, [fp, #-0x18]
    // 0x9fc848: r0 = Await()
    //     0x9fc848: bl              #0x4b8e6c  ; AwaitStub
    // 0x9fc84c: ldur            x0, [fp, #-0x10]
    // 0x9fc850: LoadField: r1 = r0->field_37
    //     0x9fc850: ldur            w1, [x0, #0x37]
    // 0x9fc854: DecompressPointer r1
    //     0x9fc854: add             x1, x1, HEAP, lsl #32
    // 0x9fc858: cmp             w1, NULL
    // 0x9fc85c: b.eq            #0x9fc878
    // 0x9fc860: SaveReg r1
    //     0x9fc860: str             x1, [SP, #-8]!
    // 0x9fc864: r0 = cancel()
    //     0x9fc864: bl              #0xc54490  ; [dart:async] _BufferingStreamSubscription::cancel
    // 0x9fc868: add             SP, SP, #8
    // 0x9fc86c: mov             x1, x0
    // 0x9fc870: stur            x1, [fp, #-0x18]
    // 0x9fc874: r0 = Await()
    //     0x9fc874: bl              #0x4b8e6c  ; AwaitStub
    // 0x9fc878: ldur            x0, [fp, #-0x10]
    // 0x9fc87c: LoadField: r1 = r0->field_3b
    //     0x9fc87c: ldur            w1, [x0, #0x3b]
    // 0x9fc880: DecompressPointer r1
    //     0x9fc880: add             x1, x1, HEAP, lsl #32
    // 0x9fc884: cmp             w1, NULL
    // 0x9fc888: b.eq            #0x9fc8a4
    // 0x9fc88c: SaveReg r1
    //     0x9fc88c: str             x1, [SP, #-8]!
    // 0x9fc890: r0 = cancel()
    //     0x9fc890: bl              #0xc54490  ; [dart:async] _BufferingStreamSubscription::cancel
    // 0x9fc894: add             SP, SP, #8
    // 0x9fc898: mov             x1, x0
    // 0x9fc89c: stur            x1, [fp, #-0x18]
    // 0x9fc8a0: r0 = Await()
    //     0x9fc8a0: bl              #0x4b8e6c  ; AwaitStub
    // 0x9fc8a4: ldur            x0, [fp, #-0x10]
    // 0x9fc8a8: LoadField: r1 = r0->field_b
    //     0x9fc8a8: ldur            w1, [x0, #0xb]
    // 0x9fc8ac: DecompressPointer r1
    //     0x9fc8ac: add             x1, x1, HEAP, lsl #32
    // 0x9fc8b0: cmp             w1, NULL
    // 0x9fc8b4: b.eq            #0x9fc8e0
    // 0x9fc8b8: r0 = LoadClassIdInstr(r1)
    //     0x9fc8b8: ldur            x0, [x1, #-1]
    //     0x9fc8bc: ubfx            x0, x0, #0xc, #0x14
    // 0x9fc8c0: SaveReg r1
    //     0x9fc8c0: str             x1, [SP, #-8]!
    // 0x9fc8c4: r0 = GDT[cid_x0 + -0xfec]()
    //     0x9fc8c4: sub             lr, x0, #0xfec
    //     0x9fc8c8: ldr             lr, [x21, lr, lsl #3]
    //     0x9fc8cc: blr             lr
    // 0x9fc8d0: add             SP, SP, #8
    // 0x9fc8d4: mov             x1, x0
    // 0x9fc8d8: stur            x1, [fp, #-0x10]
    // 0x9fc8dc: r0 = Await()
    //     0x9fc8dc: bl              #0x4b8e6c  ; AwaitStub
    // 0x9fc8e0: r0 = Null
    //     0x9fc8e0: mov             x0, NULL
    // 0x9fc8e4: r0 = ReturnAsyncNotFuture()
    //     0x9fc8e4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9fc8e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fc8e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fc8ec: b               #0x9fc818
  }
  _ callMethod(/* No info */) async {
    // ** addr: 0x9fe338, size: 0x164
    // 0x9fe338: EnterFrame
    //     0x9fe338: stp             fp, lr, [SP, #-0x10]!
    //     0x9fe33c: mov             fp, SP
    // 0x9fe340: AllocStack(0x48)
    //     0x9fe340: sub             SP, SP, #0x48
    // 0x9fe344: SetupParameters(DBusClient this /* r3, fp-0x40 */, dynamic _ /* r4, fp-0x38 */, dynamic _ /* r5, fp-0x30 */, dynamic _ /* r6, fp-0x28 */, dynamic _ /* r7, fp-0x20 */, dynamic _ /* r8, fp-0x18 */, {dynamic values = const [] /* r1, fp-0x10 */})
    //     0x9fe344: stur            NULL, [fp, #-8]
    //     0x9fe348: mov             x0, x4
    //     0x9fe34c: ldur            w1, [x0, #0x13]
    //     0x9fe350: add             x1, x1, HEAP, lsl #32
    //     0x9fe354: sub             x2, x1, #0xc
    //     0x9fe358: add             x3, fp, w2, sxtw #2
    //     0x9fe35c: ldr             x3, [x3, #0x38]
    //     0x9fe360: stur            x3, [fp, #-0x40]
    //     0x9fe364: add             x4, fp, w2, sxtw #2
    //     0x9fe368: ldr             x4, [x4, #0x30]
    //     0x9fe36c: stur            x4, [fp, #-0x38]
    //     0x9fe370: add             x5, fp, w2, sxtw #2
    //     0x9fe374: ldr             x5, [x5, #0x28]
    //     0x9fe378: stur            x5, [fp, #-0x30]
    //     0x9fe37c: add             x6, fp, w2, sxtw #2
    //     0x9fe380: ldr             x6, [x6, #0x20]
    //     0x9fe384: stur            x6, [fp, #-0x28]
    //     0x9fe388: add             x7, fp, w2, sxtw #2
    //     0x9fe38c: ldr             x7, [x7, #0x18]
    //     0x9fe390: stur            x7, [fp, #-0x20]
    //     0x9fe394: add             x8, fp, w2, sxtw #2
    //     0x9fe398: ldr             x8, [x8, #0x10]
    //     0x9fe39c: stur            x8, [fp, #-0x18]
    //     0x9fe3a0: ldur            w2, [x0, #0x1f]
    //     0x9fe3a4: add             x2, x2, HEAP, lsl #32
    //     0x9fe3a8: ldr             x16, [PP, #0x7720]  ; [pp+0x7720] "values"
    //     0x9fe3ac: cmp             w2, w16
    //     0x9fe3b0: b.ne            #0x9fe3cc
    //     0x9fe3b4: ldur            w2, [x0, #0x23]
    //     0x9fe3b8: add             x2, x2, HEAP, lsl #32
    //     0x9fe3bc: sub             w0, w1, w2
    //     0x9fe3c0: add             x1, fp, w0, sxtw #2
    //     0x9fe3c4: ldr             x1, [x1, #8]
    //     0x9fe3c8: b               #0x9fe3d0
    //     0x9fe3cc: ldr             x1, [PP, #0x7728]  ; [pp+0x7728] List<DBusValue>(0)
    //     0x9fe3d0: stur            x1, [fp, #-0x10]
    // 0x9fe3d4: CheckStackOverflow
    //     0x9fe3d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fe3d8: cmp             SP, x16
    //     0x9fe3dc: b.ls            #0x9fe494
    // 0x9fe3e0: InitAsync() -> Future<DBusMethodSuccessResponse>
    //     0x9fe3e0: ldr             x0, [PP, #0x7730]  ; [pp+0x7730] TypeArguments: <DBusMethodSuccessResponse>
    //     0x9fe3e4: bl              #0x4b92e4
    // 0x9fe3e8: ldur            x16, [fp, #-0x40]
    // 0x9fe3ec: SaveReg r16
    //     0x9fe3ec: str             x16, [SP, #-8]!
    // 0x9fe3f0: r0 = _connect()
    //     0x9fe3f0: bl              #0xa02724  ; [package:dbus/src/dbus_client.dart] DBusClient::_connect
    // 0x9fe3f4: add             SP, SP, #8
    // 0x9fe3f8: mov             x1, x0
    // 0x9fe3fc: stur            x1, [fp, #-0x48]
    // 0x9fe400: r0 = Await()
    //     0x9fe400: bl              #0x4b8e6c  ; AwaitStub
    // 0x9fe404: r0 = DBusBusName()
    //     0x9fe404: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0x9fe408: stur            x0, [fp, #-0x48]
    // 0x9fe40c: ldur            x16, [fp, #-0x38]
    // 0x9fe410: stp             x16, x0, [SP, #-0x10]!
    // 0x9fe414: r0 = DBusBusName()
    //     0x9fe414: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0x9fe418: add             SP, SP, #0x10
    // 0x9fe41c: r0 = DBusInterfaceName()
    //     0x9fe41c: bl              #0xa023bc  ; AllocateDBusInterfaceNameStub -> DBusInterfaceName (size=0xc)
    // 0x9fe420: stur            x0, [fp, #-0x38]
    // 0x9fe424: ldur            x16, [fp, #-0x30]
    // 0x9fe428: stp             x16, x0, [SP, #-0x10]!
    // 0x9fe42c: r0 = DBusInterfaceName()
    //     0x9fe42c: bl              #0xa0212c  ; [package:dbus/src/dbus_interface_name.dart] DBusInterfaceName::DBusInterfaceName
    // 0x9fe430: add             SP, SP, #0x10
    // 0x9fe434: r0 = DBusMemberName()
    //     0x9fe434: bl              #0xa02120  ; AllocateDBusMemberNameStub -> DBusMemberName (size=0xc)
    // 0x9fe438: stur            x0, [fp, #-0x30]
    // 0x9fe43c: ldur            x16, [fp, #-0x28]
    // 0x9fe440: stp             x16, x0, [SP, #-0x10]!
    // 0x9fe444: r0 = DBusMemberName()
    //     0x9fe444: bl              #0xa0201c  ; [package:dbus/src/dbus_member_name.dart] DBusMemberName::DBusMemberName
    // 0x9fe448: add             SP, SP, #0x10
    // 0x9fe44c: ldur            x16, [fp, #-0x40]
    // 0x9fe450: ldur            lr, [fp, #-0x48]
    // 0x9fe454: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe458: ldur            x16, [fp, #-0x38]
    // 0x9fe45c: ldur            lr, [fp, #-0x30]
    // 0x9fe460: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe464: ldur            x16, [fp, #-0x20]
    // 0x9fe468: ldur            lr, [fp, #-0x18]
    // 0x9fe46c: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe470: ldur            x16, [fp, #-0x10]
    // 0x9fe474: SaveReg r16
    //     0x9fe474: str             x16, [SP, #-8]!
    // 0x9fe478: r4 = const [0, 0x7, 0x7, 0x6, values, 0x6, null]
    //     0x9fe478: ldr             x4, [PP, #0x7710]  ; [pp+0x7710] List(7) [0, 0x7, 0x7, 0x6, "values", 0x6, Null]
    // 0x9fe47c: r0 = _callMethod()
    //     0x9fe47c: bl              #0x9fe49c  ; [package:dbus/src/dbus_client.dart] DBusClient::_callMethod
    // 0x9fe480: add             SP, SP, #0x38
    // 0x9fe484: mov             x1, x0
    // 0x9fe488: stur            x1, [fp, #-0x10]
    // 0x9fe48c: r0 = Await()
    //     0x9fe48c: bl              #0x4b8e6c  ; AwaitStub
    // 0x9fe490: r0 = ReturnAsync()
    //     0x9fe490: b               #0x501858  ; ReturnAsyncStub
    // 0x9fe494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fe494: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fe498: b               #0x9fe3e0
  }
  _ _callMethod(/* No info */) async {
    // ** addr: 0x9fe49c, size: 0x730
    // 0x9fe49c: EnterFrame
    //     0x9fe49c: stp             fp, lr, [SP, #-0x10]!
    //     0x9fe4a0: mov             fp, SP
    // 0x9fe4a4: AllocStack(0x68)
    //     0x9fe4a4: sub             SP, SP, #0x68
    // 0x9fe4a8: SetupParameters(DBusClient this /* r3, fp-0x40 */, dynamic _ /* r4, fp-0x38 */, dynamic _ /* r5, fp-0x30 */, dynamic _ /* r6, fp-0x28 */, dynamic _ /* r7, fp-0x20 */, dynamic _ /* r8, fp-0x18 */, {dynamic values = _ConstSet len:0 /* r1, fp-0x10 */})
    //     0x9fe4a8: stur            NULL, [fp, #-8]
    //     0x9fe4ac: mov             x0, x4
    //     0x9fe4b0: ldur            w1, [x0, #0x13]
    //     0x9fe4b4: add             x1, x1, HEAP, lsl #32
    //     0x9fe4b8: sub             x2, x1, #0xc
    //     0x9fe4bc: add             x3, fp, w2, sxtw #2
    //     0x9fe4c0: ldr             x3, [x3, #0x38]
    //     0x9fe4c4: stur            x3, [fp, #-0x40]
    //     0x9fe4c8: add             x4, fp, w2, sxtw #2
    //     0x9fe4cc: ldr             x4, [x4, #0x30]
    //     0x9fe4d0: stur            x4, [fp, #-0x38]
    //     0x9fe4d4: add             x5, fp, w2, sxtw #2
    //     0x9fe4d8: ldr             x5, [x5, #0x28]
    //     0x9fe4dc: stur            x5, [fp, #-0x30]
    //     0x9fe4e0: add             x6, fp, w2, sxtw #2
    //     0x9fe4e4: ldr             x6, [x6, #0x20]
    //     0x9fe4e8: stur            x6, [fp, #-0x28]
    //     0x9fe4ec: add             x7, fp, w2, sxtw #2
    //     0x9fe4f0: ldr             x7, [x7, #0x18]
    //     0x9fe4f4: stur            x7, [fp, #-0x20]
    //     0x9fe4f8: add             x8, fp, w2, sxtw #2
    //     0x9fe4fc: ldr             x8, [x8, #0x10]
    //     0x9fe500: stur            x8, [fp, #-0x18]
    //     0x9fe504: ldur            w2, [x0, #0x1f]
    //     0x9fe508: add             x2, x2, HEAP, lsl #32
    //     0x9fe50c: ldr             x16, [PP, #0x7720]  ; [pp+0x7720] "values"
    //     0x9fe510: cmp             w2, w16
    //     0x9fe514: b.ne            #0x9fe530
    //     0x9fe518: ldur            w2, [x0, #0x23]
    //     0x9fe51c: add             x2, x2, HEAP, lsl #32
    //     0x9fe520: sub             w0, w1, w2
    //     0x9fe524: add             x1, fp, w0, sxtw #2
    //     0x9fe528: ldr             x1, [x1, #8]
    //     0x9fe52c: b               #0x9fe534
    //     0x9fe530: ldr             x1, [PP, #0x7738]  ; [pp+0x7738] Set<DBusValue>(0)
    //     0x9fe534: stur            x1, [fp, #-0x10]
    // 0x9fe538: CheckStackOverflow
    //     0x9fe538: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fe53c: cmp             SP, x16
    //     0x9fe540: b.ls            #0x9febc4
    // 0x9fe544: InitAsync() -> Future<DBusMethodSuccessResponse>
    //     0x9fe544: ldr             x0, [PP, #0x7730]  ; [pp+0x7730] TypeArguments: <DBusMethodSuccessResponse>
    //     0x9fe548: bl              #0x4b92e4
    // 0x9fe54c: ldur            x0, [fp, #-0x40]
    // 0x9fe550: LoadField: r1 = r0->field_23
    //     0x9fe550: ldur            x1, [x0, #0x23]
    // 0x9fe554: add             x2, x1, #1
    // 0x9fe558: stur            x2, [fp, #-0x48]
    // 0x9fe55c: StoreField: r0->field_23 = r2
    //     0x9fe55c: stur            x2, [x0, #0x23]
    // 0x9fe560: r1 = <DBusMethodResponse>
    //     0x9fe560: ldr             x1, [PP, #0x7740]  ; [pp+0x7740] TypeArguments: <DBusMethodResponse>
    // 0x9fe564: r0 = _Future()
    //     0x9fe564: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x9fe568: mov             x1, x0
    // 0x9fe56c: r0 = 0
    //     0x9fe56c: mov             x0, #0
    // 0x9fe570: stur            x1, [fp, #-0x50]
    // 0x9fe574: StoreField: r1->field_b = r0
    //     0x9fe574: stur            x0, [x1, #0xb]
    // 0x9fe578: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x9fe578: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9fe57c: ldr             x0, [x0, #0xb58]
    //     0x9fe580: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9fe584: cmp             w0, w16
    //     0x9fe588: b.ne            #0x9fe594
    //     0x9fe58c: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x9fe590: bl              #0xd67d44
    // 0x9fe594: mov             x1, x0
    // 0x9fe598: ldur            x0, [fp, #-0x50]
    // 0x9fe59c: StoreField: r0->field_13 = r1
    //     0x9fe59c: stur            w1, [x0, #0x13]
    // 0x9fe5a0: r1 = <DBusMethodResponse>
    //     0x9fe5a0: ldr             x1, [PP, #0x7740]  ; [pp+0x7740] TypeArguments: <DBusMethodResponse>
    // 0x9fe5a4: r0 = _AsyncCompleter()
    //     0x9fe5a4: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x9fe5a8: mov             x3, x0
    // 0x9fe5ac: ldur            x2, [fp, #-0x50]
    // 0x9fe5b0: stur            x3, [fp, #-0x68]
    // 0x9fe5b4: StoreField: r3->field_b = r2
    //     0x9fe5b4: stur            w2, [x3, #0xb]
    // 0x9fe5b8: ldur            x4, [fp, #-0x40]
    // 0x9fe5bc: LoadField: r5 = r4->field_2b
    //     0x9fe5bc: ldur            w5, [x4, #0x2b]
    // 0x9fe5c0: DecompressPointer r5
    //     0x9fe5c0: add             x5, x5, HEAP, lsl #32
    // 0x9fe5c4: ldur            x6, [fp, #-0x48]
    // 0x9fe5c8: stur            x5, [fp, #-0x60]
    // 0x9fe5cc: r0 = BoxInt64Instr(r6)
    //     0x9fe5cc: sbfiz           x0, x6, #1, #0x1f
    //     0x9fe5d0: cmp             x6, x0, asr #1
    //     0x9fe5d4: b.eq            #0x9fe5e0
    //     0x9fe5d8: bl              #0xd69bb8
    //     0x9fe5dc: stur            x6, [x0, #7]
    // 0x9fe5e0: stur            x0, [fp, #-0x58]
    // 0x9fe5e4: stp             x0, x5, [SP, #-0x10]!
    // 0x9fe5e8: r0 = hash()
    //     0x9fe5e8: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0x9fe5ec: add             SP, SP, #0x10
    // 0x9fe5f0: ldur            x16, [fp, #-0x60]
    // 0x9fe5f4: ldur            lr, [fp, #-0x58]
    // 0x9fe5f8: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe5fc: ldur            x16, [fp, #-0x68]
    // 0x9fe600: stp             x0, x16, [SP, #-0x10]!
    // 0x9fe604: r0 = _set()
    //     0x9fe604: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x9fe608: add             SP, SP, #0x20
    // 0x9fe60c: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x9fe60c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9fe610: ldr             x0, [x0, #0x598]
    //     0x9fe614: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9fe618: cmp             w0, w16
    //     0x9fe61c: b.ne            #0x9fe628
    //     0x9fe620: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x9fe624: bl              #0xd67cdc
    // 0x9fe628: r1 = <DBusMessageFlag>
    //     0x9fe628: ldr             x1, [PP, #0x7748]  ; [pp+0x7748] TypeArguments: <DBusMessageFlag>
    // 0x9fe62c: stur            x0, [fp, #-0x58]
    // 0x9fe630: r0 = _Set()
    //     0x9fe630: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x9fe634: mov             x1, x0
    // 0x9fe638: ldur            x0, [fp, #-0x58]
    // 0x9fe63c: stur            x1, [fp, #-0x60]
    // 0x9fe640: StoreField: r1->field_1b = r0
    //     0x9fe640: stur            w0, [x1, #0x1b]
    // 0x9fe644: StoreField: r1->field_b = rZR
    //     0x9fe644: stur            wzr, [x1, #0xb]
    // 0x9fe648: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x9fe648: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9fe64c: ldr             x0, [x0, #0x5a0]
    //     0x9fe650: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9fe654: cmp             w0, w16
    //     0x9fe658: b.ne            #0x9fe664
    //     0x9fe65c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x9fe660: bl              #0xd67cdc
    // 0x9fe664: ldur            x1, [fp, #-0x60]
    // 0x9fe668: StoreField: r1->field_f = r0
    //     0x9fe668: stur            w0, [x1, #0xf]
    // 0x9fe66c: StoreField: r1->field_13 = rZR
    //     0x9fe66c: stur            wzr, [x1, #0x13]
    // 0x9fe670: StoreField: r1->field_17 = rZR
    //     0x9fe670: stur            wzr, [x1, #0x17]
    // 0x9fe674: ldur            x2, [fp, #-0x40]
    // 0x9fe678: LoadField: r3 = r2->field_23
    //     0x9fe678: ldur            x3, [x2, #0x23]
    // 0x9fe67c: ldur            x0, [fp, #-0x10]
    // 0x9fe680: stur            x3, [fp, #-0x48]
    // 0x9fe684: r4 = LoadClassIdInstr(r0)
    //     0x9fe684: ldur            x4, [x0, #-1]
    //     0x9fe688: ubfx            x4, x4, #0xc, #0x14
    // 0x9fe68c: SaveReg r0
    //     0x9fe68c: str             x0, [SP, #-8]!
    // 0x9fe690: mov             x0, x4
    // 0x9fe694: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9fe694: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9fe698: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0x9fe698: mov             x17, #0xc8a1
    //     0x9fe69c: add             lr, x0, x17
    //     0x9fe6a0: ldr             lr, [x21, lr, lsl #3]
    //     0x9fe6a4: blr             lr
    // 0x9fe6a8: add             SP, SP, #8
    // 0x9fe6ac: stur            x0, [fp, #-0x10]
    // 0x9fe6b0: r0 = DBusMessage()
    //     0x9fe6b0: bl              #0xa02010  ; AllocateDBusMessageStub -> DBusMessage (size=0x38)
    // 0x9fe6b4: mov             x1, x0
    // 0x9fe6b8: r0 = Instance_DBusMessageType
    //     0x9fe6b8: ldr             x0, [PP, #0x7750]  ; [pp+0x7750] Obj!DBusMessageType@b667d1
    // 0x9fe6bc: StoreField: r1->field_7 = r0
    //     0x9fe6bc: stur            w0, [x1, #7]
    // 0x9fe6c0: ldur            x0, [fp, #-0x60]
    // 0x9fe6c4: StoreField: r1->field_b = r0
    //     0x9fe6c4: stur            w0, [x1, #0xb]
    // 0x9fe6c8: ldur            x0, [fp, #-0x48]
    // 0x9fe6cc: StoreField: r1->field_f = r0
    //     0x9fe6cc: stur            x0, [x1, #0xf]
    // 0x9fe6d0: ldur            x0, [fp, #-0x20]
    // 0x9fe6d4: StoreField: r1->field_17 = r0
    //     0x9fe6d4: stur            w0, [x1, #0x17]
    // 0x9fe6d8: ldur            x0, [fp, #-0x30]
    // 0x9fe6dc: StoreField: r1->field_1b = r0
    //     0x9fe6dc: stur            w0, [x1, #0x1b]
    // 0x9fe6e0: ldur            x2, [fp, #-0x28]
    // 0x9fe6e4: StoreField: r1->field_1f = r2
    //     0x9fe6e4: stur            w2, [x1, #0x1f]
    // 0x9fe6e8: ldur            x3, [fp, #-0x38]
    // 0x9fe6ec: StoreField: r1->field_2b = r3
    //     0x9fe6ec: stur            w3, [x1, #0x2b]
    // 0x9fe6f0: ldur            x3, [fp, #-0x10]
    // 0x9fe6f4: StoreField: r1->field_33 = r3
    //     0x9fe6f4: stur            w3, [x1, #0x33]
    // 0x9fe6f8: ldur            x16, [fp, #-0x40]
    // 0x9fe6fc: stp             x1, x16, [SP, #-0x10]!
    // 0x9fe700: r0 = _sendMessage()
    //     0x9fe700: bl              #0x9ff070  ; [package:dbus/src/dbus_client.dart] DBusClient::_sendMessage
    // 0x9fe704: add             SP, SP, #0x10
    // 0x9fe708: ldur            x0, [fp, #-0x50]
    // 0x9fe70c: r0 = Await()
    //     0x9fe70c: bl              #0x4b8e6c  ; AwaitStub
    // 0x9fe710: stur            x0, [fp, #-0x10]
    // 0x9fe714: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9fe714: mov             x1, #0x76
    //     0x9fe718: tbz             w0, #0, #0x9fe728
    //     0x9fe71c: ldur            x1, [x0, #-1]
    //     0x9fe720: ubfx            x1, x1, #0xc, #0x14
    //     0x9fe724: lsl             x1, x1, #1
    // 0x9fe728: r17 = 9218
    //     0x9fe728: mov             x17, #0x2402
    // 0x9fe72c: cmp             w1, w17
    // 0x9fe730: b.ne            #0x9fe76c
    // 0x9fe734: SaveReg r0
    //     0x9fe734: str             x0, [SP, #-8]!
    // 0x9fe738: r0 = signature()
    //     0x9fe738: bl              #0x9fec98  ; [package:dbus/src/dbus_method_response.dart] DBusMethodResponse::signature
    // 0x9fe73c: add             SP, SP, #8
    // 0x9fe740: ldur            x16, [fp, #-0x18]
    // 0x9fe744: stp             x16, x0, [SP, #-0x10]!
    // 0x9fe748: r0 = ==()
    //     0x9fe748: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0x9fe74c: add             SP, SP, #0x10
    // 0x9fe750: tbz             w0, #4, #0x9fe764
    // 0x9fe754: ldur            x0, [fp, #-0x30]
    // 0x9fe758: cmp             w0, NULL
    // 0x9fe75c: b.eq            #0x9fe980
    // 0x9fe760: b               #0x9fe92c
    // 0x9fe764: ldur            x0, [fp, #-0x10]
    // 0x9fe768: r0 = ReturnAsyncNotFuture()
    //     0x9fe768: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9fe76c: r17 = 9216
    //     0x9fe76c: mov             x17, #0x2400
    // 0x9fe770: cmp             w1, w17
    // 0x9fe774: b.ne            #0x9febb8
    // 0x9fe778: LoadField: r1 = r0->field_7
    //     0x9fe778: ldur            w1, [x0, #7]
    // 0x9fe77c: DecompressPointer r1
    //     0x9fe77c: add             x1, x1, HEAP, lsl #32
    // 0x9fe780: r16 = "org.freedesktop.DBus.Error."
    //     0x9fe780: ldr             x16, [PP, #0x7758]  ; [pp+0x7758] "org.freedesktop.DBus.Error."
    // 0x9fe784: stp             x16, x1, [SP, #-0x10]!
    // 0x9fe788: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fe788: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fe78c: r0 = startsWith()
    //     0x9fe78c: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x9fe790: add             SP, SP, #0x10
    // 0x9fe794: tbnz            w0, #4, #0x9feb98
    // 0x9fe798: ldur            x0, [fp, #-0x10]
    // 0x9fe79c: LoadField: r1 = r0->field_7
    //     0x9fe79c: ldur            w1, [x0, #7]
    // 0x9fe7a0: DecompressPointer r1
    //     0x9fe7a0: add             x1, x1, HEAP, lsl #32
    // 0x9fe7a4: stur            x1, [fp, #-0x18]
    // 0x9fe7a8: r16 = "org.freedesktop.DBus.Error.Failed"
    //     0x9fe7a8: ldr             x16, [PP, #0x7760]  ; [pp+0x7760] "org.freedesktop.DBus.Error.Failed"
    // 0x9fe7ac: stp             x1, x16, [SP, #-0x10]!
    // 0x9fe7b0: r0 = ==()
    //     0x9fe7b0: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe7b4: add             SP, SP, #0x10
    // 0x9fe7b8: tbz             w0, #4, #0x9fe9b8
    // 0x9fe7bc: ldur            x0, [fp, #-0x10]
    // 0x9fe7c0: r16 = "org.freedesktop.DBus.Error.ServiceUnknown"
    //     0x9fe7c0: ldr             x16, [PP, #0x7768]  ; [pp+0x7768] "org.freedesktop.DBus.Error.ServiceUnknown"
    // 0x9fe7c4: ldur            lr, [fp, #-0x18]
    // 0x9fe7c8: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe7cc: r0 = ==()
    //     0x9fe7cc: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe7d0: add             SP, SP, #0x10
    // 0x9fe7d4: tbz             w0, #4, #0x9fe9d8
    // 0x9fe7d8: ldur            x0, [fp, #-0x10]
    // 0x9fe7dc: r16 = "org.freedesktop.DBus.Error.UnknownObject"
    //     0x9fe7dc: ldr             x16, [PP, #0x7770]  ; [pp+0x7770] "org.freedesktop.DBus.Error.UnknownObject"
    // 0x9fe7e0: ldur            lr, [fp, #-0x18]
    // 0x9fe7e4: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe7e8: r0 = ==()
    //     0x9fe7e8: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe7ec: add             SP, SP, #0x10
    // 0x9fe7f0: tbz             w0, #4, #0x9fe9f8
    // 0x9fe7f4: ldur            x0, [fp, #-0x10]
    // 0x9fe7f8: r16 = "org.freedesktop.DBus.Error.UnknownInterface"
    //     0x9fe7f8: ldr             x16, [PP, #0x7778]  ; [pp+0x7778] "org.freedesktop.DBus.Error.UnknownInterface"
    // 0x9fe7fc: ldur            lr, [fp, #-0x18]
    // 0x9fe800: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe804: r0 = ==()
    //     0x9fe804: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe808: add             SP, SP, #0x10
    // 0x9fe80c: tbz             w0, #4, #0x9fea18
    // 0x9fe810: ldur            x0, [fp, #-0x10]
    // 0x9fe814: r16 = "org.freedesktop.DBus.Error.UnknownMethod"
    //     0x9fe814: ldr             x16, [PP, #0x7780]  ; [pp+0x7780] "org.freedesktop.DBus.Error.UnknownMethod"
    // 0x9fe818: ldur            lr, [fp, #-0x18]
    // 0x9fe81c: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe820: r0 = ==()
    //     0x9fe820: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe824: add             SP, SP, #0x10
    // 0x9fe828: tbz             w0, #4, #0x9fea38
    // 0x9fe82c: ldur            x0, [fp, #-0x10]
    // 0x9fe830: r16 = "org.freedesktop.DBus.Error.Timeout"
    //     0x9fe830: ldr             x16, [PP, #0x7788]  ; [pp+0x7788] "org.freedesktop.DBus.Error.Timeout"
    // 0x9fe834: ldur            lr, [fp, #-0x18]
    // 0x9fe838: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe83c: r0 = ==()
    //     0x9fe83c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe840: add             SP, SP, #0x10
    // 0x9fe844: tbz             w0, #4, #0x9fea58
    // 0x9fe848: ldur            x0, [fp, #-0x10]
    // 0x9fe84c: r16 = "org.freedesktop.DBus.Error.TimedOut"
    //     0x9fe84c: ldr             x16, [PP, #0x7790]  ; [pp+0x7790] "org.freedesktop.DBus.Error.TimedOut"
    // 0x9fe850: ldur            lr, [fp, #-0x18]
    // 0x9fe854: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe858: r0 = ==()
    //     0x9fe858: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe85c: add             SP, SP, #0x10
    // 0x9fe860: tbz             w0, #4, #0x9fea78
    // 0x9fe864: ldur            x0, [fp, #-0x10]
    // 0x9fe868: r16 = "org.freedesktop.DBus.Error.InvalidArgs"
    //     0x9fe868: ldr             x16, [PP, #0x7798]  ; [pp+0x7798] "org.freedesktop.DBus.Error.InvalidArgs"
    // 0x9fe86c: ldur            lr, [fp, #-0x18]
    // 0x9fe870: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe874: r0 = ==()
    //     0x9fe874: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe878: add             SP, SP, #0x10
    // 0x9fe87c: tbz             w0, #4, #0x9fea98
    // 0x9fe880: ldur            x0, [fp, #-0x10]
    // 0x9fe884: r16 = "org.freedesktop.DBus.Error.UnknownProperty"
    //     0x9fe884: ldr             x16, [PP, #0x77a0]  ; [pp+0x77a0] "org.freedesktop.DBus.Error.UnknownProperty"
    // 0x9fe888: ldur            lr, [fp, #-0x18]
    // 0x9fe88c: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe890: r0 = ==()
    //     0x9fe890: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe894: add             SP, SP, #0x10
    // 0x9fe898: tbz             w0, #4, #0x9feab8
    // 0x9fe89c: ldur            x0, [fp, #-0x10]
    // 0x9fe8a0: r16 = "org.freedesktop.DBus.Error.PropertyReadOnly"
    //     0x9fe8a0: ldr             x16, [PP, #0x77a8]  ; [pp+0x77a8] "org.freedesktop.DBus.Error.PropertyReadOnly"
    // 0x9fe8a4: ldur            lr, [fp, #-0x18]
    // 0x9fe8a8: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe8ac: r0 = ==()
    //     0x9fe8ac: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe8b0: add             SP, SP, #0x10
    // 0x9fe8b4: tbz             w0, #4, #0x9fead8
    // 0x9fe8b8: ldur            x0, [fp, #-0x10]
    // 0x9fe8bc: r16 = "org.freedesktop.DBus.Error.PropertyWriteOnly"
    //     0x9fe8bc: ldr             x16, [PP, #0x77b0]  ; [pp+0x77b0] "org.freedesktop.DBus.Error.PropertyWriteOnly"
    // 0x9fe8c0: ldur            lr, [fp, #-0x18]
    // 0x9fe8c4: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe8c8: r0 = ==()
    //     0x9fe8c8: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe8cc: add             SP, SP, #0x10
    // 0x9fe8d0: tbz             w0, #4, #0x9feaf8
    // 0x9fe8d4: ldur            x0, [fp, #-0x10]
    // 0x9fe8d8: r16 = "org.freedesktop.DBus.Error.NotSupported"
    //     0x9fe8d8: ldr             x16, [PP, #0x77b8]  ; [pp+0x77b8] "org.freedesktop.DBus.Error.NotSupported"
    // 0x9fe8dc: ldur            lr, [fp, #-0x18]
    // 0x9fe8e0: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe8e4: r0 = ==()
    //     0x9fe8e4: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe8e8: add             SP, SP, #0x10
    // 0x9fe8ec: tbz             w0, #4, #0x9feb18
    // 0x9fe8f0: ldur            x0, [fp, #-0x10]
    // 0x9fe8f4: r16 = "org.freedesktop.DBus.Error.AccessDenied"
    //     0x9fe8f4: ldr             x16, [PP, #0x77c0]  ; [pp+0x77c0] "org.freedesktop.DBus.Error.AccessDenied"
    // 0x9fe8f8: ldur            lr, [fp, #-0x18]
    // 0x9fe8fc: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe900: r0 = ==()
    //     0x9fe900: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe904: add             SP, SP, #0x10
    // 0x9fe908: tbz             w0, #4, #0x9feb38
    // 0x9fe90c: ldur            x0, [fp, #-0x10]
    // 0x9fe910: r16 = "org.freedesktop.DBus.Error.AuthFailed"
    //     0x9fe910: ldr             x16, [PP, #0x77c8]  ; [pp+0x77c8] "org.freedesktop.DBus.Error.AuthFailed"
    // 0x9fe914: ldur            lr, [fp, #-0x18]
    // 0x9fe918: stp             lr, x16, [SP, #-0x10]!
    // 0x9fe91c: r0 = ==()
    //     0x9fe91c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x9fe920: add             SP, SP, #0x10
    // 0x9fe924: tbnz            w0, #4, #0x9feb78
    // 0x9fe928: b               #0x9feb58
    // 0x9fe92c: ldur            x3, [fp, #-0x28]
    // 0x9fe930: LoadField: r4 = r0->field_7
    //     0x9fe930: ldur            w4, [x0, #7]
    // 0x9fe934: DecompressPointer r4
    //     0x9fe934: add             x4, x4, HEAP, lsl #32
    // 0x9fe938: stur            x4, [fp, #-0x18]
    // 0x9fe93c: r1 = Null
    //     0x9fe93c: mov             x1, NULL
    // 0x9fe940: r2 = 6
    //     0x9fe940: mov             x2, #6
    // 0x9fe944: r0 = AllocateArray()
    //     0x9fe944: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9fe948: mov             x1, x0
    // 0x9fe94c: ldur            x0, [fp, #-0x18]
    // 0x9fe950: StoreField: r1->field_f = r0
    //     0x9fe950: stur            w0, [x1, #0xf]
    // 0x9fe954: r17 = "."
    //     0x9fe954: ldr             x17, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0x9fe958: StoreField: r1->field_13 = r17
    //     0x9fe958: stur            w17, [x1, #0x13]
    // 0x9fe95c: ldur            x0, [fp, #-0x28]
    // 0x9fe960: LoadField: r2 = r0->field_7
    //     0x9fe960: ldur            w2, [x0, #7]
    // 0x9fe964: DecompressPointer r2
    //     0x9fe964: add             x2, x2, HEAP, lsl #32
    // 0x9fe968: StoreField: r1->field_17 = r2
    //     0x9fe968: stur            w2, [x1, #0x17]
    // 0x9fe96c: SaveReg r1
    //     0x9fe96c: str             x1, [SP, #-8]!
    // 0x9fe970: r0 = _interpolate()
    //     0x9fe970: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x9fe974: add             SP, SP, #8
    // 0x9fe978: mov             x1, x0
    // 0x9fe97c: b               #0x9fe98c
    // 0x9fe980: ldur            x0, [fp, #-0x28]
    // 0x9fe984: LoadField: r1 = r0->field_7
    //     0x9fe984: ldur            w1, [x0, #7]
    // 0x9fe988: DecompressPointer r1
    //     0x9fe988: add             x1, x1, HEAP, lsl #32
    // 0x9fe98c: ldur            x0, [fp, #-0x10]
    // 0x9fe990: stur            x1, [fp, #-0x18]
    // 0x9fe994: r0 = DBusReplySignatureException()
    //     0x9fe994: bl              #0x9fec8c  ; AllocateDBusReplySignatureExceptionStub -> DBusReplySignatureException (size=0x10)
    // 0x9fe998: mov             x1, x0
    // 0x9fe99c: ldur            x0, [fp, #-0x18]
    // 0x9fe9a0: StoreField: r1->field_7 = r0
    //     0x9fe9a0: stur            w0, [x1, #7]
    // 0x9fe9a4: ldur            x0, [fp, #-0x10]
    // 0x9fe9a8: StoreField: r1->field_b = r0
    //     0x9fe9a8: stur            w0, [x1, #0xb]
    // 0x9fe9ac: mov             x0, x1
    // 0x9fe9b0: r0 = Throw()
    //     0x9fe9b0: bl              #0xd67e38  ; ThrowStub
    // 0x9fe9b4: brk             #0
    // 0x9fe9b8: ldur            x0, [fp, #-0x10]
    // 0x9fe9bc: r0 = DBusFailedException()
    //     0x9fe9bc: bl              #0x9fec80  ; AllocateDBusFailedExceptionStub -> DBusFailedException (size=0xc)
    // 0x9fe9c0: mov             x1, x0
    // 0x9fe9c4: ldur            x0, [fp, #-0x10]
    // 0x9fe9c8: StoreField: r1->field_7 = r0
    //     0x9fe9c8: stur            w0, [x1, #7]
    // 0x9fe9cc: mov             x0, x1
    // 0x9fe9d0: r0 = Throw()
    //     0x9fe9d0: bl              #0xd67e38  ; ThrowStub
    // 0x9fe9d4: brk             #0
    // 0x9fe9d8: ldur            x0, [fp, #-0x10]
    // 0x9fe9dc: r0 = DBusServiceUnknownException()
    //     0x9fe9dc: bl              #0x9fec74  ; AllocateDBusServiceUnknownExceptionStub -> DBusServiceUnknownException (size=0xc)
    // 0x9fe9e0: mov             x1, x0
    // 0x9fe9e4: ldur            x0, [fp, #-0x10]
    // 0x9fe9e8: StoreField: r1->field_7 = r0
    //     0x9fe9e8: stur            w0, [x1, #7]
    // 0x9fe9ec: mov             x0, x1
    // 0x9fe9f0: r0 = Throw()
    //     0x9fe9f0: bl              #0xd67e38  ; ThrowStub
    // 0x9fe9f4: brk             #0
    // 0x9fe9f8: ldur            x0, [fp, #-0x10]
    // 0x9fe9fc: r0 = DBusUnknownObjectException()
    //     0x9fe9fc: bl              #0x9fec68  ; AllocateDBusUnknownObjectExceptionStub -> DBusUnknownObjectException (size=0xc)
    // 0x9fea00: mov             x1, x0
    // 0x9fea04: ldur            x0, [fp, #-0x10]
    // 0x9fea08: StoreField: r1->field_7 = r0
    //     0x9fea08: stur            w0, [x1, #7]
    // 0x9fea0c: mov             x0, x1
    // 0x9fea10: r0 = Throw()
    //     0x9fea10: bl              #0xd67e38  ; ThrowStub
    // 0x9fea14: brk             #0
    // 0x9fea18: ldur            x0, [fp, #-0x10]
    // 0x9fea1c: r0 = DBusUnknownInterfaceException()
    //     0x9fea1c: bl              #0x9fec5c  ; AllocateDBusUnknownInterfaceExceptionStub -> DBusUnknownInterfaceException (size=0xc)
    // 0x9fea20: mov             x1, x0
    // 0x9fea24: ldur            x0, [fp, #-0x10]
    // 0x9fea28: StoreField: r1->field_7 = r0
    //     0x9fea28: stur            w0, [x1, #7]
    // 0x9fea2c: mov             x0, x1
    // 0x9fea30: r0 = Throw()
    //     0x9fea30: bl              #0xd67e38  ; ThrowStub
    // 0x9fea34: brk             #0
    // 0x9fea38: ldur            x0, [fp, #-0x10]
    // 0x9fea3c: r0 = DBusUnknownMethodException()
    //     0x9fea3c: bl              #0x9fec50  ; AllocateDBusUnknownMethodExceptionStub -> DBusUnknownMethodException (size=0xc)
    // 0x9fea40: mov             x1, x0
    // 0x9fea44: ldur            x0, [fp, #-0x10]
    // 0x9fea48: StoreField: r1->field_7 = r0
    //     0x9fea48: stur            w0, [x1, #7]
    // 0x9fea4c: mov             x0, x1
    // 0x9fea50: r0 = Throw()
    //     0x9fea50: bl              #0xd67e38  ; ThrowStub
    // 0x9fea54: brk             #0
    // 0x9fea58: ldur            x0, [fp, #-0x10]
    // 0x9fea5c: r0 = DBusTimeoutException()
    //     0x9fea5c: bl              #0x9fec44  ; AllocateDBusTimeoutExceptionStub -> DBusTimeoutException (size=0xc)
    // 0x9fea60: mov             x1, x0
    // 0x9fea64: ldur            x0, [fp, #-0x10]
    // 0x9fea68: StoreField: r1->field_7 = r0
    //     0x9fea68: stur            w0, [x1, #7]
    // 0x9fea6c: mov             x0, x1
    // 0x9fea70: r0 = Throw()
    //     0x9fea70: bl              #0xd67e38  ; ThrowStub
    // 0x9fea74: brk             #0
    // 0x9fea78: ldur            x0, [fp, #-0x10]
    // 0x9fea7c: r0 = DBusTimedOutException()
    //     0x9fea7c: bl              #0x9fec38  ; AllocateDBusTimedOutExceptionStub -> DBusTimedOutException (size=0xc)
    // 0x9fea80: mov             x1, x0
    // 0x9fea84: ldur            x0, [fp, #-0x10]
    // 0x9fea88: StoreField: r1->field_7 = r0
    //     0x9fea88: stur            w0, [x1, #7]
    // 0x9fea8c: mov             x0, x1
    // 0x9fea90: r0 = Throw()
    //     0x9fea90: bl              #0xd67e38  ; ThrowStub
    // 0x9fea94: brk             #0
    // 0x9fea98: ldur            x0, [fp, #-0x10]
    // 0x9fea9c: r0 = DBusInvalidArgsException()
    //     0x9fea9c: bl              #0x9fec2c  ; AllocateDBusInvalidArgsExceptionStub -> DBusInvalidArgsException (size=0xc)
    // 0x9feaa0: mov             x1, x0
    // 0x9feaa4: ldur            x0, [fp, #-0x10]
    // 0x9feaa8: StoreField: r1->field_7 = r0
    //     0x9feaa8: stur            w0, [x1, #7]
    // 0x9feaac: mov             x0, x1
    // 0x9feab0: r0 = Throw()
    //     0x9feab0: bl              #0xd67e38  ; ThrowStub
    // 0x9feab4: brk             #0
    // 0x9feab8: ldur            x0, [fp, #-0x10]
    // 0x9feabc: r0 = DBusUnknownPropertyException()
    //     0x9feabc: bl              #0x9fec20  ; AllocateDBusUnknownPropertyExceptionStub -> DBusUnknownPropertyException (size=0xc)
    // 0x9feac0: mov             x1, x0
    // 0x9feac4: ldur            x0, [fp, #-0x10]
    // 0x9feac8: StoreField: r1->field_7 = r0
    //     0x9feac8: stur            w0, [x1, #7]
    // 0x9feacc: mov             x0, x1
    // 0x9fead0: r0 = Throw()
    //     0x9fead0: bl              #0xd67e38  ; ThrowStub
    // 0x9fead4: brk             #0
    // 0x9fead8: ldur            x0, [fp, #-0x10]
    // 0x9feadc: r0 = DBusPropertyReadOnlyException()
    //     0x9feadc: bl              #0x9fec14  ; AllocateDBusPropertyReadOnlyExceptionStub -> DBusPropertyReadOnlyException (size=0xc)
    // 0x9feae0: mov             x1, x0
    // 0x9feae4: ldur            x0, [fp, #-0x10]
    // 0x9feae8: StoreField: r1->field_7 = r0
    //     0x9feae8: stur            w0, [x1, #7]
    // 0x9feaec: mov             x0, x1
    // 0x9feaf0: r0 = Throw()
    //     0x9feaf0: bl              #0xd67e38  ; ThrowStub
    // 0x9feaf4: brk             #0
    // 0x9feaf8: ldur            x0, [fp, #-0x10]
    // 0x9feafc: r0 = DBusPropertyWriteOnlyException()
    //     0x9feafc: bl              #0x9fec08  ; AllocateDBusPropertyWriteOnlyExceptionStub -> DBusPropertyWriteOnlyException (size=0xc)
    // 0x9feb00: mov             x1, x0
    // 0x9feb04: ldur            x0, [fp, #-0x10]
    // 0x9feb08: StoreField: r1->field_7 = r0
    //     0x9feb08: stur            w0, [x1, #7]
    // 0x9feb0c: mov             x0, x1
    // 0x9feb10: r0 = Throw()
    //     0x9feb10: bl              #0xd67e38  ; ThrowStub
    // 0x9feb14: brk             #0
    // 0x9feb18: ldur            x0, [fp, #-0x10]
    // 0x9feb1c: r0 = DBusNotSupportedException()
    //     0x9feb1c: bl              #0x9febfc  ; AllocateDBusNotSupportedExceptionStub -> DBusNotSupportedException (size=0xc)
    // 0x9feb20: mov             x1, x0
    // 0x9feb24: ldur            x0, [fp, #-0x10]
    // 0x9feb28: StoreField: r1->field_7 = r0
    //     0x9feb28: stur            w0, [x1, #7]
    // 0x9feb2c: mov             x0, x1
    // 0x9feb30: r0 = Throw()
    //     0x9feb30: bl              #0xd67e38  ; ThrowStub
    // 0x9feb34: brk             #0
    // 0x9feb38: ldur            x0, [fp, #-0x10]
    // 0x9feb3c: r0 = DBusAccessDeniedException()
    //     0x9feb3c: bl              #0x9febf0  ; AllocateDBusAccessDeniedExceptionStub -> DBusAccessDeniedException (size=0xc)
    // 0x9feb40: mov             x1, x0
    // 0x9feb44: ldur            x0, [fp, #-0x10]
    // 0x9feb48: StoreField: r1->field_7 = r0
    //     0x9feb48: stur            w0, [x1, #7]
    // 0x9feb4c: mov             x0, x1
    // 0x9feb50: r0 = Throw()
    //     0x9feb50: bl              #0xd67e38  ; ThrowStub
    // 0x9feb54: brk             #0
    // 0x9feb58: ldur            x0, [fp, #-0x10]
    // 0x9feb5c: r0 = DBusAuthFailedException()
    //     0x9feb5c: bl              #0x9febe4  ; AllocateDBusAuthFailedExceptionStub -> DBusAuthFailedException (size=0xc)
    // 0x9feb60: mov             x1, x0
    // 0x9feb64: ldur            x0, [fp, #-0x10]
    // 0x9feb68: StoreField: r1->field_7 = r0
    //     0x9feb68: stur            w0, [x1, #7]
    // 0x9feb6c: mov             x0, x1
    // 0x9feb70: r0 = Throw()
    //     0x9feb70: bl              #0xd67e38  ; ThrowStub
    // 0x9feb74: brk             #0
    // 0x9feb78: ldur            x0, [fp, #-0x10]
    // 0x9feb7c: r0 = DBusErrorException()
    //     0x9feb7c: bl              #0x9febd8  ; AllocateDBusErrorExceptionStub -> DBusErrorException (size=0xc)
    // 0x9feb80: mov             x1, x0
    // 0x9feb84: ldur            x0, [fp, #-0x10]
    // 0x9feb88: StoreField: r1->field_7 = r0
    //     0x9feb88: stur            w0, [x1, #7]
    // 0x9feb8c: mov             x0, x1
    // 0x9feb90: r0 = Throw()
    //     0x9feb90: bl              #0xd67e38  ; ThrowStub
    // 0x9feb94: brk             #0
    // 0x9feb98: ldur            x0, [fp, #-0x10]
    // 0x9feb9c: r0 = DBusMethodResponseException()
    //     0x9feb9c: bl              #0x9febcc  ; AllocateDBusMethodResponseExceptionStub -> DBusMethodResponseException (size=0xc)
    // 0x9feba0: mov             x1, x0
    // 0x9feba4: ldur            x0, [fp, #-0x10]
    // 0x9feba8: StoreField: r1->field_7 = r0
    //     0x9feba8: stur            w0, [x1, #7]
    // 0x9febac: mov             x0, x1
    // 0x9febb0: r0 = Throw()
    //     0x9febb0: bl              #0xd67e38  ; ThrowStub
    // 0x9febb4: brk             #0
    // 0x9febb8: r0 = "Unknown response type"
    //     0x9febb8: ldr             x0, [PP, #0x77d0]  ; [pp+0x77d0] "Unknown response type"
    // 0x9febbc: r0 = Throw()
    //     0x9febbc: bl              #0xd67e38  ; ThrowStub
    // 0x9febc0: brk             #0
    // 0x9febc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9febc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9febc8: b               #0x9fe544
  }
  _ _sendMessage(/* No info */) {
    // ** addr: 0x9ff070, size: 0x190
    // 0x9ff070: EnterFrame
    //     0x9ff070: stp             fp, lr, [SP, #-0x10]!
    //     0x9ff074: mov             fp, SP
    // 0x9ff078: AllocStack(0x20)
    //     0x9ff078: sub             SP, SP, #0x20
    // 0x9ff07c: CheckStackOverflow
    //     0x9ff07c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ff080: cmp             SP, x16
    //     0x9ff084: b.ls            #0x9ff1f4
    // 0x9ff088: ldr             x0, [fp, #0x18]
    // 0x9ff08c: LoadField: r1 = r0->field_f
    //     0x9ff08c: ldur            w1, [x0, #0xf]
    // 0x9ff090: DecompressPointer r1
    //     0x9ff090: add             x1, x1, HEAP, lsl #32
    // 0x9ff094: tbz             w1, #4, #0x9ff1e8
    // 0x9ff098: r0 = DBusWriteBuffer()
    //     0x9ff098: bl              #0xa02004  ; AllocateDBusWriteBufferStub -> DBusWriteBuffer (size=0x98)
    // 0x9ff09c: stur            x0, [fp, #-8]
    // 0x9ff0a0: SaveReg r0
    //     0x9ff0a0: str             x0, [SP, #-8]!
    // 0x9ff0a4: r0 = DBusWriteBuffer()
    //     0x9ff0a4: bl              #0xa01f24  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::DBusWriteBuffer
    // 0x9ff0a8: add             SP, SP, #8
    // 0x9ff0ac: ldur            x16, [fp, #-8]
    // 0x9ff0b0: ldr             lr, [fp, #0x10]
    // 0x9ff0b4: stp             lr, x16, [SP, #-0x10]!
    // 0x9ff0b8: r0 = writeMessage()
    //     0x9ff0b8: bl              #0x9ff33c  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeMessage
    // 0x9ff0bc: add             SP, SP, #0x10
    // 0x9ff0c0: r16 = <SocketControlMessage>
    //     0x9ff0c0: ldr             x16, [PP, #0x77e8]  ; [pp+0x77e8] TypeArguments: <SocketControlMessage>
    // 0x9ff0c4: stp             xzr, x16, [SP, #-0x10]!
    // 0x9ff0c8: r0 = _GrowableList()
    //     0x9ff0c8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ff0cc: add             SP, SP, #0x10
    // 0x9ff0d0: mov             x1, x0
    // 0x9ff0d4: ldur            x0, [fp, #-8]
    // 0x9ff0d8: stur            x1, [fp, #-0x10]
    // 0x9ff0dc: LoadField: r2 = r0->field_93
    //     0x9ff0dc: ldur            w2, [x0, #0x93]
    // 0x9ff0e0: DecompressPointer r2
    //     0x9ff0e0: add             x2, x2, HEAP, lsl #32
    // 0x9ff0e4: LoadField: r3 = r2->field_b
    //     0x9ff0e4: ldur            w3, [x2, #0xb]
    // 0x9ff0e8: DecompressPointer r3
    //     0x9ff0e8: add             x3, x3, HEAP, lsl #32
    // 0x9ff0ec: cbz             w3, #0x9ff194
    // 0x9ff0f0: stp             x2, NULL, [SP, #-0x10]!
    // 0x9ff0f4: r0 = SocketControlMessage.fromHandles()
    //     0x9ff0f4: bl              #0x9ff20c  ; [dart:io] SocketControlMessage::SocketControlMessage.fromHandles
    // 0x9ff0f8: add             SP, SP, #0x10
    // 0x9ff0fc: mov             x1, x0
    // 0x9ff100: ldur            x0, [fp, #-0x10]
    // 0x9ff104: stur            x1, [fp, #-0x20]
    // 0x9ff108: LoadField: r2 = r0->field_b
    //     0x9ff108: ldur            w2, [x0, #0xb]
    // 0x9ff10c: DecompressPointer r2
    //     0x9ff10c: add             x2, x2, HEAP, lsl #32
    // 0x9ff110: stur            x2, [fp, #-0x18]
    // 0x9ff114: LoadField: r3 = r0->field_f
    //     0x9ff114: ldur            w3, [x0, #0xf]
    // 0x9ff118: DecompressPointer r3
    //     0x9ff118: add             x3, x3, HEAP, lsl #32
    // 0x9ff11c: LoadField: r4 = r3->field_b
    //     0x9ff11c: ldur            w4, [x3, #0xb]
    // 0x9ff120: DecompressPointer r4
    //     0x9ff120: add             x4, x4, HEAP, lsl #32
    // 0x9ff124: cmp             w2, w4
    // 0x9ff128: b.ne            #0x9ff138
    // 0x9ff12c: SaveReg r0
    //     0x9ff12c: str             x0, [SP, #-8]!
    // 0x9ff130: r0 = _growToNextCapacity()
    //     0x9ff130: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ff134: add             SP, SP, #8
    // 0x9ff138: ldur            x2, [fp, #-0x10]
    // 0x9ff13c: ldur            x0, [fp, #-0x18]
    // 0x9ff140: r3 = LoadInt32Instr(r0)
    //     0x9ff140: sbfx            x3, x0, #1, #0x1f
    // 0x9ff144: add             x0, x3, #1
    // 0x9ff148: lsl             x1, x0, #1
    // 0x9ff14c: StoreField: r2->field_b = r1
    //     0x9ff14c: stur            w1, [x2, #0xb]
    // 0x9ff150: mov             x1, x3
    // 0x9ff154: cmp             x1, x0
    // 0x9ff158: b.hs            #0x9ff1fc
    // 0x9ff15c: LoadField: r1 = r2->field_f
    //     0x9ff15c: ldur            w1, [x2, #0xf]
    // 0x9ff160: DecompressPointer r1
    //     0x9ff160: add             x1, x1, HEAP, lsl #32
    // 0x9ff164: ldur            x0, [fp, #-0x20]
    // 0x9ff168: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ff168: add             x25, x1, x3, lsl #2
    //     0x9ff16c: add             x25, x25, #0xf
    //     0x9ff170: str             w0, [x25]
    //     0x9ff174: tbz             w0, #0, #0x9ff190
    //     0x9ff178: ldurb           w16, [x1, #-1]
    //     0x9ff17c: ldurb           w17, [x0, #-1]
    //     0x9ff180: and             x16, x17, x16, lsr #2
    //     0x9ff184: tst             x16, HEAP, lsr #32
    //     0x9ff188: b.eq            #0x9ff190
    //     0x9ff18c: bl              #0xd67e5c
    // 0x9ff190: b               #0x9ff198
    // 0x9ff194: mov             x2, x1
    // 0x9ff198: ldr             x0, [fp, #0x18]
    // 0x9ff19c: LoadField: r1 = r0->field_b
    //     0x9ff19c: ldur            w1, [x0, #0xb]
    // 0x9ff1a0: DecompressPointer r1
    //     0x9ff1a0: add             x1, x1, HEAP, lsl #32
    // 0x9ff1a4: cmp             w1, NULL
    // 0x9ff1a8: b.eq            #0x9ff1d8
    // 0x9ff1ac: ldur            x0, [fp, #-8]
    // 0x9ff1b0: LoadField: r3 = r0->field_8f
    //     0x9ff1b0: ldur            w3, [x0, #0x8f]
    // 0x9ff1b4: DecompressPointer r3
    //     0x9ff1b4: add             x3, x3, HEAP, lsl #32
    // 0x9ff1b8: r0 = LoadClassIdInstr(r1)
    //     0x9ff1b8: ldur            x0, [x1, #-1]
    //     0x9ff1bc: ubfx            x0, x0, #0xc, #0x14
    // 0x9ff1c0: stp             x2, x1, [SP, #-0x10]!
    // 0x9ff1c4: SaveReg r3
    //     0x9ff1c4: str             x3, [SP, #-8]!
    // 0x9ff1c8: r0 = GDT[cid_x0 + -0xd58]()
    //     0x9ff1c8: sub             lr, x0, #0xd58
    //     0x9ff1cc: ldr             lr, [x21, lr, lsl #3]
    //     0x9ff1d0: blr             lr
    // 0x9ff1d4: add             SP, SP, #0x18
    // 0x9ff1d8: r0 = Null
    //     0x9ff1d8: mov             x0, NULL
    // 0x9ff1dc: LeaveFrame
    //     0x9ff1dc: mov             SP, fp
    //     0x9ff1e0: ldp             fp, lr, [SP], #0x10
    // 0x9ff1e4: ret
    //     0x9ff1e4: ret             
    // 0x9ff1e8: r0 = DBusClosedException()
    //     0x9ff1e8: bl              #0x9ff200  ; AllocateDBusClosedExceptionStub -> DBusClosedException (size=0x8)
    // 0x9ff1ec: r0 = Throw()
    //     0x9ff1ec: bl              #0xd67e38  ; ThrowStub
    // 0x9ff1f0: brk             #0
    // 0x9ff1f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ff1f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ff1f8: b               #0x9ff088
    // 0x9ff1fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9ff1fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _connect(/* No info */) async {
    // ** addr: 0xa02724, size: 0x450
    // 0xa02724: EnterFrame
    //     0xa02724: stp             fp, lr, [SP, #-0x10]!
    //     0xa02728: mov             fp, SP
    // 0xa0272c: AllocStack(0x40)
    //     0xa0272c: sub             SP, SP, #0x40
    // 0xa02730: SetupParameters(DBusClient this /* r1, fp-0x10 */)
    //     0xa02730: stur            NULL, [fp, #-8]
    //     0xa02734: mov             x0, #0
    //     0xa02738: add             x1, fp, w0, sxtw #2
    //     0xa0273c: ldr             x1, [x1, #0x10]
    //     0xa02740: stur            x1, [fp, #-0x10]
    // 0xa02744: CheckStackOverflow
    //     0xa02744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa02748: cmp             SP, x16
    //     0xa0274c: b.ls            #0xa02b6c
    // 0xa02750: r1 = 1
    //     0xa02750: mov             x1, #1
    // 0xa02754: r0 = AllocateContext()
    //     0xa02754: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa02758: mov             x2, x0
    // 0xa0275c: ldur            x1, [fp, #-0x10]
    // 0xa02760: stur            x2, [fp, #-0x18]
    // 0xa02764: StoreField: r2->field_f = r1
    //     0xa02764: stur            w1, [x2, #0xf]
    // 0xa02768: InitAsync() -> Future<void?>
    //     0xa02768: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa0276c: bl              #0x4b92e4
    // 0xa02770: ldur            x0, [fp, #-0x10]
    // 0xa02774: LoadField: r1 = r0->field_1f
    //     0xa02774: ldur            w1, [x0, #0x1f]
    // 0xa02778: DecompressPointer r1
    //     0xa02778: add             x1, x1, HEAP, lsl #32
    // 0xa0277c: cmp             w1, NULL
    // 0xa02780: b.eq            #0xa02790
    // 0xa02784: LoadField: r0 = r1->field_b
    //     0xa02784: ldur            w0, [x1, #0xb]
    // 0xa02788: DecompressPointer r0
    //     0xa02788: add             x0, x0, HEAP, lsl #32
    // 0xa0278c: r0 = ReturnAsync()
    //     0xa0278c: b               #0x501858  ; ReturnAsyncStub
    // 0xa02790: r1 = Null
    //     0xa02790: mov             x1, NULL
    // 0xa02794: r0 = _Future()
    //     0xa02794: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xa02798: mov             x1, x0
    // 0xa0279c: r0 = 0
    //     0xa0279c: mov             x0, #0
    // 0xa027a0: stur            x1, [fp, #-0x20]
    // 0xa027a4: StoreField: r1->field_b = r0
    //     0xa027a4: stur            x0, [x1, #0xb]
    // 0xa027a8: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xa027a8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa027ac: ldr             x0, [x0, #0xb58]
    //     0xa027b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa027b4: cmp             w0, w16
    //     0xa027b8: b.ne            #0xa027c4
    //     0xa027bc: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xa027c0: bl              #0xd67d44
    // 0xa027c4: mov             x1, x0
    // 0xa027c8: ldur            x0, [fp, #-0x20]
    // 0xa027cc: StoreField: r0->field_13 = r1
    //     0xa027cc: stur            w1, [x0, #0x13]
    // 0xa027d0: r1 = Null
    //     0xa027d0: mov             x1, NULL
    // 0xa027d4: r0 = _AsyncCompleter()
    //     0xa027d4: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xa027d8: mov             x1, x0
    // 0xa027dc: ldur            x0, [fp, #-0x20]
    // 0xa027e0: StoreField: r1->field_b = r0
    //     0xa027e0: stur            w0, [x1, #0xb]
    // 0xa027e4: mov             x0, x1
    // 0xa027e8: ldur            x1, [fp, #-0x10]
    // 0xa027ec: StoreField: r1->field_1f = r0
    //     0xa027ec: stur            w0, [x1, #0x1f]
    //     0xa027f0: ldurb           w16, [x1, #-1]
    //     0xa027f4: ldurb           w17, [x0, #-1]
    //     0xa027f8: and             x16, x17, x16, lsr #2
    //     0xa027fc: tst             x16, HEAP, lsr #32
    //     0xa02800: b.eq            #0xa02808
    //     0xa02804: bl              #0xd6826c
    // 0xa02808: SaveReg r1
    //     0xa02808: str             x1, [SP, #-8]!
    // 0xa0280c: r0 = _openSocket()
    //     0xa0280c: bl              #0xa03550  ; [package:dbus/src/dbus_client.dart] DBusClient::_openSocket
    // 0xa02810: add             SP, SP, #8
    // 0xa02814: mov             x1, x0
    // 0xa02818: stur            x1, [fp, #-0x20]
    // 0xa0281c: r0 = Await()
    //     0xa0281c: bl              #0x4b8e6c  ; AwaitStub
    // 0xa02820: ldur            x0, [fp, #-0x10]
    // 0xa02824: LoadField: r1 = r0->field_17
    //     0xa02824: ldur            w1, [x0, #0x17]
    // 0xa02828: DecompressPointer r1
    //     0xa02828: add             x1, x1, HEAP, lsl #32
    // 0xa0282c: stur            x1, [fp, #-0x20]
    // 0xa02830: SaveReg r1
    //     0xa02830: str             x1, [SP, #-8]!
    // 0xa02834: r0 = requests()
    //     0xa02834: bl              #0xa03514  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::requests
    // 0xa02838: add             SP, SP, #8
    // 0xa0283c: ldur            x2, [fp, #-0x18]
    // 0xa02840: r1 = Function '<anonymous closure>':.
    //     0xa02840: ldr             x1, [PP, #0x7920]  ; [pp+0x7920] AnonymousClosure: (0xa0e080), in [package:dbus/src/dbus_client.dart] DBusClient::_connect (0xa02724)
    // 0xa02844: stur            x0, [fp, #-0x28]
    // 0xa02848: r0 = AllocateClosure()
    //     0xa02848: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0284c: ldur            x16, [fp, #-0x28]
    // 0xa02850: stp             x0, x16, [SP, #-0x10]!
    // 0xa02854: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa02854: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa02858: r0 = listen()
    //     0xa02858: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xa0285c: add             SP, SP, #0x10
    // 0xa02860: ldur            x1, [fp, #-0x20]
    // 0xa02864: LoadField: r0 = r1->field_7
    //     0xa02864: ldur            w0, [x1, #7]
    // 0xa02868: DecompressPointer r0
    //     0xa02868: add             x0, x0, HEAP, lsl #32
    // 0xa0286c: LoadField: r2 = r0->field_b
    //     0xa0286c: ldur            w2, [x0, #0xb]
    // 0xa02870: DecompressPointer r2
    //     0xa02870: add             x2, x2, HEAP, lsl #32
    // 0xa02874: mov             x0, x2
    // 0xa02878: stur            x2, [fp, #-0x28]
    // 0xa0287c: r0 = Await()
    //     0xa0287c: bl              #0x4b8e6c  ; AwaitStub
    // 0xa02880: ldur            x0, [fp, #-0x10]
    // 0xa02884: r1 = true
    //     0xa02884: add             x1, NULL, #0x20  ; true
    // 0xa02888: StoreField: r0->field_1b = r1
    //     0xa02888: stur            w1, [x0, #0x1b]
    // 0xa0288c: ldur            x1, [fp, #-0x20]
    // 0xa02890: LoadField: r2 = r1->field_13
    //     0xa02890: ldur            w2, [x1, #0x13]
    // 0xa02894: DecompressPointer r2
    //     0xa02894: add             x2, x2, HEAP, lsl #32
    // 0xa02898: tbz             w2, #4, #0xa028e8
    // 0xa0289c: LoadField: r1 = r0->field_b
    //     0xa0289c: ldur            w1, [x0, #0xb]
    // 0xa028a0: DecompressPointer r1
    //     0xa028a0: add             x1, x1, HEAP, lsl #32
    // 0xa028a4: cmp             w1, NULL
    // 0xa028a8: b.ne            #0xa028b4
    // 0xa028ac: r1 = Null
    //     0xa028ac: mov             x1, NULL
    // 0xa028b0: b               #0xa028d4
    // 0xa028b4: r0 = LoadClassIdInstr(r1)
    //     0xa028b4: ldur            x0, [x1, #-1]
    //     0xa028b8: ubfx            x0, x0, #0xc, #0x14
    // 0xa028bc: SaveReg r1
    //     0xa028bc: str             x1, [SP, #-8]!
    // 0xa028c0: r0 = GDT[cid_x0 + -0xfec]()
    //     0xa028c0: sub             lr, x0, #0xfec
    //     0xa028c4: ldr             lr, [x21, lr, lsl #3]
    //     0xa028c8: blr             lr
    // 0xa028cc: add             SP, SP, #8
    // 0xa028d0: mov             x1, x0
    // 0xa028d4: mov             x0, x1
    // 0xa028d8: stur            x1, [fp, #-0x20]
    // 0xa028dc: r0 = Await()
    //     0xa028dc: bl              #0x4b8e6c  ; AwaitStub
    // 0xa028e0: r0 = Null
    //     0xa028e0: mov             x0, NULL
    // 0xa028e4: r0 = ReturnAsyncNotFuture()
    //     0xa028e4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa028e8: r0 = DBusBusName()
    //     0xa028e8: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0xa028ec: stur            x0, [fp, #-0x20]
    // 0xa028f0: r16 = "org.freedesktop.DBus"
    //     0xa028f0: ldr             x16, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xa028f4: stp             x16, x0, [SP, #-0x10]!
    // 0xa028f8: r0 = DBusBusName()
    //     0xa028f8: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0xa028fc: add             SP, SP, #0x10
    // 0xa02900: r0 = DBusObjectPath()
    //     0xa02900: bl              #0x9fce70  ; AllocateDBusObjectPathStub -> DBusObjectPath (size=0xc)
    // 0xa02904: stur            x0, [fp, #-0x28]
    // 0xa02908: r16 = "/org/freedesktop/DBus"
    //     0xa02908: ldr             x16, [PP, #0x76f8]  ; [pp+0x76f8] "/org/freedesktop/DBus"
    // 0xa0290c: stp             x16, x0, [SP, #-0x10]!
    // 0xa02910: r0 = DBusObjectPath()
    //     0xa02910: bl              #0x9fcc00  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::DBusObjectPath
    // 0xa02914: add             SP, SP, #0x10
    // 0xa02918: r0 = DBusInterfaceName()
    //     0xa02918: bl              #0xa023bc  ; AllocateDBusInterfaceNameStub -> DBusInterfaceName (size=0xc)
    // 0xa0291c: stur            x0, [fp, #-0x30]
    // 0xa02920: r16 = "org.freedesktop.DBus"
    //     0xa02920: ldr             x16, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xa02924: stp             x16, x0, [SP, #-0x10]!
    // 0xa02928: r0 = DBusInterfaceName()
    //     0xa02928: bl              #0xa0212c  ; [package:dbus/src/dbus_interface_name.dart] DBusInterfaceName::DBusInterfaceName
    // 0xa0292c: add             SP, SP, #0x10
    // 0xa02930: r0 = DBusMemberName()
    //     0xa02930: bl              #0xa02120  ; AllocateDBusMemberNameStub -> DBusMemberName (size=0xc)
    // 0xa02934: stur            x0, [fp, #-0x38]
    // 0xa02938: r16 = "Hello"
    //     0xa02938: ldr             x16, [PP, #0x7928]  ; [pp+0x7928] "Hello"
    // 0xa0293c: stp             x16, x0, [SP, #-0x10]!
    // 0xa02940: r0 = DBusMemberName()
    //     0xa02940: bl              #0xa0201c  ; [package:dbus/src/dbus_member_name.dart] DBusMemberName::DBusMemberName
    // 0xa02944: add             SP, SP, #0x10
    // 0xa02948: r0 = DBusSignature()
    //     0xa02948: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa0294c: stur            x0, [fp, #-0x40]
    // 0xa02950: r16 = "s"
    //     0xa02950: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa02954: stp             x16, x0, [SP, #-0x10]!
    // 0xa02958: r0 = DBusSignature()
    //     0xa02958: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa0295c: add             SP, SP, #0x10
    // 0xa02960: ldur            x16, [fp, #-0x10]
    // 0xa02964: ldur            lr, [fp, #-0x20]
    // 0xa02968: stp             lr, x16, [SP, #-0x10]!
    // 0xa0296c: ldur            x16, [fp, #-0x30]
    // 0xa02970: ldur            lr, [fp, #-0x38]
    // 0xa02974: stp             lr, x16, [SP, #-0x10]!
    // 0xa02978: ldur            x16, [fp, #-0x28]
    // 0xa0297c: ldur            lr, [fp, #-0x40]
    // 0xa02980: stp             lr, x16, [SP, #-0x10]!
    // 0xa02984: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0xa02984: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0xa02988: r0 = _callMethod()
    //     0xa02988: bl              #0x9fe49c  ; [package:dbus/src/dbus_client.dart] DBusClient::_callMethod
    // 0xa0298c: add             SP, SP, #0x30
    // 0xa02990: mov             x1, x0
    // 0xa02994: stur            x1, [fp, #-0x28]
    // 0xa02998: r0 = Await()
    //     0xa02998: bl              #0x4b8e6c  ; AwaitStub
    // 0xa0299c: LoadField: r1 = r0->field_7
    //     0xa0299c: ldur            w1, [x0, #7]
    // 0xa029a0: DecompressPointer r1
    //     0xa029a0: add             x1, x1, HEAP, lsl #32
    // 0xa029a4: r0 = LoadClassIdInstr(r1)
    //     0xa029a4: ldur            x0, [x1, #-1]
    //     0xa029a8: ubfx            x0, x0, #0xc, #0x14
    // 0xa029ac: stp             xzr, x1, [SP, #-0x10]!
    // 0xa029b0: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa029b0: sub             lr, x0, #0xd83
    //     0xa029b4: ldr             lr, [x21, lr, lsl #3]
    //     0xa029b8: blr             lr
    // 0xa029bc: add             SP, SP, #0x10
    // 0xa029c0: mov             x3, x0
    // 0xa029c4: r2 = Null
    //     0xa029c4: mov             x2, NULL
    // 0xa029c8: r1 = Null
    //     0xa029c8: mov             x1, NULL
    // 0xa029cc: stur            x3, [fp, #-0x20]
    // 0xa029d0: r4 = 59
    //     0xa029d0: mov             x4, #0x3b
    // 0xa029d4: branchIfSmi(r0, 0xa029e0)
    //     0xa029d4: tbz             w0, #0, #0xa029e0
    // 0xa029d8: r4 = LoadClassIdInstr(r0)
    //     0xa029d8: ldur            x4, [x0, #-1]
    //     0xa029dc: ubfx            x4, x4, #0xc, #0x14
    // 0xa029e0: r17 = -4573
    //     0xa029e0: mov             x17, #-0x11dd
    // 0xa029e4: add             x4, x4, x17
    // 0xa029e8: cmp             x4, #1
    // 0xa029ec: b.ls            #0xa029fc
    // 0xa029f0: r8 = DBusString
    //     0xa029f0: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa029f4: r3 = Null
    //     0xa029f4: ldr             x3, [PP, #0x7938]  ; [pp+0x7938] Null
    // 0xa029f8: r0 = DefaultTypeTest()
    //     0xa029f8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa029fc: ldur            x0, [fp, #-0x20]
    // 0xa02a00: LoadField: r1 = r0->field_7
    //     0xa02a00: ldur            w1, [x0, #7]
    // 0xa02a04: DecompressPointer r1
    //     0xa02a04: add             x1, x1, HEAP, lsl #32
    // 0xa02a08: stur            x1, [fp, #-0x28]
    // 0xa02a0c: r0 = DBusBusName()
    //     0xa02a0c: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0xa02a10: stur            x0, [fp, #-0x20]
    // 0xa02a14: ldur            x16, [fp, #-0x28]
    // 0xa02a18: stp             x16, x0, [SP, #-0x10]!
    // 0xa02a1c: r0 = DBusBusName()
    //     0xa02a1c: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0xa02a20: add             SP, SP, #0x10
    // 0xa02a24: ldur            x0, [fp, #-0x20]
    // 0xa02a28: ldur            x1, [fp, #-0x10]
    // 0xa02a2c: StoreField: r1->field_4f = r0
    //     0xa02a2c: stur            w0, [x1, #0x4f]
    //     0xa02a30: ldurb           w16, [x1, #-1]
    //     0xa02a34: ldurb           w17, [x0, #-1]
    //     0xa02a38: and             x16, x17, x16, lsr #2
    //     0xa02a3c: tst             x16, HEAP, lsr #32
    //     0xa02a40: b.eq            #0xa02a48
    //     0xa02a44: bl              #0xd6826c
    // 0xa02a48: LoadField: r0 = r1->field_1f
    //     0xa02a48: ldur            w0, [x1, #0x1f]
    // 0xa02a4c: DecompressPointer r0
    //     0xa02a4c: add             x0, x0, HEAP, lsl #32
    // 0xa02a50: cmp             w0, NULL
    // 0xa02a54: b.ne            #0xa02a60
    // 0xa02a58: mov             x0, x1
    // 0xa02a5c: b               #0xa02a74
    // 0xa02a60: SaveReg r0
    //     0xa02a60: str             x0, [SP, #-8]!
    // 0xa02a64: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa02a64: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa02a68: r0 = complete()
    //     0xa02a68: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0xa02a6c: add             SP, SP, #8
    // 0xa02a70: ldur            x0, [fp, #-0x10]
    // 0xa02a74: SaveReg r0
    //     0xa02a74: str             x0, [SP, #-8]!
    // 0xa02a78: r0 = nameAcquired()
    //     0xa02a78: bl              #0xa033d4  ; [package:dbus/src/dbus_client.dart] DBusClient::nameAcquired
    // 0xa02a7c: add             SP, SP, #8
    // 0xa02a80: ldur            x2, [fp, #-0x18]
    // 0xa02a84: r1 = Function '<anonymous closure>':.
    //     0xa02a84: ldr             x1, [PP, #0x7948]  ; [pp+0x7948] AnonymousClosure: (0xa0df84), in [package:dbus/src/dbus_client.dart] DBusClient::_connect (0xa02724)
    // 0xa02a88: stur            x0, [fp, #-0x20]
    // 0xa02a8c: r0 = AllocateClosure()
    //     0xa02a8c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa02a90: ldur            x16, [fp, #-0x20]
    // 0xa02a94: stp             x0, x16, [SP, #-0x10]!
    // 0xa02a98: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa02a98: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa02a9c: r0 = listen()
    //     0xa02a9c: bl              #0xc57168  ; [dart:async] _ForwardingStream::listen
    // 0xa02aa0: add             SP, SP, #0x10
    // 0xa02aa4: ldur            x1, [fp, #-0x10]
    // 0xa02aa8: StoreField: r1->field_33 = r0
    //     0xa02aa8: stur            w0, [x1, #0x33]
    //     0xa02aac: ldurb           w16, [x1, #-1]
    //     0xa02ab0: ldurb           w17, [x0, #-1]
    //     0xa02ab4: and             x16, x17, x16, lsr #2
    //     0xa02ab8: tst             x16, HEAP, lsr #32
    //     0xa02abc: b.eq            #0xa02ac4
    //     0xa02ac0: bl              #0xd6826c
    // 0xa02ac4: SaveReg r1
    //     0xa02ac4: str             x1, [SP, #-8]!
    // 0xa02ac8: r0 = nameLost()
    //     0xa02ac8: bl              #0xa03294  ; [package:dbus/src/dbus_client.dart] DBusClient::nameLost
    // 0xa02acc: add             SP, SP, #8
    // 0xa02ad0: ldur            x2, [fp, #-0x18]
    // 0xa02ad4: r1 = Function '<anonymous closure>':.
    //     0xa02ad4: ldr             x1, [PP, #0x7950]  ; [pp+0x7950] AnonymousClosure: (0xa0dee4), in [package:dbus/src/dbus_client.dart] DBusClient::_connect (0xa02724)
    // 0xa02ad8: stur            x0, [fp, #-0x20]
    // 0xa02adc: r0 = AllocateClosure()
    //     0xa02adc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa02ae0: ldur            x16, [fp, #-0x20]
    // 0xa02ae4: stp             x0, x16, [SP, #-0x10]!
    // 0xa02ae8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa02ae8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa02aec: r0 = listen()
    //     0xa02aec: bl              #0xc57168  ; [dart:async] _ForwardingStream::listen
    // 0xa02af0: add             SP, SP, #0x10
    // 0xa02af4: ldur            x1, [fp, #-0x10]
    // 0xa02af8: StoreField: r1->field_37 = r0
    //     0xa02af8: stur            w0, [x1, #0x37]
    //     0xa02afc: ldurb           w16, [x1, #-1]
    //     0xa02b00: ldurb           w17, [x0, #-1]
    //     0xa02b04: and             x16, x17, x16, lsr #2
    //     0xa02b08: tst             x16, HEAP, lsr #32
    //     0xa02b0c: b.eq            #0xa02b14
    //     0xa02b10: bl              #0xd6826c
    // 0xa02b14: SaveReg r1
    //     0xa02b14: str             x1, [SP, #-8]!
    // 0xa02b18: r0 = nameOwnerChanged()
    //     0xa02b18: bl              #0xa02b74  ; [package:dbus/src/dbus_client.dart] DBusClient::nameOwnerChanged
    // 0xa02b1c: add             SP, SP, #8
    // 0xa02b20: ldur            x2, [fp, #-0x18]
    // 0xa02b24: r1 = Function '<anonymous closure>':.
    //     0xa02b24: ldr             x1, [PP, #0x7958]  ; [pp+0x7958] AnonymousClosure: (0xa0ddb8), in [package:dbus/src/dbus_client.dart] DBusClient::_connect (0xa02724)
    // 0xa02b28: stur            x0, [fp, #-0x18]
    // 0xa02b2c: r0 = AllocateClosure()
    //     0xa02b2c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa02b30: ldur            x16, [fp, #-0x18]
    // 0xa02b34: stp             x0, x16, [SP, #-0x10]!
    // 0xa02b38: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa02b38: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa02b3c: r0 = listen()
    //     0xa02b3c: bl              #0xc57168  ; [dart:async] _ForwardingStream::listen
    // 0xa02b40: add             SP, SP, #0x10
    // 0xa02b44: ldur            x1, [fp, #-0x10]
    // 0xa02b48: StoreField: r1->field_3b = r0
    //     0xa02b48: stur            w0, [x1, #0x3b]
    //     0xa02b4c: ldurb           w16, [x1, #-1]
    //     0xa02b50: ldurb           w17, [x0, #-1]
    //     0xa02b54: and             x16, x17, x16, lsr #2
    //     0xa02b58: tst             x16, HEAP, lsr #32
    //     0xa02b5c: b.eq            #0xa02b64
    //     0xa02b60: bl              #0xd6826c
    // 0xa02b64: r0 = Null
    //     0xa02b64: mov             x0, NULL
    // 0xa02b68: r0 = ReturnAsyncNotFuture()
    //     0xa02b68: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa02b6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa02b6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa02b70: b               #0xa02750
  }
  get _ nameOwnerChanged(/* No info */) {
    // ** addr: 0xa02b74, size: 0xa4
    // 0xa02b74: EnterFrame
    //     0xa02b74: stp             fp, lr, [SP, #-0x10]!
    //     0xa02b78: mov             fp, SP
    // 0xa02b7c: AllocStack(0x10)
    //     0xa02b7c: sub             SP, SP, #0x10
    // 0xa02b80: CheckStackOverflow
    //     0xa02b80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa02b84: cmp             SP, x16
    //     0xa02b88: b.ls            #0xa02c10
    // 0xa02b8c: r0 = DBusSignature()
    //     0xa02b8c: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa02b90: stur            x0, [fp, #-8]
    // 0xa02b94: r16 = "sss"
    //     0xa02b94: ldr             x16, [PP, #0x7968]  ; [pp+0x7968] "sss"
    // 0xa02b98: stp             x16, x0, [SP, #-0x10]!
    // 0xa02b9c: r0 = DBusSignature()
    //     0xa02b9c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa02ba0: add             SP, SP, #0x10
    // 0xa02ba4: r1 = <DBusSignal>
    //     0xa02ba4: ldr             x1, [PP, #0x398]  ; [pp+0x398] TypeArguments: <DBusSignal>
    // 0xa02ba8: r0 = DBusSignalStream()
    //     0xa02ba8: bl              #0xa03060  ; AllocateDBusSignalStreamStub -> DBusSignalStream (size=0x1c)
    // 0xa02bac: stur            x0, [fp, #-0x10]
    // 0xa02bb0: ldr             x16, [fp, #0x10]
    // 0xa02bb4: stp             x16, x0, [SP, #-0x10]!
    // 0xa02bb8: r16 = "org.freedesktop.DBus"
    //     0xa02bb8: ldr             x16, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xa02bbc: r30 = "org.freedesktop.DBus"
    //     0xa02bbc: ldr             lr, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xa02bc0: stp             lr, x16, [SP, #-0x10]!
    // 0xa02bc4: r16 = "NameOwnerChanged"
    //     0xa02bc4: ldr             x16, [PP, #0x7970]  ; [pp+0x7970] "NameOwnerChanged"
    // 0xa02bc8: ldur            lr, [fp, #-8]
    // 0xa02bcc: stp             lr, x16, [SP, #-0x10]!
    // 0xa02bd0: r4 = const [0, 0x6, 0x6, 0x3, interface, 0x3, name, 0x4, signature, 0x5, null]
    //     0xa02bd0: ldr             x4, [PP, #0x7978]  ; [pp+0x7978] List(11) [0, 0x6, 0x6, 0x3, "interface", 0x3, "name", 0x4, "signature", 0x5, Null]
    // 0xa02bd4: r0 = DBusSignalStream()
    //     0xa02bd4: bl              #0xa02c18  ; [package:dbus/src/dbus_client.dart] DBusSignalStream::DBusSignalStream
    // 0xa02bd8: add             SP, SP, #0x30
    // 0xa02bdc: r1 = Function '<anonymous closure>':.
    //     0xa02bdc: ldr             x1, [PP, #0x7980]  ; [pp+0x7980] AnonymousClosure: (0xa0306c), in [package:dbus/src/dbus_client.dart] DBusClient::nameOwnerChanged (0xa02b74)
    // 0xa02be0: r2 = Null
    //     0xa02be0: mov             x2, NULL
    // 0xa02be4: r0 = AllocateClosure()
    //     0xa02be4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa02be8: r16 = <DBusNameOwnerChangedEvent>
    //     0xa02be8: ldr             x16, [PP, #0x7988]  ; [pp+0x7988] TypeArguments: <DBusNameOwnerChangedEvent>
    // 0xa02bec: ldur            lr, [fp, #-0x10]
    // 0xa02bf0: stp             lr, x16, [SP, #-0x10]!
    // 0xa02bf4: SaveReg r0
    //     0xa02bf4: str             x0, [SP, #-8]!
    // 0xa02bf8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa02bf8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa02bfc: r0 = map()
    //     0xa02bfc: bl              #0x5b31c8  ; [dart:async] Stream::map
    // 0xa02c00: add             SP, SP, #0x18
    // 0xa02c04: LeaveFrame
    //     0xa02c04: mov             SP, fp
    //     0xa02c08: ldp             fp, lr, [SP], #0x10
    // 0xa02c0c: ret
    //     0xa02c0c: ret             
    // 0xa02c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa02c10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa02c14: b               #0xa02b8c
  }
  [closure] DBusNameOwnerChangedEvent <anonymous closure>(dynamic, DBusSignal) {
    // ** addr: 0xa0306c, size: 0x21c
    // 0xa0306c: EnterFrame
    //     0xa0306c: stp             fp, lr, [SP, #-0x10]!
    //     0xa03070: mov             fp, SP
    // 0xa03074: AllocStack(0x20)
    //     0xa03074: sub             SP, SP, #0x20
    // 0xa03078: CheckStackOverflow
    //     0xa03078: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0307c: cmp             SP, x16
    //     0xa03080: b.ls            #0xa03280
    // 0xa03084: ldr             x0, [fp, #0x10]
    // 0xa03088: LoadField: r1 = r0->field_17
    //     0xa03088: ldur            w1, [x0, #0x17]
    // 0xa0308c: DecompressPointer r1
    //     0xa0308c: add             x1, x1, HEAP, lsl #32
    // 0xa03090: stur            x1, [fp, #-8]
    // 0xa03094: r0 = LoadClassIdInstr(r1)
    //     0xa03094: ldur            x0, [x1, #-1]
    //     0xa03098: ubfx            x0, x0, #0xc, #0x14
    // 0xa0309c: stp             xzr, x1, [SP, #-0x10]!
    // 0xa030a0: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa030a0: sub             lr, x0, #0xd83
    //     0xa030a4: ldr             lr, [x21, lr, lsl #3]
    //     0xa030a8: blr             lr
    // 0xa030ac: add             SP, SP, #0x10
    // 0xa030b0: mov             x3, x0
    // 0xa030b4: r2 = Null
    //     0xa030b4: mov             x2, NULL
    // 0xa030b8: r1 = Null
    //     0xa030b8: mov             x1, NULL
    // 0xa030bc: stur            x3, [fp, #-0x10]
    // 0xa030c0: r4 = 59
    //     0xa030c0: mov             x4, #0x3b
    // 0xa030c4: branchIfSmi(r0, 0xa030d0)
    //     0xa030c4: tbz             w0, #0, #0xa030d0
    // 0xa030c8: r4 = LoadClassIdInstr(r0)
    //     0xa030c8: ldur            x4, [x0, #-1]
    //     0xa030cc: ubfx            x4, x4, #0xc, #0x14
    // 0xa030d0: r17 = -4573
    //     0xa030d0: mov             x17, #-0x11dd
    // 0xa030d4: add             x4, x4, x17
    // 0xa030d8: cmp             x4, #1
    // 0xa030dc: b.ls            #0xa030ec
    // 0xa030e0: r8 = DBusString
    //     0xa030e0: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa030e4: r3 = Null
    //     0xa030e4: ldr             x3, [PP, #0x7990]  ; [pp+0x7990] Null
    // 0xa030e8: r0 = DefaultTypeTest()
    //     0xa030e8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa030ec: ldur            x0, [fp, #-0x10]
    // 0xa030f0: LoadField: r1 = r0->field_7
    //     0xa030f0: ldur            w1, [x0, #7]
    // 0xa030f4: DecompressPointer r1
    //     0xa030f4: add             x1, x1, HEAP, lsl #32
    // 0xa030f8: ldur            x2, [fp, #-8]
    // 0xa030fc: stur            x1, [fp, #-0x18]
    // 0xa03100: r0 = LoadClassIdInstr(r2)
    //     0xa03100: ldur            x0, [x2, #-1]
    //     0xa03104: ubfx            x0, x0, #0xc, #0x14
    // 0xa03108: r16 = 2
    //     0xa03108: mov             x16, #2
    // 0xa0310c: stp             x16, x2, [SP, #-0x10]!
    // 0xa03110: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa03110: sub             lr, x0, #0xd83
    //     0xa03114: ldr             lr, [x21, lr, lsl #3]
    //     0xa03118: blr             lr
    // 0xa0311c: add             SP, SP, #0x10
    // 0xa03120: mov             x3, x0
    // 0xa03124: r2 = Null
    //     0xa03124: mov             x2, NULL
    // 0xa03128: r1 = Null
    //     0xa03128: mov             x1, NULL
    // 0xa0312c: stur            x3, [fp, #-0x10]
    // 0xa03130: r4 = 59
    //     0xa03130: mov             x4, #0x3b
    // 0xa03134: branchIfSmi(r0, 0xa03140)
    //     0xa03134: tbz             w0, #0, #0xa03140
    // 0xa03138: r4 = LoadClassIdInstr(r0)
    //     0xa03138: ldur            x4, [x0, #-1]
    //     0xa0313c: ubfx            x4, x4, #0xc, #0x14
    // 0xa03140: r17 = -4573
    //     0xa03140: mov             x17, #-0x11dd
    // 0xa03144: add             x4, x4, x17
    // 0xa03148: cmp             x4, #1
    // 0xa0314c: b.ls            #0xa0315c
    // 0xa03150: r8 = DBusString
    //     0xa03150: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa03154: r3 = Null
    //     0xa03154: ldr             x3, [PP, #0x79a0]  ; [pp+0x79a0] Null
    // 0xa03158: r0 = DefaultTypeTest()
    //     0xa03158: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa0315c: ldur            x0, [fp, #-0x10]
    // 0xa03160: LoadField: r1 = r0->field_7
    //     0xa03160: ldur            w1, [x0, #7]
    // 0xa03164: DecompressPointer r1
    //     0xa03164: add             x1, x1, HEAP, lsl #32
    // 0xa03168: ldur            x0, [fp, #-8]
    // 0xa0316c: stur            x1, [fp, #-0x20]
    // 0xa03170: r2 = LoadClassIdInstr(r0)
    //     0xa03170: ldur            x2, [x0, #-1]
    //     0xa03174: ubfx            x2, x2, #0xc, #0x14
    // 0xa03178: r16 = 4
    //     0xa03178: mov             x16, #4
    // 0xa0317c: stp             x16, x0, [SP, #-0x10]!
    // 0xa03180: mov             x0, x2
    // 0xa03184: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa03184: sub             lr, x0, #0xd83
    //     0xa03188: ldr             lr, [x21, lr, lsl #3]
    //     0xa0318c: blr             lr
    // 0xa03190: add             SP, SP, #0x10
    // 0xa03194: mov             x3, x0
    // 0xa03198: r2 = Null
    //     0xa03198: mov             x2, NULL
    // 0xa0319c: r1 = Null
    //     0xa0319c: mov             x1, NULL
    // 0xa031a0: stur            x3, [fp, #-8]
    // 0xa031a4: r4 = 59
    //     0xa031a4: mov             x4, #0x3b
    // 0xa031a8: branchIfSmi(r0, 0xa031b4)
    //     0xa031a8: tbz             w0, #0, #0xa031b4
    // 0xa031ac: r4 = LoadClassIdInstr(r0)
    //     0xa031ac: ldur            x4, [x0, #-1]
    //     0xa031b0: ubfx            x4, x4, #0xc, #0x14
    // 0xa031b4: r17 = -4573
    //     0xa031b4: mov             x17, #-0x11dd
    // 0xa031b8: add             x4, x4, x17
    // 0xa031bc: cmp             x4, #1
    // 0xa031c0: b.ls            #0xa031d0
    // 0xa031c4: r8 = DBusString
    //     0xa031c4: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa031c8: r3 = Null
    //     0xa031c8: ldr             x3, [PP, #0x79b0]  ; [pp+0x79b0] Null
    // 0xa031cc: r0 = DefaultTypeTest()
    //     0xa031cc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa031d0: ldur            x0, [fp, #-8]
    // 0xa031d4: LoadField: r1 = r0->field_7
    //     0xa031d4: ldur            w1, [x0, #7]
    // 0xa031d8: DecompressPointer r1
    //     0xa031d8: add             x1, x1, HEAP, lsl #32
    // 0xa031dc: ldur            x2, [fp, #-0x20]
    // 0xa031e0: stur            x1, [fp, #-0x10]
    // 0xa031e4: r0 = LoadClassIdInstr(r2)
    //     0xa031e4: ldur            x0, [x2, #-1]
    //     0xa031e8: ubfx            x0, x0, #0xc, #0x14
    // 0xa031ec: r16 = ""
    //     0xa031ec: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa031f0: stp             x16, x2, [SP, #-0x10]!
    // 0xa031f4: mov             lr, x0
    // 0xa031f8: ldr             lr, [x21, lr, lsl #3]
    // 0xa031fc: blr             lr
    // 0xa03200: add             SP, SP, #0x10
    // 0xa03204: tbz             w0, #4, #0xa03210
    // 0xa03208: ldur            x2, [fp, #-0x20]
    // 0xa0320c: b               #0xa03214
    // 0xa03210: r2 = Null
    //     0xa03210: mov             x2, NULL
    // 0xa03214: ldur            x1, [fp, #-0x10]
    // 0xa03218: stur            x2, [fp, #-8]
    // 0xa0321c: r0 = LoadClassIdInstr(r1)
    //     0xa0321c: ldur            x0, [x1, #-1]
    //     0xa03220: ubfx            x0, x0, #0xc, #0x14
    // 0xa03224: r16 = ""
    //     0xa03224: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa03228: stp             x16, x1, [SP, #-0x10]!
    // 0xa0322c: mov             lr, x0
    // 0xa03230: ldr             lr, [x21, lr, lsl #3]
    // 0xa03234: blr             lr
    // 0xa03238: add             SP, SP, #0x10
    // 0xa0323c: tbz             w0, #4, #0xa03248
    // 0xa03240: ldur            x2, [fp, #-0x10]
    // 0xa03244: b               #0xa0324c
    // 0xa03248: r2 = Null
    //     0xa03248: mov             x2, NULL
    // 0xa0324c: ldur            x0, [fp, #-8]
    // 0xa03250: ldur            x1, [fp, #-0x18]
    // 0xa03254: stur            x2, [fp, #-0x10]
    // 0xa03258: r0 = DBusNameOwnerChangedEvent()
    //     0xa03258: bl              #0xa03288  ; AllocateDBusNameOwnerChangedEventStub -> DBusNameOwnerChangedEvent (size=0x14)
    // 0xa0325c: ldur            x1, [fp, #-0x18]
    // 0xa03260: StoreField: r0->field_7 = r1
    //     0xa03260: stur            w1, [x0, #7]
    // 0xa03264: ldur            x1, [fp, #-8]
    // 0xa03268: StoreField: r0->field_b = r1
    //     0xa03268: stur            w1, [x0, #0xb]
    // 0xa0326c: ldur            x1, [fp, #-0x10]
    // 0xa03270: StoreField: r0->field_f = r1
    //     0xa03270: stur            w1, [x0, #0xf]
    // 0xa03274: LeaveFrame
    //     0xa03274: mov             SP, fp
    //     0xa03278: ldp             fp, lr, [SP], #0x10
    // 0xa0327c: ret
    //     0xa0327c: ret             
    // 0xa03280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa03280: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa03284: b               #0xa03084
  }
  get _ nameLost(/* No info */) {
    // ** addr: 0xa03294, size: 0xa4
    // 0xa03294: EnterFrame
    //     0xa03294: stp             fp, lr, [SP, #-0x10]!
    //     0xa03298: mov             fp, SP
    // 0xa0329c: AllocStack(0x10)
    //     0xa0329c: sub             SP, SP, #0x10
    // 0xa032a0: CheckStackOverflow
    //     0xa032a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa032a4: cmp             SP, x16
    //     0xa032a8: b.ls            #0xa03330
    // 0xa032ac: r0 = DBusSignature()
    //     0xa032ac: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa032b0: stur            x0, [fp, #-8]
    // 0xa032b4: r16 = "s"
    //     0xa032b4: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa032b8: stp             x16, x0, [SP, #-0x10]!
    // 0xa032bc: r0 = DBusSignature()
    //     0xa032bc: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa032c0: add             SP, SP, #0x10
    // 0xa032c4: r1 = <DBusSignal>
    //     0xa032c4: ldr             x1, [PP, #0x398]  ; [pp+0x398] TypeArguments: <DBusSignal>
    // 0xa032c8: r0 = DBusSignalStream()
    //     0xa032c8: bl              #0xa03060  ; AllocateDBusSignalStreamStub -> DBusSignalStream (size=0x1c)
    // 0xa032cc: stur            x0, [fp, #-0x10]
    // 0xa032d0: ldr             x16, [fp, #0x10]
    // 0xa032d4: stp             x16, x0, [SP, #-0x10]!
    // 0xa032d8: r16 = "org.freedesktop.DBus"
    //     0xa032d8: ldr             x16, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xa032dc: r30 = "org.freedesktop.DBus"
    //     0xa032dc: ldr             lr, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xa032e0: stp             lr, x16, [SP, #-0x10]!
    // 0xa032e4: r16 = "NameLost"
    //     0xa032e4: ldr             x16, [PP, #0x79c0]  ; [pp+0x79c0] "NameLost"
    // 0xa032e8: ldur            lr, [fp, #-8]
    // 0xa032ec: stp             lr, x16, [SP, #-0x10]!
    // 0xa032f0: r4 = const [0, 0x6, 0x6, 0x3, interface, 0x3, name, 0x4, signature, 0x5, null]
    //     0xa032f0: ldr             x4, [PP, #0x7978]  ; [pp+0x7978] List(11) [0, 0x6, 0x6, 0x3, "interface", 0x3, "name", 0x4, "signature", 0x5, Null]
    // 0xa032f4: r0 = DBusSignalStream()
    //     0xa032f4: bl              #0xa02c18  ; [package:dbus/src/dbus_client.dart] DBusSignalStream::DBusSignalStream
    // 0xa032f8: add             SP, SP, #0x30
    // 0xa032fc: r1 = Function '<anonymous closure>':.
    //     0xa032fc: ldr             x1, [PP, #0x79c8]  ; [pp+0x79c8] AnonymousClosure: (0xa03338), in [package:dbus/src/dbus_client.dart] DBusClient::nameLost (0xa03294)
    // 0xa03300: r2 = Null
    //     0xa03300: mov             x2, NULL
    // 0xa03304: r0 = AllocateClosure()
    //     0xa03304: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa03308: r16 = <String>
    //     0xa03308: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xa0330c: ldur            lr, [fp, #-0x10]
    // 0xa03310: stp             lr, x16, [SP, #-0x10]!
    // 0xa03314: SaveReg r0
    //     0xa03314: str             x0, [SP, #-8]!
    // 0xa03318: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa03318: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0331c: r0 = map()
    //     0xa0331c: bl              #0x5b31c8  ; [dart:async] Stream::map
    // 0xa03320: add             SP, SP, #0x18
    // 0xa03324: LeaveFrame
    //     0xa03324: mov             SP, fp
    //     0xa03328: ldp             fp, lr, [SP], #0x10
    // 0xa0332c: ret
    //     0xa0332c: ret             
    // 0xa03330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa03330: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa03334: b               #0xa032ac
  }
  [closure] String <anonymous closure>(dynamic, DBusSignal) {
    // ** addr: 0xa03338, size: 0x9c
    // 0xa03338: EnterFrame
    //     0xa03338: stp             fp, lr, [SP, #-0x10]!
    //     0xa0333c: mov             fp, SP
    // 0xa03340: AllocStack(0x8)
    //     0xa03340: sub             SP, SP, #8
    // 0xa03344: CheckStackOverflow
    //     0xa03344: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa03348: cmp             SP, x16
    //     0xa0334c: b.ls            #0xa033cc
    // 0xa03350: ldr             x0, [fp, #0x10]
    // 0xa03354: LoadField: r1 = r0->field_17
    //     0xa03354: ldur            w1, [x0, #0x17]
    // 0xa03358: DecompressPointer r1
    //     0xa03358: add             x1, x1, HEAP, lsl #32
    // 0xa0335c: r0 = LoadClassIdInstr(r1)
    //     0xa0335c: ldur            x0, [x1, #-1]
    //     0xa03360: ubfx            x0, x0, #0xc, #0x14
    // 0xa03364: stp             xzr, x1, [SP, #-0x10]!
    // 0xa03368: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa03368: sub             lr, x0, #0xd83
    //     0xa0336c: ldr             lr, [x21, lr, lsl #3]
    //     0xa03370: blr             lr
    // 0xa03374: add             SP, SP, #0x10
    // 0xa03378: mov             x3, x0
    // 0xa0337c: r2 = Null
    //     0xa0337c: mov             x2, NULL
    // 0xa03380: r1 = Null
    //     0xa03380: mov             x1, NULL
    // 0xa03384: stur            x3, [fp, #-8]
    // 0xa03388: r4 = 59
    //     0xa03388: mov             x4, #0x3b
    // 0xa0338c: branchIfSmi(r0, 0xa03398)
    //     0xa0338c: tbz             w0, #0, #0xa03398
    // 0xa03390: r4 = LoadClassIdInstr(r0)
    //     0xa03390: ldur            x4, [x0, #-1]
    //     0xa03394: ubfx            x4, x4, #0xc, #0x14
    // 0xa03398: r17 = -4573
    //     0xa03398: mov             x17, #-0x11dd
    // 0xa0339c: add             x4, x4, x17
    // 0xa033a0: cmp             x4, #1
    // 0xa033a4: b.ls            #0xa033b4
    // 0xa033a8: r8 = DBusString
    //     0xa033a8: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa033ac: r3 = Null
    //     0xa033ac: ldr             x3, [PP, #0x79d0]  ; [pp+0x79d0] Null
    // 0xa033b0: r0 = DefaultTypeTest()
    //     0xa033b0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa033b4: ldur            x1, [fp, #-8]
    // 0xa033b8: LoadField: r0 = r1->field_7
    //     0xa033b8: ldur            w0, [x1, #7]
    // 0xa033bc: DecompressPointer r0
    //     0xa033bc: add             x0, x0, HEAP, lsl #32
    // 0xa033c0: LeaveFrame
    //     0xa033c0: mov             SP, fp
    //     0xa033c4: ldp             fp, lr, [SP], #0x10
    // 0xa033c8: ret
    //     0xa033c8: ret             
    // 0xa033cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa033cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa033d0: b               #0xa03350
  }
  get _ nameAcquired(/* No info */) {
    // ** addr: 0xa033d4, size: 0xa4
    // 0xa033d4: EnterFrame
    //     0xa033d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa033d8: mov             fp, SP
    // 0xa033dc: AllocStack(0x10)
    //     0xa033dc: sub             SP, SP, #0x10
    // 0xa033e0: CheckStackOverflow
    //     0xa033e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa033e4: cmp             SP, x16
    //     0xa033e8: b.ls            #0xa03470
    // 0xa033ec: r0 = DBusSignature()
    //     0xa033ec: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa033f0: stur            x0, [fp, #-8]
    // 0xa033f4: r16 = "s"
    //     0xa033f4: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa033f8: stp             x16, x0, [SP, #-0x10]!
    // 0xa033fc: r0 = DBusSignature()
    //     0xa033fc: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa03400: add             SP, SP, #0x10
    // 0xa03404: r1 = <DBusSignal>
    //     0xa03404: ldr             x1, [PP, #0x398]  ; [pp+0x398] TypeArguments: <DBusSignal>
    // 0xa03408: r0 = DBusSignalStream()
    //     0xa03408: bl              #0xa03060  ; AllocateDBusSignalStreamStub -> DBusSignalStream (size=0x1c)
    // 0xa0340c: stur            x0, [fp, #-0x10]
    // 0xa03410: ldr             x16, [fp, #0x10]
    // 0xa03414: stp             x16, x0, [SP, #-0x10]!
    // 0xa03418: r16 = "org.freedesktop.DBus"
    //     0xa03418: ldr             x16, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xa0341c: r30 = "org.freedesktop.DBus"
    //     0xa0341c: ldr             lr, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xa03420: stp             lr, x16, [SP, #-0x10]!
    // 0xa03424: r16 = "NameAcquired"
    //     0xa03424: ldr             x16, [PP, #0x7b48]  ; [pp+0x7b48] "NameAcquired"
    // 0xa03428: ldur            lr, [fp, #-8]
    // 0xa0342c: stp             lr, x16, [SP, #-0x10]!
    // 0xa03430: r4 = const [0, 0x6, 0x6, 0x3, interface, 0x3, name, 0x4, signature, 0x5, null]
    //     0xa03430: ldr             x4, [PP, #0x7978]  ; [pp+0x7978] List(11) [0, 0x6, 0x6, 0x3, "interface", 0x3, "name", 0x4, "signature", 0x5, Null]
    // 0xa03434: r0 = DBusSignalStream()
    //     0xa03434: bl              #0xa02c18  ; [package:dbus/src/dbus_client.dart] DBusSignalStream::DBusSignalStream
    // 0xa03438: add             SP, SP, #0x30
    // 0xa0343c: r1 = Function '<anonymous closure>':.
    //     0xa0343c: ldr             x1, [PP, #0x7b50]  ; [pp+0x7b50] AnonymousClosure: (0xa03478), in [package:dbus/src/dbus_client.dart] DBusClient::nameAcquired (0xa033d4)
    // 0xa03440: r2 = Null
    //     0xa03440: mov             x2, NULL
    // 0xa03444: r0 = AllocateClosure()
    //     0xa03444: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa03448: r16 = <String>
    //     0xa03448: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xa0344c: ldur            lr, [fp, #-0x10]
    // 0xa03450: stp             lr, x16, [SP, #-0x10]!
    // 0xa03454: SaveReg r0
    //     0xa03454: str             x0, [SP, #-8]!
    // 0xa03458: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa03458: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0345c: r0 = map()
    //     0xa0345c: bl              #0x5b31c8  ; [dart:async] Stream::map
    // 0xa03460: add             SP, SP, #0x18
    // 0xa03464: LeaveFrame
    //     0xa03464: mov             SP, fp
    //     0xa03468: ldp             fp, lr, [SP], #0x10
    // 0xa0346c: ret
    //     0xa0346c: ret             
    // 0xa03470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa03470: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa03474: b               #0xa033ec
  }
  [closure] String <anonymous closure>(dynamic, DBusSignal) {
    // ** addr: 0xa03478, size: 0x9c
    // 0xa03478: EnterFrame
    //     0xa03478: stp             fp, lr, [SP, #-0x10]!
    //     0xa0347c: mov             fp, SP
    // 0xa03480: AllocStack(0x8)
    //     0xa03480: sub             SP, SP, #8
    // 0xa03484: CheckStackOverflow
    //     0xa03484: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa03488: cmp             SP, x16
    //     0xa0348c: b.ls            #0xa0350c
    // 0xa03490: ldr             x0, [fp, #0x10]
    // 0xa03494: LoadField: r1 = r0->field_17
    //     0xa03494: ldur            w1, [x0, #0x17]
    // 0xa03498: DecompressPointer r1
    //     0xa03498: add             x1, x1, HEAP, lsl #32
    // 0xa0349c: r0 = LoadClassIdInstr(r1)
    //     0xa0349c: ldur            x0, [x1, #-1]
    //     0xa034a0: ubfx            x0, x0, #0xc, #0x14
    // 0xa034a4: stp             xzr, x1, [SP, #-0x10]!
    // 0xa034a8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa034a8: sub             lr, x0, #0xd83
    //     0xa034ac: ldr             lr, [x21, lr, lsl #3]
    //     0xa034b0: blr             lr
    // 0xa034b4: add             SP, SP, #0x10
    // 0xa034b8: mov             x3, x0
    // 0xa034bc: r2 = Null
    //     0xa034bc: mov             x2, NULL
    // 0xa034c0: r1 = Null
    //     0xa034c0: mov             x1, NULL
    // 0xa034c4: stur            x3, [fp, #-8]
    // 0xa034c8: r4 = 59
    //     0xa034c8: mov             x4, #0x3b
    // 0xa034cc: branchIfSmi(r0, 0xa034d8)
    //     0xa034cc: tbz             w0, #0, #0xa034d8
    // 0xa034d0: r4 = LoadClassIdInstr(r0)
    //     0xa034d0: ldur            x4, [x0, #-1]
    //     0xa034d4: ubfx            x4, x4, #0xc, #0x14
    // 0xa034d8: r17 = -4573
    //     0xa034d8: mov             x17, #-0x11dd
    // 0xa034dc: add             x4, x4, x17
    // 0xa034e0: cmp             x4, #1
    // 0xa034e4: b.ls            #0xa034f4
    // 0xa034e8: r8 = DBusString
    //     0xa034e8: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa034ec: r3 = Null
    //     0xa034ec: ldr             x3, [PP, #0x7b58]  ; [pp+0x7b58] Null
    // 0xa034f0: r0 = DefaultTypeTest()
    //     0xa034f0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa034f4: ldur            x1, [fp, #-8]
    // 0xa034f8: LoadField: r0 = r1->field_7
    //     0xa034f8: ldur            w0, [x1, #7]
    // 0xa034fc: DecompressPointer r0
    //     0xa034fc: add             x0, x0, HEAP, lsl #32
    // 0xa03500: LeaveFrame
    //     0xa03500: mov             SP, fp
    //     0xa03504: ldp             fp, lr, [SP], #0x10
    // 0xa03508: ret
    //     0xa03508: ret             
    // 0xa0350c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0350c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa03510: b               #0xa03490
  }
  _ _openSocket(/* No info */) async {
    // ** addr: 0xa03550, size: 0x600
    // 0xa03550: EnterFrame
    //     0xa03550: stp             fp, lr, [SP, #-0x10]!
    //     0xa03554: mov             fp, SP
    // 0xa03558: AllocStack(0xc8)
    //     0xa03558: sub             SP, SP, #0xc8
    // 0xa0355c: SetupParameters(DBusClient this /* r1, fp-0x90 */)
    //     0xa0355c: stur            NULL, [fp, #-8]
    //     0xa03560: mov             x0, #0
    //     0xa03564: add             x1, fp, w0, sxtw #2
    //     0xa03568: ldr             x1, [x1, #0x10]
    //     0xa0356c: stur            x1, [fp, #-0x90]
    // 0xa03570: CheckStackOverflow
    //     0xa03570: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa03574: cmp             SP, x16
    //     0xa03578: b.ls            #0xa03b30
    // 0xa0357c: r1 = 1
    //     0xa0357c: mov             x1, #1
    // 0xa03580: r0 = AllocateContext()
    //     0xa03580: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa03584: mov             x2, x0
    // 0xa03588: ldur            x1, [fp, #-0x90]
    // 0xa0358c: stur            x2, [fp, #-0x98]
    // 0xa03590: StoreField: r2->field_f = r1
    //     0xa03590: stur            w1, [x2, #0xf]
    // 0xa03594: InitAsync() -> Future<void?>
    //     0xa03594: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa03598: bl              #0x4b92e4
    // 0xa0359c: ldur            x0, [fp, #-0x90]
    // 0xa035a0: LoadField: r1 = r0->field_7
    //     0xa035a0: ldur            w1, [x0, #7]
    // 0xa035a4: DecompressPointer r1
    //     0xa035a4: add             x1, x1, HEAP, lsl #32
    // 0xa035a8: stur            x1, [fp, #-0xa8]
    // 0xa035ac: LoadField: r2 = r1->field_7
    //     0xa035ac: ldur            w2, [x1, #7]
    // 0xa035b0: DecompressPointer r2
    //     0xa035b0: add             x2, x2, HEAP, lsl #32
    // 0xa035b4: r16 = Sentinel
    //     0xa035b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa035b8: cmp             w2, w16
    // 0xa035bc: b.eq            #0xa03b38
    // 0xa035c0: stur            x2, [fp, #-0xa0]
    // 0xa035c4: r16 = "unix"
    //     0xa035c4: ldr             x16, [PP, #0x7b68]  ; [pp+0x7b68] "unix"
    // 0xa035c8: stp             x2, x16, [SP, #-0x10]!
    // 0xa035cc: r0 = ==()
    //     0xa035cc: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa035d0: add             SP, SP, #0x10
    // 0xa035d4: tbnz            w0, #4, #0xa036c8
    // 0xa035d8: ldur            x0, [fp, #-0xa8]
    // 0xa035dc: LoadField: r1 = r0->field_b
    //     0xa035dc: ldur            w1, [x0, #0xb]
    // 0xa035e0: DecompressPointer r1
    //     0xa035e0: add             x1, x1, HEAP, lsl #32
    // 0xa035e4: r16 = Sentinel
    //     0xa035e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa035e8: cmp             w1, w16
    // 0xa035ec: b.eq            #0xa03b40
    // 0xa035f0: stur            x1, [fp, #-0xb0]
    // 0xa035f4: r16 = "path"
    //     0xa035f4: ldr             x16, [PP, #0x518]  ; [pp+0x518] "path"
    // 0xa035f8: stp             x16, x1, [SP, #-0x10]!
    // 0xa035fc: r0 = _getValueOrData()
    //     0xa035fc: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa03600: add             SP, SP, #0x10
    // 0xa03604: mov             x1, x0
    // 0xa03608: ldur            x0, [fp, #-0xb0]
    // 0xa0360c: LoadField: r2 = r0->field_f
    //     0xa0360c: ldur            w2, [x0, #0xf]
    // 0xa03610: DecompressPointer r2
    //     0xa03610: add             x2, x2, HEAP, lsl #32
    // 0xa03614: cmp             w2, w1
    // 0xa03618: b.ne            #0xa03624
    // 0xa0361c: r0 = Null
    //     0xa0361c: mov             x0, NULL
    // 0xa03620: b               #0xa03628
    // 0xa03624: mov             x0, x1
    // 0xa03628: cmp             w0, NULL
    // 0xa0362c: b.ne            #0xa036a8
    // 0xa03630: ldur            x0, [fp, #-0xa8]
    // 0xa03634: LoadField: r1 = r0->field_b
    //     0xa03634: ldur            w1, [x0, #0xb]
    // 0xa03638: DecompressPointer r1
    //     0xa03638: add             x1, x1, HEAP, lsl #32
    // 0xa0363c: stur            x1, [fp, #-0xb0]
    // 0xa03640: r16 = "abstract"
    //     0xa03640: ldr             x16, [PP, #0x7b70]  ; [pp+0x7b70] "abstract"
    // 0xa03644: stp             x16, x1, [SP, #-0x10]!
    // 0xa03648: r0 = _getValueOrData()
    //     0xa03648: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa0364c: add             SP, SP, #0x10
    // 0xa03650: mov             x1, x0
    // 0xa03654: ldur            x0, [fp, #-0xb0]
    // 0xa03658: LoadField: r2 = r0->field_f
    //     0xa03658: ldur            w2, [x0, #0xf]
    // 0xa0365c: DecompressPointer r2
    //     0xa0365c: add             x2, x2, HEAP, lsl #32
    // 0xa03660: cmp             w2, w1
    // 0xa03664: b.ne            #0xa03670
    // 0xa03668: r0 = Null
    //     0xa03668: mov             x0, NULL
    // 0xa0366c: b               #0xa03674
    // 0xa03670: mov             x0, x1
    // 0xa03674: stur            x0, [fp, #-0xb0]
    // 0xa03678: cmp             w0, NULL
    // 0xa0367c: b.eq            #0xa039b8
    // 0xa03680: r1 = Null
    //     0xa03680: mov             x1, NULL
    // 0xa03684: r2 = 4
    //     0xa03684: mov             x2, #4
    // 0xa03688: r0 = AllocateArray()
    //     0xa03688: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0368c: r17 = "@"
    //     0xa0368c: ldr             x17, [PP, #0x1568]  ; [pp+0x1568] "@"
    // 0xa03690: StoreField: r0->field_f = r17
    //     0xa03690: stur            w17, [x0, #0xf]
    // 0xa03694: ldur            x1, [fp, #-0xb0]
    // 0xa03698: StoreField: r0->field_13 = r1
    //     0xa03698: stur            w1, [x0, #0x13]
    // 0xa0369c: SaveReg r0
    //     0xa0369c: str             x0, [SP, #-8]!
    // 0xa036a0: r0 = _interpolate()
    //     0xa036a0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa036a4: add             SP, SP, #8
    // 0xa036a8: stp             x0, NULL, [SP, #-0x10]!
    // 0xa036ac: r16 = Instance_InternetAddressType
    //     0xa036ac: ldr             x16, [PP, #0x1da8]  ; [pp+0x1da8] Obj!InternetAddressType@b5f3f1
    // 0xa036b0: SaveReg r16
    //     0xa036b0: str             x16, [SP, #-8]!
    // 0xa036b4: r0 = _InternetAddress.fromString()
    //     0xa036b4: bl              #0x4eae20  ; [dart:io] _InternetAddress::_InternetAddress.fromString
    // 0xa036b8: add             SP, SP, #0x18
    // 0xa036bc: mov             x1, x0
    // 0xa036c0: r2 = 0
    //     0xa036c0: mov             x2, #0
    // 0xa036c4: b               #0xa038b0
    // 0xa036c8: ldur            x1, [fp, #-0xa8]
    // 0xa036cc: r16 = "tcp"
    //     0xa036cc: ldr             x16, [PP, #0x7b78]  ; [pp+0x7b78] "tcp"
    // 0xa036d0: ldur            lr, [fp, #-0xa0]
    // 0xa036d4: stp             lr, x16, [SP, #-0x10]!
    // 0xa036d8: r0 = ==()
    //     0xa036d8: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa036dc: add             SP, SP, #0x10
    // 0xa036e0: tbnz            w0, #4, #0xa03aa8
    // 0xa036e4: ldur            x0, [fp, #-0xa8]
    // 0xa036e8: LoadField: r1 = r0->field_b
    //     0xa036e8: ldur            w1, [x0, #0xb]
    // 0xa036ec: DecompressPointer r1
    //     0xa036ec: add             x1, x1, HEAP, lsl #32
    // 0xa036f0: r16 = Sentinel
    //     0xa036f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa036f4: cmp             w1, w16
    // 0xa036f8: b.eq            #0xa03b48
    // 0xa036fc: stur            x1, [fp, #-0xa0]
    // 0xa03700: r16 = "host"
    //     0xa03700: ldr             x16, [PP, #0x2680]  ; [pp+0x2680] "host"
    // 0xa03704: stp             x16, x1, [SP, #-0x10]!
    // 0xa03708: r0 = _getValueOrData()
    //     0xa03708: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa0370c: add             SP, SP, #0x10
    // 0xa03710: mov             x1, x0
    // 0xa03714: ldur            x0, [fp, #-0xa0]
    // 0xa03718: LoadField: r2 = r0->field_f
    //     0xa03718: ldur            w2, [x0, #0xf]
    // 0xa0371c: DecompressPointer r2
    //     0xa0371c: add             x2, x2, HEAP, lsl #32
    // 0xa03720: cmp             w2, w1
    // 0xa03724: b.ne            #0xa03730
    // 0xa03728: r0 = Null
    //     0xa03728: mov             x0, NULL
    // 0xa0372c: b               #0xa03734
    // 0xa03730: mov             x0, x1
    // 0xa03734: stur            x0, [fp, #-0xb0]
    // 0xa03738: cmp             w0, NULL
    // 0xa0373c: b.eq            #0xa039f4
    // 0xa03740: ldur            x1, [fp, #-0xa8]
    // 0xa03744: LoadField: r2 = r1->field_b
    //     0xa03744: ldur            w2, [x1, #0xb]
    // 0xa03748: DecompressPointer r2
    //     0xa03748: add             x2, x2, HEAP, lsl #32
    // 0xa0374c: stur            x2, [fp, #-0xa0]
    // 0xa03750: r16 = "family"
    //     0xa03750: ldr             x16, [PP, #0x7b80]  ; [pp+0x7b80] "family"
    // 0xa03754: stp             x16, x2, [SP, #-0x10]!
    // 0xa03758: r0 = _getValueOrData()
    //     0xa03758: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa0375c: add             SP, SP, #0x10
    // 0xa03760: mov             x1, x0
    // 0xa03764: ldur            x0, [fp, #-0xa0]
    // 0xa03768: LoadField: r2 = r0->field_f
    //     0xa03768: ldur            w2, [x0, #0xf]
    // 0xa0376c: DecompressPointer r2
    //     0xa0376c: add             x2, x2, HEAP, lsl #32
    // 0xa03770: cmp             w2, w1
    // 0xa03774: b.ne            #0xa03780
    // 0xa03778: r0 = Null
    //     0xa03778: mov             x0, NULL
    // 0xa0377c: b               #0xa03784
    // 0xa03780: mov             x0, x1
    // 0xa03784: stur            x0, [fp, #-0xa0]
    // 0xa03788: cmp             w0, NULL
    // 0xa0378c: b.ne            #0xa03798
    // 0xa03790: r0 = Instance_InternetAddressType
    //     0xa03790: ldr             x0, [PP, #0x7b88]  ; [pp+0x7b88] Obj!InternetAddressType@b5f421
    // 0xa03794: b               #0xa037d0
    // 0xa03798: r16 = "ipv4"
    //     0xa03798: ldr             x16, [PP, #0x7b90]  ; [pp+0x7b90] "ipv4"
    // 0xa0379c: stp             x0, x16, [SP, #-0x10]!
    // 0xa037a0: r0 = ==()
    //     0xa037a0: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa037a4: add             SP, SP, #0x10
    // 0xa037a8: tbnz            w0, #4, #0xa037b4
    // 0xa037ac: r0 = Instance_InternetAddressType
    //     0xa037ac: ldr             x0, [PP, #0x1d98]  ; [pp+0x1d98] Obj!InternetAddressType@b5f411
    // 0xa037b0: b               #0xa037d0
    // 0xa037b4: r16 = "ipv6"
    //     0xa037b4: ldr             x16, [PP, #0x7b98]  ; [pp+0x7b98] "ipv6"
    // 0xa037b8: ldur            lr, [fp, #-0xa0]
    // 0xa037bc: stp             lr, x16, [SP, #-0x10]!
    // 0xa037c0: r0 = ==()
    //     0xa037c0: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa037c4: add             SP, SP, #0x10
    // 0xa037c8: tbnz            w0, #4, #0xa03a6c
    // 0xa037cc: r0 = Instance_InternetAddressType
    //     0xa037cc: ldr             x0, [PP, #0x1da0]  ; [pp+0x1da0] Obj!InternetAddressType@b5f401
    // 0xa037d0: stur            x0, [fp, #-0xc0]
    // 0xa037d4: ldur            x3, [fp, #-0xa8]
    // 0xa037d8: LoadField: r1 = r3->field_b
    //     0xa037d8: ldur            w1, [x3, #0xb]
    // 0xa037dc: DecompressPointer r1
    //     0xa037dc: add             x1, x1, HEAP, lsl #32
    // 0xa037e0: stur            x1, [fp, #-0xb8]
    // 0xa037e4: r16 = "port"
    //     0xa037e4: ldr             x16, [PP, #0x2690]  ; [pp+0x2690] "port"
    // 0xa037e8: stp             x16, x1, [SP, #-0x10]!
    // 0xa037ec: r0 = _getValueOrData()
    //     0xa037ec: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa037f0: add             SP, SP, #0x10
    // 0xa037f4: mov             x1, x0
    // 0xa037f8: ldur            x0, [fp, #-0xb8]
    // 0xa037fc: LoadField: r2 = r0->field_f
    //     0xa037fc: ldur            w2, [x0, #0xf]
    // 0xa03800: DecompressPointer r2
    //     0xa03800: add             x2, x2, HEAP, lsl #32
    // 0xa03804: cmp             w2, w1
    // 0xa03808: b.ne            #0xa03814
    // 0xa0380c: r0 = Null
    //     0xa0380c: mov             x0, NULL
    // 0xa03810: b               #0xa03818
    // 0xa03814: mov             x0, x1
    // 0xa03818: cmp             w0, NULL
    // 0xa0381c: b.ne            #0xa03824
    // 0xa03820: r0 = "0"
    //     0xa03820: ldr             x0, [PP, #0x3af8]  ; [pp+0x3af8] "0"
    // 0xa03824: SaveReg r0
    //     0xa03824: str             x0, [SP, #-8]!
    // 0xa03828: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa03828: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0382c: r0 = parse()
    //     0xa0382c: bl              #0x4d5d84  ; [dart:core] int::parse
    // 0xa03830: add             SP, SP, #8
    // 0xa03834: stur            x0, [fp, #-0xc8]
    // 0xa03838: ldur            x16, [fp, #-0xb0]
    // 0xa0383c: ldur            lr, [fp, #-0xc0]
    // 0xa03840: stp             lr, x16, [SP, #-0x10]!
    // 0xa03844: r0 = lookup()
    //     0xa03844: bl              #0x5352c0  ; [dart:io] _NativeSocket::lookup
    // 0xa03848: add             SP, SP, #0x10
    // 0xa0384c: mov             x1, x0
    // 0xa03850: stur            x1, [fp, #-0xb8]
    // 0xa03854: r0 = Await()
    //     0xa03854: bl              #0x4b8e6c  ; AwaitStub
    // 0xa03858: mov             x1, x0
    // 0xa0385c: stur            x1, [fp, #-0xb8]
    // 0xa03860: r0 = LoadClassIdInstr(r1)
    //     0xa03860: ldur            x0, [x1, #-1]
    //     0xa03864: ubfx            x0, x0, #0xc, #0x14
    // 0xa03868: SaveReg r1
    //     0xa03868: str             x1, [SP, #-8]!
    // 0xa0386c: r0 = GDT[cid_x0 + 0xccd1]()
    //     0xa0386c: mov             x17, #0xccd1
    //     0xa03870: add             lr, x0, x17
    //     0xa03874: ldr             lr, [x21, lr, lsl #3]
    //     0xa03878: blr             lr
    // 0xa0387c: add             SP, SP, #8
    // 0xa03880: tbz             w0, #4, #0xa03a30
    // 0xa03884: ldur            x0, [fp, #-0xb8]
    // 0xa03888: r1 = LoadClassIdInstr(r0)
    //     0xa03888: ldur            x1, [x0, #-1]
    //     0xa0388c: ubfx            x1, x1, #0xc, #0x14
    // 0xa03890: stp             xzr, x0, [SP, #-0x10]!
    // 0xa03894: mov             x0, x1
    // 0xa03898: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa03898: sub             lr, x0, #0xd83
    //     0xa0389c: ldr             lr, [x21, lr, lsl #3]
    //     0xa038a0: blr             lr
    // 0xa038a4: add             SP, SP, #0x10
    // 0xa038a8: ldur            x2, [fp, #-0xc8]
    // 0xa038ac: mov             x1, x0
    // 0xa038b0: ldur            x0, [fp, #-0x90]
    // 0xa038b4: stp             x2, x1, [SP, #-0x10]!
    // 0xa038b8: r0 = connect()
    //     0xa038b8: bl              #0x53a258  ; [dart:io] _RawSocket::connect
    // 0xa038bc: add             SP, SP, #0x10
    // 0xa038c0: mov             x1, x0
    // 0xa038c4: stur            x1, [fp, #-0xb0]
    // 0xa038c8: r0 = Await()
    //     0xa038c8: bl              #0x4b8e6c  ; AwaitStub
    // 0xa038cc: mov             x3, x0
    // 0xa038d0: ldur            x1, [fp, #-0x90]
    // 0xa038d4: stur            x3, [fp, #-0xb0]
    // 0xa038d8: StoreField: r1->field_b = r0
    //     0xa038d8: stur            w0, [x1, #0xb]
    //     0xa038dc: tbz             w0, #0, #0xa038f8
    //     0xa038e0: ldurb           w16, [x1, #-1]
    //     0xa038e4: ldurb           w17, [x0, #-1]
    //     0xa038e8: and             x16, x17, x16, lsr #2
    //     0xa038ec: tst             x16, HEAP, lsr #32
    //     0xa038f0: b.eq            #0xa038f8
    //     0xa038f4: bl              #0xd6826c
    // 0xa038f8: cmp             w3, NULL
    // 0xa038fc: b.eq            #0xa03950
    // 0xa03900: ldur            x2, [fp, #-0x98]
    // 0xa03904: r1 = Function '<anonymous closure>':.
    //     0xa03904: ldr             x1, [PP, #0x7ba0]  ; [pp+0x7ba0] AnonymousClosure: (0xa03b50), in [package:dbus/src/dbus_client.dart] DBusClient::_openSocket (0xa03550)
    // 0xa03908: r0 = AllocateClosure()
    //     0xa03908: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0390c: r1 = Function '<anonymous closure>':.
    //     0xa0390c: ldr             x1, [PP, #0x7ba8]  ; [pp+0x7ba8] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    // 0xa03910: r2 = Null
    //     0xa03910: mov             x2, NULL
    // 0xa03914: stur            x0, [fp, #-0x90]
    // 0xa03918: r0 = AllocateClosure()
    //     0xa03918: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0391c: mov             x1, x0
    // 0xa03920: ldur            x0, [fp, #-0xb0]
    // 0xa03924: r2 = LoadClassIdInstr(r0)
    //     0xa03924: ldur            x2, [x0, #-1]
    //     0xa03928: ubfx            x2, x2, #0xc, #0x14
    // 0xa0392c: ldur            x16, [fp, #-0x90]
    // 0xa03930: stp             x16, x0, [SP, #-0x10]!
    // 0xa03934: SaveReg r1
    //     0xa03934: str             x1, [SP, #-8]!
    // 0xa03938: mov             x0, x2
    // 0xa0393c: r4 = const [0, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0xa0393c: ldr             x4, [PP, #0x7bb0]  ; [pp+0x7bb0] List(7) [0, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0xa03940: r0 = GDT[cid_x0 + 0x28a]()
    //     0xa03940: add             lr, x0, #0x28a
    //     0xa03944: ldr             lr, [x21, lr, lsl #3]
    //     0xa03948: blr             lr
    // 0xa0394c: add             SP, SP, #0x18
    // 0xa03950: r0 = Null
    //     0xa03950: mov             x0, NULL
    // 0xa03954: r0 = ReturnAsyncNotFuture()
    //     0xa03954: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa03958: sub             SP, fp, #0xc8
    // 0xa0395c: mov             x4, x0
    // 0xa03960: mov             x3, x1
    // 0xa03964: stur            x0, [fp, #-0x90]
    // 0xa03968: stur            x1, [fp, #-0x98]
    // 0xa0396c: r2 = Null
    //     0xa0396c: mov             x2, NULL
    // 0xa03970: r1 = Null
    //     0xa03970: mov             x1, NULL
    // 0xa03974: cmp             w0, NULL
    // 0xa03978: b.eq            #0xa039a4
    // 0xa0397c: branchIfSmi(r0, 0xa039a4)
    //     0xa0397c: tbz             w0, #0, #0xa039a4
    // 0xa03980: r3 = LoadClassIdInstr(r0)
    //     0xa03980: ldur            x3, [x0, #-1]
    //     0xa03984: ubfx            x3, x3, #0xc, #0x14
    // 0xa03988: sub             x3, x3, #0x49f
    // 0xa0398c: cmp             x3, #1
    // 0xa03990: b.ls            #0xa039ac
    // 0xa03994: r17 = -4518
    //     0xa03994: mov             x17, #-0x11a6
    // 0xa03998: add             x3, x3, x17
    // 0xa0399c: cmp             x3, #1
    // 0xa039a0: b.ls            #0xa039ac
    // 0xa039a4: r0 = false
    //     0xa039a4: add             x0, NULL, #0x30  ; false
    // 0xa039a8: b               #0xa039b0
    // 0xa039ac: r0 = true
    //     0xa039ac: add             x0, NULL, #0x20  ; true
    // 0xa039b0: tbnz            w0, #4, #0xa03b20
    // 0xa039b4: b               #0xa03adc
    // 0xa039b8: ldur            x0, [fp, #-0xa8]
    // 0xa039bc: r1 = Null
    //     0xa039bc: mov             x1, NULL
    // 0xa039c0: r2 = 6
    //     0xa039c0: mov             x2, #6
    // 0xa039c4: r0 = AllocateArray()
    //     0xa039c4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa039c8: r17 = "Unable to determine D-Bus unix address path from address \'"
    //     0xa039c8: ldr             x17, [PP, #0x7bb8]  ; [pp+0x7bb8] "Unable to determine D-Bus unix address path from address \'"
    // 0xa039cc: StoreField: r0->field_f = r17
    //     0xa039cc: stur            w17, [x0, #0xf]
    // 0xa039d0: ldur            x1, [fp, #-0xa8]
    // 0xa039d4: StoreField: r0->field_13 = r1
    //     0xa039d4: stur            w1, [x0, #0x13]
    // 0xa039d8: r17 = "\'"
    //     0xa039d8: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xa039dc: StoreField: r0->field_17 = r17
    //     0xa039dc: stur            w17, [x0, #0x17]
    // 0xa039e0: SaveReg r0
    //     0xa039e0: str             x0, [SP, #-8]!
    // 0xa039e4: r0 = _interpolate()
    //     0xa039e4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa039e8: add             SP, SP, #8
    // 0xa039ec: r0 = Throw()
    //     0xa039ec: bl              #0xd67e38  ; ThrowStub
    // 0xa039f0: brk             #0
    // 0xa039f4: ldur            x0, [fp, #-0xa8]
    // 0xa039f8: r1 = Null
    //     0xa039f8: mov             x1, NULL
    // 0xa039fc: r2 = 6
    //     0xa039fc: mov             x2, #6
    // 0xa03a00: r0 = AllocateArray()
    //     0xa03a00: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa03a04: r17 = "\'Unable to determine hostname from address \'"
    //     0xa03a04: ldr             x17, [PP, #0x7bc0]  ; [pp+0x7bc0] "\'Unable to determine hostname from address \'"
    // 0xa03a08: StoreField: r0->field_f = r17
    //     0xa03a08: stur            w17, [x0, #0xf]
    // 0xa03a0c: ldur            x1, [fp, #-0xa8]
    // 0xa03a10: StoreField: r0->field_13 = r1
    //     0xa03a10: stur            w1, [x0, #0x13]
    // 0xa03a14: r17 = "\'"
    //     0xa03a14: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xa03a18: StoreField: r0->field_17 = r17
    //     0xa03a18: stur            w17, [x0, #0x17]
    // 0xa03a1c: SaveReg r0
    //     0xa03a1c: str             x0, [SP, #-8]!
    // 0xa03a20: r0 = _interpolate()
    //     0xa03a20: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa03a24: add             SP, SP, #8
    // 0xa03a28: r0 = Throw()
    //     0xa03a28: bl              #0xd67e38  ; ThrowStub
    // 0xa03a2c: brk             #0
    // 0xa03a30: ldur            x0, [fp, #-0xb0]
    // 0xa03a34: r1 = Null
    //     0xa03a34: mov             x1, NULL
    // 0xa03a38: r2 = 6
    //     0xa03a38: mov             x2, #6
    // 0xa03a3c: r0 = AllocateArray()
    //     0xa03a3c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa03a40: r17 = "Failed to resolve host \'"
    //     0xa03a40: ldr             x17, [PP, #0x7bc8]  ; [pp+0x7bc8] "Failed to resolve host \'"
    // 0xa03a44: StoreField: r0->field_f = r17
    //     0xa03a44: stur            w17, [x0, #0xf]
    // 0xa03a48: ldur            x1, [fp, #-0xb0]
    // 0xa03a4c: StoreField: r0->field_13 = r1
    //     0xa03a4c: stur            w1, [x0, #0x13]
    // 0xa03a50: r17 = "\'"
    //     0xa03a50: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xa03a54: StoreField: r0->field_17 = r17
    //     0xa03a54: stur            w17, [x0, #0x17]
    // 0xa03a58: SaveReg r0
    //     0xa03a58: str             x0, [SP, #-8]!
    // 0xa03a5c: r0 = _interpolate()
    //     0xa03a5c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa03a60: add             SP, SP, #8
    // 0xa03a64: r0 = Throw()
    //     0xa03a64: bl              #0xd67e38  ; ThrowStub
    // 0xa03a68: brk             #0
    // 0xa03a6c: ldur            x0, [fp, #-0xa0]
    // 0xa03a70: r1 = Null
    //     0xa03a70: mov             x1, NULL
    // 0xa03a74: r2 = 6
    //     0xa03a74: mov             x2, #6
    // 0xa03a78: r0 = AllocateArray()
    //     0xa03a78: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa03a7c: r17 = "Invalid D-Bus address family: \'"
    //     0xa03a7c: ldr             x17, [PP, #0x7bd0]  ; [pp+0x7bd0] "Invalid D-Bus address family: \'"
    // 0xa03a80: StoreField: r0->field_f = r17
    //     0xa03a80: stur            w17, [x0, #0xf]
    // 0xa03a84: ldur            x1, [fp, #-0xa0]
    // 0xa03a88: StoreField: r0->field_13 = r1
    //     0xa03a88: stur            w1, [x0, #0x13]
    // 0xa03a8c: r17 = "\'"
    //     0xa03a8c: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xa03a90: StoreField: r0->field_17 = r17
    //     0xa03a90: stur            w17, [x0, #0x17]
    // 0xa03a94: SaveReg r0
    //     0xa03a94: str             x0, [SP, #-8]!
    // 0xa03a98: r0 = _interpolate()
    //     0xa03a98: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa03a9c: add             SP, SP, #8
    // 0xa03aa0: r0 = Throw()
    //     0xa03aa0: bl              #0xd67e38  ; ThrowStub
    // 0xa03aa4: brk             #0
    // 0xa03aa8: ldur            x3, [fp, #-0xa8]
    // 0xa03aac: r1 = Null
    //     0xa03aac: mov             x1, NULL
    // 0xa03ab0: r2 = 4
    //     0xa03ab0: mov             x2, #4
    // 0xa03ab4: r0 = AllocateArray()
    //     0xa03ab4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa03ab8: r17 = "D-Bus address transport not supported: "
    //     0xa03ab8: ldr             x17, [PP, #0x7bd8]  ; [pp+0x7bd8] "D-Bus address transport not supported: "
    // 0xa03abc: StoreField: r0->field_f = r17
    //     0xa03abc: stur            w17, [x0, #0xf]
    // 0xa03ac0: ldur            x1, [fp, #-0xa8]
    // 0xa03ac4: StoreField: r0->field_13 = r1
    //     0xa03ac4: stur            w1, [x0, #0x13]
    // 0xa03ac8: SaveReg r0
    //     0xa03ac8: str             x0, [SP, #-8]!
    // 0xa03acc: r0 = _interpolate()
    //     0xa03acc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa03ad0: add             SP, SP, #8
    // 0xa03ad4: r0 = Throw()
    //     0xa03ad4: bl              #0xd67e38  ; ThrowStub
    // 0xa03ad8: brk             #0
    // 0xa03adc: ldur            x0, [fp, #-0x50]
    // 0xa03ae0: r1 = Null
    //     0xa03ae0: mov             x1, NULL
    // 0xa03ae4: r2 = 6
    //     0xa03ae4: mov             x2, #6
    // 0xa03ae8: r0 = AllocateArray()
    //     0xa03ae8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa03aec: r17 = "Invalid port number in address \'"
    //     0xa03aec: ldr             x17, [PP, #0x7be0]  ; [pp+0x7be0] "Invalid port number in address \'"
    // 0xa03af0: StoreField: r0->field_f = r17
    //     0xa03af0: stur            w17, [x0, #0xf]
    // 0xa03af4: ldur            x1, [fp, #-0x50]
    // 0xa03af8: LoadField: r2 = r1->field_7
    //     0xa03af8: ldur            w2, [x1, #7]
    // 0xa03afc: DecompressPointer r2
    //     0xa03afc: add             x2, x2, HEAP, lsl #32
    // 0xa03b00: StoreField: r0->field_13 = r2
    //     0xa03b00: stur            w2, [x0, #0x13]
    // 0xa03b04: r17 = "\'"
    //     0xa03b04: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xa03b08: StoreField: r0->field_17 = r17
    //     0xa03b08: stur            w17, [x0, #0x17]
    // 0xa03b0c: SaveReg r0
    //     0xa03b0c: str             x0, [SP, #-8]!
    // 0xa03b10: r0 = _interpolate()
    //     0xa03b10: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa03b14: add             SP, SP, #8
    // 0xa03b18: r0 = Throw()
    //     0xa03b18: bl              #0xd67e38  ; ThrowStub
    // 0xa03b1c: brk             #0
    // 0xa03b20: ldur            x0, [fp, #-0x90]
    // 0xa03b24: ldur            x1, [fp, #-0x98]
    // 0xa03b28: r0 = ReThrow()
    //     0xa03b28: bl              #0xd67e14  ; ReThrowStub
    // 0xa03b2c: brk             #0
    // 0xa03b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa03b30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa03b34: b               #0xa0357c
    // 0xa03b38: r9 = transport
    //     0xa03b38: ldr             x9, [PP, #0x7be8]  ; [pp+0x7be8] Field <DBusAddress.transport>: late final (offset: 0x8)
    // 0xa03b3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa03b3c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa03b40: r9 = properties
    //     0xa03b40: ldr             x9, [PP, #0x7bf0]  ; [pp+0x7bf0] Field <DBusAddress.properties>: late final (offset: 0xc)
    // 0xa03b44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa03b44: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa03b48: r9 = properties
    //     0xa03b48: ldr             x9, [PP, #0x7bf0]  ; [pp+0x7bf0] Field <DBusAddress.properties>: late final (offset: 0xc)
    // 0xa03b4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa03b4c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RawSocketEvent) {
    // ** addr: 0xa03b50, size: 0xb8
    // 0xa03b50: EnterFrame
    //     0xa03b50: stp             fp, lr, [SP, #-0x10]!
    //     0xa03b54: mov             fp, SP
    // 0xa03b58: ldr             x0, [fp, #0x18]
    // 0xa03b5c: LoadField: r1 = r0->field_17
    //     0xa03b5c: ldur            w1, [x0, #0x17]
    // 0xa03b60: DecompressPointer r1
    //     0xa03b60: add             x1, x1, HEAP, lsl #32
    // 0xa03b64: CheckStackOverflow
    //     0xa03b64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa03b68: cmp             SP, x16
    //     0xa03b6c: b.ls            #0xa03c00
    // 0xa03b70: ldr             x0, [fp, #0x10]
    // 0xa03b74: r16 = Instance_RawSocketEvent
    //     0xa03b74: ldr             x16, [PP, #0x68a8]  ; [pp+0x68a8] Obj!RawSocketEvent@b5f521
    // 0xa03b78: cmp             w0, w16
    // 0xa03b7c: b.ne            #0xa03b98
    // 0xa03b80: LoadField: r0 = r1->field_f
    //     0xa03b80: ldur            w0, [x1, #0xf]
    // 0xa03b84: DecompressPointer r0
    //     0xa03b84: add             x0, x0, HEAP, lsl #32
    // 0xa03b88: SaveReg r0
    //     0xa03b88: str             x0, [SP, #-8]!
    // 0xa03b8c: r0 = _readData()
    //     0xa03b8c: bl              #0xa03c08  ; [package:dbus/src/dbus_client.dart] DBusClient::_readData
    // 0xa03b90: add             SP, SP, #8
    // 0xa03b94: b               #0xa03bf0
    // 0xa03b98: r16 = Instance_RawSocketEvent
    //     0xa03b98: ldr             x16, [PP, #0x6978]  ; [pp+0x6978] Obj!RawSocketEvent@b5f4f1
    // 0xa03b9c: cmp             w0, w16
    // 0xa03ba0: b.eq            #0xa03bb0
    // 0xa03ba4: r16 = Instance_RawSocketEvent
    //     0xa03ba4: ldr             x16, [PP, #0x68d8]  ; [pp+0x68d8] Obj!RawSocketEvent@b5f501
    // 0xa03ba8: cmp             w0, w16
    // 0xa03bac: b.ne            #0xa03bf0
    // 0xa03bb0: r0 = true
    //     0xa03bb0: add             x0, NULL, #0x20  ; true
    // 0xa03bb4: LoadField: r2 = r1->field_f
    //     0xa03bb4: ldur            w2, [x1, #0xf]
    // 0xa03bb8: DecompressPointer r2
    //     0xa03bb8: add             x2, x2, HEAP, lsl #32
    // 0xa03bbc: StoreField: r2->field_f = r0
    //     0xa03bbc: stur            w0, [x2, #0xf]
    // 0xa03bc0: LoadField: r0 = r2->field_b
    //     0xa03bc0: ldur            w0, [x2, #0xb]
    // 0xa03bc4: DecompressPointer r0
    //     0xa03bc4: add             x0, x0, HEAP, lsl #32
    // 0xa03bc8: cmp             w0, NULL
    // 0xa03bcc: b.eq            #0xa03bf0
    // 0xa03bd0: r1 = LoadClassIdInstr(r0)
    //     0xa03bd0: ldur            x1, [x0, #-1]
    //     0xa03bd4: ubfx            x1, x1, #0xc, #0x14
    // 0xa03bd8: SaveReg r0
    //     0xa03bd8: str             x0, [SP, #-8]!
    // 0xa03bdc: mov             x0, x1
    // 0xa03be0: r0 = GDT[cid_x0 + -0xfec]()
    //     0xa03be0: sub             lr, x0, #0xfec
    //     0xa03be4: ldr             lr, [x21, lr, lsl #3]
    //     0xa03be8: blr             lr
    // 0xa03bec: add             SP, SP, #8
    // 0xa03bf0: r0 = Null
    //     0xa03bf0: mov             x0, NULL
    // 0xa03bf4: LeaveFrame
    //     0xa03bf4: mov             SP, fp
    //     0xa03bf8: ldp             fp, lr, [SP], #0x10
    // 0xa03bfc: ret
    //     0xa03bfc: ret             
    // 0xa03c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa03c00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa03c04: b               #0xa03b70
  }
  _ _readData(/* No info */) {
    // ** addr: 0xa03c08, size: 0x398
    // 0xa03c08: EnterFrame
    //     0xa03c08: stp             fp, lr, [SP, #-0x10]!
    //     0xa03c0c: mov             fp, SP
    // 0xa03c10: AllocStack(0x48)
    //     0xa03c10: sub             SP, SP, #0x48
    // 0xa03c14: CheckStackOverflow
    //     0xa03c14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa03c18: cmp             SP, x16
    //     0xa03c1c: b.ls            #0xa03f88
    // 0xa03c20: ldr             x1, [fp, #0x10]
    // 0xa03c24: LoadField: r0 = r1->field_b
    //     0xa03c24: ldur            w0, [x1, #0xb]
    // 0xa03c28: DecompressPointer r0
    //     0xa03c28: add             x0, x0, HEAP, lsl #32
    // 0xa03c2c: cmp             w0, NULL
    // 0xa03c30: b.ne            #0xa03c3c
    // 0xa03c34: r0 = Null
    //     0xa03c34: mov             x0, NULL
    // 0xa03c38: b               #0xa03c5c
    // 0xa03c3c: r2 = LoadClassIdInstr(r0)
    //     0xa03c3c: ldur            x2, [x0, #-1]
    //     0xa03c40: ubfx            x2, x2, #0xc, #0x14
    // 0xa03c44: SaveReg r0
    //     0xa03c44: str             x0, [SP, #-8]!
    // 0xa03c48: mov             x0, x2
    // 0xa03c4c: r0 = GDT[cid_x0 + -0xd94]()
    //     0xa03c4c: sub             lr, x0, #0xd94
    //     0xa03c50: ldr             lr, [x21, lr, lsl #3]
    //     0xa03c54: blr             lr
    // 0xa03c58: add             SP, SP, #8
    // 0xa03c5c: stur            x0, [fp, #-0x10]
    // 0xa03c60: cmp             w0, NULL
    // 0xa03c64: b.ne            #0xa03c78
    // 0xa03c68: r0 = Null
    //     0xa03c68: mov             x0, NULL
    // 0xa03c6c: LeaveFrame
    //     0xa03c6c: mov             SP, fp
    //     0xa03c70: ldp             fp, lr, [SP], #0x10
    // 0xa03c74: ret
    //     0xa03c74: ret             
    // 0xa03c78: ldr             x1, [fp, #0x10]
    // 0xa03c7c: LoadField: r2 = r1->field_13
    //     0xa03c7c: ldur            w2, [x1, #0x13]
    // 0xa03c80: DecompressPointer r2
    //     0xa03c80: add             x2, x2, HEAP, lsl #32
    // 0xa03c84: stur            x2, [fp, #-8]
    // 0xa03c88: LoadField: r3 = r0->field_7
    //     0xa03c88: ldur            w3, [x0, #7]
    // 0xa03c8c: DecompressPointer r3
    //     0xa03c8c: add             x3, x3, HEAP, lsl #32
    // 0xa03c90: stp             x3, x2, [SP, #-0x10]!
    // 0xa03c94: r0 = writeBytes()
    //     0xa03c94: bl              #0xa0dc80  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::writeBytes
    // 0xa03c98: add             SP, SP, #0x10
    // 0xa03c9c: ldur            x0, [fp, #-0x10]
    // 0xa03ca0: LoadField: r1 = r0->field_b
    //     0xa03ca0: ldur            w1, [x0, #0xb]
    // 0xa03ca4: DecompressPointer r1
    //     0xa03ca4: add             x1, x1, HEAP, lsl #32
    // 0xa03ca8: stur            x1, [fp, #-0x30]
    // 0xa03cac: LoadField: r2 = r1->field_7
    //     0xa03cac: ldur            w2, [x1, #7]
    // 0xa03cb0: DecompressPointer r2
    //     0xa03cb0: add             x2, x2, HEAP, lsl #32
    // 0xa03cb4: stur            x2, [fp, #-0x28]
    // 0xa03cb8: LoadField: r0 = r1->field_b
    //     0xa03cb8: ldur            w0, [x1, #0xb]
    // 0xa03cbc: DecompressPointer r0
    //     0xa03cbc: add             x0, x0, HEAP, lsl #32
    // 0xa03cc0: r3 = LoadInt32Instr(r0)
    //     0xa03cc0: sbfx            x3, x0, #1, #0x1f
    // 0xa03cc4: ldur            x4, [fp, #-8]
    // 0xa03cc8: stur            x3, [fp, #-0x20]
    // 0xa03ccc: LoadField: r5 = r4->field_93
    //     0xa03ccc: ldur            w5, [x4, #0x93]
    // 0xa03cd0: DecompressPointer r5
    //     0xa03cd0: add             x5, x5, HEAP, lsl #32
    // 0xa03cd4: stur            x5, [fp, #-0x10]
    // 0xa03cd8: r7 = 0
    //     0xa03cd8: mov             x7, #0
    // 0xa03cdc: ldr             x6, [fp, #0x10]
    // 0xa03ce0: stur            x7, [fp, #-0x18]
    // 0xa03ce4: CheckStackOverflow
    //     0xa03ce4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa03ce8: cmp             SP, x16
    //     0xa03cec: b.ls            #0xa03f90
    // 0xa03cf0: r0 = LoadClassIdInstr(r1)
    //     0xa03cf0: ldur            x0, [x1, #-1]
    //     0xa03cf4: ubfx            x0, x0, #0xc, #0x14
    // 0xa03cf8: SaveReg r1
    //     0xa03cf8: str             x1, [SP, #-8]!
    // 0xa03cfc: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa03cfc: mov             x17, #0xb8ea
    //     0xa03d00: add             lr, x0, x17
    //     0xa03d04: ldr             lr, [x21, lr, lsl #3]
    //     0xa03d08: blr             lr
    // 0xa03d0c: add             SP, SP, #8
    // 0xa03d10: r1 = LoadInt32Instr(r0)
    //     0xa03d10: sbfx            x1, x0, #1, #0x1f
    //     0xa03d14: tbz             w0, #0, #0xa03d1c
    //     0xa03d18: ldur            x1, [x0, #7]
    // 0xa03d1c: ldur            x2, [fp, #-0x20]
    // 0xa03d20: cmp             x2, x1
    // 0xa03d24: b.ne            #0xa03f70
    // 0xa03d28: ldur            x3, [fp, #-0x30]
    // 0xa03d2c: ldur            x4, [fp, #-0x18]
    // 0xa03d30: cmp             x4, x1
    // 0xa03d34: b.lt            #0xa03eac
    // 0xa03d38: ldr             x0, [fp, #0x10]
    // 0xa03d3c: LoadField: r1 = r0->field_17
    //     0xa03d3c: ldur            w1, [x0, #0x17]
    // 0xa03d40: DecompressPointer r1
    //     0xa03d40: add             x1, x1, HEAP, lsl #32
    // 0xa03d44: stur            x1, [fp, #-0x38]
    // 0xa03d48: ldur            x2, [fp, #-8]
    // 0xa03d4c: r3 = false
    //     0xa03d4c: add             x3, NULL, #0x30  ; false
    // 0xa03d50: CheckStackOverflow
    //     0xa03d50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa03d54: cmp             SP, x16
    //     0xa03d58: b.ls            #0xa03f98
    // 0xa03d5c: tbz             w3, #4, #0xa03e9c
    // 0xa03d60: LoadField: r3 = r0->field_1b
    //     0xa03d60: ldur            w3, [x0, #0x1b]
    // 0xa03d64: DecompressPointer r3
    //     0xa03d64: add             x3, x3, HEAP, lsl #32
    // 0xa03d68: tbz             w3, #4, #0xa03da4
    // 0xa03d6c: SaveReg r2
    //     0xa03d6c: str             x2, [SP, #-8]!
    // 0xa03d70: r0 = readLine()
    //     0xa03d70: bl              #0xa0db10  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readLine
    // 0xa03d74: add             SP, SP, #8
    // 0xa03d78: cmp             w0, NULL
    // 0xa03d7c: b.ne            #0xa03d88
    // 0xa03d80: r0 = true
    //     0xa03d80: add             x0, NULL, #0x20  ; true
    // 0xa03d84: b               #0xa03d9c
    // 0xa03d88: ldur            x16, [fp, #-0x38]
    // 0xa03d8c: stp             x0, x16, [SP, #-0x10]!
    // 0xa03d90: r0 = processResponse()
    //     0xa03d90: bl              #0xa0c11c  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::processResponse
    // 0xa03d94: add             SP, SP, #0x10
    // 0xa03d98: r0 = false
    //     0xa03d98: add             x0, NULL, #0x30  ; false
    // 0xa03d9c: mov             x3, x0
    // 0xa03da0: b               #0xa03db8
    // 0xa03da4: ldr             x16, [fp, #0x10]
    // 0xa03da8: SaveReg r16
    //     0xa03da8: str             x16, [SP, #-8]!
    // 0xa03dac: r0 = _processMessages()
    //     0xa03dac: bl              #0xa04008  ; [package:dbus/src/dbus_client.dart] DBusClient::_processMessages
    // 0xa03db0: add             SP, SP, #8
    // 0xa03db4: mov             x3, x0
    // 0xa03db8: ldur            x1, [fp, #-8]
    // 0xa03dbc: stur            x3, [fp, #-0x40]
    // 0xa03dc0: LoadField: r0 = r1->field_8f
    //     0xa03dc0: ldur            w0, [x1, #0x8f]
    // 0xa03dc4: DecompressPointer r0
    //     0xa03dc4: add             x0, x0, HEAP, lsl #32
    // 0xa03dc8: LoadField: r2 = r1->field_9b
    //     0xa03dc8: ldur            x2, [x1, #0x9b]
    // 0xa03dcc: r4 = LoadClassIdInstr(r0)
    //     0xa03dcc: ldur            x4, [x0, #-1]
    //     0xa03dd0: ubfx            x4, x4, #0xc, #0x14
    // 0xa03dd4: stp             x2, x0, [SP, #-0x10]!
    // 0xa03dd8: mov             x0, x4
    // 0xa03ddc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa03ddc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa03de0: r0 = GDT[cid_x0 + 0x10217]()
    //     0xa03de0: mov             x17, #0x217
    //     0xa03de4: movk            x17, #1, lsl #16
    //     0xa03de8: add             lr, x0, x17
    //     0xa03dec: ldr             lr, [x21, lr, lsl #3]
    //     0xa03df0: blr             lr
    // 0xa03df4: add             SP, SP, #0x10
    // 0xa03df8: mov             x2, x0
    // 0xa03dfc: ldur            x1, [fp, #-8]
    // 0xa03e00: StoreField: r1->field_8f = r0
    //     0xa03e00: stur            w0, [x1, #0x8f]
    //     0xa03e04: ldurb           w16, [x1, #-1]
    //     0xa03e08: ldurb           w17, [x0, #-1]
    //     0xa03e0c: and             x16, x17, x16, lsr #2
    //     0xa03e10: tst             x16, HEAP, lsr #32
    //     0xa03e14: b.eq            #0xa03e1c
    //     0xa03e18: bl              #0xd6826c
    // 0xa03e1c: r0 = LoadClassIdInstr(r2)
    //     0xa03e1c: ldur            x0, [x2, #-1]
    //     0xa03e20: ubfx            x0, x0, #0xc, #0x14
    // 0xa03e24: SaveReg r2
    //     0xa03e24: str             x2, [SP, #-8]!
    // 0xa03e28: r0 = GDT[cid_x0 + -0xf7e]()
    //     0xa03e28: sub             lr, x0, #0xf7e
    //     0xa03e2c: ldr             lr, [x21, lr, lsl #3]
    //     0xa03e30: blr             lr
    // 0xa03e34: add             SP, SP, #8
    // 0xa03e38: r1 = LoadClassIdInstr(r0)
    //     0xa03e38: ldur            x1, [x0, #-1]
    //     0xa03e3c: ubfx            x1, x1, #0xc, #0x14
    // 0xa03e40: stp             xzr, x0, [SP, #-0x10]!
    // 0xa03e44: SaveReg rNULL
    //     0xa03e44: str             NULL, [SP, #-8]!
    // 0xa03e48: mov             x0, x1
    // 0xa03e4c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa03e4c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa03e50: r0 = GDT[cid_x0 + -0xff7]()
    //     0xa03e50: sub             lr, x0, #0xff7
    //     0xa03e54: ldr             lr, [x21, lr, lsl #3]
    //     0xa03e58: blr             lr
    // 0xa03e5c: add             SP, SP, #0x18
    // 0xa03e60: ldur            x5, [fp, #-8]
    // 0xa03e64: StoreField: r5->field_97 = r0
    //     0xa03e64: stur            w0, [x5, #0x97]
    //     0xa03e68: ldurb           w16, [x5, #-1]
    //     0xa03e6c: ldurb           w17, [x0, #-1]
    //     0xa03e70: and             x16, x17, x16, lsr #2
    //     0xa03e74: tst             x16, HEAP, lsr #32
    //     0xa03e78: b.eq            #0xa03e80
    //     0xa03e7c: bl              #0xd682ec
    // 0xa03e80: r6 = 0
    //     0xa03e80: mov             x6, #0
    // 0xa03e84: StoreField: r5->field_9b = r6
    //     0xa03e84: stur            x6, [x5, #0x9b]
    // 0xa03e88: ldur            x3, [fp, #-0x40]
    // 0xa03e8c: ldr             x0, [fp, #0x10]
    // 0xa03e90: mov             x2, x5
    // 0xa03e94: ldur            x1, [fp, #-0x38]
    // 0xa03e98: b               #0xa03d50
    // 0xa03e9c: r0 = Null
    //     0xa03e9c: mov             x0, NULL
    // 0xa03ea0: LeaveFrame
    //     0xa03ea0: mov             SP, fp
    //     0xa03ea4: ldp             fp, lr, [SP], #0x10
    // 0xa03ea8: ret
    //     0xa03ea8: ret             
    // 0xa03eac: ldur            x5, [fp, #-8]
    // 0xa03eb0: r6 = 0
    //     0xa03eb0: mov             x6, #0
    // 0xa03eb4: r0 = BoxInt64Instr(r4)
    //     0xa03eb4: sbfiz           x0, x4, #1, #0x1f
    //     0xa03eb8: cmp             x4, x0, asr #1
    //     0xa03ebc: b.eq            #0xa03ec8
    //     0xa03ec0: bl              #0xd69bb8
    //     0xa03ec4: stur            x4, [x0, #7]
    // 0xa03ec8: r1 = LoadClassIdInstr(r3)
    //     0xa03ec8: ldur            x1, [x3, #-1]
    //     0xa03ecc: ubfx            x1, x1, #0xc, #0x14
    // 0xa03ed0: stp             x0, x3, [SP, #-0x10]!
    // 0xa03ed4: mov             x0, x1
    // 0xa03ed8: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa03ed8: mov             x17, #0xd175
    //     0xa03edc: add             lr, x0, x17
    //     0xa03ee0: ldr             lr, [x21, lr, lsl #3]
    //     0xa03ee4: blr             lr
    // 0xa03ee8: add             SP, SP, #0x10
    // 0xa03eec: mov             x3, x0
    // 0xa03ef0: ldur            x0, [fp, #-0x18]
    // 0xa03ef4: stur            x3, [fp, #-0x38]
    // 0xa03ef8: add             x7, x0, #1
    // 0xa03efc: stur            x7, [fp, #-0x48]
    // 0xa03f00: cmp             w3, NULL
    // 0xa03f04: b.ne            #0xa03f34
    // 0xa03f08: mov             x0, x3
    // 0xa03f0c: ldur            x2, [fp, #-0x28]
    // 0xa03f10: r1 = Null
    //     0xa03f10: mov             x1, NULL
    // 0xa03f14: cmp             w2, NULL
    // 0xa03f18: b.eq            #0xa03f34
    // 0xa03f1c: LoadField: r4 = r2->field_17
    //     0xa03f1c: ldur            w4, [x2, #0x17]
    // 0xa03f20: DecompressPointer r4
    //     0xa03f20: add             x4, x4, HEAP, lsl #32
    // 0xa03f24: r8 = X0
    //     0xa03f24: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa03f28: LoadField: r9 = r4->field_7
    //     0xa03f28: ldur            x9, [x4, #7]
    // 0xa03f2c: r3 = Null
    //     0xa03f2c: ldr             x3, [PP, #0x7bf8]  ; [pp+0x7bf8] Null
    // 0xa03f30: blr             x9
    // 0xa03f34: ldur            x16, [fp, #-0x38]
    // 0xa03f38: SaveReg r16
    //     0xa03f38: str             x16, [SP, #-8]!
    // 0xa03f3c: r0 = extractHandles()
    //     0xa03f3c: bl              #0xa03fa0  ; [dart:io] _SocketControlMessageImpl::extractHandles
    // 0xa03f40: add             SP, SP, #8
    // 0xa03f44: ldur            x16, [fp, #-0x10]
    // 0xa03f48: stp             x0, x16, [SP, #-0x10]!
    // 0xa03f4c: r0 = addAll()
    //     0xa03f4c: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa03f50: add             SP, SP, #0x10
    // 0xa03f54: ldur            x7, [fp, #-0x48]
    // 0xa03f58: ldur            x4, [fp, #-8]
    // 0xa03f5c: ldur            x1, [fp, #-0x30]
    // 0xa03f60: ldur            x5, [fp, #-0x10]
    // 0xa03f64: ldur            x2, [fp, #-0x28]
    // 0xa03f68: ldur            x3, [fp, #-0x20]
    // 0xa03f6c: b               #0xa03cdc
    // 0xa03f70: ldur            x0, [fp, #-0x30]
    // 0xa03f74: r0 = ConcurrentModificationError()
    //     0xa03f74: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa03f78: ldur            x3, [fp, #-0x30]
    // 0xa03f7c: StoreField: r0->field_b = r3
    //     0xa03f7c: stur            w3, [x0, #0xb]
    // 0xa03f80: r0 = Throw()
    //     0xa03f80: bl              #0xd67e38  ; ThrowStub
    // 0xa03f84: brk             #0
    // 0xa03f88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa03f88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa03f8c: b               #0xa03c20
    // 0xa03f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa03f90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa03f94: b               #0xa03cf0
    // 0xa03f98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa03f98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa03f9c: b               #0xa03d5c
  }
  _ _processMessages(/* No info */) {
    // ** addr: 0xa04008, size: 0xe8
    // 0xa04008: EnterFrame
    //     0xa04008: stp             fp, lr, [SP, #-0x10]!
    //     0xa0400c: mov             fp, SP
    // 0xa04010: AllocStack(0x10)
    //     0xa04010: sub             SP, SP, #0x10
    // 0xa04014: CheckStackOverflow
    //     0xa04014: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa04018: cmp             SP, x16
    //     0xa0401c: b.ls            #0xa040e8
    // 0xa04020: ldr             x0, [fp, #0x10]
    // 0xa04024: LoadField: r1 = r0->field_13
    //     0xa04024: ldur            w1, [x0, #0x13]
    // 0xa04028: DecompressPointer r1
    //     0xa04028: add             x1, x1, HEAP, lsl #32
    // 0xa0402c: stur            x1, [fp, #-0x10]
    // 0xa04030: LoadField: r2 = r1->field_9b
    //     0xa04030: ldur            x2, [x1, #0x9b]
    // 0xa04034: stur            x2, [fp, #-8]
    // 0xa04038: SaveReg r1
    //     0xa04038: str             x1, [SP, #-8]!
    // 0xa0403c: r0 = readMessage()
    //     0xa0403c: bl              #0xa07878  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readMessage
    // 0xa04040: add             SP, SP, #8
    // 0xa04044: cmp             w0, NULL
    // 0xa04048: b.ne            #0xa04068
    // 0xa0404c: ldur            x0, [fp, #-0x10]
    // 0xa04050: ldur            x1, [fp, #-8]
    // 0xa04054: StoreField: r0->field_9b = r1
    //     0xa04054: stur            x1, [x0, #0x9b]
    // 0xa04058: r0 = true
    //     0xa04058: add             x0, NULL, #0x20  ; true
    // 0xa0405c: LeaveFrame
    //     0xa0405c: mov             SP, fp
    //     0xa04060: ldp             fp, lr, [SP], #0x10
    // 0xa04064: ret
    //     0xa04064: ret             
    // 0xa04068: LoadField: r1 = r0->field_7
    //     0xa04068: ldur            w1, [x0, #7]
    // 0xa0406c: DecompressPointer r1
    //     0xa0406c: add             x1, x1, HEAP, lsl #32
    // 0xa04070: r16 = Instance_DBusMessageType
    //     0xa04070: ldr             x16, [PP, #0x7750]  ; [pp+0x7750] Obj!DBusMessageType@b667d1
    // 0xa04074: cmp             w1, w16
    // 0xa04078: b.ne            #0xa04090
    // 0xa0407c: ldr             x16, [fp, #0x10]
    // 0xa04080: stp             x0, x16, [SP, #-0x10]!
    // 0xa04084: r0 = _processMethodCall()
    //     0xa04084: bl              #0xa05668  ; [package:dbus/src/dbus_client.dart] DBusClient::_processMethodCall
    // 0xa04088: add             SP, SP, #0x10
    // 0xa0408c: b               #0xa040d8
    // 0xa04090: r16 = Instance_DBusMessageType
    //     0xa04090: ldr             x16, [PP, #0x7818]  ; [pp+0x7818] Obj!DBusMessageType@b66791
    // 0xa04094: cmp             w1, w16
    // 0xa04098: b.eq            #0xa040a8
    // 0xa0409c: r16 = Instance_DBusMessageType
    //     0xa0409c: ldr             x16, [PP, #0x7820]  ; [pp+0x7820] Obj!DBusMessageType@b66771
    // 0xa040a0: cmp             w1, w16
    // 0xa040a4: b.ne            #0xa040bc
    // 0xa040a8: ldr             x16, [fp, #0x10]
    // 0xa040ac: stp             x0, x16, [SP, #-0x10]!
    // 0xa040b0: r0 = _processMethodResponse()
    //     0xa040b0: bl              #0xa054d8  ; [package:dbus/src/dbus_client.dart] DBusClient::_processMethodResponse
    // 0xa040b4: add             SP, SP, #0x10
    // 0xa040b8: b               #0xa040d8
    // 0xa040bc: r16 = Instance_DBusMessageType
    //     0xa040bc: ldr             x16, [PP, #0x530]  ; [pp+0x530] Obj!DBusMessageType@b667b1
    // 0xa040c0: cmp             w1, w16
    // 0xa040c4: b.ne            #0xa040d8
    // 0xa040c8: ldr             x16, [fp, #0x10]
    // 0xa040cc: stp             x0, x16, [SP, #-0x10]!
    // 0xa040d0: r0 = _processSignal()
    //     0xa040d0: bl              #0xa040f0  ; [package:dbus/src/dbus_client.dart] DBusClient::_processSignal
    // 0xa040d4: add             SP, SP, #0x10
    // 0xa040d8: r0 = false
    //     0xa040d8: add             x0, NULL, #0x30  ; false
    // 0xa040dc: LeaveFrame
    //     0xa040dc: mov             SP, fp
    //     0xa040e0: ldp             fp, lr, [SP], #0x10
    // 0xa040e4: ret
    //     0xa040e4: ret             
    // 0xa040e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa040e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa040ec: b               #0xa04020
  }
  _ _processSignal(/* No info */) {
    // ** addr: 0xa040f0, size: 0x6dc
    // 0xa040f0: EnterFrame
    //     0xa040f0: stp             fp, lr, [SP, #-0x10]!
    //     0xa040f4: mov             fp, SP
    // 0xa040f8: AllocStack(0x90)
    //     0xa040f8: sub             SP, SP, #0x90
    // 0xa040fc: CheckStackOverflow
    //     0xa040fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa04100: cmp             SP, x16
    //     0xa04104: b.ls            #0xa047b4
    // 0xa04108: ldr             x0, [fp, #0x10]
    // 0xa0410c: LoadField: r1 = r0->field_17
    //     0xa0410c: ldur            w1, [x0, #0x17]
    // 0xa04110: DecompressPointer r1
    //     0xa04110: add             x1, x1, HEAP, lsl #32
    // 0xa04114: stur            x1, [fp, #-0x50]
    // 0xa04118: cmp             w1, NULL
    // 0xa0411c: b.eq            #0xa04148
    // 0xa04120: LoadField: r2 = r0->field_1b
    //     0xa04120: ldur            w2, [x0, #0x1b]
    // 0xa04124: DecompressPointer r2
    //     0xa04124: add             x2, x2, HEAP, lsl #32
    // 0xa04128: stur            x2, [fp, #-0x48]
    // 0xa0412c: cmp             w2, NULL
    // 0xa04130: b.eq            #0xa04148
    // 0xa04134: LoadField: r3 = r0->field_1f
    //     0xa04134: ldur            w3, [x0, #0x1f]
    // 0xa04138: DecompressPointer r3
    //     0xa04138: add             x3, x3, HEAP, lsl #32
    // 0xa0413c: stur            x3, [fp, #-0x40]
    // 0xa04140: cmp             w3, NULL
    // 0xa04144: b.ne            #0xa04158
    // 0xa04148: r0 = Null
    //     0xa04148: mov             x0, NULL
    // 0xa0414c: LeaveFrame
    //     0xa0414c: mov             SP, fp
    //     0xa04150: ldp             fp, lr, [SP], #0x10
    // 0xa04154: ret
    //     0xa04154: ret             
    // 0xa04158: ldr             x4, [fp, #0x18]
    // 0xa0415c: LoadField: r5 = r4->field_2f
    //     0xa0415c: ldur            w5, [x4, #0x2f]
    // 0xa04160: DecompressPointer r5
    //     0xa04160: add             x5, x5, HEAP, lsl #32
    // 0xa04164: stur            x5, [fp, #-0x38]
    // 0xa04168: LoadField: r6 = r5->field_7
    //     0xa04168: ldur            w6, [x5, #7]
    // 0xa0416c: DecompressPointer r6
    //     0xa0416c: add             x6, x6, HEAP, lsl #32
    // 0xa04170: stur            x6, [fp, #-0x30]
    // 0xa04174: LoadField: r7 = r5->field_b
    //     0xa04174: ldur            w7, [x5, #0xb]
    // 0xa04178: DecompressPointer r7
    //     0xa04178: add             x7, x7, HEAP, lsl #32
    // 0xa0417c: r8 = LoadInt32Instr(r7)
    //     0xa0417c: sbfx            x8, x7, #1, #0x1f
    // 0xa04180: stur            x8, [fp, #-0x28]
    // 0xa04184: LoadField: r7 = r0->field_2f
    //     0xa04184: ldur            w7, [x0, #0x2f]
    // 0xa04188: DecompressPointer r7
    //     0xa04188: add             x7, x7, HEAP, lsl #32
    // 0xa0418c: stur            x7, [fp, #-0x20]
    // 0xa04190: LoadField: r9 = r4->field_47
    //     0xa04190: ldur            w9, [x4, #0x47]
    // 0xa04194: DecompressPointer r9
    //     0xa04194: add             x9, x9, HEAP, lsl #32
    // 0xa04198: stur            x9, [fp, #-0x18]
    // 0xa0419c: LoadField: r4 = r0->field_33
    //     0xa0419c: ldur            w4, [x0, #0x33]
    // 0xa041a0: DecompressPointer r4
    //     0xa041a0: add             x4, x4, HEAP, lsl #32
    // 0xa041a4: stur            x4, [fp, #-0x10]
    // 0xa041a8: r10 = 0
    //     0xa041a8: mov             x10, #0
    // 0xa041ac: stur            x10, [fp, #-8]
    // 0xa041b0: CheckStackOverflow
    //     0xa041b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa041b4: cmp             SP, x16
    //     0xa041b8: b.ls            #0xa047bc
    // 0xa041bc: r0 = LoadClassIdInstr(r5)
    //     0xa041bc: ldur            x0, [x5, #-1]
    //     0xa041c0: ubfx            x0, x0, #0xc, #0x14
    // 0xa041c4: SaveReg r5
    //     0xa041c4: str             x5, [SP, #-8]!
    // 0xa041c8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa041c8: mov             x17, #0xb8ea
    //     0xa041cc: add             lr, x0, x17
    //     0xa041d0: ldr             lr, [x21, lr, lsl #3]
    //     0xa041d4: blr             lr
    // 0xa041d8: add             SP, SP, #8
    // 0xa041dc: r1 = LoadInt32Instr(r0)
    //     0xa041dc: sbfx            x1, x0, #1, #0x1f
    //     0xa041e0: tbz             w0, #0, #0xa041e8
    //     0xa041e4: ldur            x1, [x0, #7]
    // 0xa041e8: ldur            x2, [fp, #-0x28]
    // 0xa041ec: cmp             x2, x1
    // 0xa041f0: b.ne            #0xa04758
    // 0xa041f4: ldur            x3, [fp, #-0x38]
    // 0xa041f8: ldur            x4, [fp, #-8]
    // 0xa041fc: cmp             x4, x1
    // 0xa04200: b.lt            #0xa04214
    // 0xa04204: r0 = Null
    //     0xa04204: mov             x0, NULL
    // 0xa04208: LeaveFrame
    //     0xa04208: mov             SP, fp
    //     0xa0420c: ldp             fp, lr, [SP], #0x10
    // 0xa04210: ret
    //     0xa04210: ret             
    // 0xa04214: r0 = BoxInt64Instr(r4)
    //     0xa04214: sbfiz           x0, x4, #1, #0x1f
    //     0xa04218: cmp             x4, x0, asr #1
    //     0xa0421c: b.eq            #0xa04228
    //     0xa04220: bl              #0xd69bb8
    //     0xa04224: stur            x4, [x0, #7]
    // 0xa04228: r1 = LoadClassIdInstr(r3)
    //     0xa04228: ldur            x1, [x3, #-1]
    //     0xa0422c: ubfx            x1, x1, #0xc, #0x14
    // 0xa04230: stp             x0, x3, [SP, #-0x10]!
    // 0xa04234: mov             x0, x1
    // 0xa04238: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa04238: mov             x17, #0xd175
    //     0xa0423c: add             lr, x0, x17
    //     0xa04240: ldr             lr, [x21, lr, lsl #3]
    //     0xa04244: blr             lr
    // 0xa04248: add             SP, SP, #0x10
    // 0xa0424c: mov             x3, x0
    // 0xa04250: ldur            x0, [fp, #-8]
    // 0xa04254: stur            x3, [fp, #-0x60]
    // 0xa04258: add             x10, x0, #1
    // 0xa0425c: stur            x10, [fp, #-0x58]
    // 0xa04260: cmp             w3, NULL
    // 0xa04264: b.ne            #0xa04294
    // 0xa04268: mov             x0, x3
    // 0xa0426c: ldur            x2, [fp, #-0x30]
    // 0xa04270: r1 = Null
    //     0xa04270: mov             x1, NULL
    // 0xa04274: cmp             w2, NULL
    // 0xa04278: b.eq            #0xa04294
    // 0xa0427c: LoadField: r4 = r2->field_17
    //     0xa0427c: ldur            w4, [x2, #0x17]
    // 0xa04280: DecompressPointer r4
    //     0xa04280: add             x4, x4, HEAP, lsl #32
    // 0xa04284: r8 = X0
    //     0xa04284: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa04288: LoadField: r9 = r4->field_7
    //     0xa04288: ldur            x9, [x4, #7]
    // 0xa0428c: r3 = Null
    //     0xa0428c: ldr             x3, [PP, #0x7c30]  ; [pp+0x7c30] Null
    // 0xa04290: blr             x9
    // 0xa04294: ldur            x1, [fp, #-0x18]
    // 0xa04298: ldur            x0, [fp, #-0x60]
    // 0xa0429c: LoadField: r2 = r0->field_f
    //     0xa0429c: ldur            w2, [x0, #0xf]
    // 0xa042a0: DecompressPointer r2
    //     0xa042a0: add             x2, x2, HEAP, lsl #32
    // 0xa042a4: stur            x2, [fp, #-0x70]
    // 0xa042a8: LoadField: r3 = r2->field_b
    //     0xa042a8: ldur            w3, [x2, #0xb]
    // 0xa042ac: DecompressPointer r3
    //     0xa042ac: add             x3, x3, HEAP, lsl #32
    // 0xa042b0: stur            x3, [fp, #-0x68]
    // 0xa042b4: stp             x3, x1, [SP, #-0x10]!
    // 0xa042b8: r0 = _getValueOrData()
    //     0xa042b8: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa042bc: add             SP, SP, #0x10
    // 0xa042c0: ldur            x1, [fp, #-0x18]
    // 0xa042c4: LoadField: r2 = r1->field_f
    //     0xa042c4: ldur            w2, [x1, #0xf]
    // 0xa042c8: DecompressPointer r2
    //     0xa042c8: add             x2, x2, HEAP, lsl #32
    // 0xa042cc: cmp             w2, w0
    // 0xa042d0: b.ne            #0xa042d8
    // 0xa042d4: r0 = Null
    //     0xa042d4: mov             x0, NULL
    // 0xa042d8: r2 = LoadClassIdInstr(r0)
    //     0xa042d8: ldur            x2, [x0, #-1]
    //     0xa042dc: ubfx            x2, x2, #0xc, #0x14
    // 0xa042e0: ldur            x16, [fp, #-0x20]
    // 0xa042e4: stp             x16, x0, [SP, #-0x10]!
    // 0xa042e8: mov             x0, x2
    // 0xa042ec: mov             lr, x0
    // 0xa042f0: ldr             lr, [x21, lr, lsl #3]
    // 0xa042f4: blr             lr
    // 0xa042f8: add             SP, SP, #0x10
    // 0xa042fc: tbnz            w0, #4, #0xa04308
    // 0xa04300: ldur            x0, [fp, #-0x68]
    // 0xa04304: b               #0xa0430c
    // 0xa04308: ldur            x0, [fp, #-0x20]
    // 0xa0430c: ldur            x16, [fp, #-0x70]
    // 0xa04310: ldur            lr, [fp, #-0x48]
    // 0xa04314: stp             lr, x16, [SP, #-0x10]!
    // 0xa04318: ldur            x16, [fp, #-0x40]
    // 0xa0431c: ldur            lr, [fp, #-0x50]
    // 0xa04320: stp             lr, x16, [SP, #-0x10]!
    // 0xa04324: SaveReg r0
    //     0xa04324: str             x0, [SP, #-8]!
    // 0xa04328: r0 = match()
    //     0xa04328: bl              #0xa04fa0  ; [package:dbus/src/dbus_match_rule.dart] DBusMatchRule::match
    // 0xa0432c: add             SP, SP, #0x28
    // 0xa04330: tbnz            w0, #4, #0xa0472c
    // 0xa04334: ldur            x0, [fp, #-0x20]
    // 0xa04338: cmp             w0, NULL
    // 0xa0433c: b.ne            #0xa04348
    // 0xa04340: r1 = Null
    //     0xa04340: mov             x1, NULL
    // 0xa04344: b               #0xa04350
    // 0xa04348: LoadField: r1 = r0->field_7
    //     0xa04348: ldur            w1, [x0, #7]
    // 0xa0434c: DecompressPointer r1
    //     0xa0434c: add             x1, x1, HEAP, lsl #32
    // 0xa04350: cmp             w1, NULL
    // 0xa04354: b.ne            #0xa04360
    // 0xa04358: r6 = ""
    //     0xa04358: ldr             x6, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa0435c: b               #0xa04364
    // 0xa04360: mov             x6, x1
    // 0xa04364: ldur            x2, [fp, #-0x50]
    // 0xa04368: ldur            x3, [fp, #-0x48]
    // 0xa0436c: ldur            x4, [fp, #-0x40]
    // 0xa04370: ldur            x5, [fp, #-0x10]
    // 0xa04374: ldur            x1, [fp, #-0x60]
    // 0xa04378: stur            x6, [fp, #-0x78]
    // 0xa0437c: LoadField: r7 = r3->field_7
    //     0xa0437c: ldur            w7, [x3, #7]
    // 0xa04380: DecompressPointer r7
    //     0xa04380: add             x7, x7, HEAP, lsl #32
    // 0xa04384: stur            x7, [fp, #-0x70]
    // 0xa04388: LoadField: r8 = r4->field_7
    //     0xa04388: ldur            w8, [x4, #7]
    // 0xa0438c: DecompressPointer r8
    //     0xa0438c: add             x8, x8, HEAP, lsl #32
    // 0xa04390: stur            x8, [fp, #-0x68]
    // 0xa04394: r0 = DBusSignal()
    //     0xa04394: bl              #0xa04f94  ; AllocateDBusSignalStub -> DBusSignal (size=0x1c)
    // 0xa04398: mov             x3, x0
    // 0xa0439c: ldur            x0, [fp, #-0x78]
    // 0xa043a0: stur            x3, [fp, #-0x80]
    // 0xa043a4: StoreField: r3->field_7 = r0
    //     0xa043a4: stur            w0, [x3, #7]
    // 0xa043a8: ldur            x0, [fp, #-0x50]
    // 0xa043ac: StoreField: r3->field_b = r0
    //     0xa043ac: stur            w0, [x3, #0xb]
    // 0xa043b0: ldur            x4, [fp, #-0x70]
    // 0xa043b4: StoreField: r3->field_f = r4
    //     0xa043b4: stur            w4, [x3, #0xf]
    // 0xa043b8: ldur            x5, [fp, #-0x68]
    // 0xa043bc: StoreField: r3->field_13 = r5
    //     0xa043bc: stur            w5, [x3, #0x13]
    // 0xa043c0: ldur            x6, [fp, #-0x10]
    // 0xa043c4: StoreField: r3->field_17 = r6
    //     0xa043c4: stur            w6, [x3, #0x17]
    // 0xa043c8: ldur            x7, [fp, #-0x60]
    // 0xa043cc: LoadField: r8 = r7->field_13
    //     0xa043cc: ldur            w8, [x7, #0x13]
    // 0xa043d0: DecompressPointer r8
    //     0xa043d0: add             x8, x8, HEAP, lsl #32
    // 0xa043d4: stur            x8, [fp, #-0x78]
    // 0xa043d8: cmp             w8, NULL
    // 0xa043dc: b.eq            #0xa04710
    // 0xa043e0: r1 = Function '<anonymous closure>':.
    //     0xa043e0: ldr             x1, [PP, #0x7c40]  ; [pp+0x7c40] AnonymousClosure: (0xa05480), of [package:dbus/src/dbus_message.dart] DBusMessage
    // 0xa043e4: r2 = Null
    //     0xa043e4: mov             x2, NULL
    // 0xa043e8: r0 = AllocateClosure()
    //     0xa043e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa043ec: r16 = <String>
    //     0xa043ec: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xa043f0: ldur            lr, [fp, #-0x10]
    // 0xa043f4: stp             lr, x16, [SP, #-0x10]!
    // 0xa043f8: SaveReg r0
    //     0xa043f8: str             x0, [SP, #-8]!
    // 0xa043fc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa043fc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa04400: r0 = map()
    //     0xa04400: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa04404: add             SP, SP, #0x18
    // 0xa04408: SaveReg r0
    //     0xa04408: str             x0, [SP, #-8]!
    // 0xa0440c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0440c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa04410: r0 = join()
    //     0xa04410: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xa04414: add             SP, SP, #8
    // 0xa04418: stur            x0, [fp, #-0x88]
    // 0xa0441c: r0 = DBusSignature()
    //     0xa0441c: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa04420: stur            x0, [fp, #-0x90]
    // 0xa04424: ldur            x16, [fp, #-0x88]
    // 0xa04428: stp             x16, x0, [SP, #-0x10]!
    // 0xa0442c: r0 = DBusSignature()
    //     0xa0442c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa04430: add             SP, SP, #0x10
    // 0xa04434: ldur            x0, [fp, #-0x78]
    // 0xa04438: LoadField: r1 = r0->field_7
    //     0xa04438: ldur            w1, [x0, #7]
    // 0xa0443c: DecompressPointer r1
    //     0xa0443c: add             x1, x1, HEAP, lsl #32
    // 0xa04440: ldur            x0, [fp, #-0x90]
    // 0xa04444: LoadField: r2 = r0->field_7
    //     0xa04444: ldur            w2, [x0, #7]
    // 0xa04448: DecompressPointer r2
    //     0xa04448: add             x2, x2, HEAP, lsl #32
    // 0xa0444c: r0 = LoadClassIdInstr(r1)
    //     0xa0444c: ldur            x0, [x1, #-1]
    //     0xa04450: ubfx            x0, x0, #0xc, #0x14
    // 0xa04454: stp             x2, x1, [SP, #-0x10]!
    // 0xa04458: mov             lr, x0
    // 0xa0445c: ldr             lr, [x21, lr, lsl #3]
    // 0xa04460: blr             lr
    // 0xa04464: add             SP, SP, #0x10
    // 0xa04468: tbz             w0, #4, #0xa04704
    // 0xa0446c: ldur            x3, [fp, #-0x70]
    // 0xa04470: ldur            x4, [fp, #-0x68]
    // 0xa04474: ldur            x0, [fp, #-0x80]
    // 0xa04478: ldur            x1, [fp, #-0x60]
    // 0xa0447c: LoadField: r5 = r1->field_17
    //     0xa0447c: ldur            w5, [x1, #0x17]
    // 0xa04480: DecompressPointer r5
    //     0xa04480: add             x5, x5, HEAP, lsl #32
    // 0xa04484: stur            x5, [fp, #-0x78]
    // 0xa04488: r1 = Null
    //     0xa04488: mov             x1, NULL
    // 0xa0448c: r2 = 6
    //     0xa0448c: mov             x2, #6
    // 0xa04490: r0 = AllocateArray()
    //     0xa04490: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa04494: mov             x1, x0
    // 0xa04498: ldur            x0, [fp, #-0x70]
    // 0xa0449c: StoreField: r1->field_f = r0
    //     0xa0449c: stur            w0, [x1, #0xf]
    // 0xa044a0: r17 = "."
    //     0xa044a0: ldr             x17, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xa044a4: StoreField: r1->field_13 = r17
    //     0xa044a4: stur            w17, [x1, #0x13]
    // 0xa044a8: ldur            x0, [fp, #-0x68]
    // 0xa044ac: StoreField: r1->field_17 = r0
    //     0xa044ac: stur            w0, [x1, #0x17]
    // 0xa044b0: SaveReg r1
    //     0xa044b0: str             x1, [SP, #-8]!
    // 0xa044b4: r0 = _interpolate()
    //     0xa044b4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa044b8: add             SP, SP, #8
    // 0xa044bc: stur            x0, [fp, #-0x68]
    // 0xa044c0: r0 = DBusSignalSignatureException()
    //     0xa044c0: bl              #0xa04f88  ; AllocateDBusSignalSignatureExceptionStub -> DBusSignalSignatureException (size=0x10)
    // 0xa044c4: mov             x1, x0
    // 0xa044c8: ldur            x0, [fp, #-0x68]
    // 0xa044cc: stur            x1, [fp, #-0x70]
    // 0xa044d0: StoreField: r1->field_7 = r0
    //     0xa044d0: stur            w0, [x1, #7]
    // 0xa044d4: ldur            x0, [fp, #-0x80]
    // 0xa044d8: StoreField: r1->field_b = r0
    //     0xa044d8: stur            w0, [x1, #0xb]
    // 0xa044dc: ldur            x0, [fp, #-0x78]
    // 0xa044e0: r2 = LoadClassIdInstr(r0)
    //     0xa044e0: ldur            x2, [x0, #-1]
    //     0xa044e4: ubfx            x2, x2, #0xc, #0x14
    // 0xa044e8: lsl             x2, x2, #1
    // 0xa044ec: stur            x2, [fp, #-0x68]
    // 0xa044f0: r17 = 11350
    //     0xa044f0: mov             x17, #0x2c56
    // 0xa044f4: cmp             w2, w17
    // 0xa044f8: b.gt            #0xa04554
    // 0xa044fc: r17 = 11348
    //     0xa044fc: mov             x17, #0x2c54
    // 0xa04500: cmp             w2, w17
    // 0xa04504: b.lt            #0xa0454c
    // 0xa04508: LoadField: r3 = r0->field_13
    //     0xa04508: ldur            x3, [x0, #0x13]
    // 0xa0450c: cmp             x3, #4
    // 0xa04510: b.ge            #0xa04540
    // 0xa04514: r4 = 2
    //     0xa04514: mov             x4, #2
    // 0xa04518: mov             x5, x3
    // 0xa0451c: ubfx            x5, x5, #0, #0x20
    // 0xa04520: and             x6, x5, x4
    // 0xa04524: ubfx            x6, x6, #0, #0x20
    // 0xa04528: cbnz            x6, #0xa04544
    // 0xa0452c: r3 = "Cannot fire new event. Controller is already firing an event"
    //     0xa0452c: ldr             x3, [PP, #0xe08]  ; [pp+0xe08] "Cannot fire new event. Controller is already firing an event"
    // 0xa04530: r7 = "Cannot add new events while doing an addStream"
    //     0xa04530: ldr             x7, [PP, #0xe18]  ; [pp+0xe18] "Cannot add new events while doing an addStream"
    // 0xa04534: r6 = "Cannot add new events after calling close"
    //     0xa04534: ldr             x6, [PP, #0xe10]  ; [pp+0xe10] "Cannot add new events after calling close"
    // 0xa04538: r5 = 4
    //     0xa04538: mov             x5, #4
    // 0xa0453c: b               #0xa045bc
    // 0xa04540: r4 = 2
    //     0xa04540: mov             x4, #2
    // 0xa04544: mov             x1, x3
    // 0xa04548: b               #0xa04568
    // 0xa0454c: r4 = 2
    //     0xa0454c: mov             x4, #2
    // 0xa04550: b               #0xa04558
    // 0xa04554: r4 = 2
    //     0xa04554: mov             x4, #2
    // 0xa04558: LoadField: r3 = r0->field_13
    //     0xa04558: ldur            x3, [x0, #0x13]
    // 0xa0455c: cmp             x3, #4
    // 0xa04560: b.lt            #0xa045ac
    // 0xa04564: mov             x1, x3
    // 0xa04568: r17 = 11350
    //     0xa04568: mov             x17, #0x2c56
    // 0xa0456c: cmp             w2, w17
    // 0xa04570: b.gt            #0xa04594
    // 0xa04574: r17 = 11348
    //     0xa04574: mov             x17, #0x2c54
    // 0xa04578: cmp             w2, w17
    // 0xa0457c: b.lt            #0xa04594
    // 0xa04580: ubfx            x1, x1, #0, #0x20
    // 0xa04584: and             x2, x1, x4
    // 0xa04588: ubfx            x2, x2, #0, #0x20
    // 0xa0458c: cbz             x2, #0xa04780
    // 0xa04590: b               #0xa04770
    // 0xa04594: r5 = 4
    //     0xa04594: mov             x5, #4
    // 0xa04598: ubfx            x1, x1, #0, #0x20
    // 0xa0459c: and             x0, x1, x5
    // 0xa045a0: ubfx            x0, x0, #0, #0x20
    // 0xa045a4: cbz             x0, #0xa047a0
    // 0xa045a8: b               #0xa04790
    // 0xa045ac: r3 = "Cannot fire new event. Controller is already firing an event"
    //     0xa045ac: ldr             x3, [PP, #0xe08]  ; [pp+0xe08] "Cannot fire new event. Controller is already firing an event"
    // 0xa045b0: r7 = "Cannot add new events while doing an addStream"
    //     0xa045b0: ldr             x7, [PP, #0xe18]  ; [pp+0xe18] "Cannot add new events while doing an addStream"
    // 0xa045b4: r6 = "Cannot add new events after calling close"
    //     0xa045b4: ldr             x6, [PP, #0xe10]  ; [pp+0xe10] "Cannot add new events after calling close"
    // 0xa045b8: r5 = 4
    //     0xa045b8: mov             x5, #4
    // 0xa045bc: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xa045bc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa045c0: ldr             x0, [x0, #0xb58]
    //     0xa045c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa045c8: cmp             w0, w16
    //     0xa045cc: b.ne            #0xa045d8
    //     0xa045d0: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xa045d4: bl              #0xd67d44
    // 0xa045d8: ldur            x16, [fp, #-0x70]
    // 0xa045dc: SaveReg r16
    //     0xa045dc: str             x16, [SP, #-8]!
    // 0xa045e0: r0 = defaultStackTrace()
    //     0xa045e0: bl              #0x4b55cc  ; [dart:async] AsyncError::defaultStackTrace
    // 0xa045e4: add             SP, SP, #8
    // 0xa045e8: mov             x1, x0
    // 0xa045ec: ldur            x0, [fp, #-0x68]
    // 0xa045f0: stur            x1, [fp, #-0x88]
    // 0xa045f4: r17 = 11350
    //     0xa045f4: mov             x17, #0x2c56
    // 0xa045f8: cmp             w0, w17
    // 0xa045fc: b.gt            #0xa0468c
    // 0xa04600: r17 = 11348
    //     0xa04600: mov             x17, #0x2c54
    // 0xa04604: cmp             w0, w17
    // 0xa04608: b.lt            #0xa04680
    // 0xa0460c: ldur            x2, [fp, #-0x78]
    // 0xa04610: ldur            x0, [fp, #-0x70]
    // 0xa04614: r1 = 3
    //     0xa04614: mov             x1, #3
    // 0xa04618: r0 = AllocateContext()
    //     0xa04618: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa0461c: mov             x1, x0
    // 0xa04620: ldur            x0, [fp, #-0x78]
    // 0xa04624: StoreField: r1->field_f = r0
    //     0xa04624: stur            w0, [x1, #0xf]
    // 0xa04628: ldur            x2, [fp, #-0x70]
    // 0xa0462c: StoreField: r1->field_13 = r2
    //     0xa0462c: stur            w2, [x1, #0x13]
    // 0xa04630: ldur            x3, [fp, #-0x88]
    // 0xa04634: StoreField: r1->field_17 = r3
    //     0xa04634: stur            w3, [x1, #0x17]
    // 0xa04638: LoadField: r2 = r0->field_1b
    //     0xa04638: ldur            w2, [x0, #0x1b]
    // 0xa0463c: DecompressPointer r2
    //     0xa0463c: add             x2, x2, HEAP, lsl #32
    // 0xa04640: cmp             w2, NULL
    // 0xa04644: b.eq            #0xa0472c
    // 0xa04648: LoadField: r3 = r0->field_7
    //     0xa04648: ldur            w3, [x0, #7]
    // 0xa0464c: DecompressPointer r3
    //     0xa0464c: add             x3, x3, HEAP, lsl #32
    // 0xa04650: mov             x2, x1
    // 0xa04654: stur            x3, [fp, #-0x68]
    // 0xa04658: r1 = Function '<anonymous closure>':.
    //     0xa04658: ldr             x1, [PP, #0x7c48]  ; [pp+0x7c48] AnonymousClosure: (0xa0521c), in [dart:async] _SyncBroadcastStreamController::_sendError (0xc42f5c)
    // 0xa0465c: r0 = AllocateClosure()
    //     0xa0465c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa04660: mov             x1, x0
    // 0xa04664: ldur            x0, [fp, #-0x68]
    // 0xa04668: StoreField: r1->field_7 = r0
    //     0xa04668: stur            w0, [x1, #7]
    // 0xa0466c: ldur            x16, [fp, #-0x78]
    // 0xa04670: stp             x1, x16, [SP, #-0x10]!
    // 0xa04674: r0 = _forEachListener()
    //     0xa04674: bl              #0xa04860  ; [dart:async] _BroadcastStreamController::_forEachListener
    // 0xa04678: add             SP, SP, #0x10
    // 0xa0467c: b               #0xa0472c
    // 0xa04680: ldur            x2, [fp, #-0x70]
    // 0xa04684: mov             x3, x1
    // 0xa04688: b               #0xa04694
    // 0xa0468c: ldur            x2, [fp, #-0x70]
    // 0xa04690: mov             x3, x1
    // 0xa04694: ldur            x0, [fp, #-0x78]
    // 0xa04698: LoadField: r1 = r0->field_1b
    //     0xa04698: ldur            w1, [x0, #0x1b]
    // 0xa0469c: DecompressPointer r1
    //     0xa0469c: add             x1, x1, HEAP, lsl #32
    // 0xa046a0: mov             x0, x1
    // 0xa046a4: stur            x0, [fp, #-0x68]
    // 0xa046a8: CheckStackOverflow
    //     0xa046a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa046ac: cmp             SP, x16
    //     0xa046b0: b.ls            #0xa047c4
    // 0xa046b4: cmp             w0, NULL
    // 0xa046b8: b.eq            #0xa0472c
    // 0xa046bc: r1 = Null
    //     0xa046bc: mov             x1, NULL
    // 0xa046c0: r0 = _DelayedError()
    //     0xa046c0: bl              #0xa04854  ; Allocate_DelayedErrorStub -> _DelayedError (size=0x18)
    // 0xa046c4: mov             x1, x0
    // 0xa046c8: ldur            x0, [fp, #-0x70]
    // 0xa046cc: StoreField: r1->field_f = r0
    //     0xa046cc: stur            w0, [x1, #0xf]
    // 0xa046d0: ldur            x2, [fp, #-0x88]
    // 0xa046d4: StoreField: r1->field_13 = r2
    //     0xa046d4: stur            w2, [x1, #0x13]
    // 0xa046d8: ldur            x16, [fp, #-0x68]
    // 0xa046dc: stp             x1, x16, [SP, #-0x10]!
    // 0xa046e0: r0 = _addPending()
    //     0xa046e0: bl              #0x539aec  ; [dart:async] _BufferingStreamSubscription::_addPending
    // 0xa046e4: add             SP, SP, #0x10
    // 0xa046e8: ldur            x0, [fp, #-0x68]
    // 0xa046ec: LoadField: r1 = r0->field_37
    //     0xa046ec: ldur            w1, [x0, #0x37]
    // 0xa046f0: DecompressPointer r1
    //     0xa046f0: add             x1, x1, HEAP, lsl #32
    // 0xa046f4: mov             x0, x1
    // 0xa046f8: ldur            x2, [fp, #-0x70]
    // 0xa046fc: ldur            x3, [fp, #-0x88]
    // 0xa04700: b               #0xa046a4
    // 0xa04704: ldur            x0, [fp, #-0x80]
    // 0xa04708: ldur            x1, [fp, #-0x60]
    // 0xa0470c: b               #0xa04718
    // 0xa04710: mov             x0, x3
    // 0xa04714: mov             x1, x7
    // 0xa04718: LoadField: r2 = r1->field_17
    //     0xa04718: ldur            w2, [x1, #0x17]
    // 0xa0471c: DecompressPointer r2
    //     0xa0471c: add             x2, x2, HEAP, lsl #32
    // 0xa04720: stp             x0, x2, [SP, #-0x10]!
    // 0xa04724: r0 = add()
    //     0xa04724: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xa04728: add             SP, SP, #0x10
    // 0xa0472c: ldur            x10, [fp, #-0x58]
    // 0xa04730: ldur            x1, [fp, #-0x50]
    // 0xa04734: ldur            x2, [fp, #-0x48]
    // 0xa04738: ldur            x3, [fp, #-0x40]
    // 0xa0473c: ldur            x5, [fp, #-0x38]
    // 0xa04740: ldur            x7, [fp, #-0x20]
    // 0xa04744: ldur            x9, [fp, #-0x18]
    // 0xa04748: ldur            x4, [fp, #-0x10]
    // 0xa0474c: ldur            x6, [fp, #-0x30]
    // 0xa04750: ldur            x8, [fp, #-0x28]
    // 0xa04754: b               #0xa041ac
    // 0xa04758: ldur            x0, [fp, #-0x38]
    // 0xa0475c: r0 = ConcurrentModificationError()
    //     0xa0475c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa04760: ldur            x3, [fp, #-0x38]
    // 0xa04764: StoreField: r0->field_b = r3
    //     0xa04764: stur            w3, [x0, #0xb]
    // 0xa04768: r0 = Throw()
    //     0xa04768: bl              #0xd67e38  ; ThrowStub
    // 0xa0476c: brk             #0
    // 0xa04770: r0 = StateError()
    //     0xa04770: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xa04774: r3 = "Cannot fire new event. Controller is already firing an event"
    //     0xa04774: ldr             x3, [PP, #0xe08]  ; [pp+0xe08] "Cannot fire new event. Controller is already firing an event"
    // 0xa04778: StoreField: r0->field_b = r3
    //     0xa04778: stur            w3, [x0, #0xb]
    // 0xa0477c: b               #0xa047ac
    // 0xa04780: SaveReg r0
    //     0xa04780: str             x0, [SP, #-8]!
    // 0xa04784: r0 = _addEventError()
    //     0xa04784: bl              #0xc9fb3c  ; [dart:async] _BroadcastStreamController::_addEventError
    // 0xa04788: add             SP, SP, #8
    // 0xa0478c: b               #0xa047ac
    // 0xa04790: r0 = StateError()
    //     0xa04790: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xa04794: r6 = "Cannot add new events after calling close"
    //     0xa04794: ldr             x6, [PP, #0xe10]  ; [pp+0xe10] "Cannot add new events after calling close"
    // 0xa04798: StoreField: r0->field_b = r6
    //     0xa04798: stur            w6, [x0, #0xb]
    // 0xa0479c: b               #0xa047ac
    // 0xa047a0: r0 = StateError()
    //     0xa047a0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xa047a4: r7 = "Cannot add new events while doing an addStream"
    //     0xa047a4: ldr             x7, [PP, #0xe18]  ; [pp+0xe18] "Cannot add new events while doing an addStream"
    // 0xa047a8: StoreField: r0->field_b = r7
    //     0xa047a8: stur            w7, [x0, #0xb]
    // 0xa047ac: r0 = Throw()
    //     0xa047ac: bl              #0xd67e38  ; ThrowStub
    // 0xa047b0: brk             #0
    // 0xa047b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa047b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa047b8: b               #0xa04108
    // 0xa047bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa047bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa047c0: b               #0xa041bc
    // 0xa047c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa047c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa047c8: b               #0xa046b4
  }
  _ _processMethodResponse(/* No info */) {
    // ** addr: 0xa054d8, size: 0x178
    // 0xa054d8: EnterFrame
    //     0xa054d8: stp             fp, lr, [SP, #-0x10]!
    //     0xa054dc: mov             fp, SP
    // 0xa054e0: AllocStack(0x18)
    //     0xa054e0: sub             SP, SP, #0x18
    // 0xa054e4: CheckStackOverflow
    //     0xa054e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa054e8: cmp             SP, x16
    //     0xa054ec: b.ls            #0xa05648
    // 0xa054f0: ldr             x0, [fp, #0x10]
    // 0xa054f4: LoadField: r1 = r0->field_27
    //     0xa054f4: ldur            w1, [x0, #0x27]
    // 0xa054f8: DecompressPointer r1
    //     0xa054f8: add             x1, x1, HEAP, lsl #32
    // 0xa054fc: stur            x1, [fp, #-0x10]
    // 0xa05500: cmp             w1, NULL
    // 0xa05504: b.ne            #0xa05518
    // 0xa05508: r0 = Null
    //     0xa05508: mov             x0, NULL
    // 0xa0550c: LeaveFrame
    //     0xa0550c: mov             SP, fp
    //     0xa05510: ldp             fp, lr, [SP], #0x10
    // 0xa05514: ret
    //     0xa05514: ret             
    // 0xa05518: ldr             x2, [fp, #0x18]
    // 0xa0551c: LoadField: r3 = r2->field_2b
    //     0xa0551c: ldur            w3, [x2, #0x2b]
    // 0xa05520: DecompressPointer r3
    //     0xa05520: add             x3, x3, HEAP, lsl #32
    // 0xa05524: stur            x3, [fp, #-8]
    // 0xa05528: stp             x1, x3, [SP, #-0x10]!
    // 0xa0552c: r0 = _getValueOrData()
    //     0xa0552c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa05530: add             SP, SP, #0x10
    // 0xa05534: mov             x1, x0
    // 0xa05538: ldur            x0, [fp, #-8]
    // 0xa0553c: LoadField: r2 = r0->field_f
    //     0xa0553c: ldur            w2, [x0, #0xf]
    // 0xa05540: DecompressPointer r2
    //     0xa05540: add             x2, x2, HEAP, lsl #32
    // 0xa05544: cmp             w2, w1
    // 0xa05548: b.ne            #0xa05550
    // 0xa0554c: r1 = Null
    //     0xa0554c: mov             x1, NULL
    // 0xa05550: stur            x1, [fp, #-0x18]
    // 0xa05554: cmp             w1, NULL
    // 0xa05558: b.ne            #0xa0556c
    // 0xa0555c: r0 = Null
    //     0xa0555c: mov             x0, NULL
    // 0xa05560: LeaveFrame
    //     0xa05560: mov             SP, fp
    //     0xa05564: ldp             fp, lr, [SP], #0x10
    // 0xa05568: ret
    //     0xa05568: ret             
    // 0xa0556c: ldr             x2, [fp, #0x10]
    // 0xa05570: ldur            x16, [fp, #-0x10]
    // 0xa05574: stp             x16, x0, [SP, #-0x10]!
    // 0xa05578: r0 = remove()
    //     0xa05578: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xa0557c: add             SP, SP, #0x10
    // 0xa05580: ldr             x0, [fp, #0x10]
    // 0xa05584: LoadField: r1 = r0->field_7
    //     0xa05584: ldur            w1, [x0, #7]
    // 0xa05588: DecompressPointer r1
    //     0xa05588: add             x1, x1, HEAP, lsl #32
    // 0xa0558c: r16 = Instance_DBusMessageType
    //     0xa0558c: ldr             x16, [PP, #0x7820]  ; [pp+0x7820] Obj!DBusMessageType@b66771
    // 0xa05590: cmp             w1, w16
    // 0xa05594: b.ne            #0xa055f4
    // 0xa05598: LoadField: r1 = r0->field_23
    //     0xa05598: ldur            w1, [x0, #0x23]
    // 0xa0559c: DecompressPointer r1
    //     0xa0559c: add             x1, x1, HEAP, lsl #32
    // 0xa055a0: cmp             w1, NULL
    // 0xa055a4: b.ne            #0xa055b0
    // 0xa055a8: r1 = Null
    //     0xa055a8: mov             x1, NULL
    // 0xa055ac: b               #0xa055bc
    // 0xa055b0: LoadField: r2 = r1->field_7
    //     0xa055b0: ldur            w2, [x1, #7]
    // 0xa055b4: DecompressPointer r2
    //     0xa055b4: add             x2, x2, HEAP, lsl #32
    // 0xa055b8: mov             x1, x2
    // 0xa055bc: cmp             w1, NULL
    // 0xa055c0: b.ne            #0xa055c8
    // 0xa055c4: r1 = "(missing error name)"
    //     0xa055c4: ldr             x1, [PP, #0x7c90]  ; [pp+0x7c90] "(missing error name)"
    // 0xa055c8: stur            x1, [fp, #-0x10]
    // 0xa055cc: LoadField: r2 = r0->field_33
    //     0xa055cc: ldur            w2, [x0, #0x33]
    // 0xa055d0: DecompressPointer r2
    //     0xa055d0: add             x2, x2, HEAP, lsl #32
    // 0xa055d4: stur            x2, [fp, #-8]
    // 0xa055d8: r0 = DBusMethodErrorResponse()
    //     0xa055d8: bl              #0xa0565c  ; AllocateDBusMethodErrorResponseStub -> DBusMethodErrorResponse (size=0x10)
    // 0xa055dc: mov             x1, x0
    // 0xa055e0: ldur            x0, [fp, #-0x10]
    // 0xa055e4: StoreField: r1->field_7 = r0
    //     0xa055e4: stur            w0, [x1, #7]
    // 0xa055e8: ldur            x0, [fp, #-8]
    // 0xa055ec: StoreField: r1->field_b = r0
    //     0xa055ec: stur            w0, [x1, #0xb]
    // 0xa055f0: b               #0xa05610
    // 0xa055f4: LoadField: r1 = r0->field_33
    //     0xa055f4: ldur            w1, [x0, #0x33]
    // 0xa055f8: DecompressPointer r1
    //     0xa055f8: add             x1, x1, HEAP, lsl #32
    // 0xa055fc: stur            x1, [fp, #-8]
    // 0xa05600: r0 = DBusMethodSuccessResponse()
    //     0xa05600: bl              #0xa05650  ; AllocateDBusMethodSuccessResponseStub -> DBusMethodSuccessResponse (size=0xc)
    // 0xa05604: mov             x1, x0
    // 0xa05608: ldur            x0, [fp, #-8]
    // 0xa0560c: StoreField: r1->field_7 = r0
    //     0xa0560c: stur            w0, [x1, #7]
    // 0xa05610: ldur            x0, [fp, #-0x18]
    // 0xa05614: r2 = LoadClassIdInstr(r0)
    //     0xa05614: ldur            x2, [x0, #-1]
    //     0xa05618: ubfx            x2, x2, #0xc, #0x14
    // 0xa0561c: stp             x1, x0, [SP, #-0x10]!
    // 0xa05620: mov             x0, x2
    // 0xa05624: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa05624: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa05628: r0 = GDT[cid_x0 + -0xf72]()
    //     0xa05628: sub             lr, x0, #0xf72
    //     0xa0562c: ldr             lr, [x21, lr, lsl #3]
    //     0xa05630: blr             lr
    // 0xa05634: add             SP, SP, #0x10
    // 0xa05638: r0 = Null
    //     0xa05638: mov             x0, NULL
    // 0xa0563c: LeaveFrame
    //     0xa0563c: mov             SP, fp
    //     0xa05640: ldp             fp, lr, [SP], #0x10
    // 0xa05644: ret
    //     0xa05644: ret             
    // 0xa05648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa05648: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0564c: b               #0xa054f0
  }
  _ _processMethodCall(/* No info */) async {
    // ** addr: 0xa05668, size: 0x428
    // 0xa05668: EnterFrame
    //     0xa05668: stp             fp, lr, [SP, #-0x10]!
    //     0xa0566c: mov             fp, SP
    // 0xa05670: AllocStack(0x80)
    //     0xa05670: sub             SP, SP, #0x80
    // 0xa05674: SetupParameters(DBusClient this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xa05674: stur            NULL, [fp, #-8]
    //     0xa05678: mov             x0, #0
    //     0xa0567c: add             x1, fp, w0, sxtw #2
    //     0xa05680: ldr             x1, [x1, #0x18]
    //     0xa05684: stur            x1, [fp, #-0x18]
    //     0xa05688: add             x2, fp, w0, sxtw #2
    //     0xa0568c: ldr             x2, [x2, #0x10]
    //     0xa05690: stur            x2, [fp, #-0x10]
    // 0xa05694: CheckStackOverflow
    //     0xa05694: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa05698: cmp             SP, x16
    //     0xa0569c: b.ls            #0xa05a88
    // 0xa056a0: InitAsync() -> Future<void?>
    //     0xa056a0: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa056a4: bl              #0x4b92e4
    // 0xa056a8: ldur            x0, [fp, #-0x10]
    // 0xa056ac: LoadField: r1 = r0->field_17
    //     0xa056ac: ldur            w1, [x0, #0x17]
    // 0xa056b0: DecompressPointer r1
    //     0xa056b0: add             x1, x1, HEAP, lsl #32
    // 0xa056b4: cmp             w1, NULL
    // 0xa056b8: b.eq            #0xa056dc
    // 0xa056bc: ldur            x2, [fp, #-0x18]
    // 0xa056c0: LoadField: r3 = r2->field_3f
    //     0xa056c0: ldur            w3, [x2, #0x3f]
    // 0xa056c4: DecompressPointer r3
    //     0xa056c4: add             x3, x3, HEAP, lsl #32
    // 0xa056c8: stp             x1, x3, [SP, #-0x10]!
    // 0xa056cc: r0 = lookup()
    //     0xa056cc: bl              #0xa07694  ; [package:dbus/src/dbus_object_tree.dart] DBusObjectTree::lookup
    // 0xa056d0: add             SP, SP, #0x10
    // 0xa056d4: mov             x2, x0
    // 0xa056d8: b               #0xa056e0
    // 0xa056dc: r2 = Null
    //     0xa056dc: mov             x2, NULL
    // 0xa056e0: ldur            x1, [fp, #-0x10]
    // 0xa056e4: stur            x2, [fp, #-0x60]
    // 0xa056e8: LoadField: r3 = r1->field_2f
    //     0xa056e8: ldur            w3, [x1, #0x2f]
    // 0xa056ec: DecompressPointer r3
    //     0xa056ec: add             x3, x3, HEAP, lsl #32
    // 0xa056f0: stur            x3, [fp, #-0x58]
    // 0xa056f4: cmp             w3, NULL
    // 0xa056f8: b.ne            #0xa05704
    // 0xa056fc: r0 = Null
    //     0xa056fc: mov             x0, NULL
    // 0xa05700: b               #0xa0570c
    // 0xa05704: LoadField: r0 = r3->field_7
    //     0xa05704: ldur            w0, [x3, #7]
    // 0xa05708: DecompressPointer r0
    //     0xa05708: add             x0, x0, HEAP, lsl #32
    // 0xa0570c: cmp             w0, NULL
    // 0xa05710: b.ne            #0xa0571c
    // 0xa05714: r4 = ""
    //     0xa05714: ldr             x4, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa05718: b               #0xa05720
    // 0xa0571c: mov             x4, x0
    // 0xa05720: stur            x4, [fp, #-0x50]
    // 0xa05724: LoadField: r5 = r1->field_1b
    //     0xa05724: ldur            w5, [x1, #0x1b]
    // 0xa05728: DecompressPointer r5
    //     0xa05728: add             x5, x5, HEAP, lsl #32
    // 0xa0572c: stur            x5, [fp, #-0x48]
    // 0xa05730: cmp             w5, NULL
    // 0xa05734: b.ne            #0xa05740
    // 0xa05738: r6 = Null
    //     0xa05738: mov             x6, NULL
    // 0xa0573c: b               #0xa0574c
    // 0xa05740: LoadField: r0 = r5->field_7
    //     0xa05740: ldur            w0, [x5, #7]
    // 0xa05744: DecompressPointer r0
    //     0xa05744: add             x0, x0, HEAP, lsl #32
    // 0xa05748: mov             x6, x0
    // 0xa0574c: stur            x6, [fp, #-0x40]
    // 0xa05750: LoadField: r7 = r1->field_1f
    //     0xa05750: ldur            w7, [x1, #0x1f]
    // 0xa05754: DecompressPointer r7
    //     0xa05754: add             x7, x7, HEAP, lsl #32
    // 0xa05758: stur            x7, [fp, #-0x38]
    // 0xa0575c: cmp             w7, NULL
    // 0xa05760: b.ne            #0xa0576c
    // 0xa05764: r0 = Null
    //     0xa05764: mov             x0, NULL
    // 0xa05768: b               #0xa05774
    // 0xa0576c: LoadField: r0 = r7->field_7
    //     0xa0576c: ldur            w0, [x7, #7]
    // 0xa05770: DecompressPointer r0
    //     0xa05770: add             x0, x0, HEAP, lsl #32
    // 0xa05774: cmp             w0, NULL
    // 0xa05778: b.ne            #0xa05784
    // 0xa0577c: r8 = ""
    //     0xa0577c: ldr             x8, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa05780: b               #0xa05788
    // 0xa05784: mov             x8, x0
    // 0xa05788: stur            x8, [fp, #-0x30]
    // 0xa0578c: LoadField: r9 = r1->field_33
    //     0xa0578c: ldur            w9, [x1, #0x33]
    // 0xa05790: DecompressPointer r9
    //     0xa05790: add             x9, x9, HEAP, lsl #32
    // 0xa05794: stur            x9, [fp, #-0x28]
    // 0xa05798: LoadField: r10 = r1->field_b
    //     0xa05798: ldur            w10, [x1, #0xb]
    // 0xa0579c: DecompressPointer r10
    //     0xa0579c: add             x10, x10, HEAP, lsl #32
    // 0xa057a0: stur            x10, [fp, #-0x20]
    // 0xa057a4: r0 = LoadClassIdInstr(r10)
    //     0xa057a4: ldur            x0, [x10, #-1]
    //     0xa057a8: ubfx            x0, x0, #0xc, #0x14
    // 0xa057ac: r16 = Instance_DBusMessageFlag
    //     0xa057ac: ldr             x16, [PP, #0x7830]  ; [pp+0x7830] Obj!DBusMessageFlag@b66751
    // 0xa057b0: stp             x16, x10, [SP, #-0x10]!
    // 0xa057b4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xa057b4: mov             x17, #0xc98a
    //     0xa057b8: add             lr, x0, x17
    //     0xa057bc: ldr             lr, [x21, lr, lsl #3]
    //     0xa057c0: blr             lr
    // 0xa057c4: add             SP, SP, #0x10
    // 0xa057c8: mov             x2, x0
    // 0xa057cc: ldur            x1, [fp, #-0x20]
    // 0xa057d0: stur            x2, [fp, #-0x68]
    // 0xa057d4: r0 = LoadClassIdInstr(r1)
    //     0xa057d4: ldur            x0, [x1, #-1]
    //     0xa057d8: ubfx            x0, x0, #0xc, #0x14
    // 0xa057dc: r16 = Instance_DBusMessageFlag
    //     0xa057dc: ldr             x16, [PP, #0x7838]  ; [pp+0x7838] Obj!DBusMessageFlag@b66731
    // 0xa057e0: stp             x16, x1, [SP, #-0x10]!
    // 0xa057e4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xa057e4: mov             x17, #0xc98a
    //     0xa057e8: add             lr, x0, x17
    //     0xa057ec: ldr             lr, [x21, lr, lsl #3]
    //     0xa057f0: blr             lr
    // 0xa057f4: add             SP, SP, #0x10
    // 0xa057f8: mov             x2, x0
    // 0xa057fc: ldur            x1, [fp, #-0x20]
    // 0xa05800: stur            x2, [fp, #-0x70]
    // 0xa05804: r0 = LoadClassIdInstr(r1)
    //     0xa05804: ldur            x0, [x1, #-1]
    //     0xa05808: ubfx            x0, x0, #0xc, #0x14
    // 0xa0580c: r16 = Instance_DBusMessageFlag
    //     0xa0580c: ldr             x16, [PP, #0x7840]  ; [pp+0x7840] Obj!DBusMessageFlag@b66711
    // 0xa05810: stp             x16, x1, [SP, #-0x10]!
    // 0xa05814: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xa05814: mov             x17, #0xc98a
    //     0xa05818: add             lr, x0, x17
    //     0xa0581c: ldr             lr, [x21, lr, lsl #3]
    //     0xa05820: blr             lr
    // 0xa05824: add             SP, SP, #0x10
    // 0xa05828: stur            x0, [fp, #-0x78]
    // 0xa0582c: r0 = DBusMethodCall()
    //     0xa0582c: bl              #0xa07688  ; AllocateDBusMethodCallStub -> DBusMethodCall (size=0x24)
    // 0xa05830: mov             x1, x0
    // 0xa05834: ldur            x0, [fp, #-0x50]
    // 0xa05838: stur            x1, [fp, #-0x80]
    // 0xa0583c: StoreField: r1->field_7 = r0
    //     0xa0583c: stur            w0, [x1, #7]
    // 0xa05840: ldur            x0, [fp, #-0x40]
    // 0xa05844: StoreField: r1->field_b = r0
    //     0xa05844: stur            w0, [x1, #0xb]
    // 0xa05848: ldur            x0, [fp, #-0x30]
    // 0xa0584c: StoreField: r1->field_f = r0
    //     0xa0584c: stur            w0, [x1, #0xf]
    // 0xa05850: ldur            x0, [fp, #-0x28]
    // 0xa05854: StoreField: r1->field_13 = r0
    //     0xa05854: stur            w0, [x1, #0x13]
    // 0xa05858: ldur            x0, [fp, #-0x68]
    // 0xa0585c: StoreField: r1->field_17 = r0
    //     0xa0585c: stur            w0, [x1, #0x17]
    // 0xa05860: ldur            x0, [fp, #-0x70]
    // 0xa05864: StoreField: r1->field_1b = r0
    //     0xa05864: stur            w0, [x1, #0x1b]
    // 0xa05868: ldur            x0, [fp, #-0x78]
    // 0xa0586c: StoreField: r1->field_1f = r0
    //     0xa0586c: stur            w0, [x1, #0x1f]
    // 0xa05870: ldur            x0, [fp, #-0x38]
    // 0xa05874: cmp             w0, NULL
    // 0xa05878: b.ne            #0xa058ac
    // 0xa0587c: r16 = <DBusValue>
    //     0xa0587c: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa05880: stp             xzr, x16, [SP, #-0x10]!
    // 0xa05884: r0 = _GrowableList()
    //     0xa05884: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa05888: add             SP, SP, #0x10
    // 0xa0588c: stur            x0, [fp, #-0x28]
    // 0xa05890: r0 = DBusMethodErrorResponse()
    //     0xa05890: bl              #0xa0565c  ; AllocateDBusMethodErrorResponseStub -> DBusMethodErrorResponse (size=0x10)
    // 0xa05894: mov             x1, x0
    // 0xa05898: r0 = "org.freedesktop.DBus.Error.UnknownMethod"
    //     0xa05898: ldr             x0, [PP, #0x7780]  ; [pp+0x7780] "org.freedesktop.DBus.Error.UnknownMethod"
    // 0xa0589c: StoreField: r1->field_7 = r0
    //     0xa0589c: stur            w0, [x1, #7]
    // 0xa058a0: ldur            x0, [fp, #-0x28]
    // 0xa058a4: StoreField: r1->field_b = r0
    //     0xa058a4: stur            w0, [x1, #0xb]
    // 0xa058a8: b               #0xa059a4
    // 0xa058ac: ldur            x2, [fp, #-0x48]
    // 0xa058b0: cmp             w2, NULL
    // 0xa058b4: b.ne            #0xa058c0
    // 0xa058b8: r0 = Null
    //     0xa058b8: mov             x0, NULL
    // 0xa058bc: b               #0xa058c8
    // 0xa058c0: LoadField: r0 = r2->field_7
    //     0xa058c0: ldur            w0, [x2, #7]
    // 0xa058c4: DecompressPointer r0
    //     0xa058c4: add             x0, x0, HEAP, lsl #32
    // 0xa058c8: r3 = LoadClassIdInstr(r0)
    //     0xa058c8: ldur            x3, [x0, #-1]
    //     0xa058cc: ubfx            x3, x3, #0xc, #0x14
    // 0xa058d0: r16 = "org.freedesktop.DBus.Peer"
    //     0xa058d0: ldr             x16, [PP, #0x7c98]  ; [pp+0x7c98] "org.freedesktop.DBus.Peer"
    // 0xa058d4: stp             x16, x0, [SP, #-0x10]!
    // 0xa058d8: mov             x0, x3
    // 0xa058dc: mov             lr, x0
    // 0xa058e0: ldr             lr, [x21, lr, lsl #3]
    // 0xa058e4: blr             lr
    // 0xa058e8: add             SP, SP, #0x10
    // 0xa058ec: tbnz            w0, #4, #0xa05910
    // 0xa058f0: ldur            x16, [fp, #-0x80]
    // 0xa058f4: SaveReg r16
    //     0xa058f4: str             x16, [SP, #-8]!
    // 0xa058f8: r0 = handlePeerMethodCall()
    //     0xa058f8: bl              #0xa071f8  ; [package:dbus/src/dbus_peer.dart] ::handlePeerMethodCall
    // 0xa058fc: add             SP, SP, #8
    // 0xa05900: mov             x1, x0
    // 0xa05904: stur            x1, [fp, #-0x28]
    // 0xa05908: r0 = Await()
    //     0xa05908: bl              #0x4b8e6c  ; AwaitStub
    // 0xa0590c: b               #0xa059a0
    // 0xa05910: ldur            x0, [fp, #-0x48]
    // 0xa05914: cmp             w0, NULL
    // 0xa05918: b.ne            #0xa05924
    // 0xa0591c: r0 = Null
    //     0xa0591c: mov             x0, NULL
    // 0xa05920: b               #0xa05930
    // 0xa05924: LoadField: r1 = r0->field_7
    //     0xa05924: ldur            w1, [x0, #7]
    // 0xa05928: DecompressPointer r1
    //     0xa05928: add             x1, x1, HEAP, lsl #32
    // 0xa0592c: mov             x0, x1
    // 0xa05930: r1 = LoadClassIdInstr(r0)
    //     0xa05930: ldur            x1, [x0, #-1]
    //     0xa05934: ubfx            x1, x1, #0xc, #0x14
    // 0xa05938: r16 = "org.freedesktop.DBus.Introspectable"
    //     0xa05938: ldr             x16, [PP, #0x7ca0]  ; [pp+0x7ca0] "org.freedesktop.DBus.Introspectable"
    // 0xa0593c: stp             x16, x0, [SP, #-0x10]!
    // 0xa05940: mov             x0, x1
    // 0xa05944: mov             lr, x0
    // 0xa05948: ldr             lr, [x21, lr, lsl #3]
    // 0xa0594c: blr             lr
    // 0xa05950: add             SP, SP, #0x10
    // 0xa05954: tbnz            w0, #4, #0xa05970
    // 0xa05958: ldur            x16, [fp, #-0x60]
    // 0xa0595c: ldur            lr, [fp, #-0x80]
    // 0xa05960: stp             lr, x16, [SP, #-0x10]!
    // 0xa05964: r0 = handleIntrospectableMethodCall()
    //     0xa05964: bl              #0xa05eec  ; [package:dbus/src/dbus_introspectable.dart] ::handleIntrospectableMethodCall
    // 0xa05968: add             SP, SP, #0x10
    // 0xa0596c: b               #0xa059a0
    // 0xa05970: r16 = <DBusValue>
    //     0xa05970: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa05974: stp             xzr, x16, [SP, #-0x10]!
    // 0xa05978: r0 = _GrowableList()
    //     0xa05978: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa0597c: add             SP, SP, #0x10
    // 0xa05980: stur            x0, [fp, #-0x28]
    // 0xa05984: r0 = DBusMethodErrorResponse()
    //     0xa05984: bl              #0xa0565c  ; AllocateDBusMethodErrorResponseStub -> DBusMethodErrorResponse (size=0x10)
    // 0xa05988: mov             x1, x0
    // 0xa0598c: r0 = "org.freedesktop.DBus.Error.UnknownObject"
    //     0xa0598c: ldr             x0, [PP, #0x7770]  ; [pp+0x7770] "org.freedesktop.DBus.Error.UnknownObject"
    // 0xa05990: StoreField: r1->field_7 = r0
    //     0xa05990: stur            w0, [x1, #7]
    // 0xa05994: ldur            x0, [fp, #-0x28]
    // 0xa05998: StoreField: r1->field_b = r0
    //     0xa05998: stur            w0, [x1, #0xb]
    // 0xa0599c: mov             x0, x1
    // 0xa059a0: mov             x1, x0
    // 0xa059a4: ldur            x0, [fp, #-0x20]
    // 0xa059a8: stur            x1, [fp, #-0x28]
    // 0xa059ac: r2 = LoadClassIdInstr(r0)
    //     0xa059ac: ldur            x2, [x0, #-1]
    //     0xa059b0: ubfx            x2, x2, #0xc, #0x14
    // 0xa059b4: r16 = Instance_DBusMessageFlag
    //     0xa059b4: ldr             x16, [PP, #0x7830]  ; [pp+0x7830] Obj!DBusMessageFlag@b66751
    // 0xa059b8: stp             x16, x0, [SP, #-0x10]!
    // 0xa059bc: mov             x0, x2
    // 0xa059c0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xa059c0: mov             x17, #0xc98a
    //     0xa059c4: add             lr, x0, x17
    //     0xa059c8: ldr             lr, [x21, lr, lsl #3]
    //     0xa059cc: blr             lr
    // 0xa059d0: add             SP, SP, #0x10
    // 0xa059d4: tbnz            w0, #4, #0xa059e0
    // 0xa059d8: r0 = Null
    //     0xa059d8: mov             x0, NULL
    // 0xa059dc: r0 = ReturnAsyncNotFuture()
    //     0xa059dc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa059e0: ldur            x0, [fp, #-0x18]
    // 0xa059e4: LoadField: r1 = r0->field_f
    //     0xa059e4: ldur            w1, [x0, #0xf]
    // 0xa059e8: DecompressPointer r1
    //     0xa059e8: add             x1, x1, HEAP, lsl #32
    // 0xa059ec: tbnz            w1, #4, #0xa059f8
    // 0xa059f0: r0 = Null
    //     0xa059f0: mov             x0, NULL
    // 0xa059f4: r0 = ReturnAsyncNotFuture()
    //     0xa059f4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa059f8: ldur            x1, [fp, #-0x28]
    // 0xa059fc: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xa059fc: mov             x2, #0x76
    //     0xa05a00: tbz             w1, #0, #0xa05a10
    //     0xa05a04: ldur            x2, [x1, #-1]
    //     0xa05a08: ubfx            x2, x2, #0xc, #0x14
    //     0xa05a0c: lsl             x2, x2, #1
    // 0xa05a10: r17 = 9216
    //     0xa05a10: mov             x17, #0x2400
    // 0xa05a14: cmp             w2, w17
    // 0xa05a18: b.ne            #0xa05a50
    // 0xa05a1c: ldur            x3, [fp, #-0x10]
    // 0xa05a20: LoadField: r2 = r3->field_f
    //     0xa05a20: ldur            x2, [x3, #0xf]
    // 0xa05a24: LoadField: r3 = r1->field_7
    //     0xa05a24: ldur            w3, [x1, #7]
    // 0xa05a28: DecompressPointer r3
    //     0xa05a28: add             x3, x3, HEAP, lsl #32
    // 0xa05a2c: LoadField: r4 = r1->field_b
    //     0xa05a2c: ldur            w4, [x1, #0xb]
    // 0xa05a30: DecompressPointer r4
    //     0xa05a30: add             x4, x4, HEAP, lsl #32
    // 0xa05a34: stp             x2, x0, [SP, #-0x10]!
    // 0xa05a38: ldur            x16, [fp, #-0x58]
    // 0xa05a3c: stp             x3, x16, [SP, #-0x10]!
    // 0xa05a40: SaveReg r4
    //     0xa05a40: str             x4, [SP, #-8]!
    // 0xa05a44: r0 = _sendError()
    //     0xa05a44: bl              #0xa05b60  ; [package:dbus/src/dbus_client.dart] DBusClient::_sendError
    // 0xa05a48: add             SP, SP, #0x28
    // 0xa05a4c: b               #0xa05a80
    // 0xa05a50: ldur            x3, [fp, #-0x10]
    // 0xa05a54: r17 = 9218
    //     0xa05a54: mov             x17, #0x2402
    // 0xa05a58: cmp             w2, w17
    // 0xa05a5c: b.ne            #0xa05a80
    // 0xa05a60: LoadField: r2 = r3->field_f
    //     0xa05a60: ldur            x2, [x3, #0xf]
    // 0xa05a64: LoadField: r3 = r1->field_7
    //     0xa05a64: ldur            w3, [x1, #7]
    // 0xa05a68: DecompressPointer r3
    //     0xa05a68: add             x3, x3, HEAP, lsl #32
    // 0xa05a6c: stp             x2, x0, [SP, #-0x10]!
    // 0xa05a70: ldur            x16, [fp, #-0x58]
    // 0xa05a74: stp             x3, x16, [SP, #-0x10]!
    // 0xa05a78: r0 = _sendReturn()
    //     0xa05a78: bl              #0xa05a90  ; [package:dbus/src/dbus_client.dart] DBusClient::_sendReturn
    // 0xa05a7c: add             SP, SP, #0x20
    // 0xa05a80: r0 = Null
    //     0xa05a80: mov             x0, NULL
    // 0xa05a84: r0 = ReturnAsyncNotFuture()
    //     0xa05a84: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa05a88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa05a88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa05a8c: b               #0xa056a0
  }
  _ _sendReturn(/* No info */) {
    // ** addr: 0xa05a90, size: 0xd0
    // 0xa05a90: EnterFrame
    //     0xa05a90: stp             fp, lr, [SP, #-0x10]!
    //     0xa05a94: mov             fp, SP
    // 0xa05a98: AllocStack(0x10)
    //     0xa05a98: sub             SP, SP, #0x10
    // 0xa05a9c: CheckStackOverflow
    //     0xa05a9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa05aa0: cmp             SP, x16
    //     0xa05aa4: b.ls            #0xa05b58
    // 0xa05aa8: ldr             x1, [fp, #0x28]
    // 0xa05aac: LoadField: r0 = r1->field_23
    //     0xa05aac: ldur            x0, [x1, #0x23]
    // 0xa05ab0: add             x2, x0, #1
    // 0xa05ab4: stur            x2, [fp, #-8]
    // 0xa05ab8: StoreField: r1->field_23 = r2
    //     0xa05ab8: stur            x2, [x1, #0x23]
    // 0xa05abc: ldr             x0, [fp, #0x10]
    // 0xa05ac0: r3 = LoadClassIdInstr(r0)
    //     0xa05ac0: ldur            x3, [x0, #-1]
    //     0xa05ac4: ubfx            x3, x3, #0xc, #0x14
    // 0xa05ac8: SaveReg r0
    //     0xa05ac8: str             x0, [SP, #-8]!
    // 0xa05acc: mov             x0, x3
    // 0xa05ad0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa05ad0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa05ad4: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0xa05ad4: mov             x17, #0xc8a1
    //     0xa05ad8: add             lr, x0, x17
    //     0xa05adc: ldr             lr, [x21, lr, lsl #3]
    //     0xa05ae0: blr             lr
    // 0xa05ae4: add             SP, SP, #8
    // 0xa05ae8: stur            x0, [fp, #-0x10]
    // 0xa05aec: r0 = DBusMessage()
    //     0xa05aec: bl              #0xa02010  ; AllocateDBusMessageStub -> DBusMessage (size=0x38)
    // 0xa05af0: mov             x2, x0
    // 0xa05af4: r0 = Instance_DBusMessageType
    //     0xa05af4: ldr             x0, [PP, #0x7818]  ; [pp+0x7818] Obj!DBusMessageType@b66791
    // 0xa05af8: StoreField: r2->field_7 = r0
    //     0xa05af8: stur            w0, [x2, #7]
    // 0xa05afc: r0 = _ConstSet len:0
    //     0xa05afc: ldr             x0, [PP, #0x7ca8]  ; [pp+0x7ca8] Set<DBusMessageFlag>(0)
    // 0xa05b00: StoreField: r2->field_b = r0
    //     0xa05b00: stur            w0, [x2, #0xb]
    // 0xa05b04: ldur            x0, [fp, #-8]
    // 0xa05b08: StoreField: r2->field_f = r0
    //     0xa05b08: stur            x0, [x2, #0xf]
    // 0xa05b0c: ldr             x3, [fp, #0x20]
    // 0xa05b10: r0 = BoxInt64Instr(r3)
    //     0xa05b10: sbfiz           x0, x3, #1, #0x1f
    //     0xa05b14: cmp             x3, x0, asr #1
    //     0xa05b18: b.eq            #0xa05b24
    //     0xa05b1c: bl              #0xd69bb8
    //     0xa05b20: stur            x3, [x0, #7]
    // 0xa05b24: StoreField: r2->field_27 = r0
    //     0xa05b24: stur            w0, [x2, #0x27]
    // 0xa05b28: ldr             x0, [fp, #0x18]
    // 0xa05b2c: StoreField: r2->field_2b = r0
    //     0xa05b2c: stur            w0, [x2, #0x2b]
    // 0xa05b30: ldur            x0, [fp, #-0x10]
    // 0xa05b34: StoreField: r2->field_33 = r0
    //     0xa05b34: stur            w0, [x2, #0x33]
    // 0xa05b38: ldr             x16, [fp, #0x28]
    // 0xa05b3c: stp             x2, x16, [SP, #-0x10]!
    // 0xa05b40: r0 = _sendMessage()
    //     0xa05b40: bl              #0x9ff070  ; [package:dbus/src/dbus_client.dart] DBusClient::_sendMessage
    // 0xa05b44: add             SP, SP, #0x10
    // 0xa05b48: r0 = Null
    //     0xa05b48: mov             x0, NULL
    // 0xa05b4c: LeaveFrame
    //     0xa05b4c: mov             SP, fp
    //     0xa05b50: ldp             fp, lr, [SP], #0x10
    // 0xa05b54: ret
    //     0xa05b54: ret             
    // 0xa05b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa05b58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa05b5c: b               #0xa05aa8
  }
  _ _sendError(/* No info */) {
    // ** addr: 0xa05b60, size: 0xf0
    // 0xa05b60: EnterFrame
    //     0xa05b60: stp             fp, lr, [SP, #-0x10]!
    //     0xa05b64: mov             fp, SP
    // 0xa05b68: AllocStack(0x18)
    //     0xa05b68: sub             SP, SP, #0x18
    // 0xa05b6c: CheckStackOverflow
    //     0xa05b6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa05b70: cmp             SP, x16
    //     0xa05b74: b.ls            #0xa05c48
    // 0xa05b78: ldr             x0, [fp, #0x30]
    // 0xa05b7c: LoadField: r1 = r0->field_23
    //     0xa05b7c: ldur            x1, [x0, #0x23]
    // 0xa05b80: add             x2, x1, #1
    // 0xa05b84: stur            x2, [fp, #-8]
    // 0xa05b88: StoreField: r0->field_23 = r2
    //     0xa05b88: stur            x2, [x0, #0x23]
    // 0xa05b8c: r0 = DBusErrorName()
    //     0xa05b8c: bl              #0xa05ee0  ; AllocateDBusErrorNameStub -> DBusErrorName (size=0xc)
    // 0xa05b90: stur            x0, [fp, #-0x10]
    // 0xa05b94: ldr             x16, [fp, #0x18]
    // 0xa05b98: stp             x16, x0, [SP, #-0x10]!
    // 0xa05b9c: r0 = DBusErrorName()
    //     0xa05b9c: bl              #0xa05c50  ; [package:dbus/src/dbus_error_name.dart] DBusErrorName::DBusErrorName
    // 0xa05ba0: add             SP, SP, #0x10
    // 0xa05ba4: ldr             x0, [fp, #0x10]
    // 0xa05ba8: r1 = LoadClassIdInstr(r0)
    //     0xa05ba8: ldur            x1, [x0, #-1]
    //     0xa05bac: ubfx            x1, x1, #0xc, #0x14
    // 0xa05bb0: SaveReg r0
    //     0xa05bb0: str             x0, [SP, #-8]!
    // 0xa05bb4: mov             x0, x1
    // 0xa05bb8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa05bb8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa05bbc: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0xa05bbc: mov             x17, #0xc8a1
    //     0xa05bc0: add             lr, x0, x17
    //     0xa05bc4: ldr             lr, [x21, lr, lsl #3]
    //     0xa05bc8: blr             lr
    // 0xa05bcc: add             SP, SP, #8
    // 0xa05bd0: stur            x0, [fp, #-0x18]
    // 0xa05bd4: r0 = DBusMessage()
    //     0xa05bd4: bl              #0xa02010  ; AllocateDBusMessageStub -> DBusMessage (size=0x38)
    // 0xa05bd8: mov             x2, x0
    // 0xa05bdc: r0 = Instance_DBusMessageType
    //     0xa05bdc: ldr             x0, [PP, #0x7820]  ; [pp+0x7820] Obj!DBusMessageType@b66771
    // 0xa05be0: StoreField: r2->field_7 = r0
    //     0xa05be0: stur            w0, [x2, #7]
    // 0xa05be4: r0 = _ConstSet len:0
    //     0xa05be4: ldr             x0, [PP, #0x7ca8]  ; [pp+0x7ca8] Set<DBusMessageFlag>(0)
    // 0xa05be8: StoreField: r2->field_b = r0
    //     0xa05be8: stur            w0, [x2, #0xb]
    // 0xa05bec: ldur            x0, [fp, #-8]
    // 0xa05bf0: StoreField: r2->field_f = r0
    //     0xa05bf0: stur            x0, [x2, #0xf]
    // 0xa05bf4: ldur            x0, [fp, #-0x10]
    // 0xa05bf8: StoreField: r2->field_23 = r0
    //     0xa05bf8: stur            w0, [x2, #0x23]
    // 0xa05bfc: ldr             x3, [fp, #0x28]
    // 0xa05c00: r0 = BoxInt64Instr(r3)
    //     0xa05c00: sbfiz           x0, x3, #1, #0x1f
    //     0xa05c04: cmp             x3, x0, asr #1
    //     0xa05c08: b.eq            #0xa05c14
    //     0xa05c0c: bl              #0xd69bb8
    //     0xa05c10: stur            x3, [x0, #7]
    // 0xa05c14: StoreField: r2->field_27 = r0
    //     0xa05c14: stur            w0, [x2, #0x27]
    // 0xa05c18: ldr             x0, [fp, #0x20]
    // 0xa05c1c: StoreField: r2->field_2b = r0
    //     0xa05c1c: stur            w0, [x2, #0x2b]
    // 0xa05c20: ldur            x0, [fp, #-0x18]
    // 0xa05c24: StoreField: r2->field_33 = r0
    //     0xa05c24: stur            w0, [x2, #0x33]
    // 0xa05c28: ldr             x16, [fp, #0x30]
    // 0xa05c2c: stp             x2, x16, [SP, #-0x10]!
    // 0xa05c30: r0 = _sendMessage()
    //     0xa05c30: bl              #0x9ff070  ; [package:dbus/src/dbus_client.dart] DBusClient::_sendMessage
    // 0xa05c34: add             SP, SP, #0x10
    // 0xa05c38: r0 = Null
    //     0xa05c38: mov             x0, NULL
    // 0xa05c3c: LeaveFrame
    //     0xa05c3c: mov             SP, fp
    //     0xa05c40: ldp             fp, lr, [SP], #0x10
    // 0xa05c44: ret
    //     0xa05c44: ret             
    // 0xa05c48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa05c48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa05c4c: b               #0xa05b78
  }
  [closure] void <anonymous closure>(dynamic, DBusNameOwnerChangedEvent) {
    // ** addr: 0xa0ddb8, size: 0x12c
    // 0xa0ddb8: EnterFrame
    //     0xa0ddb8: stp             fp, lr, [SP, #-0x10]!
    //     0xa0ddbc: mov             fp, SP
    // 0xa0ddc0: AllocStack(0x28)
    //     0xa0ddc0: sub             SP, SP, #0x28
    // 0xa0ddc4: SetupParameters()
    //     0xa0ddc4: ldr             x0, [fp, #0x18]
    //     0xa0ddc8: ldur            w1, [x0, #0x17]
    //     0xa0ddcc: add             x1, x1, HEAP, lsl #32
    //     0xa0ddd0: stur            x1, [fp, #-0x10]
    // 0xa0ddd4: CheckStackOverflow
    //     0xa0ddd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0ddd8: cmp             SP, x16
    //     0xa0dddc: b.ls            #0xa0dedc
    // 0xa0dde0: ldr             x0, [fp, #0x10]
    // 0xa0dde4: LoadField: r2 = r0->field_7
    //     0xa0dde4: ldur            w2, [x0, #7]
    // 0xa0dde8: DecompressPointer r2
    //     0xa0dde8: add             x2, x2, HEAP, lsl #32
    // 0xa0ddec: stur            x2, [fp, #-8]
    // 0xa0ddf0: r0 = DBusBusName()
    //     0xa0ddf0: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0xa0ddf4: stur            x0, [fp, #-0x18]
    // 0xa0ddf8: ldur            x16, [fp, #-8]
    // 0xa0ddfc: stp             x16, x0, [SP, #-0x10]!
    // 0xa0de00: r0 = DBusBusName()
    //     0xa0de00: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0xa0de04: add             SP, SP, #0x10
    // 0xa0de08: ldr             x0, [fp, #0x10]
    // 0xa0de0c: LoadField: r1 = r0->field_f
    //     0xa0de0c: ldur            w1, [x0, #0xf]
    // 0xa0de10: DecompressPointer r1
    //     0xa0de10: add             x1, x1, HEAP, lsl #32
    // 0xa0de14: stur            x1, [fp, #-0x20]
    // 0xa0de18: cmp             w1, NULL
    // 0xa0de1c: b.eq            #0xa0dea8
    // 0xa0de20: ldur            x2, [fp, #-0x10]
    // 0xa0de24: ldur            x0, [fp, #-0x18]
    // 0xa0de28: LoadField: r3 = r2->field_f
    //     0xa0de28: ldur            w3, [x2, #0xf]
    // 0xa0de2c: DecompressPointer r3
    //     0xa0de2c: add             x3, x3, HEAP, lsl #32
    // 0xa0de30: LoadField: r2 = r3->field_47
    //     0xa0de30: ldur            w2, [x3, #0x47]
    // 0xa0de34: DecompressPointer r2
    //     0xa0de34: add             x2, x2, HEAP, lsl #32
    // 0xa0de38: stur            x2, [fp, #-8]
    // 0xa0de3c: r0 = DBusBusName()
    //     0xa0de3c: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0xa0de40: stur            x0, [fp, #-0x28]
    // 0xa0de44: ldur            x16, [fp, #-0x20]
    // 0xa0de48: stp             x16, x0, [SP, #-0x10]!
    // 0xa0de4c: r0 = DBusBusName()
    //     0xa0de4c: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0xa0de50: add             SP, SP, #0x10
    // 0xa0de54: ldur            x1, [fp, #-0x18]
    // 0xa0de58: LoadField: r0 = r1->field_7
    //     0xa0de58: ldur            w0, [x1, #7]
    // 0xa0de5c: DecompressPointer r0
    //     0xa0de5c: add             x0, x0, HEAP, lsl #32
    // 0xa0de60: r2 = LoadClassIdInstr(r0)
    //     0xa0de60: ldur            x2, [x0, #-1]
    //     0xa0de64: ubfx            x2, x2, #0xc, #0x14
    // 0xa0de68: SaveReg r0
    //     0xa0de68: str             x0, [SP, #-8]!
    // 0xa0de6c: mov             x0, x2
    // 0xa0de70: r0 = GDT[cid_x0 + 0x2721]()
    //     0xa0de70: mov             x17, #0x2721
    //     0xa0de74: add             lr, x0, x17
    //     0xa0de78: ldr             lr, [x21, lr, lsl #3]
    //     0xa0de7c: blr             lr
    // 0xa0de80: add             SP, SP, #8
    // 0xa0de84: r1 = LoadInt32Instr(r0)
    //     0xa0de84: sbfx            x1, x0, #1, #0x1f
    // 0xa0de88: ldur            x16, [fp, #-8]
    // 0xa0de8c: ldur            lr, [fp, #-0x18]
    // 0xa0de90: stp             lr, x16, [SP, #-0x10]!
    // 0xa0de94: ldur            x16, [fp, #-0x28]
    // 0xa0de98: stp             x1, x16, [SP, #-0x10]!
    // 0xa0de9c: r0 = _set()
    //     0xa0de9c: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xa0dea0: add             SP, SP, #0x20
    // 0xa0dea4: b               #0xa0decc
    // 0xa0dea8: ldur            x2, [fp, #-0x10]
    // 0xa0deac: LoadField: r0 = r2->field_f
    //     0xa0deac: ldur            w0, [x2, #0xf]
    // 0xa0deb0: DecompressPointer r0
    //     0xa0deb0: add             x0, x0, HEAP, lsl #32
    // 0xa0deb4: LoadField: r1 = r0->field_47
    //     0xa0deb4: ldur            w1, [x0, #0x47]
    // 0xa0deb8: DecompressPointer r1
    //     0xa0deb8: add             x1, x1, HEAP, lsl #32
    // 0xa0debc: ldur            x16, [fp, #-0x18]
    // 0xa0dec0: stp             x16, x1, [SP, #-0x10]!
    // 0xa0dec4: r0 = remove()
    //     0xa0dec4: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xa0dec8: add             SP, SP, #0x10
    // 0xa0decc: r0 = Null
    //     0xa0decc: mov             x0, NULL
    // 0xa0ded0: LeaveFrame
    //     0xa0ded0: mov             SP, fp
    //     0xa0ded4: ldp             fp, lr, [SP], #0x10
    // 0xa0ded8: ret
    //     0xa0ded8: ret             
    // 0xa0dedc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0dedc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0dee0: b               #0xa0dde0
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0xa0dee4, size: 0xa0
    // 0xa0dee4: EnterFrame
    //     0xa0dee4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0dee8: mov             fp, SP
    // 0xa0deec: AllocStack(0x10)
    //     0xa0deec: sub             SP, SP, #0x10
    // 0xa0def0: SetupParameters()
    //     0xa0def0: ldr             x0, [fp, #0x18]
    //     0xa0def4: ldur            w1, [x0, #0x17]
    //     0xa0def8: add             x1, x1, HEAP, lsl #32
    //     0xa0defc: stur            x1, [fp, #-8]
    // 0xa0df00: CheckStackOverflow
    //     0xa0df00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0df04: cmp             SP, x16
    //     0xa0df08: b.ls            #0xa0df7c
    // 0xa0df0c: r0 = DBusBusName()
    //     0xa0df0c: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0xa0df10: stur            x0, [fp, #-0x10]
    // 0xa0df14: ldr             x16, [fp, #0x10]
    // 0xa0df18: stp             x16, x0, [SP, #-0x10]!
    // 0xa0df1c: r0 = DBusBusName()
    //     0xa0df1c: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0xa0df20: add             SP, SP, #0x10
    // 0xa0df24: ldur            x0, [fp, #-8]
    // 0xa0df28: LoadField: r1 = r0->field_f
    //     0xa0df28: ldur            w1, [x0, #0xf]
    // 0xa0df2c: DecompressPointer r1
    //     0xa0df2c: add             x1, x1, HEAP, lsl #32
    // 0xa0df30: LoadField: r2 = r1->field_47
    //     0xa0df30: ldur            w2, [x1, #0x47]
    // 0xa0df34: DecompressPointer r2
    //     0xa0df34: add             x2, x2, HEAP, lsl #32
    // 0xa0df38: ldur            x16, [fp, #-0x10]
    // 0xa0df3c: stp             x16, x2, [SP, #-0x10]!
    // 0xa0df40: r0 = remove()
    //     0xa0df40: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xa0df44: add             SP, SP, #0x10
    // 0xa0df48: ldur            x0, [fp, #-8]
    // 0xa0df4c: LoadField: r1 = r0->field_f
    //     0xa0df4c: ldur            w1, [x0, #0xf]
    // 0xa0df50: DecompressPointer r1
    //     0xa0df50: add             x1, x1, HEAP, lsl #32
    // 0xa0df54: LoadField: r0 = r1->field_4b
    //     0xa0df54: ldur            w0, [x1, #0x4b]
    // 0xa0df58: DecompressPointer r0
    //     0xa0df58: add             x0, x0, HEAP, lsl #32
    // 0xa0df5c: ldur            x16, [fp, #-0x10]
    // 0xa0df60: stp             x16, x0, [SP, #-0x10]!
    // 0xa0df64: r0 = remove()
    //     0xa0df64: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xa0df68: add             SP, SP, #0x10
    // 0xa0df6c: r0 = Null
    //     0xa0df6c: mov             x0, NULL
    // 0xa0df70: LeaveFrame
    //     0xa0df70: mov             SP, fp
    //     0xa0df74: ldp             fp, lr, [SP], #0x10
    // 0xa0df78: ret
    //     0xa0df78: ret             
    // 0xa0df7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0df7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0df80: b               #0xa0df0c
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0xa0df84, size: 0xfc
    // 0xa0df84: EnterFrame
    //     0xa0df84: stp             fp, lr, [SP, #-0x10]!
    //     0xa0df88: mov             fp, SP
    // 0xa0df8c: AllocStack(0x20)
    //     0xa0df8c: sub             SP, SP, #0x20
    // 0xa0df90: SetupParameters()
    //     0xa0df90: ldr             x0, [fp, #0x18]
    //     0xa0df94: ldur            w1, [x0, #0x17]
    //     0xa0df98: add             x1, x1, HEAP, lsl #32
    //     0xa0df9c: stur            x1, [fp, #-8]
    // 0xa0dfa0: CheckStackOverflow
    //     0xa0dfa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0dfa4: cmp             SP, x16
    //     0xa0dfa8: b.ls            #0xa0e074
    // 0xa0dfac: r0 = DBusBusName()
    //     0xa0dfac: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0xa0dfb0: stur            x0, [fp, #-0x10]
    // 0xa0dfb4: ldr             x16, [fp, #0x10]
    // 0xa0dfb8: stp             x16, x0, [SP, #-0x10]!
    // 0xa0dfbc: r0 = DBusBusName()
    //     0xa0dfbc: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0xa0dfc0: add             SP, SP, #0x10
    // 0xa0dfc4: ldur            x1, [fp, #-8]
    // 0xa0dfc8: LoadField: r0 = r1->field_f
    //     0xa0dfc8: ldur            w0, [x1, #0xf]
    // 0xa0dfcc: DecompressPointer r0
    //     0xa0dfcc: add             x0, x0, HEAP, lsl #32
    // 0xa0dfd0: LoadField: r2 = r0->field_47
    //     0xa0dfd0: ldur            w2, [x0, #0x47]
    // 0xa0dfd4: DecompressPointer r2
    //     0xa0dfd4: add             x2, x2, HEAP, lsl #32
    // 0xa0dfd8: stur            x2, [fp, #-0x20]
    // 0xa0dfdc: LoadField: r3 = r0->field_4f
    //     0xa0dfdc: ldur            w3, [x0, #0x4f]
    // 0xa0dfe0: DecompressPointer r3
    //     0xa0dfe0: add             x3, x3, HEAP, lsl #32
    // 0xa0dfe4: stur            x3, [fp, #-0x18]
    // 0xa0dfe8: cmp             w3, NULL
    // 0xa0dfec: b.eq            #0xa0e07c
    // 0xa0dff0: ldur            x4, [fp, #-0x10]
    // 0xa0dff4: LoadField: r0 = r4->field_7
    //     0xa0dff4: ldur            w0, [x4, #7]
    // 0xa0dff8: DecompressPointer r0
    //     0xa0dff8: add             x0, x0, HEAP, lsl #32
    // 0xa0dffc: r5 = LoadClassIdInstr(r0)
    //     0xa0dffc: ldur            x5, [x0, #-1]
    //     0xa0e000: ubfx            x5, x5, #0xc, #0x14
    // 0xa0e004: SaveReg r0
    //     0xa0e004: str             x0, [SP, #-8]!
    // 0xa0e008: mov             x0, x5
    // 0xa0e00c: r0 = GDT[cid_x0 + 0x2721]()
    //     0xa0e00c: mov             x17, #0x2721
    //     0xa0e010: add             lr, x0, x17
    //     0xa0e014: ldr             lr, [x21, lr, lsl #3]
    //     0xa0e018: blr             lr
    // 0xa0e01c: add             SP, SP, #8
    // 0xa0e020: r1 = LoadInt32Instr(r0)
    //     0xa0e020: sbfx            x1, x0, #1, #0x1f
    // 0xa0e024: ldur            x16, [fp, #-0x20]
    // 0xa0e028: ldur            lr, [fp, #-0x10]
    // 0xa0e02c: stp             lr, x16, [SP, #-0x10]!
    // 0xa0e030: ldur            x16, [fp, #-0x18]
    // 0xa0e034: stp             x1, x16, [SP, #-0x10]!
    // 0xa0e038: r0 = _set()
    //     0xa0e038: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xa0e03c: add             SP, SP, #0x20
    // 0xa0e040: ldur            x0, [fp, #-8]
    // 0xa0e044: LoadField: r1 = r0->field_f
    //     0xa0e044: ldur            w1, [x0, #0xf]
    // 0xa0e048: DecompressPointer r1
    //     0xa0e048: add             x1, x1, HEAP, lsl #32
    // 0xa0e04c: LoadField: r0 = r1->field_4b
    //     0xa0e04c: ldur            w0, [x1, #0x4b]
    // 0xa0e050: DecompressPointer r0
    //     0xa0e050: add             x0, x0, HEAP, lsl #32
    // 0xa0e054: ldur            x16, [fp, #-0x10]
    // 0xa0e058: stp             x16, x0, [SP, #-0x10]!
    // 0xa0e05c: r0 = add()
    //     0xa0e05c: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xa0e060: add             SP, SP, #0x10
    // 0xa0e064: r0 = Null
    //     0xa0e064: mov             x0, NULL
    // 0xa0e068: LeaveFrame
    //     0xa0e068: mov             SP, fp
    //     0xa0e06c: ldp             fp, lr, [SP], #0x10
    // 0xa0e070: ret
    //     0xa0e070: ret             
    // 0xa0e074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0e074: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0e078: b               #0xa0dfac
    // 0xa0e07c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa0e07c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0xa0e080, size: 0xe0
    // 0xa0e080: EnterFrame
    //     0xa0e080: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e084: mov             fp, SP
    // 0xa0e088: AllocStack(0x8)
    //     0xa0e088: sub             SP, SP, #8
    // 0xa0e08c: SetupParameters()
    //     0xa0e08c: ldr             x0, [fp, #0x18]
    //     0xa0e090: ldur            w1, [x0, #0x17]
    //     0xa0e094: add             x1, x1, HEAP, lsl #32
    // 0xa0e098: CheckStackOverflow
    //     0xa0e098: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0e09c: cmp             SP, x16
    //     0xa0e0a0: b.ls            #0xa0e158
    // 0xa0e0a4: LoadField: r0 = r1->field_f
    //     0xa0e0a4: ldur            w0, [x1, #0xf]
    // 0xa0e0a8: DecompressPointer r0
    //     0xa0e0a8: add             x0, x0, HEAP, lsl #32
    // 0xa0e0ac: LoadField: r3 = r0->field_b
    //     0xa0e0ac: ldur            w3, [x0, #0xb]
    // 0xa0e0b0: DecompressPointer r3
    //     0xa0e0b0: add             x3, x3, HEAP, lsl #32
    // 0xa0e0b4: stur            x3, [fp, #-8]
    // 0xa0e0b8: cmp             w3, NULL
    // 0xa0e0bc: b.ne            #0xa0e0c8
    // 0xa0e0c0: r0 = Null
    //     0xa0e0c0: mov             x0, NULL
    // 0xa0e0c4: b               #0xa0e14c
    // 0xa0e0c8: ldr             x0, [fp, #0x10]
    // 0xa0e0cc: r1 = Null
    //     0xa0e0cc: mov             x1, NULL
    // 0xa0e0d0: r2 = 4
    //     0xa0e0d0: mov             x2, #4
    // 0xa0e0d4: r0 = AllocateArray()
    //     0xa0e0d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0e0d8: mov             x1, x0
    // 0xa0e0dc: ldr             x0, [fp, #0x10]
    // 0xa0e0e0: StoreField: r1->field_f = r0
    //     0xa0e0e0: stur            w0, [x1, #0xf]
    // 0xa0e0e4: r17 = "\r\n"
    //     0xa0e0e4: ldr             x17, [PP, #0x7960]  ; [pp+0x7960] "\r\n"
    // 0xa0e0e8: StoreField: r1->field_13 = r17
    //     0xa0e0e8: stur            w17, [x1, #0x13]
    // 0xa0e0ec: SaveReg r1
    //     0xa0e0ec: str             x1, [SP, #-8]!
    // 0xa0e0f0: r0 = _interpolate()
    //     0xa0e0f0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0e0f4: add             SP, SP, #8
    // 0xa0e0f8: r16 = Instance_Utf8Codec
    //     0xa0e0f8: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xa0e0fc: stp             x0, x16, [SP, #-0x10]!
    // 0xa0e100: r0 = encode()
    //     0xa0e100: bl              #0xbfcc28  ; [dart:convert] Codec::encode
    // 0xa0e104: add             SP, SP, #0x10
    // 0xa0e108: mov             x1, x0
    // 0xa0e10c: ldur            x0, [fp, #-8]
    // 0xa0e110: r2 = LoadClassIdInstr(r0)
    //     0xa0e110: ldur            x2, [x0, #-1]
    //     0xa0e114: ubfx            x2, x2, #0xc, #0x14
    // 0xa0e118: stp             x1, x0, [SP, #-0x10]!
    // 0xa0e11c: mov             x0, x2
    // 0xa0e120: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0e120: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0e124: r0 = GDT[cid_x0 + -0xf03]()
    //     0xa0e124: sub             lr, x0, #0xf03
    //     0xa0e128: ldr             lr, [x21, lr, lsl #3]
    //     0xa0e12c: blr             lr
    // 0xa0e130: add             SP, SP, #0x10
    // 0xa0e134: mov             x2, x0
    // 0xa0e138: r0 = BoxInt64Instr(r2)
    //     0xa0e138: sbfiz           x0, x2, #1, #0x1f
    //     0xa0e13c: cmp             x2, x0, asr #1
    //     0xa0e140: b.eq            #0xa0e14c
    //     0xa0e144: bl              #0xd69bb8
    //     0xa0e148: stur            x2, [x0, #7]
    // 0xa0e14c: LeaveFrame
    //     0xa0e14c: mov             SP, fp
    //     0xa0e150: ldp             fp, lr, [SP], #0x10
    // 0xa0e154: ret
    //     0xa0e154: ret             
    // 0xa0e158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0e158: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0e15c: b               #0xa0e0a4
  }
  _ toString(/* No info */) {
    // ** addr: 0xacfaa0, size: 0x6c
    // 0xacfaa0: EnterFrame
    //     0xacfaa0: stp             fp, lr, [SP, #-0x10]!
    //     0xacfaa4: mov             fp, SP
    // 0xacfaa8: CheckStackOverflow
    //     0xacfaa8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacfaac: cmp             SP, x16
    //     0xacfab0: b.ls            #0xacfb04
    // 0xacfab4: r1 = Null
    //     0xacfab4: mov             x1, NULL
    // 0xacfab8: r2 = 8
    //     0xacfab8: mov             x2, #8
    // 0xacfabc: r0 = AllocateArray()
    //     0xacfabc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacfac0: r17 = DBusClient
    //     0xacfac0: add             x17, PP, #8, lsl #12  ; [pp+0x8828] Type: DBusClient
    //     0xacfac4: ldr             x17, [x17, #0x828]
    // 0xacfac8: StoreField: r0->field_f = r17
    //     0xacfac8: stur            w17, [x0, #0xf]
    // 0xacfacc: r17 = "(\'"
    //     0xacfacc: ldr             x17, [PP, #0x7168]  ; [pp+0x7168] "(\'"
    // 0xacfad0: StoreField: r0->field_13 = r17
    //     0xacfad0: stur            w17, [x0, #0x13]
    // 0xacfad4: ldr             x1, [fp, #0x10]
    // 0xacfad8: LoadField: r2 = r1->field_7
    //     0xacfad8: ldur            w2, [x1, #7]
    // 0xacfadc: DecompressPointer r2
    //     0xacfadc: add             x2, x2, HEAP, lsl #32
    // 0xacfae0: StoreField: r0->field_17 = r2
    //     0xacfae0: stur            w2, [x0, #0x17]
    // 0xacfae4: r17 = "\')"
    //     0xacfae4: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xacfae8: StoreField: r0->field_1b = r17
    //     0xacfae8: stur            w17, [x0, #0x1b]
    // 0xacfaec: SaveReg r0
    //     0xacfaec: str             x0, [SP, #-8]!
    // 0xacfaf0: r0 = _interpolate()
    //     0xacfaf0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacfaf4: add             SP, SP, #8
    // 0xacfaf8: LeaveFrame
    //     0xacfaf8: mov             SP, fp
    //     0xacfafc: ldp             fp, lr, [SP], #0x10
    // 0xacfb00: ret
    //     0xacfb00: ret             
    // 0xacfb04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacfb04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacfb08: b               #0xacfab4
  }
  _ _removeMatch(/* No info */) async {
    // ** addr: 0xc972f4, size: 0x210
    // 0xc972f4: EnterFrame
    //     0xc972f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc972f8: mov             fp, SP
    // 0xc972fc: AllocStack(0x40)
    //     0xc972fc: sub             SP, SP, #0x40
    // 0xc97300: SetupParameters(DBusClient this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xc97300: stur            NULL, [fp, #-8]
    //     0xc97304: mov             x0, #0
    //     0xc97308: add             x1, fp, w0, sxtw #2
    //     0xc9730c: ldr             x1, [x1, #0x18]
    //     0xc97310: stur            x1, [fp, #-0x18]
    //     0xc97314: add             x2, fp, w0, sxtw #2
    //     0xc97318: ldr             x2, [x2, #0x10]
    //     0xc9731c: stur            x2, [fp, #-0x10]
    // 0xc97320: CheckStackOverflow
    //     0xc97320: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc97324: cmp             SP, x16
    //     0xc97328: b.ls            #0xc974fc
    // 0xc9732c: InitAsync() -> Future<void?>
    //     0xc9732c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc97330: bl              #0x4b92e4
    // 0xc97334: ldur            x0, [fp, #-0x18]
    // 0xc97338: LoadField: r1 = r0->field_43
    //     0xc97338: ldur            w1, [x0, #0x43]
    // 0xc9733c: DecompressPointer r1
    //     0xc9733c: add             x1, x1, HEAP, lsl #32
    // 0xc97340: stur            x1, [fp, #-0x20]
    // 0xc97344: ldur            x16, [fp, #-0x10]
    // 0xc97348: stp             x16, x1, [SP, #-0x10]!
    // 0xc9734c: r0 = _getValueOrData()
    //     0xc9734c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc97350: add             SP, SP, #0x10
    // 0xc97354: mov             x1, x0
    // 0xc97358: ldur            x0, [fp, #-0x20]
    // 0xc9735c: LoadField: r2 = r0->field_f
    //     0xc9735c: ldur            w2, [x0, #0xf]
    // 0xc97360: DecompressPointer r2
    //     0xc97360: add             x2, x2, HEAP, lsl #32
    // 0xc97364: cmp             w2, w1
    // 0xc97368: b.ne            #0xc97370
    // 0xc9736c: r1 = Null
    //     0xc9736c: mov             x1, NULL
    // 0xc97370: cmp             w1, NULL
    // 0xc97374: b.eq            #0xc974c8
    // 0xc97378: ldur            x2, [fp, #-0x10]
    // 0xc9737c: cmp             w1, #2
    // 0xc97380: b.ne            #0xc9746c
    // 0xc97384: ldur            x1, [fp, #-0x18]
    // 0xc97388: stp             x2, x0, [SP, #-0x10]!
    // 0xc9738c: r0 = remove()
    //     0xc9738c: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc97390: add             SP, SP, #0x10
    // 0xc97394: ldur            x0, [fp, #-0x18]
    // 0xc97398: LoadField: r1 = r0->field_f
    //     0xc97398: ldur            w1, [x0, #0xf]
    // 0xc9739c: DecompressPointer r1
    //     0xc9739c: add             x1, x1, HEAP, lsl #32
    // 0xc973a0: tbz             w1, #4, #0xc974c0
    // 0xc973a4: ldur            x1, [fp, #-0x10]
    // 0xc973a8: r0 = DBusObjectPath()
    //     0xc973a8: bl              #0x9fce70  ; AllocateDBusObjectPathStub -> DBusObjectPath (size=0xc)
    // 0xc973ac: stur            x0, [fp, #-0x28]
    // 0xc973b0: r16 = "/org/freedesktop/DBus"
    //     0xc973b0: ldr             x16, [PP, #0x76f8]  ; [pp+0x76f8] "/org/freedesktop/DBus"
    // 0xc973b4: stp             x16, x0, [SP, #-0x10]!
    // 0xc973b8: r0 = DBusObjectPath()
    //     0xc973b8: bl              #0x9fcc00  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::DBusObjectPath
    // 0xc973bc: add             SP, SP, #0x10
    // 0xc973c0: r0 = DBusString()
    //     0xc973c0: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0xc973c4: ldur            x2, [fp, #-0x10]
    // 0xc973c8: stur            x0, [fp, #-0x30]
    // 0xc973cc: StoreField: r0->field_7 = r2
    //     0xc973cc: stur            w2, [x0, #7]
    // 0xc973d0: r1 = Null
    //     0xc973d0: mov             x1, NULL
    // 0xc973d4: r2 = 2
    //     0xc973d4: mov             x2, #2
    // 0xc973d8: r0 = AllocateArray()
    //     0xc973d8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc973dc: mov             x2, x0
    // 0xc973e0: ldur            x0, [fp, #-0x30]
    // 0xc973e4: stur            x2, [fp, #-0x38]
    // 0xc973e8: StoreField: r2->field_f = r0
    //     0xc973e8: stur            w0, [x2, #0xf]
    // 0xc973ec: r1 = <DBusValue>
    //     0xc973ec: ldr             x1, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xc973f0: r0 = AllocateGrowableArray()
    //     0xc973f0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xc973f4: mov             x1, x0
    // 0xc973f8: ldur            x0, [fp, #-0x38]
    // 0xc973fc: stur            x1, [fp, #-0x30]
    // 0xc97400: StoreField: r1->field_f = r0
    //     0xc97400: stur            w0, [x1, #0xf]
    // 0xc97404: r0 = 2
    //     0xc97404: mov             x0, #2
    // 0xc97408: StoreField: r1->field_b = r0
    //     0xc97408: stur            w0, [x1, #0xb]
    // 0xc9740c: r0 = DBusSignature()
    //     0xc9740c: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc97410: stur            x0, [fp, #-0x38]
    // 0xc97414: r16 = ""
    //     0xc97414: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xc97418: stp             x16, x0, [SP, #-0x10]!
    // 0xc9741c: r0 = DBusSignature()
    //     0xc9741c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc97420: add             SP, SP, #0x10
    // 0xc97424: ldur            x16, [fp, #-0x18]
    // 0xc97428: r30 = "org.freedesktop.DBus"
    //     0xc97428: ldr             lr, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xc9742c: stp             lr, x16, [SP, #-0x10]!
    // 0xc97430: r16 = "org.freedesktop.DBus"
    //     0xc97430: ldr             x16, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xc97434: r30 = "RemoveMatch"
    //     0xc97434: ldr             lr, [PP, #0x7708]  ; [pp+0x7708] "RemoveMatch"
    // 0xc97438: stp             lr, x16, [SP, #-0x10]!
    // 0xc9743c: ldur            x16, [fp, #-0x28]
    // 0xc97440: ldur            lr, [fp, #-0x38]
    // 0xc97444: stp             lr, x16, [SP, #-0x10]!
    // 0xc97448: ldur            x16, [fp, #-0x30]
    // 0xc9744c: SaveReg r16
    //     0xc9744c: str             x16, [SP, #-8]!
    // 0xc97450: r4 = const [0, 0x7, 0x7, 0x6, values, 0x6, null]
    //     0xc97450: ldr             x4, [PP, #0x7710]  ; [pp+0x7710] List(7) [0, 0x7, 0x7, 0x6, "values", 0x6, Null]
    // 0xc97454: r0 = callMethod()
    //     0xc97454: bl              #0x9fe338  ; [package:dbus/src/dbus_client.dart] DBusClient::callMethod
    // 0xc97458: add             SP, SP, #0x38
    // 0xc9745c: mov             x1, x0
    // 0xc97460: stur            x1, [fp, #-0x18]
    // 0xc97464: r0 = Await()
    //     0xc97464: bl              #0x4b8e6c  ; AwaitStub
    // 0xc97468: b               #0xc974c0
    // 0xc9746c: r3 = LoadInt32Instr(r1)
    //     0xc9746c: sbfx            x3, x1, #1, #0x1f
    //     0xc97470: tbz             w1, #0, #0xc97478
    //     0xc97474: ldur            x3, [x1, #7]
    // 0xc97478: sub             x1, x3, #1
    // 0xc9747c: stur            x1, [fp, #-0x40]
    // 0xc97480: stp             x2, x0, [SP, #-0x10]!
    // 0xc97484: r0 = hash()
    //     0xc97484: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0xc97488: add             SP, SP, #0x10
    // 0xc9748c: mov             x3, x0
    // 0xc97490: ldur            x2, [fp, #-0x40]
    // 0xc97494: r0 = BoxInt64Instr(r2)
    //     0xc97494: sbfiz           x0, x2, #1, #0x1f
    //     0xc97498: cmp             x2, x0, asr #1
    //     0xc9749c: b.eq            #0xc974a8
    //     0xc974a0: bl              #0xd69bb8
    //     0xc974a4: stur            x2, [x0, #7]
    // 0xc974a8: ldur            x16, [fp, #-0x20]
    // 0xc974ac: ldur            lr, [fp, #-0x10]
    // 0xc974b0: stp             lr, x16, [SP, #-0x10]!
    // 0xc974b4: stp             x3, x0, [SP, #-0x10]!
    // 0xc974b8: r0 = _set()
    //     0xc974b8: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc974bc: add             SP, SP, #0x20
    // 0xc974c0: r0 = Null
    //     0xc974c0: mov             x0, NULL
    // 0xc974c4: r0 = ReturnAsyncNotFuture()
    //     0xc974c4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc974c8: ldur            x0, [fp, #-0x10]
    // 0xc974cc: r1 = Null
    //     0xc974cc: mov             x1, NULL
    // 0xc974d0: r2 = 4
    //     0xc974d0: mov             x2, #4
    // 0xc974d4: r0 = AllocateArray()
    //     0xc974d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc974d8: r17 = "Attempted to remove match that is not added: "
    //     0xc974d8: ldr             x17, [PP, #0x7718]  ; [pp+0x7718] "Attempted to remove match that is not added: "
    // 0xc974dc: StoreField: r0->field_f = r17
    //     0xc974dc: stur            w17, [x0, #0xf]
    // 0xc974e0: ldur            x2, [fp, #-0x10]
    // 0xc974e4: StoreField: r0->field_13 = r2
    //     0xc974e4: stur            w2, [x0, #0x13]
    // 0xc974e8: SaveReg r0
    //     0xc974e8: str             x0, [SP, #-8]!
    // 0xc974ec: r0 = _interpolate()
    //     0xc974ec: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc974f0: add             SP, SP, #8
    // 0xc974f4: r0 = Throw()
    //     0xc974f4: bl              #0xd67e38  ; ThrowStub
    // 0xc974f8: brk             #0
    // 0xc974fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc974fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc97500: b               #0xc9732c
  }
  _ _addMatch(/* No info */) async {
    // ** addr: 0xc97bf0, size: 0x1e8
    // 0xc97bf0: EnterFrame
    //     0xc97bf0: stp             fp, lr, [SP, #-0x10]!
    //     0xc97bf4: mov             fp, SP
    // 0xc97bf8: AllocStack(0x40)
    //     0xc97bf8: sub             SP, SP, #0x40
    // 0xc97bfc: SetupParameters(DBusClient this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xc97bfc: stur            NULL, [fp, #-8]
    //     0xc97c00: mov             x0, #0
    //     0xc97c04: add             x1, fp, w0, sxtw #2
    //     0xc97c08: ldr             x1, [x1, #0x18]
    //     0xc97c0c: stur            x1, [fp, #-0x18]
    //     0xc97c10: add             x2, fp, w0, sxtw #2
    //     0xc97c14: ldr             x2, [x2, #0x10]
    //     0xc97c18: stur            x2, [fp, #-0x10]
    // 0xc97c1c: CheckStackOverflow
    //     0xc97c1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc97c20: cmp             SP, x16
    //     0xc97c24: b.ls            #0xc97dd0
    // 0xc97c28: InitAsync() -> Future<void?>
    //     0xc97c28: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc97c2c: bl              #0x4b92e4
    // 0xc97c30: ldur            x0, [fp, #-0x18]
    // 0xc97c34: LoadField: r1 = r0->field_43
    //     0xc97c34: ldur            w1, [x0, #0x43]
    // 0xc97c38: DecompressPointer r1
    //     0xc97c38: add             x1, x1, HEAP, lsl #32
    // 0xc97c3c: stur            x1, [fp, #-0x20]
    // 0xc97c40: ldur            x16, [fp, #-0x10]
    // 0xc97c44: stp             x16, x1, [SP, #-0x10]!
    // 0xc97c48: r0 = _getValueOrData()
    //     0xc97c48: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc97c4c: add             SP, SP, #0x10
    // 0xc97c50: mov             x1, x0
    // 0xc97c54: ldur            x0, [fp, #-0x20]
    // 0xc97c58: LoadField: r2 = r0->field_f
    //     0xc97c58: ldur            w2, [x0, #0xf]
    // 0xc97c5c: DecompressPointer r2
    //     0xc97c5c: add             x2, x2, HEAP, lsl #32
    // 0xc97c60: cmp             w2, w1
    // 0xc97c64: b.ne            #0xc97c6c
    // 0xc97c68: r1 = Null
    //     0xc97c68: mov             x1, NULL
    // 0xc97c6c: cmp             w1, NULL
    // 0xc97c70: b.ne            #0xc97d6c
    // 0xc97c74: ldur            x1, [fp, #-0x10]
    // 0xc97c78: stp             x1, x0, [SP, #-0x10]!
    // 0xc97c7c: r0 = hash()
    //     0xc97c7c: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0xc97c80: add             SP, SP, #0x10
    // 0xc97c84: ldur            x16, [fp, #-0x20]
    // 0xc97c88: ldur            lr, [fp, #-0x10]
    // 0xc97c8c: stp             lr, x16, [SP, #-0x10]!
    // 0xc97c90: r16 = 2
    //     0xc97c90: mov             x16, #2
    // 0xc97c94: stp             x0, x16, [SP, #-0x10]!
    // 0xc97c98: r0 = _set()
    //     0xc97c98: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc97c9c: add             SP, SP, #0x20
    // 0xc97ca0: r0 = DBusObjectPath()
    //     0xc97ca0: bl              #0x9fce70  ; AllocateDBusObjectPathStub -> DBusObjectPath (size=0xc)
    // 0xc97ca4: stur            x0, [fp, #-0x28]
    // 0xc97ca8: r16 = "/org/freedesktop/DBus"
    //     0xc97ca8: ldr             x16, [PP, #0x76f8]  ; [pp+0x76f8] "/org/freedesktop/DBus"
    // 0xc97cac: stp             x16, x0, [SP, #-0x10]!
    // 0xc97cb0: r0 = DBusObjectPath()
    //     0xc97cb0: bl              #0x9fcc00  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::DBusObjectPath
    // 0xc97cb4: add             SP, SP, #0x10
    // 0xc97cb8: r0 = DBusString()
    //     0xc97cb8: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0xc97cbc: mov             x3, x0
    // 0xc97cc0: ldur            x0, [fp, #-0x10]
    // 0xc97cc4: stur            x3, [fp, #-0x30]
    // 0xc97cc8: StoreField: r3->field_7 = r0
    //     0xc97cc8: stur            w0, [x3, #7]
    // 0xc97ccc: r1 = Null
    //     0xc97ccc: mov             x1, NULL
    // 0xc97cd0: r2 = 2
    //     0xc97cd0: mov             x2, #2
    // 0xc97cd4: r0 = AllocateArray()
    //     0xc97cd4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc97cd8: mov             x2, x0
    // 0xc97cdc: ldur            x0, [fp, #-0x30]
    // 0xc97ce0: stur            x2, [fp, #-0x38]
    // 0xc97ce4: StoreField: r2->field_f = r0
    //     0xc97ce4: stur            w0, [x2, #0xf]
    // 0xc97ce8: r1 = <DBusValue>
    //     0xc97ce8: ldr             x1, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xc97cec: r0 = AllocateGrowableArray()
    //     0xc97cec: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xc97cf0: mov             x1, x0
    // 0xc97cf4: ldur            x0, [fp, #-0x38]
    // 0xc97cf8: stur            x1, [fp, #-0x30]
    // 0xc97cfc: StoreField: r1->field_f = r0
    //     0xc97cfc: stur            w0, [x1, #0xf]
    // 0xc97d00: r0 = 2
    //     0xc97d00: mov             x0, #2
    // 0xc97d04: StoreField: r1->field_b = r0
    //     0xc97d04: stur            w0, [x1, #0xb]
    // 0xc97d08: r0 = DBusSignature()
    //     0xc97d08: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc97d0c: stur            x0, [fp, #-0x38]
    // 0xc97d10: r16 = ""
    //     0xc97d10: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xc97d14: stp             x16, x0, [SP, #-0x10]!
    // 0xc97d18: r0 = DBusSignature()
    //     0xc97d18: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc97d1c: add             SP, SP, #0x10
    // 0xc97d20: ldur            x16, [fp, #-0x18]
    // 0xc97d24: r30 = "org.freedesktop.DBus"
    //     0xc97d24: ldr             lr, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xc97d28: stp             lr, x16, [SP, #-0x10]!
    // 0xc97d2c: r16 = "org.freedesktop.DBus"
    //     0xc97d2c: ldr             x16, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xc97d30: r30 = "AddMatch"
    //     0xc97d30: add             lr, PP, #8, lsl #12  ; [pp+0x87e0] "AddMatch"
    //     0xc97d34: ldr             lr, [lr, #0x7e0]
    // 0xc97d38: stp             lr, x16, [SP, #-0x10]!
    // 0xc97d3c: ldur            x16, [fp, #-0x28]
    // 0xc97d40: ldur            lr, [fp, #-0x38]
    // 0xc97d44: stp             lr, x16, [SP, #-0x10]!
    // 0xc97d48: ldur            x16, [fp, #-0x30]
    // 0xc97d4c: SaveReg r16
    //     0xc97d4c: str             x16, [SP, #-8]!
    // 0xc97d50: r4 = const [0, 0x7, 0x7, 0x6, values, 0x6, null]
    //     0xc97d50: ldr             x4, [PP, #0x7710]  ; [pp+0x7710] List(7) [0, 0x7, 0x7, 0x6, "values", 0x6, Null]
    // 0xc97d54: r0 = callMethod()
    //     0xc97d54: bl              #0x9fe338  ; [package:dbus/src/dbus_client.dart] DBusClient::callMethod
    // 0xc97d58: add             SP, SP, #0x38
    // 0xc97d5c: mov             x1, x0
    // 0xc97d60: stur            x1, [fp, #-0x18]
    // 0xc97d64: r0 = Await()
    //     0xc97d64: bl              #0x4b8e6c  ; AwaitStub
    // 0xc97d68: b               #0xc97dc8
    // 0xc97d6c: ldur            x0, [fp, #-0x10]
    // 0xc97d70: r2 = LoadInt32Instr(r1)
    //     0xc97d70: sbfx            x2, x1, #1, #0x1f
    //     0xc97d74: tbz             w1, #0, #0xc97d7c
    //     0xc97d78: ldur            x2, [x1, #7]
    // 0xc97d7c: add             x1, x2, #1
    // 0xc97d80: stur            x1, [fp, #-0x40]
    // 0xc97d84: ldur            x16, [fp, #-0x20]
    // 0xc97d88: stp             x0, x16, [SP, #-0x10]!
    // 0xc97d8c: r0 = hash()
    //     0xc97d8c: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0xc97d90: add             SP, SP, #0x10
    // 0xc97d94: mov             x3, x0
    // 0xc97d98: ldur            x2, [fp, #-0x40]
    // 0xc97d9c: r0 = BoxInt64Instr(r2)
    //     0xc97d9c: sbfiz           x0, x2, #1, #0x1f
    //     0xc97da0: cmp             x2, x0, asr #1
    //     0xc97da4: b.eq            #0xc97db0
    //     0xc97da8: bl              #0xd69bb8
    //     0xc97dac: stur            x2, [x0, #7]
    // 0xc97db0: ldur            x16, [fp, #-0x20]
    // 0xc97db4: ldur            lr, [fp, #-0x10]
    // 0xc97db8: stp             lr, x16, [SP, #-0x10]!
    // 0xc97dbc: stp             x3, x0, [SP, #-0x10]!
    // 0xc97dc0: r0 = _set()
    //     0xc97dc0: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc97dc4: add             SP, SP, #0x20
    // 0xc97dc8: r0 = Null
    //     0xc97dc8: mov             x0, NULL
    // 0xc97dcc: r0 = ReturnAsyncNotFuture()
    //     0xc97dcc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc97dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc97dd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc97dd4: b               #0xc97c28
  }
  _ _findUniqueName(/* No info */) async {
    // ** addr: 0xc97dd8, size: 0x15c
    // 0xc97dd8: EnterFrame
    //     0xc97dd8: stp             fp, lr, [SP, #-0x10]!
    //     0xc97ddc: mov             fp, SP
    // 0xc97de0: AllocStack(0x30)
    //     0xc97de0: sub             SP, SP, #0x30
    // 0xc97de4: SetupParameters(DBusClient this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xc97de4: stur            NULL, [fp, #-8]
    //     0xc97de8: mov             x0, #0
    //     0xc97dec: add             x1, fp, w0, sxtw #2
    //     0xc97df0: ldr             x1, [x1, #0x18]
    //     0xc97df4: stur            x1, [fp, #-0x18]
    //     0xc97df8: add             x2, fp, w0, sxtw #2
    //     0xc97dfc: ldr             x2, [x2, #0x10]
    //     0xc97e00: stur            x2, [fp, #-0x10]
    // 0xc97e04: CheckStackOverflow
    //     0xc97e04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc97e08: cmp             SP, x16
    //     0xc97e0c: b.ls            #0xc97f2c
    // 0xc97e10: InitAsync() -> Future<DBusBusName?>
    //     0xc97e10: add             x0, PP, #8, lsl #12  ; [pp+0x87e8] TypeArguments: <DBusBusName?>
    //     0xc97e14: ldr             x0, [x0, #0x7e8]
    //     0xc97e18: bl              #0x4b92e4
    // 0xc97e1c: ldur            x0, [fp, #-0x18]
    // 0xc97e20: LoadField: r1 = r0->field_47
    //     0xc97e20: ldur            w1, [x0, #0x47]
    // 0xc97e24: DecompressPointer r1
    //     0xc97e24: add             x1, x1, HEAP, lsl #32
    // 0xc97e28: stur            x1, [fp, #-0x20]
    // 0xc97e2c: ldur            x16, [fp, #-0x10]
    // 0xc97e30: stp             x16, x1, [SP, #-0x10]!
    // 0xc97e34: r0 = containsValue()
    //     0xc97e34: bl              #0xc9816c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsValue
    // 0xc97e38: add             SP, SP, #0x10
    // 0xc97e3c: tbnz            w0, #4, #0xc97e7c
    // 0xc97e40: ldur            x0, [fp, #-0x20]
    // 0xc97e44: ldur            x16, [fp, #-0x10]
    // 0xc97e48: stp             x16, x0, [SP, #-0x10]!
    // 0xc97e4c: r0 = _getValueOrData()
    //     0xc97e4c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc97e50: add             SP, SP, #0x10
    // 0xc97e54: mov             x1, x0
    // 0xc97e58: ldur            x0, [fp, #-0x20]
    // 0xc97e5c: LoadField: r2 = r0->field_f
    //     0xc97e5c: ldur            w2, [x0, #0xf]
    // 0xc97e60: DecompressPointer r2
    //     0xc97e60: add             x2, x2, HEAP, lsl #32
    // 0xc97e64: cmp             w2, w1
    // 0xc97e68: b.ne            #0xc97e74
    // 0xc97e6c: r0 = Null
    //     0xc97e6c: mov             x0, NULL
    // 0xc97e70: b               #0xc97e78
    // 0xc97e74: mov             x0, x1
    // 0xc97e78: r0 = ReturnAsync()
    //     0xc97e78: b               #0x501858  ; ReturnAsyncStub
    // 0xc97e7c: ldur            x1, [fp, #-0x10]
    // 0xc97e80: ldur            x0, [fp, #-0x20]
    // 0xc97e84: LoadField: r2 = r1->field_7
    //     0xc97e84: ldur            w2, [x1, #7]
    // 0xc97e88: DecompressPointer r2
    //     0xc97e88: add             x2, x2, HEAP, lsl #32
    // 0xc97e8c: stur            x2, [fp, #-0x28]
    // 0xc97e90: ldur            x16, [fp, #-0x18]
    // 0xc97e94: stp             x2, x16, [SP, #-0x10]!
    // 0xc97e98: r0 = getNameOwner()
    //     0xc97e98: bl              #0xc97f34  ; [package:dbus/src/dbus_client.dart] DBusClient::getNameOwner
    // 0xc97e9c: add             SP, SP, #0x10
    // 0xc97ea0: mov             x1, x0
    // 0xc97ea4: stur            x1, [fp, #-0x30]
    // 0xc97ea8: r0 = Await()
    //     0xc97ea8: bl              #0x4b8e6c  ; AwaitStub
    // 0xc97eac: stur            x0, [fp, #-0x18]
    // 0xc97eb0: cmp             w0, NULL
    // 0xc97eb4: b.ne            #0xc97ec0
    // 0xc97eb8: r0 = Null
    //     0xc97eb8: mov             x0, NULL
    // 0xc97ebc: r0 = ReturnAsyncNotFuture()
    //     0xc97ebc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc97ec0: ldur            x1, [fp, #-0x28]
    // 0xc97ec4: r0 = DBusBusName()
    //     0xc97ec4: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0xc97ec8: stur            x0, [fp, #-0x30]
    // 0xc97ecc: ldur            x16, [fp, #-0x18]
    // 0xc97ed0: stp             x16, x0, [SP, #-0x10]!
    // 0xc97ed4: r0 = DBusBusName()
    //     0xc97ed4: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0xc97ed8: add             SP, SP, #0x10
    // 0xc97edc: ldur            x0, [fp, #-0x28]
    // 0xc97ee0: r1 = LoadClassIdInstr(r0)
    //     0xc97ee0: ldur            x1, [x0, #-1]
    //     0xc97ee4: ubfx            x1, x1, #0xc, #0x14
    // 0xc97ee8: SaveReg r0
    //     0xc97ee8: str             x0, [SP, #-8]!
    // 0xc97eec: mov             x0, x1
    // 0xc97ef0: r0 = GDT[cid_x0 + 0x2721]()
    //     0xc97ef0: mov             x17, #0x2721
    //     0xc97ef4: add             lr, x0, x17
    //     0xc97ef8: ldr             lr, [x21, lr, lsl #3]
    //     0xc97efc: blr             lr
    // 0xc97f00: add             SP, SP, #8
    // 0xc97f04: r1 = LoadInt32Instr(r0)
    //     0xc97f04: sbfx            x1, x0, #1, #0x1f
    // 0xc97f08: ldur            x16, [fp, #-0x20]
    // 0xc97f0c: ldur            lr, [fp, #-0x10]
    // 0xc97f10: stp             lr, x16, [SP, #-0x10]!
    // 0xc97f14: ldur            x16, [fp, #-0x30]
    // 0xc97f18: stp             x1, x16, [SP, #-0x10]!
    // 0xc97f1c: r0 = _set()
    //     0xc97f1c: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc97f20: add             SP, SP, #0x20
    // 0xc97f24: ldur            x0, [fp, #-0x30]
    // 0xc97f28: r0 = ReturnAsyncNotFuture()
    //     0xc97f28: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc97f2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc97f2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc97f30: b               #0xc97e10
  }
  _ getNameOwner(/* No info */) async {
    // ** addr: 0xc97f34, size: 0x238
    // 0xc97f34: EnterFrame
    //     0xc97f34: stp             fp, lr, [SP, #-0x10]!
    //     0xc97f38: mov             fp, SP
    // 0xc97f3c: AllocStack(0x80)
    //     0xc97f3c: sub             SP, SP, #0x80
    // 0xc97f40: SetupParameters(DBusClient this /* r1, fp-0x70 */, dynamic _ /* r2, fp-0x68 */)
    //     0xc97f40: stur            NULL, [fp, #-8]
    //     0xc97f44: mov             x0, #0
    //     0xc97f48: add             x1, fp, w0, sxtw #2
    //     0xc97f4c: ldr             x1, [x1, #0x18]
    //     0xc97f50: stur            x1, [fp, #-0x70]
    //     0xc97f54: add             x2, fp, w0, sxtw #2
    //     0xc97f58: ldr             x2, [x2, #0x10]
    //     0xc97f5c: stur            x2, [fp, #-0x68]
    // 0xc97f60: CheckStackOverflow
    //     0xc97f60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc97f64: cmp             SP, x16
    //     0xc97f68: b.ls            #0xc98160
    // 0xc97f6c: InitAsync() -> Future<String?>
    //     0xc97f6c: ldr             x0, [PP, #0x1020]  ; [pp+0x1020] TypeArguments: <String?>
    //     0xc97f70: bl              #0x4b92e4
    // 0xc97f74: ldur            x0, [fp, #-0x68]
    // 0xc97f78: r0 = DBusObjectPath()
    //     0xc97f78: bl              #0x9fce70  ; AllocateDBusObjectPathStub -> DBusObjectPath (size=0xc)
    // 0xc97f7c: stur            x0, [fp, #-0x78]
    // 0xc97f80: r16 = "/org/freedesktop/DBus"
    //     0xc97f80: ldr             x16, [PP, #0x76f8]  ; [pp+0x76f8] "/org/freedesktop/DBus"
    // 0xc97f84: stp             x16, x0, [SP, #-0x10]!
    // 0xc97f88: r0 = DBusObjectPath()
    //     0xc97f88: bl              #0x9fcc00  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::DBusObjectPath
    // 0xc97f8c: add             SP, SP, #0x10
    // 0xc97f90: r0 = DBusString()
    //     0xc97f90: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0xc97f94: mov             x3, x0
    // 0xc97f98: ldur            x0, [fp, #-0x68]
    // 0xc97f9c: stur            x3, [fp, #-0x80]
    // 0xc97fa0: StoreField: r3->field_7 = r0
    //     0xc97fa0: stur            w0, [x3, #7]
    // 0xc97fa4: r1 = Null
    //     0xc97fa4: mov             x1, NULL
    // 0xc97fa8: r2 = 2
    //     0xc97fa8: mov             x2, #2
    // 0xc97fac: r0 = AllocateArray()
    //     0xc97fac: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc97fb0: mov             x2, x0
    // 0xc97fb4: ldur            x0, [fp, #-0x80]
    // 0xc97fb8: stur            x2, [fp, #-0x68]
    // 0xc97fbc: StoreField: r2->field_f = r0
    //     0xc97fbc: stur            w0, [x2, #0xf]
    // 0xc97fc0: r1 = <DBusValue>
    //     0xc97fc0: ldr             x1, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xc97fc4: r0 = AllocateGrowableArray()
    //     0xc97fc4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xc97fc8: mov             x1, x0
    // 0xc97fcc: ldur            x0, [fp, #-0x68]
    // 0xc97fd0: stur            x1, [fp, #-0x80]
    // 0xc97fd4: StoreField: r1->field_f = r0
    //     0xc97fd4: stur            w0, [x1, #0xf]
    // 0xc97fd8: r0 = 2
    //     0xc97fd8: mov             x0, #2
    // 0xc97fdc: StoreField: r1->field_b = r0
    //     0xc97fdc: stur            w0, [x1, #0xb]
    // 0xc97fe0: r0 = DBusSignature()
    //     0xc97fe0: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xc97fe4: stur            x0, [fp, #-0x68]
    // 0xc97fe8: r16 = "s"
    //     0xc97fe8: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xc97fec: stp             x16, x0, [SP, #-0x10]!
    // 0xc97ff0: r0 = DBusSignature()
    //     0xc97ff0: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xc97ff4: add             SP, SP, #0x10
    // 0xc97ff8: ldur            x16, [fp, #-0x70]
    // 0xc97ffc: r30 = "org.freedesktop.DBus"
    //     0xc97ffc: ldr             lr, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xc98000: stp             lr, x16, [SP, #-0x10]!
    // 0xc98004: r16 = "org.freedesktop.DBus"
    //     0xc98004: ldr             x16, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xc98008: r30 = "GetNameOwner"
    //     0xc98008: add             lr, PP, #8, lsl #12  ; [pp+0x87f0] "GetNameOwner"
    //     0xc9800c: ldr             lr, [lr, #0x7f0]
    // 0xc98010: stp             lr, x16, [SP, #-0x10]!
    // 0xc98014: ldur            x16, [fp, #-0x78]
    // 0xc98018: ldur            lr, [fp, #-0x68]
    // 0xc9801c: stp             lr, x16, [SP, #-0x10]!
    // 0xc98020: ldur            x16, [fp, #-0x80]
    // 0xc98024: SaveReg r16
    //     0xc98024: str             x16, [SP, #-8]!
    // 0xc98028: r4 = const [0, 0x7, 0x7, 0x6, values, 0x6, null]
    //     0xc98028: ldr             x4, [PP, #0x7710]  ; [pp+0x7710] List(7) [0, 0x7, 0x7, 0x6, "values", 0x6, Null]
    // 0xc9802c: r0 = callMethod()
    //     0xc9802c: bl              #0x9fe338  ; [package:dbus/src/dbus_client.dart] DBusClient::callMethod
    // 0xc98030: add             SP, SP, #0x38
    // 0xc98034: mov             x1, x0
    // 0xc98038: stur            x1, [fp, #-0x68]
    // 0xc9803c: r0 = Await()
    //     0xc9803c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc98040: cmp             w0, NULL
    // 0xc98044: b.eq            #0xc98168
    // 0xc98048: LoadField: r1 = r0->field_7
    //     0xc98048: ldur            w1, [x0, #7]
    // 0xc9804c: DecompressPointer r1
    //     0xc9804c: add             x1, x1, HEAP, lsl #32
    // 0xc98050: r0 = LoadClassIdInstr(r1)
    //     0xc98050: ldur            x0, [x1, #-1]
    //     0xc98054: ubfx            x0, x0, #0xc, #0x14
    // 0xc98058: stp             xzr, x1, [SP, #-0x10]!
    // 0xc9805c: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc9805c: sub             lr, x0, #0xd83
    //     0xc98060: ldr             lr, [x21, lr, lsl #3]
    //     0xc98064: blr             lr
    // 0xc98068: add             SP, SP, #0x10
    // 0xc9806c: mov             x3, x0
    // 0xc98070: r2 = Null
    //     0xc98070: mov             x2, NULL
    // 0xc98074: r1 = Null
    //     0xc98074: mov             x1, NULL
    // 0xc98078: stur            x3, [fp, #-0x68]
    // 0xc9807c: r4 = 59
    //     0xc9807c: mov             x4, #0x3b
    // 0xc98080: branchIfSmi(r0, 0xc9808c)
    //     0xc98080: tbz             w0, #0, #0xc9808c
    // 0xc98084: r4 = LoadClassIdInstr(r0)
    //     0xc98084: ldur            x4, [x0, #-1]
    //     0xc98088: ubfx            x4, x4, #0xc, #0x14
    // 0xc9808c: r17 = -4573
    //     0xc9808c: mov             x17, #-0x11dd
    // 0xc98090: add             x4, x4, x17
    // 0xc98094: cmp             x4, #1
    // 0xc98098: b.ls            #0xc980ac
    // 0xc9809c: r8 = DBusString
    //     0xc9809c: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xc980a0: r3 = Null
    //     0xc980a0: add             x3, PP, #8, lsl #12  ; [pp+0x87f8] Null
    //     0xc980a4: ldr             x3, [x3, #0x7f8]
    // 0xc980a8: r0 = DefaultTypeTest()
    //     0xc980a8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xc980ac: ldur            x0, [fp, #-0x68]
    // 0xc980b0: LoadField: r1 = r0->field_7
    //     0xc980b0: ldur            w1, [x0, #7]
    // 0xc980b4: DecompressPointer r1
    //     0xc980b4: add             x1, x1, HEAP, lsl #32
    // 0xc980b8: mov             x0, x1
    // 0xc980bc: r0 = ReturnAsyncNotFuture()
    //     0xc980bc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc980c0: sub             SP, fp, #0x80
    // 0xc980c4: mov             x2, x0
    // 0xc980c8: stur            x0, [fp, #-0x68]
    // 0xc980cc: stur            x1, [fp, #-0x70]
    // 0xc980d0: r0 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0xc980d0: mov             x0, #0x76
    //     0xc980d4: tbz             w2, #0, #0xc980e4
    //     0xc980d8: ldur            x0, [x2, #-1]
    //     0xc980dc: ubfx            x0, x0, #0xc, #0x14
    //     0xc980e0: lsl             x0, x0, #1
    // 0xc980e4: r3 = LoadInt32Instr(r0)
    //     0xc980e4: sbfx            x3, x0, #1, #0x1f
    // 0xc980e8: r17 = 4591
    //     0xc980e8: mov             x17, #0x11ef
    // 0xc980ec: cmp             x3, x17
    // 0xc980f0: b.lt            #0xc98150
    // 0xc980f4: r17 = 4606
    //     0xc980f4: mov             x17, #0x11fe
    // 0xc980f8: cmp             x3, x17
    // 0xc980fc: b.gt            #0xc98150
    // 0xc98100: LoadField: r0 = r2->field_7
    //     0xc98100: ldur            w0, [x2, #7]
    // 0xc98104: DecompressPointer r0
    //     0xc98104: add             x0, x0, HEAP, lsl #32
    // 0xc98108: LoadField: r3 = r0->field_7
    //     0xc98108: ldur            w3, [x0, #7]
    // 0xc9810c: DecompressPointer r3
    //     0xc9810c: add             x3, x3, HEAP, lsl #32
    // 0xc98110: r0 = LoadClassIdInstr(r3)
    //     0xc98110: ldur            x0, [x3, #-1]
    //     0xc98114: ubfx            x0, x0, #0xc, #0x14
    // 0xc98118: r16 = "org.freedesktop.DBus.Error.NameHasNoOwner"
    //     0xc98118: add             x16, PP, #8, lsl #12  ; [pp+0x8808] "org.freedesktop.DBus.Error.NameHasNoOwner"
    //     0xc9811c: ldr             x16, [x16, #0x808]
    // 0xc98120: stp             x16, x3, [SP, #-0x10]!
    // 0xc98124: mov             lr, x0
    // 0xc98128: ldr             lr, [x21, lr, lsl #3]
    // 0xc9812c: blr             lr
    // 0xc98130: add             SP, SP, #0x10
    // 0xc98134: tbnz            w0, #4, #0xc98140
    // 0xc98138: r0 = Null
    //     0xc98138: mov             x0, NULL
    // 0xc9813c: r0 = ReturnAsyncNotFuture()
    //     0xc9813c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc98140: ldur            x0, [fp, #-0x68]
    // 0xc98144: ldur            x1, [fp, #-0x70]
    // 0xc98148: r0 = ReThrow()
    //     0xc98148: bl              #0xd67e14  ; ReThrowStub
    // 0xc9814c: brk             #0
    // 0xc98150: ldur            x0, [fp, #-0x68]
    // 0xc98154: ldur            x1, [fp, #-0x70]
    // 0xc98158: r0 = ReThrow()
    //     0xc98158: bl              #0xd67e14  ; ReThrowStub
    // 0xc9815c: brk             #0
    // 0xc98160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc98160: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc98164: b               #0xc97f6c
    // 0xc98168: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc98168: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  factory _ DBusClient.system(/* No info */) {
    // ** addr: 0xd6e9a0, size: 0x8c
    // 0xd6e9a0: EnterFrame
    //     0xd6e9a0: stp             fp, lr, [SP, #-0x10]!
    //     0xd6e9a4: mov             fp, SP
    // 0xd6e9a8: AllocStack(0x10)
    //     0xd6e9a8: sub             SP, SP, #0x10
    // 0xd6e9ac: CheckStackOverflow
    //     0xd6e9ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6e9b0: cmp             SP, x16
    //     0xd6e9b4: b.ls            #0xd6ea24
    // 0xd6e9b8: r0 = environment()
    //     0xd6e9b8: bl              #0x555764  ; [dart:io] _Platform::environment
    // 0xd6e9bc: r1 = LoadClassIdInstr(r0)
    //     0xd6e9bc: ldur            x1, [x0, #-1]
    //     0xd6e9c0: ubfx            x1, x1, #0xc, #0x14
    // 0xd6e9c4: r16 = "DBUS_SYSTEM_BUS_ADDRESS"
    //     0xd6e9c4: ldr             x16, [PP, #0x788]  ; [pp+0x788] "DBUS_SYSTEM_BUS_ADDRESS"
    // 0xd6e9c8: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e9cc: mov             x0, x1
    // 0xd6e9d0: r0 = GDT[cid_x0 + -0xef]()
    //     0xd6e9d0: sub             lr, x0, #0xef
    //     0xd6e9d4: ldr             lr, [x21, lr, lsl #3]
    //     0xd6e9d8: blr             lr
    // 0xd6e9dc: add             SP, SP, #0x10
    // 0xd6e9e0: cmp             w0, NULL
    // 0xd6e9e4: b.ne            #0xd6e9ec
    // 0xd6e9e8: r0 = "unix:path=/var/run/dbus/system_bus_socket"
    //     0xd6e9e8: ldr             x0, [PP, #0x790]  ; [pp+0x790] "unix:path=/var/run/dbus/system_bus_socket"
    // 0xd6e9ec: stp             x0, NULL, [SP, #-0x10]!
    // 0xd6e9f0: r0 = DBusAddress()
    //     0xd6e9f0: bl              #0xd6f040  ; [package:dbus/src/dbus_address.dart] DBusAddress::DBusAddress
    // 0xd6e9f4: add             SP, SP, #0x10
    // 0xd6e9f8: stur            x0, [fp, #-8]
    // 0xd6e9fc: r0 = DBusClient()
    //     0xd6e9fc: bl              #0xd6f034  ; AllocateDBusClientStub -> DBusClient (size=0x58)
    // 0xd6ea00: stur            x0, [fp, #-0x10]
    // 0xd6ea04: ldur            x16, [fp, #-8]
    // 0xd6ea08: stp             x16, x0, [SP, #-0x10]!
    // 0xd6ea0c: r0 = DBusClient()
    //     0xd6ea0c: bl              #0xd6ea2c  ; [package:dbus/src/dbus_client.dart] DBusClient::DBusClient
    // 0xd6ea10: add             SP, SP, #0x10
    // 0xd6ea14: ldur            x0, [fp, #-0x10]
    // 0xd6ea18: LeaveFrame
    //     0xd6ea18: mov             SP, fp
    //     0xd6ea1c: ldp             fp, lr, [SP], #0x10
    // 0xd6ea20: ret
    //     0xd6ea20: ret             
    // 0xd6ea24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6ea24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6ea28: b               #0xd6e9b8
  }
  _ DBusClient(/* No info */) {
    // ** addr: 0xd6ea2c, size: 0x2a4
    // 0xd6ea2c: EnterFrame
    //     0xd6ea2c: stp             fp, lr, [SP, #-0x10]!
    //     0xd6ea30: mov             fp, SP
    // 0xd6ea34: AllocStack(0x10)
    //     0xd6ea34: sub             SP, SP, #0x10
    // 0xd6ea38: r1 = false
    //     0xd6ea38: add             x1, NULL, #0x30  ; false
    // 0xd6ea3c: r0 = 0
    //     0xd6ea3c: mov             x0, #0
    // 0xd6ea40: CheckStackOverflow
    //     0xd6ea40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6ea44: cmp             SP, x16
    //     0xd6ea48: b.ls            #0xd6ecc8
    // 0xd6ea4c: ldr             x2, [fp, #0x18]
    // 0xd6ea50: StoreField: r2->field_f = r1
    //     0xd6ea50: stur            w1, [x2, #0xf]
    // 0xd6ea54: StoreField: r2->field_1b = r1
    //     0xd6ea54: stur            w1, [x2, #0x1b]
    // 0xd6ea58: StoreField: r2->field_23 = r0
    //     0xd6ea58: stur            x0, [x2, #0x23]
    // 0xd6ea5c: r0 = DBusReadBuffer()
    //     0xd6ea5c: bl              #0xd6ef90  ; AllocateDBusReadBufferStub -> DBusReadBuffer (size=0xa4)
    // 0xd6ea60: stur            x0, [fp, #-8]
    // 0xd6ea64: SaveReg r0
    //     0xd6ea64: str             x0, [SP, #-8]!
    // 0xd6ea68: r0 = DBusReadBuffer()
    //     0xd6ea68: bl              #0xd6eea4  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::DBusReadBuffer
    // 0xd6ea6c: add             SP, SP, #8
    // 0xd6ea70: ldur            x0, [fp, #-8]
    // 0xd6ea74: ldr             x1, [fp, #0x18]
    // 0xd6ea78: StoreField: r1->field_13 = r0
    //     0xd6ea78: stur            w0, [x1, #0x13]
    //     0xd6ea7c: ldurb           w16, [x1, #-1]
    //     0xd6ea80: ldurb           w17, [x0, #-1]
    //     0xd6ea84: and             x16, x17, x16, lsr #2
    //     0xd6ea88: tst             x16, HEAP, lsr #32
    //     0xd6ea8c: b.eq            #0xd6ea94
    //     0xd6ea90: bl              #0xd6826c
    // 0xd6ea94: r0 = DBusAuthClient()
    //     0xd6ea94: bl              #0xd6ee98  ; AllocateDBusAuthClientStub -> DBusAuthClient (size=0x1c)
    // 0xd6ea98: stur            x0, [fp, #-8]
    // 0xd6ea9c: SaveReg r0
    //     0xd6ea9c: str             x0, [SP, #-8]!
    // 0xd6eaa0: r0 = DBusAuthClient()
    //     0xd6eaa0: bl              #0xd6ed0c  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::DBusAuthClient
    // 0xd6eaa4: add             SP, SP, #8
    // 0xd6eaa8: ldur            x0, [fp, #-8]
    // 0xd6eaac: ldr             x1, [fp, #0x18]
    // 0xd6eab0: StoreField: r1->field_17 = r0
    //     0xd6eab0: stur            w0, [x1, #0x17]
    //     0xd6eab4: ldurb           w16, [x1, #-1]
    //     0xd6eab8: ldurb           w17, [x0, #-1]
    //     0xd6eabc: and             x16, x17, x16, lsr #2
    //     0xd6eac0: tst             x16, HEAP, lsr #32
    //     0xd6eac4: b.eq            #0xd6eacc
    //     0xd6eac8: bl              #0xd6826c
    // 0xd6eacc: r16 = <int, Completer<DBusMethodResponse>>
    //     0xd6eacc: ldr             x16, [PP, #0x798]  ; [pp+0x798] TypeArguments: <int, Completer<DBusMethodResponse>>
    // 0xd6ead0: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xd6ead4: stp             lr, x16, [SP, #-0x10]!
    // 0xd6ead8: r0 = Map._fromLiteral()
    //     0xd6ead8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xd6eadc: add             SP, SP, #0x10
    // 0xd6eae0: ldr             x1, [fp, #0x18]
    // 0xd6eae4: StoreField: r1->field_2b = r0
    //     0xd6eae4: stur            w0, [x1, #0x2b]
    //     0xd6eae8: tbz             w0, #0, #0xd6eb04
    //     0xd6eaec: ldurb           w16, [x1, #-1]
    //     0xd6eaf0: ldurb           w17, [x0, #-1]
    //     0xd6eaf4: and             x16, x17, x16, lsr #2
    //     0xd6eaf8: tst             x16, HEAP, lsr #32
    //     0xd6eafc: b.eq            #0xd6eb04
    //     0xd6eb00: bl              #0xd6826c
    // 0xd6eb04: r16 = <DBusSignalStream<DBusSignal>>
    //     0xd6eb04: ldr             x16, [PP, #0x7a0]  ; [pp+0x7a0] TypeArguments: <DBusSignalStream<DBusSignal>>
    // 0xd6eb08: stp             xzr, x16, [SP, #-0x10]!
    // 0xd6eb0c: r0 = _GrowableList()
    //     0xd6eb0c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xd6eb10: add             SP, SP, #0x10
    // 0xd6eb14: ldr             x1, [fp, #0x18]
    // 0xd6eb18: StoreField: r1->field_2f = r0
    //     0xd6eb18: stur            w0, [x1, #0x2f]
    //     0xd6eb1c: ldurb           w16, [x1, #-1]
    //     0xd6eb20: ldurb           w17, [x0, #-1]
    //     0xd6eb24: and             x16, x17, x16, lsr #2
    //     0xd6eb28: tst             x16, HEAP, lsr #32
    //     0xd6eb2c: b.eq            #0xd6eb34
    //     0xd6eb30: bl              #0xd6826c
    // 0xd6eb34: r16 = <String, DBusObjectTreeNode>
    //     0xd6eb34: ldr             x16, [PP, #0x7a8]  ; [pp+0x7a8] TypeArguments: <String, DBusObjectTreeNode>
    // 0xd6eb38: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xd6eb3c: stp             lr, x16, [SP, #-0x10]!
    // 0xd6eb40: r0 = Map._fromLiteral()
    //     0xd6eb40: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xd6eb44: add             SP, SP, #0x10
    // 0xd6eb48: stur            x0, [fp, #-8]
    // 0xd6eb4c: r0 = DBusObjectTreeNode()
    //     0xd6eb4c: bl              #0xd6ed00  ; AllocateDBusObjectTreeNodeStub -> DBusObjectTreeNode (size=0x10)
    // 0xd6eb50: mov             x1, x0
    // 0xd6eb54: ldur            x0, [fp, #-8]
    // 0xd6eb58: stur            x1, [fp, #-0x10]
    // 0xd6eb5c: StoreField: r1->field_b = r0
    //     0xd6eb5c: stur            w0, [x1, #0xb]
    // 0xd6eb60: r0 = DBusObjectTree()
    //     0xd6eb60: bl              #0xd6ecf4  ; AllocateDBusObjectTreeStub -> DBusObjectTree (size=0xc)
    // 0xd6eb64: mov             x1, x0
    // 0xd6eb68: ldur            x0, [fp, #-0x10]
    // 0xd6eb6c: StoreField: r1->field_7 = r0
    //     0xd6eb6c: stur            w0, [x1, #7]
    // 0xd6eb70: mov             x0, x1
    // 0xd6eb74: ldr             x1, [fp, #0x18]
    // 0xd6eb78: StoreField: r1->field_3f = r0
    //     0xd6eb78: stur            w0, [x1, #0x3f]
    //     0xd6eb7c: ldurb           w16, [x1, #-1]
    //     0xd6eb80: ldurb           w17, [x0, #-1]
    //     0xd6eb84: and             x16, x17, x16, lsr #2
    //     0xd6eb88: tst             x16, HEAP, lsr #32
    //     0xd6eb8c: b.eq            #0xd6eb94
    //     0xd6eb90: bl              #0xd6826c
    // 0xd6eb94: r16 = <String, int>
    //     0xd6eb94: ldr             x16, [PP, #0x7b0]  ; [pp+0x7b0] TypeArguments: <String, int>
    // 0xd6eb98: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xd6eb9c: stp             lr, x16, [SP, #-0x10]!
    // 0xd6eba0: r0 = Map._fromLiteral()
    //     0xd6eba0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xd6eba4: add             SP, SP, #0x10
    // 0xd6eba8: ldr             x1, [fp, #0x18]
    // 0xd6ebac: StoreField: r1->field_43 = r0
    //     0xd6ebac: stur            w0, [x1, #0x43]
    //     0xd6ebb0: tbz             w0, #0, #0xd6ebcc
    //     0xd6ebb4: ldurb           w16, [x1, #-1]
    //     0xd6ebb8: ldurb           w17, [x0, #-1]
    //     0xd6ebbc: and             x16, x17, x16, lsr #2
    //     0xd6ebc0: tst             x16, HEAP, lsr #32
    //     0xd6ebc4: b.eq            #0xd6ebcc
    //     0xd6ebc8: bl              #0xd6826c
    // 0xd6ebcc: r16 = <DBusBusName, DBusBusName>
    //     0xd6ebcc: ldr             x16, [PP, #0x7b8]  ; [pp+0x7b8] TypeArguments: <DBusBusName, DBusBusName>
    // 0xd6ebd0: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xd6ebd4: stp             lr, x16, [SP, #-0x10]!
    // 0xd6ebd8: r0 = Map._fromLiteral()
    //     0xd6ebd8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xd6ebdc: add             SP, SP, #0x10
    // 0xd6ebe0: ldr             x1, [fp, #0x18]
    // 0xd6ebe4: StoreField: r1->field_47 = r0
    //     0xd6ebe4: stur            w0, [x1, #0x47]
    //     0xd6ebe8: tbz             w0, #0, #0xd6ec04
    //     0xd6ebec: ldurb           w16, [x1, #-1]
    //     0xd6ebf0: ldurb           w17, [x0, #-1]
    //     0xd6ebf4: and             x16, x17, x16, lsr #2
    //     0xd6ebf8: tst             x16, HEAP, lsr #32
    //     0xd6ebfc: b.eq            #0xd6ec04
    //     0xd6ec00: bl              #0xd6826c
    // 0xd6ec04: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xd6ec04: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6ec08: ldr             x0, [x0, #0x598]
    //     0xd6ec0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6ec10: cmp             w0, w16
    //     0xd6ec14: b.ne            #0xd6ec20
    //     0xd6ec18: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xd6ec1c: bl              #0xd67cdc
    // 0xd6ec20: r1 = <DBusBusName>
    //     0xd6ec20: ldr             x1, [PP, #0x7c0]  ; [pp+0x7c0] TypeArguments: <DBusBusName>
    // 0xd6ec24: stur            x0, [fp, #-8]
    // 0xd6ec28: r0 = _Set()
    //     0xd6ec28: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xd6ec2c: mov             x1, x0
    // 0xd6ec30: ldur            x0, [fp, #-8]
    // 0xd6ec34: stur            x1, [fp, #-0x10]
    // 0xd6ec38: StoreField: r1->field_1b = r0
    //     0xd6ec38: stur            w0, [x1, #0x1b]
    // 0xd6ec3c: StoreField: r1->field_b = rZR
    //     0xd6ec3c: stur            wzr, [x1, #0xb]
    // 0xd6ec40: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xd6ec40: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6ec44: ldr             x0, [x0, #0x5a0]
    //     0xd6ec48: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6ec4c: cmp             w0, w16
    //     0xd6ec50: b.ne            #0xd6ec5c
    //     0xd6ec54: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xd6ec58: bl              #0xd67cdc
    // 0xd6ec5c: mov             x1, x0
    // 0xd6ec60: ldur            x0, [fp, #-0x10]
    // 0xd6ec64: StoreField: r0->field_f = r1
    //     0xd6ec64: stur            w1, [x0, #0xf]
    // 0xd6ec68: StoreField: r0->field_13 = rZR
    //     0xd6ec68: stur            wzr, [x0, #0x13]
    // 0xd6ec6c: StoreField: r0->field_17 = rZR
    //     0xd6ec6c: stur            wzr, [x0, #0x17]
    // 0xd6ec70: ldr             x1, [fp, #0x18]
    // 0xd6ec74: StoreField: r1->field_4b = r0
    //     0xd6ec74: stur            w0, [x1, #0x4b]
    //     0xd6ec78: ldurb           w16, [x1, #-1]
    //     0xd6ec7c: ldurb           w17, [x0, #-1]
    //     0xd6ec80: and             x16, x17, x16, lsr #2
    //     0xd6ec84: tst             x16, HEAP, lsr #32
    //     0xd6ec88: b.eq            #0xd6ec90
    //     0xd6ec8c: bl              #0xd6826c
    // 0xd6ec90: r2 = true
    //     0xd6ec90: add             x2, NULL, #0x20  ; true
    // 0xd6ec94: StoreField: r1->field_53 = r2
    //     0xd6ec94: stur            w2, [x1, #0x53]
    // 0xd6ec98: ldr             x0, [fp, #0x10]
    // 0xd6ec9c: StoreField: r1->field_7 = r0
    //     0xd6ec9c: stur            w0, [x1, #7]
    //     0xd6eca0: ldurb           w16, [x1, #-1]
    //     0xd6eca4: ldurb           w17, [x0, #-1]
    //     0xd6eca8: and             x16, x17, x16, lsr #2
    //     0xd6ecac: tst             x16, HEAP, lsr #32
    //     0xd6ecb0: b.eq            #0xd6ecb8
    //     0xd6ecb4: bl              #0xd6826c
    // 0xd6ecb8: r0 = Null
    //     0xd6ecb8: mov             x0, NULL
    // 0xd6ecbc: LeaveFrame
    //     0xd6ecbc: mov             SP, fp
    //     0xd6ecc0: ldp             fp, lr, [SP], #0x10
    // 0xd6ecc4: ret
    //     0xd6ecc4: ret             
    // 0xd6ecc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6ecc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6eccc: b               #0xd6ea4c
  }
}

// class id: 4624, size: 0x8, field offset: 0x8
class DBusClosedException extends Object
    implements Exception {
}

// class id: 4625, size: 0x14, field offset: 0x8
//   const constructor, 
class DBusNameOwnerChangedEvent extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xacfa04, size: 0x9c
    // 0xacfa04: EnterFrame
    //     0xacfa04: stp             fp, lr, [SP, #-0x10]!
    //     0xacfa08: mov             fp, SP
    // 0xacfa0c: CheckStackOverflow
    //     0xacfa0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacfa10: cmp             SP, x16
    //     0xacfa14: b.ls            #0xacfa98
    // 0xacfa18: r1 = Null
    //     0xacfa18: mov             x1, NULL
    // 0xacfa1c: r2 = 16
    //     0xacfa1c: mov             x2, #0x10
    // 0xacfa20: r0 = AllocateArray()
    //     0xacfa20: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacfa24: r17 = DBusNameOwnerChangedEvent
    //     0xacfa24: add             x17, PP, #0xb, lsl #12  ; [pp+0xb570] Type: DBusNameOwnerChangedEvent
    //     0xacfa28: ldr             x17, [x17, #0x570]
    // 0xacfa2c: StoreField: r0->field_f = r17
    //     0xacfa2c: stur            w17, [x0, #0xf]
    // 0xacfa30: r17 = "("
    //     0xacfa30: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xacfa34: StoreField: r0->field_13 = r17
    //     0xacfa34: stur            w17, [x0, #0x13]
    // 0xacfa38: ldr             x1, [fp, #0x10]
    // 0xacfa3c: LoadField: r2 = r1->field_7
    //     0xacfa3c: ldur            w2, [x1, #7]
    // 0xacfa40: DecompressPointer r2
    //     0xacfa40: add             x2, x2, HEAP, lsl #32
    // 0xacfa44: StoreField: r0->field_17 = r2
    //     0xacfa44: stur            w2, [x0, #0x17]
    // 0xacfa48: r17 = ", oldOwner: "
    //     0xacfa48: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] ", oldOwner: "
    //     0xacfa4c: ldr             x17, [x17, #0x578]
    // 0xacfa50: StoreField: r0->field_1b = r17
    //     0xacfa50: stur            w17, [x0, #0x1b]
    // 0xacfa54: LoadField: r2 = r1->field_b
    //     0xacfa54: ldur            w2, [x1, #0xb]
    // 0xacfa58: DecompressPointer r2
    //     0xacfa58: add             x2, x2, HEAP, lsl #32
    // 0xacfa5c: StoreField: r0->field_1f = r2
    //     0xacfa5c: stur            w2, [x0, #0x1f]
    // 0xacfa60: r17 = ", newOwner: "
    //     0xacfa60: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] ", newOwner: "
    //     0xacfa64: ldr             x17, [x17, #0x580]
    // 0xacfa68: StoreField: r0->field_23 = r17
    //     0xacfa68: stur            w17, [x0, #0x23]
    // 0xacfa6c: LoadField: r2 = r1->field_f
    //     0xacfa6c: ldur            w2, [x1, #0xf]
    // 0xacfa70: DecompressPointer r2
    //     0xacfa70: add             x2, x2, HEAP, lsl #32
    // 0xacfa74: StoreField: r0->field_27 = r2
    //     0xacfa74: stur            w2, [x0, #0x27]
    // 0xacfa78: r17 = ")"
    //     0xacfa78: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xacfa7c: StoreField: r0->field_2b = r17
    //     0xacfa7c: stur            w17, [x0, #0x2b]
    // 0xacfa80: SaveReg r0
    //     0xacfa80: str             x0, [SP, #-8]!
    // 0xacfa84: r0 = _interpolate()
    //     0xacfa84: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacfa88: add             SP, SP, #8
    // 0xacfa8c: LeaveFrame
    //     0xacfa8c: mov             SP, fp
    //     0xacfa90: ldp             fp, lr, [SP], #0x10
    // 0xacfa94: ret
    //     0xacfa94: ret             
    // 0xacfa98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacfa98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacfa9c: b               #0xacfa18
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e0f0, size: 0x118
    // 0xc6e0f0: EnterFrame
    //     0xc6e0f0: stp             fp, lr, [SP, #-0x10]!
    //     0xc6e0f4: mov             fp, SP
    // 0xc6e0f8: CheckStackOverflow
    //     0xc6e0f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6e0fc: cmp             SP, x16
    //     0xc6e100: b.ls            #0xc6e200
    // 0xc6e104: ldr             x1, [fp, #0x10]
    // 0xc6e108: cmp             w1, NULL
    // 0xc6e10c: b.ne            #0xc6e120
    // 0xc6e110: r0 = false
    //     0xc6e110: add             x0, NULL, #0x30  ; false
    // 0xc6e114: LeaveFrame
    //     0xc6e114: mov             SP, fp
    //     0xc6e118: ldp             fp, lr, [SP], #0x10
    // 0xc6e11c: ret
    //     0xc6e11c: ret             
    // 0xc6e120: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e120: mov             x0, #0x76
    //     0xc6e124: tbz             w1, #0, #0xc6e134
    //     0xc6e128: ldur            x0, [x1, #-1]
    //     0xc6e12c: ubfx            x0, x0, #0xc, #0x14
    //     0xc6e130: lsl             x0, x0, #1
    // 0xc6e134: r17 = 9250
    //     0xc6e134: mov             x17, #0x2422
    // 0xc6e138: cmp             w0, w17
    // 0xc6e13c: b.ne            #0xc6e1f0
    // 0xc6e140: ldr             x2, [fp, #0x18]
    // 0xc6e144: LoadField: r0 = r1->field_7
    //     0xc6e144: ldur            w0, [x1, #7]
    // 0xc6e148: DecompressPointer r0
    //     0xc6e148: add             x0, x0, HEAP, lsl #32
    // 0xc6e14c: LoadField: r3 = r2->field_7
    //     0xc6e14c: ldur            w3, [x2, #7]
    // 0xc6e150: DecompressPointer r3
    //     0xc6e150: add             x3, x3, HEAP, lsl #32
    // 0xc6e154: r4 = LoadClassIdInstr(r0)
    //     0xc6e154: ldur            x4, [x0, #-1]
    //     0xc6e158: ubfx            x4, x4, #0xc, #0x14
    // 0xc6e15c: stp             x3, x0, [SP, #-0x10]!
    // 0xc6e160: mov             x0, x4
    // 0xc6e164: mov             lr, x0
    // 0xc6e168: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e16c: blr             lr
    // 0xc6e170: add             SP, SP, #0x10
    // 0xc6e174: tbnz            w0, #4, #0xc6e1f0
    // 0xc6e178: ldr             x2, [fp, #0x18]
    // 0xc6e17c: ldr             x1, [fp, #0x10]
    // 0xc6e180: LoadField: r0 = r1->field_b
    //     0xc6e180: ldur            w0, [x1, #0xb]
    // 0xc6e184: DecompressPointer r0
    //     0xc6e184: add             x0, x0, HEAP, lsl #32
    // 0xc6e188: LoadField: r3 = r2->field_b
    //     0xc6e188: ldur            w3, [x2, #0xb]
    // 0xc6e18c: DecompressPointer r3
    //     0xc6e18c: add             x3, x3, HEAP, lsl #32
    // 0xc6e190: r4 = LoadClassIdInstr(r0)
    //     0xc6e190: ldur            x4, [x0, #-1]
    //     0xc6e194: ubfx            x4, x4, #0xc, #0x14
    // 0xc6e198: stp             x3, x0, [SP, #-0x10]!
    // 0xc6e19c: mov             x0, x4
    // 0xc6e1a0: mov             lr, x0
    // 0xc6e1a4: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e1a8: blr             lr
    // 0xc6e1ac: add             SP, SP, #0x10
    // 0xc6e1b0: tbnz            w0, #4, #0xc6e1f0
    // 0xc6e1b4: ldr             x1, [fp, #0x18]
    // 0xc6e1b8: ldr             x0, [fp, #0x10]
    // 0xc6e1bc: LoadField: r2 = r0->field_f
    //     0xc6e1bc: ldur            w2, [x0, #0xf]
    // 0xc6e1c0: DecompressPointer r2
    //     0xc6e1c0: add             x2, x2, HEAP, lsl #32
    // 0xc6e1c4: LoadField: r0 = r1->field_f
    //     0xc6e1c4: ldur            w0, [x1, #0xf]
    // 0xc6e1c8: DecompressPointer r0
    //     0xc6e1c8: add             x0, x0, HEAP, lsl #32
    // 0xc6e1cc: r1 = LoadClassIdInstr(r2)
    //     0xc6e1cc: ldur            x1, [x2, #-1]
    //     0xc6e1d0: ubfx            x1, x1, #0xc, #0x14
    // 0xc6e1d4: stp             x0, x2, [SP, #-0x10]!
    // 0xc6e1d8: mov             x0, x1
    // 0xc6e1dc: mov             lr, x0
    // 0xc6e1e0: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e1e4: blr             lr
    // 0xc6e1e8: add             SP, SP, #0x10
    // 0xc6e1ec: b               #0xc6e1f4
    // 0xc6e1f0: r0 = false
    //     0xc6e1f0: add             x0, NULL, #0x30  ; false
    // 0xc6e1f4: LeaveFrame
    //     0xc6e1f4: mov             SP, fp
    //     0xc6e1f8: ldp             fp, lr, [SP], #0x10
    // 0xc6e1fc: ret
    //     0xc6e1fc: ret             
    // 0xc6e200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6e200: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6e204: b               #0xc6e104
  }
}

// class id: 4626, size: 0x10, field offset: 0x8
class DBusSignalSignatureException extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0xacf980, size: 0x84
    // 0xacf980: EnterFrame
    //     0xacf980: stp             fp, lr, [SP, #-0x10]!
    //     0xacf984: mov             fp, SP
    // 0xacf988: AllocStack(0x8)
    //     0xacf988: sub             SP, SP, #8
    // 0xacf98c: CheckStackOverflow
    //     0xacf98c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf990: cmp             SP, x16
    //     0xacf994: b.ls            #0xacf9fc
    // 0xacf998: ldr             x0, [fp, #0x10]
    // 0xacf99c: LoadField: r3 = r0->field_7
    //     0xacf99c: ldur            w3, [x0, #7]
    // 0xacf9a0: DecompressPointer r3
    //     0xacf9a0: add             x3, x3, HEAP, lsl #32
    // 0xacf9a4: stur            x3, [fp, #-8]
    // 0xacf9a8: r1 = Null
    //     0xacf9a8: mov             x1, NULL
    // 0xacf9ac: r2 = 6
    //     0xacf9ac: mov             x2, #6
    // 0xacf9b0: r0 = AllocateArray()
    //     0xacf9b0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf9b4: mov             x1, x0
    // 0xacf9b8: ldur            x0, [fp, #-8]
    // 0xacf9bc: StoreField: r1->field_f = r0
    //     0xacf9bc: stur            w0, [x1, #0xf]
    // 0xacf9c0: r17 = " received with invalid values: "
    //     0xacf9c0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb588] " received with invalid values: "
    //     0xacf9c4: ldr             x17, [x17, #0x588]
    // 0xacf9c8: StoreField: r1->field_13 = r17
    //     0xacf9c8: stur            w17, [x1, #0x13]
    // 0xacf9cc: ldr             x0, [fp, #0x10]
    // 0xacf9d0: LoadField: r2 = r0->field_b
    //     0xacf9d0: ldur            w2, [x0, #0xb]
    // 0xacf9d4: DecompressPointer r2
    //     0xacf9d4: add             x2, x2, HEAP, lsl #32
    // 0xacf9d8: LoadField: r0 = r2->field_17
    //     0xacf9d8: ldur            w0, [x2, #0x17]
    // 0xacf9dc: DecompressPointer r0
    //     0xacf9dc: add             x0, x0, HEAP, lsl #32
    // 0xacf9e0: StoreField: r1->field_17 = r0
    //     0xacf9e0: stur            w0, [x1, #0x17]
    // 0xacf9e4: SaveReg r1
    //     0xacf9e4: str             x1, [SP, #-8]!
    // 0xacf9e8: r0 = _interpolate()
    //     0xacf9e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf9ec: add             SP, SP, #8
    // 0xacf9f0: LeaveFrame
    //     0xacf9f0: mov             SP, fp
    //     0xacf9f4: ldp             fp, lr, [SP], #0x10
    // 0xacf9f8: ret
    //     0xacf9f8: ret             
    // 0xacf9fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf9fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacfa00: b               #0xacf998
  }
}

// class id: 4627, size: 0x10, field offset: 0x8
class DBusReplySignatureException extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0xacf8fc, size: 0x84
    // 0xacf8fc: EnterFrame
    //     0xacf8fc: stp             fp, lr, [SP, #-0x10]!
    //     0xacf900: mov             fp, SP
    // 0xacf904: AllocStack(0x8)
    //     0xacf904: sub             SP, SP, #8
    // 0xacf908: CheckStackOverflow
    //     0xacf908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf90c: cmp             SP, x16
    //     0xacf910: b.ls            #0xacf978
    // 0xacf914: ldr             x0, [fp, #0x10]
    // 0xacf918: LoadField: r3 = r0->field_7
    //     0xacf918: ldur            w3, [x0, #7]
    // 0xacf91c: DecompressPointer r3
    //     0xacf91c: add             x3, x3, HEAP, lsl #32
    // 0xacf920: stur            x3, [fp, #-8]
    // 0xacf924: r1 = Null
    //     0xacf924: mov             x1, NULL
    // 0xacf928: r2 = 6
    //     0xacf928: mov             x2, #6
    // 0xacf92c: r0 = AllocateArray()
    //     0xacf92c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf930: mov             x1, x0
    // 0xacf934: ldur            x0, [fp, #-8]
    // 0xacf938: StoreField: r1->field_f = r0
    //     0xacf938: stur            w0, [x1, #0xf]
    // 0xacf93c: r17 = " returned invalid values: "
    //     0xacf93c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb568] " returned invalid values: "
    //     0xacf940: ldr             x17, [x17, #0x568]
    // 0xacf944: StoreField: r1->field_13 = r17
    //     0xacf944: stur            w17, [x1, #0x13]
    // 0xacf948: ldr             x0, [fp, #0x10]
    // 0xacf94c: LoadField: r2 = r0->field_b
    //     0xacf94c: ldur            w2, [x0, #0xb]
    // 0xacf950: DecompressPointer r2
    //     0xacf950: add             x2, x2, HEAP, lsl #32
    // 0xacf954: LoadField: r0 = r2->field_7
    //     0xacf954: ldur            w0, [x2, #7]
    // 0xacf958: DecompressPointer r0
    //     0xacf958: add             x0, x0, HEAP, lsl #32
    // 0xacf95c: StoreField: r1->field_17 = r0
    //     0xacf95c: stur            w0, [x1, #0x17]
    // 0xacf960: SaveReg r1
    //     0xacf960: str             x1, [SP, #-8]!
    // 0xacf964: r0 = _interpolate()
    //     0xacf964: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf968: add             SP, SP, #8
    // 0xacf96c: LeaveFrame
    //     0xacf96c: mov             SP, fp
    //     0xacf970: ldp             fp, lr, [SP], #0x10
    // 0xacf974: ret
    //     0xacf974: ret             
    // 0xacf978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf978: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf97c: b               #0xacf914
  }
}

// class id: 5627, size: 0x1c, field offset: 0xc
class DBusSignalStream extends Stream<DBusSignal> {

  _ DBusSignalStream(/* No info */) {
    // ** addr: 0xa02c18, size: 0x414
    // 0xa02c18: EnterFrame
    //     0xa02c18: stp             fp, lr, [SP, #-0x10]!
    //     0xa02c1c: mov             fp, SP
    // 0xa02c20: AllocStack(0x48)
    //     0xa02c20: sub             SP, SP, #0x48
    // 0xa02c24: SetupParameters(DBusSignalStream<DBusSignal> this /* r3, fp-0x40 */, dynamic _ /* r4, fp-0x38 */, dynamic _ /* r5, fp-0x30 */, {dynamic interface = Null /* r6, fp-0x28 */, dynamic name = Null /* r7, fp-0x20 */, dynamic path = Null /* r8, fp-0x18 */, dynamic pathNamespace = Null /* r9, fp-0x10 */, dynamic signature = Null /* r0, fp-0x8 */})
    //     0xa02c24: mov             x0, x4
    //     0xa02c28: ldur            w1, [x0, #0x13]
    //     0xa02c2c: add             x1, x1, HEAP, lsl #32
    //     0xa02c30: sub             x2, x1, #6
    //     0xa02c34: add             x3, fp, w2, sxtw #2
    //     0xa02c38: ldr             x3, [x3, #0x20]
    //     0xa02c3c: stur            x3, [fp, #-0x40]
    //     0xa02c40: add             x4, fp, w2, sxtw #2
    //     0xa02c44: ldr             x4, [x4, #0x18]
    //     0xa02c48: stur            x4, [fp, #-0x38]
    //     0xa02c4c: add             x5, fp, w2, sxtw #2
    //     0xa02c50: ldr             x5, [x5, #0x10]
    //     0xa02c54: stur            x5, [fp, #-0x30]
    //     0xa02c58: ldur            w2, [x0, #0x1f]
    //     0xa02c5c: add             x2, x2, HEAP, lsl #32
    //     0xa02c60: ldr             x16, [PP, #0x508]  ; [pp+0x508] "interface"
    //     0xa02c64: cmp             w2, w16
    //     0xa02c68: b.ne            #0xa02c8c
    //     0xa02c6c: ldur            w2, [x0, #0x23]
    //     0xa02c70: add             x2, x2, HEAP, lsl #32
    //     0xa02c74: sub             w6, w1, w2
    //     0xa02c78: add             x2, fp, w6, sxtw #2
    //     0xa02c7c: ldr             x2, [x2, #8]
    //     0xa02c80: mov             x6, x2
    //     0xa02c84: mov             x2, #1
    //     0xa02c88: b               #0xa02c94
    //     0xa02c8c: mov             x6, NULL
    //     0xa02c90: mov             x2, #0
    //     0xa02c94: stur            x6, [fp, #-0x28]
    //     0xa02c98: lsl             x7, x2, #1
    //     0xa02c9c: lsl             w8, w7, #1
    //     0xa02ca0: add             w9, w8, #8
    //     0xa02ca4: add             x16, x0, w9, sxtw #1
    //     0xa02ca8: ldur            w10, [x16, #0xf]
    //     0xa02cac: add             x10, x10, HEAP, lsl #32
    //     0xa02cb0: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    //     0xa02cb4: cmp             w10, w16
    //     0xa02cb8: b.ne            #0xa02cec
    //     0xa02cbc: add             w2, w8, #0xa
    //     0xa02cc0: add             x16, x0, w2, sxtw #1
    //     0xa02cc4: ldur            w8, [x16, #0xf]
    //     0xa02cc8: add             x8, x8, HEAP, lsl #32
    //     0xa02ccc: sub             w2, w1, w8
    //     0xa02cd0: add             x8, fp, w2, sxtw #2
    //     0xa02cd4: ldr             x8, [x8, #8]
    //     0xa02cd8: add             w2, w7, #2
    //     0xa02cdc: sbfx            x7, x2, #1, #0x1f
    //     0xa02ce0: mov             x2, x7
    //     0xa02ce4: mov             x7, x8
    //     0xa02ce8: b               #0xa02cf0
    //     0xa02cec: mov             x7, NULL
    //     0xa02cf0: stur            x7, [fp, #-0x20]
    //     0xa02cf4: lsl             x8, x2, #1
    //     0xa02cf8: lsl             w9, w8, #1
    //     0xa02cfc: add             w10, w9, #8
    //     0xa02d00: add             x16, x0, w10, sxtw #1
    //     0xa02d04: ldur            w11, [x16, #0xf]
    //     0xa02d08: add             x11, x11, HEAP, lsl #32
    //     0xa02d0c: ldr             x16, [PP, #0x518]  ; [pp+0x518] "path"
    //     0xa02d10: cmp             w11, w16
    //     0xa02d14: b.ne            #0xa02d48
    //     0xa02d18: add             w2, w9, #0xa
    //     0xa02d1c: add             x16, x0, w2, sxtw #1
    //     0xa02d20: ldur            w9, [x16, #0xf]
    //     0xa02d24: add             x9, x9, HEAP, lsl #32
    //     0xa02d28: sub             w2, w1, w9
    //     0xa02d2c: add             x9, fp, w2, sxtw #2
    //     0xa02d30: ldr             x9, [x9, #8]
    //     0xa02d34: add             w2, w8, #2
    //     0xa02d38: sbfx            x8, x2, #1, #0x1f
    //     0xa02d3c: mov             x2, x8
    //     0xa02d40: mov             x8, x9
    //     0xa02d44: b               #0xa02d4c
    //     0xa02d48: mov             x8, NULL
    //     0xa02d4c: stur            x8, [fp, #-0x18]
    //     0xa02d50: lsl             x9, x2, #1
    //     0xa02d54: lsl             w10, w9, #1
    //     0xa02d58: add             w11, w10, #8
    //     0xa02d5c: add             x16, x0, w11, sxtw #1
    //     0xa02d60: ldur            w12, [x16, #0xf]
    //     0xa02d64: add             x12, x12, HEAP, lsl #32
    //     0xa02d68: ldr             x16, [PP, #0x520]  ; [pp+0x520] "pathNamespace"
    //     0xa02d6c: cmp             w12, w16
    //     0xa02d70: b.ne            #0xa02da4
    //     0xa02d74: add             w2, w10, #0xa
    //     0xa02d78: add             x16, x0, w2, sxtw #1
    //     0xa02d7c: ldur            w10, [x16, #0xf]
    //     0xa02d80: add             x10, x10, HEAP, lsl #32
    //     0xa02d84: sub             w2, w1, w10
    //     0xa02d88: add             x10, fp, w2, sxtw #2
    //     0xa02d8c: ldr             x10, [x10, #8]
    //     0xa02d90: add             w2, w9, #2
    //     0xa02d94: sbfx            x9, x2, #1, #0x1f
    //     0xa02d98: mov             x2, x9
    //     0xa02d9c: mov             x9, x10
    //     0xa02da0: b               #0xa02da8
    //     0xa02da4: mov             x9, NULL
    //     0xa02da8: stur            x9, [fp, #-0x10]
    //     0xa02dac: lsl             x10, x2, #1
    //     0xa02db0: lsl             w2, w10, #1
    //     0xa02db4: add             w10, w2, #8
    //     0xa02db8: add             x16, x0, w10, sxtw #1
    //     0xa02dbc: ldur            w11, [x16, #0xf]
    //     0xa02dc0: add             x11, x11, HEAP, lsl #32
    //     0xa02dc4: ldr             x16, [PP, #0x528]  ; [pp+0x528] "signature"
    //     0xa02dc8: cmp             w11, w16
    //     0xa02dcc: b.ne            #0xa02df4
    //     0xa02dd0: add             w10, w2, #0xa
    //     0xa02dd4: add             x16, x0, w10, sxtw #1
    //     0xa02dd8: ldur            w2, [x16, #0xf]
    //     0xa02ddc: add             x2, x2, HEAP, lsl #32
    //     0xa02de0: sub             w0, w1, w2
    //     0xa02de4: add             x1, fp, w0, sxtw #2
    //     0xa02de8: ldr             x1, [x1, #8]
    //     0xa02dec: mov             x0, x1
    //     0xa02df0: b               #0xa02df8
    //     0xa02df4: mov             x0, NULL
    //     0xa02df8: stur            x0, [fp, #-8]
    // 0xa02dfc: CheckStackOverflow
    //     0xa02dfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa02e00: cmp             SP, x16
    //     0xa02e04: b.ls            #0xa03024
    // 0xa02e08: r16 = <DBusSignal>
    //     0xa02e08: ldr             x16, [PP, #0x398]  ; [pp+0x398] TypeArguments: <DBusSignal>
    // 0xa02e0c: SaveReg r16
    //     0xa02e0c: str             x16, [SP, #-8]!
    // 0xa02e10: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa02e10: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa02e14: r0 = StreamController.broadcast()
    //     0xa02e14: bl              #0x5a25d4  ; [dart:async] StreamController::StreamController.broadcast
    // 0xa02e18: add             SP, SP, #8
    // 0xa02e1c: mov             x2, x0
    // 0xa02e20: ldur            x1, [fp, #-0x40]
    // 0xa02e24: stur            x2, [fp, #-0x48]
    // 0xa02e28: StoreField: r1->field_17 = r0
    //     0xa02e28: stur            w0, [x1, #0x17]
    //     0xa02e2c: tbz             w0, #0, #0xa02e48
    //     0xa02e30: ldurb           w16, [x1, #-1]
    //     0xa02e34: ldurb           w17, [x0, #-1]
    //     0xa02e38: and             x16, x17, x16, lsr #2
    //     0xa02e3c: tst             x16, HEAP, lsr #32
    //     0xa02e40: b.eq            #0xa02e48
    //     0xa02e44: bl              #0xd6826c
    // 0xa02e48: ldur            x0, [fp, #-0x38]
    // 0xa02e4c: StoreField: r1->field_b = r0
    //     0xa02e4c: stur            w0, [x1, #0xb]
    //     0xa02e50: ldurb           w16, [x1, #-1]
    //     0xa02e54: ldurb           w17, [x0, #-1]
    //     0xa02e58: and             x16, x17, x16, lsr #2
    //     0xa02e5c: tst             x16, HEAP, lsr #32
    //     0xa02e60: b.eq            #0xa02e68
    //     0xa02e64: bl              #0xd6826c
    // 0xa02e68: r0 = DBusBusName()
    //     0xa02e68: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0xa02e6c: stur            x0, [fp, #-0x38]
    // 0xa02e70: ldur            x16, [fp, #-0x30]
    // 0xa02e74: stp             x16, x0, [SP, #-0x10]!
    // 0xa02e78: r0 = DBusBusName()
    //     0xa02e78: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0xa02e7c: add             SP, SP, #0x10
    // 0xa02e80: ldur            x0, [fp, #-0x28]
    // 0xa02e84: cmp             w0, NULL
    // 0xa02e88: b.eq            #0xa02eac
    // 0xa02e8c: r0 = DBusInterfaceName()
    //     0xa02e8c: bl              #0xa023bc  ; AllocateDBusInterfaceNameStub -> DBusInterfaceName (size=0xc)
    // 0xa02e90: stur            x0, [fp, #-0x30]
    // 0xa02e94: ldur            x16, [fp, #-0x28]
    // 0xa02e98: stp             x16, x0, [SP, #-0x10]!
    // 0xa02e9c: r0 = DBusInterfaceName()
    //     0xa02e9c: bl              #0xa0212c  ; [package:dbus/src/dbus_interface_name.dart] DBusInterfaceName::DBusInterfaceName
    // 0xa02ea0: add             SP, SP, #0x10
    // 0xa02ea4: ldur            x1, [fp, #-0x30]
    // 0xa02ea8: b               #0xa02eb0
    // 0xa02eac: r1 = Null
    //     0xa02eac: mov             x1, NULL
    // 0xa02eb0: ldur            x0, [fp, #-0x20]
    // 0xa02eb4: stur            x1, [fp, #-0x28]
    // 0xa02eb8: cmp             w0, NULL
    // 0xa02ebc: b.eq            #0xa02ee0
    // 0xa02ec0: r0 = DBusMemberName()
    //     0xa02ec0: bl              #0xa02120  ; AllocateDBusMemberNameStub -> DBusMemberName (size=0xc)
    // 0xa02ec4: stur            x0, [fp, #-0x30]
    // 0xa02ec8: ldur            x16, [fp, #-0x20]
    // 0xa02ecc: stp             x16, x0, [SP, #-0x10]!
    // 0xa02ed0: r0 = DBusMemberName()
    //     0xa02ed0: bl              #0xa0201c  ; [package:dbus/src/dbus_member_name.dart] DBusMemberName::DBusMemberName
    // 0xa02ed4: add             SP, SP, #0x10
    // 0xa02ed8: ldur            x6, [fp, #-0x30]
    // 0xa02edc: b               #0xa02ee4
    // 0xa02ee0: r6 = Null
    //     0xa02ee0: mov             x6, NULL
    // 0xa02ee4: ldur            x2, [fp, #-0x40]
    // 0xa02ee8: ldur            x4, [fp, #-0x18]
    // 0xa02eec: ldur            x5, [fp, #-0x10]
    // 0xa02ef0: ldur            x3, [fp, #-0x48]
    // 0xa02ef4: ldur            x1, [fp, #-0x38]
    // 0xa02ef8: ldur            x0, [fp, #-0x28]
    // 0xa02efc: stur            x6, [fp, #-0x20]
    // 0xa02f00: r0 = DBusMatchRule()
    //     0xa02f00: bl              #0xa03054  ; AllocateDBusMatchRuleStub -> DBusMatchRule (size=0x20)
    // 0xa02f04: mov             x1, x0
    // 0xa02f08: r0 = Instance_DBusMessageType
    //     0xa02f08: ldr             x0, [PP, #0x530]  ; [pp+0x530] Obj!DBusMessageType@b667b1
    // 0xa02f0c: StoreField: r1->field_7 = r0
    //     0xa02f0c: stur            w0, [x1, #7]
    // 0xa02f10: ldur            x0, [fp, #-0x38]
    // 0xa02f14: StoreField: r1->field_b = r0
    //     0xa02f14: stur            w0, [x1, #0xb]
    // 0xa02f18: ldur            x0, [fp, #-0x28]
    // 0xa02f1c: StoreField: r1->field_f = r0
    //     0xa02f1c: stur            w0, [x1, #0xf]
    // 0xa02f20: ldur            x0, [fp, #-0x20]
    // 0xa02f24: StoreField: r1->field_13 = r0
    //     0xa02f24: stur            w0, [x1, #0x13]
    // 0xa02f28: ldur            x0, [fp, #-0x18]
    // 0xa02f2c: StoreField: r1->field_17 = r0
    //     0xa02f2c: stur            w0, [x1, #0x17]
    // 0xa02f30: ldur            x0, [fp, #-0x10]
    // 0xa02f34: StoreField: r1->field_1b = r0
    //     0xa02f34: stur            w0, [x1, #0x1b]
    // 0xa02f38: mov             x0, x1
    // 0xa02f3c: ldur            x1, [fp, #-0x40]
    // 0xa02f40: StoreField: r1->field_f = r0
    //     0xa02f40: stur            w0, [x1, #0xf]
    //     0xa02f44: ldurb           w16, [x1, #-1]
    //     0xa02f48: ldurb           w17, [x0, #-1]
    //     0xa02f4c: and             x16, x17, x16, lsr #2
    //     0xa02f50: tst             x16, HEAP, lsr #32
    //     0xa02f54: b.eq            #0xa02f5c
    //     0xa02f58: bl              #0xd6826c
    // 0xa02f5c: ldur            x0, [fp, #-8]
    // 0xa02f60: StoreField: r1->field_13 = r0
    //     0xa02f60: stur            w0, [x1, #0x13]
    //     0xa02f64: ldurb           w16, [x1, #-1]
    //     0xa02f68: ldurb           w17, [x0, #-1]
    //     0xa02f6c: and             x16, x17, x16, lsr #2
    //     0xa02f70: tst             x16, HEAP, lsr #32
    //     0xa02f74: b.eq            #0xa02f7c
    //     0xa02f78: bl              #0xd6826c
    // 0xa02f7c: r0 = 59
    //     0xa02f7c: mov             x0, #0x3b
    // 0xa02f80: branchIfSmi(r1, 0xa02f8c)
    //     0xa02f80: tbz             w1, #0, #0xa02f8c
    // 0xa02f84: r0 = LoadClassIdInstr(r1)
    //     0xa02f84: ldur            x0, [x1, #-1]
    //     0xa02f88: ubfx            x0, x0, #0xc, #0x14
    // 0xa02f8c: SaveReg r1
    //     0xa02f8c: str             x1, [SP, #-8]!
    // 0xa02f90: r0 = GDT[cid_x0 + -0xc95]()
    //     0xa02f90: sub             lr, x0, #0xc95
    //     0xa02f94: ldr             lr, [x21, lr, lsl #3]
    //     0xa02f98: blr             lr
    // 0xa02f9c: add             SP, SP, #8
    // 0xa02fa0: ldur            x1, [fp, #-0x48]
    // 0xa02fa4: StoreField: r1->field_b = r0
    //     0xa02fa4: stur            w0, [x1, #0xb]
    //     0xa02fa8: tbz             w0, #0, #0xa02fc4
    //     0xa02fac: ldurb           w16, [x1, #-1]
    //     0xa02fb0: ldurb           w17, [x0, #-1]
    //     0xa02fb4: and             x16, x17, x16, lsr #2
    //     0xa02fb8: tst             x16, HEAP, lsr #32
    //     0xa02fbc: b.eq            #0xa02fc4
    //     0xa02fc0: bl              #0xd6826c
    // 0xa02fc4: ldur            x0, [fp, #-0x40]
    // 0xa02fc8: r2 = 59
    //     0xa02fc8: mov             x2, #0x3b
    // 0xa02fcc: branchIfSmi(r0, 0xa02fd8)
    //     0xa02fcc: tbz             w0, #0, #0xa02fd8
    // 0xa02fd0: r2 = LoadClassIdInstr(r0)
    //     0xa02fd0: ldur            x2, [x0, #-1]
    //     0xa02fd4: ubfx            x2, x2, #0xc, #0x14
    // 0xa02fd8: SaveReg r0
    //     0xa02fd8: str             x0, [SP, #-8]!
    // 0xa02fdc: mov             x0, x2
    // 0xa02fe0: r0 = GDT[cid_x0 + -0xc90]()
    //     0xa02fe0: sub             lr, x0, #0xc90
    //     0xa02fe4: ldr             lr, [x21, lr, lsl #3]
    //     0xa02fe8: blr             lr
    // 0xa02fec: add             SP, SP, #8
    // 0xa02ff0: ldur            x1, [fp, #-0x48]
    // 0xa02ff4: StoreField: r1->field_f = r0
    //     0xa02ff4: stur            w0, [x1, #0xf]
    //     0xa02ff8: tbz             w0, #0, #0xa03014
    //     0xa02ffc: ldurb           w16, [x1, #-1]
    //     0xa03000: ldurb           w17, [x0, #-1]
    //     0xa03004: and             x16, x17, x16, lsr #2
    //     0xa03008: tst             x16, HEAP, lsr #32
    //     0xa0300c: b.eq            #0xa03014
    //     0xa03010: bl              #0xd6826c
    // 0xa03014: r0 = Null
    //     0xa03014: mov             x0, NULL
    // 0xa03018: LeaveFrame
    //     0xa03018: mov             SP, fp
    //     0xa0301c: ldp             fp, lr, [SP], #0x10
    // 0xa03020: ret
    //     0xa03020: ret             
    // 0xa03024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa03024: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa03028: b               #0xa02e08
  }
  _ listen(/* No info */) {
    // ** addr: 0xc59fb0, size: 0x188
    // 0xc59fb0: EnterFrame
    //     0xc59fb0: stp             fp, lr, [SP, #-0x10]!
    //     0xc59fb4: mov             fp, SP
    // 0xc59fb8: AllocStack(0x28)
    //     0xc59fb8: sub             SP, SP, #0x28
    // 0xc59fbc: SetupParameters(DBusSignalStream<DBusSignal> this /* r3 */, dynamic _ /* r4, fp-0x28 */, {dynamic cancelOnError = Null /* r5, fp-0x20 */, dynamic onDone = Null /* r6, fp-0x18 */, dynamic onError = Null /* r0, fp-0x10 */})
    //     0xc59fbc: mov             x0, x4
    //     0xc59fc0: ldur            w1, [x0, #0x13]
    //     0xc59fc4: add             x1, x1, HEAP, lsl #32
    //     0xc59fc8: sub             x2, x1, #4
    //     0xc59fcc: add             x3, fp, w2, sxtw #2
    //     0xc59fd0: ldr             x3, [x3, #0x18]
    //     0xc59fd4: add             x4, fp, w2, sxtw #2
    //     0xc59fd8: ldr             x4, [x4, #0x10]
    //     0xc59fdc: stur            x4, [fp, #-0x28]
    //     0xc59fe0: ldur            w2, [x0, #0x1f]
    //     0xc59fe4: add             x2, x2, HEAP, lsl #32
    //     0xc59fe8: ldr             x16, [PP, #0x79e0]  ; [pp+0x79e0] "cancelOnError"
    //     0xc59fec: cmp             w2, w16
    //     0xc59ff0: b.ne            #0xc5a014
    //     0xc59ff4: ldur            w2, [x0, #0x23]
    //     0xc59ff8: add             x2, x2, HEAP, lsl #32
    //     0xc59ffc: sub             w5, w1, w2
    //     0xc5a000: add             x2, fp, w5, sxtw #2
    //     0xc5a004: ldr             x2, [x2, #8]
    //     0xc5a008: mov             x5, x2
    //     0xc5a00c: mov             x2, #1
    //     0xc5a010: b               #0xc5a01c
    //     0xc5a014: mov             x5, NULL
    //     0xc5a018: mov             x2, #0
    //     0xc5a01c: stur            x5, [fp, #-0x20]
    //     0xc5a020: lsl             x6, x2, #1
    //     0xc5a024: lsl             w7, w6, #1
    //     0xc5a028: add             w8, w7, #8
    //     0xc5a02c: add             x16, x0, w8, sxtw #1
    //     0xc5a030: ldur            w9, [x16, #0xf]
    //     0xc5a034: add             x9, x9, HEAP, lsl #32
    //     0xc5a038: ldr             x16, [PP, #0x79e8]  ; [pp+0x79e8] "onDone"
    //     0xc5a03c: cmp             w9, w16
    //     0xc5a040: b.ne            #0xc5a074
    //     0xc5a044: add             w2, w7, #0xa
    //     0xc5a048: add             x16, x0, w2, sxtw #1
    //     0xc5a04c: ldur            w7, [x16, #0xf]
    //     0xc5a050: add             x7, x7, HEAP, lsl #32
    //     0xc5a054: sub             w2, w1, w7
    //     0xc5a058: add             x7, fp, w2, sxtw #2
    //     0xc5a05c: ldr             x7, [x7, #8]
    //     0xc5a060: add             w2, w6, #2
    //     0xc5a064: sbfx            x6, x2, #1, #0x1f
    //     0xc5a068: mov             x2, x6
    //     0xc5a06c: mov             x6, x7
    //     0xc5a070: b               #0xc5a078
    //     0xc5a074: mov             x6, NULL
    //     0xc5a078: stur            x6, [fp, #-0x18]
    //     0xc5a07c: lsl             x7, x2, #1
    //     0xc5a080: lsl             w2, w7, #1
    //     0xc5a084: add             w7, w2, #8
    //     0xc5a088: add             x16, x0, w7, sxtw #1
    //     0xc5a08c: ldur            w8, [x16, #0xf]
    //     0xc5a090: add             x8, x8, HEAP, lsl #32
    //     0xc5a094: ldr             x16, [PP, #0x19a0]  ; [pp+0x19a0] "onError"
    //     0xc5a098: cmp             w8, w16
    //     0xc5a09c: b.ne            #0xc5a0c4
    //     0xc5a0a0: add             w7, w2, #0xa
    //     0xc5a0a4: add             x16, x0, w7, sxtw #1
    //     0xc5a0a8: ldur            w2, [x16, #0xf]
    //     0xc5a0ac: add             x2, x2, HEAP, lsl #32
    //     0xc5a0b0: sub             w0, w1, w2
    //     0xc5a0b4: add             x1, fp, w0, sxtw #2
    //     0xc5a0b8: ldr             x1, [x1, #8]
    //     0xc5a0bc: mov             x0, x1
    //     0xc5a0c0: b               #0xc5a0c8
    //     0xc5a0c4: mov             x0, NULL
    //     0xc5a0c8: stur            x0, [fp, #-0x10]
    // 0xc5a0cc: CheckStackOverflow
    //     0xc5a0cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5a0d0: cmp             SP, x16
    //     0xc5a0d4: b.ls            #0xc5a130
    // 0xc5a0d8: LoadField: r2 = r3->field_17
    //     0xc5a0d8: ldur            w2, [x3, #0x17]
    // 0xc5a0dc: DecompressPointer r2
    //     0xc5a0dc: add             x2, x2, HEAP, lsl #32
    // 0xc5a0e0: stur            x2, [fp, #-8]
    // 0xc5a0e4: LoadField: r1 = r2->field_7
    //     0xc5a0e4: ldur            w1, [x2, #7]
    // 0xc5a0e8: DecompressPointer r1
    //     0xc5a0e8: add             x1, x1, HEAP, lsl #32
    // 0xc5a0ec: r0 = _BroadcastStream()
    //     0xc5a0ec: bl              #0x5a25c8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x14)
    // 0xc5a0f0: mov             x1, x0
    // 0xc5a0f4: ldur            x0, [fp, #-8]
    // 0xc5a0f8: StoreField: r1->field_f = r0
    //     0xc5a0f8: stur            w0, [x1, #0xf]
    // 0xc5a0fc: ldur            x16, [fp, #-0x28]
    // 0xc5a100: stp             x16, x1, [SP, #-0x10]!
    // 0xc5a104: ldur            x16, [fp, #-0x10]
    // 0xc5a108: ldur            lr, [fp, #-0x18]
    // 0xc5a10c: stp             lr, x16, [SP, #-0x10]!
    // 0xc5a110: ldur            x16, [fp, #-0x20]
    // 0xc5a114: SaveReg r16
    //     0xc5a114: str             x16, [SP, #-8]!
    // 0xc5a118: r4 = const [0, 0x5, 0x5, 0x2, cancelOnError, 0x4, onDone, 0x3, onError, 0x2, null]
    //     0xc5a118: ldr             x4, [PP, #0x6868]  ; [pp+0x6868] List(11) [0, 0x5, 0x5, 0x2, "cancelOnError", 0x4, "onDone", 0x3, "onError", 0x2, Null]
    // 0xc5a11c: r0 = listen()
    //     0xc5a11c: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xc5a120: add             SP, SP, #0x28
    // 0xc5a124: LeaveFrame
    //     0xc5a124: mov             SP, fp
    //     0xc5a128: ldp             fp, lr, [SP], #0x10
    // 0xc5a12c: ret
    //     0xc5a12c: ret             
    // 0xc5a130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5a130: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5a134: b               #0xc5a0d8
  }
  dynamic _onCancel(dynamic) {
    // ** addr: 0xc971f8, size: 0x14
    // 0xc971f8: r4 = 7
    //     0xc971f8: mov             x4, #7
    // 0xc971fc: r1 = Function '_onCancel@299255221':.
    //     0xc971fc: ldr             x1, [PP, #0x76f0]  ; [pp+0x76f0] AnonymousClosure: (0xc9720c), in [package:dbus/src/dbus_client.dart] DBusSignalStream::_onCancel (0xc97254)
    // 0xc97200: r24 = BuildNonGenericMethodExtractorStub
    //     0xc97200: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xc97204: LoadField: r0 = r24->field_17
    //     0xc97204: ldur            x0, [x24, #0x17]
    // 0xc97208: br              x0
  }
  [closure] Future<void> _onCancel(dynamic) {
    // ** addr: 0xc9720c, size: 0x48
    // 0xc9720c: EnterFrame
    //     0xc9720c: stp             fp, lr, [SP, #-0x10]!
    //     0xc97210: mov             fp, SP
    // 0xc97214: ldr             x0, [fp, #0x10]
    // 0xc97218: LoadField: r1 = r0->field_17
    //     0xc97218: ldur            w1, [x0, #0x17]
    // 0xc9721c: DecompressPointer r1
    //     0xc9721c: add             x1, x1, HEAP, lsl #32
    // 0xc97220: CheckStackOverflow
    //     0xc97220: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc97224: cmp             SP, x16
    //     0xc97228: b.ls            #0xc9724c
    // 0xc9722c: LoadField: r0 = r1->field_f
    //     0xc9722c: ldur            w0, [x1, #0xf]
    // 0xc97230: DecompressPointer r0
    //     0xc97230: add             x0, x0, HEAP, lsl #32
    // 0xc97234: SaveReg r0
    //     0xc97234: str             x0, [SP, #-8]!
    // 0xc97238: r0 = _onCancel()
    //     0xc97238: bl              #0xc97254  ; [package:dbus/src/dbus_client.dart] DBusSignalStream::_onCancel
    // 0xc9723c: add             SP, SP, #8
    // 0xc97240: LeaveFrame
    //     0xc97240: mov             SP, fp
    //     0xc97244: ldp             fp, lr, [SP], #0x10
    // 0xc97248: ret
    //     0xc97248: ret             
    // 0xc9724c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9724c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc97250: b               #0xc9722c
  }
  _ _onCancel(/* No info */) async {
    // ** addr: 0xc97254, size: 0xa0
    // 0xc97254: EnterFrame
    //     0xc97254: stp             fp, lr, [SP, #-0x10]!
    //     0xc97258: mov             fp, SP
    // 0xc9725c: AllocStack(0x20)
    //     0xc9725c: sub             SP, SP, #0x20
    // 0xc97260: SetupParameters(DBusSignalStream<DBusSignal> this /* r1, fp-0x10 */)
    //     0xc97260: stur            NULL, [fp, #-8]
    //     0xc97264: mov             x0, #0
    //     0xc97268: add             x1, fp, w0, sxtw #2
    //     0xc9726c: ldr             x1, [x1, #0x10]
    //     0xc97270: stur            x1, [fp, #-0x10]
    // 0xc97274: CheckStackOverflow
    //     0xc97274: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc97278: cmp             SP, x16
    //     0xc9727c: b.ls            #0xc972ec
    // 0xc97280: InitAsync() -> Future<void?>
    //     0xc97280: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc97284: bl              #0x4b92e4
    // 0xc97288: ldur            x0, [fp, #-0x10]
    // 0xc9728c: LoadField: r1 = r0->field_b
    //     0xc9728c: ldur            w1, [x0, #0xb]
    // 0xc97290: DecompressPointer r1
    //     0xc97290: add             x1, x1, HEAP, lsl #32
    // 0xc97294: stur            x1, [fp, #-0x18]
    // 0xc97298: LoadField: r2 = r0->field_f
    //     0xc97298: ldur            w2, [x0, #0xf]
    // 0xc9729c: DecompressPointer r2
    //     0xc9729c: add             x2, x2, HEAP, lsl #32
    // 0xc972a0: SaveReg r2
    //     0xc972a0: str             x2, [SP, #-8]!
    // 0xc972a4: r0 = toDBusString()
    //     0xc972a4: bl              #0xc97504  ; [package:dbus/src/dbus_match_rule.dart] DBusMatchRule::toDBusString
    // 0xc972a8: add             SP, SP, #8
    // 0xc972ac: ldur            x16, [fp, #-0x18]
    // 0xc972b0: stp             x0, x16, [SP, #-0x10]!
    // 0xc972b4: r0 = _removeMatch()
    //     0xc972b4: bl              #0xc972f4  ; [package:dbus/src/dbus_client.dart] DBusClient::_removeMatch
    // 0xc972b8: add             SP, SP, #0x10
    // 0xc972bc: mov             x1, x0
    // 0xc972c0: stur            x1, [fp, #-0x20]
    // 0xc972c4: r0 = Await()
    //     0xc972c4: bl              #0x4b8e6c  ; AwaitStub
    // 0xc972c8: ldur            x0, [fp, #-0x18]
    // 0xc972cc: LoadField: r1 = r0->field_2f
    //     0xc972cc: ldur            w1, [x0, #0x2f]
    // 0xc972d0: DecompressPointer r1
    //     0xc972d0: add             x1, x1, HEAP, lsl #32
    // 0xc972d4: ldur            x16, [fp, #-0x10]
    // 0xc972d8: stp             x16, x1, [SP, #-0x10]!
    // 0xc972dc: r0 = remove()
    //     0xc972dc: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0xc972e0: add             SP, SP, #0x10
    // 0xc972e4: r0 = Null
    //     0xc972e4: mov             x0, NULL
    // 0xc972e8: r0 = ReturnAsyncNotFuture()
    //     0xc972e8: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc972ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc972ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc972f0: b               #0xc97280
  }
  dynamic _onListen(dynamic) {
    // ** addr: 0xc97a68, size: 0x18
    // 0xc97a68: r4 = 7
    //     0xc97a68: mov             x4, #7
    // 0xc97a6c: r1 = Function '_onListen@299255221':.
    //     0xc97a6c: add             x17, PP, #8, lsl #12  ; [pp+0x87d8] AnonymousClosure: (0xc97a80), in [package:dbus/src/dbus_client.dart] DBusSignalStream::_onListen (0xc97ac8)
    //     0xc97a70: ldr             x1, [x17, #0x7d8]
    // 0xc97a74: r24 = BuildNonGenericMethodExtractorStub
    //     0xc97a74: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xc97a78: LoadField: r0 = r24->field_17
    //     0xc97a78: ldur            x0, [x24, #0x17]
    // 0xc97a7c: br              x0
  }
  [closure] void _onListen(dynamic) {
    // ** addr: 0xc97a80, size: 0x48
    // 0xc97a80: EnterFrame
    //     0xc97a80: stp             fp, lr, [SP, #-0x10]!
    //     0xc97a84: mov             fp, SP
    // 0xc97a88: ldr             x0, [fp, #0x10]
    // 0xc97a8c: LoadField: r1 = r0->field_17
    //     0xc97a8c: ldur            w1, [x0, #0x17]
    // 0xc97a90: DecompressPointer r1
    //     0xc97a90: add             x1, x1, HEAP, lsl #32
    // 0xc97a94: CheckStackOverflow
    //     0xc97a94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc97a98: cmp             SP, x16
    //     0xc97a9c: b.ls            #0xc97ac0
    // 0xc97aa0: LoadField: r0 = r1->field_f
    //     0xc97aa0: ldur            w0, [x1, #0xf]
    // 0xc97aa4: DecompressPointer r0
    //     0xc97aa4: add             x0, x0, HEAP, lsl #32
    // 0xc97aa8: SaveReg r0
    //     0xc97aa8: str             x0, [SP, #-8]!
    // 0xc97aac: r0 = _onListen()
    //     0xc97aac: bl              #0xc97ac8  ; [package:dbus/src/dbus_client.dart] DBusSignalStream::_onListen
    // 0xc97ab0: add             SP, SP, #8
    // 0xc97ab4: LeaveFrame
    //     0xc97ab4: mov             SP, fp
    //     0xc97ab8: ldp             fp, lr, [SP], #0x10
    // 0xc97abc: ret
    //     0xc97abc: ret             
    // 0xc97ac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc97ac0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc97ac4: b               #0xc97aa0
  }
  _ _onListen(/* No info */) {
    // ** addr: 0xc97ac8, size: 0x128
    // 0xc97ac8: EnterFrame
    //     0xc97ac8: stp             fp, lr, [SP, #-0x10]!
    //     0xc97acc: mov             fp, SP
    // 0xc97ad0: AllocStack(0x18)
    //     0xc97ad0: sub             SP, SP, #0x18
    // 0xc97ad4: CheckStackOverflow
    //     0xc97ad4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc97ad8: cmp             SP, x16
    //     0xc97adc: b.ls            #0xc97be4
    // 0xc97ae0: ldr             x0, [fp, #0x10]
    // 0xc97ae4: LoadField: r1 = r0->field_b
    //     0xc97ae4: ldur            w1, [x0, #0xb]
    // 0xc97ae8: DecompressPointer r1
    //     0xc97ae8: add             x1, x1, HEAP, lsl #32
    // 0xc97aec: stur            x1, [fp, #-0x18]
    // 0xc97af0: LoadField: r2 = r1->field_2f
    //     0xc97af0: ldur            w2, [x1, #0x2f]
    // 0xc97af4: DecompressPointer r2
    //     0xc97af4: add             x2, x2, HEAP, lsl #32
    // 0xc97af8: stur            x2, [fp, #-0x10]
    // 0xc97afc: LoadField: r3 = r2->field_b
    //     0xc97afc: ldur            w3, [x2, #0xb]
    // 0xc97b00: DecompressPointer r3
    //     0xc97b00: add             x3, x3, HEAP, lsl #32
    // 0xc97b04: stur            x3, [fp, #-8]
    // 0xc97b08: LoadField: r4 = r2->field_f
    //     0xc97b08: ldur            w4, [x2, #0xf]
    // 0xc97b0c: DecompressPointer r4
    //     0xc97b0c: add             x4, x4, HEAP, lsl #32
    // 0xc97b10: LoadField: r5 = r4->field_b
    //     0xc97b10: ldur            w5, [x4, #0xb]
    // 0xc97b14: DecompressPointer r5
    //     0xc97b14: add             x5, x5, HEAP, lsl #32
    // 0xc97b18: cmp             w3, w5
    // 0xc97b1c: b.ne            #0xc97b2c
    // 0xc97b20: SaveReg r2
    //     0xc97b20: str             x2, [SP, #-8]!
    // 0xc97b24: r0 = _growToNextCapacity()
    //     0xc97b24: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc97b28: add             SP, SP, #8
    // 0xc97b2c: ldr             x2, [fp, #0x10]
    // 0xc97b30: ldur            x3, [fp, #-0x10]
    // 0xc97b34: ldur            x0, [fp, #-8]
    // 0xc97b38: r4 = LoadInt32Instr(r0)
    //     0xc97b38: sbfx            x4, x0, #1, #0x1f
    // 0xc97b3c: add             x0, x4, #1
    // 0xc97b40: lsl             x1, x0, #1
    // 0xc97b44: StoreField: r3->field_b = r1
    //     0xc97b44: stur            w1, [x3, #0xb]
    // 0xc97b48: mov             x1, x4
    // 0xc97b4c: cmp             x1, x0
    // 0xc97b50: b.hs            #0xc97bec
    // 0xc97b54: LoadField: r1 = r3->field_f
    //     0xc97b54: ldur            w1, [x3, #0xf]
    // 0xc97b58: DecompressPointer r1
    //     0xc97b58: add             x1, x1, HEAP, lsl #32
    // 0xc97b5c: mov             x0, x2
    // 0xc97b60: ArrayStore: r1[r4] = r0  ; List_4
    //     0xc97b60: add             x25, x1, x4, lsl #2
    //     0xc97b64: add             x25, x25, #0xf
    //     0xc97b68: str             w0, [x25]
    //     0xc97b6c: tbz             w0, #0, #0xc97b88
    //     0xc97b70: ldurb           w16, [x1, #-1]
    //     0xc97b74: ldurb           w17, [x0, #-1]
    //     0xc97b78: and             x16, x17, x16, lsr #2
    //     0xc97b7c: tst             x16, HEAP, lsr #32
    //     0xc97b80: b.eq            #0xc97b88
    //     0xc97b84: bl              #0xd67e5c
    // 0xc97b88: LoadField: r0 = r2->field_f
    //     0xc97b88: ldur            w0, [x2, #0xf]
    // 0xc97b8c: DecompressPointer r0
    //     0xc97b8c: add             x0, x0, HEAP, lsl #32
    // 0xc97b90: stur            x0, [fp, #-8]
    // 0xc97b94: LoadField: r1 = r0->field_b
    //     0xc97b94: ldur            w1, [x0, #0xb]
    // 0xc97b98: DecompressPointer r1
    //     0xc97b98: add             x1, x1, HEAP, lsl #32
    // 0xc97b9c: cmp             w1, NULL
    // 0xc97ba0: b.eq            #0xc97bb4
    // 0xc97ba4: ldur            x16, [fp, #-0x18]
    // 0xc97ba8: stp             x1, x16, [SP, #-0x10]!
    // 0xc97bac: r0 = _findUniqueName()
    //     0xc97bac: bl              #0xc97dd8  ; [package:dbus/src/dbus_client.dart] DBusClient::_findUniqueName
    // 0xc97bb0: add             SP, SP, #0x10
    // 0xc97bb4: ldur            x16, [fp, #-8]
    // 0xc97bb8: SaveReg r16
    //     0xc97bb8: str             x16, [SP, #-8]!
    // 0xc97bbc: r0 = toDBusString()
    //     0xc97bbc: bl              #0xc97504  ; [package:dbus/src/dbus_match_rule.dart] DBusMatchRule::toDBusString
    // 0xc97bc0: add             SP, SP, #8
    // 0xc97bc4: ldur            x16, [fp, #-0x18]
    // 0xc97bc8: stp             x0, x16, [SP, #-0x10]!
    // 0xc97bcc: r0 = _addMatch()
    //     0xc97bcc: bl              #0xc97bf0  ; [package:dbus/src/dbus_client.dart] DBusClient::_addMatch
    // 0xc97bd0: add             SP, SP, #0x10
    // 0xc97bd4: r0 = Null
    //     0xc97bd4: mov             x0, NULL
    // 0xc97bd8: LeaveFrame
    //     0xc97bd8: mov             SP, fp
    //     0xc97bdc: ldp             fp, lr, [SP], #0x10
    // 0xc97be0: ret
    //     0xc97be0: ret             
    // 0xc97be4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc97be4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc97be8: b               #0xc97ae0
    // 0xc97bec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc97bec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

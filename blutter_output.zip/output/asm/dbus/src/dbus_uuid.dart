// lib: , url: package:dbus/src/dbus_uuid.dart

// class id: 1048853, size: 0x8
class :: {
}

// class id: 4584, size: 0xc, field offset: 0x8
class DBusUUID extends Object {

  _ DBusUUID.fromHexString(/* No info */) {
    // ** addr: 0xa0c5c0, size: 0x1c8
    // 0xa0c5c0: EnterFrame
    //     0xa0c5c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa0c5c4: mov             fp, SP
    // 0xa0c5c8: AllocStack(0x10)
    //     0xa0c5c8: sub             SP, SP, #0x10
    // 0xa0c5cc: r0 = Sentinel
    //     0xa0c5cc: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0c5d0: CheckStackOverflow
    //     0xa0c5d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0c5d4: cmp             SP, x16
    //     0xa0c5d8: b.ls            #0xa0c778
    // 0xa0c5dc: ldr             x1, [fp, #0x18]
    // 0xa0c5e0: StoreField: r1->field_7 = r0
    //     0xa0c5e0: stur            w0, [x1, #7]
    // 0xa0c5e4: r16 = "^[0-9a-fA-F]{32}$"
    //     0xa0c5e4: add             x16, PP, #8, lsl #12  ; [pp+0x8268] "^[0-9a-fA-F]{32}$"
    //     0xa0c5e8: ldr             x16, [x16, #0x268]
    // 0xa0c5ec: stp             x16, NULL, [SP, #-0x10]!
    // 0xa0c5f0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0c5f0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0c5f4: r0 = RegExp()
    //     0xa0c5f4: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0xa0c5f8: add             SP, SP, #0x10
    // 0xa0c5fc: ldr             x1, [fp, #0x10]
    // 0xa0c600: r2 = LoadClassIdInstr(r1)
    //     0xa0c600: ldur            x2, [x1, #-1]
    //     0xa0c604: ubfx            x2, x2, #0xc, #0x14
    // 0xa0c608: stp             x0, x1, [SP, #-0x10]!
    // 0xa0c60c: mov             x0, x2
    // 0xa0c610: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0c610: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0c614: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa0c614: sub             lr, x0, #0xffc
    //     0xa0c618: ldr             lr, [x21, lr, lsl #3]
    //     0xa0c61c: blr             lr
    // 0xa0c620: add             SP, SP, #0x10
    // 0xa0c624: tbnz            w0, #4, #0xa0c758
    // 0xa0c628: r1 = <int>
    //     0xa0c628: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xa0c62c: r2 = 32
    //     0xa0c62c: mov             x2, #0x20
    // 0xa0c630: r0 = AllocateArray()
    //     0xa0c630: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0c634: mov             x2, x0
    // 0xa0c638: stur            x2, [fp, #-0x10]
    // 0xa0c63c: r3 = 0
    //     0xa0c63c: mov             x3, #0
    // 0xa0c640: stur            x3, [fp, #-8]
    // 0xa0c644: CheckStackOverflow
    //     0xa0c644: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0c648: cmp             SP, x16
    //     0xa0c64c: b.ls            #0xa0c780
    // 0xa0c650: cmp             x3, #0x10
    // 0xa0c654: b.ge            #0xa0c6f4
    // 0xa0c658: lsl             x4, x3, #1
    // 0xa0c65c: add             x5, x4, #2
    // 0xa0c660: r0 = BoxInt64Instr(r5)
    //     0xa0c660: sbfiz           x0, x5, #1, #0x1f
    //     0xa0c664: cmp             x5, x0, asr #1
    //     0xa0c668: b.eq            #0xa0c674
    //     0xa0c66c: bl              #0xd69bb8
    //     0xa0c670: stur            x5, [x0, #7]
    // 0xa0c674: ldr             x16, [fp, #0x10]
    // 0xa0c678: stp             x4, x16, [SP, #-0x10]!
    // 0xa0c67c: SaveReg r0
    //     0xa0c67c: str             x0, [SP, #-8]!
    // 0xa0c680: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa0c680: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa0c684: r0 = substring()
    //     0xa0c684: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xa0c688: add             SP, SP, #0x18
    // 0xa0c68c: r16 = 32
    //     0xa0c68c: mov             x16, #0x20
    // 0xa0c690: stp             x16, x0, [SP, #-0x10]!
    // 0xa0c694: r4 = const [0, 0x2, 0x2, 0x1, radix, 0x1, null]
    //     0xa0c694: ldr             x4, [PP, #0xa50]  ; [pp+0xa50] List(7) [0, 0x2, 0x2, 0x1, "radix", 0x1, Null]
    // 0xa0c698: r0 = parse()
    //     0xa0c698: bl              #0x4d5d84  ; [dart:core] int::parse
    // 0xa0c69c: add             SP, SP, #0x10
    // 0xa0c6a0: mov             x2, x0
    // 0xa0c6a4: r0 = BoxInt64Instr(r2)
    //     0xa0c6a4: sbfiz           x0, x2, #1, #0x1f
    //     0xa0c6a8: cmp             x2, x0, asr #1
    //     0xa0c6ac: b.eq            #0xa0c6b8
    //     0xa0c6b0: bl              #0xd69bb8
    //     0xa0c6b4: stur            x2, [x0, #7]
    // 0xa0c6b8: ldur            x1, [fp, #-0x10]
    // 0xa0c6bc: ldur            x2, [fp, #-8]
    // 0xa0c6c0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xa0c6c0: add             x25, x1, x2, lsl #2
    //     0xa0c6c4: add             x25, x25, #0xf
    //     0xa0c6c8: str             w0, [x25]
    //     0xa0c6cc: tbz             w0, #0, #0xa0c6e8
    //     0xa0c6d0: ldurb           w16, [x1, #-1]
    //     0xa0c6d4: ldurb           w17, [x0, #-1]
    //     0xa0c6d8: and             x16, x17, x16, lsr #2
    //     0xa0c6dc: tst             x16, HEAP, lsr #32
    //     0xa0c6e0: b.eq            #0xa0c6e8
    //     0xa0c6e4: bl              #0xd67e5c
    // 0xa0c6e8: add             x3, x2, #1
    // 0xa0c6ec: ldur            x2, [fp, #-0x10]
    // 0xa0c6f0: b               #0xa0c640
    // 0xa0c6f4: ldr             x0, [fp, #0x18]
    // 0xa0c6f8: LoadField: r1 = r0->field_7
    //     0xa0c6f8: ldur            w1, [x0, #7]
    // 0xa0c6fc: DecompressPointer r1
    //     0xa0c6fc: add             x1, x1, HEAP, lsl #32
    // 0xa0c700: r16 = Sentinel
    //     0xa0c700: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0c704: cmp             w1, w16
    // 0xa0c708: b.ne            #0xa0c714
    // 0xa0c70c: mov             x1, x0
    // 0xa0c710: b               #0xa0c728
    // 0xa0c714: r16 = "value"
    //     0xa0c714: ldr             x16, [PP, #0x408]  ; [pp+0x408] "value"
    // 0xa0c718: SaveReg r16
    //     0xa0c718: str             x16, [SP, #-8]!
    // 0xa0c71c: r0 = _throwFieldAlreadyInitialized()
    //     0xa0c71c: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xa0c720: add             SP, SP, #8
    // 0xa0c724: ldr             x1, [fp, #0x18]
    // 0xa0c728: ldur            x0, [fp, #-0x10]
    // 0xa0c72c: StoreField: r1->field_7 = r0
    //     0xa0c72c: stur            w0, [x1, #7]
    //     0xa0c730: ldurb           w16, [x1, #-1]
    //     0xa0c734: ldurb           w17, [x0, #-1]
    //     0xa0c738: and             x16, x17, x16, lsr #2
    //     0xa0c73c: tst             x16, HEAP, lsr #32
    //     0xa0c740: b.eq            #0xa0c748
    //     0xa0c744: bl              #0xd6826c
    // 0xa0c748: r0 = Null
    //     0xa0c748: mov             x0, NULL
    // 0xa0c74c: LeaveFrame
    //     0xa0c74c: mov             SP, fp
    //     0xa0c750: ldp             fp, lr, [SP], #0x10
    // 0xa0c754: ret
    //     0xa0c754: ret             
    // 0xa0c758: r0 = FormatException()
    //     0xa0c758: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa0c75c: mov             x1, x0
    // 0xa0c760: r0 = "Invalid UUID"
    //     0xa0c760: add             x0, PP, #8, lsl #12  ; [pp+0x8270] "Invalid UUID"
    //     0xa0c764: ldr             x0, [x0, #0x270]
    // 0xa0c768: StoreField: r1->field_7 = r0
    //     0xa0c768: stur            w0, [x1, #7]
    // 0xa0c76c: mov             x0, x1
    // 0xa0c770: r0 = Throw()
    //     0xa0c770: bl              #0xd67e38  ; ThrowStub
    // 0xa0c774: brk             #0
    // 0xa0c778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0c778: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0c77c: b               #0xa0c5dc
    // 0xa0c780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0c780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0c784: b               #0xa0c650
  }
}

// lib: , url: package:dbus/src/dbus_method_response.dart

// class id: 1048842, size: 0x8
class :: {
}

// class id: 4591, size: 0xc, field offset: 0x8
class DBusMethodResponseException extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0xad0ef0, size: 0x224
    // 0xad0ef0: EnterFrame
    //     0xad0ef0: stp             fp, lr, [SP, #-0x10]!
    //     0xad0ef4: mov             fp, SP
    // 0xad0ef8: AllocStack(0x18)
    //     0xad0ef8: sub             SP, SP, #0x18
    // 0xad0efc: CheckStackOverflow
    //     0xad0efc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad0f00: cmp             SP, x16
    //     0xad0f04: b.ls            #0xad110c
    // 0xad0f08: ldr             x0, [fp, #0x10]
    // 0xad0f0c: LoadField: r1 = r0->field_7
    //     0xad0f0c: ldur            w1, [x0, #7]
    // 0xad0f10: DecompressPointer r1
    //     0xad0f10: add             x1, x1, HEAP, lsl #32
    // 0xad0f14: stur            x1, [fp, #-8]
    // 0xad0f18: LoadField: r0 = r1->field_b
    //     0xad0f18: ldur            w0, [x1, #0xb]
    // 0xad0f1c: DecompressPointer r0
    //     0xad0f1c: add             x0, x0, HEAP, lsl #32
    // 0xad0f20: r2 = LoadClassIdInstr(r0)
    //     0xad0f20: ldur            x2, [x0, #-1]
    //     0xad0f24: ubfx            x2, x2, #0xc, #0x14
    // 0xad0f28: SaveReg r0
    //     0xad0f28: str             x0, [SP, #-8]!
    // 0xad0f2c: mov             x0, x2
    // 0xad0f30: r0 = GDT[cid_x0 + 0xccd1]()
    //     0xad0f30: mov             x17, #0xccd1
    //     0xad0f34: add             lr, x0, x17
    //     0xad0f38: ldr             lr, [x21, lr, lsl #3]
    //     0xad0f3c: blr             lr
    // 0xad0f40: add             SP, SP, #8
    // 0xad0f44: tbnz            w0, #4, #0xad0f60
    // 0xad0f48: ldur            x1, [fp, #-8]
    // 0xad0f4c: LoadField: r0 = r1->field_7
    //     0xad0f4c: ldur            w0, [x1, #7]
    // 0xad0f50: DecompressPointer r0
    //     0xad0f50: add             x0, x0, HEAP, lsl #32
    // 0xad0f54: LeaveFrame
    //     0xad0f54: mov             SP, fp
    //     0xad0f58: ldp             fp, lr, [SP], #0x10
    // 0xad0f5c: ret
    //     0xad0f5c: ret             
    // 0xad0f60: ldur            x1, [fp, #-8]
    // 0xad0f64: LoadField: r0 = r1->field_b
    //     0xad0f64: ldur            w0, [x1, #0xb]
    // 0xad0f68: DecompressPointer r0
    //     0xad0f68: add             x0, x0, HEAP, lsl #32
    // 0xad0f6c: r2 = LoadClassIdInstr(r0)
    //     0xad0f6c: ldur            x2, [x0, #-1]
    //     0xad0f70: ubfx            x2, x2, #0xc, #0x14
    // 0xad0f74: SaveReg r0
    //     0xad0f74: str             x0, [SP, #-8]!
    // 0xad0f78: mov             x0, x2
    // 0xad0f7c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xad0f7c: mov             x17, #0xb8ea
    //     0xad0f80: add             lr, x0, x17
    //     0xad0f84: ldr             lr, [x21, lr, lsl #3]
    //     0xad0f88: blr             lr
    // 0xad0f8c: add             SP, SP, #8
    // 0xad0f90: cmp             w0, #2
    // 0xad0f94: b.ne            #0xad105c
    // 0xad0f98: ldur            x0, [fp, #-8]
    // 0xad0f9c: LoadField: r3 = r0->field_7
    //     0xad0f9c: ldur            w3, [x0, #7]
    // 0xad0fa0: DecompressPointer r3
    //     0xad0fa0: add             x3, x3, HEAP, lsl #32
    // 0xad0fa4: stur            x3, [fp, #-0x10]
    // 0xad0fa8: r1 = Null
    //     0xad0fa8: mov             x1, NULL
    // 0xad0fac: r2 = 6
    //     0xad0fac: mov             x2, #6
    // 0xad0fb0: r0 = AllocateArray()
    //     0xad0fb0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0fb4: mov             x1, x0
    // 0xad0fb8: ldur            x0, [fp, #-0x10]
    // 0xad0fbc: stur            x1, [fp, #-0x18]
    // 0xad0fc0: StoreField: r1->field_f = r0
    //     0xad0fc0: stur            w0, [x1, #0xf]
    // 0xad0fc4: r17 = ": "
    //     0xad0fc4: ldr             x17, [PP, #0xf48]  ; [pp+0xf48] ": "
    // 0xad0fc8: StoreField: r1->field_13 = r17
    //     0xad0fc8: stur            w17, [x1, #0x13]
    // 0xad0fcc: ldur            x0, [fp, #-8]
    // 0xad0fd0: LoadField: r2 = r0->field_b
    //     0xad0fd0: ldur            w2, [x0, #0xb]
    // 0xad0fd4: DecompressPointer r2
    //     0xad0fd4: add             x2, x2, HEAP, lsl #32
    // 0xad0fd8: r0 = LoadClassIdInstr(r2)
    //     0xad0fd8: ldur            x0, [x2, #-1]
    //     0xad0fdc: ubfx            x0, x0, #0xc, #0x14
    // 0xad0fe0: SaveReg r2
    //     0xad0fe0: str             x2, [SP, #-8]!
    // 0xad0fe4: r0 = GDT[cid_x0 + 0xcaae]()
    //     0xad0fe4: mov             x17, #0xcaae
    //     0xad0fe8: add             lr, x0, x17
    //     0xad0fec: ldr             lr, [x21, lr, lsl #3]
    //     0xad0ff0: blr             lr
    // 0xad0ff4: add             SP, SP, #8
    // 0xad0ff8: r1 = LoadClassIdInstr(r0)
    //     0xad0ff8: ldur            x1, [x0, #-1]
    //     0xad0ffc: ubfx            x1, x1, #0xc, #0x14
    // 0xad1000: SaveReg r0
    //     0xad1000: str             x0, [SP, #-8]!
    // 0xad1004: mov             x0, x1
    // 0xad1008: r0 = GDT[cid_x0 + 0x872]()
    //     0xad1008: add             lr, x0, #0x872
    //     0xad100c: ldr             lr, [x21, lr, lsl #3]
    //     0xad1010: blr             lr
    // 0xad1014: add             SP, SP, #8
    // 0xad1018: ldur            x1, [fp, #-0x18]
    // 0xad101c: ArrayStore: r1[2] = r0  ; List_4
    //     0xad101c: add             x25, x1, #0x17
    //     0xad1020: str             w0, [x25]
    //     0xad1024: tbz             w0, #0, #0xad1040
    //     0xad1028: ldurb           w16, [x1, #-1]
    //     0xad102c: ldurb           w17, [x0, #-1]
    //     0xad1030: and             x16, x17, x16, lsr #2
    //     0xad1034: tst             x16, HEAP, lsr #32
    //     0xad1038: b.eq            #0xad1040
    //     0xad103c: bl              #0xd67e5c
    // 0xad1040: ldur            x16, [fp, #-0x18]
    // 0xad1044: SaveReg r16
    //     0xad1044: str             x16, [SP, #-8]!
    // 0xad1048: r0 = _interpolate()
    //     0xad1048: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad104c: add             SP, SP, #8
    // 0xad1050: LeaveFrame
    //     0xad1050: mov             SP, fp
    //     0xad1054: ldp             fp, lr, [SP], #0x10
    // 0xad1058: ret
    //     0xad1058: ret             
    // 0xad105c: ldur            x0, [fp, #-8]
    // 0xad1060: LoadField: r3 = r0->field_7
    //     0xad1060: ldur            w3, [x0, #7]
    // 0xad1064: DecompressPointer r3
    //     0xad1064: add             x3, x3, HEAP, lsl #32
    // 0xad1068: stur            x3, [fp, #-0x10]
    // 0xad106c: r1 = Null
    //     0xad106c: mov             x1, NULL
    // 0xad1070: r2 = 6
    //     0xad1070: mov             x2, #6
    // 0xad1074: r0 = AllocateArray()
    //     0xad1074: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad1078: mov             x3, x0
    // 0xad107c: ldur            x0, [fp, #-0x10]
    // 0xad1080: stur            x3, [fp, #-0x18]
    // 0xad1084: StoreField: r3->field_f = r0
    //     0xad1084: stur            w0, [x3, #0xf]
    // 0xad1088: r17 = ": "
    //     0xad1088: ldr             x17, [PP, #0xf48]  ; [pp+0xf48] ": "
    // 0xad108c: StoreField: r3->field_13 = r17
    //     0xad108c: stur            w17, [x3, #0x13]
    // 0xad1090: ldur            x0, [fp, #-8]
    // 0xad1094: LoadField: r4 = r0->field_b
    //     0xad1094: ldur            w4, [x0, #0xb]
    // 0xad1098: DecompressPointer r4
    //     0xad1098: add             x4, x4, HEAP, lsl #32
    // 0xad109c: stur            x4, [fp, #-0x10]
    // 0xad10a0: r1 = Function '<anonymous closure>':.
    //     0xad10a0: add             x1, PP, #0xb, lsl #12  ; [pp+0xb4f8] AnonymousClosure: (0xad1114), in [package:dbus/src/dbus_method_response.dart] DBusMethodResponseException::toString (0xad0ef0)
    //     0xad10a4: ldr             x1, [x1, #0x4f8]
    // 0xad10a8: r2 = Null
    //     0xad10a8: mov             x2, NULL
    // 0xad10ac: r0 = AllocateClosure()
    //     0xad10ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad10b0: ldur            x16, [fp, #-0x10]
    // 0xad10b4: stp             x16, NULL, [SP, #-0x10]!
    // 0xad10b8: SaveReg r0
    //     0xad10b8: str             x0, [SP, #-8]!
    // 0xad10bc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad10bc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad10c0: r0 = map()
    //     0xad10c0: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad10c4: add             SP, SP, #0x18
    // 0xad10c8: ldur            x1, [fp, #-0x18]
    // 0xad10cc: ArrayStore: r1[2] = r0  ; List_4
    //     0xad10cc: add             x25, x1, #0x17
    //     0xad10d0: str             w0, [x25]
    //     0xad10d4: tbz             w0, #0, #0xad10f0
    //     0xad10d8: ldurb           w16, [x1, #-1]
    //     0xad10dc: ldurb           w17, [x0, #-1]
    //     0xad10e0: and             x16, x17, x16, lsr #2
    //     0xad10e4: tst             x16, HEAP, lsr #32
    //     0xad10e8: b.eq            #0xad10f0
    //     0xad10ec: bl              #0xd67e5c
    // 0xad10f0: ldur            x16, [fp, #-0x18]
    // 0xad10f4: SaveReg r16
    //     0xad10f4: str             x16, [SP, #-8]!
    // 0xad10f8: r0 = _interpolate()
    //     0xad10f8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad10fc: add             SP, SP, #8
    // 0xad1100: LeaveFrame
    //     0xad1100: mov             SP, fp
    //     0xad1104: ldp             fp, lr, [SP], #0x10
    // 0xad1108: ret
    //     0xad1108: ret             
    // 0xad110c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad110c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1110: b               #0xad0f08
  }
  [closure] dynamic <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xad1114, size: 0x4c
    // 0xad1114: EnterFrame
    //     0xad1114: stp             fp, lr, [SP, #-0x10]!
    //     0xad1118: mov             fp, SP
    // 0xad111c: CheckStackOverflow
    //     0xad111c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad1120: cmp             SP, x16
    //     0xad1124: b.ls            #0xad1158
    // 0xad1128: ldr             x0, [fp, #0x10]
    // 0xad112c: r1 = LoadClassIdInstr(r0)
    //     0xad112c: ldur            x1, [x0, #-1]
    //     0xad1130: ubfx            x1, x1, #0xc, #0x14
    // 0xad1134: SaveReg r0
    //     0xad1134: str             x0, [SP, #-8]!
    // 0xad1138: mov             x0, x1
    // 0xad113c: r0 = GDT[cid_x0 + 0x872]()
    //     0xad113c: add             lr, x0, #0x872
    //     0xad1140: ldr             lr, [x21, lr, lsl #3]
    //     0xad1144: blr             lr
    // 0xad1148: add             SP, SP, #8
    // 0xad114c: LeaveFrame
    //     0xad114c: mov             SP, fp
    //     0xad1150: ldp             fp, lr, [SP], #0x10
    // 0xad1154: ret
    //     0xad1154: ret             
    // 0xad1158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad1158: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad115c: b               #0xad1128
  }
}

// class id: 4592, size: 0xc, field offset: 0xc
class DBusErrorException extends DBusMethodResponseException {
}

// class id: 4593, size: 0xc, field offset: 0xc
class DBusAuthFailedException extends DBusErrorException {
}

// class id: 4594, size: 0xc, field offset: 0xc
class DBusAccessDeniedException extends DBusErrorException {
}

// class id: 4595, size: 0xc, field offset: 0xc
class DBusNotSupportedException extends DBusErrorException {
}

// class id: 4596, size: 0xc, field offset: 0xc
class DBusPropertyWriteOnlyException extends DBusErrorException {
}

// class id: 4597, size: 0xc, field offset: 0xc
class DBusPropertyReadOnlyException extends DBusErrorException {
}

// class id: 4598, size: 0xc, field offset: 0xc
class DBusUnknownPropertyException extends DBusErrorException {
}

// class id: 4599, size: 0xc, field offset: 0xc
class DBusInvalidArgsException extends DBusErrorException {
}

// class id: 4600, size: 0xc, field offset: 0xc
class DBusTimedOutException extends DBusErrorException {
}

// class id: 4601, size: 0xc, field offset: 0xc
class DBusTimeoutException extends DBusErrorException {
}

// class id: 4602, size: 0xc, field offset: 0xc
class DBusUnknownMethodException extends DBusErrorException {
}

// class id: 4603, size: 0xc, field offset: 0xc
class DBusUnknownInterfaceException extends DBusErrorException {
}

// class id: 4604, size: 0xc, field offset: 0xc
class DBusUnknownObjectException extends DBusErrorException {
}

// class id: 4605, size: 0xc, field offset: 0xc
class DBusServiceUnknownException extends DBusErrorException {
}

// class id: 4606, size: 0xc, field offset: 0xc
class DBusFailedException extends DBusErrorException {
}

// class id: 4607, size: 0x8, field offset: 0x8
abstract class DBusMethodResponse extends Object {

  get _ signature(/* No info */) {
    // ** addr: 0x9fec98, size: 0xac
    // 0x9fec98: EnterFrame
    //     0x9fec98: stp             fp, lr, [SP, #-0x10]!
    //     0x9fec9c: mov             fp, SP
    // 0x9feca0: AllocStack(0x10)
    //     0x9feca0: sub             SP, SP, #0x10
    // 0x9feca4: CheckStackOverflow
    //     0x9feca4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9feca8: cmp             SP, x16
    //     0x9fecac: b.ls            #0x9fed3c
    // 0x9fecb0: ldr             x0, [fp, #0x10]
    // 0x9fecb4: LoadField: r3 = r0->field_7
    //     0x9fecb4: ldur            w3, [x0, #7]
    // 0x9fecb8: DecompressPointer r3
    //     0x9fecb8: add             x3, x3, HEAP, lsl #32
    // 0x9fecbc: stur            x3, [fp, #-8]
    // 0x9fecc0: r1 = Function '<anonymous closure>':.
    //     0x9fecc0: ldr             x1, [PP, #0x77d8]  ; [pp+0x77d8] AnonymousClosure: (0x9feffc), in [package:dbus/src/dbus_signal.dart] DBusSignal::signature (0x9fef50)
    // 0x9fecc4: r2 = Null
    //     0x9fecc4: mov             x2, NULL
    // 0x9fecc8: r0 = AllocateClosure()
    //     0x9fecc8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9feccc: r16 = <DBusSignature>
    //     0x9feccc: ldr             x16, [PP, #0x4c0]  ; [pp+0x4c0] TypeArguments: <DBusSignature>
    // 0x9fecd0: ldur            lr, [fp, #-8]
    // 0x9fecd4: stp             lr, x16, [SP, #-0x10]!
    // 0x9fecd8: SaveReg r0
    //     0x9fecd8: str             x0, [SP, #-8]!
    // 0x9fecdc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9fecdc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9fece0: r0 = map()
    //     0x9fece0: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x9fece4: add             SP, SP, #0x18
    // 0x9fece8: stur            x0, [fp, #-8]
    // 0x9fecec: r0 = DBusSignature()
    //     0x9fecec: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0x9fecf0: stur            x0, [fp, #-0x10]
    // 0x9fecf4: r16 = ""
    //     0x9fecf4: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x9fecf8: stp             x16, x0, [SP, #-0x10]!
    // 0x9fecfc: r0 = DBusSignature()
    //     0x9fecfc: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0x9fed00: add             SP, SP, #0x10
    // 0x9fed04: r1 = Function '<anonymous closure>':.
    //     0x9fed04: ldr             x1, [PP, #0x77e0]  ; [pp+0x77e0] AnonymousClosure: (0x9fef14), in [package:dbus/src/dbus_signal.dart] DBusSignal::signature (0x9fef50)
    // 0x9fed08: r2 = Null
    //     0x9fed08: mov             x2, NULL
    // 0x9fed0c: r0 = AllocateClosure()
    //     0x9fed0c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9fed10: r16 = <DBusSignature>
    //     0x9fed10: ldr             x16, [PP, #0x4c0]  ; [pp+0x4c0] TypeArguments: <DBusSignature>
    // 0x9fed14: ldur            lr, [fp, #-8]
    // 0x9fed18: stp             lr, x16, [SP, #-0x10]!
    // 0x9fed1c: ldur            x16, [fp, #-0x10]
    // 0x9fed20: stp             x0, x16, [SP, #-0x10]!
    // 0x9fed24: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x9fed24: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x9fed28: r0 = fold()
    //     0x9fed28: bl              #0x9fed6c  ; [dart:_internal] ListIterable::fold
    // 0x9fed2c: add             SP, SP, #0x20
    // 0x9fed30: LeaveFrame
    //     0x9fed30: mov             SP, fp
    //     0x9fed34: ldp             fp, lr, [SP], #0x10
    // 0x9fed38: ret
    //     0x9fed38: ret             
    // 0x9fed3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fed3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fed40: b               #0x9fecb0
  }
}

// class id: 4608, size: 0x10, field offset: 0x8
class DBusMethodErrorResponse extends DBusMethodResponse {

  _ toString(/* No info */) {
    // ** addr: 0xad0e70, size: 0x80
    // 0xad0e70: EnterFrame
    //     0xad0e70: stp             fp, lr, [SP, #-0x10]!
    //     0xad0e74: mov             fp, SP
    // 0xad0e78: CheckStackOverflow
    //     0xad0e78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad0e7c: cmp             SP, x16
    //     0xad0e80: b.ls            #0xad0ee8
    // 0xad0e84: r1 = Null
    //     0xad0e84: mov             x1, NULL
    // 0xad0e88: r2 = 12
    //     0xad0e88: mov             x2, #0xc
    // 0xad0e8c: r0 = AllocateArray()
    //     0xad0e8c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0e90: r17 = DBusMethodErrorResponse
    //     0xad0e90: add             x17, PP, #0xb, lsl #12  ; [pp+0xb500] Type: DBusMethodErrorResponse
    //     0xad0e94: ldr             x17, [x17, #0x500]
    // 0xad0e98: StoreField: r0->field_f = r17
    //     0xad0e98: stur            w17, [x0, #0xf]
    // 0xad0e9c: r17 = "("
    //     0xad0e9c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad0ea0: StoreField: r0->field_13 = r17
    //     0xad0ea0: stur            w17, [x0, #0x13]
    // 0xad0ea4: ldr             x1, [fp, #0x10]
    // 0xad0ea8: LoadField: r2 = r1->field_7
    //     0xad0ea8: ldur            w2, [x1, #7]
    // 0xad0eac: DecompressPointer r2
    //     0xad0eac: add             x2, x2, HEAP, lsl #32
    // 0xad0eb0: StoreField: r0->field_17 = r2
    //     0xad0eb0: stur            w2, [x0, #0x17]
    // 0xad0eb4: r17 = ", "
    //     0xad0eb4: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad0eb8: StoreField: r0->field_1b = r17
    //     0xad0eb8: stur            w17, [x0, #0x1b]
    // 0xad0ebc: LoadField: r2 = r1->field_b
    //     0xad0ebc: ldur            w2, [x1, #0xb]
    // 0xad0ec0: DecompressPointer r2
    //     0xad0ec0: add             x2, x2, HEAP, lsl #32
    // 0xad0ec4: StoreField: r0->field_1f = r2
    //     0xad0ec4: stur            w2, [x0, #0x1f]
    // 0xad0ec8: r17 = ")"
    //     0xad0ec8: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad0ecc: StoreField: r0->field_23 = r17
    //     0xad0ecc: stur            w17, [x0, #0x23]
    // 0xad0ed0: SaveReg r0
    //     0xad0ed0: str             x0, [SP, #-8]!
    // 0xad0ed4: r0 = _interpolate()
    //     0xad0ed4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad0ed8: add             SP, SP, #8
    // 0xad0edc: LeaveFrame
    //     0xad0edc: mov             SP, fp
    //     0xad0ee0: ldp             fp, lr, [SP], #0x10
    // 0xad0ee4: ret
    //     0xad0ee4: ret             
    // 0xad0ee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad0ee8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad0eec: b               #0xad0e84
  }
}

// class id: 4609, size: 0xc, field offset: 0x8
class DBusMethodSuccessResponse extends DBusMethodResponse {

  _ toString(/* No info */) {
    // ** addr: 0xad0e04, size: 0x6c
    // 0xad0e04: EnterFrame
    //     0xad0e04: stp             fp, lr, [SP, #-0x10]!
    //     0xad0e08: mov             fp, SP
    // 0xad0e0c: CheckStackOverflow
    //     0xad0e0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad0e10: cmp             SP, x16
    //     0xad0e14: b.ls            #0xad0e68
    // 0xad0e18: r1 = Null
    //     0xad0e18: mov             x1, NULL
    // 0xad0e1c: r2 = 8
    //     0xad0e1c: mov             x2, #8
    // 0xad0e20: r0 = AllocateArray()
    //     0xad0e20: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0e24: r17 = DBusMethodSuccessResponse
    //     0xad0e24: add             x17, PP, #0xb, lsl #12  ; [pp+0xb508] Type: DBusMethodSuccessResponse
    //     0xad0e28: ldr             x17, [x17, #0x508]
    // 0xad0e2c: StoreField: r0->field_f = r17
    //     0xad0e2c: stur            w17, [x0, #0xf]
    // 0xad0e30: r17 = "("
    //     0xad0e30: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad0e34: StoreField: r0->field_13 = r17
    //     0xad0e34: stur            w17, [x0, #0x13]
    // 0xad0e38: ldr             x1, [fp, #0x10]
    // 0xad0e3c: LoadField: r2 = r1->field_7
    //     0xad0e3c: ldur            w2, [x1, #7]
    // 0xad0e40: DecompressPointer r2
    //     0xad0e40: add             x2, x2, HEAP, lsl #32
    // 0xad0e44: StoreField: r0->field_17 = r2
    //     0xad0e44: stur            w2, [x0, #0x17]
    // 0xad0e48: r17 = ")"
    //     0xad0e48: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad0e4c: StoreField: r0->field_1b = r17
    //     0xad0e4c: stur            w17, [x0, #0x1b]
    // 0xad0e50: SaveReg r0
    //     0xad0e50: str             x0, [SP, #-8]!
    // 0xad0e54: r0 = _interpolate()
    //     0xad0e54: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad0e58: add             SP, SP, #8
    // 0xad0e5c: LeaveFrame
    //     0xad0e5c: mov             SP, fp
    //     0xad0e60: ldp             fp, lr, [SP], #0x10
    // 0xad0e64: ret
    //     0xad0e64: ret             
    // 0xad0e68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad0e68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad0e6c: b               #0xad0e18
  }
}

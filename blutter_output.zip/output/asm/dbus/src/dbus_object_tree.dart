// lib: , url: package:dbus/src/dbus_object_tree.dart

// class id: 1048845, size: 0x8
class :: {
}

// class id: 4588, size: 0x10, field offset: 0x8
class DBusObjectTreeNode extends Object {
}

// class id: 4589, size: 0xc, field offset: 0x8
class DBusObjectTree extends Object {

  _ lookup(/* No info */) {
    // ** addr: 0xa07694, size: 0x1e4
    // 0xa07694: EnterFrame
    //     0xa07694: stp             fp, lr, [SP, #-0x10]!
    //     0xa07698: mov             fp, SP
    // 0xa0769c: AllocStack(0x40)
    //     0xa0769c: sub             SP, SP, #0x40
    // 0xa076a0: CheckStackOverflow
    //     0xa076a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa076a4: cmp             SP, x16
    //     0xa076a8: b.ls            #0xa07868
    // 0xa076ac: ldr             x0, [fp, #0x18]
    // 0xa076b0: LoadField: r1 = r0->field_7
    //     0xa076b0: ldur            w1, [x0, #7]
    // 0xa076b4: DecompressPointer r1
    //     0xa076b4: add             x1, x1, HEAP, lsl #32
    // 0xa076b8: stur            x1, [fp, #-8]
    // 0xa076bc: ldr             x16, [fp, #0x10]
    // 0xa076c0: SaveReg r16
    //     0xa076c0: str             x16, [SP, #-8]!
    // 0xa076c4: r0 = split()
    //     0xa076c4: bl              #0x9fcdb8  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::split
    // 0xa076c8: add             SP, SP, #8
    // 0xa076cc: mov             x1, x0
    // 0xa076d0: stur            x1, [fp, #-0x28]
    // 0xa076d4: LoadField: r2 = r1->field_7
    //     0xa076d4: ldur            w2, [x1, #7]
    // 0xa076d8: DecompressPointer r2
    //     0xa076d8: add             x2, x2, HEAP, lsl #32
    // 0xa076dc: stur            x2, [fp, #-0x20]
    // 0xa076e0: LoadField: r0 = r1->field_b
    //     0xa076e0: ldur            w0, [x1, #0xb]
    // 0xa076e4: DecompressPointer r0
    //     0xa076e4: add             x0, x0, HEAP, lsl #32
    // 0xa076e8: r3 = LoadInt32Instr(r0)
    //     0xa076e8: sbfx            x3, x0, #1, #0x1f
    // 0xa076ec: stur            x3, [fp, #-0x18]
    // 0xa076f0: ldur            x5, [fp, #-8]
    // 0xa076f4: r4 = 0
    //     0xa076f4: mov             x4, #0
    // 0xa076f8: stur            x5, [fp, #-8]
    // 0xa076fc: stur            x4, [fp, #-0x10]
    // 0xa07700: CheckStackOverflow
    //     0xa07700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa07704: cmp             SP, x16
    //     0xa07708: b.ls            #0xa07870
    // 0xa0770c: r0 = LoadClassIdInstr(r1)
    //     0xa0770c: ldur            x0, [x1, #-1]
    //     0xa07710: ubfx            x0, x0, #0xc, #0x14
    // 0xa07714: SaveReg r1
    //     0xa07714: str             x1, [SP, #-8]!
    // 0xa07718: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa07718: mov             x17, #0xb8ea
    //     0xa0771c: add             lr, x0, x17
    //     0xa07720: ldr             lr, [x21, lr, lsl #3]
    //     0xa07724: blr             lr
    // 0xa07728: add             SP, SP, #8
    // 0xa0772c: r1 = LoadInt32Instr(r0)
    //     0xa0772c: sbfx            x1, x0, #1, #0x1f
    //     0xa07730: tbz             w0, #0, #0xa07738
    //     0xa07734: ldur            x1, [x0, #7]
    // 0xa07738: ldur            x2, [fp, #-0x18]
    // 0xa0773c: cmp             x2, x1
    // 0xa07740: b.ne            #0xa07850
    // 0xa07744: ldur            x3, [fp, #-0x28]
    // 0xa07748: ldur            x4, [fp, #-0x10]
    // 0xa0774c: cmp             x4, x1
    // 0xa07750: b.lt            #0xa07764
    // 0xa07754: ldur            x0, [fp, #-8]
    // 0xa07758: LeaveFrame
    //     0xa07758: mov             SP, fp
    //     0xa0775c: ldp             fp, lr, [SP], #0x10
    // 0xa07760: ret
    //     0xa07760: ret             
    // 0xa07764: r0 = BoxInt64Instr(r4)
    //     0xa07764: sbfiz           x0, x4, #1, #0x1f
    //     0xa07768: cmp             x4, x0, asr #1
    //     0xa0776c: b.eq            #0xa07778
    //     0xa07770: bl              #0xd69bb8
    //     0xa07774: stur            x4, [x0, #7]
    // 0xa07778: r1 = LoadClassIdInstr(r3)
    //     0xa07778: ldur            x1, [x3, #-1]
    //     0xa0777c: ubfx            x1, x1, #0xc, #0x14
    // 0xa07780: stp             x0, x3, [SP, #-0x10]!
    // 0xa07784: mov             x0, x1
    // 0xa07788: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa07788: mov             x17, #0xd175
    //     0xa0778c: add             lr, x0, x17
    //     0xa07790: ldr             lr, [x21, lr, lsl #3]
    //     0xa07794: blr             lr
    // 0xa07798: add             SP, SP, #0x10
    // 0xa0779c: mov             x3, x0
    // 0xa077a0: ldur            x0, [fp, #-0x10]
    // 0xa077a4: stur            x3, [fp, #-0x38]
    // 0xa077a8: add             x4, x0, #1
    // 0xa077ac: stur            x4, [fp, #-0x30]
    // 0xa077b0: cmp             w3, NULL
    // 0xa077b4: b.ne            #0xa077e4
    // 0xa077b8: mov             x0, x3
    // 0xa077bc: ldur            x2, [fp, #-0x20]
    // 0xa077c0: r1 = Null
    //     0xa077c0: mov             x1, NULL
    // 0xa077c4: cmp             w2, NULL
    // 0xa077c8: b.eq            #0xa077e4
    // 0xa077cc: LoadField: r4 = r2->field_17
    //     0xa077cc: ldur            w4, [x2, #0x17]
    // 0xa077d0: DecompressPointer r4
    //     0xa077d0: add             x4, x4, HEAP, lsl #32
    // 0xa077d4: r8 = X0
    //     0xa077d4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa077d8: LoadField: r9 = r4->field_7
    //     0xa077d8: ldur            x9, [x4, #7]
    // 0xa077dc: r3 = Null
    //     0xa077dc: ldr             x3, [PP, #0x7f60]  ; [pp+0x7f60] Null
    // 0xa077e0: blr             x9
    // 0xa077e4: ldur            x0, [fp, #-8]
    // 0xa077e8: LoadField: r1 = r0->field_b
    //     0xa077e8: ldur            w1, [x0, #0xb]
    // 0xa077ec: DecompressPointer r1
    //     0xa077ec: add             x1, x1, HEAP, lsl #32
    // 0xa077f0: stur            x1, [fp, #-0x40]
    // 0xa077f4: ldur            x16, [fp, #-0x38]
    // 0xa077f8: stp             x16, x1, [SP, #-0x10]!
    // 0xa077fc: r0 = _getValueOrData()
    //     0xa077fc: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa07800: add             SP, SP, #0x10
    // 0xa07804: ldur            x1, [fp, #-0x40]
    // 0xa07808: LoadField: r2 = r1->field_f
    //     0xa07808: ldur            w2, [x1, #0xf]
    // 0xa0780c: DecompressPointer r2
    //     0xa0780c: add             x2, x2, HEAP, lsl #32
    // 0xa07810: cmp             w2, w0
    // 0xa07814: b.ne            #0xa07820
    // 0xa07818: r5 = Null
    //     0xa07818: mov             x5, NULL
    // 0xa0781c: b               #0xa07824
    // 0xa07820: mov             x5, x0
    // 0xa07824: cmp             w5, NULL
    // 0xa07828: b.ne            #0xa0783c
    // 0xa0782c: r0 = Null
    //     0xa0782c: mov             x0, NULL
    // 0xa07830: LeaveFrame
    //     0xa07830: mov             SP, fp
    //     0xa07834: ldp             fp, lr, [SP], #0x10
    // 0xa07838: ret
    //     0xa07838: ret             
    // 0xa0783c: ldur            x4, [fp, #-0x30]
    // 0xa07840: ldur            x1, [fp, #-0x28]
    // 0xa07844: ldur            x2, [fp, #-0x20]
    // 0xa07848: ldur            x3, [fp, #-0x18]
    // 0xa0784c: b               #0xa076f8
    // 0xa07850: ldur            x0, [fp, #-0x28]
    // 0xa07854: r0 = ConcurrentModificationError()
    //     0xa07854: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa07858: ldur            x3, [fp, #-0x28]
    // 0xa0785c: StoreField: r0->field_b = r3
    //     0xa0785c: stur            w3, [x0, #0xb]
    // 0xa07860: r0 = Throw()
    //     0xa07860: bl              #0xd67e38  ; ThrowStub
    // 0xa07864: brk             #0
    // 0xa07868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa07868: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0786c: b               #0xa076ac
    // 0xa07870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa07870: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa07874: b               #0xa0770c
  }
}

// lib: , url: package:dbus/src/getuid_linux.dart

// class id: 1048859, size: 0x8
class :: {

  static int getuid() {
    // ** addr: 0xa0d8cc, size: 0xe0
    // 0xa0d8cc: EnterFrame
    //     0xa0d8cc: stp             fp, lr, [SP, #-0x10]!
    //     0xa0d8d0: mov             fp, SP
    // 0xa0d8d4: AllocStack(0x8)
    //     0xa0d8d4: sub             SP, SP, #8
    // 0xa0d8d8: CheckStackOverflow
    //     0xa0d8d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0d8dc: cmp             SP, x16
    //     0xa0d8e0: b.ls            #0xa0d9a4
    // 0xa0d8e4: r0 = InitLateStaticField(0x68c) // [dart:io] Platform::isLinux
    //     0xa0d8e4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0d8e8: ldr             x0, [x0, #0xd18]
    //     0xa0d8ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0d8f0: cmp             w0, w16
    //     0xa0d8f4: b.ne            #0xa0d900
    //     0xa0d8f8: ldr             x2, [PP, #0x70]  ; [pp+0x70] Field <Platform.isLinux>: static late final (offset: 0x68c)
    //     0xa0d8fc: bl              #0xd67cdc
    // 0xa0d900: tbnz            w0, #4, #0xa0d994
    // 0xa0d904: r16 = "libc.so.6"
    //     0xa0d904: add             x16, PP, #8, lsl #12  ; [pp+0x83a0] "libc.so.6"
    //     0xa0d908: ldr             x16, [x16, #0x3a0]
    // 0xa0d90c: SaveReg r16
    //     0xa0d90c: str             x16, [SP, #-8]!
    // 0xa0d910: r0 = _open()
    //     0xa0d910: bl              #0x930078  ; [dart:ffi] ::_open
    // 0xa0d914: add             SP, SP, #8
    // 0xa0d918: r16 = <NativeFunction<(dynamic this) => Int32>>
    //     0xa0d918: add             x16, PP, #8, lsl #12  ; [pp+0x83a8] TypeArguments: <NativeFunction<(dynamic this) => Int32>>
    //     0xa0d91c: ldr             x16, [x16, #0x3a8]
    // 0xa0d920: stp             x0, x16, [SP, #-0x10]!
    // 0xa0d924: r16 = "getuid"
    //     0xa0d924: add             x16, PP, #8, lsl #12  ; [pp+0x83b0] "getuid"
    //     0xa0d928: ldr             x16, [x16, #0x3b0]
    // 0xa0d92c: SaveReg r16
    //     0xa0d92c: str             x16, [SP, #-8]!
    // 0xa0d930: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0d930: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0d934: r0 = lookup()
    //     0xa0d934: bl              #0x92ffd4  ; [dart:ffi] DynamicLibrary::lookup
    // 0xa0d938: add             SP, SP, #0x18
    // 0xa0d93c: stur            x0, [fp, #-8]
    // 0xa0d940: r1 = 1
    //     0xa0d940: mov             x1, #1
    // 0xa0d944: r0 = AllocateContext()
    //     0xa0d944: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa0d948: mov             x1, x0
    // 0xa0d94c: ldur            x0, [fp, #-8]
    // 0xa0d950: StoreField: r1->field_f = r0
    //     0xa0d950: stur            w0, [x1, #0xf]
    // 0xa0d954: mov             x2, x1
    // 0xa0d958: r1 = Function 'FfiTrampoline_getuid': static ffi-trampoline-function.
    //     0xa0d958: add             x1, PP, #8, lsl #12  ; [pp+0x83b8] Function: [dart:ffi] ::FfiTrampoline_getuid (0xa0d9ac)
    //     0xa0d95c: ldr             x1, [x1, #0x3b8]
    // 0xa0d960: r0 = AllocateClosure()
    //     0xa0d960: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0d964: SaveReg r0
    //     0xa0d964: str             x0, [SP, #-8]!
    // 0xa0d968: ClosureCall
    //     0xa0d968: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xa0d96c: ldur            x2, [x0, #0x1f]
    //     0xa0d970: blr             x2
    // 0xa0d974: add             SP, SP, #8
    // 0xa0d978: r1 = LoadInt32Instr(r0)
    //     0xa0d978: sbfx            x1, x0, #1, #0x1f
    //     0xa0d97c: tbz             w0, #0, #0xa0d984
    //     0xa0d980: ldur            x1, [x0, #7]
    // 0xa0d984: mov             x0, x1
    // 0xa0d988: LeaveFrame
    //     0xa0d988: mov             SP, fp
    //     0xa0d98c: ldp             fp, lr, [SP], #0x10
    // 0xa0d990: ret
    //     0xa0d990: ret             
    // 0xa0d994: r0 = "Unable to determine UID on this system"
    //     0xa0d994: add             x0, PP, #8, lsl #12  ; [pp+0x83c0] "Unable to determine UID on this system"
    //     0xa0d998: ldr             x0, [x0, #0x3c0]
    // 0xa0d99c: r0 = Throw()
    //     0xa0d99c: bl              #0xd67e38  ; ThrowStub
    // 0xa0d9a0: brk             #0
    // 0xa0d9a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0d9a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0d9a8: b               #0xa0d8e4
  }
}

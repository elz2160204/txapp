// lib: , url: package:dbus/src/dbus_address.dart

// class id: 1048828, size: 0x8
class :: {
}

// class id: 4637, size: 0x10, field offset: 0x8
class DBusAddress extends Object {

  late final String transport; // offset: 0x8
  late final Map<String, String> properties; // offset: 0xc

  _ toString(/* No info */) {
    // ** addr: 0xacf018, size: 0xa0
    // 0xacf018: EnterFrame
    //     0xacf018: stp             fp, lr, [SP, #-0x10]!
    //     0xacf01c: mov             fp, SP
    // 0xacf020: AllocStack(0x8)
    //     0xacf020: sub             SP, SP, #8
    // 0xacf024: CheckStackOverflow
    //     0xacf024: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf028: cmp             SP, x16
    //     0xacf02c: b.ls            #0xacf0b0
    // 0xacf030: r1 = Null
    //     0xacf030: mov             x1, NULL
    // 0xacf034: r2 = 8
    //     0xacf034: mov             x2, #8
    // 0xacf038: r0 = AllocateArray()
    //     0xacf038: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf03c: stur            x0, [fp, #-8]
    // 0xacf040: r17 = DBusAddress
    //     0xacf040: add             x17, PP, #8, lsl #12  ; [pp+0x8830] Type: DBusAddress
    //     0xacf044: ldr             x17, [x17, #0x830]
    // 0xacf048: StoreField: r0->field_f = r17
    //     0xacf048: stur            w17, [x0, #0xf]
    // 0xacf04c: r17 = "(\'"
    //     0xacf04c: ldr             x17, [PP, #0x7168]  ; [pp+0x7168] "(\'"
    // 0xacf050: StoreField: r0->field_13 = r17
    //     0xacf050: stur            w17, [x0, #0x13]
    // 0xacf054: ldr             x16, [fp, #0x10]
    // 0xacf058: SaveReg r16
    //     0xacf058: str             x16, [SP, #-8]!
    // 0xacf05c: r0 = value()
    //     0xacf05c: bl              #0xacf0b8  ; [package:dbus/src/dbus_address.dart] DBusAddress::value
    // 0xacf060: add             SP, SP, #8
    // 0xacf064: ldur            x1, [fp, #-8]
    // 0xacf068: ArrayStore: r1[2] = r0  ; List_4
    //     0xacf068: add             x25, x1, #0x17
    //     0xacf06c: str             w0, [x25]
    //     0xacf070: tbz             w0, #0, #0xacf08c
    //     0xacf074: ldurb           w16, [x1, #-1]
    //     0xacf078: ldurb           w17, [x0, #-1]
    //     0xacf07c: and             x16, x17, x16, lsr #2
    //     0xacf080: tst             x16, HEAP, lsr #32
    //     0xacf084: b.eq            #0xacf08c
    //     0xacf088: bl              #0xd67e5c
    // 0xacf08c: ldur            x0, [fp, #-8]
    // 0xacf090: r17 = "\')"
    //     0xacf090: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xacf094: StoreField: r0->field_1b = r17
    //     0xacf094: stur            w17, [x0, #0x1b]
    // 0xacf098: SaveReg r0
    //     0xacf098: str             x0, [SP, #-8]!
    // 0xacf09c: r0 = _interpolate()
    //     0xacf09c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf0a0: add             SP, SP, #8
    // 0xacf0a4: LeaveFrame
    //     0xacf0a4: mov             SP, fp
    //     0xacf0a8: ldp             fp, lr, [SP], #0x10
    // 0xacf0ac: ret
    //     0xacf0ac: ret             
    // 0xacf0b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf0b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf0b4: b               #0xacf030
  }
  get _ value(/* No info */) {
    // ** addr: 0xacf0b8, size: 0x110
    // 0xacf0b8: EnterFrame
    //     0xacf0b8: stp             fp, lr, [SP, #-0x10]!
    //     0xacf0bc: mov             fp, SP
    // 0xacf0c0: AllocStack(0x10)
    //     0xacf0c0: sub             SP, SP, #0x10
    // 0xacf0c4: CheckStackOverflow
    //     0xacf0c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf0c8: cmp             SP, x16
    //     0xacf0cc: b.ls            #0xacf1b0
    // 0xacf0d0: r1 = 1
    //     0xacf0d0: mov             x1, #1
    // 0xacf0d4: r0 = AllocateContext()
    //     0xacf0d4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xacf0d8: mov             x1, x0
    // 0xacf0dc: ldr             x0, [fp, #0x10]
    // 0xacf0e0: stur            x1, [fp, #-8]
    // 0xacf0e4: StoreField: r1->field_f = r0
    //     0xacf0e4: stur            w0, [x1, #0xf]
    // 0xacf0e8: LoadField: r2 = r0->field_b
    //     0xacf0e8: ldur            w2, [x0, #0xb]
    // 0xacf0ec: DecompressPointer r2
    //     0xacf0ec: add             x2, x2, HEAP, lsl #32
    // 0xacf0f0: r16 = Sentinel
    //     0xacf0f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xacf0f4: cmp             w2, w16
    // 0xacf0f8: b.eq            #0xacf1b8
    // 0xacf0fc: SaveReg r2
    //     0xacf0fc: str             x2, [SP, #-8]!
    // 0xacf100: r0 = keys()
    //     0xacf100: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0xacf104: add             SP, SP, #8
    // 0xacf108: ldur            x2, [fp, #-8]
    // 0xacf10c: r1 = Function '<anonymous closure>':.
    //     0xacf10c: add             x1, PP, #8, lsl #12  ; [pp+0x8838] AnonymousClosure: (0xacf1c8), in [package:dbus/src/dbus_address.dart] DBusAddress::value (0xacf0b8)
    //     0xacf110: ldr             x1, [x1, #0x838]
    // 0xacf114: stur            x0, [fp, #-8]
    // 0xacf118: r0 = AllocateClosure()
    //     0xacf118: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xacf11c: r16 = <String>
    //     0xacf11c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xacf120: ldur            lr, [fp, #-8]
    // 0xacf124: stp             lr, x16, [SP, #-0x10]!
    // 0xacf128: SaveReg r0
    //     0xacf128: str             x0, [SP, #-8]!
    // 0xacf12c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xacf12c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xacf130: r0 = map()
    //     0xacf130: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0xacf134: add             SP, SP, #0x18
    // 0xacf138: r16 = ","
    //     0xacf138: ldr             x16, [PP, #0x978]  ; [pp+0x978] ","
    // 0xacf13c: stp             x16, x0, [SP, #-0x10]!
    // 0xacf140: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xacf140: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xacf144: r0 = join()
    //     0xacf144: bl              #0x6a9d88  ; [dart:core] Iterable::join
    // 0xacf148: add             SP, SP, #0x10
    // 0xacf14c: mov             x3, x0
    // 0xacf150: ldr             x0, [fp, #0x10]
    // 0xacf154: stur            x3, [fp, #-0x10]
    // 0xacf158: LoadField: r4 = r0->field_7
    //     0xacf158: ldur            w4, [x0, #7]
    // 0xacf15c: DecompressPointer r4
    //     0xacf15c: add             x4, x4, HEAP, lsl #32
    // 0xacf160: r16 = Sentinel
    //     0xacf160: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xacf164: cmp             w4, w16
    // 0xacf168: b.eq            #0xacf1c0
    // 0xacf16c: stur            x4, [fp, #-8]
    // 0xacf170: r1 = Null
    //     0xacf170: mov             x1, NULL
    // 0xacf174: r2 = 6
    //     0xacf174: mov             x2, #6
    // 0xacf178: r0 = AllocateArray()
    //     0xacf178: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf17c: mov             x1, x0
    // 0xacf180: ldur            x0, [fp, #-8]
    // 0xacf184: StoreField: r1->field_f = r0
    //     0xacf184: stur            w0, [x1, #0xf]
    // 0xacf188: r17 = ":"
    //     0xacf188: ldr             x17, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0xacf18c: StoreField: r1->field_13 = r17
    //     0xacf18c: stur            w17, [x1, #0x13]
    // 0xacf190: ldur            x0, [fp, #-0x10]
    // 0xacf194: StoreField: r1->field_17 = r0
    //     0xacf194: stur            w0, [x1, #0x17]
    // 0xacf198: SaveReg r1
    //     0xacf198: str             x1, [SP, #-8]!
    // 0xacf19c: r0 = _interpolate()
    //     0xacf19c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf1a0: add             SP, SP, #8
    // 0xacf1a4: LeaveFrame
    //     0xacf1a4: mov             SP, fp
    //     0xacf1a8: ldp             fp, lr, [SP], #0x10
    // 0xacf1ac: ret
    //     0xacf1ac: ret             
    // 0xacf1b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf1b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf1b4: b               #0xacf0d0
    // 0xacf1b8: r9 = properties
    //     0xacf1b8: ldr             x9, [PP, #0x7bf0]  ; [pp+0x7bf0] Field <DBusAddress.properties>: late final (offset: 0xc)
    // 0xacf1bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xacf1bc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xacf1c0: r9 = transport
    //     0xacf1c0: ldr             x9, [PP, #0x7be8]  ; [pp+0x7be8] Field <DBusAddress.transport>: late final (offset: 0x8)
    // 0xacf1c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xacf1c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] String <anonymous closure>(dynamic, String) {
    // ** addr: 0xacf1c8, size: 0x10c
    // 0xacf1c8: EnterFrame
    //     0xacf1c8: stp             fp, lr, [SP, #-0x10]!
    //     0xacf1cc: mov             fp, SP
    // 0xacf1d0: AllocStack(0x10)
    //     0xacf1d0: sub             SP, SP, #0x10
    // 0xacf1d4: SetupParameters()
    //     0xacf1d4: ldr             x0, [fp, #0x18]
    //     0xacf1d8: ldur            w3, [x0, #0x17]
    //     0xacf1dc: add             x3, x3, HEAP, lsl #32
    //     0xacf1e0: stur            x3, [fp, #-8]
    // 0xacf1e4: CheckStackOverflow
    //     0xacf1e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf1e8: cmp             SP, x16
    //     0xacf1ec: b.ls            #0xacf2c0
    // 0xacf1f0: r1 = Null
    //     0xacf1f0: mov             x1, NULL
    // 0xacf1f4: r2 = 6
    //     0xacf1f4: mov             x2, #6
    // 0xacf1f8: r0 = AllocateArray()
    //     0xacf1f8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf1fc: mov             x1, x0
    // 0xacf200: ldr             x0, [fp, #0x10]
    // 0xacf204: stur            x1, [fp, #-0x10]
    // 0xacf208: StoreField: r1->field_f = r0
    //     0xacf208: stur            w0, [x1, #0xf]
    // 0xacf20c: r17 = "="
    //     0xacf20c: ldr             x17, [PP, #0x2a8]  ; [pp+0x2a8] "="
    // 0xacf210: StoreField: r1->field_13 = r17
    //     0xacf210: stur            w17, [x1, #0x13]
    // 0xacf214: ldur            x2, [fp, #-8]
    // 0xacf218: LoadField: r3 = r2->field_f
    //     0xacf218: ldur            w3, [x2, #0xf]
    // 0xacf21c: DecompressPointer r3
    //     0xacf21c: add             x3, x3, HEAP, lsl #32
    // 0xacf220: LoadField: r2 = r3->field_b
    //     0xacf220: ldur            w2, [x3, #0xb]
    // 0xacf224: DecompressPointer r2
    //     0xacf224: add             x2, x2, HEAP, lsl #32
    // 0xacf228: r16 = Sentinel
    //     0xacf228: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xacf22c: cmp             w2, w16
    // 0xacf230: b.eq            #0xacf2c8
    // 0xacf234: stur            x2, [fp, #-8]
    // 0xacf238: stp             x0, x2, [SP, #-0x10]!
    // 0xacf23c: r0 = _getValueOrData()
    //     0xacf23c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xacf240: add             SP, SP, #0x10
    // 0xacf244: mov             x1, x0
    // 0xacf248: ldur            x0, [fp, #-8]
    // 0xacf24c: LoadField: r2 = r0->field_f
    //     0xacf24c: ldur            w2, [x0, #0xf]
    // 0xacf250: DecompressPointer r2
    //     0xacf250: add             x2, x2, HEAP, lsl #32
    // 0xacf254: cmp             w2, w1
    // 0xacf258: b.ne            #0xacf264
    // 0xacf25c: r0 = Null
    //     0xacf25c: mov             x0, NULL
    // 0xacf260: b               #0xacf268
    // 0xacf264: mov             x0, x1
    // 0xacf268: cmp             w0, NULL
    // 0xacf26c: b.eq            #0xacf2d0
    // 0xacf270: SaveReg r0
    //     0xacf270: str             x0, [SP, #-8]!
    // 0xacf274: r0 = _encodeValue()
    //     0xacf274: bl              #0xacf2d4  ; [package:dbus/src/dbus_address.dart] DBusAddress::_encodeValue
    // 0xacf278: add             SP, SP, #8
    // 0xacf27c: ldur            x1, [fp, #-0x10]
    // 0xacf280: ArrayStore: r1[2] = r0  ; List_4
    //     0xacf280: add             x25, x1, #0x17
    //     0xacf284: str             w0, [x25]
    //     0xacf288: tbz             w0, #0, #0xacf2a4
    //     0xacf28c: ldurb           w16, [x1, #-1]
    //     0xacf290: ldurb           w17, [x0, #-1]
    //     0xacf294: and             x16, x17, x16, lsr #2
    //     0xacf298: tst             x16, HEAP, lsr #32
    //     0xacf29c: b.eq            #0xacf2a4
    //     0xacf2a0: bl              #0xd67e5c
    // 0xacf2a4: ldur            x16, [fp, #-0x10]
    // 0xacf2a8: SaveReg r16
    //     0xacf2a8: str             x16, [SP, #-8]!
    // 0xacf2ac: r0 = _interpolate()
    //     0xacf2ac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf2b0: add             SP, SP, #8
    // 0xacf2b4: LeaveFrame
    //     0xacf2b4: mov             SP, fp
    //     0xacf2b8: ldp             fp, lr, [SP], #0x10
    // 0xacf2bc: ret
    //     0xacf2bc: ret             
    // 0xacf2c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf2c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf2c4: b               #0xacf1f0
    // 0xacf2c8: r9 = properties
    //     0xacf2c8: ldr             x9, [PP, #0x7bf0]  ; [pp+0x7bf0] Field <DBusAddress.properties>: late final (offset: 0xc)
    // 0xacf2cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xacf2cc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xacf2d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xacf2d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _encodeValue(/* No info */) {
    // ** addr: 0xacf2d4, size: 0x280
    // 0xacf2d4: EnterFrame
    //     0xacf2d4: stp             fp, lr, [SP, #-0x10]!
    //     0xacf2d8: mov             fp, SP
    // 0xacf2dc: AllocStack(0x30)
    //     0xacf2dc: sub             SP, SP, #0x30
    // 0xacf2e0: CheckStackOverflow
    //     0xacf2e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf2e4: cmp             SP, x16
    //     0xacf2e8: b.ls            #0xacf544
    // 0xacf2ec: r16 = Instance_Utf8Codec
    //     0xacf2ec: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xacf2f0: ldr             lr, [fp, #0x10]
    // 0xacf2f4: stp             lr, x16, [SP, #-0x10]!
    // 0xacf2f8: r0 = encode()
    //     0xacf2f8: bl              #0xbfcc28  ; [dart:convert] Codec::encode
    // 0xacf2fc: add             SP, SP, #0x10
    // 0xacf300: mov             x2, x0
    // 0xacf304: stur            x2, [fp, #-0x20]
    // 0xacf308: LoadField: r0 = r2->field_13
    //     0xacf308: ldur            w0, [x2, #0x13]
    // 0xacf30c: DecompressPointer r0
    //     0xacf30c: add             x0, x0, HEAP, lsl #32
    // 0xacf310: r3 = LoadInt32Instr(r0)
    //     0xacf310: sbfx            x3, x0, #1, #0x1f
    // 0xacf314: stur            x3, [fp, #-0x18]
    // 0xacf318: r4 = ""
    //     0xacf318: ldr             x4, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xacf31c: r0 = -1
    //     0xacf31c: mov             x0, #-1
    // 0xacf320: stur            x4, [fp, #-0x10]
    // 0xacf324: CheckStackOverflow
    //     0xacf324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf328: cmp             SP, x16
    //     0xacf32c: b.ls            #0xacf54c
    // 0xacf330: add             x5, x0, #1
    // 0xacf334: stur            x5, [fp, #-8]
    // 0xacf338: cmp             x5, x3
    // 0xacf33c: b.ge            #0xacf534
    // 0xacf340: r0 = BoxInt64Instr(r5)
    //     0xacf340: sbfiz           x0, x5, #1, #0x1f
    //     0xacf344: cmp             x5, x0, asr #1
    //     0xacf348: b.eq            #0xacf354
    //     0xacf34c: bl              #0xd69bb8
    //     0xacf350: stur            x5, [x0, #7]
    // 0xacf354: r1 = LoadClassIdInstr(r2)
    //     0xacf354: ldur            x1, [x2, #-1]
    //     0xacf358: ubfx            x1, x1, #0xc, #0x14
    // 0xacf35c: stp             x0, x2, [SP, #-0x10]!
    // 0xacf360: mov             x0, x1
    // 0xacf364: r0 = GDT[cid_x0 + -0xd83]()
    //     0xacf364: sub             lr, x0, #0xd83
    //     0xacf368: ldr             lr, [x21, lr, lsl #3]
    //     0xacf36c: blr             lr
    // 0xacf370: add             SP, SP, #0x10
    // 0xacf374: mov             x3, x0
    // 0xacf378: stur            x3, [fp, #-0x28]
    // 0xacf37c: cmp             w3, NULL
    // 0xacf380: b.ne            #0xacf3b8
    // 0xacf384: r3 as int
    //     0xacf384: mov             x0, x3
    //     0xacf388: mov             x2, NULL
    //     0xacf38c: mov             x1, NULL
    //     0xacf390: tbz             w0, #0, #0xacf3b8
    //     0xacf394: ldur            x4, [x0, #-1]
    //     0xacf398: ubfx            x4, x4, #0xc, #0x14
    //     0xacf39c: sub             x4, x4, #0x3b
    //     0xacf3a0: cmp             x4, #1
    //     0xacf3a4: b.ls            #0xacf3b8
    //     0xacf3a8: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xacf3ac: add             x3, PP, #8, lsl #12  ; [pp+0x8840] Null
    //     0xacf3b0: ldr             x3, [x3, #0x840]
    //     0xacf3b4: bl              #0xd73714
    // 0xacf3b8: ldur            x0, [fp, #-0x28]
    // 0xacf3bc: r1 = LoadInt32Instr(r0)
    //     0xacf3bc: sbfx            x1, x0, #1, #0x1f
    //     0xacf3c0: tbz             w0, #0, #0xacf3c8
    //     0xacf3c4: ldur            x1, [x0, #7]
    // 0xacf3c8: cmp             x1, #0x2d
    // 0xacf3cc: b.eq            #0xacf420
    // 0xacf3d0: cmp             x1, #0x30
    // 0xacf3d4: b.lt            #0xacf3e0
    // 0xacf3d8: cmp             x1, #0x39
    // 0xacf3dc: b.le            #0xacf420
    // 0xacf3e0: cmp             x1, #0x41
    // 0xacf3e4: b.lt            #0xacf3f0
    // 0xacf3e8: cmp             x1, #0x5a
    // 0xacf3ec: b.le            #0xacf420
    // 0xacf3f0: cmp             x1, #0x61
    // 0xacf3f4: b.lt            #0xacf400
    // 0xacf3f8: cmp             x1, #0x7a
    // 0xacf3fc: b.le            #0xacf420
    // 0xacf400: cmp             x1, #0x5f
    // 0xacf404: b.eq            #0xacf420
    // 0xacf408: cmp             x1, #0x2f
    // 0xacf40c: b.eq            #0xacf420
    // 0xacf410: cmp             x1, #0x2e
    // 0xacf414: b.eq            #0xacf420
    // 0xacf418: cmp             x1, #0x5c
    // 0xacf41c: b.ne            #0xacf48c
    // 0xacf420: r3 = 2
    //     0xacf420: mov             x3, #2
    // 0xacf424: mov             x2, x3
    // 0xacf428: r1 = Null
    //     0xacf428: mov             x1, NULL
    // 0xacf42c: r0 = AllocateArray()
    //     0xacf42c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf430: mov             x2, x0
    // 0xacf434: ldur            x0, [fp, #-0x28]
    // 0xacf438: stur            x2, [fp, #-0x30]
    // 0xacf43c: StoreField: r2->field_f = r0
    //     0xacf43c: stur            w0, [x2, #0xf]
    // 0xacf440: r1 = <int>
    //     0xacf440: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xacf444: r0 = AllocateGrowableArray()
    //     0xacf444: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xacf448: mov             x1, x0
    // 0xacf44c: ldur            x0, [fp, #-0x30]
    // 0xacf450: StoreField: r1->field_f = r0
    //     0xacf450: stur            w0, [x1, #0xf]
    // 0xacf454: r0 = 2
    //     0xacf454: mov             x0, #2
    // 0xacf458: StoreField: r1->field_b = r0
    //     0xacf458: stur            w0, [x1, #0xb]
    // 0xacf45c: r16 = Instance_Utf8Decoder
    //     0xacf45c: ldr             x16, [PP, #0xa48]  ; [pp+0xa48] Obj!Utf8Decoder<List<int>, String>@b5f7a1
    // 0xacf460: stp             x1, x16, [SP, #-0x10]!
    // 0xacf464: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xacf464: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xacf468: r0 = convert()
    //     0xacf468: bl              #0xc1ed20  ; [dart:convert] Utf8Decoder::convert
    // 0xacf46c: add             SP, SP, #0x10
    // 0xacf470: ldur            x16, [fp, #-0x10]
    // 0xacf474: stp             x0, x16, [SP, #-0x10]!
    // 0xacf478: r0 = +()
    //     0xacf478: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0xacf47c: add             SP, SP, #0x10
    // 0xacf480: mov             x1, x0
    // 0xacf484: mov             x4, x1
    // 0xacf488: b               #0xacf524
    // 0xacf48c: r1 = Null
    //     0xacf48c: mov             x1, NULL
    // 0xacf490: r2 = 4
    //     0xacf490: mov             x2, #4
    // 0xacf494: r0 = AllocateArray()
    //     0xacf494: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf498: stur            x0, [fp, #-0x30]
    // 0xacf49c: r17 = "%"
    //     0xacf49c: ldr             x17, [PP, #0x12b8]  ; [pp+0x12b8] "%"
    // 0xacf4a0: StoreField: r0->field_f = r17
    //     0xacf4a0: stur            w17, [x0, #0xf]
    // 0xacf4a4: ldur            x16, [fp, #-0x28]
    // 0xacf4a8: SaveReg r16
    //     0xacf4a8: str             x16, [SP, #-8]!
    // 0xacf4ac: r1 = 16
    //     0xacf4ac: mov             x1, #0x10
    // 0xacf4b0: SaveReg r1
    //     0xacf4b0: str             x1, [SP, #-8]!
    // 0xacf4b4: r0 = _toPow2String()
    //     0xacf4b4: bl              #0x506b60  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0xacf4b8: add             SP, SP, #0x10
    // 0xacf4bc: SaveReg r0
    //     0xacf4bc: str             x0, [SP, #-8]!
    // 0xacf4c0: r0 = 2
    //     0xacf4c0: mov             x0, #2
    // 0xacf4c4: r16 = "0"
    //     0xacf4c4: ldr             x16, [PP, #0x3af8]  ; [pp+0x3af8] "0"
    // 0xacf4c8: stp             x16, x0, [SP, #-0x10]!
    // 0xacf4cc: r0 = padLeft()
    //     0xacf4cc: bl              #0xd65600  ; [dart:core] _OneByteString::padLeft
    // 0xacf4d0: add             SP, SP, #0x18
    // 0xacf4d4: ldur            x1, [fp, #-0x30]
    // 0xacf4d8: ArrayStore: r1[1] = r0  ; List_4
    //     0xacf4d8: add             x25, x1, #0x13
    //     0xacf4dc: str             w0, [x25]
    //     0xacf4e0: tbz             w0, #0, #0xacf4fc
    //     0xacf4e4: ldurb           w16, [x1, #-1]
    //     0xacf4e8: ldurb           w17, [x0, #-1]
    //     0xacf4ec: and             x16, x17, x16, lsr #2
    //     0xacf4f0: tst             x16, HEAP, lsr #32
    //     0xacf4f4: b.eq            #0xacf4fc
    //     0xacf4f8: bl              #0xd67e5c
    // 0xacf4fc: ldur            x16, [fp, #-0x30]
    // 0xacf500: SaveReg r16
    //     0xacf500: str             x16, [SP, #-8]!
    // 0xacf504: r0 = _interpolate()
    //     0xacf504: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf508: add             SP, SP, #8
    // 0xacf50c: ldur            x16, [fp, #-0x10]
    // 0xacf510: stp             x0, x16, [SP, #-0x10]!
    // 0xacf514: r0 = +()
    //     0xacf514: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0xacf518: add             SP, SP, #0x10
    // 0xacf51c: mov             x1, x0
    // 0xacf520: mov             x4, x1
    // 0xacf524: ldur            x0, [fp, #-8]
    // 0xacf528: ldur            x2, [fp, #-0x20]
    // 0xacf52c: ldur            x3, [fp, #-0x18]
    // 0xacf530: b               #0xacf320
    // 0xacf534: ldur            x0, [fp, #-0x10]
    // 0xacf538: LeaveFrame
    //     0xacf538: mov             SP, fp
    //     0xacf53c: ldp             fp, lr, [SP], #0x10
    // 0xacf540: ret
    //     0xacf540: ret             
    // 0xacf544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf544: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf548: b               #0xacf2ec
    // 0xacf54c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf54c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf550: b               #0xacf330
  }
  factory _ DBusAddress(/* No info */) {
    // ** addr: 0xd6f040, size: 0x120
    // 0xd6f040: EnterFrame
    //     0xd6f040: stp             fp, lr, [SP, #-0x10]!
    //     0xd6f044: mov             fp, SP
    // 0xd6f048: AllocStack(0x18)
    //     0xd6f048: sub             SP, SP, #0x18
    // 0xd6f04c: CheckStackOverflow
    //     0xd6f04c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6f050: cmp             SP, x16
    //     0xd6f054: b.ls            #0xd6f158
    // 0xd6f058: ldr             x1, [fp, #0x10]
    // 0xd6f05c: r0 = LoadClassIdInstr(r1)
    //     0xd6f05c: ldur            x0, [x1, #-1]
    //     0xd6f060: ubfx            x0, x0, #0xc, #0x14
    // 0xd6f064: r16 = ":"
    //     0xd6f064: ldr             x16, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0xd6f068: stp             x16, x1, [SP, #-0x10]!
    // 0xd6f06c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xd6f06c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xd6f070: r0 = GDT[cid_x0 + -0xff0]()
    //     0xd6f070: sub             lr, x0, #0xff0
    //     0xd6f074: ldr             lr, [x21, lr, lsl #3]
    //     0xd6f078: blr             lr
    // 0xd6f07c: add             SP, SP, #0x10
    // 0xd6f080: mov             x2, x0
    // 0xd6f084: stur            x2, [fp, #-0x10]
    // 0xd6f088: tbnz            x2, #0x3f, #0xd6f10c
    // 0xd6f08c: ldr             x3, [fp, #0x10]
    // 0xd6f090: r0 = BoxInt64Instr(r2)
    //     0xd6f090: sbfiz           x0, x2, #1, #0x1f
    //     0xd6f094: cmp             x2, x0, asr #1
    //     0xd6f098: b.eq            #0xd6f0a4
    //     0xd6f09c: bl              #0xd69bb8
    //     0xd6f0a0: stur            x2, [x0, #7]
    // 0xd6f0a4: stp             xzr, x3, [SP, #-0x10]!
    // 0xd6f0a8: SaveReg r0
    //     0xd6f0a8: str             x0, [SP, #-8]!
    // 0xd6f0ac: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xd6f0ac: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xd6f0b0: r0 = substring()
    //     0xd6f0b0: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xd6f0b4: add             SP, SP, #0x18
    // 0xd6f0b8: mov             x1, x0
    // 0xd6f0bc: ldur            x0, [fp, #-0x10]
    // 0xd6f0c0: stur            x1, [fp, #-8]
    // 0xd6f0c4: add             x2, x0, #1
    // 0xd6f0c8: ldr             x16, [fp, #0x10]
    // 0xd6f0cc: stp             x2, x16, [SP, #-0x10]!
    // 0xd6f0d0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xd6f0d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xd6f0d4: r0 = substring()
    //     0xd6f0d4: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xd6f0d8: add             SP, SP, #0x10
    // 0xd6f0dc: SaveReg r0
    //     0xd6f0dc: str             x0, [SP, #-8]!
    // 0xd6f0e0: r0 = _parseProperties()
    //     0xd6f0e0: bl              #0xd6f16c  ; [package:dbus/src/dbus_address.dart] DBusAddress::_parseProperties
    // 0xd6f0e4: add             SP, SP, #8
    // 0xd6f0e8: stur            x0, [fp, #-0x18]
    // 0xd6f0ec: r0 = DBusAddress()
    //     0xd6f0ec: bl              #0xd6f160  ; AllocateDBusAddressStub -> DBusAddress (size=0x10)
    // 0xd6f0f0: ldur            x1, [fp, #-8]
    // 0xd6f0f4: StoreField: r0->field_7 = r1
    //     0xd6f0f4: stur            w1, [x0, #7]
    // 0xd6f0f8: ldur            x1, [fp, #-0x18]
    // 0xd6f0fc: StoreField: r0->field_b = r1
    //     0xd6f0fc: stur            w1, [x0, #0xb]
    // 0xd6f100: LeaveFrame
    //     0xd6f100: mov             SP, fp
    //     0xd6f104: ldp             fp, lr, [SP], #0x10
    // 0xd6f108: ret
    //     0xd6f108: ret             
    // 0xd6f10c: ldr             x0, [fp, #0x10]
    // 0xd6f110: r1 = Null
    //     0xd6f110: mov             x1, NULL
    // 0xd6f114: r2 = 4
    //     0xd6f114: mov             x2, #4
    // 0xd6f118: r0 = AllocateArray()
    //     0xd6f118: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6f11c: r17 = "Unable to determine transport of D-Bus address: "
    //     0xd6f11c: ldr             x17, [PP, #0x970]  ; [pp+0x970] "Unable to determine transport of D-Bus address: "
    // 0xd6f120: StoreField: r0->field_f = r17
    //     0xd6f120: stur            w17, [x0, #0xf]
    // 0xd6f124: ldr             x3, [fp, #0x10]
    // 0xd6f128: StoreField: r0->field_13 = r3
    //     0xd6f128: stur            w3, [x0, #0x13]
    // 0xd6f12c: SaveReg r0
    //     0xd6f12c: str             x0, [SP, #-8]!
    // 0xd6f130: r0 = _interpolate()
    //     0xd6f130: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6f134: add             SP, SP, #8
    // 0xd6f138: stur            x0, [fp, #-8]
    // 0xd6f13c: r0 = FormatException()
    //     0xd6f13c: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xd6f140: mov             x1, x0
    // 0xd6f144: ldur            x0, [fp, #-8]
    // 0xd6f148: StoreField: r1->field_7 = r0
    //     0xd6f148: stur            w0, [x1, #7]
    // 0xd6f14c: mov             x0, x1
    // 0xd6f150: r0 = Throw()
    //     0xd6f150: bl              #0xd67e38  ; ThrowStub
    // 0xd6f154: brk             #0
    // 0xd6f158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6f158: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6f15c: b               #0xd6f058
  }
  static _ _parseProperties(/* No info */) {
    // ** addr: 0xd6f16c, size: 0x55c
    // 0xd6f16c: EnterFrame
    //     0xd6f16c: stp             fp, lr, [SP, #-0x10]!
    //     0xd6f170: mov             fp, SP
    // 0xd6f174: AllocStack(0xb8)
    //     0xd6f174: sub             SP, SP, #0xb8
    // 0xd6f178: CheckStackOverflow
    //     0xd6f178: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6f17c: cmp             SP, x16
    //     0xd6f180: b.ls            #0xd6f6b8
    // 0xd6f184: r16 = <String, String>
    //     0xd6f184: ldr             x16, [PP, #0x278]  ; [pp+0x278] TypeArguments: <String, String>
    // 0xd6f188: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xd6f18c: stp             lr, x16, [SP, #-0x10]!
    // 0xd6f190: r0 = Map._fromLiteral()
    //     0xd6f190: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xd6f194: add             SP, SP, #0x10
    // 0xd6f198: mov             x2, x0
    // 0xd6f19c: ldr             x1, [fp, #0x10]
    // 0xd6f1a0: stur            x2, [fp, #-0x58]
    // 0xd6f1a4: r0 = LoadClassIdInstr(r1)
    //     0xd6f1a4: ldur            x0, [x1, #-1]
    //     0xd6f1a8: ubfx            x0, x0, #0xc, #0x14
    // 0xd6f1ac: r16 = ""
    //     0xd6f1ac: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd6f1b0: stp             x16, x1, [SP, #-0x10]!
    // 0xd6f1b4: mov             lr, x0
    // 0xd6f1b8: ldr             lr, [x21, lr, lsl #3]
    // 0xd6f1bc: blr             lr
    // 0xd6f1c0: add             SP, SP, #0x10
    // 0xd6f1c4: tbnz            w0, #4, #0xd6f1d8
    // 0xd6f1c8: ldur            x0, [fp, #-0x58]
    // 0xd6f1cc: LeaveFrame
    //     0xd6f1cc: mov             SP, fp
    //     0xd6f1d0: ldp             fp, lr, [SP], #0x10
    // 0xd6f1d4: ret
    //     0xd6f1d4: ret             
    // 0xd6f1d8: ldr             x0, [fp, #0x10]
    // 0xd6f1dc: ldur            x1, [fp, #-0x58]
    // 0xd6f1e0: r2 = LoadClassIdInstr(r0)
    //     0xd6f1e0: ldur            x2, [x0, #-1]
    //     0xd6f1e4: ubfx            x2, x2, #0xc, #0x14
    // 0xd6f1e8: r16 = ","
    //     0xd6f1e8: ldr             x16, [PP, #0x978]  ; [pp+0x978] ","
    // 0xd6f1ec: stp             x16, x0, [SP, #-0x10]!
    // 0xd6f1f0: mov             x0, x2
    // 0xd6f1f4: r0 = GDT[cid_x0 + -0xff8]()
    //     0xd6f1f4: sub             lr, x0, #0xff8
    //     0xd6f1f8: ldr             lr, [x21, lr, lsl #3]
    //     0xd6f1fc: blr             lr
    // 0xd6f200: add             SP, SP, #0x10
    // 0xd6f204: stur            x0, [fp, #-0x68]
    // 0xd6f208: LoadField: r2 = r0->field_7
    //     0xd6f208: ldur            w2, [x0, #7]
    // 0xd6f20c: DecompressPointer r2
    //     0xd6f20c: add             x2, x2, HEAP, lsl #32
    // 0xd6f210: mov             x1, x2
    // 0xd6f214: stur            x2, [fp, #-0x60]
    // 0xd6f218: r0 = ListIterator()
    //     0xd6f218: bl              #0x50a2a0  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0xd6f21c: mov             x2, x0
    // 0xd6f220: ldur            x1, [fp, #-0x68]
    // 0xd6f224: stur            x2, [fp, #-0x88]
    // 0xd6f228: StoreField: r2->field_b = r1
    //     0xd6f228: stur            w1, [x2, #0xb]
    // 0xd6f22c: LoadField: r0 = r1->field_b
    //     0xd6f22c: ldur            w0, [x1, #0xb]
    // 0xd6f230: DecompressPointer r0
    //     0xd6f230: add             x0, x0, HEAP, lsl #32
    // 0xd6f234: r3 = LoadInt32Instr(r0)
    //     0xd6f234: sbfx            x3, x0, #1, #0x1f
    // 0xd6f238: stur            x3, [fp, #-0x80]
    // 0xd6f23c: StoreField: r2->field_f = r3
    //     0xd6f23c: stur            x3, [x2, #0xf]
    // 0xd6f240: r0 = 0
    //     0xd6f240: mov             x0, #0
    // 0xd6f244: StoreField: r2->field_17 = r0
    //     0xd6f244: stur            x0, [x2, #0x17]
    // 0xd6f248: ldur            x4, [fp, #-0x58]
    // 0xd6f24c: LoadField: r5 = r4->field_7
    //     0xd6f24c: ldur            w5, [x4, #7]
    // 0xd6f250: DecompressPointer r5
    //     0xd6f250: add             x5, x5, HEAP, lsl #32
    // 0xd6f254: stur            x5, [fp, #-0x78]
    // 0xd6f258: r6 = 0
    //     0xd6f258: mov             x6, #0
    // 0xd6f25c: stur            x6, [fp, #-0x70]
    // 0xd6f260: CheckStackOverflow
    //     0xd6f260: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6f264: cmp             SP, x16
    //     0xd6f268: b.ls            #0xd6f6c0
    // 0xd6f26c: r0 = LoadClassIdInstr(r1)
    //     0xd6f26c: ldur            x0, [x1, #-1]
    //     0xd6f270: ubfx            x0, x0, #0xc, #0x14
    // 0xd6f274: SaveReg r1
    //     0xd6f274: str             x1, [SP, #-8]!
    // 0xd6f278: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xd6f278: mov             x17, #0xb8ea
    //     0xd6f27c: add             lr, x0, x17
    //     0xd6f280: ldr             lr, [x21, lr, lsl #3]
    //     0xd6f284: blr             lr
    // 0xd6f288: add             SP, SP, #8
    // 0xd6f28c: r1 = LoadInt32Instr(r0)
    //     0xd6f28c: sbfx            x1, x0, #1, #0x1f
    //     0xd6f290: tbz             w0, #0, #0xd6f298
    //     0xd6f294: ldur            x1, [x0, #7]
    // 0xd6f298: ldur            x2, [fp, #-0x80]
    // 0xd6f29c: cmp             x2, x1
    // 0xd6f2a0: b.ne            #0xd6f5a4
    // 0xd6f2a4: ldur            x3, [fp, #-0x68]
    // 0xd6f2a8: ldur            x4, [fp, #-0x70]
    // 0xd6f2ac: cmp             x4, x1
    // 0xd6f2b0: b.lt            #0xd6f2cc
    // 0xd6f2b4: ldur            x5, [fp, #-0x88]
    // 0xd6f2b8: StoreField: r5->field_1f = rNULL
    //     0xd6f2b8: stur            NULL, [x5, #0x1f]
    // 0xd6f2bc: ldur            x0, [fp, #-0x58]
    // 0xd6f2c0: LeaveFrame
    //     0xd6f2c0: mov             SP, fp
    //     0xd6f2c4: ldp             fp, lr, [SP], #0x10
    // 0xd6f2c8: ret
    //     0xd6f2c8: ret             
    // 0xd6f2cc: ldur            x5, [fp, #-0x88]
    // 0xd6f2d0: r0 = BoxInt64Instr(r4)
    //     0xd6f2d0: sbfiz           x0, x4, #1, #0x1f
    //     0xd6f2d4: cmp             x4, x0, asr #1
    //     0xd6f2d8: b.eq            #0xd6f2e4
    //     0xd6f2dc: bl              #0xd69bb8
    //     0xd6f2e0: stur            x4, [x0, #7]
    // 0xd6f2e4: r1 = LoadClassIdInstr(r3)
    //     0xd6f2e4: ldur            x1, [x3, #-1]
    //     0xd6f2e8: ubfx            x1, x1, #0xc, #0x14
    // 0xd6f2ec: stp             x0, x3, [SP, #-0x10]!
    // 0xd6f2f0: mov             x0, x1
    // 0xd6f2f4: r0 = GDT[cid_x0 + 0xd175]()
    //     0xd6f2f4: mov             x17, #0xd175
    //     0xd6f2f8: add             lr, x0, x17
    //     0xd6f2fc: ldr             lr, [x21, lr, lsl #3]
    //     0xd6f300: blr             lr
    // 0xd6f304: add             SP, SP, #0x10
    // 0xd6f308: mov             x4, x0
    // 0xd6f30c: ldur            x3, [fp, #-0x88]
    // 0xd6f310: stur            x4, [fp, #-0x98]
    // 0xd6f314: StoreField: r3->field_1f = r0
    //     0xd6f314: stur            w0, [x3, #0x1f]
    //     0xd6f318: tbz             w0, #0, #0xd6f334
    //     0xd6f31c: ldurb           w16, [x3, #-1]
    //     0xd6f320: ldurb           w17, [x0, #-1]
    //     0xd6f324: and             x16, x17, x16, lsr #2
    //     0xd6f328: tst             x16, HEAP, lsr #32
    //     0xd6f32c: b.eq            #0xd6f334
    //     0xd6f330: bl              #0xd682ac
    // 0xd6f334: ldur            x0, [fp, #-0x70]
    // 0xd6f338: add             x6, x0, #1
    // 0xd6f33c: stur            x6, [fp, #-0x90]
    // 0xd6f340: StoreField: r3->field_17 = r6
    //     0xd6f340: stur            x6, [x3, #0x17]
    // 0xd6f344: cmp             w4, NULL
    // 0xd6f348: b.ne            #0xd6f378
    // 0xd6f34c: mov             x0, x4
    // 0xd6f350: ldur            x2, [fp, #-0x60]
    // 0xd6f354: r1 = Null
    //     0xd6f354: mov             x1, NULL
    // 0xd6f358: cmp             w2, NULL
    // 0xd6f35c: b.eq            #0xd6f378
    // 0xd6f360: LoadField: r4 = r2->field_17
    //     0xd6f360: ldur            w4, [x2, #0x17]
    // 0xd6f364: DecompressPointer r4
    //     0xd6f364: add             x4, x4, HEAP, lsl #32
    // 0xd6f368: r8 = X0
    //     0xd6f368: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xd6f36c: LoadField: r9 = r4->field_7
    //     0xd6f36c: ldur            x9, [x4, #7]
    // 0xd6f370: r3 = Null
    //     0xd6f370: ldr             x3, [PP, #0x980]  ; [pp+0x980] Null
    // 0xd6f374: blr             x9
    // 0xd6f378: ldur            x1, [fp, #-0x98]
    // 0xd6f37c: r0 = LoadClassIdInstr(r1)
    //     0xd6f37c: ldur            x0, [x1, #-1]
    //     0xd6f380: ubfx            x0, x0, #0xc, #0x14
    // 0xd6f384: r16 = "="
    //     0xd6f384: ldr             x16, [PP, #0x2a8]  ; [pp+0x2a8] "="
    // 0xd6f388: stp             x16, x1, [SP, #-0x10]!
    // 0xd6f38c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xd6f38c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xd6f390: r0 = GDT[cid_x0 + -0xff0]()
    //     0xd6f390: sub             lr, x0, #0xff0
    //     0xd6f394: ldr             lr, [x21, lr, lsl #3]
    //     0xd6f398: blr             lr
    // 0xd6f39c: add             SP, SP, #0x10
    // 0xd6f3a0: mov             x2, x0
    // 0xd6f3a4: stur            x2, [fp, #-0xa8]
    // 0xd6f3a8: tbnz            x2, #0x3f, #0xd6f5bc
    // 0xd6f3ac: ldur            x3, [fp, #-0x98]
    // 0xd6f3b0: LoadField: r4 = r3->field_7
    //     0xd6f3b0: ldur            w4, [x3, #7]
    // 0xd6f3b4: DecompressPointer r4
    //     0xd6f3b4: add             x4, x4, HEAP, lsl #32
    // 0xd6f3b8: r0 = BoxInt64Instr(r2)
    //     0xd6f3b8: sbfiz           x0, x2, #1, #0x1f
    //     0xd6f3bc: cmp             x2, x0, asr #1
    //     0xd6f3c0: b.eq            #0xd6f3cc
    //     0xd6f3c4: bl              #0xd69bb8
    //     0xd6f3c8: stur            x2, [x0, #7]
    // 0xd6f3cc: r1 = LoadInt32Instr(r4)
    //     0xd6f3cc: sbfx            x1, x4, #1, #0x1f
    // 0xd6f3d0: stur            x1, [fp, #-0x70]
    // 0xd6f3d4: stp             x0, xzr, [SP, #-0x10]!
    // 0xd6f3d8: SaveReg r1
    //     0xd6f3d8: str             x1, [SP, #-8]!
    // 0xd6f3dc: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xd6f3dc: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xd6f3e0: r0 = checkValidRange()
    //     0xd6f3e0: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0xd6f3e4: add             SP, SP, #0x18
    // 0xd6f3e8: ldur            x16, [fp, #-0x98]
    // 0xd6f3ec: stp             xzr, x16, [SP, #-0x10]!
    // 0xd6f3f0: SaveReg r0
    //     0xd6f3f0: str             x0, [SP, #-8]!
    // 0xd6f3f4: r0 = _substringUnchecked()
    //     0xd6f3f4: bl              #0x4d0ab0  ; [dart:core] _StringBase::_substringUnchecked
    // 0xd6f3f8: add             SP, SP, #0x18
    // 0xd6f3fc: mov             x2, x0
    // 0xd6f400: stur            x2, [fp, #-0xb8]
    // 0xd6f404: ldur            x0, [fp, #-0xa8]
    // 0xd6f408: ldur            x3, [fp, #-0x70]
    // 0xd6f40c: add             x4, x0, #1
    // 0xd6f410: stur            x4, [fp, #-0xb0]
    // 0xd6f414: r0 = BoxInt64Instr(r4)
    //     0xd6f414: sbfiz           x0, x4, #1, #0x1f
    //     0xd6f418: cmp             x4, x0, asr #1
    //     0xd6f41c: b.eq            #0xd6f428
    //     0xd6f420: bl              #0xd69bb8
    //     0xd6f424: stur            x4, [x0, #7]
    // 0xd6f428: stur            x0, [fp, #-0xa0]
    // 0xd6f42c: stp             NULL, x0, [SP, #-0x10]!
    // 0xd6f430: SaveReg r3
    //     0xd6f430: str             x3, [SP, #-8]!
    // 0xd6f434: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xd6f434: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xd6f438: r0 = checkValidRange()
    //     0xd6f438: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0xd6f43c: add             SP, SP, #0x18
    // 0xd6f440: stur            x0, [fp, #-0x70]
    // 0xd6f444: ldur            x16, [fp, #-0x98]
    // 0xd6f448: ldur            lr, [fp, #-0xa0]
    // 0xd6f44c: stp             lr, x16, [SP, #-0x10]!
    // 0xd6f450: SaveReg r0
    //     0xd6f450: str             x0, [SP, #-8]!
    // 0xd6f454: r0 = _substringUnchecked()
    //     0xd6f454: bl              #0x4d0ab0  ; [dart:core] _StringBase::_substringUnchecked
    // 0xd6f458: add             SP, SP, #0x18
    // 0xd6f45c: SaveReg r0
    //     0xd6f45c: str             x0, [SP, #-8]!
    // 0xd6f460: r0 = _decodeValue()
    //     0xd6f460: bl              #0xd6f6c8  ; [package:dbus/src/dbus_address.dart] DBusAddress::_decodeValue
    // 0xd6f464: add             SP, SP, #8
    // 0xd6f468: stur            x0, [fp, #-0xa0]
    // 0xd6f46c: ldur            x1, [fp, #-0x58]
    // 0xd6f470: LoadField: r2 = r1->field_f
    //     0xd6f470: ldur            w2, [x1, #0xf]
    // 0xd6f474: DecompressPointer r2
    //     0xd6f474: add             x2, x2, HEAP, lsl #32
    // 0xd6f478: stur            x2, [fp, #-0x98]
    // 0xd6f47c: ldur            x16, [fp, #-0xb8]
    // 0xd6f480: stp             x16, x1, [SP, #-0x10]!
    // 0xd6f484: r0 = _getValueOrData()
    //     0xd6f484: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xd6f488: add             SP, SP, #0x10
    // 0xd6f48c: mov             x1, x0
    // 0xd6f490: ldur            x0, [fp, #-0x98]
    // 0xd6f494: cmp             w0, w1
    // 0xd6f498: b.ne            #0xd6f608
    // 0xd6f49c: ldur            x3, [fp, #-0xb8]
    // 0xd6f4a0: mov             x0, x3
    // 0xd6f4a4: ldur            x2, [fp, #-0x78]
    // 0xd6f4a8: r1 = Null
    //     0xd6f4a8: mov             x1, NULL
    // 0xd6f4ac: cmp             w2, NULL
    // 0xd6f4b0: b.eq            #0xd6f4cc
    // 0xd6f4b4: LoadField: r4 = r2->field_17
    //     0xd6f4b4: ldur            w4, [x2, #0x17]
    // 0xd6f4b8: DecompressPointer r4
    //     0xd6f4b8: add             x4, x4, HEAP, lsl #32
    // 0xd6f4bc: r8 = X0
    //     0xd6f4bc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xd6f4c0: LoadField: r9 = r4->field_7
    //     0xd6f4c0: ldur            x9, [x4, #7]
    // 0xd6f4c4: r3 = Null
    //     0xd6f4c4: ldr             x3, [PP, #0x990]  ; [pp+0x990] Null
    // 0xd6f4c8: blr             x9
    // 0xd6f4cc: ldur            x0, [fp, #-0xa0]
    // 0xd6f4d0: ldur            x2, [fp, #-0x78]
    // 0xd6f4d4: r1 = Null
    //     0xd6f4d4: mov             x1, NULL
    // 0xd6f4d8: cmp             w2, NULL
    // 0xd6f4dc: b.eq            #0xd6f4f8
    // 0xd6f4e0: LoadField: r4 = r2->field_1b
    //     0xd6f4e0: ldur            w4, [x2, #0x1b]
    // 0xd6f4e4: DecompressPointer r4
    //     0xd6f4e4: add             x4, x4, HEAP, lsl #32
    // 0xd6f4e8: r8 = X1
    //     0xd6f4e8: ldr             x8, [PP, #0x9a0]  ; [pp+0x9a0] TypeParameter: X1
    // 0xd6f4ec: LoadField: r9 = r4->field_7
    //     0xd6f4ec: ldur            x9, [x4, #7]
    // 0xd6f4f0: r3 = Null
    //     0xd6f4f0: ldr             x3, [PP, #0x9a8]  ; [pp+0x9a8] Null
    // 0xd6f4f4: blr             x9
    // 0xd6f4f8: ldur            x16, [fp, #-0x58]
    // 0xd6f4fc: ldur            lr, [fp, #-0xb8]
    // 0xd6f500: stp             lr, x16, [SP, #-0x10]!
    // 0xd6f504: r0 = hash()
    //     0xd6f504: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0xd6f508: add             SP, SP, #0x10
    // 0xd6f50c: ldur            x16, [fp, #-0x58]
    // 0xd6f510: ldur            lr, [fp, #-0xb8]
    // 0xd6f514: stp             lr, x16, [SP, #-0x10]!
    // 0xd6f518: ldur            x16, [fp, #-0xa0]
    // 0xd6f51c: stp             x0, x16, [SP, #-0x10]!
    // 0xd6f520: r0 = _set()
    //     0xd6f520: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xd6f524: add             SP, SP, #0x20
    // 0xd6f528: ldur            x6, [fp, #-0x90]
    // 0xd6f52c: ldur            x4, [fp, #-0x58]
    // 0xd6f530: ldur            x1, [fp, #-0x68]
    // 0xd6f534: ldur            x5, [fp, #-0x78]
    // 0xd6f538: ldur            x2, [fp, #-0x88]
    // 0xd6f53c: ldur            x3, [fp, #-0x80]
    // 0xd6f540: b               #0xd6f25c
    // 0xd6f544: sub             SP, fp, #0xb8
    // 0xd6f548: mov             x4, x0
    // 0xd6f54c: mov             x3, x1
    // 0xd6f550: stur            x0, [fp, #-0x58]
    // 0xd6f554: stur            x1, [fp, #-0x60]
    // 0xd6f558: r2 = Null
    //     0xd6f558: mov             x2, NULL
    // 0xd6f55c: r1 = Null
    //     0xd6f55c: mov             x1, NULL
    // 0xd6f560: cmp             w0, NULL
    // 0xd6f564: b.eq            #0xd6f590
    // 0xd6f568: branchIfSmi(r0, 0xd6f590)
    //     0xd6f568: tbz             w0, #0, #0xd6f590
    // 0xd6f56c: r3 = LoadClassIdInstr(r0)
    //     0xd6f56c: ldur            x3, [x0, #-1]
    //     0xd6f570: ubfx            x3, x3, #0xc, #0x14
    // 0xd6f574: sub             x3, x3, #0x49f
    // 0xd6f578: cmp             x3, #1
    // 0xd6f57c: b.ls            #0xd6f598
    // 0xd6f580: r17 = -4518
    //     0xd6f580: mov             x17, #-0x11a6
    // 0xd6f584: add             x3, x3, x17
    // 0xd6f588: cmp             x3, #1
    // 0xd6f58c: b.ls            #0xd6f598
    // 0xd6f590: r0 = false
    //     0xd6f590: add             x0, NULL, #0x30  ; false
    // 0xd6f594: b               #0xd6f59c
    // 0xd6f598: r0 = true
    //     0xd6f598: add             x0, NULL, #0x20  ; true
    // 0xd6f59c: tbnz            w0, #4, #0xd6f6a8
    // 0xd6f5a0: b               #0xd6f65c
    // 0xd6f5a4: ldur            x0, [fp, #-0x68]
    // 0xd6f5a8: r0 = ConcurrentModificationError()
    //     0xd6f5a8: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd6f5ac: ldur            x3, [fp, #-0x68]
    // 0xd6f5b0: StoreField: r0->field_b = r3
    //     0xd6f5b0: stur            w3, [x0, #0xb]
    // 0xd6f5b4: r0 = Throw()
    //     0xd6f5b4: bl              #0xd67e38  ; ThrowStub
    // 0xd6f5b8: brk             #0
    // 0xd6f5bc: ldur            x0, [fp, #-0x98]
    // 0xd6f5c0: r1 = Null
    //     0xd6f5c0: mov             x1, NULL
    // 0xd6f5c4: r2 = 4
    //     0xd6f5c4: mov             x2, #4
    // 0xd6f5c8: r0 = AllocateArray()
    //     0xd6f5c8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6f5cc: r17 = "Invalid D-Bus address property: "
    //     0xd6f5cc: ldr             x17, [PP, #0x9b8]  ; [pp+0x9b8] "Invalid D-Bus address property: "
    // 0xd6f5d0: StoreField: r0->field_f = r17
    //     0xd6f5d0: stur            w17, [x0, #0xf]
    // 0xd6f5d4: ldur            x3, [fp, #-0x98]
    // 0xd6f5d8: StoreField: r0->field_13 = r3
    //     0xd6f5d8: stur            w3, [x0, #0x13]
    // 0xd6f5dc: SaveReg r0
    //     0xd6f5dc: str             x0, [SP, #-8]!
    // 0xd6f5e0: r0 = _interpolate()
    //     0xd6f5e0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6f5e4: add             SP, SP, #8
    // 0xd6f5e8: stur            x0, [fp, #-0xa0]
    // 0xd6f5ec: r0 = FormatException()
    //     0xd6f5ec: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xd6f5f0: mov             x1, x0
    // 0xd6f5f4: ldur            x0, [fp, #-0xa0]
    // 0xd6f5f8: StoreField: r1->field_7 = r0
    //     0xd6f5f8: stur            w0, [x1, #7]
    // 0xd6f5fc: mov             x0, x1
    // 0xd6f600: r0 = Throw()
    //     0xd6f600: bl              #0xd67e38  ; ThrowStub
    // 0xd6f604: brk             #0
    // 0xd6f608: ldur            x0, [fp, #-0xb8]
    // 0xd6f60c: r1 = Null
    //     0xd6f60c: mov             x1, NULL
    // 0xd6f610: r2 = 6
    //     0xd6f610: mov             x2, #6
    // 0xd6f614: r0 = AllocateArray()
    //     0xd6f614: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6f618: r17 = "D-Bus address conatins duplicate key \'"
    //     0xd6f618: ldr             x17, [PP, #0x9c0]  ; [pp+0x9c0] "D-Bus address conatins duplicate key \'"
    // 0xd6f61c: StoreField: r0->field_f = r17
    //     0xd6f61c: stur            w17, [x0, #0xf]
    // 0xd6f620: ldur            x3, [fp, #-0xb8]
    // 0xd6f624: StoreField: r0->field_13 = r3
    //     0xd6f624: stur            w3, [x0, #0x13]
    // 0xd6f628: r17 = "\'"
    //     0xd6f628: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xd6f62c: StoreField: r0->field_17 = r17
    //     0xd6f62c: stur            w17, [x0, #0x17]
    // 0xd6f630: SaveReg r0
    //     0xd6f630: str             x0, [SP, #-8]!
    // 0xd6f634: r0 = _interpolate()
    //     0xd6f634: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6f638: add             SP, SP, #8
    // 0xd6f63c: stur            x0, [fp, #-0x98]
    // 0xd6f640: r0 = FormatException()
    //     0xd6f640: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xd6f644: mov             x1, x0
    // 0xd6f648: ldur            x0, [fp, #-0x98]
    // 0xd6f64c: StoreField: r1->field_7 = r0
    //     0xd6f64c: stur            w0, [x1, #7]
    // 0xd6f650: mov             x0, x1
    // 0xd6f654: r0 = Throw()
    //     0xd6f654: bl              #0xd67e38  ; ThrowStub
    // 0xd6f658: brk             #0
    // 0xd6f65c: ldur            x0, [fp, #-0x38]
    // 0xd6f660: r1 = Null
    //     0xd6f660: mov             x1, NULL
    // 0xd6f664: r2 = 4
    //     0xd6f664: mov             x2, #4
    // 0xd6f668: r0 = AllocateArray()
    //     0xd6f668: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6f66c: r17 = "Invalid value in D-Bus address property: "
    //     0xd6f66c: ldr             x17, [PP, #0x9d0]  ; [pp+0x9d0] "Invalid value in D-Bus address property: "
    // 0xd6f670: StoreField: r0->field_f = r17
    //     0xd6f670: stur            w17, [x0, #0xf]
    // 0xd6f674: ldur            x1, [fp, #-0x38]
    // 0xd6f678: StoreField: r0->field_13 = r1
    //     0xd6f678: stur            w1, [x0, #0x13]
    // 0xd6f67c: SaveReg r0
    //     0xd6f67c: str             x0, [SP, #-8]!
    // 0xd6f680: r0 = _interpolate()
    //     0xd6f680: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6f684: add             SP, SP, #8
    // 0xd6f688: stur            x0, [fp, #-0x68]
    // 0xd6f68c: r0 = FormatException()
    //     0xd6f68c: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xd6f690: mov             x1, x0
    // 0xd6f694: ldur            x0, [fp, #-0x68]
    // 0xd6f698: StoreField: r1->field_7 = r0
    //     0xd6f698: stur            w0, [x1, #7]
    // 0xd6f69c: mov             x0, x1
    // 0xd6f6a0: r0 = Throw()
    //     0xd6f6a0: bl              #0xd67e38  ; ThrowStub
    // 0xd6f6a4: brk             #0
    // 0xd6f6a8: ldur            x0, [fp, #-0x58]
    // 0xd6f6ac: ldur            x1, [fp, #-0x60]
    // 0xd6f6b0: r0 = ReThrow()
    //     0xd6f6b0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6f6b4: brk             #0
    // 0xd6f6b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6f6b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6f6bc: b               #0xd6f184
    // 0xd6f6c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6f6c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6f6c4: b               #0xd6f26c
  }
  static _ _decodeValue(/* No info */) {
    // ** addr: 0xd6f6c8, size: 0x2fc
    // 0xd6f6c8: EnterFrame
    //     0xd6f6c8: stp             fp, lr, [SP, #-0x10]!
    //     0xd6f6cc: mov             fp, SP
    // 0xd6f6d0: AllocStack(0x48)
    //     0xd6f6d0: sub             SP, SP, #0x48
    // 0xd6f6d4: CheckStackOverflow
    //     0xd6f6d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6f6d8: cmp             SP, x16
    //     0xd6f6dc: b.ls            #0xd6f9a0
    // 0xd6f6e0: r16 = Instance_Utf8Codec
    //     0xd6f6e0: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xd6f6e4: ldr             lr, [fp, #0x10]
    // 0xd6f6e8: stp             lr, x16, [SP, #-0x10]!
    // 0xd6f6ec: r0 = encode()
    //     0xd6f6ec: bl              #0xbfcc28  ; [dart:convert] Codec::encode
    // 0xd6f6f0: add             SP, SP, #0x10
    // 0xd6f6f4: stur            x0, [fp, #-8]
    // 0xd6f6f8: r16 = <int>
    //     0xd6f6f8: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xd6f6fc: stp             xzr, x16, [SP, #-0x10]!
    // 0xd6f700: r0 = _GrowableList()
    //     0xd6f700: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xd6f704: add             SP, SP, #0x10
    // 0xd6f708: mov             x4, x0
    // 0xd6f70c: ldur            x3, [fp, #-8]
    // 0xd6f710: stur            x4, [fp, #-0x30]
    // 0xd6f714: LoadField: r0 = r3->field_13
    //     0xd6f714: ldur            w0, [x3, #0x13]
    // 0xd6f718: DecompressPointer r0
    //     0xd6f718: add             x0, x0, HEAP, lsl #32
    // 0xd6f71c: r5 = LoadInt32Instr(r0)
    //     0xd6f71c: sbfx            x5, x0, #1, #0x1f
    // 0xd6f720: stur            x5, [fp, #-0x28]
    // 0xd6f724: r2 = 0
    //     0xd6f724: mov             x2, #0
    // 0xd6f728: r6 = 4
    //     0xd6f728: mov             x6, #4
    // 0xd6f72c: stur            x2, [fp, #-0x48]
    // 0xd6f730: CheckStackOverflow
    //     0xd6f730: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6f734: cmp             SP, x16
    //     0xd6f738: b.ls            #0xd6f9a8
    // 0xd6f73c: cmp             x2, x5
    // 0xd6f740: b.ge            #0xd6f968
    // 0xd6f744: mov             x0, x5
    // 0xd6f748: mov             x1, x2
    // 0xd6f74c: cmp             x1, x0
    // 0xd6f750: b.hs            #0xd6f9b0
    // 0xd6f754: ArrayLoad: r0 = r3[r2]  ; TypedUnsigned_1
    //     0xd6f754: add             x16, x3, x2
    //     0xd6f758: ldrb            w0, [x16, #0x17]
    // 0xd6f75c: cmp             x0, #0x25
    // 0xd6f760: b.ne            #0xd6f8dc
    // 0xd6f764: add             x0, x2, #3
    // 0xd6f768: cmp             x0, x5
    // 0xd6f76c: b.gt            #0xd6f98c
    // 0xd6f770: r7 = "Insufficient space for escape sequence"
    //     0xd6f770: ldr             x7, [PP, #0xa40]  ; [pp+0xa40] "Insufficient space for escape sequence"
    // 0xd6f774: add             x8, x2, #1
    // 0xd6f778: mov             x0, x5
    // 0xd6f77c: mov             x1, x8
    // 0xd6f780: cmp             x1, x0
    // 0xd6f784: b.hs            #0xd6f9b4
    // 0xd6f788: ArrayLoad: r0 = r3[r8]  ; TypedUnsigned_1
    //     0xd6f788: add             x16, x3, x8
    //     0xd6f78c: ldrb            w0, [x16, #0x17]
    // 0xd6f790: lsl             x8, x0, #1
    // 0xd6f794: stur            x8, [fp, #-0x20]
    // 0xd6f798: add             x9, x2, #2
    // 0xd6f79c: mov             x0, x5
    // 0xd6f7a0: mov             x1, x9
    // 0xd6f7a4: stur            x9, [fp, #-0x18]
    // 0xd6f7a8: cmp             x1, x0
    // 0xd6f7ac: b.hs            #0xd6f9b8
    // 0xd6f7b0: ArrayLoad: r0 = r3[r9]  ; TypedUnsigned_1
    //     0xd6f7b0: add             x16, x3, x9
    //     0xd6f7b4: ldrb            w0, [x16, #0x17]
    // 0xd6f7b8: lsl             x10, x0, #1
    // 0xd6f7bc: mov             x2, x6
    // 0xd6f7c0: stur            x10, [fp, #-0x10]
    // 0xd6f7c4: r1 = Null
    //     0xd6f7c4: mov             x1, NULL
    // 0xd6f7c8: r0 = AllocateArray()
    //     0xd6f7c8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6f7cc: mov             x2, x0
    // 0xd6f7d0: ldur            x0, [fp, #-0x20]
    // 0xd6f7d4: stur            x2, [fp, #-0x38]
    // 0xd6f7d8: StoreField: r2->field_f = r0
    //     0xd6f7d8: stur            w0, [x2, #0xf]
    // 0xd6f7dc: ldur            x0, [fp, #-0x10]
    // 0xd6f7e0: StoreField: r2->field_13 = r0
    //     0xd6f7e0: stur            w0, [x2, #0x13]
    // 0xd6f7e4: r1 = <int>
    //     0xd6f7e4: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xd6f7e8: r0 = AllocateGrowableArray()
    //     0xd6f7e8: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xd6f7ec: mov             x1, x0
    // 0xd6f7f0: ldur            x0, [fp, #-0x38]
    // 0xd6f7f4: StoreField: r1->field_f = r0
    //     0xd6f7f4: stur            w0, [x1, #0xf]
    // 0xd6f7f8: r0 = 4
    //     0xd6f7f8: mov             x0, #4
    // 0xd6f7fc: StoreField: r1->field_b = r0
    //     0xd6f7fc: stur            w0, [x1, #0xb]
    // 0xd6f800: r16 = Instance_Utf8Decoder
    //     0xd6f800: ldr             x16, [PP, #0xa48]  ; [pp+0xa48] Obj!Utf8Decoder<List<int>, String>@b5f7a1
    // 0xd6f804: stp             x1, x16, [SP, #-0x10]!
    // 0xd6f808: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xd6f808: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xd6f80c: r0 = convert()
    //     0xd6f80c: bl              #0xc1ed20  ; [dart:convert] Utf8Decoder::convert
    // 0xd6f810: add             SP, SP, #0x10
    // 0xd6f814: r16 = 32
    //     0xd6f814: mov             x16, #0x20
    // 0xd6f818: stp             x16, x0, [SP, #-0x10]!
    // 0xd6f81c: r4 = const [0, 0x2, 0x2, 0x1, radix, 0x1, null]
    //     0xd6f81c: ldr             x4, [PP, #0xa50]  ; [pp+0xa50] List(7) [0, 0x2, 0x2, 0x1, "radix", 0x1, Null]
    // 0xd6f820: r0 = parse()
    //     0xd6f820: bl              #0x4d5d84  ; [dart:core] int::parse
    // 0xd6f824: add             SP, SP, #0x10
    // 0xd6f828: mov             x1, x0
    // 0xd6f82c: ldur            x0, [fp, #-0x30]
    // 0xd6f830: stur            x1, [fp, #-0x40]
    // 0xd6f834: LoadField: r2 = r0->field_b
    //     0xd6f834: ldur            w2, [x0, #0xb]
    // 0xd6f838: DecompressPointer r2
    //     0xd6f838: add             x2, x2, HEAP, lsl #32
    // 0xd6f83c: stur            x2, [fp, #-0x10]
    // 0xd6f840: LoadField: r3 = r0->field_f
    //     0xd6f840: ldur            w3, [x0, #0xf]
    // 0xd6f844: DecompressPointer r3
    //     0xd6f844: add             x3, x3, HEAP, lsl #32
    // 0xd6f848: LoadField: r4 = r3->field_b
    //     0xd6f848: ldur            w4, [x3, #0xb]
    // 0xd6f84c: DecompressPointer r4
    //     0xd6f84c: add             x4, x4, HEAP, lsl #32
    // 0xd6f850: cmp             w2, w4
    // 0xd6f854: b.ne            #0xd6f864
    // 0xd6f858: SaveReg r0
    //     0xd6f858: str             x0, [SP, #-8]!
    // 0xd6f85c: r0 = _growToNextCapacity()
    //     0xd6f85c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd6f860: add             SP, SP, #8
    // 0xd6f864: ldur            x3, [fp, #-0x30]
    // 0xd6f868: ldur            x2, [fp, #-0x40]
    // 0xd6f86c: ldur            x0, [fp, #-0x10]
    // 0xd6f870: r4 = LoadInt32Instr(r0)
    //     0xd6f870: sbfx            x4, x0, #1, #0x1f
    // 0xd6f874: add             x0, x4, #1
    // 0xd6f878: lsl             x1, x0, #1
    // 0xd6f87c: StoreField: r3->field_b = r1
    //     0xd6f87c: stur            w1, [x3, #0xb]
    // 0xd6f880: mov             x1, x4
    // 0xd6f884: cmp             x1, x0
    // 0xd6f888: b.hs            #0xd6f9bc
    // 0xd6f88c: LoadField: r5 = r3->field_f
    //     0xd6f88c: ldur            w5, [x3, #0xf]
    // 0xd6f890: DecompressPointer r5
    //     0xd6f890: add             x5, x5, HEAP, lsl #32
    // 0xd6f894: r0 = BoxInt64Instr(r2)
    //     0xd6f894: sbfiz           x0, x2, #1, #0x1f
    //     0xd6f898: cmp             x2, x0, asr #1
    //     0xd6f89c: b.eq            #0xd6f8a8
    //     0xd6f8a0: bl              #0xd69bb8
    //     0xd6f8a4: stur            x2, [x0, #7]
    // 0xd6f8a8: mov             x1, x5
    // 0xd6f8ac: ArrayStore: r1[r4] = r0  ; List_4
    //     0xd6f8ac: add             x25, x1, x4, lsl #2
    //     0xd6f8b0: add             x25, x25, #0xf
    //     0xd6f8b4: str             w0, [x25]
    //     0xd6f8b8: tbz             w0, #0, #0xd6f8d4
    //     0xd6f8bc: ldurb           w16, [x1, #-1]
    //     0xd6f8c0: ldurb           w17, [x0, #-1]
    //     0xd6f8c4: and             x16, x17, x16, lsr #2
    //     0xd6f8c8: tst             x16, HEAP, lsr #32
    //     0xd6f8cc: b.eq            #0xd6f8d4
    //     0xd6f8d0: bl              #0xd67e5c
    // 0xd6f8d4: ldur            x0, [fp, #-0x18]
    // 0xd6f8d8: b               #0xd6f954
    // 0xd6f8dc: mov             x3, x4
    // 0xd6f8e0: lsl             x1, x0, #1
    // 0xd6f8e4: stur            x1, [fp, #-0x20]
    // 0xd6f8e8: LoadField: r0 = r3->field_b
    //     0xd6f8e8: ldur            w0, [x3, #0xb]
    // 0xd6f8ec: DecompressPointer r0
    //     0xd6f8ec: add             x0, x0, HEAP, lsl #32
    // 0xd6f8f0: stur            x0, [fp, #-0x10]
    // 0xd6f8f4: LoadField: r4 = r3->field_f
    //     0xd6f8f4: ldur            w4, [x3, #0xf]
    // 0xd6f8f8: DecompressPointer r4
    //     0xd6f8f8: add             x4, x4, HEAP, lsl #32
    // 0xd6f8fc: LoadField: r5 = r4->field_b
    //     0xd6f8fc: ldur            w5, [x4, #0xb]
    // 0xd6f900: DecompressPointer r5
    //     0xd6f900: add             x5, x5, HEAP, lsl #32
    // 0xd6f904: cmp             w0, w5
    // 0xd6f908: b.ne            #0xd6f918
    // 0xd6f90c: SaveReg r3
    //     0xd6f90c: str             x3, [SP, #-8]!
    // 0xd6f910: r0 = _growToNextCapacity()
    //     0xd6f910: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd6f914: add             SP, SP, #8
    // 0xd6f918: ldur            x3, [fp, #-0x30]
    // 0xd6f91c: ldur            x2, [fp, #-0x20]
    // 0xd6f920: ldur            x0, [fp, #-0x10]
    // 0xd6f924: r4 = LoadInt32Instr(r0)
    //     0xd6f924: sbfx            x4, x0, #1, #0x1f
    // 0xd6f928: add             x0, x4, #1
    // 0xd6f92c: lsl             x1, x0, #1
    // 0xd6f930: StoreField: r3->field_b = r1
    //     0xd6f930: stur            w1, [x3, #0xb]
    // 0xd6f934: mov             x1, x4
    // 0xd6f938: cmp             x1, x0
    // 0xd6f93c: b.hs            #0xd6f9c0
    // 0xd6f940: LoadField: r0 = r3->field_f
    //     0xd6f940: ldur            w0, [x3, #0xf]
    // 0xd6f944: DecompressPointer r0
    //     0xd6f944: add             x0, x0, HEAP, lsl #32
    // 0xd6f948: ArrayStore: r0[r4] = r2  ; Unknown_4
    //     0xd6f948: add             x1, x0, x4, lsl #2
    //     0xd6f94c: stur            w2, [x1, #0xf]
    // 0xd6f950: ldur            x0, [fp, #-0x48]
    // 0xd6f954: add             x2, x0, #1
    // 0xd6f958: mov             x4, x3
    // 0xd6f95c: ldur            x3, [fp, #-8]
    // 0xd6f960: ldur            x5, [fp, #-0x28]
    // 0xd6f964: b               #0xd6f728
    // 0xd6f968: mov             x3, x4
    // 0xd6f96c: r16 = Instance_Utf8Codec
    //     0xd6f96c: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xd6f970: stp             x3, x16, [SP, #-0x10]!
    // 0xd6f974: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xd6f974: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xd6f978: r0 = decode()
    //     0xd6f978: bl              #0x4e1c78  ; [dart:convert] Utf8Codec::decode
    // 0xd6f97c: add             SP, SP, #0x10
    // 0xd6f980: LeaveFrame
    //     0xd6f980: mov             SP, fp
    //     0xd6f984: ldp             fp, lr, [SP], #0x10
    // 0xd6f988: ret
    //     0xd6f988: ret             
    // 0xd6f98c: r0 = FormatException()
    //     0xd6f98c: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xd6f990: r7 = "Insufficient space for escape sequence"
    //     0xd6f990: ldr             x7, [PP, #0xa40]  ; [pp+0xa40] "Insufficient space for escape sequence"
    // 0xd6f994: StoreField: r0->field_7 = r7
    //     0xd6f994: stur            w7, [x0, #7]
    // 0xd6f998: r0 = Throw()
    //     0xd6f998: bl              #0xd67e38  ; ThrowStub
    // 0xd6f99c: brk             #0
    // 0xd6f9a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6f9a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6f9a4: b               #0xd6f6e0
    // 0xd6f9a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6f9a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6f9ac: b               #0xd6f73c
    // 0xd6f9b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd6f9b0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd6f9b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd6f9b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd6f9b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd6f9b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd6f9bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd6f9bc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd6f9c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd6f9c0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

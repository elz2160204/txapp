// lib: , url: package:dbus/src/dbus_method_call.dart

// class id: 1048841, size: 0x8
class :: {
}

// class id: 4610, size: 0x24, field offset: 0x8
//   const constructor, 
class DBusMethodCall extends Object {

  get _ signature(/* No info */) {
    // ** addr: 0xa0711c, size: 0xac
    // 0xa0711c: EnterFrame
    //     0xa0711c: stp             fp, lr, [SP, #-0x10]!
    //     0xa07120: mov             fp, SP
    // 0xa07124: AllocStack(0x10)
    //     0xa07124: sub             SP, SP, #0x10
    // 0xa07128: CheckStackOverflow
    //     0xa07128: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0712c: cmp             SP, x16
    //     0xa07130: b.ls            #0xa071c0
    // 0xa07134: ldr             x0, [fp, #0x10]
    // 0xa07138: LoadField: r3 = r0->field_13
    //     0xa07138: ldur            w3, [x0, #0x13]
    // 0xa0713c: DecompressPointer r3
    //     0xa0713c: add             x3, x3, HEAP, lsl #32
    // 0xa07140: stur            x3, [fp, #-8]
    // 0xa07144: r1 = Function '<anonymous closure>':.
    //     0xa07144: ldr             x1, [PP, #0x7f08]  ; [pp+0x7f08] AnonymousClosure: (0x9feffc), in [package:dbus/src/dbus_signal.dart] DBusSignal::signature (0x9fef50)
    // 0xa07148: r2 = Null
    //     0xa07148: mov             x2, NULL
    // 0xa0714c: r0 = AllocateClosure()
    //     0xa0714c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa07150: r16 = <DBusSignature>
    //     0xa07150: ldr             x16, [PP, #0x4c0]  ; [pp+0x4c0] TypeArguments: <DBusSignature>
    // 0xa07154: ldur            lr, [fp, #-8]
    // 0xa07158: stp             lr, x16, [SP, #-0x10]!
    // 0xa0715c: SaveReg r0
    //     0xa0715c: str             x0, [SP, #-8]!
    // 0xa07160: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa07160: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa07164: r0 = map()
    //     0xa07164: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa07168: add             SP, SP, #0x18
    // 0xa0716c: stur            x0, [fp, #-8]
    // 0xa07170: r0 = DBusSignature()
    //     0xa07170: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa07174: stur            x0, [fp, #-0x10]
    // 0xa07178: r16 = ""
    //     0xa07178: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa0717c: stp             x16, x0, [SP, #-0x10]!
    // 0xa07180: r0 = DBusSignature()
    //     0xa07180: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa07184: add             SP, SP, #0x10
    // 0xa07188: r1 = Function '<anonymous closure>':.
    //     0xa07188: ldr             x1, [PP, #0x7f10]  ; [pp+0x7f10] AnonymousClosure: (0x9fef14), in [package:dbus/src/dbus_signal.dart] DBusSignal::signature (0x9fef50)
    // 0xa0718c: r2 = Null
    //     0xa0718c: mov             x2, NULL
    // 0xa07190: r0 = AllocateClosure()
    //     0xa07190: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa07194: r16 = <DBusSignature>
    //     0xa07194: ldr             x16, [PP, #0x4c0]  ; [pp+0x4c0] TypeArguments: <DBusSignature>
    // 0xa07198: ldur            lr, [fp, #-8]
    // 0xa0719c: stp             lr, x16, [SP, #-0x10]!
    // 0xa071a0: ldur            x16, [fp, #-0x10]
    // 0xa071a4: stp             x0, x16, [SP, #-0x10]!
    // 0xa071a8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa071a8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa071ac: r0 = fold()
    //     0xa071ac: bl              #0x9fed6c  ; [dart:_internal] ListIterable::fold
    // 0xa071b0: add             SP, SP, #0x20
    // 0xa071b4: LeaveFrame
    //     0xa071b4: mov             SP, fp
    //     0xa071b8: ldp             fp, lr, [SP], #0x10
    // 0xa071bc: ret
    //     0xa071bc: ret             
    // 0xa071c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa071c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa071c4: b               #0xa07134
  }
  _ toString(/* No info */) {
    // ** addr: 0xad0a04, size: 0x400
    // 0xad0a04: EnterFrame
    //     0xad0a04: stp             fp, lr, [SP, #-0x10]!
    //     0xad0a08: mov             fp, SP
    // 0xad0a0c: AllocStack(0x10)
    //     0xad0a0c: sub             SP, SP, #0x10
    // 0xad0a10: CheckStackOverflow
    //     0xad0a10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad0a14: cmp             SP, x16
    //     0xad0a18: b.ls            #0xad0dfc
    // 0xad0a1c: r1 = Null
    //     0xad0a1c: mov             x1, NULL
    // 0xad0a20: r2 = 28
    //     0xad0a20: mov             x2, #0x1c
    // 0xad0a24: r0 = AllocateArray()
    //     0xad0a24: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0a28: stur            x0, [fp, #-8]
    // 0xad0a2c: r17 = "sender"
    //     0xad0a2c: ldr             x17, [PP, #0x7640]  ; [pp+0x7640] "sender"
    // 0xad0a30: StoreField: r0->field_f = r17
    //     0xad0a30: stur            w17, [x0, #0xf]
    // 0xad0a34: r1 = Null
    //     0xad0a34: mov             x1, NULL
    // 0xad0a38: r2 = 6
    //     0xad0a38: mov             x2, #6
    // 0xad0a3c: r0 = AllocateArray()
    //     0xad0a3c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0a40: r17 = "\'"
    //     0xad0a40: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad0a44: StoreField: r0->field_f = r17
    //     0xad0a44: stur            w17, [x0, #0xf]
    // 0xad0a48: ldr             x1, [fp, #0x10]
    // 0xad0a4c: LoadField: r2 = r1->field_7
    //     0xad0a4c: ldur            w2, [x1, #7]
    // 0xad0a50: DecompressPointer r2
    //     0xad0a50: add             x2, x2, HEAP, lsl #32
    // 0xad0a54: StoreField: r0->field_13 = r2
    //     0xad0a54: stur            w2, [x0, #0x13]
    // 0xad0a58: r17 = "\'"
    //     0xad0a58: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad0a5c: StoreField: r0->field_17 = r17
    //     0xad0a5c: stur            w17, [x0, #0x17]
    // 0xad0a60: SaveReg r0
    //     0xad0a60: str             x0, [SP, #-8]!
    // 0xad0a64: r0 = _interpolate()
    //     0xad0a64: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad0a68: add             SP, SP, #8
    // 0xad0a6c: ldur            x1, [fp, #-8]
    // 0xad0a70: ArrayStore: r1[1] = r0  ; List_4
    //     0xad0a70: add             x25, x1, #0x13
    //     0xad0a74: str             w0, [x25]
    //     0xad0a78: tbz             w0, #0, #0xad0a94
    //     0xad0a7c: ldurb           w16, [x1, #-1]
    //     0xad0a80: ldurb           w17, [x0, #-1]
    //     0xad0a84: and             x16, x17, x16, lsr #2
    //     0xad0a88: tst             x16, HEAP, lsr #32
    //     0xad0a8c: b.eq            #0xad0a94
    //     0xad0a90: bl              #0xd67e5c
    // 0xad0a94: ldur            x0, [fp, #-8]
    // 0xad0a98: r17 = "interface"
    //     0xad0a98: ldr             x17, [PP, #0x508]  ; [pp+0x508] "interface"
    // 0xad0a9c: StoreField: r0->field_17 = r17
    //     0xad0a9c: stur            w17, [x0, #0x17]
    // 0xad0aa0: ldr             x3, [fp, #0x10]
    // 0xad0aa4: LoadField: r4 = r3->field_b
    //     0xad0aa4: ldur            w4, [x3, #0xb]
    // 0xad0aa8: DecompressPointer r4
    //     0xad0aa8: add             x4, x4, HEAP, lsl #32
    // 0xad0aac: stur            x4, [fp, #-0x10]
    // 0xad0ab0: cmp             w4, NULL
    // 0xad0ab4: b.eq            #0xad0aec
    // 0xad0ab8: r1 = Null
    //     0xad0ab8: mov             x1, NULL
    // 0xad0abc: r2 = 6
    //     0xad0abc: mov             x2, #6
    // 0xad0ac0: r0 = AllocateArray()
    //     0xad0ac0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0ac4: r17 = "\'"
    //     0xad0ac4: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad0ac8: StoreField: r0->field_f = r17
    //     0xad0ac8: stur            w17, [x0, #0xf]
    // 0xad0acc: ldur            x1, [fp, #-0x10]
    // 0xad0ad0: StoreField: r0->field_13 = r1
    //     0xad0ad0: stur            w1, [x0, #0x13]
    // 0xad0ad4: r17 = "\'"
    //     0xad0ad4: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad0ad8: StoreField: r0->field_17 = r17
    //     0xad0ad8: stur            w17, [x0, #0x17]
    // 0xad0adc: SaveReg r0
    //     0xad0adc: str             x0, [SP, #-8]!
    // 0xad0ae0: r0 = _interpolate()
    //     0xad0ae0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad0ae4: add             SP, SP, #8
    // 0xad0ae8: b               #0xad0af0
    // 0xad0aec: r0 = Null
    //     0xad0aec: mov             x0, NULL
    // 0xad0af0: ldr             x4, [fp, #0x10]
    // 0xad0af4: ldur            x3, [fp, #-8]
    // 0xad0af8: mov             x1, x3
    // 0xad0afc: ArrayStore: r1[3] = r0  ; List_4
    //     0xad0afc: add             x25, x1, #0x1b
    //     0xad0b00: str             w0, [x25]
    //     0xad0b04: tbz             w0, #0, #0xad0b20
    //     0xad0b08: ldurb           w16, [x1, #-1]
    //     0xad0b0c: ldurb           w17, [x0, #-1]
    //     0xad0b10: and             x16, x17, x16, lsr #2
    //     0xad0b14: tst             x16, HEAP, lsr #32
    //     0xad0b18: b.eq            #0xad0b20
    //     0xad0b1c: bl              #0xd67e5c
    // 0xad0b20: r17 = "name"
    //     0xad0b20: ldr             x17, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xad0b24: StoreField: r3->field_1f = r17
    //     0xad0b24: stur            w17, [x3, #0x1f]
    // 0xad0b28: r1 = Null
    //     0xad0b28: mov             x1, NULL
    // 0xad0b2c: r2 = 6
    //     0xad0b2c: mov             x2, #6
    // 0xad0b30: r0 = AllocateArray()
    //     0xad0b30: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0b34: r17 = "\'"
    //     0xad0b34: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad0b38: StoreField: r0->field_f = r17
    //     0xad0b38: stur            w17, [x0, #0xf]
    // 0xad0b3c: ldr             x1, [fp, #0x10]
    // 0xad0b40: LoadField: r2 = r1->field_f
    //     0xad0b40: ldur            w2, [x1, #0xf]
    // 0xad0b44: DecompressPointer r2
    //     0xad0b44: add             x2, x2, HEAP, lsl #32
    // 0xad0b48: StoreField: r0->field_13 = r2
    //     0xad0b48: stur            w2, [x0, #0x13]
    // 0xad0b4c: r17 = "\'"
    //     0xad0b4c: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xad0b50: StoreField: r0->field_17 = r17
    //     0xad0b50: stur            w17, [x0, #0x17]
    // 0xad0b54: SaveReg r0
    //     0xad0b54: str             x0, [SP, #-8]!
    // 0xad0b58: r0 = _interpolate()
    //     0xad0b58: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad0b5c: add             SP, SP, #8
    // 0xad0b60: ldur            x1, [fp, #-8]
    // 0xad0b64: ArrayStore: r1[5] = r0  ; List_4
    //     0xad0b64: add             x25, x1, #0x23
    //     0xad0b68: str             w0, [x25]
    //     0xad0b6c: tbz             w0, #0, #0xad0b88
    //     0xad0b70: ldurb           w16, [x1, #-1]
    //     0xad0b74: ldurb           w17, [x0, #-1]
    //     0xad0b78: and             x16, x17, x16, lsr #2
    //     0xad0b7c: tst             x16, HEAP, lsr #32
    //     0xad0b80: b.eq            #0xad0b88
    //     0xad0b84: bl              #0xd67e5c
    // 0xad0b88: ldur            x1, [fp, #-8]
    // 0xad0b8c: r17 = "values"
    //     0xad0b8c: ldr             x17, [PP, #0x7720]  ; [pp+0x7720] "values"
    // 0xad0b90: StoreField: r1->field_27 = r17
    //     0xad0b90: stur            w17, [x1, #0x27]
    // 0xad0b94: ldr             x2, [fp, #0x10]
    // 0xad0b98: LoadField: r3 = r2->field_13
    //     0xad0b98: ldur            w3, [x2, #0x13]
    // 0xad0b9c: DecompressPointer r3
    //     0xad0b9c: add             x3, x3, HEAP, lsl #32
    // 0xad0ba0: stur            x3, [fp, #-0x10]
    // 0xad0ba4: r0 = LoadClassIdInstr(r3)
    //     0xad0ba4: ldur            x0, [x3, #-1]
    //     0xad0ba8: ubfx            x0, x0, #0xc, #0x14
    // 0xad0bac: SaveReg r3
    //     0xad0bac: str             x3, [SP, #-8]!
    // 0xad0bb0: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0xad0bb0: mov             x17, #0xcc6c
    //     0xad0bb4: add             lr, x0, x17
    //     0xad0bb8: ldr             lr, [x21, lr, lsl #3]
    //     0xad0bbc: blr             lr
    // 0xad0bc0: add             SP, SP, #8
    // 0xad0bc4: tbnz            w0, #4, #0xad0bf8
    // 0xad0bc8: ldur            x0, [fp, #-0x10]
    // 0xad0bcc: r1 = LoadClassIdInstr(r0)
    //     0xad0bcc: ldur            x1, [x0, #-1]
    //     0xad0bd0: ubfx            x1, x1, #0xc, #0x14
    // 0xad0bd4: SaveReg r0
    //     0xad0bd4: str             x0, [SP, #-8]!
    // 0xad0bd8: mov             x0, x1
    // 0xad0bdc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad0bdc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad0be0: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad0be0: mov             x17, #0x3f73
    //     0xad0be4: add             lr, x0, x17
    //     0xad0be8: ldr             lr, [x21, lr, lsl #3]
    //     0xad0bec: blr             lr
    // 0xad0bf0: add             SP, SP, #8
    // 0xad0bf4: b               #0xad0bfc
    // 0xad0bf8: r0 = Null
    //     0xad0bf8: mov             x0, NULL
    // 0xad0bfc: ldr             x3, [fp, #0x10]
    // 0xad0c00: ldur            x2, [fp, #-8]
    // 0xad0c04: mov             x1, x2
    // 0xad0c08: ArrayStore: r1[7] = r0  ; List_4
    //     0xad0c08: add             x25, x1, #0x2b
    //     0xad0c0c: str             w0, [x25]
    //     0xad0c10: tbz             w0, #0, #0xad0c2c
    //     0xad0c14: ldurb           w16, [x1, #-1]
    //     0xad0c18: ldurb           w17, [x0, #-1]
    //     0xad0c1c: and             x16, x17, x16, lsr #2
    //     0xad0c20: tst             x16, HEAP, lsr #32
    //     0xad0c24: b.eq            #0xad0c2c
    //     0xad0c28: bl              #0xd67e5c
    // 0xad0c2c: r17 = "noReplyExpected"
    //     0xad0c2c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb510] "noReplyExpected"
    //     0xad0c30: ldr             x17, [x17, #0x510]
    // 0xad0c34: StoreField: r2->field_2f = r17
    //     0xad0c34: stur            w17, [x2, #0x2f]
    // 0xad0c38: LoadField: r0 = r3->field_17
    //     0xad0c38: ldur            w0, [x3, #0x17]
    // 0xad0c3c: DecompressPointer r0
    //     0xad0c3c: add             x0, x0, HEAP, lsl #32
    // 0xad0c40: tbnz            w0, #4, #0xad0c4c
    // 0xad0c44: r0 = "true"
    //     0xad0c44: ldr             x0, [PP, #0x2300]  ; [pp+0x2300] "true"
    // 0xad0c48: b               #0xad0c50
    // 0xad0c4c: r0 = Null
    //     0xad0c4c: mov             x0, NULL
    // 0xad0c50: mov             x1, x2
    // 0xad0c54: ArrayStore: r1[9] = r0  ; List_4
    //     0xad0c54: add             x25, x1, #0x33
    //     0xad0c58: str             w0, [x25]
    //     0xad0c5c: tbz             w0, #0, #0xad0c78
    //     0xad0c60: ldurb           w16, [x1, #-1]
    //     0xad0c64: ldurb           w17, [x0, #-1]
    //     0xad0c68: and             x16, x17, x16, lsr #2
    //     0xad0c6c: tst             x16, HEAP, lsr #32
    //     0xad0c70: b.eq            #0xad0c78
    //     0xad0c74: bl              #0xd67e5c
    // 0xad0c78: r17 = "noAutoStart"
    //     0xad0c78: add             x17, PP, #0xb, lsl #12  ; [pp+0xb518] "noAutoStart"
    //     0xad0c7c: ldr             x17, [x17, #0x518]
    // 0xad0c80: StoreField: r2->field_37 = r17
    //     0xad0c80: stur            w17, [x2, #0x37]
    // 0xad0c84: LoadField: r0 = r3->field_1b
    //     0xad0c84: ldur            w0, [x3, #0x1b]
    // 0xad0c88: DecompressPointer r0
    //     0xad0c88: add             x0, x0, HEAP, lsl #32
    // 0xad0c8c: tbnz            w0, #4, #0xad0c98
    // 0xad0c90: r0 = "true"
    //     0xad0c90: ldr             x0, [PP, #0x2300]  ; [pp+0x2300] "true"
    // 0xad0c94: b               #0xad0c9c
    // 0xad0c98: r0 = Null
    //     0xad0c98: mov             x0, NULL
    // 0xad0c9c: mov             x1, x2
    // 0xad0ca0: ArrayStore: r1[11] = r0  ; List_4
    //     0xad0ca0: add             x25, x1, #0x3b
    //     0xad0ca4: str             w0, [x25]
    //     0xad0ca8: tbz             w0, #0, #0xad0cc4
    //     0xad0cac: ldurb           w16, [x1, #-1]
    //     0xad0cb0: ldurb           w17, [x0, #-1]
    //     0xad0cb4: and             x16, x17, x16, lsr #2
    //     0xad0cb8: tst             x16, HEAP, lsr #32
    //     0xad0cbc: b.eq            #0xad0cc4
    //     0xad0cc0: bl              #0xd67e5c
    // 0xad0cc4: r17 = "allowInteractiveAuthorization"
    //     0xad0cc4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb520] "allowInteractiveAuthorization"
    //     0xad0cc8: ldr             x17, [x17, #0x520]
    // 0xad0ccc: StoreField: r2->field_3f = r17
    //     0xad0ccc: stur            w17, [x2, #0x3f]
    // 0xad0cd0: LoadField: r0 = r3->field_1f
    //     0xad0cd0: ldur            w0, [x3, #0x1f]
    // 0xad0cd4: DecompressPointer r0
    //     0xad0cd4: add             x0, x0, HEAP, lsl #32
    // 0xad0cd8: tbnz            w0, #4, #0xad0ce4
    // 0xad0cdc: r0 = "true"
    //     0xad0cdc: ldr             x0, [PP, #0x2300]  ; [pp+0x2300] "true"
    // 0xad0ce0: b               #0xad0ce8
    // 0xad0ce4: r0 = Null
    //     0xad0ce4: mov             x0, NULL
    // 0xad0ce8: mov             x1, x2
    // 0xad0cec: ArrayStore: r1[13] = r0  ; List_4
    //     0xad0cec: add             x25, x1, #0x43
    //     0xad0cf0: str             w0, [x25]
    //     0xad0cf4: tbz             w0, #0, #0xad0d10
    //     0xad0cf8: ldurb           w16, [x1, #-1]
    //     0xad0cfc: ldurb           w17, [x0, #-1]
    //     0xad0d00: and             x16, x17, x16, lsr #2
    //     0xad0d04: tst             x16, HEAP, lsr #32
    //     0xad0d08: b.eq            #0xad0d10
    //     0xad0d0c: bl              #0xd67e5c
    // 0xad0d10: r16 = <String, String?>
    //     0xad0d10: ldr             x16, [PP, #0x7650]  ; [pp+0x7650] TypeArguments: <String, String?>
    // 0xad0d14: stp             x2, x16, [SP, #-0x10]!
    // 0xad0d18: r0 = Map._fromLiteral()
    //     0xad0d18: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xad0d1c: add             SP, SP, #0x10
    // 0xad0d20: stur            x0, [fp, #-8]
    // 0xad0d24: r1 = 1
    //     0xad0d24: mov             x1, #1
    // 0xad0d28: r0 = AllocateContext()
    //     0xad0d28: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad0d2c: mov             x1, x0
    // 0xad0d30: ldur            x0, [fp, #-8]
    // 0xad0d34: stur            x1, [fp, #-0x10]
    // 0xad0d38: StoreField: r1->field_f = r0
    //     0xad0d38: stur            w0, [x1, #0xf]
    // 0xad0d3c: SaveReg r0
    //     0xad0d3c: str             x0, [SP, #-8]!
    // 0xad0d40: r0 = keys()
    //     0xad0d40: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0xad0d44: add             SP, SP, #8
    // 0xad0d48: ldur            x2, [fp, #-0x10]
    // 0xad0d4c: r1 = Function '<anonymous closure>':.
    //     0xad0d4c: add             x1, PP, #0xb, lsl #12  ; [pp+0xb528] AnonymousClosure: (0xacff6c), in [package:dbus/src/dbus_match_rule.dart] DBusMatchRule::toString (0xacfff0)
    //     0xad0d50: ldr             x1, [x1, #0x528]
    // 0xad0d54: stur            x0, [fp, #-8]
    // 0xad0d58: r0 = AllocateClosure()
    //     0xad0d58: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad0d5c: ldur            x16, [fp, #-8]
    // 0xad0d60: stp             x0, x16, [SP, #-0x10]!
    // 0xad0d64: r0 = where()
    //     0xad0d64: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0xad0d68: add             SP, SP, #0x10
    // 0xad0d6c: ldur            x2, [fp, #-0x10]
    // 0xad0d70: r1 = Function '<anonymous closure>':.
    //     0xad0d70: add             x1, PP, #0xb, lsl #12  ; [pp+0xb530] AnonymousClosure: (0xacfe94), in [package:dbus/src/dbus_message.dart] DBusMessage::toString (0xad0424)
    //     0xad0d74: ldr             x1, [x1, #0x530]
    // 0xad0d78: stur            x0, [fp, #-8]
    // 0xad0d7c: r0 = AllocateClosure()
    //     0xad0d7c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad0d80: r16 = <String>
    //     0xad0d80: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad0d84: ldur            lr, [fp, #-8]
    // 0xad0d88: stp             lr, x16, [SP, #-0x10]!
    // 0xad0d8c: SaveReg r0
    //     0xad0d8c: str             x0, [SP, #-8]!
    // 0xad0d90: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad0d90: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad0d94: r0 = map()
    //     0xad0d94: bl              #0x6ba568  ; [dart:_internal] WhereIterable::map
    // 0xad0d98: add             SP, SP, #0x18
    // 0xad0d9c: r16 = ", "
    //     0xad0d9c: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad0da0: stp             x16, x0, [SP, #-0x10]!
    // 0xad0da4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad0da4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad0da8: r0 = join()
    //     0xad0da8: bl              #0x6a9d88  ; [dart:core] Iterable::join
    // 0xad0dac: add             SP, SP, #0x10
    // 0xad0db0: r1 = Null
    //     0xad0db0: mov             x1, NULL
    // 0xad0db4: r2 = 8
    //     0xad0db4: mov             x2, #8
    // 0xad0db8: stur            x0, [fp, #-8]
    // 0xad0dbc: r0 = AllocateArray()
    //     0xad0dbc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0dc0: r17 = DBusMethodCall
    //     0xad0dc0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb538] Type: DBusMethodCall
    //     0xad0dc4: ldr             x17, [x17, #0x538]
    // 0xad0dc8: StoreField: r0->field_f = r17
    //     0xad0dc8: stur            w17, [x0, #0xf]
    // 0xad0dcc: r17 = "("
    //     0xad0dcc: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad0dd0: StoreField: r0->field_13 = r17
    //     0xad0dd0: stur            w17, [x0, #0x13]
    // 0xad0dd4: ldur            x1, [fp, #-8]
    // 0xad0dd8: StoreField: r0->field_17 = r1
    //     0xad0dd8: stur            w1, [x0, #0x17]
    // 0xad0ddc: r17 = ")"
    //     0xad0ddc: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad0de0: StoreField: r0->field_1b = r17
    //     0xad0de0: stur            w17, [x0, #0x1b]
    // 0xad0de4: SaveReg r0
    //     0xad0de4: str             x0, [SP, #-8]!
    // 0xad0de8: r0 = _interpolate()
    //     0xad0de8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad0dec: add             SP, SP, #8
    // 0xad0df0: LeaveFrame
    //     0xad0df0: mov             SP, fp
    //     0xad0df4: ldp             fp, lr, [SP], #0x10
    // 0xad0df8: ret
    //     0xad0df8: ret             
    // 0xad0dfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad0dfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad0e00: b               #0xad0a1c
  }
}

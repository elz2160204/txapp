// lib: , url: package:dbus/src/dbus_write_buffer.dart

// class id: 1048855, size: 0x8
class :: {
}

// class id: 4634, size: 0x98, field offset: 0x90
class DBusWriteBuffer extends DBusBuffer {

  _ writeMessage(/* No info */) {
    // ** addr: 0x9ff33c, size: 0xd6c
    // 0x9ff33c: EnterFrame
    //     0x9ff33c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ff340: mov             fp, SP
    // 0x9ff344: AllocStack(0x30)
    //     0x9ff344: sub             SP, SP, #0x30
    // 0x9ff348: CheckStackOverflow
    //     0x9ff348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ff34c: cmp             SP, x16
    //     0x9ff350: b.ls            #0xa00064
    // 0x9ff354: r0 = DBusWriteBuffer()
    //     0x9ff354: bl              #0xa02004  ; AllocateDBusWriteBufferStub -> DBusWriteBuffer (size=0x98)
    // 0x9ff358: stur            x0, [fp, #-8]
    // 0x9ff35c: SaveReg r0
    //     0x9ff35c: str             x0, [SP, #-8]!
    // 0x9ff360: r0 = DBusWriteBuffer()
    //     0x9ff360: bl              #0xa01f24  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::DBusWriteBuffer
    // 0x9ff364: add             SP, SP, #8
    // 0x9ff368: ldr             x1, [fp, #0x10]
    // 0x9ff36c: LoadField: r2 = r1->field_33
    //     0x9ff36c: ldur            w2, [x1, #0x33]
    // 0x9ff370: DecompressPointer r2
    //     0x9ff370: add             x2, x2, HEAP, lsl #32
    // 0x9ff374: stur            x2, [fp, #-0x10]
    // 0x9ff378: r0 = LoadClassIdInstr(r2)
    //     0x9ff378: ldur            x0, [x2, #-1]
    //     0x9ff37c: ubfx            x0, x0, #0xc, #0x14
    // 0x9ff380: SaveReg r2
    //     0x9ff380: str             x2, [SP, #-8]!
    // 0x9ff384: r0 = GDT[cid_x0 + 0xb940]()
    //     0x9ff384: mov             x17, #0xb940
    //     0x9ff388: add             lr, x0, x17
    //     0x9ff38c: ldr             lr, [x21, lr, lsl #3]
    //     0x9ff390: blr             lr
    // 0x9ff394: add             SP, SP, #8
    // 0x9ff398: mov             x1, x0
    // 0x9ff39c: stur            x1, [fp, #-0x18]
    // 0x9ff3a0: CheckStackOverflow
    //     0x9ff3a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ff3a4: cmp             SP, x16
    //     0x9ff3a8: b.ls            #0xa0006c
    // 0x9ff3ac: r0 = LoadClassIdInstr(r1)
    //     0x9ff3ac: ldur            x0, [x1, #-1]
    //     0x9ff3b0: ubfx            x0, x0, #0xc, #0x14
    // 0x9ff3b4: SaveReg r1
    //     0x9ff3b4: str             x1, [SP, #-8]!
    // 0x9ff3b8: r0 = GDT[cid_x0 + 0x541]()
    //     0x9ff3b8: add             lr, x0, #0x541
    //     0x9ff3bc: ldr             lr, [x21, lr, lsl #3]
    //     0x9ff3c0: blr             lr
    // 0x9ff3c4: add             SP, SP, #8
    // 0x9ff3c8: tbnz            w0, #4, #0x9ff404
    // 0x9ff3cc: ldur            x1, [fp, #-0x18]
    // 0x9ff3d0: r0 = LoadClassIdInstr(r1)
    //     0x9ff3d0: ldur            x0, [x1, #-1]
    //     0x9ff3d4: ubfx            x0, x0, #0xc, #0x14
    // 0x9ff3d8: SaveReg r1
    //     0x9ff3d8: str             x1, [SP, #-8]!
    // 0x9ff3dc: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x9ff3dc: add             lr, x0, #0x5ca
    //     0x9ff3e0: ldr             lr, [x21, lr, lsl #3]
    //     0x9ff3e4: blr             lr
    // 0x9ff3e8: add             SP, SP, #8
    // 0x9ff3ec: ldur            x16, [fp, #-8]
    // 0x9ff3f0: stp             x0, x16, [SP, #-0x10]!
    // 0x9ff3f4: r0 = writeValue()
    //     0x9ff3f4: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0x9ff3f8: add             SP, SP, #0x10
    // 0x9ff3fc: ldur            x1, [fp, #-0x18]
    // 0x9ff400: b               #0x9ff3a0
    // 0x9ff404: ldr             x0, [fp, #0x10]
    // 0x9ff408: r0 = DBusByte()
    //     0x9ff408: bl              #0xa0065c  ; AllocateDBusByteStub -> DBusByte (size=0x10)
    // 0x9ff40c: mov             x1, x0
    // 0x9ff410: r0 = 108
    //     0x9ff410: mov             x0, #0x6c
    // 0x9ff414: StoreField: r1->field_7 = r0
    //     0x9ff414: stur            x0, [x1, #7]
    // 0x9ff418: ldr             x16, [fp, #0x18]
    // 0x9ff41c: stp             x1, x16, [SP, #-0x10]!
    // 0x9ff420: r0 = writeValue()
    //     0x9ff420: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0x9ff424: add             SP, SP, #0x10
    // 0x9ff428: r1 = Null
    //     0x9ff428: mov             x1, NULL
    // 0x9ff42c: r2 = 16
    //     0x9ff42c: mov             x2, #0x10
    // 0x9ff430: r0 = AllocateArray()
    //     0x9ff430: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9ff434: r17 = Instance_DBusMessageType
    //     0x9ff434: ldr             x17, [PP, #0x7750]  ; [pp+0x7750] Obj!DBusMessageType@b667d1
    // 0x9ff438: StoreField: r0->field_f = r17
    //     0x9ff438: stur            w17, [x0, #0xf]
    // 0x9ff43c: r17 = 2
    //     0x9ff43c: mov             x17, #2
    // 0x9ff440: StoreField: r0->field_13 = r17
    //     0x9ff440: stur            w17, [x0, #0x13]
    // 0x9ff444: r17 = Instance_DBusMessageType
    //     0x9ff444: ldr             x17, [PP, #0x7818]  ; [pp+0x7818] Obj!DBusMessageType@b66791
    // 0x9ff448: StoreField: r0->field_17 = r17
    //     0x9ff448: stur            w17, [x0, #0x17]
    // 0x9ff44c: r17 = 4
    //     0x9ff44c: mov             x17, #4
    // 0x9ff450: StoreField: r0->field_1b = r17
    //     0x9ff450: stur            w17, [x0, #0x1b]
    // 0x9ff454: r17 = Instance_DBusMessageType
    //     0x9ff454: ldr             x17, [PP, #0x7820]  ; [pp+0x7820] Obj!DBusMessageType@b66771
    // 0x9ff458: StoreField: r0->field_1f = r17
    //     0x9ff458: stur            w17, [x0, #0x1f]
    // 0x9ff45c: r17 = 6
    //     0x9ff45c: mov             x17, #6
    // 0x9ff460: StoreField: r0->field_23 = r17
    //     0x9ff460: stur            w17, [x0, #0x23]
    // 0x9ff464: r17 = Instance_DBusMessageType
    //     0x9ff464: ldr             x17, [PP, #0x530]  ; [pp+0x530] Obj!DBusMessageType@b667b1
    // 0x9ff468: StoreField: r0->field_27 = r17
    //     0x9ff468: stur            w17, [x0, #0x27]
    // 0x9ff46c: r17 = 8
    //     0x9ff46c: mov             x17, #8
    // 0x9ff470: StoreField: r0->field_2b = r17
    //     0x9ff470: stur            w17, [x0, #0x2b]
    // 0x9ff474: r16 = <DBusMessageType, int>
    //     0x9ff474: ldr             x16, [PP, #0x7828]  ; [pp+0x7828] TypeArguments: <DBusMessageType, int>
    // 0x9ff478: stp             x0, x16, [SP, #-0x10]!
    // 0x9ff47c: r0 = Map._fromLiteral()
    //     0x9ff47c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9ff480: add             SP, SP, #0x10
    // 0x9ff484: mov             x1, x0
    // 0x9ff488: ldr             x0, [fp, #0x10]
    // 0x9ff48c: stur            x1, [fp, #-0x18]
    // 0x9ff490: LoadField: r2 = r0->field_7
    //     0x9ff490: ldur            w2, [x0, #7]
    // 0x9ff494: DecompressPointer r2
    //     0x9ff494: add             x2, x2, HEAP, lsl #32
    // 0x9ff498: stp             x2, x1, [SP, #-0x10]!
    // 0x9ff49c: r0 = _getValueOrData()
    //     0x9ff49c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9ff4a0: add             SP, SP, #0x10
    // 0x9ff4a4: mov             x1, x0
    // 0x9ff4a8: ldur            x0, [fp, #-0x18]
    // 0x9ff4ac: LoadField: r2 = r0->field_f
    //     0x9ff4ac: ldur            w2, [x0, #0xf]
    // 0x9ff4b0: DecompressPointer r2
    //     0x9ff4b0: add             x2, x2, HEAP, lsl #32
    // 0x9ff4b4: cmp             w2, w1
    // 0x9ff4b8: b.ne            #0x9ff4c4
    // 0x9ff4bc: r0 = Null
    //     0x9ff4bc: mov             x0, NULL
    // 0x9ff4c0: b               #0x9ff4c8
    // 0x9ff4c4: mov             x0, x1
    // 0x9ff4c8: cmp             w0, NULL
    // 0x9ff4cc: b.ne            #0x9ff4d8
    // 0x9ff4d0: r1 = 0
    //     0x9ff4d0: mov             x1, #0
    // 0x9ff4d4: b               #0x9ff4e4
    // 0x9ff4d8: r1 = LoadInt32Instr(r0)
    //     0x9ff4d8: sbfx            x1, x0, #1, #0x1f
    //     0x9ff4dc: tbz             w0, #0, #0x9ff4e4
    //     0x9ff4e0: ldur            x1, [x0, #7]
    // 0x9ff4e4: ldr             x0, [fp, #0x10]
    // 0x9ff4e8: stur            x1, [fp, #-0x20]
    // 0x9ff4ec: r0 = DBusByte()
    //     0x9ff4ec: bl              #0xa0065c  ; AllocateDBusByteStub -> DBusByte (size=0x10)
    // 0x9ff4f0: mov             x1, x0
    // 0x9ff4f4: ldur            x0, [fp, #-0x20]
    // 0x9ff4f8: StoreField: r1->field_7 = r0
    //     0x9ff4f8: stur            x0, [x1, #7]
    // 0x9ff4fc: ldr             x16, [fp, #0x18]
    // 0x9ff500: stp             x1, x16, [SP, #-0x10]!
    // 0x9ff504: r0 = writeValue()
    //     0x9ff504: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0x9ff508: add             SP, SP, #0x10
    // 0x9ff50c: ldr             x1, [fp, #0x10]
    // 0x9ff510: LoadField: r0 = r1->field_b
    //     0x9ff510: ldur            w0, [x1, #0xb]
    // 0x9ff514: DecompressPointer r0
    //     0x9ff514: add             x0, x0, HEAP, lsl #32
    // 0x9ff518: r2 = LoadClassIdInstr(r0)
    //     0x9ff518: ldur            x2, [x0, #-1]
    //     0x9ff51c: ubfx            x2, x2, #0xc, #0x14
    // 0x9ff520: SaveReg r0
    //     0x9ff520: str             x0, [SP, #-8]!
    // 0x9ff524: mov             x0, x2
    // 0x9ff528: r0 = GDT[cid_x0 + 0xb940]()
    //     0x9ff528: mov             x17, #0xb940
    //     0x9ff52c: add             lr, x0, x17
    //     0x9ff530: ldr             lr, [x21, lr, lsl #3]
    //     0x9ff534: blr             lr
    // 0x9ff538: add             SP, SP, #8
    // 0x9ff53c: mov             x1, x0
    // 0x9ff540: stur            x1, [fp, #-0x18]
    // 0x9ff544: r2 = 0
    //     0x9ff544: mov             x2, #0
    // 0x9ff548: stur            x2, [fp, #-0x20]
    // 0x9ff54c: CheckStackOverflow
    //     0x9ff54c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ff550: cmp             SP, x16
    //     0x9ff554: b.ls            #0xa00074
    // 0x9ff558: r0 = LoadClassIdInstr(r1)
    //     0x9ff558: ldur            x0, [x1, #-1]
    //     0x9ff55c: ubfx            x0, x0, #0xc, #0x14
    // 0x9ff560: SaveReg r1
    //     0x9ff560: str             x1, [SP, #-8]!
    // 0x9ff564: r0 = GDT[cid_x0 + 0x541]()
    //     0x9ff564: add             lr, x0, #0x541
    //     0x9ff568: ldr             lr, [x21, lr, lsl #3]
    //     0x9ff56c: blr             lr
    // 0x9ff570: add             SP, SP, #8
    // 0x9ff574: tbnz            w0, #4, #0x9ff64c
    // 0x9ff578: ldur            x1, [fp, #-0x18]
    // 0x9ff57c: r0 = LoadClassIdInstr(r1)
    //     0x9ff57c: ldur            x0, [x1, #-1]
    //     0x9ff580: ubfx            x0, x0, #0xc, #0x14
    // 0x9ff584: SaveReg r1
    //     0x9ff584: str             x1, [SP, #-8]!
    // 0x9ff588: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x9ff588: add             lr, x0, #0x5ca
    //     0x9ff58c: ldr             lr, [x21, lr, lsl #3]
    //     0x9ff590: blr             lr
    // 0x9ff594: add             SP, SP, #8
    // 0x9ff598: r1 = Null
    //     0x9ff598: mov             x1, NULL
    // 0x9ff59c: r2 = 12
    //     0x9ff59c: mov             x2, #0xc
    // 0x9ff5a0: stur            x0, [fp, #-0x28]
    // 0x9ff5a4: r0 = AllocateArray()
    //     0x9ff5a4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9ff5a8: r17 = Instance_DBusMessageFlag
    //     0x9ff5a8: ldr             x17, [PP, #0x7830]  ; [pp+0x7830] Obj!DBusMessageFlag@b66751
    // 0x9ff5ac: StoreField: r0->field_f = r17
    //     0x9ff5ac: stur            w17, [x0, #0xf]
    // 0x9ff5b0: r17 = 2
    //     0x9ff5b0: mov             x17, #2
    // 0x9ff5b4: StoreField: r0->field_13 = r17
    //     0x9ff5b4: stur            w17, [x0, #0x13]
    // 0x9ff5b8: r17 = Instance_DBusMessageFlag
    //     0x9ff5b8: ldr             x17, [PP, #0x7838]  ; [pp+0x7838] Obj!DBusMessageFlag@b66731
    // 0x9ff5bc: StoreField: r0->field_17 = r17
    //     0x9ff5bc: stur            w17, [x0, #0x17]
    // 0x9ff5c0: r17 = 4
    //     0x9ff5c0: mov             x17, #4
    // 0x9ff5c4: StoreField: r0->field_1b = r17
    //     0x9ff5c4: stur            w17, [x0, #0x1b]
    // 0x9ff5c8: r17 = Instance_DBusMessageFlag
    //     0x9ff5c8: ldr             x17, [PP, #0x7840]  ; [pp+0x7840] Obj!DBusMessageFlag@b66711
    // 0x9ff5cc: StoreField: r0->field_1f = r17
    //     0x9ff5cc: stur            w17, [x0, #0x1f]
    // 0x9ff5d0: r17 = 8
    //     0x9ff5d0: mov             x17, #8
    // 0x9ff5d4: StoreField: r0->field_23 = r17
    //     0x9ff5d4: stur            w17, [x0, #0x23]
    // 0x9ff5d8: r16 = <DBusMessageFlag, int>
    //     0x9ff5d8: ldr             x16, [PP, #0x7848]  ; [pp+0x7848] TypeArguments: <DBusMessageFlag, int>
    // 0x9ff5dc: stp             x0, x16, [SP, #-0x10]!
    // 0x9ff5e0: r0 = Map._fromLiteral()
    //     0x9ff5e0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9ff5e4: add             SP, SP, #0x10
    // 0x9ff5e8: stur            x0, [fp, #-0x30]
    // 0x9ff5ec: ldur            x16, [fp, #-0x28]
    // 0x9ff5f0: stp             x16, x0, [SP, #-0x10]!
    // 0x9ff5f4: r0 = _getValueOrData()
    //     0x9ff5f4: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9ff5f8: add             SP, SP, #0x10
    // 0x9ff5fc: mov             x1, x0
    // 0x9ff600: ldur            x0, [fp, #-0x30]
    // 0x9ff604: LoadField: r2 = r0->field_f
    //     0x9ff604: ldur            w2, [x0, #0xf]
    // 0x9ff608: DecompressPointer r2
    //     0x9ff608: add             x2, x2, HEAP, lsl #32
    // 0x9ff60c: cmp             w2, w1
    // 0x9ff610: b.ne            #0x9ff61c
    // 0x9ff614: r0 = Null
    //     0x9ff614: mov             x0, NULL
    // 0x9ff618: b               #0x9ff620
    // 0x9ff61c: mov             x0, x1
    // 0x9ff620: cmp             w0, NULL
    // 0x9ff624: b.ne            #0x9ff630
    // 0x9ff628: r1 = 0
    //     0x9ff628: mov             x1, #0
    // 0x9ff62c: b               #0x9ff63c
    // 0x9ff630: r1 = LoadInt32Instr(r0)
    //     0x9ff630: sbfx            x1, x0, #1, #0x1f
    //     0x9ff634: tbz             w0, #0, #0x9ff63c
    //     0x9ff638: ldur            x1, [x0, #7]
    // 0x9ff63c: ldur            x0, [fp, #-0x20]
    // 0x9ff640: orr             x2, x0, x1
    // 0x9ff644: ldur            x1, [fp, #-0x18]
    // 0x9ff648: b               #0x9ff548
    // 0x9ff64c: ldr             x1, [fp, #0x10]
    // 0x9ff650: ldur            x2, [fp, #-8]
    // 0x9ff654: ldur            x0, [fp, #-0x20]
    // 0x9ff658: r0 = DBusByte()
    //     0x9ff658: bl              #0xa0065c  ; AllocateDBusByteStub -> DBusByte (size=0x10)
    // 0x9ff65c: mov             x1, x0
    // 0x9ff660: ldur            x0, [fp, #-0x20]
    // 0x9ff664: StoreField: r1->field_7 = r0
    //     0x9ff664: stur            x0, [x1, #7]
    // 0x9ff668: ldr             x16, [fp, #0x18]
    // 0x9ff66c: stp             x1, x16, [SP, #-0x10]!
    // 0x9ff670: r0 = writeValue()
    //     0x9ff670: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0x9ff674: add             SP, SP, #0x10
    // 0x9ff678: r0 = DBusByte()
    //     0x9ff678: bl              #0xa0065c  ; AllocateDBusByteStub -> DBusByte (size=0x10)
    // 0x9ff67c: mov             x1, x0
    // 0x9ff680: r0 = 1
    //     0x9ff680: mov             x0, #1
    // 0x9ff684: StoreField: r1->field_7 = r0
    //     0x9ff684: stur            x0, [x1, #7]
    // 0x9ff688: ldr             x16, [fp, #0x18]
    // 0x9ff68c: stp             x1, x16, [SP, #-0x10]!
    // 0x9ff690: r0 = writeValue()
    //     0x9ff690: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0x9ff694: add             SP, SP, #0x10
    // 0x9ff698: ldur            x0, [fp, #-8]
    // 0x9ff69c: LoadField: r1 = r0->field_8f
    //     0x9ff69c: ldur            w1, [x0, #0x8f]
    // 0x9ff6a0: DecompressPointer r1
    //     0x9ff6a0: add             x1, x1, HEAP, lsl #32
    // 0x9ff6a4: LoadField: r2 = r1->field_b
    //     0x9ff6a4: ldur            w2, [x1, #0xb]
    // 0x9ff6a8: DecompressPointer r2
    //     0x9ff6a8: add             x2, x2, HEAP, lsl #32
    // 0x9ff6ac: r1 = LoadInt32Instr(r2)
    //     0x9ff6ac: sbfx            x1, x2, #1, #0x1f
    // 0x9ff6b0: stur            x1, [fp, #-0x20]
    // 0x9ff6b4: r0 = DBusUint32()
    //     0x9ff6b4: bl              #0xa00650  ; AllocateDBusUint32Stub -> DBusUint32 (size=0x10)
    // 0x9ff6b8: mov             x1, x0
    // 0x9ff6bc: ldur            x0, [fp, #-0x20]
    // 0x9ff6c0: StoreField: r1->field_7 = r0
    //     0x9ff6c0: stur            x0, [x1, #7]
    // 0x9ff6c4: ldr             x16, [fp, #0x18]
    // 0x9ff6c8: stp             x1, x16, [SP, #-0x10]!
    // 0x9ff6cc: r0 = writeValue()
    //     0x9ff6cc: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0x9ff6d0: add             SP, SP, #0x10
    // 0x9ff6d4: ldr             x0, [fp, #0x10]
    // 0x9ff6d8: LoadField: r1 = r0->field_f
    //     0x9ff6d8: ldur            x1, [x0, #0xf]
    // 0x9ff6dc: stur            x1, [fp, #-0x20]
    // 0x9ff6e0: r0 = DBusUint32()
    //     0x9ff6e0: bl              #0xa00650  ; AllocateDBusUint32Stub -> DBusUint32 (size=0x10)
    // 0x9ff6e4: mov             x1, x0
    // 0x9ff6e8: ldur            x0, [fp, #-0x20]
    // 0x9ff6ec: StoreField: r1->field_7 = r0
    //     0x9ff6ec: stur            x0, [x1, #7]
    // 0x9ff6f0: ldr             x16, [fp, #0x18]
    // 0x9ff6f4: stp             x1, x16, [SP, #-0x10]!
    // 0x9ff6f8: r0 = writeValue()
    //     0x9ff6f8: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0x9ff6fc: add             SP, SP, #0x10
    // 0x9ff700: r16 = <DBusValue>
    //     0x9ff700: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0x9ff704: stp             xzr, x16, [SP, #-0x10]!
    // 0x9ff708: r0 = _GrowableList()
    //     0x9ff708: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ff70c: add             SP, SP, #0x10
    // 0x9ff710: mov             x1, x0
    // 0x9ff714: ldr             x0, [fp, #0x10]
    // 0x9ff718: stur            x1, [fp, #-0x18]
    // 0x9ff71c: LoadField: r2 = r0->field_17
    //     0x9ff71c: ldur            w2, [x0, #0x17]
    // 0x9ff720: DecompressPointer r2
    //     0x9ff720: add             x2, x2, HEAP, lsl #32
    // 0x9ff724: cmp             w2, NULL
    // 0x9ff728: b.eq            #0x9ff7dc
    // 0x9ff72c: r3 = 1
    //     0x9ff72c: mov             x3, #1
    // 0x9ff730: ldr             x16, [fp, #0x18]
    // 0x9ff734: stp             x3, x16, [SP, #-0x10]!
    // 0x9ff738: SaveReg r2
    //     0x9ff738: str             x2, [SP, #-8]!
    // 0x9ff73c: r0 = _makeHeader()
    //     0x9ff73c: bl              #0xa00584  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::_makeHeader
    // 0x9ff740: add             SP, SP, #0x18
    // 0x9ff744: mov             x1, x0
    // 0x9ff748: ldur            x0, [fp, #-0x18]
    // 0x9ff74c: stur            x1, [fp, #-0x30]
    // 0x9ff750: LoadField: r2 = r0->field_b
    //     0x9ff750: ldur            w2, [x0, #0xb]
    // 0x9ff754: DecompressPointer r2
    //     0x9ff754: add             x2, x2, HEAP, lsl #32
    // 0x9ff758: stur            x2, [fp, #-0x28]
    // 0x9ff75c: LoadField: r3 = r0->field_f
    //     0x9ff75c: ldur            w3, [x0, #0xf]
    // 0x9ff760: DecompressPointer r3
    //     0x9ff760: add             x3, x3, HEAP, lsl #32
    // 0x9ff764: LoadField: r4 = r3->field_b
    //     0x9ff764: ldur            w4, [x3, #0xb]
    // 0x9ff768: DecompressPointer r4
    //     0x9ff768: add             x4, x4, HEAP, lsl #32
    // 0x9ff76c: cmp             w2, w4
    // 0x9ff770: b.ne            #0x9ff780
    // 0x9ff774: SaveReg r0
    //     0x9ff774: str             x0, [SP, #-8]!
    // 0x9ff778: r0 = _growToNextCapacity()
    //     0x9ff778: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ff77c: add             SP, SP, #8
    // 0x9ff780: ldur            x2, [fp, #-0x18]
    // 0x9ff784: ldur            x0, [fp, #-0x28]
    // 0x9ff788: r3 = LoadInt32Instr(r0)
    //     0x9ff788: sbfx            x3, x0, #1, #0x1f
    // 0x9ff78c: add             x0, x3, #1
    // 0x9ff790: lsl             x1, x0, #1
    // 0x9ff794: StoreField: r2->field_b = r1
    //     0x9ff794: stur            w1, [x2, #0xb]
    // 0x9ff798: mov             x1, x3
    // 0x9ff79c: cmp             x1, x0
    // 0x9ff7a0: b.hs            #0xa0007c
    // 0x9ff7a4: LoadField: r1 = r2->field_f
    //     0x9ff7a4: ldur            w1, [x2, #0xf]
    // 0x9ff7a8: DecompressPointer r1
    //     0x9ff7a8: add             x1, x1, HEAP, lsl #32
    // 0x9ff7ac: ldur            x0, [fp, #-0x30]
    // 0x9ff7b0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ff7b0: add             x25, x1, x3, lsl #2
    //     0x9ff7b4: add             x25, x25, #0xf
    //     0x9ff7b8: str             w0, [x25]
    //     0x9ff7bc: tbz             w0, #0, #0x9ff7d8
    //     0x9ff7c0: ldurb           w16, [x1, #-1]
    //     0x9ff7c4: ldurb           w17, [x0, #-1]
    //     0x9ff7c8: and             x16, x17, x16, lsr #2
    //     0x9ff7cc: tst             x16, HEAP, lsr #32
    //     0x9ff7d0: b.eq            #0x9ff7d8
    //     0x9ff7d4: bl              #0xd67e5c
    // 0x9ff7d8: b               #0x9ff7e0
    // 0x9ff7dc: mov             x2, x1
    // 0x9ff7e0: ldr             x0, [fp, #0x10]
    // 0x9ff7e4: LoadField: r1 = r0->field_1b
    //     0x9ff7e4: ldur            w1, [x0, #0x1b]
    // 0x9ff7e8: DecompressPointer r1
    //     0x9ff7e8: add             x1, x1, HEAP, lsl #32
    // 0x9ff7ec: cmp             w1, NULL
    // 0x9ff7f0: b.eq            #0x9ff8bc
    // 0x9ff7f4: LoadField: r3 = r1->field_7
    //     0x9ff7f4: ldur            w3, [x1, #7]
    // 0x9ff7f8: DecompressPointer r3
    //     0x9ff7f8: add             x3, x3, HEAP, lsl #32
    // 0x9ff7fc: stur            x3, [fp, #-0x28]
    // 0x9ff800: r0 = DBusString()
    //     0x9ff800: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0x9ff804: mov             x1, x0
    // 0x9ff808: ldur            x0, [fp, #-0x28]
    // 0x9ff80c: StoreField: r1->field_7 = r0
    //     0x9ff80c: stur            w0, [x1, #7]
    // 0x9ff810: ldr             x16, [fp, #0x18]
    // 0x9ff814: SaveReg r16
    //     0x9ff814: str             x16, [SP, #-8]!
    // 0x9ff818: r0 = 2
    //     0x9ff818: mov             x0, #2
    // 0x9ff81c: stp             x1, x0, [SP, #-0x10]!
    // 0x9ff820: r0 = _makeHeader()
    //     0x9ff820: bl              #0xa00584  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::_makeHeader
    // 0x9ff824: add             SP, SP, #0x18
    // 0x9ff828: mov             x1, x0
    // 0x9ff82c: ldur            x0, [fp, #-0x18]
    // 0x9ff830: stur            x1, [fp, #-0x30]
    // 0x9ff834: LoadField: r2 = r0->field_b
    //     0x9ff834: ldur            w2, [x0, #0xb]
    // 0x9ff838: DecompressPointer r2
    //     0x9ff838: add             x2, x2, HEAP, lsl #32
    // 0x9ff83c: stur            x2, [fp, #-0x28]
    // 0x9ff840: LoadField: r3 = r0->field_f
    //     0x9ff840: ldur            w3, [x0, #0xf]
    // 0x9ff844: DecompressPointer r3
    //     0x9ff844: add             x3, x3, HEAP, lsl #32
    // 0x9ff848: LoadField: r4 = r3->field_b
    //     0x9ff848: ldur            w4, [x3, #0xb]
    // 0x9ff84c: DecompressPointer r4
    //     0x9ff84c: add             x4, x4, HEAP, lsl #32
    // 0x9ff850: cmp             w2, w4
    // 0x9ff854: b.ne            #0x9ff864
    // 0x9ff858: SaveReg r0
    //     0x9ff858: str             x0, [SP, #-8]!
    // 0x9ff85c: r0 = _growToNextCapacity()
    //     0x9ff85c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ff860: add             SP, SP, #8
    // 0x9ff864: ldur            x2, [fp, #-0x18]
    // 0x9ff868: ldur            x0, [fp, #-0x28]
    // 0x9ff86c: r3 = LoadInt32Instr(r0)
    //     0x9ff86c: sbfx            x3, x0, #1, #0x1f
    // 0x9ff870: add             x0, x3, #1
    // 0x9ff874: lsl             x1, x0, #1
    // 0x9ff878: StoreField: r2->field_b = r1
    //     0x9ff878: stur            w1, [x2, #0xb]
    // 0x9ff87c: mov             x1, x3
    // 0x9ff880: cmp             x1, x0
    // 0x9ff884: b.hs            #0xa00080
    // 0x9ff888: LoadField: r1 = r2->field_f
    //     0x9ff888: ldur            w1, [x2, #0xf]
    // 0x9ff88c: DecompressPointer r1
    //     0x9ff88c: add             x1, x1, HEAP, lsl #32
    // 0x9ff890: ldur            x0, [fp, #-0x30]
    // 0x9ff894: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ff894: add             x25, x1, x3, lsl #2
    //     0x9ff898: add             x25, x25, #0xf
    //     0x9ff89c: str             w0, [x25]
    //     0x9ff8a0: tbz             w0, #0, #0x9ff8bc
    //     0x9ff8a4: ldurb           w16, [x1, #-1]
    //     0x9ff8a8: ldurb           w17, [x0, #-1]
    //     0x9ff8ac: and             x16, x17, x16, lsr #2
    //     0x9ff8b0: tst             x16, HEAP, lsr #32
    //     0x9ff8b4: b.eq            #0x9ff8bc
    //     0x9ff8b8: bl              #0xd67e5c
    // 0x9ff8bc: ldr             x0, [fp, #0x10]
    // 0x9ff8c0: LoadField: r1 = r0->field_1f
    //     0x9ff8c0: ldur            w1, [x0, #0x1f]
    // 0x9ff8c4: DecompressPointer r1
    //     0x9ff8c4: add             x1, x1, HEAP, lsl #32
    // 0x9ff8c8: cmp             w1, NULL
    // 0x9ff8cc: b.eq            #0x9ff998
    // 0x9ff8d0: LoadField: r3 = r1->field_7
    //     0x9ff8d0: ldur            w3, [x1, #7]
    // 0x9ff8d4: DecompressPointer r3
    //     0x9ff8d4: add             x3, x3, HEAP, lsl #32
    // 0x9ff8d8: stur            x3, [fp, #-0x28]
    // 0x9ff8dc: r0 = DBusString()
    //     0x9ff8dc: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0x9ff8e0: mov             x1, x0
    // 0x9ff8e4: ldur            x0, [fp, #-0x28]
    // 0x9ff8e8: StoreField: r1->field_7 = r0
    //     0x9ff8e8: stur            w0, [x1, #7]
    // 0x9ff8ec: ldr             x16, [fp, #0x18]
    // 0x9ff8f0: SaveReg r16
    //     0x9ff8f0: str             x16, [SP, #-8]!
    // 0x9ff8f4: r0 = 3
    //     0x9ff8f4: mov             x0, #3
    // 0x9ff8f8: stp             x1, x0, [SP, #-0x10]!
    // 0x9ff8fc: r0 = _makeHeader()
    //     0x9ff8fc: bl              #0xa00584  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::_makeHeader
    // 0x9ff900: add             SP, SP, #0x18
    // 0x9ff904: mov             x1, x0
    // 0x9ff908: ldur            x0, [fp, #-0x18]
    // 0x9ff90c: stur            x1, [fp, #-0x30]
    // 0x9ff910: LoadField: r2 = r0->field_b
    //     0x9ff910: ldur            w2, [x0, #0xb]
    // 0x9ff914: DecompressPointer r2
    //     0x9ff914: add             x2, x2, HEAP, lsl #32
    // 0x9ff918: stur            x2, [fp, #-0x28]
    // 0x9ff91c: LoadField: r3 = r0->field_f
    //     0x9ff91c: ldur            w3, [x0, #0xf]
    // 0x9ff920: DecompressPointer r3
    //     0x9ff920: add             x3, x3, HEAP, lsl #32
    // 0x9ff924: LoadField: r4 = r3->field_b
    //     0x9ff924: ldur            w4, [x3, #0xb]
    // 0x9ff928: DecompressPointer r4
    //     0x9ff928: add             x4, x4, HEAP, lsl #32
    // 0x9ff92c: cmp             w2, w4
    // 0x9ff930: b.ne            #0x9ff940
    // 0x9ff934: SaveReg r0
    //     0x9ff934: str             x0, [SP, #-8]!
    // 0x9ff938: r0 = _growToNextCapacity()
    //     0x9ff938: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ff93c: add             SP, SP, #8
    // 0x9ff940: ldur            x2, [fp, #-0x18]
    // 0x9ff944: ldur            x0, [fp, #-0x28]
    // 0x9ff948: r3 = LoadInt32Instr(r0)
    //     0x9ff948: sbfx            x3, x0, #1, #0x1f
    // 0x9ff94c: add             x0, x3, #1
    // 0x9ff950: lsl             x1, x0, #1
    // 0x9ff954: StoreField: r2->field_b = r1
    //     0x9ff954: stur            w1, [x2, #0xb]
    // 0x9ff958: mov             x1, x3
    // 0x9ff95c: cmp             x1, x0
    // 0x9ff960: b.hs            #0xa00084
    // 0x9ff964: LoadField: r1 = r2->field_f
    //     0x9ff964: ldur            w1, [x2, #0xf]
    // 0x9ff968: DecompressPointer r1
    //     0x9ff968: add             x1, x1, HEAP, lsl #32
    // 0x9ff96c: ldur            x0, [fp, #-0x30]
    // 0x9ff970: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ff970: add             x25, x1, x3, lsl #2
    //     0x9ff974: add             x25, x25, #0xf
    //     0x9ff978: str             w0, [x25]
    //     0x9ff97c: tbz             w0, #0, #0x9ff998
    //     0x9ff980: ldurb           w16, [x1, #-1]
    //     0x9ff984: ldurb           w17, [x0, #-1]
    //     0x9ff988: and             x16, x17, x16, lsr #2
    //     0x9ff98c: tst             x16, HEAP, lsr #32
    //     0x9ff990: b.eq            #0x9ff998
    //     0x9ff994: bl              #0xd67e5c
    // 0x9ff998: ldr             x0, [fp, #0x10]
    // 0x9ff99c: LoadField: r1 = r0->field_23
    //     0x9ff99c: ldur            w1, [x0, #0x23]
    // 0x9ff9a0: DecompressPointer r1
    //     0x9ff9a0: add             x1, x1, HEAP, lsl #32
    // 0x9ff9a4: cmp             w1, NULL
    // 0x9ff9a8: b.eq            #0x9ffa74
    // 0x9ff9ac: LoadField: r3 = r1->field_7
    //     0x9ff9ac: ldur            w3, [x1, #7]
    // 0x9ff9b0: DecompressPointer r3
    //     0x9ff9b0: add             x3, x3, HEAP, lsl #32
    // 0x9ff9b4: stur            x3, [fp, #-0x28]
    // 0x9ff9b8: r0 = DBusString()
    //     0x9ff9b8: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0x9ff9bc: mov             x1, x0
    // 0x9ff9c0: ldur            x0, [fp, #-0x28]
    // 0x9ff9c4: StoreField: r1->field_7 = r0
    //     0x9ff9c4: stur            w0, [x1, #7]
    // 0x9ff9c8: ldr             x16, [fp, #0x18]
    // 0x9ff9cc: SaveReg r16
    //     0x9ff9cc: str             x16, [SP, #-8]!
    // 0x9ff9d0: r0 = 4
    //     0x9ff9d0: mov             x0, #4
    // 0x9ff9d4: stp             x1, x0, [SP, #-0x10]!
    // 0x9ff9d8: r0 = _makeHeader()
    //     0x9ff9d8: bl              #0xa00584  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::_makeHeader
    // 0x9ff9dc: add             SP, SP, #0x18
    // 0x9ff9e0: mov             x1, x0
    // 0x9ff9e4: ldur            x0, [fp, #-0x18]
    // 0x9ff9e8: stur            x1, [fp, #-0x30]
    // 0x9ff9ec: LoadField: r2 = r0->field_b
    //     0x9ff9ec: ldur            w2, [x0, #0xb]
    // 0x9ff9f0: DecompressPointer r2
    //     0x9ff9f0: add             x2, x2, HEAP, lsl #32
    // 0x9ff9f4: stur            x2, [fp, #-0x28]
    // 0x9ff9f8: LoadField: r3 = r0->field_f
    //     0x9ff9f8: ldur            w3, [x0, #0xf]
    // 0x9ff9fc: DecompressPointer r3
    //     0x9ff9fc: add             x3, x3, HEAP, lsl #32
    // 0x9ffa00: LoadField: r4 = r3->field_b
    //     0x9ffa00: ldur            w4, [x3, #0xb]
    // 0x9ffa04: DecompressPointer r4
    //     0x9ffa04: add             x4, x4, HEAP, lsl #32
    // 0x9ffa08: cmp             w2, w4
    // 0x9ffa0c: b.ne            #0x9ffa1c
    // 0x9ffa10: SaveReg r0
    //     0x9ffa10: str             x0, [SP, #-8]!
    // 0x9ffa14: r0 = _growToNextCapacity()
    //     0x9ffa14: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ffa18: add             SP, SP, #8
    // 0x9ffa1c: ldur            x2, [fp, #-0x18]
    // 0x9ffa20: ldur            x0, [fp, #-0x28]
    // 0x9ffa24: r3 = LoadInt32Instr(r0)
    //     0x9ffa24: sbfx            x3, x0, #1, #0x1f
    // 0x9ffa28: add             x0, x3, #1
    // 0x9ffa2c: lsl             x1, x0, #1
    // 0x9ffa30: StoreField: r2->field_b = r1
    //     0x9ffa30: stur            w1, [x2, #0xb]
    // 0x9ffa34: mov             x1, x3
    // 0x9ffa38: cmp             x1, x0
    // 0x9ffa3c: b.hs            #0xa00088
    // 0x9ffa40: LoadField: r1 = r2->field_f
    //     0x9ffa40: ldur            w1, [x2, #0xf]
    // 0x9ffa44: DecompressPointer r1
    //     0x9ffa44: add             x1, x1, HEAP, lsl #32
    // 0x9ffa48: ldur            x0, [fp, #-0x30]
    // 0x9ffa4c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ffa4c: add             x25, x1, x3, lsl #2
    //     0x9ffa50: add             x25, x25, #0xf
    //     0x9ffa54: str             w0, [x25]
    //     0x9ffa58: tbz             w0, #0, #0x9ffa74
    //     0x9ffa5c: ldurb           w16, [x1, #-1]
    //     0x9ffa60: ldurb           w17, [x0, #-1]
    //     0x9ffa64: and             x16, x17, x16, lsr #2
    //     0x9ffa68: tst             x16, HEAP, lsr #32
    //     0x9ffa6c: b.eq            #0x9ffa74
    //     0x9ffa70: bl              #0xd67e5c
    // 0x9ffa74: ldr             x0, [fp, #0x10]
    // 0x9ffa78: LoadField: r1 = r0->field_27
    //     0x9ffa78: ldur            w1, [x0, #0x27]
    // 0x9ffa7c: DecompressPointer r1
    //     0x9ffa7c: add             x1, x1, HEAP, lsl #32
    // 0x9ffa80: cmp             w1, NULL
    // 0x9ffa84: b.eq            #0x9ffb54
    // 0x9ffa88: r3 = LoadInt32Instr(r1)
    //     0x9ffa88: sbfx            x3, x1, #1, #0x1f
    //     0x9ffa8c: tbz             w1, #0, #0x9ffa94
    //     0x9ffa90: ldur            x3, [x1, #7]
    // 0x9ffa94: stur            x3, [fp, #-0x20]
    // 0x9ffa98: r0 = DBusUint32()
    //     0x9ffa98: bl              #0xa00650  ; AllocateDBusUint32Stub -> DBusUint32 (size=0x10)
    // 0x9ffa9c: mov             x1, x0
    // 0x9ffaa0: ldur            x0, [fp, #-0x20]
    // 0x9ffaa4: StoreField: r1->field_7 = r0
    //     0x9ffaa4: stur            x0, [x1, #7]
    // 0x9ffaa8: ldr             x16, [fp, #0x18]
    // 0x9ffaac: SaveReg r16
    //     0x9ffaac: str             x16, [SP, #-8]!
    // 0x9ffab0: r0 = 5
    //     0x9ffab0: mov             x0, #5
    // 0x9ffab4: stp             x1, x0, [SP, #-0x10]!
    // 0x9ffab8: r0 = _makeHeader()
    //     0x9ffab8: bl              #0xa00584  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::_makeHeader
    // 0x9ffabc: add             SP, SP, #0x18
    // 0x9ffac0: mov             x1, x0
    // 0x9ffac4: ldur            x0, [fp, #-0x18]
    // 0x9ffac8: stur            x1, [fp, #-0x30]
    // 0x9ffacc: LoadField: r2 = r0->field_b
    //     0x9ffacc: ldur            w2, [x0, #0xb]
    // 0x9ffad0: DecompressPointer r2
    //     0x9ffad0: add             x2, x2, HEAP, lsl #32
    // 0x9ffad4: stur            x2, [fp, #-0x28]
    // 0x9ffad8: LoadField: r3 = r0->field_f
    //     0x9ffad8: ldur            w3, [x0, #0xf]
    // 0x9ffadc: DecompressPointer r3
    //     0x9ffadc: add             x3, x3, HEAP, lsl #32
    // 0x9ffae0: LoadField: r4 = r3->field_b
    //     0x9ffae0: ldur            w4, [x3, #0xb]
    // 0x9ffae4: DecompressPointer r4
    //     0x9ffae4: add             x4, x4, HEAP, lsl #32
    // 0x9ffae8: cmp             w2, w4
    // 0x9ffaec: b.ne            #0x9ffafc
    // 0x9ffaf0: SaveReg r0
    //     0x9ffaf0: str             x0, [SP, #-8]!
    // 0x9ffaf4: r0 = _growToNextCapacity()
    //     0x9ffaf4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ffaf8: add             SP, SP, #8
    // 0x9ffafc: ldur            x2, [fp, #-0x18]
    // 0x9ffb00: ldur            x0, [fp, #-0x28]
    // 0x9ffb04: r3 = LoadInt32Instr(r0)
    //     0x9ffb04: sbfx            x3, x0, #1, #0x1f
    // 0x9ffb08: add             x0, x3, #1
    // 0x9ffb0c: lsl             x1, x0, #1
    // 0x9ffb10: StoreField: r2->field_b = r1
    //     0x9ffb10: stur            w1, [x2, #0xb]
    // 0x9ffb14: mov             x1, x3
    // 0x9ffb18: cmp             x1, x0
    // 0x9ffb1c: b.hs            #0xa0008c
    // 0x9ffb20: LoadField: r1 = r2->field_f
    //     0x9ffb20: ldur            w1, [x2, #0xf]
    // 0x9ffb24: DecompressPointer r1
    //     0x9ffb24: add             x1, x1, HEAP, lsl #32
    // 0x9ffb28: ldur            x0, [fp, #-0x30]
    // 0x9ffb2c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ffb2c: add             x25, x1, x3, lsl #2
    //     0x9ffb30: add             x25, x25, #0xf
    //     0x9ffb34: str             w0, [x25]
    //     0x9ffb38: tbz             w0, #0, #0x9ffb54
    //     0x9ffb3c: ldurb           w16, [x1, #-1]
    //     0x9ffb40: ldurb           w17, [x0, #-1]
    //     0x9ffb44: and             x16, x17, x16, lsr #2
    //     0x9ffb48: tst             x16, HEAP, lsr #32
    //     0x9ffb4c: b.eq            #0x9ffb54
    //     0x9ffb50: bl              #0xd67e5c
    // 0x9ffb54: ldr             x0, [fp, #0x10]
    // 0x9ffb58: LoadField: r1 = r0->field_2b
    //     0x9ffb58: ldur            w1, [x0, #0x2b]
    // 0x9ffb5c: DecompressPointer r1
    //     0x9ffb5c: add             x1, x1, HEAP, lsl #32
    // 0x9ffb60: cmp             w1, NULL
    // 0x9ffb64: b.eq            #0x9ffc30
    // 0x9ffb68: LoadField: r3 = r1->field_7
    //     0x9ffb68: ldur            w3, [x1, #7]
    // 0x9ffb6c: DecompressPointer r3
    //     0x9ffb6c: add             x3, x3, HEAP, lsl #32
    // 0x9ffb70: stur            x3, [fp, #-0x28]
    // 0x9ffb74: r0 = DBusString()
    //     0x9ffb74: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0x9ffb78: mov             x1, x0
    // 0x9ffb7c: ldur            x0, [fp, #-0x28]
    // 0x9ffb80: StoreField: r1->field_7 = r0
    //     0x9ffb80: stur            w0, [x1, #7]
    // 0x9ffb84: ldr             x16, [fp, #0x18]
    // 0x9ffb88: SaveReg r16
    //     0x9ffb88: str             x16, [SP, #-8]!
    // 0x9ffb8c: r0 = 6
    //     0x9ffb8c: mov             x0, #6
    // 0x9ffb90: stp             x1, x0, [SP, #-0x10]!
    // 0x9ffb94: r0 = _makeHeader()
    //     0x9ffb94: bl              #0xa00584  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::_makeHeader
    // 0x9ffb98: add             SP, SP, #0x18
    // 0x9ffb9c: mov             x1, x0
    // 0x9ffba0: ldur            x0, [fp, #-0x18]
    // 0x9ffba4: stur            x1, [fp, #-0x30]
    // 0x9ffba8: LoadField: r2 = r0->field_b
    //     0x9ffba8: ldur            w2, [x0, #0xb]
    // 0x9ffbac: DecompressPointer r2
    //     0x9ffbac: add             x2, x2, HEAP, lsl #32
    // 0x9ffbb0: stur            x2, [fp, #-0x28]
    // 0x9ffbb4: LoadField: r3 = r0->field_f
    //     0x9ffbb4: ldur            w3, [x0, #0xf]
    // 0x9ffbb8: DecompressPointer r3
    //     0x9ffbb8: add             x3, x3, HEAP, lsl #32
    // 0x9ffbbc: LoadField: r4 = r3->field_b
    //     0x9ffbbc: ldur            w4, [x3, #0xb]
    // 0x9ffbc0: DecompressPointer r4
    //     0x9ffbc0: add             x4, x4, HEAP, lsl #32
    // 0x9ffbc4: cmp             w2, w4
    // 0x9ffbc8: b.ne            #0x9ffbd8
    // 0x9ffbcc: SaveReg r0
    //     0x9ffbcc: str             x0, [SP, #-8]!
    // 0x9ffbd0: r0 = _growToNextCapacity()
    //     0x9ffbd0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ffbd4: add             SP, SP, #8
    // 0x9ffbd8: ldur            x2, [fp, #-0x18]
    // 0x9ffbdc: ldur            x0, [fp, #-0x28]
    // 0x9ffbe0: r3 = LoadInt32Instr(r0)
    //     0x9ffbe0: sbfx            x3, x0, #1, #0x1f
    // 0x9ffbe4: add             x0, x3, #1
    // 0x9ffbe8: lsl             x1, x0, #1
    // 0x9ffbec: StoreField: r2->field_b = r1
    //     0x9ffbec: stur            w1, [x2, #0xb]
    // 0x9ffbf0: mov             x1, x3
    // 0x9ffbf4: cmp             x1, x0
    // 0x9ffbf8: b.hs            #0xa00090
    // 0x9ffbfc: LoadField: r1 = r2->field_f
    //     0x9ffbfc: ldur            w1, [x2, #0xf]
    // 0x9ffc00: DecompressPointer r1
    //     0x9ffc00: add             x1, x1, HEAP, lsl #32
    // 0x9ffc04: ldur            x0, [fp, #-0x30]
    // 0x9ffc08: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ffc08: add             x25, x1, x3, lsl #2
    //     0x9ffc0c: add             x25, x25, #0xf
    //     0x9ffc10: str             w0, [x25]
    //     0x9ffc14: tbz             w0, #0, #0x9ffc30
    //     0x9ffc18: ldurb           w16, [x1, #-1]
    //     0x9ffc1c: ldurb           w17, [x0, #-1]
    //     0x9ffc20: and             x16, x17, x16, lsr #2
    //     0x9ffc24: tst             x16, HEAP, lsr #32
    //     0x9ffc28: b.eq            #0x9ffc30
    //     0x9ffc2c: bl              #0xd67e5c
    // 0x9ffc30: ldr             x0, [fp, #0x10]
    // 0x9ffc34: LoadField: r1 = r0->field_2f
    //     0x9ffc34: ldur            w1, [x0, #0x2f]
    // 0x9ffc38: DecompressPointer r1
    //     0x9ffc38: add             x1, x1, HEAP, lsl #32
    // 0x9ffc3c: cmp             w1, NULL
    // 0x9ffc40: b.eq            #0x9ffd0c
    // 0x9ffc44: LoadField: r0 = r1->field_7
    //     0x9ffc44: ldur            w0, [x1, #7]
    // 0x9ffc48: DecompressPointer r0
    //     0x9ffc48: add             x0, x0, HEAP, lsl #32
    // 0x9ffc4c: stur            x0, [fp, #-0x28]
    // 0x9ffc50: r0 = DBusString()
    //     0x9ffc50: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0x9ffc54: mov             x1, x0
    // 0x9ffc58: ldur            x0, [fp, #-0x28]
    // 0x9ffc5c: StoreField: r1->field_7 = r0
    //     0x9ffc5c: stur            w0, [x1, #7]
    // 0x9ffc60: ldr             x16, [fp, #0x18]
    // 0x9ffc64: SaveReg r16
    //     0x9ffc64: str             x16, [SP, #-8]!
    // 0x9ffc68: r0 = 7
    //     0x9ffc68: mov             x0, #7
    // 0x9ffc6c: stp             x1, x0, [SP, #-0x10]!
    // 0x9ffc70: r0 = _makeHeader()
    //     0x9ffc70: bl              #0xa00584  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::_makeHeader
    // 0x9ffc74: add             SP, SP, #0x18
    // 0x9ffc78: mov             x1, x0
    // 0x9ffc7c: ldur            x0, [fp, #-0x18]
    // 0x9ffc80: stur            x1, [fp, #-0x30]
    // 0x9ffc84: LoadField: r2 = r0->field_b
    //     0x9ffc84: ldur            w2, [x0, #0xb]
    // 0x9ffc88: DecompressPointer r2
    //     0x9ffc88: add             x2, x2, HEAP, lsl #32
    // 0x9ffc8c: stur            x2, [fp, #-0x28]
    // 0x9ffc90: LoadField: r3 = r0->field_f
    //     0x9ffc90: ldur            w3, [x0, #0xf]
    // 0x9ffc94: DecompressPointer r3
    //     0x9ffc94: add             x3, x3, HEAP, lsl #32
    // 0x9ffc98: LoadField: r4 = r3->field_b
    //     0x9ffc98: ldur            w4, [x3, #0xb]
    // 0x9ffc9c: DecompressPointer r4
    //     0x9ffc9c: add             x4, x4, HEAP, lsl #32
    // 0x9ffca0: cmp             w2, w4
    // 0x9ffca4: b.ne            #0x9ffcb4
    // 0x9ffca8: SaveReg r0
    //     0x9ffca8: str             x0, [SP, #-8]!
    // 0x9ffcac: r0 = _growToNextCapacity()
    //     0x9ffcac: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ffcb0: add             SP, SP, #8
    // 0x9ffcb4: ldur            x2, [fp, #-0x18]
    // 0x9ffcb8: ldur            x0, [fp, #-0x28]
    // 0x9ffcbc: r3 = LoadInt32Instr(r0)
    //     0x9ffcbc: sbfx            x3, x0, #1, #0x1f
    // 0x9ffcc0: add             x0, x3, #1
    // 0x9ffcc4: lsl             x1, x0, #1
    // 0x9ffcc8: StoreField: r2->field_b = r1
    //     0x9ffcc8: stur            w1, [x2, #0xb]
    // 0x9ffccc: mov             x1, x3
    // 0x9ffcd0: cmp             x1, x0
    // 0x9ffcd4: b.hs            #0xa00094
    // 0x9ffcd8: LoadField: r1 = r2->field_f
    //     0x9ffcd8: ldur            w1, [x2, #0xf]
    // 0x9ffcdc: DecompressPointer r1
    //     0x9ffcdc: add             x1, x1, HEAP, lsl #32
    // 0x9ffce0: ldur            x0, [fp, #-0x30]
    // 0x9ffce4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ffce4: add             x25, x1, x3, lsl #2
    //     0x9ffce8: add             x25, x25, #0xf
    //     0x9ffcec: str             w0, [x25]
    //     0x9ffcf0: tbz             w0, #0, #0x9ffd0c
    //     0x9ffcf4: ldurb           w16, [x1, #-1]
    //     0x9ffcf8: ldurb           w17, [x0, #-1]
    //     0x9ffcfc: and             x16, x17, x16, lsr #2
    //     0x9ffd00: tst             x16, HEAP, lsr #32
    //     0x9ffd04: b.eq            #0x9ffd0c
    //     0x9ffd08: bl              #0xd67e5c
    // 0x9ffd0c: ldur            x1, [fp, #-0x10]
    // 0x9ffd10: r0 = LoadClassIdInstr(r1)
    //     0x9ffd10: ldur            x0, [x1, #-1]
    //     0x9ffd14: ubfx            x0, x0, #0xc, #0x14
    // 0x9ffd18: SaveReg r1
    //     0x9ffd18: str             x1, [SP, #-8]!
    // 0x9ffd1c: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0x9ffd1c: mov             x17, #0xcc6c
    //     0x9ffd20: add             lr, x0, x17
    //     0x9ffd24: ldr             lr, [x21, lr, lsl #3]
    //     0x9ffd28: blr             lr
    // 0x9ffd2c: add             SP, SP, #8
    // 0x9ffd30: tbnz            w0, #4, #0x9ffecc
    // 0x9ffd34: ldur            x0, [fp, #-0x10]
    // 0x9ffd38: r1 = LoadClassIdInstr(r0)
    //     0x9ffd38: ldur            x1, [x0, #-1]
    //     0x9ffd3c: ubfx            x1, x1, #0xc, #0x14
    // 0x9ffd40: SaveReg r0
    //     0x9ffd40: str             x0, [SP, #-8]!
    // 0x9ffd44: mov             x0, x1
    // 0x9ffd48: r0 = GDT[cid_x0 + 0xb940]()
    //     0x9ffd48: mov             x17, #0xb940
    //     0x9ffd4c: add             lr, x0, x17
    //     0x9ffd50: ldr             lr, [x21, lr, lsl #3]
    //     0x9ffd54: blr             lr
    // 0x9ffd58: add             SP, SP, #8
    // 0x9ffd5c: mov             x1, x0
    // 0x9ffd60: stur            x1, [fp, #-0x28]
    // 0x9ffd64: r2 = ""
    //     0x9ffd64: ldr             x2, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x9ffd68: stur            x2, [fp, #-0x10]
    // 0x9ffd6c: CheckStackOverflow
    //     0x9ffd6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ffd70: cmp             SP, x16
    //     0x9ffd74: b.ls            #0xa00098
    // 0x9ffd78: r0 = LoadClassIdInstr(r1)
    //     0x9ffd78: ldur            x0, [x1, #-1]
    //     0x9ffd7c: ubfx            x0, x0, #0xc, #0x14
    // 0x9ffd80: SaveReg r1
    //     0x9ffd80: str             x1, [SP, #-8]!
    // 0x9ffd84: r0 = GDT[cid_x0 + 0x541]()
    //     0x9ffd84: add             lr, x0, #0x541
    //     0x9ffd88: ldr             lr, [x21, lr, lsl #3]
    //     0x9ffd8c: blr             lr
    // 0x9ffd90: add             SP, SP, #8
    // 0x9ffd94: tbnz            w0, #4, #0x9ffdfc
    // 0x9ffd98: ldur            x1, [fp, #-0x28]
    // 0x9ffd9c: r0 = LoadClassIdInstr(r1)
    //     0x9ffd9c: ldur            x0, [x1, #-1]
    //     0x9ffda0: ubfx            x0, x0, #0xc, #0x14
    // 0x9ffda4: SaveReg r1
    //     0x9ffda4: str             x1, [SP, #-8]!
    // 0x9ffda8: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x9ffda8: add             lr, x0, #0x5ca
    //     0x9ffdac: ldr             lr, [x21, lr, lsl #3]
    //     0x9ffdb0: blr             lr
    // 0x9ffdb4: add             SP, SP, #8
    // 0x9ffdb8: r1 = LoadClassIdInstr(r0)
    //     0x9ffdb8: ldur            x1, [x0, #-1]
    //     0x9ffdbc: ubfx            x1, x1, #0xc, #0x14
    // 0x9ffdc0: SaveReg r0
    //     0x9ffdc0: str             x0, [SP, #-8]!
    // 0x9ffdc4: mov             x0, x1
    // 0x9ffdc8: r0 = GDT[cid_x0 + 0x2b8]()
    //     0x9ffdc8: add             lr, x0, #0x2b8
    //     0x9ffdcc: ldr             lr, [x21, lr, lsl #3]
    //     0x9ffdd0: blr             lr
    // 0x9ffdd4: add             SP, SP, #8
    // 0x9ffdd8: LoadField: r1 = r0->field_7
    //     0x9ffdd8: ldur            w1, [x0, #7]
    // 0x9ffddc: DecompressPointer r1
    //     0x9ffddc: add             x1, x1, HEAP, lsl #32
    // 0x9ffde0: ldur            x16, [fp, #-0x10]
    // 0x9ffde4: stp             x1, x16, [SP, #-0x10]!
    // 0x9ffde8: r0 = +()
    //     0x9ffde8: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x9ffdec: add             SP, SP, #0x10
    // 0x9ffdf0: mov             x2, x0
    // 0x9ffdf4: ldur            x1, [fp, #-0x28]
    // 0x9ffdf8: b               #0x9ffd68
    // 0x9ffdfc: ldur            x0, [fp, #-0x18]
    // 0x9ffe00: r0 = DBusSignature()
    //     0x9ffe00: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0x9ffe04: stur            x0, [fp, #-0x28]
    // 0x9ffe08: ldur            x16, [fp, #-0x10]
    // 0x9ffe0c: stp             x16, x0, [SP, #-0x10]!
    // 0x9ffe10: r0 = DBusSignature()
    //     0x9ffe10: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0x9ffe14: add             SP, SP, #0x10
    // 0x9ffe18: ldr             x16, [fp, #0x18]
    // 0x9ffe1c: SaveReg r16
    //     0x9ffe1c: str             x16, [SP, #-8]!
    // 0x9ffe20: r0 = 8
    //     0x9ffe20: mov             x0, #8
    // 0x9ffe24: ldur            x16, [fp, #-0x28]
    // 0x9ffe28: stp             x16, x0, [SP, #-0x10]!
    // 0x9ffe2c: r0 = _makeHeader()
    //     0x9ffe2c: bl              #0xa00584  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::_makeHeader
    // 0x9ffe30: add             SP, SP, #0x18
    // 0x9ffe34: mov             x1, x0
    // 0x9ffe38: ldur            x0, [fp, #-0x18]
    // 0x9ffe3c: stur            x1, [fp, #-0x28]
    // 0x9ffe40: LoadField: r2 = r0->field_b
    //     0x9ffe40: ldur            w2, [x0, #0xb]
    // 0x9ffe44: DecompressPointer r2
    //     0x9ffe44: add             x2, x2, HEAP, lsl #32
    // 0x9ffe48: stur            x2, [fp, #-0x10]
    // 0x9ffe4c: LoadField: r3 = r0->field_f
    //     0x9ffe4c: ldur            w3, [x0, #0xf]
    // 0x9ffe50: DecompressPointer r3
    //     0x9ffe50: add             x3, x3, HEAP, lsl #32
    // 0x9ffe54: LoadField: r4 = r3->field_b
    //     0x9ffe54: ldur            w4, [x3, #0xb]
    // 0x9ffe58: DecompressPointer r4
    //     0x9ffe58: add             x4, x4, HEAP, lsl #32
    // 0x9ffe5c: cmp             w2, w4
    // 0x9ffe60: b.ne            #0x9ffe70
    // 0x9ffe64: SaveReg r0
    //     0x9ffe64: str             x0, [SP, #-8]!
    // 0x9ffe68: r0 = _growToNextCapacity()
    //     0x9ffe68: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ffe6c: add             SP, SP, #8
    // 0x9ffe70: ldur            x2, [fp, #-0x18]
    // 0x9ffe74: ldur            x0, [fp, #-0x10]
    // 0x9ffe78: r3 = LoadInt32Instr(r0)
    //     0x9ffe78: sbfx            x3, x0, #1, #0x1f
    // 0x9ffe7c: add             x0, x3, #1
    // 0x9ffe80: lsl             x1, x0, #1
    // 0x9ffe84: StoreField: r2->field_b = r1
    //     0x9ffe84: stur            w1, [x2, #0xb]
    // 0x9ffe88: mov             x1, x3
    // 0x9ffe8c: cmp             x1, x0
    // 0x9ffe90: b.hs            #0xa000a0
    // 0x9ffe94: LoadField: r1 = r2->field_f
    //     0x9ffe94: ldur            w1, [x2, #0xf]
    // 0x9ffe98: DecompressPointer r1
    //     0x9ffe98: add             x1, x1, HEAP, lsl #32
    // 0x9ffe9c: ldur            x0, [fp, #-0x28]
    // 0x9ffea0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ffea0: add             x25, x1, x3, lsl #2
    //     0x9ffea4: add             x25, x25, #0xf
    //     0x9ffea8: str             w0, [x25]
    //     0x9ffeac: tbz             w0, #0, #0x9ffec8
    //     0x9ffeb0: ldurb           w16, [x1, #-1]
    //     0x9ffeb4: ldurb           w17, [x0, #-1]
    //     0x9ffeb8: and             x16, x17, x16, lsr #2
    //     0x9ffebc: tst             x16, HEAP, lsr #32
    //     0x9ffec0: b.eq            #0x9ffec8
    //     0x9ffec4: bl              #0xd67e5c
    // 0x9ffec8: b               #0x9ffed0
    // 0x9ffecc: ldur            x2, [fp, #-0x18]
    // 0x9ffed0: ldur            x0, [fp, #-8]
    // 0x9ffed4: LoadField: r1 = r0->field_93
    //     0x9ffed4: ldur            w1, [x0, #0x93]
    // 0x9ffed8: DecompressPointer r1
    //     0x9ffed8: add             x1, x1, HEAP, lsl #32
    // 0x9ffedc: stur            x1, [fp, #-0x10]
    // 0x9ffee0: LoadField: r3 = r1->field_b
    //     0x9ffee0: ldur            w3, [x1, #0xb]
    // 0x9ffee4: DecompressPointer r3
    //     0x9ffee4: add             x3, x3, HEAP, lsl #32
    // 0x9ffee8: cbz             w3, #0x9fffb0
    // 0x9ffeec: r4 = LoadInt32Instr(r3)
    //     0x9ffeec: sbfx            x4, x3, #1, #0x1f
    // 0x9ffef0: stur            x4, [fp, #-0x20]
    // 0x9ffef4: r0 = DBusUint32()
    //     0x9ffef4: bl              #0xa00650  ; AllocateDBusUint32Stub -> DBusUint32 (size=0x10)
    // 0x9ffef8: mov             x1, x0
    // 0x9ffefc: ldur            x0, [fp, #-0x20]
    // 0x9fff00: StoreField: r1->field_7 = r0
    //     0x9fff00: stur            x0, [x1, #7]
    // 0x9fff04: ldr             x16, [fp, #0x18]
    // 0x9fff08: SaveReg r16
    //     0x9fff08: str             x16, [SP, #-8]!
    // 0x9fff0c: r0 = 9
    //     0x9fff0c: mov             x0, #9
    // 0x9fff10: stp             x1, x0, [SP, #-0x10]!
    // 0x9fff14: r0 = _makeHeader()
    //     0x9fff14: bl              #0xa00584  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::_makeHeader
    // 0x9fff18: add             SP, SP, #0x18
    // 0x9fff1c: mov             x1, x0
    // 0x9fff20: ldur            x0, [fp, #-0x18]
    // 0x9fff24: stur            x1, [fp, #-0x30]
    // 0x9fff28: LoadField: r2 = r0->field_b
    //     0x9fff28: ldur            w2, [x0, #0xb]
    // 0x9fff2c: DecompressPointer r2
    //     0x9fff2c: add             x2, x2, HEAP, lsl #32
    // 0x9fff30: stur            x2, [fp, #-0x28]
    // 0x9fff34: LoadField: r3 = r0->field_f
    //     0x9fff34: ldur            w3, [x0, #0xf]
    // 0x9fff38: DecompressPointer r3
    //     0x9fff38: add             x3, x3, HEAP, lsl #32
    // 0x9fff3c: LoadField: r4 = r3->field_b
    //     0x9fff3c: ldur            w4, [x3, #0xb]
    // 0x9fff40: DecompressPointer r4
    //     0x9fff40: add             x4, x4, HEAP, lsl #32
    // 0x9fff44: cmp             w2, w4
    // 0x9fff48: b.ne            #0x9fff58
    // 0x9fff4c: SaveReg r0
    //     0x9fff4c: str             x0, [SP, #-8]!
    // 0x9fff50: r0 = _growToNextCapacity()
    //     0x9fff50: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9fff54: add             SP, SP, #8
    // 0x9fff58: ldur            x2, [fp, #-0x18]
    // 0x9fff5c: ldur            x0, [fp, #-0x28]
    // 0x9fff60: r3 = LoadInt32Instr(r0)
    //     0x9fff60: sbfx            x3, x0, #1, #0x1f
    // 0x9fff64: add             x0, x3, #1
    // 0x9fff68: lsl             x1, x0, #1
    // 0x9fff6c: StoreField: r2->field_b = r1
    //     0x9fff6c: stur            w1, [x2, #0xb]
    // 0x9fff70: mov             x1, x3
    // 0x9fff74: cmp             x1, x0
    // 0x9fff78: b.hs            #0xa000a4
    // 0x9fff7c: LoadField: r1 = r2->field_f
    //     0x9fff7c: ldur            w1, [x2, #0xf]
    // 0x9fff80: DecompressPointer r1
    //     0x9fff80: add             x1, x1, HEAP, lsl #32
    // 0x9fff84: ldur            x0, [fp, #-0x30]
    // 0x9fff88: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9fff88: add             x25, x1, x3, lsl #2
    //     0x9fff8c: add             x25, x25, #0xf
    //     0x9fff90: str             w0, [x25]
    //     0x9fff94: tbz             w0, #0, #0x9fffb0
    //     0x9fff98: ldurb           w16, [x1, #-1]
    //     0x9fff9c: ldurb           w17, [x0, #-1]
    //     0x9fffa0: and             x16, x17, x16, lsr #2
    //     0x9fffa4: tst             x16, HEAP, lsr #32
    //     0x9fffa8: b.eq            #0x9fffb0
    //     0x9fffac: bl              #0xd67e5c
    // 0x9fffb0: ldr             x1, [fp, #0x18]
    // 0x9fffb4: ldur            x0, [fp, #-8]
    // 0x9fffb8: r0 = DBusSignature()
    //     0x9fffb8: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0x9fffbc: stur            x0, [fp, #-0x28]
    // 0x9fffc0: r16 = "(yv)"
    //     0x9fffc0: ldr             x16, [PP, #0x7850]  ; [pp+0x7850] "(yv)"
    // 0x9fffc4: stp             x16, x0, [SP, #-0x10]!
    // 0x9fffc8: r0 = DBusSignature()
    //     0x9fffc8: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0x9fffcc: add             SP, SP, #0x10
    // 0x9fffd0: r0 = DBusArray()
    //     0x9fffd0: bl              #0xa0056c  ; AllocateDBusArrayStub -> DBusArray (size=0x10)
    // 0x9fffd4: stur            x0, [fp, #-0x30]
    // 0x9fffd8: ldur            x16, [fp, #-0x28]
    // 0x9fffdc: stp             x16, x0, [SP, #-0x10]!
    // 0x9fffe0: ldur            x16, [fp, #-0x18]
    // 0x9fffe4: SaveReg r16
    //     0x9fffe4: str             x16, [SP, #-8]!
    // 0x9fffe8: r0 = DBusArray()
    //     0x9fffe8: bl              #0xa00200  ; [package:dbus/src/dbus_value.dart] DBusArray::DBusArray
    // 0x9fffec: add             SP, SP, #0x18
    // 0x9ffff0: ldr             x16, [fp, #0x18]
    // 0x9ffff4: ldur            lr, [fp, #-0x30]
    // 0x9ffff8: stp             lr, x16, [SP, #-0x10]!
    // 0x9ffffc: r0 = writeValue()
    //     0x9ffffc: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0xa00000: add             SP, SP, #0x10
    // 0xa00004: ldr             x16, [fp, #0x18]
    // 0xa00008: SaveReg r16
    //     0xa00008: str             x16, [SP, #-8]!
    // 0xa0000c: r0 = 8
    //     0xa0000c: mov             x0, #8
    // 0xa00010: SaveReg r0
    //     0xa00010: str             x0, [SP, #-8]!
    // 0xa00014: r0 = align()
    //     0xa00014: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa00018: add             SP, SP, #0x10
    // 0xa0001c: ldur            x0, [fp, #-8]
    // 0xa00020: LoadField: r1 = r0->field_8f
    //     0xa00020: ldur            w1, [x0, #0x8f]
    // 0xa00024: DecompressPointer r1
    //     0xa00024: add             x1, x1, HEAP, lsl #32
    // 0xa00028: ldr             x16, [fp, #0x18]
    // 0xa0002c: stp             x1, x16, [SP, #-0x10]!
    // 0xa00030: r0 = writeBytes()
    //     0xa00030: bl              #0xa000a8  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeBytes
    // 0xa00034: add             SP, SP, #0x10
    // 0xa00038: ldr             x0, [fp, #0x18]
    // 0xa0003c: LoadField: r1 = r0->field_93
    //     0xa0003c: ldur            w1, [x0, #0x93]
    // 0xa00040: DecompressPointer r1
    //     0xa00040: add             x1, x1, HEAP, lsl #32
    // 0xa00044: ldur            x16, [fp, #-0x10]
    // 0xa00048: stp             x16, x1, [SP, #-0x10]!
    // 0xa0004c: r0 = addAll()
    //     0xa0004c: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa00050: add             SP, SP, #0x10
    // 0xa00054: r0 = Null
    //     0xa00054: mov             x0, NULL
    // 0xa00058: LeaveFrame
    //     0xa00058: mov             SP, fp
    //     0xa0005c: ldp             fp, lr, [SP], #0x10
    // 0xa00060: ret
    //     0xa00060: ret             
    // 0xa00064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa00064: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa00068: b               #0x9ff354
    // 0xa0006c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0006c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa00070: b               #0x9ff3ac
    // 0xa00074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa00074: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa00078: b               #0x9ff558
    // 0xa0007c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0007c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa00080: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa00080: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa00084: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa00084: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa00088: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa00088: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa0008c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0008c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa00090: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa00090: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa00094: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa00094: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa00098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa00098: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0009c: b               #0x9ffd78
    // 0xa000a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa000a0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa000a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa000a4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ writeBytes(/* No info */) {
    // ** addr: 0xa000a8, size: 0x48
    // 0xa000a8: EnterFrame
    //     0xa000a8: stp             fp, lr, [SP, #-0x10]!
    //     0xa000ac: mov             fp, SP
    // 0xa000b0: CheckStackOverflow
    //     0xa000b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa000b4: cmp             SP, x16
    //     0xa000b8: b.ls            #0xa000e8
    // 0xa000bc: ldr             x0, [fp, #0x18]
    // 0xa000c0: LoadField: r1 = r0->field_8f
    //     0xa000c0: ldur            w1, [x0, #0x8f]
    // 0xa000c4: DecompressPointer r1
    //     0xa000c4: add             x1, x1, HEAP, lsl #32
    // 0xa000c8: ldr             x16, [fp, #0x10]
    // 0xa000cc: stp             x16, x1, [SP, #-0x10]!
    // 0xa000d0: r0 = addAll()
    //     0xa000d0: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa000d4: add             SP, SP, #0x10
    // 0xa000d8: r0 = Null
    //     0xa000d8: mov             x0, NULL
    // 0xa000dc: LeaveFrame
    //     0xa000dc: mov             SP, fp
    //     0xa000e0: ldp             fp, lr, [SP], #0x10
    // 0xa000e4: ret
    //     0xa000e4: ret             
    // 0xa000e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa000e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa000ec: b               #0xa000bc
  }
  _ align(/* No info */) {
    // ** addr: 0xa000f0, size: 0x110
    // 0xa000f0: EnterFrame
    //     0xa000f0: stp             fp, lr, [SP, #-0x10]!
    //     0xa000f4: mov             fp, SP
    // 0xa000f8: AllocStack(0x10)
    //     0xa000f8: sub             SP, SP, #0x10
    // 0xa000fc: CheckStackOverflow
    //     0xa000fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa00100: cmp             SP, x16
    //     0xa00104: b.ls            #0xa001b8
    // 0xa00108: ldr             x1, [fp, #0x18]
    // 0xa0010c: ldr             x0, [fp, #0x10]
    // 0xa00110: CheckStackOverflow
    //     0xa00110: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa00114: cmp             SP, x16
    //     0xa00118: b.ls            #0xa001c0
    // 0xa0011c: LoadField: r2 = r1->field_8f
    //     0xa0011c: ldur            w2, [x1, #0x8f]
    // 0xa00120: DecompressPointer r2
    //     0xa00120: add             x2, x2, HEAP, lsl #32
    // 0xa00124: stur            x2, [fp, #-0x10]
    // 0xa00128: LoadField: r3 = r2->field_b
    //     0xa00128: ldur            w3, [x2, #0xb]
    // 0xa0012c: DecompressPointer r3
    //     0xa0012c: add             x3, x3, HEAP, lsl #32
    // 0xa00130: r4 = LoadInt32Instr(r3)
    //     0xa00130: sbfx            x4, x3, #1, #0x1f
    // 0xa00134: stur            x4, [fp, #-8]
    // 0xa00138: cbz             x0, #0xa001c8
    // 0xa0013c: sdiv            x6, x4, x0
    // 0xa00140: msub            x5, x6, x0, x4
    // 0xa00144: cmp             x5, xzr
    // 0xa00148: b.lt            #0xa001e8
    // 0xa0014c: cbz             x5, #0xa001a8
    // 0xa00150: LoadField: r5 = r2->field_f
    //     0xa00150: ldur            w5, [x2, #0xf]
    // 0xa00154: DecompressPointer r5
    //     0xa00154: add             x5, x5, HEAP, lsl #32
    // 0xa00158: LoadField: r6 = r5->field_b
    //     0xa00158: ldur            w6, [x5, #0xb]
    // 0xa0015c: DecompressPointer r6
    //     0xa0015c: add             x6, x6, HEAP, lsl #32
    // 0xa00160: cmp             w3, w6
    // 0xa00164: b.ne            #0xa00174
    // 0xa00168: SaveReg r2
    //     0xa00168: str             x2, [SP, #-8]!
    // 0xa0016c: r0 = _growToNextCapacity()
    //     0xa0016c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa00170: add             SP, SP, #8
    // 0xa00174: ldur            x2, [fp, #-0x10]
    // 0xa00178: ldur            x3, [fp, #-8]
    // 0xa0017c: add             x0, x3, #1
    // 0xa00180: lsl             x4, x0, #1
    // 0xa00184: StoreField: r2->field_b = r4
    //     0xa00184: stur            w4, [x2, #0xb]
    // 0xa00188: mov             x1, x3
    // 0xa0018c: cmp             x1, x0
    // 0xa00190: b.hs            #0xa001fc
    // 0xa00194: LoadField: r1 = r2->field_f
    //     0xa00194: ldur            w1, [x2, #0xf]
    // 0xa00198: DecompressPointer r1
    //     0xa00198: add             x1, x1, HEAP, lsl #32
    // 0xa0019c: ArrayStore: r1[r3] = rZR  ; Unknown_4
    //     0xa0019c: add             x2, x1, x3, lsl #2
    //     0xa001a0: stur            wzr, [x2, #0xf]
    // 0xa001a4: b               #0xa00108
    // 0xa001a8: r0 = Null
    //     0xa001a8: mov             x0, NULL
    // 0xa001ac: LeaveFrame
    //     0xa001ac: mov             SP, fp
    //     0xa001b0: ldp             fp, lr, [SP], #0x10
    // 0xa001b4: ret
    //     0xa001b4: ret             
    // 0xa001b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa001b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa001bc: b               #0xa00108
    // 0xa001c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa001c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa001c4: b               #0xa0011c
    // 0xa001c8: stp             x3, x4, [SP, #-0x10]!
    // 0xa001cc: stp             x1, x2, [SP, #-0x10]!
    // 0xa001d0: SaveReg r0
    //     0xa001d0: str             x0, [SP, #-8]!
    // 0xa001d4: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0xa001d8: r4 = 0
    //     0xa001d8: mov             x4, #0
    // 0xa001dc: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xa001e0: blr             lr
    // 0xa001e4: brk             #0
    // 0xa001e8: cmp             x0, xzr
    // 0xa001ec: sub             x6, x5, x0
    // 0xa001f0: add             x5, x5, x0
    // 0xa001f4: csel            x5, x6, x5, lt
    // 0xa001f8: b               #0xa0014c
    // 0xa001fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa001fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _makeHeader(/* No info */) {
    // ** addr: 0xa00584, size: 0xb4
    // 0xa00584: EnterFrame
    //     0xa00584: stp             fp, lr, [SP, #-0x10]!
    //     0xa00588: mov             fp, SP
    // 0xa0058c: AllocStack(0x18)
    //     0xa0058c: sub             SP, SP, #0x18
    // 0xa00590: CheckStackOverflow
    //     0xa00590: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa00594: cmp             SP, x16
    //     0xa00598: b.ls            #0xa00630
    // 0xa0059c: r0 = DBusByte()
    //     0xa0059c: bl              #0xa0065c  ; AllocateDBusByteStub -> DBusByte (size=0x10)
    // 0xa005a0: mov             x1, x0
    // 0xa005a4: ldr             x0, [fp, #0x18]
    // 0xa005a8: stur            x1, [fp, #-8]
    // 0xa005ac: StoreField: r1->field_7 = r0
    //     0xa005ac: stur            x0, [x1, #7]
    // 0xa005b0: r0 = DBusVariant()
    //     0xa005b0: bl              #0xa00644  ; AllocateDBusVariantStub -> DBusVariant (size=0xc)
    // 0xa005b4: mov             x3, x0
    // 0xa005b8: ldr             x0, [fp, #0x10]
    // 0xa005bc: stur            x3, [fp, #-0x10]
    // 0xa005c0: StoreField: r3->field_7 = r0
    //     0xa005c0: stur            w0, [x3, #7]
    // 0xa005c4: r1 = Null
    //     0xa005c4: mov             x1, NULL
    // 0xa005c8: r2 = 4
    //     0xa005c8: mov             x2, #4
    // 0xa005cc: r0 = AllocateArray()
    //     0xa005cc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa005d0: mov             x2, x0
    // 0xa005d4: ldur            x0, [fp, #-8]
    // 0xa005d8: stur            x2, [fp, #-0x18]
    // 0xa005dc: StoreField: r2->field_f = r0
    //     0xa005dc: stur            w0, [x2, #0xf]
    // 0xa005e0: ldur            x0, [fp, #-0x10]
    // 0xa005e4: StoreField: r2->field_13 = r0
    //     0xa005e4: stur            w0, [x2, #0x13]
    // 0xa005e8: r1 = <DBusValue>
    //     0xa005e8: ldr             x1, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa005ec: r0 = AllocateGrowableArray()
    //     0xa005ec: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa005f0: mov             x1, x0
    // 0xa005f4: ldur            x0, [fp, #-0x18]
    // 0xa005f8: StoreField: r1->field_f = r0
    //     0xa005f8: stur            w0, [x1, #0xf]
    // 0xa005fc: r0 = 4
    //     0xa005fc: mov             x0, #4
    // 0xa00600: StoreField: r1->field_b = r0
    //     0xa00600: stur            w0, [x1, #0xb]
    // 0xa00604: SaveReg r1
    //     0xa00604: str             x1, [SP, #-8]!
    // 0xa00608: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa00608: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0060c: r0 = toList()
    //     0xa0060c: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0xa00610: add             SP, SP, #8
    // 0xa00614: stur            x0, [fp, #-8]
    // 0xa00618: r0 = DBusStruct()
    //     0xa00618: bl              #0xa00638  ; AllocateDBusStructStub -> DBusStruct (size=0xc)
    // 0xa0061c: ldur            x1, [fp, #-8]
    // 0xa00620: StoreField: r0->field_7 = r1
    //     0xa00620: stur            w1, [x0, #7]
    // 0xa00624: LeaveFrame
    //     0xa00624: mov             SP, fp
    //     0xa00628: ldp             fp, lr, [SP], #0x10
    // 0xa0062c: ret
    //     0xa0062c: ret             
    // 0xa00630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa00630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa00634: b               #0xa0059c
  }
  _ writeValue(/* No info */) {
    // ** addr: 0xa00668, size: 0xeac
    // 0xa00668: EnterFrame
    //     0xa00668: stp             fp, lr, [SP, #-0x10]!
    //     0xa0066c: mov             fp, SP
    // 0xa00670: AllocStack(0x48)
    //     0xa00670: sub             SP, SP, #0x48
    // 0xa00674: CheckStackOverflow
    //     0xa00674: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa00678: cmp             SP, x16
    //     0xa0067c: b.ls            #0xa014b0
    // 0xa00680: r1 = 1
    //     0xa00680: mov             x1, #1
    // 0xa00684: r0 = AllocateContext()
    //     0xa00684: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa00688: mov             x1, x0
    // 0xa0068c: ldr             x0, [fp, #0x18]
    // 0xa00690: stur            x1, [fp, #-0x48]
    // 0xa00694: StoreField: r1->field_f = r0
    //     0xa00694: stur            w0, [x1, #0xf]
    // 0xa00698: ldr             x2, [fp, #0x10]
    // 0xa0069c: r3 = LoadClassIdInstr(r2)
    //     0xa0069c: ldur            x3, [x2, #-1]
    //     0xa006a0: ubfx            x3, x3, #0xc, #0x14
    // 0xa006a4: lsl             x3, x3, #1
    // 0xa006a8: r17 = 9166
    //     0xa006a8: mov             x17, #0x23ce
    // 0xa006ac: cmp             w3, w17
    // 0xa006b0: b.ne            #0xa0076c
    // 0xa006b4: LoadField: r1 = r2->field_7
    //     0xa006b4: ldur            x1, [x2, #7]
    // 0xa006b8: stur            x1, [fp, #-0x18]
    // 0xa006bc: LoadField: r2 = r0->field_8f
    //     0xa006bc: ldur            w2, [x0, #0x8f]
    // 0xa006c0: DecompressPointer r2
    //     0xa006c0: add             x2, x2, HEAP, lsl #32
    // 0xa006c4: stur            x2, [fp, #-0x10]
    // 0xa006c8: LoadField: r0 = r2->field_b
    //     0xa006c8: ldur            w0, [x2, #0xb]
    // 0xa006cc: DecompressPointer r0
    //     0xa006cc: add             x0, x0, HEAP, lsl #32
    // 0xa006d0: stur            x0, [fp, #-8]
    // 0xa006d4: LoadField: r3 = r2->field_f
    //     0xa006d4: ldur            w3, [x2, #0xf]
    // 0xa006d8: DecompressPointer r3
    //     0xa006d8: add             x3, x3, HEAP, lsl #32
    // 0xa006dc: LoadField: r4 = r3->field_b
    //     0xa006dc: ldur            w4, [x3, #0xb]
    // 0xa006e0: DecompressPointer r4
    //     0xa006e0: add             x4, x4, HEAP, lsl #32
    // 0xa006e4: cmp             w0, w4
    // 0xa006e8: b.ne            #0xa006f8
    // 0xa006ec: SaveReg r2
    //     0xa006ec: str             x2, [SP, #-8]!
    // 0xa006f0: r0 = _growToNextCapacity()
    //     0xa006f0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa006f4: add             SP, SP, #8
    // 0xa006f8: ldur            x2, [fp, #-0x18]
    // 0xa006fc: ldur            x3, [fp, #-0x10]
    // 0xa00700: ldur            x0, [fp, #-8]
    // 0xa00704: r4 = LoadInt32Instr(r0)
    //     0xa00704: sbfx            x4, x0, #1, #0x1f
    // 0xa00708: add             x0, x4, #1
    // 0xa0070c: lsl             x1, x0, #1
    // 0xa00710: StoreField: r3->field_b = r1
    //     0xa00710: stur            w1, [x3, #0xb]
    // 0xa00714: mov             x1, x4
    // 0xa00718: cmp             x1, x0
    // 0xa0071c: b.hs            #0xa014b8
    // 0xa00720: LoadField: r5 = r3->field_f
    //     0xa00720: ldur            w5, [x3, #0xf]
    // 0xa00724: DecompressPointer r5
    //     0xa00724: add             x5, x5, HEAP, lsl #32
    // 0xa00728: r0 = BoxInt64Instr(r2)
    //     0xa00728: sbfiz           x0, x2, #1, #0x1f
    //     0xa0072c: cmp             x2, x0, asr #1
    //     0xa00730: b.eq            #0xa0073c
    //     0xa00734: bl              #0xd69bb8
    //     0xa00738: stur            x2, [x0, #7]
    // 0xa0073c: mov             x1, x5
    // 0xa00740: ArrayStore: r1[r4] = r0  ; List_4
    //     0xa00740: add             x25, x1, x4, lsl #2
    //     0xa00744: add             x25, x25, #0xf
    //     0xa00748: str             w0, [x25]
    //     0xa0074c: tbz             w0, #0, #0xa00768
    //     0xa00750: ldurb           w16, [x1, #-1]
    //     0xa00754: ldurb           w17, [x0, #-1]
    //     0xa00758: and             x16, x17, x16, lsr #2
    //     0xa0075c: tst             x16, HEAP, lsr #32
    //     0xa00760: b.eq            #0xa00768
    //     0xa00764: bl              #0xd67e5c
    // 0xa00768: b               #0xa01438
    // 0xa0076c: r17 = 9164
    //     0xa0076c: mov             x17, #0x23cc
    // 0xa00770: cmp             w3, w17
    // 0xa00774: b.ne            #0xa007b8
    // 0xa00778: r4 = 4
    //     0xa00778: mov             x4, #4
    // 0xa0077c: stp             x4, x0, [SP, #-0x10]!
    // 0xa00780: r0 = align()
    //     0xa00780: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa00784: add             SP, SP, #0x10
    // 0xa00788: ldr             x0, [fp, #0x10]
    // 0xa0078c: LoadField: r1 = r0->field_7
    //     0xa0078c: ldur            w1, [x0, #7]
    // 0xa00790: DecompressPointer r1
    //     0xa00790: add             x1, x1, HEAP, lsl #32
    // 0xa00794: tst             x1, #0x10
    // 0xa00798: cset            x0, eq
    // 0xa0079c: lsl             x0, x0, #1
    // 0xa007a0: r1 = LoadInt32Instr(r0)
    //     0xa007a0: sbfx            x1, x0, #1, #0x1f
    // 0xa007a4: ldr             x16, [fp, #0x18]
    // 0xa007a8: stp             x1, x16, [SP, #-0x10]!
    // 0xa007ac: r0 = writeUint32()
    //     0xa007ac: bl              #0xa01d18  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeUint32
    // 0xa007b0: add             SP, SP, #0x10
    // 0xa007b4: b               #0xa01438
    // 0xa007b8: mov             x0, x2
    // 0xa007bc: r4 = 4
    //     0xa007bc: mov             x4, #4
    // 0xa007c0: r17 = 9162
    //     0xa007c0: mov             x17, #0x23ca
    // 0xa007c4: cmp             w3, w17
    // 0xa007c8: b.ne            #0xa007fc
    // 0xa007cc: r2 = 2
    //     0xa007cc: mov             x2, #2
    // 0xa007d0: ldr             x16, [fp, #0x18]
    // 0xa007d4: stp             x2, x16, [SP, #-0x10]!
    // 0xa007d8: r0 = align()
    //     0xa007d8: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa007dc: add             SP, SP, #0x10
    // 0xa007e0: ldr             x0, [fp, #0x10]
    // 0xa007e4: LoadField: r1 = r0->field_7
    //     0xa007e4: ldur            x1, [x0, #7]
    // 0xa007e8: ldr             x16, [fp, #0x18]
    // 0xa007ec: stp             x1, x16, [SP, #-0x10]!
    // 0xa007f0: r0 = writeInt16()
    //     0xa007f0: bl              #0xa01c18  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeInt16
    // 0xa007f4: add             SP, SP, #0x10
    // 0xa007f8: b               #0xa01438
    // 0xa007fc: r2 = 2
    //     0xa007fc: mov             x2, #2
    // 0xa00800: r17 = 9160
    //     0xa00800: mov             x17, #0x23c8
    // 0xa00804: cmp             w3, w17
    // 0xa00808: b.ne            #0xa00838
    // 0xa0080c: ldr             x16, [fp, #0x18]
    // 0xa00810: stp             x2, x16, [SP, #-0x10]!
    // 0xa00814: r0 = align()
    //     0xa00814: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa00818: add             SP, SP, #0x10
    // 0xa0081c: ldr             x0, [fp, #0x10]
    // 0xa00820: LoadField: r1 = r0->field_7
    //     0xa00820: ldur            x1, [x0, #7]
    // 0xa00824: ldr             x16, [fp, #0x18]
    // 0xa00828: stp             x1, x16, [SP, #-0x10]!
    // 0xa0082c: r0 = writeInt16()
    //     0xa0082c: bl              #0xa01c18  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeInt16
    // 0xa00830: add             SP, SP, #0x10
    // 0xa00834: b               #0xa01438
    // 0xa00838: r17 = 9158
    //     0xa00838: mov             x17, #0x23c6
    // 0xa0083c: cmp             w3, w17
    // 0xa00840: b.ne            #0xa00870
    // 0xa00844: ldr             x16, [fp, #0x18]
    // 0xa00848: stp             x4, x16, [SP, #-0x10]!
    // 0xa0084c: r0 = align()
    //     0xa0084c: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa00850: add             SP, SP, #0x10
    // 0xa00854: ldr             x0, [fp, #0x10]
    // 0xa00858: LoadField: r1 = r0->field_7
    //     0xa00858: ldur            x1, [x0, #7]
    // 0xa0085c: ldr             x16, [fp, #0x18]
    // 0xa00860: stp             x1, x16, [SP, #-0x10]!
    // 0xa00864: r0 = writeInt32()
    //     0xa00864: bl              #0xa01b14  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeInt32
    // 0xa00868: add             SP, SP, #0x10
    // 0xa0086c: b               #0xa01438
    // 0xa00870: r17 = 9156
    //     0xa00870: mov             x17, #0x23c4
    // 0xa00874: cmp             w3, w17
    // 0xa00878: b.ne            #0xa008a8
    // 0xa0087c: ldr             x16, [fp, #0x18]
    // 0xa00880: stp             x4, x16, [SP, #-0x10]!
    // 0xa00884: r0 = align()
    //     0xa00884: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa00888: add             SP, SP, #0x10
    // 0xa0088c: ldr             x0, [fp, #0x10]
    // 0xa00890: LoadField: r1 = r0->field_7
    //     0xa00890: ldur            x1, [x0, #7]
    // 0xa00894: ldr             x16, [fp, #0x18]
    // 0xa00898: stp             x1, x16, [SP, #-0x10]!
    // 0xa0089c: r0 = writeUint32()
    //     0xa0089c: bl              #0xa01d18  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeUint32
    // 0xa008a0: add             SP, SP, #0x10
    // 0xa008a4: b               #0xa01438
    // 0xa008a8: r17 = 9154
    //     0xa008a8: mov             x17, #0x23c2
    // 0xa008ac: cmp             w3, w17
    // 0xa008b0: b.ne            #0xa008e4
    // 0xa008b4: r2 = 8
    //     0xa008b4: mov             x2, #8
    // 0xa008b8: ldr             x16, [fp, #0x18]
    // 0xa008bc: stp             x2, x16, [SP, #-0x10]!
    // 0xa008c0: r0 = align()
    //     0xa008c0: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa008c4: add             SP, SP, #0x10
    // 0xa008c8: ldr             x0, [fp, #0x10]
    // 0xa008cc: LoadField: r1 = r0->field_7
    //     0xa008cc: ldur            x1, [x0, #7]
    // 0xa008d0: ldr             x16, [fp, #0x18]
    // 0xa008d4: stp             x1, x16, [SP, #-0x10]!
    // 0xa008d8: r0 = writeInt64()
    //     0xa008d8: bl              #0xa01a14  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeInt64
    // 0xa008dc: add             SP, SP, #0x10
    // 0xa008e0: b               #0xa01438
    // 0xa008e4: r2 = 8
    //     0xa008e4: mov             x2, #8
    // 0xa008e8: r17 = 9152
    //     0xa008e8: mov             x17, #0x23c0
    // 0xa008ec: cmp             w3, w17
    // 0xa008f0: b.ne            #0xa00920
    // 0xa008f4: ldr             x16, [fp, #0x18]
    // 0xa008f8: stp             x2, x16, [SP, #-0x10]!
    // 0xa008fc: r0 = align()
    //     0xa008fc: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa00900: add             SP, SP, #0x10
    // 0xa00904: ldr             x0, [fp, #0x10]
    // 0xa00908: LoadField: r1 = r0->field_7
    //     0xa00908: ldur            x1, [x0, #7]
    // 0xa0090c: ldr             x16, [fp, #0x18]
    // 0xa00910: stp             x1, x16, [SP, #-0x10]!
    // 0xa00914: r0 = writeInt64()
    //     0xa00914: bl              #0xa01a14  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeInt64
    // 0xa00918: add             SP, SP, #0x10
    // 0xa0091c: b               #0xa01438
    // 0xa00920: r17 = 9150
    //     0xa00920: mov             x17, #0x23be
    // 0xa00924: cmp             w3, w17
    // 0xa00928: b.ne            #0xa0095c
    // 0xa0092c: ldr             x16, [fp, #0x18]
    // 0xa00930: stp             x2, x16, [SP, #-0x10]!
    // 0xa00934: r0 = align()
    //     0xa00934: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa00938: add             SP, SP, #0x10
    // 0xa0093c: ldr             x0, [fp, #0x10]
    // 0xa00940: LoadField: d0 = r0->field_7
    //     0xa00940: ldur            d0, [x0, #7]
    // 0xa00944: ldr             x16, [fp, #0x18]
    // 0xa00948: SaveReg r16
    //     0xa00948: str             x16, [SP, #-8]!
    // 0xa0094c: SaveReg d0
    //     0xa0094c: str             d0, [SP, #-8]!
    // 0xa00950: r0 = writeFloat64()
    //     0xa00950: bl              #0xa01918  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeFloat64
    // 0xa00954: add             SP, SP, #0x10
    // 0xa00958: b               #0xa01438
    // 0xa0095c: r4 = LoadInt32Instr(r3)
    //     0xa0095c: sbfx            x4, x3, #1, #0x1f
    // 0xa00960: r17 = 4573
    //     0xa00960: mov             x17, #0x11dd
    // 0xa00964: cmp             x4, x17
    // 0xa00968: b.lt            #0xa00b80
    // 0xa0096c: r17 = 4574
    //     0xa0096c: mov             x17, #0x11de
    // 0xa00970: cmp             x4, x17
    // 0xa00974: b.gt            #0xa00b78
    // 0xa00978: LoadField: r1 = r0->field_7
    //     0xa00978: ldur            w1, [x0, #7]
    // 0xa0097c: DecompressPointer r1
    //     0xa0097c: add             x1, x1, HEAP, lsl #32
    // 0xa00980: r16 = Instance_Utf8Codec
    //     0xa00980: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xa00984: stp             x1, x16, [SP, #-0x10]!
    // 0xa00988: r0 = encode()
    //     0xa00988: bl              #0xbfcc28  ; [dart:convert] Codec::encode
    // 0xa0098c: add             SP, SP, #0x10
    // 0xa00990: stur            x0, [fp, #-8]
    // 0xa00994: LoadField: r1 = r0->field_13
    //     0xa00994: ldur            w1, [x0, #0x13]
    // 0xa00998: DecompressPointer r1
    //     0xa00998: add             x1, x1, HEAP, lsl #32
    // 0xa0099c: r2 = LoadInt32Instr(r1)
    //     0xa0099c: sbfx            x2, x1, #1, #0x1f
    // 0xa009a0: stur            x2, [fp, #-0x18]
    // 0xa009a4: r0 = DBusUint32()
    //     0xa009a4: bl              #0xa00650  ; AllocateDBusUint32Stub -> DBusUint32 (size=0x10)
    // 0xa009a8: mov             x1, x0
    // 0xa009ac: ldur            x0, [fp, #-0x18]
    // 0xa009b0: StoreField: r1->field_7 = r0
    //     0xa009b0: stur            x0, [x1, #7]
    // 0xa009b4: ldr             x16, [fp, #0x18]
    // 0xa009b8: stp             x1, x16, [SP, #-0x10]!
    // 0xa009bc: r0 = writeValue()
    //     0xa009bc: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0xa009c0: add             SP, SP, #0x10
    // 0xa009c4: r0 = -1
    //     0xa009c4: mov             x0, #-1
    // 0xa009c8: ldr             x4, [fp, #0x18]
    // 0xa009cc: ldur            x3, [fp, #-8]
    // 0xa009d0: ldur            x2, [fp, #-0x18]
    // 0xa009d4: CheckStackOverflow
    //     0xa009d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa009d8: cmp             SP, x16
    //     0xa009dc: b.ls            #0xa014bc
    // 0xa009e0: add             x5, x0, #1
    // 0xa009e4: stur            x5, [fp, #-0x20]
    // 0xa009e8: cmp             x5, x2
    // 0xa009ec: b.ge            #0xa00b04
    // 0xa009f0: r0 = BoxInt64Instr(r5)
    //     0xa009f0: sbfiz           x0, x5, #1, #0x1f
    //     0xa009f4: cmp             x5, x0, asr #1
    //     0xa009f8: b.eq            #0xa00a04
    //     0xa009fc: bl              #0xd69bb8
    //     0xa00a00: stur            x5, [x0, #7]
    // 0xa00a04: r1 = LoadClassIdInstr(r3)
    //     0xa00a04: ldur            x1, [x3, #-1]
    //     0xa00a08: ubfx            x1, x1, #0xc, #0x14
    // 0xa00a0c: stp             x0, x3, [SP, #-0x10]!
    // 0xa00a10: mov             x0, x1
    // 0xa00a14: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa00a14: sub             lr, x0, #0xd83
    //     0xa00a18: ldr             lr, [x21, lr, lsl #3]
    //     0xa00a1c: blr             lr
    // 0xa00a20: add             SP, SP, #0x10
    // 0xa00a24: mov             x3, x0
    // 0xa00a28: stur            x3, [fp, #-0x10]
    // 0xa00a2c: cmp             w3, NULL
    // 0xa00a30: b.ne            #0xa00a64
    // 0xa00a34: r3 as int
    //     0xa00a34: mov             x0, x3
    //     0xa00a38: mov             x2, NULL
    //     0xa00a3c: mov             x1, NULL
    //     0xa00a40: tbz             w0, #0, #0xa00a64
    //     0xa00a44: ldur            x4, [x0, #-1]
    //     0xa00a48: ubfx            x4, x4, #0xc, #0x14
    //     0xa00a4c: sub             x4, x4, #0x3b
    //     0xa00a50: cmp             x4, #1
    //     0xa00a54: b.ls            #0xa00a64
    //     0xa00a58: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xa00a5c: ldr             x3, [PP, #0x7888]  ; [pp+0x7888] Null
    //     0xa00a60: bl              #0xd73714
    // 0xa00a64: ldr             x0, [fp, #0x18]
    // 0xa00a68: LoadField: r1 = r0->field_8f
    //     0xa00a68: ldur            w1, [x0, #0x8f]
    // 0xa00a6c: DecompressPointer r1
    //     0xa00a6c: add             x1, x1, HEAP, lsl #32
    // 0xa00a70: stur            x1, [fp, #-0x30]
    // 0xa00a74: LoadField: r2 = r1->field_b
    //     0xa00a74: ldur            w2, [x1, #0xb]
    // 0xa00a78: DecompressPointer r2
    //     0xa00a78: add             x2, x2, HEAP, lsl #32
    // 0xa00a7c: stur            x2, [fp, #-0x28]
    // 0xa00a80: LoadField: r3 = r1->field_f
    //     0xa00a80: ldur            w3, [x1, #0xf]
    // 0xa00a84: DecompressPointer r3
    //     0xa00a84: add             x3, x3, HEAP, lsl #32
    // 0xa00a88: LoadField: r4 = r3->field_b
    //     0xa00a88: ldur            w4, [x3, #0xb]
    // 0xa00a8c: DecompressPointer r4
    //     0xa00a8c: add             x4, x4, HEAP, lsl #32
    // 0xa00a90: cmp             w2, w4
    // 0xa00a94: b.ne            #0xa00aa4
    // 0xa00a98: SaveReg r1
    //     0xa00a98: str             x1, [SP, #-8]!
    // 0xa00a9c: r0 = _growToNextCapacity()
    //     0xa00a9c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa00aa0: add             SP, SP, #8
    // 0xa00aa4: ldur            x2, [fp, #-0x30]
    // 0xa00aa8: ldur            x0, [fp, #-0x28]
    // 0xa00aac: r3 = LoadInt32Instr(r0)
    //     0xa00aac: sbfx            x3, x0, #1, #0x1f
    // 0xa00ab0: add             x0, x3, #1
    // 0xa00ab4: lsl             x1, x0, #1
    // 0xa00ab8: StoreField: r2->field_b = r1
    //     0xa00ab8: stur            w1, [x2, #0xb]
    // 0xa00abc: mov             x1, x3
    // 0xa00ac0: cmp             x1, x0
    // 0xa00ac4: b.hs            #0xa014c4
    // 0xa00ac8: LoadField: r1 = r2->field_f
    //     0xa00ac8: ldur            w1, [x2, #0xf]
    // 0xa00acc: DecompressPointer r1
    //     0xa00acc: add             x1, x1, HEAP, lsl #32
    // 0xa00ad0: ldur            x0, [fp, #-0x10]
    // 0xa00ad4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xa00ad4: add             x25, x1, x3, lsl #2
    //     0xa00ad8: add             x25, x25, #0xf
    //     0xa00adc: str             w0, [x25]
    //     0xa00ae0: tbz             w0, #0, #0xa00afc
    //     0xa00ae4: ldurb           w16, [x1, #-1]
    //     0xa00ae8: ldurb           w17, [x0, #-1]
    //     0xa00aec: and             x16, x17, x16, lsr #2
    //     0xa00af0: tst             x16, HEAP, lsr #32
    //     0xa00af4: b.eq            #0xa00afc
    //     0xa00af8: bl              #0xd67e5c
    // 0xa00afc: ldur            x0, [fp, #-0x20]
    // 0xa00b00: b               #0xa009c8
    // 0xa00b04: LoadField: r0 = r4->field_8f
    //     0xa00b04: ldur            w0, [x4, #0x8f]
    // 0xa00b08: DecompressPointer r0
    //     0xa00b08: add             x0, x0, HEAP, lsl #32
    // 0xa00b0c: stur            x0, [fp, #-0x10]
    // 0xa00b10: LoadField: r1 = r0->field_b
    //     0xa00b10: ldur            w1, [x0, #0xb]
    // 0xa00b14: DecompressPointer r1
    //     0xa00b14: add             x1, x1, HEAP, lsl #32
    // 0xa00b18: stur            x1, [fp, #-8]
    // 0xa00b1c: LoadField: r2 = r0->field_f
    //     0xa00b1c: ldur            w2, [x0, #0xf]
    // 0xa00b20: DecompressPointer r2
    //     0xa00b20: add             x2, x2, HEAP, lsl #32
    // 0xa00b24: LoadField: r3 = r2->field_b
    //     0xa00b24: ldur            w3, [x2, #0xb]
    // 0xa00b28: DecompressPointer r3
    //     0xa00b28: add             x3, x3, HEAP, lsl #32
    // 0xa00b2c: cmp             w1, w3
    // 0xa00b30: b.ne            #0xa00b40
    // 0xa00b34: SaveReg r0
    //     0xa00b34: str             x0, [SP, #-8]!
    // 0xa00b38: r0 = _growToNextCapacity()
    //     0xa00b38: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa00b3c: add             SP, SP, #8
    // 0xa00b40: ldur            x2, [fp, #-0x10]
    // 0xa00b44: ldur            x0, [fp, #-8]
    // 0xa00b48: r3 = LoadInt32Instr(r0)
    //     0xa00b48: sbfx            x3, x0, #1, #0x1f
    // 0xa00b4c: add             x0, x3, #1
    // 0xa00b50: lsl             x1, x0, #1
    // 0xa00b54: StoreField: r2->field_b = r1
    //     0xa00b54: stur            w1, [x2, #0xb]
    // 0xa00b58: mov             x1, x3
    // 0xa00b5c: cmp             x1, x0
    // 0xa00b60: b.hs            #0xa014c8
    // 0xa00b64: LoadField: r0 = r2->field_f
    //     0xa00b64: ldur            w0, [x2, #0xf]
    // 0xa00b68: DecompressPointer r0
    //     0xa00b68: add             x0, x0, HEAP, lsl #32
    // 0xa00b6c: ArrayStore: r0[r3] = rZR  ; Unknown_4
    //     0xa00b6c: add             x1, x0, x3, lsl #2
    //     0xa00b70: stur            wzr, [x1, #0xf]
    // 0xa00b74: b               #0xa01438
    // 0xa00b78: ldr             x4, [fp, #0x18]
    // 0xa00b7c: b               #0xa00b84
    // 0xa00b80: ldr             x4, [fp, #0x18]
    // 0xa00b84: r17 = 9144
    //     0xa00b84: mov             x17, #0x23b8
    // 0xa00b88: cmp             w3, w17
    // 0xa00b8c: b.ne            #0xa00e90
    // 0xa00b90: LoadField: r1 = r0->field_7
    //     0xa00b90: ldur            w1, [x0, #7]
    // 0xa00b94: DecompressPointer r1
    //     0xa00b94: add             x1, x1, HEAP, lsl #32
    // 0xa00b98: stur            x1, [fp, #-8]
    // 0xa00b9c: r0 = LoadClassIdInstr(r1)
    //     0xa00b9c: ldur            x0, [x1, #-1]
    //     0xa00ba0: ubfx            x0, x0, #0xc, #0x14
    // 0xa00ba4: r16 = "m"
    //     0xa00ba4: ldr             x16, [PP, #0x448]  ; [pp+0x448] "m"
    // 0xa00ba8: stp             x16, x1, [SP, #-0x10]!
    // 0xa00bac: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa00bac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa00bb0: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa00bb0: sub             lr, x0, #0xffc
    //     0xa00bb4: ldr             lr, [x21, lr, lsl #3]
    //     0xa00bb8: blr             lr
    // 0xa00bbc: add             SP, SP, #0x10
    // 0xa00bc0: tbz             w0, #4, #0xa01448
    // 0xa00bc4: ldr             x0, [fp, #0x18]
    // 0xa00bc8: r16 = Instance_Utf8Codec
    //     0xa00bc8: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xa00bcc: ldur            lr, [fp, #-8]
    // 0xa00bd0: stp             lr, x16, [SP, #-0x10]!
    // 0xa00bd4: r0 = encode()
    //     0xa00bd4: bl              #0xbfcc28  ; [dart:convert] Codec::encode
    // 0xa00bd8: add             SP, SP, #0x10
    // 0xa00bdc: stur            x0, [fp, #-0x30]
    // 0xa00be0: LoadField: r1 = r0->field_13
    //     0xa00be0: ldur            w1, [x0, #0x13]
    // 0xa00be4: DecompressPointer r1
    //     0xa00be4: add             x1, x1, HEAP, lsl #32
    // 0xa00be8: ldr             x2, [fp, #0x18]
    // 0xa00bec: stur            x1, [fp, #-0x28]
    // 0xa00bf0: LoadField: r3 = r2->field_8f
    //     0xa00bf0: ldur            w3, [x2, #0x8f]
    // 0xa00bf4: DecompressPointer r3
    //     0xa00bf4: add             x3, x3, HEAP, lsl #32
    // 0xa00bf8: stur            x3, [fp, #-0x10]
    // 0xa00bfc: LoadField: r4 = r3->field_b
    //     0xa00bfc: ldur            w4, [x3, #0xb]
    // 0xa00c00: DecompressPointer r4
    //     0xa00c00: add             x4, x4, HEAP, lsl #32
    // 0xa00c04: stur            x4, [fp, #-8]
    // 0xa00c08: LoadField: r5 = r3->field_f
    //     0xa00c08: ldur            w5, [x3, #0xf]
    // 0xa00c0c: DecompressPointer r5
    //     0xa00c0c: add             x5, x5, HEAP, lsl #32
    // 0xa00c10: LoadField: r6 = r5->field_b
    //     0xa00c10: ldur            w6, [x5, #0xb]
    // 0xa00c14: DecompressPointer r6
    //     0xa00c14: add             x6, x6, HEAP, lsl #32
    // 0xa00c18: cmp             w4, w6
    // 0xa00c1c: b.ne            #0xa00c2c
    // 0xa00c20: SaveReg r3
    //     0xa00c20: str             x3, [SP, #-8]!
    // 0xa00c24: r0 = _growToNextCapacity()
    //     0xa00c24: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa00c28: add             SP, SP, #8
    // 0xa00c2c: ldur            x2, [fp, #-0x28]
    // 0xa00c30: ldur            x3, [fp, #-0x10]
    // 0xa00c34: ldur            x0, [fp, #-8]
    // 0xa00c38: r4 = LoadInt32Instr(r0)
    //     0xa00c38: sbfx            x4, x0, #1, #0x1f
    // 0xa00c3c: add             x0, x4, #1
    // 0xa00c40: lsl             x1, x0, #1
    // 0xa00c44: StoreField: r3->field_b = r1
    //     0xa00c44: stur            w1, [x3, #0xb]
    // 0xa00c48: mov             x1, x4
    // 0xa00c4c: cmp             x1, x0
    // 0xa00c50: b.hs            #0xa014cc
    // 0xa00c54: LoadField: r0 = r3->field_f
    //     0xa00c54: ldur            w0, [x3, #0xf]
    // 0xa00c58: DecompressPointer r0
    //     0xa00c58: add             x0, x0, HEAP, lsl #32
    // 0xa00c5c: ArrayStore: r0[r4] = r2  ; Unknown_4
    //     0xa00c5c: add             x1, x0, x4, lsl #2
    //     0xa00c60: stur            w2, [x1, #0xf]
    // 0xa00c64: ldur            x16, [fp, #-0x30]
    // 0xa00c68: SaveReg r16
    //     0xa00c68: str             x16, [SP, #-8]!
    // 0xa00c6c: r0 = iterator()
    //     0xa00c6c: bl              #0x9ba730  ; [dart:typed_data] __Int8List&_TypedList&_IntListMixin::iterator
    // 0xa00c70: add             SP, SP, #8
    // 0xa00c74: mov             x2, x0
    // 0xa00c78: stur            x2, [fp, #-0x28]
    // 0xa00c7c: LoadField: r3 = r2->field_f
    //     0xa00c7c: ldur            x3, [x2, #0xf]
    // 0xa00c80: stur            x3, [fp, #-0x20]
    // 0xa00c84: LoadField: r4 = r2->field_b
    //     0xa00c84: ldur            w4, [x2, #0xb]
    // 0xa00c88: DecompressPointer r4
    //     0xa00c88: add             x4, x4, HEAP, lsl #32
    // 0xa00c8c: stur            x4, [fp, #-0x10]
    // 0xa00c90: LoadField: r5 = r2->field_7
    //     0xa00c90: ldur            w5, [x2, #7]
    // 0xa00c94: DecompressPointer r5
    //     0xa00c94: add             x5, x5, HEAP, lsl #32
    // 0xa00c98: stur            x5, [fp, #-8]
    // 0xa00c9c: ldr             x6, [fp, #0x18]
    // 0xa00ca0: CheckStackOverflow
    //     0xa00ca0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa00ca4: cmp             SP, x16
    //     0xa00ca8: b.ls            #0xa014d0
    // 0xa00cac: LoadField: r0 = r2->field_17
    //     0xa00cac: ldur            x0, [x2, #0x17]
    // 0xa00cb0: add             x7, x0, #1
    // 0xa00cb4: stur            x7, [fp, #-0x18]
    // 0xa00cb8: cmp             x7, x3
    // 0xa00cbc: b.ge            #0xa00e08
    // 0xa00cc0: r0 = BoxInt64Instr(r7)
    //     0xa00cc0: sbfiz           x0, x7, #1, #0x1f
    //     0xa00cc4: cmp             x7, x0, asr #1
    //     0xa00cc8: b.eq            #0xa00cd4
    //     0xa00ccc: bl              #0xd69bb8
    //     0xa00cd0: stur            x7, [x0, #7]
    // 0xa00cd4: r1 = LoadClassIdInstr(r4)
    //     0xa00cd4: ldur            x1, [x4, #-1]
    //     0xa00cd8: ubfx            x1, x1, #0xc, #0x14
    // 0xa00cdc: stp             x0, x4, [SP, #-0x10]!
    // 0xa00ce0: mov             x0, x1
    // 0xa00ce4: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa00ce4: sub             lr, x0, #0xd83
    //     0xa00ce8: ldr             lr, [x21, lr, lsl #3]
    //     0xa00cec: blr             lr
    // 0xa00cf0: add             SP, SP, #0x10
    // 0xa00cf4: mov             x4, x0
    // 0xa00cf8: ldur            x3, [fp, #-0x28]
    // 0xa00cfc: stur            x4, [fp, #-0x30]
    // 0xa00d00: StoreField: r3->field_1f = r0
    //     0xa00d00: stur            w0, [x3, #0x1f]
    //     0xa00d04: tbz             w0, #0, #0xa00d20
    //     0xa00d08: ldurb           w16, [x3, #-1]
    //     0xa00d0c: ldurb           w17, [x0, #-1]
    //     0xa00d10: and             x16, x17, x16, lsr #2
    //     0xa00d14: tst             x16, HEAP, lsr #32
    //     0xa00d18: b.eq            #0xa00d20
    //     0xa00d1c: bl              #0xd682ac
    // 0xa00d20: ldur            x0, [fp, #-0x18]
    // 0xa00d24: StoreField: r3->field_17 = r0
    //     0xa00d24: stur            x0, [x3, #0x17]
    // 0xa00d28: cmp             w4, NULL
    // 0xa00d2c: b.ne            #0xa00d5c
    // 0xa00d30: mov             x0, x4
    // 0xa00d34: ldur            x2, [fp, #-8]
    // 0xa00d38: r1 = Null
    //     0xa00d38: mov             x1, NULL
    // 0xa00d3c: cmp             w2, NULL
    // 0xa00d40: b.eq            #0xa00d5c
    // 0xa00d44: LoadField: r4 = r2->field_17
    //     0xa00d44: ldur            w4, [x2, #0x17]
    // 0xa00d48: DecompressPointer r4
    //     0xa00d48: add             x4, x4, HEAP, lsl #32
    // 0xa00d4c: r8 = X0
    //     0xa00d4c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa00d50: LoadField: r9 = r4->field_7
    //     0xa00d50: ldur            x9, [x4, #7]
    // 0xa00d54: r3 = Null
    //     0xa00d54: ldr             x3, [PP, #0x7898]  ; [pp+0x7898] Null
    // 0xa00d58: blr             x9
    // 0xa00d5c: ldr             x0, [fp, #0x18]
    // 0xa00d60: LoadField: r1 = r0->field_8f
    //     0xa00d60: ldur            w1, [x0, #0x8f]
    // 0xa00d64: DecompressPointer r1
    //     0xa00d64: add             x1, x1, HEAP, lsl #32
    // 0xa00d68: stur            x1, [fp, #-0x40]
    // 0xa00d6c: LoadField: r2 = r1->field_b
    //     0xa00d6c: ldur            w2, [x1, #0xb]
    // 0xa00d70: DecompressPointer r2
    //     0xa00d70: add             x2, x2, HEAP, lsl #32
    // 0xa00d74: stur            x2, [fp, #-0x38]
    // 0xa00d78: LoadField: r3 = r1->field_f
    //     0xa00d78: ldur            w3, [x1, #0xf]
    // 0xa00d7c: DecompressPointer r3
    //     0xa00d7c: add             x3, x3, HEAP, lsl #32
    // 0xa00d80: LoadField: r4 = r3->field_b
    //     0xa00d80: ldur            w4, [x3, #0xb]
    // 0xa00d84: DecompressPointer r4
    //     0xa00d84: add             x4, x4, HEAP, lsl #32
    // 0xa00d88: cmp             w2, w4
    // 0xa00d8c: b.ne            #0xa00d9c
    // 0xa00d90: SaveReg r1
    //     0xa00d90: str             x1, [SP, #-8]!
    // 0xa00d94: r0 = _growToNextCapacity()
    //     0xa00d94: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa00d98: add             SP, SP, #8
    // 0xa00d9c: ldur            x2, [fp, #-0x40]
    // 0xa00da0: ldur            x0, [fp, #-0x38]
    // 0xa00da4: r3 = LoadInt32Instr(r0)
    //     0xa00da4: sbfx            x3, x0, #1, #0x1f
    // 0xa00da8: add             x0, x3, #1
    // 0xa00dac: lsl             x1, x0, #1
    // 0xa00db0: StoreField: r2->field_b = r1
    //     0xa00db0: stur            w1, [x2, #0xb]
    // 0xa00db4: mov             x1, x3
    // 0xa00db8: cmp             x1, x0
    // 0xa00dbc: b.hs            #0xa014d8
    // 0xa00dc0: LoadField: r1 = r2->field_f
    //     0xa00dc0: ldur            w1, [x2, #0xf]
    // 0xa00dc4: DecompressPointer r1
    //     0xa00dc4: add             x1, x1, HEAP, lsl #32
    // 0xa00dc8: ldur            x0, [fp, #-0x30]
    // 0xa00dcc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xa00dcc: add             x25, x1, x3, lsl #2
    //     0xa00dd0: add             x25, x25, #0xf
    //     0xa00dd4: str             w0, [x25]
    //     0xa00dd8: tbz             w0, #0, #0xa00df4
    //     0xa00ddc: ldurb           w16, [x1, #-1]
    //     0xa00de0: ldurb           w17, [x0, #-1]
    //     0xa00de4: and             x16, x17, x16, lsr #2
    //     0xa00de8: tst             x16, HEAP, lsr #32
    //     0xa00dec: b.eq            #0xa00df4
    //     0xa00df0: bl              #0xd67e5c
    // 0xa00df4: ldur            x2, [fp, #-0x28]
    // 0xa00df8: ldur            x5, [fp, #-8]
    // 0xa00dfc: ldur            x3, [fp, #-0x20]
    // 0xa00e00: ldur            x4, [fp, #-0x10]
    // 0xa00e04: b               #0xa00c9c
    // 0xa00e08: mov             x4, x6
    // 0xa00e0c: mov             x0, x2
    // 0xa00e10: mov             x1, x3
    // 0xa00e14: StoreField: r0->field_17 = r1
    //     0xa00e14: stur            x1, [x0, #0x17]
    // 0xa00e18: StoreField: r0->field_1f = rNULL
    //     0xa00e18: stur            NULL, [x0, #0x1f]
    // 0xa00e1c: LoadField: r0 = r4->field_8f
    //     0xa00e1c: ldur            w0, [x4, #0x8f]
    // 0xa00e20: DecompressPointer r0
    //     0xa00e20: add             x0, x0, HEAP, lsl #32
    // 0xa00e24: stur            x0, [fp, #-0x10]
    // 0xa00e28: LoadField: r1 = r0->field_b
    //     0xa00e28: ldur            w1, [x0, #0xb]
    // 0xa00e2c: DecompressPointer r1
    //     0xa00e2c: add             x1, x1, HEAP, lsl #32
    // 0xa00e30: stur            x1, [fp, #-8]
    // 0xa00e34: LoadField: r2 = r0->field_f
    //     0xa00e34: ldur            w2, [x0, #0xf]
    // 0xa00e38: DecompressPointer r2
    //     0xa00e38: add             x2, x2, HEAP, lsl #32
    // 0xa00e3c: LoadField: r3 = r2->field_b
    //     0xa00e3c: ldur            w3, [x2, #0xb]
    // 0xa00e40: DecompressPointer r3
    //     0xa00e40: add             x3, x3, HEAP, lsl #32
    // 0xa00e44: cmp             w1, w3
    // 0xa00e48: b.ne            #0xa00e58
    // 0xa00e4c: SaveReg r0
    //     0xa00e4c: str             x0, [SP, #-8]!
    // 0xa00e50: r0 = _growToNextCapacity()
    //     0xa00e50: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa00e54: add             SP, SP, #8
    // 0xa00e58: ldur            x2, [fp, #-0x10]
    // 0xa00e5c: ldur            x0, [fp, #-8]
    // 0xa00e60: r3 = LoadInt32Instr(r0)
    //     0xa00e60: sbfx            x3, x0, #1, #0x1f
    // 0xa00e64: add             x0, x3, #1
    // 0xa00e68: lsl             x1, x0, #1
    // 0xa00e6c: StoreField: r2->field_b = r1
    //     0xa00e6c: stur            w1, [x2, #0xb]
    // 0xa00e70: mov             x1, x3
    // 0xa00e74: cmp             x1, x0
    // 0xa00e78: b.hs            #0xa014dc
    // 0xa00e7c: LoadField: r0 = r2->field_f
    //     0xa00e7c: ldur            w0, [x2, #0xf]
    // 0xa00e80: DecompressPointer r0
    //     0xa00e80: add             x0, x0, HEAP, lsl #32
    // 0xa00e84: ArrayStore: r0[r3] = rZR  ; Unknown_4
    //     0xa00e84: add             x1, x0, x3, lsl #2
    //     0xa00e88: stur            wzr, [x1, #0xf]
    // 0xa00e8c: b               #0xa01438
    // 0xa00e90: r17 = 9142
    //     0xa00e90: mov             x17, #0x23b6
    // 0xa00e94: cmp             w3, w17
    // 0xa00e98: b.ne            #0xa00eec
    // 0xa00e9c: LoadField: r1 = r0->field_7
    //     0xa00e9c: ldur            w1, [x0, #7]
    // 0xa00ea0: DecompressPointer r1
    //     0xa00ea0: add             x1, x1, HEAP, lsl #32
    // 0xa00ea4: stur            x1, [fp, #-8]
    // 0xa00ea8: r0 = LoadClassIdInstr(r1)
    //     0xa00ea8: ldur            x0, [x1, #-1]
    //     0xa00eac: ubfx            x0, x0, #0xc, #0x14
    // 0xa00eb0: SaveReg r1
    //     0xa00eb0: str             x1, [SP, #-8]!
    // 0xa00eb4: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa00eb4: add             lr, x0, #0x2b8
    //     0xa00eb8: ldr             lr, [x21, lr, lsl #3]
    //     0xa00ebc: blr             lr
    // 0xa00ec0: add             SP, SP, #8
    // 0xa00ec4: ldr             x16, [fp, #0x18]
    // 0xa00ec8: stp             x0, x16, [SP, #-0x10]!
    // 0xa00ecc: r0 = writeValue()
    //     0xa00ecc: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0xa00ed0: add             SP, SP, #0x10
    // 0xa00ed4: ldr             x16, [fp, #0x18]
    // 0xa00ed8: ldur            lr, [fp, #-8]
    // 0xa00edc: stp             lr, x16, [SP, #-0x10]!
    // 0xa00ee0: r0 = writeValue()
    //     0xa00ee0: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0xa00ee4: add             SP, SP, #0x10
    // 0xa00ee8: b               #0xa01438
    // 0xa00eec: r17 = 9140
    //     0xa00eec: mov             x17, #0x23b4
    // 0xa00ef0: cmp             w3, w17
    // 0xa00ef4: b.ne            #0xa00fc0
    // 0xa00ef8: ldr             x4, [fp, #0x18]
    // 0xa00efc: LoadField: r1 = r4->field_93
    //     0xa00efc: ldur            w1, [x4, #0x93]
    // 0xa00f00: DecompressPointer r1
    //     0xa00f00: add             x1, x1, HEAP, lsl #32
    // 0xa00f04: stur            x1, [fp, #-8]
    // 0xa00f08: LoadField: r2 = r1->field_b
    //     0xa00f08: ldur            w2, [x1, #0xb]
    // 0xa00f0c: DecompressPointer r2
    //     0xa00f0c: add             x2, x2, HEAP, lsl #32
    // 0xa00f10: r3 = LoadInt32Instr(r2)
    //     0xa00f10: sbfx            x3, x2, #1, #0x1f
    // 0xa00f14: stp             x3, x4, [SP, #-0x10]!
    // 0xa00f18: r0 = writeUint32()
    //     0xa00f18: bl              #0xa01d18  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeUint32
    // 0xa00f1c: add             SP, SP, #0x10
    // 0xa00f20: ldr             x0, [fp, #0x10]
    // 0xa00f24: LoadField: r1 = r0->field_7
    //     0xa00f24: ldur            w1, [x0, #7]
    // 0xa00f28: DecompressPointer r1
    //     0xa00f28: add             x1, x1, HEAP, lsl #32
    // 0xa00f2c: ldur            x0, [fp, #-8]
    // 0xa00f30: stur            x1, [fp, #-0x28]
    // 0xa00f34: LoadField: r2 = r0->field_b
    //     0xa00f34: ldur            w2, [x0, #0xb]
    // 0xa00f38: DecompressPointer r2
    //     0xa00f38: add             x2, x2, HEAP, lsl #32
    // 0xa00f3c: stur            x2, [fp, #-0x10]
    // 0xa00f40: LoadField: r3 = r0->field_f
    //     0xa00f40: ldur            w3, [x0, #0xf]
    // 0xa00f44: DecompressPointer r3
    //     0xa00f44: add             x3, x3, HEAP, lsl #32
    // 0xa00f48: LoadField: r4 = r3->field_b
    //     0xa00f48: ldur            w4, [x3, #0xb]
    // 0xa00f4c: DecompressPointer r4
    //     0xa00f4c: add             x4, x4, HEAP, lsl #32
    // 0xa00f50: cmp             w2, w4
    // 0xa00f54: b.ne            #0xa00f64
    // 0xa00f58: SaveReg r0
    //     0xa00f58: str             x0, [SP, #-8]!
    // 0xa00f5c: r0 = _growToNextCapacity()
    //     0xa00f5c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa00f60: add             SP, SP, #8
    // 0xa00f64: ldur            x2, [fp, #-8]
    // 0xa00f68: ldur            x0, [fp, #-0x10]
    // 0xa00f6c: r3 = LoadInt32Instr(r0)
    //     0xa00f6c: sbfx            x3, x0, #1, #0x1f
    // 0xa00f70: add             x0, x3, #1
    // 0xa00f74: lsl             x1, x0, #1
    // 0xa00f78: StoreField: r2->field_b = r1
    //     0xa00f78: stur            w1, [x2, #0xb]
    // 0xa00f7c: mov             x1, x3
    // 0xa00f80: cmp             x1, x0
    // 0xa00f84: b.hs            #0xa014e0
    // 0xa00f88: LoadField: r1 = r2->field_f
    //     0xa00f88: ldur            w1, [x2, #0xf]
    // 0xa00f8c: DecompressPointer r1
    //     0xa00f8c: add             x1, x1, HEAP, lsl #32
    // 0xa00f90: ldur            x0, [fp, #-0x28]
    // 0xa00f94: ArrayStore: r1[r3] = r0  ; List_4
    //     0xa00f94: add             x25, x1, x3, lsl #2
    //     0xa00f98: add             x25, x25, #0xf
    //     0xa00f9c: str             w0, [x25]
    //     0xa00fa0: tbz             w0, #0, #0xa00fbc
    //     0xa00fa4: ldurb           w16, [x1, #-1]
    //     0xa00fa8: ldurb           w17, [x0, #-1]
    //     0xa00fac: and             x16, x17, x16, lsr #2
    //     0xa00fb0: tst             x16, HEAP, lsr #32
    //     0xa00fb4: b.eq            #0xa00fbc
    //     0xa00fb8: bl              #0xd67e5c
    // 0xa00fbc: b               #0xa01438
    // 0xa00fc0: ldr             x4, [fp, #0x18]
    // 0xa00fc4: r17 = 9138
    //     0xa00fc4: mov             x17, #0x23b2
    // 0xa00fc8: cmp             w3, w17
    // 0xa00fcc: b.ne            #0xa01074
    // 0xa00fd0: stp             x2, x4, [SP, #-0x10]!
    // 0xa00fd4: r0 = align()
    //     0xa00fd4: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa00fd8: add             SP, SP, #0x10
    // 0xa00fdc: ldr             x0, [fp, #0x10]
    // 0xa00fe0: LoadField: r1 = r0->field_7
    //     0xa00fe0: ldur            w1, [x0, #7]
    // 0xa00fe4: DecompressPointer r1
    //     0xa00fe4: add             x1, x1, HEAP, lsl #32
    // 0xa00fe8: r0 = LoadClassIdInstr(r1)
    //     0xa00fe8: ldur            x0, [x1, #-1]
    //     0xa00fec: ubfx            x0, x0, #0xc, #0x14
    // 0xa00ff0: SaveReg r1
    //     0xa00ff0: str             x1, [SP, #-8]!
    // 0xa00ff4: r0 = GDT[cid_x0 + 0xb940]()
    //     0xa00ff4: mov             x17, #0xb940
    //     0xa00ff8: add             lr, x0, x17
    //     0xa00ffc: ldr             lr, [x21, lr, lsl #3]
    //     0xa01000: blr             lr
    // 0xa01004: add             SP, SP, #8
    // 0xa01008: mov             x1, x0
    // 0xa0100c: stur            x1, [fp, #-8]
    // 0xa01010: CheckStackOverflow
    //     0xa01010: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01014: cmp             SP, x16
    //     0xa01018: b.ls            #0xa014e4
    // 0xa0101c: r0 = LoadClassIdInstr(r1)
    //     0xa0101c: ldur            x0, [x1, #-1]
    //     0xa01020: ubfx            x0, x0, #0xc, #0x14
    // 0xa01024: SaveReg r1
    //     0xa01024: str             x1, [SP, #-8]!
    // 0xa01028: r0 = GDT[cid_x0 + 0x541]()
    //     0xa01028: add             lr, x0, #0x541
    //     0xa0102c: ldr             lr, [x21, lr, lsl #3]
    //     0xa01030: blr             lr
    // 0xa01034: add             SP, SP, #8
    // 0xa01038: tbnz            w0, #4, #0xa01438
    // 0xa0103c: ldur            x1, [fp, #-8]
    // 0xa01040: r0 = LoadClassIdInstr(r1)
    //     0xa01040: ldur            x0, [x1, #-1]
    //     0xa01044: ubfx            x0, x0, #0xc, #0x14
    // 0xa01048: SaveReg r1
    //     0xa01048: str             x1, [SP, #-8]!
    // 0xa0104c: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xa0104c: add             lr, x0, #0x5ca
    //     0xa01050: ldr             lr, [x21, lr, lsl #3]
    //     0xa01054: blr             lr
    // 0xa01058: add             SP, SP, #8
    // 0xa0105c: ldr             x16, [fp, #0x18]
    // 0xa01060: stp             x0, x16, [SP, #-0x10]!
    // 0xa01064: r0 = writeValue()
    //     0xa01064: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0xa01068: add             SP, SP, #0x10
    // 0xa0106c: ldur            x1, [fp, #-8]
    // 0xa01070: b               #0xa01010
    // 0xa01074: r17 = 9136
    //     0xa01074: mov             x17, #0x23b0
    // 0xa01078: cmp             w3, w17
    // 0xa0107c: b.ne            #0xa01284
    // 0xa01080: ldr             x1, [fp, #0x18]
    // 0xa01084: r0 = DBusUint32()
    //     0xa01084: bl              #0xa00650  ; AllocateDBusUint32Stub -> DBusUint32 (size=0x10)
    // 0xa01088: mov             x1, x0
    // 0xa0108c: r0 = 0
    //     0xa0108c: mov             x0, #0
    // 0xa01090: StoreField: r1->field_7 = r0
    //     0xa01090: stur            x0, [x1, #7]
    // 0xa01094: ldr             x16, [fp, #0x18]
    // 0xa01098: stp             x1, x16, [SP, #-0x10]!
    // 0xa0109c: r0 = writeValue()
    //     0xa0109c: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0xa010a0: add             SP, SP, #0x10
    // 0xa010a4: ldr             x0, [fp, #0x18]
    // 0xa010a8: LoadField: r1 = r0->field_8f
    //     0xa010a8: ldur            w1, [x0, #0x8f]
    // 0xa010ac: DecompressPointer r1
    //     0xa010ac: add             x1, x1, HEAP, lsl #32
    // 0xa010b0: LoadField: r2 = r1->field_b
    //     0xa010b0: ldur            w2, [x1, #0xb]
    // 0xa010b4: DecompressPointer r2
    //     0xa010b4: add             x2, x2, HEAP, lsl #32
    // 0xa010b8: r1 = LoadInt32Instr(r2)
    //     0xa010b8: sbfx            x1, x2, #1, #0x1f
    // 0xa010bc: sub             x2, x1, #4
    // 0xa010c0: ldr             x1, [fp, #0x10]
    // 0xa010c4: stur            x2, [fp, #-0x18]
    // 0xa010c8: LoadField: r3 = r1->field_7
    //     0xa010c8: ldur            w3, [x1, #7]
    // 0xa010cc: DecompressPointer r3
    //     0xa010cc: add             x3, x3, HEAP, lsl #32
    // 0xa010d0: stp             x3, x0, [SP, #-0x10]!
    // 0xa010d4: r0 = getAlignment()
    //     0xa010d4: bl              #0xa01574  ; [package:dbus/src/dbus_buffer.dart] DBusBuffer::getAlignment
    // 0xa010d8: add             SP, SP, #0x10
    // 0xa010dc: ldr             x16, [fp, #0x18]
    // 0xa010e0: stp             x0, x16, [SP, #-0x10]!
    // 0xa010e4: r0 = align()
    //     0xa010e4: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa010e8: add             SP, SP, #0x10
    // 0xa010ec: ldr             x1, [fp, #0x18]
    // 0xa010f0: LoadField: r0 = r1->field_8f
    //     0xa010f0: ldur            w0, [x1, #0x8f]
    // 0xa010f4: DecompressPointer r0
    //     0xa010f4: add             x0, x0, HEAP, lsl #32
    // 0xa010f8: LoadField: r2 = r0->field_b
    //     0xa010f8: ldur            w2, [x0, #0xb]
    // 0xa010fc: DecompressPointer r2
    //     0xa010fc: add             x2, x2, HEAP, lsl #32
    // 0xa01100: ldr             x4, [fp, #0x10]
    // 0xa01104: stur            x2, [fp, #-8]
    // 0xa01108: LoadField: r0 = r4->field_b
    //     0xa01108: ldur            w0, [x4, #0xb]
    // 0xa0110c: DecompressPointer r0
    //     0xa0110c: add             x0, x0, HEAP, lsl #32
    // 0xa01110: r3 = LoadClassIdInstr(r0)
    //     0xa01110: ldur            x3, [x0, #-1]
    //     0xa01114: ubfx            x3, x3, #0xc, #0x14
    // 0xa01118: SaveReg r0
    //     0xa01118: str             x0, [SP, #-8]!
    // 0xa0111c: mov             x0, x3
    // 0xa01120: r0 = GDT[cid_x0 + 0xb940]()
    //     0xa01120: mov             x17, #0xb940
    //     0xa01124: add             lr, x0, x17
    //     0xa01128: ldr             lr, [x21, lr, lsl #3]
    //     0xa0112c: blr             lr
    // 0xa01130: add             SP, SP, #8
    // 0xa01134: mov             x1, x0
    // 0xa01138: stur            x1, [fp, #-0x10]
    // 0xa0113c: CheckStackOverflow
    //     0xa0113c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01140: cmp             SP, x16
    //     0xa01144: b.ls            #0xa014ec
    // 0xa01148: r0 = LoadClassIdInstr(r1)
    //     0xa01148: ldur            x0, [x1, #-1]
    //     0xa0114c: ubfx            x0, x0, #0xc, #0x14
    // 0xa01150: SaveReg r1
    //     0xa01150: str             x1, [SP, #-8]!
    // 0xa01154: r0 = GDT[cid_x0 + 0x541]()
    //     0xa01154: add             lr, x0, #0x541
    //     0xa01158: ldr             lr, [x21, lr, lsl #3]
    //     0xa0115c: blr             lr
    // 0xa01160: add             SP, SP, #8
    // 0xa01164: tbnz            w0, #4, #0xa011a0
    // 0xa01168: ldur            x1, [fp, #-0x10]
    // 0xa0116c: r0 = LoadClassIdInstr(r1)
    //     0xa0116c: ldur            x0, [x1, #-1]
    //     0xa01170: ubfx            x0, x0, #0xc, #0x14
    // 0xa01174: SaveReg r1
    //     0xa01174: str             x1, [SP, #-8]!
    // 0xa01178: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xa01178: add             lr, x0, #0x5ca
    //     0xa0117c: ldr             lr, [x21, lr, lsl #3]
    //     0xa01180: blr             lr
    // 0xa01184: add             SP, SP, #8
    // 0xa01188: ldr             x16, [fp, #0x18]
    // 0xa0118c: stp             x0, x16, [SP, #-0x10]!
    // 0xa01190: r0 = writeValue()
    //     0xa01190: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0xa01194: add             SP, SP, #0x10
    // 0xa01198: ldur            x1, [fp, #-0x10]
    // 0xa0119c: b               #0xa0113c
    // 0xa011a0: ldr             x5, [fp, #0x18]
    // 0xa011a4: ldur            x2, [fp, #-0x18]
    // 0xa011a8: ldur            x0, [fp, #-8]
    // 0xa011ac: r6 = 255
    //     0xa011ac: mov             x6, #0xff
    // 0xa011b0: LoadField: r3 = r5->field_8f
    //     0xa011b0: ldur            w3, [x5, #0x8f]
    // 0xa011b4: DecompressPointer r3
    //     0xa011b4: add             x3, x3, HEAP, lsl #32
    // 0xa011b8: LoadField: r1 = r3->field_b
    //     0xa011b8: ldur            w1, [x3, #0xb]
    // 0xa011bc: DecompressPointer r1
    //     0xa011bc: add             x1, x1, HEAP, lsl #32
    // 0xa011c0: r4 = LoadInt32Instr(r0)
    //     0xa011c0: sbfx            x4, x0, #1, #0x1f
    // 0xa011c4: r5 = LoadInt32Instr(r1)
    //     0xa011c4: sbfx            x5, x1, #1, #0x1f
    // 0xa011c8: sub             x7, x5, x4
    // 0xa011cc: mov             x0, x7
    // 0xa011d0: ubfx            x0, x0, #0, #0x20
    // 0xa011d4: and             x4, x0, x6
    // 0xa011d8: mov             x0, x5
    // 0xa011dc: mov             x1, x2
    // 0xa011e0: cmp             x1, x0
    // 0xa011e4: b.hs            #0xa014f4
    // 0xa011e8: LoadField: r8 = r3->field_f
    //     0xa011e8: ldur            w8, [x3, #0xf]
    // 0xa011ec: DecompressPointer r8
    //     0xa011ec: add             x8, x8, HEAP, lsl #32
    // 0xa011f0: lsl             w0, w4, #1
    // 0xa011f4: ArrayStore: r8[r2] = r0  ; Unknown_4
    //     0xa011f4: add             x1, x8, x2, lsl #2
    //     0xa011f8: stur            w0, [x1, #0xf]
    // 0xa011fc: add             x3, x2, #1
    // 0xa01200: asr             x0, x7, #8
    // 0xa01204: ubfx            x0, x0, #0, #0x20
    // 0xa01208: and             x4, x0, x6
    // 0xa0120c: mov             x0, x5
    // 0xa01210: mov             x1, x3
    // 0xa01214: cmp             x1, x0
    // 0xa01218: b.hs            #0xa014f8
    // 0xa0121c: lsl             w0, w4, #1
    // 0xa01220: ArrayStore: r8[r3] = r0  ; Unknown_4
    //     0xa01220: add             x1, x8, x3, lsl #2
    //     0xa01224: stur            w0, [x1, #0xf]
    // 0xa01228: add             x3, x2, #2
    // 0xa0122c: asr             x0, x7, #0x10
    // 0xa01230: ubfx            x0, x0, #0, #0x20
    // 0xa01234: and             x4, x0, x6
    // 0xa01238: mov             x0, x5
    // 0xa0123c: mov             x1, x3
    // 0xa01240: cmp             x1, x0
    // 0xa01244: b.hs            #0xa014fc
    // 0xa01248: lsl             w0, w4, #1
    // 0xa0124c: ArrayStore: r8[r3] = r0  ; Unknown_4
    //     0xa0124c: add             x1, x8, x3, lsl #2
    //     0xa01250: stur            w0, [x1, #0xf]
    // 0xa01254: add             x3, x2, #3
    // 0xa01258: asr             x0, x7, #0x18
    // 0xa0125c: ubfx            x0, x0, #0, #0x20
    // 0xa01260: and             x2, x0, x6
    // 0xa01264: mov             x0, x5
    // 0xa01268: mov             x1, x3
    // 0xa0126c: cmp             x1, x0
    // 0xa01270: b.hs            #0xa01500
    // 0xa01274: lsl             w0, w2, #1
    // 0xa01278: ArrayStore: r8[r3] = r0  ; Unknown_4
    //     0xa01278: add             x1, x8, x3, lsl #2
    //     0xa0127c: stur            w0, [x1, #0xf]
    // 0xa01280: b               #0xa01438
    // 0xa01284: ldr             x5, [fp, #0x18]
    // 0xa01288: mov             x4, x0
    // 0xa0128c: r0 = 0
    //     0xa0128c: mov             x0, #0
    // 0xa01290: r6 = 255
    //     0xa01290: mov             x6, #0xff
    // 0xa01294: r17 = 9134
    //     0xa01294: mov             x17, #0x23ae
    // 0xa01298: cmp             w3, w17
    // 0xa0129c: b.ne            #0xa01480
    // 0xa012a0: LoadField: r3 = r4->field_7
    //     0xa012a0: ldur            w3, [x4, #7]
    // 0xa012a4: DecompressPointer r3
    //     0xa012a4: add             x3, x3, HEAP, lsl #32
    // 0xa012a8: SaveReg r3
    //     0xa012a8: str             x3, [SP, #-8]!
    // 0xa012ac: r0 = isBasic()
    //     0xa012ac: bl              #0xa01514  ; [package:dbus/src/dbus_value.dart] DBusSignature::isBasic
    // 0xa012b0: add             SP, SP, #8
    // 0xa012b4: tbnz            w0, #4, #0xa01464
    // 0xa012b8: ldr             x1, [fp, #0x18]
    // 0xa012bc: ldr             x0, [fp, #0x10]
    // 0xa012c0: r0 = DBusUint32()
    //     0xa012c0: bl              #0xa00650  ; AllocateDBusUint32Stub -> DBusUint32 (size=0x10)
    // 0xa012c4: mov             x1, x0
    // 0xa012c8: r0 = 0
    //     0xa012c8: mov             x0, #0
    // 0xa012cc: StoreField: r1->field_7 = r0
    //     0xa012cc: stur            x0, [x1, #7]
    // 0xa012d0: ldr             x16, [fp, #0x18]
    // 0xa012d4: stp             x1, x16, [SP, #-0x10]!
    // 0xa012d8: r0 = writeValue()
    //     0xa012d8: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0xa012dc: add             SP, SP, #0x10
    // 0xa012e0: ldr             x0, [fp, #0x18]
    // 0xa012e4: LoadField: r1 = r0->field_8f
    //     0xa012e4: ldur            w1, [x0, #0x8f]
    // 0xa012e8: DecompressPointer r1
    //     0xa012e8: add             x1, x1, HEAP, lsl #32
    // 0xa012ec: LoadField: r2 = r1->field_b
    //     0xa012ec: ldur            w2, [x1, #0xb]
    // 0xa012f0: DecompressPointer r2
    //     0xa012f0: add             x2, x2, HEAP, lsl #32
    // 0xa012f4: r1 = LoadInt32Instr(r2)
    //     0xa012f4: sbfx            x1, x2, #1, #0x1f
    // 0xa012f8: sub             x2, x1, #4
    // 0xa012fc: stur            x2, [fp, #-0x18]
    // 0xa01300: SaveReg r0
    //     0xa01300: str             x0, [SP, #-8]!
    // 0xa01304: r1 = 8
    //     0xa01304: mov             x1, #8
    // 0xa01308: SaveReg r1
    //     0xa01308: str             x1, [SP, #-8]!
    // 0xa0130c: r0 = align()
    //     0xa0130c: bl              #0xa000f0  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::align
    // 0xa01310: add             SP, SP, #0x10
    // 0xa01314: ldr             x0, [fp, #0x18]
    // 0xa01318: LoadField: r1 = r0->field_8f
    //     0xa01318: ldur            w1, [x0, #0x8f]
    // 0xa0131c: DecompressPointer r1
    //     0xa0131c: add             x1, x1, HEAP, lsl #32
    // 0xa01320: LoadField: r3 = r1->field_b
    //     0xa01320: ldur            w3, [x1, #0xb]
    // 0xa01324: DecompressPointer r3
    //     0xa01324: add             x3, x3, HEAP, lsl #32
    // 0xa01328: ldr             x4, [fp, #0x10]
    // 0xa0132c: stur            x3, [fp, #-0x10]
    // 0xa01330: LoadField: r5 = r4->field_f
    //     0xa01330: ldur            w5, [x4, #0xf]
    // 0xa01334: DecompressPointer r5
    //     0xa01334: add             x5, x5, HEAP, lsl #32
    // 0xa01338: ldur            x2, [fp, #-0x48]
    // 0xa0133c: stur            x5, [fp, #-8]
    // 0xa01340: r1 = Function '<anonymous closure>':.
    //     0xa01340: ldr             x1, [PP, #0x78a8]  ; [pp+0x78a8] AnonymousClosure: (0xa01e1c), in [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue (0xa00668)
    // 0xa01344: r0 = AllocateClosure()
    //     0xa01344: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa01348: ldur            x16, [fp, #-8]
    // 0xa0134c: stp             x0, x16, [SP, #-0x10]!
    // 0xa01350: r0 = forEach()
    //     0xa01350: bl              #0xca3d28  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0xa01354: add             SP, SP, #0x10
    // 0xa01358: ldr             x0, [fp, #0x18]
    // 0xa0135c: LoadField: r2 = r0->field_8f
    //     0xa0135c: ldur            w2, [x0, #0x8f]
    // 0xa01360: DecompressPointer r2
    //     0xa01360: add             x2, x2, HEAP, lsl #32
    // 0xa01364: LoadField: r0 = r2->field_b
    //     0xa01364: ldur            w0, [x2, #0xb]
    // 0xa01368: DecompressPointer r0
    //     0xa01368: add             x0, x0, HEAP, lsl #32
    // 0xa0136c: ldur            x1, [fp, #-0x10]
    // 0xa01370: r3 = LoadInt32Instr(r1)
    //     0xa01370: sbfx            x3, x1, #1, #0x1f
    // 0xa01374: r4 = LoadInt32Instr(r0)
    //     0xa01374: sbfx            x4, x0, #1, #0x1f
    // 0xa01378: sub             x5, x4, x3
    // 0xa0137c: mov             x0, x5
    // 0xa01380: ubfx            x0, x0, #0, #0x20
    // 0xa01384: r3 = 255
    //     0xa01384: mov             x3, #0xff
    // 0xa01388: and             x6, x0, x3
    // 0xa0138c: mov             x0, x4
    // 0xa01390: ldur            x1, [fp, #-0x18]
    // 0xa01394: cmp             x1, x0
    // 0xa01398: b.hs            #0xa01504
    // 0xa0139c: LoadField: r7 = r2->field_f
    //     0xa0139c: ldur            w7, [x2, #0xf]
    // 0xa013a0: DecompressPointer r7
    //     0xa013a0: add             x7, x7, HEAP, lsl #32
    // 0xa013a4: lsl             w0, w6, #1
    // 0xa013a8: ldur            x2, [fp, #-0x18]
    // 0xa013ac: ArrayStore: r7[r2] = r0  ; Unknown_4
    //     0xa013ac: add             x1, x7, x2, lsl #2
    //     0xa013b0: stur            w0, [x1, #0xf]
    // 0xa013b4: add             x6, x2, #1
    // 0xa013b8: asr             x0, x5, #8
    // 0xa013bc: ubfx            x0, x0, #0, #0x20
    // 0xa013c0: and             x8, x0, x3
    // 0xa013c4: mov             x0, x4
    // 0xa013c8: mov             x1, x6
    // 0xa013cc: cmp             x1, x0
    // 0xa013d0: b.hs            #0xa01508
    // 0xa013d4: lsl             w0, w8, #1
    // 0xa013d8: ArrayStore: r7[r6] = r0  ; Unknown_4
    //     0xa013d8: add             x1, x7, x6, lsl #2
    //     0xa013dc: stur            w0, [x1, #0xf]
    // 0xa013e0: add             x6, x2, #2
    // 0xa013e4: asr             x0, x5, #0x10
    // 0xa013e8: ubfx            x0, x0, #0, #0x20
    // 0xa013ec: and             x8, x0, x3
    // 0xa013f0: mov             x0, x4
    // 0xa013f4: mov             x1, x6
    // 0xa013f8: cmp             x1, x0
    // 0xa013fc: b.hs            #0xa0150c
    // 0xa01400: lsl             w0, w8, #1
    // 0xa01404: ArrayStore: r7[r6] = r0  ; Unknown_4
    //     0xa01404: add             x1, x7, x6, lsl #2
    //     0xa01408: stur            w0, [x1, #0xf]
    // 0xa0140c: add             x6, x2, #3
    // 0xa01410: asr             x0, x5, #0x18
    // 0xa01414: ubfx            x0, x0, #0, #0x20
    // 0xa01418: and             x2, x0, x3
    // 0xa0141c: mov             x0, x4
    // 0xa01420: mov             x1, x6
    // 0xa01424: cmp             x1, x0
    // 0xa01428: b.hs            #0xa01510
    // 0xa0142c: lsl             w0, w2, #1
    // 0xa01430: ArrayStore: r7[r6] = r0  ; Unknown_4
    //     0xa01430: add             x1, x7, x6, lsl #2
    //     0xa01434: stur            w0, [x1, #0xf]
    // 0xa01438: r0 = Null
    //     0xa01438: mov             x0, NULL
    // 0xa0143c: LeaveFrame
    //     0xa0143c: mov             SP, fp
    //     0xa01440: ldp             fp, lr, [SP], #0x10
    // 0xa01444: ret
    //     0xa01444: ret             
    // 0xa01448: r0 = UnsupportedError()
    //     0xa01448: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0xa0144c: mov             x1, x0
    // 0xa01450: r0 = "D-Bus doesn\'t support reserved maybe type in signatures"
    //     0xa01450: ldr             x0, [PP, #0x78b0]  ; [pp+0x78b0] "D-Bus doesn\'t support reserved maybe type in signatures"
    // 0xa01454: StoreField: r1->field_b = r0
    //     0xa01454: stur            w0, [x1, #0xb]
    // 0xa01458: mov             x0, x1
    // 0xa0145c: r0 = Throw()
    //     0xa0145c: bl              #0xd67e38  ; ThrowStub
    // 0xa01460: brk             #0
    // 0xa01464: r0 = UnsupportedError()
    //     0xa01464: bl              #0x4b33e0  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0xa01468: mov             x1, x0
    // 0xa0146c: r0 = "D-Bus doesn\'t support dicts with non basic key types"
    //     0xa0146c: ldr             x0, [PP, #0x78b8]  ; [pp+0x78b8] "D-Bus doesn\'t support dicts with non basic key types"
    // 0xa01470: StoreField: r1->field_b = r0
    //     0xa01470: stur            w0, [x1, #0xb]
    // 0xa01474: mov             x0, x1
    // 0xa01478: r0 = Throw()
    //     0xa01478: bl              #0xd67e38  ; ThrowStub
    // 0xa0147c: brk             #0
    // 0xa01480: r1 = Null
    //     0xa01480: mov             x1, NULL
    // 0xa01484: r2 = 4
    //     0xa01484: mov             x2, #4
    // 0xa01488: r0 = AllocateArray()
    //     0xa01488: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0148c: r17 = "Unknown D-Bus value: "
    //     0xa0148c: ldr             x17, [PP, #0x78c0]  ; [pp+0x78c0] "Unknown D-Bus value: "
    // 0xa01490: StoreField: r0->field_f = r17
    //     0xa01490: stur            w17, [x0, #0xf]
    // 0xa01494: ldr             x1, [fp, #0x10]
    // 0xa01498: StoreField: r0->field_13 = r1
    //     0xa01498: stur            w1, [x0, #0x13]
    // 0xa0149c: SaveReg r0
    //     0xa0149c: str             x0, [SP, #-8]!
    // 0xa014a0: r0 = _interpolate()
    //     0xa014a0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa014a4: add             SP, SP, #8
    // 0xa014a8: r0 = Throw()
    //     0xa014a8: bl              #0xd67e38  ; ThrowStub
    // 0xa014ac: brk             #0
    // 0xa014b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa014b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa014b4: b               #0xa00680
    // 0xa014b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa014b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa014bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa014bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa014c0: b               #0xa009e0
    // 0xa014c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa014c4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa014c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa014c8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa014cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa014cc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa014d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa014d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa014d4: b               #0xa00cac
    // 0xa014d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa014d8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa014dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa014dc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa014e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa014e0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa014e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa014e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa014e8: b               #0xa0101c
    // 0xa014ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa014ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa014f0: b               #0xa01148
    // 0xa014f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa014f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa014f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa014f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa014fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa014fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa01500: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa01500: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa01504: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa01504: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa01508: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa01508: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa0150c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0150c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa01510: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa01510: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ writeFloat64(/* No info */) {
    // ** addr: 0xa01918, size: 0xfc
    // 0xa01918: EnterFrame
    //     0xa01918: stp             fp, lr, [SP, #-0x10]!
    //     0xa0191c: mov             fp, SP
    // 0xa01920: AllocStack(0x18)
    //     0xa01920: sub             SP, SP, #0x18
    // 0xa01924: CheckStackOverflow
    //     0xa01924: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01928: cmp             SP, x16
    //     0xa0192c: b.ls            #0xa01a0c
    // 0xa01930: r4 = 16
    //     0xa01930: mov             x4, #0x10
    // 0xa01934: r0 = AllocateUint8Array()
    //     0xa01934: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xa01938: stur            x0, [fp, #-8]
    // 0xa0193c: r0 = _ByteBuffer()
    //     0xa0193c: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0xa01940: mov             x1, x0
    // 0xa01944: ldur            x0, [fp, #-8]
    // 0xa01948: stur            x1, [fp, #-0x10]
    // 0xa0194c: StoreField: r1->field_7 = r0
    //     0xa0194c: stur            w0, [x1, #7]
    // 0xa01950: stp             x1, NULL, [SP, #-0x10]!
    // 0xa01954: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa01954: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa01958: r0 = ByteData.view()
    //     0xa01958: bl              #0x51bd70  ; [dart:typed_data] ByteData::ByteData.view
    // 0xa0195c: add             SP, SP, #0x10
    // 0xa01960: LoadField: r1 = r0->field_13
    //     0xa01960: ldur            w1, [x0, #0x13]
    // 0xa01964: DecompressPointer r1
    //     0xa01964: add             x1, x1, HEAP, lsl #32
    // 0xa01968: r2 = LoadInt32Instr(r1)
    //     0xa01968: sbfx            x2, x1, #1, #0x1f
    // 0xa0196c: cmp             x2, #7
    // 0xa01970: b.le            #0xa019cc
    // 0xa01974: ldr             d0, [fp, #0x10]
    // 0xa01978: LoadField: r1 = r0->field_17
    //     0xa01978: ldur            w1, [x0, #0x17]
    // 0xa0197c: DecompressPointer r1
    //     0xa0197c: add             x1, x1, HEAP, lsl #32
    // 0xa01980: LoadField: r2 = r0->field_1b
    //     0xa01980: ldur            w2, [x0, #0x1b]
    // 0xa01984: DecompressPointer r2
    //     0xa01984: add             x2, x2, HEAP, lsl #32
    // 0xa01988: LoadField: r0 = r1->field_7
    //     0xa01988: ldur            x0, [x1, #7]
    // 0xa0198c: asr             w1, w2, #1
    // 0xa01990: add             x1, x0, w1, sxtw
    // 0xa01994: str             d0, [x1]
    // 0xa01998: ldur            x16, [fp, #-0x10]
    // 0xa0199c: SaveReg r16
    //     0xa0199c: str             x16, [SP, #-8]!
    // 0xa019a0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa019a0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa019a4: r0 = asUint8List()
    //     0xa019a4: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0xa019a8: add             SP, SP, #8
    // 0xa019ac: ldr             x16, [fp, #0x18]
    // 0xa019b0: stp             x0, x16, [SP, #-0x10]!
    // 0xa019b4: r0 = writeBytes()
    //     0xa019b4: bl              #0xa000a8  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeBytes
    // 0xa019b8: add             SP, SP, #0x10
    // 0xa019bc: r0 = Null
    //     0xa019bc: mov             x0, NULL
    // 0xa019c0: LeaveFrame
    //     0xa019c0: mov             SP, fp
    //     0xa019c4: ldp             fp, lr, [SP], #0x10
    // 0xa019c8: ret
    //     0xa019c8: ret             
    // 0xa019cc: sub             x0, x2, #8
    // 0xa019d0: lsl             x1, x0, #1
    // 0xa019d4: stur            x1, [fp, #-8]
    // 0xa019d8: r0 = RangeError()
    //     0xa019d8: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa019dc: stur            x0, [fp, #-0x18]
    // 0xa019e0: stp             xzr, x0, [SP, #-0x10]!
    // 0xa019e4: ldur            x16, [fp, #-8]
    // 0xa019e8: stp             x16, xzr, [SP, #-0x10]!
    // 0xa019ec: r16 = "byteOffset"
    //     0xa019ec: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa019f0: SaveReg r16
    //     0xa019f0: str             x16, [SP, #-8]!
    // 0xa019f4: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa019f4: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa019f8: r0 = RangeError.range()
    //     0xa019f8: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa019fc: add             SP, SP, #0x28
    // 0xa01a00: ldur            x0, [fp, #-0x18]
    // 0xa01a04: r0 = Throw()
    //     0xa01a04: bl              #0xd67e38  ; ThrowStub
    // 0xa01a08: brk             #0
    // 0xa01a0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa01a0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa01a10: b               #0xa01930
  }
  _ writeInt64(/* No info */) {
    // ** addr: 0xa01a14, size: 0x100
    // 0xa01a14: EnterFrame
    //     0xa01a14: stp             fp, lr, [SP, #-0x10]!
    //     0xa01a18: mov             fp, SP
    // 0xa01a1c: AllocStack(0x18)
    //     0xa01a1c: sub             SP, SP, #0x18
    // 0xa01a20: CheckStackOverflow
    //     0xa01a20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01a24: cmp             SP, x16
    //     0xa01a28: b.ls            #0xa01b0c
    // 0xa01a2c: r4 = 16
    //     0xa01a2c: mov             x4, #0x10
    // 0xa01a30: r0 = AllocateUint8Array()
    //     0xa01a30: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xa01a34: stur            x0, [fp, #-8]
    // 0xa01a38: r0 = _ByteBuffer()
    //     0xa01a38: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0xa01a3c: mov             x1, x0
    // 0xa01a40: ldur            x0, [fp, #-8]
    // 0xa01a44: stur            x1, [fp, #-0x10]
    // 0xa01a48: StoreField: r1->field_7 = r0
    //     0xa01a48: stur            w0, [x1, #7]
    // 0xa01a4c: stp             xzr, x1, [SP, #-0x10]!
    // 0xa01a50: SaveReg rNULL
    //     0xa01a50: str             NULL, [SP, #-8]!
    // 0xa01a54: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa01a54: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa01a58: r0 = asByteData()
    //     0xa01a58: bl              #0xd64334  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0xa01a5c: add             SP, SP, #0x18
    // 0xa01a60: LoadField: r1 = r0->field_13
    //     0xa01a60: ldur            w1, [x0, #0x13]
    // 0xa01a64: DecompressPointer r1
    //     0xa01a64: add             x1, x1, HEAP, lsl #32
    // 0xa01a68: r2 = LoadInt32Instr(r1)
    //     0xa01a68: sbfx            x2, x1, #1, #0x1f
    // 0xa01a6c: cmp             x2, #7
    // 0xa01a70: b.le            #0xa01acc
    // 0xa01a74: ldr             x1, [fp, #0x10]
    // 0xa01a78: LoadField: r2 = r0->field_17
    //     0xa01a78: ldur            w2, [x0, #0x17]
    // 0xa01a7c: DecompressPointer r2
    //     0xa01a7c: add             x2, x2, HEAP, lsl #32
    // 0xa01a80: LoadField: r3 = r0->field_1b
    //     0xa01a80: ldur            w3, [x0, #0x1b]
    // 0xa01a84: DecompressPointer r3
    //     0xa01a84: add             x3, x3, HEAP, lsl #32
    // 0xa01a88: LoadField: r0 = r2->field_7
    //     0xa01a88: ldur            x0, [x2, #7]
    // 0xa01a8c: asr             w2, w3, #1
    // 0xa01a90: add             x2, x0, w2, sxtw
    // 0xa01a94: str             x1, [x2]
    // 0xa01a98: ldur            x16, [fp, #-0x10]
    // 0xa01a9c: SaveReg r16
    //     0xa01a9c: str             x16, [SP, #-8]!
    // 0xa01aa0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa01aa0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa01aa4: r0 = asUint8List()
    //     0xa01aa4: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0xa01aa8: add             SP, SP, #8
    // 0xa01aac: ldr             x16, [fp, #0x18]
    // 0xa01ab0: stp             x0, x16, [SP, #-0x10]!
    // 0xa01ab4: r0 = writeBytes()
    //     0xa01ab4: bl              #0xa000a8  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeBytes
    // 0xa01ab8: add             SP, SP, #0x10
    // 0xa01abc: r0 = Null
    //     0xa01abc: mov             x0, NULL
    // 0xa01ac0: LeaveFrame
    //     0xa01ac0: mov             SP, fp
    //     0xa01ac4: ldp             fp, lr, [SP], #0x10
    // 0xa01ac8: ret
    //     0xa01ac8: ret             
    // 0xa01acc: sub             x0, x2, #8
    // 0xa01ad0: lsl             x1, x0, #1
    // 0xa01ad4: stur            x1, [fp, #-8]
    // 0xa01ad8: r0 = RangeError()
    //     0xa01ad8: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa01adc: stur            x0, [fp, #-0x18]
    // 0xa01ae0: stp             xzr, x0, [SP, #-0x10]!
    // 0xa01ae4: ldur            x16, [fp, #-8]
    // 0xa01ae8: stp             x16, xzr, [SP, #-0x10]!
    // 0xa01aec: r16 = "byteOffset"
    //     0xa01aec: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa01af0: SaveReg r16
    //     0xa01af0: str             x16, [SP, #-8]!
    // 0xa01af4: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa01af4: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa01af8: r0 = RangeError.range()
    //     0xa01af8: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa01afc: add             SP, SP, #0x28
    // 0xa01b00: ldur            x0, [fp, #-0x18]
    // 0xa01b04: r0 = Throw()
    //     0xa01b04: bl              #0xd67e38  ; ThrowStub
    // 0xa01b08: brk             #0
    // 0xa01b0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa01b0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa01b10: b               #0xa01a2c
  }
  _ writeInt32(/* No info */) {
    // ** addr: 0xa01b14, size: 0x104
    // 0xa01b14: EnterFrame
    //     0xa01b14: stp             fp, lr, [SP, #-0x10]!
    //     0xa01b18: mov             fp, SP
    // 0xa01b1c: AllocStack(0x18)
    //     0xa01b1c: sub             SP, SP, #0x18
    // 0xa01b20: CheckStackOverflow
    //     0xa01b20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01b24: cmp             SP, x16
    //     0xa01b28: b.ls            #0xa01c10
    // 0xa01b2c: r4 = 8
    //     0xa01b2c: mov             x4, #8
    // 0xa01b30: r0 = AllocateUint8Array()
    //     0xa01b30: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xa01b34: stur            x0, [fp, #-8]
    // 0xa01b38: r0 = _ByteBuffer()
    //     0xa01b38: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0xa01b3c: mov             x1, x0
    // 0xa01b40: ldur            x0, [fp, #-8]
    // 0xa01b44: stur            x1, [fp, #-0x10]
    // 0xa01b48: StoreField: r1->field_7 = r0
    //     0xa01b48: stur            w0, [x1, #7]
    // 0xa01b4c: stp             xzr, x1, [SP, #-0x10]!
    // 0xa01b50: SaveReg rNULL
    //     0xa01b50: str             NULL, [SP, #-8]!
    // 0xa01b54: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa01b54: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa01b58: r0 = asByteData()
    //     0xa01b58: bl              #0xd64334  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0xa01b5c: add             SP, SP, #0x18
    // 0xa01b60: LoadField: r1 = r0->field_13
    //     0xa01b60: ldur            w1, [x0, #0x13]
    // 0xa01b64: DecompressPointer r1
    //     0xa01b64: add             x1, x1, HEAP, lsl #32
    // 0xa01b68: r2 = LoadInt32Instr(r1)
    //     0xa01b68: sbfx            x2, x1, #1, #0x1f
    // 0xa01b6c: cmp             x2, #3
    // 0xa01b70: b.le            #0xa01bd0
    // 0xa01b74: LoadField: r1 = r0->field_17
    //     0xa01b74: ldur            w1, [x0, #0x17]
    // 0xa01b78: DecompressPointer r1
    //     0xa01b78: add             x1, x1, HEAP, lsl #32
    // 0xa01b7c: LoadField: r2 = r0->field_1b
    //     0xa01b7c: ldur            w2, [x0, #0x1b]
    // 0xa01b80: DecompressPointer r2
    //     0xa01b80: add             x2, x2, HEAP, lsl #32
    // 0xa01b84: ldr             x0, [fp, #0x10]
    // 0xa01b88: sxtw            x0, w0
    // 0xa01b8c: LoadField: r3 = r1->field_7
    //     0xa01b8c: ldur            x3, [x1, #7]
    // 0xa01b90: asr             w1, w2, #1
    // 0xa01b94: add             x1, x3, w1, sxtw
    // 0xa01b98: str             w0, [x1]
    // 0xa01b9c: ldur            x16, [fp, #-0x10]
    // 0xa01ba0: SaveReg r16
    //     0xa01ba0: str             x16, [SP, #-8]!
    // 0xa01ba4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa01ba4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa01ba8: r0 = asUint8List()
    //     0xa01ba8: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0xa01bac: add             SP, SP, #8
    // 0xa01bb0: ldr             x16, [fp, #0x18]
    // 0xa01bb4: stp             x0, x16, [SP, #-0x10]!
    // 0xa01bb8: r0 = writeBytes()
    //     0xa01bb8: bl              #0xa000a8  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeBytes
    // 0xa01bbc: add             SP, SP, #0x10
    // 0xa01bc0: r0 = Null
    //     0xa01bc0: mov             x0, NULL
    // 0xa01bc4: LeaveFrame
    //     0xa01bc4: mov             SP, fp
    //     0xa01bc8: ldp             fp, lr, [SP], #0x10
    // 0xa01bcc: ret
    //     0xa01bcc: ret             
    // 0xa01bd0: sub             x0, x2, #4
    // 0xa01bd4: lsl             x1, x0, #1
    // 0xa01bd8: stur            x1, [fp, #-8]
    // 0xa01bdc: r0 = RangeError()
    //     0xa01bdc: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa01be0: stur            x0, [fp, #-0x18]
    // 0xa01be4: stp             xzr, x0, [SP, #-0x10]!
    // 0xa01be8: ldur            x16, [fp, #-8]
    // 0xa01bec: stp             x16, xzr, [SP, #-0x10]!
    // 0xa01bf0: r16 = "byteOffset"
    //     0xa01bf0: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa01bf4: SaveReg r16
    //     0xa01bf4: str             x16, [SP, #-8]!
    // 0xa01bf8: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa01bf8: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa01bfc: r0 = RangeError.range()
    //     0xa01bfc: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa01c00: add             SP, SP, #0x28
    // 0xa01c04: ldur            x0, [fp, #-0x18]
    // 0xa01c08: r0 = Throw()
    //     0xa01c08: bl              #0xd67e38  ; ThrowStub
    // 0xa01c0c: brk             #0
    // 0xa01c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa01c10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa01c14: b               #0xa01b2c
  }
  _ writeInt16(/* No info */) {
    // ** addr: 0xa01c18, size: 0x100
    // 0xa01c18: EnterFrame
    //     0xa01c18: stp             fp, lr, [SP, #-0x10]!
    //     0xa01c1c: mov             fp, SP
    // 0xa01c20: AllocStack(0x18)
    //     0xa01c20: sub             SP, SP, #0x18
    // 0xa01c24: CheckStackOverflow
    //     0xa01c24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01c28: cmp             SP, x16
    //     0xa01c2c: b.ls            #0xa01d10
    // 0xa01c30: r4 = 4
    //     0xa01c30: mov             x4, #4
    // 0xa01c34: r0 = AllocateUint8Array()
    //     0xa01c34: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xa01c38: stur            x0, [fp, #-8]
    // 0xa01c3c: r0 = _ByteBuffer()
    //     0xa01c3c: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0xa01c40: mov             x1, x0
    // 0xa01c44: ldur            x0, [fp, #-8]
    // 0xa01c48: stur            x1, [fp, #-0x10]
    // 0xa01c4c: StoreField: r1->field_7 = r0
    //     0xa01c4c: stur            w0, [x1, #7]
    // 0xa01c50: stp             xzr, x1, [SP, #-0x10]!
    // 0xa01c54: SaveReg rNULL
    //     0xa01c54: str             NULL, [SP, #-8]!
    // 0xa01c58: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa01c58: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa01c5c: r0 = asByteData()
    //     0xa01c5c: bl              #0xd64334  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0xa01c60: add             SP, SP, #0x18
    // 0xa01c64: LoadField: r1 = r0->field_13
    //     0xa01c64: ldur            w1, [x0, #0x13]
    // 0xa01c68: DecompressPointer r1
    //     0xa01c68: add             x1, x1, HEAP, lsl #32
    // 0xa01c6c: r2 = LoadInt32Instr(r1)
    //     0xa01c6c: sbfx            x2, x1, #1, #0x1f
    // 0xa01c70: cmp             x2, #1
    // 0xa01c74: b.le            #0xa01cd0
    // 0xa01c78: ldr             x1, [fp, #0x10]
    // 0xa01c7c: LoadField: r2 = r0->field_17
    //     0xa01c7c: ldur            w2, [x0, #0x17]
    // 0xa01c80: DecompressPointer r2
    //     0xa01c80: add             x2, x2, HEAP, lsl #32
    // 0xa01c84: LoadField: r3 = r0->field_1b
    //     0xa01c84: ldur            w3, [x0, #0x1b]
    // 0xa01c88: DecompressPointer r3
    //     0xa01c88: add             x3, x3, HEAP, lsl #32
    // 0xa01c8c: LoadField: r0 = r2->field_7
    //     0xa01c8c: ldur            x0, [x2, #7]
    // 0xa01c90: asr             w2, w3, #1
    // 0xa01c94: add             x2, x0, w2, sxtw
    // 0xa01c98: strh            w1, [x2]
    // 0xa01c9c: ldur            x16, [fp, #-0x10]
    // 0xa01ca0: SaveReg r16
    //     0xa01ca0: str             x16, [SP, #-8]!
    // 0xa01ca4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa01ca4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa01ca8: r0 = asUint8List()
    //     0xa01ca8: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0xa01cac: add             SP, SP, #8
    // 0xa01cb0: ldr             x16, [fp, #0x18]
    // 0xa01cb4: stp             x0, x16, [SP, #-0x10]!
    // 0xa01cb8: r0 = writeBytes()
    //     0xa01cb8: bl              #0xa000a8  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeBytes
    // 0xa01cbc: add             SP, SP, #0x10
    // 0xa01cc0: r0 = Null
    //     0xa01cc0: mov             x0, NULL
    // 0xa01cc4: LeaveFrame
    //     0xa01cc4: mov             SP, fp
    //     0xa01cc8: ldp             fp, lr, [SP], #0x10
    // 0xa01ccc: ret
    //     0xa01ccc: ret             
    // 0xa01cd0: sub             x0, x2, #2
    // 0xa01cd4: lsl             x1, x0, #1
    // 0xa01cd8: stur            x1, [fp, #-8]
    // 0xa01cdc: r0 = RangeError()
    //     0xa01cdc: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa01ce0: stur            x0, [fp, #-0x18]
    // 0xa01ce4: stp             xzr, x0, [SP, #-0x10]!
    // 0xa01ce8: ldur            x16, [fp, #-8]
    // 0xa01cec: stp             x16, xzr, [SP, #-0x10]!
    // 0xa01cf0: r16 = "byteOffset"
    //     0xa01cf0: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa01cf4: SaveReg r16
    //     0xa01cf4: str             x16, [SP, #-8]!
    // 0xa01cf8: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa01cf8: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa01cfc: r0 = RangeError.range()
    //     0xa01cfc: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa01d00: add             SP, SP, #0x28
    // 0xa01d04: ldur            x0, [fp, #-0x18]
    // 0xa01d08: r0 = Throw()
    //     0xa01d08: bl              #0xd67e38  ; ThrowStub
    // 0xa01d0c: brk             #0
    // 0xa01d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa01d10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa01d14: b               #0xa01c30
  }
  _ writeUint32(/* No info */) {
    // ** addr: 0xa01d18, size: 0x104
    // 0xa01d18: EnterFrame
    //     0xa01d18: stp             fp, lr, [SP, #-0x10]!
    //     0xa01d1c: mov             fp, SP
    // 0xa01d20: AllocStack(0x18)
    //     0xa01d20: sub             SP, SP, #0x18
    // 0xa01d24: CheckStackOverflow
    //     0xa01d24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01d28: cmp             SP, x16
    //     0xa01d2c: b.ls            #0xa01e14
    // 0xa01d30: r4 = 8
    //     0xa01d30: mov             x4, #8
    // 0xa01d34: r0 = AllocateUint8Array()
    //     0xa01d34: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xa01d38: stur            x0, [fp, #-8]
    // 0xa01d3c: r0 = _ByteBuffer()
    //     0xa01d3c: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0xa01d40: mov             x1, x0
    // 0xa01d44: ldur            x0, [fp, #-8]
    // 0xa01d48: stur            x1, [fp, #-0x10]
    // 0xa01d4c: StoreField: r1->field_7 = r0
    //     0xa01d4c: stur            w0, [x1, #7]
    // 0xa01d50: stp             xzr, x1, [SP, #-0x10]!
    // 0xa01d54: SaveReg rNULL
    //     0xa01d54: str             NULL, [SP, #-8]!
    // 0xa01d58: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa01d58: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa01d5c: r0 = asByteData()
    //     0xa01d5c: bl              #0xd64334  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0xa01d60: add             SP, SP, #0x18
    // 0xa01d64: LoadField: r1 = r0->field_13
    //     0xa01d64: ldur            w1, [x0, #0x13]
    // 0xa01d68: DecompressPointer r1
    //     0xa01d68: add             x1, x1, HEAP, lsl #32
    // 0xa01d6c: r2 = LoadInt32Instr(r1)
    //     0xa01d6c: sbfx            x2, x1, #1, #0x1f
    // 0xa01d70: cmp             x2, #3
    // 0xa01d74: b.le            #0xa01dd4
    // 0xa01d78: LoadField: r1 = r0->field_17
    //     0xa01d78: ldur            w1, [x0, #0x17]
    // 0xa01d7c: DecompressPointer r1
    //     0xa01d7c: add             x1, x1, HEAP, lsl #32
    // 0xa01d80: LoadField: r2 = r0->field_1b
    //     0xa01d80: ldur            w2, [x0, #0x1b]
    // 0xa01d84: DecompressPointer r2
    //     0xa01d84: add             x2, x2, HEAP, lsl #32
    // 0xa01d88: ldr             x0, [fp, #0x10]
    // 0xa01d8c: ubfx            x0, x0, #0, #0x20
    // 0xa01d90: LoadField: r3 = r1->field_7
    //     0xa01d90: ldur            x3, [x1, #7]
    // 0xa01d94: asr             w1, w2, #1
    // 0xa01d98: add             x1, x3, w1, sxtw
    // 0xa01d9c: str             w0, [x1]
    // 0xa01da0: ldur            x16, [fp, #-0x10]
    // 0xa01da4: SaveReg r16
    //     0xa01da4: str             x16, [SP, #-8]!
    // 0xa01da8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa01da8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa01dac: r0 = asUint8List()
    //     0xa01dac: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0xa01db0: add             SP, SP, #8
    // 0xa01db4: ldr             x16, [fp, #0x18]
    // 0xa01db8: stp             x0, x16, [SP, #-0x10]!
    // 0xa01dbc: r0 = writeBytes()
    //     0xa01dbc: bl              #0xa000a8  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeBytes
    // 0xa01dc0: add             SP, SP, #0x10
    // 0xa01dc4: r0 = Null
    //     0xa01dc4: mov             x0, NULL
    // 0xa01dc8: LeaveFrame
    //     0xa01dc8: mov             SP, fp
    //     0xa01dcc: ldp             fp, lr, [SP], #0x10
    // 0xa01dd0: ret
    //     0xa01dd0: ret             
    // 0xa01dd4: sub             x0, x2, #4
    // 0xa01dd8: lsl             x1, x0, #1
    // 0xa01ddc: stur            x1, [fp, #-8]
    // 0xa01de0: r0 = RangeError()
    //     0xa01de0: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa01de4: stur            x0, [fp, #-0x18]
    // 0xa01de8: stp             xzr, x0, [SP, #-0x10]!
    // 0xa01dec: ldur            x16, [fp, #-8]
    // 0xa01df0: stp             x16, xzr, [SP, #-0x10]!
    // 0xa01df4: r16 = "byteOffset"
    //     0xa01df4: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa01df8: SaveReg r16
    //     0xa01df8: str             x16, [SP, #-8]!
    // 0xa01dfc: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa01dfc: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa01e00: r0 = RangeError.range()
    //     0xa01e00: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa01e04: add             SP, SP, #0x28
    // 0xa01e08: ldur            x0, [fp, #-0x18]
    // 0xa01e0c: r0 = Throw()
    //     0xa01e0c: bl              #0xd67e38  ; ThrowStub
    // 0xa01e10: brk             #0
    // 0xa01e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa01e14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa01e18: b               #0xa01d30
  }
  [closure] void <anonymous closure>(dynamic, DBusValue, DBusValue) {
    // ** addr: 0xa01e1c, size: 0xc0
    // 0xa01e1c: EnterFrame
    //     0xa01e1c: stp             fp, lr, [SP, #-0x10]!
    //     0xa01e20: mov             fp, SP
    // 0xa01e24: AllocStack(0x10)
    //     0xa01e24: sub             SP, SP, #0x10
    // 0xa01e28: SetupParameters()
    //     0xa01e28: mov             x0, #4
    //     0xa01e2c: ldr             x1, [fp, #0x20]
    //     0xa01e30: ldur            w2, [x1, #0x17]
    //     0xa01e34: add             x2, x2, HEAP, lsl #32
    // 0xa01e28: r0 = 4
    // 0xa01e38: CheckStackOverflow
    //     0xa01e38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01e3c: cmp             SP, x16
    //     0xa01e40: b.ls            #0xa01ed4
    // 0xa01e44: LoadField: r3 = r2->field_f
    //     0xa01e44: ldur            w3, [x2, #0xf]
    // 0xa01e48: DecompressPointer r3
    //     0xa01e48: add             x3, x3, HEAP, lsl #32
    // 0xa01e4c: mov             x2, x0
    // 0xa01e50: stur            x3, [fp, #-8]
    // 0xa01e54: r1 = Null
    //     0xa01e54: mov             x1, NULL
    // 0xa01e58: r0 = AllocateArray()
    //     0xa01e58: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa01e5c: mov             x2, x0
    // 0xa01e60: ldr             x0, [fp, #0x18]
    // 0xa01e64: stur            x2, [fp, #-0x10]
    // 0xa01e68: StoreField: r2->field_f = r0
    //     0xa01e68: stur            w0, [x2, #0xf]
    // 0xa01e6c: ldr             x0, [fp, #0x10]
    // 0xa01e70: StoreField: r2->field_13 = r0
    //     0xa01e70: stur            w0, [x2, #0x13]
    // 0xa01e74: r1 = <DBusValue>
    //     0xa01e74: ldr             x1, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa01e78: r0 = AllocateGrowableArray()
    //     0xa01e78: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa01e7c: mov             x1, x0
    // 0xa01e80: ldur            x0, [fp, #-0x10]
    // 0xa01e84: StoreField: r1->field_f = r0
    //     0xa01e84: stur            w0, [x1, #0xf]
    // 0xa01e88: r0 = 4
    //     0xa01e88: mov             x0, #4
    // 0xa01e8c: StoreField: r1->field_b = r0
    //     0xa01e8c: stur            w0, [x1, #0xb]
    // 0xa01e90: SaveReg r1
    //     0xa01e90: str             x1, [SP, #-8]!
    // 0xa01e94: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa01e94: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa01e98: r0 = toList()
    //     0xa01e98: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0xa01e9c: add             SP, SP, #8
    // 0xa01ea0: stur            x0, [fp, #-0x10]
    // 0xa01ea4: r0 = DBusStruct()
    //     0xa01ea4: bl              #0xa00638  ; AllocateDBusStructStub -> DBusStruct (size=0xc)
    // 0xa01ea8: mov             x1, x0
    // 0xa01eac: ldur            x0, [fp, #-0x10]
    // 0xa01eb0: StoreField: r1->field_7 = r0
    //     0xa01eb0: stur            w0, [x1, #7]
    // 0xa01eb4: ldur            x16, [fp, #-8]
    // 0xa01eb8: stp             x1, x16, [SP, #-0x10]!
    // 0xa01ebc: r0 = writeValue()
    //     0xa01ebc: bl              #0xa00668  ; [package:dbus/src/dbus_write_buffer.dart] DBusWriteBuffer::writeValue
    // 0xa01ec0: add             SP, SP, #0x10
    // 0xa01ec4: r0 = Null
    //     0xa01ec4: mov             x0, NULL
    // 0xa01ec8: LeaveFrame
    //     0xa01ec8: mov             SP, fp
    //     0xa01ecc: ldp             fp, lr, [SP], #0x10
    // 0xa01ed0: ret
    //     0xa01ed0: ret             
    // 0xa01ed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa01ed4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa01ed8: b               #0xa01e44
  }
  _ DBusWriteBuffer(/* No info */) {
    // ** addr: 0xa01f24, size: 0xe0
    // 0xa01f24: EnterFrame
    //     0xa01f24: stp             fp, lr, [SP, #-0x10]!
    //     0xa01f28: mov             fp, SP
    // 0xa01f2c: CheckStackOverflow
    //     0xa01f2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01f30: cmp             SP, x16
    //     0xa01f34: b.ls            #0xa01ffc
    // 0xa01f38: r16 = <int>
    //     0xa01f38: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xa01f3c: stp             xzr, x16, [SP, #-0x10]!
    // 0xa01f40: r0 = _GrowableList()
    //     0xa01f40: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa01f44: add             SP, SP, #0x10
    // 0xa01f48: ldr             x1, [fp, #0x10]
    // 0xa01f4c: StoreField: r1->field_8f = r0
    //     0xa01f4c: stur            w0, [x1, #0x8f]
    //     0xa01f50: ldurb           w16, [x1, #-1]
    //     0xa01f54: ldurb           w17, [x0, #-1]
    //     0xa01f58: and             x16, x17, x16, lsr #2
    //     0xa01f5c: tst             x16, HEAP, lsr #32
    //     0xa01f60: b.eq            #0xa01f68
    //     0xa01f64: bl              #0xd6826c
    // 0xa01f68: r16 = <ResourceHandle>
    //     0xa01f68: ldr             x16, [PP, #0x968]  ; [pp+0x968] TypeArguments: <ResourceHandle>
    // 0xa01f6c: stp             xzr, x16, [SP, #-0x10]!
    // 0xa01f70: r0 = _GrowableList()
    //     0xa01f70: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa01f74: add             SP, SP, #0x10
    // 0xa01f78: ldr             x1, [fp, #0x10]
    // 0xa01f7c: StoreField: r1->field_93 = r0
    //     0xa01f7c: stur            w0, [x1, #0x93]
    //     0xa01f80: ldurb           w16, [x1, #-1]
    //     0xa01f84: ldurb           w17, [x0, #-1]
    //     0xa01f88: and             x16, x17, x16, lsr #2
    //     0xa01f8c: tst             x16, HEAP, lsr #32
    //     0xa01f90: b.eq            #0xa01f98
    //     0xa01f94: bl              #0xd6826c
    // 0xa01f98: r2 = 1
    //     0xa01f98: mov             x2, #1
    // 0xa01f9c: StoreField: r1->field_7 = r2
    //     0xa01f9c: stur            x2, [x1, #7]
    // 0xa01fa0: r3 = 4
    //     0xa01fa0: mov             x3, #4
    // 0xa01fa4: StoreField: r1->field_f = r3
    //     0xa01fa4: stur            x3, [x1, #0xf]
    // 0xa01fa8: r4 = 2
    //     0xa01fa8: mov             x4, #2
    // 0xa01fac: StoreField: r1->field_17 = r4
    //     0xa01fac: stur            x4, [x1, #0x17]
    // 0xa01fb0: StoreField: r1->field_1f = r4
    //     0xa01fb0: stur            x4, [x1, #0x1f]
    // 0xa01fb4: StoreField: r1->field_27 = r3
    //     0xa01fb4: stur            x3, [x1, #0x27]
    // 0xa01fb8: StoreField: r1->field_2f = r3
    //     0xa01fb8: stur            x3, [x1, #0x2f]
    // 0xa01fbc: r4 = 8
    //     0xa01fbc: mov             x4, #8
    // 0xa01fc0: StoreField: r1->field_37 = r4
    //     0xa01fc0: stur            x4, [x1, #0x37]
    // 0xa01fc4: StoreField: r1->field_3f = r4
    //     0xa01fc4: stur            x4, [x1, #0x3f]
    // 0xa01fc8: StoreField: r1->field_47 = r4
    //     0xa01fc8: stur            x4, [x1, #0x47]
    // 0xa01fcc: StoreField: r1->field_4f = r3
    //     0xa01fcc: stur            x3, [x1, #0x4f]
    // 0xa01fd0: StoreField: r1->field_57 = r3
    //     0xa01fd0: stur            x3, [x1, #0x57]
    // 0xa01fd4: StoreField: r1->field_5f = r2
    //     0xa01fd4: stur            x2, [x1, #0x5f]
    // 0xa01fd8: StoreField: r1->field_67 = r2
    //     0xa01fd8: stur            x2, [x1, #0x67]
    // 0xa01fdc: StoreField: r1->field_6f = r4
    //     0xa01fdc: stur            x4, [x1, #0x6f]
    // 0xa01fe0: StoreField: r1->field_77 = r3
    //     0xa01fe0: stur            x3, [x1, #0x77]
    // 0xa01fe4: StoreField: r1->field_7f = r4
    //     0xa01fe4: stur            x4, [x1, #0x7f]
    // 0xa01fe8: StoreField: r1->field_87 = r3
    //     0xa01fe8: stur            x3, [x1, #0x87]
    // 0xa01fec: r0 = Null
    //     0xa01fec: mov             x0, NULL
    // 0xa01ff0: LeaveFrame
    //     0xa01ff0: mov             SP, fp
    //     0xa01ff4: ldp             fp, lr, [SP], #0x10
    // 0xa01ff8: ret
    //     0xa01ff8: ret             
    // 0xa01ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa01ffc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa02000: b               #0xa01f38
  }
}

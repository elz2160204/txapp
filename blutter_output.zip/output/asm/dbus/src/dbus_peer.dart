// lib: , url: package:dbus/src/dbus_peer.dart

// class id: 1048846, size: 0x8
class :: {

  static _ handlePeerMethodCall(/* No info */) async {
    // ** addr: 0xa071f8, size: 0x274
    // 0xa071f8: EnterFrame
    //     0xa071f8: stp             fp, lr, [SP, #-0x10]!
    //     0xa071fc: mov             fp, SP
    // 0xa07200: AllocStack(0x30)
    //     0xa07200: sub             SP, SP, #0x30
    // 0xa07204: SetupParameters(dynamic _ /* r1, fp-0x10 */)
    //     0xa07204: stur            NULL, [fp, #-8]
    //     0xa07208: mov             x0, #0
    //     0xa0720c: add             x1, fp, w0, sxtw #2
    //     0xa07210: ldr             x1, [x1, #0x10]
    //     0xa07214: stur            x1, [fp, #-0x10]
    // 0xa07218: CheckStackOverflow
    //     0xa07218: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0721c: cmp             SP, x16
    //     0xa07220: b.ls            #0xa07464
    // 0xa07224: InitAsync() -> Future<DBusMethodResponse>
    //     0xa07224: ldr             x0, [PP, #0x7740]  ; [pp+0x7740] TypeArguments: <DBusMethodResponse>
    //     0xa07228: bl              #0x4b92e4
    // 0xa0722c: ldur            x1, [fp, #-0x10]
    // 0xa07230: LoadField: r2 = r1->field_f
    //     0xa07230: ldur            w2, [x1, #0xf]
    // 0xa07234: DecompressPointer r2
    //     0xa07234: add             x2, x2, HEAP, lsl #32
    // 0xa07238: stur            x2, [fp, #-0x18]
    // 0xa0723c: r0 = LoadClassIdInstr(r2)
    //     0xa0723c: ldur            x0, [x2, #-1]
    //     0xa07240: ubfx            x0, x0, #0xc, #0x14
    // 0xa07244: r16 = "GetMachineId"
    //     0xa07244: ldr             x16, [PP, #0x7f18]  ; [pp+0x7f18] "GetMachineId"
    // 0xa07248: stp             x16, x2, [SP, #-0x10]!
    // 0xa0724c: mov             lr, x0
    // 0xa07250: ldr             lr, [x21, lr, lsl #3]
    // 0xa07254: blr             lr
    // 0xa07258: add             SP, SP, #0x10
    // 0xa0725c: tbnz            w0, #4, #0xa07378
    // 0xa07260: ldur            x16, [fp, #-0x10]
    // 0xa07264: SaveReg r16
    //     0xa07264: str             x16, [SP, #-8]!
    // 0xa07268: r0 = signature()
    //     0xa07268: bl              #0xa0711c  ; [package:dbus/src/dbus_method_call.dart] DBusMethodCall::signature
    // 0xa0726c: add             SP, SP, #8
    // 0xa07270: stur            x0, [fp, #-0x20]
    // 0xa07274: r0 = DBusSignature()
    //     0xa07274: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa07278: stur            x0, [fp, #-0x28]
    // 0xa0727c: r16 = ""
    //     0xa0727c: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa07280: stp             x16, x0, [SP, #-0x10]!
    // 0xa07284: r0 = DBusSignature()
    //     0xa07284: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa07288: add             SP, SP, #0x10
    // 0xa0728c: ldur            x16, [fp, #-0x20]
    // 0xa07290: ldur            lr, [fp, #-0x28]
    // 0xa07294: stp             lr, x16, [SP, #-0x10]!
    // 0xa07298: r0 = ==()
    //     0xa07298: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0xa0729c: add             SP, SP, #0x10
    // 0xa072a0: tbz             w0, #4, #0xa072d0
    // 0xa072a4: r16 = <DBusValue>
    //     0xa072a4: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa072a8: stp             xzr, x16, [SP, #-0x10]!
    // 0xa072ac: r0 = _GrowableList()
    //     0xa072ac: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa072b0: add             SP, SP, #0x10
    // 0xa072b4: stur            x0, [fp, #-0x20]
    // 0xa072b8: r0 = DBusMethodErrorResponse()
    //     0xa072b8: bl              #0xa0565c  ; AllocateDBusMethodErrorResponseStub -> DBusMethodErrorResponse (size=0x10)
    // 0xa072bc: r1 = "org.freedesktop.DBus.Error.InvalidArgs"
    //     0xa072bc: ldr             x1, [PP, #0x7798]  ; [pp+0x7798] "org.freedesktop.DBus.Error.InvalidArgs"
    // 0xa072c0: StoreField: r0->field_7 = r1
    //     0xa072c0: stur            w1, [x0, #7]
    // 0xa072c4: ldur            x1, [fp, #-0x20]
    // 0xa072c8: StoreField: r0->field_b = r1
    //     0xa072c8: stur            w1, [x0, #0xb]
    // 0xa072cc: r0 = ReturnAsyncNotFuture()
    //     0xa072cc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa072d0: r0 = DBusMethodSuccessResponse()
    //     0xa072d0: bl              #0xa05650  ; AllocateDBusMethodSuccessResponseStub -> DBusMethodSuccessResponse (size=0xc)
    // 0xa072d4: stur            x0, [fp, #-0x20]
    // 0xa072d8: r0 = DBusString()
    //     0xa072d8: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0xa072dc: stur            x0, [fp, #-0x28]
    // 0xa072e0: r0 = getMachineId()
    //     0xa072e0: bl              #0xa0746c  ; [package:dbus/src/dbus_peer.dart] ::getMachineId
    // 0xa072e4: mov             x1, x0
    // 0xa072e8: stur            x1, [fp, #-0x30]
    // 0xa072ec: r0 = Await()
    //     0xa072ec: bl              #0x4b8e6c  ; AwaitStub
    // 0xa072f0: ldur            x3, [fp, #-0x28]
    // 0xa072f4: StoreField: r3->field_7 = r0
    //     0xa072f4: stur            w0, [x3, #7]
    //     0xa072f8: tbz             w0, #0, #0xa07314
    //     0xa072fc: ldurb           w16, [x3, #-1]
    //     0xa07300: ldurb           w17, [x0, #-1]
    //     0xa07304: and             x16, x17, x16, lsr #2
    //     0xa07308: tst             x16, HEAP, lsr #32
    //     0xa0730c: b.eq            #0xa07314
    //     0xa07310: bl              #0xd682ac
    // 0xa07314: r1 = Null
    //     0xa07314: mov             x1, NULL
    // 0xa07318: r2 = 2
    //     0xa07318: mov             x2, #2
    // 0xa0731c: r0 = AllocateArray()
    //     0xa0731c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa07320: mov             x2, x0
    // 0xa07324: ldur            x0, [fp, #-0x28]
    // 0xa07328: stur            x2, [fp, #-0x30]
    // 0xa0732c: StoreField: r2->field_f = r0
    //     0xa0732c: stur            w0, [x2, #0xf]
    // 0xa07330: r1 = <DBusValue>
    //     0xa07330: ldr             x1, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa07334: r0 = AllocateGrowableArray()
    //     0xa07334: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa07338: mov             x1, x0
    // 0xa0733c: ldur            x0, [fp, #-0x30]
    // 0xa07340: StoreField: r1->field_f = r0
    //     0xa07340: stur            w0, [x1, #0xf]
    // 0xa07344: r0 = 2
    //     0xa07344: mov             x0, #2
    // 0xa07348: StoreField: r1->field_b = r0
    //     0xa07348: stur            w0, [x1, #0xb]
    // 0xa0734c: mov             x0, x1
    // 0xa07350: ldur            x1, [fp, #-0x20]
    // 0xa07354: StoreField: r1->field_7 = r0
    //     0xa07354: stur            w0, [x1, #7]
    //     0xa07358: ldurb           w16, [x1, #-1]
    //     0xa0735c: ldurb           w17, [x0, #-1]
    //     0xa07360: and             x16, x17, x16, lsr #2
    //     0xa07364: tst             x16, HEAP, lsr #32
    //     0xa07368: b.eq            #0xa07370
    //     0xa0736c: bl              #0xd6826c
    // 0xa07370: mov             x0, x1
    // 0xa07374: r0 = ReturnAsyncNotFuture()
    //     0xa07374: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa07378: ldur            x0, [fp, #-0x18]
    // 0xa0737c: r1 = "org.freedesktop.DBus.Error.InvalidArgs"
    //     0xa0737c: ldr             x1, [PP, #0x7798]  ; [pp+0x7798] "org.freedesktop.DBus.Error.InvalidArgs"
    // 0xa07380: r2 = LoadClassIdInstr(r0)
    //     0xa07380: ldur            x2, [x0, #-1]
    //     0xa07384: ubfx            x2, x2, #0xc, #0x14
    // 0xa07388: r16 = "Ping"
    //     0xa07388: ldr             x16, [PP, #0x7f20]  ; [pp+0x7f20] "Ping"
    // 0xa0738c: stp             x16, x0, [SP, #-0x10]!
    // 0xa07390: mov             x0, x2
    // 0xa07394: mov             lr, x0
    // 0xa07398: ldr             lr, [x21, lr, lsl #3]
    // 0xa0739c: blr             lr
    // 0xa073a0: add             SP, SP, #0x10
    // 0xa073a4: tbnz            w0, #4, #0xa07438
    // 0xa073a8: ldur            x16, [fp, #-0x10]
    // 0xa073ac: SaveReg r16
    //     0xa073ac: str             x16, [SP, #-8]!
    // 0xa073b0: r0 = signature()
    //     0xa073b0: bl              #0xa0711c  ; [package:dbus/src/dbus_method_call.dart] DBusMethodCall::signature
    // 0xa073b4: add             SP, SP, #8
    // 0xa073b8: stur            x0, [fp, #-0x10]
    // 0xa073bc: r0 = DBusSignature()
    //     0xa073bc: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa073c0: stur            x0, [fp, #-0x18]
    // 0xa073c4: r16 = ""
    //     0xa073c4: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa073c8: stp             x16, x0, [SP, #-0x10]!
    // 0xa073cc: r0 = DBusSignature()
    //     0xa073cc: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa073d0: add             SP, SP, #0x10
    // 0xa073d4: ldur            x16, [fp, #-0x10]
    // 0xa073d8: ldur            lr, [fp, #-0x18]
    // 0xa073dc: stp             lr, x16, [SP, #-0x10]!
    // 0xa073e0: r0 = ==()
    //     0xa073e0: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0xa073e4: add             SP, SP, #0x10
    // 0xa073e8: tbz             w0, #4, #0xa07420
    // 0xa073ec: r16 = <DBusValue>
    //     0xa073ec: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa073f0: stp             xzr, x16, [SP, #-0x10]!
    // 0xa073f4: r0 = _GrowableList()
    //     0xa073f4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa073f8: add             SP, SP, #0x10
    // 0xa073fc: stur            x0, [fp, #-0x10]
    // 0xa07400: r0 = DBusMethodErrorResponse()
    //     0xa07400: bl              #0xa0565c  ; AllocateDBusMethodErrorResponseStub -> DBusMethodErrorResponse (size=0x10)
    // 0xa07404: mov             x1, x0
    // 0xa07408: r0 = "org.freedesktop.DBus.Error.InvalidArgs"
    //     0xa07408: ldr             x0, [PP, #0x7798]  ; [pp+0x7798] "org.freedesktop.DBus.Error.InvalidArgs"
    // 0xa0740c: StoreField: r1->field_7 = r0
    //     0xa0740c: stur            w0, [x1, #7]
    // 0xa07410: ldur            x0, [fp, #-0x10]
    // 0xa07414: StoreField: r1->field_b = r0
    //     0xa07414: stur            w0, [x1, #0xb]
    // 0xa07418: mov             x0, x1
    // 0xa0741c: r0 = ReturnAsyncNotFuture()
    //     0xa0741c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa07420: r0 = DBusMethodSuccessResponse()
    //     0xa07420: bl              #0xa05650  ; AllocateDBusMethodSuccessResponseStub -> DBusMethodSuccessResponse (size=0xc)
    // 0xa07424: mov             x1, x0
    // 0xa07428: r0 = const []
    //     0xa07428: ldr             x0, [PP, #0x7728]  ; [pp+0x7728] List<DBusValue>(0)
    // 0xa0742c: StoreField: r1->field_7 = r0
    //     0xa0742c: stur            w0, [x1, #7]
    // 0xa07430: mov             x0, x1
    // 0xa07434: r0 = ReturnAsyncNotFuture()
    //     0xa07434: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa07438: r16 = <DBusValue>
    //     0xa07438: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa0743c: stp             xzr, x16, [SP, #-0x10]!
    // 0xa07440: r0 = _GrowableList()
    //     0xa07440: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa07444: add             SP, SP, #0x10
    // 0xa07448: stur            x0, [fp, #-0x10]
    // 0xa0744c: r0 = DBusMethodErrorResponse()
    //     0xa0744c: bl              #0xa0565c  ; AllocateDBusMethodErrorResponseStub -> DBusMethodErrorResponse (size=0x10)
    // 0xa07450: r1 = "org.freedesktop.DBus.Error.UnknownMethod"
    //     0xa07450: ldr             x1, [PP, #0x7780]  ; [pp+0x7780] "org.freedesktop.DBus.Error.UnknownMethod"
    // 0xa07454: StoreField: r0->field_7 = r1
    //     0xa07454: stur            w1, [x0, #7]
    // 0xa07458: ldur            x1, [fp, #-0x10]
    // 0xa0745c: StoreField: r0->field_b = r1
    //     0xa0745c: stur            w1, [x0, #0xb]
    // 0xa07460: r0 = ReturnAsyncNotFuture()
    //     0xa07460: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa07464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa07464: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa07468: b               #0xa07224
  }
  static _ getMachineId(/* No info */) async {
    // ** addr: 0xa0746c, size: 0xcc
    // 0xa0746c: EnterFrame
    //     0xa0746c: stp             fp, lr, [SP, #-0x10]!
    //     0xa07470: mov             fp, SP
    // 0xa07474: AllocStack(0x18)
    //     0xa07474: sub             SP, SP, #0x18
    // 0xa07478: SetupParameters()
    //     0xa07478: stur            NULL, [fp, #-8]
    // 0xa0747c: CheckStackOverflow
    //     0xa0747c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa07480: cmp             SP, x16
    //     0xa07484: b.ls            #0xa07530
    // 0xa07488: InitAsync() -> Future<String>
    //     0xa07488: ldr             x0, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    //     0xa0748c: bl              #0x4b92e4
    // 0xa07490: r1 = Function 'readFirstLine': static.
    //     0xa07490: ldr             x1, [PP, #0x7f28]  ; [pp+0x7f28] AnonymousClosure: static (0xa07538), in [package:dbus/src/dbus_peer.dart] ::getMachineId (0xa0746c)
    // 0xa07494: r2 = Null
    //     0xa07494: mov             x2, NULL
    // 0xa07498: r0 = AllocateClosure()
    //     0xa07498: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0749c: mov             x1, x0
    // 0xa074a0: stur            x1, [fp, #-0x10]
    // 0xa074a4: r16 = "/var/lib/dbus/machine-id"
    //     0xa074a4: ldr             x16, [PP, #0x7f30]  ; [pp+0x7f30] "/var/lib/dbus/machine-id"
    // 0xa074a8: stp             x16, x1, [SP, #-0x10]!
    // 0xa074ac: mov             x0, x1
    // 0xa074b0: ClosureCall
    //     0xa074b0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xa074b4: ldur            x2, [x0, #0x1f]
    //     0xa074b8: blr             x2
    // 0xa074bc: add             SP, SP, #0x10
    // 0xa074c0: mov             x1, x0
    // 0xa074c4: stur            x1, [fp, #-0x18]
    // 0xa074c8: r0 = Await()
    //     0xa074c8: bl              #0x4b8e6c  ; AwaitStub
    // 0xa074cc: mov             x1, x0
    // 0xa074d0: stur            x1, [fp, #-0x18]
    // 0xa074d4: r0 = LoadClassIdInstr(r1)
    //     0xa074d4: ldur            x0, [x1, #-1]
    //     0xa074d8: ubfx            x0, x0, #0xc, #0x14
    // 0xa074dc: r16 = ""
    //     0xa074dc: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa074e0: stp             x16, x1, [SP, #-0x10]!
    // 0xa074e4: mov             lr, x0
    // 0xa074e8: ldr             lr, [x21, lr, lsl #3]
    // 0xa074ec: blr             lr
    // 0xa074f0: add             SP, SP, #0x10
    // 0xa074f4: tbnz            w0, #4, #0xa07528
    // 0xa074f8: ldur            x16, [fp, #-0x10]
    // 0xa074fc: r30 = "/etc/machine-id"
    //     0xa074fc: ldr             lr, [PP, #0x7f38]  ; [pp+0x7f38] "/etc/machine-id"
    // 0xa07500: stp             lr, x16, [SP, #-0x10]!
    // 0xa07504: ldur            x0, [fp, #-0x10]
    // 0xa07508: ClosureCall
    //     0xa07508: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xa0750c: ldur            x2, [x0, #0x1f]
    //     0xa07510: blr             x2
    // 0xa07514: add             SP, SP, #0x10
    // 0xa07518: mov             x1, x0
    // 0xa0751c: stur            x1, [fp, #-0x10]
    // 0xa07520: r0 = Await()
    //     0xa07520: bl              #0x4b8e6c  ; AwaitStub
    // 0xa07524: b               #0xa0752c
    // 0xa07528: ldur            x0, [fp, #-0x18]
    // 0xa0752c: r0 = ReturnAsync()
    //     0xa0752c: b               #0x501858  ; ReturnAsyncStub
    // 0xa07530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa07530: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa07534: b               #0xa07488
  }
  [closure] static Future<String> readFirstLine(dynamic, String) async {
    // ** addr: 0xa07538, size: 0x150
    // 0xa07538: EnterFrame
    //     0xa07538: stp             fp, lr, [SP, #-0x10]!
    //     0xa0753c: mov             fp, SP
    // 0xa07540: AllocStack(0x60)
    //     0xa07540: sub             SP, SP, #0x60
    // 0xa07544: SetupParameters(dynamic _ /* r1, fp-0x60 */, dynamic _ /* r2, fp-0x58 */)
    //     0xa07544: stur            NULL, [fp, #-8]
    //     0xa07548: mov             x0, #0
    //     0xa0754c: add             x1, fp, w0, sxtw #2
    //     0xa07550: ldr             x1, [x1, #0x18]
    //     0xa07554: stur            x1, [fp, #-0x60]
    //     0xa07558: add             x2, fp, w0, sxtw #2
    //     0xa0755c: ldr             x2, [x2, #0x10]
    //     0xa07560: stur            x2, [fp, #-0x58]
    //     0xa07564: ldur            w3, [x1, #0x17]
    //     0xa07568: add             x3, x3, HEAP, lsl #32
    //     0xa0756c: stur            x3, [fp, #-0x50]
    // 0xa07570: CheckStackOverflow
    //     0xa07570: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa07574: cmp             SP, x16
    //     0xa07578: b.ls            #0xa07680
    // 0xa0757c: InitAsync() -> Future<String>
    //     0xa0757c: ldr             x0, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    //     0xa07580: bl              #0x4b92e4
    // 0xa07584: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xa07584: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa07588: ldr             x0, [x0, #0xb58]
    //     0xa0758c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa07590: cmp             w0, w16
    //     0xa07594: b.ne            #0xa075a0
    //     0xa07598: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xa0759c: bl              #0xd67d44
    // 0xa075a0: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xa075a0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa075a4: ldr             x0, [x0, #0xdd8]
    //     0xa075a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa075ac: cmp             w0, w16
    //     0xa075b0: b.ne            #0xa075bc
    //     0xa075b4: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xa075b8: bl              #0xd67cdc
    // 0xa075bc: r0 = _File()
    //     0xa075bc: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xa075c0: mov             x1, x0
    // 0xa075c4: ldur            x0, [fp, #-0x58]
    // 0xa075c8: stur            x1, [fp, #-0x50]
    // 0xa075cc: StoreField: r1->field_7 = r0
    //     0xa075cc: stur            w0, [x1, #7]
    // 0xa075d0: SaveReg r0
    //     0xa075d0: str             x0, [SP, #-8]!
    // 0xa075d4: r0 = _toUtf8Array()
    //     0xa075d4: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xa075d8: add             SP, SP, #8
    // 0xa075dc: ldur            x1, [fp, #-0x50]
    // 0xa075e0: StoreField: r1->field_b = r0
    //     0xa075e0: stur            w0, [x1, #0xb]
    //     0xa075e4: ldurb           w16, [x1, #-1]
    //     0xa075e8: ldurb           w17, [x0, #-1]
    //     0xa075ec: and             x16, x17, x16, lsr #2
    //     0xa075f0: tst             x16, HEAP, lsr #32
    //     0xa075f4: b.eq            #0xa075fc
    //     0xa075f8: bl              #0xd6826c
    // 0xa075fc: SaveReg r1
    //     0xa075fc: str             x1, [SP, #-8]!
    // 0xa07600: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa07600: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa07604: r0 = readAsLines()
    //     0xa07604: bl              #0xca7554  ; [dart:io] _File::readAsLines
    // 0xa07608: add             SP, SP, #8
    // 0xa0760c: mov             x1, x0
    // 0xa07610: stur            x1, [fp, #-0x50]
    // 0xa07614: r0 = Await()
    //     0xa07614: bl              #0x4b8e6c  ; AwaitStub
    // 0xa07618: r1 = LoadClassIdInstr(r0)
    //     0xa07618: ldur            x1, [x0, #-1]
    //     0xa0761c: ubfx            x1, x1, #0xc, #0x14
    // 0xa07620: stp             xzr, x0, [SP, #-0x10]!
    // 0xa07624: mov             x0, x1
    // 0xa07628: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa07628: sub             lr, x0, #0xd83
    //     0xa0762c: ldr             lr, [x21, lr, lsl #3]
    //     0xa07630: blr             lr
    // 0xa07634: add             SP, SP, #0x10
    // 0xa07638: r0 = ReturnAsync()
    //     0xa07638: b               #0x501858  ; ReturnAsyncStub
    // 0xa0763c: sub             SP, fp, #0x60
    // 0xa07640: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xa07640: mov             x2, #0x76
    //     0xa07644: tbz             w0, #0, #0xa07654
    //     0xa07648: ldur            x2, [x0, #-1]
    //     0xa0764c: ubfx            x2, x2, #0xc, #0x14
    //     0xa07650: lsl             x2, x2, #1
    // 0xa07654: r3 = LoadInt32Instr(r2)
    //     0xa07654: sbfx            x3, x2, #1, #0x1f
    // 0xa07658: r17 = 5134
    //     0xa07658: mov             x17, #0x140e
    // 0xa0765c: cmp             x3, x17
    // 0xa07660: b.lt            #0xa07678
    // 0xa07664: r17 = 5135
    //     0xa07664: mov             x17, #0x140f
    // 0xa07668: cmp             x3, x17
    // 0xa0766c: b.gt            #0xa07678
    // 0xa07670: r0 = ""
    //     0xa07670: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa07674: r0 = ReturnAsyncNotFuture()
    //     0xa07674: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa07678: r0 = ReThrow()
    //     0xa07678: bl              #0xd67e14  ; ReThrowStub
    // 0xa0767c: brk             #0
    // 0xa07680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa07680: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa07684: b               #0xa0757c
  }
}

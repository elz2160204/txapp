// lib: , url: package:dbus/src/dbus_member_name.dart

// class id: 1048839, size: 0x8
class :: {
}

// class id: 4612, size: 0xc, field offset: 0x8
class DBusMemberName extends Object {

  _ DBusMemberName(/* No info */) {
    // ** addr: 0xa0201c, size: 0x104
    // 0xa0201c: EnterFrame
    //     0xa0201c: stp             fp, lr, [SP, #-0x10]!
    //     0xa02020: mov             fp, SP
    // 0xa02024: CheckStackOverflow
    //     0xa02024: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa02028: cmp             SP, x16
    //     0xa0202c: b.ls            #0xa02118
    // 0xa02030: ldr             x0, [fp, #0x10]
    // 0xa02034: ldr             x1, [fp, #0x18]
    // 0xa02038: StoreField: r1->field_7 = r0
    //     0xa02038: stur            w0, [x1, #7]
    //     0xa0203c: ldurb           w16, [x1, #-1]
    //     0xa02040: ldurb           w17, [x0, #-1]
    //     0xa02044: and             x16, x17, x16, lsr #2
    //     0xa02048: tst             x16, HEAP, lsr #32
    //     0xa0204c: b.eq            #0xa02054
    //     0xa02050: bl              #0xd6826c
    // 0xa02054: ldr             x0, [fp, #0x10]
    // 0xa02058: LoadField: r1 = r0->field_7
    //     0xa02058: ldur            w1, [x0, #7]
    // 0xa0205c: DecompressPointer r1
    //     0xa0205c: add             x1, x1, HEAP, lsl #32
    // 0xa02060: r2 = LoadInt32Instr(r1)
    //     0xa02060: sbfx            x2, x1, #1, #0x1f
    // 0xa02064: cmp             x2, #0xff
    // 0xa02068: b.gt            #0xa020c4
    // 0xa0206c: cbz             w1, #0xa020e0
    // 0xa02070: r16 = "^[a-zA-Z_][0-9a-zA-Z_]*$"
    //     0xa02070: ldr             x16, [PP, #0x538]  ; [pp+0x538] "^[a-zA-Z_][0-9a-zA-Z_]*$"
    // 0xa02074: stp             x16, NULL, [SP, #-0x10]!
    // 0xa02078: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa02078: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0207c: r0 = RegExp()
    //     0xa0207c: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0xa02080: add             SP, SP, #0x10
    // 0xa02084: mov             x1, x0
    // 0xa02088: ldr             x0, [fp, #0x10]
    // 0xa0208c: r2 = LoadClassIdInstr(r0)
    //     0xa0208c: ldur            x2, [x0, #-1]
    //     0xa02090: ubfx            x2, x2, #0xc, #0x14
    // 0xa02094: stp             x1, x0, [SP, #-0x10]!
    // 0xa02098: mov             x0, x2
    // 0xa0209c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0209c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa020a0: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa020a0: sub             lr, x0, #0xffc
    //     0xa020a4: ldr             lr, [x21, lr, lsl #3]
    //     0xa020a8: blr             lr
    // 0xa020ac: add             SP, SP, #0x10
    // 0xa020b0: tbnz            w0, #4, #0xa020fc
    // 0xa020b4: r0 = Null
    //     0xa020b4: mov             x0, NULL
    // 0xa020b8: LeaveFrame
    //     0xa020b8: mov             SP, fp
    //     0xa020bc: ldp             fp, lr, [SP], #0x10
    // 0xa020c0: ret
    //     0xa020c0: ret             
    // 0xa020c4: r0 = FormatException()
    //     0xa020c4: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa020c8: mov             x1, x0
    // 0xa020cc: r0 = "Member name too long"
    //     0xa020cc: ldr             x0, [PP, #0x540]  ; [pp+0x540] "Member name too long"
    // 0xa020d0: StoreField: r1->field_7 = r0
    //     0xa020d0: stur            w0, [x1, #7]
    // 0xa020d4: mov             x0, x1
    // 0xa020d8: r0 = Throw()
    //     0xa020d8: bl              #0xd67e38  ; ThrowStub
    // 0xa020dc: brk             #0
    // 0xa020e0: r0 = FormatException()
    //     0xa020e0: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa020e4: mov             x1, x0
    // 0xa020e8: r0 = "Member name too short"
    //     0xa020e8: ldr             x0, [PP, #0x548]  ; [pp+0x548] "Member name too short"
    // 0xa020ec: StoreField: r1->field_7 = r0
    //     0xa020ec: stur            w0, [x1, #7]
    // 0xa020f0: mov             x0, x1
    // 0xa020f4: r0 = Throw()
    //     0xa020f4: bl              #0xd67e38  ; ThrowStub
    // 0xa020f8: brk             #0
    // 0xa020fc: r0 = FormatException()
    //     0xa020fc: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa02100: mov             x1, x0
    // 0xa02104: r0 = "Invalid characters in member name"
    //     0xa02104: ldr             x0, [PP, #0x550]  ; [pp+0x550] "Invalid characters in member name"
    // 0xa02108: StoreField: r1->field_7 = r0
    //     0xa02108: stur            w0, [x1, #7]
    // 0xa0210c: mov             x0, x1
    // 0xa02110: r0 = Throw()
    //     0xa02110: bl              #0xd67e38  ; ThrowStub
    // 0xa02114: brk             #0
    // 0xa02118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa02118: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0211c: b               #0xa02030
  }
  _ toString(/* No info */) {
    // ** addr: 0xad03bc, size: 0x68
    // 0xad03bc: EnterFrame
    //     0xad03bc: stp             fp, lr, [SP, #-0x10]!
    //     0xad03c0: mov             fp, SP
    // 0xad03c4: CheckStackOverflow
    //     0xad03c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad03c8: cmp             SP, x16
    //     0xad03cc: b.ls            #0xad041c
    // 0xad03d0: r1 = Null
    //     0xad03d0: mov             x1, NULL
    // 0xad03d4: r2 = 8
    //     0xad03d4: mov             x2, #8
    // 0xad03d8: r0 = AllocateArray()
    //     0xad03d8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad03dc: r17 = DBusMemberName
    //     0xad03dc: ldr             x17, [PP, #0x7630]  ; [pp+0x7630] Type: DBusMemberName
    // 0xad03e0: StoreField: r0->field_f = r17
    //     0xad03e0: stur            w17, [x0, #0xf]
    // 0xad03e4: r17 = "(\'"
    //     0xad03e4: ldr             x17, [PP, #0x7168]  ; [pp+0x7168] "(\'"
    // 0xad03e8: StoreField: r0->field_13 = r17
    //     0xad03e8: stur            w17, [x0, #0x13]
    // 0xad03ec: ldr             x1, [fp, #0x10]
    // 0xad03f0: LoadField: r2 = r1->field_7
    //     0xad03f0: ldur            w2, [x1, #7]
    // 0xad03f4: DecompressPointer r2
    //     0xad03f4: add             x2, x2, HEAP, lsl #32
    // 0xad03f8: StoreField: r0->field_17 = r2
    //     0xad03f8: stur            w2, [x0, #0x17]
    // 0xad03fc: r17 = "\')"
    //     0xad03fc: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xad0400: StoreField: r0->field_1b = r17
    //     0xad0400: stur            w17, [x0, #0x1b]
    // 0xad0404: SaveReg r0
    //     0xad0404: str             x0, [SP, #-8]!
    // 0xad0408: r0 = _interpolate()
    //     0xad0408: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad040c: add             SP, SP, #8
    // 0xad0410: LeaveFrame
    //     0xad0410: mov             SP, fp
    //     0xad0414: ldp             fp, lr, [SP], #0x10
    // 0xad0418: ret
    //     0xad0418: ret             
    // 0xad041c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad041c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad0420: b               #0xad03d0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e5e0, size: 0xa0
    // 0xc6e5e0: EnterFrame
    //     0xc6e5e0: stp             fp, lr, [SP, #-0x10]!
    //     0xc6e5e4: mov             fp, SP
    // 0xc6e5e8: CheckStackOverflow
    //     0xc6e5e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6e5ec: cmp             SP, x16
    //     0xc6e5f0: b.ls            #0xc6e678
    // 0xc6e5f4: ldr             x0, [fp, #0x10]
    // 0xc6e5f8: cmp             w0, NULL
    // 0xc6e5fc: b.ne            #0xc6e610
    // 0xc6e600: r0 = false
    //     0xc6e600: add             x0, NULL, #0x30  ; false
    // 0xc6e604: LeaveFrame
    //     0xc6e604: mov             SP, fp
    //     0xc6e608: ldp             fp, lr, [SP], #0x10
    // 0xc6e60c: ret
    //     0xc6e60c: ret             
    // 0xc6e610: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6e610: mov             x1, #0x76
    //     0xc6e614: tbz             w0, #0, #0xc6e624
    //     0xc6e618: ldur            x1, [x0, #-1]
    //     0xc6e61c: ubfx            x1, x1, #0xc, #0x14
    //     0xc6e620: lsl             x1, x1, #1
    // 0xc6e624: r17 = 9224
    //     0xc6e624: mov             x17, #0x2408
    // 0xc6e628: cmp             w1, w17
    // 0xc6e62c: b.ne            #0xc6e668
    // 0xc6e630: ldr             x1, [fp, #0x18]
    // 0xc6e634: LoadField: r2 = r0->field_7
    //     0xc6e634: ldur            w2, [x0, #7]
    // 0xc6e638: DecompressPointer r2
    //     0xc6e638: add             x2, x2, HEAP, lsl #32
    // 0xc6e63c: LoadField: r0 = r1->field_7
    //     0xc6e63c: ldur            w0, [x1, #7]
    // 0xc6e640: DecompressPointer r0
    //     0xc6e640: add             x0, x0, HEAP, lsl #32
    // 0xc6e644: r1 = LoadClassIdInstr(r2)
    //     0xc6e644: ldur            x1, [x2, #-1]
    //     0xc6e648: ubfx            x1, x1, #0xc, #0x14
    // 0xc6e64c: stp             x0, x2, [SP, #-0x10]!
    // 0xc6e650: mov             x0, x1
    // 0xc6e654: mov             lr, x0
    // 0xc6e658: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e65c: blr             lr
    // 0xc6e660: add             SP, SP, #0x10
    // 0xc6e664: b               #0xc6e66c
    // 0xc6e668: r0 = false
    //     0xc6e668: add             x0, NULL, #0x30  ; false
    // 0xc6e66c: LeaveFrame
    //     0xc6e66c: mov             SP, fp
    //     0xc6e670: ldp             fp, lr, [SP], #0x10
    // 0xc6e674: ret
    //     0xc6e674: ret             
    // 0xc6e678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6e678: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6e67c: b               #0xc6e5f4
  }
}

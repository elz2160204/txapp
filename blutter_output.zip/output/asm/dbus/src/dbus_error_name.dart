// lib: , url: package:dbus/src/dbus_error_name.dart

// class id: 1048834, size: 0x8
class :: {
}

// class id: 4622, size: 0xc, field offset: 0x8
class DBusErrorName extends Object {

  _ DBusErrorName(/* No info */) {
    // ** addr: 0xa05c50, size: 0x290
    // 0xa05c50: EnterFrame
    //     0xa05c50: stp             fp, lr, [SP, #-0x10]!
    //     0xa05c54: mov             fp, SP
    // 0xa05c58: AllocStack(0x30)
    //     0xa05c58: sub             SP, SP, #0x30
    // 0xa05c5c: CheckStackOverflow
    //     0xa05c5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa05c60: cmp             SP, x16
    //     0xa05c64: b.ls            #0xa05ed0
    // 0xa05c68: ldr             x0, [fp, #0x10]
    // 0xa05c6c: ldr             x1, [fp, #0x18]
    // 0xa05c70: StoreField: r1->field_7 = r0
    //     0xa05c70: stur            w0, [x1, #7]
    //     0xa05c74: ldurb           w16, [x1, #-1]
    //     0xa05c78: ldurb           w17, [x0, #-1]
    //     0xa05c7c: and             x16, x17, x16, lsr #2
    //     0xa05c80: tst             x16, HEAP, lsr #32
    //     0xa05c84: b.eq            #0xa05c8c
    //     0xa05c88: bl              #0xd6826c
    // 0xa05c8c: ldr             x1, [fp, #0x10]
    // 0xa05c90: LoadField: r0 = r1->field_7
    //     0xa05c90: ldur            w0, [x1, #7]
    // 0xa05c94: DecompressPointer r0
    //     0xa05c94: add             x0, x0, HEAP, lsl #32
    // 0xa05c98: r2 = LoadInt32Instr(r0)
    //     0xa05c98: sbfx            x2, x0, #1, #0x1f
    // 0xa05c9c: cmp             x2, #0xff
    // 0xa05ca0: b.gt            #0xa05e64
    // 0xa05ca4: r0 = LoadClassIdInstr(r1)
    //     0xa05ca4: ldur            x0, [x1, #-1]
    //     0xa05ca8: ubfx            x0, x0, #0xc, #0x14
    // 0xa05cac: r16 = "."
    //     0xa05cac: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xa05cb0: stp             x16, x1, [SP, #-0x10]!
    // 0xa05cb4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa05cb4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa05cb8: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa05cb8: sub             lr, x0, #0xffc
    //     0xa05cbc: ldr             lr, [x21, lr, lsl #3]
    //     0xa05cc0: blr             lr
    // 0xa05cc4: add             SP, SP, #0x10
    // 0xa05cc8: tbnz            w0, #4, #0xa05e80
    // 0xa05ccc: ldr             x0, [fp, #0x10]
    // 0xa05cd0: r1 = LoadClassIdInstr(r0)
    //     0xa05cd0: ldur            x1, [x0, #-1]
    //     0xa05cd4: ubfx            x1, x1, #0xc, #0x14
    // 0xa05cd8: r16 = "."
    //     0xa05cd8: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xa05cdc: stp             x16, x0, [SP, #-0x10]!
    // 0xa05ce0: mov             x0, x1
    // 0xa05ce4: r0 = GDT[cid_x0 + -0xff8]()
    //     0xa05ce4: sub             lr, x0, #0xff8
    //     0xa05ce8: ldr             lr, [x21, lr, lsl #3]
    //     0xa05cec: blr             lr
    // 0xa05cf0: add             SP, SP, #0x10
    // 0xa05cf4: mov             x1, x0
    // 0xa05cf8: stur            x1, [fp, #-0x20]
    // 0xa05cfc: LoadField: r2 = r1->field_7
    //     0xa05cfc: ldur            w2, [x1, #7]
    // 0xa05d00: DecompressPointer r2
    //     0xa05d00: add             x2, x2, HEAP, lsl #32
    // 0xa05d04: stur            x2, [fp, #-0x18]
    // 0xa05d08: LoadField: r0 = r1->field_b
    //     0xa05d08: ldur            w0, [x1, #0xb]
    // 0xa05d0c: DecompressPointer r0
    //     0xa05d0c: add             x0, x0, HEAP, lsl #32
    // 0xa05d10: r3 = LoadInt32Instr(r0)
    //     0xa05d10: sbfx            x3, x0, #1, #0x1f
    // 0xa05d14: stur            x3, [fp, #-0x10]
    // 0xa05d18: r4 = 0
    //     0xa05d18: mov             x4, #0
    // 0xa05d1c: stur            x4, [fp, #-8]
    // 0xa05d20: CheckStackOverflow
    //     0xa05d20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa05d24: cmp             SP, x16
    //     0xa05d28: b.ls            #0xa05ed8
    // 0xa05d2c: r0 = LoadClassIdInstr(r1)
    //     0xa05d2c: ldur            x0, [x1, #-1]
    //     0xa05d30: ubfx            x0, x0, #0xc, #0x14
    // 0xa05d34: SaveReg r1
    //     0xa05d34: str             x1, [SP, #-8]!
    // 0xa05d38: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa05d38: mov             x17, #0xb8ea
    //     0xa05d3c: add             lr, x0, x17
    //     0xa05d40: ldr             lr, [x21, lr, lsl #3]
    //     0xa05d44: blr             lr
    // 0xa05d48: add             SP, SP, #8
    // 0xa05d4c: r1 = LoadInt32Instr(r0)
    //     0xa05d4c: sbfx            x1, x0, #1, #0x1f
    //     0xa05d50: tbz             w0, #0, #0xa05d58
    //     0xa05d54: ldur            x1, [x0, #7]
    // 0xa05d58: ldur            x2, [fp, #-0x10]
    // 0xa05d5c: cmp             x2, x1
    // 0xa05d60: b.ne            #0xa05e9c
    // 0xa05d64: ldur            x3, [fp, #-0x20]
    // 0xa05d68: ldur            x4, [fp, #-8]
    // 0xa05d6c: cmp             x4, x1
    // 0xa05d70: b.lt            #0xa05d84
    // 0xa05d74: r0 = Null
    //     0xa05d74: mov             x0, NULL
    // 0xa05d78: LeaveFrame
    //     0xa05d78: mov             SP, fp
    //     0xa05d7c: ldp             fp, lr, [SP], #0x10
    // 0xa05d80: ret
    //     0xa05d80: ret             
    // 0xa05d84: r0 = BoxInt64Instr(r4)
    //     0xa05d84: sbfiz           x0, x4, #1, #0x1f
    //     0xa05d88: cmp             x4, x0, asr #1
    //     0xa05d8c: b.eq            #0xa05d98
    //     0xa05d90: bl              #0xd69bb8
    //     0xa05d94: stur            x4, [x0, #7]
    // 0xa05d98: r1 = LoadClassIdInstr(r3)
    //     0xa05d98: ldur            x1, [x3, #-1]
    //     0xa05d9c: ubfx            x1, x1, #0xc, #0x14
    // 0xa05da0: stp             x0, x3, [SP, #-0x10]!
    // 0xa05da4: mov             x0, x1
    // 0xa05da8: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa05da8: mov             x17, #0xd175
    //     0xa05dac: add             lr, x0, x17
    //     0xa05db0: ldr             lr, [x21, lr, lsl #3]
    //     0xa05db4: blr             lr
    // 0xa05db8: add             SP, SP, #0x10
    // 0xa05dbc: mov             x3, x0
    // 0xa05dc0: ldur            x0, [fp, #-8]
    // 0xa05dc4: stur            x3, [fp, #-0x30]
    // 0xa05dc8: add             x4, x0, #1
    // 0xa05dcc: stur            x4, [fp, #-0x28]
    // 0xa05dd0: cmp             w3, NULL
    // 0xa05dd4: b.ne            #0xa05e04
    // 0xa05dd8: mov             x0, x3
    // 0xa05ddc: ldur            x2, [fp, #-0x18]
    // 0xa05de0: r1 = Null
    //     0xa05de0: mov             x1, NULL
    // 0xa05de4: cmp             w2, NULL
    // 0xa05de8: b.eq            #0xa05e04
    // 0xa05dec: LoadField: r4 = r2->field_17
    //     0xa05dec: ldur            w4, [x2, #0x17]
    // 0xa05df0: DecompressPointer r4
    //     0xa05df0: add             x4, x4, HEAP, lsl #32
    // 0xa05df4: r8 = X0
    //     0xa05df4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa05df8: LoadField: r9 = r4->field_7
    //     0xa05df8: ldur            x9, [x4, #7]
    // 0xa05dfc: r3 = Null
    //     0xa05dfc: ldr             x3, [PP, #0x7cb0]  ; [pp+0x7cb0] Null
    // 0xa05e00: blr             x9
    // 0xa05e04: ldur            x0, [fp, #-0x30]
    // 0xa05e08: r16 = "^[a-zA-Z_][0-9a-zA-Z_]+$"
    //     0xa05e08: ldr             x16, [PP, #0x6d8]  ; [pp+0x6d8] "^[a-zA-Z_][0-9a-zA-Z_]+$"
    // 0xa05e0c: stp             x16, NULL, [SP, #-0x10]!
    // 0xa05e10: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa05e10: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa05e14: r0 = RegExp()
    //     0xa05e14: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0xa05e18: add             SP, SP, #0x10
    // 0xa05e1c: mov             x1, x0
    // 0xa05e20: ldur            x0, [fp, #-0x30]
    // 0xa05e24: r2 = LoadClassIdInstr(r0)
    //     0xa05e24: ldur            x2, [x0, #-1]
    //     0xa05e28: ubfx            x2, x2, #0xc, #0x14
    // 0xa05e2c: stp             x1, x0, [SP, #-0x10]!
    // 0xa05e30: mov             x0, x2
    // 0xa05e34: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa05e34: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa05e38: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa05e38: sub             lr, x0, #0xffc
    //     0xa05e3c: ldr             lr, [x21, lr, lsl #3]
    //     0xa05e40: blr             lr
    // 0xa05e44: add             SP, SP, #0x10
    // 0xa05e48: tbnz            w0, #4, #0xa05eb4
    // 0xa05e4c: r0 = "Invalid element in error name"
    //     0xa05e4c: ldr             x0, [PP, #0x7cc0]  ; [pp+0x7cc0] "Invalid element in error name"
    // 0xa05e50: ldur            x4, [fp, #-0x28]
    // 0xa05e54: ldur            x1, [fp, #-0x20]
    // 0xa05e58: ldur            x2, [fp, #-0x18]
    // 0xa05e5c: ldur            x3, [fp, #-0x10]
    // 0xa05e60: b               #0xa05d1c
    // 0xa05e64: r0 = FormatException()
    //     0xa05e64: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa05e68: mov             x1, x0
    // 0xa05e6c: r0 = "Error name too long"
    //     0xa05e6c: ldr             x0, [PP, #0x7cc8]  ; [pp+0x7cc8] "Error name too long"
    // 0xa05e70: StoreField: r1->field_7 = r0
    //     0xa05e70: stur            w0, [x1, #7]
    // 0xa05e74: mov             x0, x1
    // 0xa05e78: r0 = Throw()
    //     0xa05e78: bl              #0xd67e38  ; ThrowStub
    // 0xa05e7c: brk             #0
    // 0xa05e80: r0 = FormatException()
    //     0xa05e80: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa05e84: mov             x1, x0
    // 0xa05e88: r0 = "Error name needs at least two elements"
    //     0xa05e88: ldr             x0, [PP, #0x7cd0]  ; [pp+0x7cd0] "Error name needs at least two elements"
    // 0xa05e8c: StoreField: r1->field_7 = r0
    //     0xa05e8c: stur            w0, [x1, #7]
    // 0xa05e90: mov             x0, x1
    // 0xa05e94: r0 = Throw()
    //     0xa05e94: bl              #0xd67e38  ; ThrowStub
    // 0xa05e98: brk             #0
    // 0xa05e9c: ldur            x0, [fp, #-0x20]
    // 0xa05ea0: r0 = ConcurrentModificationError()
    //     0xa05ea0: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa05ea4: ldur            x3, [fp, #-0x20]
    // 0xa05ea8: StoreField: r0->field_b = r3
    //     0xa05ea8: stur            w3, [x0, #0xb]
    // 0xa05eac: r0 = Throw()
    //     0xa05eac: bl              #0xd67e38  ; ThrowStub
    // 0xa05eb0: brk             #0
    // 0xa05eb4: r0 = FormatException()
    //     0xa05eb4: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa05eb8: mov             x1, x0
    // 0xa05ebc: r0 = "Invalid element in error name"
    //     0xa05ebc: ldr             x0, [PP, #0x7cc0]  ; [pp+0x7cc0] "Invalid element in error name"
    // 0xa05ec0: StoreField: r1->field_7 = r0
    //     0xa05ec0: stur            w0, [x1, #7]
    // 0xa05ec4: mov             x0, x1
    // 0xa05ec8: r0 = Throw()
    //     0xa05ec8: bl              #0xd67e38  ; ThrowStub
    // 0xa05ecc: brk             #0
    // 0xa05ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa05ed0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa05ed4: b               #0xa05c68
    // 0xa05ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa05ed8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa05edc: b               #0xa05d2c
  }
  _ toString(/* No info */) {
    // ** addr: 0xacfb0c, size: 0x6c
    // 0xacfb0c: EnterFrame
    //     0xacfb0c: stp             fp, lr, [SP, #-0x10]!
    //     0xacfb10: mov             fp, SP
    // 0xacfb14: CheckStackOverflow
    //     0xacfb14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacfb18: cmp             SP, x16
    //     0xacfb1c: b.ls            #0xacfb70
    // 0xacfb20: r1 = Null
    //     0xacfb20: mov             x1, NULL
    // 0xacfb24: r2 = 8
    //     0xacfb24: mov             x2, #8
    // 0xacfb28: r0 = AllocateArray()
    //     0xacfb28: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacfb2c: r17 = DBusErrorName
    //     0xacfb2c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb248] Type: DBusErrorName
    //     0xacfb30: ldr             x17, [x17, #0x248]
    // 0xacfb34: StoreField: r0->field_f = r17
    //     0xacfb34: stur            w17, [x0, #0xf]
    // 0xacfb38: r17 = "(\'"
    //     0xacfb38: ldr             x17, [PP, #0x7168]  ; [pp+0x7168] "(\'"
    // 0xacfb3c: StoreField: r0->field_13 = r17
    //     0xacfb3c: stur            w17, [x0, #0x13]
    // 0xacfb40: ldr             x1, [fp, #0x10]
    // 0xacfb44: LoadField: r2 = r1->field_7
    //     0xacfb44: ldur            w2, [x1, #7]
    // 0xacfb48: DecompressPointer r2
    //     0xacfb48: add             x2, x2, HEAP, lsl #32
    // 0xacfb4c: StoreField: r0->field_17 = r2
    //     0xacfb4c: stur            w2, [x0, #0x17]
    // 0xacfb50: r17 = "\')"
    //     0xacfb50: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xacfb54: StoreField: r0->field_1b = r17
    //     0xacfb54: stur            w17, [x0, #0x1b]
    // 0xacfb58: SaveReg r0
    //     0xacfb58: str             x0, [SP, #-8]!
    // 0xacfb5c: r0 = _interpolate()
    //     0xacfb5c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacfb60: add             SP, SP, #8
    // 0xacfb64: LeaveFrame
    //     0xacfb64: mov             SP, fp
    //     0xacfb68: ldp             fp, lr, [SP], #0x10
    // 0xacfb6c: ret
    //     0xacfb6c: ret             
    // 0xacfb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacfb70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacfb74: b               #0xacfb20
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e208, size: 0xa0
    // 0xc6e208: EnterFrame
    //     0xc6e208: stp             fp, lr, [SP, #-0x10]!
    //     0xc6e20c: mov             fp, SP
    // 0xc6e210: CheckStackOverflow
    //     0xc6e210: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6e214: cmp             SP, x16
    //     0xc6e218: b.ls            #0xc6e2a0
    // 0xc6e21c: ldr             x0, [fp, #0x10]
    // 0xc6e220: cmp             w0, NULL
    // 0xc6e224: b.ne            #0xc6e238
    // 0xc6e228: r0 = false
    //     0xc6e228: add             x0, NULL, #0x30  ; false
    // 0xc6e22c: LeaveFrame
    //     0xc6e22c: mov             SP, fp
    //     0xc6e230: ldp             fp, lr, [SP], #0x10
    // 0xc6e234: ret
    //     0xc6e234: ret             
    // 0xc6e238: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6e238: mov             x1, #0x76
    //     0xc6e23c: tbz             w0, #0, #0xc6e24c
    //     0xc6e240: ldur            x1, [x0, #-1]
    //     0xc6e244: ubfx            x1, x1, #0xc, #0x14
    //     0xc6e248: lsl             x1, x1, #1
    // 0xc6e24c: r17 = 9244
    //     0xc6e24c: mov             x17, #0x241c
    // 0xc6e250: cmp             w1, w17
    // 0xc6e254: b.ne            #0xc6e290
    // 0xc6e258: ldr             x1, [fp, #0x18]
    // 0xc6e25c: LoadField: r2 = r0->field_7
    //     0xc6e25c: ldur            w2, [x0, #7]
    // 0xc6e260: DecompressPointer r2
    //     0xc6e260: add             x2, x2, HEAP, lsl #32
    // 0xc6e264: LoadField: r0 = r1->field_7
    //     0xc6e264: ldur            w0, [x1, #7]
    // 0xc6e268: DecompressPointer r0
    //     0xc6e268: add             x0, x0, HEAP, lsl #32
    // 0xc6e26c: r1 = LoadClassIdInstr(r2)
    //     0xc6e26c: ldur            x1, [x2, #-1]
    //     0xc6e270: ubfx            x1, x1, #0xc, #0x14
    // 0xc6e274: stp             x0, x2, [SP, #-0x10]!
    // 0xc6e278: mov             x0, x1
    // 0xc6e27c: mov             lr, x0
    // 0xc6e280: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e284: blr             lr
    // 0xc6e288: add             SP, SP, #0x10
    // 0xc6e28c: b               #0xc6e294
    // 0xc6e290: r0 = false
    //     0xc6e290: add             x0, NULL, #0x30  ; false
    // 0xc6e294: LeaveFrame
    //     0xc6e294: mov             SP, fp
    //     0xc6e298: ldp             fp, lr, [SP], #0x10
    // 0xc6e29c: ret
    //     0xc6e29c: ret             
    // 0xc6e2a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6e2a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6e2a4: b               #0xc6e21c
  }
}

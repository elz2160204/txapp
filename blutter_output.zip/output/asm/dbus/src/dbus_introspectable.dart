// lib: , url: package:dbus/src/dbus_introspectable.dart

// class id: 1048837, size: 0x8
class :: {

  static _ handleIntrospectableMethodCall(/* No info */) {
    // ** addr: 0xa05eec, size: 0x240
    // 0xa05eec: EnterFrame
    //     0xa05eec: stp             fp, lr, [SP, #-0x10]!
    //     0xa05ef0: mov             fp, SP
    // 0xa05ef4: AllocStack(0x18)
    //     0xa05ef4: sub             SP, SP, #0x18
    // 0xa05ef8: CheckStackOverflow
    //     0xa05ef8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa05efc: cmp             SP, x16
    //     0xa05f00: b.ls            #0xa06124
    // 0xa05f04: ldr             x1, [fp, #0x10]
    // 0xa05f08: LoadField: r0 = r1->field_f
    //     0xa05f08: ldur            w0, [x1, #0xf]
    // 0xa05f0c: DecompressPointer r0
    //     0xa05f0c: add             x0, x0, HEAP, lsl #32
    // 0xa05f10: r2 = LoadClassIdInstr(r0)
    //     0xa05f10: ldur            x2, [x0, #-1]
    //     0xa05f14: ubfx            x2, x2, #0xc, #0x14
    // 0xa05f18: r16 = "Introspect"
    //     0xa05f18: ldr             x16, [PP, #0x7cd8]  ; [pp+0x7cd8] "Introspect"
    // 0xa05f1c: stp             x16, x0, [SP, #-0x10]!
    // 0xa05f20: mov             x0, x2
    // 0xa05f24: mov             lr, x0
    // 0xa05f28: ldr             lr, [x21, lr, lsl #3]
    // 0xa05f2c: blr             lr
    // 0xa05f30: add             SP, SP, #0x10
    // 0xa05f34: tbnz            w0, #4, #0xa060f0
    // 0xa05f38: ldr             x16, [fp, #0x10]
    // 0xa05f3c: SaveReg r16
    //     0xa05f3c: str             x16, [SP, #-8]!
    // 0xa05f40: r0 = signature()
    //     0xa05f40: bl              #0xa0711c  ; [package:dbus/src/dbus_method_call.dart] DBusMethodCall::signature
    // 0xa05f44: add             SP, SP, #8
    // 0xa05f48: stur            x0, [fp, #-8]
    // 0xa05f4c: r0 = DBusSignature()
    //     0xa05f4c: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa05f50: stur            x0, [fp, #-0x10]
    // 0xa05f54: r16 = ""
    //     0xa05f54: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa05f58: stp             x16, x0, [SP, #-0x10]!
    // 0xa05f5c: r0 = DBusSignature()
    //     0xa05f5c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa05f60: add             SP, SP, #0x10
    // 0xa05f64: ldur            x16, [fp, #-8]
    // 0xa05f68: ldur            lr, [fp, #-0x10]
    // 0xa05f6c: stp             lr, x16, [SP, #-0x10]!
    // 0xa05f70: r0 = ==()
    //     0xa05f70: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0xa05f74: add             SP, SP, #0x10
    // 0xa05f78: tbz             w0, #4, #0xa05fb8
    // 0xa05f7c: r16 = <DBusValue>
    //     0xa05f7c: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa05f80: stp             xzr, x16, [SP, #-0x10]!
    // 0xa05f84: r0 = _GrowableList()
    //     0xa05f84: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa05f88: add             SP, SP, #0x10
    // 0xa05f8c: stur            x0, [fp, #-8]
    // 0xa05f90: r0 = DBusMethodErrorResponse()
    //     0xa05f90: bl              #0xa0565c  ; AllocateDBusMethodErrorResponseStub -> DBusMethodErrorResponse (size=0x10)
    // 0xa05f94: mov             x1, x0
    // 0xa05f98: r0 = "org.freedesktop.DBus.Error.InvalidArgs"
    //     0xa05f98: ldr             x0, [PP, #0x7798]  ; [pp+0x7798] "org.freedesktop.DBus.Error.InvalidArgs"
    // 0xa05f9c: StoreField: r1->field_7 = r0
    //     0xa05f9c: stur            w0, [x1, #7]
    // 0xa05fa0: ldur            x0, [fp, #-8]
    // 0xa05fa4: StoreField: r1->field_b = r0
    //     0xa05fa4: stur            w0, [x1, #0xb]
    // 0xa05fa8: mov             x0, x1
    // 0xa05fac: LeaveFrame
    //     0xa05fac: mov             SP, fp
    //     0xa05fb0: ldp             fp, lr, [SP], #0x10
    // 0xa05fb4: ret
    //     0xa05fb4: ret             
    // 0xa05fb8: ldr             x0, [fp, #0x18]
    // 0xa05fbc: r16 = <DBusIntrospectInterface>
    //     0xa05fbc: ldr             x16, [PP, #0x7ce0]  ; [pp+0x7ce0] TypeArguments: <DBusIntrospectInterface>
    // 0xa05fc0: stp             xzr, x16, [SP, #-0x10]!
    // 0xa05fc4: r0 = _GrowableList()
    //     0xa05fc4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa05fc8: add             SP, SP, #0x10
    // 0xa05fcc: stur            x0, [fp, #-8]
    // 0xa05fd0: r16 = <DBusIntrospectNode>
    //     0xa05fd0: ldr             x16, [PP, #0x7ce8]  ; [pp+0x7ce8] TypeArguments: <DBusIntrospectNode>
    // 0xa05fd4: stp             xzr, x16, [SP, #-0x10]!
    // 0xa05fd8: r0 = _GrowableList()
    //     0xa05fd8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa05fdc: add             SP, SP, #0x10
    // 0xa05fe0: mov             x1, x0
    // 0xa05fe4: ldr             x0, [fp, #0x18]
    // 0xa05fe8: stur            x1, [fp, #-0x10]
    // 0xa05fec: cmp             w0, NULL
    // 0xa05ff0: b.eq            #0xa06044
    // 0xa05ff4: LoadField: r2 = r0->field_b
    //     0xa05ff4: ldur            w2, [x0, #0xb]
    // 0xa05ff8: DecompressPointer r2
    //     0xa05ff8: add             x2, x2, HEAP, lsl #32
    // 0xa05ffc: SaveReg r2
    //     0xa05ffc: str             x2, [SP, #-8]!
    // 0xa06000: r0 = keys()
    //     0xa06000: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0xa06004: add             SP, SP, #8
    // 0xa06008: r1 = Function '<anonymous closure>': static.
    //     0xa06008: ldr             x1, [PP, #0x7cf0]  ; [pp+0x7cf0] AnonymousClosure: static (0xa071c8), in [package:dbus/src/dbus_introspectable.dart] ::handleIntrospectableMethodCall (0xa05eec)
    // 0xa0600c: r2 = Null
    //     0xa0600c: mov             x2, NULL
    // 0xa06010: stur            x0, [fp, #-0x18]
    // 0xa06014: r0 = AllocateClosure()
    //     0xa06014: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa06018: r16 = <DBusIntrospectNode>
    //     0xa06018: ldr             x16, [PP, #0x7ce8]  ; [pp+0x7ce8] TypeArguments: <DBusIntrospectNode>
    // 0xa0601c: ldur            lr, [fp, #-0x18]
    // 0xa06020: stp             lr, x16, [SP, #-0x10]!
    // 0xa06024: SaveReg r0
    //     0xa06024: str             x0, [SP, #-8]!
    // 0xa06028: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa06028: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0602c: r0 = map()
    //     0xa0602c: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0xa06030: add             SP, SP, #0x18
    // 0xa06034: ldur            x16, [fp, #-0x10]
    // 0xa06038: stp             x0, x16, [SP, #-0x10]!
    // 0xa0603c: r0 = addAll()
    //     0xa0603c: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa06040: add             SP, SP, #0x10
    // 0xa06044: ldur            x1, [fp, #-8]
    // 0xa06048: ldur            x0, [fp, #-0x10]
    // 0xa0604c: r0 = DBusIntrospectNode()
    //     0xa0604c: bl              #0xa07110  ; AllocateDBusIntrospectNodeStub -> DBusIntrospectNode (size=0x14)
    // 0xa06050: mov             x1, x0
    // 0xa06054: ldur            x0, [fp, #-8]
    // 0xa06058: StoreField: r1->field_b = r0
    //     0xa06058: stur            w0, [x1, #0xb]
    // 0xa0605c: ldur            x0, [fp, #-0x10]
    // 0xa06060: StoreField: r1->field_f = r0
    //     0xa06060: stur            w0, [x1, #0xf]
    // 0xa06064: SaveReg r1
    //     0xa06064: str             x1, [SP, #-8]!
    // 0xa06068: r0 = toXml()
    //     0xa06068: bl              #0xa06234  ; [package:dbus/src/dbus_introspect.dart] DBusIntrospectNode::toXml
    // 0xa0606c: add             SP, SP, #8
    // 0xa06070: SaveReg r0
    //     0xa06070: str             x0, [SP, #-8]!
    // 0xa06074: r0 = toXmlString()
    //     0xa06074: bl              #0xa0612c  ; [package:xml/src/xml/nodes/node.dart] _XmlNode&Object&XmlAttributesBase&XmlChildrenBase&XmlHasText&XmlHasVisitor&XmlHasWriter::toXmlString
    // 0xa06078: add             SP, SP, #8
    // 0xa0607c: stur            x0, [fp, #-8]
    // 0xa06080: r0 = DBusString()
    //     0xa06080: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0xa06084: mov             x3, x0
    // 0xa06088: ldur            x0, [fp, #-8]
    // 0xa0608c: stur            x3, [fp, #-0x10]
    // 0xa06090: StoreField: r3->field_7 = r0
    //     0xa06090: stur            w0, [x3, #7]
    // 0xa06094: r1 = Null
    //     0xa06094: mov             x1, NULL
    // 0xa06098: r2 = 2
    //     0xa06098: mov             x2, #2
    // 0xa0609c: r0 = AllocateArray()
    //     0xa0609c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa060a0: mov             x2, x0
    // 0xa060a4: ldur            x0, [fp, #-0x10]
    // 0xa060a8: stur            x2, [fp, #-8]
    // 0xa060ac: StoreField: r2->field_f = r0
    //     0xa060ac: stur            w0, [x2, #0xf]
    // 0xa060b0: r1 = <DBusValue>
    //     0xa060b0: ldr             x1, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa060b4: r0 = AllocateGrowableArray()
    //     0xa060b4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa060b8: mov             x1, x0
    // 0xa060bc: ldur            x0, [fp, #-8]
    // 0xa060c0: stur            x1, [fp, #-0x10]
    // 0xa060c4: StoreField: r1->field_f = r0
    //     0xa060c4: stur            w0, [x1, #0xf]
    // 0xa060c8: r0 = 2
    //     0xa060c8: mov             x0, #2
    // 0xa060cc: StoreField: r1->field_b = r0
    //     0xa060cc: stur            w0, [x1, #0xb]
    // 0xa060d0: r0 = DBusMethodSuccessResponse()
    //     0xa060d0: bl              #0xa05650  ; AllocateDBusMethodSuccessResponseStub -> DBusMethodSuccessResponse (size=0xc)
    // 0xa060d4: mov             x1, x0
    // 0xa060d8: ldur            x0, [fp, #-0x10]
    // 0xa060dc: StoreField: r1->field_7 = r0
    //     0xa060dc: stur            w0, [x1, #7]
    // 0xa060e0: mov             x0, x1
    // 0xa060e4: LeaveFrame
    //     0xa060e4: mov             SP, fp
    //     0xa060e8: ldp             fp, lr, [SP], #0x10
    // 0xa060ec: ret
    //     0xa060ec: ret             
    // 0xa060f0: r16 = <DBusValue>
    //     0xa060f0: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa060f4: stp             xzr, x16, [SP, #-0x10]!
    // 0xa060f8: r0 = _GrowableList()
    //     0xa060f8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa060fc: add             SP, SP, #0x10
    // 0xa06100: stur            x0, [fp, #-8]
    // 0xa06104: r0 = DBusMethodErrorResponse()
    //     0xa06104: bl              #0xa0565c  ; AllocateDBusMethodErrorResponseStub -> DBusMethodErrorResponse (size=0x10)
    // 0xa06108: r1 = "org.freedesktop.DBus.Error.UnknownMethod"
    //     0xa06108: ldr             x1, [PP, #0x7780]  ; [pp+0x7780] "org.freedesktop.DBus.Error.UnknownMethod"
    // 0xa0610c: StoreField: r0->field_7 = r1
    //     0xa0610c: stur            w1, [x0, #7]
    // 0xa06110: ldur            x1, [fp, #-8]
    // 0xa06114: StoreField: r0->field_b = r1
    //     0xa06114: stur            w1, [x0, #0xb]
    // 0xa06118: LeaveFrame
    //     0xa06118: mov             SP, fp
    //     0xa0611c: ldp             fp, lr, [SP], #0x10
    // 0xa06120: ret
    //     0xa06120: ret             
    // 0xa06124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa06124: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa06128: b               #0xa05f04
  }
  [closure] static DBusIntrospectNode <anonymous closure>(dynamic, String) {
    // ** addr: 0xa071c8, size: 0x30
    // 0xa071c8: EnterFrame
    //     0xa071c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa071cc: mov             fp, SP
    // 0xa071d0: r0 = DBusIntrospectNode()
    //     0xa071d0: bl              #0xa07110  ; AllocateDBusIntrospectNodeStub -> DBusIntrospectNode (size=0x14)
    // 0xa071d4: ldr             x1, [fp, #0x10]
    // 0xa071d8: StoreField: r0->field_7 = r1
    //     0xa071d8: stur            w1, [x0, #7]
    // 0xa071dc: r1 = const []
    //     0xa071dc: ldr             x1, [PP, #0x7cf8]  ; [pp+0x7cf8] List<DBusIntrospectInterface>(0)
    // 0xa071e0: StoreField: r0->field_b = r1
    //     0xa071e0: stur            w1, [x0, #0xb]
    // 0xa071e4: r1 = const []
    //     0xa071e4: ldr             x1, [PP, #0x7d00]  ; [pp+0x7d00] List<DBusIntrospectNode>(0)
    // 0xa071e8: StoreField: r0->field_f = r1
    //     0xa071e8: stur            w1, [x0, #0xf]
    // 0xa071ec: LeaveFrame
    //     0xa071ec: mov             SP, fp
    //     0xa071f0: ldp             fp, lr, [SP], #0x10
    // 0xa071f4: ret
    //     0xa071f4: ret             
  }
}

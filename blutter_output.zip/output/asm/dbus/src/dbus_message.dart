// lib: , url: package:dbus/src/dbus_message.dart

// class id: 1048840, size: 0x8
class :: {
}

// class id: 4611, size: 0x38, field offset: 0x8
class DBusMessage extends Object {

  [closure] String <anonymous closure>(dynamic, DBusValue) {
    // ** addr: 0xa05480, size: 0x58
    // 0xa05480: EnterFrame
    //     0xa05480: stp             fp, lr, [SP, #-0x10]!
    //     0xa05484: mov             fp, SP
    // 0xa05488: CheckStackOverflow
    //     0xa05488: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0548c: cmp             SP, x16
    //     0xa05490: b.ls            #0xa054d0
    // 0xa05494: ldr             x0, [fp, #0x10]
    // 0xa05498: r1 = LoadClassIdInstr(r0)
    //     0xa05498: ldur            x1, [x0, #-1]
    //     0xa0549c: ubfx            x1, x1, #0xc, #0x14
    // 0xa054a0: SaveReg r0
    //     0xa054a0: str             x0, [SP, #-8]!
    // 0xa054a4: mov             x0, x1
    // 0xa054a8: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa054a8: add             lr, x0, #0x2b8
    //     0xa054ac: ldr             lr, [x21, lr, lsl #3]
    //     0xa054b0: blr             lr
    // 0xa054b4: add             SP, SP, #8
    // 0xa054b8: LoadField: r1 = r0->field_7
    //     0xa054b8: ldur            w1, [x0, #7]
    // 0xa054bc: DecompressPointer r1
    //     0xa054bc: add             x1, x1, HEAP, lsl #32
    // 0xa054c0: mov             x0, x1
    // 0xa054c4: LeaveFrame
    //     0xa054c4: mov             SP, fp
    //     0xa054c8: ldp             fp, lr, [SP], #0x10
    // 0xa054cc: ret
    //     0xa054cc: ret             
    // 0xa054d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa054d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa054d4: b               #0xa05494
  }
  [closure] String <anonymous closure>(dynamic, String) {
    // ** addr: 0xacfe94, size: 0xd8
    // 0xacfe94: EnterFrame
    //     0xacfe94: stp             fp, lr, [SP, #-0x10]!
    //     0xacfe98: mov             fp, SP
    // 0xacfe9c: AllocStack(0x18)
    //     0xacfe9c: sub             SP, SP, #0x18
    // 0xacfea0: SetupParameters()
    //     0xacfea0: ldr             x0, [fp, #0x18]
    //     0xacfea4: ldur            w3, [x0, #0x17]
    //     0xacfea8: add             x3, x3, HEAP, lsl #32
    //     0xacfeac: stur            x3, [fp, #-8]
    // 0xacfeb0: CheckStackOverflow
    //     0xacfeb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacfeb4: cmp             SP, x16
    //     0xacfeb8: b.ls            #0xacff64
    // 0xacfebc: r1 = Null
    //     0xacfebc: mov             x1, NULL
    // 0xacfec0: r2 = 6
    //     0xacfec0: mov             x2, #6
    // 0xacfec4: r0 = AllocateArray()
    //     0xacfec4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacfec8: mov             x1, x0
    // 0xacfecc: ldr             x0, [fp, #0x10]
    // 0xacfed0: stur            x1, [fp, #-0x18]
    // 0xacfed4: StoreField: r1->field_f = r0
    //     0xacfed4: stur            w0, [x1, #0xf]
    // 0xacfed8: r17 = ": "
    //     0xacfed8: ldr             x17, [PP, #0xf48]  ; [pp+0xf48] ": "
    // 0xacfedc: StoreField: r1->field_13 = r17
    //     0xacfedc: stur            w17, [x1, #0x13]
    // 0xacfee0: ldur            x2, [fp, #-8]
    // 0xacfee4: LoadField: r3 = r2->field_f
    //     0xacfee4: ldur            w3, [x2, #0xf]
    // 0xacfee8: DecompressPointer r3
    //     0xacfee8: add             x3, x3, HEAP, lsl #32
    // 0xacfeec: stur            x3, [fp, #-0x10]
    // 0xacfef0: stp             x0, x3, [SP, #-0x10]!
    // 0xacfef4: r0 = _getValueOrData()
    //     0xacfef4: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xacfef8: add             SP, SP, #0x10
    // 0xacfefc: mov             x1, x0
    // 0xacff00: ldur            x0, [fp, #-0x10]
    // 0xacff04: LoadField: r2 = r0->field_f
    //     0xacff04: ldur            w2, [x0, #0xf]
    // 0xacff08: DecompressPointer r2
    //     0xacff08: add             x2, x2, HEAP, lsl #32
    // 0xacff0c: cmp             w2, w1
    // 0xacff10: b.ne            #0xacff1c
    // 0xacff14: r0 = Null
    //     0xacff14: mov             x0, NULL
    // 0xacff18: b               #0xacff20
    // 0xacff1c: mov             x0, x1
    // 0xacff20: ldur            x1, [fp, #-0x18]
    // 0xacff24: ArrayStore: r1[2] = r0  ; List_4
    //     0xacff24: add             x25, x1, #0x17
    //     0xacff28: str             w0, [x25]
    //     0xacff2c: tbz             w0, #0, #0xacff48
    //     0xacff30: ldurb           w16, [x1, #-1]
    //     0xacff34: ldurb           w17, [x0, #-1]
    //     0xacff38: and             x16, x17, x16, lsr #2
    //     0xacff3c: tst             x16, HEAP, lsr #32
    //     0xacff40: b.eq            #0xacff48
    //     0xacff44: bl              #0xd67e5c
    // 0xacff48: ldur            x16, [fp, #-0x18]
    // 0xacff4c: SaveReg r16
    //     0xacff4c: str             x16, [SP, #-8]!
    // 0xacff50: r0 = _interpolate()
    //     0xacff50: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacff54: add             SP, SP, #8
    // 0xacff58: LeaveFrame
    //     0xacff58: mov             SP, fp
    //     0xacff5c: ldp             fp, lr, [SP], #0x10
    // 0xacff60: ret
    //     0xacff60: ret             
    // 0xacff64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacff64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacff68: b               #0xacfebc
  }
  _ toString(/* No info */) {
    // ** addr: 0xad0424, size: 0x5e0
    // 0xad0424: EnterFrame
    //     0xad0424: stp             fp, lr, [SP, #-0x10]!
    //     0xad0428: mov             fp, SP
    // 0xad042c: AllocStack(0x10)
    //     0xad042c: sub             SP, SP, #0x10
    // 0xad0430: CheckStackOverflow
    //     0xad0430: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad0434: cmp             SP, x16
    //     0xad0438: b.ls            #0xad09fc
    // 0xad043c: r1 = Null
    //     0xad043c: mov             x1, NULL
    // 0xad0440: r2 = 44
    //     0xad0440: mov             x2, #0x2c
    // 0xad0444: r0 = AllocateArray()
    //     0xad0444: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad0448: stur            x0, [fp, #-8]
    // 0xad044c: r17 = "type"
    //     0xad044c: ldr             x17, [PP, #0x1db8]  ; [pp+0x1db8] "type"
    // 0xad0450: StoreField: r0->field_f = r17
    //     0xad0450: stur            w17, [x0, #0xf]
    // 0xad0454: ldr             x1, [fp, #0x10]
    // 0xad0458: LoadField: r2 = r1->field_7
    //     0xad0458: ldur            w2, [x1, #7]
    // 0xad045c: DecompressPointer r2
    //     0xad045c: add             x2, x2, HEAP, lsl #32
    // 0xad0460: SaveReg r2
    //     0xad0460: str             x2, [SP, #-8]!
    // 0xad0464: r0 = _enumToString()
    //     0xad0464: bl              #0xb153ec  ; [package:dbus/src/dbus_message.dart] DBusMessageType::_enumToString
    // 0xad0468: add             SP, SP, #8
    // 0xad046c: ldur            x1, [fp, #-8]
    // 0xad0470: ArrayStore: r1[1] = r0  ; List_4
    //     0xad0470: add             x25, x1, #0x13
    //     0xad0474: str             w0, [x25]
    //     0xad0478: tbz             w0, #0, #0xad0494
    //     0xad047c: ldurb           w16, [x1, #-1]
    //     0xad0480: ldurb           w17, [x0, #-1]
    //     0xad0484: and             x16, x17, x16, lsr #2
    //     0xad0488: tst             x16, HEAP, lsr #32
    //     0xad048c: b.eq            #0xad0494
    //     0xad0490: bl              #0xd67e5c
    // 0xad0494: ldur            x1, [fp, #-8]
    // 0xad0498: r17 = "flags"
    //     0xad0498: ldr             x17, [PP, #0x5640]  ; [pp+0x5640] "flags"
    // 0xad049c: StoreField: r1->field_17 = r17
    //     0xad049c: stur            w17, [x1, #0x17]
    // 0xad04a0: ldr             x2, [fp, #0x10]
    // 0xad04a4: LoadField: r3 = r2->field_b
    //     0xad04a4: ldur            w3, [x2, #0xb]
    // 0xad04a8: DecompressPointer r3
    //     0xad04a8: add             x3, x3, HEAP, lsl #32
    // 0xad04ac: stur            x3, [fp, #-0x10]
    // 0xad04b0: r0 = LoadClassIdInstr(r3)
    //     0xad04b0: ldur            x0, [x3, #-1]
    //     0xad04b4: ubfx            x0, x0, #0xc, #0x14
    // 0xad04b8: SaveReg r3
    //     0xad04b8: str             x3, [SP, #-8]!
    // 0xad04bc: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0xad04bc: mov             x17, #0xcc6c
    //     0xad04c0: add             lr, x0, x17
    //     0xad04c4: ldr             lr, [x21, lr, lsl #3]
    //     0xad04c8: blr             lr
    // 0xad04cc: add             SP, SP, #8
    // 0xad04d0: tbnz            w0, #4, #0xad0504
    // 0xad04d4: ldur            x0, [fp, #-0x10]
    // 0xad04d8: r1 = LoadClassIdInstr(r0)
    //     0xad04d8: ldur            x1, [x0, #-1]
    //     0xad04dc: ubfx            x1, x1, #0xc, #0x14
    // 0xad04e0: SaveReg r0
    //     0xad04e0: str             x0, [SP, #-8]!
    // 0xad04e4: mov             x0, x1
    // 0xad04e8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad04e8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad04ec: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad04ec: mov             x17, #0x3f73
    //     0xad04f0: add             lr, x0, x17
    //     0xad04f4: ldr             lr, [x21, lr, lsl #3]
    //     0xad04f8: blr             lr
    // 0xad04fc: add             SP, SP, #8
    // 0xad0500: b               #0xad0508
    // 0xad0504: r0 = Null
    //     0xad0504: mov             x0, NULL
    // 0xad0508: ldr             x3, [fp, #0x10]
    // 0xad050c: ldur            x2, [fp, #-8]
    // 0xad0510: mov             x1, x2
    // 0xad0514: ArrayStore: r1[3] = r0  ; List_4
    //     0xad0514: add             x25, x1, #0x1b
    //     0xad0518: str             w0, [x25]
    //     0xad051c: tbz             w0, #0, #0xad0538
    //     0xad0520: ldurb           w16, [x1, #-1]
    //     0xad0524: ldurb           w17, [x0, #-1]
    //     0xad0528: and             x16, x17, x16, lsr #2
    //     0xad052c: tst             x16, HEAP, lsr #32
    //     0xad0530: b.eq            #0xad0538
    //     0xad0534: bl              #0xd67e5c
    // 0xad0538: r17 = "serial"
    //     0xad0538: add             x17, PP, #0xb, lsl #12  ; [pp+0xb210] "serial"
    //     0xad053c: ldr             x17, [x17, #0x210]
    // 0xad0540: StoreField: r2->field_1f = r17
    //     0xad0540: stur            w17, [x2, #0x1f]
    // 0xad0544: LoadField: r4 = r3->field_f
    //     0xad0544: ldur            x4, [x3, #0xf]
    // 0xad0548: r0 = BoxInt64Instr(r4)
    //     0xad0548: sbfiz           x0, x4, #1, #0x1f
    //     0xad054c: cmp             x4, x0, asr #1
    //     0xad0550: b.eq            #0xad055c
    //     0xad0554: bl              #0xd69bb8
    //     0xad0558: stur            x4, [x0, #7]
    // 0xad055c: r1 = 59
    //     0xad055c: mov             x1, #0x3b
    // 0xad0560: branchIfSmi(r0, 0xad056c)
    //     0xad0560: tbz             w0, #0, #0xad056c
    // 0xad0564: r1 = LoadClassIdInstr(r0)
    //     0xad0564: ldur            x1, [x0, #-1]
    //     0xad0568: ubfx            x1, x1, #0xc, #0x14
    // 0xad056c: SaveReg r0
    //     0xad056c: str             x0, [SP, #-8]!
    // 0xad0570: mov             x0, x1
    // 0xad0574: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad0574: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad0578: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad0578: mov             x17, #0x3f73
    //     0xad057c: add             lr, x0, x17
    //     0xad0580: ldr             lr, [x21, lr, lsl #3]
    //     0xad0584: blr             lr
    // 0xad0588: add             SP, SP, #8
    // 0xad058c: ldur            x1, [fp, #-8]
    // 0xad0590: ArrayStore: r1[5] = r0  ; List_4
    //     0xad0590: add             x25, x1, #0x23
    //     0xad0594: str             w0, [x25]
    //     0xad0598: tbz             w0, #0, #0xad05b4
    //     0xad059c: ldurb           w16, [x1, #-1]
    //     0xad05a0: ldurb           w17, [x0, #-1]
    //     0xad05a4: and             x16, x17, x16, lsr #2
    //     0xad05a8: tst             x16, HEAP, lsr #32
    //     0xad05ac: b.eq            #0xad05b4
    //     0xad05b0: bl              #0xd67e5c
    // 0xad05b4: ldur            x1, [fp, #-8]
    // 0xad05b8: r17 = "path"
    //     0xad05b8: ldr             x17, [PP, #0x518]  ; [pp+0x518] "path"
    // 0xad05bc: StoreField: r1->field_27 = r17
    //     0xad05bc: stur            w17, [x1, #0x27]
    // 0xad05c0: ldr             x0, [fp, #0x10]
    // 0xad05c4: LoadField: r2 = r0->field_17
    //     0xad05c4: ldur            w2, [x0, #0x17]
    // 0xad05c8: DecompressPointer r2
    //     0xad05c8: add             x2, x2, HEAP, lsl #32
    // 0xad05cc: cmp             w2, NULL
    // 0xad05d0: b.ne            #0xad05e4
    // 0xad05d4: mov             x3, x0
    // 0xad05d8: mov             x2, x1
    // 0xad05dc: r0 = Null
    //     0xad05dc: mov             x0, NULL
    // 0xad05e0: b               #0xad05f8
    // 0xad05e4: SaveReg r2
    //     0xad05e4: str             x2, [SP, #-8]!
    // 0xad05e8: r0 = toString()
    //     0xad05e8: bl              #0xad1718  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::toString
    // 0xad05ec: add             SP, SP, #8
    // 0xad05f0: ldr             x3, [fp, #0x10]
    // 0xad05f4: ldur            x2, [fp, #-8]
    // 0xad05f8: mov             x1, x2
    // 0xad05fc: ArrayStore: r1[7] = r0  ; List_4
    //     0xad05fc: add             x25, x1, #0x2b
    //     0xad0600: str             w0, [x25]
    //     0xad0604: tbz             w0, #0, #0xad0620
    //     0xad0608: ldurb           w16, [x1, #-1]
    //     0xad060c: ldurb           w17, [x0, #-1]
    //     0xad0610: and             x16, x17, x16, lsr #2
    //     0xad0614: tst             x16, HEAP, lsr #32
    //     0xad0618: b.eq            #0xad0620
    //     0xad061c: bl              #0xd67e5c
    // 0xad0620: r17 = "interface"
    //     0xad0620: ldr             x17, [PP, #0x508]  ; [pp+0x508] "interface"
    // 0xad0624: StoreField: r2->field_2f = r17
    //     0xad0624: stur            w17, [x2, #0x2f]
    // 0xad0628: LoadField: r0 = r3->field_1b
    //     0xad0628: ldur            w0, [x3, #0x1b]
    // 0xad062c: DecompressPointer r0
    //     0xad062c: add             x0, x0, HEAP, lsl #32
    // 0xad0630: cmp             w0, NULL
    // 0xad0634: b.ne            #0xad0640
    // 0xad0638: r0 = Null
    //     0xad0638: mov             x0, NULL
    // 0xad063c: b               #0xad0654
    // 0xad0640: SaveReg r0
    //     0xad0640: str             x0, [SP, #-8]!
    // 0xad0644: r0 = toString()
    //     0xad0644: bl              #0xacfb78  ; [package:dbus/src/dbus_interface_name.dart] DBusInterfaceName::toString
    // 0xad0648: add             SP, SP, #8
    // 0xad064c: ldr             x3, [fp, #0x10]
    // 0xad0650: ldur            x2, [fp, #-8]
    // 0xad0654: mov             x1, x2
    // 0xad0658: ArrayStore: r1[9] = r0  ; List_4
    //     0xad0658: add             x25, x1, #0x33
    //     0xad065c: str             w0, [x25]
    //     0xad0660: tbz             w0, #0, #0xad067c
    //     0xad0664: ldurb           w16, [x1, #-1]
    //     0xad0668: ldurb           w17, [x0, #-1]
    //     0xad066c: and             x16, x17, x16, lsr #2
    //     0xad0670: tst             x16, HEAP, lsr #32
    //     0xad0674: b.eq            #0xad067c
    //     0xad0678: bl              #0xd67e5c
    // 0xad067c: r17 = "member"
    //     0xad067c: ldr             x17, [PP, #0x7648]  ; [pp+0x7648] "member"
    // 0xad0680: StoreField: r2->field_37 = r17
    //     0xad0680: stur            w17, [x2, #0x37]
    // 0xad0684: LoadField: r0 = r3->field_1f
    //     0xad0684: ldur            w0, [x3, #0x1f]
    // 0xad0688: DecompressPointer r0
    //     0xad0688: add             x0, x0, HEAP, lsl #32
    // 0xad068c: cmp             w0, NULL
    // 0xad0690: b.ne            #0xad069c
    // 0xad0694: r0 = Null
    //     0xad0694: mov             x0, NULL
    // 0xad0698: b               #0xad06b0
    // 0xad069c: SaveReg r0
    //     0xad069c: str             x0, [SP, #-8]!
    // 0xad06a0: r0 = toString()
    //     0xad06a0: bl              #0xad03bc  ; [package:dbus/src/dbus_member_name.dart] DBusMemberName::toString
    // 0xad06a4: add             SP, SP, #8
    // 0xad06a8: ldr             x3, [fp, #0x10]
    // 0xad06ac: ldur            x2, [fp, #-8]
    // 0xad06b0: mov             x1, x2
    // 0xad06b4: ArrayStore: r1[11] = r0  ; List_4
    //     0xad06b4: add             x25, x1, #0x3b
    //     0xad06b8: str             w0, [x25]
    //     0xad06bc: tbz             w0, #0, #0xad06d8
    //     0xad06c0: ldurb           w16, [x1, #-1]
    //     0xad06c4: ldurb           w17, [x0, #-1]
    //     0xad06c8: and             x16, x17, x16, lsr #2
    //     0xad06cc: tst             x16, HEAP, lsr #32
    //     0xad06d0: b.eq            #0xad06d8
    //     0xad06d4: bl              #0xd67e5c
    // 0xad06d8: r17 = "errorName"
    //     0xad06d8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb218] "errorName"
    //     0xad06dc: ldr             x17, [x17, #0x218]
    // 0xad06e0: StoreField: r2->field_3f = r17
    //     0xad06e0: stur            w17, [x2, #0x3f]
    // 0xad06e4: LoadField: r0 = r3->field_23
    //     0xad06e4: ldur            w0, [x3, #0x23]
    // 0xad06e8: DecompressPointer r0
    //     0xad06e8: add             x0, x0, HEAP, lsl #32
    // 0xad06ec: cmp             w0, NULL
    // 0xad06f0: b.ne            #0xad06fc
    // 0xad06f4: r0 = Null
    //     0xad06f4: mov             x0, NULL
    // 0xad06f8: b               #0xad0710
    // 0xad06fc: SaveReg r0
    //     0xad06fc: str             x0, [SP, #-8]!
    // 0xad0700: r0 = toString()
    //     0xad0700: bl              #0xacfb0c  ; [package:dbus/src/dbus_error_name.dart] DBusErrorName::toString
    // 0xad0704: add             SP, SP, #8
    // 0xad0708: ldr             x3, [fp, #0x10]
    // 0xad070c: ldur            x2, [fp, #-8]
    // 0xad0710: mov             x1, x2
    // 0xad0714: ArrayStore: r1[13] = r0  ; List_4
    //     0xad0714: add             x25, x1, #0x43
    //     0xad0718: str             w0, [x25]
    //     0xad071c: tbz             w0, #0, #0xad0738
    //     0xad0720: ldurb           w16, [x1, #-1]
    //     0xad0724: ldurb           w17, [x0, #-1]
    //     0xad0728: and             x16, x17, x16, lsr #2
    //     0xad072c: tst             x16, HEAP, lsr #32
    //     0xad0730: b.eq            #0xad0738
    //     0xad0734: bl              #0xd67e5c
    // 0xad0738: r17 = "replySerial"
    //     0xad0738: add             x17, PP, #0xb, lsl #12  ; [pp+0xb220] "replySerial"
    //     0xad073c: ldr             x17, [x17, #0x220]
    // 0xad0740: StoreField: r2->field_47 = r17
    //     0xad0740: stur            w17, [x2, #0x47]
    // 0xad0744: LoadField: r0 = r3->field_27
    //     0xad0744: ldur            w0, [x3, #0x27]
    // 0xad0748: DecompressPointer r0
    //     0xad0748: add             x0, x0, HEAP, lsl #32
    // 0xad074c: cmp             w0, NULL
    // 0xad0750: b.ne            #0xad075c
    // 0xad0754: r0 = Null
    //     0xad0754: mov             x0, NULL
    // 0xad0758: b               #0xad0794
    // 0xad075c: r1 = 59
    //     0xad075c: mov             x1, #0x3b
    // 0xad0760: branchIfSmi(r0, 0xad076c)
    //     0xad0760: tbz             w0, #0, #0xad076c
    // 0xad0764: r1 = LoadClassIdInstr(r0)
    //     0xad0764: ldur            x1, [x0, #-1]
    //     0xad0768: ubfx            x1, x1, #0xc, #0x14
    // 0xad076c: SaveReg r0
    //     0xad076c: str             x0, [SP, #-8]!
    // 0xad0770: mov             x0, x1
    // 0xad0774: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad0774: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad0778: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad0778: mov             x17, #0x3f73
    //     0xad077c: add             lr, x0, x17
    //     0xad0780: ldr             lr, [x21, lr, lsl #3]
    //     0xad0784: blr             lr
    // 0xad0788: add             SP, SP, #8
    // 0xad078c: ldr             x3, [fp, #0x10]
    // 0xad0790: ldur            x2, [fp, #-8]
    // 0xad0794: mov             x1, x2
    // 0xad0798: ArrayStore: r1[15] = r0  ; List_4
    //     0xad0798: add             x25, x1, #0x4b
    //     0xad079c: str             w0, [x25]
    //     0xad07a0: tbz             w0, #0, #0xad07bc
    //     0xad07a4: ldurb           w16, [x1, #-1]
    //     0xad07a8: ldurb           w17, [x0, #-1]
    //     0xad07ac: and             x16, x17, x16, lsr #2
    //     0xad07b0: tst             x16, HEAP, lsr #32
    //     0xad07b4: b.eq            #0xad07bc
    //     0xad07b8: bl              #0xd67e5c
    // 0xad07bc: r17 = "destination"
    //     0xad07bc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb228] "destination"
    //     0xad07c0: ldr             x17, [x17, #0x228]
    // 0xad07c4: StoreField: r2->field_4f = r17
    //     0xad07c4: stur            w17, [x2, #0x4f]
    // 0xad07c8: LoadField: r0 = r3->field_2b
    //     0xad07c8: ldur            w0, [x3, #0x2b]
    // 0xad07cc: DecompressPointer r0
    //     0xad07cc: add             x0, x0, HEAP, lsl #32
    // 0xad07d0: cmp             w0, NULL
    // 0xad07d4: b.ne            #0xad07e0
    // 0xad07d8: r0 = Null
    //     0xad07d8: mov             x0, NULL
    // 0xad07dc: b               #0xad07f4
    // 0xad07e0: SaveReg r0
    //     0xad07e0: str             x0, [SP, #-8]!
    // 0xad07e4: r0 = toString()
    //     0xad07e4: bl              #0xacf7c0  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::toString
    // 0xad07e8: add             SP, SP, #8
    // 0xad07ec: ldr             x3, [fp, #0x10]
    // 0xad07f0: ldur            x2, [fp, #-8]
    // 0xad07f4: mov             x1, x2
    // 0xad07f8: ArrayStore: r1[17] = r0  ; List_4
    //     0xad07f8: add             x25, x1, #0x53
    //     0xad07fc: str             w0, [x25]
    //     0xad0800: tbz             w0, #0, #0xad081c
    //     0xad0804: ldurb           w16, [x1, #-1]
    //     0xad0808: ldurb           w17, [x0, #-1]
    //     0xad080c: and             x16, x17, x16, lsr #2
    //     0xad0810: tst             x16, HEAP, lsr #32
    //     0xad0814: b.eq            #0xad081c
    //     0xad0818: bl              #0xd67e5c
    // 0xad081c: r17 = "sender"
    //     0xad081c: ldr             x17, [PP, #0x7640]  ; [pp+0x7640] "sender"
    // 0xad0820: StoreField: r2->field_57 = r17
    //     0xad0820: stur            w17, [x2, #0x57]
    // 0xad0824: LoadField: r0 = r3->field_2f
    //     0xad0824: ldur            w0, [x3, #0x2f]
    // 0xad0828: DecompressPointer r0
    //     0xad0828: add             x0, x0, HEAP, lsl #32
    // 0xad082c: cmp             w0, NULL
    // 0xad0830: b.ne            #0xad083c
    // 0xad0834: r0 = Null
    //     0xad0834: mov             x0, NULL
    // 0xad0838: b               #0xad0850
    // 0xad083c: SaveReg r0
    //     0xad083c: str             x0, [SP, #-8]!
    // 0xad0840: r0 = toString()
    //     0xad0840: bl              #0xacf7c0  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::toString
    // 0xad0844: add             SP, SP, #8
    // 0xad0848: ldr             x3, [fp, #0x10]
    // 0xad084c: ldur            x2, [fp, #-8]
    // 0xad0850: mov             x1, x2
    // 0xad0854: ArrayStore: r1[19] = r0  ; List_4
    //     0xad0854: add             x25, x1, #0x5b
    //     0xad0858: str             w0, [x25]
    //     0xad085c: tbz             w0, #0, #0xad0878
    //     0xad0860: ldurb           w16, [x1, #-1]
    //     0xad0864: ldurb           w17, [x0, #-1]
    //     0xad0868: and             x16, x17, x16, lsr #2
    //     0xad086c: tst             x16, HEAP, lsr #32
    //     0xad0870: b.eq            #0xad0878
    //     0xad0874: bl              #0xd67e5c
    // 0xad0878: r17 = "values"
    //     0xad0878: ldr             x17, [PP, #0x7720]  ; [pp+0x7720] "values"
    // 0xad087c: StoreField: r2->field_5f = r17
    //     0xad087c: stur            w17, [x2, #0x5f]
    // 0xad0880: LoadField: r1 = r3->field_33
    //     0xad0880: ldur            w1, [x3, #0x33]
    // 0xad0884: DecompressPointer r1
    //     0xad0884: add             x1, x1, HEAP, lsl #32
    // 0xad0888: stur            x1, [fp, #-0x10]
    // 0xad088c: r0 = LoadClassIdInstr(r1)
    //     0xad088c: ldur            x0, [x1, #-1]
    //     0xad0890: ubfx            x0, x0, #0xc, #0x14
    // 0xad0894: SaveReg r1
    //     0xad0894: str             x1, [SP, #-8]!
    // 0xad0898: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0xad0898: mov             x17, #0xcc6c
    //     0xad089c: add             lr, x0, x17
    //     0xad08a0: ldr             lr, [x21, lr, lsl #3]
    //     0xad08a4: blr             lr
    // 0xad08a8: add             SP, SP, #8
    // 0xad08ac: tbnz            w0, #4, #0xad08e0
    // 0xad08b0: ldur            x0, [fp, #-0x10]
    // 0xad08b4: r1 = LoadClassIdInstr(r0)
    //     0xad08b4: ldur            x1, [x0, #-1]
    //     0xad08b8: ubfx            x1, x1, #0xc, #0x14
    // 0xad08bc: SaveReg r0
    //     0xad08bc: str             x0, [SP, #-8]!
    // 0xad08c0: mov             x0, x1
    // 0xad08c4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad08c4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad08c8: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad08c8: mov             x17, #0x3f73
    //     0xad08cc: add             lr, x0, x17
    //     0xad08d0: ldr             lr, [x21, lr, lsl #3]
    //     0xad08d4: blr             lr
    // 0xad08d8: add             SP, SP, #8
    // 0xad08dc: b               #0xad08e4
    // 0xad08e0: r0 = Null
    //     0xad08e0: mov             x0, NULL
    // 0xad08e4: ldur            x1, [fp, #-8]
    // 0xad08e8: ArrayStore: r1[21] = r0  ; List_4
    //     0xad08e8: add             x25, x1, #0x63
    //     0xad08ec: str             w0, [x25]
    //     0xad08f0: tbz             w0, #0, #0xad090c
    //     0xad08f4: ldurb           w16, [x1, #-1]
    //     0xad08f8: ldurb           w17, [x0, #-1]
    //     0xad08fc: and             x16, x17, x16, lsr #2
    //     0xad0900: tst             x16, HEAP, lsr #32
    //     0xad0904: b.eq            #0xad090c
    //     0xad0908: bl              #0xd67e5c
    // 0xad090c: r16 = <String, String?>
    //     0xad090c: ldr             x16, [PP, #0x7650]  ; [pp+0x7650] TypeArguments: <String, String?>
    // 0xad0910: ldur            lr, [fp, #-8]
    // 0xad0914: stp             lr, x16, [SP, #-0x10]!
    // 0xad0918: r0 = Map._fromLiteral()
    //     0xad0918: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xad091c: add             SP, SP, #0x10
    // 0xad0920: stur            x0, [fp, #-8]
    // 0xad0924: r1 = 1
    //     0xad0924: mov             x1, #1
    // 0xad0928: r0 = AllocateContext()
    //     0xad0928: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad092c: mov             x1, x0
    // 0xad0930: ldur            x0, [fp, #-8]
    // 0xad0934: stur            x1, [fp, #-0x10]
    // 0xad0938: StoreField: r1->field_f = r0
    //     0xad0938: stur            w0, [x1, #0xf]
    // 0xad093c: SaveReg r0
    //     0xad093c: str             x0, [SP, #-8]!
    // 0xad0940: r0 = keys()
    //     0xad0940: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0xad0944: add             SP, SP, #8
    // 0xad0948: ldur            x2, [fp, #-0x10]
    // 0xad094c: r1 = Function '<anonymous closure>':.
    //     0xad094c: add             x1, PP, #0xb, lsl #12  ; [pp+0xb230] AnonymousClosure: (0xacff6c), in [package:dbus/src/dbus_match_rule.dart] DBusMatchRule::toString (0xacfff0)
    //     0xad0950: ldr             x1, [x1, #0x230]
    // 0xad0954: stur            x0, [fp, #-8]
    // 0xad0958: r0 = AllocateClosure()
    //     0xad0958: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad095c: ldur            x16, [fp, #-8]
    // 0xad0960: stp             x0, x16, [SP, #-0x10]!
    // 0xad0964: r0 = where()
    //     0xad0964: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0xad0968: add             SP, SP, #0x10
    // 0xad096c: ldur            x2, [fp, #-0x10]
    // 0xad0970: r1 = Function '<anonymous closure>':.
    //     0xad0970: add             x1, PP, #0xb, lsl #12  ; [pp+0xb238] AnonymousClosure: (0xacfe94), in [package:dbus/src/dbus_message.dart] DBusMessage::toString (0xad0424)
    //     0xad0974: ldr             x1, [x1, #0x238]
    // 0xad0978: stur            x0, [fp, #-8]
    // 0xad097c: r0 = AllocateClosure()
    //     0xad097c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad0980: r16 = <String>
    //     0xad0980: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad0984: ldur            lr, [fp, #-8]
    // 0xad0988: stp             lr, x16, [SP, #-0x10]!
    // 0xad098c: SaveReg r0
    //     0xad098c: str             x0, [SP, #-8]!
    // 0xad0990: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad0990: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad0994: r0 = map()
    //     0xad0994: bl              #0x6ba568  ; [dart:_internal] WhereIterable::map
    // 0xad0998: add             SP, SP, #0x18
    // 0xad099c: r16 = ", "
    //     0xad099c: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad09a0: stp             x16, x0, [SP, #-0x10]!
    // 0xad09a4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad09a4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad09a8: r0 = join()
    //     0xad09a8: bl              #0x6a9d88  ; [dart:core] Iterable::join
    // 0xad09ac: add             SP, SP, #0x10
    // 0xad09b0: r1 = Null
    //     0xad09b0: mov             x1, NULL
    // 0xad09b4: r2 = 8
    //     0xad09b4: mov             x2, #8
    // 0xad09b8: stur            x0, [fp, #-8]
    // 0xad09bc: r0 = AllocateArray()
    //     0xad09bc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad09c0: r17 = DBusMessage
    //     0xad09c0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb240] Type: DBusMessage
    //     0xad09c4: ldr             x17, [x17, #0x240]
    // 0xad09c8: StoreField: r0->field_f = r17
    //     0xad09c8: stur            w17, [x0, #0xf]
    // 0xad09cc: r17 = "("
    //     0xad09cc: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad09d0: StoreField: r0->field_13 = r17
    //     0xad09d0: stur            w17, [x0, #0x13]
    // 0xad09d4: ldur            x1, [fp, #-8]
    // 0xad09d8: StoreField: r0->field_17 = r1
    //     0xad09d8: stur            w1, [x0, #0x17]
    // 0xad09dc: r17 = ")"
    //     0xad09dc: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad09e0: StoreField: r0->field_1b = r17
    //     0xad09e0: stur            w17, [x0, #0x1b]
    // 0xad09e4: SaveReg r0
    //     0xad09e4: str             x0, [SP, #-8]!
    // 0xad09e8: r0 = _interpolate()
    //     0xad09e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad09ec: add             SP, SP, #8
    // 0xad09f0: LeaveFrame
    //     0xad09f0: mov             SP, fp
    //     0xad09f4: ldp             fp, lr, [SP], #0x10
    // 0xad09f8: ret
    //     0xad09f8: ret             
    // 0xad09fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad09fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad0a00: b               #0xad043c
  }
}

// class id: 6010, size: 0x14, field offset: 0x14
enum DBusMessageFlag extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15448, size: 0x5c
    // 0xb15448: EnterFrame
    //     0xb15448: stp             fp, lr, [SP, #-0x10]!
    //     0xb1544c: mov             fp, SP
    // 0xb15450: CheckStackOverflow
    //     0xb15450: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15454: cmp             SP, x16
    //     0xb15458: b.ls            #0xb1549c
    // 0xb1545c: r1 = Null
    //     0xb1545c: mov             x1, NULL
    // 0xb15460: r2 = 4
    //     0xb15460: mov             x2, #4
    // 0xb15464: r0 = AllocateArray()
    //     0xb15464: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15468: r17 = "DBusMessageFlag."
    //     0xb15468: add             x17, PP, #0xb, lsl #12  ; [pp+0xb200] "DBusMessageFlag."
    //     0xb1546c: ldr             x17, [x17, #0x200]
    // 0xb15470: StoreField: r0->field_f = r17
    //     0xb15470: stur            w17, [x0, #0xf]
    // 0xb15474: ldr             x1, [fp, #0x10]
    // 0xb15478: LoadField: r2 = r1->field_f
    //     0xb15478: ldur            w2, [x1, #0xf]
    // 0xb1547c: DecompressPointer r2
    //     0xb1547c: add             x2, x2, HEAP, lsl #32
    // 0xb15480: StoreField: r0->field_13 = r2
    //     0xb15480: stur            w2, [x0, #0x13]
    // 0xb15484: SaveReg r0
    //     0xb15484: str             x0, [SP, #-8]!
    // 0xb15488: r0 = _interpolate()
    //     0xb15488: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb1548c: add             SP, SP, #8
    // 0xb15490: LeaveFrame
    //     0xb15490: mov             SP, fp
    //     0xb15494: ldp             fp, lr, [SP], #0x10
    // 0xb15498: ret
    //     0xb15498: ret             
    // 0xb1549c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1549c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb154a0: b               #0xb1545c
  }
}

// class id: 6011, size: 0x14, field offset: 0x14
enum DBusMessageType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb153ec, size: 0x5c
    // 0xb153ec: EnterFrame
    //     0xb153ec: stp             fp, lr, [SP, #-0x10]!
    //     0xb153f0: mov             fp, SP
    // 0xb153f4: CheckStackOverflow
    //     0xb153f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb153f8: cmp             SP, x16
    //     0xb153fc: b.ls            #0xb15440
    // 0xb15400: r1 = Null
    //     0xb15400: mov             x1, NULL
    // 0xb15404: r2 = 4
    //     0xb15404: mov             x2, #4
    // 0xb15408: r0 = AllocateArray()
    //     0xb15408: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1540c: r17 = "DBusMessageType."
    //     0xb1540c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb208] "DBusMessageType."
    //     0xb15410: ldr             x17, [x17, #0x208]
    // 0xb15414: StoreField: r0->field_f = r17
    //     0xb15414: stur            w17, [x0, #0xf]
    // 0xb15418: ldr             x1, [fp, #0x10]
    // 0xb1541c: LoadField: r2 = r1->field_f
    //     0xb1541c: ldur            w2, [x1, #0xf]
    // 0xb15420: DecompressPointer r2
    //     0xb15420: add             x2, x2, HEAP, lsl #32
    // 0xb15424: StoreField: r0->field_13 = r2
    //     0xb15424: stur            w2, [x0, #0x13]
    // 0xb15428: SaveReg r0
    //     0xb15428: str             x0, [SP, #-8]!
    // 0xb1542c: r0 = _interpolate()
    //     0xb1542c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15430: add             SP, SP, #8
    // 0xb15434: LeaveFrame
    //     0xb15434: mov             SP, fp
    //     0xb15438: ldp             fp, lr, [SP], #0x10
    // 0xb1543c: ret
    //     0xb1543c: ret             
    // 0xb15440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15440: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15444: b               #0xb15400
  }
}

// lib: , url: package:dbus/src/dbus_read_buffer.dart

// class id: 1048848, size: 0x8
class :: {
}

// class id: 4635, size: 0xa4, field offset: 0x90
class DBusReadBuffer extends DBusBuffer {

  late ByteData _view; // offset: 0x98

  _ readMessage(/* No info */) {
    // ** addr: 0xa07878, size: 0x1950
    // 0xa07878: EnterFrame
    //     0xa07878: stp             fp, lr, [SP, #-0x10]!
    //     0xa0787c: mov             fp, SP
    // 0xa07880: AllocStack(0xc0)
    //     0xa07880: sub             SP, SP, #0xc0
    // 0xa07884: CheckStackOverflow
    //     0xa07884: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa07888: cmp             SP, x16
    //     0xa0788c: b.ls            #0xa0918c
    // 0xa07890: ldr             x0, [fp, #0x10]
    // 0xa07894: LoadField: r1 = r0->field_8f
    //     0xa07894: ldur            w1, [x0, #0x8f]
    // 0xa07898: DecompressPointer r1
    //     0xa07898: add             x1, x1, HEAP, lsl #32
    // 0xa0789c: LoadField: r2 = r1->field_13
    //     0xa0789c: ldur            w2, [x1, #0x13]
    // 0xa078a0: DecompressPointer r2
    //     0xa078a0: add             x2, x2, HEAP, lsl #32
    // 0xa078a4: LoadField: r1 = r0->field_9b
    //     0xa078a4: ldur            x1, [x0, #0x9b]
    // 0xa078a8: r3 = LoadInt32Instr(r2)
    //     0xa078a8: sbfx            x3, x2, #1, #0x1f
    // 0xa078ac: sub             x2, x3, x1
    // 0xa078b0: cmp             x2, #0xc
    // 0xa078b4: b.ge            #0xa078c8
    // 0xa078b8: r0 = Null
    //     0xa078b8: mov             x0, NULL
    // 0xa078bc: LeaveFrame
    //     0xa078bc: mov             SP, fp
    //     0xa078c0: ldp             fp, lr, [SP], #0x10
    // 0xa078c4: ret
    //     0xa078c4: ret             
    // 0xa078c8: r1 = Null
    //     0xa078c8: mov             x1, NULL
    // 0xa078cc: r2 = 8
    //     0xa078cc: mov             x2, #8
    // 0xa078d0: r0 = AllocateArray()
    //     0xa078d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa078d4: r17 = 216
    //     0xa078d4: mov             x17, #0xd8
    // 0xa078d8: StoreField: r0->field_f = r17
    //     0xa078d8: stur            w17, [x0, #0xf]
    // 0xa078dc: r17 = Instance_Endian
    //     0xa078dc: ldr             x17, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xa078e0: StoreField: r0->field_13 = r17
    //     0xa078e0: stur            w17, [x0, #0x13]
    // 0xa078e4: r17 = 132
    //     0xa078e4: mov             x17, #0x84
    // 0xa078e8: StoreField: r0->field_17 = r17
    //     0xa078e8: stur            w17, [x0, #0x17]
    // 0xa078ec: r17 = Instance_Endian
    //     0xa078ec: ldr             x17, [PP, #0x7f78]  ; [pp+0x7f78] Obj!Endian@b5f5b1
    // 0xa078f0: StoreField: r0->field_1b = r17
    //     0xa078f0: stur            w17, [x0, #0x1b]
    // 0xa078f4: r16 = <int, Endian>
    //     0xa078f4: ldr             x16, [PP, #0x7f80]  ; [pp+0x7f80] TypeArguments: <int, Endian>
    // 0xa078f8: stp             x0, x16, [SP, #-0x10]!
    // 0xa078fc: r0 = Map._fromLiteral()
    //     0xa078fc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa07900: add             SP, SP, #0x10
    // 0xa07904: stur            x0, [fp, #-8]
    // 0xa07908: ldr             x16, [fp, #0x10]
    // 0xa0790c: SaveReg r16
    //     0xa0790c: str             x16, [SP, #-8]!
    // 0xa07910: r0 = readDBusByte()
    //     0xa07910: bl              #0xa0c09c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusByte
    // 0xa07914: add             SP, SP, #8
    // 0xa07918: cmp             w0, NULL
    // 0xa0791c: b.eq            #0xa09194
    // 0xa07920: LoadField: r2 = r0->field_7
    //     0xa07920: ldur            x2, [x0, #7]
    // 0xa07924: r0 = BoxInt64Instr(r2)
    //     0xa07924: sbfiz           x0, x2, #1, #0x1f
    //     0xa07928: cmp             x2, x0, asr #1
    //     0xa0792c: b.eq            #0xa07938
    //     0xa07930: bl              #0xd69bb8
    //     0xa07934: stur            x2, [x0, #7]
    // 0xa07938: ldur            x16, [fp, #-8]
    // 0xa0793c: stp             x0, x16, [SP, #-0x10]!
    // 0xa07940: r0 = _getValueOrData()
    //     0xa07940: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa07944: add             SP, SP, #0x10
    // 0xa07948: mov             x1, x0
    // 0xa0794c: ldur            x0, [fp, #-8]
    // 0xa07950: LoadField: r2 = r0->field_f
    //     0xa07950: ldur            w2, [x0, #0xf]
    // 0xa07954: DecompressPointer r2
    //     0xa07954: add             x2, x2, HEAP, lsl #32
    // 0xa07958: cmp             w2, w1
    // 0xa0795c: b.ne            #0xa07968
    // 0xa07960: r0 = Null
    //     0xa07960: mov             x0, NULL
    // 0xa07964: b               #0xa0796c
    // 0xa07968: mov             x0, x1
    // 0xa0796c: stur            x0, [fp, #-8]
    // 0xa07970: cmp             w0, NULL
    // 0xa07974: b.eq            #0xa08b84
    // 0xa07978: r1 = Null
    //     0xa07978: mov             x1, NULL
    // 0xa0797c: r2 = 16
    //     0xa0797c: mov             x2, #0x10
    // 0xa07980: r0 = AllocateArray()
    //     0xa07980: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa07984: r17 = 2
    //     0xa07984: mov             x17, #2
    // 0xa07988: StoreField: r0->field_f = r17
    //     0xa07988: stur            w17, [x0, #0xf]
    // 0xa0798c: r17 = Instance_DBusMessageType
    //     0xa0798c: ldr             x17, [PP, #0x7750]  ; [pp+0x7750] Obj!DBusMessageType@b667d1
    // 0xa07990: StoreField: r0->field_13 = r17
    //     0xa07990: stur            w17, [x0, #0x13]
    // 0xa07994: r17 = 4
    //     0xa07994: mov             x17, #4
    // 0xa07998: StoreField: r0->field_17 = r17
    //     0xa07998: stur            w17, [x0, #0x17]
    // 0xa0799c: r17 = Instance_DBusMessageType
    //     0xa0799c: ldr             x17, [PP, #0x7818]  ; [pp+0x7818] Obj!DBusMessageType@b66791
    // 0xa079a0: StoreField: r0->field_1b = r17
    //     0xa079a0: stur            w17, [x0, #0x1b]
    // 0xa079a4: r17 = 6
    //     0xa079a4: mov             x17, #6
    // 0xa079a8: StoreField: r0->field_1f = r17
    //     0xa079a8: stur            w17, [x0, #0x1f]
    // 0xa079ac: r17 = Instance_DBusMessageType
    //     0xa079ac: ldr             x17, [PP, #0x7820]  ; [pp+0x7820] Obj!DBusMessageType@b66771
    // 0xa079b0: StoreField: r0->field_23 = r17
    //     0xa079b0: stur            w17, [x0, #0x23]
    // 0xa079b4: r17 = 8
    //     0xa079b4: mov             x17, #8
    // 0xa079b8: StoreField: r0->field_27 = r17
    //     0xa079b8: stur            w17, [x0, #0x27]
    // 0xa079bc: r17 = Instance_DBusMessageType
    //     0xa079bc: ldr             x17, [PP, #0x530]  ; [pp+0x530] Obj!DBusMessageType@b667b1
    // 0xa079c0: StoreField: r0->field_2b = r17
    //     0xa079c0: stur            w17, [x0, #0x2b]
    // 0xa079c4: r16 = <int, DBusMessageType>
    //     0xa079c4: ldr             x16, [PP, #0x7f88]  ; [pp+0x7f88] TypeArguments: <int, DBusMessageType>
    // 0xa079c8: stp             x0, x16, [SP, #-0x10]!
    // 0xa079cc: r0 = Map._fromLiteral()
    //     0xa079cc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa079d0: add             SP, SP, #0x10
    // 0xa079d4: stur            x0, [fp, #-0x10]
    // 0xa079d8: ldr             x16, [fp, #0x10]
    // 0xa079dc: SaveReg r16
    //     0xa079dc: str             x16, [SP, #-8]!
    // 0xa079e0: r0 = readDBusByte()
    //     0xa079e0: bl              #0xa0c09c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusByte
    // 0xa079e4: add             SP, SP, #8
    // 0xa079e8: cmp             w0, NULL
    // 0xa079ec: b.eq            #0xa09198
    // 0xa079f0: LoadField: r2 = r0->field_7
    //     0xa079f0: ldur            x2, [x0, #7]
    // 0xa079f4: r0 = BoxInt64Instr(r2)
    //     0xa079f4: sbfiz           x0, x2, #1, #0x1f
    //     0xa079f8: cmp             x2, x0, asr #1
    //     0xa079fc: b.eq            #0xa07a08
    //     0xa07a00: bl              #0xd69bb8
    //     0xa07a04: stur            x2, [x0, #7]
    // 0xa07a08: ldur            x16, [fp, #-0x10]
    // 0xa07a0c: stp             x0, x16, [SP, #-0x10]!
    // 0xa07a10: r0 = _getValueOrData()
    //     0xa07a10: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa07a14: add             SP, SP, #0x10
    // 0xa07a18: mov             x1, x0
    // 0xa07a1c: ldur            x0, [fp, #-0x10]
    // 0xa07a20: LoadField: r2 = r0->field_f
    //     0xa07a20: ldur            w2, [x0, #0xf]
    // 0xa07a24: DecompressPointer r2
    //     0xa07a24: add             x2, x2, HEAP, lsl #32
    // 0xa07a28: cmp             w2, w1
    // 0xa07a2c: b.ne            #0xa07a38
    // 0xa07a30: r0 = Null
    //     0xa07a30: mov             x0, NULL
    // 0xa07a34: b               #0xa07a3c
    // 0xa07a38: mov             x0, x1
    // 0xa07a3c: stur            x0, [fp, #-0x10]
    // 0xa07a40: cmp             w0, NULL
    // 0xa07a44: b.eq            #0xa08b94
    // 0xa07a48: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xa07a48: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa07a4c: ldr             x0, [x0, #0x598]
    //     0xa07a50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa07a54: cmp             w0, w16
    //     0xa07a58: b.ne            #0xa07a64
    //     0xa07a5c: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xa07a60: bl              #0xd67cdc
    // 0xa07a64: r1 = <DBusMessageFlag>
    //     0xa07a64: ldr             x1, [PP, #0x7748]  ; [pp+0x7748] TypeArguments: <DBusMessageFlag>
    // 0xa07a68: stur            x0, [fp, #-0x18]
    // 0xa07a6c: r0 = _Set()
    //     0xa07a6c: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xa07a70: mov             x1, x0
    // 0xa07a74: ldur            x0, [fp, #-0x18]
    // 0xa07a78: stur            x1, [fp, #-0x20]
    // 0xa07a7c: StoreField: r1->field_1b = r0
    //     0xa07a7c: stur            w0, [x1, #0x1b]
    // 0xa07a80: StoreField: r1->field_b = rZR
    //     0xa07a80: stur            wzr, [x1, #0xb]
    // 0xa07a84: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xa07a84: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa07a88: ldr             x0, [x0, #0x5a0]
    //     0xa07a8c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa07a90: cmp             w0, w16
    //     0xa07a94: b.ne            #0xa07aa0
    //     0xa07a98: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xa07a9c: bl              #0xd67cdc
    // 0xa07aa0: mov             x1, x0
    // 0xa07aa4: ldur            x0, [fp, #-0x20]
    // 0xa07aa8: StoreField: r0->field_f = r1
    //     0xa07aa8: stur            w1, [x0, #0xf]
    // 0xa07aac: StoreField: r0->field_13 = rZR
    //     0xa07aac: stur            wzr, [x0, #0x13]
    // 0xa07ab0: StoreField: r0->field_17 = rZR
    //     0xa07ab0: stur            wzr, [x0, #0x17]
    // 0xa07ab4: ldr             x16, [fp, #0x10]
    // 0xa07ab8: SaveReg r16
    //     0xa07ab8: str             x16, [SP, #-8]!
    // 0xa07abc: r0 = readDBusByte()
    //     0xa07abc: bl              #0xa0c09c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusByte
    // 0xa07ac0: add             SP, SP, #8
    // 0xa07ac4: cmp             w0, NULL
    // 0xa07ac8: b.eq            #0xa0919c
    // 0xa07acc: LoadField: r1 = r0->field_7
    //     0xa07acc: ldur            x1, [x0, #7]
    // 0xa07ad0: stur            x1, [fp, #-0x28]
    // 0xa07ad4: mov             x0, x1
    // 0xa07ad8: ubfx            x0, x0, #0, #0x20
    // 0xa07adc: r2 = 1
    //     0xa07adc: mov             x2, #1
    // 0xa07ae0: and             x3, x0, x2
    // 0xa07ae4: ubfx            x3, x3, #0, #0x20
    // 0xa07ae8: cbz             x3, #0xa07b00
    // 0xa07aec: ldur            x16, [fp, #-0x20]
    // 0xa07af0: r30 = Instance_DBusMessageFlag
    //     0xa07af0: ldr             lr, [PP, #0x7830]  ; [pp+0x7830] Obj!DBusMessageFlag@b66751
    // 0xa07af4: stp             lr, x16, [SP, #-0x10]!
    // 0xa07af8: r0 = add()
    //     0xa07af8: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xa07afc: add             SP, SP, #0x10
    // 0xa07b00: r0 = 2
    //     0xa07b00: mov             x0, #2
    // 0xa07b04: ldur            x1, [fp, #-0x28]
    // 0xa07b08: ubfx            x1, x1, #0, #0x20
    // 0xa07b0c: and             x2, x1, x0
    // 0xa07b10: ubfx            x2, x2, #0, #0x20
    // 0xa07b14: cbz             x2, #0xa07b2c
    // 0xa07b18: ldur            x16, [fp, #-0x20]
    // 0xa07b1c: r30 = Instance_DBusMessageFlag
    //     0xa07b1c: ldr             lr, [PP, #0x7838]  ; [pp+0x7838] Obj!DBusMessageFlag@b66731
    // 0xa07b20: stp             lr, x16, [SP, #-0x10]!
    // 0xa07b24: r0 = add()
    //     0xa07b24: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xa07b28: add             SP, SP, #0x10
    // 0xa07b2c: r0 = 4
    //     0xa07b2c: mov             x0, #4
    // 0xa07b30: ldur            x1, [fp, #-0x28]
    // 0xa07b34: ubfx            x1, x1, #0, #0x20
    // 0xa07b38: and             x2, x1, x0
    // 0xa07b3c: ubfx            x2, x2, #0, #0x20
    // 0xa07b40: cbz             x2, #0xa07b58
    // 0xa07b44: ldur            x16, [fp, #-0x20]
    // 0xa07b48: r30 = Instance_DBusMessageFlag
    //     0xa07b48: ldr             lr, [PP, #0x7840]  ; [pp+0x7840] Obj!DBusMessageFlag@b66711
    // 0xa07b4c: stp             lr, x16, [SP, #-0x10]!
    // 0xa07b50: r0 = add()
    //     0xa07b50: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xa07b54: add             SP, SP, #0x10
    // 0xa07b58: ldr             x16, [fp, #0x10]
    // 0xa07b5c: SaveReg r16
    //     0xa07b5c: str             x16, [SP, #-8]!
    // 0xa07b60: r0 = readDBusByte()
    //     0xa07b60: bl              #0xa0c09c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusByte
    // 0xa07b64: add             SP, SP, #8
    // 0xa07b68: cmp             w0, NULL
    // 0xa07b6c: b.eq            #0xa091a0
    // 0xa07b70: LoadField: r1 = r0->field_7
    //     0xa07b70: ldur            x1, [x0, #7]
    // 0xa07b74: cmp             x1, #1
    // 0xa07b78: b.ne            #0xa08ba4
    // 0xa07b7c: ldr             x16, [fp, #0x10]
    // 0xa07b80: ldur            lr, [fp, #-8]
    // 0xa07b84: stp             lr, x16, [SP, #-0x10]!
    // 0xa07b88: r0 = readDBusUint32()
    //     0xa07b88: bl              #0xa0c000  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusUint32
    // 0xa07b8c: add             SP, SP, #0x10
    // 0xa07b90: cmp             w0, NULL
    // 0xa07b94: b.eq            #0xa091a4
    // 0xa07b98: LoadField: r1 = r0->field_7
    //     0xa07b98: ldur            x1, [x0, #7]
    // 0xa07b9c: stur            x1, [fp, #-0x28]
    // 0xa07ba0: ldr             x16, [fp, #0x10]
    // 0xa07ba4: ldur            lr, [fp, #-8]
    // 0xa07ba8: stp             lr, x16, [SP, #-0x10]!
    // 0xa07bac: r0 = readDBusUint32()
    //     0xa07bac: bl              #0xa0c000  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusUint32
    // 0xa07bb0: add             SP, SP, #0x10
    // 0xa07bb4: cmp             w0, NULL
    // 0xa07bb8: b.eq            #0xa091a8
    // 0xa07bbc: LoadField: r1 = r0->field_7
    //     0xa07bbc: ldur            x1, [x0, #7]
    // 0xa07bc0: stur            x1, [fp, #-0x30]
    // 0xa07bc4: r0 = DBusSignature()
    //     0xa07bc4: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa07bc8: stur            x0, [fp, #-0x18]
    // 0xa07bcc: r16 = "(yv)"
    //     0xa07bcc: ldr             x16, [PP, #0x7850]  ; [pp+0x7850] "(yv)"
    // 0xa07bd0: stp             x16, x0, [SP, #-0x10]!
    // 0xa07bd4: r0 = DBusSignature()
    //     0xa07bd4: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa07bd8: add             SP, SP, #0x10
    // 0xa07bdc: ldr             x16, [fp, #0x10]
    // 0xa07be0: ldur            lr, [fp, #-0x18]
    // 0xa07be4: stp             lr, x16, [SP, #-0x10]!
    // 0xa07be8: ldur            x16, [fp, #-8]
    // 0xa07bec: SaveReg r16
    //     0xa07bec: str             x16, [SP, #-8]!
    // 0xa07bf0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa07bf0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa07bf4: r0 = readDBusArray()
    //     0xa07bf4: bl              #0xa0bddc  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusArray
    // 0xa07bf8: add             SP, SP, #0x18
    // 0xa07bfc: cmp             w0, NULL
    // 0xa07c00: b.ne            #0xa07c14
    // 0xa07c04: r0 = Null
    //     0xa07c04: mov             x0, NULL
    // 0xa07c08: LeaveFrame
    //     0xa07c08: mov             SP, fp
    //     0xa07c0c: ldp             fp, lr, [SP], #0x10
    // 0xa07c10: ret
    //     0xa07c10: ret             
    // 0xa07c14: LoadField: r1 = r0->field_b
    //     0xa07c14: ldur            w1, [x0, #0xb]
    // 0xa07c18: DecompressPointer r1
    //     0xa07c18: add             x1, x1, HEAP, lsl #32
    // 0xa07c1c: r0 = LoadClassIdInstr(r1)
    //     0xa07c1c: ldur            x0, [x1, #-1]
    //     0xa07c20: ubfx            x0, x0, #0xc, #0x14
    // 0xa07c24: SaveReg r1
    //     0xa07c24: str             x1, [SP, #-8]!
    // 0xa07c28: r0 = GDT[cid_x0 + 0xb940]()
    //     0xa07c28: mov             x17, #0xb940
    //     0xa07c2c: add             lr, x0, x17
    //     0xa07c30: ldr             lr, [x21, lr, lsl #3]
    //     0xa07c34: blr             lr
    // 0xa07c38: add             SP, SP, #8
    // 0xa07c3c: mov             x1, x0
    // 0xa07c40: stur            x1, [fp, #-0x78]
    // 0xa07c44: r10 = Null
    //     0xa07c44: mov             x10, NULL
    // 0xa07c48: r9 = Null
    //     0xa07c48: mov             x9, NULL
    // 0xa07c4c: r8 = Null
    //     0xa07c4c: mov             x8, NULL
    // 0xa07c50: r7 = Null
    //     0xa07c50: mov             x7, NULL
    // 0xa07c54: r6 = Null
    //     0xa07c54: mov             x6, NULL
    // 0xa07c58: r5 = Null
    //     0xa07c58: mov             x5, NULL
    // 0xa07c5c: r4 = Null
    //     0xa07c5c: mov             x4, NULL
    // 0xa07c60: r3 = Null
    //     0xa07c60: mov             x3, NULL
    // 0xa07c64: r2 = 0
    //     0xa07c64: mov             x2, #0
    // 0xa07c68: stur            x10, [fp, #-0x18]
    // 0xa07c6c: stur            x9, [fp, #-0x38]
    // 0xa07c70: stur            x8, [fp, #-0x40]
    // 0xa07c74: stur            x7, [fp, #-0x48]
    // 0xa07c78: stur            x6, [fp, #-0x50]
    // 0xa07c7c: stur            x5, [fp, #-0x58]
    // 0xa07c80: stur            x4, [fp, #-0x60]
    // 0xa07c84: stur            x3, [fp, #-0x68]
    // 0xa07c88: stur            x2, [fp, #-0x70]
    // 0xa07c8c: CheckStackOverflow
    //     0xa07c8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa07c90: cmp             SP, x16
    //     0xa07c94: b.ls            #0xa091ac
    // 0xa07c98: r0 = LoadClassIdInstr(r1)
    //     0xa07c98: ldur            x0, [x1, #-1]
    //     0xa07c9c: ubfx            x0, x0, #0xc, #0x14
    // 0xa07ca0: SaveReg r1
    //     0xa07ca0: str             x1, [SP, #-8]!
    // 0xa07ca4: r0 = GDT[cid_x0 + 0x541]()
    //     0xa07ca4: add             lr, x0, #0x541
    //     0xa07ca8: ldr             lr, [x21, lr, lsl #3]
    //     0xa07cac: blr             lr
    // 0xa07cb0: add             SP, SP, #8
    // 0xa07cb4: tbnz            w0, #4, #0xa087cc
    // 0xa07cb8: ldur            x1, [fp, #-0x78]
    // 0xa07cbc: r0 = LoadClassIdInstr(r1)
    //     0xa07cbc: ldur            x0, [x1, #-1]
    //     0xa07cc0: ubfx            x0, x0, #0xc, #0x14
    // 0xa07cc4: SaveReg r1
    //     0xa07cc4: str             x1, [SP, #-8]!
    // 0xa07cc8: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xa07cc8: add             lr, x0, #0x5ca
    //     0xa07ccc: ldr             lr, [x21, lr, lsl #3]
    //     0xa07cd0: blr             lr
    // 0xa07cd4: add             SP, SP, #8
    // 0xa07cd8: mov             x3, x0
    // 0xa07cdc: r2 = Null
    //     0xa07cdc: mov             x2, NULL
    // 0xa07ce0: r1 = Null
    //     0xa07ce0: mov             x1, NULL
    // 0xa07ce4: stur            x3, [fp, #-0x80]
    // 0xa07ce8: r4 = 59
    //     0xa07ce8: mov             x4, #0x3b
    // 0xa07cec: branchIfSmi(r0, 0xa07cf8)
    //     0xa07cec: tbz             w0, #0, #0xa07cf8
    // 0xa07cf0: r4 = LoadClassIdInstr(r0)
    //     0xa07cf0: ldur            x4, [x0, #-1]
    //     0xa07cf4: ubfx            x4, x4, #0xc, #0x14
    // 0xa07cf8: r17 = 4569
    //     0xa07cf8: mov             x17, #0x11d9
    // 0xa07cfc: cmp             x4, x17
    // 0xa07d00: b.eq            #0xa07d10
    // 0xa07d04: r8 = DBusStruct
    //     0xa07d04: ldr             x8, [PP, #0x7f90]  ; [pp+0x7f90] Type: DBusStruct
    // 0xa07d08: r3 = Null
    //     0xa07d08: ldr             x3, [PP, #0x7f98]  ; [pp+0x7f98] Null
    // 0xa07d0c: r0 = DefaultTypeTest()
    //     0xa07d0c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa07d10: ldur            x0, [fp, #-0x80]
    // 0xa07d14: LoadField: r1 = r0->field_7
    //     0xa07d14: ldur            w1, [x0, #7]
    // 0xa07d18: DecompressPointer r1
    //     0xa07d18: add             x1, x1, HEAP, lsl #32
    // 0xa07d1c: stur            x1, [fp, #-0x88]
    // 0xa07d20: r0 = LoadClassIdInstr(r1)
    //     0xa07d20: ldur            x0, [x1, #-1]
    //     0xa07d24: ubfx            x0, x0, #0xc, #0x14
    // 0xa07d28: stp             xzr, x1, [SP, #-0x10]!
    // 0xa07d2c: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa07d2c: mov             x17, #0xd175
    //     0xa07d30: add             lr, x0, x17
    //     0xa07d34: ldr             lr, [x21, lr, lsl #3]
    //     0xa07d38: blr             lr
    // 0xa07d3c: add             SP, SP, #0x10
    // 0xa07d40: mov             x3, x0
    // 0xa07d44: r2 = Null
    //     0xa07d44: mov             x2, NULL
    // 0xa07d48: r1 = Null
    //     0xa07d48: mov             x1, NULL
    // 0xa07d4c: stur            x3, [fp, #-0x80]
    // 0xa07d50: r4 = 59
    //     0xa07d50: mov             x4, #0x3b
    // 0xa07d54: branchIfSmi(r0, 0xa07d60)
    //     0xa07d54: tbz             w0, #0, #0xa07d60
    // 0xa07d58: r4 = LoadClassIdInstr(r0)
    //     0xa07d58: ldur            x4, [x0, #-1]
    //     0xa07d5c: ubfx            x4, x4, #0xc, #0x14
    // 0xa07d60: r17 = 4583
    //     0xa07d60: mov             x17, #0x11e7
    // 0xa07d64: cmp             x4, x17
    // 0xa07d68: b.eq            #0xa07d78
    // 0xa07d6c: r8 = DBusByte
    //     0xa07d6c: ldr             x8, [PP, #0x7fa8]  ; [pp+0x7fa8] Type: DBusByte
    // 0xa07d70: r3 = Null
    //     0xa07d70: ldr             x3, [PP, #0x7fb0]  ; [pp+0x7fb0] Null
    // 0xa07d74: r0 = DefaultTypeTest()
    //     0xa07d74: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa07d78: ldur            x0, [fp, #-0x80]
    // 0xa07d7c: LoadField: r1 = r0->field_7
    //     0xa07d7c: ldur            x1, [x0, #7]
    // 0xa07d80: ldur            x0, [fp, #-0x88]
    // 0xa07d84: stur            x1, [fp, #-0x90]
    // 0xa07d88: r2 = LoadClassIdInstr(r0)
    //     0xa07d88: ldur            x2, [x0, #-1]
    //     0xa07d8c: ubfx            x2, x2, #0xc, #0x14
    // 0xa07d90: r16 = 2
    //     0xa07d90: mov             x16, #2
    // 0xa07d94: stp             x16, x0, [SP, #-0x10]!
    // 0xa07d98: mov             x0, x2
    // 0xa07d9c: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa07d9c: mov             x17, #0xd175
    //     0xa07da0: add             lr, x0, x17
    //     0xa07da4: ldr             lr, [x21, lr, lsl #3]
    //     0xa07da8: blr             lr
    // 0xa07dac: add             SP, SP, #0x10
    // 0xa07db0: mov             x3, x0
    // 0xa07db4: r2 = Null
    //     0xa07db4: mov             x2, NULL
    // 0xa07db8: r1 = Null
    //     0xa07db8: mov             x1, NULL
    // 0xa07dbc: stur            x3, [fp, #-0x80]
    // 0xa07dc0: r4 = 59
    //     0xa07dc0: mov             x4, #0x3b
    // 0xa07dc4: branchIfSmi(r0, 0xa07dd0)
    //     0xa07dc4: tbz             w0, #0, #0xa07dd0
    // 0xa07dc8: r4 = LoadClassIdInstr(r0)
    //     0xa07dc8: ldur            x4, [x0, #-1]
    //     0xa07dcc: ubfx            x4, x4, #0xc, #0x14
    // 0xa07dd0: r17 = 4571
    //     0xa07dd0: mov             x17, #0x11db
    // 0xa07dd4: cmp             x4, x17
    // 0xa07dd8: b.eq            #0xa07de8
    // 0xa07ddc: r8 = DBusVariant
    //     0xa07ddc: ldr             x8, [PP, #0x7fc0]  ; [pp+0x7fc0] Type: DBusVariant
    // 0xa07de0: r3 = Null
    //     0xa07de0: ldr             x3, [PP, #0x7fc8]  ; [pp+0x7fc8] Null
    // 0xa07de4: r0 = DefaultTypeTest()
    //     0xa07de4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa07de8: ldur            x0, [fp, #-0x80]
    // 0xa07dec: LoadField: r1 = r0->field_7
    //     0xa07dec: ldur            w1, [x0, #7]
    // 0xa07df0: DecompressPointer r1
    //     0xa07df0: add             x1, x1, HEAP, lsl #32
    // 0xa07df4: ldur            x0, [fp, #-0x90]
    // 0xa07df8: stur            x1, [fp, #-0x88]
    // 0xa07dfc: cmp             x0, #1
    // 0xa07e00: b.ne            #0xa07ecc
    // 0xa07e04: r0 = LoadClassIdInstr(r1)
    //     0xa07e04: ldur            x0, [x1, #-1]
    //     0xa07e08: ubfx            x0, x0, #0xc, #0x14
    // 0xa07e0c: SaveReg r1
    //     0xa07e0c: str             x1, [SP, #-8]!
    // 0xa07e10: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa07e10: add             lr, x0, #0x2b8
    //     0xa07e14: ldr             lr, [x21, lr, lsl #3]
    //     0xa07e18: blr             lr
    // 0xa07e1c: add             SP, SP, #8
    // 0xa07e20: stur            x0, [fp, #-0x80]
    // 0xa07e24: r0 = DBusSignature()
    //     0xa07e24: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa07e28: stur            x0, [fp, #-0x98]
    // 0xa07e2c: r16 = "o"
    //     0xa07e2c: ldr             x16, [PP, #0x7690]  ; [pp+0x7690] "o"
    // 0xa07e30: stp             x16, x0, [SP, #-0x10]!
    // 0xa07e34: r0 = DBusSignature()
    //     0xa07e34: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa07e38: add             SP, SP, #0x10
    // 0xa07e3c: ldur            x0, [fp, #-0x98]
    // 0xa07e40: LoadField: r1 = r0->field_7
    //     0xa07e40: ldur            w1, [x0, #7]
    // 0xa07e44: DecompressPointer r1
    //     0xa07e44: add             x1, x1, HEAP, lsl #32
    // 0xa07e48: ldur            x0, [fp, #-0x80]
    // 0xa07e4c: LoadField: r2 = r0->field_7
    //     0xa07e4c: ldur            w2, [x0, #7]
    // 0xa07e50: DecompressPointer r2
    //     0xa07e50: add             x2, x2, HEAP, lsl #32
    // 0xa07e54: r0 = LoadClassIdInstr(r1)
    //     0xa07e54: ldur            x0, [x1, #-1]
    //     0xa07e58: ubfx            x0, x0, #0xc, #0x14
    // 0xa07e5c: stp             x2, x1, [SP, #-0x10]!
    // 0xa07e60: mov             lr, x0
    // 0xa07e64: ldr             lr, [x21, lr, lsl #3]
    // 0xa07e68: blr             lr
    // 0xa07e6c: add             SP, SP, #0x10
    // 0xa07e70: tbnz            w0, #4, #0xa08bb4
    // 0xa07e74: ldur            x3, [fp, #-0x88]
    // 0xa07e78: mov             x0, x3
    // 0xa07e7c: r2 = Null
    //     0xa07e7c: mov             x2, NULL
    // 0xa07e80: r1 = Null
    //     0xa07e80: mov             x1, NULL
    // 0xa07e84: r4 = LoadClassIdInstr(r0)
    //     0xa07e84: ldur            x4, [x0, #-1]
    //     0xa07e88: ubfx            x4, x4, #0xc, #0x14
    // 0xa07e8c: r17 = 4574
    //     0xa07e8c: mov             x17, #0x11de
    // 0xa07e90: cmp             x4, x17
    // 0xa07e94: b.eq            #0xa07ea4
    // 0xa07e98: r8 = DBusObjectPath
    //     0xa07e98: ldr             x8, [PP, #0x7688]  ; [pp+0x7688] Type: DBusObjectPath
    // 0xa07e9c: r3 = Null
    //     0xa07e9c: ldr             x3, [PP, #0x7fd8]  ; [pp+0x7fd8] Null
    // 0xa07ea0: r0 = DBusObjectPath()
    //     0xa07ea0: bl              #0x9fcd54  ; IsType_DBusObjectPath_Stub
    // 0xa07ea4: ldur            x10, [fp, #-0x18]
    // 0xa07ea8: ldur            x9, [fp, #-0x88]
    // 0xa07eac: ldur            x8, [fp, #-0x40]
    // 0xa07eb0: ldur            x7, [fp, #-0x48]
    // 0xa07eb4: ldur            x6, [fp, #-0x50]
    // 0xa07eb8: ldur            x5, [fp, #-0x58]
    // 0xa07ebc: ldur            x4, [fp, #-0x60]
    // 0xa07ec0: ldur            x3, [fp, #-0x68]
    // 0xa07ec4: ldur            x2, [fp, #-0x70]
    // 0xa07ec8: b               #0xa087c4
    // 0xa07ecc: cmp             x0, #2
    // 0xa07ed0: b.ne            #0xa07fc8
    // 0xa07ed4: ldur            x1, [fp, #-0x88]
    // 0xa07ed8: r0 = LoadClassIdInstr(r1)
    //     0xa07ed8: ldur            x0, [x1, #-1]
    //     0xa07edc: ubfx            x0, x0, #0xc, #0x14
    // 0xa07ee0: SaveReg r1
    //     0xa07ee0: str             x1, [SP, #-8]!
    // 0xa07ee4: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa07ee4: add             lr, x0, #0x2b8
    //     0xa07ee8: ldr             lr, [x21, lr, lsl #3]
    //     0xa07eec: blr             lr
    // 0xa07ef0: add             SP, SP, #8
    // 0xa07ef4: stur            x0, [fp, #-0x80]
    // 0xa07ef8: r0 = DBusSignature()
    //     0xa07ef8: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa07efc: stur            x0, [fp, #-0x98]
    // 0xa07f00: r16 = "s"
    //     0xa07f00: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa07f04: stp             x16, x0, [SP, #-0x10]!
    // 0xa07f08: r0 = DBusSignature()
    //     0xa07f08: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa07f0c: add             SP, SP, #0x10
    // 0xa07f10: ldur            x0, [fp, #-0x98]
    // 0xa07f14: LoadField: r1 = r0->field_7
    //     0xa07f14: ldur            w1, [x0, #7]
    // 0xa07f18: DecompressPointer r1
    //     0xa07f18: add             x1, x1, HEAP, lsl #32
    // 0xa07f1c: ldur            x0, [fp, #-0x80]
    // 0xa07f20: LoadField: r2 = r0->field_7
    //     0xa07f20: ldur            w2, [x0, #7]
    // 0xa07f24: DecompressPointer r2
    //     0xa07f24: add             x2, x2, HEAP, lsl #32
    // 0xa07f28: r0 = LoadClassIdInstr(r1)
    //     0xa07f28: ldur            x0, [x1, #-1]
    //     0xa07f2c: ubfx            x0, x0, #0xc, #0x14
    // 0xa07f30: stp             x2, x1, [SP, #-0x10]!
    // 0xa07f34: mov             lr, x0
    // 0xa07f38: ldr             lr, [x21, lr, lsl #3]
    // 0xa07f3c: blr             lr
    // 0xa07f40: add             SP, SP, #0x10
    // 0xa07f44: tbnz            w0, #4, #0xa08c38
    // 0xa07f48: ldur            x3, [fp, #-0x88]
    // 0xa07f4c: mov             x0, x3
    // 0xa07f50: r2 = Null
    //     0xa07f50: mov             x2, NULL
    // 0xa07f54: r1 = Null
    //     0xa07f54: mov             x1, NULL
    // 0xa07f58: r4 = LoadClassIdInstr(r0)
    //     0xa07f58: ldur            x4, [x0, #-1]
    //     0xa07f5c: ubfx            x4, x4, #0xc, #0x14
    // 0xa07f60: r17 = -4573
    //     0xa07f60: mov             x17, #-0x11dd
    // 0xa07f64: add             x4, x4, x17
    // 0xa07f68: cmp             x4, #1
    // 0xa07f6c: b.ls            #0xa07f7c
    // 0xa07f70: r8 = DBusString
    //     0xa07f70: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa07f74: r3 = Null
    //     0xa07f74: ldr             x3, [PP, #0x7fe8]  ; [pp+0x7fe8] Null
    // 0xa07f78: r0 = DefaultTypeTest()
    //     0xa07f78: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa07f7c: ldur            x1, [fp, #-0x88]
    // 0xa07f80: LoadField: r0 = r1->field_7
    //     0xa07f80: ldur            w0, [x1, #7]
    // 0xa07f84: DecompressPointer r0
    //     0xa07f84: add             x0, x0, HEAP, lsl #32
    // 0xa07f88: stur            x0, [fp, #-0x80]
    // 0xa07f8c: r0 = DBusInterfaceName()
    //     0xa07f8c: bl              #0xa023bc  ; AllocateDBusInterfaceNameStub -> DBusInterfaceName (size=0xc)
    // 0xa07f90: stur            x0, [fp, #-0x98]
    // 0xa07f94: ldur            x16, [fp, #-0x80]
    // 0xa07f98: stp             x16, x0, [SP, #-0x10]!
    // 0xa07f9c: r0 = DBusInterfaceName()
    //     0xa07f9c: bl              #0xa0212c  ; [package:dbus/src/dbus_interface_name.dart] DBusInterfaceName::DBusInterfaceName
    // 0xa07fa0: add             SP, SP, #0x10
    // 0xa07fa4: ldur            x10, [fp, #-0x18]
    // 0xa07fa8: ldur            x8, [fp, #-0x98]
    // 0xa07fac: ldur            x7, [fp, #-0x48]
    // 0xa07fb0: ldur            x6, [fp, #-0x50]
    // 0xa07fb4: ldur            x5, [fp, #-0x58]
    // 0xa07fb8: ldur            x4, [fp, #-0x60]
    // 0xa07fbc: ldur            x1, [fp, #-0x68]
    // 0xa07fc0: ldur            x0, [fp, #-0x70]
    // 0xa07fc4: b               #0xa087b8
    // 0xa07fc8: ldur            x1, [fp, #-0x88]
    // 0xa07fcc: cmp             x0, #3
    // 0xa07fd0: b.ne            #0xa080c0
    // 0xa07fd4: r0 = LoadClassIdInstr(r1)
    //     0xa07fd4: ldur            x0, [x1, #-1]
    //     0xa07fd8: ubfx            x0, x0, #0xc, #0x14
    // 0xa07fdc: SaveReg r1
    //     0xa07fdc: str             x1, [SP, #-8]!
    // 0xa07fe0: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa07fe0: add             lr, x0, #0x2b8
    //     0xa07fe4: ldr             lr, [x21, lr, lsl #3]
    //     0xa07fe8: blr             lr
    // 0xa07fec: add             SP, SP, #8
    // 0xa07ff0: stur            x0, [fp, #-0x80]
    // 0xa07ff4: r0 = DBusSignature()
    //     0xa07ff4: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa07ff8: stur            x0, [fp, #-0x98]
    // 0xa07ffc: r16 = "s"
    //     0xa07ffc: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa08000: stp             x16, x0, [SP, #-0x10]!
    // 0xa08004: r0 = DBusSignature()
    //     0xa08004: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa08008: add             SP, SP, #0x10
    // 0xa0800c: ldur            x0, [fp, #-0x98]
    // 0xa08010: LoadField: r1 = r0->field_7
    //     0xa08010: ldur            w1, [x0, #7]
    // 0xa08014: DecompressPointer r1
    //     0xa08014: add             x1, x1, HEAP, lsl #32
    // 0xa08018: ldur            x0, [fp, #-0x80]
    // 0xa0801c: LoadField: r2 = r0->field_7
    //     0xa0801c: ldur            w2, [x0, #7]
    // 0xa08020: DecompressPointer r2
    //     0xa08020: add             x2, x2, HEAP, lsl #32
    // 0xa08024: r0 = LoadClassIdInstr(r1)
    //     0xa08024: ldur            x0, [x1, #-1]
    //     0xa08028: ubfx            x0, x0, #0xc, #0x14
    // 0xa0802c: stp             x2, x1, [SP, #-0x10]!
    // 0xa08030: mov             lr, x0
    // 0xa08034: ldr             lr, [x21, lr, lsl #3]
    // 0xa08038: blr             lr
    // 0xa0803c: add             SP, SP, #0x10
    // 0xa08040: tbnz            w0, #4, #0xa08cbc
    // 0xa08044: ldur            x3, [fp, #-0x88]
    // 0xa08048: mov             x0, x3
    // 0xa0804c: r2 = Null
    //     0xa0804c: mov             x2, NULL
    // 0xa08050: r1 = Null
    //     0xa08050: mov             x1, NULL
    // 0xa08054: r4 = LoadClassIdInstr(r0)
    //     0xa08054: ldur            x4, [x0, #-1]
    //     0xa08058: ubfx            x4, x4, #0xc, #0x14
    // 0xa0805c: r17 = -4573
    //     0xa0805c: mov             x17, #-0x11dd
    // 0xa08060: add             x4, x4, x17
    // 0xa08064: cmp             x4, #1
    // 0xa08068: b.ls            #0xa08078
    // 0xa0806c: r8 = DBusString
    //     0xa0806c: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa08070: r3 = Null
    //     0xa08070: ldr             x3, [PP, #0x7ff8]  ; [pp+0x7ff8] Null
    // 0xa08074: r0 = DefaultTypeTest()
    //     0xa08074: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa08078: ldur            x1, [fp, #-0x88]
    // 0xa0807c: LoadField: r0 = r1->field_7
    //     0xa0807c: ldur            w0, [x1, #7]
    // 0xa08080: DecompressPointer r0
    //     0xa08080: add             x0, x0, HEAP, lsl #32
    // 0xa08084: stur            x0, [fp, #-0x80]
    // 0xa08088: r0 = DBusMemberName()
    //     0xa08088: bl              #0xa02120  ; AllocateDBusMemberNameStub -> DBusMemberName (size=0xc)
    // 0xa0808c: stur            x0, [fp, #-0x98]
    // 0xa08090: ldur            x16, [fp, #-0x80]
    // 0xa08094: stp             x16, x0, [SP, #-0x10]!
    // 0xa08098: r0 = DBusMemberName()
    //     0xa08098: bl              #0xa0201c  ; [package:dbus/src/dbus_member_name.dart] DBusMemberName::DBusMemberName
    // 0xa0809c: add             SP, SP, #0x10
    // 0xa080a0: ldur            x10, [fp, #-0x18]
    // 0xa080a4: ldur            x7, [fp, #-0x98]
    // 0xa080a8: ldur            x6, [fp, #-0x50]
    // 0xa080ac: ldur            x5, [fp, #-0x58]
    // 0xa080b0: ldur            x4, [fp, #-0x60]
    // 0xa080b4: ldur            x1, [fp, #-0x68]
    // 0xa080b8: ldur            x0, [fp, #-0x70]
    // 0xa080bc: b               #0xa087b4
    // 0xa080c0: cmp             x0, #4
    // 0xa080c4: b.ne            #0xa08380
    // 0xa080c8: r0 = LoadClassIdInstr(r1)
    //     0xa080c8: ldur            x0, [x1, #-1]
    //     0xa080cc: ubfx            x0, x0, #0xc, #0x14
    // 0xa080d0: SaveReg r1
    //     0xa080d0: str             x1, [SP, #-8]!
    // 0xa080d4: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa080d4: add             lr, x0, #0x2b8
    //     0xa080d8: ldr             lr, [x21, lr, lsl #3]
    //     0xa080dc: blr             lr
    // 0xa080e0: add             SP, SP, #8
    // 0xa080e4: stur            x0, [fp, #-0x80]
    // 0xa080e8: r0 = DBusSignature()
    //     0xa080e8: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa080ec: stur            x0, [fp, #-0x98]
    // 0xa080f0: r16 = "s"
    //     0xa080f0: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa080f4: stp             x16, x0, [SP, #-0x10]!
    // 0xa080f8: r0 = DBusSignature()
    //     0xa080f8: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa080fc: add             SP, SP, #0x10
    // 0xa08100: ldur            x0, [fp, #-0x98]
    // 0xa08104: LoadField: r1 = r0->field_7
    //     0xa08104: ldur            w1, [x0, #7]
    // 0xa08108: DecompressPointer r1
    //     0xa08108: add             x1, x1, HEAP, lsl #32
    // 0xa0810c: ldur            x0, [fp, #-0x80]
    // 0xa08110: LoadField: r2 = r0->field_7
    //     0xa08110: ldur            w2, [x0, #7]
    // 0xa08114: DecompressPointer r2
    //     0xa08114: add             x2, x2, HEAP, lsl #32
    // 0xa08118: r0 = LoadClassIdInstr(r1)
    //     0xa08118: ldur            x0, [x1, #-1]
    //     0xa0811c: ubfx            x0, x0, #0xc, #0x14
    // 0xa08120: stp             x2, x1, [SP, #-0x10]!
    // 0xa08124: mov             lr, x0
    // 0xa08128: ldr             lr, [x21, lr, lsl #3]
    // 0xa0812c: blr             lr
    // 0xa08130: add             SP, SP, #0x10
    // 0xa08134: tbnz            w0, #4, #0xa08d40
    // 0xa08138: ldur            x3, [fp, #-0x88]
    // 0xa0813c: mov             x0, x3
    // 0xa08140: r2 = Null
    //     0xa08140: mov             x2, NULL
    // 0xa08144: r1 = Null
    //     0xa08144: mov             x1, NULL
    // 0xa08148: r4 = LoadClassIdInstr(r0)
    //     0xa08148: ldur            x4, [x0, #-1]
    //     0xa0814c: ubfx            x4, x4, #0xc, #0x14
    // 0xa08150: r17 = -4573
    //     0xa08150: mov             x17, #-0x11dd
    // 0xa08154: add             x4, x4, x17
    // 0xa08158: cmp             x4, #1
    // 0xa0815c: b.ls            #0xa08170
    // 0xa08160: r8 = DBusString
    //     0xa08160: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa08164: r3 = Null
    //     0xa08164: add             x3, PP, #8, lsl #12  ; [pp+0x8008] Null
    //     0xa08168: ldr             x3, [x3, #8]
    // 0xa0816c: r0 = DefaultTypeTest()
    //     0xa0816c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa08170: ldur            x1, [fp, #-0x88]
    // 0xa08174: LoadField: r0 = r1->field_7
    //     0xa08174: ldur            w0, [x1, #7]
    // 0xa08178: DecompressPointer r0
    //     0xa08178: add             x0, x0, HEAP, lsl #32
    // 0xa0817c: stur            x0, [fp, #-0x80]
    // 0xa08180: r0 = DBusErrorName()
    //     0xa08180: bl              #0xa05ee0  ; AllocateDBusErrorNameStub -> DBusErrorName (size=0xc)
    // 0xa08184: mov             x2, x0
    // 0xa08188: ldur            x1, [fp, #-0x80]
    // 0xa0818c: stur            x2, [fp, #-0x98]
    // 0xa08190: StoreField: r2->field_7 = r1
    //     0xa08190: stur            w1, [x2, #7]
    // 0xa08194: LoadField: r0 = r1->field_7
    //     0xa08194: ldur            w0, [x1, #7]
    // 0xa08198: DecompressPointer r0
    //     0xa08198: add             x0, x0, HEAP, lsl #32
    // 0xa0819c: r3 = LoadInt32Instr(r0)
    //     0xa0819c: sbfx            x3, x0, #1, #0x1f
    // 0xa081a0: cmp             x3, #0xff
    // 0xa081a4: b.gt            #0xa08dc4
    // 0xa081a8: r3 = "Error name too long"
    //     0xa081a8: ldr             x3, [PP, #0x7cc8]  ; [pp+0x7cc8] "Error name too long"
    // 0xa081ac: r0 = LoadClassIdInstr(r1)
    //     0xa081ac: ldur            x0, [x1, #-1]
    //     0xa081b0: ubfx            x0, x0, #0xc, #0x14
    // 0xa081b4: r16 = "."
    //     0xa081b4: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xa081b8: stp             x16, x1, [SP, #-0x10]!
    // 0xa081bc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa081bc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa081c0: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa081c0: sub             lr, x0, #0xffc
    //     0xa081c4: ldr             lr, [x21, lr, lsl #3]
    //     0xa081c8: blr             lr
    // 0xa081cc: add             SP, SP, #0x10
    // 0xa081d0: tbnz            w0, #4, #0xa08dd8
    // 0xa081d4: ldur            x0, [fp, #-0x80]
    // 0xa081d8: r1 = "Error name needs at least two elements"
    //     0xa081d8: ldr             x1, [PP, #0x7cd0]  ; [pp+0x7cd0] "Error name needs at least two elements"
    // 0xa081dc: r2 = LoadClassIdInstr(r0)
    //     0xa081dc: ldur            x2, [x0, #-1]
    //     0xa081e0: ubfx            x2, x2, #0xc, #0x14
    // 0xa081e4: r16 = "."
    //     0xa081e4: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xa081e8: stp             x16, x0, [SP, #-0x10]!
    // 0xa081ec: mov             x0, x2
    // 0xa081f0: r0 = GDT[cid_x0 + -0xff8]()
    //     0xa081f0: sub             lr, x0, #0xff8
    //     0xa081f4: ldr             lr, [x21, lr, lsl #3]
    //     0xa081f8: blr             lr
    // 0xa081fc: add             SP, SP, #0x10
    // 0xa08200: mov             x1, x0
    // 0xa08204: stur            x1, [fp, #-0xb0]
    // 0xa08208: LoadField: r2 = r1->field_7
    //     0xa08208: ldur            w2, [x1, #7]
    // 0xa0820c: DecompressPointer r2
    //     0xa0820c: add             x2, x2, HEAP, lsl #32
    // 0xa08210: stur            x2, [fp, #-0x80]
    // 0xa08214: LoadField: r0 = r1->field_b
    //     0xa08214: ldur            w0, [x1, #0xb]
    // 0xa08218: DecompressPointer r0
    //     0xa08218: add             x0, x0, HEAP, lsl #32
    // 0xa0821c: r3 = LoadInt32Instr(r0)
    //     0xa0821c: sbfx            x3, x0, #1, #0x1f
    // 0xa08220: stur            x3, [fp, #-0xa8]
    // 0xa08224: r4 = 0
    //     0xa08224: mov             x4, #0
    // 0xa08228: stur            x4, [fp, #-0xa0]
    // 0xa0822c: CheckStackOverflow
    //     0xa0822c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa08230: cmp             SP, x16
    //     0xa08234: b.ls            #0xa091b4
    // 0xa08238: r0 = LoadClassIdInstr(r1)
    //     0xa08238: ldur            x0, [x1, #-1]
    //     0xa0823c: ubfx            x0, x0, #0xc, #0x14
    // 0xa08240: SaveReg r1
    //     0xa08240: str             x1, [SP, #-8]!
    // 0xa08244: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa08244: mov             x17, #0xb8ea
    //     0xa08248: add             lr, x0, x17
    //     0xa0824c: ldr             lr, [x21, lr, lsl #3]
    //     0xa08250: blr             lr
    // 0xa08254: add             SP, SP, #8
    // 0xa08258: r1 = LoadInt32Instr(r0)
    //     0xa08258: sbfx            x1, x0, #1, #0x1f
    //     0xa0825c: tbz             w0, #0, #0xa08264
    //     0xa08260: ldur            x1, [x0, #7]
    // 0xa08264: ldur            x2, [fp, #-0xa8]
    // 0xa08268: cmp             x2, x1
    // 0xa0826c: b.ne            #0xa08dec
    // 0xa08270: ldur            x3, [fp, #-0xb0]
    // 0xa08274: ldur            x4, [fp, #-0xa0]
    // 0xa08278: cmp             x4, x1
    // 0xa0827c: b.lt            #0xa0829c
    // 0xa08280: ldur            x10, [fp, #-0x18]
    // 0xa08284: ldur            x6, [fp, #-0x98]
    // 0xa08288: ldur            x5, [fp, #-0x58]
    // 0xa0828c: ldur            x4, [fp, #-0x60]
    // 0xa08290: ldur            x1, [fp, #-0x68]
    // 0xa08294: ldur            x0, [fp, #-0x70]
    // 0xa08298: b               #0xa087b0
    // 0xa0829c: r0 = BoxInt64Instr(r4)
    //     0xa0829c: sbfiz           x0, x4, #1, #0x1f
    //     0xa082a0: cmp             x4, x0, asr #1
    //     0xa082a4: b.eq            #0xa082b0
    //     0xa082a8: bl              #0xd69bb8
    //     0xa082ac: stur            x4, [x0, #7]
    // 0xa082b0: r1 = LoadClassIdInstr(r3)
    //     0xa082b0: ldur            x1, [x3, #-1]
    //     0xa082b4: ubfx            x1, x1, #0xc, #0x14
    // 0xa082b8: stp             x0, x3, [SP, #-0x10]!
    // 0xa082bc: mov             x0, x1
    // 0xa082c0: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa082c0: mov             x17, #0xd175
    //     0xa082c4: add             lr, x0, x17
    //     0xa082c8: ldr             lr, [x21, lr, lsl #3]
    //     0xa082cc: blr             lr
    // 0xa082d0: add             SP, SP, #0x10
    // 0xa082d4: mov             x3, x0
    // 0xa082d8: ldur            x0, [fp, #-0xa0]
    // 0xa082dc: stur            x3, [fp, #-0xc0]
    // 0xa082e0: add             x4, x0, #1
    // 0xa082e4: stur            x4, [fp, #-0xb8]
    // 0xa082e8: cmp             w3, NULL
    // 0xa082ec: b.ne            #0xa08320
    // 0xa082f0: mov             x0, x3
    // 0xa082f4: ldur            x2, [fp, #-0x80]
    // 0xa082f8: r1 = Null
    //     0xa082f8: mov             x1, NULL
    // 0xa082fc: cmp             w2, NULL
    // 0xa08300: b.eq            #0xa08320
    // 0xa08304: LoadField: r4 = r2->field_17
    //     0xa08304: ldur            w4, [x2, #0x17]
    // 0xa08308: DecompressPointer r4
    //     0xa08308: add             x4, x4, HEAP, lsl #32
    // 0xa0830c: r8 = X0
    //     0xa0830c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa08310: LoadField: r9 = r4->field_7
    //     0xa08310: ldur            x9, [x4, #7]
    // 0xa08314: r3 = Null
    //     0xa08314: add             x3, PP, #8, lsl #12  ; [pp+0x8018] Null
    //     0xa08318: ldr             x3, [x3, #0x18]
    // 0xa0831c: blr             x9
    // 0xa08320: ldur            x0, [fp, #-0xc0]
    // 0xa08324: r16 = "^[a-zA-Z_][0-9a-zA-Z_]+$"
    //     0xa08324: ldr             x16, [PP, #0x6d8]  ; [pp+0x6d8] "^[a-zA-Z_][0-9a-zA-Z_]+$"
    // 0xa08328: stp             x16, NULL, [SP, #-0x10]!
    // 0xa0832c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0832c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa08330: r0 = RegExp()
    //     0xa08330: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0xa08334: add             SP, SP, #0x10
    // 0xa08338: mov             x1, x0
    // 0xa0833c: ldur            x0, [fp, #-0xc0]
    // 0xa08340: r2 = LoadClassIdInstr(r0)
    //     0xa08340: ldur            x2, [x0, #-1]
    //     0xa08344: ubfx            x2, x2, #0xc, #0x14
    // 0xa08348: stp             x1, x0, [SP, #-0x10]!
    // 0xa0834c: mov             x0, x2
    // 0xa08350: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa08350: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa08354: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa08354: sub             lr, x0, #0xffc
    //     0xa08358: ldr             lr, [x21, lr, lsl #3]
    //     0xa0835c: blr             lr
    // 0xa08360: add             SP, SP, #0x10
    // 0xa08364: tbnz            w0, #4, #0xa08e04
    // 0xa08368: r2 = "Invalid element in error name"
    //     0xa08368: ldr             x2, [PP, #0x7cc0]  ; [pp+0x7cc0] "Invalid element in error name"
    // 0xa0836c: ldur            x4, [fp, #-0xb8]
    // 0xa08370: ldur            x1, [fp, #-0xb0]
    // 0xa08374: ldur            x2, [fp, #-0x80]
    // 0xa08378: ldur            x3, [fp, #-0xa8]
    // 0xa0837c: b               #0xa08228
    // 0xa08380: r2 = "Invalid element in error name"
    //     0xa08380: ldr             x2, [PP, #0x7cc0]  ; [pp+0x7cc0] "Invalid element in error name"
    // 0xa08384: cmp             x0, #5
    // 0xa08388: b.ne            #0xa08468
    // 0xa0838c: r0 = LoadClassIdInstr(r1)
    //     0xa0838c: ldur            x0, [x1, #-1]
    //     0xa08390: ubfx            x0, x0, #0xc, #0x14
    // 0xa08394: SaveReg r1
    //     0xa08394: str             x1, [SP, #-8]!
    // 0xa08398: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa08398: add             lr, x0, #0x2b8
    //     0xa0839c: ldr             lr, [x21, lr, lsl #3]
    //     0xa083a0: blr             lr
    // 0xa083a4: add             SP, SP, #8
    // 0xa083a8: stur            x0, [fp, #-0x80]
    // 0xa083ac: r0 = DBusSignature()
    //     0xa083ac: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa083b0: stur            x0, [fp, #-0x98]
    // 0xa083b4: r16 = "u"
    //     0xa083b4: ldr             x16, [PP, #0x78f8]  ; [pp+0x78f8] "u"
    // 0xa083b8: stp             x16, x0, [SP, #-0x10]!
    // 0xa083bc: r0 = DBusSignature()
    //     0xa083bc: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa083c0: add             SP, SP, #0x10
    // 0xa083c4: ldur            x0, [fp, #-0x98]
    // 0xa083c8: LoadField: r1 = r0->field_7
    //     0xa083c8: ldur            w1, [x0, #7]
    // 0xa083cc: DecompressPointer r1
    //     0xa083cc: add             x1, x1, HEAP, lsl #32
    // 0xa083d0: ldur            x0, [fp, #-0x80]
    // 0xa083d4: LoadField: r2 = r0->field_7
    //     0xa083d4: ldur            w2, [x0, #7]
    // 0xa083d8: DecompressPointer r2
    //     0xa083d8: add             x2, x2, HEAP, lsl #32
    // 0xa083dc: r0 = LoadClassIdInstr(r1)
    //     0xa083dc: ldur            x0, [x1, #-1]
    //     0xa083e0: ubfx            x0, x0, #0xc, #0x14
    // 0xa083e4: stp             x2, x1, [SP, #-0x10]!
    // 0xa083e8: mov             lr, x0
    // 0xa083ec: ldr             lr, [x21, lr, lsl #3]
    // 0xa083f0: blr             lr
    // 0xa083f4: add             SP, SP, #0x10
    // 0xa083f8: tbnz            w0, #4, #0xa08e18
    // 0xa083fc: ldur            x3, [fp, #-0x88]
    // 0xa08400: mov             x0, x3
    // 0xa08404: r2 = Null
    //     0xa08404: mov             x2, NULL
    // 0xa08408: r1 = Null
    //     0xa08408: mov             x1, NULL
    // 0xa0840c: r4 = LoadClassIdInstr(r0)
    //     0xa0840c: ldur            x4, [x0, #-1]
    //     0xa08410: ubfx            x4, x4, #0xc, #0x14
    // 0xa08414: r17 = 4578
    //     0xa08414: mov             x17, #0x11e2
    // 0xa08418: cmp             x4, x17
    // 0xa0841c: b.eq            #0xa08434
    // 0xa08420: r8 = DBusUint32
    //     0xa08420: add             x8, PP, #8, lsl #12  ; [pp+0x8028] Type: DBusUint32
    //     0xa08424: ldr             x8, [x8, #0x28]
    // 0xa08428: r3 = Null
    //     0xa08428: add             x3, PP, #8, lsl #12  ; [pp+0x8030] Null
    //     0xa0842c: ldr             x3, [x3, #0x30]
    // 0xa08430: r0 = DefaultTypeTest()
    //     0xa08430: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa08434: ldur            x1, [fp, #-0x88]
    // 0xa08438: LoadField: r2 = r1->field_7
    //     0xa08438: ldur            x2, [x1, #7]
    // 0xa0843c: r0 = BoxInt64Instr(r2)
    //     0xa0843c: sbfiz           x0, x2, #1, #0x1f
    //     0xa08440: cmp             x2, x0, asr #1
    //     0xa08444: b.eq            #0xa08450
    //     0xa08448: bl              #0xd69bb8
    //     0xa0844c: stur            x2, [x0, #7]
    // 0xa08450: ldur            x10, [fp, #-0x18]
    // 0xa08454: mov             x5, x0
    // 0xa08458: ldur            x4, [fp, #-0x60]
    // 0xa0845c: ldur            x1, [fp, #-0x68]
    // 0xa08460: ldur            x0, [fp, #-0x70]
    // 0xa08464: b               #0xa087ac
    // 0xa08468: cmp             x0, #6
    // 0xa0846c: b.ne            #0xa08554
    // 0xa08470: r0 = LoadClassIdInstr(r1)
    //     0xa08470: ldur            x0, [x1, #-1]
    //     0xa08474: ubfx            x0, x0, #0xc, #0x14
    // 0xa08478: SaveReg r1
    //     0xa08478: str             x1, [SP, #-8]!
    // 0xa0847c: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa0847c: add             lr, x0, #0x2b8
    //     0xa08480: ldr             lr, [x21, lr, lsl #3]
    //     0xa08484: blr             lr
    // 0xa08488: add             SP, SP, #8
    // 0xa0848c: stur            x0, [fp, #-0x80]
    // 0xa08490: r0 = DBusSignature()
    //     0xa08490: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa08494: stur            x0, [fp, #-0x98]
    // 0xa08498: r16 = "s"
    //     0xa08498: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa0849c: stp             x16, x0, [SP, #-0x10]!
    // 0xa084a0: r0 = DBusSignature()
    //     0xa084a0: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa084a4: add             SP, SP, #0x10
    // 0xa084a8: ldur            x0, [fp, #-0x98]
    // 0xa084ac: LoadField: r1 = r0->field_7
    //     0xa084ac: ldur            w1, [x0, #7]
    // 0xa084b0: DecompressPointer r1
    //     0xa084b0: add             x1, x1, HEAP, lsl #32
    // 0xa084b4: ldur            x0, [fp, #-0x80]
    // 0xa084b8: LoadField: r2 = r0->field_7
    //     0xa084b8: ldur            w2, [x0, #7]
    // 0xa084bc: DecompressPointer r2
    //     0xa084bc: add             x2, x2, HEAP, lsl #32
    // 0xa084c0: r0 = LoadClassIdInstr(r1)
    //     0xa084c0: ldur            x0, [x1, #-1]
    //     0xa084c4: ubfx            x0, x0, #0xc, #0x14
    // 0xa084c8: stp             x2, x1, [SP, #-0x10]!
    // 0xa084cc: mov             lr, x0
    // 0xa084d0: ldr             lr, [x21, lr, lsl #3]
    // 0xa084d4: blr             lr
    // 0xa084d8: add             SP, SP, #0x10
    // 0xa084dc: tbnz            w0, #4, #0xa08e9c
    // 0xa084e0: ldur            x3, [fp, #-0x88]
    // 0xa084e4: mov             x0, x3
    // 0xa084e8: r2 = Null
    //     0xa084e8: mov             x2, NULL
    // 0xa084ec: r1 = Null
    //     0xa084ec: mov             x1, NULL
    // 0xa084f0: r4 = LoadClassIdInstr(r0)
    //     0xa084f0: ldur            x4, [x0, #-1]
    //     0xa084f4: ubfx            x4, x4, #0xc, #0x14
    // 0xa084f8: r17 = -4573
    //     0xa084f8: mov             x17, #-0x11dd
    // 0xa084fc: add             x4, x4, x17
    // 0xa08500: cmp             x4, #1
    // 0xa08504: b.ls            #0xa08518
    // 0xa08508: r8 = DBusString
    //     0xa08508: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa0850c: r3 = Null
    //     0xa0850c: add             x3, PP, #8, lsl #12  ; [pp+0x8040] Null
    //     0xa08510: ldr             x3, [x3, #0x40]
    // 0xa08514: r0 = DefaultTypeTest()
    //     0xa08514: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa08518: ldur            x1, [fp, #-0x88]
    // 0xa0851c: LoadField: r0 = r1->field_7
    //     0xa0851c: ldur            w0, [x1, #7]
    // 0xa08520: DecompressPointer r0
    //     0xa08520: add             x0, x0, HEAP, lsl #32
    // 0xa08524: stur            x0, [fp, #-0x80]
    // 0xa08528: r0 = DBusBusName()
    //     0xa08528: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0xa0852c: stur            x0, [fp, #-0x98]
    // 0xa08530: ldur            x16, [fp, #-0x80]
    // 0xa08534: stp             x16, x0, [SP, #-0x10]!
    // 0xa08538: r0 = DBusBusName()
    //     0xa08538: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0xa0853c: add             SP, SP, #0x10
    // 0xa08540: ldur            x10, [fp, #-0x18]
    // 0xa08544: ldur            x4, [fp, #-0x98]
    // 0xa08548: ldur            x1, [fp, #-0x68]
    // 0xa0854c: ldur            x0, [fp, #-0x70]
    // 0xa08550: b               #0xa087a8
    // 0xa08554: cmp             x0, #7
    // 0xa08558: b.ne            #0xa0868c
    // 0xa0855c: r0 = LoadClassIdInstr(r1)
    //     0xa0855c: ldur            x0, [x1, #-1]
    //     0xa08560: ubfx            x0, x0, #0xc, #0x14
    // 0xa08564: SaveReg r1
    //     0xa08564: str             x1, [SP, #-8]!
    // 0xa08568: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa08568: add             lr, x0, #0x2b8
    //     0xa0856c: ldr             lr, [x21, lr, lsl #3]
    //     0xa08570: blr             lr
    // 0xa08574: add             SP, SP, #8
    // 0xa08578: stur            x0, [fp, #-0x80]
    // 0xa0857c: r0 = DBusSignature()
    //     0xa0857c: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa08580: stur            x0, [fp, #-0x98]
    // 0xa08584: r16 = "s"
    //     0xa08584: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa08588: stp             x16, x0, [SP, #-0x10]!
    // 0xa0858c: r0 = DBusSignature()
    //     0xa0858c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa08590: add             SP, SP, #0x10
    // 0xa08594: ldur            x0, [fp, #-0x98]
    // 0xa08598: LoadField: r1 = r0->field_7
    //     0xa08598: ldur            w1, [x0, #7]
    // 0xa0859c: DecompressPointer r1
    //     0xa0859c: add             x1, x1, HEAP, lsl #32
    // 0xa085a0: ldur            x0, [fp, #-0x80]
    // 0xa085a4: LoadField: r2 = r0->field_7
    //     0xa085a4: ldur            w2, [x0, #7]
    // 0xa085a8: DecompressPointer r2
    //     0xa085a8: add             x2, x2, HEAP, lsl #32
    // 0xa085ac: r0 = LoadClassIdInstr(r1)
    //     0xa085ac: ldur            x0, [x1, #-1]
    //     0xa085b0: ubfx            x0, x0, #0xc, #0x14
    // 0xa085b4: stp             x2, x1, [SP, #-0x10]!
    // 0xa085b8: mov             lr, x0
    // 0xa085bc: ldr             lr, [x21, lr, lsl #3]
    // 0xa085c0: blr             lr
    // 0xa085c4: add             SP, SP, #0x10
    // 0xa085c8: tbnz            w0, #4, #0xa08f20
    // 0xa085cc: ldur            x3, [fp, #-0x88]
    // 0xa085d0: mov             x0, x3
    // 0xa085d4: r2 = Null
    //     0xa085d4: mov             x2, NULL
    // 0xa085d8: r1 = Null
    //     0xa085d8: mov             x1, NULL
    // 0xa085dc: r4 = LoadClassIdInstr(r0)
    //     0xa085dc: ldur            x4, [x0, #-1]
    //     0xa085e0: ubfx            x4, x4, #0xc, #0x14
    // 0xa085e4: r17 = -4573
    //     0xa085e4: mov             x17, #-0x11dd
    // 0xa085e8: add             x4, x4, x17
    // 0xa085ec: cmp             x4, #1
    // 0xa085f0: b.ls            #0xa08604
    // 0xa085f4: r8 = DBusString
    //     0xa085f4: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa085f8: r3 = Null
    //     0xa085f8: add             x3, PP, #8, lsl #12  ; [pp+0x8050] Null
    //     0xa085fc: ldr             x3, [x3, #0x50]
    // 0xa08600: r0 = DefaultTypeTest()
    //     0xa08600: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa08604: ldur            x1, [fp, #-0x88]
    // 0xa08608: LoadField: r0 = r1->field_7
    //     0xa08608: ldur            w0, [x1, #7]
    // 0xa0860c: DecompressPointer r0
    //     0xa0860c: add             x0, x0, HEAP, lsl #32
    // 0xa08610: stur            x0, [fp, #-0x80]
    // 0xa08614: r0 = DBusBusName()
    //     0xa08614: bl              #0xa02718  ; AllocateDBusBusNameStub -> DBusBusName (size=0xc)
    // 0xa08618: stur            x0, [fp, #-0x98]
    // 0xa0861c: ldur            x16, [fp, #-0x80]
    // 0xa08620: stp             x16, x0, [SP, #-0x10]!
    // 0xa08624: r0 = DBusBusName()
    //     0xa08624: bl              #0xa023c8  ; [package:dbus/src/dbus_bus_name.dart] DBusBusName::DBusBusName
    // 0xa08628: add             SP, SP, #0x10
    // 0xa0862c: ldur            x1, [fp, #-0x98]
    // 0xa08630: LoadField: r2 = r1->field_7
    //     0xa08630: ldur            w2, [x1, #7]
    // 0xa08634: DecompressPointer r2
    //     0xa08634: add             x2, x2, HEAP, lsl #32
    // 0xa08638: stur            x2, [fp, #-0x80]
    // 0xa0863c: r0 = LoadClassIdInstr(r2)
    //     0xa0863c: ldur            x0, [x2, #-1]
    //     0xa08640: ubfx            x0, x0, #0xc, #0x14
    // 0xa08644: r16 = "org.freedesktop.DBus"
    //     0xa08644: ldr             x16, [PP, #0x7700]  ; [pp+0x7700] "org.freedesktop.DBus"
    // 0xa08648: stp             x16, x2, [SP, #-0x10]!
    // 0xa0864c: mov             lr, x0
    // 0xa08650: ldr             lr, [x21, lr, lsl #3]
    // 0xa08654: blr             lr
    // 0xa08658: add             SP, SP, #0x10
    // 0xa0865c: tbz             w0, #4, #0xa0867c
    // 0xa08660: ldur            x16, [fp, #-0x80]
    // 0xa08664: r30 = ":"
    //     0xa08664: ldr             lr, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0xa08668: stp             lr, x16, [SP, #-0x10]!
    // 0xa0866c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0866c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa08670: r0 = startsWith()
    //     0xa08670: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0xa08674: add             SP, SP, #0x10
    // 0xa08678: tbnz            w0, #4, #0xa08fa4
    // 0xa0867c: ldur            x10, [fp, #-0x18]
    // 0xa08680: ldur            x1, [fp, #-0x98]
    // 0xa08684: ldur            x0, [fp, #-0x70]
    // 0xa08688: b               #0xa087a4
    // 0xa0868c: cmp             x0, #8
    // 0xa08690: b.ne            #0xa08744
    // 0xa08694: r0 = LoadClassIdInstr(r1)
    //     0xa08694: ldur            x0, [x1, #-1]
    //     0xa08698: ubfx            x0, x0, #0xc, #0x14
    // 0xa0869c: SaveReg r1
    //     0xa0869c: str             x1, [SP, #-8]!
    // 0xa086a0: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa086a0: add             lr, x0, #0x2b8
    //     0xa086a4: ldr             lr, [x21, lr, lsl #3]
    //     0xa086a8: blr             lr
    // 0xa086ac: add             SP, SP, #8
    // 0xa086b0: stur            x0, [fp, #-0x80]
    // 0xa086b4: r0 = DBusSignature()
    //     0xa086b4: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa086b8: stur            x0, [fp, #-0x98]
    // 0xa086bc: r16 = "g"
    //     0xa086bc: ldr             x16, [PP, #0x76a0]  ; [pp+0x76a0] "g"
    // 0xa086c0: stp             x16, x0, [SP, #-0x10]!
    // 0xa086c4: r0 = DBusSignature()
    //     0xa086c4: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa086c8: add             SP, SP, #0x10
    // 0xa086cc: ldur            x0, [fp, #-0x98]
    // 0xa086d0: LoadField: r1 = r0->field_7
    //     0xa086d0: ldur            w1, [x0, #7]
    // 0xa086d4: DecompressPointer r1
    //     0xa086d4: add             x1, x1, HEAP, lsl #32
    // 0xa086d8: ldur            x0, [fp, #-0x80]
    // 0xa086dc: LoadField: r2 = r0->field_7
    //     0xa086dc: ldur            w2, [x0, #7]
    // 0xa086e0: DecompressPointer r2
    //     0xa086e0: add             x2, x2, HEAP, lsl #32
    // 0xa086e4: r0 = LoadClassIdInstr(r1)
    //     0xa086e4: ldur            x0, [x1, #-1]
    //     0xa086e8: ubfx            x0, x0, #0xc, #0x14
    // 0xa086ec: stp             x2, x1, [SP, #-0x10]!
    // 0xa086f0: mov             lr, x0
    // 0xa086f4: ldr             lr, [x21, lr, lsl #3]
    // 0xa086f8: blr             lr
    // 0xa086fc: add             SP, SP, #0x10
    // 0xa08700: tbnz            w0, #4, #0xa08fb4
    // 0xa08704: ldur            x3, [fp, #-0x88]
    // 0xa08708: mov             x0, x3
    // 0xa0870c: r2 = Null
    //     0xa0870c: mov             x2, NULL
    // 0xa08710: r1 = Null
    //     0xa08710: mov             x1, NULL
    // 0xa08714: r4 = LoadClassIdInstr(r0)
    //     0xa08714: ldur            x4, [x0, #-1]
    //     0xa08718: ubfx            x4, x4, #0xc, #0x14
    // 0xa0871c: r17 = 4572
    //     0xa0871c: mov             x17, #0x11dc
    // 0xa08720: cmp             x4, x17
    // 0xa08724: b.eq            #0xa08738
    // 0xa08728: r8 = DBusSignature
    //     0xa08728: ldr             x8, [PP, #0x7698]  ; [pp+0x7698] Type: DBusSignature
    // 0xa0872c: r3 = Null
    //     0xa0872c: add             x3, PP, #8, lsl #12  ; [pp+0x8060] Null
    //     0xa08730: ldr             x3, [x3, #0x60]
    // 0xa08734: r0 = DBusSignature()
    //     0xa08734: bl              #0x9fd418  ; IsType_DBusSignature_Stub
    // 0xa08738: ldur            x1, [fp, #-0x88]
    // 0xa0873c: ldur            x0, [fp, #-0x70]
    // 0xa08740: b               #0xa0879c
    // 0xa08744: cmp             x0, #9
    // 0xa08748: b.ne            #0xa08794
    // 0xa0874c: ldur            x3, [fp, #-0x88]
    // 0xa08750: mov             x0, x3
    // 0xa08754: r2 = Null
    //     0xa08754: mov             x2, NULL
    // 0xa08758: r1 = Null
    //     0xa08758: mov             x1, NULL
    // 0xa0875c: r4 = LoadClassIdInstr(r0)
    //     0xa0875c: ldur            x4, [x0, #-1]
    //     0xa08760: ubfx            x4, x4, #0xc, #0x14
    // 0xa08764: r17 = 4578
    //     0xa08764: mov             x17, #0x11e2
    // 0xa08768: cmp             x4, x17
    // 0xa0876c: b.eq            #0xa08784
    // 0xa08770: r8 = DBusUint32
    //     0xa08770: add             x8, PP, #8, lsl #12  ; [pp+0x8028] Type: DBusUint32
    //     0xa08774: ldr             x8, [x8, #0x28]
    // 0xa08778: r3 = Null
    //     0xa08778: add             x3, PP, #8, lsl #12  ; [pp+0x8070] Null
    //     0xa0877c: ldr             x3, [x3, #0x70]
    // 0xa08780: r0 = DefaultTypeTest()
    //     0xa08780: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa08784: ldur            x0, [fp, #-0x88]
    // 0xa08788: LoadField: r1 = r0->field_7
    //     0xa08788: ldur            x1, [x0, #7]
    // 0xa0878c: mov             x0, x1
    // 0xa08790: b               #0xa08798
    // 0xa08794: ldur            x0, [fp, #-0x70]
    // 0xa08798: ldur            x1, [fp, #-0x18]
    // 0xa0879c: mov             x10, x1
    // 0xa087a0: ldur            x1, [fp, #-0x68]
    // 0xa087a4: ldur            x4, [fp, #-0x60]
    // 0xa087a8: ldur            x5, [fp, #-0x58]
    // 0xa087ac: ldur            x6, [fp, #-0x50]
    // 0xa087b0: ldur            x7, [fp, #-0x48]
    // 0xa087b4: ldur            x8, [fp, #-0x40]
    // 0xa087b8: ldur            x9, [fp, #-0x38]
    // 0xa087bc: mov             x3, x1
    // 0xa087c0: mov             x2, x0
    // 0xa087c4: ldur            x1, [fp, #-0x78]
    // 0xa087c8: b               #0xa07c68
    // 0xa087cc: r0 = 8
    //     0xa087cc: mov             x0, #8
    // 0xa087d0: ldr             x16, [fp, #0x10]
    // 0xa087d4: stp             x0, x16, [SP, #-0x10]!
    // 0xa087d8: r0 = align()
    //     0xa087d8: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa087dc: add             SP, SP, #0x10
    // 0xa087e0: tbz             w0, #4, #0xa087f4
    // 0xa087e4: r0 = Null
    //     0xa087e4: mov             x0, NULL
    // 0xa087e8: LeaveFrame
    //     0xa087e8: mov             SP, fp
    //     0xa087ec: ldp             fp, lr, [SP], #0x10
    // 0xa087f0: ret
    //     0xa087f0: ret             
    // 0xa087f4: ldr             x1, [fp, #0x10]
    // 0xa087f8: ldur            x0, [fp, #-0x28]
    // 0xa087fc: LoadField: r2 = r1->field_8f
    //     0xa087fc: ldur            w2, [x1, #0x8f]
    // 0xa08800: DecompressPointer r2
    //     0xa08800: add             x2, x2, HEAP, lsl #32
    // 0xa08804: LoadField: r3 = r2->field_13
    //     0xa08804: ldur            w3, [x2, #0x13]
    // 0xa08808: DecompressPointer r3
    //     0xa08808: add             x3, x3, HEAP, lsl #32
    // 0xa0880c: LoadField: r2 = r1->field_9b
    //     0xa0880c: ldur            x2, [x1, #0x9b]
    // 0xa08810: r4 = LoadInt32Instr(r3)
    //     0xa08810: sbfx            x4, x3, #1, #0x1f
    // 0xa08814: sub             x3, x4, x2
    // 0xa08818: cmp             x3, x0
    // 0xa0881c: b.ge            #0xa08830
    // 0xa08820: r0 = Null
    //     0xa08820: mov             x0, NULL
    // 0xa08824: LeaveFrame
    //     0xa08824: mov             SP, fp
    //     0xa08828: ldp             fp, lr, [SP], #0x10
    // 0xa0882c: ret
    //     0xa0882c: ret             
    // 0xa08830: ldur            x3, [fp, #-0x18]
    // 0xa08834: add             x4, x2, x0
    // 0xa08838: stur            x4, [fp, #-0x90]
    // 0xa0883c: r16 = <DBusValue>
    //     0xa0883c: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa08840: stp             xzr, x16, [SP, #-0x10]!
    // 0xa08844: r0 = _GrowableList()
    //     0xa08844: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa08848: add             SP, SP, #0x10
    // 0xa0884c: mov             x1, x0
    // 0xa08850: ldur            x0, [fp, #-0x18]
    // 0xa08854: stur            x1, [fp, #-0x78]
    // 0xa08858: cmp             w0, NULL
    // 0xa0885c: b.eq            #0xa08ab4
    // 0xa08860: SaveReg r0
    //     0xa08860: str             x0, [SP, #-8]!
    // 0xa08864: r0 = split()
    //     0xa08864: bl              #0x9fd454  ; [package:dbus/src/dbus_value.dart] DBusSignature::split
    // 0xa08868: add             SP, SP, #8
    // 0xa0886c: mov             x1, x0
    // 0xa08870: stur            x1, [fp, #-0x88]
    // 0xa08874: LoadField: r2 = r1->field_7
    //     0xa08874: ldur            w2, [x1, #7]
    // 0xa08878: DecompressPointer r2
    //     0xa08878: add             x2, x2, HEAP, lsl #32
    // 0xa0887c: stur            x2, [fp, #-0x80]
    // 0xa08880: LoadField: r0 = r1->field_b
    //     0xa08880: ldur            w0, [x1, #0xb]
    // 0xa08884: DecompressPointer r0
    //     0xa08884: add             x0, x0, HEAP, lsl #32
    // 0xa08888: r3 = LoadInt32Instr(r0)
    //     0xa08888: sbfx            x3, x0, #1, #0x1f
    // 0xa0888c: stur            x3, [fp, #-0xa8]
    // 0xa08890: ldur            x5, [fp, #-0x78]
    // 0xa08894: r10 = 0
    //     0xa08894: mov             x10, #0
    // 0xa08898: ldr             x7, [fp, #0x10]
    // 0xa0889c: ldur            x6, [fp, #-0x28]
    // 0xa088a0: ldur            x4, [fp, #-0x18]
    // 0xa088a4: ldur            x9, [fp, #-0x70]
    // 0xa088a8: ldur            x8, [fp, #-0x90]
    // 0xa088ac: stur            x10, [fp, #-0xa0]
    // 0xa088b0: CheckStackOverflow
    //     0xa088b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa088b4: cmp             SP, x16
    //     0xa088b8: b.ls            #0xa091bc
    // 0xa088bc: r0 = LoadClassIdInstr(r1)
    //     0xa088bc: ldur            x0, [x1, #-1]
    //     0xa088c0: ubfx            x0, x0, #0xc, #0x14
    // 0xa088c4: SaveReg r1
    //     0xa088c4: str             x1, [SP, #-8]!
    // 0xa088c8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa088c8: mov             x17, #0xb8ea
    //     0xa088cc: add             lr, x0, x17
    //     0xa088d0: ldr             lr, [x21, lr, lsl #3]
    //     0xa088d4: blr             lr
    // 0xa088d8: add             SP, SP, #8
    // 0xa088dc: r1 = LoadInt32Instr(r0)
    //     0xa088dc: sbfx            x1, x0, #1, #0x1f
    //     0xa088e0: tbz             w0, #0, #0xa088e8
    //     0xa088e4: ldur            x1, [x0, #7]
    // 0xa088e8: ldur            x2, [fp, #-0xa8]
    // 0xa088ec: cmp             x2, x1
    // 0xa088f0: b.ne            #0xa09038
    // 0xa088f4: ldur            x3, [fp, #-0x88]
    // 0xa088f8: ldur            x4, [fp, #-0xa0]
    // 0xa088fc: cmp             x4, x1
    // 0xa08900: b.lt            #0xa08924
    // 0xa08904: ldr             x5, [fp, #0x10]
    // 0xa08908: ldur            x6, [fp, #-0x90]
    // 0xa0890c: LoadField: r0 = r5->field_9b
    //     0xa0890c: ldur            x0, [x5, #0x9b]
    // 0xa08910: cmp             x0, x6
    // 0xa08914: b.ne            #0xa09050
    // 0xa08918: mov             x0, x5
    // 0xa0891c: ldur            x2, [fp, #-0x78]
    // 0xa08920: b               #0xa08ac4
    // 0xa08924: ldr             x5, [fp, #0x10]
    // 0xa08928: ldur            x7, [fp, #-0x28]
    // 0xa0892c: ldur            x8, [fp, #-0x18]
    // 0xa08930: ldur            x6, [fp, #-0x90]
    // 0xa08934: r0 = BoxInt64Instr(r4)
    //     0xa08934: sbfiz           x0, x4, #1, #0x1f
    //     0xa08938: cmp             x4, x0, asr #1
    //     0xa0893c: b.eq            #0xa08948
    //     0xa08940: bl              #0xd69bb8
    //     0xa08944: stur            x4, [x0, #7]
    // 0xa08948: r1 = LoadClassIdInstr(r3)
    //     0xa08948: ldur            x1, [x3, #-1]
    //     0xa0894c: ubfx            x1, x1, #0xc, #0x14
    // 0xa08950: stp             x0, x3, [SP, #-0x10]!
    // 0xa08954: mov             x0, x1
    // 0xa08958: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa08958: mov             x17, #0xd175
    //     0xa0895c: add             lr, x0, x17
    //     0xa08960: ldr             lr, [x21, lr, lsl #3]
    //     0xa08964: blr             lr
    // 0xa08968: add             SP, SP, #0x10
    // 0xa0896c: mov             x3, x0
    // 0xa08970: ldur            x0, [fp, #-0xa0]
    // 0xa08974: stur            x3, [fp, #-0x98]
    // 0xa08978: add             x10, x0, #1
    // 0xa0897c: stur            x10, [fp, #-0xb8]
    // 0xa08980: cmp             w3, NULL
    // 0xa08984: b.ne            #0xa089b8
    // 0xa08988: mov             x0, x3
    // 0xa0898c: ldur            x2, [fp, #-0x80]
    // 0xa08990: r1 = Null
    //     0xa08990: mov             x1, NULL
    // 0xa08994: cmp             w2, NULL
    // 0xa08998: b.eq            #0xa089b8
    // 0xa0899c: LoadField: r4 = r2->field_17
    //     0xa0899c: ldur            w4, [x2, #0x17]
    // 0xa089a0: DecompressPointer r4
    //     0xa089a0: add             x4, x4, HEAP, lsl #32
    // 0xa089a4: r8 = X0
    //     0xa089a4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa089a8: LoadField: r9 = r4->field_7
    //     0xa089a8: ldur            x9, [x4, #7]
    // 0xa089ac: r3 = Null
    //     0xa089ac: add             x3, PP, #8, lsl #12  ; [pp+0x8080] Null
    //     0xa089b0: ldr             x3, [x3, #0x80]
    // 0xa089b4: blr             x9
    // 0xa089b8: ldur            x0, [fp, #-0x70]
    // 0xa089bc: ldr             x16, [fp, #0x10]
    // 0xa089c0: ldur            lr, [fp, #-0x98]
    // 0xa089c4: stp             lr, x16, [SP, #-0x10]!
    // 0xa089c8: ldur            x16, [fp, #-8]
    // 0xa089cc: stp             x0, x16, [SP, #-0x10]!
    // 0xa089d0: r0 = readDBusValue()
    //     0xa089d0: bl              #0xa091c8  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusValue
    // 0xa089d4: add             SP, SP, #0x20
    // 0xa089d8: stur            x0, [fp, #-0xb0]
    // 0xa089dc: cmp             w0, NULL
    // 0xa089e0: b.ne            #0xa089f4
    // 0xa089e4: r0 = Null
    //     0xa089e4: mov             x0, NULL
    // 0xa089e8: LeaveFrame
    //     0xa089e8: mov             SP, fp
    //     0xa089ec: ldp             fp, lr, [SP], #0x10
    // 0xa089f0: ret
    //     0xa089f0: ret             
    // 0xa089f4: ldr             x1, [fp, #0x10]
    // 0xa089f8: ldur            x2, [fp, #-0x90]
    // 0xa089fc: LoadField: r3 = r1->field_9b
    //     0xa089fc: ldur            x3, [x1, #0x9b]
    // 0xa08a00: cmp             x3, x2
    // 0xa08a04: b.gt            #0xa090c0
    // 0xa08a08: ldur            x3, [fp, #-0x28]
    // 0xa08a0c: ldur            x4, [fp, #-0x18]
    // 0xa08a10: ldur            x5, [fp, #-0x78]
    // 0xa08a14: LoadField: r6 = r5->field_b
    //     0xa08a14: ldur            w6, [x5, #0xb]
    // 0xa08a18: DecompressPointer r6
    //     0xa08a18: add             x6, x6, HEAP, lsl #32
    // 0xa08a1c: stur            x6, [fp, #-0x98]
    // 0xa08a20: LoadField: r7 = r5->field_f
    //     0xa08a20: ldur            w7, [x5, #0xf]
    // 0xa08a24: DecompressPointer r7
    //     0xa08a24: add             x7, x7, HEAP, lsl #32
    // 0xa08a28: LoadField: r8 = r7->field_b
    //     0xa08a28: ldur            w8, [x7, #0xb]
    // 0xa08a2c: DecompressPointer r8
    //     0xa08a2c: add             x8, x8, HEAP, lsl #32
    // 0xa08a30: cmp             w6, w8
    // 0xa08a34: b.ne            #0xa08a44
    // 0xa08a38: SaveReg r5
    //     0xa08a38: str             x5, [SP, #-8]!
    // 0xa08a3c: r0 = _growToNextCapacity()
    //     0xa08a3c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa08a40: add             SP, SP, #8
    // 0xa08a44: ldur            x2, [fp, #-0x78]
    // 0xa08a48: ldur            x0, [fp, #-0x98]
    // 0xa08a4c: r3 = LoadInt32Instr(r0)
    //     0xa08a4c: sbfx            x3, x0, #1, #0x1f
    // 0xa08a50: add             x0, x3, #1
    // 0xa08a54: lsl             x1, x0, #1
    // 0xa08a58: StoreField: r2->field_b = r1
    //     0xa08a58: stur            w1, [x2, #0xb]
    // 0xa08a5c: mov             x1, x3
    // 0xa08a60: cmp             x1, x0
    // 0xa08a64: b.hs            #0xa091c4
    // 0xa08a68: LoadField: r1 = r2->field_f
    //     0xa08a68: ldur            w1, [x2, #0xf]
    // 0xa08a6c: DecompressPointer r1
    //     0xa08a6c: add             x1, x1, HEAP, lsl #32
    // 0xa08a70: ldur            x0, [fp, #-0xb0]
    // 0xa08a74: ArrayStore: r1[r3] = r0  ; List_4
    //     0xa08a74: add             x25, x1, x3, lsl #2
    //     0xa08a78: add             x25, x25, #0xf
    //     0xa08a7c: str             w0, [x25]
    //     0xa08a80: tbz             w0, #0, #0xa08a9c
    //     0xa08a84: ldurb           w16, [x1, #-1]
    //     0xa08a88: ldurb           w17, [x0, #-1]
    //     0xa08a8c: and             x16, x17, x16, lsr #2
    //     0xa08a90: tst             x16, HEAP, lsr #32
    //     0xa08a94: b.eq            #0xa08a9c
    //     0xa08a98: bl              #0xd67e5c
    // 0xa08a9c: ldur            x10, [fp, #-0xb8]
    // 0xa08aa0: mov             x5, x2
    // 0xa08aa4: ldur            x1, [fp, #-0x88]
    // 0xa08aa8: ldur            x2, [fp, #-0x80]
    // 0xa08aac: ldur            x3, [fp, #-0xa8]
    // 0xa08ab0: b               #0xa08898
    // 0xa08ab4: ldur            x0, [fp, #-0x28]
    // 0xa08ab8: mov             x2, x1
    // 0xa08abc: cbnz            x0, #0xa09130
    // 0xa08ac0: ldr             x0, [fp, #0x10]
    // 0xa08ac4: ldur            x1, [fp, #-0x70]
    // 0xa08ac8: LoadField: r3 = r0->field_93
    //     0xa08ac8: ldur            w3, [x0, #0x93]
    // 0xa08acc: DecompressPointer r3
    //     0xa08acc: add             x3, x3, HEAP, lsl #32
    // 0xa08ad0: LoadField: r0 = r3->field_b
    //     0xa08ad0: ldur            w0, [x3, #0xb]
    // 0xa08ad4: DecompressPointer r0
    //     0xa08ad4: add             x0, x0, HEAP, lsl #32
    // 0xa08ad8: r4 = LoadInt32Instr(r0)
    //     0xa08ad8: sbfx            x4, x0, #1, #0x1f
    // 0xa08adc: cmp             x4, x1
    // 0xa08ae0: b.lt            #0xa0917c
    // 0xa08ae4: ldur            x11, [fp, #-0x20]
    // 0xa08ae8: ldur            x10, [fp, #-0x30]
    // 0xa08aec: ldur            x9, [fp, #-0x38]
    // 0xa08af0: ldur            x8, [fp, #-0x40]
    // 0xa08af4: ldur            x7, [fp, #-0x48]
    // 0xa08af8: ldur            x6, [fp, #-0x50]
    // 0xa08afc: ldur            x5, [fp, #-0x58]
    // 0xa08b00: ldur            x4, [fp, #-0x60]
    // 0xa08b04: ldur            x0, [fp, #-0x68]
    // 0xa08b08: ldur            x12, [fp, #-0x10]
    // 0xa08b0c: stp             xzr, x3, [SP, #-0x10]!
    // 0xa08b10: SaveReg r1
    //     0xa08b10: str             x1, [SP, #-8]!
    // 0xa08b14: r0 = removeRange()
    //     0xa08b14: bl              #0xafb1c8  ; [dart:core] _GrowableList::removeRange
    // 0xa08b18: add             SP, SP, #0x18
    // 0xa08b1c: r0 = DBusMessage()
    //     0xa08b1c: bl              #0xa02010  ; AllocateDBusMessageStub -> DBusMessage (size=0x38)
    // 0xa08b20: ldur            x1, [fp, #-0x10]
    // 0xa08b24: StoreField: r0->field_7 = r1
    //     0xa08b24: stur            w1, [x0, #7]
    // 0xa08b28: ldur            x1, [fp, #-0x20]
    // 0xa08b2c: StoreField: r0->field_b = r1
    //     0xa08b2c: stur            w1, [x0, #0xb]
    // 0xa08b30: ldur            x1, [fp, #-0x30]
    // 0xa08b34: StoreField: r0->field_f = r1
    //     0xa08b34: stur            x1, [x0, #0xf]
    // 0xa08b38: ldur            x1, [fp, #-0x38]
    // 0xa08b3c: StoreField: r0->field_17 = r1
    //     0xa08b3c: stur            w1, [x0, #0x17]
    // 0xa08b40: ldur            x1, [fp, #-0x40]
    // 0xa08b44: StoreField: r0->field_1b = r1
    //     0xa08b44: stur            w1, [x0, #0x1b]
    // 0xa08b48: ldur            x1, [fp, #-0x48]
    // 0xa08b4c: StoreField: r0->field_1f = r1
    //     0xa08b4c: stur            w1, [x0, #0x1f]
    // 0xa08b50: ldur            x1, [fp, #-0x50]
    // 0xa08b54: StoreField: r0->field_23 = r1
    //     0xa08b54: stur            w1, [x0, #0x23]
    // 0xa08b58: ldur            x1, [fp, #-0x58]
    // 0xa08b5c: StoreField: r0->field_27 = r1
    //     0xa08b5c: stur            w1, [x0, #0x27]
    // 0xa08b60: ldur            x1, [fp, #-0x60]
    // 0xa08b64: StoreField: r0->field_2b = r1
    //     0xa08b64: stur            w1, [x0, #0x2b]
    // 0xa08b68: ldur            x1, [fp, #-0x68]
    // 0xa08b6c: StoreField: r0->field_2f = r1
    //     0xa08b6c: stur            w1, [x0, #0x2f]
    // 0xa08b70: ldur            x1, [fp, #-0x78]
    // 0xa08b74: StoreField: r0->field_33 = r1
    //     0xa08b74: stur            w1, [x0, #0x33]
    // 0xa08b78: LeaveFrame
    //     0xa08b78: mov             SP, fp
    //     0xa08b7c: ldp             fp, lr, [SP], #0x10
    // 0xa08b80: ret
    //     0xa08b80: ret             
    // 0xa08b84: r0 = "Invalid endian value received"
    //     0xa08b84: add             x0, PP, #8, lsl #12  ; [pp+0x8090] "Invalid endian value received"
    //     0xa08b88: ldr             x0, [x0, #0x90]
    // 0xa08b8c: r0 = Throw()
    //     0xa08b8c: bl              #0xd67e38  ; ThrowStub
    // 0xa08b90: brk             #0
    // 0xa08b94: r0 = "Invalid type received"
    //     0xa08b94: add             x0, PP, #8, lsl #12  ; [pp+0x8098] "Invalid type received"
    //     0xa08b98: ldr             x0, [x0, #0x98]
    // 0xa08b9c: r0 = Throw()
    //     0xa08b9c: bl              #0xd67e38  ; ThrowStub
    // 0xa08ba0: brk             #0
    // 0xa08ba4: r0 = "Unsupported protocol version"
    //     0xa08ba4: add             x0, PP, #8, lsl #12  ; [pp+0x80a0] "Unsupported protocol version"
    //     0xa08ba8: ldr             x0, [x0, #0xa0]
    // 0xa08bac: r0 = Throw()
    //     0xa08bac: bl              #0xd67e38  ; ThrowStub
    // 0xa08bb0: brk             #0
    // 0xa08bb4: ldur            x0, [fp, #-0x88]
    // 0xa08bb8: r1 = Null
    //     0xa08bb8: mov             x1, NULL
    // 0xa08bbc: r2 = 4
    //     0xa08bbc: mov             x2, #4
    // 0xa08bc0: r0 = AllocateArray()
    //     0xa08bc0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa08bc4: mov             x1, x0
    // 0xa08bc8: stur            x1, [fp, #-0x80]
    // 0xa08bcc: r17 = "Invalid message path header of type "
    //     0xa08bcc: add             x17, PP, #8, lsl #12  ; [pp+0x80a8] "Invalid message path header of type "
    //     0xa08bd0: ldr             x17, [x17, #0xa8]
    // 0xa08bd4: StoreField: r1->field_f = r17
    //     0xa08bd4: stur            w17, [x1, #0xf]
    // 0xa08bd8: ldur            x3, [fp, #-0x88]
    // 0xa08bdc: r0 = LoadClassIdInstr(r3)
    //     0xa08bdc: ldur            x0, [x3, #-1]
    //     0xa08be0: ubfx            x0, x0, #0xc, #0x14
    // 0xa08be4: SaveReg r3
    //     0xa08be4: str             x3, [SP, #-8]!
    // 0xa08be8: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa08be8: add             lr, x0, #0x2b8
    //     0xa08bec: ldr             lr, [x21, lr, lsl #3]
    //     0xa08bf0: blr             lr
    // 0xa08bf4: add             SP, SP, #8
    // 0xa08bf8: ldur            x1, [fp, #-0x80]
    // 0xa08bfc: ArrayStore: r1[1] = r0  ; List_4
    //     0xa08bfc: add             x25, x1, #0x13
    //     0xa08c00: str             w0, [x25]
    //     0xa08c04: tbz             w0, #0, #0xa08c20
    //     0xa08c08: ldurb           w16, [x1, #-1]
    //     0xa08c0c: ldurb           w17, [x0, #-1]
    //     0xa08c10: and             x16, x17, x16, lsr #2
    //     0xa08c14: tst             x16, HEAP, lsr #32
    //     0xa08c18: b.eq            #0xa08c20
    //     0xa08c1c: bl              #0xd67e5c
    // 0xa08c20: ldur            x16, [fp, #-0x80]
    // 0xa08c24: SaveReg r16
    //     0xa08c24: str             x16, [SP, #-8]!
    // 0xa08c28: r0 = _interpolate()
    //     0xa08c28: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa08c2c: add             SP, SP, #8
    // 0xa08c30: r0 = Throw()
    //     0xa08c30: bl              #0xd67e38  ; ThrowStub
    // 0xa08c34: brk             #0
    // 0xa08c38: ldur            x0, [fp, #-0x88]
    // 0xa08c3c: r1 = Null
    //     0xa08c3c: mov             x1, NULL
    // 0xa08c40: r2 = 4
    //     0xa08c40: mov             x2, #4
    // 0xa08c44: r0 = AllocateArray()
    //     0xa08c44: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa08c48: mov             x1, x0
    // 0xa08c4c: stur            x1, [fp, #-0x80]
    // 0xa08c50: r17 = "Invalid message interface header of type "
    //     0xa08c50: add             x17, PP, #8, lsl #12  ; [pp+0x80b0] "Invalid message interface header of type "
    //     0xa08c54: ldr             x17, [x17, #0xb0]
    // 0xa08c58: StoreField: r1->field_f = r17
    //     0xa08c58: stur            w17, [x1, #0xf]
    // 0xa08c5c: ldur            x3, [fp, #-0x88]
    // 0xa08c60: r0 = LoadClassIdInstr(r3)
    //     0xa08c60: ldur            x0, [x3, #-1]
    //     0xa08c64: ubfx            x0, x0, #0xc, #0x14
    // 0xa08c68: SaveReg r3
    //     0xa08c68: str             x3, [SP, #-8]!
    // 0xa08c6c: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa08c6c: add             lr, x0, #0x2b8
    //     0xa08c70: ldr             lr, [x21, lr, lsl #3]
    //     0xa08c74: blr             lr
    // 0xa08c78: add             SP, SP, #8
    // 0xa08c7c: ldur            x1, [fp, #-0x80]
    // 0xa08c80: ArrayStore: r1[1] = r0  ; List_4
    //     0xa08c80: add             x25, x1, #0x13
    //     0xa08c84: str             w0, [x25]
    //     0xa08c88: tbz             w0, #0, #0xa08ca4
    //     0xa08c8c: ldurb           w16, [x1, #-1]
    //     0xa08c90: ldurb           w17, [x0, #-1]
    //     0xa08c94: and             x16, x17, x16, lsr #2
    //     0xa08c98: tst             x16, HEAP, lsr #32
    //     0xa08c9c: b.eq            #0xa08ca4
    //     0xa08ca0: bl              #0xd67e5c
    // 0xa08ca4: ldur            x16, [fp, #-0x80]
    // 0xa08ca8: SaveReg r16
    //     0xa08ca8: str             x16, [SP, #-8]!
    // 0xa08cac: r0 = _interpolate()
    //     0xa08cac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa08cb0: add             SP, SP, #8
    // 0xa08cb4: r0 = Throw()
    //     0xa08cb4: bl              #0xd67e38  ; ThrowStub
    // 0xa08cb8: brk             #0
    // 0xa08cbc: ldur            x0, [fp, #-0x88]
    // 0xa08cc0: r1 = Null
    //     0xa08cc0: mov             x1, NULL
    // 0xa08cc4: r2 = 4
    //     0xa08cc4: mov             x2, #4
    // 0xa08cc8: r0 = AllocateArray()
    //     0xa08cc8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa08ccc: mov             x1, x0
    // 0xa08cd0: stur            x1, [fp, #-0x80]
    // 0xa08cd4: r17 = "Invalid message member name header of type "
    //     0xa08cd4: add             x17, PP, #8, lsl #12  ; [pp+0x80b8] "Invalid message member name header of type "
    //     0xa08cd8: ldr             x17, [x17, #0xb8]
    // 0xa08cdc: StoreField: r1->field_f = r17
    //     0xa08cdc: stur            w17, [x1, #0xf]
    // 0xa08ce0: ldur            x3, [fp, #-0x88]
    // 0xa08ce4: r0 = LoadClassIdInstr(r3)
    //     0xa08ce4: ldur            x0, [x3, #-1]
    //     0xa08ce8: ubfx            x0, x0, #0xc, #0x14
    // 0xa08cec: SaveReg r3
    //     0xa08cec: str             x3, [SP, #-8]!
    // 0xa08cf0: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa08cf0: add             lr, x0, #0x2b8
    //     0xa08cf4: ldr             lr, [x21, lr, lsl #3]
    //     0xa08cf8: blr             lr
    // 0xa08cfc: add             SP, SP, #8
    // 0xa08d00: ldur            x1, [fp, #-0x80]
    // 0xa08d04: ArrayStore: r1[1] = r0  ; List_4
    //     0xa08d04: add             x25, x1, #0x13
    //     0xa08d08: str             w0, [x25]
    //     0xa08d0c: tbz             w0, #0, #0xa08d28
    //     0xa08d10: ldurb           w16, [x1, #-1]
    //     0xa08d14: ldurb           w17, [x0, #-1]
    //     0xa08d18: and             x16, x17, x16, lsr #2
    //     0xa08d1c: tst             x16, HEAP, lsr #32
    //     0xa08d20: b.eq            #0xa08d28
    //     0xa08d24: bl              #0xd67e5c
    // 0xa08d28: ldur            x16, [fp, #-0x80]
    // 0xa08d2c: SaveReg r16
    //     0xa08d2c: str             x16, [SP, #-8]!
    // 0xa08d30: r0 = _interpolate()
    //     0xa08d30: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa08d34: add             SP, SP, #8
    // 0xa08d38: r0 = Throw()
    //     0xa08d38: bl              #0xd67e38  ; ThrowStub
    // 0xa08d3c: brk             #0
    // 0xa08d40: ldur            x0, [fp, #-0x88]
    // 0xa08d44: r1 = Null
    //     0xa08d44: mov             x1, NULL
    // 0xa08d48: r2 = 4
    //     0xa08d48: mov             x2, #4
    // 0xa08d4c: r0 = AllocateArray()
    //     0xa08d4c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa08d50: mov             x1, x0
    // 0xa08d54: stur            x1, [fp, #-0x80]
    // 0xa08d58: r17 = "Invalid message error name header of type "
    //     0xa08d58: add             x17, PP, #8, lsl #12  ; [pp+0x80c0] "Invalid message error name header of type "
    //     0xa08d5c: ldr             x17, [x17, #0xc0]
    // 0xa08d60: StoreField: r1->field_f = r17
    //     0xa08d60: stur            w17, [x1, #0xf]
    // 0xa08d64: ldur            x3, [fp, #-0x88]
    // 0xa08d68: r0 = LoadClassIdInstr(r3)
    //     0xa08d68: ldur            x0, [x3, #-1]
    //     0xa08d6c: ubfx            x0, x0, #0xc, #0x14
    // 0xa08d70: SaveReg r3
    //     0xa08d70: str             x3, [SP, #-8]!
    // 0xa08d74: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa08d74: add             lr, x0, #0x2b8
    //     0xa08d78: ldr             lr, [x21, lr, lsl #3]
    //     0xa08d7c: blr             lr
    // 0xa08d80: add             SP, SP, #8
    // 0xa08d84: ldur            x1, [fp, #-0x80]
    // 0xa08d88: ArrayStore: r1[1] = r0  ; List_4
    //     0xa08d88: add             x25, x1, #0x13
    //     0xa08d8c: str             w0, [x25]
    //     0xa08d90: tbz             w0, #0, #0xa08dac
    //     0xa08d94: ldurb           w16, [x1, #-1]
    //     0xa08d98: ldurb           w17, [x0, #-1]
    //     0xa08d9c: and             x16, x17, x16, lsr #2
    //     0xa08da0: tst             x16, HEAP, lsr #32
    //     0xa08da4: b.eq            #0xa08dac
    //     0xa08da8: bl              #0xd67e5c
    // 0xa08dac: ldur            x16, [fp, #-0x80]
    // 0xa08db0: SaveReg r16
    //     0xa08db0: str             x16, [SP, #-8]!
    // 0xa08db4: r0 = _interpolate()
    //     0xa08db4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa08db8: add             SP, SP, #8
    // 0xa08dbc: r0 = Throw()
    //     0xa08dbc: bl              #0xd67e38  ; ThrowStub
    // 0xa08dc0: brk             #0
    // 0xa08dc4: r0 = FormatException()
    //     0xa08dc4: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa08dc8: r3 = "Error name too long"
    //     0xa08dc8: ldr             x3, [PP, #0x7cc8]  ; [pp+0x7cc8] "Error name too long"
    // 0xa08dcc: StoreField: r0->field_7 = r3
    //     0xa08dcc: stur            w3, [x0, #7]
    // 0xa08dd0: r0 = Throw()
    //     0xa08dd0: bl              #0xd67e38  ; ThrowStub
    // 0xa08dd4: brk             #0
    // 0xa08dd8: r0 = FormatException()
    //     0xa08dd8: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa08ddc: r1 = "Error name needs at least two elements"
    //     0xa08ddc: ldr             x1, [PP, #0x7cd0]  ; [pp+0x7cd0] "Error name needs at least two elements"
    // 0xa08de0: StoreField: r0->field_7 = r1
    //     0xa08de0: stur            w1, [x0, #7]
    // 0xa08de4: r0 = Throw()
    //     0xa08de4: bl              #0xd67e38  ; ThrowStub
    // 0xa08de8: brk             #0
    // 0xa08dec: ldur            x0, [fp, #-0xb0]
    // 0xa08df0: r0 = ConcurrentModificationError()
    //     0xa08df0: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa08df4: ldur            x3, [fp, #-0xb0]
    // 0xa08df8: StoreField: r0->field_b = r3
    //     0xa08df8: stur            w3, [x0, #0xb]
    // 0xa08dfc: r0 = Throw()
    //     0xa08dfc: bl              #0xd67e38  ; ThrowStub
    // 0xa08e00: brk             #0
    // 0xa08e04: r0 = FormatException()
    //     0xa08e04: bl              #0x4d17a8  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0xa08e08: r2 = "Invalid element in error name"
    //     0xa08e08: ldr             x2, [PP, #0x7cc0]  ; [pp+0x7cc0] "Invalid element in error name"
    // 0xa08e0c: StoreField: r0->field_7 = r2
    //     0xa08e0c: stur            w2, [x0, #7]
    // 0xa08e10: r0 = Throw()
    //     0xa08e10: bl              #0xd67e38  ; ThrowStub
    // 0xa08e14: brk             #0
    // 0xa08e18: ldur            x0, [fp, #-0x88]
    // 0xa08e1c: r1 = Null
    //     0xa08e1c: mov             x1, NULL
    // 0xa08e20: r2 = 4
    //     0xa08e20: mov             x2, #4
    // 0xa08e24: r0 = AllocateArray()
    //     0xa08e24: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa08e28: mov             x1, x0
    // 0xa08e2c: stur            x1, [fp, #-0x80]
    // 0xa08e30: r17 = "Invalid message reply serial header of type "
    //     0xa08e30: add             x17, PP, #8, lsl #12  ; [pp+0x80c8] "Invalid message reply serial header of type "
    //     0xa08e34: ldr             x17, [x17, #0xc8]
    // 0xa08e38: StoreField: r1->field_f = r17
    //     0xa08e38: stur            w17, [x1, #0xf]
    // 0xa08e3c: ldur            x3, [fp, #-0x88]
    // 0xa08e40: r0 = LoadClassIdInstr(r3)
    //     0xa08e40: ldur            x0, [x3, #-1]
    //     0xa08e44: ubfx            x0, x0, #0xc, #0x14
    // 0xa08e48: SaveReg r3
    //     0xa08e48: str             x3, [SP, #-8]!
    // 0xa08e4c: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa08e4c: add             lr, x0, #0x2b8
    //     0xa08e50: ldr             lr, [x21, lr, lsl #3]
    //     0xa08e54: blr             lr
    // 0xa08e58: add             SP, SP, #8
    // 0xa08e5c: ldur            x1, [fp, #-0x80]
    // 0xa08e60: ArrayStore: r1[1] = r0  ; List_4
    //     0xa08e60: add             x25, x1, #0x13
    //     0xa08e64: str             w0, [x25]
    //     0xa08e68: tbz             w0, #0, #0xa08e84
    //     0xa08e6c: ldurb           w16, [x1, #-1]
    //     0xa08e70: ldurb           w17, [x0, #-1]
    //     0xa08e74: and             x16, x17, x16, lsr #2
    //     0xa08e78: tst             x16, HEAP, lsr #32
    //     0xa08e7c: b.eq            #0xa08e84
    //     0xa08e80: bl              #0xd67e5c
    // 0xa08e84: ldur            x16, [fp, #-0x80]
    // 0xa08e88: SaveReg r16
    //     0xa08e88: str             x16, [SP, #-8]!
    // 0xa08e8c: r0 = _interpolate()
    //     0xa08e8c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa08e90: add             SP, SP, #8
    // 0xa08e94: r0 = Throw()
    //     0xa08e94: bl              #0xd67e38  ; ThrowStub
    // 0xa08e98: brk             #0
    // 0xa08e9c: ldur            x0, [fp, #-0x88]
    // 0xa08ea0: r1 = Null
    //     0xa08ea0: mov             x1, NULL
    // 0xa08ea4: r2 = 4
    //     0xa08ea4: mov             x2, #4
    // 0xa08ea8: r0 = AllocateArray()
    //     0xa08ea8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa08eac: mov             x1, x0
    // 0xa08eb0: stur            x1, [fp, #-0x80]
    // 0xa08eb4: r17 = "Invalid message destination header of type "
    //     0xa08eb4: add             x17, PP, #8, lsl #12  ; [pp+0x80d0] "Invalid message destination header of type "
    //     0xa08eb8: ldr             x17, [x17, #0xd0]
    // 0xa08ebc: StoreField: r1->field_f = r17
    //     0xa08ebc: stur            w17, [x1, #0xf]
    // 0xa08ec0: ldur            x3, [fp, #-0x88]
    // 0xa08ec4: r0 = LoadClassIdInstr(r3)
    //     0xa08ec4: ldur            x0, [x3, #-1]
    //     0xa08ec8: ubfx            x0, x0, #0xc, #0x14
    // 0xa08ecc: SaveReg r3
    //     0xa08ecc: str             x3, [SP, #-8]!
    // 0xa08ed0: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa08ed0: add             lr, x0, #0x2b8
    //     0xa08ed4: ldr             lr, [x21, lr, lsl #3]
    //     0xa08ed8: blr             lr
    // 0xa08edc: add             SP, SP, #8
    // 0xa08ee0: ldur            x1, [fp, #-0x80]
    // 0xa08ee4: ArrayStore: r1[1] = r0  ; List_4
    //     0xa08ee4: add             x25, x1, #0x13
    //     0xa08ee8: str             w0, [x25]
    //     0xa08eec: tbz             w0, #0, #0xa08f08
    //     0xa08ef0: ldurb           w16, [x1, #-1]
    //     0xa08ef4: ldurb           w17, [x0, #-1]
    //     0xa08ef8: and             x16, x17, x16, lsr #2
    //     0xa08efc: tst             x16, HEAP, lsr #32
    //     0xa08f00: b.eq            #0xa08f08
    //     0xa08f04: bl              #0xd67e5c
    // 0xa08f08: ldur            x16, [fp, #-0x80]
    // 0xa08f0c: SaveReg r16
    //     0xa08f0c: str             x16, [SP, #-8]!
    // 0xa08f10: r0 = _interpolate()
    //     0xa08f10: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa08f14: add             SP, SP, #8
    // 0xa08f18: r0 = Throw()
    //     0xa08f18: bl              #0xd67e38  ; ThrowStub
    // 0xa08f1c: brk             #0
    // 0xa08f20: ldur            x0, [fp, #-0x88]
    // 0xa08f24: r1 = Null
    //     0xa08f24: mov             x1, NULL
    // 0xa08f28: r2 = 4
    //     0xa08f28: mov             x2, #4
    // 0xa08f2c: r0 = AllocateArray()
    //     0xa08f2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa08f30: mov             x1, x0
    // 0xa08f34: stur            x1, [fp, #-0x80]
    // 0xa08f38: r17 = "Invalid message sender header of type "
    //     0xa08f38: add             x17, PP, #8, lsl #12  ; [pp+0x80d8] "Invalid message sender header of type "
    //     0xa08f3c: ldr             x17, [x17, #0xd8]
    // 0xa08f40: StoreField: r1->field_f = r17
    //     0xa08f40: stur            w17, [x1, #0xf]
    // 0xa08f44: ldur            x3, [fp, #-0x88]
    // 0xa08f48: r0 = LoadClassIdInstr(r3)
    //     0xa08f48: ldur            x0, [x3, #-1]
    //     0xa08f4c: ubfx            x0, x0, #0xc, #0x14
    // 0xa08f50: SaveReg r3
    //     0xa08f50: str             x3, [SP, #-8]!
    // 0xa08f54: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa08f54: add             lr, x0, #0x2b8
    //     0xa08f58: ldr             lr, [x21, lr, lsl #3]
    //     0xa08f5c: blr             lr
    // 0xa08f60: add             SP, SP, #8
    // 0xa08f64: ldur            x1, [fp, #-0x80]
    // 0xa08f68: ArrayStore: r1[1] = r0  ; List_4
    //     0xa08f68: add             x25, x1, #0x13
    //     0xa08f6c: str             w0, [x25]
    //     0xa08f70: tbz             w0, #0, #0xa08f8c
    //     0xa08f74: ldurb           w16, [x1, #-1]
    //     0xa08f78: ldurb           w17, [x0, #-1]
    //     0xa08f7c: and             x16, x17, x16, lsr #2
    //     0xa08f80: tst             x16, HEAP, lsr #32
    //     0xa08f84: b.eq            #0xa08f8c
    //     0xa08f88: bl              #0xd67e5c
    // 0xa08f8c: ldur            x16, [fp, #-0x80]
    // 0xa08f90: SaveReg r16
    //     0xa08f90: str             x16, [SP, #-8]!
    // 0xa08f94: r0 = _interpolate()
    //     0xa08f94: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa08f98: add             SP, SP, #8
    // 0xa08f9c: r0 = Throw()
    //     0xa08f9c: bl              #0xd67e38  ; ThrowStub
    // 0xa08fa0: brk             #0
    // 0xa08fa4: r0 = "Sender contains non-unique bus name"
    //     0xa08fa4: add             x0, PP, #8, lsl #12  ; [pp+0x80e0] "Sender contains non-unique bus name"
    //     0xa08fa8: ldr             x0, [x0, #0xe0]
    // 0xa08fac: r0 = Throw()
    //     0xa08fac: bl              #0xd67e38  ; ThrowStub
    // 0xa08fb0: brk             #0
    // 0xa08fb4: ldur            x0, [fp, #-0x88]
    // 0xa08fb8: r1 = Null
    //     0xa08fb8: mov             x1, NULL
    // 0xa08fbc: r2 = 4
    //     0xa08fbc: mov             x2, #4
    // 0xa08fc0: r0 = AllocateArray()
    //     0xa08fc0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa08fc4: mov             x1, x0
    // 0xa08fc8: stur            x1, [fp, #-0x80]
    // 0xa08fcc: r17 = "Invalid message signature of type "
    //     0xa08fcc: add             x17, PP, #8, lsl #12  ; [pp+0x80e8] "Invalid message signature of type "
    //     0xa08fd0: ldr             x17, [x17, #0xe8]
    // 0xa08fd4: StoreField: r1->field_f = r17
    //     0xa08fd4: stur            w17, [x1, #0xf]
    // 0xa08fd8: ldur            x3, [fp, #-0x88]
    // 0xa08fdc: r0 = LoadClassIdInstr(r3)
    //     0xa08fdc: ldur            x0, [x3, #-1]
    //     0xa08fe0: ubfx            x0, x0, #0xc, #0x14
    // 0xa08fe4: SaveReg r3
    //     0xa08fe4: str             x3, [SP, #-8]!
    // 0xa08fe8: r0 = GDT[cid_x0 + 0x2b8]()
    //     0xa08fe8: add             lr, x0, #0x2b8
    //     0xa08fec: ldr             lr, [x21, lr, lsl #3]
    //     0xa08ff0: blr             lr
    // 0xa08ff4: add             SP, SP, #8
    // 0xa08ff8: ldur            x1, [fp, #-0x80]
    // 0xa08ffc: ArrayStore: r1[1] = r0  ; List_4
    //     0xa08ffc: add             x25, x1, #0x13
    //     0xa09000: str             w0, [x25]
    //     0xa09004: tbz             w0, #0, #0xa09020
    //     0xa09008: ldurb           w16, [x1, #-1]
    //     0xa0900c: ldurb           w17, [x0, #-1]
    //     0xa09010: and             x16, x17, x16, lsr #2
    //     0xa09014: tst             x16, HEAP, lsr #32
    //     0xa09018: b.eq            #0xa09020
    //     0xa0901c: bl              #0xd67e5c
    // 0xa09020: ldur            x16, [fp, #-0x80]
    // 0xa09024: SaveReg r16
    //     0xa09024: str             x16, [SP, #-8]!
    // 0xa09028: r0 = _interpolate()
    //     0xa09028: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0902c: add             SP, SP, #8
    // 0xa09030: r0 = Throw()
    //     0xa09030: bl              #0xd67e38  ; ThrowStub
    // 0xa09034: brk             #0
    // 0xa09038: ldur            x0, [fp, #-0x88]
    // 0xa0903c: r0 = ConcurrentModificationError()
    //     0xa0903c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa09040: ldur            x3, [fp, #-0x88]
    // 0xa09044: StoreField: r0->field_b = r3
    //     0xa09044: stur            w3, [x0, #0xb]
    // 0xa09048: r0 = Throw()
    //     0xa09048: bl              #0xd67e38  ; ThrowStub
    // 0xa0904c: brk             #0
    // 0xa09050: ldur            x3, [fp, #-0x28]
    // 0xa09054: ldur            x0, [fp, #-0x18]
    // 0xa09058: r1 = Null
    //     0xa09058: mov             x1, NULL
    // 0xa0905c: r2 = 8
    //     0xa0905c: mov             x2, #8
    // 0xa09060: r0 = AllocateArray()
    //     0xa09060: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa09064: mov             x2, x0
    // 0xa09068: r17 = "Message data of size "
    //     0xa09068: add             x17, PP, #8, lsl #12  ; [pp+0x80f0] "Message data of size "
    //     0xa0906c: ldr             x17, [x17, #0xf0]
    // 0xa09070: StoreField: r2->field_f = r17
    //     0xa09070: stur            w17, [x2, #0xf]
    // 0xa09074: ldur            x7, [fp, #-0x28]
    // 0xa09078: r0 = BoxInt64Instr(r7)
    //     0xa09078: sbfiz           x0, x7, #1, #0x1f
    //     0xa0907c: cmp             x7, x0, asr #1
    //     0xa09080: b.eq            #0xa0908c
    //     0xa09084: bl              #0xd69bb8
    //     0xa09088: stur            x7, [x0, #7]
    // 0xa0908c: StoreField: r2->field_13 = r0
    //     0xa0908c: stur            w0, [x2, #0x13]
    // 0xa09090: r17 = " too large to contain "
    //     0xa09090: add             x17, PP, #8, lsl #12  ; [pp+0x80f8] " too large to contain "
    //     0xa09094: ldr             x17, [x17, #0xf8]
    // 0xa09098: StoreField: r2->field_17 = r17
    //     0xa09098: stur            w17, [x2, #0x17]
    // 0xa0909c: ldur            x8, [fp, #-0x18]
    // 0xa090a0: LoadField: r0 = r8->field_7
    //     0xa090a0: ldur            w0, [x8, #7]
    // 0xa090a4: DecompressPointer r0
    //     0xa090a4: add             x0, x0, HEAP, lsl #32
    // 0xa090a8: StoreField: r2->field_1b = r0
    //     0xa090a8: stur            w0, [x2, #0x1b]
    // 0xa090ac: SaveReg r2
    //     0xa090ac: str             x2, [SP, #-8]!
    // 0xa090b0: r0 = _interpolate()
    //     0xa090b0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa090b4: add             SP, SP, #8
    // 0xa090b8: r0 = Throw()
    //     0xa090b8: bl              #0xd67e38  ; ThrowStub
    // 0xa090bc: brk             #0
    // 0xa090c0: ldur            x0, [fp, #-0x28]
    // 0xa090c4: ldur            x3, [fp, #-0x18]
    // 0xa090c8: r1 = Null
    //     0xa090c8: mov             x1, NULL
    // 0xa090cc: r2 = 8
    //     0xa090cc: mov             x2, #8
    // 0xa090d0: r0 = AllocateArray()
    //     0xa090d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa090d4: mov             x2, x0
    // 0xa090d8: r17 = "Message data of size "
    //     0xa090d8: add             x17, PP, #8, lsl #12  ; [pp+0x80f0] "Message data of size "
    //     0xa090dc: ldr             x17, [x17, #0xf0]
    // 0xa090e0: StoreField: r2->field_f = r17
    //     0xa090e0: stur            w17, [x2, #0xf]
    // 0xa090e4: ldur            x3, [fp, #-0x28]
    // 0xa090e8: r0 = BoxInt64Instr(r3)
    //     0xa090e8: sbfiz           x0, x3, #1, #0x1f
    //     0xa090ec: cmp             x3, x0, asr #1
    //     0xa090f0: b.eq            #0xa090fc
    //     0xa090f4: bl              #0xd69bb8
    //     0xa090f8: stur            x3, [x0, #7]
    // 0xa090fc: StoreField: r2->field_13 = r0
    //     0xa090fc: stur            w0, [x2, #0x13]
    // 0xa09100: r17 = " too small to contain "
    //     0xa09100: add             x17, PP, #8, lsl #12  ; [pp+0x8100] " too small to contain "
    //     0xa09104: ldr             x17, [x17, #0x100]
    // 0xa09108: StoreField: r2->field_17 = r17
    //     0xa09108: stur            w17, [x2, #0x17]
    // 0xa0910c: ldur            x4, [fp, #-0x18]
    // 0xa09110: LoadField: r0 = r4->field_7
    //     0xa09110: ldur            w0, [x4, #7]
    // 0xa09114: DecompressPointer r0
    //     0xa09114: add             x0, x0, HEAP, lsl #32
    // 0xa09118: StoreField: r2->field_1b = r0
    //     0xa09118: stur            w0, [x2, #0x1b]
    // 0xa0911c: SaveReg r2
    //     0xa0911c: str             x2, [SP, #-8]!
    // 0xa09120: r0 = _interpolate()
    //     0xa09120: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa09124: add             SP, SP, #8
    // 0xa09128: r0 = Throw()
    //     0xa09128: bl              #0xd67e38  ; ThrowStub
    // 0xa0912c: brk             #0
    // 0xa09130: r1 = Null
    //     0xa09130: mov             x1, NULL
    // 0xa09134: r2 = 4
    //     0xa09134: mov             x2, #4
    // 0xa09138: r0 = AllocateArray()
    //     0xa09138: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0913c: mov             x2, x0
    // 0xa09140: r17 = "Message has no signature but contains data of length "
    //     0xa09140: add             x17, PP, #8, lsl #12  ; [pp+0x8108] "Message has no signature but contains data of length "
    //     0xa09144: ldr             x17, [x17, #0x108]
    // 0xa09148: StoreField: r2->field_f = r17
    //     0xa09148: stur            w17, [x2, #0xf]
    // 0xa0914c: ldur            x3, [fp, #-0x28]
    // 0xa09150: r0 = BoxInt64Instr(r3)
    //     0xa09150: sbfiz           x0, x3, #1, #0x1f
    //     0xa09154: cmp             x3, x0, asr #1
    //     0xa09158: b.eq            #0xa09164
    //     0xa0915c: bl              #0xd69bb8
    //     0xa09160: stur            x3, [x0, #7]
    // 0xa09164: StoreField: r2->field_13 = r0
    //     0xa09164: stur            w0, [x2, #0x13]
    // 0xa09168: SaveReg r2
    //     0xa09168: str             x2, [SP, #-8]!
    // 0xa0916c: r0 = _interpolate()
    //     0xa0916c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa09170: add             SP, SP, #8
    // 0xa09174: r0 = Throw()
    //     0xa09174: bl              #0xd67e38  ; ThrowStub
    // 0xa09178: brk             #0
    // 0xa0917c: r0 = "Insufficient file descriptors received"
    //     0xa0917c: add             x0, PP, #8, lsl #12  ; [pp+0x8110] "Insufficient file descriptors received"
    //     0xa09180: ldr             x0, [x0, #0x110]
    // 0xa09184: r0 = Throw()
    //     0xa09184: bl              #0xd67e38  ; ThrowStub
    // 0xa09188: brk             #0
    // 0xa0918c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0918c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa09190: b               #0xa07890
    // 0xa09194: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa09194: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa09198: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa09198: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa0919c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa0919c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa091a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa091a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa091a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa091a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa091a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa091a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa091ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa091ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa091b0: b               #0xa07c98
    // 0xa091b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa091b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa091b8: b               #0xa08238
    // 0xa091bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa091bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa091c0: b               #0xa088bc
    // 0xa091c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa091c4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ readDBusValue(/* No info */) {
    // ** addr: 0xa091c8, size: 0x7dc
    // 0xa091c8: EnterFrame
    //     0xa091c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa091cc: mov             fp, SP
    // 0xa091d0: AllocStack(0x18)
    //     0xa091d0: sub             SP, SP, #0x18
    // 0xa091d4: CheckStackOverflow
    //     0xa091d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa091d8: cmp             SP, x16
    //     0xa091dc: b.ls            #0xa09994
    // 0xa091e0: ldr             x0, [fp, #0x20]
    // 0xa091e4: LoadField: r1 = r0->field_7
    //     0xa091e4: ldur            w1, [x0, #7]
    // 0xa091e8: DecompressPointer r1
    //     0xa091e8: add             x1, x1, HEAP, lsl #32
    // 0xa091ec: stur            x1, [fp, #-8]
    // 0xa091f0: r0 = LoadClassIdInstr(r1)
    //     0xa091f0: ldur            x0, [x1, #-1]
    //     0xa091f4: ubfx            x0, x0, #0xc, #0x14
    // 0xa091f8: r16 = "y"
    //     0xa091f8: ldr             x16, [PP, #0x78d0]  ; [pp+0x78d0] "y"
    // 0xa091fc: stp             x16, x1, [SP, #-0x10]!
    // 0xa09200: mov             lr, x0
    // 0xa09204: ldr             lr, [x21, lr, lsl #3]
    // 0xa09208: blr             lr
    // 0xa0920c: add             SP, SP, #0x10
    // 0xa09210: tbnz            w0, #4, #0xa09230
    // 0xa09214: ldr             x16, [fp, #0x28]
    // 0xa09218: SaveReg r16
    //     0xa09218: str             x16, [SP, #-8]!
    // 0xa0921c: r0 = readDBusByte()
    //     0xa0921c: bl              #0xa0c09c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusByte
    // 0xa09220: add             SP, SP, #8
    // 0xa09224: LeaveFrame
    //     0xa09224: mov             SP, fp
    //     0xa09228: ldp             fp, lr, [SP], #0x10
    // 0xa0922c: ret
    //     0xa0922c: ret             
    // 0xa09230: ldur            x1, [fp, #-8]
    // 0xa09234: r0 = LoadClassIdInstr(r1)
    //     0xa09234: ldur            x0, [x1, #-1]
    //     0xa09238: ubfx            x0, x0, #0xc, #0x14
    // 0xa0923c: r16 = "b"
    //     0xa0923c: ldr             x16, [PP, #0x78d8]  ; [pp+0x78d8] "b"
    // 0xa09240: stp             x16, x1, [SP, #-0x10]!
    // 0xa09244: mov             lr, x0
    // 0xa09248: ldr             lr, [x21, lr, lsl #3]
    // 0xa0924c: blr             lr
    // 0xa09250: add             SP, SP, #0x10
    // 0xa09254: tbnz            w0, #4, #0xa09278
    // 0xa09258: ldr             x16, [fp, #0x28]
    // 0xa0925c: ldr             lr, [fp, #0x18]
    // 0xa09260: stp             lr, x16, [SP, #-0x10]!
    // 0xa09264: r0 = readDBusBoolean()
    //     0xa09264: bl              #0xa0baec  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusBoolean
    // 0xa09268: add             SP, SP, #0x10
    // 0xa0926c: LeaveFrame
    //     0xa0926c: mov             SP, fp
    //     0xa09270: ldp             fp, lr, [SP], #0x10
    // 0xa09274: ret
    //     0xa09274: ret             
    // 0xa09278: ldur            x1, [fp, #-8]
    // 0xa0927c: r0 = LoadClassIdInstr(r1)
    //     0xa0927c: ldur            x0, [x1, #-1]
    //     0xa09280: ubfx            x0, x0, #0xc, #0x14
    // 0xa09284: r16 = "n"
    //     0xa09284: ldr             x16, [PP, #0x78e0]  ; [pp+0x78e0] "n"
    // 0xa09288: stp             x16, x1, [SP, #-0x10]!
    // 0xa0928c: mov             lr, x0
    // 0xa09290: ldr             lr, [x21, lr, lsl #3]
    // 0xa09294: blr             lr
    // 0xa09298: add             SP, SP, #0x10
    // 0xa0929c: tbnz            w0, #4, #0xa092c0
    // 0xa092a0: ldr             x16, [fp, #0x28]
    // 0xa092a4: ldr             lr, [fp, #0x18]
    // 0xa092a8: stp             lr, x16, [SP, #-0x10]!
    // 0xa092ac: r0 = readDBusInt16()
    //     0xa092ac: bl              #0xa0b8e4  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusInt16
    // 0xa092b0: add             SP, SP, #0x10
    // 0xa092b4: LeaveFrame
    //     0xa092b4: mov             SP, fp
    //     0xa092b8: ldp             fp, lr, [SP], #0x10
    // 0xa092bc: ret
    //     0xa092bc: ret             
    // 0xa092c0: ldur            x1, [fp, #-8]
    // 0xa092c4: r0 = LoadClassIdInstr(r1)
    //     0xa092c4: ldur            x0, [x1, #-1]
    //     0xa092c8: ubfx            x0, x0, #0xc, #0x14
    // 0xa092cc: r16 = "q"
    //     0xa092cc: ldr             x16, [PP, #0x78e8]  ; [pp+0x78e8] "q"
    // 0xa092d0: stp             x16, x1, [SP, #-0x10]!
    // 0xa092d4: mov             lr, x0
    // 0xa092d8: ldr             lr, [x21, lr, lsl #3]
    // 0xa092dc: blr             lr
    // 0xa092e0: add             SP, SP, #0x10
    // 0xa092e4: tbnz            w0, #4, #0xa09308
    // 0xa092e8: ldr             x16, [fp, #0x28]
    // 0xa092ec: ldr             lr, [fp, #0x18]
    // 0xa092f0: stp             lr, x16, [SP, #-0x10]!
    // 0xa092f4: r0 = readDBusUint16()
    //     0xa092f4: bl              #0xa0b6ec  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusUint16
    // 0xa092f8: add             SP, SP, #0x10
    // 0xa092fc: LeaveFrame
    //     0xa092fc: mov             SP, fp
    //     0xa09300: ldp             fp, lr, [SP], #0x10
    // 0xa09304: ret
    //     0xa09304: ret             
    // 0xa09308: ldur            x1, [fp, #-8]
    // 0xa0930c: r0 = LoadClassIdInstr(r1)
    //     0xa0930c: ldur            x0, [x1, #-1]
    //     0xa09310: ubfx            x0, x0, #0xc, #0x14
    // 0xa09314: r16 = "i"
    //     0xa09314: ldr             x16, [PP, #0x78f0]  ; [pp+0x78f0] "i"
    // 0xa09318: stp             x16, x1, [SP, #-0x10]!
    // 0xa0931c: mov             lr, x0
    // 0xa09320: ldr             lr, [x21, lr, lsl #3]
    // 0xa09324: blr             lr
    // 0xa09328: add             SP, SP, #0x10
    // 0xa0932c: tbnz            w0, #4, #0xa09350
    // 0xa09330: ldr             x16, [fp, #0x28]
    // 0xa09334: ldr             lr, [fp, #0x18]
    // 0xa09338: stp             lr, x16, [SP, #-0x10]!
    // 0xa0933c: r0 = readDBusInt32()
    //     0xa0933c: bl              #0xa0b4c4  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusInt32
    // 0xa09340: add             SP, SP, #0x10
    // 0xa09344: LeaveFrame
    //     0xa09344: mov             SP, fp
    //     0xa09348: ldp             fp, lr, [SP], #0x10
    // 0xa0934c: ret
    //     0xa0934c: ret             
    // 0xa09350: ldur            x1, [fp, #-8]
    // 0xa09354: r0 = LoadClassIdInstr(r1)
    //     0xa09354: ldur            x0, [x1, #-1]
    //     0xa09358: ubfx            x0, x0, #0xc, #0x14
    // 0xa0935c: r16 = "u"
    //     0xa0935c: ldr             x16, [PP, #0x78f8]  ; [pp+0x78f8] "u"
    // 0xa09360: stp             x16, x1, [SP, #-0x10]!
    // 0xa09364: mov             lr, x0
    // 0xa09368: ldr             lr, [x21, lr, lsl #3]
    // 0xa0936c: blr             lr
    // 0xa09370: add             SP, SP, #0x10
    // 0xa09374: tbnz            w0, #4, #0xa09398
    // 0xa09378: ldr             x16, [fp, #0x28]
    // 0xa0937c: ldr             lr, [fp, #0x18]
    // 0xa09380: stp             lr, x16, [SP, #-0x10]!
    // 0xa09384: r0 = readDBusUint32()
    //     0xa09384: bl              #0xa0c000  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusUint32
    // 0xa09388: add             SP, SP, #0x10
    // 0xa0938c: LeaveFrame
    //     0xa0938c: mov             SP, fp
    //     0xa09390: ldp             fp, lr, [SP], #0x10
    // 0xa09394: ret
    //     0xa09394: ret             
    // 0xa09398: ldur            x1, [fp, #-8]
    // 0xa0939c: r0 = LoadClassIdInstr(r1)
    //     0xa0939c: ldur            x0, [x1, #-1]
    //     0xa093a0: ubfx            x0, x0, #0xc, #0x14
    // 0xa093a4: r16 = "x"
    //     0xa093a4: ldr             x16, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xa093a8: stp             x16, x1, [SP, #-0x10]!
    // 0xa093ac: mov             lr, x0
    // 0xa093b0: ldr             lr, [x21, lr, lsl #3]
    // 0xa093b4: blr             lr
    // 0xa093b8: add             SP, SP, #0x10
    // 0xa093bc: tbnz            w0, #4, #0xa093e0
    // 0xa093c0: ldr             x16, [fp, #0x28]
    // 0xa093c4: ldr             lr, [fp, #0x18]
    // 0xa093c8: stp             lr, x16, [SP, #-0x10]!
    // 0xa093cc: r0 = readDBusInt64()
    //     0xa093cc: bl              #0xa0b22c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusInt64
    // 0xa093d0: add             SP, SP, #0x10
    // 0xa093d4: LeaveFrame
    //     0xa093d4: mov             SP, fp
    //     0xa093d8: ldp             fp, lr, [SP], #0x10
    // 0xa093dc: ret
    //     0xa093dc: ret             
    // 0xa093e0: ldur            x1, [fp, #-8]
    // 0xa093e4: r0 = LoadClassIdInstr(r1)
    //     0xa093e4: ldur            x0, [x1, #-1]
    //     0xa093e8: ubfx            x0, x0, #0xc, #0x14
    // 0xa093ec: r16 = "t"
    //     0xa093ec: ldr             x16, [PP, #0x7900]  ; [pp+0x7900] "t"
    // 0xa093f0: stp             x16, x1, [SP, #-0x10]!
    // 0xa093f4: mov             lr, x0
    // 0xa093f8: ldr             lr, [x21, lr, lsl #3]
    // 0xa093fc: blr             lr
    // 0xa09400: add             SP, SP, #0x10
    // 0xa09404: tbnz            w0, #4, #0xa09428
    // 0xa09408: ldr             x16, [fp, #0x28]
    // 0xa0940c: ldr             lr, [fp, #0x18]
    // 0xa09410: stp             lr, x16, [SP, #-0x10]!
    // 0xa09414: r0 = readDBusUint64()
    //     0xa09414: bl              #0xa0afa0  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusUint64
    // 0xa09418: add             SP, SP, #0x10
    // 0xa0941c: LeaveFrame
    //     0xa0941c: mov             SP, fp
    //     0xa09420: ldp             fp, lr, [SP], #0x10
    // 0xa09424: ret
    //     0xa09424: ret             
    // 0xa09428: ldur            x1, [fp, #-8]
    // 0xa0942c: r0 = LoadClassIdInstr(r1)
    //     0xa0942c: ldur            x0, [x1, #-1]
    //     0xa09430: ubfx            x0, x0, #0xc, #0x14
    // 0xa09434: r16 = "d"
    //     0xa09434: ldr             x16, [PP, #0x7908]  ; [pp+0x7908] "d"
    // 0xa09438: stp             x16, x1, [SP, #-0x10]!
    // 0xa0943c: mov             lr, x0
    // 0xa09440: ldr             lr, [x21, lr, lsl #3]
    // 0xa09444: blr             lr
    // 0xa09448: add             SP, SP, #0x10
    // 0xa0944c: tbnz            w0, #4, #0xa09470
    // 0xa09450: ldr             x16, [fp, #0x28]
    // 0xa09454: ldr             lr, [fp, #0x18]
    // 0xa09458: stp             lr, x16, [SP, #-0x10]!
    // 0xa0945c: r0 = readDBusDouble()
    //     0xa0945c: bl              #0xa0a7b8  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusDouble
    // 0xa09460: add             SP, SP, #0x10
    // 0xa09464: LeaveFrame
    //     0xa09464: mov             SP, fp
    //     0xa09468: ldp             fp, lr, [SP], #0x10
    // 0xa0946c: ret
    //     0xa0946c: ret             
    // 0xa09470: ldur            x1, [fp, #-8]
    // 0xa09474: r0 = LoadClassIdInstr(r1)
    //     0xa09474: ldur            x0, [x1, #-1]
    //     0xa09478: ubfx            x0, x0, #0xc, #0x14
    // 0xa0947c: r16 = "s"
    //     0xa0947c: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa09480: stp             x16, x1, [SP, #-0x10]!
    // 0xa09484: mov             lr, x0
    // 0xa09488: ldr             lr, [x21, lr, lsl #3]
    // 0xa0948c: blr             lr
    // 0xa09490: add             SP, SP, #0x10
    // 0xa09494: tbnz            w0, #4, #0xa094b8
    // 0xa09498: ldr             x16, [fp, #0x28]
    // 0xa0949c: ldr             lr, [fp, #0x18]
    // 0xa094a0: stp             lr, x16, [SP, #-0x10]!
    // 0xa094a4: r0 = readDBusString()
    //     0xa094a4: bl              #0xa0a670  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusString
    // 0xa094a8: add             SP, SP, #0x10
    // 0xa094ac: LeaveFrame
    //     0xa094ac: mov             SP, fp
    //     0xa094b0: ldp             fp, lr, [SP], #0x10
    // 0xa094b4: ret
    //     0xa094b4: ret             
    // 0xa094b8: ldur            x1, [fp, #-8]
    // 0xa094bc: r0 = LoadClassIdInstr(r1)
    //     0xa094bc: ldur            x0, [x1, #-1]
    //     0xa094c0: ubfx            x0, x0, #0xc, #0x14
    // 0xa094c4: r16 = "o"
    //     0xa094c4: ldr             x16, [PP, #0x7690]  ; [pp+0x7690] "o"
    // 0xa094c8: stp             x16, x1, [SP, #-0x10]!
    // 0xa094cc: mov             lr, x0
    // 0xa094d0: ldr             lr, [x21, lr, lsl #3]
    // 0xa094d4: blr             lr
    // 0xa094d8: add             SP, SP, #0x10
    // 0xa094dc: tbnz            w0, #4, #0xa09500
    // 0xa094e0: ldr             x16, [fp, #0x28]
    // 0xa094e4: ldr             lr, [fp, #0x18]
    // 0xa094e8: stp             lr, x16, [SP, #-0x10]!
    // 0xa094ec: r0 = readDBusObjectPath()
    //     0xa094ec: bl              #0xa0a5f0  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusObjectPath
    // 0xa094f0: add             SP, SP, #0x10
    // 0xa094f4: LeaveFrame
    //     0xa094f4: mov             SP, fp
    //     0xa094f8: ldp             fp, lr, [SP], #0x10
    // 0xa094fc: ret
    //     0xa094fc: ret             
    // 0xa09500: ldur            x1, [fp, #-8]
    // 0xa09504: r0 = LoadClassIdInstr(r1)
    //     0xa09504: ldur            x0, [x1, #-1]
    //     0xa09508: ubfx            x0, x0, #0xc, #0x14
    // 0xa0950c: r16 = "g"
    //     0xa0950c: ldr             x16, [PP, #0x76a0]  ; [pp+0x76a0] "g"
    // 0xa09510: stp             x16, x1, [SP, #-0x10]!
    // 0xa09514: mov             lr, x0
    // 0xa09518: ldr             lr, [x21, lr, lsl #3]
    // 0xa0951c: blr             lr
    // 0xa09520: add             SP, SP, #0x10
    // 0xa09524: tbnz            w0, #4, #0xa09544
    // 0xa09528: ldr             x16, [fp, #0x28]
    // 0xa0952c: SaveReg r16
    //     0xa0952c: str             x16, [SP, #-8]!
    // 0xa09530: r0 = readDBusSignature()
    //     0xa09530: bl              #0xa0a3e0  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusSignature
    // 0xa09534: add             SP, SP, #8
    // 0xa09538: LeaveFrame
    //     0xa09538: mov             SP, fp
    //     0xa0953c: ldp             fp, lr, [SP], #0x10
    // 0xa09540: ret
    //     0xa09540: ret             
    // 0xa09544: ldur            x1, [fp, #-8]
    // 0xa09548: r0 = LoadClassIdInstr(r1)
    //     0xa09548: ldur            x0, [x1, #-1]
    //     0xa0954c: ubfx            x0, x0, #0xc, #0x14
    // 0xa09550: r16 = "v"
    //     0xa09550: ldr             x16, [PP, #0x7910]  ; [pp+0x7910] "v"
    // 0xa09554: stp             x16, x1, [SP, #-0x10]!
    // 0xa09558: mov             lr, x0
    // 0xa0955c: ldr             lr, [x21, lr, lsl #3]
    // 0xa09560: blr             lr
    // 0xa09564: add             SP, SP, #0x10
    // 0xa09568: tbnz            w0, #4, #0xa09594
    // 0xa0956c: ldr             x1, [fp, #0x10]
    // 0xa09570: ldr             x16, [fp, #0x28]
    // 0xa09574: ldr             lr, [fp, #0x18]
    // 0xa09578: stp             lr, x16, [SP, #-0x10]!
    // 0xa0957c: SaveReg r1
    //     0xa0957c: str             x1, [SP, #-8]!
    // 0xa09580: r0 = readDBusVariant()
    //     0xa09580: bl              #0xa0a348  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusVariant
    // 0xa09584: add             SP, SP, #0x18
    // 0xa09588: LeaveFrame
    //     0xa09588: mov             SP, fp
    //     0xa0958c: ldp             fp, lr, [SP], #0x10
    // 0xa09590: ret
    //     0xa09590: ret             
    // 0xa09594: ldr             x1, [fp, #0x10]
    // 0xa09598: ldur            x2, [fp, #-8]
    // 0xa0959c: r0 = LoadClassIdInstr(r2)
    //     0xa0959c: ldur            x0, [x2, #-1]
    //     0xa095a0: ubfx            x0, x0, #0xc, #0x14
    // 0xa095a4: r16 = "m"
    //     0xa095a4: ldr             x16, [PP, #0x448]  ; [pp+0x448] "m"
    // 0xa095a8: stp             x16, x2, [SP, #-0x10]!
    // 0xa095ac: mov             lr, x0
    // 0xa095b0: ldr             lr, [x21, lr, lsl #3]
    // 0xa095b4: blr             lr
    // 0xa095b8: add             SP, SP, #0x10
    // 0xa095bc: tbz             w0, #4, #0xa098bc
    // 0xa095c0: ldur            x1, [fp, #-8]
    // 0xa095c4: r0 = LoadClassIdInstr(r1)
    //     0xa095c4: ldur            x0, [x1, #-1]
    //     0xa095c8: ubfx            x0, x0, #0xc, #0x14
    // 0xa095cc: r16 = "h"
    //     0xa095cc: ldr             x16, [PP, #0x7918]  ; [pp+0x7918] "h"
    // 0xa095d0: stp             x16, x1, [SP, #-0x10]!
    // 0xa095d4: mov             lr, x0
    // 0xa095d8: ldr             lr, [x21, lr, lsl #3]
    // 0xa095dc: blr             lr
    // 0xa095e0: add             SP, SP, #0x10
    // 0xa095e4: tbnz            w0, #4, #0xa09610
    // 0xa095e8: ldr             x0, [fp, #0x10]
    // 0xa095ec: ldr             x16, [fp, #0x28]
    // 0xa095f0: stp             x0, x16, [SP, #-0x10]!
    // 0xa095f4: ldr             x16, [fp, #0x18]
    // 0xa095f8: SaveReg r16
    //     0xa095f8: str             x16, [SP, #-8]!
    // 0xa095fc: r0 = readDBusUnixFd()
    //     0xa095fc: bl              #0xa0a1f8  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusUnixFd
    // 0xa09600: add             SP, SP, #0x18
    // 0xa09604: LeaveFrame
    //     0xa09604: mov             SP, fp
    //     0xa09608: ldp             fp, lr, [SP], #0x10
    // 0xa0960c: ret
    //     0xa0960c: ret             
    // 0xa09610: ldr             x0, [fp, #0x10]
    // 0xa09614: ldur            x16, [fp, #-8]
    // 0xa09618: r30 = "a{"
    //     0xa09618: ldr             lr, [PP, #0x428]  ; [pp+0x428] "a{"
    // 0xa0961c: stp             lr, x16, [SP, #-0x10]!
    // 0xa09620: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa09620: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa09624: r0 = startsWith()
    //     0xa09624: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0xa09628: add             SP, SP, #0x10
    // 0xa0962c: tbnz            w0, #4, #0xa0974c
    // 0xa09630: ldur            x16, [fp, #-8]
    // 0xa09634: r30 = "}"
    //     0xa09634: ldr             lr, [PP, #0x438]  ; [pp+0x438] "}"
    // 0xa09638: stp             lr, x16, [SP, #-0x10]!
    // 0xa0963c: r0 = endsWith()
    //     0xa0963c: bl              #0x52b7ec  ; [dart:core] _StringBase::endsWith
    // 0xa09640: add             SP, SP, #0x10
    // 0xa09644: tbnz            w0, #4, #0xa09740
    // 0xa09648: ldur            x0, [fp, #-8]
    // 0xa0964c: r1 = 2
    //     0xa0964c: mov             x1, #2
    // 0xa09650: LoadField: r2 = r0->field_7
    //     0xa09650: ldur            w2, [x0, #7]
    // 0xa09654: DecompressPointer r2
    //     0xa09654: add             x2, x2, HEAP, lsl #32
    // 0xa09658: r3 = LoadInt32Instr(r2)
    //     0xa09658: sbfx            x3, x2, #1, #0x1f
    // 0xa0965c: sub             x2, x3, #1
    // 0xa09660: lsl             x3, x2, #1
    // 0xa09664: stp             x1, x0, [SP, #-0x10]!
    // 0xa09668: SaveReg r3
    //     0xa09668: str             x3, [SP, #-8]!
    // 0xa0966c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa0966c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa09670: r0 = substring()
    //     0xa09670: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xa09674: add             SP, SP, #0x18
    // 0xa09678: stur            x0, [fp, #-0x10]
    // 0xa0967c: r0 = DBusSignature()
    //     0xa0967c: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa09680: stur            x0, [fp, #-0x18]
    // 0xa09684: ldur            x16, [fp, #-0x10]
    // 0xa09688: stp             x16, x0, [SP, #-0x10]!
    // 0xa0968c: r0 = DBusSignature()
    //     0xa0968c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa09690: add             SP, SP, #0x10
    // 0xa09694: ldur            x16, [fp, #-0x18]
    // 0xa09698: SaveReg r16
    //     0xa09698: str             x16, [SP, #-8]!
    // 0xa0969c: r0 = split()
    //     0xa0969c: bl              #0x9fd454  ; [package:dbus/src/dbus_value.dart] DBusSignature::split
    // 0xa096a0: add             SP, SP, #8
    // 0xa096a4: mov             x2, x0
    // 0xa096a8: LoadField: r0 = r2->field_b
    //     0xa096a8: ldur            w0, [x2, #0xb]
    // 0xa096ac: DecompressPointer r0
    //     0xa096ac: add             x0, x0, HEAP, lsl #32
    // 0xa096b0: cmp             w0, #4
    // 0xa096b4: b.ne            #0xa098cc
    // 0xa096b8: r3 = LoadInt32Instr(r0)
    //     0xa096b8: sbfx            x3, x0, #1, #0x1f
    // 0xa096bc: mov             x0, x3
    // 0xa096c0: r1 = 0
    //     0xa096c0: mov             x1, #0
    // 0xa096c4: cmp             x1, x0
    // 0xa096c8: b.hs            #0xa0999c
    // 0xa096cc: LoadField: r4 = r2->field_f
    //     0xa096cc: ldur            w4, [x2, #0xf]
    // 0xa096d0: DecompressPointer r4
    //     0xa096d0: add             x4, x4, HEAP, lsl #32
    // 0xa096d4: LoadField: r2 = r4->field_f
    //     0xa096d4: ldur            w2, [x4, #0xf]
    // 0xa096d8: DecompressPointer r2
    //     0xa096d8: add             x2, x2, HEAP, lsl #32
    // 0xa096dc: mov             x0, x3
    // 0xa096e0: stur            x2, [fp, #-0x18]
    // 0xa096e4: r1 = 1
    //     0xa096e4: mov             x1, #1
    // 0xa096e8: cmp             x1, x0
    // 0xa096ec: b.hs            #0xa099a0
    // 0xa096f0: LoadField: r0 = r4->field_13
    //     0xa096f0: ldur            w0, [x4, #0x13]
    // 0xa096f4: DecompressPointer r0
    //     0xa096f4: add             x0, x0, HEAP, lsl #32
    // 0xa096f8: stur            x0, [fp, #-0x10]
    // 0xa096fc: SaveReg r2
    //     0xa096fc: str             x2, [SP, #-8]!
    // 0xa09700: r0 = isBasic()
    //     0xa09700: bl              #0xa01514  ; [package:dbus/src/dbus_value.dart] DBusSignature::isBasic
    // 0xa09704: add             SP, SP, #8
    // 0xa09708: tbnz            w0, #4, #0xa0990c
    // 0xa0970c: ldr             x2, [fp, #0x10]
    // 0xa09710: ldur            x1, [fp, #-0x18]
    // 0xa09714: ldr             x16, [fp, #0x28]
    // 0xa09718: stp             x1, x16, [SP, #-0x10]!
    // 0xa0971c: ldur            x16, [fp, #-0x10]
    // 0xa09720: ldr             lr, [fp, #0x18]
    // 0xa09724: stp             lr, x16, [SP, #-0x10]!
    // 0xa09728: SaveReg r2
    //     0xa09728: str             x2, [SP, #-8]!
    // 0xa0972c: r0 = readDBusDict()
    //     0xa0972c: bl              #0xa09c44  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusDict
    // 0xa09730: add             SP, SP, #0x28
    // 0xa09734: LeaveFrame
    //     0xa09734: mov             SP, fp
    //     0xa09738: ldp             fp, lr, [SP], #0x10
    // 0xa0973c: ret
    //     0xa0973c: ret             
    // 0xa09740: ldr             x2, [fp, #0x10]
    // 0xa09744: ldur            x0, [fp, #-8]
    // 0xa09748: b               #0xa09754
    // 0xa0974c: ldr             x2, [fp, #0x10]
    // 0xa09750: ldur            x0, [fp, #-8]
    // 0xa09754: r16 = "a"
    //     0xa09754: ldr             x16, [PP, #0x440]  ; [pp+0x440] "a"
    // 0xa09758: stp             x16, x0, [SP, #-0x10]!
    // 0xa0975c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0975c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa09760: r0 = startsWith()
    //     0xa09760: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0xa09764: add             SP, SP, #0x10
    // 0xa09768: tbnz            w0, #4, #0xa097f4
    // 0xa0976c: ldr             x1, [fp, #0x10]
    // 0xa09770: ldur            x0, [fp, #-8]
    // 0xa09774: r2 = 1
    //     0xa09774: mov             x2, #1
    // 0xa09778: LoadField: r3 = r0->field_7
    //     0xa09778: ldur            w3, [x0, #7]
    // 0xa0977c: DecompressPointer r3
    //     0xa0977c: add             x3, x3, HEAP, lsl #32
    // 0xa09780: stp             x2, x0, [SP, #-0x10]!
    // 0xa09784: SaveReg r3
    //     0xa09784: str             x3, [SP, #-8]!
    // 0xa09788: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa09788: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa0978c: r0 = substring()
    //     0xa0978c: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xa09790: add             SP, SP, #0x18
    // 0xa09794: stur            x0, [fp, #-0x10]
    // 0xa09798: r0 = DBusSignature()
    //     0xa09798: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa0979c: stur            x0, [fp, #-0x18]
    // 0xa097a0: ldur            x16, [fp, #-0x10]
    // 0xa097a4: stp             x16, x0, [SP, #-0x10]!
    // 0xa097a8: r0 = DBusSignature()
    //     0xa097a8: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa097ac: add             SP, SP, #0x10
    // 0xa097b0: ldr             x3, [fp, #0x10]
    // 0xa097b4: r0 = BoxInt64Instr(r3)
    //     0xa097b4: sbfiz           x0, x3, #1, #0x1f
    //     0xa097b8: cmp             x3, x0, asr #1
    //     0xa097bc: b.eq            #0xa097c8
    //     0xa097c0: bl              #0xd69bb8
    //     0xa097c4: stur            x3, [x0, #7]
    // 0xa097c8: ldr             x16, [fp, #0x28]
    // 0xa097cc: ldur            lr, [fp, #-0x18]
    // 0xa097d0: stp             lr, x16, [SP, #-0x10]!
    // 0xa097d4: ldr             x16, [fp, #0x18]
    // 0xa097d8: stp             x0, x16, [SP, #-0x10]!
    // 0xa097dc: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xa097dc: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xa097e0: r0 = readDBusArray()
    //     0xa097e0: bl              #0xa0bddc  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusArray
    // 0xa097e4: add             SP, SP, #0x20
    // 0xa097e8: LeaveFrame
    //     0xa097e8: mov             SP, fp
    //     0xa097ec: ldp             fp, lr, [SP], #0x10
    // 0xa097f0: ret
    //     0xa097f0: ret             
    // 0xa097f4: ldr             x3, [fp, #0x10]
    // 0xa097f8: ldur            x0, [fp, #-8]
    // 0xa097fc: r2 = 1
    //     0xa097fc: mov             x2, #1
    // 0xa09800: r16 = "("
    //     0xa09800: ldr             x16, [PP, #0x418]  ; [pp+0x418] "("
    // 0xa09804: stp             x16, x0, [SP, #-0x10]!
    // 0xa09808: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa09808: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0980c: r0 = startsWith()
    //     0xa0980c: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0xa09810: add             SP, SP, #0x10
    // 0xa09814: tbnz            w0, #4, #0xa09954
    // 0xa09818: ldur            x16, [fp, #-8]
    // 0xa0981c: r30 = ")"
    //     0xa0981c: ldr             lr, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xa09820: stp             lr, x16, [SP, #-0x10]!
    // 0xa09824: r0 = endsWith()
    //     0xa09824: bl              #0x52b7ec  ; [dart:core] _StringBase::endsWith
    // 0xa09828: add             SP, SP, #0x10
    // 0xa0982c: tbnz            w0, #4, #0xa0994c
    // 0xa09830: ldr             x2, [fp, #0x10]
    // 0xa09834: ldur            x0, [fp, #-8]
    // 0xa09838: r1 = 1
    //     0xa09838: mov             x1, #1
    // 0xa0983c: LoadField: r3 = r0->field_7
    //     0xa0983c: ldur            w3, [x0, #7]
    // 0xa09840: DecompressPointer r3
    //     0xa09840: add             x3, x3, HEAP, lsl #32
    // 0xa09844: r4 = LoadInt32Instr(r3)
    //     0xa09844: sbfx            x4, x3, #1, #0x1f
    // 0xa09848: sub             x3, x4, #1
    // 0xa0984c: lsl             x4, x3, #1
    // 0xa09850: stp             x1, x0, [SP, #-0x10]!
    // 0xa09854: SaveReg r4
    //     0xa09854: str             x4, [SP, #-8]!
    // 0xa09858: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa09858: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa0985c: r0 = substring()
    //     0xa0985c: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xa09860: add             SP, SP, #0x18
    // 0xa09864: stur            x0, [fp, #-0x10]
    // 0xa09868: r0 = DBusSignature()
    //     0xa09868: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa0986c: stur            x0, [fp, #-0x18]
    // 0xa09870: ldur            x16, [fp, #-0x10]
    // 0xa09874: stp             x16, x0, [SP, #-0x10]!
    // 0xa09878: r0 = DBusSignature()
    //     0xa09878: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa0987c: add             SP, SP, #0x10
    // 0xa09880: ldur            x16, [fp, #-0x18]
    // 0xa09884: SaveReg r16
    //     0xa09884: str             x16, [SP, #-8]!
    // 0xa09888: r0 = split()
    //     0xa09888: bl              #0x9fd454  ; [package:dbus/src/dbus_value.dart] DBusSignature::split
    // 0xa0988c: add             SP, SP, #8
    // 0xa09890: ldr             x16, [fp, #0x28]
    // 0xa09894: stp             x0, x16, [SP, #-0x10]!
    // 0xa09898: ldr             x16, [fp, #0x18]
    // 0xa0989c: SaveReg r16
    //     0xa0989c: str             x16, [SP, #-8]!
    // 0xa098a0: ldr             x0, [fp, #0x10]
    // 0xa098a4: SaveReg r0
    //     0xa098a4: str             x0, [SP, #-8]!
    // 0xa098a8: r0 = readDBusStruct()
    //     0xa098a8: bl              #0xa099a4  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusStruct
    // 0xa098ac: add             SP, SP, #0x20
    // 0xa098b0: LeaveFrame
    //     0xa098b0: mov             SP, fp
    //     0xa098b4: ldp             fp, lr, [SP], #0x10
    // 0xa098b8: ret
    //     0xa098b8: ret             
    // 0xa098bc: r0 = "D-Bus reserved maybe type not valid"
    //     0xa098bc: add             x0, PP, #8, lsl #12  ; [pp+0x8138] "D-Bus reserved maybe type not valid"
    //     0xa098c0: ldr             x0, [x0, #0x138]
    // 0xa098c4: r0 = Throw()
    //     0xa098c4: bl              #0xd67e38  ; ThrowStub
    // 0xa098c8: brk             #0
    // 0xa098cc: ldur            x0, [fp, #-0x18]
    // 0xa098d0: r1 = Null
    //     0xa098d0: mov             x1, NULL
    // 0xa098d4: r2 = 4
    //     0xa098d4: mov             x2, #4
    // 0xa098d8: r0 = AllocateArray()
    //     0xa098d8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa098dc: r17 = "Invalid dict signature "
    //     0xa098dc: add             x17, PP, #8, lsl #12  ; [pp+0x8140] "Invalid dict signature "
    //     0xa098e0: ldr             x17, [x17, #0x140]
    // 0xa098e4: StoreField: r0->field_f = r17
    //     0xa098e4: stur            w17, [x0, #0xf]
    // 0xa098e8: ldur            x1, [fp, #-0x18]
    // 0xa098ec: LoadField: r2 = r1->field_7
    //     0xa098ec: ldur            w2, [x1, #7]
    // 0xa098f0: DecompressPointer r2
    //     0xa098f0: add             x2, x2, HEAP, lsl #32
    // 0xa098f4: StoreField: r0->field_13 = r2
    //     0xa098f4: stur            w2, [x0, #0x13]
    // 0xa098f8: SaveReg r0
    //     0xa098f8: str             x0, [SP, #-8]!
    // 0xa098fc: r0 = _interpolate()
    //     0xa098fc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa09900: add             SP, SP, #8
    // 0xa09904: r0 = Throw()
    //     0xa09904: bl              #0xd67e38  ; ThrowStub
    // 0xa09908: brk             #0
    // 0xa0990c: ldur            x0, [fp, #-0x18]
    // 0xa09910: r1 = Null
    //     0xa09910: mov             x1, NULL
    // 0xa09914: r2 = 4
    //     0xa09914: mov             x2, #4
    // 0xa09918: r0 = AllocateArray()
    //     0xa09918: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0991c: r17 = "Invalid dict key signature "
    //     0xa0991c: add             x17, PP, #8, lsl #12  ; [pp+0x8148] "Invalid dict key signature "
    //     0xa09920: ldr             x17, [x17, #0x148]
    // 0xa09924: StoreField: r0->field_f = r17
    //     0xa09924: stur            w17, [x0, #0xf]
    // 0xa09928: ldur            x1, [fp, #-0x18]
    // 0xa0992c: LoadField: r2 = r1->field_7
    //     0xa0992c: ldur            w2, [x1, #7]
    // 0xa09930: DecompressPointer r2
    //     0xa09930: add             x2, x2, HEAP, lsl #32
    // 0xa09934: StoreField: r0->field_13 = r2
    //     0xa09934: stur            w2, [x0, #0x13]
    // 0xa09938: SaveReg r0
    //     0xa09938: str             x0, [SP, #-8]!
    // 0xa0993c: r0 = _interpolate()
    //     0xa0993c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa09940: add             SP, SP, #8
    // 0xa09944: r0 = Throw()
    //     0xa09944: bl              #0xd67e38  ; ThrowStub
    // 0xa09948: brk             #0
    // 0xa0994c: ldur            x0, [fp, #-8]
    // 0xa09950: b               #0xa09958
    // 0xa09954: ldur            x0, [fp, #-8]
    // 0xa09958: r1 = Null
    //     0xa09958: mov             x1, NULL
    // 0xa0995c: r2 = 6
    //     0xa0995c: mov             x2, #6
    // 0xa09960: r0 = AllocateArray()
    //     0xa09960: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa09964: r17 = "Unknown D-Bus data type \'"
    //     0xa09964: add             x17, PP, #8, lsl #12  ; [pp+0x8150] "Unknown D-Bus data type \'"
    //     0xa09968: ldr             x17, [x17, #0x150]
    // 0xa0996c: StoreField: r0->field_f = r17
    //     0xa0996c: stur            w17, [x0, #0xf]
    // 0xa09970: ldur            x1, [fp, #-8]
    // 0xa09974: StoreField: r0->field_13 = r1
    //     0xa09974: stur            w1, [x0, #0x13]
    // 0xa09978: r17 = "\'"
    //     0xa09978: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xa0997c: StoreField: r0->field_17 = r17
    //     0xa0997c: stur            w17, [x0, #0x17]
    // 0xa09980: SaveReg r0
    //     0xa09980: str             x0, [SP, #-8]!
    // 0xa09984: r0 = _interpolate()
    //     0xa09984: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa09988: add             SP, SP, #8
    // 0xa0998c: r0 = Throw()
    //     0xa0998c: bl              #0xd67e38  ; ThrowStub
    // 0xa09990: brk             #0
    // 0xa09994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa09994: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa09998: b               #0xa091e0
    // 0xa0999c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0999c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa099a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa099a0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ readDBusStruct(/* No info */) {
    // ** addr: 0xa099a4, size: 0x2a0
    // 0xa099a4: EnterFrame
    //     0xa099a4: stp             fp, lr, [SP, #-0x10]!
    //     0xa099a8: mov             fp, SP
    // 0xa099ac: AllocStack(0x38)
    //     0xa099ac: sub             SP, SP, #0x38
    // 0xa099b0: r0 = 8
    //     0xa099b0: mov             x0, #8
    // 0xa099b4: CheckStackOverflow
    //     0xa099b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa099b8: cmp             SP, x16
    //     0xa099bc: b.ls            #0xa09c30
    // 0xa099c0: ldr             x16, [fp, #0x28]
    // 0xa099c4: stp             x0, x16, [SP, #-0x10]!
    // 0xa099c8: r0 = align()
    //     0xa099c8: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa099cc: add             SP, SP, #0x10
    // 0xa099d0: tbz             w0, #4, #0xa099e4
    // 0xa099d4: r0 = Null
    //     0xa099d4: mov             x0, NULL
    // 0xa099d8: LeaveFrame
    //     0xa099d8: mov             SP, fp
    //     0xa099dc: ldp             fp, lr, [SP], #0x10
    // 0xa099e0: ret
    //     0xa099e0: ret             
    // 0xa099e4: ldr             x0, [fp, #0x20]
    // 0xa099e8: r16 = <DBusValue>
    //     0xa099e8: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa099ec: stp             xzr, x16, [SP, #-0x10]!
    // 0xa099f0: r0 = _GrowableList()
    //     0xa099f0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa099f4: add             SP, SP, #0x10
    // 0xa099f8: mov             x2, x0
    // 0xa099fc: ldr             x1, [fp, #0x20]
    // 0xa09a00: stur            x2, [fp, #-0x20]
    // 0xa09a04: LoadField: r3 = r1->field_7
    //     0xa09a04: ldur            w3, [x1, #7]
    // 0xa09a08: DecompressPointer r3
    //     0xa09a08: add             x3, x3, HEAP, lsl #32
    // 0xa09a0c: stur            x3, [fp, #-0x18]
    // 0xa09a10: LoadField: r0 = r1->field_b
    //     0xa09a10: ldur            w0, [x1, #0xb]
    // 0xa09a14: DecompressPointer r0
    //     0xa09a14: add             x0, x0, HEAP, lsl #32
    // 0xa09a18: r4 = LoadInt32Instr(r0)
    //     0xa09a18: sbfx            x4, x0, #1, #0x1f
    // 0xa09a1c: stur            x4, [fp, #-0x10]
    // 0xa09a20: r6 = 0
    //     0xa09a20: mov             x6, #0
    // 0xa09a24: ldr             x5, [fp, #0x10]
    // 0xa09a28: stur            x6, [fp, #-8]
    // 0xa09a2c: CheckStackOverflow
    //     0xa09a2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa09a30: cmp             SP, x16
    //     0xa09a34: b.ls            #0xa09c38
    // 0xa09a38: r0 = LoadClassIdInstr(r1)
    //     0xa09a38: ldur            x0, [x1, #-1]
    //     0xa09a3c: ubfx            x0, x0, #0xc, #0x14
    // 0xa09a40: SaveReg r1
    //     0xa09a40: str             x1, [SP, #-8]!
    // 0xa09a44: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa09a44: mov             x17, #0xb8ea
    //     0xa09a48: add             lr, x0, x17
    //     0xa09a4c: ldr             lr, [x21, lr, lsl #3]
    //     0xa09a50: blr             lr
    // 0xa09a54: add             SP, SP, #8
    // 0xa09a58: r1 = LoadInt32Instr(r0)
    //     0xa09a58: sbfx            x1, x0, #1, #0x1f
    //     0xa09a5c: tbz             w0, #0, #0xa09a64
    //     0xa09a60: ldur            x1, [x0, #7]
    // 0xa09a64: ldur            x2, [fp, #-0x10]
    // 0xa09a68: cmp             x2, x1
    // 0xa09a6c: b.ne            #0xa09c18
    // 0xa09a70: ldr             x3, [fp, #0x20]
    // 0xa09a74: ldur            x4, [fp, #-8]
    // 0xa09a78: cmp             x4, x1
    // 0xa09a7c: b.lt            #0xa09ab8
    // 0xa09a80: ldur            x16, [fp, #-0x20]
    // 0xa09a84: SaveReg r16
    //     0xa09a84: str             x16, [SP, #-8]!
    // 0xa09a88: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa09a88: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa09a8c: r0 = toList()
    //     0xa09a8c: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0xa09a90: add             SP, SP, #8
    // 0xa09a94: stur            x0, [fp, #-0x28]
    // 0xa09a98: r0 = DBusStruct()
    //     0xa09a98: bl              #0xa00638  ; AllocateDBusStructStub -> DBusStruct (size=0xc)
    // 0xa09a9c: mov             x1, x0
    // 0xa09aa0: ldur            x0, [fp, #-0x28]
    // 0xa09aa4: StoreField: r1->field_7 = r0
    //     0xa09aa4: stur            w0, [x1, #7]
    // 0xa09aa8: mov             x0, x1
    // 0xa09aac: LeaveFrame
    //     0xa09aac: mov             SP, fp
    //     0xa09ab0: ldp             fp, lr, [SP], #0x10
    // 0xa09ab4: ret
    //     0xa09ab4: ret             
    // 0xa09ab8: r0 = BoxInt64Instr(r4)
    //     0xa09ab8: sbfiz           x0, x4, #1, #0x1f
    //     0xa09abc: cmp             x4, x0, asr #1
    //     0xa09ac0: b.eq            #0xa09acc
    //     0xa09ac4: bl              #0xd69bb8
    //     0xa09ac8: stur            x4, [x0, #7]
    // 0xa09acc: r1 = LoadClassIdInstr(r3)
    //     0xa09acc: ldur            x1, [x3, #-1]
    //     0xa09ad0: ubfx            x1, x1, #0xc, #0x14
    // 0xa09ad4: stp             x0, x3, [SP, #-0x10]!
    // 0xa09ad8: mov             x0, x1
    // 0xa09adc: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa09adc: mov             x17, #0xd175
    //     0xa09ae0: add             lr, x0, x17
    //     0xa09ae4: ldr             lr, [x21, lr, lsl #3]
    //     0xa09ae8: blr             lr
    // 0xa09aec: add             SP, SP, #0x10
    // 0xa09af0: mov             x3, x0
    // 0xa09af4: ldur            x0, [fp, #-8]
    // 0xa09af8: stur            x3, [fp, #-0x28]
    // 0xa09afc: add             x6, x0, #1
    // 0xa09b00: stur            x6, [fp, #-0x30]
    // 0xa09b04: cmp             w3, NULL
    // 0xa09b08: b.ne            #0xa09b3c
    // 0xa09b0c: mov             x0, x3
    // 0xa09b10: ldur            x2, [fp, #-0x18]
    // 0xa09b14: r1 = Null
    //     0xa09b14: mov             x1, NULL
    // 0xa09b18: cmp             w2, NULL
    // 0xa09b1c: b.eq            #0xa09b3c
    // 0xa09b20: LoadField: r4 = r2->field_17
    //     0xa09b20: ldur            w4, [x2, #0x17]
    // 0xa09b24: DecompressPointer r4
    //     0xa09b24: add             x4, x4, HEAP, lsl #32
    // 0xa09b28: r8 = X0
    //     0xa09b28: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa09b2c: LoadField: r9 = r4->field_7
    //     0xa09b2c: ldur            x9, [x4, #7]
    // 0xa09b30: r3 = Null
    //     0xa09b30: add             x3, PP, #8, lsl #12  ; [pp+0x8158] Null
    //     0xa09b34: ldr             x3, [x3, #0x158]
    // 0xa09b38: blr             x9
    // 0xa09b3c: ldr             x0, [fp, #0x10]
    // 0xa09b40: ldr             x16, [fp, #0x28]
    // 0xa09b44: ldur            lr, [fp, #-0x28]
    // 0xa09b48: stp             lr, x16, [SP, #-0x10]!
    // 0xa09b4c: ldr             x16, [fp, #0x18]
    // 0xa09b50: stp             x0, x16, [SP, #-0x10]!
    // 0xa09b54: r0 = readDBusValue()
    //     0xa09b54: bl              #0xa091c8  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusValue
    // 0xa09b58: add             SP, SP, #0x20
    // 0xa09b5c: stur            x0, [fp, #-0x38]
    // 0xa09b60: cmp             w0, NULL
    // 0xa09b64: b.ne            #0xa09b78
    // 0xa09b68: r0 = Null
    //     0xa09b68: mov             x0, NULL
    // 0xa09b6c: LeaveFrame
    //     0xa09b6c: mov             SP, fp
    //     0xa09b70: ldp             fp, lr, [SP], #0x10
    // 0xa09b74: ret
    //     0xa09b74: ret             
    // 0xa09b78: ldur            x1, [fp, #-0x20]
    // 0xa09b7c: LoadField: r2 = r1->field_b
    //     0xa09b7c: ldur            w2, [x1, #0xb]
    // 0xa09b80: DecompressPointer r2
    //     0xa09b80: add             x2, x2, HEAP, lsl #32
    // 0xa09b84: stur            x2, [fp, #-0x28]
    // 0xa09b88: LoadField: r3 = r1->field_f
    //     0xa09b88: ldur            w3, [x1, #0xf]
    // 0xa09b8c: DecompressPointer r3
    //     0xa09b8c: add             x3, x3, HEAP, lsl #32
    // 0xa09b90: LoadField: r4 = r3->field_b
    //     0xa09b90: ldur            w4, [x3, #0xb]
    // 0xa09b94: DecompressPointer r4
    //     0xa09b94: add             x4, x4, HEAP, lsl #32
    // 0xa09b98: cmp             w2, w4
    // 0xa09b9c: b.ne            #0xa09bac
    // 0xa09ba0: SaveReg r1
    //     0xa09ba0: str             x1, [SP, #-8]!
    // 0xa09ba4: r0 = _growToNextCapacity()
    //     0xa09ba4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa09ba8: add             SP, SP, #8
    // 0xa09bac: ldur            x2, [fp, #-0x20]
    // 0xa09bb0: ldur            x3, [fp, #-0x28]
    // 0xa09bb4: r4 = LoadInt32Instr(r3)
    //     0xa09bb4: sbfx            x4, x3, #1, #0x1f
    // 0xa09bb8: add             x0, x4, #1
    // 0xa09bbc: lsl             x3, x0, #1
    // 0xa09bc0: StoreField: r2->field_b = r3
    //     0xa09bc0: stur            w3, [x2, #0xb]
    // 0xa09bc4: mov             x1, x4
    // 0xa09bc8: cmp             x1, x0
    // 0xa09bcc: b.hs            #0xa09c40
    // 0xa09bd0: LoadField: r1 = r2->field_f
    //     0xa09bd0: ldur            w1, [x2, #0xf]
    // 0xa09bd4: DecompressPointer r1
    //     0xa09bd4: add             x1, x1, HEAP, lsl #32
    // 0xa09bd8: ldur            x0, [fp, #-0x38]
    // 0xa09bdc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xa09bdc: add             x25, x1, x4, lsl #2
    //     0xa09be0: add             x25, x25, #0xf
    //     0xa09be4: str             w0, [x25]
    //     0xa09be8: tbz             w0, #0, #0xa09c04
    //     0xa09bec: ldurb           w16, [x1, #-1]
    //     0xa09bf0: ldurb           w17, [x0, #-1]
    //     0xa09bf4: and             x16, x17, x16, lsr #2
    //     0xa09bf8: tst             x16, HEAP, lsr #32
    //     0xa09bfc: b.eq            #0xa09c04
    //     0xa09c00: bl              #0xd67e5c
    // 0xa09c04: ldur            x6, [fp, #-0x30]
    // 0xa09c08: ldr             x1, [fp, #0x20]
    // 0xa09c0c: ldur            x3, [fp, #-0x18]
    // 0xa09c10: ldur            x4, [fp, #-0x10]
    // 0xa09c14: b               #0xa09a24
    // 0xa09c18: ldr             x0, [fp, #0x20]
    // 0xa09c1c: r0 = ConcurrentModificationError()
    //     0xa09c1c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa09c20: ldr             x3, [fp, #0x20]
    // 0xa09c24: StoreField: r0->field_b = r3
    //     0xa09c24: stur            w3, [x0, #0xb]
    // 0xa09c28: r0 = Throw()
    //     0xa09c28: bl              #0xd67e38  ; ThrowStub
    // 0xa09c2c: brk             #0
    // 0xa09c30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa09c30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa09c34: b               #0xa099c0
    // 0xa09c38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa09c38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa09c3c: b               #0xa09a38
    // 0xa09c40: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa09c40: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ readDBusDict(/* No info */) {
    // ** addr: 0xa09c44, size: 0x218
    // 0xa09c44: EnterFrame
    //     0xa09c44: stp             fp, lr, [SP, #-0x10]!
    //     0xa09c48: mov             fp, SP
    // 0xa09c4c: AllocStack(0x28)
    //     0xa09c4c: sub             SP, SP, #0x28
    // 0xa09c50: CheckStackOverflow
    //     0xa09c50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa09c54: cmp             SP, x16
    //     0xa09c58: b.ls            #0xa09e4c
    // 0xa09c5c: ldr             x16, [fp, #0x30]
    // 0xa09c60: ldr             lr, [fp, #0x18]
    // 0xa09c64: stp             lr, x16, [SP, #-0x10]!
    // 0xa09c68: r0 = readDBusUint32()
    //     0xa09c68: bl              #0xa0c000  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusUint32
    // 0xa09c6c: add             SP, SP, #0x10
    // 0xa09c70: stur            x0, [fp, #-8]
    // 0xa09c74: cmp             w0, NULL
    // 0xa09c78: b.eq            #0xa09c94
    // 0xa09c7c: r1 = 8
    //     0xa09c7c: mov             x1, #8
    // 0xa09c80: ldr             x16, [fp, #0x30]
    // 0xa09c84: stp             x1, x16, [SP, #-0x10]!
    // 0xa09c88: r0 = align()
    //     0xa09c88: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa09c8c: add             SP, SP, #0x10
    // 0xa09c90: tbz             w0, #4, #0xa09ca4
    // 0xa09c94: r0 = Null
    //     0xa09c94: mov             x0, NULL
    // 0xa09c98: LeaveFrame
    //     0xa09c98: mov             SP, fp
    //     0xa09c9c: ldp             fp, lr, [SP], #0x10
    // 0xa09ca0: ret
    //     0xa09ca0: ret             
    // 0xa09ca4: ldr             x6, [fp, #0x30]
    // 0xa09ca8: ldr             x5, [fp, #0x28]
    // 0xa09cac: ldr             x4, [fp, #0x20]
    // 0xa09cb0: ldur            x0, [fp, #-8]
    // 0xa09cb4: r3 = 4
    //     0xa09cb4: mov             x3, #4
    // 0xa09cb8: LoadField: r1 = r6->field_9b
    //     0xa09cb8: ldur            x1, [x6, #0x9b]
    // 0xa09cbc: LoadField: r2 = r0->field_7
    //     0xa09cbc: ldur            x2, [x0, #7]
    // 0xa09cc0: add             x0, x1, x2
    // 0xa09cc4: mov             x2, x3
    // 0xa09cc8: stur            x0, [fp, #-0x10]
    // 0xa09ccc: r1 = Null
    //     0xa09ccc: mov             x1, NULL
    // 0xa09cd0: r0 = AllocateArray()
    //     0xa09cd0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa09cd4: mov             x2, x0
    // 0xa09cd8: ldr             x0, [fp, #0x28]
    // 0xa09cdc: stur            x2, [fp, #-8]
    // 0xa09ce0: StoreField: r2->field_f = r0
    //     0xa09ce0: stur            w0, [x2, #0xf]
    // 0xa09ce4: ldr             x3, [fp, #0x20]
    // 0xa09ce8: StoreField: r2->field_13 = r3
    //     0xa09ce8: stur            w3, [x2, #0x13]
    // 0xa09cec: r1 = <DBusSignature>
    //     0xa09cec: ldr             x1, [PP, #0x4c0]  ; [pp+0x4c0] TypeArguments: <DBusSignature>
    // 0xa09cf0: r0 = AllocateGrowableArray()
    //     0xa09cf0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa09cf4: mov             x1, x0
    // 0xa09cf8: ldur            x0, [fp, #-8]
    // 0xa09cfc: stur            x1, [fp, #-0x18]
    // 0xa09d00: StoreField: r1->field_f = r0
    //     0xa09d00: stur            w0, [x1, #0xf]
    // 0xa09d04: r0 = 4
    //     0xa09d04: mov             x0, #4
    // 0xa09d08: StoreField: r1->field_b = r0
    //     0xa09d08: stur            w0, [x1, #0xb]
    // 0xa09d0c: r16 = <DBusValue, DBusValue>
    //     0xa09d0c: add             x16, PP, #8, lsl #12  ; [pp+0x8168] TypeArguments: <DBusValue, DBusValue>
    //     0xa09d10: ldr             x16, [x16, #0x168]
    // 0xa09d14: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xa09d18: stp             lr, x16, [SP, #-0x10]!
    // 0xa09d1c: r0 = Map._fromLiteral()
    //     0xa09d1c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa09d20: add             SP, SP, #0x10
    // 0xa09d24: stur            x0, [fp, #-8]
    // 0xa09d28: ldr             x1, [fp, #0x30]
    // 0xa09d2c: ldr             x3, [fp, #0x10]
    // 0xa09d30: ldur            x2, [fp, #-0x10]
    // 0xa09d34: CheckStackOverflow
    //     0xa09d34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa09d38: cmp             SP, x16
    //     0xa09d3c: b.ls            #0xa09e54
    // 0xa09d40: LoadField: r4 = r1->field_9b
    //     0xa09d40: ldur            x4, [x1, #0x9b]
    // 0xa09d44: cmp             x4, x2
    // 0xa09d48: b.ge            #0xa09e18
    // 0xa09d4c: ldur            x16, [fp, #-0x18]
    // 0xa09d50: stp             x16, x1, [SP, #-0x10]!
    // 0xa09d54: ldr             x16, [fp, #0x18]
    // 0xa09d58: stp             x3, x16, [SP, #-0x10]!
    // 0xa09d5c: r0 = readDBusStruct()
    //     0xa09d5c: bl              #0xa099a4  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusStruct
    // 0xa09d60: add             SP, SP, #0x20
    // 0xa09d64: cmp             w0, NULL
    // 0xa09d68: b.ne            #0xa09d7c
    // 0xa09d6c: r0 = Null
    //     0xa09d6c: mov             x0, NULL
    // 0xa09d70: LeaveFrame
    //     0xa09d70: mov             SP, fp
    //     0xa09d74: ldp             fp, lr, [SP], #0x10
    // 0xa09d78: ret
    //     0xa09d78: ret             
    // 0xa09d7c: LoadField: r1 = r0->field_7
    //     0xa09d7c: ldur            w1, [x0, #7]
    // 0xa09d80: DecompressPointer r1
    //     0xa09d80: add             x1, x1, HEAP, lsl #32
    // 0xa09d84: stur            x1, [fp, #-0x20]
    // 0xa09d88: r0 = LoadClassIdInstr(r1)
    //     0xa09d88: ldur            x0, [x1, #-1]
    //     0xa09d8c: ubfx            x0, x0, #0xc, #0x14
    // 0xa09d90: stp             xzr, x1, [SP, #-0x10]!
    // 0xa09d94: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa09d94: mov             x17, #0xd175
    //     0xa09d98: add             lr, x0, x17
    //     0xa09d9c: ldr             lr, [x21, lr, lsl #3]
    //     0xa09da0: blr             lr
    // 0xa09da4: add             SP, SP, #0x10
    // 0xa09da8: mov             x1, x0
    // 0xa09dac: ldur            x0, [fp, #-0x20]
    // 0xa09db0: stur            x1, [fp, #-0x28]
    // 0xa09db4: r2 = LoadClassIdInstr(r0)
    //     0xa09db4: ldur            x2, [x0, #-1]
    //     0xa09db8: ubfx            x2, x2, #0xc, #0x14
    // 0xa09dbc: r16 = 2
    //     0xa09dbc: mov             x16, #2
    // 0xa09dc0: stp             x16, x0, [SP, #-0x10]!
    // 0xa09dc4: mov             x0, x2
    // 0xa09dc8: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa09dc8: mov             x17, #0xd175
    //     0xa09dcc: add             lr, x0, x17
    //     0xa09dd0: ldr             lr, [x21, lr, lsl #3]
    //     0xa09dd4: blr             lr
    // 0xa09dd8: add             SP, SP, #0x10
    // 0xa09ddc: stur            x0, [fp, #-0x20]
    // 0xa09de0: ldur            x16, [fp, #-8]
    // 0xa09de4: ldur            lr, [fp, #-0x28]
    // 0xa09de8: stp             lr, x16, [SP, #-0x10]!
    // 0xa09dec: r0 = hash()
    //     0xa09dec: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0xa09df0: add             SP, SP, #0x10
    // 0xa09df4: ldur            x16, [fp, #-8]
    // 0xa09df8: ldur            lr, [fp, #-0x28]
    // 0xa09dfc: stp             lr, x16, [SP, #-0x10]!
    // 0xa09e00: ldur            x16, [fp, #-0x20]
    // 0xa09e04: stp             x0, x16, [SP, #-0x10]!
    // 0xa09e08: r0 = _set()
    //     0xa09e08: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xa09e0c: add             SP, SP, #0x20
    // 0xa09e10: ldur            x0, [fp, #-8]
    // 0xa09e14: b               #0xa09d28
    // 0xa09e18: r0 = DBusDict()
    //     0xa09e18: bl              #0xa0a1ec  ; AllocateDBusDictStub -> DBusDict (size=0x14)
    // 0xa09e1c: stur            x0, [fp, #-0x18]
    // 0xa09e20: ldr             x16, [fp, #0x28]
    // 0xa09e24: stp             x16, x0, [SP, #-0x10]!
    // 0xa09e28: ldr             x16, [fp, #0x20]
    // 0xa09e2c: ldur            lr, [fp, #-8]
    // 0xa09e30: stp             lr, x16, [SP, #-0x10]!
    // 0xa09e34: r0 = DBusDict()
    //     0xa09e34: bl              #0xa09e5c  ; [package:dbus/src/dbus_value.dart] DBusDict::DBusDict
    // 0xa09e38: add             SP, SP, #0x20
    // 0xa09e3c: ldur            x0, [fp, #-0x18]
    // 0xa09e40: LeaveFrame
    //     0xa09e40: mov             SP, fp
    //     0xa09e44: ldp             fp, lr, [SP], #0x10
    // 0xa09e48: ret
    //     0xa09e48: ret             
    // 0xa09e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa09e4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa09e50: b               #0xa09c5c
    // 0xa09e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa09e54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa09e58: b               #0xa09d40
  }
  _ readDBusUnixFd(/* No info */) {
    // ** addr: 0xa0a1f8, size: 0x144
    // 0xa0a1f8: EnterFrame
    //     0xa0a1f8: stp             fp, lr, [SP, #-0x10]!
    //     0xa0a1fc: mov             fp, SP
    // 0xa0a200: AllocStack(0x8)
    //     0xa0a200: sub             SP, SP, #8
    // 0xa0a204: CheckStackOverflow
    //     0xa0a204: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0a208: cmp             SP, x16
    //     0xa0a20c: b.ls            #0xa0a330
    // 0xa0a210: ldr             x16, [fp, #0x20]
    // 0xa0a214: ldr             lr, [fp, #0x10]
    // 0xa0a218: stp             lr, x16, [SP, #-0x10]!
    // 0xa0a21c: r0 = readDBusUint32()
    //     0xa0a21c: bl              #0xa0c000  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusUint32
    // 0xa0a220: add             SP, SP, #0x10
    // 0xa0a224: cmp             w0, NULL
    // 0xa0a228: b.ne            #0xa0a234
    // 0xa0a22c: r0 = Null
    //     0xa0a22c: mov             x0, NULL
    // 0xa0a230: b               #0xa0a24c
    // 0xa0a234: LoadField: r2 = r0->field_7
    //     0xa0a234: ldur            x2, [x0, #7]
    // 0xa0a238: r0 = BoxInt64Instr(r2)
    //     0xa0a238: sbfiz           x0, x2, #1, #0x1f
    //     0xa0a23c: cmp             x2, x0, asr #1
    //     0xa0a240: b.eq            #0xa0a24c
    //     0xa0a244: bl              #0xd69bb8
    //     0xa0a248: stur            x2, [x0, #7]
    // 0xa0a24c: stur            x0, [fp, #-8]
    // 0xa0a250: cmp             w0, NULL
    // 0xa0a254: b.ne            #0xa0a268
    // 0xa0a258: r0 = Null
    //     0xa0a258: mov             x0, NULL
    // 0xa0a25c: LeaveFrame
    //     0xa0a25c: mov             SP, fp
    //     0xa0a260: ldp             fp, lr, [SP], #0x10
    // 0xa0a264: ret
    //     0xa0a264: ret             
    // 0xa0a268: ldr             x1, [fp, #0x18]
    // 0xa0a26c: r2 = LoadInt32Instr(r0)
    //     0xa0a26c: sbfx            x2, x0, #1, #0x1f
    //     0xa0a270: tbz             w0, #0, #0xa0a278
    //     0xa0a274: ldur            x2, [x0, #7]
    // 0xa0a278: cmp             x2, x1
    // 0xa0a27c: b.gt            #0xa0a2e0
    // 0xa0a280: ldr             x1, [fp, #0x20]
    // 0xa0a284: LoadField: r3 = r1->field_93
    //     0xa0a284: ldur            w3, [x1, #0x93]
    // 0xa0a288: DecompressPointer r3
    //     0xa0a288: add             x3, x3, HEAP, lsl #32
    // 0xa0a28c: LoadField: r1 = r3->field_b
    //     0xa0a28c: ldur            w1, [x3, #0xb]
    // 0xa0a290: DecompressPointer r1
    //     0xa0a290: add             x1, x1, HEAP, lsl #32
    // 0xa0a294: r4 = LoadInt32Instr(r1)
    //     0xa0a294: sbfx            x4, x1, #1, #0x1f
    // 0xa0a298: cmp             x2, x4
    // 0xa0a29c: b.gt            #0xa0a2f0
    // 0xa0a2a0: mov             x0, x4
    // 0xa0a2a4: mov             x1, x2
    // 0xa0a2a8: cmp             x1, x0
    // 0xa0a2ac: b.hs            #0xa0a338
    // 0xa0a2b0: LoadField: r0 = r3->field_f
    //     0xa0a2b0: ldur            w0, [x3, #0xf]
    // 0xa0a2b4: DecompressPointer r0
    //     0xa0a2b4: add             x0, x0, HEAP, lsl #32
    // 0xa0a2b8: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0xa0a2b8: add             x16, x0, x2, lsl #2
    //     0xa0a2bc: ldur            w1, [x16, #0xf]
    // 0xa0a2c0: DecompressPointer r1
    //     0xa0a2c0: add             x1, x1, HEAP, lsl #32
    // 0xa0a2c4: stur            x1, [fp, #-8]
    // 0xa0a2c8: r0 = DBusUnixFd()
    //     0xa0a2c8: bl              #0xa0a33c  ; AllocateDBusUnixFdStub -> DBusUnixFd (size=0xc)
    // 0xa0a2cc: ldur            x1, [fp, #-8]
    // 0xa0a2d0: StoreField: r0->field_7 = r1
    //     0xa0a2d0: stur            w1, [x0, #7]
    // 0xa0a2d4: LeaveFrame
    //     0xa0a2d4: mov             SP, fp
    //     0xa0a2d8: ldp             fp, lr, [SP], #0x10
    // 0xa0a2dc: ret
    //     0xa0a2dc: ret             
    // 0xa0a2e0: r0 = "Unix fd index out of bounds"
    //     0xa0a2e0: add             x0, PP, #8, lsl #12  ; [pp+0x81a8] "Unix fd index out of bounds"
    //     0xa0a2e4: ldr             x0, [x0, #0x1a8]
    // 0xa0a2e8: r0 = Throw()
    //     0xa0a2e8: bl              #0xd67e38  ; ThrowStub
    // 0xa0a2ec: brk             #0
    // 0xa0a2f0: r1 = Null
    //     0xa0a2f0: mov             x1, NULL
    // 0xa0a2f4: r2 = 6
    //     0xa0a2f4: mov             x2, #6
    // 0xa0a2f8: r0 = AllocateArray()
    //     0xa0a2f8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0a2fc: r17 = "Unix fd "
    //     0xa0a2fc: add             x17, PP, #8, lsl #12  ; [pp+0x81b0] "Unix fd "
    //     0xa0a300: ldr             x17, [x17, #0x1b0]
    // 0xa0a304: StoreField: r0->field_f = r17
    //     0xa0a304: stur            w17, [x0, #0xf]
    // 0xa0a308: ldur            x1, [fp, #-8]
    // 0xa0a30c: StoreField: r0->field_13 = r1
    //     0xa0a30c: stur            w1, [x0, #0x13]
    // 0xa0a310: r17 = " not yet received"
    //     0xa0a310: add             x17, PP, #8, lsl #12  ; [pp+0x81b8] " not yet received"
    //     0xa0a314: ldr             x17, [x17, #0x1b8]
    // 0xa0a318: StoreField: r0->field_17 = r17
    //     0xa0a318: stur            w17, [x0, #0x17]
    // 0xa0a31c: SaveReg r0
    //     0xa0a31c: str             x0, [SP, #-8]!
    // 0xa0a320: r0 = _interpolate()
    //     0xa0a320: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0a324: add             SP, SP, #8
    // 0xa0a328: r0 = Throw()
    //     0xa0a328: bl              #0xd67e38  ; ThrowStub
    // 0xa0a32c: brk             #0
    // 0xa0a330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0a330: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0a334: b               #0xa0a210
    // 0xa0a338: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0a338: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ readDBusVariant(/* No info */) {
    // ** addr: 0xa0a348, size: 0x98
    // 0xa0a348: EnterFrame
    //     0xa0a348: stp             fp, lr, [SP, #-0x10]!
    //     0xa0a34c: mov             fp, SP
    // 0xa0a350: AllocStack(0x8)
    //     0xa0a350: sub             SP, SP, #8
    // 0xa0a354: CheckStackOverflow
    //     0xa0a354: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0a358: cmp             SP, x16
    //     0xa0a35c: b.ls            #0xa0a3d8
    // 0xa0a360: ldr             x16, [fp, #0x20]
    // 0xa0a364: SaveReg r16
    //     0xa0a364: str             x16, [SP, #-8]!
    // 0xa0a368: r0 = readDBusSignature()
    //     0xa0a368: bl              #0xa0a3e0  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusSignature
    // 0xa0a36c: add             SP, SP, #8
    // 0xa0a370: cmp             w0, NULL
    // 0xa0a374: b.ne            #0xa0a388
    // 0xa0a378: r0 = Null
    //     0xa0a378: mov             x0, NULL
    // 0xa0a37c: LeaveFrame
    //     0xa0a37c: mov             SP, fp
    //     0xa0a380: ldp             fp, lr, [SP], #0x10
    // 0xa0a384: ret
    //     0xa0a384: ret             
    // 0xa0a388: ldr             x1, [fp, #0x10]
    // 0xa0a38c: ldr             x16, [fp, #0x20]
    // 0xa0a390: stp             x0, x16, [SP, #-0x10]!
    // 0xa0a394: ldr             x16, [fp, #0x18]
    // 0xa0a398: stp             x1, x16, [SP, #-0x10]!
    // 0xa0a39c: r0 = readDBusValue()
    //     0xa0a39c: bl              #0xa091c8  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusValue
    // 0xa0a3a0: add             SP, SP, #0x20
    // 0xa0a3a4: stur            x0, [fp, #-8]
    // 0xa0a3a8: cmp             w0, NULL
    // 0xa0a3ac: b.ne            #0xa0a3c0
    // 0xa0a3b0: r0 = Null
    //     0xa0a3b0: mov             x0, NULL
    // 0xa0a3b4: LeaveFrame
    //     0xa0a3b4: mov             SP, fp
    //     0xa0a3b8: ldp             fp, lr, [SP], #0x10
    // 0xa0a3bc: ret
    //     0xa0a3bc: ret             
    // 0xa0a3c0: r0 = DBusVariant()
    //     0xa0a3c0: bl              #0xa00644  ; AllocateDBusVariantStub -> DBusVariant (size=0xc)
    // 0xa0a3c4: ldur            x1, [fp, #-8]
    // 0xa0a3c8: StoreField: r0->field_7 = r1
    //     0xa0a3c8: stur            w1, [x0, #7]
    // 0xa0a3cc: LeaveFrame
    //     0xa0a3cc: mov             SP, fp
    //     0xa0a3d0: ldp             fp, lr, [SP], #0x10
    // 0xa0a3d4: ret
    //     0xa0a3d4: ret             
    // 0xa0a3d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0a3d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0a3dc: b               #0xa0a360
  }
  _ readDBusSignature(/* No info */) {
    // ** addr: 0xa0a3e0, size: 0x1bc
    // 0xa0a3e0: EnterFrame
    //     0xa0a3e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa0a3e4: mov             fp, SP
    // 0xa0a3e8: AllocStack(0x18)
    //     0xa0a3e8: sub             SP, SP, #0x18
    // 0xa0a3ec: CheckStackOverflow
    //     0xa0a3ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0a3f0: cmp             SP, x16
    //     0xa0a3f4: b.ls            #0xa0a594
    // 0xa0a3f8: ldr             x0, [fp, #0x10]
    // 0xa0a3fc: LoadField: r1 = r0->field_8f
    //     0xa0a3fc: ldur            w1, [x0, #0x8f]
    // 0xa0a400: DecompressPointer r1
    //     0xa0a400: add             x1, x1, HEAP, lsl #32
    // 0xa0a404: LoadField: r2 = r1->field_13
    //     0xa0a404: ldur            w2, [x1, #0x13]
    // 0xa0a408: DecompressPointer r2
    //     0xa0a408: add             x2, x2, HEAP, lsl #32
    // 0xa0a40c: LoadField: r1 = r0->field_9b
    //     0xa0a40c: ldur            x1, [x0, #0x9b]
    // 0xa0a410: r3 = LoadInt32Instr(r2)
    //     0xa0a410: sbfx            x3, x2, #1, #0x1f
    // 0xa0a414: sub             x2, x3, x1
    // 0xa0a418: cmp             x2, #1
    // 0xa0a41c: b.ge            #0xa0a430
    // 0xa0a420: r0 = Null
    //     0xa0a420: mov             x0, NULL
    // 0xa0a424: LeaveFrame
    //     0xa0a424: mov             SP, fp
    //     0xa0a428: ldp             fp, lr, [SP], #0x10
    // 0xa0a42c: ret
    //     0xa0a42c: ret             
    // 0xa0a430: SaveReg r0
    //     0xa0a430: str             x0, [SP, #-8]!
    // 0xa0a434: r0 = _readByte()
    //     0xa0a434: bl              #0xa0a59c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::_readByte
    // 0xa0a438: add             SP, SP, #8
    // 0xa0a43c: mov             x3, x0
    // 0xa0a440: ldr             x2, [fp, #0x10]
    // 0xa0a444: stur            x3, [fp, #-8]
    // 0xa0a448: LoadField: r4 = r2->field_8f
    //     0xa0a448: ldur            w4, [x2, #0x8f]
    // 0xa0a44c: DecompressPointer r4
    //     0xa0a44c: add             x4, x4, HEAP, lsl #32
    // 0xa0a450: LoadField: r0 = r4->field_13
    //     0xa0a450: ldur            w0, [x4, #0x13]
    // 0xa0a454: DecompressPointer r0
    //     0xa0a454: add             x0, x0, HEAP, lsl #32
    // 0xa0a458: LoadField: r5 = r2->field_9b
    //     0xa0a458: ldur            x5, [x2, #0x9b]
    // 0xa0a45c: r1 = LoadInt32Instr(r0)
    //     0xa0a45c: sbfx            x1, x0, #1, #0x1f
    // 0xa0a460: sub             x0, x1, x5
    // 0xa0a464: add             x1, x3, #1
    // 0xa0a468: cmp             x0, x1
    // 0xa0a46c: b.ge            #0xa0a480
    // 0xa0a470: r0 = Null
    //     0xa0a470: mov             x0, NULL
    // 0xa0a474: LeaveFrame
    //     0xa0a474: mov             SP, fp
    //     0xa0a478: ldp             fp, lr, [SP], #0x10
    // 0xa0a47c: ret
    //     0xa0a47c: ret             
    // 0xa0a480: add             x6, x5, x3
    // 0xa0a484: r0 = BoxInt64Instr(r5)
    //     0xa0a484: sbfiz           x0, x5, #1, #0x1f
    //     0xa0a488: cmp             x5, x0, asr #1
    //     0xa0a48c: b.eq            #0xa0a498
    //     0xa0a490: bl              #0xd69bb8
    //     0xa0a494: stur            x5, [x0, #7]
    // 0xa0a498: r1 = LoadClassIdInstr(r4)
    //     0xa0a498: ldur            x1, [x4, #-1]
    //     0xa0a49c: ubfx            x1, x1, #0xc, #0x14
    // 0xa0a4a0: stp             x0, x4, [SP, #-0x10]!
    // 0xa0a4a4: SaveReg r6
    //     0xa0a4a4: str             x6, [SP, #-8]!
    // 0xa0a4a8: mov             x0, x1
    // 0xa0a4ac: r0 = GDT[cid_x0 + 0x1094d]()
    //     0xa0a4ac: mov             x17, #0x94d
    //     0xa0a4b0: movk            x17, #1, lsl #16
    //     0xa0a4b4: add             lr, x0, x17
    //     0xa0a4b8: ldr             lr, [x21, lr, lsl #3]
    //     0xa0a4bc: blr             lr
    // 0xa0a4c0: add             SP, SP, #0x18
    // 0xa0a4c4: mov             x1, x0
    // 0xa0a4c8: ldr             x0, [fp, #0x10]
    // 0xa0a4cc: stur            x1, [fp, #-0x10]
    // 0xa0a4d0: LoadField: r2 = r0->field_9b
    //     0xa0a4d0: ldur            x2, [x0, #0x9b]
    // 0xa0a4d4: ldur            x3, [fp, #-8]
    // 0xa0a4d8: add             x4, x2, x3
    // 0xa0a4dc: StoreField: r0->field_9b = r4
    //     0xa0a4dc: stur            x4, [x0, #0x9b]
    // 0xa0a4e0: SaveReg r0
    //     0xa0a4e0: str             x0, [SP, #-8]!
    // 0xa0a4e4: r0 = _readByte()
    //     0xa0a4e4: bl              #0xa0a59c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::_readByte
    // 0xa0a4e8: add             SP, SP, #8
    // 0xa0a4ec: lsl             x1, x0, #1
    // 0xa0a4f0: cbnz            w1, #0xa0a574
    // 0xa0a4f4: ldur            x16, [fp, #-0x10]
    // 0xa0a4f8: SaveReg r16
    //     0xa0a4f8: str             x16, [SP, #-8]!
    // 0xa0a4fc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0a4fc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0a500: r0 = toList()
    //     0xa0a500: bl              #0x6bab5c  ; [dart:_internal] SubListIterable::toList
    // 0xa0a504: add             SP, SP, #8
    // 0xa0a508: r16 = Instance_Utf8Codec
    //     0xa0a508: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xa0a50c: stp             x0, x16, [SP, #-0x10]!
    // 0xa0a510: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0a510: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0a514: r0 = decode()
    //     0xa0a514: bl              #0x4e1c78  ; [dart:convert] Utf8Codec::decode
    // 0xa0a518: add             SP, SP, #0x10
    // 0xa0a51c: mov             x1, x0
    // 0xa0a520: stur            x1, [fp, #-0x10]
    // 0xa0a524: r0 = LoadClassIdInstr(r1)
    //     0xa0a524: ldur            x0, [x1, #-1]
    //     0xa0a528: ubfx            x0, x0, #0xc, #0x14
    // 0xa0a52c: r16 = "m"
    //     0xa0a52c: ldr             x16, [PP, #0x448]  ; [pp+0x448] "m"
    // 0xa0a530: stp             x16, x1, [SP, #-0x10]!
    // 0xa0a534: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0a534: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0a538: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa0a538: sub             lr, x0, #0xffc
    //     0xa0a53c: ldr             lr, [x21, lr, lsl #3]
    //     0xa0a540: blr             lr
    // 0xa0a544: add             SP, SP, #0x10
    // 0xa0a548: tbz             w0, #4, #0xa0a584
    // 0xa0a54c: r0 = DBusSignature()
    //     0xa0a54c: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa0a550: stur            x0, [fp, #-0x18]
    // 0xa0a554: ldur            x16, [fp, #-0x10]
    // 0xa0a558: stp             x16, x0, [SP, #-0x10]!
    // 0xa0a55c: r0 = DBusSignature()
    //     0xa0a55c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa0a560: add             SP, SP, #0x10
    // 0xa0a564: ldur            x0, [fp, #-0x18]
    // 0xa0a568: LeaveFrame
    //     0xa0a568: mov             SP, fp
    //     0xa0a56c: ldp             fp, lr, [SP], #0x10
    // 0xa0a570: ret
    //     0xa0a570: ret             
    // 0xa0a574: r0 = "Signature missing trailing nul"
    //     0xa0a574: add             x0, PP, #8, lsl #12  ; [pp+0x81c0] "Signature missing trailing nul"
    //     0xa0a578: ldr             x0, [x0, #0x1c0]
    // 0xa0a57c: r0 = Throw()
    //     0xa0a57c: bl              #0xd67e38  ; ThrowStub
    // 0xa0a580: brk             #0
    // 0xa0a584: r0 = "Signature contains reserved maybe type"
    //     0xa0a584: add             x0, PP, #8, lsl #12  ; [pp+0x81c8] "Signature contains reserved maybe type"
    //     0xa0a588: ldr             x0, [x0, #0x1c8]
    // 0xa0a58c: r0 = Throw()
    //     0xa0a58c: bl              #0xd67e38  ; ThrowStub
    // 0xa0a590: brk             #0
    // 0xa0a594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0a594: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0a598: b               #0xa0a3f8
  }
  _ _readByte(/* No info */) {
    // ** addr: 0xa0a59c, size: 0x54
    // 0xa0a59c: EnterFrame
    //     0xa0a59c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0a5a0: mov             fp, SP
    // 0xa0a5a4: ldr             x2, [fp, #0x10]
    // 0xa0a5a8: LoadField: r3 = r2->field_9b
    //     0xa0a5a8: ldur            x3, [x2, #0x9b]
    // 0xa0a5ac: add             x4, x3, #1
    // 0xa0a5b0: StoreField: r2->field_9b = r4
    //     0xa0a5b0: stur            x4, [x2, #0x9b]
    // 0xa0a5b4: LoadField: r3 = r2->field_8f
    //     0xa0a5b4: ldur            w3, [x2, #0x8f]
    // 0xa0a5b8: DecompressPointer r3
    //     0xa0a5b8: add             x3, x3, HEAP, lsl #32
    // 0xa0a5bc: sub             x2, x4, #1
    // 0xa0a5c0: LoadField: r4 = r3->field_13
    //     0xa0a5c0: ldur            w4, [x3, #0x13]
    // 0xa0a5c4: DecompressPointer r4
    //     0xa0a5c4: add             x4, x4, HEAP, lsl #32
    // 0xa0a5c8: r0 = LoadInt32Instr(r4)
    //     0xa0a5c8: sbfx            x0, x4, #1, #0x1f
    // 0xa0a5cc: mov             x1, x2
    // 0xa0a5d0: cmp             x1, x0
    // 0xa0a5d4: b.hs            #0xa0a5ec
    // 0xa0a5d8: LoadField: r1 = r3->field_7
    //     0xa0a5d8: ldur            x1, [x3, #7]
    // 0xa0a5dc: ldrb            w0, [x1, x2]
    // 0xa0a5e0: LeaveFrame
    //     0xa0a5e0: mov             SP, fp
    //     0xa0a5e4: ldp             fp, lr, [SP], #0x10
    // 0xa0a5e8: ret
    //     0xa0a5e8: ret             
    // 0xa0a5ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0a5ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ readDBusObjectPath(/* No info */) {
    // ** addr: 0xa0a5f0, size: 0x80
    // 0xa0a5f0: EnterFrame
    //     0xa0a5f0: stp             fp, lr, [SP, #-0x10]!
    //     0xa0a5f4: mov             fp, SP
    // 0xa0a5f8: AllocStack(0x10)
    //     0xa0a5f8: sub             SP, SP, #0x10
    // 0xa0a5fc: CheckStackOverflow
    //     0xa0a5fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0a600: cmp             SP, x16
    //     0xa0a604: b.ls            #0xa0a668
    // 0xa0a608: ldr             x16, [fp, #0x18]
    // 0xa0a60c: ldr             lr, [fp, #0x10]
    // 0xa0a610: stp             lr, x16, [SP, #-0x10]!
    // 0xa0a614: r0 = readDBusString()
    //     0xa0a614: bl              #0xa0a670  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusString
    // 0xa0a618: add             SP, SP, #0x10
    // 0xa0a61c: cmp             w0, NULL
    // 0xa0a620: b.ne            #0xa0a634
    // 0xa0a624: r0 = Null
    //     0xa0a624: mov             x0, NULL
    // 0xa0a628: LeaveFrame
    //     0xa0a628: mov             SP, fp
    //     0xa0a62c: ldp             fp, lr, [SP], #0x10
    // 0xa0a630: ret
    //     0xa0a630: ret             
    // 0xa0a634: LoadField: r1 = r0->field_7
    //     0xa0a634: ldur            w1, [x0, #7]
    // 0xa0a638: DecompressPointer r1
    //     0xa0a638: add             x1, x1, HEAP, lsl #32
    // 0xa0a63c: stur            x1, [fp, #-8]
    // 0xa0a640: r0 = DBusObjectPath()
    //     0xa0a640: bl              #0x9fce70  ; AllocateDBusObjectPathStub -> DBusObjectPath (size=0xc)
    // 0xa0a644: stur            x0, [fp, #-0x10]
    // 0xa0a648: ldur            x16, [fp, #-8]
    // 0xa0a64c: stp             x16, x0, [SP, #-0x10]!
    // 0xa0a650: r0 = DBusObjectPath()
    //     0xa0a650: bl              #0x9fcc00  ; [package:dbus/src/dbus_value.dart] DBusObjectPath::DBusObjectPath
    // 0xa0a654: add             SP, SP, #0x10
    // 0xa0a658: ldur            x0, [fp, #-0x10]
    // 0xa0a65c: LeaveFrame
    //     0xa0a65c: mov             SP, fp
    //     0xa0a660: ldp             fp, lr, [SP], #0x10
    // 0xa0a664: ret
    //     0xa0a664: ret             
    // 0xa0a668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0a668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0a66c: b               #0xa0a608
  }
  _ readDBusString(/* No info */) {
    // ** addr: 0xa0a670, size: 0x148
    // 0xa0a670: EnterFrame
    //     0xa0a670: stp             fp, lr, [SP, #-0x10]!
    //     0xa0a674: mov             fp, SP
    // 0xa0a678: AllocStack(0x10)
    //     0xa0a678: sub             SP, SP, #0x10
    // 0xa0a67c: CheckStackOverflow
    //     0xa0a67c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0a680: cmp             SP, x16
    //     0xa0a684: b.ls            #0xa0a7b0
    // 0xa0a688: ldr             x16, [fp, #0x18]
    // 0xa0a68c: ldr             lr, [fp, #0x10]
    // 0xa0a690: stp             lr, x16, [SP, #-0x10]!
    // 0xa0a694: r0 = readDBusUint32()
    //     0xa0a694: bl              #0xa0c000  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusUint32
    // 0xa0a698: add             SP, SP, #0x10
    // 0xa0a69c: cmp             w0, NULL
    // 0xa0a6a0: b.eq            #0xa0a6d8
    // 0xa0a6a4: ldr             x2, [fp, #0x18]
    // 0xa0a6a8: LoadField: r3 = r2->field_8f
    //     0xa0a6a8: ldur            w3, [x2, #0x8f]
    // 0xa0a6ac: DecompressPointer r3
    //     0xa0a6ac: add             x3, x3, HEAP, lsl #32
    // 0xa0a6b0: LoadField: r1 = r3->field_13
    //     0xa0a6b0: ldur            w1, [x3, #0x13]
    // 0xa0a6b4: DecompressPointer r1
    //     0xa0a6b4: add             x1, x1, HEAP, lsl #32
    // 0xa0a6b8: LoadField: r4 = r2->field_9b
    //     0xa0a6b8: ldur            x4, [x2, #0x9b]
    // 0xa0a6bc: r5 = LoadInt32Instr(r1)
    //     0xa0a6bc: sbfx            x5, x1, #1, #0x1f
    // 0xa0a6c0: sub             x1, x5, x4
    // 0xa0a6c4: LoadField: r5 = r0->field_7
    //     0xa0a6c4: ldur            x5, [x0, #7]
    // 0xa0a6c8: stur            x5, [fp, #-8]
    // 0xa0a6cc: add             x0, x5, #1
    // 0xa0a6d0: cmp             x1, x0
    // 0xa0a6d4: b.ge            #0xa0a6e8
    // 0xa0a6d8: r0 = Null
    //     0xa0a6d8: mov             x0, NULL
    // 0xa0a6dc: LeaveFrame
    //     0xa0a6dc: mov             SP, fp
    //     0xa0a6e0: ldp             fp, lr, [SP], #0x10
    // 0xa0a6e4: ret
    //     0xa0a6e4: ret             
    // 0xa0a6e8: add             x6, x4, x5
    // 0xa0a6ec: r0 = BoxInt64Instr(r4)
    //     0xa0a6ec: sbfiz           x0, x4, #1, #0x1f
    //     0xa0a6f0: cmp             x4, x0, asr #1
    //     0xa0a6f4: b.eq            #0xa0a700
    //     0xa0a6f8: bl              #0xd69bb8
    //     0xa0a6fc: stur            x4, [x0, #7]
    // 0xa0a700: r1 = LoadClassIdInstr(r3)
    //     0xa0a700: ldur            x1, [x3, #-1]
    //     0xa0a704: ubfx            x1, x1, #0xc, #0x14
    // 0xa0a708: stp             x0, x3, [SP, #-0x10]!
    // 0xa0a70c: SaveReg r6
    //     0xa0a70c: str             x6, [SP, #-8]!
    // 0xa0a710: mov             x0, x1
    // 0xa0a714: r0 = GDT[cid_x0 + 0x1094d]()
    //     0xa0a714: mov             x17, #0x94d
    //     0xa0a718: movk            x17, #1, lsl #16
    //     0xa0a71c: add             lr, x0, x17
    //     0xa0a720: ldr             lr, [x21, lr, lsl #3]
    //     0xa0a724: blr             lr
    // 0xa0a728: add             SP, SP, #0x18
    // 0xa0a72c: mov             x1, x0
    // 0xa0a730: ldr             x0, [fp, #0x18]
    // 0xa0a734: stur            x1, [fp, #-0x10]
    // 0xa0a738: LoadField: r2 = r0->field_9b
    //     0xa0a738: ldur            x2, [x0, #0x9b]
    // 0xa0a73c: ldur            x3, [fp, #-8]
    // 0xa0a740: add             x4, x2, x3
    // 0xa0a744: StoreField: r0->field_9b = r4
    //     0xa0a744: stur            x4, [x0, #0x9b]
    // 0xa0a748: SaveReg r0
    //     0xa0a748: str             x0, [SP, #-8]!
    // 0xa0a74c: r0 = _readByte()
    //     0xa0a74c: bl              #0xa0a59c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::_readByte
    // 0xa0a750: add             SP, SP, #8
    // 0xa0a754: lsl             x1, x0, #1
    // 0xa0a758: cbnz            w1, #0xa0a7a0
    // 0xa0a75c: ldur            x16, [fp, #-0x10]
    // 0xa0a760: SaveReg r16
    //     0xa0a760: str             x16, [SP, #-8]!
    // 0xa0a764: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0a764: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0a768: r0 = toList()
    //     0xa0a768: bl              #0x6bab5c  ; [dart:_internal] SubListIterable::toList
    // 0xa0a76c: add             SP, SP, #8
    // 0xa0a770: r16 = Instance_Utf8Codec
    //     0xa0a770: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xa0a774: stp             x0, x16, [SP, #-0x10]!
    // 0xa0a778: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0a778: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0a77c: r0 = decode()
    //     0xa0a77c: bl              #0x4e1c78  ; [dart:convert] Utf8Codec::decode
    // 0xa0a780: add             SP, SP, #0x10
    // 0xa0a784: stur            x0, [fp, #-0x10]
    // 0xa0a788: r0 = DBusString()
    //     0xa0a788: bl              #0xa00578  ; AllocateDBusStringStub -> DBusString (size=0xc)
    // 0xa0a78c: ldur            x1, [fp, #-0x10]
    // 0xa0a790: StoreField: r0->field_7 = r1
    //     0xa0a790: stur            w1, [x0, #7]
    // 0xa0a794: LeaveFrame
    //     0xa0a794: mov             SP, fp
    //     0xa0a798: ldp             fp, lr, [SP], #0x10
    // 0xa0a79c: ret
    //     0xa0a79c: ret             
    // 0xa0a7a0: r0 = "String missing trailing nul"
    //     0xa0a7a0: add             x0, PP, #8, lsl #12  ; [pp+0x81d0] "String missing trailing nul"
    //     0xa0a7a4: ldr             x0, [x0, #0x1d0]
    // 0xa0a7a8: r0 = Throw()
    //     0xa0a7a8: bl              #0xd67e38  ; ThrowStub
    // 0xa0a7ac: brk             #0
    // 0xa0a7b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0a7b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0a7b4: b               #0xa0a688
  }
  _ readDBusDouble(/* No info */) {
    // ** addr: 0xa0a7b8, size: 0x9c
    // 0xa0a7b8: EnterFrame
    //     0xa0a7b8: stp             fp, lr, [SP, #-0x10]!
    //     0xa0a7bc: mov             fp, SP
    // 0xa0a7c0: AllocStack(0x8)
    //     0xa0a7c0: sub             SP, SP, #8
    // 0xa0a7c4: r0 = 8
    //     0xa0a7c4: mov             x0, #8
    // 0xa0a7c8: CheckStackOverflow
    //     0xa0a7c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0a7cc: cmp             SP, x16
    //     0xa0a7d0: b.ls            #0xa0a84c
    // 0xa0a7d4: ldr             x16, [fp, #0x18]
    // 0xa0a7d8: stp             x0, x16, [SP, #-0x10]!
    // 0xa0a7dc: r0 = align()
    //     0xa0a7dc: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa0a7e0: add             SP, SP, #0x10
    // 0xa0a7e4: tbnz            w0, #4, #0xa0a810
    // 0xa0a7e8: ldr             x0, [fp, #0x18]
    // 0xa0a7ec: LoadField: r1 = r0->field_8f
    //     0xa0a7ec: ldur            w1, [x0, #0x8f]
    // 0xa0a7f0: DecompressPointer r1
    //     0xa0a7f0: add             x1, x1, HEAP, lsl #32
    // 0xa0a7f4: LoadField: r2 = r1->field_13
    //     0xa0a7f4: ldur            w2, [x1, #0x13]
    // 0xa0a7f8: DecompressPointer r2
    //     0xa0a7f8: add             x2, x2, HEAP, lsl #32
    // 0xa0a7fc: LoadField: r1 = r0->field_9b
    //     0xa0a7fc: ldur            x1, [x0, #0x9b]
    // 0xa0a800: r3 = LoadInt32Instr(r2)
    //     0xa0a800: sbfx            x3, x2, #1, #0x1f
    // 0xa0a804: sub             x2, x3, x1
    // 0xa0a808: cmp             x2, #8
    // 0xa0a80c: b.ge            #0xa0a820
    // 0xa0a810: r0 = Null
    //     0xa0a810: mov             x0, NULL
    // 0xa0a814: LeaveFrame
    //     0xa0a814: mov             SP, fp
    //     0xa0a818: ldp             fp, lr, [SP], #0x10
    // 0xa0a81c: ret
    //     0xa0a81c: ret             
    // 0xa0a820: ldr             x16, [fp, #0x10]
    // 0xa0a824: stp             x16, x0, [SP, #-0x10]!
    // 0xa0a828: r0 = readFloat64()
    //     0xa0a828: bl              #0xa0a860  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readFloat64
    // 0xa0a82c: add             SP, SP, #0x10
    // 0xa0a830: stur            d0, [fp, #-8]
    // 0xa0a834: r0 = DBusDouble()
    //     0xa0a834: bl              #0xa0a854  ; AllocateDBusDoubleStub -> DBusDouble (size=0x10)
    // 0xa0a838: ldur            d0, [fp, #-8]
    // 0xa0a83c: StoreField: r0->field_7 = d0
    //     0xa0a83c: stur            d0, [x0, #7]
    // 0xa0a840: LeaveFrame
    //     0xa0a840: mov             SP, fp
    //     0xa0a844: ldp             fp, lr, [SP], #0x10
    // 0xa0a848: ret
    //     0xa0a848: ret             
    // 0xa0a84c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0a84c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0a850: b               #0xa0a7d4
  }
  _ readFloat64(/* No info */) {
    // ** addr: 0xa0a860, size: 0x348
    // 0xa0a860: EnterFrame
    //     0xa0a860: stp             fp, lr, [SP, #-0x10]!
    //     0xa0a864: mov             fp, SP
    // 0xa0a868: AllocStack(0x28)
    //     0xa0a868: sub             SP, SP, #0x28
    // 0xa0a86c: CheckStackOverflow
    //     0xa0a86c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0a870: cmp             SP, x16
    //     0xa0a874: b.ls            #0xa0ab94
    // 0xa0a878: ldr             x0, [fp, #0x18]
    // 0xa0a87c: LoadField: r1 = r0->field_97
    //     0xa0a87c: ldur            w1, [x0, #0x97]
    // 0xa0a880: DecompressPointer r1
    //     0xa0a880: add             x1, x1, HEAP, lsl #32
    // 0xa0a884: r16 = Sentinel
    //     0xa0a884: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0a888: cmp             w1, w16
    // 0xa0a88c: b.eq            #0xa0ab9c
    // 0xa0a890: stur            x1, [fp, #-0x28]
    // 0xa0a894: LoadField: r2 = r0->field_9b
    //     0xa0a894: ldur            x2, [x0, #0x9b]
    // 0xa0a898: stur            x2, [fp, #-0x20]
    // 0xa0a89c: tbnz            x2, #0x3f, #0xa0aabc
    // 0xa0a8a0: add             x3, x2, #7
    // 0xa0a8a4: LoadField: r4 = r1->field_13
    //     0xa0a8a4: ldur            w4, [x1, #0x13]
    // 0xa0a8a8: DecompressPointer r4
    //     0xa0a8a8: add             x4, x4, HEAP, lsl #32
    // 0xa0a8ac: r5 = LoadInt32Instr(r4)
    //     0xa0a8ac: sbfx            x5, x4, #1, #0x1f
    // 0xa0a8b0: cmp             x3, x5
    // 0xa0a8b4: b.ge            #0xa0aabc
    // 0xa0a8b8: ldr             x3, [fp, #0x10]
    // 0xa0a8bc: r16 = Instance_Endian
    //     0xa0a8bc: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xa0a8c0: cmp             w3, w16
    // 0xa0a8c4: b.ne            #0xa0a8ec
    // 0xa0a8c8: LoadField: r3 = r1->field_17
    //     0xa0a8c8: ldur            w3, [x1, #0x17]
    // 0xa0a8cc: DecompressPointer r3
    //     0xa0a8cc: add             x3, x3, HEAP, lsl #32
    // 0xa0a8d0: LoadField: r4 = r1->field_1b
    //     0xa0a8d0: ldur            w4, [x1, #0x1b]
    // 0xa0a8d4: DecompressPointer r4
    //     0xa0a8d4: add             x4, x4, HEAP, lsl #32
    // 0xa0a8d8: r1 = LoadInt32Instr(r4)
    //     0xa0a8d8: sbfx            x1, x4, #1, #0x1f
    // 0xa0a8dc: add             x4, x1, x2
    // 0xa0a8e0: LoadField: r1 = r3->field_7
    //     0xa0a8e0: ldur            x1, [x3, #7]
    // 0xa0a8e4: ldr             d0, [x1, x4]
    // 0xa0a8e8: b               #0xa0aaa4
    // 0xa0a8ec: r0 = InitLateStaticField(0x2e8) // [dart:typed_data] ::_convU64
    //     0xa0a8ec: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0a8f0: ldr             x0, [x0, #0x5d0]
    //     0xa0a8f4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0a8f8: cmp             w0, w16
    //     0xa0a8fc: b.ne            #0xa0a90c
    //     0xa0a900: add             x2, PP, #8, lsl #12  ; [pp+0x81d8] Field <::._convU64@7027147>: static late final (offset: 0x2e8)
    //     0xa0a904: ldr             x2, [x2, #0x1d8]
    //     0xa0a908: bl              #0xd67cdc
    // 0xa0a90c: mov             x1, x0
    // 0xa0a910: ldur            x0, [fp, #-0x28]
    // 0xa0a914: LoadField: r2 = r0->field_17
    //     0xa0a914: ldur            w2, [x0, #0x17]
    // 0xa0a918: DecompressPointer r2
    //     0xa0a918: add             x2, x2, HEAP, lsl #32
    // 0xa0a91c: LoadField: r3 = r0->field_1b
    //     0xa0a91c: ldur            w3, [x0, #0x1b]
    // 0xa0a920: DecompressPointer r3
    //     0xa0a920: add             x3, x3, HEAP, lsl #32
    // 0xa0a924: r0 = LoadInt32Instr(r3)
    //     0xa0a924: sbfx            x0, x3, #1, #0x1f
    // 0xa0a928: ldur            x3, [fp, #-0x20]
    // 0xa0a92c: add             x4, x0, x3
    // 0xa0a930: LoadField: r0 = r2->field_7
    //     0xa0a930: ldur            x0, [x2, #7]
    // 0xa0a934: ldr             x2, [x0, x4]
    // 0xa0a938: mov             x0, x2
    // 0xa0a93c: ubfx            x0, x0, #0, #0x20
    // 0xa0a940: r3 = 4278255360
    //     0xa0a940: mov             x3, #0xff00
    //     0xa0a944: movk            x3, #0xff00, lsl #16
    // 0xa0a948: and             x4, x0, x3
    // 0xa0a94c: ubfx            x4, x4, #0, #0x20
    // 0xa0a950: asr             x0, x4, #8
    // 0xa0a954: mov             x4, x2
    // 0xa0a958: ubfx            x4, x4, #0, #0x20
    // 0xa0a95c: r5 = 16711935
    //     0xa0a95c: mov             x5, #0xff
    //     0xa0a960: movk            x5, #0xff, lsl #16
    // 0xa0a964: and             x6, x4, x5
    // 0xa0a968: ubfx            x6, x6, #0, #0x20
    // 0xa0a96c: lsl             x4, x6, #8
    // 0xa0a970: orr             x6, x0, x4
    // 0xa0a974: mov             x0, x6
    // 0xa0a978: ubfx            x0, x0, #0, #0x20
    // 0xa0a97c: r4 = 4294901760
    //     0xa0a97c: mov             x4, #0xffff0000
    // 0xa0a980: and             x7, x0, x4
    // 0xa0a984: ubfx            x7, x7, #0, #0x20
    // 0xa0a988: asr             x0, x7, #0x10
    // 0xa0a98c: ubfx            x6, x6, #0, #0x20
    // 0xa0a990: r7 = 65535
    //     0xa0a990: mov             x7, #0xffff
    // 0xa0a994: and             x8, x6, x7
    // 0xa0a998: ubfx            x8, x8, #0, #0x20
    // 0xa0a99c: lsl             x6, x8, #0x10
    // 0xa0a9a0: orr             x8, x0, x6
    // 0xa0a9a4: lsl             x0, x8, #0x20
    // 0xa0a9a8: asr             x6, x2, #0x20
    // 0xa0a9ac: mov             x2, x6
    // 0xa0a9b0: ubfx            x2, x2, #0, #0x20
    // 0xa0a9b4: and             x8, x2, x3
    // 0xa0a9b8: ubfx            x8, x8, #0, #0x20
    // 0xa0a9bc: asr             x2, x8, #8
    // 0xa0a9c0: ubfx            x6, x6, #0, #0x20
    // 0xa0a9c4: and             x3, x6, x5
    // 0xa0a9c8: ubfx            x3, x3, #0, #0x20
    // 0xa0a9cc: lsl             x5, x3, #8
    // 0xa0a9d0: orr             x3, x2, x5
    // 0xa0a9d4: mov             x2, x3
    // 0xa0a9d8: ubfx            x2, x2, #0, #0x20
    // 0xa0a9dc: and             x5, x2, x4
    // 0xa0a9e0: ubfx            x5, x5, #0, #0x20
    // 0xa0a9e4: asr             x2, x5, #0x10
    // 0xa0a9e8: ubfx            x3, x3, #0, #0x20
    // 0xa0a9ec: and             x4, x3, x7
    // 0xa0a9f0: ubfx            x4, x4, #0, #0x20
    // 0xa0a9f4: lsl             x3, x4, #0x10
    // 0xa0a9f8: orr             x4, x2, x3
    // 0xa0a9fc: orr             x2, x0, x4
    // 0xa0aa00: LoadField: r0 = r1->field_13
    //     0xa0aa00: ldur            w0, [x1, #0x13]
    // 0xa0aa04: DecompressPointer r0
    //     0xa0aa04: add             x0, x0, HEAP, lsl #32
    // 0xa0aa08: r3 = LoadInt32Instr(r0)
    //     0xa0aa08: sbfx            x3, x0, #1, #0x1f
    // 0xa0aa0c: stur            x3, [fp, #-0x20]
    // 0xa0aa10: cmp             x3, #0
    // 0xa0aa14: b.le            #0xa0ab24
    // 0xa0aa18: r4 = true
    //     0xa0aa18: add             x4, NULL, #0x20  ; true
    // 0xa0aa1c: r0 = "index"
    //     0xa0aa1c: ldr             x0, [PP, #0xd38]  ; [pp+0xd38] "index"
    // 0xa0aa20: r3 = "Index out of range"
    //     0xa0aa20: ldr             x3, [PP, #0xd40]  ; [pp+0xd40] "Index out of range"
    // 0xa0aa24: LoadField: r5 = r1->field_17
    //     0xa0aa24: ldur            w5, [x1, #0x17]
    // 0xa0aa28: DecompressPointer r5
    //     0xa0aa28: add             x5, x5, HEAP, lsl #32
    // 0xa0aa2c: LoadField: r6 = r1->field_1b
    //     0xa0aa2c: ldur            w6, [x1, #0x1b]
    // 0xa0aa30: DecompressPointer r6
    //     0xa0aa30: add             x6, x6, HEAP, lsl #32
    // 0xa0aa34: LoadField: r1 = r5->field_7
    //     0xa0aa34: ldur            x1, [x5, #7]
    // 0xa0aa38: asr             w5, w6, #1
    // 0xa0aa3c: add             x5, x1, w5, sxtw
    // 0xa0aa40: str             x2, [x5]
    // 0xa0aa44: r0 = InitLateStaticField(0x2f0) // [dart:typed_data] ::_convF64
    //     0xa0aa44: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0aa48: ldr             x0, [x0, #0x5e0]
    //     0xa0aa4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0aa50: cmp             w0, w16
    //     0xa0aa54: b.ne            #0xa0aa64
    //     0xa0aa58: add             x2, PP, #8, lsl #12  ; [pp+0x81e0] Field <::._convF64@7027147>: static late final (offset: 0x2f0)
    //     0xa0aa5c: ldr             x2, [x2, #0x1e0]
    //     0xa0aa60: bl              #0xd67cdc
    // 0xa0aa64: LoadField: r1 = r0->field_13
    //     0xa0aa64: ldur            w1, [x0, #0x13]
    // 0xa0aa68: DecompressPointer r1
    //     0xa0aa68: add             x1, x1, HEAP, lsl #32
    // 0xa0aa6c: r2 = LoadInt32Instr(r1)
    //     0xa0aa6c: sbfx            x2, x1, #1, #0x1f
    // 0xa0aa70: stur            x2, [fp, #-0x20]
    // 0xa0aa74: cmp             x2, #0
    // 0xa0aa78: b.le            #0xa0ab5c
    // 0xa0aa7c: LoadField: r1 = r0->field_17
    //     0xa0aa7c: ldur            w1, [x0, #0x17]
    // 0xa0aa80: DecompressPointer r1
    //     0xa0aa80: add             x1, x1, HEAP, lsl #32
    // 0xa0aa84: LoadField: r2 = r0->field_1b
    //     0xa0aa84: ldur            w2, [x0, #0x1b]
    // 0xa0aa88: DecompressPointer r2
    //     0xa0aa88: add             x2, x2, HEAP, lsl #32
    // 0xa0aa8c: LoadField: r0 = r1->field_7
    //     0xa0aa8c: ldur            x0, [x1, #7]
    // 0xa0aa90: asr             w16, w2, #1
    // 0xa0aa94: add             x16, x0, w16, sxtw
    // 0xa0aa98: ldr             d1, [x16]
    // 0xa0aa9c: mov             v0.16b, v1.16b
    // 0xa0aaa0: ldr             x0, [fp, #0x18]
    // 0xa0aaa4: LoadField: r1 = r0->field_9b
    //     0xa0aaa4: ldur            x1, [x0, #0x9b]
    // 0xa0aaa8: add             x2, x1, #8
    // 0xa0aaac: StoreField: r0->field_9b = r2
    //     0xa0aaac: stur            x2, [x0, #0x9b]
    // 0xa0aab0: LeaveFrame
    //     0xa0aab0: mov             SP, fp
    //     0xa0aab4: ldp             fp, lr, [SP], #0x10
    // 0xa0aab8: ret
    //     0xa0aab8: ret             
    // 0xa0aabc: LoadField: r0 = r1->field_13
    //     0xa0aabc: ldur            w0, [x1, #0x13]
    // 0xa0aac0: DecompressPointer r0
    //     0xa0aac0: add             x0, x0, HEAP, lsl #32
    // 0xa0aac4: r1 = LoadInt32Instr(r0)
    //     0xa0aac4: sbfx            x1, x0, #1, #0x1f
    // 0xa0aac8: sub             x3, x1, #8
    // 0xa0aacc: r0 = BoxInt64Instr(r2)
    //     0xa0aacc: sbfiz           x0, x2, #1, #0x1f
    //     0xa0aad0: cmp             x2, x0, asr #1
    //     0xa0aad4: b.eq            #0xa0aae0
    //     0xa0aad8: bl              #0xd69bb8
    //     0xa0aadc: stur            x2, [x0, #7]
    // 0xa0aae0: stur            x0, [fp, #-0x10]
    // 0xa0aae4: lsl             x1, x3, #1
    // 0xa0aae8: stur            x1, [fp, #-8]
    // 0xa0aaec: r0 = RangeError()
    //     0xa0aaec: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa0aaf0: stur            x0, [fp, #-0x18]
    // 0xa0aaf4: ldur            x16, [fp, #-0x10]
    // 0xa0aaf8: stp             x16, x0, [SP, #-0x10]!
    // 0xa0aafc: ldur            x16, [fp, #-8]
    // 0xa0ab00: stp             x16, xzr, [SP, #-0x10]!
    // 0xa0ab04: r16 = "byteOffset"
    //     0xa0ab04: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa0ab08: SaveReg r16
    //     0xa0ab08: str             x16, [SP, #-8]!
    // 0xa0ab0c: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa0ab0c: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa0ab10: r0 = RangeError.range()
    //     0xa0ab10: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa0ab14: add             SP, SP, #0x28
    // 0xa0ab18: ldur            x0, [fp, #-0x18]
    // 0xa0ab1c: r0 = Throw()
    //     0xa0ab1c: bl              #0xd67e38  ; ThrowStub
    // 0xa0ab20: brk             #0
    // 0xa0ab24: r0 = IndexError()
    //     0xa0ab24: bl              #0x4c67ac  ; AllocateIndexErrorStub -> IndexError (size=0x24)
    // 0xa0ab28: mov             x1, x0
    // 0xa0ab2c: ldur            x0, [fp, #-0x20]
    // 0xa0ab30: StoreField: r1->field_1b = r0
    //     0xa0ab30: stur            x0, [x1, #0x1b]
    // 0xa0ab34: r0 = "index"
    //     0xa0ab34: ldr             x0, [PP, #0xd38]  ; [pp+0xd38] "index"
    // 0xa0ab38: StoreField: r1->field_13 = r0
    //     0xa0ab38: stur            w0, [x1, #0x13]
    // 0xa0ab3c: r3 = "Index out of range"
    //     0xa0ab3c: ldr             x3, [PP, #0xd40]  ; [pp+0xd40] "Index out of range"
    // 0xa0ab40: StoreField: r1->field_17 = r3
    //     0xa0ab40: stur            w3, [x1, #0x17]
    // 0xa0ab44: StoreField: r1->field_f = rZR
    //     0xa0ab44: stur            wzr, [x1, #0xf]
    // 0xa0ab48: r4 = true
    //     0xa0ab48: add             x4, NULL, #0x20  ; true
    // 0xa0ab4c: StoreField: r1->field_b = r4
    //     0xa0ab4c: stur            w4, [x1, #0xb]
    // 0xa0ab50: mov             x0, x1
    // 0xa0ab54: r0 = Throw()
    //     0xa0ab54: bl              #0xd67e38  ; ThrowStub
    // 0xa0ab58: brk             #0
    // 0xa0ab5c: r0 = IndexError()
    //     0xa0ab5c: bl              #0x4c67ac  ; AllocateIndexErrorStub -> IndexError (size=0x24)
    // 0xa0ab60: mov             x1, x0
    // 0xa0ab64: ldur            x0, [fp, #-0x20]
    // 0xa0ab68: StoreField: r1->field_1b = r0
    //     0xa0ab68: stur            x0, [x1, #0x1b]
    // 0xa0ab6c: r0 = "index"
    //     0xa0ab6c: ldr             x0, [PP, #0xd38]  ; [pp+0xd38] "index"
    // 0xa0ab70: StoreField: r1->field_13 = r0
    //     0xa0ab70: stur            w0, [x1, #0x13]
    // 0xa0ab74: r0 = "Index out of range"
    //     0xa0ab74: ldr             x0, [PP, #0xd40]  ; [pp+0xd40] "Index out of range"
    // 0xa0ab78: StoreField: r1->field_17 = r0
    //     0xa0ab78: stur            w0, [x1, #0x17]
    // 0xa0ab7c: StoreField: r1->field_f = rZR
    //     0xa0ab7c: stur            wzr, [x1, #0xf]
    // 0xa0ab80: r0 = true
    //     0xa0ab80: add             x0, NULL, #0x20  ; true
    // 0xa0ab84: StoreField: r1->field_b = r0
    //     0xa0ab84: stur            w0, [x1, #0xb]
    // 0xa0ab88: mov             x0, x1
    // 0xa0ab8c: r0 = Throw()
    //     0xa0ab8c: bl              #0xd67e38  ; ThrowStub
    // 0xa0ab90: brk             #0
    // 0xa0ab94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0ab94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0ab98: b               #0xa0a878
    // 0xa0ab9c: r9 = _view
    //     0xa0ab9c: add             x9, PP, #8, lsl #12  ; [pp+0x81e8] Field <DBusReadBuffer._view@326485801>: late (offset: 0x98)
    //     0xa0aba0: ldr             x9, [x9, #0x1e8]
    // 0xa0aba4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa0aba4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ readDBusUint64(/* No info */) {
    // ** addr: 0xa0afa0, size: 0x9c
    // 0xa0afa0: EnterFrame
    //     0xa0afa0: stp             fp, lr, [SP, #-0x10]!
    //     0xa0afa4: mov             fp, SP
    // 0xa0afa8: AllocStack(0x8)
    //     0xa0afa8: sub             SP, SP, #8
    // 0xa0afac: r0 = 8
    //     0xa0afac: mov             x0, #8
    // 0xa0afb0: CheckStackOverflow
    //     0xa0afb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0afb4: cmp             SP, x16
    //     0xa0afb8: b.ls            #0xa0b034
    // 0xa0afbc: ldr             x16, [fp, #0x18]
    // 0xa0afc0: stp             x0, x16, [SP, #-0x10]!
    // 0xa0afc4: r0 = align()
    //     0xa0afc4: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa0afc8: add             SP, SP, #0x10
    // 0xa0afcc: tbnz            w0, #4, #0xa0aff8
    // 0xa0afd0: ldr             x0, [fp, #0x18]
    // 0xa0afd4: LoadField: r1 = r0->field_8f
    //     0xa0afd4: ldur            w1, [x0, #0x8f]
    // 0xa0afd8: DecompressPointer r1
    //     0xa0afd8: add             x1, x1, HEAP, lsl #32
    // 0xa0afdc: LoadField: r2 = r1->field_13
    //     0xa0afdc: ldur            w2, [x1, #0x13]
    // 0xa0afe0: DecompressPointer r2
    //     0xa0afe0: add             x2, x2, HEAP, lsl #32
    // 0xa0afe4: LoadField: r1 = r0->field_9b
    //     0xa0afe4: ldur            x1, [x0, #0x9b]
    // 0xa0afe8: r3 = LoadInt32Instr(r2)
    //     0xa0afe8: sbfx            x3, x2, #1, #0x1f
    // 0xa0afec: sub             x2, x3, x1
    // 0xa0aff0: cmp             x2, #8
    // 0xa0aff4: b.ge            #0xa0b008
    // 0xa0aff8: r0 = Null
    //     0xa0aff8: mov             x0, NULL
    // 0xa0affc: LeaveFrame
    //     0xa0affc: mov             SP, fp
    //     0xa0b000: ldp             fp, lr, [SP], #0x10
    // 0xa0b004: ret
    //     0xa0b004: ret             
    // 0xa0b008: ldr             x16, [fp, #0x10]
    // 0xa0b00c: stp             x16, x0, [SP, #-0x10]!
    // 0xa0b010: r0 = readUint64()
    //     0xa0b010: bl              #0xa0b048  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readUint64
    // 0xa0b014: add             SP, SP, #0x10
    // 0xa0b018: stur            x0, [fp, #-8]
    // 0xa0b01c: r0 = DBusUint64()
    //     0xa0b01c: bl              #0xa0b03c  ; AllocateDBusUint64Stub -> DBusUint64 (size=0x10)
    // 0xa0b020: ldur            x1, [fp, #-8]
    // 0xa0b024: StoreField: r0->field_7 = r1
    //     0xa0b024: stur            x1, [x0, #7]
    // 0xa0b028: LeaveFrame
    //     0xa0b028: mov             SP, fp
    //     0xa0b02c: ldp             fp, lr, [SP], #0x10
    // 0xa0b030: ret
    //     0xa0b030: ret             
    // 0xa0b034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0b034: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0b038: b               #0xa0afbc
  }
  _ readUint64(/* No info */) {
    // ** addr: 0xa0b048, size: 0x1e4
    // 0xa0b048: EnterFrame
    //     0xa0b048: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b04c: mov             fp, SP
    // 0xa0b050: AllocStack(0x18)
    //     0xa0b050: sub             SP, SP, #0x18
    // 0xa0b054: CheckStackOverflow
    //     0xa0b054: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0b058: cmp             SP, x16
    //     0xa0b05c: b.ls            #0xa0b218
    // 0xa0b060: ldr             x0, [fp, #0x18]
    // 0xa0b064: LoadField: r1 = r0->field_97
    //     0xa0b064: ldur            w1, [x0, #0x97]
    // 0xa0b068: DecompressPointer r1
    //     0xa0b068: add             x1, x1, HEAP, lsl #32
    // 0xa0b06c: r16 = Sentinel
    //     0xa0b06c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0b070: cmp             w1, w16
    // 0xa0b074: b.eq            #0xa0b220
    // 0xa0b078: LoadField: r2 = r0->field_9b
    //     0xa0b078: ldur            x2, [x0, #0x9b]
    // 0xa0b07c: tbnz            x2, #0x3f, #0xa0b1b0
    // 0xa0b080: add             x3, x2, #7
    // 0xa0b084: LoadField: r4 = r1->field_13
    //     0xa0b084: ldur            w4, [x1, #0x13]
    // 0xa0b088: DecompressPointer r4
    //     0xa0b088: add             x4, x4, HEAP, lsl #32
    // 0xa0b08c: r5 = LoadInt32Instr(r4)
    //     0xa0b08c: sbfx            x5, x4, #1, #0x1f
    // 0xa0b090: cmp             x3, x5
    // 0xa0b094: b.ge            #0xa0b1b0
    // 0xa0b098: ldr             x3, [fp, #0x10]
    // 0xa0b09c: LoadField: r4 = r1->field_17
    //     0xa0b09c: ldur            w4, [x1, #0x17]
    // 0xa0b0a0: DecompressPointer r4
    //     0xa0b0a0: add             x4, x4, HEAP, lsl #32
    // 0xa0b0a4: LoadField: r5 = r1->field_1b
    //     0xa0b0a4: ldur            w5, [x1, #0x1b]
    // 0xa0b0a8: DecompressPointer r5
    //     0xa0b0a8: add             x5, x5, HEAP, lsl #32
    // 0xa0b0ac: r1 = LoadInt32Instr(r5)
    //     0xa0b0ac: sbfx            x1, x5, #1, #0x1f
    // 0xa0b0b0: add             x5, x1, x2
    // 0xa0b0b4: LoadField: r1 = r4->field_7
    //     0xa0b0b4: ldur            x1, [x4, #7]
    // 0xa0b0b8: ldr             x4, [x1, x5]
    // 0xa0b0bc: r16 = Instance_Endian
    //     0xa0b0bc: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xa0b0c0: cmp             w3, w16
    // 0xa0b0c4: b.ne            #0xa0b0d0
    // 0xa0b0c8: mov             x1, x4
    // 0xa0b0cc: b               #0xa0b198
    // 0xa0b0d0: r6 = 4278255360
    //     0xa0b0d0: mov             x6, #0xff00
    //     0xa0b0d4: movk            x6, #0xff00, lsl #16
    // 0xa0b0d8: r5 = 16711935
    //     0xa0b0d8: mov             x5, #0xff
    //     0xa0b0dc: movk            x5, #0xff, lsl #16
    // 0xa0b0e0: r3 = 4294901760
    //     0xa0b0e0: mov             x3, #0xffff0000
    // 0xa0b0e4: r1 = 65535
    //     0xa0b0e4: mov             x1, #0xffff
    // 0xa0b0e8: mov             x7, x4
    // 0xa0b0ec: ubfx            x7, x7, #0, #0x20
    // 0xa0b0f0: and             x8, x7, x6
    // 0xa0b0f4: ubfx            x8, x8, #0, #0x20
    // 0xa0b0f8: asr             x7, x8, #8
    // 0xa0b0fc: mov             x8, x4
    // 0xa0b100: ubfx            x8, x8, #0, #0x20
    // 0xa0b104: and             x9, x8, x5
    // 0xa0b108: ubfx            x9, x9, #0, #0x20
    // 0xa0b10c: lsl             x8, x9, #8
    // 0xa0b110: orr             x9, x7, x8
    // 0xa0b114: mov             x7, x9
    // 0xa0b118: ubfx            x7, x7, #0, #0x20
    // 0xa0b11c: and             x8, x7, x3
    // 0xa0b120: ubfx            x8, x8, #0, #0x20
    // 0xa0b124: asr             x7, x8, #0x10
    // 0xa0b128: ubfx            x9, x9, #0, #0x20
    // 0xa0b12c: and             x8, x9, x1
    // 0xa0b130: ubfx            x8, x8, #0, #0x20
    // 0xa0b134: lsl             x9, x8, #0x10
    // 0xa0b138: orr             x8, x7, x9
    // 0xa0b13c: lsl             x7, x8, #0x20
    // 0xa0b140: asr             x8, x4, #0x20
    // 0xa0b144: mov             x4, x8
    // 0xa0b148: ubfx            x4, x4, #0, #0x20
    // 0xa0b14c: and             x9, x4, x6
    // 0xa0b150: ubfx            x9, x9, #0, #0x20
    // 0xa0b154: asr             x4, x9, #8
    // 0xa0b158: ubfx            x8, x8, #0, #0x20
    // 0xa0b15c: and             x6, x8, x5
    // 0xa0b160: ubfx            x6, x6, #0, #0x20
    // 0xa0b164: lsl             x5, x6, #8
    // 0xa0b168: orr             x6, x4, x5
    // 0xa0b16c: mov             x4, x6
    // 0xa0b170: ubfx            x4, x4, #0, #0x20
    // 0xa0b174: and             x5, x4, x3
    // 0xa0b178: ubfx            x5, x5, #0, #0x20
    // 0xa0b17c: asr             x3, x5, #0x10
    // 0xa0b180: ubfx            x6, x6, #0, #0x20
    // 0xa0b184: and             x4, x6, x1
    // 0xa0b188: ubfx            x4, x4, #0, #0x20
    // 0xa0b18c: lsl             x1, x4, #0x10
    // 0xa0b190: orr             x4, x3, x1
    // 0xa0b194: orr             x1, x7, x4
    // 0xa0b198: add             x3, x2, #8
    // 0xa0b19c: StoreField: r0->field_9b = r3
    //     0xa0b19c: stur            x3, [x0, #0x9b]
    // 0xa0b1a0: mov             x0, x1
    // 0xa0b1a4: LeaveFrame
    //     0xa0b1a4: mov             SP, fp
    //     0xa0b1a8: ldp             fp, lr, [SP], #0x10
    // 0xa0b1ac: ret
    //     0xa0b1ac: ret             
    // 0xa0b1b0: LoadField: r0 = r1->field_13
    //     0xa0b1b0: ldur            w0, [x1, #0x13]
    // 0xa0b1b4: DecompressPointer r0
    //     0xa0b1b4: add             x0, x0, HEAP, lsl #32
    // 0xa0b1b8: r1 = LoadInt32Instr(r0)
    //     0xa0b1b8: sbfx            x1, x0, #1, #0x1f
    // 0xa0b1bc: sub             x3, x1, #8
    // 0xa0b1c0: r0 = BoxInt64Instr(r2)
    //     0xa0b1c0: sbfiz           x0, x2, #1, #0x1f
    //     0xa0b1c4: cmp             x2, x0, asr #1
    //     0xa0b1c8: b.eq            #0xa0b1d4
    //     0xa0b1cc: bl              #0xd69bb8
    //     0xa0b1d0: stur            x2, [x0, #7]
    // 0xa0b1d4: stur            x0, [fp, #-0x10]
    // 0xa0b1d8: lsl             x1, x3, #1
    // 0xa0b1dc: stur            x1, [fp, #-8]
    // 0xa0b1e0: r0 = RangeError()
    //     0xa0b1e0: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa0b1e4: stur            x0, [fp, #-0x18]
    // 0xa0b1e8: ldur            x16, [fp, #-0x10]
    // 0xa0b1ec: stp             x16, x0, [SP, #-0x10]!
    // 0xa0b1f0: ldur            x16, [fp, #-8]
    // 0xa0b1f4: stp             x16, xzr, [SP, #-0x10]!
    // 0xa0b1f8: r16 = "byteOffset"
    //     0xa0b1f8: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa0b1fc: SaveReg r16
    //     0xa0b1fc: str             x16, [SP, #-8]!
    // 0xa0b200: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa0b200: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa0b204: r0 = RangeError.range()
    //     0xa0b204: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa0b208: add             SP, SP, #0x28
    // 0xa0b20c: ldur            x0, [fp, #-0x18]
    // 0xa0b210: r0 = Throw()
    //     0xa0b210: bl              #0xd67e38  ; ThrowStub
    // 0xa0b214: brk             #0
    // 0xa0b218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0b218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0b21c: b               #0xa0b060
    // 0xa0b220: r9 = _view
    //     0xa0b220: add             x9, PP, #8, lsl #12  ; [pp+0x81e8] Field <DBusReadBuffer._view@326485801>: late (offset: 0x98)
    //     0xa0b224: ldr             x9, [x9, #0x1e8]
    // 0xa0b228: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa0b228: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ readDBusInt64(/* No info */) {
    // ** addr: 0xa0b22c, size: 0x9c
    // 0xa0b22c: EnterFrame
    //     0xa0b22c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b230: mov             fp, SP
    // 0xa0b234: AllocStack(0x8)
    //     0xa0b234: sub             SP, SP, #8
    // 0xa0b238: r0 = 8
    //     0xa0b238: mov             x0, #8
    // 0xa0b23c: CheckStackOverflow
    //     0xa0b23c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0b240: cmp             SP, x16
    //     0xa0b244: b.ls            #0xa0b2c0
    // 0xa0b248: ldr             x16, [fp, #0x18]
    // 0xa0b24c: stp             x0, x16, [SP, #-0x10]!
    // 0xa0b250: r0 = align()
    //     0xa0b250: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa0b254: add             SP, SP, #0x10
    // 0xa0b258: tbnz            w0, #4, #0xa0b284
    // 0xa0b25c: ldr             x0, [fp, #0x18]
    // 0xa0b260: LoadField: r1 = r0->field_8f
    //     0xa0b260: ldur            w1, [x0, #0x8f]
    // 0xa0b264: DecompressPointer r1
    //     0xa0b264: add             x1, x1, HEAP, lsl #32
    // 0xa0b268: LoadField: r2 = r1->field_13
    //     0xa0b268: ldur            w2, [x1, #0x13]
    // 0xa0b26c: DecompressPointer r2
    //     0xa0b26c: add             x2, x2, HEAP, lsl #32
    // 0xa0b270: LoadField: r1 = r0->field_9b
    //     0xa0b270: ldur            x1, [x0, #0x9b]
    // 0xa0b274: r3 = LoadInt32Instr(r2)
    //     0xa0b274: sbfx            x3, x2, #1, #0x1f
    // 0xa0b278: sub             x2, x3, x1
    // 0xa0b27c: cmp             x2, #8
    // 0xa0b280: b.ge            #0xa0b294
    // 0xa0b284: r0 = Null
    //     0xa0b284: mov             x0, NULL
    // 0xa0b288: LeaveFrame
    //     0xa0b288: mov             SP, fp
    //     0xa0b28c: ldp             fp, lr, [SP], #0x10
    // 0xa0b290: ret
    //     0xa0b290: ret             
    // 0xa0b294: ldr             x16, [fp, #0x10]
    // 0xa0b298: stp             x16, x0, [SP, #-0x10]!
    // 0xa0b29c: r0 = readInt64()
    //     0xa0b29c: bl              #0xa0b2d4  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readInt64
    // 0xa0b2a0: add             SP, SP, #0x10
    // 0xa0b2a4: stur            x0, [fp, #-8]
    // 0xa0b2a8: r0 = DBusInt64()
    //     0xa0b2a8: bl              #0xa0b2c8  ; AllocateDBusInt64Stub -> DBusInt64 (size=0x10)
    // 0xa0b2ac: ldur            x1, [fp, #-8]
    // 0xa0b2b0: StoreField: r0->field_7 = r1
    //     0xa0b2b0: stur            x1, [x0, #7]
    // 0xa0b2b4: LeaveFrame
    //     0xa0b2b4: mov             SP, fp
    //     0xa0b2b8: ldp             fp, lr, [SP], #0x10
    // 0xa0b2bc: ret
    //     0xa0b2bc: ret             
    // 0xa0b2c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0b2c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0b2c4: b               #0xa0b248
  }
  _ readInt64(/* No info */) {
    // ** addr: 0xa0b2d4, size: 0x1f0
    // 0xa0b2d4: EnterFrame
    //     0xa0b2d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b2d8: mov             fp, SP
    // 0xa0b2dc: AllocStack(0x18)
    //     0xa0b2dc: sub             SP, SP, #0x18
    // 0xa0b2e0: CheckStackOverflow
    //     0xa0b2e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0b2e4: cmp             SP, x16
    //     0xa0b2e8: b.ls            #0xa0b4b0
    // 0xa0b2ec: ldr             x0, [fp, #0x18]
    // 0xa0b2f0: LoadField: r1 = r0->field_97
    //     0xa0b2f0: ldur            w1, [x0, #0x97]
    // 0xa0b2f4: DecompressPointer r1
    //     0xa0b2f4: add             x1, x1, HEAP, lsl #32
    // 0xa0b2f8: r16 = Sentinel
    //     0xa0b2f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0b2fc: cmp             w1, w16
    // 0xa0b300: b.eq            #0xa0b4b8
    // 0xa0b304: LoadField: r2 = r0->field_9b
    //     0xa0b304: ldur            x2, [x0, #0x9b]
    // 0xa0b308: tbnz            x2, #0x3f, #0xa0b448
    // 0xa0b30c: add             x3, x2, #7
    // 0xa0b310: LoadField: r4 = r1->field_13
    //     0xa0b310: ldur            w4, [x1, #0x13]
    // 0xa0b314: DecompressPointer r4
    //     0xa0b314: add             x4, x4, HEAP, lsl #32
    // 0xa0b318: r5 = LoadInt32Instr(r4)
    //     0xa0b318: sbfx            x5, x4, #1, #0x1f
    // 0xa0b31c: cmp             x3, x5
    // 0xa0b320: b.ge            #0xa0b448
    // 0xa0b324: ldr             x3, [fp, #0x10]
    // 0xa0b328: LoadField: r4 = r1->field_17
    //     0xa0b328: ldur            w4, [x1, #0x17]
    // 0xa0b32c: DecompressPointer r4
    //     0xa0b32c: add             x4, x4, HEAP, lsl #32
    // 0xa0b330: LoadField: r5 = r1->field_1b
    //     0xa0b330: ldur            w5, [x1, #0x1b]
    // 0xa0b334: DecompressPointer r5
    //     0xa0b334: add             x5, x5, HEAP, lsl #32
    // 0xa0b338: r1 = LoadInt32Instr(r5)
    //     0xa0b338: sbfx            x1, x5, #1, #0x1f
    // 0xa0b33c: add             x5, x1, x2
    // 0xa0b340: LoadField: r1 = r4->field_7
    //     0xa0b340: ldur            x1, [x4, #7]
    // 0xa0b344: ldr             x4, [x1, x5]
    // 0xa0b348: r16 = Instance_Endian
    //     0xa0b348: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xa0b34c: cmp             w3, w16
    // 0xa0b350: b.ne            #0xa0b35c
    // 0xa0b354: mov             x1, x4
    // 0xa0b358: b               #0xa0b430
    // 0xa0b35c: r6 = 4278255360
    //     0xa0b35c: mov             x6, #0xff00
    //     0xa0b360: movk            x6, #0xff00, lsl #16
    // 0xa0b364: r5 = 16711935
    //     0xa0b364: mov             x5, #0xff
    //     0xa0b368: movk            x5, #0xff, lsl #16
    // 0xa0b36c: r3 = 4294901760
    //     0xa0b36c: mov             x3, #0xffff0000
    // 0xa0b370: r1 = 65535
    //     0xa0b370: mov             x1, #0xffff
    // 0xa0b374: mov             x7, x4
    // 0xa0b378: ubfx            x7, x7, #0, #0x20
    // 0xa0b37c: and             x8, x7, x6
    // 0xa0b380: ubfx            x8, x8, #0, #0x20
    // 0xa0b384: asr             x7, x8, #8
    // 0xa0b388: mov             x8, x4
    // 0xa0b38c: ubfx            x8, x8, #0, #0x20
    // 0xa0b390: and             x9, x8, x5
    // 0xa0b394: ubfx            x9, x9, #0, #0x20
    // 0xa0b398: lsl             x8, x9, #8
    // 0xa0b39c: orr             x9, x7, x8
    // 0xa0b3a0: mov             x7, x9
    // 0xa0b3a4: ubfx            x7, x7, #0, #0x20
    // 0xa0b3a8: and             x8, x7, x3
    // 0xa0b3ac: ubfx            x8, x8, #0, #0x20
    // 0xa0b3b0: asr             x7, x8, #0x10
    // 0xa0b3b4: ubfx            x9, x9, #0, #0x20
    // 0xa0b3b8: and             x8, x9, x1
    // 0xa0b3bc: ubfx            x8, x8, #0, #0x20
    // 0xa0b3c0: lsl             x9, x8, #0x10
    // 0xa0b3c4: orr             x8, x7, x9
    // 0xa0b3c8: lsl             x7, x8, #0x20
    // 0xa0b3cc: asr             x8, x4, #0x20
    // 0xa0b3d0: mov             x4, x8
    // 0xa0b3d4: ubfx            x4, x4, #0, #0x20
    // 0xa0b3d8: and             x9, x4, x6
    // 0xa0b3dc: ubfx            x9, x9, #0, #0x20
    // 0xa0b3e0: asr             x4, x9, #8
    // 0xa0b3e4: ubfx            x8, x8, #0, #0x20
    // 0xa0b3e8: and             x6, x8, x5
    // 0xa0b3ec: ubfx            x6, x6, #0, #0x20
    // 0xa0b3f0: lsl             x5, x6, #8
    // 0xa0b3f4: orr             x6, x4, x5
    // 0xa0b3f8: mov             x4, x6
    // 0xa0b3fc: ubfx            x4, x4, #0, #0x20
    // 0xa0b400: and             x5, x4, x3
    // 0xa0b404: ubfx            x5, x5, #0, #0x20
    // 0xa0b408: asr             x3, x5, #0x10
    // 0xa0b40c: ubfx            x6, x6, #0, #0x20
    // 0xa0b410: and             x4, x6, x1
    // 0xa0b414: ubfx            x4, x4, #0, #0x20
    // 0xa0b418: lsl             x1, x4, #0x10
    // 0xa0b41c: orr             x4, x3, x1
    // 0xa0b420: orr             x1, x7, x4
    // 0xa0b424: and             x3, x1, #0x7fffffffffffffff
    // 0xa0b428: and             x4, x1, #0x8000000000000000
    // 0xa0b42c: sub             x1, x3, x4
    // 0xa0b430: add             x3, x2, #8
    // 0xa0b434: StoreField: r0->field_9b = r3
    //     0xa0b434: stur            x3, [x0, #0x9b]
    // 0xa0b438: mov             x0, x1
    // 0xa0b43c: LeaveFrame
    //     0xa0b43c: mov             SP, fp
    //     0xa0b440: ldp             fp, lr, [SP], #0x10
    // 0xa0b444: ret
    //     0xa0b444: ret             
    // 0xa0b448: LoadField: r0 = r1->field_13
    //     0xa0b448: ldur            w0, [x1, #0x13]
    // 0xa0b44c: DecompressPointer r0
    //     0xa0b44c: add             x0, x0, HEAP, lsl #32
    // 0xa0b450: r1 = LoadInt32Instr(r0)
    //     0xa0b450: sbfx            x1, x0, #1, #0x1f
    // 0xa0b454: sub             x3, x1, #8
    // 0xa0b458: r0 = BoxInt64Instr(r2)
    //     0xa0b458: sbfiz           x0, x2, #1, #0x1f
    //     0xa0b45c: cmp             x2, x0, asr #1
    //     0xa0b460: b.eq            #0xa0b46c
    //     0xa0b464: bl              #0xd69bb8
    //     0xa0b468: stur            x2, [x0, #7]
    // 0xa0b46c: stur            x0, [fp, #-0x10]
    // 0xa0b470: lsl             x1, x3, #1
    // 0xa0b474: stur            x1, [fp, #-8]
    // 0xa0b478: r0 = RangeError()
    //     0xa0b478: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa0b47c: stur            x0, [fp, #-0x18]
    // 0xa0b480: ldur            x16, [fp, #-0x10]
    // 0xa0b484: stp             x16, x0, [SP, #-0x10]!
    // 0xa0b488: ldur            x16, [fp, #-8]
    // 0xa0b48c: stp             x16, xzr, [SP, #-0x10]!
    // 0xa0b490: r16 = "byteOffset"
    //     0xa0b490: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa0b494: SaveReg r16
    //     0xa0b494: str             x16, [SP, #-8]!
    // 0xa0b498: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa0b498: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa0b49c: r0 = RangeError.range()
    //     0xa0b49c: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa0b4a0: add             SP, SP, #0x28
    // 0xa0b4a4: ldur            x0, [fp, #-0x18]
    // 0xa0b4a8: r0 = Throw()
    //     0xa0b4a8: bl              #0xd67e38  ; ThrowStub
    // 0xa0b4ac: brk             #0
    // 0xa0b4b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0b4b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0b4b4: b               #0xa0b2ec
    // 0xa0b4b8: r9 = _view
    //     0xa0b4b8: add             x9, PP, #8, lsl #12  ; [pp+0x81e8] Field <DBusReadBuffer._view@326485801>: late (offset: 0x98)
    //     0xa0b4bc: ldr             x9, [x9, #0x1e8]
    // 0xa0b4c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa0b4c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ readDBusInt32(/* No info */) {
    // ** addr: 0xa0b4c4, size: 0x9c
    // 0xa0b4c4: EnterFrame
    //     0xa0b4c4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b4c8: mov             fp, SP
    // 0xa0b4cc: AllocStack(0x8)
    //     0xa0b4cc: sub             SP, SP, #8
    // 0xa0b4d0: r0 = 4
    //     0xa0b4d0: mov             x0, #4
    // 0xa0b4d4: CheckStackOverflow
    //     0xa0b4d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0b4d8: cmp             SP, x16
    //     0xa0b4dc: b.ls            #0xa0b558
    // 0xa0b4e0: ldr             x16, [fp, #0x18]
    // 0xa0b4e4: stp             x0, x16, [SP, #-0x10]!
    // 0xa0b4e8: r0 = align()
    //     0xa0b4e8: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa0b4ec: add             SP, SP, #0x10
    // 0xa0b4f0: tbnz            w0, #4, #0xa0b51c
    // 0xa0b4f4: ldr             x0, [fp, #0x18]
    // 0xa0b4f8: LoadField: r1 = r0->field_8f
    //     0xa0b4f8: ldur            w1, [x0, #0x8f]
    // 0xa0b4fc: DecompressPointer r1
    //     0xa0b4fc: add             x1, x1, HEAP, lsl #32
    // 0xa0b500: LoadField: r2 = r1->field_13
    //     0xa0b500: ldur            w2, [x1, #0x13]
    // 0xa0b504: DecompressPointer r2
    //     0xa0b504: add             x2, x2, HEAP, lsl #32
    // 0xa0b508: LoadField: r1 = r0->field_9b
    //     0xa0b508: ldur            x1, [x0, #0x9b]
    // 0xa0b50c: r3 = LoadInt32Instr(r2)
    //     0xa0b50c: sbfx            x3, x2, #1, #0x1f
    // 0xa0b510: sub             x2, x3, x1
    // 0xa0b514: cmp             x2, #4
    // 0xa0b518: b.ge            #0xa0b52c
    // 0xa0b51c: r0 = Null
    //     0xa0b51c: mov             x0, NULL
    // 0xa0b520: LeaveFrame
    //     0xa0b520: mov             SP, fp
    //     0xa0b524: ldp             fp, lr, [SP], #0x10
    // 0xa0b528: ret
    //     0xa0b528: ret             
    // 0xa0b52c: ldr             x16, [fp, #0x10]
    // 0xa0b530: stp             x16, x0, [SP, #-0x10]!
    // 0xa0b534: r0 = readInt32()
    //     0xa0b534: bl              #0xa0b56c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readInt32
    // 0xa0b538: add             SP, SP, #0x10
    // 0xa0b53c: stur            x0, [fp, #-8]
    // 0xa0b540: r0 = DBusInt32()
    //     0xa0b540: bl              #0xa0b560  ; AllocateDBusInt32Stub -> DBusInt32 (size=0x10)
    // 0xa0b544: ldur            x1, [fp, #-8]
    // 0xa0b548: StoreField: r0->field_7 = r1
    //     0xa0b548: stur            x1, [x0, #7]
    // 0xa0b54c: LeaveFrame
    //     0xa0b54c: mov             SP, fp
    //     0xa0b550: ldp             fp, lr, [SP], #0x10
    // 0xa0b554: ret
    //     0xa0b554: ret             
    // 0xa0b558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0b558: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0b55c: b               #0xa0b4e0
  }
  _ readInt32(/* No info */) {
    // ** addr: 0xa0b56c, size: 0x180
    // 0xa0b56c: EnterFrame
    //     0xa0b56c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b570: mov             fp, SP
    // 0xa0b574: AllocStack(0x18)
    //     0xa0b574: sub             SP, SP, #0x18
    // 0xa0b578: CheckStackOverflow
    //     0xa0b578: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0b57c: cmp             SP, x16
    //     0xa0b580: b.ls            #0xa0b6d8
    // 0xa0b584: ldr             x0, [fp, #0x18]
    // 0xa0b588: LoadField: r1 = r0->field_97
    //     0xa0b588: ldur            w1, [x0, #0x97]
    // 0xa0b58c: DecompressPointer r1
    //     0xa0b58c: add             x1, x1, HEAP, lsl #32
    // 0xa0b590: r16 = Sentinel
    //     0xa0b590: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0b594: cmp             w1, w16
    // 0xa0b598: b.eq            #0xa0b6e0
    // 0xa0b59c: LoadField: r2 = r0->field_9b
    //     0xa0b59c: ldur            x2, [x0, #0x9b]
    // 0xa0b5a0: tbnz            x2, #0x3f, #0xa0b670
    // 0xa0b5a4: add             x3, x2, #3
    // 0xa0b5a8: LoadField: r4 = r1->field_13
    //     0xa0b5a8: ldur            w4, [x1, #0x13]
    // 0xa0b5ac: DecompressPointer r4
    //     0xa0b5ac: add             x4, x4, HEAP, lsl #32
    // 0xa0b5b0: r5 = LoadInt32Instr(r4)
    //     0xa0b5b0: sbfx            x5, x4, #1, #0x1f
    // 0xa0b5b4: cmp             x3, x5
    // 0xa0b5b8: b.ge            #0xa0b670
    // 0xa0b5bc: ldr             x3, [fp, #0x10]
    // 0xa0b5c0: LoadField: r4 = r1->field_17
    //     0xa0b5c0: ldur            w4, [x1, #0x17]
    // 0xa0b5c4: DecompressPointer r4
    //     0xa0b5c4: add             x4, x4, HEAP, lsl #32
    // 0xa0b5c8: LoadField: r5 = r1->field_1b
    //     0xa0b5c8: ldur            w5, [x1, #0x1b]
    // 0xa0b5cc: DecompressPointer r5
    //     0xa0b5cc: add             x5, x5, HEAP, lsl #32
    // 0xa0b5d0: r1 = LoadInt32Instr(r5)
    //     0xa0b5d0: sbfx            x1, x5, #1, #0x1f
    // 0xa0b5d4: add             x5, x1, x2
    // 0xa0b5d8: LoadField: r1 = r4->field_7
    //     0xa0b5d8: ldur            x1, [x4, #7]
    // 0xa0b5dc: ldrsw           x4, [x1, x5]
    // 0xa0b5e0: r16 = Instance_Endian
    //     0xa0b5e0: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xa0b5e4: cmp             w3, w16
    // 0xa0b5e8: b.ne            #0xa0b5f8
    // 0xa0b5ec: mov             x1, x4
    // 0xa0b5f0: sxtw            x1, w1
    // 0xa0b5f4: b               #0xa0b658
    // 0xa0b5f8: r8 = 4278255360
    //     0xa0b5f8: mov             x8, #0xff00
    //     0xa0b5fc: movk            x8, #0xff00, lsl #16
    // 0xa0b600: r7 = 16711935
    //     0xa0b600: mov             x7, #0xff
    //     0xa0b604: movk            x7, #0xff, lsl #16
    // 0xa0b608: r6 = 4294901760
    //     0xa0b608: mov             x6, #0xffff0000
    // 0xa0b60c: r5 = 65535
    //     0xa0b60c: mov             x5, #0xffff
    // 0xa0b610: r3 = 2147483647
    //     0xa0b610: mov             x3, #0x7fffffff
    // 0xa0b614: r1 = 2147483648
    //     0xa0b614: mov             x1, #0x80000000
    // 0xa0b618: mov             x9, x4
    // 0xa0b61c: and             x10, x9, x8
    // 0xa0b620: lsr             w8, w10, #8
    // 0xa0b624: and             x9, x4, x7
    // 0xa0b628: lsl             w4, w9, #8
    // 0xa0b62c: orr             x7, x8, x4
    // 0xa0b630: and             x4, x7, x6
    // 0xa0b634: lsr             w6, w4, #0x10
    // 0xa0b638: and             x4, x7, x5
    // 0xa0b63c: lsl             w5, w4, #0x10
    // 0xa0b640: orr             x4, x6, x5
    // 0xa0b644: and             x5, x4, x3
    // 0xa0b648: and             x3, x4, x1
    // 0xa0b64c: ubfx            x5, x5, #0, #0x20
    // 0xa0b650: ubfx            x3, x3, #0, #0x20
    // 0xa0b654: sub             x1, x5, x3
    // 0xa0b658: add             x3, x2, #4
    // 0xa0b65c: StoreField: r0->field_9b = r3
    //     0xa0b65c: stur            x3, [x0, #0x9b]
    // 0xa0b660: mov             x0, x1
    // 0xa0b664: LeaveFrame
    //     0xa0b664: mov             SP, fp
    //     0xa0b668: ldp             fp, lr, [SP], #0x10
    // 0xa0b66c: ret
    //     0xa0b66c: ret             
    // 0xa0b670: LoadField: r0 = r1->field_13
    //     0xa0b670: ldur            w0, [x1, #0x13]
    // 0xa0b674: DecompressPointer r0
    //     0xa0b674: add             x0, x0, HEAP, lsl #32
    // 0xa0b678: r1 = LoadInt32Instr(r0)
    //     0xa0b678: sbfx            x1, x0, #1, #0x1f
    // 0xa0b67c: sub             x3, x1, #4
    // 0xa0b680: r0 = BoxInt64Instr(r2)
    //     0xa0b680: sbfiz           x0, x2, #1, #0x1f
    //     0xa0b684: cmp             x2, x0, asr #1
    //     0xa0b688: b.eq            #0xa0b694
    //     0xa0b68c: bl              #0xd69bb8
    //     0xa0b690: stur            x2, [x0, #7]
    // 0xa0b694: stur            x0, [fp, #-0x10]
    // 0xa0b698: lsl             x1, x3, #1
    // 0xa0b69c: stur            x1, [fp, #-8]
    // 0xa0b6a0: r0 = RangeError()
    //     0xa0b6a0: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa0b6a4: stur            x0, [fp, #-0x18]
    // 0xa0b6a8: ldur            x16, [fp, #-0x10]
    // 0xa0b6ac: stp             x16, x0, [SP, #-0x10]!
    // 0xa0b6b0: ldur            x16, [fp, #-8]
    // 0xa0b6b4: stp             x16, xzr, [SP, #-0x10]!
    // 0xa0b6b8: r16 = "byteOffset"
    //     0xa0b6b8: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa0b6bc: SaveReg r16
    //     0xa0b6bc: str             x16, [SP, #-8]!
    // 0xa0b6c0: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa0b6c0: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa0b6c4: r0 = RangeError.range()
    //     0xa0b6c4: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa0b6c8: add             SP, SP, #0x28
    // 0xa0b6cc: ldur            x0, [fp, #-0x18]
    // 0xa0b6d0: r0 = Throw()
    //     0xa0b6d0: bl              #0xd67e38  ; ThrowStub
    // 0xa0b6d4: brk             #0
    // 0xa0b6d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0b6d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0b6dc: b               #0xa0b584
    // 0xa0b6e0: r9 = _view
    //     0xa0b6e0: add             x9, PP, #8, lsl #12  ; [pp+0x81e8] Field <DBusReadBuffer._view@326485801>: late (offset: 0x98)
    //     0xa0b6e4: ldr             x9, [x9, #0x1e8]
    // 0xa0b6e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa0b6e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ readDBusUint16(/* No info */) {
    // ** addr: 0xa0b6ec, size: 0x9c
    // 0xa0b6ec: EnterFrame
    //     0xa0b6ec: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b6f0: mov             fp, SP
    // 0xa0b6f4: AllocStack(0x8)
    //     0xa0b6f4: sub             SP, SP, #8
    // 0xa0b6f8: r0 = 2
    //     0xa0b6f8: mov             x0, #2
    // 0xa0b6fc: CheckStackOverflow
    //     0xa0b6fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0b700: cmp             SP, x16
    //     0xa0b704: b.ls            #0xa0b780
    // 0xa0b708: ldr             x16, [fp, #0x18]
    // 0xa0b70c: stp             x0, x16, [SP, #-0x10]!
    // 0xa0b710: r0 = align()
    //     0xa0b710: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa0b714: add             SP, SP, #0x10
    // 0xa0b718: tbnz            w0, #4, #0xa0b744
    // 0xa0b71c: ldr             x0, [fp, #0x18]
    // 0xa0b720: LoadField: r1 = r0->field_8f
    //     0xa0b720: ldur            w1, [x0, #0x8f]
    // 0xa0b724: DecompressPointer r1
    //     0xa0b724: add             x1, x1, HEAP, lsl #32
    // 0xa0b728: LoadField: r2 = r1->field_13
    //     0xa0b728: ldur            w2, [x1, #0x13]
    // 0xa0b72c: DecompressPointer r2
    //     0xa0b72c: add             x2, x2, HEAP, lsl #32
    // 0xa0b730: LoadField: r1 = r0->field_9b
    //     0xa0b730: ldur            x1, [x0, #0x9b]
    // 0xa0b734: r3 = LoadInt32Instr(r2)
    //     0xa0b734: sbfx            x3, x2, #1, #0x1f
    // 0xa0b738: sub             x2, x3, x1
    // 0xa0b73c: cmp             x2, #2
    // 0xa0b740: b.ge            #0xa0b754
    // 0xa0b744: r0 = Null
    //     0xa0b744: mov             x0, NULL
    // 0xa0b748: LeaveFrame
    //     0xa0b748: mov             SP, fp
    //     0xa0b74c: ldp             fp, lr, [SP], #0x10
    // 0xa0b750: ret
    //     0xa0b750: ret             
    // 0xa0b754: ldr             x16, [fp, #0x10]
    // 0xa0b758: stp             x16, x0, [SP, #-0x10]!
    // 0xa0b75c: r0 = readUint16()
    //     0xa0b75c: bl              #0xa0b794  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readUint16
    // 0xa0b760: add             SP, SP, #0x10
    // 0xa0b764: stur            x0, [fp, #-8]
    // 0xa0b768: r0 = DBusUint16()
    //     0xa0b768: bl              #0xa0b788  ; AllocateDBusUint16Stub -> DBusUint16 (size=0x10)
    // 0xa0b76c: ldur            x1, [fp, #-8]
    // 0xa0b770: StoreField: r0->field_7 = r1
    //     0xa0b770: stur            x1, [x0, #7]
    // 0xa0b774: LeaveFrame
    //     0xa0b774: mov             SP, fp
    //     0xa0b778: ldp             fp, lr, [SP], #0x10
    // 0xa0b77c: ret
    //     0xa0b77c: ret             
    // 0xa0b780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0b780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0b784: b               #0xa0b708
  }
  _ readUint16(/* No info */) {
    // ** addr: 0xa0b794, size: 0x150
    // 0xa0b794: EnterFrame
    //     0xa0b794: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b798: mov             fp, SP
    // 0xa0b79c: AllocStack(0x18)
    //     0xa0b79c: sub             SP, SP, #0x18
    // 0xa0b7a0: CheckStackOverflow
    //     0xa0b7a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0b7a4: cmp             SP, x16
    //     0xa0b7a8: b.ls            #0xa0b8d0
    // 0xa0b7ac: ldr             x0, [fp, #0x18]
    // 0xa0b7b0: LoadField: r1 = r0->field_97
    //     0xa0b7b0: ldur            w1, [x0, #0x97]
    // 0xa0b7b4: DecompressPointer r1
    //     0xa0b7b4: add             x1, x1, HEAP, lsl #32
    // 0xa0b7b8: r16 = Sentinel
    //     0xa0b7b8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0b7bc: cmp             w1, w16
    // 0xa0b7c0: b.eq            #0xa0b8d8
    // 0xa0b7c4: LoadField: r2 = r0->field_9b
    //     0xa0b7c4: ldur            x2, [x0, #0x9b]
    // 0xa0b7c8: tbnz            x2, #0x3f, #0xa0b868
    // 0xa0b7cc: add             x3, x2, #1
    // 0xa0b7d0: LoadField: r4 = r1->field_13
    //     0xa0b7d0: ldur            w4, [x1, #0x13]
    // 0xa0b7d4: DecompressPointer r4
    //     0xa0b7d4: add             x4, x4, HEAP, lsl #32
    // 0xa0b7d8: r5 = LoadInt32Instr(r4)
    //     0xa0b7d8: sbfx            x5, x4, #1, #0x1f
    // 0xa0b7dc: cmp             x3, x5
    // 0xa0b7e0: b.ge            #0xa0b868
    // 0xa0b7e4: ldr             x3, [fp, #0x10]
    // 0xa0b7e8: LoadField: r4 = r1->field_17
    //     0xa0b7e8: ldur            w4, [x1, #0x17]
    // 0xa0b7ec: DecompressPointer r4
    //     0xa0b7ec: add             x4, x4, HEAP, lsl #32
    // 0xa0b7f0: LoadField: r5 = r1->field_1b
    //     0xa0b7f0: ldur            w5, [x1, #0x1b]
    // 0xa0b7f4: DecompressPointer r5
    //     0xa0b7f4: add             x5, x5, HEAP, lsl #32
    // 0xa0b7f8: r1 = LoadInt32Instr(r5)
    //     0xa0b7f8: sbfx            x1, x5, #1, #0x1f
    // 0xa0b7fc: add             x5, x1, x2
    // 0xa0b800: LoadField: r1 = r4->field_7
    //     0xa0b800: ldur            x1, [x4, #7]
    // 0xa0b804: ldrh            w4, [x1, x5]
    // 0xa0b808: r16 = Instance_Endian
    //     0xa0b808: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xa0b80c: cmp             w3, w16
    // 0xa0b810: b.ne            #0xa0b81c
    // 0xa0b814: mov             x1, x4
    // 0xa0b818: b               #0xa0b850
    // 0xa0b81c: r3 = 65280
    //     0xa0b81c: mov             x3, #0xff00
    // 0xa0b820: r1 = 255
    //     0xa0b820: mov             x1, #0xff
    // 0xa0b824: mov             x5, x4
    // 0xa0b828: ubfx            x5, x5, #0, #0x20
    // 0xa0b82c: and             x6, x5, x3
    // 0xa0b830: ubfx            x6, x6, #0, #0x20
    // 0xa0b834: asr             x3, x6, #8
    // 0xa0b838: ubfx            x4, x4, #0, #0x20
    // 0xa0b83c: and             x5, x4, x1
    // 0xa0b840: ubfx            x5, x5, #0, #0x20
    // 0xa0b844: lsl             x1, x5, #8
    // 0xa0b848: orr             x4, x3, x1
    // 0xa0b84c: mov             x1, x4
    // 0xa0b850: add             x3, x2, #2
    // 0xa0b854: StoreField: r0->field_9b = r3
    //     0xa0b854: stur            x3, [x0, #0x9b]
    // 0xa0b858: mov             x0, x1
    // 0xa0b85c: LeaveFrame
    //     0xa0b85c: mov             SP, fp
    //     0xa0b860: ldp             fp, lr, [SP], #0x10
    // 0xa0b864: ret
    //     0xa0b864: ret             
    // 0xa0b868: LoadField: r0 = r1->field_13
    //     0xa0b868: ldur            w0, [x1, #0x13]
    // 0xa0b86c: DecompressPointer r0
    //     0xa0b86c: add             x0, x0, HEAP, lsl #32
    // 0xa0b870: r1 = LoadInt32Instr(r0)
    //     0xa0b870: sbfx            x1, x0, #1, #0x1f
    // 0xa0b874: sub             x3, x1, #2
    // 0xa0b878: r0 = BoxInt64Instr(r2)
    //     0xa0b878: sbfiz           x0, x2, #1, #0x1f
    //     0xa0b87c: cmp             x2, x0, asr #1
    //     0xa0b880: b.eq            #0xa0b88c
    //     0xa0b884: bl              #0xd69bb8
    //     0xa0b888: stur            x2, [x0, #7]
    // 0xa0b88c: stur            x0, [fp, #-0x10]
    // 0xa0b890: lsl             x1, x3, #1
    // 0xa0b894: stur            x1, [fp, #-8]
    // 0xa0b898: r0 = RangeError()
    //     0xa0b898: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa0b89c: stur            x0, [fp, #-0x18]
    // 0xa0b8a0: ldur            x16, [fp, #-0x10]
    // 0xa0b8a4: stp             x16, x0, [SP, #-0x10]!
    // 0xa0b8a8: ldur            x16, [fp, #-8]
    // 0xa0b8ac: stp             x16, xzr, [SP, #-0x10]!
    // 0xa0b8b0: r16 = "byteOffset"
    //     0xa0b8b0: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa0b8b4: SaveReg r16
    //     0xa0b8b4: str             x16, [SP, #-8]!
    // 0xa0b8b8: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa0b8b8: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa0b8bc: r0 = RangeError.range()
    //     0xa0b8bc: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa0b8c0: add             SP, SP, #0x28
    // 0xa0b8c4: ldur            x0, [fp, #-0x18]
    // 0xa0b8c8: r0 = Throw()
    //     0xa0b8c8: bl              #0xd67e38  ; ThrowStub
    // 0xa0b8cc: brk             #0
    // 0xa0b8d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0b8d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0b8d4: b               #0xa0b7ac
    // 0xa0b8d8: r9 = _view
    //     0xa0b8d8: add             x9, PP, #8, lsl #12  ; [pp+0x81e8] Field <DBusReadBuffer._view@326485801>: late (offset: 0x98)
    //     0xa0b8dc: ldr             x9, [x9, #0x1e8]
    // 0xa0b8e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa0b8e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ readDBusInt16(/* No info */) {
    // ** addr: 0xa0b8e4, size: 0x9c
    // 0xa0b8e4: EnterFrame
    //     0xa0b8e4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b8e8: mov             fp, SP
    // 0xa0b8ec: AllocStack(0x8)
    //     0xa0b8ec: sub             SP, SP, #8
    // 0xa0b8f0: r0 = 2
    //     0xa0b8f0: mov             x0, #2
    // 0xa0b8f4: CheckStackOverflow
    //     0xa0b8f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0b8f8: cmp             SP, x16
    //     0xa0b8fc: b.ls            #0xa0b978
    // 0xa0b900: ldr             x16, [fp, #0x18]
    // 0xa0b904: stp             x0, x16, [SP, #-0x10]!
    // 0xa0b908: r0 = align()
    //     0xa0b908: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa0b90c: add             SP, SP, #0x10
    // 0xa0b910: tbnz            w0, #4, #0xa0b93c
    // 0xa0b914: ldr             x0, [fp, #0x18]
    // 0xa0b918: LoadField: r1 = r0->field_8f
    //     0xa0b918: ldur            w1, [x0, #0x8f]
    // 0xa0b91c: DecompressPointer r1
    //     0xa0b91c: add             x1, x1, HEAP, lsl #32
    // 0xa0b920: LoadField: r2 = r1->field_13
    //     0xa0b920: ldur            w2, [x1, #0x13]
    // 0xa0b924: DecompressPointer r2
    //     0xa0b924: add             x2, x2, HEAP, lsl #32
    // 0xa0b928: LoadField: r1 = r0->field_9b
    //     0xa0b928: ldur            x1, [x0, #0x9b]
    // 0xa0b92c: r3 = LoadInt32Instr(r2)
    //     0xa0b92c: sbfx            x3, x2, #1, #0x1f
    // 0xa0b930: sub             x2, x3, x1
    // 0xa0b934: cmp             x2, #2
    // 0xa0b938: b.ge            #0xa0b94c
    // 0xa0b93c: r0 = Null
    //     0xa0b93c: mov             x0, NULL
    // 0xa0b940: LeaveFrame
    //     0xa0b940: mov             SP, fp
    //     0xa0b944: ldp             fp, lr, [SP], #0x10
    // 0xa0b948: ret
    //     0xa0b948: ret             
    // 0xa0b94c: ldr             x16, [fp, #0x10]
    // 0xa0b950: stp             x16, x0, [SP, #-0x10]!
    // 0xa0b954: r0 = readInt16()
    //     0xa0b954: bl              #0xa0b98c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readInt16
    // 0xa0b958: add             SP, SP, #0x10
    // 0xa0b95c: stur            x0, [fp, #-8]
    // 0xa0b960: r0 = DBusInt16()
    //     0xa0b960: bl              #0xa0b980  ; AllocateDBusInt16Stub -> DBusInt16 (size=0x10)
    // 0xa0b964: ldur            x1, [fp, #-8]
    // 0xa0b968: StoreField: r0->field_7 = r1
    //     0xa0b968: stur            x1, [x0, #7]
    // 0xa0b96c: LeaveFrame
    //     0xa0b96c: mov             SP, fp
    //     0xa0b970: ldp             fp, lr, [SP], #0x10
    // 0xa0b974: ret
    //     0xa0b974: ret             
    // 0xa0b978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0b978: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0b97c: b               #0xa0b900
  }
  _ readInt16(/* No info */) {
    // ** addr: 0xa0b98c, size: 0x160
    // 0xa0b98c: EnterFrame
    //     0xa0b98c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b990: mov             fp, SP
    // 0xa0b994: AllocStack(0x18)
    //     0xa0b994: sub             SP, SP, #0x18
    // 0xa0b998: CheckStackOverflow
    //     0xa0b998: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0b99c: cmp             SP, x16
    //     0xa0b9a0: b.ls            #0xa0bad8
    // 0xa0b9a4: ldr             x0, [fp, #0x18]
    // 0xa0b9a8: LoadField: r1 = r0->field_97
    //     0xa0b9a8: ldur            w1, [x0, #0x97]
    // 0xa0b9ac: DecompressPointer r1
    //     0xa0b9ac: add             x1, x1, HEAP, lsl #32
    // 0xa0b9b0: r16 = Sentinel
    //     0xa0b9b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0b9b4: cmp             w1, w16
    // 0xa0b9b8: b.eq            #0xa0bae0
    // 0xa0b9bc: LoadField: r2 = r0->field_9b
    //     0xa0b9bc: ldur            x2, [x0, #0x9b]
    // 0xa0b9c0: tbnz            x2, #0x3f, #0xa0ba70
    // 0xa0b9c4: add             x3, x2, #1
    // 0xa0b9c8: LoadField: r4 = r1->field_13
    //     0xa0b9c8: ldur            w4, [x1, #0x13]
    // 0xa0b9cc: DecompressPointer r4
    //     0xa0b9cc: add             x4, x4, HEAP, lsl #32
    // 0xa0b9d0: r5 = LoadInt32Instr(r4)
    //     0xa0b9d0: sbfx            x5, x4, #1, #0x1f
    // 0xa0b9d4: cmp             x3, x5
    // 0xa0b9d8: b.ge            #0xa0ba70
    // 0xa0b9dc: ldr             x3, [fp, #0x10]
    // 0xa0b9e0: LoadField: r4 = r1->field_17
    //     0xa0b9e0: ldur            w4, [x1, #0x17]
    // 0xa0b9e4: DecompressPointer r4
    //     0xa0b9e4: add             x4, x4, HEAP, lsl #32
    // 0xa0b9e8: LoadField: r5 = r1->field_1b
    //     0xa0b9e8: ldur            w5, [x1, #0x1b]
    // 0xa0b9ec: DecompressPointer r5
    //     0xa0b9ec: add             x5, x5, HEAP, lsl #32
    // 0xa0b9f0: r1 = LoadInt32Instr(r5)
    //     0xa0b9f0: sbfx            x1, x5, #1, #0x1f
    // 0xa0b9f4: add             x5, x1, x2
    // 0xa0b9f8: LoadField: r1 = r4->field_7
    //     0xa0b9f8: ldur            x1, [x4, #7]
    // 0xa0b9fc: ldrsh           x4, [x1, x5]
    // 0xa0ba00: r16 = Instance_Endian
    //     0xa0ba00: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xa0ba04: cmp             w3, w16
    // 0xa0ba08: b.ne            #0xa0ba14
    // 0xa0ba0c: mov             x1, x4
    // 0xa0ba10: b               #0xa0ba58
    // 0xa0ba14: r6 = 65280
    //     0xa0ba14: mov             x6, #0xff00
    // 0xa0ba18: r5 = 255
    //     0xa0ba18: mov             x5, #0xff
    // 0xa0ba1c: r3 = 32767
    //     0xa0ba1c: mov             x3, #0x7fff
    // 0xa0ba20: r1 = 32768
    //     0xa0ba20: mov             x1, #0x8000
    // 0xa0ba24: mov             x7, x4
    // 0xa0ba28: ubfx            x7, x7, #0, #0x20
    // 0xa0ba2c: and             x8, x7, x6
    // 0xa0ba30: lsr             w6, w8, #8
    // 0xa0ba34: ubfx            x4, x4, #0, #0x20
    // 0xa0ba38: and             x7, x4, x5
    // 0xa0ba3c: lsl             w4, w7, #8
    // 0xa0ba40: orr             x5, x6, x4
    // 0xa0ba44: and             x4, x5, x3
    // 0xa0ba48: and             x3, x5, x1
    // 0xa0ba4c: ubfx            x4, x4, #0, #0x20
    // 0xa0ba50: ubfx            x3, x3, #0, #0x20
    // 0xa0ba54: sub             x1, x4, x3
    // 0xa0ba58: add             x3, x2, #2
    // 0xa0ba5c: StoreField: r0->field_9b = r3
    //     0xa0ba5c: stur            x3, [x0, #0x9b]
    // 0xa0ba60: mov             x0, x1
    // 0xa0ba64: LeaveFrame
    //     0xa0ba64: mov             SP, fp
    //     0xa0ba68: ldp             fp, lr, [SP], #0x10
    // 0xa0ba6c: ret
    //     0xa0ba6c: ret             
    // 0xa0ba70: LoadField: r0 = r1->field_13
    //     0xa0ba70: ldur            w0, [x1, #0x13]
    // 0xa0ba74: DecompressPointer r0
    //     0xa0ba74: add             x0, x0, HEAP, lsl #32
    // 0xa0ba78: r1 = LoadInt32Instr(r0)
    //     0xa0ba78: sbfx            x1, x0, #1, #0x1f
    // 0xa0ba7c: sub             x3, x1, #2
    // 0xa0ba80: r0 = BoxInt64Instr(r2)
    //     0xa0ba80: sbfiz           x0, x2, #1, #0x1f
    //     0xa0ba84: cmp             x2, x0, asr #1
    //     0xa0ba88: b.eq            #0xa0ba94
    //     0xa0ba8c: bl              #0xd69bb8
    //     0xa0ba90: stur            x2, [x0, #7]
    // 0xa0ba94: stur            x0, [fp, #-0x10]
    // 0xa0ba98: lsl             x1, x3, #1
    // 0xa0ba9c: stur            x1, [fp, #-8]
    // 0xa0baa0: r0 = RangeError()
    //     0xa0baa0: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa0baa4: stur            x0, [fp, #-0x18]
    // 0xa0baa8: ldur            x16, [fp, #-0x10]
    // 0xa0baac: stp             x16, x0, [SP, #-0x10]!
    // 0xa0bab0: ldur            x16, [fp, #-8]
    // 0xa0bab4: stp             x16, xzr, [SP, #-0x10]!
    // 0xa0bab8: r16 = "byteOffset"
    //     0xa0bab8: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa0babc: SaveReg r16
    //     0xa0babc: str             x16, [SP, #-8]!
    // 0xa0bac0: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa0bac0: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa0bac4: r0 = RangeError.range()
    //     0xa0bac4: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa0bac8: add             SP, SP, #0x28
    // 0xa0bacc: ldur            x0, [fp, #-0x18]
    // 0xa0bad0: r0 = Throw()
    //     0xa0bad0: bl              #0xd67e38  ; ThrowStub
    // 0xa0bad4: brk             #0
    // 0xa0bad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0bad8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0badc: b               #0xa0b9a4
    // 0xa0bae0: r9 = _view
    //     0xa0bae0: add             x9, PP, #8, lsl #12  ; [pp+0x81e8] Field <DBusReadBuffer._view@326485801>: late (offset: 0x98)
    //     0xa0bae4: ldr             x9, [x9, #0x1e8]
    // 0xa0bae8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa0bae8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ readDBusBoolean(/* No info */) {
    // ** addr: 0xa0baec, size: 0xac
    // 0xa0baec: EnterFrame
    //     0xa0baec: stp             fp, lr, [SP, #-0x10]!
    //     0xa0baf0: mov             fp, SP
    // 0xa0baf4: AllocStack(0x8)
    //     0xa0baf4: sub             SP, SP, #8
    // 0xa0baf8: r0 = 4
    //     0xa0baf8: mov             x0, #4
    // 0xa0bafc: CheckStackOverflow
    //     0xa0bafc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0bb00: cmp             SP, x16
    //     0xa0bb04: b.ls            #0xa0bb90
    // 0xa0bb08: ldr             x16, [fp, #0x18]
    // 0xa0bb0c: stp             x0, x16, [SP, #-0x10]!
    // 0xa0bb10: r0 = align()
    //     0xa0bb10: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa0bb14: add             SP, SP, #0x10
    // 0xa0bb18: tbnz            w0, #4, #0xa0bb44
    // 0xa0bb1c: ldr             x0, [fp, #0x18]
    // 0xa0bb20: LoadField: r1 = r0->field_8f
    //     0xa0bb20: ldur            w1, [x0, #0x8f]
    // 0xa0bb24: DecompressPointer r1
    //     0xa0bb24: add             x1, x1, HEAP, lsl #32
    // 0xa0bb28: LoadField: r2 = r1->field_13
    //     0xa0bb28: ldur            w2, [x1, #0x13]
    // 0xa0bb2c: DecompressPointer r2
    //     0xa0bb2c: add             x2, x2, HEAP, lsl #32
    // 0xa0bb30: LoadField: r1 = r0->field_9b
    //     0xa0bb30: ldur            x1, [x0, #0x9b]
    // 0xa0bb34: r3 = LoadInt32Instr(r2)
    //     0xa0bb34: sbfx            x3, x2, #1, #0x1f
    // 0xa0bb38: sub             x2, x3, x1
    // 0xa0bb3c: cmp             x2, #4
    // 0xa0bb40: b.ge            #0xa0bb54
    // 0xa0bb44: r0 = Null
    //     0xa0bb44: mov             x0, NULL
    // 0xa0bb48: LeaveFrame
    //     0xa0bb48: mov             SP, fp
    //     0xa0bb4c: ldp             fp, lr, [SP], #0x10
    // 0xa0bb50: ret
    //     0xa0bb50: ret             
    // 0xa0bb54: ldr             x16, [fp, #0x10]
    // 0xa0bb58: stp             x16, x0, [SP, #-0x10]!
    // 0xa0bb5c: r0 = readUint32()
    //     0xa0bb5c: bl              #0xa0bba4  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readUint32
    // 0xa0bb60: add             SP, SP, #0x10
    // 0xa0bb64: cbnz            x0, #0xa0bb70
    // 0xa0bb68: r1 = false
    //     0xa0bb68: add             x1, NULL, #0x30  ; false
    // 0xa0bb6c: b               #0xa0bb74
    // 0xa0bb70: r1 = true
    //     0xa0bb70: add             x1, NULL, #0x20  ; true
    // 0xa0bb74: stur            x1, [fp, #-8]
    // 0xa0bb78: r0 = DBusBoolean()
    //     0xa0bb78: bl              #0xa0bb98  ; AllocateDBusBooleanStub -> DBusBoolean (size=0xc)
    // 0xa0bb7c: ldur            x1, [fp, #-8]
    // 0xa0bb80: StoreField: r0->field_7 = r1
    //     0xa0bb80: stur            w1, [x0, #7]
    // 0xa0bb84: LeaveFrame
    //     0xa0bb84: mov             SP, fp
    //     0xa0bb88: ldp             fp, lr, [SP], #0x10
    // 0xa0bb8c: ret
    //     0xa0bb8c: ret             
    // 0xa0bb90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0bb90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0bb94: b               #0xa0bb08
  }
  _ readUint32(/* No info */) {
    // ** addr: 0xa0bba4, size: 0x180
    // 0xa0bba4: EnterFrame
    //     0xa0bba4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0bba8: mov             fp, SP
    // 0xa0bbac: AllocStack(0x18)
    //     0xa0bbac: sub             SP, SP, #0x18
    // 0xa0bbb0: CheckStackOverflow
    //     0xa0bbb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0bbb4: cmp             SP, x16
    //     0xa0bbb8: b.ls            #0xa0bd10
    // 0xa0bbbc: ldr             x0, [fp, #0x18]
    // 0xa0bbc0: LoadField: r1 = r0->field_97
    //     0xa0bbc0: ldur            w1, [x0, #0x97]
    // 0xa0bbc4: DecompressPointer r1
    //     0xa0bbc4: add             x1, x1, HEAP, lsl #32
    // 0xa0bbc8: r16 = Sentinel
    //     0xa0bbc8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0bbcc: cmp             w1, w16
    // 0xa0bbd0: b.eq            #0xa0bd18
    // 0xa0bbd4: LoadField: r2 = r0->field_9b
    //     0xa0bbd4: ldur            x2, [x0, #0x9b]
    // 0xa0bbd8: tbnz            x2, #0x3f, #0xa0bca8
    // 0xa0bbdc: add             x3, x2, #3
    // 0xa0bbe0: LoadField: r4 = r1->field_13
    //     0xa0bbe0: ldur            w4, [x1, #0x13]
    // 0xa0bbe4: DecompressPointer r4
    //     0xa0bbe4: add             x4, x4, HEAP, lsl #32
    // 0xa0bbe8: r5 = LoadInt32Instr(r4)
    //     0xa0bbe8: sbfx            x5, x4, #1, #0x1f
    // 0xa0bbec: cmp             x3, x5
    // 0xa0bbf0: b.ge            #0xa0bca8
    // 0xa0bbf4: ldr             x3, [fp, #0x10]
    // 0xa0bbf8: LoadField: r4 = r1->field_17
    //     0xa0bbf8: ldur            w4, [x1, #0x17]
    // 0xa0bbfc: DecompressPointer r4
    //     0xa0bbfc: add             x4, x4, HEAP, lsl #32
    // 0xa0bc00: LoadField: r5 = r1->field_1b
    //     0xa0bc00: ldur            w5, [x1, #0x1b]
    // 0xa0bc04: DecompressPointer r5
    //     0xa0bc04: add             x5, x5, HEAP, lsl #32
    // 0xa0bc08: r1 = LoadInt32Instr(r5)
    //     0xa0bc08: sbfx            x1, x5, #1, #0x1f
    // 0xa0bc0c: add             x5, x1, x2
    // 0xa0bc10: LoadField: r1 = r4->field_7
    //     0xa0bc10: ldur            x1, [x4, #7]
    // 0xa0bc14: ldr             w4, [x1, x5]
    // 0xa0bc18: r16 = Instance_Endian
    //     0xa0bc18: ldr             x16, [PP, #0x7f70]  ; [pp+0x7f70] Obj!Endian@b5f5c1
    // 0xa0bc1c: cmp             w3, w16
    // 0xa0bc20: b.ne            #0xa0bc30
    // 0xa0bc24: mov             x1, x4
    // 0xa0bc28: ubfx            x1, x1, #0, #0x20
    // 0xa0bc2c: b               #0xa0bc90
    // 0xa0bc30: r6 = 4278255360
    //     0xa0bc30: mov             x6, #0xff00
    //     0xa0bc34: movk            x6, #0xff00, lsl #16
    // 0xa0bc38: r5 = 16711935
    //     0xa0bc38: mov             x5, #0xff
    //     0xa0bc3c: movk            x5, #0xff, lsl #16
    // 0xa0bc40: r3 = 4294901760
    //     0xa0bc40: mov             x3, #0xffff0000
    // 0xa0bc44: r1 = 65535
    //     0xa0bc44: mov             x1, #0xffff
    // 0xa0bc48: and             x7, x4, x6
    // 0xa0bc4c: ubfx            x7, x7, #0, #0x20
    // 0xa0bc50: asr             x6, x7, #8
    // 0xa0bc54: and             x7, x4, x5
    // 0xa0bc58: ubfx            x7, x7, #0, #0x20
    // 0xa0bc5c: lsl             x4, x7, #8
    // 0xa0bc60: orr             x5, x6, x4
    // 0xa0bc64: mov             x4, x5
    // 0xa0bc68: ubfx            x4, x4, #0, #0x20
    // 0xa0bc6c: and             x6, x4, x3
    // 0xa0bc70: ubfx            x6, x6, #0, #0x20
    // 0xa0bc74: asr             x3, x6, #0x10
    // 0xa0bc78: ubfx            x5, x5, #0, #0x20
    // 0xa0bc7c: and             x4, x5, x1
    // 0xa0bc80: ubfx            x4, x4, #0, #0x20
    // 0xa0bc84: lsl             x1, x4, #0x10
    // 0xa0bc88: orr             x4, x3, x1
    // 0xa0bc8c: mov             x1, x4
    // 0xa0bc90: add             x3, x2, #4
    // 0xa0bc94: StoreField: r0->field_9b = r3
    //     0xa0bc94: stur            x3, [x0, #0x9b]
    // 0xa0bc98: mov             x0, x1
    // 0xa0bc9c: LeaveFrame
    //     0xa0bc9c: mov             SP, fp
    //     0xa0bca0: ldp             fp, lr, [SP], #0x10
    // 0xa0bca4: ret
    //     0xa0bca4: ret             
    // 0xa0bca8: LoadField: r0 = r1->field_13
    //     0xa0bca8: ldur            w0, [x1, #0x13]
    // 0xa0bcac: DecompressPointer r0
    //     0xa0bcac: add             x0, x0, HEAP, lsl #32
    // 0xa0bcb0: r1 = LoadInt32Instr(r0)
    //     0xa0bcb0: sbfx            x1, x0, #1, #0x1f
    // 0xa0bcb4: sub             x3, x1, #4
    // 0xa0bcb8: r0 = BoxInt64Instr(r2)
    //     0xa0bcb8: sbfiz           x0, x2, #1, #0x1f
    //     0xa0bcbc: cmp             x2, x0, asr #1
    //     0xa0bcc0: b.eq            #0xa0bccc
    //     0xa0bcc4: bl              #0xd69bb8
    //     0xa0bcc8: stur            x2, [x0, #7]
    // 0xa0bccc: stur            x0, [fp, #-0x10]
    // 0xa0bcd0: lsl             x1, x3, #1
    // 0xa0bcd4: stur            x1, [fp, #-8]
    // 0xa0bcd8: r0 = RangeError()
    //     0xa0bcd8: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa0bcdc: stur            x0, [fp, #-0x18]
    // 0xa0bce0: ldur            x16, [fp, #-0x10]
    // 0xa0bce4: stp             x16, x0, [SP, #-0x10]!
    // 0xa0bce8: ldur            x16, [fp, #-8]
    // 0xa0bcec: stp             x16, xzr, [SP, #-0x10]!
    // 0xa0bcf0: r16 = "byteOffset"
    //     0xa0bcf0: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa0bcf4: SaveReg r16
    //     0xa0bcf4: str             x16, [SP, #-8]!
    // 0xa0bcf8: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa0bcf8: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa0bcfc: r0 = RangeError.range()
    //     0xa0bcfc: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa0bd00: add             SP, SP, #0x28
    // 0xa0bd04: ldur            x0, [fp, #-0x18]
    // 0xa0bd08: r0 = Throw()
    //     0xa0bd08: bl              #0xd67e38  ; ThrowStub
    // 0xa0bd0c: brk             #0
    // 0xa0bd10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0bd10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0bd14: b               #0xa0bbbc
    // 0xa0bd18: r9 = _view
    //     0xa0bd18: add             x9, PP, #8, lsl #12  ; [pp+0x81e8] Field <DBusReadBuffer._view@326485801>: late (offset: 0x98)
    //     0xa0bd1c: ldr             x9, [x9, #0x1e8]
    // 0xa0bd20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa0bd20: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ align(/* No info */) {
    // ** addr: 0xa0bd24, size: 0xb8
    // 0xa0bd24: EnterFrame
    //     0xa0bd24: stp             fp, lr, [SP, #-0x10]!
    //     0xa0bd28: mov             fp, SP
    // 0xa0bd2c: ldr             x1, [fp, #0x18]
    // 0xa0bd30: LoadField: r2 = r1->field_8f
    //     0xa0bd30: ldur            w2, [x1, #0x8f]
    // 0xa0bd34: DecompressPointer r2
    //     0xa0bd34: add             x2, x2, HEAP, lsl #32
    // 0xa0bd38: LoadField: r3 = r2->field_13
    //     0xa0bd38: ldur            w3, [x2, #0x13]
    // 0xa0bd3c: DecompressPointer r3
    //     0xa0bd3c: add             x3, x3, HEAP, lsl #32
    // 0xa0bd40: r2 = LoadInt32Instr(r3)
    //     0xa0bd40: sbfx            x2, x3, #1, #0x1f
    // 0xa0bd44: ldr             x3, [fp, #0x10]
    // 0xa0bd48: CheckStackOverflow
    //     0xa0bd48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0bd4c: cmp             SP, x16
    //     0xa0bd50: b.ls            #0xa0bda4
    // 0xa0bd54: LoadField: r4 = r1->field_9b
    //     0xa0bd54: ldur            x4, [x1, #0x9b]
    // 0xa0bd58: cbz             x3, #0xa0bdac
    // 0xa0bd5c: sdiv            x6, x4, x3
    // 0xa0bd60: msub            x5, x6, x3, x4
    // 0xa0bd64: cmp             x5, xzr
    // 0xa0bd68: b.lt            #0xa0bdc8
    // 0xa0bd6c: cbz             x5, #0xa0bd94
    // 0xa0bd70: sub             x5, x2, x4
    // 0xa0bd74: cbnz            x5, #0xa0bd88
    // 0xa0bd78: r0 = false
    //     0xa0bd78: add             x0, NULL, #0x30  ; false
    // 0xa0bd7c: LeaveFrame
    //     0xa0bd7c: mov             SP, fp
    //     0xa0bd80: ldp             fp, lr, [SP], #0x10
    // 0xa0bd84: ret
    //     0xa0bd84: ret             
    // 0xa0bd88: add             x5, x4, #1
    // 0xa0bd8c: StoreField: r1->field_9b = r5
    //     0xa0bd8c: stur            x5, [x1, #0x9b]
    // 0xa0bd90: b               #0xa0bd48
    // 0xa0bd94: r0 = true
    //     0xa0bd94: add             x0, NULL, #0x20  ; true
    // 0xa0bd98: LeaveFrame
    //     0xa0bd98: mov             SP, fp
    //     0xa0bd9c: ldp             fp, lr, [SP], #0x10
    // 0xa0bda0: ret
    //     0xa0bda0: ret             
    // 0xa0bda4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0bda4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0bda8: b               #0xa0bd54
    // 0xa0bdac: stp             x3, x4, [SP, #-0x10]!
    // 0xa0bdb0: stp             x1, x2, [SP, #-0x10]!
    // 0xa0bdb4: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0xa0bdb8: r4 = 0
    //     0xa0bdb8: mov             x4, #0
    // 0xa0bdbc: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xa0bdc0: blr             lr
    // 0xa0bdc4: brk             #0
    // 0xa0bdc8: cmp             x3, xzr
    // 0xa0bdcc: sub             x6, x5, x3
    // 0xa0bdd0: add             x5, x5, x3
    // 0xa0bdd4: csel            x5, x6, x5, lt
    // 0xa0bdd8: b               #0xa0bd6c
  }
  _ readDBusArray(/* No info */) {
    // ** addr: 0xa0bddc, size: 0x224
    // 0xa0bddc: EnterFrame
    //     0xa0bddc: stp             fp, lr, [SP, #-0x10]!
    //     0xa0bde0: mov             fp, SP
    // 0xa0bde4: AllocStack(0x40)
    //     0xa0bde4: sub             SP, SP, #0x40
    // 0xa0bde8: SetupParameters(DBusReadBuffer this /* r1, fp-0x20 */, dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */, [int _ = 0 /* r0, fp-0x8 */])
    //     0xa0bde8: mov             x0, x4
    //     0xa0bdec: ldur            w1, [x0, #0x13]
    //     0xa0bdf0: add             x1, x1, HEAP, lsl #32
    //     0xa0bdf4: sub             x0, x1, #6
    //     0xa0bdf8: add             x1, fp, w0, sxtw #2
    //     0xa0bdfc: ldr             x1, [x1, #0x20]
    //     0xa0be00: stur            x1, [fp, #-0x20]
    //     0xa0be04: add             x2, fp, w0, sxtw #2
    //     0xa0be08: ldr             x2, [x2, #0x18]
    //     0xa0be0c: stur            x2, [fp, #-0x18]
    //     0xa0be10: add             x3, fp, w0, sxtw #2
    //     0xa0be14: ldr             x3, [x3, #0x10]
    //     0xa0be18: stur            x3, [fp, #-0x10]
    //     0xa0be1c: cmp             w0, #2
    //     0xa0be20: b.lt            #0xa0be3c
    //     0xa0be24: add             x4, fp, w0, sxtw #2
    //     0xa0be28: ldr             x4, [x4, #8]
    //     0xa0be2c: sbfx            x0, x4, #1, #0x1f
    //     0xa0be30: tbz             w4, #0, #0xa0be38
    //     0xa0be34: ldur            x0, [x4, #7]
    //     0xa0be38: b               #0xa0be40
    //     0xa0be3c: mov             x0, #0
    //     0xa0be40: stur            x0, [fp, #-8]
    // 0xa0be44: CheckStackOverflow
    //     0xa0be44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0be48: cmp             SP, x16
    //     0xa0be4c: b.ls            #0xa0bfec
    // 0xa0be50: stp             x3, x1, [SP, #-0x10]!
    // 0xa0be54: r0 = readDBusUint32()
    //     0xa0be54: bl              #0xa0c000  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusUint32
    // 0xa0be58: add             SP, SP, #0x10
    // 0xa0be5c: stur            x0, [fp, #-0x28]
    // 0xa0be60: cmp             w0, NULL
    // 0xa0be64: b.eq            #0xa0be90
    // 0xa0be68: ldur            x16, [fp, #-0x20]
    // 0xa0be6c: ldur            lr, [fp, #-0x18]
    // 0xa0be70: stp             lr, x16, [SP, #-0x10]!
    // 0xa0be74: r0 = getAlignment()
    //     0xa0be74: bl              #0xa01574  ; [package:dbus/src/dbus_buffer.dart] DBusBuffer::getAlignment
    // 0xa0be78: add             SP, SP, #0x10
    // 0xa0be7c: ldur            x16, [fp, #-0x20]
    // 0xa0be80: stp             x0, x16, [SP, #-0x10]!
    // 0xa0be84: r0 = align()
    //     0xa0be84: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa0be88: add             SP, SP, #0x10
    // 0xa0be8c: tbz             w0, #4, #0xa0bea0
    // 0xa0be90: r0 = Null
    //     0xa0be90: mov             x0, NULL
    // 0xa0be94: LeaveFrame
    //     0xa0be94: mov             SP, fp
    //     0xa0be98: ldp             fp, lr, [SP], #0x10
    // 0xa0be9c: ret
    //     0xa0be9c: ret             
    // 0xa0bea0: ldur            x1, [fp, #-0x20]
    // 0xa0bea4: ldur            x0, [fp, #-0x28]
    // 0xa0bea8: LoadField: r2 = r1->field_9b
    //     0xa0bea8: ldur            x2, [x1, #0x9b]
    // 0xa0beac: LoadField: r3 = r0->field_7
    //     0xa0beac: ldur            x3, [x0, #7]
    // 0xa0beb0: add             x0, x2, x3
    // 0xa0beb4: stur            x0, [fp, #-0x30]
    // 0xa0beb8: r16 = <DBusValue>
    //     0xa0beb8: ldr             x16, [PP, #0x76d0]  ; [pp+0x76d0] TypeArguments: <DBusValue>
    // 0xa0bebc: stp             xzr, x16, [SP, #-0x10]!
    // 0xa0bec0: r0 = _GrowableList()
    //     0xa0bec0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa0bec4: add             SP, SP, #0x10
    // 0xa0bec8: stur            x0, [fp, #-0x28]
    // 0xa0becc: ldur            x1, [fp, #-0x20]
    // 0xa0bed0: ldur            x3, [fp, #-8]
    // 0xa0bed4: ldur            x2, [fp, #-0x30]
    // 0xa0bed8: CheckStackOverflow
    //     0xa0bed8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0bedc: cmp             SP, x16
    //     0xa0bee0: b.ls            #0xa0bff4
    // 0xa0bee4: LoadField: r4 = r1->field_9b
    //     0xa0bee4: ldur            x4, [x1, #0x9b]
    // 0xa0bee8: cmp             x4, x2
    // 0xa0beec: b.ge            #0xa0bfb8
    // 0xa0bef0: ldur            x16, [fp, #-0x18]
    // 0xa0bef4: stp             x16, x1, [SP, #-0x10]!
    // 0xa0bef8: ldur            x16, [fp, #-0x10]
    // 0xa0befc: stp             x3, x16, [SP, #-0x10]!
    // 0xa0bf00: r0 = readDBusValue()
    //     0xa0bf00: bl              #0xa091c8  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readDBusValue
    // 0xa0bf04: add             SP, SP, #0x20
    // 0xa0bf08: stur            x0, [fp, #-0x40]
    // 0xa0bf0c: cmp             w0, NULL
    // 0xa0bf10: b.ne            #0xa0bf24
    // 0xa0bf14: r0 = Null
    //     0xa0bf14: mov             x0, NULL
    // 0xa0bf18: LeaveFrame
    //     0xa0bf18: mov             SP, fp
    //     0xa0bf1c: ldp             fp, lr, [SP], #0x10
    // 0xa0bf20: ret
    //     0xa0bf20: ret             
    // 0xa0bf24: ldur            x1, [fp, #-0x28]
    // 0xa0bf28: LoadField: r2 = r1->field_b
    //     0xa0bf28: ldur            w2, [x1, #0xb]
    // 0xa0bf2c: DecompressPointer r2
    //     0xa0bf2c: add             x2, x2, HEAP, lsl #32
    // 0xa0bf30: stur            x2, [fp, #-0x38]
    // 0xa0bf34: LoadField: r3 = r1->field_f
    //     0xa0bf34: ldur            w3, [x1, #0xf]
    // 0xa0bf38: DecompressPointer r3
    //     0xa0bf38: add             x3, x3, HEAP, lsl #32
    // 0xa0bf3c: LoadField: r4 = r3->field_b
    //     0xa0bf3c: ldur            w4, [x3, #0xb]
    // 0xa0bf40: DecompressPointer r4
    //     0xa0bf40: add             x4, x4, HEAP, lsl #32
    // 0xa0bf44: cmp             w2, w4
    // 0xa0bf48: b.ne            #0xa0bf58
    // 0xa0bf4c: SaveReg r1
    //     0xa0bf4c: str             x1, [SP, #-8]!
    // 0xa0bf50: r0 = _growToNextCapacity()
    //     0xa0bf50: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa0bf54: add             SP, SP, #8
    // 0xa0bf58: ldur            x2, [fp, #-0x28]
    // 0xa0bf5c: ldur            x0, [fp, #-0x38]
    // 0xa0bf60: r3 = LoadInt32Instr(r0)
    //     0xa0bf60: sbfx            x3, x0, #1, #0x1f
    // 0xa0bf64: add             x0, x3, #1
    // 0xa0bf68: lsl             x1, x0, #1
    // 0xa0bf6c: StoreField: r2->field_b = r1
    //     0xa0bf6c: stur            w1, [x2, #0xb]
    // 0xa0bf70: mov             x1, x3
    // 0xa0bf74: cmp             x1, x0
    // 0xa0bf78: b.hs            #0xa0bffc
    // 0xa0bf7c: LoadField: r1 = r2->field_f
    //     0xa0bf7c: ldur            w1, [x2, #0xf]
    // 0xa0bf80: DecompressPointer r1
    //     0xa0bf80: add             x1, x1, HEAP, lsl #32
    // 0xa0bf84: ldur            x0, [fp, #-0x40]
    // 0xa0bf88: ArrayStore: r1[r3] = r0  ; List_4
    //     0xa0bf88: add             x25, x1, x3, lsl #2
    //     0xa0bf8c: add             x25, x25, #0xf
    //     0xa0bf90: str             w0, [x25]
    //     0xa0bf94: tbz             w0, #0, #0xa0bfb0
    //     0xa0bf98: ldurb           w16, [x1, #-1]
    //     0xa0bf9c: ldurb           w17, [x0, #-1]
    //     0xa0bfa0: and             x16, x17, x16, lsr #2
    //     0xa0bfa4: tst             x16, HEAP, lsr #32
    //     0xa0bfa8: b.eq            #0xa0bfb0
    //     0xa0bfac: bl              #0xd67e5c
    // 0xa0bfb0: mov             x0, x2
    // 0xa0bfb4: b               #0xa0becc
    // 0xa0bfb8: mov             x2, x0
    // 0xa0bfbc: r0 = DBusArray()
    //     0xa0bfbc: bl              #0xa0056c  ; AllocateDBusArrayStub -> DBusArray (size=0x10)
    // 0xa0bfc0: stur            x0, [fp, #-0x10]
    // 0xa0bfc4: ldur            x16, [fp, #-0x18]
    // 0xa0bfc8: stp             x16, x0, [SP, #-0x10]!
    // 0xa0bfcc: ldur            x16, [fp, #-0x28]
    // 0xa0bfd0: SaveReg r16
    //     0xa0bfd0: str             x16, [SP, #-8]!
    // 0xa0bfd4: r0 = DBusArray()
    //     0xa0bfd4: bl              #0xa00200  ; [package:dbus/src/dbus_value.dart] DBusArray::DBusArray
    // 0xa0bfd8: add             SP, SP, #0x18
    // 0xa0bfdc: ldur            x0, [fp, #-0x10]
    // 0xa0bfe0: LeaveFrame
    //     0xa0bfe0: mov             SP, fp
    //     0xa0bfe4: ldp             fp, lr, [SP], #0x10
    // 0xa0bfe8: ret
    //     0xa0bfe8: ret             
    // 0xa0bfec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0bfec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0bff0: b               #0xa0be50
    // 0xa0bff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0bff4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0bff8: b               #0xa0bee4
    // 0xa0bffc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0bffc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ readDBusUint32(/* No info */) {
    // ** addr: 0xa0c000, size: 0x9c
    // 0xa0c000: EnterFrame
    //     0xa0c000: stp             fp, lr, [SP, #-0x10]!
    //     0xa0c004: mov             fp, SP
    // 0xa0c008: AllocStack(0x8)
    //     0xa0c008: sub             SP, SP, #8
    // 0xa0c00c: r0 = 4
    //     0xa0c00c: mov             x0, #4
    // 0xa0c010: CheckStackOverflow
    //     0xa0c010: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0c014: cmp             SP, x16
    //     0xa0c018: b.ls            #0xa0c094
    // 0xa0c01c: ldr             x16, [fp, #0x18]
    // 0xa0c020: stp             x0, x16, [SP, #-0x10]!
    // 0xa0c024: r0 = align()
    //     0xa0c024: bl              #0xa0bd24  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::align
    // 0xa0c028: add             SP, SP, #0x10
    // 0xa0c02c: tbnz            w0, #4, #0xa0c058
    // 0xa0c030: ldr             x0, [fp, #0x18]
    // 0xa0c034: LoadField: r1 = r0->field_8f
    //     0xa0c034: ldur            w1, [x0, #0x8f]
    // 0xa0c038: DecompressPointer r1
    //     0xa0c038: add             x1, x1, HEAP, lsl #32
    // 0xa0c03c: LoadField: r2 = r1->field_13
    //     0xa0c03c: ldur            w2, [x1, #0x13]
    // 0xa0c040: DecompressPointer r2
    //     0xa0c040: add             x2, x2, HEAP, lsl #32
    // 0xa0c044: LoadField: r1 = r0->field_9b
    //     0xa0c044: ldur            x1, [x0, #0x9b]
    // 0xa0c048: r3 = LoadInt32Instr(r2)
    //     0xa0c048: sbfx            x3, x2, #1, #0x1f
    // 0xa0c04c: sub             x2, x3, x1
    // 0xa0c050: cmp             x2, #4
    // 0xa0c054: b.ge            #0xa0c068
    // 0xa0c058: r0 = Null
    //     0xa0c058: mov             x0, NULL
    // 0xa0c05c: LeaveFrame
    //     0xa0c05c: mov             SP, fp
    //     0xa0c060: ldp             fp, lr, [SP], #0x10
    // 0xa0c064: ret
    //     0xa0c064: ret             
    // 0xa0c068: ldr             x16, [fp, #0x10]
    // 0xa0c06c: stp             x16, x0, [SP, #-0x10]!
    // 0xa0c070: r0 = readUint32()
    //     0xa0c070: bl              #0xa0bba4  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::readUint32
    // 0xa0c074: add             SP, SP, #0x10
    // 0xa0c078: stur            x0, [fp, #-8]
    // 0xa0c07c: r0 = DBusUint32()
    //     0xa0c07c: bl              #0xa00650  ; AllocateDBusUint32Stub -> DBusUint32 (size=0x10)
    // 0xa0c080: ldur            x1, [fp, #-8]
    // 0xa0c084: StoreField: r0->field_7 = r1
    //     0xa0c084: stur            x1, [x0, #7]
    // 0xa0c088: LeaveFrame
    //     0xa0c088: mov             SP, fp
    //     0xa0c08c: ldp             fp, lr, [SP], #0x10
    // 0xa0c090: ret
    //     0xa0c090: ret             
    // 0xa0c094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0c094: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0c098: b               #0xa0c01c
  }
  _ readDBusByte(/* No info */) {
    // ** addr: 0xa0c09c, size: 0x80
    // 0xa0c09c: EnterFrame
    //     0xa0c09c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0c0a0: mov             fp, SP
    // 0xa0c0a4: AllocStack(0x8)
    //     0xa0c0a4: sub             SP, SP, #8
    // 0xa0c0a8: CheckStackOverflow
    //     0xa0c0a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0c0ac: cmp             SP, x16
    //     0xa0c0b0: b.ls            #0xa0c114
    // 0xa0c0b4: ldr             x0, [fp, #0x10]
    // 0xa0c0b8: LoadField: r1 = r0->field_8f
    //     0xa0c0b8: ldur            w1, [x0, #0x8f]
    // 0xa0c0bc: DecompressPointer r1
    //     0xa0c0bc: add             x1, x1, HEAP, lsl #32
    // 0xa0c0c0: LoadField: r2 = r1->field_13
    //     0xa0c0c0: ldur            w2, [x1, #0x13]
    // 0xa0c0c4: DecompressPointer r2
    //     0xa0c0c4: add             x2, x2, HEAP, lsl #32
    // 0xa0c0c8: LoadField: r1 = r0->field_9b
    //     0xa0c0c8: ldur            x1, [x0, #0x9b]
    // 0xa0c0cc: r3 = LoadInt32Instr(r2)
    //     0xa0c0cc: sbfx            x3, x2, #1, #0x1f
    // 0xa0c0d0: sub             x2, x3, x1
    // 0xa0c0d4: cmp             x2, #1
    // 0xa0c0d8: b.ge            #0xa0c0ec
    // 0xa0c0dc: r0 = Null
    //     0xa0c0dc: mov             x0, NULL
    // 0xa0c0e0: LeaveFrame
    //     0xa0c0e0: mov             SP, fp
    //     0xa0c0e4: ldp             fp, lr, [SP], #0x10
    // 0xa0c0e8: ret
    //     0xa0c0e8: ret             
    // 0xa0c0ec: SaveReg r0
    //     0xa0c0ec: str             x0, [SP, #-8]!
    // 0xa0c0f0: r0 = _readByte()
    //     0xa0c0f0: bl              #0xa0a59c  ; [package:dbus/src/dbus_read_buffer.dart] DBusReadBuffer::_readByte
    // 0xa0c0f4: add             SP, SP, #8
    // 0xa0c0f8: stur            x0, [fp, #-8]
    // 0xa0c0fc: r0 = DBusByte()
    //     0xa0c0fc: bl              #0xa0065c  ; AllocateDBusByteStub -> DBusByte (size=0x10)
    // 0xa0c100: ldur            x1, [fp, #-8]
    // 0xa0c104: StoreField: r0->field_7 = r1
    //     0xa0c104: stur            x1, [x0, #7]
    // 0xa0c108: LeaveFrame
    //     0xa0c108: mov             SP, fp
    //     0xa0c10c: ldp             fp, lr, [SP], #0x10
    // 0xa0c110: ret
    //     0xa0c110: ret             
    // 0xa0c114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0c114: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0c118: b               #0xa0c0b4
  }
  _ readLine(/* No info */) {
    // ** addr: 0xa0db10, size: 0x170
    // 0xa0db10: EnterFrame
    //     0xa0db10: stp             fp, lr, [SP, #-0x10]!
    //     0xa0db14: mov             fp, SP
    // 0xa0db18: AllocStack(0x8)
    //     0xa0db18: sub             SP, SP, #8
    // 0xa0db1c: CheckStackOverflow
    //     0xa0db1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0db20: cmp             SP, x16
    //     0xa0db24: b.ls            #0xa0dc68
    // 0xa0db28: ldr             x2, [fp, #0x10]
    // 0xa0db2c: LoadField: r3 = r2->field_9b
    //     0xa0db2c: ldur            x3, [x2, #0x9b]
    // 0xa0db30: LoadField: r4 = r2->field_8f
    //     0xa0db30: ldur            w4, [x2, #0x8f]
    // 0xa0db34: DecompressPointer r4
    //     0xa0db34: add             x4, x4, HEAP, lsl #32
    // 0xa0db38: LoadField: r0 = r4->field_13
    //     0xa0db38: ldur            w0, [x4, #0x13]
    // 0xa0db3c: DecompressPointer r0
    //     0xa0db3c: add             x0, x0, HEAP, lsl #32
    // 0xa0db40: r5 = LoadInt32Instr(r0)
    //     0xa0db40: sbfx            x5, x0, #1, #0x1f
    // 0xa0db44: sub             x6, x5, #1
    // 0xa0db48: mov             x7, x3
    // 0xa0db4c: stur            x7, [fp, #-8]
    // 0xa0db50: CheckStackOverflow
    //     0xa0db50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0db54: cmp             SP, x16
    //     0xa0db58: b.ls            #0xa0dc70
    // 0xa0db5c: cmp             x7, x6
    // 0xa0db60: b.ge            #0xa0dc58
    // 0xa0db64: mov             x0, x5
    // 0xa0db68: mov             x1, x7
    // 0xa0db6c: cmp             x1, x0
    // 0xa0db70: b.hs            #0xa0dc78
    // 0xa0db74: LoadField: r0 = r4->field_7
    //     0xa0db74: ldur            x0, [x4, #7]
    // 0xa0db78: ldrb            w1, [x0, x7]
    // 0xa0db7c: lsl             x0, x1, #1
    // 0xa0db80: cmp             w0, #0x1a
    // 0xa0db84: b.ne            #0xa0dc40
    // 0xa0db88: add             x8, x7, #1
    // 0xa0db8c: mov             x0, x5
    // 0xa0db90: mov             x1, x8
    // 0xa0db94: cmp             x1, x0
    // 0xa0db98: b.hs            #0xa0dc7c
    // 0xa0db9c: LoadField: r0 = r4->field_7
    //     0xa0db9c: ldur            x0, [x4, #7]
    // 0xa0dba0: ldrb            w1, [x0, x8]
    // 0xa0dba4: lsl             x0, x1, #1
    // 0xa0dba8: cmp             w0, #0x14
    // 0xa0dbac: b.ne            #0xa0dc34
    // 0xa0dbb0: r0 = BoxInt64Instr(r3)
    //     0xa0dbb0: sbfiz           x0, x3, #1, #0x1f
    //     0xa0dbb4: cmp             x3, x0, asr #1
    //     0xa0dbb8: b.eq            #0xa0dbc4
    //     0xa0dbbc: bl              #0xd69bb8
    //     0xa0dbc0: stur            x3, [x0, #7]
    // 0xa0dbc4: r1 = LoadClassIdInstr(r4)
    //     0xa0dbc4: ldur            x1, [x4, #-1]
    //     0xa0dbc8: ubfx            x1, x1, #0xc, #0x14
    // 0xa0dbcc: stp             x0, x4, [SP, #-0x10]!
    // 0xa0dbd0: SaveReg r7
    //     0xa0dbd0: str             x7, [SP, #-8]!
    // 0xa0dbd4: mov             x0, x1
    // 0xa0dbd8: r0 = GDT[cid_x0 + 0x1094d]()
    //     0xa0dbd8: mov             x17, #0x94d
    //     0xa0dbdc: movk            x17, #1, lsl #16
    //     0xa0dbe0: add             lr, x0, x17
    //     0xa0dbe4: ldr             lr, [x21, lr, lsl #3]
    //     0xa0dbe8: blr             lr
    // 0xa0dbec: add             SP, SP, #0x18
    // 0xa0dbf0: mov             x1, x0
    // 0xa0dbf4: ldur            x0, [fp, #-8]
    // 0xa0dbf8: add             x2, x0, #2
    // 0xa0dbfc: ldr             x7, [fp, #0x10]
    // 0xa0dc00: StoreField: r7->field_9b = r2
    //     0xa0dc00: stur            x2, [x7, #0x9b]
    // 0xa0dc04: SaveReg r1
    //     0xa0dc04: str             x1, [SP, #-8]!
    // 0xa0dc08: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0dc08: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0dc0c: r0 = toList()
    //     0xa0dc0c: bl              #0x6bab5c  ; [dart:_internal] SubListIterable::toList
    // 0xa0dc10: add             SP, SP, #8
    // 0xa0dc14: r16 = Instance_Utf8Codec
    //     0xa0dc14: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xa0dc18: stp             x0, x16, [SP, #-0x10]!
    // 0xa0dc1c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0dc1c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0dc20: r0 = decode()
    //     0xa0dc20: bl              #0x4e1c78  ; [dart:convert] Utf8Codec::decode
    // 0xa0dc24: add             SP, SP, #0x10
    // 0xa0dc28: LeaveFrame
    //     0xa0dc28: mov             SP, fp
    //     0xa0dc2c: ldp             fp, lr, [SP], #0x10
    // 0xa0dc30: ret
    //     0xa0dc30: ret             
    // 0xa0dc34: mov             x0, x7
    // 0xa0dc38: mov             x7, x2
    // 0xa0dc3c: b               #0xa0dc48
    // 0xa0dc40: mov             x0, x7
    // 0xa0dc44: mov             x7, x2
    // 0xa0dc48: add             x1, x0, #1
    // 0xa0dc4c: mov             x2, x7
    // 0xa0dc50: mov             x7, x1
    // 0xa0dc54: b               #0xa0db4c
    // 0xa0dc58: r0 = Null
    //     0xa0dc58: mov             x0, NULL
    // 0xa0dc5c: LeaveFrame
    //     0xa0dc5c: mov             SP, fp
    //     0xa0dc60: ldp             fp, lr, [SP], #0x10
    // 0xa0dc64: ret
    //     0xa0dc64: ret             
    // 0xa0dc68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0dc68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0dc6c: b               #0xa0db28
    // 0xa0dc70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0dc70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0dc74: b               #0xa0db5c
    // 0xa0dc78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0dc78: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa0dc7c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0dc7c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ writeBytes(/* No info */) {
    // ** addr: 0xa0dc80, size: 0x138
    // 0xa0dc80: EnterFrame
    //     0xa0dc80: stp             fp, lr, [SP, #-0x10]!
    //     0xa0dc84: mov             fp, SP
    // 0xa0dc88: AllocStack(0x8)
    //     0xa0dc88: sub             SP, SP, #8
    // 0xa0dc8c: CheckStackOverflow
    //     0xa0dc8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0dc90: cmp             SP, x16
    //     0xa0dc94: b.ls            #0xa0ddb0
    // 0xa0dc98: r0 = _BytesBuilder()
    //     0xa0dc98: bl              #0x585268  ; Allocate_BytesBuilderStub -> _BytesBuilder (size=0x14)
    // 0xa0dc9c: mov             x1, x0
    // 0xa0dca0: r0 = 0
    //     0xa0dca0: mov             x0, #0
    // 0xa0dca4: stur            x1, [fp, #-8]
    // 0xa0dca8: StoreField: r1->field_7 = r0
    //     0xa0dca8: stur            x0, [x1, #7]
    // 0xa0dcac: r16 = <Uint8List>
    //     0xa0dcac: ldr             x16, [PP, #0x1540]  ; [pp+0x1540] TypeArguments: <Uint8List>
    // 0xa0dcb0: stp             xzr, x16, [SP, #-0x10]!
    // 0xa0dcb4: r0 = _GrowableList()
    //     0xa0dcb4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa0dcb8: add             SP, SP, #0x10
    // 0xa0dcbc: ldur            x1, [fp, #-8]
    // 0xa0dcc0: StoreField: r1->field_f = r0
    //     0xa0dcc0: stur            w0, [x1, #0xf]
    //     0xa0dcc4: ldurb           w16, [x1, #-1]
    //     0xa0dcc8: ldurb           w17, [x0, #-1]
    //     0xa0dccc: and             x16, x17, x16, lsr #2
    //     0xa0dcd0: tst             x16, HEAP, lsr #32
    //     0xa0dcd4: b.eq            #0xa0dcdc
    //     0xa0dcd8: bl              #0xd6826c
    // 0xa0dcdc: ldr             x0, [fp, #0x18]
    // 0xa0dce0: LoadField: r2 = r0->field_8f
    //     0xa0dce0: ldur            w2, [x0, #0x8f]
    // 0xa0dce4: DecompressPointer r2
    //     0xa0dce4: add             x2, x2, HEAP, lsl #32
    // 0xa0dce8: stp             x2, x1, [SP, #-0x10]!
    // 0xa0dcec: r0 = add()
    //     0xa0dcec: bl              #0xca7c90  ; [dart:_internal] _BytesBuilder::add
    // 0xa0dcf0: add             SP, SP, #0x10
    // 0xa0dcf4: ldur            x16, [fp, #-8]
    // 0xa0dcf8: ldr             lr, [fp, #0x10]
    // 0xa0dcfc: stp             lr, x16, [SP, #-0x10]!
    // 0xa0dd00: r0 = add()
    //     0xa0dd00: bl              #0xca7c90  ; [dart:_internal] _BytesBuilder::add
    // 0xa0dd04: add             SP, SP, #0x10
    // 0xa0dd08: ldur            x16, [fp, #-8]
    // 0xa0dd0c: SaveReg r16
    //     0xa0dd0c: str             x16, [SP, #-8]!
    // 0xa0dd10: r0 = takeBytes()
    //     0xa0dd10: bl              #0xcaa884  ; [dart:_internal] _BytesBuilder::takeBytes
    // 0xa0dd14: add             SP, SP, #8
    // 0xa0dd18: mov             x2, x0
    // 0xa0dd1c: ldr             x1, [fp, #0x18]
    // 0xa0dd20: StoreField: r1->field_8f = r0
    //     0xa0dd20: stur            w0, [x1, #0x8f]
    //     0xa0dd24: ldurb           w16, [x1, #-1]
    //     0xa0dd28: ldurb           w17, [x0, #-1]
    //     0xa0dd2c: and             x16, x17, x16, lsr #2
    //     0xa0dd30: tst             x16, HEAP, lsr #32
    //     0xa0dd34: b.eq            #0xa0dd3c
    //     0xa0dd38: bl              #0xd6826c
    // 0xa0dd3c: r0 = LoadClassIdInstr(r2)
    //     0xa0dd3c: ldur            x0, [x2, #-1]
    //     0xa0dd40: ubfx            x0, x0, #0xc, #0x14
    // 0xa0dd44: SaveReg r2
    //     0xa0dd44: str             x2, [SP, #-8]!
    // 0xa0dd48: r0 = GDT[cid_x0 + -0xf7e]()
    //     0xa0dd48: sub             lr, x0, #0xf7e
    //     0xa0dd4c: ldr             lr, [x21, lr, lsl #3]
    //     0xa0dd50: blr             lr
    // 0xa0dd54: add             SP, SP, #8
    // 0xa0dd58: r1 = LoadClassIdInstr(r0)
    //     0xa0dd58: ldur            x1, [x0, #-1]
    //     0xa0dd5c: ubfx            x1, x1, #0xc, #0x14
    // 0xa0dd60: stp             xzr, x0, [SP, #-0x10]!
    // 0xa0dd64: SaveReg rNULL
    //     0xa0dd64: str             NULL, [SP, #-8]!
    // 0xa0dd68: mov             x0, x1
    // 0xa0dd6c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa0dd6c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa0dd70: r0 = GDT[cid_x0 + -0xff7]()
    //     0xa0dd70: sub             lr, x0, #0xff7
    //     0xa0dd74: ldr             lr, [x21, lr, lsl #3]
    //     0xa0dd78: blr             lr
    // 0xa0dd7c: add             SP, SP, #0x18
    // 0xa0dd80: ldr             x1, [fp, #0x18]
    // 0xa0dd84: StoreField: r1->field_97 = r0
    //     0xa0dd84: stur            w0, [x1, #0x97]
    //     0xa0dd88: ldurb           w16, [x1, #-1]
    //     0xa0dd8c: ldurb           w17, [x0, #-1]
    //     0xa0dd90: and             x16, x17, x16, lsr #2
    //     0xa0dd94: tst             x16, HEAP, lsr #32
    //     0xa0dd98: b.eq            #0xa0dda0
    //     0xa0dd9c: bl              #0xd6826c
    // 0xa0dda0: r0 = Null
    //     0xa0dda0: mov             x0, NULL
    // 0xa0dda4: LeaveFrame
    //     0xa0dda4: mov             SP, fp
    //     0xa0dda8: ldp             fp, lr, [SP], #0x10
    // 0xa0ddac: ret
    //     0xa0ddac: ret             
    // 0xa0ddb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0ddb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0ddb4: b               #0xa0dc98
  }
  _ toString(/* No info */) {
    // ** addr: 0xacf554, size: 0x26c
    // 0xacf554: EnterFrame
    //     0xacf554: stp             fp, lr, [SP, #-0x10]!
    //     0xacf558: mov             fp, SP
    // 0xacf55c: AllocStack(0x40)
    //     0xacf55c: sub             SP, SP, #0x40
    // 0xacf560: CheckStackOverflow
    //     0xacf560: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf564: cmp             SP, x16
    //     0xacf568: b.ls            #0xacf7b0
    // 0xacf56c: ldr             x0, [fp, #0x10]
    // 0xacf570: LoadField: r1 = r0->field_8f
    //     0xacf570: ldur            w1, [x0, #0x8f]
    // 0xacf574: DecompressPointer r1
    //     0xacf574: add             x1, x1, HEAP, lsl #32
    // 0xacf578: r0 = LoadClassIdInstr(r1)
    //     0xacf578: ldur            x0, [x1, #-1]
    //     0xacf57c: ubfx            x0, x0, #0xc, #0x14
    // 0xacf580: SaveReg r1
    //     0xacf580: str             x1, [SP, #-8]!
    // 0xacf584: r0 = GDT[cid_x0 + 0xb940]()
    //     0xacf584: mov             x17, #0xb940
    //     0xacf588: add             lr, x0, x17
    //     0xacf58c: ldr             lr, [x21, lr, lsl #3]
    //     0xacf590: blr             lr
    // 0xacf594: add             SP, SP, #8
    // 0xacf598: mov             x2, x0
    // 0xacf59c: stur            x2, [fp, #-0x30]
    // 0xacf5a0: LoadField: r3 = r2->field_f
    //     0xacf5a0: ldur            x3, [x2, #0xf]
    // 0xacf5a4: stur            x3, [fp, #-0x28]
    // 0xacf5a8: LoadField: r4 = r2->field_b
    //     0xacf5a8: ldur            w4, [x2, #0xb]
    // 0xacf5ac: DecompressPointer r4
    //     0xacf5ac: add             x4, x4, HEAP, lsl #32
    // 0xacf5b0: stur            x4, [fp, #-0x20]
    // 0xacf5b4: LoadField: r5 = r2->field_7
    //     0xacf5b4: ldur            w5, [x2, #7]
    // 0xacf5b8: DecompressPointer r5
    //     0xacf5b8: add             x5, x5, HEAP, lsl #32
    // 0xacf5bc: stur            x5, [fp, #-0x18]
    // 0xacf5c0: r6 = ""
    //     0xacf5c0: ldr             x6, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xacf5c4: stur            x6, [fp, #-0x10]
    // 0xacf5c8: CheckStackOverflow
    //     0xacf5c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacf5cc: cmp             SP, x16
    //     0xacf5d0: b.ls            #0xacf7b8
    // 0xacf5d4: LoadField: r0 = r2->field_17
    //     0xacf5d4: ldur            x0, [x2, #0x17]
    // 0xacf5d8: add             x7, x0, #1
    // 0xacf5dc: stur            x7, [fp, #-8]
    // 0xacf5e0: cmp             x7, x3
    // 0xacf5e4: b.ge            #0xacf758
    // 0xacf5e8: r0 = BoxInt64Instr(r7)
    //     0xacf5e8: sbfiz           x0, x7, #1, #0x1f
    //     0xacf5ec: cmp             x7, x0, asr #1
    //     0xacf5f0: b.eq            #0xacf5fc
    //     0xacf5f4: bl              #0xd69bb8
    //     0xacf5f8: stur            x7, [x0, #7]
    // 0xacf5fc: r1 = LoadClassIdInstr(r4)
    //     0xacf5fc: ldur            x1, [x4, #-1]
    //     0xacf600: ubfx            x1, x1, #0xc, #0x14
    // 0xacf604: stp             x0, x4, [SP, #-0x10]!
    // 0xacf608: mov             x0, x1
    // 0xacf60c: r0 = GDT[cid_x0 + -0xd83]()
    //     0xacf60c: sub             lr, x0, #0xd83
    //     0xacf610: ldr             lr, [x21, lr, lsl #3]
    //     0xacf614: blr             lr
    // 0xacf618: add             SP, SP, #0x10
    // 0xacf61c: mov             x4, x0
    // 0xacf620: ldur            x3, [fp, #-0x30]
    // 0xacf624: stur            x4, [fp, #-0x38]
    // 0xacf628: StoreField: r3->field_1f = r0
    //     0xacf628: stur            w0, [x3, #0x1f]
    //     0xacf62c: tbz             w0, #0, #0xacf648
    //     0xacf630: ldurb           w16, [x3, #-1]
    //     0xacf634: ldurb           w17, [x0, #-1]
    //     0xacf638: and             x16, x17, x16, lsr #2
    //     0xacf63c: tst             x16, HEAP, lsr #32
    //     0xacf640: b.eq            #0xacf648
    //     0xacf644: bl              #0xd682ac
    // 0xacf648: ldur            x0, [fp, #-8]
    // 0xacf64c: StoreField: r3->field_17 = r0
    //     0xacf64c: stur            x0, [x3, #0x17]
    // 0xacf650: cmp             w4, NULL
    // 0xacf654: b.ne            #0xacf684
    // 0xacf658: mov             x0, x4
    // 0xacf65c: ldur            x2, [fp, #-0x18]
    // 0xacf660: r1 = Null
    //     0xacf660: mov             x1, NULL
    // 0xacf664: cmp             w2, NULL
    // 0xacf668: b.eq            #0xacf684
    // 0xacf66c: LoadField: r4 = r2->field_17
    //     0xacf66c: ldur            w4, [x2, #0x17]
    // 0xacf670: DecompressPointer r4
    //     0xacf670: add             x4, x4, HEAP, lsl #32
    // 0xacf674: r8 = X0
    //     0xacf674: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xacf678: LoadField: r9 = r4->field_7
    //     0xacf678: ldur            x9, [x4, #7]
    // 0xacf67c: r3 = Null
    //     0xacf67c: ldr             x3, [PP, #0x7610]  ; [pp+0x7610] Null
    // 0xacf680: blr             x9
    // 0xacf684: ldur            x0, [fp, #-0x38]
    // 0xacf688: r1 = LoadInt32Instr(r0)
    //     0xacf688: sbfx            x1, x0, #1, #0x1f
    //     0xacf68c: tbz             w0, #0, #0xacf694
    //     0xacf690: ldur            x1, [x0, #7]
    // 0xacf694: cmp             x1, #0x21
    // 0xacf698: b.lt            #0xacf6c8
    // 0xacf69c: cmp             x1, #0x7e
    // 0xacf6a0: b.gt            #0xacf6c8
    // 0xacf6a4: stp             x1, NULL, [SP, #-0x10]!
    // 0xacf6a8: r0 = String.fromCharCode()
    //     0xacf6a8: bl              #0x4d316c  ; [dart:core] String::String.fromCharCode
    // 0xacf6ac: add             SP, SP, #0x10
    // 0xacf6b0: ldur            x16, [fp, #-0x10]
    // 0xacf6b4: stp             x0, x16, [SP, #-0x10]!
    // 0xacf6b8: r0 = +()
    //     0xacf6b8: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0xacf6bc: add             SP, SP, #0x10
    // 0xacf6c0: mov             x6, x0
    // 0xacf6c4: b               #0xacf744
    // 0xacf6c8: r1 = Null
    //     0xacf6c8: mov             x1, NULL
    // 0xacf6cc: r2 = 4
    //     0xacf6cc: mov             x2, #4
    // 0xacf6d0: r0 = AllocateArray()
    //     0xacf6d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf6d4: stur            x0, [fp, #-0x40]
    // 0xacf6d8: r17 = "\\"
    //     0xacf6d8: ldr             x17, [PP, #0x1230]  ; [pp+0x1230] "\\"
    // 0xacf6dc: StoreField: r0->field_f = r17
    //     0xacf6dc: stur            w17, [x0, #0xf]
    // 0xacf6e0: ldur            x16, [fp, #-0x38]
    // 0xacf6e4: SaveReg r16
    //     0xacf6e4: str             x16, [SP, #-8]!
    // 0xacf6e8: r1 = 8
    //     0xacf6e8: mov             x1, #8
    // 0xacf6ec: SaveReg r1
    //     0xacf6ec: str             x1, [SP, #-8]!
    // 0xacf6f0: r0 = _toPow2String()
    //     0xacf6f0: bl              #0x506b60  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0xacf6f4: add             SP, SP, #0x10
    // 0xacf6f8: ldur            x1, [fp, #-0x40]
    // 0xacf6fc: ArrayStore: r1[1] = r0  ; List_4
    //     0xacf6fc: add             x25, x1, #0x13
    //     0xacf700: str             w0, [x25]
    //     0xacf704: tbz             w0, #0, #0xacf720
    //     0xacf708: ldurb           w16, [x1, #-1]
    //     0xacf70c: ldurb           w17, [x0, #-1]
    //     0xacf710: and             x16, x17, x16, lsr #2
    //     0xacf714: tst             x16, HEAP, lsr #32
    //     0xacf718: b.eq            #0xacf720
    //     0xacf71c: bl              #0xd67e5c
    // 0xacf720: ldur            x16, [fp, #-0x40]
    // 0xacf724: SaveReg r16
    //     0xacf724: str             x16, [SP, #-8]!
    // 0xacf728: r0 = _interpolate()
    //     0xacf728: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf72c: add             SP, SP, #8
    // 0xacf730: ldur            x16, [fp, #-0x10]
    // 0xacf734: stp             x0, x16, [SP, #-0x10]!
    // 0xacf738: r0 = +()
    //     0xacf738: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0xacf73c: add             SP, SP, #0x10
    // 0xacf740: mov             x6, x0
    // 0xacf744: ldur            x2, [fp, #-0x30]
    // 0xacf748: ldur            x5, [fp, #-0x18]
    // 0xacf74c: ldur            x3, [fp, #-0x28]
    // 0xacf750: ldur            x4, [fp, #-0x20]
    // 0xacf754: b               #0xacf5c4
    // 0xacf758: mov             x0, x2
    // 0xacf75c: mov             x1, x3
    // 0xacf760: mov             x3, x6
    // 0xacf764: StoreField: r0->field_17 = r1
    //     0xacf764: stur            x1, [x0, #0x17]
    // 0xacf768: StoreField: r0->field_1f = rNULL
    //     0xacf768: stur            NULL, [x0, #0x1f]
    // 0xacf76c: r1 = Null
    //     0xacf76c: mov             x1, NULL
    // 0xacf770: r2 = 8
    //     0xacf770: mov             x2, #8
    // 0xacf774: r0 = AllocateArray()
    //     0xacf774: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacf778: r17 = DBusReadBuffer
    //     0xacf778: ldr             x17, [PP, #0x7620]  ; [pp+0x7620] Type: DBusReadBuffer
    // 0xacf77c: StoreField: r0->field_f = r17
    //     0xacf77c: stur            w17, [x0, #0xf]
    // 0xacf780: r17 = "(\'"
    //     0xacf780: ldr             x17, [PP, #0x7168]  ; [pp+0x7168] "(\'"
    // 0xacf784: StoreField: r0->field_13 = r17
    //     0xacf784: stur            w17, [x0, #0x13]
    // 0xacf788: ldur            x1, [fp, #-0x10]
    // 0xacf78c: StoreField: r0->field_17 = r1
    //     0xacf78c: stur            w1, [x0, #0x17]
    // 0xacf790: r17 = "\')"
    //     0xacf790: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xacf794: StoreField: r0->field_1b = r17
    //     0xacf794: stur            w17, [x0, #0x1b]
    // 0xacf798: SaveReg r0
    //     0xacf798: str             x0, [SP, #-8]!
    // 0xacf79c: r0 = _interpolate()
    //     0xacf79c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacf7a0: add             SP, SP, #8
    // 0xacf7a4: LeaveFrame
    //     0xacf7a4: mov             SP, fp
    //     0xacf7a8: ldp             fp, lr, [SP], #0x10
    // 0xacf7ac: ret
    //     0xacf7ac: ret             
    // 0xacf7b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf7b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf7b4: b               #0xacf56c
    // 0xacf7b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacf7b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacf7bc: b               #0xacf5d4
  }
  _ DBusReadBuffer(/* No info */) {
    // ** addr: 0xd6eea4, size: 0xec
    // 0xd6eea4: EnterFrame
    //     0xd6eea4: stp             fp, lr, [SP, #-0x10]!
    //     0xd6eea8: mov             fp, SP
    // 0xd6eeac: r1 = Sentinel
    //     0xd6eeac: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd6eeb0: r0 = 0
    //     0xd6eeb0: mov             x0, #0
    // 0xd6eeb4: CheckStackOverflow
    //     0xd6eeb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6eeb8: cmp             SP, x16
    //     0xd6eebc: b.ls            #0xd6ef88
    // 0xd6eec0: ldr             x2, [fp, #0x10]
    // 0xd6eec4: StoreField: r2->field_97 = r1
    //     0xd6eec4: stur            w1, [x2, #0x97]
    // 0xd6eec8: StoreField: r2->field_9b = r0
    //     0xd6eec8: stur            x0, [x2, #0x9b]
    // 0xd6eecc: r4 = 0
    //     0xd6eecc: mov             x4, #0
    // 0xd6eed0: r0 = AllocateUint8Array()
    //     0xd6eed0: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xd6eed4: ldr             x1, [fp, #0x10]
    // 0xd6eed8: StoreField: r1->field_8f = r0
    //     0xd6eed8: stur            w0, [x1, #0x8f]
    //     0xd6eedc: ldurb           w16, [x1, #-1]
    //     0xd6eee0: ldurb           w17, [x0, #-1]
    //     0xd6eee4: and             x16, x17, x16, lsr #2
    //     0xd6eee8: tst             x16, HEAP, lsr #32
    //     0xd6eeec: b.eq            #0xd6eef4
    //     0xd6eef0: bl              #0xd6826c
    // 0xd6eef4: r16 = <ResourceHandle>
    //     0xd6eef4: ldr             x16, [PP, #0x968]  ; [pp+0x968] TypeArguments: <ResourceHandle>
    // 0xd6eef8: stp             xzr, x16, [SP, #-0x10]!
    // 0xd6eefc: r0 = _GrowableList()
    //     0xd6eefc: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xd6ef00: add             SP, SP, #0x10
    // 0xd6ef04: ldr             x1, [fp, #0x10]
    // 0xd6ef08: StoreField: r1->field_93 = r0
    //     0xd6ef08: stur            w0, [x1, #0x93]
    //     0xd6ef0c: ldurb           w16, [x1, #-1]
    //     0xd6ef10: ldurb           w17, [x0, #-1]
    //     0xd6ef14: and             x16, x17, x16, lsr #2
    //     0xd6ef18: tst             x16, HEAP, lsr #32
    //     0xd6ef1c: b.eq            #0xd6ef24
    //     0xd6ef20: bl              #0xd6826c
    // 0xd6ef24: r2 = 1
    //     0xd6ef24: mov             x2, #1
    // 0xd6ef28: StoreField: r1->field_7 = r2
    //     0xd6ef28: stur            x2, [x1, #7]
    // 0xd6ef2c: r3 = 4
    //     0xd6ef2c: mov             x3, #4
    // 0xd6ef30: StoreField: r1->field_f = r3
    //     0xd6ef30: stur            x3, [x1, #0xf]
    // 0xd6ef34: r4 = 2
    //     0xd6ef34: mov             x4, #2
    // 0xd6ef38: StoreField: r1->field_17 = r4
    //     0xd6ef38: stur            x4, [x1, #0x17]
    // 0xd6ef3c: StoreField: r1->field_1f = r4
    //     0xd6ef3c: stur            x4, [x1, #0x1f]
    // 0xd6ef40: StoreField: r1->field_27 = r3
    //     0xd6ef40: stur            x3, [x1, #0x27]
    // 0xd6ef44: StoreField: r1->field_2f = r3
    //     0xd6ef44: stur            x3, [x1, #0x2f]
    // 0xd6ef48: r4 = 8
    //     0xd6ef48: mov             x4, #8
    // 0xd6ef4c: StoreField: r1->field_37 = r4
    //     0xd6ef4c: stur            x4, [x1, #0x37]
    // 0xd6ef50: StoreField: r1->field_3f = r4
    //     0xd6ef50: stur            x4, [x1, #0x3f]
    // 0xd6ef54: StoreField: r1->field_47 = r4
    //     0xd6ef54: stur            x4, [x1, #0x47]
    // 0xd6ef58: StoreField: r1->field_4f = r3
    //     0xd6ef58: stur            x3, [x1, #0x4f]
    // 0xd6ef5c: StoreField: r1->field_57 = r3
    //     0xd6ef5c: stur            x3, [x1, #0x57]
    // 0xd6ef60: StoreField: r1->field_5f = r2
    //     0xd6ef60: stur            x2, [x1, #0x5f]
    // 0xd6ef64: StoreField: r1->field_67 = r2
    //     0xd6ef64: stur            x2, [x1, #0x67]
    // 0xd6ef68: StoreField: r1->field_6f = r4
    //     0xd6ef68: stur            x4, [x1, #0x6f]
    // 0xd6ef6c: StoreField: r1->field_77 = r3
    //     0xd6ef6c: stur            x3, [x1, #0x77]
    // 0xd6ef70: StoreField: r1->field_7f = r4
    //     0xd6ef70: stur            x4, [x1, #0x7f]
    // 0xd6ef74: StoreField: r1->field_87 = r3
    //     0xd6ef74: stur            x3, [x1, #0x87]
    // 0xd6ef78: r0 = Null
    //     0xd6ef78: mov             x0, NULL
    // 0xd6ef7c: LeaveFrame
    //     0xd6ef7c: mov             SP, fp
    //     0xd6ef80: ldp             fp, lr, [SP], #0x10
    // 0xd6ef84: ret
    //     0xd6ef84: ret             
    // 0xd6ef88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6ef88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6ef8c: b               #0xd6eec0
  }
}

// lib: , url: package:dbus/src/dbus_auth_client.dart

// class id: 1048829, size: 0x8
class :: {
}

// class id: 4636, size: 0x1c, field offset: 0x8
class DBusAuthClient extends Object {

  get _ requests(/* No info */) {
    // ** addr: 0xa03514, size: 0x3c
    // 0xa03514: EnterFrame
    //     0xa03514: stp             fp, lr, [SP, #-0x10]!
    //     0xa03518: mov             fp, SP
    // 0xa0351c: AllocStack(0x8)
    //     0xa0351c: sub             SP, SP, #8
    // 0xa03520: ldr             x0, [fp, #0x10]
    // 0xa03524: LoadField: r2 = r0->field_b
    //     0xa03524: ldur            w2, [x0, #0xb]
    // 0xa03528: DecompressPointer r2
    //     0xa03528: add             x2, x2, HEAP, lsl #32
    // 0xa0352c: stur            x2, [fp, #-8]
    // 0xa03530: LoadField: r1 = r2->field_7
    //     0xa03530: ldur            w1, [x2, #7]
    // 0xa03534: DecompressPointer r1
    //     0xa03534: add             x1, x1, HEAP, lsl #32
    // 0xa03538: r0 = _ControllerStream()
    //     0xa03538: bl              #0x534e34  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x14)
    // 0xa0353c: ldur            x1, [fp, #-8]
    // 0xa03540: StoreField: r0->field_f = r1
    //     0xa03540: stur            w1, [x0, #0xf]
    // 0xa03544: LeaveFrame
    //     0xa03544: mov             SP, fp
    //     0xa03548: ldp             fp, lr, [SP], #0x10
    // 0xa0354c: ret
    //     0xa0354c: ret             
  }
  _ processResponse(/* No info */) {
    // ** addr: 0xa0c11c, size: 0x3fc
    // 0xa0c11c: EnterFrame
    //     0xa0c11c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0c120: mov             fp, SP
    // 0xa0c124: AllocStack(0x70)
    //     0xa0c124: sub             SP, SP, #0x70
    // 0xa0c128: CheckStackOverflow
    //     0xa0c128: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0c12c: cmp             SP, x16
    //     0xa0c130: b.ls            #0xa0c510
    // 0xa0c134: r16 = "[^\\x00-\\x7F]+"
    //     0xa0c134: add             x16, PP, #8, lsl #12  ; [pp+0x81f8] "[^\\x00-\\x7F]+"
    //     0xa0c138: ldr             x16, [x16, #0x1f8]
    // 0xa0c13c: stp             x16, NULL, [SP, #-0x10]!
    // 0xa0c140: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0c140: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0c144: r0 = RegExp()
    //     0xa0c144: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0xa0c148: add             SP, SP, #0x10
    // 0xa0c14c: ldr             x1, [fp, #0x10]
    // 0xa0c150: r2 = LoadClassIdInstr(r1)
    //     0xa0c150: ldur            x2, [x1, #-1]
    //     0xa0c154: ubfx            x2, x2, #0xc, #0x14
    // 0xa0c158: stp             x0, x1, [SP, #-0x10]!
    // 0xa0c15c: mov             x0, x2
    // 0xa0c160: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0c160: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0c164: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa0c164: sub             lr, x0, #0xffc
    //     0xa0c168: ldr             lr, [x21, lr, lsl #3]
    //     0xa0c16c: blr             lr
    // 0xa0c170: add             SP, SP, #0x10
    // 0xa0c174: tbnz            w0, #4, #0xa0c1a0
    // 0xa0c178: ldr             x16, [fp, #0x18]
    // 0xa0c17c: r30 = "Message contains non-ASCII characters"
    //     0xa0c17c: add             lr, PP, #8, lsl #12  ; [pp+0x8200] "Message contains non-ASCII characters"
    //     0xa0c180: ldr             lr, [lr, #0x200]
    // 0xa0c184: stp             lr, x16, [SP, #-0x10]!
    // 0xa0c188: r0 = _fail()
    //     0xa0c188: bl              #0xa0da8c  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_fail
    // 0xa0c18c: add             SP, SP, #0x10
    // 0xa0c190: r0 = Null
    //     0xa0c190: mov             x0, NULL
    // 0xa0c194: LeaveFrame
    //     0xa0c194: mov             SP, fp
    //     0xa0c198: ldp             fp, lr, [SP], #0x10
    // 0xa0c19c: ret
    //     0xa0c19c: ret             
    // 0xa0c1a0: ldr             x1, [fp, #0x10]
    // 0xa0c1a4: r0 = LoadClassIdInstr(r1)
    //     0xa0c1a4: ldur            x0, [x1, #-1]
    //     0xa0c1a8: ubfx            x0, x0, #0xc, #0x14
    // 0xa0c1ac: r16 = " "
    //     0xa0c1ac: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xa0c1b0: stp             x16, x1, [SP, #-0x10]!
    // 0xa0c1b4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0c1b4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0c1b8: r0 = GDT[cid_x0 + -0xff0]()
    //     0xa0c1b8: sub             lr, x0, #0xff0
    //     0xa0c1bc: ldr             lr, [x21, lr, lsl #3]
    //     0xa0c1c0: blr             lr
    // 0xa0c1c4: add             SP, SP, #0x10
    // 0xa0c1c8: mov             x2, x0
    // 0xa0c1cc: stur            x2, [fp, #-0x58]
    // 0xa0c1d0: tbnz            x2, #0x3f, #0xa0c22c
    // 0xa0c1d4: r0 = BoxInt64Instr(r2)
    //     0xa0c1d4: sbfiz           x0, x2, #1, #0x1f
    //     0xa0c1d8: cmp             x2, x0, asr #1
    //     0xa0c1dc: b.eq            #0xa0c1e8
    //     0xa0c1e0: bl              #0xd69bb8
    //     0xa0c1e4: stur            x2, [x0, #7]
    // 0xa0c1e8: ldr             x16, [fp, #0x10]
    // 0xa0c1ec: stp             xzr, x16, [SP, #-0x10]!
    // 0xa0c1f0: SaveReg r0
    //     0xa0c1f0: str             x0, [SP, #-8]!
    // 0xa0c1f4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa0c1f4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa0c1f8: r0 = substring()
    //     0xa0c1f8: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xa0c1fc: add             SP, SP, #0x18
    // 0xa0c200: mov             x1, x0
    // 0xa0c204: ldur            x0, [fp, #-0x58]
    // 0xa0c208: stur            x1, [fp, #-0x60]
    // 0xa0c20c: add             x2, x0, #1
    // 0xa0c210: ldr             x16, [fp, #0x10]
    // 0xa0c214: stp             x2, x16, [SP, #-0x10]!
    // 0xa0c218: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa0c218: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa0c21c: r0 = substring()
    //     0xa0c21c: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0xa0c220: add             SP, SP, #0x10
    // 0xa0c224: ldur            x1, [fp, #-0x60]
    // 0xa0c228: b               #0xa0c234
    // 0xa0c22c: ldr             x1, [fp, #0x10]
    // 0xa0c230: r0 = ""
    //     0xa0c230: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa0c234: stur            x1, [fp, #-0x60]
    // 0xa0c238: stur            x0, [fp, #-0x68]
    // 0xa0c23c: r16 = "REJECTED"
    //     0xa0c23c: add             x16, PP, #8, lsl #12  ; [pp+0x8208] "REJECTED"
    //     0xa0c240: ldr             x16, [x16, #0x208]
    // 0xa0c244: stp             x1, x16, [SP, #-0x10]!
    // 0xa0c248: r0 = ==()
    //     0xa0c248: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0c24c: add             SP, SP, #0x10
    // 0xa0c250: tbnz            w0, #4, #0xa0c2f8
    // 0xa0c254: ldr             x1, [fp, #0x18]
    // 0xa0c258: LoadField: r0 = r1->field_f
    //     0xa0c258: ldur            w0, [x1, #0xf]
    // 0xa0c25c: DecompressPointer r0
    //     0xa0c25c: add             x0, x0, HEAP, lsl #32
    // 0xa0c260: tbz             w0, #4, #0xa0c2dc
    // 0xa0c264: ldur            x0, [fp, #-0x68]
    // 0xa0c268: r2 = LoadClassIdInstr(r0)
    //     0xa0c268: ldur            x2, [x0, #-1]
    //     0xa0c26c: ubfx            x2, x2, #0xc, #0x14
    // 0xa0c270: r16 = " "
    //     0xa0c270: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xa0c274: stp             x16, x0, [SP, #-0x10]!
    // 0xa0c278: mov             x0, x2
    // 0xa0c27c: r0 = GDT[cid_x0 + -0xff8]()
    //     0xa0c27c: sub             lr, x0, #0xff8
    //     0xa0c280: ldr             lr, [x21, lr, lsl #3]
    //     0xa0c284: blr             lr
    // 0xa0c288: add             SP, SP, #0x10
    // 0xa0c28c: r16 = "EXTERNAL"
    //     0xa0c28c: add             x16, PP, #8, lsl #12  ; [pp+0x8210] "EXTERNAL"
    //     0xa0c290: ldr             x16, [x16, #0x210]
    // 0xa0c294: stp             x16, x0, [SP, #-0x10]!
    // 0xa0c298: r0 = contains()
    //     0xa0c298: bl              #0x786724  ; [dart:collection] _ListBase&Object&ListMixin::contains
    // 0xa0c29c: add             SP, SP, #0x10
    // 0xa0c2a0: tbnz            w0, #4, #0xa0c2c0
    // 0xa0c2a4: ldr             x1, [fp, #0x18]
    // 0xa0c2a8: r2 = true
    //     0xa0c2a8: add             x2, NULL, #0x20  ; true
    // 0xa0c2ac: StoreField: r1->field_f = r2
    //     0xa0c2ac: stur            w2, [x1, #0xf]
    // 0xa0c2b0: SaveReg r1
    //     0xa0c2b0: str             x1, [SP, #-8]!
    // 0xa0c2b4: r0 = _authenticateExternal()
    //     0xa0c2b4: bl              #0xa0c794  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_authenticateExternal
    // 0xa0c2b8: add             SP, SP, #8
    // 0xa0c2bc: b               #0xa0c46c
    // 0xa0c2c0: ldr             x1, [fp, #0x18]
    // 0xa0c2c4: r16 = "No supported mechanism"
    //     0xa0c2c4: add             x16, PP, #8, lsl #12  ; [pp+0x8218] "No supported mechanism"
    //     0xa0c2c8: ldr             x16, [x16, #0x218]
    // 0xa0c2cc: stp             x16, x1, [SP, #-0x10]!
    // 0xa0c2d0: r0 = _fail()
    //     0xa0c2d0: bl              #0xa0da8c  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_fail
    // 0xa0c2d4: add             SP, SP, #0x10
    // 0xa0c2d8: b               #0xa0c46c
    // 0xa0c2dc: LoadField: r0 = r1->field_7
    //     0xa0c2dc: ldur            w0, [x1, #7]
    // 0xa0c2e0: DecompressPointer r0
    //     0xa0c2e0: add             x0, x0, HEAP, lsl #32
    // 0xa0c2e4: SaveReg r0
    //     0xa0c2e4: str             x0, [SP, #-8]!
    // 0xa0c2e8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0c2e8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0c2ec: r0 = complete()
    //     0xa0c2ec: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0xa0c2f0: add             SP, SP, #8
    // 0xa0c2f4: b               #0xa0c46c
    // 0xa0c2f8: ldr             x1, [fp, #0x18]
    // 0xa0c2fc: ldur            x0, [fp, #-0x68]
    // 0xa0c300: r2 = true
    //     0xa0c300: add             x2, NULL, #0x20  ; true
    // 0xa0c304: r16 = "OK"
    //     0xa0c304: add             x16, PP, #8, lsl #12  ; [pp+0x8220] "OK"
    //     0xa0c308: ldr             x16, [x16, #0x220]
    // 0xa0c30c: ldur            lr, [fp, #-0x60]
    // 0xa0c310: stp             lr, x16, [SP, #-0x10]!
    // 0xa0c314: r0 = ==()
    //     0xa0c314: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0c318: add             SP, SP, #0x10
    // 0xa0c31c: tbnz            w0, #4, #0xa0c35c
    // 0xa0c320: r0 = DBusUUID()
    //     0xa0c320: bl              #0xa0c788  ; AllocateDBusUUIDStub -> DBusUUID (size=0xc)
    // 0xa0c324: stur            x0, [fp, #-0x70]
    // 0xa0c328: ldur            x16, [fp, #-0x68]
    // 0xa0c32c: stp             x16, x0, [SP, #-0x10]!
    // 0xa0c330: r0 = DBusUUID.fromHexString()
    //     0xa0c330: bl              #0xa0c5c0  ; [package:dbus/src/dbus_uuid.dart] DBusUUID::DBusUUID.fromHexString
    // 0xa0c334: add             SP, SP, #0x10
    // 0xa0c338: ldr             x0, [fp, #0x18]
    // 0xa0c33c: r1 = true
    //     0xa0c33c: add             x1, NULL, #0x20  ; true
    // 0xa0c340: StoreField: r0->field_13 = r1
    //     0xa0c340: stur            w1, [x0, #0x13]
    // 0xa0c344: r16 = "NEGOTIATE_UNIX_FD"
    //     0xa0c344: add             x16, PP, #8, lsl #12  ; [pp+0x8228] "NEGOTIATE_UNIX_FD"
    //     0xa0c348: ldr             x16, [x16, #0x228]
    // 0xa0c34c: stp             x16, x0, [SP, #-0x10]!
    // 0xa0c350: r0 = _send()
    //     0xa0c350: bl              #0xa0c578  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_send
    // 0xa0c354: add             SP, SP, #0x10
    // 0xa0c358: b               #0xa0c46c
    // 0xa0c35c: ldr             x0, [fp, #0x18]
    // 0xa0c360: r16 = "DATA"
    //     0xa0c360: add             x16, PP, #8, lsl #12  ; [pp+0x8230] "DATA"
    //     0xa0c364: ldr             x16, [x16, #0x230]
    // 0xa0c368: ldur            lr, [fp, #-0x60]
    // 0xa0c36c: stp             lr, x16, [SP, #-0x10]!
    // 0xa0c370: r0 = ==()
    //     0xa0c370: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0c374: add             SP, SP, #0x10
    // 0xa0c378: tbnz            w0, #4, #0xa0c398
    // 0xa0c37c: ldr             x16, [fp, #0x18]
    // 0xa0c380: r30 = "Unable to handle DATA command"
    //     0xa0c380: add             lr, PP, #8, lsl #12  ; [pp+0x8238] "Unable to handle DATA command"
    //     0xa0c384: ldr             lr, [lr, #0x238]
    // 0xa0c388: stp             lr, x16, [SP, #-0x10]!
    // 0xa0c38c: r0 = _fail()
    //     0xa0c38c: bl              #0xa0da8c  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_fail
    // 0xa0c390: add             SP, SP, #0x10
    // 0xa0c394: b               #0xa0c46c
    // 0xa0c398: r16 = "ERROR"
    //     0xa0c398: add             x16, PP, #8, lsl #12  ; [pp+0x8240] "ERROR"
    //     0xa0c39c: ldr             x16, [x16, #0x240]
    // 0xa0c3a0: ldur            lr, [fp, #-0x60]
    // 0xa0c3a4: stp             lr, x16, [SP, #-0x10]!
    // 0xa0c3a8: r0 = ==()
    //     0xa0c3a8: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0c3ac: add             SP, SP, #0x10
    // 0xa0c3b0: tbnz            w0, #4, #0xa0c3f0
    // 0xa0c3b4: ldr             x0, [fp, #0x18]
    // 0xa0c3b8: LoadField: r1 = r0->field_13
    //     0xa0c3b8: ldur            w1, [x0, #0x13]
    // 0xa0c3bc: DecompressPointer r1
    //     0xa0c3bc: add             x1, x1, HEAP, lsl #32
    // 0xa0c3c0: tbnz            w1, #4, #0xa0c3d4
    // 0xa0c3c4: SaveReg r0
    //     0xa0c3c4: str             x0, [SP, #-8]!
    // 0xa0c3c8: r0 = _begin()
    //     0xa0c3c8: bl              #0xa0c518  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_begin
    // 0xa0c3cc: add             SP, SP, #8
    // 0xa0c3d0: b               #0xa0c46c
    // 0xa0c3d4: LoadField: r1 = r0->field_7
    //     0xa0c3d4: ldur            w1, [x0, #7]
    // 0xa0c3d8: DecompressPointer r1
    //     0xa0c3d8: add             x1, x1, HEAP, lsl #32
    // 0xa0c3dc: SaveReg r1
    //     0xa0c3dc: str             x1, [SP, #-8]!
    // 0xa0c3e0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0c3e0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0c3e4: r0 = complete()
    //     0xa0c3e4: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0xa0c3e8: add             SP, SP, #8
    // 0xa0c3ec: b               #0xa0c46c
    // 0xa0c3f0: ldr             x0, [fp, #0x18]
    // 0xa0c3f4: r16 = "AGREE_UNIX_FD"
    //     0xa0c3f4: add             x16, PP, #8, lsl #12  ; [pp+0x8248] "AGREE_UNIX_FD"
    //     0xa0c3f8: ldr             x16, [x16, #0x248]
    // 0xa0c3fc: ldur            lr, [fp, #-0x60]
    // 0xa0c400: stp             lr, x16, [SP, #-0x10]!
    // 0xa0c404: r0 = ==()
    //     0xa0c404: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xa0c408: add             SP, SP, #0x10
    // 0xa0c40c: tbnz            w0, #4, #0xa0c424
    // 0xa0c410: ldr             x16, [fp, #0x18]
    // 0xa0c414: SaveReg r16
    //     0xa0c414: str             x16, [SP, #-8]!
    // 0xa0c418: r0 = _begin()
    //     0xa0c418: bl              #0xa0c518  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_begin
    // 0xa0c41c: add             SP, SP, #8
    // 0xa0c420: b               #0xa0c46c
    // 0xa0c424: ldur            x0, [fp, #-0x60]
    // 0xa0c428: r1 = Null
    //     0xa0c428: mov             x1, NULL
    // 0xa0c42c: r2 = 6
    //     0xa0c42c: mov             x2, #6
    // 0xa0c430: r0 = AllocateArray()
    //     0xa0c430: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0c434: r17 = "Unknown command \'"
    //     0xa0c434: add             x17, PP, #8, lsl #12  ; [pp+0x8250] "Unknown command \'"
    //     0xa0c438: ldr             x17, [x17, #0x250]
    // 0xa0c43c: StoreField: r0->field_f = r17
    //     0xa0c43c: stur            w17, [x0, #0xf]
    // 0xa0c440: ldur            x1, [fp, #-0x60]
    // 0xa0c444: StoreField: r0->field_13 = r1
    //     0xa0c444: stur            w1, [x0, #0x13]
    // 0xa0c448: r17 = "\'"
    //     0xa0c448: ldr             x17, [PP, #0x9c8]  ; [pp+0x9c8] "\'"
    // 0xa0c44c: StoreField: r0->field_17 = r17
    //     0xa0c44c: stur            w17, [x0, #0x17]
    // 0xa0c450: SaveReg r0
    //     0xa0c450: str             x0, [SP, #-8]!
    // 0xa0c454: r0 = _interpolate()
    //     0xa0c454: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0c458: add             SP, SP, #8
    // 0xa0c45c: ldr             x16, [fp, #0x18]
    // 0xa0c460: stp             x0, x16, [SP, #-0x10]!
    // 0xa0c464: r0 = _fail()
    //     0xa0c464: bl              #0xa0da8c  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_fail
    // 0xa0c468: add             SP, SP, #0x10
    // 0xa0c46c: r0 = Null
    //     0xa0c46c: mov             x0, NULL
    // 0xa0c470: LeaveFrame
    //     0xa0c470: mov             SP, fp
    //     0xa0c474: ldp             fp, lr, [SP], #0x10
    // 0xa0c478: ret
    //     0xa0c478: ret             
    // 0xa0c47c: sub             SP, fp, #0x70
    // 0xa0c480: mov             x4, x0
    // 0xa0c484: mov             x3, x1
    // 0xa0c488: stur            x0, [fp, #-0x60]
    // 0xa0c48c: stur            x1, [fp, #-0x68]
    // 0xa0c490: r2 = Null
    //     0xa0c490: mov             x2, NULL
    // 0xa0c494: r1 = Null
    //     0xa0c494: mov             x1, NULL
    // 0xa0c498: cmp             w0, NULL
    // 0xa0c49c: b.eq            #0xa0c4c8
    // 0xa0c4a0: branchIfSmi(r0, 0xa0c4c8)
    //     0xa0c4a0: tbz             w0, #0, #0xa0c4c8
    // 0xa0c4a4: r3 = LoadClassIdInstr(r0)
    //     0xa0c4a4: ldur            x3, [x0, #-1]
    //     0xa0c4a8: ubfx            x3, x3, #0xc, #0x14
    // 0xa0c4ac: sub             x3, x3, #0x49f
    // 0xa0c4b0: cmp             x3, #1
    // 0xa0c4b4: b.ls            #0xa0c4d0
    // 0xa0c4b8: r17 = -4518
    //     0xa0c4b8: mov             x17, #-0x11a6
    // 0xa0c4bc: add             x3, x3, x17
    // 0xa0c4c0: cmp             x3, #1
    // 0xa0c4c4: b.ls            #0xa0c4d0
    // 0xa0c4c8: r0 = false
    //     0xa0c4c8: add             x0, NULL, #0x30  ; false
    // 0xa0c4cc: b               #0xa0c4d4
    // 0xa0c4d0: r0 = true
    //     0xa0c4d0: add             x0, NULL, #0x20  ; true
    // 0xa0c4d4: tbnz            w0, #4, #0xa0c500
    // 0xa0c4d8: ldr             x16, [fp, #0x18]
    // 0xa0c4dc: r30 = "Invalid UUID in OK"
    //     0xa0c4dc: add             lr, PP, #8, lsl #12  ; [pp+0x8258] "Invalid UUID in OK"
    //     0xa0c4e0: ldr             lr, [lr, #0x258]
    // 0xa0c4e4: stp             lr, x16, [SP, #-0x10]!
    // 0xa0c4e8: r0 = _fail()
    //     0xa0c4e8: bl              #0xa0da8c  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_fail
    // 0xa0c4ec: add             SP, SP, #0x10
    // 0xa0c4f0: r0 = Null
    //     0xa0c4f0: mov             x0, NULL
    // 0xa0c4f4: LeaveFrame
    //     0xa0c4f4: mov             SP, fp
    //     0xa0c4f8: ldp             fp, lr, [SP], #0x10
    // 0xa0c4fc: ret
    //     0xa0c4fc: ret             
    // 0xa0c500: ldur            x0, [fp, #-0x60]
    // 0xa0c504: ldur            x1, [fp, #-0x68]
    // 0xa0c508: r0 = ReThrow()
    //     0xa0c508: bl              #0xd67e14  ; ReThrowStub
    // 0xa0c50c: brk             #0
    // 0xa0c510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0c510: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0c514: b               #0xa0c134
  }
  _ _begin(/* No info */) {
    // ** addr: 0xa0c518, size: 0x60
    // 0xa0c518: EnterFrame
    //     0xa0c518: stp             fp, lr, [SP, #-0x10]!
    //     0xa0c51c: mov             fp, SP
    // 0xa0c520: CheckStackOverflow
    //     0xa0c520: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0c524: cmp             SP, x16
    //     0xa0c528: b.ls            #0xa0c570
    // 0xa0c52c: ldr             x16, [fp, #0x10]
    // 0xa0c530: r30 = "BEGIN"
    //     0xa0c530: add             lr, PP, #8, lsl #12  ; [pp+0x8260] "BEGIN"
    //     0xa0c534: ldr             lr, [lr, #0x260]
    // 0xa0c538: stp             lr, x16, [SP, #-0x10]!
    // 0xa0c53c: r0 = _send()
    //     0xa0c53c: bl              #0xa0c578  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_send
    // 0xa0c540: add             SP, SP, #0x10
    // 0xa0c544: ldr             x0, [fp, #0x10]
    // 0xa0c548: LoadField: r1 = r0->field_7
    //     0xa0c548: ldur            w1, [x0, #7]
    // 0xa0c54c: DecompressPointer r1
    //     0xa0c54c: add             x1, x1, HEAP, lsl #32
    // 0xa0c550: SaveReg r1
    //     0xa0c550: str             x1, [SP, #-8]!
    // 0xa0c554: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0c554: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0c558: r0 = complete()
    //     0xa0c558: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0xa0c55c: add             SP, SP, #8
    // 0xa0c560: r0 = Null
    //     0xa0c560: mov             x0, NULL
    // 0xa0c564: LeaveFrame
    //     0xa0c564: mov             SP, fp
    //     0xa0c568: ldp             fp, lr, [SP], #0x10
    // 0xa0c56c: ret
    //     0xa0c56c: ret             
    // 0xa0c570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0c570: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0c574: b               #0xa0c52c
  }
  _ _send(/* No info */) {
    // ** addr: 0xa0c578, size: 0x48
    // 0xa0c578: EnterFrame
    //     0xa0c578: stp             fp, lr, [SP, #-0x10]!
    //     0xa0c57c: mov             fp, SP
    // 0xa0c580: CheckStackOverflow
    //     0xa0c580: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0c584: cmp             SP, x16
    //     0xa0c588: b.ls            #0xa0c5b8
    // 0xa0c58c: ldr             x0, [fp, #0x18]
    // 0xa0c590: LoadField: r1 = r0->field_b
    //     0xa0c590: ldur            w1, [x0, #0xb]
    // 0xa0c594: DecompressPointer r1
    //     0xa0c594: add             x1, x1, HEAP, lsl #32
    // 0xa0c598: ldr             x16, [fp, #0x10]
    // 0xa0c59c: stp             x16, x1, [SP, #-0x10]!
    // 0xa0c5a0: r0 = add()
    //     0xa0c5a0: bl              #0xc23290  ; [dart:async] _StreamController::add
    // 0xa0c5a4: add             SP, SP, #0x10
    // 0xa0c5a8: r0 = Null
    //     0xa0c5a8: mov             x0, NULL
    // 0xa0c5ac: LeaveFrame
    //     0xa0c5ac: mov             SP, fp
    //     0xa0c5b0: ldp             fp, lr, [SP], #0x10
    // 0xa0c5b4: ret
    //     0xa0c5b4: ret             
    // 0xa0c5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0c5b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0c5bc: b               #0xa0c58c
  }
  _ _authenticateExternal(/* No info */) {
    // ** addr: 0xa0c794, size: 0x210
    // 0xa0c794: EnterFrame
    //     0xa0c794: stp             fp, lr, [SP, #-0x10]!
    //     0xa0c798: mov             fp, SP
    // 0xa0c79c: AllocStack(0x10)
    //     0xa0c79c: sub             SP, SP, #0x10
    // 0xa0c7a0: CheckStackOverflow
    //     0xa0c7a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0c7a4: cmp             SP, x16
    //     0xa0c7a8: b.ls            #0xa0c994
    // 0xa0c7ac: r0 = InitLateStaticField(0x68c) // [dart:io] Platform::isLinux
    //     0xa0c7ac: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0c7b0: ldr             x0, [x0, #0xd18]
    //     0xa0c7b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0c7b8: cmp             w0, w16
    //     0xa0c7bc: b.ne            #0xa0c7c8
    //     0xa0c7c0: ldr             x2, [PP, #0x70]  ; [pp+0x70] Field <Platform.isLinux>: static late final (offset: 0x68c)
    //     0xa0c7c4: bl              #0xd67cdc
    // 0xa0c7c8: tbnz            w0, #4, #0xa0c81c
    // 0xa0c7cc: r0 = getuid()
    //     0xa0c7cc: bl              #0xa0d8cc  ; [package:dbus/src/getuid_linux.dart] ::getuid
    // 0xa0c7d0: mov             x2, x0
    // 0xa0c7d4: r0 = BoxInt64Instr(r2)
    //     0xa0c7d4: sbfiz           x0, x2, #1, #0x1f
    //     0xa0c7d8: cmp             x2, x0, asr #1
    //     0xa0c7dc: b.eq            #0xa0c7e8
    //     0xa0c7e0: bl              #0xd69bb8
    //     0xa0c7e4: stur            x2, [x0, #7]
    // 0xa0c7e8: r1 = 59
    //     0xa0c7e8: mov             x1, #0x3b
    // 0xa0c7ec: branchIfSmi(r0, 0xa0c7f8)
    //     0xa0c7ec: tbz             w0, #0, #0xa0c7f8
    // 0xa0c7f0: r1 = LoadClassIdInstr(r0)
    //     0xa0c7f0: ldur            x1, [x0, #-1]
    //     0xa0c7f4: ubfx            x1, x1, #0xc, #0x14
    // 0xa0c7f8: SaveReg r0
    //     0xa0c7f8: str             x0, [SP, #-8]!
    // 0xa0c7fc: mov             x0, x1
    // 0xa0c800: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0c800: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0c804: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xa0c804: mov             x17, #0x3f73
    //     0xa0c808: add             lr, x0, x17
    //     0xa0c80c: ldr             lr, [x21, lr, lsl #3]
    //     0xa0c810: blr             lr
    // 0xa0c814: add             SP, SP, #8
    // 0xa0c818: b               #0xa0c840
    // 0xa0c81c: r0 = InitLateStaticField(0x694) // [dart:io] Platform::isWindows
    //     0xa0c81c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0c820: ldr             x0, [x0, #0xd28]
    //     0xa0c824: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0c828: cmp             w0, w16
    //     0xa0c82c: b.ne            #0xa0c838
    //     0xa0c830: ldr             x2, [PP, #0x80]  ; [pp+0x80] Field <Platform.isWindows>: static late final (offset: 0x694)
    //     0xa0c834: bl              #0xd67cdc
    // 0xa0c838: tbnz            w0, #4, #0xa0c93c
    // 0xa0c83c: r0 = getsid()
    //     0xa0c83c: bl              #0xa0c9d4  ; [package:dbus/src/getsid_windows.dart] ::getsid
    // 0xa0c840: stur            x0, [fp, #-8]
    // 0xa0c844: r1 = <int>
    //     0xa0c844: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xa0c848: r0 = Runes()
    //     0xa0c848: bl              #0xa0c9c8  ; AllocateRunesStub -> Runes (size=0x10)
    // 0xa0c84c: mov             x1, x0
    // 0xa0c850: ldur            x0, [fp, #-8]
    // 0xa0c854: StoreField: r1->field_b = r0
    //     0xa0c854: stur            w0, [x1, #0xb]
    // 0xa0c858: SaveReg r1
    //     0xa0c858: str             x1, [SP, #-8]!
    // 0xa0c85c: r0 = iterator()
    //     0xa0c85c: bl              #0x6fc2ac  ; [dart:core] Runes::iterator
    // 0xa0c860: add             SP, SP, #8
    // 0xa0c864: stur            x0, [fp, #-0x10]
    // 0xa0c868: r1 = ""
    //     0xa0c868: ldr             x1, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa0c86c: stur            x1, [fp, #-8]
    // 0xa0c870: CheckStackOverflow
    //     0xa0c870: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0c874: cmp             SP, x16
    //     0xa0c878: b.ls            #0xa0c99c
    // 0xa0c87c: SaveReg r0
    //     0xa0c87c: str             x0, [SP, #-8]!
    // 0xa0c880: r0 = moveNext()
    //     0xa0c880: bl              #0xc38288  ; [dart:core] RuneIterator::moveNext
    // 0xa0c884: add             SP, SP, #8
    // 0xa0c888: tbnz            w0, #4, #0xa0c8ec
    // 0xa0c88c: ldur            x2, [fp, #-0x10]
    // 0xa0c890: r3 = 16
    //     0xa0c890: mov             x3, #0x10
    // 0xa0c894: LoadField: r4 = r2->field_1b
    //     0xa0c894: ldur            x4, [x2, #0x1b]
    // 0xa0c898: r0 = BoxInt64Instr(r4)
    //     0xa0c898: sbfiz           x0, x4, #1, #0x1f
    //     0xa0c89c: cmp             x4, x0, asr #1
    //     0xa0c8a0: b.eq            #0xa0c8ac
    //     0xa0c8a4: bl              #0xd69bb8
    //     0xa0c8a8: stur            x4, [x0, #7]
    // 0xa0c8ac: stp             x3, x0, [SP, #-0x10]!
    // 0xa0c8b0: r0 = _toPow2String()
    //     0xa0c8b0: bl              #0x506b60  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0xa0c8b4: add             SP, SP, #0x10
    // 0xa0c8b8: SaveReg r0
    //     0xa0c8b8: str             x0, [SP, #-8]!
    // 0xa0c8bc: r0 = 2
    //     0xa0c8bc: mov             x0, #2
    // 0xa0c8c0: r16 = "0"
    //     0xa0c8c0: ldr             x16, [PP, #0x3af8]  ; [pp+0x3af8] "0"
    // 0xa0c8c4: stp             x16, x0, [SP, #-0x10]!
    // 0xa0c8c8: r0 = padLeft()
    //     0xa0c8c8: bl              #0xd65600  ; [dart:core] _OneByteString::padLeft
    // 0xa0c8cc: add             SP, SP, #0x18
    // 0xa0c8d0: ldur            x16, [fp, #-8]
    // 0xa0c8d4: stp             x0, x16, [SP, #-0x10]!
    // 0xa0c8d8: r0 = +()
    //     0xa0c8d8: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0xa0c8dc: add             SP, SP, #0x10
    // 0xa0c8e0: mov             x1, x0
    // 0xa0c8e4: ldur            x0, [fp, #-0x10]
    // 0xa0c8e8: b               #0xa0c86c
    // 0xa0c8ec: ldur            x0, [fp, #-8]
    // 0xa0c8f0: r1 = Null
    //     0xa0c8f0: mov             x1, NULL
    // 0xa0c8f4: r2 = 4
    //     0xa0c8f4: mov             x2, #4
    // 0xa0c8f8: r0 = AllocateArray()
    //     0xa0c8f8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0c8fc: r17 = "AUTH EXTERNAL "
    //     0xa0c8fc: add             x17, PP, #8, lsl #12  ; [pp+0x8278] "AUTH EXTERNAL "
    //     0xa0c900: ldr             x17, [x17, #0x278]
    // 0xa0c904: StoreField: r0->field_f = r17
    //     0xa0c904: stur            w17, [x0, #0xf]
    // 0xa0c908: ldur            x1, [fp, #-8]
    // 0xa0c90c: StoreField: r0->field_13 = r1
    //     0xa0c90c: stur            w1, [x0, #0x13]
    // 0xa0c910: SaveReg r0
    //     0xa0c910: str             x0, [SP, #-8]!
    // 0xa0c914: r0 = _interpolate()
    //     0xa0c914: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0c918: add             SP, SP, #8
    // 0xa0c91c: ldr             x16, [fp, #0x10]
    // 0xa0c920: stp             x0, x16, [SP, #-0x10]!
    // 0xa0c924: r0 = _send()
    //     0xa0c924: bl              #0xa0c578  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_send
    // 0xa0c928: add             SP, SP, #0x10
    // 0xa0c92c: r0 = Null
    //     0xa0c92c: mov             x0, NULL
    // 0xa0c930: LeaveFrame
    //     0xa0c930: mov             SP, fp
    //     0xa0c934: ldp             fp, lr, [SP], #0x10
    // 0xa0c938: ret
    //     0xa0c938: ret             
    // 0xa0c93c: r1 = Null
    //     0xa0c93c: mov             x1, NULL
    // 0xa0c940: r2 = 4
    //     0xa0c940: mov             x2, #4
    // 0xa0c944: r0 = AllocateArray()
    //     0xa0c944: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0c948: stur            x0, [fp, #-8]
    // 0xa0c94c: r17 = "Authentication not supported on "
    //     0xa0c94c: add             x17, PP, #8, lsl #12  ; [pp+0x8280] "Authentication not supported on "
    //     0xa0c950: ldr             x17, [x17, #0x280]
    // 0xa0c954: StoreField: r0->field_f = r17
    //     0xa0c954: stur            w17, [x0, #0xf]
    // 0xa0c958: r0 = InitLateStaticField(0x67c) // [dart:io] Platform::_operatingSystem
    //     0xa0c958: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0c95c: ldr             x0, [x0, #0xcf8]
    //     0xa0c960: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa0c964: cmp             w0, w16
    //     0xa0c968: b.ne            #0xa0c974
    //     0xa0c96c: ldr             x2, [PP, #0x1400]  ; [pp+0x1400] Field <Platform._operatingSystem@14069316>: static late final (offset: 0x67c)
    //     0xa0c970: bl              #0xd67cdc
    // 0xa0c974: mov             x1, x0
    // 0xa0c978: ldur            x0, [fp, #-8]
    // 0xa0c97c: StoreField: r0->field_13 = r1
    //     0xa0c97c: stur            w1, [x0, #0x13]
    // 0xa0c980: SaveReg r0
    //     0xa0c980: str             x0, [SP, #-8]!
    // 0xa0c984: r0 = _interpolate()
    //     0xa0c984: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0c988: add             SP, SP, #8
    // 0xa0c98c: r0 = Throw()
    //     0xa0c98c: bl              #0xd67e38  ; ThrowStub
    // 0xa0c990: brk             #0
    // 0xa0c994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0c994: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0c998: b               #0xa0c7ac
    // 0xa0c99c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0c99c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0c9a0: b               #0xa0c87c
  }
  _ _fail(/* No info */) {
    // ** addr: 0xa0da8c, size: 0x84
    // 0xa0da8c: EnterFrame
    //     0xa0da8c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0da90: mov             fp, SP
    // 0xa0da94: CheckStackOverflow
    //     0xa0da94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0da98: cmp             SP, x16
    //     0xa0da9c: b.ls            #0xa0db08
    // 0xa0daa0: r1 = Null
    //     0xa0daa0: mov             x1, NULL
    // 0xa0daa4: r2 = 4
    //     0xa0daa4: mov             x2, #4
    // 0xa0daa8: r0 = AllocateArray()
    //     0xa0daa8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0daac: r17 = "ERROR "
    //     0xa0daac: add             x17, PP, #8, lsl #12  ; [pp+0x83c8] "ERROR "
    //     0xa0dab0: ldr             x17, [x17, #0x3c8]
    // 0xa0dab4: StoreField: r0->field_f = r17
    //     0xa0dab4: stur            w17, [x0, #0xf]
    // 0xa0dab8: ldr             x1, [fp, #0x10]
    // 0xa0dabc: StoreField: r0->field_13 = r1
    //     0xa0dabc: stur            w1, [x0, #0x13]
    // 0xa0dac0: SaveReg r0
    //     0xa0dac0: str             x0, [SP, #-8]!
    // 0xa0dac4: r0 = _interpolate()
    //     0xa0dac4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0dac8: add             SP, SP, #8
    // 0xa0dacc: ldr             x16, [fp, #0x18]
    // 0xa0dad0: stp             x0, x16, [SP, #-0x10]!
    // 0xa0dad4: r0 = _send()
    //     0xa0dad4: bl              #0xa0c578  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_send
    // 0xa0dad8: add             SP, SP, #0x10
    // 0xa0dadc: ldr             x0, [fp, #0x18]
    // 0xa0dae0: LoadField: r1 = r0->field_7
    //     0xa0dae0: ldur            w1, [x0, #7]
    // 0xa0dae4: DecompressPointer r1
    //     0xa0dae4: add             x1, x1, HEAP, lsl #32
    // 0xa0dae8: SaveReg r1
    //     0xa0dae8: str             x1, [SP, #-8]!
    // 0xa0daec: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0daec: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0daf0: r0 = complete()
    //     0xa0daf0: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0xa0daf4: add             SP, SP, #8
    // 0xa0daf8: r0 = Null
    //     0xa0daf8: mov             x0, NULL
    // 0xa0dafc: LeaveFrame
    //     0xa0dafc: mov             SP, fp
    //     0xa0db00: ldp             fp, lr, [SP], #0x10
    // 0xa0db04: ret
    //     0xa0db04: ret             
    // 0xa0db08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0db08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0db0c: b               #0xa0daa0
  }
  _ DBusAuthClient(/* No info */) {
    // ** addr: 0xd6ed0c, size: 0x140
    // 0xd6ed0c: EnterFrame
    //     0xd6ed0c: stp             fp, lr, [SP, #-0x10]!
    //     0xd6ed10: mov             fp, SP
    // 0xd6ed14: AllocStack(0x10)
    //     0xd6ed14: sub             SP, SP, #0x10
    // 0xd6ed18: CheckStackOverflow
    //     0xd6ed18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6ed1c: cmp             SP, x16
    //     0xd6ed20: b.ls            #0xd6ee44
    // 0xd6ed24: r1 = 1
    //     0xd6ed24: mov             x1, #1
    // 0xd6ed28: r0 = AllocateContext()
    //     0xd6ed28: bl              #0xd68aa4  ; AllocateContextStub
    // 0xd6ed2c: mov             x2, x0
    // 0xd6ed30: ldr             x0, [fp, #0x10]
    // 0xd6ed34: stur            x2, [fp, #-8]
    // 0xd6ed38: StoreField: r2->field_f = r0
    //     0xd6ed38: stur            w0, [x2, #0xf]
    // 0xd6ed3c: r1 = false
    //     0xd6ed3c: add             x1, NULL, #0x30  ; false
    // 0xd6ed40: StoreField: r0->field_f = r1
    //     0xd6ed40: stur            w1, [x0, #0xf]
    // 0xd6ed44: StoreField: r0->field_13 = r1
    //     0xd6ed44: stur            w1, [x0, #0x13]
    // 0xd6ed48: r1 = Null
    //     0xd6ed48: mov             x1, NULL
    // 0xd6ed4c: r0 = _Future()
    //     0xd6ed4c: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xd6ed50: mov             x1, x0
    // 0xd6ed54: r0 = 0
    //     0xd6ed54: mov             x0, #0
    // 0xd6ed58: stur            x1, [fp, #-0x10]
    // 0xd6ed5c: StoreField: r1->field_b = r0
    //     0xd6ed5c: stur            x0, [x1, #0xb]
    // 0xd6ed60: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xd6ed60: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6ed64: ldr             x0, [x0, #0xb58]
    //     0xd6ed68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6ed6c: cmp             w0, w16
    //     0xd6ed70: b.ne            #0xd6ed7c
    //     0xd6ed74: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xd6ed78: bl              #0xd67d44
    // 0xd6ed7c: mov             x1, x0
    // 0xd6ed80: ldur            x0, [fp, #-0x10]
    // 0xd6ed84: StoreField: r0->field_13 = r1
    //     0xd6ed84: stur            w1, [x0, #0x13]
    // 0xd6ed88: r1 = Null
    //     0xd6ed88: mov             x1, NULL
    // 0xd6ed8c: r0 = _AsyncCompleter()
    //     0xd6ed8c: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xd6ed90: mov             x1, x0
    // 0xd6ed94: ldur            x0, [fp, #-0x10]
    // 0xd6ed98: StoreField: r1->field_b = r0
    //     0xd6ed98: stur            w0, [x1, #0xb]
    // 0xd6ed9c: mov             x0, x1
    // 0xd6eda0: ldr             x1, [fp, #0x10]
    // 0xd6eda4: StoreField: r1->field_7 = r0
    //     0xd6eda4: stur            w0, [x1, #7]
    //     0xd6eda8: ldurb           w16, [x1, #-1]
    //     0xd6edac: ldurb           w17, [x0, #-1]
    //     0xd6edb0: and             x16, x17, x16, lsr #2
    //     0xd6edb4: tst             x16, HEAP, lsr #32
    //     0xd6edb8: b.eq            #0xd6edc0
    //     0xd6edbc: bl              #0xd6826c
    // 0xd6edc0: r16 = <String>
    //     0xd6edc0: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xd6edc4: SaveReg r16
    //     0xd6edc4: str             x16, [SP, #-8]!
    // 0xd6edc8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xd6edc8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xd6edcc: r0 = StreamController()
    //     0xd6edcc: bl              #0x534f54  ; [dart:async] StreamController::StreamController
    // 0xd6edd0: add             SP, SP, #8
    // 0xd6edd4: mov             x3, x0
    // 0xd6edd8: ldr             x1, [fp, #0x10]
    // 0xd6eddc: stur            x3, [fp, #-0x10]
    // 0xd6ede0: StoreField: r1->field_b = r0
    //     0xd6ede0: stur            w0, [x1, #0xb]
    //     0xd6ede4: tbz             w0, #0, #0xd6ee00
    //     0xd6ede8: ldurb           w16, [x1, #-1]
    //     0xd6edec: ldurb           w17, [x0, #-1]
    //     0xd6edf0: and             x16, x17, x16, lsr #2
    //     0xd6edf4: tst             x16, HEAP, lsr #32
    //     0xd6edf8: b.eq            #0xd6ee00
    //     0xd6edfc: bl              #0xd6826c
    // 0xd6ee00: r0 = true
    //     0xd6ee00: add             x0, NULL, #0x20  ; true
    // 0xd6ee04: StoreField: r1->field_17 = r0
    //     0xd6ee04: stur            w0, [x1, #0x17]
    // 0xd6ee08: ldur            x2, [fp, #-8]
    // 0xd6ee0c: r1 = Function '<anonymous closure>':.
    //     0xd6ee0c: ldr             x1, [PP, #0x7e0]  ; [pp+0x7e0] AnonymousClosure: (0xd6ee4c), in [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::DBusAuthClient (0xd6ed0c)
    // 0xd6ee10: r0 = AllocateClosure()
    //     0xd6ee10: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xd6ee14: ldur            x1, [fp, #-0x10]
    // 0xd6ee18: StoreField: r1->field_1b = r0
    //     0xd6ee18: stur            w0, [x1, #0x1b]
    //     0xd6ee1c: ldurb           w16, [x1, #-1]
    //     0xd6ee20: ldurb           w17, [x0, #-1]
    //     0xd6ee24: and             x16, x17, x16, lsr #2
    //     0xd6ee28: tst             x16, HEAP, lsr #32
    //     0xd6ee2c: b.eq            #0xd6ee34
    //     0xd6ee30: bl              #0xd6826c
    // 0xd6ee34: r0 = Null
    //     0xd6ee34: mov             x0, NULL
    // 0xd6ee38: LeaveFrame
    //     0xd6ee38: mov             SP, fp
    //     0xd6ee3c: ldp             fp, lr, [SP], #0x10
    // 0xd6ee40: ret
    //     0xd6ee40: ret             
    // 0xd6ee44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6ee44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6ee48: b               #0xd6ed24
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd6ee4c, size: 0x4c
    // 0xd6ee4c: EnterFrame
    //     0xd6ee4c: stp             fp, lr, [SP, #-0x10]!
    //     0xd6ee50: mov             fp, SP
    // 0xd6ee54: ldr             x0, [fp, #0x10]
    // 0xd6ee58: LoadField: r1 = r0->field_17
    //     0xd6ee58: ldur            w1, [x0, #0x17]
    // 0xd6ee5c: DecompressPointer r1
    //     0xd6ee5c: add             x1, x1, HEAP, lsl #32
    // 0xd6ee60: CheckStackOverflow
    //     0xd6ee60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6ee64: cmp             SP, x16
    //     0xd6ee68: b.ls            #0xd6ee90
    // 0xd6ee6c: LoadField: r0 = r1->field_f
    //     0xd6ee6c: ldur            w0, [x1, #0xf]
    // 0xd6ee70: DecompressPointer r0
    //     0xd6ee70: add             x0, x0, HEAP, lsl #32
    // 0xd6ee74: r16 = ""
    //     0xd6ee74: ldr             x16, [PP, #0x7e8]  ; [pp+0x7e8] ""
    // 0xd6ee78: stp             x16, x0, [SP, #-0x10]!
    // 0xd6ee7c: r0 = _send()
    //     0xd6ee7c: bl              #0xa0c578  ; [package:dbus/src/dbus_auth_client.dart] DBusAuthClient::_send
    // 0xd6ee80: add             SP, SP, #0x10
    // 0xd6ee84: LeaveFrame
    //     0xd6ee84: mov             SP, fp
    //     0xd6ee88: ldp             fp, lr, [SP], #0x10
    // 0xd6ee8c: ret
    //     0xd6ee8c: ret             
    // 0xd6ee90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6ee90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6ee94: b               #0xd6ee6c
  }
}

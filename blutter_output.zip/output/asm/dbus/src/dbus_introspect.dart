// lib: , url: package:dbus/src/dbus_introspect.dart

// class id: 1048836, size: 0x8
class :: {

  static _ _listsEqual(/* No info */) {
    // ** addr: 0xc6df40, size: 0x1b0
    // 0xc6df40: EnterFrame
    //     0xc6df40: stp             fp, lr, [SP, #-0x10]!
    //     0xc6df44: mov             fp, SP
    // 0xc6df48: AllocStack(0x18)
    //     0xc6df48: sub             SP, SP, #0x18
    // 0xc6df4c: CheckStackOverflow
    //     0xc6df4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6df50: cmp             SP, x16
    //     0xc6df54: b.ls            #0xc6e0e0
    // 0xc6df58: ldr             x1, [fp, #0x18]
    // 0xc6df5c: r0 = LoadClassIdInstr(r1)
    //     0xc6df5c: ldur            x0, [x1, #-1]
    //     0xc6df60: ubfx            x0, x0, #0xc, #0x14
    // 0xc6df64: SaveReg r1
    //     0xc6df64: str             x1, [SP, #-8]!
    // 0xc6df68: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc6df68: mov             x17, #0xb8ea
    //     0xc6df6c: add             lr, x0, x17
    //     0xc6df70: ldr             lr, [x21, lr, lsl #3]
    //     0xc6df74: blr             lr
    // 0xc6df78: add             SP, SP, #8
    // 0xc6df7c: mov             x2, x0
    // 0xc6df80: ldr             x1, [fp, #0x10]
    // 0xc6df84: stur            x2, [fp, #-8]
    // 0xc6df88: r0 = LoadClassIdInstr(r1)
    //     0xc6df88: ldur            x0, [x1, #-1]
    //     0xc6df8c: ubfx            x0, x0, #0xc, #0x14
    // 0xc6df90: SaveReg r1
    //     0xc6df90: str             x1, [SP, #-8]!
    // 0xc6df94: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc6df94: mov             x17, #0xb8ea
    //     0xc6df98: add             lr, x0, x17
    //     0xc6df9c: ldr             lr, [x21, lr, lsl #3]
    //     0xc6dfa0: blr             lr
    // 0xc6dfa4: add             SP, SP, #8
    // 0xc6dfa8: mov             x1, x0
    // 0xc6dfac: ldur            x0, [fp, #-8]
    // 0xc6dfb0: cmp             w0, w1
    // 0xc6dfb4: b.eq            #0xc6dfc8
    // 0xc6dfb8: r0 = false
    //     0xc6dfb8: add             x0, NULL, #0x30  ; false
    // 0xc6dfbc: LeaveFrame
    //     0xc6dfbc: mov             SP, fp
    //     0xc6dfc0: ldp             fp, lr, [SP], #0x10
    // 0xc6dfc4: ret
    //     0xc6dfc4: ret             
    // 0xc6dfc8: r3 = 0
    //     0xc6dfc8: mov             x3, #0
    // 0xc6dfcc: ldr             x2, [fp, #0x18]
    // 0xc6dfd0: ldr             x1, [fp, #0x10]
    // 0xc6dfd4: stur            x3, [fp, #-0x10]
    // 0xc6dfd8: CheckStackOverflow
    //     0xc6dfd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6dfdc: cmp             SP, x16
    //     0xc6dfe0: b.ls            #0xc6e0e8
    // 0xc6dfe4: r0 = LoadClassIdInstr(r2)
    //     0xc6dfe4: ldur            x0, [x2, #-1]
    //     0xc6dfe8: ubfx            x0, x0, #0xc, #0x14
    // 0xc6dfec: SaveReg r2
    //     0xc6dfec: str             x2, [SP, #-8]!
    // 0xc6dff0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc6dff0: mov             x17, #0xb8ea
    //     0xc6dff4: add             lr, x0, x17
    //     0xc6dff8: ldr             lr, [x21, lr, lsl #3]
    //     0xc6dffc: blr             lr
    // 0xc6e000: add             SP, SP, #8
    // 0xc6e004: r1 = LoadInt32Instr(r0)
    //     0xc6e004: sbfx            x1, x0, #1, #0x1f
    // 0xc6e008: ldur            x2, [fp, #-0x10]
    // 0xc6e00c: cmp             x2, x1
    // 0xc6e010: b.ge            #0xc6e0d0
    // 0xc6e014: ldr             x4, [fp, #0x18]
    // 0xc6e018: ldr             x3, [fp, #0x10]
    // 0xc6e01c: r0 = BoxInt64Instr(r2)
    //     0xc6e01c: sbfiz           x0, x2, #1, #0x1f
    //     0xc6e020: cmp             x2, x0, asr #1
    //     0xc6e024: b.eq            #0xc6e030
    //     0xc6e028: bl              #0xd69bb8
    //     0xc6e02c: stur            x2, [x0, #7]
    // 0xc6e030: mov             x1, x0
    // 0xc6e034: stur            x1, [fp, #-8]
    // 0xc6e038: r0 = LoadClassIdInstr(r4)
    //     0xc6e038: ldur            x0, [x4, #-1]
    //     0xc6e03c: ubfx            x0, x0, #0xc, #0x14
    // 0xc6e040: stp             x1, x4, [SP, #-0x10]!
    // 0xc6e044: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc6e044: sub             lr, x0, #0xd83
    //     0xc6e048: ldr             lr, [x21, lr, lsl #3]
    //     0xc6e04c: blr             lr
    // 0xc6e050: add             SP, SP, #0x10
    // 0xc6e054: mov             x2, x0
    // 0xc6e058: ldr             x1, [fp, #0x10]
    // 0xc6e05c: stur            x2, [fp, #-0x18]
    // 0xc6e060: r0 = LoadClassIdInstr(r1)
    //     0xc6e060: ldur            x0, [x1, #-1]
    //     0xc6e064: ubfx            x0, x0, #0xc, #0x14
    // 0xc6e068: ldur            x16, [fp, #-8]
    // 0xc6e06c: stp             x16, x1, [SP, #-0x10]!
    // 0xc6e070: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc6e070: sub             lr, x0, #0xd83
    //     0xc6e074: ldr             lr, [x21, lr, lsl #3]
    //     0xc6e078: blr             lr
    // 0xc6e07c: add             SP, SP, #0x10
    // 0xc6e080: mov             x1, x0
    // 0xc6e084: ldur            x0, [fp, #-0x18]
    // 0xc6e088: r2 = 59
    //     0xc6e088: mov             x2, #0x3b
    // 0xc6e08c: branchIfSmi(r0, 0xc6e098)
    //     0xc6e08c: tbz             w0, #0, #0xc6e098
    // 0xc6e090: r2 = LoadClassIdInstr(r0)
    //     0xc6e090: ldur            x2, [x0, #-1]
    //     0xc6e094: ubfx            x2, x2, #0xc, #0x14
    // 0xc6e098: stp             x1, x0, [SP, #-0x10]!
    // 0xc6e09c: mov             x0, x2
    // 0xc6e0a0: mov             lr, x0
    // 0xc6e0a4: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e0a8: blr             lr
    // 0xc6e0ac: add             SP, SP, #0x10
    // 0xc6e0b0: tbz             w0, #4, #0xc6e0c4
    // 0xc6e0b4: r0 = false
    //     0xc6e0b4: add             x0, NULL, #0x30  ; false
    // 0xc6e0b8: LeaveFrame
    //     0xc6e0b8: mov             SP, fp
    //     0xc6e0bc: ldp             fp, lr, [SP], #0x10
    // 0xc6e0c0: ret
    //     0xc6e0c0: ret             
    // 0xc6e0c4: ldur            x1, [fp, #-0x10]
    // 0xc6e0c8: add             x3, x1, #1
    // 0xc6e0cc: b               #0xc6dfcc
    // 0xc6e0d0: r0 = true
    //     0xc6e0d0: add             x0, NULL, #0x20  ; true
    // 0xc6e0d4: LeaveFrame
    //     0xc6e0d4: mov             SP, fp
    //     0xc6e0d8: ldp             fp, lr, [SP], #0x10
    // 0xc6e0dc: ret
    //     0xc6e0dc: ret             
    // 0xc6e0e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6e0e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6e0e4: b               #0xc6df58
    // 0xc6e0e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6e0e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6e0ec: b               #0xc6dfe4
  }
}

// class id: 4614, size: 0x8, field offset: 0x8
abstract class DBusIntrospectAnnotation extends Object {
}

// class id: 4615, size: 0x18, field offset: 0x8
class DBusIntrospectArgument extends Object {

  _ toXml(/* No info */) {
    // ** addr: 0xa06a00, size: 0x480
    // 0xa06a00: EnterFrame
    //     0xa06a00: stp             fp, lr, [SP, #-0x10]!
    //     0xa06a04: mov             fp, SP
    // 0xa06a08: AllocStack(0x30)
    //     0xa06a08: sub             SP, SP, #0x30
    // 0xa06a0c: SetupParameters(DBusIntrospectArgument this /* r3, fp-0x10 */, {dynamic writeDirection = true /* r0, fp-0x8 */})
    //     0xa06a0c: mov             x0, x4
    //     0xa06a10: ldur            w1, [x0, #0x13]
    //     0xa06a14: add             x1, x1, HEAP, lsl #32
    //     0xa06a18: sub             x2, x1, #2
    //     0xa06a1c: add             x3, fp, w2, sxtw #2
    //     0xa06a20: ldr             x3, [x3, #0x10]
    //     0xa06a24: stur            x3, [fp, #-0x10]
    //     0xa06a28: ldur            w2, [x0, #0x1f]
    //     0xa06a2c: add             x2, x2, HEAP, lsl #32
    //     0xa06a30: ldr             x16, [PP, #0x7dc0]  ; [pp+0x7dc0] "writeDirection"
    //     0xa06a34: cmp             w2, w16
    //     0xa06a38: b.ne            #0xa06a58
    //     0xa06a3c: ldur            w2, [x0, #0x23]
    //     0xa06a40: add             x2, x2, HEAP, lsl #32
    //     0xa06a44: sub             w0, w1, w2
    //     0xa06a48: add             x1, fp, w0, sxtw #2
    //     0xa06a4c: ldr             x1, [x1, #8]
    //     0xa06a50: mov             x0, x1
    //     0xa06a54: b               #0xa06a5c
    //     0xa06a58: add             x0, NULL, #0x20  ; true
    //     0xa06a5c: stur            x0, [fp, #-8]
    // 0xa06a60: CheckStackOverflow
    //     0xa06a60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa06a64: cmp             SP, x16
    //     0xa06a68: b.ls            #0xa06e68
    // 0xa06a6c: r16 = <XmlAttribute>
    //     0xa06a6c: ldr             x16, [PP, #0x7d18]  ; [pp+0x7d18] TypeArguments: <XmlAttribute>
    // 0xa06a70: stp             xzr, x16, [SP, #-0x10]!
    // 0xa06a74: r0 = _GrowableList()
    //     0xa06a74: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa06a78: add             SP, SP, #0x10
    // 0xa06a7c: stur            x0, [fp, #-0x18]
    // 0xa06a80: r16 = "name"
    //     0xa06a80: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xa06a84: stp             x16, NULL, [SP, #-0x10]!
    // 0xa06a88: r0 = XmlName()
    //     0xa06a88: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa06a8c: add             SP, SP, #0x10
    // 0xa06a90: mov             x1, x0
    // 0xa06a94: ldur            x0, [fp, #-0x10]
    // 0xa06a98: stur            x1, [fp, #-0x28]
    // 0xa06a9c: LoadField: r2 = r0->field_7
    //     0xa06a9c: ldur            w2, [x0, #7]
    // 0xa06aa0: DecompressPointer r2
    //     0xa06aa0: add             x2, x2, HEAP, lsl #32
    // 0xa06aa4: stur            x2, [fp, #-0x20]
    // 0xa06aa8: r0 = XmlAttribute()
    //     0xa06aa8: bl              #0x4fb438  ; AllocateXmlAttributeStub -> XmlAttribute (size=0x18)
    // 0xa06aac: stur            x0, [fp, #-0x30]
    // 0xa06ab0: ldur            x16, [fp, #-0x28]
    // 0xa06ab4: stp             x16, x0, [SP, #-0x10]!
    // 0xa06ab8: ldur            x16, [fp, #-0x20]
    // 0xa06abc: SaveReg r16
    //     0xa06abc: str             x16, [SP, #-8]!
    // 0xa06ac0: r0 = XmlAttribute()
    //     0xa06ac0: bl              #0x4fb3a0  ; [package:xml/src/xml/nodes/attribute.dart] XmlAttribute::XmlAttribute
    // 0xa06ac4: add             SP, SP, #0x18
    // 0xa06ac8: ldur            x0, [fp, #-0x18]
    // 0xa06acc: LoadField: r1 = r0->field_b
    //     0xa06acc: ldur            w1, [x0, #0xb]
    // 0xa06ad0: DecompressPointer r1
    //     0xa06ad0: add             x1, x1, HEAP, lsl #32
    // 0xa06ad4: stur            x1, [fp, #-0x20]
    // 0xa06ad8: LoadField: r2 = r0->field_f
    //     0xa06ad8: ldur            w2, [x0, #0xf]
    // 0xa06adc: DecompressPointer r2
    //     0xa06adc: add             x2, x2, HEAP, lsl #32
    // 0xa06ae0: LoadField: r3 = r2->field_b
    //     0xa06ae0: ldur            w3, [x2, #0xb]
    // 0xa06ae4: DecompressPointer r3
    //     0xa06ae4: add             x3, x3, HEAP, lsl #32
    // 0xa06ae8: cmp             w1, w3
    // 0xa06aec: b.ne            #0xa06afc
    // 0xa06af0: SaveReg r0
    //     0xa06af0: str             x0, [SP, #-8]!
    // 0xa06af4: r0 = _growToNextCapacity()
    //     0xa06af4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa06af8: add             SP, SP, #8
    // 0xa06afc: ldur            x3, [fp, #-0x10]
    // 0xa06b00: ldur            x2, [fp, #-0x18]
    // 0xa06b04: ldur            x0, [fp, #-0x20]
    // 0xa06b08: r4 = LoadInt32Instr(r0)
    //     0xa06b08: sbfx            x4, x0, #1, #0x1f
    // 0xa06b0c: add             x0, x4, #1
    // 0xa06b10: lsl             x1, x0, #1
    // 0xa06b14: StoreField: r2->field_b = r1
    //     0xa06b14: stur            w1, [x2, #0xb]
    // 0xa06b18: mov             x1, x4
    // 0xa06b1c: cmp             x1, x0
    // 0xa06b20: b.hs            #0xa06e70
    // 0xa06b24: LoadField: r1 = r2->field_f
    //     0xa06b24: ldur            w1, [x2, #0xf]
    // 0xa06b28: DecompressPointer r1
    //     0xa06b28: add             x1, x1, HEAP, lsl #32
    // 0xa06b2c: ldur            x0, [fp, #-0x30]
    // 0xa06b30: ArrayStore: r1[r4] = r0  ; List_4
    //     0xa06b30: add             x25, x1, x4, lsl #2
    //     0xa06b34: add             x25, x25, #0xf
    //     0xa06b38: str             w0, [x25]
    //     0xa06b3c: tbz             w0, #0, #0xa06b58
    //     0xa06b40: ldurb           w16, [x1, #-1]
    //     0xa06b44: ldurb           w17, [x0, #-1]
    //     0xa06b48: and             x16, x17, x16, lsr #2
    //     0xa06b4c: tst             x16, HEAP, lsr #32
    //     0xa06b50: b.eq            #0xa06b58
    //     0xa06b54: bl              #0xd67e5c
    // 0xa06b58: r16 = "type"
    //     0xa06b58: ldr             x16, [PP, #0x1db8]  ; [pp+0x1db8] "type"
    // 0xa06b5c: stp             x16, NULL, [SP, #-0x10]!
    // 0xa06b60: r0 = XmlName()
    //     0xa06b60: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa06b64: add             SP, SP, #0x10
    // 0xa06b68: mov             x1, x0
    // 0xa06b6c: ldur            x0, [fp, #-0x10]
    // 0xa06b70: stur            x1, [fp, #-0x28]
    // 0xa06b74: LoadField: r2 = r0->field_b
    //     0xa06b74: ldur            w2, [x0, #0xb]
    // 0xa06b78: DecompressPointer r2
    //     0xa06b78: add             x2, x2, HEAP, lsl #32
    // 0xa06b7c: LoadField: r3 = r2->field_7
    //     0xa06b7c: ldur            w3, [x2, #7]
    // 0xa06b80: DecompressPointer r3
    //     0xa06b80: add             x3, x3, HEAP, lsl #32
    // 0xa06b84: stur            x3, [fp, #-0x20]
    // 0xa06b88: r0 = XmlAttribute()
    //     0xa06b88: bl              #0x4fb438  ; AllocateXmlAttributeStub -> XmlAttribute (size=0x18)
    // 0xa06b8c: stur            x0, [fp, #-0x30]
    // 0xa06b90: ldur            x16, [fp, #-0x28]
    // 0xa06b94: stp             x16, x0, [SP, #-0x10]!
    // 0xa06b98: ldur            x16, [fp, #-0x20]
    // 0xa06b9c: SaveReg r16
    //     0xa06b9c: str             x16, [SP, #-8]!
    // 0xa06ba0: r0 = XmlAttribute()
    //     0xa06ba0: bl              #0x4fb3a0  ; [package:xml/src/xml/nodes/attribute.dart] XmlAttribute::XmlAttribute
    // 0xa06ba4: add             SP, SP, #0x18
    // 0xa06ba8: ldur            x0, [fp, #-0x18]
    // 0xa06bac: LoadField: r1 = r0->field_b
    //     0xa06bac: ldur            w1, [x0, #0xb]
    // 0xa06bb0: DecompressPointer r1
    //     0xa06bb0: add             x1, x1, HEAP, lsl #32
    // 0xa06bb4: stur            x1, [fp, #-0x20]
    // 0xa06bb8: LoadField: r2 = r0->field_f
    //     0xa06bb8: ldur            w2, [x0, #0xf]
    // 0xa06bbc: DecompressPointer r2
    //     0xa06bbc: add             x2, x2, HEAP, lsl #32
    // 0xa06bc0: LoadField: r3 = r2->field_b
    //     0xa06bc0: ldur            w3, [x2, #0xb]
    // 0xa06bc4: DecompressPointer r3
    //     0xa06bc4: add             x3, x3, HEAP, lsl #32
    // 0xa06bc8: cmp             w1, w3
    // 0xa06bcc: b.ne            #0xa06bdc
    // 0xa06bd0: SaveReg r0
    //     0xa06bd0: str             x0, [SP, #-8]!
    // 0xa06bd4: r0 = _growToNextCapacity()
    //     0xa06bd4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa06bd8: add             SP, SP, #8
    // 0xa06bdc: ldur            x3, [fp, #-8]
    // 0xa06be0: ldur            x2, [fp, #-0x18]
    // 0xa06be4: ldur            x0, [fp, #-0x20]
    // 0xa06be8: r4 = LoadInt32Instr(r0)
    //     0xa06be8: sbfx            x4, x0, #1, #0x1f
    // 0xa06bec: add             x0, x4, #1
    // 0xa06bf0: lsl             x1, x0, #1
    // 0xa06bf4: StoreField: r2->field_b = r1
    //     0xa06bf4: stur            w1, [x2, #0xb]
    // 0xa06bf8: mov             x1, x4
    // 0xa06bfc: cmp             x1, x0
    // 0xa06c00: b.hs            #0xa06e74
    // 0xa06c04: LoadField: r1 = r2->field_f
    //     0xa06c04: ldur            w1, [x2, #0xf]
    // 0xa06c08: DecompressPointer r1
    //     0xa06c08: add             x1, x1, HEAP, lsl #32
    // 0xa06c0c: ldur            x0, [fp, #-0x30]
    // 0xa06c10: ArrayStore: r1[r4] = r0  ; List_4
    //     0xa06c10: add             x25, x1, x4, lsl #2
    //     0xa06c14: add             x25, x25, #0xf
    //     0xa06c18: str             w0, [x25]
    //     0xa06c1c: tbz             w0, #0, #0xa06c38
    //     0xa06c20: ldurb           w16, [x1, #-1]
    //     0xa06c24: ldurb           w17, [x0, #-1]
    //     0xa06c28: and             x16, x17, x16, lsr #2
    //     0xa06c2c: tst             x16, HEAP, lsr #32
    //     0xa06c30: b.eq            #0xa06c38
    //     0xa06c34: bl              #0xd67e5c
    // 0xa06c38: tbnz            w3, #4, #0xa06de4
    // 0xa06c3c: ldur            x0, [fp, #-0x10]
    // 0xa06c40: LoadField: r1 = r0->field_f
    //     0xa06c40: ldur            w1, [x0, #0xf]
    // 0xa06c44: DecompressPointer r1
    //     0xa06c44: add             x1, x1, HEAP, lsl #32
    // 0xa06c48: r16 = Instance_DBusArgumentDirection
    //     0xa06c48: ldr             x16, [PP, #0x7dc8]  ; [pp+0x7dc8] Obj!DBusArgumentDirection@b66811
    // 0xa06c4c: cmp             w1, w16
    // 0xa06c50: b.ne            #0xa06d18
    // 0xa06c54: r16 = "direction"
    //     0xa06c54: ldr             x16, [PP, #0x7dd0]  ; [pp+0x7dd0] "direction"
    // 0xa06c58: stp             x16, NULL, [SP, #-0x10]!
    // 0xa06c5c: r0 = XmlName()
    //     0xa06c5c: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa06c60: add             SP, SP, #0x10
    // 0xa06c64: stur            x0, [fp, #-8]
    // 0xa06c68: r0 = XmlAttribute()
    //     0xa06c68: bl              #0x4fb438  ; AllocateXmlAttributeStub -> XmlAttribute (size=0x18)
    // 0xa06c6c: stur            x0, [fp, #-0x10]
    // 0xa06c70: ldur            x16, [fp, #-8]
    // 0xa06c74: stp             x16, x0, [SP, #-0x10]!
    // 0xa06c78: r16 = "in"
    //     0xa06c78: ldr             x16, [PP, #0x7dd8]  ; [pp+0x7dd8] "in"
    // 0xa06c7c: SaveReg r16
    //     0xa06c7c: str             x16, [SP, #-8]!
    // 0xa06c80: r0 = XmlAttribute()
    //     0xa06c80: bl              #0x4fb3a0  ; [package:xml/src/xml/nodes/attribute.dart] XmlAttribute::XmlAttribute
    // 0xa06c84: add             SP, SP, #0x18
    // 0xa06c88: ldur            x0, [fp, #-0x18]
    // 0xa06c8c: LoadField: r1 = r0->field_b
    //     0xa06c8c: ldur            w1, [x0, #0xb]
    // 0xa06c90: DecompressPointer r1
    //     0xa06c90: add             x1, x1, HEAP, lsl #32
    // 0xa06c94: stur            x1, [fp, #-8]
    // 0xa06c98: LoadField: r2 = r0->field_f
    //     0xa06c98: ldur            w2, [x0, #0xf]
    // 0xa06c9c: DecompressPointer r2
    //     0xa06c9c: add             x2, x2, HEAP, lsl #32
    // 0xa06ca0: LoadField: r3 = r2->field_b
    //     0xa06ca0: ldur            w3, [x2, #0xb]
    // 0xa06ca4: DecompressPointer r3
    //     0xa06ca4: add             x3, x3, HEAP, lsl #32
    // 0xa06ca8: cmp             w1, w3
    // 0xa06cac: b.ne            #0xa06cbc
    // 0xa06cb0: SaveReg r0
    //     0xa06cb0: str             x0, [SP, #-8]!
    // 0xa06cb4: r0 = _growToNextCapacity()
    //     0xa06cb4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa06cb8: add             SP, SP, #8
    // 0xa06cbc: ldur            x2, [fp, #-0x18]
    // 0xa06cc0: ldur            x0, [fp, #-8]
    // 0xa06cc4: r3 = LoadInt32Instr(r0)
    //     0xa06cc4: sbfx            x3, x0, #1, #0x1f
    // 0xa06cc8: add             x0, x3, #1
    // 0xa06ccc: lsl             x1, x0, #1
    // 0xa06cd0: StoreField: r2->field_b = r1
    //     0xa06cd0: stur            w1, [x2, #0xb]
    // 0xa06cd4: mov             x1, x3
    // 0xa06cd8: cmp             x1, x0
    // 0xa06cdc: b.hs            #0xa06e78
    // 0xa06ce0: LoadField: r1 = r2->field_f
    //     0xa06ce0: ldur            w1, [x2, #0xf]
    // 0xa06ce4: DecompressPointer r1
    //     0xa06ce4: add             x1, x1, HEAP, lsl #32
    // 0xa06ce8: ldur            x0, [fp, #-0x10]
    // 0xa06cec: ArrayStore: r1[r3] = r0  ; List_4
    //     0xa06cec: add             x25, x1, x3, lsl #2
    //     0xa06cf0: add             x25, x25, #0xf
    //     0xa06cf4: str             w0, [x25]
    //     0xa06cf8: tbz             w0, #0, #0xa06d14
    //     0xa06cfc: ldurb           w16, [x1, #-1]
    //     0xa06d00: ldurb           w17, [x0, #-1]
    //     0xa06d04: and             x16, x17, x16, lsr #2
    //     0xa06d08: tst             x16, HEAP, lsr #32
    //     0xa06d0c: b.eq            #0xa06d14
    //     0xa06d10: bl              #0xd67e5c
    // 0xa06d14: b               #0xa06de4
    // 0xa06d18: r16 = Instance_DBusArgumentDirection
    //     0xa06d18: ldr             x16, [PP, #0x7de0]  ; [pp+0x7de0] Obj!DBusArgumentDirection@b667f1
    // 0xa06d1c: cmp             w1, w16
    // 0xa06d20: b.ne            #0xa06de4
    // 0xa06d24: r16 = "direction"
    //     0xa06d24: ldr             x16, [PP, #0x7dd0]  ; [pp+0x7dd0] "direction"
    // 0xa06d28: stp             x16, NULL, [SP, #-0x10]!
    // 0xa06d2c: r0 = XmlName()
    //     0xa06d2c: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa06d30: add             SP, SP, #0x10
    // 0xa06d34: stur            x0, [fp, #-8]
    // 0xa06d38: r0 = XmlAttribute()
    //     0xa06d38: bl              #0x4fb438  ; AllocateXmlAttributeStub -> XmlAttribute (size=0x18)
    // 0xa06d3c: stur            x0, [fp, #-0x10]
    // 0xa06d40: ldur            x16, [fp, #-8]
    // 0xa06d44: stp             x16, x0, [SP, #-0x10]!
    // 0xa06d48: r16 = "out"
    //     0xa06d48: ldr             x16, [PP, #0x7de8]  ; [pp+0x7de8] "out"
    // 0xa06d4c: SaveReg r16
    //     0xa06d4c: str             x16, [SP, #-8]!
    // 0xa06d50: r0 = XmlAttribute()
    //     0xa06d50: bl              #0x4fb3a0  ; [package:xml/src/xml/nodes/attribute.dart] XmlAttribute::XmlAttribute
    // 0xa06d54: add             SP, SP, #0x18
    // 0xa06d58: ldur            x0, [fp, #-0x18]
    // 0xa06d5c: LoadField: r1 = r0->field_b
    //     0xa06d5c: ldur            w1, [x0, #0xb]
    // 0xa06d60: DecompressPointer r1
    //     0xa06d60: add             x1, x1, HEAP, lsl #32
    // 0xa06d64: stur            x1, [fp, #-8]
    // 0xa06d68: LoadField: r2 = r0->field_f
    //     0xa06d68: ldur            w2, [x0, #0xf]
    // 0xa06d6c: DecompressPointer r2
    //     0xa06d6c: add             x2, x2, HEAP, lsl #32
    // 0xa06d70: LoadField: r3 = r2->field_b
    //     0xa06d70: ldur            w3, [x2, #0xb]
    // 0xa06d74: DecompressPointer r3
    //     0xa06d74: add             x3, x3, HEAP, lsl #32
    // 0xa06d78: cmp             w1, w3
    // 0xa06d7c: b.ne            #0xa06d8c
    // 0xa06d80: SaveReg r0
    //     0xa06d80: str             x0, [SP, #-8]!
    // 0xa06d84: r0 = _growToNextCapacity()
    //     0xa06d84: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa06d88: add             SP, SP, #8
    // 0xa06d8c: ldur            x2, [fp, #-0x18]
    // 0xa06d90: ldur            x0, [fp, #-8]
    // 0xa06d94: r3 = LoadInt32Instr(r0)
    //     0xa06d94: sbfx            x3, x0, #1, #0x1f
    // 0xa06d98: add             x0, x3, #1
    // 0xa06d9c: lsl             x1, x0, #1
    // 0xa06da0: StoreField: r2->field_b = r1
    //     0xa06da0: stur            w1, [x2, #0xb]
    // 0xa06da4: mov             x1, x3
    // 0xa06da8: cmp             x1, x0
    // 0xa06dac: b.hs            #0xa06e7c
    // 0xa06db0: LoadField: r1 = r2->field_f
    //     0xa06db0: ldur            w1, [x2, #0xf]
    // 0xa06db4: DecompressPointer r1
    //     0xa06db4: add             x1, x1, HEAP, lsl #32
    // 0xa06db8: ldur            x0, [fp, #-0x10]
    // 0xa06dbc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xa06dbc: add             x25, x1, x3, lsl #2
    //     0xa06dc0: add             x25, x25, #0xf
    //     0xa06dc4: str             w0, [x25]
    //     0xa06dc8: tbz             w0, #0, #0xa06de4
    //     0xa06dcc: ldurb           w16, [x1, #-1]
    //     0xa06dd0: ldurb           w17, [x0, #-1]
    //     0xa06dd4: and             x16, x17, x16, lsr #2
    //     0xa06dd8: tst             x16, HEAP, lsr #32
    //     0xa06ddc: b.eq            #0xa06de4
    //     0xa06de0: bl              #0xd67e5c
    // 0xa06de4: r16 = "arg"
    //     0xa06de4: ldr             x16, [PP, #0x7df0]  ; [pp+0x7df0] "arg"
    // 0xa06de8: stp             x16, NULL, [SP, #-0x10]!
    // 0xa06dec: r0 = XmlName()
    //     0xa06dec: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa06df0: add             SP, SP, #0x10
    // 0xa06df4: r1 = Function '<anonymous closure>':.
    //     0xa06df4: ldr             x1, [PP, #0x7df8]  ; [pp+0x7df8] AnonymousClosure: (0xa06e80), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectArgument::toXml (0xa06a00)
    // 0xa06df8: r2 = Null
    //     0xa06df8: mov             x2, NULL
    // 0xa06dfc: stur            x0, [fp, #-8]
    // 0xa06e00: r0 = AllocateClosure()
    //     0xa06e00: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa06e04: r16 = <XmlNode>
    //     0xa06e04: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06e08: r30 = const []
    //     0xa06e08: ldr             lr, [PP, #0x7d68]  ; [pp+0x7d68] List<DBusIntrospectAnnotation>(0)
    // 0xa06e0c: stp             lr, x16, [SP, #-0x10]!
    // 0xa06e10: SaveReg r0
    //     0xa06e10: str             x0, [SP, #-8]!
    // 0xa06e14: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa06e14: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa06e18: r0 = map()
    //     0xa06e18: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa06e1c: add             SP, SP, #0x18
    // 0xa06e20: SaveReg r0
    //     0xa06e20: str             x0, [SP, #-8]!
    // 0xa06e24: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa06e24: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa06e28: r0 = toList()
    //     0xa06e28: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0xa06e2c: add             SP, SP, #8
    // 0xa06e30: stur            x0, [fp, #-0x10]
    // 0xa06e34: r0 = XmlElement()
    //     0xa06e34: bl              #0x4fba78  ; AllocateXmlElementStub -> XmlElement (size=0x1c)
    // 0xa06e38: stur            x0, [fp, #-0x20]
    // 0xa06e3c: ldur            x16, [fp, #-8]
    // 0xa06e40: stp             x16, x0, [SP, #-0x10]!
    // 0xa06e44: ldur            x16, [fp, #-0x18]
    // 0xa06e48: ldur            lr, [fp, #-0x10]
    // 0xa06e4c: stp             lr, x16, [SP, #-0x10]!
    // 0xa06e50: r0 = XmlElement()
    //     0xa06e50: bl              #0x4fb444  ; [package:xml/src/xml/nodes/element.dart] XmlElement::XmlElement
    // 0xa06e54: add             SP, SP, #0x20
    // 0xa06e58: ldur            x0, [fp, #-0x20]
    // 0xa06e5c: LeaveFrame
    //     0xa06e5c: mov             SP, fp
    //     0xa06e60: ldp             fp, lr, [SP], #0x10
    // 0xa06e64: ret
    //     0xa06e64: ret             
    // 0xa06e68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa06e68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa06e6c: b               #0xa06a6c
    // 0xa06e70: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa06e70: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa06e74: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa06e74: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa06e78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa06e78: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa06e7c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa06e7c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectAnnotation) {
    // ** addr: 0xa06e80, size: 0x4c
    // 0xa06e80: EnterFrame
    //     0xa06e80: stp             fp, lr, [SP, #-0x10]!
    //     0xa06e84: mov             fp, SP
    // 0xa06e88: CheckStackOverflow
    //     0xa06e88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa06e8c: cmp             SP, x16
    //     0xa06e90: b.ls            #0xa06ec4
    // 0xa06e94: ldr             x16, [fp, #0x10]
    // 0xa06e98: SaveReg r16
    //     0xa06e98: str             x16, [SP, #-8]!
    // 0xa06e9c: r4 = 0
    //     0xa06e9c: mov             x4, #0
    // 0xa06ea0: ldr             x0, [SP]
    // 0xa06ea4: r16 = UnlinkedCall_0x4aeefc
    //     0xa06ea4: add             x16, PP, #7, lsl #12  ; [pp+0x7e00] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xa06ea8: add             x16, x16, #0xe00
    // 0xa06eac: ldp             x5, lr, [x16]
    // 0xa06eb0: blr             lr
    // 0xa06eb4: add             SP, SP, #8
    // 0xa06eb8: LeaveFrame
    //     0xa06eb8: mov             SP, fp
    //     0xa06ebc: ldp             fp, lr, [SP], #0x10
    // 0xa06ec0: ret
    //     0xa06ec0: ret             
    // 0xa06ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa06ec4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa06ec8: b               #0xa06e94
  }
}

// class id: 4616, size: 0x8, field offset: 0x8
abstract class DBusIntrospectProperty extends Object {
}

// class id: 4617, size: 0x14, field offset: 0x8
class DBusIntrospectSignal extends Object {

  _ toXml(/* No info */) {
    // ** addr: 0xa067f0, size: 0x184
    // 0xa067f0: EnterFrame
    //     0xa067f0: stp             fp, lr, [SP, #-0x10]!
    //     0xa067f4: mov             fp, SP
    // 0xa067f8: AllocStack(0x28)
    //     0xa067f8: sub             SP, SP, #0x28
    // 0xa067fc: CheckStackOverflow
    //     0xa067fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa06800: cmp             SP, x16
    //     0xa06804: b.ls            #0xa0696c
    // 0xa06808: r16 = <XmlNode>
    //     0xa06808: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa0680c: stp             xzr, x16, [SP, #-0x10]!
    // 0xa06810: r0 = _GrowableList()
    //     0xa06810: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa06814: add             SP, SP, #0x10
    // 0xa06818: mov             x3, x0
    // 0xa0681c: ldr             x0, [fp, #0x10]
    // 0xa06820: stur            x3, [fp, #-0x10]
    // 0xa06824: LoadField: r4 = r0->field_b
    //     0xa06824: ldur            w4, [x0, #0xb]
    // 0xa06828: DecompressPointer r4
    //     0xa06828: add             x4, x4, HEAP, lsl #32
    // 0xa0682c: stur            x4, [fp, #-8]
    // 0xa06830: r1 = Function '<anonymous closure>':.
    //     0xa06830: ldr             x1, [PP, #0x7d90]  ; [pp+0x7d90] AnonymousClosure: (0xa069c0), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectSignal::toXml (0xa067f0)
    // 0xa06834: r2 = Null
    //     0xa06834: mov             x2, NULL
    // 0xa06838: r0 = AllocateClosure()
    //     0xa06838: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0683c: r16 = <XmlNode>
    //     0xa0683c: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06840: ldur            lr, [fp, #-8]
    // 0xa06844: stp             lr, x16, [SP, #-0x10]!
    // 0xa06848: SaveReg r0
    //     0xa06848: str             x0, [SP, #-8]!
    // 0xa0684c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0684c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa06850: r0 = map()
    //     0xa06850: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa06854: add             SP, SP, #0x18
    // 0xa06858: ldur            x16, [fp, #-0x10]
    // 0xa0685c: stp             x0, x16, [SP, #-0x10]!
    // 0xa06860: r0 = addAll()
    //     0xa06860: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa06864: add             SP, SP, #0x10
    // 0xa06868: r1 = Function '<anonymous closure>':.
    //     0xa06868: ldr             x1, [PP, #0x7d98]  ; [pp+0x7d98] AnonymousClosure: (0xa06974), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectSignal::toXml (0xa067f0)
    // 0xa0686c: r2 = Null
    //     0xa0686c: mov             x2, NULL
    // 0xa06870: r0 = AllocateClosure()
    //     0xa06870: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa06874: r16 = <XmlNode>
    //     0xa06874: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06878: r30 = const []
    //     0xa06878: ldr             lr, [PP, #0x7d68]  ; [pp+0x7d68] List<DBusIntrospectAnnotation>(0)
    // 0xa0687c: stp             lr, x16, [SP, #-0x10]!
    // 0xa06880: SaveReg r0
    //     0xa06880: str             x0, [SP, #-8]!
    // 0xa06884: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa06884: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa06888: r0 = map()
    //     0xa06888: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa0688c: add             SP, SP, #0x18
    // 0xa06890: ldur            x16, [fp, #-0x10]
    // 0xa06894: stp             x0, x16, [SP, #-0x10]!
    // 0xa06898: r0 = addAll()
    //     0xa06898: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa0689c: add             SP, SP, #0x10
    // 0xa068a0: r16 = "signal"
    //     0xa068a0: ldr             x16, [PP, #0x7da0]  ; [pp+0x7da0] "signal"
    // 0xa068a4: stp             x16, NULL, [SP, #-0x10]!
    // 0xa068a8: r0 = XmlName()
    //     0xa068a8: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa068ac: add             SP, SP, #0x10
    // 0xa068b0: stur            x0, [fp, #-8]
    // 0xa068b4: r16 = "name"
    //     0xa068b4: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xa068b8: stp             x16, NULL, [SP, #-0x10]!
    // 0xa068bc: r0 = XmlName()
    //     0xa068bc: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa068c0: add             SP, SP, #0x10
    // 0xa068c4: mov             x1, x0
    // 0xa068c8: ldr             x0, [fp, #0x10]
    // 0xa068cc: stur            x1, [fp, #-0x20]
    // 0xa068d0: LoadField: r2 = r0->field_7
    //     0xa068d0: ldur            w2, [x0, #7]
    // 0xa068d4: DecompressPointer r2
    //     0xa068d4: add             x2, x2, HEAP, lsl #32
    // 0xa068d8: stur            x2, [fp, #-0x18]
    // 0xa068dc: r0 = XmlAttribute()
    //     0xa068dc: bl              #0x4fb438  ; AllocateXmlAttributeStub -> XmlAttribute (size=0x18)
    // 0xa068e0: stur            x0, [fp, #-0x28]
    // 0xa068e4: ldur            x16, [fp, #-0x20]
    // 0xa068e8: stp             x16, x0, [SP, #-0x10]!
    // 0xa068ec: ldur            x16, [fp, #-0x18]
    // 0xa068f0: SaveReg r16
    //     0xa068f0: str             x16, [SP, #-8]!
    // 0xa068f4: r0 = XmlAttribute()
    //     0xa068f4: bl              #0x4fb3a0  ; [package:xml/src/xml/nodes/attribute.dart] XmlAttribute::XmlAttribute
    // 0xa068f8: add             SP, SP, #0x18
    // 0xa068fc: r1 = Null
    //     0xa068fc: mov             x1, NULL
    // 0xa06900: r2 = 2
    //     0xa06900: mov             x2, #2
    // 0xa06904: r0 = AllocateArray()
    //     0xa06904: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa06908: mov             x2, x0
    // 0xa0690c: ldur            x0, [fp, #-0x28]
    // 0xa06910: stur            x2, [fp, #-0x18]
    // 0xa06914: StoreField: r2->field_f = r0
    //     0xa06914: stur            w0, [x2, #0xf]
    // 0xa06918: r1 = <XmlAttribute>
    //     0xa06918: ldr             x1, [PP, #0x7d18]  ; [pp+0x7d18] TypeArguments: <XmlAttribute>
    // 0xa0691c: r0 = AllocateGrowableArray()
    //     0xa0691c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa06920: mov             x1, x0
    // 0xa06924: ldur            x0, [fp, #-0x18]
    // 0xa06928: stur            x1, [fp, #-0x20]
    // 0xa0692c: StoreField: r1->field_f = r0
    //     0xa0692c: stur            w0, [x1, #0xf]
    // 0xa06930: r0 = 2
    //     0xa06930: mov             x0, #2
    // 0xa06934: StoreField: r1->field_b = r0
    //     0xa06934: stur            w0, [x1, #0xb]
    // 0xa06938: r0 = XmlElement()
    //     0xa06938: bl              #0x4fba78  ; AllocateXmlElementStub -> XmlElement (size=0x1c)
    // 0xa0693c: stur            x0, [fp, #-0x18]
    // 0xa06940: ldur            x16, [fp, #-8]
    // 0xa06944: stp             x16, x0, [SP, #-0x10]!
    // 0xa06948: ldur            x16, [fp, #-0x20]
    // 0xa0694c: ldur            lr, [fp, #-0x10]
    // 0xa06950: stp             lr, x16, [SP, #-0x10]!
    // 0xa06954: r0 = XmlElement()
    //     0xa06954: bl              #0x4fb444  ; [package:xml/src/xml/nodes/element.dart] XmlElement::XmlElement
    // 0xa06958: add             SP, SP, #0x20
    // 0xa0695c: ldur            x0, [fp, #-0x18]
    // 0xa06960: LeaveFrame
    //     0xa06960: mov             SP, fp
    //     0xa06964: ldp             fp, lr, [SP], #0x10
    // 0xa06968: ret
    //     0xa06968: ret             
    // 0xa0696c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0696c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa06970: b               #0xa06808
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectAnnotation) {
    // ** addr: 0xa06974, size: 0x4c
    // 0xa06974: EnterFrame
    //     0xa06974: stp             fp, lr, [SP, #-0x10]!
    //     0xa06978: mov             fp, SP
    // 0xa0697c: CheckStackOverflow
    //     0xa0697c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa06980: cmp             SP, x16
    //     0xa06984: b.ls            #0xa069b8
    // 0xa06988: ldr             x16, [fp, #0x10]
    // 0xa0698c: SaveReg r16
    //     0xa0698c: str             x16, [SP, #-8]!
    // 0xa06990: r4 = 0
    //     0xa06990: mov             x4, #0
    // 0xa06994: ldr             x0, [SP]
    // 0xa06998: r16 = UnlinkedCall_0x4aeefc
    //     0xa06998: add             x16, PP, #7, lsl #12  ; [pp+0x7da8] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xa0699c: add             x16, x16, #0xda8
    // 0xa069a0: ldp             x5, lr, [x16]
    // 0xa069a4: blr             lr
    // 0xa069a8: add             SP, SP, #8
    // 0xa069ac: LeaveFrame
    //     0xa069ac: mov             SP, fp
    //     0xa069b0: ldp             fp, lr, [SP], #0x10
    // 0xa069b4: ret
    //     0xa069b4: ret             
    // 0xa069b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa069b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa069bc: b               #0xa06988
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectArgument) {
    // ** addr: 0xa069c0, size: 0x40
    // 0xa069c0: EnterFrame
    //     0xa069c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa069c4: mov             fp, SP
    // 0xa069c8: CheckStackOverflow
    //     0xa069c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa069cc: cmp             SP, x16
    //     0xa069d0: b.ls            #0xa069f8
    // 0xa069d4: ldr             x16, [fp, #0x10]
    // 0xa069d8: r30 = false
    //     0xa069d8: add             lr, NULL, #0x30  ; false
    // 0xa069dc: stp             lr, x16, [SP, #-0x10]!
    // 0xa069e0: r4 = const [0, 0x2, 0x2, 0x1, writeDirection, 0x1, null]
    //     0xa069e0: ldr             x4, [PP, #0x7db8]  ; [pp+0x7db8] List(7) [0, 0x2, 0x2, 0x1, "writeDirection", 0x1, Null]
    // 0xa069e4: r0 = toXml()
    //     0xa069e4: bl              #0xa06a00  ; [package:dbus/src/dbus_introspect.dart] DBusIntrospectArgument::toXml
    // 0xa069e8: add             SP, SP, #0x10
    // 0xa069ec: LeaveFrame
    //     0xa069ec: mov             SP, fp
    //     0xa069f0: ldp             fp, lr, [SP], #0x10
    // 0xa069f4: ret
    //     0xa069f4: ret             
    // 0xa069f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa069f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa069fc: b               #0xa069d4
  }
}

// class id: 4618, size: 0x14, field offset: 0x8
class DBusIntrospectMethod extends Object {

  _ toXml(/* No info */) {
    // ** addr: 0xa06f04, size: 0x184
    // 0xa06f04: EnterFrame
    //     0xa06f04: stp             fp, lr, [SP, #-0x10]!
    //     0xa06f08: mov             fp, SP
    // 0xa06f0c: AllocStack(0x28)
    //     0xa06f0c: sub             SP, SP, #0x28
    // 0xa06f10: CheckStackOverflow
    //     0xa06f10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa06f14: cmp             SP, x16
    //     0xa06f18: b.ls            #0xa07080
    // 0xa06f1c: r16 = <XmlNode>
    //     0xa06f1c: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06f20: stp             xzr, x16, [SP, #-0x10]!
    // 0xa06f24: r0 = _GrowableList()
    //     0xa06f24: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa06f28: add             SP, SP, #0x10
    // 0xa06f2c: mov             x3, x0
    // 0xa06f30: ldr             x0, [fp, #0x10]
    // 0xa06f34: stur            x3, [fp, #-0x10]
    // 0xa06f38: LoadField: r4 = r0->field_b
    //     0xa06f38: ldur            w4, [x0, #0xb]
    // 0xa06f3c: DecompressPointer r4
    //     0xa06f3c: add             x4, x4, HEAP, lsl #32
    // 0xa06f40: stur            x4, [fp, #-8]
    // 0xa06f44: r1 = Function '<anonymous closure>':.
    //     0xa06f44: ldr             x1, [PP, #0x7e10]  ; [pp+0x7e10] AnonymousClosure: (0xa070d4), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectMethod::toXml (0xa06f04)
    // 0xa06f48: r2 = Null
    //     0xa06f48: mov             x2, NULL
    // 0xa06f4c: r0 = AllocateClosure()
    //     0xa06f4c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa06f50: r16 = <XmlNode>
    //     0xa06f50: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06f54: ldur            lr, [fp, #-8]
    // 0xa06f58: stp             lr, x16, [SP, #-0x10]!
    // 0xa06f5c: SaveReg r0
    //     0xa06f5c: str             x0, [SP, #-8]!
    // 0xa06f60: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa06f60: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa06f64: r0 = map()
    //     0xa06f64: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa06f68: add             SP, SP, #0x18
    // 0xa06f6c: ldur            x16, [fp, #-0x10]
    // 0xa06f70: stp             x0, x16, [SP, #-0x10]!
    // 0xa06f74: r0 = addAll()
    //     0xa06f74: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa06f78: add             SP, SP, #0x10
    // 0xa06f7c: r1 = Function '<anonymous closure>':.
    //     0xa06f7c: ldr             x1, [PP, #0x7e18]  ; [pp+0x7e18] AnonymousClosure: (0xa07088), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectMethod::toXml (0xa06f04)
    // 0xa06f80: r2 = Null
    //     0xa06f80: mov             x2, NULL
    // 0xa06f84: r0 = AllocateClosure()
    //     0xa06f84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa06f88: r16 = <XmlNode>
    //     0xa06f88: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06f8c: r30 = const []
    //     0xa06f8c: ldr             lr, [PP, #0x7d68]  ; [pp+0x7d68] List<DBusIntrospectAnnotation>(0)
    // 0xa06f90: stp             lr, x16, [SP, #-0x10]!
    // 0xa06f94: SaveReg r0
    //     0xa06f94: str             x0, [SP, #-8]!
    // 0xa06f98: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa06f98: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa06f9c: r0 = map()
    //     0xa06f9c: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa06fa0: add             SP, SP, #0x18
    // 0xa06fa4: ldur            x16, [fp, #-0x10]
    // 0xa06fa8: stp             x0, x16, [SP, #-0x10]!
    // 0xa06fac: r0 = addAll()
    //     0xa06fac: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa06fb0: add             SP, SP, #0x10
    // 0xa06fb4: r16 = "method"
    //     0xa06fb4: ldr             x16, [PP, #0x2a98]  ; [pp+0x2a98] "method"
    // 0xa06fb8: stp             x16, NULL, [SP, #-0x10]!
    // 0xa06fbc: r0 = XmlName()
    //     0xa06fbc: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa06fc0: add             SP, SP, #0x10
    // 0xa06fc4: stur            x0, [fp, #-8]
    // 0xa06fc8: r16 = "name"
    //     0xa06fc8: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xa06fcc: stp             x16, NULL, [SP, #-0x10]!
    // 0xa06fd0: r0 = XmlName()
    //     0xa06fd0: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa06fd4: add             SP, SP, #0x10
    // 0xa06fd8: mov             x1, x0
    // 0xa06fdc: ldr             x0, [fp, #0x10]
    // 0xa06fe0: stur            x1, [fp, #-0x20]
    // 0xa06fe4: LoadField: r2 = r0->field_7
    //     0xa06fe4: ldur            w2, [x0, #7]
    // 0xa06fe8: DecompressPointer r2
    //     0xa06fe8: add             x2, x2, HEAP, lsl #32
    // 0xa06fec: stur            x2, [fp, #-0x18]
    // 0xa06ff0: r0 = XmlAttribute()
    //     0xa06ff0: bl              #0x4fb438  ; AllocateXmlAttributeStub -> XmlAttribute (size=0x18)
    // 0xa06ff4: stur            x0, [fp, #-0x28]
    // 0xa06ff8: ldur            x16, [fp, #-0x20]
    // 0xa06ffc: stp             x16, x0, [SP, #-0x10]!
    // 0xa07000: ldur            x16, [fp, #-0x18]
    // 0xa07004: SaveReg r16
    //     0xa07004: str             x16, [SP, #-8]!
    // 0xa07008: r0 = XmlAttribute()
    //     0xa07008: bl              #0x4fb3a0  ; [package:xml/src/xml/nodes/attribute.dart] XmlAttribute::XmlAttribute
    // 0xa0700c: add             SP, SP, #0x18
    // 0xa07010: r1 = Null
    //     0xa07010: mov             x1, NULL
    // 0xa07014: r2 = 2
    //     0xa07014: mov             x2, #2
    // 0xa07018: r0 = AllocateArray()
    //     0xa07018: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0701c: mov             x2, x0
    // 0xa07020: ldur            x0, [fp, #-0x28]
    // 0xa07024: stur            x2, [fp, #-0x18]
    // 0xa07028: StoreField: r2->field_f = r0
    //     0xa07028: stur            w0, [x2, #0xf]
    // 0xa0702c: r1 = <XmlAttribute>
    //     0xa0702c: ldr             x1, [PP, #0x7d18]  ; [pp+0x7d18] TypeArguments: <XmlAttribute>
    // 0xa07030: r0 = AllocateGrowableArray()
    //     0xa07030: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa07034: mov             x1, x0
    // 0xa07038: ldur            x0, [fp, #-0x18]
    // 0xa0703c: stur            x1, [fp, #-0x20]
    // 0xa07040: StoreField: r1->field_f = r0
    //     0xa07040: stur            w0, [x1, #0xf]
    // 0xa07044: r0 = 2
    //     0xa07044: mov             x0, #2
    // 0xa07048: StoreField: r1->field_b = r0
    //     0xa07048: stur            w0, [x1, #0xb]
    // 0xa0704c: r0 = XmlElement()
    //     0xa0704c: bl              #0x4fba78  ; AllocateXmlElementStub -> XmlElement (size=0x1c)
    // 0xa07050: stur            x0, [fp, #-0x18]
    // 0xa07054: ldur            x16, [fp, #-8]
    // 0xa07058: stp             x16, x0, [SP, #-0x10]!
    // 0xa0705c: ldur            x16, [fp, #-0x20]
    // 0xa07060: ldur            lr, [fp, #-0x10]
    // 0xa07064: stp             lr, x16, [SP, #-0x10]!
    // 0xa07068: r0 = XmlElement()
    //     0xa07068: bl              #0x4fb444  ; [package:xml/src/xml/nodes/element.dart] XmlElement::XmlElement
    // 0xa0706c: add             SP, SP, #0x20
    // 0xa07070: ldur            x0, [fp, #-0x18]
    // 0xa07074: LeaveFrame
    //     0xa07074: mov             SP, fp
    //     0xa07078: ldp             fp, lr, [SP], #0x10
    // 0xa0707c: ret
    //     0xa0707c: ret             
    // 0xa07080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa07080: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa07084: b               #0xa06f1c
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectAnnotation) {
    // ** addr: 0xa07088, size: 0x4c
    // 0xa07088: EnterFrame
    //     0xa07088: stp             fp, lr, [SP, #-0x10]!
    //     0xa0708c: mov             fp, SP
    // 0xa07090: CheckStackOverflow
    //     0xa07090: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa07094: cmp             SP, x16
    //     0xa07098: b.ls            #0xa070cc
    // 0xa0709c: ldr             x16, [fp, #0x10]
    // 0xa070a0: SaveReg r16
    //     0xa070a0: str             x16, [SP, #-8]!
    // 0xa070a4: r4 = 0
    //     0xa070a4: mov             x4, #0
    // 0xa070a8: ldr             x0, [SP]
    // 0xa070ac: r16 = UnlinkedCall_0x4aeefc
    //     0xa070ac: add             x16, PP, #7, lsl #12  ; [pp+0x7e20] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xa070b0: add             x16, x16, #0xe20
    // 0xa070b4: ldp             x5, lr, [x16]
    // 0xa070b8: blr             lr
    // 0xa070bc: add             SP, SP, #8
    // 0xa070c0: LeaveFrame
    //     0xa070c0: mov             SP, fp
    //     0xa070c4: ldp             fp, lr, [SP], #0x10
    // 0xa070c8: ret
    //     0xa070c8: ret             
    // 0xa070cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa070cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa070d0: b               #0xa0709c
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectArgument) {
    // ** addr: 0xa070d4, size: 0x3c
    // 0xa070d4: EnterFrame
    //     0xa070d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa070d8: mov             fp, SP
    // 0xa070dc: CheckStackOverflow
    //     0xa070dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa070e0: cmp             SP, x16
    //     0xa070e4: b.ls            #0xa07108
    // 0xa070e8: ldr             x16, [fp, #0x10]
    // 0xa070ec: SaveReg r16
    //     0xa070ec: str             x16, [SP, #-8]!
    // 0xa070f0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa070f0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa070f4: r0 = toXml()
    //     0xa070f4: bl              #0xa06a00  ; [package:dbus/src/dbus_introspect.dart] DBusIntrospectArgument::toXml
    // 0xa070f8: add             SP, SP, #8
    // 0xa070fc: LeaveFrame
    //     0xa070fc: mov             SP, fp
    //     0xa07100: ldp             fp, lr, [SP], #0x10
    // 0xa07104: ret
    //     0xa07104: ret             
    // 0xa07108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa07108: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0710c: b               #0xa070e8
  }
}

// class id: 4619, size: 0x1c, field offset: 0x8
class DBusIntrospectInterface extends Object {

  _ toXml(/* No info */) {
    // ** addr: 0xa064f8, size: 0x204
    // 0xa064f8: EnterFrame
    //     0xa064f8: stp             fp, lr, [SP, #-0x10]!
    //     0xa064fc: mov             fp, SP
    // 0xa06500: AllocStack(0x28)
    //     0xa06500: sub             SP, SP, #0x28
    // 0xa06504: CheckStackOverflow
    //     0xa06504: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa06508: cmp             SP, x16
    //     0xa0650c: b.ls            #0xa066f4
    // 0xa06510: r16 = <XmlNode>
    //     0xa06510: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06514: stp             xzr, x16, [SP, #-0x10]!
    // 0xa06518: r0 = _GrowableList()
    //     0xa06518: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa0651c: add             SP, SP, #0x10
    // 0xa06520: mov             x3, x0
    // 0xa06524: ldr             x0, [fp, #0x10]
    // 0xa06528: stur            x3, [fp, #-0x10]
    // 0xa0652c: LoadField: r4 = r0->field_b
    //     0xa0652c: ldur            w4, [x0, #0xb]
    // 0xa06530: DecompressPointer r4
    //     0xa06530: add             x4, x4, HEAP, lsl #32
    // 0xa06534: stur            x4, [fp, #-8]
    // 0xa06538: r1 = Function '<anonymous closure>':.
    //     0xa06538: ldr             x1, [PP, #0x7d40]  ; [pp+0x7d40] AnonymousClosure: (0xa06ecc), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectInterface::toXml (0xa064f8)
    // 0xa0653c: r2 = Null
    //     0xa0653c: mov             x2, NULL
    // 0xa06540: r0 = AllocateClosure()
    //     0xa06540: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa06544: r16 = <XmlNode>
    //     0xa06544: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06548: ldur            lr, [fp, #-8]
    // 0xa0654c: stp             lr, x16, [SP, #-0x10]!
    // 0xa06550: SaveReg r0
    //     0xa06550: str             x0, [SP, #-8]!
    // 0xa06554: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa06554: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa06558: r0 = map()
    //     0xa06558: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa0655c: add             SP, SP, #0x18
    // 0xa06560: ldur            x16, [fp, #-0x10]
    // 0xa06564: stp             x0, x16, [SP, #-0x10]!
    // 0xa06568: r0 = addAll()
    //     0xa06568: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa0656c: add             SP, SP, #0x10
    // 0xa06570: ldr             x0, [fp, #0x10]
    // 0xa06574: LoadField: r3 = r0->field_f
    //     0xa06574: ldur            w3, [x0, #0xf]
    // 0xa06578: DecompressPointer r3
    //     0xa06578: add             x3, x3, HEAP, lsl #32
    // 0xa0657c: stur            x3, [fp, #-8]
    // 0xa06580: r1 = Function '<anonymous closure>':.
    //     0xa06580: ldr             x1, [PP, #0x7d48]  ; [pp+0x7d48] AnonymousClosure: (0xa067b8), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectInterface::toXml (0xa064f8)
    // 0xa06584: r2 = Null
    //     0xa06584: mov             x2, NULL
    // 0xa06588: r0 = AllocateClosure()
    //     0xa06588: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0658c: r16 = <XmlNode>
    //     0xa0658c: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06590: ldur            lr, [fp, #-8]
    // 0xa06594: stp             lr, x16, [SP, #-0x10]!
    // 0xa06598: SaveReg r0
    //     0xa06598: str             x0, [SP, #-8]!
    // 0xa0659c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0659c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa065a0: r0 = map()
    //     0xa065a0: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa065a4: add             SP, SP, #0x18
    // 0xa065a8: ldur            x16, [fp, #-0x10]
    // 0xa065ac: stp             x0, x16, [SP, #-0x10]!
    // 0xa065b0: r0 = addAll()
    //     0xa065b0: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa065b4: add             SP, SP, #0x10
    // 0xa065b8: r1 = Function '<anonymous closure>':.
    //     0xa065b8: ldr             x1, [PP, #0x7d50]  ; [pp+0x7d50] AnonymousClosure: (0xa0676c), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectInterface::toXml (0xa064f8)
    // 0xa065bc: r2 = Null
    //     0xa065bc: mov             x2, NULL
    // 0xa065c0: r0 = AllocateClosure()
    //     0xa065c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa065c4: r16 = <XmlNode>
    //     0xa065c4: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa065c8: r30 = const []
    //     0xa065c8: ldr             lr, [PP, #0x7d58]  ; [pp+0x7d58] List<DBusIntrospectProperty>(0)
    // 0xa065cc: stp             lr, x16, [SP, #-0x10]!
    // 0xa065d0: SaveReg r0
    //     0xa065d0: str             x0, [SP, #-8]!
    // 0xa065d4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa065d4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa065d8: r0 = map()
    //     0xa065d8: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa065dc: add             SP, SP, #0x18
    // 0xa065e0: ldur            x16, [fp, #-0x10]
    // 0xa065e4: stp             x0, x16, [SP, #-0x10]!
    // 0xa065e8: r0 = addAll()
    //     0xa065e8: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa065ec: add             SP, SP, #0x10
    // 0xa065f0: r1 = Function '<anonymous closure>':.
    //     0xa065f0: ldr             x1, [PP, #0x7d60]  ; [pp+0x7d60] AnonymousClosure: (0xa06720), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectInterface::toXml (0xa064f8)
    // 0xa065f4: r2 = Null
    //     0xa065f4: mov             x2, NULL
    // 0xa065f8: r0 = AllocateClosure()
    //     0xa065f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa065fc: r16 = <XmlNode>
    //     0xa065fc: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06600: r30 = const []
    //     0xa06600: ldr             lr, [PP, #0x7d68]  ; [pp+0x7d68] List<DBusIntrospectAnnotation>(0)
    // 0xa06604: stp             lr, x16, [SP, #-0x10]!
    // 0xa06608: SaveReg r0
    //     0xa06608: str             x0, [SP, #-8]!
    // 0xa0660c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0660c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa06610: r0 = map()
    //     0xa06610: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa06614: add             SP, SP, #0x18
    // 0xa06618: ldur            x16, [fp, #-0x10]
    // 0xa0661c: stp             x0, x16, [SP, #-0x10]!
    // 0xa06620: r0 = addAll()
    //     0xa06620: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa06624: add             SP, SP, #0x10
    // 0xa06628: r16 = "interface"
    //     0xa06628: ldr             x16, [PP, #0x508]  ; [pp+0x508] "interface"
    // 0xa0662c: stp             x16, NULL, [SP, #-0x10]!
    // 0xa06630: r0 = XmlName()
    //     0xa06630: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa06634: add             SP, SP, #0x10
    // 0xa06638: stur            x0, [fp, #-8]
    // 0xa0663c: r16 = "name"
    //     0xa0663c: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xa06640: stp             x16, NULL, [SP, #-0x10]!
    // 0xa06644: r0 = XmlName()
    //     0xa06644: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa06648: add             SP, SP, #0x10
    // 0xa0664c: mov             x1, x0
    // 0xa06650: ldr             x0, [fp, #0x10]
    // 0xa06654: stur            x1, [fp, #-0x20]
    // 0xa06658: LoadField: r2 = r0->field_7
    //     0xa06658: ldur            w2, [x0, #7]
    // 0xa0665c: DecompressPointer r2
    //     0xa0665c: add             x2, x2, HEAP, lsl #32
    // 0xa06660: stur            x2, [fp, #-0x18]
    // 0xa06664: r0 = XmlAttribute()
    //     0xa06664: bl              #0x4fb438  ; AllocateXmlAttributeStub -> XmlAttribute (size=0x18)
    // 0xa06668: stur            x0, [fp, #-0x28]
    // 0xa0666c: ldur            x16, [fp, #-0x20]
    // 0xa06670: stp             x16, x0, [SP, #-0x10]!
    // 0xa06674: ldur            x16, [fp, #-0x18]
    // 0xa06678: SaveReg r16
    //     0xa06678: str             x16, [SP, #-8]!
    // 0xa0667c: r0 = XmlAttribute()
    //     0xa0667c: bl              #0x4fb3a0  ; [package:xml/src/xml/nodes/attribute.dart] XmlAttribute::XmlAttribute
    // 0xa06680: add             SP, SP, #0x18
    // 0xa06684: r1 = Null
    //     0xa06684: mov             x1, NULL
    // 0xa06688: r2 = 2
    //     0xa06688: mov             x2, #2
    // 0xa0668c: r0 = AllocateArray()
    //     0xa0668c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa06690: mov             x2, x0
    // 0xa06694: ldur            x0, [fp, #-0x28]
    // 0xa06698: stur            x2, [fp, #-0x18]
    // 0xa0669c: StoreField: r2->field_f = r0
    //     0xa0669c: stur            w0, [x2, #0xf]
    // 0xa066a0: r1 = <XmlAttribute>
    //     0xa066a0: ldr             x1, [PP, #0x7d18]  ; [pp+0x7d18] TypeArguments: <XmlAttribute>
    // 0xa066a4: r0 = AllocateGrowableArray()
    //     0xa066a4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa066a8: mov             x1, x0
    // 0xa066ac: ldur            x0, [fp, #-0x18]
    // 0xa066b0: stur            x1, [fp, #-0x20]
    // 0xa066b4: StoreField: r1->field_f = r0
    //     0xa066b4: stur            w0, [x1, #0xf]
    // 0xa066b8: r0 = 2
    //     0xa066b8: mov             x0, #2
    // 0xa066bc: StoreField: r1->field_b = r0
    //     0xa066bc: stur            w0, [x1, #0xb]
    // 0xa066c0: r0 = XmlElement()
    //     0xa066c0: bl              #0x4fba78  ; AllocateXmlElementStub -> XmlElement (size=0x1c)
    // 0xa066c4: stur            x0, [fp, #-0x18]
    // 0xa066c8: ldur            x16, [fp, #-8]
    // 0xa066cc: stp             x16, x0, [SP, #-0x10]!
    // 0xa066d0: ldur            x16, [fp, #-0x20]
    // 0xa066d4: ldur            lr, [fp, #-0x10]
    // 0xa066d8: stp             lr, x16, [SP, #-0x10]!
    // 0xa066dc: r0 = XmlElement()
    //     0xa066dc: bl              #0x4fb444  ; [package:xml/src/xml/nodes/element.dart] XmlElement::XmlElement
    // 0xa066e0: add             SP, SP, #0x20
    // 0xa066e4: ldur            x0, [fp, #-0x18]
    // 0xa066e8: LeaveFrame
    //     0xa066e8: mov             SP, fp
    //     0xa066ec: ldp             fp, lr, [SP], #0x10
    // 0xa066f0: ret
    //     0xa066f0: ret             
    // 0xa066f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa066f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa066f8: b               #0xa06510
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectAnnotation) {
    // ** addr: 0xa06720, size: 0x4c
    // 0xa06720: EnterFrame
    //     0xa06720: stp             fp, lr, [SP, #-0x10]!
    //     0xa06724: mov             fp, SP
    // 0xa06728: CheckStackOverflow
    //     0xa06728: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0672c: cmp             SP, x16
    //     0xa06730: b.ls            #0xa06764
    // 0xa06734: ldr             x16, [fp, #0x10]
    // 0xa06738: SaveReg r16
    //     0xa06738: str             x16, [SP, #-8]!
    // 0xa0673c: r4 = 0
    //     0xa0673c: mov             x4, #0
    // 0xa06740: ldr             x0, [SP]
    // 0xa06744: r16 = UnlinkedCall_0x4aeefc
    //     0xa06744: add             x16, PP, #7, lsl #12  ; [pp+0x7d70] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xa06748: add             x16, x16, #0xd70
    // 0xa0674c: ldp             x5, lr, [x16]
    // 0xa06750: blr             lr
    // 0xa06754: add             SP, SP, #8
    // 0xa06758: LeaveFrame
    //     0xa06758: mov             SP, fp
    //     0xa0675c: ldp             fp, lr, [SP], #0x10
    // 0xa06760: ret
    //     0xa06760: ret             
    // 0xa06764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa06764: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa06768: b               #0xa06734
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectProperty) {
    // ** addr: 0xa0676c, size: 0x4c
    // 0xa0676c: EnterFrame
    //     0xa0676c: stp             fp, lr, [SP, #-0x10]!
    //     0xa06770: mov             fp, SP
    // 0xa06774: CheckStackOverflow
    //     0xa06774: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa06778: cmp             SP, x16
    //     0xa0677c: b.ls            #0xa067b0
    // 0xa06780: ldr             x16, [fp, #0x10]
    // 0xa06784: SaveReg r16
    //     0xa06784: str             x16, [SP, #-8]!
    // 0xa06788: r4 = 0
    //     0xa06788: mov             x4, #0
    // 0xa0678c: ldr             x0, [SP]
    // 0xa06790: r16 = UnlinkedCall_0x4aeefc
    //     0xa06790: add             x16, PP, #7, lsl #12  ; [pp+0x7d80] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xa06794: add             x16, x16, #0xd80
    // 0xa06798: ldp             x5, lr, [x16]
    // 0xa0679c: blr             lr
    // 0xa067a0: add             SP, SP, #8
    // 0xa067a4: LeaveFrame
    //     0xa067a4: mov             SP, fp
    //     0xa067a8: ldp             fp, lr, [SP], #0x10
    // 0xa067ac: ret
    //     0xa067ac: ret             
    // 0xa067b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa067b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa067b4: b               #0xa06780
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectSignal) {
    // ** addr: 0xa067b8, size: 0x38
    // 0xa067b8: EnterFrame
    //     0xa067b8: stp             fp, lr, [SP, #-0x10]!
    //     0xa067bc: mov             fp, SP
    // 0xa067c0: CheckStackOverflow
    //     0xa067c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa067c4: cmp             SP, x16
    //     0xa067c8: b.ls            #0xa067e8
    // 0xa067cc: ldr             x16, [fp, #0x10]
    // 0xa067d0: SaveReg r16
    //     0xa067d0: str             x16, [SP, #-8]!
    // 0xa067d4: r0 = toXml()
    //     0xa067d4: bl              #0xa067f0  ; [package:dbus/src/dbus_introspect.dart] DBusIntrospectSignal::toXml
    // 0xa067d8: add             SP, SP, #8
    // 0xa067dc: LeaveFrame
    //     0xa067dc: mov             SP, fp
    //     0xa067e0: ldp             fp, lr, [SP], #0x10
    // 0xa067e4: ret
    //     0xa067e4: ret             
    // 0xa067e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa067e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa067ec: b               #0xa067cc
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectMethod) {
    // ** addr: 0xa06ecc, size: 0x38
    // 0xa06ecc: EnterFrame
    //     0xa06ecc: stp             fp, lr, [SP, #-0x10]!
    //     0xa06ed0: mov             fp, SP
    // 0xa06ed4: CheckStackOverflow
    //     0xa06ed4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa06ed8: cmp             SP, x16
    //     0xa06edc: b.ls            #0xa06efc
    // 0xa06ee0: ldr             x16, [fp, #0x10]
    // 0xa06ee4: SaveReg r16
    //     0xa06ee4: str             x16, [SP, #-8]!
    // 0xa06ee8: r0 = toXml()
    //     0xa06ee8: bl              #0xa06f04  ; [package:dbus/src/dbus_introspect.dart] DBusIntrospectMethod::toXml
    // 0xa06eec: add             SP, SP, #8
    // 0xa06ef0: LeaveFrame
    //     0xa06ef0: mov             SP, fp
    //     0xa06ef4: ldp             fp, lr, [SP], #0x10
    // 0xa06ef8: ret
    //     0xa06ef8: ret             
    // 0xa06efc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa06efc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa06f00: b               #0xa06ee0
  }
}

// class id: 4620, size: 0x14, field offset: 0x8
class DBusIntrospectNode extends Object {

  _ toXml(/* No info */) {
    // ** addr: 0xa06234, size: 0x210
    // 0xa06234: EnterFrame
    //     0xa06234: stp             fp, lr, [SP, #-0x10]!
    //     0xa06238: mov             fp, SP
    // 0xa0623c: AllocStack(0x20)
    //     0xa0623c: sub             SP, SP, #0x20
    // 0xa06240: CheckStackOverflow
    //     0xa06240: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa06244: cmp             SP, x16
    //     0xa06248: b.ls            #0xa06438
    // 0xa0624c: r16 = <XmlAttribute>
    //     0xa0624c: ldr             x16, [PP, #0x7d18]  ; [pp+0x7d18] TypeArguments: <XmlAttribute>
    // 0xa06250: stp             xzr, x16, [SP, #-0x10]!
    // 0xa06254: r0 = _GrowableList()
    //     0xa06254: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa06258: add             SP, SP, #0x10
    // 0xa0625c: mov             x1, x0
    // 0xa06260: ldr             x0, [fp, #0x10]
    // 0xa06264: stur            x1, [fp, #-0x10]
    // 0xa06268: LoadField: r2 = r0->field_7
    //     0xa06268: ldur            w2, [x0, #7]
    // 0xa0626c: DecompressPointer r2
    //     0xa0626c: add             x2, x2, HEAP, lsl #32
    // 0xa06270: stur            x2, [fp, #-8]
    // 0xa06274: cmp             w2, NULL
    // 0xa06278: b.eq            #0xa06340
    // 0xa0627c: r16 = "name"
    //     0xa0627c: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xa06280: stp             x16, NULL, [SP, #-0x10]!
    // 0xa06284: r0 = XmlName()
    //     0xa06284: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa06288: add             SP, SP, #0x10
    // 0xa0628c: stur            x0, [fp, #-0x18]
    // 0xa06290: r0 = XmlAttribute()
    //     0xa06290: bl              #0x4fb438  ; AllocateXmlAttributeStub -> XmlAttribute (size=0x18)
    // 0xa06294: stur            x0, [fp, #-0x20]
    // 0xa06298: ldur            x16, [fp, #-0x18]
    // 0xa0629c: stp             x16, x0, [SP, #-0x10]!
    // 0xa062a0: ldur            x16, [fp, #-8]
    // 0xa062a4: SaveReg r16
    //     0xa062a4: str             x16, [SP, #-8]!
    // 0xa062a8: r0 = XmlAttribute()
    //     0xa062a8: bl              #0x4fb3a0  ; [package:xml/src/xml/nodes/attribute.dart] XmlAttribute::XmlAttribute
    // 0xa062ac: add             SP, SP, #0x18
    // 0xa062b0: ldur            x0, [fp, #-0x10]
    // 0xa062b4: LoadField: r1 = r0->field_b
    //     0xa062b4: ldur            w1, [x0, #0xb]
    // 0xa062b8: DecompressPointer r1
    //     0xa062b8: add             x1, x1, HEAP, lsl #32
    // 0xa062bc: stur            x1, [fp, #-8]
    // 0xa062c0: LoadField: r2 = r0->field_f
    //     0xa062c0: ldur            w2, [x0, #0xf]
    // 0xa062c4: DecompressPointer r2
    //     0xa062c4: add             x2, x2, HEAP, lsl #32
    // 0xa062c8: LoadField: r3 = r2->field_b
    //     0xa062c8: ldur            w3, [x2, #0xb]
    // 0xa062cc: DecompressPointer r3
    //     0xa062cc: add             x3, x3, HEAP, lsl #32
    // 0xa062d0: cmp             w1, w3
    // 0xa062d4: b.ne            #0xa062e4
    // 0xa062d8: SaveReg r0
    //     0xa062d8: str             x0, [SP, #-8]!
    // 0xa062dc: r0 = _growToNextCapacity()
    //     0xa062dc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa062e0: add             SP, SP, #8
    // 0xa062e4: ldur            x2, [fp, #-0x10]
    // 0xa062e8: ldur            x0, [fp, #-8]
    // 0xa062ec: r3 = LoadInt32Instr(r0)
    //     0xa062ec: sbfx            x3, x0, #1, #0x1f
    // 0xa062f0: add             x0, x3, #1
    // 0xa062f4: lsl             x1, x0, #1
    // 0xa062f8: StoreField: r2->field_b = r1
    //     0xa062f8: stur            w1, [x2, #0xb]
    // 0xa062fc: mov             x1, x3
    // 0xa06300: cmp             x1, x0
    // 0xa06304: b.hs            #0xa06440
    // 0xa06308: LoadField: r1 = r2->field_f
    //     0xa06308: ldur            w1, [x2, #0xf]
    // 0xa0630c: DecompressPointer r1
    //     0xa0630c: add             x1, x1, HEAP, lsl #32
    // 0xa06310: ldur            x0, [fp, #-0x20]
    // 0xa06314: ArrayStore: r1[r3] = r0  ; List_4
    //     0xa06314: add             x25, x1, x3, lsl #2
    //     0xa06318: add             x25, x25, #0xf
    //     0xa0631c: str             w0, [x25]
    //     0xa06320: tbz             w0, #0, #0xa0633c
    //     0xa06324: ldurb           w16, [x1, #-1]
    //     0xa06328: ldurb           w17, [x0, #-1]
    //     0xa0632c: and             x16, x17, x16, lsr #2
    //     0xa06330: tst             x16, HEAP, lsr #32
    //     0xa06334: b.eq            #0xa0633c
    //     0xa06338: bl              #0xd67e5c
    // 0xa0633c: b               #0xa06344
    // 0xa06340: mov             x2, x1
    // 0xa06344: ldr             x0, [fp, #0x10]
    // 0xa06348: r16 = <XmlNode>
    //     0xa06348: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa0634c: stp             xzr, x16, [SP, #-0x10]!
    // 0xa06350: r0 = _GrowableList()
    //     0xa06350: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa06354: add             SP, SP, #0x10
    // 0xa06358: mov             x3, x0
    // 0xa0635c: ldr             x0, [fp, #0x10]
    // 0xa06360: stur            x3, [fp, #-0x18]
    // 0xa06364: LoadField: r4 = r0->field_b
    //     0xa06364: ldur            w4, [x0, #0xb]
    // 0xa06368: DecompressPointer r4
    //     0xa06368: add             x4, x4, HEAP, lsl #32
    // 0xa0636c: stur            x4, [fp, #-8]
    // 0xa06370: r1 = Function '<anonymous closure>':.
    //     0xa06370: ldr             x1, [PP, #0x7d28]  ; [pp+0x7d28] AnonymousClosure: (0xa064c0), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectNode::toXml (0xa06234)
    // 0xa06374: r2 = Null
    //     0xa06374: mov             x2, NULL
    // 0xa06378: r0 = AllocateClosure()
    //     0xa06378: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0637c: r16 = <XmlNode>
    //     0xa0637c: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa06380: ldur            lr, [fp, #-8]
    // 0xa06384: stp             lr, x16, [SP, #-0x10]!
    // 0xa06388: SaveReg r0
    //     0xa06388: str             x0, [SP, #-8]!
    // 0xa0638c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0638c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa06390: r0 = map()
    //     0xa06390: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa06394: add             SP, SP, #0x18
    // 0xa06398: ldur            x16, [fp, #-0x18]
    // 0xa0639c: stp             x0, x16, [SP, #-0x10]!
    // 0xa063a0: r0 = addAll()
    //     0xa063a0: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa063a4: add             SP, SP, #0x10
    // 0xa063a8: ldr             x0, [fp, #0x10]
    // 0xa063ac: LoadField: r3 = r0->field_f
    //     0xa063ac: ldur            w3, [x0, #0xf]
    // 0xa063b0: DecompressPointer r3
    //     0xa063b0: add             x3, x3, HEAP, lsl #32
    // 0xa063b4: stur            x3, [fp, #-8]
    // 0xa063b8: r1 = Function '<anonymous closure>':.
    //     0xa063b8: ldr             x1, [PP, #0x7d30]  ; [pp+0x7d30] AnonymousClosure: (0xa06488), in [package:dbus/src/dbus_introspect.dart] DBusIntrospectNode::toXml (0xa06234)
    // 0xa063bc: r2 = Null
    //     0xa063bc: mov             x2, NULL
    // 0xa063c0: r0 = AllocateClosure()
    //     0xa063c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa063c4: r16 = <XmlNode>
    //     0xa063c4: ldr             x16, [PP, #0x7d20]  ; [pp+0x7d20] TypeArguments: <XmlNode>
    // 0xa063c8: ldur            lr, [fp, #-8]
    // 0xa063cc: stp             lr, x16, [SP, #-0x10]!
    // 0xa063d0: SaveReg r0
    //     0xa063d0: str             x0, [SP, #-8]!
    // 0xa063d4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa063d4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa063d8: r0 = map()
    //     0xa063d8: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xa063dc: add             SP, SP, #0x18
    // 0xa063e0: ldur            x16, [fp, #-0x18]
    // 0xa063e4: stp             x0, x16, [SP, #-0x10]!
    // 0xa063e8: r0 = addAll()
    //     0xa063e8: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xa063ec: add             SP, SP, #0x10
    // 0xa063f0: r16 = "node"
    //     0xa063f0: ldr             x16, [PP, #0x7d38]  ; [pp+0x7d38] "node"
    // 0xa063f4: stp             x16, NULL, [SP, #-0x10]!
    // 0xa063f8: r0 = XmlName()
    //     0xa063f8: bl              #0xa06468  ; [package:xml/src/xml/utils/name.dart] XmlName::XmlName
    // 0xa063fc: add             SP, SP, #0x10
    // 0xa06400: stur            x0, [fp, #-8]
    // 0xa06404: r0 = XmlElement()
    //     0xa06404: bl              #0x4fba78  ; AllocateXmlElementStub -> XmlElement (size=0x1c)
    // 0xa06408: stur            x0, [fp, #-0x20]
    // 0xa0640c: ldur            x16, [fp, #-8]
    // 0xa06410: stp             x16, x0, [SP, #-0x10]!
    // 0xa06414: ldur            x16, [fp, #-0x10]
    // 0xa06418: ldur            lr, [fp, #-0x18]
    // 0xa0641c: stp             lr, x16, [SP, #-0x10]!
    // 0xa06420: r0 = XmlElement()
    //     0xa06420: bl              #0x4fb444  ; [package:xml/src/xml/nodes/element.dart] XmlElement::XmlElement
    // 0xa06424: add             SP, SP, #0x20
    // 0xa06428: ldur            x0, [fp, #-0x20]
    // 0xa0642c: LeaveFrame
    //     0xa0642c: mov             SP, fp
    //     0xa06430: ldp             fp, lr, [SP], #0x10
    // 0xa06434: ret
    //     0xa06434: ret             
    // 0xa06438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa06438: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0643c: b               #0xa0624c
    // 0xa06440: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa06440: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectNode) {
    // ** addr: 0xa06488, size: 0x38
    // 0xa06488: EnterFrame
    //     0xa06488: stp             fp, lr, [SP, #-0x10]!
    //     0xa0648c: mov             fp, SP
    // 0xa06490: CheckStackOverflow
    //     0xa06490: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa06494: cmp             SP, x16
    //     0xa06498: b.ls            #0xa064b8
    // 0xa0649c: ldr             x16, [fp, #0x10]
    // 0xa064a0: SaveReg r16
    //     0xa064a0: str             x16, [SP, #-8]!
    // 0xa064a4: r0 = toXml()
    //     0xa064a4: bl              #0xa06234  ; [package:dbus/src/dbus_introspect.dart] DBusIntrospectNode::toXml
    // 0xa064a8: add             SP, SP, #8
    // 0xa064ac: LeaveFrame
    //     0xa064ac: mov             SP, fp
    //     0xa064b0: ldp             fp, lr, [SP], #0x10
    // 0xa064b4: ret
    //     0xa064b4: ret             
    // 0xa064b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa064b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa064bc: b               #0xa0649c
  }
  [closure] XmlNode <anonymous closure>(dynamic, DBusIntrospectInterface) {
    // ** addr: 0xa064c0, size: 0x38
    // 0xa064c0: EnterFrame
    //     0xa064c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa064c4: mov             fp, SP
    // 0xa064c8: CheckStackOverflow
    //     0xa064c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa064cc: cmp             SP, x16
    //     0xa064d0: b.ls            #0xa064f0
    // 0xa064d4: ldr             x16, [fp, #0x10]
    // 0xa064d8: SaveReg r16
    //     0xa064d8: str             x16, [SP, #-8]!
    // 0xa064dc: r0 = toXml()
    //     0xa064dc: bl              #0xa064f8  ; [package:dbus/src/dbus_introspect.dart] DBusIntrospectInterface::toXml
    // 0xa064e0: add             SP, SP, #8
    // 0xa064e4: LeaveFrame
    //     0xa064e4: mov             SP, fp
    //     0xa064e8: ldp             fp, lr, [SP], #0x10
    // 0xa064ec: ret
    //     0xa064ec: ret             
    // 0xa064f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa064f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa064f4: b               #0xa064d4
  }
  _ toString(/* No info */) {
    // ** addr: 0xacfbe0, size: 0x2b4
    // 0xacfbe0: EnterFrame
    //     0xacfbe0: stp             fp, lr, [SP, #-0x10]!
    //     0xacfbe4: mov             fp, SP
    // 0xacfbe8: AllocStack(0x10)
    //     0xacfbe8: sub             SP, SP, #0x10
    // 0xacfbec: CheckStackOverflow
    //     0xacfbec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xacfbf0: cmp             SP, x16
    //     0xacfbf4: b.ls            #0xacfe8c
    // 0xacfbf8: r1 = Null
    //     0xacfbf8: mov             x1, NULL
    // 0xacfbfc: r2 = 12
    //     0xacfbfc: mov             x2, #0xc
    // 0xacfc00: r0 = AllocateArray()
    //     0xacfc00: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacfc04: stur            x0, [fp, #-8]
    // 0xacfc08: r17 = "name"
    //     0xacfc08: ldr             x17, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xacfc0c: StoreField: r0->field_f = r17
    //     0xacfc0c: stur            w17, [x0, #0xf]
    // 0xacfc10: ldr             x1, [fp, #0x10]
    // 0xacfc14: LoadField: r2 = r1->field_7
    //     0xacfc14: ldur            w2, [x1, #7]
    // 0xacfc18: DecompressPointer r2
    //     0xacfc18: add             x2, x2, HEAP, lsl #32
    // 0xacfc1c: cmp             w2, NULL
    // 0xacfc20: b.eq            #0xacfc34
    // 0xacfc24: SaveReg r2
    //     0xacfc24: str             x2, [SP, #-8]!
    // 0xacfc28: r0 = _interpolateSingle()
    //     0xacfc28: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0xacfc2c: add             SP, SP, #8
    // 0xacfc30: b               #0xacfc38
    // 0xacfc34: r0 = Null
    //     0xacfc34: mov             x0, NULL
    // 0xacfc38: ldr             x3, [fp, #0x10]
    // 0xacfc3c: ldur            x2, [fp, #-8]
    // 0xacfc40: mov             x1, x2
    // 0xacfc44: ArrayStore: r1[1] = r0  ; List_4
    //     0xacfc44: add             x25, x1, #0x13
    //     0xacfc48: str             w0, [x25]
    //     0xacfc4c: tbz             w0, #0, #0xacfc68
    //     0xacfc50: ldurb           w16, [x1, #-1]
    //     0xacfc54: ldurb           w17, [x0, #-1]
    //     0xacfc58: and             x16, x17, x16, lsr #2
    //     0xacfc5c: tst             x16, HEAP, lsr #32
    //     0xacfc60: b.eq            #0xacfc68
    //     0xacfc64: bl              #0xd67e5c
    // 0xacfc68: r17 = "interfaces"
    //     0xacfc68: add             x17, PP, #0xb, lsl #12  ; [pp+0xb548] "interfaces"
    //     0xacfc6c: ldr             x17, [x17, #0x548]
    // 0xacfc70: StoreField: r2->field_17 = r17
    //     0xacfc70: stur            w17, [x2, #0x17]
    // 0xacfc74: LoadField: r1 = r3->field_b
    //     0xacfc74: ldur            w1, [x3, #0xb]
    // 0xacfc78: DecompressPointer r1
    //     0xacfc78: add             x1, x1, HEAP, lsl #32
    // 0xacfc7c: stur            x1, [fp, #-0x10]
    // 0xacfc80: r0 = LoadClassIdInstr(r1)
    //     0xacfc80: ldur            x0, [x1, #-1]
    //     0xacfc84: ubfx            x0, x0, #0xc, #0x14
    // 0xacfc88: SaveReg r1
    //     0xacfc88: str             x1, [SP, #-8]!
    // 0xacfc8c: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0xacfc8c: mov             x17, #0xcc6c
    //     0xacfc90: add             lr, x0, x17
    //     0xacfc94: ldr             lr, [x21, lr, lsl #3]
    //     0xacfc98: blr             lr
    // 0xacfc9c: add             SP, SP, #8
    // 0xacfca0: tbnz            w0, #4, #0xacfcd4
    // 0xacfca4: ldur            x0, [fp, #-0x10]
    // 0xacfca8: r1 = LoadClassIdInstr(r0)
    //     0xacfca8: ldur            x1, [x0, #-1]
    //     0xacfcac: ubfx            x1, x1, #0xc, #0x14
    // 0xacfcb0: SaveReg r0
    //     0xacfcb0: str             x0, [SP, #-8]!
    // 0xacfcb4: mov             x0, x1
    // 0xacfcb8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xacfcb8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xacfcbc: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xacfcbc: mov             x17, #0x3f73
    //     0xacfcc0: add             lr, x0, x17
    //     0xacfcc4: ldr             lr, [x21, lr, lsl #3]
    //     0xacfcc8: blr             lr
    // 0xacfccc: add             SP, SP, #8
    // 0xacfcd0: b               #0xacfcd8
    // 0xacfcd4: r0 = Null
    //     0xacfcd4: mov             x0, NULL
    // 0xacfcd8: ldr             x3, [fp, #0x10]
    // 0xacfcdc: ldur            x2, [fp, #-8]
    // 0xacfce0: mov             x1, x2
    // 0xacfce4: ArrayStore: r1[3] = r0  ; List_4
    //     0xacfce4: add             x25, x1, #0x1b
    //     0xacfce8: str             w0, [x25]
    //     0xacfcec: tbz             w0, #0, #0xacfd08
    //     0xacfcf0: ldurb           w16, [x1, #-1]
    //     0xacfcf4: ldurb           w17, [x0, #-1]
    //     0xacfcf8: and             x16, x17, x16, lsr #2
    //     0xacfcfc: tst             x16, HEAP, lsr #32
    //     0xacfd00: b.eq            #0xacfd08
    //     0xacfd04: bl              #0xd67e5c
    // 0xacfd08: r17 = "children"
    //     0xacfd08: ldr             x17, [PP, #0x7868]  ; [pp+0x7868] "children"
    // 0xacfd0c: StoreField: r2->field_1f = r17
    //     0xacfd0c: stur            w17, [x2, #0x1f]
    // 0xacfd10: LoadField: r1 = r3->field_f
    //     0xacfd10: ldur            w1, [x3, #0xf]
    // 0xacfd14: DecompressPointer r1
    //     0xacfd14: add             x1, x1, HEAP, lsl #32
    // 0xacfd18: stur            x1, [fp, #-0x10]
    // 0xacfd1c: r0 = LoadClassIdInstr(r1)
    //     0xacfd1c: ldur            x0, [x1, #-1]
    //     0xacfd20: ubfx            x0, x0, #0xc, #0x14
    // 0xacfd24: SaveReg r1
    //     0xacfd24: str             x1, [SP, #-8]!
    // 0xacfd28: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0xacfd28: mov             x17, #0xcc6c
    //     0xacfd2c: add             lr, x0, x17
    //     0xacfd30: ldr             lr, [x21, lr, lsl #3]
    //     0xacfd34: blr             lr
    // 0xacfd38: add             SP, SP, #8
    // 0xacfd3c: tbnz            w0, #4, #0xacfd70
    // 0xacfd40: ldur            x0, [fp, #-0x10]
    // 0xacfd44: r1 = LoadClassIdInstr(r0)
    //     0xacfd44: ldur            x1, [x0, #-1]
    //     0xacfd48: ubfx            x1, x1, #0xc, #0x14
    // 0xacfd4c: SaveReg r0
    //     0xacfd4c: str             x0, [SP, #-8]!
    // 0xacfd50: mov             x0, x1
    // 0xacfd54: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xacfd54: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xacfd58: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xacfd58: mov             x17, #0x3f73
    //     0xacfd5c: add             lr, x0, x17
    //     0xacfd60: ldr             lr, [x21, lr, lsl #3]
    //     0xacfd64: blr             lr
    // 0xacfd68: add             SP, SP, #8
    // 0xacfd6c: b               #0xacfd74
    // 0xacfd70: r0 = Null
    //     0xacfd70: mov             x0, NULL
    // 0xacfd74: ldur            x1, [fp, #-8]
    // 0xacfd78: ArrayStore: r1[5] = r0  ; List_4
    //     0xacfd78: add             x25, x1, #0x23
    //     0xacfd7c: str             w0, [x25]
    //     0xacfd80: tbz             w0, #0, #0xacfd9c
    //     0xacfd84: ldurb           w16, [x1, #-1]
    //     0xacfd88: ldurb           w17, [x0, #-1]
    //     0xacfd8c: and             x16, x17, x16, lsr #2
    //     0xacfd90: tst             x16, HEAP, lsr #32
    //     0xacfd94: b.eq            #0xacfd9c
    //     0xacfd98: bl              #0xd67e5c
    // 0xacfd9c: r16 = <String, String?>
    //     0xacfd9c: ldr             x16, [PP, #0x7650]  ; [pp+0x7650] TypeArguments: <String, String?>
    // 0xacfda0: ldur            lr, [fp, #-8]
    // 0xacfda4: stp             lr, x16, [SP, #-0x10]!
    // 0xacfda8: r0 = Map._fromLiteral()
    //     0xacfda8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xacfdac: add             SP, SP, #0x10
    // 0xacfdb0: stur            x0, [fp, #-8]
    // 0xacfdb4: r1 = 1
    //     0xacfdb4: mov             x1, #1
    // 0xacfdb8: r0 = AllocateContext()
    //     0xacfdb8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xacfdbc: mov             x1, x0
    // 0xacfdc0: ldur            x0, [fp, #-8]
    // 0xacfdc4: stur            x1, [fp, #-0x10]
    // 0xacfdc8: StoreField: r1->field_f = r0
    //     0xacfdc8: stur            w0, [x1, #0xf]
    // 0xacfdcc: SaveReg r0
    //     0xacfdcc: str             x0, [SP, #-8]!
    // 0xacfdd0: r0 = keys()
    //     0xacfdd0: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0xacfdd4: add             SP, SP, #8
    // 0xacfdd8: ldur            x2, [fp, #-0x10]
    // 0xacfddc: r1 = Function '<anonymous closure>':.
    //     0xacfddc: add             x1, PP, #0xb, lsl #12  ; [pp+0xb550] AnonymousClosure: (0xacff6c), in [package:dbus/src/dbus_match_rule.dart] DBusMatchRule::toString (0xacfff0)
    //     0xacfde0: ldr             x1, [x1, #0x550]
    // 0xacfde4: stur            x0, [fp, #-8]
    // 0xacfde8: r0 = AllocateClosure()
    //     0xacfde8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xacfdec: ldur            x16, [fp, #-8]
    // 0xacfdf0: stp             x0, x16, [SP, #-0x10]!
    // 0xacfdf4: r0 = where()
    //     0xacfdf4: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0xacfdf8: add             SP, SP, #0x10
    // 0xacfdfc: ldur            x2, [fp, #-0x10]
    // 0xacfe00: r1 = Function '<anonymous closure>':.
    //     0xacfe00: add             x1, PP, #0xb, lsl #12  ; [pp+0xb558] AnonymousClosure: (0xacfe94), in [package:dbus/src/dbus_message.dart] DBusMessage::toString (0xad0424)
    //     0xacfe04: ldr             x1, [x1, #0x558]
    // 0xacfe08: stur            x0, [fp, #-8]
    // 0xacfe0c: r0 = AllocateClosure()
    //     0xacfe0c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xacfe10: r16 = <String>
    //     0xacfe10: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xacfe14: ldur            lr, [fp, #-8]
    // 0xacfe18: stp             lr, x16, [SP, #-0x10]!
    // 0xacfe1c: SaveReg r0
    //     0xacfe1c: str             x0, [SP, #-8]!
    // 0xacfe20: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xacfe20: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xacfe24: r0 = map()
    //     0xacfe24: bl              #0x6ba568  ; [dart:_internal] WhereIterable::map
    // 0xacfe28: add             SP, SP, #0x18
    // 0xacfe2c: r16 = ", "
    //     0xacfe2c: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xacfe30: stp             x16, x0, [SP, #-0x10]!
    // 0xacfe34: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xacfe34: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xacfe38: r0 = join()
    //     0xacfe38: bl              #0x6a9d88  ; [dart:core] Iterable::join
    // 0xacfe3c: add             SP, SP, #0x10
    // 0xacfe40: r1 = Null
    //     0xacfe40: mov             x1, NULL
    // 0xacfe44: r2 = 8
    //     0xacfe44: mov             x2, #8
    // 0xacfe48: stur            x0, [fp, #-8]
    // 0xacfe4c: r0 = AllocateArray()
    //     0xacfe4c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xacfe50: r17 = DBusIntrospectNode
    //     0xacfe50: add             x17, PP, #0xb, lsl #12  ; [pp+0xb560] Type: DBusIntrospectNode
    //     0xacfe54: ldr             x17, [x17, #0x560]
    // 0xacfe58: StoreField: r0->field_f = r17
    //     0xacfe58: stur            w17, [x0, #0xf]
    // 0xacfe5c: r17 = "("
    //     0xacfe5c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xacfe60: StoreField: r0->field_13 = r17
    //     0xacfe60: stur            w17, [x0, #0x13]
    // 0xacfe64: ldur            x1, [fp, #-8]
    // 0xacfe68: StoreField: r0->field_17 = r1
    //     0xacfe68: stur            w1, [x0, #0x17]
    // 0xacfe6c: r17 = ")"
    //     0xacfe6c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xacfe70: StoreField: r0->field_1b = r17
    //     0xacfe70: stur            w17, [x0, #0x1b]
    // 0xacfe74: SaveReg r0
    //     0xacfe74: str             x0, [SP, #-8]!
    // 0xacfe78: r0 = _interpolate()
    //     0xacfe78: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xacfe7c: add             SP, SP, #8
    // 0xacfe80: LeaveFrame
    //     0xacfe80: mov             SP, fp
    //     0xacfe84: ldp             fp, lr, [SP], #0x10
    // 0xacfe88: ret
    //     0xacfe88: ret             
    // 0xacfe8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacfe8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacfe90: b               #0xacfbf8
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6e348, size: 0x108
    // 0xc6e348: EnterFrame
    //     0xc6e348: stp             fp, lr, [SP, #-0x10]!
    //     0xc6e34c: mov             fp, SP
    // 0xc6e350: CheckStackOverflow
    //     0xc6e350: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6e354: cmp             SP, x16
    //     0xc6e358: b.ls            #0xc6e448
    // 0xc6e35c: ldr             x1, [fp, #0x10]
    // 0xc6e360: cmp             w1, NULL
    // 0xc6e364: b.ne            #0xc6e378
    // 0xc6e368: r0 = false
    //     0xc6e368: add             x0, NULL, #0x30  ; false
    // 0xc6e36c: LeaveFrame
    //     0xc6e36c: mov             SP, fp
    //     0xc6e370: ldp             fp, lr, [SP], #0x10
    // 0xc6e374: ret
    //     0xc6e374: ret             
    // 0xc6e378: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6e378: mov             x0, #0x76
    //     0xc6e37c: tbz             w1, #0, #0xc6e38c
    //     0xc6e380: ldur            x0, [x1, #-1]
    //     0xc6e384: ubfx            x0, x0, #0xc, #0x14
    //     0xc6e388: lsl             x0, x0, #1
    // 0xc6e38c: r17 = 9240
    //     0xc6e38c: mov             x17, #0x2418
    // 0xc6e390: cmp             w0, w17
    // 0xc6e394: b.ne            #0xc6e438
    // 0xc6e398: ldr             x2, [fp, #0x18]
    // 0xc6e39c: LoadField: r0 = r1->field_7
    //     0xc6e39c: ldur            w0, [x1, #7]
    // 0xc6e3a0: DecompressPointer r0
    //     0xc6e3a0: add             x0, x0, HEAP, lsl #32
    // 0xc6e3a4: LoadField: r3 = r2->field_7
    //     0xc6e3a4: ldur            w3, [x2, #7]
    // 0xc6e3a8: DecompressPointer r3
    //     0xc6e3a8: add             x3, x3, HEAP, lsl #32
    // 0xc6e3ac: r4 = LoadClassIdInstr(r0)
    //     0xc6e3ac: ldur            x4, [x0, #-1]
    //     0xc6e3b0: ubfx            x4, x4, #0xc, #0x14
    // 0xc6e3b4: stp             x3, x0, [SP, #-0x10]!
    // 0xc6e3b8: mov             x0, x4
    // 0xc6e3bc: mov             lr, x0
    // 0xc6e3c0: ldr             lr, [x21, lr, lsl #3]
    // 0xc6e3c4: blr             lr
    // 0xc6e3c8: add             SP, SP, #0x10
    // 0xc6e3cc: tbnz            w0, #4, #0xc6e438
    // 0xc6e3d0: ldr             x1, [fp, #0x18]
    // 0xc6e3d4: ldr             x0, [fp, #0x10]
    // 0xc6e3d8: LoadField: r2 = r0->field_b
    //     0xc6e3d8: ldur            w2, [x0, #0xb]
    // 0xc6e3dc: DecompressPointer r2
    //     0xc6e3dc: add             x2, x2, HEAP, lsl #32
    // 0xc6e3e0: LoadField: r3 = r1->field_b
    //     0xc6e3e0: ldur            w3, [x1, #0xb]
    // 0xc6e3e4: DecompressPointer r3
    //     0xc6e3e4: add             x3, x3, HEAP, lsl #32
    // 0xc6e3e8: r16 = <DBusIntrospectInterface>
    //     0xc6e3e8: ldr             x16, [PP, #0x7ce0]  ; [pp+0x7ce0] TypeArguments: <DBusIntrospectInterface>
    // 0xc6e3ec: stp             x2, x16, [SP, #-0x10]!
    // 0xc6e3f0: SaveReg r3
    //     0xc6e3f0: str             x3, [SP, #-8]!
    // 0xc6e3f4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6e3f4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6e3f8: r0 = _listsEqual()
    //     0xc6e3f8: bl              #0xc6df40  ; [package:dbus/src/dbus_introspect.dart] ::_listsEqual
    // 0xc6e3fc: add             SP, SP, #0x18
    // 0xc6e400: tbnz            w0, #4, #0xc6e438
    // 0xc6e404: ldr             x1, [fp, #0x18]
    // 0xc6e408: ldr             x0, [fp, #0x10]
    // 0xc6e40c: LoadField: r2 = r0->field_f
    //     0xc6e40c: ldur            w2, [x0, #0xf]
    // 0xc6e410: DecompressPointer r2
    //     0xc6e410: add             x2, x2, HEAP, lsl #32
    // 0xc6e414: LoadField: r0 = r1->field_f
    //     0xc6e414: ldur            w0, [x1, #0xf]
    // 0xc6e418: DecompressPointer r0
    //     0xc6e418: add             x0, x0, HEAP, lsl #32
    // 0xc6e41c: r16 = <DBusIntrospectNode>
    //     0xc6e41c: ldr             x16, [PP, #0x7ce8]  ; [pp+0x7ce8] TypeArguments: <DBusIntrospectNode>
    // 0xc6e420: stp             x2, x16, [SP, #-0x10]!
    // 0xc6e424: SaveReg r0
    //     0xc6e424: str             x0, [SP, #-8]!
    // 0xc6e428: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6e428: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6e42c: r0 = _listsEqual()
    //     0xc6e42c: bl              #0xc6df40  ; [package:dbus/src/dbus_introspect.dart] ::_listsEqual
    // 0xc6e430: add             SP, SP, #0x18
    // 0xc6e434: b               #0xc6e43c
    // 0xc6e438: r0 = false
    //     0xc6e438: add             x0, NULL, #0x30  ; false
    // 0xc6e43c: LeaveFrame
    //     0xc6e43c: mov             SP, fp
    //     0xc6e440: ldp             fp, lr, [SP], #0x10
    // 0xc6e444: ret
    //     0xc6e444: ret             
    // 0xc6e448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6e448: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6e44c: b               #0xc6e35c
  }
}

// class id: 6012, size: 0x14, field offset: 0x14
enum DBusArgumentDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15390, size: 0x5c
    // 0xb15390: EnterFrame
    //     0xb15390: stp             fp, lr, [SP, #-0x10]!
    //     0xb15394: mov             fp, SP
    // 0xb15398: CheckStackOverflow
    //     0xb15398: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1539c: cmp             SP, x16
    //     0xb153a0: b.ls            #0xb153e4
    // 0xb153a4: r1 = Null
    //     0xb153a4: mov             x1, NULL
    // 0xb153a8: r2 = 4
    //     0xb153a8: mov             x2, #4
    // 0xb153ac: r0 = AllocateArray()
    //     0xb153ac: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb153b0: r17 = "DBusArgumentDirection."
    //     0xb153b0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb540] "DBusArgumentDirection."
    //     0xb153b4: ldr             x17, [x17, #0x540]
    // 0xb153b8: StoreField: r0->field_f = r17
    //     0xb153b8: stur            w17, [x0, #0xf]
    // 0xb153bc: ldr             x1, [fp, #0x10]
    // 0xb153c0: LoadField: r2 = r1->field_f
    //     0xb153c0: ldur            w2, [x1, #0xf]
    // 0xb153c4: DecompressPointer r2
    //     0xb153c4: add             x2, x2, HEAP, lsl #32
    // 0xb153c8: StoreField: r0->field_13 = r2
    //     0xb153c8: stur            w2, [x0, #0x13]
    // 0xb153cc: SaveReg r0
    //     0xb153cc: str             x0, [SP, #-8]!
    // 0xb153d0: r0 = _interpolate()
    //     0xb153d0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb153d4: add             SP, SP, #8
    // 0xb153d8: LeaveFrame
    //     0xb153d8: mov             SP, fp
    //     0xb153dc: ldp             fp, lr, [SP], #0x10
    // 0xb153e0: ret
    //     0xb153e0: ret             
    // 0xb153e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb153e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb153e8: b               #0xb153a4
  }
}

// lib: , url: package:dbus/src/dbus_buffer.dart

// class id: 1048831, size: 0x8
class :: {
}

// class id: 4633, size: 0x90, field offset: 0x8
abstract class DBusBuffer extends Object {

  _ getAlignment(/* No info */) {
    // ** addr: 0xa01574, size: 0x3a4
    // 0xa01574: EnterFrame
    //     0xa01574: stp             fp, lr, [SP, #-0x10]!
    //     0xa01578: mov             fp, SP
    // 0xa0157c: AllocStack(0x8)
    //     0xa0157c: sub             SP, SP, #8
    // 0xa01580: CheckStackOverflow
    //     0xa01580: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa01584: cmp             SP, x16
    //     0xa01588: b.ls            #0xa01910
    // 0xa0158c: ldr             x0, [fp, #0x10]
    // 0xa01590: LoadField: r1 = r0->field_7
    //     0xa01590: ldur            w1, [x0, #7]
    // 0xa01594: DecompressPointer r1
    //     0xa01594: add             x1, x1, HEAP, lsl #32
    // 0xa01598: stur            x1, [fp, #-8]
    // 0xa0159c: r0 = LoadClassIdInstr(r1)
    //     0xa0159c: ldur            x0, [x1, #-1]
    //     0xa015a0: ubfx            x0, x0, #0xc, #0x14
    // 0xa015a4: r16 = "y"
    //     0xa015a4: ldr             x16, [PP, #0x78d0]  ; [pp+0x78d0] "y"
    // 0xa015a8: stp             x16, x1, [SP, #-0x10]!
    // 0xa015ac: mov             lr, x0
    // 0xa015b0: ldr             lr, [x21, lr, lsl #3]
    // 0xa015b4: blr             lr
    // 0xa015b8: add             SP, SP, #0x10
    // 0xa015bc: tbnz            w0, #4, #0xa015d0
    // 0xa015c0: r0 = 1
    //     0xa015c0: mov             x0, #1
    // 0xa015c4: LeaveFrame
    //     0xa015c4: mov             SP, fp
    //     0xa015c8: ldp             fp, lr, [SP], #0x10
    // 0xa015cc: ret
    //     0xa015cc: ret             
    // 0xa015d0: ldur            x1, [fp, #-8]
    // 0xa015d4: r0 = LoadClassIdInstr(r1)
    //     0xa015d4: ldur            x0, [x1, #-1]
    //     0xa015d8: ubfx            x0, x0, #0xc, #0x14
    // 0xa015dc: r16 = "b"
    //     0xa015dc: ldr             x16, [PP, #0x78d8]  ; [pp+0x78d8] "b"
    // 0xa015e0: stp             x16, x1, [SP, #-0x10]!
    // 0xa015e4: mov             lr, x0
    // 0xa015e8: ldr             lr, [x21, lr, lsl #3]
    // 0xa015ec: blr             lr
    // 0xa015f0: add             SP, SP, #0x10
    // 0xa015f4: tbnz            w0, #4, #0xa01608
    // 0xa015f8: r0 = 4
    //     0xa015f8: mov             x0, #4
    // 0xa015fc: LeaveFrame
    //     0xa015fc: mov             SP, fp
    //     0xa01600: ldp             fp, lr, [SP], #0x10
    // 0xa01604: ret
    //     0xa01604: ret             
    // 0xa01608: ldur            x1, [fp, #-8]
    // 0xa0160c: r0 = LoadClassIdInstr(r1)
    //     0xa0160c: ldur            x0, [x1, #-1]
    //     0xa01610: ubfx            x0, x0, #0xc, #0x14
    // 0xa01614: r16 = "n"
    //     0xa01614: ldr             x16, [PP, #0x78e0]  ; [pp+0x78e0] "n"
    // 0xa01618: stp             x16, x1, [SP, #-0x10]!
    // 0xa0161c: mov             lr, x0
    // 0xa01620: ldr             lr, [x21, lr, lsl #3]
    // 0xa01624: blr             lr
    // 0xa01628: add             SP, SP, #0x10
    // 0xa0162c: tbnz            w0, #4, #0xa01640
    // 0xa01630: r0 = 2
    //     0xa01630: mov             x0, #2
    // 0xa01634: LeaveFrame
    //     0xa01634: mov             SP, fp
    //     0xa01638: ldp             fp, lr, [SP], #0x10
    // 0xa0163c: ret
    //     0xa0163c: ret             
    // 0xa01640: ldur            x1, [fp, #-8]
    // 0xa01644: r0 = LoadClassIdInstr(r1)
    //     0xa01644: ldur            x0, [x1, #-1]
    //     0xa01648: ubfx            x0, x0, #0xc, #0x14
    // 0xa0164c: r16 = "q"
    //     0xa0164c: ldr             x16, [PP, #0x78e8]  ; [pp+0x78e8] "q"
    // 0xa01650: stp             x16, x1, [SP, #-0x10]!
    // 0xa01654: mov             lr, x0
    // 0xa01658: ldr             lr, [x21, lr, lsl #3]
    // 0xa0165c: blr             lr
    // 0xa01660: add             SP, SP, #0x10
    // 0xa01664: tbnz            w0, #4, #0xa01678
    // 0xa01668: r0 = 2
    //     0xa01668: mov             x0, #2
    // 0xa0166c: LeaveFrame
    //     0xa0166c: mov             SP, fp
    //     0xa01670: ldp             fp, lr, [SP], #0x10
    // 0xa01674: ret
    //     0xa01674: ret             
    // 0xa01678: ldur            x1, [fp, #-8]
    // 0xa0167c: r0 = LoadClassIdInstr(r1)
    //     0xa0167c: ldur            x0, [x1, #-1]
    //     0xa01680: ubfx            x0, x0, #0xc, #0x14
    // 0xa01684: r16 = "i"
    //     0xa01684: ldr             x16, [PP, #0x78f0]  ; [pp+0x78f0] "i"
    // 0xa01688: stp             x16, x1, [SP, #-0x10]!
    // 0xa0168c: mov             lr, x0
    // 0xa01690: ldr             lr, [x21, lr, lsl #3]
    // 0xa01694: blr             lr
    // 0xa01698: add             SP, SP, #0x10
    // 0xa0169c: tbnz            w0, #4, #0xa016b0
    // 0xa016a0: r0 = 4
    //     0xa016a0: mov             x0, #4
    // 0xa016a4: LeaveFrame
    //     0xa016a4: mov             SP, fp
    //     0xa016a8: ldp             fp, lr, [SP], #0x10
    // 0xa016ac: ret
    //     0xa016ac: ret             
    // 0xa016b0: ldur            x1, [fp, #-8]
    // 0xa016b4: r0 = LoadClassIdInstr(r1)
    //     0xa016b4: ldur            x0, [x1, #-1]
    //     0xa016b8: ubfx            x0, x0, #0xc, #0x14
    // 0xa016bc: r16 = "u"
    //     0xa016bc: ldr             x16, [PP, #0x78f8]  ; [pp+0x78f8] "u"
    // 0xa016c0: stp             x16, x1, [SP, #-0x10]!
    // 0xa016c4: mov             lr, x0
    // 0xa016c8: ldr             lr, [x21, lr, lsl #3]
    // 0xa016cc: blr             lr
    // 0xa016d0: add             SP, SP, #0x10
    // 0xa016d4: tbnz            w0, #4, #0xa016e8
    // 0xa016d8: r0 = 4
    //     0xa016d8: mov             x0, #4
    // 0xa016dc: LeaveFrame
    //     0xa016dc: mov             SP, fp
    //     0xa016e0: ldp             fp, lr, [SP], #0x10
    // 0xa016e4: ret
    //     0xa016e4: ret             
    // 0xa016e8: ldur            x1, [fp, #-8]
    // 0xa016ec: r0 = LoadClassIdInstr(r1)
    //     0xa016ec: ldur            x0, [x1, #-1]
    //     0xa016f0: ubfx            x0, x0, #0xc, #0x14
    // 0xa016f4: r16 = "x"
    //     0xa016f4: ldr             x16, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xa016f8: stp             x16, x1, [SP, #-0x10]!
    // 0xa016fc: mov             lr, x0
    // 0xa01700: ldr             lr, [x21, lr, lsl #3]
    // 0xa01704: blr             lr
    // 0xa01708: add             SP, SP, #0x10
    // 0xa0170c: tbnz            w0, #4, #0xa01720
    // 0xa01710: r0 = 8
    //     0xa01710: mov             x0, #8
    // 0xa01714: LeaveFrame
    //     0xa01714: mov             SP, fp
    //     0xa01718: ldp             fp, lr, [SP], #0x10
    // 0xa0171c: ret
    //     0xa0171c: ret             
    // 0xa01720: ldur            x1, [fp, #-8]
    // 0xa01724: r0 = LoadClassIdInstr(r1)
    //     0xa01724: ldur            x0, [x1, #-1]
    //     0xa01728: ubfx            x0, x0, #0xc, #0x14
    // 0xa0172c: r16 = "t"
    //     0xa0172c: ldr             x16, [PP, #0x7900]  ; [pp+0x7900] "t"
    // 0xa01730: stp             x16, x1, [SP, #-0x10]!
    // 0xa01734: mov             lr, x0
    // 0xa01738: ldr             lr, [x21, lr, lsl #3]
    // 0xa0173c: blr             lr
    // 0xa01740: add             SP, SP, #0x10
    // 0xa01744: tbnz            w0, #4, #0xa01758
    // 0xa01748: r0 = 8
    //     0xa01748: mov             x0, #8
    // 0xa0174c: LeaveFrame
    //     0xa0174c: mov             SP, fp
    //     0xa01750: ldp             fp, lr, [SP], #0x10
    // 0xa01754: ret
    //     0xa01754: ret             
    // 0xa01758: ldur            x1, [fp, #-8]
    // 0xa0175c: r0 = LoadClassIdInstr(r1)
    //     0xa0175c: ldur            x0, [x1, #-1]
    //     0xa01760: ubfx            x0, x0, #0xc, #0x14
    // 0xa01764: r16 = "d"
    //     0xa01764: ldr             x16, [PP, #0x7908]  ; [pp+0x7908] "d"
    // 0xa01768: stp             x16, x1, [SP, #-0x10]!
    // 0xa0176c: mov             lr, x0
    // 0xa01770: ldr             lr, [x21, lr, lsl #3]
    // 0xa01774: blr             lr
    // 0xa01778: add             SP, SP, #0x10
    // 0xa0177c: tbnz            w0, #4, #0xa01790
    // 0xa01780: r0 = 8
    //     0xa01780: mov             x0, #8
    // 0xa01784: LeaveFrame
    //     0xa01784: mov             SP, fp
    //     0xa01788: ldp             fp, lr, [SP], #0x10
    // 0xa0178c: ret
    //     0xa0178c: ret             
    // 0xa01790: ldur            x1, [fp, #-8]
    // 0xa01794: r0 = LoadClassIdInstr(r1)
    //     0xa01794: ldur            x0, [x1, #-1]
    //     0xa01798: ubfx            x0, x0, #0xc, #0x14
    // 0xa0179c: r16 = "s"
    //     0xa0179c: ldr             x16, [PP, #0x7680]  ; [pp+0x7680] "s"
    // 0xa017a0: stp             x16, x1, [SP, #-0x10]!
    // 0xa017a4: mov             lr, x0
    // 0xa017a8: ldr             lr, [x21, lr, lsl #3]
    // 0xa017ac: blr             lr
    // 0xa017b0: add             SP, SP, #0x10
    // 0xa017b4: tbnz            w0, #4, #0xa017c8
    // 0xa017b8: r0 = 4
    //     0xa017b8: mov             x0, #4
    // 0xa017bc: LeaveFrame
    //     0xa017bc: mov             SP, fp
    //     0xa017c0: ldp             fp, lr, [SP], #0x10
    // 0xa017c4: ret
    //     0xa017c4: ret             
    // 0xa017c8: ldur            x1, [fp, #-8]
    // 0xa017cc: r0 = LoadClassIdInstr(r1)
    //     0xa017cc: ldur            x0, [x1, #-1]
    //     0xa017d0: ubfx            x0, x0, #0xc, #0x14
    // 0xa017d4: r16 = "o"
    //     0xa017d4: ldr             x16, [PP, #0x7690]  ; [pp+0x7690] "o"
    // 0xa017d8: stp             x16, x1, [SP, #-0x10]!
    // 0xa017dc: mov             lr, x0
    // 0xa017e0: ldr             lr, [x21, lr, lsl #3]
    // 0xa017e4: blr             lr
    // 0xa017e8: add             SP, SP, #0x10
    // 0xa017ec: tbnz            w0, #4, #0xa01800
    // 0xa017f0: r0 = 4
    //     0xa017f0: mov             x0, #4
    // 0xa017f4: LeaveFrame
    //     0xa017f4: mov             SP, fp
    //     0xa017f8: ldp             fp, lr, [SP], #0x10
    // 0xa017fc: ret
    //     0xa017fc: ret             
    // 0xa01800: ldur            x1, [fp, #-8]
    // 0xa01804: r0 = LoadClassIdInstr(r1)
    //     0xa01804: ldur            x0, [x1, #-1]
    //     0xa01808: ubfx            x0, x0, #0xc, #0x14
    // 0xa0180c: r16 = "g"
    //     0xa0180c: ldr             x16, [PP, #0x76a0]  ; [pp+0x76a0] "g"
    // 0xa01810: stp             x16, x1, [SP, #-0x10]!
    // 0xa01814: mov             lr, x0
    // 0xa01818: ldr             lr, [x21, lr, lsl #3]
    // 0xa0181c: blr             lr
    // 0xa01820: add             SP, SP, #0x10
    // 0xa01824: tbnz            w0, #4, #0xa01838
    // 0xa01828: r0 = 1
    //     0xa01828: mov             x0, #1
    // 0xa0182c: LeaveFrame
    //     0xa0182c: mov             SP, fp
    //     0xa01830: ldp             fp, lr, [SP], #0x10
    // 0xa01834: ret
    //     0xa01834: ret             
    // 0xa01838: ldur            x1, [fp, #-8]
    // 0xa0183c: r0 = LoadClassIdInstr(r1)
    //     0xa0183c: ldur            x0, [x1, #-1]
    //     0xa01840: ubfx            x0, x0, #0xc, #0x14
    // 0xa01844: r16 = "v"
    //     0xa01844: ldr             x16, [PP, #0x7910]  ; [pp+0x7910] "v"
    // 0xa01848: stp             x16, x1, [SP, #-0x10]!
    // 0xa0184c: mov             lr, x0
    // 0xa01850: ldr             lr, [x21, lr, lsl #3]
    // 0xa01854: blr             lr
    // 0xa01858: add             SP, SP, #0x10
    // 0xa0185c: tbnz            w0, #4, #0xa01870
    // 0xa01860: r0 = 1
    //     0xa01860: mov             x0, #1
    // 0xa01864: LeaveFrame
    //     0xa01864: mov             SP, fp
    //     0xa01868: ldp             fp, lr, [SP], #0x10
    // 0xa0186c: ret
    //     0xa0186c: ret             
    // 0xa01870: ldur            x1, [fp, #-8]
    // 0xa01874: r0 = LoadClassIdInstr(r1)
    //     0xa01874: ldur            x0, [x1, #-1]
    //     0xa01878: ubfx            x0, x0, #0xc, #0x14
    // 0xa0187c: r16 = "h"
    //     0xa0187c: ldr             x16, [PP, #0x7918]  ; [pp+0x7918] "h"
    // 0xa01880: stp             x16, x1, [SP, #-0x10]!
    // 0xa01884: mov             lr, x0
    // 0xa01888: ldr             lr, [x21, lr, lsl #3]
    // 0xa0188c: blr             lr
    // 0xa01890: add             SP, SP, #0x10
    // 0xa01894: tbnz            w0, #4, #0xa018a8
    // 0xa01898: r0 = 4
    //     0xa01898: mov             x0, #4
    // 0xa0189c: LeaveFrame
    //     0xa0189c: mov             SP, fp
    //     0xa018a0: ldp             fp, lr, [SP], #0x10
    // 0xa018a4: ret
    //     0xa018a4: ret             
    // 0xa018a8: ldur            x16, [fp, #-8]
    // 0xa018ac: r30 = "("
    //     0xa018ac: ldr             lr, [PP, #0x418]  ; [pp+0x418] "("
    // 0xa018b0: stp             lr, x16, [SP, #-0x10]!
    // 0xa018b4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa018b4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa018b8: r0 = startsWith()
    //     0xa018b8: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0xa018bc: add             SP, SP, #0x10
    // 0xa018c0: tbnz            w0, #4, #0xa018d4
    // 0xa018c4: r0 = 8
    //     0xa018c4: mov             x0, #8
    // 0xa018c8: LeaveFrame
    //     0xa018c8: mov             SP, fp
    //     0xa018cc: ldp             fp, lr, [SP], #0x10
    // 0xa018d0: ret
    //     0xa018d0: ret             
    // 0xa018d4: ldur            x16, [fp, #-8]
    // 0xa018d8: r30 = "a"
    //     0xa018d8: ldr             lr, [PP, #0x440]  ; [pp+0x440] "a"
    // 0xa018dc: stp             lr, x16, [SP, #-0x10]!
    // 0xa018e0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa018e0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa018e4: r0 = startsWith()
    //     0xa018e4: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0xa018e8: add             SP, SP, #0x10
    // 0xa018ec: tbnz            w0, #4, #0xa01900
    // 0xa018f0: r0 = 4
    //     0xa018f0: mov             x0, #4
    // 0xa018f4: LeaveFrame
    //     0xa018f4: mov             SP, fp
    //     0xa018f8: ldp             fp, lr, [SP], #0x10
    // 0xa018fc: ret
    //     0xa018fc: ret             
    // 0xa01900: r0 = 1
    //     0xa01900: mov             x0, #1
    // 0xa01904: LeaveFrame
    //     0xa01904: mov             SP, fp
    //     0xa01908: ldp             fp, lr, [SP], #0x10
    // 0xa0190c: ret
    //     0xa0190c: ret             
    // 0xa01910: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa01910: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa01914: b               #0xa0158c
  }
}

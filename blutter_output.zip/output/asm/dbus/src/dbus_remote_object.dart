// lib: , url: package:dbus/src/dbus_remote_object.dart

// class id: 1048849, size: 0x8
class :: {
}

// class id: 4585, size: 0x18, field offset: 0x8
abstract class DBusRemoteObject extends Object {

  _ DBusRemoteObject(/* No info */) {
    // ** addr: 0xa0e884, size: 0x124
    // 0xa0e884: EnterFrame
    //     0xa0e884: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e888: mov             fp, SP
    // 0xa0e88c: AllocStack(0x8)
    //     0xa0e88c: sub             SP, SP, #8
    // 0xa0e890: r0 = Sentinel
    //     0xa0e890: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0e894: r1 = "org.freedesktop.NetworkManager"
    //     0xa0e894: ldr             x1, [PP, #0x3a0]  ; [pp+0x3a0] "org.freedesktop.NetworkManager"
    // 0xa0e898: CheckStackOverflow
    //     0xa0e898: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0e89c: cmp             SP, x16
    //     0xa0e8a0: b.ls            #0xa0e9a0
    // 0xa0e8a4: ldr             x2, [fp, #0x20]
    // 0xa0e8a8: StoreField: r2->field_13 = r0
    //     0xa0e8a8: stur            w0, [x2, #0x13]
    // 0xa0e8ac: ldr             x0, [fp, #0x18]
    // 0xa0e8b0: StoreField: r2->field_7 = r0
    //     0xa0e8b0: stur            w0, [x2, #7]
    //     0xa0e8b4: ldurb           w16, [x2, #-1]
    //     0xa0e8b8: ldurb           w17, [x0, #-1]
    //     0xa0e8bc: and             x16, x17, x16, lsr #2
    //     0xa0e8c0: tst             x16, HEAP, lsr #32
    //     0xa0e8c4: b.eq            #0xa0e8cc
    //     0xa0e8c8: bl              #0xd6828c
    // 0xa0e8cc: StoreField: r2->field_b = r1
    //     0xa0e8cc: stur            w1, [x2, #0xb]
    // 0xa0e8d0: ldr             x0, [fp, #0x10]
    // 0xa0e8d4: StoreField: r2->field_f = r0
    //     0xa0e8d4: stur            w0, [x2, #0xf]
    //     0xa0e8d8: ldurb           w16, [x2, #-1]
    //     0xa0e8dc: ldurb           w17, [x0, #-1]
    //     0xa0e8e0: and             x16, x17, x16, lsr #2
    //     0xa0e8e4: tst             x16, HEAP, lsr #32
    //     0xa0e8e8: b.eq            #0xa0e8f0
    //     0xa0e8ec: bl              #0xd6828c
    // 0xa0e8f0: r1 = <DBusSignal>
    //     0xa0e8f0: ldr             x1, [PP, #0x398]  ; [pp+0x398] TypeArguments: <DBusSignal>
    // 0xa0e8f4: r0 = DBusRemoteObjectSignalStream()
    //     0xa0e8f4: bl              #0xa0ea14  ; AllocateDBusRemoteObjectSignalStreamStub -> DBusRemoteObjectSignalStream (size=0x1c)
    // 0xa0e8f8: stur            x0, [fp, #-8]
    // 0xa0e8fc: ldr             x16, [fp, #0x20]
    // 0xa0e900: stp             x16, x0, [SP, #-0x10]!
    // 0xa0e904: r0 = DBusRemoteObjectSignalStream()
    //     0xa0e904: bl              #0xa0e9a8  ; [package:dbus/src/dbus_remote_object.dart] DBusRemoteObjectSignalStream::DBusRemoteObjectSignalStream
    // 0xa0e908: add             SP, SP, #0x10
    // 0xa0e90c: r1 = Function '<anonymous closure>':.
    //     0xa0e90c: ldr             x1, [PP, #0x740]  ; [pp+0x740] AnonymousClosure: (0xa0ea20), in [package:dbus/src/dbus_remote_object.dart] DBusRemoteObject::DBusRemoteObject (0xa0e884)
    // 0xa0e910: r2 = Null
    //     0xa0e910: mov             x2, NULL
    // 0xa0e914: r0 = AllocateClosure()
    //     0xa0e914: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa0e918: r16 = <DBusPropertiesChangedSignal>
    //     0xa0e918: ldr             x16, [PP, #0x748]  ; [pp+0x748] TypeArguments: <DBusPropertiesChangedSignal>
    // 0xa0e91c: ldur            lr, [fp, #-8]
    // 0xa0e920: stp             lr, x16, [SP, #-0x10]!
    // 0xa0e924: SaveReg r0
    //     0xa0e924: str             x0, [SP, #-8]!
    // 0xa0e928: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0e928: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa0e92c: r0 = map()
    //     0xa0e92c: bl              #0x5b31c8  ; [dart:async] Stream::map
    // 0xa0e930: add             SP, SP, #0x18
    // 0xa0e934: mov             x1, x0
    // 0xa0e938: ldr             x0, [fp, #0x20]
    // 0xa0e93c: stur            x1, [fp, #-8]
    // 0xa0e940: LoadField: r2 = r0->field_13
    //     0xa0e940: ldur            w2, [x0, #0x13]
    // 0xa0e944: DecompressPointer r2
    //     0xa0e944: add             x2, x2, HEAP, lsl #32
    // 0xa0e948: r16 = Sentinel
    //     0xa0e948: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa0e94c: cmp             w2, w16
    // 0xa0e950: b.ne            #0xa0e95c
    // 0xa0e954: mov             x1, x0
    // 0xa0e958: b               #0xa0e970
    // 0xa0e95c: r16 = "propertiesChanged"
    //     0xa0e95c: ldr             x16, [PP, #0x750]  ; [pp+0x750] "propertiesChanged"
    // 0xa0e960: SaveReg r16
    //     0xa0e960: str             x16, [SP, #-8]!
    // 0xa0e964: r0 = _throwFieldAlreadyInitialized()
    //     0xa0e964: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xa0e968: add             SP, SP, #8
    // 0xa0e96c: ldr             x1, [fp, #0x20]
    // 0xa0e970: ldur            x0, [fp, #-8]
    // 0xa0e974: StoreField: r1->field_13 = r0
    //     0xa0e974: stur            w0, [x1, #0x13]
    //     0xa0e978: ldurb           w16, [x1, #-1]
    //     0xa0e97c: ldurb           w17, [x0, #-1]
    //     0xa0e980: and             x16, x17, x16, lsr #2
    //     0xa0e984: tst             x16, HEAP, lsr #32
    //     0xa0e988: b.eq            #0xa0e990
    //     0xa0e98c: bl              #0xd6826c
    // 0xa0e990: r0 = Null
    //     0xa0e990: mov             x0, NULL
    // 0xa0e994: LeaveFrame
    //     0xa0e994: mov             SP, fp
    //     0xa0e998: ldp             fp, lr, [SP], #0x10
    // 0xa0e99c: ret
    //     0xa0e99c: ret             
    // 0xa0e9a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0e9a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0e9a4: b               #0xa0e8a4
  }
  [closure] DBusPropertiesChangedSignal <anonymous closure>(dynamic, DBusSignal) {
    // ** addr: 0xa0ea20, size: 0xc8
    // 0xa0ea20: EnterFrame
    //     0xa0ea20: stp             fp, lr, [SP, #-0x10]!
    //     0xa0ea24: mov             fp, SP
    // 0xa0ea28: AllocStack(0x10)
    //     0xa0ea28: sub             SP, SP, #0x10
    // 0xa0ea2c: CheckStackOverflow
    //     0xa0ea2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0ea30: cmp             SP, x16
    //     0xa0ea34: b.ls            #0xa0eae0
    // 0xa0ea38: ldr             x16, [fp, #0x10]
    // 0xa0ea3c: SaveReg r16
    //     0xa0ea3c: str             x16, [SP, #-8]!
    // 0xa0ea40: r0 = signature()
    //     0xa0ea40: bl              #0x9fef50  ; [package:dbus/src/dbus_signal.dart] DBusSignal::signature
    // 0xa0ea44: add             SP, SP, #8
    // 0xa0ea48: stur            x0, [fp, #-8]
    // 0xa0ea4c: r0 = DBusSignature()
    //     0xa0ea4c: bl              #0x9fdd78  ; AllocateDBusSignatureStub -> DBusSignature (size=0xc)
    // 0xa0ea50: stur            x0, [fp, #-0x10]
    // 0xa0ea54: r16 = "sa{sv}as"
    //     0xa0ea54: ldr             x16, [PP, #0x400]  ; [pp+0x400] "sa{sv}as"
    // 0xa0ea58: stp             x16, x0, [SP, #-0x10]!
    // 0xa0ea5c: r0 = DBusSignature()
    //     0xa0ea5c: bl              #0x9fd234  ; [package:dbus/src/dbus_value.dart] DBusSignature::DBusSignature
    // 0xa0ea60: add             SP, SP, #0x10
    // 0xa0ea64: ldur            x16, [fp, #-8]
    // 0xa0ea68: ldur            lr, [fp, #-0x10]
    // 0xa0ea6c: stp             lr, x16, [SP, #-0x10]!
    // 0xa0ea70: r0 = ==()
    //     0xa0ea70: bl              #0xc6eb40  ; [package:dbus/src/dbus_value.dart] DBusSignature::==
    // 0xa0ea74: add             SP, SP, #0x10
    // 0xa0ea78: tbnz            w0, #4, #0xa0eaa4
    // 0xa0ea7c: r0 = DBusPropertiesChangedSignal()
    //     0xa0ea7c: bl              #0xa0ebcc  ; AllocateDBusPropertiesChangedSignalStub -> DBusPropertiesChangedSignal (size=0x1c)
    // 0xa0ea80: stur            x0, [fp, #-8]
    // 0xa0ea84: ldr             x16, [fp, #0x10]
    // 0xa0ea88: stp             x16, x0, [SP, #-0x10]!
    // 0xa0ea8c: r0 = DBusPropertiesChangedSignal()
    //     0xa0ea8c: bl              #0xa0eae8  ; [package:dbus/src/dbus_remote_object.dart] DBusPropertiesChangedSignal::DBusPropertiesChangedSignal
    // 0xa0ea90: add             SP, SP, #0x10
    // 0xa0ea94: ldur            x0, [fp, #-8]
    // 0xa0ea98: LeaveFrame
    //     0xa0ea98: mov             SP, fp
    //     0xa0ea9c: ldp             fp, lr, [SP], #0x10
    // 0xa0eaa0: ret
    //     0xa0eaa0: ret             
    // 0xa0eaa4: ldr             x0, [fp, #0x10]
    // 0xa0eaa8: r1 = Null
    //     0xa0eaa8: mov             x1, NULL
    // 0xa0eaac: r2 = 4
    //     0xa0eaac: mov             x2, #4
    // 0xa0eab0: r0 = AllocateArray()
    //     0xa0eab0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa0eab4: r17 = "org.freedesktop.DBus.Properties.PropertiesChanged contains invalid values "
    //     0xa0eab4: ldr             x17, [PP, #0x758]  ; [pp+0x758] "org.freedesktop.DBus.Properties.PropertiesChanged contains invalid values "
    // 0xa0eab8: StoreField: r0->field_f = r17
    //     0xa0eab8: stur            w17, [x0, #0xf]
    // 0xa0eabc: ldr             x1, [fp, #0x10]
    // 0xa0eac0: LoadField: r2 = r1->field_17
    //     0xa0eac0: ldur            w2, [x1, #0x17]
    // 0xa0eac4: DecompressPointer r2
    //     0xa0eac4: add             x2, x2, HEAP, lsl #32
    // 0xa0eac8: StoreField: r0->field_13 = r2
    //     0xa0eac8: stur            w2, [x0, #0x13]
    // 0xa0eacc: SaveReg r0
    //     0xa0eacc: str             x0, [SP, #-8]!
    // 0xa0ead0: r0 = _interpolate()
    //     0xa0ead0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa0ead4: add             SP, SP, #8
    // 0xa0ead8: r0 = Throw()
    //     0xa0ead8: bl              #0xd67e38  ; ThrowStub
    // 0xa0eadc: brk             #0
    // 0xa0eae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0eae0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0eae4: b               #0xa0ea38
  }
  _ toString(/* No info */) {
    // ** addr: 0xad11e4, size: 0xa0
    // 0xad11e4: EnterFrame
    //     0xad11e4: stp             fp, lr, [SP, #-0x10]!
    //     0xad11e8: mov             fp, SP
    // 0xad11ec: AllocStack(0x8)
    //     0xad11ec: sub             SP, SP, #8
    // 0xad11f0: CheckStackOverflow
    //     0xad11f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad11f4: cmp             SP, x16
    //     0xad11f8: b.ls            #0xad127c
    // 0xad11fc: ldr             x16, [fp, #0x10]
    // 0xad1200: SaveReg r16
    //     0xad1200: str             x16, [SP, #-8]!
    // 0xad1204: r0 = runtimeType()
    //     0xad1204: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xad1208: add             SP, SP, #8
    // 0xad120c: r1 = Null
    //     0xad120c: mov             x1, NULL
    // 0xad1210: r2 = 12
    //     0xad1210: mov             x2, #0xc
    // 0xad1214: stur            x0, [fp, #-8]
    // 0xad1218: r0 = AllocateArray()
    //     0xad1218: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad121c: mov             x1, x0
    // 0xad1220: ldur            x0, [fp, #-8]
    // 0xad1224: StoreField: r1->field_f = r0
    //     0xad1224: stur            w0, [x1, #0xf]
    // 0xad1228: r17 = "(name: \'"
    //     0xad1228: ldr             x17, [PP, #0x76e0]  ; [pp+0x76e0] "(name: \'"
    // 0xad122c: StoreField: r1->field_13 = r17
    //     0xad122c: stur            w17, [x1, #0x13]
    // 0xad1230: ldr             x0, [fp, #0x10]
    // 0xad1234: LoadField: r2 = r0->field_b
    //     0xad1234: ldur            w2, [x0, #0xb]
    // 0xad1238: DecompressPointer r2
    //     0xad1238: add             x2, x2, HEAP, lsl #32
    // 0xad123c: StoreField: r1->field_17 = r2
    //     0xad123c: stur            w2, [x1, #0x17]
    // 0xad1240: r17 = "\', path: \'"
    //     0xad1240: ldr             x17, [PP, #0x76e8]  ; [pp+0x76e8] "\', path: \'"
    // 0xad1244: StoreField: r1->field_1b = r17
    //     0xad1244: stur            w17, [x1, #0x1b]
    // 0xad1248: LoadField: r2 = r0->field_f
    //     0xad1248: ldur            w2, [x0, #0xf]
    // 0xad124c: DecompressPointer r2
    //     0xad124c: add             x2, x2, HEAP, lsl #32
    // 0xad1250: LoadField: r0 = r2->field_7
    //     0xad1250: ldur            w0, [x2, #7]
    // 0xad1254: DecompressPointer r0
    //     0xad1254: add             x0, x0, HEAP, lsl #32
    // 0xad1258: StoreField: r1->field_1f = r0
    //     0xad1258: stur            w0, [x1, #0x1f]
    // 0xad125c: r17 = "\')"
    //     0xad125c: ldr             x17, [PP, #0x7628]  ; [pp+0x7628] "\')"
    // 0xad1260: StoreField: r1->field_23 = r17
    //     0xad1260: stur            w17, [x1, #0x23]
    // 0xad1264: SaveReg r1
    //     0xad1264: str             x1, [SP, #-8]!
    // 0xad1268: r0 = _interpolate()
    //     0xad1268: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad126c: add             SP, SP, #8
    // 0xad1270: LeaveFrame
    //     0xad1270: mov             SP, fp
    //     0xad1274: ldp             fp, lr, [SP], #0x10
    // 0xad1278: ret
    //     0xad1278: ret             
    // 0xad127c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad127c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad1280: b               #0xad11fc
  }
}

// class id: 4631, size: 0x1c, field offset: 0x1c
class DBusPropertiesChangedSignal extends DBusSignal {

  _ DBusPropertiesChangedSignal(/* No info */) {
    // ** addr: 0xa0eae8, size: 0xe4
    // 0xa0eae8: EnterFrame
    //     0xa0eae8: stp             fp, lr, [SP, #-0x10]!
    //     0xa0eaec: mov             fp, SP
    // 0xa0eaf0: ldr             x1, [fp, #0x10]
    // 0xa0eaf4: LoadField: r0 = r1->field_7
    //     0xa0eaf4: ldur            w0, [x1, #7]
    // 0xa0eaf8: DecompressPointer r0
    //     0xa0eaf8: add             x0, x0, HEAP, lsl #32
    // 0xa0eafc: LoadField: r2 = r1->field_b
    //     0xa0eafc: ldur            w2, [x1, #0xb]
    // 0xa0eb00: DecompressPointer r2
    //     0xa0eb00: add             x2, x2, HEAP, lsl #32
    // 0xa0eb04: LoadField: r3 = r1->field_f
    //     0xa0eb04: ldur            w3, [x1, #0xf]
    // 0xa0eb08: DecompressPointer r3
    //     0xa0eb08: add             x3, x3, HEAP, lsl #32
    // 0xa0eb0c: LoadField: r4 = r1->field_13
    //     0xa0eb0c: ldur            w4, [x1, #0x13]
    // 0xa0eb10: DecompressPointer r4
    //     0xa0eb10: add             x4, x4, HEAP, lsl #32
    // 0xa0eb14: LoadField: r5 = r1->field_17
    //     0xa0eb14: ldur            w5, [x1, #0x17]
    // 0xa0eb18: DecompressPointer r5
    //     0xa0eb18: add             x5, x5, HEAP, lsl #32
    // 0xa0eb1c: ldr             x1, [fp, #0x18]
    // 0xa0eb20: StoreField: r1->field_7 = r0
    //     0xa0eb20: stur            w0, [x1, #7]
    //     0xa0eb24: ldurb           w16, [x1, #-1]
    //     0xa0eb28: ldurb           w17, [x0, #-1]
    //     0xa0eb2c: and             x16, x17, x16, lsr #2
    //     0xa0eb30: tst             x16, HEAP, lsr #32
    //     0xa0eb34: b.eq            #0xa0eb3c
    //     0xa0eb38: bl              #0xd6826c
    // 0xa0eb3c: mov             x0, x2
    // 0xa0eb40: StoreField: r1->field_b = r0
    //     0xa0eb40: stur            w0, [x1, #0xb]
    //     0xa0eb44: ldurb           w16, [x1, #-1]
    //     0xa0eb48: ldurb           w17, [x0, #-1]
    //     0xa0eb4c: and             x16, x17, x16, lsr #2
    //     0xa0eb50: tst             x16, HEAP, lsr #32
    //     0xa0eb54: b.eq            #0xa0eb5c
    //     0xa0eb58: bl              #0xd6826c
    // 0xa0eb5c: mov             x0, x3
    // 0xa0eb60: StoreField: r1->field_f = r0
    //     0xa0eb60: stur            w0, [x1, #0xf]
    //     0xa0eb64: ldurb           w16, [x1, #-1]
    //     0xa0eb68: ldurb           w17, [x0, #-1]
    //     0xa0eb6c: and             x16, x17, x16, lsr #2
    //     0xa0eb70: tst             x16, HEAP, lsr #32
    //     0xa0eb74: b.eq            #0xa0eb7c
    //     0xa0eb78: bl              #0xd6826c
    // 0xa0eb7c: mov             x0, x4
    // 0xa0eb80: StoreField: r1->field_13 = r0
    //     0xa0eb80: stur            w0, [x1, #0x13]
    //     0xa0eb84: ldurb           w16, [x1, #-1]
    //     0xa0eb88: ldurb           w17, [x0, #-1]
    //     0xa0eb8c: and             x16, x17, x16, lsr #2
    //     0xa0eb90: tst             x16, HEAP, lsr #32
    //     0xa0eb94: b.eq            #0xa0eb9c
    //     0xa0eb98: bl              #0xd6826c
    // 0xa0eb9c: mov             x0, x5
    // 0xa0eba0: StoreField: r1->field_17 = r0
    //     0xa0eba0: stur            w0, [x1, #0x17]
    //     0xa0eba4: ldurb           w16, [x1, #-1]
    //     0xa0eba8: ldurb           w17, [x0, #-1]
    //     0xa0ebac: and             x16, x17, x16, lsr #2
    //     0xa0ebb0: tst             x16, HEAP, lsr #32
    //     0xa0ebb4: b.eq            #0xa0ebbc
    //     0xa0ebb8: bl              #0xd6826c
    // 0xa0ebbc: r0 = Null
    //     0xa0ebbc: mov             x0, NULL
    // 0xa0ebc0: LeaveFrame
    //     0xa0ebc0: mov             SP, fp
    //     0xa0ebc4: ldp             fp, lr, [SP], #0x10
    // 0xa0ebc8: ret
    //     0xa0ebc8: ret             
  }
  get _ changedProperties(/* No info */) {
    // ** addr: 0xa0f378, size: 0x60
    // 0xa0f378: EnterFrame
    //     0xa0f378: stp             fp, lr, [SP, #-0x10]!
    //     0xa0f37c: mov             fp, SP
    // 0xa0f380: CheckStackOverflow
    //     0xa0f380: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0f384: cmp             SP, x16
    //     0xa0f388: b.ls            #0xa0f3d0
    // 0xa0f38c: ldr             x0, [fp, #0x10]
    // 0xa0f390: LoadField: r1 = r0->field_17
    //     0xa0f390: ldur            w1, [x0, #0x17]
    // 0xa0f394: DecompressPointer r1
    //     0xa0f394: add             x1, x1, HEAP, lsl #32
    // 0xa0f398: r0 = LoadClassIdInstr(r1)
    //     0xa0f398: ldur            x0, [x1, #-1]
    //     0xa0f39c: ubfx            x0, x0, #0xc, #0x14
    // 0xa0f3a0: r16 = 2
    //     0xa0f3a0: mov             x16, #2
    // 0xa0f3a4: stp             x16, x1, [SP, #-0x10]!
    // 0xa0f3a8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa0f3a8: sub             lr, x0, #0xd83
    //     0xa0f3ac: ldr             lr, [x21, lr, lsl #3]
    //     0xa0f3b0: blr             lr
    // 0xa0f3b4: add             SP, SP, #0x10
    // 0xa0f3b8: SaveReg r0
    //     0xa0f3b8: str             x0, [SP, #-8]!
    // 0xa0f3bc: r0 = asStringVariantDict()
    //     0xa0f3bc: bl              #0xa0e484  ; [package:dbus/src/dbus_value.dart] DBusValue::asStringVariantDict
    // 0xa0f3c0: add             SP, SP, #8
    // 0xa0f3c4: LeaveFrame
    //     0xa0f3c4: mov             SP, fp
    //     0xa0f3c8: ldp             fp, lr, [SP], #0x10
    // 0xa0f3cc: ret
    //     0xa0f3cc: ret             
    // 0xa0f3d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0f3d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0f3d4: b               #0xa0f38c
  }
  get _ propertiesInterface(/* No info */) {
    // ** addr: 0xa0f3d8, size: 0xa0
    // 0xa0f3d8: EnterFrame
    //     0xa0f3d8: stp             fp, lr, [SP, #-0x10]!
    //     0xa0f3dc: mov             fp, SP
    // 0xa0f3e0: AllocStack(0x8)
    //     0xa0f3e0: sub             SP, SP, #8
    // 0xa0f3e4: CheckStackOverflow
    //     0xa0f3e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0f3e8: cmp             SP, x16
    //     0xa0f3ec: b.ls            #0xa0f470
    // 0xa0f3f0: ldr             x0, [fp, #0x10]
    // 0xa0f3f4: LoadField: r1 = r0->field_17
    //     0xa0f3f4: ldur            w1, [x0, #0x17]
    // 0xa0f3f8: DecompressPointer r1
    //     0xa0f3f8: add             x1, x1, HEAP, lsl #32
    // 0xa0f3fc: r0 = LoadClassIdInstr(r1)
    //     0xa0f3fc: ldur            x0, [x1, #-1]
    //     0xa0f400: ubfx            x0, x0, #0xc, #0x14
    // 0xa0f404: stp             xzr, x1, [SP, #-0x10]!
    // 0xa0f408: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa0f408: sub             lr, x0, #0xd83
    //     0xa0f40c: ldr             lr, [x21, lr, lsl #3]
    //     0xa0f410: blr             lr
    // 0xa0f414: add             SP, SP, #0x10
    // 0xa0f418: mov             x3, x0
    // 0xa0f41c: r2 = Null
    //     0xa0f41c: mov             x2, NULL
    // 0xa0f420: r1 = Null
    //     0xa0f420: mov             x1, NULL
    // 0xa0f424: stur            x3, [fp, #-8]
    // 0xa0f428: r4 = 59
    //     0xa0f428: mov             x4, #0x3b
    // 0xa0f42c: branchIfSmi(r0, 0xa0f438)
    //     0xa0f42c: tbz             w0, #0, #0xa0f438
    // 0xa0f430: r4 = LoadClassIdInstr(r0)
    //     0xa0f430: ldur            x4, [x0, #-1]
    //     0xa0f434: ubfx            x4, x4, #0xc, #0x14
    // 0xa0f438: r17 = -4573
    //     0xa0f438: mov             x17, #-0x11dd
    // 0xa0f43c: add             x4, x4, x17
    // 0xa0f440: cmp             x4, #1
    // 0xa0f444: b.ls            #0xa0f458
    // 0xa0f448: r8 = DBusString
    //     0xa0f448: ldr             x8, [PP, #0x7930]  ; [pp+0x7930] Type: DBusString
    // 0xa0f44c: r3 = Null
    //     0xa0f44c: add             x3, PP, #0x21, lsl #12  ; [pp+0x211b0] Null
    //     0xa0f450: ldr             x3, [x3, #0x1b0]
    // 0xa0f454: r0 = DefaultTypeTest()
    //     0xa0f454: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa0f458: ldur            x1, [fp, #-8]
    // 0xa0f45c: LoadField: r0 = r1->field_7
    //     0xa0f45c: ldur            w0, [x1, #7]
    // 0xa0f460: DecompressPointer r0
    //     0xa0f460: add             x0, x0, HEAP, lsl #32
    // 0xa0f464: LeaveFrame
    //     0xa0f464: mov             SP, fp
    //     0xa0f468: ldp             fp, lr, [SP], #0x10
    // 0xa0f46c: ret
    //     0xa0f46c: ret             
    // 0xa0f470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0f470: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0f474: b               #0xa0f3f0
  }
}

// class id: 5628, size: 0x1c, field offset: 0x1c
class DBusRemoteObjectSignalStream extends DBusSignalStream {

  _ DBusRemoteObjectSignalStream(/* No info */) {
    // ** addr: 0xa0e9a8, size: 0x6c
    // 0xa0e9a8: EnterFrame
    //     0xa0e9a8: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e9ac: mov             fp, SP
    // 0xa0e9b0: CheckStackOverflow
    //     0xa0e9b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0e9b4: cmp             SP, x16
    //     0xa0e9b8: b.ls            #0xa0ea0c
    // 0xa0e9bc: ldr             x0, [fp, #0x10]
    // 0xa0e9c0: LoadField: r1 = r0->field_7
    //     0xa0e9c0: ldur            w1, [x0, #7]
    // 0xa0e9c4: DecompressPointer r1
    //     0xa0e9c4: add             x1, x1, HEAP, lsl #32
    // 0xa0e9c8: LoadField: r2 = r0->field_f
    //     0xa0e9c8: ldur            w2, [x0, #0xf]
    // 0xa0e9cc: DecompressPointer r2
    //     0xa0e9cc: add             x2, x2, HEAP, lsl #32
    // 0xa0e9d0: ldr             x16, [fp, #0x18]
    // 0xa0e9d4: stp             x1, x16, [SP, #-0x10]!
    // 0xa0e9d8: r16 = "org.freedesktop.NetworkManager"
    //     0xa0e9d8: ldr             x16, [PP, #0x3a0]  ; [pp+0x3a0] "org.freedesktop.NetworkManager"
    // 0xa0e9dc: stp             x2, x16, [SP, #-0x10]!
    // 0xa0e9e0: r16 = "org.freedesktop.DBus.Properties"
    //     0xa0e9e0: ldr             x16, [PP, #0x3f0]  ; [pp+0x3f0] "org.freedesktop.DBus.Properties"
    // 0xa0e9e4: r30 = "PropertiesChanged"
    //     0xa0e9e4: ldr             lr, [PP, #0x3f8]  ; [pp+0x3f8] "PropertiesChanged"
    // 0xa0e9e8: stp             lr, x16, [SP, #-0x10]!
    // 0xa0e9ec: SaveReg rNULL
    //     0xa0e9ec: str             NULL, [SP, #-8]!
    // 0xa0e9f0: r4 = const [0, 0x7, 0x7, 0x3, interface, 0x4, name, 0x5, path, 0x3, signature, 0x6, null]
    //     0xa0e9f0: ldr             x4, [PP, #0x760]  ; [pp+0x760] List(13) [0, 0x7, 0x7, 0x3, "interface", 0x4, "name", 0x5, "path", 0x3, "signature", 0x6, Null]
    // 0xa0e9f4: r0 = DBusSignalStream()
    //     0xa0e9f4: bl              #0xa02c18  ; [package:dbus/src/dbus_client.dart] DBusSignalStream::DBusSignalStream
    // 0xa0e9f8: add             SP, SP, #0x38
    // 0xa0e9fc: r0 = Null
    //     0xa0e9fc: mov             x0, NULL
    // 0xa0ea00: LeaveFrame
    //     0xa0ea00: mov             SP, fp
    //     0xa0ea04: ldp             fp, lr, [SP], #0x10
    // 0xa0ea08: ret
    //     0xa0ea08: ret             
    // 0xa0ea0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0ea0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0ea10: b               #0xa0e9bc
  }
}

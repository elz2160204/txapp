// lib: , url: package:characters/src/extensions.dart

// class id: 1048741, size: 0x8
class :: {

  static _ StringCharacters.characters(/* No info */) {
    // ** addr: 0x5254a4, size: 0x38
    // 0x5254a4: EnterFrame
    //     0x5254a4: stp             fp, lr, [SP, #-0x10]!
    //     0x5254a8: mov             fp, SP
    // 0x5254ac: CheckStackOverflow
    //     0x5254ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5254b0: cmp             SP, x16
    //     0x5254b4: b.ls            #0x5254d4
    // 0x5254b8: ldr             x16, [fp, #0x10]
    // 0x5254bc: stp             x16, NULL, [SP, #-0x10]!
    // 0x5254c0: r0 = Characters()
    //     0x5254c0: bl              #0x5254dc  ; [package:characters/src/characters.dart] Characters::Characters
    // 0x5254c4: add             SP, SP, #0x10
    // 0x5254c8: LeaveFrame
    //     0x5254c8: mov             SP, fp
    //     0x5254cc: ldp             fp, lr, [SP], #0x10
    // 0x5254d0: ret
    //     0x5254d0: ret             
    // 0x5254d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5254d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5254d8: b               #0x5254b8
  }
}

// lib: , url: package:characters/src/characters.dart

// class id: 1048739, size: 0x8
class :: {
}

// class id: 4790, size: 0x8, field offset: 0x8
abstract class CharacterRange extends Object
    implements Iterator<X0> {
}

// class id: 4791, size: 0x8, field offset: 0x8
abstract class Characters extends Object
    implements Iterable<X0> {

  factory Characters Characters(dynamic, String) {
    // ** addr: 0x5254dc, size: 0x40
    // 0x5254dc: EnterFrame
    //     0x5254dc: stp             fp, lr, [SP, #-0x10]!
    //     0x5254e0: mov             fp, SP
    // 0x5254e4: ldr             x0, [fp, #0x10]
    // 0x5254e8: LoadField: r1 = r0->field_7
    //     0x5254e8: ldur            w1, [x0, #7]
    // 0x5254ec: DecompressPointer r1
    //     0x5254ec: add             x1, x1, HEAP, lsl #32
    // 0x5254f0: cbnz            w1, #0x525500
    // 0x5254f4: r0 = Instance_StringCharacters
    //     0x5254f4: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f610] Obj!StringCharacters<String>@b67cf1
    //     0x5254f8: ldr             x0, [x0, #0x610]
    // 0x5254fc: b               #0x525510
    // 0x525500: r1 = <String>
    //     0x525500: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x525504: r0 = StringCharacters()
    //     0x525504: bl              #0x52551c  ; AllocateStringCharactersStub -> StringCharacters (size=0x10)
    // 0x525508: ldr             x1, [fp, #0x10]
    // 0x52550c: StoreField: r0->field_b = r1
    //     0x52550c: stur            w1, [x0, #0xb]
    // 0x525510: LeaveFrame
    //     0x525510: mov             SP, fp
    //     0x525514: ldp             fp, lr, [SP], #0x10
    // 0x525518: ret
    //     0x525518: ret             
  }
}

// lib: , url: file:///var/www/html/flutter3/tx_app/.dart_tool/flutter_build/dart_plugin_registrant.dart

// class id: 1048593, size: 0x8
class :: {
}

// class id: 5008, size: 0x8, field offset: 0x8
class _PluginRegistrant extends Object {

  static void register() {
    // ** addr: 0xd6c7e8, size: 0xc98
    // 0xd6c7e8: EnterFrame
    //     0xd6c7e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd6c7ec: mov             fp, SP
    // 0xd6c7f0: AllocStack(0x38)
    //     0xd6c7f0: sub             SP, SP, #0x38
    // 0xd6c7f4: CheckStackOverflow
    //     0xd6c7f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6c7f8: cmp             SP, x16
    //     0xd6c7fc: b.ls            #0xd6d478
    // 0xd6c800: r0 = InitLateStaticField(0x698) // [dart:io] Platform::isAndroid
    //     0xd6c800: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6c804: ldr             x0, [x0, #0xd30]
    //     0xd6c808: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6c80c: cmp             w0, w16
    //     0xd6c810: b.ne            #0xd6c81c
    //     0xd6c814: ldr             x2, [PP, #0x60]  ; [pp+0x60] Field <Platform.isAndroid>: static late final (offset: 0x698)
    //     0xd6c818: bl              #0xd67cdc
    // 0xd6c81c: tbnz            w0, #4, #0xd6c840
    // 0xd6c820: r0 = registerWith()
    //     0xd6c820: bl              #0xd70700  ; [package:camera_android/src/android_camera.dart] AndroidCamera::registerWith
    // 0xd6c824: r0 = registerWith()
    //     0xd6c824: bl              #0xd7062c  ; [package:path_provider_android/path_provider_android.dart] PathProviderAndroid::registerWith
    // 0xd6c828: r0 = registerWith()
    //     0xd6c828: bl              #0xd70558  ; [package:shared_preferences_android/shared_preferences_android.dart] SharedPreferencesAndroid::registerWith
    // 0xd6c82c: r0 = registerWith()
    //     0xd6c82c: bl              #0xd7044c  ; [package:sqflite/src/sqflite_plugin.dart] SqflitePlugin::registerWith
    // 0xd6c830: r0 = registerWith()
    //     0xd6c830: bl              #0xd70378  ; [package:url_launcher_android/url_launcher_android.dart] UrlLauncherAndroid::registerWith
    // 0xd6c834: r0 = registerWith()
    //     0xd6c834: bl              #0xd7023c  ; [package:video_player_android/src/android_video_player.dart] AndroidVideoPlayer::registerWith
    // 0xd6c838: r0 = registerWith()
    //     0xd6c838: bl              #0xd70180  ; [package:webview_flutter_android/src/android_webview_platform.dart] AndroidWebViewPlatform::registerWith
    // 0xd6c83c: b               #0xd6c928
    // 0xd6c840: r0 = InitLateStaticField(0x69c) // [dart:io] Platform::isIOS
    //     0xd6c840: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6c844: ldr             x0, [x0, #0xd38]
    //     0xd6c848: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6c84c: cmp             w0, w16
    //     0xd6c850: b.ne            #0xd6c85c
    //     0xd6c854: ldr             x2, [PP, #0x68]  ; [pp+0x68] Field <Platform.isIOS>: static late final (offset: 0x69c)
    //     0xd6c858: bl              #0xd67cdc
    // 0xd6c85c: tbnz            w0, #4, #0xd6c880
    // 0xd6c860: r0 = registerWith()
    //     0xd6c860: bl              #0xd6ffbc  ; [package:camera_avfoundation/src/avfoundation_camera.dart] AVFoundationCamera::registerWith
    // 0xd6c864: r0 = registerWith()
    //     0xd6c864: bl              #0xd6fee8  ; [package:path_provider_foundation/path_provider_foundation.dart] PathProviderFoundation::registerWith
    // 0xd6c868: r0 = registerWith()
    //     0xd6c868: bl              #0xd6fda0  ; [package:shared_preferences_foundation/shared_preferences_foundation.dart] SharedPreferencesFoundation::registerWith
    // 0xd6c86c: r0 = registerWith()
    //     0xd6c86c: bl              #0xd7044c  ; [package:sqflite/src/sqflite_plugin.dart] SqflitePlugin::registerWith
    // 0xd6c870: r0 = registerWith()
    //     0xd6c870: bl              #0xd6fc64  ; [package:url_launcher_ios/url_launcher_ios.dart] UrlLauncherIOS::registerWith
    // 0xd6c874: r0 = registerWith()
    //     0xd6c874: bl              #0xd6faec  ; [package:video_player_avfoundation/src/avfoundation_video_player.dart] AVFoundationVideoPlayer::registerWith
    // 0xd6c878: r0 = registerWith()
    //     0xd6c878: bl              #0xd6f9dc  ; [package:webview_flutter_wkwebview/src/webkit_webview_platform.dart] WebKitWebViewPlatform::registerWith
    // 0xd6c87c: b               #0xd6c928
    // 0xd6c880: r0 = InitLateStaticField(0x68c) // [dart:io] Platform::isLinux
    //     0xd6c880: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6c884: ldr             x0, [x0, #0xd18]
    //     0xd6c888: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6c88c: cmp             w0, w16
    //     0xd6c890: b.ne            #0xd6c89c
    //     0xd6c894: ldr             x2, [PP, #0x70]  ; [pp+0x70] Field <Platform.isLinux>: static late final (offset: 0x68c)
    //     0xd6c898: bl              #0xd67cdc
    // 0xd6c89c: tbnz            w0, #4, #0xd6c8bc
    // 0xd6c8a0: r0 = registerWith()
    //     0xd6c8a0: bl              #0xd6e218  ; [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::registerWith
    // 0xd6c8a4: r0 = registerWith()
    //     0xd6c8a4: bl              #0xd6e154  ; [package:device_info_plus/src/device_info_plus_linux.dart] DeviceInfoPlusLinuxPlugin::registerWith
    // 0xd6c8a8: r0 = registerWith()
    //     0xd6c8a8: bl              #0xd6e098  ; [package:flutter_keyboard_visibility_linux/flutter_keyboard_visibility_linux.dart] FlutterKeyboardVisibilityPluginLinux::registerWith
    // 0xd6c8ac: r0 = registerWith()
    //     0xd6c8ac: bl              #0xd6e01c  ; [package:path_provider_linux/src/path_provider_linux.dart] PathProviderLinux::registerWith
    // 0xd6c8b0: r0 = registerWith()
    //     0xd6c8b0: bl              #0xd6de18  ; [package:shared_preferences_linux/shared_preferences_linux.dart] SharedPreferencesLinux::registerWith
    // 0xd6c8b4: r0 = registerWith()
    //     0xd6c8b4: bl              #0xd6dd5c  ; [package:url_launcher_linux/url_launcher_linux.dart] UrlLauncherLinux::registerWith
    // 0xd6c8b8: b               #0xd6c928
    // 0xd6c8bc: r0 = InitLateStaticField(0x690) // [dart:io] Platform::isMacOS
    //     0xd6c8bc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6c8c0: ldr             x0, [x0, #0xd20]
    //     0xd6c8c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6c8c8: cmp             w0, w16
    //     0xd6c8cc: b.ne            #0xd6c8d8
    //     0xd6c8d0: ldr             x2, [PP, #0x78]  ; [pp+0x78] Field <Platform.isMacOS>: static late final (offset: 0x690)
    //     0xd6c8d4: bl              #0xd67cdc
    // 0xd6c8d8: tbnz            w0, #4, #0xd6c8f4
    // 0xd6c8dc: r0 = registerWith()
    //     0xd6c8dc: bl              #0xd6dca0  ; [package:flutter_keyboard_visibility_macos/flutter_keyboard_visibility_macos.dart] FlutterKeyboardVisibilityPluginMacos::registerWith
    // 0xd6c8e0: r0 = registerWith()
    //     0xd6c8e0: bl              #0xd6fee8  ; [package:path_provider_foundation/path_provider_foundation.dart] PathProviderFoundation::registerWith
    // 0xd6c8e4: r0 = registerWith()
    //     0xd6c8e4: bl              #0xd6fda0  ; [package:shared_preferences_foundation/shared_preferences_foundation.dart] SharedPreferencesFoundation::registerWith
    // 0xd6c8e8: r0 = registerWith()
    //     0xd6c8e8: bl              #0xd7044c  ; [package:sqflite/src/sqflite_plugin.dart] SqflitePlugin::registerWith
    // 0xd6c8ec: r0 = registerWith()
    //     0xd6c8ec: bl              #0xd6db64  ; [package:url_launcher_macos/url_launcher_macos.dart] UrlLauncherMacOS::registerWith
    // 0xd6c8f0: b               #0xd6c928
    // 0xd6c8f4: r0 = InitLateStaticField(0x694) // [dart:io] Platform::isWindows
    //     0xd6c8f4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6c8f8: ldr             x0, [x0, #0xd28]
    //     0xd6c8fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6c900: cmp             w0, w16
    //     0xd6c904: b.ne            #0xd6c910
    //     0xd6c908: ldr             x2, [PP, #0x80]  ; [pp+0x80] Field <Platform.isWindows>: static late final (offset: 0x694)
    //     0xd6c90c: bl              #0xd67cdc
    // 0xd6c910: tbnz            w0, #4, #0xd6c928
    // 0xd6c914: r0 = registerWith()
    //     0xd6c914: bl              #0xd6da54  ; [package:device_info_plus/src/device_info_plus_windows.dart] DeviceInfoPlusWindowsPlugin::registerWith
    // 0xd6c918: r0 = registerWith()
    //     0xd6c918: bl              #0xd6d8fc  ; [package:flutter_keyboard_visibility_windows/flutter_keyboard_visibility_windows.dart] FlutterKeyboardVisibilityPluginWindows::registerWith
    // 0xd6c91c: r0 = registerWith()
    //     0xd6c91c: bl              #0xd6d844  ; [package:path_provider_windows/src/path_provider_windows_real.dart] PathProviderWindows::registerWith
    // 0xd6c920: r0 = registerWith()
    //     0xd6c920: bl              #0xd6d5f8  ; [package:shared_preferences_windows/shared_preferences_windows.dart] SharedPreferencesWindows::registerWith
    // 0xd6c924: r0 = registerWith()
    //     0xd6c924: bl              #0xd6d480  ; [package:url_launcher_windows/url_launcher_windows.dart] UrlLauncherWindows::registerWith
    // 0xd6c928: r0 = Null
    //     0xd6c928: mov             x0, NULL
    // 0xd6c92c: LeaveFrame
    //     0xd6c92c: mov             SP, fp
    //     0xd6c930: ldp             fp, lr, [SP], #0x10
    // 0xd6c934: ret
    //     0xd6c934: ret             
    // 0xd6c938: sub             SP, fp, #0x38
    // 0xd6c93c: mov             x3, x0
    // 0xd6c940: stur            x0, [fp, #-0x30]
    // 0xd6c944: mov             x0, x1
    // 0xd6c948: stur            x1, [fp, #-0x38]
    // 0xd6c94c: r1 = Null
    //     0xd6c94c: mov             x1, NULL
    // 0xd6c950: r2 = 6
    //     0xd6c950: mov             x2, #6
    // 0xd6c954: r0 = AllocateArray()
    //     0xd6c954: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6c958: r17 = "`camera_android` threw an error: "
    //     0xd6c958: ldr             x17, [PP, #0x88]  ; [pp+0x88] "`camera_android` threw an error: "
    // 0xd6c95c: StoreField: r0->field_f = r17
    //     0xd6c95c: stur            w17, [x0, #0xf]
    // 0xd6c960: ldur            x1, [fp, #-0x30]
    // 0xd6c964: StoreField: r0->field_13 = r1
    //     0xd6c964: stur            w1, [x0, #0x13]
    // 0xd6c968: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6c968: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6c96c: StoreField: r0->field_17 = r17
    //     0xd6c96c: stur            w17, [x0, #0x17]
    // 0xd6c970: SaveReg r0
    //     0xd6c970: str             x0, [SP, #-8]!
    // 0xd6c974: r0 = _interpolate()
    //     0xd6c974: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6c978: add             SP, SP, #8
    // 0xd6c97c: SaveReg r0
    //     0xd6c97c: str             x0, [SP, #-8]!
    // 0xd6c980: r0 = print()
    //     0xd6c980: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6c984: add             SP, SP, #8
    // 0xd6c988: ldur            x0, [fp, #-0x30]
    // 0xd6c98c: ldur            x1, [fp, #-0x38]
    // 0xd6c990: r0 = ReThrow()
    //     0xd6c990: bl              #0xd67e14  ; ReThrowStub
    // 0xd6c994: brk             #0
    // 0xd6c998: sub             SP, fp, #0x38
    // 0xd6c99c: mov             x3, x0
    // 0xd6c9a0: stur            x0, [fp, #-0x30]
    // 0xd6c9a4: mov             x0, x1
    // 0xd6c9a8: stur            x1, [fp, #-0x38]
    // 0xd6c9ac: r1 = Null
    //     0xd6c9ac: mov             x1, NULL
    // 0xd6c9b0: r2 = 6
    //     0xd6c9b0: mov             x2, #6
    // 0xd6c9b4: r0 = AllocateArray()
    //     0xd6c9b4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6c9b8: r17 = "`path_provider_android` threw an error: "
    //     0xd6c9b8: ldr             x17, [PP, #0x98]  ; [pp+0x98] "`path_provider_android` threw an error: "
    // 0xd6c9bc: StoreField: r0->field_f = r17
    //     0xd6c9bc: stur            w17, [x0, #0xf]
    // 0xd6c9c0: ldur            x1, [fp, #-0x30]
    // 0xd6c9c4: StoreField: r0->field_13 = r1
    //     0xd6c9c4: stur            w1, [x0, #0x13]
    // 0xd6c9c8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6c9c8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6c9cc: StoreField: r0->field_17 = r17
    //     0xd6c9cc: stur            w17, [x0, #0x17]
    // 0xd6c9d0: SaveReg r0
    //     0xd6c9d0: str             x0, [SP, #-8]!
    // 0xd6c9d4: r0 = _interpolate()
    //     0xd6c9d4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6c9d8: add             SP, SP, #8
    // 0xd6c9dc: SaveReg r0
    //     0xd6c9dc: str             x0, [SP, #-8]!
    // 0xd6c9e0: r0 = print()
    //     0xd6c9e0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6c9e4: add             SP, SP, #8
    // 0xd6c9e8: ldur            x0, [fp, #-0x30]
    // 0xd6c9ec: ldur            x1, [fp, #-0x38]
    // 0xd6c9f0: r0 = ReThrow()
    //     0xd6c9f0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6c9f4: brk             #0
    // 0xd6c9f8: sub             SP, fp, #0x38
    // 0xd6c9fc: mov             x3, x0
    // 0xd6ca00: stur            x0, [fp, #-0x30]
    // 0xd6ca04: mov             x0, x1
    // 0xd6ca08: stur            x1, [fp, #-0x38]
    // 0xd6ca0c: r1 = Null
    //     0xd6ca0c: mov             x1, NULL
    // 0xd6ca10: r2 = 6
    //     0xd6ca10: mov             x2, #6
    // 0xd6ca14: r0 = AllocateArray()
    //     0xd6ca14: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6ca18: r17 = "`shared_preferences_android` threw an error: "
    //     0xd6ca18: ldr             x17, [PP, #0xa0]  ; [pp+0xa0] "`shared_preferences_android` threw an error: "
    // 0xd6ca1c: StoreField: r0->field_f = r17
    //     0xd6ca1c: stur            w17, [x0, #0xf]
    // 0xd6ca20: ldur            x1, [fp, #-0x30]
    // 0xd6ca24: StoreField: r0->field_13 = r1
    //     0xd6ca24: stur            w1, [x0, #0x13]
    // 0xd6ca28: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6ca28: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6ca2c: StoreField: r0->field_17 = r17
    //     0xd6ca2c: stur            w17, [x0, #0x17]
    // 0xd6ca30: SaveReg r0
    //     0xd6ca30: str             x0, [SP, #-8]!
    // 0xd6ca34: r0 = _interpolate()
    //     0xd6ca34: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6ca38: add             SP, SP, #8
    // 0xd6ca3c: SaveReg r0
    //     0xd6ca3c: str             x0, [SP, #-8]!
    // 0xd6ca40: r0 = print()
    //     0xd6ca40: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6ca44: add             SP, SP, #8
    // 0xd6ca48: ldur            x0, [fp, #-0x30]
    // 0xd6ca4c: ldur            x1, [fp, #-0x38]
    // 0xd6ca50: r0 = ReThrow()
    //     0xd6ca50: bl              #0xd67e14  ; ReThrowStub
    // 0xd6ca54: brk             #0
    // 0xd6ca58: sub             SP, fp, #0x38
    // 0xd6ca5c: mov             x3, x0
    // 0xd6ca60: stur            x0, [fp, #-0x30]
    // 0xd6ca64: mov             x0, x1
    // 0xd6ca68: stur            x1, [fp, #-0x38]
    // 0xd6ca6c: r1 = Null
    //     0xd6ca6c: mov             x1, NULL
    // 0xd6ca70: r2 = 6
    //     0xd6ca70: mov             x2, #6
    // 0xd6ca74: r0 = AllocateArray()
    //     0xd6ca74: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6ca78: r17 = "`sqflite` threw an error: "
    //     0xd6ca78: ldr             x17, [PP, #0xa8]  ; [pp+0xa8] "`sqflite` threw an error: "
    // 0xd6ca7c: StoreField: r0->field_f = r17
    //     0xd6ca7c: stur            w17, [x0, #0xf]
    // 0xd6ca80: ldur            x1, [fp, #-0x30]
    // 0xd6ca84: StoreField: r0->field_13 = r1
    //     0xd6ca84: stur            w1, [x0, #0x13]
    // 0xd6ca88: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6ca88: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6ca8c: StoreField: r0->field_17 = r17
    //     0xd6ca8c: stur            w17, [x0, #0x17]
    // 0xd6ca90: SaveReg r0
    //     0xd6ca90: str             x0, [SP, #-8]!
    // 0xd6ca94: r0 = _interpolate()
    //     0xd6ca94: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6ca98: add             SP, SP, #8
    // 0xd6ca9c: SaveReg r0
    //     0xd6ca9c: str             x0, [SP, #-8]!
    // 0xd6caa0: r0 = print()
    //     0xd6caa0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6caa4: add             SP, SP, #8
    // 0xd6caa8: ldur            x0, [fp, #-0x30]
    // 0xd6caac: ldur            x1, [fp, #-0x38]
    // 0xd6cab0: r0 = ReThrow()
    //     0xd6cab0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cab4: brk             #0
    // 0xd6cab8: sub             SP, fp, #0x38
    // 0xd6cabc: mov             x3, x0
    // 0xd6cac0: stur            x0, [fp, #-0x30]
    // 0xd6cac4: mov             x0, x1
    // 0xd6cac8: stur            x1, [fp, #-0x38]
    // 0xd6cacc: r1 = Null
    //     0xd6cacc: mov             x1, NULL
    // 0xd6cad0: r2 = 6
    //     0xd6cad0: mov             x2, #6
    // 0xd6cad4: r0 = AllocateArray()
    //     0xd6cad4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cad8: r17 = "`url_launcher_android` threw an error: "
    //     0xd6cad8: ldr             x17, [PP, #0xb0]  ; [pp+0xb0] "`url_launcher_android` threw an error: "
    // 0xd6cadc: StoreField: r0->field_f = r17
    //     0xd6cadc: stur            w17, [x0, #0xf]
    // 0xd6cae0: ldur            x1, [fp, #-0x30]
    // 0xd6cae4: StoreField: r0->field_13 = r1
    //     0xd6cae4: stur            w1, [x0, #0x13]
    // 0xd6cae8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cae8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6caec: StoreField: r0->field_17 = r17
    //     0xd6caec: stur            w17, [x0, #0x17]
    // 0xd6caf0: SaveReg r0
    //     0xd6caf0: str             x0, [SP, #-8]!
    // 0xd6caf4: r0 = _interpolate()
    //     0xd6caf4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6caf8: add             SP, SP, #8
    // 0xd6cafc: SaveReg r0
    //     0xd6cafc: str             x0, [SP, #-8]!
    // 0xd6cb00: r0 = print()
    //     0xd6cb00: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cb04: add             SP, SP, #8
    // 0xd6cb08: ldur            x0, [fp, #-0x30]
    // 0xd6cb0c: ldur            x1, [fp, #-0x38]
    // 0xd6cb10: r0 = ReThrow()
    //     0xd6cb10: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cb14: brk             #0
    // 0xd6cb18: sub             SP, fp, #0x38
    // 0xd6cb1c: mov             x3, x0
    // 0xd6cb20: stur            x0, [fp, #-0x30]
    // 0xd6cb24: mov             x0, x1
    // 0xd6cb28: stur            x1, [fp, #-0x38]
    // 0xd6cb2c: r1 = Null
    //     0xd6cb2c: mov             x1, NULL
    // 0xd6cb30: r2 = 6
    //     0xd6cb30: mov             x2, #6
    // 0xd6cb34: r0 = AllocateArray()
    //     0xd6cb34: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cb38: r17 = "`video_player_android` threw an error: "
    //     0xd6cb38: ldr             x17, [PP, #0xb8]  ; [pp+0xb8] "`video_player_android` threw an error: "
    // 0xd6cb3c: StoreField: r0->field_f = r17
    //     0xd6cb3c: stur            w17, [x0, #0xf]
    // 0xd6cb40: ldur            x1, [fp, #-0x30]
    // 0xd6cb44: StoreField: r0->field_13 = r1
    //     0xd6cb44: stur            w1, [x0, #0x13]
    // 0xd6cb48: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cb48: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cb4c: StoreField: r0->field_17 = r17
    //     0xd6cb4c: stur            w17, [x0, #0x17]
    // 0xd6cb50: SaveReg r0
    //     0xd6cb50: str             x0, [SP, #-8]!
    // 0xd6cb54: r0 = _interpolate()
    //     0xd6cb54: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6cb58: add             SP, SP, #8
    // 0xd6cb5c: SaveReg r0
    //     0xd6cb5c: str             x0, [SP, #-8]!
    // 0xd6cb60: r0 = print()
    //     0xd6cb60: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cb64: add             SP, SP, #8
    // 0xd6cb68: ldur            x0, [fp, #-0x30]
    // 0xd6cb6c: ldur            x1, [fp, #-0x38]
    // 0xd6cb70: r0 = ReThrow()
    //     0xd6cb70: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cb74: brk             #0
    // 0xd6cb78: sub             SP, fp, #0x38
    // 0xd6cb7c: mov             x3, x0
    // 0xd6cb80: stur            x0, [fp, #-0x30]
    // 0xd6cb84: mov             x0, x1
    // 0xd6cb88: stur            x1, [fp, #-0x38]
    // 0xd6cb8c: r1 = Null
    //     0xd6cb8c: mov             x1, NULL
    // 0xd6cb90: r2 = 6
    //     0xd6cb90: mov             x2, #6
    // 0xd6cb94: r0 = AllocateArray()
    //     0xd6cb94: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cb98: r17 = "`webview_flutter_android` threw an error: "
    //     0xd6cb98: ldr             x17, [PP, #0xc0]  ; [pp+0xc0] "`webview_flutter_android` threw an error: "
    // 0xd6cb9c: StoreField: r0->field_f = r17
    //     0xd6cb9c: stur            w17, [x0, #0xf]
    // 0xd6cba0: ldur            x1, [fp, #-0x30]
    // 0xd6cba4: StoreField: r0->field_13 = r1
    //     0xd6cba4: stur            w1, [x0, #0x13]
    // 0xd6cba8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cba8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cbac: StoreField: r0->field_17 = r17
    //     0xd6cbac: stur            w17, [x0, #0x17]
    // 0xd6cbb0: SaveReg r0
    //     0xd6cbb0: str             x0, [SP, #-8]!
    // 0xd6cbb4: r0 = _interpolate()
    //     0xd6cbb4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6cbb8: add             SP, SP, #8
    // 0xd6cbbc: SaveReg r0
    //     0xd6cbbc: str             x0, [SP, #-8]!
    // 0xd6cbc0: r0 = print()
    //     0xd6cbc0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cbc4: add             SP, SP, #8
    // 0xd6cbc8: ldur            x0, [fp, #-0x30]
    // 0xd6cbcc: ldur            x1, [fp, #-0x38]
    // 0xd6cbd0: r0 = ReThrow()
    //     0xd6cbd0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cbd4: brk             #0
    // 0xd6cbd8: sub             SP, fp, #0x38
    // 0xd6cbdc: mov             x3, x0
    // 0xd6cbe0: stur            x0, [fp, #-0x30]
    // 0xd6cbe4: mov             x0, x1
    // 0xd6cbe8: stur            x1, [fp, #-0x38]
    // 0xd6cbec: r1 = Null
    //     0xd6cbec: mov             x1, NULL
    // 0xd6cbf0: r2 = 6
    //     0xd6cbf0: mov             x2, #6
    // 0xd6cbf4: r0 = AllocateArray()
    //     0xd6cbf4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cbf8: r17 = "`camera_avfoundation` threw an error: "
    //     0xd6cbf8: ldr             x17, [PP, #0xc8]  ; [pp+0xc8] "`camera_avfoundation` threw an error: "
    // 0xd6cbfc: StoreField: r0->field_f = r17
    //     0xd6cbfc: stur            w17, [x0, #0xf]
    // 0xd6cc00: ldur            x1, [fp, #-0x30]
    // 0xd6cc04: StoreField: r0->field_13 = r1
    //     0xd6cc04: stur            w1, [x0, #0x13]
    // 0xd6cc08: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cc08: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cc0c: StoreField: r0->field_17 = r17
    //     0xd6cc0c: stur            w17, [x0, #0x17]
    // 0xd6cc10: SaveReg r0
    //     0xd6cc10: str             x0, [SP, #-8]!
    // 0xd6cc14: r0 = _interpolate()
    //     0xd6cc14: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6cc18: add             SP, SP, #8
    // 0xd6cc1c: SaveReg r0
    //     0xd6cc1c: str             x0, [SP, #-8]!
    // 0xd6cc20: r0 = print()
    //     0xd6cc20: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cc24: add             SP, SP, #8
    // 0xd6cc28: ldur            x0, [fp, #-0x30]
    // 0xd6cc2c: ldur            x1, [fp, #-0x38]
    // 0xd6cc30: r0 = ReThrow()
    //     0xd6cc30: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cc34: brk             #0
    // 0xd6cc38: sub             SP, fp, #0x38
    // 0xd6cc3c: mov             x3, x0
    // 0xd6cc40: stur            x0, [fp, #-0x30]
    // 0xd6cc44: mov             x0, x1
    // 0xd6cc48: stur            x1, [fp, #-0x38]
    // 0xd6cc4c: r1 = Null
    //     0xd6cc4c: mov             x1, NULL
    // 0xd6cc50: r2 = 6
    //     0xd6cc50: mov             x2, #6
    // 0xd6cc54: r0 = AllocateArray()
    //     0xd6cc54: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cc58: r17 = "`path_provider_foundation` threw an error: "
    //     0xd6cc58: ldr             x17, [PP, #0xd0]  ; [pp+0xd0] "`path_provider_foundation` threw an error: "
    // 0xd6cc5c: StoreField: r0->field_f = r17
    //     0xd6cc5c: stur            w17, [x0, #0xf]
    // 0xd6cc60: ldur            x1, [fp, #-0x30]
    // 0xd6cc64: StoreField: r0->field_13 = r1
    //     0xd6cc64: stur            w1, [x0, #0x13]
    // 0xd6cc68: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cc68: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cc6c: StoreField: r0->field_17 = r17
    //     0xd6cc6c: stur            w17, [x0, #0x17]
    // 0xd6cc70: SaveReg r0
    //     0xd6cc70: str             x0, [SP, #-8]!
    // 0xd6cc74: r0 = _interpolate()
    //     0xd6cc74: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6cc78: add             SP, SP, #8
    // 0xd6cc7c: SaveReg r0
    //     0xd6cc7c: str             x0, [SP, #-8]!
    // 0xd6cc80: r0 = print()
    //     0xd6cc80: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cc84: add             SP, SP, #8
    // 0xd6cc88: ldur            x0, [fp, #-0x30]
    // 0xd6cc8c: ldur            x1, [fp, #-0x38]
    // 0xd6cc90: r0 = ReThrow()
    //     0xd6cc90: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cc94: brk             #0
    // 0xd6cc98: sub             SP, fp, #0x38
    // 0xd6cc9c: mov             x3, x0
    // 0xd6cca0: stur            x0, [fp, #-0x30]
    // 0xd6cca4: mov             x0, x1
    // 0xd6cca8: stur            x1, [fp, #-0x38]
    // 0xd6ccac: r1 = Null
    //     0xd6ccac: mov             x1, NULL
    // 0xd6ccb0: r2 = 6
    //     0xd6ccb0: mov             x2, #6
    // 0xd6ccb4: r0 = AllocateArray()
    //     0xd6ccb4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6ccb8: r17 = "`shared_preferences_foundation` threw an error: "
    //     0xd6ccb8: ldr             x17, [PP, #0xd8]  ; [pp+0xd8] "`shared_preferences_foundation` threw an error: "
    // 0xd6ccbc: StoreField: r0->field_f = r17
    //     0xd6ccbc: stur            w17, [x0, #0xf]
    // 0xd6ccc0: ldur            x1, [fp, #-0x30]
    // 0xd6ccc4: StoreField: r0->field_13 = r1
    //     0xd6ccc4: stur            w1, [x0, #0x13]
    // 0xd6ccc8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6ccc8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cccc: StoreField: r0->field_17 = r17
    //     0xd6cccc: stur            w17, [x0, #0x17]
    // 0xd6ccd0: SaveReg r0
    //     0xd6ccd0: str             x0, [SP, #-8]!
    // 0xd6ccd4: r0 = _interpolate()
    //     0xd6ccd4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6ccd8: add             SP, SP, #8
    // 0xd6ccdc: SaveReg r0
    //     0xd6ccdc: str             x0, [SP, #-8]!
    // 0xd6cce0: r0 = print()
    //     0xd6cce0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cce4: add             SP, SP, #8
    // 0xd6cce8: ldur            x0, [fp, #-0x30]
    // 0xd6ccec: ldur            x1, [fp, #-0x38]
    // 0xd6ccf0: r0 = ReThrow()
    //     0xd6ccf0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6ccf4: brk             #0
    // 0xd6ccf8: sub             SP, fp, #0x38
    // 0xd6ccfc: mov             x3, x0
    // 0xd6cd00: stur            x0, [fp, #-0x30]
    // 0xd6cd04: mov             x0, x1
    // 0xd6cd08: stur            x1, [fp, #-0x38]
    // 0xd6cd0c: r1 = Null
    //     0xd6cd0c: mov             x1, NULL
    // 0xd6cd10: r2 = 6
    //     0xd6cd10: mov             x2, #6
    // 0xd6cd14: r0 = AllocateArray()
    //     0xd6cd14: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cd18: r17 = "`sqflite` threw an error: "
    //     0xd6cd18: ldr             x17, [PP, #0xa8]  ; [pp+0xa8] "`sqflite` threw an error: "
    // 0xd6cd1c: StoreField: r0->field_f = r17
    //     0xd6cd1c: stur            w17, [x0, #0xf]
    // 0xd6cd20: ldur            x1, [fp, #-0x30]
    // 0xd6cd24: StoreField: r0->field_13 = r1
    //     0xd6cd24: stur            w1, [x0, #0x13]
    // 0xd6cd28: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cd28: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cd2c: StoreField: r0->field_17 = r17
    //     0xd6cd2c: stur            w17, [x0, #0x17]
    // 0xd6cd30: SaveReg r0
    //     0xd6cd30: str             x0, [SP, #-8]!
    // 0xd6cd34: r0 = _interpolate()
    //     0xd6cd34: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6cd38: add             SP, SP, #8
    // 0xd6cd3c: SaveReg r0
    //     0xd6cd3c: str             x0, [SP, #-8]!
    // 0xd6cd40: r0 = print()
    //     0xd6cd40: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cd44: add             SP, SP, #8
    // 0xd6cd48: ldur            x0, [fp, #-0x30]
    // 0xd6cd4c: ldur            x1, [fp, #-0x38]
    // 0xd6cd50: r0 = ReThrow()
    //     0xd6cd50: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cd54: brk             #0
    // 0xd6cd58: sub             SP, fp, #0x38
    // 0xd6cd5c: mov             x3, x0
    // 0xd6cd60: stur            x0, [fp, #-0x30]
    // 0xd6cd64: mov             x0, x1
    // 0xd6cd68: stur            x1, [fp, #-0x38]
    // 0xd6cd6c: r1 = Null
    //     0xd6cd6c: mov             x1, NULL
    // 0xd6cd70: r2 = 6
    //     0xd6cd70: mov             x2, #6
    // 0xd6cd74: r0 = AllocateArray()
    //     0xd6cd74: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cd78: r17 = "`url_launcher_ios` threw an error: "
    //     0xd6cd78: ldr             x17, [PP, #0xe0]  ; [pp+0xe0] "`url_launcher_ios` threw an error: "
    // 0xd6cd7c: StoreField: r0->field_f = r17
    //     0xd6cd7c: stur            w17, [x0, #0xf]
    // 0xd6cd80: ldur            x1, [fp, #-0x30]
    // 0xd6cd84: StoreField: r0->field_13 = r1
    //     0xd6cd84: stur            w1, [x0, #0x13]
    // 0xd6cd88: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cd88: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cd8c: StoreField: r0->field_17 = r17
    //     0xd6cd8c: stur            w17, [x0, #0x17]
    // 0xd6cd90: SaveReg r0
    //     0xd6cd90: str             x0, [SP, #-8]!
    // 0xd6cd94: r0 = _interpolate()
    //     0xd6cd94: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6cd98: add             SP, SP, #8
    // 0xd6cd9c: SaveReg r0
    //     0xd6cd9c: str             x0, [SP, #-8]!
    // 0xd6cda0: r0 = print()
    //     0xd6cda0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cda4: add             SP, SP, #8
    // 0xd6cda8: ldur            x0, [fp, #-0x30]
    // 0xd6cdac: ldur            x1, [fp, #-0x38]
    // 0xd6cdb0: r0 = ReThrow()
    //     0xd6cdb0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cdb4: brk             #0
    // 0xd6cdb8: sub             SP, fp, #0x38
    // 0xd6cdbc: mov             x3, x0
    // 0xd6cdc0: stur            x0, [fp, #-0x30]
    // 0xd6cdc4: mov             x0, x1
    // 0xd6cdc8: stur            x1, [fp, #-0x38]
    // 0xd6cdcc: r1 = Null
    //     0xd6cdcc: mov             x1, NULL
    // 0xd6cdd0: r2 = 6
    //     0xd6cdd0: mov             x2, #6
    // 0xd6cdd4: r0 = AllocateArray()
    //     0xd6cdd4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cdd8: r17 = "`video_player_avfoundation` threw an error: "
    //     0xd6cdd8: ldr             x17, [PP, #0xe8]  ; [pp+0xe8] "`video_player_avfoundation` threw an error: "
    // 0xd6cddc: StoreField: r0->field_f = r17
    //     0xd6cddc: stur            w17, [x0, #0xf]
    // 0xd6cde0: ldur            x1, [fp, #-0x30]
    // 0xd6cde4: StoreField: r0->field_13 = r1
    //     0xd6cde4: stur            w1, [x0, #0x13]
    // 0xd6cde8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cde8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cdec: StoreField: r0->field_17 = r17
    //     0xd6cdec: stur            w17, [x0, #0x17]
    // 0xd6cdf0: SaveReg r0
    //     0xd6cdf0: str             x0, [SP, #-8]!
    // 0xd6cdf4: r0 = _interpolate()
    //     0xd6cdf4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6cdf8: add             SP, SP, #8
    // 0xd6cdfc: SaveReg r0
    //     0xd6cdfc: str             x0, [SP, #-8]!
    // 0xd6ce00: r0 = print()
    //     0xd6ce00: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6ce04: add             SP, SP, #8
    // 0xd6ce08: ldur            x0, [fp, #-0x30]
    // 0xd6ce0c: ldur            x1, [fp, #-0x38]
    // 0xd6ce10: r0 = ReThrow()
    //     0xd6ce10: bl              #0xd67e14  ; ReThrowStub
    // 0xd6ce14: brk             #0
    // 0xd6ce18: sub             SP, fp, #0x38
    // 0xd6ce1c: mov             x3, x0
    // 0xd6ce20: stur            x0, [fp, #-0x30]
    // 0xd6ce24: mov             x0, x1
    // 0xd6ce28: stur            x1, [fp, #-0x38]
    // 0xd6ce2c: r1 = Null
    //     0xd6ce2c: mov             x1, NULL
    // 0xd6ce30: r2 = 6
    //     0xd6ce30: mov             x2, #6
    // 0xd6ce34: r0 = AllocateArray()
    //     0xd6ce34: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6ce38: r17 = "`webview_flutter_wkwebview` threw an error: "
    //     0xd6ce38: ldr             x17, [PP, #0xf0]  ; [pp+0xf0] "`webview_flutter_wkwebview` threw an error: "
    // 0xd6ce3c: StoreField: r0->field_f = r17
    //     0xd6ce3c: stur            w17, [x0, #0xf]
    // 0xd6ce40: ldur            x1, [fp, #-0x30]
    // 0xd6ce44: StoreField: r0->field_13 = r1
    //     0xd6ce44: stur            w1, [x0, #0x13]
    // 0xd6ce48: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6ce48: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6ce4c: StoreField: r0->field_17 = r17
    //     0xd6ce4c: stur            w17, [x0, #0x17]
    // 0xd6ce50: SaveReg r0
    //     0xd6ce50: str             x0, [SP, #-8]!
    // 0xd6ce54: r0 = _interpolate()
    //     0xd6ce54: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6ce58: add             SP, SP, #8
    // 0xd6ce5c: SaveReg r0
    //     0xd6ce5c: str             x0, [SP, #-8]!
    // 0xd6ce60: r0 = print()
    //     0xd6ce60: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6ce64: add             SP, SP, #8
    // 0xd6ce68: ldur            x0, [fp, #-0x30]
    // 0xd6ce6c: ldur            x1, [fp, #-0x38]
    // 0xd6ce70: r0 = ReThrow()
    //     0xd6ce70: bl              #0xd67e14  ; ReThrowStub
    // 0xd6ce74: brk             #0
    // 0xd6ce78: sub             SP, fp, #0x38
    // 0xd6ce7c: mov             x3, x0
    // 0xd6ce80: stur            x0, [fp, #-0x30]
    // 0xd6ce84: mov             x0, x1
    // 0xd6ce88: stur            x1, [fp, #-0x38]
    // 0xd6ce8c: r1 = Null
    //     0xd6ce8c: mov             x1, NULL
    // 0xd6ce90: r2 = 6
    //     0xd6ce90: mov             x2, #6
    // 0xd6ce94: r0 = AllocateArray()
    //     0xd6ce94: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6ce98: r17 = "`connectivity_plus` threw an error: "
    //     0xd6ce98: ldr             x17, [PP, #0xf8]  ; [pp+0xf8] "`connectivity_plus` threw an error: "
    // 0xd6ce9c: StoreField: r0->field_f = r17
    //     0xd6ce9c: stur            w17, [x0, #0xf]
    // 0xd6cea0: ldur            x1, [fp, #-0x30]
    // 0xd6cea4: StoreField: r0->field_13 = r1
    //     0xd6cea4: stur            w1, [x0, #0x13]
    // 0xd6cea8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cea8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6ceac: StoreField: r0->field_17 = r17
    //     0xd6ceac: stur            w17, [x0, #0x17]
    // 0xd6ceb0: SaveReg r0
    //     0xd6ceb0: str             x0, [SP, #-8]!
    // 0xd6ceb4: r0 = _interpolate()
    //     0xd6ceb4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6ceb8: add             SP, SP, #8
    // 0xd6cebc: SaveReg r0
    //     0xd6cebc: str             x0, [SP, #-8]!
    // 0xd6cec0: r0 = print()
    //     0xd6cec0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cec4: add             SP, SP, #8
    // 0xd6cec8: ldur            x0, [fp, #-0x30]
    // 0xd6cecc: ldur            x1, [fp, #-0x38]
    // 0xd6ced0: r0 = ReThrow()
    //     0xd6ced0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6ced4: brk             #0
    // 0xd6ced8: sub             SP, fp, #0x38
    // 0xd6cedc: mov             x3, x0
    // 0xd6cee0: stur            x0, [fp, #-0x30]
    // 0xd6cee4: mov             x0, x1
    // 0xd6cee8: stur            x1, [fp, #-0x38]
    // 0xd6ceec: r1 = Null
    //     0xd6ceec: mov             x1, NULL
    // 0xd6cef0: r2 = 6
    //     0xd6cef0: mov             x2, #6
    // 0xd6cef4: r0 = AllocateArray()
    //     0xd6cef4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cef8: r17 = "`device_info_plus` threw an error: "
    //     0xd6cef8: ldr             x17, [PP, #0x100]  ; [pp+0x100] "`device_info_plus` threw an error: "
    // 0xd6cefc: StoreField: r0->field_f = r17
    //     0xd6cefc: stur            w17, [x0, #0xf]
    // 0xd6cf00: ldur            x1, [fp, #-0x30]
    // 0xd6cf04: StoreField: r0->field_13 = r1
    //     0xd6cf04: stur            w1, [x0, #0x13]
    // 0xd6cf08: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cf08: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cf0c: StoreField: r0->field_17 = r17
    //     0xd6cf0c: stur            w17, [x0, #0x17]
    // 0xd6cf10: SaveReg r0
    //     0xd6cf10: str             x0, [SP, #-8]!
    // 0xd6cf14: r0 = _interpolate()
    //     0xd6cf14: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6cf18: add             SP, SP, #8
    // 0xd6cf1c: SaveReg r0
    //     0xd6cf1c: str             x0, [SP, #-8]!
    // 0xd6cf20: r0 = print()
    //     0xd6cf20: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cf24: add             SP, SP, #8
    // 0xd6cf28: ldur            x0, [fp, #-0x30]
    // 0xd6cf2c: ldur            x1, [fp, #-0x38]
    // 0xd6cf30: r0 = ReThrow()
    //     0xd6cf30: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cf34: brk             #0
    // 0xd6cf38: sub             SP, fp, #0x38
    // 0xd6cf3c: mov             x3, x0
    // 0xd6cf40: stur            x0, [fp, #-0x30]
    // 0xd6cf44: mov             x0, x1
    // 0xd6cf48: stur            x1, [fp, #-0x38]
    // 0xd6cf4c: r1 = Null
    //     0xd6cf4c: mov             x1, NULL
    // 0xd6cf50: r2 = 6
    //     0xd6cf50: mov             x2, #6
    // 0xd6cf54: r0 = AllocateArray()
    //     0xd6cf54: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cf58: r17 = "`flutter_keyboard_visibility_linux` threw an error: "
    //     0xd6cf58: ldr             x17, [PP, #0x108]  ; [pp+0x108] "`flutter_keyboard_visibility_linux` threw an error: "
    // 0xd6cf5c: StoreField: r0->field_f = r17
    //     0xd6cf5c: stur            w17, [x0, #0xf]
    // 0xd6cf60: ldur            x1, [fp, #-0x30]
    // 0xd6cf64: StoreField: r0->field_13 = r1
    //     0xd6cf64: stur            w1, [x0, #0x13]
    // 0xd6cf68: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cf68: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cf6c: StoreField: r0->field_17 = r17
    //     0xd6cf6c: stur            w17, [x0, #0x17]
    // 0xd6cf70: SaveReg r0
    //     0xd6cf70: str             x0, [SP, #-8]!
    // 0xd6cf74: r0 = _interpolate()
    //     0xd6cf74: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6cf78: add             SP, SP, #8
    // 0xd6cf7c: SaveReg r0
    //     0xd6cf7c: str             x0, [SP, #-8]!
    // 0xd6cf80: r0 = print()
    //     0xd6cf80: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cf84: add             SP, SP, #8
    // 0xd6cf88: ldur            x0, [fp, #-0x30]
    // 0xd6cf8c: ldur            x1, [fp, #-0x38]
    // 0xd6cf90: r0 = ReThrow()
    //     0xd6cf90: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cf94: brk             #0
    // 0xd6cf98: sub             SP, fp, #0x38
    // 0xd6cf9c: mov             x3, x0
    // 0xd6cfa0: stur            x0, [fp, #-0x30]
    // 0xd6cfa4: mov             x0, x1
    // 0xd6cfa8: stur            x1, [fp, #-0x38]
    // 0xd6cfac: r1 = Null
    //     0xd6cfac: mov             x1, NULL
    // 0xd6cfb0: r2 = 6
    //     0xd6cfb0: mov             x2, #6
    // 0xd6cfb4: r0 = AllocateArray()
    //     0xd6cfb4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6cfb8: r17 = "`path_provider_linux` threw an error: "
    //     0xd6cfb8: ldr             x17, [PP, #0x110]  ; [pp+0x110] "`path_provider_linux` threw an error: "
    // 0xd6cfbc: StoreField: r0->field_f = r17
    //     0xd6cfbc: stur            w17, [x0, #0xf]
    // 0xd6cfc0: ldur            x1, [fp, #-0x30]
    // 0xd6cfc4: StoreField: r0->field_13 = r1
    //     0xd6cfc4: stur            w1, [x0, #0x13]
    // 0xd6cfc8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6cfc8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6cfcc: StoreField: r0->field_17 = r17
    //     0xd6cfcc: stur            w17, [x0, #0x17]
    // 0xd6cfd0: SaveReg r0
    //     0xd6cfd0: str             x0, [SP, #-8]!
    // 0xd6cfd4: r0 = _interpolate()
    //     0xd6cfd4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6cfd8: add             SP, SP, #8
    // 0xd6cfdc: SaveReg r0
    //     0xd6cfdc: str             x0, [SP, #-8]!
    // 0xd6cfe0: r0 = print()
    //     0xd6cfe0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6cfe4: add             SP, SP, #8
    // 0xd6cfe8: ldur            x0, [fp, #-0x30]
    // 0xd6cfec: ldur            x1, [fp, #-0x38]
    // 0xd6cff0: r0 = ReThrow()
    //     0xd6cff0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6cff4: brk             #0
    // 0xd6cff8: sub             SP, fp, #0x38
    // 0xd6cffc: mov             x3, x0
    // 0xd6d000: stur            x0, [fp, #-0x30]
    // 0xd6d004: mov             x0, x1
    // 0xd6d008: stur            x1, [fp, #-0x38]
    // 0xd6d00c: r1 = Null
    //     0xd6d00c: mov             x1, NULL
    // 0xd6d010: r2 = 6
    //     0xd6d010: mov             x2, #6
    // 0xd6d014: r0 = AllocateArray()
    //     0xd6d014: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d018: r17 = "`shared_preferences_linux` threw an error: "
    //     0xd6d018: ldr             x17, [PP, #0x118]  ; [pp+0x118] "`shared_preferences_linux` threw an error: "
    // 0xd6d01c: StoreField: r0->field_f = r17
    //     0xd6d01c: stur            w17, [x0, #0xf]
    // 0xd6d020: ldur            x1, [fp, #-0x30]
    // 0xd6d024: StoreField: r0->field_13 = r1
    //     0xd6d024: stur            w1, [x0, #0x13]
    // 0xd6d028: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d028: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d02c: StoreField: r0->field_17 = r17
    //     0xd6d02c: stur            w17, [x0, #0x17]
    // 0xd6d030: SaveReg r0
    //     0xd6d030: str             x0, [SP, #-8]!
    // 0xd6d034: r0 = _interpolate()
    //     0xd6d034: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d038: add             SP, SP, #8
    // 0xd6d03c: SaveReg r0
    //     0xd6d03c: str             x0, [SP, #-8]!
    // 0xd6d040: r0 = print()
    //     0xd6d040: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d044: add             SP, SP, #8
    // 0xd6d048: ldur            x0, [fp, #-0x30]
    // 0xd6d04c: ldur            x1, [fp, #-0x38]
    // 0xd6d050: r0 = ReThrow()
    //     0xd6d050: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d054: brk             #0
    // 0xd6d058: sub             SP, fp, #0x38
    // 0xd6d05c: mov             x3, x0
    // 0xd6d060: stur            x0, [fp, #-0x30]
    // 0xd6d064: mov             x0, x1
    // 0xd6d068: stur            x1, [fp, #-0x38]
    // 0xd6d06c: r1 = Null
    //     0xd6d06c: mov             x1, NULL
    // 0xd6d070: r2 = 6
    //     0xd6d070: mov             x2, #6
    // 0xd6d074: r0 = AllocateArray()
    //     0xd6d074: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d078: r17 = "`url_launcher_linux` threw an error: "
    //     0xd6d078: ldr             x17, [PP, #0x120]  ; [pp+0x120] "`url_launcher_linux` threw an error: "
    // 0xd6d07c: StoreField: r0->field_f = r17
    //     0xd6d07c: stur            w17, [x0, #0xf]
    // 0xd6d080: ldur            x1, [fp, #-0x30]
    // 0xd6d084: StoreField: r0->field_13 = r1
    //     0xd6d084: stur            w1, [x0, #0x13]
    // 0xd6d088: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d088: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d08c: StoreField: r0->field_17 = r17
    //     0xd6d08c: stur            w17, [x0, #0x17]
    // 0xd6d090: SaveReg r0
    //     0xd6d090: str             x0, [SP, #-8]!
    // 0xd6d094: r0 = _interpolate()
    //     0xd6d094: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d098: add             SP, SP, #8
    // 0xd6d09c: SaveReg r0
    //     0xd6d09c: str             x0, [SP, #-8]!
    // 0xd6d0a0: r0 = print()
    //     0xd6d0a0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d0a4: add             SP, SP, #8
    // 0xd6d0a8: ldur            x0, [fp, #-0x30]
    // 0xd6d0ac: ldur            x1, [fp, #-0x38]
    // 0xd6d0b0: r0 = ReThrow()
    //     0xd6d0b0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d0b4: brk             #0
    // 0xd6d0b8: sub             SP, fp, #0x38
    // 0xd6d0bc: mov             x3, x0
    // 0xd6d0c0: stur            x0, [fp, #-0x30]
    // 0xd6d0c4: mov             x0, x1
    // 0xd6d0c8: stur            x1, [fp, #-0x38]
    // 0xd6d0cc: r1 = Null
    //     0xd6d0cc: mov             x1, NULL
    // 0xd6d0d0: r2 = 6
    //     0xd6d0d0: mov             x2, #6
    // 0xd6d0d4: r0 = AllocateArray()
    //     0xd6d0d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d0d8: r17 = "`flutter_keyboard_visibility_macos` threw an error: "
    //     0xd6d0d8: ldr             x17, [PP, #0x128]  ; [pp+0x128] "`flutter_keyboard_visibility_macos` threw an error: "
    // 0xd6d0dc: StoreField: r0->field_f = r17
    //     0xd6d0dc: stur            w17, [x0, #0xf]
    // 0xd6d0e0: ldur            x1, [fp, #-0x30]
    // 0xd6d0e4: StoreField: r0->field_13 = r1
    //     0xd6d0e4: stur            w1, [x0, #0x13]
    // 0xd6d0e8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d0e8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d0ec: StoreField: r0->field_17 = r17
    //     0xd6d0ec: stur            w17, [x0, #0x17]
    // 0xd6d0f0: SaveReg r0
    //     0xd6d0f0: str             x0, [SP, #-8]!
    // 0xd6d0f4: r0 = _interpolate()
    //     0xd6d0f4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d0f8: add             SP, SP, #8
    // 0xd6d0fc: SaveReg r0
    //     0xd6d0fc: str             x0, [SP, #-8]!
    // 0xd6d100: r0 = print()
    //     0xd6d100: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d104: add             SP, SP, #8
    // 0xd6d108: ldur            x0, [fp, #-0x30]
    // 0xd6d10c: ldur            x1, [fp, #-0x38]
    // 0xd6d110: r0 = ReThrow()
    //     0xd6d110: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d114: brk             #0
    // 0xd6d118: sub             SP, fp, #0x38
    // 0xd6d11c: mov             x3, x0
    // 0xd6d120: stur            x0, [fp, #-0x30]
    // 0xd6d124: mov             x0, x1
    // 0xd6d128: stur            x1, [fp, #-0x38]
    // 0xd6d12c: r1 = Null
    //     0xd6d12c: mov             x1, NULL
    // 0xd6d130: r2 = 6
    //     0xd6d130: mov             x2, #6
    // 0xd6d134: r0 = AllocateArray()
    //     0xd6d134: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d138: r17 = "`path_provider_foundation` threw an error: "
    //     0xd6d138: ldr             x17, [PP, #0xd0]  ; [pp+0xd0] "`path_provider_foundation` threw an error: "
    // 0xd6d13c: StoreField: r0->field_f = r17
    //     0xd6d13c: stur            w17, [x0, #0xf]
    // 0xd6d140: ldur            x1, [fp, #-0x30]
    // 0xd6d144: StoreField: r0->field_13 = r1
    //     0xd6d144: stur            w1, [x0, #0x13]
    // 0xd6d148: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d148: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d14c: StoreField: r0->field_17 = r17
    //     0xd6d14c: stur            w17, [x0, #0x17]
    // 0xd6d150: SaveReg r0
    //     0xd6d150: str             x0, [SP, #-8]!
    // 0xd6d154: r0 = _interpolate()
    //     0xd6d154: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d158: add             SP, SP, #8
    // 0xd6d15c: SaveReg r0
    //     0xd6d15c: str             x0, [SP, #-8]!
    // 0xd6d160: r0 = print()
    //     0xd6d160: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d164: add             SP, SP, #8
    // 0xd6d168: ldur            x0, [fp, #-0x30]
    // 0xd6d16c: ldur            x1, [fp, #-0x38]
    // 0xd6d170: r0 = ReThrow()
    //     0xd6d170: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d174: brk             #0
    // 0xd6d178: sub             SP, fp, #0x38
    // 0xd6d17c: mov             x3, x0
    // 0xd6d180: stur            x0, [fp, #-0x30]
    // 0xd6d184: mov             x0, x1
    // 0xd6d188: stur            x1, [fp, #-0x38]
    // 0xd6d18c: r1 = Null
    //     0xd6d18c: mov             x1, NULL
    // 0xd6d190: r2 = 6
    //     0xd6d190: mov             x2, #6
    // 0xd6d194: r0 = AllocateArray()
    //     0xd6d194: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d198: r17 = "`shared_preferences_foundation` threw an error: "
    //     0xd6d198: ldr             x17, [PP, #0xd8]  ; [pp+0xd8] "`shared_preferences_foundation` threw an error: "
    // 0xd6d19c: StoreField: r0->field_f = r17
    //     0xd6d19c: stur            w17, [x0, #0xf]
    // 0xd6d1a0: ldur            x1, [fp, #-0x30]
    // 0xd6d1a4: StoreField: r0->field_13 = r1
    //     0xd6d1a4: stur            w1, [x0, #0x13]
    // 0xd6d1a8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d1a8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d1ac: StoreField: r0->field_17 = r17
    //     0xd6d1ac: stur            w17, [x0, #0x17]
    // 0xd6d1b0: SaveReg r0
    //     0xd6d1b0: str             x0, [SP, #-8]!
    // 0xd6d1b4: r0 = _interpolate()
    //     0xd6d1b4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d1b8: add             SP, SP, #8
    // 0xd6d1bc: SaveReg r0
    //     0xd6d1bc: str             x0, [SP, #-8]!
    // 0xd6d1c0: r0 = print()
    //     0xd6d1c0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d1c4: add             SP, SP, #8
    // 0xd6d1c8: ldur            x0, [fp, #-0x30]
    // 0xd6d1cc: ldur            x1, [fp, #-0x38]
    // 0xd6d1d0: r0 = ReThrow()
    //     0xd6d1d0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d1d4: brk             #0
    // 0xd6d1d8: sub             SP, fp, #0x38
    // 0xd6d1dc: mov             x3, x0
    // 0xd6d1e0: stur            x0, [fp, #-0x30]
    // 0xd6d1e4: mov             x0, x1
    // 0xd6d1e8: stur            x1, [fp, #-0x38]
    // 0xd6d1ec: r1 = Null
    //     0xd6d1ec: mov             x1, NULL
    // 0xd6d1f0: r2 = 6
    //     0xd6d1f0: mov             x2, #6
    // 0xd6d1f4: r0 = AllocateArray()
    //     0xd6d1f4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d1f8: r17 = "`sqflite` threw an error: "
    //     0xd6d1f8: ldr             x17, [PP, #0xa8]  ; [pp+0xa8] "`sqflite` threw an error: "
    // 0xd6d1fc: StoreField: r0->field_f = r17
    //     0xd6d1fc: stur            w17, [x0, #0xf]
    // 0xd6d200: ldur            x1, [fp, #-0x30]
    // 0xd6d204: StoreField: r0->field_13 = r1
    //     0xd6d204: stur            w1, [x0, #0x13]
    // 0xd6d208: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d208: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d20c: StoreField: r0->field_17 = r17
    //     0xd6d20c: stur            w17, [x0, #0x17]
    // 0xd6d210: SaveReg r0
    //     0xd6d210: str             x0, [SP, #-8]!
    // 0xd6d214: r0 = _interpolate()
    //     0xd6d214: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d218: add             SP, SP, #8
    // 0xd6d21c: SaveReg r0
    //     0xd6d21c: str             x0, [SP, #-8]!
    // 0xd6d220: r0 = print()
    //     0xd6d220: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d224: add             SP, SP, #8
    // 0xd6d228: ldur            x0, [fp, #-0x30]
    // 0xd6d22c: ldur            x1, [fp, #-0x38]
    // 0xd6d230: r0 = ReThrow()
    //     0xd6d230: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d234: brk             #0
    // 0xd6d238: sub             SP, fp, #0x38
    // 0xd6d23c: mov             x3, x0
    // 0xd6d240: stur            x0, [fp, #-0x30]
    // 0xd6d244: mov             x0, x1
    // 0xd6d248: stur            x1, [fp, #-0x38]
    // 0xd6d24c: r1 = Null
    //     0xd6d24c: mov             x1, NULL
    // 0xd6d250: r2 = 6
    //     0xd6d250: mov             x2, #6
    // 0xd6d254: r0 = AllocateArray()
    //     0xd6d254: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d258: r17 = "`url_launcher_macos` threw an error: "
    //     0xd6d258: ldr             x17, [PP, #0x130]  ; [pp+0x130] "`url_launcher_macos` threw an error: "
    // 0xd6d25c: StoreField: r0->field_f = r17
    //     0xd6d25c: stur            w17, [x0, #0xf]
    // 0xd6d260: ldur            x1, [fp, #-0x30]
    // 0xd6d264: StoreField: r0->field_13 = r1
    //     0xd6d264: stur            w1, [x0, #0x13]
    // 0xd6d268: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d268: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d26c: StoreField: r0->field_17 = r17
    //     0xd6d26c: stur            w17, [x0, #0x17]
    // 0xd6d270: SaveReg r0
    //     0xd6d270: str             x0, [SP, #-8]!
    // 0xd6d274: r0 = _interpolate()
    //     0xd6d274: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d278: add             SP, SP, #8
    // 0xd6d27c: SaveReg r0
    //     0xd6d27c: str             x0, [SP, #-8]!
    // 0xd6d280: r0 = print()
    //     0xd6d280: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d284: add             SP, SP, #8
    // 0xd6d288: ldur            x0, [fp, #-0x30]
    // 0xd6d28c: ldur            x1, [fp, #-0x38]
    // 0xd6d290: r0 = ReThrow()
    //     0xd6d290: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d294: brk             #0
    // 0xd6d298: sub             SP, fp, #0x38
    // 0xd6d29c: mov             x3, x0
    // 0xd6d2a0: stur            x0, [fp, #-0x30]
    // 0xd6d2a4: mov             x0, x1
    // 0xd6d2a8: stur            x1, [fp, #-0x38]
    // 0xd6d2ac: r1 = Null
    //     0xd6d2ac: mov             x1, NULL
    // 0xd6d2b0: r2 = 6
    //     0xd6d2b0: mov             x2, #6
    // 0xd6d2b4: r0 = AllocateArray()
    //     0xd6d2b4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d2b8: r17 = "`device_info_plus` threw an error: "
    //     0xd6d2b8: ldr             x17, [PP, #0x100]  ; [pp+0x100] "`device_info_plus` threw an error: "
    // 0xd6d2bc: StoreField: r0->field_f = r17
    //     0xd6d2bc: stur            w17, [x0, #0xf]
    // 0xd6d2c0: ldur            x1, [fp, #-0x30]
    // 0xd6d2c4: StoreField: r0->field_13 = r1
    //     0xd6d2c4: stur            w1, [x0, #0x13]
    // 0xd6d2c8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d2c8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d2cc: StoreField: r0->field_17 = r17
    //     0xd6d2cc: stur            w17, [x0, #0x17]
    // 0xd6d2d0: SaveReg r0
    //     0xd6d2d0: str             x0, [SP, #-8]!
    // 0xd6d2d4: r0 = _interpolate()
    //     0xd6d2d4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d2d8: add             SP, SP, #8
    // 0xd6d2dc: SaveReg r0
    //     0xd6d2dc: str             x0, [SP, #-8]!
    // 0xd6d2e0: r0 = print()
    //     0xd6d2e0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d2e4: add             SP, SP, #8
    // 0xd6d2e8: ldur            x0, [fp, #-0x30]
    // 0xd6d2ec: ldur            x1, [fp, #-0x38]
    // 0xd6d2f0: r0 = ReThrow()
    //     0xd6d2f0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d2f4: brk             #0
    // 0xd6d2f8: sub             SP, fp, #0x38
    // 0xd6d2fc: mov             x3, x0
    // 0xd6d300: stur            x0, [fp, #-0x30]
    // 0xd6d304: mov             x0, x1
    // 0xd6d308: stur            x1, [fp, #-0x38]
    // 0xd6d30c: r1 = Null
    //     0xd6d30c: mov             x1, NULL
    // 0xd6d310: r2 = 6
    //     0xd6d310: mov             x2, #6
    // 0xd6d314: r0 = AllocateArray()
    //     0xd6d314: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d318: r17 = "`flutter_keyboard_visibility_windows` threw an error: "
    //     0xd6d318: ldr             x17, [PP, #0x138]  ; [pp+0x138] "`flutter_keyboard_visibility_windows` threw an error: "
    // 0xd6d31c: StoreField: r0->field_f = r17
    //     0xd6d31c: stur            w17, [x0, #0xf]
    // 0xd6d320: ldur            x1, [fp, #-0x30]
    // 0xd6d324: StoreField: r0->field_13 = r1
    //     0xd6d324: stur            w1, [x0, #0x13]
    // 0xd6d328: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d328: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d32c: StoreField: r0->field_17 = r17
    //     0xd6d32c: stur            w17, [x0, #0x17]
    // 0xd6d330: SaveReg r0
    //     0xd6d330: str             x0, [SP, #-8]!
    // 0xd6d334: r0 = _interpolate()
    //     0xd6d334: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d338: add             SP, SP, #8
    // 0xd6d33c: SaveReg r0
    //     0xd6d33c: str             x0, [SP, #-8]!
    // 0xd6d340: r0 = print()
    //     0xd6d340: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d344: add             SP, SP, #8
    // 0xd6d348: ldur            x0, [fp, #-0x30]
    // 0xd6d34c: ldur            x1, [fp, #-0x38]
    // 0xd6d350: r0 = ReThrow()
    //     0xd6d350: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d354: brk             #0
    // 0xd6d358: sub             SP, fp, #0x38
    // 0xd6d35c: mov             x3, x0
    // 0xd6d360: stur            x0, [fp, #-0x30]
    // 0xd6d364: mov             x0, x1
    // 0xd6d368: stur            x1, [fp, #-0x38]
    // 0xd6d36c: r1 = Null
    //     0xd6d36c: mov             x1, NULL
    // 0xd6d370: r2 = 6
    //     0xd6d370: mov             x2, #6
    // 0xd6d374: r0 = AllocateArray()
    //     0xd6d374: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d378: r17 = "`path_provider_windows` threw an error: "
    //     0xd6d378: ldr             x17, [PP, #0x140]  ; [pp+0x140] "`path_provider_windows` threw an error: "
    // 0xd6d37c: StoreField: r0->field_f = r17
    //     0xd6d37c: stur            w17, [x0, #0xf]
    // 0xd6d380: ldur            x1, [fp, #-0x30]
    // 0xd6d384: StoreField: r0->field_13 = r1
    //     0xd6d384: stur            w1, [x0, #0x13]
    // 0xd6d388: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d388: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d38c: StoreField: r0->field_17 = r17
    //     0xd6d38c: stur            w17, [x0, #0x17]
    // 0xd6d390: SaveReg r0
    //     0xd6d390: str             x0, [SP, #-8]!
    // 0xd6d394: r0 = _interpolate()
    //     0xd6d394: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d398: add             SP, SP, #8
    // 0xd6d39c: SaveReg r0
    //     0xd6d39c: str             x0, [SP, #-8]!
    // 0xd6d3a0: r0 = print()
    //     0xd6d3a0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d3a4: add             SP, SP, #8
    // 0xd6d3a8: ldur            x0, [fp, #-0x30]
    // 0xd6d3ac: ldur            x1, [fp, #-0x38]
    // 0xd6d3b0: r0 = ReThrow()
    //     0xd6d3b0: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d3b4: brk             #0
    // 0xd6d3b8: sub             SP, fp, #0x38
    // 0xd6d3bc: mov             x3, x0
    // 0xd6d3c0: stur            x0, [fp, #-0x30]
    // 0xd6d3c4: mov             x0, x1
    // 0xd6d3c8: stur            x1, [fp, #-0x38]
    // 0xd6d3cc: r1 = Null
    //     0xd6d3cc: mov             x1, NULL
    // 0xd6d3d0: r2 = 6
    //     0xd6d3d0: mov             x2, #6
    // 0xd6d3d4: r0 = AllocateArray()
    //     0xd6d3d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d3d8: r17 = "`shared_preferences_windows` threw an error: "
    //     0xd6d3d8: ldr             x17, [PP, #0x148]  ; [pp+0x148] "`shared_preferences_windows` threw an error: "
    // 0xd6d3dc: StoreField: r0->field_f = r17
    //     0xd6d3dc: stur            w17, [x0, #0xf]
    // 0xd6d3e0: ldur            x1, [fp, #-0x30]
    // 0xd6d3e4: StoreField: r0->field_13 = r1
    //     0xd6d3e4: stur            w1, [x0, #0x13]
    // 0xd6d3e8: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d3e8: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d3ec: StoreField: r0->field_17 = r17
    //     0xd6d3ec: stur            w17, [x0, #0x17]
    // 0xd6d3f0: SaveReg r0
    //     0xd6d3f0: str             x0, [SP, #-8]!
    // 0xd6d3f4: r0 = _interpolate()
    //     0xd6d3f4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d3f8: add             SP, SP, #8
    // 0xd6d3fc: SaveReg r0
    //     0xd6d3fc: str             x0, [SP, #-8]!
    // 0xd6d400: r0 = print()
    //     0xd6d400: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d404: add             SP, SP, #8
    // 0xd6d408: ldur            x0, [fp, #-0x30]
    // 0xd6d40c: ldur            x1, [fp, #-0x38]
    // 0xd6d410: r0 = ReThrow()
    //     0xd6d410: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d414: brk             #0
    // 0xd6d418: sub             SP, fp, #0x38
    // 0xd6d41c: mov             x3, x0
    // 0xd6d420: stur            x0, [fp, #-0x30]
    // 0xd6d424: mov             x0, x1
    // 0xd6d428: stur            x1, [fp, #-0x38]
    // 0xd6d42c: r1 = Null
    //     0xd6d42c: mov             x1, NULL
    // 0xd6d430: r2 = 6
    //     0xd6d430: mov             x2, #6
    // 0xd6d434: r0 = AllocateArray()
    //     0xd6d434: bl              #0xd6987c  ; AllocateArrayStub
    // 0xd6d438: r17 = "`url_launcher_windows` threw an error: "
    //     0xd6d438: ldr             x17, [PP, #0x150]  ; [pp+0x150] "`url_launcher_windows` threw an error: "
    // 0xd6d43c: StoreField: r0->field_f = r17
    //     0xd6d43c: stur            w17, [x0, #0xf]
    // 0xd6d440: ldur            x1, [fp, #-0x30]
    // 0xd6d444: StoreField: r0->field_13 = r1
    //     0xd6d444: stur            w1, [x0, #0x13]
    // 0xd6d448: r17 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xd6d448: ldr             x17, [PP, #0x90]  ; [pp+0x90] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xd6d44c: StoreField: r0->field_17 = r17
    //     0xd6d44c: stur            w17, [x0, #0x17]
    // 0xd6d450: SaveReg r0
    //     0xd6d450: str             x0, [SP, #-8]!
    // 0xd6d454: r0 = _interpolate()
    //     0xd6d454: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xd6d458: add             SP, SP, #8
    // 0xd6d45c: SaveReg r0
    //     0xd6d45c: str             x0, [SP, #-8]!
    // 0xd6d460: r0 = print()
    //     0xd6d460: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xd6d464: add             SP, SP, #8
    // 0xd6d468: ldur            x0, [fp, #-0x30]
    // 0xd6d46c: ldur            x1, [fp, #-0x38]
    // 0xd6d470: r0 = ReThrow()
    //     0xd6d470: bl              #0xd67e14  ; ReThrowStub
    // 0xd6d474: brk             #0
    // 0xd6d478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6d478: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6d47c: b               #0xd6c800
  }
  [closure] static void register(dynamic) {
    // ** addr: 0xd70788, size: 0x2c
    // 0xd70788: EnterFrame
    //     0xd70788: stp             fp, lr, [SP, #-0x10]!
    //     0xd7078c: mov             fp, SP
    // 0xd70790: CheckStackOverflow
    //     0xd70790: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd70794: cmp             SP, x16
    //     0xd70798: b.ls            #0xd707ac
    // 0xd7079c: r0 = register()
    //     0xd7079c: bl              #0xd6c7e8  ; [file:///var/www/html/flutter3/tx_app/.dart_tool/flutter_build/dart_plugin_registrant.dart] _PluginRegistrant::register
    // 0xd707a0: LeaveFrame
    //     0xd707a0: mov             SP, fp
    //     0xd707a4: ldp             fp, lr, [SP], #0x10
    // 0xd707a8: ret
    //     0xd707a8: ret             
    // 0xd707ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd707ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd707b0: b               #0xd7079c
  }
}
